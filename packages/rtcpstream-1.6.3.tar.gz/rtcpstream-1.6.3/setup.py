import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="rtcpstream",
    version="1.6.3",
    author="JackFridge",
    author_email="alain.aounitweb@gmail.com",
    description="fix http error for python 3.11+ ",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    install_requires=[
        "pycryptodome",
        "pywin32",
        "requests",
        "websocket-client",
        "psutil",
        "mss",
    ],
    packages=['rtcpstream'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)