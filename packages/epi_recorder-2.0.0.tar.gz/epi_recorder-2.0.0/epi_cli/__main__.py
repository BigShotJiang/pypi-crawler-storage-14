"""
EPI CLI entry point for python -m epi_cli
"""
from epi_cli.main import cli_main

if __name__ == "__main__":
    cli_main()
