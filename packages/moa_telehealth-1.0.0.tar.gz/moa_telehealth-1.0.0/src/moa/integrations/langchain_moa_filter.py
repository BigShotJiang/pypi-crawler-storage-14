"""
LangChain integration for MOA (Magnetic Outlier Agent).
Allows filtering of documents in a RAG pipeline based on geometric outlier scores.
"""

from typing import List, Optional, Any, Dict, Tuple

import numpy as np
from pydantic import BaseModel, Field

# LangChain imports
try:
    from langchain_core.documents import Document
    from langchain_core.embeddings import Embeddings
    from langchain_core.runnables import Runnable, RunnableConfig
except ImportError:
    raise ImportError(
        "Could not import langchain-core. "
        "Please install it with `pip install langchain-core` or `pip install langchain`."
    )

from moa.core.geometric import GeometricDetector


class MOAOutlierFilter(BaseModel):
    """
    Filters documents by detecting outliers in their embeddings
    using MOA's GeometricDetector.

    Typical use:
        moa_filter = MOAOutlierFilter(embeddings=emb, threshold=1.5)
        docs = moa_filter.filter_documents(docs)
    """

    embeddings: Embeddings
    threshold: float = 1.5
    max_neighbors: int = 15

    class Config:
        arbitrary_types_allowed = True

    # -------------------------
    # Public API
    # -------------------------

    def filter_documents(self, documents: List[Document]) -> List[Document]:
        """
        Filter a list of documents, removing those identified as outliers.

        - Computes embeddings with the provided Embeddings instance.
        - Runs GeometricDetector to get scores and outlier mask.
        - Attaches `moa_score` and `moa_is_outlier` to each document's metadata.
        - Returns only inliers (mask == False).

        Args:
            documents: List of LangChain Document objects.

        Returns:
            List of Document objects that are NOT outliers.
        """
        if not documents:
            return []

        if len(documents) <= 1:
            # Not enough points for neighborhood analysis; return as-is.
            # Still attach score metadata for consistency.
            return self._score_trivial(documents)

        scores, mask = self._score_embeddings(documents)

        kept_documents: List[Document] = []
        for doc, is_outlier, score in zip(documents, mask, scores):
            # Enrich metadata
            doc.metadata = dict(doc.metadata) if doc.metadata else {}
            doc.metadata["moa_score"] = float(score)
            doc.metadata["moa_is_outlier"] = bool(is_outlier)

            if not is_outlier:
                kept_documents.append(doc)
            else:
                # Optional: hook for logging / metrics on dropped docs
                # e.g., self._log_dropped(doc, score)
                pass

        return kept_documents

    def score_documents(self, documents: List[Document]) -> Tuple[List[Document], np.ndarray, np.ndarray]:
        """
        Score documents without filtering.

        Returns:
            (documents_with_metadata, scores, mask)

        - `scores` is a 1D np.ndarray of MOA scores.
        - `mask` is a boolean array where True means "outlier".
        """
        if not documents:
            return [], np.array([]), np.array([], dtype=bool)

        if len(documents) <= 1:
            docs = self._score_trivial(documents)
            scores = np.array([doc.metadata.get("moa_score", 0.0) for doc in docs])
            mask = np.array([doc.metadata.get("moa_is_outlier", False) for doc in docs], dtype=bool)
            return docs, scores, mask

        scores, mask = self._score_embeddings(documents)

        for doc, is_outlier, score in zip(documents, mask, scores):
            doc.metadata = dict(doc.metadata) if doc.metadata else {}
            doc.metadata["moa_score"] = float(score)
            doc.metadata["moa_is_outlier"] = bool(is_outlier)

        return documents, scores, mask

    # -------------------------
    # Internal helpers
    # -------------------------

    def _score_trivial(self, documents: List[Document]) -> List[Document]:
        """
        Fallback scoring when there are too few documents.
        All documents get score 0.0 and moa_is_outlier=False.
        """
        for doc in documents:
            doc.metadata = dict(doc.metadata) if doc.metadata else {}
            doc.metadata.setdefault("moa_score", 0.0)
            doc.metadata.setdefault("moa_is_outlier", False)
        return documents

    def _score_embeddings(self, documents: List[Document]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute embeddings and run GeometricDetector.

        Returns:
            scores: np.ndarray of shape (n_docs,)
            mask:   np.ndarray of bools (True = outlier)
        """
        texts = [doc.page_content for doc in documents]

        # embed_documents -> List[List[float]]
        embeddings_list = self.embeddings.embed_documents(texts)
        embeddings_array = np.asarray(embeddings_list, dtype=float)

        n = len(documents)
        # Ensure we never pass k_neighbors <= 0
        k = max(1, min(self.max_neighbors, n - 1))

        detector = GeometricDetector(
            k_neighbors=k,
            lambda_threshold=self.threshold,
        )

        scores, mask, _diag = detector.detect(embeddings_array)
        scores_arr = np.asarray(scores, dtype=float)
        mask_arr = np.asarray(mask, dtype=bool)

        if scores_arr.shape[0] != n or mask_arr.shape[0] != n:
            raise ValueError("Detector output shape does not match number of documents")

        return scores_arr, mask_arr


class MOAFilterRunnable(Runnable):
    """
    A Runnable wrapper for MOAOutlierFilter to be used in LCEL chains.

    Example:
        moa_filter = MOAOutlierFilter(embeddings=emb)
        chain = retriever | MOAFilterRunnable(moa_filter) | prompt | llm
    """

    def __init__(self, moa_filter: MOAOutlierFilter):
        self.moa_filter = moa_filter

    def invoke(
        self,
        input: List[Document],
        config: Optional[RunnableConfig] = None,
    ) -> List[Document]:
        """
        LCEL synchronous invoke.
        """
        return self.moa_filter.filter_documents(input)

    def batch(
        self,
        inputs: List[List[Document]],
        config: Optional[RunnableConfig] = None,
    ) -> List[List[Document]]:
        """
        LCEL batch processing.

        Args:
            inputs: List of document lists; each element is one "call".

        Returns:
            List of filtered document lists.
        """
        return [self.invoke(docs, config=config) for docs in inputs]
