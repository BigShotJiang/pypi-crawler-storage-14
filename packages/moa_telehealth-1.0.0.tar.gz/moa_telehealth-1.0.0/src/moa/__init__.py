"""
MOA Telehealth - Magnetic Outlier Agent Package
"""
__version__ = "1.0.0"
