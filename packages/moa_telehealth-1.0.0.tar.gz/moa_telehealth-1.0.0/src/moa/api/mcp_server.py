"""
MOA MCP Server - Model Context Protocol Integration
Exposes Magnetic Outlier Agent as an MCP tool for Claude/Cursor integration.

Usage: @MOA audit my RAG chunks
"""

import json
import numpy as np
from typing import List, Dict, Any
from ..core.geometric import GeometricDetector

# FastMCP Integration (if using mcp library)
try:
    from mcp.server.fastmcp import FastMCP
    
    mcp = FastMCP("MOA Outlier Auditor", json_response=True)
    
    @mcp.tool()
    def audit_rag_context(chunks: List[Dict[str, Any]], k: int = 10, threshold: float = 2.0) -> str:
        """
        Audit RAG retrieved chunks for outliers in embedding space.
        
        Args:
            chunks: List of {'text': str, 'embedding': list[float]}
            k: Number of neighbors for local density (default 10)
            threshold: Outlier score threshold in std devs (default 2.0)
        
        Returns:
            JSON string with outlier analysis results
        """
        if not chunks:
            return json.dumps({"error": "No chunks provided"})
        
        try:
            embeddings = np.array([chunk['embedding'] for chunk in chunks])
            
            # Use core GeometricDetector
            detector = GeometricDetector(k_neighbors=k, lambda_threshold=threshold)
            scores, mask, components = detector.detect(embeddings, return_components=True)
            
            # Enrich with texts for flagged chunks
            outliers_indices = np.where(mask)[0]
            flagged = []
            
            for i in outliers_indices:
                explanation = detector.explain_outlier(i, embeddings, scores, components)
                flagged.append({
                    "index": int(i),
                    "text": chunks[i].get("text", ""),
                    "score": float(scores[i]),
                    "outlier_type": "high_risk",
                    "explanation": explanation
                })
            
            results = {
                "scores": scores.tolist(),
                "outliers_indices": outliers_indices.tolist(),
                "num_outliers": len(outliers_indices),
                "total_chunks": len(embeddings),
                "summary": f"Detected {len(outliers_indices)} outliers out of {len(embeddings)} chunks ({100*len(outliers_indices)/len(embeddings):.1f}%)",
                "flagged_chunks": flagged
            }
            
            return json.dumps(results, indent=2)
        
        except Exception as e:
            return json.dumps({"error": str(e)})
    
    
    def run():
        """Entry point for the MCP server."""
        mcp.run(transport="stdio")

    if __name__ == "__main__":
        run()

except ImportError:
    # Fallback: CLI mode if MCP not installed
    def run():
        print("MOA MCP Server")
        print("Install with: pip install mcp")
        print("\nStandalone mode: Use moa.core.geometric.GeometricDetector directly.")

    if __name__ == "__main__":
        run()
