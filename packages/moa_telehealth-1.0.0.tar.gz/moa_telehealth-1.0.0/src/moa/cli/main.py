import click
import numpy as np
import pandas as pd
from pathlib import Path
import json
from ..core.geometric import GeometricDetector
from ..core.fourier import FourierAnalyzer

@click.group()
@click.version_option()
def cli():
    """MOA Telehealth CLI - Compliance Monitoring Tool"""
    pass

@cli.command()
@click.option('--input', '-i', required=True, type=click.Path(exists=True), help='Input CSV/NPY file with embeddings')
@click.option('--output', '-o', type=click.Path(), help='Output report file (JSON/CSV)')
@click.option('--threshold', '-t', default=1.5, help='Outlier detection threshold (sigma)')
def detect(input, output, threshold):
    """Run Geometric Outlier Detection (Stage I)"""
    click.echo(f"Loading data from {input}...")
    
    # Load data
    file_path = Path(input)
    if file_path.suffix == '.csv':
        df = pd.read_csv(file_path)
        # Assume embeddings are in columns or a specific column - simplified for demo
        # Try to find numeric columns
        embeddings = df.select_dtypes(include=[np.number]).values
    elif file_path.suffix == '.npy':
        embeddings = np.load(file_path)
    else:
        click.echo("Error: Unsupported file format. Use CSV or NPY.")
        return

    click.echo(f"Running geometric detection on {len(embeddings)} records with threshold {threshold}...")
    
    detector = GeometricDetector(lambda_threshold=threshold)
    scores, mask, components = detector.detect(embeddings, return_components=True)
    
    outlier_count = np.sum(mask)
    click.echo(f"Found {outlier_count} outliers.")
    
    if output:
        results = {
            'total_records': len(embeddings),
            'outlier_count': int(outlier_count),
            'outlier_indices': np.where(mask)[0].tolist(),
            'scores': scores.tolist()
        }
        with open(output, 'w') as f:
            json.dump(results, f, indent=2)
        click.echo(f"Results saved to {output}")
    else:
        # Print top outliers
        if outlier_count > 0:
            click.echo("\nTop Outliers:")
            outlier_indices = np.where(mask)[0]
            # Sort by score descending
            sorted_idx = outlier_indices[np.argsort(scores[outlier_indices])[::-1]]
            
            for idx in sorted_idx[:5]:
                explanation = detector.explain_outlier(idx, embeddings, scores, components)
                click.echo(f"\n{explanation}")

@cli.command()
@click.option('--input', '-i', required=True, type=click.Path(exists=True), help='Input file with sequential norms')
@click.option('--window', '-w', default=50, help='Monitoring window size')
def monitor(input, window):
    """Run Fourier Sequential Monitoring (Stage II)"""
    click.echo(f"Monitoring sequence from {input}...")
    # Implementation stub
    click.echo("Sequential monitoring complete.")

if __name__ == '__main__':
    cli()
