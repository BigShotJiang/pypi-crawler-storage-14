import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock, MagicMock
from backend.moa_proxy_api import app

client = TestClient(app)

def test_generate_endpoint_success():
    """Test successful generation with mocked Gemini response."""
    mock_response_data = {
        "candidates": [
            {
                "content": {
                    "parts": [
                        {"text": "Mocked Gemini Response"}
                    ]
                }
            }
        ]
    }

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = mock_response_data
    mock_response.text = "OK"

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_response

        response = client.post(
            "/api/generate",
            json={"prompt": "Test prompt"}
        )

        assert response.status_code == 200
        assert response.json() == {"text": "Mocked Gemini Response"}
        
        # Verify correct URL and headers were used
        call_args = mock_post.call_args
        assert "generativelanguage.googleapis.com" in call_args[0][0]
        assert "x-goog-api-key" in call_args[1]["headers"]

def test_generate_endpoint_gemini_error():
    """Test handling of Gemini API errors."""
    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.text = "Bad Request"

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_response

        response = client.post(
            "/api/generate",
            json={"prompt": "Test prompt"}
        )

        assert response.status_code == 502
        assert "Gemini error" in response.json()["detail"]

def test_generate_endpoint_malformed_response():
    """Test handling of unexpected Gemini response format."""
    mock_response_data = {} # Missing candidates
    
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = mock_response_data

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock) as mock_post:
        mock_post.return_value = mock_response

        response = client.post(
            "/api/generate",
            json={"prompt": "Test prompt"}
        )

        assert response.status_code == 502
        assert "Unexpected Gemini response format" in response.json()["detail"]
