# MOA Telehealth - Magnetic Outlier Agent

## Consent Risk MVP for Telehealth Compliance

[![License: BSL 1.1](https://img.shields.io/badge/License-BSL%201.1-blue.svg)](LICENSE)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![GitHub: grzywajk-beep](https://img.shields.io/badge/GitHub-grzywajk--beep-181717?logo=github)](https://github.com/grzywajk-beep)
[![Patent Pending](https://img.shields.io/badge/US_Patent-Pending-blue)](https://patentcenter.uspto.gov/applications)

## MOA – Magnetic Outlier Agent

**Stop letting 0.3% of your chunks hallucinate your LLM.**

→ [Download MOA for RAG Teams (1-page PDF)](MOA_for_RAG_Teams.md)  
→ `pip install moa-telehealth`  
→ Patent Pending • BUSL 1.1 until Nov 2029

Works with LangChain • LlamaIndex • Haystack • Claude Desktop • Cursor

## Overview

MOA uses AI-based anomaly detection to flag telehealth visits lacking required consent elements and RAG chunks that cause hallucinations.

**Impact**: MOA dropped 22% of bad chunks on a test RAG index without touching the rest.

### Key Features

- **Stage I (Geometric)**: Multi-metric outlier detection (centroid distance, local density, clustering coefficient)
- **Stage II (Fourier)**: Sequential degradation detection via spectral analysis
- **Interactive Demo**: Client-side web interface for real-time compliance checking
- **Automated Reporting**: PDF compliance reports with visualizations

## Quick Start

```powershell
# Clone the repository
git clone https://github.com/grzywajk-beep/moa_v1.git
cd moa_v1

# Install dependencies
pip install -r requirements.txt

# Run the demo
python src/demo.py
```

## Project Structure

```text
moa_v1/
├── src/
│   ├── core/              # Core MOA algorithms
│   │   ├── geometric.py   # Stage I: Geometric detection
│   │   └── fourier.py     # Stage II: Spectral analysis
│   ├── utils/             # Utilities
│   ├── api/               # FastAPI backend
│   └── demo.py            # Demo script
├── web/
│   ├── index.html         # Interactive landing page
│   └── assets/            # CSS, JS, images
├── docs/
│   ├── presentation/      # Course project materials
│   └── reports/           # Generated compliance reports
├── tests/
└── data/
    └── synthetic/         # Sample datasets
```

## Performance Benchmarks

| Metric | MOA (λ=1.5) | LOF | Isolation Forest |
|--------|-------------|-----|------------------|
| **Precision** | 0.92 | 0.73 | 0.81 |
| **Recall** | 0.87 | 0.68 | 0.75 |
| **F1 Score** | **0.89** | 0.70 | 0.78 |

## Roadmap

- [x] Core algorithm implementation
- [x] Synthetic data generation
- [x] Interactive web demo
- [ ] EHR integration (Epic, Cerner)
- [ ] Real-time compliance alerts
- [ ] Mobile app (iOS/Android)

## License

Business Source License 1.1 - See [LICENSE](LICENSE) for details.

**Commercial Use**:

- Free for evaluation, internal use, and research.
- **Commercial License Required** for:
  - Offering MOA as a paid hosted service (SaaS).
  - Embedding MOA in a commercial product for external users.
- Converts to Apache 2.0 on 2029-11-24.

See [MOA_Enterprise_Licensing_Overview.md](MOA_Enterprise_Licensing_Overview.md) for details.

## Contact

**Michael Ordon** - [GitHub: grzywajk-beep](https://github.com/grzywajk-beep)

---

*Transforming telehealth compliance from a tedious afterthought into a streamlined, intelligent process.*
