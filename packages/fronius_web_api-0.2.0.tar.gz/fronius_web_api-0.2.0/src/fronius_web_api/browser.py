from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional

import requests

from .exceptions import RequestError, AuthError

logger = logging.getLogger(__name__)


def _join_url(base: str, path: str) -> str:
    if not base:
        return path
    if path.startswith("http://") or path.startswith("https://"):
        return path
    if base.endswith("/") and path.startswith("/"):
        return base[:-1] + path
    if not base.endswith("/") and not path.startswith("/"):
        return base + "/" + path
    return base + path


class BrowserSession:
    """
    Thin wrapper around requests.Session that emulates a browser sufficiently to
    authenticate to a Fronius Gen24 web UI.
    - Sets a browser-like User-Agent
    """

    def __init__(
        self,
        base_url: str,
        verify_ssl: bool = True,
        timeout: float = 10.0,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.verify_ssl = verify_ssl
        self.timeout = timeout

        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/125.0 Safari/537.36"
                ),
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "en-US,en;q=0.5",
                "Connection": "keep-alive",
            }
        )
        if headers:
            self.session.headers.update(headers)

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Any | None = None,
        data: Any | None = None,
        headers: Optional[Dict[str, str]] = None,
        allow_redirects: bool = True,
        retries: int = 1,
        retry_backoff: float = 0.5,
        expected_status: tuple[int, ...] = (200, 204),
        auth: Any | None = None,
    ) -> requests.Response:
        url = _join_url(self.base_url, path)

        last_exc: Exception | None = None
        for attempt in range(retries + 1):
            try:
                resp = self.session.request(
                    method,
                    url,
                    params=params,
                    json=json,
                    data=data,
                    headers=headers,
                    verify=self.verify_ssl,
                    timeout=self.timeout,
                    allow_redirects=allow_redirects,
                    auth=auth,
                )

                if resp.status_code not in expected_status:
                    if resp.status_code == 404:
                        raise RequestError(f"Not found: {url}", status=404)
                    if resp.status_code == 401:
                        raise RequestError("Unauthorized", status=401)
                    if resp.status_code == 403:
                        raise AuthError("Forbidden (Authentication failed)")
                    raise RequestError(
                        f"Unexpected status {resp.status_code} for {url}",
                        status=resp.status_code,
                    )
                return resp
            except (requests.RequestException, RequestError) as e:
                last_exc = e
                if attempt < retries:
                    time.sleep(retry_backoff * (2 ** attempt))
                else:
                    break
        # If we got here
        if isinstance(last_exc, RequestError):
            raise last_exc
        raise RequestError(f"Request failed for {url}: {last_exc}")
