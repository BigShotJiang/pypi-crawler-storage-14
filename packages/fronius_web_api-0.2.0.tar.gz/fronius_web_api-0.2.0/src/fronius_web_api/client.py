from __future__ import annotations

from typing import Any, Dict, Optional
from enum import StrEnum

from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator, RootModel

from .auth import HTTPFroniusDigestAuth
from .browser import BrowserSession
from .exceptions import AuthError, RequestError


DEFAULT_DIGEST_LOGIN_URLS = (
    "/api/commands/Login",
)


class BatteryLimitType(StrEnum):
    CHARGE_MIN = "CHARGE_MIN"
    CHARGE_MAX = "CHARGE_MAX"
    DISCHARGE_MIN = "DISCHARGE_MIN"
    DISCHARGE_MAX = "DISCHARGE_MAX"


# ------------------------ Pydantic v2 models ------------------------
class TimeTable(BaseModel):
    Start: str
    End: str

    @field_validator("Start", "End")
    @classmethod
    def validate_time(cls, v: str) -> str:
        import re
        if not re.match(r"^(?:[01]\d|2[0-3]):[0-5]\d$", v):
            raise ValueError("time must be HH:MM in 24-hour format (HH:MM)")
        return v


class Weekdays(BaseModel):
    Mon: bool = False
    Tue: bool = False
    Wed: bool = False
    Thu: bool = False
    Fri: bool = False
    Sat: bool = False
    Sun: bool = False


class TimeOfUseItem(BaseModel):
    Active: bool
    Power: int = Field(ge=0)
    ScheduleType: BatteryLimitType
    TimeTable: TimeTable
    Weekdays: Weekdays


class TimeOfUsePayload(RootModel[list[TimeOfUseItem]]):
    # Optional: enforce at least one item and a simple cross-field check on the first element
    @model_validator(mode="after")
    def check_non_empty(self):
        items = self.root
        if not items and not len(items) == 0:
            raise ValueError("At least one schedule item is required")
        try:
            tt = items[0].TimeTable
            s_h, s_m = map(int, tt.Start.split(":"))
            e_h, e_m = map(int, tt.End.split(":"))
            if (s_h, s_m) > (e_h, e_m):
                raise ValueError("TimeTable.Start must be <= TimeTable.End")
        except Exception:
            # If parsing fails, field-level validators will raise; ignore here
            pass
        return self


def _remove_underscore_fields(obj):
    if isinstance(obj, dict):
        # Filter out keys that start with '_', and recurse on values
        return {
            k: _remove_underscore_fields(v)
            for k, v in obj.items()
            if not k.startswith('_')
        }
    elif isinstance(obj, list):
        # Recurse into each element
        return [_remove_underscore_fields(item) for item in obj]
    else:
        # Base case: return non-dict, non-list values as-is
        return obj


class FroniusGen24Client:
    """
    Synchronous client for Fronius Gen24 inverters.

    This client maintains a browser-like session and can log into the web UI
    to access settings that are not available via the public solar_api.
    """

    # ------------------------ Public draft schema ------------------------
    # Expose the Pydantic models so library users can import and build payloads.
    TimeTableModel = TimeTable
    WeekdaysModel = Weekdays
    TimeOfUseItemModel = TimeOfUseItem
    TimeOfUsePayloadModel = TimeOfUsePayload

    def __init__(
        self,
        base_url: str,
        *,
        verify_ssl: bool = True,
        timeout: float = 10.0,
        login_url: Optional[str] = None,
        default_retries: int = 1,
        digest_login_urls: tuple[str, ...] = DEFAULT_DIGEST_LOGIN_URLS,
    ) -> None:
        self.browser = BrowserSession(
            base_url=base_url,
            verify_ssl=verify_ssl,
            timeout=timeout,
        )
        self.login_url = login_url
        self.default_retries = default_retries
        self.digest_login_urls = digest_login_urls

    # ------------------------------- Auth -------------------------------
    def login(self, username: str, password: str) -> None:
        """Authenticate to the inverter web UI using HTTP Digest authentication.

        Tries the configured login_url if provided; otherwise falls back to
        DEFAULT_DIGEST_LOGIN_URLS (e.g., /api/commands/Login).
        """
        urls_to_try = [self.login_url] if self.login_url else list(self.digest_login_urls)
        last_err: Exception | None = None
        for url in [u for u in urls_to_try if u]:
            try:
                auth = HTTPFroniusDigestAuth(username, password)
                self.browser.session.auth = auth
                self.browser.request(
                    "GET",
                    url,
                    params={"user": username},
                    retries=self.default_retries,
                )
                return
            except RequestError as e:
                last_err = e
                continue
        raise AuthError(f"Digest login failed using URLs: {urls_to_try}. Last error: {last_err}")

    # ------------------------- Public API helpers ------------------------
    def get_power_flow(self) -> Dict[str, Any]:
        """Fetch real-time power flow from public API.

        Endpoint: /solar_api/v1/GetPowerFlowRealtimeData.fcgi
        """
        resp = self.browser.request(
            "GET",
            "/solar_api/v1/GetPowerFlowRealtimeData.fcgi",
            retries=self.default_retries,
            expected_status=(200,),
        )
        return resp.json()

    def get_inverter_info(self) -> Dict[str, Any]:
        resp = self.browser.request(
            "GET",
            "/solar_api/v1/GetInverterInfo.cgi",
            retries=self.default_retries,
            expected_status=(200,),
        )
        return resp.json()

    def get_time_of_use(self) -> Dict[str, Any]:
        """Get battery schedule."""
        resp = self.get("/api/config/timeofuse")
        return resp["timeofuse"]

    def get_battery_limit(self):
        response = self.get("api/config/timeofuse")
        return _remove_underscore_fields(response)

    def set_battery_limit(self, payload: TimeOfUsePayload) -> Dict[str, Any]:
        """Set battery limit/schedule with validation (Pydantic v2).
        Payloads are validated against the Pydantic schema before posting.
        """
        items = payload.root
        envelope = {"timeofuse": [i.model_dump() if isinstance(i, TimeOfUseItem) else i for i in items]}
        response = self.post_json("/api/config/timeofuse", envelope)
        return _remove_underscore_fields(response)

    # ------------------------ Protected UI endpoints ---------------------
    def get(self, path: str, *, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        resp = self.browser.request(
            "GET",
            path,
            params=params,
            retries=self.default_retries,
            expected_status=(200,),
        )
        ctype = resp.headers.get("Content-Type", "")
        if "application/json" in ctype:
            return resp.json()
        # Try to parse JSON regardless; if fails, return text
        try:
            return resp.json()
        except Exception:
            return {"text": resp.text}

    def post_json(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        resp = self.browser.request(
            "POST",
            path,
            json=payload,
            headers={"Content-Type": "application/json"},
            retries=self.default_retries,
            expected_status=(200, 204),
        )
        try:
            return resp.json() if resp.content else {"status": resp.status_code}
        except Exception:
            return {"status": resp.status_code, "text": resp.text}

    def set_setting(self, path: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Convenience method for posting settings to a protected endpoint."""
        return self.post_json(path, payload)

    # ---------------------------- Utilities ------------------------------
    def get_raw(self, path: str) -> str:
        """Fetch raw text/HTML from a path (authenticated if session is logged-in)."""
        resp = self.browser.request(
            "GET",
            path,
            retries=self.default_retries,
            expected_status=(200,),
        )
        return resp.text
