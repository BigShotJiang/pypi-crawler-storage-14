import argparse
import json
import logging

from . import FroniusGen24Client, TimeOfUsePayload, TimeOfUseItem, BatteryLimitType, TimeTable, Weekdays

logging.basicConfig(level=logging.INFO)


def main():
    parser = argparse.ArgumentParser(description="Fronius Gen24 CLI")
    parser.add_argument("--host", required=True, help="Base URL or host, e.g., http://192.168.1.100")
    parser.add_argument("--verify-ssl", action="store_true", help="Verify SSL certificates (default off)")
    parser.add_argument("--timeout", type=float, default=10.0, help="Request timeout seconds")
    parser.add_argument("--username", default="customer", help="Username for login")
    parser.add_argument("--password", help="Password for login")
    parser.add_argument("--login-url", help="Custom digest login URL path (e.g., /api/commands/Login)")
    parser.add_argument("--battery-schedule", action="store_true", help="Fetch battery schedule")

    args = parser.parse_args()

    base = args.host
    if not base.startswith("http://") and not base.startswith("https://"):
        base = f"http://{base}"

    client = FroniusGen24Client(
        base_url=base,
        verify_ssl=args.verify_ssl,
        timeout=args.timeout,
        login_url=args.login_url,
    )

    if args.username and args.password:
        client.login(args.username, args.password)

    if args.battery_schedule:
        result = client.get_battery_limit()
        print(json.dumps(result, indent=2))
    else:
        pf = client.get_inverter_info()
        print(json.dumps(pf, indent=2))

    client.set_battery_limit(TimeOfUsePayload.model_validate([
        {
            "Active": True,
            "Power": 1000,
            "ScheduleType": "CHARGE_MIN",
            "TimeTable": {"Start": "00:00", "End":"06:00"},
            "Weekdays": {
                "Mon": True,
                "Tue": True,
                "Wed": True,
                "Thu": True,
                "Fri": True,
                "Sat": True,
                "Sun": True,
            },
        }
    ]))


if __name__ == "__main__":
    main()
