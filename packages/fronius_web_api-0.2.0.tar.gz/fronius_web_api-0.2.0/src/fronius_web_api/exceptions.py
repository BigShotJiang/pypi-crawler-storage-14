class FroniusError(Exception):
    """Base error for the Fronius Gen24 client."""


class RequestError(FroniusError):
    """Raised when an HTTP request fails or returns a bad status code."""
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


class AuthError(FroniusError):
    """Raised when authentication fails."""


class NotFoundError(FroniusError):
    """Raised when a requested endpoint is not found (404)."""
