"""
Manual integration tests for a real Fronius Gen24 inverter.

These tests are intentionally gated so they only run when:
- You explicitly enable them by setting RUN_MANUAL_INTEGRATION_TESTS=1
- You provide a secret password via MANUAL_TESTS_PASSWORD

Required environment variables when running the tests:
- RUN_MANUAL_INTEGRATION_TESTS=1
- MANUAL_TESTS_PASSWORD=<your secret password>
- FRONIUS_BASE_URL=https://inverter.local (or http://<ip>)

Example on PowerShell:
  $pwd = Read-Host -AsSecureString | ConvertFrom-SecureString -AsPlainText
  $env:RUN_MANUAL_INTEGRATION_TESTS = "1"
  $env:MANUAL_TESTS_PASSWORD = $pwd
  $env:FRONIUS_BASE_URL = "http://192.168.1.50"
  pytest -q tests/test_integration_manual.py
"""

from __future__ import annotations

import hashlib
import os
import pytest

from fronius_web_api.client import FroniusGen24Client


# -------------------------- Gating / authorization --------------------------

def _gate_manual_tests() -> None:
    # Must be explicitly enabled
    if os.environ.get("RUN_MANUAL_INTEGRATION_TESTS", "").lower() not in {"1", "true", "yes", "on"}:
        pytest.skip(
            "Manual integration tests are disabled. Set RUN_MANUAL_INTEGRATION_TESTS=1 to run.",
            allow_module_level=True,
        )

    # Require a shared secret password and its hash to be provided via env vars
    pwd = os.environ.get("MANUAL_TESTS_PASSWORD")
    if not pwd:
        pytest.skip(
            "Provide MANUAL_TESTS_PASSWORD to run manual tests.",
            allow_module_level=True,
        )


_gate_manual_tests()


# ---------------------------- Helper utilities -----------------------------

def _get_env(name: str, *, required: bool = True, default: str | None = None) -> str | None:
    val = os.environ.get(name, default)
    if required and not val:
        pytest.skip(f"Environment variable {name} is required for manual integration tests.")
    return val


def _make_client() -> FroniusGen24Client:
    base_url = _get_env("FRONIUS_BASE_URL")
    return FroniusGen24Client(base_url=base_url, verify_ssl=False, timeout=15.0)


# --------------------------------- Tests -----------------------------------

def test_login_and_power_flow():
    """Log in using UI credentials and fetch realtime power flow data."""
    username = "customer"
    password = _get_env("MANUAL_TESTS_PASSWORD")

    client = _make_client()
    client.login(username, password)

    data = client.get_power_flow()
    assert isinstance(data, dict)
    # The exact structure may vary by firmware; basic sanity check
    assert data != {}


def test_public_inverter_info():
    """Fetch inverter info from the public solar_api."""
    client = _make_client()
    data = client.get_inverter_info()
    assert isinstance(data, dict)
    assert data != {}
