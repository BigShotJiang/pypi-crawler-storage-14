import hashlib
from types import SimpleNamespace

import pytest
import requests

from fronius_web_api.auth import HTTPFroniusDigestAuth


class DummyThreadLocal(SimpleNamespace):
    pass


def test_build_digest_header_sha256_no_qop():
    """
    When no qop is provided in the server challenge, the header should be
    deterministic (no nc/cnonce) and use SHA-256 for HA2 and final KD.
    HA1 stays MD5 per implementation.
    """
    auth = HTTPFroniusDigestAuth("customer", "secret")

    # Inject a fake challenge and thread-local storage to avoid making a request
    chal = {
        "realm": "Webinterface area",
        "nonce": "abcdef0123456789",
        # No qop → deterministic header without cnonce/nc
        # Explicitly set algorithm to SHA-256 to cover that code path
        "algorithm": "SHA-256",
    }

    # Prepare thread-local state similar to requests' HTTPDigestAuth
    auth._thread_local = DummyThreadLocal(chal=chal, last_nonce=None, nonce_count=0)

    method = "POST"
    url = "http://inverter.local/api/commands/Login?foo=bar"

    header = auth.build_digest_header(method, url)

    # Build expected digest according to the implementation
    realm = chal["realm"]
    nonce = chal["nonce"]

    # A1 and A2 as per implementation
    A1 = f"{auth.username}:{realm}:{auth.password}"
    A2 = f"{method}:/api/commands/Login?foo=bar"

    HA1 = hashlib.md5(A1.encode("utf-8")).hexdigest()
    HA2 = hashlib.sha256(A2.encode("utf-8")).hexdigest()
    response = hashlib.sha256(f"{HA1}:{nonce}:{HA2}".encode("utf-8")).hexdigest()

    expected = (
        "Digest "
        f"username=\"{auth.username}\", realm=\"{realm}\", nonce=\"{nonce}\", "
        f"uri=\"/api/commands/Login?foo=bar\", response=\"{response}\", algorithm=\"SHA-256\""
    )

    assert header == expected


def test_build_digest_header_sha256_qop_auth(monkeypatch):
    """
    When qop is set to auth, the header should include qop, nc and cnonce.
    Make cnonce deterministic by monkeypatching os.urandom and time.ctime
    inside the fronius_web_api.auth module, then verify the exact Digest header.
    """
    auth = HTTPFroniusDigestAuth("customer", "secret")

    chal = {
        "realm": "Webinterface area",
        "nonce": "abcdef0123456789",
        "qop": "auth",
        "algorithm": "SHA-256",
    }

    # Set up thread-local state like requests' HTTPDigestAuth would
    auth._thread_local = DummyThreadLocal(chal=chal, last_nonce=None, nonce_count=0)

    method = "POST"
    url = "http://inverter.local/api/commands/Login?foo=bar"

    # Make cnonce deterministic by fixing the entropy and time used by the module
    monkeypatch.setattr("fronius_web_api.auth.os.urandom", lambda n: b"\x00" * n, raising=True)
    monkeypatch.setattr("fronius_web_api.auth.time.ctime", lambda: "Sat Oct 18 15:44:00 2025", raising=True)

    header = auth.build_digest_header(method, url)

    realm = chal["realm"]
    nonce = chal["nonce"]

    # Expected values calculated to match implementation
    A1 = f"{auth.username}:{realm}:{auth.password}"
    A2 = f"{method}:/api/commands/Login?foo=bar"

    HA1 = hashlib.md5(A1.encode("utf-8")).hexdigest()
    HA2 = hashlib.sha256(A2.encode("utf-8")).hexdigest()

    # Reproduce the module's cnonce derivation
    ncvalue = "00000001"
    s = b"1" + nonce.encode("utf-8") + b"Sat Oct 18 15:44:00 2025" + (b"\x00" * 8)
    cnonce = hashlib.sha1(s).hexdigest()[:16]

    noncebit = f"{nonce}:{ncvalue}:{cnonce}:auth:{HA2}"
    response = hashlib.sha256(f"{HA1}:{noncebit}".encode("utf-8")).hexdigest()

    expected = (
        "Digest "
        f"username=\"{auth.username}\", realm=\"{realm}\", nonce=\"{nonce}\", "
        f"uri=\"/api/commands/Login?foo=bar\", response=\"{response}\""
        f", algorithm=\"SHA-256\", qop=auth, nc={ncvalue}, cnonce=\"{cnonce}\""
    )

    assert header == expected


def test_handle_401_translates_x_www_authenticate(monkeypatch):
    """
    Verify that handle_401 moves X-WWW-Authenticate to WWW-Authenticate and
    normalizes SHA256 to SHA-256 before delegating to the parent handler.
    """
    auth = HTTPFroniusDigestAuth("user", "pass")

    r = requests.Response()
    r.status_code = 401
    r.headers["X-WWW-Authenticate"] = 'Digest algorithm="SHA256", qop="auth", realm="Webinterface area", nonce="abcdef0123456789"'

    called = {"value": False}

    # Monkeypatch the parent class' handle_401 to a no-op that just returns r
    def fake_parent_handle_401(self, resp, **kwargs):
        called["value"] = True
        # Assert transformation happened before delegation
        assert "WWW-Authenticate" in resp.headers
        return resp

    monkeypatch.setattr(
        "fronius_web_api.auth.HTTPDigestAuth.handle_401", fake_parent_handle_401, raising=True
    )

    out = auth.handle_401(r)

    assert out is r
    assert called["value"] is True
    assert "WWW-Authenticate" in r.headers
    assert r.headers["WWW-Authenticate"].startswith("Digest ")
