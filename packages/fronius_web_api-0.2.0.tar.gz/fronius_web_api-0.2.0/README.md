# Fronius Gen24 Client (Python)

A lightweight Python client for Fronius Gen24 solar inverters that can authenticate like a browser (cookies + CSRF) and access endpoints that are not exposed by the public `solar_api`.

This is intended to be used later in a Home Assistant integration or other automations/scripts.

## Features
- Simple, synchronous Python API built on `requests`.
- Browser-like session with cookies, CSRF token discovery, and configurable headers.
- Public API helpers (e.g., power flow) using `/solar_api/...` endpoints.
- Configurable "hidden" endpoints for settings that require login to the web UI.
- Small CLI for quick testing.

## Disclaimer
The Fronius Gen24 web UI and endpoints may vary by firmware. Some settings are intentionally not documented by the vendor, and may change without notice. Use at your own risk. This project aims to provide a flexible client that you can configure to match your device's behavior.

## Installation
- Local develop install:

```bash
pip install -e .
```

- From source:

```bash
pip install .
```

## Quick start
```python
from fronius_gen24 import FroniusGen24Client

client = FroniusGen24Client(
    base_url="http://192.168.1.100",  # Change to your inverter IP or hostname
    verify_ssl=False,                  # Gen24 may use self-signed certs; set True if trusted
)

# Optional: login if you need access to protected settings
client.login(username="customer", password="your-password")

# Public API example
pf = client.get_power_flow()
print(pf)

# Access a protected (UI) endpoint (example, may vary by firmware)
# You should inspect your device (browser devtools) to find the URL and payload.
# client.set_setting("/rest/energy/settings", {"someSetting": 1})
```

## CLI
A minimal CLI is available for smoke testing:

```bash
python -m fronius_gen24 --host 192.168.1.100 --username user --password pass --power-flow
```

## Notes
- This client now uses HTTP Digest authentication exclusively for web UI login.
- By default it will try the endpoint `/api/commands/Login`. You can override the path by passing `login_url` to the client.

## Notes for Home Assistant
- The current client is synchronous. For optimal HA integration, wrap calls with `async_add_executor_job` or create an async wrapper later.
- Expose timeouts and exception handling to avoid blocking the event loop.

## License
MIT
