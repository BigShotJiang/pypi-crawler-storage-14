"""High-level streaming transcription API."""

from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from google.api_core import exceptions as core_exceptions
from google.auth.exceptions import DefaultCredentialsError
from google.cloud import speech_v1p1beta1 as speech

from .config import TranscriptionConfig
from .events import TranscriptionEvent
from .encoder import decode_audio_to_pcm16_stream, stream_pcm_chunks

logger = logging.getLogger(__name__)


@asynccontextmanager
async def _speech_client(credentials_path: Optional[str]) -> AsyncIterator[speech.SpeechAsyncClient]:
    """Context manager that yields a configured SpeechAsyncClient."""

    previous_credentials = None
    if credentials_path:
        logger.debug("Setting GOOGLE_APPLICATION_CREDENTIALS to %s", credentials_path)
        previous_credentials = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = credentials_path
    else:
        logger.debug(
            "Using default Google credentials (GOOGLE_APPLICATION_CREDENTIALS=%s)",
            os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"),
        )

    try:
        logger.debug("Creating SpeechAsyncClient...")
        client = speech.SpeechAsyncClient()
        logger.debug("SpeechAsyncClient created successfully")
    except (DefaultCredentialsError, core_exceptions.GoogleAPICallError) as err:
        raise RuntimeError(f"Failed to create Speech client: {err}") from err

    try:
        yield client
    finally:
        logger.debug("Closing SpeechAsyncClient transport...")
        await client.transport.close()
        if credentials_path is not None:
            if previous_credentials is None:
                os.environ.pop("GOOGLE_APPLICATION_CREDENTIALS", None)
            else:
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = previous_credentials
        logger.debug("Speech client context cleaned up")


class StreamingTranscriber:
    """Stream audio data to Google Speech-to-Text and yield transcripts."""

    def __init__(self, *, credentials_path: Optional[str] = None, logger_: Optional[logging.Logger] = None) -> None:
        self._credentials_path = credentials_path
        self._logger = logger_ or logging.getLogger(self.__class__.__name__)

    async def stream(
        self,
        audio_chunks: AsyncIterator[bytes],
        config: TranscriptionConfig,
    ) -> AsyncIterator[TranscriptionEvent]:
        """Stream audio chunks to Google Speech and yield ``TranscriptionEvent`` objects.

        Args:
            audio_chunks: Async iterator of PCM audio chunks (16-bit little-endian mono samples).
            config: Transcription configuration.

        Yields:
            TranscriptionEvent objects as they are received.
        """
        self._logger.debug("Validating TranscriptionConfig: %s", config)
        config.validate()

        lang_display = config.language_code if config.language_code else "auto"
        self._logger.info(
            "Starting streaming transcription (lang=%s, sample_rate=%d Hz, "
            "chunk_size=%d, chunk_delay=%.3f, interim=%s, single_utterance=%s, "
            "auto_punct=%s)...",
            lang_display,
            config.sample_rate_hz,
            config.chunk_size,
            config.chunk_delay,
            config.enable_interim_results,
            config.single_utterance,
            config.enable_automatic_punctuation,
        )

        event_count = 0
        final_count = 0
        interim_count = 0

        async with _speech_client(self._credentials_path) as client:
            self._logger.debug("Speech client ready, creating request generator...")
            request_iter = self._request_generator(audio_chunks=audio_chunks, config=config)

            try:
                responses = await client.streaming_recognize(requests=request_iter)
                self._logger.debug("StreamingRecognize call established")
            except core_exceptions.GoogleAPICallError as err:
                self._logger.error("Streaming recognition failed during setup: %s", err)
                raise RuntimeError(f"Streaming recognition failed: {err}") from err

            async for response in responses:
                self._logger.debug("Received response with %d result(s)", len(response.results))
                for result in response.results:
                    event = self._result_to_event(result)
                    if event is None:
                        self._logger.debug("Result had no usable transcript, skipping")
                        continue
                    if not config.enable_interim_results and event.type == "interim":
                        self._logger.debug("Interim result suppressed by config")
                        continue

                    event_count += 1
                    if event.type == "final":
                        final_count += 1
                    else:
                        interim_count += 1

                    self._logger.debug(
                        "[%s] %s",
                        event.type.upper(),
                        event.transcript.replace("\n", " "),
                    )
                    yield event

        self._logger.info(
            "Streaming transcription finished: total_events=%d, final=%d, interim=%d",
            event_count,
            final_count,
            interim_count,
        )

    async def stream_from_audio(
        self,
        audio_stream: AsyncIterator[bytes],
        config: TranscriptionConfig,
    ) -> AsyncIterator[TranscriptionEvent]:
        """从任意格式的音频流转录文本。

        自动检测音频格式并解码为 PCM16，无需手动调用 decode_audio_to_pcm16_stream。

        Args:
            audio_stream: 任意格式的音频数据流（webm、wav 等）
            config: 转录配置

        Yields:
            TranscriptionEvent 对象

        Example:
            ```python
            async def websocket_audio_stream():
                async for chunk_bytes in receive_audio_chunks():
                    yield chunk_bytes

            transcriber = StreamingTranscriber(credentials_path="google.json")
            async for event in transcriber.stream_from_audio(websocket_audio_stream(), config):
                if event.type == "final":
                    print("[FINAL]", event.transcript)
            ```
        """
        self._logger.info(
            "Starting stream_from_audio with automatic decoding to PCM16 "
            "(sample_rate=%d Hz)...",
            config.sample_rate_hz,
        )
        pcm_stream = decode_audio_to_pcm16_stream(
            audio_stream=audio_stream,
            sample_rate_hz=config.sample_rate_hz,
        )
        async for event in self.stream(pcm_stream, config):
            yield event
        self._logger.info("stream_from_audio finished")

    async def _request_generator(
        self,
        *,
        audio_chunks: AsyncIterator[bytes],
        config: TranscriptionConfig,
    ) -> AsyncIterator[speech.StreamingRecognizeRequest]:
        """Yield StreamingRecognizeRequest objects for the speech client."""

        self._logger.debug(
            "Building recognition configuration (language_code=%s, sample_rate=%d, "
            "chunk_size=%d, chunk_delay=%.3f, auto_punct=%s, single_utterance=%s)",
            config.language_code or "auto",
            config.sample_rate_hz,
            config.chunk_size,
            config.chunk_delay,
            config.enable_automatic_punctuation,
            config.single_utterance,
        )

        # 当 language_code 为 None 时，使用自动语言检测
        # Google Speech API 通过设置多个 alternative_language_codes 来实现自动检测
        if config.language_code is None:
            # 使用常见的多语言列表进行自动检测
            alternative_languages = [
                "zh-CN",  # 中文（简体）
                "zh-TW",  # 中文（繁体）
                "en-US",  # 英语（美国）
                "en-GB",  # 英语（英国）
                "ja-JP",  # 日语
                "ko-KR",  # 韩语
                "es-ES",  # 西班牙语
                "fr-FR",  # 法语
                "de-DE",  # 德语
                "ru-RU",  # 俄语
            ]
            # 使用第一个作为主要语言，其余作为备选
            recognition_config = speech.RecognitionConfig(
                encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=config.sample_rate_hz,
                language_code=alternative_languages[0],
                alternative_language_codes=alternative_languages[1:],
                enable_automatic_punctuation=config.enable_automatic_punctuation,
            )
        else:
            recognition_config = speech.RecognitionConfig(
                encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
                sample_rate_hertz=config.sample_rate_hz,
                language_code=config.language_code,
                enable_automatic_punctuation=config.enable_automatic_punctuation,
            )
            self._logger.debug("Using explicit language_code=%s", config.language_code)
        streaming_config = speech.StreamingRecognitionConfig(
            config=recognition_config,
            interim_results=True,
            single_utterance=config.single_utterance,
        )

        yield speech.StreamingRecognizeRequest(streaming_config=streaming_config)

        self._logger.debug(
            "Emitting initial StreamingRecognizeRequest with streaming_config"
        )

        # Re-chunk the audio stream to the specified chunk size
        total_bytes = 0
        chunk_count = 0
        async for chunk in stream_pcm_chunks(
            chunks=audio_chunks,
            chunk_size=config.chunk_size,
            chunk_delay=config.chunk_delay,
        ):
            chunk_len = len(chunk)
            total_bytes += chunk_len
            chunk_count += 1
            if chunk_count <= 5 or chunk_count % 50 == 0:
                self._logger.debug(
                    "Sending audio chunk #%d (size=%d bytes, total_sent=%d bytes)",
                    chunk_count,
                    chunk_len,
                    total_bytes,
                )
            yield speech.StreamingRecognizeRequest(audio_content=chunk)

        self._logger.debug(
            "Finished request generator: chunks=%d, total_audio_bytes=%d",
            chunk_count,
            total_bytes,
        )

    def _result_to_event(
        self,
        result: speech.StreamingRecognitionResult,
    ) -> Optional[TranscriptionEvent]:
        """Convert a ``StreamingRecognitionResult`` into a ``TranscriptionEvent``."""

        if not result.alternatives:
            return None

        transcript = result.alternatives[0].transcript.strip()
        if not transcript:
            return None

        event_type = "final" if result.is_final else "interim"
        confidence = result.alternatives[0].confidence if result.is_final else None
        stability = None if result.is_final else result.stability or None

        return TranscriptionEvent(
            type=event_type,
            transcript=transcript,
            is_final=result.is_final,
            confidence=confidence,
            stability=stability,
            result_index=getattr(result, "result_index", None),
        )

