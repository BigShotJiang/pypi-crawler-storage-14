#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8

"""
Modules, classes, and variables declared in _internal are not intended for general public use.
"""

from meerschaum._internal.static import STATIC_CONFIG
