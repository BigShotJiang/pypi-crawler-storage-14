# Structurizr GCP Theme CLI
A very stupid CLI tool to create a Structurizr theme starting from svg or png icons.

## Next Step
[] Refactor of the code
[] Documentation
[] Repository structure
[] Load configuration from toml file 
[] Create a way to pass some metadata as json
[] Create a command to upload to a remote bucket on GCP 
[] Create a cloud function version of the cli
