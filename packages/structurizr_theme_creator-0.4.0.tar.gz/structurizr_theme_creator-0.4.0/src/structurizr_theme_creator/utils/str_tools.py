import re


def clean_string(s: str, is_folder: bool = False) -> str:
    s = re.sub(r"([a-z])([A-Z])", r"\1_\2", s)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", s)
    words = re.findall(r"[a-zA-Z]+", s)
    if is_folder:
        return "_".join(words).lower()
    else:
        return "_".join(words[:-1]).lower()


def remove_unwanted_from_name(item_name: str, unwanted_parts: list[str]) -> str:
    for part in unwanted_parts:
        item_name = item_name.replace(part, "")

    item_name = "_".join([word for word in item_name.split("_") if word != ""])

    return item_name
