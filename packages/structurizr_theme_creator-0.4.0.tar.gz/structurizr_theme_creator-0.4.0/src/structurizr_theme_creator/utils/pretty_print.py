class Styles:
    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


def print_ok(message: str, **kwargs) -> None:
    """Print an ok message

    Args:
        message (str): message to print
    """
    print(f"{Styles.OKGREEN}{message}{Styles.ENDC}", **kwargs)


def print_warning(message: str, **kwargs) -> None:
    """Print a warning message

    Args:
        message (str): message to print
    """
    print(f"{Styles.WARNING}{message}{Styles.ENDC}", **kwargs)


def print_fail(message: str, **kwargs) -> None:
    """Print an error message

    Args:
        message (str): message to print
    """
    print(f"{Styles.FAIL}{message}{Styles.ENDC}", **kwargs)


def print_done(message: str, **kwargs) -> None:
    """Print a done message
    Args:
        message (str): message to print
    """
    print(f"{Styles.OKCYAN}{message} 🐦‍⬛{Styles.ENDC}", **kwargs)
