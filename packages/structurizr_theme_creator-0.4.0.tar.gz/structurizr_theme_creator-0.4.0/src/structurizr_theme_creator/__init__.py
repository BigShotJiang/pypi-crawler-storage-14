import click

import structurizr_theme_creator.commands as commands


@click.group()
def main():
    """Entrypoint for the CLI."""


main.add_command(commands.clean)
main.add_command(commands.create)

if __name__ == "__main__":
    main()
