import os
import pathlib

import click

from structurizr_theme_creator.utils.core import (
    Element,
    Theme,
    ThemeElement,
    go_through_fs_tree,
)
from structurizr_theme_creator.utils.pretty_print import print_done, print_warning
from structurizr_theme_creator.utils.str_tools import clean_string


@click.command()
@click.argument("path", type=click.Path(exists=True))
@click.option("--ignore", type=str, required=False, default=None)
def clean(path, ignore):
    ignore_list = (
        ignore.replace("'", "").replace('"', "").split(",") if ignore else None
    )
    print("Ignore list is ", ignore_list)
    full_path = pathlib.Path(path)
    output_path = full_path.parent / "output"
    first_level = [item for item in os.listdir(full_path) if not item.startswith(".")]
    first_level_dict = {item: clean_string(item, True) for item in first_level}
    for item in first_level_dict.values():
        if item.startswith("."):
            print_warning(f"Skipping hidden directory: {item}")
        else:
            if item is not None:
                os.makedirs(os.path.join(output_path, item), exist_ok=True)
    elements = go_through_fs_tree(
        full_path=full_path,
        output_path=output_path,
    )
    for element in elements:
        file_name = (
            Element.clean_string(element.name_without_extension, ignore=ignore_list)
            + element.path.suffix
        )

        element.copy(
            output_path=output_path
            / Element.clean_string(
                element.first_level_directory_inside_root,
                is_folder=True,
                ignore=ignore_list,
            )
            / file_name
        )
    print_done("Cleaning done!")


@click.command()
@click.argument("path", type=click.Path(exists=True))
@click.option("--name", type=str, required=True)
@click.option("--description", type=str, required=False, default=None)
@click.option("--color", type=str, required=False, default=None)
def create(path, name, description, color):
    full_path = pathlib.Path(path).resolve()
    output_path = full_path.parent / "-".join(name.lower().split(" "))

    name = name.replace("'", "").replace('"', "") if name else None
    description = description.replace("'", "").replace('"', "") if description else None
    os.makedirs(os.path.join(output_path), exist_ok=True)
    theme = Theme(
        name=name,
        description="description here" if description is None else description,
    )

    elements = go_through_fs_tree(
        full_path=full_path,
        output_path=pathlib.Path(output_path),
    )

    for element in elements:
        if element.has_extension("svg"):
            element.copy(
                output_path=output_path / element.get_theme_name(),
            )

            theme_element = ThemeElement(
                tag=element.get_theme_tag(),
                stroke=color if color is not None else "#232f3d",
                color=color if color is not None else "#232f3d",
                icon=element.get_theme_name(),
            )
            theme.add_element(theme_element)
    theme.create(pathlib.Path(output_path) / "theme.json")
    print_done("Theme created!")
