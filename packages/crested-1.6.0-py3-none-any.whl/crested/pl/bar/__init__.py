"""Initialize the bar module."""

from ._normalization_weights import normalization_weights
from ._region import prediction, region, region_predictions
