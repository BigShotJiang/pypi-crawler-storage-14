"""Initialize the locus module."""

from ._locus_scoring import locus_scoring
from ._track import track
