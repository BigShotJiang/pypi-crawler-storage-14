"""Initialize the hist module."""

from crested.pl.locus._locus_scoring import locus_scoring

from ._distribution import distribution
