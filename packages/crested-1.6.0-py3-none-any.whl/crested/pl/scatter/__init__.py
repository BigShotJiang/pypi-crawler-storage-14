"""Init file for scatter module."""

from ._class_density import class_density
