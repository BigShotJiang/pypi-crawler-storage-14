"""Persistent configuration for the crested package."""

genome = None  # persistent genome object
