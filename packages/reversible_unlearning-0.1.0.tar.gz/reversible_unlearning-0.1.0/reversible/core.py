﻿import torch, torch.nn as nn
from typing import Optional, Dict

class Reversible(nn.Module):
    K_CHARGE = 0.56
    K_DISCHARGE = 0.337
    K_RECHARGE = 0.57
    HOLONOMY_RANK = 32
    HOLONOMY_ALPHA = 0.03
    
    def __init__(self, model, optimizer=None, device='cuda', use_holonomy=True):
        super().__init__()
        self.model = model
        self.device = device
        self.use_holonomy = use_holonomy
        self.optimizer = optimizer or torch.optim.AdamW(model.parameters(), lr=1e-4)
        self.criterion = nn.CrossEntropyLoss()
        self.k_current = self.K_CHARGE
        self.phase = 'IDLE'
        self.metrics = {'before': {}, 'after': {}, 'recovery_ratio': 0.0, 'loop_area': 0.0}
        if use_holonomy:
            self._init_holonomy()
        self.curvature_registry = {}
        print(f'✓ Reversible initialized\n  k_charge={self.K_CHARGE}\n  k_discharge={self.K_DISCHARGE}\n  k_recharge={self.K_RECHARGE}')
    
    def _init_holonomy(self):
        for name, module in self.model.named_modules():
            if 'layer3' in name and 'conv' in name:
                self.rotation = nn.Parameter(torch.eye(module.out_channels, device=self.device), requires_grad=False)
                break
    
    def charge(self, dataloader, num_epochs=1, verbose=True):
        print('\n🔋 CHARGE PHASE')
        self.phase = 'CHARGE'
        self.k_current = self.K_CHARGE
        self.model.train()
        total_loss = total_correct = total_samples = 0
        for epoch in range(num_epochs):
            for inputs, labels in dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = self.criterion(outputs.logits if hasattr(outputs, 'logits') else outputs, labels)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                total_loss += loss.item()
                pred = (outputs.logits if hasattr(outputs, 'logits') else outputs).argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        acc = 100 * total_correct / total_samples
        if verbose: print(f'  Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%')
        self.metrics['before']['acc'] = acc
        return acc
    
    def discharge(self, dataloader, num_epochs=1, verbose=True):
        print(f'\n⚡ DISCHARGE PHASE (k={self.K_DISCHARGE})')
        self.phase = 'DISCHARGE'
        self.k_current = self.K_DISCHARGE
        self.model.train()
        total_loss = total_correct = total_samples = 0
        for epoch in range(num_epochs):
            for inputs, labels in dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = self.criterion(outputs.logits if hasattr(outputs, 'logits') else outputs, labels)
                loss.backward()
                with torch.no_grad():
                    for name, param in self.model.named_parameters():
                        if param.grad is not None:
                            curvature = torch.abs(param.grad).mean()
                            param.grad *= -self.k_current * (1 + 0.1 * curvature)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                total_loss += loss.item()
                pred = (outputs.logits if hasattr(outputs, 'logits') else outputs).argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        acc = 100 * total_correct / total_samples
        if verbose: print(f'  Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%\n  ✓ Unlearning complete')
        self.metrics['after']['acc'] = acc
        return acc
    
    def recharge(self, dataloader, num_epochs=1, verbose=True):
        print(f'\n🔌 RECHARGE PHASE (k={self.K_RECHARGE})')
        self.phase = 'RECHARGE'
        self.k_current = self.K_RECHARGE
        self.model.train()
        total_loss = total_correct = total_samples = 0
        for epoch in range(num_epochs):
            for inputs, labels in dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = self.criterion(outputs.logits if hasattr(outputs, 'logits') else outputs, labels)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                self.optimizer.step()
                total_loss += loss.item()
                pred = (outputs.logits if hasattr(outputs, 'logits') else outputs).argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        acc = 100 * total_correct / total_samples
        if verbose: print(f'  Loss: {total_loss/len(dataloader):.4f}, Acc: {acc:.2f}%\n  ✓ Recharging complete')
        return acc
    
    def verify(self, test_dataloader, verbose=True):
        print('\n✅ VERIFICATION PHASE')
        self.model.eval()
        total_correct = total_samples = 0
        with torch.no_grad():
            for inputs, labels in test_dataloader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                outputs = self.model(inputs)
                pred = (outputs.logits if hasattr(outputs, 'logits') else outputs).argmax(1)
                total_correct += (pred == labels).sum().item()
                total_samples += labels.size(0)
        test_acc = 100 * total_correct / total_samples
        before_acc = self.metrics['before'].get('acc', 0)
        after_acc = self.metrics['after'].get('acc', 0)
        recovery_ratio = 1 - (after_acc / before_acc) if before_acc > 0 else 0
        loop_area = max(before_acc - after_acc, 0) / 100.0
        if verbose: print(f'  Before: {before_acc:.2f}%, After: {after_acc:.2f}%, Recovery: {test_acc:.2f}%\n  Ratio: {recovery_ratio:.3f}')
        self.metrics['recovery_ratio'] = recovery_ratio
        self.metrics['loop_area'] = loop_area
        return {'before_acc': before_acc, 'after_acc': after_acc, 'recovery_ratio': recovery_ratio, 'test_acc': test_acc, 'loop_area': loop_area, 'k_optimal': {'charge': self.K_CHARGE, 'discharge': self.K_DISCHARGE, 'recharge': self.K_RECHARGE}}
