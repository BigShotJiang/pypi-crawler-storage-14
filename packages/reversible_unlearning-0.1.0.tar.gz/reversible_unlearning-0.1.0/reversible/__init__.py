﻿from .core import Reversible
__version__ = '0.1.0'
__all__ = ['Reversible']
