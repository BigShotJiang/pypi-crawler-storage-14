"""
urlink.exceptions - Custom exceptions for the urlink package
"""


class UrlinkError(Exception):
    """Base exception for all urlink errors."""
    pass


class UrlinkAPIError(UrlinkError):
    """
    Raised when the API returns an error response.
    
    Attributes:
        status_code: HTTP status code from the response
        response: The full error response dict
    """
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response or {}


class UrlinkConnectionError(UrlinkError):
    """Raised when unable to connect to the API."""
    pass


class UrlinkValidationError(UrlinkError):
    """Raised when input validation fails."""
    pass


class UrlinkCodeExistsError(UrlinkAPIError):
    """Raised when the requested custom code already exists."""
    def __init__(self, code: str, domain: str = None):
        self.code = code
        self.domain = domain
        domain_info = f" on domain {domain}" if domain else ""
        super().__init__(
            message=f"Short code '{code}' already exists{domain_info}",
            status_code=409
        )


class UrlinkRateLimitError(UrlinkAPIError):
    """Raised when rate limit is exceeded."""
    def __init__(self, retry_after: int = None):
        self.retry_after = retry_after
        message = "Rate limit exceeded"
        if retry_after:
            message += f". Retry after {retry_after} seconds"
        super().__init__(message=message, status_code=429)
