"""
urlink - Python SDK for URL Shortener API
A simple and intuitive Python package to shorten URLs programmatically.

Usage:
    import urlink
    
    urlink.configure(api_key="YOUR-API-KEY")
    urlink.input = "https://example.com/very/long/url"
    urlink.domain = "urlink.co"  # optional
    urlink.ending = "my-custom"  # optional
    
    print(urlink.output)  # Returns shortened URL
"""

from .client import UrlinkClient

__version__ = "1.0.0"
__author__ = "Urlink Team"

# Global client instance for simple API
_client = UrlinkClient()

# Properties for simple global API
_input_url = None
_domain = None
_ending = None
_api_key = None


def configure(api_key: str = None, base_url: str = None):
    """
    Configure the urlink client with API key and optional custom base URL.
    
    Args:
        api_key: Your API key for requests (required for remote API calls)
        base_url: Custom API base URL (defaults to https://urlink.co)
    """
    global _client
    _client = UrlinkClient(api_key=api_key, base_url=base_url)


@property
def input():
    """Get the input URL."""
    return _input_url


@input.setter
def input(value: str):
    """Set the URL to shorten."""
    global _input_url
    _input_url = value


@property
def domain():
    """Get the custom domain."""
    return _domain


@domain.setter  
def domain(value: str):
    """Set custom domain (optional)."""
    global _domain
    _domain = value


@property
def ending():
    """Get the custom ending/slug."""
    return _ending


@ending.setter
def ending(value: str):
    """Set custom ending/slug (optional)."""
    global _ending
    _ending = value


@property
def output():
    """Get the shortened URL."""
    if not _input_url:
        raise ValueError("No input URL set. Set urlink.input first.")
    
    result = _client.shorten(
        url=_input_url,
        domain=_domain,
        code=_ending
    )
    return result.get('short', '')


# Module-level attribute access for simple API
class _UrlinkModule:
    """Module wrapper to enable property-like access on the module."""
    
    def __init__(self):
        self._input = None
        self._domain = None
        self._ending = None
        self._api_key = None
        self._base_url = UrlinkClient.DEFAULT_BASE_URL
        self._client = UrlinkClient()
    
    def _rebuild_client(self):
        self._client = UrlinkClient(api_key=self._api_key, base_url=self._base_url)
    
    @property
    def input(self):
        return self._input
    
    @input.setter
    def input(self, value: str):
        self._input = value
    
    @property
    def domain(self):
        return self._domain
    
    @domain.setter
    def domain(self, value: str):
        self._domain = value
    
    @property
    def ending(self):
        return self._ending
    
    @ending.setter
    def ending(self, value: str):
        self._ending = value
    
    @property
    def api_key(self):
        return self._api_key
    
    @api_key.setter
    def api_key(self, value: str):
        self._api_key = value.strip() if isinstance(value, str) else None
        self._rebuild_client()
    
    @property
    def base_url(self):
        return self._base_url
    
    @base_url.setter
    def base_url(self, value: str):
        if value:
            self._base_url = value.strip()
        else:
            self._base_url = UrlinkClient.DEFAULT_BASE_URL
        self._rebuild_client()
    
    @property
    def output(self):
        if not self._input:
            raise ValueError("No input URL set. Set urlink.input first.")
        
        result = self._client.shorten(
            url=self._input,
            domain=self._domain,
            code=self._ending
        )
        return result.get('short', '')
    
    def configure(self, api_key: str = None, base_url: str = None):
        """Configure the client."""
        if api_key is not None:
            self.api_key = api_key
        if base_url is not None:
            self.base_url = base_url
        if api_key is None and base_url is None:
            self._rebuild_client()
    
    def shorten(self, url: str, domain: str = None, ending: str = None) -> str:
        """
        Shortcut method to shorten a URL in one call.
        
        Args:
            url: The URL to shorten
            domain: Custom domain (optional)
            ending: Custom slug/ending (optional)
        
        Returns:
            The shortened URL string
        """
        result = self._client.shorten(url=url, domain=domain, code=ending)
        return result.get('short', '')
    
    def check(self, code: str, domain: str = None) -> bool:
        """
        Check if a custom code is available.
        
        Args:
            code: The custom code to check
            domain: The domain to check on (optional)
        
        Returns:
            True if available, False otherwise
        """
        return self._client.check_availability(code=code, domain=domain)
    
    def reset(self):
        """Reset all settings to defaults."""
        self._input = None
        self._domain = None
        self._ending = None


import sys
sys.modules[__name__] = _UrlinkModule()
