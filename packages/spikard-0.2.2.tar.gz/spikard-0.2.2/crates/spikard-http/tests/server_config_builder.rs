//! Tests for ServerConfig builder with dependency injection

#[cfg(feature = "di")]
mod di_builder_tests {
    use spikard_core::di::ValueDependency;
    use spikard_http::ServerConfig;
    use std::sync::Arc;

    #[test]
    fn test_builder_basic() {
        let config = ServerConfig::builder().port(3000).host("0.0.0.0").build();

        assert_eq!(config.port, 3000);
        assert_eq!(config.host, "0.0.0.0");
    }

    #[test]
    fn test_provide_value() {
        let config = ServerConfig::builder()
            .provide_value("test", "value".to_string())
            .build();

        assert!(config.di_container.is_some());
        let container = config.di_container.unwrap();

        // Verify the dependency exists (we can't easily resolve it here without a request)
        // but we can check the container exists
        assert!(Arc::strong_count(&container) >= 1);
    }

    #[test]
    fn test_provide_multiple_values() {
        let config = ServerConfig::builder()
            .provide_value("val1", 1)
            .provide_value("val2", 2)
            .provide_value("val3", "three".to_string())
            .build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_provide_factory() {
        let config = ServerConfig::builder()
            .provide_factory("counter", |_resolved| async { Ok(42) })
            .build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_provide_value_and_factory() {
        let config = ServerConfig::builder()
            .provide_value("base_value", 10)
            .provide_factory("computed", |_resolved| async { Ok(100) })
            .build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_provide_custom_dependency() {
        let dep = ValueDependency::new("custom", "value".to_string());

        let config = ServerConfig::builder().provide(Arc::new(dep)).build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_builder_chaining() {
        let config = ServerConfig::builder()
            .port(8080)
            .host("localhost")
            .enable_request_id(false)
            .provide_value("app_name", "TestApp".to_string())
            .provide_value("version", "1.0.0".to_string())
            .build();

        assert_eq!(config.port, 8080);
        assert_eq!(config.host, "localhost");
        assert!(!config.enable_request_id);
        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_builder_with_all_options() {
        use spikard_http::{BackgroundTaskConfig, CompressionConfig, RateLimitConfig};

        let config = ServerConfig::builder()
            .port(9000)
            .host("127.0.0.1")
            .workers(4)
            .enable_request_id(true)
            .max_body_size(Some(5 * 1024 * 1024))
            .request_timeout(Some(60))
            .compression(Some(CompressionConfig::default()))
            .rate_limit(Some(RateLimitConfig::default()))
            .graceful_shutdown(true)
            .shutdown_timeout(30)
            .background_tasks(BackgroundTaskConfig::default())
            .provide_value("config_value", "test".to_string())
            .build();

        assert_eq!(config.port, 9000);
        assert_eq!(config.host, "127.0.0.1");
        assert_eq!(config.workers, 4);
        assert!(config.enable_request_id);
        assert_eq!(config.max_body_size, Some(5 * 1024 * 1024));
        assert_eq!(config.request_timeout, Some(60));
        assert!(config.compression.is_some());
        assert!(config.rate_limit.is_some());
        assert!(config.graceful_shutdown);
        assert_eq!(config.shutdown_timeout, 30);
        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_factory_with_dependencies() {
        let config = ServerConfig::builder()
            .provide_value("multiplier", 2)
            .provide_factory("result", |resolved| {
                // Eagerly get the value to avoid lifetime issues
                let multiplier = resolved.get::<i32>("multiplier").map(|v| *v);
                async move {
                    let mult = multiplier.ok_or("multiplier not found")?;
                    Ok(mult * 21)
                }
            })
            .build();

        assert!(config.di_container.is_some());

        // We can't easily test resolution here without creating a full request context,
        // but we verified the factory can be registered
    }

    #[test]
    fn test_builder_without_di() {
        // Test that builder works fine without any DI configuration
        let config = ServerConfig::builder().port(3000).host("localhost").build();

        assert_eq!(config.port, 3000);
        assert_eq!(config.host, "localhost");
        assert!(config.di_container.is_none());
    }

    #[test]
    fn test_multiple_factories() {
        let config = ServerConfig::builder()
            .provide_factory("factory1", |_resolved| async { Ok(1) })
            .provide_factory("factory2", |_resolved| async { Ok(2) })
            .provide_factory("factory3", |_resolved| async { Ok(3) })
            .build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_mixed_dependencies() {
        let config = ServerConfig::builder()
            .provide_value("static1", "value1".to_string())
            .provide_factory("dynamic1", |_resolved| async { Ok("computed1".to_string()) })
            .provide_value("static2", 42)
            .provide_factory("dynamic2", |_resolved| async { Ok(100) })
            .build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_type_inference() {
        // Test that the builder can infer types correctly
        let config = ServerConfig::builder()
            .provide_value("string", "test")
            .provide_value("number", 42)
            .provide_value("bool", true)
            .provide_value("vec", vec![1, 2, 3])
            .build();

        assert!(config.di_container.is_some());
    }

    #[test]
    fn test_builder_default() {
        let builder = ServerConfig::builder();
        let config = builder.build();

        // Should have default values
        assert_eq!(config.port, 8000);
        assert_eq!(config.host, "127.0.0.1");
        assert_eq!(config.workers, 1);
        assert!(config.enable_request_id);
        assert_eq!(config.max_body_size, Some(10 * 1024 * 1024));
        assert_eq!(config.request_timeout, Some(30));
        assert!(config.graceful_shutdown);
        assert_eq!(config.shutdown_timeout, 30);
    }

    #[test]
    fn test_builder_override_defaults() {
        let config = ServerConfig::builder()
            .port(9999)
            .enable_request_id(false)
            .max_body_size(None)
            .build();

        assert_eq!(config.port, 9999);
        assert!(!config.enable_request_id);
        assert_eq!(config.max_body_size, None);
    }

    #[test]
    fn test_provide_with_arc() {
        // Test providing Arc<T> values
        let shared_value = Arc::new("shared".to_string());

        let config = ServerConfig::builder()
            .provide_value("shared", shared_value.clone())
            .build();

        assert!(config.di_container.is_some());
        // Original Arc is still valid
        assert_eq!(*shared_value, "shared");
    }
}

#[cfg(not(feature = "di"))]
mod no_di_tests {
    use spikard_http::ServerConfig;

    #[test]
    fn test_builder_without_di_feature() {
        // Test that builder works without DI feature enabled
        let config = ServerConfig::builder().port(3000).host("localhost").build();

        assert_eq!(config.port, 3000);
        assert_eq!(config.host, "localhost");
    }
}
