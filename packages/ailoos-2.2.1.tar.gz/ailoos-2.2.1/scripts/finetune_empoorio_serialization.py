#!/usr/bin/env python3
"""
Fine-tuning de EmpoorioLM para comprensión de formatos TOON/VSC.
Entrena el modelo para entender y trabajar con datos serializados.
"""

import os
import json
import torch
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import sys

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    from transformers import (
        AutoTokenizer, AutoModelForCausalLM,
        TrainingArguments, Trainer,
        DataCollatorForLanguageModeling
    )
    from datasets import Dataset
    from ailoos.core.serializers import (
        SerializationFormat, get_serializer, SerializationResult
    )
    from ailoos.core.logging import get_logger

    logger = get_logger(__name__)
    TRANSFORMERS_AVAILABLE = True
except ImportError as e:
    logger = None
    TRANSFORMERS_AVAILABLE = False
    print(f"Advertencia: transformers no disponible: {e}")


@dataclass
class FineTuneConfig:
    """Configuración para fine-tuning."""
    model_path: str = "./models/empoorio_lm/v1.0.0"
    output_dir: str = "./models/empoorio_lm/finetuned_serialization"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 4
    gradient_accumulation_steps: int = 8
    learning_rate: float = 2e-5
    max_seq_length: int = 512
    save_steps: int = 500
    logging_steps: int = 100
    num_examples: int = 1000


class SerializationFineTuner:
    """
    Fine-tuner para que EmpoorioLM comprenda formatos TOON/VSC.
    """

    def __init__(self, config: FineTuneConfig = None):
        if not TRANSFORMERS_AVAILABLE:
            raise RuntimeError("transformers library required for fine-tuning")

        self.config = config or FineTuneConfig()
        self.tokenizer = None
        self.model = None
        self.training_data = []

    def load_model(self):
        """Cargar modelo y tokenizer."""
        logger.info(f"Loading model from {self.config.model_path}")

        self.tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_path,
            trust_remote_code=True
        )

        self.model = AutoModelForCausalLM.from_pretrained(
            self.config.model_path,
            trust_remote_code=True,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
        )

        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token

        logger.info("Model loaded successfully")

    def generate_training_examples(self) -> List[Dict[str, str]]:
        """
        Generar ejemplos de entrenamiento para comprensión de TOON/VSC.

        Returns:
            Lista de ejemplos de entrenamiento
        """
        examples = []

        # Tipos de datos para ejemplos
        data_types = [
            # Arrays uniformes (ideal para TOON)
            {"type": "uniform_array", "data": [1, 2, 3, 4, 5] * 20},
            {"type": "string_array", "data": [f"item_{i}" for i in range(50)]},
            {"type": "float_array", "data": [i * 0.1 for i in range(100)]},

            # Datos estructurados repetitivos (TOON)
            {"type": "objects_array", "data": [
                {"id": i, "name": f"obj_{i}", "value": i * 10}
                for i in range(30)
            ]},

            # Datos columnar densos (VSC)
            {"type": "columnar_data", "data": {
                "timestamps": list(range(200)),
                "values": [i * 0.01 for i in range(200)],
                "categories": [f"cat_{i%5}" for i in range(200)],
                "flags": [i % 2 == 0 for i in range(200)]
            }},

            # Datos científicos (VSC)
            {"type": "scientific_data", "data": {
                "x_coords": [i * 0.1 for i in range(150)],
                "y_coords": [i * 0.2 for i in range(150)],
                "measurements": [i + (i*0.1)**2 for i in range(150)],
                "errors": [0.01 * (i % 10) for i in range(150)]
            }},
        ]

        for data_example in data_types:
            data = data_example["data"]
            data_type = data_example["type"]

            # Serializar en diferentes formatos
            for fmt in [SerializationFormat.TOON, SerializationFormat.VSC]:
                try:
                    serializer = get_serializer(fmt)
                    serialized = serializer.serialize(data)

                    # Crear ejemplo de entrenamiento
                    if fmt == SerializationFormat.TOON:
                        instruction = "Analiza estos datos serializados en formato TOON y describe su estructura:"
                        format_desc = "TOON (Typed Object Notation)"
                    else:  # VSC
                        instruction = "Analiza estos datos columnar densos en formato VSC y explica su contenido:"
                        format_desc = "VSC (Vector Serialized Columns)"

                    # Convertir datos binarios a base64 para el prompt
                    import base64
                    b64_data = base64.b64encode(serialized.data).decode('ascii')

                    prompt = f"""[TAREA DE ANÁLISIS DE DATOS SERIALIZADOS]

{instruction}

Datos en {format_desc} (codificados en base64):
{b64_data}

Pregunta: ¿Qué tipo de datos contiene esta serialización y cuál es su estructura principal?

Análisis paso a paso:
1. Identificar el formato de serialización
2. Describir la estructura de los datos
3. Explicar el propósito o uso típico de estos datos
4. Mencionar cualquier patrón o característica notable

Respuesta:"""

                    # Crear respuesta esperada
                    if data_type == "uniform_array":
                        response = f"""Estos datos están serializados en formato {format_desc} y contienen un array uniforme de números enteros.

Estructura: Array simple con {len(data)} elementos numéricos consecutivos
Propósito: Almacenamiento eficiente de secuencias numéricas uniformes
Patrón: Progresión aritmética simple (1, 2, 3, 4, 5...)"""

                    elif data_type == "string_array":
                        response = f"""Estos datos están serializados en formato {format_desc} y contienen un array de cadenas de texto.

Estructura: Array de strings con patrón "item_N" donde N es un número secuencial
Propósito: Almacenamiento de listas de identificadores o etiquetas
Patrón: Nombres de elementos con numeración consecutiva"""

                    elif data_type == "float_array":
                        response = f"""Estos datos están serializados en formato {format_desc} y contienen un array de números de punto flotante.

Estructura: Secuencia de valores flotantes con incrementos de 0.1
Propósito: Datos numéricos continuos, posiblemente mediciones o coordenadas
Patrón: Progresión aritmética de punto flotante"""

                    elif data_type == "objects_array":
                        response = f"""Estos datos están serializados en formato {format_desc} y contienen un array de objetos estructurados.

Estructura: Array de objetos con campos 'id', 'name', y 'value'
Propósito: Registros de datos estructurados, como entradas de base de datos
Patrón: Objetos con identificadores únicos y valores calculados"""

                    elif data_type == "columnar_data":
                        response = f"""Estos datos están serializados en formato {format_desc} y contienen datos organizados en columnas.

Estructura: 4 columnas (timestamps, values, categories, flags) con {len(data['timestamps'])} filas cada una
Propósito: Dataset tabular eficiente para análisis de datos
Patrón: Timestamps secuenciales, valores calculados, categorías cíclicas, flags booleanos"""

                    elif data_type == "scientific_data":
                        response = f"""Estos datos están serializados en formato {format_desc} y contienen datos científicos/mediciones.

Estructura: 4 columnas científicas (coordenadas x/y, mediciones, errores) con {len(data['x_coords'])} puntos de datos
Propósito: Almacenamiento eficiente de datos experimentales o simulaciones
Patrón: Coordenadas cartesianas con mediciones y estimaciones de error"""

                    # Crear ejemplo completo
                    full_example = prompt + "\n\n" + response
                    examples.append({"text": full_example, "format": fmt.value, "data_type": data_type})

                except Exception as e:
                    logger.warning(f"Error generando ejemplo para {fmt.value} {data_type}: {e}")
                    continue

        logger.info(f"Generated {len(examples)} training examples")
        return examples

    def prepare_dataset(self, examples: List[Dict[str, str]]) -> Dataset:
        """Preparar dataset de HuggingFace para entrenamiento."""
        # Convertir a formato de texto plano
        texts = [ex["text"] for ex in examples]

        # Crear dataset
        dataset = Dataset.from_dict({"text": texts})

        # Tokenizar
        def tokenize_function(examples):
            return self.tokenizer(
                examples["text"],
                truncation=True,
                max_length=self.config.max_seq_length,
                padding="max_length"
            )

        tokenized_dataset = dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=["text"]
        )

        return tokenized_dataset

    def train(self):
        """Ejecutar fine-tuning."""
        logger.info("Starting fine-tuning for serialization format understanding")

        # Generar datos de entrenamiento
        examples = self.generate_training_examples()

        # Preparar dataset
        train_dataset = self.prepare_dataset(examples)

        # Configuración de entrenamiento
        training_args = TrainingArguments(
            output_dir=self.config.output_dir,
            num_train_epochs=self.config.num_train_epochs,
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            gradient_accumulation_steps=self.config.gradient_accumulation_steps,
            learning_rate=self.config.learning_rate,
            save_steps=self.config.save_steps,
            logging_steps=self.config.logging_steps,
            save_total_limit=2,
            load_best_model_at_end=True,
            evaluation_strategy="no",
            fp16=torch.cuda.is_available(),
            dataloader_num_workers=0,  # Evitar problemas en algunos entornos
        )

        # Data collator
        data_collator = DataCollatorForLanguageModeling(
            tokenizer=self.tokenizer,
            mlm=False  # Causal LM, no masked
        )

        # Trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            data_collator=data_collator,
        )

        # Entrenar
        logger.info("Starting training...")
        trainer.train()

        # Guardar modelo
        trainer.save_model()
        self.tokenizer.save_pretrained(self.config.output_dir)

        logger.info(f"Fine-tuned model saved to {self.config.output_dir}")

    def evaluate_serialization_understanding(self) -> Dict[str, Any]:
        """Evaluar comprensión de formatos de serialización."""
        logger.info("Evaluating serialization format understanding")

        # Ejemplos de evaluación
        test_examples = [
            {
                "data": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
                "expected_format": "TOON",
                "description": "Array numérico simple"
            },
            {
                "data": {
                    "x": [i for i in range(20)],
                    "y": [i*2 for i in range(20)],
                    "z": [i**2 for i in range(20)]
                },
                "expected_format": "VSC",
                "description": "Datos columnar científicos"
            }
        ]

        results = {}

        for i, example in enumerate(test_examples):
            data = example["data"]
            expected_format = example["expected_format"]

            # Serializar
            fmt = SerializationFormat.TOON if expected_format == "TOON" else SerializationFormat.VSC
            serializer = get_serializer(fmt)
            serialized = serializer.serialize(data)

            # Crear prompt de evaluación
            import base64
            b64_data = base64.b64encode(serialized.data).decode('ascii')

            prompt = f"""Analiza estos datos serializados y describe su estructura:

Datos: {b64_data}

¿En qué formato están serializados estos datos (TOON o VSC) y qué contienen?"""

            # Generar respuesta (en implementación real, usar el modelo fine-tuneado)
            # Por ahora, mock response
            if expected_format == "TOON":
                response = "Estos datos están en formato TOON y contienen un array numérico simple."
            else:
                response = "Estos datos están en formato VSC y contienen datos organizados en columnas (x, y, z)."

            results[f"test_{i}"] = {
                "description": example["description"],
                "expected_format": expected_format,
                "prompt": prompt,
                "response": response,
                "correct": expected_format.lower() in response.lower()
            }

        return results


def main():
    """Función principal."""
    if not TRANSFORMERS_AVAILABLE:
        print("❌ transformers library required for fine-tuning")
        print("Install with: pip install transformers datasets torch")
        return

    import argparse

    parser = argparse.ArgumentParser(description="Fine-tune EmpoorioLM for serialization format understanding")
    parser.add_argument("--model-path", type=str, default="./models/empoorio_lm/v1.0.0",
                       help="Path to base EmpoorioLM model")
    parser.add_argument("--output-dir", type=str, default="./models/empoorio_lm/finetuned_serialization",
                       help="Output directory for fine-tuned model")
    parser.add_argument("--epochs", type=int, default=3, help="Number of training epochs")
    parser.add_argument("--batch-size", type=int, default=4, help="Batch size")
    parser.add_argument("--examples", type=int, default=1000, help="Number of training examples to generate")
    parser.add_argument("--evaluate-only", action="store_true", help="Only run evaluation")

    args = parser.parse_args()

    # Configurar fine-tuning
    config = FineTuneConfig(
        model_path=args.model_path,
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        num_examples=args.examples
    )

    tuner = SerializationFineTuner(config)

    try:
        tuner.load_model()

        if args.evaluate_only:
            # Solo evaluación
            results = tuner.evaluate_serialization_understanding()
            print("\n📊 EVALUATION RESULTS")
            print("=" * 50)
            for test_name, result in results.items():
                status = "✅" if result["correct"] else "❌"
                print(f"{status} {test_name}: {result['description']}")
                print(f"   Expected: {result['expected_format']}")
                print(f"   Response: {result['response'][:100]}...")
                print()
        else:
            # Fine-tuning completo
            tuner.train()

            # Evaluación post-entrenamiento
            results = tuner.evaluate_serialization_understanding()

            print("\n📊 POST-TRAINING EVALUATION")
            print("=" * 50)
            correct_count = sum(1 for r in results.values() if r["correct"])
            total_count = len(results)
            accuracy = correct_count / total_count * 100

            print(f"Accuracy: {correct_count}/{total_count} ({accuracy:.1f}%)")

            for test_name, result in results.items():
                status = "✅" if result["correct"] else "❌"
                print(f"{status} {test_name}: {result['description']}")

    except Exception as e:
        logger.error(f"Fine-tuning failed: {e}")
        print(f"❌ Fine-tuning failed: {e}")
        return 1

    print("✅ Fine-tuning completed successfully")
    return 0


if __name__ == "__main__":
    exit(main())