#!/bin/bash
# Main script for automated pruning of Docker images in Google Cloud Artifact Registry
# Performs pruning of old and unsigned images, and generates a report on space freed
# Usage: ./maintenance_prune.sh <project_id> <location> <repository> [days_old] [log_file]

set -e

if [ $# -lt 3 ]; then
    echo "Usage: $0 <project_id> <location> <repository> [days_old] [log_file]"
    echo "Example: $0 my-project us-central1 my-repo 30 maintenance.log"
    exit 1
fi

PROJECT_ID=$1
LOCATION=$2
REPOSITORY=$3
DAYS_OLD=${4:-30}
LOG_FILE=${5:-"maintenance_prune_$(date +%Y%m%d_%H%M%S).log"}

echo "Starting maintenance pruning for repository: $REPOSITORY"
echo "Log file: $LOG_FILE"

# Function to calculate total size of images in repository
calculate_total_size() {
    gcloud artifacts docker images list --repository="$REPOSITORY" --location="$LOCATION" --project="$PROJECT_ID" --format="value(sizeBytes)" | awk '{sum += $1} END {print sum+0}'
}

# Function to count images
count_images() {
    gcloud artifacts docker images list --repository="$REPOSITORY" --location="$LOCATION" --project="$PROJECT_ID" --format="count()"
}

# Initial state
echo "Calculating initial repository state..." | tee -a "$LOG_FILE"
INITIAL_SIZE=$(calculate_total_size)
INITIAL_COUNT=$(count_images)
echo "Initial images count: $INITIAL_COUNT" | tee -a "$LOG_FILE"
echo "Initial total size: $INITIAL_SIZE bytes" | tee -a "$LOG_FILE"

# Prune old images
echo "Pruning images older than $DAYS_OLD days..." | tee -a "$LOG_FILE"
./prune_old_images.sh "$PROJECT_ID" "$LOCATION" "$REPOSITORY" "$DAYS_OLD" 2>&1 | tee -a "$LOG_FILE"

# Prune unsigned images
echo "Pruning unsigned images..." | tee -a "$LOG_FILE"
./prune_unsigned_images.sh "$PROJECT_ID" "$LOCATION" "$REPOSITORY" 2>&1 | tee -a "$LOG_FILE"

# Final state
echo "Calculating final repository state..." | tee -a "$LOG_FILE"
FINAL_SIZE=$(calculate_total_size)
FINAL_COUNT=$(count_images)
echo "Final images count: $FINAL_COUNT" | tee -a "$LOG_FILE"
echo "Final total size: $FINAL_SIZE bytes" | tee -a "$LOG_FILE"

# Calculate differences
DELETED_IMAGES=$((INITIAL_COUNT - FINAL_COUNT))
SPACE_FREED=$((INITIAL_SIZE - FINAL_SIZE))

# Report
echo "=== MAINTENANCE PRUNING REPORT ===" | tee -a "$LOG_FILE"
echo "Repository: $REPOSITORY" | tee -a "$LOG_FILE"
echo "Project: $PROJECT_ID" | tee -a "$LOG_FILE"
echo "Location: $LOCATION" | tee -a "$LOG_FILE"
echo "Date: $(date)" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "Images deleted: $DELETED_IMAGES" | tee -a "$LOG_FILE"
echo "Space freed: $SPACE_FREED bytes" | tee -a "$LOG_FILE"
echo "Space freed (MB): $((SPACE_FREED / 1024 / 1024)) MB" | tee -a "$LOG_FILE"
echo "" | tee -a "$LOG_FILE"
echo "Maintenance completed successfully." | tee -a "$LOG_FILE"