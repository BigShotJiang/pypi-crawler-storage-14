#!/usr/bin/env python3
"""
Script to clean up placeholders and simulations from the AILOOS codebase.
This script identifies and removes mock data, placeholders, and simulation code.
"""

import os
import re
import sys
from pathlib import Path
from typing import List, Dict, Set
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

class PlaceholderCleaner:
    """Class to clean up placeholders and simulations."""

    def __init__(self, root_dir: str = "."):
        self.root_dir = Path(root_dir)
        self.python_files: List[Path] = []
        self.cleaned_files: Set[str] = set()
        self.issues_found: Dict[str, List[str]] = {}

        # Patterns to identify placeholders
        self.placeholder_patterns = [
            # Mock/Simulated data
            r'\b(mock|simul|fake|dummy)\b',
            r'\bplaceholder\b',
            r'\bTODO\b',
            r'\bFIXME\b',
            r'\bXXX\b',

            # Simulation comments
            r'#.*(?:mock|simul|fake|dummy|placeholder)',
            r'#.*TODO',
            r'#.*FIXME',
            r'#.*XXX',

            # Mock function calls
            r'\.mock_',
            r'_mock\b',
            r'Mock\(\)',

            # Fallback data
            r'fallback.*data',
            r'default.*data',
            r'sample.*data',

            # Simulation mode
            r'simulation.*mode',
            r'use_real.*=.*False',
        ]

        # Files to exclude from cleaning
        self.exclude_patterns = [
            'test_*.py',  # Test files
            '*test*.py',
            '__pycache__',
            '.git',
            'node_modules',
            'build',
            'dist',
            '*.pyc',
            '*.pyo',
            '*.egg-info',
            '.pytest_cache',
            'cleanup_placeholders.py',  # This script itself
        ]

    def find_python_files(self):
        """Find all Python files in the project."""
        self.python_files = []

        for root, dirs, files in os.walk(self.root_dir):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if not any(
                re.match(pattern.replace('*', '.*'), d) for pattern in self.exclude_patterns
            )]

            for file in files:
                if file.endswith('.py'):
                    file_path = Path(root) / file

                    # Check if file should be excluded
                    should_exclude = any(
                        re.match(pattern.replace('*', '.*'), str(file_path)) for pattern in self.exclude_patterns
                    )

                    if not should_exclude:
                        self.python_files.append(file_path)

        logger.info(f"Found {len(self.python_files)} Python files to analyze")

    def analyze_file(self, file_path: Path) -> List[str]:
        """Analyze a file for placeholders and issues."""
        issues = []

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()

            for line_num, line in enumerate(lines, 1):
                line_clean = line.strip().lower()

                # Check for placeholder patterns
                for pattern in self.placeholder_patterns:
                    if re.search(pattern, line_clean, re.IGNORECASE):
                        issues.append(f"Line {line_num}: {line.strip()}")
                        break

        except Exception as e:
            logger.warning(f"Error analyzing {file_path}: {e}")

        return issues

    def analyze_all_files(self):
        """Analyze all Python files for placeholders."""
        logger.info("Analyzing files for placeholders...")

        total_issues = 0

        for file_path in self.python_files:
            issues = self.analyze_file(file_path)
            if issues:
                self.issues_found[str(file_path)] = issues
                total_issues += len(issues)

        logger.info(f"Found {total_issues} placeholder issues in {len(self.issues_found)} files")

    def generate_report(self) -> str:
        """Generate a comprehensive report of findings."""
        report = []
        report.append("# AILOOS Placeholder Cleanup Report")
        report.append("")
        report.append(f"**Total files analyzed:** {len(self.python_files)}")
        report.append(f"**Files with issues:** {len(self.issues_found)}")
        report.append(f"**Total issues found:** {sum(len(issues) for issues in self.issues_found.values())}")
        report.append("")

        if self.issues_found:
            report.append("## Files Requiring Attention")
            report.append("")

            for file_path, issues in sorted(self.issues_found.items()):
                report.append(f"### {file_path}")
                report.append(f"**Issues found:** {len(issues)}")
                report.append("")

                # Show first 10 issues
                for issue in issues[:10]:
                    report.append(f"- {issue}")

                if len(issues) > 10:
                    report.append(f"- ... and {len(issues) - 10} more issues")

                report.append("")

        else:
            report.append("## ✅ No Placeholder Issues Found")
            report.append("")
            report.append("All files are clean of placeholders and simulations!")

        return "\n".join(report)

    def save_report(self, output_file: str = "placeholder_report.md"):
        """Save the report to a file."""
        report = self.generate_report()

        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report)

        logger.info(f"Report saved to {output_file}")

    def run_cleanup(self):
        """Run the complete cleanup process."""
        logger.info("Starting AILOOS placeholder cleanup...")

        self.find_python_files()
        self.analyze_all_files()
        self.save_report()

        logger.info("Cleanup analysis complete!")

        # Print summary
        if self.issues_found:
            print(f"\n❌ Found {len(self.issues_found)} files with placeholder issues")
            print("See placeholder_report.md for details")
        else:
            print("\n✅ No placeholder issues found!")

def main():
    """Main entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="Clean up placeholders in AILOOS codebase")
    parser.add_argument("--root-dir", default=".", help="Root directory to analyze")
    parser.add_argument("--output", default="placeholder_report.md", help="Output report file")

    args = parser.parse_args()

    cleaner = PlaceholderCleaner(args.root_dir)
    cleaner.run_cleanup()

    # Save detailed report
    cleaner.save_report(args.output)

if __name__ == "__main__":
    main()