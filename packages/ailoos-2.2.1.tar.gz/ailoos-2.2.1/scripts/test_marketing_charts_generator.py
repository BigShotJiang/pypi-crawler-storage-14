#!/usr/bin/env python3
"""
Script de prueba para el generador de gráficos de marketing de EmpoorioLM.
Prueba la funcionalidad del MarketingChartsGenerator con datos de ejemplo.
"""

import os
import sys
import json
from pathlib import Path

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.benchmarking.marketing_charts_generator import (
    MarketingChartsGenerator,
    MarketingChartConfig,
    generate_marketing_charts
)

def create_sample_comparison_data():
    """Crea datos de comparación de ejemplo para pruebas."""
    return {
        'comprehensive_metrics': {
            'empoorio': {
                'model_name': 'empoorio',
                'accuracy_overall': 0.875,
                'accuracy_mmlu': 0.842,
                'accuracy_gsm8k': 0.756,
                'avg_latency': 1.23,
                'total_energy_joules': 45.6,
                'efficiency_score': 0.723,
                'rag_accuracy': 0.891,
                'sample_count': 150
            },
            'gpt4': {
                'model_name': 'gpt4',
                'accuracy_overall': 0.834,
                'accuracy_mmlu': 0.798,
                'accuracy_gsm8k': 0.712,
                'avg_latency': 2.45,
                'total_energy_joules': 89.2,
                'efficiency_score': 0.456,
                'rag_accuracy': 0.834,
                'sample_count': 150
            },
            'claude': {
                'model_name': 'claude',
                'accuracy_overall': 0.812,
                'accuracy_mmlu': 0.776,
                'accuracy_gsm8k': 0.698,
                'avg_latency': 1.87,
                'total_energy_joules': 67.8,
                'efficiency_score': 0.534,
                'rag_accuracy': 0.812,
                'sample_count': 150
            },
            'gemini': {
                'model_name': 'gemini',
                'accuracy_overall': 0.798,
                'accuracy_mmlu': 0.754,
                'accuracy_gsm8k': 0.678,
                'avg_latency': 2.12,
                'total_energy_joules': 78.9,
                'efficiency_score': 0.489,
                'rag_accuracy': 0.798,
                'sample_count': 150
            }
        },
        'statistical_comparisons': [
            {
                'model_a': 'empoorio',
                'model_b': 'gpt4',
                'metric': 'accuracy_overall',
                'mean_a': 0.875,
                'mean_b': 0.834,
                'difference': 0.041,
                'p_value': 0.023,
                'significant': True
            }
        ],
        'market_headlines': [
            {
                'headline': 'EmpoorioLM: 4.9% más preciso que GPT-4 en benchmarks comprehensivos',
                'model': 'empoorio',
                'competitor': 'gpt4',
                'improvement': 4.9,
                'category': 'accuracy'
            }
        ]
    }

def test_basic_functionality():
    """Prueba funcionalidad básica del generador."""
    print("🧪 Probando funcionalidad básica del MarketingChartsGenerator")

    # Crear datos de ejemplo
    sample_data = create_sample_comparison_data()

    # Crear generador
    config = MarketingChartConfig(
        output_dir='./test_marketing_charts',
        color_palette='ailoos',
        target_platform='presentation'
    )
    generator = MarketingChartsGenerator(config)

    # Cargar datos
    generator.load_comparison_data(sample_data)
    print("✅ Datos de comparación cargados")

    # Generar gráfico de barras de precisión
    accuracy_chart = generator.generate_accuracy_comparison_chart('bar')
    if accuracy_chart:
        print(f"✅ Gráfico de barras de precisión generado: {accuracy_chart}")
    else:
        print("❌ Error generando gráfico de barras de precisión")

    # Generar gráfico de radar
    radar_chart = generator.generate_accuracy_comparison_chart('radar')
    if radar_chart:
        print(f"✅ Gráfico radar de precisión generado: {radar_chart}")
    else:
        print("❌ Error generando gráfico radar de precisión")

    # Generar gráfico de rendimiento
    latency_chart = generator.generate_performance_comparison_chart('latency', 'bar')
    if latency_chart:
        print(f"✅ Gráfico de latencia generado: {latency_chart}")
    else:
        print("❌ Error generando gráfico de latencia")

    print("🎉 Pruebas básicas completadas")

def test_platform_optimization():
    """Prueba optimización para diferentes plataformas."""
    print("\n📱 Probando optimización para plataformas")

    sample_data = create_sample_comparison_data()

    platforms = ['presentation', 'social_media', 'web']

    for platform in platforms:
        print(f"\n🎯 Probando plataforma: {platform}")

        generator = MarketingChartsGenerator()
        generator.optimize_for_platform(platform)
        generator.load_comparison_data(sample_data)

        # Generar un gráfico para cada plataforma
        chart = generator.generate_accuracy_comparison_chart('bar',
            filename=f'accuracy_{platform}_{generator.config.dpi}dpi.png')

        if chart:
            print(f"✅ Gráfico para {platform} generado: {chart}")
        else:
            print(f"❌ Error generando gráfico para {platform}")

def test_social_media_formats():
    """Prueba formatos específicos de redes sociales."""
    print("\n📸 Probando formatos de redes sociales")

    sample_data = create_sample_comparison_data()
    generator = MarketingChartsGenerator()
    generator.load_comparison_data(sample_data)

    formats = ['instagram_post', 'twitter_post', 'linkedin_post']

    for fmt in formats:
        print(f"\n🎨 Probando formato: {fmt}")
        generator.set_social_media_format(fmt)

        chart = generator.generate_accuracy_comparison_chart('bar',
            filename=f'accuracy_{fmt}.png')

        if chart:
            print(f"✅ Gráfico {fmt} generado: {chart}")
        else:
            print(f"❌ Error generando gráfico {fmt}")

def test_chart_suite():
    """Prueba generación de suite completa de gráficos."""
    print("\n🎨 Probando suite completa de gráficos")

    sample_data = create_sample_comparison_data()

    # Usar función de conveniencia
    generated_files = generate_marketing_charts(
        sample_data,
        output_dir='./test_chart_suite',
        platform='presentation'
    )

    print(f"✅ Suite generada con {len(generated_files)} gráficos:")
    for chart_type, filepath in generated_files.items():
        print(f"  • {chart_type}: {filepath}")

def test_metadata_export():
    """Prueba exportación de metadata de gráficos."""
    print("\n📋 Probando exportación de metadata")

    sample_data = create_sample_comparison_data()
    generator = MarketingChartsGenerator()
    generator.load_comparison_data(sample_data)

    # Generar algunos gráficos
    generator.generate_accuracy_comparison_chart('bar')
    generator.generate_accuracy_comparison_chart('radar')

    # Exportar metadata
    metadata_file = generator.export_chart_metadata()
    if metadata_file:
        print(f"✅ Metadata exportada: {metadata_file}")

        # Leer y mostrar metadata
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
            print(f"📊 Metadata de {len(metadata)} gráficos exportada")
    else:
        print("❌ Error exportando metadata")

def main():
    """Función principal de pruebas."""
    print("🚀 Iniciando pruebas del MarketingChartsGenerator")
    print("=" * 60)

    try:
        # Crear directorio de pruebas
        os.makedirs('./test_marketing_charts', exist_ok=True)
        os.makedirs('./test_chart_suite', exist_ok=True)

        # Ejecutar pruebas
        test_basic_functionality()
        test_platform_optimization()
        test_social_media_formats()
        test_chart_suite()
        test_metadata_export()

        print("\n🎉 Todas las pruebas completadas exitosamente!")
        print("📁 Archivos generados en ./test_marketing_charts/ y ./test_chart_suite/")

    except Exception as e:
        print(f"\n❌ Error durante las pruebas: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()