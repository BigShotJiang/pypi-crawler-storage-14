#!/usr/bin/env python3
"""
Standalone test for document deduplication system.
Tests the core functionality without importing the full Ailoos package.
"""

import sys
import os
import hashlib
import json
from typing import Dict, Any, Optional
from unittest.mock import Mock, AsyncMock
import asyncio

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import directly from the module file to avoid package dependencies
exec(open('src/ailoos/rag/core/deduplication.py').read())


async def test_basic_hashing():
    """Test basic SHA-256 hashing functionality."""
    print("Testing basic hashing...")

    doc1 = {'content': 'This is test content', 'title': 'Test Document'}
    doc2 = {'content': 'This is test content', 'title': 'Test Document'}
    doc3 = {'content': 'Different content', 'title': 'Test Document'}

    hash1 = DocumentDeduplicator.calculate_document_hash(doc1)
    hash2 = DocumentDeduplicator.calculate_document_hash(doc2)
    hash3 = DocumentDeduplicator.calculate_document_hash(doc3)

    assert hash1 == hash2, "Identical documents should have same hash"
    assert hash1 != hash3, "Different documents should have different hashes"
    assert len(hash1) == 64, "SHA-256 should produce 64 character hash"

    print("✓ Basic hashing tests passed")


async def test_document_hash_dataclass():
    """Test DocumentHash dataclass."""
    print("Testing DocumentHash dataclass...")

    doc_hash = DocumentHash(
        document_hash="abc123",
        document_id="doc1",
        content_length=100,
        timestamp="2023-01-01T00:00:00",
        node_id="node1",
        metadata={"title": "Test"}
    )

    # Test serialization
    data = doc_hash.to_dict()
    restored = DocumentHash.from_dict(data)

    assert doc_hash.document_hash == restored.document_hash
    assert doc_hash.document_id == restored.document_id
    assert doc_hash.metadata == restored.metadata

    print("✓ DocumentHash dataclass tests passed")


async def test_distributed_registry():
    """Test distributed hash registry."""
    print("Testing distributed hash registry...")

    # Mock IPFS manager
    mock_ipfs = AsyncMock()
    mock_ipfs.add_data.return_value = "test_cid"

    registry = DistributedHashRegistry(mock_ipfs, "test_node")

    # Test initialization
    await registry.initialize()
    assert registry.is_initialized

    # Test registering a hash
    doc_hash = DocumentHash(
        document_hash="hash123",
        document_id="doc1",
        content_length=100,
        timestamp="2023-01-01T00:00:00",
        node_id="test_node"
    )

    result = await registry.register_document_hash(doc_hash)
    assert result == True
    assert "hash123" in registry.hash_registry

    # Test duplicate registration
    result2 = await registry.register_document_hash(doc_hash)
    assert result2 == False

    # Test document known check
    assert await registry.is_document_known("hash123") == True
    assert await registry.is_document_known("unknown") == False

    print("✓ Distributed hash registry tests passed")


async def test_deduplicator():
    """Test document deduplicator."""
    print("Testing document deduplicator...")

    mock_registry = AsyncMock()
    deduplicator = DocumentDeduplicator(mock_registry)

    # Test new document
    mock_registry.is_document_known.return_value = False
    mock_registry.register_document_hash.return_value = True

    doc = {'id': 'doc1', 'content': 'Test content'}
    result = await deduplicator.should_process_document(doc)

    assert result == True
    assert deduplicator.stats['documents_processed'] == 1
    assert deduplicator.stats['duplicates_found'] == 0

    # Test duplicate document
    mock_registry.is_document_known.return_value = True

    doc2 = {'id': 'doc2', 'content': 'Test content'}
    result2 = await deduplicator.should_process_document(doc2)

    assert result2 == False
    assert deduplicator.stats['documents_processed'] == 2
    assert deduplicator.stats['duplicates_found'] == 1

    print("✓ Document deduplicator tests passed")


async def test_storage_reduction():
    """Test storage reduction calculation."""
    print("Testing storage reduction...")

    mock_registry = AsyncMock()
    deduplicator = DocumentDeduplicator(mock_registry)

    # Simulate processing documents with known sizes
    mock_registry.is_document_known.return_value = True  # All are duplicates

    documents = [
        {'id': 'doc1', 'content': 'A' * 1000},  # 1000 bytes
        {'id': 'doc2', 'content': 'B' * 2000},  # 2000 bytes
        {'id': 'doc3', 'content': 'C' * 1500},  # 1500 bytes
    ]

    for doc in documents:
        await deduplicator.should_process_document(doc)

    stats = deduplicator.get_deduplication_stats()

    assert stats['documents_processed'] == 3
    assert stats['duplicates_found'] == 3
    assert stats['storage_saved_bytes'] == 4500  # 1000 + 2000 + 1500

    print("✓ Storage reduction tests passed")


async def test_deduplication_pipeline():
    """Test full deduplication pipeline."""
    print("Testing deduplication pipeline...")

    mock_registry = AsyncMock()
    deduplicator = DocumentDeduplicator(mock_registry)

    # Mix of new and duplicate documents
    mock_registry.is_document_known.side_effect = [False, True, False, True, False]
    mock_registry.register_document_hash.return_value = True

    documents = [
        {'id': 'new1', 'content': 'New content 1'},
        {'id': 'dup1', 'content': 'Duplicate content'},
        {'id': 'new2', 'content': 'New content 2'},
        {'id': 'dup2', 'content': 'Duplicate content'},
        {'id': 'new3', 'content': 'New content 3'},
    ]

    result = await deduplicator.deduplicate_documents(documents)

    # Should return only new documents
    assert len(result) == 3
    assert all(doc['id'].startswith('new') for doc in result)

    stats = deduplicator.get_deduplication_stats()
    assert stats['documents_processed'] == 5
    assert stats['duplicates_found'] == 2
    assert stats['unique_documents'] == 3

    print("✓ Deduplication pipeline tests passed")


async def main():
    """Run all tests."""
    print("Running Document Deduplication System Tests")
    print("=" * 50)

    try:
        await test_basic_hashing()
        await test_document_hash_dataclass()
        await test_distributed_registry()
        await test_deduplicator()
        await test_storage_reduction()
        await test_deduplication_pipeline()

        print("=" * 50)
        print("🎉 All tests passed successfully!")
        print("Document deduplication system is working correctly.")

    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == '__main__':
    exit_code = asyncio.run(main())
    sys.exit(exit_code)