import json

def validate_json_results(file_path):
    """
    Valida los resultados de un archivo JSON de prueba a gran escala.
    """
    try:
        with open(file_path, 'r') as f:
            results = json.load(f)
    except FileNotFoundError:
        print(f"❌ Error: El archivo {file_path} no fue encontrado.")
        return
    except json.JSONDecodeError:
        print(f"❌ Error: El archivo {file_path} no es un JSON válido.")
        return

    print(f"📄 Validando resultados de: {file_path}")
    print("=" * 60)

    # Extraer métricas clave
    network_stability = results.get('network_stability', 0)
    gossip_results = results.get('individual_test_results', {}).get('gossip_consensus_at_scale', {})
    healing_results = results.get('individual_test_results', {}).get('auto_healing_at_scale', {})
    model_dist_results = results.get('individual_test_results', {}).get('model_distribution_at_scale', {})

    gossip_rate = gossip_results.get('consensus_rate', 0)
    healing_stability = healing_results.get('node_stability', 0)
    total_recovery_events = healing_results.get('total_recovery_events', 0)
    chunks_distributed = model_dist_results.get('chunks_distributed', 0)
    total_chunks = model_dist_results.get('total_chunks', 0)

    # --- Criterios de Validación ---
    # Basados en las aserciones del script de validación y el sentido común.
    # Un sistema saludable debería tener alta estabilidad y consenso.

    print("📊 Resumen de Métricas Clave:")
    print(f"  - Estabilidad de la red general: {network_stability:.2%}")
    print(f"  - Tasa de consenso Gossip: {gossip_rate:.2%}")
    print(f"  - Estabilidad de nodos en auto-reparación: {healing_stability:.2%}")
    print(f"  - Eventos de recuperación: {total_recovery_events}")
    print(f"  - Chunks de modelo distribuidos: {chunks_distributed} (de {total_chunks} esperados)")


    print("\n🔬 Análisis de Validación:")
    
    # 1. Estabilidad de la red
    if network_stability < 0.5:
        print(f"    - ⚠️  Alerta de Estabilidad: La estabilidad general de la red ({network_stability:.2%}) es muy baja. Menos de la mitad de los nodos permanecieron estables.")
    else:
        print("    - ✅ Estabilidad de la Red: Aceptable.")

    # 2. Consenso
    if gossip_rate < 0.1: # Umbral más realista para una prueba grande
        print(f"    - ❌ Fallo Crítico en Consenso: La tasa de consenso ({gossip_rate:.2%}) es extremadamente baja. Los nodos no están llegando a acuerdos.")
    else:
        print("    - ✅ Consenso Gossip: Aceptable.")

    # 3. Auto-reparación
    if healing_stability < 0.5 or total_recovery_events == 0:
        print(f"    - ❌ Fallo Crítico en Auto-Reparación: La estabilidad durante la prueba de curación fue solo del {healing_stability:.2%}, y lo más importante, se registraron {total_recovery_events} eventos de recuperación. Esto indica que el mecanismo de auto-reparación no está funcionando como se esperaba.")
    else:
        print("    - ✅ Auto-Reparación: Parece funcional.")
        
    # 4. Distribución de modelo
    if chunks_distributed > total_chunks * 10: # Si se distribuyen más de 10x chunks, algo es anómalo
        print(f"    - ⚠️  Anomalía en Distribución: Se distribuyeron {chunks_distributed} chunks, lo cual es significativamente más que los {total_chunks} chunks del modelo. Esto podría indicar un error en el reporte o retransmisiones excesivas.")
    elif chunks_distributed < total_chunks:
        print(f"    - ⚠️  Alerta de Distribución: No se distribuyeron todos los chunks del modelo ({chunks_distributed}/{total_chunks}).")
    else:
        print("    - ✅ Distribución de Modelo: Aceptable.")


    print("\n" + "=" * 60)
    print("🏁 Fin de la Validación.")


if __name__ == "__main__":
    validate_json_results('large_scale_test_results_500_nodes.json')
