#!/usr/bin/env python3
"""
Script de prueba de coherencia para EmpoorioLM
Evalúa consistencia, razonamiento y comprensión en diferentes tipos de preguntas.
"""

import asyncio
import json
import time
from typing import Dict, List, Any
from collections import defaultdict
import sys
import os

# Añadir src al path para importar módulos
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from ailoos.inference.api import generate_text, InferenceConfig, EmpoorioLMInferenceAPI


class CoherenceTest:
    """Clase para ejecutar pruebas de coherencia en EmpoorioLM."""

    def __init__(self):
        self.questions = self._define_questions()
        self.results = {}
        self.consistency_checks = {}

    def _define_questions(self) -> Dict[str, List[Dict[str, Any]]]:
        """Definir preguntas de prueba organizadas por categoría."""
        return {
            "ciencia": [
                {
                    "id": "ciencia_1",
                    "question": "¿Cómo funciona la fotosíntesis?",
                    "category": "ciencia",
                    "type": "explicativo"
                },
                {
                    "id": "ciencia_2",
                    "question": "Explica el proceso de la fotosíntesis en plantas.",
                    "category": "ciencia",
                    "type": "explicativo",
                    "similar_to": "ciencia_1"  # Para verificar consistencia
                },
                {
                    "id": "ciencia_3",
                    "question": "¿Cuál es la fórmula química de la fotosíntesis?",
                    "category": "ciencia",
                    "type": "factual"
                }
            ],
            "historia": [
                {
                    "id": "historia_1",
                    "question": "¿Cuándo comenzó la Segunda Guerra Mundial?",
                    "category": "historia",
                    "type": "factual"
                },
                {
                    "id": "historia_2",
                    "question": "¿En qué año empezó la Segunda Guerra Mundial?",
                    "category": "historia",
                    "type": "factual",
                    "similar_to": "historia_1"
                },
                {
                    "id": "historia_3",
                    "question": "¿Qué países participaron en la Segunda Guerra Mundial?",
                    "category": "historia",
                    "type": "factual"
                }
            ],
            "logica": [
                {
                    "id": "logica_1",
                    "question": "Si todos los gatos son mamíferos y algunos mamíferos son mascotas, ¿qué puedes concluir?",
                    "category": "logica",
                    "type": "razonamiento"
                },
                {
                    "id": "logica_2",
                    "question": "Todos los estudiantes aprueban el examen. Juan es estudiante. ¿Aprueba Juan el examen?",
                    "category": "logica",
                    "type": "razonamiento"
                },
                {
                    "id": "logica_3",
                    "question": "Si A implica B, y B implica C, ¿entonces A implica C?",
                    "category": "logica",
                    "type": "razonamiento"
                }
            ],
            "creatividad": [
                {
                    "id": "creatividad_1",
                    "question": "Escribe un poema corto sobre la naturaleza.",
                    "category": "creatividad",
                    "type": "creativo"
                },
                {
                    "id": "creatividad_2",
                    "question": "Inventa una historia corta sobre un robot que aprende a sentir emociones.",
                    "category": "creatividad",
                    "type": "creativo"
                },
                {
                    "id": "creatividad_3",
                    "question": "Describe un mundo donde los colores tienen sonidos.",
                    "category": "creatividad",
                    "type": "creativo"
                }
            ],
            "espanol": [
                {
                    "id": "espanol_1",
                    "question": "¿Cuál es la capital de España?",
                    "category": "espanol",
                    "type": "factual"
                },
                {
                    "id": "espanol_2",
                    "question": "¿Qué significa la palabra 'serendipia' en español?",
                    "category": "espanol",
                    "type": "traduccion"
                },
                {
                    "id": "espanol_3",
                    "question": "Explica el significado de 'estar en las nubes' como expresión idiomática.",
                    "category": "espanol",
                    "type": "idiomatico"
                },
                {
                    "id": "espanol_4",
                    "question": "¿Cuál es la diferencia entre 'ser' y 'estar' en español?",
                    "category": "espanol",
                    "type": "gramatical"
                }
            ],
            "razonamiento": [
                {
                    "id": "razonamiento_1",
                    "question": "Un hombre tiene 12 monedas. Una es falsa y pesa diferente. ¿Cómo encuentra la falsa en 3 pesadas?",
                    "category": "razonamiento",
                    "type": "problema_logico"
                },
                {
                    "id": "razonamiento_2",
                    "question": "Si 5 máquinas tardan 5 minutos en hacer 5 widgets, ¿cuánto tardan 100 máquinas en hacer 100 widgets?",
                    "category": "razonamiento",
                    "type": "matematico"
                },
                {
                    "id": "razonamiento_3",
                    "question": "Tres interruptores controlan tres bombillas. ¿Cómo determinas cuál interruptor controla cuál bombilla con solo una visita al cuarto?",
                    "category": "razonamiento",
                    "type": "problema_logico"
                }
            ]
        }

    async def run_test(self, api: EmpoorioLMInferenceAPI) -> Dict[str, Any]:
        """Ejecutar todas las pruebas de coherencia."""
        print("🚀 Iniciando pruebas de coherencia de EmpoorioLM...")
        print("=" * 60)

        all_questions = []
        for category, questions in self.questions.items():
            all_questions.extend(questions)

        # Ejecutar preguntas
        for question_data in all_questions:
            print(f"\n📝 Pregunta {question_data['id']}: {question_data['question']}")
            print(f"   Categoría: {question_data['category']} | Tipo: {question_data['type']}")

            try:
                # Generar respuesta
                start_time = time.time()
                response = await generate_text(
                    prompt=question_data['question'],
                    model_path="./src/models/empoorio_lm/versions/empoorio_lm_v1.0.0-trained_267306",
                    max_tokens=200,
                    temperature=0.7
                )
                response_time = time.time() - start_time

                # Guardar resultado
                result = {
                    "question": question_data['question'],
                    "category": question_data['category'],
                    "type": question_data['type'],
                    "response": response,
                    "response_time": response_time,
                    "timestamp": time.time()
                }

                self.results[question_data['id']] = result

                print(f"   ⏱️  Tiempo: {response_time:.2f}s")
                print(f"   🤖 Respuesta: {response[:150]}{'...' if len(response) > 150 else ''}")

            except Exception as e:
                print(f"   ❌ Error: {str(e)}")
                self.results[question_data['id']] = {
                    "question": question_data['question'],
                    "category": question_data['category'],
                    "type": question_data['type'],
                    "error": str(e),
                    "timestamp": time.time()
                }

        # Evaluar consistencia
        self._evaluate_consistency()

        # Generar reporte
        return self._generate_report()

    def _evaluate_consistency(self):
        """Evaluar consistencia entre preguntas similares."""
        print("\n🔍 Evaluando consistencia entre preguntas similares...")

        consistency_pairs = [
            ("ciencia_1", "ciencia_2"),  # Fotosíntesis
            ("historia_1", "historia_2")  # WWII start
        ]

        for q1_id, q2_id in consistency_pairs:
            if q1_id in self.results and q2_id in self.results:
                resp1 = self.results[q1_id].get('response', '')
                resp2 = self.results[q2_id].get('response', '')

                # Calcular similitud simple (podría mejorarse con embeddings)
                similarity = self._calculate_similarity(resp1, resp2)

                self.consistency_checks[f"{q1_id}_vs_{q2_id}"] = {
                    "question1": self.results[q1_id]['question'],
                    "question2": self.results[q2_id]['question'],
                    "response1": resp1,
                    "response2": resp2,
                    "similarity_score": similarity,
                    "consistent": similarity > 0.5  # Umbral arbitrario
                }

                print(f"   📊 {q1_id} vs {q2_id}: Similitud = {similarity:.2f} {'✅' if similarity > 0.5 else '❌'}")

    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """Calcular similitud simple entre dos textos."""
        if not text1 or not text2:
            return 0.0

        # Convertir a minúsculas y dividir en palabras
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())

        # Calcular Jaccard similarity
        intersection = len(words1.intersection(words2))
        union = len(words1.union(words2))

        return intersection / union if union > 0 else 0.0

    def _generate_report(self) -> Dict[str, Any]:
        """Generar reporte completo de resultados."""
        # Estadísticas por categoría
        category_stats = defaultdict(lambda: {"total": 0, "successful": 0, "avg_time": 0.0})

        for result in self.results.values():
            cat = result['category']
            category_stats[cat]['total'] += 1

            if 'response' in result and 'error' not in result:
                category_stats[cat]['successful'] += 1
                category_stats[cat]['avg_time'] += result.get('response_time', 0)

        # Calcular promedios
        for cat in category_stats:
            if category_stats[cat]['successful'] > 0:
                category_stats[cat]['avg_time'] /= category_stats[cat]['successful']
            category_stats[cat]['success_rate'] = category_stats[cat]['successful'] / category_stats[cat]['total']

        # Estadísticas generales
        total_questions = len(self.results)
        successful_questions = sum(1 for r in self.results.values() if 'response' in r and 'error' not in r)
        avg_response_time = sum(r.get('response_time', 0) for r in self.results.values() if 'response_time' in r) / max(successful_questions, 1)

        report = {
            "summary": {
                "total_questions": total_questions,
                "successful_questions": successful_questions,
                "success_rate": successful_questions / total_questions,
                "average_response_time": avg_response_time,
                "categories_tested": list(self.questions.keys())
            },
            "category_stats": dict(category_stats),
            "consistency_checks": self.consistency_checks,
            "detailed_results": self.results,
            "timestamp": time.time()
        }

        return report


async def main():
    """Función principal."""
    print("🧪 Script de Prueba de Coherencia - EmpoorioLM")
    print("=" * 60)

    # Crear API
    config = InferenceConfig(
        model_path="./src/models/empoorio_lm/versions/empoorio_lm_v1.0.0-trained_267306",
        device="auto",
        max_new_tokens=200,
        temperature=0.7
    )

    api = EmpoorioLMInferenceAPI(config)

    # Cargar modelo
    print("📥 Cargando modelo EmpoorioLM...")
    success = await api.load_model()

    if not success:
        print("❌ Error: No se pudo cargar el modelo")
        return

    print("✅ Modelo cargado exitosamente")

    # Ejecutar pruebas
    test = CoherenceTest()
    report = await test.run_test(api)

    # Mostrar resultados
    print("\n" + "=" * 60)
    print("📊 REPORTE FINAL DE COHERENCIA")
    print("=" * 60)

    summary = report['summary']
    print(f"📈 Estadísticas Generales:")
    print(f"   • Total de preguntas: {summary['total_questions']}")
    print(f"   • Preguntas exitosas: {summary['successful_questions']}")
    print(f"   • Tasa de éxito: {summary['success_rate']:.1%}")
    print(f"   • Tiempo promedio: {summary['average_response_time']:.2f}s")
    print(f"   • Categorías probadas: {', '.join(summary['categories_tested'])}")

    print(f"\n📊 Estadísticas por Categoría:")
    for cat, stats in report['category_stats'].items():
        print(f"   • {cat.capitalize()}: {stats['successful']}/{stats['total']} ({stats['success_rate']:.1%}) - {stats['avg_time']:.2f}s avg")

    print(f"\n🔍 Verificación de Consistencia:")
    for check_id, check_data in report['consistency_checks'].items():
        status = "✅ Consistente" if check_data['consistent'] else "❌ Inconsistente"
        print(f"   • {check_id}: {status} (Similitud: {check_data['similarity_score']:.2f})")

    print(f"\n📝 Resultados Detallados:")
    print("-" * 40)
    for q_id, result in report['detailed_results'].items():
        status = "✅" if 'response' in result else "❌"
        print(f"{status} {q_id}: {result['question'][:50]}...")
        if 'response' in result:
            print(f"   → {result['response'][:100]}{'...' if len(result['response']) > 100 else ''}")
        elif 'error' in result:
            print(f"   → Error: {result['error']}")
        print()

    # Guardar reporte completo
    with open("empoorio_coherence_test_results.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    print("💾 Reporte completo guardado en: empoorio_coherence_test_results.json")

    print("\n🎉 Pruebas completadas!")


if __name__ == "__main__":
    asyncio.run(main())