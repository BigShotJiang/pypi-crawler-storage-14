#!/usr/bin/env python3
"""
Graph RAG Benchmarking Script

This script provides comprehensive benchmarking for the Graph RAG system,
measuring performance, accuracy, and scalability.
"""

import time
import asyncio
import statistics
from typing import Dict, List, Any, Optional, Tuple
import json
import os
from pathlib import Path

# Add src to path for imports
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from ailoos.rag.techniques.graph_rag import GraphRAG
from ailoos.rag.knowledge_graph.graph_builder import GraphBuilder
from ailoos.rag.knowledge_graph.graph_retriever import GraphRetriever
from ailoos.rag.knowledge_graph.result_aggregator import ResultAggregator


class GraphRAGBenchmark:
    """Benchmark suite for Graph RAG system."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize benchmark suite."""
        self.config = config or self._get_default_config()
        self.results = {}

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration for benchmarking."""
        return {
            'graph_config': {
                'uri': 'bolt://localhost:7687',
                'user': 'neo4j',
                'password': 'password',
                'database': 'neo4j'
            },
            'entity_patterns': {
                'Person': [r'\b[A-Z][a-z]+\s[A-Z][a-z]+\b'],
                'Organization': [r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b'],
                'Location': [r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b']
            },
            'relationship_patterns': {
                'WORKS_FOR': [r'works for', r'employed by'],
                'LOCATED_IN': [r'located in', r'situated in']
            },
            'aggregation_strategy': 'weighted_sum',
            'aggregation_weights': [0.6, 0.4]
        }

    def generate_test_data(self, num_documents: int = 100) -> List[Dict[str, Any]]:
        """Generate synthetic test data."""
        documents = []

        companies = ['Google', 'Microsoft', 'Apple', 'Amazon', 'Meta', 'Tesla', 'Netflix']
        locations = ['New York', 'San Francisco', 'Seattle', 'Austin', 'Boston', 'Chicago']
        roles = ['Engineer', 'Manager', 'Designer', 'Analyst', 'Developer', 'Architect']

        for i in range(num_documents):
            company = companies[i % len(companies)]
            location = locations[i % len(locations)]
            role = roles[i % len(roles)]

            content = f"""
            John Doe{i} is a {role} at {company}.
            He works in {location} and specializes in software development.
            {company} is located in {location} and is a technology company.
            """

            documents.append({
                'id': f'doc_{i}',
                'content': content.strip(),
                'title': f'Employee Profile {i}',
                'source': 'test_database',
                'metadata': {
                    'company': company,
                    'location': location,
                    'role': role
                }
            })

        return documents

    def benchmark_graph_construction(self, documents: List[Dict[str, Any]],
                                   num_runs: int = 3) -> Dict[str, Any]:
        """Benchmark graph construction performance."""
        print(f"🔧 Benchmarking graph construction with {len(documents)} documents...")

        construction_times = []

        for run in range(num_runs):
            print(f"  Run {run + 1}/{num_runs}...")

            start_time = time.time()

            # Create fresh builder for each run
            builder = GraphBuilder(self.config)

            try:
                builder.build_from_documents(documents)
                end_time = time.time()

                construction_time = end_time - start_time
                construction_times.append(construction_time)
                print(".2f")

            except Exception as e:
                print(f"    ❌ Error in run {run + 1}: {str(e)}")
                construction_times.append(float('inf'))

        # Calculate statistics
        valid_times = [t for t in construction_times if t != float('inf')]

        if valid_times:
            stats = {
                'mean_time': statistics.mean(valid_times),
                'median_time': statistics.median(valid_times),
                'min_time': min(valid_times),
                'max_time': max(valid_times),
                'std_dev': statistics.stdev(valid_times) if len(valid_times) > 1 else 0,
                'success_rate': len(valid_times) / num_runs,
                'documents_per_second': len(documents) / statistics.mean(valid_times)
            }
        else:
            stats = {'error': 'All runs failed'}

        print("  📊 Construction Stats:")
        print(f"    Mean time: {stats.get('mean_time', 'N/A'):.2f}s")
        print(f"    Documents/sec: {stats.get('documents_per_second', 'N/A'):.1f}")

        return stats

    def benchmark_retrieval(self, graph_rag: GraphRAG, queries: List[str],
                          num_runs: int = 5) -> Dict[str, Any]:
        """Benchmark retrieval performance."""
        print(f"🔍 Benchmarking retrieval with {len(queries)} queries...")

        all_response_times = []
        all_result_counts = []

        for query_idx, query in enumerate(queries):
            print(f"  Query {query_idx + 1}/{len(queries)}: '{query[:50]}...'")

            query_times = []

            for run in range(num_runs):
                start_time = time.time()

                try:
                    results = graph_rag.retrieve(query, top_k=10)
                    end_time = time.time()

                    response_time = end_time - start_time
                    query_times.append(response_time)
                    all_result_counts.append(len(results))

                    print(".3f")

                except Exception as e:
                    print(f"    ❌ Error in run {run + 1}: {str(e)}")
                    query_times.append(float('inf'))

            # Add valid times to overall stats
            valid_times = [t for t in query_times if t != float('inf')]
            all_response_times.extend(valid_times)

        # Calculate statistics
        if all_response_times:
            stats = {
                'mean_response_time': statistics.mean(all_response_times),
                'median_response_time': statistics.median(all_response_times),
                'min_response_time': min(all_response_times),
                'max_response_time': max(all_response_times),
                'std_dev_response_time': statistics.stdev(all_response_times) if len(all_response_times) > 1 else 0,
                'mean_results_count': statistics.mean(all_result_counts),
                'total_queries': len(queries),
                'successful_runs': len(all_response_times),
                'queries_per_second': len(queries) * num_runs / sum(all_response_times)
            }
        else:
            stats = {'error': 'All retrievals failed'}

        print("  📊 Retrieval Stats:")
        print(f"    Mean response time: {stats.get('mean_response_time', 'N/A'):.3f}s")
        print(f"    Queries/sec: {stats.get('queries_per_second', 'N/A'):.2f}")

        return stats

    def benchmark_aggregation_strategies(self, result_sets: List[List[Tuple[Dict[str, Any], float]]],
                                       strategies: List[str] = None) -> Dict[str, Any]:
        """Benchmark different aggregation strategies."""
        if strategies is None:
            strategies = ['weighted_sum', 'reciprocal_rank', 'diversity_aware']

        print(f"⚖️ Benchmarking {len(strategies)} aggregation strategies...")

        aggregator = ResultAggregator()
        weights = [0.5, 0.5]  # Equal weights for two result sets

        strategy_results = {}

        for strategy in strategies:
            print(f"  Testing {strategy}...")

            start_time = time.time()
            try:
                results = aggregator.aggregate_results(
                    result_sets=result_sets,
                    strategy=strategy,
                    weights=weights,
                    top_k=20
                )
                end_time = time.time()

                processing_time = end_time - start_time

                strategy_results[strategy] = {
                    'processing_time': processing_time,
                    'num_results': len(results),
                    'success': True
                }

                print(".4f")

            except Exception as e:
                strategy_results[strategy] = {
                    'error': str(e),
                    'success': False
                }
                print(f"    ❌ Error: {str(e)}")

        return strategy_results

    def run_comprehensive_benchmark(self, document_counts: List[int] = None,
                                  query_counts: List[int] = None) -> Dict[str, Any]:
        """Run comprehensive benchmark suite."""
        if document_counts is None:
            document_counts = [50, 100, 200]

        if query_counts is None:
            query_counts = [10, 20, 50]

        print("🚀 Starting comprehensive Graph RAG benchmark...")

        benchmark_results = {
            'timestamp': time.time(),
            'config': self.config,
            'construction_benchmarks': {},
            'retrieval_benchmarks': {},
            'aggregation_benchmarks': {}
        }

        # Test data generation
        print("\n📝 Generating test data...")
        test_documents = self.generate_test_data(max(document_counts))
        test_queries = [
            "Who works at Google?",
            "Where is Microsoft located?",
            "Find engineers in Seattle",
            "Show me people who work for Amazon",
            "What companies are in New York?",
            "Find managers at Apple",
            "Where do developers work?",
            "Show organizations in Boston",
            "Find people in San Francisco",
            "What roles exist at Tesla?"
        ] * 5  # Repeat for more queries

        # Construction benchmarks
        print("\n🏗️ Running construction benchmarks...")
        for num_docs in document_counts:
            docs = test_documents[:num_docs]
            benchmark_results['construction_benchmarks'][f'{num_docs}_documents'] = \
                self.benchmark_graph_construction(docs)

        # Setup Graph RAG for retrieval benchmarks
        print("\n🔧 Setting up Graph RAG for retrieval tests...")
        try:
            graph_rag = GraphRAG(self.config)
            graph_rag.build_graph_from_documents(test_documents[:100])  # Use 100 docs for retrieval

            # Retrieval benchmarks
            print("\n🔍 Running retrieval benchmarks...")
            for num_queries in query_counts:
                queries = test_queries[:num_queries]
                benchmark_results['retrieval_benchmarks'][f'{num_queries}_queries'] = \
                    self.benchmark_retrieval(graph_rag, queries)

        except Exception as e:
            print(f"❌ Error setting up Graph RAG: {str(e)}")
            benchmark_results['setup_error'] = str(e)

        # Aggregation benchmarks
        print("\n⚖️ Running aggregation benchmarks...")
        mock_result_sets = [
            [({'id': f'v{i}', 'content': f'Vector result {i}'}, 0.9 - i*0.05) for i in range(10)],
            [({'id': f'g{i}', 'content': f'Graph result {i}'}, 0.8 - i*0.04) for i in range(10)]
        ]

        benchmark_results['aggregation_benchmarks'] = \
            self.benchmark_aggregation_strategies(mock_result_sets)

        # Save results
        self.save_results(benchmark_results)

        print("\n✅ Benchmark completed!")
        return benchmark_results

    def save_results(self, results: Dict[str, Any], filename: str = None) -> None:
        """Save benchmark results to file."""
        if filename is None:
            timestamp = int(results['timestamp'])
            filename = f"graph_rag_benchmark_{timestamp}.json"

        output_dir = Path("benchmark_results")
        output_dir.mkdir(exist_ok=True)

        filepath = output_dir / filename

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

        print(f"💾 Results saved to {filepath}")


def main():
    """Main benchmark execution."""
    print("🎯 Graph RAG Benchmark Suite")
    print("=" * 50)

    # Check if Neo4j is available
    try:
        import neo4j
        print("✅ Neo4j driver available")
    except ImportError:
        print("⚠️ Neo4j driver not available - using mock implementations")

    # Check if spaCy is available
    try:
        import spacy
        print("✅ spaCy NLP available")
    except ImportError:
        print("⚠️ spaCy not available - entity extraction will be limited")

    # Run benchmarks
    benchmark = GraphRAGBenchmark()

    try:
        results = benchmark.run_comprehensive_benchmark(
            document_counts=[50, 100],
            query_counts=[10, 20]
        )

        # Print summary
        print("\n📊 Benchmark Summary:")
        print("-" * 30)

        if 'construction_benchmarks' in results:
            for key, stats in results['construction_benchmarks'].items():
                if 'mean_time' in stats:
                    print(f"Construction ({key}): {stats['mean_time']:.2f}s, "
                          f"{stats['documents_per_second']:.1f} docs/sec")

        if 'retrieval_benchmarks' in results:
            for key, stats in results['retrieval_benchmarks'].items():
                if 'mean_response_time' in stats:
                    print(f"Retrieval ({key}): {stats['mean_response_time']:.3f}s/query, "
                          f"{stats['queries_per_second']:.2f} queries/sec")

        print("\n🎉 Benchmark completed successfully!")

    except Exception as e:
        print(f"❌ Benchmark failed: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()