#!/usr/bin/env python3
"""
End-to-End Test for AILOOS Data Infrastructure
Tests the complete pipeline: IPFS + PII Scrubber + Dataset Manager
"""

import os
import sys
import json
import tempfile
import shutil
from pathlib import Path

# Add root to path
sys.path.append(os.getcwd())

from src.ailoos.data.ipfs_connector import ipfs_connector
from src.ailoos.privacy.pii_scrubber import pii_scrubber
from src.ailoos.data.dataset_manager import dataset_manager

def create_test_data():
    """Create test data with various types of PII."""
    test_data = {
        "text_file": """DOCUMENTO CONFIDENCIAL DE PRUEBA

Este documento contiene información sensible para validar el sistema de privacidad.

Usuario: Usuario Demo 1
Email: demo1@example.com
Teléfono: +34 666 123 456
DNI: 11111111A
Dirección IP: 192.168.1.100
Número de tarjeta: 4111-1111-1111-1111
Fecha de nacimiento: 15/05/1985

Otro usuario: Usuario Demo 2
Email: demo2@example.com
Teléfono: 555-987-6543
NIE: X1111111L
IP: 10.0.0.50

Información adicional sobre el proyecto de IA distribuida.
Esta es una prueba del sistema de sanitización PII.
El sistema debe detectar y eliminar toda la información personal.
""" + "Texto de relleno para probar sharding. " * 500,

        "json_dataset": [
            {
                "id": 1,
                "name": "Usuario Demo 1",
                "email": "demo1@example.com",
                "phone": "+34666123456",
                "dni": "11111111A",
                "ip": "192.168.1.100",
                "birth_date": "1985-05-15",
                "content": "Este es un registro de prueba con información personal."
            },
            {
                "id": 2,
                "name": "Usuario Demo 2",
                "email": "demo2@example.com",
                "phone": "555987654",
                "nie": "X1111111L",
                "ip": "10.0.0.50",
                "birth_date": "1990-03-22",
                "content": "Otro registro de prueba para validar sanitización."
            },
            {
                "id": 3,
                "name": "Usuario Demo 3",
                "email": "demo3@example.com",
                "phone": "+1-555-123-4567",
                "ssn": "111-22-3333",
                "ip": "172.16.0.25",
                "birth_date": "1978-11-30",
                "content": "Tercer registro sin información sensible adicional."
            }
        ]
    }
    return test_data

def test_pii_scrubber():
    """Test PII scrubber functionality."""
    print("🧹 TESTING PII SCRUBBER")
    print("-" * 40)

    test_data = create_test_data()

    # Test text scrubbing
    original_text = test_data["text_file"][:500]  # First 500 chars
    scrubbed_text = pii_scrubber.scrub_text(original_text)

    print(f"📄 Texto original (primeros 200 chars): {original_text[:200]}...")
    print(f"🛡️ Texto sanitizado (primeros 200 chars): {scrubbed_text[:200]}...")

    # Verify PII removal
    pii_detected = []
    if "demo1@example.com" not in scrubbed_text:
        pii_detected.append("email")
    if "11111111A" not in scrubbed_text:
        pii_detected.append("DNI")
    if "192.168.1.100" not in scrubbed_text:
        pii_detected.append("IP")
    if "+34 666 123 456" not in scrubbed_text:
        pii_detected.append("phone")

    print(f"✅ PII removida: {', '.join(pii_detected)}")

    # Test JSON scrubbing
    original_json = test_data["json_dataset"]
    scrubbed_json = pii_scrubber.scrub_dataset(original_json)

    print(f"📊 Dataset JSON original: {len(original_json)} registros")
    print(f"📊 Dataset JSON sanitizado: {len(scrubbed_json)} registros")

    # Check that sensitive fields are hashed/redacted
    sensitive_fields = ['email', 'phone', 'dni', 'nie', 'ssn', 'ip']
    for record in scrubbed_json:
        for field in sensitive_fields:
            if field in record:
                value = record[field]
                if value.startswith('SHA256:') or '[REDACTED]' in str(value):
                    print(f"✅ Campo {field} correctamente sanitizado")
                    break

    # Get stats
    stats = pii_scrubber.get_stats()
    print(f"📈 Estadísticas: {stats['pii_found']} PII encontrada, {stats['total_processed']} elementos procesados")

    return True

def test_ipfs_connector():
    """Test IPFS connector functionality."""
    print("\n🌐 TESTING IPFS CONNECTOR")
    print("-" * 40)

    # Test connection status
    print(f"🔗 Estado de conexión IPFS: {'Conectado' if ipfs_connector.connected else 'Desconectado'}")
    print(f"📡 Puede subir: {'Sí' if ipfs_connector.connected else 'No (solo lectura)'}")

    # Test JSON upload/download (simulated if no IPFS daemon)
    test_data = {
        "test": "data",
        "timestamp": "2024-01-01T00:00:00Z",
        "message": "Test IPFS functionality"
    }

    try:
        if ipfs_connector.connected:
            # Real IPFS test
            cid = ipfs_connector.add_json(test_data)
            print(f"📤 JSON subido a IPFS: {cid}")

            # Try to retrieve it
            retrieved = ipfs_connector.get_json(cid)
            if retrieved == test_data:
                print("✅ JSON recuperado correctamente")
            else:
                print("❌ Error en recuperación JSON")
        else:
            print("ℹ️ IPFS en modo gateway - probando descarga")
            # Try to download a known CID from gateway
            try:
                # Use a known test CID that should exist
                test_cid = "QmYwAPJzv5CZsnAztxH7ruuVvKrEf8H8Qz8j5VJJkhjf6"  # IPFS hello world
                data = ipfs_connector.get_bytes(test_cid)
                print(f"✅ Descarga desde gateway exitosa: {len(data)} bytes")
            except Exception as e:
                print(f"⚠️ No se pudo probar descarga desde gateway: {e}")

    except Exception as e:
        print(f"❌ Error en pruebas IPFS: {e}")

    # Get stats
    stats = ipfs_connector.get_stats()
    print(f"📊 Estadísticas IPFS: {stats}")

    return True

def test_dataset_manager():
    """Test dataset manager end-to-end."""
    print("\n📦 TESTING DATASET MANAGER")
    print("-" * 40)

    test_data = create_test_data()

    # Create temporary files
    with tempfile.TemporaryDirectory() as temp_dir:
        # Test text file processing
        text_file = Path(temp_dir) / "test_document.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write(test_data["text_file"])

        print(f"📄 Procesando archivo de texto: {text_file}")

        try:
            text_result = dataset_manager.process_text_file(
                file_path=str(text_file),
                dataset_name="test_text_dataset",
                shard_size_mb=0.01  # Small shards for testing
            )

            print("✅ Archivo de texto procesado exitosamente")
            print(f"   📊 Shards creados: {text_result['num_shards']}")
            print(f"   📏 Tamaño total: {text_result['total_size_mb']:.2f} MB")
            shard_cids = text_result.get('shard_cids', [])
            print(f"   🔗 CIDs generados: {len(shard_cids)}")

        except Exception as e:
            print(f"❌ Error procesando archivo de texto: {e}")
            return False

        # Test JSON dataset processing
        print("\n📊 Procesando dataset JSON...")
        try:
            json_result = dataset_manager.process_json_dataset(
                data=test_data["json_dataset"],
                dataset_name="test_json_dataset",
                metadata={"test": True, "source": "e2e_test"}
            )

            if json_result:
                print("✅ Dataset JSON procesado exitosamente")
                print(f"   📊 Shards creados: {json_result.get('num_shards', 0)}")
                print(f"   📏 Tamaño total: {json_result.get('total_size_mb', 0):.2f} MB")
                shard_cids = json_result.get('shard_cids', [])
                print(f"   🔗 CIDs generados: {len(shard_cids)}")
            else:
                print("⚠️ Dataset JSON procesado pero sin resultado detallado")

        except Exception as e:
            print(f"❌ Error procesando dataset JSON: {e}")
            import traceback
            traceback.print_exc()
            return False

        # Test dataset listing
        datasets = dataset_manager.list_datasets()
        print(f"\n📋 Datasets registrados: {len(datasets)}")
        for ds in datasets:
            if ds['dataset_name'].startswith('test_'):
                print(f"   📦 {ds['dataset_name']}: {ds['num_shards']} shards, {ds['total_size_mb']:.2f} MB")

    return True

def test_end_to_end_pipeline():
    """Test complete pipeline integration."""
    print("\n🔄 TESTING END-TO-END PIPELINE")
    print("-" * 40)

    test_data = create_test_data()

    # Create test file with PII
    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write(test_data["text_file"])
        test_file = f.name

    try:
        print("🚀 Ejecutando pipeline completo...")

        # 1. Process file (includes PII scrubbing internally)
        result = dataset_manager.process_text_file(
            file_path=test_file,
            dataset_name="e2e_test_dataset",
            shard_size_mb=0.01
        )

        print("✅ Pipeline completado exitosamente")
        print(f"   📦 Dataset: {result['dataset_name']}")
        print(f"   🛡️ PII Scrubbed: {result['pii_scrubbed']}")
        print(f"   📊 Shards: {result['num_shards']}")
        ipfs_stats = result.get('ipfs_stats', {})
        ipfs_mode = 'Usado' if ipfs_stats.get('connected', False) else 'Simulado'
        print(f"   🌐 IPFS: {ipfs_mode}")

        # 2. Verify PII was removed by checking a shard
        if result['shard_cids']:
            first_cid = result['shard_cids'][0]
            try:
                shard_data = ipfs_connector.get_json(first_cid)
                shard_content = shard_data.get('data', '')

                # Check for PII presence
                pii_found = []
                if any(email in shard_content for email in ['demo1@example.com', 'demo2@example.com']):
                    pii_found.append('emails')
                if '11111111A' in shard_content:
                    pii_found.append('DNI')
                if '192.168.1.100' in shard_content:
                    pii_found.append('IP addresses')

                if pii_found:
                    print(f"❌ PII encontrada en shard: {', '.join(pii_found)}")
                    return False
                else:
                    print("✅ No se encontró PII en los shards procesados")

            except Exception as e:
                print(f"⚠️ No se pudo verificar shard ({ipfs_connector.mode} mode): {e}")

        return True

    except Exception as e:
        print(f"❌ Error en pipeline end-to-end: {e}")
        return False

    finally:
        # Cleanup
        if os.path.exists(test_file):
            os.unlink(test_file)

def run_all_tests():
    """Run all infrastructure tests."""
    print("🏗️ AILOOS DATA INFRASTRUCTURE - END-TO-END TESTS")
    print("=" * 60)

    tests = [
        ("PII Scrubber", test_pii_scrubber),
        ("IPFS Connector", test_ipfs_connector),
        ("Dataset Manager", test_dataset_manager),
        ("End-to-End Pipeline", test_end_to_end_pipeline)
    ]

    results = []
    for test_name, test_func in tests:
        try:
            print(f"\n🧪 Running: {test_name}")
            success = test_func()
            results.append((test_name, success))
            status = "✅ PASSED" if success else "❌ FAILED"
            print(f"📋 {test_name}: {status}")
        except Exception as e:
            print(f"💥 {test_name}: CRASHED - {e}")
            results.append((test_name, False))

    # Summary
    print("\n" + "=" * 60)
    print("📊 TEST SUMMARY")
    print("=" * 60)

    passed = sum(1 for _, success in results if success)
    total = len(results)

    for test_name, success in results:
        status = "✅" if success else "❌"
        print(f"{status} {test_name}")

    print(f"\n🎯 Resultado: {passed}/{total} tests pasaron")

    if passed == total:
        print("🎉 ¡Todos los componentes de la infraestructura de datos funcionan correctamente!")
        return True
    else:
        print("⚠️ Algunos componentes necesitan atención.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)