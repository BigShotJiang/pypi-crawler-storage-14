#!/bin/bash

# AILOOS Production Deployment Script
# This script handles the complete deployment process to Google Cloud

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_ID="ailoos-oauth-473213"
REGION="europe-west1"
SERVICE_NAME="ailoos-api"
WEBSOCKET_SERVICE_NAME="ailoos-websocket"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_dependencies() {
    log_info "Checking dependencies..."

    # Check if gcloud is installed
    if ! command -v gcloud &> /dev/null; then
        log_error "gcloud CLI is not installed. Please install it first."
        exit 1
    fi

    # Check if terraform is installed
    if ! command -v terraform &> /dev/null; then
        log_error "Terraform is not installed. Please install it first."
        exit 1
    fi

    # Check if docker is installed
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed. Please install it first."
        exit 1
    fi

    log_success "All dependencies are installed"
}

authenticate_gcloud() {
    log_info "Authenticating with Google Cloud..."

    # Check if already authenticated
    if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
        log_warning "Not authenticated with Google Cloud. Please run:"
        echo "gcloud auth login"
        echo "gcloud config set project $PROJECT_ID"
        exit 1
    fi

    # Set project
    gcloud config set project $PROJECT_ID

    log_success "Authenticated with Google Cloud"
}

setup_infrastructure() {
    log_info "Setting up infrastructure with Terraform..."

    cd infrastructure/production

    # Initialize Terraform
    terraform init

    # Validate configuration
    terraform validate

    # Plan deployment
    terraform plan -out=tfplan

    # Ask for confirmation
    read -p "Do you want to apply the Terraform changes? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Deployment cancelled"
        exit 0
    fi

    # Apply changes
    terraform apply tfplan

    cd ../..

    log_success "Infrastructure setup completed"
}

build_and_push_image() {
    log_info "Building and pushing Docker image..."

    # Build image
    docker build -t gcr.io/$PROJECT_ID/ailoos-api:latest -f Dockerfile .

    # Push to GCR
    docker push gcr.io/$PROJECT_ID/ailoos-api:latest

    log_success "Docker image built and pushed"
}

deploy_to_cloud_run() {
    log_info "Deploying to Cloud Run..."

    # Deploy API service
    gcloud run deploy $SERVICE_NAME \
        --image gcr.io/$PROJECT_ID/ailoos-api:latest \
        --platform managed \
        --region $REGION \
        --allow-unauthenticated \
        --port 8000 \
        --memory 1Gi \
        --cpu 1 \
        --max-instances 10 \
        --min-instances 1 \
        --set-env-vars ENVIRONMENT=production \
        --set-secrets DATABASE_URL=DATABASE_URL:latest \
        --set-secrets JWT_SECRET=JWT_SECRET:latest

    # Get service URL
    SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")
    log_success "API deployed to: $SERVICE_URL"
}

setup_domain_mapping() {
    log_info "Setting up domain mapping..."

    # Map custom domain to Cloud Run service
    gcloud run domain-mappings create \
        --service $SERVICE_NAME \
        --domain api.ailoos.com \
        --region $REGION

    log_success "Domain mapping configured"
}

run_health_check() {
    log_info "Running health checks..."

    SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format="value(status.url)")

    # Wait for service to be ready
    for i in {1..30}; do
        if curl -f -s "$SERVICE_URL/health" > /dev/null; then
            log_success "Health check passed"
            return 0
        fi
        log_info "Waiting for service to be healthy... ($i/30)"
        sleep 10
    done

    log_error "Health check failed"
    exit 1
}

deploy_frontend() {
    log_info "Deploying frontend..."

    cd frontend

    # Install dependencies
    npm install

    # Build for production
    npm run build

    # Deploy to Vercel (assuming Vercel CLI is configured)
    if command -v vercel &> /dev/null; then
        vercel --prod
        log_success "Frontend deployed to Vercel"
    else
        log_warning "Vercel CLI not found. Please deploy frontend manually."
        log_info "Run: cd frontend && npm run build && deploy to your hosting provider"
    fi

    cd ..
}

setup_monitoring() {
    log_info "Setting up monitoring and alerting..."

    # Create Cloud Monitoring dashboard
    gcloud monitoring dashboards create \
        --config-from-file=infrastructure/monitoring/dashboard.json \
        --project=$PROJECT_ID

    # Create alerting policies
    gcloud alpha monitoring policies create \
        --policy-from-file=infrastructure/monitoring/alerts.json \
        --project=$PROJECT_ID

    log_success "Monitoring and alerting configured"
}

main() {
    echo "🚀 AILOOS Production Deployment Script"
    echo "====================================="
    echo

    # Parse command line arguments
    case "${1:-all}" in
        "check")
            check_dependencies
            ;;
        "auth")
            authenticate_gcloud
            ;;
        "infra")
            check_dependencies
            authenticate_gcloud
            setup_infrastructure
            ;;
        "build")
            check_dependencies
            authenticate_gcloud
            build_and_push_image
            ;;
        "deploy")
            check_dependencies
            authenticate_gcloud
            deploy_to_cloud_run
            run_health_check
            ;;
        "domain")
            check_dependencies
            authenticate_gcloud
            setup_domain_mapping
            ;;
        "frontend")
            deploy_frontend
            ;;
        "monitor")
            check_dependencies
            authenticate_gcloud
            setup_monitoring
            ;;
        "all")
            check_dependencies
            authenticate_gcloud
            setup_infrastructure
            build_and_push_image
            deploy_to_cloud_run
            setup_domain_mapping
            run_health_check
            deploy_frontend
            setup_monitoring
            log_success "🎉 Complete deployment finished!"
            ;;
        *)
            echo "Usage: $0 {check|auth|infra|build|deploy|domain|frontend|monitor|all}"
            echo
            echo "Commands:"
            echo "  check    - Check dependencies"
            echo "  auth     - Authenticate with Google Cloud"
            echo "  infra    - Setup infrastructure with Terraform"
            echo "  build    - Build and push Docker image"
            echo "  deploy   - Deploy to Cloud Run"
            echo "  domain   - Setup domain mapping"
            echo "  frontend - Deploy frontend"
            echo "  monitor  - Setup monitoring"
            echo "  all      - Run complete deployment"
            exit 1
            ;;
    esac
}

# Run main function
main "$@"