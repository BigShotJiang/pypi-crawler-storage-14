#!/usr/bin/env python3
"""
Script de prueba para el PerformanceReportGenerator
Integra con AccuracyComparisonFramework para generar reportes reales.
"""

import os
import sys
import json
from pathlib import Path

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.benchmarking.performance_report_generator import PerformanceReportGenerator, generate_performance_report
from ailoos.benchmarking.accuracy_comparison_framework import create_accuracy_comparison_framework, run_accuracy_comparison


def test_with_mock_data():
    """Prueba con datos simulados."""
    print("🧪 Probando PerformanceReportGenerator con datos simulados")

    # Crear datos simulados similares a los del framework
    mock_data = {
        'comprehensive_metrics': {
            'empoorio': {
                'model_name': 'empoorio',
                'accuracy_mmlu': 0.785,
                'accuracy_gsm8k': 0.723,
                'accuracy_overall': 0.754,
                'avg_latency': 0.45,
                'p95_latency': 0.89,
                'total_energy_joules': 12.3,
                'joules_per_token': 0.023,
                'rag_accuracy': 0.812,
                'efficiency_score': 2.45,
                'sample_count': 150,
                'evaluation_timestamp': '2025-11-25T18:00:00'
            },
            'gpt4': {
                'model_name': 'gpt4',
                'accuracy_mmlu': 0.876,
                'accuracy_gsm8k': 0.892,
                'accuracy_overall': 0.884,
                'avg_latency': 1.23,
                'p95_latency': 2.45,
                'total_energy_joules': 45.6,
                'joules_per_token': 0.089,
                'rag_accuracy': 0.945,
                'efficiency_score': 1.12,
                'sample_count': 150,
                'evaluation_timestamp': '2025-11-25T18:00:00'
            },
            'claude': {
                'model_name': 'claude',
                'accuracy_mmlu': 0.834,
                'accuracy_gsm8k': 0.856,
                'accuracy_overall': 0.845,
                'avg_latency': 0.98,
                'p95_latency': 1.87,
                'total_energy_joules': 38.9,
                'joules_per_token': 0.076,
                'rag_accuracy': 0.898,
                'efficiency_score': 1.34,
                'sample_count': 150,
                'evaluation_timestamp': '2025-11-25T18:00:00'
            },
            'gemini': {
                'model_name': 'gemini',
                'accuracy_mmlu': 0.798,
                'accuracy_gsm8k': 0.812,
                'accuracy_overall': 0.805,
                'avg_latency': 0.76,
                'p95_latency': 1.45,
                'total_energy_joules': 32.1,
                'joules_per_token': 0.062,
                'rag_accuracy': 0.867,
                'efficiency_score': 1.67,
                'sample_count': 150,
                'evaluation_timestamp': '2025-11-25T18:00:00'
            }
        },
        'statistical_comparisons': [
            {
                'model_a': 'empoorio',
                'model_b': 'gpt4',
                'metric': 'accuracy_overall',
                'mean_a': 0.754,
                'mean_b': 0.884,
                'difference': -0.13,
                'relative_difference': -0.147,
                'p_value': 0.0012,
                'significant': True,
                'effect_size': -1.45
            }
        ],
        'market_headlines': [
            {
                'headline': 'EmpoorioLM 2.7x más eficiente energéticamente que GPT-4',
                'metric': 'energy',
                'model': 'empoorio',
                'competitor': 'gpt4',
                'improvement': 2.7,
                'significance': 'estadísticamente significativo'
            }
        ]
    }

    # Crear generador y cargar datos
    generator = PerformanceReportGenerator()
    generator.load_comparison_data(mock_data)

    # Generar reportes
    try:
        generated_files = generator.generate_comprehensive_report()

        print("✅ Reportes generados exitosamente:")
        for file_type, file_path in generated_files.items():
            print(f"  📄 {file_type.upper()}: {file_path}")

        return True

    except Exception as e:
        print(f"❌ Error generando reportes: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_with_real_framework():
    """Prueba integrando con el AccuracyComparisonFramework real."""
    print("🔬 Probando integración con AccuracyComparisonFramework real")

    try:
        # Crear framework de comparación
        framework = create_accuracy_comparison_framework(
            models=['empoorio', 'gpt4'],
            output_dir='./test_comparison_results'
        )

        # Ejecutar comparación (esto puede tomar tiempo)
        print("🚀 Ejecutando comparación comprehensiva (esto puede tomar varios minutos)...")
        results = framework.run_comprehensive_comparison()

        if results:
            print(f"✅ Comparación completada. Modelos evaluados: {list(results.keys())}")

            # Crear generador de reportes
            generator = PerformanceReportGenerator()
            generator.load_comparison_data({
                'comprehensive_metrics': {k: v.__dict__ for k, v in results.items()},
                'statistical_comparisons': [comp.__dict__ for comp in framework.statistical_comparisons],
                'market_headlines': [h.__dict__ for h in framework.market_headlines]
            })

            # Generar reportes
            generated_files = generator.generate_comprehensive_report()

            print("✅ Reportes generados exitosamente:")
            for file_type, file_path in generated_files.items():
                print(f"  📄 {file_type.upper()}: {file_path}")

            return True

        else:
            print("⚠️ No se obtuvieron resultados de la comparación")
            return False

    except Exception as e:
        print(f"❌ Error en integración real: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Función principal."""
    print("🚀 Test del PerformanceReportGenerator")
    print("=" * 50)

    # Crear directorio de salida
    os.makedirs('./test_reports', exist_ok=True)

    # Prueba 1: Datos simulados
    print("\n📊 PRUEBA 1: Datos simulados")
    success_mock = test_with_mock_data()

    # Prueba 2: Framework real (opcional, puede ser lento)
    if '--real' in sys.argv:
        print("\n🔬 PRUEBA 2: Framework real")
        success_real = test_with_real_framework()
    else:
        print("\n💡 Para probar con framework real, ejecuta: python test_performance_report_generator.py --real")
        success_real = None

    # Resumen
    print("\n" + "=" * 50)
    print("📋 RESUMEN DE PRUEBAS")
    print(f"✅ Datos simulados: {'PASÓ' if success_mock else 'FALLÓ'}")

    if success_real is not None:
        print(f"✅ Framework real: {'PASÓ' if success_real else 'FALLÓ'}")
    else:
        print("⏭️ Framework real: NO EJECUTADO")

    if success_mock:
        print("\n📁 Reportes generados en: ./performance_reports/")
        print("📄 Abre performance_report.html en tu navegador para ver el resultado")


if __name__ == "__main__":
    main()