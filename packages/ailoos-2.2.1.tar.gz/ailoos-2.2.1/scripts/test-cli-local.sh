#!/bin/bash

# Test AILOOS CLI locally before publishing to npm
# This installs the CLI from the local tarball

echo "🧪 Testing AILOOS CLI locally..."
echo ""

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 14+ first:"
    echo "   https://nodejs.org/"
    exit 1
fi

# Check if Python is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+ first:"
    echo "   https://python.org/"
    exit 1
fi

# Check if AILOOS Python SDK is installed
if ! python3 -c "import ailoos; print('OK')" &> /dev/null; then
    echo "❌ AILOOS Python SDK not found. Installing..."
    pip install ailoos
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install AILOOS Python SDK"
        exit 1
    fi
fi

echo "✅ Prerequisites check passed"
echo ""

# Create the package tarball
echo "📦 Creating CLI package..."
cd ailoos-cli
npm pack
cd ..
echo ""

# Install from local tarball
echo "📦 Installing CLI from local package..."
TARBALL_PATH="$(pwd)/ailoos-cli/ailoos-cli-2.1.2.tgz"

if command -v npm &> /dev/null; then
    echo "Using npm..."
    npm install -g "$TARBALL_PATH"
    EXEC_CMD="npx ailoos-cli"
elif command -v pnpm &> /dev/null; then
    echo "Using pnpm..."
    pnpm add -g "$TARBALL_PATH"
    EXEC_CMD="pnpm dlx ailoos-cli"
else
    echo "❌ No package manager found"
    exit 1
fi

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Installation successful!"
    echo ""
    echo "🚀 Test the CLI:"
    echo "   $EXEC_CMD"
    echo ""
    echo "📚 Available commands:"
    echo "   $EXEC_CMD --help"
    echo ""
    echo "🧪 Quick test (will show interface for 5 seconds):"
    echo "   timeout 5s $EXEC_CMD || true"
else
    echo ""
    echo "❌ Installation failed"
    exit 1
fi