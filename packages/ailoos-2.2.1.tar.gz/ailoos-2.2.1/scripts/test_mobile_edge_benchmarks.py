#!/usr/bin/env python3
"""
Script de ejemplo para probar los benchmarks de edge móvil de EmpoorioLM.
Demuestra cómo usar el módulo mobile_edge_benchmarks.py directamente.
"""

import os
import sys
import time

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Import del módulo de benchmarks móviles
from ailoos.benchmarking.mobile_edge_benchmarks import (
    MobileEdgeBenchmarkRunner, MobileEdgeBenchmarkConfig,
    run_mobile_vs_cloud_comparison, create_mobile_edge_benchmark_runner
)

# Import de ejemplo del EmpoorioLM wrapper (mock para desarrollo)
try:
    from ailoos.api.empoorio_api import EmpoorioLMApi, EmpoorioLMApiConfig, GenerationConfig
    EMPOORIO_AVAILABLE = True
except ImportError:
    EMPOORIO_AVAILABLE = False
    print("⚠️ EmpoorioLM no disponible, usando mock")

# Mock wrapper para desarrollo (siempre disponible)
class MockEmpoorioWrapper:
    def __init__(self):
        self.model_name = "EmpoorioLM-Mock"

    def generate(self, prompt, **kwargs):
        import time
        time.sleep(0.05)  # Simular latencia
        response = f"Respuesta mock para: {prompt[:50]}..."
        return response, {
            'latency': 0.05,
            'tokens_generated': len(response.split()),
            'success': True
        }


def test_basic_mobile_edge_benchmarks():
    """Prueba básica de benchmarks de edge móvil."""
    print("🚀 Probando benchmarks básicos de edge móvil...")

    # Crear configuración
    config = MobileEdgeBenchmarkConfig(
        target_devices=['pixel_7', 'iphone_14'],
        num_requests=10,  # Pocos para prueba rápida
        output_dir='./test_mobile_edge_results'
    )

    # Crear runner
    runner = MobileEdgeBenchmarkRunner(config)

    # Crear wrapper del modelo (mock si no está disponible)
    if EMPOORIO_AVAILABLE:
        # Configuración real de EmpoorioLM
        api_config = EmpoorioLMApiConfig()
        model_wrapper = EmpoorioLMApi(api_config)
    else:
        model_wrapper = MockEmpoorioWrapper()

    # Ejecutar benchmarks
    results = runner.run_mobile_edge_benchmarks(
        model_wrapper, "empoorio", model_size_mb=100.0
    )

    # Generar reportes
    runner.generate_edge_reports()

    # Mostrar resumen
    print("\n📊 Resumen de resultados:")
    for device, metrics in results.items():
        print(f"\n📱 {device.upper()}:")
        print(f"  ⏱️  Latencia: {metrics.avg_latency_ms:.2f} ms")
        print(f"  🔋 Batería: {metrics.battery_consumption_mah:.1f} mAh")
        print(f"  🧠 Memoria: {metrics.peak_memory_mb:.0f} MB")
        print(f"  🚀 Throughput: {metrics.throughput_tokens_per_sec:.1f} tokens/s")
        print(f"  ☁️  Speedup vs Nube: {metrics.edge_vs_cloud_speedup:.1f}x")
        print(f"  💰 Ahorro energético: {metrics.edge_vs_cloud_energy_savings:.1f}%")

    print(f"\n📁 Resultados guardados en: {config.output_dir}")
    return results


def test_mobile_vs_cloud_comparison():
    """Prueba de comparación entre edge móvil y nube."""
    print("\n☁️ Probando comparación edge vs nube...")

    # Crear wrapper del modelo
    if EMPOORIO_AVAILABLE:
        api_config = EmpoorioLMApiConfig()
        model_wrapper = EmpoorioLMApi(api_config)
    else:
        model_wrapper = MockEmpoorioWrapper()

    # Ejecutar comparación
    comparison = run_mobile_vs_cloud_comparison(
        model_wrapper, "empoorio", model_size_mb=100.0,
        devices=['pixel_7', 'iphone_14']
    )

    # Mostrar resultados
    print("\n📊 Resultados de comparación:")
    print(f"Modelo: {comparison['model_name']}")
    print(f"Tamaño del modelo: {comparison['model_size_mb']} MB")
    print(f"Mejor dispositivo: {comparison['best_device']}")
    print(f"Speedup promedio: {comparison['avg_speedup']:.1f}x")
    print(f"Ahorro energético promedio: {comparison['avg_energy_savings']:.1f}%")

    return comparison


def test_different_devices():
    """Prueba con diferentes dispositivos móviles."""
    print("\n📱 Probando diferentes dispositivos móviles...")

    devices_to_test = ['pixel_7', 'pixel_8', 'iphone_14', 'iphone_15', 'samsung_s22']

    # Crear configuración
    config = MobileEdgeBenchmarkConfig(
        target_devices=devices_to_test,
        num_requests=5,  # Muy pocos para prueba rápida
        output_dir='./test_devices_results'
    )

    runner = MobileEdgeBenchmarkRunner(config)

    # Wrapper mock para prueba rápida
    model_wrapper = MockEmpoorioWrapper()

    # Ejecutar benchmarks
    results = runner.run_mobile_edge_benchmarks(
        model_wrapper, "empoorio", model_size_mb=50.0
    )

    # Mostrar comparación rápida
    print("\n📊 Comparación de dispositivos:")
    print("Dispositivo".ljust(15), "Latencia(ms)".ljust(12), "Batería(mAh)".ljust(12), "Memoria(MB)".ljust(12))
    print("-" * 55)

    for device, metrics in results.items():
        print(f"{device:<15}"
              f"{metrics.avg_latency_ms:>12.1f}"
              f"{metrics.battery_consumption_mah:>12.1f}"
              f"{metrics.peak_memory_mb:>12.0f}")

    return results


def main():
    """Función principal."""
    print("🧪 Test Suite para Mobile Edge Benchmarks")
    print("=" * 50)

    start_time = time.time()

    try:
        # Ejecutar pruebas
        test_basic_mobile_edge_benchmarks()
        test_mobile_vs_cloud_comparison()
        test_different_devices()

        end_time = time.time()
        print(f"\n✅ Todas las pruebas completadas en {end_time - start_time:.2f} segundos")

    except Exception as e:
        print(f"❌ Error durante las pruebas: {e}")
        import traceback
        traceback.print_exc()

    print("\n💡 Para usar con modelos reales:")
    print("1. Instala EmpoorioLM correctamente")
    print("2. Configura las APIs necesarias")
    print("3. Ejecuta: python test_mobile_edge_benchmarks.py")


if __name__ == "__main__":
    main()