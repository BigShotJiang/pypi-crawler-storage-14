#!/usr/bin/env python3
"""
Test Básico del Sistema de Workflows - FASE 9
===========================================

Test simplificado que demuestra la funcionalidad core del WorkflowEngine.
"""

import asyncio
import sys
from pathlib import Path

# Añadir el directorio raíz al path
script_dir = Path(__file__).parent
root_dir = script_dir.parent
sys.path.insert(0, str(root_dir))

from src.ailoos.workflows.engine import WorkflowEngine, WorkflowStep
from src.ailoos.workflows.templates import DOCUMENT_ANALYSIS_TEMPLATE
from src.ailoos.models.empoorio_lm.expert_system import create_expert_manager
from src.ailoos.inference.api import InferenceConfig, EmpoorioLMInferenceAPI


async def test_basic_workflow():
    """Test básico del workflow engine."""
    print("🧪 TEST BÁSICO: Workflow Engine")
    print("=" * 40)

    try:
        # Inicializar componentes
        expert_manager = create_expert_manager("models/experts")
        inference_config = InferenceConfig()
        inference_api = EmpoorioLMInferenceAPI(inference_config)
        engine = WorkflowEngine(expert_manager, inference_api)

        # Crear workflow simple
        steps = [
            WorkflowStep(
                step_id="vision_test",
                step_type="vision",
                description="Extraer texto de imagen",
                config={"extraction_mode": "ocr"}
            ),
            WorkflowStep(
                step_id="validation_test",
                step_type="validation",
                description="Validar resultado",
                config={"required_fields": ["extracted_text"]},
                dependencies=["vision_test"]
            )
        ]

        # Ejecutar
        result = await engine.execute_workflow("test_workflow_001", steps, {"image_path": "test.jpg"})

        print(f"✅ Workflow ejecutado: {'Éxito' if result.success else 'Falló'}")
        print(f"   Tiempo: {result.execution_time:.2f}s")
        print(f"   Pasos completados: {len(result.steps_executed)}")

        if result.final_output:
            print(f"   Output final: {type(result.final_output)}")

        return result.success

    except Exception as e:
        print(f"❌ Error: {e}")
        return False


async def test_template_instantiation():
    """Test de instanciación de templates."""
    print("\n📋 TEST: Instanciación de Templates")
    print("=" * 40)

    try:
        # Instanciar template
        template = DOCUMENT_ANALYSIS_TEMPLATE
        steps = template.instantiate({"domain": "legal"})

        print(f"✅ Template '{template.name}' instanciado")
        print(f"   Pasos generados: {len(steps)}")
        for step in steps:
            print(f"   - {step.step_id} ({step.step_type})")

        return True

    except Exception as e:
        print(f"❌ Error: {e}")
        return False


async def main():
    """Función principal."""
    print("🚀 TEST DEL SISTEMA DE WORKFLOWS - FASE 9")
    print("=" * 50)

    # Test 1: Workflow básico
    success1 = await test_basic_workflow()

    # Test 2: Templates
    success2 = await test_template_instantiation()

    # Resultado
    print("\n" + "=" * 50)
    print("📊 RESULTADOS:")
    print(f"Workflow Engine: {'✅ OK' if success1 else '❌ Falló'}")
    print(f"Templates: {'✅ OK' if success2 else '❌ Falló'}")

    if success1 and success2:
        print("\n🎉 SISTEMA DE WORKFLOWS OPERATIVO")
        print("✅ FASE 9: Workflows Multimodales - BASE VALIDADA")
    else:
        print("\n⚠️ SISTEMA CON OBSERVACIONES")

    print("=" * 50)


if __name__ == "__main__":
    asyncio.run(main())