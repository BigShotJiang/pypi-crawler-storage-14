#!/usr/bin/env python3
"""
AILOOS Benchmark CI/CD Runner
Ejecuta todos los benchmarks de manera automatizada para CI/CD.
"""

import os
import sys
import json
import time
import logging
import argparse
from typing import Dict, List, Any, Optional
from pathlib import Path
import asyncio
import subprocess

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.benchmarking.energy_tracker import EnergyTracker, EnergyTrackerConfig
from ailoos.benchmarking.latency_tester import LatencyTester
from ailoos.benchmarking.accuracy_comparison_framework import AccuracyComparisonFramework
from ailoos.benchmarking.mobile_edge_benchmarks import MobileEdgeBenchmarks
from ailoos.benchmarking.rag_needle_evaluator import RAGNeedleEvaluator
from ailoos.benchmarking.competitive_analysis_report import CompetitiveAnalysisReport

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('/app/benchmark_results/ci_benchmark.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


class BenchmarkCIOrchestrator:
    """Orquestador principal para benchmarks en CI/CD."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.results_dir = Path(config.get('results_dir', '/app/benchmark_results'))
        self.results_dir.mkdir(exist_ok=True)

        # Configurar energy tracker
        energy_config = EnergyTrackerConfig(
            enable_codecarbon=config.get('enable_energy_tracking', True),
            enable_gpu_monitoring=config.get('enable_gpu_monitoring', False),
            tracking_interval_seconds=config.get('energy_tracking_interval', 1.0),
            output_dir=str(self.results_dir / 'energy_logs')
        )
        self.energy_tracker = EnergyTracker(energy_config)

        logger.info("🚀 Benchmark CI Orchestrator initialized")

    async def run_accuracy_benchmarks(self) -> Dict[str, Any]:
        """Ejecutar benchmarks de precisión."""
        logger.info("🎯 Running accuracy benchmarks...")

        try:
            framework = AccuracyComparisonFramework()

            results = await framework.run_comprehensive_accuracy_test(
                num_samples=self.config.get('num_samples', 50),
                models_to_test=self.config.get('models_to_test', ['empoorio']),
                datasets=self.config.get('datasets', ['mmlu', 'gsm8k'])
            )

            # Guardar resultados
            output_file = self.results_dir / 'accuracy_benchmark_results.json'
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)

            logger.info(f"✅ Accuracy benchmarks completed. Results saved to {output_file}")
            return results

        except Exception as e:
            logger.error(f"❌ Error in accuracy benchmarks: {e}")
            return {"error": str(e), "benchmark_type": "accuracy"}

    async def run_latency_benchmarks(self) -> Dict[str, Any]:
        """Ejecutar benchmarks de latencia."""
        logger.info("⚡ Running latency benchmarks...")

        try:
            tester = LatencyTester()

            results = await tester.run_comprehensive_latency_test(
                num_requests=self.config.get('latency_num_requests', 100),
                context_sizes=self.config.get('latency_context_sizes', [512, 1024, 2048]),
                batch_sizes=self.config.get('latency_batch_sizes', [1, 2, 4])
            )

            # Guardar resultados
            output_file = self.results_dir / 'latency_benchmark_results.json'
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)

            logger.info(f"✅ Latency benchmarks completed. Results saved to {output_file}")
            return results

        except Exception as e:
            logger.error(f"❌ Error in latency benchmarks: {e}")
            return {"error": str(e), "benchmark_type": "latency"}

    async def run_energy_benchmarks(self) -> Dict[str, Any]:
        """Ejecutar benchmarks de eficiencia energética."""
        logger.info("🔋 Running energy efficiency benchmarks...")

        try:
            # Simular workload de benchmark con tracking de energía
            self.energy_tracker.start_monitoring()

            # Ejecutar un benchmark representativo (accuracy benchmark)
            accuracy_results = await self.run_accuracy_benchmarks()

            # Calcular métricas de energía
            tokens_generated = sum(
                result.get('tokens_generated', 0)
                for result in accuracy_results.values()
                if isinstance(result, dict)
            )

            accuracy_avg = sum(
                result.get('accuracy', 0.0)
                for result in accuracy_results.values()
                if isinstance(result, dict)
            ) / len([r for r in accuracy_results.values() if isinstance(r, dict)])

            metrics = self.energy_tracker.stop_monitoring(
                tokens_generated=tokens_generated,
                accuracy=accuracy_avg
            )

            # Convertir métricas a dict para JSON
            energy_results = {
                'total_energy_joules': metrics.total_energy_joules,
                'carbon_emissions_kg': metrics.carbon_emissions_kg,
                'joules_per_token': metrics.joules_per_token,
                'tokens_per_watt': metrics.tokens_per_watt,
                'intelligence_per_watt': metrics.intelligence_per_watt,
                'power_consumption_watts': metrics.power_consumption_watts,
                'avg_power_draw': metrics.avg_power_draw,
                'peak_power_draw': metrics.peak_power_draw,
                'duration_seconds': metrics.duration_seconds,
                'system_info': metrics.system_info,
                'tokens_generated': tokens_generated,
                'average_accuracy': accuracy_avg
            }

            # Guardar resultados
            output_file = self.results_dir / 'energy_benchmark_results.json'
            with open(output_file, 'w') as f:
                json.dump(energy_results, f, indent=2)

            logger.info(f"✅ Energy benchmarks completed. Results saved to {output_file}")
            return energy_results

        except Exception as e:
            logger.error(f"❌ Error in energy benchmarks: {e}")
            return {"error": str(e), "benchmark_type": "energy"}

    async def run_mobile_edge_benchmarks(self) -> Dict[str, Any]:
        """Ejecutar benchmarks mobile edge."""
        logger.info("📱 Running mobile edge benchmarks...")

        try:
            benchmarks = MobileEdgeBenchmarks()

            results = await benchmarks.run_comprehensive_mobile_edge_test(
                num_samples=self.config.get('num_samples', 50),
                device_configs=self.config.get('mobile_device_configs', ['cpu', 'mock_gpu'])
            )

            # Guardar resultados
            output_file = self.results_dir / 'mobile_edge_benchmark_results.json'
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)

            logger.info(f"✅ Mobile edge benchmarks completed. Results saved to {output_file}")
            return results

        except Exception as e:
            logger.error(f"❌ Error in mobile edge benchmarks: {e}")
            return {"error": str(e), "benchmark_type": "mobile_edge"}

    async def run_rag_benchmarks(self) -> Dict[str, Any]:
        """Ejecutar benchmarks RAG."""
        logger.info("🧠 Running RAG benchmarks...")

        try:
            evaluator = RAGNeedleEvaluator()

            results = await evaluator.run_comprehensive_rag_evaluation(
                num_samples=self.config.get('rag_num_samples', 50),
                needle_sizes=self.config.get('rag_needle_sizes', ['small', 'medium', 'large']),
                context_lengths=self.config.get('rag_context_lengths', [1000, 2000, 4000])
            )

            # Guardar resultados
            output_file = self.results_dir / 'rag_benchmark_results.json'
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2)

            logger.info(f"✅ RAG benchmarks completed. Results saved to {output_file}")
            return results

        except Exception as e:
            logger.error(f"❌ Error in RAG benchmarks: {e}")
            return {"error": str(e), "benchmark_type": "rag"}

    async def run_all_benchmarks(self) -> Dict[str, Any]:
        """Ejecutar todos los benchmarks."""
        logger.info("🚀 Starting comprehensive benchmark suite...")

        start_time = time.time()
        all_results = {}

        benchmark_types = self.config.get('benchmark_types', ['accuracy', 'latency', 'energy', 'mobile_edge', 'rag'])

        for benchmark_type in benchmark_types:
            logger.info(f"📊 Running {benchmark_type} benchmarks...")

            if benchmark_type == 'accuracy':
                all_results['accuracy'] = await self.run_accuracy_benchmarks()
            elif benchmark_type == 'latency':
                all_results['latency'] = await self.run_latency_benchmarks()
            elif benchmark_type == 'energy':
                all_results['energy'] = await self.run_energy_benchmarks()
            elif benchmark_type == 'mobile_edge':
                all_results['mobile_edge'] = await self.run_mobile_edge_benchmarks()
            elif benchmark_type == 'rag':
                all_results['rag'] = await self.run_rag_benchmarks()

            # Pequeña pausa entre benchmarks
            await asyncio.sleep(1)

        # Calcular tiempo total
        total_time = time.time() - start_time
        all_results['metadata'] = {
            'total_execution_time_seconds': total_time,
            'benchmark_types_executed': benchmark_types,
            'config': self.config,
            'timestamp': time.time(),
            'environment': dict(os.environ)
        }

        # Guardar resultados completos
        output_file = self.results_dir / 'comprehensive_benchmark_results.json'
        with open(output_file, 'w') as f:
            json.dump(all_results, f, indent=2)

        logger.info(f"✅ All benchmarks completed in {total_time:.2f} seconds. Results saved to {output_file}")

        # Limpiar recursos
        self.energy_tracker.cleanup()

        return all_results

    def generate_summary_report(self, results: Dict[str, Any]) -> str:
        """Generar reporte resumen de los benchmarks."""
        summary = []
        summary.append("# 🚀 AILOOS Benchmark CI/CD Results Summary")
        summary.append("")

        if 'metadata' in results:
            metadata = results['metadata']
            summary.append(f"**Total Execution Time:** {metadata['total_execution_time_seconds']:.2f} seconds")
            summary.append(f"**Benchmark Types:** {', '.join(metadata['benchmark_types_executed'])}")
            summary.append("")

        # Resumen por tipo de benchmark
        for benchmark_type, benchmark_results in results.items():
            if benchmark_type == 'metadata':
                continue

            summary.append(f"## {benchmark_type.upper()} Benchmarks")

            if isinstance(benchmark_results, dict) and 'error' not in benchmark_results:
                # Métricas específicas por tipo
                if benchmark_type == 'accuracy':
                    if 'overall_accuracy' in benchmark_results:
                        summary.append(f"- **Overall Accuracy:** {benchmark_results['overall_accuracy']:.3f}")
                    if 'models_compared' in benchmark_results:
                        summary.append(f"- **Models Compared:** {len(benchmark_results['models_compared'])}")

                elif benchmark_type == 'latency':
                    if 'avg_latency_ms' in benchmark_results:
                        summary.append(f"- **Average Latency:** {benchmark_results['avg_latency_ms']:.2f} ms")
                    if 'p95_latency_ms' in benchmark_results:
                        summary.append(f"- **P95 Latency:** {benchmark_results['p95_latency_ms']:.2f} ms")

                elif benchmark_type == 'energy':
                    if 'total_energy_joules' in benchmark_results:
                        summary.append(f"- **Total Energy:** {benchmark_results['total_energy_joules']:.2f} J")
                    if 'joules_per_token' in benchmark_results:
                        summary.append(f"- **Joules per Token:** {benchmark_results['joules_per_token']:.4f}")
                    if 'carbon_emissions_kg' in benchmark_results:
                        summary.append(f"- **Carbon Emissions:** {benchmark_results['carbon_emissions_kg']:.6f} kg CO2")

                elif benchmark_type == 'mobile_edge':
                    if 'avg_inference_time_ms' in benchmark_results:
                        summary.append(f"- **Avg Inference Time:** {benchmark_results['avg_inference_time_ms']:.2f} ms")
                    if 'model_size_mb' in benchmark_results:
                        summary.append(f"- **Model Size:** {benchmark_results['model_size_mb']:.2f} MB")

                elif benchmark_type == 'rag':
                    if 'avg_retrieval_accuracy' in benchmark_results:
                        summary.append(f"- **Avg Retrieval Accuracy:** {benchmark_results['avg_retrieval_accuracy']:.3f}")
                    if 'avg_generation_quality' in benchmark_results:
                        summary.append(f"- **Avg Generation Quality:** {benchmark_results['avg_generation_quality']:.3f}")
            else:
                summary.append("❌ Benchmark failed or returned no valid results")

            summary.append("")

        return "\n".join(summary)


async def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='AILOOS Benchmark CI/CD Runner')
    parser.add_argument('--config-file', type=str, default='/app/scripts/benchmark_config_ci.json',
                       help='Path to benchmark configuration file')
    parser.add_argument('--benchmark-types', nargs='+',
                       choices=['accuracy', 'latency', 'energy', 'mobile_edge', 'rag', 'all'],
                       default=['all'], help='Types of benchmarks to run')
    parser.add_argument('--num-samples', type=int, default=50,
                       help='Number of samples for benchmarks')
    parser.add_argument('--results-dir', type=str, default='/app/benchmark_results',
                       help='Directory to save results')
    parser.add_argument('--enable-energy-tracking', action='store_true', default=True,
                       help='Enable energy consumption tracking')
    parser.add_argument('--enable-gpu-monitoring', action='store_true', default=False,
                       help='Enable GPU monitoring (if available)')

    args = parser.parse_args()

    # Cargar configuración
    config = {
        'benchmark_types': args.benchmark_types if 'all' not in args.benchmark_types else ['accuracy', 'latency', 'energy', 'mobile_edge', 'rag'],
        'num_samples': args.num_samples,
        'results_dir': args.results_dir,
        'enable_energy_tracking': args.enable_energy_tracking,
        'enable_gpu_monitoring': args.enable_gpu_monitoring,
        'latency_num_requests': 100,
        'latency_context_sizes': [512, 1024, 2048],
        'latency_batch_sizes': [1, 2, 4],
        'rag_num_samples': args.num_samples,
        'rag_needle_sizes': ['small', 'medium', 'large'],
        'rag_context_lengths': [1000, 2000, 4000],
        'models_to_test': ['empoorio'],  # Solo modelo local para CI
        'datasets': ['mmlu', 'gsm8k'],
        'mobile_device_configs': ['cpu']
    }

    # Si existe archivo de configuración, cargarlo y mergear
    if os.path.exists(args.config_file):
        with open(args.config_file, 'r') as f:
            file_config = json.load(f)
        config.update(file_config)
        logger.info(f"Loaded configuration from {args.config_file}")

    # Crear orquestador y ejecutar benchmarks
    orchestrator = BenchmarkCIOrchestrator(config)

    try:
        results = await orchestrator.run_all_benchmarks()

        # Generar reporte resumen
        summary_report = orchestrator.generate_summary_report(results)

        # Guardar reporte
        summary_file = Path(args.results_dir) / 'benchmark_summary.md'
        with open(summary_file, 'w') as f:
            f.write(summary_report)

        logger.info(f"📊 Benchmark summary saved to {summary_file}")

        # Imprimir resumen en consola
        print("\n" + "="*80)
        print(summary_report)
        print("="*80)

        return 0

    except Exception as e:
        logger.error(f"❌ Benchmark execution failed: {e}")
        return 1

    finally:
        orchestrator.energy_tracker.cleanup()


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)