#!/bin/bash

# AILOOS Frontend Deployment Script for Vercel
# Despliega el frontend en Vercel con configuración automática

set -e

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Función de logging
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

success() {
    echo -e "${GREEN}✅ $1${NC}"
}

error() {
    echo -e "${RED}❌ $1${NC}"
}

warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Función de ayuda
usage() {
    echo "Uso: $0 [OPTIONS]"
    echo ""
    echo "Despliega el frontend de AILOOS en Vercel"
    echo ""
    echo "OPTIONS:"
    echo "  -e, --environment ENV    Ambiente (staging|production) [default: staging]"
    echo "  -b, --backend-config FILE Archivo de configuración del backend [default: backend_config_staging.json]"
    echo "  -p, --project-name NAME   Nombre del proyecto en Vercel [default: ailoos]"
    echo "  -t, --team TEAM           Equipo de Vercel (opcional)"
    echo "  -s, --skip-env            Saltar configuración de variables de entorno"
    echo "  -h, --help                Mostrar esta ayuda"
    echo ""
    echo "Ejemplos:"
    echo "  $0 --environment production"
    echo "  $0 -e staging -b backend_config_production.json"
}

# Valores por defecto
ENVIRONMENT="staging"
BACKEND_CONFIG="backend_config_staging.json"
PROJECT_NAME="ailoos"
TEAM=""
SKIP_ENV=false

# Parsear argumentos
while [[ $# -gt 0 ]]; do
    case $1 in
        -e|--environment)
            ENVIRONMENT="$2"
            BACKEND_CONFIG="backend_config_$2.json"
            shift 2
            ;;
        -b|--backend-config)
            BACKEND_CONFIG="$2"
            shift 2
            ;;
        -p|--project-name)
            PROJECT_NAME="$2"
            shift 2
            ;;
        -t|--team)
            TEAM="$2"
            shift 2
            ;;
        -s|--skip-env)
            SKIP_ENV=true
            shift
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            error "Opción desconocida: $1"
            usage
            exit 1
            ;;
    esac
done

# Validar ambiente
if [[ "$ENVIRONMENT" != "staging" && "$ENVIRONMENT" != "production" ]]; then
    error "Ambiente inválido: $ENVIRONMENT. Debe ser 'staging' o 'production'"
    exit 1
fi

log "🚀 Iniciando despliegue del frontend AILOOS"
log "Ambiente: $ENVIRONMENT"
log "Proyecto Vercel: $PROJECT_NAME"
log "Configuración backend: $BACKEND_CONFIG"

# Verificar instalación de Vercel CLI
if ! command -v vercel &> /dev/null; then
    error "Vercel CLI no está instalado. Instálalo con: npm i -g vercel"
    exit 1
fi

# Verificar autenticación en Vercel
log "Verificando autenticación en Vercel..."
if ! vercel whoami &> /dev/null; then
    warning "No estás autenticado en Vercel. Ejecutando vercel login..."
    vercel login
fi

# Cambiar al directorio del frontend
log "Cambiando al directorio del frontend..."
cd frontend

# Verificar que estamos en el directorio correcto
if [[ ! -f "package.json" ]]; then
    error "No se encuentra package.json. Asegúrate de estar en el directorio del frontend"
    exit 1
fi

# Función para configurar CORS en vercel.json
configure_cors() {
    log "Configurando CORS en vercel.json..."

    local cors_origin
    if [[ "$ENVIRONMENT" == "production" ]]; then
        cors_origin="https://api.ailoos.com"
    else
        cors_origin="https://api-staging.ailoos.com"
    fi

    # Actualizar vercel.json con el origen CORS correcto
    if command -v jq &> /dev/null; then
        jq --arg origin "$cors_origin" '.headers[0].headers[0].value = $origin' vercel.json > vercel.json.tmp && mv vercel.json.tmp vercel.json
        success "CORS configurado para origen: $cors_origin"
    else
        warning "jq no está instalado. CORS configurado con origen por defecto."
    fi
}
# Configurar CORS
configure_cors

# Verificar configuración del backend
if [[ "$SKIP_ENV" == false ]]; then
    if [[ ! -f "../$BACKEND_CONFIG" ]]; then
        warning "Archivo de configuración del backend no encontrado: ../$BACKEND_CONFIG"
        warning "Usando configuración por defecto. Ejecuta primero el despliegue del backend"
        BACKEND_CONFIG=""
    else
        log "Cargando configuración del backend desde $BACKEND_CONFIG..."
        # Leer configuración del backend
        if command -v jq &> /dev/null; then
            GATEWAY_URL=$(jq -r '.gateway_url' "../$BACKEND_CONFIG")
            GCP_PROJECT_ID=$(jq -r '.project_id' "../$BACKEND_CONFIG")
            GCP_REGION=$(jq -r '.region' "../$BACKEND_CONFIG")
        else
            # Fallback si no hay jq
            GATEWAY_URL=$(grep '"gateway_url"' "../$BACKEND_CONFIG" | sed 's/.*"gateway_url": "\([^"]*\)".*/\1/')
            GCP_PROJECT_ID=$(grep '"project_id"' "../$BACKEND_CONFIG" | sed 's/.*"project_id": "\([^"]*\)".*/\1/')
            GCP_REGION=$(grep '"region"' "../$BACKEND_CONFIG" | sed 's/.*"region": "\([^"]*\)".*/\1/')
        fi

        success "Configuración del backend cargada"
        log "Gateway URL: $GATEWAY_URL"
    fi
fi


# Función para configurar variables de entorno
set_env_vars() {
    local env_file="../.env.$ENVIRONMENT"

    log "Configurando variables de entorno para $ENVIRONMENT..."

    # Configurar variables de entorno usando un archivo temporal
    local env_file="/tmp/vercel_env_$ENVIRONMENT.json"

    # Crear archivo JSON con las variables de entorno
    cat > "$env_file" << EOF
{
  "NODE_ENV": "$ENVIRONMENT",
  "ENVIRONMENT": "$ENVIRONMENT"
EOF

    # Agregar variables del backend si están disponibles
    if [[ -n "$GATEWAY_URL" ]]; then
        cat >> "$env_file" << EOF
,
  "NEXT_PUBLIC_API_URL": "$GATEWAY_URL",
  "NEXT_PUBLIC_COORDINATOR_API_URL": "$GATEWAY_URL",
  "NEXT_PUBLIC_FEDERATED_API_URL": "$GATEWAY_URL",
  "NEXT_PUBLIC_MARKETPLACE_API_URL": "$GATEWAY_URL",
  "NEXT_PUBLIC_WALLET_API_URL": "$GATEWAY_URL",
  "NEXT_PUBLIC_EMPOORIO_API_URL": "$GATEWAY_URL",
  "NEXT_PUBLIC_SETTINGS_API_URL": "$GATEWAY_URL",
  "API_BASE_URL": "$GATEWAY_URL"
EOF
    fi

    # WebSocket URL
    if [[ -n "$GATEWAY_URL" ]]; then
        local ws_url="${GATEWAY_URL/http/ws}"
        ws_url="${ws_url/https/wss}"
        cat >> "$env_file" << EOF
,
  "NEXT_PUBLIC_WEBSOCKET_URL": "$ws_url"
EOF
    fi

    if [[ -n "$GCP_PROJECT_ID" ]]; then
        cat >> "$env_file" << EOF
,
  "GCP_PROJECT_ID": "$GCP_PROJECT_ID"
EOF
    fi

    if [[ -n "$GCP_REGION" ]]; then
        cat >> "$env_file" << EOF
,
  "GCP_REGION": "$GCP_REGION"
EOF
    fi

    # Variables adicionales para producción
    if [[ "$ENVIRONMENT" == "production" ]]; then
        cat >> "$env_file" << EOF
,
  "NEXT_PUBLIC_APP_ENV": "production",
  "NEXT_PUBLIC_APP_NAME": "AILOOS",
  "NEXT_PUBLIC_APP_VERSION": "1.0.0",
  "NEXT_PUBLIC_ANALYTICS_ENABLED": "true",
  "NEXT_PUBLIC_ENABLE_HTTPS": "true",
  "NEXT_PUBLIC_ENABLE_PWA": "true",
  "NEXT_PUBLIC_ENABLE_SERVICE_WORKER": "true",
  "NEXT_PUBLIC_ENABLE_FEDERATED_LEARNING": "true",
  "NEXT_PUBLIC_ENABLE_MARKETPLACE": "true",
  "NEXT_PUBLIC_ENABLE_WALLET": "true",
  "NEXT_PUBLIC_ENABLE_ANALYTICS": "true",
  "NEXT_PUBLIC_ENABLE_IPFS": "true"
EOF
    fi

    # Cerrar JSON
    echo "}" >> "$env_file"

    # Importar variables desde JSON
    vercel env import "$env_file"

    # Limpiar archivo temporal
    rm -f "$env_file"

    # Variables críticas que deben estar configuradas manualmente
    local required_vars=("AUTH_SECRET" "DATABASE_URL" "BLOB_READ_WRITE_TOKEN" "AI_GATEWAY_API_KEY" "NEXTAUTH_SECRET" "GOOGLE_CLIENT_ID" "GOOGLE_CLIENT_SECRET")

    log "Verificando variables requeridas..."
    for var in "${required_vars[@]}"; do
        if ! vercel env ls | grep -q "^$var"; then
            warning "Variable requerida no configurada: $var"
            warning "Configúrala manualmente en Vercel Dashboard o ejecuta:"
            echo "  vercel env add $var"
        fi
    done
}

# Configurar variables de entorno si no se salta
if [[ "$SKIP_ENV" == false ]]; then
    set_env_vars
else
    warning "Saltando configuración de variables de entorno (--skip-env)"
fi

# Construir opciones de despliegue
DEPLOY_OPTIONS="--prod"

if [[ "$ENVIRONMENT" == "staging" ]]; then
    DEPLOY_OPTIONS=""
fi

if [[ -n "$TEAM" ]]; then
    DEPLOY_OPTIONS="$DEPLOY_OPTIONS --team $TEAM"
fi

# Desplegar a Vercel
log "🚀 Desplegando a Vercel ($ENVIRONMENT)..."
log "Comando: vercel $DEPLOY_OPTIONS"

# Ejecutar despliegue
if [[ "$ENVIRONMENT" == "production" ]]; then
    # Despliegue a producción
    DEPLOY_URL=$(vercel --prod 2>&1 | grep -o 'https://[^ ]*\.vercel\.app')
else
    # Despliegue a staging/preview
    DEPLOY_URL=$(vercel 2>&1 | grep -o 'https://[^ ]*\.vercel\.app')
fi

if [[ -z "$DEPLOY_URL" ]]; then
    error "No se pudo obtener la URL de despliegue"
    exit 1
fi

success "Frontend desplegado exitosamente"
log "URL de despliegue: $DEPLOY_URL"

# Función para verificar CORS
verify_cors() {
    log "Verificando configuración CORS..."

    # Verificar headers CORS en una ruta API
    local api_url="$DEPLOY_URL/api/health"  # Asumiendo que hay una ruta /api/health

    local cors_headers=$(curl -s -I -H "Origin: https://ailoos.com" "$api_url" 2>/dev/null | grep -i "access-control")

    if [[ -n "$cors_headers" ]]; then
        success "CORS configurado correctamente"
        echo "$cors_headers"
    else
        warning "No se detectaron headers CORS. Verifica la configuración en vercel.json"
    fi
}

# Verificar despliegue
log "Verificando despliegue..."
max_attempts=30
attempt=1

while [[ $attempt -le $max_attempts ]]; do
    log "Intento $attempt de $max_attempts..."

    if curl -f -s "$DEPLOY_URL" > /dev/null 2>&1; then
        success "Despliegue verificado exitosamente"
        break
    fi

    if [[ $attempt -eq $max_attempts ]]; then
        error "El despliegue no está respondiendo después de $max_attempts intentos"
        exit 1
    fi

    sleep 10
    ((attempt++))
done

# Verificar CORS después del despliegue
verify_cors

# Configurar dominio personalizado si es producción
if [[ "$ENVIRONMENT" == "production" ]]; then
    log "Configurando dominio personalizado para producción..."

    # Intentar agregar dominio ailoos.com
    if vercel domains add ailoos.com 2>/dev/null; then
        success "Dominio ailoos.com agregado"
    else
        warning "No se pudo agregar dominio ailoos.com (puede que ya esté configurado)"
    fi
fi

# Mostrar resumen del despliegue
log "📋 Resumen del despliegue del frontend:"
echo ""
echo "Ambiente: $ENVIRONMENT"
echo "Proyecto Vercel: $PROJECT_NAME"
echo "URL de despliegue: $DEPLOY_URL"
if [[ "$ENVIRONMENT" == "production" ]]; then
    echo "Dominio personalizado: https://ailoos.dev"
fi
echo ""
echo "Variables de entorno configuradas:"
vercel env ls | grep -E "(AUTH_SECRET|DATABASE_URL|BLOB_READ_WRITE_TOKEN|AI_GATEWAY_API_KEY|NEXT_PUBLIC_API_URL)" | head -10
echo ""

success "🎉 Despliegue del frontend completado exitosamente!"

# Recomendaciones post-despliegue
warning "Próximos pasos recomendados:"
echo "1. Verifica que todas las funcionalidades funcionen correctamente"
echo "2. Configura monitoring en Vercel Analytics"
echo "3. Revisa los logs de despliegue en Vercel Dashboard"
if [[ "$ENVIRONMENT" == "production" ]]; then
    echo "4. Actualiza DNS si es necesario para el dominio personalizado"
fi
echo "5. Ejecuta tests de integración: ./scripts/integration_test_production.sh"