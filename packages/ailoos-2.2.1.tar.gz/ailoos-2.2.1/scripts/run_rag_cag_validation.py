#!/usr/bin/env python3
"""
Pipeline completo de validación Fase IA 1: RAG + CAG en EmpoorioLM.

Este script ejecuta todos los benchmarks de validación en secuencia:
1. Medición de cache hit rate
2. Medición de latencia de inferencia (con/sin cache)
3. Comparación de rendimiento general
4. Cálculo de costos ahorrados
5. Generación de reporte consolidado

Uso:
    python scripts/run_rag_cag_validation.py --full_pipeline --output_dir reports/fase_ia1
"""

import argparse
import asyncio
import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class RAGCAGValidationPipeline:
    """Pipeline completo de validación para RAG + CAG con EmpoorioLM."""

    def __init__(self, config: Dict[str, Any]):
        """
        Inicializar el pipeline.

        Args:
            config: Configuración del pipeline
        """
        self.config = config
        self.results = {
            'pipeline_config': config,
            'execution_log': [],
            'benchmark_results': {},
            'consolidated_report': {},
            'timestamp': datetime.now().isoformat()
        }

    def log_execution(self, step: str, status: str, details: str = ""):
        """Registrar ejecución de paso."""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'step': step,
            'status': status,
            'details': details
        }
        self.results['execution_log'].append(log_entry)
        logger.info(f"[{status}] {step}: {details}")

    async def run_benchmark(self, script_name: str, args: List[str]) -> bool:
        """Ejecutar un script de benchmark."""
        script_path = Path(__file__).parent / script_name

        if not script_path.exists():
            self.log_execution(script_name, "ERROR", f"Script no encontrado: {script_path}")
            return False

        # Construir comando
        cmd = [sys.executable, str(script_path)] + args

        try:
            self.log_execution(script_name, "STARTING", f"Ejecutando: {' '.join(cmd)}")

            # Ejecutar script
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.config.get('script_timeout', 300)  # 5 minutos timeout
            )

            if result.returncode == 0:
                self.log_execution(script_name, "SUCCESS", "Ejecución exitosa")
                logger.info(f"Output: {result.stdout[-500:]}...")  # Últimos 500 chars
                return True
            else:
                self.log_execution(script_name, "FAILED",
                                 f"Error {result.returncode}: {result.stderr[-500:]}")
                return False

        except subprocess.TimeoutExpired:
            self.log_execution(script_name, "TIMEOUT", f"Timeout después de {self.config['script_timeout']}s")
            return False
        except Exception as e:
            self.log_execution(script_name, "ERROR", str(e))
            return False

    async def run_cache_hit_rate_benchmark(self) -> bool:
        """Ejecutar benchmark de cache hit rate."""
        args = [
            '--num_queries', str(self.config.get('num_queries', 50)),
            '--similarity_threshold', str(self.config.get('similarity_threshold', 0.8)),
            '--cache_max_size', str(self.config.get('cache_max_size', 1000)),
            '--num_repetitions', str(self.config.get('num_repetitions', 3)),
            '--model_path', self.config.get('model_path', './models/empoorio_lm/v1.0.0'),
            '--output_file', str(self.config['output_dir'] / 'cache_hit_rate_results.json'),
            '--eviction_policy', self.config.get('eviction_policy', 'LRU')
        ]

        return await self.run_benchmark('measure_cache_hit_rate.py', args)

    async def run_inference_latency_benchmark(self) -> bool:
        """Ejecutar benchmark de latencia de inferencia."""
        args = [
            '--num_queries', str(self.config.get('num_queries', 50)),
            '--warmup_queries', str(self.config.get('warmup_queries', 5)),
            '--similarity_threshold', str(self.config.get('similarity_threshold', 0.8)),
            '--cache_max_size', str(self.config.get('cache_max_size', 1000)),
            '--model_path', self.config.get('model_path', './models/empoorio_lm/v1.0.0'),
            '--output_file', str(self.config['output_dir'] / 'inference_latency_results.json'),
            '--eviction_policy', self.config.get('eviction_policy', 'LRU')
        ]

        return await self.run_benchmark('measure_inference_latency.py', args)

    async def run_performance_comparison_benchmark(self) -> bool:
        """Ejecutar benchmark de comparación de rendimiento."""
        test_types = self.config.get('test_types', 'latency,hit_rate,quality')

        args = [
            '--test_types', test_types,
            '--num_queries', str(self.config.get('num_queries', 30)),
            '--similarity_threshold', str(self.config.get('similarity_threshold', 0.8)),
            '--cache_max_size', str(self.config.get('cache_max_size', 1000)),
            '--model_path', self.config.get('model_path', './models/empoorio_lm/v1.0.0'),
            '--output_file', str(self.config['output_dir'] / 'rag_performance_comparison.json'),
            '--eviction_policy', self.config.get('eviction_policy', 'LRU')
        ]

        return await self.run_benchmark('compare_rag_performance.py', args)

    async def run_cost_savings_calculation(self) -> bool:
        """Ejecutar cálculo de costos ahorrados."""
        args = [
            '--benchmark_results_dir', str(self.config['output_dir']),
            '--cost_model', self.config.get('cost_model', 'all'),
            '--monthly_queries', str(self.config.get('monthly_queries', 100000)),
            '--avg_tokens_per_query', str(self.config.get('avg_tokens_per_query', 200)),
            '--cache_size_gb', str(self.config.get('cache_size_gb', 1.0)),
            '--development_hours', str(self.config.get('development_hours', 40)),
            '--hourly_developer_rate', str(self.config.get('hourly_developer_rate', 75.0)),
            '--output_file', str(self.config['output_dir'] / 'cost_savings_report.json')
        ]

        return await self.run_benchmark('calculate_cost_savings.py', args)

    def load_benchmark_results(self) -> Dict[str, Any]:
        """Cargar resultados de todos los benchmarks."""
        results_files = {
            'cache_hit_rate': self.config['output_dir'] / 'cache_hit_rate_results.json',
            'inference_latency': self.config['output_dir'] / 'inference_latency_results.json',
            'performance_comparison': self.config['output_dir'] / 'rag_performance_comparison.json',
            'cost_savings': self.config['output_dir'] / 'cost_savings_report.json'
        }

        loaded_results = {}

        for name, file_path in results_files.items():
            if file_path.exists():
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        loaded_results[name] = json.load(f)
                    logger.info(f"Resultados cargados: {name}")
                except Exception as e:
                    logger.warning(f"Error cargando {file_path}: {e}")
            else:
                logger.warning(f"Archivo no encontrado: {file_path}")

        return loaded_results

    def generate_consolidated_report(self, benchmark_results: Dict[str, Any]):
        """Generar reporte consolidado."""
        report = {
            'titulo': 'REPORTE DE VALIDACIÓN - FASE IA 1: RAG + CAG en EmpoorioLM',
            'fecha_generacion': datetime.now().isoformat(),
            'configuracion_pipeline': self.config,
            'resumen_ejecucion': self.generate_execution_summary(),
            'resultados_consolidados': {},
            'conclusiones': {},
            'recomendaciones': []
        }

        # Consolidar métricas clave
        consolidated = self.consolidate_key_metrics(benchmark_results)
        report['resultados_consolidados'] = consolidated

        # Generar conclusiones
        conclusions = self.generate_conclusions(consolidated)
        report['conclusiones'] = conclusions

        # Generar recomendaciones
        recommendations = self.generate_recommendations(consolidated)
        report['recomendaciones'] = recommendations

        self.results['consolidated_report'] = report
        return report

    def generate_execution_summary(self) -> Dict[str, Any]:
        """Generar resumen de ejecución."""
        log_entries = self.results['execution_log']

        summary = {
            'total_steps': len(log_entries),
            'successful_steps': len([e for e in log_entries if e['status'] == 'SUCCESS']),
            'failed_steps': len([e for e in log_entries if e['status'] in ['FAILED', 'ERROR', 'TIMEOUT']]),
            'execution_time_total': 0
        }

        if log_entries:
            start_time = datetime.fromisoformat(log_entries[0]['timestamp'])
            end_time = datetime.fromisoformat(log_entries[-1]['timestamp'])
            summary['execution_time_total'] = (end_time - start_time).total_seconds()

        summary['success_rate'] = (
            summary['successful_steps'] / summary['total_steps'] * 100
            if summary['total_steps'] > 0 else 0
        )

        return summary

    def consolidate_key_metrics(self, benchmark_results: Dict[str, Any]) -> Dict[str, Any]:
        """Consolidar métricas clave de todos los benchmarks."""
        consolidated = {
            'cache_performance': {},
            'latency_performance': {},
            'quality_metrics': {},
            'cost_savings': {}
        }

        # Cache performance
        if 'cache_hit_rate' in benchmark_results:
            chr_data = benchmark_results['cache_hit_rate']
            metrics = chr_data.get('metrics', {})
            consolidated['cache_performance'] = {
                'hit_rate': metrics.get('cache_hit_rate', 0),
                'total_queries': metrics.get('total_queries', 0),
                'cache_hits': metrics.get('cache_hits', 0),
                'cache_misses': metrics.get('cache_misses', 0)
            }

        # Latency performance
        if 'inference_latency' in benchmark_results:
            latency_data = benchmark_results['inference_latency']
            comparison = latency_data.get('comparison', {})
            consolidated['latency_performance'] = {
                'latency_improvement_percent': comparison.get('latency_improvement_percent', 0),
                'throughput_improvement_percent': comparison.get('throughput_improvement_percent', 0),
                'cache_benefit_score': comparison.get('cache_benefit_score', 0)
            }

        # Quality metrics
        if 'performance_comparison' in benchmark_results:
            perf_data = benchmark_results['performance_comparison']
            summary = perf_data.get('summary', {})
            consolidated['quality_metrics'] = {
                'key_findings': summary.get('key_findings', []),
                'total_tests_run': summary.get('total_tests_run', 0)
            }

        # Cost savings
        if 'cost_savings' in benchmark_results:
            cost_data = benchmark_results['cost_savings']
            analysis = cost_data.get('savings_analysis', {})
            consolidated['cost_savings'] = {
                'recommended_model': analysis.get('recommended_model'),
                'highest_savings_model': analysis.get('highest_savings_model'),
                'average_roi': analysis.get('average_roi', 0),
                'total_potential_savings': analysis.get('total_potential_savings', 0)
            }

        return consolidated

    def generate_conclusions(self, consolidated: Dict[str, Any]) -> Dict[str, Any]:
        """Generar conclusiones basadas en métricas consolidadas."""
        conclusions = {
            'cache_effectiveness': self.evaluate_cache_effectiveness(consolidated),
            'performance_impact': self.evaluate_performance_impact(consolidated),
            'cost_benefit': self.evaluate_cost_benefit(consolidated),
            'overall_recommendation': self.generate_overall_recommendation(consolidated)
        }

        return conclusions

    def evaluate_cache_effectiveness(self, consolidated: Dict[str, Any]) -> str:
        """Evaluar efectividad del sistema de cache."""
        cache_perf = consolidated.get('cache_performance', {})
        hit_rate = cache_perf.get('hit_rate', 0)

        if hit_rate >= 0.8:
            return "EXCELENTE: El sistema de cache muestra una tasa de aciertos muy alta (>80%)"
        elif hit_rate >= 0.6:
            return "BUENA: El sistema de cache tiene una tasa de aciertos aceptable (60-80%)"
        elif hit_rate >= 0.4:
            return "REGULAR: El sistema de cache tiene una tasa de aciertos moderada (40-60%)"
        else:
            return "DEFICIENTE: El sistema de cache requiere optimización (<40% hit rate)"

    def evaluate_performance_impact(self, consolidated: Dict[str, Any]) -> str:
        """Evaluar impacto en rendimiento."""
        latency_perf = consolidated.get('latency_performance', {})
        latency_improvement = latency_perf.get('latency_improvement_percent', 0)
        throughput_improvement = latency_perf.get('throughput_improvement_percent', 0)

        if latency_improvement > 50 and throughput_improvement > 50:
            return "EXCELENTE: Mejoras significativas en latencia y throughput"
        elif latency_improvement > 25 or throughput_improvement > 25:
            return "BUENA: Mejoras notables en rendimiento"
        elif latency_improvement > 10 or throughput_improvement > 10:
            return "MODERADA: Mejoras limitadas en rendimiento"
        else:
            return "LIMITADA: Impacto mínimo en rendimiento"

    def evaluate_cost_benefit(self, consolidated: Dict[str, Any]) -> str:
        """Evaluar beneficio costo."""
        cost_savings = consolidated.get('cost_savings', {})
        avg_roi = cost_savings.get('average_roi', 0)

        if avg_roi > 200:
            return "EXCELENTE: ROI muy alto justifica ampliamente la implementación"
        elif avg_roi > 100:
            return "BUENO: ROI positivo con buen retorno de inversión"
        elif avg_roi > 50:
            return "ACEPTABLE: ROI moderado, beneficios a medio plazo"
        else:
            return "LIMITADO: ROI bajo, revisar viabilidad económica"

    def generate_overall_recommendation(self, consolidated: Dict[str, Any]) -> str:
        """Generar recomendación general."""
        cache_score = self.get_score_from_evaluation(
            self.evaluate_cache_effectiveness(consolidated)
        )
        performance_score = self.get_score_from_evaluation(
            self.evaluate_performance_impact(consolidated)
        )
        cost_score = self.get_score_from_evaluation(
            self.evaluate_cost_benefit(consolidated)
        )

        avg_score = (cache_score + performance_score + cost_score) / 3

        if avg_score >= 4:
            return "IMPLEMENTAR INMEDIATAMENTE: Excelentes resultados en todas las métricas"
        elif avg_score >= 3:
            return "IMPLEMENTAR CON SEGUIMIENTO: Buenos resultados generales"
        elif avg_score >= 2:
            return "EVALUAR OPTIMIZACIONES: Resultados moderados, considerar mejoras"
        else:
            return "RECONSIDERAR IMPLEMENTACIÓN: Resultados insuficientes"

    def get_score_from_evaluation(self, evaluation: str) -> int:
        """Convertir evaluación textual a puntuación numérica."""
        score_map = {
            'EXCELENTE': 5,
            'BUENA': 4,
            'BUENO': 4,
            'MODERADA': 3,
            'REGULAR': 3,
            'ACEPTABLE': 3,
            'LIMITADA': 2,
            'LIMITADO': 2,
            'DEFICIENTE': 1
        }

        for key, score in score_map.items():
            if key in evaluation.upper():
                return score
        return 1

    def generate_recommendations(self, consolidated: Dict[str, Any]) -> List[str]:
        """Generar lista de recomendaciones."""
        recommendations = []

        # Recomendaciones basadas en cache performance
        cache_perf = consolidated.get('cache_performance', {})
        hit_rate = cache_perf.get('hit_rate', 0)

        if hit_rate < 0.5:
            recommendations.append(
                "Optimizar configuración del cache: Considerar aumentar umbral de similitud o tamaño del cache"
            )
        elif hit_rate > 0.8:
            recommendations.append(
                "Cache funcionando óptimamente: Mantener configuración actual"
            )

        # Recomendaciones basadas en rendimiento
        latency_perf = consolidated.get('latency_performance', {})
        latency_improvement = latency_perf.get('latency_improvement_percent', 0)

        if latency_improvement < 20:
            recommendations.append(
                "Investigar cuellos de botella: Latencia de mejora limitada, revisar configuración del modelo"
            )

        # Recomendaciones basadas en costos
        cost_savings = consolidated.get('cost_savings', {})
        avg_roi = cost_savings.get('average_roi', 0)

        if avg_roi > 150:
            recommendations.append(
                "Expandir implementación: Altos retornos justifican expansión a más casos de uso"
            )
        elif avg_roi < 50:
            recommendations.append(
                "Revisar modelo de costos: ROI bajo, considerar ajustes en estimaciones"
            )

        # Recomendaciones generales
        recommendations.extend([
            "Monitoreo continuo: Implementar métricas en producción para seguimiento",
            "Pruebas A/B: Considerar pruebas graduales con subconjuntos de usuarios",
            "Documentación: Registrar configuraciones óptimas y lecciones aprendidas"
        ])

        return recommendations

    async def run_full_pipeline(self) -> Dict[str, Any]:
        """Ejecutar pipeline completo."""
        logger.info("Iniciando pipeline completo de validación RAG + CAG...")

        # Crear directorio de salida
        self.config['output_dir'].mkdir(parents=True, exist_ok=True)

        # Ejecutar benchmarks en secuencia
        benchmarks = [
            ("Cache Hit Rate", self.run_cache_hit_rate_benchmark),
            ("Inference Latency", self.run_inference_latency_benchmark),
            ("Performance Comparison", self.run_performance_comparison_benchmark),
            ("Cost Savings", self.run_cost_savings_calculation)
        ]

        for benchmark_name, benchmark_func in benchmarks:
            logger.info(f"=== EJECUTANDO: {benchmark_name} ===")
            success = await benchmark_func()

            if not success and self.config.get('fail_fast', False):
                logger.error(f"Pipeline detenido por fallo en {benchmark_name}")
                break

        # Cargar y consolidar resultados
        benchmark_results = self.load_benchmark_results()
        consolidated_report = self.generate_consolidated_report(benchmark_results)

        # Guardar reporte final
        self.save_consolidated_report()

        logger.info("Pipeline completado")
        return self.results

    def save_consolidated_report(self):
        """Guardar reporte consolidado."""
        output_file = self.config['output_dir'] / 'fase_ia1_validation_report.json'
        report_file = self.config['output_dir'] / 'fase_ia1_validation_report.md'

        # Guardar JSON
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)

        # Generar reporte Markdown
        self.generate_markdown_report(report_file)

        logger.info(f"Reportes guardados en {self.config['output_dir']}")

    def generate_markdown_report(self, output_file: Path):
        """Generar reporte en formato Markdown."""
        report = self.results['consolidated_report']

        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("# FASE IA 1: Validación RAG + CAG en EmpoorioLM\n\n")

            f.write("## Resumen Ejecutivo\n\n")
            f.write(f"**Fecha de generación:** {report['fecha_generacion']}\n\n")

            execution = report['resumen_ejecucion']
            f.write("### Resumen de Ejecución\n\n")
            f.write(f"- **Pasos totales:** {execution['total_steps']}\n")
            f.write(f"- **Pasos exitosos:** {execution['successful_steps']}\n")
            f.write(f"- **Tasa de éxito:** {execution['success_rate']:.1f}%\n")
            f.write(f"- **Tiempo total:** {execution['execution_time_total']:.2f}s\n\n")

            f.write("## Resultados Consolidados\n\n")

            consolidated = report['resultados_consolidados']

            # Cache Performance
            if consolidated.get('cache_performance'):
                f.write("### Rendimiento del Cache\n\n")
                cp = consolidated['cache_performance']
                f.write(f"- **Tasa de aciertos:** {cp['hit_rate']:.1f}%\n")
                f.write(f"- **Total consultas:** {cp['total_queries']}\n")
                f.write(f"- **Cache hits:** {cp['cache_hits']}\n")
                f.write(f"- **Cache misses:** {cp['cache_misses']}\n\n")

            # Latency Performance
            if consolidated.get('latency_performance'):
                f.write("### Rendimiento de Latencia\n\n")
                lp = consolidated['latency_performance']
                f.write(f"- **Mejora de latencia:** {lp['latency_improvement_percent']:.1f}%\n")
                f.write(f"- **Mejora de throughput:** {lp['throughput_improvement_percent']:.1f}%\n")
                f.write(f"- **Puntuación beneficio cache:** {lp['cache_benefit_score']:.1f}/100\n\n")

            # Cost Savings
            if consolidated.get('cost_savings'):
                f.write("### Ahorros de Costo\n\n")
                cs = consolidated['cost_savings']
                f.write(f"- **Modelo recomendado:** {cs['recommended_model']}\n")
                f.write(f"- **Modelo con mayores ahorros:** {cs['highest_savings_model']}\n")
                f.write(f"- **ROI promedio:** {cs['average_roi']:.1f}%\n")
                f.write(f"- **Ahorros potenciales mensuales:** ${cs['total_potential_savings']:.0f}\n\n")

            f.write("## Conclusiones\n\n")
            conclusions = report['conclusiones']
            for key, value in conclusions.items():
                f.write(f"### {key.replace('_', ' ').title()}\n\n")
                f.write(f"{value}\n\n")

            f.write("## Recomendaciones\n\n")
            for i, rec in enumerate(report['recomendaciones'], 1):
                f.write(f"{i}. {rec}\n")

            f.write("\n---\n*Reporte generado automáticamente por el pipeline de validación Fase IA 1*")

    def print_summary(self):
        """Imprimir resumen del pipeline."""
        report = self.results.get('consolidated_report', {})

        print("\n" + "="*80)
        print("PIPELINE COMPLETADO - FASE IA 1: RAG + CAG en EmpoorioLM")
        print("="*80)

        execution = report.get('resumen_ejecucion', {})
        print(f"\nEjecución: {execution.get('successful_steps', 0)}/{execution.get('total_steps', 0)} pasos exitosos")
        print(f"Tasa de éxito: {execution.get('success_rate', 0):.1f}%")
        print(f"Tiempo total: {execution.get('execution_time_total', 0):.2f}s")

        consolidated = report.get('resultados_consolidados', {})

        if consolidated.get('cache_performance'):
            cp = consolidated['cache_performance']
            print(f"Cache hit rate: {cp.get('hit_rate', 0):.1f}%")

        if consolidated.get('latency_performance'):
            lp = consolidated['latency_performance']
            print(f"Mejora latencia: {lp.get('latency_improvement_percent', 0):.1f}%")

        if consolidated.get('cost_savings'):
            cs = consolidated['cost_savings']
            print(f"ROI promedio: {cs.get('average_roi', 0):.1f}%")

        conclusions = report.get('conclusiones', {})
        if conclusions.get('overall_recommendation'):
            print(f"\nRecomendación general: {conclusions['overall_recommendation']}")

        print(f"\nReportes guardados en: {self.config['output_dir']}")
        print("="*80)


async def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Pipeline de validación Fase IA 1: RAG + CAG')
    parser.add_argument('--full_pipeline', action='store_true',
                       help='Ejecutar pipeline completo')
    parser.add_argument('--cache_hit_rate_only', action='store_true',
                       help='Ejecutar solo benchmark de cache hit rate')
    parser.add_argument('--latency_only', action='store_true',
                       help='Ejecutar solo benchmark de latencia')
    parser.add_argument('--comparison_only', action='store_true',
                       help='Ejecutar solo comparación de rendimiento')
    parser.add_argument('--costs_only', action='store_true',
                       help='Ejecutar solo cálculo de costos')
    parser.add_argument('--output_dir', type=str, default='reports/fase_ia1',
                       help='Directorio de salida para reportes')
    parser.add_argument('--num_queries', type=int, default=50,
                       help='Número de consultas por benchmark')
    parser.add_argument('--similarity_threshold', type=float, default=0.8,
                       help='Umbral de similitud para cache')
    parser.add_argument('--cache_max_size', type=int, default=1000,
                       help='Tamaño máximo del cache')
    parser.add_argument('--model_path', type=str, default='./models/empoorio_lm/v1.0.0',
                       help='Ruta al modelo EmpoorioLM')
    parser.add_argument('--eviction_policy', type=str, default='LRU',
                       help='Política de eviction del cache')
    parser.add_argument('--fail_fast', action='store_true',
                       help='Detener pipeline al primer error')
    parser.add_argument('--script_timeout', type=int, default=300,
                       help='Timeout por script en segundos')

    args = parser.parse_args()

    # Configuración del pipeline
    config = {
        'output_dir': Path(args.output_dir),
        'num_queries': args.num_queries,
        'similarity_threshold': args.similarity_threshold,
        'cache_max_size': args.cache_max_size,
        'model_path': args.model_path,
        'eviction_policy': args.eviction_policy,
        'fail_fast': args.fail_fast,
        'script_timeout': args.script_timeout,
        # Configuración adicional para costos
        'monthly_queries': 100000,
        'avg_tokens_per_query': 200,
        'cache_size_gb': 1.0,
        'development_hours': 40,
        'hourly_developer_rate': 75.0,
        'cost_model': 'all',
        'test_types': 'latency,hit_rate,quality',
        'warmup_queries': 5,
        'num_repetitions': 3
    }

    # Crear pipeline
    pipeline = RAGCAGValidationPipeline(config)

    try:
        if args.full_pipeline:
            # Ejecutar pipeline completo
            results = await pipeline.run_full_pipeline()

        elif args.cache_hit_rate_only:
            # Solo cache hit rate
            await pipeline.run_cache_hit_rate_benchmark()
            pipeline.results['benchmark_results'] = pipeline.load_benchmark_results()

        elif args.latency_only:
            # Solo latencia
            await pipeline.run_inference_latency_benchmark()
            pipeline.results['benchmark_results'] = pipeline.load_benchmark_results()

        elif args.comparison_only:
            # Solo comparación
            await pipeline.run_performance_comparison_benchmark()
            pipeline.results['benchmark_results'] = pipeline.load_benchmark_results()

        elif args.costs_only:
            # Solo costos (asumiendo que hay resultados previos)
            await pipeline.run_cost_savings_calculation()
            pipeline.results['benchmark_results'] = pipeline.load_benchmark_results()

        else:
            print("Especifique --full_pipeline o un benchmark específico")
            return

        # Generar reporte consolidado si hay resultados
        if pipeline.results.get('benchmark_results'):
            consolidated_report = pipeline.generate_consolidated_report(
                pipeline.results['benchmark_results']
            )
            pipeline.save_consolidated_report()

        # Imprimir resumen
        pipeline.print_summary()

        logger.info("Pipeline ejecutado exitosamente")

    except Exception as e:
        logger.error(f"Error en el pipeline: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())