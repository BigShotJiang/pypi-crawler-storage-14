#!/bin/bash

# Stress test for Cloud Build agility validation
# Measures build times in cold and warm scenarios to validate 70-80% reduction with Cache Mounts

PROJECT_ID=${PROJECT_ID:-"your-project-id"}  # Set your GCP project ID
NUM_RUNS=3  # Number of runs for each scenario to average results
REPORT_FILE="benchmark_results/build_stress_test_report.txt"

# Create benchmark results directory if it doesn't exist
mkdir -p benchmark_results

# Initialize report file
echo "=== Cloud Build Stress Test for Agility Validation ===" > $REPORT_FILE
echo "Timestamp: $(date)" >> $REPORT_FILE
echo "Project ID: $PROJECT_ID" >> $REPORT_FILE
echo "Number of runs per scenario: $NUM_RUNS" >> $REPORT_FILE
echo "" >> $REPORT_FILE

# Function to run build and measure time
run_build() {
    local use_cache=$1
    local run_num=$2
    local scenario=$3

    echo "🔄 Running $scenario build $run_num (cache=$use_cache)" | tee -a $REPORT_FILE
    echo "Start time: $(date)" >> $REPORT_FILE

    start=$(date +%s)

    # Run the build with logging
    if gcloud builds submit --config infrastructure/cloudbuild.yaml --substitutions _USE_CACHE=$use_cache --project $PROJECT_ID 2>&1; then
        status="SUCCESS"
    else
        status="FAILED"
    fi

    end=$(date +%s)
    duration=$((end - start))

    echo "End time: $(date)" >> $REPORT_FILE
    echo "Duration: $duration seconds" >> $REPORT_FILE
    echo "Status: $status" >> $REPORT_FILE
    echo "" >> $REPORT_FILE

    if [ "$status" = "FAILED" ]; then
        echo "❌ Build failed, skipping time measurement" | tee -a $REPORT_FILE
        return 1
    fi

    echo $duration
}

# Cold builds (no cache)
echo "=== Cold Builds (No Cache) ===" | tee -a $REPORT_FILE
cold_times=()
for i in $(seq 1 $NUM_RUNS); do
    time=$(run_build false $i "Cold")
    if [ $? -eq 0 ]; then
        cold_times+=($time)
    fi
done

# Warm builds (with cache)
echo "=== Warm Builds (With Cache) ===" | tee -a $REPORT_FILE
warm_times=()
for i in $(seq 1 $NUM_RUNS); do
    time=$(run_build true $i "Warm")
    if [ $? -eq 0 ]; then
        warm_times+=($time)
    fi
done

# Calculate averages
cold_sum=0
cold_count=${#cold_times[@]}
for t in "${cold_times[@]}"; do
    cold_sum=$((cold_sum + t))
done
if [ $cold_count -gt 0 ]; then
    cold_avg=$((cold_sum / cold_count))
else
    cold_avg=0
fi

warm_sum=0
warm_count=${#warm_times[@]}
for t in "${warm_times[@]}"; do
    warm_sum=$((warm_sum + t))
done
if [ $warm_count -gt 0 ]; then
    warm_avg=$((warm_sum / warm_count))
else
    warm_avg=0
fi

# Calculate reduction
if [ $cold_avg -gt 0 ]; then
    reduction=$(( (cold_avg - warm_avg) * 100 / cold_avg ))
else
    reduction=0
fi

# Generate final report
echo "=== Results Summary ===" | tee -a $REPORT_FILE
echo "Cold builds successful: $cold_count/$NUM_RUNS" >> $REPORT_FILE
echo "Warm builds successful: $warm_count/$NUM_RUNS" >> $REPORT_FILE
echo "" >> $REPORT_FILE
echo "Average Cold Build Time: $cold_avg seconds" | tee -a $REPORT_FILE
echo "Average Warm Build Time: $warm_avg seconds" | tee -a $REPORT_FILE
echo "Time Reduction: $reduction%" | tee -a $REPORT_FILE

if [ $reduction -ge 70 ] && [ $reduction -le 80 ]; then
    echo "✅ Agility validation PASSED: Reduction $reduction% (within 70-80% target)" | tee -a $REPORT_FILE
elif [ $reduction -ge 70 ]; then
    echo "✅ Agility validation PASSED: Reduction $reduction% (>= 70%)" | tee -a $REPORT_FILE
else
    echo "❌ Agility validation FAILED: Reduction $reduction% (< 70%)" | tee -a $REPORT_FILE
fi

echo "" >> $REPORT_FILE
echo "Detailed logs and times:" >> $REPORT_FILE
echo "Cold times: ${cold_times[*]}" >> $REPORT_FILE
echo "Warm times: ${warm_times[*]}" >> $REPORT_FILE

echo ""
echo "📊 Report generated: $REPORT_FILE"
echo "View full report with: cat $REPORT_FILE"