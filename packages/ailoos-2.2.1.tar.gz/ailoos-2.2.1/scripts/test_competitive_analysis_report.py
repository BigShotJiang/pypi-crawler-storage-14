#!/usr/bin/env python3
"""
Script de prueba para el CompetitiveAnalysisReport
Integra datos de todos los benchmarks y genera reporte competitivo completo.
"""

import os
import sys
import json
import logging
from pathlib import Path

# Añadir src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.benchmarking.competitive_analysis_report import (
    CompetitiveAnalysisReport,
    CompetitiveAnalysisConfig,
    generate_competitive_report
)

# Importar frameworks de benchmark (con manejo de errores)
try:
    from ailoos.benchmarking.accuracy_comparison_framework import AccuracyComparisonFramework
    ACCURACY_AVAILABLE = True
except ImportError:
    ACCURACY_AVAILABLE = False
    print("⚠️ AccuracyComparisonFramework no disponible")

try:
    from ailoos.benchmarking.performance_report_generator import PerformanceReportGenerator
    PERFORMANCE_AVAILABLE = True
except ImportError:
    PERFORMANCE_AVAILABLE = False
    print("⚠️ PerformanceReportGenerator no disponible")

try:
    from ailoos.benchmarking.mobile_edge_benchmarks import MobileEdgeBenchmarkRunner
    MOBILE_AVAILABLE = True
except ImportError:
    MOBILE_AVAILABLE = False
    print("⚠️ MobileEdgeBenchmarkRunner no disponible")

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_mock_accuracy_data():
    """Crear datos de ejemplo para AccuracyComparisonFramework."""
    return {
        'comprehensive_metrics': {
            'empoorio': {
                'model_name': 'empoorio',
                'accuracy_mmlu': 0.78,
                'accuracy_gsm8k': 0.82,
                'accuracy_overall': 0.80,
                'avg_latency': 0.45,
                'p95_latency': 0.62,
                'time_to_first_token': 0.12,
                'throughput': 125.5,
                'total_energy_joules': 15.2,
                'joules_per_token': 0.008,
                'tokens_per_watt': 125.0,
                'carbon_emissions_kg': 0.002,
                'rag_accuracy': 0.85,
                'rag_context_sizes': [512, 1024, 2048, 4096],
                'rag_performance_curve': {512: 0.88, 1024: 0.86, 2048: 0.83, 4096: 0.80},
                'efficiency_score': 2.8,
                'intelligence_per_watt': 100.0,
                'sample_count': 1000,
                'evaluation_timestamp': '2024-11-25T18:00:00'
            },
            'gpt4': {
                'model_name': 'gpt4',
                'accuracy_mmlu': 0.88,
                'accuracy_gsm8k': 0.92,
                'accuracy_overall': 0.90,
                'avg_latency': 1.2,
                'p95_latency': 1.8,
                'time_to_first_token': 0.3,
                'throughput': 45.2,
                'total_energy_joules': 85.0,
                'joules_per_token': 0.042,
                'tokens_per_watt': 23.8,
                'carbon_emissions_kg': 0.015,
                'rag_accuracy': 0.87,
                'rag_context_sizes': [512, 1024, 2048, 4096, 8192],
                'rag_performance_curve': {512: 0.90, 1024: 0.88, 2048: 0.85, 4096: 0.82, 8192: 0.78},
                'efficiency_score': 1.2,
                'intelligence_per_watt': 21.4,
                'sample_count': 1000,
                'evaluation_timestamp': '2024-11-25T18:00:00'
            },
            'claude': {
                'model_name': 'claude',
                'accuracy_mmlu': 0.85,
                'accuracy_gsm8k': 0.89,
                'accuracy_overall': 0.87,
                'avg_latency': 0.95,
                'p95_latency': 1.4,
                'time_to_first_token': 0.25,
                'throughput': 62.1,
                'total_energy_joules': 65.0,
                'joules_per_token': 0.032,
                'tokens_per_watt': 31.2,
                'carbon_emissions_kg': 0.012,
                'rag_accuracy': 0.86,
                'rag_context_sizes': [512, 1024, 2048, 4096],
                'rag_performance_curve': {512: 0.89, 1024: 0.87, 2048: 0.84, 4096: 0.81},
                'efficiency_score': 1.5,
                'intelligence_per_watt': 27.2,
                'sample_count': 1000,
                'evaluation_timestamp': '2024-11-25T18:00:00'
            }
        },
        'statistical_comparisons': [
            {
                'model_a': 'empoorio',
                'model_b': 'gpt4',
                'metric': 'efficiency_score',
                'mean_a': 2.8,
                'mean_b': 1.2,
                'difference': 1.6,
                'relative_difference': 1.33,
                'p_value': 0.001,
                'significant': True,
                'confidence_interval': [1.2, 2.0],
                'effect_size': 2.1,
                'sample_size_a': 100,
                'sample_size_b': 100
            }
        ],
        'market_headlines': [
            {
                'headline': 'EmpoorioLM 2.3x más eficiente energéticamente que GPT-4',
                'metric': 'efficiency',
                'model': 'empoorio',
                'competitor': 'gpt4',
                'improvement': 2.3,
                'significance': 'estadísticamente significativo',
                'category': 'efficiency'
            }
        ]
    }


def create_mock_mobile_edge_data():
    """Crear datos de ejemplo para MobileEdgeBenchmarkRunner."""
    return {
        'pixel_7': {
            'device_name': 'pixel_7',
            'platform': 'android',
            'model_name': 'empoorio',
            'model_size_mb': 85.0,
            'quantization_type': 'int8',
            'avg_latency_ms': 45.2,
            'p95_latency_ms': 62.1,
            'p99_latency_ms': 78.5,
            'battery_consumption_mah': 12.5,
            'battery_percentage_used': 2.1,
            'energy_efficiency_mah_per_token': 0.006,
            'peak_memory_mb': 120.5,
            'avg_memory_mb': 95.2,
            'memory_efficiency_mb_per_token': 0.048,
            'throughput_tokens_per_sec': 22.1,
            'throughput_requests_per_min': 1326.0,
            'cloud_latency_baseline_ms': 1200.0,
            'edge_vs_cloud_speedup': 26.5,
            'edge_vs_cloud_energy_savings': 85.2,
            'num_requests': 100,
            'successful_requests': 98,
            'test_duration_seconds': 45.2,
            'timestamp': '20241125_180000'
        },
        'iphone_14': {
            'device_name': 'iphone_14',
            'platform': 'ios',
            'model_name': 'empoorio',
            'model_size_mb': 85.0,
            'quantization_type': 'int8',
            'avg_latency_ms': 38.9,
            'p95_latency_ms': 52.4,
            'battery_consumption_mah': 8.9,
            'battery_percentage_used': 1.8,
            'energy_efficiency_mah_per_token': 0.004,
            'peak_memory_mb': 105.2,
            'throughput_tokens_per_sec': 25.7,
            'edge_vs_cloud_speedup': 30.8,
            'edge_vs_cloud_energy_savings': 88.1,
            'num_requests': 100,
            'successful_requests': 99,
            'test_duration_seconds': 38.9,
            'timestamp': '20241125_180000'
        }
    }


def run_competitive_analysis_demo():
    """Ejecutar demostración completa del análisis competitivo."""
    print("🚀 Competitive Analysis Report - Demo")
    print("=" * 50)

    # Crear datos de ejemplo
    print("📊 Generando datos de ejemplo...")
    accuracy_data = create_mock_accuracy_data()
    mobile_edge_data = create_mock_mobile_edge_data()
    performance_data = None  # Usar None por simplicidad

    # Crear configuración
    config = CompetitiveAnalysisConfig(
        output_dir='./competitive_analysis_demo',
        report_title='EmpoorioLM: Análisis Competitivo Demo',
        target_audience='investors_and_stakeholders'
    )

    # Crear generador
    report = CompetitiveAnalysisReport(config)

    # Cargar datos
    print("📥 Cargando datos de benchmarks...")
    report.load_benchmark_data(accuracy_data, performance_data, mobile_edge_data)

    # Generar análisis competitivo
    print("🔄 Generando análisis competitivo...")
    generated_files = report.generate_competitive_analysis()

    # Mostrar resultados
    print("\n✅ Análisis competitivo completado!")
    print("📁 Archivos generados:")
    for format_type, file_path in generated_files.items():
        print(f"  • {format_type.upper()}: {file_path}")

    # Mostrar insights clave
    print("\n💡 Insights de Mercado Generados:")
    for insight in report.market_insights:
        print(f"  • {insight}")

    print("\n🎯 Recomendaciones Estratégicas:")
    for rec in report.strategic_recommendations[:3]:  # Top 3
        print(f"  • {rec.recommendation} ({rec.priority.upper()})")

    return generated_files


def run_integration_test():
    """Ejecutar prueba de integración con frameworks reales."""
    print("🔗 Integration Test - Competitive Analysis Report")
    print("=" * 50)

    try:
        # Intentar ejecutar frameworks reales si están disponibles
        accuracy_data = None
        if ACCURACY_AVAILABLE:
            print("🏃 Ejecutando AccuracyComparisonFramework...")
            framework = AccuracyComparisonFramework()
            accuracy_data = framework.run_comprehensive_comparison()
            framework.generate_comprehensive_report()
            print("✅ AccuracyComparisonFramework completado")

        mobile_edge_data = None
        if MOBILE_AVAILABLE:
            print("📱 Ejecutando MobileEdgeBenchmarkRunner...")
            # Nota: Esto requeriría un modelo real, así que usamos datos mock
            mobile_edge_data = create_mock_mobile_edge_data()
            print("✅ MobileEdgeBenchmarkRunner datos preparados")

        # Generar reporte competitivo
        print("📊 Generando reporte competitivo integrado...")
        generated_files = generate_competitive_report(
            accuracy_data, None, mobile_edge_data,
            output_dir='./competitive_analysis_integration'
        )

        print("\n✅ Integration test completado!")
        print("📁 Archivos generados:")
        for format_type, file_path in generated_files.items():
            print(f"  • {format_type.upper()}: {file_path}")

        return generated_files

    except Exception as e:
        print(f"❌ Error en integration test: {e}")
        return {}


def main():
    """Función principal."""
    import argparse

    parser = argparse.ArgumentParser(description='Test Competitive Analysis Report')
    parser.add_argument('--demo', action='store_true', help='Ejecutar demo con datos de ejemplo')
    parser.add_argument('--integration', action='store_true', help='Ejecutar prueba de integración')
    parser.add_argument('--output', type=str, default='./competitive_analysis_test', help='Directorio de salida')

    args = parser.parse_args()

    if args.demo:
        run_competitive_analysis_demo()
    elif args.integration:
        run_integration_test()
    else:
        print("💡 Uso:")
        print("  python test_competitive_analysis_report.py --demo")
        print("  python test_competitive_analysis_report.py --integration")
        print("\n📖 El módulo CompetitiveAnalysisReport integra datos de:")
        print("  • AccuracyComparisonFramework (precisión, latencia, energía, RAG)")
        print("  • PerformanceReportGenerator (reportes técnicos)")
        print("  • MobileEdgeBenchmarkRunner (benchmarks móviles)")
        print("\n🎯 Genera whitepapers profesionales con:")
        print("  • Análisis de mercado y posicionamiento competitivo")
        print("  • Análisis SWOT estratégico")
        print("  • Roadmap y recomendaciones para inversores")
        print("  • Visualizaciones profesionales")


if __name__ == "__main__":
    main()