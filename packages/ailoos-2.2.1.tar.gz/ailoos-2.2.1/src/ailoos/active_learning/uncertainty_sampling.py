import numpy as np
from scipy.stats import entropy
from typing import List, Tuple, Any
import logging

logger = logging.getLogger(__name__)

class UncertaintySampling:
    """
    Estrategia de muestreo por incertidumbre para aprendizaje activo.
    Implementa métodos: least confident, margin, entropy.
    """

    def __init__(self, method: str = 'least_confident'):
        """
        Inicializa UncertaintySampling.

        Args:
            method: Método de incertidumbre ('least_confident', 'margin', 'entropy')
        """
        self.method = method
        self.valid_methods = ['least_confident', 'margin', 'entropy']
        if method not in self.valid_methods:
            raise ValueError(f"Método {method} no válido. Opciones: {self.valid_methods}")

    def select_samples(self, model: Any, unlabeled_data: np.ndarray, n_samples: int) -> List[int]:
        """
        Selecciona las muestras más inciertas del conjunto no etiquetado.

        Args:
            model: Modelo con método predict_proba
            unlabeled_data: Datos no etiquetados (n_samples, n_features)
            n_samples: Número de muestras a seleccionar

        Returns:
            Lista de índices de las muestras seleccionadas
        """
        try:
            # Obtener probabilidades de predicción
            probabilities = model.predict_proba(unlabeled_data)

            if self.method == 'least_confident':
                scores = self._least_confident(probabilities)
            elif self.method == 'margin':
                scores = self._margin(probabilities)
            elif self.method == 'entropy':
                scores = self._entropy(probabilities)

            # Seleccionar índices con mayor incertidumbre (menor confianza)
            indices = np.argsort(scores)[-n_samples:][::-1]  # Orden descendente
            return indices.tolist()

        except Exception as e:
            logger.error(f"Error en select_samples: {e}")
            raise

    def _least_confident(self, probabilities: np.ndarray) -> np.ndarray:
        """Calcula la incertidumbre como 1 - max_prob"""
        max_probs = np.max(probabilities, axis=1)
        return 1 - max_probs

    def _margin(self, probabilities: np.ndarray) -> np.ndarray:
        """Calcula la incertidumbre como diferencia entre las dos probabilidades más altas"""
        sorted_probs = np.sort(probabilities, axis=1)
        return sorted_probs[:, -1] - sorted_probs[:, -2]

    def _entropy(self, probabilities: np.ndarray) -> np.ndarray:
        """Calcula la incertidumbre como entropía de Shannon"""
        return entropy(probabilities.T)