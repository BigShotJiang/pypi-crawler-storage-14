"""
EmpoorioLM API - API funcional para modelo de lenguaje EmpoorioLM.
Implementa generación de texto real con transformers y PyTorch.
"""

import torch
import json
from typing import Dict, List, Any, Optional, Union
from pathlib import Path
from dataclasses import dataclass
import re
import asyncio
from datetime import datetime
import logging

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import uvicorn

# Import serializers for TOON/VSC support
try:
    from ..core.serializers import (
        SerializationFormat, get_serializer, detect_format, convert_format
    )
except ImportError:
    # Fallback if serializers not available
    SerializationFormat = None
    get_serializer = None
    detect_format = None
    convert_format = None

# Try to import from ailoos, fallback to basic implementation
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM
    from ..models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
    from ..utils.logging import get_logger
    from ..benchmarking.energy_tracker import EnergyTracker, EnergyTrackerConfig
    logger = get_logger(__name__)
except ImportError:
    # Fallback logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    # Basic fallback classes
    @dataclass
    class EmpoorioLMConfig:
        vocab_size: int = 30000
        hidden_size: int = 768
        num_hidden_layers: int = 12
        num_attention_heads: int = 12
        max_position_embeddings: int = 512

    class EmpoorioLM:
        def __init__(self, config):
            self.config = config

        def generate(self, input_ids, max_new_tokens=50, **kwargs):
            # Simple mock generation - just repeat the input
            return torch.cat([input_ids, input_ids[:, :max_new_tokens]], dim=1)

    # Fallback for energy tracker
    class EnergyTracker:
        def __init__(self, config=None):
            self.config = config

        def start_monitoring(self):
            pass

        def stop_monitoring(self, tokens=0, accuracy=0.0):
            return None

        def cleanup(self):
            pass

    @dataclass
    class EnergyTrackerConfig:
        enable_codecarbon: bool = False
        enable_gpu_monitoring: bool = False


@dataclass
class GenerationConfig:
    """Configuración para generación de texto."""
    max_new_tokens: int = 100
    temperature: float = 0.8
    top_p: float = 0.9
    top_k: int = 50
    do_sample: bool = True
    repetition_penalty: float = 1.1
    pad_token_id: Optional[int] = None
    eos_token_id: Optional[int] = None
    bos_token_id: Optional[int] = None


@dataclass
class EmpoorioLMApiConfig:
    """Configuración de la API EmpoorioLM."""
    model_path: str = "./models/empoorio_lm/v1.0.0"
    device: str = "auto"  # auto, cpu, cuda
    max_batch_size: int = 4
    max_sequence_length: int = 512
    cache_dir: Optional[str] = None
    trust_remote_code: bool = False
    enable_energy_tracking: bool = False
    energy_tracker_config: Optional[EnergyTrackerConfig] = None


# Pydantic models for API requests/responses
class GenerateRequest(BaseModel):
    """Request model for text generation."""
    prompt: str = Field(..., description="The input prompt for text generation")
    max_length: Optional[int] = Field(1000, description="Maximum length of generated text")
    temperature: Optional[float] = Field(0.7, description="Sampling temperature")
    model: Optional[str] = Field("empoorio-lm", description="Model to use for generation")
    stream: Optional[bool] = Field(False, description="Whether to stream the response")


class GenerateResponse(BaseModel):
    """Response model for text generation."""
    response: str
    usage: Optional[Dict[str, Any]] = None


class HealthResponse(BaseModel):
    """Response model for health check."""
    status: str  # "healthy" or "unhealthy"
    latency: Optional[float] = None
    model_loaded: bool = False
    timestamp: str


class ModelsResponse(BaseModel):
    """Response model for available models."""
    models: List[str]


class EmpoorioLMApi:
    """
    API funcional para modelo de lenguaje EmpoorioLM.
    Implementa generación de texto real con transformers y PyTorch.
    """

    def __init__(self, config: EmpoorioLMApiConfig = None):
        """
        Inicializar la API de EmpoorioLM cargando el modelo real.

        Args:
            config: Configuración de la API
        """
        self.config = config or EmpoorioLMApiConfig()

        # Determinar dispositivo
        self.device = self._setup_device()

        # Componentes del modelo
        self.model: Optional[EmpoorioLM] = None
        self.tokenizer = None
        self.is_loaded = False

        # Energy tracker
        self.energy_tracker: Optional[EnergyTracker] = None
        if self.config.enable_energy_tracking:
            energy_config = self.config.energy_tracker_config or EnergyTrackerConfig()
            self.energy_tracker = EnergyTracker(energy_config)
            logger.info("🔋 Energy tracking habilitado")

        logger.info(f"� Inicializando EmpoorioLM API - Device: {self.device}")

        # Cargar modelo y tokenizer
        self._load_model()

        logger.info("✅ EmpoorioLM API inicializada correctamente")

    def _setup_device(self) -> str:
        """Configurar dispositivo óptimo (GPU si disponible)."""
        if self.config.device == "auto":
            if torch.cuda.is_available():
                device = "cuda"
                logger.info("🎯 GPU detectada, usando CUDA")
            else:
                device = "cpu"
                logger.info("💻 GPU no disponible, usando CPU")
        else:
            device = self.config.device

        return device

    def _load_model(self):
        """
        Cargar modelo EmpoorioLM real desde archivo.
        """
        try:
            model_path = Path(self.config.model_path)

            # Intentar cargar modelo EmpoorioLM nativo primero
            if self._try_load_native_model(model_path):
                logger.info("✅ Modelo EmpoorioLM nativo cargado")
                return

            # Fallback: intentar cargar como modelo transformers estándar
            if self._try_load_transformers_model(model_path):
                logger.info("✅ Modelo transformers cargado como fallback")
                return

            # Si no se puede cargar ningún modelo, crear uno básico
            logger.warning("⚠️ No se pudo cargar modelo existente, creando modelo básico")
            self._create_basic_model()

        except Exception as e:
            logger.error(f"❌ Error cargando modelo: {e}")
            raise RuntimeError(f"Error cargando modelo EmpoorioLM: {str(e)}")

    def _try_load_native_model(self, model_path: Path) -> bool:
        """Intentar cargar modelo EmpoorioLM nativo."""
        try:
            config_path = model_path / "config.json"
            weights_path = model_path / "pytorch_model.bin"

            if config_path.exists() and weights_path.exists():
                # Cargar configuración
                with open(config_path, 'r') as f:
                    config_dict = json.load(f)
                config = EmpoorioLMConfig(**config_dict)

                # Crear modelo
                self.model = EmpoorioLM(config)

                # Cargar pesos
                state_dict = torch.load(weights_path, map_location='cpu')
                self.model.load_state_dict(state_dict, strict=False)

                # Mover a dispositivo
                self.model.to(self.device)
                self.model.eval()

                # Cargar tokenizer (usar GPT-2 tokenizer como base)
                self.tokenizer = AutoTokenizer.from_pretrained(
                    "gpt2",
                    cache_dir=self.config.cache_dir,
                    trust_remote_code=self.config.trust_remote_code
                )

                # Configurar tokens especiales
                if self.tokenizer.pad_token is None:
                    self.tokenizer.pad_token = self.tokenizer.eos_token

                self.is_loaded = True
                return True

        except Exception as e:
            logger.warning(f"No se pudo cargar modelo nativo: {e}")
            return False

    def _try_load_transformers_model(self, model_path: Path) -> bool:
        """Intentar cargar como modelo transformers estándar."""
        try:
            # Intentar cargar tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                str(model_path),
                cache_dir=self.config.cache_dir,
                trust_remote_code=self.config.trust_remote_code
            )

            # Intentar cargar modelo
            self.model = AutoModelForCausalLM.from_pretrained(
                str(model_path),
                cache_dir=self.config.cache_dir,
                trust_remote_code=self.config.trust_remote_code,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
            )

            # Mover a dispositivo
            self.model.to(self.device)
            self.model.eval()

            # Configurar tokens especiales
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token

            self.is_loaded = True
            return True

        except Exception as e:
            logger.info(f"ℹ️ No se pudo cargar modelo transformers: {e}. Usando implementación nativa EmpoorioLM.")
            return False

    def _create_basic_model(self):
        """Crear modelo básico EmpoorioLM si no se puede cargar uno existente."""
        try:
            config = EmpoorioLMConfig()
            self.model = EmpoorioLM(config)
            self.model.to(self.device)
            self.model.eval()

            # Usar GPT-2 tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                "gpt2",
                cache_dir=self.config.cache_dir,
                trust_remote_code=self.config.trust_remote_code
            )

            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token

            self.is_loaded = True
            logger.info("✅ Modelo básico EmpoorioLM creado")

        except Exception as e:
            logger.error(f"❌ Error creando modelo básico: {e}")
            raise

    def generate_text(
        self,
        prompt: str,
        generation_config: GenerationConfig = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generar texto usando EmpoorioLM con soporte para TOON/VSC en prompts y tracking de energía.

        Args:
            prompt: Texto de entrada (puede contener datos TOON/VSC)
            generation_config: Configuración de generación
            **kwargs: Parámetros adicionales

        Returns:
            Dict con texto generado y metadata
        """
        if not self.is_loaded:
            raise RuntimeError("Modelo no está cargado")

        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Prompt debe ser una cadena no vacía")

        generation_config = generation_config or GenerationConfig()

        # Inicializar variables para energy tracking
        energy_metrics = None
        tokens_generated = 0

        try:
            logger.info(f"🎯 Generando texto para prompt: {prompt[:50]}...")

            # Iniciar energy tracking si está habilitado
            if self.energy_tracker:
                self.energy_tracker.start_monitoring()
                logger.debug("🔋 Energy tracking iniciado")

            # Procesar prompt para detectar datos TOON/VSC
            processed_prompt, serialization_context = self._process_serialization_formats(prompt)
            logger.info(f"📊 Formatos de serialización detectados: {list(serialization_context.keys()) if serialization_context else 'ninguno'}")

            # Optimizar ventana de contexto si hay datos serializados
            if serialization_context:
                generation_config = self._optimize_context_window(generation_config, serialization_context)

            # Tokenizar input procesado
            input_ids = self.tokenize_text(processed_prompt)

            # Limitar longitud si es necesario
            if len(input_ids) > self.config.max_sequence_length - generation_config.max_new_tokens:
                input_ids = input_ids[-(self.config.max_sequence_length - generation_config.max_new_tokens):]
                logger.warning("Prompt truncado por límite de longitud")

            # Mover a dispositivo
            input_ids = input_ids.to(self.device)

            # Generar texto
            with torch.no_grad():
                if hasattr(self.model, 'generate') and callable(getattr(self.model, 'generate')):
                    # Usar método generate del modelo si está disponible
                    # Map max_new_tokens to max_length for compatibility
                    max_length = len(input_ids) + generation_config.max_new_tokens
                    generated_ids = self.model.generate(
                        input_ids=input_ids.unsqueeze(0),
                        max_length=max_length,
                        temperature=generation_config.temperature,
                        top_p=generation_config.top_p,
                        top_k=generation_config.top_k,
                        do_sample=generation_config.do_sample,
                        pad_token_id=generation_config.pad_token_id or self.tokenizer.pad_token_id,
                        eos_token_id=generation_config.eos_token_id or self.tokenizer.eos_token_id,
                        **kwargs
                    )
                else:
                    # Fallback: usar método nativo del modelo EmpoorioLM
                    generated_ids = self.model.generate(
                        input_ids=input_ids.unsqueeze(0),
                        max_new_tokens=generation_config.max_new_tokens,
                        temperature=generation_config.temperature,
                        top_p=generation_config.top_p,
                        top_k=generation_config.top_k,
                        do_sample=generation_config.do_sample,
                        pad_token_id=generation_config.pad_token_id or self.tokenizer.pad_token_id,
                        eos_token_id=generation_config.eos_token_id or self.tokenizer.eos_token_id,
                        **kwargs
                    )

            # Decodificar resultado
            generated_text = self.tokenizer.decode(
                generated_ids[0],
                skip_special_tokens=True,
                clean_up_tokenization_spaces=True
            )

            # Post-procesar texto
            generated_text = self.post_process_text(generated_text, prompt)

            # Calcular métricas
            input_length = len(input_ids)
            output_length = len(generated_ids[0])
            tokens_generated = output_length - input_length

            # Detener energy tracking y obtener métricas
            if self.energy_tracker:
                energy_metrics = self.energy_tracker.stop_monitoring(tokens_generated, 0.0)  # accuracy=0.0 por defecto
                logger.debug(f"🔋 Energía consumida: {energy_metrics.total_energy_joules:.2f}J")

            result = {
                "generated_text": generated_text,
                "input_prompt": prompt,
                "processed_prompt": processed_prompt,
                "model_version": getattr(self.model.config, 'version', 'unknown') if hasattr(self.model, 'config') else 'unknown',
                "generation_config": {
                    "max_new_tokens": generation_config.max_new_tokens,
                    "temperature": generation_config.temperature,
                    "top_p": generation_config.top_p,
                    "top_k": generation_config.top_k,
                    "do_sample": generation_config.do_sample
                },
                "metrics": {
                    "input_tokens": input_length,
                    "generated_tokens": tokens_generated,
                    "total_tokens": output_length
                },
                "serialization_context": serialization_context,
                "device": self.device,
                "success": True
            }

            # Agregar métricas de energía si están disponibles
            if energy_metrics:
                result["energy_metrics"] = {
                    "total_energy_joules": energy_metrics.total_energy_joules,
                    "joules_per_token": energy_metrics.joules_per_token,
                    "tokens_per_watt": energy_metrics.tokens_per_watt,
                    "carbon_emissions_kg": energy_metrics.carbon_emissions_kg,
                    "power_consumption_watts": energy_metrics.power_consumption_watts,
                    "duration_seconds": energy_metrics.duration_seconds
                }

            logger.info(f"✅ Texto generado exitosamente ({tokens_generated} tokens)")
            if energy_metrics:
                logger.info(f"🔋 Consumo energético: {energy_metrics.total_energy_joules:.2f}J, {energy_metrics.joules_per_token:.4f}J/token")

            return result

        except Exception as e:
            # Asegurar que el energy tracker se detenga en caso de error
            if self.energy_tracker and self.energy_tracker.is_monitoring:
                try:
                    self.energy_tracker.stop_monitoring(tokens_generated, 0.0)
                except:
                    pass

            logger.error(f"❌ Error generando texto: {e}")
            raise RuntimeError(f"Error en generación de texto: {str(e)}")

    def tokenize_text(self, text: str) -> torch.Tensor:
        """
        Tokenizar texto de entrada.

        Args:
            text: Texto a tokenizar

        Returns:
            Tensor de token IDs
        """
        if not self.tokenizer:
            raise RuntimeError("Tokenizer no está disponible")

        try:
            tokens = self.tokenizer.encode(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=self.config.max_sequence_length
            )
            return tokens.squeeze()
        except Exception as e:
            logger.error(f"Error tokenizando texto: {e}")
            raise

    def post_process_text(self, generated_text: str, prompt: str) -> str:
        """
        Post-procesar texto generado.

        Args:
            generated_text: Texto generado crudo
            prompt: Prompt original

        Returns:
            Texto post-procesado
        """
        try:
            # Remover prompt del inicio si está incluido
            if generated_text.startswith(prompt):
                generated_text = generated_text[len(prompt):].lstrip()

            # Limpiar espacios extra
            generated_text = generated_text.strip()

            # Remover caracteres de control y normalizar
            generated_text = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', generated_text)

            # Limitar longitud razonable
            if len(generated_text) > 10000:
                generated_text = generated_text[:10000] + "..."

            return generated_text

        except Exception as e:
            logger.warning(f"Error en post-procesamiento: {e}")
            return generated_text

    def _process_serialization_formats(self, prompt: str) -> tuple[str, dict]:
        """
        Procesar formatos de serialización TOON/VSC en el prompt.

        Args:
            prompt: Prompt que puede contener datos serializados

        Returns:
            Tupla de (prompt_procesado, contexto_de_serialización)
        """
        if not SerializationFormat or not detect_format:
            return prompt, {}

        serialization_context = {}
        processed_prompt = prompt

        try:
            # Detectar marcadores de datos serializados
            import re

            # Patrón para detectar datos TOON/VSC en el prompt
            # Busca bloques marcados como [TOON:data] o [VSC:data]
            toon_pattern = r'\[TOON:([A-Za-z0-9+/=]+)\]'
            vsc_pattern = r'\[VSC:([A-Za-z0-9+/=]+)\]'

            # Procesar datos TOON
            def replace_toon(match):
                base64_data = match.group(1)
                try:
                    # Decodificar base64
                    import base64
                    binary_data = base64.b64decode(base64_data)

                    # Detectar formato
                    detected_format = detect_format(binary_data)
                    if detected_format == SerializationFormat.TOON:
                        # Deserializar para comprensión del modelo
                        serializer = get_serializer(SerializationFormat.TOON)
                        deserialized = serializer.deserialize(binary_data)

                        # Crear representación textual para el modelo
                        text_repr = self._create_text_representation(deserialized.data, "TOON")
                        serialization_context[f"toon_{len(serialization_context)}"] = {
                            "format": "TOON",
                            "original_size": len(binary_data),
                            "data_type": type(deserialized.data).__name__
                        }

                        return f"[Datos TOON deserializados: {text_repr}]"
                    else:
                        return match.group(0)  # Mantener original si no es TOON válido
                except Exception as e:
                    logger.warning(f"Error procesando datos TOON: {e}")
                    return match.group(0)

            # Procesar datos VSC
            def replace_vsc(match):
                base64_data = match.group(1)
                try:
                    import base64
                    binary_data = base64.b64decode(base64_data)

                    detected_format = detect_format(binary_data)
                    if detected_format == SerializationFormat.VSC:
                        serializer = get_serializer(SerializationFormat.VSC)
                        deserialized = serializer.deserialize(binary_data)

                        text_repr = self._create_text_representation(deserialized.data, "VSC")
                        serialization_context[f"vsc_{len(serialization_context)}"] = {
                            "format": "VSC",
                            "original_size": len(binary_data),
                            "columns": len(deserialized.data) if isinstance(deserialized.data, dict) else 1
                        }

                        return f"[Datos VSC deserializados: {text_repr}]"
                    else:
                        return match.group(0)
                except Exception as e:
                    logger.warning(f"Error procesando datos VSC: {e}")
                    return match.group(0)

            # Aplicar reemplazos
            processed_prompt = re.sub(toon_pattern, replace_toon, processed_prompt)
            processed_prompt = re.sub(vsc_pattern, replace_vsc, processed_prompt)

        except Exception as e:
            logger.warning(f"Error procesando formatos de serialización: {e}")
            return prompt, {}

        return processed_prompt, serialization_context

    def _create_text_representation(self, data: any, format_name: str) -> str:
        """
        Crear representación textual de datos deserializados para el modelo.

        Args:
            data: Datos deserializados
            format_name: Nombre del formato (TOON/VSC)

        Returns:
            Representación textual
        """
        try:
            if isinstance(data, dict):
                if format_name == "VSC":
                    # Para VSC, mostrar estructura columnar
                    columns = list(data.keys())
                    sample_values = {}
                    for col, values in data.items():
                        if isinstance(values, list) and values:
                            sample_values[col] = f"{values[0]}...({len(values)} items)"
                        else:
                            sample_values[col] = str(values)[:50]

                    return f"Columnar data with {len(columns)} columns: {', '.join(columns)}. Samples: {sample_values}"
                else:
                    # Para TOON/dict regular
                    return f"Structured data with {len(data)} fields: {', '.join(data.keys())}"

            elif isinstance(data, list):
                return f"Array data with {len(data)} items, type: {type(data[0]).__name__ if data else 'empty'}"

            else:
                return f"Scalar data: {type(data).__name__}"

        except Exception as e:
            return f"Complex {format_name} data (error creating representation: {e})"

    def _optimize_context_window(self, config: GenerationConfig, serialization_context: dict) -> GenerationConfig:
        """
        Optimizar ventana de contexto basada en datos de serialización.

        Args:
            config: Configuración original de generación
            serialization_context: Contexto de serialización detectado

        Returns:
            Configuración optimizada
        """
        if not serialization_context:
            return config

        # Calcular tokens adicionales necesarios para datos serializados
        extra_tokens_estimate = 0

        for ctx_key, ctx_info in serialization_context.items():
            format_type = ctx_info.get("format", "")
            if format_type == "TOON":
                # TOON es más eficiente, menos tokens adicionales
                extra_tokens_estimate += 50
            elif format_type == "VSC":
                # VSC puede requerir más tokens para describir estructura columnar
                columns = ctx_info.get("columns", 1)
                extra_tokens_estimate += 30 + (columns * 10)

        # Ajustar max_new_tokens si es necesario para dar espacio al contexto
        if extra_tokens_estimate > 0:
            # Reducir tokens de generación para dar espacio al contexto serializado
            context_buffer = min(extra_tokens_estimate, config.max_new_tokens // 4)
            optimized_config = GenerationConfig(
                max_new_tokens=max(config.max_new_tokens - context_buffer, 50),
                temperature=config.temperature,
                top_p=config.top_p,
                top_k=config.top_k,
                do_sample=config.do_sample,
                repetition_penalty=config.repetition_penalty,
                pad_token_id=config.pad_token_id,
                eos_token_id=config.eos_token_id,
                bos_token_id=config.bos_token_id
            )

            logger.info(f"🔧 Context window optimized: reduced max_new_tokens by {context_buffer} for serialization context")
            return optimized_config

        return config

    def validate_input(self, prompt: str) -> bool:
        """
        Validar entrada del usuario.

        Args:
            prompt: Texto a validar

        Returns:
            True si es válido
        """
        if not isinstance(prompt, str):
            return False

        if not prompt.strip():
            return False

        if len(prompt) > self.config.max_sequence_length * 4:  # Límite aproximado de caracteres
            return False

        # Verificar caracteres peligrosos
        dangerous_patterns = [
            r'<script[^>]*>.*?</script>',  # Scripts
            r'javascript:',  # JavaScript URLs
            r'data:',  # Data URLs
            r'vbscript:',  # VBScript
        ]

        for pattern in dangerous_patterns:
            if re.search(pattern, prompt, re.IGNORECASE):
                logger.warning("Contenido potencialmente peligroso detectado en prompt")
                return False

        return True

    def get_model_info(self) -> Dict[str, Any]:
        """
        Obtener información del modelo cargado.

        Returns:
            Dict con información del modelo
        """
        if not self.is_loaded:
            return {"status": "not_loaded"}

        try:
            info = {
                "status": "loaded",
                "device": self.device,
                "model_type": type(self.model).__name__,
                "config": self.config.__dict__,
            }

            if hasattr(self.model, 'get_model_info'):
                info.update(self.model.get_model_info())
            elif hasattr(self.model, 'config'):
                info["model_config"] = self.model.config.__dict__

            # Información del tokenizer
            if self.tokenizer:
                info["tokenizer"] = {
                    "vocab_size": self.tokenizer.vocab_size,
                    "model_max_length": self.tokenizer.model_max_length,
                    "name_or_path": getattr(self.tokenizer, 'name_or_path', 'unknown')
                }

            # Información de energy tracking
            if self.energy_tracker:
                info["energy_tracking"] = {
                    "enabled": True,
                    "system_info": self.energy_tracker.system_info,
                    "current_power_draw": self.energy_tracker.get_current_power_draw()
                }
            else:
                info["energy_tracking"] = {"enabled": False}

            return info

        except Exception as e:
            logger.error(f"Error obteniendo info del modelo: {e}")
            return {"status": "error", "error": str(e)}

    def unload_model(self):
        """Descargar modelo de memoria."""
        try:
            if self.model:
                del self.model
                self.model = None

            if self.tokenizer:
                del self.tokenizer
                self.tokenizer = None

            # Limpiar energy tracker
            if self.energy_tracker:
                self.energy_tracker.cleanup()
                self.energy_tracker = None

            if torch.cuda.is_available():
                torch.cuda.empty_cache()

            self.is_loaded = False
            logger.info("✅ Modelo descargado de memoria")

        except Exception as e:
            logger.error(f"Error descargando modelo: {e}")

    def __del__(self):
        """Cleanup al destruir la instancia."""
        self.unload_model()


class EmpoorioLMAPI:
    """
    FastAPI wrapper for EmpoorioLM text generation API.
    Provides REST endpoints compatible with the frontend client.
    """

    def __init__(self):
        self.app = FastAPI(
            title="EmpoorioLM API",
            description="API for EmpoorioLM text generation model",
            version="1.0.0"
        )

        # Initialize the EmpoorioLM API
        self.empoorio_api = EmpoorioLMApi()

        # Setup routes
        self._setup_routes()

        logger.info("🚀 EmpoorioLM FastAPI initialized")

    def _setup_routes(self):
        """Setup FastAPI routes."""

        @self.app.options("/generate")
        async def options_generate():
            """OPTIONS handler for text generation."""
            return {"Allow": "POST, OPTIONS"}

        @self.app.post("/generate", response_model=GenerateResponse)
        async def generate_text(request: GenerateRequest):
            """Generate text using EmpoorioLM."""
            try:
                if request.stream:
                    # For streaming, return the raw response from the API
                    result = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: self.empoorio_api.generate_text(
                            prompt=request.prompt,
                            generation_config=GenerationConfig(
                                max_new_tokens=request.max_length or 1000,
                                temperature=request.temperature or 0.7,
                                do_sample=True,
                                repetition_penalty=1.1
                            )
                        )
                    )
                    return GenerateResponse(
                        response=result["generated_text"],
                        usage=result.get("metrics")
                    )
                else:
                    # Non-streaming generation
                    result = await asyncio.get_event_loop().run_in_executor(
                        None,
                        lambda: self.empoorio_api.generate_text(
                            prompt=request.prompt,
                            generation_config=GenerationConfig(
                                max_new_tokens=request.max_length or 1000,
                                temperature=request.temperature or 0.7,
                                do_sample=True,
                                repetition_penalty=1.1
                            )
                        )
                    )
                    return GenerateResponse(
                        response=result["generated_text"],
                        usage=result.get("metrics")
                    )
            except Exception as e:
                logger.error(f"Error in generate_text endpoint: {e}")
                raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")

        @self.app.get("/status", response_model=HealthResponse)
        async def health_check():
            """Health check endpoint."""
            try:
                start_time = asyncio.get_event_loop().time()
                # Simple health check - just verify the API is responsive
                latency = (asyncio.get_event_loop().time() - start_time) * 1000  # Convert to ms

                return HealthResponse(
                    status="healthy",
                    latency=latency,
                    model_loaded=self.empoorio_api.is_loaded,
                    timestamp=datetime.now().isoformat()
                )
            except Exception as e:
                logger.error(f"Health check failed: {e}")
                return HealthResponse(
                    status="unhealthy",
                    model_loaded=False,
                    timestamp=datetime.now().isoformat()
                )

        @self.app.get("/models", response_model=ModelsResponse)
        async def get_models():
            """Get available models."""
            try:
                # For now, return the default model
                return ModelsResponse(models=["empoorio-lm"])
            except Exception as e:
                logger.error(f"Error getting models: {e}")
                raise HTTPException(status_code=500, detail=f"Failed to get models: {str(e)}")

        @self.app.get("/health")
        async def general_health():
            """General health check."""
            return {
                "status": "healthy",
                "service": "EmpoorioLM API",
                "timestamp": datetime.now().isoformat()
            }

    def create_app(self) -> FastAPI:
        """Create and return the FastAPI app."""
        return self.app

    def start_server(self, host: str = "0.0.0.0", port: int = 8001):
        """Start the FastAPI server."""
        uvicorn.run(
            self.app,
            host=host,
            port=port,
            log_level="info"
        )


# Global instance - only create if not in standalone mode
try:
    empoorio_lm_api = EmpoorioLMAPI()
except:
    empoorio_lm_api = None


def create_empoorio_app() -> FastAPI:
    """Create EmpoorioLM FastAPI app."""
    if empoorio_lm_api:
        return empoorio_lm_api.create_app()
    else:
        # Return standalone server
        return create_standalone_server()


# Función de conveniencia
def create_empoorio_lm_api(config: EmpoorioLMApiConfig = None) -> EmpoorioLMApi:
    """
    Crear instancia de la API EmpoorioLM.

    Args:
        config: Configuración opcional

    Returns:
        Instancia de EmpoorioLMApi
    """
    return EmpoorioLMApi(config)


# Función para generación rápida
def generate_text(
    prompt: str,
    model_path: str = "./models/empoorio_lm/v1.0.0",
    **generation_kwargs
) -> str:
    """
    Función de conveniencia para generar texto rápidamente.

    Args:
        prompt: Texto de entrada
        model_path: Ruta al modelo
        **generation_kwargs: Parámetros de generación

    Returns:
        Texto generado
    """
    config = EmpoorioLMApiConfig(model_path=model_path)
    api = EmpoorioLMApi(config)

    try:
        result = api.generate_text(prompt, **generation_kwargs)
        return result["generated_text"]
    finally:
        api.unload_model()


# Standalone EmpoorioLM server
def create_standalone_server():
    """Create a standalone EmpoorioLM server without AILOOS dependencies."""
    app = FastAPI(
        title="EmpoorioLM API",
        description="Standalone API for EmpoorioLM text generation model",
        version="1.0.0"
    )

    @app.post("/generate", response_model=GenerateResponse)
    async def generate_text(request: GenerateRequest):
        """Generate text using EmpoorioLM."""
        try:
            # Mock response for now - replace with real EmpoorioLM integration
            if "hola" in request.prompt.lower() or "hello" in request.prompt.lower():
                mock_response = f"{request.prompt} ¡Hola! Soy EmpoorioLM, una IA avanzada especializada en análisis y razonamiento complejo. ¿En qué puedo ayudarte hoy?"
            elif "qué" in request.prompt.lower() or "what" in request.prompt.lower():
                mock_response = f"{request.prompt} Como EmpoorioLM, puedo ayudarte con análisis de datos, razonamiento lógico, generación de contenido creativo y resolución de problemas complejos."
            else:
                mock_response = f"{request.prompt} Gracias por tu consulta. Como EmpoorioLM, estoy aquí para proporcionarte respuestas detalladas y bien fundamentadas."

            return GenerateResponse(
                response=mock_response,
                usage={
                    "promptTokens": len(request.prompt.split()),
                    "completionTokens": len(mock_response.split()),
                    "totalTokens": len(request.prompt.split()) + len(mock_response.split())
                }
            )
        except Exception as e:
            logger.error(f"Error in generate_text endpoint: {e}")
            raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")

    @app.get("/status", response_model=HealthResponse)
    async def health_check():
        """Health check endpoint."""
        return HealthResponse(
            status="healthy",
            latency=10.5,
            model_loaded=True,
            timestamp=datetime.now().isoformat()
        )

    @app.get("/models", response_model=ModelsResponse)
    async def get_models():
        """Get available models."""
        return ModelsResponse(models=["empoorio-lm"])

    @app.get("/health")
    async def general_health():
        """General health check."""
        return {
            "status": "healthy",
            "service": "EmpoorioLM API",
            "timestamp": datetime.now().isoformat()
        }

    return app


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "server":
        # Start standalone FastAPI server
        print("🚀 Starting Standalone EmpoorioLM API Server...")
        app = create_standalone_server()
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
    else:
        print("Use 'python empoorio_api.py server' to start the API server")