"""
Tests for EmpoorioLM Service
Pruebas unitarias y de integración para el servicio completo EmpoorioLM.
"""

import pytest
import asyncio
import time
from unittest.mock import Mock, patch, AsyncMock
import torch
import numpy as np

from ..service import EmpoorioLMService, EmpoorioLMServiceConfig
from ..model_manager import ModelManagerConfig
from ..inference_engine import InferenceEngineConfig
from ..version_controller import VersionControllerConfig
from ..performance_optimizer import PerformanceOptimizerConfig
from ..version_manager import EmpoorioLMVersionManager


class TestEmpoorioLMService:
    """Test suite for EmpoorioLM Service."""

    @pytest.fixture
    def service_config(self):
        """Create test service configuration."""
        return EmpoorioLMServiceConfig(
            service_name="test_empoorio_lm_service",
            enable_health_checks=True,
            enable_metrics=True,
            models_dir="./test_models",
            auto_initialize_base_model=False,  # Disable for testing
            default_model_version="v1.0.0-test",
            model_manager=ModelManagerConfig(
                max_memory_gb=2.0,  # Small for testing
                max_models_in_memory=2,
                cache_ttl_seconds=300,
                prefer_gpu=False,  # Use CPU for testing
                enable_monitoring=False,  # Disable monitoring for tests
            ),
            inference_engine=InferenceEngineConfig(
                max_concurrent_requests=2,
                max_batch_size=2,
                request_timeout_seconds=30,
                enable_streaming=True,
                enable_dynamic_batching=False,  # Disable for simpler testing
                max_workers=1,
                enable_gpu_optimization=False,
            ),
            version_controller=VersionControllerConfig(
                max_active_versions=3,
                enable_ab_testing=False,  # Disable for testing
                enable_canary_deployments=False,
                enable_performance_monitoring=False,
            ),
            performance_optimizer=PerformanceOptimizerConfig(
                enable_auto_scaling=False,  # Disable for testing
                enable_cache_optimization=False,
                metrics_collection_interval_seconds=10,
                optimization_check_interval_seconds=30,
            )
        )

    @pytest.fixture
    async def mock_version_manager(self):
        """Create mock version manager."""
        mock_vm = Mock(spec=EmpoorioLMVersionManager)

        # Mock version info
        mock_vm.get_version_info.return_value = {
            "version_id": "test_version_1",
            "version_name": "v1.0.0-test",
            "created_at": "2025-01-01T00:00:00",
            "description": "Test version",
            "is_active": True
        }

        # Mock load_version
        mock_model = Mock()
        mock_model.generate.return_value = torch.tensor([[1, 2, 3, 4, 5]])
        mock_vm.load_version = AsyncMock(return_value=mock_model)

        return mock_vm

    @pytest.fixture
    async def service(self, service_config, mock_version_manager):
        """Create test service instance."""
        with patch('src.ailoos.coordinator.empoorio_lm.service.EmpoorioLMVersionManager', return_value=mock_version_manager):
            service = EmpoorioLMService(service_config)
            yield service

    @pytest.mark.asyncio
    async def test_service_initialization(self, service):
        """Test service initialization."""
        assert service.config.service_name == "test_empoorio_lm_service"
        assert not service.is_initialized
        assert not service.is_running

        # Test components are created
        assert service.version_manager is not None
        assert service.model_manager is not None
        assert service.inference_engine is not None
        assert service.version_controller is not None
        assert service.performance_optimizer is not None

    @pytest.mark.asyncio
    async def test_service_initialization_success(self, service):
        """Test successful service initialization."""
        # Mock the base model initialization
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            success = await service.initialize()

            assert success
            assert service.is_initialized

    @pytest.mark.asyncio
    async def test_service_initialization_failure(self, service):
        """Test service initialization failure."""
        with patch.object(service, '_initialize_base_model', return_value=False):
            success = await service.initialize()

            assert not success
            assert not service.is_initialized

    @pytest.mark.asyncio
    async def test_service_start_stop(self, service):
        """Test service start and stop."""
        # Initialize first
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()

            # Start service
            success = await service.start()
            assert success
            assert service.is_running

            # Stop service
            await service.stop()
            assert not service.is_running

    @pytest.mark.asyncio
    async def test_generate_text_success(self, service):
        """Test successful text generation."""
        # Setup service
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()
            await service.start()

            # Mock inference engine
            service.inference_engine.submit_request = AsyncMock(return_value="req_123")
            service.inference_engine.get_result = AsyncMock(return_value=Mock(
                request_id="req_123",
                output_text="Generated text",
                tokens_generated=10,
                processing_time=0.5,
                model_version="v1.0.0-test",
                metadata={}
            ))

            # Mock version controller
            service.version_controller.route_request = Mock(return_value="test_version_1")
            service.version_controller.record_request_metrics = Mock()

            # Generate text
            result = await service.generate_text("Test prompt")

            assert result is not None
            assert result["generated_text"] == "Generated text"
            assert result["tokens_generated"] == 10
            assert result["model_version"] == "v1.0.0-test"

    @pytest.mark.asyncio
    async def test_generate_text_no_active_versions(self, service):
        """Test text generation when no versions are active."""
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()
            await service.start()

            # Mock version controller to return None (no active versions)
            service.version_controller.route_request = Mock(return_value=None)

            result = await service.generate_text("Test prompt")

            assert result is None

    @pytest.mark.asyncio
    async def test_stream_generate_text(self, service):
        """Test streaming text generation."""
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()
            await service.start()

            # Mock components
            service.version_controller.route_request = Mock(return_value="test_version_1")

            # Mock streaming generator
            async def mock_stream_generator():
                yield "Hello"
                yield " world"
                yield "!"

            service.inference_engine.stream_inference = AsyncMock(return_value=mock_stream_generator())

            # Test streaming
            stream_gen = await service.stream_generate_text("Test prompt")

            chunks = []
            async for chunk in stream_gen:
                chunks.append(chunk)

            assert len(chunks) == 3
            assert chunks == ["Hello", " world", "!"]

    @pytest.mark.asyncio
    async def test_generate_batch(self, service):
        """Test batch text generation."""
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()
            await service.start()

            # Mock components
            service.version_controller.route_request = Mock(return_value="test_version_1")
            service.inference_engine.submit_batch_request = AsyncMock(return_value="batch_123")

            # Test batch generation
            batch_requests = [
                ("Prompt 1", {"temperature": 0.5}),
                ("Prompt 2", {"temperature": 0.7}),
            ]

            batch_id = await service.generate_batch(batch_requests)

            assert batch_id == "batch_123"
            service.inference_engine.submit_batch_request.assert_called_once()

    @pytest.mark.asyncio
    async def test_activate_version(self, service):
        """Test version activation."""
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()
            await service.start()

            # Mock version controller
            service.version_controller.activate_version = AsyncMock(return_value=True)

            # Test activation
            success = await service.activate_model_version("test_version_1", is_default=True)

            assert success
            service.version_controller.activate_version.assert_called_once_with(
                version_id="test_version_1",
                is_default=True,
                traffic_percentage=None
            )

    @pytest.mark.asyncio
    async def test_deactivate_version(self, service):
        """Test version deactivation."""
        with patch.object(service, '_initialize_base_model', return_value=True), \
             patch.object(service, '_activate_default_version', return_value=True):

            await service.initialize()
            await service.start()

            # Mock version controller
            service.version_controller.deactivate_version = AsyncMock(return_value=True)

            # Test deactivation
            success = await service.deactivate_model_version("test_version_1")

            assert success
            service.version_controller.deactivate_version.assert_called_once_with("test_version_1")

    def test_get_service_status(self, service):
        """Test service status retrieval."""
        # Mock components
        service.model_manager.get_stats = Mock(return_value={"models_loaded": 1})
        service.inference_engine.get_stats = Mock(return_value={"active_requests": 0})
        service.version_controller.get_active_versions_info = Mock(return_value={"total_active": 1})
        service.performance_optimizer.get_performance_report = Mock(return_value={"status": "healthy"})

        status = service.get_service_status()

        assert status["service_name"] == "test_empoorio_lm_service"
        assert "uptime_seconds" in status
        assert "active_versions" in status
        assert "performance_metrics" in status

    def test_get_service_health_healthy(self, service):
        """Test service health check when healthy."""
        # Mock components for healthy state
        service.is_initialized = True
        service.is_running = True

        service.model_manager.get_stats = Mock(return_value={"current_models_loaded": 1})
        service.inference_engine.get_stats = Mock(return_value={"is_running": True})
        service.version_controller.get_active_versions_info = Mock(return_value={"total_active": 1})

        health = service.get_service_health()

        assert health["status"] == "healthy"
        assert all(check["status"] == "pass" for check in health["checks"].values())

    def test_get_service_health_unhealthy(self, service):
        """Test service health check when unhealthy."""
        # Mock components for unhealthy state
        service.is_initialized = False
        service.is_running = False

        health = service.get_service_health()

        assert health["status"] == "unhealthy"
        assert health["checks"]["service_initialized"]["status"] == "fail"
        assert health["checks"]["service_running"]["status"] == "fail"

    def test_get_performance_report(self, service):
        """Test performance report generation."""
        # Mock performance optimizer
        service.performance_optimizer.get_performance_report = Mock(return_value={
            "current_metrics": {"cpu_usage": 50.0},
            "averages_last_10": {"response_time": 100.0}
        })

        report = service.get_performance_report()

        assert "current_metrics" in report
        assert "averages_last_10" in report

    def test_get_optimization_recommendations(self, service):
        """Test optimization recommendations."""
        # Mock performance optimizer
        service.performance_optimizer.get_optimization_recommendations = Mock(return_value=[
            {
                "type": "memory_optimization",
                "priority": "high",
                "description": "Memory usage is high"
            }
        ])

        recommendations = service.get_optimization_recommendations()

        assert len(recommendations) == 1
        assert recommendations[0]["type"] == "memory_optimization"


class TestEmpoorioLMServiceIntegration:
    """Integration tests for EmpoorioLM Service."""

    @pytest.mark.asyncio
    async def test_full_service_lifecycle(self):
        """Test complete service lifecycle."""
        config = EmpoorioLMServiceConfig(
            service_name="integration_test_service",
            auto_initialize_base_model=False,
            model_manager=ModelManagerConfig(
                max_memory_gb=1.0,
                max_models_in_memory=1,
                prefer_gpu=False,
                enable_monitoring=False,
            ),
            inference_engine=InferenceEngineConfig(
                max_concurrent_requests=1,
                enable_dynamic_batching=False,
                max_workers=1,
                enable_gpu_optimization=False,
            ),
            version_controller=VersionControllerConfig(
                max_active_versions=2,
                enable_performance_monitoring=False,
            ),
            performance_optimizer=PerformanceOptimizerConfig(
                enable_auto_scaling=False,
                metrics_collection_interval_seconds=60,  # Longer for tests
                optimization_check_interval_seconds=120,
            )
        )

        # Create service with mocked version manager
        with patch('src.ailoos.coordinator.empoorio_lm.service.EmpoorioLMVersionManager') as mock_vm_class:
            mock_vm = Mock()
            mock_vm_class.return_value = mock_vm

            service = EmpoorioLMService(config)

            # Test initialization (will fail due to mocking, but tests structure)
            assert service.config.service_name == "integration_test_service"
            assert not service.is_initialized

            # Test that all components are properly initialized
            assert service.version_manager is not None
            assert service.model_manager is not None
            assert service.inference_engine is not None
            assert service.version_controller is not None
            assert service.performance_optimizer is not None

    @pytest.mark.asyncio
    async def test_concurrent_requests(self):
        """Test handling of concurrent requests."""
        config = EmpoorioLMServiceConfig(
            inference_engine=InferenceEngineConfig(
                max_concurrent_requests=3,
                max_workers=2,
            )
        )

        with patch('src.ailoos.coordinator.empoorio_lm.service.EmpoorioLMVersionManager'):
            service = EmpoorioLMService(config)

            # This would require more complex mocking for full concurrent testing
            # For now, just verify the configuration is applied
            assert service.inference_engine.config.max_concurrent_requests == 3
            assert service.inference_engine.config.max_workers == 2


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])