"""
EmpoorioLM Model Manager
Sistema de gestión de modelos en memoria para el servicio EmpoorioLM.
"""

import asyncio
import time
import torch
import threading
from typing import Dict, List, Any, Optional, Tuple
from collections import OrderedDict
import logging
from dataclasses import dataclass, field
from datetime import datetime
import psutil
try:
    import GPUtil
    GPU_UTIL_AVAILABLE = True
except ImportError:
    GPU_UTIL_AVAILABLE = False
    GPUtil = None

from ...models.empoorio_lm import EmpoorioLM
from .version_manager import EmpoorioLMVersionManager

logger = logging.getLogger(__name__)


@dataclass
class ModelInstance:
    """Instancia de modelo cargada en memoria."""

    model: EmpoorioLM
    tokenizer: Any
    version_id: str
    loaded_at: float
    last_used: float
    memory_usage: int  # En bytes
    device: str  # 'cpu' o 'cuda:X'
    usage_count: int = 0
    is_active: bool = True


@dataclass
class ModelManagerConfig:
    """Configuración del Model Manager."""

    # Límites de memoria
    max_memory_gb: float = 8.0  # Memoria máxima para modelos
    max_models_in_memory: int = 3  # Máximo número de modelos simultáneos

    # Configuración de cache
    cache_ttl_seconds: int = 3600  # TTL para modelos inactivos
    lru_eviction_enabled: bool = True

    # Configuración de dispositivo
    prefer_gpu: bool = True
    gpu_memory_fraction: float = 0.8  # Fracción de GPU a usar

    # Monitoreo
    enable_monitoring: bool = True
    monitoring_interval_seconds: int = 60


class ModelManager:
    """
    Gestor de modelos EmpoorioLM en memoria.

    Funcionalidades:
    - Cache LRU de modelos
    - Gestión automática de memoria
    - Balanceo entre GPU/CPU
    - Monitoreo de rendimiento
    - Carga lazy de modelos
    """

    def __init__(self, config: ModelManagerConfig, version_manager: EmpoorioLMVersionManager):
        self.config = config
        self.version_manager = version_manager

        # Cache de modelos: version_id -> ModelInstance
        self.model_cache: OrderedDict[str, ModelInstance] = OrderedDict()

        # Estadísticas
        self.stats = {
            "total_models_loaded": 0,
            "total_models_evicted": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "memory_peak_usage": 0,
            "gpu_memory_peak": 0
        }

        # Locks para thread safety
        self.cache_lock = threading.RLock()

        # Monitoreo
        self.monitoring_active = False
        self.monitoring_thread: Optional[threading.Thread] = None

        # Inicializar dispositivo
        self._initialize_device()

        logger.info(f"🧠 Model Manager inicializado - Device: {self.device}")

    def _initialize_device(self):
        """Inicializar dispositivo preferido (GPU/CPU)."""
        if self.config.prefer_gpu and torch.cuda.is_available():
            # Seleccionar GPU con más memoria disponible
            if GPU_UTIL_AVAILABLE:
                try:
                    gpus = GPUtil.getGPUs()
                    if gpus:
                        # Ordenar por memoria libre
                        best_gpu = max(gpus, key=lambda gpu: gpu.memoryFree)
                        self.device = f"cuda:{best_gpu.id}"

                        # Configurar fracción de memoria
                        torch.cuda.set_per_process_memory_fraction(self.config.gpu_memory_fraction)
                        torch.cuda.empty_cache()

                        logger.info(f"🎮 GPU seleccionada: {best_gpu.name} ({best_gpu.memoryFree}MB libre)")
                        return
                except Exception as e:
                    logger.warning(f"Error inicializando GPU: {e}")
            else:
                # Fallback: usar primera GPU disponible
                self.device = "cuda:0"
                torch.cuda.set_per_process_memory_fraction(self.config.gpu_memory_fraction)
                torch.cuda.empty_cache()
                logger.info("🎮 GPU seleccionada: cuda:0 (GPUtil no disponible)")
                return

        # Fallback a CPU
        self.device = "cpu"
        logger.info("💻 Usando CPU para inferencia")

    async def get_model(self, version_id: str) -> Optional[Tuple[EmpoorioLM, Any]]:
        """
        Obtener modelo y tokenizer desde cache o cargar desde disco.

        Args:
            version_id: ID de la versión del modelo

        Returns:
            Tupla de (modelo, tokenizer) o None si no se pudo cargar
        """
        with self.cache_lock:
            # Verificar si está en cache
            if version_id in self.model_cache:
                instance = self.model_cache[version_id]
                instance.last_used = time.time()
                instance.usage_count += 1
                self.stats["cache_hits"] += 1

                # Mover al final (LRU)
                self.model_cache.move_to_end(version_id)

                logger.debug(f"✅ Cache hit para modelo {version_id}")
                return instance.model, instance.tokenizer

            self.stats["cache_misses"] += 1

        # No está en cache, cargar desde disco
        return await self._load_model(version_id)

    async def _load_model(self, version_id: str) -> Optional[Tuple[EmpoorioLM, Any]]:
        """
        Cargar modelo y tokenizer desde disco y añadir al cache.

        Args:
            version_id: ID de la versión

        Returns:
            Tupla de (modelo, tokenizer) o None si falló
        """
        try:
            # Verificar si hay espacio en cache
            if len(self.model_cache) >= self.config.max_models_in_memory:
                await self._evict_oldest_model()

            # Cargar información de la versión para obtener metadatos
            version_info = self.version_manager.get_version_info(version_id)
            if not version_info:
                logger.error(f"❌ No se encontró información para la versión: {version_id}")
                return None

            # Cargar modelo
            model = await self.version_manager.load_version(version_id)
            if model is None:
                logger.error(f"❌ No se pudo cargar el modelo {version_id}")
                return None

            # Cargar tokenizer
            from transformers import AutoTokenizer
            tokenizer = None
            try:
                # El nombre del modelo base (ej. 'gpt2') debería estar en los metadatos
                base_model_name = version_info.get("metadata", {}).get("base_model", "gpt2")
                tokenizer = AutoTokenizer.from_pretrained(base_model_name)
                logger.info(f"✅ Tokenizer cargado para {version_id} (base: {base_model_name})")
            except Exception as e:
                logger.error(f"❌ Error al cargar el tokenizer para {version_id}: {e}")
                return None # No se puede proceder sin tokenizer

            # Mover a dispositivo
            model = model.to(self.device)
            model.eval()  # Modo evaluación

            # Calcular uso de memoria
            memory_usage = self._calculate_model_memory(model)

            # Verificar límites de memoria
            if not self._check_memory_limits(memory_usage):
                logger.error(f"❌ Modelo {version_id} excede límites de memoria")
                del model
                torch.cuda.empty_cache()
                return None

            # Crear instancia
            instance = ModelInstance(
                model=model,
                tokenizer=tokenizer,
                version_id=version_id,
                loaded_at=time.time(),
                last_used=time.time(),
                memory_usage=memory_usage,
                device=self.device
            )

            # Añadir al cache
            with self.cache_lock:
                self.model_cache[version_id] = instance
                self.stats["total_models_loaded"] += 1

            # Actualizar estadísticas de memoria
            self._update_memory_stats()

            logger.info(f"📥 Modelo cargado: {version_id} ({memory_usage / (1024**3):.2f}GB)")
            return model, tokenizer

        except Exception as e:
            logger.error(f"❌ Error cargando modelo {version_id}: {e}")
            return None

    def _calculate_model_memory(self, model: EmpoorioLM) -> int:
        """Calcular uso de memoria del modelo en bytes."""
        total_params = sum(p.numel() for p in model.parameters())
        # Estimación: 4 bytes por parámetro (float32) + overhead
        memory_bytes = total_params * 4 * 1.2  # 20% overhead

        # Añadir memoria de buffers y optimizador si aplica
        buffer_memory = sum(b.numel() * b.element_size() for b in model.buffers())
        memory_bytes += buffer_memory

        return int(memory_bytes)

    def _check_memory_limits(self, new_model_memory: int) -> bool:
        """Verificar si el nuevo modelo cabe en memoria."""
        current_memory = sum(inst.memory_usage for inst in self.model_cache.values())

        if self.device.startswith("cuda"):
            # Verificar memoria GPU
            if GPU_UTIL_AVAILABLE:
                try:
                    gpu_id = int(self.device.split(":")[1])
                    gpu = GPUtil.getGPUs()[gpu_id]
                    available_memory = gpu.memoryFree * (1024**2)  # Convertir a bytes
                    max_allowed = available_memory * self.config.gpu_memory_fraction

                    if current_memory + new_model_memory > max_allowed:
                        logger.warning("⚠️ Modelo excede límite de memoria GPU")
                        return False
                except Exception as e:
                    logger.warning(f"Error verificando memoria GPU: {e}")
                    return False
            else:
                # Sin GPUtil, usar estimación de PyTorch
                try:
                    allocated = torch.cuda.memory_allocated()
                    reserved = torch.cuda.memory_reserved()
                    total = torch.cuda.get_device_properties(0).total_memory
                    available = total - max(allocated, reserved)
                    max_allowed = available * self.config.gpu_memory_fraction

                    if current_memory + new_model_memory > max_allowed:
                        logger.warning("⚠️ Modelo excede límite de memoria GPU (estimación)")
                        return False
                except Exception as e:
                    logger.warning(f"Error verificando memoria GPU con PyTorch: {e}")
                    return False
        else:
            # Verificar memoria sistema
            system_memory = psutil.virtual_memory()
            available_memory = system_memory.available
            max_allowed = self.config.max_memory_gb * (1024**3)

            if current_memory + new_model_memory > max_allowed:
                logger.warning("⚠️ Modelo excede límite de memoria sistema")
                return False

        return True

    async def _evict_oldest_model(self):
        """Evictar el modelo menos recientemente usado."""
        if not self.model_cache:
            return

        with self.cache_lock:
            # Encontrar el menos usado (primero en OrderedDict)
            oldest_version, oldest_instance = next(iter(self.model_cache.items()))

            # Remover del cache
            del self.model_cache[oldest_version]

            # Liberar memoria
            del oldest_instance.model
            torch.cuda.empty_cache()

            self.stats["total_models_evicted"] += 1

            logger.info(f"🗑️ Modelo evitado: {oldest_version}")

    def _update_memory_stats(self):
        """Actualizar estadísticas de uso de memoria."""
        current_memory = sum(inst.memory_usage for inst in self.model_cache.values())
        self.stats["memory_peak_usage"] = max(self.stats["memory_peak_usage"], current_memory)

        if self.device.startswith("cuda"):
            try:
                gpu_memory = torch.cuda.memory_allocated()
                self.stats["gpu_memory_peak"] = max(self.stats["gpu_memory_peak"], gpu_memory)
            except:
                pass

    async def preload_model(self, version_id: str) -> bool:
        """
        Precargar un modelo en cache.

        Args:
            version_id: ID de la versión a precargar

        Returns:
            True si se precargó correctamente
        """
        if version_id in self.model_cache:
            return True  # Ya está cargado

        model = await self._load_model(version_id)
        return model is not None

    async def unload_model(self, version_id: str) -> bool:
        """
        Descargar un modelo del cache.

        Args:
            version_id: ID de la versión a descargar

        Returns:
            True si se descargó correctamente
        """
        with self.cache_lock:
            if version_id not in self.model_cache:
                return False

            instance = self.model_cache[version_id]
            del self.model_cache[version_id]
            del instance.model
            torch.cuda.empty_cache()

            logger.info(f"📤 Modelo descargado: {version_id}")
            return True

    def get_cache_info(self) -> Dict[str, Any]:
        """Obtener información del estado del cache."""
        with self.cache_lock:
            cache_info = {
                "models_in_cache": len(self.model_cache),
                "max_models": self.config.max_models_in_memory,
                "cache_size_mb": sum(inst.memory_usage for inst in self.model_cache.values()) / (1024**2),
                "models": []
            }

            for version_id, instance in self.model_cache.items():
                cache_info["models"].append({
                    "version_id": version_id,
                    "loaded_at": datetime.fromtimestamp(instance.loaded_at).isoformat(),
                    "last_used": datetime.fromtimestamp(instance.last_used).isoformat(),
                    "usage_count": instance.usage_count,
                    "memory_mb": instance.memory_usage / (1024**2),
                    "device": instance.device
                })

            return cache_info

    def get_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del Model Manager."""
        base_stats = self.stats.copy()

        # Añadir información en tiempo real
        with self.cache_lock:
            base_stats.update({
                "current_models_loaded": len(self.model_cache),
                "current_memory_usage_mb": sum(inst.memory_usage for inst in self.model_cache.values()) / (1024**2),
                "device": self.device,
                "cache_hit_rate": (
                    self.stats["cache_hits"] /
                    max(1, self.stats["cache_hits"] + self.stats["cache_misses"])
                )
            })

        return base_stats

    def start_monitoring(self):
        """Iniciar monitoreo en background."""
        if self.monitoring_active:
            return

        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

        logger.info("📊 Monitoreo de Model Manager iniciado")

    def stop_monitoring(self):
        """Detener monitoreo."""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)

        logger.info("📊 Monitoreo de Model Manager detenido")

    def _monitoring_loop(self):
        """Loop de monitoreo en background."""
        while self.monitoring_active:
            try:
                # Limpiar modelos expirados
                self._cleanup_expired_models()

                # Log de estado periódico
                if len(self.model_cache) > 0:
                    cache_info = self.get_cache_info()
                    logger.debug(f"📊 Cache status: {cache_info['models_in_cache']} modelos, "
                               f"{cache_info['cache_size_mb']:.1f}MB")

            except Exception as e:
                logger.error(f"Error en monitoreo: {e}")

            time.sleep(self.config.monitoring_interval_seconds)

    def _cleanup_expired_models(self):
        """Limpiar modelos expirados del cache."""
        current_time = time.time()
        expired_versions = []

        with self.cache_lock:
            for version_id, instance in self.model_cache.items():
                if (current_time - instance.last_used) > self.config.cache_ttl_seconds:
                    expired_versions.append(version_id)

        # Evitar fuera del lock para no bloquear
        for version_id in expired_versions:
            asyncio.run(self.unload_model(version_id))
            logger.info(f"⏰ Modelo expirado removido: {version_id}")

    async def optimize_memory(self):
        """Optimizar uso de memoria."""
        # Evitar modelos poco usados si hay presión de memoria
        if len(self.model_cache) > self.config.max_models_in_memory * 0.8:
            await self._evict_oldest_model()

        # Liberar cache de GPU si es necesario
        if self.device.startswith("cuda"):
            torch.cuda.empty_cache()

        logger.info("🧹 Memoria optimizada")


# Funciones de conveniencia
def create_model_manager(
    version_manager: EmpoorioLMVersionManager,
    config: Optional[ModelManagerConfig] = None
) -> ModelManager:
    """Crear instancia del Model Manager."""
    if config is None:
        config = ModelManagerConfig()

    manager = ModelManager(config, version_manager)

    # Iniciar monitoreo si está habilitado
    if config.enable_monitoring:
        manager.start_monitoring()

    return manager