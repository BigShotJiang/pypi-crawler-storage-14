"""Add Discord and webhook integrations to apps_connectors_settings

Revision ID: add_discord_webhook_integrations
Revises: partitioning_setup
Create Date: 2025-11-11 10:03:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'add_discord_webhook_integrations'
down_revision = 'partitioning_setup'
branch_labels = None
depends_on = None


def upgrade():
    # Add new columns to apps_connectors_settings table
    op.add_column('apps_connectors_settings', sa.Column('discord_bot_token', sa.String(255), nullable=True))
    op.add_column('apps_connectors_settings', sa.Column('discord_server_id', sa.String(50), nullable=True))
    op.add_column('apps_connectors_settings', sa.Column('discord_channel_id', sa.String(50), nullable=True))
    op.add_column('apps_connectors_settings', sa.Column('discord_webhook_url', sa.String(500), nullable=True))
    op.add_column('apps_connectors_settings', sa.Column('webhook_headers', sa.Text(), nullable=True))
    op.add_column('apps_connectors_settings', sa.Column('webhook_method', sa.String(10), nullable=False, server_default='POST'))
    op.add_column('apps_connectors_settings', sa.Column('webhook_enabled', sa.Boolean(), nullable=False, server_default='false'))

    # Add check constraint for webhook_method
    op.create_check_constraint(
        'check_webhook_method',
        'apps_connectors_settings',
        "webhook_method IN ('GET', 'POST', 'PUT', 'PATCH', 'DELETE')"
    )


def downgrade():
    # Remove check constraint
    op.drop_constraint('check_webhook_method', 'apps_connectors_settings', type_='check')

    # Remove added columns
    op.drop_column('apps_connectors_settings', 'webhook_enabled')
    op.drop_column('apps_connectors_settings', 'webhook_method')
    op.drop_column('apps_connectors_settings', 'webhook_headers')
    op.drop_column('apps_connectors_settings', 'discord_webhook_url')
    op.drop_column('apps_connectors_settings', 'discord_channel_id')
    op.drop_column('apps_connectors_settings', 'discord_server_id')
    op.drop_column('apps_connectors_settings', 'discord_bot_token')