"""
Model Quality Monitor - Monitoreo de calidad y detección de drift
Sistema de monitoreo continuo para detectar degradación de rendimiento y drift de datos.
"""

import asyncio
import time
import json
import statistics
from typing import Dict, List, Any, Optional, Callable, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict, deque

from ...core.logging import get_logger
from ...federated.rollback_coordinator import RollbackCoordinator, RollbackTrigger
from ...federated.privacy_preserving_aggregator import PrivacyPreservingAggregator
from .model_registry import ModelRegistry
from .model_lifecycle_manager import ModelLifecycleManager, LifecycleTransition

logger = get_logger(__name__)


class DriftType(Enum):
    """Tipos de drift detectados."""
    CONCEPT_DRIFT = "concept_drift"  # Cambio en la relación entre features y target
    DATA_DRIFT = "data_drift"  # Cambio en la distribución de features
    PERFORMANCE_DRIFT = "performance_drift"  # Degradación general del rendimiento
    PREDICTION_DRIFT = "prediction_drift"  # Cambio en la distribución de predicciones


class AlertSeverity(Enum):
    """Severidad de alertas."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class QualityMetrics:
    """Métricas de calidad recopiladas."""
    timestamp: int
    accuracy: Optional[float] = None
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1_score: Optional[float] = None
    loss: Optional[float] = None
    latency_ms: Optional[float] = None
    throughput: Optional[float] = None
    error_rate: Optional[float] = None
    custom_metrics: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'timestamp': self.timestamp,
            'accuracy': self.accuracy,
            'precision': self.precision,
            'recall': self.recall,
            'f1_score': self.f1_score,
            'loss': self.loss,
            'latency_ms': self.latency_ms,
            'throughput': self.throughput,
            'error_rate': self.error_rate,
            'custom_metrics': self.custom_metrics
        }


@dataclass
class DriftDetection:
    """Detección de drift."""
    drift_type: DriftType
    severity: AlertSeverity
    confidence: float
    detected_at: int
    description: str
    metrics_before: Dict[str, Any]
    metrics_after: Dict[str, Any]
    statistical_test: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'drift_type': self.drift_type.value,
            'severity': self.severity.value,
            'confidence': self.confidence,
            'detected_at': self.detected_at,
            'description': self.description,
            'metrics_before': self.metrics_before,
            'metrics_after': self.metrics_after,
            'statistical_test': self.statistical_test
        }


@dataclass
class QualityAlert:
    """Alerta de calidad."""
    model_name: str
    alert_type: str
    severity: AlertSeverity
    message: str
    triggered_at: int
    resolved_at: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'model_name': self.model_name,
            'alert_type': self.alert_type,
            'severity': self.severity.value,
            'message': self.message,
            'triggered_at': self.triggered_at,
            'resolved_at': self.resolved_at,
            'metadata': self.metadata
        }


class ModelQualityMonitor:
    """
    Monitor de calidad para modelos en producción.
    Detecta drift, degradación de rendimiento y genera alertas automáticas.
    """

    def __init__(self, registry: ModelRegistry,
                 lifecycle_manager: ModelLifecycleManager,
                 rollback_coordinator: RollbackCoordinator,
                 privacy_preserving_aggregator: PrivacyPreservingAggregator = None,
                 monitoring_window_hours: int = 24,
                 check_interval_minutes: int = 15):
        """
        Inicializar el monitor de calidad.

        Args:
            registry: Registro de modelos
            lifecycle_manager: Gestor del ciclo de vida
            rollback_coordinator: Coordinador de rollbacks
            privacy_preserving_aggregator: Agregador con preservación de privacidad
            monitoring_window_hours: Ventana de monitoreo en horas
            check_interval_minutes: Intervalo entre checks en minutos
        """
        self.registry = registry
        self.lifecycle_manager = lifecycle_manager
        self.rollback_coordinator = rollback_coordinator
        self.privacy_preserving_aggregator = privacy_preserving_aggregator

        # Configuración de monitoreo
        self.monitoring_window_seconds = monitoring_window_hours * 3600
        self.check_interval_seconds = check_interval_minutes * 60

        # Almacenamiento de métricas (model_name -> deque de métricas)
        self.metrics_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))

        # Estado de alertas activas
        self.active_alerts: Dict[str, List[QualityAlert]] = defaultdict(list)

        # Historial de detecciones de drift
        self.drift_history: Dict[str, List[DriftDetection]] = defaultdict(list)

        # Configuración de thresholds
        self.drift_thresholds = {
            'performance_drop_threshold': 0.05,  # 5% drop
            'statistical_significance': 0.95,  # 95% confidence
            'min_samples_for_drift': 100,
            'max_consecutive_failures': 3
        }

        # Callbacks para alertas
        self.alert_callbacks: List[Callable] = []

        # Tarea de monitoreo
        self.monitoring_task: Optional[asyncio.Task] = None
        self.is_running = False

        # Estadísticas
        self.stats = {
            'total_checks': 0,
            'drift_detections': 0,
            'alerts_triggered': 0,
            'auto_rollbacks': 0
        }

        logger.info("🚀 ModelQualityMonitor initialized")

    async def start_monitoring(self):
        """Iniciar monitoreo continuo."""
        if self.is_running:
            return

        self.is_running = True
        self.monitoring_task = asyncio.create_task(self._continuous_monitoring())

        logger.info("👀 Started continuous quality monitoring")

    async def stop_monitoring(self):
        """Detener monitoreo."""
        if not self.is_running:
            return

        self.is_running = False
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass

        logger.info("🛑 Stopped quality monitoring")

    async def report_metrics(self, model_name: str, metrics: QualityMetrics) -> bool:
        """
        Reportar métricas de calidad para un modelo.

        Args:
            model_name: Nombre del modelo
            metrics: Métricas reportadas

        Returns:
            True si las métricas fueron aceptadas
        """
        try:
            # Verificar que el modelo existe y está en producción
            active_version = await self.registry.get_active_version(model_name)
            if not active_version:
                logger.warning(f"Received metrics for inactive model {model_name}")
                return False

            # Almacenar métricas
            self.metrics_history[model_name].append(metrics)

            # Integrar métricas federadas si está disponible
            if self.privacy_preserving_aggregator:
                await self._integrate_federated_metrics(model_name, metrics)

            # Verificar calidad inmediatamente
            await self._check_model_quality(model_name)

            logger.debug(f"📊 Metrics reported for {model_name}: accuracy={metrics.accuracy}")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to report metrics for {model_name}: {e}")
            return False

    async def _integrate_federated_metrics(self, model_name: str, metrics: QualityMetrics):
        """
        Integrar métricas del sistema federado para monitoreo de calidad.

        Args:
            model_name: Nombre del modelo
            metrics: Métricas locales reportadas
        """
        try:
            # Obtener estado del agregador federado
            aggregator_status = self.privacy_preserving_aggregator.get_aggregation_status()

            # Si hay resultados de agregación recientes, integrar métricas federadas
            if aggregator_status.get('latest_aggregation', {}).get('success'):
                global_model = await self.privacy_preserving_aggregator.get_global_model()
                if global_model:
                    # Calcular métricas federadas adicionales
                    federated_metrics = await self._calculate_federated_metrics(model_name, global_model)

                    # Fusionar métricas locales con federadas
                    if federated_metrics:
                        # Agregar métricas federadas a las métricas personalizadas
                        metrics.custom_metrics.update({
                            'federated_accuracy': federated_metrics.get('accuracy'),
                            'federated_loss': federated_metrics.get('loss'),
                            'federated_participants': aggregator_status['latest_aggregation']['num_participants'],
                            'federated_round': aggregator_status['current_round']
                        })

                        logger.debug(f"🔗 Integrated federated metrics for {model_name}")

        except Exception as e:
            logger.warning(f"⚠️ Failed to integrate federated metrics for {model_name}: {e}")

    async def _calculate_federated_metrics(self, model_name: str, global_model: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calcular métricas adicionales basadas en el modelo global federado.

        Args:
            model_name: Nombre del modelo
            global_model: Modelo global del agregador federado

        Returns:
            Diccionario con métricas federadas
        """
        # Placeholder - en producción calcularía métricas reales del modelo global
        # Por ejemplo: evaluar en un conjunto de validación común
        return {
            'accuracy': 0.85,  # Placeholder
            'loss': 0.25,      # Placeholder
            'federated_score': 0.90
        }

    async def _continuous_monitoring(self):
        """Monitoreo continuo de calidad."""
        logger.info("🔄 Starting continuous quality monitoring loop")

        while self.is_running:
            try:
                await self._perform_quality_checks()
                await asyncio.sleep(self.check_interval_seconds)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Monitoring error: {e}")
                await asyncio.sleep(30)  # Esperar antes de reintentar

    async def _perform_quality_checks(self):
        """Realizar checks de calidad para todos los modelos activos."""
        try:
            # Obtener modelos en producción
            active_models = await self.registry.list_models(status_filter="active")

            for model_info in active_models:
                model_name = model_info['model_name']
                await self._check_model_quality(model_name)

            self.stats['total_checks'] += 1

        except Exception as e:
            logger.error(f"❌ Quality check error: {e}")

    async def _check_model_quality(self, model_name: str):
        """Verificar calidad de un modelo específico."""
        metrics_history = self.metrics_history.get(model_name, deque())
        if len(metrics_history) < self.drift_thresholds['min_samples_for_drift']:
            return  # Insuficientes datos

        try:
            # Detectar diferentes tipos de drift
            await self._detect_performance_drift(model_name, metrics_history)
            await self._detect_data_drift(model_name, metrics_history)
            await self._detect_prediction_drift(model_name, metrics_history)

            # Verificar alertas activas
            await self._check_active_alerts(model_name)

        except Exception as e:
            logger.error(f"❌ Quality check failed for {model_name}: {e}")

    async def _detect_performance_drift(self, model_name: str, metrics_history: deque):
        """Detectar drift de rendimiento."""
        if len(metrics_history) < 2:
            return

        # Obtener métricas recientes vs baseline
        recent_metrics = list(metrics_history)[-10:]  # Últimas 10 mediciones
        baseline_metrics = list(metrics_history)[:-10]  # Resto como baseline

        if len(baseline_metrics) < 10:
            return

        # Calcular promedios
        recent_accuracy = statistics.mean(m.accuracy for m in recent_metrics if m.accuracy)
        baseline_accuracy = statistics.mean(m.accuracy for m in baseline_metrics if m.accuracy)

        if recent_accuracy and baseline_accuracy:
            accuracy_drop = baseline_accuracy - recent_accuracy

            if accuracy_drop > self.drift_thresholds['performance_drop_threshold']:
                # Calcular confianza estadística (simplificada)
                confidence = min(1.0, accuracy_drop / 0.1)  # Normalizado

                drift = DriftDetection(
                    drift_type=DriftType.PERFORMANCE_DRIFT,
                    severity=AlertSeverity.HIGH if accuracy_drop > 0.1 else AlertSeverity.MEDIUM,
                    confidence=confidence,
                    detected_at=int(time.time()),
                    description=f"Performance degradation detected: accuracy dropped by {accuracy_drop:.2%}",
                    metrics_before={'accuracy': baseline_accuracy},
                    metrics_after={'accuracy': recent_accuracy}
                )

                await self._handle_drift_detection(model_name, drift)

    async def _detect_data_drift(self, model_name: str, metrics_history: deque):
        """Detectar drift de datos basado en cambios en distribución."""
        # Placeholder - en producción implementaría tests estadísticos
        # como Kolmogorov-Smirnov o Population Stability Index
        pass

    async def _detect_prediction_drift(self, model_name: str, metrics_history: deque):
        """Detectar drift en distribución de predicciones."""
        # Placeholder - monitorearía cambios en la distribución de outputs
        pass

    async def _handle_drift_detection(self, model_name: str, drift: DriftDetection):
        """Manejar detección de drift."""
        # Registrar drift
        self.drift_history[model_name].append(drift)
        self.stats['drift_detections'] += 1

        # Generar alerta
        alert = QualityAlert(
            model_name=model_name,
            alert_type=f"{drift.drift_type.value}_detected",
            severity=drift.severity,
            message=drift.description,
            triggered_at=drift.detected_at,
            metadata=drift.to_dict()
        )

        self.active_alerts[model_name].append(alert)
        self.stats['alerts_triggered'] += 1

        # Notificar callbacks
        await self._notify_alert_callbacks(alert)

        # Trigger automático de rollback si es crítico
        if drift.severity in [AlertSeverity.HIGH, AlertSeverity.CRITICAL]:
            await self._trigger_auto_rollback(model_name, drift)

        logger.warning(f"🚨 Drift detected for {model_name}: {drift.description}")

    async def _trigger_auto_rollback(self, model_name: str, drift: DriftDetection):
        """Trigger rollback automático por drift crítico."""
        try:
            # Obtener versión activa
            active_version = await self.registry.get_active_version(model_name)
            if not active_version:
                return

            # Buscar versión anterior adecuada
            versions = await self.registry.get_model_versions(model_name)
            if len(versions) < 2:
                logger.warning(f"No previous version available for rollback of {model_name}")
                return

            # Usar la penúltima versión
            rollback_version = versions[-2]

            # Trigger rollback
            rollback_id = await self.rollback_coordinator.trigger_rollback(
                from_version=active_version.version_id,
                to_version=rollback_version.version_id,
                trigger=RollbackTrigger.PERFORMANCE_DEGRADATION,
                reason=f"Auto-rollback due to {drift.drift_type.value}: {drift.description}",
                affected_nodes=["all_nodes"]  # Placeholder
            )

            self.stats['auto_rollbacks'] += 1
            logger.info(f"🔄 Auto-rollback triggered for {model_name}: {active_version.version_id} -> {rollback_version.version_id}")

        except Exception as e:
            logger.error(f"❌ Auto-rollback failed for {model_name}: {e}")

    async def _check_active_alerts(self, model_name: str):
        """Verificar y resolver alertas activas."""
        active_alerts = self.active_alerts.get(model_name, [])
        resolved_alerts = []

        for alert in active_alerts:
            # Verificar si la alerta se ha resuelto
            if await self._is_alert_resolved(model_name, alert):
                alert.resolved_at = int(time.time())
                resolved_alerts.append(alert)
                logger.info(f"✅ Alert resolved for {model_name}: {alert.message}")

        # Remover alertas resueltas
        for resolved in resolved_alerts:
            active_alerts.remove(resolved)

    async def _is_alert_resolved(self, model_name: str, alert: QualityAlert) -> bool:
        """Verificar si una alerta se ha resuelto."""
        # Lógica simplificada: resolver después de 1 hora o si el rendimiento mejora
        if time.time() - alert.triggered_at > 3600:  # 1 hora
            return True

        # Verificar si el rendimiento ha vuelto a niveles normales
        metrics_history = self.metrics_history.get(model_name, deque())
        if len(metrics_history) >= 5:
            recent_accuracies = [m.accuracy for m in list(metrics_history)[-5:] if m.accuracy]
            if recent_accuracies:
                avg_recent = statistics.mean(recent_accuracies)
                # Resolver si accuracy > 0.8 (threshold arbitrario)
                if avg_recent > 0.8:
                    return True

        return False

    async def _notify_alert_callbacks(self, alert: QualityAlert):
        """Notificar callbacks de alertas."""
        for callback in self.alert_callbacks:
            try:
                await callback(alert)
            except Exception as e:
                logger.warning(f"Alert callback failed: {e}")

    def add_alert_callback(self, callback: Callable):
        """Agregar callback para alertas."""
        self.alert_callbacks.append(callback)

    async def get_model_metrics(self, model_name: str, hours: int = 24) -> List[QualityMetrics]:
        """Obtener métricas recientes de un modelo."""
        metrics_history = self.metrics_history.get(model_name, deque())
        cutoff_time = time.time() - (hours * 3600)

        return [m for m in metrics_history if m.timestamp > cutoff_time]

    async def get_active_alerts(self, model_name: Optional[str] = None) -> List[QualityAlert]:
        """Obtener alertas activas."""
        if model_name:
            return self.active_alerts.get(model_name, [])
        else:
            # Todas las alertas activas
            all_alerts = []
            for alerts in self.active_alerts.values():
                all_alerts.extend(alerts)
            return all_alerts

    async def get_drift_history(self, model_name: str, days: int = 7) -> List[DriftDetection]:
        """Obtener historial de drift de un modelo."""
        drift_history = self.drift_history.get(model_name, [])
        cutoff_time = time.time() - (days * 24 * 3600)

        return [d for d in drift_history if d.detected_at > cutoff_time]

    def update_drift_thresholds(self, thresholds: Dict[str, Any]):
        """Actualizar thresholds de detección de drift."""
        self.drift_thresholds.update(thresholds)
        logger.info(f"⚙️ Updated drift thresholds: {thresholds}")

    def get_monitoring_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de monitoreo."""
        total_alerts = sum(len(alerts) for alerts in self.active_alerts.values())
        total_drift_detections = sum(len(drifts) for drifts in self.drift_history.values())

        stats = {
            'is_running': self.is_running,
            'total_checks': self.stats['total_checks'],
            'drift_detections': self.stats['drift_detections'],
            'alerts_triggered': self.stats['alerts_triggered'],
            'auto_rollbacks': self.stats['auto_rollbacks'],
            'active_alerts': total_alerts,
            'total_drift_history': total_drift_detections,
            'monitored_models': len(self.metrics_history),
            'drift_thresholds': self.drift_thresholds
        }

        # Agregar estadísticas del agregador federado si está disponible
        if self.privacy_preserving_aggregator:
            federated_stats = self.privacy_preserving_aggregator.get_aggregation_stats()
            stats['federated_aggregator'] = {
                'connected': True,
                'total_aggregations': federated_stats.get('total_aggregations', 0),
                'current_round': federated_stats.get('current_round', 0),
                'pending_updates': federated_stats.get('pending_updates', 0),
                'success_rate': federated_stats.get('success_rate', 0.0)
            }
        else:
            stats['federated_aggregator'] = {'connected': False}

        return stats

    async def force_quality_check(self, model_name: str) -> Dict[str, Any]:
        """Forzar check de calidad para un modelo."""
        metrics_history = self.metrics_history.get(model_name, deque())

        if not metrics_history:
            return {'status': 'no_data', 'message': 'No metrics available for model'}

        await self._check_model_quality(model_name)

        active_alerts = len(self.active_alerts.get(model_name, []))
        recent_drifts = len(await self.get_drift_history(model_name, days=1))

        return {
            'status': 'checked',
            'metrics_count': len(metrics_history),
            'active_alerts': active_alerts,
            'recent_drifts': recent_drifts
        }


# Instancia global del servicio
model_quality_monitor = ModelQualityMonitor(None, None, None)