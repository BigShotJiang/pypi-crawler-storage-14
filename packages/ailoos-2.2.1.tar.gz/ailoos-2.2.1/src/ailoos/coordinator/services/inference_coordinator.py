"""
Inference Coordinator - Coordinador de inferencia con gestión de modelos
Sistema que coordina la inferencia usando servicios de gestión de modelos federados.
"""

import asyncio
import time
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from datetime import datetime

from ...core.logging import get_logger
from ...federated.federated_version_manager import ModelVersion, VersionStatus
from .model_registry import ModelRegistry
from .model_version_controller import ModelVersionController
from .model_quality_monitor import ModelQualityMonitor, QualityMetrics

logger = get_logger(__name__)


@dataclass
class InferenceRequest:
    """Solicitud de inferencia coordinada."""
    model_name: str
    input_data: Any
    parameters: Dict[str, Any] = None
    require_federated_version: bool = True
    quality_check: bool = True
    request_id: str = None

    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}
        if self.request_id is None:
            self.request_id = f"req_{int(time.time() * 1000)}"


@dataclass
class InferenceResult:
    """Resultado de inferencia coordinada."""
    request_id: str
    model_name: str
    model_version: str
    output: Any
    confidence: Optional[float] = None
    processing_time: float = 0.0
    federated_info: Dict[str, Any] = None
    quality_metrics: Dict[str, Any] = None
    success: bool = True
    error_message: Optional[str] = None


class InferenceCoordinator:
    """
    Coordinador de inferencia que integra servicios de gestión de modelos federados.
    Gestiona selección de versiones, calidad y coordinación con el sistema federado.
    """

    def __init__(self, model_registry: ModelRegistry,
                 version_controller: ModelVersionController,
                 quality_monitor: ModelQualityMonitor,
                 inference_api=None):  # inference_api será la API de inferencia real
        """
        Inicializar el coordinador de inferencia.

        Args:
            model_registry: Registro de modelos
            version_controller: Controlador de versiones
            quality_monitor: Monitor de calidad
            inference_api: API de inferencia (EmpoorioLMInferenceAPI)
        """
        self.model_registry = model_registry
        self.version_controller = version_controller
        self.quality_monitor = quality_monitor
        self.inference_api = inference_api

        # Estado del coordinador
        self.is_active = False
        self.active_models: Dict[str, str] = {}  # model_name -> active_version_id

        # Estadísticas
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'avg_processing_time': 0.0,
            'model_version_switches': 0,
            'quality_checks_performed': 0
        }

        # Callbacks para eventos
        self.inference_callbacks: List[Callable] = []

        logger.info("🚀 InferenceCoordinator initialized")

    async def start(self):
        """Iniciar el coordinador."""
        if self.is_active:
            return

        self.is_active = True

        # Cargar versiones activas
        await self._load_active_versions()

        logger.info("✅ InferenceCoordinator started")

    async def stop(self):
        """Detener el coordinador."""
        if not self.is_active:
            return

        self.is_active = False
        logger.info("🛑 InferenceCoordinator stopped")

    async def process_inference_request(self, request: InferenceRequest) -> InferenceResult:
        """
        Procesar una solicitud de inferencia coordinada.

        Args:
            request: Solicitud de inferencia

        Returns:
            Resultado de la inferencia
        """
        start_time = time.time()

        try:
            self.stats['total_requests'] += 1

            # Validar solicitud
            validation_result = await self._validate_request(request)
            if not validation_result['valid']:
                return InferenceResult(
                    request_id=request.request_id,
                    model_name=request.model_name,
                    model_version="",
                    output=None,
                    success=False,
                    error_message=validation_result['error']
                )

            # Seleccionar versión del modelo
            version_info = await self._select_model_version(request)
            if not version_info['success']:
                return InferenceResult(
                    request_id=request.request_id,
                    model_name=request.model_name,
                    model_version="",
                    output=None,
                    success=False,
                    error_message=version_info['error']
                )

            model_version = version_info['version']

            # Verificar calidad si está habilitado
            if request.quality_check:
                quality_ok = await self._check_model_quality(request.model_name, model_version)
                if not quality_ok:
                    # Intentar con versión anterior si la calidad falla
                    fallback_version = await self._get_fallback_version(request.model_name)
                    if fallback_version:
                        model_version = fallback_version
                        logger.warning(f"🔄 Fallback to version {model_version.version_id} for {request.model_name}")
                    else:
                        return InferenceResult(
                            request_id=request.request_id,
                            model_name=request.model_name,
                            model_version=model_version.version_id,
                            output=None,
                            success=False,
                            error_message="Model quality check failed and no fallback available"
                        )

            # Ejecutar inferencia
            inference_result = await self._execute_inference(request, model_version)

            # Calcular tiempo de procesamiento
            processing_time = time.time() - start_time

            # Reportar métricas de calidad
            if inference_result['success']:
                await self._report_inference_metrics(request.model_name, processing_time, inference_result)

            # Crear resultado
            result = InferenceResult(
                request_id=request.request_id,
                model_name=request.model_name,
                model_version=model_version.version_id,
                output=inference_result['output'],
                confidence=inference_result.get('confidence'),
                processing_time=processing_time,
                federated_info={
                    'version_id': model_version.version_id,
                    'federated_round': model_version.federated_info.get('rounds', 0),
                    'participants': model_version.federated_info.get('participants', 1)
                },
                quality_metrics=inference_result.get('quality_metrics'),
                success=inference_result['success'],
                error_message=inference_result.get('error')
            )

            if result.success:
                self.stats['successful_requests'] += 1
            else:
                self.stats['failed_requests'] += 1

            # Actualizar tiempo promedio
            self._update_avg_processing_time(processing_time)

            # Notificar callbacks
            await self._notify_inference_event('inference_completed', result)

            return result

        except Exception as e:
            logger.error(f"❌ Inference request failed: {e}")
            self.stats['failed_requests'] += 1

            return InferenceResult(
                request_id=request.request_id,
                model_name=request.model_name,
                model_version="",
                output=None,
                processing_time=time.time() - start_time,
                success=False,
                error_message=str(e)
            )

    async def _validate_request(self, request: InferenceRequest) -> Dict[str, Any]:
        """Validar solicitud de inferencia."""
        try:
            # Verificar que el modelo existe
            model_info = await self.model_registry.get_model_lineage(request.model_name)
            if not model_info:
                return {'valid': False, 'error': f"Model {request.model_name} not found"}

            # Verificar que hay versiones disponibles
            versions = await self.model_registry.get_model_versions(request.model_name)
            if not versions:
                return {'valid': False, 'error': f"No versions available for model {request.model_name}"}

            return {'valid': True}

        except Exception as e:
            return {'valid': False, 'error': f"Validation error: {str(e)}"}

    async def _select_model_version(self, request: InferenceRequest) -> Dict[str, Any]:
        """Seleccionar la versión apropiada del modelo."""
        try:
            if request.require_federated_version:
                # Obtener versión activa federada
                active_version = await self.model_registry.get_active_version(request.model_name)
                if active_version and active_version.status == VersionStatus.ACTIVE:
                    return {'success': True, 'version': active_version}
                else:
                    return {'success': False, 'error': "No active federated version available"}
            else:
                # Usar cualquier versión disponible
                versions = await self.model_registry.get_model_versions(request.model_name)
                if versions:
                    # Usar la más reciente validada
                    for version in versions:
                        if version.status in [VersionStatus.ACTIVE, VersionStatus.VALIDATED]:
                            return {'success': True, 'version': version}

                return {'success': False, 'error': "No suitable version found"}

        except Exception as e:
            return {'success': False, 'error': f"Version selection error: {str(e)}"}

    async def _check_model_quality(self, model_name: str, version: ModelVersion) -> bool:
        """Verificar calidad del modelo."""
        try:
            self.stats['quality_checks_performed'] += 1

            # Obtener métricas recientes
            recent_metrics = await self.quality_monitor.get_model_metrics(model_name, hours=1)

            if not recent_metrics:
                logger.warning(f"⚠️ No recent metrics for quality check of {model_name}")
                return True  # Asumir calidad OK si no hay métricas

            # Verificar que las métricas recientes estén por encima de thresholds
            latest_metric = recent_metrics[-1]

            # Thresholds básicos
            min_accuracy = 0.7
            max_error_rate = 0.1

            if latest_metric.accuracy is not None and latest_metric.accuracy < min_accuracy:
                logger.warning(f"⚠️ Low accuracy detected for {model_name}: {latest_metric.accuracy}")
                return False

            if latest_metric.error_rate is not None and latest_metric.error_rate > max_error_rate:
                logger.warning(f"⚠️ High error rate detected for {model_name}: {latest_metric.error_rate}")
                return False

            return True

        except Exception as e:
            logger.warning(f"⚠️ Quality check failed for {model_name}: {e}")
            return True  # Asumir OK en caso de error

    async def _get_fallback_version(self, model_name: str) -> Optional[ModelVersion]:
        """Obtener versión de fallback."""
        try:
            versions = await self.model_registry.get_model_versions(model_name)
            if len(versions) < 2:
                return None

            # Usar la penúltima versión
            return versions[-2]

        except Exception:
            return None

    async def _execute_inference(self, request: InferenceRequest, model_version: ModelVersion) -> Dict[str, Any]:
        """Ejecutar la inferencia usando la API de inferencia."""
        try:
            if not self.inference_api:
                return {
                    'success': False,
                    'error': 'Inference API not available',
                    'output': None
                }

            # Preparar solicitud para la API de inferencia
            inference_request = {
                'prompt': str(request.input_data),  # Simplificar para texto
                'max_tokens': request.parameters.get('max_tokens', 512),
                'temperature': request.parameters.get('temperature', 0.7),
                'model_version': model_version.version_id
            }

            # Ejecutar inferencia
            # Nota: Esto es un placeholder - la API real tendría su propia interfaz
            response = await self.inference_api.generate_from_dict(inference_request)

            return {
                'success': True,
                'output': response.get('text', ''),
                'confidence': response.get('confidence'),
                'quality_metrics': {
                    'response_time': response.get('usage', {}).get('response_time_seconds', 0),
                    'tokens_generated': response.get('usage', {}).get('completion_tokens', 0)
                }
            }

        except Exception as e:
            logger.error(f"❌ Inference execution failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'output': None
            }

    async def _report_inference_metrics(self, model_name: str, processing_time: float, result: Dict[str, Any]):
        """Reportar métricas de inferencia al monitor de calidad."""
        try:
            # Crear métricas de calidad
            quality_metrics = QualityMetrics(
                timestamp=int(time.time()),
                latency_ms=processing_time * 1000,
                throughput=1.0 / processing_time if processing_time > 0 else 0,
                custom_metrics={
                    'inference_success': result.get('success', False),
                    'tokens_generated': result.get('quality_metrics', {}).get('tokens_generated', 0),
                    'federated_coordination': True
                }
            )

            # Reportar al monitor
            await self.quality_monitor.report_metrics(model_name, quality_metrics)

        except Exception as e:
            logger.warning(f"⚠️ Failed to report inference metrics: {e}")

    async def _load_active_versions(self):
        """Cargar versiones activas de todos los modelos."""
        try:
            models = await self.model_registry.list_models()
            for model_info in models:
                model_name = model_info['model_name']
                active_version = await self.model_registry.get_active_version(model_name)
                if active_version:
                    self.active_models[model_name] = active_version.version_id

            logger.info(f"📋 Loaded {len(self.active_models)} active model versions")

        except Exception as e:
            logger.error(f"❌ Failed to load active versions: {e}")

    def _update_avg_processing_time(self, processing_time: float):
        """Actualizar tiempo promedio de procesamiento."""
        current_avg = self.stats['avg_processing_time']
        total_requests = self.stats['total_requests']

        if total_requests == 1:
            self.stats['avg_processing_time'] = processing_time
        else:
            self.stats['avg_processing_time'] = (current_avg * (total_requests - 1) + processing_time) / total_requests

    async def _notify_inference_event(self, event_type: str, result: InferenceResult):
        """Notificar eventos de inferencia."""
        for callback in self.inference_callbacks:
            try:
                await callback(event_type, result)
            except Exception as e:
                logger.warning(f"Inference callback failed: {e}")

    def add_inference_callback(self, callback: Callable):
        """Agregar callback para eventos de inferencia."""
        self.inference_callbacks.append(callback)

    def get_coordinator_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del coordinador."""
        return {
            'is_active': self.is_active,
            'total_requests': self.stats['total_requests'],
            'successful_requests': self.stats['successful_requests'],
            'failed_requests': self.stats['failed_requests'],
            'success_rate': self.stats['successful_requests'] / max(1, self.stats['total_requests']),
            'avg_processing_time': self.stats['avg_processing_time'],
            'model_version_switches': self.stats['model_version_switches'],
            'quality_checks_performed': self.stats['quality_checks_performed'],
            'active_models': len(self.active_models)
        }

    async def force_version_switch(self, model_name: str, version_id: str) -> bool:
        """Forzar cambio de versión para un modelo."""
        try:
            # Verificar que la versión existe
            version = await self.version_controller.get_version_info(version_id)
            if not version:
                return False

            # Actualizar versión activa
            self.active_models[model_name] = version_id
            self.stats['model_version_switches'] += 1

            logger.info(f"🔄 Forced version switch for {model_name} to {version_id}")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to force version switch: {e}")
            return False


# Instancia global del servicio
inference_coordinator = InferenceCoordinator(None, None, None)