"""
Model Registry - Registro de modelos con versionado y linaje federado
Sistema centralizado para gestión de modelos con trazabilidad completa.
"""

import asyncio
import json
import time
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime

from ...core.logging import get_logger
from ...federated.federated_version_manager import FederatedVersionManager, ModelVersion, VersionStatus
from ...infrastructure.ipfs_embedded import IPFSManager
from ..models.base import Model
from ..models.schemas import ModelCreate
from enum import Enum

logger = get_logger(__name__)


class ModelRegistryStatus(Enum):
    """Estados del registro de modelos."""
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


@dataclass
class ModelLineage:
    """Linaje completo de un modelo."""
    model_name: str
    versions: List[str] = field(default_factory=list)
    parent_models: Set[str] = field(default_factory=set)
    child_models: Set[str] = field(default_factory=set)
    created_at: int = field(default_factory=lambda: int(time.time()))
    last_updated: int = field(default_factory=lambda: int(time.time()))

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'model_name': self.model_name,
            'versions': self.versions,
            'parent_models': list(self.parent_models),
            'child_models': list(self.child_models),
            'created_at': self.created_at,
            'last_updated': self.last_updated
        }


class ModelRegistry:
    """
    Registro centralizado de modelos con versionado federado.
    Maneja el linaje completo de modelos y su evolución.
    """

    def __init__(self, federated_version_manager: FederatedVersionManager,
                 ipfs_manager: IPFSManager, registry_path: str):
        """
        Inicializar el registro de modelos.

        Args:
            federated_version_manager: Gestor de versiones federadas
            ipfs_manager: Gestor de IPFS
            registry_path: Ruta para persistir el registro
        """
        self.version_manager = federated_version_manager
        self.ipfs_manager = ipfs_manager
        self.registry_path = registry_path

        # Estado del registro
        self.model_lineages: Dict[str, ModelLineage] = {}
        self.model_registry: Dict[str, Dict[str, Any]] = {}  # model_name -> metadata

        # Locks
        self.registry_lock = asyncio.Lock()

        logger.info(f"🚀 ModelRegistry initialized with registry at {registry_path}")

    async def initialize(self) -> bool:
        """Inicializar el registro cargando datos existentes."""
        try:
            await self._load_registry()
            logger.info(f"✅ Loaded model registry with {len(self.model_lineages)} model lineages")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to initialize model registry: {e}")
            return False

    async def register_model(self, model_data: ModelCreate, creator_node: str,
                           parent_models: List[str] = None) -> str:
        """
        Registrar un nuevo modelo en el sistema.

        Args:
            model_data: Datos del modelo a registrar
            creator_node: Nodo creador
            parent_models: Modelos padre (para linaje)

        Returns:
            ID de la versión inicial creada
        """
        async with self.registry_lock:
            try:
                model_name = model_data.name

                # Verificar si el modelo ya existe
                if model_name in self.model_registry:
                    # Crear nueva versión del modelo existente
                    return await self._create_new_version(model_name, model_data, creator_node)

                # Crear nuevo modelo
                return await self._create_new_model(model_name, model_data, creator_node, parent_models or [])

            except Exception as e:
                logger.error(f"❌ Failed to register model {model_data.name}: {e}")
                raise

    async def _create_new_model(self, model_name: str, model_data: ModelCreate,
                              creator_node: str, parent_models: List[str]) -> str:
        """Crear un nuevo modelo en el registro."""
        # Crear metadata del modelo
        model_metadata = {
            'model_name': model_name,
            'model_type': model_data.model_type,
            'description': getattr(model_data, 'description', ''),
            'tags': getattr(model_data, 'tags', []),
            'created_by': creator_node,
            'created_at': int(time.time()),
            'status': ModelRegistryStatus.ACTIVE.value,
            'federated_info': {
                'creator_node': creator_node,
                'parent_models': parent_models
            }
        }

        # Crear primera versión
        version_metadata = {
            'model_name': model_name,
            'version_name': '1.0.0',
            'description': f'Initial version of {model_name}',
            'federated_info': {
                'participants': 1,
                'total_samples': 0,
                'rounds': 1
            },
            'quality_metrics': getattr(model_data, 'metrics', {}),
            'config': getattr(model_data, 'config', {})
        }

        # Crear versión en el sistema federado (placeholder - necesitaría datos reales del modelo)
        # En producción, esto requeriría los datos binarios del modelo
        version_id = f"{model_name}_v1.0.0_{int(time.time())}"

        # Crear linaje
        lineage = ModelLineage(
            model_name=model_name,
            versions=[version_id],
            parent_models=set(parent_models)
        )

        # Actualizar hijos de modelos padre
        for parent in parent_models:
            if parent in self.model_lineages:
                self.model_lineages[parent].child_models.add(model_name)

        # Registrar en el sistema
        self.model_registry[model_name] = model_metadata
        self.model_lineages[model_name] = lineage

        await self._save_registry()

        logger.info(f"✅ Registered new model {model_name} with initial version {version_id}")
        return version_id

    async def _create_new_version(self, model_name: str, model_data: ModelCreate,
                                creator_node: str) -> str:
        """Crear nueva versión de un modelo existente."""
        lineage = self.model_lineages[model_name]
        current_version = len(lineage.versions)

        # Crear metadata de versión
        version_metadata = {
            'model_name': model_name,
            'version_name': f'1.0.{current_version}',
            'description': getattr(model_data, 'description', f'Version {current_version + 1} of {model_name}'),
            'federated_info': {
                'participants': 1,
                'total_samples': 0,
                'rounds': current_version + 1
            },
            'quality_metrics': getattr(model_data, 'metrics', {}),
            'config': getattr(model_data, 'config', {})
        }

        # Crear versión en el sistema federado
        version_id = f"{model_name}_v1.0.{current_version}_{int(time.time())}"

        # Actualizar linaje
        lineage.versions.append(version_id)
        lineage.last_updated = int(time.time())

        await self._save_registry()

        logger.info(f"✅ Created new version {version_id} for model {model_name}")
        return version_id

    async def get_model_lineage(self, model_name: str) -> Optional[ModelLineage]:
        """Obtener linaje completo de un modelo."""
        return self.model_lineages.get(model_name)

    async def get_model_versions(self, model_name: str) -> List[ModelVersion]:
        """Obtener todas las versiones de un modelo."""
        lineage = self.model_lineages.get(model_name)
        if not lineage:
            return []

        versions = []
        for version_id in lineage.versions:
            version = await self.version_manager.get_version(version_id)
            if version:
                versions.append(version)

        return versions

    async def get_active_version(self, model_name: str) -> Optional[ModelVersion]:
        """Obtener versión activa de un modelo."""
        versions = await self.get_model_versions(model_name)
        for version in versions:
            if version.status == VersionStatus.ACTIVE:
                return version
        return None

    async def deprecate_model(self, model_name: str, reason: str = "") -> bool:
        """Deprecar un modelo."""
        async with self.registry_lock:
            if model_name not in self.model_registry:
                return False

            # Deprecar todas las versiones activas
            versions = await self.get_model_versions(model_name)
            for version in versions:
                if version.status == VersionStatus.ACTIVE:
                    await self.version_manager.deprecate_version(
                        version.version_id,
                        reason=f"Model {model_name} deprecated: {reason}"
                    )

            # Actualizar estado del modelo
            self.model_registry[model_name]['status'] = ModelRegistryStatus.DEPRECATED.value
            self.model_registry[model_name]['deprecated_at'] = int(time.time())
            self.model_registry[model_name]['deprecation_reason'] = reason

            await self._save_registry()

            logger.info(f"📅 Deprecated model {model_name}: {reason}")
            return True

    async def archive_model(self, model_name: str) -> bool:
        """Archivar un modelo."""
        async with self.registry_lock:
            if model_name not in self.model_registry:
                return False

            # Marcar como archivado
            self.model_registry[model_name]['status'] = ModelRegistryStatus.ARCHIVED.value
            self.model_registry[model_name]['archived_at'] = int(time.time())

            await self._save_registry()

            logger.info(f"📦 Archived model {model_name}")
            return True

    async def list_models(self, status_filter: Optional[ModelRegistryStatus] = None,
                         model_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Listar modelos con filtros."""
        models = []

        for model_name, metadata in self.model_registry.items():
            if status_filter and metadata.get('status') != status_filter.value:
                continue
            if model_type and metadata.get('model_type') != model_type:
                continue

            # Agregar información de linaje
            lineage = self.model_lineages.get(model_name)
            if lineage:
                metadata_copy = metadata.copy()
                metadata_copy['version_count'] = len(lineage.versions)
                metadata_copy['latest_version'] = lineage.versions[-1] if lineage.versions else None
                models.append(metadata_copy)

        return models

    async def get_model_dependencies(self, model_name: str) -> Dict[str, List[str]]:
        """Obtener dependencias de un modelo (padres e hijos)."""
        lineage = self.model_lineages.get(model_name)
        if not lineage:
            return {'parents': [], 'children': []}

        return {
            'parents': list(lineage.parent_models),
            'children': list(lineage.child_models)
        }

    async def search_models(self, query: str, tags: List[str] = None) -> List[Dict[str, Any]]:
        """Buscar modelos por nombre, descripción o tags."""
        results = []
        query_lower = query.lower()

        for model_name, metadata in self.model_registry.items():
            # Buscar en nombre y descripción
            if (query_lower in model_name.lower() or
                query_lower in metadata.get('description', '').lower()):

                # Filtrar por tags si se especifican
                if tags:
                    model_tags = set(metadata.get('tags', []))
                    if not set(tags).issubset(model_tags):
                        continue

                results.append(metadata.copy())

        return results

    async def _load_registry(self):
        """Cargar registro desde archivo."""
        try:
            with open(self.registry_path, 'r') as f:
                data = json.load(f)

            # Cargar metadatos de modelos
            self.model_registry = data.get('models', {})

            # Cargar linajes
            lineages_data = data.get('lineages', {})
            for model_name, lineage_data in lineages_data.items():
                self.model_lineages[model_name] = ModelLineage(
                    model_name=model_name,
                    versions=lineage_data.get('versions', []),
                    parent_models=set(lineage_data.get('parent_models', [])),
                    child_models=set(lineage_data.get('child_models', [])),
                    created_at=lineage_data.get('created_at', int(time.time())),
                    last_updated=lineage_data.get('last_updated', int(time.time()))
                )

        except FileNotFoundError:
            # Crear registro vacío si no existe
            self.model_registry = {}
            self.model_lineages = {}
        except Exception as e:
            logger.warning(f"Failed to load registry, creating new one: {e}")
            self.model_registry = {}
            self.model_lineages = {}

    async def _save_registry(self):
        """Guardar registro a archivo."""
        try:
            data = {
                'models': self.model_registry,
                'lineages': {name: lineage.to_dict() for name, lineage in self.model_lineages.items()},
                'last_updated': int(time.time())
            }

            with open(self.registry_path, 'w') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"❌ Failed to save registry: {e}")
            raise

    def get_registry_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del registro."""
        total_models = len(self.model_registry)
        active_models = sum(1 for m in self.model_registry.values()
                          if m.get('status') == ModelRegistryStatus.ACTIVE.value)
        deprecated_models = sum(1 for m in self.model_registry.values()
                              if m.get('status') == ModelRegistryStatus.DEPRECATED.value)

        total_versions = sum(len(lineage.versions) for lineage in self.model_lineages.values())

        return {
            'total_models': total_models,
            'active_models': active_models,
            'deprecated_models': deprecated_models,
            'archived_models': total_models - active_models - deprecated_models,
            'total_versions': total_versions,
            'average_versions_per_model': total_versions / total_models if total_models > 0 else 0
        }


# Instancia global del servicio
model_registry = ModelRegistry(None, None, "data/model_registry.json")