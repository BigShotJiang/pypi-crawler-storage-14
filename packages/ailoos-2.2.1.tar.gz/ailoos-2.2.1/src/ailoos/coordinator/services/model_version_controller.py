"""
Model Version Controller - Control de versiones con IPFS y rollback
Gestión centralizada de versiones de modelos con distribución IPFS y rollback automático.
"""

import asyncio
import json
import time
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from ...core.logging import get_logger
from ...federated.federated_version_manager import FederatedVersionManager, ModelVersion, VersionStatus
from ...federated.ipfs_version_distributor import IPFSVersionDistributor, DistributionStrategy
from ...federated.rollback_coordinator import RollbackCoordinator, RollbackTrigger
from ...infrastructure.ipfs_embedded import IPFSManager
from .model_registry import ModelRegistry

logger = get_logger(__name__)


class VersionControlAction(Enum):
    """Acciones de control de versiones."""
    CREATE_VERSION = "create_version"
    PROMOTE_VERSION = "promote_version"
    ROLLBACK_VERSION = "rollback_version"
    DEPRECATE_VERSION = "deprecate_version"
    DISTRIBUTE_VERSION = "distribute_version"
    VALIDATE_VERSION = "validate_version"


@dataclass
class VersionControlEvent:
    """Evento de control de versiones."""
    model_name: str
    version_id: str
    action: VersionControlAction
    triggered_by: str
    reason: str
    success: bool
    timestamp: int = field(default_factory=lambda: int(time.time()))
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convertir a diccionario."""
        return {
            'model_name': self.model_name,
            'version_id': self.version_id,
            'action': self.action.value,
            'triggered_by': self.triggered_by,
            'reason': self.reason,
            'success': self.success,
            'timestamp': self.timestamp,
            'metadata': self.metadata
        }


class ModelVersionController:
    """
    Controlador centralizado de versiones de modelos.
    Maneja creación, distribución, promoción y rollback de versiones usando IPFS.
    """

    def __init__(self, version_manager: FederatedVersionManager,
                 distributor: IPFSVersionDistributor,
                 rollback_coordinator: RollbackCoordinator,
                 registry: ModelRegistry,
                 ipfs_manager: IPFSManager):
        """
        Inicializar el controlador de versiones.

        Args:
            version_manager: Gestor de versiones federadas
            distributor: Distribuidor IPFS
            rollback_coordinator: Coordinador de rollbacks
            registry: Registro de modelos
            ipfs_manager: Gestor IPFS
        """
        self.version_manager = version_manager
        self.distributor = distributor
        self.rollback_coordinator = rollback_coordinator
        self.registry = registry
        self.ipfs_manager = ipfs_manager

        # Historial de eventos
        self.control_history: Dict[str, List[VersionControlEvent]] = {}  # model_name -> events

        # Configuración de distribución
        self.distribution_config = {
            'default_strategy': DistributionStrategy.BROADCAST,
            'auto_distribute_on_promotion': True,
            'replication_factor': 3,
            'distribution_timeout_seconds': 300
        }

        # Callbacks para eventos
        self.control_callbacks: List[Callable] = []

        # Locks
        self.control_lock = asyncio.Lock()

        logger.info("🚀 ModelVersionController initialized")

    async def create_version(self, model_name: str, version_data: bytes,
                           metadata: Dict[str, Any], creator_node: str) -> str:
        """
        Crear una nueva versión del modelo.

        Args:
            model_name: Nombre del modelo
            version_data: Datos binarios del modelo
            metadata: Metadatos de la versión
            creator_node: Nodo creador

        Returns:
            ID de la versión creada
        """
        async with self.control_lock:
            try:
                # Crear versión en el sistema federado
                version_id = await self.version_manager.register_new_version(
                    model_data=version_data,
                    metadata=metadata,
                    creator_node=creator_node
                )

                # Registrar evento
                await self._record_control_event(
                    model_name, version_id, VersionControlAction.CREATE_VERSION,
                    creator_node, "New version created", True
                )

                logger.info(f"✅ Created version {version_id} for model {model_name}")
                return version_id

            except Exception as e:
                logger.error(f"❌ Failed to create version for {model_name}: {e}")
                await self._record_control_event(
                    model_name, "", VersionControlAction.CREATE_VERSION,
                    creator_node, f"Creation failed: {str(e)}", False
                )
                raise

    async def promote_version(self, model_name: str, version_id: str,
                            promoted_by: str, target_nodes: List[str] = None) -> bool:
        """
        Promover una versión a producción con distribución IPFS.

        Args:
            model_name: Nombre del modelo
            version_id: ID de la versión a promover
            promoted_by: Usuario que promueve
            target_nodes: Nodos objetivo (None = todos)

        Returns:
            True si la promoción fue exitosa
        """
        async with self.control_lock:
            try:
                # Verificar que la versión existe y está validada
                version = await self.version_manager.get_version(version_id)
                if not version:
                    raise ValueError(f"Version {version_id} not found")

                if version.status != VersionStatus.VALIDATED:
                    raise ValueError(f"Version {version_id} is not validated (status: {version.status.value})")

                # Activar versión
                await self.version_manager.force_activate_version(version_id, f"Promoted by {promoted_by}")

                # Distribuir automáticamente si está habilitado
                if self.distribution_config['auto_distribute_on_promotion']:
                    distribution_target = target_nodes or ["all_nodes"]  # Placeholder
                    await self.distribute_version(
                        version_id, distribution_target,
                        DistributionStrategy.BROADCAST, promoted_by
                    )

                # Registrar evento
                await self._record_control_event(
                    model_name, version_id, VersionControlAction.PROMOTE_VERSION,
                    promoted_by, "Version promoted to production", True,
                    {'distributed_to': distribution_target}
                )

                logger.info(f"✅ Promoted version {version_id} for model {model_name}")
                return True

            except Exception as e:
                logger.error(f"❌ Failed to promote version {version_id}: {e}")
                await self._record_control_event(
                    model_name, version_id, VersionControlAction.PROMOTE_VERSION,
                    promoted_by, f"Promotion failed: {str(e)}", False
                )
                raise

    async def rollback_version(self, model_name: str, from_version_id: str,
                             to_version_id: str, triggered_by: str,
                             reason: str = "Manual rollback") -> str:
        """
        Ejecutar rollback de versión usando el coordinador de rollbacks.

        Args:
            model_name: Nombre del modelo
            from_version_id: Versión actual
            to_version_id: Versión objetivo
            triggered_by: Usuario que ejecuta rollback
            reason: Razón del rollback

        Returns:
            ID del rollback creado
        """
        async with self.control_lock:
            try:
                # Ejecutar rollback usando el coordinador
                rollback_id = await self.rollback_coordinator.trigger_rollback(
                    from_version=from_version_id,
                    to_version=to_version_id,
                    trigger=RollbackTrigger.MANUAL_TRIGGER,
                    reason=reason,
                    affected_nodes=["all_nodes"]  # Placeholder
                )

                # Registrar evento
                await self._record_control_event(
                    model_name, to_version_id, VersionControlAction.ROLLBACK_VERSION,
                    triggered_by, reason, True,
                    {'rollback_id': rollback_id, 'from_version': from_version_id}
                )

                logger.info(f"🔄 Rollback initiated for model {model_name}: {from_version_id} -> {to_version_id}")
                return rollback_id

            except Exception as e:
                logger.error(f"❌ Failed to rollback version for {model_name}: {e}")
                await self._record_control_event(
                    model_name, to_version_id, VersionControlAction.ROLLBACK_VERSION,
                    triggered_by, f"Rollback failed: {str(e)}", False,
                    {'from_version': from_version_id}
                )
                raise

    async def distribute_version(self, version_id: str, target_nodes: List[str],
                               strategy: DistributionStrategy = None,
                               distributed_by: str = "system") -> str:
        """
        Distribuir versión a nodos usando IPFS.

        Args:
            version_id: ID de la versión a distribuir
            target_nodes: Nodos objetivo
            strategy: Estrategia de distribución
            distributed_by: Usuario que distribuye

        Returns:
            ID de la tarea de distribución
        """
        try:
            strategy = strategy or DistributionStrategy(self.distribution_config['default_strategy'].value)

            # Iniciar distribución
            distribution_task = await self.distributor.distribute_version(
                version_id=version_id,
                target_nodes=target_nodes,
                strategy=strategy,
                priority=3
            )

            # Esperar completación con timeout
            timeout = self.distribution_config['distribution_timeout_seconds']
            await self._wait_for_distribution(distribution_task, timeout)

            # Obtener modelo para metadata
            version = await self.version_manager.get_version(version_id)
            model_name = "unknown"
            if version:
                # Extraer nombre del modelo de metadata (placeholder)
                model_name = version.version_name.split('_')[0] if '_' in version.version_name else version.version_name

            # Registrar evento
            await self._record_control_event(
                model_name, version_id, VersionControlAction.DISTRIBUTE_VERSION,
                distributed_by, f"Distributed using {strategy.value} strategy", True,
                {'task_id': distribution_task, 'target_nodes': len(target_nodes)}
            )

            logger.info(f"📤 Distributed version {version_id} to {len(target_nodes)} nodes")
            return distribution_task

        except Exception as e:
            logger.error(f"❌ Failed to distribute version {version_id}: {e}")
            raise

    async def _wait_for_distribution(self, task_id: str, timeout_seconds: int):
        """Esperar a que una distribución se complete."""
        start_time = time.time()

        while time.time() - start_time < timeout_seconds:
            status = await self.distributor.get_distribution_status(task_id)
            if status and status['status'] in ['completed', 'partial']:
                if status['status'] == 'partial':
                    logger.warning(f"⚠️ Distribution {task_id} completed partially")
                return
            elif status and status['status'] == 'failed':
                raise Exception(f"Distribution {task_id} failed")

            await asyncio.sleep(5)

        raise Exception(f"Distribution {task_id} timed out after {timeout_seconds}s")

    async def deprecate_version(self, model_name: str, version_id: str,
                              deprecated_by: str, reason: str = "") -> bool:
        """
        Deprecar una versión del modelo.

        Args:
            model_name: Nombre del modelo
            version_id: ID de la versión a deprecar
            deprecated_by: Usuario que deprecia
            reason: Razón de la deprecación

        Returns:
            True si la deprecación fue exitosa
        """
        async with self.control_lock:
            try:
                # Deprecar versión
                success = await self.version_manager.deprecate_version(version_id, reason)

                if success:
                    # Registrar evento
                    await self._record_control_event(
                        model_name, version_id, VersionControlAction.DEPRECATE_VERSION,
                        deprecated_by, reason or "Version deprecated", True
                    )

                    logger.info(f"📅 Deprecated version {version_id} for model {model_name}")
                    return True
                else:
                    raise ValueError(f"Version {version_id} not found or could not be deprecated")

            except Exception as e:
                logger.error(f"❌ Failed to deprecate version {version_id}: {e}")
                await self._record_control_event(
                    model_name, version_id, VersionControlAction.DEPRECATE_VERSION,
                    deprecated_by, f"Deprecation failed: {str(e)}", False
                )
                raise

    async def validate_version(self, model_name: str, version_id: str,
                             validated_by: str) -> bool:
        """
        Iniciar validación colectiva de una versión.

        Args:
            model_name: Nombre del modelo
            version_id: ID de la versión a validar
            validated_by: Usuario que inicia validación

        Returns:
            True si la validación se inició correctamente
        """
        try:
            # Obtener nodos para validación (placeholder)
            validation_nodes = ["node_1", "node_2", "node_3"]

            # Iniciar validación colectiva
            success = await self.version_manager.validator.start_validation(version_id, validation_nodes)

            if success:
                # Registrar evento
                await self._record_control_event(
                    model_name, version_id, VersionControlAction.VALIDATE_VERSION,
                    validated_by, "Collective validation started", True,
                    {'validation_nodes': validation_nodes}
                )

                logger.info(f"🎯 Started validation for version {version_id} of model {model_name}")
                return True
            else:
                raise ValueError("Failed to start validation")

        except Exception as e:
            logger.error(f"❌ Failed to start validation for version {version_id}: {e}")
            await self._record_control_event(
                model_name, version_id, VersionControlAction.VALIDATE_VERSION,
                validated_by, f"Validation start failed: {str(e)}", False
            )
            raise

    async def get_version_info(self, version_id: str) -> Optional[Dict[str, Any]]:
        """Obtener información detallada de una versión."""
        version = await self.version_manager.get_version(version_id)
        if not version:
            return None

        # Obtener estado de validación
        validation_status = await self.version_manager.get_validation_status(version_id)

        # Obtener distribución activa
        distribution_status = None
        # En producción, buscar distribuciones activas para esta versión

        return {
            'version_id': version_id,
            'version_name': version.version_name,
            'status': version.status.value,
            'created_at': version.created_at,
            'model_cid': version.model_cid,
            'metadata_cid': version.metadata_cid,
            'validation_status': validation_status,
            'distribution_status': distribution_status,
            'quality_metrics': version.quality_metrics,
            'federated_info': version.federated_info
        }

    async def list_versions(self, model_name: str, status_filter: Optional[VersionStatus] = None) -> List[Dict[str, Any]]:
        """Listar versiones de un modelo con información detallada."""
        versions = await self.registry.get_model_versions(model_name)

        result = []
        for version in versions:
            if status_filter and version.status != status_filter:
                continue

            info = await self.get_version_info(version.version_id)
            if info:
                result.append(info)

        return result

    async def _record_control_event(self, model_name: str, version_id: str,
                                  action: VersionControlAction, triggered_by: str,
                                  reason: str, success: bool, metadata: Dict[str, Any] = None):
        """Registrar evento de control de versiones."""
        event = VersionControlEvent(
            model_name=model_name,
            version_id=version_id,
            action=action,
            triggered_by=triggered_by,
            reason=reason,
            success=success,
            metadata=metadata or {}
        )

        if model_name not in self.control_history:
            self.control_history[model_name] = []

        self.control_history[model_name].append(event)

        # Notificar callbacks
        await self._notify_control_event(event)

    async def _notify_control_event(self, event: VersionControlEvent):
        """Notificar eventos de control."""
        for callback in self.control_callbacks:
            try:
                await callback(event)
            except Exception as e:
                logger.warning(f"Control callback failed: {e}")

    def add_control_callback(self, callback: Callable):
        """Agregar callback para eventos de control."""
        self.control_callbacks.append(callback)

    async def get_control_history(self, model_name: str) -> List[VersionControlEvent]:
        """Obtener historial de control de versiones de un modelo."""
        return self.control_history.get(model_name, [])

    def update_distribution_config(self, config: Dict[str, Any]):
        """Actualizar configuración de distribución."""
        self.distribution_config.update(config)
        logger.info(f"⚙️ Updated distribution config: {config}")

    def get_version_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de versiones."""
        total_events = sum(len(events) for events in self.control_history.values())

        action_counts = {}
        for events in self.control_history.values():
            for event in events:
                action = event.action.value
                action_counts[action] = action_counts.get(action, 0) + 1

        return {
            'total_models': len(self.control_history),
            'total_events': total_events,
            'events_by_action': action_counts,
            'distribution_config': self.distribution_config
        }


# Instancia global del servicio
model_version_controller = ModelVersionController(None, None, None, None, None)