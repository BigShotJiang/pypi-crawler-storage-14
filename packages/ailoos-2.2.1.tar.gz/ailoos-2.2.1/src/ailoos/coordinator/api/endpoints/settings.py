"""
API endpoints for user settings management.
"""

from typing import Dict, Any
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from datetime import datetime
import speakeasy
import qrcode
import base64
from io import BytesIO
import os
import json
import logging
import asyncio
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.backends import default_backend
import pywebpush

from ...database.connection import get_db
from ...auth.dependencies import get_current_user
from ....settings.service_sqlalchemy import SettingsServiceSQLAlchemy
from ....validation.security_validator import AdvancedSecurityValidator as SecurityValidator
from ....notifications.security_notifications import SecurityNotificationService
from ....notifications.service import NotificationService

logger = logging.getLogger(__name__)

router = APIRouter()

# Instancia del servicio de settings
def get_settings_service(db: Session = Depends(get_db)):
    """Obtiene una instancia del servicio de settings."""
    # Crear fábrica de sesión para el servicio de settings
    def db_session_factory():
        return db
    return SettingsServiceSQLAlchemy(db_session_factory)


@router.get("/settings/account")
async def get_account_settings(db: Session = Depends(get_db)):
    """Get account settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "name": "John Doe",
            "email": "john@example.com",
            "phone": "+1234567890",
            "bio": "Federated learning enthusiast",
            "sessions_completed": 15,
            "tokens_used": 1250
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving account settings: {str(e)}")


@router.put("/settings/account")
async def update_account_settings(settings: Dict[str, Any], db: Session = Depends(get_db)):
    """Update account settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Account settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating account settings: {str(e)}")


@router.get("/settings/ui")
async def get_ui_settings(db: Session = Depends(get_db)):
    """Get UI settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "appearance": "system",
            "accent_color": "blue",
            "font_size": "medium",
            "send_with_enter": True,
            "ui_language": "es",
            "spoken_language": "es",
            "voice": "ember"
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving UI settings: {str(e)}")


@router.put("/settings/ui")
async def update_ui_settings(settings: Dict[str, Any], db: Session = Depends(get_db)):
    """Update UI settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "UI settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating UI settings: {str(e)}")


@router.post("/settings/ui/reset")
async def reset_ui_settings(db: Session = Depends(get_db)):
    """Reset UI settings to defaults."""
    try:
        # Mock implementation - in real implementation, reset to defaults
        result = {
            "reset": True,
            "message": "UI settings reset to defaults"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error resetting UI settings: {str(e)}")


@router.get("/settings/notifications")
async def get_notification_settings(db: Session = Depends(get_db)):
    """Get notification settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "mute_all": False,
            "responses_app": True,
            "responses_email": True,
            "tasks_app": True,
            "tasks_email": False,
            "projects_app": True,
            "projects_email": True,
            "recommendations_app": False,
            "recommendations_email": False
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving notification settings: {str(e)}")


@router.put("/settings/notifications")
async def update_notification_settings(settings: Dict[str, Any], db: Session = Depends(get_db)):
    """Update notification settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Notification settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating notification settings: {str(e)}")


@router.get("/settings/personalization")
async def get_personalization_settings(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Get personalization settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "enable_personalization": True,
            "custom_instructions": False,
            "base_style_tone": "witty",
            "nickname": "",
            "occupation": "",
            "more_about_you": "",
            "reference_chat_history": True
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving personalization settings: {str(e)}")


@router.put("/settings/personalization")
async def update_personalization_settings(settings: Dict[str, Any], db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Update personalization settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Personalization settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating personalization settings: {str(e)}")


@router.get("/settings/memory")
async def get_memory_settings(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Get memory settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "memory_used": 0,
            "max_memory_items": 256,
            "reference_memories": True
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving memory settings: {str(e)}")


@router.put("/settings/memory")
async def update_memory_settings(settings: Dict[str, Any], db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Update memory settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Memory settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating memory settings: {str(e)}")


@router.get("/settings/apps-connectors")
async def get_apps_connectors_settings(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Get apps & connectors settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "google_drive": False,
            "dropbox": False,
            "slack": False,
            "discord": False,
            "discord_bot_token": "",
            "discord_server_id": "",
            "discord_channel_id": "",
            "discord_webhook_url": "",
            "webhook_url": "",
            "webhook_headers": "",
            "webhook_method": "POST",
            "webhook_enabled": False
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving apps-connectors settings: {str(e)}")


@router.put("/settings/apps-connectors")
async def update_apps_connectors_settings(settings: Dict[str, Any], db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Update apps & connectors settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Apps & connectors settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating apps-connectors settings: {str(e)}")


@router.get("/settings/data-controls")
async def get_data_controls_settings(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Get data controls settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "data_collection": True,
            "analytics": True,
            "data_retention": "1year",
            "export_data": False
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving data-controls settings: {str(e)}")


@router.put("/settings/data-controls")
async def update_data_controls_settings(settings: Dict[str, Any], db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Update data controls settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Data controls settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating data-controls settings: {str(e)}")


@router.get("/api/v1/settings/security")
async def get_security_settings(
    current_user: dict = Depends(get_current_user),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Obtener configuraciones de seguridad del usuario actual."""
    try:
        user_id = int(current_user.get("user_id"))
        user_settings = settings_service.get_user_settings(user_id)

        if not user_settings:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        # Retornar solo la configuración de seguridad
        security_data = user_settings.security.to_dict()
        return security_data

    except ValueError:
        raise HTTPException(status_code=400, detail="ID de usuario inválido")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al obtener configuraciones de seguridad: {str(e)}")


@router.put("/api/v1/settings/security")
async def update_security_settings(
    settings: Dict[str, Any],
    current_user: dict = Depends(get_current_user),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Actualizar configuraciones de seguridad del usuario."""
    try:
        user_id = int(current_user.get("user_id"))

        # Actualizar solo la categoría de seguridad
        updated_settings = settings_service.update_category_settings(user_id, 'security', settings)

        return {
            "updated": True,
            "message": "Configuraciones de seguridad actualizadas exitosamente",
            "security": updated_settings.security.to_dict()
        }

    except ValueError:
        raise HTTPException(status_code=400, detail="ID de usuario inválido")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al actualizar configuraciones de seguridad: {str(e)}")


@router.get("/settings/parental-controls")
async def get_parental_controls_settings(db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Get parental controls settings."""
    try:
        # Mock data for now - in real implementation, query database
        settings = {
            "parental_control": False,
            "content_filter": "moderate",
            "time_limits": False,
            "max_time_per_day": "2hours",
            "parental_pin_hash": None
        }
        return settings
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving parental-controls settings: {str(e)}")


@router.put("/settings/parental-controls")
async def update_parental_controls_settings(settings: Dict[str, Any], db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):
    """Update parental controls settings."""
    try:
        # Mock implementation - in real implementation, save to database
        result = {
            "updated": True,
            "message": "Parental controls settings updated successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating parental-controls settings: {str(e)}")


@router.post("/api/v1/settings/change-password")
async def change_password(
    password_data: Dict[str, Any],
    request: Request,
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Cambiar contraseña del usuario con validaciones."""
    try:
        # Validar datos de entrada
        if not isinstance(password_data, dict):
            raise HTTPException(status_code=400, detail="Datos inválidos")

        current_password = password_data.get("current_password")
        new_password = password_data.get("new_password")

        if not current_password or not new_password:
            raise HTTPException(status_code=400, detail="Se requieren current_password y new_password")

        user_id = int(current_user.get("user_id"))

        # Obtener usuario para verificar contraseña actual
        from ...models.base import User
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        # Verificar contraseña actual
        import bcrypt
        if not bcrypt.checkpw(current_password.encode(), user.password_hash.encode()):
            raise HTTPException(status_code=400, detail="Contraseña actual incorrecta")

        # Validar nueva contraseña usando SecurityValidator
        validator = SecurityValidator()
        validation_result = validator.validate_password_comprehensive(new_password)

        if not validation_result.is_valid:
            issues = [f"- {issue}" for issue in validation_result.issues]
            warnings = [f"- {warning}" for warning in validation_result.warnings]
            error_msg = "La nueva contraseña no cumple con los requisitos de seguridad:\n"
            if issues:
                error_msg += "Errores:\n" + "\n".join(issues) + "\n"
            if warnings:
                error_msg += "Advertencias:\n" + "\n".join(warnings)
            raise HTTPException(status_code=400, detail=error_msg)

        # Cambiar contraseña
        new_hash = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt()).decode()
        user.password_hash = new_hash
        user.updated_at = datetime.utcnow()

        # Actualizar password_last_changed en security settings
        security_update = {
            "password_last_changed": datetime.utcnow()
        }
        settings_service.update_category_settings(user_id, 'security', security_update)

        db.commit()

        # Enviar notificación de cambio de contraseña
        try:
            # Crear instancia del servicio de notificaciones de seguridad
            notification_service = NotificationService(settings_service, None, None)  # Configurar según sea necesario
            security_notifications = SecurityNotificationService(notification_service, settings_service)

            # Obtener IP del cliente de la request
            client_ip = None
            if hasattr(request, 'client') and request.client:
                client_ip = request.client.host

            # Enviar notificación (no esperamos para no bloquear la respuesta)
            import asyncio
            asyncio.create_task(security_notifications.notify_password_change(user_id, client_ip))

        except Exception as e:
            # No fallar el cambio de contraseña si la notificación falla
            logger.warning(f"Error enviando notificación de cambio de contraseña: {e}")

        return {
            "changed": True,
            "message": "Contraseña cambiada exitosamente",
            "password_last_changed": datetime.utcnow().isoformat(),
            "score": validation_result.score
        }

    except HTTPException:
        raise
    except ValueError:
        raise HTTPException(status_code=400, detail="ID de usuario inválido")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al cambiar contraseña: {str(e)}")


@router.post("/api/v1/settings/export-data")
async def export_data(export_data: Dict[str, Any], db: Session = Depends(get_db)):
    """Export user data."""
    try:
        # Mock implementation - in real implementation, export user data
        result = {
            "export_id": "export_123",
            "status": "processing",
            "message": "Data export initiated"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting data: {str(e)}")


@router.post("/settings/test-webhook")
async def test_webhook(db: Session = Depends(get_db)):
    """Test webhook configuration."""
    try:
        # Mock implementation - in real implementation, test webhook
        result = {
            "test_sent": True,
            "message": "Webhook test sent successfully"
        }
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error testing webhook: {str(e)}")


@router.post("/api/v1/auth/2fa/setup")
async def setup_2fa(
    current_user: dict = Depends(get_current_user),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Generar secreto TOTP y QR code para configuración de 2FA."""
    try:
        user_id = int(current_user.get("user_id"))

        # Obtener configuraciones de seguridad actuales
        user_settings = settings_service.get_user_settings(user_id)
        if not user_settings:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        security_settings = user_settings.security

        # Verificar si 2FA ya está habilitado
        if security_settings.two_factor_enabled:
            raise HTTPException(status_code=400, detail="2FA ya está habilitado para este usuario")

        # Generar nuevo secreto TOTP
        secret = speakeasy.generate_secret()
        issuer = "AILOOS"
        account_name = current_user.get("email", f"user_{user_id}")

        # Crear URL otpauth
        otpauth_url = f"otpauth://totp/{issuer}:{account_name}?secret={secret}&issuer={issuer}&algorithm={security_settings.two_factor_algorithm}&digits={security_settings.two_factor_digits}&period={security_settings.two_factor_interval}"

        # Generar QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(otpauth_url)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        qr_code_base64 = base64.b64encode(buffer.getvalue()).decode()

        # Actualizar configuración de seguridad con el secreto (pero no activar aún)
        security_update = {
            "two_factor_secret": secret,
            "two_factor": True  # Indicar que se está configurando
        }
        settings_service.update_category_settings(user_id, 'security', security_update)

        return {
            "secret": secret,
            "otpauth_url": otpauth_url,
            "qr_code": f"data:image/png;base64,{qr_code_base64}",
            "algorithm": security_settings.two_factor_algorithm,
            "digits": security_settings.two_factor_digits,
            "period": security_settings.two_factor_interval
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al configurar 2FA: {str(e)}")


@router.post("/api/v1/auth/2fa/verify")
async def verify_2fa_setup(
    verification_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Verificar código TOTP y activar 2FA."""
    try:
        user_id = int(current_user.get("user_id"))
        code = verification_data.get("code")

        if not code or not isinstance(code, str) or len(code) != 6:
            raise HTTPException(status_code=400, detail="Código de verificación inválido")

        # Obtener configuraciones de seguridad
        user_settings = settings_service.get_user_settings(user_id)
        if not user_settings:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        security_settings = user_settings.security

        if not security_settings.two_factor_secret:
            raise HTTPException(status_code=400, detail="2FA no configurado. Configure primero con /setup")

        if security_settings.two_factor_enabled:
            raise HTTPException(status_code=400, detail="2FA ya está activado")

        # Verificar código TOTP
        is_valid = speakeasy.totp_verify(
            code,
            security_settings.two_factor_secret,
            algorithm=getattr(speakeasy, security_settings.two_factor_algorithm),
            digits=security_settings.two_factor_digits,
            interval=security_settings.two_factor_interval
        )

        if not is_valid:
            raise HTTPException(status_code=400, detail="Código de verificación incorrecto")

        # Activar 2FA
        security_update = {
            "two_factor_enabled": True
        }
        settings_service.update_category_settings(user_id, 'security', security_update)

        # Enviar notificación de 2FA activado
        try:
            notification_service = NotificationService(settings_service, None, None)
            security_notifications = SecurityNotificationService(notification_service, settings_service)
            asyncio.create_task(security_notifications.notify_2fa_enabled(user_id))
        except Exception as e:
            logger.warning(f"Error enviando notificación de 2FA activado: {e}")

        return {
            "verified": True,
            "message": "2FA activado exitosamente",
            "two_factor_enabled": True
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al verificar 2FA: {str(e)}")


@router.post("/api/v1/auth/2fa/verify-login")
async def verify_2fa_login(
    verification_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Verificar código TOTP durante el login."""
    try:
        user_id = int(current_user.get("user_id"))
        code = verification_data.get("code")

        if not code or not isinstance(code, str) or len(code) != 6:
            raise HTTPException(status_code=400, detail="Código de verificación inválido")

        # Obtener configuraciones de seguridad
        user_settings = settings_service.get_user_settings(user_id)
        if not user_settings:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        security_settings = user_settings.security

        if not security_settings.two_factor_enabled or not security_settings.two_factor_secret:
            raise HTTPException(status_code=400, detail="2FA no está activado para este usuario")

        # Verificar código TOTP
        is_valid = speakeasy.totp_verify(
            code,
            security_settings.two_factor_secret,
            algorithm=getattr(speakeasy, security_settings.two_factor_algorithm),
            digits=security_settings.two_factor_digits,
            interval=security_settings.two_factor_interval
        )

        if not is_valid:
            raise HTTPException(status_code=400, detail="Código de verificación incorrecto")

        return {
            "verified": True,
            "message": "Autenticación 2FA exitosa"
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al verificar 2FA en login: {str(e)}")


@router.delete("/api/v1/auth/2fa/disable")
async def disable_2fa(
    current_user: dict = Depends(get_current_user),
    settings_service: SettingsServiceSQLAlchemy = Depends(get_settings_service)
):
    """Desactivar 2FA para el usuario."""
    try:
        user_id = int(current_user.get("user_id"))

        # Obtener configuraciones de seguridad
        user_settings = settings_service.get_user_settings(user_id)
        if not user_settings:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")

        security_settings = user_settings.security

        if not security_settings.two_factor_enabled:
            raise HTTPException(status_code=400, detail="2FA no está activado")

        # Desactivar 2FA
        security_update = {
            "two_factor_enabled": False,
            "two_factor": False,
            "two_factor_secret": None
        }
        settings_service.update_category_settings(user_id, 'security', security_update)

        # Enviar notificación de 2FA desactivado
        try:
            notification_service = NotificationService(settings_service, None, None)
            security_notifications = SecurityNotificationService(notification_service, settings_service)
            asyncio.create_task(security_notifications.notify_2fa_disabled(user_id))
        except Exception as e:
            logger.warning(f"Error enviando notificación de 2FA desactivado: {e}")

        return {
            "disabled": True,
            "message": "2FA desactivado exitosamente",
            "two_factor_enabled": False
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al desactivar 2FA: {str(e)}")


# ==================== NOTIFICACIONES PUSH ====================

@router.post("/api/v1/notifications/subscribe")
async def subscribe_push_notifications(
    subscription_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Registrar una suscripción de notificaciones push para el usuario actual.

    Args:
        subscription_data: Datos de la suscripción (endpoint, keys)
        current_user: Usuario autenticado
        db: Sesión de base de datos

    Returns:
        Dict: Confirmación de suscripción
    """
    try:
        user_id = int(current_user.get("user_id"))

        # Validar datos de suscripción
        if not subscription_data or 'subscription' not in subscription_data:
            raise HTTPException(status_code=400, detail="Datos de suscripción inválidos")

        subscription = subscription_data['subscription']
        required_fields = ['endpoint', 'keys']
        if not all(field in subscription for field in required_fields):
            raise HTTPException(status_code=400, detail="Suscripción incompleta")

        keys = subscription['keys']
        if 'p256dh' not in keys or 'auth' not in keys:
            raise HTTPException(status_code=400, detail="Claves de encriptación faltantes")

        # Verificar si ya existe una suscripción para este endpoint
        from .....settings.models_sqlalchemy import PushSubscription
        existing = db.query(PushSubscription).filter(
            PushSubscription.endpoint == subscription['endpoint']
        ).first()

        if existing:
            # Actualizar suscripción existente
            existing.p256dh_key = keys['p256dh']
            existing.auth_key = keys['auth']
            existing.user_agent = subscription_data.get('userAgent', '')
            existing.is_active = True
            existing.updated_at = datetime.utcnow()
            db.commit()

            return {
                "subscribed": True,
                "message": "Suscripción actualizada exitosamente",
                "subscription_id": existing.id
            }

        # Crear nueva suscripción
        new_subscription = PushSubscription(
            user_id=user_id,
            endpoint=subscription['endpoint'],
            p256dh_key=keys['p256dh'],
            auth_key=keys['auth'],
            user_agent=subscription_data.get('userAgent', ''),
            browser_info=subscription_data.get('browserInfo', ''),
            ip_address=subscription_data.get('ipAddress', ''),
            is_active=True
        )

        db.add(new_subscription)
        db.commit()
        db.refresh(new_subscription)

        return {
            "subscribed": True,
            "message": "Suscripción creada exitosamente",
            "subscription_id": new_subscription.id
        }

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al suscribir notificaciones: {str(e)}")


@router.delete("/api/v1/notifications/unsubscribe")
async def unsubscribe_push_notifications(
    unsubscribe_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Eliminar una suscripción de notificaciones push.

    Args:
        unsubscribe_data: Datos para eliminar suscripción (endpoint)
        current_user: Usuario autenticado
        db: Sesión de base de datos

    Returns:
        Dict: Confirmación de eliminación
    """
    try:
        user_id = int(current_user.get("user_id"))

        if not unsubscribe_data or 'endpoint' not in unsubscribe_data:
            raise HTTPException(status_code=400, detail="Endpoint requerido")

        endpoint = unsubscribe_data['endpoint']

        # Buscar y eliminar la suscripción
        from .....settings.models_sqlalchemy import PushSubscription
        subscription = db.query(PushSubscription).filter(
            PushSubscription.user_id == user_id,
            PushSubscription.endpoint == endpoint
        ).first()

        if not subscription:
            raise HTTPException(status_code=404, detail="Suscripción no encontrada")

        # Marcar como inactiva en lugar de eliminar físicamente
        subscription.is_active = False
        subscription.updated_at = datetime.utcnow()
        db.commit()

        return {
            "unsubscribed": True,
            "message": "Suscripción eliminada exitosamente"
        }

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al eliminar suscripción: {str(e)}")


@router.post("/api/v1/notifications/send")
async def send_push_notification(
    notification_data: Dict[str, Any],
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Enviar una notificación push a las suscripciones activas del usuario.

    Args:
        notification_data: Datos de la notificación (title, body, etc.)
        current_user: Usuario autenticado
        db: Sesión de base de datos

    Returns:
        Dict: Resultado del envío
    """
    try:
        user_id = int(current_user.get("user_id"))

        # Validar datos de notificación
        if not notification_data or 'title' not in notification_data:
            raise HTTPException(status_code=400, detail="Título de notificación requerido")

        title = notification_data['title']
        body = notification_data.get('body', '')
        icon = notification_data.get('icon', '/icon1.png')
        badge = notification_data.get('badge', '/favicon.ico')
        url = notification_data.get('url', '/')
        data = notification_data.get('data', {})

        # Obtener suscripciones activas del usuario
        from .....settings.models_sqlalchemy import PushSubscription
        subscriptions = db.query(PushSubscription).filter(
            PushSubscription.user_id == user_id,
            PushSubscription.is_active == True
        ).all()

        if not subscriptions:
            return {
                "sent": False,
                "message": "No hay suscripciones activas",
                "count": 0
            }

        # Obtener claves VAPID
        vapid_private_key = os.getenv('VAPID_PRIVATE_KEY')
        vapid_public_key = os.getenv('VAPID_PUBLIC_KEY')
        vapid_subject = os.getenv('VAPID_SUBJECT', 'mailto:test@example.com')

        if not vapid_private_key or not vapid_public_key:
            raise HTTPException(status_code=500, detail="Claves VAPID no configuradas")

        # Preparar payload de notificación
        payload = {
            "title": title,
            "body": body,
            "icon": icon,
            "badge": badge,
            "data": {
                "url": url,
                "notificationId": f"notif_{datetime.utcnow().timestamp()}",
                "type": notification_data.get('type', 'general'),
                **data
            },
            "requireInteraction": notification_data.get('requireInteraction', False),
            "silent": notification_data.get('silent', False),
            "timestamp": datetime.utcnow().isoformat()
        }

        # Enviar a cada suscripción
        sent_count = 0
        failed_count = 0

        for subscription in subscriptions:
            try:
                # Preparar datos de suscripción para pywebpush
                subscription_info = {
                    "endpoint": subscription.endpoint,
                    "keys": {
                        "p256dh": subscription.p256dh_key,
                        "auth": subscription.auth_key
                    }
                }

                # Enviar notificación
                pywebpush.webpush(
                    subscription_info=subscription_info,
                    data=json.dumps(payload),
                    vapid_private_key=vapid_private_key,
                    vapid_claims={
                        "sub": vapid_subject
                    }
                )

                # Actualizar last_used_at
                subscription.last_used_at = datetime.utcnow()
                sent_count += 1

            except Exception as e:
                print(f"Error enviando a suscripción {subscription.id}: {e}")
                failed_count += 1

        db.commit()

        return {
            "sent": sent_count > 0,
            "message": f"Notificación enviada a {sent_count} suscripciones",
            "count": sent_count,
            "failed": failed_count
        }

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error al enviar notificación: {str(e)}")


@router.get("/api/v1/notifications/subscriptions")
async def get_push_subscriptions(
    current_user: dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Obtener las suscripciones push activas del usuario.

    Args:
        current_user: Usuario autenticado
        db: Sesión de base de datos

    Returns:
        List: Lista de suscripciones
    """
    try:
        user_id = int(current_user.get("user_id"))

        from .....settings.models_sqlalchemy import PushSubscription
        subscriptions = db.query(PushSubscription).filter(
            PushSubscription.user_id == user_id,
            PushSubscription.is_active == True
        ).all()

        return {
            "subscriptions": [sub.to_dict() for sub in subscriptions],
            "count": len(subscriptions)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al obtener suscripciones: {str(e)}")


@router.get("/api/v1/notifications/vapid-public-key")
async def get_vapid_public_key():
    """
    Obtener la clave pública VAPID para el frontend.

    Returns:
        Dict: Clave pública VAPID
    """
    try:
        vapid_public_key = os.getenv('VAPID_PUBLIC_KEY')

        if not vapid_public_key:
            raise HTTPException(status_code=500, detail="Clave VAPID pública no configurada")

        return {
            "publicKey": vapid_public_key
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al obtener clave VAPID: {str(e)}")


@router.get("/health")
async def get_settings_health():
    """Get settings service health status."""
    try:
        # Basic health check
        health_data = {
            "status": "healthy",
            "database_connection": "connected",
            "last_health_check": "2024-01-15T10:30:00Z"
        }
        return health_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving settings health: {str(e)}")