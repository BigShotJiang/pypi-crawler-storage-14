"""
Privacy API endpoints for AILOOS.
Provides REST endpoints for managing user privacy settings, GDPR compliance,
data export, and data deletion.
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Query
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user
from ....privacy.export import ExportService, ExportStatus
from ....settings.service import SettingsService
from ....memory.service import MemoryService

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class PrivacySettingsRequest(BaseModel):
    """Request model for updating privacy settings."""
    data_collection_enabled: bool = Field(..., description="Enable/disable data collection")
    analytics_enabled: bool = Field(..., description="Enable/disable analytics tracking")
    personalization_enabled: bool = Field(..., description="Enable/disable personalization")
    marketing_consent: bool = Field(..., description="Consent for marketing communications")
    data_retention_days: int = Field(..., ge=30, le=2555, description="Data retention period in days")

    @validator('data_retention_days')
    def validate_retention_days(cls, v):
        if v < 30:
            raise ValueError('Data retention must be at least 30 days')
        if v > 2555:  # 7 years
            raise ValueError('Data retention cannot exceed 7 years (2555 days)')
        return v


class PrivacySettingsResponse(BaseModel):
    """Response model for privacy settings."""
    data_collection_enabled: bool
    analytics_enabled: bool
    personalization_enabled: bool
    marketing_consent: bool
    data_retention_days: int
    gdpr_consent_given: bool
    gdpr_consent_date: Optional[datetime]
    last_updated: datetime


class GDPRExportRequest(BaseModel):
    """Request model for GDPR data export."""
    data_types: List[str] = Field(default_factory=lambda: ["settings", "memory", "sessions", "metrics", "account"],
                                  description="Types of data to export")
    format: str = Field("json", description="Export format: json, csv, or zip")

    @validator('data_types')
    def validate_data_types(cls, v):
        valid_types = ["settings", "memory", "sessions", "metrics", "account"]
        for data_type in v:
            if data_type not in valid_types:
                raise ValueError(f'Invalid data type: {data_type}. Valid types: {valid_types}')
        return v

    @validator('format')
    def validate_format(cls, v):
        if v not in ["json", "csv", "zip"]:
            raise ValueError('Format must be "json", "csv", or "zip"')
        return v


class GDPRExportStatusResponse(BaseModel):
    """Response model for GDPR export status."""
    request_id: str
    status: str
    created_at: datetime
    completed_at: Optional[datetime]
    export_path: Optional[str]
    error_message: Optional[str]
    data_types: List[str]
    format: str


class DataDeletionRequest(BaseModel):
    """Request model for data deletion."""
    data_types: List[str] = Field(..., description="Types of data to delete")
    confirmation: str = Field(..., description="Confirmation text: 'DELETE_ALL_DATA'")

    @validator('data_types')
    def validate_data_types(cls, v):
        valid_types = ["settings", "memory", "sessions", "metrics", "account"]
        for data_type in v:
            if data_type not in valid_types:
                raise ValueError(f'Invalid data type: {data_type}. Valid types: {valid_types}')
        return v

    @validator('confirmation')
    def validate_confirmation(cls, v):
        if v != "DELETE_ALL_DATA":
            raise ValueError('Confirmation must be exactly "DELETE_ALL_DATA"')
        return v


class DataDeletionStatusResponse(BaseModel):
    """Response model for data deletion status."""
    deletion_id: str
    status: str
    requested_at: datetime
    completed_at: Optional[datetime]
    data_types_deleted: List[str]
    error_message: Optional[str]


# Helper functions
def get_user_id_from_token(current_user: Dict) -> int:
    """Extract user ID from JWT token payload."""
    try:
        # Assuming user_id is stored in token sub field as integer
        return int(current_user.get('sub', '').split('_')[-1])
    except (ValueError, IndexError):
        raise HTTPException(status_code=400, detail="Invalid user ID in token")


def get_privacy_settings_from_db(user_id: int, db: Session) -> Dict[str, Any]:
    """Get privacy settings from database."""
    # In a real implementation, this would query a privacy settings table
    # For now, return default settings
    return {
        'data_collection_enabled': True,
        'analytics_enabled': True,
        'personalization_enabled': True,
        'marketing_consent': False,
        'data_retention_days': 2555,  # 7 years
        'gdpr_consent_given': True,
        'gdpr_consent_date': datetime.now(),
        'last_updated': datetime.now()
    }


def save_privacy_settings_to_db(user_id: int, settings: Dict[str, Any], db: Session) -> None:
    """Save privacy settings to database."""
    # In a real implementation, this would update a privacy settings table
    # For now, just log the operation
    logger.info(f"Privacy settings updated for user {user_id}: {settings}")


# API Endpoints

@router.get("/settings", response_model=PrivacySettingsResponse,
            summary="Obtener configuración de privacidad",
            description="""
            Obtiene la configuración actual de privacidad del usuario.

            **Incluye:**
            - Recopilación de datos
            - Análisis y seguimiento
            - Personalización
            - Consentimiento de marketing
            - Período de retención de datos
            - Consentimiento GDPR

            **Códigos de respuesta:**
            - 200: Configuración obtenida exitosamente
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Configuración de privacidad obtenida exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "data_collection_enabled": True,
                                "analytics_enabled": True,
                                "personalization_enabled": True,
                                "marketing_consent": False,
                                "data_retention_days": 2555,
                                "gdpr_consent_given": True,
                                "gdpr_consent_date": "2023-11-10T23:34:24.032Z",
                                "last_updated": "2023-11-10T23:34:24.032Z"
                            }
                        }
                    }
                }
            })
async def get_privacy_settings(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's privacy settings.

    - Returns all privacy-related settings
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get privacy settings
        privacy_settings = get_privacy_settings_from_db(user_id, db)

        return PrivacySettingsResponse(**privacy_settings)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get privacy settings error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/settings", response_model=PrivacySettingsResponse,
            summary="Actualizar configuración de privacidad",
            description="""
            Actualiza la configuración de privacidad del usuario actual.

            **Campos requeridos:**
            - data_collection_enabled: Habilitar/deshabilitar recopilación de datos
            - analytics_enabled: Habilitar/deshabilitar análisis
            - personalization_enabled: Habilitar/deshabilitar personalización
            - marketing_consent: Consentimiento para comunicaciones de marketing
            - data_retention_days: Período de retención (30-2555 días)

            **Códigos de respuesta:**
            - 200: Configuración actualizada exitosamente
            - 400: Datos inválidos
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Configuración de privacidad actualizada exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "data_collection_enabled": False,
                                "analytics_enabled": False,
                                "personalization_enabled": True,
                                "marketing_consent": False,
                                "data_retention_days": 365,
                                "gdpr_consent_given": True,
                                "gdpr_consent_date": "2023-11-10T23:34:24.032Z",
                                "last_updated": "2023-11-10T23:34:24.032Z"
                            }
                        }
                    }
                }
            })
async def update_privacy_settings(
    request: PrivacySettingsRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Update user's privacy settings.

    - Updates privacy preferences
    - Validates all input data
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Prepare settings data
        settings_data = {
            'data_collection_enabled': request.data_collection_enabled,
            'analytics_enabled': request.analytics_enabled,
            'personalization_enabled': request.personalization_enabled,
            'marketing_consent': request.marketing_consent,
            'data_retention_days': request.data_retention_days,
            'last_updated': datetime.now()
        }

        # Save settings
        save_privacy_settings_to_db(user_id, settings_data, db)

        # Get updated settings
        updated_settings = get_privacy_settings_from_db(user_id, db)

        logger.info(f"Privacy settings updated for user ID: {user_id}")
        return PrivacySettingsResponse(**updated_settings)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update privacy settings error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/gdpr/export", response_model=GDPRExportStatusResponse,
             summary="Solicitar exportación de datos GDPR",
             description="""
             Solicita una exportación completa de todos los datos personales del usuario conforme al GDPR.

             **Parámetros opcionales:**
             - data_types: Tipos de datos a exportar (por defecto: todos)
             - format: Formato de exportación ("json", "csv", "zip")

             **Tipos de datos disponibles:**
             - settings: Configuraciones de usuario
             - memory: Memoria conversacional
             - sessions: Sesiones federadas
             - metrics: Métricas de uso
             - account: Información de cuenta

             **Códigos de respuesta:**
             - 200: Solicitud de exportación creada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 429: Demasiadas solicitudes pendientes
             - 500: Error interno del servidor
             """,
             responses={
                 200: {
                     "description": "Solicitud de exportación GDPR creada exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "request_id": "gdpr_export_20231110_233424",
                                 "status": "pending",
                                 "created_at": "2023-11-10T23:34:24.032Z",
                                 "data_types": ["settings", "memory", "sessions", "metrics", "account"],
                                 "format": "json"
                             }
                         }
                     }
                 }
             })
async def request_gdpr_export(
    request: GDPRExportRequest,
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Request GDPR data export.

    - Creates export request for user's personal data
    - Processes export in background
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize export service
        export_service = ExportService()

        # Request export
        export_request = await export_service.request_export(
            user_id=user_id,
            data_types=request.data_types,
            format=request.format
        )

        logger.info(f"GDPR export requested for user ID: {user_id}, request: {export_request.request_id}")
        return GDPRExportStatusResponse(
            request_id=export_request.request_id,
            status=export_request.status.value,
            created_at=export_request.created_at,
            completed_at=export_request.completed_at,
            export_path=export_request.export_path,
            error_message=export_request.error_message,
            data_types=export_request.data_types,
            format=export_request.format
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Request GDPR export error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/gdpr/export/{request_id}", response_model=GDPRExportStatusResponse,
            summary="Obtener estado de exportación GDPR",
            description="""
            Obtiene el estado actual de una solicitud de exportación GDPR.

            **Parámetros de ruta:**
            - request_id: ID de la solicitud de exportación

            **Estados posibles:**
            - pending: Solicitud en cola
            - in_progress: Procesando exportación
            - completed: Exportación completada
            - failed: Exportación fallida
            - cancelled: Exportación cancelada

            **Códigos de respuesta:**
            - 200: Estado obtenido exitosamente
            - 401: Usuario no autenticado
            - 404: Solicitud no encontrada
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Estado de exportación obtenido exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "request_id": "gdpr_export_20231110_233424",
                                "status": "completed",
                                "created_at": "2023-11-10T23:34:24.032Z",
                                "completed_at": "2023-11-10T23:35:12.456Z",
                                "export_path": "/exports/gdpr/gdpr_export_123_20231110_233424.json",
                                "data_types": ["settings", "memory", "sessions", "metrics", "account"],
                                "format": "json"
                            }
                        }
                    }
                }
            })
async def get_gdpr_export_status(
    request_id: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get GDPR export request status.

    - Returns current status of export request
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize export service
        export_service = ExportService()

        # Get export status
        export_request = await export_service.get_export_status(request_id)

        if not export_request:
            raise HTTPException(status_code=404, detail="Export request not found")

        # Verify ownership (in a real implementation)
        # For now, assume user owns the request

        return GDPRExportStatusResponse(
            request_id=export_request.request_id,
            status=export_request.status.value,
            created_at=export_request.created_at,
            completed_at=export_request.completed_at,
            export_path=export_request.export_path,
            error_message=export_request.error_message,
            data_types=export_request.data_types,
            format=export_request.format
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get GDPR export status error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/gdpr/export/{request_id}",
               summary="Cancelar exportación GDPR",
               description="""
               Cancela una solicitud de exportación GDPR pendiente o en progreso.

               **Parámetros de ruta:**
               - request_id: ID de la solicitud de exportación

               **Códigos de respuesta:**
               - 200: Exportación cancelada exitosamente
               - 400: No se puede cancelar (ya completada o fallida)
               - 401: Usuario no autenticado
               - 404: Solicitud no encontrada
               - 500: Error interno del servidor
               """)
async def cancel_gdpr_export(
    request_id: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Cancel GDPR export request.

    - Cancels pending or in-progress export
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize export service
        export_service = ExportService()

        # Cancel export
        cancelled = await export_service.cancel_export(request_id)

        if not cancelled:
            raise HTTPException(status_code=400, detail="Cannot cancel export (already completed or failed)")

        logger.info(f"GDPR export cancelled for user ID: {user_id}, request: {request_id}")
        return {"message": "Export cancelled successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Cancel GDPR export error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/data", response_model=DataDeletionStatusResponse,
               summary="Solicitar eliminación de datos (Derecho al olvido)",
               description="""
               Solicita la eliminación completa de todos los datos personales del usuario (Derecho al olvido GDPR).

               **Campos requeridos:**
               - data_types: Tipos de datos a eliminar
               - confirmation: Confirmación exacta "DELETE_ALL_DATA"

               **Tipos de datos disponibles:**
               - settings: Configuraciones de usuario
               - memory: Memoria conversacional
               - sessions: Sesiones federadas
               - metrics: Métricas de uso
               - account: Información de cuenta

               **Advertencia:** Esta operación es irreversible.

               **Códigos de respuesta:**
               - 200: Solicitud de eliminación creada exitosamente
               - 400: Datos inválidos o confirmación incorrecta
               - 401: Usuario no autenticado
               - 429: Demasiadas solicitudes pendientes
               - 500: Error interno del servidor
               """,
               responses={
                   200: {
                       "description": "Solicitud de eliminación de datos creada exitosamente",
                       "content": {
                           "application/json": {
                               "example": {
                                   "deletion_id": "data_deletion_20231110_233424",
                                   "status": "pending",
                                   "requested_at": "2023-11-10T23:34:24.032Z",
                                   "data_types_deleted": ["settings", "memory", "sessions", "metrics", "account"]
                               }
                           }
                       }
                   }
               })
async def request_data_deletion(
    request: DataDeletionRequest,
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Request complete data deletion (Right to be forgotten).

    - Initiates deletion of all user personal data
    - Processes deletion in background
    - Requires explicit confirmation
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Generate deletion ID
        deletion_id = f"data_deletion_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        # In a real implementation, this would:
        # 1. Create a deletion request record
        # 2. Queue the deletion task
        # 3. Send confirmation email
        # 4. Schedule actual deletion after confirmation period

        # For now, simulate immediate processing
        deletion_status = {
            'deletion_id': deletion_id,
            'status': 'completed',  # In real implementation, this would be 'pending'
            'requested_at': datetime.now(),
            'completed_at': datetime.now(),
            'data_types_deleted': request.data_types,
            'error_message': None
        }

        logger.warning(f"DATA DELETION REQUESTED for user ID: {user_id}, deletion: {deletion_id}, types: {request.data_types}")

        return DataDeletionStatusResponse(**deletion_status)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Request data deletion error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/data/retention",
            summary="Obtener información de retención de datos",
            description="""
            Obtiene información sobre la retención de datos del usuario actual.

            **Incluye:**
            - Período de retención configurado
            - Fecha de próxima eliminación automática
            - Tipos de datos sujetos a retención

            **Códigos de respuesta:**
            - 200: Información obtenida exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def get_data_retention_info(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get data retention information for current user.

    - Returns retention policy and schedule
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Get privacy settings
        privacy_settings = get_privacy_settings_from_db(user_id, db)

        # Calculate next deletion date
        retention_days = privacy_settings['data_retention_days']
        next_deletion = datetime.now() + timedelta(days=retention_days)

        return {
            "retention_period_days": retention_days,
            "next_auto_deletion": next_deletion.isoformat(),
            "data_types_retained": ["settings", "memory", "sessions", "metrics", "account"],
            "retention_policy": "GDPR compliant automatic deletion after retention period"
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get data retention info error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")