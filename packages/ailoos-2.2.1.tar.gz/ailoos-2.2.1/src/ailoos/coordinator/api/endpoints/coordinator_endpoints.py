"""
API endpoints for coordinator-specific operations.
Provides endpoints for active rounds, metrics, and sessions management.
"""

from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.dependencies import get_current_node
from ...services.round_service import RoundService
from ...services.session_service import SessionService
from ...services.node_service import NodeService
from ...models.schemas import APIResponse
from ...core.exceptions import CoordinatorException


router = APIRouter()


@router.get("/rounds/active", response_model=APIResponse)
async def get_active_rounds(
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get all active federated learning rounds for coordinator dashboard."""
    try:
        rounds = await RoundService.get_active_rounds(db=db)

        return APIResponse(
            success=True,
            message="Active rounds retrieved successfully",
            data={"rounds": rounds}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving active rounds: {str(e)}")


@router.get("/metrics", response_model=APIResponse)
async def get_coordinator_metrics(
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get real-time metrics for coordinator dashboard."""
    try:
        # Get active rounds count
        active_rounds_count = await RoundService.get_active_rounds_count(db)

        # Get active sessions count
        active_sessions_count = await SessionService.get_active_sessions_count(db)

        # Get active nodes count
        active_nodes_count = await NodeService.get_active_nodes_count(db)

        # Get total nodes count
        total_nodes_result = await NodeService.list_nodes(db=db, skip=0, limit=1000)
        total_nodes_count = total_nodes_result[1] if isinstance(total_nodes_result, tuple) else 0

        # Get total sessions count
        total_sessions_result = await SessionService.list_sessions(db=db, skip=0, limit=1000)
        total_sessions_count = total_sessions_result[1] if isinstance(total_sessions_result, tuple) else 0

        # Mock additional metrics for now
        metrics = {
            "active_rounds": active_rounds_count,
            "active_sessions": active_sessions_count,
            "active_nodes": active_nodes_count,
            "total_nodes": total_nodes_count,
            "total_sessions": total_sessions_count,
            "network_health": "good",
            "cpu_usage": 45.2,
            "memory_usage": 62.8,
            "disk_usage": 34.1,
            "network_latency": 12.5,
            "federation_efficiency": 87.3,
            "total_rewards_distributed": 15420.50,
            "data_processed_gb": 892.4,
            "uptime_hours": 168.5
        }

        return APIResponse(
            success=True,
            message="Coordinator metrics retrieved successfully",
            data=metrics
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving coordinator metrics: {str(e)}")


@router.get("/sessions", response_model=APIResponse)
async def get_coordinator_sessions(
    status: Optional[str] = Query(None, description="Filter by session status"),
    limit: int = Query(50, ge=1, le=200, description="Maximum number of sessions to return"),
    db: Session = Depends(get_db),
    current_node: dict = Depends(get_current_node)
):
    """Get sessions overview for coordinator dashboard."""
    try:
        sessions_result = await SessionService.list_sessions(
            db=db,
            skip=0,
            limit=limit,
            status=status
        )

        sessions, total = sessions_result

        # Get active sessions count
        active_count = await SessionService.get_active_sessions_count(db)

        # Get sessions by status
        active_sessions = await SessionService.get_sessions_by_status(db, "active", 10)
        completed_sessions = await SessionService.get_sessions_by_status(db, "completed", 10)

        sessions_data = {
            "total_sessions": total,
            "active_sessions_count": active_count,
            "sessions": sessions,
            "recent_active": active_sessions,
            "recent_completed": completed_sessions
        }

        return APIResponse(
            success=True,
            message="Coordinator sessions retrieved successfully",
            data=sessions_data
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving coordinator sessions: {str(e)}")