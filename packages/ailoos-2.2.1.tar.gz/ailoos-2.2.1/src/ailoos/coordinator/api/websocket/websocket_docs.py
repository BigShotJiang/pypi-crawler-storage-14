"""
Documentación OpenAPI/Swagger para endpoints WebSocket.
Este módulo proporciona documentación detallada para las conexiones WebSocket
y sus esquemas de mensajes.
"""

from typing import Dict, Any, List, Optional
from pydantic import BaseModel, Field
from datetime import datetime


# Esquemas de mensajes WebSocket
class WebSocketMessageBase(BaseModel):
    """Esquema base para mensajes WebSocket."""
    message_type: str = Field(..., description="Tipo de mensaje")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp del mensaje")
    session_id: Optional[str] = Field(None, description="ID de sesión (opcional)")
    node_id: Optional[str] = Field(None, description="ID de nodo (opcional)")


class SessionUpdateMessage(WebSocketMessageBase):
    """Mensaje de actualización de sesión federada."""
    message_type: str = "session_update"
    session_status: str = Field(..., description="Estado de la sesión")
    current_round: int = Field(..., description="Ronda actual")
    total_participants: int = Field(..., description="Total de participantes")
    active_participants: int = Field(..., description="Participantes activos")


class MetricsUpdateMessage(WebSocketMessageBase):
    """Mensaje de actualización de métricas."""
    message_type: str = "metrics_update"
    cpu_usage: float = Field(..., description="Uso de CPU (%)")
    memory_usage: float = Field(..., description="Uso de memoria (%)")
    active_nodes: int = Field(..., description="Nodos activos")
    active_sessions: int = Field(..., description="Sesiones activas")


class AlertMessage(WebSocketMessageBase):
    """Mensaje de alerta del sistema."""
    message_type: str = "alert"
    alert_level: str = Field(..., description="Nivel de alerta: info, warning, error, critical")
    alert_title: str = Field(..., description="Título de la alerta")
    alert_message: str = Field(..., description="Mensaje detallado de la alerta")
    affected_components: List[str] = Field(default_factory=list, description="Componentes afectados")


class FederatedEventMessage(WebSocketMessageBase):
    """Mensaje de evento federado."""
    message_type: str = "federated_event"
    event_type: str = Field(..., description="Tipo de evento: round_start, round_end, contribution_received, etc.")
    event_data: Dict[str, Any] = Field(..., description="Datos específicos del evento")


class NodeHeartbeatMessage(WebSocketMessageBase):
    """Mensaje de heartbeat de nodo."""
    message_type: str = "node_heartbeat"
    node_status: str = Field(..., description="Estado del nodo")
    last_seen: datetime = Field(..., description="Última vez visto")
    reputation_score: float = Field(..., description="Puntuación de reputación")


# Esquemas de respuesta para documentación
class WebSocketEndpointDoc(BaseModel):
    """Documentación de endpoint WebSocket."""
    url: str = Field(..., description="URL del endpoint WebSocket")
    description: str = Field(..., description="Descripción del endpoint")
    message_types: List[str] = Field(..., description="Tipos de mensajes soportados")
    authentication: str = Field(..., description="Método de autenticación requerido")
    example_messages: Dict[str, Any] = Field(..., description="Ejemplos de mensajes")


# Documentación completa de WebSocket
WEBSOCKET_DOCUMENTATION = {
    "session_websocket": WebSocketEndpointDoc(
        url="/api/v1/ws-api/session/{session_id}",
        description="""
        WebSocket para actualizaciones en tiempo real de sesiones federadas.

        **Funcionalidades:**
        - Actualizaciones de estado de sesión
        - Progreso de rondas de entrenamiento
        - Estadísticas de participantes
        - Eventos de contribución

        **Mensajes soportados:**
        - session_update: Cambios en el estado de la sesión
        - round_progress: Avance de rondas
        - participant_join/leave: Cambios en participantes
        """,
        message_types=["session_update", "round_progress", "participant_update"],
        authentication="JWT token en query parameter",
        example_messages={
            "session_update": {
                "message_type": "session_update",
                "timestamp": "2023-11-10T15:00:00Z",
                "session_id": "session_123",
                "session_status": "active",
                "current_round": 3,
                "total_participants": 10,
                "active_participants": 8
            }
        }
    ),

    "metrics_websocket": WebSocketEndpointDoc(
        url="/api/v1/ws-api/metrics",
        description="""
        WebSocket para métricas del sistema en tiempo real.

        **Funcionalidades:**
        - Métricas de rendimiento del sistema
        - Estadísticas de nodos y sesiones
        - Alertas de recursos
        - Monitoreo de salud

        **Mensajes soportados:**
        - metrics_update: Actualizaciones de métricas
        - system_alert: Alertas del sistema
        - resource_warning: Advertencias de recursos
        """,
        message_types=["metrics_update", "system_alert", "resource_warning"],
        authentication="JWT token requerido",
        example_messages={
            "metrics_update": {
                "message_type": "metrics_update",
                "timestamp": "2023-11-10T15:00:00Z",
                "cpu_usage": 45.2,
                "memory_usage": 67.8,
                "active_nodes": 12,
                "active_sessions": 3
            }
        }
    ),

    "alerts_websocket": WebSocketEndpointDoc(
        url="/api/v1/ws-api/alerts",
        description="""
        WebSocket para alertas y notificaciones del sistema.

        **Funcionalidades:**
        - Alertas críticas del sistema
        - Notificaciones de eventos importantes
        - Advertencias de seguridad
        - Mensajes de mantenimiento

        **Niveles de alerta:**
        - info: Información general
        - warning: Advertencias
        - error: Errores recuperables
        - critical: Errores críticos
        """,
        message_types=["alert", "notification", "system_message"],
        authentication="JWT token requerido",
        example_messages={
            "alert": {
                "message_type": "alert",
                "timestamp": "2023-11-10T15:00:00Z",
                "alert_level": "warning",
                "alert_title": "Alto uso de CPU",
                "alert_message": "El uso de CPU ha superado el 90%",
                "affected_components": ["coordinator", "inference_service"]
            }
        }
    ),

    "federated_websocket": WebSocketEndpointDoc(
        url="/api/v1/ws-api/federated",
        description="""
        WebSocket para eventos del sistema federado.

        **Funcionalidades:**
        - Eventos de aprendizaje federado
        - Actualizaciones de modelos
        - Sincronización de parámetros
        - Eventos de contribución

        **Mensajes soportados:**
        - federated_event: Eventos federados
        - model_update: Actualizaciones de modelo
        - contribution_received: Contribuciones recibidas
        """,
        message_types=["federated_event", "model_update", "contribution_received"],
        authentication="JWT token requerido",
        example_messages={
            "federated_event": {
                "message_type": "federated_event",
                "timestamp": "2023-11-10T15:00:00Z",
                "event_type": "round_start",
                "event_data": {
                    "round_number": 5,
                    "expected_contributions": 10,
                    "timeout_minutes": 30
                }
            }
        }
    )
}


def get_websocket_openapi_schema() -> Dict[str, Any]:
    """
    Genera el esquema OpenAPI para la documentación de WebSocket.

    Returns:
        Dict con el esquema OpenAPI para WebSocket
    """
    return {
        "WebSocketMessageBase": WebSocketMessageBase.schema(),
        "SessionUpdateMessage": SessionUpdateMessage.schema(),
        "MetricsUpdateMessage": MetricsUpdateMessage.schema(),
        "AlertMessage": AlertMessage.schema(),
        "FederatedEventMessage": FederatedEventMessage.schema(),
        "NodeHeartbeatMessage": NodeHeartbeatMessage.schema(),
        "WebSocketEndpointDoc": WebSocketEndpointDoc.schema(),
        "websocket_endpoints": WEBSOCKET_DOCUMENTATION
    }