#!/usr/bin/env python3
"""
Coordinator for Ailoos Federated Learning
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class FederatedCoordinator:
    """Main coordinator for federated learning sessions"""

    def __init__(self, config=None):
        self.active_sessions: Dict[str, Dict[str, Any]] = {}
        self.connected_nodes: Dict[str, Dict[str, Any]] = {}
        self.session_counter = 0
        self.config = config

    def get_global_status(self) -> Dict[str, Any]:
        """Get global federated learning status."""
        return {
            "active_sessions": len(self.active_sessions),
            "connected_nodes": len(self.connected_nodes),
            "total_sessions_created": self.session_counter
        }

    def get_session_status(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a session."""
        return self.active_sessions.get(session_id)

    def get_node_status(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a node."""
        return self.connected_nodes.get(node_id)

    def get_round_status(self, round_id: str) -> Dict[str, Any]:
        """Get status of a round."""
        # Mock implementation - in real implementation this would track rounds
        return {
            "round_id": round_id,
            "status": "active",
            "participants": 0,
            "completed_contributions": 0
        }


class Coordinator(FederatedCoordinator):
    """Main coordinator for federated learning sessions - backwards compatibility"""

    def __init__(self):
        super().__init__()

    async def create_session(self, session_config: Dict[str, Any]) -> str:
        """Create a new federated learning session"""
        session_id = f"session_{self.session_counter}"
        self.session_counter += 1

        session = {
            "session_id": session_id,
            "config": session_config,
            "status": "created",
            "created_at": datetime.now().isoformat(),
            "participants": [],
            "rounds_completed": 0,
            "total_rounds": session_config.get("rounds", 5)
        }

        self.active_sessions[session_id] = session
        logger.info(f"Created session {session_id}")
        return session_id

    async def register_node(self, node_id: str, node_info: Dict[str, Any]):
        """Register a node with the coordinator"""
        self.connected_nodes[node_id] = {
            "node_id": node_id,
            "info": node_info,
            "registered_at": datetime.now().isoformat(),
            "status": "active"
        }
        logger.info(f"Registered node {node_id}")

    async def get_session_status(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a session"""
        return self.active_sessions.get(session_id)

    def get_connected_nodes(self) -> List[str]:
        """Get list of connected node IDs"""
        return list(self.connected_nodes.keys())

    def get_active_sessions(self) -> List[str]:
        """Get list of active session IDs"""
        return list(self.active_sessions.keys())