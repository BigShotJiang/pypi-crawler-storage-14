"""
DRACMA Token Infrastructure - Infraestructura preparada para integración con token real.
Abstracción completa para facilitar la migración a token real cuando esté disponible.
"""

import asyncio
import json
import time
from typing import Dict, List, Any, Optional, Protocol, Union
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
import hashlib
import os

from web3 import Web3, AsyncWeb3
from web3.contract import Contract
try:
    from web3.middleware import geth_poa_middleware
except ImportError:
    try:
        # Fallback for older web3 versions
        from web3.middleware.geth_poa import geth_poa_middleware
    except ImportError:
        # Another fallback
        geth_poa_middleware = None
from eth_account import Account
from eth_account.signers.local import LocalAccount

from ..core.logging import get_logger, log_blockchain_tx

logger = get_logger(__name__)


class TokenStandard(Enum):
    """Estándares de token soportados."""
    ERC20 = "ERC20"
    ERC721 = "ERC721"
    ERC1155 = "ERC1155"
    BEP20 = "BEP20"
    CUSTOM = "CUSTOM"


class NetworkType(Enum):
    """Tipos de red blockchain."""
    ETHEREUM = "ethereum"
    POLYGON = "polygon"
    BSC = "bsc"
    ARBITRUM = "arbitrum"
    OPTIMISM = "optimism"
    LOCAL = "local"  # Para desarrollo/testing


@dataclass
class TokenConfig:
    """Configuración del token DRACMA."""
    name: str = "DRACMA"
    symbol: str = "DRACMA"
    decimals: int = 18
    total_supply: int = 1_000_000_000  # 1B tokens
    standard: TokenStandard = TokenStandard.ERC20
    network: NetworkType = NetworkType.LOCAL  # Default to local for testing

    # Contratos inteligentes
    token_contract_address: Optional[str] = None
    staking_contract_address: Optional[str] = None
    marketplace_contract_address: Optional[str] = None

    # Configuración RPC
    rpc_url: Optional[str] = None
    chain_id: Optional[int] = None

    # Configuración de wallets
    wallet_connect_project_id: Optional[str] = None


@dataclass
class TransactionResult:
    """Resultado de una transacción blockchain."""
    success: bool
    tx_hash: Optional[str] = None
    block_number: Optional[int] = None
    gas_used: Optional[int] = None
    error_message: Optional[str] = None
    events: List[Dict[str, Any]] = None

    def __post_init__(self):
        if self.events is None:
            self.events = []


class ITokenProvider(Protocol):
    """Interfaz para proveedores de token (simulado vs real)."""

    async def get_balance(self, address: str) -> float:
        """Obtiene balance de una dirección."""
        ...

    async def transfer(self, from_address: str, to_address: str, amount: float,
                      private_key: Optional[str] = None) -> TransactionResult:
        """Transfiere tokens entre direcciones."""
        ...

    async def approve(self, spender_address: str, amount: float,
                     private_key: Optional[str] = None) -> TransactionResult:
        """Aprueba gasto de tokens."""
        ...

    async def stake(self, amount: float, private_key: Optional[str] = None) -> TransactionResult:
        """Hace stake de tokens."""
        ...

    async def unstake(self, amount: float, private_key: Optional[str] = None) -> TransactionResult:
        """Hace unstake de tokens."""
        ...

    async def get_staking_info(self, address: str) -> Dict[str, Any]:
        """Obtiene información de staking."""
        ...

    async def get_transaction_history(self, address: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Obtiene historial de transacciones."""
        ...

    async def estimate_gas(self, from_address: str, to_address: str, amount: float) -> int:
        """Estima gas para una transacción."""
        ...





class RealTokenProvider(ITokenProvider):
    """
    Proveedor real de tokens para producción.
    Se conecta a blockchain real usando Web3.py.
    """

    def __init__(self, config: TokenConfig):
        self.config = config
        self.web3: Optional[AsyncWeb3] = None
        self.contract: Optional[Contract] = None
        self.staking_contract: Optional[Contract] = None
        self.account: Optional[LocalAccount] = None

        # Inicializar conexión
        self._initialize_web3()

        logger.info(f"🔗 RealTokenProvider initialized for {config.symbol} on {config.network.value}")

    def _initialize_web3(self):
        """Inicializa conexión Web3."""
        if not self.config.rpc_url:
            # Para testing, usar configuración local por defecto
            if self.config.network == NetworkType.LOCAL:
                self.config.rpc_url = "http://localhost:8545"
                self.config.chain_id = 1337
            else:
                raise ValueError("RPC URL is required for real token provider")

        # Crear instancia AsyncWeb3
        self.web3 = AsyncWeb3(AsyncWeb3.AsyncHTTPProvider(self.config.rpc_url))

        # Añadir middleware para redes PoA (como Polygon, BSC)
        if self.config.network in [NetworkType.POLYGON, NetworkType.BSC] and geth_poa_middleware:
            self.web3.middleware_onion.inject(geth_poa_middleware, layer=0)

        # Verificar conexión
        if not self.web3.is_connected():
            raise ConnectionError(f"Cannot connect to {self.config.rpc_url}")

        # Cargar contratos si están configurados
        if self.config.token_contract_address:
            self._load_token_contract()

        if self.config.staking_contract_address:
            self._load_staking_contract()

        # Configurar cuenta si hay private key
        private_key = os.getenv('DRACMA_PRIVATE_KEY')
        if private_key:
            self.account = Account.from_key(private_key)

        logger.info(f"✅ Connected to {self.config.network.value} at {self.config.rpc_url}")

    def _load_token_contract(self):
        """Carga contrato del token ERC20."""
        # ABI básica para ERC20
        erc20_abi = [
            {
                "constant": True,
                "inputs": [{"name": "_owner", "type": "address"}],
                "name": "balanceOf",
                "outputs": [{"name": "balance", "type": "uint256"}],
                "type": "function"
            },
            {
                "constant": False,
                "inputs": [
                    {"name": "_to", "type": "address"},
                    {"name": "_value", "type": "uint256"}
                ],
                "name": "transfer",
                "outputs": [{"name": "", "type": "bool"}],
                "type": "function"
            },
            {
                "constant": False,
                "inputs": [
                    {"name": "_spender", "type": "address"},
                    {"name": "_value", "type": "uint256"}
                ],
                "name": "approve",
                "outputs": [{"name": "", "type": "bool"}],
                "type": "function"
            }
        ]

        self.contract = self.web3.eth.contract(
            address=self.config.token_contract_address,
            abi=erc20_abi
        )

    def _load_staking_contract(self):
        """Carga contrato de staking."""
        # ABI básica para staking (simplificada)
        staking_abi = [
            {
                "constant": False,
                "inputs": [{"name": "_amount", "type": "uint256"}],
                "name": "stake",
                "outputs": [],
                "type": "function"
            },
            {
                "constant": False,
                "inputs": [{"name": "_amount", "type": "uint256"}],
                "name": "unstake",
                "outputs": [],
                "type": "function"
            },
            {
                "constant": True,
                "inputs": [{"name": "_user", "type": "address"}],
                "name": "getStakingInfo",
                "outputs": [
                    {"name": "stakedAmount", "type": "uint256"},
                    {"name": "rewards", "type": "uint256"}
                ],
                "type": "function"
            }
        ]

        self.staking_contract = self.web3.eth.contract(
            address=self.config.staking_contract_address,
            abi=staking_abi
        )

    async def get_balance(self, address: str) -> float:
        """Obtiene balance real desde blockchain."""
        if not self.contract:
            raise ValueError("Token contract not loaded")

        try:
            # Llamar al contrato
            balance_wei = await self.contract.functions.balanceOf(address).call()

            # Convertir de wei a tokens (dividir por 10^decimals)
            balance = balance_wei / (10 ** self.config.decimals)

            logger.info(f"💰 Balance for {address}: {balance} {self.config.symbol}")
            return balance

        except Exception as e:
            logger.error(f"❌ Error getting balance for {address}: {e}")
            raise

    async def transfer(self, from_address: str, to_address: str, amount: float,
                       private_key: Optional[str] = None) -> TransactionResult:
        """Transfiere tokens reales."""
        if not self.contract or not self.account:
            raise ValueError("Contract and account required for transfers")

        try:
            # Convertir amount a wei
            amount_wei = int(amount * (10 ** self.config.decimals))

            # Estimar gas
            gas_estimate = await self.contract.functions.transfer(to_address, amount_wei).estimate_gas({
                'from': self.account.address
            })

            # Crear transacción
            tx = await self.contract.functions.transfer(to_address, amount_wei).build_transaction({
                'from': self.account.address,
                'gas': gas_estimate,
                'gasPrice': await self.web3.eth.gas_price,
                'nonce': await self.web3.eth.get_transaction_count(self.account.address),
                'chainId': self.config.chain_id or 1
            })

            # Firmar transacción
            signed_tx = self.web3.eth.account.sign_transaction(tx, private_key or self.account.key)

            # Enviar transacción
            tx_hash = await self.web3.eth.send_raw_transaction(signed_tx.rawTransaction)

            # Esperar confirmación
            receipt = await self.web3.eth.wait_for_transaction_receipt(tx_hash)

            # Log de transacción
            log_blockchain_tx(
                tx_hash=tx_hash.hex(),
                tx_type="transfer",
                amount=amount,
                status="confirmed" if receipt.status == 1 else "failed",
                gas_used=receipt.gasUsed,
                from_addr=from_address,
                to_addr=to_address
            )

            return TransactionResult(
                success=receipt.status == 1,
                tx_hash=tx_hash.hex(),
                block_number=receipt.blockNumber,
                gas_used=receipt.gasUsed
            )

        except Exception as e:
            logger.error(f"❌ Error transferring tokens: {e}")
            return TransactionResult(success=False, error_message=str(e))

    async def approve(self, spender_address: str, amount: float,
                      private_key: Optional[str] = None) -> TransactionResult:
        """Aprueba gasto real."""
        if not self.contract or not self.account:
            raise ValueError("Contract and account required for approvals")

        try:
            amount_wei = int(amount * (10 ** self.config.decimals))

            gas_estimate = await self.contract.functions.approve(spender_address, amount_wei).estimate_gas({
                'from': self.account.address
            })

            tx = await self.contract.functions.approve(spender_address, amount_wei).build_transaction({
                'from': self.account.address,
                'gas': gas_estimate,
                'gasPrice': await self.web3.eth.gas_price,
                'nonce': await self.web3.eth.get_transaction_count(self.account.address),
                'chainId': self.config.chain_id or 1
            })

            signed_tx = self.web3.eth.account.sign_transaction(tx, private_key or self.account.key)
            tx_hash = await self.web3.eth.send_raw_transaction(signed_tx.rawTransaction)
            receipt = await self.web3.eth.wait_for_transaction_receipt(tx_hash)

            return TransactionResult(
                success=receipt.status == 1,
                tx_hash=tx_hash.hex(),
                block_number=receipt.blockNumber,
                gas_used=receipt.gasUsed
            )

        except Exception as e:
            logger.error(f"❌ Error approving tokens: {e}")
            return TransactionResult(success=False, error_message=str(e))

    async def stake(self, amount: float, private_key: Optional[str] = None) -> TransactionResult:
        """Staking real."""
        if not self.staking_contract or not self.account:
            raise ValueError("Staking contract and account required")

        try:
            amount_wei = int(amount * (10 ** self.config.decimals))

            gas_estimate = await self.staking_contract.functions.stake(amount_wei).estimate_gas({
                'from': self.account.address
            })

            tx = await self.staking_contract.functions.stake(amount_wei).build_transaction({
                'from': self.account.address,
                'gas': gas_estimate,
                'gasPrice': await self.web3.eth.gas_price,
                'nonce': await self.web3.eth.get_transaction_count(self.account.address),
                'chainId': self.config.chain_id or 1
            })

            signed_tx = self.web3.eth.account.sign_transaction(tx, private_key or self.account.key)
            tx_hash = await self.web3.eth.send_raw_transaction(signed_tx.rawTransaction)
            receipt = await self.web3.eth.wait_for_transaction_receipt(tx_hash)

            log_blockchain_tx(
                tx_hash=tx_hash.hex(),
                tx_type="stake",
                amount=amount,
                status="confirmed" if receipt.status == 1 else "failed",
                gas_used=receipt.gasUsed
            )

            return TransactionResult(
                success=receipt.status == 1,
                tx_hash=tx_hash.hex(),
                block_number=receipt.blockNumber,
                gas_used=receipt.gasUsed
            )

        except Exception as e:
            logger.error(f"❌ Error staking tokens: {e}")
            return TransactionResult(success=False, error_message=str(e))

    async def unstake(self, amount: float, private_key: Optional[str] = None) -> TransactionResult:
        """Unstaking real."""
        if not self.staking_contract or not self.account:
            raise ValueError("Staking contract and account required")

        try:
            amount_wei = int(amount * (10 ** self.config.decimals))

            gas_estimate = await self.staking_contract.functions.unstake(amount_wei).estimate_gas({
                'from': self.account.address
            })

            tx = await self.staking_contract.functions.unstake(amount_wei).build_transaction({
                'from': self.account.address,
                'gas': gas_estimate,
                'gasPrice': await self.web3.eth.gas_price,
                'nonce': await self.web3.eth.get_transaction_count(self.account.address),
                'chainId': self.config.chain_id or 1
            })

            signed_tx = self.web3.eth.account.sign_transaction(tx, private_key or self.account.key)
            tx_hash = await self.web3.eth.send_raw_transaction(signed_tx.rawTransaction)
            receipt = await self.web3.eth.wait_for_transaction_receipt(tx_hash)

            log_blockchain_tx(
                tx_hash=tx_hash.hex(),
                tx_type="unstake",
                amount=amount,
                status="confirmed" if receipt.status == 1 else "failed",
                gas_used=receipt.gasUsed
            )

            return TransactionResult(
                success=receipt.status == 1,
                tx_hash=tx_hash.hex(),
                block_number=receipt.blockNumber,
                gas_used=receipt.gasUsed
            )

        except Exception as e:
            logger.error(f"❌ Error unstaking tokens: {e}")
            return TransactionResult(success=False, error_message=str(e))

    async def get_staking_info(self, address: str) -> Dict[str, Any]:
        """Información de staking real."""
        if not self.staking_contract:
            raise ValueError("Staking contract not loaded")

        try:
            result = await self.staking_contract.functions.getStakingInfo(address).call()
            staked_wei, rewards_wei = result

            staked_amount = staked_wei / (10 ** self.config.decimals)
            rewards_amount = rewards_wei / (10 ** self.config.decimals)

            multiplier = self._calculate_staking_multiplier(staked_amount)

            return {
                "staked_amount": staked_amount,
                "rewards_amount": rewards_amount,
                "multiplier": multiplier,
                "estimated_daily_reward": staked_amount * 0.001 * multiplier,
                "total_staked": await self._get_total_staked(),
                "staking_apr": await self._calculate_current_apr()
            }

        except Exception as e:
            logger.error(f"❌ Error getting staking info for {address}: {e}")
            raise

    async def get_transaction_history(self, address: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Historial real de transacciones."""
        try:
            # Get latest block number
            latest_block = await self.web3.eth.block_number

            # Search for transactions in recent blocks (last 10000 blocks)
            start_block = max(0, latest_block - 10000)

            transactions = []
            for block_num in range(latest_block, start_block, -1):
                try:
                    block = await self.web3.eth.get_block(block_num, full_transactions=True)
                    for tx in block.transactions:
                        # Check if address is involved
                        if tx.get('from', '').lower() == address.lower() or tx.get('to', '').lower() == address.lower():
                            # Get transaction receipt for status
                            receipt = await self.web3.eth.get_transaction_receipt(tx.hash)

                            tx_data = {
                                "hash": tx.hash.hex(),
                                "from": tx.get('from', ''),
                                "to": tx.get('to', ''),
                                "value": float(tx.get('value', 0)) / (10 ** 18),  # Convert from wei
                                "timestamp": block.timestamp,
                                "blockNumber": block_num,
                                "gasUsed": receipt.gasUsed if receipt else 0,
                                "status": "confirmed" if receipt and receipt.status == 1 else "failed",
                                "type": "native_transfer"  # Could be enhanced to detect token transfers
                            }
                            transactions.append(tx_data)

                            if len(transactions) >= limit:
                                break
                    if len(transactions) >= limit:
                        break
                except Exception as e:
                    logger.debug(f"Error processing block {block_num}: {e}")
                    continue

            logger.info(f"📋 Retrieved {len(transactions)} transactions for {address}")
            return transactions[:limit]

        except Exception as e:
            logger.error(f"❌ Error getting transaction history for {address}: {e}")
            return []

    async def estimate_gas(self, from_address: str, to_address: str, amount: float) -> int:
        """Estimación real de gas."""
        if not self.contract:
            raise ValueError("Token contract not loaded")

        try:
            amount_wei = int(amount * (10 ** self.config.decimals))
            gas_estimate = await self.contract.functions.transfer(to_address, amount_wei).estimate_gas({
                'from': from_address
            })
            return gas_estimate

        except Exception as e:
            logger.error(f"❌ Error estimating gas: {e}")
            return 21000  # Gas estándar como fallback

    def _calculate_staking_multiplier(self, staked_amount: float) -> float:
        """Calcula multiplicador basado en cantidad staked."""
        if staked_amount >= 10000:  # 10K+
            return 2.0
        elif staked_amount >= 1000:  # 1K+
            return 1.5
        elif staked_amount >= 100:   # 100+
            return 1.2
        else:
            return 1.0


class MockTokenProvider(ITokenProvider):
    """
    Proveedor simulado de tokens para desarrollo/testing.
    No se conecta a blockchain real.
    """

    def __init__(self, config: TokenConfig):
        self.config = config
        self.balances: Dict[str, float] = {}
        self.staking_info: Dict[str, Dict[str, Any]] = {}
        self.transactions: List[Dict[str, Any]] = []

        logger.info(f"🎭 MockTokenProvider initialized for {config.symbol}")

    async def get_balance(self, address: str) -> float:
        """Obtiene balance simulado."""
        balance = self.balances.get(address, 1000.0)  # Balance inicial de 1000 tokens
        logger.info(f"💰 Mock balance for {address}: {balance} {self.config.symbol}")
        return balance

    async def transfer(self, from_address: str, to_address: str, amount: float,
                       private_key: Optional[str] = None) -> TransactionResult:
        """Transfiere tokens simulados."""
        if self.balances.get(from_address, 1000.0) < amount:
            return TransactionResult(success=False, error_message="Insufficient balance")

        # Actualizar balances
        self.balances[from_address] = self.balances.get(from_address, 1000.0) - amount
        self.balances[to_address] = self.balances.get(to_address, 1000.0) + amount

        # Registrar transacción
        tx_hash = f"mock_tx_{len(self.transactions)}"
        self.transactions.append({
            "hash": tx_hash,
            "from": from_address,
            "to": to_address,
            "amount": amount,
            "timestamp": time.time()
        })

        logger.info(f"✅ Mock transfer: {amount} {self.config.symbol} from {from_address} to {to_address}")
        return TransactionResult(success=True, tx_hash=tx_hash)

    async def approve(self, spender_address: str, amount: float,
                      private_key: Optional[str] = None) -> TransactionResult:
        """Aprueba gasto simulado."""
        tx_hash = f"mock_approve_{len(self.transactions)}"
        logger.info(f"✅ Mock approve: {amount} {self.config.symbol} for {spender_address}")
        return TransactionResult(success=True, tx_hash=tx_hash)

    async def stake(self, amount: float, private_key: Optional[str] = None) -> TransactionResult:
        """Staking simulado."""
        tx_hash = f"mock_stake_{len(self.transactions)}"
        logger.info(f"✅ Mock stake: {amount} {self.config.symbol}")
        return TransactionResult(success=True, tx_hash=tx_hash)

    async def unstake(self, amount: float, private_key: Optional[str] = None) -> TransactionResult:
        """Unstaking simulado."""
        tx_hash = f"mock_unstake_{len(self.transactions)}"
        logger.info(f"✅ Mock unstake: {amount} {self.config.symbol}")
        return TransactionResult(success=True, tx_hash=tx_hash)

    async def get_staking_info(self, address: str) -> Dict[str, Any]:
        """Información de staking simulada."""
        return {
            "staked_amount": self.staking_info.get(address, {}).get("staked_amount", 0.0),
            "rewards_amount": self.staking_info.get(address, {}).get("rewards_amount", 0.0),
            "multiplier": 1.0,
            "estimated_daily_reward": 0.0,
            "total_staked": sum(info.get("staked_amount", 0) for info in self.staking_info.values()),
            "staking_apr": 5.0
        }

    async def get_transaction_history(self, address: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Historial simulado de transacciones."""
        return self.transactions[-limit:] if self.transactions else []

    async def estimate_gas(self, from_address: str, to_address: str, amount: float) -> int:
        """Estimación simulada de gas."""
        return 21000


class DRACMATokenManager:
    """
    Gestor principal del token DRACMA.
    Usa proveedor simulado por defecto para desarrollo.
    """

    def __init__(self, config: Optional[TokenConfig] = None):
        self.config = config or TokenConfig()
        # Usar MockTokenProvider por defecto para evitar problemas de conexión
        self.provider: ITokenProvider = MockTokenProvider(self.config)

        logger.info("🪙 DRACMA Token Manager initialized with mock provider")

    async def initialize_user_wallet(self, user_id: str) -> str:
        """
        Inicializa wallet para nuevo usuario.

        Args:
            user_id: ID del usuario

        Returns:
            Dirección de la wallet
        """
        # Generar dirección determinística basada en user_id
        address = f"0x{hashlib.sha256(f'ailoos_user_{user_id}'.encode()).hexdigest()[:40]}"

        logger.info(f"🎁 Initialized wallet for user {user_id}: {address}")
        return address

    async def get_user_balance(self, user_address: str) -> float:
        """Obtiene balance de usuario."""
        return await self.provider.get_balance(user_address)

    async def transfer_tokens(self, from_address: str, to_address: str, amount: float,
                             private_key: Optional[str] = None) -> TransactionResult:
        """Transfiere tokens entre direcciones."""
        return await self.provider.transfer(from_address, to_address, amount, private_key)

    async def stake_tokens(self, user_address: str, amount: float,
                          private_key: Optional[str] = None) -> TransactionResult:
        """Hace stake de tokens."""
        return await self.provider.stake(amount, private_key or user_address)

    async def unstake_tokens(self, user_address: str, amount: float,
                            private_key: Optional[str] = None) -> TransactionResult:
        """Hace unstake de tokens."""
        return await self.provider.unstake(amount, private_key or user_address)

    async def get_staking_rewards(self, user_address: str) -> Dict[str, Any]:
        """Obtiene información de rewards de staking."""
        return await self.provider.get_staking_info(user_address)

    async def get_transaction_history(self, user_address: str, limit: int = 20) -> List[Dict[str, Any]]:
        """Obtiene historial de transacciones."""
        return await self.provider.get_transaction_history(user_address, limit)

    async def marketplace_purchase(self, buyer_address: str, seller_address: str,
                                  amount: float, data_hash: str, ipfs_cid: str,
                                  private_key: Optional[str] = None) -> TransactionResult:
        """
        Procesa compra en marketplace con metadata adicional.
        """
        # Transferir tokens
        result = await self.provider.transfer(
            buyer_address,
            seller_address,
            amount,
            private_key
        )

        if result.success:
            # Aquí se añadiría metadata de la compra al resultado
            result.events.append({
                "event": "MarketplacePurchase",
                "buyer": buyer_address,
                "seller": seller_address,
                "amount": amount,
                "data_hash": data_hash,
                "ipfs_cid": ipfs_cid
            })

        return result



    def get_token_info(self) -> Dict[str, Any]:
        """Obtiene información del token."""
        return {
            "name": self.config.name,
            "symbol": self.config.symbol,
            "decimals": self.config.decimals,
            "total_supply": self.config.total_supply,
            "standard": self.config.standard.value,
            "network": self.config.network.value,
            "contract_address": self.config.token_contract_address
        }


# Instancia global del gestor de tokens
token_manager = DRACMATokenManager()


def get_token_manager() -> DRACMATokenManager:
    """Obtiene instancia global del gestor de tokens."""
    return token_manager


async def initialize_dracma_infrastructure():
    """
    Inicializa la infraestructura completa del token DRACMA.
    Función de conveniencia para setup inicial.
    """
    manager = get_token_manager()

    # Aquí irían inicializaciones adicionales como:
    # - Conexión a nodos blockchain
    # - Sincronización de contratos
    # - Setup de listeners de eventos
    # - etc.

    logger.info("🏗️ DRACMA infrastructure initialized")
    return manager