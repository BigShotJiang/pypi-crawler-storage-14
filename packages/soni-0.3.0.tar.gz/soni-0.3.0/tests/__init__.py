"""Tests for Soni Framework"""
