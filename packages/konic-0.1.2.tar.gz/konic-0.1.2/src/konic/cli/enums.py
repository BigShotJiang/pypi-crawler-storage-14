from enum import Enum


class BoilerplateOptions(str, Enum):
    basic = "basic"
