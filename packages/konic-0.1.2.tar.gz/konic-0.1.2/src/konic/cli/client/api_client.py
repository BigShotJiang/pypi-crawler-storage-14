import functools
import os
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypeVar

import httpx
from dotenv import load_dotenv

from konic.cli.env_keys import KonicCLIEnvVars
from konic.common.errors import KonicEnvironmentError, KonicHTTPError

F = TypeVar("F", bound=Callable[..., Any])


def handle_http_errors[F: Callable[..., Any]](func: F) -> F:
    """
    Decorator to handle HTTP errors for API client methods.
    Converts httpx.HTTPStatusError into KonicHTTPError with detailed information.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        response = func(*args, **kwargs)
        try:
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as e:
            try:
                error_detail = response.json().get("detail", str(e))
            except Exception:
                error_detail = response.text or str(e)

            raise KonicHTTPError(
                message=error_detail,
                status_code=response.status_code,
                endpoint=str(response.url),
                response_body=response.text[:500] if response.text else None,
            )

    return wrapper  # type: ignore


class KonicAPIClient:
    def __init__(self):
        load_dotenv()

        headers = {"Accept": "application/json", "User-Agent": "konic-cli/0.1.0"}

        self.BASE_URL = os.environ.get(KonicCLIEnvVars.KONIC_HOST.value, "")
        if self.BASE_URL is None or self.BASE_URL == "":
            raise KonicEnvironmentError(
                env_var=KonicCLIEnvVars.KONIC_HOST.value,
                suggestion=f"export {KonicCLIEnvVars.KONIC_HOST.value}=<host-url>",
            )

        self.APIKEY = None  # TODO: not-implemented yet
        self.client = httpx.Client(base_url=self.BASE_URL, headers=headers)

    @handle_http_errors
    def get(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """
        Perform a GET request.

        Args:
            endpoint: The API endpoint to call
            params: Optional query parameters
            headers: Optional additional headers

        Returns:
            httpx.Response: The response object

        Raises:
            KonicHTTPError: If the request fails
        """
        return self.client.get(endpoint, params=params, headers=headers)

    @handle_http_errors
    def post(
        self,
        endpoint: str,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """
        Perform a POST request.

        Args:
            endpoint: The API endpoint to call
            json: Optional JSON body
            data: Optional form data
            headers: Optional additional headers

        Returns:
            httpx.Response: The response object

        Raises:
            KonicHTTPError: If the request fails
        """
        return self.client.post(endpoint, json=json, data=data, headers=headers)

    @handle_http_errors
    def put(
        self,
        endpoint: str,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """
        Perform a PUT request.

        Args:
            endpoint: The API endpoint to call
            json: Optional JSON body
            data: Optional form data
            headers: Optional additional headers

        Returns:
            httpx.Response: The response object

        Raises:
            KonicHTTPError: If the request fails
        """
        return self.client.put(endpoint, json=json, data=data, headers=headers)

    @handle_http_errors
    def patch(
        self,
        endpoint: str,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """
        Perform a PATCH request.

        Args:
            endpoint: The API endpoint to call
            json: Optional JSON body
            data: Optional form data
            headers: Optional additional headers

        Returns:
            httpx.Response: The response object

        Raises:
            KonicHTTPError: If the request fails
        """
        return self.client.patch(endpoint, json=json, data=data, headers=headers)

    @handle_http_errors
    def delete(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """
        Perform a DELETE request.

        Args:
            endpoint: The API endpoint to call
            params: Optional query parameters
            headers: Optional additional headers

        Returns:
            httpx.Response: The response object

        Raises:
            KonicHTTPError: If the request fails
        """
        return self.client.delete(endpoint, params=params, headers=headers)

    def get_json(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """
        Perform a GET request and return JSON response.

        Args:
            endpoint: The API endpoint to call
            params: Optional query parameters
            headers: Optional additional headers

        Returns:
            Any: The parsed JSON response

        Raises:
            KonicHTTPError: If the request fails
        """
        response = self.get(endpoint, params=params, headers=headers)
        return response.json()

    def post_json(
        self,
        endpoint: str,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """
        Perform a POST request and return JSON response.

        Args:
            endpoint: The API endpoint to call
            json: Optional JSON body
            data: Optional form data
            headers: Optional additional headers

        Returns:
            Any: The parsed JSON response

        Raises:
            KonicHTTPError: If the request fails
        """
        response = self.post(endpoint, json=json, data=data, headers=headers)
        return response.json()

    def put_json(
        self,
        endpoint: str,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """
        Perform a PUT request and return JSON response.

        Args:
            endpoint: The API endpoint to call
            json: Optional JSON body
            data: Optional form data
            headers: Optional additional headers

        Returns:
            Any: The parsed JSON response

        Raises:
            KonicHTTPError: If the request fails
        """
        response = self.put(endpoint, json=json, data=data, headers=headers)
        return response.json()

    def patch_json(
        self,
        endpoint: str,
        json: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """
        Perform a PATCH request and return JSON response.

        Args:
            endpoint: The API endpoint to call
            json: Optional JSON body
            data: Optional form data
            headers: Optional additional headers

        Returns:
            Any: The parsed JSON response

        Raises:
            KonicHTTPError: If the request fails
        """
        response = self.patch(endpoint, json=json, data=data, headers=headers)
        return response.json()

    def delete_json(
        self,
        endpoint: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """
        Perform a DELETE request and return JSON response.

        Args:
            endpoint: The API endpoint to call
            params: Optional query parameters
            headers: Optional additional headers

        Returns:
            Any: The parsed JSON response

        Raises:
            KonicHTTPError: If the request fails
        """
        response = self.delete(endpoint, params=params, headers=headers)
        return response.json()

    def close(self):
        """Close the HTTP client connection."""
        self.client.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    def set_base_url(self, base_url: str) -> None:
        """
        Update the base URL for the client.

        Args:
            base_url: The new base URL to use for requests
        """
        self.BASE_URL = base_url
        headers = {"Accept": "application/json", "User-Agent": "konic-cli/0.1.0"}
        self.client = httpx.Client(base_url=self.BASE_URL, headers=headers)

    @handle_http_errors
    def upload_file(
        self,
        endpoint: str,
        file_path: Path,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """
        Upload a file via multipart/form-data POST request.

        Args:
            endpoint: The API endpoint to call
            file_path: Path to the file to upload
            headers: Optional additional headers

        Returns:
            httpx.Response: The response object

        Raises:
            KonicHTTPError: If the request fails
            FileNotFoundError: If the file does not exist
        """
        with open(file_path, "rb") as f:
            files = {"file": (file_path.name, f, "application/octet-stream")}
            return self.client.post(endpoint, files=files, headers=headers)

    def upload_file_json(
        self,
        endpoint: str,
        file_path: Path,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """
        Upload a file and return JSON response.

        Args:
            endpoint: The API endpoint to call
            file_path: Path to the file to upload
            headers: Optional additional headers

        Returns:
            Any: The parsed JSON response

        Raises:
            KonicHTTPError: If the request fails
        """
        response = self.upload_file(endpoint, file_path, headers=headers)
        return response.json()

    def download_file(
        self,
        endpoint: str,
        output_path: Path,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Path:
        """
        Download a file from the API and save it to disk.

        Args:
            endpoint: The API endpoint to call
            output_path: Path where the file should be saved
            params: Optional query parameters
            headers: Optional additional headers

        Returns:
            Path: The path to the downloaded file

        Raises:
            KonicHTTPError: If the request fails
        """
        with self.client.stream("GET", endpoint, params=params, headers=headers) as response:
            try:
                response.raise_for_status()
            except httpx.HTTPStatusError:
                try:
                    error_detail = response.json().get("detail", str(response.status_code))
                except Exception:
                    error_detail = response.text or str(response.status_code)

                raise KonicHTTPError(
                    message=error_detail,
                    status_code=response.status_code,
                    endpoint=str(response.url),
                    response_body=response.text[:500] if response.text else None,
                )

            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, "wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)

        return output_path
