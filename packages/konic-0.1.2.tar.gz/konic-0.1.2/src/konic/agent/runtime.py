import inspect
from typing import Any

from konic.agent import KonicAgent
from konic.common.errors.cli import KonicValidationError

_REGISTERED_AGENT_INSTANCE = None
_REGISTERED_ENV_CLASS = None


def _perform_registration(agent_instance: KonicAgent, name: str):
    global _REGISTERED_AGENT_INSTANCE, _REGISTERED_ENV_CLASS

    if not name:
        raise KonicValidationError("Agent name is required.")

    if inspect.isclass(agent_instance):
        raise KonicValidationError(
            f"Expected an agent instance, got class {agent_instance.__name__}. Please instantiate it first."
        )

    env_class = agent_instance.get_environment()

    try:
        setattr(
            agent_instance,
            "_konic_meta",
            {"name": name, "env_module": env_class},
        )
    except AttributeError as e:
        raise KonicValidationError(f"Failed to set metadata on agent instance: {e}") from e

    _REGISTERED_AGENT_INSTANCE = agent_instance
    _REGISTERED_ENV_CLASS = env_class

    return agent_instance


def register_agent(agent_instance: Any, name: str):
    return _perform_registration(agent_instance, name)


def get_registered_agent():
    return _REGISTERED_AGENT_INSTANCE, _REGISTERED_ENV_CLASS
