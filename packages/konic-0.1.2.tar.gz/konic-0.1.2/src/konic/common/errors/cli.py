"""CLI and API Client specific error classes for Konic."""

from konic.common.errors.base import KonicError

__all__ = [
    "KonicCLIError",
    "KonicConfigurationError",
    "KonicAPIClientError",
    "KonicHTTPError",
    "KonicValidationError",
    "KonicEnvironmentError",
    "KonicAgentNotFoundError",
    "KonicAgentConflictError",
    "KonicAgentResolutionError",
]


class KonicCLIError(KonicError):
    """Base exception for CLI-related errors."""

    def __init__(self, message: str, exit_code: int = 1):
        """
        Initialize CLI error.

        Args:
            message: The error message
            exit_code: The exit code to use when this error occurs
        """
        super().__init__(message)
        self.exit_code = exit_code


class KonicConfigurationError(KonicCLIError):
    """Exception raised when there are configuration issues (missing env vars, invalid config, etc.)."""

    def __init__(self, message: str, config_key: str | None = None):
        """
        Initialize configuration error.

        Args:
            message: The error message
            config_key: The configuration key that caused the error
        """
        super().__init__(message, exit_code=1)
        self.config_key = config_key


class KonicEnvironmentError(KonicConfigurationError):
    """Exception raised when required environment variables are missing or invalid."""

    def __init__(self, env_var: str, suggestion: str | None = None):
        """
        Initialize environment error.

        Args:
            env_var: The environment variable that is missing or invalid
            suggestion: Optional suggestion on how to set the variable
        """
        message = f"Missing or invalid environment variable: {env_var}"
        if suggestion:
            message += f"\n💡 Suggestion: {suggestion}"
        super().__init__(message, config_key=env_var)
        self.env_var = env_var


class KonicAPIClientError(KonicCLIError):
    """Base exception for API client errors."""

    def __init__(self, message: str, endpoint: str | None = None):
        """
        Initialize API client error.

        Args:
            message: The error message
            endpoint: The API endpoint that caused the error
        """
        super().__init__(message, exit_code=1)
        self.endpoint = endpoint


class KonicHTTPError(KonicAPIClientError):
    """Exception raised when HTTP requests fail."""

    def __init__(
        self,
        message: str,
        status_code: int,
        endpoint: str | None = None,
        response_body: str | None = None,
    ):
        """
        Initialize HTTP error.

        Args:
            message: The error message
            status_code: HTTP status code
            endpoint: The API endpoint that caused the error
            response_body: Optional response body for debugging
        """
        super().__init__(message, endpoint=endpoint)
        self.status_code = status_code
        self.response_body = response_body

    def __str__(self) -> str:
        """Return formatted error message."""
        base = f"HTTP {self.status_code}"
        if self.endpoint:
            base += f" at {self.endpoint}"
        base += f": {self.message}"
        return base


class KonicValidationError(KonicCLIError):
    """Exception raised when input validation fails."""

    def __init__(self, message: str, field: str | None = None):
        """
        Initialize validation error.

        Args:
            message: The error message
            field: The field that failed validation
        """
        super().__init__(message, exit_code=1)
        self.field = field


class KonicAgentNotFoundError(KonicAPIClientError):
    """Exception raised when an agent is not found (404)."""

    def __init__(self, agent_identifier: str):
        """
        Initialize agent not found error.

        Args:
            agent_identifier: The agent name or ID that was not found
        """
        message = f"Agent not found: {agent_identifier}"
        super().__init__(message, endpoint="/agents")
        self.agent_identifier = agent_identifier


class KonicAgentConflictError(KonicAPIClientError):
    """Exception raised when there's a conflict creating an agent (409), e.g., duplicate name."""

    def __init__(self, agent_name: str):
        """
        Initialize agent conflict error.

        Args:
            agent_name: The agent name that caused the conflict
        """
        message = f"Agent with name '{agent_name}' already exists. Use 'konic agent update' to add a new version."
        super().__init__(message, endpoint="/agents/upload")
        self.agent_name = agent_name


class KonicAgentResolutionError(KonicAPIClientError):
    """Exception raised when multiple agents match a given name."""

    def __init__(self, agent_name: str, count: int):
        """
        Initialize agent resolution error.

        Args:
            agent_name: The agent name that matched multiple agents
            count: The number of agents that matched
        """
        message = f"Multiple agents ({count}) found with name '{agent_name}'. Please use the agent ID instead."
        super().__init__(message, endpoint="/agents")
        self.agent_name = agent_name
        self.count = count
