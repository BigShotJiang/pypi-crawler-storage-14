import pytest

from konic.agent import KonicAgent
from konic.agent.runtime import _perform_registration, get_registered_agent, register_agent
from konic.common.errors.cli import KonicValidationError
from konic.environment import KonicEnvironment
from konic.environment.reward import KonicRewardComposer
from konic.environment.space.space import KonicSpace
from konic.environment.space.type import KonicDiscrete
from konic.environment.termination import KonicTerminationComposer


class MockActionSpace(KonicSpace):
    """Mock action space for testing."""

    action: KonicDiscrete = 3


class MockObservationSpace(KonicSpace):
    """Mock observation space for testing."""

    observation: KonicDiscrete = 5


class MockRewardComposer(KonicRewardComposer):
    """Mock reward composer for testing."""

    def reward(self) -> float:
        return 1.0


class MockTerminationComposer(KonicTerminationComposer):
    """Mock termination composer for testing."""

    def terminated(self) -> bool:
        return False


class MockEnvironment(KonicEnvironment):
    """Mock environment for testing."""

    def __init__(self):
        super().__init__(
            action_space=MockActionSpace(),
            observation_space=MockObservationSpace(),
            reward_composer=MockRewardComposer(),
            termination_composer=MockTerminationComposer(),
        )

    def reset(self):
        return {"observation": 0}

    def step(self, action):
        return {"observation": 1}, 1.0, False, False, {}


class TestAgentRegistration:
    """Test cases for agent registration functionality."""

    def setup_method(self):
        """Reset global state before each test."""

        import konic.agent.runtime as runtime

        runtime._REGISTERED_AGENT_INSTANCE = None
        runtime._REGISTERED_ENV_CLASS = None

    def test_register_agent_success(self):
        """Test successful agent registration."""
        env = MockEnvironment()
        agent = KonicAgent(environment=env)
        agent_instance = agent

        result = register_agent(agent_instance, "test_agent")

        assert result is agent_instance
        registered_agent, registered_env = get_registered_agent()
        assert registered_agent is agent_instance
        assert registered_env is env
        assert hasattr(agent_instance, "_konic_meta")
        meta = getattr(agent_instance, "_konic_meta")
        assert meta["name"] == "test_agent"
        assert meta["env_module"] is env

    def test_register_agent_empty_name_raises_error(self):
        """Test that registering with empty name raises error."""
        env = MockEnvironment()
        agent = KonicAgent(environment=env)

        with pytest.raises(KonicValidationError, match="Agent name is required"):
            register_agent(agent, "")

    def test_register_agent_without_environment_raises_error(self):
        """Test that agent without environment raises error during registration."""
        agent = KonicAgent()

        with pytest.raises(Exception):
            register_agent(agent, "test_agent")

    def test_get_registered_agent_initially_none(self):
        """Test that initially no agent is registered."""
        agent, env = get_registered_agent()
        assert agent is None
        assert env is None

    def test_perform_registration_direct_call(self):
        """Test calling _perform_registration directly."""
        env = MockEnvironment()
        agent = KonicAgent(environment=env)

        result = _perform_registration(agent, "direct_test")

        assert result is agent
        registered_agent, registered_env = get_registered_agent()
        assert registered_agent is agent
        assert registered_env is env
        assert hasattr(agent, "_konic_meta")
        meta = getattr(agent, "_konic_meta")
        assert meta["name"] == "direct_test"

    def test_perform_registration_empty_name(self):
        """Test _perform_registration with empty name."""
        env = MockEnvironment()
        agent = KonicAgent(environment=env)

        with pytest.raises(KonicValidationError, match="Agent name is required"):
            _perform_registration(agent, "")
