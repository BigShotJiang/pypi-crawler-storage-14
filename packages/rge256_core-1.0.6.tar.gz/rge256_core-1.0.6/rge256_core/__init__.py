from .rge256_core import RGE256
