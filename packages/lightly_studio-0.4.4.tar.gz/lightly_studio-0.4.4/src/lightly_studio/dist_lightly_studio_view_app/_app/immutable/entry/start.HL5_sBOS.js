import{l as o,e as r}from"../chunks/DoHM1I9c.js";export{o as load_css,r as start};
