import{q as o,E as f,v as i,x as p,y as c,z as d,A as h}from"./B-I5x6eV.js";function y(e,n,...t){var s=e,r=p,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=i(()=>r(s,...t)))},f),d&&(s=h)}export{y as s};
