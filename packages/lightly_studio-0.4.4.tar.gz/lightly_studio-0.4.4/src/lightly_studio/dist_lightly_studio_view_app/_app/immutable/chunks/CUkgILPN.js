import"./CWj6FrbW.js";import{p as n,f as i,x as m,a as c}from"./B-I5x6eV.js";import{c as d,a as f}from"./BGpqse05.js";import{s as l}from"./DxjuJ8y7.js";import{s as u,r as h}from"./B0-u5Ga-.js";import{I as $}from"./Do678iri.js";function y(r,o){n(o,!0);/**
 * @license @lucide/svelte v0.482.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */let t=h(o,["$$slots","$$events","$$legacy"]);const a=[["path",{d:"M5 12h14"}]];$(r,u({name:"minus"},()=>t,{get iconNode(){return a},children:(e,_)=>{var s=d(),p=i(s);l(p,()=>o.children??m),f(e,s)},$$slots:{default:!0}})),c()}export{y as default};
