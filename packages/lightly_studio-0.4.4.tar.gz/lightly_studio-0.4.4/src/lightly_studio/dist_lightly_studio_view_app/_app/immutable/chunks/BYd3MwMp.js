import{r as a}from"./BRi4yukY.js";const s=async()=>{const{data:t}=await a();if(!t)throw"No dataset found";return t};export{s as u};
