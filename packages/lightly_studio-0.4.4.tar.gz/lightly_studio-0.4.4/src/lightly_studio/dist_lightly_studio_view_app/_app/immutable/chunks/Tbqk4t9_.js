import{P as e}from"./wc2kT3m0.js";const o=a=>`${e}/sample/${a}`;export{o as g};
