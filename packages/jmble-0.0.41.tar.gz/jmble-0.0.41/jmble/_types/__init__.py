""" General type definitions """

from ._attr_dict import AttrDict

__all__ = ["AttrDict"]
