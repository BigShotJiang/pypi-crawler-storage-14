"""Tests for chuk-mcp-vfs"""
