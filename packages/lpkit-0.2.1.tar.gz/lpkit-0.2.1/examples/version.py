import lpkit

print(lpkit.__version__)