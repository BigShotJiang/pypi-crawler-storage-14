"""MCP JSON/YAML/TOML - MCP server for JSON, YAML, and TOML configuration files."""

from mcp_json_yaml_toml.version import __version__

__all__ = ["__version__"]
