# qstar 

blocks. so I don't waste time rewriting code each time I create a new arch.

```bash
uv add qstar 
```

