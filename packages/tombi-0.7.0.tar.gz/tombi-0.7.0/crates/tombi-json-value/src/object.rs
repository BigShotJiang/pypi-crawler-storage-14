pub type Object = crate::Map<String, crate::Value>;
