package linksocks

import "runtime"

var (
	Version  = "v1.7.2"
	Platform = runtime.GOOS + "/" + runtime.GOARCH
)
