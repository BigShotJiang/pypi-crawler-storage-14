# PDF 添加文字水印 MCP 服务

仅提供一个工具：`add_text_watermark_direct`，直接在 PDF 上叠加可选择的文字水印。

## 运行

```bash
uv run pdf-mcp-server
```

或：

```bash
$env:PYTHONPATH="src"; python -c "import pdf_mcp.server; pdf_mcp.server.main()"
```

## 工具：add_text_watermark_direct

- `input_path` (str) 输入 PDF 文件路径
- `output_path` (str) 输出 PDF 文件路径
- `watermark_text` (str) 水印文字内容
- `opacity` (float) 不透明度 (0.0-1.0)，建议 0.03-0.1 获得“若隐若现”效果
- `font_size` (int) 字体大小
- `position` (str) 位置：`center`, `top-left`, `top-right`, `bottom-left`, `bottom-right`
- `color_r`/`color_g`/`color_b` (float) 颜色分量 (0.0-1.0)
- `layout` (str) 布局：`single`、`corners`、`tile`

## 示例

```
为 report.pdf 添加可选择文字水印 "机密文件"，整页平铺
```

## 依赖

- `fastmcp`
- `pymupdf` (fitz)

## 运行

```bash
uv run pdf-mcp-server
```

## License

MIT
