# CONTRIBUTORS

## Current team members
- Leonid Burmistrov
- Mykhailo Dalchenko
- Tjark Miener
- Georgios Voutsinas

## Former team members
- Gabriel Emery
- Antonio Di Pilato
- Gregoire Uhlrich
- Vadym Voitsekhovskyi
