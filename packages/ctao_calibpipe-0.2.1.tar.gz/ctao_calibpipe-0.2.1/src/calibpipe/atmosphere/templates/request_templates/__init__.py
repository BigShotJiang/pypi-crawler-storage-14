"""Templates for DAS data requests."""
