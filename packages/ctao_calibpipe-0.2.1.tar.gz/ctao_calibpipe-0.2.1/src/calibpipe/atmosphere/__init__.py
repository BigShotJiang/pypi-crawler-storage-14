"""Sub-package containing classes responsible for the atmosphere calibration."""
