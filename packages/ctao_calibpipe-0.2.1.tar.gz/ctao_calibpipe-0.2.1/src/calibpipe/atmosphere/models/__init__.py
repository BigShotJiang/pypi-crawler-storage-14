"""Collection of reference files for atmospheric models."""
