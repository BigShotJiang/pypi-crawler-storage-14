"""Reference atmospheric models."""
