"""Mdformat plugin for MyST compatibility."""

__version__ = "0.3.0"
