# -*- coding: utf-8 -*-
"""
Subagent MCP Tools for MassGen

Provides MCP tools for spawning and managing subagents.
"""
