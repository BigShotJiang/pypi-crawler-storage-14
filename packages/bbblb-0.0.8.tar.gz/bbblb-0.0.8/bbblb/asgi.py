from bbblb.web import make_app

app = make_app()
__all__ = ["app"]
