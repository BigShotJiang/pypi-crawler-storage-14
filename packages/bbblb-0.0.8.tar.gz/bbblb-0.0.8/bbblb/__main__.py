from bbblb.cli import main

main()
