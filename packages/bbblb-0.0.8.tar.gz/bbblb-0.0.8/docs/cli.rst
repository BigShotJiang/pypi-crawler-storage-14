.. _cli:

==================
Command Line Tools
==================

.. note::

    If you followed the :doc:`docker compose based deployment <deploy>`, you can use the ``bbbctl.sh`` wrapper ro tun ``bbbctl`` inside the container.


.. click:: bbblb.cli:main
   :prog: bbblb
   :nested: full