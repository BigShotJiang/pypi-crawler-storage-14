"""Package containing implementations of different backends for NOVA-Server

Author:
    Dominik Schiller <dominik.schiller@uni-a.de>
Date:
    18.8.2023
"""