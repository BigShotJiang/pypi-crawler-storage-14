def docs() -> str:
    return """
Insere uma reunião de atendimento avulso infraestrutura no SIGA para múltiplos participantes.

INSTRUÇÃO PARA O AGENTE IA:
ANTES de executar esta função de inserção:
1. MOSTRE ao usuário TODAS as informações que serão criadas/inseridas no sistema
2. APRESENTE os dados de forma clara: área, descrição da reunião, horário (início e fim), solicitante, participantes (quantidade e matrículas), origem, categoria, equipe, projeto, plaqueta
3. PEÇA confirmação explícita do usuário: "Confirma a criação da reunião? (sim/não)"
4. SÓ EXECUTE esta função se o usuário confirmar explicitamente
5. Se o usuário não confirmar, cancele a operação e informe que foi cancelada

VALIDAÇÃO OBRIGATÓRIA ANTES DA EXECUÇÃO:
NUNCA execute esta função sem ter TODOS os dados obrigatórios coletados do usuário:
1. Matrícula do solicitante - OBRIGATÓRIO
2. Lista de participantes (matrículas) - OBRIGATÓRIO, MÍNIMO 2 PARTICIPANTES (reunião exige múltiplos participantes)
3. Data de início - OBRIGATÓRIO
4. Data de fim - OBRIGATÓRIO (reuniões avulsa sempre exigem data fim)
5. Descrição da reunião - OBRIGATÓRIO

Se o usuário NÃO informou a lista de participantes:
- PARE e PERGUNTE: "Quem são os participantes da reunião? Informe as matrículas ou nomes."
- NÃO tente executar a função sem essa informação
- NÃO assuma lista vazia ou participantes padrão
- NÃO prossiga sem coletar explicitamente do usuário

Se o usuário informou APENAS 1 participante:
- PARE e ALERTE: "Uma reunião precisa ter no mínimo 2 participantes. Para atendimento individual, use a função de inserir atendimento avulso infraestrutura."
- PERGUNTE: "Quem mais participou da reunião?"
- NÃO execute a função com apenas 1 participante

Se o usuário informou "equipe X" ou "gerente Y" mas não informou matrículas específicas:
- Use listar_usuarios_equipe_por_gerente + extrair_matriculas_do_xml ANTES de executar esta função

Esta função cria múltiplos registros de atendimento avulso infraestrutura (um para cada participante) 
vinculados a uma reunião. Cada participante é inserido individualmente com auto-commit. A função 
tenta inserir todos os participantes e retorna: lista de participantes inseridos com sucesso e 
lista de participantes que falharam (com matrícula, nome e motivo do erro).

ORIENTAÇÃO PARA SOLICITAÇÕES GENÉRICAS:
Quando o usuário solicitar "criar reunião" SEM especificar o tipo:
1. PRIMEIRO: Perguntar "A reunião é vinculada a uma OS ou é uma reunião avulsa?"
2. Se responder "OS" ou mencionar número de OS: Usar inserir_reuniao_atendimentos_os
3. Se responder "avulsa" ou "não tem OS": Perguntar "É de Sistemas ou Infraestrutura?"
   - Se "Sistemas": Usar inserir_reuniao_atendimento_avulso_sistemas
   - Se "Infraestrutura": Usar ESTA função (inserir_reuniao_atendimento_avulso_infraestrutura)
4. Só depois de definir o tipo: Coletar demais informações (data, descrição, participantes, solicitante)

Esta função é específica para Reuniões Avulso Infraestrutura (área de Infraestrutura). Para outros tipos, use:
- `inserir_reuniao_atendimentos_os` (vinculadas a OS)  
- `inserir_reuniao_atendimento_avulso_sistemas` (área de Sistemas)

ORIENTAÇÃO PARA BUSCA DE PARTICIPANTES:
Se o usuário solicitar "reunião com equipe do gerente X" ou "reunião com equipe Help-Desk":
1. PRIMEIRO chamar: listar_usuarios_equipe_por_gerente (com filtros apropriados)
2. DEPOIS chamar: extrair_matriculas_do_xml (para obter lista de matrículas)
3. FINALMENTE chamar: esta função com a lista de participantes obtida

Args:
    data_inicio: Data e hora de início da reunião. Aceita formatos de data ou palavras-chave como "hoje", "agora", "ontem". Convertido automaticamente.
    data_fim: Data e hora de fim da reunião. Aceita formatos de data ou palavras-chave. Obrigatório para reuniões avulsa.
    matricula_solicitante: Matrícula de quem criou/solicitou a reunião (fixo para todos os registros). Aceita "CURRENT_USER" para usar o usuário logado ou número de matrícula. Não pode estar vazio ou ser zero.
    descricao_reuniao: Descrição detalhada da reunião/pauta
    participantes: Lista de matrículas dos participantes da reunião (ex: ["24142", "20634", "12345"]). OBRIGATÓRIO ter no MÍNIMO 2 PARTICIPANTES (reuniões exigem múltiplos participantes). Para atendimento individual, use inserir_atendimento_avulso_infraestrutura.
    origem: Canal/origem do atendimento. Deve ser um dos valores válidos em OrigemAtendimentoAvulsoSistemasType. Defaults to "E-mail".
    categoria: Categoria do atendimento. Deve ser uma das categorias válidas em CategoriasInfraestruturaType. Defaults to "AD - Suporte/Dúvidas/Outros".
    equipe: Equipe responsável. Deve ser uma das equipes válidas em EquipeInfraestruturaType. Defaults to "Help-Desk - Aeroporto".
    projeto: Projeto relacionado. Deve ser um dos valores válidos em ProjetoType. Defaults to "Operação Help Desk".
    plaqueta: Plaqueta do equipamento relacionado ao atendimento. Campo opcional, pode ser None ou string. Defaults to None.

Returns:
    XML formatado contendo status da operação, tipo (reuniao_avulso_infraestrutura), área (Infraestrutura), solicitante, total de participantes inseridos, lista de participantes inseridos com sucesso (matrícula, nome e status), lista de erros (matrícula, nome e motivo do erro) para participantes que falharam, mensagem descritiva e metadados da reunião (origem, categoria, equipe, projeto, plaqueta).

Notes:
    - ÁREA FIXA: Esta função cria atendimentos para ÁREA INFRAESTRUTURA (área=2) exclusivamente
    - MÚLTIPLOS REGISTROS: Cria um registro de atendimento avulso para cada participante na lista
    - MÍNIMO 2 PARTICIPANTES: Reuniões exigem pelo menos 2 participantes. Para atendimento individual, use inserir_atendimento_avulso_infraestrutura
    - AUTO-COMMIT INDIVIDUAL: Cada participante é inserido com auto-commit independente usando trocarConexao()
    - INSERÇÃO INDEPENDENTE: Falha de um participante não afeta inserção dos demais
    - SUCESSO PARCIAL: Insere todos os participantes possíveis. Retorna lista de sucessos E lista de erros (com motivo) separadamente
    - FALHA TOTAL: Operação só falha se NENHUM participante puder ser inserido
    - BUSCA DE NOMES: Backend busca nomes de todos os participantes em uma única query antes da inserção
    - VALIDAÇÃO OBRIGATÓRIA: matricula_solicitante não pode estar vazio ou ser zero, lista de participantes deve ter no mínimo 2 matrículas
    - SOLICITANTE vs PARTICIPANTES: O solicitante é quem criou a reunião (fixo para todos). Os participantes são os analistas que participaram (variável)
    - ESTRUTURA DE DADOS: Cada registro tem: Solicitante=matricula_solicitante (fixo), Analista=participante (variável)
    - PLAQUETA OPCIONAL: Campo plaqueta pode ser None ou string vazia. Se None, será enviado como string vazia para a API
    - NOMES INCLUÍDOS: Participantes inseridos e erros incluem matrícula e nome completo do colaborador
    - FORMATAÇÃO: Participantes e erros formatados com bullets (•) para melhor legibilidade na resposta
    - CONVERSÃO DE DATAS: Datas são automaticamente convertidas usando converter_data_siga com manter_horas=True
    - NORMALIZAÇÃO: Função realiza validação case-insensitive de origem, categoria, equipe e projeto usando constantes de mapeamento
    - CONSTANTES UTILIZADAS: ORIGEM_TO_NUMBER, CATEGORIA_TO_NUMBER, EQUIPE_INFRAESTRUTURA_TO_NUMBER, PROJETO_TO_NUMBER
    - API KEY: Obtida automaticamente da variável de ambiente AVA_API_KEY
    - TIMEOUT: Requisição HTTP tem timeout de 60 segundos
    - ERRO HTTP: Em caso de falha na requisição, retorna erro interno formatado em XML
    - Esta função é diferente de inserir_atendimento_avulso_infraestrutura que cria atendimento único para um analista
    - Integra-se com listar_usuarios_equipe_por_gerente e extrair_matriculas_do_xml para busca de participantes

"""
