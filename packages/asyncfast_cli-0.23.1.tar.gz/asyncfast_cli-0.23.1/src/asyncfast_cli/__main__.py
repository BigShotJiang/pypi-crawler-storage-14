from asyncfast_cli.cli import main

main()
