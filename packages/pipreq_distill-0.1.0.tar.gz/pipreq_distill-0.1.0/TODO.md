# TODO: pipreq-distill Implementation

## Phase 1: Project Setup

- [ ] Create pyproject.toml with uv init
- [ ] Configure project metadata (name, version, description, authors)
- [ ] Add main dependencies (fire, httpx, packaging, tenacity, loguru, rich, tomlkit)
- [ ] Add dev dependencies (pytest, pytest-asyncio, pytest-cov, ruff, mypy)
- [ ] Create src/pipreq_distill/ directory structure
- [ ] Create src/pipreq_distill/__init__.py with version and exports
- [ ] Configure ruff in pyproject.toml
- [ ] Configure mypy in pyproject.toml
- [ ] Configure pytest in pyproject.toml
- [ ] Add console script entry point for pipreq-distill CLI

## Phase 2: Core Data Models

- [ ] Create src/pipreq_distill/models.py
- [ ] Implement PackageInfo dataclass with name, version, release_date, requires_dist
- [ ] Add canonical_name property to PackageInfo
- [ ] Implement ResolvedResult dataclass with kept and removed lists
- [ ] Add kept_requirements property to ResolvedResult
- [ ] Add type hints to all model fields and methods

## Phase 3: PyPI Client

- [ ] Create src/pipreq_distill/pypi.py
- [ ] Port PyPIClient class from pipunreq
- [ ] Update cache directory to pipreq_distill_cache
- [ ] Replace print statements with loguru logging
- [ ] Add complete type hints to all methods
- [ ] Implement _get_client with lazy initialization
- [ ] Implement _get_cache_path for disk caching
- [ ] Implement _load_from_disk_cache with TTL check
- [ ] Implement _save_to_disk_cache
- [ ] Implement _fetch_url with retry decorator
- [ ] Implement _extract_metadata_from_wheel
- [ ] Implement _extract_metadata_from_sdist
- [ ] Implement get_package_info for single package fetch
- [ ] Implement get_packages_parallel for concurrent fetching
- [ ] Implement close method for cleanup

## Phase 4: Parsers

- [ ] Create src/pipreq_distill/parsers/__init__.py
- [ ] Create src/pipreq_distill/parsers/base.py with BaseParser ABC
- [ ] Define parse abstract method in BaseParser
- [ ] Define parse_file abstract method in BaseParser
- [ ] Define can_handle classmethod in BaseParser
- [ ] Create src/pipreq_distill/parsers/requirements.py
- [ ] Implement RequirementsParser.parse for parsing requirement strings
- [ ] Handle comments and empty lines in RequirementsParser
- [ ] Handle -r and -e lines gracefully in RequirementsParser
- [ ] Implement RequirementsParser.parse_file
- [ ] Implement RequirementsParser.can_handle
- [ ] Create src/pipreq_distill/parsers/pyproject.py
- [ ] Implement PyprojectParser with dependency_group parameter
- [ ] Implement parsing PEP 621 project.dependencies
- [ ] Implement parsing project.optional-dependencies groups
- [ ] Implement parsing tool.uv.dev-dependencies
- [ ] Implement parsing tool.poetry.group dependencies
- [ ] Implement PyprojectParser.parse_file
- [ ] Implement PyprojectParser.can_handle
- [ ] Export parsers from __init__.py

## Phase 5: Writers

- [ ] Create src/pipreq_distill/writers/__init__.py
- [ ] Create src/pipreq_distill/writers/base.py with BaseWriter ABC
- [ ] Define write abstract method in BaseWriter
- [ ] Define write_file abstract method in BaseWriter
- [ ] Create src/pipreq_distill/writers/requirements.py
- [ ] Implement RequirementsWriter.write to generate requirements string
- [ ] Implement RequirementsWriter.write_file
- [ ] Create src/pipreq_distill/writers/pyproject.py
- [ ] Implement PyprojectWriter with dependency_group parameter
- [ ] Implement PyprojectWriter.write for snippet generation
- [ ] Implement PyprojectWriter.update_file using tomlkit
- [ ] Handle creating new pyproject.toml structure
- [ ] Handle updating existing pyproject.toml preserving formatting
- [ ] Export writers from __init__.py

## Phase 6: Core Resolver

- [ ] Create src/pipreq_distill/core.py
- [ ] Port DependencyResolver class from pipunreq
- [ ] Update constructor to use new PyPIClient
- [ ] Replace print statements with loguru logging
- [ ] Add complete type hints to all methods
- [ ] Implement _build_dependency_map using parallel fetching
- [ ] Implement _build_dependency_graph for forward and reverse deps
- [ ] Implement _find_conflicts to detect version conflicts
- [ ] Implement _score_packages for removal prioritization
- [ ] Implement _find_conflict_clusters for batch analysis
- [ ] Implement resolve method returning ResolvedResult
- [ ] Ensure proper async/await throughout

## Phase 7: CLI Implementation

- [ ] Create src/pipreq_distill/cli.py
- [ ] Import Fire, loguru, rich, and all internal modules
- [ ] Implement distill function with all CLI parameters
- [ ] Add --input parameter for input file path
- [ ] Add --output parameter for output file path
- [ ] Add --format parameter (auto, requirements, pyproject)
- [ ] Add --group parameter for pyproject.toml dependency groups
- [ ] Add --keep parameter for protected packages
- [ ] Add --dry-run parameter
- [ ] Add --json-output parameter
- [ ] Add --verbose parameter
- [ ] Add --timeout parameter
- [ ] Add --max-concurrent parameter
- [ ] Implement auto-detection of file format
- [ ] Implement stdin reading when no input file
- [ ] Implement stdout writing when no output file
- [ ] Implement _print_dry_run with rich table output
- [ ] Implement _print_json for JSON output
- [ ] Implement main entry point with fire.Fire
- [ ] Add comprehensive docstrings for Fire help

## Phase 8: Error Handling

- [ ] Create src/pipreq_distill/exceptions.py
- [ ] Define PipreqDistillError base exception
- [ ] Define ParseError exception
- [ ] Define PyPIError exception
- [ ] Define ResolutionError exception
- [ ] Add exception handling in parsers
- [ ] Add exception handling in PyPI client
- [ ] Add exception handling in resolver
- [ ] Add user-friendly error messages in CLI

## Phase 9: Testing Setup

- [ ] Create tests/ directory
- [ ] Create tests/__init__.py
- [ ] Create tests/conftest.py with shared fixtures
- [ ] Add PackageInfo fixture for testing
- [ ] Add mock PyPI responses fixture
- [ ] Add sample requirements.txt fixture
- [ ] Add sample pyproject.toml fixture

## Phase 10: Model Tests

- [ ] Create tests/test_models.py
- [ ] Test PackageInfo dataclass creation
- [ ] Test PackageInfo.canonical_name property
- [ ] Test ResolvedResult dataclass creation
- [ ] Test ResolvedResult.kept_requirements property

## Phase 11: Parser Tests

- [ ] Create tests/test_parsers.py
- [ ] Test RequirementsParser.parse with basic requirements
- [ ] Test RequirementsParser.parse with comments
- [ ] Test RequirementsParser.parse with empty lines
- [ ] Test RequirementsParser.parse with version specifiers
- [ ] Test RequirementsParser.parse with invalid lines
- [ ] Test RequirementsParser.parse_file
- [ ] Test RequirementsParser.can_handle
- [ ] Test PyprojectParser.parse with PEP 621 dependencies
- [ ] Test PyprojectParser.parse with optional dependencies
- [ ] Test PyprojectParser.parse with uv dev dependencies
- [ ] Test PyprojectParser.parse with empty dependencies
- [ ] Test PyprojectParser.parse_file
- [ ] Test PyprojectParser.can_handle

## Phase 12: Writer Tests

- [ ] Create tests/test_writers.py
- [ ] Test RequirementsWriter.write output format
- [ ] Test RequirementsWriter.write_file creates correct file
- [ ] Test PyprojectWriter.write output format
- [ ] Test PyprojectWriter.update_file preserves formatting
- [ ] Test PyprojectWriter.update_file creates missing sections

## Phase 13: PyPI Client Tests

- [ ] Create tests/test_pypi.py
- [ ] Test PyPIClient initialization
- [ ] Test cache directory creation
- [ ] Test disk cache loading and saving
- [ ] Test cache TTL expiration
- [ ] Test get_package_info with mocked responses
- [ ] Test get_packages_parallel concurrency
- [ ] Test retry logic on transient errors
- [ ] Test metadata extraction from wheel
- [ ] Test metadata extraction from sdist

## Phase 14: Core Resolver Tests

- [ ] Create tests/test_core.py
- [ ] Test DependencyResolver initialization
- [ ] Test _build_dependency_map with mocked PyPI
- [ ] Test _build_dependency_graph structure
- [ ] Test _find_conflicts detects version conflicts
- [ ] Test _find_conflicts with no conflicts
- [ ] Test _score_packages scoring logic
- [ ] Test resolve removes conflicting packages
- [ ] Test resolve respects keep list
- [ ] Test resolve handles empty requirements
- [ ] Test resolve handles all packages protected

## Phase 15: CLI Tests

- [ ] Create tests/test_cli.py
- [ ] Test distill with requirements.txt input
- [ ] Test distill with pyproject.toml input
- [ ] Test distill with stdin input
- [ ] Test distill with stdout output
- [ ] Test distill with file output
- [ ] Test distill --dry-run flag
- [ ] Test distill --json-output flag
- [ ] Test distill --keep flag
- [ ] Test distill --verbose flag
- [ ] Test distill --format auto detection

## Phase 16: Integration Tests

- [ ] Create tests/test_integration.py
- [ ] Test full workflow requirements.txt to requirements.txt
- [ ] Test full workflow pyproject.toml to pyproject.toml
- [ ] Test conflict resolution with real package scenarios
- [ ] Test error handling for missing files
- [ ] Test error handling for invalid input

## Phase 17: Documentation

- [ ] Create README.md with project description
- [ ] Add installation instructions to README.md
- [ ] Add usage examples to README.md
- [ ] Document CLI options in README.md
- [ ] Add examples for requirements.txt workflow
- [ ] Add examples for pyproject.toml workflow
- [ ] Document the scoring algorithm
- [ ] Add troubleshooting section
- [ ] Create CHANGELOG.md
- [ ] Add initial release notes to CHANGELOG.md

## Phase 18: Quality Assurance

- [ ] Run ruff check and fix all issues
- [ ] Run ruff format on all files
- [ ] Run mypy and fix all type errors
- [ ] Run pytest and ensure all tests pass
- [ ] Achieve >80% code coverage
- [ ] Test CLI manually with real requirements
- [ ] Test edge cases (empty input, huge input, network errors)

## Phase 19: Final Polish

- [ ] Review all docstrings for completeness
- [ ] Review all error messages for clarity
- [ ] Verify package can be installed with uv pip install -e .
- [ ] Verify CLI entry point works after install
- [ ] Clean up any debug code or comments
- [ ] Final review of PLAN.md and TODO.md
