"""Tests for PyPI client."""

import tempfile
from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from pipreq_distill.models import PackageInfo
from pipreq_distill.pypi import PyPIClient


class TestPyPIClient:
    def test_init_default(self) -> None:
        client = PyPIClient()
        assert client.timeout == 30.0
        assert client.use_cache is True
        assert client.verbose is False

    def test_init_custom(self) -> None:
        client = PyPIClient(timeout=60.0, use_cache=False, verbose=True)
        assert client.timeout == 60.0
        assert client.use_cache is False
        assert client.verbose is True

    def test_cache_dir_creation(self) -> None:
        client = PyPIClient(use_cache=True)
        assert client.CACHE_DIR.exists()

    def test_get_cache_path(self) -> None:
        client = PyPIClient()
        path = client._get_cache_path("test:1.0.0")
        assert path.parent == client.CACHE_DIR
        assert path.suffix == ".json"

    def test_save_and_load_disk_cache(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            client = PyPIClient()
            client.CACHE_DIR = Path(tmpdir)

            data = {"info": {"name": "test", "version": "1.0.0"}}
            client._save_to_disk_cache("test:1.0.0", data)

            loaded = client._load_from_disk_cache("test:1.0.0")
            assert loaded == data

    def test_load_disk_cache_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            client = PyPIClient()
            client.CACHE_DIR = Path(tmpdir)

            loaded = client._load_from_disk_cache("nonexistent:1.0.0")
            assert loaded is None

    def test_load_disk_cache_disabled(self) -> None:
        client = PyPIClient(use_cache=False)
        loaded = client._load_from_disk_cache("test:1.0.0")
        assert loaded is None


class TestPyPIClientAsync:
    @pytest.mark.asyncio
    async def test_get_package_info_basic(self) -> None:
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "info": {"name": "requests", "version": "2.31.0"},
            "urls": [
                {
                    "packagetype": "bdist_wheel",
                    "upload_time_iso_8601": "2024-01-01T00:00:00Z",
                    "url": "https://example.com/requests.whl",
                }
            ],
        }

        with patch.object(PyPIClient, "_fetch_url", return_value=mock_response):
            client = PyPIClient(use_cache=False)
            info = await client.get_package_info("requests", "2.31.0")

            assert info is not None
            assert info.name == "requests"
            assert info.version == "2.31.0"

    @pytest.mark.asyncio
    async def test_get_package_info_not_found(self) -> None:
        with patch.object(
            PyPIClient, "_fetch_url", side_effect=Exception("Not found")
        ):
            client = PyPIClient(use_cache=False)
            info = await client.get_package_info("nonexistent-pkg", "1.0.0")
            assert info is None

    @pytest.mark.asyncio
    async def test_get_packages_parallel(self) -> None:
        now = datetime.now(UTC)

        async def mock_get_info(self, name, version=None):
            if name.lower() == "requests":
                return PackageInfo("requests", "2.31.0", now, [])
            elif name.lower() == "flask":
                return PackageInfo("Flask", "3.0.0", now, [])
            return None

        with patch.object(PyPIClient, "get_package_info", mock_get_info):
            client = PyPIClient(use_cache=False)
            results = await client.get_packages_parallel([
                ("requests", None),
                ("flask", None),
            ])

            assert len(results) == 2
            assert "requests" in results
            assert "flask" in results

    @pytest.mark.asyncio
    async def test_close(self) -> None:
        client = PyPIClient()
        # Create the client
        await client._get_client()
        assert client._client is not None

        # Close it
        await client.close()
        assert client._client is None
