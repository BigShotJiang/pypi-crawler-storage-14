"""Tests for data models."""

from datetime import UTC, datetime

from pipreq_distill.models import PackageInfo, ResolvedResult


class TestPackageInfo:
    def test_create_basic(self) -> None:
        info = PackageInfo(
            name="test-pkg",
            version="1.0.0",
            release_date=datetime(2024, 1, 1, tzinfo=UTC),
            requires_dist=["dep>=1.0"],
        )
        assert info.name == "test-pkg"
        assert info.version == "1.0.0"
        assert info.requires_dist == ["dep>=1.0"]

    def test_canonical_name_lowercase(self) -> None:
        info = PackageInfo(
            name="Test-Pkg",
            version="1.0.0",
            release_date=datetime(2024, 1, 1, tzinfo=UTC),
        )
        assert info.canonical_name == "test_pkg"

    def test_canonical_name_replaces_dashes(self) -> None:
        info = PackageInfo(
            name="my-test-package",
            version="1.0.0",
            release_date=datetime(2024, 1, 1, tzinfo=UTC),
        )
        assert info.canonical_name == "my_test_package"

    def test_canonical_name_replaces_dots(self) -> None:
        info = PackageInfo(
            name="zope.interface",
            version="1.0.0",
            release_date=datetime(2024, 1, 1, tzinfo=UTC),
        )
        assert info.canonical_name == "zope_interface"

    def test_default_requires_dist(self) -> None:
        info = PackageInfo(
            name="test",
            version="1.0.0",
            release_date=datetime(2024, 1, 1, tzinfo=UTC),
        )
        assert info.requires_dist == []


class TestResolvedResult:
    def test_kept_requirements_empty(self) -> None:
        result = ResolvedResult(kept=[], removed=[])
        assert result.kept_requirements == []

    def test_kept_requirements_sorted(self) -> None:
        now = datetime.now(UTC)
        result = ResolvedResult(
            kept=[
                PackageInfo("zlib", "1.0.0", now),
                PackageInfo("abc", "2.0.0", now),
                PackageInfo("middle", "3.0.0", now),
            ],
            removed=[],
        )
        assert result.kept_requirements == [
            "abc==2.0.0",
            "middle==3.0.0",
            "zlib==1.0.0",
        ]

    def test_removed_count(self) -> None:
        now = datetime.now(UTC)
        pkg = PackageInfo("test", "1.0.0", now)
        result = ResolvedResult(kept=[], removed=[(pkg, 100.0), (pkg, 200.0)])
        assert result.removed_count == 2

    def test_kept_count(self) -> None:
        now = datetime.now(UTC)
        result = ResolvedResult(
            kept=[
                PackageInfo("a", "1.0.0", now),
                PackageInfo("b", "1.0.0", now),
            ],
            removed=[],
        )
        assert result.kept_count == 2
