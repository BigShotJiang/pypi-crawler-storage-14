"""Tests for CLI."""

import json
from datetime import UTC, datetime
from unittest.mock import AsyncMock, patch

import pytest

from pipreq_distill.cli import _print_dry_run, _print_json, distill
from pipreq_distill.models import PackageInfo, ResolvedResult


@pytest.fixture
def sample_result() -> ResolvedResult:
    now = datetime.now(UTC)
    return ResolvedResult(
        kept=[
            PackageInfo("requests", "2.31.0", now),
            PackageInfo("flask", "2.3.0", now),
        ],
        removed=[(PackageInfo("old-pkg", "1.0.0", now), 150.5)],
    )


class TestPrintDryRun:
    def test_prints_removed_packages(self, sample_result: ResolvedResult) -> None:
        # Just verify it doesn't raise
        _print_dry_run(sample_result)

    def test_prints_no_removal(self) -> None:
        result = ResolvedResult(kept=[], removed=[])
        _print_dry_run(result)


class TestPrintJson:
    def test_outputs_valid_json(
        self, sample_result: ResolvedResult, capsys
    ) -> None:
        _print_json(sample_result)
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert "kept" in data
        assert "removed" in data
        assert data["kept_count"] == 2
        assert data["removed_count"] == 1

    def test_json_structure(self, sample_result: ResolvedResult, capsys) -> None:
        _print_json(sample_result)
        captured = capsys.readouterr()
        data = json.loads(captured.out)

        assert data["removed"][0]["name"] == "old-pkg"
        assert data["removed"][0]["version"] == "1.0.0"
        assert data["removed"][0]["score"] == 150.5


class TestDistill:
    def test_distill_with_file_input(self, tmp_path) -> None:
        req_file = tmp_path / "requirements.txt"
        req_file.write_text("requests>=2.0\nflask>=2.0\n")
        output_file = tmp_path / "resolved.txt"

        now = datetime.now(UTC)
        mock_result = ResolvedResult(
            kept=[
                PackageInfo("requests", "2.31.0", now),
                PackageInfo("flask", "2.3.0", now),
            ],
            removed=[],
        )

        async def mock_resolve(*args):
            return mock_result

        with patch("pipreq_distill.core.DependencyResolver.resolve", mock_resolve):
            with patch("pipreq_distill.core.PyPIClient.close", new_callable=AsyncMock):
                distill(
                    input=str(req_file),
                    output=str(output_file),
                )

        assert output_file.exists()
        content = output_file.read_text()
        assert "flask==2.3.0" in content
        assert "requests==2.31.0" in content

    def test_distill_dry_run_no_output(self, tmp_path) -> None:
        req_file = tmp_path / "requirements.txt"
        req_file.write_text("requests>=2.0\n")
        output_file = tmp_path / "resolved.txt"

        now = datetime.now(UTC)
        mock_result = ResolvedResult(
            kept=[PackageInfo("requests", "2.31.0", now)],
            removed=[],
        )

        async def mock_resolve(*args):
            return mock_result

        with patch("pipreq_distill.core.DependencyResolver.resolve", mock_resolve):
            with patch("pipreq_distill.core.PyPIClient.close", new_callable=AsyncMock):
                distill(
                    input=str(req_file),
                    output=str(output_file),
                    dry_run=True,
                )

        # Dry run should not create output file
        assert not output_file.exists()

    def test_distill_json_output(self, tmp_path, capsys) -> None:
        req_file = tmp_path / "requirements.txt"
        req_file.write_text("requests>=2.0\n")

        now = datetime.now(UTC)
        mock_result = ResolvedResult(
            kept=[PackageInfo("requests", "2.31.0", now)],
            removed=[],
        )

        async def mock_resolve(*args):
            return mock_result

        with patch("pipreq_distill.core.DependencyResolver.resolve", mock_resolve):
            with patch("pipreq_distill.core.PyPIClient.close", new_callable=AsyncMock):
                distill(
                    input=str(req_file),
                    json_output=True,
                )

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["kept_count"] == 1

    def test_distill_pyproject_format(self, tmp_path) -> None:
        pyproject_file = tmp_path / "pyproject.toml"
        pyproject_file.write_text('''
[project]
name = "test"
dependencies = ["requests>=2.0"]
''')
        output_file = tmp_path / "output.toml"

        now = datetime.now(UTC)
        mock_result = ResolvedResult(
            kept=[PackageInfo("requests", "2.31.0", now)],
            removed=[],
        )

        async def mock_resolve(*args):
            return mock_result

        with patch("pipreq_distill.core.DependencyResolver.resolve", mock_resolve):
            with patch("pipreq_distill.core.PyPIClient.close", new_callable=AsyncMock):
                distill(
                    input=str(pyproject_file),
                    output=str(output_file),
                    format="pyproject",
                )

        assert output_file.exists()

    def test_distill_keep_packages(self, tmp_path) -> None:
        req_file = tmp_path / "requirements.txt"
        req_file.write_text("requests>=2.0\nflask>=2.0\n")

        now = datetime.now(UTC)
        mock_result = ResolvedResult(
            kept=[PackageInfo("requests", "2.31.0", now)],
            removed=[],
        )

        async def mock_resolve(*args):
            return mock_result

        with patch(
            "pipreq_distill.cli.DependencyResolver"
        ) as mock_resolver_class:
            mock_resolver = mock_resolver_class.return_value
            mock_resolver.resolve = mock_resolve

            distill(
                input=str(req_file),
                keep="requests,flask",
                dry_run=True,
            )

            # Verify keep was passed
            mock_resolver_class.assert_called_once()
            call_kwargs = mock_resolver_class.call_args[1]
            assert "requests" in call_kwargs["keep"]
            assert "flask" in call_kwargs["keep"]
