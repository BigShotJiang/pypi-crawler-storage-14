"""Shared test fixtures."""

from datetime import UTC, datetime

import pytest

from pipreq_distill.models import PackageInfo


@pytest.fixture
def now() -> datetime:
    """Current datetime with timezone."""
    return datetime.now(UTC)


@pytest.fixture
def old_date() -> datetime:
    """Old datetime for testing age scoring."""
    return datetime(2020, 1, 1, tzinfo=UTC)


@pytest.fixture
def new_date() -> datetime:
    """Recent datetime for testing age scoring."""
    return datetime(2024, 6, 1, tzinfo=UTC)


@pytest.fixture
def sample_package_info(now: datetime) -> PackageInfo:
    """Sample PackageInfo for testing."""
    return PackageInfo(
        name="test-pkg",
        version="1.0.0",
        release_date=now,
        requires_dist=["dep>=1.0"],
    )


@pytest.fixture
def sample_requirements_txt() -> str:
    """Sample requirements.txt content."""
    return """\
# Comment line
requests>=2.28.0
flask==2.3.0

# Another comment
httpx>=0.24.0
"""


@pytest.fixture
def sample_pyproject_toml() -> str:
    """Sample pyproject.toml content."""
    return """\
[project]
name = "sample"
version = "0.1.0"
dependencies = [
    "requests>=2.28.0",
    "flask==2.3.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "ruff>=0.4.0",
]
"""
