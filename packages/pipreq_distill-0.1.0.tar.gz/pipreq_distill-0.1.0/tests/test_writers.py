"""Tests for writers."""

from datetime import UTC, datetime

import pytest

from pipreq_distill.models import PackageInfo, ResolvedResult
from pipreq_distill.writers import PyprojectWriter, RequirementsWriter


@pytest.fixture
def sample_result() -> ResolvedResult:
    now = datetime.now(UTC)
    return ResolvedResult(
        kept=[
            PackageInfo("requests", "2.31.0", now),
            PackageInfo("flask", "2.3.0", now),
        ],
        removed=[],
    )


class TestRequirementsWriter:
    def test_write_basic(self, sample_result: ResolvedResult) -> None:
        writer = RequirementsWriter()
        output = writer.write(sample_result)
        assert "flask==2.3.0" in output
        assert "requests==2.31.0" in output

    def test_write_sorted(self, sample_result: ResolvedResult) -> None:
        writer = RequirementsWriter()
        output = writer.write(sample_result)
        lines = output.strip().split("\n")
        assert lines[0] == "flask==2.3.0"
        assert lines[1] == "requests==2.31.0"

    def test_write_empty(self) -> None:
        writer = RequirementsWriter()
        result = ResolvedResult(kept=[], removed=[])
        output = writer.write(result)
        assert output == ""

    def test_write_ends_with_newline(self, sample_result: ResolvedResult) -> None:
        writer = RequirementsWriter()
        output = writer.write(sample_result)
        assert output.endswith("\n")

    def test_write_file(self, sample_result: ResolvedResult, tmp_path) -> None:
        writer = RequirementsWriter()
        path = tmp_path / "requirements.txt"
        writer.write_file(sample_result, path)
        assert path.exists()
        content = path.read_text()
        assert "flask==2.3.0" in content


class TestPyprojectWriter:
    def test_write_dependencies(self, sample_result: ResolvedResult) -> None:
        writer = PyprojectWriter()
        output = writer.write(sample_result)
        assert "[project]" in output
        assert "dependencies" in output
        assert "flask==2.3.0" in output
        assert "requests==2.31.0" in output

    def test_write_optional_dependencies(self, sample_result: ResolvedResult) -> None:
        writer = PyprojectWriter("optional.dev")
        output = writer.write(sample_result)
        # tomlkit outputs as [project.optional-dependencies] which is valid TOML
        assert "optional-dependencies" in output
        assert "flask==2.3.0" in output

    def test_update_file_preserves_other_content(
        self, sample_result: ResolvedResult, tmp_path
    ) -> None:
        path = tmp_path / "pyproject.toml"
        path.write_text('''
[project]
name = "test"
version = "0.1.0"
dependencies = ["old-dep"]

[tool.ruff]
line-length = 100
''')
        writer = PyprojectWriter()
        writer.update_file(sample_result, path)

        content = path.read_text()
        assert "name = \"test\"" in content
        assert "[tool.ruff]" in content
        assert "line-length = 100" in content
        assert "flask==2.3.0" in content
        assert "old-dep" not in content

    def test_update_file_creates_project_section(
        self, sample_result: ResolvedResult, tmp_path
    ) -> None:
        path = tmp_path / "pyproject.toml"
        path.write_text('''
[tool.ruff]
line-length = 100
''')
        writer = PyprojectWriter()
        writer.update_file(sample_result, path)

        content = path.read_text()
        assert "[project]" in content
        assert "dependencies" in content
