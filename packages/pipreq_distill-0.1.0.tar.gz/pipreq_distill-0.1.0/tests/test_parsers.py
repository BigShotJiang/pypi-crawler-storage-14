"""Tests for parsers."""


from pipreq_distill.parsers import PyprojectParser, RequirementsParser


class TestRequirementsParser:
    def test_parse_basic(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("requests>=2.0\nflask==2.0.0")
        assert len(reqs) == 2
        assert reqs[0].name == "requests"
        assert reqs[1].name == "flask"

    def test_parse_with_comments(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("# Comment\nrequests>=2.0\n\n# Another\nflask==2.0.0")
        assert len(reqs) == 2

    def test_parse_empty_lines(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("\n\nrequests>=2.0\n\n\nflask==2.0.0\n\n")
        assert len(reqs) == 2

    def test_parse_with_pip_options(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("-r other.txt\n-e .\nrequests>=2.0\n--index-url https://...")
        assert len(reqs) == 1
        assert reqs[0].name == "requests"

    def test_parse_empty(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("\n\n# Only comments\n")
        assert len(reqs) == 0

    def test_parse_invalid_lines_skipped(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("valid-pkg>=1.0\nnot a valid!!!\nanother==2.0")
        assert len(reqs) == 2

    def test_parse_version_specifiers(self) -> None:
        parser = RequirementsParser()
        reqs = parser.parse("pkg1>=1.0,<2.0\npkg2~=1.4.0\npkg3!=1.5.0")
        assert len(reqs) == 3

    def test_can_handle_txt_suffix(self, tmp_path) -> None:
        path = tmp_path / "deps.txt"
        assert RequirementsParser.can_handle(path)

    def test_can_handle_requirements_name(self, tmp_path) -> None:
        path = tmp_path / "requirements.txt"
        assert RequirementsParser.can_handle(path)

    def test_can_handle_dev_requirements(self, tmp_path) -> None:
        path = tmp_path / "requirements-dev.txt"
        assert RequirementsParser.can_handle(path)

    def test_cannot_handle_pyproject(self, tmp_path) -> None:
        path = tmp_path / "pyproject.toml"
        assert not RequirementsParser.can_handle(path)


class TestPyprojectParser:
    def test_parse_pep621_dependencies(self) -> None:
        parser = PyprojectParser()
        content = '''
[project]
dependencies = ["requests>=2.0", "flask"]
'''
        reqs = parser.parse(content)
        assert len(reqs) == 2
        assert reqs[0].name == "requests"
        assert reqs[1].name == "flask"

    def test_parse_optional_dependencies(self) -> None:
        parser = PyprojectParser("optional.dev")
        content = '''
[project.optional-dependencies]
dev = ["pytest", "ruff"]
'''
        reqs = parser.parse(content)
        assert len(reqs) == 2
        assert reqs[0].name == "pytest"
        assert reqs[1].name == "ruff"

    def test_parse_uv_dev_dependencies(self) -> None:
        parser = PyprojectParser("dev")
        content = '''
[tool.uv]
dev-dependencies = ["pytest>=8.0", "ruff"]
'''
        reqs = parser.parse(content)
        assert len(reqs) == 2

    def test_parse_empty_dependencies(self) -> None:
        parser = PyprojectParser()
        content = '''
[project]
name = "test"
'''
        reqs = parser.parse(content)
        assert len(reqs) == 0

    def test_parse_missing_project(self) -> None:
        parser = PyprojectParser()
        content = '''
[tool.black]
line-length = 88
'''
        reqs = parser.parse(content)
        assert len(reqs) == 0

    def test_can_handle_pyproject(self, tmp_path) -> None:
        path = tmp_path / "pyproject.toml"
        assert PyprojectParser.can_handle(path)

    def test_cannot_handle_requirements(self, tmp_path) -> None:
        path = tmp_path / "requirements.txt"
        assert not PyprojectParser.can_handle(path)
