"""Tests for pipreq-distill."""
