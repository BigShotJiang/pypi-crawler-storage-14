"""Tests for core dependency resolver."""

from datetime import UTC, datetime
from unittest.mock import AsyncMock, patch

import pytest
from packaging.requirements import Requirement

from pipreq_distill.core import DependencyResolver
from pipreq_distill.models import PackageInfo


@pytest.fixture
def now() -> datetime:
    return datetime.now(UTC)


@pytest.fixture
def old_date() -> datetime:
    return datetime(2020, 1, 1, tzinfo=UTC)


class TestDependencyResolver:
    def test_init_default(self) -> None:
        resolver = DependencyResolver()
        assert resolver.keep == set()
        assert resolver.verbose is False

    def test_init_with_keep(self) -> None:
        resolver = DependencyResolver(keep=["requests", "Flask"])
        assert resolver.keep == {"requests", "flask"}

    def test_find_conflicts_no_conflicts(self, now: datetime) -> None:
        resolver = DependencyResolver()
        pkg_map = {
            "pkg-a": PackageInfo("pkg-a", "1.0.0", now, ["pkg-b>=1.0"]),
            "pkg-b": PackageInfo("pkg-b", "2.0.0", now, []),
        }
        conflicts = resolver._find_conflicts(pkg_map)
        assert len(conflicts) == 0

    def test_find_conflicts_with_conflict(self, now: datetime) -> None:
        resolver = DependencyResolver()
        pkg_map = {
            "pkg-a": PackageInfo("pkg-a", "1.0.0", now, ["pkg-b<1.0"]),
            "pkg-b": PackageInfo("pkg-b", "2.0.0", now, []),
        }
        conflicts = resolver._find_conflicts(pkg_map)
        assert len(conflicts) == 1
        assert conflicts[0][0] == "pkg-a"
        assert conflicts[0][1] == "pkg-b"

    def test_find_conflicts_skips_conditional(self, now: datetime) -> None:
        resolver = DependencyResolver()
        pkg_map = {
            "pkg-a": PackageInfo(
                "pkg-a", "1.0.0", now, ['pkg-b<1.0 ; python_version < "3.8"']
            ),
            "pkg-b": PackageInfo("pkg-b", "2.0.0", now, []),
        }
        # Conditional part is stripped, conflict still detected
        conflicts = resolver._find_conflicts(pkg_map)
        assert len(conflicts) == 1

    def test_build_dependency_graph(self, now: datetime) -> None:
        resolver = DependencyResolver()
        pkg_map = {
            "pkg-a": PackageInfo("pkg-a", "1.0.0", now, ["pkg-b>=1.0"]),
            "pkg-b": PackageInfo("pkg-b", "2.0.0", now, ["pkg-c>=1.0"]),
            "pkg-c": PackageInfo("pkg-c", "1.0.0", now, []),
        }
        depends_on, depended_by = resolver._build_dependency_graph(pkg_map)

        assert "pkg-b" in depends_on["pkg-a"]
        assert "pkg-c" in depends_on["pkg-b"]
        assert "pkg-a" in depended_by["pkg-b"]
        assert "pkg-b" in depended_by["pkg-c"]

    def test_get_package_age_score(self, old_date: datetime) -> None:
        resolver = DependencyResolver()
        info = PackageInfo("pkg", "1.0", old_date, [])
        score = resolver._get_package_age_score(info)
        # Should be positive (days since 2020-01-01)
        assert score > 1000

    def test_score_package_for_removal(
        self, old_date: datetime, now: datetime
    ) -> None:
        resolver = DependencyResolver()
        old_pkg = PackageInfo("old-pkg", "1.0.0", old_date, [])
        new_pkg = PackageInfo("new-pkg", "1.0.0", now, [])
        pkg_map = {"old-pkg": old_pkg, "new-pkg": new_pkg}
        conflicts: list[tuple[str, str, str]] = []
        depended_by: dict[str, set[str]] = {}

        old_score = resolver._score_package_for_removal(
            "old-pkg", old_pkg, pkg_map, conflicts, depended_by
        )
        new_score = resolver._score_package_for_removal(
            "new-pkg", new_pkg, pkg_map, conflicts, depended_by
        )

        assert old_score > new_score

    def test_find_conflict_clusters_empty(self) -> None:
        resolver = DependencyResolver()
        clusters = resolver._find_conflict_clusters([], {})
        assert clusters == []

    def test_find_conflict_clusters_single(self, now: datetime) -> None:
        resolver = DependencyResolver()
        pkg_map = {
            "a": PackageInfo("a", "1.0", now, []),
            "b": PackageInfo("b", "1.0", now, []),
        }
        conflicts = [("a", "b", "conflict")]
        clusters = resolver._find_conflict_clusters(conflicts, pkg_map)
        assert len(clusters) == 1
        assert clusters[0] == {"a", "b"}

    def test_find_conflict_clusters_multiple(self, now: datetime) -> None:
        resolver = DependencyResolver()
        pkg_map = {
            "a": PackageInfo("a", "1.0", now, []),
            "b": PackageInfo("b", "1.0", now, []),
            "c": PackageInfo("c", "1.0", now, []),
            "d": PackageInfo("d", "1.0", now, []),
        }
        conflicts = [("a", "b", "conflict1"), ("c", "d", "conflict2")]
        clusters = resolver._find_conflict_clusters(conflicts, pkg_map)
        assert len(clusters) == 2


class TestDependencyResolverAsync:
    @pytest.mark.asyncio
    async def test_resolve_no_conflicts(self, now: datetime) -> None:
        with patch(
            "pipreq_distill.core.PyPIClient.get_packages_parallel"
        ) as mock_fetch:
            mock_fetch.return_value = {
                "requests": PackageInfo("requests", "2.31.0", now, []),
                "flask": PackageInfo("Flask", "3.0.0", now, []),
            }
            with patch("pipreq_distill.core.PyPIClient.close"):
                resolver = DependencyResolver()
                reqs = [Requirement("requests>=2.0"), Requirement("flask>=3.0")]
                result = await resolver.resolve(reqs)

                assert len(result.kept) == 2
                assert result.removed_count == 0

    @pytest.mark.asyncio
    async def test_resolve_removes_conflicting(
        self, old_date: datetime, now: datetime
    ) -> None:
        async def mock_get_parallel(self, reqs):
            return {
                "jmespath": PackageInfo("jmespath", "1.0.1", now, []),
                "aliyun-python-sdk-core": PackageInfo(
                    "aliyun-python-sdk-core",
                    "2.16.0",
                    old_date,
                    ["jmespath<1.0.0,>=0.9.3"],
                ),
            }

        with patch.object(
            DependencyResolver, "_build_dependency_map", mock_get_parallel
        ), patch("pipreq_distill.core.PyPIClient.close", new_callable=AsyncMock):
            resolver = DependencyResolver()
            reqs = [
                Requirement("aliyun-python-sdk-core>=2.16.0"),
                Requirement("jmespath>=1.0.1"),
            ]
            result = await resolver.resolve(reqs)

            # Conflict should be resolved by removing one package
            assert len(result.kept) == 1
            assert result.removed_count == 1
            # Either package removal resolves the conflict
            removed_names = {p.name for p, _ in result.removed}
            kept_names = {p.name for p in result.kept}
            assert removed_names | kept_names == {
                "jmespath",
                "aliyun-python-sdk-core",
            }

    @pytest.mark.asyncio
    async def test_resolve_respects_keep(
        self, old_date: datetime, now: datetime
    ) -> None:
        with patch(
            "pipreq_distill.core.PyPIClient.get_packages_parallel"
        ) as mock_fetch:
            mock_fetch.return_value = {
                "jmespath": PackageInfo("jmespath", "1.0.1", now, []),
                "aliyun-python-sdk-core": PackageInfo(
                    "aliyun-python-sdk-core",
                    "2.16.0",
                    old_date,
                    ["jmespath<1.0.0,>=0.9.3"],
                ),
            }
            with patch("pipreq_distill.core.PyPIClient.close"):
                resolver = DependencyResolver(keep=["aliyun-python-sdk-core"])
                reqs = [
                    Requirement("aliyun-python-sdk-core>=2.16.0"),
                    Requirement("jmespath>=1.0.1"),
                ]
                result = await resolver.resolve(reqs)

                # Should keep aliyun and remove jmespath instead
                assert len(result.kept) == 1
                assert result.kept[0].name == "aliyun-python-sdk-core"

    @pytest.mark.asyncio
    async def test_resolve_empty_requirements(self) -> None:
        with patch("pipreq_distill.core.PyPIClient.get_packages_parallel") as mock_fetch:
            mock_fetch.return_value = {}
            with patch("pipreq_distill.core.PyPIClient.close"):
                resolver = DependencyResolver()
                result = await resolver.resolve([])

                assert result.kept == []
                assert result.removed == []
