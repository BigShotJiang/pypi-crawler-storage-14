# Changelog

All notable changes to pipreq-distill will be documented in this file.

## [0.1.0] - 2024-11-28

### Added

- Initial release
- Support for requirements.txt input and output
- Support for pyproject.toml input and output
- PEP 621 dependencies parsing
- Optional dependencies group support
- Fire-based CLI with comprehensive options
- Graph-aware conflict resolution algorithm
- Package scoring based on age, conflicts, and dependencies
- PyPI caching with 24-hour TTL
- Parallel package fetching (up to 20 concurrent requests)
- Dry-run mode to preview changes
- JSON output for scripting
- Package protection with `--keep` flag
- Rich terminal output for dry-run results
- Comprehensive test suite
