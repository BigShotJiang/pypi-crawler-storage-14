# pipreq-distill: Implementation Plan

## Scope Statement

**pipreq-distill** is a CLI tool that resolves pip dependency conflicts by intelligently removing problematic packages, supporting both `requirements.txt` and `pyproject.toml` formats for input and output.

---

## 1. Current State Analysis

### 1.1 Existing pipunreq Implementation

The `issues/pipunreq/pipunreq.py` provides a working foundation with:

**Strengths:**
- Async PyPI client with caching and retry logic
- Graph-aware conflict resolution algorithm
- Package scoring based on age, dependencies, and conflict involvement
- Wheel/sdist metadata extraction fallbacks

**Gaps to Address:**
- Single-file script, not a proper package
- Only supports `requirements.txt` format
- Uses `print()` for logging instead of structured logging
- Tests have async issues (calling sync wrapper on async functions)
- Missing type hints in some areas
- No rich terminal output

---

## 2. Architecture Design

### 2.1 Package Structure

```
pipreq-distill/
├── src/
│   └── pipreq_distill/
│       ├── __init__.py          # Package exports
│       ├── cli.py               # Fire CLI entry point
│       ├── core.py              # DependencyResolver, main logic
│       ├── pypi.py              # PyPIClient (async HTTP)
│       ├── models.py            # PackageInfo, ResolvedPackages dataclasses
│       ├── parsers/
│       │   ├── __init__.py
│       │   ├── base.py          # Abstract base parser
│       │   ├── requirements.py  # requirements.txt parser
│       │   └── pyproject.py     # pyproject.toml parser
│       └── writers/
│           ├── __init__.py
│           ├── base.py          # Abstract base writer
│           ├── requirements.py  # requirements.txt writer
│           └── pyproject.py     # pyproject.toml writer
├── tests/
│   ├── __init__.py
│   ├── conftest.py              # Shared fixtures
│   ├── test_models.py
│   ├── test_pypi.py
│   ├── test_core.py
│   ├── test_parsers.py
│   ├── test_writers.py
│   └── test_cli.py
├── pyproject.toml
├── README.md
├── CHANGELOG.md
└── LICENSE
```

### 2.2 Module Responsibilities

#### `models.py` - Data Structures

```python
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class PackageInfo:
    """Package metadata from PyPI."""
    name: str
    version: str
    release_date: datetime
    requires_dist: list[str] = field(default_factory=list)

    @property
    def canonical_name(self) -> str:
        """Return PEP 503 normalized name."""
        return self.name.lower().replace("-", "_").replace(".", "_")


@dataclass
class ResolvedResult:
    """Result of dependency resolution."""
    kept: list[PackageInfo]
    removed: list[tuple[PackageInfo, float]]  # (pkg, removal_score)

    @property
    def kept_requirements(self) -> list[str]:
        """Return list of 'name==version' strings."""
        return [f"{p.name}=={p.version}" for p in sorted(self.kept, key=lambda x: x.name.lower())]
```

#### `parsers/base.py` - Abstract Parser

```python
from abc import ABC, abstractmethod
from pathlib import Path
from packaging.requirements import Requirement


class BaseParser(ABC):
    """Abstract base for requirement parsers."""

    @abstractmethod
    def parse(self, content: str) -> list[Requirement]:
        """Parse content into requirements list."""
        ...

    @abstractmethod
    def parse_file(self, path: Path) -> list[Requirement]:
        """Parse file into requirements list."""
        ...

    @classmethod
    @abstractmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this parser can handle the file."""
        ...
```

#### `parsers/requirements.py` - Requirements.txt Parser

```python
from pathlib import Path
from packaging.requirements import Requirement
from .base import BaseParser


class RequirementsParser(BaseParser):
    """Parser for requirements.txt files."""

    def parse(self, content: str) -> list[Requirement]:
        requirements = []
        for line in content.strip().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            try:
                requirements.append(Requirement(line))
            except Exception:
                pass  # Skip invalid lines
        return requirements

    def parse_file(self, path: Path) -> list[Requirement]:
        return self.parse(path.read_text())

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        return path.suffix == ".txt" or path.name == "requirements.txt"
```

#### `parsers/pyproject.py` - Pyproject.toml Parser

```python
from pathlib import Path
import tomllib
from packaging.requirements import Requirement
from .base import BaseParser


class PyprojectParser(BaseParser):
    """Parser for pyproject.toml files."""

    def __init__(self, dependency_group: str = "dependencies"):
        self.dependency_group = dependency_group

    def parse(self, content: str) -> list[Requirement]:
        data = tomllib.loads(content)
        deps = []

        # Standard PEP 621 dependencies
        if self.dependency_group == "dependencies":
            deps = data.get("project", {}).get("dependencies", [])
        # Optional dependency groups
        elif self.dependency_group.startswith("optional."):
            group = self.dependency_group.split(".", 1)[1]
            deps = data.get("project", {}).get("optional-dependencies", {}).get(group, [])
        # uv/poetry specific groups
        else:
            # Check uv groups
            deps = data.get("tool", {}).get("uv", {}).get("dev-dependencies", {}).get(self.dependency_group, [])
            if not deps:
                # Check poetry groups
                deps = data.get("tool", {}).get("poetry", {}).get("group", {}).get(self.dependency_group, {}).get("dependencies", {})
                if isinstance(deps, dict):
                    deps = [f"{k}{v}" if isinstance(v, str) else k for k, v in deps.items()]

        return [Requirement(d) for d in deps if isinstance(d, str)]

    def parse_file(self, path: Path) -> list[Requirement]:
        return self.parse(path.read_text())

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        return path.name == "pyproject.toml"
```

#### `writers/requirements.py` - Requirements.txt Writer

```python
from pathlib import Path
from ..models import ResolvedResult
from .base import BaseWriter


class RequirementsWriter(BaseWriter):
    """Writer for requirements.txt format."""

    def write(self, result: ResolvedResult) -> str:
        return "\n".join(result.kept_requirements) + "\n"

    def write_file(self, result: ResolvedResult, path: Path) -> None:
        path.write_text(self.write(result))
```

#### `writers/pyproject.py` - Pyproject.toml Writer

```python
from pathlib import Path
import tomllib
from ..models import ResolvedResult
from .base import BaseWriter


class PyprojectWriter(BaseWriter):
    """Writer for pyproject.toml format."""

    def __init__(self, dependency_group: str = "dependencies"):
        self.dependency_group = dependency_group

    def write(self, result: ResolvedResult) -> str:
        """Generate pyproject.toml snippet for dependencies."""
        deps = result.kept_requirements
        lines = ["[project]", "dependencies = ["]
        for dep in deps:
            lines.append(f'    "{dep}",')
        lines.append("]")
        return "\n".join(lines) + "\n"

    def update_file(self, result: ResolvedResult, path: Path) -> None:
        """Update existing pyproject.toml with resolved dependencies."""
        content = path.read_text()
        data = tomllib.loads(content)

        # Use tomlkit for preserving formatting
        import tomlkit
        doc = tomlkit.parse(content)

        if self.dependency_group == "dependencies":
            if "project" not in doc:
                doc["project"] = {}
            doc["project"]["dependencies"] = result.kept_requirements

        path.write_text(tomlkit.dumps(doc))
```

#### `pypi.py` - Async PyPI Client

```python
import asyncio
import hashlib
import json
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Optional

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from .models import PackageInfo


class PyPIClient:
    """Async client for PyPI API with caching and retry."""

    CACHE_DIR = Path(tempfile.gettempdir()) / "pipreq_distill_cache"
    CACHE_TTL_HOURS = 24
    MAX_CONCURRENT = 20

    def __init__(
        self,
        timeout: float = 30.0,
        use_cache: bool = True,
        verbose: bool = False,
    ):
        self.timeout = timeout
        self.use_cache = use_cache
        self.verbose = verbose
        self._memory_cache: dict[str, dict] = {}
        self._client: Optional[httpx.AsyncClient] = None
        self._semaphore: Optional[asyncio.Semaphore] = None

        if use_cache:
            self.CACHE_DIR.mkdir(exist_ok=True)

    async def get_package_info(
        self,
        package_name: str,
        version: Optional[str] = None
    ) -> Optional[PackageInfo]:
        """Fetch package info from PyPI."""
        # ... implementation from pipunreq with improvements

    async def get_packages_parallel(
        self,
        requirements: list[tuple[str, Optional[str]]]
    ) -> dict[str, PackageInfo]:
        """Fetch multiple packages concurrently."""
        # ... implementation from pipunreq

    async def close(self) -> None:
        """Close HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
```

#### `core.py` - Dependency Resolver

```python
from collections import defaultdict
from datetime import datetime
from typing import Optional

from loguru import logger
from packaging.requirements import Requirement

from .models import PackageInfo, ResolvedResult
from .pypi import PyPIClient


class DependencyResolver:
    """Graph-aware dependency conflict resolver."""

    def __init__(
        self,
        keep: Optional[list[str]] = None,
        timeout: float = 30.0,
        use_cache: bool = True,
        max_concurrent: int = 20,
        verbose: bool = False,
    ):
        self.pypi = PyPIClient(timeout=timeout, use_cache=use_cache, verbose=verbose)
        self.pypi.MAX_CONCURRENT = max_concurrent
        self.keep = {k.lower() for k in (keep or [])}
        self.verbose = verbose

    async def resolve(self, requirements: list[Requirement]) -> ResolvedResult:
        """Resolve dependency conflicts using iterative removal."""
        pkg_map = await self._build_dependency_map(requirements)
        _, depended_by = self._build_dependency_graph(pkg_map)

        removed: list[tuple[PackageInfo, float]] = []

        while True:
            conflicts = self._find_conflicts(pkg_map)
            if not conflicts:
                break

            # Score and remove worst package
            scores = self._score_packages(pkg_map, conflicts, depended_by)
            if not scores:
                break

            worst_name = max(scores, key=scores.get)
            worst_pkg = pkg_map.pop(worst_name)
            removed.append((worst_pkg, scores[worst_name]))

            if self.verbose:
                logger.info(f"Removed {worst_name} (score: {scores[worst_name]:.1f})")

        await self.pypi.close()
        return ResolvedResult(
            kept=list(pkg_map.values()),
            removed=removed,
        )

    # ... additional methods from pipunreq
```

#### `cli.py` - Fire CLI

```python
from pathlib import Path
from typing import Optional
import asyncio
import json
import sys

import fire
from loguru import logger
from rich.console import Console
from rich.table import Table

from .core import DependencyResolver
from .parsers import RequirementsParser, PyprojectParser
from .writers import RequirementsWriter, PyprojectWriter


console = Console()


def distill(
    input: Optional[str] = None,
    output: Optional[str] = None,
    format: str = "auto",
    group: str = "dependencies",
    keep: Optional[str] = None,
    dry_run: bool = False,
    json_output: bool = False,
    verbose: bool = False,
    timeout: float = 30.0,
    max_concurrent: int = 20,
) -> None:
    """
    Resolve pip dependency conflicts by removing problematic packages.

    Args:
        input: Input file (requirements.txt or pyproject.toml). Default: stdin
        output: Output file. Default: stdout
        format: Input/output format: auto, requirements, pyproject
        group: Dependency group for pyproject.toml (default: dependencies)
        keep: Comma-separated package names to protect from removal
        dry_run: Show what would be removed without writing output
        json_output: Output results as JSON
        verbose: Show detailed progress
        timeout: PyPI request timeout in seconds
        max_concurrent: Maximum concurrent PyPI requests
    """
    # Configure logging
    logger.remove()
    if verbose:
        logger.add(sys.stderr, level="INFO")

    # Parse input
    if input:
        path = Path(input)
        if format == "auto":
            format = "pyproject" if path.name == "pyproject.toml" else "requirements"

        parser = PyprojectParser(group) if format == "pyproject" else RequirementsParser()
        requirements = parser.parse_file(path)
    else:
        content = sys.stdin.read()
        parser = RequirementsParser()
        requirements = parser.parse(content)

    # Resolve
    keep_list = [k.strip() for k in (keep or "").split(",") if k.strip()]
    resolver = DependencyResolver(
        keep=keep_list,
        timeout=timeout,
        max_concurrent=max_concurrent,
        verbose=verbose,
    )
    result = asyncio.run(resolver.resolve(requirements))

    # Output
    if dry_run:
        _print_dry_run(result)
        return

    if json_output:
        _print_json(result)
        return

    # Write output
    writer = PyprojectWriter(group) if format == "pyproject" else RequirementsWriter()

    if output:
        if format == "pyproject" and Path(output).exists():
            writer.update_file(result, Path(output))
        else:
            writer.write_file(result, Path(output))
        if verbose:
            console.print(f"[green]Written to {output}[/green]")
    else:
        print(writer.write(result))


def _print_dry_run(result) -> None:
    """Print dry-run summary."""
    console.print("\n[bold]Dry Run Results[/bold]\n")

    if result.removed:
        table = Table(title="Would Remove")
        table.add_column("Package", style="red")
        table.add_column("Version")
        table.add_column("Score", justify="right")

        for pkg, score in result.removed:
            table.add_row(pkg.name, pkg.version, f"{score:.1f}")

        console.print(table)
    else:
        console.print("[green]No packages would be removed[/green]")

    console.print(f"\nWould keep [bold]{len(result.kept)}[/bold] packages")


def _print_json(result) -> None:
    """Print JSON output."""
    data = {
        "kept": result.kept_requirements,
        "removed": [
            {"name": p.name, "version": p.version, "score": round(s, 1)}
            for p, s in result.removed
        ],
        "kept_count": len(result.kept),
        "removed_count": len(result.removed),
    }
    print(json.dumps(data, indent=2))


def main():
    """Entry point."""
    fire.Fire(distill)


if __name__ == "__main__":
    main()
```

---

## 3. Key Improvements Over pipunreq

### 3.1 Input/Output Flexibility

| Feature | pipunreq | pipreq-distill |
|---------|----------|----------------|
| requirements.txt input | Yes | Yes |
| pyproject.toml input | No | Yes |
| requirements.txt output | Yes | Yes |
| pyproject.toml output | No | Yes |
| Dependency groups | No | Yes |
| stdin/stdout | Yes | Yes |

### 3.2 Better Logging

Replace `print()` statements with `loguru`:

```python
# Before (pipunreq)
if self.verbose:
    print(f"Warning: Failed to fetch {package_name}: {e}", file=sys.stderr)

# After (pipreq-distill)
logger.warning(f"Failed to fetch {package_name}: {e}")
```

### 3.3 Rich Terminal Output

```python
from rich.progress import Progress, SpinnerColumn, TextColumn

async def resolve_with_progress(self, requirements):
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Fetching packages...", total=None)
        # ...
```

### 3.4 Type Safety

All functions will have complete type hints:

```python
def score_package_for_removal(
    self,
    pkg_name: str,
    pkg_info: PackageInfo,
    pkg_map: dict[str, PackageInfo],
    conflicts: list[tuple[str, str, str]],
    depended_by: dict[str, set[str]],
) -> float:
```

---

## 4. Dependencies

```toml
[project]
dependencies = [
    "fire>=0.5.0",
    "httpx>=0.27.0",
    "packaging>=24.0",
    "tenacity>=8.0.0",
    "loguru>=0.7.0",
    "rich>=13.0.0",
    "tomlkit>=0.12.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=0.23.0",
    "pytest-cov>=4.0.0",
    "ruff>=0.4.0",
    "mypy>=1.10.0",
]
```

---

## 5. CLI Interface

```bash
# Basic usage (requirements.txt)
pipreq-distill --input requirements.txt --output resolved.txt

# From stdin
cat requirements.txt | pipreq-distill > resolved.txt

# pyproject.toml input/output
pipreq-distill --input pyproject.toml --output pyproject.toml --format pyproject

# Specific dependency group
pipreq-distill --input pyproject.toml --group dev --dry-run

# Protect specific packages
pipreq-distill --input requirements.txt --keep "requests,flask"

# JSON output for scripting
pipreq-distill --input requirements.txt --json-output

# Verbose mode
pipreq-distill --input requirements.txt --verbose
```

---

## 6. Testing Strategy

### 6.1 Unit Tests

```python
# tests/test_parsers.py
import pytest
from pipreq_distill.parsers import RequirementsParser, PyprojectParser


class TestRequirementsParser:
    def test_parse_basic(self):
        parser = RequirementsParser()
        reqs = parser.parse("requests>=2.0\nflask==2.0.0")
        assert len(reqs) == 2

    def test_parse_with_comments(self):
        parser = RequirementsParser()
        reqs = parser.parse("# comment\nrequests>=2.0")
        assert len(reqs) == 1


class TestPyprojectParser:
    def test_parse_pep621(self):
        parser = PyprojectParser()
        content = '''
        [project]
        dependencies = ["requests>=2.0", "flask"]
        '''
        reqs = parser.parse(content)
        assert len(reqs) == 2

    def test_parse_optional_deps(self):
        parser = PyprojectParser("optional.dev")
        content = '''
        [project.optional-dependencies]
        dev = ["pytest", "ruff"]
        '''
        reqs = parser.parse(content)
        assert len(reqs) == 2
```

### 6.2 Integration Tests

```python
# tests/test_integration.py
import pytest
from unittest.mock import AsyncMock, patch
from pipreq_distill.core import DependencyResolver
from pipreq_distill.models import PackageInfo


@pytest.mark.asyncio
async def test_resolve_removes_conflicting_package():
    """Test that conflicting packages are correctly removed."""
    with patch.object(PyPIClient, 'get_packages_parallel') as mock:
        mock.return_value = {
            "jmespath": PackageInfo("jmespath", "1.0.1", now, []),
            "aliyun-python-sdk-core": PackageInfo(
                "aliyun-python-sdk-core", "2.16.0", old_date,
                ["jmespath<1.0.0,>=0.9.3"]
            ),
        }

        resolver = DependencyResolver()
        result = await resolver.resolve(requirements)

        assert len(result.kept) == 1
        assert result.kept[0].name == "jmespath"
        assert len(result.removed) == 1
```

---

## 7. Implementation Phases

### Phase 1: Project Setup
- Initialize pyproject.toml with uv
- Set up src layout
- Configure ruff and mypy
- Add basic CI

### Phase 2: Core Modules
- Port models.py from pipunreq
- Port pypi.py with improvements
- Port core.py resolver logic

### Phase 3: Parsers & Writers
- Implement RequirementsParser
- Implement PyprojectParser
- Implement RequirementsWriter
- Implement PyprojectWriter

### Phase 4: CLI
- Implement Fire-based CLI
- Add rich output formatting
- Add loguru logging

### Phase 5: Testing
- Port and fix existing tests
- Add parser/writer tests
- Add integration tests
- Achieve >80% coverage

### Phase 6: Documentation
- Write comprehensive README
- Add CLI help text
- Add usage examples

---

## 8. Error Handling

```python
class PipreqDistillError(Exception):
    """Base exception for pipreq-distill."""
    pass


class ParseError(PipreqDistillError):
    """Error parsing requirements."""
    pass


class PyPIError(PipreqDistillError):
    """Error fetching from PyPI."""
    pass


class ResolutionError(PipreqDistillError):
    """Could not resolve conflicts."""
    pass
```

---

## 9. Success Criteria

1. All existing pipunreq tests pass
2. New parser/writer tests pass
3. CLI works with both file formats
4. >80% code coverage
5. All type checks pass (mypy)
6. All linting passes (ruff)
7. README with clear examples
