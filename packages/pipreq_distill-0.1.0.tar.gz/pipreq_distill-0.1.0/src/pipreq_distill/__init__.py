"""pipreq-distill: Resolve pip dependency conflicts by intelligently removing problematic packages."""

from pipreq_distill.models import PackageInfo, ResolvedResult

__version__ = "0.1.0"
__all__ = ["PackageInfo", "ResolvedResult", "__version__"]
