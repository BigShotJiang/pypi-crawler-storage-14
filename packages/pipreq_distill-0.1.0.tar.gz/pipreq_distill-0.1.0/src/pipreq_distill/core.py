"""Core dependency resolver using graph-aware conflict resolution."""

import re
from collections import defaultdict
from datetime import datetime

from loguru import logger
from packaging.requirements import Requirement

from pipreq_distill.models import PackageInfo, ResolvedResult
from pipreq_distill.pypi import PyPIClient


class DependencyResolver:
    """Graph-aware dependency conflict resolver.

    Uses parallel PyPI fetching and iterative removal to find the
    largest compatible subset of packages.
    """

    def __init__(
        self,
        keep: list[str] | None = None,
        timeout: float = 30.0,
        use_cache: bool = True,
        max_concurrent: int = 20,
        verbose: bool = False,
    ) -> None:
        """Initialize resolver.

        Args:
            keep: Package names to protect from removal.
            timeout: PyPI request timeout in seconds.
            use_cache: Whether to use disk cache for PyPI responses.
            max_concurrent: Maximum concurrent PyPI requests.
            verbose: Show detailed progress.
        """
        self.pypi = PyPIClient(timeout=timeout, use_cache=use_cache, verbose=verbose)
        self.pypi.MAX_CONCURRENT = max_concurrent
        self.keep = {k.lower() for k in (keep or [])}
        self.verbose = verbose

    async def resolve(self, requirements: list[Requirement]) -> ResolvedResult:
        """Resolve dependency conflicts using iterative removal.

        Args:
            requirements: List of parsed requirements to resolve.

        Returns:
            ResolvedResult with kept and removed packages.
        """
        if self.verbose:
            logger.info(f"Resolving {len(requirements)} requirements")

        pkg_map = await self._build_dependency_map(requirements)

        if not pkg_map:
            await self.pypi.close()
            return ResolvedResult(kept=[], removed=[])

        _, depended_by = self._build_dependency_graph(pkg_map)
        removed: list[tuple[PackageInfo, float]] = []
        max_iterations = len(pkg_map)
        iteration = 0

        while iteration < max_iterations:
            conflicts = self._find_conflicts(pkg_map)

            if not conflicts:
                break

            if self.verbose:
                clusters = self._find_conflict_clusters(conflicts, pkg_map)
                logger.info(
                    f"Iteration {iteration + 1}: {len(conflicts)} conflicts "
                    f"in {len(clusters)} cluster(s)"
                )
                for pkg, dep, reason in conflicts[:3]:
                    logger.debug(f"  - {reason}")
                if len(conflicts) > 3:
                    logger.debug(f"  ... and {len(conflicts) - 3} more")

            # Score all packages involved in conflicts
            conflict_packages = {p for p, d, _ in conflicts} | {d for p, d, _ in conflicts}
            scores: dict[str, float] = {}
            for pkg_name in conflict_packages:
                if pkg_name in pkg_map and pkg_name not in self.keep:
                    scores[pkg_name] = self._score_package_for_removal(
                        pkg_name, pkg_map[pkg_name], pkg_map, conflicts, depended_by
                    )

            if not scores:
                if self.verbose:
                    logger.warning("All conflicting packages are protected, cannot resolve")
                break

            # Remove package with highest score
            worst_name = max(scores, key=lambda x: scores[x])
            worst_score = scores[worst_name]
            worst_pkg = pkg_map[worst_name]
            removed.append((worst_pkg, worst_score))

            if self.verbose:
                logger.info(f"Removing {worst_name} (score: {worst_score:.1f})")

            # Update graph when removing package
            for dep in list(depended_by.get(worst_name, set())):
                if dep in depended_by:
                    depended_by[dep].discard(worst_name)
            del pkg_map[worst_name]

            iteration += 1

        await self.pypi.close()

        if self.verbose:
            logger.info(f"Resolved to {len(pkg_map)} compatible packages")

        return ResolvedResult(
            kept=list(pkg_map.values()),
            removed=removed,
        )

    async def _build_dependency_map(
        self, requirements: list[Requirement]
    ) -> dict[str, PackageInfo]:
        """Build map of package name to info for latest compatible versions."""
        if self.verbose:
            logger.info(f"Fetching {len(requirements)} packages in parallel...")

        # First pass: get latest versions for all packages
        req_tuples = [(req.name, None) for req in requirements]
        pkg_map = await self.pypi.get_packages_parallel(req_tuples)

        # Second pass: for packages where latest doesn't satisfy specifier
        retry_list: list[tuple[str, str]] = []
        for req in requirements:
            name_lower = req.name.lower()
            if name_lower in pkg_map:
                info = pkg_map[name_lower]
                if req.specifier and not req.specifier.contains(info.version):
                    if "==" in str(req.specifier):
                        version_match = re.search(r"==\s*([^\s,]+)", str(req.specifier))
                        if version_match:
                            retry_list.append((req.name, version_match.group(1)))
                            del pkg_map[name_lower]

        if retry_list:
            if self.verbose:
                logger.info(f"Fetching {len(retry_list)} version-specific packages...")
            extra_pkgs = await self.pypi.get_packages_parallel(retry_list)
            pkg_map.update(extra_pkgs)

        if self.verbose:
            logger.info(f"Fetched {len(pkg_map)} packages successfully")

        return pkg_map

    def _build_dependency_graph(
        self, pkg_map: dict[str, PackageInfo]
    ) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
        """Build forward and reverse dependency graphs.

        Returns:
            (depends_on, depended_by): Forward deps and reverse deps.
        """
        depends_on: dict[str, set[str]] = defaultdict(set)
        depended_by: dict[str, set[str]] = defaultdict(set)

        for pkg_name, pkg_info in pkg_map.items():
            for dep_str in pkg_info.requires_dist:
                if ";" in dep_str:
                    dep_str = dep_str.split(";")[0].strip()
                if not dep_str:
                    continue
                try:
                    dep_req = Requirement(dep_str)
                    dep_name_lower = dep_req.name.lower()
                    if dep_name_lower in pkg_map:
                        depends_on[pkg_name].add(dep_name_lower)
                        depended_by[dep_name_lower].add(pkg_name)
                except Exception:
                    pass

        return depends_on, depended_by

    def _find_conflicts(
        self, pkg_map: dict[str, PackageInfo]
    ) -> list[tuple[str, str, str]]:
        """Find version conflicts.

        Returns:
            List of (package, dependency, conflict_reason).
        """
        conflicts: list[tuple[str, str, str]] = []

        for pkg_name, pkg_info in pkg_map.items():
            for dep_str in pkg_info.requires_dist:
                if ";" in dep_str:
                    dep_str = dep_str.split(";")[0].strip()

                if not dep_str:
                    continue

                try:
                    dep_req = Requirement(dep_str)
                    dep_name_lower = dep_req.name.lower()

                    if dep_name_lower in pkg_map:
                        dep_info = pkg_map[dep_name_lower]
                        if dep_req.specifier and not dep_req.specifier.contains(dep_info.version):
                            conflict = (
                                f"{pkg_name} requires {dep_str}, "
                                f"but we have {dep_name_lower}=={dep_info.version}"
                            )
                            conflicts.append((pkg_name, dep_name_lower, conflict))
                except Exception:
                    pass

        return conflicts

    def _get_package_age_score(self, info: PackageInfo) -> float:
        """Calculate age score (older = higher score = worse)."""
        now = datetime.now(info.release_date.tzinfo)
        age_days = (now - info.release_date).days
        return float(age_days)

    def _score_package_for_removal(
        self,
        pkg_name: str,
        pkg_info: PackageInfo,
        pkg_map: dict[str, PackageInfo],
        conflicts: list[tuple[str, str, str]],
        depended_by: dict[str, set[str]],
    ) -> float:
        """Score package for removal using graph-aware algorithm.

        Higher score = remove first. Considers:
        1. Conflict involvement: packages in more conflicts are worse
        2. Reverse dependencies: packages depended on by fewer packages are better
        3. Age: older packages are worse
        4. Cascade potential: removing pkg that's only dep of conflicting pkgs is better
        """
        score = 0.0

        # 1. Conflict involvement score (major factor)
        conflict_count = sum(1 for p, d, _ in conflicts if p == pkg_name or d == pkg_name)
        score += conflict_count * 500

        # 2. Reverse dependency score (fewer dependents = higher score)
        num_dependents = len(depended_by.get(pkg_name, set()) & set(pkg_map.keys()))
        score += max(0, 200 - num_dependents * 50)

        # 3. Age factor
        age_score = self._get_package_age_score(pkg_info)
        score += age_score * 0.1

        # 4. Old dependencies penalty
        old_dep_count = 0
        for dep_str in pkg_info.requires_dist:
            if ";" in dep_str:
                dep_str = dep_str.split(";")[0].strip()
            try:
                dep_req = Requirement(dep_str)
                dep_name_lower = dep_req.name.lower()
                if dep_name_lower in pkg_map:
                    dep_info = pkg_map[dep_name_lower]
                    dep_age = self._get_package_age_score(dep_info)
                    if dep_age > 365:
                        old_dep_count += 1
            except Exception:
                pass
        score += old_dep_count * 100

        # 5. Cascade bonus
        dependents = depended_by.get(pkg_name, set()) & set(pkg_map.keys())
        conflicting_pkgs = {p for p, d, _ in conflicts} | {d for p, d, _ in conflicts}
        if dependents and dependents.issubset(conflicting_pkgs):
            score += 300

        return score

    def _find_conflict_clusters(
        self, conflicts: list[tuple[str, str, str]], pkg_map: dict[str, PackageInfo]
    ) -> list[set[str]]:
        """Find connected components of conflicting packages for batch analysis."""
        if not conflicts:
            return []

        adj: dict[str, set[str]] = defaultdict(set)
        for pkg, dep, _ in conflicts:
            adj[pkg].add(dep)
            adj[dep].add(pkg)

        visited: set[str] = set()
        clusters: list[set[str]] = []

        for start in adj:
            if start in visited:
                continue
            cluster: set[str] = set()
            queue = [start]
            while queue:
                node = queue.pop()
                if node in visited:
                    continue
                visited.add(node)
                cluster.add(node)
                queue.extend(adj[node] - visited)
            clusters.append(cluster)

        return clusters
