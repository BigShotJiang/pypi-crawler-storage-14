"""Parser for pyproject.toml files."""

import tomllib
from pathlib import Path
from typing import Any

from loguru import logger
from packaging.requirements import Requirement

from pipreq_distill.parsers.base import BaseParser


class PyprojectParser(BaseParser):
    """Parser for pyproject.toml files."""

    def __init__(self, dependency_group: str = "dependencies") -> None:
        """Initialize parser.

        Args:
            dependency_group: Which dependency group to parse. Options:
                - "dependencies": PEP 621 project.dependencies
                - "optional.<group>": project.optional-dependencies.<group>
                - "<group>": tool.uv.dev-dependencies.<group> or
                           tool.poetry.group.<group>.dependencies
        """
        self.dependency_group = dependency_group

    def parse(self, content: str) -> list[Requirement]:
        """Parse pyproject.toml content into requirements list."""
        data = tomllib.loads(content)
        deps = self._extract_dependencies(data)
        return self._parse_deps(deps)

    def _extract_dependencies(self, data: dict[str, Any]) -> list[str]:
        """Extract dependency list from parsed TOML data."""
        deps: list[str] = []

        # Standard PEP 621 dependencies
        if self.dependency_group == "dependencies":
            deps = data.get("project", {}).get("dependencies", [])

        # Optional dependency groups (e.g., "optional.dev")
        elif self.dependency_group.startswith("optional."):
            group = self.dependency_group.split(".", 1)[1]
            deps = data.get("project", {}).get("optional-dependencies", {}).get(group, [])

        # Check for tool-specific groups
        else:
            # Check uv dev-dependencies (can be list or dict)
            uv_dev = data.get("tool", {}).get("uv", {}).get("dev-dependencies")
            if isinstance(uv_dev, list) and self.dependency_group == "dev":
                # uv uses list format for dev-dependencies
                deps = uv_dev
            elif isinstance(uv_dev, dict):
                # uv uses dict format for named groups
                deps = uv_dev.get(self.dependency_group, [])
            else:
                # Check poetry groups
                poetry_deps = (
                    data.get("tool", {})
                    .get("poetry", {})
                    .get("group", {})
                    .get(self.dependency_group, {})
                    .get("dependencies", {})
                )
                if isinstance(poetry_deps, dict):
                    # Poetry uses {name: version} format
                    deps = self._convert_poetry_deps(poetry_deps)
                elif isinstance(poetry_deps, list):
                    deps = poetry_deps

        return deps

    def _convert_poetry_deps(self, poetry_deps: dict[str, Any]) -> list[str]:
        """Convert Poetry-style dependencies to PEP 508 format."""
        result: list[str] = []
        for name, version in poetry_deps.items():
            if isinstance(version, str):
                if version == "*":
                    result.append(name)
                elif version.startswith("^"):
                    # ^1.0 -> >=1.0,<2.0
                    ver = version[1:]
                    parts = ver.split(".")
                    if len(parts) >= 1:
                        major = int(parts[0])
                        result.append(f"{name}>={ver},<{major + 1}.0")
                elif version.startswith("~"):
                    # ~1.0 -> >=1.0,<1.1
                    ver = version[1:]
                    result.append(f"{name}~={ver}")
                else:
                    result.append(f"{name}{version}")
            elif isinstance(version, dict):
                # Complex dependency spec
                result.append(name)
        return result

    def _parse_deps(self, deps: list[str]) -> list[Requirement]:
        """Parse list of dependency strings into Requirement objects."""
        requirements: list[Requirement] = []
        for dep in deps:
            if not isinstance(dep, str):
                continue
            try:
                requirements.append(Requirement(dep))
            except Exception as e:
                logger.warning(f"Could not parse dependency '{dep}': {e}")
        return requirements

    def parse_file(self, path: Path) -> list[Requirement]:
        """Parse pyproject.toml file into requirements list."""
        return self.parse(path.read_text())

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this parser can handle the file."""
        return path.name == "pyproject.toml"
