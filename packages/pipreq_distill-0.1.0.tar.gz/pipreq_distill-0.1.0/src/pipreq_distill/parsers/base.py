"""Abstract base parser for requirement files."""

from abc import ABC, abstractmethod
from pathlib import Path

from packaging.requirements import Requirement


class BaseParser(ABC):
    """Abstract base for requirement parsers."""

    @abstractmethod
    def parse(self, content: str) -> list[Requirement]:
        """Parse content into requirements list."""
        ...

    @abstractmethod
    def parse_file(self, path: Path) -> list[Requirement]:
        """Parse file into requirements list."""
        ...

    @classmethod
    @abstractmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this parser can handle the file."""
        ...
