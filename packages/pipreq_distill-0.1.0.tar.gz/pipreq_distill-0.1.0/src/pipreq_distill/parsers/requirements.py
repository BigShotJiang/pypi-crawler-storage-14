"""Parser for requirements.txt files."""

from pathlib import Path

from loguru import logger
from packaging.requirements import Requirement

from pipreq_distill.parsers.base import BaseParser


class RequirementsParser(BaseParser):
    """Parser for requirements.txt files."""

    def parse(self, content: str) -> list[Requirement]:
        """Parse requirements.txt content into requirements list."""
        requirements: list[Requirement] = []
        for line in content.strip().splitlines():
            line = line.strip()
            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue
            # Skip pip options like -r, -e, --index-url, etc.
            if line.startswith("-") or line.startswith("--"):
                continue
            try:
                requirements.append(Requirement(line))
            except Exception as e:
                logger.warning(f"Could not parse requirement '{line}': {e}")
        return requirements

    def parse_file(self, path: Path) -> list[Requirement]:
        """Parse requirements.txt file into requirements list."""
        return self.parse(path.read_text())

    @classmethod
    def can_handle(cls, path: Path) -> bool:
        """Check if this parser can handle the file."""
        return path.suffix == ".txt" or "requirements" in path.name.lower()
