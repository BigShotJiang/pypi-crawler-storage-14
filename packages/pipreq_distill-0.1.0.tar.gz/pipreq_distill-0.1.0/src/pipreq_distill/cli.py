"""Fire CLI for pipreq-distill."""

import asyncio
import json
import sys
from pathlib import Path

import fire
from loguru import logger
from rich.console import Console
from rich.table import Table

from pipreq_distill.core import DependencyResolver
from pipreq_distill.models import ResolvedResult
from pipreq_distill.parsers import PyprojectParser, RequirementsParser
from pipreq_distill.writers import PyprojectWriter, RequirementsWriter

console = Console(stderr=True)


def distill(
    input: str | None = None,
    output: str | None = None,
    format: str = "auto",
    group: str = "dependencies",
    keep: str | None = None,
    dry_run: bool = False,
    json_output: bool = False,
    verbose: bool = False,
    timeout: float = 30.0,
    max_concurrent: int = 20,
) -> None:
    """Resolve pip dependency conflicts by removing problematic packages.

    Uses PyPI API to find the largest possible collection of compatible packages
    by removing oldest conflicting packages and packages with old dependencies.

    Args:
        input: Input file (requirements.txt or pyproject.toml). Default: stdin
        output: Output file. Default: stdout
        format: Input/output format: auto, requirements, pyproject
        group: Dependency group for pyproject.toml (default: dependencies).
               Examples: dependencies, optional.dev, dev
        keep: Comma-separated package names to protect from removal
        dry_run: Show what would be removed without writing output
        json_output: Output results as JSON
        verbose: Show detailed progress
        timeout: PyPI request timeout in seconds
        max_concurrent: Maximum concurrent PyPI requests

    Examples:
        # Resolve requirements.txt
        pipreq-distill --input requirements.txt --output resolved.txt

        # Pipe from stdin
        cat requirements.txt | pipreq-distill > resolved.txt

        # Process pyproject.toml
        pipreq-distill --input pyproject.toml --output pyproject.toml --format pyproject

        # Process optional dependencies
        pipreq-distill --input pyproject.toml --group optional.dev --dry-run

        # Protect specific packages
        pipreq-distill --input requirements.txt --keep "requests,flask"
    """
    # Configure logging
    logger.remove()
    if verbose:
        logger.add(sys.stderr, level="DEBUG", format="{message}")

    # Determine format
    detected_format = format
    if input and format == "auto":
        path = Path(input)
        detected_format = "pyproject" if path.name == "pyproject.toml" else "requirements"

    # Parse input
    if input:
        path = Path(input)
        if not path.exists():
            console.print(f"[red]Error: File not found: {input}[/red]")
            sys.exit(1)

        if detected_format == "pyproject":
            parser = PyprojectParser(group)
        else:
            parser = RequirementsParser()
        requirements = parser.parse_file(path)
    else:
        if sys.stdin.isatty() and not dry_run:
            console.print("[dim]Reading requirements from stdin (Ctrl+D to finish)...[/dim]")
        content = sys.stdin.read()
        parser = RequirementsParser()
        requirements = parser.parse(content)

    if not requirements:
        console.print("[yellow]No requirements found in input[/yellow]")
        sys.exit(0)

    if verbose:
        console.print(f"[dim]Parsed {len(requirements)} requirements[/dim]")

    # Parse keep list
    keep_list = [k.strip() for k in (keep or "").split(",") if k.strip()]

    # Resolve
    resolver = DependencyResolver(
        keep=keep_list,
        timeout=timeout,
        max_concurrent=max_concurrent,
        verbose=verbose,
    )
    result = asyncio.run(resolver.resolve(requirements))

    # Handle output
    if dry_run:
        _print_dry_run(result)
        return

    if json_output:
        _print_json(result)
        return

    # Determine output format
    output_format = detected_format
    if output and format == "auto":
        output_path = Path(output)
        output_format = "pyproject" if output_path.name == "pyproject.toml" else "requirements"

    # Write output
    if output_format == "pyproject":
        writer = PyprojectWriter(group)
    else:
        writer = RequirementsWriter()

    if output:
        output_path = Path(output)
        if output_format == "pyproject" and output_path.exists():
            writer.update_file(result, output_path)  # type: ignore[union-attr]
        else:
            writer.write_file(result, output_path)
        if verbose:
            console.print(f"[green]Written to {output}[/green]")
    else:
        # Write to stdout
        output_console = Console()
        output_console.print(writer.write(result), end="")


def _print_dry_run(result: ResolvedResult) -> None:
    """Print dry-run summary."""
    console.print("\n[bold]Dry Run Results[/bold]\n")

    if result.removed:
        table = Table(title="Would Remove")
        table.add_column("Package", style="red")
        table.add_column("Version")
        table.add_column("Score", justify="right")

        for pkg, score in result.removed:
            table.add_row(pkg.name, pkg.version, f"{score:.1f}")

        console.print(table)
    else:
        console.print("[green]No packages would be removed (no conflicts found)[/green]")

    console.print(f"\nWould keep [bold]{result.kept_count}[/bold] packages")

    if result.kept:
        console.print("\n[dim]Kept packages:[/dim]")
        for req in result.kept_requirements:
            console.print(f"  {req}")


def _print_json(result: ResolvedResult) -> None:
    """Print JSON output."""
    data = {
        "kept": result.kept_requirements,
        "removed": [
            {"name": p.name, "version": p.version, "score": round(s, 1)}
            for p, s in result.removed
        ],
        "kept_count": result.kept_count,
        "removed_count": result.removed_count,
    }
    # Print to stdout, not stderr
    print(json.dumps(data, indent=2))


def main() -> None:
    """Entry point."""
    fire.Fire(distill)


if __name__ == "__main__":
    main()
