"""Custom exceptions for pipreq-distill."""


class PipreqDistillError(Exception):
    """Base exception for pipreq-distill."""


class ParseError(PipreqDistillError):
    """Error parsing requirements."""


class PyPIError(PipreqDistillError):
    """Error fetching from PyPI."""


class ResolutionError(PipreqDistillError):
    """Could not resolve dependency conflicts."""
