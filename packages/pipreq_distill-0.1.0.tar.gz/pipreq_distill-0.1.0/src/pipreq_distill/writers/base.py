"""Abstract base writer for requirement files."""

from abc import ABC, abstractmethod
from pathlib import Path

from pipreq_distill.models import ResolvedResult


class BaseWriter(ABC):
    """Abstract base for requirement writers."""

    @abstractmethod
    def write(self, result: ResolvedResult) -> str:
        """Generate output string from resolved result."""
        ...

    @abstractmethod
    def write_file(self, result: ResolvedResult, path: Path) -> None:
        """Write resolved result to file."""
        ...
