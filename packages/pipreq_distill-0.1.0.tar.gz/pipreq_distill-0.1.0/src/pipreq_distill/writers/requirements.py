"""Writer for requirements.txt files."""

from pathlib import Path

from pipreq_distill.models import ResolvedResult
from pipreq_distill.writers.base import BaseWriter


class RequirementsWriter(BaseWriter):
    """Writer for requirements.txt format."""

    def write(self, result: ResolvedResult) -> str:
        """Generate requirements.txt content from resolved result."""
        if not result.kept_requirements:
            return ""
        return "\n".join(result.kept_requirements) + "\n"

    def write_file(self, result: ResolvedResult, path: Path) -> None:
        """Write resolved result to requirements.txt file."""
        path.write_text(self.write(result))
