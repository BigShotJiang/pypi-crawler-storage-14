"""Writer for pyproject.toml files."""

from pathlib import Path

import tomlkit

from pipreq_distill.models import ResolvedResult
from pipreq_distill.writers.base import BaseWriter


class PyprojectWriter(BaseWriter):
    """Writer for pyproject.toml format."""

    def __init__(self, dependency_group: str = "dependencies") -> None:
        """Initialize writer.

        Args:
            dependency_group: Which dependency group to write. Options:
                - "dependencies": PEP 621 project.dependencies
                - "optional.<group>": project.optional-dependencies.<group>
        """
        self.dependency_group = dependency_group

    def write(self, result: ResolvedResult) -> str:
        """Generate pyproject.toml snippet for dependencies."""
        deps = result.kept_requirements
        doc = tomlkit.document()

        if self.dependency_group == "dependencies":
            project = tomlkit.table()
            project["dependencies"] = tomlkit.array(deps).multiline(True)
            doc["project"] = project
        elif self.dependency_group.startswith("optional."):
            group = self.dependency_group.split(".", 1)[1]
            project = tomlkit.table()
            optional_deps = tomlkit.table()
            optional_deps[group] = tomlkit.array(deps).multiline(True)
            project["optional-dependencies"] = optional_deps
            doc["project"] = project
        else:
            # Write as tool.uv.dev-dependencies style
            tool = tomlkit.table()
            uv = tomlkit.table()
            uv["dev-dependencies"] = tomlkit.array(deps).multiline(True)
            tool["uv"] = uv
            doc["tool"] = tool

        return tomlkit.dumps(doc)

    def write_file(self, result: ResolvedResult, path: Path) -> None:
        """Write resolved result to new pyproject.toml file."""
        path.write_text(self.write(result))

    def update_file(self, result: ResolvedResult, path: Path) -> None:
        """Update existing pyproject.toml with resolved dependencies."""
        content = path.read_text()
        doc = tomlkit.parse(content)
        deps = result.kept_requirements

        if self.dependency_group == "dependencies":
            if "project" not in doc:
                doc["project"] = tomlkit.table()
            doc["project"]["dependencies"] = tomlkit.array(deps).multiline(True)  # type: ignore[index]

        elif self.dependency_group.startswith("optional."):
            group = self.dependency_group.split(".", 1)[1]
            if "project" not in doc:
                doc["project"] = tomlkit.table()
            if "optional-dependencies" not in doc["project"]:  # type: ignore[operator]
                doc["project"]["optional-dependencies"] = tomlkit.table()  # type: ignore[index]
            doc["project"]["optional-dependencies"][group] = tomlkit.array(deps).multiline(True)  # type: ignore[index]

        else:
            # Update tool.uv.dev-dependencies
            if "tool" not in doc:
                doc["tool"] = tomlkit.table()
            if "uv" not in doc["tool"]:  # type: ignore[operator]
                doc["tool"]["uv"] = tomlkit.table()  # type: ignore[index]
            doc["tool"]["uv"]["dev-dependencies"] = tomlkit.array(deps).multiline(True)  # type: ignore[index]

        path.write_text(tomlkit.dumps(doc))
