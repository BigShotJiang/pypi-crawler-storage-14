"""Data models for pipreq-distill."""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class PackageInfo:
    """Package metadata from PyPI."""

    name: str
    version: str
    release_date: datetime
    requires_dist: list[str] = field(default_factory=list)

    @property
    def canonical_name(self) -> str:
        """Return PEP 503 normalized name."""
        return self.name.lower().replace("-", "_").replace(".", "_")


@dataclass
class ResolvedResult:
    """Result of dependency resolution."""

    kept: list[PackageInfo]
    removed: list[tuple[PackageInfo, float]]  # (pkg, removal_score)

    @property
    def kept_requirements(self) -> list[str]:
        """Return list of 'name==version' strings, sorted by name."""
        return [
            f"{p.name}=={p.version}" for p in sorted(self.kept, key=lambda x: x.name.lower())
        ]

    @property
    def removed_count(self) -> int:
        """Return count of removed packages."""
        return len(self.removed)

    @property
    def kept_count(self) -> int:
        """Return count of kept packages."""
        return len(self.kept)
