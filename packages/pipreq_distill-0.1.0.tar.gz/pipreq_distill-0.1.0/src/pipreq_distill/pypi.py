"""Async PyPI client with caching and retry logic."""

import asyncio
import hashlib
import io
import json
import tarfile
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

import httpx
from loguru import logger
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from pipreq_distill.models import PackageInfo


class PyPIClient:
    """Async client for PyPI API with caching and retry."""

    CACHE_DIR = Path(tempfile.gettempdir()) / "pipreq_distill_cache"
    CACHE_TTL_HOURS = 24
    MAX_CONCURRENT = 20

    def __init__(
        self,
        timeout: float = 30.0,
        use_cache: bool = True,
        verbose: bool = False,
    ) -> None:
        self.timeout = timeout
        self.use_cache = use_cache
        self.verbose = verbose
        self._memory_cache: dict[str, dict] = {}
        self._client: httpx.AsyncClient | None = None
        self._semaphore: asyncio.Semaphore | None = None

        if use_cache:
            self.CACHE_DIR.mkdir(exist_ok=True)

    async def _get_client(self) -> httpx.AsyncClient:
        """Lazy initialization of async client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
            self._semaphore = asyncio.Semaphore(self.MAX_CONCURRENT)
        return self._client

    def _get_cache_path(self, key: str) -> Path:
        """Get path for cached data."""
        safe_key = hashlib.md5(key.encode()).hexdigest()
        return self.CACHE_DIR / f"{safe_key}.json"

    def _load_from_disk_cache(self, key: str) -> dict | None:
        """Load data from disk cache if valid."""
        if not self.use_cache:
            return None
        cache_path = self._get_cache_path(key)
        if not cache_path.exists():
            return None
        # Check TTL
        age_hours = (datetime.now().timestamp() - cache_path.stat().st_mtime) / 3600
        if age_hours > self.CACHE_TTL_HOURS:
            cache_path.unlink()
            return None
        try:
            return json.loads(cache_path.read_text())  # type: ignore[no-any-return]
        except (json.JSONDecodeError, OSError):
            return None

    def _save_to_disk_cache(self, key: str, data: dict) -> None:
        """Save data to disk cache."""
        if not self.use_cache:
            return
        try:
            cache_path = self._get_cache_path(key)
            cache_path.write_text(json.dumps(data))
        except OSError:
            pass  # Ignore cache write errors

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type((httpx.HTTPStatusError, httpx.TransportError)),
        reraise=True,
    )
    async def _fetch_url(self, url: str) -> httpx.Response:
        """Fetch URL with retry logic."""
        client = await self._get_client()
        if self._semaphore is None:
            self._semaphore = asyncio.Semaphore(self.MAX_CONCURRENT)
        async with self._semaphore:
            response = await client.get(url)
            response.raise_for_status()
            return response

    async def _extract_metadata_from_wheel(self, wheel_url: str) -> list[str]:
        """Download wheel and extract Requires-Dist from METADATA file."""
        try:
            response = await self._fetch_url(wheel_url)
            with zipfile.ZipFile(io.BytesIO(response.content)) as wheel:
                for name in wheel.namelist():
                    if name.endswith(".dist-info/METADATA"):
                        metadata_content = wheel.read(name).decode("utf-8")
                        requires = []
                        for line in metadata_content.split("\n"):
                            if line.startswith("Requires-Dist:"):
                                req = line.replace("Requires-Dist:", "").strip()
                                requires.append(req)
                        return requires
            return []
        except Exception as e:
            if self.verbose:
                logger.warning(f"Failed to extract metadata from wheel: {e}")
            return []

    async def _extract_metadata_from_sdist(self, sdist_url: str) -> list[str]:
        """Download sdist and extract dependencies from PKG-INFO or requires.txt."""
        try:
            response = await self._fetch_url(sdist_url)
            with tarfile.open(fileobj=io.BytesIO(response.content), mode="r:gz") as tar:
                requires: list[str] = []
                for member in tar.getmembers():
                    if member.name.endswith("/PKG-INFO") or member.name.endswith("/METADATA"):
                        f = tar.extractfile(member)
                        if f is None:
                            continue
                        content = f.read().decode("utf-8")
                        for line in content.split("\n"):
                            if line.startswith("Requires-Dist:"):
                                req = line.replace("Requires-Dist:", "").strip()
                                requires.append(req)
                        if requires:
                            return requires

                    if member.name.endswith(".egg-info/requires.txt"):
                        f = tar.extractfile(member)
                        if f is None:
                            continue
                        content = f.read().decode("utf-8")
                        for line in content.split("\n"):
                            line = line.strip()
                            if line and not line.startswith("["):
                                requires.append(line)
                        if requires:
                            return requires
                return requires
        except Exception as e:
            if self.verbose:
                logger.warning(f"Failed to extract metadata from sdist: {e}")
            return []

    async def get_package_info(
        self,
        package_name: str,
        version: str | None = None,
    ) -> PackageInfo | None:
        """Get package info from PyPI. If version is None, gets latest."""
        # First, get latest version if not specified
        if version is None:
            url = f"https://pypi.org/pypi/{package_name}/json"
            try:
                response = await self._fetch_url(url)
                data = response.json()
                version = data["info"]["version"]
            except Exception as e:
                if self.verbose:
                    logger.warning(f"Failed to fetch {package_name}: {e}")
                return None

        # Now fetch version-specific metadata
        cache_key = f"{package_name}:{version}"

        if cache_key in self._memory_cache:
            data = self._memory_cache[cache_key]
        else:
            # Try disk cache first
            data = self._load_from_disk_cache(cache_key)
            if data is None:
                url = f"https://pypi.org/pypi/{package_name}/{version}/json"
                try:
                    response = await self._fetch_url(url)
                    data = response.json()
                    self._save_to_disk_cache(cache_key, data)
                except Exception as e:
                    if self.verbose:
                        logger.warning(f"Failed to fetch {package_name} {version}: {e}")
                    return None
            self._memory_cache[cache_key] = data

        # Parse release info
        urls = data.get("urls", [])
        if not urls:
            if self.verbose:
                logger.warning(f"No release files found for {package_name} {version}")
            return None

        # Parse release date
        upload_time = urls[0]["upload_time_iso_8601"]
        release_date = datetime.fromisoformat(upload_time.replace("Z", "+00:00"))

        # Get dependencies
        requires_dist = data.get("info", {}).get("requires_dist")

        # If requires_dist is not available in JSON, extract from wheel or sdist
        if not requires_dist:
            wheel_url = None
            sdist_url = None

            for url_info in urls:
                if url_info["packagetype"] == "bdist_wheel":
                    wheel_url = url_info["url"]
                elif url_info["packagetype"] == "sdist":
                    sdist_url = url_info["url"]

            if wheel_url:
                if self.verbose:
                    logger.debug(f"Extracting metadata from wheel for {package_name} {version}")
                requires_dist = await self._extract_metadata_from_wheel(wheel_url)
            elif sdist_url:
                if self.verbose:
                    logger.debug(f"Extracting metadata from sdist for {package_name} {version}")
                requires_dist = await self._extract_metadata_from_sdist(sdist_url)
            else:
                requires_dist = []

        if requires_dist is None:
            requires_dist = []

        return PackageInfo(
            name=data["info"]["name"],
            version=version,
            release_date=release_date,
            requires_dist=requires_dist,
        )

    async def get_packages_parallel(
        self,
        requirements: list[tuple[str, str | None]],
    ) -> dict[str, PackageInfo]:
        """Fetch multiple packages concurrently. Returns map of lowercase name -> info."""
        tasks = [self.get_package_info(name, version) for name, version in requirements]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        pkg_map: dict[str, PackageInfo] = {}
        for (name, _), result in zip(requirements, results):
            if isinstance(result, PackageInfo):
                pkg_map[result.name.lower()] = result
            elif isinstance(result, Exception) and self.verbose:
                logger.warning(f"Failed to fetch {name}: {result}")
        return pkg_map

    async def close(self) -> None:
        """Close HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
