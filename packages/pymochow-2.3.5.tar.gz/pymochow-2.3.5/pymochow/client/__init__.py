"""
This module defines some constants for Client
"""

URL_PREFIX = b"/"
URL_VERSION = b"v1"
