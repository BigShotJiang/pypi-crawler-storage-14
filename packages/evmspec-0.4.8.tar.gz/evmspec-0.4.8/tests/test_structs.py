from evmspec import *
from evmspec.structs import *


def test_imports():
    """We have no tests right now but we can at least make sure imports work."""
