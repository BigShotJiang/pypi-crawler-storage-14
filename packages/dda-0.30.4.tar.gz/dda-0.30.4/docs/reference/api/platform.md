# Platform utilities reference

-----

::: dda.utils.platform
    options:
      show_if_no_docstring: false
      show_root_heading: false
      show_root_toc_entry: false
