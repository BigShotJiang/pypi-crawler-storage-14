# Telemetry reference

-----

::: dda.telemetry.manager.TelemetryManager
    options:
      members:
      - enabled
      - log
      - trace

::: dda.telemetry.writers.log.LogTelemetryWriter
    options:
      members:
      - write

::: dda.telemetry.writers.trace.TraceTelemetryWriter
    options:
      members:
      - span
