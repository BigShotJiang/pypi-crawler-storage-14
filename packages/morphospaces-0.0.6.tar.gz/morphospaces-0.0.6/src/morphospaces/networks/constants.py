# dataset key for the ViT autoencoder augmentation views 1 and 2
VIT_AC_AUG_VIEW_1_KEY = "image"
VIT_AC_AUG_VIEW_2_KEY = "image_2"

# dataset key for the Vit autoencoder ground truth image
VIT_AC_GT_KEY = "gt_image"
