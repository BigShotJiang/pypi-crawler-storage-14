from morphospaces.networks.semantic_multiscale import (
    MultiscaleSemanticSegmentationNet,
)

__all__ = ["MultiscaleSemanticSegmentationNet"]
