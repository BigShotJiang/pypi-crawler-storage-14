## Changelog 

### Improved

- If you upload a RAW table in csv or parquet format and specify which
column to use for key using `cdf data upload dir`, Toolkit now validates
that the column is in csv/parquet file.