# part of:
#   S C R I P T U M 
#

from .tag import Tag, getReTag, getTag, createTag

__all__ = [ 'Tag', 'getTag', 'getReTag', 'createTag']