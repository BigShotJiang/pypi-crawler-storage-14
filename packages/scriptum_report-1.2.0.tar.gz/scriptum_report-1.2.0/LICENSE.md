# License

This project is dual-licensed:

- **Non-commercial use:** PolyForm Noncommercial License 1.0.0  
  SPDX-Identifier: `PolyForm-Noncommercial-1.0.0`
- **Commercial use:** Separate commercial license  
  SPDX-Identifier: `LicenseRef-SCRIPTUM-Commercial`

See:

- [`LICENSES/PolyForm-Noncommercial-1.0.0.md`](LICENSES/PolyForm-Noncommercial-1.0.0.md)
- [`LICENSES/Commercial.md`](LICENSES/Commercial.md)

If you are unsure whether your use is commercial, please contact the author.

Copyright (c) 2020 - 2026 Thomas EMMEL <temmel007@gmail.com>