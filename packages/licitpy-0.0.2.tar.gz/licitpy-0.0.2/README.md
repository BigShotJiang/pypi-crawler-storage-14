# Licitpy SDK

🚧 **Official Placeholder**

This package is reserved for the **Licitpy Engine SDK**, powered by [Oportunia](https://oportunia.com).

The official client will be released soon.
