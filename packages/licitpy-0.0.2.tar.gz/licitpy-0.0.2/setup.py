from setuptools import setup, find_packages

setup(
    name="licitpy",
    version="0.0.2",
    author="Oportunia Team",
    description="Official Python Client for Licitpy Engine",
    packages=find_packages(),
)
