import pandas as pd
from ..exceptions import ColumnValidationError

def validate_unique(series: pd.Series, column_name: str):
    """
    Ensure values in series are unique (ignores nulls).
    Raises ColumnValidationError with sample duplicate rows.
    """
    if series is None:
        raise ColumnValidationError(column_name, "column missing", sample=[])
    # Consider only non-null values for uniqueness
    non_null = series.dropna()
    dup_mask = non_null.duplicated(keep=False)
    if dup_mask.any():
        dup_values = non_null[dup_mask].head(10).tolist()
        raise ColumnValidationError(column_name, "duplicate values found", sample=dup_values)
