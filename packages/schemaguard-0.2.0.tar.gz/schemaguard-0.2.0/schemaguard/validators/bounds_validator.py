import pandas as pd
from ..exceptions import ColumnValidationError
from typing import Optional

def validate_min(series: pd.Series, min_value: Optional[float], column_name: str):
    if min_value is None:
        return
    if series is None:
        raise ColumnValidationError(column_name, "column missing", sample=[])
    # Compare only on non-null numeric-friendly values
    try:
        mask = series < min_value
    except Exception:
        # If comparison fails due to types, show offending sample
        sample = series[~series.apply(lambda v: pd.isna(v) or isinstance(v, (int, float)))].head(10).tolist()
        raise ColumnValidationError(column_name, f"cannot compare values with min {min_value}", sample=sample)
    if mask.any():
        sample = series[mask].head(10).tolist()
        raise ColumnValidationError(column_name, f"values below min ({min_value})", sample=sample)

def validate_max(series: pd.Series, max_value: Optional[float], column_name: str):
    if max_value is None:
        return
    if series is None:
        raise ColumnValidationError(column_name, "column missing", sample=[])
    try:
        mask = series > max_value
    except Exception:
        sample = series[~series.apply(lambda v: pd.isna(v) or isinstance(v, (int, float)))].head(10).tolist()
        raise ColumnValidationError(column_name, f"cannot compare values with max {max_value}", sample=sample)
    if mask.any():
        sample = series[mask].head(10).tolist()
        raise ColumnValidationError(column_name, f"values above max ({max_value})", sample=sample)
