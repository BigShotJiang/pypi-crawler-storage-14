import pandas as pd
from ..exceptions import ColumnValidationError

def validate_not_null(series: pd.Series, column_name: str):
    """Raise if any value is null/NaN in series."""
    if series is None:
        raise ColumnValidationError(column_name, "column missing", sample=[])
    null_mask = series.isnull()
    if null_mask.any():
        sample = series[null_mask].head(10).tolist()
        raise ColumnValidationError(column_name, "null values present", sample=sample)
