class ValidationError(Exception):
    """Raised when schema validation fails for the dataframe as a whole."""

class ColumnValidationError(ValidationError):
    """
    Raised when a particular column fails validation.
    Attributes:
        column: name of the column
        reason: short reason string
        sample: a small sample of offending values (list)
    """
    def __init__(self, column: str, reason: str, sample=None):
        self.column = column
        self.reason = reason
        self.sample = sample or []
        message = f"Validation failed for column '{column}': {reason}."
        if self.sample:
            message += f" Sample offending values: {self.sample}"
        super().__init__(message)

class SchemaVersionError(Exception):
    """Errors related to schema versioning / compatibility."""
