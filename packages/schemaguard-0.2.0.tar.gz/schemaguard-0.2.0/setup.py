from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    description = fh.read()

setup(
    name="schemaguard",
    version="0.2.0",
    author="Inzamam Yousaf",
    author_email="uniprecisionofficial@gmail.com",
    description="Lightweight Schema Validator",
    url="https://github.com/inzamam1121/schemaguard",
    packages=find_packages(exclude=["examples*", "tests*"]),
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.0",
        "pyyaml>=6.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    long_description = description,
    long_description_content_type = "text/markdown",
)
