import os

environment = os.getenv("NODE_ENVIRONMENT", "dev")
region = os.getenv("AWS_DEFAULT_REGION", "us-east-1")

ssmParameter = {
    "tokenSSM": {
        "awsEnvt": environment,
        "awsRegion": region,
        "ssmMap": [
            {"Name": "Token/SigningKey", "Value": "SigningKey"},
            {"Name": "Token/Issuer", "Value": "Issuer"},
            {"Name": "Token/Audience", "Value": "Audience"},
            {"Name": "IdObfuscation/MinHashLength", "Value": "MinHashLength"},
            {"Name": "IdObfuscation/Salt", "Value": "Salt"},
        ]
    },
    "refreshTokenSSM": {
        "awsEnvt": environment,
        "awsRegion": region,
        "ssmMap": [
            {"Name": "RefreshToken/SigningKey", "Value": "SigningKey"}
        ]
    },
    "idObfuscationSSM": {
        "awsEnvt": environment,
        "awsRegion": region,
        "ssmMap": [
            {"Name": "IdObfuscation/MinHashLength", "Value": "MinHashLength"},
            {"Name": "IdObfuscation/Salt", "Value": "Salt"}
        ]
    }
}
