# Pre-Requisites to publish as pypi project
Always bump the version in pyproject.toml else it will throw an exception at the time of publishing!!

1. In case of updates to the existing code - change the minor version in pyproject.toml.(increment the minor version i.e 1.0.0 will be 1.0.1)

2. In case of a new feature - change the major version in pyproject.toml.(increment the major version i.e 1.0.1 becomes 2.0.0)


4. Following are the credentials required to publish pypi package -

   Full Name : Aurionpro Solutions
   Public Email : trekket2021@gmail.com
   Username : __token__
   Token: ""

   Library name - aurocx-common


   Make Sure you have .pypirc file exist in application







