## Step 1 – Prepare a clean environment

From the project root (where pyproject.toml lives):

`rm -rf build dist *.egg-info`

Create a fresh virtualenv:

```
python -m venv .venv  # or conda create -n test-host python=3.9
source .venv/bin/activate  # on Windows: .venv\Scripts\activate
python -m pip install --upgrade pip
pip install .[dev]
```

## Step 2 – Install build and upload tools
`python -m pip install --upgrade build twine`
`python -m build`

### Uninstall any old version (just to be sure):
`python -m pip uninstall -y host-picker`

### Install from the freshly built wheel:
`python -m pip install dist/host_picker-*.whl`

### Test imports:
`python - << 'EOF'`
