# Initialize the Higher Order STatistics picker
__author__ = "Matteo Bagagli"
__date__ = "11/2025"
__version__ = "2.5.0"
