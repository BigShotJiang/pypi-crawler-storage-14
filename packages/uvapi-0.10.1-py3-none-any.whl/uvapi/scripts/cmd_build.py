"""构建应用的 worker 目录"""

import argparse
import os
import platform
import shutil
import subprocess
import sys
import zipapp
from pathlib import Path

from ..modules import VenvLibsModeType

from .cli_config import (
    APP_CONFIG_FILE,
    BUILD_CYTHON_DIR,
    BUILD_DIR,
    MAIN_MODULE_FILE,
    copy_tree,
    load_configs,
    logger,
)

# 排除的库列表（前缀匹配）
EXCLUDED_LIBS = [
    'cython',
    'fastapi',
    'numpy',
    'pydantic',
    'pyserial',
    'pyvisa',
    'pyvisa-py',
    'pyzmq',
    'scipy',
    'sqlmodel',
    'ultraview-app-sdk',
    'uvicorn',
    'httpx',
    'pyinstaller',
    '_pytest',
    'pytest',
    'pytest-cov',
    'ruff',
    'viztracer',
    'objprint',
    'sqlalchemy',
    'zmq',
    'uv_messagebus',
    'websockets',
    'ormsgpack',
    'coverage',
    'anyio',
    'starlette',
    'hatchling',
    '_pyinstaller_hooks_contrib',
]


def compile_with_cython(source_dir: Path, enable_upx: bool, upx_path: str) -> bool:
    """使用 Cython 编译 Python 文件.

    使用 Cython.Build.cythonize API 进行编译。

    Args:
        source_dir: 源代码目录
        enable_upx: 是否启用 UPX 压缩
        upx_path: UPX 可执行文件路径

    Returns:
        bool: 编译是否成功
    """
    try:
        from Cython.Build import cythonize
    except ImportError:
        logger.warning('Cython not installed, skipping compilation')
        return False

    logger.info('Starting Cython compilation...')
    logger.indent()

    # 收集所有需要编译的 .py 文件
    py_files = []
    for root, dirs, files in os.walk(source_dir):
        # 排除 __pycache__
        dirs[:] = [d for d in dirs if d != '__pycache__']

        for file in files:
            if file.endswith('.py') and file not in ['__init__.py', MAIN_MODULE_FILE]:
                py_file = Path(root) / file
                py_files.append(py_file)

    if not py_files:
        logger.info('No Python files found to compile')
        logger.dedent()
        return True

    # 为每个文件生成临时 setup.py 并编译
    compiled_files = []
    for py_file in py_files:
        try:
            logger.info(f'Compiling: {py_file.absolute()}')

            # 创建临时 setup.py
            setup_content = f'''
from setuptools import setup, Extension
from Cython.Build import cythonize

extensions = [Extension("*", ["{py_file.absolute()}"])]

setup(
    ext_modules=cythonize(extensions, compiler_directives={{'language_level': "3"}})
)
'''
            setup_file = py_file.parent / '_temp_setup.py'
            setup_file.write_text(setup_content, encoding='utf-8')

            # 编译
            result = subprocess.run(
                [sys.executable, str(setup_file), 'build_ext', '--inplace'],
                # cwd=str(py_file.parent),
                capture_output=True,
                text=True,
            )

            # 清理临时文件
            setup_file.unlink(missing_ok=True)

            if result.returncode != 0:
                logger.warning(f'Cython compilation failed: {result.stderr[:200]}')
                continue

            # 检查是否生成了扩展模块
            ext_suffix = '.pyd' if platform.system() == 'Windows' else '.so'
            ext_files = list(py_file.parent.glob(f'{py_file.stem}*{ext_suffix}'))

            if ext_files:
                # 编译成功，删除源文件和中间文件
                py_file.unlink()
                c_file = py_file.with_suffix('.c')
                c_file.unlink(missing_ok=True)
                # 清理 build 目录
                build_dir = py_file.parent / 'build'
                if build_dir.exists():
                    shutil.rmtree(build_dir)

                compiled_files.append(py_file)
                logger.success(f'Compiled: {py_file.name}')
            else:
                logger.warning(f'No extension module generated: {py_file.name}')

        except Exception as e:
            logger.warning(f'Failed to compile {py_file.name}: {e}')
            continue

    if len(compiled_files) != len(py_files):
        logger.warning(
            f'Failed to compile {len(py_files) - len(compiled_files)} files, will use source files'
        )
        logger.dedent()
        return False

    # UPX 压缩
    if enable_upx and compiled_files:
        logger.info('Starting UPX compression...')
        upx_cmd = upx_path if upx_path else 'upx'

        # 查找所有编译生成的二进制文件
        binary_ext = '.pyd' if platform.system() == 'Windows' else '.so'
        binary_files = list(source_dir.rglob(f'*{binary_ext}'))

        for binary_file in binary_files:
            try:
                logger.info(f'Compressing: {binary_file.relative_to(source_dir)}')
                subprocess.run(
                    [upx_cmd, '--best', str(binary_file)],
                    check=True,
                    capture_output=True,
                )
                logger.success(f'Compressed: {binary_file.name}')
            except subprocess.CalledProcessError:
                logger.warning(f'Failed to compress {binary_file.name}')
            except FileNotFoundError:
                logger.warning(f'UPX tool not found: {upx_cmd}')
                break

    logger.success(f'Cython compilation completed: {len(compiled_files)} files compiled')
    logger.dedent()
    return True


def cmd_build(args: argparse.Namespace) -> None:  # noqa: ANN001, ARG001
    """执行 build 命令.

    Args:
        args: 命令行参数
    """
    logger.set_stage('BUILD')
    logger.info('Starting application build...')

    # 加载配置
    logger.set_stage('CONFIG')
    logger.info('Loading configurations...')
    app_config, _, build_config = load_configs()
    logger.success('Configurations loaded')

    # 删除并重建 build 目录
    logger.set_stage('SETUP')
    build_path = Path(BUILD_DIR)
    if build_path.exists():
        logger.info(f'Removing existing {BUILD_DIR}/ directory...')
        shutil.rmtree(build_path)

    logger.info(f'Creating {BUILD_DIR}/ directory structure...')
    build_path.mkdir(parents=True, exist_ok=True)
    worker_path = build_path / 'worker'
    worker_path.mkdir(parents=True, exist_ok=True)
    data_path = worker_path / 'data'
    data_path.mkdir(parents=True, exist_ok=True)
    logger.success(f'Directory structure created: {build_path.absolute()}')

    # 处理 backend
    backend_path = Path(build_config.info.backend_path)
    if backend_path.exists() and backend_path.is_dir():
        logger.set_stage('BACKEND')
        logger.info(f'Processing backend code: {backend_path.absolute()}')

        source_for_pyz = backend_path

        # Cython 编译
        if build_config.python.enable_cython:
            logger.info('Cython compilation enabled')
            cython_path = Path(BUILD_CYTHON_DIR)

            # 清理并创建临时目录
            if cython_path.exists():
                shutil.rmtree(cython_path)
            cython_path.mkdir(parents=True, exist_ok=True)

            # 拷贝源码到临时目录
            logger.info(f'Copying source to {BUILD_CYTHON_DIR}/...')
            copy_tree(backend_path, cython_path)

            # 编译
            compile_success = compile_with_cython(
                cython_path,
                build_config.python.enable_upx,
                build_config.python.upx_path,
            )

            if compile_success:
                source_for_pyz = cython_path
            else:
                logger.warning('Cython compilation failed, using original source code')

        # 打包为 pyz
        app_name = app_config.name
        app_id = app_config.id
        pyz_name = f'{app_name}_{app_id}.pyz'
        pyz_path = worker_path / pyz_name

        logger.info(f'Creating .pyz archive: {pyz_name}')
        try:
            # 创建临时目录用于组织 pyz 结构
            temp_pyz_dir = Path('_temp_pyz')
            if temp_pyz_dir.exists():
                shutil.rmtree(temp_pyz_dir)
            temp_pyz_dir.mkdir(parents=True, exist_ok=True)

            # 获取 backend_path 的目录名
            backend_dir_name = backend_path.name

            # 将源代码复制到临时目录下，保持目录名
            target_backend_dir = temp_pyz_dir / backend_dir_name
            logger.info(f'Copying source to temporary pyz directory: {backend_dir_name}/')
            copy_tree(source_for_pyz, target_backend_dir, ignore_patterns=['__pycache__'])

            # 从 main.py 读取内容，创建 __main__.py
            main_file = source_for_pyz / MAIN_MODULE_FILE
            if main_file.exists():
                main_content = main_file.read_text(encoding='utf-8')
                # 修改 import 路径，因为现在 backend 是子目录
                # 需要将相对导入改为从 backend_dir_name 导入
                __main__file = temp_pyz_dir / '__main__.py'
                # 使用 LF 换行符
                with open(__main__file, 'w', encoding='utf-8', newline='\n') as f:
                    f.write(main_content)
                logger.success(f'Created __main__.py from {backend_dir_name}/{MAIN_MODULE_FILE}')
            else:
                logger.warning(f'{MAIN_MODULE_FILE} not found in {source_for_pyz.absolute()}')

            # 使用临时目录创建 pyz
            zipapp.create_archive(
                source=str(temp_pyz_dir),
                target=str(pyz_path),
                interpreter='/usr/bin/env python3',
            )
            logger.success(f'Created: {pyz_path.absolute()}')

            # 清理临时 pyz 目录
            shutil.rmtree(temp_pyz_dir)

        except Exception as e:
            logger.error(f'Failed to create .pyz file: {e}')
            # 确保清理临时目录
            if Path('_temp_pyz').exists():
                shutil.rmtree('_temp_pyz')

        # 清理临时目录
        if build_config.python.enable_cython:
            cython_path = Path(BUILD_CYTHON_DIR)
            if cython_path.exists():
                logger.info(f'Cleaning up temporary directory {BUILD_CYTHON_DIR}/')
                shutil.rmtree(cython_path)
    else:
        logger.set_stage('BACKEND')
        logger.warning(f'Backend path invalid, skipping backend packaging: {backend_path.absolute()}')

    # 拷贝 app_config.toml
    logger.set_stage('COPY')
    logger.info(f'Copying {APP_CONFIG_FILE}...')
    config_file = Path(APP_CONFIG_FILE)
    if config_file.exists():
        shutil.copy2(config_file, data_path / APP_CONFIG_FILE)
        logger.success(f'Copied: {config_file.absolute()} -> {(data_path / APP_CONFIG_FILE).absolute()}')

    # 拷贝 include_files
    if build_config.info.include_files:
        logger.info('Copying include_files...')
        logger.indent()
        for file_path in build_config.info.include_files:
            src = Path(file_path)
            if src.exists():
                dst = data_path / src.name
                if src.is_dir():
                    copy_tree(src, dst)
                else:
                    shutil.copy2(src, dst)
                logger.success(f'Copied: {src.absolute()} -> {dst.absolute()}')
            else:
                logger.warning(f'File not found: {src.absolute()}')
        logger.dedent()

    # 拷贝依赖库
    venv_site_packages = Path('.venv') / 'Lib' / 'site-packages'
    if not venv_site_packages.exists():
        # 尝试 Linux/Mac 路径
        venv_site_packages = Path('.venv') / 'lib'
        if venv_site_packages.exists():
            # 查找 python3.x 目录
            python_dirs = list(venv_site_packages.glob('python3.*'))
            if python_dirs:
                venv_site_packages = python_dirs[0] / 'site-packages'
    venv_libs_path = worker_path / 'venv_libs'
    venv_libs_path.mkdir(parents=True, exist_ok=True)

    if build_config.python.venv_libs_mode is VenvLibsModeType.NONE:
        logger.info('Skipping copying dependencies...')

    elif venv_site_packages.exists():
        logger.info('Copying dependencies...')
        logger.indent()

        excluded_libs = [*EXCLUDED_LIBS, *build_config.python.additional_exclude_venv_libs]
        if build_config.python.venv_libs_mode is VenvLibsModeType.FULL:
            excluded_libs = []
        elif build_config.python.venv_libs_mode is VenvLibsModeType.AUTO:
            excluded_libs = [*EXCLUDED_LIBS, *build_config.python.additional_exclude_venv_libs]
        else:
            logger.error(f'Invalid venv_libs_mode: {build_config.python.venv_libs_mode}')
            sys.exit(1)

        for item in venv_site_packages.iterdir():
            # 跳过元数据和缓存
            if item.name.endswith('.dist-info') or item.name.endswith('.egg-info'):
                continue
            if item.name == '__pycache__':
                continue

            # 检查是否在排除列表中（前缀匹配）
            should_exclude = False
            for excluded in excluded_libs:
                if item.name.lower().startswith(
                    excluded.replace('-', '_').lower()
                ) or item.name.lower().startswith(excluded.replace('_', '-').lower()):
                    should_exclude = True
                    break

            if should_exclude:
                logger.info(f'Excluded: {item.name}')
                continue

            # 拷贝
            dst = venv_libs_path / item.name
            try:
                if item.is_dir():
                    copy_tree(item, dst, ignore_patterns=['__pycache__'])
                else:
                    shutil.copy2(item, dst)
                logger.success(f'Copied: {item.absolute()} -> {dst.absolute()}')
            except Exception as e:
                logger.warning(f'Failed to copy {item.name}: {e}')
        logger.dedent()
    else:
        logger.warning(f'Virtual environment site-packages not found: {venv_site_packages.absolute()}')

    # 拷贝 screenshots
    screenshot_path = Path(build_config.info.screenshot_path)
    screenshots_dst = build_path / 'screenshots'
    screenshots_dst.mkdir(parents=True, exist_ok=True)
    if screenshot_path.exists() and screenshot_path.is_dir():
        logger.info('Copying screenshots...')
        copy_tree(screenshot_path, screenshots_dst)
        logger.success(f'Copied: {screenshot_path.absolute()} -> {screenshots_dst.absolute()}')

    # 拷贝 install_hook
    install_hook_path = Path(build_config.info.install_hook)
    if install_hook_path.exists() and install_hook_path.is_file():
        logger.info('Copying install hook script...')
        hook_dst = build_path / install_hook_path.name
        shutil.copy2(install_hook_path, hook_dst)
        logger.success(f'Copied: {install_hook_path.absolute()} -> {hook_dst.absolute()}')

    # 拷贝 update_note_file
    update_note_path = Path(build_config.info.update_note_file)
    note_dst = build_path / update_note_path.name
    if update_note_path.exists() and update_note_path.is_file():
        logger.info('Copying update note file...')
        shutil.copy2(update_note_path, note_dst)
        logger.success(f'Copied: {update_note_path.absolute()} -> {note_dst.absolute()}')
    else:
        note_dst.touch(exist_ok=True)
        logger.success(f'Created: {note_dst.absolute()}')

    logger.set_stage('BUILD')
    logger.success(f'Build completed! Output directory: {build_path.absolute()}')
