"""打包应用程序为 .uvapp 安装包"""

import re
from typing import Optional
from pathlib import Path
import hashlib
import json
import shutil
import sys
import argparse
from .cli_config import (
    logger,
    load_configs,
    README_FILE,
    BUILD_DIR,
    DIST_DIR,
    get_platform,
    copy_tree,
)
from ..modules import AppConfig, PyProjectConfig, BuildConfig, ManifestModel


def parse_base_language(requires_python: Optional[str]) -> str:
    """从 requires-python 解析基础语言版本.

    Args:
        requires_python: Python版本要求，如 ">=3.13", ">=3.11,<3.14"

    Returns:
        str: 格式化的语言版本，如 "python==3.13"
    """
    if not requires_python:
        return 'python==3.13'

    # 提取版本号
    match = re.search(r'(\d+)\.(\d+)', requires_python)
    if match:
        major, minor = match.groups()
        return f'python=={major}.{minor}'

    return 'python==3.13'


def calculate_checksum(build_dir: Path) -> str:
    """计算 CHECKSUM.

    Args:
        build_dir: build 目录路径

    Returns:
        str: MD5 哈希值
    """
    md5 = hashlib.md5()

    # 递归获取所有文件，排除 venv_libs 和 CHECKSUM
    files = sorted(
        [
            f
            for f in build_dir.rglob('*')
            if f.is_file() and 'venv_libs' not in f.parts and f.name != 'CHECKSUM'
        ]
    )

    for file in files:
        with open(file, 'rb') as f:
            md5.update(f.read())

    return md5.hexdigest()


def create_manifest(
    app_config: AppConfig,
    pyproject_config: PyProjectConfig,
    build_config: BuildConfig,
) -> ManifestModel:
    """创建 manifest.json 数据.

    Args:
        app_config: app_config.toml 配置字典
        pyproject_config: pyproject.toml 配置
        build_config: build 配置

    Returns:
        ManifestModel: manifest 数据模型
    """
    # 读取 README.md
    app_note = ''
    readme_path = Path(README_FILE)
    if readme_path.exists():
        try:
            app_note = readme_path.read_text(encoding='utf-8')
        except Exception as e:
            logger.warning(f'Failed to read {README_FILE}: {e}')

    # 解析 base_language
    base_language = parse_base_language(pyproject_config.project.requires_python)

    # 创建 manifest
    manifest = ManifestModel(
        build_version='v1',
        app_id=app_config.id,
        name=app_config.name,
        author=build_config.info.author,
        version=app_config.version,
        custom=build_config.info.custom,
        description=app_config.description,
        license_type=build_config.info.license_type,
        base_language=base_language,
        tag=build_config.info.tag,
        instrument_type=build_config.info.instrument_type,
        supported_instrument=build_config.info.supported_instrument,
        dependences=build_config.info.dependences,
        app_note=app_note,
    )

    return manifest


def cmd_uvapp(args: argparse.Namespace) -> None:  # noqa: ANN001, ARG001
    """执行 uvapp 命令.

    Args:
        args: 命令行参数
    """
    logger.set_stage('PACKAGE')
    logger.info('Starting application packaging...')

    # 加载配置
    logger.set_stage('CONFIG')
    logger.info('Loading configurations...')
    app_config, pyproject_config, build_config = load_configs()
    logger.success('Configurations loaded')

    # 确认 build 目录存在
    logger.set_stage('VALIDATE')
    build_path = Path(BUILD_DIR)
    if not build_path.exists():
        logger.warning(f'{BUILD_DIR}/ directory not found, please run build command first')
        sys.exit(1)
    logger.success(f'Build directory validated: {build_path.absolute()}')

    # 处理前端
    logger.set_stage('FRONTEND')
    frontend_dst = build_path / 'frontend'
    if frontend_dst.exists():
        logger.info(f'Removing existing {frontend_dst.name}/ directory...')
        shutil.rmtree(frontend_dst)

    frontend_path = Path(build_config.info.frontend_path)
    frontend_dist = frontend_path / 'dist'
    if frontend_dist.exists() and frontend_dist.is_dir():
        logger.info(f'Copying frontend resources: {frontend_dist.absolute()}')
        frontend_dst.mkdir(parents=True, exist_ok=True)
        copy_tree(frontend_dist, frontend_dst)
        logger.success(f'Copied: {frontend_dist.absolute()} -> {frontend_dst.absolute()}')
    else:
        logger.warning(
            f'Frontend dist directory not found, skipping frontend packaging: {frontend_dist.absolute()}'
        )

    # 生成 manifest.json
    logger.set_stage('MANIFEST')
    logger.info('Generating manifest.json...')
    manifest = create_manifest(app_config, pyproject_config, build_config)
    manifest_path = build_path / 'manifest.json'

    # 使用 LF 换行符
    with open(manifest_path, 'w', encoding='utf-8', newline='\n') as f:
        json.dump(manifest.model_dump(exclude_none=True), f, ensure_ascii=False, indent=2)

    logger.success(f'Generated: {manifest_path.absolute()}')

    # 计算 CHECKSUM
    logger.set_stage('CHECKSUM')
    logger.info('Calculating CHECKSUM...')
    checksum = calculate_checksum(build_path)
    checksum_path = build_path / 'CHECKSUM'
    # 使用 LF 换行符
    with open(checksum_path, 'w', encoding='utf-8', newline='\n') as f:
        f.write(checksum)
    logger.success(f'CHECKSUM: {checksum}')
    logger.success(f'Saved to: {checksum_path.absolute()}')

    # 打包为 .uvapp
    logger.set_stage('ARCHIVE')
    dist_path = Path(DIST_DIR)
    dist_path.mkdir(parents=True, exist_ok=True)

    app_name = app_config.name
    app_id = app_config.id
    app_version = app_config.version
    platform_name = get_platform()
    uvapp_name = f'{app_name}_{app_version}_{platform_name}_{app_id}.uvapp'
    uvapp_path = dist_path / uvapp_name

    logger.info(f'Creating .uvapp package: {uvapp_name}')
    shutil.make_archive(
        str(uvapp_path.with_suffix('')),
        'zip',
        root_dir=BUILD_DIR,
    )

    # 重命名为 .uvapp
    zip_path = uvapp_path.with_suffix('.zip')
    if zip_path.exists():
        if uvapp_path.exists():
            uvapp_path.unlink()
        zip_path.rename(uvapp_path)

    logger.success(f'Package created: {uvapp_path.absolute()}')

    logger.set_stage('PACKAGE')
    logger.success(f'Packaging completed! Output file: {uvapp_path.absolute()}')
