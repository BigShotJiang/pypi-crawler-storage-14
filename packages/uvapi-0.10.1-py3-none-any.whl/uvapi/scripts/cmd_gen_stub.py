"""生成 TypeScript 存根文件"""

import argparse
import ast
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Set, Tuple
from typing import List as TypingList

from uvapi import __version__
from .cli_config import load_configs, logger
from ..modules import AppConfig, BuildConfig


@dataclass
class ActionInfo:
    """Action 信息"""

    name: str
    params: TypingList[Tuple[str, str]]  # [(param_name, type_annotation), ...]
    return_type: str
    description: str = ''
    timeout: float | None = None  # 超时时间（秒）


@dataclass
class AttributeInfo:
    """Attribute 信息"""

    name: str
    fields: TypingList[Tuple[str, str, Any]]  # [(field_name, type_annotation, default_value), ...]
    is_base: bool = True  # True: BaseAttrGroup, False: SubAttrGroup


@dataclass
class ModelInfo:
    """Pydantic 模型信息"""

    name: str
    fields: TypingList[Tuple[str, str, Any]]  # [(field_name, type_annotation, default_value), ...]
    docstring: str = ''


class TypeResolver:
    """类型解析和转换器"""

    # Python 到 TypeScript 类型映射
    TYPE_MAP = {
        'str': 'string',
        'int': 'number',
        'float': 'number',
        'bool': 'boolean',
        'None': 'null',
        'Any': 'any',
        'datetime': 'string',
        'date': 'string',
        'time': 'string',
        'TrackedDict': 'Record<string, any>',
        'TrackedList': 'any[]',
    }

    def __init__(self) -> None:
        """初始化类型解析器"""
        self.models: Dict[str, ModelInfo] = {}
        self.imported_types: Set[str] = set()

    def convert_type(self, type_annotation: str) -> str:
        """转换 Python 类型注解到 TypeScript 类型

        Args:
            type_annotation: Python 类型注解字符串

        Returns:
            str: TypeScript 类型字符串
        """
        # 移除空格
        type_annotation = type_annotation.strip()

        # 基本类型映射
        if type_annotation in self.TYPE_MAP:
            return self.TYPE_MAP[type_annotation]

        # Optional[T] -> T | undefined
        if type_annotation.startswith('Optional['):
            inner_type = type_annotation[9:-1]
            return f'{self.convert_type(inner_type)} | undefined'

        # List[T] -> T[]
        if type_annotation.startswith('List['):
            inner_type = type_annotation[5:-1]
            return f'{self.convert_type(inner_type)}[]'

        # Dict[K, V] -> Record<K, V>
        if type_annotation.startswith('Dict['):
            inner = type_annotation[5:-1]
            parts = self._split_type_params(inner)
            if len(parts) == 2:
                key_type = self.convert_type(parts[0])
                value_type = self.convert_type(parts[1])
                return f'Record<{key_type}, {value_type}>'
            return 'Record<string, any>'

        # Tuple[T1, T2, ...] -> [T1, T2, ...]
        if type_annotation.startswith('Tuple['):
            inner = type_annotation[6:-1]
            parts = self._split_type_params(inner)
            converted = [self.convert_type(p) for p in parts]
            return f'[{", ".join(converted)}]'

        # Union[A, B] -> A | B
        if type_annotation.startswith('Union['):
            inner = type_annotation[6:-1]
            parts = self._split_type_params(inner)
            converted = [self.convert_type(p) for p in parts]
            return ' | '.join(converted)

        # 如果是已知的模型，直接返回
        if type_annotation in self.models:
            return type_annotation

        # 默认返回 any
        return 'any'

    def _split_type_params(self, params: str) -> TypingList[str]:
        """分割类型参数（处理嵌套）

        Args:
            params: 类型参数字符串，如 "str, List[int]"

        Returns:
            List[str]: 分割后的参数列表
        """
        result = []
        current = []
        depth = 0

        for char in params:
            if char == '[':
                depth += 1
            elif char == ']':
                depth -= 1
            elif char == ',' and depth == 0:
                result.append(''.join(current).strip())
                current = []
                continue
            current.append(char)

        if current:
            result.append(''.join(current).strip())

        return result

    def convert_default_value(self, value: Any, type_annotation: str) -> str:
        """转换 Python 默认值到 TypeScript 字面量

        Args:
            value: Python 默认值
            type_annotation: 类型注解

        Returns:
            str: TypeScript 字面量字符串
        """
        if value is None:
            return 'undefined'
        elif isinstance(value, bool):
            return 'true' if value else 'false'
        elif isinstance(value, (int, float)):
            return str(value)
        elif isinstance(value, str):
            # 转义字符串
            escaped = value.replace('\\', '\\\\').replace("'", "\\'")
            return f"'{escaped}'"
        elif isinstance(value, dict):
            # 递归处理字典
            items = []
            for k, v in value.items():
                key = k if k.isidentifier() else f'"{k}"'
                val = self.convert_default_value(v, 'any')
                items.append(f'{key}: {val}')
            return '{' + ', '.join(items) + '}'
        elif isinstance(value, list):
            # 递归处理列表
            items = [self.convert_default_value(v, 'any') for v in value]
            return '[' + ', '.join(items) + ']'
        else:
            return 'undefined'


class PythonASTParser:
    """Python AST 解析器"""

    def __init__(self, backend_path: Path) -> None:
        """初始化解析器

        Args:
            backend_path: 后端代码路径
        """
        self.backend_path = backend_path
        self.type_resolver = TypeResolver()
        self.actions: TypingList[ActionInfo] = []
        self.attributes: TypingList[AttributeInfo] = []

    def parse(self) -> Tuple[TypingList[ActionInfo], TypingList[AttributeInfo], Dict[str, ModelInfo]]:
        """解析所有文件

        Returns:
            Tuple[List[ActionInfo], List[AttributeInfo], Dict[str, ModelInfo]]: actions, attributes, models
        """
        logger.info(f'Scanning Python files in: {self.backend_path.absolute()}')

        # 第一遍：收集所有模型定义
        for py_file in self.backend_path.rglob('*.py'):
            if '__pycache__' in str(py_file) or py_file.name == '__init__.py':
                continue

            try:
                self._parse_file_for_models(py_file)
            except Exception as e:
                logger.warning(f'Failed to parse {py_file.name}: {e}')

        # 第二遍：解析 actions 和 attributes
        for py_file in self.backend_path.rglob('*.py'):
            if '__pycache__' in str(py_file) or py_file.name == '__init__.py':
                continue

            try:
                self._parse_file_for_actions_attributes(py_file)
            except Exception as e:
                logger.warning(f'Failed to parse {py_file.name}: {e}')

        logger.success(
            f'Found {len(self.actions)} actions, {len(self.attributes)} attributes '
            f'groups, {len(self.type_resolver.models)} models'
        )

        return self.actions, self.attributes, self.type_resolver.models

    def _parse_file_for_models(self, file_path: Path) -> None:
        """解析文件中的模型定义

        Args:
            file_path: Python 文件路径
        """
        content = file_path.read_text(encoding='utf-8')
        tree = ast.parse(content)

        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                # 检查是否继承自 BaseModel
                is_base_model = any(
                    isinstance(base, ast.Name) and base.id == 'BaseModel' for base in node.bases
                )

                if is_base_model:
                    model_info = self._extract_model_info(node)
                    self.type_resolver.models[model_info.name] = model_info

    def _parse_file_for_actions_attributes(self, file_path: Path) -> None:
        """解析文件中的 actions 和 attributes

        Args:
            file_path: Python 文件路径
        """
        content = file_path.read_text(encoding='utf-8')
        tree = ast.parse(content)

        for node in ast.walk(tree):
            # 解析 actions
            if isinstance(node, ast.FunctionDef):
                for decorator in node.decorator_list:
                    if self._is_action_decorator(decorator):
                        action_info = self._extract_action_info(node, decorator)
                        self.actions.append(action_info)
                        break

            # 解析 attributes
            if isinstance(node, ast.ClassDef):
                # 检查是否继承 BaseAttrGroup 或 SubAttrGroup
                is_base = any(
                    isinstance(base, ast.Name) and base.id == 'BaseAttrGroup' for base in node.bases
                )
                is_sub = any(
                    isinstance(base, ast.Name) and base.id == 'SubAttrGroup' for base in node.bases
                )

                # 如果是 BaseAttrGroup 或 SubAttrGroup，都添加到 attributes
                if is_base or is_sub:
                    # BaseAttrGroup 必须有装饰器，SubAttrGroup 不需要
                    has_decorator = any(self._is_attribute_decorator(d) for d in node.decorator_list)
                    if is_base and has_decorator:
                        attr_info = self._extract_attribute_info(node, is_base)
                        self.attributes.append(attr_info)
                    elif is_sub:
                        attr_info = self._extract_attribute_info(node, is_base)
                        self.attributes.append(attr_info)

    def _is_action_decorator(self, decorator: ast.expr) -> bool:
        """检查是否为 action 装饰器

        Args:
            decorator: 装饰器节点

        Returns:
            bool: 是否为 action 装饰器
        """
        if isinstance(decorator, ast.Call):
            if isinstance(decorator.func, ast.Attribute):
                return decorator.func.attr == 'action'
        return False

    def _is_attribute_decorator(self, decorator: ast.expr) -> bool:
        """检查是否为 register_attributes 装饰器

        Args:
            decorator: 装饰器节点

        Returns:
            bool: 是否为 attribute 装饰器
        """
        if isinstance(decorator, ast.Call):
            if isinstance(decorator.func, ast.Attribute):
                return decorator.func.attr == 'register_attributes'
        return False

    def _extract_action_info(self, func_node: ast.FunctionDef, decorator: ast.Call) -> ActionInfo:
        """提取 action 信息

        Args:
            func_node: 函数节点
            decorator: 装饰器节点

        Returns:
            ActionInfo: action 信息
        """
        # 提取 description 和 timeout
        description = ''
        timeout = None
        for keyword in decorator.keywords:
            if keyword.arg == 'description' and isinstance(keyword.value, ast.Constant):
                description = keyword.value.value
            elif keyword.arg == 'timeout' and isinstance(keyword.value, ast.Constant):
                timeout = keyword.value.value

        # 提取参数
        params = []
        for arg in func_node.args.args:
            if arg.arg == 'self':
                continue
            type_annotation = 'any'
            if arg.annotation:
                type_annotation = ast.unparse(arg.annotation)
            params.append((arg.arg, type_annotation))

        # 提取返回值类型
        return_type = 'any'
        if func_node.returns:
            return_type = ast.unparse(func_node.returns)

        return ActionInfo(
            name=func_node.name,
            params=params,
            return_type=return_type,
            description=description,
            timeout=timeout,
        )

    def _extract_attribute_info(self, class_node: ast.ClassDef, is_base: bool) -> AttributeInfo:
        """提取 attribute 信息

        Args:
            class_node: 类节点
            is_base: 是否为 BaseAttrGroup

        Returns:
            AttributeInfo: attribute 信息
        """
        fields = []

        for node in class_node.body:
            if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                field_name = node.target.id
                type_annotation = ast.unparse(node.annotation)

                # 提取默认值
                default_value = None
                if node.value:
                    default_value = self._extract_default_value(node.value)

                fields.append((field_name, type_annotation, default_value))

        return AttributeInfo(name=class_node.name, fields=fields, is_base=is_base)

    def _extract_model_info(self, class_node: ast.ClassDef) -> ModelInfo:
        """提取模型信息

        Args:
            class_node: 类节点

        Returns:
            ModelInfo: 模型信息
        """
        fields = []
        docstring = ast.get_docstring(class_node) or ''

        for node in class_node.body:
            if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                field_name = node.target.id
                type_annotation = ast.unparse(node.annotation)

                # 提取默认值
                default_value = None
                if node.value:
                    default_value = self._extract_default_value(node.value)

                fields.append((field_name, type_annotation, default_value))

        return ModelInfo(name=class_node.name, fields=fields, docstring=docstring)

    def _extract_default_value(self, node: ast.expr) -> Any:
        """提取默认值

        Args:
            node: AST 节点

        Returns:
            Any: 默认值
        """
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.List):
            return [self._extract_default_value(elt) for elt in node.elts]
        elif isinstance(node, ast.Dict):
            return {
                self._extract_default_value(k): self._extract_default_value(v)
                for k, v in zip(node.keys, node.values)
            }
        elif isinstance(node, ast.Call):
            # 处理 Field(default_factory=...) 等
            if isinstance(node.func, ast.Name) and node.func.id == 'Field':
                for keyword in node.keywords:
                    if keyword.arg == 'default':
                        return self._extract_default_value(keyword.value)
                    elif keyword.arg == 'default_factory':
                        # 尝试简单计算
                        if isinstance(keyword.value, ast.Lambda):
                            # lambda: {...} 或 lambda: [...]
                            return self._extract_default_value(keyword.value.body)
                        elif isinstance(keyword.value, ast.Name):
                            # Field(default_factory=ClassName) - 返回类名用于后续查找
                            return ('_class_ref_', keyword.value.id)
                return None
            # 处理 TrackedDict(...) 或 TrackedList(...)
            if isinstance(node.func, ast.Name):
                if node.func.id == 'TrackedDict' and node.args:
                    return self._extract_default_value(node.args[0])
                elif node.func.id == 'TrackedList' and node.args:
                    return self._extract_default_value(node.args[0])
            return None
        return None


def _model_all_fields_have_defaults(model: ModelInfo) -> bool:
    """检查模型的所有字段是否都有默认值

    Args:
        model: 模型信息

    Returns:
        bool: 所有字段都有默认值返回 True，否则返回 False
    """
    if not model.fields:
        return False

    for field_name, field_type, default_value in model.fields:
        # 如果字段没有默认值，且不是 Optional 类型，则返回 False
        if default_value is None and 'Optional[' not in field_type:
            return False

    return True


def _generate_file_header(
    app_config: AppConfig, build_config: BuildConfig, file_description: str
) -> TypingList[str]:
    """生成文件头注释

    Args:
        app_config: 应用配置
        build_config: 构建配置
        file_description: 文件描述

    Returns:
        List[str]: 文件头注释行列表
    """
    lines = []
    lines.append('/**')
    lines.append(f' * {file_description}')
    lines.append(' *')
    lines.append(f' * Generated at: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append(f' * SDK Version: {__version__}')
    lines.append(f' * App Name: {app_config.name}')
    lines.append(f' * App Version: {app_config.version}')
    lines.append(f' * Author: {build_config.info.author}')
    if app_config.description:
        lines.append(f' * Description: {app_config.description}')
    lines.append(' *')
    lines.append(' * This file is auto-generated. Do not edit manually.')
    lines.append(' */')
    lines.append('')
    return lines


def generate_actions_ts(
    actions: TypingList[ActionInfo],
    models: Dict[str, ModelInfo],
    type_resolver: TypeResolver,
    app_config: AppConfig,
    build_config: BuildConfig,
) -> str:
    """生成 actions.ts 文件内容

    Args:
        actions: action 列表
        models: 模型字典
        type_resolver: 类型解析器
        app_config: 应用配置
        build_config: 构建配置

    Returns:
        str: TypeScript 代码
    """
    lines = []
    need_partial = False

    # 添加文件头注释
    header_lines = _generate_file_header(app_config, build_config, 'Actions API Client')

    # 如果没有 actions，只返回文件头注释
    if not actions:
        return '\n'.join(header_lines)

    # 收集所有使用的模型
    used_models = set()
    for action in actions:
        for _, param_type in action.params:
            if param_type in models:
                used_models.add(param_type)
        if action.return_type in models:
            used_models.add(action.return_type)

    # 递归收集嵌套模型
    to_check = list(used_models)
    while to_check:
        model_name = to_check.pop()
        if model_name not in models:
            continue
        model = models[model_name]
        for _, field_type, _ in model.fields:
            # 简单提取类型名称
            clean_type = field_type.replace('Optional[', '').replace(']', '').replace('List[', '')
            if clean_type in models and clean_type not in used_models:
                used_models.add(clean_type)
                to_check.append(clean_type)

    # 生成模型接口
    for model_name in sorted(used_models):
        if model_name not in models:
            continue
        model = models[model_name]

        if model.docstring:
            lines.append('/**')
            for line in model.docstring.split('\n'):
                lines.append(f' * {line}')
            lines.append(' */')

        lines.append(f'export interface {model_name} {{')

        for field_name, field_type, default_value in model.fields:
            ts_type = type_resolver.convert_type(field_type)
            # Optional 字段添加 ?
            if 'Optional[' in field_type or default_value is None:
                lines.append(f'  {field_name}?: {ts_type}')
            else:
                lines.append(f'  {field_name}: {ts_type}')

        lines.append('}\n')

    # 生成 Client 类
    lines.append('/**')
    lines.append(' * API Client')
    lines.append(' *')
    lines.append(' * Auto-generated from backend actions')
    lines.append(' */')
    lines.append('export class Client extends RestAPIClient {')
    lines.append('  constructor() {')
    lines.append('    super()')
    lines.append('  }\n')

    # 生成每个 action 方法
    for action in actions:
        if action.description:
            lines.append('  /**')
            lines.append(f'   * {action.description}')
            lines.append('   */')

        # 生成参数列表
        param_strs = []
        param_obj_items = []
        for param_name, param_type in action.params:
            # 检查参数类型是否为模型，且该模型所有字段都有默认值
            if param_type in models and _model_all_fields_have_defaults(models[param_type]):
                ts_type = f'DeepPartial<{type_resolver.convert_type(param_type)}>'
                need_partial = True
            else:
                ts_type = type_resolver.convert_type(param_type)
            param_strs.append(f'{param_name}: {ts_type}')
            param_obj_items.append(param_name)

        params_signature = ', '.join(param_strs)
        return_ts_type = type_resolver.convert_type(action.return_type)

        lines.append(f'  async {action.name}({params_signature}) {{')

        # 构建 action 调用
        if action.timeout is not None:
            # 将秒转换为毫秒
            timeout_ms = int(action.timeout * 1000)
            if param_obj_items:
                lines.append(
                    f"    return await this.action<{return_ts_type}>('{action.name}', {{ {', '.join(param_obj_items)} }}, {{"
                )
                lines.append(f"      headers: {{ 'X-UV-Action-Timeout': '{timeout_ms}' }},")
                lines.append('    })')
            else:
                lines.append(
                    f"    return await this.action<{return_ts_type}>('{action.name}', undefined, {{"
                )
                lines.append(f"      headers: {{ 'X-UV-Action-Timeout': '{timeout_ms}' }},")
                lines.append('    })')
        else:
            if param_obj_items:
                lines.append(
                    f"    return await this.action<{return_ts_type}>('{action.name}', {{ {', '.join(param_obj_items)} }})"
                )
            else:
                lines.append(f"    return await this.action<{return_ts_type}>('{action.name}')")

        lines.append('  }\n')

    lines.append('}')

    # 头部导入
    if need_partial:
        header_lines.append("import { RestAPIClient, type DeepPartial } from '@rigol/ui-sdk'\n")
    else:
        header_lines.append("import { RestAPIClient } from '@rigol/ui-sdk'\n")

    header_lines.append('')

    return '\n'.join(header_lines + lines)


def generate_attributes_ts(
    attributes: TypingList[AttributeInfo],
    models: Dict[str, ModelInfo],
    type_resolver: TypeResolver,
    app_config: AppConfig,
    build_config: BuildConfig,
) -> str:
    """生成 attributes.ts 文件内容

    Args:
        attributes: attribute 列表
        models: 模型字典
        type_resolver: 类型解析器
        app_config: 应用配置
        build_config: 构建配置

    Returns:
        str: TypeScript 代码
    """
    lines = []

    # 添加文件头注释
    lines.extend(_generate_file_header(app_config, build_config, 'Attributes Store'))

    # 如果没有 attributes，只返回文件头注释
    if not attributes:
        return '\n'.join(lines)

    # 头部导入
    lines.append("import { storeManager, useAttributeMonitor } from '@rigol/ui-sdk'\n")
    lines.append('')

    # 先生成 SubAttrGroup 接口
    sub_groups = [attr for attr in attributes if not attr.is_base]
    for attr in sub_groups:
        lines.append(f'export interface {attr.name} {{')
        for field_name, field_type, default_value in attr.fields:
            ts_type = type_resolver.convert_type(field_type)
            lines.append(f'  {field_name}: {ts_type}')
        lines.append('}\n')

    # 生成 BaseAttrGroup 接口和 use 函数
    base_groups = [attr for attr in attributes if attr.is_base]
    for attr in base_groups:
        # 生成接口
        lines.append(f'export interface {attr.name} {{')
        for field_name, field_type, default_value in attr.fields:
            ts_type = type_resolver.convert_type(field_type)
            lines.append(f'  {field_name}: {ts_type}')
        lines.append('}\n')

        # 生成 use 函数
        use_func_name = f'use{attr.name.replace("Attributes", "")}'
        lines.append('/**')
        lines.append(f' * Create or get {attr.name} store')
        lines.append(' *')
        lines.append(' * @param appId - Application ID')
        lines.append(' * @param initialState - Optional initial state')
        lines.append(' * @returns Store manager instance')
        lines.append(' */')
        lines.append(f'export const {use_func_name} = (appId?: string, initialState?: {attr.name}) => {{')
        lines.append(f'  const store = storeManager.register<{attr.name}>(')
        lines.append(f"    '{attr.name}',")
        lines.append('    initialState || {')

        # 生成默认值对象
        for field_name, field_type, default_value in attr.fields:
            # 检查是否是类引用（嵌套对象）
            if (
                isinstance(default_value, tuple)
                and len(default_value) == 2
                and default_value[0] == '_class_ref_'
            ):
                class_name = default_value[1]
                # 查找对应的 attribute 定义
                nested_attr = None
                for a in attributes:
                    if a.name == class_name:
                        nested_attr = a
                        break

                if nested_attr:
                    # 展开嵌套对象的默认值
                    lines.append(f'      {field_name}: {{')
                    for nested_field_name, nested_field_type, nested_default_value in nested_attr.fields:
                        nested_ts_value = type_resolver.convert_default_value(
                            nested_default_value, nested_field_type
                        )
                        lines.append(f'        {nested_field_name}: {nested_ts_value},')
                    lines.append('      },')
                else:
                    ts_value = type_resolver.convert_default_value(default_value, field_type)
                    lines.append(f'      {field_name}: {ts_value},')
            else:
                ts_value = type_resolver.convert_default_value(default_value, field_type)
                lines.append(f'      {field_name}: {ts_value},')

        lines.append('    },')
        lines.append('    {}')
        lines.append('  )\n')

        # 添加 useAttributeMonitor 调用
        lines.append('  useAttributeMonitor({')
        lines.append('    appId: appId,')
        lines.append('    store: store,')
        lines.append('  })')
        lines.append('  return store')
        lines.append('}\n')

    return '\n'.join(lines)


def cmd_stub_update(args: argparse.Namespace) -> None:  # noqa: ARG001
    """执行 stub update 命令

    Args:
        args: 命令行参数
    """
    logger.set_stage('STUB')
    logger.info('Starting stub generation...')

    # 加载配置
    logger.set_stage('CONFIG')
    logger.info('Loading configurations...')
    app_config, _, build_config = load_configs()
    logger.success('Configurations loaded')

    # 验证路径
    backend_path = Path(build_config.info.backend_path)
    frontend_path = Path(build_config.info.frontend_path)

    if not backend_path.exists() or not backend_path.is_dir():
        logger.error(f'Backend path not found: {backend_path.absolute()}')
        sys.exit(1)

    if not frontend_path.exists() or not frontend_path.is_dir():
        logger.error(f'Frontend path not found: {frontend_path.absolute()}')
        sys.exit(1)

    logger.success(f'Backend path: {backend_path.absolute()}')
    logger.success(f'Frontend path: {frontend_path.absolute()}')

    # 解析 Python 代码
    logger.set_stage('PARSE')
    logger.info('Parsing Python source files...')

    parser = PythonASTParser(backend_path)
    actions, attributes, models = parser.parse()

    # 将 attributes 类型添加到 type_resolver 中，以便在类型转换时识别
    for attr in attributes:
        if attr.name not in parser.type_resolver.models:
            # 将 AttributeInfo 转换为 ModelInfo 格式
            model_info = ModelInfo(name=attr.name, fields=attr.fields, docstring='')
            parser.type_resolver.models[attr.name] = model_info

    # 生成 TypeScript 代码
    logger.set_stage('GENERATE')
    logger.info('Generating TypeScript stub files...')

    actions_ts = generate_actions_ts(actions, models, parser.type_resolver, app_config, build_config)
    attributes_ts = generate_attributes_ts(
        attributes, models, parser.type_resolver, app_config, build_config
    )

    # 确保目标目录存在
    stub_dir = frontend_path / 'src' / 'stub' / 'self'
    stub_dir.mkdir(parents=True, exist_ok=True)

    # 写入文件（使用 LF 换行符）
    actions_file = stub_dir / 'actions.ts'
    attributes_file = stub_dir / 'attributes.ts'

    with open(actions_file, 'w', encoding='utf-8', newline='\n') as f:
        f.write(actions_ts)
    logger.success(f'Generated: {actions_file.absolute()}')

    with open(attributes_file, 'w', encoding='utf-8', newline='\n') as f:
        f.write(attributes_ts)
    logger.success(f'Generated: {attributes_file.absolute()}')

    logger.set_stage('STUB')
    logger.success('Stub generation completed!')
