"""构建日志器，用于格式化输出构建过程信息."""

import shutil
import sys
import tomllib
import platform
from pathlib import Path
from typing import Optional, Tuple

from ..config import UV_APP_CONFIG
from ..modules import (
    AppConfig,
    BuildConfig,
    BuildInfo,
    BuildPython,
    DependencyInfo,
    PyProjectConfig,
)

# 常量定义
APP_CONFIG_FILE = 'app_config.toml'
PYPROJECT_FILE = 'pyproject.toml'
README_FILE = 'README.md'
MAIN_MODULE_FILE = 'main.py'
BUILD_DIR = 'build'
BUILD_CYTHON_DIR = 'build_cython'
DIST_DIR = 'dist'


class BuildLogger:
    """构建日志器，用于格式化输出构建过程信息."""

    def __init__(self) -> None:
        """初始化日志器."""
        self.current_stage = ''
        self.indent_level = 0

        # 配置 stdout 使用 UTF-8 编码，以支持 Unicode 字符
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except (AttributeError, OSError):
            # 如果 reconfigure 不可用，则回退使用 ASCII 字符
            pass

    def set_stage(self, stage: str) -> None:
        """设置当前构建阶段.

        Args:
            stage: 阶段名称
        """
        self.current_stage = stage
        self.indent_level = 0

    def _format_message(self, message: str, prefix: str = '') -> str:
        """格式化消息.

        Args:
            message: 消息内容
            prefix: 消息前缀

        Returns:
            str: 格式化后的消息
        """
        indent = '  ' * self.indent_level
        stage_tag = f'[{self.current_stage}]' if self.current_stage else ''
        return f'{stage_tag} {indent}{prefix}{message}'

    def _safe_print(self, message: str) -> None:
        """安全地打印消息，处理编码错误.

        Args:
            message: 要打印的消息
        """
        try:
            print(message)
        except UnicodeEncodeError:
            # 如果遇到编码错误，替换 Unicode 字符为 ASCII
            safe_message = message.replace('✓', '[OK]').replace('⚠', '[WARN]').replace('✗', '[ERROR]')
            print(safe_message)

    def info(self, message: str) -> None:
        """输出信息消息.

        Args:
            message: 消息内容
        """
        self._safe_print(self._format_message(message))

    def success(self, message: str) -> None:
        """输出成功消息.

        Args:
            message: 消息内容
        """
        self._safe_print(self._format_message(message, '[OK] '))

    def warning(self, message: str) -> None:
        """输出警告消息.

        Args:
            message: 消息内容
        """
        self._safe_print(self._format_message(message, '[WARN] '))

    def error(self, message: str) -> None:
        """输出错误消息.

        Args:
            message: 消息内容
        """
        self._safe_print(self._format_message(message, '[ERROR] '))

    def indent(self) -> None:
        """增加缩进级别."""
        self.indent_level += 1

    def dedent(self) -> None:
        """减少缩进级别."""
        if self.indent_level > 0:
            self.indent_level -= 1


# 全局日志器实例
logger = BuildLogger()


def load_configs() -> Tuple[AppConfig, PyProjectConfig, BuildConfig]:
    """加载配置文件.

    Returns:
        Tuple[AppConfig, PyProjectConfig, BuildConfig]: app_config, pyproject配置, build配置
    """
    # 加载 app_config.toml
    try:
        with open(APP_CONFIG_FILE, 'rb') as f:
            app_config_dict = tomllib.load(f)
    except FileNotFoundError:
        logger.error(f'File not found: {APP_CONFIG_FILE}')
        sys.exit(1)
    except Exception as e:
        logger.error(f'Failed to read {APP_CONFIG_FILE}: {e}')
        sys.exit(1)

    # 加载 pyproject.toml
    try:
        with open(PYPROJECT_FILE, 'rb') as f:
            pyproject_dict = tomllib.load(f)
            pyproject_config = PyProjectConfig.model_validate(pyproject_dict)
    except FileNotFoundError:
        logger.error(f'File not found: {PYPROJECT_FILE}')
        sys.exit(1)
    except Exception as e:
        logger.error(f'Failed to read {PYPROJECT_FILE}: {e}')
        sys.exit(1)

    # 解析 build 配置
    build_dict = app_config_dict.get('build', {})
    try:
        # 处理 dependences 字段
        build_info_dict = build_dict.get('info', {})
        if 'dependences' in build_info_dict:
            deps = []
            for dep in build_info_dict['dependences']:
                deps.append(DependencyInfo.model_validate(dep))
            build_info_dict['dependences'] = deps

        build_info = BuildInfo.model_validate(build_info_dict)
        build_python = BuildPython.model_validate(build_dict.get('python', {}))
        build_config = BuildConfig(info=build_info, python=build_python)
    except Exception as e:
        logger.error(f'Failed to parse build config: {e}')
        sys.exit(1)

    return UV_APP_CONFIG.app_config, pyproject_config, build_config


def get_platform() -> str:
    """获取平台标识.

    Returns:
        str: 平台标识，如 win_amd64, linux_x86_64
    """
    system = platform.system().lower()
    machine = platform.machine().lower()

    if system == 'windows':
        if machine in ['amd64', 'x86_64']:
            return 'win_amd64'
        elif machine == 'x86':
            return 'win32'
        else:
            return f'win_{machine}'
    elif system == 'linux':
        if machine in ['amd64', 'x86_64']:
            return 'linux_x86_64'
        elif machine in ['aarch64', 'arm64']:
            return 'linux_aarch64'
        else:
            return f'linux_{machine}'
    elif system == 'darwin':
        if machine in ['amd64', 'x86_64']:
            return 'macosx_x86_64'
        elif machine in ['aarch64', 'arm64']:
            return 'macosx_arm64'
        else:
            return f'macosx_{machine}'
    else:
        return f'{system}_{machine}'


def copy_tree(src: Path, dst: Path, ignore_patterns: Optional[list] = None) -> None:
    """递归拷贝文件夹.

    Args:
        src: 源路径
        dst: 目标路径
        ignore_patterns: 忽略的模式列表
    """
    if not src.exists():
        return

    dst.mkdir(parents=True, exist_ok=True)

    if src.is_file():
        shutil.copy2(src, dst / src.name)
        return

    for item in src.iterdir():
        if ignore_patterns:
            if any(pattern in item.name for pattern in ignore_patterns):
                continue

        s = item
        d = dst / item.name

        if s.is_dir():
            copy_tree(s, d, ignore_patterns)
        else:
            shutil.copy2(s, d)
