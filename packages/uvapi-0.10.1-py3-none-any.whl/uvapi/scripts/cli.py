"""UrVerse Core SDK 命令行工具接口."""

import argparse

from .cmd_gen_stub import cmd_stub_update
from .cmd_build import cmd_build
from .cmd_uvapp import cmd_uvapp


def main() -> None:
    """pyuvtools 命令行工具主入口函数."""
    # 动态获取版本号
    try:
        from uvapi import __version__

        version_string = f'pyuvtools (uvapi) {__version__}'
    except Exception:
        version_string = 'pyuvtools (uvapi) unknown'

    parser = argparse.ArgumentParser(
        prog='pyuvtools',
        description='UrVerse Core SDK Command Line Tool',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pyuvtools version              Show version information
  pyuvtools build                Build application in current directory
  pyuvtools uvapp                Package application as .uvapp
        """,
    )

    parser.add_argument(
        '--version',
        action='version',
        version=version_string,
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # version 命令
    subparsers.add_parser('version', help='Show version information')

    # build 命令
    subparsers.add_parser('build', help='Build application in current directory')

    # uvapp 命令
    subparsers.add_parser('uvapp', help='Package application as .uvapp installer')

    # stub 命令
    stub_parser = subparsers.add_parser('stub', help='Generate TypeScript stub files')
    stub_subparsers = stub_parser.add_subparsers(dest='stub_command', help='Stub commands')
    stub_subparsers.add_parser('update', help='Update TypeScript stub files from backend code')

    args = parser.parse_args()

    if args.command == 'version':
        print(version_string)
    elif args.command == 'build':
        cmd_build(args)
    elif args.command == 'uvapp':
        cmd_uvapp(args)
    elif args.command == 'stub':
        if args.stub_command == 'update':
            cmd_stub_update(args)
        else:
            stub_parser.print_help()
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
