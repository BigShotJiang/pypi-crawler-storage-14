"""配置文件加载和日志设置"""

import tomllib
import logging.config

from .modules import UVAppConfig, AppConfig, PyProjectConfig, PyProjectProject


LOG_LEVEL_MAP = {
    'debug': logging.DEBUG,
    'info': logging.INFO,
    'warn': logging.WARNING,
    'error': logging.ERROR,
    'critical': logging.CRITICAL,
    logging.DEBUG: 'debug',
    logging.INFO: 'info',
    logging.WARNING: 'warn',
    logging.ERROR: 'error',
    logging.CRITICAL: 'critical'
}

try:
    with open('pyproject.toml', 'rb') as f:
        _pyproject_dict = tomllib.load(f)
        _PY_CONFIG = PyProjectConfig.model_validate(_pyproject_dict)
except Exception:
    _PY_CONFIG = PyProjectConfig(
        project=PyProjectProject(
            name='',
            version='',
            description='',
        )
    )


try:
    with open('app_config.toml', 'rb') as f:
        _app_dict = tomllib.load(f)
        _APP_CONFIG = AppConfig.model_validate(_app_dict['app-config'])
except Exception:
    _APP_CONFIG = AppConfig(
        id='',
        name='',
        version='',
        description='',
    )

UV_APP_CONFIG = UVAppConfig(app_config=_APP_CONFIG, project_config=_PY_CONFIG)
