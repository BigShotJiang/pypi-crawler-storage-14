"""UVAppService类

Raises:
    RuntimeError: 运行时错误
    any: 任何错误
Returns:
    any: 任何返回值
"""

import inspect
import json
import threading
import time
from threading import Condition
from queue import Queue
from concurrent.futures import Future, ThreadPoolExecutor
from datetime import datetime
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Optional,
    Type,
    Union,
    get_type_hints,
)

from pydantic import ValidationError
from sqlmodel import SQLModel, create_engine
from ..client.client_link import LinkConfig, LinkConnectionState
from ..client.topic_manager import TopicHandler, TopicManager, TopicType

from ..config import UV_APP_CONFIG
from ..logger import get_logger, UV_LOGGER
from ..modules import ActionInfo, ActionRuntimeContext
from .action import ActionParser
from .attribute import BaseAttrGroup

if TYPE_CHECKING:
    from sqlalchemy.engine import Engine

    from ..modules import AppConfig


class UVAppService:
    """UVAppService类"""

    def __init__(self) -> None:
        """初始化UVAppService类"""
        self.config: 'AppConfig' = UV_APP_CONFIG.app_config
        self.service_logger = get_logger(f'{self.config.name}_sdk')
        self.action_parser: ActionParser = ActionParser(self.service_logger)

        # 初始化action映射表，存储已注册的action函数
        self._actions: Dict[str, ActionInfo] = {}
        self._actions_lock = threading.RLock()

        # REP工作线程相关
        self._rep_worker_thread: Optional[threading.Thread] = None
        self._rep_worker_running = False
        self._rep_worker_condition = Condition()
        self._action_completed_event = threading.Event()  # action完成通知事件

        # 线程池配置，用于并发处理REP消息
        self._max_workers = self.config.max_workers if hasattr(self.config, 'max_workers') else 10
        self._thread_pool: Optional[ThreadPoolExecutor] = None
        self._pending_actions: list[ActionRuntimeContext] = []

        self.topic_manager: Optional[TopicManager] = None
        self.rep_topic: Optional[TopicHandler] = None
        self.attribute_topic: Optional[TopicHandler] = None
        self.log_topic: Optional[TopicHandler] = None
        self.db_engine: Optional['Engine'] = None

        db_url: str = self.config.database_addr
        if not db_url:
            db_url = f'sqlite:///{self.config.name}.db'
        if not db_url.startswith('sqlite'):
            raise RuntimeError(f'database_addr must be a sqlite url, not {db_url}')

        db_url = db_url.replace('sqlite:///', '')
        self.db_url = f'sqlite:///{self.config.runtime.platform_app_data / db_url}'

    def _setup_attribute_stream(self) -> None:
        """设置attribute通知器的Stream主题"""
        try:
            from .attribute import BaseAttrGroup

            notifier = BaseAttrGroup.get_notifier()
            notifier.set_stream_topic(self.attribute_topic)
            self.service_logger.debug('set Stream topic for attribute notifier')
        except Exception as e:
            self.service_logger.debug(f'set Stream topic for attribute notifier failed: {e}')

    def run(self) -> None:
        """运行服务"""
        if self.topic_manager is None:
            link_config = LinkConfig(
                worker_id=self.config.id,
                worker_name=self.config.name,
                version=self.config.version,
                server_host=self.config.messagebus_addr,
                heartbeat_interval=20.0,
                heartbeat_timeout=10.0,
                heartbeat_max_missed=1,
            )
            self.topic_manager = TopicManager(link_config, logger=self.service_logger)

            self.topic_manager.start()
            if self.topic_manager.link.state != LinkConnectionState.CONNECTED:
                self.service_logger.debug('not connected to server, cannot start service')
                return
            self.rep_topic = self.topic_manager.register_topic(
                f'FRAMEWORK::CONTROL::{self.config.id}', TopicType.REP
            )

            self.attribute_topic = self.topic_manager.register_topic(
                f'FRAMEWORK::ATTRIBUTE::{self.config.id}', TopicType.STREAM
            )
            self.log_topic = self.topic_manager.register_topic(
                'FRAMEWORK::LOGGING::LOG', TopicType.PUBSUB
            )
            if self.log_topic:
                UV_LOGGER._log_topic = self.log_topic
        if self.topic_manager.link.state != LinkConnectionState.CONNECTED:
            self.service_logger.debug('not connected to server, cannot start service')
            return
        self._start_rep_worker()
        self._setup_attribute_stream()
        self.service_logger.debug('UVAppService started')

        try:
            # 使用带超时的循环join，使得能够响应Ctrl+C
            while self._rep_worker_running and self._rep_worker_thread.is_alive():
                self._rep_worker_thread.join(timeout=1.0)
        except KeyboardInterrupt:
            self.service_logger.debug('received interrupt signal (Ctrl+C), shutting down service...')
            self.shutdown()

        except Exception as e:
            self.service_logger.debug(f'runtime error: {e}')
            self.shutdown()
            raise

    def create_db(self) -> None:
        """创建数据库"""
        if not self.db_engine:
            self.service_logger.debug('start creating database tables ...')
            # 根据配置决定是否启用SQLAlchemy的echo
            db_echo = self.config.database_echo
            self.db_engine = create_engine(self.db_url, echo=db_echo)
            SQLModel.metadata.create_all(self.db_engine)
            self.service_logger.debug(f'Database Link URL: {self.db_url}')
            self.service_logger.debug('Database tables created')

    def _start_rep_worker(self) -> None:
        """启动REP工作线程和线程池"""
        if not self._rep_worker_running:
            self._rep_worker_running = True

            # 初始化线程池
            self._thread_pool = ThreadPoolExecutor(
                max_workers=self._max_workers, thread_name_prefix=f'REP-Worker-{self.config.id}'
            )
            self.service_logger.debug(
                f'REP thread pool created, maximum number of workers: {self._max_workers}'
            )

            # 启动消息接收主线程
            self._rep_worker_thread = threading.Thread(
                target=self._rep_worker_loop, daemon=True, name=f'REP-Receiver-{self.config.id}'
            )
            self._rep_worker_thread.start()
            self.service_logger.debug('REP message receive thread started')

    def _stop_rep_worker(self) -> None:
        """停止REP工作线程和线程池"""
        if self._rep_worker_running:
            self._rep_worker_running = False

            # 停止消息接收主线程
            if self._rep_worker_thread and self._rep_worker_thread.is_alive():
                self._rep_worker_thread.join(timeout=5.0)
            self.service_logger.debug('REP message receive thread stopped')

            # 关闭线程池
            if self._thread_pool:
                self.service_logger.debug('waiting for tasks in thread pool to complete...')
                self._thread_pool.shutdown(wait=True, cancel_futures=False)
                self._thread_pool = None
                self._pending_actions.clear()
                self.service_logger.debug('REP thread pool closed')

    # WebSocket端点已移除，attribute推送现在通过Stream主题实现

    def _rep_worker_loop(self) -> None:
        """REP消息接收循环，使用线程池并发处理消息

        REP模式要求严格的顺序：receive -> send -> receive -> send
        因此需要：
        1. 使用event通知机制，action完成后立即处理
        2. 及时处理已完成的action并发送响应
        3. 保持响应顺序与请求顺序一致
        """
        while self._rep_worker_running:
            try:
                # 优先处理已完成的action（被event唤醒或常规检查）
                self._process_completed_actions()

                # 动态调整超时时间：
                # - 有pending actions时使用短超时(1ms)，以便快速响应action完成
                # - 无pending actions时使用较长超时(50ms)，减少CPU占用
                receive_timeout = 0.001 if self._pending_actions else 0.05
                message = self.rep_topic.receive_message(timeout=receive_timeout)

                if message is None:
                    # 没有新消息，检查是否有action完成或超时
                    self._process_completed_actions()
                    continue

                # 检查消息上下文中是否包含action信息
                if not message.context or not message.context.get('action'):
                    self.service_logger.debug('received message without action context, ignored')
                    continue

                # 提交到线程池处理
                if self._thread_pool:
                    context = ActionRuntimeContext(
                        message=message,
                        timeout=self.config.action_default_timeout,
                    )
                    future = self._thread_pool.submit(self._handle_rep_message, context)
                    context.future = future
                    self._pending_actions.append(context)
                else:
                    self.service_logger.debug('thread pool not initialized, cannot process message')

            except Exception as e:
                self.service_logger.exception(e)
                self.service_logger.debug('REP message receive loop error')

    def _process_completed_actions(self) -> None:
        """处理已完成/已超时的ActionRuntimeContext对象

        REP模式要求严格的FIFO顺序，因此：
        1. 只处理队列头部的action
        2. 如果头部未完成，不处理后续action
        3. 这样保证响应顺序与请求顺序一致
        """
        now = time.time()

        for context in self._pending_actions[:]:
            if context.future.done() and context.result is not None:  # 已完成
                self.rep_topic.send_message(context.result)
                self._pending_actions.remove(context)
            elif context.future.done() and context.future._exception is not None:  # 执行出错
                self._set_error_response(
                    context, f'action {context.action_info.name} failed: {context.future._exception}'
                )
                self.rep_topic.send_message(context.result)
                self._pending_actions.remove(context)
                self.service_logger.debug(
                    f'sent error response for action {context.action_info.name} (exception), '
                    f'remaining pending actions: {len(self._pending_actions)}'
                )
            elif now - context.timestamp >= context.timeout:  # 已超时
                self._set_timeout_response(
                    context,
                    f'action {context.action_info.name} timeout, '
                    f'timeout threshold: {context.timeout}s, '
                    f'actual elapsed: {now - context.timestamp:.2f}s',
                )
                self.rep_topic.send_message(context.result)
                context.future.cancel()
                self._pending_actions.remove(context)
                self.service_logger.debug(
                    f'sent timeout response for action {context.action_info.name}, '
                    f'remaining pending actions: {len(self._pending_actions)}'
                )

    def _handle_rep_message(self, context: ActionRuntimeContext) -> None:
        """处理REP收到的消息并执行对应的action"""
        message = context.message
        try:
            action_name = message.context.get('action')

            if action_name not in self._actions:
                self.service_logger.debug(f'can not find action: {action_name}')
                self._set_not_found_response(context, action_name)
                return

            # 查找对应的action函数
            with self._actions_lock:
                action_info = self._actions[action_name]

            # 执行action函数
            try:
                self.service_logger.debug(f'execute action: {action_name}')

                # 准备函数参数
                action_params = message.context.get('params', {})
                context.params = action_params
                context.action_info = action_info
                context.timeout = action_info.timeout
                result = self._execute_action(context)

                # 发送成功响应
                self._set_success_response(context, result)
                self.service_logger.debug(f'action {action_name} executed successfully')

            except ValidationError as e:
                self.service_logger.debug(f'action {action_name} parameters validation failed: {e}')
                self._set_validation_error_response(context, str(e))
            except Exception as e:
                self.service_logger.exception(e)
                self.service_logger.debug(f'execute action {action_name} failed')
                self._set_error_response(context, f'execute action {action_name} failed: {str(e)}')

        except Exception as e:
            self.service_logger.exception(e)
            self.service_logger.debug(f'handle REP message failed: {e}')
            try:
                self._set_error_response(context, f'handle REP message failed: {str(e)}')
            except Exception:
                pass  # send error response failed, avoid infinite loop

    def _execute_action(self, context: ActionRuntimeContext) -> Any:
        """执行action函数，仿照FastAPI的方式处理参数"""
        try:
            # 获取函数签名和类型注解
            sig = context.action_info.func_signature
            type_hints = context.action_info.func_type_hints
            params = context.params

            # 准备函数参数
            func_params = {}
            validation_errors = []

            for param_name, param in sig.parameters.items():
                param_type = type_hints.get(param_name, Any)
                param_value = params.get(param_name)

                try:
                    # 处理参数值
                    if param_value is not None:
                        # 转换和验证参数
                        converted_value = self.action_parser.convert_and_validate_param(
                            param_name, param_value, param_type
                        )
                        func_params[param_name] = converted_value
                    elif param.default is not param.empty:
                        # 使用默认值
                        func_params[param_name] = param.default
                    elif self.action_parser._is_optional_type(param_type):
                        # 可选类型，使用None
                        func_params[param_name] = None
                    else:
                        # 必需参数但未提供
                        validation_errors.append(f'missing required parameter: {param_name}')

                except Exception as e:
                    validation_errors.append(f'parameter {param_name} validation failed: {str(e)}')

            # 如果有验证错误，抛出异常
            if validation_errors:
                raise ValueError(f'parameters validation failed: {"; ".join(validation_errors)}')

            # 调用函数
            result = context.action_info.func(**func_params)

            # 处理返回值序列化
            return self.action_parser.serialize_result(result)

        except ValidationError:
            raise  # 重新抛出 Pydantic 模型验证错误
        except Exception as e:
            self.service_logger.exception(e)
            raise RuntimeError(f'execute action {context.action_info.name} failed: {str(e)}') from e

    def _set_success_response(self, context: ActionRuntimeContext, result: Any) -> None:
        """设置成功响应"""
        try:
            response_context = {
                'status': 'success',
                'result': result,
                'timestamp': datetime.now().isoformat(),
            }

            # 如果结果包含不能序列化的对象，尝试转换
            try:
                json.dumps(response_context)
            except (TypeError, ValueError):
                # 序列化失败，将结果转为字符串
                response_context['result'] = str(result)

            response_message = context.message.create_response(response_context)
            context.result = response_message

        except Exception as e:
            self.service_logger.debug(f'set success response failed: {e}')

    def _set_timeout_response(
        self, context: ActionRuntimeContext, error_msg: str, error_code: int = 408
    ) -> None:
        """设置超时响应"""
        try:
            response_context = {
                'status': 'error',
                'error_type': 'TimeoutError',
                'message': f'action timeout: {error_msg}',
                'code': error_code,
                'timestamp': datetime.now().isoformat(),
            }
            error_response = context.message.create_response(response_context)
            context.result = error_response
        except Exception as e:
            self.service_logger.debug(f'set timeout response failed: {e}')

    def _set_validation_error_response(
        self, context: ActionRuntimeContext, error_msg: str, error_code: int = 422
    ) -> None:
        """设置参数验证错误响应，仿照FastAPI的422错误格式"""
        try:
            response_context = {
                'status': 'error',
                'error_type': 'ValidationError',
                'message': f'parameter validation failed: {error_msg}',
                'code': error_code,  # HTTP 422 Unprocessable Entity
                'timestamp': datetime.now().isoformat(),
            }
            error_response = context.message.create_response(response_context)
            context.result = error_response

        except Exception as e:
            self.service_logger.debug(f'set validation error response failed: {e}')

    def _set_error_response(
        self, context: ActionRuntimeContext, error_msg: str, error_code: int = 500
    ) -> None:
        """设置通用错误响应，仿照FastAPI的错误格式"""
        try:
            response_context = {
                'status': 'error',
                'error_type': 'InternalServerError',
                'message': error_msg,
                'code': error_code,
                'timestamp': datetime.now().isoformat(),
            }
            error_response = context.message.create_response(response_context)
            context.result = error_response

        except Exception as e:
            self.service_logger.debug(f'set error response failed: {e}')

    def _set_not_found_response(
        self, context: ActionRuntimeContext, action_name: str, error_code: int = 404
    ) -> None:
        """设置action未找到错误响应"""
        try:
            response_context = {
                'status': 'error',
                'error_type': 'NotFoundError',
                'message': f'Action "{action_name}" not found',
                'code': error_code,
                'timestamp': datetime.now().isoformat(),
            }
            error_response = context.message.create_response(response_context)
            context.result = error_response

        except Exception as e:
            self.service_logger.debug(f'set not found error response failed: {e}')

    def action(
        self,
        *,
        action_name: Optional[str] = None,
        description: Optional[str] = '',
        timeout: Optional[float] = None,
    ) -> Callable[[Callable], Callable]:
        """Action装饰器，仅用于REP消息处理

        可以使用如下方法注册action，通过REP消息调用：

        ```python
        service = UVAppService()

        @service.action()
        def my_action(param1: str, param2: int = 10):
            return {"result": f"处理 {param1} with {param2}"}
        ```

        Args:
            action_name: action名称，如果不提供则使用函数名
            description: action描述
            timeout: action超时时间，单位为秒，如果不提供则使用默认超时时间
        Returns:
            装饰器函数
        """

        def decorator(func: Callable) -> Callable:
            # 确定action名称
            _action_name = action_name or func.__name__
            _timeout = self.config.action_default_timeout if timeout is None else timeout
            # 将action函数注册到内部映射表中，用于REP消息处理
            with self._actions_lock:
                self._actions[_action_name] = ActionInfo(
                    name=_action_name,
                    func_signature=inspect.signature(func),
                    func_type_hints=get_type_hints(func),
                    description=description,
                    func=func,
                    timeout=_timeout,
                )
            return func

        return decorator

    def register_attributes(
        self, group_name: str = ''
    ) -> Callable[[Type[BaseAttrGroup]], Type[BaseAttrGroup]]:
        """注册属性组装饰器

        Args:
            group_name: 属性组名，如果不提供则使用类名

        Returns:
            装饰器函数
        """

        def decorator(cls: Type[BaseAttrGroup]) -> Type[BaseAttrGroup]:
            # 设置组名
            if group_name:
                cls._group_name = group_name
            else:
                cls._group_name = cls.__name__

            # 向通知器注册属性组
            notifier = BaseAttrGroup.get_notifier()
            notifier.register_attribute_group(cls._group_name, cls)

            self.service_logger.debug(f'Registered attribute group: {cls._group_name}')
            return cls

        return decorator

    def load_apis(self) -> None:
        """加载API

        在app_config.toml中配置的API模块会自动导入并注册到UVAppService类中
        """
        from ..apis import internal_api

        self.service_logger.debug('Internal API module imported successfully!')

        import importlib

        apis = self.config.apis

        if not apis:
            self.service_logger.debug('No API modules configured in app_config.toml')
            return

        self.service_logger.debug(f'Start loading API modules: {apis}')

        for view in apis:
            try:
                self.service_logger.debug(f'Import API module: {view}')
                importlib.import_module(view)
            except Exception as e:
                self.service_logger.debug(f'Failed to import API module: {view}, error: {e}')
                raise

        self.service_logger.debug('All API modules loaded')

    def shutdown(self) -> None:
        """关闭服务，清理资源"""
        self.service_logger.debug('starting to shutdown UVAppService...')

        # 停止REP工作线程
        self._stop_rep_worker()

        # 关闭topic manager
        if hasattr(self, 'topic_manager'):
            self.topic_manager.shutdown()

        self.service_logger.debug('UVAppService shut down')

    def __del__(self) -> None:
        """析构函数"""
        try:
            if self._rep_worker_running:
                self.shutdown()
        except Exception:
            pass  # avoid exception during destruction
