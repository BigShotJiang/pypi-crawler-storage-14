"""嵌套属性组支持

提供 SubAttrGroup 类，支持静态的嵌套属性组结构。
子属性变更时会向上冒泡通知到根 AttrGroup。
"""

import copy
from typing import Any, Optional, TYPE_CHECKING
from pydantic import BaseModel

if TYPE_CHECKING:
    from .attribute import BaseAttrGroup


class SubAttrGroup(BaseModel):
    """静态嵌套属性组基类

    用于在 BaseAttrGroup 内部定义嵌套的属性组。
    子属性变更时会自动向上冒泡通知到根属性组。

    注意：
    - SubAttrGroup 不支持整体赋值，只能修改其内部属性
    - 继承自 Pydantic BaseModel，支持类型验证

    示例：
        class UserInfo(SubAttrGroup):
            address: str = "Beijing"
            phone: str = "123456"

        class CurrentUser(BaseAttrGroup):
            name: str = "John"
            info: UserInfo = UserInfo()

        # 正确用法：修改子属性
        user = CurrentUser()
        user.info.address = "Shanghai"  # 触发变更通知

        # 错误用法：整体赋值
        user.info = UserInfo()  # 抛出异常
    """

    # 私有属性，用于维护父子关系
    model_config = {'arbitrary_types_allowed': True}

    def model_post_init(self, __context: Any) -> None:
        """Pydantic 初始化后的钩子，用于设置私有属性"""
        from .tracked_containers import TrackedDict, TrackedList

        # 父对象引用，初始化时为 None，后续由 BaseAttrGroup 设置
        object.__setattr__(self, '_parent', None)
        # 在父对象中的属性路径
        object.__setattr__(self, '_attr_path', '')
        # 标记是否已完成初始化
        object.__setattr__(self, '_initialized', True)

        # 遍历所有字段，为嵌套的 SubAttrGroup/TrackedDict/TrackedList 建立父子关系
        for field_name, field_info in self.__class__.model_fields.items():
            value = getattr(self, field_name, None)
            if value is not None and isinstance(value, (SubAttrGroup, TrackedDict, TrackedList)):
                try:
                    parent = object.__getattribute__(value, '_parent')
                    if parent is None:
                        value._set_parent(self, field_name)
                except AttributeError:
                    value._set_parent(self, field_name)

    def __setattr__(self, name: str, value: Any) -> None:
        """拦截子属性变更，向上冒泡通知

        当子属性发生变更时：
        1. 记录旧值
        2. 设置新值
        3. 通知父对象（如果已建立父子关系）
        """
        # 跳过私有属性
        if name.startswith('_'):
            object.__setattr__(self, name, value)
            return

        # 检查是否已完成初始化
        if not hasattr(self, '_initialized'):
            # 初始化阶段，直接设置值
            super().__setattr__(name, value)
            return

        # 获取旧值
        old_value = getattr(self, name, None) if hasattr(self, name) else None

        # 设置新值
        super().__setattr__(name, value)

        # 如果值发生变化且已建立父子关系，发送通知
        if old_value != value:
            self._notify_parent(name, old_value, value)

    def _notify_parent(self, attr_name: str, old_value: Any, new_value: Any) -> None:
        """通知父对象属性变更

        构建完整的属性路径并通知到根 AttrGroup。

        Args:
            attr_name: 变更的属性名
            old_value: 旧值
            new_value: 新值
        """
        parent = object.__getattribute__(self, '_parent')
        attr_path = object.__getattribute__(self, '_attr_path')

        if parent is None or not attr_path:
            # 尚未建立父子关系，跳过通知
            return

        # 构建完整路径：parent_path.attr_name
        full_path = [attr_path, attr_name]

        # 深拷贝值以避免引用问题
        try:
            old_value_copy = copy.deepcopy(old_value)
            new_value_copy = copy.deepcopy(new_value)
        except Exception:
            # 如果深拷贝失败，使用原值
            old_value_copy = old_value
            new_value_copy = new_value

        new_value_copy = {attr_path: {attr_name: new_value_copy}}

        # 向父对象通知变更
        self._propagate_change_to_root(parent, full_path, old_value_copy, new_value_copy)

    def _propagate_change_to_root(
        self, parent: Any, full_path: list[str], old_value: Any, new_value: Any
    ) -> None:
        """将变更通知传播到根 AttrGroup

        Args:
            parent: 父对象
            full_path: 完整的属性路径
            old_value: 旧值
            new_value: 新值
        """
        from .attribute import BaseAttrGroup

        # 如果父对象是 BaseAttrGroup，直接通知
        if isinstance(parent, BaseAttrGroup):
            group_name = parent._group_name
            if group_name is not None:
                notifier = parent.get_notifier()
                notifier.notify_change(group_name, full_path[0], old_value, new_value[full_path[0]])
        # 如果父对象也是 SubAttrGroup，继续向上传播
        elif isinstance(parent, SubAttrGroup):
            parent_parent = object.__getattribute__(parent, '_parent')
            parent_path = object.__getattribute__(parent, '_attr_path')
            if parent_parent is not None and parent_path:
                # 保持完整的嵌套路径
                new_full_path = [parent_path, *full_path]
                # 将当前值包装到父路径中
                new_value = {parent_path: new_value}
                parent._propagate_change_to_root(parent_parent, new_full_path, old_value, new_value)

    def _set_parent(self, parent: Any, attr_path: str) -> None:
        """设置父对象引用和属性路径

        由 BaseAttrGroup 或父 SubAttrGroup 在初始化时调用。

        Args:
            parent: 父对象引用（可以是 BaseAttrGroup 或 SubAttrGroup）
            attr_path: 在父对象中的属性路径
        """
        object.__setattr__(self, '_parent', parent)
        object.__setattr__(self, '_attr_path', attr_path)
