"""可追踪的容器类

提供 TrackedDict 和 TrackedList，支持动态容器的变更追踪。
容器内部元素变更时会通知父 AttrGroup。
"""

import copy
from typing import Any, Optional, TYPE_CHECKING, Iterable

if TYPE_CHECKING:
    from .attribute import BaseAttrGroup


class TrackedDict(dict):
    """可追踪的字典容器

    继承自 dict，拦截所有修改操作并通知父对象。
    变更时会推送整个 dict 的副本。

    限制：
    - 不支持 update() 方法，只支持 var['key'] = value

    示例：
        class Config(BaseAttrGroup):
            settings: TrackedDict = TrackedDict()

        config = Config()
        config.settings['theme'] = 'dark'  # 触发变更通知
        config.settings['language'] = 'zh'  # 触发变更通知
    """

    def __init__(self, *args, **kwargs) -> None:
        """初始化可追踪字典"""
        super().__init__(*args, **kwargs)
        # 父对象引用，初始化时为 None，后续由 BaseAttrGroup 设置
        object.__setattr__(self, '_parent', None)
        # 在父对象中的属性名
        object.__setattr__(self, '_attr_name', '')

    def __setitem__(self, key: Any, value: Any) -> None:
        """拦截赋值操作，通知父对象

        Args:
            key: 字典键
            value: 字典值
        """
        # 记录旧的字典副本
        old_dict = self._get_dict_copy()

        # 执行赋值操作
        super().__setitem__(key, value)

        # 通知变更
        self._notify_change(old_dict)

    def __delitem__(self, key: Any) -> None:
        """拦截删除操作，通知父对象

        Args:
            key: 要删除的键
        """
        # 记录旧的字典副本
        old_dict = self._get_dict_copy()

        # 执行删除操作
        super().__delitem__(key)

        # 通知变更
        self._notify_change(old_dict)

    def pop(self, key: Any, *args) -> Any:
        """拦截 pop 操作，通知父对象

        Args:
            key: 要弹出的键
            *args: 默认值（可选）

        Returns:
            弹出的值
        """
        # 记录旧的字典副本
        old_dict = self._get_dict_copy()

        # 执行 pop 操作
        result = super().pop(key, *args)

        # 通知变更
        self._notify_change(old_dict)

        return result

    def popitem(self) -> tuple:
        """拦截 popitem 操作，通知父对象

        Returns:
            弹出的键值对
        """
        # 记录旧的字典副本
        old_dict = self._get_dict_copy()

        # 执行 popitem 操作
        result = super().popitem()

        # 通知变更
        self._notify_change(old_dict)

        return result

    def clear(self) -> None:
        """拦截 clear 操作，通知父对象"""
        # 记录旧的字典副本
        old_dict = self._get_dict_copy()

        # 执行 clear 操作
        super().clear()

        # 通知变更
        self._notify_change(old_dict)

    def setdefault(self, key: Any, default: Any = None) -> Any:
        """拦截 setdefault 操作，通知父对象

        Args:
            key: 键
            default: 默认值

        Returns:
            键对应的值
        """
        # 记录旧的字典副本
        old_dict = self._get_dict_copy()

        # 执行 setdefault 操作
        result = super().setdefault(key, default)

        # 只有在实际设置了新键时才通知变更
        if key not in old_dict:
            self._notify_change(old_dict)

        return result

    def update(self, *args, **kwargs) -> None:
        """禁用 update 方法

        Raises:
            NotImplementedError: TrackedDict 不支持 update 方法
        """
        raise NotImplementedError(
            "TrackedDict 不支持 update 方法，请使用 dict['key'] = value 的方式逐个设置"
        )

    def _get_dict_copy(self) -> dict:
        """获取当前字典的深拷贝

        Returns:
            字典的深拷贝
        """
        try:
            return copy.deepcopy(dict(self))
        except Exception:
            # 如果深拷贝失败，使用浅拷贝
            return dict(self).copy()

    def _notify_change(self, old_dict: dict) -> None:
        """通知父对象字典已变更

        Args:
            old_dict: 变更前的字典副本
        """
        parent = object.__getattribute__(self, '_parent')
        attr_name = object.__getattribute__(self, '_attr_name')

        if parent is None or not attr_name:
            # 尚未建立父子关系，跳过通知
            return

        # 获取新的字典副本
        new_dict = self._get_dict_copy()

        # 通知父对象
        from .attribute import BaseAttrGroup
        from .nested_attribute import SubAttrGroup

        if isinstance(parent, BaseAttrGroup):
            group_name = parent._group_name
            if group_name is not None:
                notifier = parent.get_notifier()
                notifier.notify_change(group_name, attr_name, old_dict, new_dict)
        elif isinstance(parent, SubAttrGroup):
            # 如果父对象是 SubAttrGroup，通过其向上传播
            parent._notify_parent(attr_name, old_dict, new_dict)

    def _set_parent(self, parent: 'BaseAttrGroup', attr_name: str) -> None:
        """设置父对象引用和属性名

        由 BaseAttrGroup 在初始化时调用。

        Args:
            parent: 父对象引用
            attr_name: 在父对象中的属性名
        """
        object.__setattr__(self, '_parent', parent)
        object.__setattr__(self, '_attr_name', attr_name)


class TrackedList(list):
    """可追踪的列表容器

    继承自 list，拦截所有修改操作并通知父对象。
    任何元素变更时都会推送整个 list 的副本。

    示例：
        class Items(BaseAttrGroup):
            data: TrackedList = TrackedList()

        items = Items()
        items.data.append('item1')  # 触发变更通知
        items.data[0] = 'item2'     # 触发变更通知
    """

    def __init__(self, *args, **kwargs) -> None:
        """初始化可追踪列表"""
        super().__init__(*args, **kwargs)
        # 父对象引用，初始化时为 None，后续由 BaseAttrGroup 设置
        object.__setattr__(self, '_parent', None)
        # 在父对象中的属性名
        object.__setattr__(self, '_attr_name', '')

    def __setitem__(self, index: Any, value: Any) -> None:
        """拦截赋值操作，通知父对象

        Args:
            index: 索引或切片
            value: 新值
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行赋值操作
        super().__setitem__(index, value)

        # 通知变更
        self._notify_change(old_list)

    def __delitem__(self, index: Any) -> None:
        """拦截删除操作，通知父对象

        Args:
            index: 索引或切片
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行删除操作
        super().__delitem__(index)

        # 通知变更
        self._notify_change(old_list)

    def append(self, value: Any) -> None:
        """拦截 append 操作，通知父对象

        Args:
            value: 要添加的值
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 append 操作
        super().append(value)

        # 通知变更
        self._notify_change(old_list)

    def extend(self, iterable: Iterable[Any]) -> None:
        """拦截 extend 操作，通知父对象

        Args:
            iterable: 可迭代对象
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 extend 操作
        super().extend(iterable)

        # 通知变更
        self._notify_change(old_list)

    def insert(self, index: int, value: Any) -> None:
        """拦截 insert 操作，通知父对象

        Args:
            index: 插入位置
            value: 要插入的值
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 insert 操作
        super().insert(index, value)

        # 通知变更
        self._notify_change(old_list)

    def remove(self, value: Any) -> None:
        """拦截 remove 操作，通知父对象

        Args:
            value: 要移除的值
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 remove 操作
        super().remove(value)

        # 通知变更
        self._notify_change(old_list)

    def pop(self, index: int = -1) -> Any:
        """拦截 pop 操作，通知父对象

        Args:
            index: 要弹出的索引，默认为 -1（最后一个元素）

        Returns:
            弹出的值
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 pop 操作
        result = super().pop(index)

        # 通知变更
        self._notify_change(old_list)

        return result

    def clear(self) -> None:
        """拦截 clear 操作，通知父对象"""
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 clear 操作
        super().clear()

        # 通知变更
        self._notify_change(old_list)

    def sort(self, *args, **kwargs) -> None:
        """拦截 sort 操作，通知父对象

        Args:
            *args: 排序参数
            **kwargs: 排序关键字参数
        """
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 sort 操作
        super().sort(*args, **kwargs)

        # 通知变更
        self._notify_change(old_list)

    def reverse(self) -> None:
        """拦截 reverse 操作，通知父对象"""
        # 记录旧的列表副本
        old_list = self._get_list_copy()

        # 执行 reverse 操作
        super().reverse()

        # 通知变更
        self._notify_change(old_list)

    def _get_list_copy(self) -> list:
        """获取当前列表的深拷贝

        Returns:
            列表的深拷贝
        """
        try:
            return copy.deepcopy(list(self))
        except Exception:
            # 如果深拷贝失败，使用浅拷贝
            return list(self).copy()

    def _notify_change(self, old_list: list) -> None:
        """通知父对象列表已变更

        Args:
            old_list: 变更前的列表副本
        """
        parent = object.__getattribute__(self, '_parent')
        attr_name = object.__getattribute__(self, '_attr_name')

        if parent is None or not attr_name:
            # 尚未建立父子关系，跳过通知
            return

        # 获取新的列表副本
        new_list = self._get_list_copy()

        # 通知父对象
        from .attribute import BaseAttrGroup
        from .nested_attribute import SubAttrGroup

        if isinstance(parent, BaseAttrGroup):
            group_name = parent._group_name
            if group_name is not None:
                notifier = parent.get_notifier()
                notifier.notify_change(group_name, attr_name, old_list, new_list)
        elif isinstance(parent, SubAttrGroup):
            # 如果父对象是 SubAttrGroup，通过其向上传播
            parent._notify_parent(attr_name, old_list, new_list)

    def _set_parent(self, parent: 'BaseAttrGroup', attr_name: str) -> None:
        """设置父对象引用和属性名

        由 BaseAttrGroup 在初始化时调用。

        Args:
            parent: 父对象引用
            attr_name: 在父对象中的属性名
        """
        object.__setattr__(self, '_parent', parent)
        object.__setattr__(self, '_attr_name', attr_name)
