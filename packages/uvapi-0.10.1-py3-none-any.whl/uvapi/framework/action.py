"""Action解析器"""

import inspect
import logging
from datetime import date, datetime, time
from decimal import Decimal
from enum import Enum
from typing import Any, Type, Union, get_args, get_origin

from pydantic import BaseModel, ValidationError


class ActionParser:
    """Action解析器"""

    def __init__(self, service_logger: 'logging.Logger') -> None:
        """初始化Action解析器"""
        self.service_logger = service_logger

    def convert_and_validate_param(self, param_name: str, param_value: Any, param_type: Type) -> Any:
        """转换和验证参数，使用FastAPI同样的解析规则"""
        # 处理None值
        if param_value is None:
            if self._is_optional_type(param_type):
                return None
            raise ValueError(f'Parameter {param_name} cannot be None')

        # 处理Union类型
        if self._is_union_type(param_type):
            return self._convert_union_type(param_name, param_value, param_type)

        # 处理类类型（Pydantic、Enum等）
        converted = self._try_convert_class_types(param_name, param_value, param_type)
        if converted is not None:
            return converted

        # 处理内置类型
        converted = self._try_convert_builtin_types(param_name, param_value, param_type)
        if converted is not None:
            return converted

        # 处理容器类型
        converted = self._try_convert_container_types(param_name, param_value, param_type)
        if converted is not None:
            return converted

        # Any类型或其他类型
        if param_type is Any or isinstance(param_value, param_type):
            return param_value

        self.service_logger.debug(
            f'Parameter {param_name} of type {param_type} not explicitly handled, returning original value'
        )
        return param_value

    def _try_convert_class_types(self, param_name: str, param_value: Any, param_type: Type) -> Any:
        """尝试转换类类型，返回None表示不是该类型"""
        if inspect.isclass(param_type):
            if issubclass(param_type, BaseModel):
                return self._convert_pydantic_model(param_name, param_value, param_type)
            if issubclass(param_type, Enum):
                return self._convert_enum_type(param_name, param_value, param_type)
        return None

    def _try_convert_builtin_types(self, param_name: str, param_value: Any, param_type: Type) -> Any:
        """尝试转换内置类型，返回None表示不是该类型"""
        if param_type in (datetime, date, time):
            return self._convert_datetime_type(param_name, param_value, param_type)
        if param_type is Decimal:
            return self._convert_decimal_type(param_name, param_value)
        if param_type in (str, int, float, bool):
            return self._convert_primitive_type(param_name, param_value, param_type)
        return None

    def _try_convert_container_types(self, param_name: str, param_value: Any, param_type: Type) -> Any:
        """尝试转换容器类型，返回None表示不是该类型"""
        origin = get_origin(param_type)
        if origin is list:
            return self._convert_list_type(param_name, param_value, param_type)
        if origin in (set, frozenset):
            return self._convert_set_type(param_name, param_value, param_type)
        if origin is tuple:
            return self._convert_tuple_type(param_name, param_value, param_type)
        if origin is dict:
            return self._convert_dict_type(param_name, param_value, param_type)
        return None

    def _convert_union_type(self, param_name: str, param_value: Any, param_type: Type) -> Any:
        """转换Union类型参数"""
        union_args = get_args(param_type)
        errors = []
        for union_type in union_args:
            if union_type is type(None):
                continue
            try:
                return self.convert_and_validate_param(param_name, param_value, union_type)
            except Exception as e:
                errors.append(f'{union_type.__name__}: {str(e)}')
        if type(None) in union_args and param_value is None:
            return None
        raise ValueError(
            f'Cannot convert parameter {param_name} to any Union type. Tried: {"; ".join(errors)}'
        )

    def _convert_pydantic_model(
        self, param_name: str, param_value: Any, param_type: Type[BaseModel]
    ) -> BaseModel:
        """转换Pydantic模型参数"""
        if isinstance(param_value, param_type):
            return param_value
        try:
            return param_type.model_validate(param_value)
        except ValidationError as e:
            error_details = '; '.join([f'{err["loc"]}: {err["msg"]}' for err in e.errors()])
            raise ValueError(f'Pydantic model validation failed: {param_name} {error_details}')
        except Exception as e:
            raise ValueError(f'Pydantic model validation failed: {param_name} {str(e)}')

    def _convert_enum_type(self, param_name: str, param_value: Any, param_type: Type[Enum]) -> Enum:
        """转换Enum类型参数"""
        if isinstance(param_value, param_type):
            return param_value
        try:
            return param_type(param_value)
        except (ValueError, KeyError):
            valid_values = [e.value for e in param_type]
            raise ValueError(f'Parameter {param_name} must be one of {valid_values}')

    def _convert_datetime_type(
        self, param_name: str, param_value: Any, param_type: Type
    ) -> Union[datetime, date, time]:
        """转换日期时间类型参数"""
        if param_type is datetime:
            return self._convert_to_datetime(param_name, param_value)
        if param_type is date:
            return self._convert_to_date(param_name, param_value)
        if param_type is time:
            return self._convert_to_time(param_name, param_value)

    def _convert_to_datetime(self, param_name: str, param_value: Any) -> datetime:
        """转换为datetime类型"""
        if isinstance(param_value, datetime):
            return param_value
        if isinstance(param_value, str):
            return datetime.fromisoformat(param_value.replace('Z', '+00:00'))
        if isinstance(param_value, (int, float)):
            return datetime.fromtimestamp(param_value)
        raise ValueError(f'Parameter {param_name} cannot be converted to datetime')

    def _convert_to_date(self, param_name: str, param_value: Any) -> date:
        """转换为date类型"""
        if isinstance(param_value, date):
            return param_value
        if isinstance(param_value, str):
            return date.fromisoformat(param_value)
        raise ValueError(f'Parameter {param_name} cannot be converted to date')

    def _convert_to_time(self, param_name: str, param_value: Any) -> time:
        """转换为time类型"""
        if isinstance(param_value, time):
            return param_value
        if isinstance(param_value, str):
            return time.fromisoformat(param_value)
        raise ValueError(f'Parameter {param_name} cannot be converted to time')

    def _convert_decimal_type(self, param_name: str, param_value: Any) -> Decimal:
        """转换Decimal类型参数"""
        try:
            return Decimal(str(param_value))
        except Exception:
            raise ValueError(f'Parameter {param_name} cannot be converted to Decimal')

    def _convert_primitive_type(self, param_name: str, param_value: Any, param_type: Type) -> Any:
        """转换基本类型参数"""
        if isinstance(param_value, param_type):
            return param_value
        try:
            if param_type is bool:
                if isinstance(param_value, str):
                    lower_val = param_value.lower()
                    if lower_val in ('true', '1', 'yes', 'on'):
                        return True
                    if lower_val in ('false', '0', 'no', 'off'):
                        return False
                    raise ValueError()
                return bool(param_value)
            if param_type is str:
                return str(param_value)
            return param_type(param_value)
        except (ValueError, TypeError):
            raise ValueError(f'Cannot convert parameter {param_name} to {param_type.__name__}')

    def _convert_list_type(self, param_name: str, param_value: Any, param_type: Type) -> list:
        """转换List类型参数"""
        if not isinstance(param_value, (list, tuple, set)):
            raise ValueError(f'Parameter {param_name} should be an iterable type')
        list_args = get_args(param_type)
        if list_args:
            item_type = list_args[0]
            return [
                self.convert_and_validate_param(f'{param_name}[{i}]', item, item_type)
                for i, item in enumerate(param_value)
            ]
        return list(param_value)

    def _convert_set_type(
        self, param_name: str, param_value: Any, param_type: Type
    ) -> Union[set, frozenset]:
        """转换Set/FrozenSet类型参数"""
        if not isinstance(param_value, (list, tuple, set, frozenset)):
            raise ValueError(f'Parameter {param_name} should be an iterable type')
        set_args = get_args(param_type)
        origin = get_origin(param_type)
        if set_args:
            item_type = set_args[0]
            converted_items = [
                self.convert_and_validate_param(f'{param_name}[{i}]', item, item_type)
                for i, item in enumerate(param_value)
            ]
            return origin(converted_items)
        return origin(param_value)

    def _convert_tuple_type(self, param_name: str, param_value: Any, param_type: Type) -> tuple:
        """转换Tuple类型参数"""
        if not isinstance(param_value, (list, tuple)):
            raise ValueError(f'Parameter {param_name} should be a list or tuple type')
        tuple_args = get_args(param_type)
        if not tuple_args:
            return tuple(param_value)

        # 可变长度元组
        if len(tuple_args) == 2 and tuple_args[1] is Ellipsis:
            item_type = tuple_args[0]
            return tuple(
                self.convert_and_validate_param(f'{param_name}[{i}]', item, item_type)
                for i, item in enumerate(param_value)
            )

        # 固定长度元组
        if len(param_value) != len(tuple_args):
            raise ValueError(f'Parameter {param_name} should contain {len(tuple_args)} elements')
        return tuple(
            self.convert_and_validate_param(f'{param_name}[{i}]', item, item_type)
            for i, (item, item_type) in enumerate(zip(param_value, tuple_args))
        )

    def _convert_dict_type(self, param_name: str, param_value: Any, param_type: Type) -> dict:
        """转换Dict类型参数"""
        if not isinstance(param_value, dict):
            raise ValueError(f'Parameter {param_name} should be a dictionary type')
        dict_args = get_args(param_type)
        if dict_args and len(dict_args) == 2:
            key_type, value_type = dict_args
            return {
                self.convert_and_validate_param(
                    f'{param_name}.key', k, key_type
                ): self.convert_and_validate_param(f'{param_name}[{k}]', v, value_type)
                for k, v in param_value.items()
            }
        return param_value

    def _is_optional_type(self, param_type: Type) -> bool:
        """检查是否为可选类型（Optional[T] 或 Union[T, None]）"""
        return self._is_union_type(param_type) and type(None) in get_args(param_type)

    def _is_union_type(self, param_type: Type) -> bool:
        """检查是否为Union类型"""
        return get_origin(param_type) is Union

    def serialize_result(self, result: Any) -> Any:
        """序列化返回结果，使用FastAPI同样的格式化规则"""
        if result is None:
            return None

        # 处理基本类型（快速路径）
        if isinstance(result, (str, int, float, bool)):
            return result

        # 处理模型和特殊类型
        serialized = self._serialize_special_types(result)
        if serialized is not None:
            return serialized

        # 处理容器类型
        return self._serialize_containers(result)

    def _serialize_special_types(self, result: Any) -> Any:
        """序列化特殊类型，返回None表示不是特殊类型"""
        if isinstance(result, BaseModel):
            return self._serialize_pydantic_model(result)
        if hasattr(result, 'model_dump'):
            return self._serialize_model_like(result)
        if isinstance(result, (datetime, date, time)):
            return result.isoformat()
        if isinstance(result, Enum):
            return result.value
        if isinstance(result, Decimal):
            return self._serialize_decimal(result)
        if isinstance(result, bytes):
            return self._serialize_bytes(result)
        return None

    def _serialize_containers(self, result: Any) -> Any:
        """序列化容器类型和对象"""
        if isinstance(result, (list, tuple)):
            return [self.serialize_result(item) for item in result]
        if isinstance(result, (set, frozenset)):
            return [self.serialize_result(item) for item in result]
        if isinstance(result, dict):
            return {self.serialize_result(k): self.serialize_result(v) for k, v in result.items()}
        return self._serialize_object(result)

    def _serialize_pydantic_model(self, result: BaseModel) -> dict:
        """序列化Pydantic模型"""
        try:
            return result.model_dump(mode='json')
        except Exception:
            return result.model_dump()

    def _serialize_model_like(self, result: Any) -> Any:
        """序列化类似模型的对象"""
        try:
            return result.model_dump(mode='json')
        except Exception:
            return None

    def _serialize_decimal(self, result: Decimal) -> Union[float, str]:
        """序列化Decimal类型"""
        try:
            float_val = float(result)
            if Decimal(str(float_val)) == result:
                return float_val
            return str(result)
        except Exception:
            return str(result)

    def _serialize_bytes(self, result: bytes) -> str:
        """序列化bytes类型为base64字符串"""
        import base64

        return base64.b64encode(result).decode('utf-8')

    def _serialize_object(self, result: Any) -> Any:
        """序列化普通对象"""
        if hasattr(result, '__dict__'):
            try:
                obj_dict = {}
                for key, value in result.__dict__.items():
                    if not key.startswith('_'):
                        obj_dict[key] = self.serialize_result(value)
                return obj_dict
            except Exception:
                pass
        try:
            return str(result)
        except Exception:
            return f'<Unserializable object: {type(result).__name__}>'
