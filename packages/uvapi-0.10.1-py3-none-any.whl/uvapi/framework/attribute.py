"""APP Attribute 特性"""

import queue
import time
from typing import Any, Dict, Type, Optional, ClassVar, TYPE_CHECKING
from threading import Lock, Thread, Event
from pydantic import BaseModel
import ormsgpack

from ..logger import UV_LOGGER
from ..config import UV_APP_CONFIG
from ..modules import AttributesSnapshotMessage, AttributesChangeMessage

if TYPE_CHECKING:
    from ..client.topic_manager import StreamTopic


class AttributeChangeNotifier:
    """属性变更通知器"""

    def __init__(self) -> None:
        """初始化属性变更通知器"""
        # Stream主题用于推送attribute变更
        self._stream_topic: Optional['StreamTopic'] = None
        self._topic_lock = Lock()

        # 从配置获取队列大小
        config = UV_APP_CONFIG.app_config
        queue_max_size = config.attributes_queue_max_size

        # 消息队列用于缓冲通知
        self._message_queue: 'queue.Queue[AttributesSnapshotMessage | AttributesChangeMessage]' = (
            queue.Queue(maxsize=queue_max_size)
        )

        # 工作线程控制
        self._worker_thread: Optional[Thread] = None
        self._shutdown_event = Event()
        self._running = False

        # 属性组注册表，用于定时推送
        self._attribute_groups: Dict[str, Type['BaseAttrGroup']] = {}
        self._groups_lock = Lock()

        # 定时推送配置
        self._auto_push_enabled = config.attributes_auto_push
        self._push_interval = config.attributes_push_interval
        self._last_push_time = 0.0

        # 启动工作线程
        self._start_worker()

    def set_stream_topic(self, stream_topic: 'StreamTopic') -> None:
        """设置Stream主题用于推送attribute数据

        Args:
            stream_topic: Stream主题实例
        """
        with self._topic_lock:
            self._stream_topic = stream_topic
        UV_LOGGER.debug('AttributeChangeNotifier also configured to push data via Stream topic')

    def push_attributes_snapshot(self, group_name: str) -> bool:
        """推送指定属性组的当前值"""
        with self._groups_lock:
            groups = self._attribute_groups.copy()

        if group_name not in groups:
            UV_LOGGER.debug(f'Attribute group {group_name} not found, current has groups: {groups.keys()}')
            return False

        instance = groups[group_name]()
        message = AttributesSnapshotMessage(
            group=group_name,
            attributes=instance,
        )
        self._process_message(message)
        return True

    def get_registered_attribute_group(self, group_name: str) -> Optional[Type['BaseAttrGroup']]:
        """获取已注册的属性组类"""
        with self._groups_lock:
            groups = self._attribute_groups.copy()
        if group_name not in groups:
            UV_LOGGER.debug(f'Attribute group {group_name} not found, current has groups: {groups.keys()}')
            return None
        return groups[group_name]

    def get_all_attribute_groups(self) -> list[str]:
        """获取所有属性组"""
        with self._groups_lock:
            return list(self._attribute_groups.keys())

    def _start_worker(self) -> None:
        """启动工作线程"""
        if not self._running:
            self._running = True
            self._shutdown_event.clear()
            self._worker_thread = Thread(
                target=self._worker_loop, daemon=True, name=f'AttributeChangeNotifierWorker-{self}'
            )
            self._worker_thread.start()

    def _should_push_attributes(self) -> bool:
        """检查是否应该推送属性快照"""
        if not self._auto_push_enabled:
            return False

        current_time = time.time()
        if current_time - self._last_push_time >= self._push_interval:
            self._last_push_time = current_time
            return True
        return False

    def _push_all_attributes(self) -> None:
        """推送所有属性组的当前值"""
        with self._groups_lock:
            groups = self._attribute_groups.copy()

        for group_name, group_class in groups.items():
            try:
                # 获取单例实例
                instance = group_class()

                # 创建全量推送消息
                message = AttributesSnapshotMessage(
                    group=group_name,
                    attributes=instance,
                )

                # 直接处理消息（不通过队列，避免阻塞变更通知）
                self._process_message(message)

            except Exception as e:
                UV_LOGGER.exception(e)
                UV_LOGGER.debug(f'Error pushing attributes for group {group_name}')

    def _worker_loop(self) -> None:
        """处理Attribute消息队列、定时推送Attribute当前值"""
        while not self._shutdown_event.is_set():
            try:
                # 从队列中获取消息，使用较短的超时以便检查定时推送
                message_processed = False
                try:
                    message_data = self._message_queue.get(timeout=0.5)
                    # 处理消息
                    self._process_message(message_data)
                    self._message_queue.task_done()
                    message_processed = True
                except queue.Empty:
                    pass

                # 如果没有处理消息，检查是否需要定时推送
                if not message_processed and self._should_push_attributes():
                    try:
                        self._push_all_attributes()
                    except Exception as e:
                        UV_LOGGER.exception(e)
                        UV_LOGGER.debug('Periodic push error')

            except Exception as e:
                # 记录错误但继续运行
                UV_LOGGER.exception(e)
                UV_LOGGER.debug('Worker thread error')
                continue

    def _process_message(self, message_data: AttributesSnapshotMessage | AttributesChangeMessage) -> None:
        """处理单个消息，通过Stream主题推送"""
        try:
            # 检查Stream主题是否可用
            with self._topic_lock:
                stream_topic = self._stream_topic

            if not stream_topic:
                UV_LOGGER.debug('Stream topic not set, skipping attribute push')
                return

            # 序列化消息
            option = ormsgpack.OPT_SERIALIZE_PYDANTIC if isinstance(message_data, BaseModel) else None
            packed_message = ormsgpack.packb(message_data, option=option)

            # 通过Stream主题发送数据
            self._send_via_stream(stream_topic, packed_message)

        except Exception as e:
            UV_LOGGER.exception(e)
            UV_LOGGER.debug('Error processing attribute message')

    def _send_via_stream(self, stream_topic: 'StreamTopic', data: bytes) -> None:
        """通过Stream主题发送数据

        Args:
            stream_topic: Stream主题实例
            data: 要发送的数据
        """
        try:
            from ..modules import Message

            # 创建Stream消息
            context = {
                'data': data,
                'seq': int(time.time() * 1000000),  # 使用微秒时间戳作为序列号
            }

            message = Message(context=context)

            # 发送消息
            stream_topic.ready_to_write = True
            success = stream_topic.send_message(message)
            if success:
                UV_LOGGER.debug('Attribute data pushed via Stream topic')
            else:
                UV_LOGGER.debug('Failed to push attribute data via Stream topic')

        except Exception as e:
            UV_LOGGER.exception(e)
            UV_LOGGER.debug('Error pushing attribute data via Stream topic')

    def register_attribute_group(self, group_name: str, group_class: Type['BaseAttrGroup']) -> None:
        """注册属性组

        Args:
            group_name: 属性组名
            group_class: 属性组类
        """
        with self._groups_lock:
            self._attribute_groups[group_name] = group_class
        UV_LOGGER.debug(f'Attribute group {group_name} registered')

    def unregister_attribute_group(self, group_name: str) -> None:
        """注销属性组

        Args:
            group_name: 属性组名
        """
        with self._groups_lock:
            self._attribute_groups.pop(group_name, None)
        UV_LOGGER.debug(f'Attribute group {group_name} unregistered')

    def notify_change(self, group_name: str, attr_name: str, old_value: Any, new_value: Any) -> None:
        """通知属性变更

        Args:
            group_name: 属性组名
            attr_name: 属性名
            old_value: 旧值
            new_value: 新值
        """
        if not self._running:
            return

        message = AttributesChangeMessage(
            group=group_name,
            attribute=attr_name,
            old_value=old_value,
            value=new_value,
            timestamp=time.time(),
        )

        try:
            # 将消息放入队列，如果队列满了则丢弃旧消息
            self._message_queue.put_nowait(message)
        except queue.Full:
            # 队列满了，移除最旧的消息并添加新消息
            try:
                self._message_queue.get_nowait()
                self._message_queue.put_nowait(message)
            except queue.Empty:
                pass

    def shutdown(self) -> None:
        """关闭通知器"""
        if self._running:
            self._running = False
            self._shutdown_event.set()

            # 等待工作线程结束
            if self._worker_thread and self._worker_thread.is_alive():
                self._worker_thread.join(timeout=5.0)

    def __del__(self) -> None:
        """析构函数"""
        self.shutdown()


# 全局通知器实例
_notifier = AttributeChangeNotifier()


class SingletonModelMeta(type(BaseModel)):
    """兼容BaseModel的单例元类"""

    _instances: Dict[Type, Any] = {}
    _lock = Lock()

    def __call__(cls, *args, **kwargs) -> Any:
        """单例模式的调用方法"""
        if cls not in cls._instances:
            with cls._lock:
                if cls not in cls._instances:
                    cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]


class BaseAttrGroup(BaseModel, metaclass=SingletonModelMeta):
    """属性组模型"""

    model_config = {'arbitrary_types_allowed': True}

    _group_name: ClassVar[Optional[str]] = None
    _notifier: ClassVar[AttributeChangeNotifier] = _notifier

    def model_post_init(self, __context: Any) -> None:
        """Pydantic 初始化后的钩子，用于建立嵌套类型的父子关系"""
        from .nested_attribute import SubAttrGroup
        from .tracked_containers import TrackedDict, TrackedList

        # 遍历所有字段，建立父子关系
        for field_name, _ in self.__class__.model_fields.items():
            value = getattr(self, field_name, None)
            if value is None:
                continue
            if isinstance(value, (SubAttrGroup, TrackedDict, TrackedList)):
                try:
                    parent = object.__getattribute__(value, '_parent')
                    if parent is None:
                        value._set_parent(self, field_name)
                except AttributeError:
                    value._set_parent(self, field_name)

    def __setattr__(self, name: str, value: Any) -> None:
        """重写属性设置方法以支持变更通知和嵌套类型"""
        from .nested_attribute import SubAttrGroup
        from .tracked_containers import TrackedDict, TrackedList

        # 跳过私有属性
        if name.startswith('_'):
            super(BaseAttrGroup, self).__setattr__(name, value)
            return

        # 检查是否是 SubAttrGroup 的整体赋值（运行时修改）
        if hasattr(self, name):
            existing_value = getattr(self, name, None)
            if isinstance(existing_value, SubAttrGroup) and isinstance(value, SubAttrGroup):
                # 禁止对 SubAttrGroup 进行整体赋值
                raise TypeError(
                    f"不能对 SubAttrGroup 类型的属性 '{name}' 进行整体赋值。"
                    f'请直接修改其内部属性，例如：obj.{name}.field = value'
                )

        # 获取旧值
        old_value = getattr(self, name, None) if hasattr(self, name) else None

        # 设置新值
        super(BaseAttrGroup, self).__setattr__(name, value)

        # 如果值发生变化且不是私有属性，发送通知
        if old_value != value and self._group_name is not None:
            # 直接调用同步的notify_change方法，它会将消息放入队列
            self._notifier.notify_change(self._group_name, name, old_value, value)

    @classmethod
    def get_notifier(cls) -> AttributeChangeNotifier:
        """获取通知器实例"""
        return cls._notifier
