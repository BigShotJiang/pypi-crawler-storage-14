"""设置全局logging配置"""
import datetime
import logging
import logging.config
from typing import Dict, Any
import sys
from ..modules import Message
from ..client.topic_manager import TopicHandler
from ..config import UV_APP_CONFIG, LOG_LEVEL_MAP


class CustomLogger:
    """自定义日志记录器"""

    _log_topic: TopicHandler | None = None

    def __init__(self) -> None:
        """初始化自定义日志记录器"""
        self.logger = setup_logging()

    def _pub_message(self, msg: str, lvl: int = logging.DEBUG, code: int = 0) -> None:
        """发布消息到日志主题"""
        if self._log_topic is not None:
            """构建日志消息"""
            log_message = {
                "app_id": str(UV_APP_CONFIG.app_config.id),
                "app_name": str(UV_APP_CONFIG.app_config.name),
                "lvl": LOG_LEVEL_MAP.get(lvl).upper(),
                "code": code,
                "ctx": msg,
                "ts": datetime.datetime.now().timestamp()
            }
            self._log_topic.publish_message(message=Message(context=log_message))

    def debug(self, msg: str, *args, **kwargs) -> None:
        """调试级别日志"""
        self.logger.debug(msg, *args, **kwargs)

    def info(self, msg: str, code: int, *args, **kwargs) -> None:
        """信息级别日志"""
        self._pub_message(msg, logging.INFO, code)
        self.logger.info(msg, *args, **kwargs)

    def warning(self, msg: str, code: int, *args, **kwargs) -> None:
        """警告级别日志"""
        self._pub_message(msg, logging.WARNING, code)
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg: str, code: int, *args, **kwargs) -> None:
        """错误级别日志"""
        self._pub_message(msg, logging.ERROR, code)
        self.logger.error(msg, *args, **kwargs)

    def exception(self, exeception: Exception, *args, **kwargs) -> None:
        """异常级别日志"""
        self.logger.exception(exeception, *args, **kwargs)

    def critical(self, msg: str, code: int, *args, **kwargs) -> None:
        """严重级别日志"""
        self._pub_message(msg, logging.CRITICAL, code)
        self.logger.critical(msg, *args, **kwargs)


def setup_logging() -> logging.Logger:
    """设置全局logging配置

    Returns:
        logging.Logger: 配置好的logger实例
    """
    app_config = UV_APP_CONFIG.app_config

    # 获取配置参数
    log_level = app_config.logging_level
    log_format = app_config.logging_format

    log_file = app_config.logging_file
    log_file_max_bytes = app_config.logging_file_max_bytes
    log_file_backup_count = app_config.logging_file_backup_count
    log_console = app_config.logging_console

    # 创建logger配置字典
    log_config: Dict[str, Any] = {
        'version': 1,
        'disable_existing_loggers': False,
        'formatters': {
            'default': {'format': log_format, 'datefmt': '%Y-%m-%d %H:%M:%S'},
            'detailed': {
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
                'datefmt': '%Y-%m-%d %H:%M:%S',
            },
        },
        'handlers': {},
        'loggers': {
            '': {  # root logger
                'level': LOG_LEVEL_MAP.get(log_level, logging.INFO),
                'handlers': [],
                'propagate': False,
            },
            app_config.name: {  # app logger
                'level': LOG_LEVEL_MAP.get(log_level, logging.INFO),
                'handlers': [],
                'propagate': False,
            },
            'uvicorn': {
                'level': LOG_LEVEL_MAP.get(log_level, logging.INFO),
                'handlers': [],
                'propagate': False,
            },
            'uvicorn.access': {
                'level': logging.WARNING,
                'handlers': [],
                'propagate': False,
            },
            'fastapi': {
                'level': LOG_LEVEL_MAP.get(log_level, logging.INFO),
                'handlers': [],
                'propagate': False,
            },
            'sqlalchemy': {
                'level': logging.WARNING,
                'handlers': [],
                'propagate': False,
            },
        },
    }

    # 添加控制台处理器
    if log_console:
        log_config['handlers']['console'] = {
            'class': 'logging.StreamHandler',
            'level': logging.DEBUG,
            'formatter': 'default',
            'stream': sys.stdout,
        }
        # 为所有logger添加控制台处理器
        for logger_name in log_config['loggers']:
            log_config['loggers'][logger_name]['handlers'].append('console')

    # 添加文件处理器
    if log_file:
        log_file_path = UV_APP_CONFIG.app_config.runtime.platform_app_data / log_file
        log_file_path.parent.mkdir(parents=True, exist_ok=True)

        log_config['handlers']['rotating_file'] = {
            'class': 'logging.handlers.RotatingFileHandler',
            'level': logging.DEBUG,
            'formatter': 'detailed',
            'filename': str(log_file_path),
            'maxBytes': log_file_max_bytes,
            'backupCount': log_file_backup_count,
            'encoding': 'utf-8',
        }
        log_config['handlers']['buffering_file'] = {
            'class': 'logging.handlers.MemoryHandler',
            'capacity': 1000,  # 缓冲1000条日志
            'flushLevel': logging.ERROR,  # 遇到ERROR级别立即刷新
            'target': 'rotating_file',  # 目标handler
        }
        # 为所有logger添加文件处理器
        for logger_name in log_config['loggers']:
            log_config['loggers'][logger_name]['handlers'].append('buffering_file')

    # 应用配置
    logging.config.dictConfig(log_config)

    # 返回root logger
    return logging.getLogger(app_config.name)


def get_logger(name: str) -> logging.Logger:
    """获取指定名称的logger

    Args:
        name: logger名称，通常使用模块名

    Returns:
        logging.Logger: logger实例
    """
    return logging.getLogger(name)


# 初始化logging
logger = CustomLogger()
