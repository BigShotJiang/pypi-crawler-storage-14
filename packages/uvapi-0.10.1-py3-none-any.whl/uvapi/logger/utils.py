"""统一的logging工具函数

提供整个项目使用的logging工具函数和装饰器
"""

import logging
import functools
import time
from typing import Any, Callable, Optional, Type
from .logging import get_logger


def log_api_request(func: Callable) -> Callable:
    """API请求日志装饰器

    专门用于API端点的请求日志记录

    Args:
        func: 被装饰的API函数

    Returns:
        Callable: 装饰后的函数
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        api_logger = get_logger('api')
        start_time = time.time()

        # 记录请求开始
        api_logger.debug(f'API请求开始: {func.__name__}')

        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            api_logger.debug(f'API请求成功: {func.__name__}，耗时: {execution_time:.4f}秒')
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            api_logger.debug(f'API请求失败: {func.__name__}，耗时: {execution_time:.4f}秒，错误: {e}')
            raise

    return wrapper


def log_database_operation(operation: str) -> Callable:
    """数据库操作日志装饰器

    Args:
        operation: 操作类型描述

    Returns:
        Callable: 装饰器函数
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            db_logger = get_logger('database')
            db_logger.debug(f'数据库操作: {operation} - {func.__name__}')

            try:
                result = func(*args, **kwargs)
                db_logger.debug(f'数据库操作成功: {operation} - {func.__name__}')
                return result
            except Exception as e:
                db_logger.debug(f'数据库操作失败: {operation} - {func.__name__}，错误: {e}')
                raise

        return wrapper

    return decorator


class LogContext:
    """日志上下文管理器

    用于在特定上下文中记录日志
    """

    def __init__(self, logger_name: str, context_name: str, level: int = logging.INFO) -> None:
        """初始化日志上下文管理器

        Args:
            logger_name: logger名称
            context_name: 上下文名称
            level: 日志级别
        """
        self.logger = get_logger(logger_name)
        self.context_name = context_name
        self.level = level
        self.start_time: Optional[float] = None

    def __enter__(self) -> 'LogContext':
        """进入上下文"""
        self.start_time = time.time()
        self.logger.log(self.level, f'进入上下文: {self.context_name}')
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[object],
    ) -> bool:
        """退出上下文"""
        execution_time = time.time() - self.start_time if self.start_time else 0

        if exc_type is None:
            self.logger.log(self.level, f'退出上下文: {self.context_name}，耗时: {execution_time:.4f}秒')
        else:
            self.logger.debug(
                f'上下文异常退出: {self.context_name}，耗时: {execution_time:.4f}秒，错误: {exc_val}'
            )

        return False  # 不抑制异常
