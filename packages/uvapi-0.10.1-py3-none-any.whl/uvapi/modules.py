"""定义ultraview内部使用的各种数据模型"""

import enum
import inspect
import pathlib
import re
import time
from concurrent.futures import Future
from typing import Any, Annotated, Dict, List, Optional, Callable, Type, TYPE_CHECKING

from pydantic import BaseModel, ConfigDict, Field
from pydantic_core import core_schema
import json
import uuid
from datetime import datetime

from enum import Enum



if TYPE_CHECKING:
    from .framework.service import UVAppService


__all__ = [
    'UVAppConfig',
    'BuildInfo',
    'BuildPython',
    'BuildConfig',
    'DependencyInfo',
    'ManifestModel',
    'ActionInfo',
    'ActionRuntimeContext',
]


# 自定义类型包装器，用于无法序列化的类型
def _get_type_short_name(annotation: Any) -> str:
    """获取类型的简短名称，不包含模块路径"""
    if annotation is inspect.Parameter.empty or annotation is inspect.Signature.empty:
        return ''

    # 如果是类，直接返回类名
    if inspect.isclass(annotation):
        return annotation.__name__

    # 对于泛型类型（如 list[str], Optional[int] 等）
    # 使用字符串替换去掉模块路径
    type_str = str(annotation)

    # 移除常见的模块前缀
    # 匹配形如 module.submodule.ClassName 的模式，只保留 ClassName
    type_str = re.sub(r'\b[\w.]+\.(\w+)', r'\1', type_str)

    return type_str


class _SignatureAnnotation:
    """自定义 inspect.Signature 的 Pydantic 注解"""

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: Any) -> Any:
        """自定义 Pydantic core schema"""

        def serialize_signature(sig: inspect.Signature) -> str:
            """序列化函数签名为字符串，只显示类名不显示完整路径"""
            # 构建参数字符串
            params = []
            for param_name, param in sig.parameters.items():
                param_str = param_name
                if param.annotation is not inspect.Parameter.empty:
                    param_str += f': {_get_type_short_name(param.annotation)}'
                if param.default is not inspect.Parameter.empty:
                    default_str = (
                        repr(param.default) if isinstance(param.default, str) else str(param.default)
                    )
                    param_str += f' = {default_str}'
                params.append(param_str)

            # 构建返回值字符串
            result = f'({", ".join(params)})'
            if sig.return_annotation is not inspect.Signature.empty:
                result += f' -> {_get_type_short_name(sig.return_annotation)}'

            return result

        return core_schema.no_info_after_validator_function(
            lambda x: x,
            core_schema.any_schema(),
            serialization=core_schema.plain_serializer_function_ser_schema(
                serialize_signature, return_schema=core_schema.str_schema()
            ),
        )


class _TypeHintsAnnotation:
    """自定义 Dict[str, Type] 的 Pydantic 注解"""

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: Any) -> Any:
        """自定义 Pydantic core schema"""

        def serialize_type_hints(type_hints: Dict[str, Type]) -> dict:
            """序列化类型提示，将 BaseModel 展开为 dict_schema"""
            result = {}
            for key, value in type_hints.items():
                # 检查是否为 BaseModel 子类
                if inspect.isclass(value) and issubclass(value, BaseModel):
                    result[key] = value.model_json_schema()
                else:
                    result[key] = _get_type_short_name(value)
            return result

        return core_schema.no_info_after_validator_function(
            lambda x: x,
            core_schema.any_schema(),
            serialization=core_schema.plain_serializer_function_ser_schema(
                serialize_type_hints,
                return_schema=core_schema.dict_schema(
                    keys_schema=core_schema.str_schema(), values_schema=core_schema.any_schema()
                ),
            ),
        )


class _CallableAnnotation:
    """自定义 Callable 的 Pydantic 注解"""

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: Any) -> Any:
        """自定义 Pydantic core schema"""
        return core_schema.no_info_after_validator_function(
            lambda x: x,
            core_schema.any_schema(),
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda x: f'<function {getattr(x, "__name__", "anonymous")}>',
                return_schema=core_schema.str_schema(),
            ),
        )


class _FutureAnnotation:
    """自定义 Future 的 Pydantic 注解"""

    @classmethod
    def __get_pydantic_core_schema__(cls, source_type: Any, handler: Any) -> Any:
        """自定义 Pydantic core schema"""
        return core_schema.no_info_after_validator_function(
            lambda x: x,
            core_schema.any_schema(),
            serialization=core_schema.plain_serializer_function_ser_schema(
                lambda x: f'<Future {getattr(x, "__name__", "anonymous")}>',
                return_schema=core_schema.str_schema(),
            ),
        )


# 创建类型别名
SignatureType = Annotated[inspect.Signature, _SignatureAnnotation]
TypeHintsType = Annotated[Dict[str, Type], _TypeHintsAnnotation]
CallableType = Annotated[Callable, _CallableAnnotation]
FutureType = Annotated[Future, _FutureAnnotation]


class UVAppConfig(BaseModel):
    """UVApp配置模型

    Args:
        BaseModel (_type_): pydantic基类
    """

    app_config: 'AppConfig' = Field(description='应用配置')
    project_config: 'PyProjectConfig' = Field(description='项目配置')


class AppRuntimeConfig(BaseModel):
    """app runtime配置模型"""

    platform_root: pathlib.Path = Field(description='平台根目录', default=pathlib.Path('./'))
    platform_app_repo: pathlib.Path = Field(description='平台应用仓库目录', default=pathlib.Path('./repo'))
    platform_runtime_data: pathlib.Path = Field(
        description='平台运行时数据目录', default=pathlib.Path('./data')
    )
    platform_app_data: pathlib.Path = Field(description='平台应用数据目录', default=pathlib.Path('./'))
    restapi_port: int = Field(default=9898, description='REST API端口')
    mcp_port: int = Field(default=9899, description='MCP端口')


class AppConfig(BaseModel):
    """app_config.toml配置模型"""

    id: str = Field(description='应用ID')
    name: str = Field(description='应用名称')
    version: str = Field(description='应用版本')
    description: str = Field(description='应用描述')
    requires: list[str] = Field(default_factory=list, description='依赖的模块列表')
    static_worker_id: int = Field(default=-1, description='静态Worker ID')
    messagebus_addr: str = Field(default='tcp://127.0.0.1:10000', description='消息总线地址')
    apis: list[str] = Field(default_factory=list, description='API模块列表')
    # 日志级别
    logging_level: str = Field(default='info', description='日志级别')
    logging_format: str = Field(
        default='%(asctime)s - %(name)s - %(levelname)s - %(message)s', description='日志格式'
    )
    database_addr: str = Field(default='', description='数据库地址')
    database_username: str = Field(default='', description='数据库用户名')
    database_password: str = Field(default='', description='数据库密码')
    database_echo: bool = Field(default=False, description='数据库echo')
    logging_file: str = Field(default='logs/app.log', description='日志文件路径')
    logging_file_max_bytes: int = Field(default=10485760, description='日志文件最大字节数')
    logging_file_backup_count: int = Field(default=5, description='日志文件备份数量')
    logging_console: bool = Field(default=True, description='是否输出到控制台')

    # Action请求配置
    action_default_timeout: float = Field(default=5.0, description='Action默认超时时间，单位:秒')

    # Attributes推送配置
    attributes_auto_push: bool = Field(default=True, description='是否定时自动推送Attribute属性')
    attributes_push_interval: int = Field(default=30, description='定时推送间隔（秒）')
    attributes_queue_max_size: int = Field(default=1000, description='属性变更队列最大大小')

    runtime: AppRuntimeConfig = Field(description='运行时配置', default_factory=AppRuntimeConfig)


class PyProjectProject(BaseModel):
    """pyproject.toml中的[project]部分配置模型"""

    name: str = Field(description='项目名称')
    version: str = Field(description='项目版本')
    description: str = Field(description='项目描述')
    readme: Optional[str] = Field(default=None, description='README文件路径')
    requires_python: Optional[str] = Field(
        default=None, description='Python版本要求', alias='requires-python'
    )
    dependencies: List[str] = Field(default_factory=list, description='项目依赖列表')


class PyProjectDependencyGroups(BaseModel):
    """pyproject.toml中的[dependency-groups]部分配置模型"""

    dev: List[str] = Field(default_factory=list, description='开发依赖列表')


class PyProjectBuildSystem(BaseModel):
    """pyproject.toml中的[build-system]部分配置模型"""

    requires: List[str] = Field(default_factory=list, description='构建系统依赖')
    build_backend: Optional[str] = Field(default=None, description='构建后端', alias='build-backend')


class PyProjectConfig(BaseModel):
    """pyproject.toml配置模型

    完整的pyproject.toml文件结构模型
    """

    project: PyProjectProject = Field(description='项目基本信息')
    dependency_groups: Optional[PyProjectDependencyGroups] = Field(
        default=None, description='依赖组配置', alias='dependency-groups'
    )
    build_system: Optional[PyProjectBuildSystem] = Field(
        default=None, description='构建系统配置', alias='build-system'
    )

    class Config:
        """Pydantic配置类"""

        populate_by_name = True  # 允许使用字段名和别名


class ActionInfo(BaseModel):
    """Action信息模型"""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    name: str = Field(description='Action名称')
    func_signature: SignatureType = Field(description='Action函数签名')
    func_type_hints: TypeHintsType = Field(description='Action函数类型注解')
    description: str = Field(description='Action描述')
    func: CallableType = Field(description='Action函数')
    timeout: float = Field(description='Action超时时间', default=5.0)


class ActionRuntimeContext(BaseModel):
    """Action运行时上下文模型"""

    message: 'Message' = Field(description='Message实例')
    action_info: Optional[ActionInfo] = Field(description='Action信息', default=None)
    timeout: float = Field(description='Action超时时间', default=5.0)
    params: Dict[str, Any] = Field(description='Action参数', default={})
    result: Optional['Message'] = Field(description='Action结果', default=None)
    future: Optional[FutureType] = Field(description='Future实例', default=None)
    timestamp: float = Field(description='时间戳', default_factory=time.time)


class AttributeChangeType(enum.Enum):
    """属性变更类型"""

    ATTRIBUTE_CHANGE = 'attribute_change'
    ATTRIBUTE_SNAPSHOT = 'attribute_snapshot'


class AttributesSnapshotMessage(BaseModel):
    """属性快照消息模型"""

    # 属性变更类型
    type: AttributeChangeType = Field(
        description='属性变更类型', default=AttributeChangeType.ATTRIBUTE_SNAPSHOT
    )
    group: str = Field(description='属性组名')
    attributes: BaseModel = Field(description='属性模型')
    timestamp: float = Field(description='时间戳', default_factory=time.time)


class AttributesChangeMessage(BaseModel):
    """属性变更消息模型，用于通知前端属性变更"""

    # 属性变更类型
    type: AttributeChangeType = Field(
        description='属性变更类型', default=AttributeChangeType.ATTRIBUTE_CHANGE
    )
    group: str = Field(description='属性组名')
    attribute: str = Field(description='属性名')
    old_value: Any = Field(description='旧值')
    value: Any = Field(description='新值')
    timestamp: float = Field(description='时间戳', default_factory=time.time)


# ==================== 构建相关数据模型 ====================


class VenvLibsModeType(enum.Enum):
    """venv_libs生成模式"""

    FULL = 'full'
    AUTO = 'auto'
    NONE = 'none'


class DependencyInfo(BaseModel):
    """应用依赖信息模型"""

    app_id: str = Field(description='依赖应用ID')
    app_name: str = Field(description='依赖应用名称')
    version: str = Field(description='依赖版本要求')


class BuildInfo(BaseModel):
    """构建信息配置模型，映射 [build.info] 部分"""

    frontend_path: str = Field(default='./frontend', description='前端工程路径')
    backend_path: str = Field(default='./backend', description='后端工程路径')
    include_files: List[str] = Field(default_factory=list, description='需要打包的文件路径')
    exclude_files: List[str] = Field(default_factory=list, description='需要排除的文件路径')
    screenshot_path: str = Field(default='./screenshots', description='应用截图文件夹路径')
    install_hook: str = Field(default='./install_hook.py', description='app安装时钩子脚本')
    update_note_file: str = Field(default='./update_note.md', description='应用升级及版本说明文件')
    license_type: str = Field(default='free', description='许可证类型')
    author: str = Field(default='RIGOL Technology', description='作者')
    custom: bool = Field(default=True, description='是否为自定义app')
    tag: List[str] = Field(default_factory=list, description='标签')
    instrument_type: List[str] = Field(default_factory=list, description='仪器类型')
    supported_instrument: List[str] = Field(default_factory=list, description='支持的仪器')
    dependences: List[DependencyInfo] = Field(default_factory=list, description='依赖的app列表')


class BuildPython(BaseModel):
    """Python构建配置模型，映射 [build.python] 部分"""

    enable_cython: bool = Field(default=True, description='是否启用Cython')
    enable_upx: bool = Field(default=False, description='是否启用UPX压缩')
    upx_path: str = Field(default='', description='UPX可执行文件路径')
    venv_libs_mode: VenvLibsModeType = Field(default=VenvLibsModeType.AUTO, description='venv_libs生成模式')
    additional_exclude_venv_libs: List[str] = Field(default_factory=list, description='排除的库列表')


class BuildConfig(BaseModel):
    """构建配置组合模型"""

    info: BuildInfo = Field(description='构建信息配置')
    python: BuildPython = Field(description='Python构建配置')


class ManifestModel(BaseModel):
    """manifest.json 数据模型"""

    build_version: str = Field(default='v1', description='构建版本')
    app_id: str = Field(description='应用ID')
    name: str = Field(description='应用名称')
    author: str = Field(description='作者')
    version: str = Field(description='应用版本')
    custom: bool = Field(description='是否为自定义app')
    description: str = Field(description='应用描述')
    license_type: str = Field(description='许可证类型')
    base_language: str = Field(description='基础语言')
    tag: List[str] = Field(description='标签')
    instrument_type: List[str] = Field(description='仪器类型')
    supported_instrument: List[str] = Field(description='支持的仪器')
    dependences: List[DependencyInfo] = Field(description='依赖列表')
    app_note: str = Field(description='应用说明')


# ==================== 构建相关Message消息模型 ====================

class LinkType(Enum):
    """连接类型枚举"""

    CONNECT = 'CONNECT'  # 连接
    REGISTER = 'REGISTER'  # 注册
    UNREGISTER = 'UNREGISTER'  # 取消注册
    HEARTBEAT = 'HEARTBEAT'  # 心跳
    DISCONNECT = 'DISCONNECT'  # 断开连接

    REQ = 'REQ'  # 请求
    REP = 'REP'  # 响应
    PUB = 'PUB'  # 发布
    SUB = 'SUB'  # 订阅
    STREAM = 'Stream'  # 流


class MessageStatus(Enum):
    """消息状态枚举"""

    START = 'START'  # 开始
    CONTEXT = 'CONTEXT'  # 内容
    PING = 'PING'  # 心跳
    PONG = 'PONG'  # 心跳响应
    END = 'END'  # 结束
    ERROR = 'ERROR'  # 错误


class MessageMeta(BaseModel):
    """消息元数据"""

    link_type: Optional[LinkType] = None
    status: Optional[MessageStatus] = None
    topic: Optional[str] = None
    msg_id: Optional[str] = None
    timestamp: Optional[str] = datetime.now().isoformat()

    def model_post_init(self, __context: Any) -> None:
        """
        Pydantic模型初始化后处理

        在Pydantic BaseModel中，使用model_post_init来处理初始化后的逻辑
        """
        # 如果msg_id为空且link_type存在，则生成默认msg_id
        if not self.msg_id or self.msg_id == '':
            self.msg_id = f'{self.link_type.value.lower()}-{uuid.uuid4().hex[:8]}'

        # 如果timestamp为空，则设置为当前时间
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        result = {
            'link_type': self.link_type.value,
            'status': self.status.value,
            'topic': self.topic,
            'msg_id': self.msg_id,
        }

        # 处理timestamp - 如果是datetime对象则转换为ISO字符串
        if self.timestamp is not None:
            if hasattr(self.timestamp, 'isoformat'):
                result['timestamp'] = self.timestamp.isoformat()
            else:
                result['timestamp'] = self.timestamp

        return result

    def validate(self) -> None:
        """验证消息元数据"""
        if not self.topic or self.topic == '':
            raise ValueError('Topic can not be empty')

class Message(BaseModel):
    """消息类"""

    meta: Optional[MessageMeta] = None
    context: Optional[Dict[str, Any]] = {}

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {'meta': self.meta.to_dict(), 'context': self.context or {}}

    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False)

    def validate(self) -> None:
        """验证消息"""
        self.meta.validate()

    def is_request(self) -> bool:
        """是否为请求消息"""
        return self.meta.link_type == LinkType.REQ

    def is_response(self) -> bool:
        """是否为响应消息"""
        return self.meta.link_type == LinkType.REP

    def is_publish(self) -> bool:
        """是否为发布消息"""
        return self.meta.link_type == LinkType.PUB

    def is_subscribe(self) -> bool:
        """是否为订阅消息"""
        return self.meta.link_type == LinkType.SUB

    def is_stream(self) -> bool:
        """是否为流消息"""
        return self.meta.link_type == LinkType.STREAM

    def is_connect(self) -> bool:
        """是否为连接消息"""
        return self.meta.link_type == LinkType.CONNECT

    def is_register(self) -> bool:
        """是否为注册消息"""
        return self.meta.link_type == LinkType.REGISTER

    def is_unregister(self) -> bool:
        """是否为取消注册消息"""
        return self.meta.link_type == LinkType.UNREGISTER

    def is_disconnect(self) -> bool:
        """是否为断开连接消息"""
        return self.meta.link_type == LinkType.DISCONNECT

    def is_heartbeat(self) -> bool:
        """是否为心跳消息"""
        return self.meta.link_type == LinkType.HEARTBEAT

    def is_start(self) -> bool:
        """是否为开始消息"""
        return self.meta.status == MessageStatus.START

    def is_end(self) -> bool:
        """是否为结束消息"""
        return self.meta.status == MessageStatus.END

    def is_error(self) -> bool:
        """是否为错误消息"""
        return self.meta.status == MessageStatus.ERROR

    def is_context(self) -> bool:
        """是否为内容消息"""
        return self.meta.status == MessageStatus.CONTEXT

    def is_ping(self) -> bool:
        """是否为心跳消息"""
        return self.meta.status == MessageStatus.PING

    def is_pong(self) -> bool:
        """是否为心跳响应消息"""
        return self.meta.status == MessageStatus.PONG

    def create_response(self, context_data: Optional[Dict[str, Any]] = None) -> 'Message':
        """创建响应消息"""
        response_meta = MessageMeta(
            link_type=LinkType.REP, status=MessageStatus.END, topic=self.meta.topic, msg_id=self.meta.msg_id
        )
        response_context = context_data or {'status': 'success'}
        return Message(meta=response_meta, context=response_context)

    def create_error_response(self, error_message: str, error_code: int = 0x00000) -> 'Message':
        """创建错误响应消息"""
        error_meta = MessageMeta(
            link_type=self.meta.link_type,
            status=MessageStatus.ERROR,
            topic=self.meta.topic,
            msg_id=self.meta.msg_id,
        )
        error_context = {
            'status': 'error',
            'message': error_message,
            'code': error_code,
            # "timestamp": datetime.utcnow().isoformat()
        }

        return Message(meta=error_meta, context=error_context)


# 预定义的消息工厂函数


def create_link_message(
    link_type: LinkType,
    status: MessageStatus,
    response_data: Dict[str, Any],
    topic: str = 'FRAMEWORK::CONNECTION::CONNECT',
) -> Message:
    """创建链接消息"""
    meta = MessageMeta(link_type=link_type, status=status, topic=topic)
    context = response_data
    return Message(meta=meta, context=context)
