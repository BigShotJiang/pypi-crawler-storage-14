"""Internal API for internal use"""

from typing import Any

from ..config import UV_APP_CONFIG
from ..framework import UV_APP
from ..framework.attribute import BaseAttrGroup
from ..logger import UV_LOGGER
from ..modules import AppConfig, ActionInfo


app = UV_APP


@app.action(description='get app info')
def get_app_config() -> 'AppConfig':
    """获取应用配置

    Returns:
        AppConfig: 应用配置
    """
    return UV_APP_CONFIG.app_config


@app.action(description='get app action details')
def get_all_action_details() -> dict[str, ActionInfo]:
    """获取应用action详情

    Returns:
        dict[str, ActionInfo]: action详情字典
    """
    return UV_APP._actions.copy()


@app.action(description='get all attribute groups')
def get_all_attribute_groups() -> list[str]:
    """获取所有属性组名称

    Returns:
        list[str]: 属性组名称列表
    """
    return list(BaseAttrGroup.get_notifier().get_all_attribute_groups())


@app.action(description='trigger once attributes snapshot push for a group')
def trig_attributes_snapshot(group_name: str) -> bool:
    """触发一次属性快照推送

    Args:
        group_name: 属性组名

    Returns:
        bool: 是否成功推送
    """
    return BaseAttrGroup.get_notifier().push_attributes_snapshot(group_name)


@app.action(description='get attribute value by path')
def get_attribute(attribute_path: str) -> Any:
    """获取属性值

    Args:
        attribute_path: 属性路径，格式为 group_name.attr_name.attr_name...

    Returns:
        Any: 属性值
    """
    group_name, *attr_path_list = attribute_path.split('.')
    group = BaseAttrGroup.get_notifier().get_registered_attribute_group(group_name)
    if group is None:
        UV_LOGGER.debug(f'Attribute group {group_name} not found, {attribute_path=}')
        return None
    instance = group()
    for attr_name in attr_path_list:
        if not hasattr(instance, attr_name):
            UV_LOGGER.debug(f'Attribute {attr_name} not found in group {group_name}, {attribute_path=}')
            return None
        instance = getattr(instance, attr_name)
    return instance


@app.action(description='set attribute value by path')
def set_attribute(attribute_path: str, value: Any) -> bool:
    """设置属性值

    Args:
        attribute_path: 属性路径，格式为 group_name.attr_name.attr_name...
        value: 属性值

    Returns:
        bool: 是否成功设置
    """
    group_name, *attr_path_list = attribute_path.split('.')
    if not attr_path_list:
        UV_LOGGER.debug(
            f'Can not set attribute value by path {attribute_path}, {value=}, because attribute path is empty'
        )
        return False

    group = BaseAttrGroup.get_notifier().get_registered_attribute_group(group_name)
    if group is None:
        UV_LOGGER.debug(f'Attribute group {group_name} not found, {attribute_path=}, {value=}')
        return False
    instance = group()
    for idx, attr_name in enumerate(attr_path_list):
        if not hasattr(instance, attr_name):
            UV_LOGGER.debug(f'Attribute {attr_name} not found in group {group_name}, {attribute_path=}')
            return False
        if idx == len(attr_path_list) - 1:
            setattr(instance, attr_name, value)
            break
        else:
            instance = getattr(instance, attr_name)
    return True
