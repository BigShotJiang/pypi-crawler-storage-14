from .config import UV_APP_CONFIG
from .framework import UV_APP, UVAppService, BaseAttrGroup, SubAttrGroup, TrackedDict, TrackedList
from .logger import UV_LOGGER, get_logger, log_api_request, log_database_operation, LogContext

# 从已安装的包元数据中获取版本号
try:
    from importlib.metadata import version

    __version__ = version('uvapi')
except Exception:
    # 如果包未安装（开发模式），使用默认版本
    __version__ = '0.0.0+dev'

__all__ = [
    'UV_APP',
    'UV_APP_CONFIG',
    'UVAppService',
    'BaseAttrGroup',
    'SubAttrGroup',
    'TrackedDict',
    'TrackedList',
    'UV_LOGGER',
    'get_logger',
    'log_api_request',
    'log_database_operation',
    'LogContext',
    '__version__',
]
