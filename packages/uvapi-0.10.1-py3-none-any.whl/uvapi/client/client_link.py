"""MessageBus客户端链接实现

提供连接到平台MessageBus，支持：
- Client注册和心跳维持
- 命令接收收发
- PUB-SUB模式的数据订阅和接收ZMQ原生
"""

import threading
import time
import logging
import traceback
from typing import Dict, Optional, Any, Set, Tuple
from queue import Queue
from datetime import datetime
from dataclasses import dataclass
from enum import Enum

import zmq
import ormsgpack
from pydantic import BaseModel

from ..modules import Message, MessageMeta, LinkType, MessageStatus


class LinkConfig(BaseModel):
    """MessageBus客户端链接配置"""

    # worker信息
    worker_id: str = '0x0001'
    worker_name: str = 'worker_name'
    version: str = '0.0.1'
    imm_link: bool = False  # 是否是即时链接到messagebus

    # 服务器地址配置
    server_host: str = 'localhost'
    connect_port: int = 14000
    command_port: int = 14001
    data_publish_port: int = 14002  # PUB-SUB数据发布端口
    stream_port: int = 14003  # Stream传输端口

    # ZMQ配置
    zmq_linger: int = 50  # 更快的Socket关闭等待时间
    zmq_rcv_hwm: int = 10000  # 接收高水位标记
    zmq_snd_hwm: int = 10000  # 发送高水位标记

    # 发布配置
    publish_timeout: float = 10.0  # 发布超时时间（秒）

    # 重连配置
    reconnect_interval: float = 5.0  # 重连间隔时间（秒）
    reconnect_max_attempts: int = 999  # 最大重连次数

    # 心跳配置
    heartbeat_interval: float = 3.0  # 心跳间隔时间（秒）
    heartbeat_timeout: float = 10.0  # 心跳超时时间（秒）
    heartbeat_max_missed: int = 1  # 最大心跳丢失次数


class LinkConnectionState(Enum):
    """客户端连接状态"""

    DISCONNECTED = 'disconnected'
    CONNECTING = 'connecting'
    CONNECTED = 'connected'
    DISCONNECTING = 'disconnecting'


class Link:
    """MessageBus客户端链接"""

    def __init__(self, config: Optional[LinkConfig] = None, logger: logging.Logger = None) -> None:
        """初始化客户端链接"""
        self.config = config or LinkConfig()

        self.logger = logger or logging.getLogger('messagebus_client_link')

        # 消息处理回调函数 - 用于处理接收到的消息
        self._message_receive_callback = None
        # 连接状态
        self.state = LinkConnectionState.DISCONNECTED
        self.last_heartbeat = None

        self.heartbeat_failures = 0

        # ZMQ上下文和Socket
        self.context = zmq.Context()
        self.connect_socket = None  # DEALER -> ROUTER (连接管理)
        self.command_socket = None  # DEALER -> ROUTER (命令)
        self.data_socket = None  # SUB -> PUB (数据订阅)
        self.stream_socket = None  # DEALER -> ROUTER (流传输)

        # 线程管理
        self.running = False
        self.threads = []

        # 为不同消息传输类型创建独立的锁
        self.connection_lock = threading.Lock()  # 连接管理锁（connect/disconnect/heartbeat）
        # 消息队列
        self.command_queue = Queue()

        self.data_queue = Queue()  # 接收订阅的数据消息

        self.stream_data_queue = Queue()  # 自动读取的Stream数据队列

        # 订阅管理
        self.subscriptions: Set[str] = set()  # 当前订阅的主题
        # 统计信息
        self.stats = {
            'connections_sent': 0,
            'connections_received': 0,
            'commands_sent': 0,
            'commands_received': 0,
            'subscriptions_sent': 0,
            'data_messages_sent': 0,
            'data_messages_received': 0,
            'stream_messages_sent': 0,
            'stream_messages_received': 0,
            'heartbeats_sent': 0,
            'heartbeats_received': 0,
            'heartbeat_failures': 0,
            'connection_errors': 0,
            'last_error': None,
        }

        if not self._setup_connect_socket():
            raise ConnectionError('Link Connect Socket Setup Failed')

    def _setup_connect_socket(self) -> bool:
        """设置连接端口Socket"""
        with self.connection_lock:
            try:
                if self.connect_socket:
                    self.connect_socket.close()
                self.connect_socket = self.context.socket(zmq.DEALER)
                self.connect_socket.setsockopt(zmq.IDENTITY, self.config.worker_id.encode())
                self.connect_socket.setsockopt(zmq.LINGER, self.config.zmq_linger)
                self.connect_socket.setsockopt(zmq.RCVHWM, self.config.zmq_rcv_hwm)
                self.connect_socket.setsockopt(zmq.SNDHWM, self.config.zmq_snd_hwm)
                self.connect_socket.connect(f'tcp://{self.config.server_host}:{self.config.connect_port}')
                return True
            except Exception as e:
                self.logger.debug(f'Link Connect Socket Setup Failed: {e}')
                return False

    def _setup_sockets(self) -> bool:
        """设置Socket连接"""
        try:
            if not self.command_socket:
                self.command_socket = self.context.socket(zmq.DEALER)
                self.command_socket.setsockopt(zmq.IDENTITY, self.config.worker_id.encode())
                self.command_socket.setsockopt(zmq.LINGER, self.config.zmq_linger)
                self.command_socket.setsockopt(zmq.RCVHWM, self.config.zmq_rcv_hwm)
                self.command_socket.setsockopt(zmq.SNDHWM, self.config.zmq_snd_hwm)
                self.command_socket.connect(f'tcp://{self.config.server_host}:{self.config.command_port}')
            if not self.data_socket:
                self.data_socket = self.context.socket(zmq.SUB)
                self.data_socket.setsockopt(zmq.IDENTITY, self.config.worker_id.encode())
                self.data_socket.setsockopt(zmq.LINGER, self.config.zmq_linger)
                self.data_socket.setsockopt(zmq.RCVHWM, self.config.zmq_rcv_hwm)
                self.data_socket.setsockopt(zmq.SNDHWM, self.config.zmq_snd_hwm)
                self.data_socket.connect(f'tcp://{self.config.server_host}:{self.config.data_publish_port}')
            if not self.stream_socket:
                self.stream_socket = self.context.socket(zmq.DEALER)
                self.stream_socket.setsockopt(zmq.IDENTITY, self.config.worker_id.encode())
                self.stream_socket.setsockopt(zmq.LINGER, self.config.zmq_linger)
                self.stream_socket.setsockopt(zmq.RCVHWM, self.config.zmq_rcv_hwm)
                self.stream_socket.setsockopt(zmq.SNDHWM, self.config.zmq_snd_hwm)
                self.stream_socket.connect(f'tcp://{self.config.server_host}:{self.config.stream_port}')

            return True
        except Exception as e:
            self.logger.debug(f'Link Socket Setup Failed: {e}')
            return False

    # ==================== 连接相关====================
    def connect(self) -> bool:
        """连接到MessageBus"""
        self.state = LinkConnectionState.CONNECTING
        self.logger.debug('Starting to connect to MessageBus')

        try:
            # 连接到MessageBus
            if not self._connect_client():
                self.state = LinkConnectionState.DISCONNECTED
                return False

            self.state = LinkConnectionState.CONNECTED

            # 启动后台线程
            if not self._start_background_threads():
                self.logger.debug('Failed to start background threads')
                self._stop_background_threads()  # 清理已启动的线程

                self.state = LinkConnectionState.DISCONNECTED
                return False

            self.logger.debug('Successfully connected to MessageBus')

            return True

        except Exception as e:
            self.logger.debug(f'Connection failed: {e}')
            self.state = LinkConnectionState.DISCONNECTED
            self.stats['connection_errors'] += 1
            self.stats['last_error'] = str(e)
            return False

    def disconnect(self) -> bool:
        """断开连接"""
        if self.state == LinkConnectionState.DISCONNECTED:
            return True
        self.state = LinkConnectionState.DISCONNECTING
        time.sleep(1)
        self.logger.debug('Disconnecting from MessageBus')

        try:
            with self.connection_lock:
                # 发送断开连接消息
                if self.connect_socket and not self.connect_socket.closed:
                    self._send_connect_message('DISCONNECT', {'worker_id': self.config.worker_id})

                    # 等待服务器确认（可选）
                if self.connect_socket.poll(timeout=2000):  # 2秒超时
                    try:
                        response = self.connect_socket.recv_multipart()
                        response_meta, response_context = self._parse_message(response[-1])
                        if (
                            response_meta.link_type != LinkType.DISCONNECT
                            or response_meta.status != MessageStatus.END
                            or response_context.get('status') != 'success'
                        ):
                            self.logger.debug(
                                f'Server disconnect confirmation exception: {response_context.get("message", "Unknown error")}'
                            )
                    except Exception as e:
                        self.logger.debug(f'Failed to parse disconnect response: {e}')

                    # 停止后台线程
            self._stop_background_threads()

            # 关闭Socket连接
            self._close_sockets()

            self.state = LinkConnectionState.DISCONNECTED
            self.logger.debug('Successfully disconnected')
            return True

        except Exception as e:
            self.logger.debug(f'Failed to disconnect: {e}')
            self.state = LinkConnectionState.DISCONNECTED
            return False

    def _connect_client(self) -> bool:
        """连接到MessageBus"""
        with self.connection_lock:
            try:
                connect_data = {
                    'worker_id': self.config.worker_id,
                    'worker_name': self.config.worker_name,
                    'version': self.config.version,
                    'heartbeat_interval': self.config.heartbeat_interval,
                }

                # 发送连接消息
                self._send_connect_message('CONNECT', connect_data)

                # 等待连接响应
                if self.connect_socket.poll(timeout=10000):  # 5秒超时
                    response = self.connect_socket.recv_multipart()

                    # 标准响应格式：[response_data]
                    response_meta, response_context = self._parse_message(response[-1])

                    if (
                        response_meta.link_type == LinkType.CONNECT
                        and response_meta.status == MessageStatus.END
                        and response_context.get('status') == 'success'
                    ):
                        self.logger.debug('Client connection successful')

                        self.config.command_port = response_context.get('command_port')
                        self.config.data_publish_port = response_context.get('data_publish_port')
                        self.config.stream_port = response_context.get('stream_port')
                        if not self._setup_sockets():
                            return False
                        return True
                    elif (
                        response_meta.link_type == LinkType.HEARTBEAT
                        and response_meta.status == MessageStatus.PONG
                        and response_context.get('status') == 'success'
                    ):
                        self.logger.debug('Heartbeat response successful')
                        return True
                    else:
                        self.logger.debug(
                            f'Connection failed: {response_context.get("message", "Unknown error")}'
                        )
                        return False
                else:
                    self.logger.debug('Connection timeout')
                    return False

            except Exception as e:
                self.logger.debug(f'Connection failed: {e}')
                traceback.print_exc()
                return False

    def _send_connect_message(
        self, msg_type: str, data: Dict[str, Any] = None, topic: str = 'FRAMEWORK::CONNECTION::CONNECT'
    ) -> None:
        """发送连接消息 - 使用统一的FRAMEWORK::CONNECTION::CONNECT主题"""
        try:
            # 根据消息类型确定status和link_type - 简化版
            if msg_type == 'HEARTBEAT':
                status = MessageStatus.PING
                link_type = LinkType.HEARTBEAT
            elif msg_type == 'CONNECT':
                status = MessageStatus.START
                link_type = LinkType.CONNECT
            elif msg_type == 'REGISTER':
                status = MessageStatus.START
                link_type = LinkType.REGISTER
            elif msg_type == 'UNREGISTER':
                status = MessageStatus.START
                link_type = LinkType.UNREGISTER
            elif msg_type == 'DISCONNECT':
                status = MessageStatus.START
                link_type = LinkType.DISCONNECT
            else:
                raise ValueError(f'无效的消息类型: {msg_type}')

            enhanced_data = data.copy()
            # enhanced_data["operation_type"] = msg_type.lower()

            # 创建标准Message对象
            meta = MessageMeta(
                link_type=link_type,
                status=status,
                topic=topic,
                msg_id=f'link-{msg_type.lower()}-{datetime.now().timestamp():.0f}',
            )

            context = enhanced_data
            message = Message(meta=meta, context=context)

            # 序列化并发送
            packed_data = ormsgpack.packb(message.to_dict())
            self.connect_socket.send_multipart([packed_data])
            self.stats['connections_sent'] += 1

        except Exception as e:
            self.logger.debug(f'Failed to send connect message: {e}')
            traceback.print_exc()

    def _start_background_threads(self) -> bool:
        """启动后台线程"""
        self.running = True
        started_threads = 0
        total_threads = 0

        try:
            # 心跳线程
            total_threads += 1
            heartbeat_thread = threading.Thread(target=self._heartbeat_worker, daemon=True)
            heartbeat_thread.start()
            self.threads.append(heartbeat_thread)
            started_threads += 1
            self.logger.debug('Heartbeat thread started successfully')

            # 命令接收线程
            total_threads += 1
            command_thread = threading.Thread(target=self._command_receiver, daemon=True)
            command_thread.start()
            self.threads.append(command_thread)
            started_threads += 1
            self.logger.debug('Command receiver thread started successfully')

            # 数据接收线程
            total_threads += 1
            data_thread = threading.Thread(target=self._data_receiver, daemon=True)
            data_thread.start()
            self.threads.append(data_thread)
            started_threads += 1
            self.logger.debug('Data receiver thread started successfully')

            # 共享内存接收线程
            total_threads += 1
            shared_memory_thread = threading.Thread(target=self._shared_memory_receiver, daemon=True)
            shared_memory_thread.start()
            self.threads.append(shared_memory_thread)
            started_threads += 1
            self.logger.debug('Shared memory receiver thread started successfully')

            self.logger.debug(f'Background threads started successfully: {started_threads}/{total_threads}')
            return started_threads == total_threads

        except Exception as e:
            self.logger.debug(f'Failed to start background threads: {e}')
            self.logger.debug(f'Started threads: {started_threads}/{total_threads}')
            return False

    def _stop_background_threads(self) -> None:
        """停止后台线程"""
        self.logger.debug('Stopping background threads...')
        self.running = False

        # 等待所有线程结束
        for thread in self.threads:
            if thread.is_alive():
                self.logger.debug(f'Waiting for thread to end: {thread.name}')
                thread.join(timeout=2.0)  # 最多等待2秒

                if thread.is_alive():
                    self.logger.debug(f'Thread did not end normally: {thread.name}')

        self.threads.clear()
        self.logger.debug('Background threads stopped successfully')

    def set_message_receive_callback(self, callback: Any) -> None:
        """
        设置消息接收回调函数

        Args:
            callback: 回调函数，接收 Message 对象作为参数
        """
        self._message_receive_callback = callback
        self.logger.debug('Message receive callback function set')

    def _close_sockets(self) -> None:
        """关闭Socket连接"""
        with self.connection_lock:
            for socket in [self.connect_socket, self.command_socket, self.data_socket, self.stream_socket]:
                if socket and not socket.closed:
                    socket.close()

    def _parse_message(self, message: bytes) -> Tuple[MessageMeta, Dict[str, Any]]:
        """解析消息"""
        parsed_data = ormsgpack.unpackb(message)
        message_obj = Message(**parsed_data)
        return message_obj.meta, message_obj.context

    def _heartbeat_worker(self) -> None:
        """心跳线程"""
        self.logger.debug('Heartbeat thread started, interval: %s seconds', self.config.heartbeat_interval)
        while self.running and self.state == LinkConnectionState.CONNECTED:
            try:
                # 等待心跳间隔
                interval = self.config.heartbeat_interval
                for _ in range(int(interval * 10)):  # 🔧 修复：转换为整数
                    if not self.running or self.state != LinkConnectionState.CONNECTED:
                        break
                    time.sleep(0.1)

                with self.connection_lock:
                    self._heartbeat_checker()
                    # 检查是否需要重连
                if self.heartbeat_failures >= self.config.heartbeat_max_missed:
                    self.logger.debug('Heartbeat failures too many, possible reconnection needed')
                    self.state = LinkConnectionState.DISCONNECTING
                    if not self._reconnect():
                        self.state = LinkConnectionState.DISCONNECTED
                        break
                    continue

            except Exception as e:
                self.logger.debug(f'Heartbeat send failed: {e}')
                self.stats['heartbeat_failures'] += 1
                self.heartbeat_failures += 1
                time.sleep(1)

    def _heartbeat_checker(self) -> None:
        """心跳检查"""
        # 发送心跳
        heartbeat_time = datetime.now()
        heartbeat_data = {'worker_id': self.config.worker_id}

        self._send_connect_message('HEARTBEAT', heartbeat_data)
        self.last_heartbeat = heartbeat_time
        self.stats['heartbeats_sent'] += 1

        # 等待心跳响应（可选）

        if self.connect_socket.poll(timeout=self.config.heartbeat_timeout):
            response = self.connect_socket.recv_multipart()
            response_meta, response_context = self._parse_message(response[-1])
            if (
                (response_meta.link_type == LinkType.HEARTBEAT
                or response_meta.link_type == LinkType.CONNECT)
                and response_context.get('status') == 'success'
            ):
                self.stats['heartbeats_received'] += 1
                self.heartbeat_failures = 0  # 重置失败计数
                self.logger.debug(f'Heartbeat response successful #{self.stats["heartbeats_received"]}')
            else:
                self.heartbeat_failures += 1
                self.logger.debug(
                    f'Heartbeat response failed, consecutive failures: {self.heartbeat_failures}, response: {response_context}'
                )
        else:
            self.heartbeat_failures += 1
            self.logger.debug(
                f'Receive heartbeat response timeout or failed, consecutive failures: {self.heartbeat_failures}'
            )

    def _reconnect(self) -> bool:
        """重连"""
        for _ in range(self.config.reconnect_max_attempts):
            time.sleep(self.config.reconnect_interval)

            self.state = LinkConnectionState.CONNECTING
            self.logger.debug('Starting to reconnect to MessageBus')
            if self._connect_client():
                self.logger.debug('Reconnection successful')
                self.state = LinkConnectionState.CONNECTED
                self.heartbeat_failures = 0
                return True
            else:
                self.logger.debug('Reconnection failed')
        return False

    def send_register_message(self, topic: str, is_recv: bool = False) -> bool:
        """发送注册消息"""
        # 等待连接响应
        with self.connection_lock:
            self._send_connect_message('REGISTER', {'is_recv': is_recv}, topic)

            if self.connect_socket.poll(timeout=10000):  # 5秒超时
                response = self.connect_socket.recv_multipart()

                # 标准响应格式：[response_data]
                response_meta, response_context = self._parse_message(response[-1])

                if (
                    response_meta.link_type == LinkType.REGISTER
                    and response_meta.status == MessageStatus.END
                    and response_context.get('status') == 'success'
                ):
                    self.logger.debug('Topic registration successful')
                    return True
                else:
                    self.logger.debug(
                        f'Registration failed: {response_context.get("message", "Unknown error")}'
                    )
                    return False
            else:
                self.logger.debug('Registration timeout')
                return False

    def send_unregister_message(self, topic: str) -> bool:
        """发送取消注册消息"""
        with self.connection_lock:
            self._send_connect_message('UNREGISTER', {}, topic)
            if self.connect_socket.poll(timeout=10000):  # 5秒超时
                response = self.connect_socket.recv_multipart()
                response_meta, response_context = self._parse_message(response[-1])
                if (
                    response_meta.link_type == LinkType.UNREGISTER
                    and response_meta.status == MessageStatus.END
                    and response_context.get('status') == 'success'
                ):
                    self.logger.debug('Topic unregistration successful')
                    return True
                else:
                    self.logger.debug(
                        f'Unregistration failed: {response_context.get("message", "Unknown error")}'
                    )
                    return False
            else:
                self.logger.debug('Unregistration timeout')
                return False

    # ==================== 消息发送====================
    def send_message(self, message: Message) -> bool:
        """发送消息"""
        packed_data = ormsgpack.packb(message.to_dict())

        if message.meta.link_type == LinkType.REQ or message.meta.link_type == LinkType.REP:
            self.command_socket.send_multipart([packed_data])
            self.stats['commands_sent'] += 1
        elif message.meta.link_type == LinkType.PUB:
            self.command_socket.send_multipart([packed_data])
            self.stats['data_messages_sent'] += 1
        elif message.meta.link_type == LinkType.STREAM:
            self.stream_socket.send_multipart([packed_data])
            self.stats['stream_messages_sent'] += 1
        else:
            self.logger.debug(f'Unsupported message type: {message.meta.link_type}')
            return False
        return True

    # =======================================================
    # ==================== Command 接收====================
    def _command_receiver(self) -> None:
        while self.running:
            # 检查连接状态
            if self.state == LinkConnectionState.DISCONNECTED:
                break
            elif self.state != LinkConnectionState.CONNECTED:
                time.sleep(0.1)  # 等待状态变化
                continue
            try:
                if self.command_socket.poll(timeout=100):  # 1000ms超时
                    message = self.command_socket.recv_multipart()

                    # 处理ROUTER-DEALER消息格式
                    # DEALER socket接收时会自动去掉identity帧
                    if len(message) >= 1:
                        # 标准格式: 只有一帧消息数据
                        message_data = message[-1]
                        data = ormsgpack.unpackb(message_data)
                        self._command_process(data)

                        self.stats['commands_received'] += 1

                    else:
                        self.logger.debug(
                            f'Received malformed command message, frame count: {len(message)}'
                        )
                        continue

            except Exception as e:
                self.logger.debug(f'Command receive failed: {e}')

    def _command_process(self, message_data: Any) -> None:
        """处理命令消息"""
        # 通过回调函数处理消息
        if self._message_receive_callback:
            try:
                message_obj = Message(**message_data)
                self._message_receive_callback(message_obj)
            except Exception as e:
                self.logger.debug(f'Message callback processing command message failed: {e}')
                # 失败时仍放入队列作为备选
                self.command_queue.put(message_data)
        else:
            # 没有设置回调时使用队列
            self.command_queue.put(message_data)

    # ==================== PUB-SUB 接收====================
    def _subscribe_topic(self, topic: str) -> bool:
        """订阅主题（使用ZMQ原生SUB socket）

        Args:
            topic: 要订阅的主题
        Returns:
            bool: 是否订阅成功
        """
        try:
            if not self.data_socket:
                self.logger.debug('Data socket not initialized, cannot subscribe')
                return False

            # 使用ZMQ原生订阅
            self.data_socket.setsockopt(zmq.SUBSCRIBE, topic.encode('utf-8'))

            # 添加到本地订阅记录
            self.subscriptions.add(topic)

            # 更新统计
            self.stats['subscriptions_sent'] += 1

            self.logger.debug(f'Subscribed to topic: {topic}')
            return True

        except Exception as e:
            self.logger.debug(f'Failed to subscribe to topic {topic}: {e}')
            return False

    def _unsubscribe_topic(self, topic: str) -> bool:
        """
        取消订阅主题

        Args:
            topic: 要取消订阅的主题

        Returns:
            bool: 是否取消订阅成功
        """
        try:
            if not self.data_socket:
                self.logger.debug('Data socket not initialized, cannot unsubscribe')
                return False

            # 使用ZMQ原生取消订阅
            self.data_socket.setsockopt(zmq.UNSUBSCRIBE, topic.encode('utf-8'))

            # 从本地订阅记录中移除
            self.subscriptions.discard(topic)

            self.logger.debug(f'Unsubscribed from topic: {topic}')
            return True

        except Exception as e:
            self.logger.debug(f'Failed to unsubscribe from topic {topic}: {e}')
            return False

    def _data_receiver(self) -> None:
        """数据接收线程（PUB-SUB模式）"""
        while self.running:
            # 检查连接状态
            if self.state == LinkConnectionState.DISCONNECTED:
                break
            elif self.state != LinkConnectionState.CONNECTED:
                time.sleep(0.1)  # 等待状态变化
                continue
            try:
                if self.data_socket.poll(timeout=100):  # 100ms超时
                    message = self.data_socket.recv_multipart()

                    # 处理PUB-SUB消息格式: [topic, message_data]
                    if len(message) >= 2:
                        topic_bytes, message_data = message[0], message[1]
                        topic = topic_bytes.decode('utf-8')
                        data = ormsgpack.unpackb(message_data)

                        self.stats['data_messages_received'] += 1

                        self._data_process(data)

                        self.logger.debug(
                            f'Received data message: topic={topic}, timestamp={data.get("timestamp", "N/A")}'
                        )
                    else:
                        self.logger.debug(f'Received malformed data message, frame count: {len(message)}')

            except Exception as e:
                if self.running:  # 只有在运行状态才记录错误
                    self.logger.debug(f'Data receive failed: {e}')

    def _data_process(self, message_data: Any) -> None:
        """处理数据消息"""
        # 通过回调函数处理消息
        if self._message_receive_callback:
            try:
                message_obj = Message(**message_data)
                self._message_receive_callback(message_obj)
            except Exception as e:
                self.logger.debug(f'Message callback processing data message failed: {e}')
                # 失败时仍放入队列作为备选
                self.data_queue.put(message_data)
        else:
            # 没有设置回调时使用队列
            self.data_queue.put(message_data)

    # ==================== Stream 接收====================
    def _shared_memory_receiver(self) -> None:
        """Stream消息接收线程 - 统一接收，不分类处理"""
        while self.running:
            # 检查连接状态
            if self.state == LinkConnectionState.DISCONNECTED:
                break
            elif self.state != LinkConnectionState.CONNECTED:
                time.sleep(0.1)  # 等待状态变化
                continue
            try:
                if self.stream_socket and self.stream_socket.poll(timeout=100):  # 100ms超时
                    message = self.stream_socket.recv_multipart()

                    # Stream端口接收格式: [message_data]
                    if len(message) >= 1:
                        message_data = message[-1]
                        data = ormsgpack.unpackb(message_data)

                        self._stream_process(data)

                        # 更新统计
                        self.stats['stream_messages_received'] += 1

                    else:
                        self.logger.debug(f'Received malformed stream message, frame count: {len(message)}')

            except Exception as e:
                if self.running:  # 只有在运行状态才记录错误
                    self.logger.debug(f'Stream message receive failed: {e}')

    def _stream_process(self, message_data: Any) -> None:
        """处理Stream消息"""
        # 通过回调函数处理消息
        if self._message_receive_callback:
            try:
                message_obj = Message(**message_data)
                self._message_receive_callback(message_obj)
            except Exception as e:
                self.logger.debug(f'Message callback processing stream message failed: {e}')
                # 失败时仍放入队列作为备选
                self.stream_data_queue.put(message_data)
        else:
            # 没有设置回调时使用队列
            self.stream_data_queue.put(message_data)
