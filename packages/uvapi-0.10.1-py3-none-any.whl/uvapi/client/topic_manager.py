"""
Topic 管理器
支持按主题管理 reqrep/pubsub/stream 通信
"""  # noqa: D205

import time
import logging
import threading
import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from queue import Queue
from enum import Enum

from ..modules import Message, LinkType, MessageMeta, MessageStatus
from .client_link import Link, LinkConfig
from .shared_memory_manager import SharedMemoryManager


class TopicType(Enum):
    """主题类型枚举"""

    REQ = 'REQ'
    REP = 'REP'
    STREAM = 'STREAM'
    PUBSUB = 'PUBSUB'


class TopicHandler:
    """主题处理器 - 管理单个主题下的不同类型消息"""

    def __init__(self, topic: str, link: Link, logger: logging.Logger = None) -> None:
        """初始化主题处理器

        Args:
            topic: 主题
            link: 链接
            logger: 日志记录器
        """
        if logger is None:
            logger = logging.getLogger('topic_handler')
        self.topic = topic
        self.send_queue = Queue(maxsize=1000)
        self.receive_queue = Queue(maxsize=1000)
        self.link = link
        # 用于存储等待响应的消息ID和对应的响应队列
        self.pending_responses: Dict[str, Queue] = {}
        self.response_lock = threading.RLock()
        self.logger = logger

    def get_topic(self) -> str:
        """获取主题"""
        return self.topic

    def send_message(self, message: Message) -> bool:
        """发送消息"""
        raise NotImplementedError('send_message Not Implemented')

    def execute_message(self, message: Message, timeout: float = 1.0) -> Message | None:
        """执行消息,一发一收"""
        raise NotImplementedError('execute_message Not Implemented')

    def receive_message(self, timeout: float = 1.0) -> Message | None:
        """接收消息"""
        try:
            message = self.receive_queue.get(timeout=timeout)
        except Exception:
            return None
        return message

    def _close(self) -> None:
        """关闭主题处理器"""
        pass


class ReqTopic(TopicHandler):
    """命令主题处理器 - 管理单个命令主题下的不同类型消息"""

    def __init__(self, topic: str, link: Link, logger: logging.Logger = None) -> None:
        """初始化命令主题处理器"""
        if logger is None:
            logger = logging.getLogger('req_topic')
        super().__init__(topic, link, logger)

    def send_message(self, message: Message) -> bool:
        """发送消息"""
        msg_id = message.meta.msg_id if message.meta else uuid.uuid4().hex[:8]
        meta_info = {
            'link_type': LinkType.REQ,
            'status': MessageStatus.START,
            'topic': self.topic,
            'msg_id': msg_id,
            'timestamp': datetime.now().isoformat(),
        }
        message_meta = MessageMeta(**meta_info)

        message_send = Message(meta=message_meta, context=message.context)

        response_queue = Queue(maxsize=1)
        with self.response_lock:
            self.pending_responses[msg_id] = response_queue

        self.send_queue.put_nowait(message_send)
        if self.link.send_message(message_send):
            self.send_queue.get_nowait()
            return True
        return False

    def receive_message(self, orgin_message: Message | None = None, timeout: float = 1.0) -> Message | None:
        """接收消息

        Args:
            orgin_message: 原始消息,如果为None,则从接收队列中获取消息;否则获取对应消息ID的消息
            timeout: 超时时间
        Returns:
            Message: 消息
        """
        if orgin_message is None:
            try:
                message = self.receive_queue.get(timeout=timeout)
            except Exception:
                return None
        else:
            msg_id = orgin_message.meta.msg_id
            try:
                message = self.pending_responses[msg_id].get(timeout=timeout)
            except Exception:
                return None
            finally:
                with self.response_lock:
                    if msg_id in self.pending_responses:
                        del self.pending_responses[msg_id]
        return message

    def execute_message(self, message: Message, timeout: float = 1.0) -> Message | None:
        """执行消息,一发一收 - 支持并发执行和消息ID匹配"""
        # 生成唯一的消息ID
        msg_id = message.meta.msg_id if message.meta else uuid.uuid4().hex[:8]

        meta_info = {
            'link_type': LinkType.REQ,
            'status': MessageStatus.START,
            'topic': self.topic,
            'msg_id': msg_id,
            'timestamp': datetime.now().isoformat(),
        }
        message_meta = MessageMeta(**meta_info)
        message_send = Message(meta=message_meta, context=message.context)
        if self.send_message(message_send):
            return self.receive_message(message_send, timeout)
        return None

    def excute_message(self, message: Message, timeout: float = 1.0) -> Message | None:
        """执行消息,一发一收,别名"""
        return self.execute_message(message, timeout)

    def _handle_message(self, message: Message) -> None:
        """接收消息"""
        # 首先尝试分发到等待的响应队列
        if message.meta.msg_id and message.meta.msg_id in self.pending_responses:
            with self.response_lock:
                response_queue = self.pending_responses.get(message.meta.msg_id)
                if response_queue:
                    response_queue.put_nowait(message)
        # 同时放入通用接收队列（用于非execute_message的接收）
        else:
            self.receive_queue.put_nowait(message)

    def _close(self) -> None:
        """关闭主题处理器"""
        self.link.send_unregister_message(self.topic)


class RepTopic(TopicHandler):
    """响应主题处理器 - 管理单个响应主题下的不同类型消息"""

    def __init__(self, topic: str, link: Link, logger: logging.Logger = None) -> None:
        """初始化响应主题处理器"""
        if logger is None:
            logger = logging.getLogger('rep_topic')
        super().__init__(topic, link, logger)

    def send_message(self, message: Message) -> bool:
        """发送消息"""
        if message.meta.msg_id is None:
            self.logger.debug('Message has no msg_id, cannot send')
            return False
        respone_message = message.create_response(message.context)
        self.send_queue.put_nowait(respone_message)
        if self.link.send_message(respone_message):
            self.send_queue.get_nowait()
            return True
        return False

    def receive_message(self, timeout: float = 1.0) -> Message | None:
        """接收消息"""
        try:
            message = self.receive_queue.get(timeout=timeout)
        except Exception:
            return None
        return message

    def _handle_message(self, message: Message) -> None:
        """接收消息"""
        self.receive_queue.put_nowait(message)

    def _close(self) -> None:
        """关闭主题处理器"""
        self.link.send_unregister_message(self.topic)


class PubSubTopic(TopicHandler):
    """发布订阅主题处理器 - 管理单个发布订阅主题下的不同类型消息"""

    def __init__(self, topic: str, link: Link, logger: logging.Logger = None) -> None:
        """初始化发布订阅主题处理器"""
        if logger is None:
            logger = logging.getLogger('pubsub_topic')
        super().__init__(topic, link, logger)

    def send_message(self, message: Message) -> bool:
        """发布消息"""
        meta_info = {
            'link_type': LinkType.PUB,
            'status': MessageStatus.CONTEXT,
            'topic': self.topic,
            'msg_id': '',
            'timestamp': datetime.now().isoformat(),
        }
        message_meta = MessageMeta(**meta_info)
        message_send = Message(meta=message_meta, context=message.context)
        """发布消息"""
        self.send_queue.put_nowait(message_send)
        if self.link.send_message(message_send):
            self.send_queue.get_nowait()
            return True
        return False

    def publish_message(self, message: Message) -> bool:
        """发布消息,send_message的别名"""
        return self.send_message(message)

    def subscribe(self) -> bool:
        """订阅主题"""
        return self.link._subscribe_topic(self.topic)

    def _handle_message(self, message: Message) -> None:
        """接收消息"""
        if message.meta.link_type != LinkType.PUB:
            return
        self.receive_queue.put_nowait(message)

    def _close(self) -> None:
        """关闭主题处理器"""
        self.link._unsubscribe_topic(self.topic)
        self.link.send_unregister_message(self.topic)


class StreamTopic(TopicHandler):
    """流主题处理器 - 管理单个流主题下的不同类型消息"""

    def __init__(self, topic: str, link: Link, shared_memory_manager: SharedMemoryManager, logger: logging.Logger = None) -> None:
        """初始化流主题处理器"""
        if logger is None:
            logger = logging.getLogger('stream_topic')
        super().__init__(topic, link, logger)
        self.shared_memory_manager = shared_memory_manager
        self.stream_info = None
        self.ready_to_write = True
        self.offset = 0
        self.init_stream()

    def init_stream(self) -> bool:
        """初始化流"""
        stream_id = self.link.config.worker_id + self.topic
        self.stream_info = self.shared_memory_manager.create_region(1024 * 1024, stream_id)
        if self.stream_info is None:
            return False
        return True

    def send_message(self, message: Message, timeout: float = 1.0) -> bool:
        """发送消息"""
        if self.stream_info is None:
            return False
        stream_id = self.stream_info.region_name
        file_path = self.stream_info.file_path
        data = message.context.get('data')
        if data is None or len(data) == 0:
            return False
        offset = message.context.get('offset', self.offset)
        if offset + len(data) >= self.stream_info.size:
            offset = 0
        self.offset = offset + len(data)
        seq = message.context.get('seq', 0)

        start_time = time.time()
        while not self.ready_to_write:
            if time.time() - start_time >= timeout:
                self.logger.debug('Stream not ready to write, timeout returned')
                return False
            self.logger.debug('Stream not ready to write, waiting...')
            time.sleep(0.1)  # 短暂休眠避免忙等待
        write_success = self.shared_memory_manager.write_data(stream_id, data, offset)
        if not write_success:
            self.logger.debug('Failed to write data')
            return False

        context = {
            'file_path': file_path,
            'offset': offset,
            'data_size': len(data),
            'seq': seq,
        }

        message_meta = MessageMeta(
            **{
                'link_type': LinkType.STREAM,
                'status': MessageStatus.START,
                'topic': self.topic,
                'msg_id': '',
                'timestamp': datetime.now().isoformat(),
            }
        )
        self.ready_to_write = False
        message_send = Message(meta=message_meta, context=context)
        self.send_queue.put_nowait(message_send)
        if self.link.send_message(message_send):
            self.send_queue.get_nowait()
            return True
        return False

    def receive_message(self, timeout: float = 1.0) -> Message | None:
        """接收消息"""
        try:
            message = self.receive_queue.get(timeout=timeout)
            if message.meta.status == MessageStatus.START:
                msg_id = message.meta.msg_id
                context = message.context
                file_path = context.get('file_path')
                offset = context.get('offset')
                seq = context.get('seq')
                data_size = context.get('data_size')
                data = self.shared_memory_manager.read_data_by_path(file_path, data_size, offset)
                meta_info = {
                    'link_type': LinkType.STREAM,
                    'status': MessageStatus.END,
                    'topic': self.topic,
                    'msg_id': msg_id,
                    'timestamp': datetime.now().isoformat(),
                }
                message_meta = MessageMeta(**meta_info)
                response_message = Message(meta=message_meta)
                self.link.send_message(response_message)
                return Message(
                    meta=message.meta,
                    context={
                        'seq': seq,
                        'data': data,
                    },
                )
            else:
                return message
        except Exception:
            return None

    def _handle_message(self, message: Message) -> None:
        """接收消息"""
        if message.meta.status == MessageStatus.END:
            self.ready_to_write = True
        else:
            self.receive_queue.put_nowait(message)

    def _close(self) -> None:
        """关闭主题处理器"""
        self.shared_memory_manager.close_region(self.stream_info.region_name)
        self.link.send_unregister_message(self.topic)


class TopicManager:
    """主题管理器 - 线程安全"""

    def __init__(self, config: Optional[LinkConfig] = None, logger: logging.Logger = None) -> None:
        """初始化主题管理器"""
        if logger is None:
            logger = logging.getLogger('topic_manager')
        self.logger = logger
        # 修改为支持同一个topic多种类型的handler: {topic: {TopicType: TopicHandler}}
        self.topics: Dict[str, Dict[TopicType, TopicHandler]] = {}

        self.link = Link(config=config, logger=self.logger)
        self.link.set_message_receive_callback(self.handle_receive_message)

        self.shared_memory_manager = SharedMemoryManager(config.worker_id, logger=self.logger)
        self.lock = threading.RLock()  # 可重入锁，支持同一线程多次获取
        if config.imm_link:
            self.start()

    def start(self) -> Link:
        """启动主题管理器"""
        if self.link.connect():
            self.logger.debug('Connected to server')
        else:
            self.logger.debug('Failed to connect to server')

    def stop(self) -> None:
        """停止主题管理器"""
        self.clear_topics()
        self.link.disconnect()

    def __del__(self) -> None:
        """析构函数"""
        self.stop()
        self.shared_memory_manager.close_all_regions()
        self.logger.debug('Topic manager closed')

    def register_topic(self, topic: str, topic_type: TopicType) -> TopicHandler | None:
        """注册主题
        Args:
            topic: 主题
            topic_type: 主题类型
        Returns:
            TopicHandler: 主题处理器
        """  # noqa: D205
        is_recv = True if topic_type == TopicType.REP or topic_type == TopicType.STREAM else False
        with self.lock:
            # 如果 topic 不存在，创建一个新的字典
            if self.topics.get(topic) is None:
                self.topics[topic] = {}

            # 如果该 topic_type 的 handler 已存在，直接返回
            if topic_type in self.topics[topic]:
                self.logger.debug(f'Topic {topic} with type {topic_type} already exists, returning existing handler')
                return self.topics[topic][topic_type]

            # 创建对应类型的 handler
            if topic_type == TopicType.REQ:
                handler = ReqTopic(topic, self.link, logger=self.logger)
            elif topic_type == TopicType.REP:
                handler = RepTopic(topic, self.link, logger=self.logger)
            elif topic_type == TopicType.STREAM:
                handler = StreamTopic(topic, self.link, self.shared_memory_manager, logger=self.logger)
            elif topic_type == TopicType.PUBSUB:
                handler = PubSubTopic(topic, self.link, logger=self.logger)
            else:
                self.logger.debug(f'Unknown topic type: {topic_type}')
                return None

            self.topics[topic][topic_type] = handler

            if not self.link.send_register_message(topic, is_recv):
                self.logger.debug(f'Failed to register topic {topic}')
                return None
            return handler

    def unregister_topic(self, topic: str, topic_type: Optional[TopicType] = None) -> bool:
        """取消注册主题
        Args:
            topic: 主题
            topic_type: 主题类型，如果为None则取消该topic的所有类型handler
        Returns:
            bool: 是否成功
        """  # noqa: D205
        with self.lock:
            if self.topics.get(topic) is None:
                return True

            if topic_type is None:
                # 取消所有类型的handler
                for handler in self.topics[topic].values():
                    handler._close()
                del self.topics[topic]
                return self.topics.get(topic) is None
            else:
                # 取消指定类型的handler
                if topic_type in self.topics[topic]:
                    self.topics[topic][topic_type]._close()
                    del self.topics[topic][topic_type]
                    # 如果该topic没有任何handler了，删除topic条目
                    if len(self.topics[topic]) == 0:
                        del self.topics[topic]
                return topic_type not in self.topics.get(topic, {})

    def handle_receive_message(self, message: Message) -> None:
        """处理接收到的消息"""
        topic = message.meta.topic
        if topic in self.topics:
            # 根据消息的 link_type 确定应该由哪个handler处理
            link_type = message.meta.link_type

            # 映射 LinkType 到 TopicType
            topic_type_map = {
                LinkType.REQ: TopicType.REP,  # REQ消息由REP handler处理
                LinkType.REP: TopicType.REQ,  # REP消息由REQ handler处理
                LinkType.PUB: TopicType.PUBSUB,  # PUB消息由PUBSUB handler处理
                LinkType.STREAM: TopicType.STREAM,  # STREAM消息由STREAM handler处理
            }

            target_type = topic_type_map.get(link_type)
            if target_type and target_type in self.topics[topic]:
                self.topics[topic][target_type]._handle_message(message)
            else:
                self.logger.debug(f'Handler for topic {topic} with type {target_type} not found')
        else:
            self.logger.debug(f'Topic not found: {topic}')

    def get_topic_handler(self, topic: str, topic_type: Optional[TopicType] = None) -> TopicHandler | Dict[TopicType, TopicHandler] | None:
        """获取主题处理器
        Args:
            topic: 主题
            topic_type: 主题类型，如果为None则返回该topic的所有handler字典
        Returns:
            TopicHandler | Dict[TopicType, TopicHandler] | None: 主题处理器或handler字典
        """  # noqa: D205
        with self.lock:
            if topic not in self.topics:
                return None

            if topic_type is None:
                # 返回该topic的所有handler字典
                return self.topics[topic]
            else:
                # 返回指定类型的handler
                return self.topics[topic].get(topic_type)

    def get_info(self) -> Dict[str, Any]:
        """获取处理器信息
        Returns:
            Dict[str, Any]: 处理器信息
        """  # noqa: D205
        topic_details = {}
        total_messages = 0

        with self.lock:
            for topic, handlers_dict in self.topics.items():
                topic_info = {}
                topic_messages = 0

                for topic_type, handler in handlers_dict.items():
                    send_queue_sizes = handler.send_queue.qsize()
                    receive_queue_sizes = handler.receive_queue.qsize()
                    handler_messages = send_queue_sizes + receive_queue_sizes

                    topic_info[topic_type.value] = {
                        'send_size': send_queue_sizes,
                        'receive_size': receive_queue_sizes,
                        'total_size': handler_messages,
                    }
                    topic_messages += handler_messages

                topic_details[topic] = {
                    'handlers': topic_info,
                    'total_size': topic_messages,
                }
                total_messages += topic_messages

        return {
            'managed_topics': list(self.topics.keys()),
            'topic_count': len(self.topics),
            'topic_details': topic_details,
            'total_messages': total_messages,
        }

    def clear_topics(self) -> None:
        """清除所有主题处理器"""
        with self.lock:
            for topic, handlers_dict in self.topics.items():
                for handler in handlers_dict.values():
                    handler._close()
            self.topics.clear()

    def shutdown(self) -> None:
        """关闭管理器"""
        self.clear_topics()
        self.link.disconnect()
        self.shared_memory_manager.close_all_regions()
        self.logger.debug('Topic manager closed')
