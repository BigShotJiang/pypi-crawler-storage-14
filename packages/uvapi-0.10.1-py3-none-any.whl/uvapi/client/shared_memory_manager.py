"""共享内存管理器"""

import mmap
import tempfile
import os
import logging
from typing import Dict, Optional
from datetime import datetime
from dataclasses import dataclass, field

@dataclass
class SharedMemoryRegion:
    """共享内存区域基本信息"""

    region_name: str
    size: int
    file_path: str
    created_time: datetime = field(default_factory=datetime.now)


class SharedMemoryManager:
    """共享内存管理器"""

    def __init__(self, manager_id: str = None, logger: logging.Logger = None) -> None:
        """
        初始化共享内存管理器

        Args:
            manager_id: 管理器标识
        """
        self.manager_id = manager_id or 'shared_memory_manager'
        self.logger = logger or logging.getLogger('messagebus_shared_memory_manager')

        # 活动区域管理
        self.active_regions: Dict[str, SharedMemoryRegion] = {}

        self.logger.debug(f'Shared memory manager initialized successfully: {self.manager_id}')

    def create_region(self, region_size: int, region_name: str) -> Optional[SharedMemoryRegion]:
        """
        创建共享内存区域

        Args:
            region_size: 区域大小（字节）
            region_name: 区域名称

        Returns:
            SharedMemoryRegion对象，创建失败返回None
        """
        try:
            if region_name in self.active_regions:
                self.logger.debug(f'Shared memory region already exists: {region_name}')
                return self.active_regions[region_name]

            region_name = region_name.replace('/', '_')
            region_name = region_name.replace(':', '_')

            # 创建临时文件，使用region_name作为文件名前缀
            temp_file = tempfile.NamedTemporaryFile(
                prefix=f'shm_{region_name}_', suffix='.mem', delete=False
            )
            file_path = temp_file.name

            # 设置文件大小
            temp_file.write(b'\x00' * region_size)
            temp_file.flush()
            temp_file.close()

            # 创建区域信息
            region = SharedMemoryRegion(region_name=region_name, size=region_size, file_path=file_path)

            # 记录到活动区域
            self.active_regions[region_name] = region

            self.logger.debug(
                f'Created shared memory region: {region_name} ({region_size} bytes) -> {file_path}'
            )
            return region

        except Exception as e:
            self.logger.debug(f'Failed to create shared memory region: {region_name} - {e}')
            return None

    def set_region(self, region_name: str, size: int, file_path: str) -> Optional[SharedMemoryRegion]:
        """
        设置共享内存区域

        Args:
            region_name: 区域名称
            size: 区域大小
            file_path: 区域文件路径

        Returns:
            SharedMemoryRegion对象，设置失败返回None
        """
        try:
            if region_name in self.active_regions:
                self.logger.debug(f'Shared memory region already exists: {region_name}')
                self.active_regions[region_name].size = size
                self.active_regions[region_name].file_path = file_path
                return self.active_regions[region_name]

            region = SharedMemoryRegion(region_name=region_name, size=size, file_path=file_path)

            self.active_regions[region_name] = region
            return region
        except Exception as e:
            self.logger.debug(f'Failed to set shared memory region: {region_name} - {e}')
            return None

    def write_data(self, region_name: str, data: bytes, offset: int = 0) -> bool:
        """
        写入数据到共享内存区域

        Args:
            region_name: 区域名称
            data: 要写入的数据
            offset: 写入偏移量

        Returns:
            写入成功返回True，失败返回False

        Raises:
            Exception: 写入数据失败
        """
        try:
            if region_name not in self.active_regions:
                self.logger.debug(f'Shared memory region does not exist: {region_name}')
                return False

            region = self.active_regions[region_name]

            # 检查数据大小
            if offset + len(data) > region.size:
                self.logger.debug(f'Data size exceeds region range: {len(data)} + {offset} > {region.size}')
                return False

            # 写入数据
            with open(region.file_path, 'r+b') as f:
                with mmap.mmap(f.fileno(), region.size) as mm:
                    mm[offset : offset + len(data)] = data
                    mm.flush()

            self.logger.debug(f'Wrote data successfully: {region_name}, {len(data)} bytes, offset={offset}')
            return True

        except Exception as e:
            self.logger.debug(f'Failed to write data: {region_name} - {e}')
            return False

    def read_data_by_path(self, file_path: str, size: int = None, offset: int = 0) -> Optional[bytes]:
        """
        通过文件路径直接读取共享内存数据（用于接收方读取远程共享内存）

        Args:
            file_path: 共享内存文件路径
            size: 读取大小，None表示读取全部
            offset: 读取偏移量

        Returns:
            读取的数据，失败返回None
        """
        try:
            if not os.path.exists(file_path):
                self.logger.debug(f'Shared memory file does not exist: {file_path}')
                return None

            # 获取文件大小
            file_size = os.path.getsize(file_path)

            # 确定读取大小
            if size is None:
                size = file_size - offset

            # 检查读取范围
            if offset + size > file_size:
                self.logger.debug(f'Read range exceeds file: {size} + {offset} > {file_size}')
                return None

            # 读取数据
            with open(file_path, 'rb') as f:
                with mmap.mmap(f.fileno(), file_size, access=mmap.ACCESS_READ) as mm:
                    data = bytes(mm[offset : offset + size])

            self.logger.debug(
                f'Read data successfully by path: {file_path}, {len(data)} bytes, offset={offset}'
            )
            return data

        except Exception as e:
            self.logger.debug(f'Failed to read data by path: {file_path} - {e}')
            return None

    def read_data(self, region_name: str, size: int = None, offset: int = 0) -> Optional[bytes]:
        """
        从共享内存区域读取数据

        Args:
            region_name: 区域名称
            size: 读取大小，None表示读取全部
            offset: 读取偏移量

        Returns:
            读取的数据，失败返回None
        """
        try:
            if region_name not in self.active_regions:
                self.logger.debug(f'Shared memory region does not exist: {region_name}')
                return None

            region = self.active_regions[region_name]

            # 确定读取大小
            if size is None:
                size = region.size - offset

            # 检查读取范围
            if offset + size > region.size:
                self.logger.debug(f'Read range exceeds region: {size} + {offset} > {region.size}')
                return None

            # 读取数据
            with open(region.file_path, 'rb') as f:
                with mmap.mmap(f.fileno(), region.size, access=mmap.ACCESS_READ) as mm:
                    data = bytes(mm[offset : offset + size])

            self.logger.debug(f'Read data successfully: {region_name}, {len(data)} bytes, offset={offset}')
            return data

        except Exception as e:
            self.logger.debug(f'Failed to read data: {region_name} - {e}')
            return None

    def get_region_info(self, region_name: str) -> Optional[SharedMemoryRegion]:
        """
        获取区域信息

        Args:
            region_name: 区域名称

        Returns:
            区域信息，不存在返回None
        """
        return self.active_regions.get(region_name)

    def close_region(self, region_name: str) -> bool:
        """
        关闭并销毁共享内存区域

        Args:
            region_name: 区域名称

        Returns:
            销毁成功返回True，失败返回False
        """
        try:
            if region_name not in self.active_regions:
                self.logger.debug(f'Shared memory region to destroy does not exist: {region_name}')
                return True  # 已经不存在，认为销毁成功

            region = self.active_regions[region_name]

            # 删除文件
            if os.path.exists(region.file_path):
                os.unlink(region.file_path)
                self.logger.debug(f'Deleted shared memory file: {region.file_path}')

            # 从活动区域中移除
            del self.active_regions[region_name]

            self.logger.debug(f'Destroyed shared memory region: {region_name}')
            return True

        except Exception as e:
            self.logger.debug(f'Failed to destroy shared memory region: {region_name} - {e}')
            return False

    def close_all_regions(self) -> int:
        """
        关闭所有共享内存区域

        Returns:
            成功关闭的区域数量
        """
        region_names = list(self.active_regions.keys())
        closed_count = 0

        for region_name in region_names:
            if self.close_region(region_name):
                closed_count += 1

        self.logger.debug(f'Cleaned up all shared memory regions: {closed_count}/{len(region_names)}')
        return closed_count

    def get_statistics(self) -> Dict:
        """获取统计信息"""
        total_size = sum(region.size for region in self.active_regions.values())

        return {
            'manager_id': self.manager_id,
            'active_regions': len(self.active_regions),
            'total_size': total_size,
            'regions': {
                name: {
                    'size': region.size,
                    'file_path': region.file_path,
                    'created_time': region.created_time.isoformat(),
                }
                for name, region in self.active_regions.items()
            },
        }

    def __del__(self) -> None:
        """析构函数，清理资源"""
        try:
            self.close_all_regions()
        except Exception as e:
            if hasattr(self, 'logger'):
                self.logger.debug(f'Destructor cleanup shared memory failed: {e}')


if __name__ == '__main__':
    """测试代码"""
    logging.basicConfig(level=logging.INFO)

    # 创建管理器
    manager = SharedMemoryManager('test_manager')

    # 创建共享内存区域
    region = manager.create_region(1024, 'test_region')
    if not region:
        print('创建区域失败')
        exit(1)

    # 写入数据
    test_data = b'Hello, Shared Memory!'
    if manager.write_data('test_region', test_data):
        print('写入数据成功')

    # 读取数据
    read_data = manager.read_data('test_region', len(test_data))
    if read_data:
        print(f'读取数据: {read_data.decode()}')

    # 获取统计信息
    stats = manager.get_statistics()
    print(f'统计信息: {stats}')

    # 清理
    manager.close_all_regions()
    print('测试完成')
