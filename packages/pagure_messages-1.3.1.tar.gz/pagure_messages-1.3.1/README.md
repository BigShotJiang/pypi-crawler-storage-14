# pagure messages

A schema package for [pagure](https://pagure.io/pagure).

See the [detailed documentation](https://fedora-messaging.readthedocs.io/en/latest/messages.html) on packaging your schemas.
