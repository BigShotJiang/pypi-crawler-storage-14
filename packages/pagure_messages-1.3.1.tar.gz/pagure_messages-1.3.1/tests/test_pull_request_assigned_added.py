# Copyright (C) 2020  Red Hat, Inc.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

"""Unit tests for the message schema."""

from jsonschema import ValidationError

import pytest

from pagure_messages.pull_requests_schema import PullRequestAssignedAddedV1

from .utils import PROJECT, PULL_REQUEST


def test_minimal():
    """
    Assert the message schema validates a message with the required fields.
    """
    body = {
        "agent": "dummy-user",
        "pullrequest": PULL_REQUEST,
        "project": PROJECT,
    }
    message = PullRequestAssignedAddedV1(body=body)
    message.validate()
    assert message.url == "http://localhost.localdomain/pagure/pull-request/5014"


def test_missing_fields():
    """Assert an exception is actually raised on validation failure."""
    minimal_message = {
        "pullrequest": PULL_REQUEST,
        "project": PROJECT,
    }
    message = PullRequestAssignedAddedV1(body=minimal_message)
    with pytest.raises(ValidationError):
        message.validate()


def test_str():
    """Assert __str__ produces a human-readable message."""
    body = {
        "agent": "dummy-user",
        "pullrequest": PULL_REQUEST,
        "project": PROJECT,
    }
    expected_str = "Pull-request pagure#5014 was assigned\nBy: dummy-user"
    message = PullRequestAssignedAddedV1(body=body)
    message.validate()
    assert expected_str == str(message)


def test_summary():
    """Assert the summary is correct."""
    request = PULL_REQUEST.copy()
    request["assignee"] = {
        "fullname": "Foo bar",
        "url_path": "user/foobar",
        "name": "foobar",
    }
    body = {
        "agent": "dummy-user",
        "pullrequest": request,
        "project": PROJECT,
    }
    expected_summary = "dummy-user assigned the pull-request pagure#5014 to foobar"
    message = PullRequestAssignedAddedV1(body=body)
    message.validate()
    assert expected_summary == message.summary


def test_summary_no_assignee():
    """Assert the summary is correct when there is no assignee.

    Not sure how that can happen but it does.

    Example: https://apps.fedoraproject.org/datagrepper/v2/id?id=9105f582-3eb2-4e3f-9317-df1b19599a69&is_raw=true&size=extra-large
    """
    request = PULL_REQUEST.copy()
    request["assignee"] = None
    body = {
        "agent": "dummy-user",
        "pullrequest": request,
        "project": PROJECT,
    }
    expected_summary = "dummy-user assigned the pull-request pagure#5014 to someone"
    message = PullRequestAssignedAddedV1(body=body)
    message.validate()
    assert expected_summary == message.summary
