"""Entry point for running the FL Studio MCP server as a module."""

from fruityloops_mcp.server import main

if __name__ == "__main__":
    main()
