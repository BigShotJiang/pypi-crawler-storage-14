"""Test suite for FL Studio MCP Server."""
