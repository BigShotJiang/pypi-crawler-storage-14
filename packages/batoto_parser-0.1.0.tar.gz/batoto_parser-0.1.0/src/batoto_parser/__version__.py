"""Version information for batoto-parser."""

__version__ = "0.1.0"