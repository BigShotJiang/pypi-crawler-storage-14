# -*- coding: utf-8 -*-

import json
import logging
import requests
import sys
import time
import traceback

from datetime import date, datetime
from urllib.parse import urljoin

from . import __version__, everything_broken
from .core import encode_and_compress_data, get_data_sha256, ail_json_default
from .exceptions import PyAILError, MissingDependency, NoURL, NoKey, PyAILInvalidFormat, AILServerError, PyAILNotImplementedYet, PyAILUnexpectedResponse, PyAILEmptyResponse

logger = logging.getLogger('pyail')

# class AbstractAIL

# class Investigation:
#     def __init__(self, investigation_uuid):
#         self.uuid = investigation_uuid
#
#
# class AILObject:
#     def __init__(self, obj_type, obj_subtype, obj_id):
#         self.type = obj_type
#         self.subtype = obj_subtype
#         self.id = obj_id
#
#         # first_seen
#         # last_seen
#
#     # def add_tag(self, tag):


class PyAIL:
    """Python API for AIL

    :param url: URL of the AIL instance you want to connect to
    :param key: API key of the user you want to use
    :param ssl: can be True or False (to check or to not check the validity of the certificate. Or a CA_BUNDLE in case of self signed or other certificate (the concatenation of all the *.crt of the chain)
    :param debug: Write all the debug information to stderr
    :param api_version: Version of the API used (only the v1 is currently available)
    :param proxies: Proxy dict as describes here: http://docs.python-requests.org/en/master/user/advanced/#proxies
    :param cert: Client certificate, as described there: http://docs.python-requests.org/en/master/user/advanced/#client-side-certificates
    :param auth: The auth parameter is passed directly to requests, as described here: http://docs.python-requests.org/en/master/user/authentication/
    :param tool: The software using PyAIL (string), used to set a unique user-agent
    :param timeout: Timeout as described here: https://requests.readthedocs.io/en/master/user/advanced/#timeouts
    """

    def __init__(self, url, key, ssl=True, debug=False, api_version='v1', proxies={}, cert=None, auth=None, tool=None, timeout=None):
        if not url:
            raise NoURL('Please provide the URL of your AIL instance.')
        if not key:
            raise NoKey('Please provide your authorization key.')

        self.root_url = url
        self.key = key
        self.ssl = ssl
        self.api_version = api_version
        self.proxies = proxies
        self.cert = cert
        self.auth = auth
        self.tool = tool
        self.timeout = timeout

        if debug:
            logger.setLevel(logging.DEBUG)
            logger.info('To configure logging in your script, leave it to None and use the following: import logging; logging.getLogger(\'pyail\').setLevel(logging.DEBUG)')

        if not self.ssl:
            from requests.packages.urllib3.exceptions import InsecureRequestWarning
            requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

        try:
            # Make sure the AIL instance is working and the URL is valid
            # # TODO: check version compatibility

            self.ping()

        except Exception as e:
            if debug:
                traceback.print_exc()
            raise PyAILError(f'Unable to connect to AIL ({self.root_url}). Please make sure the API key and the URL are correct (https is required): {e}')

    # # TODO: verify version compatibility between AIL and pyAIL

    #### AIL Server ####

    def ping_ail(self):
        print('WARNING DEPRECATED: Please use ping()')
        return self.ping()

    def ping(self):
        response = self._prepare_request('GET', f'api/{self.api_version}/ping')
        return self._check_json_response(response)

    def get_uuid(self):
        response = self._prepare_request('GET', f'api/{self.api_version}/uuid')
        return self._check_json_response(response)

    def get_version(self):
        response = self._prepare_request('GET', f'api/{self.api_version}/version')
        return self._check_json_response(response)

    ## -- AIL Server -- ##

    #### AIL Object ####  # TODO get meta/object fields description

    # def exists_object(self, object_type, object_subtype, object_id):
    #     pass
    #
    # def get_object(self, object_type, object_subtype, object_id):
    #     pass

    ## -- AIL Object -- ##

    #### AIL Object ####

    ## -- Investigation -- ##
    #
    # def get_investigations(self):
    #     pass
    #
    # def get_investigation(self, investigation_uuid):
    #     pass

    ## BEGIN Feed AIL ##
    def feed_json_item(self, data, meta, source, source_uuid, data_sha256=None, default_encoding='UTF-8'):
        dict_to_send = {}
        dict_to_send['data'] = encode_and_compress_data(data)
        if data_sha256:
            dict_to_send['data-sha256'] = data_sha256
        else:
            dict_to_send['data-sha256'] = get_data_sha256(data)
        dict_to_send['meta'] = meta
        dict_to_send['source'] = source
        dict_to_send['source_uuid'] = source_uuid
        dict_to_send['default_encoding'] = default_encoding
        dict_to_send['timestamp'] = int(time.time())
        response = self._prepare_request('POST', f'api/{self.api_version}/import/json/item', data=dict_to_send)
        return self._check_json_response(response)

    # feed json file  -------------------

    # # TODO: return task uuid + add check status
    # Crawler #
    def crawl_url(self, url, har=True, screenshot=True, depth_limit=1, frequency=None, cookiejar=None, proxy='force_tor'):
        dict_to_send = {}
        dict_to_send['url'] = url
        dict_to_send['har'] = har
        dict_to_send['screenshot'] = screenshot
        dict_to_send['depth_limit'] = int(depth_limit)
        if cookiejar:
            dict_to_send['cookiejar'] = cookiejar
        # can be set to 'web', 'onion', 'tor' or 'force_tor'
        if proxy:
            dict_to_send['proxy'] = proxy
        # 'monthly', 'weekly', 'daily', 'hourly' or a dict {'minutes': 0, 'hours':0, 'days': 0, 'weeks': 0, 'months': 0}
        if frequency:
            dict_to_send['frequency'] = frequency
        response = self._prepare_request('POST', f'api/{self.api_version}/add/crawler/task', data=dict_to_send)
        return self._check_json_response(response)

    def add_crawler_capture(self, task_uuid, capture_uuid, url, har=False, screenshot=False, depth_limit=1, proxy='force_tor'):
        dict_to_send = {}
        dict_to_send['task_uuid'] = task_uuid
        dict_to_send['capture_uuid'] = capture_uuid
        dict_to_send['url'] = url
        dict_to_send['har'] = har
        dict_to_send['screenshot'] = screenshot
        dict_to_send['depth_limit'] = int(depth_limit)
        # can be set to 'web', 'onion', 'tor' or 'force_tor'
        if proxy:
            dict_to_send['proxy'] = proxy
        response = self._prepare_request('POST', f'api/{self.api_version}/add/crawler/capture', data=dict_to_send)
        return self._check_json_response(response)

    def import_crawler_capture(self, capture=None, capture_file=None):
        """
        Import a crawler capture in Lacus format.

        The Lacus crawler capture is expected to follow the structure:

        {
            "html": <str>,                        # Raw HTML content of the page

            "last_redirected_url": <str>,         # Final resolved URL

            "png": <str | null>,                  # Optional - Base64-encoded screenshot

            "har": <dict | null>,                 # Optional - HAR capture as JSON/dict

            "potential_favicons": <list[str]>,    # Optional - List of base64-encoded icons

            "children": <list[dict]>              # Optional - Recursively embedded captures

        }

        One of the following must be provided:
          • ``capture``: A dictionary in Lacus format.
          • ``capture_file``: Path to a JSON file containing a Lacus capture.

        If ``capture_file`` is provided and ``capture`` is not,
        the file will be read and the parsed JSON used as the capture payload.

        :param capture: (dict) A Lacus-format capture structure.
        :type capture: dict | None
        :param capture_file: (str) Path to a JSON capture file.
        :type capture_file: str | None

        :return: A dict containing the UUID of the imported capture. {"uuid": "<UUID>"}
        :rtype: dict
        """
        if capture_file and not capture:
            with open(capture_file, 'r') as f:
                capture = f.read()
        if not capture:
            raise Exception('capture_file or capture must be provided')
        response = self._prepare_request('POST', f'api/{self.api_version}/import/crawler/capture', data=capture)
        return self._check_json_response(response)

    def import_lacus_cookiejar(self, url, storage):
        dict_to_send = {}
        dict_to_send['url'] = url
        dict_to_send['storage'] = storage
        response = self._prepare_request('POST', f'api/{self.api_version}/lacus/cookiejar/import', data=dict_to_send)
        return self._check_json_response(response)

    def onion_lookup(self, onion):
        response = self._prepare_request('GET', f'api/{self.api_version}/lookup/onion/{onion}')
        return self._check_json_response(response)

    ## -- END Feed AIL -- ##



    ## Internal methods ###

    def _check_json_response(self, response):
        r = self._check_response(response, expect_json=True)
        if isinstance(r, (dict, list)):
            return r
        else:
            raise PyAILUnexpectedResponse('Invalid JSON received.')


    def _check_response(self, response, expect_json=False):
        """Check if the response from the server is not an unexpected error"""
        if response.status_code >= 500:
            logger.critical(everything_broken.format(response.request.headers, response.request.body, response.text))
            raise AILServerError(f'Error code 500:\n{response.text}')

        if 400 <= response.status_code < 500:
            # The server returns a json message with the error details
            try:
                error_message = response.json()
            except Exception:
                raise AILServerError(f'Error code {response.status_code}:\n{response.text}')

            logger.error(f'Something went wrong ({response.status_code}): {error_message}')
            return {'errors': (response.status_code, error_message)}

        # At this point, we had no error.

        try:
            response_json = response.json()
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(response_json)
            if isinstance(response_json, dict) and response_json.get('response') is not None:
                # Cleanup.
                response_json = response_json['response']
            return response_json
        except Exception:
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(response.text)
            if expect_json:
                raise PyAILUnexpectedResponse(f'Unexpected response from server: {response.text}')
            if not response.content:
                # Empty response
                logger.error('Got an empty response.')
                return {'errors': 'The response is empty.'}
            return response.text

    def _prepare_request(self, request_type, url, data={}, params={}, output_type='json'):
        '''Prepare a request for python-requests'''
        url = urljoin(self.root_url, url)
        if data == {} or isinstance(data, str):
            d = data
        elif data:
            if not isinstance(data, str):  # Else, we already have a text blob to send
                if isinstance(data, dict):  # Else, we can directly json encode.
                    # Remove None values.
                    data = {k: v for k, v in data.items() if v is not None}
                d = json.dumps(data, default=ail_json_default)

        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(f'{request_type} - {url}')
            if d is not None:
                logger.debug(d)

        req = requests.Request(request_type, url, data=d, params=params)
        with requests.Session() as s:
            user_agent = f'PyAIL {__version__} - Python {".".join(str(x) for x in sys.version_info[:2])}'
            if self.tool:
                user_agent = f'{user_agent} - {self.tool}'
            req.auth = self.auth
            prepped = s.prepare_request(req)
            prepped.headers.update(
                {'Authorization': self.key,
                 'Accept': f'application/{output_type}',
                 'content-type': f'application/{output_type}',
                 'User-Agent': user_agent})
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(prepped.headers)
            settings = s.merge_environment_settings(req.url, proxies=self.proxies or {}, stream=None, verify=self.ssl, cert=self.cert)
            return s.send(prepped, timeout=self.timeout, **settings)

    def __repr__(self):
        return f'<{self.__class__.__name__}(url={self.root_url})'

    #################################################################################
    #################################################################################
    #################################################################################

    # AIL OBJECTS for a tpe ????

    #################################################################################
    #################################################################################
    #################################################################################

    # add_tag(ref_obj, tag)

    # add_investigation / create_investigation
    # add_tracker / create_tracker

    # add_object / create_object -> accept AILObject + dict/json -> type or var like pythonify

    # direct_call but a with better name

