from redisvl.utils.compression import CompressionAdvisor

__all__ = ["CompressionAdvisor"]
