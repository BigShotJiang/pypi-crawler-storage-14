from .video_object_segment import generate_aot
from .image_segment import generate_sa

from .visual_latent_extract import generate_dinov2, generate_dinov3