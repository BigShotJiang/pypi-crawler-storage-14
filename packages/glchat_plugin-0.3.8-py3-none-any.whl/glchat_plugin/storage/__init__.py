"""Module for glchat_plugin storage interface."""
