import logging

logger_bot = logging.getLogger("bot")
logger_connection = logging.getLogger("connection")
logger_dp = logging.getLogger("dispatcher")
