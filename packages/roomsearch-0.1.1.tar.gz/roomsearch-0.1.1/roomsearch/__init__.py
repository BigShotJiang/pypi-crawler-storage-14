import boto3
from decimal import Decimal
from django.conf import settings

__all__ = ["boto3", "Decimal", "settings"]