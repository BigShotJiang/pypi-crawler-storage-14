# Diaplot

Diaplot provides a simple endpoint for generating visually appealing plots inspired by The Economist.

## Features
- Line plot
- Bar chart

## Planned features
- Map visualisations
    - Chloropleth
    - Bubble maps
    - Arc maps
    - Drawing geometry over maps
- Scatterplots
- Legislative chamber visualisation

![RPE in Chile](images/chile_sample.png)

## Installation

```bash
pip install diaplot
```

## Quick Start

### Line Chart

```python
from diaplot import line_chart
import numpy as np

# Create chart
fig, ax = line_chart(
    x_data=years,
    y_data=values,
    title="Economic Growth Over Time",
    subtitle="Annual GDP growth rate, 1960-2020",
    source="Source: World Bank",
    color='#006BA2',  # Economist blue
    event_markers=[1970, 1973, 2008],  # Mark recession years
)
```

### Bar Chart

```python
from diaplot import bar_chart

categories = ['2018', '2019', '2020', '2021', '2022']
values = [45, 52, 48, 61, 55]

fig, ax = bar_chart(
    x=categories,
    y=values,
    title="Annual Revenue",
    subtitle="Revenue in millions, 2018-2022",
    source="Source: Company Reports",
    color='#DB0A05',  # Economist red
    reference_lines=[50],  # Add target line
)
```
