"""
Diaplot - Simple data visualisation library

Publication-ready charts with Economist-inspired styling.
"""

from .plot import (
    line_chart,
    bar_chart,
    get_palette,
    get_color,
    create_gradient,
    categorical_colors,
    diverging_gradient,
    sequential_gradient,
)

__version__ = "0.1.0"

__all__ = [
    'line_chart',
    'bar_chart',
    'get_palette',
    'get_color',
    'create_gradient',
    'categorical_colors',
    'diverging_gradient',
    'sequential_gradient',
]
