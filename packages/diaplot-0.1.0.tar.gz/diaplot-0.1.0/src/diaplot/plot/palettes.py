"""
Color Palette Module

This module provides color palettes and gradient generation utilities.
All palettes follow professional publication standards.

Functions:
    get_palette: Get a color palette by name
    get_color: Get a specific color from a palette
    create_gradient: Generate a gradient between two colors
    categorical_colors: Get multiple colors for categorical data
"""

import matplotlib.colors as mcolors
from typing import List, Dict, Optional


# Define color palettes
palettes = {
    'default': {
        'primary': '#006BA2',      # Blue
        'accent': '#DB0A05',       # Red
        'secondary': '#3EBCD2',    # Cyan
        'muted': '#758D99',        # Gray-blue
        'success': '#0C7C59',      # Green
        'warning': '#F3A712',      # Orange
        'dark': '#2E3338',         # Dark gray
        'light': '#E8E8E8'         # Light gray
    },
    
    'economist': {
        'primary': '#006BA2',
        'accent': '#DB0A05',
        'secondary': '#3EBCD2',
        'muted': '#758D99',
        'success': '#0C7C59',
        'warning': '#F3A712',
        'dark': '#2E3338',
        'light': '#E8E8E8'
    },
    
    'financial_times': {
        'primary': '#2E6E9E',      # FT Blue
        'accent': '#990F3D',       # FT Pink
        'secondary': '#0F5499',    # Dark blue
        'muted': '#6A6A6A',        # Gray
        'success': '#0C7C59',      # Green
        'warning': '#CC6600',      # Orange
        'dark': '#333333',
        'light': '#FFF1E5'         # FT cream
    },
    
    'nature': {
        'primary': '#0C7C59',      # Green
        'accent': '#D32D41',       # Red
        'secondary': '#2B6A99',    # Blue
        'muted': '#7D7D7D',        # Gray
        'success': '#0C7C59',
        'warning': '#F3A712',
        'dark': '#2E3338',
        'light': '#E8E8E8'
    },
    
    'monochrome': {
        'primary': '#2E3338',      # Dark
        'accent': '#5A5F66',       # Mid-dark
        'secondary': '#858A91',    # Mid
        'muted': '#B0B5BA',        # Mid-light
        'success': '#2E3338',
        'warning': '#5A5F66',
        'dark': '#1A1D20',
        'light': '#E8E8E8'
    },
    
    'vibrant': {
        'primary': '#0066CC',      # Bright blue
        'accent': '#FF3333',       # Bright red
        'secondary': '#00CC99',    # Bright cyan
        'muted': '#666666',        # Gray
        'success': '#00CC66',      # Bright green
        'warning': '#FF9900',      # Bright orange
        'dark': '#1A1A1A',
        'light': '#F5F5F5'
    }
}


def get_palette(name: str = 'default') -> Dict[str, str]:
    """
    Get a color palette by name.
    
    Args:
        name: Name of the palette. Options: 'default', 'economist', 
              'financial_times', 'nature', 'monochrome', 'vibrant'
    
    Returns:
        Dictionary mapping color names to hex codes
    
    Example:
        >>> palette = get_palette('economist')
        >>> print(palette['primary'])
        '#006BA2'
    """
    return palettes.get(name, palettes['default']).copy()


def get_color(key: str = 'primary', palette: str = 'default') -> str:
    """
    Get a specific color from a palette.
    
    Args:
        key: Color key ('primary', 'accent', 'secondary', 'muted', etc.)
        palette: Palette name
    
    Returns:
        Hex color code
    
    Example:
        >>> color = get_color('accent', 'economist')
        >>> print(color)
        '#DB0A05'
    """
    selected_palette = get_palette(palette)
    return selected_palette.get(key, selected_palette['primary'])


def create_gradient(
    color1: str,
    color2: str,
    n_colors: int = 10,
    color_format: str = 'hex'
) -> List[str]:
    """
    Create a gradient between two colors.
    
    Args:
        color1: Starting color (hex code)
        color2: Ending color (hex code)
        n_colors: Number of colors in gradient
        color_format: Output format ('hex' or 'rgb')
    
    Returns:
        List of color codes in the gradient
    
    Example:
        >>> gradient = create_gradient('#006BA2', '#DB0A05', n_colors=5)
        >>> print(gradient)
        ['#006BA2', '#4D5679', '#734150', '#9B2C28', '#DB0A05']
    """
    # Convert hex to RGB
    rgb1 = mcolors.hex2color(color1)
    rgb2 = mcolors.hex2color(color2)
    
    # Create gradient
    gradient = []
    for i in range(n_colors):
        t = i / (n_colors - 1) if n_colors > 1 else 0
        r = rgb1[0] * (1 - t) + rgb2[0] * t
        g = rgb1[1] * (1 - t) + rgb2[1] * t
        b = rgb1[2] * (1 - t) + rgb2[2] * t
        
        if color_format == 'hex':
            gradient.append(mcolors.rgb2hex((r, g, b)))
        else:
            gradient.append((r, g, b))
    
    return gradient


def categorical_colors(
    n_colors: int,
    palette: str = 'default',
    gradient: bool = False,
    start_color: Optional[str] = None,
    end_color: Optional[str] = None
) -> List[str]:
    """
    Get multiple colors for categorical data.
    
    Args:
        n_colors: Number of colors needed
        palette: Palette name to use
        gradient: If True, creates gradient. If False, cycles through palette colors.
        start_color: Starting color for gradient (if gradient=True)
        end_color: Ending color for gradient (if gradient=True)
    
    Returns:
        List of hex color codes
    
    Example:
        >>> # Get 5 distinct colors
        >>> colors = categorical_colors(5, palette='economist')
        
        >>> # Get 10 colors as a gradient
        >>> colors = categorical_colors(10, gradient=True, 
        ...                            start_color='#006BA2', end_color='#DB0A05')
    """
    if gradient:
        if start_color is None:
            start_color = get_color('primary', palette)
        if end_color is None:
            end_color = get_color('accent', palette)
        return create_gradient(start_color, end_color, n_colors)
    
    # Get palette colors in order
    selected_palette = get_palette(palette)
    color_keys = ['primary', 'accent', 'secondary', 'success', 'warning', 'muted']
    palette_colors = [selected_palette[key] for key in color_keys if key in selected_palette]
    
    # Cycle through colors if needed
    colors = []
    for i in range(n_colors):
        colors.append(palette_colors[i % len(palette_colors)])
    
    return colors


def diverging_gradient(
    n_colors: int = 11,
    palette: str = 'default',
    center_color: str = '#FFFFFF'
) -> List[str]:
    """
    Create a diverging gradient (low -> center -> high).
    
    Args:
        n_colors: Number of colors in gradient (should be odd for symmetric result)
        palette: Palette name
        center_color: Color for the center/midpoint
    
    Returns:
        List of hex color codes
    
    Example:
        >>> colors = diverging_gradient(11, palette='economist')
        >>> # Creates: blue -> white -> red gradient
    """
    selected_palette = get_palette(palette)
    low_color = selected_palette['primary']
    high_color = selected_palette['accent']
    
    mid_point = n_colors // 2
    
    # Create two gradients
    low_gradient = create_gradient(low_color, center_color, mid_point + 1)
    high_gradient = create_gradient(center_color, high_color, n_colors - mid_point)
    
    # Combine (remove duplicate center)
    return low_gradient[:-1] + high_gradient


def sequential_gradient(
    n_colors: int = 9,
    palette: str = 'default',
    color_key: str = 'primary',
    lighten: bool = True
) -> List[str]:
    """
    Create a sequential gradient from light to dark or dark to light.
    
    Args:
        n_colors: Number of colors in gradient
        palette: Palette name
        color_key: Which color to use as base
        lighten: If True, goes from light to dark. If False, dark to light.
    
    Returns:
        List of hex color codes
    
    Example:
        >>> colors = sequential_gradient(7, palette='economist', color_key='primary')
        >>> # Creates: light blue -> dark blue gradient
    """
    base_color = get_color(color_key, palette)
    
    if lighten:
        start_color = '#F5F5F5'  # Very light
        end_color = base_color
    else:
        start_color = base_color
        end_color = '#1A1A1A'  # Very dark
    
    return create_gradient(start_color, end_color, n_colors)