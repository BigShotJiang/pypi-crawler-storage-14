> Crackerjack Docs: [Main](<../../README.md>) | [Crackerjack Package](<../README.md>) | [Tools](<./README.md>)

# Package Tools

Internal helper tools used within the package (distinct from top-level `tools/`).

## Related

- [Crackerjack Package](<../README.md>) - Parent package
- [MCP](<../mcp/README.md>) - MCP tool implementations
- [Services](<../services/README.md>) - Service layer using these tools
