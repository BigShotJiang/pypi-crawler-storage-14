import numpy as np


def process_data(data: np.ndarray) -> np.ndarray:
    return data
