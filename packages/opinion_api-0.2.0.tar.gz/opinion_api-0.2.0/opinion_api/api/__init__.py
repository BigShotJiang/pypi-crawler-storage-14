# flake8: noqa

# import apis into api package
from opinion_api.api.prediction_market_api import PredictionMarketApi
from opinion_api.api.user_api import UserApi

