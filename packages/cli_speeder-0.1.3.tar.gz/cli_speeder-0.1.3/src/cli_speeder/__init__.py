from .core import lazy_import, lazy_from_import, speed_up_modules

__all__ = ["lazy_import", "lazy_from_import","speed_up_modules"]
