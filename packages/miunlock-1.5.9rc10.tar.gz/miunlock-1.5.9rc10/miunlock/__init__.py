from miunlock.login import get_pass_token
from miunlock.config import get_domain
from miunlock.service import get_service_data
from miunlock.unlock import unlock_device
from pathlib import Path
import io

def main():
    
    print("\nStarting MiUnlock...")

    pass_token = get_pass_token()
    if "error" in pass_token:
        print(f"\nError getting pass_token: {pass_token['error']}")
        return

    domain_result = get_domain(pass_token)
    if "error" in domain_result:
        print(f"\nError getting domain: {domain_result['error']}")
        return
    domain = domain_result["domain"]

    service_data = get_service_data(pass_token)
    if "error" in service_data:
        print(f"\nError getting service data: {service_data['error']}")
        return
    cookies = service_data["cookies"]
    ssecurity = service_data["ssecurity"]
    pcId = service_data["pcId"]
    print("\nSuccessfully got service token.")

    unlock_result = unlock_device(domain, ssecurity, cookies, pcId)
    if "error" in unlock_result:
        print(f"\nError unlocking device: {unlock_result['error']}")
        return
        
    print("\n" + "\n".join([f"{key}: {value}" for key, value in unlock_result.items()]))

    if "code" in unlock_result and unlock_result["code"] == 0:
        encryptData = unlock_result["encryptData"]
        ed = io.BytesIO(bytes.fromhex(encryptData))
        filename = Path.home() / "encryptData"
        with open(filename, "wb") as edfile:
            edfile.write(ed.getvalue())
    
        print('\ncommands to unlock the bootloader:')
        print(f'\nfastboot stage {filename}')
        print('\nfastboot oem unlock')

    input("\nPress Enter to exit")