# Changelog

This changelog is maintained manually with assistance of
[`github-activity`](https://github.com/executablebooks/github-activity).
