class TestMetrics:
    def test_stability(self):
        assert False
    def test_local_fidelity(self):
        assert False
    def test_average_jackart(self):
        assert False