class TestImportanceSampler:
    def test_fit(self):
        assert False

    def test_transform(self):
        assert False


class TestUncertainSMOTE:
    def test__fit_resample(self):
        assert False

    def test__in_danger_noise(self):
        assert False
