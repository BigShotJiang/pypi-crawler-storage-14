class TestLux:
    def test_fit(self):
        assert False

    def test_fit_bounding_boxes(self):
        assert False

    def test_create_sample_bb(self):
        assert False

    def test_process_and_predict_proba(self):
        assert False

    def test_process_input(self):
        assert False

    def test_predict(self):
        assert False

    def test_justify(self):
        assert False

    def test_counterfactual(self):
        assert False

    def test_visualize(self):
        assert False

    def test_to_hmr(self):
        assert False

    def test_generate_uarff(self):
        assert False
