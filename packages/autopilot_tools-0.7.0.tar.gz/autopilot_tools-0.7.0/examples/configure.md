# Configure autopilot (set specific parameters)

The script connects to the hardare and set paramters either from [config_px4.yaml](config_px4.yaml) or [config_ardupilot.yaml](config_ardupilot.yaml) based on the actual firmware.

## Usage

```python3
./examples/configure.py
```

## Details

Ardupilot supports 4 types of parameters:

| Internally     | MAVLink                   | Example |
| -------------- | ------------------------- | ------- |
| AP_PARAM_INT8  | MAV_PARAM_TYPE_INT8 (2)   | SCR_ENABLE |
| AP_PARAM_INT16 | MAV_PARAM_TYPE_INT16 (4)  |
| AP_PARAM_INT32 | MAV_PARAM_TYPE_INT32 (6)  | COMPASS_DEV_ID |
| AP_PARAM_FLOAT | MAV_PARAM_TYPE_REAL32 (9) | COMPASS_DIA_X |

PX4 supports 2 types of parameters:

| Internally       | MAVLink                   | Example |
| ---------------- | ------------------------- | ------- |
| PARAM_TYPE_INT32 | MAV_PARAM_TYPE_INT32 (6)  | DSHOT_3D_DEAD_H |
| PARAM_TYPE_FLOAT | MAV_PARAM_TYPE_REAL32 (9) | DSHOT_MIN |
