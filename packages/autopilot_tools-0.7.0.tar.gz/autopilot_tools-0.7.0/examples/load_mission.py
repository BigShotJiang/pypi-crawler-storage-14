#!/usr/bin/env python3
from autopilot_tools.enums import Devices
from autopilot_tools.vehicle import Vehicle

if __name__ == '__main__':
    v = Vehicle()
    v.connect(device=Devices.serial)
    print(v.load_mission('./plan_without_fence.plan'))
    print(v.run_mission(timeout=200))
