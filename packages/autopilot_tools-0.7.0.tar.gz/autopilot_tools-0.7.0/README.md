# PX4/ArduPilot Autopilot tools [![PyPI](https://img.shields.io/pypi/v/autopilot-tools?logo=pypi&style=flat)](https://pypi.org/project/autopilot-tools/) ![coverage](https://img.shields.io/badge/dynamic/json?url=https://gist.githubusercontent.com/ponomarevda/6ef26524a388d71d8a93e345fb402991/raw/coverage.json&label=coverage&query=$.coverage&color=blue) [![Downloads](https://static.pepy.tech/badge/autopilot-tools)](https://pepy.tech/project/autopilot-tools)

Tools for automating configuration, testing, and log analysis of PX4 and ArduPilot autopilots.

## 1. USE CASES

After the installation the package is accessible as a few executables.

## 1.1. Flight Log Player

`saisei` lets you play a flight log in a 3D Simulator.

<img src="https://gist.githubusercontent.com/ponomarevda/6ef26524a388d71d8a93e345fb402991/raw/saisei.gif" width="400">

**Install**

```bash
pip install "autopilot_tools[saisei]"
```

**Example**

```bash
saisei --gui --log ~/Documents/px4_flight_log.ulg
or
python3 -m "autopilot_tools.saisei.cli" --help
```

## 1.2. Autopilot configurator

`autopilot-configurator` lets you take an unknown autopilot state and make it reproducible:
- flash a specific PX4 or ArduPilot firmware,
- reset parameters and apply a parameter set in a defined order,
- run forced sensor calibration (useful for HITL).

<img src="https://gist.githubusercontent.com/ponomarevda/6ef26524a388d71d8a93e345fb402991/raw/autopilot_configurator.gif" width="768">

**Install**

```bash
pip install autopilot_tools
```

**Example 1 - firmware + params**:

```
autopilot-configurator -v --firmware https://github.com/ZilantRobotics/PX4-Autopilot/releases/download/v1.15.0-0.4.3-beta1/px4_fmu-v6c_cyphal.px4 --params examples/px4_sys_autostart_13000.yaml
```

**Example 2 - single YAML “recipe”**:

```bash
cd ~/zilant/uav_hitl_sim # or your path to the simulator
autopilot-configurator -v --force configs/vehicles/px4_v1_15_0_cyphal_quadplane_vtol.yaml
```

**Example 3 – use as a library**:

```python
from autopilot_tools.configurator import AutopilotConfigurator

AutopilotConfigurator.configure_with_yaml_file(
    config_path="path_to_config_file.yaml",
    need_upload_firmware=True,
    need_load_parameters=True,
)
```

## 1.3. Test scenario

`test-scenario` runs a full mission and collects results automatically:
- uploads a mission to the autopilot,
- runs it and waits for completion,
- downloads the flight log and uploads it to [review.px4.io](https://review.px4.io/),
- prints mission result and a link to the log.

<img src="https://gist.githubusercontent.com/ponomarevda/6ef26524a388d71d8a93e345fb402991/raw/test_scenario.gif" width="768">

**Install**

```bash
pip install autopilot_tools
```

**Example**:

```bash
test-scenario examples/plan_without_fence.plan --output flight.ulg
```

This runs the mission from `examples/` and saves the log to `flight.ulg`.

## 2. CONTRIBUTING

A developer should follow the [CONTRIBUTING.md](CONTRIBUTING.md) guide.

It is recommended installing the package from sources in [Development Mode (a.k.a. “Editable Installs”)](https://setuptools.pypa.io/en/latest/userguide/development_mode.html). Clone the repository, install the package in development mode and use it in virtual environment:

```bash
git clone https://github.com/PonomarevDA/autopilot_tools.git
python3 -m venv venv
./venv/bin/activate
pip install -e .
```

## 3. LICENSE

The package inherits [ArduPilot/pymavlink](https://github.com/ArduPilot/pymavlink) license and is distributed under GPLv3 license.
