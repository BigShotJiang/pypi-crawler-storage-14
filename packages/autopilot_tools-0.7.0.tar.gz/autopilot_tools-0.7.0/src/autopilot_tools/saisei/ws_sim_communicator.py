#!/usr/bin/env python3
import sys
import time
import math
import json
import logging
import asyncio
import argparse
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional, Sequence, Tuple

logger = logging.getLogger(__name__)
VISUAL_HZ = 25.0  # ~25 Hz for visual topics

try:
    import websockets
except ModuleNotFoundError:
    logger.critical("pip install websockets")
    sys.exit(1)


# --- Topic configuration ------------------------------------------------------
@dataclass
class TopicMap:  # pylint: disable=too-many-instance-attributes
    """All topics used by the WS simulator bridge."""
    attitude: str = "/sim/attitude"
    gps: str = "/sim/gps_position"
    actuators: str = "/sim/actuators"
    wrench: str = "/sim/wrench"

    # Inputs from Unity / simulator
    altimeter: str = "/sensor/altimeter"
    altimeter_ground: str = "/sensor/altimeter/ground_level"
    state: str = "/sim/state"
    state_accel: str = "/sim/state/accel"


# --- SimData interface --------------------------------------------------------
class SimData(ABC):
    """
    Interface for providing data to WsSimCommunicator.
    """

    @abstractmethod
    def advance(self, dt: float) -> None:
        """Advance internal simulation time by dt seconds of wall time."""
        raise NotImplementedError()

    @abstractmethod
    def get_attitude_quat(self) -> Optional[Tuple[float, float, float, float]]:
        """
        Return attitude as quaternion (x, y, z, w) in ENU/FLU or whatever
        the simulator expects. Return None if not available.
        """
        raise NotImplementedError()

    @abstractmethod
    def get_gps(self) -> Optional[Tuple[float, float, float]]:
        """
        Return GPS position as (lat_deg, lon_deg, alt_m). Return None if not available.
        """
        raise NotImplementedError()

    @abstractmethod
    def get_actuators(self) -> Optional[Sequence[float]]:
        """
        Return actuator command axes, e.g. list of floats [0..1]. Return None to skip.
        """
        raise NotImplementedError()


# --- Helpers for ROS-like messages -------------------------------------------
def header(seq: int, t: float, frame_id: str):
    """
    Build a standard ROS-like header.
    Keeping this helper as it's part of the "message schema vocabulary".
    """
    secs = int(t)
    nsecs = int((t - secs) * 1e9)
    return {
        "seq": seq,
        "stamp": {"secs": secs, "nsecs": nsecs},
        "frame_id": frame_id,
    }


def msg_publish(topic: str, msg: dict) -> str:
    return json.dumps({"op": "publish", "topic": topic, "msg": msg})


def msg_advertise(topic: str, type_: str) -> str:
    return json.dumps({"op": "advertise", "topic": topic, "type": type_})


def msg_subscribe(topic: str, type_: str) -> str:
    return json.dumps({"op": "subscribe", "topic": topic, "type": type_})


def build_actuators_msg(seq: int, t: float, axes: Sequence[float]) -> dict:
    return {
        "header": header(seq, t, "base_link"),
        "axes": list(axes),
        "buttons": [1, 0, 0, 1],
    }


def build_gps_msg(seq: int, t: float, lat: float, lon: float, alt: float) -> dict:
    return {
        "header": header(seq, t, "gps"),
        "status": {"status": 0, "service": 0},
        "latitude": lat,
        "longitude": lon,
        "altitude": alt,
        "position_covariance": [
            0.1,
            0.0,
            0.0,
            0.0,
            0.1,
            0.0,
            0.0,
            0.0,
            0.1,
        ],
        "position_covariance_type": 2,
    }


def build_attitude_msg(seq: int, t: float, quat_xyzw: Tuple[float, float, float, float]) -> dict:
    """
    quat_xyzw: (x, y, z, w)
    Using a single tuple keeps call sites and signature small and readable.
    """
    qx, qy, qz, qw = quat_xyzw
    return {
        "header": header(seq, t, "base_link"),
        "quaternion": {
            "x": qx,
            "y": qy,
            "z": qz,
            "w": qw,
        },
    }


def build_wrench(seq: int, include_gravity: bool) -> dict:
    # Very dumb example: constant thrust + small oscillating torque
    mass = 10.0  # kg
    g = 9.81

    force_z = mass * g if include_gravity else 0.0
    t = time.time()
    return {
        "header": header(seq, t, "base_link"),
        "wrench": {
            "force": {
                "x": 0.0,
                "y": 0.0,
                "z": force_z + 5.0 * math.sin(t * 2.0),
            },
            "torque": {
                "x": 0.1 * math.sin(t),
                "y": -0.1 * math.cos(t),
                "z": 0.05 * math.sin(t * 0.5),
            },
        },
    }


# --- Simple default SimData (fake orbit) --------------------------------------
def rpy_to_quat(roll: float, pitch: float, yaw: float) -> Tuple[float, float, float, float]:
    """Convert roll/pitch/yaw (rad) in ZYX order to quaternion (x, y, z, w)."""
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)

    qw = cr * cp * cy + sr * sp * sy
    qx = sr * cp * cy - cr * sp * sy
    qy = cr * sp * cy + sr * cp * sy
    qz = cr * cp * sy - sr * sp * cy
    return qx, qy, qz, qw


class DummyOrbitSimData(SimData):
    """
    Built-in 'no input' / self-test sim data:
    - orbit around a point near Kazan-ish coords
    - some roll/pitch/yaw motion
    - simple actuator sinusoid
    """

    def __init__(self):
        self.t = 0.0

    def advance(self, dt: float) -> None:
        self.t += dt

    def get_attitude_quat(self) -> Optional[Tuple[float, float, float, float]]:
        elapsed = self.t
        phase = 2.0 * math.pi / 10.0 * elapsed
        theta = 2.0 * math.pi / 30.0 * elapsed

        roll = math.radians(20.0)
        pitch = math.radians(30.0) * math.sin(phase + 3.0 * math.pi / 2.0)
        yaw = math.atan2(-math.sin(theta), math.cos(theta))

        return rpy_to_quat(roll, pitch, yaw)

    def get_gps(self) -> Optional[Tuple[float, float, float]]:
        elapsed = self.t
        phase = 2.0 * math.pi / 10.0 * elapsed
        theta = 2.0 * math.pi / 30.0 * elapsed

        lat = 55.75690 + 0.0005 * math.cos(theta)
        lon = 48.741185 + 0.0005 * math.sin(theta)
        alt = 215.0 + 10.0 * math.sin(phase)
        return lat, lon, alt

    def get_actuators(self) -> Optional[Sequence[float]]:
        v = 0.5 + 0.5 * math.sin(self.t)
        return [v, 1.0 - v, 0.0, 1.0]


# --- Internal loop state to reduce locals ------------------------------------
@dataclass
class _LoopState:
    seq_visual: int
    seq_wrench: int
    last_t_wall: float
    t_next_visual: float
    t_next_physics: float


# --- WS communicator class ----------------------------------------------------
class WsSimCommunicator:
    """
    Wraps websocket server, advert/sub, and send/recv loops.

    It does NOT know about PX4, playback, GUI, etc.
    It only:
      - drives SimData with advance(dt)
      - periodically pulls attitude/gps/actuators from SimData
      - publishes them to the simulator.
    """

    def __init__(
        self,
        unity_physics_mode: bool,
        physics_frequency: float,
        include_gravity: bool,
        sim_data: Optional[SimData] = None,
    ):
        self.unity_physics_mode = unity_physics_mode
        self.physics_frequency = physics_frequency
        self.include_gravity = include_gravity
        self.topic_map: TopicMap = TopicMap()
        self.sim_data: SimData = sim_data if sim_data is not None else DummyOrbitSimData()

    async def advertise_and_subscribe(self, ws):
        # Always: visual topics
        await ws.send(msg_advertise(self.topic_map.attitude, "geometry_msgs/QuaternionStamped"))
        await ws.send(msg_advertise(self.topic_map.actuators, "sensor_msgs/Joy"))
        await ws.send(msg_advertise(self.topic_map.gps, "sensor_msgs/NavSatFix"))

        # Sensors from Unity
        await ws.send(msg_subscribe(self.topic_map.altimeter, "sensor_msgs/Range"))
        await ws.send(
            msg_subscribe(self.topic_map.altimeter_ground, "std_msgs/Float32")
        )

        # Unity physics mode
        if self.unity_physics_mode:
            await ws.send(msg_subscribe(self.topic_map.state, "nav_msgs/Odometry"))
            await ws.send(
                msg_subscribe(self.topic_map.state_accel, "geometry_msgs/AccelStamped")
            )
            await ws.send(msg_advertise(self.topic_map.wrench, "geometry_msgs/WrenchStamped"))

        logger.info("Advertise/subscribe done.")

    async def _send_visual_step(self, ws, state: _LoopState, now: float) -> None:
        """Single visual step at ~VISUAL_HZ."""
        state.seq_visual += 1

        # Attitude
        quat = self.sim_data.get_attitude_quat()
        if quat is None:
            quat = (0.0, 0.0, 0.0, 1.0)
        att_msg = build_attitude_msg(state.seq_visual, now, quat)
        await ws.send(msg_publish(self.topic_map.attitude, att_msg))

        # GPS
        gps_sample = self.sim_data.get_gps()
        if gps_sample is not None:
            lat, lon, alt = gps_sample
            gps_msg = build_gps_msg(state.seq_visual, now, lat, lon, alt)
            await ws.send(msg_publish(self.topic_map.gps, gps_msg))

        # Actuators
        axes = self.sim_data.get_actuators()
        if axes is not None:
            act_msg = build_actuators_msg(state.seq_visual, now, axes)
            await ws.send(msg_publish(self.topic_map.actuators, act_msg))

    async def _send_wrench_step(self, ws, state: _LoopState) -> None:
        """Single physics wrench step."""
        state.seq_wrench += 1
        wrench_msg = build_wrench(state.seq_wrench, self.include_gravity)
        await ws.send(msg_publish(self.topic_map.wrench, wrench_msg))

    async def sender_loop(self, ws):
        visual_dt = 1.0 / VISUAL_HZ
        physics_dt = 1.0 / self.physics_frequency if self.unity_physics_mode else None

        now = time.time()
        state = _LoopState(
            seq_visual=0,
            seq_wrench=0,
            last_t_wall=now,
            t_next_visual=now,
            t_next_physics=now,
        )

        while True:
            now = time.time()
            dt_wall = now - state.last_t_wall
            state.last_t_wall = now

            # Drive sim data time
            self.sim_data.advance(dt_wall)

            # Visual topics
            if now >= state.t_next_visual:
                await self._send_visual_step(ws, state, now)
                state.t_next_visual += visual_dt

            # Physics topics (high-rate wrench)
            if self.unity_physics_mode and now >= state.t_next_physics:
                await self._send_wrench_step(ws, state)
                state.t_next_physics += physics_dt

            await asyncio.sleep(0.001)  # avoid busy-looping

    async def receiver_loop(self, ws):
        async for raw in ws:
            try:
                data = json.loads(raw)
            except (json.JSONDecodeError, TypeError, ValueError) as exc:
                logger.warning("Non-JSON or invalid message (%s): %r", exc, raw)
                continue

            topic = data.get("topic")
            msg = data.get("msg")
            if topic in (self.topic_map.state_accel, self.topic_map.state):
                logger.info("RX %s: %s", topic, msg)
            else:
                # ignore other topics
                pass

    async def run_server(self, host: str, port: int):
        async def handler(ws, path=None):
            logger.info("Client connected from %s, path=%s", ws.remote_address, path)
            try:
                await self.advertise_and_subscribe(ws)
                await asyncio.gather(
                    self.sender_loop(ws),
                    self.receiver_loop(ws),
                )
            except websockets.exceptions.ConnectionClosedOK:
                logger.info("Client closed connection (OK).")
            except websockets.exceptions.ConnectionClosedError as exc:
                logger.warning("Connection closed with error: %s", exc)
            except Exception as exc:  # pylint: disable=broad-exception-caught
                # Boundary: log anything unexpected to avoid silent failures
                logger.exception("Unexpected error in handler: %s", exc)

        async with websockets.serve(handler, host, port):
            logger.info("Server listening on %s:%d", host, port)
            await asyncio.Future()  # run forever


# --- Simple self-test entry point ---------------------------------------------
def main():
    """
    Minimal example:

    - Uses DummyOrbitSimData by default.
    - Currently only server mode is supported (client mode is reserved).
    """
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Simple WS sim communicator self-test (orbit trajectory)."
    )
    parser.add_argument("--mode", choices=["client", "server"], default="server")
    parser.add_argument("--port", type=int, default=9090, help="Port for server")
    parser.add_argument("--unity-physics-mode", action="store_true")
    parser.add_argument("--physics-frequency", type=float, default=500.0)
    parser.add_argument("--include-gravity", action="store_true")

    args = parser.parse_args()

    if args.mode == "client":
        # Keep the CLI option visible, but make it explicit that it's not supported yet.
        logger.error("Client mode is not implemented/tested yet. Please use --mode server.")
        sys.exit(1)

    communicator = WsSimCommunicator(
        unity_physics_mode=args.unity_physics_mode,
        physics_frequency=args.physics_frequency,
        include_gravity=args.include_gravity,
    )

    try:
        host = "0.0.0.0"
        logger.info("Server mode, listening on %s:%d", host, args.port)
        asyncio.run(communicator.run_server(host, args.port))
    except KeyboardInterrupt:
        print("\nInterrupted, shutting down.")


if __name__ == "__main__":
    main()
