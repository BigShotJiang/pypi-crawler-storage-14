#!/usr/bin/env python3
import math
from typing import Tuple

# --- Small 3x3 matrix + quaternion helpers (no numpy) ------------------------
def quat_to_rot(qx, qy, qz, qw):
    """Quaternion (x, y, z, w) -> 3x3 rotation matrix."""
    # assuming unit quaternion
    xx = qx * qx
    yy = qy * qy
    zz = qz * qz
    xy = qx * qy
    xz = qx * qz
    yz = qy * qz
    wx = qw * qx
    wy = qw * qy
    wz = qw * qz

    return [
        [1.0 - 2.0 * (yy + zz), 2.0 * (xy - wz), 2.0 * (xz + wy)],
        [2.0 * (xy + wz), 1.0 - 2.0 * (xx + zz), 2.0 * (yz - wx)],
        [2.0 * (xz - wy), 2.0 * (yz + wx), 1.0 - 2.0 * (xx + yy)],
    ]


def mat_mul(A, B):
    """3x3 * 3x3."""
    return [
        [
            A[i][0] * B[0][j] + A[i][1] * B[1][j] + A[i][2] * B[2][j]
            for j in range(3)
        ]
        for i in range(3)
    ]

def normalize_quat(
    qx: float, qy: float, qz: float, qw: float
) -> Tuple[float, float, float, float]:
    """Normalize quaternion (x, y, z, w)."""
    norm = math.sqrt(qx * qx + qy * qy + qz * qz + qw * qw)
    if norm > 0.0:
        qx /= norm
        qy /= norm
        qz /= norm
        qw /= norm
    return qx, qy, qz, qw

def rot_to_quat(R):
    """3x3 rotation matrix -> quaternion (x, y, z, w)."""
    tr = R[0][0] + R[1][1] + R[2][2]

    if tr > 0.0:
        S = math.sqrt(tr + 1.0) * 2.0  # S=4*w
        qw = 0.25 * S
        qx = (R[2][1] - R[1][2]) / S
        qy = (R[0][2] - R[2][0]) / S
        qz = (R[1][0] - R[0][1]) / S
    elif (R[0][0] > R[1][1]) and (R[0][0] > R[2][2]):
        S = math.sqrt(1.0 + R[0][0] - R[1][1] - R[2][2]) * 2.0
        qw = (R[2][1] - R[1][2]) / S
        qx = 0.25 * S
        qy = (R[0][1] + R[1][0]) / S
        qz = (R[0][2] + R[2][0]) / S
    elif R[1][1] > R[2][2]:
        S = math.sqrt(1.0 + R[1][1] - R[0][0] - R[2][2]) * 2.0
        qw = (R[0][2] - R[2][0]) / S
        qx = (R[0][1] + R[1][0]) / S
        qy = 0.25 * S
        qz = (R[1][2] + R[2][1]) / S
    else:
        S = math.sqrt(1.0 + R[2][2] - R[0][0] - R[1][1]) * 2.0
        qw = (R[1][0] - R[0][1]) / S
        qx = (R[0][2] + R[2][0]) / S
        qy = (R[1][2] + R[2][1]) / S
        qz = 0.25 * S

    return normalize_quat(qx, qy, qz, qw)
