#!/usr/bin/env python3
# pylint: disable=c-extension-no-member
"""
Log player CLI.

Responsibilities:
- Parse PX4 log into a generic FlightLogData structure.
- Create a generic TimeSeriesPlayback (log-agnostic).
- Drive playback via PlaybackController (pause/speed/seek).
- Wrap playback into a SimData implementation (PlaybackSimData).
- Start WsSimCommunicator (server) to feed the 3D sim.
- Optionally run a small PySide6 GUI to control PlaybackController.
"""

import sys
import math
import asyncio
import logging
import argparse
import threading
from typing import Optional, Sequence, Tuple, Callable
from autopilot_tools.saisei.ws_sim_communicator import WsSimCommunicator, SimData
from autopilot_tools.saisei.log_parser_px4 import parse_px4_log
from autopilot_tools.saisei.log_sim_data import (
    FlightLogData,
    SimPlaybackData,
    flight_log_to_sim_data,
)

logger = logging.getLogger(__name__)

try:
    import numpy as np
except ModuleNotFoundError:
    logger.critical("pip install numpy")
    sys.exit(1)

try:
    from PySide6 import QtWidgets, QtCore
except ModuleNotFoundError:
    logger.critical("pip install PySide6")
    sys.exit(1)


class TimeSeriesPlayback:
    """
    Generic playback for time-series data with step-wise hold.

    Input:
    - FlightLogData in flight-log frame (e.g. PX4 NED/FRD)

    Internally:
    - Data is converted once to sim frame (ENU/FLU) and stored.
    """

    # pylint: disable=too-many-instance-attributes
    def __init__(
        self,
        data: FlightLogData,
        quat_transform: Optional[
            Callable[[float, float, float, float], Tuple[float, float, float, float]]
        ] = None,
    ):
        # Convert NED/FRD -> ENU/FLU once; ignore external quat_transform for now.
        # (kept in signature to avoid widening diffs / breaking API)
        del quat_transform
        self.data: SimPlaybackData = flight_log_to_sim_data(data)

        # Duration ------------------------------------------------------------
        t_end_gps = float(self.data.gps.t[-1]) if self.data.gps.t.size > 0 else 0.0
        t_end_att = (
            float(self.data.attitude.t[-1])
            if self.data.attitude.t.size > 0
            else 0.0
        )
        t_end_act = (
            float(self.data.actuators.t[-1])
            if self.data.actuators.t.size > 0
            else 0.0
        )
        self._duration = max(t_end_gps, t_end_att, t_end_act)

    def get_duration(self) -> float:
        """Total duration in seconds."""
        return self._duration

    @staticmethod
    def _sample(t: float, ts: np.ndarray, *arrays: np.ndarray):
        """Return values from arrays at time t using step-wise hold."""
        if ts.size == 0:
            return None
        if t <= 0.0:
            idx = 0
        elif t >= ts[-1]:
            idx = len(ts) - 1
        else:
            idx = int(np.searchsorted(ts, t, side="right")) - 1
            idx = max(0, min(idx, len(ts) - 1))

        return tuple(a[idx] for a in arrays)

    def get_gps(self, t: float) -> Optional[Tuple[float, float, float]]:
        """GPS (lat, lon, alt) at time t."""
        gps = self.data.gps
        res = self._sample(t, gps.t, gps.lat, gps.lon, gps.alt)
        if res is None:
            return None

        # Convert numpy scalars to Python floats for JSON serialization.
        lat, lon, alt = res
        return float(lat), float(lon), float(alt)

    def get_attitude_quat(
        self,
        t: float,
    ) -> Optional[Tuple[float, float, float, float]]:
        """
        Quaternion (x, y, z, w) at time t (seconds from start),
        already in sim frame (ENU/FLU).
        """
        att = self.data.attitude
        res = self._sample(t, att.t, att.qx, att.qy, att.qz, att.qw)
        if res is None:
            return None

        qx, qy, qz, qw = res
        return float(qx), float(qy), float(qz), float(qw)

    def get_actuators(self, t: float) -> Optional[Sequence[float]]:
        """
        Actuator axes at time t.

        Returns a list of floats or None if no actuator series is available
        or the series is empty.
        """
        act = self.data.actuators
        res = self._sample(t, act.t, act.axes)
        if res is None:
            return None

        (row,) = res  # row is a 1D numpy array
        return [float(v) for v in row]


# --- Playback controller (GUI + SimData use this) -----------------------------


class PlaybackController:
    """
    Controls playback time, pause state, and speed.
    Intended to be used by SimData implementations.

    It is generic and does not know about PX4, ArduPilot, etc.
    """

    def __init__(self, t_end: float = 0.0):
        self._lock = threading.Lock()
        self.t_end = float(t_end)
        self.playback_time = 0.0
        self.paused = False
        self.speed = 1.0

    def advance(self, dt: float):
        with self._lock:
            if self.paused or self.t_end <= 0.0:
                return
            self.playback_time += dt * self.speed
            self.playback_time = max(self.playback_time, 0.0)
            self.playback_time = min(self.playback_time, self.t_end)

    def get_time(self) -> float:
        with self._lock:
            return self.playback_time

    def get_time_and_end(self) -> Tuple[float, float]:
        with self._lock:
            return self.playback_time, self.t_end

    def set_paused(self, paused: bool):
        with self._lock:
            self.paused = paused

    def set_speed(self, speed: float):
        with self._lock:
            self.speed = float(speed)

    def set_position_fraction(self, frac: float):
        with self._lock:
            if self.t_end <= 0.0:
                return
            frac = max(0.0, min(1.0, float(frac)))
            self.playback_time = frac * self.t_end


# --- SimData implementation for generic playback -----------------------------


class PlaybackSimData(SimData):
    """
    SimData implementation that reads from a generic TimeSeriesPlayback and a
    PlaybackController.

    This is log-agnostic: PX4, ArduPilot, custom, etc.
    """

    def __init__(self, playback: TimeSeriesPlayback, controller: PlaybackController):
        self._playback = playback
        self._controller = controller

    def advance(self, dt: float) -> None:
        self._controller.advance(dt)

    def _t_play(self) -> float:
        return self._controller.get_time()

    def get_attitude_quat(self) -> Optional[Tuple[float, float, float, float]]:
        t = self._t_play()
        return self._playback.get_attitude_quat(t)

    def get_gps(self) -> Optional[Tuple[float, float, float]]:
        t = self._t_play()
        return self._playback.get_gps(t)

    def get_actuators(self) -> Optional[Sequence[float]]:
        t = self._t_play()
        axes = self._playback.get_actuators(t)
        if axes is not None:
            return axes

        # Fallback: simple dummy pattern tied to playback time
        return [-math.sin(t), -math.cos(t), math.sin(t), math.cos(t)]


# --- PySide GUI (only knows about PlaybackController) -------------------------


class ControlWindow:  # pylint: disable=too-many-instance-attributes
    """
    Simple PySide6 window:

    - Pause/Continue button
    - x1/x2/x4/x8 speed combo box
    - Slider [0..1] for playback position
    """

    def __init__(self, controller: PlaybackController):
        self.controller = controller

        self.app = QtWidgets.QApplication(sys.argv)
        self.widget = QtWidgets.QWidget()
        self.widget.setWindowTitle("Log Player Controls")

        main_layout = QtWidgets.QVBoxLayout(self.widget)

        # Row with pause + speed
        row = QtWidgets.QHBoxLayout()
        main_layout.addLayout(row)

        self.pause_btn = QtWidgets.QPushButton("Pause")
        self.pause_btn.setCheckable(True)
        self.pause_btn.toggled.connect(self.on_pause_toggled)
        row.addWidget(self.pause_btn)

        self.speed_combo = QtWidgets.QComboBox()
        self.speed_combo.addItems(["x1", "x2", "x4", "x8"])
        self.speed_combo.currentIndexChanged.connect(self.on_speed_changed)
        row.addWidget(self.speed_combo)

        # Slider
        self.slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider.setMinimum(0)
        self.slider.setMaximum(1000)
        self.slider.setEnabled(controller.t_end > 0.0)
        self.slider.sliderPressed.connect(self.on_slider_pressed)
        self.slider.sliderReleased.connect(self.on_slider_released)
        self.slider.sliderMoved.connect(self.on_slider_moved)
        main_layout.addWidget(self.slider)

        # Time label
        self.time_label = QtWidgets.QLabel("0.0 / 0.0 s")
        main_layout.addWidget(self.time_label)

        self._slider_dragging = False

        # Timer to update slider + label
        self.timer = QtCore.QTimer(self.widget)
        self.timer.setInterval(100)  # ms
        self.timer.timeout.connect(self.on_timer)
        self.timer.start()

        self.widget.resize(400, 120)

    # --- Slots ------------------------------------------------------------
    def on_pause_toggled(self, checked: bool):
        # checked -> paused
        self.controller.set_paused(checked)
        self.pause_btn.setText("Continue" if checked else "Pause")

    def on_speed_changed(self, index: int):
        factors = [1.0, 2.0, 4.0, 8.0]
        if 0 <= index < len(factors):
            self.controller.set_speed(factors[index])

    def on_slider_pressed(self):
        self._slider_dragging = True

    def on_slider_released(self):
        self._slider_dragging = False
        self.on_slider_moved(self.slider.value())

    def on_slider_moved(self, value: int):
        _, t_end = self.controller.get_time_and_end()
        if t_end <= 0.0:
            return
        frac = value / float(self.slider.maximum())
        self.controller.set_position_fraction(frac)

    def on_timer(self):
        t, t_end = self.controller.get_time_and_end()
        if t_end > 0.0 and not self._slider_dragging:
            frac = t / t_end if t_end > 0.0 else 0.0
            self.slider.setValue(int(frac * self.slider.maximum()))
        self.time_label.setText(f"{t:.1f} / {t_end:.1f} s")

    # --- Run --------------------------------------------------------------
    def run(self):
        self.widget.show()
        self.app.exec()


# --- Entry point --------------------------------------------------------------


def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    parser = argparse.ArgumentParser(description="Log player → WS sim bridge")
    parser.add_argument("--port", type=int, default=9090)
    parser.add_argument("--unity-physics-mode", action="store_true")
    parser.add_argument("--physics-frequency", type=float, default=500.0)
    parser.add_argument("--include-gravity", action="store_true")

    parser.add_argument(
        "--log",
        type=str,
        default=None,
        help="Path to a flight log for replay (optional).",
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Enable PySide6 GUI for playback controls.",
    )

    args = parser.parse_args()

    # Build playback + controller + sim_data (if log is provided)
    playback: Optional[TimeSeriesPlayback] = None
    sim_data: Optional[SimData] = None

    if args.log:
        playback = TimeSeriesPlayback(data=parse_px4_log(args.log))
        controller = PlaybackController(playback.get_duration())
        sim_data = PlaybackSimData(playback, controller)
    else:
        # No log: WsSimCommunicator will fall back to DummyOrbitSimData.
        controller = PlaybackController(0.0)

    communicator = WsSimCommunicator(
        unity_physics_mode=args.unity_physics_mode,
        physics_frequency=args.physics_frequency,
        include_gravity=args.include_gravity,
        sim_data=sim_data,  # None => DummyOrbitSimData inside communicator
    )

    def run_asyncio():
        try:
            host = "0.0.0.0"
            logger.info("Server mode, listening on %s:%d", host, args.port)
            asyncio.run(
                communicator.run_server(
                    host,
                    args.port,
                )
            )
        except KeyboardInterrupt:
            print("\nInterrupted, shutting down.")

    if args.gui:
        # Run asyncio WS server in background thread
        thread = threading.Thread(target=run_asyncio, daemon=True)
        thread.start()

        # GUI in main thread
        gui = ControlWindow(controller)
        gui.run()
    else:
        # Headless mode (no GUI), run asyncio in main thread
        run_asyncio()


if __name__ == "__main__":
    main()
