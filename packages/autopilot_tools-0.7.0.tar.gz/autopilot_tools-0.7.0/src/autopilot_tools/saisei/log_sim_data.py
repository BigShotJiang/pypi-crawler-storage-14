#!/usr/bin/env python3
import logging
from dataclasses import dataclass
from typing import Sequence
import numpy as np
from autopilot_tools.saisei.utils import (
    quat_to_rot,
    mat_mul,
    rot_to_quat,
    normalize_quat,
)

logger = logging.getLogger(__name__)


@dataclass
class GpsSeries:
    """
    GPS time-series (canonical representation):

    - t: timestamps (seconds from log start, t[0] == 0 if non-empty)
    - lat, lon: degrees
    - alt: meters

    Implementations are expected to provide these as 1D numpy arrays
    of dtype float64, but any indexable float sequence is accepted.
    """
    t: Sequence[float]
    lat: Sequence[float]
    lon: Sequence[float]
    alt: Sequence[float]


@dataclass
class AttitudeSeries:
    """
    Attitude time-series (canonical representation):

    - t: timestamps (seconds from log start, t[0] == 0 if non-empty)
    - qx,qy,qz,qw: quaternion in some log-specific convention

    Implementations are expected to provide these as 1D numpy arrays
    of dtype float64, but any indexable float sequence is accepted.
    """
    t: Sequence[float]
    qx: Sequence[float]
    qy: Sequence[float]
    qz: Sequence[float]
    qw: Sequence[float]


@dataclass
class ActuatorSeries:
    """
    Actuator time-series (canonical representation):

    - t: timestamps (seconds from log start, t[0] == 0 if non-empty)
    - axes: per-sample actuator channels, e.g. shape [N_samples][N_channels]

    Implementations are expected to provide:
    - t as a 1D numpy array of dtype float64
    - axes as a 2D numpy array of dtype float64
    """
    t: Sequence[float]
    axes: Sequence[Sequence[float]]

@dataclass
class FlightLogMeta:
    autopilot: str  # "px4", "ardupilot", ...
    fw_version: str | None
    vehicle_type: str | None  # "multirotor", "plane", "vtol", ...
    log_path: str | None
    date: str | None

@dataclass
class FlightLogData:
    """
    Generic time-series data as stored in flight logs (e.g. PX4, ArduPilot).

    Each sub-series is aligned on its own timestamps, which follow
    the canonical convention:
    - seconds from log start
    - t[0] == 0 if the series is non-empty
    - monotonic non-decreasing

    Frames / conventions are log-specific, e.g.:
    - PX4: NED world, FRD body
    - ArduPilot: typically also NED / FRD

    - gps: GPS series (may be empty)
    - attitude: attitude series (may be empty)
    - actuators: actuator series (may be empty)
    """
    gps: GpsSeries
    attitude: AttitudeSeries
    actuators: ActuatorSeries
    meta: FlightLogMeta


@dataclass
class SimPlaybackData:
    """
    Generic time-series data prepared for simulation / visualization.

    Same structural layout as FlightLogData, but attitude is expected
    to be in the simulator's convention (e.g. ENU world, FLU body).

    - gps: GPS series (usually identical to the log, lat/lon/alt)
    - attitude: attitude in sim frame (e.g. ENU/FLU)
    - actuators: actuator series (may be copied from the log)
    """
    gps: GpsSeries
    attitude: AttitudeSeries
    actuators: ActuatorSeries

# pylint: disable=too-many-locals
def attitude_ned_frd_to_enu_flu(attitude: AttitudeSeries) -> AttitudeSeries:
    s_world = [
        [0.0, 1.0, 0.0],
        [1.0, 0.0, 0.0],
        [0.0, 0.0, -1.0],
    ]
    s_body = [
        [1.0, 0.0, 0.0],
        [0.0, -1.0, 0.0],
        [0.0, 0.0, -1.0],
    ]

    n = len(attitude.qx)
    qx_out = np.empty(n, dtype="float64")
    qy_out = np.empty(n, dtype="float64")
    qz_out = np.empty(n, dtype="float64")
    qw_out = np.empty(n, dtype="float64")

    for i in range(n):
        qx = float(attitude.qx[i])
        qy = float(attitude.qy[i])
        qz = float(attitude.qz[i])
        qw = float(attitude.qw[i])

        # Normalize once here in log frame
        qx, qy, qz, qw = normalize_quat(qx, qy, qz, qw)

        # Rotation from FRD body to NED world (PX4 convention)
        r_ned_frd = quat_to_rot(qx, qy, qz, qw)

        # Convert to ENU/FLU:
        # R^ENU_FLU = S_world * R^NED_FRD * S_body
        r_tmp = mat_mul(s_world, r_ned_frd)
        r_enu_flu = mat_mul(r_tmp, s_body)

        # Back to quaternion (x,y,z,w) in ENU/FLU
        qx2, qy2, qz2, qw2 = rot_to_quat(r_enu_flu)

        qx_out[i] = qx2
        qy_out[i] = qy2
        qz_out[i] = qz2
        qw_out[i] = qw2

    return AttitudeSeries(t=attitude.t, qx=qx_out, qy=qy_out, qz=qz_out, qw=qw_out)

def flight_log_to_sim_data(data: FlightLogData) -> SimPlaybackData:
    """
    Convert flight-log-frame data into sim-frame data.
    - Flight log (PX4, ArduPilot): world = NED, body = FRD.
    - Sim: world = ENU, body = FLU.
    """
    return SimPlaybackData(
        gps=data.gps,
        attitude=attitude_ned_frd_to_enu_flu(data.attitude),
        actuators=data.actuators,
    )
