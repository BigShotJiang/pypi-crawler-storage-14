#!/usr/bin/env python3
# pylint: disable=too-many-branches
# pylint: disable=too-many-statements
import sys
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable, Tuple

import numpy as np

from autopilot_tools.saisei.log_sim_data import (
    FlightLogData,
    GpsSeries,
    AttitudeSeries,
    ActuatorSeries,
    FlightLogMeta,
)

logger = logging.getLogger(__name__)

try:
    from pyulog import ULog
except ModuleNotFoundError:
    logger.critical("pip install pyulog")
    sys.exit(1)


@dataclass
class Px4Topics:
    """
    All PX4 uORB topic names used by the PX4 → FlightLogData parser.

    Each attribute is a tuple of alternative topic names. The first
    existing one in the ULog will be used.
    """
    gps_position: Tuple[str, ...] = ("vehicle_gps_position",)
    attitude: Tuple[str, ...] = ("vehicle_attitude",)
    actuator_motors: Tuple[str, ...] = ("actuator_motors", "actuator_motors_0")
    actuator_servos: Tuple[str, ...] = ("actuator_servos", "actuator_servos_0")


TOPICS = Px4Topics()


def _find_topic(ulog: "ULog", names: Iterable[str]):
    """Return first data set whose name is in 'names', or None."""
    names_set = set(names)
    for data in ulog.data_list:
        if data.name in names_set:
            return data
    return None


def _extract_controls_matrix(fields: dict) -> np.ndarray:
    """
    Extract actuator controls as a 2D matrix [N_samples, N_channels].

    Supports:
    - 'control' field directly (vector per sample), or
    - split fields 'control[0]', 'control[1]', ...

    Post-processing rules:
    - Drop channels that are all NaN (no real actuator there).
    - For channels that have at least one real value, replace NaNs
      with 0.0 (actuator exists but was inactive at those samples).
    """
    if "control" in fields:
        raw = np.asarray(fields["control"], dtype="float64")
        if raw.ndim == 1:
            mat = raw.reshape(-1, 1)
        elif raw.ndim == 2:
            mat = raw
        else:
            return np.empty((0, 0), dtype="float64")
    else:
        cols = []
        max_idx = -1
        for name in fields:
            if name.startswith("control[") and name.endswith("]"):
                idx_str = name[len("control["):-1]
                try:
                    idx = int(idx_str)
                except ValueError:
                    continue
                max_idx = max(max_idx, idx)

        if max_idx < 0:
            return np.empty((0, 0), dtype="float64")

        for idx in range(max_idx + 1):
            key = f"control[{idx}]"
            if key not in fields:
                break
            cols.append(np.asarray(fields[key], dtype="float64"))

        if not cols:
            return np.empty((0, 0), dtype="float64")

        mat = np.vstack(cols).T  # [N_channels, N_samples] -> [N_samples, N_channels]

    if mat.size == 0:
        return mat

    # 1) Drop channels that are all NaN.
    valid_mask = ~np.all(np.isnan(mat), axis=0)
    if not valid_mask.any():
        return np.empty((mat.shape[0], 0), dtype="float64")
    mat = mat[:, valid_mask]

    # 2) For remaining channels (at least one real sample), replace NaN with 0.0.
    mat = np.nan_to_num(mat, nan=0.0)

    return mat


def _parse_gps(ulog: "ULog") -> Tuple[GpsSeries, np.ndarray]:
    """Parse GPS series from ULog into GpsSeries + raw time array."""
    gps_data = _find_topic(ulog, TOPICS.gps_position)
    if gps_data is None:
        logger.warning("No 'vehicle_gps_position' in log. GPS will not be available.")
        gps_t = lat = lon = alt = np.array([], dtype="float64")
    else:
        gps_fields = gps_data.data
        gps_t = gps_fields["timestamp"].astype("float64") * 1e-6

        def choose_field(candidates):
            for cand in candidates:
                if cand in gps_fields:
                    return gps_fields[cand]
            return None

        lat = choose_field(["lat", "latitude", "latitude_deg"])
        lon = choose_field(["lon", "longitude", "longitude_deg"])
        alt = choose_field(["alt", "altitude", "altitude_msl_m"])

        if lat is None or lon is None or alt is None:
            logger.warning(
                "Could not find lat/lon/alt fields in GPS topic; "
                "GPS will not be available."
            )
            gps_t = lat = lon = alt = np.array([], dtype="float64")
        elif gps_t.size > 0:
            # Normalize to start from 0 (canonical playback convention)
            gps_t = gps_t - gps_t[0]

    gps_series = GpsSeries(
        t=gps_t,
        lat=lat,
        lon=lon,
        alt=alt,
    )
    return gps_series, gps_t


def _parse_attitude(ulog: "ULog") -> Tuple[AttitudeSeries, np.ndarray]:
    """Parse attitude series from ULog into AttitudeSeries + raw time array."""
    att_data = _find_topic(ulog, TOPICS.attitude)
    if att_data is None:
        logger.warning("No 'vehicle_attitude' in log. Attitude will not be available.")
        att_t = qx = qy = qz = qw = np.array([], dtype="float64")
    else:
        att_fields = att_data.data
        att_t = att_fields["timestamp"].astype("float64") * 1e-6

        try:
            q0 = att_fields["q[0]"]
            q1 = att_fields["q[1]"]
            q2 = att_fields["q[2]"]
            q3 = att_fields["q[3]"]
        except KeyError:
            logger.warning(
                "vehicle_attitude quaternion fields q[0..3] not found. "
                "Attitude will not be available."
            )
            att_t = qx = qy = qz = qw = np.array([], dtype="float64")
        else:
            # q[0] = w, q[1] = x, q[2] = y, q[3] = z
            qw = q0
            qx = q1
            qy = q2
            qz = q3

            if att_t.size > 0:
                # Normalize to start from 0 (canonical playback convention)
                att_t = att_t - att_t[0]

    attitude_series = AttitudeSeries(
        t=att_t,
        qx=qx,
        qy=qy,
        qz=qz,
        qw=qw,
    )
    return attitude_series, att_t


def _parse_actuators(ulog: "ULog") -> ActuatorSeries:  # pylint: disable=too-many-locals
    """Parse motors + servos topics into a single ActuatorSeries."""
    motors_data = _find_topic(ulog, TOPICS.actuator_motors)
    servos_data = _find_topic(ulog, TOPICS.actuator_servos)

    if motors_data is None and servos_data is None:
        logger.warning(
            "No 'actuator_motors' or 'actuator_servos' topics in log. "
            "Actuators will not be available."
        )
        act_t = np.array([], dtype="float64")
        act_axes = np.empty((0, 0), dtype="float64")
    else:
        motors_t_us = None
        motors_axes = None
        servos_t_us = None
        servos_axes = None

        if motors_data is not None:
            motors_fields = motors_data.data
            if "timestamp_sample" in motors_fields:
                motors_t_us = motors_fields["timestamp_sample"].astype("float64")
            elif "timestamp" in motors_fields:
                motors_t_us = motors_fields["timestamp"].astype("float64")
            else:
                motors_t_us = np.array([], dtype="float64")

            motors_axes = _extract_controls_matrix(motors_fields)

        if servos_data is not None:
            servos_fields = servos_data.data
            if "timestamp_sample" in servos_fields:
                servos_t_us = servos_fields["timestamp_sample"].astype("float64")
            elif "timestamp" in servos_fields:
                servos_t_us = servos_fields["timestamp"].astype("float64")
            else:
                servos_t_us = np.array([], dtype="float64")

            servos_axes = _extract_controls_matrix(servos_fields)

        first_times = []
        if motors_t_us is not None and motors_t_us.size > 0:
            first_times.append(motors_t_us[0])
        if servos_t_us is not None and servos_t_us.size > 0:
            first_times.append(servos_t_us[0])

        if not first_times:
            act_t = np.array([], dtype="float64")
            act_axes = np.empty((0, 0), dtype="float64")
        else:
            t0_us = min(first_times)

            if motors_t_us is not None and motors_t_us.size > 0:
                motors_t = (motors_t_us - t0_us) * 1e-6
            else:
                motors_t = np.array([], dtype="float64")

            if servos_t_us is not None and servos_t_us.size > 0:
                servos_t = (servos_t_us - t0_us) * 1e-6
            else:
                servos_t = np.array([], dtype="float64")

            if motors_t.size > 0 and (servos_t is None or servos_t.size == 0):
                act_t = motors_t
                act_axes = (
                    motors_axes
                    if motors_axes is not None
                    else np.empty((motors_t.size, 0), dtype="float64")
                )
            elif servos_t.size > 0 and (motors_t is None or motors_t.size == 0):
                act_t = servos_t
                act_axes = (
                    servos_axes
                    if servos_axes is not None
                    else np.empty((servos_t.size, 0), dtype="float64")
                )
            else:
                act_t = motors_t
                motors_axes = (
                    motors_axes
                    if motors_axes is not None
                    else np.empty((act_t.size, 0), dtype="float64")
                )
                if servos_axes is None or servos_t.size == 0 or servos_axes.size == 0:
                    servos_interp = np.empty((act_t.size, 0), dtype="float64")
                else:
                    idxs = np.searchsorted(servos_t, act_t, side="right") - 1
                    idxs_clipped = np.clip(idxs, 0, max(0, servos_t.size - 1))
                    servos_interp = servos_axes[idxs_clipped, :]

                    before_mask = idxs < 0
                    if np.any(before_mask):
                        servos_interp[before_mask, :] = 0.0

                act_axes = np.hstack([motors_axes, servos_interp])

    return ActuatorSeries(
        t=act_t,
        axes=act_axes,
    )

def _parse_metadata(ulog, path) -> FlightLogMeta:
    info_dict = getattr(ulog, "msg_info_dict", {})
    fw_version = None
    for key in ("ver_sw", "ver_sw_git", "ver_sw_release", "git_tag"):
        if key in info_dict:
            fw_version = str(info_dict[key])
            break

    log_date = None
    try:
        ts_us = getattr(ulog, "start_timestamp", None)
        if ts_us:
            log_date = datetime.fromtimestamp(
                ts_us / 1e6,
                tz=timezone.utc,
            )
    except Exception:  # pylint: disable=broad-exception-caught
        log_date = None

    meta = FlightLogMeta(
        autopilot="px4",
        fw_version=fw_version,
        vehicle_type=None,
        log_path=path,
        date=log_date,
    )

    return meta

def parse_px4_log(path: str) -> FlightLogData:
    """
    Parse a PX4 ULog into generic FlightLogData (no frame transform).

    The quaternion is still in PX4 convention:
    - world: NED
    - body: FRD
    with q[0] = w, q[1] = x, q[2] = y, q[3] = z.
    """

    logger.info("Loading PX4 log from %s", path)
    ulog = ULog(path)

    # --- Per-series parsing --------------------------------------------------
    gps_series, gps_t = _parse_gps(ulog)
    attitude_series, att_t = _parse_attitude(ulog)
    actuator_series = _parse_actuators(ulog)
    meta = _parse_metadata(ulog, path)

    # --- Duration for meta / logging ----------------------------------------
    t_end_gps = float(gps_t[-1]) if gps_t.size > 0 else 0.0
    t_end_att = float(att_t[-1]) if att_t.size > 0 else 0.0
    t_end_act = (
        float(actuator_series.t[-1])
        if hasattr(actuator_series.t, "size") and actuator_series.t.size > 0
        else 0.0
    )
    duration_s = max(t_end_gps, t_end_att, t_end_act)

    data = FlightLogData(
        gps=gps_series,
        attitude=attitude_series,
        actuators=actuator_series,
        meta=meta,
    )

    # --- Summary -------------------------------------------------------------
    logger.info(
        "PX4 log parsed. Duration ~%.1f s, GPS samples: %d, attitude samples: %d",
        duration_s,
        len(gps_series.lat),
        len(attitude_series.qx),
    )
    return data
