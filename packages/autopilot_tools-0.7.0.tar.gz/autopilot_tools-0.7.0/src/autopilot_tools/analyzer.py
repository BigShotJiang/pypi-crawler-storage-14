#!/usr/bin/env python3

class Analyzer:
    def __init__(self) -> None:
        pass
