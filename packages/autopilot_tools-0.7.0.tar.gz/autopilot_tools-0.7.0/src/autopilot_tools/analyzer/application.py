#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2023-2024 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>
"""
Docstring is under construction
"""
import time
import random
import logging
import subprocess
from pathlib import Path
from typing import Optional

from reactions import Reactions
from reports import TelegramReportCreator
from log_parser import LogParser

logger = logging.getLogger(__name__)
MODULE_DIR = Path(__file__).resolve().parent

WRONG_FILE_REPLIES = [
    "Nice try 😏 But I only work with `.ulog` files.",
    "This is cute, but I only support `.ulog` files.",
    "Wrong flavor. I only digest `.ulog` files.",
    "I see a file. I don’t see a `.ulog` file. Try again.",
    "Close, but not close enough. Send me a `.ulog` file.",
    "I’m picky. Only `.ulog` files get VIP access.",
    "File rejected 🚫 I only accept `.ulog`.",
    "This isn’t a `.ulog` file. I checked. Twice.",
]
def get_wrong_file_reply() -> str:
    return random.choice(WRONG_FILE_REPLIES)

def run_cmd(cmd: list):
    return subprocess.run(cmd,
                          stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,
                          text=True,
                          check=False)

class StateLogger:
    def __init__(self, flbot, chat_id, reply_id) -> None:
        self.flbot = flbot
        self.chat_id = chat_id
        self.reply_id = reply_id
        self.msg_id = None

    async def update(self, text, reaction):
        if reaction in [Reactions.IN_PROCESS, Reactions.DONE]:
            logger.info(text)
        else:
            logger.error(text)

        if self.msg_id is None:
            self.msg_id = await self.flbot.send_message(self.chat_id, text, self.reply_id)
        else:
            await self.flbot.edit_message_text(self.chat_id, self.msg_id, text)

        await self.flbot.set_message_reaction(self.chat_id, self.reply_id, reaction.value)

def upload_to_px4_flight_review(log_path: str) -> str:
    script_path = MODULE_DIR / "log_upload.py"
    cmd = [script_path, log_path, '-q']
    res = run_cmd(cmd)
    url = res.stdout[5:]
    return url

class Application:
    def __init__(self, flbot, known_vehicles, flight_review : bool = False):
        self.flbot = flbot
        self.known_vehicles = known_vehicles
        self.flight_review = flight_review
        self.url = "-"
        self.data = {}

    def start_command_handler(self, _: int):
        return __doc__

    def message_handler(self, _chat_id: int, _msg: str, replied_id: Optional[int]) -> dict:
        reaction = Reactions.DONE.value if replied_id else Reactions.IDN.value
        return {
            "text": "I'm starving for .ulog files 🛩️",
            "reaction": reaction,
        }

    async def handle_file(self, chat_id: int, msg_id: int, file: dict):
        logger.debug("handle_file(%s, %s, %s, %s, %s)",
                     chat_id,
                     msg_id,
                     file["id"],
                     file["name"],
                     file["size"],
        )

        state_logger = StateLogger(flbot=self.flbot, chat_id=chat_id, reply_id=msg_id)

        if not file["name"].endswith(".ulg"):
            await state_logger.update(get_wrong_file_reply(), Reactions.ERROR)
            return

        step = "Step 1. Getting file"
        approx_req_time = int(file["size"] / self.flbot.DOWNLOAD_SPEED_MB_PER_SEC)
        await state_logger.update(
            f"{step}: {file['name']}, {file['size']} MB, ≈{approx_req_time} sec...",
            Reactions.IN_PROCESS
        )
        try:
            start_time = time.time()
            log_path = await self.flbot.get_file(file["id"], file["name"])
            duration = time.time() - start_time
            logger.info("%s: %s has been downloaded within %s sec", step, log_path, duration)
        except (ValueError, Exception) as err:  # pylint: disable=broad-exception-caught
            await state_logger.update(
                f"{step}. Failed:{type(err).__name__}:{err}",
                Reactions.ERROR
            )
            return

        step = "Step 2. Uploading to PX4 Flight Review"
        await state_logger.update(
            f"{step}...",
            Reactions.IN_PROCESS
        )
        try:
            if not self.flight_review:
                self.url = "Skip for a while"
                logger.info("%s. Skipped.", step)
            else:
                self.url = upload_to_px4_flight_review(log_path)
                logger.debug("Done")
        except Exception as err:  # pylint: disable=broad-exception-caught
            self.url = "Failed"
            await state_logger.update(
                f"{step}. Failed:{type(err).__name__}:{err}",
                Reactions.ERROR
            )
            # This is an iptional step, so a failure is not critical

        step = "Step 3. Parsing log"
        approx_req_time = int(file["size"] / self.flbot.PARSING_SPEED_MB_PER_SEC)
        await state_logger.update(
            f"{step}: ≈{approx_req_time} sec...",
            Reactions.IN_PROCESS
        )
        try:
            start_time = time.time()
            self.data = LogParser(log_path).parse()
            logger.info("%s. Done in %s sec", step, time.time() - start_time)
        except Exception as err:  # pylint: disable=broad-exception-caught
            await state_logger.update(
                f"{step}. Failed:{type(err).__name__}:{err}",
                Reactions.ERROR
            )
            return

        step = "Step 4. Constructing flight report"
        await state_logger.update(
            f"{step}...",
            Reactions.IN_PROCESS
        )
        try:
            start_time = time.time()
            text = TelegramReportCreator(self.data, self.url, self.known_vehicles).create()
            logger.info("%s. Done in %s sec", step, time.time() - start_time)
        except Exception as err:  # pylint: disable=broad-exception-caught
            text = f"{step}. Failed:{type(err).__name__}:{err}"
            await state_logger.update(text, Reactions.ERROR)
            return

        await state_logger.update(text, Reactions.DONE)
