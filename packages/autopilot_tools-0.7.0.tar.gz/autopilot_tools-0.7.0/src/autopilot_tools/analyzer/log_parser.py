#!/usr/bin/env python3
# This software is distributed under the terms of the MIT License.
# Copyright (c) 2023-2024 Dmitry Ponomarev.
# Author: Dmitry Ponomarev <ponomarevda96@gmail.com>

import sys
import logging
from typing import Optional, Mapping, Sequence
from dataclasses import dataclass

logger = logging.getLogger(__name__)

try:
    from pyulog import ULog
except ModuleNotFoundError:
    logger.critical("pip install pyulog>=1.2.2")
    sys.exit(1)


TopicData = Mapping[str, Sequence]


def parse_topic(
    log_path: str,
    topic_name: str,
    idx: int = 0,
    ulog: Optional[ULog] = None,
) -> Optional[TopicData]:
    """
    Return a mapping (field_name -> sequence of values) for a given topic and
    instance index using pyulog.

    If `ulog` is provided, it is used directly. Otherwise, a new ULog instance
    is created filtered to the given topic.
    """
    # Use existing ULog instance if available, otherwise create a new one
    if ulog is None:
        try:
            ulog = ULog(log_path, message_name_filter_list=[topic_name])
        except Exception as exc:  # pylint: disable=broad-exception-caught
            logger.error("Failed to parse ULog %s: %s", log_path, exc)
            return None

    # Collect all datasets with this name (multi_id support)
    datasets = [d for d in ulog.data_list if d.name == topic_name]

    if not datasets:
        return None
    if idx < 0 or idx >= len(datasets):
        return None

    dataset = datasets[idx]
    if not dataset.data:
        return None

    # dataset.data is a dict: field_name -> numpy array
    return dataset.data


@dataclass
class BaseTopic:
    def __init__(self, name: str) -> None:
        self.name = name

    def hw_stats(self) -> str:
        return "❌"

    def sw_stats(self) -> str:
        return "❌"


@dataclass
class BatteryStatus:
    remaining: Sequence[float]
    current_a: Sequence[float]
    id: int

    @property
    def remaining_max_pct(self) -> int:
        return int(max(self.remaining) * 100)

    @property
    def remaining_min_pct(self) -> int:
        return int(min(self.remaining) * 100)

    @property
    def max_current(self) -> int:
        return int(max(self.current_a))

    @staticmethod
    def parse_log(
        log_path: str,
        topic_name: str = "battery_status",
        idx: int = 0,
        ulog: Optional[ULog] = None,
    ) -> Optional["BatteryStatus"]:
        data = parse_topic(log_path, topic_name, idx=idx, ulog=ulog)
        if data is None:
            return None

        battery_status = BatteryStatus(
            remaining=data["remaining"],
            current_a=data["current_a"],
            id=int(data["id"][0]),
        )

        return battery_status

    def hw_stats(self) -> str:
        stats = (
            "Battery: "
            f"Remaining: {self.remaining_max_pct} -> {self.remaining_min_pct} %, "
            f"Max current: {self.max_current} A"
        )
        return stats

    def __str__(self) -> str:
        return (
            f"BatteryStatus("
            f"remaining_max_pct={self.remaining_max_pct}, "
            f"remaining_min_pct={self.remaining_min_pct})"
        )


@dataclass
class IceStatus:
    sw_git_hash: str
    max_adc_temperature_ice: int
    max_rpm: int

    @staticmethod
    def parse_log(
        log_path: str,
        topic_name: str = "internal_combustion_engine_status",
        ulog: Optional[ULog] = None,
    ):
        data = parse_topic(log_path, topic_name, idx=0, ulog=ulog)
        if data is None:
            return BaseTopic(name="ICE")

        # flags is logged as an integer -> hex string
        sw_git_hash = hex(int(data["flags"][0]))

        if "adc_temperature_ice" in data:
            adc_temperature_ice = data["adc_temperature_ice"]
        elif "external_temperature" in data:
            adc_temperature_ice = data["external_temperature"]
        elif "intake_manifold_temperature" in data:
            # Kelvin -> Celsius
            intake = data["intake_manifold_temperature"]
            adc_temperature_ice = [v - 273.15 for v in intake]
        else:
            adc_temperature_ice = [0]

        max_adc_temperature_ice = int(max(adc_temperature_ice))

        rpm = data["engine_speed_rpm"]
        max_rpm = int(max(rpm))

        ice_status = IceStatus(
            sw_git_hash=sw_git_hash,
            max_adc_temperature_ice=max_adc_temperature_ice,
            max_rpm=max_rpm,
        )
        return ice_status

    def hw_stats(self) -> str:
        stats = (
            f"Max temperature: {self.max_adc_temperature_ice} Celcius, "
            f"Max RPM: {self.max_rpm}"
        )
        return stats

    def sw_stats(self) -> str:
        return f"{self.sw_git_hash}"


@dataclass
class EscStatus:
    esc_0_rpm: float
    esc_1_rpm: float
    esc_2_rpm: float
    esc_3_rpm: float

    @staticmethod
    def parse_log(
        log_path: str,
        topic_name: str = "esc_status",
        ulog: Optional[ULog] = None,
    ):
        data = parse_topic(log_path, topic_name, idx=0, ulog=ulog)
        if data is None:
            return BaseTopic(name="ESC")

        # NOTE: if fields are missing, this will still raise KeyError, same as before
        try:
            esc_rpm = (
                data["esc[0].esc_rpm"],
                data["esc[1].esc_rpm"],
                data["esc[2].esc_rpm"],
                data["esc[3].esc_rpm"],
            )
        except KeyError:
            esc_rpm = ([-1], [-1], [-1], [-1])

        esc_status = EscStatus(
            esc_0_rpm=float(max(esc_rpm[0])),
            esc_1_rpm=float(max(esc_rpm[1])),
            esc_2_rpm=float(max(esc_rpm[2])),
            esc_3_rpm=float(max(esc_rpm[3])),
        )

        return esc_status

    def hw_stats(self) -> str:
        stats = (
            "Max RPM: "
            f"{self.esc_0_rpm}, "
            f"{self.esc_1_rpm}, "
            f"{self.esc_2_rpm}, "
            f"{self.esc_3_rpm}\n"
        )
        return stats


@dataclass
class UlogInfo:
    sys_uuid: Optional[str]
    ver_hw: Optional[str]
    ver_sw: Optional[str]
    ver_sw_branch: Optional[str]
    vehicle: str
    ver_sw_release: Optional[str]
    ver_vendor_sw_release: Optional[str]

    @staticmethod
    def parse_log(log_path: str, ulog: Optional[ULog] = None) -> "UlogInfo":
        """
        Parse basic info from the ULog header/info messages using pyulog only.
        """
        if ulog is None:
            try:
                ulog = ULog(
                    log_path,
                    message_name_filter_list=None,
                    parse_header_only=True,
                )
            except Exception as exc:  # pylint: disable=broad-exception-caught
                logger.error("Failed to parse ULog info %s: %s", log_path, exc)
                return UlogInfo(
                    sys_uuid=None,
                    ver_hw=None,
                    ver_sw=None,
                    ver_sw_branch=None,
                    vehicle="",
                    ver_sw_release=None,
                    ver_vendor_sw_release=None,
                )

        info_dict = getattr(ulog, "msg_info_dict", {})

        def get_str(key: str) -> Optional[str]:
            val = info_dict.get(key)
            if val is None:
                return None
            return str(val)

        def get_int(key: str) -> Optional[int]:
            val = info_dict.get(key)
            if val is None:
                return None
            try:
                return int(val)
            except (TypeError, ValueError):
                return None

        ver_sw_release_int = get_int("ver_sw_release")
        ver_vendor_sw_release_int = get_int("ver_vendor_sw_release")

        ver_sw_release_str: Optional[str] = None
        ver_vendor_sw_release_str: Optional[str] = None

        if ver_sw_release_int is not None:
            ver_sw_release_str = UlogInfo.semver(ver_sw_release_int)

        if ver_vendor_sw_release_int is not None:
            ver_vendor_sw_release_str = UlogInfo.semver(ver_vendor_sw_release_int)

        ulog_info = UlogInfo(
            sys_uuid=get_str("sys_uuid"),
            ver_hw=get_str("ver_hw"),
            ver_sw=get_str("ver_sw"),
            ver_sw_branch=get_str("ver_sw_branch"),
            vehicle="",  # can be filled later from other info if needed
            ver_sw_release=ver_sw_release_str,
            ver_vendor_sw_release=ver_vendor_sw_release_str,
        )

        return ulog_info

    def full_sw_version(self) -> str:
        try:
            if self.ver_vendor_sw_release is not None:
                version = (
                    f"v{self.ver_sw_release}-{self.ver_vendor_sw_release}"
                    f"_{self.ver_sw[:8]} ({self.ver_sw_branch})"
                )
            else:
                version = (
                    f"v{self.ver_sw_release}_{self.ver_sw[:8]} "
                    f"({self.ver_sw_branch})"
                )
            return version
        except TypeError:
            return ""

    @staticmethod
    def semver(release: int) -> str:
        major = (release >> 24) & 0xFF
        minor = (release >> 16) & 0xFF
        patch = (release >> 8) & 0xFF
        type_val = release & 0xFF

        type_str = ""
        if type_val == 255:
            type_str = ""
        elif type_val >= 192:
            type_str = "-RC"
        elif type_val >= 128:
            type_str = "-beta"
        elif type_val >= 64:
            type_str = "-alpha"
        else:
            type_str = ""

        return f"{major}.{minor}.{patch}{type_str}"


@dataclass
class ParsedLog:
    info: UlogInfo
    battery: list[BatteryStatus]
    esc: Optional[EscStatus]
    ice: Optional[IceStatus]


class LogParser:
    def __init__(self, log_path: str):
        self.log_path = log_path
        # Load once, reuse for all parsing
        self._ulog = ULog(log_path)

    def parse(self) -> ParsedLog:
        log_info = UlogInfo.parse_log(self.log_path, ulog=self._ulog)

        battery_statuses: list[BatteryStatus] = []
        # preserve your "up to 4" search, but now using multi_id instances
        for idx in range(4):
            battery_status = BatteryStatus.parse_log(
                self.log_path, idx=idx, ulog=self._ulog
            )
            if battery_status is not None:
                battery_statuses.append(battery_status)
            else:
                break

        ice_status = IceStatus.parse_log(self.log_path, ulog=self._ulog)
        esc_status = EscStatus.parse_log(self.log_path, ulog=self._ulog)

        parsed_log = ParsedLog(
            info=log_info,
            battery=battery_statuses,
            ice=ice_status,
            esc=esc_status,
        )

        return parsed_log
