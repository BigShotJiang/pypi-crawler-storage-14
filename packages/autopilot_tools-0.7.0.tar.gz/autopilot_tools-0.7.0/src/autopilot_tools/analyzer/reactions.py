from enum import Enum

class Reactions(Enum):
    IN_PROCESS = "🤔"
    DONE = "👍"
    OK = "👌"
    IDN = "🤡"
    ERROR = "👎"
