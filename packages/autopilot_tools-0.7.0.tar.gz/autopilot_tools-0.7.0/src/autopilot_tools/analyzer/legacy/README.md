# Usage example

## 1 Airspeed

Usage:

```python
from autopilot_tools.log_analyzer.airspeed import airspeed
airspeed(log_path="/home/nex/FlightLogs/2022.12.31/flight_log.ulg",
         output_path=output_build_path,
         output_report_path=output_report_path)
```

## 2 Altitude

Usage:

```python
from autopilot_tools.log_analyzer.altitude import altitude
altitude(log_path="/home/nex/FlightLogs/2022.12.31/flight_log.ulg",,
            output_path=output_build_path,
            output_report_path=output_report_path)
```

## 3 Internal combustion engine**

Usage:

```python
from autopilot_tools.log_analyzer.ice import ice
altitude(log_path="/home/nex/FlightLogs/2022.12.31/flight_log.ulg",,
         output_path=output_build_path,
         output_report_path=output_report_path)
```


## 4. Collecting and visualizing overall flight statistic

Usage:

```python
from autopilot_tools.log_analyzer.flight_distance import flight_distance
input_logs_path = "/home/nex/FlightLogs"
input_dates = (
    "2020.01.01",   # first flight date
    "2021.01.01",   # optional key date
    "2022.12.31")   # last flight date
output_build_path = "/home/nex/FlightLogsBuild"
output_report_path = "report"
flight_distance(input_logs_path, input_dates, output_build_path, output_report_path)
```
