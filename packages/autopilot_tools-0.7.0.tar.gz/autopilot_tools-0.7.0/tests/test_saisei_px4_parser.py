#!/usr/bin/env python3
import os
import pytest

from autopilot_tools.saisei.log_parser_px4 import parse_px4_log
from autopilot_tools.saisei.log_sim_data import FlightLogData

fname = "log.ulg"
@pytest.mark.skipif(not os.path.isfile(fname), reason=f"Test needs {fname}")
def test_saisei_px4_parser():
    flight_log_data = parse_px4_log(fname)
    assert isinstance(flight_log_data, FlightLogData)

    # Metadata
    assert flight_log_data.meta.autopilot == "px4"

    # Attitude
    assert len(flight_log_data.attitude.t) == 2769

    # GPS
    assert len(flight_log_data.gps.t) == 1080

    # Actuators
    assert len(flight_log_data.actuators.t) == 1385
    assert len(flight_log_data.actuators.axes[0]) == 8
