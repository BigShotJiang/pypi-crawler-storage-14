
#!/usr/bin/env python3
"""
AILOOS CLI - Interfaz Interactiva Completa
CLI completa con menús interactivos para gestión completa del sistema AILOOS.
Incluye auto-detección de hardware, gestión federada, marketplace, entrenamiento local y más.
"""

import asyncio
import json
import os
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import threading
import signal

# Dependencias de CLI
try:
    import questionary
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    from rich.live import Live
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskID
    from rich.columns import Columns
    from rich.align import Align
    import click
    import pyfiglet
    from colorama import init, Fore, Back, Style
except ImportError as e:
    print(f"❌ Error: Dependencias faltantes. Instala con: pip install questionary rich click pyfiglet colorama")
    print(f"Error específico: {e}")
    sys.exit(1)

# Inicializar colorama
init(autoreset=True)

# Añadir src al path para importar módulos de AILOOS
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Importaciones de AILOOS SDK
from ailoos.sdk.hardware_monitor import HardwareMonitor, get_system_info
from ailoos.sdk.federated_client import FederatedClient, create_federated_client
from ailoos.sdk.model_manager import ModelManager, create_model_manager
from ailoos.sdk.marketplace_client import MarketplaceClient, create_marketplace_client
from ailoos.sdk.auth import NodeAuthenticator
from ailoos.training.local_trainer import LocalTrainer, LocalTrainerConfig, create_local_trainer
from ailoos.core.logging import get_logger

# Configuración de logging
logger = get_logger(__name__)

# Console para rich
console = Console()


class AILOOS_CLI:
    """
    CLI Interactiva Completa para AILOOS
    Gestiona todos los aspectos del sistema con menús intuitivos
    """

    def __init__(self):
        self.node_id = f"cli_node_{int(time.time())}"
        self.coordinator_url = "http://localhost:8001"
        self.api_server_url = "http://localhost:8000"

        # Componentes del sistema
        self.hardware_monitor = None
        self.federated_client = None
        self.model_manager = None
        self.marketplace_client = None
        self.local_trainer = None

        # Estado de la CLI
        self.expert_mode = False
        self.monitoring_active = False
        self.monitoring_thread = None

        # Configuración
        self.config = self._load_config()

        # Banner ASCII
        self.banner = pyfiglet.figlet_format("AILOOS CLI", font="slant")

    def _load_config(self) -> Dict[str, Any]:
        """Cargar configuración desde archivos de entorno."""
        config = {
            "coordinator_url": os.getenv("COORDINATOR_URL", "http://localhost:8001"),
            "api_server_url": os.getenv("API_HOST", f"http://localhost:{os.getenv('API_PORT', '8000')}"),
            "models_dir": "./models",
            "training_output_dir": "./training_output",
            "log_level": os.getenv("LOG_LEVEL", "INFO"),
            "auto_detect_hardware": True,
            "enable_monitoring": True,
            "expert_mode": False
        }
        return config

    async def initialize(self) -> bool:
        """
        Inicializar todos los componentes del sistema.

        Returns:
            True si la inicialización fue exitosa
        """
        try:
            console.print("\n[bold blue]🚀 Inicializando AILOOS CLI...[/bold blue]")

            # 1. Auto-detección de hardware
            if self.config["auto_detect_hardware"]:
                console.print("🔍 Detectando hardware del sistema...")
                self.hardware_monitor = HardwareMonitor(self.node_id)
                success = await self.hardware_monitor.initialize()
                if success:
                    console.print("✅ Hardware detectado exitosamente")
                else:
                    console.print("⚠️ Error en detección de hardware, continuando...")

            # 2. Inicializar autenticador
            authenticator = NodeAuthenticator(self.node_id, self.coordinator_url)

            # 3. Inicializar cliente federado
            console.print("🔗 Inicializando cliente federado...")
            self.federated_client = FederatedClient(
                node_id=self.node_id,
                coordinator_url=self.coordinator_url,
                authenticator=authenticator
            )
            success = await self.federated_client.initialize()
            if success:
                console.print("✅ Cliente federado inicializado")
            else:
                console.print("⚠️ Error inicializando cliente federado")

            # 4. Inicializar gestor de modelos
            console.print("📦 Inicializando gestor de modelos...")
            self.model_manager = ModelManager(
                node_id=self.node_id,
                models_dir=self.config["models_dir"],
                coordinator_url=self.coordinator_url,
                authenticator=authenticator
            )
            success = await self.model_manager.initialize()
            if success:
                console.print("✅ Gestor de modelos inicializado")
            else:
                console.print("⚠️ Error inicializando gestor de modelos")

            # 5. Inicializar cliente de marketplace
            console.print("🛒 Inicializando cliente de marketplace...")
            self.marketplace_client = MarketplaceClient(
                node_id=self.node_id,
                coordinator_url=self.coordinator_url,
                authenticator=authenticator
            )
            success = await self.marketplace_client.initialize()
            if success:
                console.print("✅ Cliente de marketplace inicializado")
            else:
                console.print("⚠️ Error inicializando cliente de marketplace")

            # 6. Inicializar entrenador local
            console.print("🎯 Inicializando entrenador local...")
            trainer_config = LocalTrainerConfig(
                output_dir=self.config["training_output_dir"]
            )
            self.local_trainer = LocalTrainer(trainer_config)
            success = await self.local_trainer.initialize()
            if success:
                console.print("✅ Entrenador local inicializado")
            else:
                console.print("⚠️ Error inicializando entrenador local")

            # 7. Iniciar monitoreo si está habilitado
            if self.config["enable_monitoring"] and self.hardware_monitor:
                self.start_monitoring()

            console.print("[bold green]✅ AILOOS CLI inicializado exitosamente![/bold green]")
            return True

        except Exception as e:
            console.print(f"[bold red]❌ Error inicializando AILOOS CLI: {e}[/bold red]")
            return False

    def start_monitoring(self):
        """Iniciar monitoreo continuo en background."""
        if self.monitoring_active:
            return

        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        console.print("📊 Monitoreo continuo iniciado")

    def stop_monitoring(self):
        """Detener monitoreo continuo."""
        self.monitoring_active = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)
        console.print("⏹️ Monitoreo detenido")

    def _monitoring_loop(self):
        """Loop de monitoreo continuo."""
        while self.monitoring_active:
            try:
                # Monitoreo cada 30 segundos
                time.sleep(30)
                # Aquí podríamos agregar alertas automáticas
            except Exception as e:
                logger.warning(f"Error en monitoring loop: {e}")

    def show_banner(self):
        """Mostrar banner de bienvenida."""
        console.print(Panel.fit(
            f"[bold cyan]{self.banner}[/bold cyan]\n"
            f"[dim]Interfaz Interactiva Completa para AILOOS[/dim]\n"
            f"[dim]Versión 1.0.0 | Nodo: {self.node_id}[/dim]",
            title="🚀 AILOOS CLI",
            border_style="blue"
        ))

    def show_main_menu(self):
        """Mostrar menú principal."""
        while True:
            console.clear()
            self.show_banner()

            # Estado del sistema
            self._show_system_status()

            # Menú principal
            choices = [
                {"name": "🔍 Sistema & Hardware", "value": "system"},
                {"name": "🔗 Aprendizaje Federado", "value": "federated"},
                {"name": "📦 Gestión de Modelos", "value": "models"},
                {"name": "🛒 Marketplace & Wallet", "value": "marketplace"},
                {"name": "🎯 Entrenamiento Local", "value": "training"},
                {"name": "📊 Dashboard & Monitoreo", "value": "dashboard"},
                {"name": "⚙️ Configuración", "value": "config"},
                {"name": "🔧 Debugging & Logs", "value": "debug"},
                {"name": "❌ Salir", "value": "exit"}
            ]

            # Agregar modo experto si está habilitado
            if self.expert_mode:
                choices.insert(-1, {"name": "🧠 Modo Experto", "value": "expert"})

            choice = questionary.select(
                "Selecciona una opción:",
                choices=choices,
                style=self._get_questionary_style()
            ).ask()

            if choice == "exit":
                self._handle_exit()
                break
            elif choice:
                self._handle_menu_choice(choice)

    def _show_system_status(self):
        """Mostrar estado actual del sistema."""
        status_table = Table(title="📊 Estado del Sistema")
        status_table.add_column("Componente", style="cyan")
        status_table.add_column("Estado", style="green")
        status_table.add_column("Detalles", style="yellow")

        # Hardware
        hw_status = "✅ Activo" if self.hardware_monitor else "❌ No disponible"
        hw_details = ""
        if self.hardware_monitor:
            hw_info = self.hardware_monitor.get_hardware_info_sync()
            hw_details = f"CPU: {hw_info.get('cpu_count', '?')} cores, RAM: {hw_info.get('memory_total_gb', '?')}GB"

        status_table.add_row("Hardware Monitor", hw_status, hw_details)

        # Cliente Federado
        fed_status = "✅ Conectado" if self.federated_client and self.federated_client._running else "❌ Desconectado"
        fed_details = f"Sesiones activas: {len(self.federated_client.active_sessions) if self.federated_client else 0}"
        status_table.add_row("Cliente Federado", fed_status, fed_details)

        # Marketplace
        mp_status = "✅ Inicializado" if self.marketplace_client else "❌ No disponible"
        mp_details = ""
        if self.marketplace_client and self.marketplace_client.wallet:
            balance = self.marketplace_client.wallet.balance
            mp_details = f"Balance: {balance:.2f} DRACMA"
        status_table.add_row("Marketplace", mp_status, mp_details)

        # Entrenador Local
        train_status = "✅ Listo" if self.local_trainer and self.local_trainer.is_initialized else "❌ No inicializado"
        train_details = f"Modelo: {self.local_trainer.config.model_name_or_path if self.local_trainer else 'N/A'}"
        status_table.add_row("Entrenamiento Local", train_status, train_details)

        console.print(status_table)
        console.print()

    def _handle_menu_choice(self, choice: str):
        """Manejar selección del menú principal."""
        handlers = {
            "system": self._show_system_menu,
            "federated": self._show_federated_menu,
            "models": self._show_models_menu,
            "marketplace": self._show_marketplace_menu,
            "training": self._show_training_menu,
            "dashboard": self._show_dashboard_menu,
            "config": self._show_config_menu,
            "debug": self._show_debug_menu,
            "expert": self._show_expert_menu
        }

        handler = handlers.get(choice)
        if handler:
            try:
                asyncio.run(handler())
            except KeyboardInterrupt:
                console.print("\n[bold yellow]⚠️ Operación cancelada por el usuario[/bold yellow]")
            except Exception as e:
                console.print(f"[bold red]❌ Error: {e}[/bold red]")
                logger.error(f"Error in menu handler {choice}: {e}")

        # Pausar para que el usuario vea el resultado
        input("\nPresiona Enter para continuar...")

    async def _show_system_menu(self):
        """Mostrar menú de sistema y hardware."""
        console.clear()
        console.print(Panel.fit("🔍 Sistema & Hardware", border_style="blue"))

        if not self.hardware_monitor:
            console.print("[bold red]❌ Hardware monitor no disponible[/bold red]")
            return

        # Información del hardware
        hw_info = self.hardware_monitor.get_hardware_info_sync()
        metrics = self.hardware_monitor.get_current_metrics_sync()

        hw_table = Table(title="💻 Información del Hardware")
        hw_table.add_column("Componente", style="cyan")
        hw_table.add_column("Valor", style="green")

        hw_table.add_row("CPU Cores", str(hw_info.get("cpu_count", "N/A")))
        hw_table.add_row("CPU Lógicos", str(hw_info.get("cpu_count_logical", "N/A")))
        hw_table.add_row("Memoria Total", f"{hw_info.get('memory_total_gb', 0):.1f} GB")
        hw_table.add_row("GPU", hw_info.get("gpu_info", "N/A"))
        hw_table.add_row("Sistema", hw_info.get("platform", "N/A"))
        hw_table.add_row("Arquitectura", hw_info.get("architecture", "N/A"))
        hw_table.add_row("Python", hw_info.get("python_version", "N/A"))

        console.print(hw_table)
        console.print()

        # Métricas actuales
        metrics_table = Table(title="📊 Métricas Actuales")
        metrics_table.add_column("Métrica", style="cyan")
        metrics_table.add_column("Valor", style="green")

        metrics_table.add_row("CPU Usado", f"{metrics.get('cpu_percent', 0):.1f}%")
        metrics_table.add_row("Memoria Usada", f"{metrics.get('memory_percent', 0):.1f}%")
        metrics_table.add_row("Memoria Usada (GB)", f"{metrics.get('memory_used_gb', 0):.2f} GB")
        metrics_table.add_row("Disco Usado", f"{metrics.get('disk_percent', 0):.1f}%")
        metrics_table.add_row("Red Enviado", f"{metrics.get('network_sent_mb', 0):.2f} MB")
        metrics_table.add_row("Red Recibido", f"{metrics.get('network_recv_mb', 0):.2f} MB")
        metrics_table.add_row("Uptime", f"{metrics.get('uptime_seconds', 0)/3600:.1f} horas")

        console.print(metrics_table)

        # Opciones del menú
        choices = [
            {"name": "📈 Generar Reporte de Rendimiento", "value": "report"},
            {"name": "🔄 Actualizar Métricas", "value": "refresh"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "report":
            await self._generate_performance_report()
        elif choice == "refresh":
            # Las métricas ya se actualizaron arriba
            pass

    async def _generate_performance_report(self):
        """Generar reporte completo de rendimiento."""
        console.print("[bold blue]📊 Generando reporte de rendimiento...[/bold blue]")

        with console.status("[bold green]Procesando datos...") as status:
            report = await self.hardware_monitor.generate_report(period_minutes=60)

        if "error" in report:
            console.print(f"[bold red]❌ Error generando reporte: {report['error']}[/bold red]")
            return

        # Mostrar reporte
        console.print(Panel.fit("📊 Reporte de Rendimiento (última hora)", border_style="green"))

        report_table = Table()
        report_table.add_column("Métrica", style="cyan")
        report_table.add_column("Valor", style="green")

        report_table.add_row("Período", f"{report.get('period_minutes', 0)} minutos")
        report_table.add_row("Mediciones", str(report.get("measurements_count", 0)))
        report_table.add_row("CPU Promedio", f"{report['averages'].get('cpu_percent', 0):.1f}%")
        report_table.add_row("Memoria Promedio", f"{report['averages'].get('memory_percent', 0):.1f}%")
        report_table.add_row("Disco Promedio", f"{report['averages'].get('disk_percent', 0):.1f}%")
        report_table.add_row("CPU Pico", f"{report['peaks'].get('cpu_percent', 0):.1f}%")
        report_table.add_row("Memoria Pico", f"{report['peaks'].get('memory_percent', 0):.1f}%")
        report_table.add_row("Disco Pico", f"{report['peaks'].get('disk_percent', 0):.1f}%")

        console.print(report_table)

        # Recomendaciones
        recommendations = report.get("recommendations", [])
        if recommendations:
            console.print("\n[bold yellow]💡 Recomendaciones:[/bold yellow]")
            for rec in recommendations:
                console.print(f"  • {rec}")

    async def _show_federated_menu(self):
        """Mostrar menú de aprendizaje federado."""
        console.clear()
        console.print(Panel.fit("🔗 Aprendizaje Federado", border_style="blue"))

        if not self.federated_client:
            console.print("[bold red]❌ Cliente federado no disponible[/bold red]")
            return

        # Estado de sesiones
        active_sessions = self.federated_client.get_active_sessions()

        if active_sessions:
            console.print(f"[bold green]✅ Sesiones activas: {len(active_sessions)}[/bold green]")

            sessions_table = Table(title="🎯 Sesiones Federadas Activas")
            sessions_table.add_column("ID Sesión", style="cyan")
            sessions_table.add_column("Estado", style="green")
            sessions_table.add_column("Ronda", style="yellow")
            sessions_table.add_column("Participantes", style="magenta")

            for session_id in active_sessions:
                session_info = self.federated_client.get_session_info(session_id)
                if session_info:
                    sessions_table.add_row(
                        session_id[:16] + "...",
                        session_info.get("status", "unknown"),
                        str(session_info.get("round_num", 0)),
                        str(len(session_info.get("participants", [])))
                    )

            console.print(sessions_table)
        else:
            console.print("[bold yellow]⚠️ No hay sesiones federadas activas[/bold yellow]")

        console.print()

        # Menú de opciones
        choices = [
            {"name": "🔗 Unirse a Sesión Federada", "value": "join"},
            {"name": "🚪 Abandonar Sesión", "value": "leave"},
            {"name": "📤 Enviar Actualización de Modelo", "value": "submit"},
            {"name": "📥 Descargar Modelo Global", "value": "download"},
            {"name": "📊 Ver Información de Sesión", "value": "info"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "join":
            await self._join_federated_session()
        elif choice == "leave":
            await self._leave_federated_session()
        elif choice == "submit":
            await self._submit_model_update()
        elif choice == "download":
            await self._download_global_model()
        elif choice == "info":
            await self._show_session_info()

    async def _join_federated_session(self):
        """Unirse a una sesión federada."""
        session_id = questionary.text("ID de la sesión federada:").ask()

        if not session_id:
            return

        console.print(f"[bold blue]🔗 Uniéndose a sesión {session_id}...[/bold blue]")

        with console.status("[bold green]Conectando...") as status:
            success = await self.federated_client.join_session(session_id)

        if success:
            console.print(f"[bold green]✅ Unido exitosamente a sesión {session_id}[/bold green]")
        else:
            console.print(f"[bold red]❌ Error uniéndose a sesión {session_id}[/bold red]")

    async def _leave_federated_session(self):
        """Abandonar una sesión federada."""
        active_sessions = self.federated_client.get_active_sessions()

        if not active_sessions:
            console.print("[bold yellow]⚠️ No hay sesiones activas para abandonar[/bold yellow]")
            return

        choices = [{"name": session_id, "value": session_id} for session_id in active_sessions]
        session_id = questionary.select("Selecciona sesión a abandonar:", choices=choices).ask()

        if not session_id:
            return

        console.print(f"[bold blue]🚪 Abandonando sesión {session_id}...[/bold blue]")

        with console.status("[bold green]Desconectando...") as status:
            success = await self.federated_client.leave_session(session_id)

        if success:
            console.print(f"[bold green]✅ Abandonada sesión {session_id}[/bold green]")
        else:
            console.print(f"[bold red]❌ Error abandonando sesión {session_id}[/bold red]")

    async def _submit_model_update(self):
        """Enviar actualización de modelo."""
        active_sessions = self.federated_client.get_active_sessions()

        if not active_sessions:
            console.print("[bold yellow]⚠️ No hay sesiones activas[/bold yellow]")
            return

        choices = [{"name": session_id, "value": session_id} for session_id in active_sessions]
        session_id = questionary.select("Selecciona sesión:", choices=choices).ask()

        if not session_id:
            return

        # Aquí necesitaríamos cargar un modelo entrenado localmente
        # Por simplicidad, simulamos una actualización
        console.print(f"[bold blue]📤 Enviando actualización para sesión {session_id}...[/bold blue]")

        # Simular datos de modelo (en implementación real vendrían del local_trainer)
        model_weights = {"layer1": [[1, 2, 3], [4, 5, 6]]}  # Simulado
        metadata = {
            "num_samples": 1000,
            "accuracy": 0.85,
            "loss": 0.45
        }

        with console.status("[bold green]Enviando actualización...") as status:
            success = await self.federated_client.submit_update(session_id, model_weights, metadata)

        if success:
            console.print(f"[bold green]✅ Actualización enviada exitosamente[/bold green]")
        else:
            console.print(f"[bold red]❌ Error enviando actualización[/bold red]")

    async def _download_global_model(self):
        """Descargar modelo global."""
        active_sessions = self.federated_client.get_active_sessions()

        if not active_sessions:
            console.print("[bold yellow]⚠️ No hay sesiones activas[/bold yellow]")
            return

        choices = [{"name": session_id, "value": session_id} for session_id in active_sessions]
        session_id = questionary.select("Selecciona sesión:", choices=choices).ask()

        if not session_id:
            return

        save_path = questionary.text("Ruta donde guardar el modelo:", default="./global_model.json").ask()

        if not save_path:
            return

        console.print(f"[bold blue]📥 Descargando modelo global de sesión {session_id}...[/bold blue]")

        with console.status("[bold green]Descargando...") as status:
            success = await self.federated_client.download_global_model(session_id, save_path)

        if success:
            console.print(f"[bold green]✅ Modelo global guardado en {save_path}[/bold green]")
        else:
            console.print(f"[bold red]❌ Error descargando modelo global[/bold red]")

    async def _show_session_info(self):
        """Mostrar información detallada de sesión."""
        active_sessions = self.federated_client.get_active_sessions()

        if not active_sessions:
            console.print("[bold yellow]⚠️ No hay sesiones activas[/bold yellow]")
            return

        choices = [{"name": session_id, "value": session_id} for session_id in active_sessions]
        session_id = questionary.select("Selecciona sesión:", choices=choices).ask()

        if not session_id:
            return

        session_info = self.federated_client.get_session_info(session_id)

        if session_info:
            console.print(Panel.fit(f"📊 Información de Sesión: {session_id}", border_style="green"))

            info_table = Table()
            info_table.add_column("Campo", style="cyan")
            info_table.add_column("Valor", style="green")

            for key, value in session_info.items():
                if isinstance(value, list):
                    value = ", ".join(str(v) for v in value)
                elif isinstance(value, dict):
                    value = json.dumps(value, indent=2)[:100] + "..." if len(str(value)) > 100 else str(value)
                info_table.add_row(key, str(value))

            console.print(info_table)
        else:
            console.print(f"[bold red]❌ No se pudo obtener información de sesión {session_id}[/bold red]")

    async def _show_models_menu(self):
        """Mostrar menú de gestión de modelos."""
        console.clear()
        console.print(Panel.fit("📦 Gestión de Modelos", border_style="blue"))

        if not self.model_manager:
            console.print("[bold red]❌ Gestor de modelos no disponible[/bold red]")
            return

        # Estadísticas de modelos
        stats = self.model_manager.get_manager_stats()

        stats_table = Table(title="📊 Estadísticas de Modelos")
        stats_table.add_column("Métrica", style="cyan")
        stats_table.add_column("Valor", style="green")

        local_stats = stats.get("local_models", {})
        stats_table.add_row("Modelos Locales", str(local_stats.get("count", 0)))
        stats_table.add_row("Tamaño Total", f"{local_stats.get('total_size_mb', 0):.1f} MB")
        stats_table.add_row("Tamaño Comprimido", f"{local_stats.get('compressed_size_mb', 0):.1f} MB")
        stats_table.add_row("Ratio Compresión", f"{local_stats.get('compression_ratio', 1):.2f}")

        console.print(stats_table)
        console.print()

        # Menú de opciones
        choices = [
            {"name": "📤 Subir Modelo", "value": "upload"},
            {"name": "📥 Descargar Modelo", "value": "download"},
            {"name": "🔍 Buscar Modelos", "value": "search"},
            {"name": "📋 Listar Modelos Locales", "value": "list"},
            {"name": "🗑️ Eliminar Modelo", "value": "delete"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "upload":
            await self._upload_model()
        elif choice == "download":
            await self._download_model()
        elif choice == "search":
            await self._search_models()
        elif choice == "list":
            await self._list_local_models()
        elif choice == "delete":
            await self._delete_model()

    async def _upload_model(self):
        """Subir un modelo."""
        model_path = questionary.text("Ruta del archivo del modelo:").ask()

        if not model_path or not Path(model_path).exists():
            console.print("[bold red]❌ Ruta de modelo inválida[/bold red]")
            return

        model_name = questionary.text("Nombre del modelo:", default=Path(model_path).stem).ask()
        model_type = questionary.select("Tipo de modelo:", choices=[
            {"name": "PyTorch (.pt/.pth)", "value": "pytorch"},
            {"name": "TensorFlow (.h5)", "value": "tensorflow"},
            {"name": "ONNX (.onnx)", "value": "onnx"},
            {"name": "Otro", "value": "other"}
        ]).ask()

        metadata = {
            "model_type": model_type,
            "filename": Path(model_path).name,
            "description": questionary.text("Descripción (opcional):").ask() or "",
            "tags": questionary.text("Tags (separados por coma):").ask().split(",") if questionary.confirm("¿Agregar tags?").ask() else []
        }

        compress = questionary.confirm("¿Comprimir modelo antes de subir?", default=True).ask()

        console.print(f"[bold blue]📤 Subiendo modelo {model_name}...[/bold blue]")

        with console.status("[bold green]Subiendo...") as status:
            model_id = await self.model_manager.upload_model(model_path, metadata, compress)

        if model_id:
            console.print(f"[bold green]✅ Modelo subido exitosamente: {model_id}[/bold green]")
        else:
            console.print("[bold red]❌ Error subiendo modelo[/bold red]")

    async def _download_model(self):
        """Descargar un modelo."""
        model_id = questionary.text("ID del modelo:").ask()

        if not model_id:
            return

        save_path = questionary.text("Ruta donde guardar:", default=f"./models/{model_id}.pt").ask()

        verify = questionary.confirm("¿Verificar integridad después de descargar?", default=True).ask()

        console.print(f"[bold blue]📥 Descargando modelo {model_id}...[/bold blue]")

        with console.status("[bold green]Descargando...") as status:
            success = await self.model_manager.download_model(model_id, save_path, verify)

        if success:
            console.print(f"[bold green]✅ Modelo descargado en {save_path}[/bold green]")
        else:
            console.print("[bold red]❌ Error descargando modelo[/bold red]")

    async def _search_models(self):
        """Buscar modelos."""
        query = questionary.text("Término de búsqueda (opcional):").ask() or ""

        filters = {}
        if questionary.confirm("¿Agregar filtros?").ask():
            framework = questionary.select("Framework:", choices=[
                {"name": "PyTorch", "value": "pytorch"},
                {"name": "TensorFlow", "value": "tensorflow"},
                {"name": "ONNX", "value": "onnx"},
                {"name": "Todos", "value": None}
            ]).ask()
            if framework:
                filters["framework"] = framework

        console.print(f"[bold blue]🔍 Buscando modelos...[/bold blue]")

        with console.status("[bold green]Buscando...") as status:
            models = await self.model_manager.list_models(filters, include_local=True)

        if models:
            models_table = Table(title=f"🔍 Resultados de Búsqueda ({len(models)} modelos)")
            models_table.add_column("ID", style="cyan")
            models_table.add_column("Nombre", style="green")
            models_table.add_column("Tipo", style="yellow")
            models_table.add_column("Framework", style="magenta")
            models_table.add_column("Tamaño", style="blue")

            for model in models[:20]:  # Mostrar máximo 20
                model_id = model.get("id") or model.get("model_id", "N/A")
                models_table.add_row(
                    model_id[:16] + "..." if len(model_id) > 16 else model_id,
                    model.get("name", "N/A"),
                    model.get("model_type", "N/A"),
                    model.get("framework", "N/A"),
                    f"{model.get('file_size', 0) / (1024*1024):.1f} MB" if model.get('file_size') else "N/A"
                )

            console.print(models_table)
        else:
            console.print("[bold yellow]⚠️ No se encontraron modelos[/bold yellow]")

    async def _list_local_models(self):
        """Listar modelos locales."""
        local_models = self.model_manager.get_local_models()

        if local_models:
            models_table = Table(title=f"📂 Modelos Locales ({len(local_models)})")
            models_table.add_column("ID", style="cyan")
            models_table.add_column("Ruta Local", style="green")
            models_table.add_column("Tamaño", style="yellow")
            models_table.add_column("Tipo", style="magenta")

            for model_id, info in local_models.items():
                path = info.get("local_path", "N/A")
                size = Path(path).stat().st_size if path != "N/A" and Path(path).exists() else 0
                models_table.add_row(
                    model_id[:16] + "..." if len(model_id) > 16 else model_id,
                    path,
                    f"{size / (1024*1024):.1f} MB",
                    info.get("format", "N/A")
                )

            console.print(models_table)
        else:
            console.print("[bold yellow]⚠️ No hay modelos locales[/bold yellow]")

    async def _delete_model(self):
        """Eliminar un modelo."""
        local_models = self.model_manager.get_local_models()

        if not local_models:
            console.print("[bold yellow]⚠️ No hay modelos locales para eliminar[/bold yellow]")
            return

        choices = [{"name": f"{model_id} - {info.get('local_path', 'N/A')}", "value": model_id}
                  for model_id, info in local_models.items()]
        model_id = questionary.select("Selecciona modelo a eliminar:", choices=choices).ask()

        if not model_id:
            return

        if questionary.confirm(f"¿Estás seguro de eliminar el modelo {model_id}?").ask():
            success = await self.model_manager.delete_model(model_id)

            if success:
                console.print(f"[bold green]✅ Modelo {model_id} eliminado[/bold green]")
            else:
                console.print(f"[bold red]❌ Error eliminando modelo {model_id}[/bold red]")

    async def _show_marketplace_menu(self):
        """Mostrar menú de marketplace."""
        console.clear()
        console.print(Panel.fit("🛒 Marketplace & Wallet", border_style="blue"))

        if not self.marketplace_client:
            console.print("[bold red]❌ Cliente de marketplace no disponible[/bold red]")
            return

        # Información de wallet
        wallet_info = self.marketplace_client.get_wallet_info()

        if wallet_info:
            wallet_table = Table(title="💰 Información de Wallet")
            wallet_table.add_column("Campo", style="cyan")
            wallet_table.add_column("Valor", style="green")

            wallet_table.add_row("Dirección", wallet_info.get("address", "N/A")[:20] + "...")
            wallet_table.add_row("Balance", f"{wallet_info.get('balance', 0):.2f} DRACMA")
            wallet_table.add_row("Staked", f"{wallet_info.get('staked_amount', 0):.2f} DRACMA")
            wallet_table.add_row("Rewards", f"{wallet_info.get('rewards_earned', 0):.2f} DRACMA")
            wallet_table.add_row("Transacciones", str(wallet_info.get('transaction_count', 0)))

            console.print(wallet_table)
        else:
            console.print("[bold yellow]⚠️ Wallet no inicializada[/bold yellow]")

        console.print()

        # Estadísticas del marketplace
        market_stats = self.marketplace_client.get_market_stats()

        if market_stats and "error" not in market_stats:
            stats_table = Table(title="📊 Estadísticas del Marketplace")
            stats_table.add_column("Métrica", style="cyan")
            stats_table.add_column("Valor", style="green")

            stats_table.add_row("Total Datasets", str(market_stats.get("total_datasets", 0)))
            stats_table.add_row("Total Transacciones", str(market_stats.get("total_transactions", 0)))
            stats_table.add_row("Volumen Total", f"{market_stats.get('total_volume', 0):.2f} DRACMA")
            stats_table.add_row("Precio Promedio", f"{market_stats.get('avg_price', 0):.2f} DRACMA")

            console.print(stats_table)

        console.print()

        # Menú de opciones
        choices = [
            {"name": "📦 Crear Listing de Datos", "value": "create_listing"},
            {"name": "🔍 Buscar Datasets", "value": "search"},
            {"name": "🛒 Comprar Datos", "value": "purchase"},
            {"name": "💸 Transferir DRACMA", "value": "transfer"},
            {"name": "🔒 Stakear Tokens", "value": "stake"},
            {"name": "🏦 Ver Historial de Transacciones", "value": "history"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "create_listing":
            await self._create_data_listing()
        elif choice == "search":
            await self._search_datasets()
        elif choice == "purchase":
            await self._purchase_dataset()
        elif choice == "transfer":
            await self._transfer_tokens()
        elif choice == "stake":
            await self._stake_tokens()
        elif choice == "history":
            await self._show_transaction_history()

    async def _create_data_listing(self):
        """Crear un listing de datos."""
        title = questionary.text("Título del dataset:").ask()
        if not title:
            return

        description = questionary.text("Descripción:").ask() or ""
        data_path = questionary.text("Ruta del archivo de datos:").ask()

        if not data_path or not Path(data_path).exists():
            console.print("[bold red]❌ Ruta de datos inválida[/bold red]")
            return

        price = questionary.text("Precio en DRACMA:", default="10.0").ask()
        # Estado del entrenador
        training_stats = self.local_trainer.get_training_stats()

        if training_stats.get("is_initialized"):
            console.print("[bold green]✅ Entrenador listo para usar[/bold green]")

            stats_table = Table(title="🎯 Estado del Entrenamiento")
            stats_table.add_column("Métrica", style="cyan")
            stats_table.add_column("Valor", style="green")

            stats_table.add_row("Modelo Base", training_stats.get("config", {}).get("model_name_or_path", "N/A"))
            stats_table.add_row("Batch Size", str(training_stats.get("config", {}).get("batch_size", 0)))
            stats_table.add_row("Paso Global", str(training_stats.get("global_step", 0)))
            stats_table.add_row("Epoch Actual", str(training_stats.get("current_epoch", 0)))
            stats_table.add_row("GPU Disponible", "✅ Sí" if training_stats.get("gpu_available") else "❌ No")
            stats_table.add_row("GPUs", str(training_stats.get("gpu_count", 0)))

            console.print(stats_table)
        else:
            console.print("[bold yellow]⚠️ Entrenador no inicializado[/bold yellow]")

        console.print()

        # Menú de opciones
        choices = [
            {"name": "🚀 Iniciar Entrenamiento", "value": "train"},
            {"name": "📊 Ver Métricas de Entrenamiento", "value": "metrics"},
            {"name": "💾 Guardar Adaptador LoRA", "value": "save"},
            {"name": "⚙️ Configurar Entrenamiento", "value": "config"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "train":
            await self._start_local_training()
        elif choice == "metrics":
            await self._show_training_metrics()
        elif choice == "save":
            await self._save_lora_adapter()
        elif choice == "config":
            await self._configure_training()

    async def _start_local_training(self):
        """Iniciar entrenamiento local."""
        if not questionary.confirm("¿Iniciar entrenamiento local? Esto puede tomar tiempo.").ask():
            return

        console.print("[bold blue]🚀 Iniciando entrenamiento local...[/bold blue]")

        # Barra de progreso para el entrenamiento
        with Progress() as progress:
            task = progress.add_task("[green]Entrenando...", total=None)

            # Ejecutar entrenamiento en una tarea separada
            import threading
            training_result = None
            training_error = None

            def training_thread():
                nonlocal training_result, training_error
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    training_result = loop.run_until_complete(self.local_trainer.train())
                except Exception as e:
                    training_error = e

            thread = threading.Thread(target=training_thread, daemon=True)
            thread.start()

            # Mostrar progreso
            while thread.is_alive():
                progress.update(task, advance=1)
                await asyncio.sleep(1)

            thread.join()

            if training_error:
                console.print(f"[bold red]❌ Error en entrenamiento: {training_error}[/bold red]")
                return

            progress.update(task, completed=True)

        # Mostrar resultados
        if training_result and training_result.get("training_completed"):
            console.print("[bold green]✅ Entrenamiento completado exitosamente![/bold green]")

            results_table = Table(title="📊 Resultados del Entrenamiento")
            results_table.add_column("Métrica", style="cyan")
            results_table.add_column("Valor", style="green")

            results_table.add_row("Epochs Completados", str(training_result.get("total_epochs", 0)))
            results_table.add_row("Pasos Totales", str(training_result.get("total_steps", 0)))
            results_table.add_row("Tiempo Total", f"{training_result.get('training_time', 0):.2f}s")

            final_metrics = training_result.get("final_metrics", {})
            if final_metrics:
                results_table.add_row("Loss Final", f"{final_metrics.get('loss', 0):.4f}")
                results_table.add_row("Learning Rate Final", f"{final_metrics.get('learning_rate', 0):.6f}")

            console.print(results_table)
        else:
            console.print("[bold red]❌ Entrenamiento fallido[/bold red]")

    async def _show_training_metrics(self):
        """Mostrar métricas de entrenamiento."""
        training_stats = self.local_trainer.get_training_stats()
        metrics_history = training_stats.get("metrics_history", [])

        if not metrics_history:
            console.print("[bold yellow]⚠️ No hay métricas de entrenamiento disponibles[/bold yellow]")
            return

        # Mostrar últimas métricas
        recent_metrics = metrics_history[-10:]  # Últimas 10

        metrics_table = Table(title=f"📈 Últimas Métricas de Entrenamiento ({len(recent_metrics)})")
        metrics_table.add_column("Paso", style="cyan")
        metrics_table.add_column("Loss", style="red")
        metrics_table.add_column("LR", style="green")
        metrics_table.add_column("GPU Mem", style="yellow")
        metrics_table.add_column("Throughput", style="blue")

        for metric in recent_metrics:
            metrics_table.add_row(
                str(metric.get("step", 0)),
                f"{metric.get('loss', 0):.4f}",
                f"{metric.get('learning_rate', 0):.6f}",
                f"{metric.get('gpu_memory_used', 0):.1f}MB",
                f"{metric.get('throughput', 0):.1f} samples/s"
            )

        console.print(metrics_table)

    async def _save_lora_adapter(self):
        """Guardar adaptador LoRA."""
        output_path = questionary.text("Ruta donde guardar el adaptador:", default="./lora_adapter").ask()

        if not output_path:
            return

        console.print(f"[bold blue]💾 Guardando adaptador LoRA en {output_path}...[/bold blue]")

        with console.status("[bold green]Guardando...") as status:
            await self.local_trainer.save_lora_adapter(output_path)

        console.print(f"[bold green]✅ Adaptador LoRA guardado en {output_path}[/bold green]")

    async def _configure_training(self):
        """Configurar parámetros de entrenamiento."""
        console.print("[bold blue]⚙️ Configuración de Entrenamiento[/bold blue]")
        console.print("Esta función permite reconfigurar el entrenador local.")
        console.print("Nota: Requiere reinicialización del entrenador.")

        # Aquí se podrían agregar opciones para cambiar configuración
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _show_dashboard_menu(self):
        """Mostrar dashboard de monitoreo."""
        console.clear()
        console.print(Panel.fit("📊 Dashboard & Monitoreo", border_style="blue"))

        # Información en tiempo real
        if self.hardware_monitor:
            hw_info = self.hardware_monitor.get_hardware_info_sync()
            metrics = self.hardware_monitor.get_current_metrics_sync()

            # Crear dashboard visual
            dashboard = Table(title="🔍 Dashboard del Sistema")
            dashboard.add_column("Sistema", style="cyan")
            dashboard.add_column("Estado", style="green")
            dashboard.add_column("Detalles", style="yellow")

            # CPU
            cpu_percent = metrics.get('cpu_percent', 0)
            cpu_status = "🟢 Bueno" if cpu_percent < 70 else "🟡 Alto" if cpu_percent < 90 else "🔴 Crítico"
            dashboard.add_row("CPU", cpu_status, f"{cpu_percent:.1f}% usado")

            # Memoria
            mem_percent = metrics.get('memory_percent', 0)
            mem_status = "🟢 Bueno" if mem_percent < 70 else "🟡 Alto" if mem_percent < 90 else "🔴 Crítico"
            dashboard.add_row("Memoria", mem_status, f"{mem_percent:.1f}% usado ({metrics.get('memory_used_gb', 0):.1f}GB)")

            # Disco
            disk_percent = metrics.get('disk_percent', 0)
            disk_status = "🟢 Bueno" if disk_percent < 80 else "🟡 Alto" if disk_percent < 95 else "🔴 Crítico"
            dashboard.add_row("Disco", disk_status, f"{disk_percent:.1f}% usado")

            # Red
            dashboard.add_row("Red", "🟢 Activa",
                            f"↑{metrics.get('network_sent_mb', 0):.1f}MB ↓{metrics.get('network_recv_mb', 0):.1f}MB")

            console.print(dashboard)

            # Sesiones federadas activas
            if self.federated_client:
                active_sessions = len(self.federated_client.get_active_sessions())
                console.print(f"\n🔗 Sesiones Federadas Activas: [bold cyan]{active_sessions}[/bold cyan]")

            # Balance de wallet
            if self.marketplace_client and self.marketplace_client.wallet:
                balance = self.marketplace_client.wallet.balance
                console.print(f"💰 Balance DRACMA: [bold cyan]{balance:.2f}[/bold cyan]")

        console.print()

        # Opciones del dashboard
        choices = [
            {"name": "📈 Ver Reporte Detallado", "value": "report"},
            {"name": "🔍 Monitoreo en Tiempo Real", "value": "realtime"},
            {"name": "📋 Logs del Sistema", "value": "logs"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "report":
            await self._show_detailed_report()
        elif choice == "realtime":
            await self._show_realtime_monitoring()
        elif choice == "logs":
            await self._show_system_logs()

    async def _show_detailed_report(self):
        """Mostrar reporte detallado del sistema."""
        console.print("[bold blue]📊 Generando reporte detallado...[/bold blue]")

        with console.status("[bold green]Recopilando datos...") as status:
            # Reporte de hardware
            hw_report = await self.hardware_monitor.generate_report(period_minutes=60) if self.hardware_monitor else None

            # Estadísticas de modelos
            model_stats = self.model_manager.get_manager_stats() if self.model_manager else None

            # Estadísticas de marketplace
            market_stats = self.marketplace_client.get_market_stats() if self.marketplace_client else None

            # Estadísticas federadas
            fed_stats = self.federated_client.get_client_stats() if self.federated_client else None

        # Mostrar reporte completo
        console.print(Panel.fit("📊 Reporte Completo del Sistema", border_style="green"))

        if hw_report and "error" not in hw_report:
            console.print("[bold cyan]💻 Hardware (última hora):[/bold cyan]")
            hw_table = Table()
            hw_table.add_column("Métrica", style="cyan")
            hw_table.add_column("Promedio", style="green")
            hw_table.add_column("Pico", style="red")

            hw_table.add_row("CPU", f"{hw_report['averages']['cpu_percent']:.1f}%",
                           f"{hw_report['peaks']['cpu_percent']:.1f}%")
            hw_table.add_row("Memoria", f"{hw_report['averages']['memory_percent']:.1f}%",
                           f"{hw_report['peaks']['memory_percent']:.1f}%")
            hw_table.add_row("Disco", f"{hw_report['averages']['disk_percent']:.1f}%",
                           f"{hw_report['peaks']['disk_percent']:.1f}%")

            console.print(hw_table)
            console.print()

        if model_stats:
            console.print("[bold cyan]📦 Modelos:[/bold cyan]")
            local_stats = model_stats.get("local_models", {})
            console.print(f"  • Modelos locales: {local_stats.get('count', 0)}")
            console.print(f"  • Tamaño total: {local_stats.get('total_size_mb', 0):.1f} MB")
            console.print(f"  • Ratio compresión: {local_stats.get('compression_ratio', 1):.2f}")
            console.print()

        if market_stats and "error" not in market_stats:
            console.print("[bold cyan]🛒 Marketplace:[/bold cyan]")
            console.print(f"  • Total datasets: {market_stats.get('total_datasets', 0)}")
            console.print(f"  • Total transacciones: {market_stats.get('total_transactions', 0)}")
            console.print(f"  • Volumen total: {market_stats.get('total_volume', 0):.2f} DRACMA")
            console.print()

        if fed_stats:
            console.print("[bold cyan]🔗 Federated Learning:[/bold cyan]")
            console.print(f"  • Sesiones activas: {fed_stats.get('active_sessions', 0)}")
            console.print(f"  • Updates pendientes: {fed_stats.get('pending_updates', 0)}")
            console.print(f"  • Estado: {'Conectado' if fed_stats.get('is_running') else 'Desconectado'}")

    async def _show_realtime_monitoring(self):
        """Mostrar monitoreo en tiempo real."""
        console.print("[bold blue]🔍 Monitoreo en Tiempo Real[/bold blue]")
        console.print("Presiona Ctrl+C para salir")

        try:
            with Live(console=console, refresh_per_second=2) as live:
                while True:
                    if self.hardware_monitor:
                        metrics = self.hardware_monitor.get_current_metrics_sync()

                        monitor_table = Table(title="📊 Métricas en Tiempo Real")
                        monitor_table.add_column("Componente", style="cyan")
                        monitor_table.add_column("Valor", style="green")
                        monitor_table.add_column("Estado", style="yellow")

                        # CPU
                        cpu = metrics.get('cpu_percent', 0)
                        cpu_status = "🟢" if cpu < 70 else "🟡" if cpu < 90 else "🔴"
                        monitor_table.add_row("CPU", f"{cpu:.1f}%", cpu_status)

                        # Memoria
                        mem = metrics.get('memory_percent', 0)
                        mem_status = "🟢" if mem < 70 else "🟡" if mem < 90 else "🔴"
                        monitor_table.add_row("Memoria", f"{mem:.1f}% ({metrics.get('memory_used_gb', 0):.1f}GB)", mem_status)

                        # Disco
                        disk = metrics.get('disk_percent', 0)
                        disk_status = "🟢" if disk < 80 else "🟡" if disk < 95 else "🔴"
                        monitor_table.add_row("Disco", f"{disk:.1f}%", disk_status)

                        # Red
                        monitor_table.add_row("Red",
                                            f"↑{metrics.get('network_sent_mb', 0):.1f}MB ↓{metrics.get('network_recv_mb', 0):.1f}MB",
                                            "🟢")

                        # Timestamp
                        monitor_table.add_row("Última actualización", datetime.now().strftime("%H:%M:%S"), "")

                        live.update(monitor_table)
                        await asyncio.sleep(2)
                    else:
                        live.update("[bold red]❌ Hardware monitor no disponible[/bold red]")
                        await asyncio.sleep(5)

        except KeyboardInterrupt:
            console.print("\n[bold yellow]⚠️ Monitoreo detenido por el usuario[/bold yellow]")

    async def _show_system_logs(self):
        """Mostrar logs del sistema."""
        console.print("[bold blue]📋 Logs del Sistema[/bold blue]")
        console.print("Esta función mostraría logs en tiempo real.")
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _show_config_menu(self):
        """Mostrar menú de configuración."""
        console.clear()
        console.print(Panel.fit("⚙️ Configuración", border_style="blue"))

        # Mostrar configuración actual
        config_table = Table(title="🔧 Configuración Actual")
        config_table.add_column("Parámetro", style="cyan")
        config_table.add_column("Valor", style="green")

        for key, value in self.config.items():
            config_table.add_row(key, str(value))

        console.print(config_table)
        console.print()

        # Opciones de configuración
        choices = [
            {"name": "🔗 Configurar URLs de Coordinador", "value": "urls"},
            {"name": "📁 Configurar Directorios", "value": "dirs"},
            {"name": "🎯 Modo Experto", "value": "expert"},
            {"name": "📊 Configurar Monitoreo", "value": "monitoring"},
            {"name": "💾 Guardar Configuración", "value": "save"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "urls":
            await self._configure_urls()
        elif choice == "dirs":
            await self._configure_directories()
        elif choice == "expert":
            self._toggle_expert_mode()
        elif choice == "monitoring":
            await self._configure_monitoring()
        elif choice == "save":
            await self._save_configuration()

    async def _configure_urls(self):
        """Configurar URLs del sistema."""
        console.print("[bold blue]🔗 Configuración de URLs[/bold blue]")

        coordinator_url = questionary.text("URL del Coordinador Federado:",
                                         default=self.config["coordinator_url"]).ask()
        api_url = questionary.text("URL del Servidor API:",
                                 default=self.config["api_server_url"]).ask()

        if coordinator_url:
            self.config["coordinator_url"] = coordinator_url
        if api_url:
            self.config["api_server_url"] = api_url

        console.print("[bold green]✅ URLs actualizadas[/bold green]")

    async def _configure_directories(self):
        """Configurar directorios."""
        console.print("[bold blue]📁 Configuración de Directorios[/bold blue]")

        models_dir = questionary.text("Directorio de Modelos:",
                                    default=self.config["models_dir"]).ask()
        training_dir = questionary.text("Directorio de Entrenamiento:",
                                      default=self.config["training_output_dir"]).ask()

        if models_dir:
            self.config["models_dir"] = models_dir
        if training_dir:
            self.config["training_output_dir"] = training_dir

        console.print("[bold green]✅ Directorios actualizados[/bold green]")

    def _toggle_expert_mode(self):
        """Alternar modo experto."""
        self.expert_mode = not self.expert_mode
        self.config["expert_mode"] = self.expert_mode

        status = "habilitado" if self.expert_mode else "deshabilitado"
        console.print(f"[bold green]✅ Modo experto {status}[/bold green]")

    async def _configure_monitoring(self):
        """Configurar monitoreo."""
        console.print("[bold blue]📊 Configuración de Monitoreo[/bold blue]")

        enable_hw = questionary.confirm("¿Habilitar monitoreo de hardware?",
                                      default=self.config["enable_monitoring"]).ask()
        auto_detect = questionary.confirm("¿Auto-detectar hardware?",
                                        default=self.config["auto_detect_hardware"]).ask()

        self.config["enable_monitoring"] = enable_hw
        self.config["auto_detect_hardware"] = auto_detect

        console.print("[bold green]✅ Configuración de monitoreo actualizada[/bold green]")

    async def _save_configuration(self):
        """Guardar configuración."""
        console.print("[bold blue]💾 Guardando configuración...[/bold blue]")

        # Aquí se guardaría en un archivo
        console.print("[bold green]✅ Configuración guardada[/bold green]")

    async def _show_debug_menu(self):
        """Mostrar menú de debugging."""
        console.clear()
        console.print(Panel.fit("🔧 Debugging & Logs", border_style="blue"))

        choices = [
            {"name": "🔍 Ver Estado de Componentes", "value": "status"},
            {"name": "📋 Ver Logs de Error", "value": "logs"},
            {"name": "🔄 Reinicializar Componentes", "value": "reset"},
            {"name": "🧪 Ejecutar Diagnósticos", "value": "diagnostics"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "status":
            await self._show_component_status()
        elif choice == "logs":
            await self._show_error_logs()
        elif choice == "reset":
            await self._reset_components()
        elif choice == "diagnostics":
            await self._run_diagnostics()

    async def _show_component_status(self):
        """Mostrar estado detallado de componentes."""
        console.print("[bold blue]🔍 Estado de Componentes[/bold blue]")

        status_table = Table(title="🔧 Estado de Componentes del Sistema")
        status_table.add_column("Componente", style="cyan")
        status_table.add_column("Estado", style="green")
        status_table.add_column("Detalles", style="yellow")

        # Hardware Monitor
        hw_status = "✅ Inicializado" if self.hardware_monitor else "❌ No disponible"
        hw_details = ""
        if self.hardware_monitor:
            hw_details = f"Node: {self.hardware_monitor.node_id}"

        status_table.add_row("Hardware Monitor", hw_status, hw_details)

        # Federated Client
        fed_status = "✅ Conectado" if self.federated_client and self.federated_client._running else "❌ Desconectado"
        fed_details = ""
        if self.federated_client:
            fed_details = f"URL: {self.federated_client.coordinator_url}"

        status_table.add_row("Cliente Federado", fed_status, fed_details)

        # Model Manager
        model_status = "✅ Inicializado" if self.model_manager else "❌ No disponible"
        model_details = ""
        if self.model_manager:
            model_details = f"Modelos locales: {len(self.model_manager.get_local_models())}"

        status_table.add_row("Gestor de Modelos", model_status, model_details)

        # Marketplace Client
        mp_status = "✅ Inicializado" if self.marketplace_client else "❌ No disponible"
        mp_details = ""
        if self.marketplace_client and self.marketplace_client.wallet:
            mp_details = f"Balance: {self.marketplace_client.wallet.balance:.2f} DRACMA"

        status_table.add_row("Cliente Marketplace", mp_status, mp_details)

        # Local Trainer
        train_status = "✅ Listo" if self.local_trainer and self.local_trainer.is_initialized else "❌ No inicializado"
        train_details = ""
        if self.local_trainer:
            train_details = f"Modelo: {self.local_trainer.config.model_name_or_path}"

        status_table.add_row("Entrenador Local", train_status, train_details)

        console.print(status_table)

    async def _show_error_logs(self):
        """Mostrar logs de error."""
        console.print("[bold blue]📋 Logs de Error[/bold blue]")
        console.print("Mostrando logs de error recientes...")
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _reset_components(self):
        """Reinicializar componentes."""
        if questionary.confirm("¿Reinicializar todos los componentes? Esto puede cerrar conexiones activas.").ask():
            console.print("[bold blue]🔄 Reinicializando componentes...[/bold blue]")

            # Detener monitoreo
            self.stop_monitoring()

            # Reinicializar
            success = await self.initialize()

            if success:
                console.print("[bold green]✅ Componentes reinicializados[/bold green]")
            else:
                console.print("[bold red]❌ Error reinicializando componentes[/bold red]")

    async def _run_diagnostics(self):
        """Ejecutar diagnósticos del sistema."""
        console.print("[bold blue]🧪 Ejecutando Diagnósticos...[/bold blue]")

        diagnostics_table = Table(title="🧪 Resultados de Diagnóstico")
        diagnostics_table.add_column("Prueba", style="cyan")
        diagnostics_table.add_column("Resultado", style="green")
        diagnostics_table.add_column("Detalles", style="yellow")

        # Diagnóstico de conectividad
        connectivity_ok = await self._test_connectivity()
        diagnostics_table.add_row("Conectividad", "✅ OK" if connectivity_ok else "❌ Error",
                                "Conexión con coordinador" if connectivity_ok else "Sin conexión")

        # Diagnóstico de hardware
        hw_ok = self.hardware_monitor is not None
        diagnostics_table.add_row("Hardware", "✅ OK" if hw_ok else "❌ Error",
                                "Hardware detectado" if hw_ok else "Hardware no disponible")

        # Diagnóstico de modelos
        models_ok = self.model_manager is not None
        diagnostics_table.add_row("Modelos", "✅ OK" if models_ok else "❌ Error",
                                "Gestor de modelos inicializado" if models_ok else "Gestor no disponible")

        # Diagnóstico de wallet
        wallet_ok = self.marketplace_client and self.marketplace_client.wallet
        diagnostics_table.add_row("Wallet", "✅ OK" if wallet_ok else "❌ Error",
                                "Wallet inicializada" if wallet_ok else "Wallet no disponible")

        console.print(diagnostics_table)

    async def _test_connectivity(self) -> bool:
        """Probar conectividad con el coordinador."""
        try:
            if not self.federated_client or not self.federated_client._session:
                return False

            # Intentar una petición simple
            async with self.federated_client._session.get(f"{self.coordinator_url}/status", timeout=5) as response:
                return response.status == 200
        except:
            return False

    async def _show_expert_menu(self):
        """Mostrar menú de modo experto."""
        if not self.expert_mode:
            console.print("[bold red]❌ Modo experto no habilitado[/bold red]")
            return

        console.clear()
        console.print(Panel.fit("🧠 Modo Experto", border_style="red"))

        choices = [
            {"name": "🔧 Configuración Avanzada", "value": "advanced_config"},
            {"name": "📊 Métricas Técnicas", "value": "technical_metrics"},
            {"name": "🔍 Inspección de Componentes", "value": "component_inspection"},
            {"name": "⚡ Operaciones Directas", "value": "direct_operations"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción (Modo Experto):", choices=choices).ask()

        if choice == "advanced_config":
            await self._show_advanced_config()
        elif choice == "technical_metrics":
            await self._show_technical_metrics()
        elif choice == "component_inspection":
            await self._show_component_inspection()
        elif choice == "direct_operations":
            await self._show_direct_operations()

    async def _show_advanced_config(self):
        """Mostrar configuración avanzada."""
        console.print("[bold red]🧠 Configuración Avanzada (Modo Experto)[/bold red]")
        console.print("[bold yellow]⚠️ Estas opciones pueden afectar la estabilidad del sistema[/bold yellow]")
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _show_technical_metrics(self):
        """Mostrar métricas técnicas detalladas."""
        console.print("[bold red]🧠 Métricas Técnicas (Modo Experto)[/bold red]")
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _show_component_inspection(self):
        """Inspeccionar componentes internos."""
        console.print("[bold red]🧠 Inspección de Componentes (Modo Experto)[/bold red]")
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _show_direct_operations(self):
        """Operaciones directas (peligrosas)."""
        console.print("[bold red]🧠 Operaciones Directas (Modo Experto)[/bold red]")
        console.print("[bold yellow]⚠️ Estas operaciones pueden ser destructivas[/bold yellow]")
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    def _handle_exit(self):
        """Manejar salida del programa."""
        console.clear()
        console.print(Panel.fit("👋 ¡Hasta luego!", border_style="blue"))
        console.print("[bold green]Gracias por usar AILOOS CLI[/bold green]")

        # Limpiar recursos
        self.stop_monitoring()

        # Cerrar componentes
        async def cleanup():
            if self.federated_client:
                await self.federated_client.disconnect()
            if self.model_manager:
                await self.model_manager.close()
            if self.marketplace_client:
                await self.marketplace_client.close()
            if self.local_trainer:
                await self.local_trainer.cleanup()

        try:
            asyncio.run(cleanup())
        except:
            pass

        console.print("[dim]Recursos limpiados. Saliendo...[/dim]")

    def _get_questionary_style(self):
        """Obtener estilo para questionary."""
        return questionary.Style([
            ('qmark', 'fg:#673ab7 bold'),
            ('question', 'bold'),
            ('answer', 'fg:#f44336 bold'),
            ('pointer', 'fg:#673ab7 bold'),
            ('highlighted', 'fg:#673ab7 bold'),
            ('selected', 'fg:#cc5803 bold'),
            ('separator', 'fg:#cc5454'),
            ('instruction', ''),
            ('text', ''),
        ])

    async def run(self):
        """Ejecutar la CLI."""
        try:
            # Inicializar sistema
            success = await self.initialize()
            if not success:
                console.print("[bold red]❌ Error inicializando AILOOS CLI. Saliendo...[/bold red]")
                return

            # Mostrar menú principal
            self.show_main_menu()

        except KeyboardInterrupt:
            self._handle_exit()
        except Exception as e:
            console.print(f"[bold red]❌ Error fatal: {e}[/bold red]")
            logger.error(f"Fatal error in CLI: {e}")
            self._handle_exit()


@click.command()
@click.option('--expert', is_flag=True, help='Habilitar modo experto')
@click.option('--coordinator-url', default=None, help='URL del coordinador federado')
@click.option('--api-url', default=None, help='URL del servidor API')
@click.option('--no-hardware-detect', is_flag=True, help='Deshabilitar auto-detección de hardware')
def main(expert, coordinator_url, api_url, no_hardware_detect):
    """AILOOS CLI - Interfaz Interactiva Completa"""
    # Configurar CLI
    cli = AILOOS_CLI()

    # Aplicar opciones de línea de comandos
    if expert:
        cli.expert_mode = True
        cli.config["expert_mode"] = True

    if coordinator_url:
        cli.config["coordinator_url"] = coordinator_url

    if api_url:
        cli.config["api_server_url"] = api_url

    if no_hardware_detect:
        cli.config["auto_detect_hardware"] = False

    # Ejecutar CLI
    asyncio.run(cli.run())


    async def _show_training_menu(self):
        """Mostrar menú de entrenamiento local."""
        console.clear()
        console.print(Panel.fit("🎯 Entrenamiento Local", border_style="blue"))

        if not self.local_trainer:
            console.print("[bold red]❌ Entrenador local no disponible[/bold red]")
            return

        # Estado del entrenador
        training_stats = self.local_trainer.get_training_stats()

        if training_stats.get("is_initialized"):
            console.print("[bold green]✅ Entrenador listo para usar[/bold green]")

            stats_table = Table(title="🎯 Estado del Entrenamiento")
            stats_table.add_column("Métrica", style="cyan")
            stats_table.add_column("Valor", style="green")

            stats_table.add_row("Modelo Base", training_stats.get("config", {}).get("model_name_or_path", "N/A"))
            stats_table.add_row("Batch Size", str(training_stats.get("config", {}).get("batch_size", 0)))
            stats_table.add_row("Paso Global", str(training_stats.get("global_step", 0)))
            stats_table.add_row("Epoch Actual", str(training_stats.get("current_epoch", 0)))
            stats_table.add_row("GPU Disponible", "✅ Sí" if training_stats.get("gpu_available") else "❌ No")
            stats_table.add_row("GPUs", str(training_stats.get("gpu_count", 0)))

            console.print(stats_table)
        else:
            console.print("[bold yellow]⚠️ Entrenador no inicializado[/bold yellow]")

        console.print()

        # Menú de opciones
        choices = [
            {"name": "🚀 Iniciar Entrenamiento", "value": "train"},
            {"name": "📊 Ver Métricas de Entrenamiento", "value": "metrics"},
            {"name": "💾 Guardar Adaptador LoRA", "value": "save"},
            {"name": "⚙️ Configurar Entrenamiento", "value": "config"},
            {"name": "⬅️ Volver al Menú Principal", "value": "back"}
        ]

        choice = questionary.select("Selecciona una opción:", choices=choices).ask()

        if choice == "train":
            await self._start_local_training()
        elif choice == "metrics":
            await self._show_training_metrics()
        elif choice == "save":
            await self._save_lora_adapter()
        elif choice == "config":
            await self._configure_training()

    async def _start_local_training(self):
        """Iniciar entrenamiento local."""
        if not questionary.confirm("¿Iniciar entrenamiento local? Esto puede tomar tiempo.").ask():
            return

        console.print("[bold blue]🚀 Iniciando entrenamiento local...[/bold blue]")

        # Barra de progreso para el entrenamiento
        with Progress() as progress:
            task = progress.add_task("[green]Entrenando...", total=None)

            # Ejecutar entrenamiento en una tarea separada
            import threading
            training_result = None
            training_error = None

            def training_thread():
                nonlocal training_result, training_error
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    training_result = loop.run_until_complete(self.local_trainer.train())
                except Exception as e:
                    training_error = e

            thread = threading.Thread(target=training_thread, daemon=True)
            thread.start()

            # Mostrar progreso
            while thread.is_alive():
                progress.update(task, advance=1)
                await asyncio.sleep(1)

            thread.join()

            if training_error:
                console.print(f"[bold red]❌ Error en entrenamiento: {training_error}[/bold red]")
                return

            progress.update(task, completed=True)

        # Mostrar resultados
        if training_result and training_result.get("training_completed"):
            console.print("[bold green]✅ Entrenamiento completado exitosamente![/bold green]")

            results_table = Table(title="📊 Resultados del Entrenamiento")
            results_table.add_column("Métrica", style="cyan")
            results_table.add_column("Valor", style="green")

            results_table.add_row("Epochs Completados", str(training_result.get("total_epochs", 0)))
            results_table.add_row("Pasos Totales", str(training_result.get("total_steps", 0)))
            results_table.add_row("Tiempo Total", f"{training_result.get('training_time', 0):.2f}s")

            final_metrics = training_result.get("final_metrics", {})
            if final_metrics:
                results_table.add_row("Loss Final", f"{final_metrics.get('loss', 0):.4f}")
                results_table.add_row("Learning Rate Final", f"{final_metrics.get('learning_rate', 0):.6f}")

            console.print(results_table)
        else:
            console.print("[bold red]❌ Entrenamiento fallido[/bold red]")

    async def _show_training_metrics(self):
        """Mostrar métricas de entrenamiento."""
        training_stats = self.local_trainer.get_training_stats()
        metrics_history = training_stats.get("metrics_history", [])

        if not metrics_history:
            console.print("[bold yellow]⚠️ No hay métricas de entrenamiento disponibles[/bold yellow]")
            return

        # Mostrar últimas métricas
        recent_metrics = metrics_history[-10:]  # Últimas 10

        metrics_table = Table(title=f"📈 Últimas Métricas de Entrenamiento ({len(recent_metrics)})")
        metrics_table.add_column("Paso", style="cyan")
        metrics_table.add_column("Loss", style="red")
        metrics_table.add_column("LR", style="green")
        metrics_table.add_column("GPU Mem", style="yellow")
        metrics_table.add_column("Throughput", style="blue")

        for metric in recent_metrics:
            metrics_table.add_row(
                str(metric.get("step", 0)),
                f"{metric.get('loss', 0):.4f}",
                f"{metric.get('learning_rate', 0):.6f}",
                f"{metric.get('gpu_memory_used', 0):.1f}MB",
                f"{metric.get('throughput', 0):.1f} samples/s"
            )

        console.print(metrics_table)

    async def _save_lora_adapter(self):
        """Guardar adaptador LoRA."""
        output_path = questionary.text("Ruta donde guardar el adaptador:", default="./lora_adapter").ask()

        if not output_path:
            return

        console.print(f"[bold blue]💾 Guardando adaptador LoRA en {output_path}...[/bold blue]")

        with console.status("[bold green]Guardando...") as status:
            await self.local_trainer.save_lora_adapter(output_path)

        console.print(f"[bold green]✅ Adaptador LoRA guardado en {output_path}[/bold green]")

    async def _configure_training(self):
        """Configurar parámetros de entrenamiento."""
        console.print("[bold blue]⚙️ Configuración de Entrenamiento[/bold blue]")
        console.print("Esta función permite reconfigurar el entrenador local.")
        console.print("Nota: Requiere reinicialización del entrenador.")

        # Aquí se podrían agregar opciones para cambiar configuración
        console.print("[bold yellow]⚠️ Función no implementada completamente[/bold yellow]")

    async def _create_data_listing(self):
        """Crear un listing de datos."""
        title = questionary.text("Título del dataset:").ask()
        if not title:
            return

        description = questionary.text("Descripción:").ask() or ""
        data_path = questionary.text("Ruta del archivo de datos:").ask()

        if not data_path or not Path(data_path).exists():
            console.print("[bold red]❌ Ruta de datos inválida[/bold red]")
            return

        price = questionary.text("Precio en DRACMA:", default="10.0").ask()
        try:
            price_dracma = float(price)
        except ValueError:
            console.print("[bold red]❌ Precio inválido[/bold red]")
            return

        metadata = {
            "data_size_mb": Path(data_path).stat().st_size / (1024 * 1024),
            "sample_count": 1000,  # Simulado
            "quality_score": 0.8,  # Simulado
            "tags": questionary.text("Tags (separados por coma):").ask().split(",") if questionary.confirm("¿Agregar tags?").ask() else []
        }

        console.print(f"[bold blue]📦 Creando listing '{title}'...[/bold blue]")

        with console.status("[bold green]Creando listing...") as status:
            listing_id = await self.marketplace_client.create_listing(title, description, data_path, price_dracma, metadata)

        if listing_id:
            console.print(f"[bold green]✅ Listing creado exitosamente: {listing_id}[/bold green]")
        else:
            console.print("[bold red]❌ Error creando listing[/bold red]")

    async def _search_datasets(self):
        """Buscar datasets en el marketplace."""
        query = questionary.text("Término de búsqueda (opcional):").ask() or ""

        min_price = questionary.text("Precio mínimo (opcional):").ask()
        max_price = questionary.text("Precio máximo (opcional):").ask()

        filters = {}
        if min_price:
            try:
                filters["min_price"] = float(min_price)
            except ValueError:
                pass
        if max_price:
            try:
                filters["max_price"] = float(max_price)
            except ValueError:
                pass

        console.print("[bold blue]🔍 Buscando datasets...[/bold blue]")

        with console.status("[bold green]Buscando...") as status:
            datasets = await self.marketplace_client.search_datasets(query=query, limit=20, **filters)

        if datasets:
            datasets_table = Table(title=f"🛒 Datasets Encontrados ({len(datasets)})")
            datasets_table.add_column("ID", style="cyan")
            datasets_table.add_column("Título", style="green")
            datasets_table.add_column("Precio", style="yellow")
            datasets_table.add_column("Calidad", style="magenta")
            datasets_table.add_column("Vendedor", style="blue")

            for dataset in datasets:
                datasets_table.add_row(
                    dataset.get("listing_id", "N/A")[:16] + "...",
                    dataset.get("title", "N/A")[:30],
                    f"{dataset.get('price_dracma', 0):.2f} DRACMA",
                    f"{dataset.get('quality_score', 0):.2f}",
                    dataset.get("seller_address", "N/A")[:16] + "..."
                )

            console.print(datasets_table)
        else:
            console.print("[bold yellow]⚠️ No se encontraron datasets[/bold yellow]")

    async def _purchase_dataset(self):
        """Comprar un dataset."""
        listing_id = questionary.text("ID del listing:").ask()

        if not listing_id:
            return

        use_escrow = questionary.confirm("¿Usar escrow para transacción segura?", default=True).ask()

        console.print(f"[bold blue]🛒 Comprando dataset {listing_id}...[/bold blue]")

        with console.status("[bold green]Procesando compra...") as status:
            result = await self.marketplace_client.purchase_data(listing_id, use_escrow)

        if result.get("success"):
            console.print(f"[bold green]✅ Compra exitosa: {result.get('message', 'Completada')}[/bold green]")
            if "escrow_id" in result:
                console.print(f"   🔐 Escrow ID: {result['escrow_id']}")
        else:
            console.print(f"[bold red]❌ Error en compra: {result.get('error', 'Desconocido')}[/bold red]")

    async def _transfer_tokens(self):
        """Transferir tokens DRACMA."""
        recipient = questionary.text("Dirección del destinatario:").ask()

        if not recipient:
            return

        amount = questionary.text("Cantidad de DRACMA:").ask()
        try:
            amount_dracma = float(amount)
        except ValueError:
            console.print("[bold red]❌ Cantidad inválida[/bold red]")
            return

        console.print(f"[bold blue]💸 Transfiriendo {amount_dracma} DRACMA a {recipient}...[/bold blue]")

        with console.status("[bold green]Procesando transferencia...") as status:
            success = await self.marketplace_client.transfer_tokens(recipient, amount_dracma)

        if success:
            console.print("[bold green]✅ Transferencia exitosa[/bold green]")
        else:
            console.print("[bold red]❌ Error en transferencia[/bold red]")

    async def _stake_tokens(self):
        """Stakear tokens."""
        amount = questionary.text("Cantidad de DRACMA a stakear:").ask()
        try:
            amount_dracma = float(amount)
        except ValueError:
            console.print("[bold red]❌ Cantidad inválida[/bold red]")
            return

        console.print(f"[bold blue]🔒 Stakeando {amount_dracma} DRACMA...[/bold blue]")

        with console.status("[bold green]Procesando stake...") as status:
            success = await self.marketplace_client.stake_tokens(amount_dracma)

        if success:
            console.print("[bold green]✅ Stake exitoso[/bold green]")
        else:
            console.print("[bold red]❌ Error en stake[/bold red]")

    async def _show_transaction_history(self):
        """Mostrar historial de transacciones."""
        console.print("[bold blue]📋 Obteniendo historial de transacciones...[/bold blue]")

        with console.status("[bold green]Cargando...") as status:
            transactions = await self.marketplace_client.get_transaction_history(limit=20)

        if transactions:
            tx_table = Table(title=f"💰 Historial de Transacciones ({len(transactions)})")
            tx_table.add_column("Tipo", style="cyan")
            tx_table.add_column("Cantidad", style="green")
            tx_table.add_column("Dirección", style="yellow")
            tx_table.add_column("Fecha", style="magenta")

            for tx in transactions:
                tx_type = tx.get("type", "unknown")
                amount = tx.get("amount", 0)
                address = tx.get("to_address", tx.get("from_address", "N/A"))
                timestamp = tx.get("timestamp", "N/A")

                tx_table.add_row(
                    tx_type,
                    f"{amount:.2f} DRACMA",
                    address[:16] + "..." if len(address) > 16 else address,
                    timestamp[:19] if timestamp != "N/A" else "N/A"
                )

            console.print(tx_table)
        else:
            console.print("[bold yellow]⚠️ No hay transacciones[/bold yellow]")


@click.command()
@click.option('--expert', is_flag=True, help='Habilitar modo experto')
@click.option('--coordinator-url', default=None, help='URL del coordinador federado')
@click.option('--api-url', default=None, help='URL del servidor API')
@click.option('--no-hardware-detect', is_flag=True, help='Deshabilitar auto-detección de hardware')
def main(expert, coordinator_url, api_url, no_hardware_detect):
    """AILOOS CLI - Interfaz Interactiva Completa"""
    # Configurar CLI
    cli = AILOOS_CLI()

    # Aplicar opciones de línea de comandos
    if expert:
        cli.expert_mode = True
        cli.config["expert_mode"] = True

    if coordinator_url:
        cli.config["coordinator_url"] = coordinator_url

    if api_url:
        cli.config["api_server_url"] = api_url

    if no_hardware_detect:
        cli.config["auto_detect_hardware"] = False

    # Ejecutar CLI
    asyncio.run(cli.run())


if __name__ == "__main__":
    main()

