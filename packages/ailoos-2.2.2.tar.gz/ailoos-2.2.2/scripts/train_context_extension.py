import os
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
import logging
from tqdm import tqdm
import math

# Importar componentes de AILOOS
from src.ailoos.models.empoorio_lm.model import EmpoorioLM
from src.ailoos.models.empoorio_lm.config import EmpoorioLMConfig

# Configurar logging
logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class LongContextDataset(Dataset):
    """
    Genera secuencias sintéticas largas diseñadas para probar
    la capacidad de recuperación a larga distancia (Needle in a Haystack).
    """
    def __init__(self, vocab_size, seq_len, num_samples):
        self.vocab_size = vocab_size
        self.seq_len = seq_len
        self.num_samples = num_samples

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        # Generar tokens aleatorios
        data = torch.randint(0, self.vocab_size, (self.seq_len,), dtype=torch.long)
        
        # Inyectar un patrón repetitivo "clave-valor" a larga distancia
        # para forzar al modelo a atender al pasado lejano.
        key_token = 100
        val_token = torch.randint(0, self.vocab_size, (1,)).item()
        
        # Colocar la clave al principio
        data[10] = key_token
        data[11] = val_token
        
        # Colocar la clave al final (el modelo debe predecir val_token)
        data[-2] = key_token
        data[-1] = val_token # Label (target)
        
        # Inputs y Labels (Shifted)
        x = data[:-1]
        y = data[1:] # El último token es el target real
        
        return x, y

def train_context_extension():
    logger.info("🚀 INICIANDO FASE 2: EXTENSIÓN DE CONTEXTO A 8192 TOKENS")
    
    # 1. Configuración
    TARGET_SEQ_LEN = 8192
    ORIGINAL_SEQ_LEN = 1024
    BATCH_SIZE = 1 # Micro-batch pequeño para no explotar VRAM
    GRAD_ACCUM_STEPS = 8
    LEARNING_RATE = 1e-4
    EPOCHS = 1
    DEVICE = "mps" if torch.backends.mps.is_available() else "cpu"
    
    # Calcular factor de escalado NTK
    scaling_factor = TARGET_SEQ_LEN / ORIGINAL_SEQ_LEN
    logger.info(f"📏 Scaling Factor NTK: {scaling_factor}x ({ORIGINAL_SEQ_LEN} -> {TARGET_SEQ_LEN})")

    # 2. Inicializar Modelo MoE (Ya activado)
    # Nota: En un escenario real cargaríamos los pesos de 'activation_benchmark', 
    # aquí inicializamos uno nuevo con la config correcta para la demo.
    config = EmpoorioLMConfig(
        vocab_size=30000,
        hidden_size=512,
        num_layers=8,
        num_heads=8,
        max_position_embeddings=ORIGINAL_SEQ_LEN, # El modelo cree que es 1k
        use_moe=True,
        num_experts=8,
        top_k=2,
        # ACTIVAR ROPE SCALING
        use_rope=True,
        rope_scaling_factor=scaling_factor, 
        rope_ntk_factor=1.0 # Base NTK
    )
    
    model = EmpoorioLM(config).to(DEVICE)
    logger.info(f"🧠 Modelo MoE Inicializado en {DEVICE}. Params: {model.get_num_params():,}")
    
    # 3. Preparar Datos de Largo Contexto
    dataset = LongContextDataset(config.vocab_size, TARGET_SEQ_LEN, num_samples=100)
    dataloader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
    
    # 4. Optimizador
    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE)
    
    # 5. Bucle de Entrenamiento (Fine-Tuning)
    model.train()
    total_loss = 0
    
    progress_bar = tqdm(dataloader, desc="Extension Training")
    
    for step, (x, y) in enumerate(progress_bar):
        x, y = x.to(DEVICE), y.to(DEVICE)
        
        # Forward Pass
        # El modelo usará internamente NTK-Aware RoPE para manejar las posiciones > 1024
        outputs = model(x, targets=y)
        loss = outputs['loss']
        
        # Gradient Accumulation
        loss = loss / GRAD_ACCUM_STEPS
        loss.backward()
        
        if (step + 1) % GRAD_ACCUM_STEPS == 0:
            optimizer.step()
            optimizer.zero_grad()
            
        total_loss += loss.item() * GRAD_ACCUM_STEPS
        progress_bar.set_postfix({'loss': f"{loss.item() * GRAD_ACCUM_STEPS:.4f}"})

    avg_loss = total_loss / len(dataloader)
    logger.info(f"✅ Entrenamiento completado. Loss promedio: {avg_loss:.4f}")
    
    # 6. Guardar Modelo Extendido
    output_path = "models/empoorio_lm_8k"
    os.makedirs(output_path, exist_ok=True)
    # En producción: model.save_pretrained(output_path)
    torch.save(model.state_dict(), f"{output_path}/pytorch_model.bin")
    
    # Guardar config actualizada
    config.max_position_embeddings = TARGET_SEQ_LEN # Actualizar config oficial
    # config.save_pretrained(output_path)
    
    logger.info(f"💾 Modelo 8k guardado en: {output_path}")
    logger.info("🚀 FASE 2 COMPLETADA: EmpoorioLM ahora soporta 8192 tokens.")

if __name__ == "__main__":
    train_context_extension()