#!/usr/bin/env python3
"""
Simple validation script for Blue-Green Deployment system.
"""

import sys
import os

# Add src/ailoos to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'ailoos'))

def test_imports():
    """Test that all modules can be imported."""
    try:
        import blue_green_deployment.blue_green_manager as bgm
        import blue_green_deployment.environment_switcher as es
        import blue_green_deployment.traffic_router as tr
        import blue_green_deployment.health_validator as hv
        import blue_green_deployment.rollback_manager as rm
        import blue_green_deployment.deployment_monitor as dm

        print("✓ All modules imported successfully")
        return True
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False

def test_basic_functionality():
    """Test basic functionality of the components."""
    try:
        from blue_green_deployment.blue_green_manager import BlueGreenManager, DeploymentStatus
        from blue_green_deployment.environment_switcher import EnvironmentSwitcher, SwitchMode
        from blue_green_deployment.traffic_router import TrafficRouter, RoutingStrategy
        from blue_green_deployment.health_validator import HealthValidator
        from blue_green_deployment.rollback_manager import RollbackManager, RollbackStrategy
        from blue_green_deployment.deployment_monitor import DeploymentMonitor, AlertSeverity

        # Test BlueGreenManager
        config = {
            'blue_env': {'url': 'http://blue.example.com'},
            'green_env': {'url': 'http://green.example.com'},
            'health_check_timeout': 30,
            'traffic_switch_timeout': 60,
            'rollback_on_failure': True
        }

        manager = BlueGreenManager(config)
        assert manager.current_status == DeploymentStatus.IDLE
        assert manager.active_environment == 'blue'
        print("✓ BlueGreenManager initialized correctly")

        # Test EnvironmentSwitcher
        switcher = EnvironmentSwitcher({'switch_mode': 'immediate'})
        result = switcher.switch_traffic('green')
        assert result == True
        assert switcher.traffic_distribution == {'blue': 0, 'green': 100}
        print("✓ EnvironmentSwitcher works correctly")

        # Test TrafficRouter
        router = TrafficRouter({'routing_strategy': 'weighted'})
        env = router.route_request({})
        assert env in ['blue', 'green']
        print("✓ TrafficRouter works correctly")

        # Test HealthValidator
        validator = HealthValidator({
            'health_checks': [{
                'name': 'test_check',
                'type': 'http',
                'url': 'http://test.com',
                'method': 'GET',
                'expected_status': 200
            }]
        })
        # Note: validation will fail due to network, but object creation works
        print("✓ HealthValidator initialized correctly")

        # Test RollbackManager
        rollback_mgr = RollbackManager({'max_snapshots': 5})
        assert len(rollback_mgr.snapshots) == 0
        print("✓ RollbackManager initialized correctly")

        # Test DeploymentMonitor
        monitor = DeploymentMonitor({
            'alert_rules': [],
            'enable_real_time': False
        })
        monitor.record_metric('test_metric', 42.0)
        stats = monitor.get_metric_stats('test_metric')
        assert stats['count'] == 1
        assert stats['avg'] == 42.0
        print("✓ DeploymentMonitor works correctly")

        return True

    except Exception as e:
        print(f"✗ Functionality test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all validation tests."""
    print("Running Blue-Green Deployment System Validation")
    print("=" * 50)

    success = True

    success &= test_imports()
    success &= test_basic_functionality()

    print("=" * 50)
    if success:
        print("✓ All validation tests passed!")
        return 0
    else:
        print("✗ Some validation tests failed!")
        return 1

if __name__ == '__main__':
    sys.exit(main())