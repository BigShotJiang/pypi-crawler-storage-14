#!/usr/bin/env python3
"""
Script de prueba independiente para validar salidas estructuradas.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_json_schema_validation():
    """Test básico de validación JSON Schema."""
    try:
        # Importar directamente los archivos sin pasar por el paquete
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src', 'ailoos', 'schemas'))

        # Importar módulos individuales
        import base
        import inference
        import serialization

        print("✅ Imports exitosos")

        # Crear respuestas de ejemplo
        base_response = base.BaseLLMResponseSchema.create_base_response(
            response_id="test-123",
            model_name="TestModel",
            model_version="v1.0",
            total_tokens=100
        )

        inference_response = inference.InferenceResponseSchema.create_inference_response(
            text="Test response",
            prompt_tokens=10,
            completion_tokens=20,
            model_name="TestModel",
            model_version="v1.0"
        )

        toon_response = serialization.TOONResponseSchema.create_toon_response(
            toon_data="VE9PTjEAAAAAAAABAAAAAQAAAAEAAAA=",
            toon_metadata={
                "original_size_bytes": 100,
                "compressed_size_bytes": 80,
                "compression_ratio": 1.25,
                "data_type": "array"
            }
        )

        vsc_response = serialization.VSCResponseSchema.create_vsc_response(
            vsc_data="VlNDLTEAAAAAAAABAAAAAQAAAAEAAAA=",
            vsc_metadata={
                "data_type": "columnar",
                "num_columns": 2,
                "num_rows": 10,
                "column_types": {"col1": "int32", "col2": "float64"}
            }
        )

        # Validar respuestas
        validations = [
            ("Base Response", base.BaseLLMResponseSchema.validate_response(base_response)),
            ("Inference Response", inference.InferenceResponseSchema.validate_response(inference_response)),
            ("TOON Response", serialization.TOONResponseSchema.validate_response(toon_response)),
            ("VSC Response", serialization.VSCResponseSchema.validate_response(vsc_response))
        ]

        print("\n🔍 Resultados de validación:")
        all_valid = True
        for name, is_valid in validations:
            status = "✅" if is_valid else "❌"
            print(f"  {status} {name}: {'Válido' if is_valid else 'Inválido'}")
            if not is_valid:
                all_valid = False

        print(f"\n📊 Resumen: {'Todas las validaciones pasaron' if all_valid else 'Algunas validaciones fallaron'}")
        return all_valid

    except Exception as e:
        print(f"❌ Error en validación: {e}")
        return False

def test_pydantic_fallback():
    """Test básico del fallback Pydantic."""
    try:
        import pydantic_fallback
        import inference

        print("\n🔄 Testing Pydantic fallback...")

        if not pydantic_fallback.is_pydantic_fallback_available():
            print("⚠️  Pydantic fallback no disponible")
            return True  # No es un error, solo no está disponible

        # Texto simulado con JSON
        test_text = '''Respuesta generada:
```json
{
    "text": "Esta es una respuesta de prueba",
    "finish_reason": "stop",
    "usage": {
        "prompt_tokens": 5,
        "completion_tokens": 10,
        "total_tokens": 15
    }
}
```'''

        schema = inference.InferenceResponseSchema.get_schema()
        result = pydantic_fallback.parse_with_pydantic_fallback(
            generated_text=test_text,
            schema=schema,
            model_name="TestModel",
            model_version="v1.0"
        )

        if result:
            print("✅ Pydantic fallback funcionó correctamente")
            return True
        else:
            print("❌ Pydantic fallback falló")
            return False

    except Exception as e:
        print(f"❌ Error en Pydantic fallback: {e}")
        return False

if __name__ == "__main__":
    print("🚀 Iniciando pruebas de salidas estructuradas...\n")

    success = True
    success &= test_json_schema_validation()
    success &= test_pydantic_fallback()

    if success:
        print("\n🎉 Todas las pruebas pasaron exitosamente!")
        sys.exit(0)
    else:
        print("\n💥 Algunas pruebas fallaron")
        sys.exit(1)