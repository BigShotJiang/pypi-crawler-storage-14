#!/usr/bin/env python3
"""
Script para ejecutar el Dashboard Interactivo completo de AILOOS.
Inicia todas las APIs necesarias para el funcionamiento del dashboard.
"""

import asyncio
import threading
import time
import sys
import os

# Añadir el directorio src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.api.dashboard_api import dashboard_api
from ailoos.api.technical_dashboard_api import technical_dashboard_api
from ailoos.api.federated_api import federated_api
from ailoos.api.wallet_api import wallet_api

def run_dashboard_api():
    """Ejecutar la API unificada del dashboard."""
    print("🚀 Iniciando Dashboard API en puerto 8003...")
    dashboard_api.start_server(host="0.0.0.0", port=8003)

def run_technical_dashboard_api():
    """Ejecutar la API técnica del dashboard."""
    print("📊 Iniciando Technical Dashboard API en puerto 8002...")
    technical_dashboard_api.start_server(host="0.0.0.0", port=8002)

def run_federated_api():
    """Ejecutar la API federada."""
    print("🔗 Iniciando Federated API en puerto 8001...")
    federated_api.start_server(host="0.0.0.0", port=8001)

def run_wallet_api():
    """Ejecutar la API de wallets."""
    print("💰 Iniciando Wallet API en puerto 8004...")
    wallet_api.start_server(host="0.0.0.0", port=8004)

async def main():
    """Función principal para ejecutar todas las APIs."""
    print("🎯 Iniciando Dashboard Interactivo Completo de AILOOS")
    print("=" * 60)

    # Crear threads para cada API
    threads = []

    apis = [
        ("Dashboard API", run_dashboard_api),
        ("Technical Dashboard API", run_technical_dashboard_api),
        ("Federated API", run_federated_api),
        ("Wallet API", run_wallet_api),
    ]

    for name, func in apis:
        thread = threading.Thread(target=func, daemon=True)
        threads.append((name, thread))

    # Iniciar todas las APIs
    for name, thread in threads:
        print(f"📡 Iniciando {name}...")
        thread.start()
        time.sleep(1)  # Pequeña pausa para evitar conflictos de puerto

    print("\n✅ Todas las APIs han sido iniciadas!")
    print("\n🌐 Endpoints disponibles:")
    print("  • Dashboard Principal: http://localhost:8003")
    print("  • Dashboard Técnico:   http://localhost:8002")
    print("  • API Federada:        http://localhost:8001")
    print("  • API Wallets:         http://localhost:8004")
    print("\n🎨 Frontend del Dashboard: http://localhost:3000/dashboard")
    print("\n⚡ WebSocket disponible en ws://localhost:8003/ws/dashboard")
    print("\n🛑 Presiona Ctrl+C para detener todas las APIs")

    try:
        # Mantener el programa corriendo
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("\n🛑 Deteniendo todas las APIs...")
        sys.exit(0)

if __name__ == "__main__":
    print("AILOOS Dashboard Interactivo")
    print("Integración completa: Refinería + Hardware + Wallets + Federated Learning")
    print("-" * 80)

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 ¡Hasta luego!")
    except Exception as e:
        print(f"❌ Error al iniciar el dashboard: {e}")
        sys.exit(1)