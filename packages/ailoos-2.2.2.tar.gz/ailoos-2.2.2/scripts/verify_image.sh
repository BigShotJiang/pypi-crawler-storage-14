#!/bin/bash
# Script to verify Docker images using Cosign
# Usage: ./verify_image.sh <image_uri>

set -e

if [ $# -ne 1 ]; then
    echo "Usage: $0 <image_uri>"
    exit 1
fi

IMAGE_URI=$1

echo "Verifying image: $IMAGE_URI"

# Verify the image using Cosign with public key from environment
cosign verify --key env://COSIGN_PUBLIC_KEY "$IMAGE_URI"

echo "Image verification successful: $IMAGE_URI"