#!/bin/bash
# AILOOS Security Penetration Test Runner
# Executes security tests on running containers

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
TEST_SCRIPT="$SCRIPT_DIR/security_penetration_test.py"
REPORT_DIR="$PROJECT_ROOT/reports"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
REPORT_FILE="$REPORT_DIR/security_test_report_$TIMESTAMP.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo "AILOOS Security Penetration Test Runner"
echo "======================================"

# Create reports directory if it doesn't exist
mkdir -p "$REPORT_DIR"

# Function to check if kubectl is available
check_kubectl() {
    if ! command -v kubectl &> /dev/null; then
        echo -e "${RED}kubectl not found. Please install kubectl or ensure it's in PATH.${NC}"
        exit 1
    fi
}

# Function to check if docker is available
check_docker() {
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}docker not found. Please install docker or ensure it's in PATH.${NC}"
        exit 1
    fi
}

# Function to run tests on Kubernetes pod
run_k8s_test() {
    local pod_name=$1
    local namespace=${2:-default}

    echo -e "${YELLOW}Running security tests on pod: $pod_name (namespace: $namespace)${NC}"

    # Check if pod exists
    if ! kubectl get pod "$pod_name" -n "$namespace" &> /dev/null; then
        echo -e "${RED}Pod $pod_name not found in namespace $namespace${NC}"
        return 1
    fi

    # Copy test script to pod
    echo "Copying test script to pod..."
    kubectl cp "$TEST_SCRIPT" "$namespace/$pod_name:/tmp/security_penetration_test.py"

    # Make script executable
    kubectl exec "$pod_name" -n "$namespace" -- chmod +x /tmp/security_penetration_test.py

    # Run the test script
    echo "Executing security tests..."
    kubectl exec "$pod_name" -n "$namespace" -- python3 /tmp/security_penetration_test.py > "$REPORT_FILE"

    # Copy report back if needed (already saved in container, but we captured output)
    echo -e "${GREEN}Tests completed for pod: $pod_name${NC}"
    echo "Report saved to: $REPORT_FILE"
}

# Function to run tests on Docker container
run_docker_test() {
    local container_name=$1

    echo -e "${YELLOW}Running security tests on container: $container_name${NC}"

    # Check if container is running
    if ! docker ps --format "table {{.Names}}" | grep -q "^${container_name}$"; then
        echo -e "${RED}Container $container_name is not running${NC}"
        return 1
    fi

    # Check if test script exists in container (via volume mount)
    if ! docker exec "$container_name" test -f /tmp/security_penetration_test.py; then
        echo -e "${RED}Test script not found in container. Make sure it's mounted as volume.${NC}"
        return 1
    fi

    # Run the test script (chmod may fail on read-only, but python can execute)
    echo "Executing security tests..."
    docker exec "$container_name" python3 /tmp/security_penetration_test.py > "$REPORT_FILE" 2>&1

    echo -e "${GREEN}Tests completed for container: $container_name${NC}"
    echo "Report saved to: $REPORT_FILE"
}

# Function to test EmpoorioLM functionality after security tests
test_empoorio_functionality() {
    local pod_name=$1
    local namespace=${2:-default}

    echo -e "${YELLOW}Testing EmpoorioLM functionality after security tests...${NC}"

    # Try to access health endpoint
    if kubectl exec "$pod_name" -n "$namespace" -- curl -f http://localhost:8000/health &> /dev/null; then
        echo -e "${GREEN}EmpoorioLM health check: PASS${NC}"
    else
        echo -e "${RED}EmpoorioLM health check: FAIL${NC}"
    fi
}

# Main execution
main() {
    local test_mode=""
    local target=""

    # Parse arguments
    while [[ $# -gt 0 ]]; do
        case $1 in
            --k8s)
                test_mode="k8s"
                shift
                ;;
            --docker)
                test_mode="docker"
                shift
                ;;
            --pod)
                target="$2"
                shift 2
                ;;
            --container)
                target="$2"
                shift 2
                ;;
            --namespace)
                namespace="$2"
                shift 2
                ;;
            --help)
                echo "Usage: $0 [--k8s|--docker] [--pod POD_NAME|--container CONTAINER_NAME] [--namespace NAMESPACE]"
                echo ""
                echo "Examples:"
                echo "  $0 --k8s --pod ailoos-empoorio-12345"
                echo "  $0 --docker --container ailoos_empoorio"
                exit 0
                ;;
            *)
                echo -e "${RED}Unknown option: $1${NC}"
                exit 1
                ;;
        esac
    done

    # Determine test mode and target
    if [[ -z "$test_mode" ]]; then
        # Auto-detect
        if command -v kubectl &> /dev/null && kubectl get pods &> /dev/null; then
            test_mode="k8s"
            echo "Auto-detected Kubernetes environment"
        elif command -v docker &> /dev/null && docker ps &> /dev/null; then
            test_mode="docker"
            echo "Auto-detected Docker environment"
        else
            echo -e "${RED}Neither Kubernetes nor Docker detected. Please specify --k8s or --docker${NC}"
            exit 1
        fi
    fi

    if [[ "$test_mode" == "k8s" ]]; then
        check_kubectl

        if [[ -z "$target" ]]; then
            # Find Empoorio pod
            target=$(kubectl get pods -l app=ailoos-empoorio -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
            if [[ -z "$target" ]]; then
                echo -e "${RED}No Empoorio pod found. Please specify --pod POD_NAME${NC}"
                exit 1
            fi
            echo "Found Empoorio pod: $target"
        fi

        run_k8s_test "$target" "${namespace:-default}"
        test_empoorio_functionality "$target" "${namespace:-default}"

    elif [[ "$test_mode" == "docker" ]]; then
        check_docker

        if [[ -z "$target" ]]; then
            # Find Empoorio container
            target=$(docker ps --filter "name=empoorio" --format "{{.Names}}" | head -1)
            if [[ -z "$target" ]]; then
                echo -e "${RED}No Empoorio container found. Please specify --container CONTAINER_NAME${NC}"
                exit 1
            fi
            echo "Found Empoorio container: $target"
        fi

        run_docker_test "$target"
        # For Docker, we can't easily test internal health without knowing the port mapping
        echo "Note: EmpoorioLM functionality test requires manual verification for Docker containers"
    fi

    echo ""
    echo -e "${GREEN}Security testing completed!${NC}"
    echo "Full report available at: $REPORT_FILE"
}

main "$@"