#!/usr/bin/env python3
"""
Script maestro para ejecutar tests completos de Maturity Level 5.
Ejecuta tests de Docker, IA, MLOps, seguridad, compliance, y CI/CD.
Genera reportes consolidados y valida que todo funciona correctamente.
"""

import asyncio
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any
import logging

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('maturity5_test_report.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class Maturity5TestRunner:
    """Ejecutor de tests para Maturity Level 5."""

    def __init__(self):
        self.project_root = Path(__file__).parent.parent
        self.reports_dir = self.project_root / "reports"
        self.reports_dir.mkdir(exist_ok=True)
        self.results = {}

    async def run_all_tests(self) -> bool:
        """Ejecutar todos los tests de Maturity Level 5."""
        logger.info("🚀 Iniciando ejecución de tests de Maturity Level 5")

        start_time = time.time()

        try:
            # 1. Tests de IA y MLOps
            await self.run_ai_mlops_tests()

            # 2. Tests de Seguridad
            await self.run_security_tests()

            # 3. Tests de Compliance
            await self.run_compliance_tests()

            # 4. Tests de Federated Learning (MLOps)
            await self.run_federated_tests()

            # 5. Tests de Docker
            await self.run_docker_tests()

            # 6. Tests de CI/CD
            await self.run_cicd_tests()

            # 7. Tests de Verificación (ZKP)
            await self.run_verification_tests()

            # Generar reporte consolidado
            await self.generate_consolidated_report()

            # Validar resultados
            success = self.validate_all_tests_passed()

            end_time = time.time()
            duration = end_time - start_time

            if success:
                logger.info(f"✅ Todos los tests pasaron en {duration:.2f} segundos")
            else:
                logger.error(f"❌ Algunos tests fallaron en {duration:.2f} segundos")
            return success

        except Exception as e:
            logger.error(f"❌ Error crítico en ejecución de tests: {e}")
            return False

    async def run_ai_mlops_tests(self):
        """Ejecutar tests de IA y MLOps."""
        logger.info("🤖 Ejecutando tests de IA y MLOps")

        test_files = [
            "tests/test_inference_maturity2.py",
            "tests/test_graph_rag.py",
            "src/ailoos/rag/tests/test_corrective_rag.py",
            "src/ailoos/rag/tests/test_naive_rag.py",
            "src/ailoos/rag/tests/test_speculative_rag.py",
            "src/ailoos/rag/tests/test_maturity3_compliance.py"
        ]

        results = []
        for test_file in test_files:
            if os.path.exists(test_file):
                result = await self.run_pytest(test_file)
                results.append(result)
            else:
                logger.warning(f"⚠️ Test file not found: {test_file}")

        self.results['ai_mlops'] = {
            'tests': results,
            'passed': sum(1 for r in results if r.get('passed', False)),
            'total': len(results)
        }

    async def run_security_tests(self):
        """Ejecutar tests de seguridad."""
        logger.info("🔒 Ejecutando tests de seguridad")

        test_files = [
            "tests/test_validation_system.py",
            "tests/test_websocket_system_tools.py"
        ]

        results = []
        for test_file in test_files:
            if os.path.exists(test_file):
                result = await self.run_pytest(test_file)
                results.append(result)

        self.results['security'] = {
            'tests': results,
            'passed': sum(1 for r in results if r.get('passed', False)),
            'total': len(results)
        }

    async def run_compliance_tests(self):
        """Ejecutar tests de compliance."""
        logger.info("📋 Ejecutando tests de compliance")

        test_files = [
            "src/ailoos/rag/tests/test_maturity3_compliance.py",
            "tests/test_integration_auditing.py",
            "tests/test_e2e_auditing.py"
        ]

        results = []
        for test_file in test_files:
            if os.path.exists(test_file):
                result = await self.run_pytest(test_file)
                results.append(result)

        self.results['compliance'] = {
            'tests': results,
            'passed': sum(1 for r in results if r.get('passed', False)),
            'total': len(results)
        }

    async def run_federated_tests(self):
        """Ejecutar tests de federated learning."""
        logger.info("🌐 Ejecutando tests de federated learning")

        # Buscar todos los tests federated
        federated_tests = [
            f for f in os.listdir("tests")
            if f.startswith("test_federated") or "federated" in f.lower()
        ]

        results = []
        for test_file in federated_tests:
            test_path = f"tests/{test_file}"
            if os.path.exists(test_path):
                result = await self.run_pytest(test_path)
                results.append(result)

        self.results['federated'] = {
            'tests': results,
            'passed': sum(1 for r in results if r.get('passed', False)),
            'total': len(results)
        }

    async def run_docker_tests(self):
        """Ejecutar tests relacionados con Docker."""
        logger.info("🐳 Ejecutando tests de Docker")

        # Ejecutar benchmark de Docker
        docker_script = "docker/benchmark_docker_sizes.py"
        if os.path.exists(docker_script):
            result = await self.run_python_script(docker_script)
            self.results['docker'] = {
                'benchmark': result,
                'passed': result.get('passed', False),
                'total': 1
            }
        else:
            logger.warning("⚠️ Docker benchmark script not found")
            self.results['docker'] = {'passed': 0, 'total': 0}

    async def run_cicd_tests(self):
        """Ejecutar tests de CI/CD."""
        logger.info("🔄 Ejecutando tests de CI/CD")

        cicd_scripts = [
            "scripts/health_check.sh",
            "scripts/verify_deployment_readiness.sh",
            "scripts/run_security_tests.sh"
        ]

        results = []
        for script in cicd_scripts:
            if os.path.exists(script):
                result = await self.run_shell_script(script)
                results.append(result)

        self.results['cicd'] = {
            'scripts': results,
            'passed': sum(1 for r in results if r.get('passed', False)),
            'total': len(results)
        }

    async def run_verification_tests(self):
        """Ejecutar tests de verificación (ZKP)."""
        logger.info("🔐 Ejecutando tests de verificación ZKP")

        verification_tests = [
            f for f in os.listdir("tests/verification")
            if f.endswith(".py")
        ]

        results = []
        for test_file in verification_tests:
            test_path = f"tests/verification/{test_file}"
            if os.path.exists(test_path):
                result = await self.run_pytest(test_path)
                results.append(result)

        self.results['verification'] = {
            'tests': results,
            'passed': sum(1 for r in results if r.get('passed', False)),
            'total': len(results)
        }

    async def run_pytest(self, test_file: str) -> Dict[str, Any]:
        """Ejecutar un archivo de test con pytest."""
        try:
            cmd = [sys.executable, "-m", "pytest", test_file, "--tb=short", "--json-report", "--json-report-file=temp_report.json"]
            result = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=self.project_root,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await result.communicate()

            # Leer reporte JSON si existe
            json_report = {}
            temp_report_path = self.project_root / "temp_report.json"
            if temp_report_path.exists():
                try:
                    with open(temp_report_path, 'r') as f:
                        json_report = json.load(f)
                    temp_report_path.unlink()  # Limpiar
                except:
                    pass

            passed = result.returncode == 0
            return {
                'test_file': test_file,
                'passed': passed,
                'return_code': result.returncode,
                'stdout': stdout.decode(),
                'stderr': stderr.decode(),
                'json_report': json_report
            }

        except Exception as e:
            logger.error(f"Error running pytest for {test_file}: {e}")
            return {
                'test_file': test_file,
                'passed': False,
                'error': str(e)
            }

    async def run_python_script(self, script_path: str) -> Dict[str, Any]:
        """Ejecutar un script Python."""
        try:
            cmd = [sys.executable, script_path]
            result = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=self.project_root,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await result.communicate()

            passed = result.returncode == 0
            return {
                'script': script_path,
                'passed': passed,
                'return_code': result.returncode,
                'stdout': stdout.decode(),
                'stderr': stderr.decode()
            }

        except Exception as e:
            logger.error(f"Error running Python script {script_path}: {e}")
            return {
                'script': script_path,
                'passed': False,
                'error': str(e)
            }

    async def run_shell_script(self, script_path: str) -> Dict[str, Any]:
        """Ejecutar un script de shell."""
        try:
            cmd = ["bash", script_path]
            result = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=self.project_root,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await result.communicate()

            passed = result.returncode == 0
            return {
                'script': script_path,
                'passed': passed,
                'return_code': result.returncode,
                'stdout': stdout.decode(),
                'stderr': stderr.decode()
            }

        except Exception as e:
            logger.error(f"Error running shell script {script_path}: {e}")
            return {
                'script': script_path,
                'passed': False,
                'error': str(e)
            }

    async def generate_consolidated_report(self):
        """Generar reporte consolidado."""
        logger.info("📊 Generando reporte consolidado")

        report = {
            'timestamp': datetime.now().isoformat(),
            'maturity_level': 5,
            'summary': {
                'total_categories': len(self.results),
                'categories_passed': sum(1 for cat in self.results.values() if cat.get('passed', 0) == cat.get('total', 1)),
                'categories_total': len(self.results)
            },
            'categories': self.results,
            'recommendations': self.generate_recommendations()
        }

        # Guardar reporte JSON
        report_file = self.reports_dir / f"maturity5_test_report_{int(time.time())}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)

        # Generar reporte de texto
        text_report = self.generate_text_report(report)
        text_file = self.reports_dir / f"maturity5_test_report_{int(time.time())}.txt"
        with open(text_file, 'w') as f:
            f.write(text_report)

        logger.info(f"✅ Reportes generados: {report_file}, {text_file}")

    def generate_text_report(self, report: Dict[str, Any]) -> str:
        """Generar reporte en formato texto."""
        lines = []
        lines.append("=" * 80)
        lines.append("REPORTE DE TESTS - MATURITY LEVEL 5")
        lines.append("=" * 80)
        lines.append(f"Fecha: {report['timestamp']}")
        lines.append("")

        summary = report['summary']
        lines.append("RESUMEN GENERAL:")
        lines.append(f"  Categorías totales: {summary['categories_total']}")
        lines.append(f"  Categorías exitosas: {summary['categories_passed']}")
        lines.append("")

        lines.append("DETALLE POR CATEGORÍA:")
        for category, data in report['categories'].items():
            lines.append(f"  {category.upper()}:")
            lines.append(f"    Tests exitosos: {data.get('passed', 0)}")
            lines.append(f"    Tests totales: {data.get('total', 0)}")
            lines.append("")

        lines.append("RECOMENDACIONES:")
        for rec in report.get('recommendations', []):
            lines.append(f"  • {rec}")
        lines.append("")

        lines.append("=" * 80)
        return "\n".join(lines)

    def generate_recommendations(self) -> List[str]:
        """Generar recomendaciones basadas en resultados."""
        recommendations = []

        for category, data in self.results.items():
            passed = data.get('passed', 0)
            total = data.get('total', 0)

            if total > 0 and passed < total:
                if category == 'security':
                    recommendations.append("Revisar y mejorar las medidas de seguridad")
                elif category == 'compliance':
                    recommendations.append("Asegurar cumplimiento con regulaciones (GDPR, HIPAA, etc.)")
                elif category == 'docker':
                    recommendations.append("Optimizar configuración de Docker y contenedores")
                elif category == 'cicd':
                    recommendations.append("Mejorar procesos de CI/CD y automatización")
                elif category == 'ai_mlops':
                    recommendations.append("Revisar implementación de modelos de IA y MLOps")
                elif category == 'federated':
                    recommendations.append("Mejorar estabilidad del federated learning")
                elif category == 'verification':
                    recommendations.append("Reforzar verificación con pruebas de conocimiento cero")

        if not recommendations:
            recommendations.append("Todos los tests pasaron exitosamente - excelente cobertura de Maturity Level 5")

        return recommendations

    def validate_all_tests_passed(self) -> bool:
        """Validar que todos los tests pasaron."""
        for category, data in self.results.items():
            passed = data.get('passed', 0)
            total = data.get('total', 0)
            if total > 0 and passed != total:
                logger.error(f"❌ Categoría {category} falló: {passed}/{total} tests pasaron")
                return False

        logger.info("✅ Todos los tests de Maturity Level 5 pasaron exitosamente")
        return True

async def main():
    """Función principal."""
    runner = Maturity5TestRunner()
    success = await runner.run_all_tests()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    asyncio.run(main())