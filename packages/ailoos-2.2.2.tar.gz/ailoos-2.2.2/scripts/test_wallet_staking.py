#!/usr/bin/env python3
"""
Test Script for Wallet and Staking System
Prueba completa del sistema de wallets y staking DRACMA
"""

import asyncio
import sys
import os
from pathlib import Path

# Asegurar que podemos importar módulos de AILOOS
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.ailoos.blockchain.wallet_manager import get_wallet_manager
from src.ailoos.blockchain.staking_manager import get_staking_manager
from src.ailoos.core.logging import get_logger

logger = get_logger(__name__)


async def test_wallet_creation():
    """Prueba creación de wallets."""
    print("\n🔑 Probando creación de wallets...")

    wallet_manager = get_wallet_manager()

    # Crear wallet para usuario 1
    result1 = await wallet_manager.create_wallet("user_alice", "main")
    if result1['success']:
        print(f"✅ Wallet creada para Alice: {result1['address'][:20]}...")
    else:
        print(f"❌ Error creando wallet Alice: {result1['error']}")
        return False

    # Crear wallet para usuario 2
    result2 = await wallet_manager.create_wallet("user_bob", "main")
    if result2['success']:
        print(f"✅ Wallet creada para Bob: {result2['address'][:20]}...")
    else:
        print(f"❌ Error creando wallet Bob: {result2['error']}")
        return False

    return result1['wallet_id'], result2['wallet_id']


async def test_staking(wallet_id_alice):
    """Prueba sistema de staking."""
    print("\n🔒 Probando sistema de staking...")

    staking_manager = get_staking_manager()

    # Stakear tokens
    result = await staking_manager.stake_tokens(wallet_id_alice, 1000.0, lock_period_days=30, auto_compound=True)
    if result['success']:
        print(f"✅ Staked 1000 DRACMA - APR: {result['apr']:.1%}, Tier: {result['tier']}")
        return result['stake_id']
    else:
        print(f"❌ Error staking: {result['error']}")
        return None


async def test_transfers(wallet_id_alice, wallet_id_bob):
    """Prueba transferencias entre wallets."""
    print("\n💸 Probando transferencias...")

    wallet_manager = get_wallet_manager()

    # Obtener balance inicial de Alice
    balance_alice = await wallet_manager.get_wallet_balance(wallet_id_alice)
    print(f"Balance inicial Alice: {balance_alice.get('total_balance', 0):.2f} DRACMA")

    # Transferir 500 DRACMA de Alice a Bob
    result = await wallet_manager.transfer(wallet_id_alice, "user_bob_main", 500.0, "Test transfer")
    if result['success']:
        print("✅ Transferencia exitosa de 500 DRACMA")
    else:
        print(f"❌ Error en transferencia: {result['error']}")
        return False

    # Verificar balances después de transferencia
    balance_alice_after = await wallet_manager.get_wallet_balance(wallet_id_alice)
    balance_bob_after = await wallet_manager.get_wallet_balance(wallet_id_bob)

    print(f"Balance Alice después: {balance_alice_after.get('total_balance', 0):.2f} DRACMA")
    print(f"Balance Bob después: {balance_bob_after.get('total_balance', 0):.2f} DRACMA")

    return True


async def test_governance(wallet_id_alice):
    """Prueba sistema de gobernanza."""
    print("\n🗳️ Probando gobernanza...")

    staking_manager = get_staking_manager()

    # Crear propuesta
    proposal_result = await staking_manager.create_proposal(
        wallet_id_alice,
        "Increase Base APR",
        "Proposal to increase base staking APR from 5% to 6%",
        {"base_apr": 0.06}
    )

    if proposal_result['success']:
        proposal_id = proposal_result['proposal_id']
        print(f"✅ Propuesta creada: {proposal_id}")

        # Votar en la propuesta
        vote_result = await staking_manager.vote_on_proposal(wallet_id_alice, proposal_id, True, "Good for ecosystem")
        if vote_result['success']:
            print("✅ Voto emitido a favor de la propuesta")
        else:
            print(f"❌ Error votando: {vote_result['error']}")

        return proposal_id
    else:
        print(f"❌ Error creando propuesta: {proposal_result['error']}")
        return None


async def test_rewards_distribution():
    """Prueba distribución de rewards."""
    print("\n💰 Probando distribución de rewards...")

    staking_manager = get_staking_manager()

    # Esperar un poco para que se distribuyan rewards
    print("Esperando distribución de rewards (5 segundos)...")
    await asyncio.sleep(5)

    # Obtener estadísticas de staking
    stats = staking_manager.get_staking_stats()
    print(f"Total staked: {stats['total_staked']:.2f} DRACMA")
    print(f"Total stakers: {stats['total_stakers']}")
    print(f"Active positions: {stats['active_positions']}")

    return True


async def show_final_stats(wallet_id_alice, wallet_id_bob):
    """Mostrar estadísticas finales."""
    print("\n📊 Estadísticas finales:")

    wallet_manager = get_wallet_manager()
    staking_manager = get_staking_manager()

    # Balances finales
    alice_balance = await wallet_manager.get_wallet_balance(wallet_id_alice)
    bob_balance = await wallet_manager.get_wallet_balance(wallet_id_bob)

    print(f"Alice balance: {alice_balance.get('total_balance', 0):.2f} DRACMA")
    print(f"Bob balance: {bob_balance.get('total_balance', 0):.2f} DRACMA")

    # Info de staking de Alice
    alice_staking = staking_manager.get_staking_info(wallet_id_alice)
    print(f"Alice staked: {alice_staking.get('total_staked', 0):.2f} DRACMA")
    print(f"Alice rewards: {alice_staking.get('total_rewards', 0):.2f} DRACMA")

    # Historial de transacciones
    alice_txs = wallet_manager.get_transaction_history(wallet_id_alice, limit=5)
    print(f"Alice transactions: {len(alice_txs)}")

    # Propuestas activas
    proposals = staking_manager.get_proposals()
    print(f"Active proposals: {len(proposals)}")


async def main():
    """Función principal de pruebas."""
    print("🚀 Iniciando pruebas del sistema Wallet & Staking DRACMA")
    print("=" * 60)

    try:
        # 1. Crear wallets
        wallet_ids = await test_wallet_creation()
        if not wallet_ids:
            print("❌ Falló creación de wallets")
            return

        wallet_id_alice, wallet_id_bob = wallet_ids

        # 2. Probar staking
        stake_id = await test_staking(wallet_id_alice)
        if not stake_id:
            print("❌ Falló staking")
            return

        # 3. Probar transferencias
        transfer_success = await test_transfers(wallet_id_alice, wallet_id_bob)
        if not transfer_success:
            print("❌ Fallaron transferencias")
            return

        # 4. Probar gobernanza
        proposal_id = await test_governance(wallet_id_alice)

        # 5. Probar rewards
        await test_rewards_distribution()

        # 6. Mostrar estadísticas finales
        await show_final_stats(wallet_id_alice, wallet_id_bob)

        print("\n🎉 Todas las pruebas completadas exitosamente!")
        print("=" * 60)

    except Exception as e:
        print(f"❌ Error durante las pruebas: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Ejecutar pruebas
    asyncio.run(main())