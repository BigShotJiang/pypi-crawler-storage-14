#!/bin/bash

# Script para configurar credenciales en Vercel para AILOOS
# Este script genera secrets seguros y proporciona instrucciones para configurar variables de entorno

set -e

echo "=== Configuración de Credenciales para Vercel - AILOOS ==="
echo ""

# 1. Generar AUTH_SECRET
echo "1. Generando AUTH_SECRET (32 bytes en base64)..."
AUTH_SECRET=$(openssl rand -base64 32)
echo "AUTH_SECRET generado: $AUTH_SECRET"
echo ""

# 2. Instrucciones para DATABASE_URL
echo "2. DATABASE_URL - URL de conexión a PostgreSQL de Google Cloud SQL"
echo "Para obtener la DATABASE_URL completa:"
echo ""
echo "Opción 1 - Desde Terraform outputs (recomendado):"
echo "  cd infrastructure/gcp/terraform"
echo "  terraform output db_password"
echo "  terraform output database_connection_name"
echo ""
echo "Construye la URL:"
echo "  postgresql://ailoos_user:[PASSWORD]@/ailoos?host=/cloudsql/[CONNECTION_NAME]"
echo ""
echo "Opción 2 - Desde Google Cloud Console:"
echo "  - Ve a Google Cloud Console > SQL > Instancias"
echo "  - Selecciona la instancia 'ailoos-database'"
echo "  - Ve a la pestaña 'Conexiones'"
echo "  - Copia la cadena de conexión PostgreSQL"
echo "  - Formato: postgresql://ailoos_user:PASSWORD@HOST/ailoos?host=/cloudsql/PROJECT:REGION:INSTANCE"
echo ""
echo "Nota: Asegúrate de que la instancia de Cloud SQL esté corriendo y accesible desde Vercel."
echo ""

# 3. Instrucciones para BLOB_READ_WRITE_TOKEN
echo "3. BLOB_READ_WRITE_TOKEN - Token de Vercel Blob Storage"
echo "Para obtener el token:"
echo "  - Ve a Vercel Dashboard > Storage > Blob"
echo "  - Crea un nuevo store si no existe"
echo "  - Ve a Settings > Tokens"
echo "  - Genera un nuevo token con permisos de read/write"
echo ""

# 4. Instrucciones para AI_GATEWAY_API_KEY
echo "4. AI_GATEWAY_API_KEY - API key para el servicio de IA"
echo "Para obtener la API key:"
echo "  - Si usas OpenAI: Ve a https://platform.openai.com/api-keys"
echo "  - Crea una nueva API key"
echo "  - Si usas otro proveedor (Anthropic, etc.), obtén la key correspondiente"
echo ""

# 5. Variables adicionales para producción
echo "5. Variables de entorno adicionales necesarias para producción:"
echo ""
echo "GCP_PROJECT_ID: $(echo 'Obtén del Google Cloud Console > Project ID')"
echo "GCP_SA_KEY: $(echo 'Ve a IAM > Service Accounts > Crea/usa ailoos-coordinator > Keys > JSON key')"
echo "REDIS_URL: redis://HOST:PORT (de Cloud Memorystore)"
echo "STORAGE_BUCKET: gs://BUCKET_NAME (de Cloud Storage)"
echo "ENVIRONMENT: production"
echo "DOMAIN: ailoos.com (o tu dominio personalizado)"
echo ""

# 6. Instrucciones para configurar en Vercel
echo "6. Configuración en Vercel Dashboard:"
echo ""
echo "Ve a tu proyecto en Vercel > Settings > Environment Variables"
echo ""
echo "Agrega las siguientes variables:"
echo ""
echo "AUTH_SECRET: $AUTH_SECRET"
echo "DATABASE_URL: [Pega la URL de Cloud SQL]"
echo "BLOB_READ_WRITE_TOKEN: [Pega el token de Vercel Blob]"
echo "AI_GATEWAY_API_KEY: [Pega tu API key de IA]"
echo "GCP_PROJECT_ID: [Tu Project ID de GCP]"
echo "GCP_SA_KEY: [Contenido del JSON de la service account key]"
echo "REDIS_URL: [URL de Redis de Cloud Memorystore]"
echo "STORAGE_BUCKET: [Nombre del bucket de Cloud Storage]"
echo "ENVIRONMENT: production"
echo "DOMAIN: ailoos.com"
echo ""

# 7. Verificación
echo "7. Verificación de credenciales:"
echo ""
echo "Después de configurar todas las variables, ejecuta el script de verificación:"
echo ""
echo "./scripts/verify_vercel_env.sh"
echo ""
echo "O manualmente con: vercel env ls"
echo ""
echo "Desde el dashboard: Proyecto > Settings > Environment Variables"
echo ""

echo "=== Script completado ==="
echo "Copia los valores generados y sigue las instrucciones para configurar Vercel."