#!/usr/bin/env python3
"""
AILOOS Complete Pipeline Demo
Demostración funcional del flujo completo: Datos → IPFS → Sanitización → Sharding → Marketplace → Training
"""

import asyncio
import os
import tempfile
import json
from pathlib import Path
import time

# Asegurar que podemos importar módulos de AILOOS
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from src.ailoos.sdk.advanced_client import create_ailoos_node
from src.ailoos.data.ipfs_connector import ipfs_connector
from src.ailoos.privacy.pii_scrubber import pii_scrubber
from src.ailoos.data.dataset_manager import dataset_manager
from src.ailoos.coordinator.registry import data_registry


class PipelineDemo:
    """
    Demo completa del pipeline de AILOOS.
    Muestra el flujo desde datos crudos hasta entrenamiento distribuido.
    """

    def __init__(self):
        self.node = None
        self.demo_data = []
        self.temp_files = []

    async def setup_demo_node(self):
        """Configura un nodo para la demo."""
        print("🤖 Inicializando nodo demo...")
        self.node = await create_ailoos_node(
            node_id="demo_pipeline_node",
            workspace_path="./demo_workspace"
        )
        print("✅ Nodo demo listo\n")

    def create_sample_dataset(self):
        """Crea un dataset de ejemplo con datos realistas."""
        print("📝 Creando dataset de ejemplo...")

        # Datos de ejemplo con PII para demostrar sanitización
        sample_records = [
            {
                "id": 1,
                "name": "Usuario Demo 1",
                "email": "demo1@example.com",
                "phone": "+34 611 222 333",
                "address": "Calle Ejemplo 45, Ciudad Demo",
                "occupation": "Ingeniera de Software",
                "salary": 75000,
                "credit_card": "4532 1234 5678 9012",
                "ssn": "111-22-3333",
                "bio": "Apasionada por la IA y el aprendizaje automático. Experiencia en procesamiento de lenguaje natural."
            },
            {
                "id": 2,
                "name": "Usuario Demo 2",
                "email": "demo2@example.com",
                "phone": "+34 622 444 555",
                "address": "Plaza Ejemplo 12, Ciudad Demo",
                "occupation": "Data Scientist",
                "salary": 68000,
                "credit_card": "4111 1111 1111 1111",
                "ssn": "222-33-4444",
                "bio": "Especialista en visión computacional y deep learning. Ha trabajado en proyectos de reconocimiento facial."
            },
            {
                "id": 3,
                "name": "Usuario Demo 3",
                "email": "demo3@example.com",
                "phone": "+34 633 666 777",
                "address": "Avenida Ejemplo 200, Ciudad Demo",
                "occupation": "Profesora Universitaria",
                "salary": 55000,
                "credit_card": "5555 5555 5555 4444",
                "ssn": "333-44-5555",
                "bio": "Investigadora en ética de la IA y aprendizaje federado. Autora de varios papers sobre privacidad en ML."
            }
        ]

        # Guardar como JSON
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(sample_records, f, indent=2, ensure_ascii=False)
            dataset_file = f.name
            self.temp_files.append(dataset_file)

        print(f"✅ Dataset creado: {len(sample_records)} registros en {dataset_file}")
        return dataset_file

    def create_sample_text_file(self):
        """Crea un archivo de texto de ejemplo."""
        print("📄 Creando archivo de texto de ejemplo...")

        sample_text = """
        En el mundo de la inteligencia artificial, la privacidad de los datos es fundamental.

        Mi nombre es Usuario Demo y mi correo electrónico es demo@example.com.
        Trabajo como desarrollador en TechCorp y mi número de teléfono es +1 111-222-3333.

        Recientemente, he estado investigando sobre aprendizaje federado y blockchain.
        Mi dirección es 123 Main Street, Anytown, USA 12345.

        Algunos números importantes:
        - Mi número de seguridad social es 111-22-3333
        - Mi tarjeta de crédito es 4111 1111 1111 1111
        - Mi IPFS hash favorito es QmYwAPJzv5CZsnAzt7H4g7RnR5vWRTCqWbJWdtXrRqyMq

        El futuro de la IA distribuida es prometedor, especialmente cuando combinamos
        técnicas de privacidad como el aprendizaje federado con sistemas de tokens
        incentivados como DRACMA.

        Contacto: soporte@ailoos.ai
        Teléfono de soporte: 1-800-AILOOS
        """

        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(sample_text)
            text_file = f.name
            self.temp_files.append(text_file)

        print(f"✅ Archivo de texto creado: {text_file}")
        return text_file

    async def demonstrate_pii_scrubbing(self):
        """Demuestra la sanitización PII."""
        print("\n🛡️ DEMO: Sanitización PII")
        print("-" * 40)

        # Texto con PII
        dirty_text = """
        Hola, soy Pedro Martínez. Mi email es pedro.martinez@gmail.com
        y mi teléfono es +34 666 777 888. Vivo en Calle Falsa 123, Madrid.
        Mi DNI es 12345678Z y mi tarjeta es 4000 1234 5678 9010.
        """

        print("📝 Texto original:")
        print(dirty_text)

        # Sanitizar
        clean_text = pii_scrubber.scrub_text(dirty_text)

        print("\n🧹 Texto sanitizado:")
        print(clean_text)

        # Mostrar estadísticas
        stats = pii_scrubber.get_stats()
        print(f"\n📊 Estadísticas: {stats['pii_found']} instancias PII removidas")

        print("✅ PII scrubbing completado\n")

    async def demonstrate_ipfs_operations(self):
        """Demuestra operaciones IPFS."""
        print("📡 DEMO: Operaciones IPFS")
        print("-" * 40)

        # Datos de prueba
        test_data = {
            "message": "Hola desde AILOOS Pipeline Demo",
            "timestamp": time.time(),
            "node_id": "demo_node",
            "data_type": "pipeline_demo"
        }

        print("📤 Subiendo datos a IPFS...")
        try:
            cid = ipfs_connector.add_json(test_data)
            print(f"✅ Datos subidos. CID: {cid}")

            print("⬇️ Descargando datos desde IPFS...")
            downloaded_data = ipfs_connector.get_json(cid)
            print(f"✅ Datos descargados: {downloaded_data['message']}")

            # Verificar integridad
            if downloaded_data == test_data:
                print("✅ Integridad verificada - datos idénticos")
            else:
                print("⚠️  Datos diferentes (posible corrupción)")

        except Exception as e:
            print(f"⚠️  IPFS no disponible localmente: {e}")
            print("   Usando modo gateway público...")

        print("✅ Demo IPFS completada\n")

    async def demonstrate_dataset_processing(self):
        """Demuestra procesamiento completo de dataset."""
        print("🔄 DEMO: Procesamiento de Dataset Completo")
        print("-" * 50)

        # Crear dataset de ejemplo
        dataset_file = self.create_sample_dataset()

        print(f"📦 Procesando dataset: {dataset_file}")

        # Procesar dataset
        start_time = time.time()
        result = await self.node.process_dataset(
            file_path=dataset_file,
            dataset_name="demo_hr_dataset",
            shard_size_mb=1  # Shards pequeños para demo
        )
        processing_time = time.time() - start_time

        print("✅ Dataset procesado exitosamente!")
        print(f"   Nombre: {result['dataset_name']}")
        print(f"   Tamaño original: {result['total_size_mb']:.2f} MB")
        print(f"   Shards creados: {result['num_shards']}")
        print(".2f")

        # Mostrar información del registro
        dataset_info = data_registry.get_dataset_info(result['dataset_name'])
        if dataset_info:
            print(f"   Registrado en red: ✅")
            print(f"   CIDs generados: {len(dataset_info['shard_cids'])}")
            print(f"   Calidad: {dataset_info['quality_score']:.2f}/1.0")

        print("✅ Procesamiento de dataset completado\n")

    async def demonstrate_text_processing(self):
        """Demuestra procesamiento de archivo de texto."""
        print("📄 DEMO: Procesamiento de Texto")
        print("-" * 40)

        # Crear archivo de texto
        text_file = self.create_sample_text_file()

        print(f"📝 Procesando archivo de texto: {text_file}")

        # Procesar archivo
        start_time = time.time()
        result = await self.node.process_dataset(
            file_path=text_file,
            dataset_name="demo_text_corpus",
            shard_size_mb=0.5  # Shards muy pequeños para demo
        )
        processing_time = time.time() - start_time

        print("✅ Archivo de texto procesado!")
        print(f"   Dataset: {result['dataset_name']}")
        print(f"   Shards: {result['num_shards']}")
        print(".2f")

        print("✅ Procesamiento de texto completado\n")

    async def demonstrate_marketplace_operations(self):
        """Demuestra operaciones del marketplace."""
        print("🛒 DEMO: Operaciones del Marketplace")
        print("-" * 45)

        # Buscar datasets disponibles
        print("🔍 Buscando datasets en el marketplace...")
        datasets = await self.node.search_datasets(limit=5)

        print(f"📋 Encontrados {len(datasets)} datasets:")
        for i, ds in enumerate(datasets[:3], 1):  # Mostrar máximo 3
            print(f"   {i}. {ds.get('dataset_name', 'N/A')} (Calidad: {ds.get('quality_score', 0):.2f})")

        # Intentar listar un dataset para venta
        if datasets:
            print("\n💰 Listando dataset para venta...")
            try:
                listing_result = await self.node.list_dataset_for_sale(
                    dataset_name="demo_hr_dataset",
                    price_dracma=100.0,
                    description="Dataset de ejemplo con información de empleados (PII removida)"
                )

                if listing_result.get('success'):
                    print("✅ Dataset listado exitosamente!")
                    print(f"   ID de listing: {listing_result.get('listing_id')}")
                    print(f"   Precio: {listing_result.get('price_dracma')} DRACMA")
                else:
                    print("⚠️  No se pudo listar el dataset (wallet/marketplace no disponible)")

            except Exception as e:
                print(f"⚠️  Error listando dataset: {e}")

        print("✅ Demo marketplace completada\n")

    async def demonstrate_wallet_operations(self):
        """Demuestra operaciones de wallet."""
        print("💰 DEMO: Operaciones de Wallet")
        print("-" * 35)

        try:
            # Obtener balance
            balance = await self.node.get_wallet_balance()
            print(".2f")

            # Mostrar información de staking
            staking_info = await self.node.get_staking_info()
            print(f"🔒 Tokens staked: {staking_info.get('staked_amount', 0):.2f} DRACMA")
            print(f"💎 Rewards disponibles: {staking_info.get('rewards_amount', 0):.2f} DRACMA")

            # Intentar staking si hay balance
            if balance > 5:
                print("\n🔒 Intentando staking...")
                stake_result = await self.node.stake_tokens(min(5, balance))
                if stake_result.get('success'):
                    print("✅ Staking exitoso!")
                    new_balance = await self.node.get_wallet_balance()
                    print(".2f")
                else:
                    print(f"⚠️  Staking falló: {stake_result.get('error', 'Desconocido')}")
            else:
                print("⚠️  Balance insuficiente para staking demo")

        except Exception as e:
            print(f"⚠️  Error en operaciones de wallet: {e}")
            print("   (Esto es normal si el sistema blockchain no está completamente configurado)")

        print("✅ Demo wallet completada\n")

    async def demonstrate_network_operations(self):
        """Demuestra operaciones de red."""
        print("🌐 DEMO: Operaciones de Red")
        print("-" * 35)

        # Estadísticas de red
        network_stats = data_registry.get_network_stats()
        print("📊 Estadísticas de red:")
        print(f"   Nodos totales: {network_stats.get('total_nodes', 0)}")
        print(f"   Nodos activos: {network_stats.get('active_nodes', 0)}")
        print(f"   Datasets: {network_stats.get('total_datasets', 0)}")
        print(f"   Shards: {network_stats.get('total_shards', 0)}")
        print(f"   Calidad promedio: {network_stats.get('avg_quality_score', 0):.2f}")

        # Información del nodo
        node_stats = self.node.get_node_stats()
        print("\n🤖 Información del nodo:")
        print(f"   ID: {node_stats['node_id']}")
        print(f"   Inicializado: {node_stats['initialized']}")
        print(f"   Datasets procesados: {node_stats['stats']['datasets_processed']}")

        print("✅ Demo de red completada\n")

    def show_pipeline_summary(self):
        """Muestra resumen del pipeline completo."""
        print("🎉 DEMO COMPLETA DEL PIPELINE AILOOS")
        print("=" * 50)
        print("✅ PII Scrubbing - Datos sanitizados")
        print("✅ IPFS Operations - Almacenamiento distribuido")
        print("✅ Dataset Processing - Archivos fragmentados")
        print("✅ Text Processing - Contenido procesado")
        print("✅ Marketplace - Datasets listados para venta")
        print("✅ Wallet Operations - Tokens gestionados")
        print("✅ Network Registry - Información compartida")
        print("=" * 50)
        print("🚀 ¡El pipeline completo de AILOOS está funcionando!")
        print("   Datos → Privacidad → Distribución → Mercado → Entrenamiento")
        print("=" * 50)

    def cleanup(self):
        """Limpia recursos de la demo."""
        print("\n🧹 Limpiando recursos de demo...")

        # Limpiar archivos temporales
        for file_path in self.temp_files:
            try:
                if os.path.exists(file_path):
                    os.unlink(file_path)
                    print(f"   🗑️  Eliminado: {file_path}")
            except Exception as e:
                print(f"   ⚠️  Error eliminando {file_path}: {e}")

        # Limpiar nodo
        if self.node:
            self.node.cleanup()
            print("   🤖 Nodo demo limpiado")

        print("✅ Limpieza completada\n")

    async def run_complete_demo(self):
        """Ejecuta la demo completa del pipeline."""
        print("🚀 AILOOS Complete Pipeline Demo")
        print("Demostrando el flujo completo: Datos → IPFS → Sanitización → Sharding → Marketplace")
        print("=" * 80)

        try:
            # Setup
            await self.setup_demo_node()

            # Demostraciones paso a paso
            await self.demonstrate_pii_scrubbing()
            await self.demonstrate_ipfs_operations()
            await self.demonstrate_dataset_processing()
            await self.demonstrate_text_processing()
            await self.demonstrate_marketplace_operations()
            await self.demonstrate_wallet_operations()
            await self.demonstrate_network_operations()

            # Resumen final
            self.show_pipeline_summary()

        except KeyboardInterrupt:
            print("\n❌ Demo interrumpida por usuario")
        except Exception as e:
            print(f"\n❌ Error en demo: {e}")
            import traceback
            traceback.print_exc()
        finally:
            self.cleanup()


async def main():
    """Función principal."""
    demo = PipelineDemo()
    await demo.run_complete_demo()


if __name__ == "__main__":
    asyncio.run(main())