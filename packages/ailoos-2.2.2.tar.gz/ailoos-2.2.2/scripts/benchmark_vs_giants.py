#!/usr/bin/env python3
"""
Benchmark EmpoorioLM vs GPT-4/Claude/Gemini
Compara rendimiento en precisión, latencia y consumo energético.
"""

import os
import sys
import time
import json
import logging
import argparse
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from pathlib import Path
import statistics
import psutil
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

# Añadir src al path para importar EmpoorioLM
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Imports de datasets
try:
    from benchmark_datasets import BenchmarkDatasetLoader, MMLULoader, GSM8kLoader
except ImportError:
    # Si no está disponible, intentar import desde el directorio actual
    import sys
    import os
    current_dir = os.path.dirname(os.path.abspath(__file__))
    if current_dir not in sys.path:
        sys.path.insert(0, current_dir)
    from benchmark_datasets import BenchmarkDatasetLoader, MMLULoader, GSM8kLoader

# Imports de modelos
try:
    from ailoos.api.empoorio_api import EmpoorioLMApi, EmpoorioLMApiConfig, GenerationConfig
    EMPOORIO_AVAILABLE = True
except ImportError:
    EMPOORIO_AVAILABLE = False
    print("⚠️ EmpoorioLM no disponible, usando mock")

# Import del latency tester
try:
    from ailoos.benchmarking.latency_tester import LatencyTester, LatencyTestConfig, LATENCY_BASELINES
    LATENCY_TESTER_AVAILABLE = True
except ImportError:
    LATENCY_TESTER_AVAILABLE = False
    print("⚠️ LatencyTester no disponible")

# Import del RAG needle evaluator
try:
    from ailoos.benchmarking.rag_needle_evaluator import RagNeedleEvaluator, RagNeedleConfig
    RAG_NEEDLE_AVAILABLE = True
except ImportError:
    RAG_NEEDLE_AVAILABLE = False
    print("⚠️ RagNeedleEvaluator no disponible")

# Import del framework de comparación de precisión
try:
    from ailoos.benchmarking.accuracy_comparison_framework import AccuracyComparisonFramework, AccuracyComparisonConfig
    ACCURACY_FRAMEWORK_AVAILABLE = True
except ImportError:
    ACCURACY_FRAMEWORK_AVAILABLE = False
    print("⚠️ AccuracyComparisonFramework no disponible")

# Import del módulo de benchmarks de edge móvil
try:
    from ailoos.benchmarking.mobile_edge_benchmarks import (
        MobileEdgeBenchmarkRunner, MobileEdgeBenchmarkConfig,
        run_mobile_vs_cloud_comparison, integrate_with_benchmark_vs_giants
    )
    MOBILE_EDGE_AVAILABLE = True
except ImportError:
    MOBILE_EDGE_AVAILABLE = False
    print("⚠️ MobileEdgeBenchmarks no disponible")

# Imports de APIs externas
try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    print("⚠️ OpenAI no disponible")

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False
    print("⚠️ Anthropic no disponible")

try:
    import google.generativeai as genai
    GOOGLE_AVAILABLE = True
except ImportError:
    GOOGLE_AVAILABLE = False
    print("⚠️ Google Generative AI no disponible")

# Para gráficos
try:
    import matplotlib.pyplot as plt
    import pandas as pd
    PLOTTING_AVAILABLE = True
except ImportError:
    PLOTTING_AVAILABLE = False
    print("⚠️ Matplotlib/Pandas no disponibles, gráficos deshabilitados")

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('benchmark_vs_giants.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class BenchmarkConfig:
    """Configuración del benchmark."""
    models_to_test: List[str] = field(default_factory=lambda: ['empoorio', 'gpt4', 'claude', 'gemini'])
    datasets: List[str] = field(default_factory=lambda: ['mmlu', 'gsm8k'])
    num_samples: int = 100
    max_tokens: int = 512
    temperature: float = 0.7
    output_dir: str = './benchmark_results'
    api_keys: Dict[str, str] = field(default_factory=dict)
    empoorio_config: Dict[str, Any] = field(default_factory=dict)
    use_baselines: bool = True
    baseline_file: str = './benchmark_baselines.json'
    model_sizes: Dict[str, str] = field(default_factory=lambda: {
        'empoorio': '7B',  # Tamaño configurable
        'gpt4': 'gpt-4',
        'claude': 'claude-3-opus',
        'gemini': 'gemini-pro'
    })
    retry_attempts: int = 3
    timeout_seconds: int = 60

    # Configuración de pruebas de latencia detalladas
    enable_latency_testing: bool = False
    latency_context_sizes: List[int] = field(default_factory=lambda: [512, 1024, 2048])
    latency_batch_sizes: List[int] = field(default_factory=lambda: [1])
    latency_num_requests: int = 50
    latency_output_dir: str = './latency_results'
    latency_enable_streaming: bool = True

    # Configuración de evaluación RAG Needle-in-Haystack
    enable_rag_needle_evaluation: bool = False
    rag_needle_context_sizes: List[int] = field(default_factory=lambda: [1024, 4096, 8192, 16384, 32768])
    rag_needle_num_tasks_per_size: int = 10
    rag_needle_output_dir: str = './rag_needle_results'

    # Configuración de benchmarks de edge móvil
    enable_mobile_edge_benchmarks: bool = False
    mobile_edge_devices: List[str] = field(default_factory=lambda: ['pixel_7', 'iphone_14'])
    mobile_edge_model_sizes: Dict[str, float] = field(default_factory=lambda: {
        'empoorio': 100.0,  # MB
        'gpt4': 0.0,  # No aplicable para nube
        'claude': 0.0,
        'gemini': 0.0
    })
    mobile_edge_output_dir: str = './mobile_edge_results'


# Baselines predefinidas (basadas en benchmarks públicos)
BASELINE_PERFORMANCE = {
    'mmlu': {
        'gpt4': {'accuracy': 0.87, 'latency': 2.1, 'energy_joules': 15.2},
        'claude': {'accuracy': 0.86, 'latency': 1.8, 'energy_joules': 12.8},
        'gemini': {'accuracy': 0.83, 'latency': 1.5, 'energy_joules': 10.5},
        'empoorio': {'accuracy': 0.75, 'latency': 0.8, 'energy_joules': 8.2}  # Estimación
    },
    'gsm8k': {
        'gpt4': {'accuracy': 0.92, 'latency': 3.2, 'energy_joules': 18.5},
        'claude': {'accuracy': 0.95, 'latency': 2.8, 'energy_joules': 16.2},
        'gemini': {'accuracy': 0.89, 'latency': 2.1, 'energy_joules': 13.8},
        'empoorio': {'accuracy': 0.82, 'latency': 1.2, 'energy_joules': 9.8}  # Estimación
    }
}


@dataclass
class PerformanceMetrics:
    """Métricas de rendimiento."""
    model_name: str
    dataset: str
    accuracy: float = 0.0
    avg_latency: float = 0.0
    p95_latency: float = 0.0
    total_energy: float = 0.0  # En Joules (estimado)
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    throughput: float = 0.0  # tokens/segundo
    total_requests: int = 0
    successful_requests: int = 0
    errors: List[str] = field(default_factory=list)


class EnergyMonitor:
    """Monitor de consumo energético."""

    def __init__(self):
        self.process = psutil.Process()
        self.start_time = None
        self.start_cpu = None
        self.start_memory = None

    def start_monitoring(self):
        """Inicia monitoreo."""
        self.start_time = time.time()
        self.start_cpu = self.process.cpu_percent(interval=None)
        self.start_memory = self.process.memory_info().rss / 1024 / 1024  # MB

    def stop_monitoring(self) -> Dict[str, float]:
        """Detiene monitoreo y retorna métricas."""
        end_time = time.time()
        duration = end_time - self.start_time

        end_cpu = self.process.cpu_percent(interval=None)
        end_memory = self.process.memory_info().rss / 1024 / 1024

        # Estimación simple de energía (CPU time * factor de conversión)
        cpu_time = duration * (end_cpu / 100.0)
        estimated_energy = cpu_time * 65  # Factor aproximado para CPU moderna (65W TDP)

        return {
            'duration': duration,
            'avg_cpu_percent': (self.start_cpu + end_cpu) / 2,
            'avg_memory_mb': (self.start_memory + end_memory) / 2,
            'peak_memory_mb': max(self.start_memory, end_memory),
            'estimated_energy_joules': estimated_energy
        }


class BaseModelWrapper:
    """Wrapper base para modelos."""

    def __init__(self, model_name: str, config: BenchmarkConfig):
        self.model_name = model_name
        self.config = config
        self.energy_monitor = EnergyMonitor()

    def generate(self, prompt: str, **kwargs) -> Tuple[str, Dict[str, Any]]:
        """
        Genera respuesta y retorna métricas con manejo de errores y reintentos.

        Returns:
            Tuple[str, Dict]: (response, metrics)
        """
        max_retries = kwargs.get('max_retries', 3)
        timeout = kwargs.get('timeout', 60)

        for attempt in range(max_retries):
            try:
                # Implementar timeout usando threading
                import threading
                result = [None]
                error = [None]

                def run_generation():
                    try:
                        result[0] = self._generate_impl(prompt, **kwargs)
                    except Exception as e:
                        error[0] = e

                thread = threading.Thread(target=run_generation)
                thread.start()
                thread.join(timeout=timeout)

                if thread.is_alive():
                    thread.join()  # Esperar a que termine
                    raise TimeoutError(f"Generación excedió timeout de {timeout}s")

                if error[0]:
                    raise error[0]

                return result[0]

            except Exception as e:
                logger.warning(f"Intento {attempt + 1}/{max_retries} falló: {e}")
                if attempt == max_retries - 1:
                    # Último intento falló
                    return "", {
                        'latency': timeout,
                        'success': False,
                        'energy_joules': 0,
                        'cpu_percent': 0,
                        'memory_mb': 0,
                        'tokens_generated': 0,
                        'error': str(e)
                    }
                time.sleep(1)  # Esperar antes de reintentar

    def _generate_impl(self, prompt: str, **kwargs) -> Tuple[str, Dict[str, Any]]:
        """
        Implementación específica de generación (debe ser implementada por subclases).
        """
        raise NotImplementedError

    def evaluate_answer(self, question: str, answer: str, correct_answer: str, dataset_type: str = 'general') -> bool:
        """Evalúa si la respuesta es correcta con lógica específica por dataset."""
        if not answer or not correct_answer:
            return False

        def normalize(text: str) -> str:
            return text.lower().strip().replace(' ', '').replace('.', '').replace(',', '')

        if dataset_type == 'mmlu':
            # Para MMLU, buscar la letra de opción correcta en la respuesta
            answer = answer.strip().upper()
            correct_answer = correct_answer.strip().upper()

            # Si la respuesta contiene la letra correcta al inicio
            if answer.startswith(correct_answer):
                return True

            # Buscar patrón "la respuesta es X" o similar
            import re
            patterns = [
                r'la respuesta es\s*([A-D])',
                r'opción\s*([A-D])',
                r'respuesta\s*([A-D])',
                r'^\s*([A-D])\s*[.)]',
                r'^\s*([A-D])\s*$',
                r'\b([A-D])\b',  # Cualquier letra A-D sola
                r'choice\s*([A-D])',
                r'answer\s*([A-D])',
                r'([A-D])\s*is correct',
                r'([A-D])\s*is the answer'
            ]

            for pattern in patterns:
                match = re.search(pattern, answer, re.IGNORECASE)
                if match and match.group(1).upper() == correct_answer:
                    return True

            # Si no encuentra patrón específico, buscar la primera letra A-D en la respuesta
            first_letter = re.search(r'\b([A-D])\b', answer)
            if first_letter and first_letter.group(1).upper() == correct_answer:
                return True

            return False

        elif dataset_type == 'gsm8k':
            # Para GSM8k, extraer números y comparar
            def extract_number(text: str) -> float:
                # Buscar el último número en el texto
                import re
                numbers = re.findall(r'-?\d+\.?\d*', text.replace(',', ''))
                return float(numbers[-1]) if numbers else 0.0

            try:
                answer_num = extract_number(answer)
                correct_num = extract_number(correct_answer)
                # Tolerancia para errores de redondeo
                return abs(answer_num - correct_num) < 0.01
            except:
                # Fallback a comparación de texto normalizada
                return normalize(answer) == normalize(correct_answer)

        else:
            # Comparación general normalizada
            return normalize(answer) == normalize(correct_answer)


class EmpoorioWrapper(BaseModelWrapper):
    """Wrapper para EmpoorioLM (versión mock para desarrollo)."""

    def __init__(self, config: BenchmarkConfig):
        super().__init__('EmpoorioLM', config)
        logger.info("Usando EmpoorioLM mock (desarrollo)")

    def generate(self, prompt: str, **kwargs) -> Tuple[str, Dict[str, Any]]:
        """Genera con EmpoorioLM (mock)."""
        self.energy_monitor.start_monitoring()
        start_time = time.time()

        # Simular latencia de procesamiento
        time.sleep(0.1)  # 100ms de latencia simulada

        # Generar respuesta mock inteligente
        response = self._generate_mock_response(prompt, kwargs.get('dataset_type', 'general'))

        end_time = time.time()
        latency = end_time - start_time

        energy_metrics = self.energy_monitor.stop_monitoring()

        metrics = {
            'latency': latency,
            'success': True,
            'energy_joules': energy_metrics['estimated_energy_joules'],
            'cpu_percent': energy_metrics['avg_cpu_percent'],
            'memory_mb': energy_metrics['avg_memory_mb'],
            'tokens_generated': len(response.split()) if response else 0
        }

        return response, metrics

    def _generate_mock_response(self, prompt: str, dataset_type: str) -> str:
        """Genera respuesta mock inteligente."""
        if dataset_type == 'mmlu':
            # Para MMLU, devolver una letra aleatoria pero consistente
            import random
            # Hacerlo determinista basado en el hash del prompt
            random.seed(hash(prompt) % 1000)
            answer = random.choice(['A', 'B', 'C', 'D'])
            return f"La respuesta correcta es {answer}."
        elif dataset_type == 'gsm8k':
            # Para GSM8k, devolver un número
            import random
            random.seed(hash(prompt) % 1000)
            number = random.randint(1, 1000)
            return f"El resultado es {number}."
        else:
            return "Esta es una respuesta de prueba de EmpoorioLM."


class GPT4Wrapper(BaseModelWrapper):
    """Wrapper para GPT-4."""

    def __init__(self, config: BenchmarkConfig):
        super().__init__('GPT-4', config)

        if not OPENAI_AVAILABLE:
            raise RuntimeError("OpenAI no está disponible")

        api_key = config.api_keys.get('openai')
        if not api_key:
            raise ValueError("API key de OpenAI requerida")

        self.client = openai.OpenAI(api_key=api_key)

    def _generate_impl(self, prompt: str, **kwargs) -> Tuple[str, Dict[str, Any]]:
        """Genera con GPT-4."""
        self.energy_monitor.start_monitoring()

        start_time = time.time()
        response = self.client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=kwargs.get('max_tokens', self.config.max_tokens),
            temperature=kwargs.get('temperature', self.config.temperature)
        )
        text = response.choices[0].message.content

        end_time = time.time()
        latency = end_time - start_time

        energy_metrics = self.energy_monitor.stop_monitoring()

        metrics = {
            'latency': latency,
            'success': True,
            'energy_joules': energy_metrics['estimated_energy_joules'],
            'cpu_percent': energy_metrics['avg_cpu_percent'],
            'memory_mb': energy_metrics['avg_memory_mb'],
            'tokens_generated': len(text.split()) if text else 0
        }

        return text, metrics


class ClaudeWrapper(BaseModelWrapper):
    """Wrapper para Claude."""

    def __init__(self, config: BenchmarkConfig):
        super().__init__('Claude', config)

        if not ANTHROPIC_AVAILABLE:
            raise RuntimeError("Anthropic no está disponible")

        api_key = config.api_keys.get('anthropic')
        if not api_key:
            raise ValueError("API key de Anthropic requerida")

        self.client = anthropic.Anthropic(api_key=api_key)

    def _generate_impl(self, prompt: str, **kwargs) -> Tuple[str, Dict[str, Any]]:
        """Genera con Claude."""
        self.energy_monitor.start_monitoring()

        start_time = time.time()
        response = self.client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=kwargs.get('max_tokens', self.config.max_tokens),
            temperature=kwargs.get('temperature', self.config.temperature),
            messages=[{"role": "user", "content": prompt}]
        )
        text = response.content[0].text

        end_time = time.time()
        latency = end_time - start_time

        energy_metrics = self.energy_monitor.stop_monitoring()

        metrics = {
            'latency': latency,
            'success': True,
            'energy_joules': energy_metrics['estimated_energy_joules'],
            'cpu_percent': energy_metrics['avg_cpu_percent'],
            'memory_mb': energy_metrics['avg_memory_mb'],
            'tokens_generated': len(text.split()) if text else 0
        }

        return text, metrics


class GeminiWrapper(BaseModelWrapper):
    """Wrapper para Gemini."""

    def __init__(self, config: BenchmarkConfig):
        super().__init__('Gemini', config)

        if not GOOGLE_AVAILABLE:
            raise RuntimeError("Google Generative AI no está disponible")

        api_key = config.api_keys.get('google')
        if not api_key:
            raise ValueError("API key de Google requerida")

        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-pro')

    def _generate_impl(self, prompt: str, **kwargs) -> Tuple[str, Dict[str, Any]]:
        """Genera con Gemini."""
        self.energy_monitor.start_monitoring()

        start_time = time.time()
        response = self.model.generate_content(
            prompt,
            generation_config=genai.types.GenerationConfig(
                max_output_tokens=kwargs.get('max_tokens', self.config.max_tokens),
                temperature=kwargs.get('temperature', self.config.temperature)
            )
        )
        text = response.text

        end_time = time.time()
        latency = end_time - start_time

        energy_metrics = self.energy_monitor.stop_monitoring()

        metrics = {
            'latency': latency,
            'success': True,
            'energy_joules': energy_metrics['estimated_energy_joules'],
            'cpu_percent': energy_metrics['avg_cpu_percent'],
            'memory_mb': energy_metrics['avg_memory_mb'],
            'tokens_generated': len(text.split()) if text else 0
        }

        return text, metrics


class BenchmarkRunner:
    """Ejecutor principal del benchmark."""

    def __init__(self, config: BenchmarkConfig):
        self.config = config
        self.models = {}
        self.datasets = {}
        self.results = []

        # Crear directorio de salida
        os.makedirs(config.output_dir, exist_ok=True)

        # Inicializar modelos
        self._init_models()

        # Inicializar datasets
        self._init_datasets()

    def _init_models(self):
        """Inicializa los modelos a testear."""
        model_classes = {
            'empoorio': EmpoorioWrapper,
            'gpt4': GPT4Wrapper,
            'claude': ClaudeWrapper,
            'gemini': GeminiWrapper
        }

        for model_name in self.config.models_to_test:
            if model_name in model_classes:
                try:
                    self.models[model_name] = model_classes[model_name](self.config)
                    logger.info(f"✅ Modelo {model_name} inicializado")
                except Exception as e:
                    logger.error(f"❌ Error inicializando {model_name}: {e}")
            else:
                logger.warning(f"⚠️ Modelo {model_name} no reconocido")

    def _init_datasets(self):
        """Inicializa los datasets."""
        dataset_classes = {
            'mmlu': MMLULoader,
            'gsm8k': GSM8kLoader
        }

        loader = BenchmarkDatasetLoader()

        for dataset_name in self.config.datasets:
            if dataset_name in dataset_classes:
                try:
                    dataset_loader = dataset_classes[dataset_name]()
                    result = dataset_loader.run()
                    self.datasets[dataset_name] = result['dataset']
                    logger.info(f"✅ Dataset {dataset_name} cargado: {len(result['dataset'])} muestras")
                except Exception as e:
                    logger.error(f"❌ Error cargando {dataset_name}: {e}")
            else:
                logger.warning(f"⚠️ Dataset {dataset_name} no reconocido")

    def run_benchmark(self) -> List[PerformanceMetrics]:
        """Ejecuta el benchmark completo."""
        logger.info("🚀 Iniciando benchmark completo")

        all_results = []

        for dataset_name, dataset in self.datasets.items():
            logger.info(f"📊 Evaluando dataset: {dataset_name}")

            # Limitar número de muestras
            samples = list(dataset)[:self.config.num_samples]

            for model_name, model in self.models.items():
                logger.info(f"🤖 Probando modelo: {model_name} en {dataset_name}")

                metrics = self._evaluate_model_on_dataset(model, model_name, dataset_name, samples)
                all_results.append(metrics)

                # Log resultados parciales
                logger.info(f"  ✅ Precisión: {metrics.accuracy:.3f}, Latencia: {metrics.avg_latency:.3f}s")

        self.results = all_results
        logger.info("✅ Benchmark completado")
        return all_results

    def run_latency_tests(self) -> Dict[str, Any]:
        """Ejecuta pruebas de latencia detalladas si está habilitado."""
        if not self.config.enable_latency_testing or not LATENCY_TESTER_AVAILABLE:
            logger.info("⏭️ Pruebas de latencia detalladas deshabilitadas o no disponibles")
            return {}

        logger.info("🧪 Iniciando pruebas de latencia detalladas")

        # Crear configuración del latency tester
        latency_config = LatencyTestConfig(
            num_requests=self.config.latency_num_requests,
            context_sizes=self.config.latency_context_sizes,
            batch_sizes=self.config.latency_batch_sizes,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            output_dir=self.config.latency_output_dir,
            enable_streaming=self.config.latency_enable_streaming
        )

        # Crear latency tester
        latency_tester = LatencyTester(latency_config)

        # Ejecutar pruebas para cada modelo disponible
        latency_results = {}
        test_prompts = latency_tester._generate_test_prompts()

        for model_name, model_wrapper in self.models.items():
            try:
                logger.info(f"📊 Ejecutando pruebas de latencia para {model_name}")
                model_results = latency_tester.run_latency_tests(model_wrapper, model_name, test_prompts)
                latency_results.update(model_results)
            except Exception as e:
                logger.error(f"❌ Error en pruebas de latencia para {model_name}: {e}")

        # Generar reportes de latencia
        latency_tester.generate_reports()

        logger.info("✅ Pruebas de latencia detalladas completadas")
        return latency_results

    def run_rag_needle_evaluation(self) -> Dict[str, Any]:
        """Ejecuta evaluación RAG Needle-in-Haystack si está habilitado."""
        if not self.config.enable_rag_needle_evaluation or not RAG_NEEDLE_AVAILABLE:
            logger.info("⏭️ Evaluación RAG Needle-in-Haystack deshabilitada o no disponible")
            return {}

        logger.info("🧪 Iniciando evaluación RAG Needle-in-Haystack")

        # Crear configuración del evaluador RAG
        rag_config = RagNeedleConfig(
            context_sizes=self.config.rag_needle_context_sizes,
            num_tasks_per_size=self.config.rag_needle_num_tasks_per_size,
            output_dir=self.config.rag_needle_output_dir,
            api_keys=self.config.api_keys,
            models_to_test=self.config.models_to_test
        )

        # Crear evaluador RAG
        rag_evaluator = RagNeedleEvaluator(rag_config)

        # Ejecutar evaluación
        rag_results = rag_evaluator.run_evaluation()

        # Generar reportes
        rag_evaluator.generate_reports()

        logger.info("✅ Evaluación RAG Needle-in-Haystack completada")
        return {"results": rag_results, "config": rag_config}

    def run_mobile_edge_benchmarks(self) -> Dict[str, Any]:
        """Ejecuta benchmarks de edge móvil si está habilitado."""
        if not self.config.enable_mobile_edge_benchmarks or not MOBILE_EDGE_AVAILABLE:
            logger.info("⏭️ Benchmarks de edge móvil deshabilitados o no disponibles")
            return {}

        logger.info("📱 Iniciando benchmarks de edge móvil")

        # Crear configuración para mobile edge benchmarks
        mobile_config = MobileEdgeBenchmarkConfig(
            target_devices=self.config.mobile_edge_devices,
            num_requests=self.config.num_samples,
            output_dir=self.config.mobile_edge_output_dir
        )

        # Crear runner de mobile edge
        mobile_runner = MobileEdgeBenchmarkRunner(mobile_config)

        # Ejecutar benchmarks para cada modelo disponible
        mobile_results = {}
        for model_name, model_wrapper in self.models.items():
            try:
                logger.info(f"📱 Ejecutando benchmarks móviles para {model_name}")

                # Obtener tamaño del modelo
                model_size_mb = self.config.mobile_edge_model_sizes.get(model_name, 100.0)

                # Ejecutar benchmarks
                model_results = mobile_runner.run_mobile_edge_benchmarks(
                    model_wrapper, model_name, model_size_mb
                )

                mobile_results[model_name] = model_results

            except Exception as e:
                logger.error(f"❌ Error en benchmarks móviles para {model_name}: {e}")

        # Generar reportes de edge
        mobile_runner.generate_edge_reports()

        logger.info("✅ Benchmarks de edge móvil completados")
        return {"results": mobile_results, "config": mobile_config}

    def _evaluate_model_on_dataset(self, model: BaseModelWrapper, model_name: str,
                                 dataset_name: str, samples: List[Dict]) -> PerformanceMetrics:
        """Evalúa un modelo en un dataset."""
        latencies = []
        energies = []
        correct_answers = 0
        total_requests = len(samples)
        successful_requests = 0
        errors = []

        # Procesar muestras en paralelo para mejor rendimiento
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = []

            for sample in samples:
                future = executor.submit(self._process_sample, model, sample, dataset_name)
                futures.append(future)

            for future in as_completed(futures):
                try:
                    result = future.result()
                    if result['success']:
                        successful_requests += 1
                        latencies.append(result['latency'])
                        energies.append(result['energy'])
                        if result['correct']:
                            correct_answers += 1
                    else:
                        errors.append(result.get('error', 'Unknown error'))
                except Exception as e:
                    errors.append(str(e))

        # Calcular métricas
        accuracy = correct_answers / successful_requests if successful_requests > 0 else 0
        avg_latency = statistics.mean(latencies) if latencies else 0
        p95_latency = statistics.quantiles(latencies, n=20)[18] if len(latencies) >= 20 else max(latencies) if latencies else 0
        total_energy = sum(energies)

        # Estimar throughput (asumiendo tokens similares por respuesta)
        avg_tokens_per_response = 50  # Estimación
        throughput = (successful_requests * avg_tokens_per_response) / sum(latencies) if latencies else 0

        return PerformanceMetrics(
            model_name=model_name,
            dataset=dataset_name,
            accuracy=accuracy,
            avg_latency=avg_latency,
            p95_latency=p95_latency,
            total_energy=total_energy,
            throughput=throughput,
            total_requests=total_requests,
            successful_requests=successful_requests,
            errors=errors[:10]  # Limitar errores guardados
        )

    def _process_sample(self, model: BaseModelWrapper, sample: Dict, dataset_name: str) -> Dict[str, Any]:
        """Procesa una muestra individual."""
        try:
            # Extraer pregunta y respuesta correcta según el dataset
            question, correct_answer = self._extract_qa_from_sample(sample, dataset_name)

            # Generar respuesta
            response, metrics = model.generate(question)

            # Evaluar respuesta
            is_correct = model.evaluate_answer(question, response, correct_answer, dataset_name) if response else False

            return {
                'success': True,
                'latency': metrics['latency'],
                'energy': metrics['energy_joules'],
                'correct': is_correct,
                'response': response,
                'correct_answer': correct_answer
            }

        except Exception as e:
            logger.error(f"Error procesando muestra: {e}")
            return {
                'success': False,
                'error': str(e)
            }

    def _extract_qa_from_sample(self, sample: Dict, dataset_name: str) -> Tuple[str, str]:
        """Extrae pregunta y respuesta correcta de una muestra."""
        if dataset_name == 'mmlu':
            # MMLU tiene choices y answer (A, B, C, D)
            question = sample.get('question', '')
            choices = sample.get('choices', [])
            answer_idx = sample.get('answer', 0)

            # Formatear pregunta con opciones
            if choices:
                options_text = '\n'.join([f"{chr(65+i)}) {choice}" for i, choice in enumerate(choices)])
                question = f"{question}\n\n{options_text}"

            # La respuesta correcta es la letra (A, B, C, D)
            correct_answer = chr(65 + answer_idx) if isinstance(answer_idx, int) else str(answer_idx)

        elif dataset_name == 'gsm8k':
            # GSM8k tiene question y answer
            question = sample.get('question', '')
            correct_answer = sample.get('answer', '')

            # Para GSM8k, a veces la respuesta está al final después de ####
            if '####' in correct_answer:
                correct_answer = correct_answer.split('####')[-1].strip()

        else:
            # Formato general
            question = sample.get('question', sample.get('input', str(sample)))
            correct_answer = sample.get('answer', sample.get('target', sample.get('label', '')))

        return question, correct_answer

    def generate_reports(self):
        """Genera reportes JSON y CSV con comparación de baselines."""
        timestamp = time.strftime('%Y%m%d_%H%M%S')

        # Preparar datos con comparación de baselines
        results_data = []
        for result in self.results:
            result_dict = vars(result)
            if self.config.use_baselines:
                baseline_comp = self._compare_with_baseline(result)
                result_dict['baseline_comparison'] = baseline_comp
            results_data.append(result_dict)

        # Reporte JSON
        json_file = os.path.join(self.config.output_dir, f'benchmark_results_{timestamp}.json')
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(results_data, f, indent=2, ensure_ascii=False)

        # Reporte CSV
        if PLOTTING_AVAILABLE:
            csv_file = os.path.join(self.config.output_dir, f'benchmark_results_{timestamp}.csv')
            df = pd.DataFrame(results_data)
            df.to_csv(csv_file, index=False)

        # Reporte de comparación con baselines
        if self.config.use_baselines:
            comparison_file = os.path.join(self.config.output_dir, f'baseline_comparison_{timestamp}.txt')
            self._generate_baseline_comparison_report(comparison_file)

        logger.info(f"📊 Reportes guardados en {self.config.output_dir}")

    def _compare_with_baseline(self, result: PerformanceMetrics) -> Dict[str, Any]:
        """Compara resultado con baseline predefinida."""
        if result.dataset not in BASELINE_PERFORMANCE:
            return {}

        dataset_baselines = BASELINE_PERFORMANCE[result.dataset]
        if result.model_name not in dataset_baselines:
            return {}

        baseline = dataset_baselines[result.model_name]

        return {
            'baseline_accuracy': baseline['accuracy'],
            'accuracy_diff': result.accuracy - baseline['accuracy'],
            'accuracy_improvement': (result.accuracy - baseline['accuracy']) / baseline['accuracy'] if baseline['accuracy'] > 0 else 0,
            'baseline_latency': baseline['latency'],
            'latency_diff': result.avg_latency - baseline['latency'],
            'latency_improvement': (baseline['latency'] - result.avg_latency) / baseline['latency'] if baseline['latency'] > 0 else 0,
            'baseline_energy': baseline['energy_joules'],
            'energy_diff': result.total_energy - baseline['energy_joules'],
            'energy_improvement': (baseline['energy_joules'] - result.total_energy) / baseline['energy_joules'] if baseline['energy_joules'] > 0 else 0
        }

    def _generate_baseline_comparison_report(self, filename: str):
        """Genera reporte de comparación con baselines."""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("🚀 EmpoorioLM vs Gigantes - Comparación con Baselines\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Fecha: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")

            for result in self.results:
                if result.dataset in BASELINE_PERFORMANCE and result.model_name in BASELINE_PERFORMANCE[result.dataset]:
                    baseline_comp = self._compare_with_baseline(result)

                    f.write(f"🤖 {result.model_name.upper()} - {result.dataset.upper()}\n")
                    f.write("-" * 40 + "\n")
                    f.write(f"Precisión actual: {result.accuracy:.3f} (Baseline: {baseline_comp['baseline_accuracy']:.3f})\n")
                    f.write(f"Diferencia: {baseline_comp['accuracy_diff']:+.3f} ({baseline_comp['accuracy_improvement']:+.1%})\n\n")

                    f.write(f"Latencia actual: {result.avg_latency:.3f}s (Baseline: {baseline_comp['baseline_latency']:.3f}s)\n")
                    f.write(f"Diferencia: {baseline_comp['latency_diff']:+.3f}s ({baseline_comp['latency_improvement']:+.1%})\n\n")

                    f.write(f"Energía actual: {result.total_energy:.1f}J (Baseline: {baseline_comp['baseline_energy']:.1f}J)\n")
                    f.write(f"Diferencia: {baseline_comp['energy_diff']:+.1f}J ({baseline_comp['energy_improvement']:+.1%})\n\n")

                    # Resumen
                    if result.model_name == 'empoorio':
                        if baseline_comp['accuracy_improvement'] > 0:
                            f.write("🎉 ¡EmpoorioLM supera el baseline en precisión!\n")
                        if baseline_comp['latency_improvement'] > 0:
                            f.write("⚡ ¡EmpoorioLM es más rápido que el baseline!\n")
                        if baseline_comp['energy_improvement'] > 0:
                            f.write("🔋 ¡EmpoorioLM es más eficiente energéticamente!\n")

                    f.write("\n" + "=" * 60 + "\n\n")

        logger.info(f"📋 Reporte de comparación guardado: {filename}")

    def generate_plots(self):
        """Genera gráficos de comparación."""
        if not PLOTTING_AVAILABLE:
            logger.warning("⚠️ Matplotlib no disponible, saltando gráficos")
            return

        # Preparar datos
        df = pd.DataFrame([vars(r) for r in self.results])

        # Gráfico de precisión
        plt.figure(figsize=(12, 8))

        plt.subplot(2, 2, 1)
        for dataset in df['dataset'].unique():
            data = df[df['dataset'] == dataset]
            plt.bar(data['model_name'], data['accuracy'], alpha=0.7, label=f'{dataset.upper()}')
        plt.title('Precisión por Modelo y Dataset')
        plt.ylabel('Precisión')
        plt.legend()
        plt.xticks(rotation=45)

        # Gráfico de latencia
        plt.subplot(2, 2, 2)
        for dataset in df['dataset'].unique():
            data = df[df['dataset'] == dataset]
            plt.bar(data['model_name'], data['avg_latency'], alpha=0.7, label=f'{dataset.upper()}')
        plt.title('Latencia Promedio por Modelo')
        plt.ylabel('Latencia (s)')
        plt.legend()
        plt.xticks(rotation=45)

        # Gráfico de energía
        plt.subplot(2, 2, 3)
        for dataset in df['dataset'].unique():
            data = df[df['dataset'] == dataset]
            plt.bar(data['model_name'], data['total_energy'], alpha=0.7, label=f'{dataset.upper()}')
        plt.title('Consumo Energético Total')
        plt.ylabel('Energía (J)')
        plt.legend()
        plt.xticks(rotation=45)

        # Gráfico de throughput
        plt.subplot(2, 2, 4)
        for dataset in df['dataset'].unique():
            data = df[df['dataset'] == dataset]
            plt.bar(data['model_name'], data['throughput'], alpha=0.7, label=f'{dataset.upper()}')
        plt.title('Throughput (tokens/seg)')
        plt.ylabel('Throughput')
        plt.legend()
        plt.xticks(rotation=45)

        plt.tight_layout()

        # Guardar gráfico
        timestamp = time.strftime('%Y%m%d_%H%M%S')
        plot_file = os.path.join(self.config.output_dir, f'benchmark_comparison_{timestamp}.png')
        plt.savefig(plot_file, dpi=300, bbox_inches='tight')
        plt.close()

        logger.info(f"📈 Gráfico guardado: {plot_file}")


def load_config_from_file(config_file: str) -> BenchmarkConfig:
    """Carga configuración desde archivo JSON."""
    with open(config_file, 'r') as f:
        data = json.load(f)

    return BenchmarkConfig(**data)


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Benchmark EmpoorioLM vs GPT-4/Claude/Gemini')
    parser.add_argument('--config', type=str, help='Archivo de configuración JSON')
    parser.add_argument('--models', nargs='+', help='Modelos a testear')
    parser.add_argument('--datasets', nargs='+', help='Datasets a usar')
    parser.add_argument('--samples', type=int, default=10, help='Número de muestras por dataset (default: 10)')
    parser.add_argument('--output', type=str, default='./benchmark_results', help='Directorio de salida')
    parser.add_argument('--openai-key', type=str, help='API key de OpenAI')
    parser.add_argument('--anthropic-key', type=str, help='API key de Anthropic')
    parser.add_argument('--google-key', type=str, help='API key de Google')
    parser.add_argument('--mock-only', action='store_true', help='Usar solo respuestas mock (para desarrollo)')
    parser.add_argument('--enable-latency-testing', action='store_true', help='Habilitar pruebas de latencia detalladas')
    parser.add_argument('--latency-context-sizes', nargs='+', type=int, help='Tamaños de contexto para pruebas de latencia')
    parser.add_argument('--latency-batch-sizes', nargs='+', type=int, help='Tamaños de batch para pruebas de latencia')
    parser.add_argument('--latency-requests', type=int, default=50, help='Número de requests para pruebas de latencia')
    parser.add_argument('--latency-output', type=str, help='Directorio de salida para resultados de latencia')
    parser.add_argument('--enable-rag-needle-evaluation', action='store_true', help='Habilitar evaluación RAG Needle-in-Haystack')
    parser.add_argument('--rag-needle-context-sizes', nargs='+', type=int, help='Tamaños de contexto para evaluación RAG')
    parser.add_argument('--rag-needle-num-tasks', type=int, default=10, help='Número de tareas por configuración RAG')
    parser.add_argument('--rag-needle-output', type=str, help='Directorio de salida para resultados RAG')
    parser.add_argument('--enable-accuracy-comparison-framework', action='store_true', help='Usar el framework comprehensivo de comparación de precisión')
    parser.add_argument('--accuracy-framework-output', type=str, help='Directorio de salida para el framework de comparación')
    parser.add_argument('--enable-mobile-edge-benchmarks', action='store_true', help='Habilitar benchmarks de edge móvil')
    parser.add_argument('--mobile-edge-devices', nargs='+', help='Dispositivos móviles a testear')
    parser.add_argument('--mobile-edge-output', type=str, help='Directorio de salida para resultados de edge móvil')

    args = parser.parse_args()

    # Configuración por defecto
    config = BenchmarkConfig()

    # Sobrescribir con argumentos
    if args.models:
        config.models_to_test = args.models
    if args.datasets:
        config.datasets = args.datasets
    if args.samples:
        config.num_samples = args.samples
    if args.output:
        config.output_dir = args.output

    # API keys
    if args.openai_key:
        config.api_keys['openai'] = args.openai_key
    if args.anthropic_key:
        config.api_keys['anthropic'] = args.anthropic_key
    if args.google_key:
        config.api_keys['google'] = args.google_key

    # Configuración de latencia
    if args.enable_latency_testing:
        config.enable_latency_testing = True
    if args.latency_context_sizes:
        config.latency_context_sizes = args.latency_context_sizes
    if args.latency_batch_sizes:
        config.latency_batch_sizes = args.latency_batch_sizes
    if args.latency_requests:
        config.latency_num_requests = args.latency_requests
    if args.latency_output:
        config.latency_output_dir = args.latency_output

    # Configuración de RAG needle evaluation
    if args.enable_rag_needle_evaluation:
        config.enable_rag_needle_evaluation = True
    if args.rag_needle_context_sizes:
        config.rag_needle_context_sizes = args.rag_needle_context_sizes
    if args.rag_needle_num_tasks:
        config.rag_needle_num_tasks_per_size = args.rag_needle_num_tasks
    if args.rag_needle_output:
        config.rag_needle_output_dir = args.rag_needle_output

    # Configuración del framework de comparación de precisión
    use_accuracy_framework = args.enable_accuracy_comparison_framework
    accuracy_framework_output = args.accuracy_framework_output or './accuracy_comparison_results'

    # Configuración de mobile edge benchmarks
    if args.enable_mobile_edge_benchmarks:
        config.enable_mobile_edge_benchmarks = True
    if args.mobile_edge_devices:
        config.mobile_edge_devices = args.mobile_edge_devices
    if args.mobile_edge_output:
        config.mobile_edge_output_dir = args.mobile_edge_output

    # Cargar desde archivo si especificado
    if args.config:
        config = load_config_from_file(args.config)

    # Ejecutar benchmark usando el framework comprehensivo si está habilitado
    if use_accuracy_framework and ACCURACY_FRAMEWORK_AVAILABLE:
        print("🚀 Usando Framework Comprehensivo de Comparación de Precisión...")

        # Crear configuración del framework
        framework_config = AccuracyComparisonConfig(
            models_to_compare=config.models_to_test,
            output_dir=accuracy_framework_output,
            benchmark_config=config,
            energy_config=None,  # Usará configuración por defecto
            latency_config=None,  # Usará configuración por defecto
            rag_config=None  # Usará configuración por defecto
        )

        # Configurar API keys
        framework_config.benchmark_config.api_keys = config.api_keys

        # Ejecutar comparación comprehensiva
        framework = AccuracyComparisonFramework(framework_config)
        comprehensive_results = framework.run_comprehensive_comparison()
        framework.generate_comprehensive_report()

        print("\n🎉 Framework de comparación completado!")
        print(f"📁 Resultados guardados en: {accuracy_framework_output}")

        # Mostrar titulares de mercado
        if framework.market_headlines:
            print("\n📰 Titulares de mercado generados:")
            for headline in framework.market_headlines[:5]:
                print(f"• {headline.headline}")

        return  # Salir temprano si se usó el framework

    # Ejecutar benchmark tradicional
    print("🚀 Iniciando benchmark EmpoorioLM vs Gigantes...")
    runner = BenchmarkRunner(config)
    results = runner.run_benchmark()

    # Ejecutar pruebas de latencia detalladas si están habilitadas
    latency_results = {}
    if config.enable_latency_testing and LATENCY_TESTER_AVAILABLE:
        print("🧪 Ejecutando pruebas de latencia detalladas...")
        latency_results = runner.run_latency_tests()

    # Ejecutar evaluación RAG Needle-in-Haystack si está habilitada
    rag_results = {}
    if config.enable_rag_needle_evaluation and RAG_NEEDLE_AVAILABLE:
        print("🧪 Ejecutando evaluación RAG Needle-in-Haystack...")
        rag_results = runner.run_rag_needle_evaluation()

    # Ejecutar benchmarks de edge móvil si están habilitados
    mobile_results = {}
    if config.enable_mobile_edge_benchmarks and MOBILE_EDGE_AVAILABLE:
        print("📱 Ejecutando benchmarks de edge móvil...")
        mobile_results = runner.run_mobile_edge_benchmarks()

    # Generar reportes
    runner.generate_reports()
    if PLOTTING_AVAILABLE:
        runner.generate_plots()

    # Imprimir resumen
    print("\n🎉 Benchmark completado!")
    print("📊 Resumen de resultados:")

    for result in results:
        print(f"\n🤖 {result.model_name} - {result.dataset.upper()}:")
        print(f"  ✅ Precisión: {result.accuracy:.3f}")
        print(f"  ⏱️  Latencia: {result.avg_latency:.3f}s")
        print(f"  ⚡ Energía: {result.total_energy:.1f}J")
        print(f"  🚀 Throughput: {result.throughput:.1f} tokens/s")

        # Mostrar comparación con baseline si está disponible
        if hasattr(result, 'baseline_comparison') and result.baseline_comparison:
            comp = result.baseline_comparison
            print(f"  📈 Mejora vs Baseline: Precisión {comp['accuracy_improvement']:+.1%}, Latencia {comp['latency_improvement']:+.1%}")

    print(f"\n📁 Resultados guardados en: {config.output_dir}")
    if config.enable_latency_testing and latency_results:
        print(f"📊 Resultados de latencia guardados en: {config.latency_output_dir}")
    if config.enable_rag_needle_evaluation and rag_results:
        print(f"🧪 Resultados RAG Needle-in-Haystack guardados en: {config.rag_needle_output_dir}")
    if config.enable_mobile_edge_benchmarks and mobile_results:
        print(f"📱 Resultados de edge móvil guardados en: {config.mobile_edge_output_dir}")
    print("\n💡 Para usar EmpoorioLM real, asegúrate de que esté correctamente instalado y configurado.")
    print("💡 Para usar APIs reales, proporciona las API keys correspondientes.")
    if config.enable_latency_testing:
        print("💡 Pruebas de latencia detalladas habilitadas - incluye percentiles, TTFT y throughput.")
    if config.enable_rag_needle_evaluation:
        print("💡 Evaluación RAG Needle-in-Haystack habilitada - mide capacidad de recuperación en contextos largos.")
    if config.enable_mobile_edge_benchmarks:
        print("💡 Benchmarks de edge móvil habilitados - mide rendimiento en dispositivos móviles simulados.")
    if use_accuracy_framework:
        print("💡 Framework Comprehensivo de Comparación de Precisión habilitado - análisis estadístico avanzado y reportes automáticos.")


if __name__ == "__main__":
    main()


"""
DOCUMENTACIÓN Y EJEMPLOS DE USO
===============================

Este script permite comparar el rendimiento de EmpoorioLM contra GPT-4, Claude y Gemini
midiendo precisión, latencia y consumo energético.

REQUISITOS
----------
- Python 3.8+
- Dependencias: torch, transformers, openai, anthropic, google-generativeai, psutil, matplotlib, pandas
- API keys para los modelos externos (opcional)

INSTALACIÓN
-----------
pip install torch transformers openai anthropic google-generativeai psutil matplotlib pandas datasets

EJEMPLOS DE USO
---------------

1. Benchmark básico con todos los modelos disponibles:
python benchmark_vs_giants.py --samples 50

2. Comparar solo EmpoorioLM y GPT-4 en MMLU:
python benchmark_vs_giants.py --models empoorio gpt4 --datasets mmlu --samples 100

3. Benchmark con configuración personalizada desde archivo JSON:
python benchmark_vs_giants.py --config config/benchmark_config.json

4. Benchmark rápido para desarrollo:
python benchmark_vs_giants.py --samples 10 --models empoorio

5. Benchmark comprehensivo con framework avanzado:
python benchmark_vs_giants.py --enable-accuracy-comparison-framework --accuracy-framework-output ./comprehensive_results

6. Benchmark con evaluación de edge móvil:
python benchmark_vs_giants.py --enable-mobile-edge-benchmarks --mobile-edge-devices pixel_7 iphone_14 --samples 50

CONFIGURACIÓN JSON EJEMPLO
--------------------------
{
  "models_to_test": ["empoorio", "gpt4", "claude"],
  "datasets": ["mmlu", "gsm8k"],
  "num_samples": 100,
  "max_tokens": 512,
  "temperature": 0.7,
  "output_dir": "./benchmark_results",
  "api_keys": {
    "openai": "sk-your-openai-key",
    "anthropic": "sk-ant-your-anthropic-key",
    "google": "your-google-api-key"
  },
  "empoorio_config": {
    "model_path": "./models/empoorio_lm/v1.0.0",
    "device": "cpu"
  },
  "use_baselines": true
}

API KEYS
--------
Para usar modelos externos, configura las variables de entorno o pásalas como argumentos:

export OPENAI_API_KEY="sk-your-key"
export ANTHROPIC_API_KEY="sk-ant-your-key"
export GOOGLE_API_KEY="your-google-key"

O usa los argumentos del script:
--openai-key "sk-your-key" --anthropic-key "sk-ant-key" --google-key "google-key"

SALIDA
------
El script genera:
- benchmark_results_TIMESTAMP.json: Resultados detallados en JSON
- benchmark_results_TIMESTAMP.csv: Resultados en formato CSV
- baseline_comparison_TIMESTAMP.txt: Comparación con baselines
- benchmark_comparison_TIMESTAMP.png: Gráficos de comparación (si matplotlib disponible)

FRAMEWORK COMPREHENSIVO (con --enable-accuracy-comparison-framework):
- comprehensive_comparison_TIMESTAMP.json: Resultados consolidados completos
- executive_summary_TIMESTAMP.txt: Resumen ejecutivo con titulares de mercado
- radar_comparison_TIMESTAMP.png: Gráfico radar multi-dimensional
- efficiency_plot_TIMESTAMP.png: Gráfico de eficiencia (precisión vs energía)
- latency_distribution_TIMESTAMP.png: Distribución de latencias
- rag_curve_TIMESTAMP.png: Curva de rendimiento RAG vs contexto

BENCHMARKS DE EDGE MÓVIL (con --enable-mobile-edge-benchmarks):
- mobile_edge_results_TIMESTAMP.json: Resultados detallados de edge móvil
- mobile_edge_results_TIMESTAMP.csv: Resultados de edge en formato CSV
- mobile_edge_comparison_TIMESTAMP.png: Gráficos comparativos de rendimiento edge

MÉTRICAS MEDIDAS
---------------
BENCHMARK BÁSICO:
- Precisión: Porcentaje de respuestas correctas
- Latencia: Tiempo promedio de respuesta (segundos)
- P95 Latencia: Percentil 95 de latencia
- Consumo Energético: Energía estimada en Joules
- Throughput: Tokens generados por segundo
- Uso de CPU/Memoria: Durante la inferencia

FRAMEWORK COMPREHENSIVO (adicionales):
- Análisis estadístico: p-values, intervalos de confianza, tamaño del efecto
- Eficiencia combinada: accuracy / (latency * energy)
- Inteligencia por watt: accuracy * tokens_per_watt
- Titulares de mercado automáticos: "X veces más eficiente", "Y% más preciso"
- RAG performance: Precisión en recuperación de información en contextos largos
- Métricas de latencia avanzadas: TTFT, percentiles detallados, distribuciones

BENCHMARKS DE EDGE MÓVIL (adicionales):
- Consumo de batería realista: mAh consumidos por inferencia
- Eficiencia energética: mAh por token generado
- Uso de memoria en dispositivos móviles: MB requeridos
- Throughput en edge: tokens/segundo en hardware móvil
- Comparación edge vs nube: speedup y ahorro energético
- Soporte multi-dispositivo: Android/iOS con especificaciones reales
- Simulación térmica: throttling por temperatura alta

BASELINES PREDEFINIDAS
---------------------
Incluye baselines aproximadas basadas en benchmarks públicos para comparación.

MANEJO DE ERRORES
----------------
- Reintentos automáticos (hasta 3 intentos por defecto)
- Timeout configurable (60 segundos por defecto)
- Logging extenso en benchmark_vs_giants.log
- Continúa ejecutándose aunque fallen algunos modelos

LIMITACIONES
-----------
- El consumo energético es una estimación basada en uso de CPU
- Para mediciones más precisas de energía, usar hardware especializado
- Los resultados pueden variar según la configuración del sistema
"""