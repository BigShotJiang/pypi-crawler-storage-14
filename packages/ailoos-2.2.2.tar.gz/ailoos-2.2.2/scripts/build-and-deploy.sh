#!/bin/bash

# AILOOS Build and Deploy Script
# Builds Docker images and deploys to Cloud Run

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_ID="ailoos-oauth-473213"
REGION="europe-west1"
API_SERVICE_NAME="ailoos-api"
WEBSOCKET_SERVICE_NAME="ailoos-websocket"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_requirements() {
    log_info "Checking requirements..."

    # Check if gcloud is authenticated
    if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
        log_error "Not authenticated with Google Cloud. Run: gcloud auth login"
        exit 1
    fi

    # Check if Docker is running
    if ! docker info > /dev/null 2>&1; then
        log_error "Docker is not running. Please start Docker."
        exit 1
    fi

    log_success "All requirements met"
}

build_api_image() {
    log_info "Building API Docker image..."

    # Build the image
    docker build -t gcr.io/${PROJECT_ID}/ailoos-api:latest -f Dockerfile .

    # Tag with commit SHA for versioning
    COMMIT_SHA=$(git rev-parse --short HEAD 2>/dev/null || echo "latest")
    docker tag gcr.io/${PROJECT_ID}/ailoos-api:latest gcr.io/${PROJECT_ID}/ailoos-api:${COMMIT_SHA}

    log_success "API image built successfully"
}

push_images() {
    log_info "Pushing images to Google Container Registry..."

    # Configure Docker to use gcloud as a credential helper
    gcloud auth configure-docker --quiet

    # Push images
    docker push gcr.io/${PROJECT_ID}/ailoos-api:latest

    COMMIT_SHA=$(git rev-parse --short HEAD 2>/dev/null || echo "latest")
    docker push gcr.io/${PROJECT_ID}/ailoos-api:${COMMIT_SHA}

    log_success "Images pushed successfully"
}

deploy_api_service() {
    log_info "Deploying API service to Cloud Run..."

    gcloud run deploy ${API_SERVICE_NAME} \
        --image gcr.io/${PROJECT_ID}/ailoos-api:latest \
        --platform managed \
        --region ${REGION} \
        --allow-unauthenticated \
        --port 8000 \
        --memory 1Gi \
        --cpu 1 \
        --max-instances 10 \
        --min-instances 1 \
        --set-env-vars ENVIRONMENT=production \
        --set-secrets DATABASE_URL=DATABASE_URL:latest \
        --set-secrets JWT_SECRET=JWT_SECRET:latest \
        --service-account ailoos-cloud-run@${PROJECT_ID}.iam.gserviceaccount.com

    API_URL=$(gcloud run services describe ${API_SERVICE_NAME} --region=${REGION} --format="value(status.url)")
    log_success "API deployed to: ${API_URL}"
}

deploy_websocket_service() {
    log_info "Deploying WebSocket service to Cloud Run..."

    # For now, we'll use the same image but different port
    # In production, you might want a separate WebSocket service
    gcloud run deploy ${WEBSOCKET_SERVICE_NAME} \
        --image gcr.io/${PROJECT_ID}/ailoos-api:latest \
        --platform managed \
        --region ${REGION} \
        --allow-unauthenticated \
        --port 8001 \
        --memory 512Mi \
        --cpu 0.5 \
        --max-instances 5 \
        --min-instances 1 \
        --set-env-vars ENVIRONMENT=production \
        --set-secrets DATABASE_URL=DATABASE_URL:latest \
        --service-account ailoos-cloud-run@${PROJECT_ID}.iam.gserviceaccount.com

    WS_URL=$(gcloud run services describe ${WEBSOCKET_SERVICE_NAME} --region=${REGION} --format="value(status.url)")
    log_success "WebSocket deployed to: ${WS_URL}"
}

setup_domain_mappings() {
    log_info "Setting up domain mappings..."

    # API domain mapping
    log_info "Setting up api.ailoos.com..."
    gcloud run domain-mappings create \
        --service ${API_SERVICE_NAME} \
        --domain api.ailoos.com \
        --region ${REGION} || log_warning "Domain mapping for api.ailoos.com may already exist"

    # WebSocket domain mapping
    log_info "Setting up ws.ailoos.com..."
    gcloud run domain-mappings create \
        --service ${WEBSOCKET_SERVICE_NAME} \
        --domain ws.ailoos.com \
        --region ${REGION} || log_warning "Domain mapping for ws.ailoos.com may already exist"

    log_success "Domain mappings configured"
}

run_health_checks() {
    log_info "Running health checks..."

    API_URL=$(gcloud run services describe ${API_SERVICE_NAME} --region=${REGION} --format="value(status.url)")

    # Wait for API to be healthy
    for i in {1..30}; do
        if curl -f -s "${API_URL}/health" > /dev/null 2>&1; then
            log_success "API health check passed"
            break
        fi

        if [ $i -eq 30 ]; then
            log_error "API health check failed after 30 attempts"
            exit 1
        fi

        log_info "Waiting for API to be healthy... ($i/30)"
        sleep 10
    done

    WS_URL=$(gcloud run services describe ${WEBSOCKET_SERVICE_NAME} --region=${REGION} --format="value(status.url)")

    # Basic WebSocket service check
    if curl -f -s "${WS_URL}/health" > /dev/null 2>&1; then
        log_success "WebSocket health check passed"
    else
        log_warning "WebSocket health check failed - this may be expected if WebSocket endpoint differs"
    fi
}

deploy_frontend() {
    log_info "Deploying frontend..."

    cd frontend

    # Install dependencies
    npm install

    # Build for production
    npm run build

    # Deploy to Vercel if available
    if command -v vercel &> /dev/null; then
        vercel --prod
        log_success "Frontend deployed to Vercel"
    else
        log_warning "Vercel CLI not found. Please deploy frontend manually:"
        echo "  cd frontend"
        echo "  npm run build"
        echo "  # Deploy build/ directory to your hosting provider"
    fi

    cd ..
}

main() {
    echo "🚀 AILOOS Build and Deploy Script"
    echo "=================================="
    echo

    # Parse command line arguments
    case "${1:-all}" in
        "check")
            check_requirements
            ;;
        "build")
            check_requirements
            build_api_image
            push_images
            ;;
        "deploy")
            check_requirements
            deploy_api_service
            deploy_websocket_service
            setup_domain_mappings
            run_health_checks
            ;;
        "frontend")
            deploy_frontend
            ;;
        "all")
            check_requirements
            build_api_image
            push_images
            deploy_api_service
            deploy_websocket_service
            setup_domain_mappings
            run_health_checks
            deploy_frontend
            log_success "🎉 Complete deployment finished!"
            ;;
        *)
            echo "Usage: $0 {check|build|deploy|frontend|all}"
            echo
            echo "Commands:"
            echo "  check    - Check requirements"
            echo "  build    - Build and push Docker images"
            echo "  deploy   - Deploy services to Cloud Run"
            echo "  frontend - Deploy frontend to Vercel"
            echo "  all      - Run complete deployment"
            exit 1
            ;;
    esac
}

# Run main function
main "$@"