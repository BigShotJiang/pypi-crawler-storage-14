#!/usr/bin/env python3
"""
Benchmark de serialización JSON/TOON/VSC para AILOOS.
Compara rendimiento de formatos de serialización en diferentes escenarios.
"""

import asyncio
import time
import json
import statistics
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from pathlib import Path
import sys

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.core.serializers import (
    SerializationFormat, get_serializer, SerializationResult
)
from ailoos.core.logging import get_logger

logger = get_logger(__name__)


@dataclass
class BenchmarkResult:
    """Resultado de un benchmark."""
    format: str
    operation: str
    data_size: int
    iterations: int
    total_time_ms: float
    avg_time_ms: float
    min_time_ms: float
    max_time_ms: float
    throughput_items_sec: float
    throughput_mb_sec: float
    compression_ratio: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "format": self.format,
            "operation": self.operation,
            "data_size": self.data_size,
            "iterations": self.iterations,
            "total_time_ms": self.total_time_ms,
            "avg_time_ms": self.avg_time_ms,
            "min_time_ms": self.min_time_ms,
            "max_time_ms": self.max_time_ms,
            "throughput_items_sec": self.throughput_items_sec,
            "throughput_mb_sec": self.throughput_mb_sec,
            "compression_ratio": self.compression_ratio
        }


class SerializationBenchmark:
    """Suite de benchmarks para serialización."""

    def __init__(self, iterations: int = 100, warmup_iterations: int = 10):
        self.iterations = iterations
        self.warmup_iterations = warmup_iterations
        self.results: List[BenchmarkResult] = []

    def generate_test_data(self, scenario: str) -> Any:
        """Generar datos de prueba para diferentes escenarios."""
        if scenario == "small_objects":
            # Lista de objetos pequeños
            return [
                {"id": i, "name": f"item_{i}", "value": i * 1.5, "active": i % 2 == 0}
                for i in range(100)
            ]

        elif scenario == "large_arrays":
            # Arrays grandes uniformes (ideal para TOON)
            return {
                "timestamps": list(range(1000)),
                "values": [i * 0.1 for i in range(1000)],
                "categories": [f"cat_{i%10}" for i in range(1000)],
                "flags": [i % 3 == 0 for i in range(1000)]
            }

        elif scenario == "sparse_data":
            # Datos dispersos (pocos valores no-null)
            return [
                {"id": i, "data": "value" if i % 100 == 0 else None}
                for i in range(10000)
            ]

        elif scenario == "nested_structures":
            # Estructuras anidadas complejas
            return {
                "metadata": {
                    "version": "1.0",
                    "created": "2024-01-01T00:00:00Z",
                    "tags": ["benchmark", "serialization", "test"]
                },
                "data": [
                    {
                        "id": i,
                        "properties": {
                            "size": i * 10,
                            "weight": i * 0.5,
                            "dimensions": [i, i*2, i*3]
                        },
                        "children": [
                            {"type": "child", "value": j}
                            for j in range(5)
                        ]
                    }
                    for i in range(50)
                ]
            }

        elif scenario == "knowledge_graph":
            # Datos similares a resultados de Knowledge Graph
            from ailoos.knowledge_graph.core import Triple
            return [
                Triple(
                    subject=f"http://example.org/entity/{i}",
                    predicate="http://example.org/property",
                    object=f"value_{i}"
                )
                for i in range(500)
            ]

        else:
            raise ValueError(f"Unknown scenario: {scenario}")

    def run_benchmark(self, scenario: str, formats: Optional[List[SerializationFormat]] = None) -> List[BenchmarkResult]:
        """Ejecutar benchmark completo para un escenario."""
        if formats is None:
            formats = [SerializationFormat.JSON, SerializationFormat.TOON, SerializationFormat.VSC]

        logger.info(f"🚀 Running serialization benchmark for scenario: {scenario}")

        data = self.generate_test_data(scenario)
        data_size = len(json.dumps(data).encode('utf-8')) if not isinstance(data, list) or not data or not hasattr(data[0], 'to_dict') else len(str(data))

        results = []

        for fmt in formats:
            logger.info(f"📊 Testing format: {fmt.value}")

            # Benchmark de serialización
            serialize_result = self._benchmark_operation(
                "serialize", fmt, data, data_size
            )
            results.append(serialize_result)

            # Benchmark de deserialización
            try:
                serializer = get_serializer(fmt)
                serialized = serializer.serialize(data)

                deserialize_result = self._benchmark_operation(
                    "deserialize", fmt, serialized.data, data_size
                )
                results.append(deserialize_result)

                # Calcular ratio de compresión
                if hasattr(serialized, 'metadata') and serialized.metadata:
                    original_size = serialized.metadata.get('size', len(serialized.data))
                    compressed_size = len(serialized.data)
                    compression_ratio = original_size / compressed_size if compressed_size > 0 else 1.0

                    # Actualizar resultados con ratio de compresión
                    for result in [serialize_result, deserialize_result]:
                        result.compression_ratio = compression_ratio

            except Exception as e:
                logger.warning(f"Failed to benchmark deserialization for {fmt.value}: {e}")

        return results

    def _benchmark_operation(self, operation: str, format: SerializationFormat,
                           data: Any, data_size: int) -> BenchmarkResult:
        """Ejecutar benchmark para una operación específica."""
        serializer = get_serializer(format)
        times = []

        # Warmup
        for _ in range(self.warmup_iterations):
            try:
                if operation == "serialize":
                    serializer.serialize(data)
                else:  # deserialize
                    serializer.deserialize(data)
            except:
                pass  # Ignorar errores en warmup

        # Benchmark
        for _ in range(self.iterations):
            start_time = time.perf_counter()

            try:
                if operation == "serialize":
                    result = serializer.serialize(data)
                    # Usar tamaño real si está disponible
                    actual_size = len(result.data) if hasattr(result, 'data') else data_size
                else:  # deserialize
                    result = serializer.deserialize(data)
                    actual_size = data_size

                end_time = time.perf_counter()
                times.append((end_time - start_time) * 1000)  # Convertir a ms

            except Exception as e:
                logger.error(f"Error in {operation} benchmark: {e}")
                times.append(float('inf'))

        # Calcular estadísticas
        valid_times = [t for t in times if t != float('inf')]
        if not valid_times:
            return BenchmarkResult(
                format=format.value,
                operation=operation,
                data_size=data_size,
                iterations=self.iterations,
                total_time_ms=float('inf'),
                avg_time_ms=float('inf'),
                min_time_ms=float('inf'),
                max_time_ms=float('inf'),
                throughput_items_sec=0,
                throughput_mb_sec=0
            )

        total_time = sum(valid_times)
        avg_time = statistics.mean(valid_times)
        min_time = min(valid_times)
        max_time = max(valid_times)

        # Calcular throughput
        items_per_sec = self.iterations / (total_time / 1000) if total_time > 0 else 0
        mb_per_sec = (data_size * self.iterations / (1024 * 1024)) / (total_time / 1000) if total_time > 0 else 0

        return BenchmarkResult(
            format=format.value,
            operation=operation,
            data_size=data_size,
            iterations=self.iterations,
            total_time_ms=total_time,
            avg_time_ms=avg_time,
            min_time_ms=min_time,
            max_time_ms=max_time,
            throughput_items_sec=items_per_sec,
            throughput_mb_sec=mb_per_sec
        )

    def run_comprehensive_benchmark(self) -> Dict[str, Any]:
        """Ejecutar benchmark completo en todos los escenarios."""
        scenarios = [
            "small_objects",
            "large_arrays",
            "sparse_data",
            "nested_structures",
            "knowledge_graph"
        ]

        all_results = {}

        for scenario in scenarios:
            logger.info(f"🏃 Running scenario: {scenario}")
            results = self.run_benchmark(scenario)
            all_results[scenario] = [r.to_dict() for r in results]
            self.results.extend(results)

        # Generar resumen
        summary = self._generate_summary(all_results)

        return {
            "scenarios": all_results,
            "summary": summary,
            "metadata": {
                "iterations": self.iterations,
                "warmup_iterations": self.warmup_iterations,
                "timestamp": time.time(),
                "formats_tested": [fmt.value for fmt in SerializationFormat]
            }
        }

    def _generate_summary(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Generar resumen de resultados."""
        summary = {
            "format_performance": {},
            "best_formats": {},
            "compression_stats": {}
        }

        # Agrupar por formato
        format_stats = {}
        for scenario, scenario_results in results.items():
            for result in scenario_results:
                fmt = result["format"]
                op = result["operation"]

                if fmt not in format_stats:
                    format_stats[fmt] = {"serialize": [], "deserialize": []}

                format_stats[fmt][op].append(result)

        # Calcular promedios por formato
        for fmt, operations in format_stats.items():
            summary["format_performance"][fmt] = {}

            for op, op_results in operations.items():
                if op_results:
                    avg_time = statistics.mean(r["avg_time_ms"] for r in op_results)
                    avg_throughput = statistics.mean(r["throughput_mb_sec"] for r in op_results)
                    avg_compression = statistics.mean(r["compression_ratio"] for r in op_results)

                    summary["format_performance"][fmt][op] = {
                        "avg_time_ms": avg_time,
                        "avg_throughput_mb_sec": avg_throughput,
                        "avg_compression_ratio": avg_compression
                    }

        # Determinar mejores formatos
        operations = ["serialize", "deserialize"]
        for op in operations:
            best_time = min(
                (stats[op]["avg_time_ms"], fmt)
                for fmt, stats in summary["format_performance"].items()
                if op in stats
            )
            best_throughput = max(
                (stats[op]["avg_throughput_mb_sec"], fmt)
                for fmt, stats in summary["format_performance"].items()
                if op in stats
            )

            summary["best_formats"][op] = {
                "fastest": best_time[1],
                "highest_throughput": best_throughput[1]
            }

        return summary

    def save_results(self, filename: str, results: Dict[str, Any]):
        """Guardar resultados en archivo JSON."""
        import json
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        logger.info(f"💾 Results saved to {filename}")


async def main():
    """Función principal para ejecutar benchmarks."""
    import argparse

    parser = argparse.ArgumentParser(description="AILOOS Serialization Benchmark")
    parser.add_argument("--iterations", type=int, default=100, help="Number of benchmark iterations")
    parser.add_argument("--warmup", type=int, default=10, help="Number of warmup iterations")
    parser.add_argument("--output", type=str, default="serialization_benchmark_results.json", help="Output file")
    parser.add_argument("--scenario", type=str, help="Specific scenario to test")

    args = parser.parse_args()

    benchmark = SerializationBenchmark(
        iterations=args.iterations,
        warmup_iterations=args.warmup
    )

    if args.scenario:
        results = {args.scenario: [r.to_dict() for r in benchmark.run_benchmark(args.scenario)]}
    else:
        results = benchmark.run_comprehensive_benchmark()

    benchmark.save_results(args.output, results)

    # Imprimir resumen
    print("\n📊 SERIALIZATION BENCHMARK RESULTS")
    print("=" * 50)

    if "summary" in results:
        summary = results["summary"]
        print("\n🏆 BEST FORMATS:")
        for op, best in summary["best_formats"].items():
            print(f"  {op.capitalize()}:")
            print(f"    Fastest: {best['fastest']}")
            print(f"    Highest throughput: {best['highest_throughput']}")

        print("\n📈 AVERAGE PERFORMANCE:")
        for fmt, perf in summary["format_performance"].items():
            print(f"  {fmt.upper()}:")
            for op, stats in perf.items():
                print(f"    {op}: {stats['avg_time_ms']:.2f}ms avg, {stats['avg_throughput_mb_sec']:.2f} MB/s")

    print(f"\n✅ Results saved to {args.output}")


if __name__ == "__main__":
    asyncio.run(main())