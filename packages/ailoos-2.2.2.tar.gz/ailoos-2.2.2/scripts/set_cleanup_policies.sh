#!/bin/bash
# Script to set cleanup policies for Google Cloud Artifact Registry
# Usage: ./set_cleanup_policies.sh <project_id> <location> <repository>

set -e

if [ $# -ne 3 ]; then
    echo "Usage: $0 <project_id> <location> <repository>"
    echo "Example: $0 my-project us-central1 my-repo"
    exit 1
fi

PROJECT_ID=$1
LOCATION=$2
REPOSITORY=$3

echo "Setting cleanup policies for repository: $REPOSITORY in project: $PROJECT_ID location: $LOCATION"

# Policy 1: Keep only the last 10 versions for each tag
gcloud artifacts repositories set-cleanup-policies "$REPOSITORY" \
  --project="$PROJECT_ID" \
  --location="$LOCATION" \
  --policy='{
    "id": "keep-recent-versions",
    "cleanupPolicies": [
      {
        "id": "keep-last-10-versions",
        "action": "KEEP",
        "condition": {
          "tagState": "TAGGED",
          "tagPrefixes": [],
          "olderThan": "",
          "newerThan": "",
          "packageNamePrefixes": [],
          "versionNamePrefixes": [],
          "versionRegexes": [],
          "retainVersions": "10"
        }
      },
      {
        "id": "delete-untagged-older-than-30-days",
        "action": "DELETE",
        "condition": {
          "tagState": "UNTAGGED",
          "olderThan": "2592000s"
        }
      },
      {
        "id": "delete-old-versions-older-than-90-days",
        "action": "DELETE",
        "condition": {
          "tagState": "TAGGED",
          "olderThan": "7776000s"
        }
      }
    ]
  }'

echo "Cleanup policies set successfully."