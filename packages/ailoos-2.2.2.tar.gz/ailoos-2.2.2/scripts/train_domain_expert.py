#!/usr/bin/env python3
"""
Entrenamiento de Expertos por Dominio para EmpoorioLM
====================================================

Este script entrena expertos especializados para dominios específicos,
permitiendo que EmpoorioLM se convierta en un "Enjambre de Especialistas".

Características:
- Entrenamiento quirúrgico: solo expertos específicos
- Congelamiento del modelo base
- Datasets especializados por dominio
- Guardado modular de expertos
"""

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

# Añadir el directorio raíz al path
script_dir = Path(__file__).parent
root_dir = script_dir.parent
sys.path.insert(0, str(root_dir))

from src.ailoos.models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
from src.ailoos.models.empoorio_lm.expert_system import (
    ExpertManager, ExpertConfig, Domain, create_expert_manager
)

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class DomainDataset(Dataset):
    """Dataset especializado para un dominio específico."""

    def __init__(self, domain: Domain, data_path: Optional[str] = None, max_length: int = 512):
        self.domain = domain
        self.max_length = max_length
        self.data = []

        if data_path:
            self.load_data(data_path)
        else:
            self.generate_synthetic_data()

    def load_data(self, data_path: str):
        """Cargar datos reales para el dominio."""
        data_path = Path(data_path)

        if data_path.exists():
            if data_path.suffix == '.jsonl':
                self._load_jsonl(data_path)
            elif data_path.suffix == '.json':
                self._load_json(data_path)
            else:
                logger.warning(f"Formato no soportado: {data_path.suffix}")
                self.generate_synthetic_data()
        else:
            logger.warning(f"Datos no encontrados: {data_path}")
            self.generate_synthetic_data()

    def _load_jsonl(self, path: Path):
        """Cargar datos en formato JSONL."""
        with open(path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    item = json.loads(line)
                    if 'text' in item:
                        self.data.append(item['text'])

    def _load_json(self, path: Path):
        """Cargar datos en formato JSON."""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, str):
                        self.data.append(item)
                    elif isinstance(item, dict) and 'text' in item:
                        self.data.append(item['text'])

    def generate_synthetic_data(self):
        """Generar datos sintéticos para testing."""
        logger.info(f"Generando datos sintéticos para dominio: {self.domain.value}")

        if self.domain == Domain.LEGAL:
            templates = [
                "El contrato establece que {partes} acuerdan {términos} bajo las condiciones {cláusulas}.",
                "Según la jurisprudencia {caso}, la corte determinó que {decisión}.",
                "La demanda por {motivo} fue presentada contra {demandado} en {jurisdicción}.",
                "El abogado argumentó que {defensa} viola el artículo {artículo} de la constitución."
            ]
            self.data = [self._fill_template(t) for t in templates * 100]

        elif self.domain == Domain.MEDICAL:
            templates = [
                "El paciente presenta síntomas de {síntoma} con diagnóstico de {enfermedad}.",
                "Se prescribe {medicamento} para tratar {condición} con dosis de {dosis}.",
                "Los resultados del análisis muestran {valores} indicando {diagnóstico}.",
                "El tratamiento para {patología} incluye {procedimiento} y seguimiento {período}."
            ]
            self.data = [self._fill_template(t) for t in templates * 100]

        elif self.domain == Domain.CODING:
            templates = [
                "La función {nombre} implementa {algoritmo} con complejidad {complejidad}.",
                "El código utiliza {paradigma} para resolver {problema} en {lenguaje}.",
                "La clase {clase} hereda de {padre} e implementa {interface}.",
                "El error {error} ocurre cuando {condición} en línea {línea}."
            ]
            self.data = [self._fill_template(t) for t in templates * 100]

        else:
            # Datos genéricos para otros dominios
            self.data = [
                f"Texto de ejemplo {i} para el dominio {self.domain.value}."
                for i in range(1000)
            ]

    def _fill_template(self, template: str) -> str:
        """Llenar template con valores aleatorios (simplificado)."""
        # En producción, usar datasets reales
        return template.replace("{", "").replace("}", "[valor]")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]


class DomainExpertTrainer:
    """Entrenador de expertos especializados por dominio."""

    def __init__(self,
                 domain: Domain,
                 target_layers: List[int],
                 expert_indices: List[int],
                 model_path: str,
                 output_dir: str,
                 device: str = "auto"):
        self.domain = domain
        self.target_layers = target_layers
        self.expert_indices = expert_indices
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Determinar dispositivo
        if device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        # Cargar modelo base
        self.model = self._load_base_model(model_path)
        self.config = self.model.config

        # Congelar modelo base (excepto expertos objetivo)
        self._freeze_base_model()

        # Configurar experto
        self.expert_name = f"{domain.value}_expert_v1.0"
        self.expert_config = ExpertConfig(
            domain=domain,
            name=self.expert_name,
            description=f"Experto especializado en {domain.value}",
            target_layers=target_layers,
            expert_indices=expert_indices,
            dataset_info={"type": "synthetic", "samples": 1000},
            version="1.0.0",
            created_at=datetime.now().isoformat()
        )

        logger.info(f"🚀 DomainExpertTrainer inicializado para {domain.value}")
        logger.info(f"   Capas objetivo: {target_layers}")
        logger.info(f"   Expertos objetivo: {expert_indices}")

    def _load_base_model(self, model_path: str) -> EmpoorioLM:
        """Cargar modelo base EmpoorioLM."""
        model_path = Path(model_path)

        # Cargar configuración
        config_path = model_path / "config.json"
        if config_path.exists():
            with open(config_path, 'r') as f:
                config_dict = json.load(f)
            # Añadir campos faltantes con valores por defecto
            config_dict.setdefault("use_rope", False)
            config_dict.setdefault("max_context_size", 1024)
            config_dict.setdefault("use_lora", False)
            config_dict.setdefault("lora_r", 8)
            config_dict.setdefault("lora_alpha", 16.0)
            config_dict.setdefault("lora_dropout", 0.05)
            config_dict.setdefault("lora_target_modules", ["q_proj", "k_proj", "v_proj", "out_proj"])
            config_dict.setdefault("use_function_calling", False)
            config_dict.setdefault("tool_call_token", "<tool_call>")
            config_dict.setdefault("tool_call_end_token", "</tool_call>")
            config_dict.setdefault("max_tool_calls_per_response", 3)
            config_dict.setdefault("tool_choice", "auto")
            config_dict.setdefault("function_call_temperature", 0.1)
            config = EmpoorioLMConfig.from_dict(config_dict)
        else:
            logger.warning("Config no encontrada, usando configuración por defecto")
            config = EmpoorioLMConfig()

        # Cargar modelo
        model = EmpoorioLM(config)
        model_file = model_path / "pytorch_model.bin"
        if model_file.exists():
            state_dict = torch.load(model_file, map_location='cpu')
            model.load_state_dict(state_dict)
            logger.info(f"✅ Modelo base cargado desde {model_file}")
        else:
            logger.warning("Modelo no encontrado, usando pesos aleatorios")

        model.to(self.device)
        return model

    def _freeze_base_model(self):
        """Congelar el modelo base, dejando solo los expertos objetivo entrenables."""
        # Congelar todo primero
        for param in self.model.parameters():
            param.requires_grad = False

        # Descongelar expertos objetivo
        for layer_idx in self.target_layers:
            if layer_idx < len(self.model.blocks):
                block = self.model.blocks[layer_idx]
                if hasattr(block.ffn, 'experts'):  # Es una capa MoE
                    for expert_idx in self.expert_indices:
                        if expert_idx < len(block.ffn.experts):
                            expert = block.ffn.experts[expert_idx]
                            for param in expert.parameters():
                                param.requires_grad = True
                            logger.info(f"✅ Experto {expert_idx} en capa {layer_idx} descongelado")

        # Verificar parámetros entrenables
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.model.parameters())

        logger.info(f"📊 Parámetros entrenables: {trainable_params:,} / {total_params:,} "
                   f"({100*trainable_params/total_params:.1f}%)")

    def train(self,
              train_dataset: Dataset,
              num_epochs: int = 10,
              batch_size: int = 4,
              learning_rate: float = 1e-4,
              save_steps: int = 100):
        """Entrenar el experto especializado."""

        # Crear DataLoader
        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=0  # Para compatibilidad
        )

        # Optimizer solo para parámetros entrenables
        trainable_params = [p for p in self.model.parameters() if p.requires_grad]
        optimizer = AdamW(trainable_params, lr=learning_rate, weight_decay=0.01)

        # Scheduler
        scheduler = CosineAnnealingLR(optimizer, T_max=num_epochs * len(train_loader))

        # Tokenizer mock (en producción usar tokenizer real)
        tokenizer = MockTokenizer()

        self.model.train()
        global_step = 0
        best_loss = float('inf')

        logger.info("🏃 Iniciando entrenamiento del experto...")
        logger.info(f"   Épocas: {num_epochs}")
        logger.info(f"   Batch size: {batch_size}")
        logger.info(f"   Learning rate: {learning_rate}")

        for epoch in range(num_epochs):
            epoch_loss = 0.0
            num_batches = 0

            for batch_texts in train_loader:
                # Tokenizar batch
                batch_inputs = []
                batch_labels = []

                for text in batch_texts:
                    tokens = tokenizer.encode(text)
                    if len(tokens) > self.config.max_position_embeddings:
                        tokens = tokens[:self.config.max_position_embeddings]

                    # Pad/truncate
                    if len(tokens) < self.config.max_position_embeddings:
                        tokens.extend([0] * (self.config.max_position_embeddings - len(tokens)))

                    batch_inputs.append(tokens[:-1])  # Input (sin último token)
                    batch_labels.append(tokens[1:])   # Labels (sin primer token)

                input_ids = torch.tensor(batch_inputs, dtype=torch.long).to(self.device)
                labels = torch.tensor(batch_labels, dtype=torch.long).to(self.device)

                # Forward pass
                outputs = self.model(input_ids=input_ids, labels=labels)
                loss = outputs["loss"]

                # Backward pass
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
                scheduler.step()

                epoch_loss += loss.item()
                num_batches += 1
                global_step += 1

                # Logging
                if global_step % 10 == 0:
                    logger.info(f"Step {global_step}: Loss = {loss.item():.4f}")

                # Guardado periódico
                if global_step % save_steps == 0:
                    self._save_checkpoint(global_step, loss.item())

            # Fin de época
            avg_epoch_loss = epoch_loss / num_batches
            logger.info(f"Época {epoch+1}/{num_epochs}: Loss promedio = {avg_epoch_loss:.4f}")

            # Guardar mejor modelo
            if avg_epoch_loss < best_loss:
                best_loss = avg_epoch_loss
                self._save_checkpoint(global_step, best_loss, is_best=True)

        # Guardado final
        self._save_expert()
        logger.info("✅ Entrenamiento completado!")

        return {
            "final_loss": avg_epoch_loss,
            "best_loss": best_loss,
            "steps_trained": global_step,
            "expert_name": self.expert_name
        }

    def _save_checkpoint(self, step: int, loss: float, is_best: bool = False):
        """Guardar checkpoint del entrenamiento."""
        checkpoint_dir = self.output_dir / "checkpoints"
        checkpoint_dir.mkdir(exist_ok=True)

        checkpoint = {
            "step": step,
            "loss": loss,
            "expert_config": self.expert_config.to_dict(),
            "model_state_dict": self.model.state_dict()
        }

        if is_best:
            path = checkpoint_dir / "best_checkpoint.pt"
        else:
            path = checkpoint_dir / f"checkpoint_step_{step}.pt"

        torch.save(checkpoint, path)
        logger.info(f"💾 Checkpoint guardado: {path}")

    def _save_expert(self):
        """Guardar el experto entrenado en formato pluggable."""
        # Extraer solo los pesos de los expertos entrenados
        expert_weights = {}

        for layer_idx in self.target_layers:
            if layer_idx < len(self.model.blocks):
                block = self.model.blocks[layer_idx]
                if hasattr(block.ffn, 'experts'):
                    for expert_idx in self.expert_indices:
                        if expert_idx < len(block.ffn.experts):
                            expert = block.ffn.experts[expert_idx]
                            expert_key = f"expert_{expert_idx}"
                            expert_weights[expert_key] = expert.state_dict()

        # Crear gestor de expertos y guardar
        expert_manager = create_expert_manager(self.output_dir.parent)
        success = expert_manager.save_expert(
            self.expert_config,
            expert_weights,
            self.domain,
            self.expert_name
        )

        if success:
            logger.info(f"✅ Experto guardado: {self.domain.value}/{self.expert_name}")
        else:
            logger.error("❌ Error guardando experto")


class MockTokenizer:
    """Tokenizer mock para entrenamiento (reemplazar con tokenizer real)."""

    def __init__(self, vocab_size: int = 30000):
        self.vocab_size = vocab_size

    def encode(self, text: str) -> List[int]:
        """Codificación simple mock."""
        tokens = [1]  # BOS
        for char in text:
            token = ord(char) % (self.vocab_size - 2) + 2  # Evitar BOS/EOS
            tokens.append(token)
        tokens.append(2)  # EOS
        return tokens


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description="Entrenar experto especializado por dominio")
    parser.add_argument("--domain", required=True, choices=[d.value for d in Domain],
                       help="Dominio del experto")
    parser.add_argument("--target_layers", required=True, type=str,
                       help="Capas MoE a entrenar (ej: 4,7,10)")
    parser.add_argument("--expert_indices", required=True, type=str,
                       help="Índices de expertos a entrenar (ej: 6,7)")
    parser.add_argument("--model_path", required=True,
                       help="Ruta al modelo base EmpoorioLM")
    parser.add_argument("--output_dir", required=True,
                       help="Directorio de salida para el experto")
    parser.add_argument("--data_path", help="Ruta a datos reales (opcional)")
    parser.add_argument("--num_epochs", type=int, default=5, help="Número de épocas")
    parser.add_argument("--batch_size", type=int, default=4, help="Tamaño del batch")
    parser.add_argument("--learning_rate", type=float, default=1e-4, help="Learning rate")
    parser.add_argument("--device", default="auto", help="Dispositivo (auto/cuda/cpu)")

    args = parser.parse_args()

    # Parsear argumentos
    domain = Domain(args.domain)
    target_layers = [int(x.strip()) for x in args.target_layers.split(',')]
    expert_indices = [int(x.strip()) for x in args.expert_indices.split(',')]

    # Crear entrenador
    trainer = DomainExpertTrainer(
        domain=domain,
        target_layers=target_layers,
        expert_indices=expert_indices,
        model_path=args.model_path,
        output_dir=args.output_dir,
        device=args.device
    )

    # Crear dataset
    dataset = DomainDataset(domain, args.data_path)

    # Entrenar
    results = trainer.train(
        train_dataset=dataset,
        num_epochs=args.num_epochs,
        batch_size=args.batch_size,
        learning_rate=args.learning_rate
    )

    # Resultados
    print("\n🎉 Entrenamiento completado!")
    print(f"📊 Loss final: {results['final_loss']:.4f}")
    print(f"🏆 Mejor loss: {results['best_loss']:.4f}")
    print(f"📁 Experto guardado en: {args.output_dir}")
    print(f"🏷️  Nombre del experto: {results['expert_name']}")


if __name__ == "__main__":
    main()