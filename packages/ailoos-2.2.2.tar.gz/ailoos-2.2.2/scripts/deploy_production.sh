#!/bin/bash

# 🚀 AILOOS Production Deployment Script
# Deploys backend locally and frontend to Vercel

set -e

echo "🚀 Starting AILOOS Production Deployment"
echo "========================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
BACKEND_PORT=8000
FRONTEND_PORT=3000
DOMAIN="www.ailoos.com"

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if required tools are installed
check_dependencies() {
    print_status "Checking dependencies..."

    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is not installed. Please install Python 3.9+"
        exit 1
    fi

    if ! command -v pip &> /dev/null; then
        print_error "pip is not installed. Please install pip"
        exit 1
    fi

    if ! command -v vercel &> /dev/null; then
        print_warning "Vercel CLI not found. Installing..."
        npm install -g vercel
    fi

    print_success "Dependencies check passed"
}

# Setup backend for production
setup_backend() {
    print_status "Setting up backend for production..."

    cd "$(dirname "$0")/.."

    # Create production environment file
    cat > .env.production << EOF
# Production Environment for AILOOS Backend
# Running on local machine

# Server Configuration
HOST=0.0.0.0
PORT=${BACKEND_PORT}
WORKERS=4
RELOAD=false

# CORS Configuration
CORS_ORIGINS=["https://www.ailoos.com", "https://ailoos.com", "http://localhost:3000"]

# Database (SQLite for now - upgrade to PostgreSQL later)
DATABASE_URL=sqlite:///./data/ailoos_production.db

# Security
SECRET_KEY=$(openssl rand -hex 32)
JWT_SECRET_KEY=$(openssl rand -hex 32)

# IPFS (Optional)
IPFS_ENABLED=false

# Blockchain (Mock for now)
BLOCKCHAIN_ENABLED=false

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/ailoos_production.log

# Model Configuration
EMPOORIO_MODEL_PATH=./models/empoorio_lm/v1.0.0
VISION_MODEL_ENABLED=true

# API Keys (Add your real keys here)
OPENAI_API_KEY=your-openai-key-here
ANTHROPIC_API_KEY=your-anthropic-key-here
EOF

    # Create necessary directories
    mkdir -p data logs models/empoorio_lm/v1.0.0

    # Install production dependencies
    print_status "Installing backend dependencies..."
    pip install -r requirements-prod.txt

    print_success "Backend setup completed"
}

# Deploy backend
deploy_backend() {
    print_status "Deploying backend..."

    cd "$(dirname "$0")/.."

    # Kill any existing backend process
    pkill -f "python.*server.py" || true
    pkill -f "uvicorn.*gateway" || true

    # Start backend in production mode
    nohup python -m src.ailoos.api.gateway > logs/backend.log 2>&1 &
    BACKEND_PID=$!

    # Wait for backend to start
    print_status "Waiting for backend to start..."
    sleep 10

    # Check if backend is running
    if curl -f http://localhost:${BACKEND_PORT}/v1/health > /dev/null 2>&1; then
        print_success "Backend deployed successfully on port ${BACKEND_PORT}"
        print_status "Backend PID: ${BACKEND_PID}"
        print_status "Backend logs: tail -f logs/backend.log"
    else
        print_error "Backend failed to start. Check logs/backend.log"
        exit 1
    fi
}

# Setup frontend for production
setup_frontend() {
    print_status "Setting up frontend for production..."

    cd "$(dirname "$0")/../frontend"

    # Install dependencies
    if command -v bun &> /dev/null; then
        bun install
    else
        npm install
    fi

    # Build frontend
    print_status "Building frontend..."
    if command -v bun &> /dev/null; then
        bun run build
    else
        npm run build
    fi

    print_success "Frontend built successfully"
}

# Deploy frontend to Vercel
deploy_frontend() {
    print_status "Deploying frontend to Vercel..."

    cd "$(dirname "$0")/../frontend"

    # Check if Vercel is logged in
    if ! vercel whoami > /dev/null 2>&1; then
        print_warning "Not logged in to Vercel. Please run 'vercel login' first"
        print_status "Opening browser for Vercel login..."
        vercel login
    fi

    # Deploy to Vercel
    print_status "Deploying to Vercel..."
    vercel --prod

    # Get deployment URL
    DEPLOYMENT_URL=$(vercel --prod 2>&1 | grep -o 'https://[^ ]*\.vercel\.app')

    if [ -n "$DEPLOYMENT_URL" ]; then
        print_success "Frontend deployed to: $DEPLOYMENT_URL"
        print_status "Configure DNS to point www.ailoos.com and ailoos.com to this URL"
    else
        print_warning "Could not get deployment URL. Check Vercel dashboard manually"
    fi
}

# Setup domain configuration
setup_domains() {
    print_status "Domain Configuration Instructions:"
    echo ""
    echo "1. Go to your DNS provider (GoDaddy, Namecheap, etc.)"
    echo "2. Add CNAME records for:"
    echo "   - www.ailoos.com → your-vercel-deployment-url.vercel.app"
    echo "   - ailoos.com → your-vercel-deployment-url.vercel.app"
    echo ""
    echo "3. In Vercel dashboard:"
    echo "   - Add custom domains: www.ailoos.com and ailoos.com"
    echo "   - Enable SSL certificates"
    echo ""
    print_success "Domain setup instructions displayed"
}

# Main deployment function
main() {
    echo "AILOOS Production Deployment"
    echo "============================"
    echo ""
    echo "This script will:"
    echo "1. Setup backend for production on your local machine"
    echo "2. Deploy backend as a service on port ${BACKEND_PORT}"
    echo "3. Build and deploy frontend to Vercel"
    echo "4. Provide domain configuration instructions"
    echo ""

    read -p "Continue with deployment? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_status "Deployment cancelled"
        exit 0
    fi

    check_dependencies
    setup_backend
    deploy_backend
    setup_frontend
    deploy_frontend
    setup_domains

    echo ""
    print_success "🎉 AILOOS Production Deployment Completed!"
    echo ""
    echo "Your application is now running:"
    echo "- Backend: http://localhost:${BACKEND_PORT} (internal)"
    echo "- Frontend: https://www.ailoos.com (after DNS setup)"
    echo "- Health Check: curl http://localhost:${BACKEND_PORT}/v1/health"
    echo ""
    echo "Next steps:"
    echo "1. Configure DNS records for your domains"
    echo "2. Test the application at https://www.ailoos.com"
    echo "3. Monitor logs: tail -f logs/backend.log"
}

# Run main function
main "$@"