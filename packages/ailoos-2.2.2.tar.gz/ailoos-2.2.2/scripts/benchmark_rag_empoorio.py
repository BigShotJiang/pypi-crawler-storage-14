#!/usr/bin/env python3
"""
RAG + EmpoorioLM Performance Benchmark

This script provides comprehensive performance benchmarking for the RAG system
with EmpoorioLM integration, comparing different configurations and workloads.
"""

import time
import asyncio
import statistics
from typing import Dict, Any, List, Optional
import json
import argparse
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class RAGEmpoorioBenchmark:
    """Benchmark suite for RAG + EmpoorioLM integration."""

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize benchmark suite.

        Args:
            config (Dict[str, Any): Benchmark configuration
        """
        self.config = config
        self.results = {}
        self.test_queries = config.get('test_queries', self._get_default_queries())
        self.test_contexts = config.get('test_contexts', self._get_default_contexts())

    def _get_default_queries(self) -> List[str]:
        """Get default test queries."""
        return [
            "¿Qué es la inteligencia artificial?",
            "¿Cómo funciona el aprendizaje automático?",
            "¿Cuáles son las aplicaciones de la IA en medicina?",
            "¿Qué es el procesamiento de lenguaje natural?",
            "¿Cómo se entrena un modelo de IA?",
            "¿Cuáles son las diferencias entre IA y machine learning?",
            "¿Qué es deep learning?",
            "¿Cómo se evalúa el rendimiento de un modelo de IA?",
            "¿Qué son las redes neuronales?",
            "¿Cuáles son los desafíos éticos de la IA?"
        ]

    def _get_default_contexts(self) -> List[List[Dict[str, Any]]]:
        """Get default test contexts."""
        return [
            [
                {
                    'content': 'La inteligencia artificial (IA) es una rama de la informática que busca crear máquinas capaces de realizar tareas que requieren inteligencia humana.',
                    'source': 'ai_basics',
                    'score': 0.95
                },
                {
                    'content': 'El aprendizaje automático es un subcampo de la IA que permite a los sistemas aprender automáticamente de los datos sin ser programados explícitamente.',
                    'source': 'ml_intro',
                    'score': 0.90
                }
            ],
            [
                {
                    'content': 'El procesamiento de lenguaje natural (NLP) es una rama de la IA que se enfoca en la interacción entre computadoras y lenguaje humano.',
                    'source': 'nlp_guide',
                    'score': 0.92
                }
            ]
        ]

    def run_comprehensive_benchmark(self) -> Dict[str, Any]:
        """Run comprehensive benchmark suite."""
        logger.info("🚀 Starting comprehensive RAG + EmpoorioLM benchmark")

        results = {
            'timestamp': time.time(),
            'configuration': self.config,
            'tests': {}
        }

        # Test different configurations
        configurations = self._get_test_configurations()

        for config_name, config in configurations.items():
            logger.info(f"📊 Testing configuration: {config_name}")
            test_results = self._run_configuration_tests(config_name, config)
            results['tests'][config_name] = test_results

        # Generate comparison report
        results['comparison'] = self._generate_comparison_report(results['tests'])

        # Save results
        self._save_results(results)

        logger.info("✅ Benchmark completed")
        return results

    def _get_test_configurations(self) -> Dict[str, Dict[str, Any]]:
        """Get different configurations to test."""
        base_config = {
            'retriever_class': 'MockRetriever',
            'generator_class': 'EmpoorioLMGenerator',
            'evaluator_class': 'MockEvaluator',
            'retriever_config': {'mock_data': True},
            'evaluator_config': {'mock_evaluation': True},
            'generator_config': {
                'empoorio_api_config': {
                    'model_path': './models/empoorio_lm',
                    'device': 'cpu'
                }
            }
        }

        return {
            'baseline': {
                **base_config,
                'generator_config': {
                    **base_config['generator_config'],
                    'rate_limiting': {'enabled': False},
                    'caching': {'enabled': False},
                    'conversation': {'enabled': False},
                    'fallback': {'enabled': False},
                    'metrics': {'enabled': False},
                    'ab_testing': {'enabled': False}
                }
            },
            'with_caching': {
                **base_config,
                'generator_config': {
                    **base_config['generator_config'],
                    'rate_limiting': {'enabled': False},
                    'caching': {'enabled': True, 'max_size': 100, 'ttl_seconds': 3600},
                    'conversation': {'enabled': False},
                    'fallback': {'enabled': False},
                    'metrics': {'enabled': False},
                    'ab_testing': {'enabled': False}
                }
            },
            'with_fallback': {
                **base_config,
                'generator_config': {
                    **base_config['generator_config'],
                    'rate_limiting': {'enabled': False},
                    'caching': {'enabled': False},
                    'conversation': {'enabled': False},
                    'fallback': {'enabled': True},
                    'metrics': {'enabled': False},
                    'ab_testing': {'enabled': False}
                }
            },
            'full_features': {
                **base_config,
                'generator_config': {
                    **base_config['generator_config'],
                    'rate_limiting': {'enabled': True, 'requests_per_minute': 100},
                    'caching': {'enabled': True, 'max_size': 100, 'ttl_seconds': 3600},
                    'conversation': {'enabled': True, 'max_turns': 10},
                    'fallback': {'enabled': True},
                    'metrics': {'enabled': True},
                    'ab_testing': {'enabled': False}
                }
            }
        }

    def _run_configuration_tests(self, config_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run tests for a specific configuration."""
        test_results = {
            'single_query_tests': self._run_single_query_tests(config),
            'concurrent_tests': self._run_concurrent_tests(config),
            'stress_tests': self._run_stress_tests(config),
            'memory_tests': self._run_memory_tests(config)
        }

        return test_results

    def _run_single_query_tests(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run single query performance tests."""
        from src.ailoos.rag.techniques.naive_rag import NaiveRAG

        # Mock the components for testing
        with self._mock_components():
            rag = NaiveRAG(config)

            results = []
            for i, query in enumerate(self.test_queries[:5]):  # Test first 5 queries
                context = self.test_contexts[i % len(self.test_contexts)]

                start_time = time.time()
                try:
                    result = rag.run(query, top_k=3)
                    end_time = time.time()

                    results.append({
                        'query_id': i,
                        'query': query,
                        'success': True,
                        'response_time': end_time - start_time,
                        'response_length': len(result.get('response', '')),
                        'context_count': len(result.get('context', []))
                    })
                except Exception as e:
                    end_time = time.time()
                    results.append({
                        'query_id': i,
                        'query': query,
                        'success': False,
                        'response_time': end_time - start_time,
                        'error': str(e)
                    })

            # Calculate statistics
            successful_results = [r for r in results if r['success']]
            response_times = [r['response_time'] for r in successful_results]

            return {
                'individual_results': results,
                'summary': {
                    'total_queries': len(results),
                    'successful_queries': len(successful_results),
                    'success_rate': len(successful_results) / len(results) if results else 0,
                    'avg_response_time': statistics.mean(response_times) if response_times else 0,
                    'median_response_time': statistics.median(response_times) if response_times else 0,
                    'min_response_time': min(response_times) if response_times else 0,
                    'max_response_time': max(response_times) if response_times else 0,
                    'p95_response_time': statistics.quantiles(response_times, n=20)[18] if len(response_times) >= 20 else max(response_times) if response_times else 0
                }
            }

    def _run_concurrent_tests(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run concurrent request tests."""
        import concurrent.futures
        from src.ailoos.rag.techniques.naive_rag import NaiveRAG

        concurrency_levels = [1, 5, 10, 20]
        results = {}

        for concurrency in concurrency_levels:
            logger.info(f"Testing concurrency level: {concurrency}")

            with self._mock_components():
                rag = NaiveRAG(config)

                def run_single_query(query_id):
                    query = self.test_queries[query_id % len(self.test_queries)]
                    context = self.test_contexts[query_id % len(self.test_contexts)]

                    start_time = time.time()
                    try:
                        result = rag.run(query, top_k=3)
                        end_time = time.time()
                        return {
                            'query_id': query_id,
                            'success': True,
                            'response_time': end_time - start_time
                        }
                    except Exception as e:
                        end_time = time.time()
                        return {
                            'query_id': query_id,
                            'success': False,
                            'response_time': end_time - start_time,
                            'error': str(e)
                        }

                # Run concurrent requests
                start_time = time.time()
                with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as executor:
                    futures = [executor.submit(run_single_query, i) for i in range(concurrency * 2)]
                    concurrent_results = [future.result() for future in concurrent.futures.as_completed(futures)]
                end_time = time.time()

                total_time = end_time - start_time
                response_times = [r['response_time'] for r in concurrent_results if r['success']]

                results[f'concurrency_{concurrency}'] = {
                    'concurrency_level': concurrency,
                    'total_requests': len(concurrent_results),
                    'successful_requests': len([r for r in concurrent_results if r['success']]),
                    'total_time': total_time,
                    'avg_response_time': statistics.mean(response_times) if response_times else 0,
                    'requests_per_second': len(concurrent_results) / total_time if total_time > 0 else 0
                }

        return results

    def _run_stress_tests(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run stress tests with high load."""
        from src.ailoos.rag.techniques.naive_rag import NaiveRAG

        stress_levels = [50, 100, 200]  # Number of requests
        results = {}

        for num_requests in stress_levels:
            logger.info(f"Running stress test with {num_requests} requests")

            with self._mock_components():
                rag = NaiveRAG(config)

                start_time = time.time()
                successful_requests = 0
                failed_requests = 0
                response_times = []

                for i in range(num_requests):
                    try:
                        query = self.test_queries[i % len(self.test_queries)]
                        context = self.test_contexts[i % len(self.test_contexts)]

                        req_start = time.time()
                        result = rag.run(query, top_k=3)
                        req_end = time.time()

                        response_times.append(req_end - req_start)
                        successful_requests += 1

                    except Exception as e:
                        failed_requests += 1
                        logger.debug(f"Request {i} failed: {str(e)}")

                end_time = time.time()
                total_time = end_time - start_time

                results[f'stress_{num_requests}'] = {
                    'num_requests': num_requests,
                    'successful_requests': successful_requests,
                    'failed_requests': failed_requests,
                    'success_rate': successful_requests / num_requests,
                    'total_time': total_time,
                    'avg_response_time': statistics.mean(response_times) if response_times else 0,
                    'requests_per_second': num_requests / total_time if total_time > 0 else 0,
                    'p95_response_time': statistics.quantiles(response_times, n=20)[18] if len(response_times) >= 20 else max(response_times) if response_times else 0
                }

        return results

    def _run_memory_tests(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Run memory usage tests."""
        import psutil
        import os
        from src.ailoos.rag.techniques.naive_rag import NaiveRAG

        process = psutil.Process(os.getpid())

        # Baseline memory
        baseline_memory = process.memory_info().rss / 1024 / 1024  # MB

        with self._mock_components():
            rag = NaiveRAG(config)

            # Memory after initialization
            init_memory = process.memory_info().rss / 1024 / 1024

            # Memory during operation
            peak_memory = init_memory
            for i in range(20):  # Run 20 queries
                query = self.test_queries[i % len(self.test_queries)]
                context = self.test_contexts[i % len(self.test_contexts)]

                result = rag.run(query, top_k=3)
                current_memory = process.memory_info().rss / 1024 / 1024
                peak_memory = max(peak_memory, current_memory)

            # Memory after operation
            final_memory = process.memory_info().rss / 1024 / 1024

            return {
                'baseline_memory_mb': baseline_memory,
                'init_memory_mb': init_memory,
                'peak_memory_mb': peak_memory,
                'final_memory_mb': final_memory,
                'memory_increase_mb': peak_memory - baseline_memory,
                'memory_leak_mb': final_memory - init_memory
            }

    def _mock_components(self):
        """Context manager to mock RAG components for testing."""
        from unittest.mock import patch, Mock

        # Mock EmpoorioLM API
        mock_api = Mock()
        mock_api.generate_text.return_value = {
            'generated_text': 'Esta es una respuesta de prueba generada por el sistema de benchmarking. Contiene información relevante sobre la consulta realizada.',
            'success': True
        }

        # Mock retriever
        def mock_search(query, top_k=5, filters=None):
            context = self.test_contexts[0][:top_k]  # Return first top_k contexts
            return [(doc, doc['score']) for doc in context]

        mock_retriever = Mock()
        mock_retriever.search = mock_search

        # Mock evaluator
        mock_evaluator = Mock()
        mock_evaluator.evaluate.return_value = {
            'relevance': 0.85,
            'faithfulness': 0.90,
            'coherence': 0.80,
            'helpfulness': 0.88,
            'overall_score': 0.86
        }

        return patch.multiple(
            'src.ailoos.rag.techniques.naive_rag',
            EmpoorioLMApi=lambda *args, **kwargs: mock_api,
            VectorRetriever=lambda *args, **kwargs: mock_retriever,
            BasicRAGEvaluator=lambda *args, **kwargs: mock_evaluator
        )

    def _generate_comparison_report(self, test_results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comparison report across configurations."""
        comparison = {
            'performance_comparison': {},
            'feature_comparison': {},
            'recommendations': []
        }

        # Compare performance metrics
        for config_name, results in test_results.items():
            single_tests = results.get('single_query_tests', {})
            summary = single_tests.get('summary', {})

            comparison['performance_comparison'][config_name] = {
                'avg_response_time': summary.get('avg_response_time', 0),
                'success_rate': summary.get('success_rate', 0),
                'p95_response_time': summary.get('p95_response_time', 0)
            }

        # Feature comparison
        feature_matrix = {
            'baseline': ['basic_generation'],
            'with_caching': ['basic_generation', 'response_caching'],
            'with_fallback': ['basic_generation', 'error_recovery'],
            'full_features': ['basic_generation', 'response_caching', 'error_recovery',
                            'rate_limiting', 'conversation_context', 'metrics_collection']
        }

        comparison['feature_comparison'] = feature_matrix

        # Generate recommendations
        if test_results:
            # Find best performing configuration
            best_config = min(
                comparison['performance_comparison'].items(),
                key=lambda x: x[1]['avg_response_time']
            )[0]

            comparison['recommendations'].append(f"Best performance: {best_config}")

            # Check for significant performance differences
            configs = list(comparison['performance_comparison'].keys())
            if len(configs) >= 2:
                times = [comparison['performance_comparison'][c]['avg_response_time'] for c in configs]
                if max(times) / min(times) > 2:  # 2x difference
                    comparison['recommendations'].append("Consider caching for better performance")

        return comparison

    def _save_results(self, results: Dict[str, Any], output_file: Optional[str] = None):
        """Save benchmark results to file."""
        if output_file is None:
            timestamp = time.strftime('%Y%m%d_%H%M%S')
            output_file = f'benchmark_results_{timestamp}.json'

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

        logger.info(f"📊 Benchmark results saved to: {output_file}")

        # Generate human-readable summary
        self._generate_summary_report(results, output_file.replace('.json', '_summary.txt'))

    def _generate_summary_report(self, results: Dict[str, Any], summary_file: str):
        """Generate human-readable summary report."""
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write("🚀 RAG + EmpoorioLM Benchmark Summary Report\n")
            f.write("=" * 50 + "\n\n")

            f.write(f"📅 Benchmark Date: {time.ctime(results['timestamp'])}\n\n")

            f.write("📊 Configuration Comparison:\n")
            f.write("-" * 30 + "\n")

            comparison = results.get('comparison', {})
            perf_comp = comparison.get('performance_comparison', {})

            for config, metrics in perf_comp.items():
                f.write(f"\n🔧 {config.upper()}:\n")
                f.write(f"  ⏱️  Avg Response Time: {metrics['avg_response_time']:.4f}s\n")
                f.write(f"  ✅ Success Rate: {metrics['success_rate']:.1%}\n")
                f.write(f"  📊 P95 Response Time: {metrics['p95_response_time']:.4f}s\n")

            f.write("\n🎯 Recommendations:\n")
            f.write("-" * 20 + "\n")
            for rec in comparison.get('recommendations', []):
                f.write(f"• {rec}\n")

            f.write("\n✨ Key Findings:\n")
            f.write("-" * 15 + "\n")

            if perf_comp:
                best_config = min(perf_comp.items(), key=lambda x: x[1]['avg_response_time'])[0]
                worst_config = max(perf_comp.items(), key=lambda x: x[1]['avg_response_time'])[0]

                f.write(f"• Best performing configuration: {best_config}\n")
                f.write(f"• Configuration with slowest responses: {worst_config}\n")

                # Calculate improvement
                best_time = perf_comp[best_config]['avg_response_time']
                worst_time = perf_comp[worst_config]['avg_response_time']
                if worst_time > 0:
                    improvement = (worst_time - best_time) / worst_time * 100
                    f.write(f"• Performance improvement: {improvement:.1f}%\n")

        logger.info(f"📋 Summary report saved to: {summary_file}")


def main():
    """Main benchmark execution function."""
    parser = argparse.ArgumentParser(description='RAG + EmpoorioLM Performance Benchmark')
    parser.add_argument('--config', type=str, help='Path to benchmark configuration file')
    parser.add_argument('--output', type=str, help='Output file for results')
    parser.add_argument('--quick', action='store_true', help='Run quick benchmark (reduced test set)')

    args = parser.parse_args()

    # Load configuration
    config = {}
    if args.config and Path(args.config).exists():
        with open(args.config, 'r') as f:
            config = json.load(f)

    # Apply quick mode settings
    if args.quick:
        config['test_queries'] = [
            "¿Qué es la inteligencia artificial?",
            "¿Cómo funciona el aprendizaje automático?",
            "¿Qué es el procesamiento de lenguaje natural?"
        ]
        config['concurrency_levels'] = [1, 5]
        config['stress_levels'] = [10, 25]

    # Run benchmark
    benchmark = RAGEmpoorioBenchmark(config)
    results = benchmark.run_comprehensive_benchmark()

    # Save with custom output if specified
    if args.output:
        benchmark._save_results(results, args.output)

    # Print summary
    print("\n🎉 Benchmark completed successfully!")
    print(f"📊 Results saved to: {args.output or 'benchmark_results_*.json'}")

    return results


if __name__ == '__main__':
    main()