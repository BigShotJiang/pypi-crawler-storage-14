#!/bin/bash

# Script para verificar que todas las credenciales necesarias estén configuradas en Vercel
# Requiere que Vercel CLI esté instalado y autenticado

set -e

echo "=== Verificación de Variables de Entorno en Vercel ==="
echo ""

# Cambiar al directorio frontend
cd frontend 2>/dev/null || {
    echo "❌ No se puede acceder al directorio frontend"
    exit 1
}

# Verificar si Vercel CLI está instalado
if ! command -v vercel &> /dev/null; then
    echo "❌ Vercel CLI no está instalado."
    echo "Instálalo con: npm i -g vercel"
    exit 1
fi

# Verificar si estamos autenticados
if ! vercel whoami &> /dev/null; then
    echo "❌ No estás autenticado en Vercel."
    echo "Ejecuta: vercel login"
    exit 1
fi

echo "✅ Vercel CLI detectado y autenticado"
echo ""

# Lista de variables requeridas
REQUIRED_VARS=(
    "AUTH_SECRET"
    "DATABASE_URL"
    "BLOB_READ_WRITE_TOKEN"
    "AI_GATEWAY_API_KEY"
)

# Variables opcionales pero recomendadas
OPTIONAL_VARS=(
    "GCP_PROJECT_ID"
    "GCP_SA_KEY"
    "REDIS_URL"
    "STORAGE_BUCKET"
    "ENVIRONMENT"
    "DOMAIN"
)

echo "Verificando variables requeridas..."
echo ""

MISSING_REQUIRED=()
MISSING_OPTIONAL=()

# Obtener lista de variables de entorno
ENV_VARS=$(vercel env ls 2>/dev/null | tail -n +4 | awk '{print $1}' | grep -E '^[A-Z_]+' || echo "")

for var in "${REQUIRED_VARS[@]}"; do
    # Verificar si la variable existe en cualquier ambiente
    if vercel env ls 2>/dev/null | grep -q "$var"; then
        echo "✅ $var - Configurada"
    else
        echo "❌ $var - FALTANTE"
        MISSING_REQUIRED+=("$var")
    fi
done

echo ""
echo "Verificando variables opcionales..."
echo ""

for var in "${OPTIONAL_VARS[@]}"; do
    if echo "$ENV_VARS" | grep -q "^$var$"; then
        echo "✅ $var - Configurada"
    else
        echo "⚠️  $var - No configurada (opcional)"
        MISSING_OPTIONAL+=("$var")
    fi
done

echo ""
echo "=== Resumen ==="

if [ ${#MISSING_REQUIRED[@]} -eq 0 ]; then
    echo "✅ Todas las variables requeridas están configuradas"
else
    echo "❌ Faltan ${#MISSING_REQUIRED[@]} variables requeridas:"
    for var in "${MISSING_REQUIRED[@]}"; do
        echo "   - $var"
    done
fi

if [ ${#MISSING_OPTIONAL[@]} -gt 0 ]; then
    echo "⚠️  ${#MISSING_OPTIONAL[@]} variables opcionales no configuradas:"
    for var in "${MISSING_OPTIONAL[@]}"; do
        echo "   - $var"
    done
fi

echo ""
if [ ${#MISSING_REQUIRED[@]} -eq 0 ]; then
    echo "🎉 ¡Todas las credenciales requeridas están listas para el despliegue!"
else
    echo "Para configurar las variables faltantes:"
    echo "  vercel env add VARIABLE_NAME"
    echo ""
    echo "O desde el dashboard: Proyecto > Settings > Environment Variables"
fi