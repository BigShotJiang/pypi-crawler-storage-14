"""
Protocolo de sincronización de estado para coordinadores distribuidos.
Implementa vector clocks, resolución de conflictos y recuperación de particiones.
"""

import asyncio
import json
import time
import hashlib
import logging
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass, asdict, field
from enum import Enum
import threading
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)


class ConflictResolutionStrategy(Enum):
    """Estrategias para resolución de conflictos."""
    LATEST_WRITER_WINS = "latest_writer_wins"
    MANUAL_MERGE = "manual_merge"
    VECTOR_CLOCK_PRIORITY = "vector_clock_priority"


@dataclass
class VectorClock:
    """Vector clock para control de versiones distribuido."""
    node_id: str
    counters: Dict[str, int] = field(default_factory=dict)

    def increment(self, node_id: str) -> 'VectorClock':
        """Incrementa el contador para un nodo."""
        new_counters = self.counters.copy()
        new_counters[node_id] = new_counters.get(node_id, 0) + 1
        return VectorClock(node_id=node_id, counters=new_counters)

    def merge(self, other: 'VectorClock') -> 'VectorClock':
        """Fusiona dos vector clocks."""
        merged_counters = self.counters.copy()
        for node_id, counter in other.counters.items():
            merged_counters[node_id] = max(merged_counters.get(node_id, 0), counter)
        return VectorClock(node_id=self.node_id, counters=merged_counters)

    def compare(self, other: 'VectorClock') -> int:
        """
        Compara dos vector clocks.
        Returns:
            -1 si self < other
             0 si self == other
             1 si self > other
             None si incomparable
        """
        self_greater = False
        other_greater = False

        all_nodes = set(self.counters.keys()) | set(other.counters.keys())

        for node in all_nodes:
            self_count = self.counters.get(node, 0)
            other_count = other.counters.get(node, 0)

            if self_count > other_count:
                self_greater = True
            elif other_count > self_count:
                other_greater = True

        if self_greater and not other_greater:
            return 1
        elif other_greater and not self_greater:
            return -1
        elif not self_greater and not other_greater:
            return 0
        else:
            return None  # Incomparable

    def __str__(self) -> str:
        return f"VC({self.node_id}: {self.counters})"


@dataclass
class StateUpdate:
    """Actualización de estado con metadatos de versión."""
    update_id: str
    node_id: str
    timestamp: float
    vector_clock: VectorClock
    operation: str  # 'create', 'update', 'delete'
    key: str
    value: Any
    checksum: str = ""

    def __post_init__(self):
        if not self.checksum:
            self.checksum = self._calculate_checksum()

    def _calculate_checksum(self) -> str:
        """Calcula checksum del contenido de la actualización."""
        content = {
            'update_id': self.update_id,
            'node_id': self.node_id,
            'timestamp': self.timestamp,
            'operation': self.operation,
            'key': self.key,
            'value': self.value
        }
        content_str = json.dumps(content, sort_keys=True, default=str)
        return hashlib.sha256(content_str.encode()).hexdigest()

    def is_valid(self) -> bool:
        """Verifica la integridad de la actualización."""
        return self.checksum == self._calculate_checksum()


@dataclass
class Conflict:
    """Representa un conflicto entre actualizaciones."""
    key: str
    local_update: StateUpdate
    remote_update: StateUpdate
    detected_at: float = field(default_factory=time.time)

    def resolve(self, strategy: ConflictResolutionStrategy) -> StateUpdate:
        """Resuelve el conflicto usando la estrategia especificada."""
        if strategy == ConflictResolutionStrategy.LATEST_WRITER_WINS:
            return self.local_update if self.local_update.timestamp > self.remote_update.timestamp else self.remote_update

        elif strategy == ConflictResolutionStrategy.VECTOR_CLOCK_PRIORITY:
            comparison = self.local_update.vector_clock.compare(self.remote_update.vector_clock)
            if comparison == 1:
                return self.local_update
            elif comparison == -1:
                return self.remote_update
            else:
                # Si son iguales o incomparable, usar timestamp
                return self.local_update if self.local_update.timestamp > self.remote_update.timestamp else self.remote_update

        else:  # MANUAL_MERGE - por defecto, mantener local
            return self.local_update


class StateSync:
    """
    Protocolo de sincronización de estado para coordinadores distribuidos.
    Maneja consistencia eventual con vector clocks y resolución de conflictos.
    """

    def __init__(self, node_id: str, conflict_strategy: ConflictResolutionStrategy = ConflictResolutionStrategy.VECTOR_CLOCK_PRIORITY):
        self.node_id = node_id
        self.conflict_strategy = conflict_strategy

        # Estado local
        self.local_state: Dict[str, Any] = {}
        self.vector_clock = VectorClock(node_id=node_id)
        self.pending_updates: List[StateUpdate] = []
        self.conflicts: List[Conflict] = []

        # Historial de actualizaciones
        self.update_history: Dict[str, StateUpdate] = {}
        self.state_versions: Dict[str, VectorClock] = {}

        # Configuración de sincronización
        self.sync_interval = 30.0  # segundos
        self.max_retry_attempts = 3
        self.partition_recovery_timeout = 300.0  # 5 minutos

        # Componentes de red
        self.peers: Set[str] = set()
        self.last_sync_times: Dict[str, float] = {}
        self.network_partitions: Dict[str, float] = {}  # peer -> tiempo de detección

        # Locks para thread safety
        self.state_lock = threading.RLock()
        self.sync_lock = threading.RLock()

        # Executor para operaciones asíncronas
        self.executor = ThreadPoolExecutor(max_workers=4)

        logger.info(f"🔄 StateSync inicializado para nodo {node_id}")

    async def start_sync_service(self):
        """Inicia el servicio de sincronización."""
        asyncio.create_task(self._periodic_sync())
        asyncio.create_task(self._partition_recovery_monitor())
        logger.info("🚀 Servicio de sincronización iniciado")

    async def stop_sync_service(self):
        """Detiene el servicio de sincronización."""
        self.executor.shutdown(wait=True)
        logger.info("🛑 Servicio de sincronización detenido")

    def update_local_state(self, key: str, value: Any, operation: str = 'update') -> StateUpdate:
        """
        Actualiza el estado local y crea una actualización.

        Args:
            key: Clave del estado a actualizar
            value: Nuevo valor
            operation: Tipo de operación ('create', 'update', 'delete')

        Returns:
            StateUpdate creado
        """
        with self.state_lock:
            # Incrementar vector clock
            self.vector_clock = self.vector_clock.increment(self.node_id)

            # Aplicar cambio local
            if operation == 'delete':
                if key in self.local_state:
                    del self.local_state[key]
            else:
                self.local_state[key] = value

            # Crear actualización
            update = StateUpdate(
                update_id=f"{self.node_id}_{int(time.time() * 1000)}",
                node_id=self.node_id,
                timestamp=time.time(),
                vector_clock=self.vector_clock,
                operation=operation,
                key=key,
                value=value
            )

            # Almacenar en historial
            self.update_history[update.update_id] = update
            self.state_versions[key] = self.vector_clock

            # Agregar a pendientes para sincronización
            self.pending_updates.append(update)

            logger.info(f"📝 Estado local actualizado: {key} = {value} (op: {operation})")
            return update

    async def synchronize_with_peer(self, peer_id: str, peer_state: Dict[str, Any],
                                  peer_updates: List[Dict[str, Any]]) -> Tuple[bool, List[Conflict]]:
        """
        Sincroniza estado con un peer.

        Args:
            peer_id: ID del peer
            peer_state: Estado actual del peer
            peer_updates: Lista de actualizaciones del peer

        Returns:
            (éxito, conflictos detectados)
        """
        with self.sync_lock:
            conflicts = []
            success = True

            try:
                # Convertir actualizaciones remotas
                remote_updates = []
                for update_dict in peer_updates:
                    try:
                        vc_dict = update_dict['vector_clock']
                        vector_clock = VectorClock(
                            node_id=vc_dict['node_id'],
                            counters=vc_dict['counters']
                        )
                        update = StateUpdate(
                            update_id=update_dict['update_id'],
                            node_id=update_dict['node_id'],
                            timestamp=update_dict['timestamp'],
                            vector_clock=vector_clock,
                            operation=update_dict['operation'],
                            key=update_dict['key'],
                            value=update_dict['value'],
                            checksum=update_dict.get('checksum', '')
                        )
                        if update.is_valid():
                            remote_updates.append(update)
                        else:
                            logger.warning(f"⚠️ Actualización inválida de {peer_id}: {update.update_id}")
                    except Exception as e:
                        logger.error(f"❌ Error procesando actualización de {peer_id}: {e}")

                # Detectar conflictos y fusionar
                merged_updates, detected_conflicts = self._merge_updates(remote_updates)
                conflicts.extend(detected_conflicts)

                # Aplicar actualizaciones fusionadas
                for update in merged_updates:
                    await self._apply_update(update)

                # Actualizar vector clock
                for update in remote_updates:
                    self.vector_clock = self.vector_clock.merge(update.vector_clock)

                # Limpiar actualizaciones pendientes ya sincronizadas
                self._cleanup_pending_updates(peer_id, remote_updates)

                # Actualizar tiempo de última sincronización
                self.last_sync_times[peer_id] = time.time()

                # Remover de particiones si estaba marcado
                if peer_id in self.network_partitions:
                    del self.network_partitions[peer_id]
                    logger.info(f"🔄 Partición de red resuelta con {peer_id}")

                logger.info(f"✅ Sincronización exitosa con {peer_id} ({len(merged_updates)} actualizaciones)")

            except Exception as e:
                logger.error(f"❌ Error sincronizando con {peer_id}: {e}")
                success = False

                # Marcar como partición de red si falla persistentemente
                if peer_id not in self.network_partitions:
                    self.network_partitions[peer_id] = time.time()
                    logger.warning(f"⚠️ Partición de red detectada con {peer_id}")

            return success, conflicts

    def _merge_updates(self, remote_updates: List[StateUpdate]) -> Tuple[List[StateUpdate], List[Conflict]]:
        """
        Fusiona actualizaciones remotas con el estado local, detectando conflictos.

        Returns:
            (actualizaciones fusionadas, conflictos detectados)
        """
        merged_updates = []
        conflicts = []

        for remote_update in remote_updates:
            key = remote_update.key

            # Verificar si ya tenemos esta actualización
            if remote_update.update_id in self.update_history:
                continue

            # Verificar versión local
            local_vc = self.state_versions.get(key)
            if local_vc:
                comparison = local_vc.compare(remote_update.vector_clock)

                if comparison == 0:
                    # Mismas versiones - no hay conflicto
                    continue
                elif comparison is None:
                    # Versiones incomparable - posible conflicto
                    local_update = self._find_last_update_for_key(key)
                    if local_update:
                        conflict = Conflict(
                            key=key,
                            local_update=local_update,
                            remote_update=remote_update
                        )
                        conflicts.append(conflict)
                        # Resolver conflicto
                        resolved_update = conflict.resolve(self.conflict_strategy)
                        merged_updates.append(resolved_update)
                        logger.warning(f"⚠️ Conflicto resuelto para {key}: {resolved_update.update_id}")
                    else:
                        merged_updates.append(remote_update)
                elif comparison < 0:
                    # Versión remota más nueva
                    merged_updates.append(remote_update)
                # Si local > remote, ignorar actualización remota
            else:
                # Nueva clave
                merged_updates.append(remote_update)

        return merged_updates, conflicts

    async def _apply_update(self, update: StateUpdate):
        """Aplica una actualización al estado local."""
        with self.state_lock:
            if update.operation == 'delete':
                if update.key in self.local_state:
                    del self.local_state[update.key]
            else:
                self.local_state[update.key] = update.value

            # Actualizar metadatos
            self.update_history[update.update_id] = update
            self.state_versions[update.key] = update.vector_clock

            logger.debug(f"📥 Aplicada actualización: {update.key} = {update.value}")

    def _find_last_update_for_key(self, key: str) -> Optional[StateUpdate]:
        """Encuentra la última actualización para una clave."""
        relevant_updates = [
            update for update in self.update_history.values()
            if update.key == key
        ]
        if not relevant_updates:
            return None

        # Encontrar la más reciente por vector clock
        latest = max(relevant_updates,
                    key=lambda u: (u.timestamp, u.vector_clock.counters.get(u.node_id, 0)))
        return latest

    def _cleanup_pending_updates(self, peer_id: str, remote_updates: List[StateUpdate]):
        """Limpia actualizaciones pendientes que ya fueron sincronizadas."""
        remote_update_ids = {u.update_id for u in remote_updates}
        self.pending_updates = [
            u for u in self.pending_updates
            if u.update_id not in remote_update_ids
        ]

    async def _periodic_sync(self):
        """Sincronización periódica con peers."""
        while True:
            try:
                await asyncio.sleep(self.sync_interval)

                # Sincronizar con peers activos
                active_peers = [p for p in self.peers if p not in self.network_partitions]

                for peer_id in active_peers:
                    try:
                        # Aquí iría la lógica de comunicación con el peer
                        # Por simplicidad, asumimos que se implementa en subclases
                        await self._sync_with_peer(peer_id)
                    except Exception as e:
                        logger.warning(f"⚠️ Error sincronizando con {peer_id}: {e}")

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Error en sincronización periódica: {e}")

    async def _sync_with_peer(self, peer_id: str):
        """Sincroniza con un peer específico (método a implementar en subclases)."""
        # Placeholder - implementado en subclases específicas
        pass

    async def _partition_recovery_monitor(self):
        """Monitorea recuperación de particiones de red."""
        while True:
            try:
                await asyncio.sleep(60)  # Verificar cada minuto

                current_time = time.time()
                recovered_peers = []

                for peer_id, detection_time in self.network_partitions.items():
                    if current_time - detection_time > self.partition_recovery_timeout:
                        # Intentar reconectar
                        try:
                            success = await self._attempt_peer_reconnection(peer_id)
                            if success:
                                recovered_peers.append(peer_id)
                                logger.info(f"🔄 Peer {peer_id} recuperado de partición")
                        except Exception as e:
                            logger.debug(f"Reconexión fallida con {peer_id}: {e}")

                # Limpiar peers recuperados
                for peer_id in recovered_peers:
                    del self.network_partitions[peer_id]

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Error monitoreando particiones: {e}")

    async def _attempt_peer_reconnection(self, peer_id: str) -> bool:
        """Intenta reconectar con un peer (método a implementar en subclases)."""
        # Placeholder - implementado en subclases específicas
        return False

    def get_state_snapshot(self) -> Dict[str, Any]:
        """Obtiene una instantánea del estado actual."""
        with self.state_lock:
            return {
                'state': self.local_state.copy(),
                'vector_clock': asdict(self.vector_clock),
                'pending_updates': [asdict(u) for u in self.pending_updates],
                'last_sync_times': self.last_sync_times.copy(),
                'network_partitions': list(self.network_partitions.keys())
            }

    def get_sync_status(self) -> Dict[str, Any]:
        """Obtiene el estado de sincronización."""
        return {
            'node_id': self.node_id,
            'vector_clock': str(self.vector_clock),
            'pending_updates_count': len(self.pending_updates),
            'active_peers': len(self.peers),
            'network_partitions': len(self.network_partitions),
            'conflicts_count': len(self.conflicts),
            'last_sync_times': self.last_sync_times
        }

    def add_peer(self, peer_id: str):
        """Agrega un peer para sincronización."""
        self.peers.add(peer_id)
        logger.info(f"👥 Peer agregado: {peer_id}")

    def remove_peer(self, peer_id: str):
        """Remueve un peer."""
        self.peers.discard(peer_id)
        self.last_sync_times.pop(peer_id, None)
        self.network_partitions.pop(peer_id, None)
        logger.info(f"👋 Peer removido: {peer_id}")


# Funciones de conveniencia
def create_state_sync(node_id: str, **kwargs) -> StateSync:
    """Crea una instancia de StateSync."""
    return StateSync(node_id, **kwargs)


async def start_state_sync_service(sync_instance: StateSync):
    """Inicia el servicio de sincronización."""
    await sync_instance.start_sync_service()