"""
WebSocket endpoints for real-time session state updates.
Provides bidirectional communication for session status, round progress, and participant updates.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional, Dict, Any
import json
import asyncio
from datetime import datetime

from ...database.connection import get_db
from ...auth.dependencies import get_current_user
from ...websocket.manager import manager
from ...websocket.room_manager import room_manager
from ...websocket.message_broker import message_broker
from ...websocket.message_types import WebSocketMessageFactory


# Create router
router = APIRouter()


@router.websocket("/ws/sessions/{session_id}")
async def session_websocket_endpoint(
    websocket: WebSocket,
    session_id: str,
    token: str = Query(..., description="JWT access token"),
    db: Session = Depends(get_db)
):
    """
    WebSocket endpoint for real-time session updates.
    Clients receive updates about session state, round progress, and participant changes.
    """
    try:
        # Authenticate user
        from ...auth.jwt import verify_token
        token_data = verify_token(token)

        if token_data.type not in ["user", "admin"]:
            await websocket.close(code=1008, reason="Invalid token type for session websocket")
            return

        user_id = token_data.sub
        await websocket.accept()

        # Join session room
        room_id = f"session_{session_id}"
        await room_manager.join_room(room_id, websocket, user_id, room_type="session")

        # Send initial session state
        await _send_initial_session_state(websocket, session_id, db)

        try:
            while True:
                # Receive messages from client
                data = await websocket.receive_text()
                message_data = json.loads(data)

                # Handle client messages
                await _handle_session_message(websocket, session_id, user_id, message_data, db)

        except WebSocketDisconnect:
            # Leave session room
            await room_manager.leave_room(room_id, websocket)
            print(f"Client {user_id} disconnected from session {session_id}")

    except Exception as e:
        print(f"Session WebSocket error for session {session_id}: {e}")
        await websocket.close(code=1011, reason="Internal server error")


async def _send_initial_session_state(websocket: WebSocket, session_id: str, db: Session):
    """Send initial session state to client."""
    try:
        # Get session information
        session_info = await _get_session_info(session_id, db)

        # Create welcome message
        message = WebSocketMessageFactory.create_session_update(
            session_id=session_id,
            update_type="initial_state",
            data=session_info
        )

        await websocket.send_text(message.json())

    except Exception as e:
        print(f"Error sending initial session state: {e}")


async def _handle_session_message(websocket: WebSocket, session_id: str, user_id: str, message_data: Dict[str, Any], db: Session):
    """Handle messages from session clients."""
    message_type = message_data.get("type")

    if message_type == "ping":
        # Respond to ping
        pong_message = WebSocketMessageFactory.create_session_update(
            session_id=session_id,
            update_type="pong",
            data={"timestamp": datetime.utcnow().isoformat()}
        )
        await websocket.send_text(pong_message.json())

    elif message_type == "request_update":
        # Send current session state
        session_info = await _get_session_info(session_id, db)
        update_message = WebSocketMessageFactory.create_session_update(
            session_id=session_id,
            update_type="state_update",
            data=session_info
        )
        await websocket.send_text(update_message.json())


async def _get_session_info(session_id: str, db: Session) -> Dict[str, Any]:
    """Get basic session information."""
    # This would integrate with your session management system
    # For now, return mock data
    return {
        "session_id": session_id,
        "status": "active",
        "current_round": 1,
        "total_rounds": 10,
        "participants": 5,
        "progress": 10.0,
        "last_updated": datetime.utcnow().isoformat()
    }


# Broadcast functions for external use
async def broadcast_session_update(session_id: str, update_type: str, data: Dict[str, Any]):
    """Broadcast session update to all clients in session room."""
    room_id = f"session_{session_id}"
    message = WebSocketMessageFactory.create_session_update(
        session_id=session_id,
        update_type=update_type,
        data=data
    )

    await room_manager.broadcast_to_room(room_id, message)