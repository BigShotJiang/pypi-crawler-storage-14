"""
API endpoints for external integrations (Discord, Webhooks).
Provides REST endpoints for managing Discord bots, webhooks, and testing integrations.
"""

import logging
from typing import Dict, Any, Optional, List
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user
from ....notifications.discord_service import DiscordService, DiscordIntegration
from ....notifications.webhook_service import WebhookService, WebhookIntegration

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()

# Global service instances (in production, these should be dependency injected)
_discord_service = DiscordService()
_webhook_service = WebhookService()


# Pydantic models for Discord integration
class DiscordIntegrationRequest(BaseModel):
    """Request model for creating/updating Discord integration."""
    name: str = Field(..., description="Descriptive name for the integration")
    bot_token: Optional[str] = Field(None, description="Discord bot token")
    server_id: str = Field(..., description="Discord server (guild) ID")
    channel_id: str = Field(..., description="Default channel ID for messages")
    webhook_url: Optional[str] = Field(None, description="Discord webhook URL (alternative to bot)")
    enabled: bool = Field(True, description="Whether the integration is enabled")

    @validator('bot_token', 'webhook_url')
    def validate_credentials(cls, v, field):
        if field.name == 'bot_token' and v and not v.strip():
            raise ValueError('bot_token cannot be empty if provided')
        if field.name == 'webhook_url' and v and not v.strip():
            raise ValueError('webhook_url cannot be empty if provided')
        return v


class DiscordIntegrationResponse(BaseModel):
    """Response model for Discord integration."""
    id: str
    name: str
    server_id: str
    channel_id: str
    webhook_url: Optional[str]
    enabled: bool
    created_at: datetime
    updated_at: datetime


class DiscordMessageRequest(BaseModel):
    """Request model for sending Discord messages."""
    integration_id: str = Field(..., description="ID of the Discord integration to use")
    content: str = Field(..., description="Message content")
    channel_id: Optional[str] = Field(None, description="Specific channel ID (overrides default)")
    embed_title: Optional[str] = Field(None, description="Embed title")
    embed_description: Optional[str] = Field(None, description="Embed description")
    embed_color: Optional[int] = Field(None, description="Embed color (decimal)")


# Pydantic models for Webhook integration
class WebhookIntegrationRequest(BaseModel):
    """Request model for creating/updating webhook integration."""
    name: str = Field(..., description="Descriptive name for the webhook")
    url: str = Field(..., description="Webhook endpoint URL")
    method: str = Field("POST", description="HTTP method")
    headers: Optional[Dict[str, str]] = Field(None, description="Custom headers")
    secret: Optional[str] = Field(None, description="HMAC secret for signature")
    enabled: bool = Field(True, description="Whether the webhook is enabled")
    retry_count: int = Field(3, description="Number of retry attempts")
    timeout: int = Field(30, description="Request timeout in seconds")

    @validator('method')
    def validate_method(cls, v):
        if v.upper() not in ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']:
            raise ValueError('method must be a valid HTTP method')
        return v.upper()

    @validator('retry_count')
    def validate_retry_count(cls, v):
        if v < 0 or v > 10:
            raise ValueError('retry_count must be between 0 and 10')
        return v

    @validator('timeout')
    def validate_timeout(cls, v):
        if v < 1 or v > 300:
            raise ValueError('timeout must be between 1 and 300 seconds')
        return v


class WebhookIntegrationResponse(BaseModel):
    """Response model for webhook integration."""
    id: str
    name: str
    url: str
    method: str
    enabled: bool
    retry_count: int
    timeout: int
    created_at: datetime
    updated_at: datetime


class WebhookPayloadRequest(BaseModel):
    """Request model for sending webhook payloads."""
    integration_id: str = Field(..., description="ID of the webhook integration to use")
    event_type: str = Field(..., description="Type of event")
    data: Dict[str, Any] = Field(..., description="Event data")


# Helper functions
def get_user_id_from_token(current_user: Dict) -> int:
    """Extract user ID from JWT token payload."""
    try:
        return int(current_user.get('sub', '').split('_')[-1])
    except (ValueError, IndexError):
        raise HTTPException(status_code=400, detail="Invalid user ID in token")


# Discord Integration Endpoints

@router.post("/discord", response_model=DiscordIntegrationResponse,
             summary="Crear integración con Discord",
             description="""
             Crea una nueva integración con Discord para envío de notificaciones.

             **Campos requeridos:**
             - name: Nombre descriptivo de la integración
             - server_id: ID del servidor de Discord
             - channel_id: ID del canal por defecto

             **Campos opcionales:**
             - bot_token: Token del bot de Discord (requerido si no se usa webhook_url)
             - webhook_url: URL del webhook de Discord (alternativa al bot)
             - enabled: Si la integración está habilitada (por defecto: true)

             **Códigos de respuesta:**
             - 201: Integración creada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def create_discord_integration(
    request: DiscordIntegrationRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create a new Discord integration.

    - Creates and registers a Discord integration
    - Requires authentication
    """
    try:
        # Validate that either bot_token or webhook_url is provided
        if not request.bot_token and not request.webhook_url:
            raise HTTPException(
                status_code=400,
                detail="Either bot_token or webhook_url must be provided"
            )

        # Create integration
        integration = DiscordIntegration(
            name=request.name,
            bot_token=request.bot_token,
            server_id=request.server_id,
            channel_id=request.channel_id,
            webhook_url=request.webhook_url,
            enabled=request.enabled
        )

        # Register with service
        await _discord_service.initialize()
        _discord_service.register_integration(integration)

        return DiscordIntegrationResponse(
            id=integration.id,
            name=integration.name,
            server_id=integration.server_id,
            channel_id=integration.channel_id,
            webhook_url=integration.webhook_url,
            enabled=integration.enabled,
            created_at=integration.created_at,
            updated_at=integration.updated_at
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create Discord integration error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/discord", response_model=List[DiscordIntegrationResponse],
            summary="Listar integraciones con Discord",
            description="""
            Obtiene la lista de todas las integraciones con Discord configuradas.

            **Códigos de respuesta:**
            - 200: Lista obtenida exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def list_discord_integrations(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    List all Discord integrations.

    - Returns all configured Discord integrations
    - Requires authentication
    """
    try:
        integrations = _discord_service.list_integrations()
        return [
            DiscordIntegrationResponse(
                id=integration.id,
                name=integration.name,
                server_id=integration.server_id,
                channel_id=integration.channel_id,
                webhook_url=integration.webhook_url,
                enabled=integration.enabled,
                created_at=integration.created_at,
                updated_at=integration.updated_at
            )
            for integration in integrations
        ]

    except Exception as e:
        logger.error(f"List Discord integrations error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/discord/test", response_model=Dict[str, Any],
             summary="Probar integración con Discord",
             description="""
             Envía un mensaje de prueba a una integración con Discord.

             **Campos requeridos:**
             - integration_id: ID de la integración a probar

             **Códigos de respuesta:**
             - 200: Prueba realizada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 404: Integración no encontrada
             - 500: Error interno del servidor
             """)
async def test_discord_integration(
    integration_id: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Test a Discord integration by sending a test message.

    - Sends a test message to verify the integration works
    - Requires authentication
    """
    try:
        await _discord_service.initialize()
        result = await _discord_service.test_integration(integration_id)

        if not result["success"]:
            raise HTTPException(
                status_code=400,
                detail=result.get("error", "Test failed")
            )

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Test Discord integration error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/discord/send", response_model=Dict[str, Any],
             summary="Enviar mensaje a Discord",
             description="""
             Envía un mensaje personalizado a Discord usando una integración configurada.

             **Campos requeridos:**
             - integration_id: ID de la integración a usar
             - content: Contenido del mensaje

             **Campos opcionales:**
             - channel_id: ID del canal específico (usa el por defecto si no se especifica)
             - embed_title: Título del embed
             - embed_description: Descripción del embed
             - embed_color: Color del embed (decimal)

             **Códigos de respuesta:**
             - 200: Mensaje enviado exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 404: Integración no encontrada
             - 500: Error interno del servidor
             """)
async def send_discord_message(
    request: DiscordMessageRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Send a custom message to Discord.

    - Sends a message using the specified Discord integration
    - Supports embeds and custom channels
    - Requires authentication
    """
    try:
        await _discord_service.initialize()

        # Create message
        from ....notifications.models import DiscordMessage
        message = DiscordMessage(content=request.content)

        # Add embed if provided
        if request.embed_title or request.embed_description:
            embed = {
                "title": request.embed_title or "",
                "description": request.embed_description or "",
                "timestamp": datetime.utcnow().isoformat()
            }
            if request.embed_color:
                embed["color"] = request.embed_color
            message.embeds = [embed]

        # Send message
        success = await _discord_service.send_message(
            request.integration_id,
            message,
            request.channel_id
        )

        if not success:
            raise HTTPException(
                status_code=400,
                detail="Failed to send Discord message"
            )

        return {
            "success": True,
            "message": "Discord message sent successfully",
            "integration_id": request.integration_id
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Send Discord message error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# Webhook Integration Endpoints

@router.post("/webhook", response_model=WebhookIntegrationResponse,
             summary="Crear integración con webhook",
             description="""
             Crea una nueva integración con webhook externo.

             **Campos requeridos:**
             - name: Nombre descriptivo del webhook
             - url: URL del endpoint del webhook

             **Campos opcionales:**
             - method: Método HTTP (por defecto: POST)
             - headers: Headers personalizados
             - secret: Secret para firma HMAC
             - enabled: Si el webhook está habilitado (por defecto: true)
             - retry_count: Número de reintentos (por defecto: 3)
             - timeout: Timeout en segundos (por defecto: 30)

             **Códigos de respuesta:**
             - 201: Webhook creado exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 500: Error interno del servidor
             """)
async def create_webhook_integration(
    request: WebhookIntegrationRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create a new webhook integration.

    - Creates and registers a webhook integration
    - Requires authentication
    """
    try:
        # Create integration
        integration = WebhookIntegration(
            name=request.name,
            url=request.url,
            method=request.method,
            headers=request.headers or {},
            secret=request.secret,
            enabled=request.enabled,
            retry_count=request.retry_count,
            timeout=request.timeout
        )

        # Register with service
        await _webhook_service.initialize()
        _webhook_service.register_integration(integration)

        return WebhookIntegrationResponse(
            id=integration.id,
            name=integration.name,
            url=integration.url,
            method=integration.method,
            enabled=integration.enabled,
            retry_count=integration.retry_count,
            timeout=integration.timeout,
            created_at=integration.created_at,
            updated_at=integration.updated_at
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create webhook integration error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/webhook", response_model=List[WebhookIntegrationResponse],
            summary="Listar integraciones con webhooks",
            description="""
            Obtiene la lista de todas las integraciones con webhooks configuradas.

            **Códigos de respuesta:**
            - 200: Lista obtenida exitosamente
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """)
async def list_webhook_integrations(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    List all webhook integrations.

    - Returns all configured webhook integrations
    - Requires authentication
    """
    try:
        integrations = _webhook_service.list_integrations()
        return [
            WebhookIntegrationResponse(
                id=integration.id,
                name=integration.name,
                url=integration.url,
                method=integration.method,
                enabled=integration.enabled,
                retry_count=integration.retry_count,
                timeout=integration.timeout,
                created_at=integration.created_at,
                updated_at=integration.updated_at
            )
            for integration in integrations
        ]

    except Exception as e:
        logger.error(f"List webhook integrations error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/webhook/test", response_model=Dict[str, Any],
             summary="Probar integración con webhook",
             description="""
             Envía un payload de prueba a una integración con webhook.

             **Campos requeridos:**
             - integration_id: ID de la integración a probar

             **Códigos de respuesta:**
             - 200: Prueba realizada exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 404: Integración no encontrada
             - 500: Error interno del servidor
             """)
async def test_webhook_integration(
    integration_id: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Test a webhook integration by sending a test payload.

    - Sends a test payload to verify the webhook works
    - Requires authentication
    """
    try:
        await _webhook_service.initialize()
        result = await _webhook_service.test_integration(integration_id)

        if not result["success"]:
            raise HTTPException(
                status_code=400,
                detail=result.get("error", "Test failed")
            )

        return result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Test webhook integration error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/webhook/send", response_model=Dict[str, Any],
             summary="Enviar payload a webhook",
             description="""
             Envía un payload personalizado a un webhook configurado.

             **Campos requeridos:**
             - integration_id: ID de la integración a usar
             - event_type: Tipo de evento
             - data: Datos del evento

             **Códigos de respuesta:**
             - 200: Payload enviado exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 404: Integración no encontrada
             - 500: Error interno del servidor
             """)
async def send_webhook_payload(
    request: WebhookPayloadRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Send a custom payload to a webhook.

    - Sends a payload using the specified webhook integration
    - Supports custom event types and data
    - Requires authentication
    """
    try:
        await _webhook_service.initialize()

        # Create payload
        from ....notifications.models import WebhookPayload
        payload = WebhookPayload(
            event_type=request.event_type,
            data=request.data
        )

        # Send payload
        success, response = await _webhook_service.send_payload(
            request.integration_id,
            payload
        )

        if not success:
            raise HTTPException(
                status_code=400,
                detail=f"Failed to send webhook payload: {response.get('error', 'Unknown error') if response else 'No response'}"
            )

        return {
            "success": True,
            "message": "Webhook payload sent successfully",
            "integration_id": request.integration_id,
            "response_status": response.get("status") if response else None
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Send webhook payload error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")