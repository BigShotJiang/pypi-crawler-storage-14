"""
SQLAlchemy database models for the coordinator service.
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, JSON, ForeignKey, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

Base = declarative_base()


class Node(Base):
    """Node model for federated learning participants."""
    __tablename__ = "nodes"

    id = Column(String(64), primary_key=True, index=True)
    public_key = Column(Text, nullable=False)
    status = Column(String(20), default="registered", index=True)
    reputation_score = Column(Float, default=0.5)
    trust_level = Column(String(20), default="basic", index=True)
    hardware_specs = Column(JSON)
    location = Column(JSON)
    last_heartbeat = Column(DateTime)
    total_contributions = Column(Integer, default=0)
    total_rewards_earned = Column(Float, default=0.0)
    is_verified = Column(Boolean, default=False)
    verification_expires_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    contributions = relationship("Contribution", back_populates="node")
    session_participants = relationship("SessionParticipant", back_populates="node")


class FederatedSession(Base):
    """Federated learning session model."""
    __tablename__ = "federated_sessions"

    id = Column(String(64), primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    model_type = Column(String(100), nullable=False, index=True)
    dataset_info = Column(JSON)
    configuration = Column(JSON)
    min_nodes = Column(Integer, default=3)
    max_nodes = Column(Integer, default=50)
    total_rounds = Column(Integer, nullable=False)
    status = Column(String(20), default="created", index=True)
    coordinator_node_id = Column(String(64), ForeignKey("nodes.id"))
    current_round = Column(Integer, default=0)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    estimated_completion = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    participants = relationship("SessionParticipant", back_populates="session")
    contributions = relationship("Contribution", back_populates="session")
    models = relationship("Model", back_populates="session")


class SessionParticipant(Base):
    """Session participant model."""
    __tablename__ = "session_participants"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(64), ForeignKey("federated_sessions.id"), nullable=False, index=True)
    node_id = Column(String(64), ForeignKey("nodes.id"), nullable=False, index=True)
    status = Column(String(20), default="invited", index=True)
    joined_at = Column(DateTime)
    last_contribution_at = Column(DateTime)
    contributions_count = Column(Integer, default=0)
    rewards_earned = Column(Float, default=0.0)
    performance_metrics = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    session = relationship("FederatedSession", back_populates="participants")
    node = relationship("Node", back_populates="session_participants")


class Model(Base):
    """Model version and metadata model."""
    __tablename__ = "models"

    id = Column(String(64), primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    version = Column(String(50), nullable=False)
    model_type = Column(String(100), nullable=False, index=True)
    description = Column(Text)
    architecture = Column(JSON)
    hyperparameters = Column(JSON)
    metrics = Column(JSON)
    tags = Column(JSON)
    is_public = Column(Boolean, default=False)
    session_id = Column(String(64), ForeignKey("federated_sessions.id"), index=True)
    status = Column(String(20), default="created", index=True)
    global_parameters_hash = Column(String(128))
    storage_location = Column(String(500))
    ipfs_cid = Column(String(128), index=True)
    file_hash = Column(String(128), index=True)
    file_size = Column(Integer)
    owner_node_id = Column(String(64), ForeignKey("nodes.id"))
    published_at = Column(DateTime)
    published_by = Column(String(64))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    session = relationship("FederatedSession", back_populates="models")


class Contribution(Base):
    """Contribution model for training rounds."""
    __tablename__ = "contributions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(64), ForeignKey("federated_sessions.id"), nullable=False, index=True)
    node_id = Column(String(64), ForeignKey("nodes.id"), nullable=False, index=True)
    round_number = Column(Integer, nullable=False, index=True)
    parameters_trained = Column(Integer, nullable=False)
    data_samples_used = Column(Integer, nullable=False)
    training_time_seconds = Column(Float, nullable=False)
    model_accuracy = Column(Float)
    loss_value = Column(Float)
    hardware_specs = Column(JSON)
    proof_of_work = Column(JSON)
    status = Column(String(20), default="submitted", index=True)
    validation_hash = Column(String(128))
    rewards_calculated = Column(Float)
    submitted_at = Column(DateTime)
    validated_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    session = relationship("FederatedSession", back_populates="contributions")
    node = relationship("Node", back_populates="contributions")
    reward_transactions = relationship("RewardTransaction", back_populates="contribution")


class RewardTransaction(Base):
    """Reward transaction model."""
    __tablename__ = "reward_transactions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(64), ForeignKey("federated_sessions.id"), nullable=False, index=True)
    node_id = Column(String(64), ForeignKey("nodes.id"), nullable=False, index=True)
    transaction_type = Column(String(50), nullable=False, index=True)
    drachma_amount = Column(Float, nullable=False)
    contribution_id = Column(Integer, ForeignKey("contributions.id"), index=True)
    status = Column(String(20), default="pending", index=True)
    blockchain_tx_hash = Column(String(128), index=True)
    blockchain_tx_status = Column(String(20))
    processed_at = Column(DateTime)
    distribution_proof = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    contribution = relationship("Contribution", back_populates="reward_transactions")


class User(Base):
    """User model for system administrators and users."""
    __tablename__ = "users"

    id = Column(String(64), primary_key=True, index=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(Text, nullable=False)
    full_name = Column(String(255))
    role = Column(String(20), default="user", index=True)
    is_active = Column(Boolean, default=True, index=True)
    is_verified = Column(Boolean, default=False, index=True)
    email_verified_at = Column(DateTime)
    last_login_at = Column(DateTime)
    login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime)
    preferences = Column(JSON)
    profile_data = Column(JSON)

    # Extended profile fields
    avatar_url = Column(String(500))
    bio = Column(Text)
    website = Column(String(255))
    location = Column(String(255))
    timezone = Column(String(50))
    language = Column(String(10), default="es")

    # Usage statistics
    total_sessions_participated = Column(Integer, default=0)
    total_contributions_made = Column(Integer, default=0)
    total_rewards_earned = Column(Float, default=0.0)
    reputation_score = Column(Float, default=0.0)
    trust_level = Column(String(20), default="basic")
    last_activity_at = Column(DateTime)
    api_calls_count = Column(Integer, default=0)
    storage_used_bytes = Column(Integer, default=0)
    models_created_count = Column(Integer, default=0)

    # OAuth fields
    github_id = Column(String(100), unique=True)
    google_id = Column(String(100), unique=True)
    wallet_address = Column(String(100), unique=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    access_logs = relationship("AccessLog", back_populates="user")
    oauth_tokens = relationship("OAuthToken", back_populates="user")


class RevokedToken(Base):
    """Revoked token model for JWT token revocation."""
    __tablename__ = "revoked_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    token_jti = Column(String(64), nullable=False, unique=True, index=True)
    token_type = Column(String(20), nullable=False, index=True)
    revoked_by = Column(String(64))
    revocation_reason = Column(String(100))
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_revoked_tokens_jti_type', 'token_jti', 'token_type'),
        Index('idx_revoked_tokens_expires', 'expires_at'),
    )


class RefreshToken(Base):
    """Refresh token model for JWT refresh tokens."""
    __tablename__ = "refresh_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    token_jti = Column(String(64), nullable=False, unique=True, index=True)
    node_id = Column(String(64), ForeignKey("nodes.id"), index=True)
    user_id = Column(String(64), ForeignKey("users.id"), index=True)
    token_type = Column(String(20), nullable=False, index=True)
    is_revoked = Column(Boolean, default=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    last_used_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_refresh_tokens_node_revoked', 'node_id', 'is_revoked'),
        Index('idx_refresh_tokens_user_revoked', 'user_id', 'is_revoked'),
        Index('idx_refresh_tokens_expires', 'expires_at'),
    )


class NodeRole(Base):
    """Node role model for role-based access control."""
    __tablename__ = "node_roles"

    id = Column(Integer, primary_key=True, autoincrement=True)
    node_id = Column(String(64), ForeignKey("nodes.id"), nullable=False, index=True)
    role = Column(String(20), nullable=False, index=True)
    is_active = Column(Boolean, default=True, index=True)
    assigned_by = Column(String(64))
    assigned_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_node_roles_node_active', 'node_id', 'is_active'),
        Index('idx_node_roles_role', 'role'),
    )


class AccessLog(Base):
    """Access log model for API access tracking."""
    __tablename__ = "access_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    node_id = Column(String(64), ForeignKey("nodes.id"), index=True)
    user_id = Column(String(64), ForeignKey("users.id"), index=True)
    endpoint = Column(String(255), nullable=False, index=True)
    method = Column(String(10), nullable=False)
    status_code = Column(Integer, nullable=False)
    ip_address = Column(String(45))
    user_agent = Column(Text)
    request_id = Column(String(64))
    response_time_ms = Column(Integer)
    error_message = Column(Text)
    permissions_checked = Column(JSON)
    token_jti = Column(String(64), index=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationships
    user = relationship("User", back_populates="access_logs")

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_access_logs_node_endpoint', 'node_id', 'endpoint'),
        Index('idx_access_logs_user_endpoint', 'user_id', 'endpoint'),
        Index('idx_access_logs_created_at', 'created_at'),
    )


class RateLimit(Base):
    """Rate limiting model for API protection."""
    __tablename__ = "rate_limits"

    id = Column(Integer, primary_key=True, autoincrement=True)
    identifier = Column(String(64), nullable=False, index=True)
    identifier_type = Column(String(20), nullable=False, index=True)  # 'node', 'user', 'ip'
    endpoint = Column(String(255), nullable=False, index=True)
    window_start = Column(Integer, nullable=False, index=True)  # Unix timestamp
    request_count = Column(Integer, default=0, nullable=False)
    window_seconds = Column(Integer, nullable=False)
    is_blocked = Column(Boolean, default=False, index=True)
    blocked_until = Column(Integer)  # Unix timestamp
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_rate_limits_identifier_endpoint', 'identifier', 'endpoint'),
        Index('idx_rate_limits_window', 'window_start'),
    )


class AuditLog(Base):
    """Audit log model for compliance and tracking."""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_type = Column(String(50), nullable=False, index=True)
    entity_id = Column(String(64), nullable=False, index=True)
    action = Column(String(50), nullable=False, index=True)
    user_id = Column(String(64), ForeignKey("users.id"), index=True)
    old_values = Column(JSON)
    new_values = Column(JSON)
    ip_address = Column(String(45))
    user_agent = Column(Text)
    audit_proof = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_audit_entity_action', 'entity_type', 'action'),
        Index('idx_audit_user_timestamp', 'user_id', 'created_at'),
    )


class OAuthProvider(Base):
    """OAuth provider configuration model."""
    __tablename__ = "oauth_providers"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50), unique=True, nullable=False, index=True)  # 'github', 'google', 'metamask'
    client_id = Column(String(255), nullable=False)
    client_secret = Column(Text, nullable=False)
    authorization_url = Column(String(500), nullable=False)
    token_url = Column(String(500), nullable=False)
    user_info_url = Column(String(500), nullable=False)
    scope = Column(String(255), default="read:user")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class OAuthToken(Base):
    """OAuth token storage model."""
    __tablename__ = "oauth_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(64), ForeignKey("users.id"), nullable=False, index=True)
    provider = Column(String(50), nullable=False, index=True)  # 'github', 'google', 'metamask'
    provider_user_id = Column(String(100), nullable=False, index=True)
    access_token = Column(Text, nullable=False)
    refresh_token = Column(Text)
    token_type = Column(String(50), default="Bearer")
    expires_at = Column(DateTime)
    scope = Column(String(255))
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="oauth_tokens")

    # Indexes for efficient querying
    __table_args__ = (
        Index('idx_oauth_tokens_user_provider', 'user_id', 'provider'),
        Index('idx_oauth_tokens_provider_user', 'provider', 'provider_user_id'),
    )


class EmailVerificationToken(Base):
    """Email verification token model."""
    __tablename__ = "email_verification_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    token = Column(String(128), unique=True, nullable=False, index=True)
    user_id = Column(String(64), ForeignKey("users.id"), nullable=False, index=True)
    email = Column(String(255), nullable=False)
    expires_at = Column(DateTime, nullable=False)
    is_used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class PasswordResetToken(Base):
    """Password reset token model."""
    __tablename__ = "password_reset_tokens"

    id = Column(Integer, primary_key=True, autoincrement=True)
    token = Column(String(128), unique=True, nullable=False, index=True)
    user_id = Column(String(64), ForeignKey("users.id"), nullable=False, index=True)
    email = Column(String(255), nullable=False)
    expires_at = Column(DateTime, nullable=False)
    is_used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# Create indexes for performance
Index('idx_nodes_status_reputation', Node.status, Node.reputation_score)
Index('idx_sessions_status_created', FederatedSession.status, FederatedSession.created_at)
Index('idx_contributions_session_round', Contribution.session_id, Contribution.round_number)
Index('idx_rewards_node_status', RewardTransaction.node_id, RewardTransaction.status)
Index('idx_users_email_active', User.email, User.is_active)
Index('idx_users_username_active', User.username, User.is_active)