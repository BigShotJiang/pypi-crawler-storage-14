import psutil
import platform
import GPUtil
from typing import Dict, Any


class HardwareMonitor:
    """Monitor de hardware real para el CLI de AILOOS."""

    def __init__(self):
        self.system = platform.system()

    def get_cpu_info(self) -> Dict[str, Any]:
        """Obtiene información del CPU."""
        return {
            'cores': psutil.cpu_count(logical=True),
            'physical_cores': psutil.cpu_count(logical=False),
            'usage_percent': psutil.cpu_percent(interval=1),
            'frequency': psutil.cpu_freq().current if psutil.cpu_freq() else None
        }

    def get_memory_info(self) -> Dict[str, Any]:
        """Obtiene información de memoria RAM."""
        mem = psutil.virtual_memory()
        return {
            'total_gb': round(mem.total / (1024**3), 1),
            'available_gb': round(mem.available / (1024**3), 1),
            'used_gb': round(mem.used / (1024**3), 1),
            'usage_percent': mem.percent
        }

    def get_disk_info(self) -> Dict[str, Any]:
        """Obtiene información del disco."""
        disk = psutil.disk_usage('/')
        return {
            'total_gb': round(disk.total / (1024**3), 1),
            'used_gb': round(disk.used / (1024**3), 1),
            'free_gb': round(disk.free / (1024**3), 1),
            'usage_percent': disk.percent
        }

    def get_gpu_info(self) -> Dict[str, Any]:
        """Obtiene información de GPU."""
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu = gpus[0]  # Primera GPU
                return {
                    'name': gpu.name,
                    'memory_total_mb': gpu.memoryTotal,
                    'memory_used_mb': gpu.memoryUsed,
                    'memory_free_mb': gpu.memoryFree,
                    'usage_percent': gpu.load * 100
                }
            else:
                return {'name': 'No GPU detected', 'memory_total_mb': 0, 'memory_used_mb': 0, 'memory_free_mb': 0, 'usage_percent': 0}
        except Exception as e:
            return {'name': f'Error detecting GPU: {str(e)}', 'memory_total_mb': 0, 'memory_used_mb': 0, 'memory_free_mb': 0, 'usage_percent': 0}

    def get_system_info(self) -> Dict[str, Any]:
        """Obtiene información general del sistema."""
        return {
            'os': platform.system(),
            'os_version': platform.version(),
            'hostname': platform.node(),
            'architecture': platform.machine(),
            'uptime_seconds': psutil.boot_time()
        }

    def get_all_hardware_info(self) -> Dict[str, Any]:
        """Obtiene toda la información de hardware."""
        return {
            'cpu': self.get_cpu_info(),
            'memory': self.get_memory_info(),
            'disk': self.get_disk_info(),
            'gpu': self.get_gpu_info(),
            'system': self.get_system_info()
        }