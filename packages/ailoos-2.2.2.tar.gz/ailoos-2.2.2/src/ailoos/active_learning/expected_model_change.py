import numpy as np
from typing import List, Any
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import copy
import logging

logger = logging.getLogger(__name__)

class ExpectedModelChange:
    """
    Estrategia de cambio esperado en el modelo para aprendizaje activo.
    Mide cuánto cambiaría el modelo si se etiqueta una muestra.
    """

    def __init__(self, model_type: str = 'logistic', n_simulations: int = 10):
        """
        Inicializa ExpectedModelChange.

        Args:
            model_type: Tipo de modelo ('logistic', 'tree', 'forest')
            n_simulations: Número de simulaciones para estimar el cambio esperado
        """
        self.model_type = model_type
        self.n_simulations = n_simulations
        self.valid_types = ['logistic', 'tree', 'forest']

        if model_type not in self.valid_types:
            raise ValueError(f"Tipo de modelo {model_type} no válido. Opciones: {self.valid_types}")

    def select_samples(self, model: Any, labeled_data: np.ndarray, labeled_labels: np.ndarray,
                      unlabeled_data: np.ndarray, n_samples: int) -> List[int]:
        """
        Selecciona muestras que causarían el mayor cambio esperado en el modelo.

        Args:
            model: Modelo actual
            labeled_data: Datos etiquetados
            labeled_labels: Etiquetas de datos etiquetados
            unlabeled_data: Datos no etiquetados
            n_samples: Número de muestras a seleccionar

        Returns:
            Lista de índices de las muestras seleccionadas
        """
        try:
            scores = np.zeros(len(unlabeled_data))

            for i, sample in enumerate(unlabeled_data):
                # Simular etiquetado con diferentes etiquetas posibles
                expected_changes = []

                for label in np.unique(labeled_labels):
                    # Crear conjunto de datos simulado
                    simulated_data = np.vstack([labeled_data, sample.reshape(1, -1)])
                    simulated_labels = np.append(labeled_labels, label)

                    # Entrenar modelo simulado
                    simulated_model = self._create_model()
                    simulated_model.fit(simulated_data, simulated_labels)

                    # Calcular cambio en parámetros (simplificado)
                    change = self._calculate_model_change(model, simulated_model)
                    expected_changes.append(change)

                # Promedio de cambios esperados
                scores[i] = np.mean(expected_changes)

            # Seleccionar índices con mayor cambio esperado
            indices = np.argsort(scores)[-n_samples:][::-1]
            return indices.tolist()

        except Exception as e:
            logger.error(f"Error en select_samples: {e}")
            raise

    def _create_model(self) -> BaseEstimator:
        """Crea una instancia del modelo especificado"""
        if self.model_type == 'logistic':
            return LogisticRegression(random_state=42, max_iter=1000)
        elif self.model_type == 'tree':
            return DecisionTreeClassifier(random_state=42)
        elif self.model_type == 'forest':
            return RandomForestClassifier(n_estimators=10, random_state=42)

    def _calculate_model_change(self, original_model: Any, new_model: Any) -> float:
        """
        Calcula el cambio entre dos modelos.
        Para simplificar, usa diferencia en coeficientes o importancia de características.
        """
        try:
            if hasattr(original_model, 'coef_') and hasattr(new_model, 'coef_'):
                # Para modelos lineales
                return np.linalg.norm(original_model.coef_ - new_model.coef_)
            elif hasattr(original_model, 'feature_importances_') and hasattr(new_model, 'feature_importances_'):
                # Para modelos basados en árboles
                return np.linalg.norm(original_model.feature_importances_ - new_model.feature_importances_)
            else:
                # Fallback: diferencia en predicciones en un conjunto de prueba pequeño
                # Esto es una aproximación simplificada
                return 0.1  # Valor constante para demostración
        except:
            return 0.1