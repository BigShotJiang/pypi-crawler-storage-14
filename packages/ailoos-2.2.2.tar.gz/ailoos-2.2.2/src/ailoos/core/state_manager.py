"""
Sistema de gestión de estado global para AILOOS.
Mantiene el estado centralizado de todos los componentes del sistema.
"""

import asyncio
import json
import threading
import time
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum

from .config import get_config
from ..utils.logging import get_logger


class ComponentStatus(Enum):
    """Estados posibles de un componente."""
    INITIALIZING = "initializing"
    RUNNING = "running"
    STOPPED = "stopped"
    ERROR = "error"
    DEGRADED = "degraded"


class SystemHealth(Enum):
    """Estados de salud del sistema."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    CRITICAL = "critical"
    UNKNOWN = "unknown"


@dataclass
class ComponentState:
    """Estado de un componente individual."""
    name: str
    status: ComponentStatus
    last_updated: datetime
    health_score: float = 1.0  # 0.0 a 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None
    start_time: Optional[datetime] = None
    restart_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status.value,
            "last_updated": self.last_updated.isoformat(),
            "health_score": self.health_score,
            "metadata": self.metadata,
            "error_message": self.error_message,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "restart_count": self.restart_count,
            "uptime_seconds": (datetime.now() - (self.start_time or datetime.now())).total_seconds() if self.start_time else 0
        }


@dataclass
class SystemMetrics:
    """Métricas globales del sistema."""
    total_requests: int = 0
    active_connections: int = 0
    memory_usage_mb: float = 0.0
    cpu_usage_percent: float = 0.0
    disk_usage_percent: float = 0.0
    network_rx_mb: float = 0.0
    network_tx_mb: float = 0.0
    federated_sessions_active: int = 0
    models_deployed: int = 0
    blockchain_transactions: int = 0
    ipfs_objects_stored: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_requests": self.total_requests,
            "active_connections": self.active_connections,
            "memory_usage_mb": self.memory_usage_mb,
            "cpu_usage_percent": self.cpu_usage_percent,
            "disk_usage_percent": self.disk_usage_percent,
            "network_rx_mb": self.network_rx_mb,
            "network_tx_mb": self.network_tx_mb,
            "federated_sessions_active": self.federated_sessions_active,
            "models_deployed": self.models_deployed,
            "blockchain_transactions": self.blockchain_transactions,
            "ipfs_objects_stored": self.ipfs_objects_stored
        }


class StateManager:
    """
    Gestor de estado global del sistema AILOOS.
    Singleton que mantiene el estado de todos los componentes.
    """

    _instance: Optional['StateManager'] = None
    _lock = threading.Lock()

    def __new__(cls) -> 'StateManager':
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if hasattr(self, '_initialized'):
            return

        self._initialized = True
        self.logger = get_logger(__name__)
        self.config = get_config()

        # Estado de componentes
        self.components: Dict[str, ComponentState] = {}
        self.system_metrics = SystemMetrics()

        # Callbacks para cambios de estado
        self.state_change_callbacks: List[Callable] = []
        self.health_change_callbacks: List[Callable] = []

        # Estado del sistema
        self.system_start_time = datetime.now()
        self.last_health_check = datetime.now()
        self.system_health = SystemHealth.UNKNOWN

        # Locks para thread safety
        self.state_lock = threading.RLock()
        self.metrics_lock = threading.RLock()

        # Tarea de monitoreo
        self.monitoring_task: Optional[asyncio.Task] = None
        self.monitoring_active = False

        self.logger.info("StateManager inicializado")

    async def start_monitoring(self):
        """Iniciar monitoreo continuo del estado."""
        if self.monitoring_active:
            return

        self.monitoring_active = True
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
        self.logger.info("Monitoreo de estado iniciado")

    async def stop_monitoring(self):
        """Detener monitoreo del estado."""
        self.monitoring_active = False
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Monitoreo de estado detenido")

    def register_component(self, name: str, initial_metadata: Optional[Dict[str, Any]] = None):
        """Registrar un componente en el sistema de estado."""
        with self.state_lock:
            if name in self.components:
                self.logger.warning(f"Componente {name} ya está registrado, actualizando")
                self.update_component_status(name, ComponentStatus.INITIALIZING, initial_metadata or {})
                return

            component = ComponentState(
                name=name,
                status=ComponentStatus.INITIALIZING,
                last_updated=datetime.now(),
                metadata=initial_metadata or {},
                start_time=datetime.now()
            )

            self.components[name] = component
            self._notify_state_change(name, component)
            self.logger.info(f"Componente registrado: {name}")

    def update_component_status(self, name: str, status: ComponentStatus,
                              metadata: Optional[Dict[str, Any]] = None,
                              error_message: Optional[str] = None,
                              health_score: Optional[float] = None):
        """Actualizar estado de un componente."""
        with self.state_lock:
            if name not in self.components:
                self.register_component(name, metadata)
                return

            component = self.components[name]
            old_status = component.status

            component.status = status
            component.last_updated = datetime.now()

            if metadata:
                component.metadata.update(metadata)

            if error_message:
                component.error_message = error_message

            if health_score is not None:
                component.health_score = max(0.0, min(1.0, health_score))

            # Incrementar contador de reinicios si vuelve a running desde error
            if old_status == ComponentStatus.ERROR and status == ComponentStatus.RUNNING:
                component.restart_count += 1

            self._notify_state_change(name, component)

            # Log del cambio de estado
            log_level = "info"
            if status == ComponentStatus.ERROR:
                log_level = "error"
            elif status == ComponentStatus.DEGRADED:
                log_level = "warning"

            getattr(self.logger, log_level)(
                f"Component status changed: {name} {old_status.value} -> {status.value}",
                component=name,
                old_status=old_status.value,
                new_status=status.value,
                health_score=component.health_score
            )

    def get_component_status(self, name: str) -> Optional[ComponentState]:
        """Obtener estado de un componente."""
        with self.state_lock:
            return self.components.get(name)

    def get_all_components(self) -> Dict[str, ComponentState]:
        """Obtener estado de todos los componentes."""
        with self.state_lock:
            return self.components.copy()

    def update_system_metrics(self, **metrics):
        """Actualizar métricas del sistema."""
        with self.metrics_lock:
            for key, value in metrics.items():
                if hasattr(self.system_metrics, key):
                    setattr(self.system_metrics, key, value)

    def get_system_metrics(self) -> SystemMetrics:
        """Obtener métricas del sistema."""
        with self.metrics_lock:
            return self.system_metrics

    def get_system_health(self) -> SystemHealth:
        """Calcular salud general del sistema."""
        with self.state_lock:
            if not self.components:
                return SystemHealth.UNKNOWN

            total_components = len(self.components)
            error_components = sum(1 for c in self.components.values()
                                 if c.status in [ComponentStatus.ERROR, ComponentStatus.STOPPED])
            degraded_components = sum(1 for c in self.components.values()
                                    if c.status == ComponentStatus.DEGRADED)

            error_ratio = error_components / total_components
            degraded_ratio = degraded_components / total_components

            if error_ratio > 0.5:
                health = SystemHealth.CRITICAL
            elif error_ratio > 0.2 or degraded_ratio > 0.5:
                health = SystemHealth.DEGRADED
            else:
                health = SystemHealth.HEALTHY

            # Notificar cambio de salud
            if health != self.system_health:
                old_health = self.system_health
                self.system_health = health
                self._notify_health_change(old_health, health)

            return health

    def get_system_status(self) -> Dict[str, Any]:
        """Obtener estado completo del sistema."""
        with self.state_lock:
            components_dict = {name: comp.to_dict() for name, comp in self.components.items()}

        return {
            "system_health": self.system_health.value,
            "system_uptime_seconds": (datetime.now() - self.system_start_time).total_seconds(),
            "total_components": len(components_dict),
            "components_running": sum(1 for c in components_dict.values() if c["status"] == "running"),
            "components_error": sum(1 for c in components_dict.values() if c["status"] == "error"),
            "components_degraded": sum(1 for c in components_dict.values() if c["status"] == "degraded"),
            "last_health_check": self.last_health_check.isoformat(),
            "metrics": self.system_metrics.to_dict(),
            "components": components_dict
        }

    def add_state_change_callback(self, callback: Callable):
        """Añadir callback para cambios de estado."""
        self.state_change_callbacks.append(callback)

    def add_health_change_callback(self, callback: Callable):
        """Añadir callback para cambios de salud."""
        self.health_change_callbacks.append(callback)

    def _notify_state_change(self, component_name: str, component: ComponentState):
        """Notificar cambios de estado a callbacks."""
        for callback in self.state_change_callbacks:
            try:
                callback(component_name, component)
            except Exception as e:
                self.logger.error(f"Error en callback de cambio de estado: {e}")

    def _notify_health_change(self, old_health: SystemHealth, new_health: SystemHealth):
        """Notificar cambios de salud a callbacks."""
        self.logger.info(f"System health changed: {old_health.value} -> {new_health.value}")

        for callback in self.health_change_callbacks:
            try:
                callback(old_health, new_health)
            except Exception as e:
                self.logger.error(f"Error en callback de cambio de salud: {e}")

    async def _monitoring_loop(self):
        """Loop de monitoreo continuo."""
        while self.monitoring_active:
            try:
                # Actualizar métricas del sistema
                await self._update_system_metrics()

                # Verificar salud de componentes
                await self._check_component_health()

                # Actualizar timestamp de health check
                self.last_health_check = datetime.now()

                # Calcular salud del sistema
                self.get_system_health()

                await asyncio.sleep(30)  # Verificar cada 30 segundos

            except Exception as e:
                self.logger.error(f"Error en monitoring loop: {e}")
                await asyncio.sleep(10)

    async def _update_system_metrics(self):
        """Actualizar métricas del sistema desde fuentes externas."""
        try:
            # Métricas básicas del sistema
            import psutil

            memory = psutil.virtual_memory()
            cpu = psutil.cpu_percent(interval=1)
            disk = psutil.disk_usage('/')

            network = psutil.net_io_counters()
            network_rx_mb = network.bytes_recv / (1024 * 1024)
            network_tx_mb = network.bytes_sent / (1024 * 1024)

            self.update_system_metrics(
                memory_usage_mb=memory.used / (1024 * 1024),
                cpu_usage_percent=cpu,
                disk_usage_percent=disk.percent,
                network_rx_mb=network_rx_mb,
                network_tx_mb=network_tx_mb
            )

        except ImportError:
            # psutil no disponible
            pass
        except Exception as e:
            self.logger.warning(f"Error actualizando métricas del sistema: {e}")

    async def _check_component_health(self):
        """Verificar salud de componentes registrados."""
        # Esta implementación básica marca componentes como healthy si están running
        # En una implementación real, se harían health checks específicos por componente
        with self.state_lock:
            for name, component in self.components.items():
                # Simular health check básico
                if component.status == ComponentStatus.RUNNING:
                    # Verificar si el componente ha estado inactivo demasiado tiempo
                    time_since_update = (datetime.now() - component.last_updated).total_seconds()
                    if time_since_update > 300:  # 5 minutos sin actualización
                        component.health_score = 0.5
                        if time_since_update > 600:  # 10 minutos
                            self.update_component_status(name, ComponentStatus.DEGRADED,
                                                       health_score=0.3,
                                                       error_message="Component not responding")

    def save_state_to_file(self, file_path: str):
        """Guardar estado del sistema a archivo."""
        state = self.get_system_status()

        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(state, f, indent=2, default=str)
            self.logger.info(f"Estado del sistema guardado en: {file_path}")
        except Exception as e:
            self.logger.error(f"Error guardando estado: {e}")

    def load_state_from_file(self, file_path: str):
        """Cargar estado del sistema desde archivo."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                state = json.load(f)

            # Restaurar componentes
            if 'components' in state:
                for name, comp_data in state['components'].items():
                    status = ComponentStatus(comp_data['status'])
                    metadata = comp_data.get('metadata', {})
                    health_score = comp_data.get('health_score', 1.0)
                    error_message = comp_data.get('error_message')

                    self.register_component(name, metadata)
                    self.update_component_status(name, status, metadata, error_message, health_score)

            self.logger.info(f"Estado del sistema cargado desde: {file_path}")

        except Exception as e:
            self.logger.error(f"Error cargando estado: {e}")


# Instancia global
state_manager = StateManager()


def get_state_manager() -> StateManager:
    """Obtener instancia global del state manager."""
    return state_manager


# Funciones de conveniencia
def register_component(name: str, metadata: Optional[Dict[str, Any]] = None):
    """Registrar componente globalmente."""
    state_manager.register_component(name, metadata)


def update_component_status(name: str, status: ComponentStatus, **kwargs):
    """Actualizar estado de componente."""
    state_manager.update_component_status(name, status, **kwargs)


def get_system_status() -> Dict[str, Any]:
    """Obtener estado del sistema."""
    return state_manager.get_system_status()