"""
Intelligent Traffic Router for Blue-Green Deployments.

Routes traffic based on various criteria including health status,
user segments, geographic location, and custom rules.
"""

import logging
import random
import hashlib
from typing import Dict, Any, List, Optional, Callable
from enum import Enum


class RoutingStrategy(Enum):
    RANDOM = "random"
    WEIGHTED = "weighted"
    STICKY_SESSION = "sticky_session"
    GEOGRAPHIC = "geographic"
    USER_SEGMENT = "user_segment"
    HEALTH_BASED = "health_based"


class TrafficRouter:
    """
    Intelligent traffic router for blue-green deployments.

    Supports multiple routing strategies and dynamic rule-based routing.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the Traffic Router.

        Args:
            config: Configuration dictionary containing:
                - routing_strategy: Default routing strategy
                - sticky_session_key: Key for sticky sessions
                - geographic_rules: Geographic routing rules
                - user_segment_rules: User segment routing rules
                - health_threshold: Health threshold for routing decisions
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

        self.routing_strategy = RoutingStrategy(config.get('routing_strategy', 'weighted'))
        self.sticky_session_key = config.get('sticky_session_key', 'user_id')
        self.geographic_rules = config.get('geographic_rules', {})
        self.user_segment_rules = config.get('user_segment_rules', {})
        self.health_threshold = config.get('health_threshold', 95.0)

        # Routing rules (functions that take request context and return target environment)
        self.custom_rules: List[Callable] = []

        # Current traffic distribution
        self.traffic_distribution = {'blue': 100, 'green': 0}

    def route_request(self, request_context: Dict[str, Any]) -> str:
        """
        Route a request to the appropriate environment.

        Args:
            request_context: Request context including headers, user info, location, etc.

        Returns:
            str: Target environment ('blue' or 'green')
        """
        try:
            # Check custom rules first
            for rule in self.custom_rules:
                result = rule(request_context)
                if result:
                    return result

            # Apply routing strategy
            if self.routing_strategy == RoutingStrategy.RANDOM:
                return self._random_route()
            elif self.routing_strategy == RoutingStrategy.WEIGHTED:
                return self._weighted_route()
            elif self.routing_strategy == RoutingStrategy.STICKY_SESSION:
                return self._sticky_session_route(request_context)
            elif self.routing_strategy == RoutingStrategy.GEOGRAPHIC:
                return self._geographic_route(request_context)
            elif self.routing_strategy == RoutingStrategy.USER_SEGMENT:
                return self._user_segment_route(request_context)
            elif self.routing_strategy == RoutingStrategy.HEALTH_BASED:
                return self._health_based_route(request_context)
            else:
                self.logger.warning(f"Unknown routing strategy: {self.routing_strategy}")
                return self._weighted_route()

        except Exception as e:
            self.logger.error(f"Routing failed: {e}, falling back to weighted routing")
            return self._weighted_route()

    def _random_route(self) -> str:
        """
        Random routing between available environments.

        Returns:
            str: Target environment
        """
        environments = [env for env, pct in self.traffic_distribution.items() if pct > 0]
        return random.choice(environments) if environments else 'blue'

    def _weighted_route(self) -> str:
        """
        Weighted routing based on traffic distribution.

        Returns:
            str: Target environment
        """
        total_weight = sum(self.traffic_distribution.values())
        if total_weight == 0:
            return 'blue'

        rand = random.uniform(0, total_weight)
        cumulative = 0

        for env, weight in self.traffic_distribution.items():
            cumulative += weight
            if rand <= cumulative:
                return env

        return 'blue'  # Fallback

    def _sticky_session_route(self, request_context: Dict[str, Any]) -> str:
        """
        Sticky session routing based on user identifier.

        Args:
            request_context: Request context

        Returns:
            str: Target environment
        """
        session_key = request_context.get(self.sticky_session_key)
        if not session_key:
            return self._weighted_route()

        # Use hash of session key to determine environment
        hash_value = int(hashlib.md5(str(session_key).encode()).hexdigest(), 16)
        environments = list(self.traffic_distribution.keys())

        # Simple hash-based routing
        target_index = hash_value % len(environments)
        return environments[target_index]

    def _geographic_route(self, request_context: Dict[str, Any]) -> str:
        """
        Geographic routing based on location.

        Args:
            request_context: Request context with location info

        Returns:
            str: Target environment
        """
        location = request_context.get('location', {}).get('country', 'unknown')

        # Check geographic rules
        for rule_location, target_env in self.geographic_rules.items():
            if location.lower() == rule_location.lower():
                return target_env

        # Fallback to weighted routing
        return self._weighted_route()

    def _user_segment_route(self, request_context: Dict[str, Any]) -> str:
        """
        User segment routing based on user attributes.

        Args:
            request_context: Request context with user info

        Returns:
            str: Target environment
        """
        user_segment = request_context.get('user_segment', 'default')

        # Check user segment rules
        if user_segment in self.user_segment_rules:
            return self.user_segment_rules[user_segment]

        # Fallback to weighted routing
        return self._weighted_route()

    def _health_based_route(self, request_context: Dict[str, Any]) -> str:
        """
        Health-based routing that avoids unhealthy environments.

        Args:
            request_context: Request context (may include health data)

        Returns:
            str: Target environment
        """
        # In a real implementation, this would check actual health metrics
        # For now, assume all environments are healthy if they have traffic allocated

        healthy_envs = [env for env, pct in self.traffic_distribution.items() if pct > 0]
        if not healthy_envs:
            return 'blue'

        # If only one healthy environment, use it
        if len(healthy_envs) == 1:
            return healthy_envs[0]

        # Otherwise, use weighted routing among healthy environments
        return self._weighted_route()

    def add_custom_rule(self, rule_function: Callable[[Dict[str, Any]], Optional[str]]):
        """
        Add a custom routing rule.

        Args:
            rule_function: Function that takes request context and returns target environment or None
        """
        self.custom_rules.append(rule_function)
        self.logger.info("Added custom routing rule")

    def remove_custom_rule(self, rule_function: Callable):
        """
        Remove a custom routing rule.

        Args:
            rule_function: The rule function to remove
        """
        if rule_function in self.custom_rules:
            self.custom_rules.remove(rule_function)
            self.logger.info("Removed custom routing rule")

    def update_traffic_distribution(self, distribution: Dict[str, float]):
        """
        Update the traffic distribution.

        Args:
            distribution: New traffic distribution (environment -> percentage)
        """
        self.traffic_distribution = distribution.copy()
        self.logger.info(f"Updated traffic distribution: {distribution}")

    def get_traffic_distribution(self) -> Dict[str, float]:
        """
        Get current traffic distribution.

        Returns:
            dict: Traffic distribution by environment
        """
        return self.traffic_distribution.copy()

    def get_routing_stats(self) -> Dict[str, Any]:
        """
        Get routing statistics.

        Returns:
            dict: Routing statistics
        """
        return {
            'strategy': self.routing_strategy.value,
            'distribution': self.traffic_distribution,
            'custom_rules_count': len(self.custom_rules),
            'geographic_rules': self.geographic_rules,
            'user_segment_rules': self.user_segment_rules
        }