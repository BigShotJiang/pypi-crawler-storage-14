import pytest
from texttools.analysis import word_count, char_count, top_words
from texttools.exceptions import InvalidTextError


def test_word_count_basic():
    assert word_count("hello world") == 2


def test_word_count_empty():
    assert word_count("") == 0


def test_word_count_invalid():
    with pytest.raises(InvalidTextError):
        word_count(123)


def test_char_count_with_spaces():
    assert char_count("a b c") == 5


def test_char_count_ignore_spaces():
    assert char_count("a b c", ignore_spaces=True) == 3


def test_char_count_invalid():
    with pytest.raises(InvalidTextError):
        char_count(None)


def test_top_words_basic():
    assert top_words("a b c a a b", n=2) == [("a", 3), ("b", 2)]


def test_top_words_empty():
    assert top_words("") == []


def test_top_words_invalid():
    with pytest.raises(InvalidTextError):
        top_words(55)
