import pytest
from texttools.cleaning import (
    _validate_text,
    remove_whitespace,
    remove_punctuation,
    normalize_spaces,
)
from texttools.exceptions import InvalidTextError


# ---------- _validate_text ----------
def test_validate_text_valid():
    assert _validate_text("hello") == "hello"


def test_validate_text_invalid():
    with pytest.raises(InvalidTextError):
        _validate_text(123)


# ---------- remove_whitespace ----------
def test_remove_whitespace_basic():
    assert remove_whitespace("hello   world") == "hello world"


def test_remove_whitespace_tabs_newlines():
    assert remove_whitespace("hello\nworld\t!") == "hello world !"


# ---------- remove_punctuation ----------
def test_remove_punctuation_basic():
    assert remove_punctuation("Hello, world!") == "Hello world"


def test_remove_punctuation_keep():
    assert remove_punctuation("a,b.c!", keep=",") == "a,b c"


# ---------- normalize_spaces ----------
def test_normalize_spaces():
    assert normalize_spaces("a   b   c") == "a b c"
