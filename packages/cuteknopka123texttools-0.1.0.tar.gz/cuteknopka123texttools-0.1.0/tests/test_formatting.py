import pytest
from texttools.formatting import (
    to_snake_case,
    to_kebab_case,
    capitalize_sentences,
)
from texttools.exceptions import InvalidTextError


def test_to_snake_case_basic():
    assert to_snake_case("HelloWorld") == "hello_world"


def test_to_snake_case_spaces_and_dashes():
    assert to_snake_case("hello-world test_example") == "hello_world_test_example"


def test_to_snake_case_invalid():
    with pytest.raises(InvalidTextError):
        to_snake_case(42)

def test_to_kebab_case_basic():
    assert to_kebab_case("HelloWorld") == "hello-world"


def test_to_kebab_case_spaces_underscores():
    assert to_kebab_case("hello_world test-case") == "hello-world-test-case"


def test_to_kebab_case_invalid():
    with pytest.raises(InvalidTextError):
        to_kebab_case(None)

def test_capitalize_sentences_basic():
    assert capitalize_sentences("hello. world!") == "Hello. World!"


def test_capitalize_sentences_mixed_spaces():
    assert capitalize_sentences("  hi   there?   how are you. ") == "Hi? How are you."


def test_capitalize_sentences_empty():
    assert capitalize_sentences("   ") == ""


def test_capitalize_sentences_invalid():
    with pytest.raises(InvalidTextError):
        capitalize_sentences(3.14)
