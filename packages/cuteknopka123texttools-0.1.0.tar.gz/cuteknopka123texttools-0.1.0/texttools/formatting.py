import re

def to_snake_case(text: str) -> str:
    text = re.sub(r'(?<!^)(?=[A-Z])', '_', text)
    text = text.replace('-', ' ').replace('_', ' ')
    return '_'.join(text.lower().split())

def to_kebab_case(text: str) -> str:
    text = re.sub(r'(?<!^)(?=[A-Z])', '-', text)
    text = text.replace('-', ' ').replace('_', ' ')
    return '-'.join(text.lower().split())

def capitalize_sentences(text: str) -> str:
    text = ' '.join(text.split())
    if not text:
        return ''
    parts = re.split(r'([.!?])', text)
    result = []
    for i in range(0, len(parts) - 1, 2):
        s, p = parts[i].strip(), parts[i+1]
        if not s:
            continue
        if p == '?':
            s = s.split()[0]
        for idx, ch in enumerate(s):
            if ch.isalpha():
                s = s[:idx] + ch.upper() + s[idx+1:]
                break
        result.append(s + p)
    return ' '.join(result)
