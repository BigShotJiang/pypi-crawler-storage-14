from collections import Counter
import re
from .cleaning import remove_punctuation

def word_count(text: str) -> int:
    return len(text.split())

def char_count(text: str, ignore_spaces: bool = False) -> int:
    return len(re.sub(r'\s','',text)) if ignore_spaces else len(text)

def top_words(text: str, n: int = 3):
    words = remove_punctuation(text).lower().split()
    return Counter(words).most_common(n) if words else []
