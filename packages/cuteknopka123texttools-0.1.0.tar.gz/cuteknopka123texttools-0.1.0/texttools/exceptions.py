class TextToolsError(Exception):
    pass

class InvalidTextError(TextToolsError):
    pass