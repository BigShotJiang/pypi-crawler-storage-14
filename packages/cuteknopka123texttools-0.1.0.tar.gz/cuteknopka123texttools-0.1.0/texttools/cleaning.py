from .exceptions import InvalidTextError
import string

def _validate_text(text):
    if not isinstance(text, str):
        raise InvalidTextError
    return text 

def remove_whitespace(text: str) -> str:

    text = _validate_text(text)
    return ' '.join(text.split())

def remove_punctuation(text: str, keep: str = "") -> str:
    text = _validate_text(text)

    all_punctuation = set(string.punctuation)
    keep_set = set(keep)

    remove_set = all_punctuation - keep_set

    for ch in remove_set:
        text = text.replace(ch, " ")

    return " ".join(text.split())


def normalize_spaces(text: str) -> str:

    text = _validate_text(text)
    return ' '.join(text.split())