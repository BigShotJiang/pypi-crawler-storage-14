# Библиотека Text Tools

Небольшая Python-библиотека, предоставляющая набор инструментов для
обработки, нормализации и анализа текста.

## Возможности

### Преобразование регистра

-   **`to_snake_case(text)`** --- преобразует текст в формат
    *snake_case*.
-   **`to_kebab_case(text)`** --- преобразует текст в *kebab-case*.
-   **`capitalize_sentences(text)`** --- корректно капитализирует
    предложения.

### Очистка текста

-   **`remove_whitespace(text)`** --- удаляет лишние пробелы.
-   **`remove_punctuation(text, keep="")`** --- удаляет пунктуацию,
    оставляя выбранные символы.
-   **`normalize_spaces(text)`** --- приводит пробелы к единому формату
    (замена повторяющихся пробелов одним).

### Валидация текста

-   **`_validate_text(text)`** --- проверяет, что аргумент является
    корректной строкой.
-   Исключения:
    -   `TextToolsError`
    -   `InvalidTextError`

### Аналитика текста

-   **`word_count(text)`** --- считает количество слов.
-   **`char_count(text, ignore_spaces=False)`** --- считает количество
    символов (с возможностью игнорировать пробелы).
-   **`top_words(text, n=3)`** --- возвращает *n* самых часто
    встречающихся слов.

## Установка

Библиотека является автономным модулем. Установите зависимости:

``` bash
pip install -r requirements.txt
```

## Требования

-   Python 3.8+
-   pypandoc

## Пример использования

``` python
from texttools import to_snake_case, word_count

print(to_snake_case("HelloWorld"))   # hello_world
print(word_count("Привет мир!"))     # 2
```

## Лицензия

MIT License
