# cropcalc-hurnaqvi

A Python package for crop yield prediction, soil recommendations, and weather-based adjustments.

## Installation
