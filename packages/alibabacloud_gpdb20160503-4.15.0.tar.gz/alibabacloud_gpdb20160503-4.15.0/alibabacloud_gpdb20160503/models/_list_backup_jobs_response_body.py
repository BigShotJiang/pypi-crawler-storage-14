# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import List

from alibabacloud_gpdb20160503 import models as main_models
from darabonba.model import DaraModel

class ListBackupJobsResponseBody(DaraModel):
    def __init__(
        self,
        items: main_models.ListBackupJobsResponseBodyItems = None,
        request_id: str = None,
    ):
        # The queried backup jobs.
        self.items = items
        # The request ID.
        self.request_id = request_id

    def validate(self):
        if self.items:
            self.items.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.items is not None:
            result['Items'] = self.items.to_map()

        if self.request_id is not None:
            result['RequestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Items') is not None:
            temp_model = main_models.ListBackupJobsResponseBodyItems()
            self.items = temp_model.from_map(m.get('Items'))

        if m.get('RequestId') is not None:
            self.request_id = m.get('RequestId')

        return self

class ListBackupJobsResponseBodyItems(DaraModel):
    def __init__(
        self,
        backup_job: List[main_models.ListBackupJobsResponseBodyItemsBackupJob] = None,
    ):
        self.backup_job = backup_job

    def validate(self):
        if self.backup_job:
            for v1 in self.backup_job:
                 if v1:
                    v1.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        result['BackupJob'] = []
        if self.backup_job is not None:
            for k1 in self.backup_job:
                result['BackupJob'].append(k1.to_map() if k1 else None)

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        self.backup_job = []
        if m.get('BackupJob') is not None:
            for k1 in m.get('BackupJob'):
                temp_model = main_models.ListBackupJobsResponseBodyItemsBackupJob()
                self.backup_job.append(temp_model.from_map(k1))

        return self

class ListBackupJobsResponseBodyItemsBackupJob(DaraModel):
    def __init__(
        self,
        backup_job_id: str = None,
        backup_mode: str = None,
        backup_status: str = None,
        process: str = None,
        start_time: str = None,
    ):
        # The backup job ID.
        self.backup_job_id = backup_job_id
        # The backup mode. Valid values:
        # 
        # *   **Automated**
        # *   **Manual**
        self.backup_mode = backup_mode
        # The backup status. Valid values:
        # 
        # *   **Success**
        # *   **Failure**
        self.backup_status = backup_status
        # The progress of the backup job.
        self.process = process
        # The time when the backup job started. The time follows the ISO 8601 standard in the YYYY-MM-DDThh:mm:ssZ format. The time is displayed in UTC.
        self.start_time = start_time

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.backup_job_id is not None:
            result['BackupJobId'] = self.backup_job_id

        if self.backup_mode is not None:
            result['BackupMode'] = self.backup_mode

        if self.backup_status is not None:
            result['BackupStatus'] = self.backup_status

        if self.process is not None:
            result['Process'] = self.process

        if self.start_time is not None:
            result['StartTime'] = self.start_time

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('BackupJobId') is not None:
            self.backup_job_id = m.get('BackupJobId')

        if m.get('BackupMode') is not None:
            self.backup_mode = m.get('BackupMode')

        if m.get('BackupStatus') is not None:
            self.backup_status = m.get('BackupStatus')

        if m.get('Process') is not None:
            self.process = m.get('Process')

        if m.get('StartTime') is not None:
            self.start_time = m.get('StartTime')

        return self

