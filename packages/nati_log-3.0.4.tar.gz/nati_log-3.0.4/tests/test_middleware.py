# -*- coding: utf-8 -*-
try:
    from types import SimpleNamespace
except ImportError:
    class SimpleNamespace(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

import pytest
from django.http import HttpResponse
from django.test import RequestFactory
from nati_log.middleware import NatiLogMiddleware

class DummyClient:
    def __init__(self, estado=True):
        self.app_estado = estado
        self.calls = []
    def actualizar_estado_aplicacion(self): pass
    def debug(self, m, datos=None, fecha=None): self.calls.append(("debug", m, datos))
    def info(self, m, datos=None, fecha=None): self.calls.append(("info", m, datos))
    def warning(self, m, datos=None, fecha=None): self.calls.append(("warning", m, datos))
    def error(self, m, datos=None, fecha=None): self.calls.append(("error", m, datos))
    def critical(self, m, datos=None, fecha=None): self.calls.append(("critical", m, datos))

class NoOpClient:
    def __init__(self):
        self.app_estado = True
        self.calls = []
    def actualizar_estado_aplicacion(self): pass

@pytest.fixture
def rf():
    return RequestFactory()

def make_response(status=200):
    r = HttpResponse("x")
    r.status_code = status
    return r

def test_middleware_registra_info_y_debug(settings, monkeypatch, rf):
    settings.NATILOG = {
        "API_URL": "http://fake/api",
        "API_URL_LOGIN": "http://fake/api/auth/",
        "APP_ID": 1,
        "USERNAME": "u",
        "PASSWORD": "p",
        "EVENT_LEVELS": {"DEBUG": True, "INFO": True},
    }
    dummy = DummyClient()
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(200))
    req = rf.get("/ok"); req.user = SimpleNamespace(username="tester")
    mw(req)
    tipos = {c[0] for c in dummy.calls}
    assert "debug" in tipos and "info" in tipos

def test_middleware_filtra_niveles(settings, monkeypatch, rf):
    settings.NATILOG = {
        "API_URL": "http://fake/api",
        "API_URL_LOGIN": "http://fake/api/auth/",
        "APP_ID": 1,
        "USERNAME": "u",
        "PASSWORD": "p",
        "EVENT_LEVELS": {"WARNING": True},
    }
    dummy = DummyClient()
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(302))
    req = rf.get("/redir"); req.user = SimpleNamespace(username="tester")
    mw(req)
    tipos = {c[0] for c in dummy.calls}
    # Solo warning (debug puede estar desactivado en config)
    assert "warning" in tipos

def test_middleware_registra_error(settings, monkeypatch, rf):
    settings.NATILOG = {
        "API_URL": "http://fake/api",
        "API_URL_LOGIN": "http://fake/api/auth/",
        "APP_ID": 1,
        "USERNAME": "u",
        "PASSWORD": "p",
        "EVENT_LEVELS": {"ERROR": True},
    }
    dummy = DummyClient()
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(404))
    req = rf.get("/nf"); req.user = SimpleNamespace(username="tester")
    mw(req)
    tipos = {c[0] for c in dummy.calls}
    assert "error" in tipos

def test_middleware_registra_critical(settings, monkeypatch, rf):
    settings.NATILOG = {
        "API_URL": "http://fake/api",
        "API_URL_LOGIN": "http://fake/api/auth/",
        "APP_ID": 1,
        "USERNAME": "u",
        "PASSWORD": "p",
        "EVENT_LEVELS": {"CRITICAL": True},
    }
    dummy = DummyClient()
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(503))
    req = rf.get("/boom"); req.user = SimpleNamespace(username="tester")
    mw(req)
    tipos = {c[0] for c in dummy.calls}
    assert "critical" in tipos

def test_middleware_sin_cliente(settings, monkeypatch, rf):
    settings.NATILOG = {"EVENT_LEVELS": {"DEBUG": True}}
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: NoOpClient())
    mw = NatiLogMiddleware(lambda r: make_response(200))
    resp = mw(rf.get("/noop"))
    assert resp.status_code == 200

def test_middleware_inactiva_no_registra(settings, monkeypatch, rf):
    settings.NATILOG = {"EVENT_LEVELS": {"INFO": True}}
    dummy = DummyClient(estado=False)
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(200))
    req = rf.get("/skip"); req.user = SimpleNamespace(username="tester")
    mw(req)
    assert dummy.calls == []

def test_middleware_warning_con_usuario(settings, monkeypatch, rf):
    settings.NATILOG = {"EVENT_LEVELS": {"WARNING": True}}
    dummy = DummyClient()
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(302))
    req = rf.get("/redir"); req.user = SimpleNamespace(username="tester")
    mw(req)
    assert any(t == "warning" for t, _, _ in dummy.calls)

def test_middleware_debug_request(settings, monkeypatch, rf):
    settings.NATILOG = {"EVENT_LEVELS": {"DEBUG": True}}
    dummy = DummyClient()
    monkeypatch.setattr("nati_log.middleware.NatiLogClient", lambda **_: dummy)
    mw = NatiLogMiddleware(lambda r: make_response(204))
    req = rf.get("/empty"); req.user = SimpleNamespace(username="tester")
    mw(req)
    assert any(t == "debug" for t, _, _ in dummy.calls)