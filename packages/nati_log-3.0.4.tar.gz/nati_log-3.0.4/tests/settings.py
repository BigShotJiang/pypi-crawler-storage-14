SECRET_KEY = "test"
INSTALLED_APPS = ["django.contrib.contenttypes", "django.contrib.auth", "nati_log"]
DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}}