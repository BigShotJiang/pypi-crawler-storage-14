from .client import NatiLogClient
