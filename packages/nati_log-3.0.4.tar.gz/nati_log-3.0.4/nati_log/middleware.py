from django.conf import settings
from .client import NatiLogClient


class NatiLogMiddleware:
    def __init__(self, get_response):
        """
        Initialize the middleware and NatiLog client.

        Args:
            get_response (callable): The next handler in the Django middleware chain.

        Behavior:
            - Reads configuration from `settings.NATILOG`.
            - Initializes `NatiLogClient` with API credentials.
            - Stores per-level toggles in `self.levels` (default: all enabled).
        """

        self.get_response = get_response
        config = getattr(settings, "NATILOG", {})
        self.levels = config.get(
            "EVENT_LEVELS",
            {"DEBUG": True, "INFO": True, "WARNING": True, "ERROR": True, "CRITICAL": True},
        )
        self.natilog = NatiLogClient(
            api_url=config.get("API_URL"),
            api_url_login=config.get("API_URL_LOGIN"),
            app_id=config.get("APP_ID"),
            username=config.get("USERNAME"),
            password=config.get("PASSWORD"),
        )
        print("NatilogClient iniziado en middleware.")
        print(f"NATILOG config: {config}")

    def __call__(self, request):
        """
        Process the request, call the view, and record events to NatiLog.

        - Ensures the application state is current via `actualizar_estado_aplicacion`.
        - Omits logging if the application is inactive.
        - Sends one event per request based on the response status:
          DEBUG (always), INFO (2xx), WARNING (3xx), ERROR (4xx), CRITICAL (5xx).
        - Includes context such as the authenticated username and the status code.

        The middleware is fail-safe: any exception during logging is caught and
        printed to stdout; it never interrupts the request/response flow.

        Args:
            request (HttpRequest): Incoming Django request.

        Returns:
            HttpResponse: The response produced by the downstream view.
        """
        self.natilog.actualizar_estado_aplicacion()
        response = self.get_response(request)
        if not self.natilog:
            return response
        if not getattr(self.natilog, "app_estado", True):
            # App inactiva: no registrar eventos
            return response

        try:
            if self.levels.get("DEBUG", True):
                self.natilog.debug(
                    f"Request recibido: {request.method} {request.path}",
                    datos={"user": getattr(request.user, "username", None)},
                )

            if 200 <= response.status_code < 300 and self.levels.get("INFO", True):
                self.natilog.info(
                    f"Request OK: {request.method} {request.path}",
                    datos={"status_code": response.status_code},
                )
            elif 300 <= response.status_code < 400 and self.levels.get("WARNING", True):
                self.natilog.warning(
                    f"Redirect: {request.method} {request.path}",
                    datos={"status_code": response.status_code},
                )
            elif 400 <= response.status_code < 500 and self.levels.get("ERROR", True):
                self.natilog.error(
                    f"Client Error {response.status_code}: {request.method} {request.path}",
                    datos={"status_code": response.status_code},
                )
            elif response.status_code >= 500 and self.levels.get("CRITICAL", True):
                self.natilog.critical(
                    f"Server Error {response.status_code}: {request.method} {request.path}",
                    datos={"status_code": response.status_code},
                )
        except Exception as exc:
            print(f"Error trying to log event: {exc}")

        return response
