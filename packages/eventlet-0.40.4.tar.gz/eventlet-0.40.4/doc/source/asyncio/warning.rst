.. warning::

   Eventlet is now in maintenance mode, so only the changes who are related
   to fixing a bug or who are related to the new Asyncio hub will be accepted.
   New features outside of the scope of the Asyncio hub won't be accepted.

   :ref:`migration-guide` is strongly encouraged. We encourage existing
   users to migrate to Asyncio. For further details see the official
   :ref:`migration guide <migration-guide>`.

