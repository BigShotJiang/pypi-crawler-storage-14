:mod:`corolocal` -- Coroutine local storage
=============================================

.. automodule:: eventlet.corolocal
	:members:
	:undoc-members:
