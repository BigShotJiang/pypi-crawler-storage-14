eventlet.support package
========================

Submodules
----------

eventlet.support.greendns module
--------------------------------

.. automodule:: eventlet.support.greendns
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.support.greenlets module
---------------------------------

.. automodule:: eventlet.support.greenlets
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.support.psycopg2\_patcher module
-----------------------------------------

.. automodule:: eventlet.support.psycopg2_patcher
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.support.pylib module
-----------------------------

.. automodule:: eventlet.support.pylib
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.support.stacklesspypys module
--------------------------------------

.. automodule:: eventlet.support.stacklesspypys
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.support.stacklesss module
----------------------------------

.. automodule:: eventlet.support.stacklesss
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: eventlet.support
   :members:
   :undoc-members:
   :show-inheritance:
