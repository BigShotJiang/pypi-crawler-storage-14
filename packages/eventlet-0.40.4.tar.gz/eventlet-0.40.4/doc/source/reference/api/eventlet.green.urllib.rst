eventlet.green.urllib package
=============================

Submodules
----------

eventlet.green.urllib.error module
----------------------------------

.. automodule:: eventlet.green.urllib.error
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.green.urllib.parse module
----------------------------------

.. automodule:: eventlet.green.urllib.parse
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.green.urllib.request module
------------------------------------

.. automodule:: eventlet.green.urllib.request
   :members:
   :undoc-members:
   :show-inheritance:

eventlet.green.urllib.response module
-------------------------------------

.. automodule:: eventlet.green.urllib.response
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: eventlet.green.urllib
   :members:
   :undoc-members:
   :show-inheritance:
