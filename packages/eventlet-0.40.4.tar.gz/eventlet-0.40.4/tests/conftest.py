import os
os.environ["EVENTLET_TESTS"] = "1"
