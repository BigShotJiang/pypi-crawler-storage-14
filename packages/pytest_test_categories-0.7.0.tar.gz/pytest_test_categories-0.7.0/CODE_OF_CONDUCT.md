# Contributor Covenant Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, caste, color, religion, or sexual
identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment for our
community include:

* Demonstrating empathy and kindness toward other people
* Being respectful of differing opinions, viewpoints, and experiences
* Giving and gracefully accepting constructive feedback
* Accepting responsibility and apologizing to those affected by our mistakes,
  and learning from the experience
* Focusing on what is best not just for us as individuals, but for the overall
  community
* Using welcoming and inclusive language
* Being patient with newcomers and helping them learn
* Celebrating the contributions of others

Examples of unacceptable behavior include:

* The use of sexualized language or imagery, and sexual attention or advances of
  any kind
* Trolling, insulting or derogatory comments, and personal or political attacks
* Public or private harassment
* Publishing others' private information, such as a physical or email address,
  without their explicit permission
* Conduct which could reasonably be considered inappropriate in a professional
  setting
* Dismissing or attacking inclusion-focused efforts
* Sustained disruption of community discussions
* Pattern of inappropriate social contact

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of
acceptable behavior and will take appropriate and fair corrective action in
response to any behavior that they deem inappropriate, threatening, offensive,
or harmful.

Community leaders have the right and responsibility to remove, edit, or reject
comments, commits, code, wiki edits, issues, and other contributions that are
not aligned to this Code of Conduct, and will communicate reasons for moderation
decisions when appropriate.

## Scope

This Code of Conduct applies within all community spaces, and also applies when
an individual is officially representing the community in public spaces.
Examples of representing our community include using an official e-mail address,
posting via an official social media account, or acting as an appointed
representative at an online or offline event.

This Code of Conduct also applies to actions taken outside of these spaces when
the community leadership has a reasonable and good faith belief that an action
by an individual community member may negatively impact the health and wellbeing
of other community members, or the community itself.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to the community leaders responsible for enforcement at
[mikelane@gmail.com](mailto:mikelane@gmail.com).

All complaints will be reviewed and investigated promptly and fairly.

All community leaders are obligated to respect the privacy and security of the
reporter of any incident.

## Enforcement Guidelines

Community leaders will follow these Community Impact Guidelines in determining
the consequences for any action they deem in violation of this Code of Conduct:

### 1. Correction

**Community Impact**: Use of inappropriate language or other behavior deemed
unprofessional or unwelcome in the community.

**Consequence**: A private, written warning from community leaders, providing
clarity around the nature of the violation and an explanation of why the
behavior was inappropriate. A public apology may be requested.

### 2. Warning

**Community Impact**: A violation through a single incident or series of
actions.

**Consequence**: A warning with consequences for continued behavior. No
interaction with the people involved, including unsolicited interaction with
those enforcing the Code of Conduct, for a specified period of time. This
includes avoiding interactions in community spaces as well as external channels
like social media. Violating these terms may lead to a temporary or permanent
ban.

### 3. Temporary Ban

**Community Impact**: A serious violation of community standards, including
sustained inappropriate behavior.

**Consequence**: A temporary ban from any sort of interaction or public
communication with the community for a specified period of time. No public or
private interaction with the people involved, including unsolicited interaction
with those enforcing the Code of Conduct, is allowed during this period.
Violating these terms may lead to a permanent ban.

### 4. Permanent Ban

**Community Impact**: Demonstrating a pattern of violation of community
standards, including sustained inappropriate behavior, harassment of an
individual, or aggression toward or disparagement of classes of individuals.

**Consequence**: A permanent ban from any sort of public interaction within the
community.

## Reporting Guidelines

### How to Report

If you experience or witness unacceptable behavior, or have any other concerns, please report it by contacting:

**Primary Contact**: Mike Lane at [mikelane@gmail.com](mailto:mikelane@gmail.com)

**What to Include**:
- Your contact information
- Names (real, nicknames, or pseudonyms) of any individuals involved
- Description of the behavior and the circumstances
- Approximate dates and times
- Any additional helpful context or information
- If you believe this incident is ongoing

**Confidentiality**: All reports will be handled with discretion. We will not share your identity without your explicit consent except as required by law.

### After You Report

**Within 24 hours**:
- You will receive an acknowledgment that we received your report
- An initial assessment of the situation

**Within 7 days**:
- Investigation will be completed
- You will be informed of the outcome and any actions taken
- You may be asked for additional information if needed

**Confidentiality**:
- Your privacy will be protected
- Details will be shared only on a need-to-know basis
- The reporter's identity will not be shared without consent

### What Happens Next

The community leadership team will:

1. **Acknowledge** receipt of the report
2. **Review** the report and gather additional information if needed
3. **Determine** what violation (if any) occurred and its severity
4. **Decide** on appropriate consequences using the Enforcement Guidelines
5. **Communicate** the decision to relevant parties
6. **Follow up** to ensure the issue is resolved

## Appeals

If you disagree with a decision made by the community leaders, you may appeal by:

1. Sending an email to [mikelane@gmail.com](mailto:mikelane@gmail.com) with subject: **Code of Conduct Appeal**
2. Explaining why you believe the decision was incorrect
3. Providing any additional relevant information

Appeals will be reviewed within 14 days and a final decision will be communicated.

## Community Values

Beyond the standards above, we value:

### Collaboration
- We work together toward shared goals
- We share knowledge and help each other learn
- We celebrate collective success

### Respect
- We respect different skill levels and learning styles
- We value diverse perspectives and experiences
- We assume good intent and practice empathy

### Transparency
- We communicate openly about decisions
- We document our processes and reasoning
- We welcome questions and feedback

### Quality
- We take pride in our work
- We review code thoughtfully and constructively
- We maintain high standards while being supportive

### Inclusivity
- We actively welcome newcomers
- We use inclusive language
- We create space for all voices to be heard

## Maintainer Responsibilities

As project maintainers, we pledge to:

- Model the behavior outlined in this Code of Conduct
- Respond to Code of Conduct violations fairly and transparently
- Take appropriate corrective action when needed
- Communicate clearly about enforcement decisions
- Protect the privacy and security of those who report issues
- Continuously improve our community practices

## Scope of Responsibility

Maintainers are responsible for:

✅ **Issues and Pull Requests**: Comments, code review feedback, decisions
✅ **Discussions**: Forum posts, questions, community interactions
✅ **Communication Channels**: Email, chat, social media as project representatives
✅ **Events**: Conferences, meetups, online gatherings related to the project

## Recognition

We recognize and celebrate positive community contributions:

- Thoughtful code reviews
- Helpful answers to questions
- Improvements to documentation
- Welcoming and mentoring newcomers
- Organizing community events
- Promoting inclusivity and respect

## Questions

Questions about this Code of Conduct? Contact:
- **Email**: [mikelane@gmail.com](mailto:mikelane@gmail.com)
- **Discussions**: [GitHub Discussions](https://github.com/mikelane/pytest-test-categories/discussions)

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant][homepage],
version 2.1, available at
[https://www.contributor-covenant.org/version/2/1/code_of_conduct.html][v2.1].

Community Impact Guidelines were inspired by
[Mozilla's code of conduct enforcement ladder][Mozilla CoC].

For answers to common questions about this code of conduct, see the FAQ at
[https://www.contributor-covenant.org/faq][FAQ]. Translations are available at
[https://www.contributor-covenant.org/translations][translations].

[homepage]: https://www.contributor-covenant.org
[v2.1]: https://www.contributor-covenant.org/version/2/1/code_of_conduct.html
[Mozilla CoC]: https://github.com/mozilla/diversity
[FAQ]: https://www.contributor-covenant.org/faq
[translations]: https://www.contributor-covenant.org/translations

---

*Thank you for helping make our community welcoming and inclusive!*

*Last updated: November 2024*
