License and Disclaimer
======================

Unless otherwise noted, this project is in the public domain in the United
States because it contains materials that originally came from the United
States Geological Survey, an agency of the United States Department of
Interior. For more information, see the `LICENSE.md`_ file. See the
`Disclaimer.md`_ file for more information about the disclaimer.

.. _LICENSE.md: https://github.com/DOI-USGS/dataretrieval-python/blob/main/LICENSE.md

.. _Disclaimer.md: https://github.com/DOI-USGS/dataretrieval-python/blob/main/DISCLAIMER.md