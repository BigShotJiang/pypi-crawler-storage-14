.. _waterdata:

dataretrieval.waterdata
-------------------------

.. automodule:: dataretrieval.waterdata
    :members:
    :special-members: