.. _nwis:

dataretrieval.nwis
------------------

.. automodule:: dataretrieval.nwis
    :members:
    :special-members: