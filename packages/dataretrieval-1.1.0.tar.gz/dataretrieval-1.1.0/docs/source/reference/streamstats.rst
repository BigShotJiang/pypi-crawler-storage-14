.. _streamstats:

dataretrieval.streamstats
-------------------------

.. automodule:: dataretrieval.streamstats
    :members:
    :special-members: