.. userguide:

==========
User Guide
==========

Topic guides to provide additional information about various aspects of
``dataretrieval``.

Contents
--------

.. toctree::
    :maxdepth: 1

    timeconventions
    dataportals
