from pipelex.base_exceptions import PipelexError


class DomainLibraryError(PipelexError):
    pass
