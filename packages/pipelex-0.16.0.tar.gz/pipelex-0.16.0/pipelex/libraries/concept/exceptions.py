from pipelex.base_exceptions import PipelexError


class ConceptLibraryError(PipelexError):
    pass
