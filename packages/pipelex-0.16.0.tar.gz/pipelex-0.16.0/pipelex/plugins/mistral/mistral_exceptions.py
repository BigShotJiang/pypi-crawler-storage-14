from pipelex.cogt.exceptions import CogtError


class MistralModelListingError(CogtError):
    pass


class MistralWorkerConfigurationError(CogtError):
    pass
