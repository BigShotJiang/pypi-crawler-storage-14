from pipelex.base_exceptions import PipelexError


class PipeComposeFactoryError(PipelexError):
    pass
