from pipelex.base_exceptions import PipelexError


class PipelexBundleSpecBlueprintError(PipelexError):
    pass
