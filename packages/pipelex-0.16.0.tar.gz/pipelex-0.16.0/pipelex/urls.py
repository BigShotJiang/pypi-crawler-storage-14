class URLs:
    homepage = "https://pipelex.com"
    repository = "https://github.com/Pipelex/pipelex"
    documentation = "https://docs.pipelex.com/"
    changelog = "https://docs.pipelex.com/changelog/"
    discord = "https://go.pipelex.com/discord"
    pipe_func_docs = "https://docs.pipelex.com/home/6-build-reliable-ai-workflows/pipes/pipe-operators/PipeFunc/"
    backend_provider_docs = "https://docs.pipelex.com/home/5-setup/configure-ai-providers/"
