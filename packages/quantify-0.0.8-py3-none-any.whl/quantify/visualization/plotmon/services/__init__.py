"""Services for the Plotmon application."""
