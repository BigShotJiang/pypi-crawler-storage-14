"""Figure builder services for the Plotmon application."""
