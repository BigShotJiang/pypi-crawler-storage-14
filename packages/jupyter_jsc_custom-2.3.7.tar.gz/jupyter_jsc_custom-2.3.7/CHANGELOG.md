## 0.12.25 (2025-04-09)

No changes.

## 0.12.24 (2025-04-08)

No changes.

## 0.12.23 (2025-03-19)

No changes.

## 0.12.22 (2025-03-19)

No changes.

## 0.12.21 (2025-03-17)

No changes.

## 0.12.20 (2025-03-17)

No changes.

## 0.12.19 (2025-03-11)

No changes.

## 0.12.18 (2025-03-11)

No changes.

## 0.12.17 (2025-03-10)

No changes.

## 0.12.16 (2025-03-09)

No changes.

## 0.12.15 (2025-03-04)

No changes.

## 0.12.14 (2025-02-20)

No changes.

## 0.12.13 (2025-02-19)

No changes.

## 0.12.12 (2025-02-12)

No changes.

## 0.12.11 (2025-02-11)

No changes.

## 0.12.10 (2025-02-10)

No changes.

## 0.12.9 (2025-02-10)

No changes.

## 0.12.8 (2025-02-07)

No changes.

## 0.12.7 (2025-02-07)

No changes.

## 0.12.6 (2025-02-06)

No changes.

## 0.12.5 (2025-02-05)

No changes.

## 0.12.4 (2025-02-05)

No changes.

## 0.12.3 (2025-02-05)

No changes.

## 0.12.2 (2025-02-05)

No changes.

## 0.12.1 (2025-02-05)

No changes.

## 0.12.0 (2025-02-05)

No changes.

## 0.11.10 (2025-01-01)

No changes.

## 0.11.9 (2024-12-20)

No changes.

## 0.11.8 (2024-12-19)

No changes.

## 0.11.7 (2024-11-14)

No changes.

## 0.11.6 (2024-10-31)

No changes.

## 0.11.5 (2024-10-30)

No changes.

## 0.11.4 (2024-10-29)

No changes.

## 0.11.3 (2024-10-23)

No changes.

## 0.11.2 (2024-10-21)

No changes.

## 0.11.1 (2024-09-27)

No changes.

## 0.11.0 (2024-09-26)

No changes.

## 0.10.13 (2024-06-28)

No changes.

## 0.10.12 (2024-06-28)

No changes.

## 0.10.11 (2024-06-10)

No changes.

## 0.10.10 (2024-06-10)

No changes.

## 0.10.9 (2024-05-29)

### added|fixed|changed|deprecated|removed|security|performance|other (1 change)

- [fix username claim for default unity-jsc group behaviour](jupyterjsc/packages/jupyter-jsc-custom@dcdbf205b464469c6f4090c961213adfd2eac0f1) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!6))

## 0.10.8 (2024-05-27)

### added (1 change)

- [Resolve "No VO should map to default group"](jupyterjsc/packages/jupyter-jsc-custom@effdeda5d0600fb9f32714991b54432e1a50935d) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!5))

## 0.10.7 (2024-05-02)

No changes.

## 0.10.6 (2024-05-01)

make reservation key path configurable

## 0.10.5 (2024-04-30)

fix addUsers reservation devel part

## 0.10.4 (2024-04-30)

### fixed (1 change)

- [Resolve "reservation not updated without re-login"](jupyterjsc/packages/jupyter-jsc-custom@7c16bec50a40b4730f71bca77b9f698d014ec860) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!4))

## 0.10.3 (2024-04-30)

add spawner.start_id to "Start service" logline

## 0.10.2 (2024-04-30)

fix logging in start process

## 0.10.1 (2024-04-25)

### added (1 change)

- [send outpost flavor update url env variable to LRZ systems](jupyterjsc/packages/jupyter-jsc-custom@7f53691f3c9763a44479648f22bc75e007580ea1) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!3))

### fixed (1 change)

- [Resolve "fix slurm provisioner"](jupyterjsc/packages/jupyter-jsc-custom@58c2fe0be82680ee4717266e44f6e2f4c6762fe5) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!2))

## 0.10.0 (2024-04-22)

### other (1 change)

- [Test cicd pipeline](jupyterjsc/packages/jupyter-jsc-custom@bb7f2822d9f6739caf73602660b7f5cea2261d18) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!1))

## 0.9.35.post1 (2024-04-23)

### fixed (1 change)

- [Resolve "fix slurm provisioner"](jupyterjsc/packages/jupyter-jsc-custom@58c2fe0be82680ee4717266e44f6e2f4c6762fe5) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!2))

### other (1 change)

- [Test cicd pipeline](jupyterjsc/packages/jupyter-jsc-custom@bb7f2822d9f6739caf73602660b7f5cea2261d18) ([merge request](jupyterjsc/packages/jupyter-jsc-custom!1))
