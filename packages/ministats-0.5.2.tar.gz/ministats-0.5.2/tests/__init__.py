"""Unit test package for ministats."""
