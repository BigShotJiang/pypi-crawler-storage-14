# make this folder a package on all pythons

from .ziptools import *    # pkg dir content is same as ./ziptools.py
