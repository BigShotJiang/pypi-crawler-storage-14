"""Treatments module."""
