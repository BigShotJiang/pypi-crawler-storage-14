"""The diagnostic module."""
