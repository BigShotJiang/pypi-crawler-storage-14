"""Research schema package."""
