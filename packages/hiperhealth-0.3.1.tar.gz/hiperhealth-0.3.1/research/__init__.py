"""Research package."""
