import asyncio
import sys

async def main():
    # cli maybe?
    print("Not implemented")

if __name__ == "__main__":
    asyncio.run(main())
