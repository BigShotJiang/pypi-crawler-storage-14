Installation
============

To install the Directed Inputs Class library, you can use pip:

.. code-block:: bash

    pip install directed-inputs-class
