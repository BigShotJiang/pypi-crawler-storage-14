Changelog
==========

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/) and this project adheres to [Semantic Versioning](https://semver.org/).

<!-- changelog follows -->


Changelog
==========

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/) and this project adheres to [Semantic Versioning](https://semver.org/).

<!-- changelog follows -->


Changelog
==========

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/) and this project adheres to [Semantic Versioning](https://semver.org/).

<!-- changelog follows -->


Changelog
==========

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/) and this project adheres to [Semantic Versioning](https://semver.org/).

<!-- changelog follows -->


## [1.0.0](https://github.com/jbcom/extended-data-types/tree/1.0.0) - 2024-10-01

### Feat

- upgraded to the latest extended-data-types which requires dropping support for Python 3.8

## [0.1.2](https://github.com/jbcom/extended-data-types/tree/0.1.2) - 2024-10-01



## [0.1.1](https://github.com/jbcom/extended-data-types/tree/0.1.1) - 2024-10-01

### Fix

- handle edge cases where inputs are retrieved already decoded
      - **Scope**: src/directed_inputs_class/__main__.py

## [0.1.0](https://github.com/jbcom/extended-data-types/tree/0.1.0) - 2024-08-27
