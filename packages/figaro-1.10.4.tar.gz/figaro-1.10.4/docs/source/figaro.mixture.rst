figaro.mixture module
=====================

.. automodule:: figaro.mixture
   :members:
   :undoc-members:
   :show-inheritance:
