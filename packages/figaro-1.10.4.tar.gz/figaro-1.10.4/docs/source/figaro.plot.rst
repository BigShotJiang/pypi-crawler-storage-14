figaro.plot module
==================

.. automodule:: figaro.plot
   :members:
   :undoc-members:
   :show-inheritance:
