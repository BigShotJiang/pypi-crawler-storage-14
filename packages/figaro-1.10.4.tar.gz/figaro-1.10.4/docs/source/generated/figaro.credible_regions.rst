﻿figaro.credible\_regions
========================

.. automodule:: figaro.credible_regions

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      ConfidenceArea
      ConfidenceVolume
      FindHeightForLevel
      FindHeights
      FindLevelForHeight
      FindNearest_Grid
      FindNearest_Volume
   
   

   
   
   

   
   
   



