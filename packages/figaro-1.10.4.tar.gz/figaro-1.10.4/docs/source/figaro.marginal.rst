figaro.marginal module
======================

.. automodule:: figaro.marginal
   :members:
   :undoc-members:
   :show-inheritance:
