# flake8: noqa

# import apis into api package
from intervals_icu_client.api.activities_api import ActivitiesApi
from intervals_icu_client.api.athletes_api import AthletesApi
from intervals_icu_client.api.chats_api import ChatsApi
from intervals_icu_client.api.custom_items_api import CustomItemsApi
from intervals_icu_client.api.events_api import EventsApi
from intervals_icu_client.api.gear_api import GearApi
from intervals_icu_client.api.library_api import LibraryApi
from intervals_icu_client.api.routes_api import RoutesApi
from intervals_icu_client.api.shared_events_api import SharedEventsApi
from intervals_icu_client.api.sports_api import SportsApi
from intervals_icu_client.api.weather_api import WeatherApi
from intervals_icu_client.api.wellness_api import WellnessApi
from intervals_icu_client.api.o_auth_server_controller_api import OAuthServerControllerApi

