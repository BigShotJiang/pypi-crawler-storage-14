"""Quality assessment tools for doc-manager."""

from .assessment import assess_quality

__all__ = ["assess_quality"]
