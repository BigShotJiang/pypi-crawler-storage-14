from ezl import task, run


@task(buffer=100, workers=0)
async def extractor():
    for i in range(10):
        yield {"id": i, "value": i}


@task(buffer=100, workers=2)
def transform_even(item):
    item["processed"] = item["value"] * 2
    return item


@task(buffer=100, workers=2)
def transform_odd(item):
    item["processed"] = item["value"] ** 2
    return item


@task(workers=0)
async def load(item):
    print(f"Loaded: {item}")


def is_even(item):
    return item["value"] % 2 == 0


if __name__ == "__main__":
    pipeline = (
        extractor >> (transform_even | transform_odd)
        ^ is_even >> load
    )
    run(p=pipeline)
