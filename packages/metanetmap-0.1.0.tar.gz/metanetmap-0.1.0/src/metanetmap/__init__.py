"""Top-level package for MetaNetMap."""

__author__ = """Coralie Muller"""
__email__ = "coralie.muller@inria.fr"
__version__ = "0.1.0"
