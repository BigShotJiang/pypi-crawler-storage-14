__pypi_version__ = "2025.11.27";__local_version__ = "2025.11.27+24e71ce"
