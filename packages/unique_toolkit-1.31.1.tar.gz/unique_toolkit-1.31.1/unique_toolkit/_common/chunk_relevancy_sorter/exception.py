from unique_toolkit._common.exception import CommonException


class ChunkRelevancySorterException(CommonException):
    pass
