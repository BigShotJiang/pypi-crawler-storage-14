"""Variable-derivation helpers for NUDB pipelines."""
