"""Utilities for working with NUDB storage paths."""
