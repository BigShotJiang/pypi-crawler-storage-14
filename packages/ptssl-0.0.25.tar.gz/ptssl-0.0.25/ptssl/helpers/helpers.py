"""
Helpers module for shared functionality used across test modules.
"""

import json
import os
import textwrap

from ptlibs.http.http_client import HttpClient
from ptlibs.ptprinthelper import ptprint

class Helpers:
    def __init__(self, args: object, ptjsonlib: object, http_client: object):
        """
        Helpers provides utility methods for loading definition files
        and making HTTP requests in a consistent way across modules.
        """
        self.args = args
        self.ptjsonlib = ptjsonlib
        self.http_client = http_client

    def fetch(self, url, allow_redirects=False):
        """
        Sends an HTTP GET request to the specified URL.

        Args:
            url (str): URL to fetch.
            allow_redirects (bool, optional): Whether to follow redirects. Defaults to False.

        Returns:
            Response: The HTTP response object.
        """
        try:
            response = self.http_client.send_request(
                url=url,
                method="GET",
                headers=self.args.headers,
                allow_redirects=allow_redirects,
                timeout=self.args.timeout
            )
            return response

        except Exception as e:
            return None

    def print_section_items(self, items, verbose=False):
        """
        items: list of dicts with keys:
            - 'display_name'
            - 'finding'
            - 'severity'
            - optionally 'description'
        Prints all items with aligned first column and wrapped second column.
        """
        # Determine max width of the first column
        max_width = max(len(item['display_name']) for item in items) + 2  # +2 spaces

        for item in items:
            name = item['display_name']
            finding = item['finding']
            severity = item['severity']
            description = item.get('description') if verbose else None

            # Wrap the finding text so the second column is aligned
            wrapper = textwrap.TextWrapper(width=80, subsequent_indent=' ' * (max_width + 2))
            wrapped_finding = wrapper.fill(f"{name:<{max_width}}  {finding}")

            ptprint(wrapped_finding, severity, not False, indent=4)

            if description:
                wrapper_desc = textwrap.TextWrapper(width=80, subsequent_indent=' ' * 6)
                ptprint(wrapper_desc.fill(description), "ADDITIONS", not False, indent=6, colortext=True)
