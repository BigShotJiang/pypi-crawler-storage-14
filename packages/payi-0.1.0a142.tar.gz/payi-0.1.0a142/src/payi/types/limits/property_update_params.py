# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, TypedDict

__all__ = ["PropertyUpdateParams"]


class PropertyUpdateParams(TypedDict, total=False):
    properties: Required[Dict[str, Optional[str]]]
