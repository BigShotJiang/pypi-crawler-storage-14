import datetime
import os
import random
import string
import time


def save_log(filename, log_content):
    """
    保存日志到指定文件

    :param filename: 日志文件名
    :param log_content: 需要保存的日志内容
    """
    # 定义日志文件夹路径
    log_dir = "logs"
    # 检查log文件夹是否存在，不存在则创建
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    # 构建完整的文件路径
    file_path = os.path.join(log_dir, filename)
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # 以追加模式打开文件，如果文件不存在会自动创建
    with open(file_path+".txt", 'a', encoding='utf-8') as file:
        file.write(f"[{current_time}] {log_content}\n")
def txt_random_string(num, uppercase=True, lowercase=True, digits=True):
    """
    生成随机字符串

    Args:
        num (int): 生成字符串的长度
        uppercase (bool): 是否包含大写字母
        lowercase (bool): 是否包含小写字母
        digits (bool): 是否包含数字

    Returns:
        str: 生成的随机字符串
    """
    if not any([uppercase, lowercase, digits]):
        raise ValueError("至少需要启用一种字符类型")

    # 构建字符池
    char_pool = ""
    if uppercase:
        char_pool += string.ascii_uppercase
    if lowercase:
        char_pool += string.ascii_lowercase
    if digits:
        char_pool += string.digits

    # 生成随机字符串
    return ''.join(random.choices(char_pool, k=num))


def txt_get_between(text, start_text, end_text):
    """
    获取两个文本之间的内容（不包含边界文本）

    Args:
        text (str): 原始文本
        start_text (str): 开始文本
        end_text (str): 结束文本

    Returns:
        str: 两个文本之间的内容，如果找不到则返回空字符串
    """
    # 查找开始文本的位置
    start_index = text.find(start_text)
    if start_index == -1:
        return ""

    # 计算开始位置（跳过开始文本）
    start_pos = start_index + len(start_text)

    # 从开始位置查找结束文本
    end_index = text.find(end_text, start_pos)
    if end_index == -1:
        return ""

    # 返回中间的文本
    return text[start_pos:end_index]


def txt_get_left(text, delimiter):
    """
    获取文本中指定分隔符左边的内容

    Args:
        text (str): 原始文本
        delimiter (str): 分隔符

    Returns:
        str: 分隔符左边的内容，如果找不到分隔符则返回空字符串
    """
    index = text.find(delimiter)
    if index == -1:
        return ""
    return text[:index]


def txt_get_right(text, delimiter):
    """
    获取文本中指定分隔符右边的内容

    Args:
        text (str): 原始文本
        delimiter (str): 分隔符

    Returns:
        str: 分隔符右边的内容，如果找不到分隔符则返回空字符串
    """
    index = text.find(delimiter)
    if index == -1:
        return ""
    return text[index + len(delimiter):]


def cookie_dict_to_string(cookie_dict):
    """
    将字典格式的cookie转换为字符串格式(key=value; key=value)

    Args:
        cookie_dict (dict): cookie字典

    Returns:
        str: 字符串格式的cookie
    """
    if not isinstance(cookie_dict, dict):
        raise ValueError("输入必须是字典类型")

    cookie_items = []
    for key, value in cookie_dict.items():
        cookie_items.append(f"{key}={value}")

    return "; ".join(cookie_items)


def cookie_string_to_dict(cookie_string):
    """
    将字符串格式的cookie转换为字典格式

    Args:
        cookie_string (str): 字符串格式的cookie (key=value; key=value)

    Returns:
        dict: cookie字典
    """
    if not isinstance(cookie_string, str):
        raise ValueError("输入必须是字符串类型")

    cookie_dict = {}
    if not cookie_string.strip():
        return cookie_dict

    # 按分号分割cookie项
    items = cookie_string.split(";")
    for item in items:
        item = item.strip()  # 去除前后空格
        if "=" in item:
            key, value = item.split("=", 1)  # 只分割第一个等号
            cookie_dict[key.strip()] = value.strip()

    return cookie_dict


def cookie_merge(old_cookie, new_cookie):
    """
    合并更新cookie，支持字典和字符串两种格式

    Args:
        old_cookie (dict or str): 旧cookie
        new_cookie (dict or str): 新cookie

    Returns:
        dict or str: 合并后的cookie，格式与old_cookie保持一致
    """
    # 判断输入类型
    old_is_dict = isinstance(old_cookie, dict)
    new_is_dict = isinstance(new_cookie, dict)

    # 统一转换为字典格式进行处理
    if old_is_dict:
        old_dict = old_cookie.copy()
    else:
        old_dict = cookie_string_to_dict(old_cookie)

    if new_is_dict:
        new_dict = new_cookie
    else:
        new_dict = cookie_string_to_dict(new_cookie)

    # 合并cookie，新cookie覆盖旧cookie
    merged_dict = {**old_dict, **new_dict}

    # 根据原始格式返回结果
    if old_is_dict:
        return merged_dict
    else:
        return cookie_dict_to_string(merged_dict)


def time_get_timestamp(is_10_digits=False):
    """
    获取当前时间戳

    Args:
        is_10_digits (bool): 是否返回10位时间戳，默认为False（返回13位毫秒时间戳）

    Returns:
        int: 时间戳
    """
    if is_10_digits:
        # 返回10位时间戳（秒级）
        return int(time.time())
    else:
        # 返回13位时间戳（毫秒级）
        return int(time.time() * 1000)


def time_random_timestamp():
    """
    生成一个随机的时间戳（类似0.842703761170252格式的小数）

    Returns:
        float: 随机时间戳
    """
    return random.random()


def time_format(time_value, date_format=None, time_format=None, is_24_hour=True):
    """
    格式化指定日期与时间，失败返回空文本

    Args:
        time_value (datetime.datetime or int or float): 欲格式化的时间
        date_format (str, optional): 日期格式，如: yyyy/M/d dddd(年/月/日 星期几)
        time_format (str, optional): 时间格式，如: hh:mm:ss(小时:分钟:秒)
        is_24_hour (bool, optional): 是否为24小时制，默认为True

    Returns:
        str: 格式化后的日期时间字符串，失败返回空字符串
    """
    try:
        # 处理不同类型的输入时间
        if isinstance(time_value, (int, float)):
            # 如果是时间戳，转换为datetime对象
            if time_value > 10000000000:  # 13位时间戳
                time_value = datetime.datetime.fromtimestamp(time_value / 1000)
            else:  # 10位时间戳
                time_value = datetime.datetime.fromtimestamp(time_value)
        elif not isinstance(time_value, datetime.datetime):
            return ""

        # 默认格式
        if date_format is None and time_format is None:
            return time_value.strftime("%Y-%m-%d %H:%M:%S")

        # 构建格式化字符串
        format_str = ""

        # 处理日期格式
        if date_format:
            # 替换易语言格式为Python格式
            date_format = date_format.replace("yyyy", "%Y")
            date_format = date_format.replace("MM", "%m")
            date_format = date_format.replace("M", "%m")
            date_format = date_format.replace("dd", "%d")
            date_format = date_format.replace("d", "%d")
            date_format = date_format.replace("dddd", "%A")
            format_str += date_format

        # 添加空格分隔符
        if date_format and time_format:
            format_str += " "

        # 处理时间格式
        if time_format:
            # 处理上午/下午
            if "tt" in time_format:
                if is_24_hour:
                    time_format = time_format.replace("tt", "")
                    time_format = time_format.replace("hh", "%H")
                    time_format = time_format.replace("h", "%H")
                else:
                    time_format = time_format.replace("tt", "%p")
                    time_format = time_format.replace("hh", "%I")
                    time_format = time_format.replace("h", "%I")
            else:
                time_format = time_format.replace("hh", "%H")
                time_format = time_format.replace("h", "%H")

            time_format = time_format.replace("mm", "%M")
            time_format = time_format.replace("m", "%M")
            time_format = time_format.replace("ss", "%S")
            time_format = time_format.replace("s", "%S")

            format_str += time_format

        # 格式化时间
        result = time_value.strftime(format_str.strip())

        # 处理星期中文显示
        if "%A" in format_str:
            weekdays = {
                'Monday': '星期一',
                'Tuesday': '星期二',
                'Wednesday': '星期三',
                'Thursday': '星期四',
                'Friday': '星期五',
                'Saturday': '星期六',
                'Sunday': '星期日'
            }
            for eng, chn in weekdays.items():
                result = result.replace(eng, chn)

        # 处理上午/下午中文显示
        if "%p" in format_str:
            result = result.replace("AM", "上午").replace("PM", "下午")

        return result

    except Exception as e:
        raise  e

if __name__ == '__main__':
    print(time_format(time.time(), "yyyy/M/d"))
