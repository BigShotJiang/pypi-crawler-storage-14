# Contributing

Any contribution to Fish&Feats are very welcome !

Please, create a fork of this repository and make a Pull Request with an overview of the contribution.

Don't hesitate to first contact us to discuss the changes you are going to make (through an issue in the repository or by email).
