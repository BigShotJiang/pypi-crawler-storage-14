#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
import os

# Read version from __init__.py
with open(os.path.join("hos_vortex", "__init__.py"), "r") as f:
    for line in f:
        if line.startswith("__version__"):
            version = line.strip().split("=")[1].strip().strip('"')
            break
    else:
        version = "0.0.1"

# Read long description from README.md
with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="hos_vortex",
    version=version,
    author="Red Team Research",
    author_email="research@redteam.example",
    description="HOS_Vortex - Advanced Red Team Penetration AI Toolkit",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/redteamresearch/hos_vortex",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Information Technology",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Security",
        "Topic :: System :: Networking :: Monitoring",
        "Topic :: Utilities",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Core dependencies
        "python-dateutil>=2.8.2",
        # Network dependencies
        "python-nmap>=0.6.1",
        "paramiko>=2.10.0",
        "netmiko>=4.1.0",
        "pyserial>=3.5",
        # AI dependencies
        "scikit-learn>=1.2.0",
        "pandas>=1.5.0",
        "numpy>=1.23.0",
        "matplotlib>=3.6.0",
        "joblib>=1.2.0",
        # Data processing
        "pyyaml>=6.0",
        "ruamel.yaml>=0.17.0",
        "pygments>=2.14.0",
        "textfsm>=1.1.0",
        # C2 communication
        "python-socketio>=5.8.0",
        "socketio-client>=0.7.2",
        "flask>=2.2.0",
        "flask-socketio>=5.3.0",
        "websocket-client>=1.5.0",
        # Security
        "pyOpenSSL>=23.0.0",
        "cryptography>=39.0.0",
        "pyjwt>=2.6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "flake8>=5.0.0",
            "black>=22.0.0",
            "mypy>=0.971",
        ],
    },
    entry_points={
        "console_scripts": [
            "hos=hos_vortex.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "hos_vortex": ["config/*"],
    },
    zip_safe=False,
    project_urls={
        "Bug Reports": "https://github.com/redteamresearch/hos_vortex/issues",
        "Source": "https://github.com/redteamresearch/hos_vortex",
        "Documentation": "https://github.com/redteamresearch/hos_vortex/wiki",
    },
)
