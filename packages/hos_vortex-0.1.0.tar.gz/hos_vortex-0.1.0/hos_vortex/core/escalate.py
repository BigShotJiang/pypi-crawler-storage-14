#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Privilege escalation module for HOS_Hyacinth"""

import argparse
import os
import platform
import subprocess
import json
import psutil
from typing import Dict, Any, List, Optional

from ..utils import logger, config

class PrivilegeEscalator:
    """Class for handling privilege escalation attempts."""
    
    def __init__(self, target: Optional[str] = None, dev_mode: bool = False):
        """Initialize the privilege escalator.
        
        Args:
            target: Target system to escalate privileges on (local if None)
            dev_mode: Run in development mode with safe operations
        """
        self.target = target if target else 'localhost'
        self.dev_mode = dev_mode
        self.logger = logger
        self.config = config
        self.system_info = {}
        self.vulnerabilities = []
        self.escalation_attempts = []
        self.escalation_result = None
    
    def enumerate_system_info(self) -> Dict[str, Any]:
        """Enumerate system information for privilege escalation reconnaissance.
        
        Returns:
            Dict[str, Any]: System information details
        """
        self.logger.info(f'Enumerating system information for {self.target}')
        
        # Get basic OS information
        self.system_info = {
            'os_name': platform.system(),
            'os_version': platform.version(),
            'os_release': platform.release(),
            'architecture': platform.architecture()[0],
            'hostname': platform.node(),
            'python_version': platform.python_version()
        }
        
        # Add user information
        if self.target == 'localhost':
            try:
                # Get current user information
                if platform.system() == 'Windows':
                    import getpass
                    self.system_info['current_user'] = getpass.getuser()
                    # Check if admin
                    import ctypes
                    self.system_info['is_admin'] = ctypes.windll.shell32.IsUserAnAdmin() != 0
                else:
                    import pwd
                    user_info = pwd.getpwuid(os.getuid())
                    self.system_info['current_user'] = user_info.pw_name
                    self.system_info['is_admin'] = os.geteuid() == 0  # Check if root
            except Exception as e:
                self.logger.error(f'Error gathering user information: {str(e)}')
        
        # Get running processes information
        try:
            self.system_info['process_count'] = len(psutil.pids())
            # Get top processes by memory usage
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'username', 'memory_percent']):
                try:
                    proc_info = proc.info
                    processes.append(proc_info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            # Sort by memory usage and take top 10
            processes.sort(key=lambda x: x['memory_percent'], reverse=True)
            self.system_info['top_processes'] = processes[:10]
        except Exception as e:
            self.logger.error(f'Error gathering process information: {str(e)}')
        
        self.logger.info(f'System enumeration complete: {json.dumps(self.system_info, indent=2)}')
        return self.system_info
    
    def check_vulnerabilities(self) -> List[Dict[str, Any]]:
        """Check for common privilege escalation vulnerabilities.
        
        Returns:
            List[Dict[str, Any]]: List of discovered vulnerabilities
        """
        self.logger.info('Checking for common privilege escalation vulnerabilities')
        
        # Clear previous vulnerabilities
        self.vulnerabilities = []
        
        # Check for SUID/SGID binaries (Linux/Unix only)
        if self.system_info.get('os_name') not in ['Windows'] and self.target == 'localhost':
            try:
                # This is a safe check - just looking for files, not executing
                if self.dev_mode:
                    self.logger.info('In dev mode - simulating SUID/SGID scan')
                    self.vulnerabilities.append({
                        'type': 'SUID_BINARIES',
                        'severity': 'medium',
                        'description': 'Simulated SUID/SGID binaries found in dev mode',
                        'remediation': 'Review and remove unnecessary SUID/SGID permissions'
                    })
                else:
                    # In production, we would scan for actual SUID/SGID files
                    pass
            except Exception as e:
                self.logger.error(f'Error checking SUID/SGID files: {str(e)}')
        
        # Check for unquoted service paths (Windows only)
        if self.system_info.get('os_name') == 'Windows' and self.target == 'localhost':
            if self.dev_mode:
                self.logger.info('In dev mode - simulating Windows service check')
                self.vulnerabilities.append({
                    'type': 'UNQUOTED_SERVICE_PATH',
                    'severity': 'medium',
                    'description': 'Simulated unquoted service path vulnerability in dev mode',
                    'remediation': 'Use fully quoted paths in service configurations'
                })
        
        # Check for weak file permissions
        self.check_weak_permissions()
        
        self.logger.info(f'Found {len(self.vulnerabilities)} potential privilege escalation vectors')
        return self.vulnerabilities
    
    def check_weak_permissions(self):
        """Check for files with weak permissions."""
        try:
            # In dev mode, we just simulate findings
            if self.dev_mode:
                self.vulnerabilities.append({
                    'type': 'WEAK_FILE_PERMISSIONS',
                    'severity': 'high',
                    'description': 'Simulated weak file permissions found in dev mode',
                    'remediation': 'Restrict file permissions to least privilege'
                })
        except Exception as e:
            self.logger.error(f'Error checking file permissions: {str(e)}')
    
    def attempt_escalation(self) -> Dict[str, Any]:
        """Attempt privilege escalation based on identified vulnerabilities.
        
        Returns:
            Dict[str, Any]: Escalation attempt results
        """
        self.logger.info('Attempting privilege escalation')
        
        # In development mode, we never attempt actual escalation
        if self.dev_mode:
            self.logger.warning('In dev mode - no actual privilege escalation attempts will be made')
            # Simulate escalation attempts for each vulnerability
            for vuln in self.vulnerabilities:
                attempt = {
                    'vulnerability_type': vuln['type'],
                    'attempted': True,
                    'success': False,
                    'message': f'Simulated escalation attempt for {vuln["type"]} in dev mode',
                    'dev_mode': True
                }
                self.escalation_attempts.append(attempt)
        else:
            # In production mode, we would attempt real escalation techniques
            # This would be highly contextual based on the vulnerabilities found
            pass
        
        # Check if any escalation attempt was successful
        self.escalation_result = {
            'attempted_vectors': len(self.escalation_attempts),
            'successful_attempts': sum(1 for attempt in self.escalation_attempts if attempt['success']),
            'success': any(attempt['success'] for attempt in self.escalation_attempts),
            'details': self.escalation_attempts
        }
        
        return self.escalation_result
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate a comprehensive privilege escalation report.
        
        Returns:
            Dict[str, Any]: Full escalation report
        """
        report = {
            'timestamp': subprocess.check_output(['powershell', '(Get-Date).ToString(\"yyyy-MM-dd HH:mm:ss\")']).decode('utf-8').strip() if platform.system() == 'Windows' else subprocess.check_output(['date', '+%Y-%m-%d %H:%M:%S']).decode('utf-8').strip(),
            'target': self.target,
            'dev_mode': self.dev_mode,
            'system_info': self.system_info,
            'vulnerabilities': self.vulnerabilities,
            'escalation_attempts': self.escalation_attempts,
            'escalation_result': self.escalation_result,
            'recommendations': self._generate_recommendations()
        }
        
        return report
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations based on findings.
        
        Returns:
            List[str]: Security recommendations
        """
        recommendations = []
        
        if self.vulnerabilities:
            recommendations.append('Address identified vulnerabilities to prevent privilege escalation')
            
            # Add specific recommendations based on vulnerability types
            vuln_types = set(v['type'] for v in self.vulnerabilities)
            
            if 'SUID_BINARIES' in vuln_types:
                recommendations.append('Audit and remove unnecessary SUID/SGID permissions from binaries')
            
            if 'UNQUOTED_SERVICE_PATH' in vuln_types:
                recommendations.append('Ensure all Windows service paths are properly quoted')
            
            if 'WEAK_FILE_PERMISSIONS' in vuln_types:
                recommendations.append('Implement proper file permissions following least privilege principle')
        
        recommendations.append('Regularly update the system and installed software')
        recommendations.append('Implement application whitelisting to prevent execution of unauthorized code')
        
        return recommendations
    
    def save_report(self, report_path: Optional[str] = None) -> str:
        """Save the privilege escalation report to a file.
        
        Args:
            report_path: Path to save the report. If None, a default path will be used.
            
        Returns:
            str: Path to the saved report file
        """
        if report_path is None:
            # Create a default report path
            from datetime import datetime
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            report_path = os.path.join(os.getcwd(), f'privilege_escalation_report_{timestamp}.json')
        
        report = self.generate_report()
        
        try:
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            self.logger.info(f'Report saved to {report_path}')
            return report_path
        except Exception as e:
            self.logger.error(f'Error saving report: {str(e)}')
            raise
    
    def execute(self, save_report: bool = True, output_path: Optional[str] = None) -> Dict[str, Any]:
        """Execute the complete privilege escalation workflow.
        
        Args:
            save_report: Whether to save the report to a file
            output_path: Path to save the report (overrides default path)
            
        Returns:
            Dict[str, Any]: Final privilege escalation results
        """
        try:
            # 1. Enumerate system information
            self.enumerate_system_info()
            
            # 2. Check for vulnerabilities
            self.check_vulnerabilities()
            
            # 3. Attempt privilege escalation
            self.attempt_escalation()
            
            # 4. Generate and optionally save report
            final_report = self.generate_report()
            if save_report:
                report_path = self.save_report(output_path)
                final_report['report_file'] = report_path
            
            # 5. Return the final results
            return {
                'success': final_report['escalation_result']['success'],
                'message': 'Privilege escalation process completed',
                'details': final_report
            }
        except Exception as e:
            self.logger.error(f'Error during privilege escalation: {str(e)}')
            return {
                'success': False,
                'message': f'Error during privilege escalation: {str(e)}',
                'details': {}
            }

def run(args: argparse.Namespace) -> None:
    """Attempt privilege escalation on target"""
    logger.info(f"Starting privilege escalation on target: {args.target}")
    logger.debug(f"Escalation parameters: {vars(args)}")
    
    # Check if in development mode
    is_dev_mode = config.get_mode()
    
    if is_dev_mode:
        logger.info("Running in DEVELOPMENT mode - detailed analysis enabled")
    else:
        logger.info("Running in PRODUCTION mode - optimized for performance")
    
    # Create and execute the privilege escalator
    escalator = PrivilegeEscalator(target=args.target, dev_mode=is_dev_mode)
    result = escalator.execute(save_report=args.output is not None, output_path=args.output)
    
    logger.info(f"Privilege escalation completed for target: {args.target}")
    
    if args.output:
        logger.info(f"Results saved to: {args.output}")
