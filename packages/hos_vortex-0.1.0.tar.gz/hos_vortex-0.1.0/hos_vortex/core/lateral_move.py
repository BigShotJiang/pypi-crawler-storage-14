#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Lateral movement module for HOS_Hyacinth"""

import argparse
import os
import platform
import subprocess
import json
import socket
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

from ..utils import logger, config


class LateralMover:
    """Class for handling lateral movement operations."""
    
    def __init__(self, source: str, destination: str, credentials: Optional[Dict[str, str]] = None, dev_mode: bool = False):
        """Initialize the lateral movement module.
        
        Args:
            source: Source system to move from
            destination: Target system to move to
            credentials: Authentication credentials (username, password, etc.)
            dev_mode: Run in development mode with safe operations
        """
        self.source = source
        self.destination = destination
        self.credentials = credentials or {}
        self.dev_mode = dev_mode
        self.logger = logger
        self.config = config
        self.available_resources = []
        self.connection_attempts = []
        self.movement_result = None
    
    def establish_source_connection(self) -> Dict[str, Any]:
        """Establish connection to the source system.
        
        Returns:
            Dict[str, Any]: Connection status and details
        """
        self.logger.info(f'Establishing connection to source system: {self.source}')
        
        # In dev mode, we simulate connection
        if self.dev_mode:
            self.logger.info('In dev mode - simulating source connection')
            connection_status = {
                'connected': True,
                'source': self.source,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'method': 'simulated',
                'dev_mode': True
            }
        else:
            # In production, attempt actual connection
            try:
                # Basic connectivity check
                if self.source == 'localhost' or self.source == socket.gethostname():
                    connection_status = {
                        'connected': True,
                        'source': self.source,
                        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'method': 'local',
                        'details': 'Local system access'
                    }
                else:
                    # Try to ping the source system
                    param = '-n' if platform.system().lower() == 'windows' else '-c'
                    result = subprocess.run(
                        ['ping', param, '1', self.source],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True
                    )
                    connection_status = {
                        'connected': result.returncode == 0,
                        'source': self.source,
                        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                        'method': 'network',
                        'details': 'Basic network connectivity check'
                    }
            except Exception as e:
                self.logger.error(f'Error establishing connection to source: {str(e)}')
                connection_status = {
                    'connected': False,
                    'source': self.source,
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'error': str(e)
                }
        
        self.logger.info(f'Source connection status: {json.dumps(connection_status, indent=2)}')
        return connection_status
    
    def enumerate_resources(self) -> List[Dict[str, Any]]:
        """Enumerate available resources and credentials on the source system.
        
        Returns:
            List[Dict[str, Any]]: List of discovered resources
        """
        self.logger.info(f'Enumerating resources on {self.source}')
        
        # Clear previous resources
        self.available_resources = []
        
        # In dev mode, we simulate resource enumeration
        if self.dev_mode:
            self.logger.info('In dev mode - simulating resource enumeration')
            # Simulate different types of resources
            self.available_resources = [
                {
                    'type': 'remote_share',
                    'name': 'C$',
                    'path': f'\\{self.source}\C$',
                    'access_level': 'read',
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                },
                {
                    'type': 'network_route',
                    'destination': '192.168.1.0/24',
                    'gateway': '192.168.1.1',
                    'interface': 'eth0',
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                },
                {
                    'type': 'local_credentials',
                    'username': 'test_user',
                    'domain': 'WORKGROUP',
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                },
                {
                    'type': 'ssh_key',
                    'path': '/home/user/.ssh/id_rsa',
                    'permissions': '600',
                    'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
            ]
        else:
            # In production, perform actual resource enumeration
            try:
                # Get network interfaces and routes
                if platform.system().lower() == 'windows':
                    # Windows route information
                    result = subprocess.run(
                        ['route', 'print'],
                        stdout=subprocess.PIPE,
                        text=True
                    )
                    # Parse routes and add to resources
                    if result.returncode == 0:
                        self.available_resources.append({
                            'type': 'network_routes',
                            'details': 'Windows routing table',
                            'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                else:
                    # Linux route information
                    result = subprocess.run(
                        ['ip', 'route'],
                        stdout=subprocess.PIPE,
                        text=True
                    )
                    if result.returncode == 0:
                        self.available_resources.append({
                            'type': 'network_routes',
                            'details': 'Linux routing table',
                            'discovered_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
            except Exception as e:
                self.logger.error(f'Error enumerating resources: {str(e)}')
        
        self.logger.info(f'Enumerated {len(self.available_resources)} resources on {self.source}')
        return self.available_resources
    
    def attempt_destination_connection(self) -> Dict[str, Any]:
        """Attempt connection to the destination system.
        
        Returns:
            Dict[str, Any]: Connection attempt results
        """
        self.logger.info(f'Attempting connection to destination: {self.destination}')
        
        # Clear previous attempts
        self.connection_attempts = []
        
        # Define connection methods to try
        connection_methods = [
            {'type': 'smb', 'name': 'SMB/WMI', 'description': 'Windows Management Instrumentation over SMB'},
            {'type': 'ssh', 'name': 'SSH', 'description': 'Secure Shell connection'},
            {'type': 'rdp', 'name': 'RDP', 'description': 'Remote Desktop Protocol'},
            {'type': 'winrm', 'name': 'WinRM', 'description': 'Windows Remote Management'}
        ]
        
        # Try each connection method
        for method in connection_methods:
            attempt = self._try_connection_method(method)
            self.connection_attempts.append(attempt)
            
            # In dev mode, don't actually connect, just simulate
            if self.dev_mode:
                self.logger.info(f'Simulated connection attempt using {method["name"]}')
            else:
                # In production, we might want to stop after first successful attempt
                if attempt['success']:
                    self.logger.info(f'Successful connection using {method["name"]}')
                    break
        
        # Compile overall result
        self.movement_result = {
            'destination': self.destination,
            'attempted_methods': len(self.connection_attempts),
            'successful_methods': sum(1 for attempt in self.connection_attempts if attempt['success']),
            'success': any(attempt['success'] for attempt in self.connection_attempts),
            'details': self.connection_attempts,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        return self.movement_result
    
    def _try_connection_method(self, method: Dict[str, Any]) -> Dict[str, Any]:
        """Try a specific connection method.
        
        Args:
            method: Method configuration
            
        Returns:
            Dict[str, Any]: Attempt result
        """
        start_time = time.time()
        
        # In dev mode, simulate results
        if self.dev_mode:
            # Randomly simulate success for some methods
            success = method['type'] in ['smb', 'ssh']  # Simulate success for SMB and SSH in dev mode
            attempt_result = {
                'method': method['type'],
                'name': method['name'],
                'description': method['description'],
                'success': success,
                'message': f'Simulated {method["name"]} connection attempt in dev mode',
                'duration': round(time.time() - start_time, 2),
                'dev_mode': True
            }
        else:
            # In production, attempt actual connection
            try:
                # For demonstration, we'll just check if the port is open
                port_map = {'smb': 445, 'ssh': 22, 'rdp': 3389, 'winrm': 5985}
                port = port_map.get(method['type'], 22)
                
                # Basic port check
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(2)
                    result = s.connect_ex((self.destination, port))
                    success = result == 0
                
                attempt_result = {
                    'method': method['type'],
                    'name': method['name'],
                    'description': method['description'],
                    'success': success,
                    'port': port,
                    'port_open': success,
                    'duration': round(time.time() - start_time, 2),
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                if success:
                    attempt_result['message'] = f'Successfully connected to port {port}'
                else:
                    attempt_result['message'] = f'Failed to connect to port {port}'
            except Exception as e:
                attempt_result = {
                    'method': method['type'],
                    'name': method['name'],
                    'description': method['description'],
                    'success': False,
                    'error': str(e),
                    'duration': round(time.time() - start_time, 2),
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
        
        return attempt_result
    
    def verify_movement(self) -> Dict[str, Any]:
        """Verify successful lateral movement.
        
        Returns:
            Dict[str, Any]: Verification results
        """
        self.logger.info(f'Verifying lateral movement to {self.destination}')
        
        # If no movement attempts were made, return failure
        if not self.connection_attempts:
            return {
                'verified': False,
                'message': 'No connection attempts were made',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        
        # In dev mode, simulate verification
        if self.dev_mode:
            self.logger.info('In dev mode - simulating movement verification')
            verified = any(attempt['success'] for attempt in self.connection_attempts)
            return {
                'verified': verified,
                'message': f'Simulated verification of lateral movement in dev mode',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'dev_mode': True
            }
        else:
            # In production, perform actual verification
            # For this example, we'll just check if any method was successful
            verified = any(attempt['success'] for attempt in self.connection_attempts)
            return {
                'verified': verified,
                'message': f'Verification of lateral movement to {self.destination}',
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
    
    def generate_report(self) -> Dict[str, Any]:
        """Generate a comprehensive lateral movement report.
        
        Returns:
            Dict[str, Any]: Full movement report
        """
        # Verify movement if not already done
        if not hasattr(self, 'verification_result'):
            self.verification_result = self.verify_movement()
        
        report = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'source': self.source,
            'destination': self.destination,
            'dev_mode': self.dev_mode,
            'available_resources': self.available_resources,
            'connection_attempts': self.connection_attempts,
            'movement_result': self.movement_result,
            'verification': self.verification_result,
            'recommendations': self._generate_recommendations()
        }
        
        return report
    
    def _generate_recommendations(self) -> List[str]:
        """Generate security recommendations based on findings.
        
        Returns:
            List[str]: Security recommendations
        """
        recommendations = []
        
        # General recommendations
        recommendations.append('Implement network segmentation to limit lateral movement')
        recommendations.append('Use multi-factor authentication for all remote access')
        recommendations.append('Implement least privilege access controls')
        recommendations.append('Monitor and log all remote access attempts')
        
        # Check if any movement methods were successful
        if self.movement_result and self.movement_result['success']:
            recommendations.append('Review successful connection methods and strengthen controls')
        
        # Add specific recommendations based on open ports/methods
        if self.connection_attempts:
            open_ports = [f"{attempt['method'].upper()} ({attempt.get('port', 'N/A')})"] \
                        for attempt in self.connection_attempts if attempt['success']
            if open_ports:
                recommendations.append(f'Restrict access to discovered open services: {', '.join(open_ports)}')
        
        return recommendations
    
    def save_report(self, report_path: Optional[str] = None) -> str:
        """Save the lateral movement report to a file.
        
        Args:
            report_path: Path to save the report. If None, a default path will be used.
            
        Returns:
            str: Path to the saved report file
        """
        if report_path is None:
            # Create a default report path
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            report_path = os.path.join(os.getcwd(), f'lateral_movement_report_{timestamp}.json')
        
        report = self.generate_report()
        
        try:
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=2)
            self.logger.info(f'Report saved to {report_path}')
            return report_path
        except Exception as e:
            self.logger.error(f'Error saving report: {str(e)}')
            raise
    
    def execute(self, save_report: bool = False, output_path: Optional[str] = None) -> Dict[str, Any]:
        """Execute the complete lateral movement workflow.
        
        Args:
            save_report: Whether to save the report to a file
            output_path: Path to save the report
            
        Returns:
            Dict[str, Any]: Final lateral movement results
        """
        try:
            # 1. Establish connection to source system
            self.source_connection = self.establish_source_connection()
            
            # If source connection failed, return early
            if not self.source_connection['connected']:
                return {
                    'success': False,
                    'message': f'Failed to establish connection to source: {self.source}',
                    'details': self.source_connection
                }
            
            # 2. Enumerate available resources and credentials
            self.enumerate_resources()
            
            # 3. Attempt connection to destination system
            self.attempt_destination_connection()
            
            # 4. Verify successful movement
            self.verification_result = self.verify_movement()
            
            # 5. Generate and optionally save report
            final_report = self.generate_report()
            if save_report:
                report_path = self.save_report(output_path)
                final_report['report_file'] = report_path
            
            # 6. Return the final results
            return {
                'success': self.verification_result['verified'],
                'message': 'Lateral movement process completed',
                'details': final_report
            }
        except Exception as e:
            self.logger.error(f'Error during lateral movement: {str(e)}')
            return {
                'success': False,
                'message': f'Error during lateral movement: {str(e)}',
                'details': {}
            }


def run(args: argparse.Namespace) -> None:
    """Perform lateral movement between systems"""
    logger.info(f"Starting lateral movement from {args.source} to {args.destination}")
    logger.debug(f"Lateral movement parameters: {vars(args)}")
    
    # Check if in development mode
    is_dev_mode = config.get_mode()
    
    if is_dev_mode:
        logger.info("Running in DEVELOPMENT mode - detailed analysis enabled")
    else:
        logger.info("Running in PRODUCTION mode - optimized for performance")
    
    # Prepare credentials if provided
    credentials = {}
    if hasattr(args, 'username') and args.username:
        credentials['username'] = args.username
    if hasattr(args, 'password') and args.password:
        credentials['password'] = args.password
    
    # Create and execute the lateral movement module
    lateral_mover = LateralMover(
        source=args.source,
        destination=args.destination,
        credentials=credentials,
        dev_mode=is_dev_mode
    )
    
    result = lateral_mover.execute(
        save_report=args.output is not None,
        output_path=args.output
    )
    
    # Log summary of results
    if result['success']:
        logger.info(f'Successful lateral movement from {args.source} to {args.destination}')
    else:
        logger.info(f'Lateral movement from {args.source} to {args.destination} failed or not attempted (dev mode)')
    
    logger.info(f"Lateral movement completed from {args.source} to {args.destination}")
    
    if args.output:
        logger.info(f"Results saved to: {args.output}")
