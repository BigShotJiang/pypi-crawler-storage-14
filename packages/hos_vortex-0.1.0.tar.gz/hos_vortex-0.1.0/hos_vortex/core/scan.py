#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Vulnerability scanning module for HOS_Vortex"""

import argparse
import socket
import json
from typing import Dict, List, Any, Optional
import ipaddress

import nmap
from scapy.all import sr1, IP, TCP, ICMP, conf

from ..utils import logger, config

# Disable scapy verbose output in production mode
conf.verb = 0

class VulnerabilityScanner:
    """Class for performing vulnerability scans"""
    
    def __init__(self, target: str, ports: Optional[str] = None, dev_mode: bool = False):
        self.target = target
        self.ports = ports
        self.dev_mode = dev_mode
        self.results = {
            "target": target,
            "scan_time": None,
            "host_info": {},
            "open_ports": [],
            "vulnerabilities": []
        }
        self.nm = nmap.PortScanner()
        
    def validate_target(self) -> bool:
        """Validate the target IP or hostname"""
        try:
            # Try to parse as IP address
            ipaddress.ip_address(self.target)
            return True
        except ValueError:
            # Try to resolve hostname
            try:
                socket.gethostbyname(self.target)
                return True
            except socket.gaierror:
                return False
    
    def ping_scan(self) -> bool:
        """Check if target is alive using ICMP ping"""
        try:
            response = sr1(IP(dst=self.target)/ICMP(), timeout=2, verbose=0)
            if response:
                logger.info(f"Target {self.target} is alive")
                return True
            else:
                logger.warning(f"Target {self.target} is not responding to ICMP")
                return False
        except Exception as e:
            logger.error(f"Error during ping scan: {str(e)}")
            return False
    
    def port_scan(self) -> List[int]:
        """Perform port scanning on target"""
        open_ports = []
        
        # Default ports if none specified
        if not self.ports:
            scan_ports = "1-1000"
        else:
            scan_ports = self.ports
        
        logger.info(f"Starting port scan on {self.target} (ports: {scan_ports})")
        
        try:
            # Using nmap for port scanning
            self.nm.scan(self.target, scan_ports, arguments="-sS -T4")
            
            if self.target in self.nm.all_hosts():
                for proto in self.nm[self.target].all_protocols():
                    ports = self.nm[self.target][proto].keys()
                    for port in ports:
                        if self.nm[self.target][proto][port]['state'] == 'open':
                            open_ports.append(port)
                            service = self.nm[self.target][proto][port]['name']
                            version = self.nm[self.target][proto][port].get('version', 'unknown')
                            logger.info(f"Port {port}: {service} ({version}) - OPEN")
                            
                            # Add to results
                            self.results["open_ports"].append({
                                "port": port,
                                "protocol": proto,
                                "service": service,
                                "version": version
                            })
            
            logger.info(f"Port scan completed. Found {len(open_ports)} open ports.")
            return open_ports
        except Exception as e:
            logger.error(f"Error during port scan: {str(e)}")
            return open_ports
    
    def detect_vulnerabilities(self) -> List[Dict[str, Any]]:
        """Simple vulnerability detection based on service versions"""
        vulnerabilities = []
        
        # Basic vulnerability signatures (simplified example)
        vuln_signatures = {
            "ssh": {
                "version_patterns": [
                    ("OpenSSH 7.2p2", "CVE-2016-6210"),
                    ("OpenSSH 6.6.1p1", "CVE-2014-2532"),
                ]
            },
            "http": {
                "version_patterns": [
                    ("Apache/2.4.18", "CVE-2017-3167"),
                    ("nginx/1.10.0", "CVE-2016-1247"),
                ]
            }
        }
        
        for port_info in self.results["open_ports"]:
            service = port_info["service"]
            version = port_info["version"]
            
            if service in vuln_signatures:
                for pattern, cve in vuln_signatures[service]["version_patterns"]:
                    if pattern in version:
                        vuln_info = {
                            "port": port_info["port"],
                            "service": service,
                            "version": version,
                            "vulnerability": cve,
                            "severity": "High",
                            "description": f"Potential vulnerability {cve} found in {service} {version}"
                        }
                        vulnerabilities.append(vuln_info)
                        logger.warning(f"Vulnerability found: {cve} on port {port_info['port']}")
        
        self.results["vulnerabilities"] = vulnerabilities
        logger.info(f"Vulnerability detection completed. Found {len(vulnerabilities)} potential issues.")
        return vulnerabilities
    
    def run_full_scan(self) -> Dict[str, Any]:
        """Run the complete scanning process"""
        import datetime
        
        # Set scan time
        self.results["scan_time"] = datetime.datetime.now().isoformat()
        
        # Validate target
        if not self.validate_target():
            logger.error(f"Invalid target: {self.target}")
            return self.results
        
        # Check if target is alive
        is_alive = self.ping_scan()
        self.results["host_info"]["alive"] = is_alive
        
        if is_alive:
            # Perform port scan
            self.port_scan()
            
            # Detect vulnerabilities
            self.detect_vulnerabilities()
        
        return self.results
    
    def save_results(self, output_file: Optional[str]) -> None:
        """Save scan results to a file"""
        if output_file:
            try:
                with open(output_file, 'w') as f:
                    json.dump(self.results, f, indent=2)
                logger.info(f"Results saved to: {output_file}")
            except Exception as e:
                logger.error(f"Failed to save results to {output_file}: {str(e)}")


def run(args: argparse.Namespace) -> None:
    """Run vulnerability scan on target"""
    logger.info(f"Starting vulnerability scan on target: {args.target}")
    logger.debug(f"Scan parameters: {vars(args)}")
    
    # Check if in development mode
    is_dev_mode = config.get_mode()
    
    if is_dev_mode:
        logger.info("Running in DEVELOPMENT mode - detailed analysis enabled")
        # Enable more verbose output in dev mode
        conf.verb = 1
    else:
        logger.info("Running in PRODUCTION mode - optimized for performance")
    
    # Initialize scanner
    scanner = VulnerabilityScanner(args.target, args.ports, is_dev_mode)
    
    # Run full scan
    results = scanner.run_full_scan()
    
    # Display summary
    logger.info(f"\nScan Summary for {args.target}:")
    logger.info(f"  Host Status: {'Alive' if results['host_info'].get('alive', False) else 'Down'}")
    logger.info(f"  Open Ports: {len(results['open_ports'])}")
    logger.info(f"  Vulnerabilities: {len(results['vulnerabilities'])}")
    
    # Save results if output file specified
    if args.output:
        scanner.save_results(args.output)
    
    logger.info("Scan completed successfully.")
    
    # In development mode, print detailed results to console
    if is_dev_mode:
        logger.info("\nDetailed Results:")
        logger.info(json.dumps(results, indent=2))
