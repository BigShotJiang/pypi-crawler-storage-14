#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Configuration management module for hos_vortex"""

import os
import json
import platform
from typing import Dict, Any, Optional, Union

# Default configuration
DEFAULT_CONFIG = {
    "mode": "production",  # production or development
    "timeout": 30,          # Default timeout in seconds
    "concurrency": 10,      # Default concurrent tasks
    "proxy": None,          # Proxy settings
    "user_agent": "hos_vortex/0.1.0",  # Default user agent
    "log_level": "info",    # Default log level
    "scan": {
        "ports": "common",  # common, all, or comma-separated list
        "timeout": 1,       # Port scan timeout per host
        "threads": 100       # Number of scanning threads
    },
    "escalate": {
        "check_suid": True,  # Check for SUID binaries
        "check_sgid": True,  # Check for SGID binaries
        "check_services": True,  # Check for unquoted service paths
        "check_permissions": True  # Check for weak permissions
    },
    "lateral_move": {
        "protocols": ["smb", "ssh", "rdp", "winrm"],
        "max_retries": 3,
        "retry_delay": 2
    },
    "exfiltrate": {
        "compress": True,
        "encrypt": True,
        "chunk_size": 1024 * 1024,  # 1MB chunks
        "transfer_timeout": 300
    },
    "c2": {
        "protocol": "http",  # http, socket, socketio
        "reconnect_interval": 30,
        "heartbeat": 60,
        "encryption_key": None  # Will be generated if not set
    },
    "ai": {
        "enabled": True,
        "analysis_depth": "medium",  # light, medium, deep
        "prediction_enabled": True
    },
    "paths": {
        "temp_dir": os.path.join(os.path.expanduser("~"), ".hos_vortex", "temp"),
        "data_dir": os.path.join(os.path.expanduser("~"), ".hos_vortex", "data"),
        "log_dir": os.path.join(os.path.expanduser("~"), ".hos_vortex", "logs")
    },
    "system": {
        "os": platform.system(),
        "os_version": platform.version(),
        "python_version": platform.python_version()
    }
}

# Global config instance
_config = DEFAULT_CONFIG.copy()


def load_config() -> None:
    """Load configuration from file"""
    global _config
    
    config_dir = os.path.join(os.path.expanduser("~"), ".hos_vortex")
    config_file = os.path.join(config_dir, "config.json")
    
    # Create necessary directories
    os.makedirs(config_dir, exist_ok=True)
    for path_key, path in _config["paths"].items():
        os.makedirs(path, exist_ok=True)
    
    if os.path.exists(config_file):
        try:
            with open(config_file, "r") as f:
                file_config = json.load(f)
            _config = deep_update(_config, file_config)
            from .logger import info
            info(f"Configuration loaded from: {config_file}")
        except json.JSONDecodeError as e:
            from .logger import error
            error(f"Failed to parse configuration file: {e}")
            error("Using default configuration instead")
        except Exception as e:
            from .logger import error
            error(f"Failed to load configuration: {e}")
    else:
        # Create default config file
        save_config()
        from .logger import info
        info(f"Created default configuration at: {config_file}")


def deep_update(source: Dict[str, Any], update: Dict[str, Any]) -> Dict[str, Any]:
    """Deep update a dictionary with another dictionary"""
    result = source.copy()
    for key, value in update.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_update(result[key], value)
        else:
            result[key] = value
    return result


def save_config() -> None:
    """Save configuration to file"""
    global _config
    
    config_dir = os.path.join(os.path.expanduser("~"), ".hos_vortex")
    config_file = os.path.join(config_dir, "config.json")
    
    try:
        os.makedirs(config_dir, exist_ok=True)
        with open(config_file, "w") as f:
            json.dump(_config, f, indent=2, ensure_ascii=False)
        from .logger import info
        info(f"Configuration saved to: {config_file}")
    except Exception as e:
        from .logger import error
        error(f"Failed to save configuration: {e}")


def get_config() -> Dict[str, Any]:
    """Get current configuration"""
    global _config
    return _config.copy()


def get_setting(key: str, default: Any = None) -> Any:
    """Get specific configuration setting"""
    global _config
    return _config.get(key, default)


def set_setting(key: str, value: Any) -> None:
    """Set specific configuration setting"""
    global _config
    _config[key] = value
    save_config()


def set_mode(dev_mode: bool) -> None:
    """Set development or production mode"""
    global _config
    _config["mode"] = "development" if dev_mode else "production"
    # Adjust other settings based on mode
    if dev_mode:
        _config["log_level"] = "debug"
        _config["scan"]["timeout"] = 2
        _config["ai"]["analysis_depth"] = "deep"
    else:
        _config["log_level"] = "info"
        _config["scan"]["timeout"] = 1
        _config["ai"]["analysis_depth"] = "medium"
    
    from .logger import info
    info(f"Mode set to: {_config['mode']}")


def get_nested_setting(path: str, default: Any = None) -> Any:
    """Get a nested configuration setting using dot notation
    
    Example:
        get_nested_setting("scan.ports")
    """
    keys = path.split(".")
    value = _config
    
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            return default
    
    return value


def set_nested_setting(path: str, value: Any) -> None:
    """Set a nested configuration setting using dot notation
    
    Example:
        set_nested_setting("scan.ports", "all")
    """
    keys = path.split(".")
    config = _config
    
    # Traverse to the parent of the target key
    for key in keys[:-1]:
        if key not in config or not isinstance(config[key], dict):
            config[key] = {}
        config = config[key]
    
    # Set the value
    config[keys[-1]] = value
    save_config()


def validate_config() -> Dict[str, str]:
    """Validate configuration and return any warnings or errors"""
    issues = {}
    
    # Validate mode
    if _config["mode"] not in ["production", "development"]:
        issues["mode"] = f"Invalid mode: {_config['mode']}, using 'production'"
        _config["mode"] = "production"
    
    # Validate log level
    valid_log_levels = ["debug", "info", "warning", "error", "critical"]
    if _config["log_level"] not in valid_log_levels:
        issues["log_level"] = f"Invalid log level: {_config['log_level']}, using 'info'"
        _config["log_level"] = "info"
    
    # Validate scan ports
    scan_ports = _config["scan"]["ports"]
    if scan_ports not in ["common", "all"] and not scan_ports.isdigit() and "," not in scan_ports:
        issues["scan.ports"] = f"Invalid scan ports: {scan_ports}, using 'common'"
        _config["scan"]["ports"] = "common"
    
    return issues


def export_config(output_file: str) -> bool:
    """Export configuration to a specified file"""
    try:
        with open(output_file, "w") as f:
            json.dump(_config, f, indent=2, ensure_ascii=False)
        from .logger import info
        info(f"Configuration exported to: {output_file}")
        return True
    except Exception as e:
        from .logger import error
        error(f"Failed to export configuration: {e}")
        return False


def import_config(input_file: str) -> bool:
    """Import configuration from a specified file"""
    global _config
    
    try:
        with open(input_file, "r") as f:
            imported_config = json.load(f)
        
        # Validate imported configuration
        _config = deep_update(_config, imported_config)
        issues = validate_config()
        
        if issues:
            from .logger import warning
            for key, issue in issues.items():
                warning(f"Config issue ({key}): {issue}")
        
        save_config()
        from .logger import info
        info(f"Configuration imported from: {input_file}")
        return True
    except json.JSONDecodeError as e:
        from .logger import error
        error(f"Failed to parse imported configuration: {e}")
        return False
    except Exception as e:
        from .logger import error
        error(f"Failed to import configuration: {e}")
        return False


def get_mode() -> bool:
    """Get current mode (True for development, False for production)"""
    global _config
    return _config["mode"] == "development"


def get_timeout() -> int:
    """Get timeout setting"""
    return get_setting("timeout", DEFAULT_CONFIG["timeout"])


def get_concurrency() -> int:
    """Get concurrency setting"""
    return get_setting("concurrency", DEFAULT_CONFIG["concurrency"])

# Initialize configuration on module import
load_config()
