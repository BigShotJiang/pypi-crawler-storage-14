#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Authorization module for hos_vortex"""

import os
import time
import json
import hashlib
import hmac
import base64
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List, Tuple

# Import logger (lazy import to avoid circular dependencies)
def _get_logger():
    from .logger import info, warning, error
    return {"info": info, "warning": warning, "error": error}

# Authorization state
_auth_state = {
    "authorized": False,
    "user": None,
    "role": None,
    "expires_at": 0,
    "permissions": [],
    "api_key": None,
    "session_id": None,
    "last_activity": 0
}

# Predefined roles and permissions
ROLES = {
    "admin": ["full_access", "manage_users", "configure_system", "execute_all"],
    "operator": ["execute_scans", "perform_escalation", "lateral_move", "data_exfil", "view_results"],
    "analyst": ["view_results", "generate_reports", "export_data"],
    "guest": ["view_public_data"]
}

# Action to permission mapping
ACTION_PERMISSIONS = {
    "scan": ["execute_scans"],
    "escalate": ["perform_escalation"],
    "move": ["lateral_move"],
    "exfil": ["data_exfil"],
    "view": ["view_results", "view_public_data"],
    "report": ["generate_reports"],
    "export": ["export_data"],
    "config": ["configure_system"],
    "users": ["manage_users"]
}

# Usage warning and terms
_ETHICS_WARNING = """
=====================================================
!!! IMPORTANT ETHICAL USAGE WARNING !!!
=====================================================
hos_vortex is designed exclusively for authorized security testing,
penetration testing, and educational purposes with explicit
permission from system owners.

UNAUTHORIZED USAGE:
- Against systems without explicit written permission
- For malicious purposes
- In violation of applicable laws and regulations

Such actions may constitute criminal offenses punishable by law.
By continuing, you confirm:
1. You have explicit permission to test the target systems
2. You understand the potential impact of your actions
3. You will act responsibly and ethically
4. You will comply with all relevant laws and regulations
=====================================================
"""

# API key storage
_API_KEYS_FILE = os.path.join(os.path.expanduser("~"), ".hos_vortex", "api_keys.json")

# Generate API key
def _generate_api_key(user: str, role: str) -> str:
    """Generate a secure API key for authentication"""
    timestamp = str(int(time.time()))
    secret = os.urandom(32)  # Generate a 256-bit random secret
    
    # Create a signature using HMAC-SHA256
    message = f"{user}:{role}:{timestamp}".encode()
    signature = hmac.new(secret, message, hashlib.sha256).hexdigest()
    
    # Combine parts into the API key
    api_key = f"vtx_{user}_{role}_{timestamp}_{signature[:16]}"
    
    # Store the key securely
    _store_api_key(user, role, api_key)
    
    return api_key

# Store API key
def _store_api_key(user: str, role: str, api_key: str) -> bool:
    """Store API key securely"""
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(_API_KEYS_FILE), exist_ok=True)
        
        # Load existing keys or create new
        if os.path.exists(_API_KEYS_FILE):
            with open(_API_KEYS_FILE, 'r') as f:
                keys = json.load(f)
        else:
            keys = {}
        
        # Hash the API key for storage
        hashed_key = hashlib.sha256(api_key.encode()).hexdigest()
        keys[hashed_key] = {
            "user": user,
            "role": role,
            "created_at": datetime.now().isoformat(),
            "last_used": None
        }
        
        # Write back to file
        with open(_API_KEYS_FILE, 'w') as f:
            json.dump(keys, f, indent=2)
        
        # Set restrictive permissions on the file
        if hasattr(os, 'chmod'):
            try:
                os.chmod(_API_KEYS_FILE, 0o600)  # Read/write for owner only
            except Exception:
                pass  # Ignore permission errors
        
        return True
    except Exception as e:
        log = _get_logger()
        log["error"](f"Failed to store API key: {e}")
        return False

# Verify API key
def _verify_api_key(api_key: str) -> Tuple[bool, Optional[Dict[str, Any]]]:
    """Verify if the provided API key is valid"""
    try:
        if not os.path.exists(_API_KEYS_FILE):
            return False, None
        
        # Hash the provided key for comparison
        hashed_key = hashlib.sha256(api_key.encode()).hexdigest()
        
        # Load and check keys
        with open(_API_KEYS_FILE, 'r') as f:
            keys = json.load(f)
        
        if hashed_key in keys:
            # Update last used timestamp
            keys[hashed_key]["last_used"] = datetime.now().isoformat()
            with open(_API_KEYS_FILE, 'w') as f:
                json.dump(keys, f, indent=2)
            
            return True, keys[hashed_key]
        
        return False, None
    except Exception as e:
        log = _get_logger()
        log["error"](f"Failed to verify API key: {e}")
        return False, None

# Display usage warning and terms
def show_usage_warning() -> bool:
    """Display usage warning and terms of service, return user acceptance"""
    print(_ETHICS_WARNING)
    
    # In development mode, automatically accept
    try:
        from .config import get_mode
        if get_mode():
            log = _get_logger()
            log["info"]('Development mode: Ethics warning bypassed')
            return True
    except ImportError:
        pass
    
    # Get user confirmation
    while True:
        response = input("Do you accept these terms and confirm authorized usage? (yes/no): ").strip().lower()
        if response == "yes":
            return True
        elif response == "no":
            print("Exiting due to declined terms.")
            return False
        else:
            print("Please enter 'yes' or 'no'")

# Generate session ID
def _generate_session_id() -> str:
    """Generate a unique session ID"""
    return base64.urlsafe_b64encode(os.urandom(32)).decode('utf-8')

# Basic authorization check
def check_authorization() -> bool:
    """Check if user is authorized to use the tool"""
    global _auth_state
    
    # Check if authorization is still valid
    if _auth_state["authorized"] and time.time() < _auth_state["expires_at"]:
        # Update last activity
        _auth_state["last_activity"] = time.time()
        return True
    
    # Check if we're in development mode
    try:
        from .config import get_mode
        if get_mode():
            log = _get_logger()
            log["info"]("Development mode: Automatic authorization")
            _auth_state["authorized"] = True
            _auth_state["user"] = "developer"
            _auth_state["role"] = "admin"
            _auth_state["expires_at"] = time.time() + 86400  # 24 hours
            _auth_state["permissions"] = ROLES["admin"]
            _auth_state["session_id"] = _generate_session_id()
            _auth_state["last_activity"] = time.time()
            return True
    except ImportError:
        pass
    
    return False

# Authenticate user with API key
def authenticate_with_api_key(api_key: str) -> bool:
    """Authenticate user with provided API key"""
    global _auth_state
    
    # First verify ethical usage
    if not show_usage_warning():
        return False
    
    # Verify API key
    is_valid, key_info = _verify_api_key(api_key)
    if not is_valid or not key_info:
        log = _get_logger()
        log["warning"]("Authentication failed: Invalid API key")
        return False
    
    # Update auth state
    _auth_state["authorized"] = True
    _auth_state["user"] = key_info["user"]
    _auth_state["role"] = key_info["role"]
    _auth_state["expires_at"] = time.time() + 3600  # 1 hour expiration
    _auth_state["permissions"] = ROLES.get(key_info["role"], [])
    _auth_state["api_key"] = api_key
    _auth_state["session_id"] = _generate_session_id()
    _auth_state["last_activity"] = time.time()
    
    log = _get_logger()
    log["info"](f"Authentication successful for user: {key_info['user']} (Role: {key_info['role']})")
    
    return True

# Authenticate with username/password (placeholder)
def authenticate(user: str, credentials: Any) -> bool:
    """Authenticate user with provided credentials"""
    # First verify ethical usage
    if not show_usage_warning():
        return False
    
    # In a real implementation, this would verify against a secure user database
    # For now, we'll generate an API key for the user
    log = _get_logger()
    log["warning"]("Username/password authentication is a placeholder. Generating API key.")
    
    # Default role if not specified
    role = "operator"  # Default to operator role
    if isinstance(credentials, dict) and "role" in credentials:
        role = credentials["role"]
    
    if role not in ROLES:
        log["error"](f"Invalid role: {role}")
        return False
    
    # Generate API key
    api_key = _generate_api_key(user, role)
    
    # Update auth state
    _auth_state["authorized"] = True
    _auth_state["user"] = user
    _auth_state["role"] = role
    _auth_state["expires_at"] = time.time() + 3600  # 1 hour expiration
    _auth_state["permissions"] = ROLES[role]
    _auth_state["api_key"] = api_key
    _auth_state["session_id"] = _generate_session_id()
    _auth_state["last_activity"] = time.time()
    
    log["info"](f"Authenticated as user: {user} (Role: {role})")
    log["info"](f"API Key: {api_key} (Keep this secure!)")
    
    return True

# Check if user is authorized for specific action
def authorize(action: str) -> bool:
    """Check if user is authorized to perform specific action"""
    # First check if authenticated
    if not check_authorization():
        log = _get_logger()
        log["warning"](f"Authorization check failed: Not authenticated")
        return False
    
    # Check if action is mapped to permissions
    if action not in ACTION_PERMISSIONS:
        # For actions without specific permissions, require full_access
        required_permissions = ["full_access"]
    else:
        required_permissions = ACTION_PERMISSIONS[action]
    
    # Check if user has any of the required permissions
    user_permissions = _auth_state["permissions"]
    has_permission = any(perm in user_permissions for perm in required_permissions)
    
    # Log the authorization check
    log = _get_logger()
    if has_permission:
        log["info"](f"Authorization granted: User '{_auth_state['user']}' can perform '{action}'")
    else:
        log["warning"](f"Authorization denied: User '{_auth_state['user']}' cannot perform '{action}'")
    
    return has_permission

# Get current auth state
def get_auth_state() -> Dict[str, Any]:
    """Get current authorization state"""
    # Return a copy without sensitive information
    state_copy = _auth_state.copy()
    if "api_key" in state_copy:
        # Mask API key for security
        if state_copy["api_key"]:
            api_key = state_copy["api_key"]
            if len(api_key) > 8:
                state_copy["api_key"] = api_key[:4] + "..." + api_key[-4:]
    return state_copy

# Reset authorization
def reset_authorization() -> None:
    """Reset authorization state"""
    global _auth_state
    log = _get_logger()
    log["info"]("Authorization reset")
    
    _auth_state = {
        "authorized": False,
        "user": None,
        "role": None,
        "expires_at": 0,
        "permissions": [],
        "api_key": None,
        "session_id": None,
        "last_activity": 0
    }

# Refresh authorization token
def refresh_authorization() -> bool:
    """Refresh the current authorization token"""
    if not _auth_state["authorized"]:
        return False
    
    # Extend expiration time
    _auth_state["expires_at"] = time.time() + 3600  # Extend by 1 hour
    _auth_state["last_activity"] = time.time()
    
    log = _get_logger()
    log["info"](f"Authorization refreshed for user: {_auth_state['user']}")
    
    return True

# Create new API key for a user
def create_api_key(user: str, role: str) -> Optional[str]:
    """Create a new API key for a user with specified role"""
    # Check if caller is authorized to manage users
    if not authorize("users"):
        return None
    
    # Validate role
    if role not in ROLES:
        log = _get_logger()
        log["error"](f"Cannot create API key: Invalid role '{role}'")
        return None
    
    # Generate and return API key
    api_key = _generate_api_key(user, role)
    log = _get_logger()
    log["info"](f"Created new API key for user '{user}' with role '{role}'")
    
    return api_key

# List all API keys (admin only)
def list_api_keys() -> List[Dict[str, Any]]:
    """List all API keys (admin only)"""
    # Check if caller is authorized to manage users
    if not authorize("users"):
        return []
    
    try:
        if not os.path.exists(_API_KEYS_FILE):
            return []
        
        with open(_API_KEYS_FILE, 'r') as f:
            keys = json.load(f)
        
        # Return sanitized key information (no actual keys)
        result = []
        for hashed_key, key_info in keys.items():
            result.append({
                "user": key_info["user"],
                "role": key_info["role"],
                "created_at": key_info["created_at"],
                "last_used": key_info["last_used"],
                "key_id": hashed_key[:8]  # Just show first 8 chars as identifier
            })
        
        return result
    except Exception as e:
        log = _get_logger()
        log["error"](f"Failed to list API keys: {e}")
        return []

# Verify ethical usage
def verify_ethical_usage(target: str, scope: Optional[List[str]] = None) -> bool:
    """Verify that the tool is being used ethically for the given target"""
    log = _get_logger()
    
    # Check authorization first
    if not check_authorization():
        log["warning"]("Ethical usage verification failed: Not authenticated")
        return False
    
    # Log the target and scope
    scope_str = ", ".join(scope) if scope else "Not specified"
    log["info"](f"Ethical usage verification: Target='{target}', Scope='{scope_str}'")
    
    # In a real implementation, this could:
    # 1. Check against a list of authorized targets
    # 2. Verify scope limitations
    # 3. Log detailed audit information
    # 4. Check time restrictions
    
    # For now, we'll just return True for authorized users
    return True

# Log authorization event
def _log_auth_event(event_type: str, success: bool, details: Optional[Dict[str, Any]] = None) -> None:
    """Log authorization-related events"""
    try:
        from .logger import log_security_event
        severity = "info" if success else "warning"
        description = f"Authorization {event_type} {'succeeded' if success else 'failed'}"
        
        context = {"user": _auth_state.get("user", "unknown")}
        if details:
            context.update(details)
        
        log_security_event("auth", severity, "system", description, context)
    except ImportError:
        pass  # Logger not available, continue anyway