#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Logging module for hos_vortex"""

import logging
import os
import sys
import datetime
from logging.handlers import TimedRotatingFileHandler
from typing import Optional, Dict, Any

# Import config module (avoid circular import by importing when needed)
_config = None
get_nested_setting = None
set_nested_setting = None

# Global logger instance
logger = None
file_handler = None
error_handler = None


# Console formatter with colors
class ColoredFormatter(logging.Formatter):
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[1;31m'  # Bold Red
    }
    RESET = '\033[0m'
    
    def format(self, record):
        color = self.COLORS.get(record.levelname, self.RESET)
        message = super().format(record)
        return f"{color}{message}{self.RESET}"


def setup_logger(dev_mode: bool = False) -> None:
    """Setup logging configuration"""
    global logger, file_handler, error_handler, _config, get_nested_setting, set_nested_setting
    
    # Lazy import to avoid circular import
    try:
        from .config import _config as imported_config
        from .config import get_nested_setting as imported_get_setting
        from .config import set_nested_setting as imported_set_setting
        _config = imported_config
        get_nested_setting = imported_get_setting
        set_nested_setting = imported_set_setting
    except ImportError:
        # Fallback if config module not available
        _config = {}
        get_nested_setting = lambda x, default=None: default
        set_nested_setting = lambda x, y: None
    
    # Create logger
    logger = logging.getLogger("hos_vortex")
    logger.setLevel(logging.DEBUG)  # Set to lowest level, handlers will filter
    logger.propagate = False  # Prevent duplicate logging
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create formatter with more details
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(process)d - %(threadName)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    
    # Get log level from config or use dev_mode
    log_level = get_nested_setting("log_level")
    if log_level is None:
        log_level = "debug" if dev_mode else "info"
    
    level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL
    }
    
    log_level_value = level_map.get(log_level.lower(), logging.INFO)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level_value)
    
    # Use colored formatter on non-Windows platforms
    is_windows = sys.platform.startswith('win')
    if not is_windows:
        console_formatter = ColoredFormatter(
            "%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
    else:
        console_formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
    
    console_handler.setFormatter(console_formatter)
    logger.addHandler(console_handler)
    
    # Get log directory from config
    log_dir = get_nested_setting("paths.log_dir")
    if not log_dir:
        log_dir = os.path.join(os.path.expanduser("~"), ".hos_vortex", "logs")
    
    os.makedirs(log_dir, exist_ok=True)
    
    # File handler with daily rotation
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d")
    log_file = os.path.join(log_dir, f"hos_vortex_{timestamp}.log")
    
    file_handler = TimedRotatingFileHandler(
        log_file,
        when="midnight",
        interval=1,
        backupCount=30,  # Keep 30 days of logs
        encoding="utf-8"
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.DEBUG)  # File always logs at debug level
    logger.addHandler(file_handler)
    
    # Error handler for separate error logging
    error_log_file = os.path.join(log_dir, f"hos_vortex_errors_{timestamp}.log")
    error_handler = TimedRotatingFileHandler(
        error_log_file,
        when="midnight",
        interval=1,
        backupCount=30,
        encoding="utf-8"
    )
    error_handler.setFormatter(formatter)
    error_handler.setLevel(logging.ERROR)
    logger.addHandler(error_handler)
    
    logger.info(f"Logging initialized. Mode: {'development' if dev_mode else 'production'}")
    logger.info(f"Log file: {log_file}")
    logger.info(f"Error log file: {error_log_file}")


def log_command(command: str, context: Optional[Dict[str, Any]] = None) -> None:
    """Log executed command with optional context"""
    log_obj = get_logger()
    if context:
        context_str = " | ".join([f"{k}={v}" for k, v in context.items()])
        log_obj.info(f"Command executed: {command} [{context_str}]")
    else:
        log_obj.info(f"Command executed: {command}")


def get_logger() -> logging.Logger:
    """Get the logger instance"""
    global logger
    if not logger:
        # Try to get mode from config
        try:
            from .config import get_mode
            is_dev = get_mode()
        except ImportError:
            is_dev = False
        setup_logger(is_dev)
    return logger


def log_with_context(level: int, message: str, context: Optional[Dict[str, Any]] = None) -> None:
    """Log a message with additional context information"""
    log_obj = get_logger()
    if context:
        context_str = " | ".join([f"{k}={v}" for k, v in context.items()])
        full_message = f"{message} [{context_str}]"
    else:
        full_message = message
    
    log_obj.log(level, full_message)


def log_module_activity(module: str, action: str, success: bool, details: Optional[Dict[str, Any]] = None) -> None:
    """Log module activity with standardized format"""
    status = "SUCCESS" if success else "FAILURE"
    context = {
        "module": module,
        "status": status
    }
    
    if details:
        context.update(details)
    
    level = logging.INFO if success else logging.ERROR
    log_with_context(level, f"{module} - {action}", context)


def log_network_activity(activity_type: str, source: str, destination: str, port: Optional[int] = None, 
                         protocol: Optional[str] = None, status: str = "unknown") -> None:
    """Log network-related activities"""
    context = {
        "type": activity_type,
        "source": source,
        "destination": destination,
        "status": status
    }
    
    if port:
        context["port"] = port
    if protocol:
        context["protocol"] = protocol
    
    log_with_context(logging.INFO, f"Network {activity_type}", context)


def log_security_event(event_type: str, severity: str, target: str, 
                       description: str, details: Optional[Dict[str, Any]] = None) -> None:
    """Log security-related events"""
    context = {
        "event_type": event_type,
        "severity": severity,
        "target": target
    }
    
    if details:
        context.update(details)
    
    # Map severity to log level
    severity_map = {
        "low": logging.INFO,
        "medium": logging.WARNING,
        "high": logging.ERROR,
        "critical": logging.CRITICAL
    }
    
    level = severity_map.get(severity.lower(), logging.INFO)
    log_with_context(level, description, context)


def set_log_level(level: str) -> None:
    """Set log level for console handler"""
    global logger
    if not logger:
        get_logger()
    
    level_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warning": logging.WARNING,
        "error": logging.ERROR,
        "critical": logging.CRITICAL
    }
    
    log_level = level_map.get(level.lower(), logging.INFO)
    
    # Update console handler level
    for handler in logger.handlers:
        if isinstance(handler, logging.StreamHandler):
            handler.setLevel(log_level)
    
    # Update the config if available
    if set_nested_setting:
        set_nested_setting("log_level", level)
    
    logger.debug(f"Log level set to: {level}")

# Enhanced logger methods with context support
def debug(msg: str, context: Optional[Dict[str, Any]] = None) -> None:
    """Log debug message with optional context"""
    if context:
        log_with_context(logging.DEBUG, msg, context)
    else:
        get_logger().debug(msg)

def info(msg: str, context: Optional[Dict[str, Any]] = None) -> None:
    """Log info message with optional context"""
    if context:
        log_with_context(logging.INFO, msg, context)
    else:
        get_logger().info(msg)

def warning(msg: str, context: Optional[Dict[str, Any]] = None) -> None:
    """Log warning message with optional context"""
    if context:
        log_with_context(logging.WARNING, msg, context)
    else:
        get_logger().warning(msg)

def error(msg: str, context: Optional[Dict[str, Any]] = None, exception: Optional[Exception] = None) -> None:
    """Log error message with optional context and exception"""
    if context:
        log_with_context(logging.ERROR, msg, context)
    else:
        get_logger().error(msg)
    
    if exception:
        get_logger().error("Exception details:", exc_info=exception)

def critical(msg: str, context: Optional[Dict[str, Any]] = None, exception: Optional[Exception] = None) -> None:
    """Log critical message with optional context and exception"""
    if context:
        log_with_context(logging.CRITICAL, msg, context)
    else:
        get_logger().critical(msg)
    
    if exception:
        get_logger().critical("Exception details:", exc_info=exception)

def exception(msg: str, exception: Exception, context: Optional[Dict[str, Any]] = None) -> None:
    """Log exception with message and optional context"""
    error(msg, context, exception)

# Initialize logging when module is imported
try:
    # Try to get mode from config if available
    try:
        from .config import get_mode
        is_dev = get_mode()
    except ImportError:
        is_dev = False
    setup_logger(is_dev)
except Exception as e:
    # Last resort logging if initialization fails
    print(f"Failed to initialize logging: {e}", file=sys.stderr)
