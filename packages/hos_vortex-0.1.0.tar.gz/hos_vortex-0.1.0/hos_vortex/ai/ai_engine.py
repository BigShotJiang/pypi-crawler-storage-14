#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""AI Engine for attack pattern recognition and behavior prediction"""

import argparse
import os
import json
import time
import numpy as np
from typing import Dict, List, Any, Tuple
import re

from ..utils import logger, config

# 攻击模式库 - 预定义常见攻击模式特征
ATTACK_PATTERNS = {
    "port_scan": {
        "name": "端口扫描",
        "description": "快速扫描多个端口，寻找开放服务",
        "features": [
            {"type": "network", "pattern": "multiple_port_connections", "threshold": 10},
            {"type": "timing", "pattern": "regular_interval", "threshold": 0.5}
        ],
        "severity": "medium"
    },
    "brute_force": {
        "name": "暴力破解",
        "description": "对认证机制进行密码暴力尝试",
        "features": [
            {"type": "auth", "pattern": "failed_attempts", "threshold": 5},
            {"type": "timing", "pattern": "rapid_attempts", "threshold": 2.0}
        ],
        "severity": "high"
    },
    "lateral_movement": {
        "name": "横向移动",
        "description": "从一个主机移动到网络中的其他主机",
        "features": [
            {"type": "network", "pattern": "internal_connections", "threshold": 3},
            {"type": "process", "pattern": "remote_execution", "threshold": 1}
        ],
        "severity": "critical"
    },
    "privilege_escalation": {
        "name": "权限提升",
        "description": "尝试获取更高的系统权限",
        "features": [
            {"type": "system", "pattern": "privilege_checks", "threshold": 2},
            {"type": "process", "pattern": "sensitive_operations", "threshold": 1}
        ],
        "severity": "critical"
    },
    "data_exfiltration": {
        "name": "数据泄露",
        "description": "将数据从目标系统传输到外部",
        "features": [
            {"type": "network", "pattern": "large_outbound_traffic", "threshold": 1000000},
            {"type": "file", "pattern": "sensitive_file_access", "threshold": 3}
        ],
        "severity": "critical"
    }
}

# 系统行为模型 - 用于预测分析
SYSTEM_BEHAVIOR_MODELS = {
    "normal_operation": {
        "name": "正常操作",
        "description": "系统正常运行状态",
        "threshold": 0.8,
        "features": ["regular_processes", "standard_network_traffic", "normal_auth_patterns"]
    },
    "compromised": {
        "name": "已被入侵",
        "description": "系统显示被入侵的特征",
        "threshold": 0.6,
        "features": ["unusual_processes", "suspicious_connections", "failed_auth_attempts"]
    },
    "vulnerable": {
        "name": "存在漏洞",
        "description": "系统存在可被利用的漏洞",
        "threshold": 0.5,
        "features": ["outdated_software", "misconfigurations", "weak_permissions"]
    }
}

def run(args: argparse.Namespace) -> None:
    """Run AI engine for attack analysis"""
    logger.info(f"Starting AI engine with action: {args.action}")
    logger.debug(f"AI parameters: {vars(args)}")
    
    # Check if in development mode
    is_dev_mode = config.get_mode()
    
    if is_dev_mode:
        logger.info("Running in DEVELOPMENT mode - detailed AI analysis enabled")
    else:
        logger.info("Running in PRODUCTION mode - optimized AI performance")
    
    # 初始化AI引擎
    ai_engine = AIEngine(is_dev_mode=is_dev_mode)
    
    # 执行相应操作
    results = {}
    if args.action == "analyze":
        results = ai_engine.analyze_attack_patterns(args)
    elif args.action == "predict":
        results = ai_engine.predict_behavior(args)
    elif args.action == "recommend":
        # 解析漏洞数据
        vulnerabilities = []
        if hasattr(args, 'vulnerabilities_file') and args.vulnerabilities_file:
            try:
                with open(args.vulnerabilities_file, 'r') as f:
                    vulnerabilities = json.load(f)
            except Exception as e:
                logger.error(f"Failed to load vulnerabilities file: {e}")
        results = ai_engine.generate_attack_recommendations(args.target or "unknown", vulnerabilities)
    else:
        logger.error(f"Unknown AI action: {args.action}")
        return
    
    logger.info(f"AI engine completed action: {args.action}")
    
    # 保存结果
    if args.output:
        try:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            logger.info(f"AI results saved to: {args.output}")
        except Exception as e:
            logger.error(f"Failed to save results to {args.output}: {e}")
    
    return results


class AIEngine:
    """AI Engine for attack analysis and prediction"""
    
    def __init__(self, is_dev_mode: bool = False):
        """Initialize AI Engine"""
        self.is_dev_mode = is_dev_mode
        self.patterns = ATTACK_PATTERNS
        self.behavior_models = SYSTEM_BEHAVIOR_MODELS
        self._load_models()
        logger.info(f"AI Engine initialized in {'development' if is_dev_mode else 'production'} mode")
    
    def _load_models(self):
        """Load AI models and pattern databases"""
        # 在实际实现中，这里可以加载预训练的机器学习模型
        # 目前使用基于规则的方法
        logger.debug("AI models loaded successfully")
    
    def analyze_attack_patterns(self, args: argparse.Namespace) -> Dict[str, Any]:
        """Analyze attack patterns from input data"""
        logger.info("Analyzing attack patterns...")
        
        # 1. 加载输入数据
        input_data = self._load_input_data(args)
        
        # 2. 预处理数据
        processed_data = self._preprocess_data(input_data)
        
        # 3. 应用AI模型进行模式识别
        detected_patterns = self._detect_patterns(processed_data)
        
        # 4. 生成分析报告
        report = self._generate_analysis_report(detected_patterns, processed_data)
        
        logger.info(f"Pattern analysis completed. Detected {len(report['detected_patterns'])} potential patterns.")
        return report
    
    def predict_behavior(self, args: argparse.Namespace) -> Dict[str, Any]:
        """Predict system behavior based on input data"""
        logger.info("Predicting system behavior...")
        
        # 1. 加载输入数据
        input_data = self._load_input_data(args)
        
        # 2. 预处理数据
        processed_data = self._preprocess_data(input_data)
        
        # 3. 应用AI模型进行行为预测
        predictions = self._predict_behavioral_outcomes(processed_data)
        
        # 4. 生成预测报告
        report = self._generate_prediction_report(predictions, processed_data)
        
        logger.info("Behavior prediction completed successfully")
        return report
    
    def generate_attack_recommendations(self, target: str, vulnerabilities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate attack recommendations based on identified vulnerabilities"""
        logger.info(f"Generating attack recommendations for target: {target}")
        
        recommendations = []
        
        # 1. 分析漏洞严重性和可利用性
        for vuln in vulnerabilities:
            severity = self._calculate_vulnerability_severity(vuln)
            exploitability = self._assess_exploitability(vuln)
            
            # 2. 生成优先级攻击路径
            attack_paths = self._generate_attack_paths(vuln, severity, exploitability)
            
            # 3. 提供详细的利用步骤
            exploitation_steps = self._generate_exploitation_steps(vuln, attack_paths)
            
            # 4. 包括防御缓解策略
            mitigation = self._generate_mitigation_strategies(vuln)
            
            recommendation = {
                "target": target,
                "vulnerability": vuln,
                "severity": severity,
                "exploitability_score": exploitability,
                "attack_paths": attack_paths,
                "exploitation_steps": exploitation_steps,
                "mitigation": mitigation,
                "timestamp": time.time()
            }
            
            recommendations.append(recommendation)
        
        # 按严重性和可利用性排序
        recommendations.sort(key=lambda x: (x["severity"], x["exploitability_score"]), reverse=True)
        
        logger.info(f"Generated {len(recommendations)} attack recommendations")
        return recommendations
    
    def _load_input_data(self, args: argparse.Namespace) -> Dict[str, Any]:
        """Load input data from specified source"""
        if hasattr(args, 'input_file') and args.input_file:
            try:
                with open(args.input_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Failed to load input file: {e}")
                # 返回示例数据用于测试
                return self._get_sample_data()
        else:
            logger.warning("No input file specified, using sample data")
            return self._get_sample_data()
    
    def _get_sample_data(self) -> Dict[str, Any]:
        """Return sample data for testing"""
        return {
            "network_connections": [
                {"source": "192.168.1.100", "destination": "192.168.1.1", "port": 80, "count": 10},
                {"source": "192.168.1.100", "destination": "192.168.1.1", "port": 443, "count": 5},
                {"source": "192.168.1.100", "destination": "192.168.1.2", "port": 22, "count": 3}
            ],
            "processes": [
                {"name": "ssh", "user": "user", "pid": 1234},
                {"name": "httpd", "user": "apache", "pid": 2345}
            ],
            "auth_attempts": [
                {"user": "admin", "success": False, "timestamp": time.time() - 300},
                {"user": "admin", "success": False, "timestamp": time.time() - 250},
                {"user": "admin", "success": False, "timestamp": time.time() - 200}
            ],
            "file_access": [
                {"path": "/etc/passwd", "user": "root", "access_type": "read"},
                {"path": "/var/log/auth.log", "user": "admin", "access_type": "read"}
            ]
        }
    
    def _preprocess_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Preprocess input data for analysis"""
        processed = data.copy()
        
        # 计算特征值
        if "auth_attempts" in data:
            failed_attempts = len([a for a in data["auth_attempts"] if not a.get("success", True)])
            processed["failed_auth_count"] = failed_attempts
        
        if "network_connections" in data:
            unique_ports = len(set([c["port"] for c in data["network_connections"]]))
            processed["unique_port_count"] = unique_ports
        
        return processed
    
    def _detect_patterns(self, data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect attack patterns in processed data"""
        detected = []
        
        # 检测端口扫描
        if data.get("unique_port_count", 0) > 10:
            detected.append({
                "pattern_id": "port_scan",
                "confidence": 0.85,
                "evidence": f"扫描了{data['unique_port_count']}个不同端口",
                "timestamp": time.time()
            })
        
        # 检测暴力破解
        if data.get("failed_auth_count", 0) > 5:
            detected.append({
                "pattern_id": "brute_force",
                "confidence": 0.9,
                "evidence": f"检测到{data['failed_auth_count']}次失败的认证尝试",
                "timestamp": time.time()
            })
        
        # 在开发模式下添加更详细的检测
        if self.is_dev_mode:
            # 检测敏感文件访问
            if "file_access" in data:
                sensitive_files = ["/etc/passwd", "/etc/shadow", "/var/log/auth.log"]
                for access in data["file_access"]:
                    if access["path"] in sensitive_files:
                        detected.append({
                            "pattern_id": "sensitive_file_access",
                            "confidence": 0.7,
                            "evidence": f"访问敏感文件: {access['path']}",
                            "timestamp": time.time()
                        })
        
        return detected
    
    def _generate_analysis_report(self, detected_patterns: List[Dict[str, Any]], data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate analysis report from detected patterns"""
        report = {
            "timestamp": time.time(),
            "analysis_type": "attack_patterns",
            "detected_patterns": [],
            "summary": {}
        }
        
        # 构建详细的模式信息
        for pattern in detected_patterns:
            pattern_info = self.patterns.get(pattern["pattern_id"], {})
            full_pattern = {
                **pattern,
                "name": pattern_info.get("name", pattern["pattern_id"]),
                "description": pattern_info.get("description", "未知模式"),
                "severity": pattern_info.get("severity", "unknown")
            }
            report["detected_patterns"].append(full_pattern)
        
        # 生成摘要
        severity_counts = {}
        for p in report["detected_patterns"]:
            severity = p.get("severity", "unknown")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
        
        report["summary"] = {
            "total_patterns": len(report["detected_patterns"]),
            "severity_distribution": severity_counts,
            "risk_level": self._calculate_overall_risk(severity_counts)
        }
        
        return report
    
    def _predict_behavioral_outcomes(self, data: Dict[str, Any]) -> Dict[str, float]:
        """Predict behavioral outcomes based on data"""
        predictions = {}
        
        # 计算各种行为模型的匹配分数
        for model_id, model in self.behavior_models.items():
            score = self._calculate_model_score(model, data)
            predictions[model_id] = score
        
        return predictions
    
    def _calculate_model_score(self, model: Dict[str, Any], data: Dict[str, Any]) -> float:
        """Calculate matching score for a behavior model"""
        score = 0.0
        
        # 基于特征计算分数
        if "failed_auth_count" in data and "failed_auth_attempts" in model.get("features", []):
            score += min(data["failed_auth_count"] / 10.0, 1.0) * 0.4
        
        if "unique_port_count" in data and "suspicious_connections" in model.get("features", []):
            score += min(data["unique_port_count"] / 50.0, 1.0) * 0.3
        
        # 开发模式下添加更多特征检查
        if self.is_dev_mode and "file_access" in data:
            sensitive_access = len([a for a in data["file_access"] if a["path"].startswith("/etc/")])
            score += min(sensitive_access / 5.0, 1.0) * 0.3
        
        return score
    
    def _generate_prediction_report(self, predictions: Dict[str, float], data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate prediction report from prediction scores"""
        report = {
            "timestamp": time.time(),
            "analysis_type": "behavior_prediction",
            "predictions": [],
            "most_likely_behavior": None,
            "confidence": 0.0
        }
        
        # 构建详细的预测信息
        for model_id, score in predictions.items():
            model_info = self.behavior_models.get(model_id, {})
            prediction = {
                "behavior_id": model_id,
                "name": model_info.get("name", model_id),
                "description": model_info.get("description", "未知行为"),
                "probability": score,
                "is_significant": score > model_info.get("threshold", 0.5)
            }
            report["predictions"].append(prediction)
        
        # 找出最可能的行为
        if report["predictions"]:
            most_likely = max(report["predictions"], key=lambda x: x["probability"])
            report["most_likely_behavior"] = most_likely["name"]
            report["confidence"] = most_likely["probability"]
        
        return report
    
    def _calculate_vulnerability_severity(self, vuln: Dict[str, Any]) -> str:
        """Calculate vulnerability severity"""
        # 基于CVSS评分或其他指标计算严重性
        cvss_score = vuln.get("cvss_score", 0.0)
        
        if cvss_score >= 9.0:
            return "critical"
        elif cvss_score >= 7.0:
            return "high"
        elif cvss_score >= 4.0:
            return "medium"
        else:
            return "low"
    
    def _assess_exploitability(self, vuln: Dict[str, Any]) -> float:
        """Assess vulnerability exploitability"""
        # 基础可利用性分数
        score = 0.5
        
        # 检查是否有公开的漏洞利用
        if vuln.get("has_exploit", False):
            score += 0.3
        
        # 检查是否需要特殊权限
        if not vuln.get("requires_privilege", True):
            score += 0.2
        
        return min(score, 1.0)
    
    def _generate_attack_paths(self, vuln: Dict[str, Any], severity: str, exploitability: float) -> List[Dict[str, Any]]:
        """Generate attack paths for a vulnerability"""
        paths = []
        
        # 基于漏洞类型生成攻击路径
        vuln_type = vuln.get("type", "unknown")
        
        if vuln_type == "rce":
            paths.append({
                "path": "直接远程代码执行",
                "complexity": "low" if exploitability > 0.7 else "medium",
                "steps": 1,
                "estimated_success_rate": exploitability
            })
        elif vuln_type == "sqli":
            paths.append({
                "path": "SQL注入 → 数据泄露 → 权限提升",
                "complexity": "medium",
                "steps": 3,
                "estimated_success_rate": exploitability * 0.8
            })
        elif vuln_type == "xss":
            paths.append({
                "path": "跨站脚本 → 会话劫持",
                "complexity": "medium",
                "steps": 2,
                "estimated_success_rate": exploitability * 0.7
            })
        else:
            # 默认攻击路径
            paths.append({
                "path": "标准漏洞利用流程",
                "complexity": "medium",
                "steps": 2,
                "estimated_success_rate": exploitability
            })
        
        return paths
    
    def _generate_exploitation_steps(self, vuln: Dict[str, Any], attack_paths: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate detailed exploitation steps"""
        steps = []
        vuln_type = vuln.get("type", "unknown")
        
        # 根据漏洞类型生成具体步骤
        if vuln_type == "rce":
            steps = [
                {"step": 1, "description": "构造恶意请求触发远程代码执行漏洞"},
                {"step": 2, "description": "执行命令验证漏洞是否可利用"},
                {"step": 3, "description": "建立持久访问或横向移动"}
            ]
        elif vuln_type == "sqli":
            steps = [
                {"step": 1, "description": "识别SQL注入点并确认漏洞"},
                {"step": 2, "description": "提取数据库结构和敏感信息"},
                {"step": 3, "description": "尝试执行系统命令"},
                {"step": 4, "description": "获取数据库用户权限"}
            ]
        else:
            # 默认步骤
            steps = [
                {"step": 1, "description": "确认漏洞存在并验证"},
                {"step": 2, "description": "使用适当的漏洞利用技术"},
                {"step": 3, "description": "获取目标系统的访问权限"},
                {"step": 4, "description": "执行后续操作（数据提取或持久性）"}
            ]
        
        return steps
    
    def _generate_mitigation_strategies(self, vuln: Dict[str, Any]) -> Dict[str, List[str]]:
        """Generate mitigation strategies for a vulnerability"""
        vuln_type = vuln.get("type", "unknown")
        
        mitigations = {
            "immediate": [],
            "long_term": [],
            "best_practices": []
        }
        
        # 通用缓解措施
        mitigations["immediate"].append("应用最新的安全补丁")
        mitigations["long_term"].append("定期进行安全评估和渗透测试")
        mitigations["best_practices"].append("实施最小权限原则")
        
        # 特定类型的缓解措施
        if vuln_type == "rce":
            mitigations["immediate"].append("暂时禁用受影响的服务或功能")
            mitigations["best_practices"].append("实施输入验证和输出编码")
        elif vuln_type == "sqli":
            mitigations["immediate"].append("使用参数化查询或预处理语句")
            mitigations["best_practices"].append("实施Web应用防火墙")
        
        return mitigations
    
    def _calculate_overall_risk(self, severity_counts: Dict[str, int]) -> str:
        """Calculate overall risk level based on severity distribution"""
        # 风险评分计算
        risk_score = 0
        weights = {"critical": 10, "high": 5, "medium": 2, "low": 1}
        
        for severity, count in severity_counts.items():
            risk_score += count * weights.get(severity, 0)
        
        # 确定风险等级
        if risk_score >= 20:
            return "critical"
        elif risk_score >= 10:
            return "high"
        elif risk_score >= 5:
            return "medium"
        else:
            return "low"