#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import sys
from typing import Optional

from .core import scan, escalate, lateral_move, exfiltrate, c2_communication
from .ai import ai_engine
from .utils import logger, config, auth


def main():
    """Main entry point for HOS_Hyacinth CLI"""
    
    # Display warning message
    print("=" * 60)
    print("HOS_Hyacinth - Advanced Red Team Penetration AI Toolkit")
    print("=" * 60)
    print("WARNING: This tool is for authorized security testing only.")
    print("Unauthorized use is illegal and unethical.")
    print("=" * 60)
    print()
    
    # Check authorization
    if not auth.check_authorization():
        print("ERROR: Authorization failed. Exiting.")
        sys.exit(1)
    
    parser = argparse.ArgumentParser(
        prog="hos",
        description="HOS_Hyacinth - Advanced Red Team Penetration AI Toolkit",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  hos scn -t 192.168.1.0/24       # Scan network for vulnerabilities
  hos esc -t target                # Attempt privilege escalation
  hos lrm -s source -d dest        # Perform lateral movement
  hos exf -t target -p passwords   # Extract sensitive data
  hos c2c -s server -p 443         # Setup C2 communication
  hos ai -a analyze -f log.txt     # Use AI for attack analysis
  
Development mode:
  hos --dev scn -t 192.168.1.1     # Run scan in development mode
        """
    )
    
    # Global options
    parser.add_argument(
        "--dev", 
        action="store_true", 
        help="Enable development mode (blue team analysis)"
    )
    
    # Subparsers for modules
    subparsers = parser.add_subparsers(dest="module", help="Available modules")
    
    # Scan module (scn)
    scn_parser = subparsers.add_parser("scn", help="Vulnerability scanning module")
    scn_parser.add_argument("-t", "--target", required=True, help="Target IP/Range/Domain")
    scn_parser.add_argument("-p", "--ports", help="Ports to scan (default: common ports)")
    scn_parser.add_argument("-o", "--output", help="Output file for results")
    
    # Escalate module (esc)
    esc_parser = subparsers.add_parser("esc", help="Privilege escalation module")
    esc_parser.add_argument("-t", "--target", required=True, help="Target system")
    esc_parser.add_argument("-m", "--method", help="Specific escalation method")
    esc_parser.add_argument("-o", "--output", help="Output file for results")
    
    # Lateral Movement module (lrm)
    lrm_parser = subparsers.add_parser("lrm", help="Lateral movement module")
    lrm_parser.add_argument("-s", "--source", required=True, help="Source system")
    lrm_parser.add_argument("-d", "--destination", required=True, help="Destination system")
    lrm_parser.add_argument("-m", "--method", help="Movement method")
    lrm_parser.add_argument("-o", "--output", help="Output file for results")
    
    # Exfiltrate module (exf)
    exf_parser = subparsers.add_parser("exf", help="Data exfiltration module")
    exf_parser.add_argument("-t", "--target", required=True, help="Target system")
    exf_parser.add_argument("-p", "--data-type", help="Data type to extract")
    exf_parser.add_argument("-o", "--output", help="Output file for results")
    
    # C2 Communication module (c2c)
    c2c_parser = subparsers.add_parser("c2c", help="C2 communication module")
    c2c_parser.add_argument("-s", "--server", required=True, help="C2 server address")
    c2c_parser.add_argument("-p", "--port", type=int, required=True, help="C2 server port")
    c2c_parser.add_argument("-m", "--method", help="Communication method")
    c2c_parser.add_argument("-o", "--output", help="Output file for results")
    
    # AI module (ai)
    ai_parser = subparsers.add_parser("ai", help="AI engine module")
    ai_parser.add_argument("-a", "--action", required=True, help="AI action (analyze, predict, etc.)")
    ai_parser.add_argument("-f", "--file", help="Input file for analysis")
    ai_parser.add_argument("-o", "--output", help="Output file for results")
    
    # Parse arguments
    args = parser.parse_args()
    
    # Set mode
    is_dev_mode = args.dev
    logger.setup_logger(dev_mode=is_dev_mode)
    config.set_mode(dev_mode=is_dev_mode)
    
    # Log command
    logger.log_command(" ".join(sys.argv))
    
    # Dispatch to appropriate module
    if args.module == "scn":
        scan.run(args)
    elif args.module == "esc":
        escalate.run(args)
    elif args.module == "lrm":
        lateral_move.run(args)
    elif args.module == "exf":
        exfiltrate.run(args)
    elif args.module == "c2c":
        c2_communication.run(args)
    elif args.module == "ai":
        ai_engine.run(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
