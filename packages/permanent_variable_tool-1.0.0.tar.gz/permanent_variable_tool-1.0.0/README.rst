Permanent Variable Tool
=======================
 
`var.new(variable:str, value:Any=None) -> None`
-----------------------------------------------------
 
**Functionality**
 
Creates/updates variable files in ``./data/`` directory 

**Usage Example**
 
.. code-block:: python 

   var.new("user_profile",  {"name": "John", "age": 28})  # Serializes to string 
   var.new("system_flag")   # Creates empty file

`var.read(variable:str) -> str`
----------------------------------
 
**Critical Notes**
 
- Always wrap in try-catch:
 
.. code-block:: python
 
   try:
       config = var.read("app_config") 
   except FileNotFoundError:
       initialize_defaults()
 
`var.delete(variable:str) -> None`
-------------------------------------
 
**Security Notice**
 
Deletion is permanent. Recommended safety check:
 
.. code-block:: python
 
   if os.path.exists(var.data_dir  + "/" + variable + ".var"):
       var.delete("temp_data") 