import os
def delete(variable):
    """
    Deletes a variable file with the given name from the 'data' subdirectory.
    
    Args:
        variable (str): The name of the variable file to be deleted (without .var extension)
        
    Raises:
        FileNotFoundError: If the specified variable file doesn't exist
        
    Note:
        - The file should be located in a 'data' subdirectory of the current script's directory
        - Files should have the '.var' extension 
    """
    path = os.path.join(f"C:\\pvt_data\\{variable}.var")
    
    try:
        os.remove(path) 
    except FileNotFoundError:
        raise FileNotFoundError(f"Variable file' {variable}.var' does not exist in the directory C:\\pvtdata\\")