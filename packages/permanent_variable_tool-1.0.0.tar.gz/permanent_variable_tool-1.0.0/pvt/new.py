import os
def new(variable, value=None):
    """
    Creates a new variable file with optional value in the 'data' subdirectory.
    
    Args:
        variable (str): Name of the variable file to create (without .var extension)
        value (any, optional): Value to store in the file. Converted to string.
                              Defaults to None (creates empty file).
    
    Behavior:
        - Creates a 'data' subdirectory if it doesn't exist (note: current code doesn't handle this)
        - Converts any non-None value to string before writing
        - Creates an empty file if value is None
        - Overwrites existing files silently
    
    Example:
        new("username", "admin")  # Creates data/username.var  containing "admin"
        new("temp")  # Creates empty data/temp.var  file
    """
    data = "C:\\pvt_data"
    path = os.path.join(f"C:\\pvt_data\\{variable}.var")
    if not os.path.exists(data): 
        os.makedirs(data) 
    
    if value is not None:
        value_str = str(value)
    else:
        value_str = ""
    
    with open(path, 'w', encoding='utf-8') as w:
        w.write(value_str) 