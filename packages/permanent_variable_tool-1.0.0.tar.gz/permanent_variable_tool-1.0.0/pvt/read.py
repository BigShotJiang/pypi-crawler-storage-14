import os
def read(variable):
    """
    Reads and returns the content of a variable file from the 'data' subdirectory.
    
    Args:
        variable (str): Name of the variable file to read (without .var extension)
        
    Returns:
        str: Content of the file as a string
        
    Raises:
        FileNotFoundError: If the specified variable file doesn't exist
        
    Note:
        - Files are expected to be UTF-8 encoded
        - File path format: ./data/{variable}.var
        - Empty files return empty string 
        - Last modified: November 25, 2025 (20:30)
    """ 
    path = os.path.join(f"C:\\pvt_data\\{variable}.var")
    
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read() 
    except FileNotFoundError:
        raise FileNotFoundError(f"Variable file' {variable}.var' does not exist in the directory C:\\pvtdata\\")