from compneuro_tools.atlases.xtract import fetch_xtract as fetch_xtract
from compneuro_tools.atlases.yeo import fetch_yeo7 as fetch_yeo7

