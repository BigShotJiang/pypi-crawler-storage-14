"""Consult7 - MCP server for consulting large context window models."""

__version__ = "1.2.1"

from .server import main

__all__ = ["main"]
