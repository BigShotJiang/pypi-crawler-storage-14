from libs.healthcheck.check_items.base_item import BaseItem
from libs.healthcheck.shared import MAX_MONGOS_PING_LATENCY, discover_nodes, enum_all_nodes, enum_result_items
from libs.utils import yellow, format_size


class HostInfoItem(BaseItem):
    def __init__(self, output_folder, config=None):
        super().__init__(output_folder, config)
        self._name = "Host Information"
        self._description = "Collects and reviews host hardware and OS information.  \n"
        self._description += "*This item is to gather information. No test is performed.*\n\n"

    def test(self, *args, **kwargs):
        """
        Main test method to gather host information.
        """
        client = kwargs.get("client")
        parsed_uri = kwargs.get("parsed_uri")
        nodes = discover_nodes(client, parsed_uri)

        def func_single(name, node, **kwargs):
            client = node["client"]
            if "pingLatencySec" in node and node["pingLatencySec"] > MAX_MONGOS_PING_LATENCY:
                self._logger.warning(
                    yellow(
                        f"Skip {node['host']} because it has been irresponsive for {node['pingLatencySec'] / 60:.2f} minutes."
                    )
                )
                return None, None
            host_info = client.admin.command("hostInfo")
            return None, host_info

        result = enum_all_nodes(
            nodes,
            func_rs_member=func_single,
            func_mongos_member=func_single,
            func_shard_member=func_single,
            func_config_member=func_single,
        )

        self.captured_sample = result

    @property
    def review_result(self):
        """
        Review the gathered host information.
        """
        result = self.captured_sample
        data = []

        def func_component(name, node, **kwargs):
            members = node["members"]
            table = {
                "type": "table",
                "caption": f"Hardware & OS Information - `{name}`",
                "columns": [
                    {"name": "Host", "type": "string"},
                    {"name": "CPU Family", "type": "string"},
                    {"name": "CPU Cores", "type": "string"},
                    {"name": "Memory", "type": "string"},
                    {"name": "OS", "type": "string"},
                    {"name": "NUMA", "type": "boolean"},
                ],
                "rows": [],
            }
            data.append(table)
            for m in members:
                info = m["rawResult"]
                if info is None:
                    table["rows"].append([m["host"], "n/a", "n/a", "n/a", "n/a", "n/a"])
                    continue
                system = info["system"]
                os = info["os"]
                extra = info["extra"]
                if "extra" in extra:
                    # Compatibility for MongoDB 6.0
                    extra = extra["extra"]
                table["rows"].append(
                    [
                        m["host"],
                        f"{extra.get('cpuString', '(Unknown CPU)')} ({system['cpuArch']}) {extra.get('cpuFrequencyMHz', 'n/a')} MHz",
                        f"{system['numCores']}c",
                        format_size(system["memSizeMB"] * 1024**2),
                        f"{os['name']} {os['version']}",
                        system["numaEnabled"],
                    ]
                )

        enum_result_items(
            result,
            func_rs_cluster=func_component,
            func_all_mongos=func_component,
            func_shard=func_component,
            func_config=func_component,
        )
        return {"name": self.name, "description": self.description, "data": data}
