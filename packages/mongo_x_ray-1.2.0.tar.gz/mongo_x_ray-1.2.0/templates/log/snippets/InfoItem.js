var cmd_options = document.getElementById("cmd_options");
var code = cmd_options.getElementsByTagName("code")[0];
hljs.highlightElement(code);