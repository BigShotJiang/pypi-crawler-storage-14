"""Tests for the veris_ai package."""
