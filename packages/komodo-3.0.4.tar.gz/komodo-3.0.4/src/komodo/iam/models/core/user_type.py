from __future__ import annotations
import json
from enum import Enum
from typing_extensions import Self


class UserType(str, Enum):
    """
    UserType
    """

    """
    allowed enum values
    """
    INTERNAL = "INTERNAL"
    EXTERNAL = "EXTERNAL"

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        """Create an instance of UserType from a JSON string"""
        return cls(json.loads(json_str))
