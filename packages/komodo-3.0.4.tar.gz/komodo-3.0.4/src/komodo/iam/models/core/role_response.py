from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from datetime import datetime
from pydantic import BaseModel, ConfigDict, Field, StrictStr
from typing import Any, ClassVar, Dict, List, Optional
from typing import Optional, Set, Union
from typing_extensions import Self


class RoleResponse(BaseModel):
    """
    RoleResponse
    """  # noqa: E501

    application_id: StrictStr = Field(description="Application ID")
    created_at: datetime = Field(description="Time of creation")
    created_by: Optional[StrictStr] = Field(default=None, description="Created By")
    description: StrictStr = Field(description="Role description")
    name: StrictStr = Field(description="Role name")
    organization_id: Optional[StrictStr] = Field(default=None, description="Organization id")
    role_id: StrictStr = Field(description="Role ID")
    updated_at: datetime = Field(description="Time of last update")
    updated_by: Optional[StrictStr] = Field(default=None, description="Updated By")
    __properties: ClassVar[List[str]] = ["application_id", "created_at", "created_by", "description", "name", "organization_id", "role_id", "updated_at", "updated_by"]

    model_config = ConfigDict(populate_by_name=True, validate_assignment=True, protected_namespaces=(), extra="allow")

    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of RoleResponse from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of RoleResponse from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate(
            {
                "application_id": obj.get("application_id"),
                "created_at": obj.get("created_at"),
                "created_by": obj.get("created_by"),
                "description": obj.get("description"),
                "name": obj.get("name"),
                "organization_id": obj.get("organization_id"),
                "role_id": obj.get("role_id"),
                "updated_at": obj.get("updated_at"),
                "updated_by": obj.get("updated_by"),
            }
        )
        return _obj
