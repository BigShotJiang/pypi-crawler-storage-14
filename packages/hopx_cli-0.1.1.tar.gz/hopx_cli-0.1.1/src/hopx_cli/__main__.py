"""Main entry point for the Hopx CLI when run as a module."""

from hopx_cli.main import app

if __name__ == "__main__":
    app()
