"""Hopx CLI - Official command-line interface for Hopx.ai cloud sandboxes."""

__version__ = "0.1.1"
__author__ = "HOPX.AI"
