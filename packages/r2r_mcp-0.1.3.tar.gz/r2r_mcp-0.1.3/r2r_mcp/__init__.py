"""R2R MCP Server - Model Context Protocol server for R2R retrieval system.

This package provides a FastMCP server that connects to R2R (RAG to Riches)
for advanced retrieval-augmented generation capabilities.

Environment Variables:
    R2R_API_BASE: R2R server URL (default: http://localhost:7272)
    R2R_COLLECTION: Collection name for queries (optional)
    R2R_API_KEY: API key for authentication (optional)
"""

__version__ = "0.1.3"
__author__ = "Igor Solomatov"

from r2r_mcp.server import mcp

__all__ = ["mcp", "__version__"]

