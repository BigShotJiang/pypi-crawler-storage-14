"""Entry point for running r2r-mcp as a module.

This allows the package to be executed as:
    python -m r2r_mcp
"""

from r2r_mcp.server import main

if __name__ == "__main__":
    main()

