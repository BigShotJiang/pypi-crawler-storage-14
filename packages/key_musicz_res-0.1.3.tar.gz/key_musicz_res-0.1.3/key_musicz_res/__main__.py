#
import sys,os
from buildz import argx,xf
dp = os.path.dirname(__file__)
sfile = os.path.join(dp,'res', 'piano1_from_TimGM6mb.sf2')
libpath = os.path.join(dp, 'win_lib')
fetch = argx.Fetch(*xf.loads("[fp,sfile,libpath,default,help],{f:fp,s:sfile,l:libpath,t:default,h:help}"))
conf = fetch(sys.argv[1:])
if 'sfile' not in conf:
    conf['sfile'] = sfile
    print("注：\n  本库默认的按键音文件的音色不太好，低音区声音很小，建议自己去网上下载")
    print("  国内FluidR3_GM.sf2文件下载路径: ")
    print("    https://gitcode.com/open-source-toolkit/1d145/?utm_source=tools_gitcode&index=top&type=card&")
    print("    文件大小145MB，其中7.6MB是钢琴按键")
    print("  FluidR3Mono_GM.sf2文件感觉更好些，但忘记下载地址了，需要的可以自己网上搜下\n")
    print("  使用自己下载的按键音: \n    python -m key_musicz_res --sfile=按键音文件路径\n\n")
if 'libpath' not in conf:
    conf['libpath'] = libpath
if 'default' not in conf:
    conf['default'] = 'newplay.js'
kvs = [f"--{k}={v}" for k,v in conf.items()]
sys.argv = sys.argv[:1]+kvs
# print("params after key_musicz_res changes:", sys.argv[1:])
from key_musicz import newconf as conf
# from key_musicz import conf
conf.test()

'''
python -m key_musicz_res

python -m key_musicz_res --sfile=D:\rootz\python\gits\key_musicz\res\mini_mono_piano.sf2

'''