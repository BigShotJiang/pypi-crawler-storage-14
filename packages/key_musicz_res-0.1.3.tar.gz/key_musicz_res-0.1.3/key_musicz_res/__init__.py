#coding=utf-8

__version__="0.0.3"
__author__ = "Zzz, emails: 1174534295@qq.com, 1309458652@qq.com"
__doc__="""
win_lib下是从https://github.com/FluidSynth/fluidsynth/releases/download/v2.4.6/fluidsynth-2.4.6-win10-x64.zip下载的fluidsynth库文件
res下是从网上下载的TimGM6mb.sf2里提取的钢琴音文件
"""
