# tests/test_core.py
import os
import shutil
import tempfile
import pytest

from ginom.core import init_repo, save, log, meta_paths
from ginom.index import track, status
from ginom.refs import head_branch, read_ref

@pytest.fixture
def temp_repo():
    root = tempfile.mkdtemp()
    init_repo(root)
    yield root
    shutil.rmtree(root)

def test_init_creates_structure(temp_repo):
    paths = meta_paths(temp_repo)
    assert os.path.isdir(paths["meta"])
    assert os.path.isfile(paths["HEAD"])
    assert os.path.isfile(paths["index"])
    assert os.path.isfile(paths["config"])
    assert os.path.isfile(paths["ignore"])

def test_track_and_status(temp_repo):
    paths = meta_paths(temp_repo)
    # create a dummy file
    fpath = os.path.join(temp_repo, "hello.py")
    with open(fpath, "w") as f:
        f.write("print('hello')")
    track(paths["index"], "hello.py")
    tracked = status(paths["index"])
    assert "hello.py" in tracked

def test_save_and_log(temp_repo):
    paths = meta_paths(temp_repo)
    # create a dummy file
    fpath = os.path.join(temp_repo, "hello.py")
    with open(fpath, "w") as f:
        f.write("print('hello')")
    track(paths["index"], "hello.py")
    commit_oid = save(temp_repo, "Initial commit", author="Norman")
    assert commit_oid is not None
    branch = head_branch(temp_repo)
    assert read_ref(temp_repo, branch) == commit_oid
    history = log(temp_repo)
    assert history[0]["message"] == "Initial commit"
