# ytp-dl

> A lightweight YouTube downloader with Mullvad VPN integration and HTTP API

[![PyPI version](https://img.shields.io/pypi/v/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)
[![Python Support](https://img.shields.io/pypi/pyversions/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)
[![License](https://img.shields.io/pypi/l/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)
[![Downloads](https://img.shields.io/pypi/dm/ytp-dl.svg)](https://pypi.org/project/ytp-dl/)

**ytp-dl** is a privacy-focused YouTube downloader that automatically routes downloads through Mullvad VPN. It provides both a command-line interface and an HTTP API for easy integration.

---

## ✨ Features

- 🔒 **Privacy First** — Automatically connects/disconnects Mullvad VPN per download
- 🎥 **Smart Quality Selection** — Prefers 1080p H.264 + AAC (no transcoding needed)
- 🎵 **Audio Downloads** — Extract audio as MP3
- 🚀 **HTTP API** — Simple Flask-based API with concurrency controls
- ⚡ **VPS Ready** — Includes automated installer script for Ubuntu

---

## 📦 Installation

```bash
pip install ytp-dl==0.3.43
```

**Requirements:**
- Linux operating system (tested on Ubuntu 24.04/25.04)
- [Mullvad CLI](https://mullvad.net/en/download/vpn/linux) installed and configured
- FFmpeg (for audio extraction)

---

## 🚀 Quick Start

### Command Line Usage

**Download video (1080p or best available):**
```bash
ytp-dl "https://www.youtube.com/watch?v=VIDEO_ID" --resolution 1080 --extension mp4
```

**Download audio only:**
```bash
ytp-dl "https://www.youtube.com/watch?v=VIDEO_ID" --extension mp3
```

### HTTP API

Start the Flask API server:

```bash
ytp-dl-api
# Listens on 0.0.0.0:5000 by default
```

**Example request:**
```bash
curl -X POST http://127.0.0.1:5000/api/download \
  -H "Content-Type: application/json" \
  -d '{"url": "https://www.youtube.com/watch?v=VIDEO_ID", "resolution": 1080, "extension": "mp4"}' \
  --output video.mp4
```

---

## ⚙️ Configuration

Configure ytp-dl using environment variables:

| Variable | Description | Default |
|----------|-------------|---------|
| `YTPDL_MAX_CONCURRENT` | Maximum concurrent downloads | `2` |
| `YTPDL_MULLVAD_LOCATION` | Mullvad relay location code | `us` |
| `YTPDL_VENV` | Path to virtualenv for yt-dlp | — |
| `YTPDL_AUDIO_LANG` | Preferred audio language | `en` |
| `YTPDL_ACCEPT_LANGUAGE` | HTTP Accept-Language header | `en-US,en;q=0.9` |

---

## 🌍 Language Handling

ytp-dl intelligently handles videos with multiple audio tracks:

- ✅ Prefers English audio tracks when available
- ✅ Falls back to other languages only if English unavailable
- ✅ Sets HTTP headers to prefer English content

This prevents accidentally downloading dubbed audio when the original is in English.

---

## 🖥️ VPS Deployment

**One-Command Ubuntu Setup:**

The included installation script automatically configures a production-ready VPS:

```bash
# With Mullvad account
MV_ACCOUNT=your_account_number bash VPS_Installation.sh

# If already logged in
bash VPS_Installation.sh
```

**What it does:**
- ✅ Installs Python, FFmpeg, and Mullvad CLI
- ✅ Creates virtualenv at `/opt/yt-dlp-mullvad/venv`
- ✅ Sets up systemd service on port 5000
- ✅ Configures Gunicorn with gevent workers
- ✅ Optional hourly auto-reboot via cron

### Full Installation Script

**VPS_Installation.sh:**

```bash
#!/usr/bin/env bash
# VPS_Installation.sh - Minimal Ubuntu 24.04/25.04 setup for ytp-dl API + Mullvad
#
# What this does:
#   - Installs Python, ffmpeg, Mullvad CLI
#   - Creates a virtualenv at /opt/yt-dlp-mullvad/venv
#   - Installs ytp-dl==0.3.43 + gunicorn + gevent in that venv
#   - Creates a simple systemd service ytp-dl-api.service on port 5000
#   - (NEW) Sets up cron to reboot the droplet on a schedule (default: hourly)
#
# Mullvad connect/disconnect is handled per-job by downloader.py.

set -euo pipefail

### --- Tunables -------------------------------------------------------------
PORT="${PORT:-5000}"                           # API listen port
APP_DIR="${APP_DIR:-/opt/yt-dlp-mullvad}"      # app/venv root
VENV_DIR="${VENV_DIR:-${APP_DIR}/venv}"        # python venv

MV_ACCOUNT="${MV_ACCOUNT:-}"                   # Mullvad account (put number after -)
MAX_CONCURRENCY="${MAX_CONCURRENCY:-2}"        # API concurrency cap
MULLVAD_LOCATION="${MULLVAD_LOCATION:-us}"     # default Mullvad relay hint

AUTO_REBOOT_CRON="${AUTO_REBOOT_CRON:-0 * * * *}"
### -------------------------------------------------------------------------

[[ "${EUID}" -eq 0 ]] || { echo "Please run as root"; exit 1; }
export DEBIAN_FRONTEND=noninteractive

echo "==> 1) Base packages & Mullvad CLI"
apt-get update
apt-get install -yq --no-install-recommends \
  python3-venv python3-pip curl ffmpeg ca-certificates

if ! command -v mullvad >/dev/null 2>&1; then
  curl -fsSLo /tmp/mullvad.deb https://mullvad.net/download/app/deb/latest/
  apt-get install -y /tmp/mullvad.deb
fi

if [[ -n "${MV_ACCOUNT}" ]]; then
  echo "Logging into Mullvad account (if not already logged in)..."
  mullvad account login "${MV_ACCOUNT}" || true
fi

mullvad status || true

echo "==> 2) App dir & virtualenv"
mkdir -p "${APP_DIR}"
python3 -m venv "${VENV_DIR}"
source "${VENV_DIR}/bin/activate"
pip install --upgrade pip
pip install "ytp-dl==0.3.43" gunicorn gevent
deactivate

echo "==> 3) API environment file (/etc/default/ytp-dl-api)"
tee /etc/default/ytp-dl-api >/dev/null <<EOF
YTPDL_MAX_CONCURRENT=${MAX_CONCURRENCY}
YTPDL_MULLVAD_LOCATION=${MULLVAD_LOCATION}
YTPDL_VENV=${VENV_DIR}
EOF

echo "==> 4) Gunicorn systemd service (ytp-dl-api.service on :${PORT})"
tee /etc/systemd/system/ytp-dl-api.service >/dev/null <<EOF
[Unit]
Description=Gunicorn for ytp-dl Mullvad API (minimal)
After=network-online.target
Wants=network-online.target

[Service]
User=root
WorkingDirectory=${APP_DIR}
EnvironmentFile=/etc/default/ytp-dl-api
Environment=VIRTUAL_ENV=${VENV_DIR}
Environment=PATH=${VENV_DIR}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin

ExecStart=${VENV_DIR}/bin/gunicorn -k gevent -w 1 \
  --worker-connections 200 --timeout 0 --graceful-timeout 15 --keep-alive 20 \
  --bind 0.0.0.0:${PORT} scripts.api:app

Restart=always
RestartSec=3
LimitNOFILE=65535
MemoryMax=800M

[Install]
WantedBy=multi-user.target
EOF

echo "==> 5) Start and enable API service"
systemctl daemon-reload
systemctl enable --now ytp-dl-api.service

echo "==> 6) Auto-reboot cron (/etc/cron.d/ytp-dl-auto-reboot)"
if [[ -n "${AUTO_REBOOT_CRON}" ]]; then
  REBOOT_BIN="$(command -v reboot || echo /sbin/reboot)"
  tee /etc/cron.d/ytp-dl-auto-reboot >/dev/null <<EOF
${AUTO_REBOOT_CRON} root ${REBOOT_BIN}
EOF
  chmod 644 /etc/cron.d/ytp-dl-auto-reboot
  systemctl restart cron || true
else
  echo "AUTO_REBOOT_CRON empty; skipping auto-reboot setup."
fi

echo "==> 7) Quick status + health check"
systemctl status ytp-dl-api --no-pager || true

echo
echo "Waiting for API to start..."
sleep 3
echo "Health (local):"
curl -sS "http://127.0.0.1:${PORT}/healthz" || true
```

---