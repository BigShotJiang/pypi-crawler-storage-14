import sierra.cli


def cli() -> None:
    sierra.cli.main()


if __name__ == "__main__":
    cli()
