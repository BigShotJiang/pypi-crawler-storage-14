import sys

if sys.platform == "win32":
    from .windows import KeyboardWindows as KeyboardImpl
else:
    from .unix import KeyboardUnix as KeyboardImpl


class KeyboardCrossplatform(KeyboardImpl):
    pass
