from abc import ABC, abstractmethod


class KeyboardABC(ABC):
    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def stop(self):
        pass

    @abstractmethod
    def get_key(self):
        """Blocking key retrieval"""
        pass
