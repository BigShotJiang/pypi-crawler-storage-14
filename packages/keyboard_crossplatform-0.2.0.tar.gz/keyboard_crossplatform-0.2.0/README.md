# Keyboard Cross-Platform Keylogger

This project is a cross-platform keylogger implemented in Python. It supports macOS, Windows, and Linux operating systems, allowing users to capture keyboard events seamlessly across different environments.

## Features

- Cross-platform support for macOS, Windows, and Linux.
- Real-time key logging with minimal performance impact.
- Easy to integrate and extend for additional functionalities.

## Installation

To install the required dependencies, you can use pip. Make sure you have Python installed on your system, then run:

```
pip install -r requirements.txt
```

## Usage

To run the keylogger, execute the following command in your terminal:

```
python -m keyboard_crossplatform
```

The keylogger will start listening for key presses. To stop the keylogger, press the `esc` key.

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for more details.