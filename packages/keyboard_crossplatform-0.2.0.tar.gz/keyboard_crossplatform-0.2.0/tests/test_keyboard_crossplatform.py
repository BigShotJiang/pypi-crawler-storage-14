import unittest
from keyboard_crossplatform import KeyLogger

class TestKeyLogger(unittest.TestCase):

    def setUp(self):
        self.keylogger = KeyLogger()

    def test_os_detection(self):
        os_name = self.keylogger.os
        self.assertIn(os_name, ["macOS", "Windows", "Linux"], "Operating system detection failed.")

    def test_get_key(self):
        # This test is a placeholder since we cannot simulate key presses in a unit test.
        # In a real scenario, you would mock the keyboard events.
        self.assertIsNone(self.keylogger.getKey(), "getKey should return None initially.")

if __name__ == "__main__":
    unittest.main()