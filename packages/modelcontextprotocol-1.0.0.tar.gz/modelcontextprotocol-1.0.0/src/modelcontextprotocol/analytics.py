"""
Analytics integration with PostHog.
"""

from typing import Optional, Dict, Any
from loguru import logger


class Analytics:
    """PostHog analytics integration."""
    
    def __init__(self, api_key: Optional[str] = None, host: str = "https://app.posthog.com"):
        """
        Initialize analytics.
        
        Args:
            api_key: PostHog API key (if None, analytics are disabled)
            host: PostHog host URL
        """
        self.enabled = api_key is not None
        self.api_key = api_key
        self.host = host
        self.client = None
        
        if self.enabled:
            try:
                import posthog
                posthog.api_key = api_key
                posthog.host = host
                self.client = posthog
                logger.debug("PostHog analytics enabled")
            except ImportError:
                logger.warning("PostHog not installed, analytics disabled")
                self.enabled = False
            except Exception as e:
                logger.warning(f"Failed to initialize PostHog: {e}")
                self.enabled = False
    
    def track_event(self, event_name: str, properties: Optional[Dict[str, Any]] = None) -> None:
        """
        Track an analytics event.
        
        Args:
            event_name: Name of the event
            properties: Event properties
        """
        if not self.enabled or not self.client:
            return
        
        try:
            self.client.capture(
                distinct_id="anonymous",  # Can be customized
                event=event_name,
                properties=properties or {}
            )
            logger.debug(f"Tracked event: {event_name}")
        except Exception as e:
            logger.debug(f"Failed to track event: {e}")
    
    def identify(self, user_id: str, properties: Optional[Dict[str, Any]] = None) -> None:
        """
        Identify a user.
        
        Args:
            user_id: User identifier
            properties: User properties
        """
        if not self.enabled or not self.client:
            return
        
        try:
            self.client.identify(
                distinct_id=user_id,
                properties=properties or {}
            )
            logger.debug(f"Identified user: {user_id}")
        except Exception as e:
            logger.debug(f"Failed to identify user: {e}")
