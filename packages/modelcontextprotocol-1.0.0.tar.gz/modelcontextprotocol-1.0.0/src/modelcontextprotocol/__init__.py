"""
Model Context Protocol - CLI and Utilities

CLI tool for scaffolding MCP projects with enhanced logging and analytics.
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
