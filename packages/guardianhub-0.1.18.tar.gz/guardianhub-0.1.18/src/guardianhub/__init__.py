# src/guardianhub/__init__.py
from ._version import __version__  # version exported for users

# Expose public modules (minimal)
__all__ = ["__version__"]