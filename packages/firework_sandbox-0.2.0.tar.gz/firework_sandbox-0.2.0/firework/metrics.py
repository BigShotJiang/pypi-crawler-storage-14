"""Metrics collection and monitoring for Firework sandbox infrastructure.

This module provides:
- MetricsConfig: Configuration for the metrics system
- HostMetrics: Host-level metrics snapshot
- SandboxMetricSnapshot: Per-sandbox metrics
- MetricsCollector: Async metrics collection loop
"""

import asyncio
import logging
import os
import psutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from firework.backend import SandboxBackend

logger = logging.getLogger(__name__)


# Environment variable names for metrics configuration
ENV_COLLECTION_INTERVAL = "METRICS_COLLECTION_INTERVAL_SECONDS"
ENV_CLOUDWATCH_INTERVAL = "CLOUDWATCH_PUBLISH_INTERVAL_SECONDS"
ENV_METRICS_HOST = "METRICS_HOST"
ENV_METRICS_PORT = "METRICS_PORT"
ENV_CAPACITY_LOW_THRESHOLD = "CAPACITY_LOW_THRESHOLD"
ENV_MEMORY_PRESSURE_THRESHOLD = "MEMORY_PRESSURE_THRESHOLD"
ENV_CREATION_LATENCY_THRESHOLD = "CREATION_LATENCY_THRESHOLD_SECONDS"
ENV_IDLE_TIMEOUT = "IDLE_TIMEOUT_MINUTES"
ENV_HOST_ID = "HOST_ID"
ENV_REGION = "AWS_REGION"
ENV_ENVIRONMENT = "ENVIRONMENT"
ENV_CLOUDWATCH_ENABLED = "CLOUDWATCH_ENABLED"
ENV_SANDBOX_CAPACITY = "SANDBOX_CAPACITY_TOTAL"


def _get_env_float(name: str, default: float) -> float:
    """Get a float from environment variable with fallback to default."""
    value = os.environ.get(name)
    if value is not None:
        try:
            return float(value)
        except ValueError:
            logger.warning(f"Invalid value for {name}: {value}, using default {default}")
    return default


def _get_env_int(name: str, default: int) -> int:
    """Get an int from environment variable with fallback to default."""
    value = os.environ.get(name)
    if value is not None:
        try:
            return int(value)
        except ValueError:
            logger.warning(f"Invalid value for {name}: {value}, using default {default}")
    return default


def _get_env_str(name: str, default: str) -> str:
    """Get a string from environment variable with fallback to default."""
    return os.environ.get(name, default)


def _get_env_bool(name: str, default: bool) -> bool:
    """Get a boolean from environment variable with fallback to default."""
    value = os.environ.get(name)
    if value is not None:
        return value.lower() in ("true", "1", "yes", "on")
    return default


@dataclass
class MetricsConfig:
    """Configuration for the metrics system.
    
    All settings have sensible defaults and can be overridden via environment variables.
    """
    
    # Collection settings
    collection_interval_seconds: float = 15.0
    cloudwatch_publish_interval_seconds: float = 60.0
    
    # Exporter settings
    metrics_host: str = "0.0.0.0"
    metrics_port: int = 9090
    
    # Thresholds
    capacity_low_threshold: float = 0.2
    memory_pressure_threshold: float = 0.85
    creation_latency_threshold_seconds: float = 5.0
    idle_timeout_minutes: int = 30
    
    # Host identification
    host_id: str = ""
    region: str = ""
    environment: str = "development"
    
    # Capacity
    sandbox_capacity_total: int = 10
    
    # Feature flags
    cloudwatch_enabled: bool = False
    
    @classmethod
    def from_env(cls) -> "MetricsConfig":
        """Create configuration from environment variables with defaults."""
        return cls(
            collection_interval_seconds=_get_env_float(ENV_COLLECTION_INTERVAL, 15.0),
            cloudwatch_publish_interval_seconds=_get_env_float(ENV_CLOUDWATCH_INTERVAL, 60.0),
            metrics_host=_get_env_str(ENV_METRICS_HOST, "0.0.0.0"),
            metrics_port=_get_env_int(ENV_METRICS_PORT, 9090),
            capacity_low_threshold=_get_env_float(ENV_CAPACITY_LOW_THRESHOLD, 0.2),
            memory_pressure_threshold=_get_env_float(ENV_MEMORY_PRESSURE_THRESHOLD, 0.85),
            creation_latency_threshold_seconds=_get_env_float(ENV_CREATION_LATENCY_THRESHOLD, 5.0),
            idle_timeout_minutes=_get_env_int(ENV_IDLE_TIMEOUT, 30),
            host_id=_get_env_str(ENV_HOST_ID, ""),
            region=_get_env_str(ENV_REGION, ""),
            environment=_get_env_str(ENV_ENVIRONMENT, "development"),
            sandbox_capacity_total=_get_env_int(ENV_SANDBOX_CAPACITY, 10),
            cloudwatch_enabled=_get_env_bool(ENV_CLOUDWATCH_ENABLED, False),
        )


@dataclass
class SandboxMetricSnapshot:
    """Per-sandbox metrics snapshot."""
    
    sandbox_id: str
    state: str  # running, paused, stopped
    cpu_percent: float
    memory_mb: float
    uptime_seconds: float
    last_activity_at: datetime
    idle_seconds: float


@dataclass
class HostMetrics:
    """Host-level metrics snapshot."""
    
    timestamp: datetime
    host_id: str
    
    # Sandbox counts
    sandbox_active_count: int
    sandbox_capacity_total: int
    
    # Host resources
    host_cpu_percent: float
    host_memory_percent: float
    host_memory_available_mb: float
    host_disk_percent: float
    
    # Per-sandbox metrics
    sandbox_metrics: List[SandboxMetricSnapshot] = field(default_factory=list)
    
    @property
    def capacity_score(self) -> float:
        """Compute capacity score: (capacity_total - active_count) / capacity_total.
        
        Returns a value in range [0.0, 1.0]. Returns 0.0 if capacity_total is 0.
        """
        if self.sandbox_capacity_total <= 0:
            return 0.0
        score = (self.sandbox_capacity_total - self.sandbox_active_count) / self.sandbox_capacity_total
        return max(0.0, min(1.0, score))


class Histogram:
    """Simple histogram for tracking duration distributions.
    
    Buckets: 0.1, 0.5, 1.0, 2.5, 5.0, 10.0, +Inf
    """
    
    BUCKETS = [0.1, 0.5, 1.0, 2.5, 5.0, 10.0, float('inf')]
    
    def __init__(self):
        self._counts: Dict[float, int] = {b: 0 for b in self.BUCKETS}
        self._sum: float = 0.0
        self._count: int = 0
    
    def observe(self, value: float) -> None:
        """Record an observation."""
        self._sum += value
        self._count += 1
        for bucket in self.BUCKETS:
            if value <= bucket:
                self._counts[bucket] += 1
    
    @property
    def sum(self) -> float:
        """Total sum of all observations."""
        return self._sum
    
    @property
    def count(self) -> int:
        """Total count of observations."""
        return self._count
    
    def get_bucket_counts(self) -> Dict[float, int]:
        """Get cumulative counts for each bucket."""
        return dict(self._counts)
    
    def reset(self) -> None:
        """Reset all counters."""
        self._counts = {b: 0 for b in self.BUCKETS}
        self._sum = 0.0
        self._count = 0


class MetricsCollector:
    """Collects metrics from the sandbox backend.
    
    Runs an async collection loop that gathers host and sandbox metrics
    at a configurable interval.
    """
    
    def __init__(self, backend: "SandboxBackend", config: MetricsConfig):
        """Initialize the metrics collector.
        
        Args:
            backend: The sandbox backend to collect metrics from
            config: Metrics configuration
        """
        self._backend = backend
        self._config = config
        self._latest_metrics: Optional[HostMetrics] = None
        self._running = False
        self._task: Optional[asyncio.Task] = None
        
        # Histograms for duration tracking
        self._creation_histogram = Histogram()
        self._command_histogram = Histogram()
    
    @property
    def config(self) -> MetricsConfig:
        """Get the metrics configuration."""
        return self._config
    
    @property
    def creation_histogram(self) -> Histogram:
        """Get the creation duration histogram."""
        return self._creation_histogram
    
    @property
    def command_histogram(self) -> Histogram:
        """Get the command duration histogram."""
        return self._command_histogram
    
    async def start(self) -> None:
        """Start the collection loop."""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._collection_loop())
        logger.info(
            f"MetricsCollector started with interval={self._config.collection_interval_seconds}s"
        )
    
    async def stop(self) -> None:
        """Stop the collection loop gracefully."""
        if not self._running:
            return
        
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("MetricsCollector stopped")
    
    async def _collection_loop(self) -> None:
        """Main collection loop."""
        while self._running:
            try:
                metrics = await self.collect()
                self._latest_metrics = metrics
                logger.debug(
                    f"Collected metrics: active={metrics.sandbox_active_count}, "
                    f"cpu={metrics.host_cpu_percent:.1f}%, mem={metrics.host_memory_percent:.1f}%"
                )
            except Exception as e:
                logger.error(f"Error collecting metrics: {e}")
            
            await asyncio.sleep(self._config.collection_interval_seconds)


    async def collect(self) -> HostMetrics:
        """Perform a single collection cycle.
        
        Gathers host-level metrics (CPU, memory, disk) and per-sandbox metrics
        from the backend.
        
        Returns:
            HostMetrics object with current metrics snapshot
        """
        timestamp = datetime.now(timezone.utc)
        
        # Collect host-level metrics using psutil
        host_cpu_percent = psutil.cpu_percent(interval=None)
        memory = psutil.virtual_memory()
        host_memory_percent = memory.percent
        host_memory_available_mb = memory.available / (1024 * 1024)
        
        disk = psutil.disk_usage('/')
        host_disk_percent = disk.percent
        
        # Collect sandbox metrics from backend
        sandbox_metrics: List[SandboxMetricSnapshot] = []
        sandbox_active_count = 0
        
        # Get list of sandboxes from the runtime directory
        try:
            sandbox_ids = await self._get_sandbox_ids()
            for sandbox_id in sandbox_ids:
                try:
                    info = await self._backend.get_info(sandbox_id)
                    if info is None:
                        continue
                    
                    state = await self._backend.get_state(sandbox_id)
                    if state == "running":
                        sandbox_active_count += 1
                    
                    # Get per-sandbox metrics
                    metrics = await self._backend.get_metrics(sandbox_id)
                    
                    # Calculate uptime and idle time
                    uptime_seconds = (timestamp - info.created_at).total_seconds()
                    idle_seconds = (timestamp - info.last_used_at).total_seconds()
                    
                    snapshot = SandboxMetricSnapshot(
                        sandbox_id=sandbox_id,
                        state=state,
                        cpu_percent=metrics.cpu_percent,
                        memory_mb=metrics.memory_mb,
                        uptime_seconds=uptime_seconds,
                        last_activity_at=info.last_used_at,
                        idle_seconds=idle_seconds,
                    )
                    sandbox_metrics.append(snapshot)
                except Exception as e:
                    logger.warning(f"Error collecting metrics for sandbox {sandbox_id}: {e}")
        except Exception as e:
            logger.warning(f"Error listing sandboxes: {e}")
        
        return HostMetrics(
            timestamp=timestamp,
            host_id=self._config.host_id,
            sandbox_active_count=sandbox_active_count,
            sandbox_capacity_total=self._config.sandbox_capacity_total,
            host_cpu_percent=host_cpu_percent,
            host_memory_percent=host_memory_percent,
            host_memory_available_mb=host_memory_available_mb,
            host_disk_percent=host_disk_percent,
            sandbox_metrics=sandbox_metrics,
        )
    
    async def _get_sandbox_ids(self) -> List[str]:
        """Get list of sandbox IDs from the backend's runtime directory."""
        from pathlib import Path
        
        # Access the runtime directory from the backend
        if hasattr(self._backend, 'runtime_dir'):
            runtime_dir = Path(self._backend.runtime_dir)
            if runtime_dir.exists():
                return [
                    d.name for d in runtime_dir.iterdir()
                    if d.is_dir() and d.name.startswith('sbx_')
                ]
        return []
    
    def get_latest_metrics(self) -> Optional[HostMetrics]:
        """Get the most recently collected metrics.
        
        Returns:
            The latest HostMetrics or None if no collection has occurred yet
        """
        return self._latest_metrics
    
    def record_creation_duration(self, duration_seconds: float) -> None:
        """Record a sandbox creation duration for histogram.
        
        Args:
            duration_seconds: Time taken to create the sandbox
        """
        self._creation_histogram.observe(duration_seconds)
        logger.debug(f"Recorded creation duration: {duration_seconds:.3f}s")
    
    def record_command_duration(self, duration_seconds: float) -> None:
        """Record a command execution duration for histogram.
        
        Args:
            duration_seconds: Time taken to execute the command
        """
        self._command_histogram.observe(duration_seconds)
        logger.debug(f"Recorded command duration: {duration_seconds:.3f}s")
    
    @property
    def is_running(self) -> bool:
        """Check if the collector is currently running."""
        return self._running


class MetricsExporter:
    """HTTP server exposing Prometheus metrics.
    
    Provides /metrics endpoint in Prometheus text exposition format
    and /health endpoint for health checks.
    """
    
    def __init__(self, collector: MetricsCollector, config: MetricsConfig):
        """Initialize the metrics exporter.
        
        Args:
            collector: The metrics collector to get data from
            config: Metrics configuration
        """
        self._collector = collector
        self._config = config
        self._app: Optional[Any] = None
        self._runner: Optional[Any] = None
        self._site: Optional[Any] = None
    
    async def start(self) -> None:
        """Start the HTTP server."""
        try:
            from aiohttp import web
        except ImportError:
            logger.error("aiohttp is required for MetricsExporter. Install with: pip install aiohttp")
            return
        
        self._app = web.Application()
        self._app.router.add_get('/metrics', self.handle_metrics)
        self._app.router.add_get('/health', self.handle_health)
        
        self._runner = web.AppRunner(self._app)
        await self._runner.setup()
        
        self._site = web.TCPSite(
            self._runner,
            self._config.metrics_host,
            self._config.metrics_port
        )
        await self._site.start()
        
        logger.info(
            f"MetricsExporter started on {self._config.metrics_host}:{self._config.metrics_port}"
        )
    
    async def stop(self) -> None:
        """Stop the HTTP server."""
        if self._runner:
            await self._runner.cleanup()
            self._runner = None
            self._site = None
            self._app = None
        logger.info("MetricsExporter stopped")
    
    async def handle_metrics(self, request: Any) -> Any:
        """Handle GET /metrics - return Prometheus format."""
        from aiohttp import web
        
        metrics = self._collector.get_latest_metrics()
        if metrics is None:
            return web.Response(
                status=503,
                text="# No metrics available yet\n",
                content_type="text/plain"
            )
        
        output = self.format_prometheus(metrics)
        return web.Response(text=output, content_type="text/plain; charset=utf-8")
    
    async def handle_health(self, request: Any) -> Any:
        """Handle GET /health - return health status."""
        from aiohttp import web
        import json
        
        is_healthy = self._collector.is_running
        status = "healthy" if is_healthy else "unhealthy"
        
        return web.Response(
            status=200 if is_healthy else 503,
            text=json.dumps({"status": status}),
            content_type="application/json"
        )
    
    def format_prometheus(self, metrics: HostMetrics) -> str:
        """Format metrics as Prometheus text exposition.
        
        Args:
            metrics: The HostMetrics to format
            
        Returns:
            Prometheus-formatted metrics string
        """
        lines: List[str] = []
        
        # Common labels
        labels = self._format_labels({
            "host_id": self._config.host_id,
            "region": self._config.region,
            "environment": self._config.environment,
        })
        
        # Gauge metrics
        lines.append("# HELP firework_sandbox_active_count Number of active sandboxes")
        lines.append("# TYPE firework_sandbox_active_count gauge")
        lines.append(f"firework_sandbox_active_count{{{labels}}} {metrics.sandbox_active_count}")
        lines.append("")
        
        lines.append("# HELP firework_sandbox_capacity_total Maximum sandbox capacity")
        lines.append("# TYPE firework_sandbox_capacity_total gauge")
        lines.append(f"firework_sandbox_capacity_total{{{labels}}} {metrics.sandbox_capacity_total}")
        lines.append("")
        
        lines.append("# HELP firework_host_cpu_percent Host CPU utilization percentage")
        lines.append("# TYPE firework_host_cpu_percent gauge")
        lines.append(f"firework_host_cpu_percent{{{labels}}} {metrics.host_cpu_percent}")
        lines.append("")
        
        lines.append("# HELP firework_host_memory_percent Host memory utilization percentage")
        lines.append("# TYPE firework_host_memory_percent gauge")
        lines.append(f"firework_host_memory_percent{{{labels}}} {metrics.host_memory_percent}")
        lines.append("")
        
        lines.append("# HELP firework_capacity_score Available capacity score (0-1)")
        lines.append("# TYPE firework_capacity_score gauge")
        lines.append(f"firework_capacity_score{{{labels}}} {metrics.capacity_score}")
        lines.append("")
        
        # Histogram metrics - creation duration
        lines.extend(self._format_histogram(
            "firework_sandbox_creation_duration_seconds",
            "Sandbox creation duration",
            self._collector.creation_histogram,
            labels
        ))
        
        # Histogram metrics - command duration
        lines.extend(self._format_histogram(
            "firework_sandbox_command_duration_seconds",
            "Command execution duration",
            self._collector.command_histogram,
            labels
        ))
        
        return "\n".join(lines) + "\n"
    
    def _format_labels(self, label_dict: Dict[str, str]) -> str:
        """Format a dictionary as Prometheus labels."""
        parts = [f'{k}="{v}"' for k, v in label_dict.items()]
        return ",".join(parts)
    
    def _format_histogram(
        self,
        name: str,
        help_text: str,
        histogram: Histogram,
        labels: str
    ) -> List[str]:
        """Format a histogram in Prometheus format."""
        lines: List[str] = []
        
        lines.append(f"# HELP {name} {help_text}")
        lines.append(f"# TYPE {name} histogram")
        
        bucket_counts = histogram.get_bucket_counts()
        for bucket, count in bucket_counts.items():
            le = "+Inf" if bucket == float('inf') else str(bucket)
            lines.append(f'{name}_bucket{{{labels},le="{le}"}} {count}')
        
        lines.append(f"{name}_sum{{{labels}}} {histogram.sum}")
        lines.append(f"{name}_count{{{labels}}} {histogram.count}")
        lines.append("")
        
        return lines


@dataclass
class Alert:
    """Represents an alert condition detected by the Watchdog."""
    
    alert_type: str  # high_creation_latency, memory_pressure, capacity_exhausted, idle_sandbox
    severity: str    # warning, critical
    message: str
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


class Watchdog:
    """Monitors conditions and emits alerts.
    
    Checks for unhealthy conditions like memory pressure, capacity exhaustion,
    and idle sandboxes, emitting alerts when thresholds are exceeded.
    """
    
    def __init__(self, collector: MetricsCollector, config: MetricsConfig):
        """Initialize the watchdog.
        
        Args:
            collector: The metrics collector to get data from
            config: Metrics configuration with thresholds
        """
        self._collector = collector
        self._config = config
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._active_alerts: Dict[str, Alert] = {}
        self._alert_callbacks: List[Callable[[Alert], None]] = []
        self._sandboxes_for_cleanup: List[str] = []
    
    async def start(self) -> None:
        """Start the watchdog loop."""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._watchdog_loop())
        logger.info("Watchdog started")
    
    async def stop(self) -> None:
        """Stop the watchdog loop."""
        if not self._running:
            return
        
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("Watchdog stopped")
    
    async def _watchdog_loop(self) -> None:
        """Main watchdog loop."""
        while self._running:
            try:
                metrics = self._collector.get_latest_metrics()
                if metrics:
                    alerts = self.check_conditions(metrics)
                    self._process_alerts(alerts)
            except Exception as e:
                logger.error(f"Error in watchdog loop: {e}")
            
            await asyncio.sleep(self._config.collection_interval_seconds)
    
    def check_conditions(self, metrics: HostMetrics) -> List[Alert]:
        """Check all alert conditions against current metrics.
        
        Args:
            metrics: Current host metrics
            
        Returns:
            List of triggered alerts
        """
        alerts: List[Alert] = []
        now = datetime.now(timezone.utc)
        
        # Check memory pressure
        if metrics.host_memory_percent > self._config.memory_pressure_threshold * 100:
            alerts.append(Alert(
                alert_type="memory_pressure",
                severity="warning",
                message=f"Host memory utilization ({metrics.host_memory_percent:.1f}%) exceeds threshold ({self._config.memory_pressure_threshold * 100:.1f}%)",
                timestamp=now,
                metadata={"memory_percent": metrics.host_memory_percent}
            ))
        
        # Check capacity exhausted
        if metrics.sandbox_active_count == metrics.sandbox_capacity_total and metrics.sandbox_capacity_total > 0:
            alerts.append(Alert(
                alert_type="capacity_exhausted",
                severity="critical",
                message=f"Host has zero available capacity ({metrics.sandbox_active_count}/{metrics.sandbox_capacity_total} sandboxes)",
                timestamp=now,
                metadata={
                    "active_count": metrics.sandbox_active_count,
                    "capacity_total": metrics.sandbox_capacity_total
                }
            ))
        
        # Check idle sandboxes
        idle_timeout_seconds = self._config.idle_timeout_minutes * 60
        self._sandboxes_for_cleanup = []
        for sandbox in metrics.sandbox_metrics:
            if sandbox.idle_seconds > idle_timeout_seconds:
                self._sandboxes_for_cleanup.append(sandbox.sandbox_id)
                alerts.append(Alert(
                    alert_type="idle_sandbox",
                    severity="warning",
                    message=f"Sandbox {sandbox.sandbox_id} has been idle for {sandbox.idle_seconds / 60:.1f} minutes",
                    timestamp=now,
                    metadata={
                        "sandbox_id": sandbox.sandbox_id,
                        "idle_seconds": sandbox.idle_seconds
                    }
                ))
        
        return alerts
    
    def _process_alerts(self, new_alerts: List[Alert]) -> None:
        """Process new alerts and emit resolution events."""
        new_alert_types = {a.alert_type for a in new_alerts}
        
        # Check for resolved alerts
        for alert_type in list(self._active_alerts.keys()):
            if alert_type not in new_alert_types:
                # Alert condition has cleared
                resolved_alert = Alert(
                    alert_type=f"{alert_type}_resolved",
                    severity="info",
                    message=f"Alert condition '{alert_type}' has been resolved",
                    timestamp=datetime.now(timezone.utc),
                    metadata={"original_alert": alert_type}
                )
                self._emit_alert(resolved_alert)
                del self._active_alerts[alert_type]
        
        # Process new alerts
        for alert in new_alerts:
            if alert.alert_type not in self._active_alerts:
                self._active_alerts[alert.alert_type] = alert
                self._emit_alert(alert)
    
    def _emit_alert(self, alert: Alert) -> None:
        """Emit an alert to all registered callbacks."""
        logger.warning(f"Alert: {alert.alert_type} - {alert.message}")
        for callback in self._alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"Error in alert callback: {e}")
    
    def get_active_alerts(self) -> List[Alert]:
        """Get currently active alerts.
        
        Returns:
            List of currently active alerts
        """
        return list(self._active_alerts.values())
    
    def get_sandboxes_for_cleanup(self) -> List[str]:
        """Get sandbox IDs that should be cleaned up due to idle timeout.
        
        Returns:
            List of sandbox IDs marked for cleanup
        """
        return list(self._sandboxes_for_cleanup)
    
    def on_alert(self, callback: Callable[[Alert], None]) -> None:
        """Register a callback for alert events.
        
        Args:
            callback: Function to call when an alert is emitted
        """
        self._alert_callbacks.append(callback)


class CloudWatchPublisher:
    """Publishes metrics to AWS CloudWatch.
    
    Pushes capacity metrics and alarm signals to CloudWatch for ASG integration.
    """
    
    def __init__(self, collector: MetricsCollector, config: MetricsConfig):
        """Initialize the CloudWatch publisher.
        
        Args:
            collector: The metrics collector to get data from
            config: Metrics configuration
        """
        self._collector = collector
        self._config = config
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._client: Optional[Any] = None
    
    async def start(self) -> None:
        """Start the publish loop."""
        if self._running:
            return
        
        if not self._config.cloudwatch_enabled:
            logger.info("CloudWatch publishing is disabled")
            return
        
        try:
            import boto3
            self._client = boto3.client('cloudwatch')
        except ImportError:
            logger.error("boto3 is required for CloudWatchPublisher. Install with: pip install boto3")
            return
        except Exception as e:
            logger.error(f"Failed to create CloudWatch client: {e}")
            return
        
        self._running = True
        self._task = asyncio.create_task(self._publish_loop())
        logger.info(
            f"CloudWatchPublisher started with interval={self._config.cloudwatch_publish_interval_seconds}s"
        )
    
    async def stop(self) -> None:
        """Stop the publish loop."""
        if not self._running:
            return
        
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("CloudWatchPublisher stopped")
    
    async def _publish_loop(self) -> None:
        """Main publish loop."""
        while self._running:
            try:
                metrics = self._collector.get_latest_metrics()
                if metrics:
                    await self.publish(metrics)
            except Exception as e:
                logger.error(f"Error publishing to CloudWatch: {e}")
            
            await asyncio.sleep(self._config.cloudwatch_publish_interval_seconds)
    
    async def publish(self, metrics: HostMetrics) -> None:
        """Publish metrics to CloudWatch.
        
        Args:
            metrics: The HostMetrics to publish
        """
        if not self._client:
            return
        
        metric_data = self._build_metric_data(metrics)
        
        try:
            # Run boto3 call in executor to avoid blocking
            import asyncio
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self._client.put_metric_data(
                    Namespace='Firework/Sandbox',
                    MetricData=metric_data
                )
            )
            logger.debug(f"Published {len(metric_data)} metrics to CloudWatch")
        except Exception as e:
            logger.error(f"Failed to publish metrics to CloudWatch: {e}")
    
    def _build_metric_data(self, metrics: HostMetrics) -> List[Dict[str, Any]]:
        """Build CloudWatch metric data from HostMetrics.
        
        Args:
            metrics: The HostMetrics to convert
            
        Returns:
            List of CloudWatch metric data dictionaries
        """
        dimensions = [
            {'Name': 'HostId', 'Value': self._config.host_id or 'unknown'},
            {'Name': 'Environment', 'Value': self._config.environment},
        ]
        
        metric_data: List[Dict[str, Any]] = [
            {
                'MetricName': 'CapacityScore',
                'Dimensions': dimensions,
                'Value': metrics.capacity_score,
                'Unit': 'None'
            },
            {
                'MetricName': 'SandboxActiveCount',
                'Dimensions': dimensions,
                'Value': metrics.sandbox_active_count,
                'Unit': 'Count'
            },
            {
                'MetricName': 'SandboxCapacityTotal',
                'Dimensions': dimensions,
                'Value': metrics.sandbox_capacity_total,
                'Unit': 'Count'
            },
            {
                'MetricName': 'HostCpuPercent',
                'Dimensions': dimensions,
                'Value': metrics.host_cpu_percent,
                'Unit': 'Percent'
            },
            {
                'MetricName': 'HostMemoryPercent',
                'Dimensions': dimensions,
                'Value': metrics.host_memory_percent,
                'Unit': 'Percent'
            },
        ]
        
        # Add CapacityLow alarm metric
        capacity_low = 1 if metrics.capacity_score < self._config.capacity_low_threshold else 0
        metric_data.append({
            'MetricName': 'CapacityLow',
            'Dimensions': dimensions,
            'Value': capacity_low,
            'Unit': 'None'
        })
        
        return metric_data


class MetricsSystem:
    """Facade that coordinates all metrics components.
    
    Provides a unified interface for starting/stopping the metrics system
    and recording metrics from the Firework client.
    """
    
    def __init__(self, backend: "SandboxBackend", config: Optional[MetricsConfig] = None):
        """Initialize the metrics system.
        
        Args:
            backend: The sandbox backend to collect metrics from
            config: Optional metrics configuration (uses defaults if not provided)
        """
        self._config = config or MetricsConfig.from_env()
        self._collector = MetricsCollector(backend, self._config)
        self._exporter = MetricsExporter(self._collector, self._config)
        self._watchdog = Watchdog(self._collector, self._config)
        self._cloudwatch: Optional[CloudWatchPublisher] = None
        
        if self._config.cloudwatch_enabled:
            self._cloudwatch = CloudWatchPublisher(self._collector, self._config)
    
    @property
    def collector(self) -> MetricsCollector:
        """Get the metrics collector."""
        return self._collector
    
    @property
    def exporter(self) -> MetricsExporter:
        """Get the metrics exporter."""
        return self._exporter
    
    @property
    def watchdog(self) -> Watchdog:
        """Get the watchdog."""
        return self._watchdog
    
    @property
    def config(self) -> MetricsConfig:
        """Get the metrics configuration."""
        return self._config
    
    async def start(self) -> None:
        """Start all metrics components."""
        await self._collector.start()
        await self._exporter.start()
        await self._watchdog.start()
        
        if self._cloudwatch:
            await self._cloudwatch.start()
        
        logger.info("MetricsSystem started")
    
    async def stop(self) -> None:
        """Stop all metrics components."""
        if self._cloudwatch:
            await self._cloudwatch.stop()
        
        await self._watchdog.stop()
        await self._exporter.stop()
        await self._collector.stop()
        
        logger.info("MetricsSystem stopped")
    
    def record_creation(self, duration_seconds: float) -> None:
        """Record sandbox creation duration.
        
        Args:
            duration_seconds: Time taken to create the sandbox
        """
        self._collector.record_creation_duration(duration_seconds)
    
    def record_command(self, duration_seconds: float) -> None:
        """Record command execution duration.
        
        Args:
            duration_seconds: Time taken to execute the command
        """
        self._collector.record_command_duration(duration_seconds)
