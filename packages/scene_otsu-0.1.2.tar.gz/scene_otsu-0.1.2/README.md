# scene-otsu

A Python library for splitting SRT subtitle files into semantic scenes using the Otsu method with OpenAI embeddings.

## Installation

```bash
pip install scene-otsu
```

## Usage

### Basic Example

```python
from scene_otsu import SceneSplitter, SubtitleParser

# Initialize SceneSplitter
splitter = SceneSplitter(api_key="your-openai-api-key")

# Process SRT string
srt_content = """
1
00:00:00,000 --> 00:00:05,000
Hello world

2
00:00:05,000 --> 00:00:10,000
This is a test
"""

result = splitter.process(srt_content, max_tokens=200)
print(result)
```

### Parsing SRT with SubtitleParser

```python
from scene_otsu import SubtitleParser

# Parse SRT string
scenes = SubtitleParser.parse_srt_scenes(srt_content)
for scene in scenes:
    print(f"Time: {scene['start_time']} - {scene['end_time']}")
    print(f"Text: {scene['text']}")
```

### Converting Scenes to SRT Format

```python
from scene_otsu import scenes_to_srt_string

scenes = [
    {
        "start_time": "00:00:00,000",
        "end_time": "00:00:05,000",
        "subtitles": ["Hello world"]
    }
]

srt_string = scenes_to_srt_string(scenes)
print(srt_string)
```

## Features

- **SceneSplitter**: Recursive scene splitting using the Otsu method
  - Detects semantic boundaries using OpenAI embeddings
  - Automatic splitting based on token count limits
  - Force splitting for long texts

- **SubtitleParser**: Parsing and conversion of SRT subtitle files
  - Parsing SRT strings
  - Timestamp conversion
  - Conversion to scene-based dictionary format

- **OpenAIEmbedder**: Text embedding generation using OpenAI API
  - Efficient embedding generation with batch processing
  - Accurate token counting

## Dependencies

- numpy >= 2.0.0
- openai >= 2.6.1
- scikit-learn >= 1.7.2
- tiktoken >= 0.5.0
- tqdm >= 4.66.0

## License

MIT License
