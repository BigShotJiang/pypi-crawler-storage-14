import hashlib
import hmac
import os
import re
import time

from django.conf import settings

# Common compound file extensions that should be kept together
COMPOUND_EXTENSIONS = {
    '.tar.gz', '.tar.bz2', '.tar.xz',
    '.tar.zst', '.tar.lz', '.tar.lzma', '.tar.z'
}


def sanitize_file_extension(filename):
    """Sanitize file extension to ensure it's safe and consistent.

    Handles compound extensions like .tar.gz and sanitizes the extension
    by truncating at the first dangerous character.
    """
    # Convert to lowercase for consistency
    filename_lower = filename.lower()

    # Check for compound extensions first
    for compound_ext in COMPOUND_EXTENSIONS:
        if filename_lower.endswith(compound_ext):
            return compound_ext

    # Get extension using os.path.splitext (handles single extensions)
    _, ext = os.path.splitext(filename)

    if ext:
        # Convert to lowercase for consistency
        ext = ext.lower()

        # Truncate at first dangerous character instead of just removing them.
        # This is more secure: ".php%00" becomes ".php" not ".php00"
        # Only allow alphanumeric, dot, dash, and underscore
        match = re.match(r'^[a-z0-9._-]+', ext)
        if match:
            return match.group(0)

    return ""


def create_file_token(file_path, filename=None, timestamp=None):
    """Create a signed token for a file path with timestamp embedded.

    Args:
        file_path: Path to the file in storage
        filename: Optional original filename to bind to the token
        timestamp: Optional timestamp (defaults to current time)

    Returns:
        Token string in format: timestamp:signature
    """
    if timestamp is None:
        timestamp = int(time.time())

    # Include filename in payload if provided for additional security
    # This prevents users from swapping files by keeping path but changing filename
    if filename:
        payload = f"{file_path}:{filename}:{timestamp}"
    else:
        payload = f"{file_path}:{timestamp}"

    signature = hmac.new(
        settings.SECRET_KEY.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()

    # Return timestamp + signature (separated by ':')
    return f"{timestamp}:{signature}"


def verify_file_token(token, file_path, filename=None, max_age=None):
    """Verify a file token is valid and not expired.

    Args:
        token: Token to verify
        file_path: Path to the file in storage
        filename: Optional original filename that must match the token
        max_age: Maximum age in seconds (defaults to AJAX_FILEFIELD_TOKEN_MAX_AGE or 3600)

    Returns:
        True if token is valid, False otherwise
    """
    if max_age is None:
        max_age = getattr(settings, 'AJAX_FILEFIELD_TOKEN_MAX_AGE', 3600)

    if not token or ':' not in token:
        return False

    try:
        timestamp_str, signature = token.split(':', 1)
        timestamp = int(timestamp_str)
    except (ValueError, IndexError):
        return False

    # Check if expired
    if int(time.time()) - timestamp > max_age:
        return False

    # Verify signature with filename if provided
    if filename:
        payload = f"{file_path}:{filename}:{timestamp}"
    else:
        payload = f"{file_path}:{timestamp}"

    expected_signature = hmac.new(
        settings.SECRET_KEY.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()

    return hmac.compare_digest(signature, expected_signature)
