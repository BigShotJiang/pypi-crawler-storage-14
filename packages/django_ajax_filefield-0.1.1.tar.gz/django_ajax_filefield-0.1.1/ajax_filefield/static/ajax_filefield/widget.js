(function() {
    'use strict';

    // =========================================================================
    // Element Configuration
    // =========================================================================

    /**
     * Maps element names to their CSS classes.
     * Used for both caching and validation.
     */
    const ELEMENT_SELECTORS = {
        fileInput: { class: 'djaff-file-input', required: true },
        pathInput: { class: 'djaff-path-input', required: true },
        filenameInput: { class: 'djaff-filename-input', required: true },
        urlInput: { class: 'djaff-url-input', required: true },
        changedInput: { class: 'djaff-changed-input', required: true },
        tokenInput: { class: 'djaff-token-input', required: true },
        fileInfo: { class: 'djaff-file-info', required: true },
        chooseBtn: { class: 'djaff-choose-btn', required: true },
        clearBtn: { class: 'djaff-clear-btn', required: true },
        resetBtn: { class: 'djaff-reset-btn', required: false }, // Only exists if initial value
    };

    /**
     * AjaxFileFieldWidget - A clean, component-based file upload widget.
     *
     * Each widget instance manages:
     * - File selection and AJAX upload
     * - UI state (choose/clear/reset buttons, file info display)
     * - Hidden form inputs (path, filename, url, changed, token)
     * - Progress indication during upload
     * - Reset to initial value functionality
     */
    class AjaxFileFieldWidget {
        /**
         * @param {HTMLElement} container - The widget container element
         */
        constructor(container) {
            this.container = container;
            this._initElements();
        }

        // =====================================================================
        // Initialization
        // =====================================================================

        _initElements() {
            this.elements = {};

            for (const [name, config] of Object.entries(ELEMENT_SELECTORS)) {
                const element = this.container.querySelector(`.${config.class}`);

                if (!element && config.required) {
                    throw new Error(`Cannot find element with ${config.class} class`);
                }

                this.elements[name] = element;
            }
        }

        // =====================================================================
        // State Management
        // =====================================================================

        get hasInitialValue() {
            return Boolean(this.elements.fileInput.dataset.initialValue);
        }

        get initialValue() {
            return this.elements.fileInput.dataset.initialValue || '';
        }

        get initialFilename() {
            return this.elements.fileInput.dataset.initialFilename || '';
        }

        get initialUrl() {
            return this.elements.fileInput.dataset.initialUrl || '';
        }

        get uploadUrl() {
            const url = this.elements.fileInput.dataset.uploadUrl;
            if (!url) {
                throw new Error('Upload URL not found on file input element');
            }
            return url;
        }

        // =====================================================================
        // Translatable Messages
        // =====================================================================

        get errorMessages() {
            const dataset = this.elements.fileInput.dataset;
            return {
                invalidResponse: dataset.errorInvalidResponse || 'Invalid server response. Please try uploading again.',
                network: dataset.errorNetwork || 'Network error during upload. Please try uploading again.',
                unknown: dataset.errorUnknown || 'An unknown error occurred. Please try uploading again.',
            };
        }

        /**
         * Update all hidden form inputs atomically.
         * @param {Object} values - Object with path, filename, changed (required) and url, token (optional)
         */
        _updateFormInputs({ path, filename, changed, url = '', token = '' }) {
            if (path === undefined || filename === undefined || changed === undefined) {
                throw new Error('updateFormInputs requires path, filename, and changed properties');
            }

            this.elements.pathInput.value = path;
            this.elements.filenameInput.value = filename;
            this.elements.urlInput.value = url;
            this.elements.changedInput.value = changed;
            this.elements.tokenInput.value = token;
        }

        // =====================================================================
        // UI Helpers
        // =====================================================================

        _hide(element) {
            if (element) element.classList.add('djaff-hidden');
        }

        _show(element) {
            if (element) element.classList.remove('djaff-hidden');
        }

        _isHidden(element) {
            return element?.classList.contains('djaff-hidden');
        }

        _updateFileInfoDisplay(filename, url) {
            const link = this.elements.fileInfo.querySelector('a');
            if (link) {
                link.href = url;
                link.textContent = filename;
            }
        }

        /**
         * Transition to "empty" state - no file selected.
         */
        _showEmptyState() {
            this._hide(this.elements.fileInfo);
            this._show(this.elements.chooseBtn);
            this._hide(this.elements.clearBtn);
        }

        /**
         * Transition to "has file" state - file is selected/uploaded.
         */
        _showFileState() {
            this._show(this.elements.fileInfo);
            this._hide(this.elements.chooseBtn);
            this._show(this.elements.clearBtn);
        }

        // =====================================================================
        // Button Handlers
        // =====================================================================

        handleChooseClick() {
            const testMode = window.__DJAFF_TEST_MODE__;
            if (testMode?.onChooseClick) {
                testMode.onChooseClick(this.elements.fileInput);
            } else {
                this.elements.fileInput.click();
            }
        }

        handleClearClick() {
            // Changed flag depends on whether we had an initial value
            // With initial: clearing is a change (true)
            // Without initial: clearing returns to initial empty state (false)
            const changedFlag = this.hasInitialValue ? 'true' : 'false';

            this._updateFormInputs({
                path: '',
                filename: '',
                url: '',
                token: '',
                changed: changedFlag,
            });

            this._updateFileInfoDisplay('', '');
            this._showEmptyState();

            // Show reset button if we can reset to initial
            if (this.elements.resetBtn && this.hasInitialValue) {
                this._show(this.elements.resetBtn);
            }
        }

        handleResetClick() {
            if (!this.hasInitialValue) return;

            this._updateFormInputs({
                path: this.initialValue,
                filename: this.initialFilename,
                url: this.initialUrl,
                token: '',
                changed: 'false',
            });

            this._updateFileInfoDisplay(this.initialFilename, this.initialUrl);
            this._showFileState();
            this._hide(this.elements.resetBtn);
        }

        // =====================================================================
        // File Upload
        // =====================================================================

        handleFileChange(file) {
            // Clear transient file input immediately
            this.elements.fileInput.value = '';

            const upload = new FileUpload(this, file);
            upload.start();
        }
    }

    /**
     * FileUpload - Handles a single file upload operation.
     *
     * Manages:
     * - XHR upload with progress tracking
     * - UI state during upload (disabled buttons, progress text)
     * - Success/error handling
     * - ARIA attributes for accessibility
     */
    class FileUpload {
        constructor(widget, file) {
            this.widget = widget;
            this.file = file;
            this.xhr = new XMLHttpRequest();
            this.shouldShowResetBtn = widget.elements.resetBtn && widget._isHidden(widget.elements.resetBtn);
        }

        start() {
            this._setupXhrHandlers();
            this._enterUploadState();
            this._showProgress(0);
            this._notifyTestMode('start');
            this._sendRequest();
        }

        // =====================================================================
        // XHR Setup
        // =====================================================================

        _setupXhrHandlers() {
            this.xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    this._showProgress(percent);
                }
            });

            this.xhr.addEventListener('load', () => this._handleLoad());
            this.xhr.addEventListener('error', () => this._handleNetworkError());
        }

        _sendRequest() {
            const formData = new FormData();
            formData.append('file', this.file);
            formData.append('csrfmiddlewaretoken', getCookie('csrftoken'));

            this.xhr.open('POST', this.widget.uploadUrl);
            this.xhr.send(formData);
        }

        // =====================================================================
        // Upload State Management
        // =====================================================================

        _enterUploadState() {
            const { chooseBtn, clearBtn, resetBtn } = this.widget.elements;

            chooseBtn.disabled = true;
            chooseBtn.setAttribute('aria-busy', 'true');
            chooseBtn.setAttribute('aria-live', 'polite');

            clearBtn.disabled = true;

            if (resetBtn) {
                resetBtn.disabled = true;
                this.widget._hide(resetBtn);
            }
        }

        _exitUploadState() {
            const { chooseBtn, clearBtn, resetBtn } = this.widget.elements;

            chooseBtn.disabled = false;
            chooseBtn.removeAttribute('aria-busy');
            chooseBtn.removeAttribute('aria-live');
            chooseBtn.removeAttribute('aria-valuenow');
            chooseBtn.removeAttribute('aria-valuemin');
            chooseBtn.removeAttribute('aria-valuemax');

            clearBtn.disabled = false;

            if (resetBtn) {
                resetBtn.disabled = false;
            }

            if (this.shouldShowResetBtn) {
                this.widget._show(this.widget.elements.resetBtn);
            }
        }

        _showProgress(percent) {
            const { chooseBtn } = this.widget.elements;

            if (percent < 100) {
                const uploadingText = chooseBtn.dataset.uploadingLabel;
                chooseBtn.textContent = `${uploadingText} ${percent}%`;
                chooseBtn.setAttribute('aria-valuenow', percent);
                chooseBtn.setAttribute('aria-valuemin', '0');
                chooseBtn.setAttribute('aria-valuemax', '100');
            } else {
                chooseBtn.textContent = chooseBtn.dataset.chooseLabel;
            }
        }

        // =====================================================================
        // Response Handling
        // =====================================================================

        _handleLoad() {
            const testMode = window.__DJAFF_TEST_MODE__;

            const complete = () => {
                if (this.xhr.status === 200) {
                    this._handleSuccess();
                } else {
                    this._handleErrorResponse();
                }
            };

            // Support artificial delay for testing progress visibility
            if (testMode?.uploadDelay) {
                setTimeout(complete, testMode.uploadDelay);
            } else {
                complete();
            }
        }

        _handleSuccess() {
            let response;
            try {
                response = JSON.parse(this.xhr.responseText);
                if (!response || response.success !== true) {
                    throw new Error('Invalid server response');
                }
            } catch (e) {
                this._showError([{ message: this.widget.errorMessages.invalidResponse }]);
                return;
            }

            this.widget._updateFormInputs({
                path: response.tmp_path,
                filename: response.original_filename,
                url: response.tmp_file_url,
                token: response.token,
                changed: 'true',
            });

            this.widget._updateFileInfoDisplay(response.original_filename, response.tmp_file_url);
            this.widget._showFileState();

            if (this.widget.elements.resetBtn && this.widget.hasInitialValue) {
                this.widget._show(this.widget.elements.resetBtn);
            }

            this._showProgress(100);
            this._exitUploadState();
            this._notifyTestMode('success');
        }

        _handleErrorResponse() {
            try {
                const response = JSON.parse(this.xhr.responseText);
                if (!response || response.success !== false || !Array.isArray(response.errors)) {
                    throw new Error('Invalid error response format');
                }
                this._showError(response.errors);
            } catch (e) {
                this._showError([{ message: this.widget.errorMessages.invalidResponse }]);
            }
        }

        _handleNetworkError() {
            this._showError([{ message: this.widget.errorMessages.network }]);
        }

        _showError(errors) {
            let message;

            if (errors.length === 1) {
                message = errors[0].message;
            } else if (errors.length > 1) {
                message = errors.map((error) => `- ${error.message}`).join('\n');
            } else {
                message = this.widget.errorMessages.unknown;
            }

            alert(message);
            this._exitUploadState();
            this._notifyTestMode('error', errors);
        }

        // =====================================================================
        // Test Mode Support
        // =====================================================================

        _notifyTestMode(event, data = null) {
            const testMode = window.__DJAFF_TEST_MODE__;
            if (!testMode) return;

            switch (event) {
                case 'start':
                    testMode.onUploadStart?.();
                    break;
                case 'success':
                    testMode.onUploadEnd?.({ success: true });
                    break;
                case 'error':
                    testMode.onUploadEnd?.({ success: false, errors: data });
                    break;
            }
        }
    }

    // =========================================================================
    // Widget Registry
    // =========================================================================

    const widgetRegistry = new WeakMap();

    function getWidget(element) {
        const container = element.parentElement;

        if (!widgetRegistry.has(container)) {
            widgetRegistry.set(container, new AjaxFileFieldWidget(container));
        }

        return widgetRegistry.get(container);
    }

    // =========================================================================
    // Event Delegation
    // =========================================================================

    document.addEventListener('click', (e) => {
        const target = e.target;

        if (target.classList.contains('djaff-choose-btn')) {
            getWidget(target).handleChooseClick();
        } else if (target.classList.contains('djaff-clear-btn')) {
            getWidget(target).handleClearClick();
        } else if (target.classList.contains('djaff-reset-btn')) {
            getWidget(target).handleResetClick();
        }
    });

    document.addEventListener('change', (e) => {
        if (e.target.classList.contains('djaff-file-input')) {
            const file = e.target.files[0];
            if (file) {
                getWidget(e.target).handleFileChange(file);
            }
        }
    });

    // =========================================================================
    // Utilities
    // =========================================================================

    function getCookie(name) {
        if (!document.cookie) return null;

        const cookies = document.cookie.split(';');
        for (const cookie of cookies) {
            const trimmed = cookie.trim();
            if (trimmed.startsWith(name + '=')) {
                return decodeURIComponent(trimmed.substring(name.length + 1));
            }
        }
        return null;
    }

})();
