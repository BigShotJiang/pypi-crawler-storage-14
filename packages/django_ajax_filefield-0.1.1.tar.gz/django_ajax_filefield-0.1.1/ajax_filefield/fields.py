import logging
import mimetypes
from os.path import basename

from django.conf import settings
from django.core import validators
from django.core.exceptions import SuspiciousFileOperation, ValidationError
from django.core.files import File
from django.forms.fields import Field
from django.forms.widgets import FileInput
from django.urls import resolve, reverse
from django.urls.exceptions import NoReverseMatch, Resolver404
from django.utils.translation import gettext_lazy as _
from django.utils.translation import ngettext_lazy

from .utils import verify_file_token
from .widgets import AjaxFileInput

logger = logging.getLogger(__name__)


def _normalize_value(value, initial=None):
    """
    Normalize any value type into the canonical dict format.

    This is THE single source of truth for the data structure used throughout
    the field/widget system. All values flow through this normalization to ensure
    consistency.

    Canonical format:
    {
        "current": {
            "path": str,      # Path in storage (empty if none)
            "filename": str,  # Display filename (empty if none)
            "url": str,       # URL to access file (empty if none)
            "token": str,     # Security token (empty if none)
        },
        "initial": {
            "path": str,      # Initial DB file path (empty if none)
            "filename": str,  # Initial DB filename (empty if none)
            "url": str,       # Initial DB file URL (empty if none)
        },
        "changed": bool,      # True if current != initial
        "has_current": bool,  # True if a file is being presented (either an initial or a submitted file)
        "has_initial": bool,  # True if initial file exists in the database
    }

    Args:
        value: Can be None, dict, FieldFile, or any object with .name/.url
        initial: Optional FieldFile from DB (for preserving reset functionality)

    Returns:
        Normalized dict with all keys present and consistent types
    """
    # Start with empty structure
    result = {
        "current": {
            "path": "",
            "filename": "",
            "url": "",
            "token": "",
        },
        "initial": {
            "path": "",
            "filename": "",
            "url": "",
        },
        "changed": False,
        "has_current": False,
        "has_initial": False,
    }

    # Process initial (DB) value if provided
    if initial and hasattr(initial, 'name') and hasattr(initial, 'url'):
        result["initial"]["path"] = initial.name or ""
        result["initial"]["filename"] = basename(initial.name) if initial.name else ""
        result["initial"]["url"] = initial.url or ""
        result["has_initial"] = bool(initial.name)

    # Process the main value
    if value is None or value == "":
        # Empty value - structure already correct
        pass

    elif isinstance(value, dict):
        # Already a dict - could be from value_from_datadict, prepare_value, or bound_data
        # Extract current file info (handle multiple possible key names for compatibility)
        current_path = value.get("path") or value.get("current", {}).get("path", "")
        current_filename = value.get("filename") or value.get("current", {}).get("filename", "")
        current_url = value.get("url") or value.get("file_url") or value.get("current", {}).get("url", "")
        current_token = value.get("token") or value.get("current", {}).get("token", "")

        result["current"]["path"] = current_path
        result["current"]["filename"] = current_filename
        result["current"]["url"] = current_url
        result["current"]["token"] = current_token
        result["has_current"] = bool(current_path)
        result["changed"] = bool(value.get("changed", False))

    elif hasattr(value, 'name') and hasattr(value, 'url'):
        # FieldFile from DB - treat as current value
        result["current"]["path"] = value.name or ""
        result["current"]["filename"] = basename(value.name) if value.name else ""
        result["current"]["url"] = value.url or ""
        result["has_current"] = bool(value.name)
        # If this is a FieldFile and no separate initial was provided, it IS the initial
        if not result["has_initial"]:
            result["initial"]["path"] = value.name or ""
            result["initial"]["filename"] = basename(value.name) if value.name else ""
            result["initial"]["url"] = value.url or ""
            result["has_initial"] = bool(value.name)

    return result


class AjaxFileField(Field):
    widget = AjaxFileInput
    upload_view_name = None
    default_error_messages = {
        "invalid": _("No file was submitted. Check the encoding type on the form."),
        "missing": _("No file was submitted."),
        "empty": _("The submitted file is empty."),
        "max_length": ngettext_lazy(
            "Ensure this filename has at most %(max)d character (it has %(length)d).",
            "Ensure this filename has at most %(max)d characters (it has %(length)d).",
            "max",
        ),
        "invalid_token": _("Invalid or expired file token. Please re-upload the file."),
        "file_access_error": _("Could not access the uploaded file. Please try uploading again."),
    }

    def __init__(self, *, upload_view_name=None, max_length=None, allow_empty_file=False, **kwargs):
        self.max_length = max_length
        self.allow_empty_file = allow_empty_file

        # Override class level upload_view_name if provided.
        # AjaxFileField.upload_view_name is None but a field subclass might set it.
        if upload_view_name is not None:
            self.upload_view_name = upload_view_name

        # If no upload_view_name set, try to get from settings
        if self.upload_view_name is None:
            self.upload_view_name = upload_view_name or getattr(settings, 'AJAX_FILEFIELD_DEFAULT_UPLOAD_VIEW_NAME', None)

        # No upload_view_name configured, raise error
        if self.upload_view_name is None:
            raise ValueError("AjaxFileField requires upload_view_name to be specified either "
                             "in the field or in AJAX_FILEFIELD_DEFAULT_UPLOAD_VIEW_NAME setting.")

        super().__init__(**kwargs)

        # Patch the widget instance with the upload view name
        self.widget.upload_view_name = self.upload_view_name

    def get_upload_view_storage(self):
        """Get the storage backend from the associated upload view."""

        # Get the URL for the view
        try:
            resolved = resolve(reverse(self.upload_view_name))
        except (NoReverseMatch, Resolver404) as e:
            raise ValueError(f"Cannot reverse URL for view name: {self.upload_view_name}") from e

        view_func = resolved.func
        view_class = view_func.view_class
        view_initkwargs = view_func.view_initkwargs

        # Create a temporary instance to get the storage
        # We need to pass the kwargs that were used when creating the view
        temp_instance = view_class(**view_initkwargs)

        return temp_instance.storage

    def _create_file_from_storage(self, file_path, original_name):
        """
        Create a File object that streams from the storage backend.

        Instead of loading the entire file into memory, this returns a Django File
        object that wraps the storage file handle, allowing efficient streaming
        for large files and remote storage backends (S3, Azure, etc.).

        Args:
            file_path: Path to the file in storage
            original_name: Original filename from the upload

        Returns:
            Django File instance that streams from storage

        Raises:
            ValidationError: If the file cannot be accessed from storage
        """
        storage = self.get_upload_view_storage()

        try:
            # Open the file from storage (returns a file-like object that supports streaming)
            file_obj = storage.open(file_path, mode='rb')

            # Get file size from storage
            file_size = storage.size(file_path)

            # Use original filename if available, otherwise extract from path
            filename = original_name or basename(file_path)

            # Guess content type from filename
            content_type = mimetypes.guess_type(filename)[0]

            # Wrap the storage file in Django's File class
            # This provides a consistent interface while maintaining streaming behavior
            file_wrapper = File(file_obj, name=filename)

            # Add metadata attributes that Django expects
            file_wrapper.content_type = content_type
            file_wrapper.size = file_size

            return file_wrapper

        except (OSError, SuspiciousFileOperation) as e:
            logger.error(
                "Failed to access uploaded file from storage: %s (file_path=%s)",
                str(e),
                file_path,
                exc_info=True
            )

            raise ValidationError(
                self.error_messages["file_access_error"],
                code="file_access_error",
            ) from e

    def to_python(self, data):
        """
        Convert normalized dict to a File object for validation/saving.

        Expects data in our normalized dict format. Returns None for empty/unchanged
        files, or a File object for new uploads.

        This is the AjaxFileField's to_python - it works with our normalized format.
        """
        if data in self.empty_values:
            return None

        # Data must be in our normalized format (from _normalize_value)
        # Validate that data is a dict with the expected structure
        if not isinstance(data, dict) or "has_current" not in data:
            raise ValidationError(
                self.error_messages["invalid"],
                code="invalid"
            )

        # If file hasn't changed, return None (Django will preserve the original)
        if not data["changed"]:
            return None

        # Extract current file info
        file_path = data["current"]["path"]
        filename = data["current"]["filename"]
        token = data["current"]["token"]

        # Verify the file token for security
        if not verify_file_token(token, file_path, filename=filename):
            raise ValidationError(
                self.error_messages["invalid_token"],
                code="invalid_token"
            )

        # Create file object from storage
        return self._create_file_from_storage(file_path, filename)

    def clean(self, data, initial=None):
        """
        Validate and clean the field data.

        This is where we bridge between our normalized format and Django's FileField.
        We handle our custom logic, then convert to a File object before calling
        Django's Field.clean() (NOT FileField.clean).

        Handles three cases:
        1. Empty (no file) - return None or False, or raise if required
        2. Unchanged (preserving DB file) - return initial
        3. Changed (new upload) - convert to File and validate with parent Field.clean()

        Note: data is already normalized by _clean_bound_field() or prepare_value().
        """
        # If data is already a file object (e.g., from disabled field), return as-is
        if hasattr(data, 'read') or hasattr(data, 'url'):
            return data

        # Case 1: File exists but unchanged (preserve initial DB file)
        if not data["changed"] and data["has_initial"]:
            return initial

        # Case 2: No current file (empty field)
        if not data["has_current"]:
            if not self.required:
                # Optional field - return False if clearing, None if empty
                return False if data["has_initial"] else None
            # Required field - let parent validate to trigger error
            # Convert our format to what parent expects (None for empty)
            return super().clean(None)

        # Case 3: File changed (new upload)
        # Use our to_python to convert normalized dict -> File object
        file_obj = self.to_python(data)

        # Validate and run validators on the File object
        self.validate(file_obj)
        self.run_validators(file_obj)

        return file_obj

    def prepare_value(self, value):
        """
        Prepare value for rendering in the widget.

        For bound forms (re-render after error): receives the output from bound_data().
        For unbound forms: receives FieldFile from DB, needs normalization.
        """
        # If we receive a dict, that's the output from bound_data(), we can just return it.
        if isinstance(value, dict):
            return value
        # Otherwise, it's the unbound case - normalize the FieldFile from DB.
        return _normalize_value(value)

    def bound_data(self, data, initial):
        """
        Return the value for bound forms (POST submissions).

        Normalizes the POST data and preserves initial DB value for reset functionality.
        """
        if self.disabled:
            return initial

        # Normalize both data and initial into canonical format
        return _normalize_value(data, initial=initial)

    def has_changed(self, initial, data):
        """
        Check if the field value has changed.

        Uses the 'changed' flag from normalized data structure.

        Note: data is already normalized by bound_data().
        The initial parameter is required by Django's signature but not used
        because the changed flag is already computed during normalization.
        """
        if self.disabled:
            return False

        # Data is already normalized - trust it
        return data["changed"]

    def _clean_bound_field(self, bf):
        """
        Override to normalize data before passing to clean().

        bf.data returns raw data from value_from_datadict() which is a flat dict.
        We need to normalize it before clean() can use it.
        """
        if self.disabled:
            value = bf.initial
        else:
            # bf.data is the flat dict from value_from_datadict()
            # Normalize it to canonical format
            value = _normalize_value(bf.data, initial=bf.initial)

        return self.clean(value, bf.initial)


class AjaxImageField(AjaxFileField):
    default_validators = [validators.validate_image_file_extension]
    default_error_messages = {
        "invalid_image": _(
            "Upload a valid image. The file you uploaded was either not an "
            "image or a corrupted image."
        ),
    }

    def to_python(self, data):
        """
        Check that the file-upload field data contains a valid image (GIF, JPG,
        PNG, etc. -- whatever Pillow supports).
        """
        f = super().to_python(data)
        if f is None:
            return None

        from PIL import Image

        try:
            # Pass the File object from our AjaxFileField.to_python() directly
            # to Pillow Image.open().
            image = Image.open(f)
            # verify() must be called immediately after the constructor.
            # with verify() only reads the header, avoiding DoS vector.
            image.verify()

            # Annotating so subclasses can reuse it for their own validation
            f.image = image
            # Pillow doesn't detect the MIME type of all formats. In those
            # cases, content_type will be None.
            f.content_type = Image.MIME.get(image.format)
        except Exception as exc:
            # Pillow doesn't recognize it as an image.
            raise ValidationError(
                self.error_messages["invalid_image"],
                code="invalid_image",
            ) from exc
        if hasattr(f, "seek") and callable(f.seek):
            f.seek(0)
        return f

    def widget_attrs(self, widget):
        attrs = super().widget_attrs(widget)
        if isinstance(widget, FileInput) and "accept" not in widget.attrs:
            attrs.setdefault("accept", "image/*")
        return attrs
