"""
Module to handle time intervals built by a
't_start' and 't_end' time moment, including
the first one and not the second one.
"""
"""
TODO: This module is general so we should send it
to another library related to time intervals and
not specifically video frame times... Move it.
"""
from yta_time_interval.decorators import parameter_to_time_interval
from yta_validation.parameter import ParameterValidator
from yta_programming_dependencies import Dependency
from quicktions import Fraction
from typing import Union


Number = Union[int, float, Fraction]
"""
Custom type to represent numbers.
"""
TimeIntervalType = Union['TimeInterval', tuple[float, float]]
"""
The type we accept as time interval, that could be a
tuple we transform into a time interval.
"""
TIME_INTERVAL_SYSTEM_LIMITS = (0, 9999)
"""
The limits for the `t_start` and `t_end` fields of any
time interval that the system will apply if no limits
are requested by the user.

The limits are `0` and `9999`.
"""

class TimeInterval:
    """
    *Using the `fps` parameter needs the optional library
    `yta_video_frame_time` installed.*

    A time interval that has a memory of the original values
    but can be modified and enshorted during its life time.

    Class to represent a time interval, which is a tuple
    of time moments representing the time range 
    `[t_start, t_end)`.

    Using the `fps` parameter allows you to have exact time
    moments multiples of `1/fps`.
    """

    @property
    def head(
        self
    ) -> Fraction:
        """
        The time remaining at the begining of this
        interval, which is the difference between
        the current `t_start` moment and the 
        `t_start_limit` of this time interval.

        This value can be useful for transitions.

        The formula:
        - `self.t_start - self.t_start_limit`
        """
        return self.t_start - self.t_start_limit
    
    @property
    def tail(
        self
    ) -> Fraction:
        """
        The time remaining at the t_end of this interval,
        which is the difference between the `t_end_limit`
        and the current `t_end` time moment of this
        time interval.

        This value can be useful for transitions.

        The formula:
        - `self.t_end_limit - self.t_end`
        """
        return self.t_end_limit - self.t_end

    @property
    def duration(
        self
    ) -> float:
        """
        The `duration` of the time interval.
        """
        return self.t_end - self.t_start

    @property
    def copy(
        self
    ) -> 'TimeInterval':
        """
        A copy of this instance.
        """
        time_interval = TimeInterval(
            t_start = self.t_start,
            t_end = self.t_end,
            t_start_limit = self.t_start_limit,
            t_end_limit = self.t_end_limit,
            fps = self.fps
        )

        return time_interval
    
    @property
    def as_tuple(
        self
    ) -> tuple[float, float]:
        """
        The time interval but as a `(t_start, t_end)` tuple.
        """
        return (self.t_start, self.t_end)
    
    @property
    def _cutter(
        self
    ) -> 'TimeIntervalCutter':
        """
        Shortcut to the static class `TimeIntervalCutter` that
        is capable of cutting time intervals.
        """
        return TimeIntervalCutter
    
    @property
    def _extender(
        self
    ) -> 'TimeIntervalExtender':
        """
        Shortcut to the static class `TimeIntervalExtender` that
        is capable of extending time intervals.
        """
        return TimeIntervalExtender
    
    @property
    def _utils(
        self
    ) -> 'TimeIntervalUtils':
        """
        Shortcut to the static class `TimeIntervalUtils` that
        is capable of extending time intervals.
        """
        return TimeIntervalUtils

    def __init__(
        self,
        t_start: Number,
        t_end: Number,
        t_start_limit: Union[Number, None] = None,
        t_end_limit: Union[Number, None] = None,
        duration_limit: Union[Number, None] = None,
        fps: Union[Number, None] = None
    ):
        """
        The `t_end` value must be greater than the `t_start` value.

        (!) If `fps` is provided, the `t_start`, `t_end`, `t_start_limit`
        and `t_end_limit` values will be truncated according to the
        `fps` provided.

        (!) If no `t_start_limit` and/or no `t_end_limit` values are
        provided, the ones from the system will be applied.
        """
        ParameterValidator.validate_positive_number('fps', fps, do_include_zero = False)
        ParameterValidator.validate_mandatory_positive_number('t_start', t_start, do_include_zero = True)
        ParameterValidator.validate_mandatory_positive_number('t_end', t_end, do_include_zero = False)
        ParameterValidator.validate_positive_number('t_start_limit', t_start_limit, do_include_zero = True)
        ParameterValidator.validate_positive_number('t_end_limit', t_end_limit, do_include_zero = False)
        ParameterValidator.validate_positive_number('duration_limit', t_end_limit, do_include_zero = False)

        self.fps: Union[Number, None] = fps
        """
        The `fps` for this time interval calculations, if set.
        """

        self._t_handler: Union[THandler, None] = None
        """
        *For internal use only*

        Shortcut to the `THandler` instance built with the `fps`
        value provided when instantiating this instance, that
        can be `None` if no `fps` are provided.

        This functionality requires the `yta_video_frame_time`
        optional library installed to work.
        """

        if fps is not None:
            if not Dependency.is_installed('yta_video_frame_time'):
                raise Exception('Using the "fps" parameter within the TimeInterval class needs the "yta_video_frame_time" optional library installed. You can install it with this command: pip install yta_time_interval[yta_video_frame_time]')
            
            from yta_video_frame_time.t_fraction import THandler

            self._t_handler: Union[THandler, None] = THandler(self.fps)

        t_start_limit = self._truncate(
            TIME_INTERVAL_SYSTEM_LIMITS[0]
            if t_start_limit is None else
            t_start_limit
        )

        t_end_limit = self._truncate(
            TIME_INTERVAL_SYSTEM_LIMITS[1]
            if t_end_limit is None else
            t_end_limit
        )

        duration_limit = self._truncate(
            TIME_INTERVAL_SYSTEM_LIMITS[1]
            if duration_limit is None else
            duration_limit
        )

        if t_start_limit < TIME_INTERVAL_SYSTEM_LIMITS[0]:
            raise Exception(f'The "t_start_limit={str(float(t_start_limit))}" is lower than the system limit ({str(float(TIME_INTERVAL_SYSTEM_LIMITS[0]))})')
        
        if t_end_limit > TIME_INTERVAL_SYSTEM_LIMITS[1]:
            raise Exception(f'The "t_end_limit={str(float(t_end_limit))}" is greater than the system limit ({str(float(TIME_INTERVAL_SYSTEM_LIMITS[1]))})')
        
        if duration_limit > TIME_INTERVAL_SYSTEM_LIMITS[1]:
            raise Exception(f'The "duration_limit={str(float(duration_limit))}" is greater than the system limit ({str(float(TIME_INTERVAL_SYSTEM_LIMITS[1]))})')
        
        if t_end_limit <= t_start_limit:
            raise Exception(f'The "t_end_limit={str(float(t_end_limit))}" is smaller than the "t_start_limit={str(float(t_start_limit))}"')
        
        self.t_start_limit: Fraction = t_start_limit
        """
        The limit for the `t_start` of this time interval, which
        will be used to raise exceptions if any of the `t_start`
        values goes beyond this limit.

        See the `TIME_INTERVAL_SYSTEM_LIMITS[0]` variable to
        know the limit defined by the system that will be
        applied if the user doesn't provided his own limit.
        """
        self.t_end_limit: Fraction = t_end_limit
        """
        The limit for the `t_end` of this time interval, which
        will be used to raise exceptions if any of the `t_end`
        values goes beyond this limit.

        See the `TIME_INTERVAL_SYSTEM_LIMITS[1]` variable to
        know the limit defined by the system that will be
        applied if the user doesn't provided his own limit.
        """
        self.duration_limit: Fraction = duration_limit
        """
        The limit for the `duration` of this time interval,
        which will be used to raise exceptions if this
        duration is exceeded when modifying the `t_start` and/or
        `t_end` values of this time interval.

        See the `TIME_INTERVAL_SYSTEM_LIMITS[1]` variable to
        know the limit defined by the system that will be
        applied if the user doesn't provided his own limit.
        """

        self.t_start: Fraction = self._truncate(t_start)
        """
        The current `t_start` value of this time interval.
        """
        self.t_end: Fraction = self._truncate(t_end)
        """
        The current `t_end` value of this time interval.
        """

        self._validate_start()
        self._validate_end()
        self._validate_duration()

        self._t_original_start: Fraction = self.t_start
        """
        *For internal use only*
        
        The `t_start` used when creating the instance.
        """
        self._t_original_end: Fraction = self.t_end
        """
        *For internal use only*
        
        The `t_end` used when creating the instance.
        """

    def _validate_start(
        self,
        t_start: Union[Number, None] = None,
        t_end: Union[Number, None] = None,
        t_start_limit: Union[Number, None] = None
    ) -> None:
        """
        *For internal use only*

        Validate that the `t_start` value provided is accepted by the
        time interval and the system based on the limits and the
        value of the `t_end` parameter also.

        This method will validate if the `t_start` is lower than the
        `t_end` parameter provided (or the current `self.t_end` if None)
        and also lower than the `t_start_limit` provided (or the 
        current `self.t_start_limit` if None).

        This method will raise an exception if the provided value is
        not valid.
        """
        t_start = (
            self.t_start
            if t_start is None else
            t_start
        )

        t_end = (
            self.t_end
            if t_end is None else
            t_end
        )

        t_start_limit = (
            self.t_start_limit
            if t_start_limit is None else
            t_start_limit
        )

        if t_start >= t_end:
            raise Exception(f'The "t_start={str(float(t_start))}" is greater or equal to the current "t_end={str(float(t_end))}".')
        
        if t_start < t_start_limit:
            raise Exception(f'The "t_start={str(float(t_start))}" is lower than the "t_start_limit={str(float(t_start_limit))}".')
        
    def _validate_end(
        self,
        t_end: Union[Number, None] = None,
        t_start: Union[Number, None] = None,
        t_end_limit: Union[Number, None]= None
    ) -> None:
        """
        *For internal use only*

        Validate that the `t_end` value provided is accepted by the
        time interval and the system based on the limits and the
        value of the `t_start` parameter also.

        This method will validate if the `t_end` is greater than the
        `t_start` parameter provided (or the current `self.t_start` if
        None) and also lower than the `t_end_limit` provided (or the 
        current `self.t_end_limit` if None).

        This method will raise an exception if the provided value is
        not valid.
        """
        t_end = (
            self.t_end
            if t_end is None else
            t_end
        )

        t_start = (
            self.t_start
            if t_start is None else
            t_start
        )

        t_end_limit = (
            self.t_end_limit
            if t_end_limit is None else
            t_end_limit
        )

        if t_end <= t_start:
            raise Exception(f'The "t_end={str(float(t_end))}" is lower or equal to the current "t_start={str(float(t_start))}".')
        
        if t_end > t_end_limit:
            raise Exception(f'The "t_end={str(float(t_end))}" is greater than the "t_end_limit={str(float(t_end_limit))}".')
        
    def _validate_duration(
        self,
        duration: Union[Number, None] = None
    ) -> None:
        """
        *For internal use only*

        Validate that the `duration` value provided is accepted by
        the time interval and the system based on the limit set
        when creating this instance.

        If the `duration` parameter provided is None, the current
        `duration` value will be used instead.

        This method will raise an exception if the provided value is
        not valid.
        """
        duration = (
            self.duration
            if duration is None else
            duration
        )

        if duration > self.duration_limit:
            raise Exception(f'The "duration={str(float(duration))}" is greater than the "duration_limit={str(float(self.duration_limit))}".')

    """
    Apparently, the professional video editors use always
    the `truncate` method to obtain the `t_start` of the
    frame time interval always. So, why should I change it?
    """
    def _truncate(
        self,
        t: Number
    ) -> float:
        """
        *For internal use only*

        Get the truncated value of the `t` time moment provided,
        which will be always the `t_start` of the time interval
        delimited by the `t` and the `fps` of this instance.

        (!) The value will be truncated only if the `fps`
        attribute is set.

        Some examples below (with `fps=5`):
        - `t=0.2` => `0.2` <=> `interval=[0.2, 0.4)`
        - `t=0.37` => `0.2` <=> `interval=[0.2, 0.4)`
        - `t=0.4` => `0.4` <=> `interval=[0.4, 0.6)`
        - `t=0.87` => `0.8` <=> `interval=[0.8, 1.0)`
        """
        return (
            self._t_handler.t.truncated(t)
            if self.fps is not None else
            t
        )
    
    def _round(
        self,
        t: Number
    ) -> float:
        """
        *For internal use only*

        Get the rounded value of the `t` time moment provided,
        which will be the `t_start` or the `t_end` (depending on which
        one is closer to the `t` value) of the time interval
        delimited by the `t` and the `fps` of this instance.

        (!) The value will be rounded only if the `fps`
        attribute is set.

        Some examples below (with `fps=5`):
        - `t=0.2` => `0.2` <=> `interval=[0.2, 0.4)`
        - `t=0.29` => `0.2` <=> `interval=[0.2, 0.4)`
        - `t=0.31` => `0.4` <=> `interval=[0.2, 0.4)`
        - `t=0.37` => `0.4` <=> `interval=[0.2, 0.4)`
        - `t=0.4` => `0.4` <=> `interval=[0.4, 0.6)`
        - `t=0.87` => `0.8` <=> `interval=[0.8, 1.0)`
        """
        return (
            self._t_handler.t.rounded(t)
            if self.fps is not None else
            t
        )
    
    def _round_up(
        self,
        t: Number
    ) -> float:
        """
        *For internal use only*
        
        Get the rounded up value of the `t` time moment provided,
        which will be the `t_end` of the time interval (unless it
        is exactly the `t_start` value of a time interval) delimited
        by the `t` and the `fps` of this instance.

        (!) The value will be rounded up only if the `fps`
        attribute is set.

        Some examples below (with `fps=5`):
        - `t=0.2` => `0.2` <=> `interval=[0.2, 0.4)`
        - `t=0.29` => `0.4` <=> `interval=[0.2, 0.4)`
        - `t=0.31` => `0.4` <=> `interval=[0.2, 0.4)`
        - `t=0.37` => `0.2` <=> `interval=[0.2, 0.4)`
        - `t=0.4` => `0.4` <=> `interval=[0.4, 0.6)`
        - `t=0.87` => `0.8` <=> `interval=[0.8, 1.0)`
        """
        return (
            self._t_handler.t.rounded_up(t)
            if self.fps is not None else
            t
        )
    
    def reset(
        self
    ) -> 'TimeInterval':
        """
        Reset the `t_start` and `t_end` value to the ones that
        were set when the instance was created.
        """
        self.t_start = self._t_original_start
        self.t_end = self._t_original_end

        return self
    
    def is_t_included(
        self,
        t: Number,
        do_include_end: bool = False
    ) -> bool:
        """
        Check if the `t` time moment provided is included in
        in this time interval instance current limits or not.
        This means that the `t` provided is between the
        current `t_start` and `t_end` time moment values.

        The `t_end` can be included for some special cases by
        providing the `do_include_end` boolean parameter as
        `True`.
        """
        return self._utils.a_includes_t(
            t = t,
            time_interval_a = self,
            do_include_end = do_include_end
        )
    
    def is_t_included_in_limits(
        self,
        t: Number
    ) -> bool:
        """
        Check if the `t` time moment provided is included in
        in this time interval instance if the original limits
        were the current `t_start` and `t_end` or not.

        This will return `True` if the `t` provided is between
        the `t_start_limit` and `t_end_limit` values.

        The `t_end_limit` is not included.
        """
        return self.t_start_limit <= t < self.t_end_limit
    
    @parameter_to_time_interval('time_interval')
    def is_adjacent_to(
        self,
        time_interval: TimeIntervalType
    ) -> bool:
        """
        Check if this time interval and the one provided as
        `time_interval` are adjacent, which means that the
        `t_end` of one interval is also the `t_start` of the
        other one.

        (!) Giving the time intervals inverted will
        provide the same result.

        Examples below:
        - `a=[2, 5)` and `b=[5, 7)` => `True`
        - `a=[5, 7)` and `b=[2, 5)` => `True`
        - `a=[2, 5)` and `b=[3, 4)` => `False`
        - `a=[2, 5)` and `b=[6, 8)` => `False`
        """
        return self._utils.a_is_adjacent_to_b(
            time_interval_a = self,
            time_interval_b = time_interval
        )
    
    @parameter_to_time_interval('time_interval')
    def is_contained_in(
        self,
        time_interval: TimeIntervalType
    ) -> bool:
        """
        Check if this time interval is fully contained
        into the one provided as `time_interval`.

        Examples below:
        - `a=[2, 5)` and `b=[1, 6)` => `True`
        - `a=[2, 5)` and `b=[0, 9)` => `True`
        - `a=[2, 5)` and `b=[2, 4)` => `False`
        - `a=[2, 5)` and `b=[4, 8)` => `False`
        - `a=[2, 5)` and `b=[7, 8)` => `False`
        """
        return self._utils.a_is_contained_in_b(
            time_interval_a = self,
            time_interval_b = time_interval
        )
    
    @parameter_to_time_interval('time_interval')
    def do_intersects_with(
        self,
        time_interval: TimeIntervalType
    ) -> bool:
        """
        Check if this time interval and the one provided
        as `time_interval` have at least a part in common.

        Examples below:
        - `a=[2, 5)` and `b=[4, 6)` => `True`
        - `a=[2, 5)` and `b=[1, 3)` => `True`
        - `a=[2, 5)` and `b=[5, 6)` => `False`
        - `a=[2, 5)` and `b=[7, 8)` => `False`
        - `a=[2, 5)` and `b=[1, 2)` => `False`
        """
        return self._utils.a_intersects_with_b(
            time_interval_a = self,
            time_interval_b = time_interval
        )
    
    @parameter_to_time_interval('time_interval')
    def get_intersection_with(
        self,
        time_interval: TimeIntervalType
    ) -> Union['TimeInterval', None]:
        """
        Get the time interval that intersects this time
        interval and the one provided as `time_interval`,
        that can be `None` if there is no intersection in
        between both.
        """
        return self._utils.get_intersection_of_a_and_b(
            time_interval_a = self,
            time_interval_b = time_interval
        )

    """
    These methods below are to modify the time interval
    `t_start` and `t_end` values.
    """

    def shift_by(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Move the `t_start` the `delta` amount of time provided (if
        possible and valid), and also the `t_end` in the same
        direction, so the duration is the same.

        This can only be done if the new `t_start` and `t_end` values
        are in between  the limits.
        """
        delta = self._truncate(delta)

        if delta == 0:
            return self

        new_start = self.t_start + delta
        new_end = self.t_end + delta

        self._validate_start(
            t_start = new_start,
            t_end = new_end
        )

        self._validate_end(
            t_end = new_end,
            t_start = new_start
        )
        
        self.t_start = new_start
        self.t_end = new_end

        return self
    
    def shift_to(
        self,
        t: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Move the `t_start` to the given `t` global time moment and
        the `t_end` the same amount in the same direction, so the
        duration will be the same (if possible and valid).

        This can only be done if the new `t_start` and `t_end` values
        are in between  the limits.
        """
        return self.shift_by(
            delta = t - self.t_start
        )

    def get_cuts(
        self,
        t_start: Number,
        t_end: Number
    ) -> tuple[Union['TimeInterval', None], Union['TimeInterval', None], Union['TimeInterval', None]]:
        """
        Cut a segment from the given `t_start` to the also provided
        `t_end` time moments of this time interval instance and get
        all the cuts.

        This method will return a tuple of 3 elements including the
        segments created by cutting this time interval in the order
        they were generated, but also having the 4th element always
        as the index of the one specifically requested by the user.
        The tuple will include all the segments at the begining and
        the rest will be None (unless the 4th one, which is the
        index).

        Examples below:
        - A time interval of `[2, 5)` cut with `t_start=3` and `t_end=4`
        will generate `((2, 3), (3, 4), (4, 5), 1)`.
        - A time interval of `[2, 5)` cut with `t_start=2` and `t_end=4`
        will generate `((2, 4), (4, 5), None, 0)`.
        - A time interval of `[2, 5)` cut with `t_start=4` and `t_end=5`
        will generate `((2, 4), (4, 5), None, 1)`.
        - A time interval of `[2, 5)` cut with `t_start=2` and `t_end=5`
        will generate `((2, 5), None, None, 0)`.

        As you can see, the result could be the same in different
        situations, but it's up to you (and the specific method in
        which you are calling to this one) to choose the tuple you
        want to return.
        """
        return self._cutter.from_to(
            time_interval = self,
            t_start = self._truncate(t_start),
            t_end = self._truncate(t_end)
        )
    
    def get_cut(
        self,
        t_start: Number,
        t_end: Number
    ) -> 'TimeInterval':
        """
        Get this time interval instance but cutted from the `t_start`
        to the `t_end` time moments provided.

        (!) This method doesn't modify the original instance but
        returns a new one.
        """
        tuples = self.get_cuts(
            t_start = t_start,
            t_end = t_end
        )

        return tuples[tuples[3]]
    
    def cut(
        self,
        t_start: Number,
        t_end: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Transform this time interval into a new one delimited by
        the `t_start` and `t_end` time moments provided.

        This method returns this same instance but modified.
        """
        cut = self.get_cut(
            t_start = t_start,
            t_end = t_end
        )

        # This will be always valid as we are cutting a valid one
        return self.with_start_and_end(cut.t_start, cut.t_end)
    
    # TODO: Rename, please
    def get_trim_starts(
        self,
        delta: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Get a tuple containing the 2 new `TimeInterval` instances
        generated by trimming this one's t_start the amount of seconds
        provided as the `delta` parameter. The first tuple is
        the remaining, and the second one is the new time interval
        requested by the user.

        (!) The `delta` value provided will be transformed into
        a multiple of `1/fps` of this instance, and truncated to fit
        the `t_start` of the time interval the new segments will belong
        to, if the `fps` is set.

        This method will raise an exception if the new `t_start` value
        becomes a value over the time interval `t_end` value or the
        `limit`, that must be greater than the `t_start` and lower
        than the time interval `t_end` value.

        The `delta` must be a positive value, the amount of
        seconds to be trimmed.
        """
        return self._cutter.trim_start(
            time_interval = self,
            delta = self._truncate(delta)
        )
    
    # TODO: Rename, please
    def get_trim_start(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        Get this time interval instance but trimmed from the `t_start`
        the `delta` amount of seconds provided.

        (!) The `delta` value provided will be transformed into
        a multiple of `1/fps` of this instance, and truncated to fit
        the `t_start` of the time interval the new segments will belong
        to, if the `fps` is set.

        (!) This method doesn't modify the original instance but
        returns a new one.
        """
        return self.get_trim_starts(
            delta = delta
        )[1]
    
    def _trim_start(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        *For internal use only*

        (!) This method will modify this instance.

        Transform this time interval into a new one in which
        the `t_start` has been trimmed the `delta` provided
        if the result respected the also given `limit`.

        This method returns this same instance but modified.
        """
        cut = self.get_trim_start(
            delta = delta
        )

        self._validate_start(cut.t_start)
        self._validate_duration(cut.t_end - cut.t_start)

        self.t_start = cut.t_start

        return self
    
    def get_trim_ends(
        self,
        delta: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Get a tuple containing the 2 new `TimeInterval` instances
        generated by trimming this one's t_end the amount of seconds
        provided as the `delta` parameter. The first tuple is
        the one requested by the user, and the second one is the
        remaining.

        (!) The `delta` value provided will be transformed into
        a multiple of `1/fps` of this instance, and truncated to fit
        the `t_start` of the time interval the new segments will belong
        to, if the `fps` is set.

        The `delta` must be a positive value, the amount of
        seconds to be trimmed.
        """
        return self._cutter.trim_end(
            time_interval = self,
            delta = self._truncate(delta)
        )
    
    # TODO: Rename, please
    def get_trim_end(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        Get this time interval instance but trimmed from the `t_end`
        the `delta` amount of seconds provided.

        (!) The `delta` value provided will be transformed into
        a multiple of `1/fps` of this instance, and truncated to fit
        the `t_end` of the time interval the new segments will belong
        to, if the `fps` is set.

        (!) This method doesn't modify the original instance but
        returns a new one.
        """
        return self.get_trim_ends(
            delta = delta
        )[0]
    
    def _trim_end(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        *For internal use only*

        (!) This method will modify this instance.

        Transform this time interval into a new one in which
        the `t_end` has been trimmed the `delta` provided
        if the result respected the also given `limit`.

        This method returns this same instance but modified.
        """
        cut = self.get_trim_end(
            delta = delta
        )

        self._validate_end(cut.t_end)
        self._validate_duration(cut.t_end - cut.t_start)

        self.t_end = cut.t_end

        return self
    
    def get_splits(
        self,
        t: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Split the time interval at the provided `t` time moment
        and get the 2 new time intervals as a result (as a tuple).

        (!) The `t` value provided will be transformed into a
        multiple of `1/fps` of this instance, and truncated to fit
        the `t_start` of the time interval the new segments will belong
        to if the `fps` value is set.

        This method will raise an exception if the `t` value 
        provided is a limit value (or above).

        Examples below:
        - A time interval of `[2, 5)` cut with `t=3` will generate
        `((2, 3), (3, 5))`.
        - A time interval of `[2, 5)` cut with `t=4` will generate
        `((2, 4), (4, 5))`.
        - A time interval of `[2, 5)` cut with `t>=5` will raise
        exception.
        - A time interval of `[2, 5)` cut with `t<=2` will raise
        exception.
        """
        return self._cutter.split(
            time_interval = self,
            t = self._truncate(t)
        )
    
    def split(
        self,
        t: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Split the time interval at the provided `t` time moment
        and get the 2 new time intervals as a result (as a tuple),
        that will be copies of this instance (with their original
        `t_start` and `t_end` values) but the new ones according to 
        the split result.

        (!) The `t` value provided will be transformed into a
        multiple of `1/fps` of this instance, and truncated to fit
        the `t_start` of the time interval the new segments will belong
        to if the `fps` value is set.

        This method will raise an exception if the `t` value 
        provided is a limit value (or above).
        """
        splits = self.get_splits(t)

        return (
            self.copy.with_start_and_end(splits[0].t_start, splits[0].t_end),
            self.copy.with_start_and_end(splits[1].t_start, splits[1].t_end)
        )
    
    def with_start_and_end(
        self,
        t_start: Number,
        t_end: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Get this instance but with the `t_start` and the `t_end`
        time moments modified to the given ones (if possible
        and valid).

        This method returns this same instance but modified.
        """
        self._validate_start(
            t_start = t_start,
            t_end = t_end
        )

        self._validate_end(
            t_end = t_end,
            t_start = t_start
        )

        self._validate_duration(t_end - t_start)

        self.t_start = t_start
        self.t_end = t_end

        return self
    
    def with_start(
        self,
        t_start: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Get this instance but with the `t_start` time moment
        modified to the given one (if possible and valid).
        
        This method will validate if the `t_start` provided 
        is valid according to this TimeInterval instance
        limits or not.

        This method returns this same instance but modified.
        """
        self._validate_start(
            t_start = t_start
        )

        self._validate_duration(self.t_end - t_start)

        self.t_start = t_start

        return self
    
    def with_end(
        self,
        t_end: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Get this instance but with the `t_end` time moment
        modified to the given one (if possible and valid).

        This method will validate if the `t_emd` provided 
        is valid according to this TimeInterval instance
        limits or not.

        This method returns this same instance but modified.
        """
        self._validate_end(
            t_end = t_end
        )

        self._validate_duration(t_end - self.t_start)

        self.t_end = t_end

        return self
    
    def _extend_end(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        *For internal use only*

        (!) This method will modify this instance.

        Transform this time interval into a new one in which
        the `t_end` has been extended the `delta` provided
        if the result respected the also given `limit`.

        This method returns this same instance but modified.

        This method will raise an exception if the new duration
        exceeds the `duration_limit`.
        """
        ParameterValidator.validate_mandatory_positive_number('delta', delta, do_include_zero = True)

        if delta == 0:
            return self

        extended = self._extender.extend_end(
            time_interval = self,
            delta = (
                self._truncate(delta)
                if self.fps is not None else
                delta
            )
        )

        self._validate_end(extended.t_end)
        self._validate_duration(extended.t_end - self.t_start)

        # TODO: Is this above a bit useless (?)
        self.t_end = extended.t_end

        return self
    
    def _extend_start(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        *For internal use only*

        (!) This method will modify this instance.

        Transform this time interval into a new one in which
        the `t_start` has been extended the `delta` provided
        if the result respected the also given `limit`.

        This method returns this same instance but modified.

        This method will raise an exception if the new duration
        exceeds the `duration_limit`.
        """
        ParameterValidator.validate_mandatory_positive_number('delta', delta, do_include_zero = True)

        if delta == 0:
            return self

        extended = self._extender.extend_start(
            time_interval = self,
            delta = (
                self._truncate(delta)
                if self.fps is not None else
                delta
            )
        )

        self._validate_start(extended.t_start)
        self._validate_duration(self.t_end - extended.t_start)

        # TODO: Is this above a bit useless (?)
        self.t_start = extended.t_start

        return self
    
    def shift_start_by(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Giving a negative `delta` value will make the
        time interval longer, extending the `t_start` value.

        Transform this time interval into a new one in which
        the `t_start` has been extended or trimmed the
        `delta` value provided if the result respects 
        the also given `limit`.

        The new `t_start` can never be lower than the original
        (min) `t_start` value of this time interval instance.

        This method returns this same instance but modified.
        """
        ParameterValidator.validate_mandatory_number(delta, delta, do_include_zero = True)

        if delta == 0:
            return self

        return (
            self._trim_start(
                delta = abs(delta)
            )
            if delta > 0 else
            self._extend_start(
                delta = abs(delta)
            )
        )
    
    def shift_start_to(
        self,
        t: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Transform the time interval into a new one in which
        the `t_start` time moment has been modified to the `t`
        provided (if possible and valid).

        This method returns this same instance but modified.
        """
        return self.shift_start_by(
            delta = t - self.t_start
        )
    
    def shift_end_by(
        self,
        delta: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Giving a positive `delta` value will make the
        time interval longer, extending the `t_end` value.

        Transform this time interval into a new one in which
        the `t_end` has been extended or trimmed the
        `delta` value provided if the result respects 
        the also given `limit`.

        The new `t_end` can never be greater than the original
        (min) `t_end` value of this time interval instance.

        This method returns this same instance but modified.
        """
        ParameterValidator.validate_mandatory_number(delta, delta, do_include_zero = True)

        if delta == 0:
            return self

        return (
            self._trim_end(
                delta = abs(delta)
            )
            if delta < 0 else
            self._extend_end(
                delta = abs(delta)
            )
        )
    
    def shift_end_to(
        self,
        t: Number
    ) -> 'TimeInterval':
        """
        (!) This method will modify this instance.

        Transform the time interval into a new one in which
        the `t_end` time moment has been modified to the `t`
        provided (if possible and valid).

        This method returns this same instance but modified.
        """
        return self.shift_end_by(
            delta = t - self.t_end
        )
    
class TimeIntervalUtils:
    """
    Static class to wrap the utils related to time intervals.
    """

    @staticmethod
    def a_includes_t(
        t: float,
        time_interval_a: 'TimeInterval',
        do_include_end: bool = False
    ) -> bool:
        """
        Check if the `t` time moment provided is included in
        the `time_interval_a` given. The `time_interval_a.t_end`
        is excluded unless the `do_include_end` parameter is
        set as `True`.

        A time interval is `[t_start, t_end)`, thats why the t_end is
        excluded by default.
        """
        return (
            time_interval_a.t_start <= t <= time_interval_a.t_end
            if do_include_end else
            time_interval_a.t_start <= t < time_interval_a.t_end
        )
    
    @staticmethod
    def a_is_adjacent_to_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval',
    ) -> bool:
        """
        Check if the `time_interval_a` provided and the
        also given `time_interval_b` are adjacent, which
        means that the `t_end` of one interval is also the
        `t_start` of the other one.

        (!) Giving the time intervals inverted will
        provide the same result.

        Examples below:
        - `a=[2, 5)` and `b=[5, 7)` => `True`
        - `a=[5, 7)` and `b=[2, 5)` => `True`
        - `a=[2, 5)` and `b=[3, 4)` => `False`
        - `a=[2, 5)` and `b=[6, 8)` => `False`
        """
        return (
            TimeIntervalUtils.a_is_inmediately_before_b(time_interval_a, time_interval_b) or
            TimeIntervalUtils.a_is_inmediately_after_b(time_interval_a, time_interval_b)
        )
    
    @staticmethod
    def a_is_inmediately_before_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval',
    ) -> bool:
        """
        Check if the `time_interval_a` provided is inmediately
        before the also given `time_interval_b`, which means
        that the `t_end` of the first one is also the `t_start` of
        the second one.

        Examples below:
        - `a=[2, 5)` and `b=[5, 7)` => `True`
        - `a=[5, 7)` and `b=[2, 5)` => `False`
        - `a=[2, 5)` and `b=[3, 4)` => `False`
        - `a=[2, 5)` and `b=[6, 8)` => `False`
        """
        return time_interval_a.t_end == time_interval_b.t_start
    
    @staticmethod
    def a_is_inmediately_after_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval',
    ) -> bool:
        """
        Check if the `time_interval_a` provided is inmediately
        after the also given `time_interval_b`, which means
        that the `t_start` of the first one is also the `t_end` of
        the second one.

        Examples below:
        - `a=[2, 5)` and `b=[5, 7)` => `False`
        - `a=[5, 7)` and `b=[2, 5)` => `True`
        - `a=[2, 5)` and `b=[3, 4)` => `False`
        - `a=[2, 5)` and `b=[6, 8)` => `False`
        """
        return time_interval_a.t_start == time_interval_b.t_end
    
    @staticmethod
    def a_contains_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval'
    ) -> bool:
        """
        Check if the `time_interval_a` time interval provided
        includes the `time_interval_b` or not, which means that
        the `time_interval_b` is fully contained in the first
        one.

        Examples below:
        - `a=[2, 5)` and `b=[3, 4)` => `True`
        - `a=[2, 5)` and `b=[2, 4)` => `True`
        - `a=[2, 5)` and `b=[3, 6)` => `False`
        - `a=[2, 5)` and `b=[6, 8)` => `False`
        """
        return (
            time_interval_a.t_start <= time_interval_b.t_start and
            time_interval_a.t_end >= time_interval_b.t_end
        )
    
    @staticmethod
    def a_is_contained_in_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval',
    ) -> bool:
        """
        Check if the `time_interval_a` provided is fully
        contained into the also provided `time_interval_b`.

        Examples below:
        - `a=[2, 5)` and `b=[1, 6)` => `True`
        - `a=[2, 5)` and `b=[0, 9)` => `True`
        - `a=[2, 5)` and `b=[2, 4)` => `False`
        - `a=[2, 5)` and `b=[4, 8)` => `False`
        - `a=[2, 5)` and `b=[7, 8)` => `False`
        """
        return TimeIntervalUtils.a_contains_b(
            time_interval_a = time_interval_b,
            time_interval_b = time_interval_a
        )
    
    @staticmethod
    def a_intersects_with_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval',
    ) -> bool:
        """
        Check if the `time_interval_a` and the `time_interval_b`
        provided have at least a part in common.

        Examples below:
        - `a=[2, 5)` and `b=[4, 6)` => `True`
        - `a=[2, 5)` and `b=[1, 3)` => `True`
        - `a=[2, 5)` and `b=[5, 6)` => `False`
        - `a=[2, 5)` and `b=[7, 8)` => `False`
        - `a=[2, 5)` and `b=[1, 2)` => `False`
        """
        return (
            time_interval_b.t_start < time_interval_a.t_end and
            time_interval_a.t_start < time_interval_b.t_end
        )
    
    @staticmethod
    def get_intersection_of_a_and_b(
        time_interval_a: 'TimeInterval',
        time_interval_b: 'TimeInterval'
    ) -> Union['TimeInterval', None]:
        """
        Get the time interval that intersects the two time
        intervals provided, that can be `None` if there is no
        intersection in between both.

        The `fps` of the intersection will be `None`.
        """
        return (
            None
            if not TimeIntervalUtils.a_intersects_with_b(
                time_interval_a = time_interval_a,
                time_interval_b = time_interval_b
            ) else
            TimeInterval(
                t_start = max(time_interval_a.t_start, time_interval_b.t_start),
                t_end = min(time_interval_a.t_end, time_interval_b.t_end),
                t_start_limit = min(time_interval_a.t_start_limit, time_interval_b.t_start_limit),
                t_end_limit = max(time_interval_a.t_end_limit, time_interval_b.t_end_limit),
                fps = None
            )
        )

class TimeIntervalCutter:
    """
    Class to wrap the functionality related to cutting
    time intervals.
    """

    @staticmethod
    @parameter_to_time_interval('time_interval')
    def trim_end_to(
        time_interval: TimeIntervalType,
        t: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Get a tuple containing the 2 new `TimeInterval` instances
        generated by trimming the `time_interval` t_end to the `t`
        time moment provided. The first tuple is the requested by
        the user, and the second one is the remaining.

        The `t` time moment provided must be a value between the
        `t_start` and `t_end` of the `time_interval` provided.
        """
        _validate_time_interval_current_limits(time_interval, t, True, True)
        
        return (
            TimeInterval(
                t_start = time_interval.t_start,
                t_end = t,
                t_start_limit = time_interval.t_start_limit,
                t_end_limit = time_interval.t_end_limit,
                fps = time_interval.fps
            ),
            TimeInterval(
                t_start = t,
                t_end = time_interval.t_end,
                t_start_limit = time_interval.t_start_limit,
                t_end_limit = time_interval.t_end_limit,
                fps = time_interval.fps
            )
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def trim_end(
        time_interval: TimeIntervalType,
        delta: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Get a tuple containing the 2 new `TimeInterval` instances
        generated by trimming the `time_interval` t_end the amount
        of seconds provided as the `delta` parameter. The
        first tuple is the requested by the user, and the second one
        is the remaining.

        The `delta` must be a positive value, the amount of
        seconds to be trimmed.
        """
        ParameterValidator.validate_mandatory_positive_number('delta', delta, do_include_zero = True)

        if delta == 0:
            return time_interval.copy

        return TimeIntervalCutter.trim_end_to(
            time_interval = time_interval,
            t = time_interval.t_end - delta
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def trim_start_to(
        time_interval: TimeIntervalType,
        t: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Get a tuple containing the 2 new `TimeInterval` instances
        generated by trimming the `time_interval` t_start to the `t`
        time moment provided. The first tuple is the remaining, and
        the second one is the requested by the user.

        The `t` time moment provided must be a value between the
        `t_start` and `t_end` of the `time_interval` provided.
        """
        _validate_time_interval_current_limits(time_interval, t, True, True)

        return (
            TimeInterval(
                t_start = time_interval.t_start,
                t_end = t,
                t_start_limit = time_interval.t_start_limit,
                t_end_limit = time_interval.t_end_limit,
                fps = time_interval.fps
            ),
            TimeInterval(
                t_start = t,
                t_end = time_interval.t_end,
                t_start_limit = time_interval.t_start_limit,
                t_end_limit = time_interval.t_end_limit,
                fps = time_interval.fps
            )
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def trim_start(
        time_interval: TimeIntervalType,
        delta: Number
    ) -> tuple['TimeInterval', 'TimeInterval']:
        """
        Get a tuple containing the 2 new `TimeInterval` instances
        generated by trimming the `time_interval` t_start the amount
        of seconds provided as the `delta` parameter. The
        first tuple is the remaining, and the second one is the
        new time interval requested by the user.

        The `delta` must be a positive value, the amount of
        seconds to be trimmed.
        """
        ParameterValidator.validate_mandatory_positive_number('delta', delta, do_include_zero = True)

        if delta == 0:
            return time_interval.copy

        return TimeIntervalCutter.trim_start_to(
            time_interval = time_interval,
            t = time_interval.t_start + delta
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def from_to(
        time_interval: 'TimeInterval',
        t_start: Number,
        t_end: Number
    ) -> tuple[Union['TimeInterval', None], Union['TimeInterval', None], Union['TimeInterval', None], int]:
        """
        Cut a segment from the given `t_start` to the also provided
        `t_end` time moments of the `time_interval` passed as
        parameter.

        This method will return a tuple of 3 elements including the
        segments created by cutting this time interval in the order
        they were generated, but also having the 4th element always
        as the index of the one specifically requested by the user.
        The tuple will include all the segments at the begining and
        the rest will be None (unless the 4th one, which is the
        index).

        Examples below:
        - A time interval of `[2, 5)` cut with `t_start=3` and `t_end=4`
        will generate `((2, 3), (3, 4), (4, 5), 1)`.
        - A time interval of `[2, 5)` cut with `t_start=2` and `t_end=4`
        will generate `((2, 4), (4, 5), None, 0)`.
        - A time interval of `[2, 5)` cut with `t_start=4` and `t_end=5`
        will generate `((2, 4), (4, 5), None, 1)`.
        - A time interval of `[2, 5)` cut with `t_start=2` and `t_end=5`
        will generate `((2, 5), None, None, 0)`.

        As you can see, the result could be the same in different
        situations, but it's up to you (and the specific method in
        which you are calling to this one) to choose the tuple you
        want to return.
        """
        _validate_time_interval_current_limits(time_interval, t_start)
        _validate_time_interval_current_limits(time_interval, t_end)

        return (
            # TODO: What about this case, should we raise except (?)
            (
                time_interval.copy,
                None,
                None,
                0
            )
            if (
                t_start == time_interval.t_start and
                t_end == time_interval.t_end
            ) else
            (
                TimeInterval(
                    t_start = time_interval.t_start,
                    t_end = t_end,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                TimeInterval(
                    t_start = t_end,
                    t_end = time_interval.t_end,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                None,
                0
            )
            if t_start == time_interval.t_start else
            (
                TimeInterval(
                    t_start = time_interval.t_start,
                    t_end = t_start,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                TimeInterval(
                    t_start = t_start,
                    t_end = time_interval.t_end,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                None,
                1
            )
            if t_end == time_interval.t_end else
            (
                TimeInterval(
                    t_start = time_interval.t_start,
                    t_end = t_start,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                TimeInterval(
                    t_start = t_start,
                    t_end = t_end,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                TimeInterval(
                    t_start = t_end,
                    t_end = time_interval.t_end,
                    t_start_limit = time_interval.t_start_limit,
                    t_end_limit = time_interval.t_end_limit,
                    fps = time_interval.fps
                ),
                1
            )
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def split(
        time_interval: TimeInterval,
        t: Number,
    ) -> tuple[TimeInterval, TimeInterval]:
        """
        Split the interval at the provided `t` time moment and
        get the 2 new time intervals as a result (as a tuple).

        This method will raise an exception if the `t` value 
        provided is a limit value (or above).

        Examples below:
        - A time interval of `[2, 5)` cut with `t=3` will generate
        `((2, 3), (3, 5))`.
        - A time interval of `[2, 5)` cut with `t=4` will generate
        `((2, 4), (4, 5))`.
        - A time interval of `[2, 5)` cut with `t>=5` will raise
        exception.
        - A time interval of `[2, 5)` cut with `t<=2` will raise
        exception.
        """
        if (
            t <= time_interval.t_start or
            t >= time_interval.t_end
        ):
            raise Exception('The "t" value is not a valid value as it is a limit (or more than a limit).')
        
        return (
            TimeInterval(
                t_start = time_interval.t_start,
                t_end = t,
                t_start_limit = time_interval.t_start_limit,
                t_end_limit = time_interval.t_end_limit,
                fps = time_interval.fps
            ),
            TimeInterval(
                t_start = t,
                t_end = time_interval.t_end,
                t_start_limit = time_interval.t_start_limit,
                t_end_limit = time_interval.t_end_limit,
                fps = time_interval.fps
            )
        )
    
# TODO: Mix this class with the cutter and make single
# methods able to extend or cut based on if the variation
# is positive or negative
class TimeIntervalExtender:
    """
    Class to wrap the functionality related to extending
    """

    @staticmethod
    @parameter_to_time_interval('time_interval')
    def extend_end(
        time_interval: 'TimeInterval',
        delta: Number
    ):
        """
        Extend the t_end of the given `time_interval` the `delta`
        amount of seconds provided.
        """
        ParameterValidator.validate_mandatory_positive_number('delta', delta, do_include_zero = True)

        if delta == 0:
            return time_interval.copy

        return TimeIntervalExtender.extend_end_to(
            time_interval = time_interval,
            t = time_interval.t_end + delta
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def extend_end_to(
        time_interval: 'TimeInterval',
        t: Number
    ):
        """
        Extend the t_end of the given `time_interval` the to the `t`
        time moment provided.
        """
        _validate_time_interval_original_limits(time_interval, t)
        
        if t < time_interval.t_end:
            raise Exception(f'The "t" value ({str(float(t))}) is lower than the current time interval `t_end` and this method is to extend it.')
        
        return TimeInterval(
            t_start = time_interval.t_start,
            t_end = t,
            t_start_limit = time_interval.t_start_limit,
            t_end_limit = time_interval.t_end_limit,
            fps = time_interval.fps
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def extend_start(
        time_interval: 'TimeInterval',
        delta: Number
    ):
        """
        Extend the t_start of the given `time_interval` the `delta`
        amount of seconds provided if the new `t_start` is greater than
        the `limit` provided and than the original (and min) `t_start`
        value of the time interval.
        """
        ParameterValidator.validate_mandatory_positive_number('delta', delta, do_include_zero = True)

        if delta == 0:
            return time_interval.copy

        return TimeIntervalExtender.extend_start_to(
            time_interval = time_interval,
            t = time_interval.t_start - delta
        )
    
    @staticmethod
    @parameter_to_time_interval('time_interval')
    def extend_start_to(
        time_interval: 'TimeInterval',
        t: Number
    ):
        """
        Extend the t_start of the given `time_interval` the to the `t`
        time moment provided.
        """
        _validate_time_interval_original_limits(time_interval, t)
        
        if t > time_interval.t_start:
            raise Exception(f'The "t" value ({str(float(t))}) is greater than the current time interval `t_start` and this method is to extend it.')
        
        return TimeInterval(
            t_start = t,
            t_end = time_interval.t_end,
            t_start_limit = time_interval.t_start_limit,
            t_end_limit = time_interval.t_end_limit,
            fps = time_interval.fps
        )
    
def _validate_time_interval_original_limits(
    time_interval: TimeInterval,
    t: Number,
    do_include_start_limit: bool = False,
    do_include_end_limit: bool = False
) -> None:
    """
    *For internal use only*

    This method will raise an exception if the `t` time moment
    parameter value provided is out of the `time_interval` 
    original limits, , or if the `t` is the `t_start_limit`
    limit and the `do_include_start_limit` boolean is `True`,
    or if the `t` is the `t_end_limit` limit and the
    `do_include_end_limit` boolean is `True`.

    TODO: How and where to put this (?)
    """
    if (
        do_include_start_limit and
        t == time_interval.t_start_limit
    ):
        raise Exception(f'The "t={str(float(t))}" provided is the same as the "t_start_limit={str(float(time_interval.t_start_limit))}".')
    
    if (
        do_include_end_limit and
        t == time_interval.t_end_limit
    ):
        raise Exception(f'The "t={str(float(t))}" provided is the same as the "t_end_limit={str(float(time_interval.t_end_limit))}".')
    
    if (
        t < time_interval.t_start_limit or
        t > time_interval.t_end_limit
    ):
        raise Exception(f'The "t" value ({str(float(t))}) is out of the time interval limits (min and max) [{str(float(time_interval.t_start_limit))}, {str(float(time_interval.t_end_limit))}].')
                        
def _validate_time_interval_current_limits(
    time_interval: TimeInterval,
    t: Number,
    do_include_start_limit: bool = False,
    do_include_end_limit: bool = False
) -> None:
    """
    *For internal use only*

    This method will raise an exception if the `t` time moment
    parameter value provided is out of the `time_interval` 
    current limits (current `t_start` and `t_end`), or if the
    `t` is the `t_start` limit and the `do_include_start_limit`
    boolean is `True`, or if the `t` is the `t_end` limit and
    the `do_include_end_limit` boolean is `True`.

    This method is useful when we are cutting or splitting the
    time interval so the parameter value must be always within
    the current time range.

    TODO: How and where to put this (?)
    """
    if (
        do_include_start_limit and
        t == time_interval.t_start
    ):
        raise Exception(f'The "t={str(float(t))}" provided is the same as the "t_start={str(float(time_interval.t_start))}".')
    
    if (
        do_include_end_limit and
        t == time_interval.t_end
    ):
        raise Exception(f'The "t={str(float(t))}" provided is the same as the "t_end={str(float(time_interval.t_end))}".')

    if (
        t < time_interval.t_start or
        t > time_interval.t_end
    ):
        raise Exception(f'The "t" value ({str(float(t))}) is out of the time interval current limits [{str(float(time_interval.t_start))}, {str(float(time_interval.t_end))}].')
    