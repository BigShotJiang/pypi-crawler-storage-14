"""
Edupaid utility functions.

Contains reusable logic extracted from endpoint functions.
Utilities handle parsing, transformation, validation, etc.

Usage:
    from edupaid.utils.some_utility import some_function
"""

# Utility functions will be exported here as they are implemented

__all__ = []

