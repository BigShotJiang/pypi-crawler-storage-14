"""
Edupaid error classes for handling API error responses.

These errors map to HTTP status codes returned by the Edupaid API:
- 400 Bad Request -> ValidationError
- 401 Unauthorized -> AuthError
- 404 Not Found -> NotFoundError
- 429 Too Many Requests -> RateLimitError
- 5xx Server Errors -> ServerError
- Configuration issues -> ConfigurationError
- Response parsing failures -> ParseError
"""

from edupaid.errors.errors import (
    EdupaidError,
    ConfigurationError,
    AuthError,
    RequestError,
    ValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ParseError,
)

__all__ = [
    "EdupaidError",
    "ConfigurationError",
    "AuthError",
    "RequestError",
    "ValidationError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ParseError",
]
