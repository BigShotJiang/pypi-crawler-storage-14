"""
Endpoint: list_app_authorizations

List learning track authorizations for a student.

POST /list-app-authorizations

Used by: edupaid/service.py::EdupaidService.list_app_authorizations

Reference: edupaid/docs/edupaid/list-app-authorizations.yaml
"""

from typing import Any, Dict

from edupaid.http import HttpClient
from edupaid.models.request import EdupaidListLearningTrackAuthorizationsRequest
from edupaid.models.response import EdupaidListLearningTrackAuthorizationsResponse


def list_app_authorizations(
    http: HttpClient,
    request: EdupaidListLearningTrackAuthorizationsRequest,
) -> EdupaidListLearningTrackAuthorizationsResponse:
    """
    List learning track authorizations for a student.

    Looks up a student by timebackStudentId and returns all their track
    authorizations categorized as locked, unlocked, scheduled, or defaulted.
    If the student does not exist, returns 200 with all tracks as locked.

    Steps:
        1. Serialize the request model to JSON
        2. POST to /list-app-authorizations
        3. Parse and return the response as EdupaidListLearningTrackAuthorizationsResponse

    Args:
        http: HttpClient instance for making API requests.
        request: Request containing timebackStudentId and optional providerId.

    Returns:
        EdupaidListLearningTrackAuthorizationsResponse with tracks categorized by status:
        - lockedTracks: Tracks requiring payment
        - unlockedTracks: Active subscriptions
        - scheduledTracks: Upcoming payments scheduled
        - defaultedTracks: Expired/defaulted subscriptions

    Raises:
        ValidationError: If request body is invalid (400).
        AuthError: If API key is invalid or missing (401).
        ServerError: If server error occurs (5xx).
    """
    # Serialize request to dict
    body: Dict[str, Any] = request.model_dump(exclude_none=True)

    # Make POST request to the endpoint
    data: Dict[str, Any] = http.post("/list-app-authorizations", json=body)

    # Parse and return typed response
    return EdupaidListLearningTrackAuthorizationsResponse.model_validate(data)

