"""
Edupaid API endpoint functions.

Each endpoint has its own file containing the function that makes the API call.
These functions are called by EdupaidService methods.

Usage:
    # Service methods call these functions internally
    from edupaid.endpoints.get_app_authorization import get_app_authorization
    
    result = get_app_authorization(http_client, request)
"""

from edupaid.endpoints.batch_get_app_authorization import batch_get_app_authorization
from edupaid.endpoints.generate_parent_token import generate_parent_token
from edupaid.endpoints.get_app_authorization import get_app_authorization
from edupaid.endpoints.list_app_authorizations import list_app_authorizations
from edupaid.endpoints.submit_token import submit_token

__all__ = [
    "batch_get_app_authorization",
    "generate_parent_token",
    "get_app_authorization",
    "list_app_authorizations",
    "submit_token",
]

