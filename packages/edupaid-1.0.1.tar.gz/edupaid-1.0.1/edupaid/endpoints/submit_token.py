"""
Endpoint: submit_token

Submit a learning token for a student.

POST /submit-token

Used by: edupaid/service.py::EdupaidService.submit_token

Reference: edupaid/docs/edupaid/submit-token.yaml
"""

from typing import Any, Dict

from edupaid.http import HttpClient
from edupaid.models.request import EdupaidSubmitTokenRequest
from edupaid.models.response import EdupaidSubmitTokenResponse


def submit_token(
    http: HttpClient,
    request: EdupaidSubmitTokenRequest,
) -> EdupaidSubmitTokenResponse:
    """
    Submit a learning token for a student.

    Validates token input, saves the token, and updates prerequisite slots accordingly.
    Invalid tokens are recorded in bad_tokens for further inspection.

    Steps:
        1. Serialize the request model to JSON
        2. POST to /submit-token
        3. Parse and return the response as EdupaidSubmitTokenResponse

    Args:
        http: HttpClient instance for making API requests.
        request: Request containing studentId, timeBackAppId, type, data, and evidenceId.

    Returns:
        EdupaidSubmitTokenResponse with the token submission ID.

    Raises:
        ValidationError: If request body is invalid (400).
        AuthError: If API key is invalid or missing (401).
        NotFoundError: If student or app not found (404).
        ServerError: If server error occurs (5xx).
    """
    # Serialize request to dict
    body: Dict[str, Any] = request.model_dump(exclude_none=True)

    # Make POST request to the endpoint
    data: Dict[str, Any] = http.post("/submit-token", json=body)

    # Parse and return typed response
    return EdupaidSubmitTokenResponse.model_validate(data)

