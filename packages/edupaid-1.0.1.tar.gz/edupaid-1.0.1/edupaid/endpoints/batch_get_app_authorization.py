"""
Endpoint: batch_get_app_authorization

Get learning track authorization status for multiple students.

POST /batch-get-app-authorization

Used by: edupaid/service.py::EdupaidService.batch_get_app_authorization

Reference: edupaid/docs/edupaid/batch-get-app-authorizations.yaml
"""

from typing import Any, Dict

from edupaid.http import HttpClient
from edupaid.models.request import EdupaidBatchGetLearningTrackAuthorizationRequest
from edupaid.models.response import EdupaidBatchGetLearningTrackAuthorizationResponse
from edupaid.logs.logger import configure_logging

log = configure_logging(__name__, log_level="DEBUG")


def batch_get_app_authorization(
    http: HttpClient,
    request: EdupaidBatchGetLearningTrackAuthorizationRequest,
) -> EdupaidBatchGetLearningTrackAuthorizationResponse:
    """
    Get learning track authorization status for multiple students.

    Returns authorization status for multiple students for a single learning track.
    Non-existent student IDs are treated as locked with payment modes rather than errors.

    Steps:
        1. Serialize the request model to JSON
        2. POST to /batch-get-app-authorization
        3. Parse and return the response as EdupaidBatchGetLearningTrackAuthorizationResponse

    Args:
        http: HttpClient instance for making API requests.
        request: Request containing learningTrackId and list of studentIds.

    Returns:
        EdupaidBatchGetLearningTrackAuthorizationResponse with:
        - learningTrackId: The track being queried
        - results: List of per-student authorization results

    Raises:
        ValidationError: If request body is invalid (400).
        AuthError: If API key is invalid or missing (401).
        NotFoundError: If learning track not found (404).
        ServerError: If server error occurs (5xx).
    """
    log.debug(f"batch_get_app_authorization request: {request}")
    # Serialize request to dict
    body: Dict[str, Any] = request.model_dump(exclude_none=True)

    # Make POST request to the endpoint
    data: Dict[str, Any] = http.post("/batch-get-app-authorization", json=body)

    log.debug(f"batch_get_app_authorization response: {data}")

    # Parse and return typed response
    return EdupaidBatchGetLearningTrackAuthorizationResponse.model_validate(data)
