"""
Endpoint: generate_parent_token

Generate parent portal access URL.

POST /generate-parent-token

Used by: edupaid/service.py::EdupaidService.generate_parent_token

Reference: edupaid/docs/edupaid/generate-parent-token.yaml
"""

from typing import Any, Dict

from edupaid.http import HttpClient
from edupaid.models.request import EdupaidGenerateParentTokenRequest
from edupaid.models.response import EdupaidGenerateParentTokenResponse


def generate_parent_token(
    http: HttpClient,
    request: EdupaidGenerateParentTokenRequest,
) -> EdupaidGenerateParentTokenResponse:
    """
    Generate parent portal access URL.

    Validates the parent identifier and returns a time-limited URL
    to the Students app subscription portal. The token is embedded
    in the URL and expires after the specified duration.

    Steps:
        1. Serialize the request model to JSON
        2. POST to /generate-parent-token
        3. Parse and return the response as EdupaidGenerateParentTokenResponse

    Args:
        http: HttpClient instance for making API requests.
        request: Request containing parentTimebackId and optional expiryMinutes.

    Returns:
        EdupaidGenerateParentTokenResponse with the portal URL.

    Raises:
        ValidationError: If request body is invalid (400).
        AuthError: If API key is invalid or missing (401).
        ServerError: If server error occurs (5xx).
    """
    # Serialize request to dict
    body: Dict[str, Any] = request.model_dump(exclude_none=True)

    # Make POST request to the endpoint
    data: Dict[str, Any] = http.post("/generate-parent-token", json=body)

    # Parse and return typed response
    return EdupaidGenerateParentTokenResponse.model_validate(data)

