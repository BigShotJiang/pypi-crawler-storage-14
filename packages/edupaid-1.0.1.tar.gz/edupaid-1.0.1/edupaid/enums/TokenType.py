from enum import Enum


class EdupaidTokenType(str, Enum):
    """Enum for token types used in submit_token endpoint.

    Used by: EdupaidSubmitTokenRequest
    """

    MASTERY = "Mastery"
    TWO_X = "TwoX"

