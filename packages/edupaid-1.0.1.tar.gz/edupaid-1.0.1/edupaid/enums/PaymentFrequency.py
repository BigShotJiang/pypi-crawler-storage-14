from enum import Enum


class EdupaidPaymentFrequency(str, Enum):
    """Enum for payment frequency values present on scheduled tracks/payment modes.

    Mirrors Edupaid schema; values must match API payloads exactly.
    """

    MONTHLY = "Monthly"
    ANNUALLY = "Annually"
    ONE_TIME = "OneTime"
    QUARTERLY = "Quarterly"
    ANNUAL_FIXED_365 = "AnnualFixed365"
