from enum import Enum


class EdupaidAuthorizationStatus(str, Enum):
    """Enum for Edupaid track authorization statuses used in responses from Edupaid.

    Used by: `BatchLearningTrackAuthorizationResult`, `LearningTrackAuthorizationResponse`.
    """

    UNLOCKED = "unlocked"
    LOCKED = "locked"
    SCHEDULED = "scheduled"
    DEFAULTED = "defaulted"
