from pydantic import BaseModel, ConfigDict


class EdupaidCaliperEvent(BaseModel):
    """Generic Caliper event payload (additional properties allowed).

    Schema source: `schemas.md` (CaliperEvent).
    """

    model_config = ConfigDict(extra="allow")

    type: str
    action: str
