from pydantic import BaseModel
from typing import Optional
from edupaid.models.UnifiedLearningTrack import EdupaidUnifiedLearningTrack
from edupaid.enums.AuthorizationStatus import EdupaidAuthorizationStatus


class EdupaidBatchLearningTrackAuthorizationResult(BaseModel):
    """Per-student result element for the batch authorization endpoint.

    Schema source: `schemas.md` (BatchLearningTrackAuthorizationResult).
    """

    studentId: str
    track: Optional[EdupaidUnifiedLearningTrack] = None
    defaulted: Optional[bool] = None
    error: Optional[str] = None
    status: Optional[EdupaidAuthorizationStatus] = None
