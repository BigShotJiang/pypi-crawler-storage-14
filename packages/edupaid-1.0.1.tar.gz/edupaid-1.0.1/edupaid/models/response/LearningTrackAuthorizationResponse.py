from pydantic import BaseModel
from edupaid.models.UnifiedLearningTrack import EdupaidUnifiedLearningTrack
from edupaid.enums.AuthorizationStatus import EdupaidAuthorizationStatus


class EdupaidLearningTrackAuthorizationResponse(BaseModel):
    """Response body for GET app authorization for a single student/track.

    Schema source: `schemas.md` (LearningTrackAuthorizationResponse).
    """

    track: EdupaidUnifiedLearningTrack
    defaulted: bool
    status: EdupaidAuthorizationStatus
