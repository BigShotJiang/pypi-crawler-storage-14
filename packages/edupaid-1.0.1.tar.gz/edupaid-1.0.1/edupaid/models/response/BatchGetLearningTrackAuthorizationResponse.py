from pydantic import BaseModel
from typing import List
from edupaid.models.BatchLearningTrackAuthorizationResult import (
    EdupaidBatchLearningTrackAuthorizationResult,
)


class EdupaidBatchGetLearningTrackAuthorizationResponse(BaseModel):
    """Response body for batch authorization lookup.

    Schema source: `schemas.md` (BatchGetLearningTrackAuthorizationResponse).
    """

    learningTrackId: str
    results: List[EdupaidBatchLearningTrackAuthorizationResult]
