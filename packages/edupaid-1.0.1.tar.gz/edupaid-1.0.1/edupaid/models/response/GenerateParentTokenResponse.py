from pydantic import BaseModel


class EdupaidGenerateParentTokenResponse(BaseModel):
    """Response body containing the generated parent portal URL.

    Schema source: `schemas.md` (GenerateParentTokenResponse).
    """

    url: str
