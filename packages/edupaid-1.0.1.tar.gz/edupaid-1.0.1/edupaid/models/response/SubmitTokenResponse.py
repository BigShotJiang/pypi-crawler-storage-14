from pydantic import BaseModel


class EdupaidSubmitTokenResponse(BaseModel):
    """Response body for token submission.

    Attributes:
        - id (str): Token submission identifier

    Schema source: `schemas.md` (SubmitTokenResponse).
    Used by: edupaid/endpoints/submit_token.py
    """

    id: str

