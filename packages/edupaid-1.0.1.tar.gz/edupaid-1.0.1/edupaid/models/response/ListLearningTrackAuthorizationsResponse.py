from pydantic import BaseModel
from typing import List
from edupaid.models.UnifiedLearningTrack import EdupaidUnifiedLearningTrack


class EdupaidListLearningTrackAuthorizationsResponse(BaseModel):
    """Response body for listing student's track authorizations by category.

    Schema source: `schemas.md` (ListLearningTrackAuthorizationsResponse).
    """

    lockedTracks: List[EdupaidUnifiedLearningTrack]
    unlockedTracks: List[EdupaidUnifiedLearningTrack]
    scheduledTracks: List[EdupaidUnifiedLearningTrack]
    defaultedTracks: List[EdupaidUnifiedLearningTrack]
