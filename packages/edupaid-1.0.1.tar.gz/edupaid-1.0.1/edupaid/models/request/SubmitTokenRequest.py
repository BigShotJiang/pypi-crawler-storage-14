from pydantic import BaseModel

from edupaid.enums.TokenType import EdupaidTokenType


class EdupaidSubmitTokenRequest(BaseModel):
    """Request body for submitting a learning token.

    Attributes:
        Required:
            - studentId (str): Timeback student identifier
            - timeBackAppId (str): App identifier
            - type (EdupaidTokenType): Token type (Mastery or TwoX)
            - data (str): JSON string containing curriculumId and other token-specific data
            - evidenceId (str): Evidence identifier

    Schema source: `schemas.md` (TokenInput).
    Used by: edupaid/endpoints/submit_token.py
    """

    studentId: str
    timeBackAppId: str
    type: EdupaidTokenType
    data: str
    evidenceId: str

