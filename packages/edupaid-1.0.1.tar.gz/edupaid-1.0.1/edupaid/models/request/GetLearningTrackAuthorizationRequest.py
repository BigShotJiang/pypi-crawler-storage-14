from pydantic import BaseModel


class EdupaidGetLearningTrackAuthorizationRequest(BaseModel):
    """Request body for a single track authorization for a student.

    Schema source: `schemas.md` (GetLearningTrackAuthorizationRequest).
    """

    studentId: str
    learningTrackId: str
