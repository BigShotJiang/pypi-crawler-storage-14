from pydantic import BaseModel
from typing import List


class EdupaidBatchGetLearningTrackAuthorizationRequest(BaseModel):
    """Request body for batch authorization lookup.

    Schema source: `schemas.md` (BatchGetLearningTrackAuthorizationRequest).
    """

    learningTrackId: str
    studentIds: List[str]
