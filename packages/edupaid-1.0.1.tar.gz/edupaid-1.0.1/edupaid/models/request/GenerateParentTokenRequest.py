from pydantic import BaseModel
from typing import Optional


class EdupaidGenerateParentTokenRequest(BaseModel):
    """Request body for generating a parent portal token/URL.

    Schema source: `schemas.md` (GenerateParentTokenRequest).
    """

    parentTimebackId: str
    expiryMinutes: Optional[int] = 60
