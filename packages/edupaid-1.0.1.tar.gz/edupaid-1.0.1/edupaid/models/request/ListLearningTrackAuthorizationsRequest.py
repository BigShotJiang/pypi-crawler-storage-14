from pydantic import BaseModel
from typing import Optional


class EdupaidListLearningTrackAuthorizationsRequest(BaseModel):
    """Request body for listing a student's track authorizations.

    Schema source: `schemas.md` (ListLearningTrackAuthorizationsRequest).
    """

    timebackStudentId: str
    providerId: Optional[str] = None
