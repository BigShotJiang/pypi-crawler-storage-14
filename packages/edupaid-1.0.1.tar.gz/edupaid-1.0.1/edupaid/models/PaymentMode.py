from pydantic import BaseModel

from edupaid.enums.PaymentFrequency import EdupaidPaymentFrequency


class EdupaidPaymentMode(BaseModel):
    """Payment option for a track when it is locked.

    Schema source: `schemas.md` (PaymentMode). Used inside `UnifiedLearningTrack`.
    """

    payee: str
    amount: float
    currency: str
    frequency: EdupaidPaymentFrequency
