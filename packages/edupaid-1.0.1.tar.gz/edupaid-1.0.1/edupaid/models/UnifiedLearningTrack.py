from pydantic import BaseModel
from typing import Optional, List
from edupaid.models.PaymentMode import EdupaidPaymentMode
from edupaid.enums.PaymentFrequency import EdupaidPaymentFrequency


class EdupaidUnifiedLearningTrack(BaseModel):
    """Normalized learning track structure used by Edupaid list/get endpoints.

    Schema source: `schemas.md` (UnifiedLearningTrack).
    """

    learningTrackId: str
    learningTrackName: str
    appId: str
    isLocked: bool
    paymentModes: Optional[List[EdupaidPaymentMode]] = None
    scheduledChargeDate: Optional[str] = None  # ISO date-time string
    frequency: Optional[EdupaidPaymentFrequency] = None
