"""
Edupaid API error response models.

The Edupaid API returns errors in a simple format: {"error": "string"}
This is used consistently across all error responses (400, 404, 500, etc.).

Reference: edupaid/docs/edupaid_api_docs.md
"""

from .edupaid_error_response import EdupaidErrorResponse

__all__ = [
    "EdupaidErrorResponse",
]
