"""
Edupaid API error response model.

The Edupaid API returns errors in a simple format: {"error": "string"}
This model is used to parse error responses from all API endpoints.

Used by: edupaid/http.py for parsing API error responses.

Reference: edupaid/docs/edupaid_api_docs.md - all error responses (400, 404, 500)
           return this format.
"""

from typing import Optional

from pydantic import BaseModel, Field


class EdupaidErrorResponse(BaseModel):
    """
    Standard error response from the Edupaid API.

    All API error responses (400, 401, 404, 500) return this format.

    Attributes:
        error: The error message describing what went wrong.
    """

    error: Optional[str] = Field(
        default=None,
        description="Error message from the API. Optional because 401 responses may not include a body.",
    )

