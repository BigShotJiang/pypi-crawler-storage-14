"""
Edupaid - A Python library for interfacing with the Edupaid API.

Usage:
    from edupaid import Edupaid

    # Using environment variables
    client = Edupaid()

    # Or with explicit credentials
    client = Edupaid(
        api_key="your-api-key",
        provider_id="your-provider-id",
        jwt_secret="your-jwt-secret",
    )

Required environment variables (if not passed directly):
    - EDUPAID_API_KEY: API key for authentication
    - EDUPAID_PROVIDER_ID: Provider identifier
    - EDUPAID_JWT_SECRET: JWT secret for webhook verification

Optional environment variables:
    - EDUPAID_ENVIRONMENT: 'production' (default) or 'staging'
"""

__version__ = "1.0.1"
__author__ = "Casey Schmid"
__email__ = "caseywschmid@gmail.com"

__all__ = ["Edupaid"]


def __getattr__(name: str):
    """Lazy import to avoid circular imports during package initialization."""
    if name == "Edupaid":
        from .client import Edupaid

        return Edupaid
    raise AttributeError(name)
