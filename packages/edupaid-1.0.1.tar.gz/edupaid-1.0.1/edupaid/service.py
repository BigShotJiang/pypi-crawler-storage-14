"""
Edupaid service - API endpoint methods.

Contains methods for all Edupaid API endpoints. Each method calls the
corresponding endpoint function from the endpoints/ directory.

Used by: edupaid/client.py::Edupaid

Reference: edupaid/docs/edupaid_api_docs.md for API documentation.
"""

from edupaid.config import Settings
from edupaid.endpoints.batch_get_app_authorization import (
    batch_get_app_authorization as batch_get_app_authorization_endpoint,
)
from edupaid.endpoints.generate_parent_token import (
    generate_parent_token as generate_parent_token_endpoint,
)
from edupaid.endpoints.get_app_authorization import (
    get_app_authorization as get_app_authorization_endpoint,
)
from edupaid.endpoints.list_app_authorizations import (
    list_app_authorizations as list_app_authorizations_endpoint,
)
from edupaid.endpoints.submit_token import submit_token as submit_token_endpoint
from edupaid.http import HttpClient
from edupaid.models.request import (
    EdupaidBatchGetLearningTrackAuthorizationRequest,
    EdupaidGenerateParentTokenRequest,
    EdupaidGetLearningTrackAuthorizationRequest,
    EdupaidListLearningTrackAuthorizationsRequest,
    EdupaidSubmitTokenRequest,
)
from edupaid.models.response import (
    EdupaidBatchGetLearningTrackAuthorizationResponse,
    EdupaidGenerateParentTokenResponse,
    EdupaidLearningTrackAuthorizationResponse,
    EdupaidListLearningTrackAuthorizationsResponse,
    EdupaidSubmitTokenResponse,
)



class EdupaidService:
    """
    Edupaid API service methods.

    Provides typed methods for each API endpoint. Methods delegate to
    individual endpoint functions for implementation.

    Attributes:
        _http: HttpClient instance for making API requests.
        _settings: Settings instance with provider_id and other config.

    Used by: edupaid/client.py::Edupaid.service
    """

    def __init__(self, http: HttpClient, settings: Settings):
        """
        Initialize the service.

        Args:
            http: HttpClient instance for making API requests.
            settings: Settings instance with provider_id and other configuration.
        """
        self._http = http
        self._settings = settings

    @property
    def provider_id(self) -> str:
        """
        Get the provider ID from settings.

        Returns:
            The provider ID string.
        """
        return self._settings.provider_id  # type: ignore[return-value]

    @property
    def jwt_secret(self) -> str:
        """
        Get the JWT secret from settings.

        Returns:
            The JWT secret string.
        """
        return self._settings.jwt_secret  # type: ignore[return-value]

    # -------------------------------------------------------------------------
    # API Endpoint Methods
    # -------------------------------------------------------------------------
    # Each method below calls an endpoint function from edupaid/endpoints/
    # -------------------------------------------------------------------------

    def get_app_authorization(
        self,
        request: EdupaidGetLearningTrackAuthorizationRequest,
    ) -> EdupaidLearningTrackAuthorizationResponse:
        """
        Get learning track authorization status for a student.

        Args:
            request: Request containing studentId and learningTrackId.

        Returns:
            EdupaidLearningTrackAuthorizationResponse with track details and authorization status.
        """
        return get_app_authorization_endpoint(self._http, request)

    def list_app_authorizations(
        self,
        request: EdupaidListLearningTrackAuthorizationsRequest,
    ) -> EdupaidListLearningTrackAuthorizationsResponse:
        """
        List learning track authorizations for a student.

        Args:
            request: Request containing timebackStudentId and optional providerId.

        Returns:
            EdupaidListLearningTrackAuthorizationsResponse with tracks by status category.
        """
        return list_app_authorizations_endpoint(self._http, request)

    def batch_get_app_authorization(
        self,
        request: EdupaidBatchGetLearningTrackAuthorizationRequest,
    ) -> EdupaidBatchGetLearningTrackAuthorizationResponse:
        """
        Get learning track authorization status for multiple students.

        Args:
            request: Request containing learningTrackId and list of studentIds.

        Returns:
            EdupaidBatchGetLearningTrackAuthorizationResponse with per-student results.
        """
        return batch_get_app_authorization_endpoint(self._http, request)

    def submit_token(
        self,
        request: EdupaidSubmitTokenRequest,
    ) -> EdupaidSubmitTokenResponse:
        """
        Submit a learning token for a student.

        Args:
            request: Request containing studentId, timeBackAppId, type, data, and evidenceId.

        Returns:
            EdupaidSubmitTokenResponse with the token submission ID.
        """
        return submit_token_endpoint(self._http, request)

    def generate_parent_token(
        self,
        request: EdupaidGenerateParentTokenRequest,
    ) -> EdupaidGenerateParentTokenResponse:
        """
        Generate parent portal access URL.

        Args:
            request: Request containing parentTimebackId and optional expiryMinutes.

        Returns:
            EdupaidGenerateParentTokenResponse with the portal URL.
        """
        return generate_parent_token_endpoint(self._http, request)
