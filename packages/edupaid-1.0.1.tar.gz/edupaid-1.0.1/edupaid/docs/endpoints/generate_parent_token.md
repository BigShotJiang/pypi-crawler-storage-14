# generate_parent_token

Generate parent portal access URL.

Validates the parent identifier and returns a time-limited URL to the Students app subscription portal. The token is embedded in the URL and expires after the specified duration.

## Usage

```python
from edupaid import Edupaid
from edupaid.models.request import EdupaidGenerateParentTokenRequest

client = Edupaid()

request = EdupaidGenerateParentTokenRequest(
    parentTimebackId="parent-123",
    expiryMinutes=60,  # Optional, defaults to 60
)

result = client.service.generate_parent_token(request)

print(f"Portal URL: {result.url}")
# Redirect parent to this URL to access the subscription portal
```

## Request

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| parentTimebackId | str | Yes | - | The Timeback identifier for the parent |
| expiryMinutes | int | No | 60 | Token expiration time in minutes |

## Response

| Field | Type | Description |
|-------|------|-------------|
| url | str | The URL to the Students app subscription portal with embedded token |

## Errors

| Status | Error | Description |
|--------|-------|-------------|
| 400 | ValidationError | Invalid request body |
| 401 | AuthError | Invalid or missing API key |
| 500 | ServerError | Internal server error |

## Examples

### Default Expiry (60 minutes)

```python
request = EdupaidGenerateParentTokenRequest(
    parentTimebackId="parent-abc-123",
)

result = client.service.generate_parent_token(request)
# Token expires in 60 minutes
```

### Custom Expiry

```python
request = EdupaidGenerateParentTokenRequest(
    parentTimebackId="parent-abc-123",
    expiryMinutes=120,  # 2 hours
)

result = client.service.generate_parent_token(request)
```

### Short-lived Token

```python
request = EdupaidGenerateParentTokenRequest(
    parentTimebackId="parent-abc-123",
    expiryMinutes=5,  # 5 minutes for immediate use
)

result = client.service.generate_parent_token(request)
```

## Use Case

This endpoint is typically used when a parent needs to access the subscription management portal:

1. Parent clicks "Manage Subscription" in your app
2. Your backend calls `generate_parent_token` with their Timeback ID
3. Redirect the parent to the returned URL
4. Parent can view/manage their subscription in the Edupaid portal

