# submit_token

Submit a learning token for a student.

Validates token input, saves the token, and updates prerequisite slots accordingly. Invalid tokens are recorded in bad_tokens for further inspection.

## Usage

```python
from edupaid import Edupaid
from edupaid.enums.TokenType import EdupaidTokenType
from edupaid.models.request import EdupaidSubmitTokenRequest

client = Edupaid()

request = EdupaidSubmitTokenRequest(
    studentId="student-123",
    timeBackAppId="alpha-anywhere",
    type=EdupaidTokenType.MASTERY,
    data='{"curriculumId":"cur-1","score":95}',
    evidenceId="ev-789",
)

result = client.service.submit_token(request)

print(f"Token submitted with ID: {result.id}")
```

## Request

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| studentId | str | Yes | Timeback student identifier |
| timeBackAppId | str | Yes | App identifier |
| type | EdupaidTokenType | Yes | Token type (MASTERY or TWO_X) |
| data | str | Yes | JSON string containing curriculumId and other token-specific data |
| evidenceId | str | Yes | Evidence identifier |

### EdupaidTokenType

- `MASTERY` - Mastery token
- `TWO_X` - TwoX token

## Response

| Field | Type | Description |
|-------|------|-------------|
| id | str | Token submission identifier |

## Errors

| Status | Error | Description |
|--------|-------|-------------|
| 400 | ValidationError | Invalid request body |
| 401 | AuthError | Invalid or missing API key |
| 404 | NotFoundError | Student or app not found, or not approved |
| 500 | ServerError | Internal server error |

## Examples

### Submit Mastery Token

```python
import json

request = EdupaidSubmitTokenRequest(
    studentId="student-123",
    timeBackAppId="alpha-anywhere",
    type=EdupaidTokenType.MASTERY,
    data=json.dumps({
        "curriculumId": "math-101",
        "score": 95,
        "completedAt": "2024-01-15T10:00:00Z"
    }),
    evidenceId="assessment-result-456",
)

result = client.service.submit_token(request)
```

### Submit TwoX Token

```python
request = EdupaidSubmitTokenRequest(
    studentId="student-123",
    timeBackAppId="alpha-reading",
    type=EdupaidTokenType.TWO_X,
    data='{"curriculumId":"reading-201"}',
    evidenceId="activity-789",
)

result = client.service.submit_token(request)
```

