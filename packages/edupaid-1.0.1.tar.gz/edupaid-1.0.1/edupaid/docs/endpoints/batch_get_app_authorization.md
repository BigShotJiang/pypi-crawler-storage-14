# batch_get_app_authorization

Get learning track authorization status for multiple students.

Returns authorization status for multiple students for a single learning track. Non-existent student IDs are treated as locked with payment modes rather than errors.

## Usage

```python
from edupaid import Edupaid
from edupaid.models.request import EdupaidBatchGetLearningTrackAuthorizationRequest

client = Edupaid()

request = EdupaidBatchGetLearningTrackAuthorizationRequest(
    learningTrackId="track-123",
    studentIds=["student-1", "student-2", "student-3"],
)

result = client.service.batch_get_app_authorization(request)

print(f"Track: {result.learningTrackId}")
for r in result.results:
    if r.error:
        print(f"{r.studentId}: Error - {r.error}")
    else:
        print(f"{r.studentId}: {r.status}")
```

## Request

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| learningTrackId | str | Yes | The learning track identifier |
| studentIds | List[str] | Yes | List of student IDs (max 100) |

## Response

| Field | Type | Description |
|-------|------|-------------|
| learningTrackId | str | The queried learning track ID |
| results | List[EdupaidBatchLearningTrackAuthorizationResult] | Per-student results |

### EdupaidBatchLearningTrackAuthorizationResult

| Field | Type | Description |
|-------|------|-------------|
| studentId | str | The student identifier |
| track | EdupaidUnifiedLearningTrack | Optional. Track details if found |
| defaulted | bool | Optional. Whether authorization has defaulted |
| status | EdupaidAuthorizationStatus | Optional. Authorization status |
| error | str | Optional. Error message if lookup failed |

## Errors

| Status | Error | Description |
|--------|-------|-------------|
| 400 | ValidationError | Invalid request (missing fields, empty array, >100 students) |
| 401 | AuthError | Invalid or missing API key |
| 404 | NotFoundError | Learning track not found |
| 500 | ServerError | Internal server error |

## Examples

### Mixed Results

```python
result = client.service.batch_get_app_authorization(request)

for r in result.results:
    if r.error:
        print(f"{r.studentId}: Error - {r.error}")
    elif r.status == EdupaidAuthorizationStatus.UNLOCKED:
        print(f"{r.studentId}: Active subscription")
    elif r.status == EdupaidAuthorizationStatus.LOCKED:
        print(f"{r.studentId}: Needs payment")
        if r.track and r.track.paymentModes:
            for mode in r.track.paymentModes:
                print(f"  Option: {mode.currency} {mode.amount}")
```

### Check All Students Have Access

```python
result = client.service.batch_get_app_authorization(request)

all_unlocked = all(
    r.status == EdupaidAuthorizationStatus.UNLOCKED
    for r in result.results
    if not r.error
)

if all_unlocked:
    print("All students have access!")
```

