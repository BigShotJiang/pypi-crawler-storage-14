# get_app_authorization

Get learning track authorization status for a student.

Verifies the API key, validates input, fetches the learning track and student, and returns whether the track is locked, unlocked, scheduled, or defaulted along with payment modes and scheduling information.

## Usage

```python
from edupaid import Edupaid
from edupaid.models.request import EdupaidGetLearningTrackAuthorizationRequest

client = Edupaid()

request = EdupaidGetLearningTrackAuthorizationRequest(
    studentId="student-123",
    learningTrackId="track-456",
)

result = client.service.get_app_authorization(request)

print(result.status)  # "unlocked", "locked", "scheduled", or "defaulted"
print(result.defaulted)  # bool
print(result.track)  # EdupaidUnifiedLearningTrack
```

## Request

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| studentId | str | Yes | The Timeback student identifier |
| learningTrackId | str | Yes | The learning track identifier |

## Response

| Field | Type | Description |
|-------|------|-------------|
| track | EdupaidUnifiedLearningTrack | Learning track details |
| defaulted | bool | Whether the authorization has defaulted |
| status | EdupaidAuthorizationStatus | Authorization status |

### EdupaidUnifiedLearningTrack

| Field | Type | Description |
|-------|------|-------------|
| learningTrackId | str | Learning track identifier |
| learningTrackName | str | Human-readable track name |
| appId | str | Application identifier |
| isLocked | bool | Whether access is currently locked |
| paymentModes | List[EdupaidPaymentMode] | Optional. Available payment options |
| scheduledChargeDate | str | Optional. ISO date-time for next charge |
| frequency | EdupaidPaymentFrequency | Optional. Payment frequency |

### EdupaidAuthorizationStatus

- `unlocked` - Active subscription, access granted
- `locked` - No subscription, access denied
- `scheduled` - Upcoming payment scheduled
- `defaulted` - Subscription expired/defaulted

## Errors

| Status | Error | Description |
|--------|-------|-------------|
| 400 | ValidationError | Invalid request body (missing fields, invalid JSON) |
| 401 | AuthError | Invalid or missing API key |
| 404 | NotFoundError | Learning track not found or not available for student |
| 500 | ServerError | Internal server error |

## Examples

### Unlocked Track

```python
result = client.service.get_app_authorization(request)
# result.status == EdupaidAuthorizationStatus.UNLOCKED
# result.defaulted == False
# result.track.isLocked == False
```

### Locked Track with Payment Options

```python
result = client.service.get_app_authorization(request)
# result.status == EdupaidAuthorizationStatus.LOCKED
# result.track.isLocked == True
# result.track.paymentModes contains available payment options
for mode in result.track.paymentModes:
    print(f"{mode.payee}: {mode.currency} {mode.amount} ({mode.frequency})")
```

### Scheduled Track

```python
result = client.service.get_app_authorization(request)
# result.status == EdupaidAuthorizationStatus.SCHEDULED
# result.track.scheduledChargeDate contains next charge date
```

