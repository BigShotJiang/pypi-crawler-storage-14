# list_app_authorizations

List learning track authorizations for a student.

Looks up a student by timebackStudentId and returns all their track authorizations categorized as locked, unlocked, scheduled, or defaulted. If the student does not exist, returns 200 with all tracks as locked.

## Usage

```python
from edupaid import Edupaid
from edupaid.models.request import EdupaidListLearningTrackAuthorizationsRequest

client = Edupaid()

request = EdupaidListLearningTrackAuthorizationsRequest(
    timebackStudentId="student-123",
    providerId=client.service.provider_id,  # Optional
)

result = client.service.list_app_authorizations(request)

# Access tracks by status
for track in result.unlockedTracks:
    print(f"Active: {track.learningTrackName}")

for track in result.lockedTracks:
    print(f"Locked: {track.learningTrackName}")
    if track.paymentModes:
        for mode in track.paymentModes:
            print(f"  Pay: {mode.currency} {mode.amount}")
```

## Request

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| timebackStudentId | str | Yes | The Timeback student identifier |
| providerId | str | No | Provider identifier (optional filter) |

## Response

| Field | Type | Description |
|-------|------|-------------|
| unlockedTracks | List[EdupaidUnifiedLearningTrack] | Active subscriptions |
| lockedTracks | List[EdupaidUnifiedLearningTrack] | Tracks requiring payment |
| scheduledTracks | List[EdupaidUnifiedLearningTrack] | Upcoming payments scheduled |
| defaultedTracks | List[EdupaidUnifiedLearningTrack] | Expired/defaulted subscriptions |

### EdupaidUnifiedLearningTrack

| Field | Type | Description |
|-------|------|-------------|
| learningTrackId | str | Learning track identifier |
| learningTrackName | str | Human-readable track name |
| appId | str | Application identifier |
| isLocked | bool | Whether access is currently locked |
| paymentModes | List[EdupaidPaymentMode] | Optional. Available payment options |
| scheduledChargeDate | str | Optional. ISO date-time for next charge |
| frequency | EdupaidPaymentFrequency | Optional. Payment frequency |

## Errors

| Status | Error | Description |
|--------|-------|-------------|
| 400 | ValidationError | Invalid request body (missing fields, invalid JSON) |
| 401 | AuthError | Invalid or missing API key |
| 500 | ServerError | Internal server error |

**Note:** This endpoint does not return 404 for missing students. Instead, it returns 200 with all tracks as locked.

## Examples

### Student with Multiple Status Categories

```python
result = client.service.list_app_authorizations(request)

print(f"Unlocked: {len(result.unlockedTracks)}")
print(f"Locked: {len(result.lockedTracks)}")
print(f"Scheduled: {len(result.scheduledTracks)}")
print(f"Defaulted: {len(result.defaultedTracks)}")
```

### New Student (All Tracks Locked)

```python
result = client.service.list_app_authorizations(request)
# result.unlockedTracks == []
# result.lockedTracks contains all available tracks with payment options
# result.scheduledTracks == []
# result.defaultedTracks == []
```

