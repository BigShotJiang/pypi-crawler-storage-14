"""
Edupaid client - main entry point for the Edupaid API.

Usage:
    from edupaid import Edupaid

    # Using environment variables (EDUPAID_API_KEY, EDUPAID_PROVIDER_ID, EDUPAID_JWT_SECRET)
    client = Edupaid()

    # Or passing credentials directly
    client = Edupaid(
        api_key="your-api-key",
        provider_id="your-provider-id",
        jwt_secret="your-jwt-secret",
    )

    # Access API methods via the service
    result = client.service.get_app_authorization(student_id="...", learning_track_id="...")

Reference: edupaid/docs/edupaid_api_docs.md for available API endpoints.
"""

from typing import Optional

from edupaid.config import Settings
from edupaid.http import HttpClient
from edupaid.service import EdupaidService


class Edupaid:
    """
    Top-level client for the Edupaid API.

    Users import via `from edupaid import Edupaid`.

    Attributes:
        settings: Validated configuration settings.
        service: EdupaidService instance for making API calls.

    Example:
        client = Edupaid()
        auth = client.service.get_app_authorization(
            student_id="student-123",
            learning_track_id="track-456"
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        provider_id: Optional[str] = None,
        jwt_secret: Optional[str] = None,
        environment: Optional[str] = None,
    ):
        """
        Initialize the Edupaid client.

        Args:
            api_key: API key for authentication (falls back to EDUPAID_API_KEY env var).
            provider_id: Provider identifier (falls back to EDUPAID_PROVIDER_ID env var).
            jwt_secret: JWT secret for webhooks (falls back to EDUPAID_JWT_SECRET env var).
            environment: Target environment (falls back to EDUPAID_ENVIRONMENT, default 'production').

        Raises:
            ConfigurationError: If required credentials are missing or invalid.
        """
        # Load and validate configuration
        self.settings = Settings(
            api_key=api_key,
            provider_id=provider_id,
            jwt_secret=jwt_secret,
            environment=environment,
        )

        # Create HTTP client with API key
        self._http = HttpClient(
            base_url=self.settings.api_base_url,
            api_key=self.settings.api_key,  # type: ignore[arg-type]
        )

        # Expose the service for API calls
        # Pass settings so service has access to provider_id for requests
        self.service = EdupaidService(http=self._http, settings=self.settings)
