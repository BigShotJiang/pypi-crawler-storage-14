from owner_change_main import OwnerChangeApp

if __name__ == "__main__":
    app = OwnerChangeApp('prod')
    app.mainloop()
