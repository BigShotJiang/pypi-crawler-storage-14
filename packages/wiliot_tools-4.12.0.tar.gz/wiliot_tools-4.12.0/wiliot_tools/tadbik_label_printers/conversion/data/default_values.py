default_config = {
        "operator_name": ['Adrian', 'Liel', 'Yaniv', 'Yael'],
        "inlay": [117, 169],
        "seq_assy_reel": 100,
        "converted_reels_serial_number": 200,
        "number_of_lanes": [str(i) for i in range(1, 7)],
        "printer_name": "",
}