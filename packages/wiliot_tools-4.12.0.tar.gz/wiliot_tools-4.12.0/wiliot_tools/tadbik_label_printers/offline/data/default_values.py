default_config = {
        "operator_name": ['Adrian', 'Liel', 'Yaniv', 'Yael'],
        "inlay": [117, 169],
        "printer_name": "",
        "converted_reel_name_length": 18,
        "sample_test_first_ext_id_length": 8,
        "sample_test_last_ext_id_length": 8,
        "fg_reel_first_ext_id_length": 8,
        "separator": "T",
}