#
# Pavlin Georgiev, Softel Labs
#
# This is a proprietary file and may not be copied,
# distributed, or modified without express permission
# from the owner. For licensing inquiries, please
# contact pavlin@softel.bg.
#
# 2025
#

import numpy as np

import gi
gi.require_version('Gst', '1.0')
gi.require_version('GstRtspServer', '1.0')
from gi.repository import Gst, GObject, GstRtspServer, GLib
Gst.init(None)

from sciveo.tools.logger import *
from sciveo.media.capture.cam import CameraDaemon


class RTSPFactoryBase(GstRtspServer.RTSPMediaFactory):
  def __init__(self, width, height, fps):
    super().__init__()
    self.width = width
    self.height = height
    self.fps = fps
    self.set_shared(True)

  def do_create_element(self, url):
    pipeline_str = (
      f"appsrc name=mysrc is-live=true block=true format=time "
      f"caps=video/x-raw,format=BGR,width={self.width},height={self.height},framerate={self.fps}/1 "
      "! videoconvert "
      "! x264enc tune=zerolatency speed-preset=ultrafast "
      "! rtph264pay config-interval=1 name=pay0 pt=96"
    )
    return Gst.parse_launch(pipeline_str)

  def do_configure(self, rtsp_media):
    self.appsrc = rtsp_media.get_element().get_child_by_name("mysrc")
    self.appsrc.connect("need-data", self.on_need_data)
    self.timestamp = 0

  def on_need_data(self, src, length):
    frame = self.next_frame()

    data = frame.tobytes()
    buf = Gst.Buffer.new_allocate(None, len(data), None)
    buf.fill(0, data)
    buf.duration = Gst.SECOND // self.fps
    buf.pts = buf.dts = self.timestamp
    self.timestamp += buf.duration
    src.emit("push-buffer", buf)

  def next_frame(self):
    return np.zeros((self.height, self.width, 3), dtype=np.uint8)

  def serve(self, host="0.0.0.0", port=8554, stream="test"):
    rtsp_url = f"rtsp://{host}:{port}/{stream}"
    server = GstRtspServer.RTSPServer()
    server.set_address(host)
    server.set_service(str(port))

    mount_points = server.get_mount_points()
    mount_points.add_factory(f"/{stream}", self)

    server.attach(None)
    info(f"RTSP server {type(self).__name__} running at {rtsp_url}")
    GLib.MainLoop().run()


"""
  RTSP TV-like Color Bars Test Generator
"""
class ColorBarsGenerator:
  """
  Generates standard vertical color bars (SMPTE/EBU-like) for testing.
  """
  def __init__(self, width=640, height=480):
    self.width = width
    self.height = height
    self.colors = [
      (255, 255, 255),  # White
      (0, 255, 255),    # Yellow
      (255, 255, 0),    # Cyan
      (0, 255, 0),      # Green
      (255, 0, 255),    # Magenta
      (0, 0, 255),      # Red
      (255, 0, 0),      # Blue
      (0, 0, 0)         # Black
    ]
    self.n_colors = len(self.colors)

  def next_frame(self):
    frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
    bar_width = self.width // self.n_colors

    for i, color in enumerate(self.colors):
      start_x = i * bar_width
      end_x = start_x + bar_width if i < self.n_colors - 1 else self.width
      frame[:, start_x:end_x] = color

    return frame


class ColorBarFactory(RTSPFactoryBase):
  def __init__(self, width, height, fps):
    super().__init__(width, height, fps)
    self.gen = ColorBarsGenerator(width=width, height=height)

  def next_frame(self):
    return self.gen.next_frame()


class CamFactory(ColorBarFactory):
  def __init__(self, cam_id, width, height, fps):
    super().__init__(width, height, fps)
    self.cam = CameraDaemon(cam_id=cam_id)
    self.cam.start()

  def next_frame(self):
    frame = self.cam.read()
    if frame is None:
      frame = super().next_frame()
    return frame


if __name__ == "__main__":

    # server = ColorBarFactory(640, 480, 10)
    # server.serve(host="0.0.0.0", port=8554, stream="test")

    server = CamFactory(0, 640, 480, 30)
    server.serve(host="0.0.0.0", port=8554, stream="camera")
