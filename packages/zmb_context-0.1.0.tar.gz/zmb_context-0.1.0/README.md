# ZMB: Zero Man Business

This repository contains the ZMB Kernel and the "Context Architect" CLI tool.

## Context Architect

A CLI tool to generate optimized context files for AI coding assistants.

### Installation

```bash
pip install .
```

### Usage

```bash
context-architect scan
context-architect generate --output context.md
context-architect generate --focus auth
```
