.. _general_examples:

Gallery
-------

Below is a gallery of examples which use PyProximal operators and utilities.
