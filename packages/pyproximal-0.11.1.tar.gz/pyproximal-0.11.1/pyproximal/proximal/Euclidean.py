from typing import Union

import numpy as np
from pylops.utils.typing import NDArray

from pyproximal.projection import EuclideanBallProj
from pyproximal.ProxOperator import ProxOperator, _check_tau


class Euclidean(ProxOperator):
    r"""Euclidean norm proximal operator.

    Proximal operator of the Euclidean norm: :math:`\sigma \|\mathbf{x}\|_2 =
    \sigma \sqrt{\sum x_i^2}`.

    Parameters
    ----------
    sigma : :obj:`int`, optional
        Multiplicative coefficient of :math:`L_{2}` norm

    Notes
    -----
    The Euclidean proximal operator is defined as:

    .. math::

        \prox_{\tau \sigma \|\cdot\|_2}(\mathbf{x}) =
        \left(1 - \frac{\tau \sigma }{\max\{\|\mathbf{x}\|_2,
        \tau \sigma \}}\right) \mathbf{x}

    This operator is sometimes called *block soft thresholding*.

    Moreover, as the conjugate of the Euclidean norm is the orthogonal
    projection of its dual norm (i.e., Euclidean norm) onto a unit ball,
    its dual operator is defined as:

    .. math::

        \prox^*_{\tau \sigma \|\cdot\|_2}(\mathbf{x}) =
        \frac{\sigma \mathbf{x}}{\max\{\|\mathbf{x}\|_2, \sigma\}}

    """

    def __init__(self, sigma: float = 1.0) -> None:
        super().__init__(None, True)
        self.sigma = sigma

    def __call__(self, x: NDArray) -> float:
        return float(self.sigma * np.linalg.norm(x))

    @_check_tau
    def prox(self, x: NDArray, tau: float) -> NDArray:
        x = (
            1.0 - (tau * self.sigma) / max(float(np.linalg.norm(x)), tau * self.sigma)
        ) * x
        return x

    @_check_tau
    def proxdual(self, x: NDArray, tau: float) -> NDArray:
        x = self.sigma * x / (max(float(np.linalg.norm(x)), self.sigma))
        return x

    def grad(self, x: NDArray) -> NDArray:
        return self.sigma * x / np.linalg.norm(x)


class EuclideanBall(ProxOperator):
    r"""Euclidean ball proximal operator.

    Proximal operator of the Euclidean ball: :math:`Eucl_{[c, r]} =
    \{ \mathbf{x}: ||\mathbf{x} - \mathbf{c}||_2 \leq r \}`.

    Parameters
    ----------
    center : :obj:`np.ndarray` or :obj:`float`
        Center of the ball
    radius : :obj:`float`
        Radius

    Notes
    -----
    As the Euclidean ball is an indicator function, the proximal operator
    corresponds to its orthogonal projection
    (see :class:`pyproximal.projection.EuclideanBallProj` for details.

    """

    def __init__(self, center: Union[NDArray, float], radius: float) -> None:
        super().__init__(None, False)
        self.center = center
        self.radius = radius
        self.ball = EuclideanBallProj(self.center, self.radius)

    def __call__(self, x: NDArray) -> bool:
        return bool(np.linalg.norm(x - self.center) <= self.radius)

    @_check_tau
    def prox(self, x: NDArray, tau: float) -> NDArray:
        return self.ball(x)
