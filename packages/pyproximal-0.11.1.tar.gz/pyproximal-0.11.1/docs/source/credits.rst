.. _credits:

Contributors
============

*  `Matteo Ravasi <https://github.com/mrava87>`_, mrava87
*  `Nick Luiken <https://github.com/NickLuiken>`_, NickLuiken
*  `Eneko Uruñuela <https://github.com/eurunuela>`_, eurunuela
*  `Marcus Valtonen Örnhag <https://github.com/marcusvaltonen>`_, marcusvaltonen
*  `Olivier Leblanc <https://github.com/olivierleblanc>`_, olivierleblanc
*  `Toru Tamaki <https://github.com/tttamaki>`_, tttamaki