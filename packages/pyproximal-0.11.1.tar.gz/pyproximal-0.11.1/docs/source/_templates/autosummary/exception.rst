{{ fullname | escape | underline }}

.. currentmodule:: {{ module }}

.. autoexception:: {{ objname }}


.. raw:: html

     <div style='clear:both'></div>

