MAVEN_URL = "https://oss.sonatype.org/content/repositories/releases"
MAVEN_SNAPSHOT_URL = "https://oss.sonatype.org/content/repositories/snapshots"
