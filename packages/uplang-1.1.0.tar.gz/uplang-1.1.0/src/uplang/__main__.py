"""
Entry point for running UpLang as a module: python -m uplang
"""

from uplang.cli import main

if __name__ == "__main__":
    main()
