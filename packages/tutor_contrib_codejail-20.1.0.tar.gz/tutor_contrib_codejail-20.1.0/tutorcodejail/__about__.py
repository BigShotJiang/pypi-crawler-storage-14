"""Helps you keep your cool when creating dozens of open edX and eduNEXT environments."""
__version__ = "20.1.0"
