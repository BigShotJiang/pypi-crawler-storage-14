"""Utility modules for vMCP backend."""
