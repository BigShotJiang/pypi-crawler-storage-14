import{c}from"./index-D-zKcq0-.js";const e=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]],o=c("circle-x",e);export{o as C};
//# sourceMappingURL=circle-x-BqeoMQrq.js.map
