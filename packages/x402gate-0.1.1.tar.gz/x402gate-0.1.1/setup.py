from setuptools import setup, find_packages
from pathlib import Path

# To sprawi, że opis na PyPI będzie pobrany z Twojego README.md
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="x402gate",  # To jest nazwa, którą wpisuje się po pip install
    version="0.1.1",
    packages=find_packages(),
    install_requires=[
        "requests>=2.0.0",
        "fastapi>=0.60.0",
        "uvicorn>=0.12.0"
    ],
    author="402gate Team",
    author_email="402gate@gmail.com", # Możesz wpisać swój
    description="Middleware for x402 payment protocol on Base network",
    long_description=long_description,
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)



