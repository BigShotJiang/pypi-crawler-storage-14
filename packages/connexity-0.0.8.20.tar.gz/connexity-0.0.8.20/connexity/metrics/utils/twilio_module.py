import logging
from asyncio import sleep
from twilio.base.exceptions import TwilioRestException
from twilio.rest import Client

logger = logging.getLogger(__name__)


class TwilioCallManager:
    def __init__(self, client: Client):
        self.client = client
        self.account_sid = client.username

    async def get_call_duration(self, call_sid: str) -> float | None:
        """
        Fetches the call duration. On any error, logs and returns None.
        """
        try:
            call = self.client.calls(call_sid).fetch()
            return float(call.duration)
        except TwilioRestException as e:
            logger.warning(f"Connexity SDK: Error fetching call duration [{e.status}]: {e.msg}")
        except Exception as e:
            logger.error(f"Connexity SDK: Unexpected error fetching call duration: {e}", exc_info=True)
        return None

    async def get_call_recording_url(
            self,
            call_sid: str,
            *,
            max_retries: int = 3,
            delay_sec: int = 3
    ) -> str | None:
        """
        Try fetching the specific recording you just created.
        Retry up to max_retries times on 404.
        """
        for attempt in range(1, max_retries + 1):
            try:
                recordings = self.client.recordings.list(call_sid=call_sid)
                if recordings:
                    return f"{recordings[0].media_url}.wav"
            except TwilioRestException as e:
                if e.status == 404:
                    logger.debug(f"Connexity SDK: Attempt {attempt} got 404; retrying in {delay_sec}s…")
                else:
                    logger.warning(f"Connexity SDK: Unexpected error fetching recording URL: {e}")
                    return None

                if attempt < max_retries:
                    await sleep(delay_sec)
        logger.warning(f"Connexity SDK: Giving up after {max_retries} attempts to fetch recording URL")
        return None

    async def get_start_call_data(self, call_sid: str) -> str | None:
        """
        Fetches the call’s start_time in ISO format. On error, logs and returns None.
        """
        try:
            call = self.client.calls(call_sid).fetch()
            return call.start_time.isoformat().replace("+00:00", "Z")
        except TwilioRestException as e:
            logger.warning(f"Connexity SDK: Error fetching start time [{e.status}]: {e.msg}")
        except Exception as e:
            logger.error(f"Connexity SDK: Unexpected error fetching start time: {e}", exc_info=True)
        return None
