# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListInfluxdbSlowLogsRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'start_time': 'str',
        'end_time': 'str',
        'limit': 'int',
        'line_num': 'str',
        'operate_type': 'str',
        'node_id': 'str',
        'keywords': 'str',
        'max_cost_time': 'int',
        'min_cost_time': 'int',
        'database': 'str',
        'retention_policy': 'str'
    }

    attribute_map = {
        'start_time': 'start_time',
        'end_time': 'end_time',
        'limit': 'limit',
        'line_num': 'line_num',
        'operate_type': 'operate_type',
        'node_id': 'node_id',
        'keywords': 'keywords',
        'max_cost_time': 'max_cost_time',
        'min_cost_time': 'min_cost_time',
        'database': 'database',
        'retention_policy': 'retention_policy'
    }

    def __init__(self, start_time=None, end_time=None, limit=None, line_num=None, operate_type=None, node_id=None, keywords=None, max_cost_time=None, min_cost_time=None, database=None, retention_policy=None):
        r"""ListInfluxdbSlowLogsRequestBody

        The model defined in huaweicloud sdk

        :param start_time: 开始时间，格式为“yyyy-mm-ddThh:mm:ssZ”。 其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。注：开始时间不得早于当前时间30天。
        :type start_time: str
        :param end_time: 结束时间，格式为“yyyy-mm-ddThh:mm:ssZ”。 其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。注：结束时间不能晚于当前时间。
        :type end_time: str
        :param limit: 表示每次查询的日志条数，最大限制100条。
        :type limit: int
        :param line_num: 日志单行序列号，第一次查询时不需要此参数，下一次查询时需要使用，可从上一次查询的返回信息中获取。 说明：当次查询从line_num的下一条日志开始查询，不包含当前line_num日志。
        :type line_num: str
        :param operate_type: 语句类型，取空值，表示查询所有语句类型。 可取值：SELECT、DELETE 、SHOW 、DROP 、CREATE 、ALTER
        :type operate_type: str
        :param node_id: 节点ID，取空值，表示查询实例下所有允许查询的节点。 具体取值请参考查询实例列表和详情接口\&quot;ListInstances\&quot;中nodes字段数据结构说明的“id”。
        :type node_id: str
        :param keywords: 根据多个关键字搜索日志全文，表示同时匹配所有关键字。 - 最多支持10个关键字。 - 每个关键字最大长度不超过512个字符。
        :type keywords: str
        :param max_cost_time: 支持根据最大执行时间范围查找日志。单位：ms
        :type max_cost_time: int
        :param min_cost_time: 支持根据最小执行时间范围查找日志。单位：ms
        :type min_cost_time: int
        :param database: 数据库名称。
        :type database: str
        :param retention_policy: 保留策略。
        :type retention_policy: str
        """
        
        

        self._start_time = None
        self._end_time = None
        self._limit = None
        self._line_num = None
        self._operate_type = None
        self._node_id = None
        self._keywords = None
        self._max_cost_time = None
        self._min_cost_time = None
        self._database = None
        self._retention_policy = None
        self.discriminator = None

        self.start_time = start_time
        self.end_time = end_time
        self.limit = limit
        if line_num is not None:
            self.line_num = line_num
        if operate_type is not None:
            self.operate_type = operate_type
        if node_id is not None:
            self.node_id = node_id
        if keywords is not None:
            self.keywords = keywords
        if max_cost_time is not None:
            self.max_cost_time = max_cost_time
        if min_cost_time is not None:
            self.min_cost_time = min_cost_time
        if database is not None:
            self.database = database
        if retention_policy is not None:
            self.retention_policy = retention_policy

    @property
    def start_time(self):
        r"""Gets the start_time of this ListInfluxdbSlowLogsRequestBody.

        开始时间，格式为“yyyy-mm-ddThh:mm:ssZ”。 其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。注：开始时间不得早于当前时间30天。

        :return: The start_time of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._start_time

    @start_time.setter
    def start_time(self, start_time):
        r"""Sets the start_time of this ListInfluxdbSlowLogsRequestBody.

        开始时间，格式为“yyyy-mm-ddThh:mm:ssZ”。 其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。注：开始时间不得早于当前时间30天。

        :param start_time: The start_time of this ListInfluxdbSlowLogsRequestBody.
        :type start_time: str
        """
        self._start_time = start_time

    @property
    def end_time(self):
        r"""Gets the end_time of this ListInfluxdbSlowLogsRequestBody.

        结束时间，格式为“yyyy-mm-ddThh:mm:ssZ”。 其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。注：结束时间不能晚于当前时间。

        :return: The end_time of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._end_time

    @end_time.setter
    def end_time(self, end_time):
        r"""Sets the end_time of this ListInfluxdbSlowLogsRequestBody.

        结束时间，格式为“yyyy-mm-ddThh:mm:ssZ”。 其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。注：结束时间不能晚于当前时间。

        :param end_time: The end_time of this ListInfluxdbSlowLogsRequestBody.
        :type end_time: str
        """
        self._end_time = end_time

    @property
    def limit(self):
        r"""Gets the limit of this ListInfluxdbSlowLogsRequestBody.

        表示每次查询的日志条数，最大限制100条。

        :return: The limit of this ListInfluxdbSlowLogsRequestBody.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListInfluxdbSlowLogsRequestBody.

        表示每次查询的日志条数，最大限制100条。

        :param limit: The limit of this ListInfluxdbSlowLogsRequestBody.
        :type limit: int
        """
        self._limit = limit

    @property
    def line_num(self):
        r"""Gets the line_num of this ListInfluxdbSlowLogsRequestBody.

        日志单行序列号，第一次查询时不需要此参数，下一次查询时需要使用，可从上一次查询的返回信息中获取。 说明：当次查询从line_num的下一条日志开始查询，不包含当前line_num日志。

        :return: The line_num of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._line_num

    @line_num.setter
    def line_num(self, line_num):
        r"""Sets the line_num of this ListInfluxdbSlowLogsRequestBody.

        日志单行序列号，第一次查询时不需要此参数，下一次查询时需要使用，可从上一次查询的返回信息中获取。 说明：当次查询从line_num的下一条日志开始查询，不包含当前line_num日志。

        :param line_num: The line_num of this ListInfluxdbSlowLogsRequestBody.
        :type line_num: str
        """
        self._line_num = line_num

    @property
    def operate_type(self):
        r"""Gets the operate_type of this ListInfluxdbSlowLogsRequestBody.

        语句类型，取空值，表示查询所有语句类型。 可取值：SELECT、DELETE 、SHOW 、DROP 、CREATE 、ALTER

        :return: The operate_type of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._operate_type

    @operate_type.setter
    def operate_type(self, operate_type):
        r"""Sets the operate_type of this ListInfluxdbSlowLogsRequestBody.

        语句类型，取空值，表示查询所有语句类型。 可取值：SELECT、DELETE 、SHOW 、DROP 、CREATE 、ALTER

        :param operate_type: The operate_type of this ListInfluxdbSlowLogsRequestBody.
        :type operate_type: str
        """
        self._operate_type = operate_type

    @property
    def node_id(self):
        r"""Gets the node_id of this ListInfluxdbSlowLogsRequestBody.

        节点ID，取空值，表示查询实例下所有允许查询的节点。 具体取值请参考查询实例列表和详情接口\"ListInstances\"中nodes字段数据结构说明的“id”。

        :return: The node_id of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._node_id

    @node_id.setter
    def node_id(self, node_id):
        r"""Sets the node_id of this ListInfluxdbSlowLogsRequestBody.

        节点ID，取空值，表示查询实例下所有允许查询的节点。 具体取值请参考查询实例列表和详情接口\"ListInstances\"中nodes字段数据结构说明的“id”。

        :param node_id: The node_id of this ListInfluxdbSlowLogsRequestBody.
        :type node_id: str
        """
        self._node_id = node_id

    @property
    def keywords(self):
        r"""Gets the keywords of this ListInfluxdbSlowLogsRequestBody.

        根据多个关键字搜索日志全文，表示同时匹配所有关键字。 - 最多支持10个关键字。 - 每个关键字最大长度不超过512个字符。

        :return: The keywords of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._keywords

    @keywords.setter
    def keywords(self, keywords):
        r"""Sets the keywords of this ListInfluxdbSlowLogsRequestBody.

        根据多个关键字搜索日志全文，表示同时匹配所有关键字。 - 最多支持10个关键字。 - 每个关键字最大长度不超过512个字符。

        :param keywords: The keywords of this ListInfluxdbSlowLogsRequestBody.
        :type keywords: str
        """
        self._keywords = keywords

    @property
    def max_cost_time(self):
        r"""Gets the max_cost_time of this ListInfluxdbSlowLogsRequestBody.

        支持根据最大执行时间范围查找日志。单位：ms

        :return: The max_cost_time of this ListInfluxdbSlowLogsRequestBody.
        :rtype: int
        """
        return self._max_cost_time

    @max_cost_time.setter
    def max_cost_time(self, max_cost_time):
        r"""Sets the max_cost_time of this ListInfluxdbSlowLogsRequestBody.

        支持根据最大执行时间范围查找日志。单位：ms

        :param max_cost_time: The max_cost_time of this ListInfluxdbSlowLogsRequestBody.
        :type max_cost_time: int
        """
        self._max_cost_time = max_cost_time

    @property
    def min_cost_time(self):
        r"""Gets the min_cost_time of this ListInfluxdbSlowLogsRequestBody.

        支持根据最小执行时间范围查找日志。单位：ms

        :return: The min_cost_time of this ListInfluxdbSlowLogsRequestBody.
        :rtype: int
        """
        return self._min_cost_time

    @min_cost_time.setter
    def min_cost_time(self, min_cost_time):
        r"""Sets the min_cost_time of this ListInfluxdbSlowLogsRequestBody.

        支持根据最小执行时间范围查找日志。单位：ms

        :param min_cost_time: The min_cost_time of this ListInfluxdbSlowLogsRequestBody.
        :type min_cost_time: int
        """
        self._min_cost_time = min_cost_time

    @property
    def database(self):
        r"""Gets the database of this ListInfluxdbSlowLogsRequestBody.

        数据库名称。

        :return: The database of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._database

    @database.setter
    def database(self, database):
        r"""Sets the database of this ListInfluxdbSlowLogsRequestBody.

        数据库名称。

        :param database: The database of this ListInfluxdbSlowLogsRequestBody.
        :type database: str
        """
        self._database = database

    @property
    def retention_policy(self):
        r"""Gets the retention_policy of this ListInfluxdbSlowLogsRequestBody.

        保留策略。

        :return: The retention_policy of this ListInfluxdbSlowLogsRequestBody.
        :rtype: str
        """
        return self._retention_policy

    @retention_policy.setter
    def retention_policy(self, retention_policy):
        r"""Sets the retention_policy of this ListInfluxdbSlowLogsRequestBody.

        保留策略。

        :param retention_policy: The retention_policy of this ListInfluxdbSlowLogsRequestBody.
        :type retention_policy: str
        """
        self._retention_policy = retention_policy

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListInfluxdbSlowLogsRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
