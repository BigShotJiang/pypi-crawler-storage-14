# SPDX-License-Identifier: Apache-2.0
# Copyright 2024 Mike Schultz
from .version import __version__

__all__ = ["__version__"]
