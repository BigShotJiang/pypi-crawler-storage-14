# SPDX-License-Identifier: Apache-2.0
# Copyright 2024 Mike Schultz

__version__ = "0.6.17"
