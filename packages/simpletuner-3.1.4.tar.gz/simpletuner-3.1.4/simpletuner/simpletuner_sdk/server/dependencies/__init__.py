"""Dependencies for FastAPI routes."""
