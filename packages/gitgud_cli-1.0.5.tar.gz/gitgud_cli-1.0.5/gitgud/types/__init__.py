"""Git and AI type definitions."""

