if __name__ == "__main__":
    from gitgud.cli import main
    main()