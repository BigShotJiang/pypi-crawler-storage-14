"""
GitGud - AI-Powered Git Assistant

A command-line tool that makes Git operations effortless with
intelligent analysis and recommendations.
"""

__version__ = "1.0.5"
__author__ = "Syed Masrur Ahmed"
__email__ = "ahmedsyedmasrur@gmail.com"

