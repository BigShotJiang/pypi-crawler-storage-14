AlazarTech Deployment Tools
===========================

This repository contains utilities that are used inside AlazarTech to help
deploy new releases to customers.
