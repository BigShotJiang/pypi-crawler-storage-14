"""Logger configuration command."""

from .main import configure_logger

__all__ = ["configure_logger"]
