A basic coin flip component initialized with create-react-app.

## Setup

### Install dependencies

```bash
yarn install
```

### Dev Flow

Run the following to start the local dev server and view the app in your browser.

```bash
yarn start
```

### Building

Run the following to build the app in preparation for deploying to mcp-agent cloud.

```bash
yarn build
```
