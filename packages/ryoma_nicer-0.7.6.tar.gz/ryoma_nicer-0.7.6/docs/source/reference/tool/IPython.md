# PythonTool

PythonTool is a tool that allows you to run python script in IPython Kernel ([IPython](https://ipython.org/)).