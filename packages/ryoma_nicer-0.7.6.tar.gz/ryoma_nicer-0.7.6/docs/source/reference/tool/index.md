(ryoma-tool)=

# Tool Documentation

Ryoma tool is an interface that can be used by AI agents to interact with the data platform.

```{toctree}
:maxdepth: 2

IPython
pandas
pyarrow
pyspark
sql
```
