(ryoma-data-sources)=

# Data Sources Documentation

The data sources is a list of data sources that Ryoma supports.
Ryoma can connect to these data sources, load data on the background and answer questions in natural language about the data.

```{toctree}
:maxdepth: 2

bigquery
file
postgresql
snowflake
```
