# Disguise Designer Plugin Pystub

Provides type hints and autocomplete support for all Designer objects available in the designer plugin system for [designer_plugin](https://github.com/disguise-one/python-plugin) module.

See [python-execution-api](https://developer.disguise.one/plugins/python-execution-api/) page for further details.

## Get started

Install designer-plugin-pystub:

```bash
pip install designer-plugin-pystub
```

Then use the stub file with designer_plugin:
```python
from designer_plugin.d3sdk import d3pythonscript
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from designer_plugin.pystub.d3 import *

@d3pythonscript
def get_surface_uid(name: str) -> int:
    surface: Screen2 = resourceManager.load(
        Path(f'objects/screen2/{name}.apx'),
        Screen2
    )
    return surface.uid
```

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
