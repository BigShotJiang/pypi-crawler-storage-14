# --------------------------------------------------------------------------
# FastAPI-fastkit package main routine
#
# @author bnbong
# --------------------------------------------------------------------------
from fastapi_fastkit.cli import fastkit_cli

fastkit_cli()
