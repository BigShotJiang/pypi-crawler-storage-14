import os
import sys
from datetime import time

from apexomni.http_private_v3 import HttpPrivate_v3

root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

from apexomni.constants import APEX_OMNI_HTTP_MAIN, \
    NETWORKID_OMNI_MAIN_ARB, APEX_OMNI_HTTP_TEST, NETWORKID_OMNI_TEST_BNB

print("Hello, Apex Omni")
# need api_key_credentials={'key': key,'secret': secret, 'passphrase': passphrase} for private api

key = '6e0b1a99-a012-cbde-0323-f37d77c5f59d'
secret = '3clXKDqoZGmta59PkjJ-ZIWDpSw7QLCfgHkCr3-3'
passphrase = 'zOMdeWiWijfJdnZ7n3Uv'

client = HttpPrivate_v3(APEX_OMNI_HTTP_TEST, network_id=NETWORKID_OMNI_TEST_BNB, api_key_credentials={'key': key,'secret': secret, 'passphrase': passphrase})
configs = client.configs_v3()

# search = client.search_v3(keyword="123",chainId=9)
# print( search)
# accountRes = client.get_account_v3()
# print(accountRes)
# getOrderRes = client.get_order_v3(id="765833172882555758")
# print(getOrderRes)
# getOrderResByClient = client.get_order_v3(clientOrderId="8956045185274888")
# print(getOrderResByClient)

transfer = client.get_account_v3()
record = client.prize_draw_records_v3(activityId="10000")
print(record)
print(transfer)
print("end, Apex Omni")



