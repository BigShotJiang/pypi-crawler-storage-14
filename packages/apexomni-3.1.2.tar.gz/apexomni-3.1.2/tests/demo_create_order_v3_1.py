import decimal
import os
import sys
import time

from apexomni.helpers.util import round_size

from apexomni.http_private_sign import HttpPrivateSign
import os
import sys
import time

from apexomni.http_private_sign import HttpPrivateSign

root_path = os.path.abspath(__file__)
root_path = '/'.join(root_path.split('/')[:-2])
sys.path.append(root_path)

from apexomni.constants import NETWORKID_TEST, APEX_OMNI_HTTP_TEST, APEX_OMNI_HTTP_MAIN, NETWORKID_OMNI_MAIN_ARB, \
    NETWORKID_OMNI_TEST_BNB

print("Hello, Apex omni")

key = '144bf7bd-de5b-5d17-40be-784d976dadbe'
secret = 'Va69MIsvg7SZPsnSF5DxJeZ-qTiqSt_t1tLWQo33'
passphrase = '9ABtpDyNhooUPC5QsN08'

seeds = '62c4e1a48dbaa16ef7e35c13c95a441c467a3207e8fef80b49611863320ef42779c59f71324908af68291be94e0ce02e25e41149f67c479a4235097f47466b251c'
l2Key = '0x6c2eb74273c402a237520e9b298c9bc970d9a6fa6babe50235b1510e71bea484'


client = HttpPrivateSign(APEX_OMNI_HTTP_TEST, network_id=NETWORKID_OMNI_TEST_BNB,
                         zk_seeds=seeds,zk_l2Key=l2Key,
                         api_key_credentials={'key': key, 'secret': secret, 'passphrase': passphrase})
configs = client.configs_v3()
accountData = client.get_account_v3()

currentTime = time.time()

symbolData = {}
for k, v in enumerate(configs.get('data').get('contractConfig').get('perpetualContract')):
    if v.get('symbol') == "BTC-USDT":
        symbolData = v
positions = accountData.get('positions')
print(positions)

# sample1
# Create a limit order
size = round_size("0.01", symbolData.get('stepSize'))
price = round_size("70000", symbolData.get('tickSize'))
createOrderRes = client.create_order_v3(symbol="BTC-USDT", side="BUY",price=price,
                                     type="LIMIT", size=size)
print(createOrderRes)

print("end, Apex Omni")


