"""Version information for queuerPy package."""

__version__ = "0.13.0"
__version_info__ = tuple(int(part) for part in __version__.split("."))

# For compatibility
VERSION = __version__
