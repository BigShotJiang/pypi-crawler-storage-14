# python/chen/__init__.py
from juliacall import Main as jl
import numpy as np
from pathlib import Path

# Point Julia to the Chen.jl package directory
chen_path = Path(__file__).parent.parent.parent.absolute()
chen_path_str = str(chen_path).replace('\\', '/')  # Fix Windows paths
jl.seval(f'import Pkg; Pkg.develop(path="{chen_path_str}")')
jl.seval("using Chen")

def sig(path, m):
    return np.asarray(jl.Chen.sig(np.asarray(path), m))

def logsig(path, m):
    d = path.shape[1]
    basis = jl.Chen.prepare(d, m)
    return np.asarray(jl.Chen.logsig(np.asarray(path), basis))