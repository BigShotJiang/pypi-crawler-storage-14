def subtract_numbers(a, b):
    return a - b
