from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='localrun',
    version='1.1.8',
    author='Fidal PalamParambil',
    author_email='mrfidal@proton.me',
    description='A simple local HTTP server similar to php -S',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/localrun',
    packages=find_packages(),
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Topic :: Internet :: WWW/HTTP :: HTTP Servers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
    python_requires='>=3.6',
    install_requires=[],
    entry_points={
        'console_scripts': [
            'localrun=cli:main',
        ],
    },
    keywords='http server local development',
    project_urls={
        'Bug Reports': 'https://github.com/ByteBreach/localrun/issues',
        'Source': 'https://github.com/ByteBreach/localrun',
    },
)