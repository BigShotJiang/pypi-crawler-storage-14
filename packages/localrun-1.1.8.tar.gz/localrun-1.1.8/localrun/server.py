import socketserver
from http.server import SimpleHTTPRequestHandler, HTTPServer
import datetime
import threading
import time

class LoggingHTTPRequestHandler(SimpleHTTPRequestHandler):
    last_log = None  
    
    def __init__(self, *args, **kwargs):
        self.silent = kwargs.pop('silent', False)
        super().__init__(*args, **kwargs)

    def log_message(self, format, *args):
        log_time = self.log_date_time_string()
        request_info = format % args
        log_entry = f"localrun - - [{log_time}] {request_info}"
        if not self.silent:
            print(log_entry)
        LoggingHTTPRequestHandler.last_log = log_entry 

    def log_date_time_string(self):
        return datetime.datetime.now().strftime('%d/%b/%Y %H:%M:%S')

def run_server(host='127.0.0.1', port=8000, silent=False):
    server_address = (host, port)
    
    handler_factory = lambda *args, **kwargs: LoggingHTTPRequestHandler(
        *args, silent=silent, **kwargs
    )
    
    if silent:
        httpd = HTTPServer(server_address, handler_factory)
        run_server._background_server = httpd
        run_server._background_server_running = True
        
        def server_thread():
            while run_server._background_server_running:
                httpd.handle_request()
        
        server_thread = threading.Thread(target=server_thread, daemon=False)
        server_thread.start()
        
        time.sleep(0.1)
        return f'{host}:{port} (running in background)'
    else:
        httpd = HTTPServer(server_address, handler_factory)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            httpd.server_close()
        return LoggingHTTPRequestHandler.last_log or f'{host}:{port}'

def stop_background_server():
    if hasattr(run_server, '_background_server_running') and run_server._background_server_running:
        run_server._background_server_running = False
        if hasattr(run_server, '_background_server'):
            run_server._background_server.shutdown()
            run_server._background_server.server_close()
            delattr(run_server, '_background_server')
        return True
    return False