# Pyarmor 9.0.8 (ci), 008036, 2025-11-29T21:00:06.612690
from .pyarmor_runtime import __pyarmor__
