from mddj._internal.cli import main

main()
