. $TESTDIR/testlib/pythonpath.sh

cat >> $HGRCPATH << EOF
[extensions]
docgraph=
EOF
