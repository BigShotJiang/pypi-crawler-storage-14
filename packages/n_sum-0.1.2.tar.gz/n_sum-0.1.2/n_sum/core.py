def sum_n(n: int) -> int:
    """Return the sum of the first n natural numbers."""
    return n * (n + 1) // 2


def sum_list(numbers: list) -> int:
    """Return the sum of a list of numbers."""
    return sum(numbers)


def sum_squares(n: int) -> int:
    """Return the sum of squares of first n natural numbers."""
    return n * (n + 1) * (2 * n + 1) // 6


def sum_cubes(n: int) -> int:
    """Return the sum of cubes of first n natural numbers."""
    return (n * (n + 1) // 2) ** 2


def arithmetic_series(a: int, d: int, n: int) -> int:
    """
    Return the sum of the first n terms of an arithmetic series.
    a: first term, d: common difference, n: number of terms
    """
    return n * (2 * a + (n - 1) * d) // 2


def geometric_series(a: float, r: float, n: int) -> float:
    """
    Return the sum of the first n terms of a geometric series.
    a: first term, r: common ratio, n: number of terms
    """
    if r == 1:
        return a * n
    return a * (1 - r ** n) / (1 - r)
