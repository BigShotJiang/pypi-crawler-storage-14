"""
Session persistence utilities for saving and restoring conversations.

Ported from the TypeScript sessionStore with the same behaviors:
- Stores summaries in an index file for quick listing
- Persists full message history per session id
- Supports autosave snapshots per profile
- Defensive parsing so corrupted files do not break the CLI
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from uuid import uuid4

from ..core.types import AssistantMessage, ConversationMessage, SystemMessage, ToolCallRequest, ToolMessage, UserMessage

DATA_ROOT_ENV = "EROSOLAR_DATA_DIR"
UTC = timezone.utc

@dataclass
class SessionSummary:
    id: str
    title: str
    created_at: str
    updated_at: str
    message_count: int = 0
    last_message_preview: str = ""
    profile: str = "general"
    provider: Optional[str] = None
    model: Optional[str] = None
    workspace_root: Optional[str] = None
    is_autosave: bool = False

@dataclass
class SessionData:
    messages: list[ConversationMessage] = field(default_factory=list)
    summary: SessionSummary = field(
        default_factory=lambda: SessionSummary(
            id="",
            title="",
            created_at=datetime.now(UTC).isoformat(),
            updated_at=datetime.now(UTC).isoformat(),
        )
    )


@dataclass
class SaveSessionOptions:
    profile: str
    provider: str
    model: str
    messages: list[ConversationMessage]
    id: Optional[str] = None
    title: Optional[str] = None
    workspace_root: Optional[str] = None
    autosave: bool = False

def _sessions_dir() -> Path:
    """Get the sessions directory path."""
    data_root = os.environ.get(DATA_ROOT_ENV)
    base = Path(data_root).expanduser() if data_root else Path.home() / ".erosolar"
    return base / "sessions"

def _ensure_dir() -> None:
    """Ensure the sessions directory exists."""
    dir_path = _sessions_dir()
    dir_path.mkdir(parents=True, exist_ok=True)

def _read_index() -> dict[str, SessionSummary]:
    """Read the session index file."""
    try:
        index_path = _sessions_dir() / "index.json"
        if index_path.exists():
            with open(index_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # Validate and migrate old formats if needed
                if isinstance(data, list):
                    # Old format - migrate to dict
                    index = {item["id"]: SessionSummary(**item) for item in data}
                    _write_index(index)
                    return index
                return {k: SessionSummary(**v) for k, v in data.items()}
        return {}
    except (json.JSONDecodeError, KeyError, TypeError):
        # Corrupted index - start fresh
        return {}

def _write_index(index: dict[str, SessionSummary]) -> None:
    """Write the session index file."""
    _ensure_dir()
    index_path = _sessions_dir() / "index.json"
    data = {k: {**v.__dict__, "id": k} for k, v in index.items()}
    with open(index_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)

def _read_session(session_id: str) -> Optional[SessionData]:
    """Read a session from disk."""
    try:
        session_path = _sessions_dir() / f"{session_id}.json"
        if not session_path.exists():
            return None
        with open(session_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        messages = [
            _deserialize_message(msg) for msg in data.get("messages", [])
        ]
        summary_data = data.get("summary", {})
        summary = SessionSummary(
            id=session_id,
            title=summary_data.get("title", ""),
            created_at=summary_data.get("created_at", _now()),
            updated_at=summary_data.get("updated_at", _now()),
            message_count=len(messages),
            last_message_preview=summary_data.get("last_message_preview", ""),
            profile=summary_data.get("profile", "general"),
            provider=summary_data.get("provider"),
            model=summary_data.get("model"),
            workspace_root=summary_data.get("workspace_root"),
            is_autosave=summary_data.get("is_autosave", False),
        )
        return SessionData(messages=messages, summary=summary)
    except (json.JSONDecodeError, KeyError):
        return None

def _write_session(session: SessionData) -> None:
    """Write a session to disk."""
    _ensure_dir()
    session_path = _sessions_dir() / f"{session.summary.id}.json"
    data = {
        "messages": [_serialize_message(msg) for msg in session.messages],
        "summary": {
            **session.summary.__dict__,
            "id": session.summary.id,
        },
    }
    with open(session_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, default=str)

def _serialize_message(message: ConversationMessage) -> dict[str, Any]:
    """Serialize a message for JSON storage."""
    base = {
        "role": message.role,
        "content": message.content,
        "timestamp": _now(),
    }
    if hasattr(message, "name"):
        base["name"] = message.name
    if hasattr(message, "tool_calls"):
        base["tool_calls"] = [
            {
                "id": call.id,
                "type": getattr(call, "type", None),
                "name": getattr(call, "name", None),
                "arguments": getattr(call, "arguments", {}),
                "function": (
                    {
                        "name": getattr(call.function, "name", None),
                        "arguments": getattr(call.function, "arguments", {}),
                    }
                    if getattr(call, "function", None)
                    else None
                ),
            }
            for call in message.tool_calls
        ]
    if hasattr(message, "tool_call_id"):
        base["tool_call_id"] = message.tool_call_id
    if getattr(message, "usage", None):
        base["usage"] = {
            "input_tokens": message.usage.input_tokens,
            "output_tokens": message.usage.output_tokens,
            "total_tokens": message.usage.total_tokens,
        }
    return base

def _deserialize_message(data: dict[str, Any]) -> ConversationMessage:
    """Deserialize a message from JSON."""
    role = data["role"]
    if role == "user":
        return UserMessage(content=data["content"], name=data.get("name"))
    elif role == "assistant":
        tool_calls = []
        if "tool_calls" in data:
            for tc_data in data["tool_calls"]:
                name = tc_data.get("name") or tc_data.get("function", {}).get("name")
                args = tc_data.get("arguments") or tc_data.get("function", {}).get("arguments") or {}
                tool_calls.append(
                    ToolCallRequest(
                        id=tc_data.get("id", ""),
                        type=tc_data.get("type"),
                        name=name,
                        arguments=args if isinstance(args, dict) else {},
                    )
                )
        return AssistantMessage(
            content=data["content"],
            tool_calls=tool_calls,
            name=data.get("name"),
        )
    elif role == "tool":
        return ToolMessage(
            content=data["content"],
            tool_call_id=data["tool_call_id"],
        )
    elif role == "system":
        return SystemMessage(content=data["content"])
    raise ValueError(f"Unknown message role: {role}")

def save_session(
    messages: list[ConversationMessage],
    session_id: Optional[str] = None,
    title: Optional[str] = None,
    profile: str = "general",
    provider: Optional[str] = None,
    model: Optional[str] = None,
    workspace_root: Optional[str] = None,
    autosave: bool = False,
) -> str:
    """Save a conversation session to disk."""
    if not messages:
        raise ValueError("Cannot save empty session")
    session_id = session_id or str(uuid4())
    summary = SessionSummary(
        id=session_id,
        title=title or _build_default_title(messages),
        created_at=_now(),
        updated_at=_now(),
        message_count=len(messages),
        last_message_preview=" ".join(messages[-1].content.split())[:100] if messages else "",
        profile=profile,
        provider=provider,
        model=model,
        workspace_root=workspace_root,
        is_autosave=autosave,
    )
    session = SessionData(messages=messages, summary=summary)
    _write_session(session)
    index = _read_index()
    index[session_id] = summary
    _write_index(index)
    return session_id

def load_session(session_id: str) -> Optional[SessionData]:
    """Load a session from disk by ID."""
    return _read_session(session_id)

def list_sessions(profile: Optional[str] = None) -> list[SessionSummary]:
    """List all saved sessions, optionally filtered by profile."""
    index = _read_index()
    summaries = list(index.values())
    if profile:
        summaries = [s for s in summaries if s.profile == profile]
    return sorted(summaries, key=lambda s: s.updated_at, reverse=True)

def delete_session(session_id: str) -> bool:
    """Delete a session from disk."""
    index = _read_index()
    if session_id not in index:
        return False
    session_path = _sessions_dir() / f"{session_id}.json"
    autosave_path = _sessions_dir() / f"{session_id}-autosave.json"
    session_path.unlink(missing_ok=True)
    autosave_path.unlink(missing_ok=True)
    del index[session_id]
    _write_index(index)
    return True


def save_session_snapshot(options: SaveSessionOptions) -> SessionSummary:
    """Wrapper to save a session using SaveSessionOptions."""
    session_id = save_session(
        messages=options.messages,
        session_id=options.id,
        title=options.title,
        profile=options.profile,
        provider=options.provider,
        model=options.model,
        workspace_root=options.workspace_root,
        autosave=options.autosave,
    )
    return _read_index().get(session_id) or SessionSummary(
        id=session_id,
        title=options.title or _build_default_title(options.messages),
        created_at=_now(),
        updated_at=_now(),
        message_count=len(options.messages),
        profile=options.profile,
        provider=options.provider,
        model=options.model,
        workspace_root=options.workspace_root,
    )


def load_session_by_id(session_id: str) -> Optional[SessionData]:
    """Alias for load_session."""
    return load_session(session_id)

def autosave_snapshot(session_id: str, messages: list[ConversationMessage]) -> None:
    """Create an autosave snapshot of the current session."""
    if not session_id:
        return
    try:
        # Load current session
        session = load_session(session_id)
        if not session:
            return
        # Update messages
        session.messages = messages
        session.summary.updated_at = _now()
        session.summary.message_count = len(messages)
        if messages:
            session.summary.last_message_preview = " ".join(messages[-1].content.split())[:100]
        # Write as autosave
        autosave_path = _sessions_dir() / f"{session_id}-autosave.json"
        data = {
            "messages": [_serialize_message(msg) for msg in session.messages],
            "summary": {
                **session.summary.__dict__,
                "id": session.summary.id,
                "is_autosave": True,
            },
        }
        with open(autosave_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
    except Exception:
        # Fail silently for autosave
        pass


def save_autosave_snapshot(profile: str, options: SaveSessionOptions) -> None:
    """Save an autosave snapshot for a profile (compat wrapper)."""
    session_id = options.id or f"autosave-{profile}"
    save_session(
        messages=options.messages,
        session_id=session_id,
        title=options.title,
        profile=options.profile,
        provider=options.provider,
        model=options.model,
        workspace_root=options.workspace_root,
        autosave=True,
    )
    autosave_snapshot(session_id, options.messages)

def restore_from_autosave(session_id: str) -> Optional[SessionData]:
    """Restore session from autosave if available."""
    autosave_path = _sessions_dir() / f"{session_id}-autosave.json"
    if not autosave_path.exists():
        return None
    try:
        with open(autosave_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        messages = [
            _deserialize_message(msg) for msg in data.get("messages", [])
        ]
        summary_data = data.get("summary", {})
        summary = SessionSummary(
            id=session_id,
            title=summary_data.get("title", ""),
            created_at=summary_data.get("created_at", _now()),
            updated_at=summary_data.get("updated_at", _now()),
            message_count=len(messages),
            last_message_preview=summary_data.get("last_message_preview", ""),
            profile=summary_data.get("profile", "general"),
            is_autosave=True,
        )
        return SessionData(messages=messages, summary=summary)
    except (json.JSONDecodeError, KeyError):
        return None


def load_autosave_snapshot(profile: str) -> Optional[SessionData]:
    """Load autosave snapshot for a profile."""
    return restore_from_autosave(f"autosave-{profile}")


def clear_autosave_snapshot(profile: str) -> None:
    """Remove autosave snapshot for a profile."""
    autosave_path = _sessions_dir() / f"autosave-{profile}-autosave.json"
    autosave_path.unlink(missing_ok=True)

def _build_default_title(messages: list[ConversationMessage]) -> str:
    for message in messages:
        if isinstance(message, UserMessage):
            condensed = " ".join(message.content.split())
            if condensed:
                return condensed[:160]
    return f"Session {datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S')}"

def _now() -> str:
    return datetime.now(UTC).isoformat() + "Z"

def _prune_orphans(index: dict[str, SessionSummary]) -> None:
    """Remove session files on disk that are not present in the index."""
    known = set(index.keys())
    try:
        for file in _sessions_dir().glob("*.json"):
            if file.name == "index.json" or "-autosave" in file.name:
                continue
            session_id = file.stem
            if session_id not in known:
                file.unlink(missing_ok=True)
    except Exception:
        return

# Clean up orphaned files on import to mirror TS behavior
_prune_orphans(_read_index())
