"""
Alpha Zero 2 Plugin - Competitive Multi-Agent RL Framework

A sophisticated reinforcement learning framework where autonomous agents
compete on code optimization tasks while recursively improving their own
implementations.

Principal Investigator: Bo Shang
Framework: erosolar_cli

Core Innovations:
- Recursive Self-Modification Engine: Agents modify their own tool source code
- Competitive Multi-Agent Framework: Tournament system with parallel execution
- Version-Controlled Self-Improvement: SHA-256 checkpoints with automatic rollback
- AST-Based Code Quality Metrics: Comprehensive evaluation across 10+ dimensions

This plugin is OPTIONAL. The core erosolar_cli functions as a complete
coding assistant without it. Enable this plugin when you want:
- Code quality evaluation and metrics
- Competitive agent tournaments
- Self-improvement tracking
- Performance introspection
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..core.tool_runtime import ToolDefinition, ToolSuite
from ..core.types import JSONSchemaObject
from . import Plugin, PluginCategory, PluginMetadata, register_plugin


@dataclass
class AlphaZeroConfig:
    """Configuration for Alpha Zero 2 plugin."""
    enable_introspection: bool = True
    enable_code_evaluation: bool = True
    enable_tournaments: bool = True
    enable_self_modification: bool = False  # Disabled by default for safety
    data_dir: Optional[str] = None
    verbose: bool = False


@register_plugin
class AlphaZeroPlugin(Plugin):
    """Alpha Zero 2 - Competitive Multi-Agent RL Framework."""

    metadata = PluginMetadata(
        id="alpha_zero",
        name="Alpha Zero 2",
        version="2.0.0",
        description="Competitive multi-agent RL framework for code optimization with recursive self-improvement",
        category=PluginCategory.RL,
        author="Bo Shang",
        requires_auth=False,
        dependencies=[],
        cli_commands=["alpha-zero tournament", "alpha-zero evaluate", "alpha-zero history"],
    )

    def __init__(self, working_dir: str, config: Optional[Dict[str, Any]] = None):
        super().__init__(working_dir, config)
        raw_config = config or {}
        self.az_config = AlphaZeroConfig(
            enable_introspection=raw_config.get("enable_introspection", True),
            enable_code_evaluation=raw_config.get("enable_code_evaluation", True),
            enable_tournaments=raw_config.get("enable_tournaments", True),
            enable_self_modification=raw_config.get("enable_self_modification", False),
            data_dir=raw_config.get("data_dir"),
            verbose=raw_config.get("verbose", False),
        )
        self._data_dir = Path(self.az_config.data_dir or working_dir) / ".alpha_zero"
        self._reward_system = None
        self._introspection_engine = None
        self._competition_framework = None

    def on_load(self) -> None:
        """Initialize Alpha Zero 2 components."""
        self._data_dir.mkdir(parents=True, exist_ok=True)

    def on_unload(self) -> None:
        """Cleanup Alpha Zero 2 resources."""
        # Save any pending state
        pass

    @property
    def reward_system(self):
        """Lazy-load reward system."""
        if self._reward_system is None:
            from ..alpha_zero import RewardSystem
            self._reward_system = RewardSystem(verbose=self.az_config.verbose)
        return self._reward_system

    @property
    def introspection_engine(self):
        """Lazy-load introspection engine."""
        if self._introspection_engine is None and self.az_config.enable_introspection:
            from ..alpha_zero import IntrospectionEngine
            self._introspection_engine = IntrospectionEngine(
                data_dir=self._data_dir / "introspection",
                verbose=self.az_config.verbose,
            )
        return self._introspection_engine

    @property
    def competition_framework(self):
        """Lazy-load competition framework."""
        if self._competition_framework is None:
            from ..alpha_zero import CompetitiveFramework
            self._competition_framework = CompetitiveFramework(
                data_dir=self._data_dir / "competitions",
            )
        return self._competition_framework

    def get_tool_suites(self) -> List[ToolSuite]:
        """Return Alpha Zero 2 tool suites."""
        tools: List[ToolDefinition] = []

        # Code evaluation tool (always available)
        if self.az_config.enable_code_evaluation:
            tools.append(self._create_evaluate_tool())

        # Tournament tool
        if self.az_config.enable_tournaments:
            tools.append(self._create_tournament_tool())

        # Introspection tools
        if self.az_config.enable_introspection:
            tools.extend(self._create_introspection_tools())

        # History tool
        tools.append(self._create_history_tool())

        # Metrics tool
        tools.append(self._create_metrics_tool())

        return [
            ToolSuite(
                id="plugin.alpha_zero",
                tools=tools,
                description="Competitive multi-agent RL framework for code optimization",
                name="Alpha Zero 2",
            )
        ]

    def _create_evaluate_tool(self) -> ToolDefinition:
        """Create code evaluation tool."""
        async def handler(code: str) -> Dict[str, Any]:
            """Evaluate code quality using Alpha Zero 2 metrics."""
            metrics = await self.reward_system.evaluate_code(code)
            reward = self.reward_system.calculate_reward(metrics)

            return {
                "reward_score": reward,
                "code_quality_score": metrics.code_quality_score,
                "algorithm_efficiency": metrics.algorithm_efficiency,
                "error_handling_score": metrics.error_handling_score,
                "documentation_score": metrics.documentation_score,
                "maintainability_index": metrics.maintainability_index,
                "security_score": metrics.security_score,
                "summary": self._format_metrics_summary(metrics, reward),
            }

        return ToolDefinition(
            name="alpha_zero_evaluate",
            description="Evaluate code quality using Alpha Zero 2's AST-based metrics across 10+ dimensions",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "code": {
                        "type": "string",
                        "description": "Code to evaluate",
                    }
                },
                required=["code"],
            ),
            handler=handler,
        )

    def _create_tournament_tool(self) -> ToolDefinition:
        """Create tournament runner tool."""
        async def handler(
            task_prompts: List[str],
            num_rounds: int = 5,
            verbose: bool = False,
        ) -> Dict[str, Any]:
            """Run a competitive tournament between agents."""
            from ..alpha_zero import TournamentRunner, TournamentConfig

            config = TournamentConfig(
                tournament_id=f"tournament_{__import__('time').time_ns()}",
                task_prompts=task_prompts,
                rounds_per_task=num_rounds,
                parallel_execution=True,
            )

            runner = TournamentRunner(
                data_dir=self._data_dir / "tournaments",
                verbose=verbose,
            )

            result = await runner.run(config)

            return {
                "tournament_id": result.tournament_id,
                "total_rounds": result.total_rounds,
                "agent1_wins": result.agent1_wins,
                "agent2_wins": result.agent2_wins,
                "agent1_win_rate": result.agent1_win_rate,
                "agent2_win_rate": result.agent2_win_rate,
                "rounds": [
                    {
                        "round": i + 1,
                        "task": r.task[:50] + "..." if len(r.task) > 50 else r.task,
                        "agent1_score": r.agent1_score,
                        "agent2_score": r.agent2_score,
                        "winner": r.winner,
                    }
                    for i, r in enumerate(result.rounds)
                ],
            }

        return ToolDefinition(
            name="alpha_zero_tournament",
            description="Run a competitive tournament between two AI agents on code optimization tasks",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "task_prompts": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of coding task prompts for the tournament",
                    },
                    "num_rounds": {
                        "type": "integer",
                        "description": "Number of rounds to run",
                        "default": 5,
                    },
                    "verbose": {
                        "type": "boolean",
                        "description": "Enable verbose logging",
                        "default": False,
                    },
                },
                required=["task_prompts"],
            ),
            handler=handler,
        )

    def _create_introspection_tools(self) -> List[ToolDefinition]:
        """Create introspection tools."""
        tools = []

        async def analyze_performance() -> Dict[str, Any]:
            """Analyze agent performance metrics."""
            if not self.introspection_engine:
                return {"error": "Introspection not enabled"}

            profile = self.introspection_engine.get_performance_profile()
            return {
                "avg_response_time_ms": profile.avg_response_time_ms,
                "total_tool_calls": profile.total_tool_calls,
                "tool_success_rate": profile.tool_success_rate,
                "code_quality_trend": profile.code_quality_trend,
                "suggestions": [s.dict() for s in profile.improvement_suggestions],
            }

        tools.append(ToolDefinition(
            name="alpha_zero_introspect",
            description="Analyze agent performance and get improvement suggestions",
            parameters=JSONSchemaObject(type="object", properties={}),
            handler=analyze_performance,
        ))

        return tools

    def _create_history_tool(self) -> ToolDefinition:
        """Create competition history tool."""
        async def handler() -> Dict[str, Any]:
            """Get historical competition data."""
            history = self.competition_framework.get_history()

            if not history.total_rounds:
                return {
                    "has_history": False,
                    "message": "No competition history found. Run a tournament first.",
                }

            return {
                "has_history": True,
                "total_rounds": history.total_rounds,
                "agent1_win_rate": history.agent1_win_rate,
                "agent2_win_rate": history.agent2_win_rate,
                "best_scores": history.best_scores,
                "quality_improvement": history.quality_improvement,
            }

        return ToolDefinition(
            name="alpha_zero_history",
            description="Get historical data from previous competitions and tournaments",
            parameters=JSONSchemaObject(type="object", properties={}),
            handler=handler,
        )

    def _create_metrics_tool(self) -> ToolDefinition:
        """Create metrics dashboard tool."""
        async def handler(
            timeframe: str = "all",
            include_trends: bool = True,
        ) -> Dict[str, Any]:
            """Get comprehensive metrics dashboard."""
            from ..alpha_zero import MetricsDashboard

            dashboard = MetricsDashboard(data_dir=self._data_dir)
            metrics = dashboard.get_metrics(timeframe=timeframe)

            result = {
                "timeframe": timeframe,
                "total_sessions": metrics.total_sessions,
                "total_code_evaluations": metrics.total_code_evaluations,
                "avg_code_quality": metrics.avg_code_quality,
                "avg_response_time_ms": metrics.avg_response_time_ms,
            }

            if include_trends:
                result["trends"] = {
                    "quality_trend": metrics.quality_trend,
                    "efficiency_trend": metrics.efficiency_trend,
                }

            return result

        return ToolDefinition(
            name="alpha_zero_metrics",
            description="Get comprehensive performance metrics and trends",
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "timeframe": {
                        "type": "string",
                        "enum": ["hour", "day", "week", "month", "all"],
                        "default": "all",
                        "description": "Time period for metrics",
                    },
                    "include_trends": {
                        "type": "boolean",
                        "default": True,
                        "description": "Include trend analysis",
                    },
                },
            ),
            handler=handler,
        )

    def _format_metrics_summary(self, metrics, reward: float) -> str:
        """Format metrics as a human-readable summary."""
        lines = [
            "Alpha Zero 2 Code Evaluation",
            "=" * 40,
            f"Overall Reward Score: {reward:.1f}/100",
            "",
            "Quality Dimensions:",
            f"  Code Quality:      {metrics.code_quality_score * 100:.1f}/100",
            f"  Algorithm Efficiency: {metrics.algorithm_efficiency * 100:.1f}/100",
            f"  Error Handling:    {metrics.error_handling_score * 100:.1f}/100",
            f"  Documentation:     {metrics.documentation_score * 100:.1f}/100",
            f"  Maintainability:   {metrics.maintainability_index * 100:.1f}/100",
            f"  Security:          {metrics.security_score * 100:.1f}/100",
        ]
        return "\n".join(lines)


# Convenience functions for direct use
def create_alpha_zero_plugin(
    working_dir: str,
    config: Optional[Dict[str, Any]] = None
) -> AlphaZeroPlugin:
    """Create and initialize an Alpha Zero 2 plugin instance."""
    plugin = AlphaZeroPlugin(working_dir, config)
    plugin.on_load()
    return plugin


def evaluate_code(code: str, working_dir: str = ".") -> Dict[str, Any]:
    """Quick code evaluation using Alpha Zero 2 metrics."""
    import asyncio
    plugin = create_alpha_zero_plugin(working_dir)
    tools = plugin.get_tool_suites()[0].tools

    for tool in tools:
        if tool.name == "alpha_zero_evaluate":
            return asyncio.run(tool.handler(code=code))

    return {"error": "Evaluate tool not found"}
