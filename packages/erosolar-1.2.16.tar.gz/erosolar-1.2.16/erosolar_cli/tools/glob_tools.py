"""
Glob tools for fast file pattern matching.

Features:
- Glob pattern support (**, *, ?)
- Sorted by modification time (newest first)
- Ignores common directories
- Head limiting
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

from ..core.tool_runtime import ToolDefinition
from ..core.types import (
    JSONSchemaArray,
    JSONSchemaBoolean,
    JSONSchemaNumber,
    JSONSchemaObject,
    JSONSchemaString,
)


# Directories to ignore during search
IGNORED_DIRS = {
    ".git",
    "node_modules",
    "dist",
    ".next",
    "build",
    "coverage",
    ".turbo",
    ".cache",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
}


def create_glob_tools(working_dir: str) -> list[ToolDefinition]:
    """
    Create glob pattern matching tool.

    Args:
        working_dir: Working directory for pattern matching

    Returns:
        List containing the Glob tool definition
    """
    working_path = Path(working_dir).resolve()

    async def glob_handler(args: dict[str, Any]) -> str:
        try:
            pattern = args.get("pattern", "")
            if not pattern or not isinstance(pattern, str) or not pattern.strip():
                return "Error: pattern must be a non-empty string."

            trimmed_pattern = pattern.strip()

            # Warn about overly broad patterns
            if trimmed_pattern in (".", "*", "**/*"):
                return (
                    f'Warning: Pattern "{pattern}" is too broad and will match many files. '
                    f'Please use a more specific pattern like "**/*.ts" or "src/**/*.js" to reduce context usage.'
                )

            path_arg = args.get("path")
            head_limit = args.get("head_limit", 20)  # Default to 20 files

            if not isinstance(head_limit, int):
                head_limit = 20

            # Resolve search path
            if path_arg and isinstance(path_arg, str):
                search_path = _resolve_path(working_path, path_arg)
            else:
                search_path = working_path

            # Perform glob search
            matches = _glob_search(search_path, pattern)

            # Sort by modification time (newest first)
            def get_mtime(file_path: Path) -> float:
                try:
                    return file_path.stat().st_mtime
                except Exception:
                    return 0.0

            sorted_matches = sorted(matches, key=get_mtime, reverse=True)

            # Convert to relative paths
            relative_paths = []
            for file_path in sorted_matches:
                try:
                    rel_path = file_path.relative_to(working_path)
                    relative_paths.append(str(rel_path))
                except ValueError:
                    relative_paths.append(str(file_path))

            if not relative_paths:
                return f"No files found matching pattern: {pattern}"

            # Apply head_limit
            total_matches = len(relative_paths)
            limited = relative_paths[:head_limit]
            truncated = total_matches > head_limit

            summary = "1 file found" if total_matches == 1 else f"{total_matches} files found"
            result = f'{summary} matching "{pattern}":'

            if truncated:
                result += f" (showing first {head_limit} of {total_matches})"

            result += "\n\n" + "\n".join(limited)

            if truncated:
                remaining = total_matches - head_limit
                result += f"\n\n... [{remaining} more files truncated. Use head_limit parameter to see more]"

            return result

        except Exception as error:
            return f"Error during glob search: {error}"

    return [
        ToolDefinition(
            name="Glob",
            description='Fast file pattern matching tool. Supports glob patterns like "**/*.js" or "src/**/*.ts". Returns matching file paths sorted by modification time.',
            parameters=JSONSchemaObject(
                type="object",
                properties={
                    "pattern": JSONSchemaString(type="string",
                        description='The glob pattern to match files against (e.g., "**/*.ts", "src/**/*.js", "*.md"). Avoid overly broad patterns like "." or "*".',
                    ),
                    "path": JSONSchemaString(type="string",
                        description="The directory to search in. If not specified, the current working directory will be used.",
                    ),
                    "head_limit": JSONSchemaNumber(type="number",
                        description="Maximum number of files to return. Defaults to 20.",
                    ),
                },
                required=["pattern"],
                additional_properties=False,
            ),
            handler=glob_handler,
            cacheable=True,
        )
    ]


def _resolve_path(working_dir: Path, path: str) -> Path:
    """Resolve a path relative to working directory."""
    path_str = path.strip()
    if os.path.isabs(path_str):
        return Path(path_str)
    return (working_dir / path_str).resolve()


def _glob_search(base_dir: Path, pattern: str) -> list[Path]:
    """
    Search for files matching glob pattern.

    Args:
        base_dir: Base directory to search in
        pattern: Glob pattern to match

    Returns:
        List of matching file paths
    """
    results: list[Path] = []
    regex = _glob_to_regex(pattern)

    def search(current_dir: Path) -> None:
        try:
            for entry in current_dir.iterdir():
                if entry.name in IGNORED_DIRS:
                    continue

                if entry.is_dir():
                    search(entry)
                elif entry.is_file():
                    # Test the full path against the pattern
                    if regex.search(str(entry)):
                        results.append(entry)
        except (PermissionError, OSError):
            # Silently ignore permission errors
            pass

    search(base_dir)
    return results


def _glob_to_regex(pattern: str) -> re.Pattern:
    """
    Convert glob pattern to regex.

    Args:
        pattern: Glob pattern

    Returns:
        Compiled regex pattern
    """
    # Escape special regex characters except glob wildcards
    escaped = re.escape(pattern)

    # Restore glob wildcards by unescaping them
    escaped = (
        escaped.replace(r"\*\*", "<!GLOBSTAR!>")  # Placeholder for **
        .replace(r"\*", "[^/]*")  # * matches any characters except /
        .replace("<!GLOBSTAR!>", ".*")  # ** matches any characters including /
        .replace(r"\?", ".")  # ? matches any single character
    )

    return re.compile(escaped + "$")
