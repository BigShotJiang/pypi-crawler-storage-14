"""
Cross-Language Tool Bridge - Python Side

Provides IPC-based communication between TypeScript and Python runtimes
for seamless tool execution across languages.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from .server import BridgeServer, start_bridge_server

__all__ = ["BridgeServer", "start_bridge_server"]
