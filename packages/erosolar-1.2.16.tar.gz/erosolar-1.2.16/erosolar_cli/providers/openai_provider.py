"""
OpenAI GPT provider with Responses API support.

Uses the new /v1/responses endpoint for GPT-5.1 and newer models.
Falls back to /v1/chat/completions for older models.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, AsyncIterator, Optional

from openai import AsyncOpenAI, OpenAI

logger = logging.getLogger(__name__)


def _safe_parse_arguments(arguments: Any, context: str = "") -> dict:
    """
    Safely parse tool call arguments, handling malformed JSON gracefully.

    Args:
        arguments: Raw arguments (str, dict, or other)
        context: Description of where parsing is happening (for logging)

    Returns:
        Parsed dict, or empty dict if parsing fails
    """
    if isinstance(arguments, dict):
        return arguments
    if not isinstance(arguments, str):
        return {}

    if not arguments.strip():
        return {}

    try:
        parsed = json.loads(arguments)
        return parsed if isinstance(parsed, dict) else {}
    except json.JSONDecodeError as e:
        logger.warning(f"Failed to parse tool arguments{' in ' + context if context else ''}: {e}")

        # Try multiple recovery strategies for truncated/malformed JSON
        fixed = arguments.rstrip()

        # Strategy 1: Close unterminated strings and add missing braces
        recovery_attempts = [
            # Try adding closing quote and brace
            fixed + '"}',
            # Try adding just closing brace
            fixed + '}',
            # Try adding closing quote, then brace
            fixed + '"' + '}',
            # Try with double closing braces (nested objects)
            fixed + '"}}',
            fixed + '}}',
            # Handle array endings
            fixed + '"}]',
            fixed + ']',
            fixed + '"}]}',
        ]

        for attempt in recovery_attempts:
            try:
                parsed = json.loads(attempt)
                if isinstance(parsed, dict):
                    logger.info(f"Recovered partial JSON with fix: {attempt[-10:]}")
                    return parsed
            except json.JSONDecodeError:
                continue

        # Strategy 2: Try to extract key-value pairs using regex as last resort
        try:
            import re
            # Look for "key": "value" or "key": value patterns
            pairs = re.findall(r'"([^"]+)":\s*(?:"([^"]*)"?|(\d+(?:\.\d+)?)|(\btrue\b|\bfalse\b|\bnull\b))', fixed)
            if pairs:
                result = {}
                for key, str_val, num_val, bool_val in pairs:
                    if str_val is not None and str_val != '':
                        result[key] = str_val
                    elif num_val:
                        result[key] = float(num_val) if '.' in num_val else int(num_val)
                    elif bool_val:
                        result[key] = bool_val == 'true' if bool_val != 'null' else None
                if result:
                    logger.info(f"Recovered {len(result)} fields via regex extraction")
                    return result
        except Exception:
            pass

        # Return empty dict as fallback - tool execution will handle missing args
        return {}

from ..core.types import (
    AssistantMessage,
    ConversationMessage,
    LLMProvider,
    ProviderMessageResponse,
    ProviderResponse,
    ProviderToolCallsResponse,
    ProviderToolDefinition,
    ProviderUsage,
    StreamChunk,
    SystemMessage,
    ToolCallRequest,
    ToolMessage,
    UserMessage,
)


# Models that require the Responses API
RESPONSES_API_MODELS = {
    "gpt-5.1-codex-max",
    "gpt-5.1-codex-mini",
    "gpt-5.1-codex",
    "gpt-5.1",
    "gpt-5",
    "gpt-5-mini",
    "gpt-5-nano",
    "gpt-5-pro",
    "o3",
    "o3-mini",
    "o3-pro",
    "o1-pro",
    "o1-pro-mini",
}


def _requires_responses_api(model: str) -> bool:
    """Check if model requires the Responses API."""
    model_lower = model.lower()
    # Check exact matches first
    if model_lower in RESPONSES_API_MODELS:
        return True
    # Check prefixes for versioned models
    for prefix in ["gpt-5", "o3", "o1-pro"]:
        if model_lower.startswith(prefix):
            return True
    return False


@dataclass
class OpenAIProviderOptions:
    """Options for OpenAI provider."""

    api_key: str
    model: str
    max_tokens: int = 2048
    temperature: float = 0.0


class OpenAIProvider(LLMProvider):
    """OpenAI GPT provider with Responses API and Chat Completions support."""

    def __init__(self, options: OpenAIProviderOptions):
        """Initialize OpenAI provider."""
        super().__init__("openai", options.model)
        self.client = AsyncOpenAI(api_key=options.api_key)
        self.sync_client = OpenAI(api_key=options.api_key)
        self.max_tokens = options.max_tokens
        self.temperature = options.temperature
        self._use_responses_api = _requires_responses_api(options.model)

    async def generate(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate a response from OpenAI."""
        if self._use_responses_api:
            return await self._generate_responses_api(messages, tools)
        else:
            return await self._generate_chat_completions(messages, tools)

    async def _generate_responses_api(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate using the Responses API (/v1/responses)."""
        # Convert messages to Responses API format
        input_items = _convert_messages_to_responses_format(messages)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "input": input_items,
        }

        # Add instructions from system message if present
        for msg in messages:
            if isinstance(msg, SystemMessage):
                params["instructions"] = msg.content
                break

        if self.max_tokens:
            params["max_output_tokens"] = self.max_tokens

        if tools:
            params["tools"] = [_map_tool_for_responses(tool) for tool in tools]

        # Make API call using responses endpoint
        response = await self.client.responses.create(**params)

        # Extract usage
        usage = None
        if hasattr(response, "usage") and response.usage:
            usage = ProviderUsage(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
                total_tokens=response.usage.input_tokens + response.usage.output_tokens,
            )

        # Process output items
        tool_calls = []
        content_parts = []

        for item in response.output:
            if item.type == "message":
                for content_item in item.content:
                    if content_item.type == "output_text":
                        content_parts.append(content_item.text)
            elif item.type == "function_call":
                tool_calls.append(
                    ToolCallRequest(
                        id=item.call_id,
                        name=item.name,
                        arguments=_safe_parse_arguments(item.arguments, "responses_api"),
                    )
                )

        content = "".join(content_parts)

        if tool_calls:
            return ProviderToolCallsResponse(
                type="tool_calls",
                tool_calls=tool_calls,
                content=content,
                usage=usage,
            )

        return ProviderMessageResponse(
            type="message",
            content=content,
            usage=usage,
        )

    async def _generate_chat_completions(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderResponse:
        """Generate using the Chat Completions API (/v1/chat/completions)."""
        converted_messages = _convert_messages(messages)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "messages": converted_messages,
            "temperature": self.temperature,
        }

        if self.max_tokens:
            params["max_tokens"] = self.max_tokens

        if tools:
            params["tools"] = [_map_tool(tool) for tool in tools]
            params["tool_choice"] = "auto"

        # Make API call
        response = await self.client.chat.completions.create(**params)

        # Extract message
        message = response.choices[0].message

        # Extract usage
        usage = None
        if response.usage:
            usage = ProviderUsage(
                input_tokens=response.usage.prompt_tokens,
                output_tokens=response.usage.completion_tokens,
                total_tokens=response.usage.total_tokens,
            )

        # Check for tool calls
        if message.tool_calls:
            tool_calls = [
                ToolCallRequest(
                    id=tc.id,
                    name=tc.function.name,
                    arguments=_safe_parse_arguments(tc.function.arguments, "chat_completions"),
                )
                for tc in message.tool_calls
            ]

            return ProviderToolCallsResponse(
                type="tool_calls",
                tool_calls=tool_calls,
                content=message.content or "",
                usage=usage,
            )

        return ProviderMessageResponse(
            type="message",
            content=message.content or "",
            usage=usage,
        )

    async def generate_stream(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> AsyncIterator[StreamChunk]:
        """Generate a streaming response from OpenAI."""
        if self._use_responses_api:
            async for chunk in self._stream_responses_api(messages, tools):
                yield chunk
        else:
            async for chunk in self._stream_chat_completions(messages, tools):
                yield chunk

    async def _stream_responses_api(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> AsyncIterator[StreamChunk]:
        """Stream using the Responses API."""
        input_items = _convert_messages_to_responses_format(messages)

        params: dict[str, Any] = {
            "model": self.model,
            "input": input_items,
            "stream": True,
        }

        # Add instructions from system message
        for msg in messages:
            if isinstance(msg, SystemMessage):
                params["instructions"] = msg.content
                break

        if self.max_tokens:
            params["max_output_tokens"] = self.max_tokens

        if tools:
            params["tools"] = [_map_tool_for_responses(tool) for tool in tools]

        # Stream response
        stream = await self.client.responses.create(**params)

        current_tool_calls: dict[str, dict[str, Any]] = {}

        async for event in stream:
            event_type = event.type

            if event_type == "response.output_text.delta":
                yield StreamChunk(
                    type="content",
                    content=event.delta,
                )

            elif event_type == "response.function_call_arguments.delta":
                call_id = event.call_id
                if call_id not in current_tool_calls:
                    current_tool_calls[call_id] = {
                        "id": call_id,
                        "name": event.name if hasattr(event, "name") else "",
                        "arguments": "",
                    }
                current_tool_calls[call_id]["arguments"] += event.delta

            elif event_type == "response.function_call_arguments.done":
                call_id = event.call_id
                if call_id in current_tool_calls:
                    tc = current_tool_calls[call_id]
                    args = _safe_parse_arguments(tc["arguments"], "stream_responses_api")

                    yield StreamChunk(
                        type="tool_call",
                        tool_call=ToolCallRequest(
                            id=tc["id"],
                            name=event.name if hasattr(event, "name") else tc["name"],
                            arguments=args,
                        ),
                    )

            elif event_type == "response.done":
                if hasattr(event, "response") and hasattr(event.response, "usage"):
                    usage = event.response.usage
                    yield StreamChunk(
                        type="usage",
                        usage=ProviderUsage(
                            input_tokens=usage.input_tokens,
                            output_tokens=usage.output_tokens,
                            total_tokens=usage.input_tokens + usage.output_tokens,
                        ),
                    )
                yield StreamChunk(type="done")

    async def _stream_chat_completions(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> AsyncIterator[StreamChunk]:
        """Stream using Chat Completions API."""
        converted_messages = _convert_messages(messages)

        # Build request parameters
        params: dict[str, Any] = {
            "model": self.model,
            "messages": converted_messages,
            "temperature": self.temperature,
            "stream": True,
        }

        if self.max_tokens:
            params["max_tokens"] = self.max_tokens

        if tools:
            params["tools"] = [_map_tool(tool) for tool in tools]
            params["tool_choice"] = "auto"

        # Stream response
        stream = await self.client.chat.completions.create(**params)

        current_tool_calls: dict[int, dict[str, Any]] = {}

        async for chunk in stream:
            delta = chunk.choices[0].delta

            # Handle content
            if delta.content:
                yield StreamChunk(
                    type="content",
                    content=delta.content,
                )

            # Handle tool calls
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index

                    if idx not in current_tool_calls:
                        current_tool_calls[idx] = {
                            "id": tc.id or "",
                            "name": tc.function.name if tc.function else "",
                            "arguments": "",
                        }

                    if tc.function and tc.function.arguments:
                        current_tool_calls[idx]["arguments"] += tc.function.arguments

            # Check if stream is done
            if chunk.choices[0].finish_reason:
                # Emit any accumulated tool calls
                for tool_call in current_tool_calls.values():
                    args = _safe_parse_arguments(tool_call["arguments"], "stream_chat_completions")

                    yield StreamChunk(
                        type="tool_call",
                        tool_call=ToolCallRequest(
                            id=tool_call["id"],
                            name=tool_call["name"],
                            arguments=args,
                        ),
                    )

                # Emit usage if available
                if hasattr(chunk, "usage") and chunk.usage:
                    yield StreamChunk(
                        type="usage",
                        usage=ProviderUsage(
                            input_tokens=chunk.usage.prompt_tokens,
                            output_tokens=chunk.usage.completion_tokens,
                            total_tokens=chunk.usage.total_tokens,
                        ),
                    )

                yield StreamChunk(type="done")

    def get_capabilities(self):
        """Get provider capabilities."""
        return {
            "streaming": True,
            "tool_calling": True,
            "vision": "vision" in self.model or "gpt-4" in self.model or "gpt-5" in self.model,
            "function_calling": True,
            "max_tokens": self.max_tokens,
            "supported_modalities": ["text", "image"],
            "api_type": "responses" if self._use_responses_api else "chat_completions",
        }


def _convert_messages_to_responses_format(messages: list[ConversationMessage]) -> list[dict[str, Any]]:
    """Convert conversation messages to Responses API input format."""
    result: list[dict[str, Any]] = []

    for message in messages:
        # Skip system messages - they go in "instructions" parameter
        if isinstance(message, SystemMessage):
            continue

        elif isinstance(message, UserMessage):
            result.append({
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": message.content}],
            })

        elif isinstance(message, AssistantMessage):
            # Add assistant content first (if present)
            if message.content:
                result.append({
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": message.content}],
                })
            # Then add function calls (if present)
            if message.tool_calls:
                for tc in message.tool_calls:
                    result.append({
                        "type": "function_call",
                        "call_id": tc.id,
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments) if isinstance(tc.arguments, dict) else tc.arguments,
                    })

        elif isinstance(message, ToolMessage):
            result.append({
                "type": "function_call_output",
                "call_id": message.tool_call_id,
                "output": message.content,
            })

    return result


def _convert_messages(messages: list[ConversationMessage]) -> list[dict[str, Any]]:
    """Convert conversation messages to Chat Completions format."""
    result: list[dict[str, Any]] = []

    for message in messages:
        if isinstance(message, SystemMessage):
            result.append({"role": "system", "content": message.content})

        elif isinstance(message, UserMessage):
            result.append({"role": "user", "content": message.content})

        elif isinstance(message, AssistantMessage):
            msg: dict[str, Any] = {"role": "assistant"}

            if message.content:
                msg["content"] = message.content

            if message.tool_calls:
                msg["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments),
                        },
                    }
                    for tc in message.tool_calls
                ]

            result.append(msg)

        elif isinstance(message, ToolMessage):
            result.append(
                {
                    "role": "tool",
                    "tool_call_id": message.tool_call_id,
                    "content": message.content,
                }
            )

    return result


def _map_tool_for_responses(definition: ProviderToolDefinition) -> dict[str, Any]:
    """Map tool definition to Responses API format."""
    return {
        "type": "function",
        "name": definition.name,
        "description": definition.description,
        "parameters": definition.parameters.model_dump(by_alias=True, exclude_none=True) if definition.parameters else {"type": "object", "properties": {}},
    }


def _map_tool(definition: ProviderToolDefinition) -> dict[str, Any]:
    """Map tool definition to Chat Completions format."""
    return {
        "type": "function",
        "function": {
            "name": definition.name,
            "description": definition.description,
            "parameters": definition.parameters.model_dump(by_alias=True, exclude_none=True) if definition.parameters else {"type": "object", "properties": {}},
        },
    }
