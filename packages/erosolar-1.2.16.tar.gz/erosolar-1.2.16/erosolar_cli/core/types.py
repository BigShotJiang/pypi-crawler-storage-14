"""
Core type definitions for Erosolar CLI.
Provides type-safe data structures for messages, providers, and tool definitions.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from enum import Enum
from datetime import datetime
from typing import Any, AsyncIterator, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


class ProviderId(str):
    """Provider identifier string."""

    pass


class ReasoningEffortLevel(str, Enum):
    """Reasoning effort level for provider."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class MessageRole(str, Enum):
    """Standard LLM message roles."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


class ToolType(str, Enum):
    """Standard tool types."""

    FUNCTION = "function"
    BUILTIN = "builtin"


class ProviderType(str, Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"


class ConversationMessage(BaseModel):
    """Base message structure for conversations."""

    role: MessageRole
    content: str
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())

    model_config = ConfigDict(arbitrary_types_allowed=True)


class SystemMessage(ConversationMessage):
    """System message for conversation setup."""

    role: Literal[MessageRole.SYSTEM] = MessageRole.SYSTEM


class UserMessage(ConversationMessage):
    """User message in conversation."""

    role: Literal[MessageRole.USER] = MessageRole.USER
    name: Optional[str] = None


class AssistantMessage(ConversationMessage):
    """Assistant response message."""

    role: Literal[MessageRole.ASSISTANT] = MessageRole.ASSISTANT
    name: Optional[str] = None
    tool_calls: list["ToolCallRequest"] = Field(default_factory=list)
    usage: Optional["UsageStats"] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ToolMessage(ConversationMessage):
    """Tool response message."""

    role: Literal[MessageRole.TOOL] = MessageRole.TOOL
    tool_call_id: str

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ToolCallRequest(BaseModel):
    """Tool call request from LLM."""

    id: str
    type: ToolType | None = None
    function: Optional["FunctionToolDefinition"] = None
    # Legacy fields for function-style tool calls
    name: Optional[str] = None
    arguments: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(arbitrary_types_allowed=True, populate_by_name=True, extra="allow")


class UsageStats(BaseModel):
    """Token usage statistics."""

    input_tokens: int
    output_tokens: int
    total_tokens: Optional[int] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def model_validate(cls, obj: Any, *args, **kwargs):
        inst = super().model_validate(obj, *args, **kwargs)
        if inst.total_tokens is None and inst.input_tokens is not None and inst.output_tokens is not None:
            try:
                inst.total_tokens = inst.input_tokens + inst.output_tokens
            except Exception:
                inst.total_tokens = None
        return inst


class ProviderToolDefinition(BaseModel):
    """Tool definition for providers."""

    type: Optional[ToolType] = ToolType.FUNCTION
    function: Optional["FunctionToolDefinition"] = None
    # Legacy fields for OpenAI-style function definitions
    name: Optional[str] = None
    description: Optional[str] = None
    parameters: Optional["JSONSchemaObject"] = None

    model_config = ConfigDict(arbitrary_types_allowed=True, populate_by_name=True, extra="allow")


class FunctionToolDefinition(BaseModel):
    """Function tool definition."""

    name: str
    description: str
    parameters: "JSONSchemaObject"

    model_config = ConfigDict(arbitrary_types_allowed=True)


class JSONSchemaObject(BaseModel):
    """JSON Schema object for tool parameters."""

    type: Literal["object"]
    properties: dict[str, Any]
    required: list[str] = Field(default_factory=list)
    # Use snake_case internally but serialize to camelCase for JSON Schema compliance
    additional_properties: bool = Field(default=False, alias="additionalProperties")

    model_config = ConfigDict(
        populate_by_name=True,  # Accept both snake_case and camelCase
        validate_assignment=True,
        arbitrary_types_allowed=True,
    )


class JSONSchemaString(BaseModel):
    """JSON Schema string type."""

    type: Literal["string"]
    description: Optional[str] = None
    min_length: Optional[int] = Field(default=None, alias="minLength")
    max_length: Optional[int] = Field(default=None, alias="maxLength")
    enum: Optional[list[str]] = None
    pattern: Optional[str] = None

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        arbitrary_types_allowed=True,
    )


class JSONSchemaNumber(BaseModel):
    """JSON Schema number type."""

    type: Literal["number"]
    description: Optional[str] = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    exclusive_minimum: Optional[float] = Field(default=None, alias="exclusiveMinimum")
    exclusive_maximum: Optional[float] = Field(default=None, alias="exclusiveMaximum")

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        arbitrary_types_allowed=True,
    )


class JSONSchemaBoolean(BaseModel):
    """JSON Schema boolean type."""

    type: Literal["boolean"]
    description: Optional[str] = None

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        arbitrary_types_allowed=True,
    )


class JSONSchemaArray(BaseModel):
    """JSON Schema array type."""

    type: Literal["array"]
    items: Optional[dict[str, Any]] = None
    description: Optional[str] = None
    min_items: Optional[int] = Field(default=None, alias="minItems")
    max_items: Optional[int] = Field(default=None, alias="maxItems")
    unique_items: Optional[bool] = Field(default=None, alias="uniqueItems")

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        arbitrary_types_allowed=True,
    )


# Type alias for any JSON Schema property
JSONSchemaProperty = JSONSchemaObject | JSONSchemaString | JSONSchemaNumber | JSONSchemaBoolean | JSONSchemaArray


class ProviderRequest(BaseModel):
    """Base provider request structure."""

    model: str
    messages: list[ConversationMessage]
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    stream: bool = False
    tools: Optional[list[ProviderToolDefinition]] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ProviderResponse(BaseModel):
    """Base provider response structure."""

    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: list["Choice"]
    usage: Optional[UsageStats] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


class Choice(BaseModel):
    """Response choice."""

    index: int
    message: AssistantMessage
    finish_reason: Optional[str] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ProviderResponseBase(BaseModel):
    """Base for streaming/non-streaming responses."""

    id: str
    model: str
    created: int
    object: str = "chat.completion.chunk"

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ProviderToolCallsResponse(ProviderResponseBase):
    """Response with tool calls."""

    choices: list["ToolCallChoice"]

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ToolCallChoice(BaseModel):
    """Tool call in choice."""

    index: int = 0
    delta: "ToolCallDelta"
    finish_reason: Optional[str] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ToolCallDelta(BaseModel):
    """Delta for tool call."""

    tool_calls: list["ToolCallDeltaItem"] = Field(default_factory=list)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ToolCallDeltaItem(BaseModel):
    """Individual tool call delta."""

    index: int
    id: Optional[str] = None
    type: Optional[str] = None
    function: "FunctionDelta" = Field(default_factory=dict)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class FunctionDelta(BaseModel):
    """Function delta in tool call."""

    name: Optional[str] = None
    arguments: str = ""

    model_config = ConfigDict(arbitrary_types_allowed=True)


class ProviderUsage(BaseModel):
    """Token usage from providers."""

    input_tokens: Optional[int] = Field(default=None, alias="inputTokens")
    output_tokens: Optional[int] = Field(default=None, alias="outputTokens")
    total_tokens: Optional[int] = Field(default=None, alias="totalTokens")

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)


class ProviderResponseBase(BaseModel):
    """Base provider response."""

    usage: Optional[ProviderUsage] = None

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)


class ProviderMessageResponse(ProviderResponseBase):
    """Provider response with message content."""

    type: Literal["message"] = "message"
    content: str


class ProviderToolCallsResponse(ProviderResponseBase):
    """Provider response containing tool calls."""

    type: Literal["tool_calls"] = "tool_calls"
    tool_calls: list[ToolCallRequest] = Field(alias="toolCalls")
    content: Optional[str] = None

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)


class StreamChunk(BaseModel):
    """Streaming chunk wrapper."""

    type: Literal["content", "tool_call", "usage", "done"]
    content: Optional[str] = None
    tool_call: Optional[ToolCallRequest] = Field(default=None, alias="toolCall")
    usage: Optional[ProviderUsage] = None

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True)


class ProviderCapabilities(BaseModel):
    """Provider capabilities."""

    streaming: bool
    tool_calling: bool
    vision: bool
    function_calling: bool
    max_tokens: int
    supported_modalities: list[str]

    model_config = ConfigDict(arbitrary_types_allowed=True)


class LLMProvider(ABC):
    """Abstract base class for LLM providers."""

    def __init__(self, provider_id: str, model: str):
        self.id = provider_id
        self.model = model

    @abstractmethod
    async def generate(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> ProviderMessageResponse | ProviderToolCallsResponse:
        """Generate a non-streaming response from the LLM."""
        raise NotImplementedError

    async def generate_stream(
        self, messages: list[ConversationMessage], tools: list[ProviderToolDefinition]
    ) -> AsyncIterator[StreamChunk]:
        """Streaming generation (optional)."""
        raise NotImplementedError("Streaming not supported by this provider")

    def get_capabilities(self) -> ProviderCapabilities:
        """Return provider capabilities."""
        return ProviderCapabilities(
            streaming=False,
            tool_calling=True,
            vision=False,
            function_calling=True,
            max_tokens=8192,
            supported_modalities=["text"],
        )
