"""
Safety Validator - Enhanced validation with auto-fixing.

Validates operations for safety, provides suggestions, and attempts auto-fixing.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable, Optional

from .error_types import BlockedOperationError, DangerousOperationError


@dataclass
class AutoFix:
    """Auto-fix suggestion for unsafe command."""

    available: bool
    apply: Callable[[], str]
    description: str


@dataclass
class ValidationResult:
    """Result of safety validation."""

    valid: bool
    error: Optional[Exception] = None
    warnings: list[str] = None
    auto_fix: Optional[AutoFix] = None

    def __post_init__(self):
        if self.warnings is None:
            self.warnings = []


@dataclass
class DangerousPattern:
    """Pattern matching dangerous command with safe alternative."""

    pattern: re.Pattern
    reason: str
    severity: str  # 'critical', 'high', 'medium'
    safe_alternative: Optional[str] = None


@dataclass
class BlockedOperation:
    """Operation blocked by policy."""

    pattern: re.Pattern
    policy: str
    allowed_alternatives: Optional[list[str]] = None


# Comprehensive dangerous command patterns
DANGEROUS_PATTERNS = [
    # Critical - system destruction
    DangerousPattern(
        pattern=re.compile(r"rm\s+-rf\s+/($|\s)"),
        reason="Attempts to delete entire root filesystem",
        severity="critical",
        safe_alternative="rm -rf ./specific-directory",
    ),
    DangerousPattern(
        pattern=re.compile(r":()\{ :\|:& \};:"),
        reason="Fork bomb that crashes system",
        severity="critical",
    ),
    DangerousPattern(
        pattern=re.compile(r"mkfs\."),
        reason="Formats filesystem, destroying all data",
        severity="critical",
    ),
    DangerousPattern(
        pattern=re.compile(r"dd\s+.*of=/dev/(sd|hd|nvme)"),
        reason="Writes directly to disk, can destroy data",
        severity="critical",
    ),
    # High - data loss
    DangerousPattern(
        pattern=re.compile(r"rm\s+-rf\s+~?/?"),
        reason="Removes files recursively without confirmation",
        severity="high",
        safe_alternative="rm -ri ./directory (interactive)",
    ),
    DangerousPattern(
        pattern=re.compile(r">\s*/dev/(sd|hd|nvme)"),
        reason="Redirects output to disk device",
        severity="high",
    ),
    DangerousPattern(
        pattern=re.compile(r"shred\s+-[a-z]*n"),
        reason="Securely deletes files, unrecoverable",
        severity="high",
    ),
    # Medium - risky operations
    DangerousPattern(
        pattern=re.compile(r"chmod\s+-R\s+777"),
        reason="Makes all files world-writable (security risk)",
        severity="medium",
        safe_alternative="chmod -R 755 ./directory",
    ),
    DangerousPattern(
        pattern=re.compile(r"curl.*\|\s*sh"),
        reason="Pipes remote script to shell (security risk)",
        severity="medium",
        safe_alternative="Download and inspect script first",
    ),
    DangerousPattern(
        pattern=re.compile(r"wget.*\|\s*sh"),
        reason="Pipes remote script to shell (security risk)",
        severity="medium",
        safe_alternative="Download and inspect script first",
    ),
    DangerousPattern(
        pattern=re.compile(r"eval\s+\$\("),
        reason="Executes arbitrary code (injection risk)",
        severity="medium",
    ),
]


# Blocked operations by policy
BLOCKED_OPERATIONS = [
    BlockedOperation(
        pattern=re.compile(r"npm\s+publish"),
        policy="Publishing requires explicit user approval",
        allowed_alternatives=["npm publish --dry-run"],
    ),
    BlockedOperation(
        pattern=re.compile(r"git\s+push\s+--force"),
        policy="Force push can overwrite remote history",
        allowed_alternatives=["git push --force-with-lease"],
    ),
    BlockedOperation(
        pattern=re.compile(r"docker\s+system\s+prune\s+-a"),
        policy="Removes all unused Docker resources",
        allowed_alternatives=["docker system prune"],
    ),
]


def validate_bash_command(command: str) -> ValidationResult:
    """
    Validate bash command for safety.

    Args:
        command: Command to validate

    Returns:
        ValidationResult with validation status and suggestions
    """
    warnings: list[str] = []

    # Check for dangerous patterns (CRITICAL - must block)
    for dangerous in DANGEROUS_PATTERNS:
        if dangerous.pattern.search(command):
            if dangerous.severity in ("critical", "high"):
                error = DangerousOperationError(command, dangerous.reason, dangerous.safe_alternative)

                auto_fix = None
                if dangerous.safe_alternative:
                    auto_fix = AutoFix(
                        available=True,
                        apply=lambda alt=dangerous.safe_alternative: alt,
                        description=f"Replace with: {dangerous.safe_alternative}",
                    )

                return ValidationResult(
                    valid=False,
                    error=error,
                    warnings=warnings,
                    auto_fix=auto_fix,
                )
            else:
                # Medium severity - warn but allow
                warning = f"Warning: {dangerous.reason}. Consider: {dangerous.safe_alternative or 'reviewing command'}"
                warnings.append(warning)

    # Check for blocked operations (ERROR - policy violation)
    for blocked in BLOCKED_OPERATIONS:
        if blocked.pattern.search(command):
            error = BlockedOperationError(command, blocked.policy, blocked.allowed_alternatives)

            auto_fix = None
            if blocked.allowed_alternatives:
                auto_fix = AutoFix(
                    available=True,
                    apply=lambda alt=blocked.allowed_alternatives[0]: alt,
                    description=f"Replace with: {blocked.allowed_alternatives[0]}",
                )

            return ValidationResult(
                valid=False,
                error=error,
                warnings=warnings,
                auto_fix=auto_fix,
            )

    return ValidationResult(valid=True, warnings=warnings)


class SmartFixer:
    """Smart command fixer for common issues."""

    @staticmethod
    def fix_dangerous_command(command: str) -> tuple[str, list[str]]:
        """
        Attempt to fix dangerous command.

        Args:
            command: Command to fix

        Returns:
            Tuple of (fixed_command, list_of_changes)
        """
        fixed = command
        changes: list[str] = []

        # Fix rm -rf / to add ./ prefix
        if re.search(r"rm\s+-rf\s+/($|\s)", command):
            fixed = re.sub(r"rm\s+-rf\s+/", "rm -rf ./", fixed)
            changes.append("Changed 'rm -rf /' to 'rm -rf ./'")

        # Fix chmod 777 to chmod 755
        if re.search(r"chmod\s+-R\s+777", command):
            fixed = re.sub(r"chmod\s+-R\s+777", "chmod -R 755", fixed)
            changes.append("Changed 'chmod -R 777' to 'chmod -R 755'")

        # Fix git push --force to --force-with-lease
        if re.search(r"git\s+push\s+--force", command):
            fixed = re.sub(r"git\s+push\s+--force", "git push --force-with-lease", fixed)
            changes.append("Changed 'git push --force' to 'git push --force-with-lease'")

        return fixed, changes
