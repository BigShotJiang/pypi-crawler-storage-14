"""
Erosolar CLI - Unified AI Command Line Interface

All LLM providers and tools are managed through the unified schema system.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from uuid import uuid4

import typer
from langchain_core.messages import AIMessage
from langgraph.checkpoint.memory import MemorySaver

try:  # SQLite checkpointer is preferred for persistence, but optional
    from langgraph.checkpoint.sqlite import SqliteSaver
except Exception:  # pragma: no cover
    SqliteSaver = None

from .config import list_profiles, resolve_profile
from .langgraph_app import ModelConfig, build_initial_state, create_app
from .tooling import build_tools

# Unified provider system
from .core.unified_provider import (
    get_providers,
    get_provider,
    get_defaults,
    route_task,
)
from .providers import (
    create_provider,
    get_supported_providers,
    get_configured_providers,
)
from .plugins import (
    registry,
    load_builtin_plugins,
    create_runtime_with_plugins,
    get_cli_version,
    SelfUpgradeManager,
    SemanticVersion,
)
from .core.version_manager import (
    VersionManager,
    get_component_versions,
    get_tool_versions,
    ComponentVersion,
    ToolVersion,
)

CHECKPOINT_PATH = Path.home() / ".erosolar" / "bo-cli.sqlite"

app = typer.Typer(add_completion=False, no_args_is_help=True)
alpha_zero_app = typer.Typer(help="Alpha Zero 2 - Multi-Agent Competitive RL Framework")
providers_app = typer.Typer(help="Unified provider management")
tools_app = typer.Typer(help="Unified tool management")
upgrade_app = typer.Typer(help="Self-upgrade and version management")

app.add_typer(alpha_zero_app, name="alpha-zero")
app.add_typer(providers_app, name="providers")
app.add_typer(tools_app, name="tools")
app.add_typer(upgrade_app, name="upgrade")


def _run_chat(
    prompt: str,
    profile: Optional[str],
    model: Optional[str],
    provider: Optional[str],
    workspace_context: Optional[str],
    workspace_context_path: Optional[Path],
    thread_id: Optional[str],
    json_output: bool,
    stream: bool,
    verbosity: str,
    root: Path,
    enabled_plugins: Optional[List[str]] = None,
) -> None:
    """Run chat with unified provider and tool system."""
    context_text = _load_context(workspace_context, workspace_context_path)
    resolved = resolve_profile(profile, workspace_context=context_text)

    selected_model = model or resolved.model
    selected_provider = provider or resolved.provider

    # Use unified provider system defaults if not specified
    if not selected_provider:
        defaults = get_defaults()
        selected_provider = defaults.provider
        selected_model = selected_model or defaults.model

    model_config = ModelConfig(
        provider=selected_provider,
        model=selected_model,
        temperature=resolved.temperature,
        max_tokens=resolved.max_tokens,
    )

    CHECKPOINT_PATH.parent.mkdir(parents=True, exist_ok=True)
    if SqliteSaver:
        try:
            checkpointer = SqliteSaver.from_conn_string(str(CHECKPOINT_PATH))
        except Exception:
            checkpointer = MemorySaver()
    else:
        checkpointer = MemorySaver()

    # Build tools using unified runtime if plugins enabled
    if enabled_plugins:
        runtime = create_runtime_with_plugins(
            working_dir=str(root),
            enabled_plugins=enabled_plugins,
        )
        tools = _runtime_to_langchain_tools(runtime, root)
    else:
        tools = build_tools(root)

    system_prompt = _with_thinking_instructions(resolved.system_prompt)
    graph = create_app(model_config, system_prompt, tools=tools, checkpointer=checkpointer)

    thread = thread_id or str(uuid4())
    config = {"configurable": {"thread_id": thread}}

    existing_state = graph.get_state(config=config)
    prior_values = getattr(existing_state, "values", existing_state) or {}
    prior_messages = prior_values.get("messages") or None
    initialized = bool(prior_values)

    initial_state = build_initial_state(prompt, previous_messages=prior_messages, initialized=initialized)
    if initialized:
        initial_state.pop("usage", None)

    last_ai: AIMessage | None = None
    usage: Dict[str, Any] | None = None

    stream_output = stream and not json_output and verbosity == "verbose"

    if stream_output:
        for update in graph.stream(initial_state, config=config, stream_mode="updates"):
            for payload in _iter_payloads(update):
                usage = payload.get("usage") or usage
                for message in payload.get("messages") or []:
                    if isinstance(message, AIMessage):
                        last_ai = message
                        typer.echo(_format_output(message.content, verbosity))
                    elif getattr(message, "type", "") == "tool":
                        name = getattr(message, "name", "tool")
                        content = message.content if isinstance(message.content, str) else str(message.content)
                        typer.echo(f"[{name}] {content}")
    else:
        final_state = graph.invoke(initial_state, config=config)
        values = _state_values(final_state)
        usage = values.get("usage") or usage
        for message in values.get("messages") or []:
            if isinstance(message, AIMessage):
                last_ai = message
        if last_ai and not json_output:
            typer.echo(_format_output(last_ai.content, verbosity))

    if not usage:
        final_state = graph.get_state(config=config)
        final_values = _state_values(final_state)
        usage = final_values.get("usage") or usage
        if not last_ai:
            for message in final_values.get("messages") or []:
                if isinstance(message, AIMessage):
                    last_ai = message

    if json_output:
        payload = {
            "profile": resolved.name,
            "label": resolved.label,
            "provider": selected_provider,
            "model": selected_model,
            "threadId": thread,
            "response": last_ai.content if last_ai else "",
            "usage": usage or {},
            "rulebookVersion": resolved.rulebook.version,
            "rulebookContract": resolved.rulebook.contract_version,
        }
        typer.echo(json.dumps(payload))
    else:
        if not last_ai:
            typer.echo("No response returned.")


def _runtime_to_langchain_tools(runtime, root: Path):
    """Convert unified runtime tools to LangChain tools."""
    from langchain_core.tools import StructuredTool
    from pydantic import BaseModel, Field, create_model

    tools = []
    for tool_def in runtime.list_tools():
        # Create Pydantic model from parameters
        fields = {}
        params = tool_def.parameters.get("properties", {})
        required = tool_def.parameters.get("required", [])

        for name, spec in params.items():
            field_type = str if spec.get("type") == "string" else Any
            default = ... if name in required else None
            description = spec.get("description", "")
            fields[name] = (field_type, Field(default=default, description=description))

        if fields:
            model = create_model(f"{tool_def.name}Args", **fields)
        else:
            model = BaseModel

        def make_handler(tid):
            def handler(**kwargs):
                result = runtime.execute(tid, kwargs)
                return result.result if result.success else f"Error: {result.error}"
            return handler

        lc_tool = StructuredTool.from_function(
            func=make_handler(tool_def.id),
            name=tool_def.name,
            description=tool_def.description,
            args_schema=model if fields else None,
        )
        tools.append(lc_tool)

    return tools


@app.command("profiles")
def list_profiles_command() -> None:
    """List available profiles."""
    for name in list_profiles():
        typer.echo(name)


# =============================================================================
# Unified Provider Commands
# =============================================================================


@providers_app.command("list")
def list_providers(
    configured_only: bool = typer.Option(False, "--configured", "-c", help="Only show configured providers"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all supported LLM providers from unified schema."""
    if configured_only:
        provider_ids = get_configured_providers()
    else:
        provider_ids = get_supported_providers()

    if json_output:
        providers_info = []
        for pid in provider_ids:
            config = get_provider(pid)
            if config:
                providers_info.append({
                    "id": config.id,
                    "name": config.name,
                    "default_model": config.default_model,
                    "capabilities": [c.value for c in config.capabilities],
                    "openai_compatible": config.openai_compatible,
                })
        typer.echo(json.dumps(providers_info, indent=2))
    else:
        typer.echo("Supported Providers:")
        typer.echo("-" * 40)
        for pid in provider_ids:
            config = get_provider(pid)
            if config:
                status = "[configured]" if pid in get_configured_providers() else ""
                typer.echo(f"  {config.id}: {config.name} {status}")
                typer.echo(f"    Default model: {config.default_model}")


@providers_app.command("info")
def provider_info(
    provider_id: str = typer.Argument(..., help="Provider ID"),
) -> None:
    """Show detailed information about a provider."""
    config = get_provider(provider_id)
    if not config:
        typer.echo(f"Provider not found: {provider_id}", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Provider: {config.name}")
    typer.echo("=" * 40)
    typer.echo(f"ID: {config.id}")
    typer.echo(f"Base URL: {config.base_url or 'N/A'}")
    typer.echo(f"OpenAI Compatible: {config.openai_compatible}")
    typer.echo(f"Default Model: {config.default_model}")
    typer.echo("")
    typer.echo("Capabilities:")
    for cap in config.capabilities:
        typer.echo(f"  - {cap.value}")
    typer.echo("")
    typer.echo("Available Models:")
    for model in config.models:
        default = " (default)" if model == config.default_model else ""
        typer.echo(f"  - {model}{default}")
    typer.echo("")
    typer.echo("Environment Variables:")
    for key, var in config.env_vars.items():
        typer.echo(f"  {key}: {var}")


@providers_app.command("route")
def route_task_command(
    prompt: str = typer.Argument(..., help="Task prompt to route"),
) -> None:
    """Route a task to the best provider using unified schema."""
    result = route_task(prompt)

    typer.echo(f"Task Type: {result.task_type}")
    typer.echo(f"Provider: {result.provider_id}")
    typer.echo(f"Model: {result.model}")
    typer.echo(f"Confidence: {result.confidence:.2%}")
    if result.fallback_providers:
        typer.echo(f"Fallbacks: {', '.join(result.fallback_providers)}")


# =============================================================================
# Unified Tool Commands
# =============================================================================


@tools_app.command("list")
def list_tools(
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter by category"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all tools from unified schema."""
    from .core.unified_provider import get_tools, get_tools_by_category

    if category:
        tools = get_tools_by_category(category)
    else:
        tools = get_tools()

    if json_output:
        tools_info = [
            {
                "id": t.id,
                "name": t.name,
                "description": t.description,
                "category": t.category,
                "cacheable": t.cacheable,
            }
            for t in tools
        ]
        typer.echo(json.dumps(tools_info, indent=2))
    else:
        typer.echo("Available Tools:")
        typer.echo("-" * 40)
        current_category = None
        for t in sorted(tools, key=lambda x: (x.category, x.name)):
            if t.category != current_category:
                current_category = t.category
                typer.echo(f"\n[{current_category}]")
            typer.echo(f"  {t.name}: {t.description[:50]}...")


@tools_app.command("categories")
def list_categories() -> None:
    """List tool categories."""
    from .core.unified_provider import get_tool_categories

    categories = get_tool_categories()
    typer.echo("Tool Categories:")
    typer.echo("-" * 40)
    for cat in categories:
        typer.echo(f"  {cat.id}: {cat.name}")
        typer.echo(f"    {cat.description}")


# =============================================================================
# Self-Upgrade Commands
# =============================================================================


@upgrade_app.command("check")
def check_updates() -> None:
    """Check for available updates."""
    cli_version = get_cli_version()
    upgrade_manager = SelfUpgradeManager(cli_version)

    typer.echo(f"Current version: {cli_version}")
    typer.echo("Checking for updates...")

    update_info = upgrade_manager.check_for_updates()
    if update_info:
        typer.echo(f"Update available: {update_info.available_version}")
        if update_info.is_breaking:
            typer.echo("  Warning: This is a breaking change (major version bump)")
        typer.echo("")
        typer.echo("Run 'bo-cli upgrade install' to upgrade")
    else:
        typer.echo("You are running the latest version")


@upgrade_app.command("install")
def install_upgrade(
    version: Optional[str] = typer.Option(None, "--version", "-v", help="Specific version to install"),
    force: bool = typer.Option(False, "--force", "-f", help="Force upgrade even if breaking changes"),
    skip_backup: bool = typer.Option(False, "--skip-backup", help="Skip creating a backup"),
) -> None:
    """Install an upgrade."""
    cli_version = get_cli_version()
    upgrade_manager = SelfUpgradeManager(cli_version)

    target_version = SemanticVersion.parse(version) if version else None

    if not skip_backup:
        typer.echo("Creating backup...")
        backup_path = upgrade_manager.create_backup()
        if backup_path:
            typer.echo(f"Backup created at: {backup_path}")
        else:
            typer.echo("Warning: Could not create backup")
            if not force:
                typer.echo("Use --force to proceed without backup")
                raise typer.Exit(code=1)

    typer.echo(f"Upgrading to {target_version or 'latest'}...")
    success, message = upgrade_manager.perform_upgrade(target_version, force)

    if success:
        typer.echo(f"Success: {message}")
        typer.echo("Please restart the CLI to use the new version")
    else:
        typer.echo(f"Failed: {message}", err=True)
        raise typer.Exit(code=1)


@upgrade_app.command("rollback")
def rollback_upgrade(
    backup_id: Optional[str] = typer.Argument(None, help="Backup ID to rollback to"),
) -> None:
    """Rollback to a previous version."""
    cli_version = get_cli_version()
    upgrade_manager = SelfUpgradeManager(cli_version)

    backups = upgrade_manager.list_backups()
    if not backups:
        typer.echo("No backups available")
        raise typer.Exit(code=1)

    if not backup_id:
        typer.echo("Available backups:")
        for i, backup in enumerate(backups):
            typer.echo(f"  {i + 1}. Version {backup['version']} ({backup['timestamp']})")
        typer.echo("")
        typer.echo("Run 'bo-cli upgrade rollback <backup_path>' to restore")
        return

    # Find backup by ID or index
    backup_path = None
    try:
        idx = int(backup_id) - 1
        if 0 <= idx < len(backups):
            backup_path = Path(backups[idx]["path"])
    except ValueError:
        backup_path = Path(backup_id)

    if not backup_path or not backup_path.exists():
        typer.echo(f"Backup not found: {backup_id}", err=True)
        raise typer.Exit(code=1)

    typer.echo(f"Rolling back to backup: {backup_path}")
    success, message = upgrade_manager.rollback(backup_path)

    if success:
        typer.echo(f"Success: {message}")
        typer.echo("Please restart the CLI")
    else:
        typer.echo(f"Failed: {message}", err=True)
        raise typer.Exit(code=1)


@upgrade_app.command("backups")
def list_backups() -> None:
    """List available backups."""
    cli_version = get_cli_version()
    upgrade_manager = SelfUpgradeManager(cli_version)

    backups = upgrade_manager.list_backups()
    if not backups:
        typer.echo("No backups available")
        return

    typer.echo("Available Backups:")
    typer.echo("-" * 60)
    for i, backup in enumerate(backups):
        typer.echo(f"  {i + 1}. Version {backup['version']}")
        typer.echo(f"     Created: {backup['timestamp']}")
        typer.echo(f"     Path: {backup['path']}")
        typer.echo("")


@upgrade_app.command("cleanup")
def cleanup_backups(
    keep: int = typer.Option(5, "--keep", "-k", help="Number of backups to keep"),
) -> None:
    """Clean up old backups."""
    cli_version = get_cli_version()
    upgrade_manager = SelfUpgradeManager(cli_version)

    removed = upgrade_manager.cleanup_old_backups(keep_count=keep)
    typer.echo(f"Removed {removed} old backup(s)")


@app.command("version")
def show_version(
    full: bool = typer.Option(False, "--full", "-f", help="Show full version details"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show CLI version information."""
    cli_version = get_cli_version()
    version_manager = VersionManager()

    if json_output:
        components = get_component_versions()
        tools = get_tool_versions()
        payload = {
            "cliVersion": str(cli_version),
            "components": {
                k: {
                    "version": str(v.version),
                    "description": v.description,
                    "status": v.status,
                    "upgradeable": v.upgradeable,
                    "dependencies": v.dependencies,
                }
                for k, v in components.items()
            },
            "tools": {
                k: {
                    "version": str(v.version),
                    "status": v.status,
                }
                for k, v in tools.items()
            },
        }

        # Add plugins
        load_builtin_plugins()
        plugins = registry.list_available()
        payload["plugins"] = {
            p.id: {
                "version": p.version,
                "description": p.description,
                "category": p.category.value,
            }
            for p in plugins
        }

        typer.echo(json.dumps(payload, indent=2))
        return

    typer.echo(f"erosolar version {cli_version}")
    typer.echo("")
    typer.echo("Unified AI Agent Framework")
    typer.echo("Author: Bo Shang")
    typer.echo("")

    if full:
        # Show component versions
        components = get_component_versions()
        if components:
            typer.echo("Components:")
            typer.echo("-" * 40)
            for comp_id, comp in components.items():
                deps = f" (deps: {', '.join(comp.dependencies)})" if comp.dependencies else ""
                typer.echo(f"  {comp_id}: v{comp.version} [{comp.status}]{deps}")
            typer.echo("")

        # Show tool versions
        tools = get_tool_versions()
        if tools:
            stable = [t for t in tools.values() if t.status == "stable"]
            beta = [t for t in tools.values() if t.status == "beta"]
            alpha = [t for t in tools.values() if t.status == "alpha"]

            typer.echo("Tools:")
            typer.echo("-" * 40)
            if stable:
                typer.echo("  Stable:")
                for t in stable:
                    typer.echo(f"    {t.tool_id}: v{t.version}")
            if beta:
                typer.echo("  Beta:")
                for t in beta:
                    typer.echo(f"    {t.tool_id}: v{t.version}")
            if alpha:
                typer.echo("  Alpha:")
                for t in alpha:
                    typer.echo(f"    {t.tool_id}: v{t.version}")
            typer.echo("")

    # Show plugin versions
    load_builtin_plugins()
    plugins = registry.list_available()
    if plugins:
        typer.echo("Plugins:")
        typer.echo("-" * 40)
        for p in plugins:
            typer.echo(f"  {p.id}: v{p.version} ({p.category.value})")


@upgrade_app.command("components")
def list_components(
    upgradeable_only: bool = typer.Option(False, "--upgradeable", "-u", help="Only show upgradeable"),
) -> None:
    """List all CLI components and their versions."""
    version_manager = VersionManager()
    components = version_manager.list_components()

    if upgradeable_only:
        components = [c for c in components if c.upgradeable]

    if not components:
        typer.echo("No components found")
        return

    typer.echo("CLI Components:")
    typer.echo("=" * 60)
    for comp in components:
        deps = f" -> {', '.join(comp.dependencies)}" if comp.dependencies else ""
        upgrade = "[upgradeable]" if comp.upgradeable else "[locked]"
        typer.echo(f"  {comp.component_id}: v{comp.version} [{comp.status}] {upgrade}")
        typer.echo(f"    {comp.description}{deps}")
        typer.echo("")


@upgrade_app.command("tools")
def list_tool_versions_cmd(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status (stable/beta/alpha)"),
) -> None:
    """List all tools and their versions."""
    version_manager = VersionManager()
    tools = version_manager.list_tool_versions()

    if status:
        tools = [t for t in tools if t.status == status]

    if not tools:
        typer.echo("No tools found")
        return

    typer.echo("Tool Versions:")
    typer.echo("=" * 60)

    # Group by status
    by_status = {}
    for t in tools:
        if t.status not in by_status:
            by_status[t.status] = []
        by_status[t.status].append(t)

    for status_name in ["stable", "beta", "alpha", "deprecated"]:
        if status_name in by_status:
            typer.echo(f"\n[{status_name.upper()}]")
            for t in by_status[status_name]:
                typer.echo(f"  {t.tool_id}: v{t.version}")


# =============================================================================
# Chat Commands
# =============================================================================


@app.command()
def chat(
    prompt: str = typer.Argument(..., help="User message to send to the agent."),
    profile: Optional[str] = typer.Option(None, "--profile", "-p", help="Profile name from src/contracts/agent-profiles.schema.json"),
    model: Optional[str] = typer.Option(None, "--model", help="Override the model id."),
    provider: Optional[str] = typer.Option(None, "--provider", help="Override the provider id."),
    workspace_context: Optional[str] = typer.Option(None, "--workspace-context", "-c", help="Optional context text appended to the system prompt."),
    workspace_context_path: Optional[Path] = typer.Option(None, "--workspace-context-path", exists=True, dir_okay=False, help="Path to a file containing workspace context text."),
    thread_id: Optional[str] = typer.Option(None, "--thread-id", help="LangGraph thread id for resuming runs."),
    json_output: bool = typer.Option(False, "--json", help="Emit a JSON envelope instead of plain text."),
    stream: bool = typer.Option(False, "--stream/--no-stream", help="Stream model output to the terminal."),
    verbosity: str = typer.Option("normal", "--verbosity", "-v", help="quiet | normal | verbose"),
    root: Path = typer.Option(Path.cwd(), "--root", help="Workspace root for tools and path safety."),
    alpha_zero: bool = typer.Option(False, "--alpha-zero", help="Enable Alpha Zero 2 plugin"),
    coding: bool = typer.Option(False, "--coding", help="Enable Coding plugin"),
    security: bool = typer.Option(False, "--security", help="Enable Security plugin"),
    all_plugins: bool = typer.Option(False, "--all-plugins", help="Enable all plugins"),
) -> None:
    """Chat with the AI agent using unified provider system."""
    enabled_plugins = []
    if all_plugins:
        load_builtin_plugins()
        enabled_plugins = [p.id for p in registry.list_available()]
    else:
        if alpha_zero:
            enabled_plugins.append("alpha_zero")
        if coding:
            enabled_plugins.append("coding")
        if security:
            enabled_plugins.append("security")

    _run_chat(
        prompt, profile, model, provider, workspace_context,
        workspace_context_path, thread_id, json_output, stream,
        verbosity, root, enabled_plugins if enabled_plugins else None
    )


@app.callback(invoke_without_command=True)
def default(
    ctx: typer.Context,
    prompt: Optional[List[str]] = typer.Argument(None, help="Prompt to send when no subcommand is provided."),
    profile: Optional[str] = typer.Option(None, "--profile", "-p", help="Profile name from src/contracts/agent-profiles.schema.json"),
    model: Optional[str] = typer.Option(None, "--model", help="Override the model id."),
    provider: Optional[str] = typer.Option(None, "--provider", help="Override the provider id."),
    workspace_context: Optional[str] = typer.Option(None, "--workspace-context", "-c", help="Optional context text appended to the system prompt."),
    workspace_context_path: Optional[Path] = typer.Option(None, "--workspace-context-path", exists=True, dir_okay=False, help="Path to a file containing workspace context text."),
    thread_id: Optional[str] = typer.Option(None, "--thread-id", help="LangGraph thread id for resuming runs."),
    json_output: bool = typer.Option(False, "--json", help="Emit a JSON envelope instead of plain text."),
    stream: bool = typer.Option(False, "--stream/--no-stream", help="Stream model output to the terminal."),
    verbosity: str = typer.Option("normal", "--verbosity", "-v", help="quiet | normal | verbose"),
    root: Path = typer.Option(Path.cwd(), "--root", help="Workspace root for tools and path safety."),
    alpha_zero: bool = typer.Option(False, "--alpha-zero", help="Enable Alpha Zero 2 plugin"),
    coding: bool = typer.Option(False, "--coding", help="Enable Coding plugin"),
    security: bool = typer.Option(False, "--security", help="Enable Security plugin"),
    all_plugins: bool = typer.Option(False, "--all-plugins", help="Enable all plugins"),
) -> None:
    """Default command - run chat if prompt provided."""
    if ctx.invoked_subcommand is not None:
        return
    if not prompt:
        typer.echo(ctx.get_help())
        raise typer.Exit(code=1)

    # Check if prompt matches a command name - if so, redirect to that command
    known_commands = ["version", "profiles", "plugins", "alpha-zero", "providers", "tools", "upgrade"]
    first_word = prompt[0].lower() if prompt else ""
    if first_word in known_commands:
        # Re-invoke the CLI with the correct command structure
        import sys
        from click.testing import CliRunner
        runner = CliRunner()
        result = runner.invoke(app, prompt)
        typer.echo(result.output.rstrip())
        raise typer.Exit(code=result.exit_code)

    enabled_plugins = []
    if all_plugins:
        load_builtin_plugins()
        enabled_plugins = [p.id for p in registry.list_available()]
    else:
        if alpha_zero:
            enabled_plugins.append("alpha_zero")
        if coding:
            enabled_plugins.append("coding")
        if security:
            enabled_plugins.append("security")

    prompt_text = " ".join(prompt).strip()
    _run_chat(
        prompt_text, profile, model, provider, workspace_context,
        workspace_context_path, thread_id, json_output, stream,
        verbosity, root, enabled_plugins if enabled_plugins else None
    )


# =============================================================================
# Plugin Commands
# =============================================================================


@app.command("plugins")
def list_plugins_command(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List available plugins."""
    load_builtin_plugins()
    plugins = registry.list_available()

    if json_output:
        plugins_info = [
            {
                "id": p.id,
                "name": p.name,
                "version": p.version,
                "description": p.description,
                "category": p.category.value,
                "requires_auth": p.requires_auth,
            }
            for p in plugins
        ]
        typer.echo(json.dumps(plugins_info, indent=2))
    else:
        typer.echo("Available Plugins:")
        typer.echo("-" * 40)
        for p in plugins:
            typer.echo(f"  {p.id} ({p.version})")
            typer.echo(f"    {p.description}")
            typer.echo(f"    Category: {p.category.value}")


# =============================================================================
# Alpha Zero 2 Commands
# =============================================================================


@alpha_zero_app.command("tournament")
def alpha_zero_tournament(
    tasks: Optional[List[str]] = typer.Option(None, "--task", "-t", help="Task prompts for agents"),
    num_rounds: int = typer.Option(5, "--rounds", "-r", help="Number of tournament rounds"),
    verbose: bool = typer.Option(True, "--verbose/--quiet", help="Enable verbose output"),
    output_dir: Optional[Path] = typer.Option(None, "--output", "-o", help="Directory for results"),
) -> None:
    """Run an Alpha Zero 2 tournament between two competing agents."""
    import asyncio as aio
    from .alpha_zero import run_simple_tournament, get_project_summary

    typer.echo(get_project_summary())
    typer.echo("")

    # Use default tasks if none provided
    task_list = tasks or [
        "Write an efficient function to find all prime numbers up to n using the Sieve of Eratosthenes.",
        "Implement a binary search algorithm with proper error handling.",
        "Create a function to merge two sorted lists into one sorted list with O(n) time complexity.",
    ]

    typer.echo(f"Starting tournament with {num_rounds} rounds...")
    typer.echo(f"Tasks: {len(task_list)}")
    typer.echo("")

    result = aio.run(run_simple_tournament(
        tasks=task_list,
        num_rounds=num_rounds,
        verbose=verbose,
    ))

    typer.echo("\nTournament Complete!")
    typer.echo(f"Total Rounds: {result.total_rounds}")
    typer.echo(f"Agent 1 Wins: {result.agent1_wins} ({result.agent1_win_rate:.1%})")
    typer.echo(f"Agent 2 Wins: {result.agent2_wins} ({result.agent2_win_rate:.1%})")
    typer.echo(f"Ties: {result.ties}")


@alpha_zero_app.command("metrics")
def alpha_zero_metrics(
    data_dir: Optional[Path] = typer.Option(None, "--data-dir", "-d", help="Tournament data directory"),
    format_type: str = typer.Option("text", "--format", "-f", help="Output format: text or markdown"),
) -> None:
    """Display Alpha Zero 2 metrics dashboard."""
    from .alpha_zero import MetricsDashboard

    dashboard = MetricsDashboard(data_dir=data_dir)
    report = dashboard.generate_report(format=format_type)
    typer.echo(report)


@alpha_zero_app.command("info")
def alpha_zero_info() -> None:
    """Display Alpha Zero 2 project and researcher information."""
    from .alpha_zero import get_project_summary, get_research_citation, BO_SHANG

    typer.echo("=" * 60)
    typer.echo("ALPHA ZERO 2 RESEARCH PROJECT")
    typer.echo("=" * 60)
    typer.echo("")
    typer.echo(get_project_summary())
    typer.echo("")
    typer.echo("-" * 40)
    typer.echo("RESEARCHER PROFILE")
    typer.echo("-" * 40)
    typer.echo(f"Name: {BO_SHANG.name}")
    typer.echo(f"Role: {BO_SHANG.role}")
    typer.echo(f"Education: {BO_SHANG.education}")
    typer.echo(f"GitHub: {BO_SHANG.github}")
    typer.echo("")
    typer.echo("Specializations:")
    for spec in BO_SHANG.specializations:
        typer.echo(f"  - {spec}")
    typer.echo("")
    typer.echo("-" * 40)
    typer.echo("CITATION")
    typer.echo("-" * 40)
    typer.echo(get_research_citation())


@alpha_zero_app.command("demo")
def alpha_zero_demo(
    demo_type: str = typer.Argument("reward", help="Demo type: reward, metrics, or introspection"),
) -> None:
    """Run an Alpha Zero 2 demo (no API keys required)."""
    from .alpha_zero import RewardSystem, CompetitionMetrics, IntrospectionEngine

    if demo_type == "reward":
        typer.echo("REWARD SYSTEM DEMO")
        typer.echo("=" * 40)
        typer.echo("")

        reward_system = RewardSystem(verbose=False)

        sample_code = '''
def fibonacci(n, memo={}):
    """Calculate fibonacci number with memoization."""
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    result = fibonacci(n-1, memo) + fibonacci(n-2, memo)
    memo[n] = result
    return result
'''
        typer.echo("Sample Code:")
        typer.echo(sample_code)
        typer.echo("")

        metrics = CompetitionMetrics(
            code_quality_score=0.85,
            algorithm_efficiency=0.9,
            error_handling_score=0.7,
            syntax_validity=1.0,
            logic_correctness=0.95,
            completeness=0.8,
            innovation_score=0.6,
            documentation_quality=0.75,
        )

        reward = reward_system.calculate_reward(metrics)
        summary = reward_system.get_performance_summary(metrics)

        typer.echo(f"Calculated Reward: {reward:.2f}/100")
        typer.echo("")
        typer.echo(summary)

    elif demo_type == "introspection":
        typer.echo("INTROSPECTION ENGINE DEMO")
        typer.echo("=" * 40)
        typer.echo("")

        engine = IntrospectionEngine(verbose=False)

        sample_code = '''
def binary_search(arr: list[int], target: int) -> int:
    """Find target in sorted array using binary search."""
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1
'''
        typer.echo("Analyzing code...")
        analysis = engine.analyze_code(sample_code, "binary_search.py")

        typer.echo(f"Lines of code: {analysis.lines_of_code}")
        typer.echo(f"Functions: {analysis.num_functions}")
        typer.echo(f"Cyclomatic complexity: {analysis.cyclomatic_complexity}")
        typer.echo(f"Has docstrings: {analysis.has_docstrings}")
        typer.echo(f"Has type hints: {analysis.has_type_hints}")

        suggestions = engine.generate_suggestions(analysis)
        if suggestions:
            typer.echo(f"\nSuggestions ({len(suggestions)}):")
            for s in suggestions:
                typer.echo(f"  [{s.priority}] {s.description}")

    else:
        typer.echo(f"Unknown demo type: {demo_type}")
        typer.echo("Available demos: reward, introspection")


def main() -> None:
    """Main entry point."""
    app()


def _load_context(inline: Optional[str], path: Optional[Path]) -> Optional[str]:
    if inline and inline.strip():
        return inline.strip()
    if path:
        return path.read_text(encoding="utf-8").strip()
    return None


def _iter_payloads(update: Any) -> Iterable[Dict[str, Any]]:
    raw = _state_values(update)
    if raw and all(isinstance(value, dict) for value in raw.values()):
        return raw.values()
    if raw:
        return [raw]
    return []


def _with_thinking_instructions(system_prompt: str) -> str:
    instructions = (
        "\n\nWhen responding:\n"
        "- Use <thinking>...</thinking> for your chain-of-thought and planned tool usage.\n"
        "- Put the final answer in <response>...</response>.\n"
        "- Use tools when helpful and cite file paths/commands in <response>.\n"
        "- Available tools: read_file, list_dir, search_text, run_bash (scoped to the workspace root).\n"
    )
    return f"{system_prompt.strip()}{instructions}"


def _extract_final_text(content: str) -> str:
    if not isinstance(content, str):
        return str(content)
    start = content.find("<response>")
    end = content.find("</response>")
    if start != -1 and end != -1 and end > start:
        return content[start + len("<response>"):end].strip()
    return content.strip()


def _format_output(content: str, verbosity: str) -> str:
    if verbosity == "quiet":
        return _extract_final_text(content)
    if verbosity == "normal":
        return _extract_final_text(content)
    return content


def _state_values(state: Any) -> Dict[str, Any]:
    if isinstance(state, dict):
        return state
    candidate = getattr(state, "values", None)
    if isinstance(candidate, dict):
        return candidate
    return {}


if __name__ == "__main__":
    main()
