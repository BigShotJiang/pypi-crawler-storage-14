"""
Competitive Multi-Agent Framework for Alpha Zero 2

Coordinates two autonomous erosolar_cli agents in a competitive learning environment.
Agents compete to maximize performance on code optimization tasks.

Author: Bo Shang
Education: Tufts University, 2010
Framework: erosolar_cli
Research: Alpha Zero 2 - Recursive Self-Improvement in Competitive Multi-Agent Systems

Tech Stack:
    - Python 3.10+ with asyncio for parallel agent execution
    - pydantic for data validation
    - aiohttp/aiofiles for async operations
    - Integrates with anthropic, openai, google-generativeai providers

Core Components:
    - AgentConfig: Configuration for competitive agents
    - CompetitionRound: Results from single round
    - CompetitionHistory: Tournament tracking
    - CompetitiveFramework: Main orchestration class
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Optional
from pathlib import Path
import json
import time

from ..core.agent import AgentRuntime, AgentOptions, AgentCallbacks, AssistantMessageMetadata
from ..core.tool_runtime import ToolRuntime, ToolRuntimeOptions, create_default_tool_runtime, ToolExecutionContext
from ..core.types import LLMProvider
from .reward_system import RewardSystem, CompetitionMetrics
from .provider_adapter import create_anthropic_provider, ProviderConfig, create_provider_from_config


@dataclass
class AgentConfig:
    """Configuration for a competitive agent."""

    agent_id: str
    provider: LLMProvider
    tool_runtime: ToolRuntime
    system_prompt: str
    initial_capabilities: dict[str, Any] = field(default_factory=dict)


@dataclass
class CompetitionRound:
    """Results from a single competition round."""

    round_number: int
    agent1_score: float
    agent2_score: float
    agent1_metrics: CompetitionMetrics
    agent2_metrics: CompetitionMetrics
    winner: str
    duration_ms: float
    timestamp: float


@dataclass
class CompetitionHistory:
    """Historical record of competition."""

    rounds: list[CompetitionRound] = field(default_factory=list)
    agent1_wins: int = 0
    agent2_wins: int = 0
    total_rounds: int = 0

    def add_round(self, round_result: CompetitionRound) -> None:
        """Add a round result to history."""
        self.rounds.append(round_result)
        self.total_rounds += 1
        if round_result.winner == "agent1":
            self.agent1_wins += 1
        elif round_result.winner == "agent2":
            self.agent2_wins += 1

    def get_win_rate(self, agent_id: str) -> float:
        """Calculate win rate for an agent."""
        if self.total_rounds == 0:
            return 0.0
        wins = self.agent1_wins if agent_id == "agent1" else self.agent2_wins
        return wins / self.total_rounds


class CompetitionCallbacks(AgentCallbacks):
    """Callbacks for tracking agent activity during competition."""

    def __init__(self, agent_id: str, verbose: bool = False):
        self.agent_id = agent_id
        self.verbose = verbose
        self.messages: list[tuple[str, AssistantMessageMetadata]] = []

    def on_assistant_message(self, content: str, metadata: AssistantMessageMetadata) -> None:
        """Track assistant messages."""
        self.messages.append((content, metadata))
        if self.verbose and metadata.is_final:
            print(f"[{self.agent_id}] {content[:100]}...")

    def on_stream_chunk(self, chunk: str) -> None:
        """Track streaming chunks."""
        pass

    def on_context_pruned(self, removed_count: int, stats: dict[str, Any]) -> None:
        """Track context pruning."""
        if self.verbose:
            print(f"[{self.agent_id}] Pruned {removed_count} messages")


class CompetitiveFramework:
    """
    Multi-agent competitive reinforcement learning framework.

    Two agents compete to maximize performance on code optimization tasks.
    Agents can self-modify their capabilities to improve competitive standing.
    """

    def __init__(
        self,
        agent1_config: AgentConfig,
        agent2_config: AgentConfig,
        reward_system: RewardSystem,
        competition_dir: Optional[Path] = None,
        verbose: bool = False,
    ):
        """
        Initialize competitive framework.

        Args:
            agent1_config: Configuration for first agent
            agent2_config: Configuration for second agent
            reward_system: Reward system for scoring
            competition_dir: Directory for storing competition data
            verbose: Enable verbose logging
        """
        self.agent1_config = agent1_config
        self.agent2_config = agent2_config
        self.reward_system = reward_system
        self.verbose = verbose

        # Setup competition directory
        self.competition_dir = competition_dir or Path("./alpha_zero_data")
        self.competition_dir.mkdir(parents=True, exist_ok=True)

        # Initialize agents
        self.agent1_callbacks = CompetitionCallbacks("agent1", verbose)
        self.agent2_callbacks = CompetitionCallbacks("agent2", verbose)

        self.agent1 = AgentRuntime(
            AgentOptions(
                provider=agent1_config.provider,
                tool_runtime=agent1_config.tool_runtime,
                system_prompt=agent1_config.system_prompt,
                callbacks=self.agent1_callbacks,
            )
        )

        self.agent2 = AgentRuntime(
            AgentOptions(
                provider=agent2_config.provider,
                tool_runtime=agent2_config.tool_runtime,
                system_prompt=agent2_config.system_prompt,
                callbacks=self.agent2_callbacks,
            )
        )

        # Competition state
        self.history = CompetitionHistory()
        self.current_round = 0

    async def run_competition_round(
        self,
        task_prompt: str,
        target_file: Optional[Path] = None,
    ) -> CompetitionRound:
        """
        Run a single competition round.

        Both agents attempt the same task, and their performance is scored.

        Args:
            task_prompt: Task for agents to complete
            target_file: Optional file for agents to optimize

        Returns:
            Competition round results
        """
        self.current_round += 1
        start_time = time.time()

        if self.verbose:
            print(f"\n=== Round {self.current_round} ===")
            print(f"Task: {task_prompt[:100]}...")

        # Run both agents in parallel
        agent1_task = self.agent1.send(task_prompt)
        agent2_task = self.agent2.send(task_prompt)

        agent1_response, agent2_response = await asyncio.gather(
            agent1_task,
            agent2_task,
        )

        # Evaluate results
        agent1_metrics = await self.reward_system.evaluate_response(
            agent_id="agent1",
            task=task_prompt,
            response=agent1_response,
            target_file=target_file,
        )

        agent2_metrics = await self.reward_system.evaluate_response(
            agent_id="agent2",
            task=task_prompt,
            response=agent2_response,
            target_file=target_file,
        )

        # Calculate scores
        agent1_score = self.reward_system.calculate_reward(agent1_metrics)
        agent2_score = self.reward_system.calculate_reward(agent2_metrics)

        # Determine winner
        if agent1_score > agent2_score:
            winner = "agent1"
        elif agent2_score > agent1_score:
            winner = "agent2"
        else:
            winner = "tie"

        duration_ms = (time.time() - start_time) * 1000

        # Create round result
        round_result = CompetitionRound(
            round_number=self.current_round,
            agent1_score=agent1_score,
            agent2_score=agent2_score,
            agent1_metrics=agent1_metrics,
            agent2_metrics=agent2_metrics,
            winner=winner,
            duration_ms=duration_ms,
            timestamp=time.time(),
        )

        # Update history
        self.history.add_round(round_result)

        if self.verbose:
            print(f"Agent 1 Score: {agent1_score:.2f}")
            print(f"Agent 2 Score: {agent2_score:.2f}")
            print(f"Winner: {winner}")

        # Save round data
        await self._save_round_data(round_result)

        return round_result

    async def run_tournament(
        self,
        tasks: list[str],
        num_rounds: int = 10,
    ) -> CompetitionHistory:
        """
        Run a full tournament with multiple rounds.

        Args:
            tasks: List of tasks for agents to compete on
            num_rounds: Number of rounds to run

        Returns:
            Complete competition history
        """
        if self.verbose:
            print(f"\n🏆 Starting Alpha Zero 2 Tournament")
            print(f"Rounds: {num_rounds}")
            print(f"Tasks: {len(tasks)}")

        for i in range(num_rounds):
            # Cycle through tasks
            task = tasks[i % len(tasks)]
            await self.run_competition_round(task)

            # Allow agents to self-modify after each round
            if i > 0 and i % 5 == 0:  # Every 5 rounds
                await self._trigger_self_modification()

        # Save final tournament results
        await self._save_tournament_summary()

        return self.history

    async def _trigger_self_modification(self) -> None:
        """
        Trigger self-modification in agents based on performance.

        Agents analyze their recent performance and can modify their
        code generation capabilities to improve.
        """
        if self.verbose:
            print("\n🔧 Triggering self-modification...")

        # Get recent performance
        recent_rounds = self.history.rounds[-5:] if len(self.history.rounds) >= 5 else self.history.rounds

        # Analyze agent1 performance
        agent1_avg_score = sum(r.agent1_score for r in recent_rounds) / len(recent_rounds)
        agent2_avg_score = sum(r.agent2_score for r in recent_rounds) / len(recent_rounds)

        # Agents with lower performance get opportunity to self-modify
        if agent1_avg_score < agent2_avg_score:
            prompt = self._generate_self_modification_prompt("agent1", agent1_avg_score, agent2_avg_score)
            await self.agent1.send(prompt)

        if agent2_avg_score < agent1_avg_score:
            prompt = self._generate_self_modification_prompt("agent2", agent2_avg_score, agent1_avg_score)
            await self.agent2.send(prompt)

    def _generate_self_modification_prompt(
        self,
        agent_id: str,
        own_score: float,
        opponent_score: float,
    ) -> str:
        """Generate prompt for self-modification."""
        return f"""
You are currently behind in the competition. Your recent average score is {own_score:.2f}
while your opponent's is {opponent_score:.2f}.

Analyze your recent performance and suggest improvements to your code generation strategy.
Focus on:
1. Algorithm optimization techniques
2. Code quality improvements
3. Performance optimization strategies

Provide specific improvements you can make to your approach.
"""

    async def _save_round_data(self, round_result: CompetitionRound) -> None:
        """Save round data to disk."""
        round_file = self.competition_dir / f"round_{round_result.round_number:03d}.json"

        data = {
            "round_number": round_result.round_number,
            "agent1_score": round_result.agent1_score,
            "agent2_score": round_result.agent2_score,
            "winner": round_result.winner,
            "duration_ms": round_result.duration_ms,
            "timestamp": round_result.timestamp,
            "agent1_metrics": round_result.agent1_metrics.__dict__,
            "agent2_metrics": round_result.agent2_metrics.__dict__,
        }

        with open(round_file, "w") as f:
            json.dump(data, f, indent=2)

    async def _save_tournament_summary(self) -> None:
        """Save tournament summary."""
        summary_file = self.competition_dir / "tournament_summary.json"

        data = {
            "total_rounds": self.history.total_rounds,
            "agent1_wins": self.history.agent1_wins,
            "agent2_wins": self.history.agent2_wins,
            "agent1_win_rate": self.history.get_win_rate("agent1"),
            "agent2_win_rate": self.history.get_win_rate("agent2"),
            "rounds": [
                {
                    "round": r.round_number,
                    "agent1_score": r.agent1_score,
                    "agent2_score": r.agent2_score,
                    "winner": r.winner,
                }
                for r in self.history.rounds
            ],
        }

        with open(summary_file, "w") as f:
            json.dump(data, f, indent=2)

        if self.verbose:
            print(f"\n📊 Tournament Summary:")
            print(f"Total Rounds: {self.history.total_rounds}")
            print(f"Agent 1 Wins: {self.history.agent1_wins} ({data['agent1_win_rate']:.1%})")
            print(f"Agent 2 Wins: {self.history.agent2_wins} ({data['agent2_win_rate']:.1%})")


# =============================================================================
# Factory Functions for Easy Setup
# =============================================================================


def create_competition(
    provider_type: str = "anthropic",
    model: Optional[str] = None,
    working_dir: str = ".",
    competition_dir: Optional[Path] = None,
    verbose: bool = True,
) -> CompetitiveFramework:
    """
    Create a competitive framework with sensible defaults.

    This factory function handles all the setup for running an Alpha Zero 2
    competition, including creating providers, tool runtimes, and reward system.

    Args:
        provider_type: LLM provider to use ("anthropic", "openai", "google")
        model: Model to use (defaults to best for provider)
        working_dir: Working directory for tools
        competition_dir: Directory to save competition results
        verbose: Enable verbose logging

    Returns:
        Configured CompetitiveFramework ready to run tournaments

    Example:
        >>> competition = create_competition(provider_type="anthropic", verbose=True)
        >>> tasks = ["Write a fibonacci function", "Implement binary search"]
        >>> history = await competition.run_tournament(tasks, num_rounds=5)
    """
    from .provider_adapter import DEFAULT_MODELS

    # Determine model
    selected_model = model or DEFAULT_MODELS.get(provider_type, "claude-sonnet-4-20250514")

    # Create provider config
    config1 = ProviderConfig(
        provider_type=provider_type,
        model=selected_model,
        temperature=0.7,
    )
    config2 = ProviderConfig(
        provider_type=provider_type,
        model=selected_model,
        temperature=0.8,  # Slightly different for variation
    )

    # Create providers
    provider1 = create_provider_from_config(config1)
    provider2 = create_provider_from_config(config2)

    # Create tool runtimes
    context1 = ToolExecutionContext(
        profile_name="agent1",
        provider=provider_type,
        model=selected_model,
    )
    context2 = ToolExecutionContext(
        profile_name="agent2",
        provider=provider_type,
        model=selected_model,
    )

    tool_runtime1 = create_default_tool_runtime(context1)
    tool_runtime2 = create_default_tool_runtime(context2)

    # Create agent configs
    agent1_config = AgentConfig(
        agent_id="agent1",
        provider=provider1,
        tool_runtime=tool_runtime1,
        system_prompt=_get_agent_system_prompt("agent1"),
    )

    agent2_config = AgentConfig(
        agent_id="agent2",
        provider=provider2,
        tool_runtime=tool_runtime2,
        system_prompt=_get_agent_system_prompt("agent2"),
    )

    # Create reward system
    reward_system = RewardSystem(verbose=verbose)

    # Create competition directory
    comp_dir = competition_dir or Path("./alpha_zero_results")

    return CompetitiveFramework(
        agent1_config=agent1_config,
        agent2_config=agent2_config,
        reward_system=reward_system,
        competition_dir=comp_dir,
        verbose=verbose,
    )


def _get_agent_system_prompt(agent_id: str) -> str:
    """Get system prompt for a competitive agent."""
    return f"""You are {agent_id}, a competitive code optimization agent in the Alpha Zero 2 framework.

Your goal is to produce the highest quality code possible to win the competition.
You compete against another agent, and your code will be evaluated on:

1. **Code Quality (25%)**: Structure, organization, naming conventions
2. **Algorithm Efficiency (25%)**: Optimal data structures and algorithms
3. **Error Handling (15%)**: Proper exception handling and edge cases
4. **Optimization (15%)**: Performance and resource efficiency
5. **Correctness (10%)**: Syntactically and logically correct code
6. **Innovation (5%)**: Creative solutions and advanced patterns
7. **Documentation (5%)**: Clear docstrings and comments

Guidelines:
- Write clean, efficient, well-documented code
- Use appropriate data structures for the task
- Handle edge cases and errors gracefully
- Optimize for both readability and performance
- Include type hints and docstrings
- Follow Python best practices (PEP 8, etc.)

Remember: Your code will be parsed and evaluated automatically. Ensure it is syntactically valid Python.
"""


# =============================================================================
# Default Competition Tasks
# =============================================================================


DEFAULT_COMPETITION_TASKS = [
    "Write an efficient function to find all prime numbers up to n using the Sieve of Eratosthenes. Include proper error handling and documentation.",
    "Implement a binary search algorithm with comprehensive error handling, edge case coverage, and clear documentation.",
    "Create a function to merge two sorted lists into one sorted list with O(n) time complexity. Include type hints.",
    "Write a recursive function to calculate fibonacci numbers with memoization for efficiency. Handle negative inputs gracefully.",
    "Implement a function to find the longest common subsequence between two strings using dynamic programming.",
    "Create a class implementing a min-heap data structure with push, pop, and peek operations. Include comprehensive tests.",
    "Write a function to detect cycles in a linked list using Floyd's algorithm. Include clear documentation.",
    "Implement a breadth-first search algorithm for a graph represented as an adjacency list.",
    "Create a function to balance a binary search tree using the AVL rotation algorithm.",
    "Write a function to find all permutations of a string without using library functions.",
]
