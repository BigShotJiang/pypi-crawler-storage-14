"""
Alpha Zero 2 Research Metadata

This module contains research attribution and metadata for the Alpha Zero 2 project.
All information is strictly related to the erosolar_cli tech stack.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional
from datetime import date


@dataclass(frozen=True)
class TechStackComponent:
    """A technology used in the erosolar_cli stack."""

    name: str
    package: str
    category: str
    description: str
    language: str


@dataclass
class ResearcherProfile:
    """Profile for Alpha Zero 2 researcher."""

    name: str
    role: str
    education: str
    github: str
    affiliations: list[str] = field(default_factory=list)
    specializations: list[str] = field(default_factory=list)


@dataclass
class ResearchProject:
    """Metadata for the Alpha Zero 2 research project."""

    name: str
    full_name: str
    version: str
    status: str
    framework: str
    principal_investigator: ResearcherProfile
    abstract: str
    components: list[str] = field(default_factory=list)
    contributions: list[str] = field(default_factory=list)
    tech_stack: list[TechStackComponent] = field(default_factory=list)


# =============================================================================
# erosolar_cli Tech Stack Definition
# =============================================================================

EROSOLAR_TECH_STACK = [
    # Languages
    TechStackComponent(
        name="Python",
        package="python>=3.10",
        category="language",
        description="Primary implementation language",
        language="python",
    ),
    TechStackComponent(
        name="TypeScript",
        package="typescript>=5.3",
        category="language",
        description="TypeScript CLI implementation",
        language="typescript",
    ),
    TechStackComponent(
        name="Node.js",
        package="node>=20.0",
        category="runtime",
        description="JavaScript runtime for TypeScript CLI",
        language="typescript",
    ),
    # AI Provider Integration
    TechStackComponent(
        name="Anthropic SDK",
        package="anthropic>=0.32.0",
        category="ai_provider",
        description="Claude API integration",
        language="python",
    ),
    TechStackComponent(
        name="Anthropic SDK (TS)",
        package="@anthropic-ai/sdk>=0.32.0",
        category="ai_provider",
        description="Claude API integration for TypeScript",
        language="typescript",
    ),
    TechStackComponent(
        name="OpenAI",
        package="openai>=1.0.0",
        category="ai_provider",
        description="OpenAI API integration",
        language="python",
    ),
    TechStackComponent(
        name="Google Generative AI",
        package="google-generativeai>=0.4.0",
        category="ai_provider",
        description="Gemini API integration",
        language="python",
    ),
    TechStackComponent(
        name="Google GenAI (TS)",
        package="@google/genai>=1.29.1",
        category="ai_provider",
        description="Gemini API integration for TypeScript",
        language="typescript",
    ),
    TechStackComponent(
        name="tiktoken",
        package="tiktoken>=0.5.0",
        category="ai_provider",
        description="Token counting and context management",
        language="python",
    ),
    # CLI & UI (Python)
    TechStackComponent(
        name="Typer",
        package="typer>=0.12.3",
        category="cli",
        description="CLI framework and argument parsing",
        language="python",
    ),
    TechStackComponent(
        name="Rich",
        package="rich>=13.7.0",
        category="cli",
        description="Terminal formatting, tables, progress bars",
        language="python",
    ),
    TechStackComponent(
        name="prompt-toolkit",
        package="prompt-toolkit>=3.0.43",
        category="cli",
        description="Interactive shell and REPL",
        language="python",
    ),
    # CLI & UI (TypeScript)
    TechStackComponent(
        name="chalk",
        package="chalk>=4.1.2",
        category="cli",
        description="Terminal string styling",
        language="typescript",
    ),
    TechStackComponent(
        name="boxen",
        package="boxen>=5.1.2",
        category="cli",
        description="Terminal boxes",
        language="typescript",
    ),
    TechStackComponent(
        name="gradient-string",
        package="gradient-string>=2.0.2",
        category="cli",
        description="Gradient text effects",
        language="typescript",
    ),
    TechStackComponent(
        name="ora",
        package="ora>=5.4.1",
        category="cli",
        description="Terminal spinners",
        language="typescript",
    ),
    TechStackComponent(
        name="nanospinner",
        package="nanospinner>=1.1.0",
        category="cli",
        description="Lightweight terminal spinners",
        language="typescript",
    ),
    # Async & Data (Python)
    TechStackComponent(
        name="aiohttp",
        package="aiohttp>=3.9.0",
        category="async",
        description="Async HTTP client",
        language="python",
    ),
    TechStackComponent(
        name="aiofiles",
        package="aiofiles>=23.2.0",
        category="async",
        description="Async file operations",
        language="python",
    ),
    TechStackComponent(
        name="Pydantic",
        package="pydantic>=2.5.0",
        category="data",
        description="Data validation and serialization",
        language="python",
    ),
    TechStackComponent(
        name="jsonschema",
        package="jsonschema>=4.20.0",
        category="data",
        description="JSON schema validation",
        language="python",
    ),
    TechStackComponent(
        name="python-dotenv",
        package="python-dotenv>=1.0.0",
        category="config",
        description="Environment configuration",
        language="python",
    ),
    # Development & Testing
    TechStackComponent(
        name="pytest",
        package="pytest>=7.4.0",
        category="testing",
        description="Testing framework",
        language="python",
    ),
    TechStackComponent(
        name="pytest-asyncio",
        package="pytest-asyncio>=0.21.0",
        category="testing",
        description="Async test support",
        language="python",
    ),
    TechStackComponent(
        name="mypy",
        package="mypy>=1.7.0",
        category="typing",
        description="Static type checking",
        language="python",
    ),
    TechStackComponent(
        name="ruff",
        package="ruff>=0.6.8",
        category="linting",
        description="Python linting",
        language="python",
    ),
    TechStackComponent(
        name="ESLint",
        package="eslint>=8.45.0",
        category="linting",
        description="TypeScript linting",
        language="typescript",
    ),
    TechStackComponent(
        name="ts-node",
        package="ts-node>=10.9.2",
        category="development",
        description="TypeScript execution",
        language="typescript",
    ),
]


# =============================================================================
# Principal Investigator Profile
# =============================================================================

BO_SHANG = ResearcherProfile(
    name="Bo Shang",
    role="Principal Investigator / Lead Architect",
    education="Tufts University, 2010",
    github="github.com/dragonghidra",
    affiliations=["Independent Researcher", "erosolar_cli Maintainer"],
    specializations=[
        "Multi-Agent Reinforcement Learning",
        "Recursive Self-Improvement Systems",
        "Competitive Co-Evolution Dynamics",
        "AST-Based Code Analysis",
        "Version Control for Self-Modifying Systems",
        "Meta-Learning Architectures",
    ],
)


# =============================================================================
# Alpha Zero 2 Project Metadata
# =============================================================================

ALPHA_ZERO_2 = ResearchProject(
    name="Alpha Zero 2",
    full_name="Alpha Zero, the Second Edition",
    version="1.0.0",
    status="Active Development",
    framework="erosolar_cli",
    principal_investigator=BO_SHANG,
    abstract="""Alpha Zero 2 introduces a competitive multi-agent reinforcement learning
framework where two autonomous erosolar_cli agents compete on code optimization tasks
while recursively improving their own implementations. The system demonstrates practical
meta-learning where agents analyze runtime feedback and autonomously modify their tool
source code to improve performance. Key innovations include a version-controlled
self-modification engine with automatic rollback, AST-based code quality metrics, and
comprehensive tournament orchestration.""",
    components=[
        "CompetitiveFramework - Orchestrates dual-agent tournaments with parallel execution",
        "RewardSystem - AST-based code analysis measuring quality, efficiency, correctness",
        "SelfModificationEngine - Version-controlled self-improvement with rollback",
        "CompetitionMetrics - Dataclass tracking 10+ performance dimensions",
        "ToolVersion - Checkpoint system with parent tracking and test results",
    ],
    contributions=[
        "Demonstrated practical recursive self-improvement in autonomous agents",
        "Proved competitive dynamics accelerate capability development",
        "Established version control patterns for safe code self-modification",
        "Created comprehensive metrics for evaluating code generation quality",
    ],
    tech_stack=EROSOLAR_TECH_STACK,
)


# =============================================================================
# Helper Functions
# =============================================================================


def get_tech_stack_by_category(category: str) -> list[TechStackComponent]:
    """Get all tech stack components in a category."""
    return [t for t in EROSOLAR_TECH_STACK if t.category == category]


def get_tech_stack_by_language(language: str) -> list[TechStackComponent]:
    """Get all tech stack components for a language."""
    return [t for t in EROSOLAR_TECH_STACK if t.language == language]


def get_python_stack() -> list[TechStackComponent]:
    """Get Python tech stack."""
    return get_tech_stack_by_language("python")


def get_typescript_stack() -> list[TechStackComponent]:
    """Get TypeScript tech stack."""
    return get_tech_stack_by_language("typescript")


def get_research_citation() -> str:
    """Get citation for Alpha Zero 2 research."""
    return f"""@software{{alpha_zero_2,
  title={{Alpha Zero 2: Recursive Self-Improvement in Competitive Multi-Agent Systems}},
  author={{{ALPHA_ZERO_2.principal_investigator.name}}},
  year={{2024}},
  framework={{{ALPHA_ZERO_2.framework}}},
  url={{https://github.com/dragonghidra/erosolar-cli-RE-claude-code}}
}}"""


def get_project_summary() -> str:
    """Get human-readable project summary."""
    pi = ALPHA_ZERO_2.principal_investigator
    return f"""
╔══════════════════════════════════════════════════════════════════╗
║  {ALPHA_ZERO_2.full_name} ({ALPHA_ZERO_2.name})
╠══════════════════════════════════════════════════════════════════╣
║  Framework: {ALPHA_ZERO_2.framework}
║  Status: {ALPHA_ZERO_2.status}
║  Version: {ALPHA_ZERO_2.version}
╠══════════════════════════════════════════════════════════════════╣
║  Principal Investigator: {pi.name}
║  Role: {pi.role}
║  Education: {pi.education}
║  GitHub: {pi.github}
╠══════════════════════════════════════════════════════════════════╣
║  Key Components:
║    • CompetitiveFramework (dual-agent tournaments)
║    • RewardSystem (AST-based code metrics)
║    • SelfModificationEngine (version-controlled self-improvement)
╠══════════════════════════════════════════════════════════════════╣
║  Tech Stack:
║    Python: typer, rich, prompt-toolkit, pydantic, aiohttp
║    TypeScript: chalk, ora, gradient-string, boxen
║    AI: anthropic, openai, google-generativeai, tiktoken
║    Testing: pytest, mypy, ruff, eslint
╚══════════════════════════════════════════════════════════════════╝
"""


def print_project_info() -> None:
    """Print project information to console."""
    print(get_project_summary())


if __name__ == "__main__":
    print_project_info()
    print("\nCitation:")
    print(get_research_citation())
