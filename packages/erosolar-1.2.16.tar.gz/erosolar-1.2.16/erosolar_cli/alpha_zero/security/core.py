"""
Core Security Research Framework

Base authorization system and reconnaissance capabilities.
All operations require explicit authorization.

LEGAL NOTICE:
These tools are intended for authorized security research only.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from __future__ import annotations

import asyncio
import json
import re
import socket
import ssl
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Optional


class AuthorizationScope(Enum):
    """Scope of authorization for security testing."""

    OWNED_SYSTEMS = "owned_systems"
    BUG_BOUNTY = "bug_bounty"
    PENTEST_ENGAGEMENT = "pentest_engagement"
    CTF_COMPETITION = "ctf_competition"
    RED_TEAM = "red_team"
    EDUCATIONAL = "educational"


@dataclass
class AuthorizationRecord:
    """Record of authorization for security testing."""

    scope: AuthorizationScope
    target_domain: str
    authorized_by: str
    authorization_date: str
    expiration_date: Optional[str] = None
    scope_limitations: list[str] = field(default_factory=list)
    out_of_scope: list[str] = field(default_factory=list)
    notes: str = ""

    def is_valid(self) -> bool:
        """Check if authorization is still valid."""
        if not self.expiration_date:
            return True
        exp = datetime.fromisoformat(self.expiration_date)
        return datetime.now() < exp

    def is_target_in_scope(self, target: str) -> bool:
        """Check if a target is within scope."""
        for oos in self.out_of_scope:
            if oos in target:
                return False
        return self.target_domain in target or target.endswith(self.target_domain)


@dataclass
class ReconResult:
    """Results from reconnaissance."""

    target: str
    timestamp: float
    dns_records: dict[str, list[str]] = field(default_factory=dict)
    open_ports: list[int] = field(default_factory=list)
    ssl_info: dict[str, Any] = field(default_factory=dict)
    http_headers: dict[str, str] = field(default_factory=dict)
    technologies: list[str] = field(default_factory=list)
    subdomains: list[str] = field(default_factory=list)
    potential_vectors: list[str] = field(default_factory=list)


@dataclass
class VulnerabilityFinding:
    """A potential vulnerability finding."""

    title: str
    severity: str  # critical, high, medium, low, info
    category: str  # injection, auth, config, crypto, etc.
    description: str
    evidence: str
    remediation: str
    cvss_score: Optional[float] = None
    cwe_id: Optional[str] = None
    affected_component: str = ""


class SecurityResearchEngine:
    """
    Engine for authorized security research.

    All operations require explicit authorization records.
    """

    def __init__(
        self,
        data_dir: Optional[Path] = None,
        authorization: Optional[AuthorizationRecord] = None,
        verbose: bool = False,
    ):
        self.data_dir = data_dir or Path(".security_research")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.authorization = authorization
        self.verbose = verbose
        self.findings: list[VulnerabilityFinding] = []
        self.recon_results: list[ReconResult] = []

    def set_authorization(self, authorization: AuthorizationRecord) -> None:
        """Set authorization for testing."""
        self.authorization = authorization
        self._save_authorization()
        if self.verbose:
            print(f"[Authorization] Set for {authorization.target_domain}")

    def _check_authorization(self, target: str) -> bool:
        """Verify authorization before any operation."""
        if not self.authorization:
            raise PermissionError("No authorization record set.")
        if not self.authorization.is_valid():
            raise PermissionError("Authorization has expired.")
        if not self.authorization.is_target_in_scope(target):
            raise PermissionError(f"Target {target} is not within authorized scope.")
        return True

    async def passive_recon(self, target: str) -> ReconResult:
        """Perform passive reconnaissance on an authorized target."""
        self._check_authorization(target)
        if self.verbose:
            print(f"[Recon] Starting passive reconnaissance on {target}")

        result = ReconResult(target=target, timestamp=time.time())
        result.dns_records = await self._dns_lookup(target)
        result.subdomains = await self._ct_log_search(target)
        result.technologies = await self._technology_detection(target)

        self.recon_results.append(result)
        return result

    async def active_recon(self, target: str, ports: list[int] = None) -> ReconResult:
        """Perform active reconnaissance (requires stronger authorization)."""
        self._check_authorization(target)

        if self.authorization.scope not in [
            AuthorizationScope.OWNED_SYSTEMS,
            AuthorizationScope.PENTEST_ENGAGEMENT,
            AuthorizationScope.RED_TEAM,
            AuthorizationScope.CTF_COMPETITION,
        ]:
            raise PermissionError("Active recon requires stronger authorization.")

        ports = ports or [80, 443, 8080, 8443]
        result = ReconResult(target=target, timestamp=time.time())

        result.open_ports = await self._port_scan(target, ports)
        if 443 in result.open_ports:
            result.ssl_info = await self._ssl_analysis(target)
        if any(p in result.open_ports for p in [80, 443, 8080, 8443]):
            result.http_headers = await self._http_headers(target)
        result.potential_vectors = self._identify_vectors(result)

        self.recon_results.append(result)
        return result

    async def _dns_lookup(self, domain: str) -> dict[str, list[str]]:
        """Perform DNS lookups."""
        records = {}
        try:
            try:
                ips = socket.gethostbyname_ex(domain)[2]
                records["A"] = ips
            except socket.gaierror:
                pass

            for record_type in ["MX", "TXT", "NS"]:
                try:
                    result = subprocess.run(
                        ["dig", "+short", record_type, domain],
                        capture_output=True, text=True, timeout=10,
                    )
                    if result.stdout.strip():
                        records[record_type] = result.stdout.strip().split("\n")
                except (subprocess.TimeoutExpired, FileNotFoundError):
                    pass
        except Exception:
            pass
        return records

    async def _ct_log_search(self, domain: str) -> list[str]:
        """Search for subdomains via common patterns."""
        prefixes = ["www", "mail", "api", "dev", "staging", "admin", "app"]
        return [f"{p}.{domain}" for p in prefixes]

    async def _technology_detection(self, target: str) -> list[str]:
        """Detect technologies from HTTP headers."""
        technologies = []
        try:
            import urllib.request
            url = f"https://{target}" if not target.startswith("http") else target
            req = urllib.request.Request(url, method="HEAD")
            req.add_header("User-Agent", "Mozilla/5.0 (Security Research)")
            try:
                with urllib.request.urlopen(req, timeout=10) as response:
                    headers = dict(response.headers)
                    if "Server" in headers:
                        technologies.append(f"Server: {headers['Server']}")
                    if "X-Powered-By" in headers:
                        technologies.append(f"Powered-By: {headers['X-Powered-By']}")
            except Exception:
                pass
        except Exception:
            pass
        return technologies

    async def _port_scan(self, target: str, ports: list[int]) -> list[int]:
        """Scan for open ports."""
        open_ports = []

        async def check_port(port: int) -> Optional[int]:
            try:
                ip = socket.gethostbyname(target)
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(2)
                result = sock.connect_ex((ip, port))
                sock.close()
                return port if result == 0 else None
            except Exception:
                return None

        tasks = [check_port(port) for port in ports]
        results = await asyncio.gather(*tasks)
        return [p for p in results if p is not None]

    async def _ssl_analysis(self, target: str) -> dict[str, Any]:
        """Analyze SSL/TLS configuration."""
        info = {}
        try:
            context = ssl.create_default_context()
            with socket.create_connection((target, 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname=target) as ssock:
                    cert = ssock.getpeercert()
                    info["version"] = ssock.version()
                    info["cipher"] = ssock.cipher()
                    info["subject"] = dict(x[0] for x in cert.get("subject", []))
                    info["issuer"] = dict(x[0] for x in cert.get("issuer", []))
        except Exception as e:
            info["error"] = str(e)
        return info

    async def _http_headers(self, target: str) -> dict[str, str]:
        """Fetch HTTP headers."""
        headers = {}
        try:
            import urllib.request
            for scheme in ["https", "http"]:
                try:
                    url = f"{scheme}://{target}"
                    req = urllib.request.Request(url, method="HEAD")
                    req.add_header("User-Agent", "Mozilla/5.0 (Security Research)")
                    with urllib.request.urlopen(req, timeout=10) as response:
                        headers = dict(response.headers)
                        break
                except Exception:
                    continue
        except Exception:
            pass
        return headers

    def _identify_vectors(self, recon: ReconResult) -> list[str]:
        """Identify potential attack vectors."""
        vectors = []
        security_headers = [
            "Strict-Transport-Security", "Content-Security-Policy",
            "X-Frame-Options", "X-Content-Type-Options",
        ]
        for header in security_headers:
            if header not in recon.http_headers:
                vectors.append(f"Missing: {header}")

        ssl_info = recon.ssl_info
        if ssl_info:
            version = ssl_info.get("version", "")
            if "TLSv1.0" in version or "TLSv1.1" in version:
                vectors.append(f"Weak TLS: {version}")
        return vectors

    def analyze_for_vulnerabilities(self, recon: ReconResult) -> list[VulnerabilityFinding]:
        """Analyze recon results for potential vulnerabilities."""
        self._check_authorization(recon.target)
        findings = []

        # Security headers analysis
        headers = recon.http_headers
        if "Strict-Transport-Security" not in headers:
            findings.append(VulnerabilityFinding(
                title="Missing HSTS Header",
                severity="medium",
                category="config",
                description="HSTS header not set.",
                evidence="Header not present",
                remediation="Add Strict-Transport-Security header",
                cwe_id="CWE-319",
            ))

        if "Content-Security-Policy" not in headers:
            findings.append(VulnerabilityFinding(
                title="Missing CSP",
                severity="medium",
                category="config",
                description="No Content-Security-Policy header.",
                evidence="Header not present",
                remediation="Implement strict CSP",
                cwe_id="CWE-79",
            ))

        self.findings.extend(findings)
        return findings

    def generate_report(self, format: str = "text") -> str:
        """Generate security research report."""
        if format == "json":
            return self._generate_json_report()
        return self._generate_text_report()

    def _generate_text_report(self) -> str:
        """Generate plain text report."""
        lines = [
            "=" * 60,
            "SECURITY RESEARCH REPORT",
            "=" * 60,
            f"Generated: {datetime.now().isoformat()}",
        ]
        if self.authorization:
            lines.extend([
                f"Target: {self.authorization.target_domain}",
                f"Scope: {self.authorization.scope.value}",
            ])
        if self.findings:
            lines.append(f"\nFindings: {len(self.findings)}")
            for f in self.findings:
                lines.append(f"  [{f.severity.upper()}] {f.title}")
        return "\n".join(lines)

    def _generate_json_report(self) -> str:
        """Generate JSON report."""
        report = {
            "generated": datetime.now().isoformat(),
            "authorization": {
                "scope": self.authorization.scope.value,
                "target": self.authorization.target_domain,
            } if self.authorization else None,
            "findings": [
                {"title": f.title, "severity": f.severity, "category": f.category}
                for f in self.findings
            ],
        }
        return json.dumps(report, indent=2)

    def _save_authorization(self) -> None:
        """Save authorization record."""
        if not self.authorization:
            return
        auth_file = self.data_dir / "authorization.json"
        data = {
            "scope": self.authorization.scope.value,
            "target_domain": self.authorization.target_domain,
            "authorized_by": self.authorization.authorized_by,
            "authorization_date": self.authorization.authorization_date,
        }
        with open(auth_file, "w") as f:
            json.dump(data, f, indent=2)


# Convenience functions

def create_bug_bounty_authorization(
    target_domain: str,
    program_name: str,
    scope_limitations: list[str] = None,
    out_of_scope: list[str] = None,
) -> AuthorizationRecord:
    """Create authorization for bug bounty testing."""
    return AuthorizationRecord(
        scope=AuthorizationScope.BUG_BOUNTY,
        target_domain=target_domain,
        authorized_by=f"Bug Bounty: {program_name}",
        authorization_date=datetime.now().isoformat(),
        scope_limitations=scope_limitations or [],
        out_of_scope=out_of_scope or [],
    )


def create_pentest_authorization(
    target_domain: str,
    client_name: str,
    engagement_id: str,
    expiration_date: str,
) -> AuthorizationRecord:
    """Create authorization for penetration testing."""
    return AuthorizationRecord(
        scope=AuthorizationScope.PENTEST_ENGAGEMENT,
        target_domain=target_domain,
        authorized_by=f"Client: {client_name} ({engagement_id})",
        authorization_date=datetime.now().isoformat(),
        expiration_date=expiration_date,
    )


def create_ctf_authorization(
    target_domain: str,
    ctf_name: str,
) -> AuthorizationRecord:
    """Create authorization for CTF competition."""
    return AuthorizationRecord(
        scope=AuthorizationScope.CTF_COMPETITION,
        target_domain=target_domain,
        authorized_by=f"CTF: {ctf_name}",
        authorization_date=datetime.now().isoformat(),
    )


__all__ = [
    "AuthorizationScope",
    "AuthorizationRecord",
    "ReconResult",
    "VulnerabilityFinding",
    "SecurityResearchEngine",
    "create_bug_bounty_authorization",
    "create_pentest_authorization",
    "create_ctf_authorization",
]
