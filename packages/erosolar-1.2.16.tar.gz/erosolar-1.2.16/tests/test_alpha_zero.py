"""
Tests for Alpha Zero 2 Framework
"""

import asyncio
from pathlib import Path
import tempfile
import pytest

from erosolar_cli.alpha_zero import RewardSystem, SelfModificationEngine, CompetitionMetrics


class TestRewardSystem:
    """Test reward system functionality."""

    def test_reward_system_initialization(self):
        """Test reward system can be initialized."""
        reward_system = RewardSystem(verbose=False)
        assert reward_system is not None
        assert reward_system.weights["code_quality"] == 0.25

    def test_custom_weights(self):
        """Test custom weights can be set."""
        custom_weights = {
            "code_quality": 0.5,
            "algorithm_efficiency": 0.3,
            "error_handling": 0.2,
            "optimization": 0.0,
            "correctness": 0.0,
            "innovation": 0.0,
            "documentation": 0.0,
        }
        reward_system = RewardSystem(weights=custom_weights, verbose=False)
        assert reward_system.weights["code_quality"] == 0.5

    @pytest.mark.asyncio
    async def test_evaluate_code_with_valid_python(self):
        """Test evaluation of valid Python code."""
        reward_system = RewardSystem(verbose=False)

        sample_code = '''
def fibonacci(n):
    """Calculate fibonacci number."""
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)
'''

        metrics = await reward_system._evaluate_code(sample_code)
        assert metrics.syntax_validity == 1.0
        assert metrics.code_quality_score > 0
        assert metrics.documentation_quality > 0

    @pytest.mark.asyncio
    async def test_evaluate_code_with_invalid_syntax(self):
        """Test evaluation of code with syntax errors."""
        reward_system = RewardSystem(verbose=False)

        invalid_code = "def broken( invalid syntax"

        metrics = await reward_system._evaluate_code(invalid_code)
        assert metrics.syntax_validity == 0.0
        assert metrics.code_quality_score == 0.0

    def test_calculate_reward(self):
        """Test reward calculation from metrics."""
        reward_system = RewardSystem(verbose=False)

        metrics = CompetitionMetrics(
            code_quality_score=0.8,
            algorithm_efficiency=0.7,
            error_handling_score=0.6,
            syntax_validity=1.0,
            logic_correctness=0.9,
            completeness=0.8,
            innovation_score=0.5,
            documentation_quality=0.7,
        )

        reward = reward_system.calculate_reward(metrics)
        assert 0 <= reward <= 100
        assert reward > 50  # Should be above average with these scores

    def test_extract_code_blocks(self):
        """Test extraction of code blocks from markdown."""
        reward_system = RewardSystem(verbose=False)

        markdown_text = '''
Here's some code:

```python
def hello():
    print("world")
```

And more text.

```
def another():
    pass
```
'''

        code_blocks = reward_system._extract_code_blocks(markdown_text)
        assert len(code_blocks) == 2
        assert "def hello():" in code_blocks[0]
        assert "def another():" in code_blocks[1]

    def test_performance_summary(self):
        """Test generation of performance summary."""
        reward_system = RewardSystem(verbose=False)

        metrics = CompetitionMetrics(
            code_quality_score=0.9,
            algorithm_efficiency=0.85,
            error_handling_score=0.8,
            syntax_validity=1.0,
            logic_correctness=0.95,
            completeness=0.9,
            innovation_score=0.7,
            documentation_quality=0.85,
        )

        summary = reward_system.get_performance_summary(metrics)
        assert "Performance Rating:" in summary
        assert "Code Quality:" in summary
        assert "Algorithm Efficiency:" in summary


class TestSelfModificationEngine:
    """Test self-modification engine functionality."""

    def test_initialization(self):
        """Test engine can be initialized."""
        with tempfile.TemporaryDirectory() as tmpdir:
            tools_dir = Path(tmpdir)
            engine = SelfModificationEngine(tools_dir=tools_dir, verbose=False)
            assert engine is not None
            assert engine.tools_dir == tools_dir

    def test_version_id_generation(self):
        """Test version ID generation is consistent."""
        with tempfile.TemporaryDirectory() as tmpdir:
            engine = SelfModificationEngine(tools_dir=Path(tmpdir), verbose=False)

            code1 = "def test(): pass"
            code2 = "def test(): pass"
            code3 = "def other(): pass"

            id1 = engine._generate_version_id(code1)
            id2 = engine._generate_version_id(code2)
            id3 = engine._generate_version_id(code3)

            assert id1 == id2  # Same code = same ID
            assert id1 != id3  # Different code = different ID

    def test_analyze_feedback(self):
        """Test runtime feedback analysis."""
        with tempfile.TemporaryDirectory() as tmpdir:
            engine = SelfModificationEngine(tools_dir=Path(tmpdir), verbose=False)

            # Slow execution feedback
            feedback1 = {"execution_time_ms": 2000, "error_count": 0}
            optimizations1 = engine._analyze_feedback(feedback1)
            assert optimizations1["reduce_latency"] is True
            assert optimizations1["add_caching"] is True

            # Error feedback
            feedback2 = {"execution_time_ms": 100, "error_count": 5}
            optimizations2 = engine._analyze_feedback(feedback2)
            assert optimizations2["add_error_handling"] is True

            # Low accuracy feedback
            feedback3 = {"accuracy": 0.8}
            optimizations3 = engine._analyze_feedback(feedback3)
            assert optimizations3["improve_accuracy"] is True
            assert optimizations3["optimize_algorithms"] is True

    @pytest.mark.asyncio
    async def test_save_and_load_version(self):
        """Test version saving and loading."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero.self_modification import ToolVersion

            engine = SelfModificationEngine(
                tools_dir=Path(tmpdir), checkpoint_dir=Path(tmpdir) / "checkpoints", verbose=False
            )

            version = ToolVersion(
                version_id="test123",
                tool_name="test_tool",
                source_code="def test(): pass",
                timestamp=0.0,
                is_working=True,
            )

            await engine._save_version(version)

            # Check files were created
            checkpoint_dir = Path(tmpdir) / "checkpoints"
            assert (checkpoint_dir / "test_tool_test123.json").exists()
            assert (checkpoint_dir / "test_tool_test123.py").exists()


class TestCompetitionMetrics:
    """Test competition metrics data class."""

    def test_metrics_initialization(self):
        """Test metrics can be created with defaults."""
        metrics = CompetitionMetrics()
        assert metrics.code_quality_score == 0.0
        assert metrics.algorithm_efficiency == 0.0
        assert metrics.evaluation_notes == {}

    def test_metrics_with_values(self):
        """Test metrics can be created with custom values."""
        metrics = CompetitionMetrics(
            code_quality_score=0.9,
            algorithm_efficiency=0.8,
            error_handling_score=0.7,
            raw_response="test response",
        )
        assert metrics.code_quality_score == 0.9
        assert metrics.algorithm_efficiency == 0.8
        assert metrics.raw_response == "test response"


class TestIntrospectionEngine:
    """Test introspection engine functionality."""

    def test_initialization(self):
        """Test engine can be initialized."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import IntrospectionEngine

            engine = IntrospectionEngine(data_dir=Path(tmpdir), verbose=False)
            assert engine is not None
            assert engine.data_dir == Path(tmpdir)

    def test_code_analysis(self):
        """Test code analysis."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import IntrospectionEngine

            engine = IntrospectionEngine(data_dir=Path(tmpdir), verbose=False)

            code = '''
def fibonacci(n: int) -> int:
    """Calculate fibonacci number recursively."""
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


class Calculator:
    """Simple calculator class."""

    def add(self, a: int, b: int) -> int:
        return a + b
'''
            analysis = engine.analyze_code(code, "test.py")
            assert analysis.num_functions == 2  # fibonacci + add
            assert analysis.num_classes == 1
            assert analysis.has_docstrings
            assert analysis.has_type_hints
            assert analysis.syntax_validity is None or analysis.lines_of_code > 0

    def test_profile_execution(self):
        """Test execution profiling."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import IntrospectionEngine

            engine = IntrospectionEngine(data_dir=Path(tmpdir), verbose=False)

            def sample_function(x: int) -> int:
                return x * 2

            result, trace = engine.profile_execution(sample_function, 5)
            assert result == 10
            assert trace.success
            assert trace.execution_time_ms >= 0
            assert trace.function_name == "sample_function"

    def test_profile_with_error(self):
        """Test profiling handles errors."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import IntrospectionEngine

            engine = IntrospectionEngine(data_dir=Path(tmpdir), verbose=False)

            def failing_function(x: int) -> int:
                raise ValueError("Test error")

            result, trace = engine.profile_execution(failing_function, 5)
            assert result is None
            assert not trace.success
            assert "ValueError" in trace.error_message

    def test_improvement_suggestions(self):
        """Test improvement suggestion generation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import IntrospectionEngine, CodeAnalysis

            engine = IntrospectionEngine(data_dir=Path(tmpdir), verbose=False)

            # Create analysis with issues
            analysis = CodeAnalysis(
                file_path="test.py",
                cyclomatic_complexity=15,  # High complexity
                has_docstrings=False,
                has_type_hints=False,
                comment_ratio=0.01,  # Low comments
            )

            suggestions = engine.generate_suggestions(analysis)
            assert len(suggestions) > 0
            categories = [s.category for s in suggestions]
            assert "maintainability" in categories  # High complexity
            assert "quality" in categories  # Missing docstrings/type hints


class TestTournamentRunner:
    """Test tournament runner functionality."""

    @pytest.mark.asyncio
    async def test_simple_tournament(self):
        """Test running a simple tournament."""
        from erosolar_cli.alpha_zero import run_simple_tournament

        result = await run_simple_tournament(
            tasks=["Write a function to add two numbers"],
            num_rounds=3,
            verbose=False,
        )

        assert result.total_rounds == 3
        assert result.agent1_wins + result.agent2_wins + result.ties == 3
        assert len(result.rounds) == 3

    def test_tournament_config(self):
        """Test tournament configuration."""
        from erosolar_cli.alpha_zero import TournamentConfig

        config = TournamentConfig(
            name="test_tournament",
            tasks=["task1", "task2"],
            num_rounds=10,
        )

        assert config.name == "test_tournament"
        assert len(config.tasks) == 2
        assert config.num_rounds == 10

    def test_tournament_result_conversion(self):
        """Test tournament result to dict conversion."""
        from erosolar_cli.alpha_zero import (
            TournamentConfig,
            TournamentResult,
            TournamentStatus,
        )

        config = TournamentConfig(
            name="test",
            tasks=["task1"],
            num_rounds=5,
        )

        result = TournamentResult(
            config=config,
            status=TournamentStatus.COMPLETED,
            agent1_wins=3,
            agent2_wins=2,
            total_duration_ms=1000.0,
        )

        data = result.to_dict()
        assert data["status"] == "completed"
        assert data["agent1_wins"] == 3
        assert data["agent2_wins"] == 2


class TestMetricsDashboard:
    """Test metrics dashboard functionality."""

    def test_initialization(self):
        """Test dashboard can be initialized."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import MetricsDashboard

            dashboard = MetricsDashboard(data_dir=Path(tmpdir))
            assert dashboard is not None

    def test_overall_stats_empty(self):
        """Test overall stats with no data."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import MetricsDashboard

            dashboard = MetricsDashboard(data_dir=Path(tmpdir))
            stats = dashboard.get_overall_stats()

            assert stats["total_tournaments"] == 0
            assert stats["total_rounds"] == 0

    def test_generate_report(self):
        """Test report generation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import MetricsDashboard

            dashboard = MetricsDashboard(data_dir=Path(tmpdir))

            text_report = dashboard.generate_report(format="text")
            assert "ALPHA ZERO 2 METRICS DASHBOARD" in text_report

            md_report = dashboard.generate_report(format="markdown")
            assert "# Alpha Zero 2 Metrics Dashboard" in md_report


class TestCodeEvolutionTracker:
    """Test code evolution tracker."""

    def test_initialization(self):
        """Test tracker initialization."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import CodeEvolutionTracker

            tracker = CodeEvolutionTracker(data_dir=Path(tmpdir))
            assert tracker is not None

    def test_record_and_get_summary(self):
        """Test recording metrics and getting summary."""
        with tempfile.TemporaryDirectory() as tmpdir:
            from erosolar_cli.alpha_zero import CodeEvolutionTracker

            tracker = CodeEvolutionTracker(data_dir=Path(tmpdir))

            # Record initial metrics
            tracker.record_metrics(
                version="v1",
                code_quality_score=0.5,
                algorithm_efficiency=0.4,
                error_handling_score=0.3,
                syntax_validity=1.0,
                documentation_quality=0.2,
            )

            # Record improved metrics
            tracker.record_metrics(
                version="v2",
                code_quality_score=0.8,
                algorithm_efficiency=0.7,
                error_handling_score=0.6,
                syntax_validity=1.0,
                documentation_quality=0.5,
            )

            summary = tracker.get_evolution_summary()
            assert summary["has_data"]
            assert summary["total_versions"] == 2
            assert abs(summary["quality_improvement"] - 0.3) < 0.001  # 0.8 - 0.5


class TestResearchMetadata:
    """Test research metadata module."""

    def test_metadata_imports(self):
        """Test metadata can be imported."""
        from erosolar_cli.alpha_zero import (
            ALPHA_ZERO_2,
            BO_SHANG,
            EROSOLAR_TECH_STACK,
            get_project_summary,
            get_research_citation,
        )

        assert ALPHA_ZERO_2 is not None
        assert BO_SHANG is not None
        assert len(EROSOLAR_TECH_STACK) > 0

    def test_project_summary(self):
        """Test project summary generation."""
        from erosolar_cli.alpha_zero import get_project_summary

        summary = get_project_summary()
        assert "Alpha Zero" in summary
        assert "erosolar_cli" in summary
        assert "Bo Shang" in summary

    def test_research_citation(self):
        """Test research citation generation."""
        from erosolar_cli.alpha_zero import get_research_citation

        citation = get_research_citation()
        assert "@software" in citation
        assert "alpha_zero_2" in citation
        assert "Bo Shang" in citation


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
