import importlib
from pathlib import Path

import pytest

from erosolar_cli.core.types import AssistantMessage, SystemMessage, UserMessage
from erosolar_cli.runtime import session_store


def _sample_messages() -> list:
    return [
        SystemMessage(role="system", content="System"),
        UserMessage(role="user", content="Hello world"),
        AssistantMessage(role="assistant", content="Hi there"),
    ]


def test_save_and_load_session(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("EROSOLAR_DATA_DIR", str(tmp_path))
    importlib.reload(session_store)

    messages = _sample_messages()
    summary = session_store.save_session_snapshot(
        session_store.SaveSessionOptions(
            profile="default",
            provider="anthropic",
            model="claude-test",
            workspace_root="/tmp/work",
            messages=messages,
            title="My Session",
        )
    )

    assert summary.id
    assert summary.title == "My Session"
    assert summary.message_count == len(messages)

    loaded = session_store.load_session_by_id(summary.id)
    assert loaded is not None
    assert loaded.summary.profile == "default"
    assert len(loaded.messages) == len(messages)
    assert isinstance(loaded.messages[1], UserMessage)
    assert loaded.messages[1].content == "Hello world"


def test_list_and_delete(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("EROSOLAR_DATA_DIR", str(tmp_path))
    importlib.reload(session_store)

    first = session_store.save_session_snapshot(
        session_store.SaveSessionOptions(
            profile="default",
            provider="anthropic",
            model="claude-test",
            messages=_sample_messages(),
        )
    )
    second = session_store.save_session_snapshot(
        session_store.SaveSessionOptions(
            profile="default",
            provider="anthropic",
            model="claude-test",
            messages=_sample_messages(),
        )
    )

    sessions = session_store.list_sessions()
    assert len(sessions) == 2
    assert sessions[0].id in {first.id, second.id}

    assert session_store.delete_session(first.id) is True
    remaining = session_store.list_sessions()
    assert len(remaining) == 1
    assert remaining[0].id == second.id


def test_autosave(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("EROSOLAR_DATA_DIR", str(tmp_path))
    importlib.reload(session_store)

    session_store.save_autosave_snapshot(
        "default",
        session_store.SaveSessionOptions(
            profile="default",
            provider="anthropic",
            model="claude-test",
            messages=_sample_messages(),
        ),
    )

    autosave = session_store.load_autosave_snapshot("default")
    assert autosave is not None
    assert autosave.summary.profile == "default"

    session_store.clear_autosave_snapshot("default")
    assert session_store.load_autosave_snapshot("default") is None
