"""Allow running as `python -m gospelo_backlog_docs`."""

from .cli import main

if __name__ == "__main__":
    main()
