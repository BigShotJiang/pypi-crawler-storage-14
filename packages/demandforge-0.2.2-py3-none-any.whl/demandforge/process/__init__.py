"""Processing and analysis utilities for DemandForge.

Submodules include:
- population_weighted_temperature: compute country-level population-weighted T
- thermosensitivity: per-hour thermosensitivity regression and reporting
- thermosensitive_share: baseload vs winter/summer thermo decomposition and report
"""
