"""Data acquisition utilities for DemandForge.

Submodules provide:
- entsoe_load_curves: ENTSO-E load data download and parquet export
- era5: ERA5 temperature retrieval by bounding box or country
- country_borders: EU country borders GeoPackage downloader
- ghsl_population_europe: GHSL population tiles download and merge
"""
