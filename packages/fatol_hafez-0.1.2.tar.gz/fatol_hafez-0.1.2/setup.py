from pathlib import Path

from setuptools import setup, find_packages

ROOT = Path(__file__).parent
README = (ROOT / "README.md").read_text(encoding="utf-8")

setup(
    name="fatol-hafez",
    version="0.1.2",
    description="Get a random beyt (couplet) from Hafez's ghazals.",
    long_description=README,
    long_description_content_type="text/markdown",
    author="MohammadReza Fatolahi",
    author_email="fatolahi.cs@gmail.com",
    url="https://github.com/mrfatolahi1/fatol-hafez",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "fatol_hafez": ["ghazals.txt"],
    },
    python_requires=">=3.8",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Natural Language :: Persian",
        "Topic :: Text Processing :: Linguistic",
    ],
    keywords=["fatol_hafez", "hafiz", "poem", "ghazal", "persian", "farsi"],
    entry_points={
        "console_scripts": [
            "fatol_hafez=fatol_hafez.__main__:main",
        ]
    },
)
