from core import get_random_beyt


def main() -> None:
    beyt = get_random_beyt()
    print(beyt)


if __name__ == "__main__":
    main()
