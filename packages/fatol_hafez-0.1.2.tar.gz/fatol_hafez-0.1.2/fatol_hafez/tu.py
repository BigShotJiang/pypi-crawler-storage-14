import core

print(core.print_all_beyts())