from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import random
from typing import List


@dataclass(frozen=True)
class Beyt:
    misra1: str
    misra2: str

    def __str__(self):
        return f"{self.misra1}\n{self.misra2}"


_BEYTS: List[Beyt] | None = None


def _get_data_file_path() -> Path:
    return Path(__file__).with_name("ghazals.txt")


def _load_beyts() -> List[Beyt]:
    path = _get_data_file_path()
    text = path.read_text(encoding="utf-8")

    blocks = [block.strip() for block in text.split("\n\n") if block.strip()]

    beyts: List[Beyt] = []
    for block in blocks:
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if len(lines) < 2:
            continue
        misra1, misra2 = lines[0], lines[1]
        beyts.append(Beyt(misra1=misra1, misra2=misra2))

    if not beyts:
        raise RuntimeError("Ghazals file missed.")

    return beyts

def print_all_beyts() -> None:
    global _BEYTS
    if _BEYTS is None:
        _BEYTS = _load_beyts()
    output = ""
    for beyt in _BEYTS:
        output += str(beyt)
        output += "\n\n"
    return output

def get_random_beyt() -> str:
    global _BEYTS
    if _BEYTS is None:
        _BEYTS = _load_beyts()
    return str(random.choice(_BEYTS))
