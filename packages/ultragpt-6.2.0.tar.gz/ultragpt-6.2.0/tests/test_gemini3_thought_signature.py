"""
Test for Gemini 3 Pro thought_signature handling in multi-turn tool calling.

This test verifies that:
1. Gemini 3 Pro returns thought_signature in tool_calls
2. The signature is preserved through storage and retrieval
3. Multi-turn conversations work without 400 errors
4. Dummy signatures are injected when missing

Requires OPENROUTER_API_KEY in environment.
"""

import os
import sys
import json
from pathlib import Path
from pydantic import BaseModel
from typing import Optional
from dotenv import load_dotenv

# === CONFIGURATION ===
# The Gemini 3 model to test (via OpenRouter)
TEST_MODEL = "google/gemini-3-pro-preview"

# === SETUP ===
# Load .env file from UltraGPT root
ultragpt_root = Path(__file__).parent.parent
env_path = ultragpt_root / ".env"
if env_path.exists():
    load_dotenv(env_path)

# Add UltraGPT to path
sys.path.insert(0, str(ultragpt_root / "src"))

from ultragpt.core import UltraGPT
from ultragpt.schemas import UserTool

# === TOOL DEFINITIONS ===
class WeatherParams(BaseModel):
    location: str
    units: Optional[str] = "celsius"

class FollowUpParams(BaseModel):
    question: str

example_tools = [
    UserTool(
        name="get_weather",
        description="Get current weather information for a location",
        parameters_schema=WeatherParams,
        usage_guide="Use this tool when the user asks about weather conditions.",
        when_to_use="When the user asks about weather"
    ),
    UserTool(
        name="ask_followup",
        description="Ask a follow-up question to clarify user intent",
        parameters_schema=FollowUpParams,
        usage_guide="Use when you need more information from the user.",
        when_to_use="When clarification is needed"
    )
]

def simulate_tool_result(tool_name: str, args: dict) -> str:
    """Simulate tool execution."""
    if tool_name == "get_weather":
        return json.dumps({
            "temperature": 22,
            "condition": "sunny",
            "humidity": 45,
            "location": args.get("location", "Unknown")
        })
    elif tool_name == "ask_followup":
        return json.dumps({"status": "question_asked", "question": args.get("question")})
    return json.dumps({"status": "unknown_tool"})

def print_separator(title: str):
    """Print a clear separator."""
    print("\n" + "=" * 80)
    print(f"  {title}")
    print("=" * 80 + "\n")

def test_single_tool_call():
    """Test a single tool call - should work and return thought_signature."""
    print_separator("TEST 1: Single Tool Call with Gemini 3 Pro")
    
    openrouter_key = os.getenv("OPENROUTER_API_KEY")
    if not openrouter_key:
        print("❌ SKIPPED: No OPENROUTER_API_KEY found")
        return False
    
    try:
        ultragpt = UltraGPT(openrouter_api_key=openrouter_key, verbose=True)
        
        messages = [
            {"role": "user", "content": "What's the weather in Tokyo?"}
        ]
        
        response, tokens, details = ultragpt.tool_call(
            messages=messages,
            user_tools=example_tools,
            model=TEST_MODEL,
            allow_multiple=False,
            temperature=0.7,
        )
        
        print(f"Response type: {type(response)}")
        print(f"Response: {json.dumps(response, indent=2, default=str)}")
        print(f"Tokens used: {tokens}")
        
        # Check if response contains tool_calls with extra_content
        if isinstance(response, list):
            for tc in response:
                if "extra_content" in tc:
                    print(f"\n✅ Found extra_content: {tc.get('extra_content')}")
                    return True
            print("\n⚠️ No extra_content found in tool_calls (model may not have returned it)")
        elif isinstance(response, dict) and "extra_content" in response:
            print(f"\n✅ Found extra_content: {response.get('extra_content')}")
            return True
        
        print("✅ Single tool call completed (extra_content may be optional)")
        return True
        
    except Exception as e:
        print(f"❌ FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_multi_turn_tool_calling():
    """Test multi-turn tool calling - this is where thought_signature is critical."""
    print_separator("TEST 2: Multi-Turn Tool Calling with Gemini 3 Pro")
    
    openrouter_key = os.getenv("OPENROUTER_API_KEY")
    if not openrouter_key:
        print("❌ SKIPPED: No OPENROUTER_API_KEY found")
        return False
    
    try:
        ultragpt = UltraGPT(openrouter_api_key=openrouter_key, verbose=True)
        
        # Turn 1: User asks about weather
        messages = [
            {"role": "user", "content": "What's the weather in Paris?"}
        ]
        
        print("--- Turn 1: Initial request ---")
        response1, tokens1, _ = ultragpt.tool_call(
            messages=messages,
            user_tools=example_tools,
            model=TEST_MODEL,
            allow_multiple=False,
            temperature=0.7,
        )
        
        print(f"Turn 1 response: {json.dumps(response1, indent=2, default=str)}")
        
        # Extract tool call info from response
        if isinstance(response1, list) and len(response1) > 0:
            tool_call = response1[0]
        elif isinstance(response1, dict):
            tool_call = response1
        else:
            print("❌ Unexpected response format")
            return False
        
        tool_call_id = tool_call.get("id")
        tool_name = tool_call.get("function", {}).get("name") or tool_call.get("name")
        tool_args = tool_call.get("function", {}).get("arguments") or tool_call.get("args", {})
        
        if isinstance(tool_args, str):
            tool_args = json.loads(tool_args)
        
        # Simulate tool execution
        tool_result = simulate_tool_result(tool_name, tool_args)
        
        # Build history with tool call and result (preserving extra_content!)
        messages.append({
            "role": "assistant",
            "content": None,
            "tool_calls": [tool_call]  # This should contain extra_content
        })
        messages.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": tool_name,
            "content": tool_result
        })
        
        # Turn 2: Continue conversation
        messages.append({
            "role": "user",
            "content": "What about London? Is it warmer or colder?"
        })
        
        print("\n--- Turn 2: Follow-up request (THIS IS WHERE 400 ERROR WOULD OCCUR) ---")
        print(f"Messages being sent: {json.dumps(messages, indent=2, default=str)}")
        
        response2, tokens2, _ = ultragpt.tool_call(
            messages=messages,
            user_tools=example_tools,
            model=TEST_MODEL,
            allow_multiple=False,
            temperature=0.7,
        )
        
        print(f"Turn 2 response: {json.dumps(response2, indent=2, default=str)}")
        print(f"\n✅ SUCCESS! Multi-turn tool calling works with Gemini 3 Pro")
        print(f"Total tokens used: {tokens1 + tokens2}")
        return True
        
    except Exception as e:
        error_msg = str(e)
        if "400" in error_msg or "thought_signature" in error_msg.lower():
            print(f"❌ FAILED: 400 error (thought_signature issue): {error_msg}")
        else:
            print(f"❌ FAILED: {error_msg}")
        import traceback
        traceback.print_exc()
        return False

def test_missing_signature_injection():
    """Test that dummy signatures are injected for messages without them."""
    print_separator("TEST 3: Signature Injection for Legacy Messages")
    
    openrouter_key = os.getenv("OPENROUTER_API_KEY")
    if not openrouter_key:
        print("❌ SKIPPED: No OPENROUTER_API_KEY found")
        return False
    
    try:
        ultragpt = UltraGPT(openrouter_api_key=openrouter_key, verbose=True)
        
        # Simulate messages from old history WITHOUT extra_content
        # This tests the _inject_thought_signatures functionality
        messages = [
            {"role": "user", "content": "What's the weather in Berlin?"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": "call_legacy_123",
                    "type": "function",
                    "function": {
                        "name": "get_weather",
                        "arguments": json.dumps({"location": "Berlin", "units": "celsius"})
                    }
                    # NOTE: No extra_content here - simulating legacy data
                }]
            },
            {
                "role": "tool",
                "tool_call_id": "call_legacy_123",
                "name": "get_weather",
                "content": json.dumps({"temperature": 15, "condition": "cloudy"})
            },
            {"role": "user", "content": "What about Munich?"}
        ]
        
        print("Sending messages WITHOUT extra_content (legacy format)...")
        print(f"Messages: {json.dumps(messages, indent=2)}")
        
        response, tokens, _ = ultragpt.tool_call(
            messages=messages,
            user_tools=example_tools,
            model=TEST_MODEL,
            allow_multiple=False,
            temperature=0.7,
        )
        
        print(f"Response: {json.dumps(response, indent=2, default=str)}")
        print(f"\n✅ SUCCESS! Dummy signature injection works for legacy messages")
        return True
        
    except Exception as e:
        error_msg = str(e)
        if "400" in error_msg or "thought_signature" in error_msg.lower():
            print(f"❌ FAILED: 400 error (signature injection not working): {error_msg}")
        else:
            print(f"❌ FAILED: {error_msg}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests."""
    print_separator("GEMINI 3 PRO THOUGHT SIGNATURE TEST SUITE")
    print(f"Testing model: {TEST_MODEL}")
    
    results = {
        "single_tool_call": test_single_tool_call(),
        "multi_turn": test_multi_turn_tool_calling(),
        "signature_injection": test_missing_signature_injection(),
    }
    
    print_separator("TEST RESULTS SUMMARY")
    all_passed = True
    for test_name, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {test_name}: {status}")
        if not passed:
            all_passed = False
    
    print()
    if all_passed:
        print("🎉 All tests passed! Gemini 3 Pro thought_signature handling is working correctly.")
    else:
        print("⚠️ Some tests failed. Check the output above for details.")
    
    return all_passed

if __name__ == "__main__":
    main()
