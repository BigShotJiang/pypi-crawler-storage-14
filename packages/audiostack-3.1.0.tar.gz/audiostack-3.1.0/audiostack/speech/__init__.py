from audiostack.speech.diction import Diction  # noqa: F401
from audiostack.speech.predict import Predict  # noqa: F401
from audiostack.speech.sts import STS  # noqa: F401
from audiostack.speech.tts import TTS  # noqa: F401
from audiostack.speech.voice import Voice  # noqa: F401
