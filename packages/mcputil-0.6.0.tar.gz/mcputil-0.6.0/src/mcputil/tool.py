import asyncio
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Callable
from typing_extensions import TypeAlias

import jsonschema
import mcp.types as types

from .types import ProgressToken, ProgressEvent, EventBus
from .func import gen_anno_and_sig, ParamName


@dataclass
class OutputEvent:
    """An output event emitted after a tool has completed execution."""

    output: Any


@dataclass
class ExceptionEvent:
    """An exception event emitted if a tool fails during execution."""

    exc: Exception


Event: TypeAlias = ProgressEvent | OutputEvent


@dataclass
class Result:
    """The result of a tool execution including its output and a way to track progress."""

    _task: asyncio.Task = field(repr=False)
    _queue: asyncio.Queue[Event | ExceptionEvent] = field(repr=False)
    _cancel_event: asyncio.Event = field(default_factory=asyncio.Event, repr=False)

    async def events(self) -> AsyncIterator[Event]:
        """Stream progress events for this result."""
        while True:
            if self._cancel_event.is_set():
                break

            event = await self._queue.get()
            self._queue.task_done()

            if isinstance(event, ProgressEvent):
                yield event
            elif isinstance(event, OutputEvent):
                yield event
                # TODO: progress events might receive after output event, need to handle it.
                break
            elif isinstance(event, ExceptionEvent):
                raise event.exc

    async def output(self) -> Any:
        """Wait for the tool to complete and return its output."""
        async for event in self.events():
            if isinstance(event, ProgressEvent):
                # Ignore progress events here, use the `events` method directly for those.
                continue
            elif isinstance(event, OutputEvent):
                return event.output
            elif isinstance(event, ExceptionEvent):
                raise event.exc

    def cancel(self) -> None:
        """Cancel the task associated with this result."""

        # Cancel the consuming task and the events() loop.
        self._task.cancel()
        self._cancel_event.set()

        # Clear the queue to prevent processing stale events.
        while not self._queue.empty():
            self._queue.get_nowait()


CallToolFn: TypeAlias = Callable[[str, dict[str, Any], str], types.CallToolResult]


@dataclass(kw_only=True)
class Tool:
    """A tool that can be executed on an MCP server."""

    name: str
    description: str = ""
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] | None = None

    _call_fn: CallToolFn = field(repr=False)
    _event_bus: EventBus = field(repr=False)

    def __post_init__(self):
        # Set the name and docstring of the instance to match the tool's metadata.
        self.__name__ = self.name
        self.__doc__ = self.description

        # Generate and set the __annotations__ and __signature__ attributes based on input/output schemas.
        # This enables proper type hints and parameter documentation when the tool is called.
        self.__annotations__, self.__signature__ = gen_anno_and_sig(
            self.input_schema.get("properties", {}),
            (
                self.output_schema.get("properties", {}).get("result")
                if self.output_schema
                else None
            ),
        )

    async def __call__(self, **kwargs) -> Any:
        result: Result = await self.call(call_id=None, **kwargs)
        async for event in result.events():
            if isinstance(event, OutputEvent):
                return event.output
            elif isinstance(event, ExceptionEvent):
                raise event.exc

    async def call(self, call_id: str | None = None, **kwargs) -> Result:
        """Call the tool with a specific call ID, which can be used to track progress."""

        async def f(**kwargs) -> Any:
            # Validate the input against the schema
            jsonschema.validate(instance=kwargs, schema=self.input_schema)

            # Actually call the tool.
            progress_token = ""
            if call_id is not None:
                progress_token = ProgressToken(call_id).token

            result = await self._call_fn(
                self.name,
                arguments=kwargs,
                progress_token=progress_token,
            )
            if not result.content:
                return ""
            content = result.content[0]

            if result.isError:
                raise ValueError(content.text)

            match content:
                case types.TextContent():
                    return content.text
                case types.ImageContent():
                    return content.data
                case _:  # types.EmbeddedResource() or other types
                    return ""

        queue: asyncio.Queue = asyncio.Queue()

        async def wrapper(**kwargs) -> Any:
            if call_id is not None:
                # Subscribe to progress updates.
                await self._event_bus.subscribe(call_id, queue)
            try:
                # Restore parameter names if started with `ParamName.prefix`.
                params: dict[str, Any] = {
                    ParamName.wrap(k).unwrap(): v for k, v in kwargs.items()
                }

                output = await f(**params)
                # TODO: progress events might receive after output event, need to handle it.
                queue.put_nowait(OutputEvent(output=output))
                return output
            except Exception as exc:
                queue.put_nowait(ExceptionEvent(exc=exc))
            finally:
                if call_id is not None:
                    # Unsubscribe from progress updates.
                    await self._event_bus.unsubscribe(call_id)

        task: asyncio.Task = asyncio.create_task(wrapper(**kwargs))
        result = Result(_task=task, _queue=queue)
        return result
