"""
Console sender - Print newsletter to console (for testing).
"""

import logging

from letterflow.senders.base import Sender

logger = logging.getLogger(__name__)


class Console(Sender):
    """
    Print newsletter details to console instead of sending.
    
    Useful for:
        - Testing without sending real emails
        - Debugging newsletter content
        - Development workflow
    
    Example:
        >>> sender = Console()
        >>> sender.send("user@email.com", "Subject", "<html>...</html>")
        # Prints to console instead of sending
    """
    
    name = "Console"
    
    def __init__(self, show_html: bool = False):
        """
        Args:
            show_html: If True, print full HTML. If False, just print metadata.
        """
        self.show_html = show_html
    
    def send(
        self,
        to: str | list[str],
        subject: str,
        html: str,
    ) -> bool:
        """Print newsletter to console."""
        recipients = [to] if isinstance(to, str) else to
        
        print("\n" + "=" * 60)
        print("📧 NEWSLETTER PREVIEW (Console Sender)")
        print("=" * 60)
        print(f"To: {', '.join(recipients)}")
        print(f"Subject: {subject}")
        print(f"HTML Length: {len(html)} characters")
        print("-" * 60)
        
        if self.show_html:
            print(html)
        else:
            # Show snippet
            snippet = html[:500] + "..." if len(html) > 500 else html
            print("HTML Preview:")
            print(snippet)
        
        print("=" * 60)
        print("✅ Newsletter would be sent to:", ", ".join(recipients))
        print("=" * 60 + "\n")
        
        logger.info(f"Console: Printed newsletter for {len(recipients)} recipient(s)")
        return True
    
    def __repr__(self) -> str:
        return f"Console(show_html={self.show_html})"

