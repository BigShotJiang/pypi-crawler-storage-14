"""
Generic SMTP sender.
"""

import logging
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from letterflow.senders.base import Sender
from letterflow.exceptions import SenderError

logger = logging.getLogger(__name__)


class SMTP(Sender):
    """
    Send emails via any SMTP server.
    
    Args:
        host: SMTP server hostname
        port: SMTP server port
        username: SMTP username
        password: SMTP password
        from_address: From email address
        from_name: Display name (default "Letterflow")
        use_tls: Use TLS (default True)
    
    Example:
        >>> sender = SMTP(
        ...     host="smtp.example.com",
        ...     port=587,
        ...     username="user",
        ...     password="pass",
        ...     from_address="noreply@example.com"
        ... )
    """
    
    name = "SMTP"
    
    def __init__(
        self,
        host: str,
        port: int,
        username: str,
        password: str,
        from_address: str,
        from_name: str = "Letterflow",
        use_tls: bool = True,
    ):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.from_address = from_address
        self.from_name = from_name
        self.use_tls = use_tls
    
    def send(
        self,
        to: str | list[str],
        subject: str,
        html: str,
    ) -> bool:
        """Send email via SMTP."""
        recipients = [to] if isinstance(to, str) else to
        
        try:
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{self.from_name} <{self.from_address}>"
            msg["To"] = ", ".join(recipients)
            
            html_part = MIMEText(html, "html")
            msg.attach(html_part)
            
            logger.info(f"Connecting to SMTP server {self.host}:{self.port}...")
            with smtplib.SMTP(self.host, self.port) as server:
                if self.use_tls:
                    server.starttls()
                server.login(self.username, self.password)
                server.sendmail(self.from_address, recipients, msg.as_string())
            
            logger.info(f"Email sent to {len(recipients)} recipient(s)")
            return True
            
        except Exception as e:
            raise SenderError(self.name, f"Failed to send: {e}", cause=e)
    
    def __repr__(self) -> str:
        return f"SMTP(host='{self.host}', port={self.port})"

