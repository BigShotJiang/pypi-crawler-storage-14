"""
Base class for email senders.
"""

from abc import ABC, abstractmethod


class Sender(ABC):
    """
    Abstract base class for email senders.
    
    Senders deliver HTML content to recipients via various methods
    (SMTP, API, console output, etc.)
    
    Example of creating a custom sender:
        >>> class MySender(Sender):
        ...     name = "My Sender"
        ...     
        ...     def send(self, to, subject, html):
        ...         # Your send logic here
        ...         return True
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this sender."""
        pass
    
    @abstractmethod
    def send(
        self,
        to: str | list[str],
        subject: str,
        html: str,
    ) -> bool:
        """
        Send an email.
        
        Args:
            to: Recipient email address(es)
            subject: Email subject line
            html: HTML content of the email
            
        Returns:
            True if sent successfully, False otherwise
            
        Raises:
            SenderError: If sending fails
        """
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"

