"""
Gmail sender - Send emails via Gmail SMTP.
"""

import logging
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from letterflow.senders.base import Sender
from letterflow.exceptions import SenderError, ConfigError

logger = logging.getLogger(__name__)


class Gmail(Sender):
    """
    Send emails via Gmail SMTP.
    
    Args:
        address: Gmail address (or set GMAIL_ADDRESS env var)
        app_password: Gmail App Password (or set GMAIL_APP_PASSWORD env var)
        from_name: Display name in From field (default "Letterflow")
    
    Example:
        >>> sender = Gmail()  # Uses env vars
        >>> sender = Gmail(
        ...     address="me@gmail.com",
        ...     app_password="xxxx xxxx xxxx xxxx",
        ...     from_name="My Newsletter"
        ... )
        >>> sender.send("user@email.com", "Subject", "<html>...</html>")
    
    Setup:
        1. Enable 2-Factor Auth on your Google account
        2. Go to https://myaccount.google.com/apppasswords
        3. Generate an App Password for "Mail"
        4. Use the 16-character password (not your regular password)
    """
    
    name = "Gmail"
    
    SMTP_SERVER = "smtp.gmail.com"
    SMTP_PORT = 587
    
    def __init__(
        self,
        address: str | None = None,
        app_password: str | None = None,
        from_name: str = "Letterflow",
    ):
        self.address = address or os.getenv("GMAIL_ADDRESS")
        self.app_password = app_password or os.getenv("GMAIL_APP_PASSWORD")
        self.from_name = from_name
        
        if not self.address:
            raise ConfigError(
                "Gmail address required. Set GMAIL_ADDRESS env var or pass address parameter.",
                key="GMAIL_ADDRESS"
            )
        if not self.app_password:
            raise ConfigError(
                "Gmail App Password required. Set GMAIL_APP_PASSWORD env var or pass app_password parameter. "
                "Generate one at https://myaccount.google.com/apppasswords",
                key="GMAIL_APP_PASSWORD"
            )
    
    def send(
        self,
        to: str | list[str],
        subject: str,
        html: str,
    ) -> bool:
        """Send email via Gmail SMTP."""
        recipients = [to] if isinstance(to, str) else to
        
        try:
            # Create message
            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{self.from_name} <{self.address}>"
            msg["To"] = ", ".join(recipients)
            
            # Attach HTML content
            html_part = MIMEText(html, "html")
            msg.attach(html_part)
            
            # Send via SMTP
            logger.info(f"Connecting to Gmail SMTP...")
            with smtplib.SMTP(self.SMTP_SERVER, self.SMTP_PORT) as server:
                server.starttls()
                server.login(self.address, self.app_password)
                server.sendmail(self.address, recipients, msg.as_string())
            
            logger.info(f"Email sent to {len(recipients)} recipient(s)")
            return True
            
        except smtplib.SMTPAuthenticationError as e:
            raise SenderError(
                self.name,
                "Authentication failed. Make sure you're using an App Password, not your regular password. "
                "Generate one at https://myaccount.google.com/apppasswords",
                cause=e
            )
        except Exception as e:
            raise SenderError(self.name, f"Failed to send: {e}", cause=e)
    
    def __repr__(self) -> str:
        return f"Gmail(address='{self.address}')"

