"""
Email senders for Letterflow.

Senders deliver the rendered newsletter to recipients.

Available senders:
    - Gmail: Send via Gmail SMTP (free)
    - SMTP: Generic SMTP sender
    - Console: Print to console (for testing)
    - File: Save to file (for testing)

Example:
    >>> from letterflow import senders
    >>> sender = senders.Gmail()
    >>> sender.send("user@email.com", "Subject", "<html>...</html>")
"""

from letterflow.senders.base import Sender
from letterflow.senders.gmail import Gmail
from letterflow.senders.smtp import SMTP
from letterflow.senders.console import Console
from letterflow.senders.file import File

__all__ = [
    "Sender",
    "Gmail",
    "SMTP",
    "Console",
    "File",
]

