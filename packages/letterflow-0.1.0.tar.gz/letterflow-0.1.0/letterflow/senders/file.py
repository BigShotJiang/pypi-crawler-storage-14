"""
File sender - Save newsletter to file (for testing/archiving).
"""

import logging
from datetime import datetime
from pathlib import Path

from letterflow.senders.base import Sender

logger = logging.getLogger(__name__)


class File(Sender):
    """
    Save newsletter to file instead of sending.
    
    Useful for:
        - Testing newsletter content
        - Previewing in browser
        - Archiving sent newsletters
    
    Example:
        >>> sender = File(output_dir="./newsletters")
        >>> sender.send("user@email.com", "Subject", "<html>...</html>")
        # Saves to ./newsletters/newsletter_2024-01-15.html
    """
    
    name = "File"
    
    def __init__(
        self,
        output_dir: str = "./output",
        filename_pattern: str = "newsletter_{date}.html",
    ):
        """
        Args:
            output_dir: Directory to save newsletters
            filename_pattern: Filename pattern ({date} will be replaced)
        """
        self.output_dir = Path(output_dir)
        self.filename_pattern = filename_pattern
    
    def send(
        self,
        to: str | list[str],
        subject: str,
        html: str,
    ) -> bool:
        """Save newsletter to file."""
        recipients = [to] if isinstance(to, str) else to
        
        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate filename
        date_str = datetime.now().strftime("%Y-%m-%d_%H%M%S")
        filename = self.filename_pattern.replace("{date}", date_str)
        filepath = self.output_dir / filename
        
        # Add metadata comment to HTML
        metadata = f"""<!--
Newsletter saved by Letterflow
Date: {datetime.now().isoformat()}
Subject: {subject}
Recipients: {', '.join(recipients)}
-->
"""
        full_html = metadata + html
        
        # Write file
        filepath.write_text(full_html)
        
        logger.info(f"Newsletter saved to: {filepath}")
        print(f"📄 Newsletter saved to: {filepath}")
        
        return True
    
    def __repr__(self) -> str:
        return f"File(output_dir='{self.output_dir}')"

