"""
Modern template - Dark theme with vibrant accents.
"""

from datetime import datetime
from jinja2 import Template as Jinja2Template

from letterflow.templates.base import Template
from letterflow.item import Item


MODERN_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ newsletter_name }}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Outfit:wght@400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Outfit', -apple-system, BlinkMacSystemFont, sans-serif;
            line-height: 1.6;
            color: #e4e4e7;
            background: linear-gradient(135deg, #0f0f11 0%, #18181b 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }
        
        .container {
            max-width: 680px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            padding: 48px 0;
            margin-bottom: 40px;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%);
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .header h1 {
            font-size: 36px;
            font-weight: 700;
            background: linear-gradient(135deg, #a855f7 0%, #6366f1 50%, #22d3ee 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 12px;
        }
        
        .header .date {
            font-family: 'JetBrains Mono', monospace;
            font-size: 14px;
            color: #71717a;
        }
        
        .section {
            margin-bottom: 48px;
        }
        
        .section-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
        }
        
        .section-icon {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
            border-radius: 12px;
            font-size: 18px;
        }
        
        .section-title {
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: #a1a1aa;
        }
        
        .item {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 16px;
            padding: 28px;
            margin-bottom: 16px;
            transition: all 0.2s ease;
        }
        
        .item:hover {
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(139, 92, 246, 0.3);
            transform: translateY(-2px);
        }
        
        .item h2 {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 12px;
            line-height: 1.4;
        }
        
        .item h2 a {
            color: #f4f4f5;
            text-decoration: none;
            transition: color 0.2s;
        }
        
        .item h2 a:hover {
            color: #a855f7;
        }
        
        .item .meta {
            font-family: 'JetBrains Mono', monospace;
            font-size: 12px;
            color: #71717a;
            margin-bottom: 16px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .item .meta .tag {
            background: rgba(99, 102, 241, 0.15);
            color: #818cf8;
            padding: 4px 10px;
            border-radius: 6px;
        }
        
        .item .summary {
            font-size: 15px;
            color: #a1a1aa;
            line-height: 1.8;
            margin-bottom: 16px;
        }
        
        .item .link {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 14px;
            font-weight: 500;
            color: #a855f7;
            text-decoration: none;
            transition: gap 0.2s;
        }
        
        .item .link:hover {
            gap: 10px;
        }
        
        .footer {
            text-align: center;
            padding: 40px 0;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            margin-top: 20px;
        }
        
        .footer p {
            font-family: 'JetBrains Mono', monospace;
            font-size: 12px;
            color: #52525b;
        }
        
        .footer a {
            color: #6366f1;
            text-decoration: none;
        }
        
        .empty {
            text-align: center;
            padding: 80px 40px;
            color: #71717a;
            background: rgba(255, 255, 255, 0.02);
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .empty p {
            font-size: 16px;
        }
        
        .count-badge {
            font-family: 'JetBrains Mono', monospace;
            font-size: 12px;
            background: rgba(34, 211, 238, 0.15);
            color: #22d3ee;
            padding: 4px 10px;
            border-radius: 6px;
            margin-left: auto;
        }
        
        @media (max-width: 600px) {
            body {
                padding: 20px 16px;
            }
            .header {
                padding: 32px 20px;
            }
            .header h1 {
                font-size: 28px;
            }
            .item {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{ newsletter_name }}</h1>
            <div class="date">{{ date }}</div>
        </div>
        
        {% if items %}
            {% set sources = items | map(attribute='source') | unique | list %}
            {% for source in sources %}
                {% set source_items = items | selectattr('source', 'equalto', source) | list %}
                <div class="section">
                    <div class="section-header">
                        <div class="section-icon">
                            {% if 'ArXiv' in source %}📄{% elif 'Hacker' in source %}🔥{% elif 'News' in source %}📰{% else %}📌{% endif %}
                        </div>
                        <div class="section-title">{{ source }}</div>
                        <div class="count-badge">{{ source_items | length }} items</div>
                    </div>
                    
                    {% for item in source_items %}
                        <div class="item">
                            <h2><a href="{{ item.url }}">{{ item.title }}</a></h2>
                            <div class="meta">
                                {% if item.authors %}
                                    <span>{{ item.display_authors }}</span>
                                {% endif %}
                                <span class="tag">{{ item.published_formatted }}</span>
                            </div>
                            <div class="summary">{{ item.display_summary }}</div>
                            <a href="{{ item.url }}" class="link">Read more →</a>
                        </div>
                    {% endfor %}
                </div>
            {% endfor %}
        {% else %}
            <div class="empty">
                <p>📭 No new content today. Check back tomorrow!</p>
            </div>
        {% endif %}
        
        <div class="footer">
            <p>Powered by <a href="https://github.com/letterflow/letterflow">letterflow</a></p>
        </div>
    </div>
</body>
</html>
"""


class Modern(Template):
    """
    Modern dark email template with vibrant gradients.
    
    Features:
        - Dark theme with purple/cyan accents
        - Outfit + JetBrains Mono fonts
        - Gradient effects
        - Grouped by source with icons
        - Mobile responsive
    
    Example:
        >>> template = Modern()
        >>> html = template.render("AI Digest", items)
    """
    
    name = "Modern"
    
    def __init__(self):
        self._template = Jinja2Template(MODERN_TEMPLATE)
    
    def render(
        self,
        newsletter_name: str,
        items: list[Item],
        date: datetime | None = None,
    ) -> str:
        """Render items into modern dark HTML template."""
        date = date or datetime.now()
        
        return self._template.render(
            newsletter_name=newsletter_name,
            items=items,
            date=date.strftime("%B %d, %Y"),
        )

