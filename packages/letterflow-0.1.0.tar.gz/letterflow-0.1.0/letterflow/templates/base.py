"""
Base class for email templates.
"""

from abc import ABC, abstractmethod
from datetime import datetime

from letterflow.item import Item


class Template(ABC):
    """
    Abstract base class for email templates.
    
    Templates convert Items into HTML email content.
    
    Example of creating a custom template:
        >>> class MyTemplate(Template):
        ...     name = "My Template"
        ...     
        ...     def render(self, newsletter_name, items, date=None):
        ...         html = f"<h1>{newsletter_name}</h1>"
        ...         for item in items:
        ...             html += f"<h2>{item.title}</h2>"
        ...         return html
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this template."""
        pass
    
    @abstractmethod
    def render(
        self,
        newsletter_name: str,
        items: list[Item],
        date: datetime | None = None,
    ) -> str:
        """
        Render items into HTML email content.
        
        Args:
            newsletter_name: Name of the newsletter
            items: List of items to include
            date: Date for the newsletter (defaults to today)
            
        Returns:
            Complete HTML string ready for email
        """
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"

