"""
Minimal template - Clean, lightweight design.
"""

from datetime import datetime
from jinja2 import Template as Jinja2Template

from letterflow.templates.base import Template
from letterflow.item import Item


MINIMAL_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ newsletter_name }}</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            line-height: 1.6;
            color: #1a1a1a;
            background: #f8f9fa;
            padding: 40px 20px;
        }
        
        .container {
            max-width: 640px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }
        
        .header {
            padding: 48px 40px 32px;
            border-bottom: 1px solid #eee;
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 600;
            color: #111;
            margin-bottom: 8px;
        }
        
        .header .date {
            font-size: 14px;
            color: #666;
        }
        
        .content {
            padding: 32px 40px;
        }
        
        .section-title {
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #888;
            margin-bottom: 24px;
            padding-bottom: 12px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .item {
            margin-bottom: 32px;
            padding-bottom: 32px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .item h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 8px;
            line-height: 1.4;
        }
        
        .item h2 a {
            color: #111;
            text-decoration: none;
        }
        
        .item h2 a:hover {
            color: #0066cc;
        }
        
        .item .meta {
            font-size: 13px;
            color: #888;
            margin-bottom: 12px;
        }
        
        .item .meta .source {
            color: #0066cc;
            font-weight: 500;
        }
        
        .item .summary {
            font-size: 15px;
            color: #444;
            line-height: 1.7;
        }
        
        .item .link {
            display: inline-block;
            margin-top: 12px;
            font-size: 13px;
            color: #0066cc;
            text-decoration: none;
            font-weight: 500;
        }
        
        .item .link:hover {
            text-decoration: underline;
        }
        
        .footer {
            padding: 24px 40px;
            background: #fafafa;
            text-align: center;
            font-size: 13px;
            color: #888;
        }
        
        .footer a {
            color: #666;
        }
        
        .empty {
            text-align: center;
            padding: 60px 40px;
            color: #888;
        }
        
        @media (max-width: 600px) {
            body {
                padding: 20px 16px;
            }
            .header, .content, .footer {
                padding-left: 24px;
                padding-right: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{{ newsletter_name }}</h1>
            <div class="date">{{ date }}</div>
        </div>
        
        <div class="content">
            {% if items %}
                {% set sources = items | map(attribute='source') | unique | list %}
                {% for source in sources %}
                    <div class="section-title">{{ source }}</div>
                    {% for item in items if item.source == source %}
                        <div class="item">
                            <h2><a href="{{ item.url }}">{{ item.title }}</a></h2>
                            <div class="meta">
                                {% if item.authors %}
                                    {{ item.display_authors }} · 
                                {% endif %}
                                {{ item.published_formatted }}
                            </div>
                            <div class="summary">{{ item.display_summary }}</div>
                            <a href="{{ item.url }}" class="link">Read more →</a>
                        </div>
                    {% endfor %}
                {% endfor %}
            {% else %}
                <div class="empty">
                    <p>No new content today. Check back tomorrow!</p>
                </div>
            {% endif %}
        </div>
        
        <div class="footer">
            <p>Built with <a href="https://github.com/letterflow/letterflow">Letterflow</a></p>
        </div>
    </div>
</body>
</html>
"""


class Minimal(Template):
    """
    Clean, minimal email template.
    
    Features:
        - Light background with white cards
        - Inter font family
        - Grouped by source
        - Mobile responsive
    
    Example:
        >>> template = Minimal()
        >>> html = template.render("AI Digest", items)
    """
    
    name = "Minimal"
    
    def __init__(self):
        self._template = Jinja2Template(MINIMAL_TEMPLATE)
    
    def render(
        self,
        newsletter_name: str,
        items: list[Item],
        date: datetime | None = None,
    ) -> str:
        """Render items into minimal HTML template."""
        date = date or datetime.now()
        
        return self._template.render(
            newsletter_name=newsletter_name,
            items=items,
            date=date.strftime("%B %d, %Y"),
        )

