"""
Email templates for Letterflow.

Templates render Items into beautiful HTML emails.

Available templates:
    - minimal: Clean, minimal design
    - modern: Modern dark theme
    - newspaper: Classic newspaper style

Example:
    >>> from letterflow import templates
    >>> html = templates.minimal.render("My Newsletter", items)
"""

from letterflow.templates.base import Template
from letterflow.templates.minimal import Minimal
from letterflow.templates.modern import Modern

# Convenience instances
minimal = Minimal()
modern = Modern()

__all__ = [
    "Template",
    "Minimal",
    "Modern",
    "minimal",
    "modern",
]

