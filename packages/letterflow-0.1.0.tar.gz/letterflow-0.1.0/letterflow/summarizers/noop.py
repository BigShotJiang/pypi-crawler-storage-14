"""
No-op summarizer - passes through content without AI processing.
"""

from letterflow.summarizers.base import Summarizer
from letterflow.item import Item


class NoOp(Summarizer):
    """
    Pass-through summarizer that doesn't use AI.
    
    Useful for:
        - Testing without API costs
        - When you don't want summarization
        - When source content is already concise
    
    Example:
        >>> summarizer = NoOp()
        >>> summary = summarizer.summarize(item)  # Returns truncated content
    """
    
    name = "NoOp"
    
    def __init__(self, max_length: int = 300):
        """
        Args:
            max_length: Maximum characters for summary (truncates content)
        """
        self.max_length = max_length
    
    def summarize(self, item: Item) -> str:
        """Return truncated content as 'summary'."""
        if len(item.content) <= self.max_length:
            return item.content
        return item.content[:self.max_length - 3] + "..."
    
    def score_relevance(self, item: Item, topic: str) -> float:
        """
        Basic keyword matching for relevance.
        
        Returns 1.0 if topic appears in title or content, 0.5 otherwise.
        """
        topic_lower = topic.lower()
        if topic_lower in item.title.lower():
            return 1.0
        if topic_lower in item.content.lower():
            return 0.7
        return 0.5
    
    def __repr__(self) -> str:
        return f"NoOp(max_length={self.max_length})"

