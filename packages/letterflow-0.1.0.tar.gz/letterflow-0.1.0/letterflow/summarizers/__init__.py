"""
AI Summarizers for Letterflow.

Summarizers generate concise summaries of content and score relevance.

Available summarizers:
    - OpenAI: Use GPT models for summarization
    - Anthropic: Use Claude models for summarization
    - NoOp: Pass-through summarizer (no AI, uses original content)

Example:
    >>> from letterflow import summarizers
    >>> summarizer = summarizers.OpenAI(model="gpt-4o-mini")
    >>> item.summary = summarizer.summarize(item)
"""

from letterflow.summarizers.base import Summarizer
from letterflow.summarizers.openai import OpenAI
from letterflow.summarizers.noop import NoOp

__all__ = [
    "Summarizer",
    "OpenAI",
    "NoOp",
]

