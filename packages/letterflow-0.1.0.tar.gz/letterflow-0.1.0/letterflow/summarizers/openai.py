"""
OpenAI-based summarizer using GPT models.
"""

import json
import logging
import os

from letterflow.summarizers.base import Summarizer
from letterflow.item import Item
from letterflow.exceptions import SummarizerError, ConfigError

logger = logging.getLogger(__name__)


class OpenAI(Summarizer):
    """
    Summarizer using OpenAI GPT models.
    
    Args:
        api_key: OpenAI API key (or set OPENAI_API_KEY env var)
        model: Model to use (default "gpt-4o-mini" for cost efficiency)
        max_tokens: Max tokens for summary (default 150)
        temperature: Generation temperature (default 0.7)
    
    Example:
        >>> summarizer = OpenAI()  # Uses env var for API key
        >>> summarizer = OpenAI(model="gpt-4o", api_key="sk-...")
        
        >>> summary = summarizer.summarize(item)
        >>> relevance = summarizer.score_relevance(item, "machine learning")
    
    Requires:
        pip install letterflow[openai]
    """
    
    name = "OpenAI"
    
    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gpt-4o-mini",
        max_tokens: int = 150,
        temperature: float = 0.7,
    ):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        
        if not self.api_key:
            raise ConfigError(
                "OpenAI API key required. Set OPENAI_API_KEY env var or pass api_key parameter.",
                key="OPENAI_API_KEY"
            )
        
        self._client = None
    
    @property
    def client(self):
        """Lazy-load OpenAI client."""
        if self._client is None:
            try:
                from openai import OpenAI as OpenAIClient
            except ImportError:
                raise SummarizerError(
                    self.name,
                    "openai package not installed. Run: pip install letterflow[openai]"
                )
            self._client = OpenAIClient(api_key=self.api_key)
        return self._client
    
    def summarize(self, item: Item) -> str:
        """Generate a concise summary using GPT."""
        prompt = f"""Summarize this content in 2-3 sentences for a newsletter audience.
Focus on the key points and why it matters.

Title: {item.title}
Source: {item.source}
Content: {item.content[:2000]}

Summary:"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a technical writer creating concise, informative summaries for a newsletter. Be direct and highlight what's important."
                    },
                    {"role": "user", "content": prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature,
            )
            
            summary = response.choices[0].message.content.strip()
            logger.debug(f"Generated summary for: {item.title[:40]}...")
            return summary
            
        except Exception as e:
            raise SummarizerError(self.name, f"Failed to summarize: {e}", cause=e)
    
    def score_relevance(self, item: Item, topic: str) -> float:
        """
        Score how relevant an item is to the given topic.
        
        Uses GPT to analyze if the content is actually about the topic,
        not just mentioning it in passing.
        """
        prompt = f"""Analyze if this content is primarily about "{topic}" or just mentions it in passing.

Title: {item.title}
Content: {item.content[:1500]}

Scoring guide:
- 1.0: Directly about {topic}, it's the main focus
- 0.7-0.9: Strongly related, {topic} is a major component
- 0.4-0.6: Somewhat related, mentions {topic} substantially
- 0.1-0.3: Tangentially related, brief mention of {topic}
- 0.0: Not related to {topic} at all

Respond with JSON only: {{"score": 0.0, "reason": "brief explanation"}}"""

        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert at analyzing content relevance. Respond only with valid JSON."
                    },
                    {"role": "user", "content": prompt}
                ],
                max_tokens=100,
                temperature=0.1,  # Low temp for consistent scoring
            )
            
            result = json.loads(response.choices[0].message.content.strip())
            score = float(result.get("score", 0.5))
            reason = result.get("reason", "")
            
            logger.debug(f"Relevance for '{item.title[:30]}...': {score:.2f} - {reason}")
            return max(0.0, min(1.0, score))  # Clamp to 0-1
            
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse relevance response, defaulting to 0.5")
            return 0.5
        except Exception as e:
            raise SummarizerError(self.name, f"Failed to score relevance: {e}", cause=e)
    
    def __repr__(self) -> str:
        return f"OpenAI(model='{self.model}')"

