"""
Base class for AI summarizers.
"""

from abc import ABC, abstractmethod

from letterflow.item import Item


class Summarizer(ABC):
    """
    Abstract base class for AI summarizers.
    
    Summarizers do two things:
        1. Generate concise summaries of content
        2. Score content relevance to a topic
    
    Example of creating a custom summarizer:
        >>> class MySummarizer(Summarizer):
        ...     name = "My Summarizer"
        ...     
        ...     def summarize(self, item):
        ...         return "Summary of: " + item.title
        ...     
        ...     def score_relevance(self, item, topic):
        ...         return 0.5  # Always medium relevance
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this summarizer."""
        pass
    
    @abstractmethod
    def summarize(self, item: Item) -> str:
        """
        Generate a concise summary of the item.
        
        Args:
            item: The item to summarize
            
        Returns:
            A concise summary string (2-3 sentences typically)
        """
        pass
    
    @abstractmethod
    def score_relevance(self, item: Item, topic: str) -> float:
        """
        Score how relevant an item is to a given topic.
        
        Args:
            item: The item to score
            topic: The topic/theme to check relevance against
            
        Returns:
            Float from 0.0 (not relevant) to 1.0 (highly relevant)
        """
        pass
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"

