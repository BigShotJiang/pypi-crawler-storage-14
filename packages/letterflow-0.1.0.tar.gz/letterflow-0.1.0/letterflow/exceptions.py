"""
Letterflow exceptions.

All exceptions inherit from LetterflowError for easy catching.
"""


class LetterflowError(Exception):
    """Base exception for all Letterflow errors."""
    pass


class SourceError(LetterflowError):
    """
    Raised when a source fails to fetch content.
    
    This is non-fatal by default - other sources will still work.
    """
    
    def __init__(self, source_name: str, message: str, cause: Exception | None = None):
        self.source_name = source_name
        self.cause = cause
        super().__init__(f"[{source_name}] {message}")


class SenderError(LetterflowError):
    """
    Raised when email sending fails.
    
    This is typically fatal - the newsletter won't be delivered.
    """
    
    def __init__(self, sender_name: str, message: str, cause: Exception | None = None):
        self.sender_name = sender_name
        self.cause = cause
        super().__init__(f"[{sender_name}] {message}")


class SummarizerError(LetterflowError):
    """
    Raised when AI summarization fails.
    
    This is non-fatal - content will be shown without summary.
    """
    
    def __init__(self, summarizer_name: str, message: str, cause: Exception | None = None):
        self.summarizer_name = summarizer_name
        self.cause = cause
        super().__init__(f"[{summarizer_name}] {message}")


class ConfigError(LetterflowError):
    """
    Raised when configuration is invalid or missing.
    """
    
    def __init__(self, message: str, key: str | None = None):
        self.key = key
        super().__init__(message)


class TemplateError(LetterflowError):
    """
    Raised when template rendering fails.
    """
    pass

