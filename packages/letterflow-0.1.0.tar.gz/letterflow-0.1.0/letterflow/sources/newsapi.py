"""
NewsAPI source - Fetch news articles via newsapi.org
"""

from datetime import datetime
import logging
import os

import httpx

from letterflow.sources.base import Source
from letterflow.item import Item
from letterflow.exceptions import SourceError, ConfigError

logger = logging.getLogger(__name__)

NEWSAPI_BASE = "https://newsapi.org/v2"


class NewsAPI(Source):
    """
    Fetch news articles from NewsAPI.org.
    
    Args:
        keywords: Keywords to search for
        api_key: NewsAPI key (or set NEWSAPI_KEY env var)
        language: Language code (default "en")
        sort_by: Sort order - "relevancy", "popularity", or "publishedAt"
    
    Example:
        >>> news = NewsAPI(keywords=["artificial intelligence", "GPT"])
        >>> articles = news.fetch()
        
        >>> news = NewsAPI(
        ...     keywords=["tech"],
        ...     language="en",
        ...     sort_by="popularity"
        ... )
    
    Note:
        Get your free API key at https://newsapi.org/
    """
    
    name = "NewsAPI"
    
    def __init__(
        self,
        keywords: list[str],
        api_key: str | None = None,
        language: str = "en",
        sort_by: str = "publishedAt",
    ):
        self.keywords = keywords
        self.api_key = api_key or os.getenv("NEWSAPI_KEY") or os.getenv("NEWS_API_KEY")
        self.language = language
        self.sort_by = sort_by
        
        if not self.api_key:
            raise ConfigError(
                "NewsAPI key required. Set NEWSAPI_KEY env var or pass api_key parameter.",
                key="NEWSAPI_KEY"
            )
    
    def fetch(self, since: datetime | None = None) -> list[Item]:
        """Fetch articles from NewsAPI."""
        since = since or self._default_since()
        
        # Build query
        query = " OR ".join(f'"{kw}"' for kw in self.keywords)
        
        params = {
            "q": query,
            "from": since.strftime("%Y-%m-%d"),
            "to": datetime.now().strftime("%Y-%m-%d"),
            "language": self.language,
            "sortBy": self.sort_by,
            "pageSize": 50,
        }
        
        headers = {"X-Api-Key": self.api_key}
        
        logger.info(f"Searching NewsAPI: {query}")
        
        try:
            with httpx.Client(timeout=30) as client:
                response = client.get(
                    f"{NEWSAPI_BASE}/everything",
                    params=params,
                    headers=headers,
                )
                
                if response.status_code == 401:
                    raise ConfigError("Invalid NewsAPI key", key="NEWSAPI_KEY")
                if response.status_code == 429:
                    raise SourceError(self.name, "Rate limit exceeded")
                
                response.raise_for_status()
                data = response.json()
                
                if data.get("status") != "ok":
                    raise SourceError(self.name, data.get("message", "Unknown error"))
                
                items = []
                for article in data.get("articles", []):
                    # Parse date
                    published_str = article.get("publishedAt", "")
                    try:
                        published = datetime.fromisoformat(published_str.replace("Z", "+00:00"))
                        published = published.replace(tzinfo=None)
                    except (ValueError, AttributeError):
                        published = datetime.now()
                    
                    if published < since:
                        continue
                    
                    # Get content
                    content = article.get("description") or article.get("content") or ""
                    
                    # Clean "[+N chars]" suffix from NewsAPI
                    if "[+" in content:
                        content = content.split("[+")[0].strip()
                    
                    source_name = article.get("source", {}).get("name", "Unknown")
                    
                    item = Item(
                        title=article.get("title", "Untitled"),
                        content=content,
                        url=article.get("url", ""),
                        source=f"NewsAPI ({source_name})",
                        published=published,
                        authors=[article.get("author")] if article.get("author") else [],
                        metadata={
                            "source_name": source_name,
                            "image_url": article.get("urlToImage"),
                        }
                    )
                    items.append(item)
                    logger.debug(f"Found article: {item.title[:50]}...")
                
                logger.info(f"NewsAPI: Found {len(items)} articles since {since}")
                return items
                
        except httpx.HTTPError as e:
            raise SourceError(self.name, f"HTTP error: {e}", cause=e)
        except ConfigError:
            raise
        except Exception as e:
            raise SourceError(self.name, f"Failed to fetch: {e}", cause=e)
    
    def __repr__(self) -> str:
        return f"NewsAPI(keywords={self.keywords})"

