"""
Hacker News source - Fetch top stories from news.ycombinator.com
"""

from datetime import datetime
import logging

import httpx

from letterflow.sources.base import Source
from letterflow.item import Item
from letterflow.exceptions import SourceError

logger = logging.getLogger(__name__)

HN_API_BASE = "https://hacker-news.firebaseio.com/v0"


class HackerNews(Source):
    """
    Fetch top stories from Hacker News.
    
    Args:
        keywords: Optional keywords to filter stories (searches title)
        min_score: Minimum score/points to include (default 10)
        max_results: Maximum stories to fetch (default 30)
    
    Example:
        >>> hn = HackerNews(keywords=["AI", "GPT"], min_score=50)
        >>> stories = hn.fetch()
        
        >>> hn = HackerNews()  # All top stories
    """
    
    name = "Hacker News"
    
    def __init__(
        self,
        keywords: list[str] | None = None,
        min_score: int = 10,
        max_results: int = 30,
    ):
        self.keywords = keywords or []
        self.min_score = min_score
        self.max_results = max_results
    
    def fetch(self, since: datetime | None = None) -> list[Item]:
        """Fetch top stories from Hacker News."""
        since = since or self._default_since()
        
        try:
            with httpx.Client(timeout=30) as client:
                # Get top story IDs
                response = client.get(f"{HN_API_BASE}/topstories.json")
                response.raise_for_status()
                story_ids = response.json()[:100]  # Top 100 stories
                
                items = []
                for story_id in story_ids:
                    if len(items) >= self.max_results:
                        break
                    
                    # Fetch story details
                    resp = client.get(f"{HN_API_BASE}/item/{story_id}.json")
                    if resp.status_code != 200:
                        continue
                    
                    story = resp.json()
                    if not story or story.get("type") != "story":
                        continue
                    
                    # Check score
                    score = story.get("score", 0)
                    if score < self.min_score:
                        continue
                    
                    # Check date
                    timestamp = story.get("time", 0)
                    published = datetime.fromtimestamp(timestamp)
                    if published < since:
                        continue
                    
                    # Check keywords if specified
                    title = story.get("title", "")
                    if self.keywords:
                        title_lower = title.lower()
                        if not any(kw.lower() in title_lower for kw in self.keywords):
                            continue
                    
                    # Get URL (some stories are text-only "Ask HN" etc.)
                    url = story.get("url") or f"https://news.ycombinator.com/item?id={story_id}"
                    
                    item = Item(
                        title=title,
                        content=story.get("text", title),  # Use title if no text
                        url=url,
                        source=self.name,
                        published=published,
                        authors=[story.get("by", "unknown")],
                        metadata={
                            "score": score,
                            "comments": story.get("descendants", 0),
                            "hn_id": story_id,
                            "hn_url": f"https://news.ycombinator.com/item?id={story_id}",
                        }
                    )
                    items.append(item)
                    logger.debug(f"Found story: {item.title[:50]}... (score: {score})")
                
                logger.info(f"HackerNews: Found {len(items)} stories since {since}")
                return items
                
        except httpx.HTTPError as e:
            raise SourceError(self.name, f"HTTP error: {e}", cause=e)
        except Exception as e:
            raise SourceError(self.name, f"Failed to fetch: {e}", cause=e)
    
    def __repr__(self) -> str:
        return f"HackerNews(keywords={self.keywords}, min_score={self.min_score})"

