"""
Content sources for Letterflow.

Sources fetch content from various platforms and convert them to Items.

Available sources:
    - ArXiv: Academic papers from arxiv.org
    - HackerNews: Top stories from Hacker News
    - RSS: Any RSS/Atom feed
    - NewsAPI: News articles via NewsAPI.org

Example:
    >>> from letterflow import sources
    >>> arxiv = sources.ArXiv(keywords=["machine learning"])
    >>> items = arxiv.fetch()
"""

from letterflow.sources.base import Source
from letterflow.sources.arxiv import ArXiv
from letterflow.sources.hackernews import HackerNews
from letterflow.sources.rss import RSS
from letterflow.sources.newsapi import NewsAPI

__all__ = [
    "Source",
    "ArXiv",
    "HackerNews", 
    "RSS",
    "NewsAPI",
]

