"""
Base class for all content sources.
"""

from abc import ABC, abstractmethod
from datetime import datetime, timedelta
from typing import Any

from letterflow.item import Item


class Source(ABC):
    """
    Abstract base class for content sources.
    
    All sources must implement:
        - name: Human-readable source name
        - fetch(): Retrieve items from the source
    
    Example of creating a custom source:
        >>> class MyBlog(Source):
        ...     name = "My Blog"
        ...     
        ...     def fetch(self, since=None):
        ...         # Your fetch logic here
        ...         return [Item(...), Item(...)]
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable name of this source (e.g., 'ArXiv', 'Hacker News')"""
        pass
    
    @abstractmethod
    def fetch(self, since: datetime | None = None) -> list[Item]:
        """
        Fetch items from this source.
        
        Args:
            since: Only fetch items published after this datetime.
                   If None, fetches from the last 24 hours.
        
        Returns:
            List of Item objects from this source.
        
        Raises:
            SourceError: If fetching fails (network error, API error, etc.)
        """
        pass
    
    def _default_since(self) -> datetime:
        """Default to 24 hours ago if no since provided."""
        return datetime.now() - timedelta(days=1)
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"

