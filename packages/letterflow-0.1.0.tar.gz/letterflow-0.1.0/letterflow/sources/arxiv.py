"""
ArXiv source - Fetch academic papers from arxiv.org
"""

from datetime import datetime
import logging

from letterflow.sources.base import Source
from letterflow.item import Item
from letterflow.exceptions import SourceError

logger = logging.getLogger(__name__)


class ArXiv(Source):
    """
    Fetch papers from arXiv.
    
    Args:
        keywords: List of keywords to search for
        categories: ArXiv categories to filter (e.g., ["cs.LG", "cs.CL"])
        max_results: Maximum number of papers to fetch (default 50)
    
    Example:
        >>> arxiv = ArXiv(keywords=["transformer", "attention"])
        >>> papers = arxiv.fetch()
        
        >>> arxiv = ArXiv(
        ...     keywords=["LLM"],
        ...     categories=["cs.CL", "cs.LG"],
        ...     max_results=20
        ... )
    
    Requires:
        pip install letterflow[arxiv]
    """
    
    name = "ArXiv"
    
    def __init__(
        self,
        keywords: list[str],
        categories: list[str] | None = None,
        max_results: int = 50,
    ):
        self.keywords = keywords
        self.categories = categories
        self.max_results = max_results
    
    def fetch(self, since: datetime | None = None) -> list[Item]:
        """Fetch papers from ArXiv matching keywords."""
        try:
            import arxiv
        except ImportError:
            raise SourceError(
                self.name,
                "arxiv package not installed. Run: pip install letterflow[arxiv]"
            )
        
        since = since or self._default_since()
        
        # Build query
        query_parts = [f'all:"{kw}"' for kw in self.keywords]
        query = " OR ".join(query_parts)
        
        # Add category filter if specified
        if self.categories:
            cat_parts = [f"cat:{cat}" for cat in self.categories]
            cat_query = " OR ".join(cat_parts)
            query = f"({query}) AND ({cat_query})"
        
        logger.info(f"Searching ArXiv: {query}")
        
        try:
            search = arxiv.Search(
                query=query,
                max_results=self.max_results,
                sort_by=arxiv.SortCriterion.SubmittedDate,
                sort_order=arxiv.SortOrder.Descending,
            )
            
            items = []
            for result in search.results():
                published = result.published.replace(tzinfo=None)
                
                if published < since:
                    break  # Results are sorted by date, so we can stop
                
                item = Item(
                    title=result.title,
                    content=result.summary.replace("\n", " ").strip(),
                    url=result.entry_id,
                    source=self.name,
                    published=published,
                    authors=[a.name for a in result.authors],
                    metadata={
                        "pdf_url": result.pdf_url,
                        "categories": result.categories,
                        "primary_category": result.primary_category,
                    }
                )
                items.append(item)
                logger.debug(f"Found paper: {item.title[:50]}...")
            
            logger.info(f"ArXiv: Found {len(items)} papers since {since}")
            return items
            
        except Exception as e:
            raise SourceError(self.name, f"Failed to fetch: {e}", cause=e)
    
    def __repr__(self) -> str:
        return f"ArXiv(keywords={self.keywords}, categories={self.categories})"

