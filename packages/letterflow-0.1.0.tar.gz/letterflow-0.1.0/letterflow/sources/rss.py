"""
RSS source - Fetch content from any RSS or Atom feed.
"""

from datetime import datetime
from email.utils import parsedate_to_datetime
import logging

from letterflow.sources.base import Source
from letterflow.item import Item
from letterflow.exceptions import SourceError

logger = logging.getLogger(__name__)


class RSS(Source):
    """
    Fetch items from an RSS or Atom feed.
    
    Args:
        url: URL of the RSS/Atom feed
        source_name: Custom name for this source (defaults to feed title)
    
    Example:
        >>> openai_blog = RSS("https://openai.com/blog/rss.xml", source_name="OpenAI Blog")
        >>> anthropic = RSS("https://www.anthropic.com/feed.xml")
        >>> posts = openai_blog.fetch()
    
    Requires:
        pip install letterflow[rss]
    """
    
    def __init__(self, url: str, source_name: str | None = None):
        self.url = url
        self._source_name = source_name
        self._feed_title: str | None = None
    
    @property
    def name(self) -> str:
        """Return source name (custom name, feed title, or URL)."""
        if self._source_name:
            return self._source_name
        if self._feed_title:
            return self._feed_title
        return f"RSS ({self.url[:30]}...)"
    
    def fetch(self, since: datetime | None = None) -> list[Item]:
        """Fetch items from the RSS feed."""
        try:
            import feedparser
        except ImportError:
            raise SourceError(
                self.name,
                "feedparser package not installed. Run: pip install letterflow[rss]"
            )
        
        since = since or self._default_since()
        
        try:
            feed = feedparser.parse(self.url)
            
            if feed.bozo and feed.bozo_exception:
                logger.warning(f"RSS feed warning: {feed.bozo_exception}")
            
            # Store feed title for name property
            self._feed_title = feed.feed.get("title")
            
            items = []
            for entry in feed.entries:
                # Parse published date
                published = self._parse_date(entry)
                if published and published < since:
                    continue
                
                # Get content (try different fields)
                content = (
                    entry.get("summary") or 
                    entry.get("description") or
                    entry.get("content", [{}])[0].get("value", "") or
                    entry.get("title", "")
                )
                
                # Clean HTML tags if present (basic)
                if "<" in content:
                    import re
                    content = re.sub(r"<[^>]+>", "", content)
                
                item = Item(
                    title=entry.get("title", "Untitled"),
                    content=content.strip(),
                    url=entry.get("link", self.url),
                    source=self.name,
                    published=published or datetime.now(),
                    authors=[a.get("name", "") for a in entry.get("authors", [])],
                    metadata={
                        "feed_url": self.url,
                        "tags": [t.get("term", "") for t in entry.get("tags", [])],
                    }
                )
                items.append(item)
                logger.debug(f"Found entry: {item.title[:50]}...")
            
            logger.info(f"RSS ({self.name}): Found {len(items)} items since {since}")
            return items
            
        except Exception as e:
            raise SourceError(self.name, f"Failed to fetch: {e}", cause=e)
    
    def _parse_date(self, entry: dict) -> datetime | None:
        """Try to parse date from various RSS date fields."""
        for field in ["published_parsed", "updated_parsed", "created_parsed"]:
            parsed = entry.get(field)
            if parsed:
                try:
                    return datetime(*parsed[:6])
                except (TypeError, ValueError):
                    pass
        
        # Try string parsing
        for field in ["published", "updated", "created"]:
            date_str = entry.get(field)
            if date_str:
                try:
                    return parsedate_to_datetime(date_str).replace(tzinfo=None)
                except (TypeError, ValueError):
                    pass
        
        return None
    
    def __repr__(self) -> str:
        return f"RSS(url='{self.url[:50]}...')"

