"""
Letterflow - Build and send beautiful newsletters in 3 lines of code.

Example:
    >>> from letterflow import Newsletter, sources
    >>> Newsletter("AI Digest").add_source(sources.ArXiv(["LLM"])).send("me@email.com")
"""

from letterflow.newsletter import Newsletter
from letterflow.item import Item
from letterflow.exceptions import (
    LetterflowError,
    SourceError,
    SenderError,
    SummarizerError,
    ConfigError,
)

# Re-export submodules for convenience
from letterflow import sources
from letterflow import templates
from letterflow import senders
from letterflow import summarizers

__version__ = "0.1.0"
__all__ = [
    "Newsletter",
    "Item",
    "LetterflowError",
    "SourceError", 
    "SenderError",
    "SummarizerError",
    "ConfigError",
    "sources",
    "templates",
    "senders",
    "summarizers",
]

