"""
Newsletter - The main orchestrator class.

This is where the magic happens. Newsletter ties together sources,
summarizers, templates, and senders into a simple, chainable API.
"""

from datetime import datetime
import logging
import os
from pathlib import Path
from typing import Callable

import yaml

from letterflow.item import Item
from letterflow.sources.base import Source
from letterflow.summarizers.base import Summarizer
from letterflow.summarizers.noop import NoOp
from letterflow.templates.base import Template
from letterflow.templates.minimal import Minimal
from letterflow.senders.base import Sender
from letterflow.senders.gmail import Gmail
from letterflow.senders.console import Console
from letterflow.exceptions import LetterflowError, SourceError, ConfigError

logger = logging.getLogger(__name__)


class Newsletter:
    """
    The main class for building and sending newsletters.
    
    Newsletter provides a fluent API for:
        1. Adding content sources (ArXiv, HackerNews, RSS, etc.)
        2. Summarizing and filtering content with AI
        3. Rendering beautiful email templates
        4. Sending via various methods (Gmail, SMTP, etc.)
    
    Simple example (3 lines):
        >>> from letterflow import Newsletter, sources
        >>> Newsletter("AI Digest").add_source(sources.ArXiv(["LLM"])).send("me@email.com")
    
    Full example:
        >>> from letterflow import Newsletter, sources, templates, summarizers
        >>> 
        >>> newsletter = Newsletter(
        ...     name="AI Research Weekly",
        ...     template=templates.modern,
        ...     summarizer=summarizers.OpenAI()
        ... )
        >>> newsletter.add_source(sources.ArXiv(["transformers"]))
        >>> newsletter.add_source(sources.HackerNews(keywords=["AI"]))
        >>> newsletter.filter(topic="AI research", min_relevance=0.6)
        >>> newsletter.send(to="team@company.com")
    
    From config file:
        >>> newsletter = Newsletter.from_config("newsletter.yaml")
        >>> newsletter.send(to=os.environ["RECIPIENT"])
    """
    
    def __init__(
        self,
        name: str,
        template: Template | None = None,
        summarizer: Summarizer | None = None,
        sender: Sender | None = None,
    ):
        """
        Create a new Newsletter.
        
        Args:
            name: Name of the newsletter (shown in header)
            template: Email template to use (default: Minimal)
            summarizer: AI summarizer (default: NoOp - no summarization)
            sender: Email sender (default: Gmail if env vars set, else Console)
        """
        self.name = name
        self.template = template or Minimal()
        self.summarizer = summarizer or NoOp()
        self._sender = sender
        
        self._sources: list[Source] = []
        self._items: list[Item] = []
        self._filter_topic: str | None = None
        self._filter_min_relevance: float = 0.0
        self._custom_filter: Callable[[Item], bool] | None = None
    
    @property
    def sender(self) -> Sender:
        """Get sender, auto-detecting from environment if not set."""
        if self._sender is None:
            # Try to auto-detect sender
            if os.getenv("GMAIL_ADDRESS") and os.getenv("GMAIL_APP_PASSWORD"):
                self._sender = Gmail()
                logger.info("Auto-detected Gmail sender from environment")
            else:
                self._sender = Console()
                logger.info("No sender configured, using Console (for testing)")
        return self._sender
    
    def add_source(self, source: Source, required: bool = False) -> "Newsletter":
        """
        Add a content source.
        
        Args:
            source: The source to add (ArXiv, HackerNews, RSS, etc.)
            required: If True, failure to fetch raises an error.
                     If False (default), failures are logged but ignored.
        
        Returns:
            self (for chaining)
        
        Example:
            >>> newsletter.add_source(sources.ArXiv(["LLM"]))
            >>> newsletter.add_source(sources.HackerNews(), required=False)
        """
        source._required = required  # type: ignore
        self._sources.append(source)
        return self
    
    def filter(
        self,
        topic: str | None = None,
        min_relevance: float = 0.5,
        custom: Callable[[Item], bool] | None = None,
    ) -> "Newsletter":
        """
        Filter items by relevance.
        
        Args:
            topic: Topic to filter for (uses AI to score relevance)
            min_relevance: Minimum relevance score (0-1) to include
            custom: Custom filter function (item -> bool)
        
        Returns:
            self (for chaining)
        
        Example:
            >>> newsletter.filter(topic="world models", min_relevance=0.7)
            >>> newsletter.filter(custom=lambda item: "GPT" in item.title)
        """
        self._filter_topic = topic
        self._filter_min_relevance = min_relevance
        self._custom_filter = custom
        return self
    
    def fetch(self, since: datetime | None = None) -> "Newsletter":
        """
        Fetch content from all sources.
        
        Args:
            since: Only fetch items published after this datetime.
                   Defaults to 24 hours ago.
        
        Returns:
            self (for chaining)
        
        Example:
            >>> newsletter.fetch()  # Last 24 hours
            >>> newsletter.fetch(since=datetime.now() - timedelta(days=7))
        """
        logger.info(f"Fetching from {len(self._sources)} source(s)...")
        self._items = []
        
        for source in self._sources:
            try:
                items = source.fetch(since)
                self._items.extend(items)
                logger.info(f"  {source.name}: {len(items)} items")
            except SourceError as e:
                if getattr(source, "_required", False):
                    raise
                logger.warning(f"  {source.name}: Failed - {e}")
        
        logger.info(f"Total: {len(self._items)} items")
        return self
    
    def summarize(self) -> "Newsletter":
        """
        Generate AI summaries for all items.
        
        Returns:
            self (for chaining)
        """
        if not self._items:
            logger.info("No items to summarize")
            return self
        
        logger.info(f"Summarizing {len(self._items)} items...")
        
        for item in self._items:
            try:
                item.summary = self.summarizer.summarize(item)
            except Exception as e:
                logger.warning(f"Failed to summarize '{item.title[:30]}...': {e}")
        
        return self
    
    def apply_filter(self) -> "Newsletter":
        """
        Apply relevance filter to items.
        
        Returns:
            self (for chaining)
        """
        if not self._items:
            return self
        
        original_count = len(self._items)
        
        # Apply topic-based filter
        if self._filter_topic:
            logger.info(f"Filtering by topic: '{self._filter_topic}' (min: {self._filter_min_relevance})")
            
            for item in self._items:
                try:
                    item.relevance_score = self.summarizer.score_relevance(
                        item, self._filter_topic
                    )
                except Exception as e:
                    logger.warning(f"Failed to score '{item.title[:30]}...': {e}")
                    item.relevance_score = 0.5  # Default
            
            self._items = [
                item for item in self._items
                if (item.relevance_score or 0) >= self._filter_min_relevance
            ]
        
        # Apply custom filter
        if self._custom_filter:
            self._items = [item for item in self._items if self._custom_filter(item)]
        
        filtered_count = original_count - len(self._items)
        if filtered_count > 0:
            logger.info(f"Filtered out {filtered_count} items, {len(self._items)} remaining")
        
        return self
    
    def render(self) -> str:
        """
        Render the newsletter to HTML.
        
        Returns:
            HTML string of the newsletter
        """
        return self.template.render(
            newsletter_name=self.name,
            items=self._items,
            date=datetime.now(),
        )
    
    def preview(self, open_browser: bool = True) -> str:
        """
        Preview the newsletter by saving to file and optionally opening in browser.
        
        Args:
            open_browser: If True, open the HTML file in default browser
            
        Returns:
            Path to the saved HTML file
        """
        from letterflow.senders.file import File
        
        # Run pipeline if not already done
        if not self._items and self._sources:
            self.fetch()
            if self._filter_topic:
                self.apply_filter()
            self.summarize()
        
        html = self.render()
        
        # Save to temp file
        output_dir = Path("./letterflow_preview")
        output_dir.mkdir(exist_ok=True)
        
        filepath = output_dir / f"preview_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        filepath.write_text(html)
        
        logger.info(f"Preview saved to: {filepath}")
        
        if open_browser:
            import webbrowser
            webbrowser.open(f"file://{filepath.absolute()}")
        
        return str(filepath)
    
    def send(
        self,
        to: str | list[str],
        subject: str | None = None,
        via: Sender | str | None = None,
    ) -> bool:
        """
        Send the newsletter.
        
        This is the main method that runs the full pipeline:
            1. Fetch content from sources
            2. Filter by relevance
            3. Generate summaries
            4. Render template
            5. Send email
        
        Args:
            to: Recipient email address(es)
            subject: Email subject (default: "{name} - {date}")
            via: Sender to use (Sender instance, or "gmail"/"console"/"file")
        
        Returns:
            True if sent successfully
        
        Example:
            >>> newsletter.send("me@email.com")
            >>> newsletter.send(["a@email.com", "b@email.com"], via="gmail")
        """
        # Resolve sender
        sender = self._resolve_sender(via)
        
        # Run pipeline
        if not self._items:
            self.fetch()
        
        if self._filter_topic:
            self.apply_filter()
        
        self.summarize()
        
        # Render
        html = self.render()
        
        # Generate subject
        if subject is None:
            subject = f"{self.name} - {datetime.now().strftime('%B %d, %Y')}"
        
        # Send
        logger.info(f"Sending newsletter to {to} via {sender.name}...")
        return sender.send(to, subject, html)
    
    def _resolve_sender(self, via: Sender | str | None) -> Sender:
        """Resolve sender from various input types."""
        if via is None:
            return self.sender
        
        if isinstance(via, Sender):
            return via
        
        if isinstance(via, str):
            via_lower = via.lower()
            if via_lower == "gmail":
                return Gmail()
            elif via_lower == "console":
                return Console()
            elif via_lower == "file":
                from letterflow.senders.file import File
                return File()
            else:
                raise ConfigError(f"Unknown sender: {via}")
        
        raise ConfigError(f"Invalid sender type: {type(via)}")
    
    @classmethod
    def from_config(cls, config_path: str) -> "Newsletter":
        """
        Create Newsletter from a YAML config file.
        
        Config file format:
            name: "My Newsletter"
            template: "modern"  # or "minimal"
            summarizer:
              type: "openai"
              model: "gpt-4o-mini"
            sources:
              - type: "arxiv"
                keywords: ["LLM", "transformer"]
              - type: "hackernews"
                min_score: 50
            filter:
              topic: "AI research"
              min_relevance: 0.6
        
        Args:
            config_path: Path to YAML config file
        
        Returns:
            Configured Newsletter instance
        """
        path = Path(config_path)
        if not path.exists():
            raise ConfigError(f"Config file not found: {config_path}")
        
        with open(path) as f:
            config = yaml.safe_load(f)
        
        # Build newsletter
        newsletter = cls(name=config.get("name", "Newsletter"))
        
        # Template
        template_name = config.get("template", "minimal")
        if template_name == "modern":
            from letterflow.templates.modern import Modern
            newsletter.template = Modern()
        else:
            from letterflow.templates.minimal import Minimal
            newsletter.template = Minimal()
        
        # Summarizer
        summarizer_config = config.get("summarizer", {})
        if summarizer_config.get("type") == "openai":
            from letterflow.summarizers.openai import OpenAI
            newsletter.summarizer = OpenAI(
                model=summarizer_config.get("model", "gpt-4o-mini")
            )
        
        # Sources
        for source_config in config.get("sources", []):
            source_type = source_config.get("type", "").lower()
            
            if source_type == "arxiv":
                from letterflow.sources.arxiv import ArXiv
                newsletter.add_source(ArXiv(
                    keywords=source_config.get("keywords", []),
                    categories=source_config.get("categories"),
                ))
            elif source_type == "hackernews":
                from letterflow.sources.hackernews import HackerNews
                newsletter.add_source(HackerNews(
                    keywords=source_config.get("keywords"),
                    min_score=source_config.get("min_score", 10),
                ))
            elif source_type == "rss":
                from letterflow.sources.rss import RSS
                newsletter.add_source(RSS(
                    url=source_config.get("url"),
                    source_name=source_config.get("name"),
                ))
            elif source_type == "newsapi":
                from letterflow.sources.newsapi import NewsAPI
                newsletter.add_source(NewsAPI(
                    keywords=source_config.get("keywords", []),
                ))
        
        # Filter
        filter_config = config.get("filter", {})
        if filter_config:
            newsletter.filter(
                topic=filter_config.get("topic"),
                min_relevance=filter_config.get("min_relevance", 0.5),
            )
        
        return newsletter
    
    @property
    def items(self) -> list[Item]:
        """Get current items (after fetch/filter)."""
        return self._items
    
    def __repr__(self) -> str:
        return (
            f"Newsletter(name='{self.name}', "
            f"sources={len(self._sources)}, "
            f"items={len(self._items)})"
        )

