"""
Item - The universal content unit in Letterflow.

Every source (ArXiv, HackerNews, RSS, etc.) produces Items.
Items flow through summarizers, filters, and templates.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class Item:
    """
    A single piece of content (paper, article, post, etc.)
    
    This is the universal format that all sources produce and all
    templates consume. Think of it as the "currency" of Letterflow.
    
    Attributes:
        title: The headline/title of the content
        content: Original content (abstract, article body, etc.)
        url: Link to the original source
        source: Name of the source (e.g., "ArXiv", "Hacker News")
        published: When the content was published
        authors: List of author names (if applicable)
        summary: AI-generated summary (filled by summarizer)
        relevance_score: 0-1 score of how relevant to the topic (filled by filter)
        metadata: Additional source-specific data
    
    Example:
        >>> item = Item(
        ...     title="Attention Is All You Need",
        ...     content="We propose a new simple network architecture...",
        ...     url="https://arxiv.org/abs/1706.03762",
        ...     source="ArXiv",
        ...     published=datetime.now(),
        ...     authors=["Vaswani", "Shazeer", "Parmar"]
        ... )
    """
    
    title: str
    content: str
    url: str
    source: str
    published: datetime
    authors: list[str] = field(default_factory=list)
    summary: str | None = None
    relevance_score: float | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self) -> None:
        """Validate item after creation."""
        if not self.title:
            raise ValueError("Item title cannot be empty")
        if not self.url:
            raise ValueError("Item URL cannot be empty")
    
    @property
    def display_summary(self) -> str:
        """Return summary if available, otherwise truncated content."""
        if self.summary:
            return self.summary
        if len(self.content) > 300:
            return self.content[:297] + "..."
        return self.content
    
    @property
    def display_authors(self) -> str:
        """Format authors for display (max 3 with 'et al.')"""
        if not self.authors:
            return ""
        if len(self.authors) <= 3:
            return ", ".join(self.authors)
        return f"{', '.join(self.authors[:3])} et al."
    
    @property
    def published_formatted(self) -> str:
        """Format published date for display."""
        return self.published.strftime("%B %d, %Y")
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "title": self.title,
            "content": self.content,
            "url": self.url,
            "source": self.source,
            "published": self.published.isoformat(),
            "authors": self.authors,
            "summary": self.summary,
            "relevance_score": self.relevance_score,
            "metadata": self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Item":
        """Create Item from dictionary."""
        data = data.copy()
        if isinstance(data.get("published"), str):
            data["published"] = datetime.fromisoformat(data["published"])
        return cls(**data)

