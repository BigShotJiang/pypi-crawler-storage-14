"""
Config-based newsletter example.

This shows how to define your newsletter in YAML and load it in Python.
Perfect for deployment with GitHub Actions.
"""

import os
from letterflow import Newsletter

# Load from config file
newsletter = Newsletter.from_config("config_example.yaml")

# Send to recipient from environment variable
recipient = os.getenv("RECIPIENT_EMAIL", "me@email.com")
newsletter.send(to=recipient)

