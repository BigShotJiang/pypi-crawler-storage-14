"""
AI Research Digest - Full-featured newsletter example.

This example shows:
- Multiple sources (ArXiv, Hacker News)
- AI summarization with OpenAI
- Relevance filtering
- Modern dark theme
"""

from letterflow import Newsletter, sources, summarizers, templates

# Create newsletter with AI summarization
newsletter = Newsletter(
    name="AI Research Weekly",
    template=templates.modern,  # Dark theme
    summarizer=summarizers.OpenAI(model="gpt-4o-mini"),
)

# Add multiple sources
newsletter.add_source(
    sources.ArXiv(
        keywords=["transformer", "large language model", "LLM"],
        categories=["cs.CL", "cs.LG", "cs.AI"],
    )
)

newsletter.add_source(
    sources.HackerNews(
        keywords=["AI", "GPT", "Claude", "machine learning"],
        min_score=50,  # Only popular stories
    )
)

# Filter to only relevant content
newsletter.filter(
    topic="AI and machine learning research",
    min_relevance=0.6,
)

# Send it!
newsletter.send(
    to="researcher@university.edu",
    subject="AI Research Digest - This Week's Highlights"
)

