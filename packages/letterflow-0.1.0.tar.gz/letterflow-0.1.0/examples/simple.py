"""
Simple 3-line newsletter example.

This demonstrates the simplest possible Letterflow usage.
"""

from letterflow import Newsletter, sources

# That's it! One line to create, one to add source, one to send.
Newsletter("AI Papers").add_source(sources.ArXiv(["machine learning"])).send("me@email.com")

