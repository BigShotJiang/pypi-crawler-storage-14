"""
World Models Newsletter - Example for specific research topic.

This shows how to create a newsletter focused on a specific
research area with strict relevance filtering.
"""

import os
from letterflow import Newsletter, sources, summarizers, templates

# Create newsletter focused on world models
newsletter = Newsletter(
    name="World Models Daily",
    template=templates.minimal,
    summarizer=summarizers.OpenAI(),
)

# ArXiv papers
newsletter.add_source(
    sources.ArXiv(
        keywords=["world model", "world models"],
        categories=["cs.LG", "cs.AI", "cs.RO"],  # ML, AI, Robotics
    )
)

# News articles
newsletter.add_source(
    sources.NewsAPI(
        keywords=["AI world model", "world models AI"],
    )
)

# Strict filtering - only papers ABOUT world models, not just mentioning them
newsletter.filter(
    topic="world models in AI - neural networks that learn to predict/simulate environment dynamics for planning",
    min_relevance=0.7,  # High threshold
)

# Preview first (for testing)
# newsletter.preview()

# Send via Gmail
newsletter.send(
    to=os.getenv("RECIPIENT_EMAIL", "me@email.com"),
)

