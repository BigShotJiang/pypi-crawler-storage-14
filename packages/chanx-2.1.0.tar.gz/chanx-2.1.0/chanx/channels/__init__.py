default_app_config = "chanx.channels.apps.ChanxChannelsConfig"
