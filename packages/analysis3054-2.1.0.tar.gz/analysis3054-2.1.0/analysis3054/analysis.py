"""
Advanced statistical analysis tools for time series.

Includes:
- Granger Causality (Pairwise matrix)
- Structural Break Detection
- Cross-Correlation Analysis
- Anomaly Detection (Isolation Forest)
- GARCH Volatility Estimation
- Dynamic Time Warping (DTW)
"""

from __future__ import annotations

from typing import Optional, List, Tuple, Dict, Union
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.figure_factory as ff
from scipy.spatial.distance import euclidean
from statsmodels.tsa.stattools import grangercausalitytests, ccf
from statsmodels.tsa.stattools import adfuller
from sklearn.ensemble import IsolationForest
from arch import arch_model

# Helper for stationarity
def _ensure_stationary(series: pd.Series, max_diff: int = 2) -> pd.Series:
    """Helper to difference series until stationary (ADF p<0.05)."""
    s = series.dropna()
    for d in range(max_diff + 1):
        pval = adfuller(s)[1]
        if pval < 0.05:
            return s
        if d < max_diff:
            s = s.diff().dropna()
    return s

# --- Existing Functions ---
def analyze_granger_causality(
    df: pd.DataFrame,
    variables: List[str],
    max_lag: int = 5,
    test: str = 'ssr_chi2test',
    alpha: float = 0.05
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Performs pairwise Granger Causality tests for selected variables.
    Returns a matrix of p-values where row causes column.
    """
    df_subset = df[variables].dropna()
    n = len(variables)
    p_matrix = pd.DataFrame(np.zeros((n, n)), index=variables, columns=variables)
    
    for col in variables: # Effect (Y)
        for row in variables: # Cause (X)
            if row == col:
                p_matrix.loc[row, col] = np.nan
                continue
            
            y = df_subset[col]
            x = df_subset[row]
            
            if adfuller(y)[1] > 0.05: y = y.diff().dropna()
            if adfuller(x)[1] > 0.05: x = x.diff().dropna()
            
            temp_df = pd.concat([y, x], axis=1).dropna()
            if len(temp_df) < max_lag + 2:
                p_matrix.loc[row, col] = np.nan
                continue
                
            try:
                res = grangercausalitytests(temp_df[[col, row]], maxlag=max_lag, verbose=False)
                p_values = [res[i+1][0][test][1] for i in range(max_lag)]
                min_p = min(p_values)
                p_matrix.loc[row, col] = min_p
            except Exception:
                p_matrix.loc[row, col] = np.nan

    z_text = np.around(p_matrix.values, 3)
    
    fig = ff.create_annotated_heatmap(
        z=p_matrix.values,
        x=variables,
        y=variables,
        annotation_text=z_text,
        colorscale='Viridis_r', 
        showscale=True
    )
    
    fig.update_layout(
        title=f"Granger Causality p-values (H0: Row does not cause Column)",
        xaxis_title="Effect (Response)",
        yaxis_title="Cause (Predictor)"
    )
    
    return p_matrix, fig

def detect_structural_breaks(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    method: str = 'rolling_stats',
    window: int = 30,
    z_threshold: float = 2.5
) -> Tuple[List[pd.Timestamp], go.Figure]:
    """
    Detects structural breaks (regime changes) in the mean/variance.
    """
    data = df.copy().sort_values(date_col)
    y = data[target_col]
    
    roll_mean = y.rolling(window=window).mean()
    mean_diff = roll_mean.diff()
    z_score = (mean_diff - mean_diff.mean()) / mean_diff.std()
    
    breaks_mask = np.abs(z_score) > z_threshold
    break_indices = np.where(breaks_mask)[0]
    cleaned_breaks = []
    last_idx = -window
    
    for idx in break_indices:
        if idx - last_idx > window:
            cleaned_breaks.append(idx)
            last_idx = idx
            
    break_dates = data.iloc[cleaned_breaks][date_col].tolist()
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data[date_col], y=y, mode='lines', name='Signal', line=dict(color='gray')))
    fig.add_trace(go.Scatter(x=data[date_col], y=roll_mean, mode='lines', name=f'Rolling Mean ({window})', line=dict(color='blue')))
    
    for bd in break_dates:
        if hasattr(bd, 'timestamp'):
            x_val = bd.timestamp() * 1000 
        else:
            x_val = bd
        fig.add_vline(x=x_val, line_width=2, line_dash="dash", line_color="red", annotation_text="Break")
                      
    fig.update_layout(title=f"Structural Breaks Detection ({target_col})")
    return break_dates, fig

def analyze_cross_correlation(
    df: pd.DataFrame,
    target_col: str,
    feature_col: str,
    max_lag: int = 30
) -> go.Figure:
    """
    Computes and plots cross-correlation between target and feature.
    """
    d = df[[target_col, feature_col]].dropna()
    y = d[target_col]
    x = d[feature_col]
    
    lags = range(-max_lag, max_lag + 1)
    corrs = []
    
    for lag in lags:
        if lag < 0:
            c = y.corr(x.shift(abs(lag)))
        else:
            c = y.corr(x.shift(-lag))
        corrs.append(c)
        
    fig = go.Figure()
    colors = ['green' if l > 0 else 'blue' for l in lags]
    
    fig.add_trace(go.Bar(x=list(lags), y=corrs, marker_color=colors, name='Correlation'))
    
    fig.update_layout(
        title=f"Cross Correlation: {target_col} vs {feature_col}",
        xaxis_title="Lag (Negative = Feature Leads Target)",
        yaxis_title="Correlation",
        shapes=[dict(type="line", x0=-max_lag, x1=max_lag, y0=0.2, y1=0.2, line=dict(dash="dot", color="gray")),
                dict(type="line", x0=-max_lag, x1=max_lag, y0=-0.2, y1=-0.2, line=dict(dash="dot", color="gray"))]
    )
    return fig

# --- New Functions ---

def detect_anomalies_isolation_forest(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    contamination: float = 0.01
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Detects anomalies using Isolation Forest (Unsupervised).
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    contamination : float
        Expected proportion of outliers.
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame subset of anomalies and plot.
    """
    data = df.copy().dropna(subset=[target_col])
    X = data[[target_col]].values
    
    model = IsolationForest(contamination=contamination, random_state=42)
    data['anomaly'] = model.fit_predict(X)
    # -1 is anomaly, 1 is normal
    anomalies = data[data['anomaly'] == -1]
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data[date_col], y=data[target_col], mode='lines', name='Normal', line=dict(color='blue')))
    fig.add_trace(go.Scatter(
        x=anomalies[date_col], y=anomalies[target_col], 
        mode='markers', name='Anomaly', 
        marker=dict(color='red', size=8, symbol='x')
    ))
    fig.update_layout(title=f"Anomaly Detection (Isolation Forest, Contam={contamination})")
    
    return anomalies, fig

def fit_garch_volatility(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    p: int = 1,
    q: int = 1
) -> Tuple[pd.Series, go.Figure]:
    """
    Estimates conditional volatility using a GARCH(p,q) model.
    Requires 'arch' package.
    
    Returns
    -------
    (pd.Series, go.Figure)
        Volatility series and plot.
    """
    # Ensure stationary returns usually
    # We assume target_col are returns or stationary series.
    # If raw prices, user should diff. We will warn or diff if non-stationary?
    # GARCH is for variance of residuals.
    
    y = df[target_col].dropna()
    # Check stationarity roughly
    if adfuller(y)[1] > 0.05:
        # Warn user or auto-diff? Auto-diff is safer for GARCH on prices
        # But assuming user provides returns is standard for volatility.
        pass 

    model = arch_model(y, vol='Garch', p=p, q=q)
    res = model.fit(disp='off')
    volatility = res.conditional_volatility
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df.loc[volatility.index, date_col], y=volatility, mode='lines', name='Conditional Volatility'))
    fig.update_layout(title=f"GARCH({p},{q}) Volatility Estimate")
    
    return volatility, fig

def analyze_dynamic_time_warping(
    series1: Union[pd.Series, np.ndarray],
    series2: Union[pd.Series, np.ndarray]
) -> Tuple[float, go.Figure]:
    """
    Computes Dynamic Time Warping (DTW) distance and alignment path between two series.
    Useful for comparing similarity of time series with speed/phase shifts.
    
    Note: Uses a simple pure-python implementation or fastdtw if available.
    Since we are building robust tools, we implement a basic efficient version using scipy cdist logic
    or just simple DP for small/medium series.
    
    Returns
    -------
    (float, go.Figure)
        DTW distance and alignment plot.
    """
    s1 = np.array(series1)
    s2 = np.array(series2)
    
    # Z-normalize for shape comparison
    s1 = (s1 - np.mean(s1)) / np.std(s1)
    s2 = (s2 - np.mean(s2)) / np.std(s2)
    
    n, m = len(s1), len(s2)
    dtw_matrix = np.zeros((n+1, m+1))
    dtw_matrix[:] = np.inf
    dtw_matrix[0, 0] = 0
    
    # DP
    # Can be slow for very large N. Limit N?
    if n > 1000 or m > 1000:
        # Downsample?
        pass
        
    for i in range(1, n+1):
        for j in range(1, m+1):
            cost = abs(s1[i-1] - s2[j-1])
            # Take min of neighbor
            last_min = min(dtw_matrix[i-1, j], dtw_matrix[i, j-1], dtw_matrix[i-1, j-1])
            dtw_matrix[i, j] = cost + last_min
            
    distance = dtw_matrix[n, m]
    
    # Backtrack for path
    path = []
    i, j = n, m
    while i > 0 and j > 0:
        path.append((i-1, j-1))
        min_neighbor = min(dtw_matrix[i-1, j], dtw_matrix[i, j-1], dtw_matrix[i-1, j-1])
        if min_neighbor == dtw_matrix[i-1, j-1]:
            i, j = i-1, j-1
        elif min_neighbor == dtw_matrix[i-1, j]:
            i -= 1
        else:
            j -= 1
    path.reverse()
    
    # Plot Alignment
    # Visualize as two series offset or connected lines
    fig = go.Figure()
    
    # Offset series 2 for visibility
    offset = np.max(s1) - np.min(s2) + 2
    
    fig.add_trace(go.Scatter(y=s1, name='Series 1', line=dict(color='blue')))
    fig.add_trace(go.Scatter(y=s2 - offset, name='Series 2 (Offset)', line=dict(color='orange')))
    
    # Draw lines for mapping
    # Sample lines if too many
    step = max(1, len(path) // 50)
    
    shapes = []
    for idx in range(0, len(path), step):
        p = path[idx]
        shapes.append(dict(
            type="line",
            x0=p[0], y0=s1[p[0]],
            x1=p[1], y1=s2[p[1]] - offset,
            line=dict(color="gray", width=0.5, dash="dot")
        ))
        
    fig.update_layout(title=f"DTW Alignment (Dist={distance:.2f})", shapes=shapes)
    
    return distance, fig
