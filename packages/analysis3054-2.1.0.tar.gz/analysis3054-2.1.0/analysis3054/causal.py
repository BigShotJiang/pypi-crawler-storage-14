"""
Causal inference and intervention analysis tools.

This module provides tools to estimate the impact of interventions or events
on time series data, using counterfactual forecasting.
"""

from __future__ import annotations

from typing import Tuple, Dict, Any
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .forecasting import forecast_sarimax, _prepare_data

def analyze_intervention_impact(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    intervention_date: str | pd.Timestamp,
    post_period_days: int = 30
) -> Tuple[Dict[str, float], go.Figure]:
    """
    Estimates the causal impact of an intervention by comparing the actual
    data post-intervention to a counterfactual forecast trained on pre-intervention data.
    
    Parameters
    ----------
    df : pd.DataFrame
        Data containing target and covariates.
    date_col : str
        Date column.
    target_col : str
        Target variable.
    intervention_date : str
        Date of the intervention/event.
    post_period_days : int
        Number of days after intervention to analyze.
        
    Returns
    -------
    (Dict, go.Figure)
        Impact metrics (Absolute, Relative) and Dashboard plot.
    """
    intervention_dt = pd.to_datetime(intervention_date)
    
    # 1. Train model on Pre-Intervention data
    # We treat the intervention date as the start of the "prediction" (counterfactual)
    # Any covariates in df will be used for the forecast if available
    
    # Using SARIMAX as a robust baseline for counterfactual
    # We need to ensure the df covers the post-period for actuals
    
    res = forecast_sarimax(
        df=df, # Full df
        date_col=date_col,
        target_col=target_col,
        prediction_start=intervention_dt,
        auto_tune=False # Speed
    )
    
    # 2. Compare Actual vs Counterfactual (Forecast)
    forecast_df = res.forecast
    # Filter to relevant post-period
    end_date = intervention_dt + pd.Timedelta(days=post_period_days)
    
    mask = (df[date_col] >= intervention_dt) & (df[date_col] <= end_date)
    actual_post = df.loc[mask].set_index(date_col)[target_col]
    
    # Align forecast
    pred_post = forecast_df.set_index('date')['predicted']
    
    # Merge aligned
    comparison = pd.concat([actual_post, pred_post], axis=1).dropna()
    comparison.columns = ['Actual', 'Counterfactual']
    
    # 3. Compute Metrics
    comparison['PointEffect'] = comparison['Actual'] - comparison['Counterfactual']
    comparison['CumEffect'] = comparison['PointEffect'].cumsum()
    
    total_absolute_effect = comparison['PointEffect'].sum()
    average_absolute_effect = comparison['PointEffect'].mean()
    relative_effect = total_absolute_effect / comparison['Counterfactual'].sum()
    
    metrics = {
        'Total_Absolute_Effect': total_absolute_effect,
        'Average_Daily_Effect': average_absolute_effect,
        'Relative_Effect_Pct': relative_effect * 100
    }
    
    # 4. Dashboard Plot
    fig = make_subplots(
        rows=3, cols=1, 
        shared_xaxes=True, 
        vertical_spacing=0.05,
        subplot_titles=("Original vs Counterfactual", "Pointwise Effect (Difference)", "Cumulative Effect")
    )
    
    # Top: Actual vs Counterfactual
    # Include some pre-history context
    pre_mask = (df[date_col] < intervention_dt) & (df[date_col] > intervention_dt - pd.Timedelta(days=60))
    pre_data = df.loc[pre_mask]
    
    fig.add_trace(go.Scatter(x=pre_data[date_col], y=pre_data[target_col], name='Pre-Intervention', line=dict(color='black')), row=1, col=1)
    fig.add_trace(go.Scatter(x=comparison.index, y=comparison['Actual'], name='Post-Intervention (Actual)', line=dict(color='black')), row=1, col=1)
    fig.add_trace(go.Scatter(x=comparison.index, y=comparison['Counterfactual'], name='Counterfactual', line=dict(color='blue', dash='dash')), row=1, col=1)
    
    # Add CI band for counterfactual
    forecast_subset = forecast_df[forecast_df['date'].isin(comparison.index)]
    fig.add_trace(go.Scatter(
        x=pd.concat([forecast_subset['date'], forecast_subset['date'][::-1]]),
        y=pd.concat([forecast_subset['upper_ci'], forecast_subset['lower_ci'][::-1]]),
        fill='toself', fillcolor='rgba(0,0,255,0.1)', line=dict(width=0), name='Counterfactual CI', showlegend=False
    ), row=1, col=1)
    
    fig.add_vline(x=intervention_dt, line_dash="dot", line_color="gray", row=1, col=1)
    
    # Middle: Pointwise Effect
    fig.add_trace(go.Bar(x=comparison.index, y=comparison['PointEffect'], name='Point Effect', marker_color='purple'), row=2, col=1)
    fig.add_hline(y=0, line_color="black", row=2, col=1)
    fig.add_vline(x=intervention_dt, line_dash="dot", line_color="gray", row=2, col=1)
    
    # Bottom: Cumulative Effect
    fig.add_trace(go.Scatter(x=comparison.index, y=comparison['CumEffect'], name='Cumulative Effect', line=dict(color='purple')), row=3, col=1)
    fig.add_hline(y=0, line_color="black", row=3, col=1)
    fig.add_vline(x=intervention_dt, line_dash="dot", line_color="gray", row=3, col=1)
    
    fig.update_layout(height=900, title="Intervention Analysis (Causal Impact)")
    
    return metrics, fig
