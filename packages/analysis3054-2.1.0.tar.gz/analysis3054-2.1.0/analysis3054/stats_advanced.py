"""
Advanced statistical tests and metrics for time series analysis.

Includes:
- Diebold-Mariano Test (Forecast Comparison)
- Hurst Exponent (Long-term memory)
- Permutation Entropy (Complexity)
- Regime Switching (Markov)
- Stationarity Testing (Comprehensive)
"""

from __future__ import annotations

from typing import Optional, Tuple, List, Union, Dict
import math
import warnings
import numpy as np
import pandas as pd
from scipy import stats
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Statsmodels imports
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.tsa.regime_switching.markov_regression import MarkovRegression

def test_diebold_mariano(
    actual: Union[np.ndarray, pd.Series],
    pred1: Union[np.ndarray, pd.Series],
    pred2: Union[np.ndarray, pd.Series],
    h: int = 1,
    loss_func: str = 'L2'
) -> Dict[str, float]:
    """Performs the Diebold-Mariano test to compare predictive accuracy."""
    actual = np.array(actual)
    pred1 = np.array(pred1)
    pred2 = np.array(pred2)
    
    n = len(actual)
    e1 = actual - pred1
    e2 = actual - pred2
    
    if loss_func == 'L2':
        d = (e1**2) - (e2**2)
    elif loss_func == 'L1':
        d = np.abs(e1) - np.abs(e2)
    else:
        raise ValueError("loss_func must be 'L1' or 'L2'")
        
    d_mean = np.mean(d)
    
    def autocovariance(x, k):
        if k == 0: return np.var(x)
        return np.cov(x[:-k], x[k:])[0, 1]
        
    gamma = [autocovariance(d, lag) for lag in range(h)]
    var_d = gamma[0] + 2 * sum(gamma[1:])
    
    if var_d == 0: 
        dm_stat = 0
    else:
        dm_stat = d_mean / np.sqrt(var_d / n)
    
    p_value = 2 * (1 - stats.norm.cdf(np.abs(dm_stat)))
    
    return {
        "DM_statistic": dm_stat,
        "p_value": p_value,
        "better_model": 1 if dm_stat < 0 else 2
    }

def calculate_rolling_hurst_exponent(
    series: Union[pd.Series, np.ndarray],
    window: int = 100,
    min_window: int = 10
) -> Tuple[pd.Series, go.Figure]:
    """Calculates the rolling Hurst Exponent."""
    s = pd.Series(series)
    hursts = pd.Series(index=s.index, dtype=float)
    
    def get_hurst(ts):
        if len(ts) < min_window: return np.nan
        y = ts - np.mean(ts)
        z = np.cumsum(y)
        r = np.max(z) - np.min(z)
        s_dev = np.std(ts)
        if s_dev == 0: return np.nan
        rs = r / s_dev
        try:
            h_est = np.log(rs) / np.log(len(ts))
        except:
            h_est = np.nan
        return h_est

    hursts = s.rolling(window=window).apply(get_hurst, raw=True)
    
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=s.index, y=hursts, mode='lines', name='Hurst Exponent'))
    fig.add_hline(y=0.5, line_dash="dash", line_color="gray", annotation_text="Random Walk")
    fig.update_layout(title=f"Rolling Hurst Exponent (Window={window})", yaxis_title="H")
    return hursts, fig

def calculate_rolling_permutation_entropy(
    series: Union[pd.Series, np.ndarray],
    window: int = 50,
    order: int = 3,
    delay: int = 1
) -> Tuple[pd.Series, go.Figure]:
    """Calculates rolling Permutation Entropy."""
    s = pd.Series(series)
    
    def _pe(x):
        n = len(x)
        if n < order * delay: return np.nan
        partitions = []
        for i in range(n - (order - 1) * delay):
            window_slice = [x[i + j * delay] for j in range(order)]
            partitions.append(tuple(np.argsort(window_slice)))
        from collections import Counter
        counts = Counter(partitions)
        probs = np.array(list(counts.values())) / len(partitions)
        entropy = -np.sum(probs * np.log2(probs))
        max_entropy = np.log2(math.factorial(order))
        return entropy / max_entropy

    pe = s.rolling(window=window).apply(_pe, raw=True)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=s.index, y=pe, mode='lines', name='Permutation Entropy'))
    fig.update_layout(title=f"Rolling Permutation Entropy (Order={order})", yaxis_title="Normalized PE")
    return pe, fig

def detect_regime_switching_markov(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    k_regimes: int = 2,
    trend: str = 'c',
    switching_variance: bool = True
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Fits a Markov Switching Autoregression model to identify regimes (e.g., High/Low Volatility).
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    date_col : str
        Date column.
    target_col : str
        Target series (e.g., returns).
    k_regimes : int
        Number of regimes (usually 2 or 3).
    trend : str
        'c' (constant), 'nc' (no constant), etc.
    switching_variance : bool
        Whether variance switches with regime.
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame with smoothed regime probabilities and plot.
    """
    data = df.set_index(pd.to_datetime(df[date_col])).sort_index()
    y = data[target_col].dropna()
    
    # Fit Model
    # Using MarkovRegression (can handle switching mean and variance)
    model = MarkovRegression(y, k_regimes=k_regimes, trend=trend, switching_variance=switching_variance)
    res = model.fit(disp=False)
    
    # Extract probabilities
    probs = res.smoothed_marginal_probabilities
    probs.columns = [f"Regime_{i}" for i in range(k_regimes)]
    
    # Plot
    # Create subplots: Price/Series and Regime Probs
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05)
    
    # Plot Series colored by likely regime (using scatter markers or colored line segments)
    # Simplified: Plot series in one color, then regime bands below
    
    fig.add_trace(go.Scatter(x=y.index, y=y, name=target_col, line=dict(color='black', width=1)), row=1, col=1)
    
    # Plot Regime Probabilities
    for i in range(k_regimes):
        fig.add_trace(go.Scatter(
            x=probs.index, y=probs[f"Regime_{i}"], 
            name=f"Regime {i}", 
            mode='lines',
            stackgroup='one' # Stacked area chart for probs
        ), row=2, col=1)
        
    fig.update_layout(height=700, title=f"Markov Switching Regimes ({k_regimes} states)")
    
    return probs, fig

def test_stationarity_comprehensive(
    series: Union[pd.Series, np.ndarray]
) -> Dict[str, Any]:
    """
    Runs ADF, KPSS, and Phillips-Perron (simplified via ADF variant) to test stationarity.
    
    Returns a comprehensive report and a conclusion.
    """
    s = pd.Series(series).dropna()
    
    # 1. ADF (H0: Unit Root / Non-Stationary)
    adf_res = adfuller(s)
    adf_stat = adf_res[0]
    adf_p = adf_res[1]
    adf_stationary = adf_p < 0.05
    
    # 2. KPSS (H0: Stationary)
    # catch warnings for interpolation
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        kpss_res = kpss(s, regression='c', nlags="auto")
        kpss_stat = kpss_res[0]
        kpss_p = kpss_res[1]
        kpss_stationary = kpss_p >= 0.05
        
    # Conclusion logic
    if adf_stationary and kpss_stationary:
        conclusion = "Stationary"
    elif not adf_stationary and not kpss_stationary:
        conclusion = "Non-Stationary"
    elif adf_stationary and not kpss_stationary:
        conclusion = "Difference Stationary (Trend Stationary?)"
    else:
        conclusion = "Trend Stationary (or contradictory)"
        
    return {
        "ADF": {"stat": adf_stat, "p_value": adf_p, "is_stationary": adf_stationary},
        "KPSS": {"stat": kpss_stat, "p_value": kpss_p, "is_stationary": kpss_stationary},
        "Conclusion": conclusion
    }
