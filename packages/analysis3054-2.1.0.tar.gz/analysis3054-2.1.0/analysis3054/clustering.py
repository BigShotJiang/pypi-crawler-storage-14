"""
Time series clustering utilities.

Includes:
- Time Series Clustering (K-Means on extracted features)
"""

from __future__ import annotations

from typing import Tuple, Dict, Optional, List
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

def cluster_time_series(
    df: pd.DataFrame,
    date_col: str,
    value_cols: List[str],
    n_clusters: int = 3,
    method: str = 'features',
    use_pca: bool = True
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Clusters multiple time series into groups based on similarity.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe (wide format usually, or just containing columns to cluster).
    date_col : str
        Date column.
    value_cols : List[str]
        List of column names representing different time series (e.g., different stocks, sensors).
    n_clusters : int
        Number of clusters.
    method : str
        'features': Extracts statistical features (mean, std, trend, autocorrelation).
        'raw': Uses raw values (standardized).
    use_pca : bool
        If True, reduces dimensionality before clustering (useful for 'raw').
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame with ['Series', 'Cluster'] and a plot.
    """
    # Prepare data
    data = df[value_cols].ffill().bfill()
    
    if method == 'features':
        # Extract simple features
        features = []
        for col in value_cols:
            s = data[col]
            feat = {
                'mean': s.mean(),
                'std': s.std(),
                'skew': s.skew(),
                'kurt': s.kurtosis(),
                'autocorr_1': s.autocorr(lag=1),
                'trend': np.polyfit(np.arange(len(s)), s.values, 1)[0] # Slope
            }
            features.append(feat)
        X = pd.DataFrame(features)
        
    elif method == 'raw':
        # Transpose so rows are series
        X = data.T # shape (n_series, n_timesteps)
    else:
        raise ValueError("Method must be 'features' or 'raw'")
        
    # Scale
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # PCA
    if use_pca:
        pca = PCA(n_components=min(X_scaled.shape) - 1 if method=='features' else 0.95)
        X_final = pca.fit_transform(X_scaled)
    else:
        X_final = X_scaled
        
    # K-Means
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    labels = kmeans.fit_predict(X_final)
    
    # Result DF
    res_df = pd.DataFrame({
        'Series': value_cols,
        'Cluster': labels
    })
    
    # Plot
    # Scatter plot of PCA components (first 2) if possible, or just time series colored by cluster
    
    fig = go.Figure()
    
    if use_pca and X_final.shape[1] >= 2:
        # PCA Scatter
        for c in range(n_clusters):
            mask = labels == c
            fig.add_trace(go.Scatter(
                x=X_final[mask, 0],
                y=X_final[mask, 1],
                mode='markers+text',
                name=f'Cluster {c}',
                text=[value_cols[i] for i in range(len(value_cols)) if mask[i]],
                textposition="top center"
            ))
        fig.update_layout(title="Time Series Clusters (PCA Projection)")
    else:
        # Plot Representative Series (Centroids) or just all series colored?
        # If many series, plotting all is messy. Plot centroids.
        # If using features, we can't plot time series centroids easily from X.
        # Let's plot all series normalized, colored by cluster.
        
        # Normalize data for plotting
        norm_data = (data - data.mean()) / data.std()
        
        dates = df[date_col]
        
        for c in range(n_clusters):
            cluster_cols = [value_cols[i] for i in range(len(value_cols)) if labels[i] == c]
            # Plot mean of cluster
            cluster_mean = norm_data[cluster_cols].mean(axis=1)
            fig.add_trace(go.Scatter(
                x=dates, y=cluster_mean, 
                mode='lines', name=f'Cluster {c} Avg',
                line=dict(width=2)
            ))
            
        fig.update_layout(title="Average Normalized Trend by Cluster")
        
    return res_df, fig
