"""
Advanced signal processing tools for time series.

Includes:
- Singular Spectrum Analysis (SSA)
- Surrogate Data Generation (IAAFT)
- Continuous Wavelet Transform (CWT)
"""

from __future__ import annotations

from typing import Tuple, List, Optional, Union
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from scipy.linalg import hankel, svd

try:
    import pywt
except ImportError:
    pywt = None

def decompose_singular_spectrum(
    series: Union[pd.Series, np.ndarray],
    L: Optional[int] = None,
    n_components: int = 2
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Performs Singular Spectrum Analysis (SSA) to decompose a time series into
    trend, oscillation, and noise components.
    
    Parameters
    ----------
    series : array-like
        Input time series.
    L : int, optional
        Window length. Defaults to N/2.
    n_components : int
        Number of principal components to reconstruct individually.
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame with reconstructed components and interactive plot.
    """
    series = np.array(series)
    series = series[~np.isnan(series)] # Drop NaNs
    N = len(series)
    
    if L is None:
        L = N // 2
        
    K = N - L + 1
    
    # 1. Embedding (Trajectory Matrix)
    X = hankel(series[:L], series[L-1:])
    
    # 2. SVD
    U, Sigma, V = svd(X)
    V = V.T # Python returns V.T
    
    # 3. Grouping & 4. Reconstruction (Diagonal Averaging)
    components = {}
    
    def diagonal_averaging(Matrix):
        # Let's use a robust logic for diagonal averaging
        nrows, ncols = Matrix.shape
        res = np.zeros(N)
        for i in range(N):
            count = 0
            sum_val = 0
            for r in range(L):
                c = i - r
                if 0 <= c < K:
                    sum_val += Matrix[r, c]
                    count += 1
            if count > 0:
                res[i] = sum_val / count
        return res

    reconstructed_total = np.zeros(N)
    
    for i in range(n_components):
        # Reconstruct Elementary Matrix
        Xi = Sigma[i] * np.outer(U[:, i], V[:, i])
        # Diagonal Average
        rec = diagonal_averaging(Xi)
        components[f'Component_{i+1}'] = rec
        reconstructed_total += rec
        
    components['Residual'] = series - reconstructed_total
    
    df_comp = pd.DataFrame(components)
    
    # Plot
    fig = go.Figure()
    fig.add_trace(go.Scatter(y=series, name='Original', line=dict(color='black', width=1)))
    
    for col in df_comp.columns:
        if col != 'Residual':
            fig.add_trace(go.Scatter(y=df_comp[col], name=col))
            
    fig.update_layout(title=f"Singular Spectrum Analysis (L={L})")
    
    return df_comp, fig

def generate_surrogate_data(
    series: Union[pd.Series, np.ndarray],
    n_surrogates: int = 19,
    method: str = 'IAAFT',
    max_iter: int = 100
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Generates surrogate data using Iterated Amplitude Adjusted Fourier Transform (IAAFT).
    Surrogates preserve the amplitude distribution and power spectrum of the original.
    Used for testing non-linearity.
    
    Parameters
    ----------
    series : array-like
        Original series.
    n_surrogates : int
        Number of surrogates.
    method : str
        'IAAFT' or 'AAFT'.
    
    Returns
    -------
    (pd.DataFrame, go.Figure)
        Surrogates and plot.
    """
    original = np.array(series)
    N = len(original)
    
    # Sorted amplitude (target distribution)
    sorted_original = np.sort(original)
    
    # Original Amplitude Spectrum
    original_fft = np.fft.rfft(original)
    original_amp = np.abs(original_fft)
    
    surrogates = []
    
    for _ in range(n_surrogates):
        # 0. Init: Random shuffle
        surr = np.random.permutation(original)
        
        if method == 'IAAFT':
            for _ in range(max_iter):
                # 1. Match Power Spectrum
                surr_fft = np.fft.rfft(surr)
                phases = np.angle(surr_fft)
                # Combine original amp with current phases
                new_fft = original_amp * np.exp(1j * phases)
                surr = np.fft.irfft(new_fft, n=N)
                
                # 2. Match Amplitude Distribution
                # Rank order replacement
                ranks = surr.argsort().argsort()
                surr = sorted_original[ranks]
                
        elif method == 'AAFT':
            # Simple AAFT (Gaussian scaling)
            # 1. Gaussian rank map
            ranks = original.argsort().argsort()
            gaussian_noise = np.random.normal(size=N)
            gaussian_noise.sort()
            y = gaussian_noise[ranks]
            
            # 2. Phase shuffle
            y_fft = np.fft.rfft(y)
            phases = np.angle(y_fft)
            random_phases = np.random.uniform(0, 2*np.pi, len(phases))
            # Keep DC phase 0?
            random_phases[0] = 0 
            
            y_new_fft = np.abs(y_fft) * np.exp(1j * random_phases)
            y_surr = np.fft.irfft(y_new_fft, n=N)
            
            # 3. Remap to original distribution
            ranks_surr = y_surr.argsort().argsort()
            surr = sorted_original[ranks_surr]
            
        surrogates.append(surr)
        
    df_surr = pd.DataFrame(np.array(surrogates).T, columns=[f"Surr_{i+1}" for i in range(n_surrogates)])
    
    # Plot
    fig = go.Figure()
    fig.add_trace(go.Scatter(y=original, name='Original', line=dict(color='black', width=2)))
    for col in df_surr.columns[:5]: # Plot first 5 only
        fig.add_trace(go.Scatter(y=df_surr[col], name=col, opacity=0.5, line=dict(width=1)))
        
    fig.update_layout(title="Surrogate Data (IAAFT)")
    
    return df_surr, fig

def analyze_wavelet_spectrum(
    series: Union[pd.Series, np.ndarray],
    wavelet: str = 'cmor',
    scales: Optional[Union[np.ndarray, List[int]]] = None,
    sampling_period: float = 1.0
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Performs Continuous Wavelet Transform (CWT) to analyze time-frequency characteristics.
    
    Parameters
    ----------
    series : array-like
        Input time series.
    wavelet : str
        Wavelet name (e.g., 'cmor', 'morl', 'mexh'). Defaults to Complex Morlet.
    scales : array-like, optional
        Scales to use. Defaults to 1 to 64.
    sampling_period : float
        Time between samples.
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        Power spectrum matrix (DataFrame with scales as index, time as columns) and Heatmap.
    """
    if pywt is None:
        raise ImportError("PyWavelets is not installed. Please install it via 'pip install PyWavelets'.")
    
    s = np.array(series)
    if scales is None:
        scales = np.arange(1, 65)
        
    # CWT
    coeffs, freqs = pywt.cwt(s, scales, wavelet, sampling_period=sampling_period)
    
    # Power Spectrum (Magnitude squared)
    power = (np.abs(coeffs)) ** 2
    
    # To DataFrame
    df_power = pd.DataFrame(power, index=scales, columns=np.arange(len(s)))
    
    # Plot
    fig = go.Figure(data=go.Heatmap(
        z=power,
        x=np.arange(len(s)),
        y=scales,
        colorscale='Viridis'
    ))
    
    fig.update_layout(
        title=f"Wavelet Power Spectrum ({wavelet})",
        xaxis_title="Time",
        yaxis_title="Scale (Inverse Frequency)"
    )
    
    return df_power, fig
