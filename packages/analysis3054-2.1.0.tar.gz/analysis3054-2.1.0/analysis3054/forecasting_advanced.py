"""
Advanced forecasting functions using Deep Learning and Statistical methods.

This module expands on the core forecasting tools with state-of-the-art models:
- Chronos (Amazon): A T5-based foundation model for time series.
- Probabilistic LSTM: A PyTorch-based LSTM with quantile output.
- STL Decomposition Forecast: Structural decomposition + robust trend/seasonality forecasting.
- Vector Autoregression (VAR): Multivariate forecasting.
- Prophet (wrapper): Standard Facebook Prophet (optional).
- Impulse Response Analysis: For VAR models.

All functions are optimized for CPU inference where possible.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple, List, Any, Dict, Union
import warnings
import os

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import plotly.graph_objects as go
from scipy import stats

# Try importing torch for deep learning models
try:
    import torch
    import torch.nn as nn
except ImportError:
    torch = None
    nn = None

# Try importing Chronos
try:
    from chronos import ChronosPipeline
except ImportError:
    ChronosPipeline = None

# Try importing Prophet
try:
    from prophet import Prophet
except ImportError:
    Prophet = None

from sklearn.preprocessing import RobustScaler, MinMaxScaler
from sklearn.linear_model import LinearRegression, HuberRegressor
from statsmodels.tsa.seasonal import STL
from statsmodels.tsa.api import VAR
from statsmodels.tsa.holtwinters import ExponentialSmoothing

from .forecasting import ForecastingResult, _prepare_data, _plot_forecast, _create_interactive_plot
from .plot_interactive import plot_decomposition_interactive

def _add_seasonality_features(df: pd.DataFrame, date_col: str) -> pd.DataFrame:
    """
    Enrich dataframe with seasonality features (Month, DayOfYear, Fourier terms).
    Useful for models that can take covariates.
    """
    df = df.copy()
    dates = pd.to_datetime(df[date_col])
    
    df['month'] = dates.dt.month
    df['day_of_year'] = dates.dt.dayofyear
    df['day_of_week'] = dates.dt.dayofweek
    
    # Fourier terms for annual seasonality
    df['sin_year'] = np.sin(2 * np.pi * df['day_of_year'] / 365.25)
    df['cos_year'] = np.cos(2 * np.pi * df['day_of_year'] / 365.25)
    
    return df

def forecast_chronos(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    model_path: str = "amazon/chronos-t5-small",
    num_samples: int = 20,
    device_map: str = "cpu",
    context_length: int = 512,
) -> ForecastingResult:
    """
    Forecast using Amazon's Chronos Foundation Model (Chronos 2).
    
    Parameters
    ----------
    model_path : str
        HuggingFace model path. Defaults to 'amazon/chronos-t5-small' for CPU efficiency.
        Use 'amazon/chronos-t5-tiny' for faster CPU inference or 'large' for better accuracy.
    num_samples : int
        Number of samples for probabilistic forecasting.
    device_map : str
        Device to run on ('cpu', 'cuda'). Defaults to 'cpu'.
    context_length : int
        Context length for the model.
        
    Note: Chronos is primarily univariate. Covariates in 'df' are used for 
    visualization/alignment but not fed into the pre-trained model unless 
    fine-tuned. This function focuses on robust univariate forecasting.
    """
    if ChronosPipeline is None:
        raise ImportError("chronos-forecasting is not installed. Please install it to use this function.")
    
    # Prepare data (Chronos needs a simple series)
    # We use _prepare_data just to get the split, but we need the raw series
    X_train_df, _, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
    
    # Chronos pipeline expects a torch tensor context
    pipeline = ChronosPipeline.from_pretrained(
        model_path,
        device_map=device_map,
        torch_dtype=torch.float32,
    )
    
    # Prepare context
    # y_train is a Series, convert to tensor
    context = torch.tensor(y_train.values, dtype=torch.float32)
    
    # Handle context length (truncate if too long)
    if len(context) > context_length:
        context = context[-context_length:]
        
    prediction_length = len(future_dates)
    
    # Predict
    # output shape: [num_series, num_samples, prediction_length]
    forecast = pipeline.predict(
        context,
        prediction_length,
        num_samples=num_samples,
        limit_prediction_length=False
    )
    
    # Process output
    # Extract median and quantiles
    forecast_samples = forecast[0].numpy() # [num_samples, prediction_length]
    
    median_forecast = np.median(forecast_samples, axis=0)
    lower_ci = np.percentile(forecast_samples, 10, axis=0) # 80% interval
    upper_ci = np.percentile(forecast_samples, 90, axis=0)
    
    forecast_df = pd.DataFrame({
        'date': future_dates,
        'predicted': median_forecast,
        'lower_ci': lower_ci,
        'upper_ci': upper_ci
    })
    
    hist_dates = df[df[date_col] < pd.to_datetime(prediction_start)][date_col]
    # Limit historical plot for clarity if too long
    if len(hist_dates) > 200:
        hist_dates = hist_dates.iloc[-200:]
        y_train_plot = y_train.iloc[-200:]
    else:
        y_train_plot = y_train

    fig = _plot_forecast(hist_dates, y_train_plot, future_dates, median_forecast, lower_ci, upper_ci,
                         f'Chronos Forecast ({model_path})', target_col)
    
    fig_interactive = _create_interactive_plot(hist_dates, y_train_plot, forecast_df, date_col, target_col, f'Chronos Forecast ({model_path})')
    
    return ForecastingResult(
        forecast=forecast_df,
        model=pipeline, # Return pipeline object
        metrics={}, # Cannot compute valid metrics on future without ground truth
        figure=fig,
        figure_interactive=fig_interactive
    )

def forecast_stl_decomposition(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    period: Optional[int] = None,
) -> ForecastingResult:
    """
    Robust Structural Forecasting using STL Decomposition.
    """
    try:
        _, _, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        if y_train.isna().any():
            y_train = y_train.interpolate().bfill().ffill()
            
        # Determine period if not provided
        if period is None:
            freq = pd.infer_freq(df[date_col])
            if freq:
                if 'M' in freq: period = 12
                elif 'D' in freq: period = 7
                elif 'Q' in freq: period = 4
                else: period = 12 
            else:
                period = 12 
        
        # STL Decomposition
        res = STL(y_train, period=period, robust=True).fit()
        
        # 1. Trend Forecast (Linear extrapolation of last part of trend)
        trend_train = res.trend.dropna()
        X_trend = np.arange(len(trend_train)).reshape(-1, 1)
        trend_model = HuberRegressor() # Robust regression
        trend_model.fit(X_trend[-2*period:], trend_train.values[-2*period:])
        
        future_steps = len(future_dates)
        X_future = np.arange(len(trend_train), len(trend_train) + future_steps).reshape(-1, 1)
        trend_forecast = trend_model.predict(X_future)
        
        # 2. Seasonal Forecast
        seasonal_component = res.seasonal.values[-period:]
        tiled_seasonal = np.tile(seasonal_component, int(np.ceil(future_steps / period)))
        seasonal_forecast = tiled_seasonal[:future_steps]
        
        # 3. Residual Forecast (Assume 0 mean)
        resid_forecast = np.zeros(future_steps)
        
        # Combine
        total_forecast = trend_forecast + seasonal_forecast + resid_forecast
        
        # Simple CI based on residual std
        resid_std = res.resid.std()
        lower = total_forecast - 1.96 * resid_std
        upper = total_forecast + 1.96 * resid_std
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': total_forecast,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = df[df[date_col] < pd.to_datetime(prediction_start)][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, total_forecast, lower, upper,
                             f'STL Decomposition Forecast (Period={period})', target_col)
                             
        # Interactive Plot (Specific STL or Fan)
        # Let's use generic Fan for main forecasting, but also include STL decomp if requested separately
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'STL Decomposition Forecast')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=res,
            metrics={'resid_std': resid_std},
            figure=fig,
            figure_interactive=fig_interactive
        )
        
    except Exception as e:
        print(f"Error in STL forecasting: {e}")
        raise

class _ProbabilisticLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super().__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size * 3) # Predict Low(10), Median(50), High(90)
        
    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :]) # Take last time step
        return out

def forecast_lstm_probabilistic(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    lookback: int = 30,
    epochs: int = 50,
) -> ForecastingResult:
    """
    Probabilistic forecasting using a PyTorch LSTM.
    """
    if torch is None:
        raise ImportError("torch is not installed.")
        
    try:
        X_train_df, X_future_df, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        scaler_y = MinMaxScaler()
        y_scaled = scaler_y.fit_transform(y_train.values.reshape(-1, 1))
        
        scaler_X = MinMaxScaler()
        X_scaled = scaler_X.fit_transform(X_train_df.values)
        X_future_scaled = scaler_X.transform(X_future_df.values)
        
        X_seq, y_seq = [], []
        data_len = len(y_scaled)
        
        for i in range(data_len - lookback):
            seq_feat = np.hstack([y_scaled[i:i+lookback], X_scaled[i:i+lookback]])
            X_seq.append(seq_feat)
            y_seq.append(y_scaled[i+lookback])
            
        X_seq = torch.FloatTensor(np.array(X_seq))
        y_seq = torch.FloatTensor(np.array(y_seq))
        
        input_size = X_seq.shape[2]
        model = _ProbabilisticLSTM(input_size, hidden_size=32, num_layers=1, output_size=1)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
        
        def quantile_loss(preds, target, quantiles=[0.1, 0.5, 0.9]):
            losses = []
            for i, q in enumerate(quantiles):
                error = target - preds[:, i:i+1]
                loss = torch.max((q-1) * error, q * error)
                losses.append(loss)
            return torch.mean(torch.sum(torch.cat(losses, dim=1), dim=1))

        model.train()
        for _ in range(epochs):
            optimizer.zero_grad()
            out = model(X_seq)
            loss = quantile_loss(out, y_seq)
            loss.backward()
            optimizer.step()
            
        model.eval()
        preds = []
        lowers = []
        uppers = []
        
        curr_seq = np.hstack([y_scaled[-lookback:], X_scaled[-lookback:]])
        curr_seq = torch.FloatTensor(curr_seq).unsqueeze(0) 
        
        with torch.no_grad():
            for i in range(len(future_dates)):
                out = model(curr_seq) 
                pred_val = out[0, 1].item() 
                lower_val = out[0, 0].item()
                upper_val = out[0, 2].item()
                
                preds.append(pred_val)
                lowers.append(lower_val)
                uppers.append(upper_val)
                
                new_y = np.array([[pred_val]])
                new_x = X_future_scaled[i:i+1]
                new_feat = np.hstack([new_y, new_x]) 
                curr_seq = torch.cat([curr_seq[:, 1:, :], torch.FloatTensor(new_feat).unsqueeze(0)], dim=1)
                
        preds = scaler_y.inverse_transform(np.array(preds).reshape(-1, 1)).flatten()
        lowers = scaler_y.inverse_transform(np.array(lowers).reshape(-1, 1)).flatten()
        uppers = scaler_y.inverse_transform(np.array(uppers).reshape(-1, 1)).flatten()
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': preds,
            'lower_ci': lowers,
            'upper_ci': uppers
        })
        
        hist_dates = df[df[date_col] < pd.to_datetime(prediction_start)][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds, lowers, uppers,
                             'Probabilistic LSTM Forecast', target_col)
                             
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, 'Probabilistic LSTM Forecast')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=model,
            metrics={},
            figure=fig,
            figure_interactive=fig_interactive
        )

    except Exception as e:
        print(f"Error in LSTM forecasting: {e}")
        raise

def forecast_var_multivariate(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    variables: Optional[List[str]] = None,
    maxlags: int = 15,
) -> ForecastingResult:
    """
    Multivariate forecasting using Vector Autoregression (VAR).
    Captures interdependence between multiple time series.
    """
    try:
        # Custom prepare data for multivariate
        data = df.copy()
        data[date_col] = pd.to_datetime(data[date_col])
        data = data.sort_values(date_col)
        
        prediction_start_dt = pd.to_datetime(prediction_start)
        historical = data[data[date_col] < prediction_start_dt].copy()
        future = data[data[date_col] >= prediction_start_dt].copy()
        
        if variables is None:
            # Use all numeric columns
            variables = historical.select_dtypes(include=np.number).columns.tolist()
        
        # Ensure target is in variables
        if target_col not in variables:
            variables.append(target_col)
            
        train_df = historical[variables].dropna()
        
        # Fit VAR
        model = VAR(train_df)
        results = model.fit(maxlags=maxlags, ic='aic')
        
        # Forecast
        lag_order = results.k_ar
        forecast_input = train_df.values[-lag_order:]
        steps = len(future)
        
        # Forecast with intervals (analytical)
        # results.forecast_interval returns (mid, lower, upper)
        # alpha=0.05 -> 95% CI
        fc_mid, fc_lower, fc_upper = results.forecast_interval(forecast_input, steps=steps, alpha=0.05)
        
        # Extract target column index
        target_idx = train_df.columns.get_loc(target_col)
        
        preds = fc_mid[:, target_idx]
        lower = fc_lower[:, target_idx]
        upper = fc_upper[:, target_idx]
        
        forecast_df = pd.DataFrame({
            'date': future[date_col].values,
            'predicted': preds,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = historical[date_col]
        y_train = historical[target_col]
        
        fig = _plot_forecast(hist_dates, y_train, future[date_col], preds, lower, upper,
                             f'VAR Forecast (Lags={lag_order})', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'VAR Forecast (Lags={lag_order})')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=results,
            metrics={'aic': results.aic},
            figure=fig,
            figure_interactive=fig_interactive
        )
        
    except Exception as e:
        print(f"Error in VAR forecasting: {e}")
        raise

def forecast_prophet_robust(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    seasonality_mode: str = 'additive',
    **kwargs
) -> ForecastingResult:
    """
    Robust wrapper for Facebook Prophet.
    """
    if Prophet is None:
        raise ImportError("prophet is not installed. Please install it to use this function.")
        
    try:
        # Prophet requires columns 'ds' and 'y'
        data = df.copy()
        data = data.rename(columns={date_col: 'ds', target_col: 'y'})
        
        prediction_start_dt = pd.to_datetime(prediction_start)
        historical = data[data['ds'] < prediction_start_dt].copy()
        future_dates = data[data['ds'] >= prediction_start_dt]['ds']
        
        model = Prophet(seasonality_mode=seasonality_mode, **kwargs)
        model.fit(historical)
        
        future = pd.DataFrame({'ds': future_dates})
        forecast = model.predict(future)
        
        preds = forecast['yhat'].values
        lower = forecast['yhat_lower'].values
        upper = forecast['yhat_upper'].values
        
        forecast_df = pd.DataFrame({
            'date': future_dates.values,
            'predicted': preds,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = df[df[date_col] < prediction_start_dt][date_col]
        y_train = df[df[date_col] < prediction_start_dt][target_col]
        
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds, lower, upper,
                             'Prophet Forecast', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, 'Prophet Forecast')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=model,
            metrics={},
            figure=fig,
            figure_interactive=fig_interactive
        )
        
    except Exception as e:
        print(f"Error in Prophet forecasting: {e}")
        raise

def analyze_impulse_response(
    var_result: ForecastingResult,
    impulse: Optional[str] = None,
    response: Optional[str] = None,
    steps: int = 10
) -> go.Figure:
    """
    Computes and plots the Impulse Response Function (IRF) from a fitted VAR model.
    Shows how a shock to one variable affects another over time.
    
    Parameters
    ----------
    var_result : ForecastingResult
        Result object from `forecast_var_multivariate`.
    impulse : str, optional
        Name of the variable creating the shock. Defaults to first variable.
    response : str, optional
        Name of the variable responding. Defaults to all.
    steps : int
        Number of steps to plot.
        
    Returns
    -------
    go.Figure
        Interactive IRF plot.
    """
    # Check if model is valid VARResultsWrapper
    # It might be wrapped in something else depending on statsmodels version
    model_res = var_result.model
    if not hasattr(model_res, 'irf'):
        raise ValueError("Provided result does not contain a valid VAR model.")
        
    irf = model_res.irf(steps)
    
    # Plot using Plotly manually for interactivity
    # irf.irfs is (steps+1, k_vars, k_vars)
    # dimensions: time, impulse_idx, response_idx
    
    names = model_res.names
    k = len(names)
    
    if impulse is None: impulse = names[0]
    impulse_idx = names.index(impulse)
    
    fig = go.Figure()
    
    response_indices = range(k)
    if response:
        response_indices = [names.index(response)]
        
    for r_idx in response_indices:
        r_name = names[r_idx]
        values = irf.irfs[:, impulse_idx, r_idx]
        # Errors if computed? irf.irf_errband is available if we ran irf with CIs?
        # irf() by default computes them? No, need to call .irf() which returns IRAnalysis
        # We can access .orth_irfs usually
        
        fig.add_trace(go.Scatter(
            y=values,
            mode='lines+markers',
            name=f'{impulse} -> {r_name}'
        ))
        
    fig.update_layout(
        title=f"Impulse Response Analysis (Impulse: {impulse})",
        xaxis_title="Steps",
        yaxis_title="Response"
    )
    
    return fig
