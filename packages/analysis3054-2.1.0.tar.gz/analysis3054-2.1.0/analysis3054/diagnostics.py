"""
Diagnostic tools for time series models.

Includes:
- Residual Analysis (4-plot panel)
- Rolling Window Backtesting
"""

from __future__ import annotations

from typing import Callable, Dict, List, Tuple, Any, Optional, Union
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import stats
from statsmodels.tsa.stattools import acf
from sklearn.metrics import mean_absolute_error, mean_squared_error

def plot_residual_diagnostics(
    residuals: Union[np.ndarray, pd.Series],
    title: str = "Residual Diagnostics"
) -> go.Figure:
    """
    Creates a 4-panel diagnostic plot for model residuals:
    1. Residuals over time
    2. Histogram (Distribution vs Normal)
    3. ACF (Autocorrelation)
    4. QQ Plot (Normality check)
    
    Parameters
    ----------
    residuals : array-like
        Model residuals.
        
    Returns
    -------
    go.Figure
        Interactive Plotly figure.
    """
    resid = np.array(residuals)
    resid = resid[~np.isnan(resid)] # Remove NaNs
    
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=("Residuals over Time", "Histogram", "Autocorrelation", "Q-Q Plot")
    )
    
    # 1. Time Series
    fig.add_trace(go.Scatter(y=resid, mode='lines', name='Residuals'), row=1, col=1)
    fig.add_hline(y=0, line_dash="dash", line_color="black", row=1, col=1)
    
    # 2. Histogram
    fig.add_trace(go.Histogram(x=resid, name='Dist', histnorm='probability density', opacity=0.7), row=1, col=2)
    # Add normal curve
    mu, std = np.mean(resid), np.std(resid)
    x_range = np.linspace(min(resid), max(resid), 100)
    pdf = stats.norm.pdf(x_range, mu, std)
    fig.add_trace(go.Scatter(x=x_range, y=pdf, mode='lines', name='Normal', line=dict(color='red')), row=1, col=2)
    
    # 3. ACF
    acf_vals = acf(resid, nlags=20, fft=True)
    lags = np.arange(len(acf_vals))
    fig.add_trace(go.Bar(x=lags, y=acf_vals, name='ACF'), row=2, col=1)
    # Significance bounds (approx 1.96/sqrt(N))
    conf = 1.96 / np.sqrt(len(resid))
    fig.add_shape(type="line", x0=0, x1=20, y0=conf, y1=conf, line=dict(color="red", dash="dot"), row=2, col=1)
    fig.add_shape(type="line", x0=0, x1=20, y0=-conf, y1=-conf, line=dict(color="red", dash="dot"), row=2, col=1)
    
    # 4. QQ Plot
    # Sort residuals
    sorted_resid = np.sort(resid)
    # Theoretical quantiles
    theoretical = stats.norm.ppf(np.linspace(0.01, 0.99, len(resid)), loc=mu, scale=std)
    
    fig.add_trace(go.Scatter(x=theoretical, y=sorted_resid, mode='markers', name='QQ'), row=2, col=2)
    # Add 45 degree line
    min_val = min(np.min(theoretical), np.min(sorted_resid))
    max_val = max(np.max(theoretical), np.max(sorted_resid))
    fig.add_trace(go.Scatter(x=[min_val, max_val], y=[min_val, max_val], mode='lines', name='Identity', line=dict(color='red')), row=2, col=2)
    
    fig.update_layout(height=700, title=title, showlegend=False)
    return fig

def backtest_rolling_window(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    forecast_func: Callable,
    initial_window: int = 100,
    step_size: int = 10,
    horizon: int = 10,
    metric: str = 'MAE',
    **kwargs
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Performs Walk-Forward Validation (Rolling Window Backtesting).
    
    Parameters
    ----------
    df : pd.DataFrame
        Full historical data.
    date_col : str
        Date column.
    target_col : str
        Target variable.
    forecast_func : Callable
        Function to call (e.g., forecast_random_forest).
        Must accept (df, date_col, target_col, prediction_start, **kwargs).
        Must return a ForecastingResult object.
    initial_window : int
        Number of initial samples to train on.
    step_size : int
        Number of samples to advance the window.
    horizon : int
        Forecast horizon to validate against.
    **kwargs : 
        Arguments passed to forecast_func.
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame of errors per fold and a summary plot.
    """
    data = df.sort_values(date_col).reset_index(drop=True)
    n = len(data)
    
    results = []
    
    # Iterate through folds
    for start_idx in range(initial_window, n - horizon, step_size):
        # Define cutoff date (prediction_start)
        # The data up to start_idx is history.
        # The data from start_idx to start_idx + horizon is the "future" (validation set)
        
        cutoff_row = data.iloc[start_idx]
        cutoff_date = cutoff_row[date_col]
        
        # Create a view of the data that simulates real-time
        # We pass the FULL dataframe because our forecast functions expect the "future" rows 
        # to be present (for covariates) but target to be unknown/masked if we follow strict rules.
        # However, our forecast functions SPLIT based on prediction_start internally.
        # So we can just pass the full dataframe, and specify prediction_start=cutoff_date.
        # The forecast function will treat >= cutoff_date as future.
        # IMPORTANT: The forecast function returns a forecast starting AT prediction_start.
        
        # We need to check if the forecast function effectively "hides" the target for the future.
        # Yes, _prepare_data splits historical < prediction_start.
        
        # Call forecast
        try:
            res = forecast_func(
                df=data, 
                date_col=date_col, 
                target_col=target_col, 
                prediction_start=cutoff_date,
                **kwargs
            )
            
            # Compare predictions with actuals
            # res.forecast contains predictions. We align with actual data.
            pred_df = res.forecast.head(horizon) # We only care about 'horizon' steps
            
            # Actuals
            # We need to find actuals corresponding to pred_df['date']
            # Merge
            validation = pd.merge(pred_df, data[[date_col, target_col]], on=date_col, how='inner')
            
            if validation.empty:
                continue
                
            y_true = validation[target_col]
            y_pred = validation['predicted']
            
            if metric == 'MAE':
                error = mean_absolute_error(y_true, y_pred)
            elif metric == 'RMSE':
                error = np.sqrt(mean_squared_error(y_true, y_pred))
            else:
                error = np.nan
                
            results.append({
                'cutoff_date': cutoff_date,
                'metric': error,
                'horizon': len(validation)
            })
            
        except Exception as e:
            print(f"Backtest fold failed at {cutoff_date}: {e}")
            
    results_df = pd.DataFrame(results)
    
    # Plot
    fig = go.Figure()
    if not results_df.empty:
        fig.add_trace(go.Scatter(
            x=results_df['cutoff_date'], 
            y=results_df['metric'],
            mode='lines+markers',
            name=f'{metric} over Time'
        ))
        avg_error = results_df['metric'].mean()
        fig.add_hline(y=avg_error, line_dash="dash", line_color="red", annotation_text=f"Avg {metric}: {avg_error:.2f}")
        
    fig.update_layout(title=f"Rolling Backtest Results ({metric})")
    
    return results_df, fig
