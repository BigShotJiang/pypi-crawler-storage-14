"""
EIA Band Plot Package
=====================

This package provides a convenient function for generating
`5‑year band` plots similar to those used by the U.S. Energy
Information Administration (EIA).  These plots visualize the
historical range, average, and current/prior year values for a
time series, making it easy to see how recent data compare with
the last five years of history.

The primary entry point is :func:`~analysis3054.five_year_plot`.

Example
-------
.. code-block:: python

    import pandas as pd
    from analysis3054 import five_year_plot

    # Suppose `df` has a ``date`` column and one or more value columns
    fig = five_year_plot(date=df['date'], df=df)
    fig.show()
"""

from .plot import five_year_plot
from .ml import ml_forecast, ForecastResult
from .predict import monthly_predictor, MonthlyPredictionResult
from .utils import (
    conditional_column_merge,
    conditional_row_merge,
    nearest_key_merge,
    coalesce_merge,
    rolling_fill,
)
from .estimators import (
    bayesian_linear_estimator,
    BayesianLinearResult,
    gaussian_process_estimator,
    GaussianProcessResult,
    load_based_forecast,
    LoadForecastResult,
)
from .finance import (
    liquidity_adjusted_volatility,
    LiquidityAdjustedVolatilityResult,
    rolling_beta,
    RollingBetaResult,
    calculate_tail_risk_metrics,
)
from .advanced import (
    harmonic_forecast,
    HarmonicForecastResult,
    ewma_volatility,
    EwmaVolatilityResult,
    monte_carlo_simulation,
    MonteCarloSimulationResult,
    value_at_risk,
    VaRResult,
    cointegration_test,
    CointegrationTestResult,
    spectral_density_plot,
    wavelet_spectrogram,
    kalman_smoother,
    resample_time_series,
    stl_decompose_plot,
)
from .forecasting import (
    forecast_random_forest,
    forecast_xgboost,
    forecast_svm,
    forecast_elastic_net,
    forecast_sarimax,
    generate_scenarios_bootstrap,
    ForecastingResult,
)
from .forecasting_advanced import (
    forecast_chronos,
    forecast_stl_decomposition,
    forecast_lstm_probabilistic,
    forecast_var_multivariate,
    forecast_prophet_robust,
    analyze_impulse_response,
)
from .ensemble import forecast_ensemble
from .causal import analyze_intervention_impact
from .tools import (
    detect_outliers_zscore,
    check_stationarity_adf,
    calculate_forecast_metrics,
    plot_forecast_comparison,
    smart_merge_asof,
    intelligent_impute_and_align,
)
from .analysis import (
    analyze_granger_causality,
    detect_structural_breaks,
    analyze_cross_correlation,
    detect_anomalies_isolation_forest,
    fit_garch_volatility,
    analyze_dynamic_time_warping,
)
from .stats_advanced import (
    test_diebold_mariano,
    calculate_rolling_hurst_exponent,
    calculate_rolling_permutation_entropy,
    detect_regime_switching_markov,
    test_stationarity_comprehensive,
)
from .signal import (
    decompose_singular_spectrum,
    generate_surrogate_data,
    analyze_wavelet_spectrum,
)
from .plot_interactive import (
    plot_yearly_comparison_interactive,
    plot_fan_chart_interactive,
    plot_decomposition_interactive,
)
from .diagnostics import (
    plot_residual_diagnostics,
    backtest_rolling_window,
)
from .clustering import cluster_time_series
from .wrapper import TimeSeriesLab

__all__ = [
    "five_year_plot",
    "ml_forecast",
    "ForecastResult",
    "monthly_predictor",
    "MonthlyPredictionResult",
    "harmonic_forecast",
    "HarmonicForecastResult",
    "ewma_volatility",
    "EwmaVolatilityResult",
    "monte_carlo_simulation",
    "MonteCarloSimulationResult",
    "value_at_risk",
    "VaRResult",
    "cointegration_test",
    "CointegrationTestResult",
    "spectral_density_plot",
    "wavelet_spectrogram",
    "kalman_smoother",
    "resample_time_series",
    "stl_decompose_plot",
    # data utilities
    "conditional_column_merge",
    "conditional_row_merge",
    "nearest_key_merge",
    "coalesce_merge",
    "rolling_fill",
    # advanced estimators
    "bayesian_linear_estimator",
    "BayesianLinearResult",
    "gaussian_process_estimator",
    "GaussianProcessResult",
    "load_based_forecast",
    "LoadForecastResult",
    # financial analytics
    "liquidity_adjusted_volatility",
    "LiquidityAdjustedVolatilityResult",
    "rolling_beta",
    "RollingBetaResult",
    "calculate_tail_risk_metrics",
    # forecasting
    "forecast_random_forest",
    "forecast_xgboost",
    "forecast_svm",
    "forecast_elastic_net",
    "forecast_sarimax",
    "generate_scenarios_bootstrap",
    "ForecastingResult",
    # advanced forecasting
    "forecast_chronos",
    "forecast_stl_decomposition",
    "forecast_lstm_probabilistic",
    "forecast_var_multivariate",
    "forecast_prophet_robust",
    "analyze_impulse_response",
    # ensemble & causal
    "forecast_ensemble",
    "analyze_intervention_impact",
    # tools
    "detect_outliers_zscore",
    "check_stationarity_adf",
    "calculate_forecast_metrics",
    "plot_forecast_comparison",
    "smart_merge_asof",
    "intelligent_impute_and_align",
    # analysis
    "analyze_granger_causality",
    "detect_structural_breaks",
    "analyze_cross_correlation",
    "detect_anomalies_isolation_forest",
    "fit_garch_volatility",
    "analyze_dynamic_time_warping",
    # stats & signal
    "test_diebold_mariano",
    "calculate_rolling_hurst_exponent",
    "calculate_rolling_permutation_entropy",
    "detect_regime_switching_markov",
    "test_stationarity_comprehensive",
    "decompose_singular_spectrum",
    "generate_surrogate_data",
    "analyze_wavelet_spectrum",
    # interactive plotting
    "plot_yearly_comparison_interactive",
    "plot_fan_chart_interactive",
    "plot_decomposition_interactive",
    # diagnostics & clustering
    "plot_residual_diagnostics",
    "backtest_rolling_window",
    "cluster_time_series",
    # wrapper
    "TimeSeriesLab",
]
