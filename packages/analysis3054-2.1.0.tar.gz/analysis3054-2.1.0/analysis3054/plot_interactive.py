"""
Interactive plotting utilities using Plotly.
"""

from __future__ import annotations

from typing import Optional, List, Dict, Union, Any
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from statsmodels.tsa.stattools import acf
from scipy import stats

def plot_yearly_comparison_interactive(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    forecast_df: Optional[pd.DataFrame] = None,
    title: str = "Yearly Comparison",
    normalize: bool = False
) -> go.Figure:
    """
    Creates an interactive Plotly chart comparing the target variable across years.
    
    Lines are colored:
    - Current Year (Max historical year): Red
    - Last Year (Max - 1): Blue
    - Next Year (Max + 1 or Forecast): Yellow
    - Others: Grey (low opacity)
    
    Parameters
    ----------
    df : pd.DataFrame
        Historical dataframe.
    date_col : str
        Name of date column.
    target_col : str
        Name of value column.
    forecast_df : pd.DataFrame, optional
        Forecast dataframe. Must have date_col and 'predicted' (or target_col).
    title : str
        Chart title.
    normalize : bool
        If True, rebase each year to start at 0 (percentage change from first day of year).
        
    Returns
    -------
    go.Figure
        Plotly figure object.
    """
    # Prepare historical data
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df['year'] = df[date_col].dt.year
    df['day_of_year'] = df[date_col].dt.dayofyear
    
    years = sorted(df['year'].unique())
    current_year = max(years)
    last_year = current_year - 1
    next_year = current_year + 1
    
    fig = go.Figure()
    
    # Plot historical years
    for year in years:
        year_data = df[df['year'] == year].sort_values('day_of_year')
        
        y_vals = year_data[target_col].values
        if normalize and len(y_vals) > 0:
            # Percentage change from first value of the year
            base = y_vals[0]
            if base != 0:
                y_vals = (y_vals - base) / base * 100
            else:
                y_vals = y_vals # Cannot normalize
                
        # Determine color and width
        if year == current_year:
            color = 'red'
            width = 3
            opacity = 1.0
            name = f"{year} (Current)"
        elif year == last_year:
            color = 'blue'
            width = 2
            opacity = 0.8
            name = f"{year} (Last)"
        elif year == next_year:
            color = 'yellow' # Or gold
            width = 3
            opacity = 1.0
            name = f"{year} (Next)"
        else:
            color = 'grey'
            width = 1
            opacity = 0.3
            name = str(year)
            
        fig.add_trace(go.Scatter(
            x=year_data['day_of_year'],
            y=y_vals,
            mode='lines',
            name=name,
            line=dict(color=color, width=width),
            opacity=opacity,
            hovertemplate=f"Year: {year}<br>Day: %{{x}}<br>Value: %{{y:.2f}}{'%' if normalize else ''}<extra></extra>"
        ))
        
    # Plot forecast if provided
    if forecast_df is not None:
        fdf = forecast_df.copy()
        fdf[date_col] = pd.to_datetime(fdf[date_col])
        fdf['year'] = fdf[date_col].dt.year
        fdf['day_of_year'] = fdf[date_col].dt.dayofyear
        
        val_col = 'predicted' if 'predicted' in fdf.columns else target_col
        
        f_years = sorted(fdf['year'].unique())
        
        for year in f_years:
            year_data = fdf[fdf['year'] == year].sort_values('day_of_year')
            y_vals = year_data[val_col].values
            
            if normalize and len(y_vals) > 0:
                # Need base from history of that year if exists, otherwise assume start of forecast is continuation
                # Complex to get right without full context.
                # Simplified: If we have historical data for this year, align.
                # If pure forecast year (next year), normalize to 0 at start?
                # Let's stick to: If year exists in history, use that base.
                
                # Check history for base
                hist_year = df[df['year'] == year]
                if not hist_year.empty:
                    base = hist_year.sort_values('day_of_year')[target_col].iloc[0]
                    if base != 0:
                        y_vals = (y_vals - base) / base * 100
                elif len(y_vals) > 0:
                     # Normalize to itself start? Or 0? 
                     # Better to not normalize purely future years without context in this simple view
                     pass

            # Determine color
            if year == current_year:
                color = 'red'
            elif year == last_year:
                color = 'blue'
            elif year >= next_year:
                color = '#FFD700' # Gold/Yellow
            else:
                color = 'grey'
                
            fig.add_trace(go.Scatter(
                x=year_data['day_of_year'],
                y=y_vals,
                mode='lines',
                name=f"{year} Forecast",
                line=dict(color=color, width=3, dash='dot'),
                hovertemplate=f"Forecast {year}<br>Day: %{{x}}<br>Value: %{{y:.2f}}<extra></extra>"
            ))
            
    fig.update_layout(
        title=title + (" (Normalized %)" if normalize else ""),
        xaxis_title="Day of Year",
        yaxis_title=target_col + (" (%)" if normalize else ""),
        template="plotly_white",
        hovermode="x unified"
    )
    
    month_starts = [1, 32, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335]
    month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    
    fig.update_xaxes(tickmode='array', tickvals=month_starts, ticktext=month_names)
    return fig

def plot_fan_chart_interactive(
    historical_df: pd.DataFrame,
    forecast_df: pd.DataFrame,
    date_col: str,
    target_col: str,
    title: str = "Forecast Fan Chart"
) -> go.Figure:
    """
    Creates an interactive fan chart showing historical data, forecast, and confidence intervals.
    """
    fig = go.Figure()
    
    # Historical
    fig.add_trace(go.Scatter(
        x=historical_df[date_col], y=historical_df[target_col],
        mode='lines', name='Historical', line=dict(color='black', width=1.5)
    ))
    
    # Forecast Central
    fig.add_trace(go.Scatter(
        x=forecast_df[date_col], y=forecast_df['predicted'],
        mode='lines', name='Forecast', line=dict(color='blue', width=2, dash='dash')
    ))
    
    # Confidence Intervals
    if 'lower_ci' in forecast_df.columns and 'upper_ci' in forecast_df.columns:
        fig.add_trace(go.Scatter(
            x=pd.concat([forecast_df[date_col], forecast_df[date_col][::-1]]),
            y=pd.concat([forecast_df['upper_ci'], forecast_df['lower_ci'][::-1]]),
            fill='toself', fillcolor='rgba(0,0,255,0.2)',
            line=dict(color='rgba(255,255,255,0)'),
            name='90% Confidence Interval', showlegend=True
        ))
        
    fig.update_layout(title=title, xaxis_title="Date", yaxis_title=target_col, template="plotly_white", hovermode="x unified")
    return fig

def plot_decomposition_interactive(result_stl, title: str = "STL Decomposition") -> go.Figure:
    """Interactive plot for STL Decomposition results."""
    observed = result_stl.observed
    trend = result_stl.trend
    seasonal = result_stl.seasonal
    resid = result_stl.resid
    
    fig = make_subplots(rows=4, cols=1, shared_xaxes=True, subplot_titles=("Observed", "Trend", "Seasonal", "Residuals"), vertical_spacing=0.05)
    
    fig.add_trace(go.Scatter(x=observed.index, y=observed, name='Observed', line=dict(color='black')), row=1, col=1)
    fig.add_trace(go.Scatter(x=trend.index, y=trend, name='Trend', line=dict(color='blue')), row=2, col=1)
    fig.add_trace(go.Scatter(x=seasonal.index, y=seasonal, name='Seasonal', line=dict(color='green')), row=3, col=1)
    fig.add_trace(go.Scatter(x=resid.index, y=resid, name='Residuals', mode='markers', marker=dict(color='gray', size=3)), row=4, col=1)
    fig.add_hline(y=0, line_dash="dash", line_color="black", row=4, col=1)
    
    fig.update_layout(title=title, height=800, template="plotly_white")
    return fig

def create_forecast_dashboard(
    historical_df: pd.DataFrame,
    forecast_df: pd.DataFrame,
    date_col: str,
    target_col: str,
    residuals: Optional[np.ndarray] = None,
    title: str = "Forecast Dashboard"
) -> go.Figure:
    """
    Creates a comprehensive 2x2 dashboard:
    1. Forecast Fan Chart (Main)
    2. Residuals over Time
    3. Residuals Histogram
    4. Residuals ACF
    """
    fig = make_subplots(
        rows=2, cols=2,
        column_widths=[0.7, 0.3],
        row_heights=[0.5, 0.5],
        specs=[[{"colspan": 2}, None], [{}, {}]],
        subplot_titles=("Forecast & History", "Residual Diagnostics (ACF)", "Residual Histogram")
    )
    
    # 1. Fan Chart (Top, spanning both cols)
    # Historical
    fig.add_trace(go.Scatter(x=historical_df[date_col], y=historical_df[target_col], mode='lines', name='History', line=dict(color='black')), row=1, col=1)
    # Forecast
    fig.add_trace(go.Scatter(x=forecast_df[date_col], y=forecast_df['predicted'], mode='lines', name='Forecast', line=dict(color='blue', dash='dash')), row=1, col=1)
    # CI
    if 'lower_ci' in forecast_df.columns:
        fig.add_trace(go.Scatter(
            x=pd.concat([forecast_df[date_col], forecast_df[date_col][::-1]]),
            y=pd.concat([forecast_df['upper_ci'], forecast_df['lower_ci'][::-1]]),
            fill='toself', fillcolor='rgba(0,0,255,0.2)', line=dict(width=0), name='CI', showlegend=True
        ), row=1, col=1)
        
    # If residuals provided, plot diagnostics
    if residuals is not None and len(residuals) > 0:
        resid = residuals[~np.isnan(residuals)]
        
        # 2. ACF (Bottom Left)
        acf_vals = acf(resid, nlags=20, fft=True)
        lags = np.arange(len(acf_vals))
        fig.add_trace(go.Bar(x=lags, y=acf_vals, name='ACF', marker_color='gray'), row=2, col=1)
        conf = 1.96 / np.sqrt(len(resid))
        fig.add_shape(type="line", x0=0, x1=20, y0=conf, y1=conf, line=dict(color="red", dash="dot"), row=2, col=1)
        fig.add_shape(type="line", x0=0, x1=20, y0=-conf, y1=-conf, line=dict(color="red", dash="dot"), row=2, col=1)
        
        # 3. Histogram (Bottom Right)
        fig.add_trace(go.Histogram(x=resid, name='Resid Dist', marker_color='purple', opacity=0.7), row=2, col=2)
        
    else:
        # Placeholder if no residuals
        fig.add_annotation(text="No Residuals Available", showarrow=False, row=2, col=1)
        
    fig.update_layout(title=title, height=800, template="plotly_white")
    return fig
