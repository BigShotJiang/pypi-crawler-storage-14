"""
Commodity trading specific analysis tools.

Includes:
- Spread Cointegration (Pairs Trading)
- Volatility Cones (Option Pricing / Risk)
- Seasonal Heatmaps
- Term Structure Analysis (Contango/Backwardation)
"""

from __future__ import annotations

from typing import Tuple, Dict, Optional, List, Union
import pandas as pd
import numpy as np
from scipy import stats
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from statsmodels.tsa.stattools import adfuller
from sklearn.linear_model import LinearRegression

def analyze_spread_cointegration(
    df: pd.DataFrame,
    date_col: str,
    asset1: str,
    asset2: str,
    window: Optional[int] = None
) -> Tuple[Dict[str, float], go.Figure]:
    """
    Analyzes the cointegration and spread between two assets (e.g., Crude vs Gasoline).
    Calculates Hedge Ratio via OLS.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    date_col : str
        Date column.
    asset1 : str
        Dependent variable (Y).
    asset2 : str
        Independent variable (X).
    window : int, optional
        If provided, calculates rolling Z-score of the spread.
        
    Returns
    -------
    (Dict, go.Figure)
        Metrics (Hedge Ratio, ADF p-value) and Spread Plot.
    """
    data = df[[date_col, asset1, asset2]].dropna().sort_values(date_col)
    y = data[asset1].values.reshape(-1, 1)
    x = data[asset2].values.reshape(-1, 1)
    
    # OLS for Hedge Ratio
    model = LinearRegression(fit_intercept=False) # Generally no intercept for pairs
    model.fit(x, y)
    hedge_ratio = model.coef_[0][0]
    
    # Spread
    spread = data[asset1] - hedge_ratio * data[asset2]
    
    # Stationarity of Spread
    adf = adfuller(spread)
    is_stationary = adf[1] < 0.05
    
    # Z-Score
    if window:
        roll_mean = spread.rolling(window).mean()
        roll_std = spread.rolling(window).std()
        z_score = (spread - roll_mean) / roll_std
    else:
        z_score = (spread - spread.mean()) / spread.std()
        
    metrics = {
        'Hedge_Ratio': hedge_ratio,
        'ADF_p_value': adf[1],
        'Is_Stationary': is_stationary,
        'Current_Z_Score': z_score.iloc[-1]
    }
    
    # Plot
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05, subplot_titles=("Asset Prices", "Spread Z-Score"))
    
    # Top: Prices
    fig.add_trace(go.Scatter(x=data[date_col], y=data[asset1], name=asset1), row=1, col=1)
    # Normalize asset2 to scale for visualization only? Or plot on secondary axis.
    # Let's just plot scaled asset2
    fig.add_trace(go.Scatter(x=data[date_col], y=data[asset2] * hedge_ratio, name=f"{hedge_ratio:.2f} * {asset2}"), row=1, col=1)
    
    # Bottom: Spread Z-Score
    fig.add_trace(go.Scatter(x=data[date_col], y=z_score, name='Spread Z-Score', line=dict(color='black')), row=2, col=1)
    # Add bands
    fig.add_hline(y=2, line_dash="dot", line_color="red", row=2, col=1)
    fig.add_hline(y=-2, line_dash="dot", line_color="green", row=2, col=1)
    fig.add_hline(y=0, line_color="gray", row=2, col=1)
    
    fig.update_layout(title=f"Spread Analysis: {asset1} vs {asset2}")
    
    return metrics, fig

def plot_volatility_cones(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    windows: List[int] = [10, 30, 60, 90],
    quantiles: List[float] = [0.25, 0.75]
) -> go.Figure:
    """
    Plots Volatility Cones to visualize if current realized volatility is 
    cheap or expensive compared to historical range for different horizons.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input data.
    target_col : str
        Price column (will calculate log returns).
    windows : List[int]
        Horizons (days) to calculate realized volatility.
        
    Returns
    -------
    go.Figure
        Volatility Cone plot.
    """
    data = df[[date_col, target_col]].dropna().sort_values(date_col)
    returns = np.log(data[target_col]).diff()
    
    stats_data = []
    current_vols = []
    
    for w in windows:
        # Annualized Realized Volatility
        # sqrt(252) * std(returns)
        rv = returns.rolling(w).std() * np.sqrt(252)
        
        # Current value (last available)
        curr = rv.iloc[-1]
        current_vols.append(curr)
        
        # Historical stats
        valid_rv = rv.dropna()
        min_v = valid_rv.min()
        max_v = valid_rv.max()
        median_v = valid_rv.median()
        q1 = valid_rv.quantile(quantiles[0])
        q2 = valid_rv.quantile(quantiles[1])
        
        stats_data.append({
            'Window': w,
            'Min': min_v,
            'Max': max_v,
            'Median': median_v,
            'Q1': q1,
            'Q2': q2,
            'Current': curr
        })
        
    stats_df = pd.DataFrame(stats_data)
    
    fig = go.Figure()
    
    # Plot Max
    fig.add_trace(go.Scatter(x=stats_df['Window'], y=stats_df['Max'], mode='lines+markers', name='Max', line=dict(color='red', dash='dash')))
    
    # Plot Q2 (High/75th)
    fig.add_trace(go.Scatter(x=stats_df['Window'], y=stats_df['Q2'], mode='lines', name=f'{int(quantiles[1]*100)}th Pctl', line=dict(color='orange', width=1)))
    
    # Plot Median
    fig.add_trace(go.Scatter(x=stats_df['Window'], y=stats_df['Median'], mode='lines+markers', name='Median', line=dict(color='gray', width=2)))
    
    # Plot Q1 (Low/25th)
    fig.add_trace(go.Scatter(x=stats_df['Window'], y=stats_df['Q1'], mode='lines', name=f'{int(quantiles[0]*100)}th Pctl', line=dict(color='green', width=1)))
    
    # Plot Min
    fig.add_trace(go.Scatter(x=stats_df['Window'], y=stats_df['Min'], mode='lines+markers', name='Min', line=dict(color='green', dash='dash')))
    
    # Plot Current
    fig.add_trace(go.Scatter(x=stats_df['Window'], y=stats_df['Current'], mode='lines+markers', name='Current Vol', line=dict(color='blue', width=4)))
    
    fig.update_layout(
        title=f"Volatility Cones: {target_col}",
        xaxis_title="Horizon (Days)",
        yaxis_title="Annualized Volatility",
        xaxis=dict(tickvals=windows, ticktext=[f"{w}D" for w in windows])
    )
    
    return fig

def plot_seasonal_heatmap(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    metric: str = 'mean' # 'mean' or 'return'
) -> go.Figure:
    """
    Creates a heatmap of Month vs Year to spot seasonal patterns/anomalies.
    """
    data = df.copy()
    data[date_col] = pd.to_datetime(data[date_col])
    data['year'] = data[date_col].dt.year
    data['month'] = data[date_col].dt.month_name()
    # Ensure correct month order
    month_order = ['January', 'February', 'March', 'April', 'May', 'June', 
                   'July', 'August', 'September', 'October', 'November', 'December']
    
    if metric == 'return':
        # Calculate monthly returns
        # First resample to month end
        monthly = data.set_index(date_col)[target_col].resample('M').last().pct_change()
        # Re-extract year/month from resampled index
        pivot_data = pd.DataFrame({'val': monthly})
        pivot_data['year'] = pivot_data.index.year
        pivot_data['month'] = pivot_data.index.month_name()
        title = f"Monthly Returns Heatmap: {target_col}"
    else:
        # Average price
        pivot_data = data.groupby(['year', 'month'])[target_col].mean().reset_index(name='val')
        title = f"Average Monthly Price Heatmap: {target_col}"
        
    # Pivot
    grid = pivot_data.pivot(index='year', columns='month', values='val')
    # Reindex columns
    grid = grid.reindex(columns=month_order)
    
    fig = go.Figure(data=go.Heatmap(
        z=grid.values,
        x=grid.columns,
        y=grid.index,
        colorscale='RdBu_r' if metric == 'return' else 'Viridis',
        zmid=0 if metric == 'return' else None
    ))
    
    fig.update_layout(title=title)
    return fig

def analyze_term_structure(
    df: pd.DataFrame,
    date_col: str,
    front_col: str,
    back_col: str,
    months_diff: int = 1
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Analyzes the term structure (Contango vs Backwardation).
    Calculates the annualized roll yield proxy.
    
    Parameters
    ----------
    front_col : str
        Nearest contract price.
    back_col : str
        Deferred contract price.
    months_diff : int
        Number of months between contracts (e.g., 1 for M1-M2).
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame with spread/roll_yield and plot.
    """
    data = df[[date_col, front_col, back_col]].dropna().sort_values(date_col)
    
    # Spread
    data['spread'] = data[front_col] - data[back_col]
    
    # Roll Yield Proxy (Annualized)
    # (Front - Back) / Front * (12 / diff) ?
    # Strictly: ln(Front / Back) * (12 / diff)
    # If Front < Back (Contango), yield is negative (cost to roll).
    # If Front > Back (Backwardation), yield is positive.
    
    data['roll_yield'] = np.log(data[front_col] / data[back_col]) * (12 / months_diff)
    
    # Percentiles
    ry = data['roll_yield']
    current_ry = ry.iloc[-1]
    percentile = stats.percentileofscore(ry, current_ry)
    
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True)
    
    # Plot Spread
    fig.add_trace(go.Scatter(x=data[date_col], y=data['spread'], name='Spread (Front-Back)', fill='tozeroy'), row=1, col=1)
    
    # Plot Roll Yield
    fig.add_trace(go.Scatter(x=data[date_col], y=data['roll_yield'], name='Roll Yield (Ann.)', line=dict(color='purple')), row=2, col=1)
    fig.add_hline(y=0, row=2, col=1, line_color='black')
    
    fig.update_layout(title=f"Term Structure Analysis: {front_col} vs {back_col} (Current Yield: {current_ry:.1%}, {int(percentile)}th %ile)")
    
    return data, fig
