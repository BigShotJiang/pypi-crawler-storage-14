"""
Ensemble forecasting utilities.

This module provides tools to combine multiple forecasts into a robust
consensus prediction, often yielding better accuracy than individual models.
"""

from __future__ import annotations

from typing import List, Dict, Optional, Union
import pandas as pd
import numpy as np
import plotly.graph_objects as go

from .forecasting import ForecastingResult, _plot_forecast, _create_interactive_plot

def forecast_ensemble(
    results: List[ForecastingResult],
    method: str = 'mean',
    weights: Optional[List[float]] = None
) -> ForecastingResult:
    """
    Combines multiple ForecastingResult objects into a single ensemble forecast.
    
    Parameters
    ----------
    results : List[ForecastingResult]
        List of results from other forecast functions (e.g., RF, Chronos, Prophet).
        Must have matching prediction dates.
    method : str
        'mean' (average), 'median' (robust average), or 'weighted'.
    weights : List[float], optional
        Weights for 'weighted' method. Must sum to 1 (normalized automatically if not).
        
    Returns
    -------
    ForecastingResult
        The ensemble result.
    """
    if not results:
        raise ValueError("No results provided for ensemble.")
        
    # Validate consistency (dates)
    base_dates = results[0].forecast['date']
    for res in results[1:]:
        if not res.forecast['date'].equals(base_dates):
            raise ValueError("Forecasts must have matching dates/frequencies for ensemble.")
            
    # Extract predictions
    preds = np.array([r.forecast['predicted'].values for r in results]) # shape: (n_models, n_steps)
    
    if method == 'mean':
        ensemble_pred = np.mean(preds, axis=0)
    elif method == 'median':
        ensemble_pred = np.median(preds, axis=0)
    elif method == 'weighted':
        if weights is None:
            raise ValueError("Weights must be provided for weighted method.")
        if len(weights) != len(results):
            raise ValueError("Number of weights must match number of results.")
        
        w = np.array(weights)
        w = w / w.sum() # Normalize
        ensemble_pred = np.average(preds, axis=0, weights=w)
    else:
        raise ValueError(f"Unknown method: {method}")
        
    # Combine Confidence Intervals (Mixture Distribution approx)
    # Simple approach: Average of bounds (if available), or min/max of bounds?
    # A robust conservative approach: Min of lowers, Max of uppers (Full Envelope)
    # Or Average of bounds (Soft Envelope).
    # Let's use Soft Envelope (Average of CIs) assuming models are calibrated.
    
    lowers = []
    uppers = []
    for r in results:
        if 'lower_ci' in r.forecast.columns:
            lowers.append(r.forecast['lower_ci'].values)
        else:
            # If no CI, assume point estimate (risk of underestimating uncertainty)
            lowers.append(r.forecast['predicted'].values)
            
        if 'upper_ci' in r.forecast.columns:
            uppers.append(r.forecast['upper_ci'].values)
        else:
            uppers.append(r.forecast['predicted'].values)
            
    ensemble_lower = np.mean(lowers, axis=0)
    ensemble_upper = np.mean(uppers, axis=0)
    
    forecast_df = pd.DataFrame({
        'date': base_dates,
        'predicted': ensemble_pred,
        'lower_ci': ensemble_lower,
        'upper_ci': ensemble_upper
    })
    
    # Create Plot
    # Use the first model's historical data for context (assuming same source)
    # We can't easily access original df here unless passed.
    # We will create a generic plot based on the forecast only if historical not available?
    # Actually, ForecastingResult doesn't store history.
    # We will produce a plot of the ensemble components vs the mean.
    
    fig = go.Figure()
    
    # Plot individual models
    for i, res in enumerate(results):
        name = f"Model {i+1}"
        if hasattr(res.model, '__class__'):
            name = res.model.__class__.__name__
            
        fig.add_trace(go.Scatter(
            x=res.forecast['date'], 
            y=res.forecast['predicted'],
            mode='lines',
            name=f"{name} (Individual)",
            line=dict(width=1, dash='dot'),
            opacity=0.5
        ))
        
    # Plot Ensemble
    fig.add_trace(go.Scatter(
        x=forecast_df['date'],
        y=forecast_df['predicted'],
        mode='lines',
        name=f'Ensemble ({method})',
        line=dict(color='black', width=3)
    ))
    
    # Fan (Ensemble CI)
    fig.add_trace(go.Scatter(
        x=pd.concat([forecast_df['date'], forecast_df['date'][::-1]]),
        y=pd.concat([forecast_df['upper_ci'], forecast_df['lower_ci'][::-1]]),
        fill='toself',
        fillcolor='rgba(0,0,0,0.1)',
        line=dict(color='rgba(255,255,255,0)'),
        name='Ensemble CI',
        showlegend=True
    ))
    
    fig.update_layout(title="Ensemble Forecast", xaxis_title="Date", yaxis_title="Value")
    
    return ForecastingResult(
        forecast=forecast_df,
        model=f"Ensemble ({method})",
        metrics={},
        figure=None, # Static plot not generated without history context easily
        figure_interactive=fig
    )
