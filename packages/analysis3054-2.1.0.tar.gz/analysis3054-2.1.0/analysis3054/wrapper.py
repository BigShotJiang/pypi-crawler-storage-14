"""
The Unified API for analysis3054.

This module provides the `TimeSeriesLab` class, a high-level, fluent interface
that integrates all the package's functionality into a single, easy-to-use object.
"""

from __future__ import annotations

from typing import Optional, List, Dict, Union, Any
import pandas as pd
import numpy as np
import plotly.graph_objects as go

# Imports from other modules
from .plot import five_year_plot
from .plot_interactive import (
    plot_yearly_comparison_interactive, plot_fan_chart_interactive, 
    plot_decomposition_interactive, create_forecast_dashboard
)
from .forecasting import (
    forecast_random_forest, forecast_xgboost, forecast_svm, 
    forecast_elastic_net, forecast_sarimax, ForecastingResult
)
from .forecasting_advanced import (
    forecast_chronos, forecast_lstm_probabilistic, 
    forecast_stl_decomposition, forecast_var_multivariate, forecast_prophet_robust
)
from .analysis import (
    analyze_granger_causality, detect_structural_breaks, 
    analyze_cross_correlation, detect_anomalies_isolation_forest
)
from .diagnostics import plot_residual_diagnostics, backtest_rolling_window
from .clustering import cluster_time_series
from .stats_advanced import test_stationarity_comprehensive
from .signal import decompose_singular_spectrum, analyze_wavelet_spectrum
from .commodities import analyze_spread_cointegration, plot_volatility_cones, plot_seasonal_heatmap, analyze_term_structure

class TimeSeriesLab:
    """
    The Production-Ready Time Series Laboratory.
    
    This class wraps a dataframe and provides a fluent API for cleaning,
    plotting, analyzing, and forecasting.
    
    Parameters
    ----------
    df : pd.DataFrame
        The input dataframe.
    date_col : str
        Name of the date column.
    target_col : str, optional
        Name of the primary target column.
    """
    
    def __init__(self, df: pd.DataFrame, date_col: str = 'date', target_col: str = 'value'):
        self.df = df.copy()
        self.date_col = date_col
        self.target_col = target_col
        
        # Ensure date is datetime and sorted
        self.df[self.date_col] = pd.to_datetime(self.df[self.date_col])
        self.df = self.df.sort_values(self.date_col).reset_index(drop=True)
        
        self.results: Dict[str, Any] = {}
        
    def plot(self, interactive: bool = True, yearly_compare: bool = False, normalize: bool = False) -> TimeSeriesLab:
        """Plots the target series."""
        if yearly_compare:
            fig = plot_yearly_comparison_interactive(self.df, self.date_col, self.target_col, normalize=normalize)
        elif interactive:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=self.df[self.date_col], y=self.df[self.target_col], mode='lines', name=self.target_col))
            fig.update_layout(title=f"Time Series: {self.target_col}")
        else:
            # Static
            fig = five_year_plot(self.df[self.date_col], self.df)
            
        fig.show()
        return self
    
    def clean(self, fill_method: str = 'interpolate') -> TimeSeriesLab:
        """Basic cleaning of the target column."""
        if fill_method == 'interpolate':
            self.df[self.target_col] = self.df[self.target_col].interpolate()
        elif fill_method == 'ffill':
            self.df[self.target_col] = self.df[self.target_col].ffill()
        
        self.df = self.df.dropna(subset=[self.target_col])
        print(f"Cleaned {self.target_col}. Current length: {len(self.df)}")
        return self
    
    def check_health(self) -> TimeSeriesLab:
        """Runs stationarity and anomaly checks."""
        print("--- Health Check ---")
        
        # Stationarity
        stat_res = test_stationarity_comprehensive(self.df[self.target_col])
        print(f"Stationarity: {stat_res['Conclusion']}")
        
        # Anomalies
        anomalies, _ = detect_anomalies_isolation_forest(self.df, self.date_col, self.target_col)
        print(f"Anomalies Detected: {len(anomalies)}")
        
        return self
    
    def forecast(
        self, 
        model: str = 'random_forest', 
        prediction_start: Optional[str] = None,
        steps: int = 30,
        **kwargs
    ) -> ForecastingResult:
        """
        Runs a forecast using the specified model.
        
        Models: 'random_forest', 'xgboost', 'prophet', 'chronos', 'sarimax', 'lstm', 'elastic_net', 'svm'.
        """
        if prediction_start is None:
            last_date = self.df[self.date_col].max()
            prediction_start = last_date
            
            future_dates = pd.date_range(start=last_date + pd.Timedelta(days=1), periods=steps, freq=pd.infer_freq(self.df[self.date_col]))
            future_df = pd.DataFrame({self.date_col: future_dates})
            extended_df = pd.concat([self.df, future_df], ignore_index=True)
            df_to_use = extended_df
        else:
            df_to_use = self.df
            
        model_map = {
            'random_forest': forecast_random_forest,
            'xgboost': forecast_xgboost,
            'svm': forecast_svm,
            'elastic_net': forecast_elastic_net,
            'sarimax': forecast_sarimax,
            'chronos': forecast_chronos,
            'prophet': forecast_prophet_robust,
            'lstm': forecast_lstm_probabilistic,
            'stl': forecast_stl_decomposition
        }
        
        if model not in model_map:
            raise ValueError(f"Model {model} not found. Options: {list(model_map.keys())}")
            
        print(f"Running {model} forecast from {prediction_start}...")
        result = model_map[model](
            df=df_to_use,
            date_col=self.date_col,
            target_col=self.target_col,
            prediction_start=prediction_start,
            **kwargs
        )
        
        self.results[f'forecast_{model}'] = result
        self.last_forecast = result # Store last result for dashboard
        return result
    
    def dashboard(self) -> TimeSeriesLab:
        """Displays a comprehensive dashboard for the most recent forecast."""
        if not hasattr(self, 'last_forecast'):
            raise ValueError("Run a forecast first before viewing dashboard.")
            
        res = self.last_forecast
        
        # Try to extract residuals from model if possible, else None
        residuals = None
        if hasattr(res.model, 'resid'):
            residuals = res.model.resid.values if hasattr(res.model.resid, 'values') else res.model.resid
            
        fig = create_forecast_dashboard(
            historical_df=self.df,
            forecast_df=res.forecast,
            date_col=self.date_col,
            target_col=self.target_col,
            residuals=residuals,
            title=f"Forecast Dashboard"
        )
        fig.show()
        return self
    
    def backtest(self, model: str = 'random_forest', **kwargs) -> TimeSeriesLab:
        """Runs a rolling backtest on the specified model."""
        
        model_map = {
            'random_forest': forecast_random_forest,
            'xgboost': forecast_xgboost,
            'prophet': forecast_prophet_robust,
            'sarimax': forecast_sarimax
        }
        
        if model not in model_map:
            raise ValueError(f"Backtest supported for: {list(model_map.keys())}")
            
        res_df, fig = backtest_rolling_window(
            self.df, self.date_col, self.target_col,
            forecast_func=model_map[model],
            **kwargs
        )
        fig.show()
        return self
    
    def analyze(self, analysis_type: str = 'decomposition', **kwargs) -> TimeSeriesLab:
        """Runs analysis: 'decomposition', 'causality', 'breaks', 'wavelet'."""
        
        if analysis_type == 'decomposition':
            res = forecast_stl_decomposition(self.df, self.date_col, self.target_col, self.df[self.date_col].iloc[-1])
            fig = plot_decomposition_interactive(res.model)
            fig.show()
            
        elif analysis_type == 'breaks':
            _, fig = detect_structural_breaks(self.df, self.date_col, self.target_col, **kwargs)
            fig.show()
            
        elif analysis_type == 'wavelet':
            _, fig = analyze_wavelet_spectrum(self.df[self.target_col], **kwargs)
            fig.show()
            
        return self

    def analyze_commodities(self, type: str, **kwargs) -> TimeSeriesLab:
        """
        Runs commodity-specific analysis.
        """
        if type == 'spread':
            metrics, fig = analyze_spread_cointegration(self.df, self.date_col, self.target_col, kwargs.get('asset2'))
            print(metrics)
            fig.show()
        elif type == 'volatility':
            fig = plot_volatility_cones(self.df, self.date_col, self.target_col)
            fig.show()
        elif type == 'seasonality':
            fig = plot_seasonal_heatmap(self.df, self.date_col, self.target_col)
            fig.show()
        elif type == 'term_structure':
            _, fig = analyze_term_structure(self.df, self.date_col, kwargs.get('front_col'), kwargs.get('back_col'))
            fig.show()
        else:
            raise ValueError(f"Unknown commodity analysis type: {type}")
            
        return self
