"""
Forecasting functions using various ML and statistical methods with rigorous methodology.

This module provides a set of robust forecasting functions that handle
covariates, perform automatic cleaning, feature engineering, hyperparameter
optimization, and uncertainty quantification.

Functions included:
- forecast_random_forest
- forecast_xgboost
- forecast_svm
- forecast_elastic_net
- forecast_sarimax
- generate_scenarios_bootstrap
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple, List, Any, Dict
import warnings

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import plotly.graph_objects as go

from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.linear_model import ElasticNet
from sklearn.preprocessing import StandardScaler, OneHotEncoder, RobustScaler
from sklearn.impute import SimpleImputer, KNNImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import TimeSeriesSplit, RandomizedSearchCV

try:
    from xgboost import XGBRegressor
except ImportError:
    XGBRegressor = None

try:
    import statsmodels.api as sm
    from statsmodels.tsa.statespace.sarimax import SARIMAX
except ImportError:
    SARIMAX = None

from .plot_interactive import plot_fan_chart_interactive

@dataclass
class ForecastingResult:
    """
    Container for forecasting results.
    
    Attributes
    ----------
    forecast : pd.DataFrame
        DataFrame with date, predicted, lower_ci, upper_ci (if available).
    model : object
        The trained model object (or best estimator).
    metrics : dict
        Dictionary of performance metrics on training/validation data.
    figure : matplotlib.figure.Figure
        The plot of the forecast.
    figure_interactive : Optional[go.Figure]
        Interactive Plotly figure of the forecast.
    """
    forecast: pd.DataFrame
    model: Any
    metrics: dict
    figure: Any
    figure_interactive: Optional[Any] = None


def _add_cyclical_features(df: pd.DataFrame, date_col: str) -> pd.DataFrame:
    """Adds sine/cosine transforms for cyclical time features."""
    df = df.copy()
    dates = pd.to_datetime(df[date_col])
    
    # Month (1-12)
    df['month_sin'] = np.sin(2 * np.pi * dates.dt.month / 12)
    df['month_cos'] = np.cos(2 * np.pi * dates.dt.month / 12)
    
    # Day of year (1-365)
    df['doy_sin'] = np.sin(2 * np.pi * dates.dt.dayofyear / 365.25)
    df['doy_cos'] = np.cos(2 * np.pi * dates.dt.dayofyear / 365.25)
    
    # Day of week (0-6)
    df['dow_sin'] = np.sin(2 * np.pi * dates.dt.dayofweek / 7)
    df['dow_cos'] = np.cos(2 * np.pi * dates.dt.dayofweek / 7)
    
    return df

def _prepare_data(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.DataFrame, List[str]]:
    """
    Internal helper to prepare data for forecasting with robust cleaning and engineering.
    """
    # Ensure date is datetime
    data = df.copy()
    data[date_col] = pd.to_datetime(data[date_col])
    data = data.sort_values(date_col)
    
    prediction_start_dt = pd.to_datetime(prediction_start)
    
    # Split into historical and future
    historical = data[data[date_col] < prediction_start_dt].copy()
    future = data[data[date_col] >= prediction_start_dt].copy()
    
    if historical.empty:
        raise ValueError(f"No data found before prediction_start {prediction_start}")
    if future.empty:
        raise ValueError(f"No data found on or after prediction_start {prediction_start}")
        
    # Target
    y_train = historical[target_col]
    
    # Feature Engineering
    # 1. Add cyclical time features
    historical = _add_cyclical_features(historical, date_col)
    future = _add_cyclical_features(future, date_col)
    
    # 2. Identify covariates
    # Exclude target and date
    exclude_cols = [date_col, target_col]
    potential_covariates = [c for c in historical.columns if c not in exclude_cols]
    
    valid_covariates = []
    for col in potential_covariates:
        # Check if future has this column (it should, as covariates)
        if col in future.columns:
             valid_covariates.append(col)
             
    X_train = historical[valid_covariates].copy()
    X_future = future[valid_covariates].copy()
    
    # 3. Handling Numeric vs Categorical
    numeric_cols = X_train.select_dtypes(include=['number']).columns
    categorical_cols = X_train.select_dtypes(exclude=['number']).columns
    
    # 4. Imputation & Scaling Pipeline
    # We use RobustScaler to be resilient to outliers
    # We use KNNImputer for numeric (more sophisticated than mean)
    # We use SimpleImputer(constant) + OneHot for categorical
    
    # Combine for consistent encoding
    combined_X = pd.concat([X_train, X_future], axis=0)
    
    # Preprocessing pipeline
    numeric_transformer = Pipeline(steps=[
        ('imputer', KNNImputer(n_neighbors=5)),
        ('scaler', RobustScaler())
    ])
    
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_cols),
            ('cat', categorical_transformer, categorical_cols)
        ],
        verbose_feature_names_out=False
    )
    
    # Fit on combined to ensure all categories are captured (or fit on train?)
    # Strictly speaking, we should fit on train. But for OHE, we want to know future cats.
    # We will fit on train and handle unknown in future.
    
    X_train_processed = preprocessor.fit_transform(X_train)
    X_future_processed = preprocessor.transform(X_future)
    
    # Get feature names
    try:
        feature_names = preprocessor.get_feature_names_out()
    except AttributeError:
        # Fallback for older sklearn
        feature_names = [f"feat_{i}" for i in range(X_train_processed.shape[1])]

    X_train_df = pd.DataFrame(X_train_processed, columns=feature_names, index=X_train.index)
    X_future_df = pd.DataFrame(X_future_processed, columns=feature_names, index=X_future.index)

    return X_train_df, X_future_df, y_train, future[date_col], list(feature_names)

def _plot_forecast(
    historical_dates, historical_y, future_dates, predicted_y, 
    lower_ci=None, upper_ci=None, title="", target_col="Value"
):
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Plot historical
    ax.plot(historical_dates, historical_y, label='Historical Actual', color='black', linewidth=1.5)
    
    # Plot forecast
    ax.plot(future_dates, predicted_y, label='Forecast', color='blue', linewidth=2, linestyle='--')
    
    # Plot CI
    if lower_ci is not None and upper_ci is not None:
        ax.fill_between(future_dates, lower_ci, upper_ci, color='blue', alpha=0.2, label='95% CI')
        
    ax.set_title(title, fontsize=14)
    ax.set_xlabel('Date')
    ax.set_ylabel(target_col)
    ax.legend(loc='upper left')
    ax.grid(True, alpha=0.3)
    
    # Format date axis
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    fig.autofmt_xdate()
    
    return fig

def _create_interactive_plot(
    historical_dates, historical_y, forecast_df, date_col, target_col, title
) -> go.Figure:
    hist_df = pd.DataFrame({date_col: historical_dates, target_col: historical_y})
    return plot_fan_chart_interactive(hist_df, forecast_df, date_col, target_col, title)

def _bootstrap_prediction_intervals(
    model, X_train, y_train, X_future, n_bootstraps=100, alpha=0.05
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generates prediction intervals using residual bootstrapping.
    This assumes the model errors are homoscedastic and uncorrelated, which is a simplification
    but robust enough for general purpose ML models that don't output variance.
    """
    # 1. Fit model on all data
    model.fit(X_train, y_train)
    preds_train = model.predict(X_train)
    residuals = y_train - preds_train
    
    preds_future = model.predict(X_future)
    
    bootstrap_preds = []
    
    # 2. Bootstrap residuals
    np.random.seed(42)
    for _ in range(n_bootstraps):
        # Resample residuals
        boot_resids = np.random.choice(residuals, size=len(y_train), replace=True)
        y_train_boot = preds_train + boot_resids
        
        # Refit model (this can be expensive, so we use a lighter version if possible or just assume parameter stability)
        # To be truly "robust"/PhD level, we should refit. 
        # Cloning the model to ensure fresh start
        from sklearn.base import clone
        model_boot = clone(model)
        model_boot.fit(X_train, y_train_boot)
        
        bootstrap_preds.append(model_boot.predict(X_future))
        
    bootstrap_preds = np.array(bootstrap_preds)
    
    # 3. Calculate percentiles
    lower = np.percentile(bootstrap_preds, 100 * (alpha / 2), axis=0)
    upper = np.percentile(bootstrap_preds, 100 * (1 - alpha / 2), axis=0)
    
    # Add the residual noise to the future prediction uncertainty? 
    # The above captures *model uncertainty*. We also need *aleatoric uncertainty* (noise).
    # We can estimate noise std dev from residuals.
    noise_std = np.std(residuals)
    
    # Adjust bounds to include noise variance
    lower = lower - 1.96 * noise_std
    upper = upper + 1.96 * noise_std
    
    return lower, upper

def generate_scenarios_bootstrap(
    result: ForecastingResult,
    n_scenarios: int = 100,
    block_size: int = 10
) -> Tuple[pd.DataFrame, go.Figure]:
    """
    Generates synthetic future scenarios by bootstrapping residuals from a fitted model.
    Uses block bootstrapping to preserve some serial correlation in errors.
    
    Parameters
    ----------
    result : ForecastingResult
        A result object containing a fitted model and forecast.
        Note: Only works for models where we can extract residuals (e.g., SARIMAX, or if we computed them).
        For generic models, we need training data residuals.
    n_scenarios : int
        Number of paths to generate.
    block_size : int
        Size of block for bootstrapping.
        
    Returns
    -------
    (pd.DataFrame, go.Figure)
        DataFrame with scenarios (cols: Scenario_1, ...) and interactive plot.
    """
    # We need access to residuals. 
    # If model is statsmodels, we have .resid
    # If generic ML, we might not have them stored in ForecastingResult directly.
    # We will assume the user passes a result that has metrics or we need to re-predict on train.
    # ForecastingResult doesn't store X_train/y_train.
    
    # Limitation: We can only do this efficiently if we have residuals.
    # Let's fallback to a simple Gaussian noise simulation based on 'metrics' RMSE if resid not available.
    
    forecast_vals = result.forecast['predicted'].values
    dates = result.forecast['date']
    steps = len(forecast_vals)
    
    residuals = None
    
    # Try to get residuals
    if hasattr(result.model, 'resid'):
        # Statsmodels
        residuals = result.model.resid
        if hasattr(residuals, 'values'): residuals = residuals.values
    elif hasattr(result.model, 'predict_residuals'):
        # Some libraries
        pass
        
    if residuals is None:
        # Fallback: generate normal noise based on RMSE/MAE from training metrics if available
        # Assume RMSE available
        sigma = 1.0
        if 'rmse' in result.metrics:
            sigma = result.metrics['rmse']
        elif 'resid_std' in result.metrics:
            sigma = result.metrics['resid_std']
        else:
            # Rough estimate from CI width if available
            if 'upper_ci' in result.forecast.columns:
                # 95% CI ~ +/- 1.96 sigma
                width = (result.forecast['upper_ci'] - result.forecast['lower_ci']).mean()
                sigma = width / 4.0
                
        # Generate independent noise (no block bootstrap)
        noise = np.random.normal(0, sigma, (steps, n_scenarios))
    else:
        # Block Bootstrap Residuals
        noise = np.zeros((steps, n_scenarios))
        n_resid = len(residuals)
        
        for i in range(n_scenarios):
            # Construct path by stitching blocks
            path_noise = []
            while len(path_noise) < steps:
                # Pick random block start
                start = np.random.randint(0, n_resid - block_size)
                block = residuals[start : start + block_size]
                path_noise.extend(block)
            noise[:, i] = np.array(path_noise[:steps])
            
    # Add noise to mean forecast
    scenarios = forecast_vals[:, None] + noise
    
    scenario_df = pd.DataFrame(scenarios, index=dates, columns=[f"Scenario_{i+1}" for i in range(n_scenarios)])
    
    # Plot
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=dates, y=forecast_vals, mode='lines', name='Base Forecast', line=dict(color='black', width=2)))
    
    # Plot first few scenarios
    for i in range(min(20, n_scenarios)):
        fig.add_trace(go.Scatter(x=dates, y=scenarios[:, i], mode='lines', name=f'Scenario {i+1}', opacity=0.2, line=dict(width=1)))
        
    fig.update_layout(title=f"Monte Carlo Scenarios ({n_scenarios} paths)", showlegend=False)
    
    return scenario_df, fig

# Re-export existing functions
def forecast_random_forest(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    auto_tune: bool = True,
    **kwargs
) -> ForecastingResult:
    """
    Forecast using Random Forest Regressor with optimization and robust interval estimation.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe.
    date_col : str
        Name of date column.
    target_col : str
        Name of target column.
    prediction_start : str
        Date string (YYYY-MM-DD) where prediction starts.
    auto_tune : bool
        If True, performs RandomizedSearchCV for hyperparameters.
    **kwargs
        Additional arguments passed to RandomForestRegressor or grid search.
    """
    try:
        X_train, X_future, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        # Handle missing target
        if y_train.isna().any():
            y_train = y_train.interpolate().bfill().ffill()

        base_model = RandomForestRegressor(random_state=42, n_jobs=-1)
        
        if auto_tune:
            param_dist = {
                'n_estimators': [100, 200, 500],
                'max_depth': [None, 10, 20, 30],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4]
            }
            # Time Series Split for CV
            tscv = TimeSeriesSplit(n_splits=3)
            search = RandomizedSearchCV(
                base_model, param_dist, n_iter=10, scoring='neg_mean_absolute_error',
                cv=tscv, n_jobs=-1, random_state=42
            )
            search.fit(X_train, y_train)
            model = search.best_estimator_
            best_score = -search.best_score_
        else:
            model = RandomForestRegressor(n_estimators=100, random_state=42, **kwargs)
            model.fit(X_train, y_train)
            best_score = np.nan # Not calculated
            
        preds = model.predict(X_future)
        
        # Calculate Confidence Intervals (Bootstrap)
        # Reducing n_bootstraps for speed in production, ideally 100+
        lower, upper = _bootstrap_prediction_intervals(model, X_train, y_train, X_future, n_bootstraps=20)
        
        # Create result df
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': preds,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        # Plot
        hist_dates = df[df[date_col] < prediction_start][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds, lower, upper,
                             f'Random Forest Forecast: {target_col}', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'Random Forest Forecast: {target_col}')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=model,
            metrics={'cv_mae': best_score},
            figure=fig,
            figure_interactive=fig_interactive
        )
    except Exception as e:
        print(f"Error in Random Forest forecasting: {e}")
        raise

def forecast_xgboost(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    auto_tune: bool = True,
    **kwargs
) -> ForecastingResult:
    """
    Forecast using XGBoost with optimization.
    """
    if XGBRegressor is None:
        raise ImportError("xgboost is not installed.")
        
    try:
        X_train, X_future, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        if y_train.isna().any():
            y_train = y_train.interpolate().bfill().ffill()
            
        base_model = XGBRegressor(random_state=42, n_jobs=-1)
        
        if auto_tune:
            param_dist = {
                'n_estimators': [100, 300, 500],
                'learning_rate': [0.01, 0.05, 0.1],
                'max_depth': [3, 5, 7],
                'subsample': [0.7, 0.9, 1.0],
                'colsample_bytree': [0.7, 0.9, 1.0]
            }
            tscv = TimeSeriesSplit(n_splits=3)
            search = RandomizedSearchCV(
                base_model, param_dist, n_iter=10, scoring='neg_mean_absolute_error',
                cv=tscv, n_jobs=-1, random_state=42
            )
            search.fit(X_train, y_train)
            model = search.best_estimator_
            best_score = -search.best_score_
        else:
            model = XGBRegressor(n_estimators=100, random_state=42, **kwargs)
            model.fit(X_train, y_train)
            best_score = np.nan
        
        preds = model.predict(X_future)
        
        # Bootstrap for CIs
        lower, upper = _bootstrap_prediction_intervals(model, X_train, y_train, X_future, n_bootstraps=20)
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': preds,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = df[df[date_col] < prediction_start][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds, lower, upper,
                             f'XGBoost Forecast: {target_col}', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'XGBoost Forecast: {target_col}')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=model,
            metrics={'cv_mae': best_score},
            figure=fig,
            figure_interactive=fig_interactive
        )
    except Exception as e:
        print(f"Error in XGBoost forecasting: {e}")
        raise

def forecast_svm(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    auto_tune: bool = True,
    **kwargs
) -> ForecastingResult:
    """
    Forecast using SVR with robust scaling and optimization.
    """
    try:
        X_train, X_future, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        if y_train.isna().any():
            y_train = y_train.interpolate().bfill().ffill()
            
        # Note: Scaling is already done in _prepare_data via RobustScaler
        
        base_model = SVR()
        
        if auto_tune:
            param_dist = {
                'C': [0.1, 1, 10, 100],
                'epsilon': [0.01, 0.1, 0.5],
                'kernel': ['rbf', 'linear']
            }
            tscv = TimeSeriesSplit(n_splits=3)
            search = RandomizedSearchCV(
                base_model, param_dist, n_iter=10, scoring='neg_mean_absolute_error',
                cv=tscv, n_jobs=-1, random_state=42
            )
            search.fit(X_train, y_train)
            model = search.best_estimator_
            best_score = -search.best_score_
        else:
            model = SVR(**kwargs)
            model.fit(X_train, y_train)
            best_score = np.nan
            
        preds = model.predict(X_future)
        
        # Bootstrap for CIs
        lower, upper = _bootstrap_prediction_intervals(model, X_train, y_train, X_future, n_bootstraps=20)
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': preds,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = df[df[date_col] < prediction_start][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds, lower, upper,
                             f'SVR Forecast: {target_col}', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'SVR Forecast: {target_col}')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=model,
            metrics={'cv_mae': best_score},
            figure=fig,
            figure_interactive=fig_interactive
        )
    except Exception as e:
        print(f"Error in SVR forecasting: {e}")
        raise

def forecast_elastic_net(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    auto_tune: bool = True,
    **kwargs
) -> ForecastingResult:
    """
    Forecast using ElasticNet with CV optimization.
    """
    try:
        X_train, X_future, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        if y_train.isna().any():
            y_train = y_train.interpolate().bfill().ffill()
            
        base_model = ElasticNet(random_state=42)
        
        if auto_tune:
            param_dist = {
                'alpha': [0.01, 0.1, 1.0, 10.0],
                'l1_ratio': [0.1, 0.5, 0.7, 0.9]
            }
            tscv = TimeSeriesSplit(n_splits=3)
            search = RandomizedSearchCV(
                base_model, param_dist, n_iter=10, scoring='neg_mean_absolute_error',
                cv=tscv, n_jobs=-1, random_state=42
            )
            search.fit(X_train, y_train)
            model = search.best_estimator_
            best_score = -search.best_score_
        else:
            model = ElasticNet(random_state=42, **kwargs)
            model.fit(X_train, y_train)
            best_score = np.nan
            
        preds = model.predict(X_future)
        
        # Bootstrap for CIs (Analytic CIs also possible for Linear, but Bootstrap is consistent here)
        lower, upper = _bootstrap_prediction_intervals(model, X_train, y_train, X_future, n_bootstraps=20)
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': preds,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = df[df[date_col] < prediction_start][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds, lower, upper,
                             f'ElasticNet Forecast: {target_col}', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'ElasticNet Forecast: {target_col}')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=model,
            metrics={'cv_mae': best_score},
            figure=fig,
            figure_interactive=fig_interactive
        )
    except Exception as e:
        print(f"Error in ElasticNet forecasting: {e}")
        raise

def forecast_sarimax(
    df: pd.DataFrame,
    date_col: str,
    target_col: str,
    prediction_start: str | pd.Timestamp,
    order: Optional[Tuple[int, int, int]] = None,
    seasonal_order: Optional[Tuple[int, int, int, int]] = None,
    **kwargs
) -> ForecastingResult:
    """
    Forecast using SARIMAX. 
    If order is not provided, this implementation could ideally use auto_arima (if installed)
    or a simple grid search. Here we use a basic grid search if order is None.
    """
    if SARIMAX is None:
        raise ImportError("statsmodels is not installed.")
        
    try:
        X_train, X_future, y_train, future_dates, _ = _prepare_data(df, date_col, target_col, prediction_start)
        
        if y_train.isna().any():
            y_train = y_train.interpolate().bfill().ffill()
            
        # SARIMAX requires strict frequency
        # Ensure we use the same sorted index as X_train/y_train
        # Note: X_train is derived from 'historical', which is sorted.
        # y_train is also from 'historical'.
        # We need to reconstruct the DatetimeIndex from the sorted historical data.
        
        # Access the original date column from the historical slice of df used in _prepare_data
        prediction_start_dt = pd.to_datetime(prediction_start)
        historical_dates = df[df[date_col] < prediction_start_dt].sort_values(date_col)[date_col]
        
        y_train_ts = y_train.copy()
        y_train_ts.index = pd.DatetimeIndex(historical_dates)
        
        # Try to infer frequency
        inferred_freq = pd.infer_freq(y_train_ts.index)
        if inferred_freq:
            y_train_ts = y_train_ts.asfreq(inferred_freq)
            
        # Exogenous variables
        X_train_ts = X_train.copy()
        X_train_ts.index = y_train_ts.index
        if inferred_freq:
            X_train_ts = X_train_ts.asfreq(inferred_freq)
            
        # Model selection logic
        best_model = None
        best_aic = float('inf')
        
        if order is None:
            # Simple Grid Search for (p,d,q)
            # Assuming d=1 for non-stationary, d=0 for stationary.
            # We'll check d=0,1 and p,q in [0,1,2]
            import itertools
            p = d = q = range(0, 2)
            pdq = list(itertools.product(p, d, q))
            
            # Keep seasonal order simple or None if not specified
            s_order = seasonal_order if seasonal_order else (0, 0, 0, 0)
            
            warnings.filterwarnings("ignore") # Ignore convergence warnings during grid search
            
            for param in pdq:
                try:
                    mod = SARIMAX(y_train_ts, exog=X_train_ts,
                                  order=param,
                                  seasonal_order=s_order,
                                  enforce_stationarity=False,
                                  enforce_invertibility=False)
                    results = mod.fit(disp=False, maxiter=200)
                    if results.aic < best_aic:
                        best_aic = results.aic
                        best_model = results
                except:
                    continue
            
            warnings.resetwarnings()
            if best_model is None:
                 # Fallback
                 mod = SARIMAX(y_train_ts, exog=X_train_ts, order=(1,1,1), seasonal_order=(0,0,0,0))
                 best_model = mod.fit(disp=False)
        else:
            s_order = seasonal_order if seasonal_order else (0, 0, 0, 0)
            mod = SARIMAX(y_train_ts, exog=X_train_ts, order=order, seasonal_order=s_order, **kwargs)
            best_model = mod.fit(disp=False)
            
        # Predict
        forecast_res = best_model.get_forecast(steps=len(X_future), exog=X_future)
        preds = forecast_res.predicted_mean
        
        # Confidence Intervals
        ci = forecast_res.conf_int(alpha=0.05)
        # ci columns are typically 'lower target_col' and 'upper target_col'
        lower = ci.iloc[:, 0].values
        upper = ci.iloc[:, 1].values
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'predicted': preds.values,
            'lower_ci': lower,
            'upper_ci': upper
        })
        
        hist_dates = df[df[date_col] < prediction_start][date_col]
        fig = _plot_forecast(hist_dates, y_train, future_dates, preds.values, lower, upper,
                             f'SARIMAX Forecast: {target_col} (AIC={best_model.aic:.2f})', target_col)
        
        fig_interactive = _create_interactive_plot(hist_dates, y_train, forecast_df, date_col, target_col, f'SARIMAX Forecast: {target_col}')
        
        return ForecastingResult(
            forecast=forecast_df,
            model=best_model,
            metrics={'aic': best_model.aic},
            figure=fig,
            figure_interactive=fig_interactive
        )
        
    except Exception as e:
        print(f"Error in SARIMAX forecasting: {e}")
        raise
