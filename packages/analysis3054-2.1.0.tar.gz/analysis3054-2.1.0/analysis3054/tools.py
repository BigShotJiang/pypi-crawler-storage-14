"""
Additional tools and utilities for time series analysis and forecasting.

This module contains helper functions for outlier detection, stationarity checks,
metric calculation, plotting, and advanced data merging.
"""

from __future__ import annotations

from typing import Optional, Dict, Any, List, Union
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.metrics import mean_squared_error, mean_absolute_error

try:
    from statsmodels.tsa.stattools import adfuller
except ImportError:
    adfuller = None

def detect_outliers_zscore(
    df: pd.DataFrame,
    col: str,
    threshold: float = 3.0
) -> pd.DataFrame:
    """
    Detect outliers using Z-score method.
    
    Parameters
    ----------
    df : pd.DataFrame
        Input dataframe.
    col : str
        Column to check for outliers.
    threshold : float
        Z-score threshold (default 3.0).
        
    Returns
    -------
    pd.DataFrame
        Subset of df containing only the outliers.
    """
    df_clean = df.dropna(subset=[col])
    z_scores = np.abs(stats.zscore(df_clean[col]))
    outliers = df_clean[z_scores > threshold]
    return outliers

def check_stationarity_adf(series: pd.Series) -> Dict[str, Any]:
    """
    Check stationarity using Augmented Dickey-Fuller test.
    
    Parameters
    ----------
    series : pd.Series
        Time series data.
        
    Returns
    -------
    dict
        Dictionary containing ADF statistic, p-value, used lag, and critical values.
    """
    if adfuller is None:
        raise ImportError("statsmodels is required for stationarity check.")
    
    # Drop NA
    series = series.dropna()
    
    result = adfuller(series)
    output = {
        'test_statistic': result[0],
        'p_value': result[1],
        'used_lag': result[2],
        'n_obs': result[3],
        'critical_values': result[4],
        'is_stationary': result[1] < 0.05
    }
    return output

def calculate_forecast_metrics(
    y_true: np.ndarray | pd.Series,
    y_pred: np.ndarray | pd.Series
) -> Dict[str, float]:
    """
    Calculate common forecast metrics: MAE, RMSE, MAPE.
    
    Parameters
    ----------
    y_true : array-like
        Actual values.
    y_pred : array-like
        Predicted values.
        
    Returns
    -------
    dict
        Dictionary with 'MAE', 'RMSE', 'MAPE'.
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    
    # Filter out NaNs from both
    mask = ~np.isnan(y_true) & ~np.isnan(y_pred)
    y_true = y_true[mask]
    y_pred = y_pred[mask]
    
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    
    # Avoid division by zero for MAPE
    non_zero_mask = y_true != 0
    if np.any(non_zero_mask):
        mape = np.mean(np.abs((y_true[non_zero_mask] - y_pred[non_zero_mask]) / y_true[non_zero_mask])) * 100
    else:
        mape = np.nan
        
    return {
        'MAE': mae,
        'RMSE': rmse,
        'MAPE': mape
    }

def plot_forecast_comparison(
    forecasts: List[Dict[str, Any]],
    actuals: pd.DataFrame,
    date_col: str,
    target_col: str,
    title: str = "Forecast Comparison"
) -> Any:
    """
    Plot multiple forecasts against actuals.
    
    Parameters
    ----------
    forecasts : list of dict
        List where each item is a dict with keys:
        - 'name': str (name of model)
        - 'df': pd.DataFrame (must have date_col and 'predicted')
    actuals : pd.DataFrame
        Dataframe with actual values.
    date_col : str
        Name of date column.
    target_col : str
        Name of target column in actuals.
    title : str
        Plot title.
        
    Returns
    -------
    matplotlib.figure.Figure
    """
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Plot actuals
    ax.plot(actuals[date_col], actuals[target_col], label='Actual', color='black', linewidth=2)
    
    # Plot forecasts
    for item in forecasts:
        name = item['name']
        df_pred = item['df']
        ax.plot(df_pred[date_col], df_pred['predicted'], label=name, linestyle='--')
        
    ax.set_title(title)
    ax.set_xlabel('Date')
    ax.set_ylabel('Value')
    ax.legend()
    ax.grid(True)
    
    return fig

def smart_merge_asof(
    left: pd.DataFrame,
    right: pd.DataFrame,
    on: str,
    direction: str = 'backward',
    tolerance: Optional[pd.Timedelta] = None
) -> pd.DataFrame:
    """
    Smart merge using asof join.
    Useful for merging dataframes with mismatched timestamps (e.g., daily vs hourly, or irregular trading data).
    
    Parameters
    ----------
    left : pd.DataFrame
        Left DataFrame.
    right : pd.DataFrame
        Right DataFrame.
    on : str
        Column to merge on (must be datetime and sorted).
    direction : str
        'backward' (default), 'forward', or 'nearest'.
    tolerance : pd.Timedelta, optional
        Maximum time distance to look for a match.
        
    Returns
    -------
    pd.DataFrame
        Merged DataFrame.
    """
    # Ensure sorted
    left = left.sort_values(on)
    right = right.sort_values(on)
    
    merged = pd.merge_asof(
        left, 
        right, 
        on=on, 
        direction=direction, 
        tolerance=tolerance,
        suffixes=('_left', '_right')
    )
    return merged

def intelligent_impute_and_align(
    dfs: Dict[str, pd.DataFrame],
    date_col: str,
    freq: str = 'D',
    method: str = 'interpolate'
) -> pd.DataFrame:
    """
    Aligns multiple dataframes to a common frequency and imputes missing values.
    
    Parameters
    ----------
    dfs : Dict[str, pd.DataFrame]
        Dictionary of dataframes keyed by a name/prefix. 
        Each dataframe must have `date_col`.
    date_col : str
        Name of date column.
    freq : str
        Target frequency (e.g., 'D', 'H', 'MS').
    method : str
        Imputation method: 'interpolate' (time-based), 'ffill', 'bfill', 'zero'.
        
    Returns
    -------
    pd.DataFrame
        Combined DataFrame with aligned index and columns prefixed by keys in `dfs`.
    """
    combined = pd.DataFrame()
    
    for name, df in dfs.items():
        df = df.copy()
        df[date_col] = pd.to_datetime(df[date_col])
        df = df.set_index(date_col)
        
        # Resample
        # If duplicates exist for a timestamp, take mean
        if not df.index.is_unique:
            df = df.groupby(level=0).mean()
            
        df_resampled = df.resample(freq).mean() # Or asfreq()
        
        # Rename columns
        df_resampled.columns = [f"{name}_{c}" for c in df_resampled.columns]
        
        # Join
        if combined.empty:
            combined = df_resampled
        else:
            combined = combined.join(df_resampled, how='outer')
            
    # Impute
    if method == 'interpolate':
        combined = combined.interpolate(method='time')
    elif method == 'ffill':
        combined = combined.ffill()
    elif method == 'bfill':
        combined = combined.bfill()
    elif method == 'zero':
        combined = combined.fillna(0)
        
    return combined
