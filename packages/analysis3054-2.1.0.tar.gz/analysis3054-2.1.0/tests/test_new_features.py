import pandas as pd
import numpy as np
import pytest
from datetime import datetime, timedelta

from analysis3054.forecasting import (
    forecast_random_forest,
    forecast_xgboost,
    forecast_svm,
    forecast_elastic_net,
    forecast_sarimax,
    ForecastingResult
)
from analysis3054.tools import (
    detect_outliers_zscore,
    check_stationarity_adf,
    calculate_forecast_metrics,
    plot_forecast_comparison
)

def create_dummy_data():
    # Create 100 days of data
    dates = pd.date_range(start='2023-01-01', periods=120, freq='D')
    
    # Create a target with some trend and seasonality + noise
    t = np.arange(len(dates))
    trend = 0.1 * t
    seasonality = 10 * np.sin(2 * np.pi * t / 12)
    noise = np.random.normal(0, 1, len(dates))
    target = trend + seasonality + noise
    
    # Create a covariate (correlated with target)
    covariate = target + np.random.normal(0, 0.5, len(dates))
    
    # Create dataframe
    df = pd.DataFrame({
        'date': dates,
        'target': target,
        'covariate': covariate
    })
    
    # "Hide" target for the last 20 days (future)
    prediction_start = dates[100]
    df.loc[100:, 'target'] = np.nan
    
    return df, prediction_start

def test_forecast_random_forest():
    df, prediction_start = create_dummy_data()
    
    # Test with auto_tune=False for speed
    result = forecast_random_forest(
        df=df,
        date_col='date',
        target_col='target',
        prediction_start=prediction_start,
        auto_tune=False
    )
    
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 20
    assert 'predicted' in result.forecast.columns
    assert 'lower_ci' in result.forecast.columns
    assert 'upper_ci' in result.forecast.columns
    assert result.figure is not None
    print("Random Forest Test Passed")

def test_forecast_xgboost():
    df, prediction_start = create_dummy_data()
    
    try:
        result = forecast_xgboost(
            df=df,
            date_col='date',
            target_col='target',
            prediction_start=prediction_start,
            auto_tune=False
        )
        
        assert isinstance(result, ForecastingResult)
        assert len(result.forecast) == 20
        assert 'lower_ci' in result.forecast.columns
        print("XGBoost Test Passed")
    except ImportError:
        print("XGBoost not installed, skipping test")

def test_forecast_svm():
    df, prediction_start = create_dummy_data()
    
    result = forecast_svm(
        df=df,
        date_col='date',
        target_col='target',
        prediction_start=prediction_start,
        auto_tune=False
    )
    
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 20
    print("SVM Test Passed")

def test_forecast_elastic_net():
    df, prediction_start = create_dummy_data()
    
    result = forecast_elastic_net(
        df=df,
        date_col='date',
        target_col='target',
        prediction_start=prediction_start,
        auto_tune=False
    )
    
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 20
    print("ElasticNet Test Passed")

def test_forecast_sarimax():
    df, prediction_start = create_dummy_data()
    
    try:
        # Order None -> trigger simple grid search
        result = forecast_sarimax(
            df=df,
            date_col='date',
            target_col='target',
            prediction_start=prediction_start,
            order=None 
        )
        
        assert isinstance(result, ForecastingResult)
        assert len(result.forecast) == 20
        assert 'lower_ci' in result.forecast.columns
        print("SARIMAX Test Passed")
    except ImportError:
        print("Statsmodels not installed, skipping test")

def test_tools():
    df, _ = create_dummy_data()
    # Fill NaNs for tool testing
    df['target'] = df['target'].fillna(0)
    
    # Outliers
    # Introduce an outlier
    df.loc[50, 'target'] = 1000
    outliers = detect_outliers_zscore(df, 'target', threshold=3)
    assert 50 in outliers.index
    print("Outlier Detection Test Passed")
    
    # Stationarity
    try:
        stats = check_stationarity_adf(df['target'])
        assert 'p_value' in stats
        print("Stationarity Test Passed")
    except ImportError:
        print("Statsmodels not installed, skipping stationarity test")
        
    # Metrics
    y_true = np.array([1, 2, 3, 4, 5])
    y_pred = np.array([1.1, 2.1, 2.9, 4.2, 5.0])
    metrics = calculate_forecast_metrics(y_true, y_pred)
    assert 'MAE' in metrics
    assert 'RMSE' in metrics
    assert 'MAPE' in metrics
    print("Metrics Test Passed")
    
    # Plot comparison
    forecasts = [
        {'name': 'Model A', 'df': pd.DataFrame({'date': df['date'], 'predicted': df['target']})}
    ]
    fig = plot_forecast_comparison(forecasts, df, 'date', 'target')
    assert fig is not None
    print("Plot Comparison Test Passed")

if __name__ == "__main__":
    test_forecast_random_forest()
    test_forecast_xgboost()
    test_forecast_svm()
    test_forecast_elastic_net()
    test_forecast_sarimax()
    test_tools()
