import pandas as pd
import numpy as np
import pytest
import plotly.graph_objects as go

from analysis3054.analysis import (
    detect_anomalies_isolation_forest,
    fit_garch_volatility,
    analyze_dynamic_time_warping
)
from analysis3054.stats_advanced import (
    test_diebold_mariano,
    calculate_rolling_hurst_exponent,
    calculate_rolling_permutation_entropy
)
from analysis3054.signal import (
    decompose_singular_spectrum,
    generate_surrogate_data
)
from analysis3054.finance import calculate_tail_risk_metrics

def create_dummy_series(n=200):
    np.random.seed(42)
    return pd.Series(np.cumsum(np.random.randn(n)), name='value')

def run_test_diebold_mariano():
    actual = np.random.randn(100)
    pred1 = actual + np.random.normal(0, 0.1, 100)
    pred2 = actual + np.random.normal(0, 0.5, 100) # Worse
    
    res = test_diebold_mariano(actual, pred1, pred2)
    assert res['p_value'] < 0.05 # Should distinguish
    assert res['better_model'] == 1
    print("DM Test Passed")

def test_hurst_exponent():
    s = create_dummy_series()
    h, fig = calculate_rolling_hurst_exponent(s, window=50)
    assert len(h) == 200
    assert isinstance(fig, go.Figure)
    print("Hurst Test Passed")

def test_permutation_entropy():
    s = create_dummy_series()
    pe, fig = calculate_rolling_permutation_entropy(s, window=50)
    assert len(pe) == 200
    assert isinstance(fig, go.Figure)
    print("Permutation Entropy Test Passed")

def test_ssa_decomposition():
    s = create_dummy_series()
    # Add seasonality
    t = np.arange(200)
    s = s + 10 * np.sin(2*np.pi*t/20)
    
    df_comp, fig = decompose_singular_spectrum(s, L=50, n_components=2)
    assert 'Component_1' in df_comp.columns
    assert 'Residual' in df_comp.columns
    assert isinstance(fig, go.Figure)
    print("SSA Test Passed")

def test_surrogate_data():
    s = create_dummy_series(100)
    df_surr, fig = generate_surrogate_data(s, n_surrogates=5)
    assert df_surr.shape == (100, 5)
    assert isinstance(fig, go.Figure)
    print("Surrogate Data Test Passed")

def test_anomaly_detection():
    dates = pd.date_range('2023-01-01', periods=100)
    val = np.random.randn(100)
    val[50] = 10 # Anomaly
    df = pd.DataFrame({'date': dates, 'val': val})
    
    anomalies, fig = detect_anomalies_isolation_forest(df, 'date', 'val', contamination=0.05)
    assert 50 in anomalies.index
    assert isinstance(fig, go.Figure)
    print("Anomaly Detection Test Passed")

def test_garch_volatility():
    try:
        import arch
    except ImportError:
        print("arch package not installed, skipping GARCH test")
        return

    dates = pd.date_range('2023-01-01', periods=200)
    returns = np.random.normal(0, 1, 200)
    # Volatility cluster
    returns[100:150] *= 3
    df = pd.DataFrame({'date': dates, 'returns': returns})
    
    vol, fig = fit_garch_volatility(df, 'date', 'returns')
    assert len(vol) == 200
    assert isinstance(fig, go.Figure)
    print("GARCH Test Passed")

def test_dtw():
    s1 = np.sin(np.linspace(0, 10, 100))
    s2 = np.sin(np.linspace(0, 10, 100) + 0.5) # Phase shift
    
    dist, fig = analyze_dynamic_time_warping(s1, s2)
    assert dist >= 0
    assert isinstance(fig, go.Figure)
    print("DTW Test Passed")

def test_tail_risk():
    dates = pd.date_range('2023-01-01', periods=100)
    returns = np.random.normal(0, 0.01, 100)
    df = pd.DataFrame({'date': dates, 'returns': returns})
    
    metrics, fig = calculate_tail_risk_metrics(df, 'date', 'returns')
    assert 'VaR_95' in metrics
    assert 'Max_Drawdown' in metrics
    assert isinstance(fig, go.Figure)
    print("Tail Risk Test Passed")

if __name__ == "__main__":
    run_test_diebold_mariano()
    test_hurst_exponent()
    test_permutation_entropy()
    test_ssa_decomposition()
    test_surrogate_data()
    test_anomaly_detection()
    test_garch_volatility()
    test_dtw()
    test_tail_risk()
