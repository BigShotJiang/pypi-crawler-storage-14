import pandas as pd
import numpy as np
import pytest
import plotly.graph_objects as go

from analysis3054.forecasting import forecast_random_forest, generate_scenarios_bootstrap
from analysis3054.ensemble import forecast_ensemble
from analysis3054.causal import analyze_intervention_impact
from analysis3054.stats_advanced import detect_regime_switching_markov, test_stationarity_comprehensive
from analysis3054.signal import analyze_wavelet_spectrum

def create_dummy_data():
    dates = pd.date_range(start='2023-01-01', periods=150, freq='D')
    t = np.arange(len(dates))
    target = 0.1 * t + np.sin(t/10) + np.random.normal(0, 0.1, len(dates))
    return pd.DataFrame({'date': dates, 'target': target}), dates[120]

def test_ensemble():
    df, prediction_start = create_dummy_data()
    # Create two dummy results
    res1 = forecast_random_forest(df, 'date', 'target', prediction_start, auto_tune=False)
    res2 = forecast_random_forest(df, 'date', 'target', prediction_start, auto_tune=False)
    
    ens = forecast_ensemble([res1, res2], method='mean')
    assert len(ens.forecast) == 30
    assert isinstance(ens.figure_interactive, go.Figure)
    print("Ensemble Test Passed")

def test_causal_impact():
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    # Jump at 60
    y = np.concatenate([np.random.randn(60), np.random.randn(40) + 5])
    df = pd.DataFrame({'date': dates, 'target': y})
    
    metrics, fig = analyze_intervention_impact(df, 'date', 'target', intervention_date='2023-03-02', post_period_days=10)
    assert 'Total_Absolute_Effect' in metrics
    assert isinstance(fig, go.Figure)
    print("Causal Impact Test Passed")

def test_regime_switching():
    dates = pd.date_range(start='2023-01-01', periods=200, freq='D')
    # Low var then High var
    y = np.concatenate([np.random.normal(0, 1, 100), np.random.normal(0, 5, 100)])
    df = pd.DataFrame({'date': dates, 'returns': y})
    
    probs, fig = detect_regime_switching_markov(df, 'date', 'returns', k_regimes=2)
    assert probs.shape[1] == 2
    assert isinstance(fig, go.Figure)
    print("Regime Switching Test Passed")

def run_test_stationarity_comprehensive():
    s = np.random.randn(100) # Stationary
    res = test_stationarity_comprehensive(s)
    assert res['ADF']['is_stationary']
    print("Stationarity Test Passed")

def test_wavelet():
    try:
        import pywt
    except ImportError:
        print("PyWavelets not installed, skipping")
        return
    
    s = np.sin(np.linspace(0, 20, 200))
    power, fig = analyze_wavelet_spectrum(s)
    assert power.shape[1] == 200
    assert isinstance(fig, go.Figure)
    print("Wavelet Test Passed")

def test_bootstrap_scenarios():
    df, prediction_start = create_dummy_data()
    # Fit base model
    res = forecast_random_forest(df, 'date', 'target', prediction_start, auto_tune=False)
    
    scenarios, fig = generate_scenarios_bootstrap(res, n_scenarios=10)
    assert scenarios.shape == (30, 10)
    assert isinstance(fig, go.Figure)
    print("Bootstrap Scenarios Test Passed")

if __name__ == "__main__":
    test_ensemble()
    test_causal_impact()
    test_regime_switching()
    run_test_stationarity_comprehensive()
    test_wavelet()
    test_bootstrap_scenarios()
