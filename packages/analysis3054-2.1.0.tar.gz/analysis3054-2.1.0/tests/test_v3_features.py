import pandas as pd
import numpy as np
import pytest
import plotly.graph_objects as go

from analysis3054.forecasting_advanced import (
    forecast_var_multivariate,
    forecast_prophet_robust
)
from analysis3054.analysis import (
    analyze_granger_causality,
    detect_structural_breaks,
    analyze_cross_correlation
)
from analysis3054.forecasting import ForecastingResult

def create_multivariate_data():
    dates = pd.date_range(start='2023-01-01', periods=150, freq='D')
    # Two correlated series
    x = np.sin(np.arange(150)/10) + np.random.normal(0, 0.1, 150)
    y = x * 0.5 + np.random.normal(0, 0.1, 150) + 2
    # Shift y to create lag
    y = np.roll(y, 5) 
    
    df = pd.DataFrame({'date': dates, 'x': x, 'y': y})
    prediction_start = dates[120]
    return df, prediction_start

def test_forecast_var_multivariate():
    df, prediction_start = create_multivariate_data()
    # VAR needs good data, fill lag shift gap
    df = df.fillna(method='bfill').fillna(method='ffill')
    
    result = forecast_var_multivariate(
        df=df,
        date_col='date',
        target_col='y',
        variables=['x', 'y'],
        prediction_start=prediction_start,
        maxlags=3
    )
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 30
    assert 'lower_ci' in result.forecast.columns
    print("VAR Multivariate Test Passed")

def test_forecast_prophet_robust():
    try:
        import prophet
    except ImportError:
        print("Prophet not installed, skipping")
        return

    df, prediction_start = create_multivariate_data()
    result = forecast_prophet_robust(
        df=df,
        date_col='date',
        target_col='x',
        prediction_start=prediction_start
    )
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 30
    print("Prophet Test Passed")

def test_granger_causality():
    df, _ = create_multivariate_data()
    df = df.dropna()
    
    # x leads y (y was rolled), so x causes y
    p_matrix, fig = analyze_granger_causality(df, ['x', 'y'], max_lag=6)
    
    assert isinstance(p_matrix, pd.DataFrame)
    assert isinstance(fig, go.Figure)
    # x causing y should be low p-value (row x, col y)
    # p_matrix is row=cause, col=effect
    # We check if p-value is valid (float)
    assert not np.isnan(p_matrix.loc['x', 'y'])
    print("Granger Causality Test Passed")

def test_structural_breaks():
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    # Jump at 50
    y = np.concatenate([np.ones(50), np.ones(50)*5])
    df = pd.DataFrame({'date': dates, 'target': y})
    
    breaks, fig = detect_structural_breaks(df, 'date', 'target', window=10, z_threshold=2)
    
    assert len(breaks) > 0
    # Break around 50 (index 50 is date 2023-02-20)
    print(f"Detected breaks: {breaks}")
    assert isinstance(fig, go.Figure)
    print("Structural Breaks Test Passed")

def test_cross_correlation():
    df, _ = create_multivariate_data()
    fig = analyze_cross_correlation(df, 'y', 'x', max_lag=10)
    assert isinstance(fig, go.Figure)
    print("Cross Correlation Test Passed")

if __name__ == "__main__":
    test_forecast_var_multivariate()
    test_forecast_prophet_robust()
    test_granger_causality()
    test_structural_breaks()
    test_cross_correlation()
