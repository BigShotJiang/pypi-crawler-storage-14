import pandas as pd
import numpy as np
import pytest
import plotly.graph_objects as go

from analysis3054 import TimeSeriesLab
from analysis3054.commodities import (
    analyze_spread_cointegration, 
    plot_volatility_cones, 
    plot_seasonal_heatmap,
    analyze_term_structure
)

def create_commodity_data():
    dates = pd.date_range(start='2020-01-01', periods=500, freq='D')
    # Crude like path
    crude = 60 + np.cumsum(np.random.normal(0, 1, 500))
    # Gasoline correlated
    gas = crude * 1.2 + np.random.normal(0, 2, 500) + 10
    
    # Term structure: Backwardation usually
    back = crude * 0.95 + np.random.normal(0, 0.5, 500)
    
    return pd.DataFrame({
        'date': dates, 
        'crude': crude, 
        'gas': gas,
        'crude_back': back
    })

def test_spread_analysis():
    df = create_commodity_data()
    metrics, fig = analyze_spread_cointegration(df, 'date', 'gas', 'crude')
    assert 'Hedge_Ratio' in metrics
    assert 'Is_Stationary' in metrics
    assert isinstance(fig, go.Figure)
    print("Spread Analysis Test Passed")

def test_volatility_cones():
    df = create_commodity_data()
    fig = plot_volatility_cones(df, 'date', 'crude', windows=[10, 30])
    assert isinstance(fig, go.Figure)
    print("Volatility Cones Test Passed")

def test_seasonal_heatmap():
    df = create_commodity_data()
    fig = plot_seasonal_heatmap(df, 'date', 'crude', metric='mean')
    assert isinstance(fig, go.Figure)
    print("Seasonal Heatmap Test Passed")

def test_term_structure():
    df = create_commodity_data()
    data, fig = analyze_term_structure(df, 'date', 'crude', 'crude_back')
    assert 'roll_yield' in data.columns
    assert isinstance(fig, go.Figure)
    print("Term Structure Test Passed")

def test_wrapper_commodities():
    df = create_commodity_data()
    lab = TimeSeriesLab(df, 'date', 'crude')
    
    # Test via wrapper
    lab.analyze_commodities('volatility')
    lab.analyze_commodities('spread', asset2='gas')
    
    print("Wrapper Commodities Test Passed")

if __name__ == "__main__":
    test_spread_analysis()
    test_volatility_cones()
    test_seasonal_heatmap()
    test_term_structure()
    test_wrapper_commodities()
