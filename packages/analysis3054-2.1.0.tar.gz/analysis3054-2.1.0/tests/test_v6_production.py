import pandas as pd
import numpy as np
import pytest
import plotly.graph_objects as go

from analysis3054 import TimeSeriesLab
from analysis3054.diagnostics import plot_residual_diagnostics, backtest_rolling_window
from analysis3054.clustering import cluster_time_series
from analysis3054.forecasting import forecast_random_forest

def create_dummy_data():
    dates = pd.date_range(start='2023-01-01', periods=150, freq='D')
    t = np.arange(len(dates))
    target = 0.1 * t + np.sin(t/10) + np.random.normal(0, 0.1, len(dates))
    return pd.DataFrame({'date': dates, 'target': target})

def test_diagnostics():
    resid = np.random.normal(0, 1, 100)
    fig = plot_residual_diagnostics(resid)
    assert isinstance(fig, go.Figure)
    print("Diagnostics Plot Test Passed")

def test_backtest():
    df = create_dummy_data()
    # Must pass function, not call it
    res_df, fig = backtest_rolling_window(
        df, 'date', 'target', 
        forecast_func=forecast_random_forest,
        initial_window=100,
        horizon=5,
        step_size=10,
        auto_tune=False
    )
    assert not res_df.empty
    assert isinstance(fig, go.Figure)
    print("Backtest Test Passed")

def test_clustering():
    dates = pd.date_range('2023-01-01', periods=50)
    # Create 3 series: 2 similar, 1 different
    s1 = np.sin(np.linspace(0, 10, 50))
    s2 = np.sin(np.linspace(0, 10, 50)) + 0.1
    s3 = np.linspace(0, 1, 50) # Trend
    
    df = pd.DataFrame({'date': dates, 's1': s1, 's2': s2, 's3': s3})
    
    res_df, fig = cluster_time_series(df, 'date', ['s1', 's2', 's3'], n_clusters=2, method='features')
    assert len(res_df) == 3
    # Check s1 and s2 in same cluster ideally (might differ by seed but likely)
    c1 = res_df.loc[res_df['Series'] == 's1', 'Cluster'].values[0]
    c2 = res_df.loc[res_df['Series'] == 's2', 'Cluster'].values[0]
    assert c1 == c2
    print("Clustering Test Passed")

def test_wrapper():
    df = create_dummy_data()
    lab = TimeSeriesLab(df, 'date', 'target')
    
    lab.clean()
    lab.check_health()
    
    # Forecast
    # Use date within range for testing
    pred_start = df['date'].iloc[120]
    res = lab.forecast(model='random_forest', prediction_start=pred_start, auto_tune=False)
    assert len(res.forecast) > 0
    
    # Backtest via wrapper
    lab.backtest(model='random_forest', initial_window=100, horizon=5, step_size=20, auto_tune=False)
    
    print("Wrapper Test Passed")

if __name__ == "__main__":
    test_diagnostics()
    test_backtest()
    test_clustering()
    test_wrapper()
