import pandas as pd
import numpy as np
import pytest
from datetime import datetime, timedelta
import plotly.graph_objects as go

# Import new features
from analysis3054.forecasting_advanced import (
    forecast_stl_decomposition,
    forecast_lstm_probabilistic,
    # forecast_chronos # Tested conditionally due to heavy dependency
)
from analysis3054.tools import (
    smart_merge_asof,
    intelligent_impute_and_align
)
from analysis3054.plot_interactive import plot_yearly_comparison_interactive
from analysis3054.forecasting import ForecastingResult

def create_dummy_data():
    dates = pd.date_range(start='2023-01-01', periods=150, freq='D')
    t = np.arange(len(dates))
    trend = 0.1 * t
    seasonality = 10 * np.sin(2 * np.pi * t / 30)
    target = trend + seasonality + np.random.normal(0, 1, len(dates))
    
    df = pd.DataFrame({'date': dates, 'target': target})
    prediction_start = dates[120] # Last 30 days future
    
    # Set future target to NaN
    df.loc[120:, 'target'] = np.nan
    
    return df, prediction_start

def test_forecast_stl_decomposition():
    df, prediction_start = create_dummy_data()
    result = forecast_stl_decomposition(
        df=df,
        date_col='date',
        target_col='target',
        prediction_start=prediction_start,
        period=30
    )
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 30
    print("STL Decomposition Test Passed")

def test_forecast_lstm_probabilistic():
    try:
        import torch
    except ImportError:
        print("Torch not installed, skipping LSTM test")
        return

    df, prediction_start = create_dummy_data()
    result = forecast_lstm_probabilistic(
        df=df,
        date_col='date',
        target_col='target',
        prediction_start=prediction_start,
        lookback=10,
        epochs=2 # Fast test
    )
    assert isinstance(result, ForecastingResult)
    assert len(result.forecast) == 30
    print("LSTM Probabilistic Test Passed")

def test_smart_merge_asof():
    # Hourly data
    left = pd.DataFrame({
        'date': pd.date_range('2023-01-01', periods=5, freq='H'),
        'val_left': [1, 2, 3, 4, 5]
    })
    # Irregular data (e.g. every 45 mins)
    right = pd.DataFrame({
        'date': pd.date_range('2023-01-01', periods=5, freq='45min'),
        'val_right': [10, 20, 30, 40, 50]
    })
    
    merged = smart_merge_asof(left, right, on='date', direction='backward')
    assert len(merged) == 5
    assert 'val_right' in merged.columns
    print("Smart Merge Asof Test Passed")

def test_intelligent_impute_and_align():
    df1 = pd.DataFrame({
        'date': pd.date_range('2023-01-01', periods=5, freq='D'),
        'val': [1, 2, np.nan, 4, 5]
    })
    df2 = pd.DataFrame({
        'date': pd.date_range('2023-01-01', periods=5, freq='D'),
        'val': [10, 20, 30, 40, 50]
    })
    
    dfs = {'d1': df1, 'd2': df2}
    aligned = intelligent_impute_and_align(dfs, 'date', freq='D', method='interpolate')
    
    assert len(aligned) == 5
    assert 'd1_val' in aligned.columns
    assert not aligned['d1_val'].isna().any()
    print("Intelligent Impute Test Passed")

def test_plot_interactive():
    df, _ = create_dummy_data()
    # Fill NaNs for plot
    df['target'] = df['target'].fillna(0)
    
    fig = plot_yearly_comparison_interactive(
        df, 'date', 'target'
    )
    assert isinstance(fig, go.Figure)
    print("Interactive Plot Test Passed")

if __name__ == "__main__":
    test_forecast_stl_decomposition()
    test_forecast_lstm_probabilistic()
    test_smart_merge_asof()
    test_intelligent_impute_and_align()
    test_plot_interactive()
