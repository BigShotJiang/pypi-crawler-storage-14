import json
import logging
import os
import shlex
import shutil
import subprocess
import tempfile
import uuid

from pathlib import Path

# Path to yt-dlp inside the Mullvad VPS venv
YTDLP_BIN = os.getenv("YTDLP_BIN", "/opt/yt-dlp-mullvad/venv/bin/yt-dlp")

# Preferred audio language (used for headers + extractor-args)
PREFERRED_AUDIO_LANG = os.getenv("YTPDL_LANG", "en")

# Where finished files are written (API/CLI will send_file / serve from here)
OUT_DIR = os.getenv("YTPDL_OUT_DIR", "/root")

# Mullvad locations we’ll iterate through for “English-ish” exits
ENGLISH_LOCATIONS = [
    loc.strip()
    for loc in os.getenv("YTPDL_EN_LOCATIONS", "us,gb,ca,au").split(",")
    if loc.strip()
]


def _run_argv(argv, check=True, capture_output=True):
    """Run a subprocess and optionally raise on non-zero exit."""
    logging.debug("Running command: %s", " ".join(shlex.quote(a) for a in argv))
    result = subprocess.run(
        argv,
        check=False,
        capture_output=capture_output,
        text=True,
    )

    if capture_output:
        if result.stdout:
            logging.debug("stdout:\n%s", result.stdout)
        if result.stderr:
            logging.debug("stderr:\n%s", result.stderr)

    if check and result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode, argv, output=result.stdout, stderr=result.stderr
        )

    return result


# ---------------------------------------------------------------------------
# Mullvad helpers
# ---------------------------------------------------------------------------

def _mullvad_connect(location: str) -> None:
    logging.info("Trying Mullvad location: %s", location)
    _run_argv(["mullvad", "relay", "set", "location", location], check=True)
    _run_argv(["mullvad", "connect"], check=True)
    status = _run_argv(["mullvad", "status"], check=True)
    logging.info("Mullvad status after connect: %s", (status.stdout or "").strip())


def _mullvad_disconnect() -> None:
    try:
        _run_argv(["mullvad", "disconnect"], check=False)
    except Exception:
        logging.exception("Failed to disconnect Mullvad (ignored)")


# ---------------------------------------------------------------------------
# yt-dlp helpers
# ---------------------------------------------------------------------------

def _list_formats(url: str) -> None:
    """
    Just logs available formats for debugging. Does not affect logic.
    """
    logging.info("Listing available formats for %s over VPN", url)
    try:
        _run_argv(
            [
                YTDLP_BIN,
                url,
                "--list-formats",
                "--no-warnings",
                "--ignore-config",
                "--no-call-home",
            ],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        logging.error("Format listing failed (ignored): %s", e.stderr or e)


def _common_yt_args() -> list[str]:
    """
    Arguments shared by all yt-dlp invocations.
    Biases toward English without being brittle.
    """
    extractor_args = f"youtube:lang={PREFERRED_AUDIO_LANG};player_client=web"

    return [
        "--ignore-config",
        "--no-warnings",
        "--no-call-home",
        "--no-playlist",
        "--concurrent-fragments",
        "4",
        "--extractor-args",
        extractor_args,
        "--add-header",
        f"Accept-Language: {PREFERRED_AUDIO_LANG},en;q=0.9",
    ]


def _probe_main_audio_lang(path: str) -> str | None:
    """
    Return ISO language code for first audio stream, or None if unknown.
    Soft check only: we never fail just because this is missing/mismatched.
    """
    try:
        result = _run_argv(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "a:0",
                "-show_entries",
                "stream=tags",
                "-of",
                "json",
                path,
            ],
            check=True,
        )
        data = json.loads(result.stdout or "{}")
        streams = data.get("streams") or []
        tags = (streams[0].get("tags") if streams else {}) or {}
        lang = tags.get("language") or tags.get("LANGUAGE")

        if lang:
            logging.info("ffprobe audio language=%s for %s", lang, path)
        else:
            logging.info("ffprobe found no language tag for %s", path)

        return lang
    except Exception:
        logging.exception("ffprobe failed; cannot determine audio language")
        return None


# ---------------------------------------------------------------------------
# Downloaders
# ---------------------------------------------------------------------------

def _download_audio(url: str, tmp_file: str) -> None:
    """
    Download audio-only as MP3 to tmp_file.
    Uses a robust fallback chain so something always matches.
    """
    fmt = (
        f"ba[language^={PREFERRED_AUDIO_LANG}]/"
        "ba[language^=en]/"
        "ba[language^=und]/"
        "bestaudio"
    )

    argv = [
        YTDLP_BIN,
        url,
        "-f",
        fmt,
        "-x",
        "--audio-format",
        "mp3",
        "--audio-quality",
        "0",
        "-o",
        tmp_file,
        "--audio-multistreams",
    ] + _common_yt_args()

    _run_argv(argv, check=True)


def _download_video(url: str, resolution: int, tmp_file: str) -> None:
    """
    Download best H.264 MP4 video up to 'resolution' with English audio if possible.

    The format chain is deliberately *tolerant*:
      1. H.264 up to cap + preferred language audio
      2. H.264 up to cap + any English audio
      3. H.264 up to cap + best audio
      4. Any video up to cap + preferred language
      5. Any video up to cap + best audio
      6. Best single-file format up to cap
      7. Absolute fallback: best overall
    """
    cap = resolution or 1080

    fmt = (
        # Prefer H.264 with preferred language audio
        f"bv*[vcodec~='^(?:avc1|h264)'][height<={cap}]"
        f"+ba[language^={PREFERRED_AUDIO_LANG}]/"
        # H.264 with any English audio
        f"bv*[vcodec~='^(?:avc1|h264)'][height<={cap}]"
        "+ba[language^=en]/"
        # H.264 with any audio
        f"bv*[vcodec~='^(?:avc1|h264)'][height<={cap}]+bestaudio/"
        # Any video up to cap with preferred language
        f"bv*[height<={cap}]+ba[language^={PREFERRED_AUDIO_LANG}]/"
        # Any video up to cap with any audio
        f"bv*[height<={cap}]+bestaudio/"
        # Single-file up to cap
        f"b[height<={cap}]/"
        # Last-resort fallback
        "b"
    )

    argv = [
        YTDLP_BIN,
        url,
        "-f",
        fmt,
        "-S",
        "vcodec:avc1,h264,res,filesize,br",
        "-o",
        tmp_file,
        "--merge-output-format",
        "mp4",
        "--audio-multistreams",
    ] + _common_yt_args()

    _run_argv(argv, check=True)

    # Soft language check: log if we didn't get preferred language, but don't fail.
    lang = _probe_main_audio_lang(tmp_file)
    if lang and not (
        lang.lower().startswith(PREFERRED_AUDIO_LANG.lower())
        or lang.lower().startswith("en")
        or lang.lower().startswith("und")
    ):
        logging.warning(
            "Non-preferred audio language detected (%s) for %s; continuing anyway.",
            lang,
            tmp_file,
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def download_video(url: str, extension: str, resolution: int | None = None) -> str:
    """
    Public entrypoint used by both CLI and FastAPI app.

    Returns absolute path to the downloaded file.
    Raises RuntimeError on failure (API turns that into HTTP 5xx).
    """
    extension = (extension or "mp4").lower()
    os.makedirs(OUT_DIR, exist_ok=True)

    # Quick Mullvad sanity check before we start looping locations
    try:
        status = _run_argv(["mullvad", "account", "get"], check=True)
        logging.info("Mullvad account: %s", (status.stdout or "").strip())
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            "Mullvad is not logged in or not installed on VPS. "
            "Run 'mullvad account login' first."
        ) from e

    last_error: Exception | None = None

    for loc in ENGLISH_LOCATIONS or ["us"]:
        try:
            _mullvad_connect(loc)
            _list_formats(url)

            with tempfile.TemporaryDirectory(prefix="ytpdl_") as tmpdir:
                base = f"ytpdl_{uuid.uuid4().hex}"
                if extension == "mp3":
                    tmp_path = os.path.join(tmpdir, base + ".mp3")
                    _download_audio(url, tmp_path)
                else:
                    tmp_path = os.path.join(tmpdir, base + ".mp4")
                    _download_video(url, resolution or 1080, tmp_path)

                if not os.path.exists(tmp_path):
                    raise RuntimeError(
                        f"Download seems to have completed but file is missing: {tmp_path}"
                    )

                final_path = os.path.join(OUT_DIR, os.path.basename(tmp_path))
                shutil.move(tmp_path, final_path)
                logging.info("Download successful at %s via %s", final_path, loc)
                return final_path

        except subprocess.CalledProcessError as e:
            last_error = e
            logging.error(
                "yt-dlp error in location %s (rc=%s): %s",
                loc,
                e.returncode,
                e.stderr or e.output or str(e),
            )
            # Try next Mullvad location
        except Exception as e:
            last_error = e
            logging.exception("Unexpected error in location %s", loc)
        finally:
            _mullvad_disconnect()

    # If we get here, all locations failed
    if last_error:
        raise RuntimeError(
            f"Download failed after trying all VPN locations: {last_error}"
        ) from last_error

    raise RuntimeError(
        "Download failed after trying all VPN locations for unknown reasons"
    )
