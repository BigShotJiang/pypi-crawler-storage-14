import plotly.graph_objects as go
import numpy as np
import sys

sys.path.append("./wave.py")


def draw():
    fig = go.Figure()
