"""
FastAPI routes for AtlasUI.
"""
