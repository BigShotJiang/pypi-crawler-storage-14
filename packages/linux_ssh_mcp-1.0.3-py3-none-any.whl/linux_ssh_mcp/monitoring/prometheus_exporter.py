#!/usr/bin/env python3
"""
Prometheus metrics exporter for Linux SSH MCP

Provides metrics collection and export functionality for monitoring with Prometheus.
"""

import time
import asyncio
from typing import Dict, Any, Optional
from datetime import datetime

try:
    from prometheus_client import Counter, Histogram, Gauge, start_http_server, CollectorRegistry, generate_latest
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False

from ..performance_monitor import PerformanceMonitor
from ..auth import AuthManager


class PrometheusExporter:
    """Prometheus metrics exporter"""

    def __init__(self, port: int = 9090, enabled: bool = True):
        self.port = port
        self.enabled = enabled and PROMETHEUS_AVAILABLE
        self.registry = CollectorRegistry()
        self._metrics_initialized = False

        if not self.enabled:
            print("Prometheus exporter disabled (prometheus_client not available)")
            return

        # Initialize metrics
        self._init_metrics()

    def _init_metrics(self):
        """Initialize Prometheus metrics"""
        # SSH connection metrics
        self.ssh_connections_total = Counter(
            'ssh_connections_total',
            'Total number of SSH connections created',
            ['server_id', 'user', 'status'],
            registry=self.registry
        )

        self.ssh_connections_active = Gauge(
            'ssh_connections_active',
            'Number of active SSH connections',
            ['server_id'],
            registry=self.registry
        )

        self.ssh_commands_total = Counter(
            'ssh_commands_total',
            'Total number of SSH commands executed',
            ['server_id', 'command_type', 'status'],
            registry=self.registry
        )

        self.ssh_commands_successful_total = Counter(
            'ssh_commands_successful_total',
            'Total number of successful SSH commands',
            ['server_id', 'command_type'],
            registry=self.registry
        )

        self.ssh_command_duration_seconds = Histogram(
            'ssh_command_duration_seconds',
            'Duration of SSH command execution',
            ['server_id', 'command_type'],
            buckets=[0.1, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0, 120.0],
            registry=self.registry
        )

        # System metrics
        self.cpu_usage_percent = Gauge(
            'cpu_usage_percent',
            'CPU usage percentage',
            registry=self.registry
        )

        self.memory_usage_percent = Gauge(
            'memory_usage_percent',
            'Memory usage percentage',
            registry=self.registry
        )

        self.memory_usage_bytes = Gauge(
            'memory_usage_bytes',
            'Memory usage in bytes',
            registry=self.registry
        )

        self.disk_usage_percent = Gauge(
            'disk_usage_percent',
            'Disk usage percentage',
            ['mount_point'],
            registry=self.registry
        )

        # Task queue metrics
        self.task_queue_length = Gauge(
            'task_queue_length',
            'Number of tasks in queue',
            ['priority', 'status'],
            registry=self.registry
        )

        self.task_execution_duration_seconds = Histogram(
            'task_execution_duration_seconds',
            'Task execution duration',
            ['task_type', 'status'],
            buckets=[1.0, 5.0, 10.0, 30.0, 60.0, 300.0, 600.0],
            registry=self.registry
        )

        self.task_total = Counter(
            'task_total',
            'Total number of tasks processed',
            ['task_type', 'status'],
            registry=self.registry
        )

        # Cache metrics
        self.cache_hits_total = Counter(
            'cache_hits_total',
            'Total number of cache hits',
            ['cache_type', 'cache_level'],
            registry=self.registry
        )

        self.cache_misses_total = Counter(
            'cache_misses_total',
            'Total number of cache misses',
            ['cache_type', 'cache_level'],
            registry=self.registry
        )

        self.cache_size_bytes = Gauge(
            'cache_size_bytes',
            'Cache size in bytes',
            ['cache_type'],
            registry=self.registry
        )

        self.cache_items_total = Gauge(
            'cache_items_total',
            'Total number of items in cache',
            ['cache_type'],
            registry=self.registry
        )

        # Batch operation metrics
        self.batch_operations_total = Counter(
            'batch_operations_total',
            'Total number of batch operations',
            ['operation_type', 'status'],
            registry=self.registry
        )

        self.batch_commands_total = Counter(
            'batch_commands_total',
            'Total number of batch commands',
            ['server_id', 'status'],
            registry=self.registry
        )

        self.batch_duration_seconds = Histogram(
            'batch_duration_seconds',
            'Batch operation duration',
            ['operation_type'],
            buckets=[1.0, 5.0, 10.0, 30.0, 60.0, 300.0, 600.0, 1800.0],
            registry=self.registry
        )

        # Authentication metrics
        self.auth_attempts_total = Counter(
            'auth_attempts_total',
            'Total authentication attempts',
            ['method', 'status'],
            registry=self.registry
        )

        self.auth_sessions_active = Gauge(
            'auth_sessions_active',
            'Number of active authentication sessions',
            ['user_type'],
            registry=self.registry
        )

        # Application metrics
        self.app_requests_total = Counter(
            'app_requests_total',
            'Total number of application requests',
            ['method', 'endpoint', 'status'],
            registry=self.registry
        )

        self.app_request_duration_seconds = Histogram(
            'app_request_duration_seconds',
            'Application request duration',
            ['method', 'endpoint'],
            buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
            registry=self.registry
        )

        self._metrics_initialized = True
        print("Prometheus metrics initialized")

    def record_ssh_connection(self, server_id: str, user: str, status: str):
        """Record SSH connection attempt"""
        if not self.enabled:
            return
        self.ssh_connections_total.labels(
            server_id=server_id,
            user=user,
            status=status
        ).inc()

    def update_active_connections(self, server_id: str, count: int):
        """Update active SSH connection count"""
        if not self.enabled:
            return
        self.ssh_connections_active.labels(server_id=server_id).set(count)

    def record_ssh_command(self, server_id: str, command_type: str,
                          status: str, duration: float):
        """Record SSH command execution"""
        if not self.enabled:
            return
        self.ssh_commands_total.labels(
            server_id=server_id,
            command_type=command_type,
            status=status
        ).inc()

        if status == 'success':
            self.ssh_commands_successful_total.labels(
                server_id=server_id,
                command_type=command_type
            ).inc()

        self.ssh_command_duration_seconds.labels(
            server_id=server_id,
            command_type=command_type
        ).observe(duration)

    def update_system_metrics(self, cpu_percent: float, memory_percent: float,
                           memory_bytes: int, disk_usage: Dict[str, float]):
        """Update system metrics"""
        if not self.enabled:
            return
        self.cpu_usage_percent.set(cpu_percent)
        self.memory_usage_percent.set(memory_percent)
        self.memory_usage_bytes.set(memory_bytes)

        for mount_point, usage_percent in disk_usage.items():
            self.disk_usage_percent.labels(mount_point=mount_point).set(usage_percent)

    def update_task_metrics(self, queue_lengths: Dict[str, int],
                           task_type: str, status: str, duration: float):
        """Update task queue metrics"""
        if not self.enabled:
            return
        for priority, length in queue_lengths.items():
            self.task_queue_length.labels(priority=priority, status='pending').set(length)

        self.task_total.labels(task_type=task_type, status=status).inc()
        self.task_execution_duration_seconds.labels(task_type=task_type, status=status).observe(duration)

    def update_cache_metrics(self, cache_type: str, hits: int, misses: int,
                           size_bytes: int, items_count: int):
        """Update cache metrics"""
        if not self.enabled:
            return
        self.cache_hits_total.labels(cache_type=cache_type, cache_level='memory').inc(hits)
        self.cache_misses_total.labels(cache_type=cache_type, cache_level='memory').inc(misses)
        self.cache_size_bytes.labels(cache_type=cache_type).set(size_bytes)
        self.cache_items_total.labels(cache_type=cache_type).set(items_count)

    def record_batch_operation(self, operation_type: str, status: str,
                             duration: float, command_results: Dict[str, int]):
        """Record batch operation metrics"""
        if not self.enabled:
            return
        self.batch_operations_total.labels(
            operation_type=operation_type,
            status=status
        ).inc()

        self.batch_duration_seconds.labels(operation_type=operation_type).observe(duration)

        for server_id, count in command_results.items():
            self.batch_commands_total.labels(server_id=server_id, status=status).inc(count)

    def record_auth_attempt(self, method: str, status: str):
        """Record authentication attempt"""
        if not self.enabled:
            return
        self.auth_attempts_total.labels(method=method, status=status).inc()

    def update_active_sessions(self, user_types: Dict[str, int]):
        """Update active session counts"""
        if not self.enabled:
            return
        for user_type, count in user_types.items():
            self.auth_sessions_active.labels(user_type=user_type).set(count)

    def record_app_request(self, method: str, endpoint: str,
                          status: str, duration: float):
        """Record application request"""
        if not self.enabled:
            return
        self.app_requests_total.labels(
            method=method,
            endpoint=endpoint,
            status=status
        ).inc()

        self.app_request_duration_seconds.labels(
            method=method,
            endpoint=endpoint
        ).observe(duration)

    def start_server(self):
        """Start the Prometheus HTTP server"""
        if not self.enabled:
            print("Prometheus server not started (exporter disabled)")
            return

        try:
            start_http_server(self.port, registry=self.registry)
            print(f"Prometheus metrics server started on port {self.port}")
        except Exception as e:
            print(f"Failed to start Prometheus server: {e}")

    def get_metrics(self) -> Optional[str]:
        """Get current metrics in Prometheus format"""
        if not self.enabled:
            return None
        return generate_latest(self.registry).decode('utf-8')


class MetricsCollector:
    """Collects and updates metrics from various components"""

    def __init__(self, exporter: PrometheusExporter):
        self.exporter = exporter
        self.running = False
        self.collection_interval = 30  # seconds

    async def start_collection(self):
        """Start metrics collection loop"""
        if not self.exporter.enabled:
            return

        self.running = True
        print("Starting metrics collection...")

        while self.running:
            try:
                await self._collect_metrics()
                await asyncio.sleep(self.collection_interval)
            except Exception as e:
                print(f"Error collecting metrics: {e}")
                await asyncio.sleep(5)

    async def _collect_metrics(self):
        """Collect metrics from all components"""
        # This method should be integrated with the actual components
        # For now, we'll collect basic system metrics
        import psutil

        # System metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')

        disk_usage = {'/': disk.percent}
        for partition in psutil.disk_partitions():
            if partition.mountpoint != '/':
                try:
                    disk_usage[partition.mountpoint] = psutil.disk_usage(partition.mountpoint).percent
                except:
                    pass

        self.exporter.update_system_metrics(
            cpu_percent=cpu_percent,
            memory_percent=memory.percent,
            memory_bytes=memory.used,
            disk_usage=disk_usage
        )

    def stop_collection(self):
        """Stop metrics collection"""
        self.running = False
        print("Metrics collection stopped")