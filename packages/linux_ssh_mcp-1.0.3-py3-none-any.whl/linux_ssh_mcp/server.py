#!/usr/bin/env python3
"""
Linux SSH MCP Server
"""

import asyncio
import argparse
import sys
import logging
from pathlib import Path

from . import SSHManager, ServerConfig
from .auth import AuthManager, UserRole
from .monitoring import PrometheusExporter, MetricsCollector


def setup_logging(level=logging.INFO):
    """Setup logging configuration"""
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('ssh-mcp-server.log')
        ]
    )


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="Linux SSH MCP Server",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument('--host', default='0.0.0.0', help='Server host (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, default=8000, help='Server port (default: 8000)')
    parser.add_argument('--log-level', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                        help='Log level (default: INFO)')
    parser.add_argument('--metrics-port', type=int, default=9090, help='Metrics port (default: 9090)')
    parser.add_argument('--enable-metrics', action='store_true', help='Enable Prometheus metrics')
    parser.add_argument('--config', help='Configuration file path')
    parser.add_argument('--workers', type=int, default=1, help='Number of worker processes')

    return parser.parse_args()


async def start_server(args):
    """Start the SSH MCP server"""
    logger = logging.getLogger(__name__)
    logger.info("Starting Linux SSH MCP Server")

    # Initialize core components
    ssh_manager = SSHManager(use_pooling=True)
    auth_manager = AuthManager()

    # Initialize metrics if enabled
    metrics_exporter = None
    metrics_collector = None

    if args.enable_metrics:
        metrics_exporter = PrometheusExporter(port=args.metrics_port)
        metrics_collector = MetricsCollector(metrics_exporter)
        await metrics_collector.start_collection()
        logger.info(f"Metrics server started on port {args.metrics_port}")

    # Load configuration if provided
    if args.config:
        logger.info(f"Loading configuration from {args.config}")
        # TODO: Implement configuration loading

    # Start FastAPI server (simplified version)
    from fastapi import FastAPI
    import uvicorn

    app = FastAPI(title="Linux SSH MCP Server", version="1.0.0")

    # Basic health check endpoint
    @app.get("/health")
    async def health_check():
        return {"status": "healthy", "service": "ssh-mcp-server"}

    @app.get("/metrics")
    async def metrics():
        if metrics_exporter:
            return metrics_exporter.get_metrics()
        return {"error": "Metrics not enabled"}

    # Start the server
    config = uvicorn.Config(
        app,
        host=args.host,
        port=args.port,
        log_level=args.log_level.lower(),
        workers=1  # Use single worker for now
    )

    server = uvicorn.Server(config)
    logger.info(f"SSH MCP Server starting on {args.host}:{args.port}")

    try:
        await server.serve()
    except Exception as e:
        logger.error(f"Server error: {e}")
        return 1
    finally:
        if metrics_collector:
            metrics_collector.stop_collection()
        await ssh_manager.cleanup_connections()
        logger.info("Server stopped")

    return 0


def main():
    """Main server entry point"""
    args = parse_args()

    # Setup logging
    log_level = getattr(logging, args.log_level.upper())
    setup_logging(log_level)

    try:
        return asyncio.run(start_server(args))
    except KeyboardInterrupt:
        print("\nServer stopped by user")
        return 0
    except Exception as e:
        print(f"Server startup failed: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())