Command-line Interface
======================

The best way to try the cli and see its capabilities is with the ``--help`` option in every subcommand.
You can also find here a complete list of the subcommands, options and arguments.

CLI reference
*************
.. click:: firecrest.cli:typer_click_object
   :prog: firecrest
   :nested: full