"""
Provides classes which extend `langchain_core.callbacks:BaseCallbackHandler`.
Not to be confused with Jupyter AI chat handlers.
"""

from .metadata import MetadataCallbackHandler
