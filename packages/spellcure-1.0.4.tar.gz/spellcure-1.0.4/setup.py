from setuptools import setup
from pathlib import Path

# Read README.md for PyPI long description
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name='spellcure',
    version='1.0.1',
    description='Saheban Khan’s original spelling correction engine',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=['spellcure'],
    python_requires='>=3.8'
)
