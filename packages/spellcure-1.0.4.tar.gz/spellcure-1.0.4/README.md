# SpellCure

**SpellCure** is a mathematical correction engine for highly scrambled or distorted text, created by **Saheban Khan** *(GitHub: Lsaheban)* and maintained by **Tohid Khan** *(GitHub: Tohid096)*.

Rather than using machine learning, SpellCure applies a **position-weighted ratio algorithm** to match noisy tokens with valid dictionary words — enabling high-accuracy recovery even from severely jumbled text.

---

## ✨ Features

- Corrects **heavily scrambled** or distorted words  
- Pure **mathematical algorithm** (no ML required)  
- Supports:
  - **Small built-in vocabulary** (~10k curated words)
  - **Large NLTK vocabulary** (~200k+ words)
- Works with single words, sentences, or mixed noisy text  
- Fast, deterministic, and lightweight  
- Extensible word bank (users may request custom additions)

---

## 🧠 How SpellCure Works

SpellCure analyzes each token using:

- Position-based character similarity  
- Ratio scoring  
- Multi-stage refinement  
- Optional large NLTK dataset  

Examples:

| Input                  | Output                 |
|------------------------|------------------------|
| `aplpe`               | `apple`                |
| `tihs wrod is msesdy` | `this word is messy`   |
| `olve is evryetign`   | `love is everything`   |

---

## 🚀 Quick Start

### Importing SpellCure

```python
from spellcure import corrector
---
## 🧪 Example Usage

Here is a minimal working example using the **small** vocabulary mode:

```python
from spellcure import corrector

def test_small():
    model = corrector(mode="small")   # Use small curated word bank
    output = model.correct("olve is evryetign")
    print(output)

test_small()
#Outpu: love is everything


# small = ~10k curated words
# large = ~200k NLTK words
model = corrector(mode="large")
----
# bash pip install spellcure
