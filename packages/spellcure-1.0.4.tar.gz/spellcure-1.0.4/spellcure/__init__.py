from .spellcure import corrector

__all__ = ["corrector"]

