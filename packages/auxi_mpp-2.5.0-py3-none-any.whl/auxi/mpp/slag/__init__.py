"""
Slag physical property models.
"""

from ._slag_property_model import SlagPropertyModel


__all__ = [
    "SlagPropertyModel",
]
