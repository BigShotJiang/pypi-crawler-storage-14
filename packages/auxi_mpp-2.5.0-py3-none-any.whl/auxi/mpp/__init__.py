"""
`auxi` provides tools to help users do calculations for metallurgical process engineering. `auxi-mpp` provides tools for calculating material physical properties.
"""

__version__ = "2.5.0"
