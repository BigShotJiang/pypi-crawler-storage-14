# Hyperdash

NOTE: [Hyperdash](https://hyperdash.info) is not an exchange, but a tracker for HyperLiquid.