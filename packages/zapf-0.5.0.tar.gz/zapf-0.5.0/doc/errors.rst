Zapf exceptions
===============

The following exceptions are defined by Zapf:

.. currentmodule:: zapf

.. autoclass:: Error

.. autoclass:: CommError

.. autoclass:: SpecError

.. autoclass:: ApiError
