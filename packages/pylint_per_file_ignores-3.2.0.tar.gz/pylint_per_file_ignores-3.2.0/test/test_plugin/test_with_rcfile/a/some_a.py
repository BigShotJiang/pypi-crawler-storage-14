# no module docstring

from __future__ import annotations

import nothere

nothere._do_something()
