# no module docstring

from __future__ import annotations

import foo

foo._do_something()
