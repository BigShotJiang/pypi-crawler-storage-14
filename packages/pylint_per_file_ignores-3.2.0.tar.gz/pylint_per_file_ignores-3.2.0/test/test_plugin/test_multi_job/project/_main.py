from __future__ import annotations

X = 123
