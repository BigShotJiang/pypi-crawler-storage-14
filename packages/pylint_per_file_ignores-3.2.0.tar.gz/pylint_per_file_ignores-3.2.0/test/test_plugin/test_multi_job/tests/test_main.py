from __future__ import annotations

from project import _main

_main.X = 42
