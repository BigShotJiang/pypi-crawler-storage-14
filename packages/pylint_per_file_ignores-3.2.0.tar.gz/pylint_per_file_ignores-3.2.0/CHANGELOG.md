# Changelog

<!-- towncrier release notes start -->

## 3.2.0 (2025-11-25)

No significant changes.


## 3.1.0
- Support pylint 4.x

## 3.0.0
- Removed support for python 3.9

## 2.0.3
- Make glob patterns recursive

## 2.0.2
- Fixed version mismatch

## 2.0.1
- Fixed project classifiers

## 2.0.0
- Dropped support for pylint versions below 3.3
- Officially support python 3.9-3.14
- Dropped support for python 3.8 and before
- Complete refactoring of the project
- Dropped support for the custom pyproject.toml section
- Support parallel mode of pylint
- Switch from regex patterns to globs
