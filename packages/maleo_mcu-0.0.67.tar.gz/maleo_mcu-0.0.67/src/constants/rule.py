from nexo.schemas.resource import Resource, ResourceIdentifier

RULE_RESOURCE = Resource(
    identifiers=[ResourceIdentifier(key="rule", name="Rule", slug="rules")],
    details=None,
)
