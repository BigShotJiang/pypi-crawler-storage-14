from uuid import UUID


IdentifierValueType = int | UUID
ValueType = bool | float | int | str
OptValueType = ValueType | None
