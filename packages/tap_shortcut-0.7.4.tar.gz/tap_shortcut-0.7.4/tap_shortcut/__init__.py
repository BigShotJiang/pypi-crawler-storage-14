"""Python package for the tap-shortcut CLI."""
