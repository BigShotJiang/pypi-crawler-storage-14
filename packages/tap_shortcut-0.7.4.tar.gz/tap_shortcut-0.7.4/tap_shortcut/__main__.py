"""Tap executable."""

from __future__ import annotations

from tap_shortcut.tap import TapShortcut

TapShortcut.cli()
