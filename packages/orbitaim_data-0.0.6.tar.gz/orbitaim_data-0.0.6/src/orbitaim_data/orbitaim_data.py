from .tools.discovery_engine import discovery_search_engine

def discovery_search(project_id,location,engine_id,api_key,search_query,page_token):
    return discovery_search_engine(project_id,location,engine_id,api_key,search_query,page_token)