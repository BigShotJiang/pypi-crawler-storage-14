import os
from abc import abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..client.exceptions import LogConfigError
from .base import LogConfig, OutputMode


def _split_env_list(env_var: str, default: Optional[List[str]] = None) -> List[str]:
    """Split comma-delimited environment variables into a normalized list."""
    value = os.getenv(env_var)
    if value is None or value.strip() == "":
        return default or []
    return [item.strip() for item in value.split(",") if item.strip()]


@dataclass
class LogCloudConfig(LogConfig):
    @abstractmethod
    def to_platform_config(self) -> Dict[str, Any]:
        """Get cloud provider specific configuration"""
        raise NotImplementedError()


@dataclass
class DatadogLogConfig(LogConfig):
    """Datadog-specific log configuration"""

    api_key: Optional[str] = field(default=None, repr=False)
    app_key: Optional[str] = field(default=None, repr=False)

    cloud_provider: str = "datadog"
    output_mode: OutputMode = "cloud"

    site: str = "datadoghq.com"
    service: str = "domolibrary"
    env: str = "production"

    def to_platform_config(self) -> Dict[str, Any]:
        return {
            "api_key": self.api_key,
            "app_key": self.app_key,
            "site": self.site,
            "service": self.service,
            "env": self.env,
            "cloud_provider": self.cloud_provider,
        }

    def validate_config(self) -> bool:
        if not self.api_key:
            raise LogConfigError("Datadog API key is required")
        return True


@dataclass
class AWSCloudWatchLogConfig(LogConfig):
    """AWS CloudWatch-specific log configuration"""

    aws_region: str = ""
    log_group: str = ""

    cloud_provider: str = "aws"
    output_mode: OutputMode = "cloud"

    log_stream: Optional[str] = None

    def to_platform_config(self) -> Dict[str, Any]:
        return {
            "aws_region": self.aws_region,
            "log_group": self.log_group,
            "log_stream": self.log_stream,
            "cloud_provider": self.cloud_provider,
        }

    def validate_config(self) -> bool:
        if not self.aws_region:
            raise LogConfigError("AWS region is required")
        if not self.log_group:
            raise LogConfigError("AWS log group is required")
        return True


@dataclass
class GCPLoggingConfig(LogConfig):
    """Google Cloud Logging-specific configuration"""

    log_name: str = ""

    project_id: Optional[str] = None

    output_mode: OutputMode = "cloud"
    cloud_provider: str = "gcp"

    def to_platform_config(self) -> Dict[str, Any]:
        return {
            "project_id": self.project_id,
            "log_name": self.log_name,
            "cloud_provider": self.cloud_provider,
        }

    def validate_config(self) -> bool:
        if not self.project_id:
            raise LogConfigError("GCP project ID is required")
        return True


@dataclass
class AzureLogAnalyticsConfig(LogConfig):
    """Azure Log Analytics-specific configuration"""

    workspace_id: Optional[str] = field(
        default_factory=lambda: os.getenv("AZURE_WORKSPACE_ID")
    )
    shared_key: Optional[str] = field(
        default_factory=lambda: os.getenv("AZURE_SHARED_KEY")
    )
    log_type: str = "domolibrary"
    output_mode: OutputMode = field(default="cloud", init=False)
    cloud_provider: str = field(default="azure", init=False)

    def to_platform_config(self) -> Dict[str, Any]:
        return {
            "workspace_id": self.workspace_id,
            "shared_key": self.shared_key,
            "log_type": self.log_type,
            "cloud_provider": self.cloud_provider,
        }

    def validate_config(self) -> bool:
        if not self.workspace_id:
            raise LogConfigError("Azure workspace ID is required")
        if not self.shared_key:
            raise LogConfigError("Azure shared key is required")
        return True

    @classmethod
    def from_env(cls) -> "AzureLogAnalyticsConfig":
        """Create Azure Log Analytics config from environment variables"""
        from ..client.enums import LogLevel

        return cls(
            workspace_id=os.getenv("AZURE_WORKSPACE_ID"),
            shared_key=os.getenv("AZURE_SHARED_KEY"),
            log_type=os.getenv("AZURE_LOG_TYPE", "domolibrary"),
            level=LogLevel.from_string(os.getenv("LOG_LEVEL", "INFO")),
            format=os.getenv("LOG_FORMAT", "json"),
            batch_size=int(os.getenv("LOG_BATCH_SIZE", "100")),
            flush_interval=int(os.getenv("LOG_FLUSH_INTERVAL", "30")),
            correlation_enabled=os.getenv("LOG_CORRELATION_ENABLED", "true").lower()
            == "true",
            include_traceback=os.getenv("LOG_INCLUDE_TRACEBACK", "true").lower()
            == "true",
            max_buffer_size=int(os.getenv("LOG_MAX_BUFFER_SIZE", "1000")),
            pretty_print=os.getenv("LOG_PRETTY_PRINT", "false").lower() == "true",
        )


@dataclass
class LangSmithLogConfig(LogConfig):
    """Configuration for streaming dc_logger output to LangSmith.

    All parameters accept explicit values or fall back to the standard LangChain /
    LangSmith environment variables so existing agent deployments can opt-in
    without additional code changes.

    Attributes:
        api_key: LangSmith API key (`LANGCHAIN_API_KEY` or `LANGSMITH_API_KEY`).
        api_url: LangSmith API endpoint (`LANGCHAIN_ENDPOINT` / `LANGSMITH_ENDPOINT`).
        project_name: Target LangSmith project (`LANGCHAIN_PROJECT`, default
            `dc_logger`).
        tenant_id: Optional tenant identifier (`LANGCHAIN_TENANT_ID`).
        run_type: Logical run type shown in LangSmith UI (`LANGCHAIN_RUN_TYPE`,
            default `"tool"`).
        tags: Static tags applied to every run (comma-separated `LANGCHAIN_TAGS`).
        max_retries: Attempts before surfacing a write failure.
        retry_backoff_seconds: Base sleep between retries.
        timeout_seconds: LangSmith request timeout.
    """

    api_key: Optional[str] = field(
        default_factory=lambda: os.getenv("LANGCHAIN_API_KEY")
        or os.getenv("LANGSMITH_API_KEY")
    )
    api_url: str = field(
        default_factory=lambda: os.getenv("LANGCHAIN_ENDPOINT")
        or os.getenv("LANGSMITH_ENDPOINT")
        or "https://api.smith.langchain.com"
    )
    project_name: str = field(
        default_factory=lambda: os.getenv("LANGCHAIN_PROJECT") or "dc_logger"
    )
    tenant_id: Optional[str] = field(
        default_factory=lambda: os.getenv("LANGCHAIN_TENANT_ID")
    )
    run_type: str = field(
        default_factory=lambda: os.getenv("LANGCHAIN_RUN_TYPE") or "tool"
    )
    tags: List[str] = field(
        default_factory=lambda: _split_env_list("LANGCHAIN_TAGS", ["dc_logger"])
    )
    max_retries: int = 3
    retry_backoff_seconds: float = 1.0
    timeout_seconds: float = 10.0
    cloud_provider: str = "langsmith"
    output_mode: OutputMode = "cloud"

    def to_platform_config(self) -> Dict[str, Any]:
        return {
            "api_key": self.api_key,
            "api_url": self.api_url,
            "project_name": self.project_name,
            "tenant_id": self.tenant_id,
            "run_type": self.run_type,
            "tags": self.tags,
            "max_retries": self.max_retries,
            "retry_backoff_seconds": self.retry_backoff_seconds,
            "timeout_seconds": self.timeout_seconds,
            "cloud_provider": self.cloud_provider,
        }

    def validate_config(self) -> bool:
        if not self.api_key:
            raise LogConfigError(
                "LangSmith API key is required. Set LANGCHAIN_API_KEY or pass api_key."
            )
        if not self.project_name:
            raise LogConfigError("LangSmith project_name is required.")
        return True
