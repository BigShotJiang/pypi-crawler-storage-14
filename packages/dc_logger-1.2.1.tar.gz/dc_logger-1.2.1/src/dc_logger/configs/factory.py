"""Factory functions for creating common logger configurations"""

from typing import Any, List, Optional

from ..client.enums import LogLevel
from .cloud import DatadogLogConfig, LangSmithLogConfig
from .console import ConsoleLogConfig
from .multi_handler import HandlerConfig, MultiHandlerLogConfig


def create_console_config(
    level: LogLevel = LogLevel.INFO, pretty_print: bool = True, **kwargs: Any
) -> ConsoleLogConfig:
    """Create a simple console configuration"""
    return ConsoleLogConfig(level=level, pretty_print=pretty_print, **kwargs)


def create_file_config(
    file_path: str, level: LogLevel = LogLevel.INFO, **kwargs: Any
) -> ConsoleLogConfig:
    """Create a file configuration"""
    return ConsoleLogConfig(
        level=level,
        output_mode="file",
        destination=file_path,
        pretty_print=False,
        **kwargs,
    )


def create_console_file_config(
    file_path: str,
    level: LogLevel = LogLevel.INFO,
    pretty_print: bool = True,
    **kwargs: Any,
) -> MultiHandlerLogConfig:
    """Create a configuration that logs to both console and file"""
    console_config = ConsoleLogConfig(level=level, pretty_print=pretty_print, **kwargs)
    file_config = ConsoleLogConfig(
        level=level,
        output_mode="file",
        destination=file_path,
        pretty_print=False,
        **kwargs,
    )

    return MultiHandlerLogConfig(
        handlers=[
            HandlerConfig(type="console", config=console_config),
            HandlerConfig(type="file", config=file_config),
        ],
        level=level,
        **kwargs,
    )


def create_console_datadog_config(
    datadog_api_key: Optional[str] = None,
    datadog_app_key: Optional[str] = None,
    datadog_site: str = "datadoghq.com",
    datadog_service: str = "domolibrary",
    datadog_env: str = "production",
    level: LogLevel = LogLevel.INFO,
    pretty_print: bool = True,
    **kwargs: Any,
) -> MultiHandlerLogConfig:
    """Create a configuration that logs to both console and Datadog"""
    console_config = ConsoleLogConfig(level=level, pretty_print=pretty_print, **kwargs)
    datadog_config = DatadogLogConfig(
        api_key=datadog_api_key,
        app_key=datadog_app_key,
        site=datadog_site,
        service=datadog_service,
        env=datadog_env,
        level=level,
        **kwargs,
    )

    return MultiHandlerLogConfig(
        handlers=[
            HandlerConfig(type="console", config=console_config),
            HandlerConfig(
                type="cloud",
                config=datadog_config,
                platform_config=datadog_config.to_platform_config(),
            ),
        ],
        level=level,
        **kwargs,
    )


def create_langsmith_config(
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
    project_name: str = "dc_logger",
    run_type: str = "tool",
    tags: Optional[List[str]] = None,
    level: LogLevel = LogLevel.INFO,
    **kwargs: Any,
) -> LangSmithLogConfig:
    """Create a single LangSmith logging configuration.

    Args:
        api_key: Explicit LangSmith key. Falls back to env defaults when omitted.
        api_url: Override the LangSmith API endpoint.
        project_name: Destination project shown in LangSmith UI.
        run_type: Logical run type (e.g., ``"tool"`` or ``"chain"``).
        tags: Static tags to apply to every run; defaults to ``["dc_logger"]``.
        level: Minimum log level for buffered entries.
        **kwargs: Additional `LogConfig` overrides (batch size, flush interval, etc.).

    Returns:
        LangSmithLogConfig: Config ready to pass to ``DCLogger`` or multi-handler factories.
    """
    return LangSmithLogConfig(
        api_key=api_key,
        api_url=api_url,
        project_name=project_name,
        run_type=run_type,
        tags=tags or ["dc_logger"],
        level=level,
        **kwargs,
    )


def create_console_langsmith_config(
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
    project_name: str = "dc_logger",
    run_type: str = "tool",
    tags: Optional[List[str]] = None,
    level: LogLevel = LogLevel.INFO,
    pretty_print: bool = True,
    **kwargs: Any,
) -> MultiHandlerLogConfig:
    """Create a dual console + LangSmith configuration.

    Args:
        api_key: Explicit LangSmith key (defaults to env vars).
        api_url: Custom LangSmith endpoint.
        project_name: Destination LangSmith project.
        run_type: Logical run type label.
        tags: Static tags for every LangSmith run.
        level: Minimum log level for both handlers.
        pretty_print: Toggle pretty JSON in console output.
        **kwargs: Additional `ConsoleLogConfig` / `LogConfig` overrides.

    Returns:
        MultiHandlerLogConfig: Config that routes logs to console and LangSmith.
    """
    console_config = ConsoleLogConfig(level=level, pretty_print=pretty_print, **kwargs)
    langsmith_config = create_langsmith_config(
        api_key=api_key,
        api_url=api_url,
        project_name=project_name,
        run_type=run_type,
        tags=tags,
        level=level,
        **kwargs,
    )

    return MultiHandlerLogConfig(
        handlers=[
            HandlerConfig(type="console", config=console_config),
            HandlerConfig(
                type="cloud",
                config=langsmith_config,
                platform_config=langsmith_config.to_platform_config(),
            ),
        ],
        level=level,
        **kwargs,
    )


def create_console_file_langsmith_config(
    file_path: str,
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
    project_name: str = "dc_logger",
    run_type: str = "tool",
    tags: Optional[List[str]] = None,
    level: LogLevel = LogLevel.INFO,
    pretty_print: bool = True,
    **kwargs: Any,
) -> MultiHandlerLogConfig:
    """Create a console + file + LangSmith configuration.

    Args:
        file_path: Destination path for file handler output.
        api_key: Explicit LangSmith key (defaults to env vars).
        api_url: Custom LangSmith endpoint.
        project_name: Destination LangSmith project.
        run_type: Logical run type label.
        tags: Static tags for LangSmith runs.
        level: Minimum log level for all handlers.
        pretty_print: Pretty-print console output when True.
        **kwargs: Additional handler/config overrides.

    Returns:
        MultiHandlerLogConfig: Config covering console, file, and LangSmith handlers.
    """
    console_config = ConsoleLogConfig(level=level, pretty_print=pretty_print, **kwargs)
    file_config = ConsoleLogConfig(
        level=level,
        output_mode="file",
        destination=file_path,
        pretty_print=False,
        **kwargs,
    )
    langsmith_config = create_langsmith_config(
        api_key=api_key,
        api_url=api_url,
        project_name=project_name,
        run_type=run_type,
        tags=tags,
        level=level,
        **kwargs,
    )

    return MultiHandlerLogConfig(
        handlers=[
            HandlerConfig(type="console", config=console_config),
            HandlerConfig(type="file", config=file_config),
            HandlerConfig(
                type="cloud",
                config=langsmith_config,
                platform_config=langsmith_config.to_platform_config(),
            ),
        ],
        level=level,
        **kwargs,
    )


def create_console_file_datadog_config(
    file_path: str,
    datadog_api_key: Optional[str] = None,
    datadog_app_key: Optional[str] = None,
    datadog_site: str = "datadoghq.com",
    datadog_service: str = "domolibrary",
    datadog_env: str = "production",
    level: LogLevel = LogLevel.INFO,
    pretty_print: bool = True,
    **kwargs: Any,
) -> MultiHandlerLogConfig:
    """Create a configuration that logs to console, file, and Datadog"""
    console_config = ConsoleLogConfig(level=level, pretty_print=pretty_print, **kwargs)
    file_config = ConsoleLogConfig(
        level=level,
        output_mode="file",
        destination=file_path,
        pretty_print=False,
        **kwargs,
    )
    datadog_config = DatadogLogConfig(
        api_key=datadog_api_key,
        app_key=datadog_app_key,
        site=datadog_site,
        service=datadog_service,
        env=datadog_env,
        level=level,
        **kwargs,
    )

    return MultiHandlerLogConfig(
        handlers=[
            HandlerConfig(type="console", config=console_config),
            HandlerConfig(type="file", config=file_config),
            HandlerConfig(
                type="cloud",
                config=datadog_config,
                platform_config=datadog_config.to_platform_config(),
            ),
        ],
        level=level,
        **kwargs,
    )


def create_file_datadog_config(
    file_path: str,
    datadog_api_key: Optional[str] = None,
    datadog_app_key: Optional[str] = None,
    datadog_site: str = "datadoghq.com",
    datadog_service: str = "domolibrary",
    datadog_env: str = "production",
    level: LogLevel = LogLevel.INFO,
    **kwargs: Any,
) -> MultiHandlerLogConfig:
    """Create a configuration that logs to file and Datadog"""
    file_config = ConsoleLogConfig(
        level=level,
        output_mode="file",
        destination=file_path,
        pretty_print=False,
        **kwargs,
    )
    datadog_config = DatadogLogConfig(
        api_key=datadog_api_key,
        app_key=datadog_app_key,
        site=datadog_site,
        service=datadog_service,
        env=datadog_env,
        level=level,
        **kwargs,
    )

    return MultiHandlerLogConfig(
        handlers=[
            HandlerConfig(type="file", config=file_config),
            HandlerConfig(
                type="cloud",
                config=datadog_config,
                platform_config=datadog_config.to_platform_config(),
            ),
        ],
        level=level,
        **kwargs,
    )
