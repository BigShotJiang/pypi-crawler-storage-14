"""Legacy service-layer exports (deprecated).

Import handlers from :mod:`dc_logger.handlers` and use :class:`dc_logger.logger.DCLogger`
instead.  This namespace remains temporarily for backwards compatibility.
"""

import warnings

warnings.warn(
    "dc_logger.services is deprecated; migrate to dc_logger.handlers / DCLogger.",
    DeprecationWarning,
    stacklevel=2,
)
