import asyncio
import datetime as dt
import os
from itertools import count
import time
import uuid
from typing import Any, Dict, List, Optional

from ...client.exceptions import LogHandlerError, LogWriteError
from ...client.models import LogEntry
from .base import CloudHandler


def _parse_timestamp(timestamp: str) -> dt.datetime:
    """Parse ISO timestamps saved on LogEntry into timezone-aware datetimes."""
    try:
        normalized = timestamp
        if normalized.endswith("Z"):
            normalized = normalized[:-1] + "+00:00"
        return dt.datetime.fromisoformat(normalized)
    except Exception:
        return dt.datetime.now(dt.timezone.utc)


class LangSmithHandler(CloudHandler):
    """Send log entries to the LangSmith observability API."""

    def __init__(self, config: Any) -> None:
        super().__init__(config)
        self.tags: List[str] = list(getattr(config, "tags", []) or [])
        self.project_name: str = getattr(config, "project_name", "dc_logger")
        self.run_type: str = getattr(config, "run_type", "tool")
        self.max_retries: int = int(getattr(config, "max_retries", 3))
        self.retry_backoff_seconds: float = float(
            getattr(config, "retry_backoff_seconds", 1.0)
        )
        self.timeout_seconds: float = float(getattr(config, "timeout_seconds", 10.0))
        self._order_counter = count(1)
        self._client = self._create_client()

    def _create_client(self) -> Any:
        """Instantiate the LangSmith client lazily so dependency stays optional."""
        try:
            from langsmith import Client
        except ImportError as exc:  # pragma: no cover - straightforward dependency hint
            raise LogHandlerError(
                "LangSmith integration requires the optional 'langsmith' extra. "
                "Install with `pip install dc_logger[langsmith]`."
            ) from exc

        client_kwargs: Dict[str, Any] = {}
        api_url = self.cloud_config.get("api_url")
        if api_url:
            client_kwargs["api_url"] = api_url
        api_key = self.cloud_config.get("api_key")
        if api_key:
            client_kwargs["api_key"] = api_key
        tenant_id = self.cloud_config.get("tenant_id")
        if tenant_id:
            client_kwargs["tenant_id"] = tenant_id

        # Ensure LangSmith knows which project to use via env var
        if self.project_name and not os.getenv("LANGCHAIN_PROJECT"):
            os.environ["LANGCHAIN_PROJECT"] = self.project_name

        return Client(**client_kwargs)

    async def _send_to_cloud(self, entries: List[LogEntry]) -> bool:
        """Bridge async write contract with the sync LangSmith client."""
        await asyncio.to_thread(self._emit_entries, entries)
        return True

    def _emit_entries(self, entries: List[LogEntry]) -> None:
        for entry in entries:
            payload = self._build_run_payload(entry)
            self._send_with_retry(payload)

    def _build_run_payload(self, entry: LogEntry) -> Dict[str, Any]:
        """Convert a LogEntry into the payload expected by LangSmith create_run."""
        entry_dict = entry.to_dict()
        correlation = entry.correlation
        span_id = getattr(correlation, "span_id", None) if correlation else None
        run_id = span_id or uuid.uuid4().hex
        trace_id = getattr(correlation, "trace_id", None) if correlation else None
        parent_run_id = (
            getattr(correlation, "parent_span_id", None) if correlation else None
        )
        dotted_order = str(next(self._order_counter))

        event_name = entry.action or entry.level.value.upper()
        metadata: Dict[str, Any] = {
            "level": entry.level.value,
            "status": entry.status,
            "method": entry.method,
            "duration_ms": entry.duration_ms,
            "app_name": entry.app_name,
            "user": entry.user,
            "color": entry.color,
            "entity": entry_dict.get("entity"),
            "multi_tenant": entry_dict.get("multi_tenant"),
            "http_details": entry_dict.get("http_details"),
            "extra": entry_dict.get("extra", {}),
        }
        metadata["log_entry"] = entry_dict

        extra_tags: List[str] = []
        extra = entry_dict.get("extra", {})
        if isinstance(extra, dict):
            candidate_tags = extra.get("langsmith_tags")
            if isinstance(candidate_tags, list):
                extra_tags = [str(tag) for tag in candidate_tags]

        combined_tags = list(dict.fromkeys([*self.tags, *extra_tags]))
        timestamp = _parse_timestamp(entry.timestamp)

        inputs = {
            "message": entry.message,
            "level": entry.level.value,
            "action": entry.action,
        }

        outputs = {
            "status": entry.status,
            "extra": entry_dict.get("extra", {}),
        }

        payload: Dict[str, Any] = {
            "name": event_name,
            "inputs": inputs,
            "run_type": self.run_type,
            "project_name": self.project_name,
            "id": run_id,
            "tags": combined_tags,
            "metadata": metadata,
            "extra": metadata,
            "start_time": timestamp,
            "end_time": timestamp,
            "outputs": outputs,
        }

        if trace_id:
            payload["trace_id"] = trace_id
            payload["dotted_order"] = dotted_order
        if parent_run_id:
            payload["parent_run_id"] = parent_run_id

        return payload

    def _send_with_retry(self, payload: Dict[str, Any]) -> None:
        last_error: Optional[Exception] = None
        for attempt in range(1, self.max_retries + 1):
            try:
                self._client.create_run(**payload)
                return
            except Exception as exc:  # pragma: no cover - error paths exercised via retry
                last_error = exc
                if attempt == self.max_retries:
                    break
                time.sleep(self.retry_backoff_seconds * attempt)

        raise LogWriteError(
            f"Failed to send logs to LangSmith after {self.max_retries} attempts"
        ) from last_error
