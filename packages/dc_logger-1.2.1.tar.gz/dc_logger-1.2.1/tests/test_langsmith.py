import asyncio
import sys
import types

import pytest

from dc_logger.client.exceptions import LogConfigError
from dc_logger.client.models import LogEntry
from dc_logger.client.enums import LogLevel
from dc_logger.configs.cloud import LangSmithLogConfig
from dc_logger.handlers.cloud.langsmith import LangSmithHandler


def test_langsmith_config_requires_api_key():
    with pytest.raises(LogConfigError):
        LangSmithLogConfig(api_key=None).validate_config()


def test_langsmith_handler_sends_events(monkeypatch):
    events: list = []

    class DummyClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

        def create_run(self, **payload):
            events.append(payload)

    dummy_module = types.SimpleNamespace(Client=DummyClient)
    monkeypatch.setitem(sys.modules, "langsmith", dummy_module)

    config = LangSmithLogConfig(
        api_key="test-key",
        project_name="observability",
        tags=["base"],
    )
    handler = LangSmithHandler(config)

    entry = LogEntry.create(
        level=LogLevel.INFO,
        message="Hello LangSmith",
        app_name="demo",
        action="demo_action",
        correlation={"trace_id": "trace", "span_id": "span"},
        extra={"langsmith_tags": ["runtime"], "details": "payload"},
    )

    asyncio.run(handler.write([entry]))

    assert events, "LangSmith handler should emit at least one event"
    first_event = events[0]
    assert first_event["name"] == "demo_action"
    assert first_event["tags"] == ["base", "runtime"]
    assert first_event["extra"]["log_entry"]["extra"]["details"] == "payload"
