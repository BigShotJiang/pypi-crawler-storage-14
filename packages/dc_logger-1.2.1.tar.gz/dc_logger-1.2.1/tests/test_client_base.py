import asyncio

import pytest

from dc_logger import ConsoleLogConfig, DCLogger, LogLevel
from dc_logger.client.base import create_dc_logger


def close_logger(logger: DCLogger) -> None:
    """Helper to ensure background tasks are cleaned up during tests."""
    asyncio.run(logger.close())


def test_create_dc_logger_uses_console_config_by_default():
    with pytest.warns(DeprecationWarning):
        logger = create_dc_logger()

    try:
        assert isinstance(logger, DCLogger)
        assert isinstance(logger.config, ConsoleLogConfig)
        assert logger.app_name == "legacy_adapter"
    finally:
        close_logger(logger)


def test_create_dc_logger_respects_custom_config_and_app_name():
    custom_config = ConsoleLogConfig(level=LogLevel.ERROR)

    with pytest.warns(DeprecationWarning):
        logger = create_dc_logger(config=custom_config, app_name="custom-app")

    try:
        assert logger.config is custom_config
        assert logger.app_name == "custom-app"
    finally:
        close_logger(logger)
