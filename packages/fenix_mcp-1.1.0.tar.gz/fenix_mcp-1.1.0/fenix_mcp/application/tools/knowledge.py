# SPDX-License-Identifier: MIT
"""Knowledge tool implementation updated for the expanded Fênix API."""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import Field

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    CategoryStr,
    DateTimeStr,
    DescriptionStr,
    EmojiStr,
    LanguageStr,
    MarkdownStr,
    TagStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    VersionStr,
    sanitize_null,
    sanitize_null_list,
)
from fenix_mcp.domain.knowledge import KnowledgeService, _format_date
from fenix_mcp.infrastructure.context import AppContext


class KnowledgeAction(str, Enum):
    def __new__(cls, value: str, description: str):
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.description = description
        return obj

    # Work items
    WORK_CREATE = (
        "work_create",
        "Creates a work item with title, status and optional links.",
    )
    WORK_LIST = (
        "work_list",
        "Lists work items with status, priority and context filters.",
    )
    WORK_GET = ("work_get", "Gets full details of a work item by ID.")
    WORK_UPDATE = (
        "work_update",
        "Updates specific fields of an existing work item.",
    )
    WORK_DELETE = ("work_delete", "Permanently removes a work item.")
    WORK_BACKLOG = ("work_backlog", "Lists backlog items for a team.")
    WORK_SEARCH = (
        "work_search",
        "Searches work items by text with additional filters.",
    )
    WORK_ANALYTICS = ("work_analytics", "Returns consolidated work item metrics.")
    WORK_BY_BOARD = ("work_by_board", "Lists work items associated with a board.")
    WORK_BY_SPRINT = ("work_by_sprint", "Lists work items associated with a sprint.")
    WORK_BY_EPIC = ("work_by_epic", "Lists work items associated with an epic.")
    WORK_CHILDREN = ("work_children", "Lists child work items of a parent item.")
    WORK_STATUS_UPDATE = (
        "work_status_update",
        "Updates only the status of a work item.",
    )
    WORK_ASSIGN_SPRINT = (
        "work_assign_sprint",
        "Assigns work items to a sprint.",
    )

    # Boards
    BOARD_LIST = ("board_list", "Lists available boards with optional filters.")
    BOARD_BY_TEAM = ("board_by_team", "Lists boards for a specific team.")
    BOARD_FAVORITES = ("board_favorites", "Lists boards marked as favorites.")
    BOARD_GET = ("board_get", "Gets board details by ID.")
    BOARD_COLUMNS = ("board_columns", "Lists columns configured for a board.")

    # Sprints
    SPRINT_LIST = ("sprint_list", "Lists available sprints with optional filters.")
    SPRINT_BY_TEAM = ("sprint_by_team", "Lists sprints associated with a team.")
    SPRINT_ACTIVE = ("sprint_active", "Gets the active sprint for a team.")
    SPRINT_GET = ("sprint_get", "Gets sprint details by ID.")
    SPRINT_WORK_ITEMS = (
        "sprint_work_items",
        "Lists work items linked to a sprint.",
    )

    # Modes
    MODE_CREATE = ("mode_create", "Creates a mode with content and optional metadata.")
    MODE_LIST = ("mode_list", "Lists registered modes.")
    MODE_GET = ("mode_get", "Gets full details of a mode.")
    MODE_UPDATE = ("mode_update", "Updates properties of an existing mode.")
    MODE_DELETE = ("mode_delete", "Removes a mode.")
    MODE_RULE_ADD = ("mode_rule_add", "Associates a rule with a mode.")
    MODE_RULE_REMOVE = (
        "mode_rule_remove",
        "Removes the association of a rule with a mode.",
    )
    MODE_RULES = ("mode_rules", "Lists rules associated with a mode.")

    # Rules
    RULE_CREATE = ("rule_create", "Creates a rule with content and metadata.")
    RULE_LIST = ("rule_list", "Lists registered rules.")
    RULE_GET = ("rule_get", "Gets rule details.")
    RULE_UPDATE = ("rule_update", "Updates an existing rule.")
    RULE_DELETE = ("rule_delete", "Removes a rule.")

    # Documentation
    DOC_CREATE = (
        "doc_create",
        "Creates a documentation item. Requires doc_emoji for page, api_doc, and guide types.",
    )
    DOC_LIST = ("doc_list", "Lists documentation items with filters.")
    DOC_GET = ("doc_get", "Gets documentation item details.")
    DOC_UPDATE = ("doc_update", "Updates a documentation item.")
    DOC_DELETE = ("doc_delete", "Removes a documentation item.")
    DOC_SEARCH = ("doc_search", "Searches documentation items by text.")
    DOC_ROOTS = ("doc_roots", "Lists available root documents.")
    DOC_RECENT = ("doc_recent", "Lists recently accessed documents.")
    DOC_ANALYTICS = ("doc_analytics", "Returns document analytics.")
    DOC_CHILDREN = ("doc_children", "Lists child documents of an item.")
    DOC_TREE = ("doc_tree", "Retrieves the direct tree of a document.")
    DOC_FULL_TREE = ("doc_full_tree", "Retrieves the full documentation tree.")
    DOC_MOVE = ("doc_move", "Moves a document to another parent.")
    DOC_PUBLISH = ("doc_publish", "Changes publication status of a document.")
    DOC_VERSION = ("doc_version", "Generates or retrieves a document version.")
    DOC_DUPLICATE = ("doc_duplicate", "Duplicates an existing document.")

    HELP = ("knowledge_help", "Shows available actions and their uses.")

    @classmethod
    def choices(cls) -> List[str]:
        return [member.value for member in cls]

    @classmethod
    def formatted_help(cls) -> str:
        lines = [
            "| **Action** | **Description** |",
            "| --- | --- |",
        ]
        for member in cls:
            lines.append(f"| `{member.value}` | {member.description} |")
        return "\n".join(lines)


ACTION_FIELD_DESCRIPTION = "Knowledge action. Choose one of the values: " + ", ".join(
    f"`{member.value}` ({member.description.rstrip('.')})."
    for member in KnowledgeAction
)


_ALLOWED_DOC_TYPES = {
    "folder",
    "page",
    "api_doc",
    "guide",
}


class KnowledgeRequest(ToolRequest):
    action: KnowledgeAction = Field(description=ACTION_FIELD_DESCRIPTION)
    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    board_id: Optional[UUIDStr] = Field(
        default=None, description="Associated board ID (UUID)."
    )
    sprint_id: Optional[UUIDStr] = Field(
        default=None, description="Associated sprint ID (UUID)."
    )
    epic_id: Optional[UUIDStr] = Field(
        default=None, description="Associated epic ID (UUID)."
    )
    query: Optional[str] = Field(default=None, description="Filter/search term.")
    return_content: Optional[bool] = Field(
        default=None, description="Return full content."
    )
    return_description: Optional[bool] = Field(
        default=None, description="Return full description."
    )
    return_metadata: Optional[bool] = Field(
        default=None, description="Return full metadata."
    )

    # Work item fields
    work_title: Optional[TitleStr] = Field(default=None, description="Work item title.")
    work_description: Optional[MarkdownStr] = Field(
        default=None, description="Work item description (Markdown)."
    )
    work_type: Optional[str] = Field(
        default="task",
        description="Work item type (epic, feature, story, task, subtask, bug).",
    )
    work_status: Optional[str] = Field(
        default=None,
        description="Work item status (backlog, todo, in_progress, review, testing, done, cancelled).",
    )
    work_priority: Optional[str] = Field(
        default=None,
        description="Work item priority (critical, high, medium, low).",
    )
    story_points: Optional[int] = Field(
        default=None, ge=0, le=100, description="Story points (0-100)."
    )
    assignee_id: Optional[UUIDStr] = Field(
        default=None, description="Assignee ID (UUID)."
    )
    parent_id: Optional[UUIDStr] = Field(
        default=None, description="Parent item ID (UUID)."
    )
    work_due_date: Optional[DateTimeStr] = Field(
        default=None, description="Work item due date (ISO 8601)."
    )
    work_tags: Optional[List[TagStr]] = Field(
        default=None, description="Work item tags."
    )
    work_item_ids: Optional[List[UUIDStr]] = Field(
        default=None,
        description="List of work item IDs for batch operations (UUIDs).",
    )

    # Mode fields
    mode_id: Optional[UUIDStr] = Field(
        default=None, description="Related mode ID (UUID)."
    )
    mode_name: Optional[TitleStr] = Field(default=None, description="Mode name.")
    mode_description: Optional[DescriptionStr] = Field(
        default=None, description="Mode description."
    )
    mode_content: Optional[MarkdownStr] = Field(
        default=None, description="Mode content (Markdown)."
    )
    mode_is_default: Optional[bool] = Field(
        default=None, description="Indicates if the mode is default."
    )
    mode_metadata: Optional[MarkdownStr] = Field(
        default=None, description="Mode metadata for AI processing."
    )

    # Rule fields
    rule_id: Optional[UUIDStr] = Field(
        default=None, description="Related rule ID (UUID)."
    )
    rule_name: Optional[TitleStr] = Field(default=None, description="Rule name.")
    rule_description: Optional[DescriptionStr] = Field(
        default=None, description="Rule description."
    )
    rule_content: Optional[MarkdownStr] = Field(
        default=None, description="Rule content (Markdown)."
    )
    rule_is_default: Optional[bool] = Field(default=None, description="Default rule.")
    rule_metadata: Optional[MarkdownStr] = Field(
        default=None, description="Rule metadata for AI processing."
    )

    # Documentation fields
    doc_title: Optional[TitleStr] = Field(
        default=None, description="Documentation title."
    )
    doc_description: Optional[DescriptionStr] = Field(
        default=None, description="Documentation description."
    )
    doc_content: Optional[MarkdownStr] = Field(
        default=None, description="Documentation content (Markdown)."
    )
    doc_status: Optional[str] = Field(
        default=None,
        description="Documentation status (draft, review, published, archived).",
    )
    doc_type: Optional[str] = Field(
        default=None,
        description="Documentation type. Values: folder, page, api_doc, guide.",
    )
    doc_language: Optional[LanguageStr] = Field(
        default=None, description="Documentation language (e.g.: pt, en, pt-BR)."
    )
    doc_parent_id: Optional[UUIDStr] = Field(
        default=None, description="Parent document ID (UUID)."
    )
    doc_owner_id: Optional[UUIDStr] = Field(
        default=None, description="Owner ID (UUID)."
    )
    doc_reviewer_id: Optional[UUIDStr] = Field(
        default=None, description="Reviewer ID (UUID)."
    )
    doc_version: Optional[VersionStr] = Field(
        default=None, description="Document version (e.g.: 1.0, 2.1.3)."
    )
    doc_category: Optional[CategoryStr] = Field(default=None, description="Category.")
    doc_tags: Optional[List[TagStr]] = Field(default=None, description="Tags.")
    doc_position: Optional[int] = Field(
        default=None, ge=0, description="Desired position when moving documents."
    )
    doc_emoji: Optional[EmojiStr] = Field(
        default=None,
        description="Emoji displayed with the document. REQUIRED for page, api_doc, and guide types (not required for folder).",
    )
    doc_emote: Optional[EmojiStr] = Field(
        default=None, description="Alias for emoji, kept for compatibility."
    )
    doc_keywords: Optional[List[TagStr]] = Field(
        default=None, description="Keywords for search."
    )
    doc_is_public: Optional[bool] = Field(
        default=None, description="Whether the document is public."
    )


class KnowledgeTool(Tool):
    name = "knowledge"
    description = "Fenix Cloud knowledge operations (Work Items, Boards, Sprints, Modes, Rules, Docs)."
    request_model = KnowledgeRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = KnowledgeService(context.api_client, context.logger)

    async def run(self, payload: KnowledgeRequest, context: AppContext):
        action = payload.action
        if action is KnowledgeAction.HELP:
            return await self._handle_help()
        if action.value.startswith("work_"):
            return await self._run_work(payload)
        if action.value.startswith("board_"):
            return await self._run_board(payload)
        if action.value.startswith("sprint_"):
            return await self._run_sprint(payload)
        if action.value.startswith("mode_"):
            return await self._run_mode(payload)
        if action.value.startswith("rule_"):
            return await self._run_rule(payload)
        if action.value.startswith("doc_"):
            return await self._run_doc(payload)
        return text(
            "❌ Invalid action for knowledge.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in KnowledgeAction.choices())
        )

    # ------------------------------------------------------------------
    # Work items
    # ------------------------------------------------------------------
    async def _run_work(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.WORK_CREATE:
            if not payload.work_title:
                return text("❌ Provide work_title to create the item.")
            work = await self._service.work_create(
                {
                    "title": payload.work_title,
                    "description": payload.work_description,
                    "item_type": payload.work_type,
                    "status": payload.work_status,
                    "priority": payload.work_priority,
                    "story_points": payload.story_points,
                    "assignee_id": payload.assignee_id,
                    "sprint_id": payload.sprint_id,
                    "board_id": payload.board_id,
                    "parent_id": payload.parent_id,
                    "due_date": payload.work_due_date,
                    "tags": payload.work_tags,
                }
            )
            return text(_format_work(work, header="✅ Work item created"))

        if action is KnowledgeAction.WORK_LIST:
            items = await self._service.work_list(
                limit=payload.limit,
                offset=payload.offset,
                priority=payload.work_priority,
                type=payload.work_type,
                assignee=payload.assignee_id,
                sprint=payload.sprint_id,
                board=payload.board_id,
            )
            if not items:
                return text("🎯 No work items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🎯 **Work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_GET:
            if not payload.id:
                return text("❌ Provide the work item ID.")
            work = await self._service.work_get(payload.id)
            return text(_format_work(work, header="🎯 Work item details"))

        if action is KnowledgeAction.WORK_UPDATE:
            if not payload.id:
                return text("❌ Provide the work item ID.")
            work = await self._service.work_update(
                payload.id,
                {
                    "title": payload.work_title,
                    "description": payload.work_description,
                    "item_type": payload.work_type,
                    "status": payload.work_status,
                    "priority": payload.work_priority,
                    "story_points": payload.story_points,
                    "assignee_id": payload.assignee_id,
                    "sprint_id": payload.sprint_id,
                    "board_id": payload.board_id,
                    "parent_id": payload.parent_id,
                    "due_date": payload.work_due_date,
                    "tags": payload.work_tags,
                },
            )
            return text(_format_work(work, header="✅ Work item updated"))

        if action is KnowledgeAction.WORK_DELETE:
            if not payload.id:
                return text("❌ Provide the work item ID.")
            await self._service.work_delete(payload.id)
            return text(f"🗑️ Work item {payload.id} removed.")

        if action is KnowledgeAction.WORK_BACKLOG:
            items = await self._service.work_backlog()
            if not items:
                return text("📋 Backlog empty.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"📋 **Backlog ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_SEARCH:
            query = sanitize_null(payload.query)
            if not query:
                return text("❌ Provide query to search work items.")
            items = await self._service.work_search(
                query=query,
                limit=payload.limit,
            )
            if not items:
                return text("🔍 No work items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🔍 **Results ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_ANALYTICS:
            analytics = await self._service.work_analytics()
            lines = ["📊 **Work Items Analytics**"]
            for key, value in analytics.items():
                lines.append(f"- {key}: {value}")
            return text("\n".join(lines))

        if action is KnowledgeAction.WORK_BY_BOARD:
            if not payload.board_id:
                return text("❌ Provide board_id to list items.")
            items = await self._service.work_by_board(board_id=payload.board_id)
            if not items:
                return text("🗂️ No work items for the specified board.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🗂️ **Board items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_BY_SPRINT:
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to list items.")
            items = await self._service.work_by_sprint(sprint_id=payload.sprint_id)
            if not items:
                return text("🏃 No items linked to the specified sprint.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🏃 **Sprint work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_BY_EPIC:
            if not payload.epic_id:
                return text("❌ Provide epic_id to list items.")
            items = await self._service.work_by_epic(epic_id=payload.epic_id)
            if not items:
                return text("📦 No items linked to the specified epic.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"📦 **Epic work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_CHILDREN:
            if not payload.id:
                return text("❌ Provide the parent work item ID.")
            items = await self._service.work_children(payload.id)
            if not items:
                return text("👶 No child items found.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"👶 **Child work items ({len(items)}):**\n\n{body}")

        if action is KnowledgeAction.WORK_STATUS_UPDATE:
            if not payload.id:
                return text("❌ Provide the work item ID.")
            if not payload.work_status:
                return text("❌ Provide work_status to update.")
            work = await self._service.work_update_status(
                payload.id,
                {"status": payload.work_status},
            )
            return text(_format_work(work, header="✅ Status updated"))

        if action is KnowledgeAction.WORK_ASSIGN_SPRINT:
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to assign items.")
            if not payload.work_item_ids:
                return text("❌ Provide work_item_ids with the list of IDs.")
            await self._service.work_assign_to_sprint(
                {
                    "sprint_id": payload.sprint_id,
                    "work_item_ids": payload.work_item_ids,
                }
            )
            count = len(payload.work_item_ids)
            return text(f"✅ {count} work item(s) assigned to sprint.")

        return text(
            "❌ Unsupported work item action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("work_")
            )
        )

    # ------------------------------------------------------------------
    # Boards
    # ------------------------------------------------------------------
    async def _run_board(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.BOARD_LIST:
            boards = await self._service.board_list(
                limit=payload.limit, offset=payload.offset
            )
            if not boards:
                return text("🗂️ No boards found.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"🗂️ **Boards ({len(boards)}):**\n\n{body}")

        if action is KnowledgeAction.BOARD_BY_TEAM:
            boards = await self._service.board_list_by_team()
            if not boards:
                return text("🗂️ No boards registered for the team.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"🗂️ **Team boards ({len(boards)}):**\n\n{body}")

        if action is KnowledgeAction.BOARD_FAVORITES:
            boards = await self._service.board_favorites()
            if not boards:
                return text("⭐ No favorite boards registered.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"⭐ **Favorite boards ({len(boards)}):**\n\n{body}")

        if action is KnowledgeAction.BOARD_GET:
            if not payload.board_id:
                return text("❌ Provide board_id to get details.")
            board = await self._service.board_get(payload.board_id)
            return text(_format_board(board, header="🗂️ Board details"))

        if action is KnowledgeAction.BOARD_COLUMNS:
            if not payload.board_id:
                return text("❌ Provide board_id to list columns.")
            columns = await self._service.board_columns(payload.board_id)
            if not columns:
                return text("📊 Board has no columns registered.")
            body = "\n".join(
                f"- {col.get('name', 'Unnamed')} (ID: {col.get('id')})"
                for col in columns
            )
            return text(f"📊 **Board columns:**\n{body}")

        return text(
            "❌ Unsupported board action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("board_")
            )
        )

    # ------------------------------------------------------------------
    # Sprints
    # ------------------------------------------------------------------
    async def _run_sprint(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.SPRINT_LIST:
            sprints = await self._service.sprint_list(
                limit=payload.limit, offset=payload.offset
            )
            if not sprints:
                return text("🏃 No sprints found.")
            body = "\n\n".join(_format_sprint(sprint) for sprint in sprints)
            return text(f"🏃 **Sprints ({len(sprints)}):**\n\n{body}")

        if action is KnowledgeAction.SPRINT_BY_TEAM:
            sprints = await self._service.sprint_list_by_team()
            if not sprints:
                return text("🏃 No sprints registered for the team.")
            body = "\n\n".join(_format_sprint(sprint) for sprint in sprints)
            return text(f"🏃 **Team sprints ({len(sprints)}):**\n\n{body}")

        if action is KnowledgeAction.SPRINT_ACTIVE:
            sprint = await self._service.sprint_active()
            if not sprint:
                return text("⏳ No active sprint at the moment.")
            return text(_format_sprint(sprint, header="⏳ Active sprint"))

        if action is KnowledgeAction.SPRINT_GET:
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to get details.")
            sprint = await self._service.sprint_get(payload.sprint_id)
            return text(_format_sprint(sprint, header="🏃 Sprint details"))

        if action is KnowledgeAction.SPRINT_WORK_ITEMS:
            if not payload.sprint_id:
                return text("❌ Provide sprint_id to list items.")
            items = await self._service.sprint_work_items(payload.sprint_id)
            if not items:
                return text("🏃 No items linked to the specified sprint.")
            body = "\n\n".join(_format_work(item) for item in items)
            return text(f"🏃 **Sprint items ({len(items)}):**\n\n{body}")

        return text(
            "❌ Unsupported sprint action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("sprint_")
            )
        )

    # ------------------------------------------------------------------
    # Modes
    # ------------------------------------------------------------------
    async def _run_mode(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.MODE_CREATE:
            if not payload.mode_name:
                return text("❌ Provide mode_name to create the mode.")
            mode = await self._service.mode_create(
                {
                    "name": payload.mode_name,
                    "description": payload.mode_description,
                    "content": payload.mode_content,
                    "is_default": payload.mode_is_default,
                    "metadata": payload.mode_metadata,
                }
            )
            return text(_format_mode(mode, header="✅ Mode created"))

        if action is KnowledgeAction.MODE_LIST:
            modes = await self._service.mode_list(
                include_rules=payload.return_metadata,
                return_description=payload.return_description,
                return_metadata=payload.return_metadata,
            )
            if not modes:
                return text("🎭 No modes found.")
            body = "\n\n".join(_format_mode(mode) for mode in modes)
            return text(f"🎭 **Modes ({len(modes)}):**\n\n{body}")

        if action is KnowledgeAction.MODE_GET:
            if not payload.mode_id:
                return text("❌ Provide mode_id to get details.")
            mode = await self._service.mode_get(
                payload.mode_id,
                return_description=payload.return_description,
                return_metadata=payload.return_metadata,
            )
            return text(_format_mode(mode, header="🎭 Mode details"))

        if action is KnowledgeAction.MODE_UPDATE:
            if not payload.mode_id:
                return text("❌ Provide mode_id to update.")
            mode = await self._service.mode_update(
                payload.mode_id,
                {
                    "name": payload.mode_name,
                    "description": payload.mode_description,
                    "content": payload.mode_content,
                    "is_default": payload.mode_is_default,
                    "metadata": payload.mode_metadata,
                },
            )
            return text(_format_mode(mode, header="✅ Mode updated"))

        if action is KnowledgeAction.MODE_DELETE:
            if not payload.mode_id:
                return text("❌ Provide mode_id to remove.")
            await self._service.mode_delete(payload.mode_id)
            return text(f"🗑️ Mode {payload.mode_id} removed.")

        if action is KnowledgeAction.MODE_RULE_ADD:
            if not payload.mode_id or not payload.rule_id:
                return text("❌ Provide mode_id and rule_id to associate.")
            link = await self._service.mode_rule_add(payload.mode_id, payload.rule_id)
            return text(
                "\n".join(
                    [
                        "🔗 **Rule associated with mode!**",
                        f"Mode: {link.get('modeId', payload.mode_id)}",
                        f"Rule: {link.get('ruleId', payload.rule_id)}",
                    ]
                )
            )

        if action is KnowledgeAction.MODE_RULE_REMOVE:
            if not payload.mode_id or not payload.rule_id:
                return text("❌ Provide mode_id and rule_id to remove the association.")
            await self._service.mode_rule_remove(payload.mode_id, payload.rule_id)
            return text("🔗 Association removed.")

        if action is KnowledgeAction.MODE_RULES:
            if payload.mode_id:
                rules = await self._service.mode_rules(payload.mode_id)
                context_label = f"mode {payload.mode_id}"
            elif payload.rule_id:
                rules = await self._service.mode_rules_for_rule(payload.rule_id)
                context_label = f"rule {payload.rule_id}"
            else:
                return text("❌ Provide mode_id or rule_id to list associations.")
            if not rules:
                return text("🔗 No associations found.")
            body = "\n".join(
                f"- {item.get('name', 'Unnamed')} (ID: {item.get('id')})"
                for item in rules
            )
            return text(f"🔗 **Associations for {context_label}:**\n{body}")

        return text(
            "❌ Unsupported mode action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("mode_")
            )
        )

    # ------------------------------------------------------------------
    # Rules
    # ------------------------------------------------------------------
    async def _run_rule(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.RULE_CREATE:
            if not payload.rule_name or not payload.rule_content:
                return text("❌ Provide rule_name and rule_content.")
            rule = await self._service.rule_create(
                {
                    "name": payload.rule_name,
                    "description": payload.rule_description,
                    "content": payload.rule_content,
                    "is_default": payload.rule_is_default,
                    "metadata": payload.rule_metadata,
                }
            )
            return text(_format_rule(rule, header="✅ Rule created"))

        if action is KnowledgeAction.RULE_LIST:
            rules = await self._service.rule_list(
                return_description=payload.return_description,
                return_metadata=payload.return_metadata,
                return_modes=payload.return_metadata,
            )
            if not rules:
                return text("📋 No rules found.")
            body = "\n\n".join(_format_rule(rule) for rule in rules)
            return text(f"📋 **Rules ({len(rules)}):**\n\n{body}")

        if action is KnowledgeAction.RULE_GET:
            if not payload.rule_id:
                return text("❌ Provide rule_id to get details.")
            rule = await self._service.rule_get(
                payload.rule_id,
                return_description=payload.return_description,
                return_metadata=payload.return_metadata,
                return_modes=payload.return_metadata,
            )
            return text(_format_rule(rule, header="📋 Rule details"))

        if action is KnowledgeAction.RULE_UPDATE:
            if not payload.rule_id:
                return text("❌ Provide rule_id to update.")
            rule = await self._service.rule_update(
                payload.rule_id,
                {
                    "name": payload.rule_name,
                    "description": payload.rule_description,
                    "content": payload.rule_content,
                    "is_default": payload.rule_is_default,
                    "metadata": payload.rule_metadata,
                },
            )
            return text(_format_rule(rule, header="✅ Rule updated"))

        if action is KnowledgeAction.RULE_DELETE:
            if not payload.rule_id:
                return text("❌ Provide rule_id to remove.")
            await self._service.rule_delete(payload.rule_id)
            return text(f"🗑️ Rule {payload.rule_id} removed.")

        return text(
            "❌ Unsupported rule action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("rule_")
            )
        )

    # ------------------------------------------------------------------
    # Documentation
    # ------------------------------------------------------------------
    async def _run_doc(self, payload: KnowledgeRequest):
        action = payload.action
        if action is KnowledgeAction.DOC_CREATE:
            if not payload.doc_title:
                return text("❌ Provide doc_title to create the documentation.")
            if payload.doc_type and payload.doc_type not in _ALLOWED_DOC_TYPES:
                allowed = ", ".join(sorted(_ALLOWED_DOC_TYPES))
                return text(
                    "❌ Invalid doc_type. Use one of the supported values: " + allowed
                )
            # Emoji is required for page, api_doc, guide (not for folder)
            doc_type = sanitize_null(payload.doc_type) or "page"
            emoji = sanitize_null(payload.doc_emoji or payload.doc_emote)
            if doc_type != "folder" and not emoji:
                return text(
                    "❌ Provide doc_emoji to create documentation. "
                    "Emoji is required for page, api_doc, and guide types."
                )
            doc = await self._service.doc_create(
                {
                    "title": payload.doc_title,
                    "description": sanitize_null(payload.doc_description),
                    "content": sanitize_null(payload.doc_content),
                    "status": sanitize_null(payload.doc_status),
                    "doc_type": sanitize_null(payload.doc_type),
                    "language": sanitize_null(payload.doc_language),
                    "parent_id": sanitize_null(payload.doc_parent_id),
                    "owner_user_id": sanitize_null(payload.doc_owner_id),
                    "reviewer_user_id": sanitize_null(payload.doc_reviewer_id),
                    "version": sanitize_null(payload.doc_version),
                    "category": sanitize_null(payload.doc_category),
                    "tags": sanitize_null_list(payload.doc_tags),
                    "emoji": sanitize_null(payload.doc_emoji or payload.doc_emote),
                    "keywords": sanitize_null_list(payload.doc_keywords),
                    "is_public": payload.doc_is_public,
                }
            )
            return text(_format_doc(doc, header="✅ Documentation created"))

        if action is KnowledgeAction.DOC_LIST:
            docs = await self._service.doc_list(
                limit=payload.limit,
                offset=payload.offset,
                returnContent=payload.return_content,
            )
            if not docs:
                return text("📄 No documentation found.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"📄 **Documents ({len(docs)}):**\n\n{body}")

        if action is KnowledgeAction.DOC_GET:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            doc = await self._service.doc_get(
                payload.id,
                returnContent=payload.return_content,
            )
            return text(_format_doc(doc, header="📄 Documentation details"))

        if action is KnowledgeAction.DOC_UPDATE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if payload.doc_type and payload.doc_type not in _ALLOWED_DOC_TYPES:
                allowed = ", ".join(sorted(_ALLOWED_DOC_TYPES))
                return text(
                    "❌ Invalid doc_type. Use one of the supported values: " + allowed
                )
            doc = await self._service.doc_update(
                payload.id,
                {
                    "title": sanitize_null(payload.doc_title),
                    "description": sanitize_null(payload.doc_description),
                    "content": sanitize_null(payload.doc_content),
                    "status": sanitize_null(payload.doc_status),
                    "doc_type": sanitize_null(payload.doc_type),
                    "language": sanitize_null(payload.doc_language),
                    "parent_id": sanitize_null(payload.doc_parent_id),
                    "owner_user_id": sanitize_null(payload.doc_owner_id),
                    "reviewer_user_id": sanitize_null(payload.doc_reviewer_id),
                    "version": sanitize_null(payload.doc_version),
                    "category": sanitize_null(payload.doc_category),
                    "tags": sanitize_null_list(payload.doc_tags),
                    "emoji": sanitize_null(payload.doc_emoji or payload.doc_emote),
                    "keywords": sanitize_null_list(payload.doc_keywords),
                    "is_public": payload.doc_is_public,
                },
            )
            return text(_format_doc(doc, header="✅ Documentation updated"))

        if action is KnowledgeAction.DOC_DELETE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            await self._service.doc_delete(payload.id)
            return text(f"🗑️ Documentation {payload.id} removed.")

        if action is KnowledgeAction.DOC_SEARCH:
            query = sanitize_null(payload.query)
            if not query:
                return text("❌ Provide query to search documentation.")
            docs = await self._service.doc_search(
                query=query,
                limit=payload.limit,
            )
            if not docs:
                return text("🔍 No documents found for the specified filters.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"🔍 **Results ({len(docs)}):**\n\n{body}")

        if action is KnowledgeAction.DOC_ROOTS:
            docs = await self._service.doc_roots()
            if not docs:
                return text("📚 No roots found.")
            body = "\n".join(
                f"- {doc.get('title', 'Untitled')} (ID: {doc.get('id')})"
                for doc in docs
            )
            return text(f"📚 **Documentation roots:**\n{body}")

        if action is KnowledgeAction.DOC_RECENT:
            docs = await self._service.doc_recent(
                limit=payload.limit,
            )
            if not docs:
                return text("🕒 No recent documentation found.")
            body = "\n\n".join(_format_doc(doc) for doc in docs)
            return text(f"🕒 **Recent documents ({len(docs)}):**\n\n{body}")

        if action is KnowledgeAction.DOC_ANALYTICS:
            analytics = await self._service.doc_analytics()
            lines = ["📊 **Documentation Analytics**"]
            for key, value in analytics.items():
                lines.append(f"- {key}: {value}")
            return text("\n".join(lines))

        if action is KnowledgeAction.DOC_CHILDREN:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            docs = await self._service.doc_children(payload.id)
            if not docs:
                return text("📄 No children registered for the specified document.")
            body = "\n".join(
                f"- {doc.get('title', 'Untitled')} (ID: {doc.get('id')})"
                for doc in docs
            )
            return text(f"📄 **Children:**\n{body}")

        if action is KnowledgeAction.DOC_TREE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            tree = await self._service.doc_tree(payload.id)
            return text(f"🌳 **Documentation tree for {payload.id}:**\n{tree}")

        if action is KnowledgeAction.DOC_FULL_TREE:
            tree = await self._service.doc_full_tree()
            return text(f"🌳 **Full documentation tree:**\n{tree}")

        if action is KnowledgeAction.DOC_MOVE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if payload.doc_parent_id is None and payload.doc_position is None:
                return text("❌ Provide doc_parent_id, doc_position or both to move.")
            move_payload = {
                "new_parent_id": payload.doc_parent_id,
                "new_position": payload.doc_position,
            }
            doc = await self._service.doc_move(payload.id, move_payload)
            return text(_format_doc(doc, header="📦 Documentation moved"))

        if action is KnowledgeAction.DOC_PUBLISH:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            result = await self._service.doc_publish(payload.id)
            return text(f"🗞️ Document published: {result}")

        if action is KnowledgeAction.DOC_VERSION:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if not payload.doc_version:
                return text(
                    "❌ Provide doc_version with the version number/identifier."
                )
            version_payload = {
                "title": payload.doc_title or f"Version {payload.doc_version}",
                "version": payload.doc_version,
                "content": payload.doc_content,
            }
            doc = await self._service.doc_version(payload.id, version_payload)
            return text(_format_doc(doc, header="🗞️ New version created"))

        if action is KnowledgeAction.DOC_DUPLICATE:
            if not payload.id:
                return text("❌ Provide the documentation ID.")
            if not payload.doc_title:
                return text("❌ Provide doc_title to name the copy.")
            doc = await self._service.doc_duplicate(
                payload.id,
                {
                    "title": payload.doc_title,
                },
            )
            return text(_format_doc(doc, header="🗂️ Document duplicated"))

        return text(
            "❌ Unsupported documentation action.\n\nChoose one of the values:\n"
            + "\n".join(
                f"- `{value}`"
                for value in KnowledgeAction.choices()
                if value.startswith("doc_")
            )
        )

    async def _handle_help(self):
        return text(
            "📚 **Available actions for knowledge**\n\n"
            + KnowledgeAction.formatted_help()
        )


def _format_work(item: Dict[str, Any], *, header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    # Extract title
    title = item.get("title") or item.get("name") or "Untitled"

    # Extract status
    status = item.get("status") or item.get("state") or "unknown"

    # Extract priority
    priority = item.get("priority") or item.get("priority_level") or "undefined"

    # Extract ID
    item_id = item.get("id", "N/A")

    # Extract assignee - check both assignee_id and assignee object
    assignee = item.get("assignee_id")
    if not assignee and item.get("assignee"):
        assignee = item.get("assignee", {}).get("name") or item.get("assignee", {}).get(
            "id"
        )
    if not assignee:
        assignee = "N/A"

    lines.extend(
        [
            f"🎯 **{title}**",
            f"ID: {item_id}",
            f"Status: {status}",
            f"Priority: {priority}",
            f"Assignee: {assignee}",
        ]
    )
    if item.get("due_date") or item.get("dueDate"):
        lines.append(
            f"Due date: {_format_date(item.get('due_date') or item.get('dueDate'))}"
        )
    if item.get("tags"):
        tags = item.get("tags", [])
        if tags:
            lines.append(f"Tags: {', '.join(tags)}")
    return "\n".join(lines)


def _format_board(board: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🗂️ **{board.get('name', 'Unnamed')}**",
            f"ID: {board.get('id', 'N/A')}",
            f"Team: {board.get('team_id', 'N/A')}",
            f"Columns: {len(board.get('columns', []))}",
        ]
    )
    return "\n".join(lines)


def _format_sprint(sprint: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🏃 **{sprint.get('name', 'Unnamed')}**",
            f"ID: {sprint.get('id', 'N/A')}",
            f"Status: {sprint.get('status', 'N/A')}",
            f"Team: {sprint.get('team_id', 'N/A')}",
        ]
    )
    if sprint.get("start_date") or sprint.get("startDate"):
        lines.append(
            f"Start: {_format_date(sprint.get('start_date') or sprint.get('startDate'))}"
        )
    if sprint.get("end_date") or sprint.get("endDate"):
        lines.append(
            f"End: {_format_date(sprint.get('end_date') or sprint.get('endDate'))}"
        )
    return "\n".join(lines)


def _format_mode(mode: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"🎭 **{mode.get('name', 'Unnamed')}**",
            f"ID: {mode.get('id', 'N/A')}",
            f"Default: {mode.get('is_default', False)}",
        ]
    )
    if mode.get("description"):
        lines.append(f"Description: {mode['description']}")
    return "\n".join(lines)


def _format_rule(rule: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"📋 **{rule.get('name', 'Unnamed')}**",
            f"ID: {rule.get('id', 'N/A')}",
            f"Default: {rule.get('is_default', False)}",
        ]
    )
    if rule.get("description"):
        lines.append(f"Description: {rule['description']}")
    return "\n".join(lines)


def _format_doc(doc: Dict[str, Any], header: Optional[str] = None) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")
    lines.extend(
        [
            f"📄 **{doc.get('title') or doc.get('name', 'Untitled')}**",
            f"ID: {doc.get('id', 'N/A')}",
            f"Status: {doc.get('status', 'N/A')}",
            f"Team: {doc.get('team_id', 'N/A')}",
        ]
    )
    if doc.get("updated_at") or doc.get("updatedAt"):
        lines.append(
            f"Updated at: {_format_date(doc.get('updated_at') or doc.get('updatedAt'))}"
        )
    return "\n".join(lines)


__all__ = ["KnowledgeTool", "KnowledgeAction"]
