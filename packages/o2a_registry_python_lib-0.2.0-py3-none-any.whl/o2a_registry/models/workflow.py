from datetime import datetime

from pydantic import BaseModel, ConfigDict, AliasGenerator, Field
from pydantic.alias_generators import to_camel


class MountWorkflow(BaseModel):
    """
    Class to automatically create a mount event, when editing or creating an item with :py:class:`o2a_registry.models.EditItem` or :py:class:`o2a_registry.models.EditItem`.
    """

    model_config = ConfigDict(
        alias_generator=AliasGenerator(serialization_alias=to_camel)
    )

    #: Label of the mount event.
    mount_label: str = Field(..., min_length=1)

    #: Datetime when the item was/is mounted.
    mount_date: datetime

    #: If a version should be automatically created for the item.
    version: bool = False


class UnMountWorkflow(BaseModel):
    """
    Class to automatically create a mount event, when editing or creating an item with :py:class:`o2a_registry.models.EditItem` or :py:class:`o2a_registry.models.EditItem`.
    """

    model_config = ConfigDict(
        alias_generator=AliasGenerator(serialization_alias=to_camel)
    )

    #: Label of the mount event.
    unmount_label: str = Field(..., min_length=1)

    #: Datetime when the item was/is mounted.
    unmount_date: datetime

    #: If a version should be automatically created for the item.
    version: bool = False


class DecommissionWorkflow(BaseModel):
    """
    Class to automatically create a decommissioned event, when setting the status of the item to decomissioned with :py:class:`o2a_registry.models.EditItem` or :py:class:`o2a_registry.models.EditItem`.
    """

    model_config = ConfigDict(
        alias_generator=AliasGenerator(serialization_alias=to_camel)
    )

    #: Label of the decommissioned event.
    decommission_label: str = Field(..., min_length=1)

    #: Datetime when the item was/is decommissioned.
    decommission_data: datetime

    #: If a version should be automatically created for the item.
    version: bool


class Workflow(BaseModel):
    model_config = ConfigDict(
        alias_generator=AliasGenerator(serialization_alias=to_camel)
    )

    parent: MountWorkflow | UnMountWorkflow | None = None
    decommission: DecommissionWorkflow | None = None
