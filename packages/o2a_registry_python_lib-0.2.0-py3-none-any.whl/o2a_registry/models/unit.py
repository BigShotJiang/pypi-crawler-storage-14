from datetime import datetime
from uuid import UUID
from pydantic import AliasPath, BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel


class Unit(BaseModel):
    """
    Unit class returned from the registry API
    """

    model_config = ConfigDict(alias_generator=to_camel)

    #: Unit unique identifier.
    uuid: UUID = Field(validation_alias=AliasPath("@uuid"))

    #: Unit id
    id: int

    #: When the unit was created
    created: datetime | None = None

    #: When the unit was last modified
    last_modified: datetime | None = None

    #: Unit code
    code: str | None = None

    #: Unit name
    name: str | None = None

    #: Typical use of the unit
    typicalUse: str | None = None

    #: Unified Code for Units of Measure
    ucum: str | None = None

    #: MathML symbol (https://de.wikipedia.org/wiki/Mathematical_Markup_Language)
    mathML: str | None = None

    #: If visible in UI
    visible: bool
