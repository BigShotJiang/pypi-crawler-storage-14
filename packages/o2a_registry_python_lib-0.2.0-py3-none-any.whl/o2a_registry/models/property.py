from datetime import datetime
from uuid import UUID
from pydantic import AliasPath, BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

from o2a_registry.models.unit import Unit
from o2a_registry.models.vocable import Vocable


class Property(BaseModel):
    """
    Property class returned from the registry API
    """

    model_config = ConfigDict(alias_generator=to_camel)

    #: Property unique identifier.
    uuid: UUID = Field(validation_alias=AliasPath("@uuid"))

    #: When the property was created
    created: datetime | None = None

    #: When the property was last modified
    last_modified: datetime | None = None

    id: int

    name: str

    lower_bound: int

    upper_bound: int

    unit: Unit

    type: Vocable
