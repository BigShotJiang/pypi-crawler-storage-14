# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""Image management operations.

Author: A M (am@bbdevs.com)
Created At: 08 Nov 2025
"""

from __future__ import annotations

import json
import re
from collections.abc import AsyncIterator
from pathlib import Path
from typing import TYPE_CHECKING, Any

from dockpycore.logging import get_logger, log_context

from .models import Image, ImageInspect


if TYPE_CHECKING:
    from .http_client import DockerHTTPClient


__all__ = ["ImageManager"]

logger = get_logger(__name__)


class ImageManager:
    """Manage Docker images.

    Provides methods for image lifecycle management, building,
    and inspection.

    Usage:
        async with AsyncDockerClient() as client:
            # Pull an image
            image = await client.images.pull("nginx:latest")

            # List images
            images = await client.images.list()

            # Tag image
            await client.images.tag("nginx:latest", "myregistry.com/nginx:v1")

            # Push image
            await client.images.push("myregistry.com/nginx:v1")

            # Remove image
            await client.images.remove("nginx:latest")
    """

    def __init__(self, client: DockerHTTPClient):
        """Initialize image manager.

        Args:
            client: HTTP client for API communication
        """
        self._client = client
        self.logger = get_logger("dockpysdk.images")

    async def list(
        self,
        *,
        all: bool = False,
        filters: dict[str, Any] | None = None,
        shared_size: bool = False,
    ) -> list[Image]:
        """List images.

        Args:
            all: Include untagged images
            filters: Filter images
            shared_size: Include shared size

        Returns:
            List of images

        Example:
            # List all images
            images = await manager.list(all=True)

            # List images by repository
            images = await manager.list(
                filters={"reference": ["nginx"]}
            )
        """
        with log_context(operation="image_list"):
            self.logger.debug("image_list", all=all)

            params: dict[str, Any] = {
                "all": all,
                "shared-size": shared_size,
            }
            if filters:
                params["filters"] = json.dumps(filters)

            response = await self._client.get("/images/json", params=params)
            data = response.json()

            images = [Image.from_api(item) for item in data]

            self.logger.info("image_list_complete", count=len(images))

            return images

    async def pull(
        self,
        repository: str,
        *,
        tag: str = "latest",
        quiet: bool = False,
    ) -> Image:
        """Pull an image from registry.

        Args:
            repository: Repository name (e.g., "nginx", "myregistry.com/image")
            tag: Image tag (default: latest)
            quiet: Suppress output

        Returns:
            Pulled image

        Example:
            image = await manager.pull("nginx", tag="1.21")
            image = await manager.pull("myregistry.com/app", tag="v1.0")
        """
        with log_context(operation="image_pull", repository=repository):
            image_ref = f"{repository}:{tag}"
            self.logger.info("image_pull_start", image=image_ref)

            params = {"fromImage": repository, "tag": tag}
            if quiet:
                params["quiet"] = quiet

            await self._client.post(
                "/images/create",
                params=params,
            )

            self.logger.info("image_pulled", image=image_ref)

            # Return image info
            return await self.inspect(image_ref)

    async def push(
        self,
        repository: str,
        *,
        tag: str = "latest",
        quiet: bool = False,
    ) -> None:
        """Push an image to registry.

        Args:
            repository: Repository name
            tag: Image tag
            quiet: Suppress output

        Example:
            await manager.push("myregistry.com/app", tag="v1.0")
        """
        with log_context(operation="image_push", repository=repository):
            image_ref = f"{repository}:{tag}"
            self.logger.info("image_push_start", image=image_ref)

            params = {"tag": image_ref}
            if quiet:
                params["quiet"] = quiet

            await self._client.post(
                f"/images/{repository}/push",
                params=params,
            )

            self.logger.info("image_pushed", image=image_ref)

    async def tag(
        self,
        source: str,
        repository: str,
        *,
        tag: str = "latest",
    ) -> None:
        """Tag an image.

        Args:
            source: Source image name (e.g., "nginx:latest")
            repository: Target repository
            tag: Target tag

        Example:
            await manager.tag("nginx:latest", "myregistry.com/nginx", tag="v1.0")
        """
        with log_context(
            operation="image_tag",
            source=source,
            target=f"{repository}:{tag}",
        ):
            self.logger.info(
                "image_tag",
                source=source,
                repository=repository,
                tag=tag,
            )

            params = {
                "repo": repository,
                "tag": tag,
            }

            await self._client.post(
                f"/images/{source}/tag",
                params=params,
            )

            self.logger.info(
                "image_tagged",
                source=source,
                target=f"{repository}:{tag}",
            )

    async def inspect(self, image_id: str) -> Image:
        """Get image details.

        Args:
            image_id: Image ID or name

        Returns:
            Image with details

        Example:
            image = await manager.inspect("nginx:latest")
            print(f"Size: {image.size} bytes")
        """
        with log_context(operation="image_inspect", image_id=image_id):
            self.logger.debug("image_inspect", image_id=image_id)

            response = await self._client.get(f"/images/{image_id}/json")
            data = response.json()

            # Convert inspect response to Image model
            image = Image(
                id=data["Id"],
                repo_tags=data.get("RepoTags") or [],
                repo_digests=data.get("RepoDigests") or [],
                size=data.get("Size", 0),
                virtual_size=data.get("VirtualSize", 0),
                created=data.get("Created", 0),
                shared_size=data.get("SharedSize"),
                labels=data.get("Config", {}).get("Labels") or {},
            )

            self.logger.debug("image_inspected", image_id=image_id)

            return image

    async def inspect_detailed(self, image_id: str) -> ImageInspect:
        """Get detailed image information.

        Args:
            image_id: Image ID or name

        Returns:
            Detailed image information

        Example:
            details = await manager.inspect_detailed("nginx:latest")
            print(f"Architecture: {details.architecture}")
            print(f"OS: {details.os}")
        """
        with log_context(operation="image_inspect_detailed", image_id=image_id):
            response = await self._client.get(f"/images/{image_id}/json")
            data = response.json()

            return ImageInspect.from_api(data)

    async def remove(
        self,
        image_id: str,
        *,
        force: bool = False,
        noprune: bool = False,
    ) -> None:
        """Remove an image.

        Args:
            image_id: Image ID or name
            force: Force removal
            noprune: Do not delete untagged parents

        Example:
            await manager.remove("nginx:latest", force=True)
        """
        with log_context(operation="image_remove", image_id=image_id):
            self.logger.info(
                "image_remove",
                image_id=image_id,
                force=force,
                noprune=noprune,
            )

            params = {"force": force, "noprune": noprune}

            await self._client.delete(f"/images/{image_id}", params=params)

            self.logger.info("image_removed", image_id=image_id)

    async def history(self, image_id: str) -> list[dict[str, Any]]:
        """Get image history.

        Args:
            image_id: Image ID or name

        Returns:
            List of history entries

        Example:
            history = await manager.history("nginx:latest")
            for entry in history:
                print(f"Created: {entry['Created']}")
                print(f"By: {entry['CreatedBy']}")
        """
        with log_context(operation="image_history", image_id=image_id):
            self.logger.debug("image_history", image_id=image_id)

            response = await self._client.get(f"/images/{image_id}/history")
            data = response.json()

            self.logger.info("image_history_complete", image_id=image_id, count=len(data))

            return data

    async def prune(
        self,
        *,
        filters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Prune unused images.

        Args:
            filters: Filter pruning (e.g., {"dangling": ["true"]})

        Returns:
            Prune result with deleted images and freed space

        Example:
            result = await manager.prune()
            print(f"Deleted images: {len(result['ImagesDeleted'])}")
            print(f"Freed space: {result['SpaceReclaimed']}")
        """
        with log_context(operation="image_prune"):
            self.logger.info("image_prune_start")

            params: dict[str, Any] = {}
            if filters:
                params["filters"] = json.dumps(filters)

            response = await self._client.post("/images/prune", params=params)
            data = response.json()

            self.logger.info(
                "image_prune_complete",
                deleted_count=len(data.get("ImagesDeleted", [])),
                space_freed=data.get("SpaceReclaimed", 0),
            )

            return data

    async def search(
        self,
        term: str,
        *,
        limit: int = 25,
    ) -> list[dict[str, Any]]:
        """Search for images in registry.

        Args:
            term: Search term
            limit: Number of results

        Returns:
            List of search results

        Example:
            results = await manager.search("nginx", limit=10)
            for result in results:
                print(f"{result['Name']}: {result['Description']}")
        """
        with log_context(operation="image_search", term=term):
            self.logger.debug("image_search", term=term, limit=limit)

            params = {"term": term, "limit": limit}

            response = await self._client.get(
                "/images/search",
                params=params,
            )
            data = response.json()

            self.logger.info("image_search_complete", term=term, count=len(data))

            return data

    async def build(
        self,
        dockerfile_content: str | None = None,
        *,
        tag: str | None = None,
        quiet: bool = False,
        nocache: bool = False,
        rm: bool = True,
        forcerm: bool = False,
        memory: int | None = None,
        memswap: int | None = None,
        cpushares: int | None = None,
        cpusetcpus: str | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Build an image.

        Args:
            dockerfile_content: Dockerfile content
            tag: Image tag
            quiet: Suppress output
            nocache: Do not use cache
            rm: Remove intermediate containers
            forcerm: Force remove intermediate containers
            memory: Memory limit
            memswap: Memory swap limit
            cpushares: CPU shares
            cpusetcpus: CPUs to use

        Yields:
            Build output lines

        Example:
            async for line in manager.build(
                dockerfile_content="FROM nginx\\nRUN apt-get update",
                tag="myapp:latest"
            ):
                if "stream" in line:
                    print(line["stream"], end="")
        """
        with log_context(operation="image_build", tag=tag):
            self.logger.info("image_build_start", tag=tag)

            params: dict[str, Any] = {
                "quiet": quiet,
                "nocache": nocache,
                "rm": rm,
                "forcerm": forcerm,
            }

            if tag:
                params["t"] = tag
            if memory:
                params["memory"] = memory
            if memswap:
                params["memswap"] = memswap
            if cpushares:
                params["cpushares"] = cpushares
            if cpusetcpus:
                params["cpusetcpus"] = cpusetcpus

            # Prepare request body
            body = dockerfile_content or ""

            async with self._client.stream(
                "POST",
                "/build",
                params=params,
                content=body,
            ) as response:
                async for line in response.aiter_lines():
                    if line:
                        try:
                            data = json.loads(line)
                            yield data
                        except json.JSONDecodeError:
                            self.logger.warning("invalid_build_response", line=line)
                            continue

            self.logger.info("image_build_complete", tag=tag)

    async def load(self, tar_path: Path | str) -> Image:
        """Load image from tar file.

        Args:
            tar_path: Path to tar file containing the image

        Returns:
            Loaded image

        Example:
            image = await manager.load("/path/to/image.tar")
            print(f"Loaded: {image.repo_tags}")
        """
        path = Path(tar_path)

        with log_context(operation="image_load", tar_path=str(path)):
            self.logger.info("image_load_start", tar_path=str(path))

            # Read tar file
            tar_data = path.read_bytes()

            # POST to /images/load with tar content
            response = await self._client.post(
                "/images/load",
                content=tar_data,
                headers={"Content-Type": "application/x-tar"},
            )

            # Parse response to extract image info
            data = response.json()
            stream = data.get("stream", "")

            # Extract image reference from response
            # Patterns: "Loaded image: name:tag" or "Loaded image ID: sha256:..."
            image_ref = None
            if (match := re.search(r"Loaded image: ([^\s\n]+)", stream)) or (
                match := re.search(r"Loaded image ID: ([^\s\n]+)", stream)
            ):
                image_ref = match.group(1)

            self.logger.info("image_load_complete", tar_path=str(path), image_ref=image_ref)

            # Return image info
            if image_ref:
                return await self.inspect(image_ref)

            # If no reference found, return minimal image
            return Image(
                id="",
                repo_tags=[],
                repo_digests=[],
                size=0,
                virtual_size=0,
                created=0,
                shared_size=None,
                labels={},
            )

    async def save(self, image_id: str, output_path: Path | str) -> Path:
        """Save image to tar file.

        Args:
            image_id: Image ID or name to save
            output_path: Path to output tar file

        Returns:
            Path to saved tar file

        Example:
            path = await manager.save("nginx:latest", "/tmp/nginx.tar")
            print(f"Saved to: {path}")
        """
        path = Path(output_path)

        with log_context(operation="image_save", image_id=image_id, output_path=str(path)):
            self.logger.info("image_save_start", image_id=image_id, output_path=str(path))

            # Stream GET from /images/{name}/get
            async with self._client.stream("GET", f"/images/{image_id}/get") as response:
                # Write streamed chunks to file
                with path.open("wb") as f:
                    async for chunk in response.aiter_bytes():
                        f.write(chunk)

            self.logger.info("image_save_complete", image_id=image_id, output_path=str(path))

            return path
