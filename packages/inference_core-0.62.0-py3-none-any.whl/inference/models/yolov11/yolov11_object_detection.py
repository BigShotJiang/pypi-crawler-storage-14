from inference.models.yolov8.yolov8_object_detection import YOLOv8ObjectDetection


class YOLOv11ObjectDetection(YOLOv8ObjectDetection):
    pass
