# IPyKernel

Use the `ipykernel` pack to install the [ipykernel](https://ipython.org/) into the user python environment.
This provides a Python 3 kernel for notebooks in either the {doc}`jupyterlab` or {doc}`notebook` interfaces:

:::{code-block} yaml
packs:
  ipykernel: {}
:::
