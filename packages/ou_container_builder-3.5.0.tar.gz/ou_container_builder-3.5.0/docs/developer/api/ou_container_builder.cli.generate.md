# `ou_container_builder.cli.generate`

```{eval-rst}
.. automodule:: ou_container_builder.cli.generate
   :members:
```
