# `ou_container_builder.packs.xfce4`

```{eval-rst}
.. automodule:: ou_container_builder.packs.xfce4
   :members:
```
