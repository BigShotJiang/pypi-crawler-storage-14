# `ou_container_builder.cli.version`

```{eval-rst}
.. automodule:: ou_container_builder.cli.version
   :members:
```
