# `ou_container_builder.core.content`

```{eval-rst}
.. automodule:: ou_container_builder.core.content
   :members:
```
