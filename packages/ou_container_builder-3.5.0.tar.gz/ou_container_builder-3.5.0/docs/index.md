# OU Container Builder

The OU Container Builder is a command-line application to build a Virtual Computing Environment (VCE) image for use in the
OpenComputing Lab or running locally.

```{tableofcontents}
```
