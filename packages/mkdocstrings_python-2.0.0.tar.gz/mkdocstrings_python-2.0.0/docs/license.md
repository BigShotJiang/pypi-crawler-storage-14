---
title: License
hide:
- feedback
---

# License

```
--8<-- "LICENSE"
```
