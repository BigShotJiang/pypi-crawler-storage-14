
class FileUtil:

    @staticmethod
    def get_file_name(file_path):
        return file_path.split('/')[-1]