class SQLUtil:
    """SQL语句生成工具类"""

    @staticmethod
    def insert(table: str, data: dict, returning: str = None) -> str:
        """
        生成INSERT SQL语句

        Args:
            table: 表名
            data: 要插入的数据字典 {列名: 值}
            returning: 返回指定列的值（可选）

        Returns:
            INSERT SQL语句
        """
        columns = ', '.join(data.keys())
        placeholders = ', '.join([f":{col}" for col in data.keys()])
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"

        if returning:
            sql += f" RETURNING {returning}"

        return sql

    @staticmethod
    def batch_insert(table: str, data_list: list) -> str:
        """
        生成批量INSERT SQL语句

        Args:
            table: 表名
            data_list: 要插入的数据列表 [{列名: 值}, ...]

        Returns:
            批量INSERT SQL语句
        """
        if not data_list:
            return ""

        columns = ', '.join(data_list[0].keys())
        placeholders = ', '.join([f":{col}" for col in data_list[0].keys()])
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"

        # 为批量插入添加额外的VALUES子句
        for i in range(1, len(data_list)):
            placeholders = ', '.join([f":{col}_{i}" for col in data_list[i].keys()])
            sql += f", ({placeholders})"

        return sql

    @staticmethod
    def update(table: str, data: dict, where: dict = None, where_clause: str = None) -> str:
        """
        生成UPDATE SQL语句

        Args:
            table: 表名
            data: 要更新的数据字典 {列名: 值}
            where: WHERE条件字典 {列名: 值}
            where_clause: 自定义WHERE子句（可选）

        Returns:
            UPDATE SQL语句
        """
        if not data:
            raise ValueError("更新数据不能为空")

        set_clause = ', '.join([f"{col} = :{col}" for col in data.keys()])
        sql = f"UPDATE {table} SET {set_clause}"

        # 处理WHERE条件
        if where_clause:
            sql += f" WHERE {where_clause}"
        elif where:
            where_parts = []
            for col in where.keys():
                where_parts.append(f"{col} = :where_{col}")
            if where_parts:
                sql += " WHERE " + " AND ".join(where_parts)

        return sql

    @staticmethod
    def delete(table: str, where: dict = None, where_clause: str = None) -> str:
        """
        生成DELETE SQL语句

        Args:
            table: 表名
            where: WHERE条件字典 {列名: 值}
            where_clause: 自定义WHERE子句（可选）

        Returns:
            DELETE SQL语句
        """
        sql = f"DELETE FROM {table}"

        # 处理WHERE条件
        if where_clause:
            sql += f" WHERE {where_clause}"
        elif where:
            where_parts = []
            for col in where.keys():
                where_parts.append(f"{col} = :where_{col}")
            if where_parts:
                sql += " WHERE " + " AND ".join(where_parts)
        else:
            # 防止意外删除所有数据
            raise ValueError("删除操作必须提供WHERE条件")

        return sql
