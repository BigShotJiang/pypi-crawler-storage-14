from pydantic import BaseModel, Field


class Diff(BaseModel):
    attribute_name: str = Field(..., alias="attributeName")
    old_value: str = Field(..., alias="oldValue")
    new_value: str = Field(..., alias="newValue")
