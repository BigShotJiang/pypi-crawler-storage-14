from moysklad_api.methods import MSMethod
from moysklad_api.types import MetaArray, Product


class GetProducts(MSMethod):
    """
    Use this method to get list of products.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/dictionaries/#suschnosti-towar
    """

    __return__ = MetaArray[Product]
    __api_method__ = "entity/product"
