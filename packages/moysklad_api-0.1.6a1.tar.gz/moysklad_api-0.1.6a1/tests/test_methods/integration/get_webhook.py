import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Demand, Webhook
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetWebhook:
    """
    Example with options: --webhook-id=1234-5678
    """

    async def test_method(
        self, real_client: MoyskladAPI, webhook_id: str, api_params
    ):
        webhook = await real_client.get_webhook(webhook_id, **api_params)
        assert isinstance(webhook, Webhook)
        assert webhook.id == webhook_id
        assert webhook.action is not None

        expanded = api_params.get("expand", None)
        if expanded:
            assert_expand(expanded, webhook)
