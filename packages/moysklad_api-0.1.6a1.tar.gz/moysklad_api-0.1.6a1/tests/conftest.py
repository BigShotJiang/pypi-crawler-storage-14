import os
import json

import pytest
import pytest_asyncio
from dotenv import load_dotenv

from moysklad_api import MoyskladAPI
from moysklad_api.enums import EntityType
from moysklad_api.types import ProductUpdate
from tests.mocked_client import MockedClient

entities = [entity_type.lower() for entity_type in EntityType]
default_params = [
    'expand',
    'filters',
    'limit',
    'offset',
    'search',
    'order',
    'paginate'
]


def pytest_addoption(parser):

    for i in entities:
        parser.addoption(f"--{i}-id", action="store", default=None, help=f"{i} id")

    for i in default_params:
        parser.addoption(f"--{i}", action="store", default=None, help=f"{i} id")

    parser.addoption("--products", action="store", default=None, help="JSON products list")
    parser.addoption("--update-fields", action="store", default=None, help="JSON update fields")


@pytest.fixture
def api_params(request):
    params = {}

    for param in default_params:
        value = request.config.getoption(f"--{param}")
        if value is not None:
            params[param] = value

    return params


@pytest.fixture
def products(request):
    products_json = request.config.getoption("--products")
    if products_json:
        products_data = json.loads(products_json)
        return [ProductUpdate(**product_data) for product_data in products_data]
    return []


@pytest.fixture
def expand(request):
    return request.config.getoption("--expand")


@pytest.fixture
def update_fields(request):
    fields = request.config.getoption("--update-fields")
    if fields:
        return json.loads(fields)
    return {}


@pytest_asyncio.fixture
async def client() -> MockedClient:
    c = MockedClient(token="mocked_token")
    yield c
    await c.close()


@pytest.fixture
def real_client() -> MoyskladAPI:
    load_dotenv()
    token = os.getenv("TOKEN")
    return MoyskladAPI(token=token)


for entity in entities:
    fixture_name = f"{entity}_id"
    exec(f"""
@pytest.fixture
def {fixture_name}(request):
    return request.config.getoption("--{entity}-id")
""")
