import pandas as pd


veri = pd.read_csv("../../veri_setleri/APPSTORE_APP_REVIEWS.csv", sep="|")

print(veri.head())

