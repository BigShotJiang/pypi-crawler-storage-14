"""Core websocket plumbing shared by all stream helpers."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Mapping, Protocol
from uuid import uuid4

from pydantic import BaseModel

from .schemas import AssetEnvelope, AssetMeta


class WebSocketConnection(Protocol):
    """Minimal websocket interface required by the helper."""

    async def send(self, data: Any) -> None:  # pragma: no cover - protocol stub
        ...

    async def recv(self) -> Any:  # pragma: no cover - protocol stub
        ...

    async def close(self) -> None:  # pragma: no cover - protocol stub
        ...


JsonDumps = Callable[[Any], str]
JsonLoads = Callable[[str], Any]
WebSocketConnect = Callable[[str], Awaitable[WebSocketConnection]]


class EnvelopeValidationError(RuntimeError):
    """Raised when a received envelope does not meet expectations."""


class AssetWebSocketBase:
    """Connection- and JSON-handling helpers shared by stream mixins."""

    def __init__(
        self,
        url: str,
        asset_id: str,
        *,
        connect: WebSocketConnect | None = None,
        json_dumps: JsonDumps | None = None,
        json_loads: JsonLoads | None = None,
    ) -> None:
        self.url = url
        self.asset_id = asset_id
        self._connect_factory: WebSocketConnect = connect or self._default_connect
        self._connection: WebSocketConnection | None = None
        self._json_dumps = json_dumps or json.dumps
        self._json_loads = json_loads or json.loads

    @property
    def is_connected(self) -> bool:
        return self._connection is not None

    async def connect(self) -> None:
        if self.is_connected:
            return
        self._connection = await self._connect_factory(self.url)

    async def close(self) -> None:
        connection = self._connection
        self._connection = None
        if connection is None:
            return
        try:
            await connection.close()
        except AttributeError:
            pass

    async def send_json(self, message: dict[str, Any]) -> None:
        connection = self._require_connection()
        await connection.send(self._json_dumps(message))

    async def send_model(self, model: BaseModel) -> None:
        await self.send_json(model.model_dump(mode="json"))

    async def receive_json(
        self,
        *,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        raw = await self._receive_raw(timeout=timeout)
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        if isinstance(raw, str):
            result = self._json_loads(raw)
            if not isinstance(result, dict):
                raise TypeError(f"Expected JSON object, got {type(result)!r}")
            return result
        if isinstance(raw, dict):
            return raw
        raise TypeError(f"Unsupported websocket payload type: {type(raw)!r}")

    async def receive_envelope(
        self,
        *,
        timeout: float | None = None,
        include_connection_frames: bool = False,
        expected_type: str | None = None,
        expected_stream: str | None = None,
        expected_asset_id: str | None = None,
    ) -> AssetEnvelope:
        while True:
            payload = await self.receive_json(timeout=timeout)
            if isinstance(payload, dict) and payload.get("type") == "connection":
                if include_connection_frames:
                    return AssetEnvelope.model_validate(payload)
                continue
            envelope = AssetEnvelope.model_validate(payload)
            self._validate_envelope(
                envelope,
                expected_type=expected_type,
                expected_stream=expected_stream,
                expected_asset_id=expected_asset_id or self.asset_id,
            )
            return envelope

    async def _receive_raw(
        self,
        *,
        timeout: float | None,
    ) -> Any:
        connection = self._require_connection()
        receiver = connection.recv()
        if timeout is None:
            return await receiver
        return await asyncio.wait_for(receiver, timeout)

    def _validate_envelope(
        self,
        envelope: AssetEnvelope,
        *,
        expected_type: str | None,
        expected_stream: str | None,
        expected_asset_id: str | None,
    ) -> None:
        if expected_type and envelope.type != expected_type:
            raise EnvelopeValidationError(
                f"Expected envelope type '{expected_type}', got '{envelope.type}'"
            )
        if expected_stream and envelope.meta.stream != expected_stream:
            raise EnvelopeValidationError(
                f"Expected stream '{expected_stream}', got '{envelope.meta.stream}'"
            )
        if expected_asset_id and envelope.meta.asset_id != expected_asset_id:
            raise EnvelopeValidationError(
                "Received envelope for unexpected asset "
                f"'{envelope.meta.asset_id}', expected '{expected_asset_id}'"
            )

    def _build_envelope(
        self,
        *,
        message_type: str,
        stream: str,
        payload: Mapping[str, Any] | BaseModel | None,
        correlation_id: str | None,
        sent_at: datetime | None,
        sequence: int | None = None,
    ) -> AssetEnvelope:
        if payload is None:
            payload_body: dict[str, Any] = {}
        elif isinstance(payload, BaseModel):
            payload_body = payload.model_dump(mode="json")
        else:
            payload_body = dict(payload)

        meta = AssetMeta(
            asset_id=self.asset_id,
            stream=stream,
            sent_at=sent_at or datetime.now(timezone.utc),
            correlation_id=correlation_id or str(uuid4()),
            sequence=sequence,
        )
        return AssetEnvelope(type=message_type, meta=meta, payload=payload_body)

    def _require_connection(self) -> WebSocketConnection:
        if self._connection is None:
            raise RuntimeError(
                "WebSocket connection has not been established. Call 'connect' first."
            )
        return self._connection

    @staticmethod
    def _prepare_payload(payload: Mapping[str, Any] | BaseModel | None) -> dict[str, Any]:
        if payload is None:
            return {}
        if isinstance(payload, BaseModel):
            return payload.model_dump(mode="json")
        return dict(payload)

    @staticmethod
    def _prepare_result(result: Mapping[str, Any] | BaseModel | Any) -> Any:
        if isinstance(result, BaseModel):
            return result.model_dump(mode="json")
        if isinstance(result, Mapping):
            return dict(result)
        return result

    async def __aenter__(self) -> "AssetWebSocketBase":
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    @staticmethod
    async def _default_connect(url: str) -> WebSocketConnection:
        try:
            import websockets
        except ImportError as exc:  # pragma: no cover - defensive error path
            raise RuntimeError(
                "The 'websockets' package is required for runtime websocket connections. "
                "Install it with 'pip install websockets'."
            ) from exc
        return await websockets.connect(url)
