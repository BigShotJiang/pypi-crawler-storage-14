"""Track stream helpers."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from pydantic import BaseModel

from .base import AssetWebSocketBase
from .schemas import AssetEnvelope

Payload = Mapping[str, Any] | BaseModel


class TrackStreamMixin(AssetWebSocketBase):
    async def create_track(
        self,
        *,
        track_id: str | None = None,
        name: str | None = None,
        track_type: str | None = None,
        description: str | None = None,
        metadata: Mapping[str, Any] | BaseModel | None = None,
        initial_position: Mapping[str, Any] | BaseModel | None = None,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        if track_id is not None and ("track_id" not in body or body["track_id"] is None):
            body["track_id"] = track_id
        if name is not None and "name" not in body:
            body["name"] = name
        if track_type is not None and "type" not in body:
            body["type"] = track_type
        if description is not None and "description" not in body:
            body["description"] = description
        if metadata is not None and ("metadata" not in body or body["metadata"] is None):
            body["metadata"] = self._prepare_payload(metadata)
        if initial_position is not None and (
            "initial_position" not in body or body["initial_position"] is None
        ):
            body["initial_position"] = self._prepare_payload(initial_position)

        envelope = self._build_envelope(
            message_type="track:create",
            stream="tracks",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="track:create:ack",
            expected_stream="tracks",
            timeout=timeout,
        )

    async def update_track(
        self,
        track_id: str,
        *,
        name: str | None = None,
        track_type: str | None = None,
        description: str | None = None,
        latest_position: Mapping[str, Any] | BaseModel | None = None,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        body["track_id"] = track_id
        if name is not None and "name" not in body:
            body["name"] = name
        if track_type is not None and "type" not in body:
            body["type"] = track_type
        if description is not None and "description" not in body:
            body["description"] = description
        if latest_position is not None:
            body["latest_position"] = self._prepare_payload(latest_position)

        envelope = self._build_envelope(
            message_type="track:update",
            stream="tracks",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="track:update:ack",
            expected_stream="tracks",
            timeout=timeout,
        )
