"""Settings stream helpers."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from pydantic import BaseModel

from .base import AssetWebSocketBase
from .schemas import AssetEnvelope

Payload = Mapping[str, Any] | BaseModel


class SettingsStreamMixin(AssetWebSocketBase):
    async def send_settings_update(
        self,
        *,
        settings: Mapping[str, Any] | BaseModel | None = None,
        mode: str | None = None,
        replace: bool | None = None,
        reset: bool | None = None,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        if settings is not None and "settings" not in body:
            body["settings"] = self._prepare_payload(settings)
        if mode is not None and "mode" not in body:
            body["mode"] = mode
        if replace is not None and "replace" not in body:
            body["replace"] = replace
        if reset is not None and "reset" not in body:
            body["reset"] = reset

        envelope = self._build_envelope(
            message_type="settings:update",
            stream="settings",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="settings:update:ack",
            expected_stream="settings",
            timeout=timeout,
        )
