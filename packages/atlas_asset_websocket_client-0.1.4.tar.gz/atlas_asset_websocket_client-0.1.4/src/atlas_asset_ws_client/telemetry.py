"""Telemetry helpers for the asset websocket client."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from pydantic import BaseModel

from .base import AssetWebSocketBase
from .schemas import AssetEnvelope

Payload = Mapping[str, Any] | BaseModel


class TelemetryStreamMixin(AssetWebSocketBase):
    async def send_telemetry_update(
        self,
        payload: Payload,
        *,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        sequence: int | None = None,
    ) -> AssetEnvelope:
        envelope = self._build_envelope(
            message_type="telemetry:update",
            stream="telemetry",
            payload=payload,
            correlation_id=correlation_id,
            sent_at=sent_at,
            sequence=sequence,
        )
        await self.send_model(envelope)
        return envelope
