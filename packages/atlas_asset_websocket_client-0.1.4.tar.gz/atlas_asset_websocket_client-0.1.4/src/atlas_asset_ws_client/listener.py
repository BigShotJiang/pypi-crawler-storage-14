"""Event-listening helpers for continous command processing."""

from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator, Awaitable, Callable

from .schemas import AssetEnvelope

AsyncEnvelopeHandler = Callable[[AssetEnvelope], Awaitable[None]]


async def listen(
    client: Any,
    *,
    include_connection_frames: bool = False,
    timeout: float | None = None,
) -> AsyncIterator[AssetEnvelope]:
    """Yield every envelope coming from the asset websocket."""
    while True:
        envelope = await client.receive_envelope(
            include_connection_frames=include_connection_frames,
            timeout=timeout,
        )
        yield envelope


async def process_command_queue(
    client: Any,
    handler: AsyncEnvelopeHandler,
    *,
    initial_request: bool = True,
    timeout: float | None = None,
    stop_event: asyncio.Event | None = None,
) -> None:
    """Keep handling command_queue updates until the stop event flips."""
    if initial_request:
        queue = await client.request_command_queue(timeout=timeout)
        await handler(queue)

    async for envelope in listen(client, timeout=timeout):
        if stop_event and stop_event.is_set():
            break
        if envelope.meta.stream == "commands" and envelope.type.startswith("command_queue"):
            await handler(envelope)
            if stop_event and stop_event.is_set():
                break
