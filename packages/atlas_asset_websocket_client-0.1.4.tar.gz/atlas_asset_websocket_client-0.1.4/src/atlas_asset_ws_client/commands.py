"""Command stream helpers (command completion and queue sync)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from pydantic import BaseModel

from .base import AssetWebSocketBase
from .schemas import AssetEnvelope

Payload = Mapping[str, Any] | BaseModel


class CommandStreamMixin(AssetWebSocketBase):
    async def complete_command(
        self,
        *,
        command_id: str | None = None,
        queue_index: int | None = None,
        status: str | None = None,
        result: Mapping[str, Any] | BaseModel | Any | None = None,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        if command_id is not None and "command_id" not in body:
            body["command_id"] = command_id
        if queue_index is not None:
            body.setdefault("index", queue_index)
            body.setdefault("queue_index", queue_index)
        if status is not None and "status" not in body:
            body["status"] = status
        if result is not None and "result" not in body:
            body["result"] = self._prepare_result(result)

        envelope = self._build_envelope(
            message_type="command:complete",
            stream="commands",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="command:complete:ack",
            expected_stream="commands",
            timeout=timeout,
        )

    async def request_command_queue(
        self,
        *,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        envelope = self._build_envelope(
            message_type="command_queue:request",
            stream="commands",
            payload=None,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="command_queue:data",
            expected_stream="commands",
            timeout=timeout,
        )
