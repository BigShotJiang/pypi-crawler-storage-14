"""GeoFeature stream helpers."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from pydantic import BaseModel

from .base import AssetWebSocketBase
from .schemas import AssetEnvelope

Payload = Mapping[str, Any] | BaseModel


class GeofeatureStreamMixin(AssetWebSocketBase):
    async def create_geofeature(
        self,
        *,
        id: str,
        name: str,
        description: str | None = None,
        type: str,
        geometry_type: str,
        geometry: dict[str, Any] | None = None,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        body.setdefault("id", id)
        body.setdefault("name", name)
        body.setdefault("type", type)
        body.setdefault("geometry_type", geometry_type)
        if description is not None and "description" not in body:
            body["description"] = description
        if geometry is not None and "geometry" not in body:
            body["geometry"] = geometry

        envelope = self._build_envelope(
            message_type="geofeature:create",
            stream="geofeatures",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="geofeature:create:ack",
            expected_stream="geofeatures",
            timeout=timeout,
        )

    async def update_geofeature(
        self,
        *,
        id: str,
        name: str | None = None,
        description: str | None = None,
        type: str | None = None,
        geometry_type: str | None = None,
        geometry: dict[str, Any] | None = None,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        body.setdefault("id", id)
        if name is not None and "name" not in body:
            body["name"] = name
        if description is not None and "description" not in body:
            body["description"] = description
        if type is not None and "type" not in body:
            body["type"] = type
        if geometry_type is not None and "geometry_type" not in body:
            body["geometry_type"] = geometry_type
        if geometry is not None and "geometry" not in body:
            body["geometry"] = geometry

        envelope = self._build_envelope(
            message_type="geofeature:update",
            stream="geofeatures",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="geofeature:update:ack",
            expected_stream="geofeatures",
            timeout=timeout,
        )

    async def delete_geofeature(
        self,
        *,
        id: str,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        body.setdefault("id", id)

        envelope = self._build_envelope(
            message_type="geofeature:delete",
            stream="geofeatures",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="geofeature:delete:ack",
            expected_stream="geofeatures",
            timeout=timeout,
        )

    async def list_geofeatures(
        self,
        *,
        limit: int = 100,
        offset: int = 0,
        payload: Payload | None = None,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        body = self._prepare_payload(payload)
        body.setdefault("limit", limit)
        body.setdefault("offset", offset)

        envelope = self._build_envelope(
            message_type="geofeature:list",
            stream="geofeatures",
            payload=body,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="geofeature:list:ack",
            expected_stream="geofeatures",
            timeout=timeout,
        )
