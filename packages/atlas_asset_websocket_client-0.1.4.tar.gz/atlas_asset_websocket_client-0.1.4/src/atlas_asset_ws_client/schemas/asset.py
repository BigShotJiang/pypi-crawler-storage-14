"""Asset-specific websocket schemas."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .common import MetaBase, PayloadBase


class AssetMeta(MetaBase):
    """Metadata for asset websocket messages."""

    asset_id: str = Field(..., description="Unique asset identifier")
    stream: str = Field(..., description="Logical stream name (telemetry, commands, media, etc.)")
    sent_at: datetime | None = Field(
        None, description="ISO timestamp when the asset emitted the message"
    )
    sequence: int | None = Field(None, description="Optional sequence number for ordered streams")


class AssetEnvelope(BaseModel):
    """Envelope that wraps asset websocket payloads."""

    type: str = Field(..., description="Domain event/action discriminator")
    meta: AssetMeta = Field(..., description="Envelope metadata for routing and correlation")
    payload: dict[str, Any] | PayloadBase = Field(
        default_factory=dict,
        description="Domain-specific payload body",
    )

    model_config = {
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }


class TelemetryPayload(PayloadBase):
    location: dict[str, float] | None = Field(
        None, description="Geographic coordinates provided by the asset"
    )
    battery_pct: float | None = Field(None, description="Battery percentage")
    altitude_m: float | None = Field(None, description="Altitude in meters")


class CommandCompletionPayload(PayloadBase):
    command_id: str | None = Field(None, description="Identifier of the completed command")
    index: int | None = Field(None, description="Queue index that triggered the completion")
    queue_index: int | None = Field(None, description="Alias for queue index")
    status: str | None = Field(None, description="Human-readable completion status")
    result: Any | None = Field(None, description="Result payload returned by the asset")

    def __init__(
        self,
        *,
        command_id: str | None = None,
        index: int | None = None,
        queue_index: int | None = None,
        status: str | None = None,
        result: Any | None = None,
        **data: Any,
    ) -> None:
        payload_data: dict[str, Any] = {
            "command_id": command_id,
            "index": index,
            "queue_index": queue_index,
            "status": status,
            "result": result,
        }
        super().__init__(**payload_data, **data)


class TrackPayload(PayloadBase):
    track_id: str | None = Field(None, description="Optional client-provided track ID")
    name: str | None = Field(None, description="Track display name")
    type: str | None = Field(None, description="Track type/category")
    description: str | None = Field(None, description="Optional description")
    metadata: dict[str, Any] | None = Field(None, description="Arbitrary metadata")
    initial_position: dict[str, Any] | None = Field(None, description="Starting position")
    latest_position: dict[str, Any] | None = Field(None, description="Most recent position")

    def __init__(
        self,
        *,
        track_id: str | None = None,
        name: str | None = None,
        type: str | None = None,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        initial_position: dict[str, Any] | None = None,
        latest_position: dict[str, Any] | None = None,
        **data: Any,
    ) -> None:
        payload_data: dict[str, Any] = {
            "track_id": track_id,
            "name": name,
            "type": type,
            "description": description,
            "metadata": metadata,
            "initial_position": initial_position,
            "latest_position": latest_position,
        }
        super().__init__(**payload_data, **data)


class GeofeaturePayload(PayloadBase):
    id: str | None = Field(None, description="Geofeature identifier")
    name: str | None = Field(None, description="Human-friendly name")
    description: str | None = Field(None, description="Longer form description")
    type: str | None = Field(None, description="Geofeature type (area, corridor, etc.)")
    geometry_type: str | None = Field(None, description="Geometry type (Point, Polygon, etc.)")
    geometry: dict[str, Any] | None = Field(None, description="Geometry data structure")

    def __init__(
        self,
        *,
        id: str | None = None,
        name: str | None = None,
        description: str | None = None,
        type: str | None = None,
        geometry_type: str | None = None,
        geometry: dict[str, Any] | None = None,
        **data: Any,
    ) -> None:
        payload_data: dict[str, Any] = {
            "id": id,
            "name": name,
            "description": description,
            "type": type,
            "geometry_type": geometry_type,
            "geometry": geometry,
        }
        super().__init__(**payload_data, **data)


class SettingsPayload(PayloadBase):
    settings: dict[str, Any] | None = Field(None, description="Settings map")
    mode: str | None = Field(None, description="Update mode (e.g., merge, replace)")
    replace: bool | None = Field(None, description="Whether to replace existing settings")
    reset: bool | None = Field(None, description="Whether to reset to defaults")

    def __init__(
        self,
        *,
        settings: dict[str, Any] | None = None,
        mode: str | None = None,
        replace: bool | None = None,
        reset: bool | None = None,
        **data: Any,
    ) -> None:
        payload_data: dict[str, Any] = {
            "settings": settings,
            "mode": mode,
            "replace": replace,
            "reset": reset,
        }
        super().__init__(**payload_data, **data)
