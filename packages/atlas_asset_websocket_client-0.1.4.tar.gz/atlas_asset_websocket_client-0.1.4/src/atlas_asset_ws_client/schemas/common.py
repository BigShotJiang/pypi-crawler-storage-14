"""Shared base models for websocket envelopes."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class MetaBase(BaseModel):
    """Base metadata shared by websocket envelopes."""

    correlation_id: str | None = None
    published_at: datetime | None = None
    extra: dict[str, Any] = Field(default_factory=dict)

    model_config = {
        "extra": "allow",
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }


class PayloadBase(BaseModel):
    """Base class for payload containers."""

    model_config = {
        "extra": "allow",
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }
