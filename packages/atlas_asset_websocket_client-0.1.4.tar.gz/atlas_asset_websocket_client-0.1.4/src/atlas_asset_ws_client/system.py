"""System stream helpers (handshake, heartbeat)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Mapping

from pydantic import BaseModel

from .base import AssetWebSocketBase
from .schemas import AssetEnvelope

Payload = Mapping[str, Any] | BaseModel


class SystemStreamMixin(AssetWebSocketBase):
    async def handshake(
        self,
        payload: Payload | None = None,
        *,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
        timeout: float | None = None,
    ) -> AssetEnvelope:
        envelope = self._build_envelope(
            message_type="system:handshake",
            stream="system",
            payload=payload,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return await self.receive_envelope(
            expected_type="system:handshake:ack",
            expected_stream="system",
            timeout=timeout,
        )

    async def send_heartbeat(
        self,
        payload: Payload | None = None,
        *,
        correlation_id: str | None = None,
        sent_at: datetime | None = None,
    ) -> AssetEnvelope:
        envelope = self._build_envelope(
            message_type="system:heartbeat",
            stream="system",
            payload=payload,
            correlation_id=correlation_id,
            sent_at=sent_at,
        )
        await self.send_model(envelope)
        return envelope
