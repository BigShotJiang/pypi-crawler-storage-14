import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, List, Tuple

import pytest
import websockets
from atlas_asset_ws_client.base import EnvelopeValidationError
from atlas_asset_ws_client.client import AssetWebSocketClient
from atlas_asset_ws_client.listener import listen, process_command_queue
from atlas_asset_ws_client.schemas import (
    AssetEnvelope,
    AssetMeta,
    CommandCompletionPayload,
    GeofeaturePayload,
    SettingsPayload,
    TrackPayload,
)


class DummyConnection:
    """Minimal async websocket stub used by the tests."""

    def __init__(self, responses: Iterable[Any] | None = None) -> None:
        self.sent: List[Any] = []
        self.closed = False
        self._responses = list(responses or [])

    async def send(self, data: Any) -> None:
        self.sent.append(data)

    async def recv(self) -> Any:
        if not self._responses:
            raise RuntimeError("No queued responses available")
        return self._responses.pop(0)

    async def close(self) -> None:
        self.closed = True


def _server_envelope(
    message_type: str,
    *,
    stream: str,
    payload: dict[str, Any] | None = None,
    asset_id: str = "asset-123",
) -> AssetEnvelope:
    meta = AssetMeta(
        asset_id=asset_id,
        stream=stream,
        sent_at=datetime(2024, 1, 1, tzinfo=timezone.utc),
        correlation_id="server-correlation",
        sequence=None,
    )
    return AssetEnvelope(type=message_type, meta=meta, payload=payload or {"status": "ok"})


def _fake_client(
    responses: Iterable[Any],
    *,
    url: str = "wss://atlas.test/asset",
    asset_id: str = "asset-123",
) -> Tuple[AssetWebSocketClient, DummyConnection]:
    connection = DummyConnection(responses)

    async def fake_connect(target: str):
        assert target == url
        return connection

    client = AssetWebSocketClient(url, asset_id=asset_id, connect=fake_connect)
    return client, connection


def _live_model_id() -> str:
    """Return an asset model ID supplied by startup data or the environment."""

    env_model_id = os.getenv("ATLAS_WS_MODEL_ID")
    if env_model_id:
        return env_model_id

    root = Path(__file__).resolve().parents[4]
    models_dir = root / "startup_data" / "asset_models"
    if not models_dir.is_dir():
        pytest.skip("Atlas live test requires startup_data asset models")

    for model_file in sorted(models_dir.glob("*.json")):
        with model_file.open() as fp:
            data = json.load(fp)
        model_id = data.get("id")
        if model_id:
            if not isinstance(model_id, str):
                raise TypeError(f"Expected string model ID, got {type(model_id)!r}")
            return model_id

    pytest.skip("Atlas live test requires at least one defined asset model")


@pytest.mark.asyncio
async def test_connect_is_idempotent_and_close_is_graceful() -> None:
    connection = DummyConnection()

    async def fake_connect(url: str):
        return connection

    client = AssetWebSocketClient("wss://atlas.test/asset", "asset-123", connect=fake_connect)

    await client.connect()
    await client.connect()

    assert client.is_connected is True
    assert len(connection.sent) == 0  # no traffic yet

    await client.close()
    assert connection.closed is True
    assert client.is_connected is False

    # Closing again without an active connection should be a no-op
    await client.close()


@pytest.mark.asyncio
async def test_receive_json_handles_strings_bytes_and_dicts() -> None:
    responses = [
        json.dumps({"first": 1}),
        b'{"second": 2}',
        {"third": 3},
    ]
    client, connection = _fake_client(responses)
    await client.connect()

    assert await client.receive_json() == {"first": 1}
    assert await client.receive_json() == {"second": 2}
    assert await client.receive_json() == {"third": 3}


@pytest.mark.asyncio
async def test_handshake_sends_envelope_and_skips_connection_ack() -> None:
    ack = _server_envelope("system:handshake:ack", stream="system", asset_id="asset-XYZ")
    responses = [
        json.dumps({"type": "connection", "status": "ok"}),
        json.dumps(ack.model_dump(mode="json")),
    ]
    client, connection = _fake_client(responses, asset_id="asset-XYZ")

    custom_sent_at = datetime(2024, 5, 17, 12, 0, tzinfo=timezone.utc)
    await client.connect()
    result = await client.handshake(
        payload={"status": "ready"},
        correlation_id="corr-123",
        sent_at=custom_sent_at,
    )

    assert result == ack

    sent_payload = json.loads(connection.sent[0])
    assert sent_payload["type"] == "system:handshake"
    assert sent_payload["payload"]["status"] == "ready"
    assert sent_payload["meta"]["correlation_id"] == "corr-123"
    serialized_sent_at = sent_payload["meta"]["sent_at"]
    parsed_sent_at = datetime.fromisoformat(serialized_sent_at.replace("Z", "+00:00"))
    assert parsed_sent_at == custom_sent_at


@pytest.mark.asyncio
async def test_complete_command_merges_defaults_and_waits_for_ack() -> None:
    ack = _server_envelope("command:complete:ack", stream="commands", asset_id="asset-XYZ")
    responses = [json.dumps(ack.model_dump(mode="json"))]
    client, connection = _fake_client(responses, asset_id="asset-XYZ")

    await client.connect()
    result = await client.complete_command(
        command_id="CMD-1",
        queue_index=5,
        status="success",
        result={"detail": "ok"},
    )

    assert result == ack

    sent_payload = json.loads(connection.sent[-1])
    assert sent_payload["type"] == "command:complete"
    assert sent_payload["payload"]["command_id"] == "CMD-1"
    assert sent_payload["payload"]["index"] == 5
    assert sent_payload["payload"]["queue_index"] == 5
    assert sent_payload["payload"]["status"] == "success"
    assert sent_payload["payload"]["result"] == {"detail": "ok"}


@pytest.mark.asyncio
async def test_heartbeat_telemetry_and_queue_messages() -> None:
    handshake_ack = _server_envelope(
        "system:handshake:ack",
        stream="system",
        asset_id="asset-telemetry",
    )
    queue_response = _server_envelope(
        "command_queue:data",
        stream="commands",
        payload={"commands": [{"id": "cmd-live", "asset_id": "asset-live"}]},
        asset_id="asset-telemetry",
    )
    responses = [
        json.dumps(handshake_ack.model_dump(mode="json")),
        json.dumps(queue_response.model_dump(mode="json")),
    ]
    client, connection = _fake_client(responses, asset_id="asset-telemetry")

    await client.connect()
    ack = await client.handshake(payload={"firmware_version": "1.0"})
    assert ack == handshake_ack

    await client.send_heartbeat(
        payload={"battery_pct": 71},
        correlation_id="hb-1",
        sent_at=datetime(2024, 6, 1, tzinfo=timezone.utc),
    )
    await client.send_telemetry_update(
        {"location": {"lat": 1.0, "lon": 2.0}},
        correlation_id="tele-1",
        sent_at=datetime(2024, 6, 1, tzinfo=timezone.utc),
        sequence=3,
    )

    queue = await client.request_command_queue(correlation_id="queue-1")
    assert queue == queue_response

    sent = [json.loads(item) for item in connection.sent]
    assert sent[0]["type"] == "system:handshake"
    assert sent[1]["type"] == "system:heartbeat"
    assert sent[1]["payload"]["battery_pct"] == 71
    assert sent[2]["type"] == "telemetry:update"
    assert sent[2]["payload"]["location"]["lat"] == 1.0
    assert sent[3]["type"] == "command_queue:request"
    assert sent[3]["meta"]["correlation_id"] == "queue-1"


@pytest.mark.asyncio
async def test_settings_update_includes_fields_and_defaults() -> None:
    handshake_ack = _server_envelope(
        "system:handshake:ack",
        stream="system",
        asset_id="asset-settings",
    )
    settings_ack = _server_envelope(
        "settings:update:ack",
        stream="settings",
        asset_id="asset-settings",
    )
    responses = [
        json.dumps(handshake_ack.model_dump(mode="json")),
        json.dumps(settings_ack.model_dump(mode="json")),
    ]
    client, connection = _fake_client(responses, asset_id="asset-settings")

    await client.connect()
    await client.handshake(payload={"firmware_version": "1.0"})
    await client.send_settings_update(
        settings={"max_speed": 42},
        mode="merge",
        replace=True,
        reset=False,
        correlation_id="settings-1",
    )

    sent = json.loads(connection.sent[-1])
    assert sent["type"] == "settings:update"
    assert sent["payload"]["settings"]["max_speed"] == 42
    assert sent["payload"]["mode"] == "merge"
    assert sent["payload"]["replace"] is True
    assert sent["payload"]["reset"] is False


@pytest.mark.asyncio
async def test_track_helpers_accept_payload_models() -> None:
    ack = _server_envelope("track:create:ack", stream="tracks", asset_id="asset-track")
    responses = [json.dumps(ack.model_dump(mode="json"))]
    client, connection = _fake_client(responses, asset_id="asset-track")
    await client.connect()

    payload = TrackPayload(name="Model")
    result = await client.create_track(
        payload=payload,
        track_id="explicit",
        metadata={"foo": "bar"},
    )

    assert result == ack
    sent = json.loads(connection.sent[-1])
    assert sent["payload"]["track_id"] == "explicit"
    assert sent["payload"]["metadata"]["foo"] == "bar"


@pytest.mark.asyncio
async def test_geofeature_helpers_support_models_and_list() -> None:
    create_ack = _server_envelope(
        "geofeature:create:ack",
        stream="geofeatures",
        asset_id="asset-geo",
    )
    list_ack = _server_envelope(
        "geofeature:list:ack",
        stream="geofeatures",
        asset_id="asset-geo",
    )
    responses = [
        json.dumps(create_ack.model_dump(mode="json")),
        json.dumps(list_ack.model_dump(mode="json")),
    ]
    client, _ = _fake_client(responses, asset_id="asset-geo")
    await client.connect()

    model = GeofeaturePayload(
        id="geo-1",
        name="Feature",
        type="area",
        geometry_type="polygon",
    )
    created = await client.create_geofeature(
        id="geo-1",
        name="Feature",
        type="area",
        geometry_type="polygon",
        payload=model,
    )
    assert created == create_ack

    listed = await client.list_geofeatures(limit=5, offset=2)
    assert listed == list_ack


@pytest.mark.asyncio
async def test_receive_envelope_validates_expected_type() -> None:
    ack = _server_envelope("system:handshake:ack", stream="system")
    responses = [json.dumps(ack.model_dump(mode="json"))]
    client, _ = _fake_client(responses)
    await client.connect()

    with pytest.raises(EnvelopeValidationError):
        await client.receive_envelope(expected_type="command:complete:ack")


@pytest.mark.asyncio
async def test_listener_reports_frames_until_break() -> None:
    ack1 = _server_envelope("system:handshake:ack", stream="system")
    ack2 = _server_envelope("command_queue:data", stream="commands")
    responses = [
        json.dumps(ack1.model_dump(mode="json")),
        json.dumps(ack2.model_dump(mode="json")),
    ]
    client, _ = _fake_client(responses)
    await client.connect()

    envelopes: list[AssetEnvelope] = []
    async for envelope in listen(client):
        envelopes.append(envelope)
        if len(envelopes) == 2:
            break

    assert envelopes == [ack1, ack2]


@pytest.mark.asyncio
async def test_process_command_queue_calls_handler_until_stopped() -> None:
    queue_ack = _server_envelope("command_queue:data", stream="commands")
    update_ack = _server_envelope("command_queue:update", stream="commands")
    responses = [
        json.dumps(queue_ack.model_dump(mode="json")),
        json.dumps(update_ack.model_dump(mode="json")),
    ]
    client, _ = _fake_client(responses)
    await client.connect()

    stop_event = asyncio.Event()
    seen: list[str] = []

    async def handler(envelope: AssetEnvelope) -> None:
        seen.append(envelope.type)
        if len(seen) == 2:
            stop_event.set()

    await process_command_queue(client, handler, stop_event=stop_event)
    assert seen == ["command_queue:data", "command_queue:update"]


@pytest.mark.asyncio
async def test_settings_update_accepts_payload_model() -> None:
    ack = _server_envelope(
        "settings:update:ack",
        stream="settings",
        asset_id="asset-settings",
    )
    responses = [json.dumps(ack.model_dump(mode="json"))]
    client, _ = _fake_client(responses, asset_id="asset-settings")
    await client.connect()

    payload = SettingsPayload(settings={"max_speed": 50}, mode="merge", replace=True)
    result = await client.send_settings_update(payload=payload)

    assert result == ack


@pytest.mark.asyncio
async def test_complete_command_accepts_command_payload_model() -> None:
    ack = _server_envelope("command:complete:ack", stream="commands", asset_id="asset-command")
    responses = [json.dumps(ack.model_dump(mode="json"))]
    client, _ = _fake_client(responses, asset_id="asset-command")
    await client.connect()

    payload = CommandCompletionPayload(command_id="CMD-99", status="success")
    response = await client.complete_command(payload=payload)
    assert response == ack


@pytest.mark.asyncio
@pytest.mark.live
async def test_live_server_roundtrip_handshake_and_queue() -> None:
    url = os.getenv("ATLAS_WS_URL", "ws://localhost:8000/ws/assets")
    token = os.getenv("ATLAS_WS_TOKEN")
    asset_id = os.getenv("ATLAS_WS_ASSET", "integration-asset")
    model_id = _live_model_id()

    async def connect(target: str):
        params = ""
        if token:
            separator = "?" if "?" not in target else "&"
            params = f"{separator}token={token}"
        return await websockets.connect(target + params, ping_interval=20)

    client = AssetWebSocketClient(url, asset_id=asset_id, connect=connect)

    try:
        async with client:
            ack = await client.handshake(
                payload={
                    "firmware_version": "integration-test",
                    "model_id": model_id,
                },
                correlation_id="live-handshake",
            )
            assert ack.meta.asset_id == asset_id
            await client.send_heartbeat(payload={"status": "live"})
            await client.send_telemetry_update(
                {
                    "location": {"lat": 37.0, "lon": -122.0, "alt": 10},
                    "battery_pct": 99,
                }
            )
            queue = await client.request_command_queue()
            assert queue.meta.stream == "commands"
    except (OSError, asyncio.TimeoutError, websockets.WebSocketException) as exc:
        pytest.skip(f"Atlas Command not reachable: {exc}")
