# T. carlae

Minimal Python repository with a simple development workflow. Share and enjoy!

## Workflow

```bash
$ git clone https://gitlab.com/lfdo/tcarlae.git
$ cd tcarlae
$ uv sync  # includes development dependencies
$ uv run tcarlae
Hello world!
```

Alternatively:

```bash
$ uv run python -m tcarlae.cli
Hello world!
```

And to publish:

```bash
$ git tag -a 2.0.0 -m "Version 2.0.0"
$ uv build
$ uv publish  # uses tag for version number
```

# Sharing and contributions

```
T. carlae
https://lofidevops.neocities.org
Copyright 2023 David Seaward and contributors
SPDX-License-Identifier: 0BSD
```

You can copy and modify this project freely and without credit. It's mostly
uncopyrightable anyway.

# Colophon

The Barbados threadsnake (known as Tetracheilostoma carlae or T. carlae) is the
smallest known snake species in the world.
