from textutilsjh.core import to_upper, to_lower, capitalize_first

def test_upper():
    assert to_upper("hello") == "HELLO"

def test_lower():
    assert to_lower("Hello") == "hello"

def test_capitalize():
    assert capitalize_first("hello") == "Hello"