# textutilsjh

Simple text utility package created for Python packaging practice.

## Installation