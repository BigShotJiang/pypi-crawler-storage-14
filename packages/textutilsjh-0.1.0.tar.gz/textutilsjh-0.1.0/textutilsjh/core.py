def to_upper(text: str) -> str:
    """문자열을 대문자로 변환합니다."""
    return text.upper()

def to_lower(text: str) -> str:
    """문자열을 소문자로 변환합니다."""
    return text.lower()

def capitalize_first(text: str) -> str:
    """문자열의 첫 글자만 대문자로 변환합니다."""
    if not text:
        return text
    return text[0].upper() + text[1:]