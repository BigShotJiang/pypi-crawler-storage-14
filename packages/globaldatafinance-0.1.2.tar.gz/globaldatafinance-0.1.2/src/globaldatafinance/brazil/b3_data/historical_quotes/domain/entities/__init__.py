from .docs_to_extractor import DocsToExtractorB3

__all__ = [
    'DocsToExtractorB3',
]
