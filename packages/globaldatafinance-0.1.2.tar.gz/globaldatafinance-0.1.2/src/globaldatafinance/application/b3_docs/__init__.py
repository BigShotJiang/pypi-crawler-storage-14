from .historical_quotes import HistoricalQuotesB3

__all__ = ['HistoricalQuotesB3']
