"""Dashboards for logicsponge."""

import logging
import math
from collections.abc import Callable
from typing import Self, TypedDict

import matplotlib.axes
import matplotlib.figure
import matplotlib.lines
import matplotlib.pyplot as plt
import numpy as np

import logicsponge.core as ls

logger = logging.getLogger(__name__)


# class PlotState(TypedDict):
#     x: list[float]
#     y: dict[str, list[float]]


class PlotParams(TypedDict):
    """Plot parameters."""

    x: list[float]
    y: list[float]
    args: list
    kwargs: dict


class Plot(ls.FunctionTerm):
    """Plot data items.

    typical uses are:
    - Plot(x='a', y=['b', 'c'])
    - Plot(x='a', y='b')
    - Plot(y='b') : plot over round number
    - Plot() : plot all keys over round number
    """

    x_name: str
    y_names: list[str] | None
    lines: dict[str, matplotlib.lines.Line2D]
    fig: matplotlib.figure.Figure
    ax: matplotlib.axes.Axes
    incremental: bool

    def __init__(
        self,
        *args,  # noqa: ANN002
        x: str = "round",
        y: str | list[str] | None = None,
        incremental: bool = True,
        **kwargs,  # noqa: ANN003
    ) -> None:
        """Create a Plot object."""
        super().__init__(*args, **kwargs)
        plt.ion()
        self.state = {
            "x": [],
            "y": {},
        }
        self.x_name = x
        if isinstance(y, str):
            self.y_names = [y]
        else:
            self.y_names = y
        self.lines = {}
        self.incremental = incremental
        self.fig, self.ax = plt.subplots()
        self.fig.show()

    def _axis_setup(self, item: ls.DataItem) -> None:
        # check if need to discover the y_names
        if self.y_names is None:
            # we will plot all keys of the input
            # except for the x-key
            self.y_names = list(set(item.keys()) - {self.x_name})

        # init the y-value dict
        self.state["y"] = {k: [] for k in self.y_names}

        # init lines
        self.lines = {y_name: self.ax.plot([], [], lw=2)[0] for y_name in self.y_names}
        self.ax.set_xlabel(self.x_name)
        self.ax.legend(self.y_names)
        self.ax.set_title(self.name)

    def plot(self, item: ls.DataItem) -> None:
        """Plot the new item."""
        to_plot = item["plot"]
        self._axis_setup(to_plot)

        # update x-state
        if self.x_name == "round":
            round_nr = len(self.state["x"])
            self.state["x"] += [round_nr]
        else:
            self.state["x"] += [to_plot[self.x_name]]
            # this may fail if x is not a key

        # update y-state
        if self.y_names is None:
            msg = "this should not happen: self.y_names must be set"
            raise ValueError(msg)
        for k in self.y_names:
            self.state["y"][k] = to_plot[k]

        # update figure data
        m = float("inf")
        M = -float("inf")  # noqa: N806
        for k in self.y_names:
            self.lines[k].set_data(self.state["x"], self.state["y"][k])
            finite_values = [v for v in self.state["y"][k] if is_finite(v)]
            m = min([*finite_values, m])
            M = max([*finite_values, M])  # noqa: N806

        # rezoom
        self.ax.set_xlim(self.state["x"][0] - 1, self.state["x"][-1] + 1)
        y_offset = min(M - m, 1.0) * 0.1
        y_lower = m - y_offset if is_finite(m - y_offset) else -1.0
        y_upper = M + y_offset if is_finite(M + y_offset) else 1.0
        self.ax.set_ylim(y_lower, y_upper)

        # draw
        self.fig.canvas.draw_idle()
        plt.pause(0.001)

    def add_data(self, item: ls.DataItem) -> None:
        """Add data to the plot."""
        if len(self.state["x"]) == 0:
            # first plot
            self._axis_setup(item)

        # update x-state
        if self.x_name == "round":
            round_nr = len(self.state["x"])
            self.state["x"] += [round_nr]
        else:
            self.state["x"] += [item[self.x_name]]
            # this may fail if x is not a key

        # update y-state
        if self.y_names is None:
            msg = "this should not happen: self.y_names must be set"
            raise ValueError(msg)
        for k in self.y_names:
            self.state["y"][k] += [item[k]]

        # update figure data
        m = float("inf")
        M = -float("inf")  # noqa: N806
        for k in self.y_names:
            self.lines[k].set_data(self.state["x"], self.state["y"][k])
            finite_values = [v for v in self.state["y"][k] if is_finite(v)]
            m = min([*finite_values, m])
            M = max([*finite_values, M])  # noqa: N806

        # rezoom
        self.ax.set_xlim(self.state["x"][0] - 1, self.state["x"][-1] + 1)
        y_offset = min(M - m, 1.0) * 0.1
        y_lower = m - y_offset if is_finite(m - y_offset) else -1.0
        y_upper = M + y_offset if is_finite(M + y_offset) else 1.0
        self.ax.set_ylim(y_lower, y_upper)

        # draw
        self.fig.canvas.draw_idle()
        plt.pause(0.001)

    def f(self, di: ls.DataItem) -> ls.DataItem:
        """Run on new data item."""
        if self.incremental:
            self.add_data(di)
        else:
            self.plot(di)
        return di


class DeepPlot(ls.FunctionTerm):
    """A complete, non-iterative plot."""

    fig: matplotlib.figure.Figure
    ax: matplotlib.axes.Axes
    then_fun: Callable[[Self, ls.DataItem], None] | None

    def __init__(self, *args, **kwargs) -> None:  # noqa: ANN002, ANN003
        """Create a DeepPlot object."""
        super().__init__(*args, **kwargs)
        self.lines = {}
        self.fig, self.ax = plt.subplots()
        plt.ion()
        self.fig.show()

    def _axis_setup(self, params: PlotParams) -> None:  # noqa: ARG002
        self.ax.set_title(self.name)

    def _call_plot_dicts(self, d: dict | ls.DataItem) -> None:
        if isinstance(d, dict):
            for k in d:
                if k == "plot":
                    self.plot(d["plot"])
                elif k == "plot-list":
                    for v in d["plot-list"]:
                        self.plot(v)
                else:
                    self._call_plot_dicts(d[k])

    def plot(self, params: PlotParams) -> None:
        """Make the plot."""
        self._axis_setup(params)

        # draw
        if not isinstance(params, dict):
            msg = "expecting a plot dictionary"
            raise TypeError(msg)

        if "y" not in params:
            msg = "expected key 'y' in a plot dict"
            raise ValueError(msg)
        y = params["y"]

        x = params["x"] if "x" in params else range(len(y))
        args = params.get("args", [])
        kwargs = params.get("kwargs", {})

        self.ax.plot(x, y, *args, **kwargs)
        self.fig.canvas.draw_idle()
        plt.pause(0.001)

    def f(self, di: ls.DataItem) -> ls.DataItem:
        """Run f on new data item."""
        # potentially clear the axis
        if self.ax is not None:
            self.ax.clear()

        # do the plotting
        self._call_plot_dicts(di)

        # potentially call the then-registered function
        if self.then_fun is not None:
            self.then_fun(self, di)

        # return all
        return di

    def then(self, fun: Callable[[Self, ls.DataItem], None]) -> Self:
        """Run a function after the plotting."""
        self.then_fun = fun
        return self


def is_finite(num: float | np.number) -> bool:
    """Return if num is a finite number."""
    # try:
    return not (math.isnan(num) or math.isinf(num))
    # except Exception as e:
    #     print('error', num)
