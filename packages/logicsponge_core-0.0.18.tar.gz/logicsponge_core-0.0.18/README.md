# logicsponge-core

[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)
[![static analysis workflow](https://github.com/innatelogic/logicsponge-core/actions/workflows/static-analysis.yaml/badge.svg)](https://github.com/innatelogic/logicsponge-core/actions/workflows/static-analysis.yaml/)
[![test workflow](https://github.com/innatelogic/logicsponge-core/actions/workflows/test.yaml/badge.svg)](https://github.com/innatelogic/logicsponge-core/actions/workflows/test.yaml/)

This is the logicsponge core library.
