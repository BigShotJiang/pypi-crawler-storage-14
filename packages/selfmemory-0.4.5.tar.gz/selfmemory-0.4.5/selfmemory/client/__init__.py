"""SelfMemory Client package."""

from .main import SelfMemoryClient

__all__ = ["SelfMemoryClient"]
