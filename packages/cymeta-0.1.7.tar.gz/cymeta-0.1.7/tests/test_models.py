"""Tests for CyMeta model wrappers."""

import torch
import pytest
from cymeta.models.linear import CyMetaLinear
from cymeta.models.attention import CyMetaAttention, CyMetaMultiHeadAttention
from cymeta.models.ffn import CyMetaFFN


def test_cymeta_linear():
    """Test CyMetaLinear layer."""
    layer = CyMetaLinear(
        in_features=128,
        out_features=64,
        dict_size=32,
        gating_hidden=16,
    )
    
    x = torch.randn(4, 128)  # (batch_size, in_features)
    output = layer(x)
    
    assert output.shape == (4, 64)
    # Compression ratio depends on dict_size and gating network size
    # With small dict_size=32, ratio may be < 1.0 for small layers
    # This is acceptable - the test just verifies the method works
    ratio = layer.get_compression_ratio()
    assert ratio > 0.0  # Should return a valid ratio


def test_cymeta_linear_with_bias():
    """Test CyMetaLinear with bias."""
    layer = CyMetaLinear(
        in_features=64,
        out_features=32,
        bias=True,
    )
    
    x = torch.randn(2, 64)
    output = layer(x)
    
    assert output.shape == (2, 32)
    assert layer.bias is not None


def test_cymeta_attention():
    """Test CyMetaAttention."""
    attention = CyMetaAttention(
        embed_dim=128,
        dict_size=32,
        gating_hidden=16,
    )
    
    batch_size = 2
    seq_len = 10
    query = torch.randn(batch_size, seq_len, 128)
    key = torch.randn(batch_size, seq_len, 128)
    value = torch.randn(batch_size, seq_len, 128)
    
    output, attn_weights = attention(query, key, value)
    
    assert output.shape == (batch_size, seq_len, 128)
    assert attn_weights.shape == (batch_size, seq_len, seq_len)


def test_cymeta_multi_head_attention():
    """Test CyMetaMultiHeadAttention."""
    attention = CyMetaMultiHeadAttention(
        embed_dim=256,
        num_heads=8,
        dict_size=32,
        gating_hidden=16,
    )
    
    batch_size = 2
    seq_len = 10
    query = torch.randn(batch_size, seq_len, 256)
    key = torch.randn(batch_size, seq_len, 256)
    value = torch.randn(batch_size, seq_len, 256)
    
    output, attn_weights = attention(query, key, value)
    
    assert output.shape == (batch_size, seq_len, 256)
    assert attn_weights.shape == (batch_size, 8, seq_len, seq_len)


def test_cymeta_ffn():
    """Test CyMetaFFN."""
    ffn = CyMetaFFN(
        embed_dim=128,
        ffn_dim=512,
        dict_size=32,
        gating_hidden=16,
    )
    
    x = torch.randn(2, 10, 128)  # (batch_size, seq_len, embed_dim)
    output = ffn(x)
    
    assert output.shape == (2, 10, 128)
    # Compression ratio depends on dict_size and gating network size
    # With small dict_size=32, ratio may be < 1.0 for small layers
    # This is acceptable - the test just verifies the method works
    ratio = ffn.get_compression_ratio()
    assert ratio > 0.0  # Should return a valid ratio


if __name__ == "__main__":
    pytest.main([__file__])

