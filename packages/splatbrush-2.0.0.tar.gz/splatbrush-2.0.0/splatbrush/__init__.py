__version__ = "2.0.0"  # https://semver.org/#summary
