"""Action table utils."""
