#special methods config

#_fsm

fsm_def = {
	"search_by": "all"
}