# spec_methods.py
class SpecMethods:
    def _fsm(self, db_name, objtocheck, storages, mnclass, settings):
        if db_name not in storages:
            raise ValueError(f"Data base: {db_name} doesn't exist")

        mode = None
        if isinstance(settings, dict):
            mode = settings.get("search_by", "all")
        else:
            mode = settings

        data = mnclass.get_all(db_name)  # список объектов из файла

        # режим "all" — полное совпадение объекта
        if mode == "all":
            return objtocheck in data

        # если mode — строка (например "Maksim"), ищем эту строку среди значений словарей
        if isinstance(mode, str):
            search_value = mode
            for item in data:
                if isinstance(item, dict):
                    # если любое значение в словаре равно search_value
                    if search_value in item.values():
                        return True
            return False

        # другие режимы (по ключу и т.п.) можно добавить здесь при необходимости
        return False