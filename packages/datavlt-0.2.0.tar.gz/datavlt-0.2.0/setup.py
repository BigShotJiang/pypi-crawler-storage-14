from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8") if (this_directory / "README.md").exists() else ""

setup(
    name="datavlt",
    version="0.2.0",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
    description="Lightweight JSON-based database storage library for Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="maksalmaz",
    author_email="maksalmaz15@gmail.com",
    url="https://github.com/username/datavlt",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Database",
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    keywords="json database storage python lightweight",
)