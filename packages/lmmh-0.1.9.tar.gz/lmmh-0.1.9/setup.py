from setuptools import setup, find_packages
import pathlib

this_dir = pathlib.Path(__file__).parent
long_description = (this_dir / "README.md").read_text(encoding="utf-8")

setup(
    name="LMMH",
    version="0.1.9",
    author="Laith Madhat M. AL-Haware",
    author_email="landr41@gmail.com",
    description="👽 LMMH - Comprehensive Library of AI (Chat, Text AI & Vision AI Processing)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/LaithALhaware/LMMH",
    packages=find_packages(),                # automatically finds your package folder (LMMH)
    include_package_data=True,
    python_requires=">=3.8",                # must match pyproject.toml
    install_requires=[
        "flask",
        "flask-cors",
        "torch",
        "torchvision",
        "transformers",
        "TTS",
        "faster-whisper",
        "pandas",
        "python-docx",
        "PyMuPDF",
        "pydub",
        "beautifulsoup4",
        "googlesearch-python",
        "aiohttp",
        "langdetect",
        "googletrans==4.0.0-rc1",          # fixed version syntax
        "Pillow",
        "tqdm",
        "attrdict",
        "einops",
        "timm"
    ],
    entry_points={
        "console_scripts": [
            "LMMH-install = LMMH.installer:main",  # make sure LMMH/installer.py exists
        ],
    },
    license="MIT",
)

