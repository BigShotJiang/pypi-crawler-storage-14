__all__ = ["Get_Detailed_Information_LMMH"]



from flask import Flask, request
import os

from .Convert_utils import New_Convert_To_LMMH_Data,Old_Convert_To_LMMH_Data,Convert_To_Text_Data


def Get_Detailed_Information_LMMH(USERS_FILES_GENERATED):
    # Get basic request info
    user_ip = request.headers.get('X-Forwarded-For', request.remote_addr)

    # Combine all request data into one variable
    request_info = f"""
    ---- Incoming Request Info ----\n
    IP Address     : {request.headers.get('X-Forwarded-For', request.remote_addr)}\n
    User-Agent     : {request.headers.get('User-Agent')}\n
    Method         : {request.method}\n
    URL            : {request.url}\n
    Headers        : {dict(request.headers)}\n
    Cookies        : {request.cookies.to_dict()}\n
    ------------------------------\n
    """
    
    # Define the filename
    filename = f"{USERS_FILES_GENERATED}/{user_ip}/INFO.ILMMH"

    # Check if the file exists and is not empty
    if os.path.exists(filename) and os.path.getsize(filename) > 0:
        return  # Exit the function if file exists and is not empty
    
    # Ensure the directory exists before trying to write
    os.makedirs(os.path.dirname(filename), exist_ok=True)

    # Save to file
    with open(filename, "w", encoding="utf-8") as file:
        file.write(New_Convert_To_LMMH_Data(request_info))

    


