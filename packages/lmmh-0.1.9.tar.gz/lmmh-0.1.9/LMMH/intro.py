__all__ = ["Intro_LMMH"]



import shutil
import time
import os
 
import shutil, sys, time


import datetime
import socket

RESET = "\033[0m"
BOLD = "\033[1m"

BLACK = "\033[30m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"

BRIGHT_BLACK = "\033[90m"
BRIGHT_RED = "\033[91m"
BRIGHT_GREEN = "\033[92m"
BRIGHT_YELLOW = "\033[93m"
BRIGHT_BLUE = "\033[94m"
BRIGHT_MAGENTA = "\033[95m"
BRIGHT_CYAN = "\033[96m"
BRIGHT_WHITE = "\033[97m"

BG_BLACK = "\033[40m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"
BG_MAGENTA = "\033[45m"
BG_CYAN = "\033[46m"
BG_WHITE = "\033[47m"
    
    
columns, _ = shutil.get_terminal_size()
width = columns if columns >= 70 else 70  # minimum width for links
horizontal = f"{CYAN}{'═' * width}{RESET}"

total = 0
   
   
Sub_APP_NAME = "Comprehensive Library of AI"
VERSION_APP = f"{BOLD}{GREEN}📦 VERSION : {RESET}{BLACK}{BG_GREEN}  0.1.1v 09/2025  {RESET}"
SECURITY_APP = f"{BOLD}{BRIGHT_YELLOW}🔒 SECURITY : {RESET}{BLACK}{BG_YELLOW}  DefenDash DD (Shahem Algorithms)  {RESET}"

APP_NAME = f"{BOLD}{RED}👽 LMMH{RESET} {BLUE}Library{RESET}"
SUB_NAME = f"{BOLD}{BLACK}{BG_BLUE}  {Sub_APP_NAME}  {RESET}"

# Links
BUG_TRACKER = f"{BOLD}{YELLOW}🐞 Bug Tracker :{RESET} {BLUE}https://github.com/LaithALhaware/LMMH/issues{RESET}"
DOCS = f"{BOLD}{CYAN}📖 Documentation :{RESET} {BLUE}https://github.com/LaithALhaware/LMMH#readme{RESET}"
SOURCE = f"{BOLD}{MAGENTA}💻 Source Code :{RESET} {BLUE}https://github.com/LaithALhaware/LMMH{RESET}"
   
start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
 
    
# Get the local IP address
def get_ip_address():
    try:
        # Connect to an external host (does not send data) to get outbound IP
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))  # Google's DNS
        ip = s.getsockname()[0]
        s.close()
    except Exception:
        ip = "127.0.0.1"
    return ip
    
    
    
def Intro_LMMH():

    os.system('cls' if os.name == 'nt' else 'clear')


    # ASCII art for "LMMH"
    header = r"""
 _     __  __ __  __ _   _ 
| |   |  \/  |  \/  | | | |
| |   | |\/| | |\/| | |_| |
| |___| |  | | |  | |  _  |
|_____|_|  |_|_|  |_|_| |_|
    """

    headAL = r"""                                                
                    ░▒▓▓▓▓▓▓▓░                    
                ▒██▓▒░      ░▒▓██▒                
             ░██▒                ▒██░             
            ██                      ██            
          ▒█░                        ░█▒          
         ░█░                          ░█░         
         █▒                            ▒█░        
        ▓█                              █▓        
        ▓▓                              ▓▓        
        ▓▓ █▒░░                    ░░▒█ ▓▓        
        ▓█ ░███████░          ░███████░ █▓        
        ░█░ ▓█████████      █████████▓ ░█░        
         ▒█  ██████████░  ░██████████  █▓         
          ▓█  ▓████████░  ░█████████  ▓█          
           ▓█   ▓█████▓    ▓█████▓░  ▒█           
            ▓█                      ▓█            
             ▒█▒                   ██             
               ██                ▒█▒              
                ▒█▓            ░██                
                  ▒█▓        ▒██                  
                    ▒██▒  ▒██▒                    
                       ▒▓▓▒                       
                                                                                                                                                                                              
    """


    linesheadAL = headAL.splitlines()
    for i, linesheadAL in enumerate(linesheadAL):
        print(BOLD + GREEN + linesheadAL.center(width) + RESET)    

    linesheader = header.splitlines()
    for i, linesheader in enumerate(linesheader):
        print(BOLD + BLUE + linesheader.center(width) + RESET)    



    # Loading bar
    loading_text = f"{BOLD}{CYAN}🚀 Initializing LMMH Modules...{RESET}\n"
    sys.stdout.write("\n" + loading_text)
    sys.stdout.flush()

    bar_length = width
    for i in range(bar_length + 1):
        percent = int((i / bar_length) * 100)
        bar = f"{GREEN}{'█' * i}{RESET}{'░' * (bar_length - i)}"
        sys.stdout.write(f"\r{bar}\r{percent}%")
        sys.stdout.flush()
        time.sleep(0.06)

    os.system('cls' if os.name == 'nt' else 'clear')

    # Print banner
    print(horizontal)
    print(APP_NAME.center(width))
    print(SUB_NAME.center(width))
    print(horizontal)
    print(VERSION_APP)
    print(SECURITY_APP)
    print(horizontal)


    # Project links
    print(BUG_TRACKER)
    print(DOCS)
    print(SOURCE)
    print(horizontal)


    # inf system
    ip_address = get_ip_address()

    # Log or print the info
    print(f"🕒 LMMH Started At : {BOLD}{BG_RED}{WHITE} {start_time} {RESET}")
    print(f"🌐 IP Address : {BOLD}{BG_RED}{WHITE} {ip_address} {RESET}")
    print(horizontal)
    
    
    
def Sub_Intro_LMMH():
    global total
    total += 1
    os.system('cls' if os.name == 'nt' else 'clear')


    # Print banner
    print(horizontal)
    print(APP_NAME.center(width))
    print(SUB_NAME.center(width))
    print(horizontal)
    print(VERSION_APP)
    print(SECURITY_APP)
    print(horizontal)

    
    # Project links
    print(BUG_TRACKER)
    print(DOCS)
    print(SOURCE)
    print(horizontal)

    # inf system
    ip_address = get_ip_address()

    # Log or print the info
    print(f"🕒 Script Started At : {BOLD}{BG_RED}{WHITE} {start_time} {RESET}")
    print(f"🌐 IP Address : {BOLD}{BG_RED}{WHITE} {ip_address} {RESET}")
    
    
    print(horizontal)
    print(f"❓ Total Number of Questions Asked : {BOLD}{BG_RED}{WHITE} {total} {RESET}")
    print(horizontal)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   

