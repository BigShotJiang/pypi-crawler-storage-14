__all__ = ["Transcribe_Audio_LMMH"]


from faster_whisper import WhisperModel



def Transcribe_Audio_LMMH(file_path):
    segments, _ = stt_model.transcribe(file_path, beam_size=5)
    return "\n".join([segment.text for segment in segments])

