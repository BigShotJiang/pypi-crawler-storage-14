from .dependency import *
from .validating import *

#--------------------------------utility----------------------------------

def save_fig_to_pdf(plt, path, filename):

    '''
    SYNOPSYS: экспорт отрендеренной фигуры в PNG формат

    KEYWORD ARGUMENTS:
    plt -- графический процессор фигуры
    path -- директория для экспорта
    filename -- название экспортируемого файла

    WARNING:
    Название файла указывается БЕЗ расширения

    RETURNS: *.png
    
    EXAMPLE:
    >>> save_fig_to_pdf(plt, True, 'SHAP_dependence_Temperature')
    >>> save_fig_to_pdf(plt, 'pictures', 'graf_month_consumption')
    '''

    if type(path) == bool:
        path = 'pictures'
    if not os.path.exists(path):
        os.makedirs(path)
    plt.savefig(f'{path}/{filename}.png', dpi = 300, transparent = True)


def rus_features(df, order='columns'):

    '''
    SYNOPSYS: Русификация датафреймов для диаграмм и графиков

    KEYWORD ARGUMENTS:
    df -- датафрейм, требуемый русификации
    order -- порядок русификации: по столбцам (columns, по умолчанию), по индексам (index)

    RETURNS:
    df : pandas.core.frame.DataFrame
        
    EXAMPLE:
    >>> rus_features(df)
    >>> rus_features(df, index)
    '''
        
    if order not in ['columns', 'index']:
        raise ValueError(f'''Опция "{order}" для параметра order отсутствует. 
            Используйте доступные опции: "columns", "index"''')
        
    features_set = {
                    'Year':'Год', 
                    'Month':'Месяц', 
                    'Day':'День', 
                    'Hour':'Час', 
                    'Weekday':'Неделя', 
                    'Volume':'Объём', 
                    'Temperature':'Температура', 
                    'ActCons':'Спрос БР', 
                    'ActGen':'Генерация БР', 
                    'Price':'ИБР',
                    'TypeDay':'Тип дня', 
                    'Light':'Свет', 
                    'Season':'Сезон',
                    'lag-1': '-1 сутки',
                    'lag-2': '-2 сутки',
                    'lag-3': '-3 сутки',
                    'lag-4': '-4 сутки',
                    'lag-5': '-5 сутки',
                    'lag-6': '-6 сутки',
                    'lag-7': '-7 сутки',
                   }
        
    if order == 'columns':
        return df.rename(columns=features_set)
    else:
        return df.rename(index=features_set)


def cat_codes_data(df_general, model='br3_act'):
    
    '''
    SYNOPSYS: Нативное кодирование категориальных признаков

    KEYWORD ARGUMENTS:
    df_general -- датафрейм с генеральной совокупностью после препроцессинг данных
    model -- тип модели (по умолчанию br3_act: [ActCons, ActGen, Price]) 

    WARNING:
    Для df_general обязательно наличие столбцов ['TypeDay', 'Season', 'Light', 'PredCons', 'PredGen', 'Price']
    
    RETURNS:
    df_general_cat : pandas.core.frame.DataFrame
    
    EXAMPLE:
    >>> cat_codes_data(df_general, model)
    >>> cat_codes_data(df_general, model=model)
    >>> cat_codes_data(df_general, 'br2_act')
    '''    
    
    df_general_cat = df_general.copy()
    
    if model == 'br3_act':
        df_general_cat.drop(columns=['PredCons', 'PredGen'], inplace=True)

    elif model == 'br2_act':
        df_general_cat.drop(columns=['PredCons', 'PredGen', 'Price'], inplace=True)
    
    df_general_cat.Season = df_general_cat.Season.apply(lambda x: ('Winter', 'Spring', 'Autumn', 'Summer')[x])
    df_general_cat.TypeDay = df_general_cat.TypeDay.apply(lambda x: ('Workday', 'Pre-holiday', 'Weekend', 'Holiday')[x])
    df_general_cat.Light = df_general_cat.Light.apply(lambda x: ('Dark', 'Light')[x])
    
    return df_general_cat


def build_and_fit_cat_selector(df_general_cat, max_depth):

    '''
    SYNOPSYS: создание и обучение feature-селектора

    KEYWORD ARGUMENTS:
    df_general_cat -- датафрейм с нативным кодированием категориальных признаков
    model -- тип модели (по умолчанию br3_act: [ActCons, ActGen, Price]) 

    WARNING:
    Для df_general_cat обязательно наличие столбцов ['Season', 'TypeDay', 'Light', 'Date', 'Volume']
    
    RETURNS:
    selector : catboost.core.CatBoostRegressor
    
    EXAMPLE:
    >>> build_and_fit_cat_selector(df_general_cut, max_depth=max_depth)
    '''

    selector = catboost.CatBoostRegressor(
                                          silent=True,
                                          n_estimators = 200,
                                          max_depth = max_depth,
                                          cat_features=['Season', 'TypeDay', 'Light']
                                         )

    selector.fit(df_general_cat.drop(columns=['Date', 'Volume']), df_general_cat.Volume)

    return selector


def get_shap_values(selector, df_general_cat):

    '''
    SYNOPSYS: генерация SHAP_value CatBoost-регрессора с помощью SHAP.Explainer

    KEYWORD ARGUMENTS:
    selector -- обученный CatBoost feature-селектор
    df_general_cat -- датафрейм с нативным кодированием категориальных признаков

    WARNING:
    Для df_general_cat обязательно наличие столбцов ['Date', 'Volume']
    
    RETURNS:
    shap_values : shap._explanation.Explanation
    
    EXAMPLE:
    >>> get_shap_values(selector, df_general_cat)
    '''

    explainer = shap.Explainer(selector)
    shap_values = explainer(df_general_cat.drop(columns=['Date', 'Volume']))
    
    return shap_values

#------------------------------visualisation------------------------------

def draw_learning_curve(df_general, max_depth, model, fontsize=14, font='Palatino Linotype', save_fig_dir=False):
    
    '''
    SYNOPSYS: Расчёт и построение кривой обучения

    KEYWORD ARGUMENTS:
    df_general -- валидируемая генеральная совокупность
    max_depth -- максимальная глубина решающего дерева регрессора
    model -- тип модели
    fontsize -- размер шрифта на графике
    font -- шрифт, используемый на графике
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    RETURNS:
    None
    
    EXAMPLE:
    >>> draw_learning_curve(df_general, max_depth=6, model=model)
    >>> draw_learning_curve(df_general, max_depth=7, model='br2_act', save_fig_dir='pictures')
    '''
    
    def X_y_split(df_general, learn_period):
    
        '''
        SYNOPSYS: Разделение выборки на целевой и исходные признаки
        '''
        
        datetime=df_general.Date.iloc[-1]
        
        df_train = df_general[(df_general.Date > datetime - timedelta(days=round(365.25*learn_period), hours=0)) &
                              (df_general.Date <= datetime)]
        
        return df_train.drop(columns=['Date', 'Volume']), df_train.Volume
    
    if model == 'br3_act':  # c 30 ноября 2025 перейти на 8 лет для br3 и 13 лет для br2
        df_general = df_general.drop(columns=['PredCons', 'PredGen'])
        learn_period = 7
    elif model == 'br2_act':
        df_general = df_general.drop(columns=['PredCons', 'PredGen', 'Price'])
        learn_period = 12
    
    X, y = X_y_split(df_general, learn_period)

    engine = catboost.CatBoostRegressor(silent=True,
                                       n_estimators = 200,
                                       max_depth = max_depth)
    common_params = {
                     "X": X,
                     "y": y,
                     "train_sizes": np.linspace(1/learn_period, 1.0, learn_period),
                     "cv": TimeSeriesSplit(n_splits=5),
                     "scoring": 'neg_mean_absolute_percentage_error',
                     "n_jobs": -1,
                     "line_kw": {"marker": "o"},
                     "std_display_style": "fill_between",
                     "score_name": "neg MAPE",
                    }

    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize 
    plt.figure(figsize=(10, 5))
    plt.rcParams['axes.prop_cycle'] = plt.cycler(color=['#1f77b4', '#8ec489'])   
    
    LCD = LearningCurveDisplay.from_estimator(engine, **common_params)
    train_sizes = LCD.train_sizes
    test_scores = LCD.test_scores
    mean_test_scores = [test_scores[i].mean() for i in range(len(test_scores))]    
    opt_y = max(mean_test_scores)
    opt_x = train_sizes[mean_test_scores.index(opt_y)]
    
    for i in range(len(mean_test_scores)):
        plt.text(train_sizes[i], mean_test_scores[i], f'{i+1}', ha='center', va='bottom')
    
    plt.annotate('Optimal period', xy=(opt_x, opt_y), 
                 xycoords='data', xytext=(opt_x-4000, opt_y-0.015), 
                 textcoords='data', fontsize=fontsize, 
                 arrowprops=dict(arrowstyle='-|>'))
    
    plt.title(f'Learning Curve for {model} (max_depth={max_depth})', fontsize=fontsize)
    plt.legend(['Training score', 'Test score'], loc='lower right')
    plt.tight_layout()

    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, f'{model}_Learning_Curve(max_depth={max_depth})')

    plt.show()


def graf_full_consumption(df, groupby_months=True, fontsize=20, font='Palatino Linotype', save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение трассированного по годам графика энергопотребления (с группировкой по месяцам и без группировки)

    KEYWORD ARGUMENTS:
    df -- датафрейм с данными об энергопотреблении
    groupby_months -- наличие группировки визуализируемого объема энергопотребления по месяцам
    fontsize -- размер шрифта на графике
    font -- шрифт, используемый на графике
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df обязательно наличие столбцов ['Volume', 'Year', 'Month']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> graf_year_consumption(df, year=2024, groupby_day=True, fontsize=20, save_fig_dir='pictures')
    '''

    if groupby_months:
        df_group = df.groupby(['Year', 'Month'])[['Volume']].mean()
        df_group.reset_index(inplace=True)
    else:
        df_group = df.copy()
   
    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    
    fig, df_volume = plt.subplots(figsize=(16,7))
    df_year = df_volume.twinx()

    df_volume.plot(df_group.Volume, label='Volume')
    df_year.plot(df_group.Year, label='Year', color='red')

    df_volume.set_xlim(0, df_group.shape[0])
    df_volume.set_ylabel('Объем, МВт·ч', fontsize=fontsize+2, color='#1f77b4')
    df_volume.set_xlabel(('Часы','Месяца')[groupby_months], fontsize=fontsize+2)
    df_year.set_ylabel('Годы', fontsize=fontsize+2, color='r')
    df_year.yaxis.set_major_locator(ticker.MultipleLocator(1.00))

    years = round((df.iloc[-1].Date.date() - df.iloc[0].Date.date()).days / 365.25)
    plt.title(f'Структура потребления за {years} лет ({df.iloc[0].Date.date()} – {df.iloc[-1].Date.date()})', 
              fontsize=fontsize+2)
    #plt.legend()
    plt.tight_layout()
    
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, 'graf_full_consumption')
    
    plt.show()


def graf_year_consumption(df, year=None, groupby_days=True, fontsize=20, font='Palatino Linotype', save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение трассированного по месяцам годового графика энергопотребления (с группировкой по дням и без группировки)

    KEYWORD ARGUMENTS:
    df -- датафрейм с данными об энергопотреблении
    year -- запрашиваемый год (по умолчанию последний)
    fontsize -- размер шрифта на графике
    font -- шрифт, используемый на графике
    groupby_days -- наличие группировки визуализируемого объема энергопотребления по дням
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df обязательно наличие столбцов ['Volume', 'Month', 'Day']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> graf_year_consumption(df, year=2024, groupby_day=True, fontsize=20, save_fig_dir='pictures')
    >>> graf_year_consumption(df)
    '''    
    
    if year == None:
        year=df.iloc[-1].Date.year

    df_year = df[df.Year == year]
    df_year.reset_index(drop=True, inplace=True)

    if groupby_days:
        df_group_year = df_year.groupby(['Month', 'Day'])[['Volume']].mean()
        df_group_year.reset_index(inplace=True)
    else:
        df_group_year = df_year.copy()

    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    
    fig, df_volume = plt.subplots(figsize=(16,6))
    df_month = df_volume.twinx()

    df_volume.plot(df_group_year.Volume, label='Volume')
    df_month.plot(df_group_year.Month, label='Month', color='r')

    df_volume.set_xlim(0, df_group_year.shape[0])
    df_volume.set_ylabel('Объем, МВт·ч', fontsize=fontsize+2, color='#1f77b4')
    df_volume.set_xlabel(('Часы','Дни')[groupby_days], fontsize=fontsize+2)
    df_month.yaxis.set_major_locator(ticker.FixedLocator([i for i in range(1, 13)]))
    df_month.set_ylabel('Месяца', fontsize=fontsize+2, color='r')
    df_month.yaxis.set_major_formatter(ticker.FixedFormatter(['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл',
                                                              'Авг', 'Сен', 'Окт', 'Ноя', 'Дек']))

    plt.title(f'Структура потребления в {year} году', fontsize=fontsize+2)
    
    #plt.legend()
    plt.tight_layout()
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, f'graf_year_consumption({year})')
    
    plt.show()
    

def graf_temp_cons_corr(df, year=None, fontsize=20, font='Palatino Linotype', save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение зависимости среднесуточного потребления электроэнергии от среднесуточной температуры за указанный год

    KEYWORD ARGUMENTS:
    df -- датафрейм с данными об энергопотреблении
    year -- запрашиваемый год (по умолчанию последний)
    fontsize -- размер шрифта на графике
    font -- шрифт, используемый на графике
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df обязательно наличие столбцов ['Volume', 'Temperature', 'Month', 'Day']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> graf_temp_cons_corr(df, 2023, save_fig_dir='pictures')
    >>> graf_temp_cons_corr(df)
    '''  
    
    if year == None:
        year=df.iloc[-1].Date.year

    df_year = df[df.Year == year]
    df_year.reset_index(drop=True, inplace=True)

    df_group_year = df_year.groupby(['Month', 'Day'])[['Volume', 'Temperature']].mean()
    df_group_year.reset_index(inplace=True) 

    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    fig, df_volume = plt.subplots(figsize=(16,6))
    df_temperature = df_volume.twinx()

    df_volume.plot(df_group_year.Volume, color='#1f77b4', label='Volume')

    df_temperature.plot(df_group_year.Temperature, color = 'red', label = 'Temperature')

    df_volume.set_xlim(0, df_group_year.shape[0])
    df_volume.set_ylabel('Объем, МВт·ч', fontsize=fontsize+2, color='#1f77b4')
    df_volume.set_xlabel('Дни', fontsize=fontsize+2)
    df_temperature.set_ylabel('Температура воздуха, °C', fontsize=fontsize+2, color='red')

    plt.title(f'График среднесуточного потребления и температура наружного воздуха за {year} год', 
              fontsize=fontsize+2)
    
    plt.tight_layout()
    #plt.legend()
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, f'graf_temp_cons_corr({year})')
    
    plt.show()


def graf_month_consumption(df, month=None, year=None, fontsize=20, font='Palatino Linotype', save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение графика месячного энергопотребления с трассировкой по дням недели

    KEYWORD ARGUMENTS:
    df -- датафрейм с данными об энергопотреблении
    month -- запрашиваемый месяц (по умолчанию последний)
    year -- запрашиваемый год (по умолчанию последний)
    fontsize -- размер шрифта на графике
    font -- шрифт, используемый на графике
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df обязательно наличие столбцов ['Volume', 'Year', 'Month', 'Weekday']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> graf_month_consumption(df, month=6, year=2025, fontsize=20, save_fig_dir='pictures')
    >>> graf_month_consumption(df)
    '''

    if year == None:
        year=df.iloc[-1].Date.year
    if month == None:
        month=df.iloc[-2].Date.month

    months = list(name for name in calendar.month_name)
    rus_months = ['', 'Январе', 'Феврале', 'Марте', 'Апреле', 'Мае', 'Июне', 
                  'Июле', 'Августе', 'Сентябре', 'Октябре', 'Ноябре', 'Декабре']

    df_month = df[(df.Year == year) & (df.Month == month)]
    df_month.reset_index(drop=True, inplace=True)

    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    fig, df_volume = plt.subplots(figsize=(16,5))
    df_weekday = df_volume.twinx()

    df_volume.plot(df_month.Volume, color='#1f77b4', label='Volume')
    df_weekday.plot(df_month.Weekday, label='Weekday', color='r')

    df_volume.set_xlim(0, df_month.shape[0])
    df_volume.set_ylabel('Объем, МВт·ч', fontsize=fontsize, color='#1f77b4')
    df_volume.set_xlabel('Часы', fontsize=fontsize)
    df_weekday.set_ylabel('Дни недели', fontsize=fontsize+2, color='r')
    df_weekday.yaxis.set_major_locator(ticker.FixedLocator([0, 1, 2, 3, 4, 5, 6]))
    df_weekday.yaxis.set_major_formatter(ticker.FixedFormatter(['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']))

    plt.title(f'Структура потребления в {rus_months[month]} {year} года', fontsize=fontsize)
    #plt.legend(loc = 'lower right')
    
    plt.tight_layout()
    
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, f'graf_month_consumption({months[month]} {year})')
    
    plt.show()


def draw_features_correlation_heatmaps(df_general, season='general', fontsize=12, font='Palatino Linotype', translation=True, save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение тепловой карты корреляций Пирсона для целевого и исходных признаков

    KEYWORD ARGUMENTS:
    df_general -- датафрейм с генеральной совокупностью после препроцессинг данных
    season -- запрашиваемый сезон. Доступные опции: 
    * winter (зима)
    * summer (лето)
    * full (сравнение лета и зимы на одном графике)
    * general (без сезонного разделения; по умолчанию)
    fontsize -- размер шрифта на карте
    font -- шрифт, используемый на графике
    translation -- перевод названий признаков на русский язык
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df обязательно наличие столбцов ['Year', 'Month', 'Day', 'Hour', 'Weekday', 'TypeDay', 'Temperature', 
                                         'Season', 'Light', 'ActCons', 'ActGen', 'Price', 'Volume']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> draw_features_correlation_heatmaps(df_general, season='general', translation=False, save_fig_dir=False)
    >>> draw_features_correlation_heatmaps(df_general, season='full', fontsize=12, translation=True, save_fig_dir='pictures')
    '''

    if season not in ['summer', 'winter', 'full', 'general']:
        raise ValueError(f'''Опция "{season}" для параметра season отсутствует. 
            Используйте доступные опции: "summer", "winter", "full", "general"''')
        
    df_gen = df_general.reindex(columns=['Year', 'Month', 'Day', 'Hour', 'Weekday', 'TypeDay', 'Temperature', 
                                         'Season', 'Light', 'ActCons', 'ActGen', 'Price', 'Volume'])

    summer_months, winter_months = [6, 7, 8], [1, 2, 3, 4, 5, 9, 10, 11, 12]
    df_summer = df_gen[df_gen.Month.isin(summer_months)].drop(columns=['Season'])
    df_winter = df_gen[df_gen.Month.isin(winter_months)].drop(columns=['Season'])
    
    if translation:
        df_summer = rus_features(df_summer)
        df_winter = rus_features(df_winter)
        df_gen = rus_features(df_gen)
    
    # Generate a mask for the upper triangle
    mask = np.triu(np.ones_like(df_gen.corr(), dtype=bool))

    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    color_map = sns.color_palette("vlag", as_cmap=True)
    
    if season in ['summer', 'winter', 'general']:
        parts = 1
        fig, axes = plt.subplots(figsize=(8, 7))
        if season == 'general':
            df_list = [df_gen]
            title_list = ['Корреляция признаков генеральной совокупности данных']
            mask = np.triu(np.ones_like(df_gen.corr(), dtype=bool))
        elif season == 'summer':
            df_list = [df_summer]
            title_list = ['Летняя корреляция']
            mask = np.triu(np.ones_like(df_summer.corr(), dtype=bool))
        elif season == 'winter':
            df_list = [df_winter]
            title_list = ['Зимняя корреляция']
            mask = np.triu(np.ones_like(df_winter.corr(), dtype=bool))
    else:
        parts = 2
        df_list = [df_winter, df_summer]
        title_list = ['Зимняя корреляция', 'Летняя корреляция']
        mask = np.triu(np.ones_like(df_winter.corr(), dtype=bool))
        fig, axes = plt.subplots(1, 2, figsize=(14, 7))

    # Draw the heatmap with the mask and correct aspect ratio
    for part in range(parts):
        if parts == 2:
            ax = axes[part]
        else:
            ax = axes
        sns.heatmap(df_list[part].corr(),
                    ax=ax,
                    annot=True, 
                    mask=mask, 
                    cmap=color_map, 
                    fmt=".2f", 
                    vmax=1.0, 
                    vmin=-1.0, 
                    center=0,
                    square=True, 
                    linewidths=1, 
                    cbar_kws={"shrink": .8})
        ax.set_title(title_list[part])

    plt.tight_layout()
    
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, f'{season}_corr_matrix')


def draw_hour_of_day_correlation_heatmaps(df_general, fontsize=18, font='Palatino Linotype', translation=True, save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение тепловой карты почасовых корреляций Пирсона для исходных признаков

    KEYWORD ARGUMENTS:
    df_general -- датафрейм с генеральной совокупностью после препроцессинг данных
    fontsize -- размер шрифта на карте
    font -- шрифт, используемый на графике
    translation -- перевод названий признаков на русский язык
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df_general обязательно наличие столбцов ['Year', 'Month', 'Day', 'Hour', 'Weekday', 'TypeDay', 'Temperature', 
                                                 'Season', 'Light', 'ActCons', 'ActGen', 'Price', 'Volume']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> draw_features_correlation_heatmaps(df_general, season='general', translation=False, save_fig_dir=False)
    >>> draw_features_correlation_heatmaps(df_general, season='full', fontsize=12, translation=True, save_fig_dir='pictures')
    '''
    
    df_gen = df_general.reindex(columns=['Year', 'Month', 'Day', 'Hour', 'Weekday', 'TypeDay', 'Light', 'Season',  
                                         'Temperature', 'ActCons', 'ActGen', 'Price', 'Volume'])
    
    features_to_correlate = df_gen.columns.drop('Hour')
    
    # generate hourly correlation
    hourly_correlations = pd.DataFrame()
    for hour in range(24):
        hourly_data = df_gen[df_gen.Hour == hour][features_to_correlate]
        hourly_correlations = pd.concat([hourly_correlations, hourly_data.corr().iloc[-1:, :-1]])

    hourly_correlations.reset_index(drop=True, inplace=True)
    
    if translation:
        hourly_correlations = rus_features(hourly_correlations)
    
    # Set up the matplotlib figure
    plt.rcParams['font.size'] = fontsize
    fig, ax = plt.subplots(figsize=(16, 7))

    color_map = sns.color_palette("vlag", as_cmap=True)

    # Draw the heatmap
    sns.heatmap(hourly_correlations.T, 
                #annot=True, 
                cmap=color_map, 
                fmt=".2f", 
                vmax=1.0, 
                vmin=-1.0, 
                center=0,
                square=True, 
                #linewidths=1, 
                cbar_kws={"shrink": .8}).set(title='Почасовая корреляция объёмов энергопотребления и исходных признаков')

    plt.tight_layout()
    
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, 'Hour-of-day_correlation_heatmaps')


def draw_bar_CatBoost_feature_importances(selector, df_general_cat, fontsize=14, font='Palatino Linotype', translation=True, save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение диаграммы ценности признаков, полученных с помощью встроенного селектора CatBoost-регрессора

    KEYWORD ARGUMENTS:
    selector -- обученный CatBoost feature-селектор
    df_general_cat -- датафрейм с нативным кодированием категориальных признаков
    fontsize -- размер шрифта на диаграмме
    font -- шрифт, используемый на графике
    translation -- перевод названий признаков на русский язык
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df_general_cat обязательно наличие столбцов ['Date', 'Volume']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> draw_bar_CatBoost_feature_importances(selector, df_general_cat, fontsize=14, translation=False)
    >>> draw_bar_CatBoost_feature_importances(selector, df_general_cat, fontsize=14, translation=True, save_fig_dir=True)
    '''   
    
    features_table = pd.DataFrame(selector.feature_importances_, 
                                  index = df_general_cat.drop(columns=['Date', 'Volume']).columns, 
                                  columns = ['importance'])
    
    feature_importances = features_table.sort_values(by='importance', ascending=False)
    
    if translation:
        feature_importances = rus_features(feature_importances, 'index')
    
    features_table = feature_importances.T
    
    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    color_map = sns.color_palette("vlag", as_cmap=True)

    plt.figure(figsize=(12, 5))

    for bar in plt.bar(range(len(feature_importances.index)), feature_importances.importance, align='center', width=0.8):
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2, yval, round(yval, 3), ha='center', va='bottom')

    plt.xticks(range(len(feature_importances.index)), feature_importances.index, rotation=90)
    plt.ylim(0, 10*(feature_importances.values.max() // 10 + 1))
    plt.ylabel('Вес признака, %')
    plt.title('Ценность признака в контексте CatBoost-регрессора')
    plt.tight_layout()
    
    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, 'CatBoost_feature_important')

    plt.show()


def draw_bar_SHAP_feature_importances(shap_values, fontsize=14, font='Palatino Linotype', translation=True, save_fig_dir=False):
    
    '''
    SYNOPSYS: Построение диаграммы ценности признаков, полученных с помощью SHAP.Explainer

    KEYWORD ARGUMENTS:
    shap_values -- массив эксплайнеров для предобученного CatBoost feature-селектора
    fontsize -- размер шрифта на диаграмме
    font -- шрифт, используемый на графике
    translation -- перевод названий признаков на русский язык
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df_general_cat обязательно наличие столбцов ['Date', 'Volume']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> draw_bar_SHAP_feature_importances(shap_values, fontsize=16, translation=True, save_fig_dir=False)
    '''
    
    cohorts = {"": shap_values}
    cohort_exps = list(cohorts.values())
    for i in range(len(cohort_exps)):
        if len(cohort_exps[i].shape) == 2:
            cohort_exps[i] = cohort_exps[i].abs.mean(0)
    feature_names = cohort_exps[0].feature_names
    values = np.array([cohort_exps[i].values for i in range(len(cohort_exps))])
    feature_importance = pd.DataFrame(
        list(zip(feature_names, sum(values))), columns=['features', 'importance'])
    feature_importance.sort_values(by=['importance'], ascending=False, inplace=True)
    SHAP_importances = feature_importance.set_index('features')
    
    if translation:
        SHAP_importances = rus_features(SHAP_importances, 'index')

    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    plt.figure(figsize=(12, 5))

    for bar in plt.bar(range(len(SHAP_importances.index)), SHAP_importances.importance, align='center', width=0.8):
        yval = bar.get_height()
        
        plt.text(bar.get_x() + bar.get_width()/2, 
                yval, 
                round(yval, 2), 
                ha='center', 
                va='bottom')

    plt.xticks(range(len(SHAP_importances.index)), SHAP_importances.index, rotation=90, fontsize=fontsize)
    plt.ylim(0, (SHAP_importances.importance.max() // 50 + 1) * 50)
    plt.ylabel('mean(|SHAP value|), МВт·ч', fontsize=fontsize)
    plt.title('Ценность признака в контексте SHAP-оценщика', fontsize=fontsize)
    plt.tight_layout()

    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, 'SHAP_feature_important')

    plt.show()


def plot_and_save_shap_scatter(feature_name,
                               df_general_cat, 
                               shap_values, 
                               interaction_index=None, 
                               fontsize=14, 
                               font='Palatino Linotype',
                               translation=True,
                               save_fig_dir=False,
                               filename='',
                              ):
    
    '''
    SYNOPSYS: Построение shap.dependence_plot для выбранного признака

    KEYWORD ARGUMENTS:
    feature_name -- исследуемый признак
    df_general_cat -- датафрейм с нативным кодированием категориальных признаков
    shap_values -- массив эксплайнеров для предобученного CatBoost feature-селектора
    filename -- название экспортируемой фигуры
    font -- шрифт, используемый на графике
    interaction_index -- вторичный исследуемый признак (по умолчанию отсутствует)
    fontsize -- размер шрифта на графике
    translation -- перевод названий признаков на русский язык
    save_fig_dir -- сохранение графика в указанную директорию 
    (False - без сохранения, True - сохранение в директорию ./pictures)

    WARNING:
    Для df_general_cat обязательно наличие столбцов ['Date', 'Volume']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> plot_and_save_shap_scatter(feature_name='Temperature',
                                   df_general_cat=df_general_cat,
                                   shap_values=shap_values,
                                   interaction_index='Season',
                                   fontsize=13.5,
                                   translation=False,
                                   save_fig_dir=True,
                                   filename='SHAP_dependence_Temperature',
                                  )

    >>> plot_and_save_shap_scatter('ActCons',
                                    df_general_cat,
                                    shap_values,
                                    interaction_index='Price',
                                    translation=False,
                                    save_fig_dir=True,
                                    filename='SHAP_dependence_ActCons',                           
                                   )
    ''' 
    
    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = fontsize
    fig, ax = plt.subplots(figsize=(7, 4))
    
    shap.dependence_plot(feature_name, shap_values.values, 
                         df_general_cat.drop(columns=['Date', 'Volume']), 
                         interaction_index=interaction_index,
                         show=False,
                         ax=ax,
                         )
    
    if translation:
        pass  # реализовать логику в будущем
    
    ax.xaxis.label.set_fontsize(fontsize)
    ax.yaxis.label.set_fontsize(fontsize)
    ax.tick_params(axis='x', labelsize=fontsize)
    ax.tick_params(axis='y', labelsize=fontsize)
    
    if interaction_index is not None:
        if len(fig.axes) > 1:
            cax = fig.axes[1]
            if hasattr(cax, 'yaxis') and hasattr(cax.yaxis, 'label'):
                cax.yaxis.label.set_fontsize(fontsize)
                cax.tick_params(axis='y', labelsize=fontsize)
            if hasattr(cax, 'xaxis') and hasattr(cax.xaxis, 'label'):
                cax.xaxis.label.set_fontsize(fontsize)
                cax.tick_params(axis='x', labelsize=fontsize)
                
    plt.tight_layout()

    if save_fig_dir:
        save_fig_to_pdf(plt, save_fig_dir, filename)

    plt.show()


def draw_example_decision_tree(df_general_cat, max_depth, tree_idx):
    
    '''
    SYNOPSYS: Построение экземпляра решающего дерева CatBoost-регрессора

    KEYWORD ARGUMENTS:
    df_general_cat -- датафрейм с нативным кодированием категориальных признаков
    max_depth -- глубина решающего дерева (для адекватных размеров рекомендуется max_depth = 3)
    tree_idx -- номер решающего дерева

    WARNING:
    Для df_general_cat обязательно наличие столбцов ['Date', 'Volume']
    
    RETURNS:
    None
    
    EXAMPLE:
    >>> draw_example_decision_tree(df_general_cat, max_depth=3, tree_idx=191)
    '''
    
    X = df_general_cat.drop(columns=['Date', 'Volume'])
    y = df_general_cat.Volume

    cat_features=['Season', 'TypeDay', 'Light']
    
    pool = catboost.Pool(X, y, feature_names=list(X.columns), cat_features=cat_features)

    model = catboost.CatBoostRegressor(
                                       silent=True,
                                       n_estimators = 200,
                                       max_depth = max_depth,
                                       cat_features=cat_features
                                      ).fit(pool)

    return model.plot_tree(tree_idx=tree_idx, pool=pool)