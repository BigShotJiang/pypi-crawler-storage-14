"""SCP command."""

from .command import scp_command

__all__ = ["scp_command"]
