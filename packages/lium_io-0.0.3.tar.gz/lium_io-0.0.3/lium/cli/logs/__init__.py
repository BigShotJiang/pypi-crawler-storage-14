"""Logs command module."""

from .command import logs_command

__all__ = ["logs_command"]
