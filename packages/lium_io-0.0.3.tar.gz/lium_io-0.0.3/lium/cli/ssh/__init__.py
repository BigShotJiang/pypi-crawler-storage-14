"""SSH command."""

from .command import ssh_command

__all__ = ["ssh_command"]
