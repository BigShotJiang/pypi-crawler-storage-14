"""Init command."""

from .command import init_command

__all__ = ["init_command"]
