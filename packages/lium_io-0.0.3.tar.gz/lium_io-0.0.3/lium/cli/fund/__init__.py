"""Fund command."""

from .command import fund_command

__all__ = ["fund_command"]
