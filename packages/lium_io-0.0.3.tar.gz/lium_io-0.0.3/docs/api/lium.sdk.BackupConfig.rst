﻿lium.sdk.BackupConfig
=====================

.. currentmodule:: lium.sdk

.. autoclass:: BackupConfig

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BackupConfig.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BackupConfig.updated_at
      ~BackupConfig.id
      ~BackupConfig.huid
      ~BackupConfig.pod_executor_id
      ~BackupConfig.backup_frequency_hours
      ~BackupConfig.retention_days
      ~BackupConfig.backup_path
      ~BackupConfig.is_active
      ~BackupConfig.created_at
   
   