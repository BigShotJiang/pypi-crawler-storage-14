﻿lium.sdk.BackupLog
==================

.. currentmodule:: lium.sdk

.. autoclass:: BackupLog

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BackupLog.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~BackupLog.backup_volume_id
      ~BackupLog.completed_at
      ~BackupLog.created_at
      ~BackupLog.error_message
      ~BackupLog.progress
      ~BackupLog.id
      ~BackupLog.huid
      ~BackupLog.backup_config_id
      ~BackupLog.status
      ~BackupLog.started_at
   
   