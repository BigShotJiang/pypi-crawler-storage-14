﻿lium.sdk.Template
=================

.. currentmodule:: lium.sdk

.. autoclass:: Template

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Template.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Template.id
      ~Template.name
      ~Template.huid
      ~Template.docker_image
      ~Template.docker_image_tag
      ~Template.category
      ~Template.status
   
   