﻿lium.sdk.VolumeInfo
===================

.. currentmodule:: lium.sdk

.. autoclass:: VolumeInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~VolumeInfo.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~VolumeInfo.current_file_count
      ~VolumeInfo.current_size_bytes
      ~VolumeInfo.current_size_gb
      ~VolumeInfo.current_size_mb
      ~VolumeInfo.last_metrics_update
      ~VolumeInfo.updated_at
      ~VolumeInfo.id
      ~VolumeInfo.huid
      ~VolumeInfo.name
      ~VolumeInfo.description
      ~VolumeInfo.created_at
   
   