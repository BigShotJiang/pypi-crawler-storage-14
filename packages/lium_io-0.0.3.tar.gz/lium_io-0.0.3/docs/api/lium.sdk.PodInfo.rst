﻿lium.sdk.PodInfo
================

.. currentmodule:: lium.sdk

.. autoclass:: PodInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PodInfo.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~PodInfo.host
      ~PodInfo.ssh_port
      ~PodInfo.username
      ~PodInfo.id
      ~PodInfo.name
      ~PodInfo.status
      ~PodInfo.huid
      ~PodInfo.ssh_cmd
      ~PodInfo.ports
      ~PodInfo.created_at
      ~PodInfo.updated_at
      ~PodInfo.executor
      ~PodInfo.template
      ~PodInfo.removal_scheduled_at
      ~PodInfo.jupyter_installation_status
      ~PodInfo.jupyter_url
   
   