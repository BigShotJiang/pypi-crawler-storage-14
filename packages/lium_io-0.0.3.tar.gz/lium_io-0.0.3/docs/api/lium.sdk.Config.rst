﻿lium.sdk.Config
===============

.. currentmodule:: lium.sdk

.. autoclass:: Config

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Config.__init__
      ~Config.load
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Config.base_pay_url
      ~Config.base_url
      ~Config.ssh_key_path
      ~Config.ssh_public_keys
      ~Config.api_key
   
   