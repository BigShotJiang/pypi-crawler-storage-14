﻿lium.sdk.ExecutorInfo
=====================

.. currentmodule:: lium.sdk

.. autoclass:: ExecutorInfo

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ExecutorInfo.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ExecutorInfo.available_port_count
      ~ExecutorInfo.driver_version
      ~ExecutorInfo.gpu_model
      ~ExecutorInfo.id
      ~ExecutorInfo.huid
      ~ExecutorInfo.machine_name
      ~ExecutorInfo.gpu_type
      ~ExecutorInfo.gpu_count
      ~ExecutorInfo.price_per_hour
      ~ExecutorInfo.price_per_gpu_hour
      ~ExecutorInfo.location
      ~ExecutorInfo.specs
      ~ExecutorInfo.status
      ~ExecutorInfo.docker_in_docker
   
   