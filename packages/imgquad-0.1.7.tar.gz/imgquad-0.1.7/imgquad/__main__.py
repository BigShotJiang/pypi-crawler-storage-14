#! /usr/bin/env python3


"""imgquad.__main__: executed when imgquad directory is called as script."""


from .imgquad import main
main()
