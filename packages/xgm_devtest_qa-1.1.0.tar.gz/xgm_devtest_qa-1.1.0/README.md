# SystemQ - QA设备驱动

QA设备驱动包，用于控制 XGM MDS24 设备。

## 安装

```bash
pip install systemq
```

## 使用方法

### 1. 启动服务

```bash
quark remote remote.json
```

### 2. 控制设备

```python
from quark import connect

adc = connect('ADC', host='127.0.0.1', port=1169)
```

## 依赖

- quarkstudio[remote]
- waveforms
- numpy

## 版本信息

- QA驱动版本: V1.0-20250523
- QA-SQ版本: V1.2-20250719

## 许可证

MIT License