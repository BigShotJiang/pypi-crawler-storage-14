"""MCP Server for Easy Instagram Automation Service"""
