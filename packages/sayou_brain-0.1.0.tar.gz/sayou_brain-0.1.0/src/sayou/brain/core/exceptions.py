from sayou.core.exceptions import SayouCoreError

class BrainError(SayouCoreError):
    """'initialize()' 메서드 실패 시 발생하는 공통 오류"""
    pass