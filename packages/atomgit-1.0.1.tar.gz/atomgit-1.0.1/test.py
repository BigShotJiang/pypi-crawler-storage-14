#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AtomGit Hub 功能测试
"""

from atomgit_hub import (
    create_repository, 
    upload_folder, 
    snapshot_download, 
    hub_download_url, 
    download_file, 
    load_dataset
)
from pathlib import Path


def test_create_model(repo_id: str, repo_type: str):
    print("\n=== 测试 create_repository ===")
    try:
        result = create_repository(
            repo_id=repo_id,
            token=None,  # 使用保存的token
            private=True,
            repo_type=repo_type,
            exist_ok=True,
            space_sdk=None,
            space_hardware=None,
            space_storage=None,
            space_sleep_time=None,
            space_secrets=None,
            space_variables=None
        )
        print(f"✅ 创建仓库成功: {result}")
    except Exception as e:
        print(f"❌ 创建仓库失败: {e}")

def test_upload_folder(repo_id: str, folder_path: str):
    print("\n=== 测试 upload_folder ===")
    
    try:
        result = upload_folder(
            folder_path=folder_path,
            repo_id=repo_id,
            token=None,  # 使用保存的token
            commit_message="Test upload with all parameters",
            commit_description="Full parameter test for upload_folder function"
        )
        print(f"✅ 上传文件夹成功: {result}")
    except Exception as e:
        print(f"❌ 上传文件夹失败: {e}")

def test_snapshot_download(repo_id: str, local_dir: str):
    print("\n=== 测试 snapshot_download ===")
    try:
        local_path = snapshot_download(
            repo_id=repo_id,
            local_dir=local_dir,
            proxies=None,
            etag_timeout=10,
            resume_download=False,
            force_download=True,
            token=None,  # 使用保存的token
            local_files_only=False,
            max_workers=8,
            tqdm_class=None
        )
        print(f"✅ 下载快照成功: {local_path}")
    except Exception as e:
        print(f"❌ 下载快照失败: {e}")

def test_download_file(repo_id: str, filename: str, local_dir: str):
    print("\n=== 测试 download_file ===")
    try:
        file_path = download_file(
            repo_id=repo_id,
            filename=filename,
            local_dir=local_dir,
            token=None,  # 使用保存的token
            force_download=True
        )
        print(f"✅ 下载文件成功: {file_path}")
    except Exception as e:
        print(f"❌ 下载文件失败: {e}")


def test_hub_download_url(repo_id: str, filename: str, repo_type: str):
    print("\n=== 测试 hub_download_url ===")
    try:
        url = hub_download_url(
            repo_id=repo_id,
            filename=filename,
            repo_type=repo_type
        )
        print(f"✅ 获取URL成功: {url}")
    except Exception as e:
        print(f"❌ 获取URL失败: {e}")

def test_load_dataset(repo_id: str, local_dir: str):
    print("\n=== 测试 load_dataset ===")
    try:
        dataset = load_dataset(
            path=repo_id,
            cache_dir=local_dir,
            token=None
        )
        print(f"✅ 加载数据集成功: {dataset}")
    except Exception as e:
        print(f"❌ 加载数据集失败: {e}")


def run_all_tests():
    """运行所有测试"""
    print("=" * 60)
    print("开始运行 AtomGit Hub 完整参数测试")
    print("=" * 60)
    model = "ai-test/atomgit-cli-test-model-full"
    dataset = "ai-test/atomgit-cli-test-dataset-full"
    
    model_folder_path="/Users/yanlp/csdn/aipython/gitcode_cli/site/yanlp-model-1"
    dataset_folder_path="/Users/yanlp/csdn/aipython/gitcode_cli/site/yanlp-model-1"

    test_dataset = "yanlp/glaive_toolcall_zh"
    # 注意：按照依赖顺序执行测试
    # 1. 先创建仓库
    # test_create_model(repo_id=model, repo_type="model")
    # test_create_model(repo_id=dataset, repo_type="dataset")
    
    # 2. 测试upload
    # test_upload_folder(repo_id=model, folder_path=model_folder_path)
    # test_upload_folder(repo_id=dataset, folder_path=dataset_folder_path)

    # 3. 测试下载
    test_snapshot_download(repo_id=model, local_dir="./test_downloads/model/snapshot_full")
    # test_snapshot_download(repo_id="hf_mirrors/Qwen/Qwen3-0.6B", local_dir="./test_downloads/dataset/snapshot_full2")
    
    # 4. 测试下载文件
    # test_download_file(repo_id=model, filename="README.md", local_dir="./test_downloads/model/single_file")

    # 5. 测试URL获取
    # test_hub_download_url(repo_id=model, filename="model.safetensors", repo_type="model")

    # 6. 测试数据集加载
    # test_load_dataset(repo_id=test_dataset, local_dir="./test_downloads/dataset/load_dataset")
    
    print("\n" + "=" * 60)
    print("所有测试完成")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()
