class SQSError(Exception):
    pass
