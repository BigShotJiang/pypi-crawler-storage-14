__all__ = ["EuronewsParser"]

from .euronews import EuronewsParser
