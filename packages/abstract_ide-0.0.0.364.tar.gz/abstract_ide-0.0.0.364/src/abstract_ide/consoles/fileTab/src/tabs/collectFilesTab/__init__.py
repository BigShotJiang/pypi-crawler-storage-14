from .main import collectFilesTab
