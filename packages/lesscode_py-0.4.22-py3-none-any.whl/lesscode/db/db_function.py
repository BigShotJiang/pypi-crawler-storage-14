# -*- coding: utf-8 -*-

class DBFunction:
    def __init__(self, function_body, value):
        self.function_body = function_body
        self.value = value
