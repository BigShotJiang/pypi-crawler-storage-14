__all__ = ['last']

def last(it):
    x = None
    for a in it:
        x = a
    return x
