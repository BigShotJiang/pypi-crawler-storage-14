"""
AI Studio Proxy - Playwright-based proxy server for AI Studio interactions

This package provides a proxy server that enables OpenAI-compatible API access
to Google AI Studio through browser automation.

Usage:
    # As CLI tools
    $ aistudio-proxy --port 2048      # Start the proxy server
    $ aistudio-llm --port 11434       # Start Ollama-compatible LLM service
    $ aistudio-gui                    # Start the GUI launcher
    $ aistudio-launch --debug         # Launch Camoufox browser

    # As a library
    from aistudio_proxy import create_app, run_server
    
    app = create_app()
    run_server(port=2048)
"""

__version__ = "0.2.0"
__author__ = "Your Name"
__email__ = "you@example.com"

from api_utils import create_app
from .server import run_server
from .cli import main, llm_main, gui_main, launch_main

__all__ = [
    "__version__",
    "create_app",
    "run_server",
    "main",
    "llm_main",
    "gui_main",
    "launch_main",
]
