"""
AI Studio Proxy - Command Line Interface

Provides CLI entry points for the proxy server, LLM mock service, GUI launcher, and browser launcher.
"""

import argparse
import os
import sys


def _get_package_root():
    """Get the root directory where package files are located."""
    # First try the installed package location
    import aistudio_proxy
    package_dir = os.path.dirname(os.path.abspath(aistudio_proxy.__file__))
    
    # Check if we're in development mode (source directory)
    parent_dir = os.path.dirname(package_dir)
    if os.path.exists(os.path.join(parent_dir, "server.py")):
        return parent_dir
    
    # Check if files are in the package directory itself
    if os.path.exists(os.path.join(package_dir, "server.py")):
        return package_dir
    
    # Fallback to current working directory
    return os.getcwd()


def main():
    """
    Main entry point for the AI Studio Proxy server.
    
    Usage:
        $ aistudio-proxy
        $ aistudio-proxy --port 8080
        $ aistudio-proxy --host 127.0.0.1 --port 8080 --log-level debug
    """
    parser = argparse.ArgumentParser(
        prog="aistudio-proxy",
        description="AI Studio Proxy Server - OpenAI-compatible API proxy for Google AI Studio",
    )
    parser.add_argument(
        "--host",
        type=str,
        default=os.environ.get("HOST", "0.0.0.0"),
        help="Host address to bind to (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--port", "-p",
        type=int,
        default=int(os.environ.get("PORT", 2048)),
        help="Port number to listen on (default: 2048)",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default=os.environ.get("LOG_LEVEL", "info"),
        choices=["debug", "info", "warning", "error", "critical"],
        help="Logging level (default: info)",
    )
    parser.add_argument(
        "--access-log",
        action="store_true",
        help="Enable access logging",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development",
    )
    parser.add_argument(
        "--version", "-v",
        action="version",
        version="%(prog)s 0.1.0",
    )
    
    args = parser.parse_args()
    
    from .server import run_server
    
    print(f"Starting AI Studio Proxy Server on {args.host}:{args.port}")
    run_server(
        host=args.host,
        port=args.port,
        log_level=args.log_level,
        access_log=args.access_log,
        reload=args.reload,
    )


def llm_main():
    """
    Entry point for the LLM mock service (Ollama-compatible).
    
    Usage:
        $ aistudio-llm
        $ aistudio-llm --main-server-port 8080
    """
    from . import _llm_service
    _llm_service.main()


def gui_main():
    """
    Entry point for the GUI launcher.
    
    Usage:
        $ aistudio-gui
    """
    # Change to package root directory so relative imports work
    package_root = _get_package_root()
    os.chdir(package_root)
    
    # Add package root to path
    if package_root not in sys.path:
        sys.path.insert(0, package_root)
    
    # Import and run gui_launcher
    try:
        import gui_launcher
        gui_launcher.main()
    except ImportError as e:
        print(f"Error: Could not import gui_launcher: {e}", file=sys.stderr)
        print(f"Package root: {package_root}", file=sys.stderr)
        print("Please ensure gui_launcher.py is available.", file=sys.stderr)
        sys.exit(1)


def launch_main():
    """
    Entry point for the Camoufox browser launcher.
    
    Usage:
        $ aistudio-launch
        $ aistudio-launch --debug
        $ aistudio-launch --headless
    """
    # Change to package root directory so relative imports work
    package_root = _get_package_root()
    os.chdir(package_root)
    
    # Add package root to path
    if package_root not in sys.path:
        sys.path.insert(0, package_root)
    
    # Import and run launch_camoufox
    try:
        import launch_camoufox
        # The script handles its own argument parsing in __main__
        # We need to re-run it as main
        if hasattr(launch_camoufox, 'main'):
            launch_camoufox.main()
        else:
            # If no main function, the script runs on import via __main__ block
            # We need to execute it differently
            import runpy
            runpy.run_path(os.path.join(package_root, "launch_camoufox.py"), run_name="__main__")
    except ImportError as e:
        print(f"Error: Could not import launch_camoufox: {e}", file=sys.stderr)
        print(f"Package root: {package_root}", file=sys.stderr)
        print("Please ensure launch_camoufox.py is available.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
