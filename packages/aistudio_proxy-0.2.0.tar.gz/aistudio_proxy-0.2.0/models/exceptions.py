class ClientDisconnectedError(Exception):
    """客户端断开连接异常"""
    pass 