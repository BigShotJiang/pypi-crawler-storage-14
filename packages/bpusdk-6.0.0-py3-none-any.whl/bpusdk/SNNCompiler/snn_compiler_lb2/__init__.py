"""SNN 模型编译成 SMT lb2 语句
"""
from . import *