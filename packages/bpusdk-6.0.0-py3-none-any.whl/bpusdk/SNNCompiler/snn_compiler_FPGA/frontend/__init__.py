"""前端 Stablehlo IR 解析
"""
