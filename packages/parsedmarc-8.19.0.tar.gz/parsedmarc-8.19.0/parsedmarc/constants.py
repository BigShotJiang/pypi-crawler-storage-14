__version__ = "8.19.0"
USER_AGENT = f"parsedmarc/{__version__}"
