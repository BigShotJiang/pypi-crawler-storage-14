class ValidationError(BaseException):
    pass


class SchemaError(BaseException):
    pass
