import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Union,
    get_args,
    get_origin,
    get_type_hints,
)

from jinja2 import Environment, FileSystemLoader, Template, select_autoescape
from pydantic import BaseModel, ValidationError

if TYPE_CHECKING:
    from fastmcp import FastMCP


DEFAULT_STEP_TEMPLATE = """\
Workflow: {{ workflow_name }}
Execution ID: {{ execution_id }}
Step: {{ step_name }}
Step ID: {{ step_id }}

## Instructions
{{ instructions }}

## Result Schema
{{ result_schema }}

{% if artifacts %}
## Available Artifacts
Previous steps have created the following artifacts:
{% for artifact in artifacts %}
- {{ artifact.name }}{% if artifact.description %}: {{ artifact.description }}{% endif %}
  Path: {{ artifact.path }}
{% endfor %}
{% endif %}

## Next Action
When complete, call `{{ workflow_name }}__complete_step` with:
  - execution_id: {{ execution_id }}
  - step_id: {{ step_id }}
  - status: SUCCESS or ERROR
  - output: <your output matching the schema above>

Use status=SUCCESS when the step completed successfully.
Use status=ERROR if you encountered an error - the step will be retried.
"""  # noqa: E501


class Workflow:
    """Base class for workflows. Subclass to create a workflow."""

    _tools: list[tuple[str, Callable]]
    _steps: dict[str, type]  # step class name -> step class
    _start_step: str | None
    _active_executions: dict[str, object]  # execution_id -> current step instance
    _output_dirs: dict[str, Path]  # execution_id -> output directory
    _jinja_env: Environment | None  # Jinja2 environment for templates
    Step: type  # Step base class for this workflow
    output_dir: Path = Path(".artificer")  # base output directory
    templates_dir: Path | None = None  # Override to set templates directory
    step_template: str | None = None  # Override to load step template from file

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Initialize class-level state
        cls._tools = []
        cls._steps = {}
        cls._start_step = None
        cls._active_executions = {}
        cls._output_dirs = {}

        # Set up Jinja2 environment if templates_dir is set
        if cls.templates_dir is not None:
            cls._jinja_env = Environment(
                loader=FileSystemLoader(cls.templates_dir),
                autoescape=select_autoescape(),
            )
        else:
            cls._jinja_env = None

        cls.Step = cls._create_step_class()

    @classmethod
    def _create_step_class(cls):
        workflow = cls

        class Step:
            """Base class for workflow steps.

            Implement start() and complete() methods.
            """

            max_retries: int = 3  # Can be overridden per step
            id: str
            execution_id: str | None
            result: BaseModel | None  # Output from previous step
            accumulated_artifacts: list[dict]  # Artifacts from previous steps

            def __init__(
                self,
                execution_id: str | None = None,
                result: BaseModel | None = None,
                accumulated_artifacts: list[dict] | None = None,
            ):
                self.id = f"{uuid.uuid4()}:attempt:1"
                self.execution_id = execution_id
                self.result = result
                self.accumulated_artifacts = accumulated_artifacts or []

            def render_template(self, template_name: str) -> str:
                """Render a template file with context."""
                if workflow._jinja_env is None:
                    msg = f"Workflow '{workflow.__name__}' has no templates_dir set"
                    raise RuntimeError(msg)
                template = workflow._jinja_env.get_template(template_name)
                return template.render(
                    result=self.result,
                    artifacts=self.accumulated_artifacts,
                )

            @staticmethod
            def _parse_step_id(step_id: str) -> tuple[str, int]:
                """Parse step ID into (uuid, attempt)."""
                parts = step_id.rsplit(":attempt:", 1)
                if len(parts) == 2:
                    return parts[0], int(parts[1])
                return step_id, 1

            @staticmethod
            def _make_step_id(step_uuid: str, attempt: int) -> str:
                """Create step ID from uuid and attempt."""
                return f"{step_uuid}:attempt:{attempt}"

            def _get_output_model(self) -> type[BaseModel] | None:
                """Extract the output model from complete() type annotation."""
                if not hasattr(self, "complete"):
                    return None

                type_hints = get_type_hints(self.complete)
                if "output" not in type_hints:
                    return None

                output_type = type_hints["output"]
                if isinstance(output_type, type) and issubclass(output_type, BaseModel):
                    return output_type
                return None

            def render(self) -> str:
                """Render the full step prompt."""
                # Get instructions from start() method
                if not hasattr(self, "start"):
                    msg = f"{type(self).__name__} must define 'start()' method"
                    raise TypeError(msg)
                instructions = self.start()

                # Get result schema from complete() type annotation
                output_model = self._get_output_model()
                if output_model is not None:
                    schema = output_model.model_json_schema()
                    result_schema = json.dumps(schema, indent=2)
                else:
                    result_schema = json.dumps({"type": "object"}, indent=2)

                # Use file template if specified, otherwise use inline default
                if workflow.step_template is not None:
                    if workflow._jinja_env is None:
                        msg = f"Workflow '{workflow.__name__}' has no templates_dir set"
                        raise RuntimeError(msg)
                    template = workflow._jinja_env.get_template(workflow.step_template)
                else:
                    template = Template(DEFAULT_STEP_TEMPLATE)
                return template.render(
                    workflow_name=workflow.__name__,
                    execution_id=self.execution_id or "N/A",
                    step_name=type(self).__name__,
                    step_id=self.id,
                    instructions=instructions,
                    result_schema=result_schema,
                    artifacts=self.accumulated_artifacts,
                )

            def __init_subclass__(step_cls, start: bool = False, **kwargs):
                super().__init_subclass__(**kwargs)
                if not hasattr(step_cls, "start"):
                    msg = f"{step_cls.__name__} must define 'start()' method"
                    raise TypeError(msg)
                if not hasattr(step_cls, "complete"):
                    msg = f"{step_cls.__name__} must define 'complete()' method"
                    raise TypeError(msg)

                # Store class by name
                step_name = step_cls.__name__
                workflow._steps[step_name] = step_cls

                # Track start step
                if start:
                    if workflow._start_step is not None:
                        msg = f"Workflow already has start step: {workflow._start_step}"
                        raise TypeError(msg)
                    workflow._start_step = step_name

                # Collect for tool registration (wrapper creates instance per call)
                def make_tool(cls):
                    def tool_fn():
                        instance = cls()
                        return instance.start()

                    tool_fn.__doc__ = f"Get instructions for {cls.__name__}"
                    return tool_fn

                tool_name = f"{workflow.__name__}__{step_name}"
                workflow._tools.append((tool_name, make_tool(step_cls)))

        return Step

    @classmethod
    def get_next(
        cls,
        step_instance: object,
        validated_output: BaseModel | dict,
        current_artifacts: list[dict],
    ) -> object | None:
        """Get the next step by calling complete() with validated output."""
        if not hasattr(step_instance, "complete"):
            return None

        # Call complete() with the validated output
        next_step_class = step_instance.complete(validated_output)
        if next_step_class is None:
            return None

        # Accumulate artifacts from previous steps
        accumulated = getattr(step_instance, "accumulated_artifacts", [])
        all_artifacts = accumulated + current_artifacts

        # Instantiate the next step with the validated output and artifacts
        return next_step_class(
            result=validated_output,
            accumulated_artifacts=all_artifacts,
        )

    @classmethod
    def _write_step_file(
        cls, execution_id: str, step_instance: object, output: dict | None = None
    ):
        """Append step log entry to logs.json."""
        workflow_dir = cls._output_dirs.get(execution_id)
        if workflow_dir is None:
            return

        logs_file = workflow_dir / "logs.json"

        # Load existing logs or create empty array
        if logs_file.exists():
            try:
                logs = json.loads(logs_file.read_text())
            except json.JSONDecodeError:
                # If corrupted, start fresh
                logs = []
        else:
            logs = []

        # Extract artifacts from output if present (handles both singular and plural)
        artifacts = []
        if output and isinstance(output, dict):
            if "artifacts" in output:
                artifacts = output.get("artifacts", [])
            elif "artifact" in output:
                artifact = output.get("artifact")
                if artifact:
                    artifacts = [artifact]

        # Create new log entry
        entry = {
            "timestamp": datetime.now().isoformat(),
            "step_name": type(step_instance).__name__,
            "step_id": step_instance.id,
            "prompt": step_instance.render(),
            "output": output,
            "artifacts": artifacts,
        }

        # Append and write
        logs.append(entry)
        logs_file.write_text(json.dumps(logs, indent=2))

    @classmethod
    def start_workflow(cls) -> dict:
        """Start a new workflow execution and return the first step info."""
        if cls._start_step is None:
            raise RuntimeError(f"Workflow '{cls.__name__}' has no start step defined")

        execution_id = str(uuid.uuid4())

        # Create output directory for this workflow execution
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dir_name = f"workflow-{cls.__name__}-{timestamp}-{execution_id}"
        workflow_dir = cls.output_dir / dir_name
        workflow_dir.mkdir(parents=True, exist_ok=True)
        cls._output_dirs[execution_id] = workflow_dir

        # Create new instance of start step
        step_class = cls._steps[cls._start_step]
        step_instance = step_class(execution_id=execution_id)

        cls._active_executions[execution_id] = step_instance

        # Write step file
        cls._write_step_file(execution_id, step_instance)

        first_tool_name = f"{cls.__name__}__{cls._start_step}"

        return {
            "execution_id": execution_id,
            "step_id": step_instance.id,
            "next_tool": first_tool_name,
            "next_step": cls._start_step,
            "prompt": step_instance.render(),
        }

    @classmethod
    def complete_step(
        cls, execution_id: str, step_id: str, status: str, output: dict[str, Any]
    ) -> dict:
        """Complete a step and return the next step's prompt."""
        if execution_id not in cls._active_executions:
            raise ValueError(f"Unknown execution_id: {execution_id}")

        current_step = cls._active_executions[execution_id]

        if current_step.id != step_id:
            msg = f"Step ID mismatch: expected {current_step.id}, got {step_id}"
            raise ValueError(msg)

        # Handle ERROR status - replay the current step
        if status == "ERROR":
            step_name = type(current_step).__name__
            step_uuid, attempt = current_step._parse_step_id(current_step.id)

            # Check if max retries exceeded
            if attempt >= current_step.max_retries:
                # Clean up
                del cls._active_executions[execution_id]
                if execution_id in cls._output_dirs:
                    del cls._output_dirs[execution_id]
                max_retries = current_step.max_retries
                return {
                    "execution_id": execution_id,
                    "status": "failed",
                    "message": f"Max retries ({max_retries}) exceeded for {step_name}",
                }

            # Increment attempt in step ID
            current_step.id = current_step._make_step_id(step_uuid, attempt + 1)

            cls._write_step_file(execution_id, current_step)
            return {
                "execution_id": execution_id,
                "step_id": current_step.id,
                "status": "retry",
                "attempt": attempt + 1,
                "max_retries": current_step.max_retries,
                "next_step": step_name,
                "prompt": current_step.render(),
            }

        # Validate output using Pydantic model from complete() type annotation
        output_model = current_step._get_output_model()
        if output_model is not None:
            try:
                validated_output = output_model.model_validate(output)
            except ValidationError as e:
                return {
                    "execution_id": execution_id,
                    "status": "validation_error",
                    "message": str(e),
                    "step": type(current_step).__name__,
                }
        else:
            # No output model, just use the raw output as a dict
            validated_output = output

        # Store the validated output on the step
        current_step.output = validated_output

        # Extract artifacts from output
        # (handles both singular 'artifact' and plural 'artifacts')
        step_artifacts = []
        if isinstance(validated_output, BaseModel):
            # Check for plural 'artifacts' field first
            if hasattr(validated_output, "artifacts"):
                artifacts_data = getattr(validated_output, "artifacts", None)
                if artifacts_data:
                    step_artifacts = [
                        a.model_dump() if isinstance(a, BaseModel) else a
                        for a in artifacts_data
                    ]
            # Check for singular 'artifact' field
            elif hasattr(validated_output, "artifact"):
                artifact_data = getattr(validated_output, "artifact", None)
                if artifact_data:
                    artifact_dict = (
                        artifact_data.model_dump()
                        if isinstance(artifact_data, BaseModel)
                        else artifact_data
                    )
                    step_artifacts = [artifact_dict]
        elif isinstance(validated_output, dict):
            # Dict output - check plural first, then singular
            if "artifacts" in validated_output:
                step_artifacts = validated_output.get("artifacts", [])
            elif "artifact" in validated_output:
                artifact = validated_output.get("artifact")
                if artifact:
                    step_artifacts = [artifact]

        # Write completed step file with output
        output_dict = (
            validated_output.model_dump()
            if isinstance(validated_output, BaseModel)
            else validated_output
        )
        cls._write_step_file(execution_id, current_step, output_dict)

        # Get next step and set execution_id
        next_step = cls.get_next(current_step, validated_output, step_artifacts)

        if next_step is not None:
            next_step.execution_id = execution_id

        if next_step is None:
            # Workflow complete
            del cls._active_executions[execution_id]
            if execution_id in cls._output_dirs:
                del cls._output_dirs[execution_id]
            return {
                "execution_id": execution_id,
                "status": "complete",
                "message": "Workflow completed successfully",
            }

        # Update active execution to next step
        cls._active_executions[execution_id] = next_step

        # Write next step file
        cls._write_step_file(execution_id, next_step)

        return {
            "execution_id": execution_id,
            "step_id": next_step.id,
            "next_step": type(next_step).__name__,
            "prompt": next_step.render(),
        }

    @classmethod
    def inspect_workflow(cls) -> str:
        """Generate a Mermaid flowchart diagram of the workflow structure.

        Analyzes the return type hints from each step's complete() method
        to determine transitions between steps, including conditional branches.

        Returns:
            A Mermaid flowchart diagram as a string, showing all steps and
            their possible transitions.
        """
        import sys
        import types

        def _resolve_step_class(arg: Any, step_class: type) -> type | None:
            """Resolve a step class from a type hint argument.

            Handles both actual class objects and forward reference strings.
            """
            if isinstance(arg, str):
                # Forward reference - look up in step's module
                module = sys.modules[step_class.__module__]
                resolved = getattr(module, arg, None)
                if resolved and isinstance(resolved, type):
                    return resolved
                return None
            elif isinstance(arg, type):
                return arg
            return None

        # Build nodes
        nodes = []
        nodes.append("    Start((Start))")

        # Add all step nodes
        for step_name in cls._steps:
            nodes.append(f"    {step_name}[{step_name}]")

        nodes.append("    End((End))")

        # Build edges
        edges = []

        # Start edge
        if cls._start_step:
            edges.append(f"    Start --> {cls._start_step}")

        # Step edges - analyze return types from complete() methods
        for step_name, step_class in cls._steps.items():
            if not hasattr(step_class, "complete"):
                continue

            try:
                hints = get_type_hints(step_class.complete)
                return_type = hints.get("return", None)

                if return_type is None:
                    # No type hint, skip
                    continue

                # Handle type[StepClass] wrapper
                if get_origin(return_type) is type:
                    # Extract the step class from type[StepClass]
                    args = get_args(return_type)
                    if args:
                        next_step_class = _resolve_step_class(args[0], step_class)
                        if next_step_class:
                            next_step_name = next_step_class.__name__
                            edges.append(f"    {step_name} --> {next_step_name}")
                # Handle Union types (e.g., type[StepA] | type[StepB] | None)
                # Check for both typing.Union and types.UnionType
                # (Python 3.10+ | operator)
                elif (
                    get_origin(return_type) is Union
                    or get_origin(return_type) is types.UnionType
                ):
                    # Extract all union members
                    union_args = get_args(return_type)
                    for arg in union_args:
                        if arg is type(None):  # noqa: E721
                            # None means terminal - edge to End
                            edges.append(f"    {step_name} --> End")
                        elif get_origin(arg) is type:
                            # type[StepClass] - extract inner class
                            inner_args = get_args(arg)
                            if inner_args:
                                next_step_class = _resolve_step_class(
                                    inner_args[0], step_class
                                )
                                if next_step_class:
                                    next_step_name = next_step_class.__name__
                                    edge = f"    {step_name} --> {next_step_name}"
                                    edges.append(edge)
                        elif isinstance(arg, type) and issubclass(arg, cls.Step):
                            # Direct step class reference
                            next_step_name = arg.__name__
                            edges.append(f"    {step_name} --> {next_step_name}")
                # Handle direct None return
                elif return_type is type(None):  # noqa: E721
                    edges.append(f"    {step_name} --> End")
                # Handle direct step class (if any workflows use this pattern)
                elif isinstance(return_type, type) and issubclass(
                    return_type, cls.Step
                ):
                    next_step_name = return_type.__name__
                    edges.append(f"    {step_name} --> {next_step_name}")

            except Exception:
                # If we can't get type hints, skip this step's edges
                continue

        # Build final diagram
        diagram_parts = ["flowchart TD"]
        diagram_parts.extend(nodes)
        diagram_parts.append("")  # Empty line between nodes and edges
        diagram_parts.extend(edges)

        return "\n".join(diagram_parts)

    @classmethod
    def register(cls, mcp: "FastMCP"):
        """Register this workflow's tools and resources with a FastMCP instance."""
        # Register workflow-level tools
        start_tool_name = f"{cls.__name__}__start_workflow"
        mcp.tool(name=start_tool_name)(cls.start_workflow)

        complete_tool_name = f"{cls.__name__}__complete_step"
        mcp.tool(name=complete_tool_name)(cls.complete_step)

        inspect_tool_name = f"{cls.__name__}__inspect_workflow"
        mcp.tool(name=inspect_tool_name)(cls.inspect_workflow)

        # Register step tools
        for tool_name, bound_method in cls._tools:
            mcp.tool(name=tool_name)(bound_method)

        # Register workflow prompt
        def workflow_prompt() -> str:
            """Start a new workflow execution."""
            result = cls.start_workflow()
            return result["prompt"]

        mcp.prompt(name=cls.__name__)(workflow_prompt)
