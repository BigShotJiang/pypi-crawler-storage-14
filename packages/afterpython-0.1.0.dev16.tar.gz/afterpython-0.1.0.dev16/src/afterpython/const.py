from afterpython._typing import tContentType

NODEENV_VERSION = "24.11.0"
CONTENT_TYPES: set[tContentType] = {"doc", "blog", "tutorial", "example", "guide"}
