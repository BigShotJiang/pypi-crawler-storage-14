KEY_SEPARATOR = '__.__'  # defined here as it is needed in datastore_srv and global_types
