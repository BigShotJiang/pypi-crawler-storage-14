"""Malha v0.9.0 - "Fat Kernel" - Sistema Operacional Semântico.

Unified Data & Compute Kernel with P2P Replication and Zero-ETL Federation.

This version consolidates infrastructure responsibilities into the kernel:
- Context Management: Thread/async-safe kernel injection
- Stream Drivers: High-performance data lake writes (Parquet)
- Compute Drivers: Safe script execution (PEP 723 + uv)
- Transaction Management: UnitOfWork for atomic graph operations
- Process State: Durable workflow persistence (SysProcess)

Quick Start:
    ```python
    from malha import connect, get_kernel
    from registro import DomainResource, register

    class User(DomainResource):
        name: str
        email: str

    register("User", User)

    async def main():
        # Connect creates kernel and sets it in global context
        kernel = await connect()

        # Create and save a user
        user = User(name="Alice", email="alice@example.com")
        saved = await kernel.save_versioned(user)
        print(f"Saved: {saved.rid}")

        # Kernel is also available via get_kernel()
        assert get_kernel() is kernel

        # Cleanup
        await kernel.close()
    ```

Migration from v0.8:
    - Import set_kernel/get_kernel/clear_kernel from malha (not semantico)
    - Use kernel.stream.write() instead of DataLakeWriter
    - Use kernel.compute.execute() instead of EphemeralRuntime
    - Use UnitOfWork for atomic multi-object operations
"""

# Dynamic version from pyproject.toml
try:
    from importlib.metadata import version
    __version__ = version("malha")
except Exception:
    __version__ = "0.10.7"

# Core API
from .instrumentation import KernelInstrumentation

# Drivers and Core Components
from .malha import (
    # Core API (most users need only these)
    connect,
    create_manager,
    get_kernel,
    set_kernel,
    clear_kernel,
    UnifiedDataManager,
    BaseRepository,
    
    # Signals
    Signal,
    post_save,
    post_delete,
    post_ingest,
    Handler,
    
    # Errors
    OptimisticLockError,
    ValidationError,
    SystemOverloadedError,
    ConsistencyTimeoutError,
    RuntimeExecutionError,
    CodeSynthesisError,
    
    # Models
    SysOutbox,
    SysProcess,
    ProcessStatus,
    
    # Transaction Management (NEW in v0.9)
    UnitOfWork,
    
    # Stream Driver (NEW in v0.9)
    StreamDriver,
    ParquetStreamDriver,
    
    # Compute Driver (NEW in v0.9)
    ComputeDriver,
    ComputeResult,
    LocalComputeDriver,
    
    # Driver Protocols
    SQLDriver,
    GraphDriver,
    AnalyticsDriver,
    ReplicationDriver,
    
    # Driver Implementations
    AsyncSQLAlchemyDriver,
    KuzuActor,
    KuzuTask,
    KuzuConfig,
    DuckDBDriver,
    
    # Extensibility
    Interceptor,
)

# Observability
from .monitor import KernelMonitor, MetricTimer

# Services (Helix pattern)
from .services import TopologySyncService, generate_virtual_rid

# Boot & Maintenance (Lifecycle)
from .boot import (
    Bootloader,
    BootResult,
    boot_kernel,
    recoverable,
    register_recovery_handler,
    WORKFLOW_REGISTRY,
)
from .maintenance import (
    Janitor,
    CleanupResult,
    Migrator,
    MigrationResult,
    SchemaDrift,
    SmartCompactor,
    CompactionResult,
    run_cleanup,
    check_schema_drift,
)

# Alembic Migrations (optional, requires alembic package)
try:
    from .drivers.alembic import (
        AlembicDriver,
        MigrationInfo,
        init_migrations,
        run_migrations,
    )
except ImportError:
    AlembicDriver = None
    MigrationInfo = None
    init_migrations = None
    run_migrations = None

# Backwards compatibility aliases
KuzuDriver = KuzuActor


def check_api() -> dict[str, bool]:
    """Verify that all expected APIs are available.
    
    Use this to debug installation issues:
        >>> import malha
        >>> malha.check_api()
        {'set_kernel': True, 'clear_kernel': True, ...}
    """
    import inspect
    
    checks = {
        # Context Management
        "set_kernel": callable(globals().get("set_kernel")),
        "clear_kernel": callable(globals().get("clear_kernel")),
        "get_kernel": callable(globals().get("get_kernel")),
        
        # UnitOfWork
        "UnitOfWork": isinstance(globals().get("UnitOfWork"), type),
        
        # mget
        "UnifiedDataManager.mget": hasattr(UnifiedDataManager, "mget"),
        "BaseRepository.mget": hasattr(BaseRepository, "mget"),
        
        # Watermark
        "UnifiedDataManager.get_session_watermark": hasattr(UnifiedDataManager, "get_session_watermark"),
        "KuzuActor.get_watermark": hasattr(KuzuActor, "get_watermark"),
        
        # required_watermark in query
        "KuzuActor.query(required_watermark)": "required_watermark" in inspect.signature(KuzuActor.query).parameters,
    }
    
    print(f"Malha {__version__} API Check:")
    for name, available in checks.items():
        status = "✅" if available else "❌"
        print(f"  {status} {name}")
    
    return checks


__all__ = [
    # ==========================================================================
    # Core API (most users need only these)
    # ==========================================================================
    "connect",
    "get_kernel",
    "set_kernel",
    "clear_kernel",
    "UnifiedDataManager",
    "BaseRepository",

    # ==========================================================================
    # Signals
    # ==========================================================================
    "Signal",
    "post_save",
    "post_delete",
    "post_ingest",
    "Handler",

    # ==========================================================================
    # Errors
    # ==========================================================================
    "OptimisticLockError",
    "ValidationError",
    "SystemOverloadedError",
    "ConsistencyTimeoutError",
    "RuntimeExecutionError",
    "CodeSynthesisError",

    # ==========================================================================
    # Models
    # ==========================================================================
    "SysOutbox",
    "SysProcess",
    "ProcessStatus",

    # ==========================================================================
    # Transaction Management (NEW in v0.9)
    # ==========================================================================
    "UnitOfWork",

    # ==========================================================================
    # Stream Driver (NEW in v0.9)
    # ==========================================================================
    "StreamDriver",
    "ParquetStreamDriver",

    # ==========================================================================
    # Compute Driver (NEW in v0.9)
    # ==========================================================================
    "ComputeDriver",
    "ComputeResult",
    "LocalComputeDriver",

    # ==========================================================================
    # Observability
    # ==========================================================================
    "KernelMonitor",
    "KernelInstrumentation",
    "MetricTimer",
    "KuzuTask",

    # ==========================================================================
    # Services (Helix pattern)
    # ==========================================================================
    "TopologySyncService",
    "generate_virtual_rid",

    # ==========================================================================
    # Advanced: Driver Protocols
    # ==========================================================================
    "SQLDriver",
    "GraphDriver",
    "AnalyticsDriver",
    "ReplicationDriver",

    # ==========================================================================
    # Advanced: Driver Implementations
    # ==========================================================================
    "AsyncSQLAlchemyDriver",
    "KuzuActor",
    "KuzuConfig",
    "KuzuDriver",  # Backwards compatibility alias
    "DuckDBDriver",

    # ==========================================================================
    # Advanced: Extensibility
    # ==========================================================================
    "Interceptor",

    # ==========================================================================
    # Advanced: Boot & Maintenance (Lifecycle)
    # ==========================================================================
    "Bootloader",
    "BootResult",
    "boot_kernel",
    "recoverable",
    "register_recovery_handler",
    "WORKFLOW_REGISTRY",
    "Janitor",
    "CleanupResult",
    "Migrator",
    "MigrationResult",
    "SchemaDrift",
    "SmartCompactor",
    "CompactionResult",
    "run_cleanup",
    "check_schema_drift",
    
    # ==========================================================================
    # Advanced: Alembic Migrations (NEW in v0.10.3)
    # ==========================================================================
    "AlembicDriver",
    "MigrationInfo",
    "init_migrations",
    "run_migrations",

    # ==========================================================================
    # Metadata & Utilities
    # ==========================================================================
    "__version__",
    "check_api",
]
