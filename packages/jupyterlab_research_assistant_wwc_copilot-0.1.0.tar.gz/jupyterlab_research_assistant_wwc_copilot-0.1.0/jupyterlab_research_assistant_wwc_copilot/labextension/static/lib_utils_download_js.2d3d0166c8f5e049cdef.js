"use strict";
(self["webpackChunkjupyterlab_research_assistant_wwc_copilot"] = self["webpackChunkjupyterlab_research_assistant_wwc_copilot"] || []).push([["lib_utils_download_js"],{

/***/ "./lib/utils/download.js":
/*!*******************************!*\
  !*** ./lib/utils/download.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   downloadBlob: () => (/* binding */ downloadBlob),
/* harmony export */   downloadCSV: () => (/* binding */ downloadCSV),
/* harmony export */   downloadFromURL: () => (/* binding */ downloadFromURL),
/* harmony export */   downloadJSON: () => (/* binding */ downloadJSON)
/* harmony export */ });
/**
 * Utility functions for downloading files from the browser.
 */
/**
 * Download a blob as a file.
 * @param blob - The blob to download
 * @param filename - The filename for the downloaded file
 */
function downloadBlob(blob, filename) {
    const downloadUrl = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(downloadUrl);
}
/**
 * Download data as a JSON file.
 * @param data - The data to download (will be JSON stringified)
 * @param filename - The filename for the downloaded file (without .json extension)
 */
function downloadJSON(data, filename) {
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    downloadBlob(blob, `${filename}.json`);
}
/**
 * Download data as a CSV file.
 * @param csvContent - The CSV content as a string
 * @param filename - The filename for the downloaded file (without .csv extension)
 */
function downloadCSV(csvContent, filename) {
    const blob = new Blob([csvContent], { type: 'text/csv' });
    downloadBlob(blob, `${filename}.csv`);
}
/**
 * Download a file from a URL.
 * @param url - The URL to download from
 * @param filename - The filename for the downloaded file
 */
async function downloadFromURL(url, filename) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to download file: ${response.statusText}`);
    }
    const blob = await response.blob();
    downloadBlob(blob, filename);
}


/***/ })

}]);
//# sourceMappingURL=lib_utils_download_js.2d3d0166c8f5e049cdef.js.map