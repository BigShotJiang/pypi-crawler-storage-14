"use strict";
(self["webpackChunkjupyterlab_research_assistant_wwc_copilot"] = self["webpackChunkjupyterlab_research_assistant_wwc_copilot"] || []).push([["lib_index_js"],{

/***/ "./lib/api.js":
/*!********************!*\
  !*** ./lib/api.js ***!
  \********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   assessPublicationBias: () => (/* binding */ assessPublicationBias),
/* harmony export */   deletePapers: () => (/* binding */ deletePapers),
/* harmony export */   detectConflicts: () => (/* binding */ detectConflicts),
/* harmony export */   detectConflictsWithFindings: () => (/* binding */ detectConflictsWithFindings),
/* harmony export */   exportLibrary: () => (/* binding */ exportLibrary),
/* harmony export */   getLibrary: () => (/* binding */ getLibrary),
/* harmony export */   importPDF: () => (/* binding */ importPDF),
/* harmony export */   importPaper: () => (/* binding */ importPaper),
/* harmony export */   performMetaAnalysis: () => (/* binding */ performMetaAnalysis),
/* harmony export */   performSensitivityAnalysis: () => (/* binding */ performSensitivityAnalysis),
/* harmony export */   performSubgroupAnalysis: () => (/* binding */ performSubgroupAnalysis),
/* harmony export */   runWWCAssessment: () => (/* binding */ runWWCAssessment),
/* harmony export */   searchLibrary: () => (/* binding */ searchLibrary),
/* harmony export */   searchSemanticScholar: () => (/* binding */ searchSemanticScholar)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./request */ "./lib/request.js");
/* harmony import */ var _utils_retry__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils/retry */ "./lib/utils/retry.js");
/* harmony import */ var _utils_api_response__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/api-response */ "./lib/utils/api-response.js");





// API functions
async function getLibrary() {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('library', {
        method: 'GET'
    });
    const data = (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Failed to fetch library');
    return data || [];
}
async function searchLibrary(query) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`search?q=${encodeURIComponent(query)}`, {
        method: 'GET'
    });
    const data = (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Search failed');
    return data || [];
}
async function searchSemanticScholar(query, limit = 20, offset = 0) {
    return (0,_utils_retry__WEBPACK_IMPORTED_MODULE_3__.retryWithBackoff)(async () => {
        const params = new URLSearchParams({ q: query });
        params.append('limit', limit.toString());
        params.append('offset', offset.toString());
        const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)(`discovery?${params.toString()}`, { method: 'GET' });
        return ((0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Semantic Scholar search failed') || {
            data: [],
            total: 0
        });
    });
}
async function importPaper(paper) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('library', {
        method: 'POST',
        body: JSON.stringify(paper)
    });
    const result = (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Import failed');
    return result;
}
async function deletePapers(paperIds) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('library', {
        method: 'DELETE',
        body: JSON.stringify({ paper_ids: paperIds })
    });
    return (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Delete failed') || { deleted_count: 0 };
}
async function importPDF(file, aiConfig) {
    const formData = new FormData();
    formData.append('file', file);
    if (aiConfig) {
        // Append as a file-like object so backend can read it from request.files
        const aiConfigBlob = new Blob([JSON.stringify(aiConfig)], {
            type: 'application/json'
        });
        formData.append('aiConfig', aiConfigBlob, 'aiConfig.json');
    }
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('import', {
        method: 'POST',
        body: formData
    });
    return (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'PDF import failed');
}
async function exportLibrary(format) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'jupyterlab-research-assistant-wwc-copilot', `export?format=${format}`);
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(url, { method: 'GET' }, settings);
    if (!response.ok) {
        throw new Error(`Export failed: ${response.statusText}`);
    }
    // Download file
    const blob = await response.blob();
    const { downloadBlob } = await __webpack_require__.e(/*! import() */ "lib_utils_download_js").then(__webpack_require__.bind(__webpack_require__, /*! ./utils/download */ "./lib/utils/download.js"));
    downloadBlob(blob, `library.${format === 'bibtex' ? 'bib' : format}`);
}
async function runWWCAssessment(request) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('wwc-assessment', {
        method: 'POST',
        body: JSON.stringify(request)
    });
    return (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'WWC assessment failed');
}
async function performMetaAnalysis(paperIds, outcomeName) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('meta-analysis', {
        method: 'POST',
        body: JSON.stringify({
            paper_ids: paperIds,
            outcome_name: outcomeName
        })
    });
    return (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Meta-analysis failed');
}
async function detectConflicts(paperIds, confidenceThreshold = 0.8) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('conflict-detection', {
        method: 'POST',
        body: JSON.stringify({
            paper_ids: paperIds,
            confidence_threshold: confidenceThreshold
        })
    });
    return (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Conflict detection failed');
}
async function performSubgroupAnalysis(paperIds, subgroupVariable, outcomeName) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('subgroup-analysis', {
        method: 'POST',
        body: JSON.stringify({
            paper_ids: paperIds,
            subgroup_variable: subgroupVariable,
            outcome_name: outcomeName
        })
    });
    if (response.status === 'error') {
        throw new Error(response.message || 'Subgroup analysis failed');
    }
    if (!response.data) {
        throw new Error('No subgroup analysis data returned');
    }
    return response.data;
}
async function assessPublicationBias(paperIds, outcomeName) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('bias-assessment', {
        method: 'POST',
        body: JSON.stringify({
            paper_ids: paperIds,
            outcome_name: outcomeName
        })
    });
    if (response.status === 'error') {
        throw new Error(response.message || 'Bias assessment failed');
    }
    if (!response.data) {
        throw new Error('No bias assessment data returned');
    }
    return response.data;
}
async function performSensitivityAnalysis(paperIds, outcomeName) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('sensitivity-analysis', {
        method: 'POST',
        body: JSON.stringify({
            paper_ids: paperIds,
            outcome_name: outcomeName
        })
    });
    if (response.status === 'error') {
        throw new Error(response.message || 'Sensitivity analysis failed');
    }
    if (!response.data) {
        throw new Error('No sensitivity analysis data returned');
    }
    return response.data;
}
async function detectConflictsWithFindings(paperIds, confidenceThreshold = 0.8) {
    const response = await (0,_request__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('conflict-detection', {
        method: 'POST',
        body: JSON.stringify({
            paper_ids: paperIds,
            confidence_threshold: confidenceThreshold,
            extract_findings: true
        })
    });
    return (0,_utils_api_response__WEBPACK_IMPORTED_MODULE_4__.handleAPIResponse)(response, 'Conflict detection failed');
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./request */ "./lib/request.js");
/* harmony import */ var _widgets_ResearchLibraryPanel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./widgets/ResearchLibraryPanel */ "./lib/widgets/ResearchLibraryPanel.js");
/* harmony import */ var _widgets_SynthesisWorkbench__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./widgets/SynthesisWorkbench */ "./lib/widgets/SynthesisWorkbench.js");
/* harmony import */ var _widgets_WWCCoPilot__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./widgets/WWCCoPilot */ "./lib/widgets/WWCCoPilot.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./api */ "./lib/api.js");
/* harmony import */ var _utils_notifications__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./utils/notifications */ "./lib/utils/notifications.js");
/* harmony import */ var _utils_events__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./utils/events */ "./lib/utils/events.js");













/**
 * Initialization data for the jupyterlab-research-assistant-wwc-copilot extension.
 */
const plugin = {
    id: 'jupyterlab-research-assistant-wwc-copilot:plugin',
    description: 'A JupyterLab extension for academic research management and WWC quality assessment',
    autoStart: true,
    optional: [
        _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_2__.ISettingRegistry,
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.ICommandPalette,
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__.ILayoutRestorer,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__.IFileBrowserFactory
    ],
    activate: (app, settingRegistry, palette, restorer, fileBrowserFactory) => {
        console.log('JupyterLab extension jupyterlab-research-assistant-wwc-copilot is activated!');
        // Store settings for use in commands
        let aiConfig = null;
        if (settingRegistry) {
            settingRegistry
                .load(plugin.id)
                .then(settings => {
                console.log('jupyterlab-research-assistant-wwc-copilot settings loaded:', settings.composite);
                // Extract AI extraction config
                const composite = settings.composite;
                if (composite &&
                    'aiExtraction' in composite &&
                    composite.aiExtraction) {
                    aiConfig = composite.aiExtraction;
                }
            })
                .catch(reason => {
                console.error('Failed to load settings for jupyterlab-research-assistant-wwc-copilot.', reason);
            });
        }
        // Create and track the research library panel
        const tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.WidgetTracker({
            namespace: 'research-library'
        });
        // Create and track synthesis workbench widgets
        const synthesisTracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.WidgetTracker({
            namespace: 'synthesis-workbench'
        });
        const createPanel = () => {
            const panel = new _widgets_ResearchLibraryPanel__WEBPACK_IMPORTED_MODULE_6__.ResearchLibraryPanel();
            tracker.add(panel);
            app.shell.add(panel, 'left', { rank: 300 });
            return panel;
        };
        // Restore panel if it was open before
        if (restorer) {
            restorer.restore(tracker, {
                command: 'jupyterlab-research-assistant-wwc-copilot:open-library',
                name: () => 'research-library'
            });
            restorer.restore(synthesisTracker, {
                command: 'jupyterlab-research-assistant-wwc-copilot:open-synthesis',
                name: () => 'synthesis-workbench'
            });
        }
        // Register command to open panel
        app.commands.addCommand('jupyterlab-research-assistant-wwc-copilot:open-library', {
            label: 'Open Research Library',
            execute: () => {
                const existing = tracker.currentWidget;
                if (existing) {
                    app.shell.activateById(existing.id);
                }
                else {
                    createPanel();
                }
            }
        });
        // Register import-pdf command
        app.commands.addCommand('jupyterlab-research-assistant-wwc-copilot:import-pdf', {
            label: 'Import PDF to Research Library',
            execute: async () => {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.pdf,application/pdf';
                input.onchange = async (e) => {
                    var _a;
                    const file = (_a = e.target.files) === null || _a === void 0 ? void 0 : _a[0];
                    if (file) {
                        try {
                            await (0,_api__WEBPACK_IMPORTED_MODULE_9__.importPDF)(file, aiConfig || undefined);
                            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showSuccess)('PDF Imported', `Successfully imported: ${file.name}`);
                            // Refresh library if panel is open
                            const panel = tracker.currentWidget;
                            if (panel) {
                                // Trigger refresh - would need to expose a method on the panel
                            }
                        }
                        catch (err) {
                            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showError)('Import Failed', err instanceof Error ? err.message : 'Unknown error');
                        }
                    }
                };
                input.click();
            }
        });
        // Register export-library command
        app.commands.addCommand('jupyterlab-research-assistant-wwc-copilot:export-library', {
            label: 'Export Research Library',
            execute: async () => {
                // Show a dialog to select format
                const format = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.showDialog)({
                    title: 'Export Library',
                    body: 'Select export format:',
                    buttons: [
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.Dialog.cancelButton(),
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.Dialog.okButton({ label: 'JSON' }),
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.Dialog.okButton({ label: 'CSV' }),
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.Dialog.okButton({ label: 'BibTeX' })
                    ]
                });
                if (format.button.accept && format.button.label) {
                    const formatMap = {
                        JSON: 'json',
                        CSV: 'csv',
                        BibTeX: 'bibtex'
                    };
                    const exportFormat = formatMap[format.button.label] || 'json';
                    try {
                        await (0,_api__WEBPACK_IMPORTED_MODULE_9__.exportLibrary)(exportFormat);
                        (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showSuccess)('Export Complete', `Library exported as ${exportFormat.toUpperCase()}`);
                    }
                    catch (err) {
                        (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showError)('Export Failed', err instanceof Error ? err.message : 'Unknown error');
                    }
                }
            }
        });
        // Register synthesis workbench command
        app.commands.addCommand('jupyterlab-research-assistant-wwc-copilot:open-synthesis', {
            label: 'Open Synthesis Workbench',
            execute: (args) => {
                const paperIds = (args === null || args === void 0 ? void 0 : args.paperIds) || [];
                // Silently return if called without paperIds (e.g., from command palette or restorer)
                // Only show error if explicitly called with invalid paperIds (length 1)
                if (paperIds.length === 0) {
                    // Called without arguments - likely from palette or restorer, don't show error
                    return;
                }
                if (paperIds.length < 2) {
                    (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showError)('Synthesis Workbench', 'Please select at least 2 papers');
                    return;
                }
                const workbench = new _widgets_SynthesisWorkbench__WEBPACK_IMPORTED_MODULE_7__.SynthesisWorkbench(paperIds);
                synthesisTracker.add(workbench);
                app.shell.add(workbench, 'main');
                app.shell.activateById(workbench.id);
            }
        });
        // Register WWC Co-Pilot command
        app.commands.addCommand('jupyterlab-research-assistant-wwc-copilot:open-wwc', {
            label: 'Open WWC Co-Pilot',
            execute: (args) => {
                const paperId = args.paperId;
                const paperTitle = args.paperTitle || 'Paper';
                if (!paperId) {
                    (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showError)('WWC Co-Pilot', 'Paper ID is required');
                    return;
                }
                // Create a widget for WWC assessment
                const wwcWidget = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_3__.ReactWidget.create(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_widgets_WWCCoPilot__WEBPACK_IMPORTED_MODULE_8__.WWCCoPilot, { paperId: paperId, paperTitle: paperTitle, onClose: () => {
                        // Close the widget
                        const widget = app.shell.currentWidget;
                        if (widget && widget.id === 'wwc-copilot') {
                            widget.close();
                        }
                    } }));
                wwcWidget.id = 'wwc-copilot';
                wwcWidget.title.label = `WWC Co-Pilot: ${paperTitle}`;
                wwcWidget.title.caption = 'WWC Quality Assessment';
                wwcWidget.title.closable = true;
                app.shell.add(wwcWidget, 'main');
                app.shell.activateById(wwcWidget.id);
            }
        });
        // Listen for custom event from LibraryTab to open synthesis workbench
        _utils_events__WEBPACK_IMPORTED_MODULE_11__.AppEvents.onOpenSynthesisWorkbench(detail => {
            if (detail.paperIds && detail.paperIds.length >= 2) {
                app.commands.execute('jupyterlab-research-assistant-wwc-copilot:open-synthesis', { paperIds: detail.paperIds });
            }
        });
        // Listen for custom event from DetailView to open WWC Co-Pilot
        _utils_events__WEBPACK_IMPORTED_MODULE_11__.AppEvents.onOpenWWCCopilot(detail => {
            if (detail.paperId) {
                app.commands.execute('jupyterlab-research-assistant-wwc-copilot:open-wwc', {
                    paperId: detail.paperId,
                    paperTitle: detail.paperTitle || 'Paper'
                });
            }
        });
        // Add to command palette
        if (palette) {
            palette.addItem({
                command: 'jupyterlab-research-assistant-wwc-copilot:open-library',
                category: 'Research Assistant'
            });
            palette.addItem({
                command: 'jupyterlab-research-assistant-wwc-copilot:import-pdf',
                category: 'Research Assistant'
            });
            palette.addItem({
                command: 'jupyterlab-research-assistant-wwc-copilot:export-library',
                category: 'Research Assistant'
            });
            palette.addItem({
                command: 'jupyterlab-research-assistant-wwc-copilot:open-synthesis',
                category: 'Research Assistant'
            });
            palette.addItem({
                command: 'jupyterlab-research-assistant-wwc-copilot:open-wwc',
                category: 'Research Assistant'
            });
        }
        // Note: Main menu integration removed - JupyterLab 4 doesn't expose IMainMenu
        // Commands are available via command palette and keyboard shortcuts
        // Add file browser context menu
        if (fileBrowserFactory) {
            app.commands.addCommand('jupyterlab-research-assistant-wwc-copilot:import-pdf-from-browser', {
                label: 'Import to Research Library',
                execute: async (args) => {
                    const path = args.path;
                    if (!path || !path.endsWith('.pdf')) {
                        return;
                    }
                    try {
                        // Read file from filesystem using file browser
                        const fileBrowser = fileBrowserFactory.tracker.currentWidget;
                        if (!fileBrowser) {
                            throw new Error('File browser not available');
                        }
                        const contents = fileBrowser.model.manager.services.contents;
                        const fileData = await contents.get(path, {
                            type: 'file',
                            format: 'base64'
                        });
                        // Convert base64 to File object
                        const binaryString = atob(fileData.content);
                        const bytes = new Uint8Array(binaryString.length);
                        for (let i = 0; i < binaryString.length; i++) {
                            bytes[i] = binaryString.charCodeAt(i);
                        }
                        const blob = new Blob([bytes], { type: 'application/pdf' });
                        const pdfFile = new File([blob], fileData.name, {
                            type: 'application/pdf'
                        });
                        await (0,_api__WEBPACK_IMPORTED_MODULE_9__.importPDF)(pdfFile, aiConfig || undefined);
                        (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showSuccess)('PDF Imported', `Successfully imported: ${fileData.name}`);
                    }
                    catch (err) {
                        (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_10__.showError)('Import Failed', err instanceof Error ? err.message : 'Unknown error');
                    }
                },
                isEnabled: (args) => {
                    const path = args.path;
                    return path ? path.endsWith('.pdf') : false;
                }
            });
            // Add to file browser context menu for PDF files
            // The selector targets PDF files in the directory listing
            app.contextMenu.addItem({
                command: 'jupyterlab-research-assistant-wwc-copilot:import-pdf-from-browser',
                selector: '.jp-DirListing-item[data-file-type="pdf"]',
                rank: 10
            });
        }
        (0,_request__WEBPACK_IMPORTED_MODULE_5__.requestAPI)('hello')
            .then(data => {
            console.log(data);
        })
            .catch(reason => {
            console.error(`The jupyterlab_research_assistant_wwc_copilot server extension appears to be missing.\n${reason}`);
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/request.js":
/*!************************!*\
  !*** ./lib/request.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the server extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'jupyterlab-research-assistant-wwc-copilot', // our server extension's API namespace
    endPoint);
    // Handle FormData - don't set Content-Type, browser will set it with boundary
    const headers = {};
    if (init.body instanceof FormData) {
        // Don't set Content-Type for FormData
    }
    else if (init.body) {
        headers['Content-Type'] = 'application/json';
    }
    const requestInit = {
        ...init,
        headers: {
            ...headers,
            ...(init.headers || {})
        }
    };
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, requestInit, settings);
    }
    catch (error) {
        // NetworkError constructor accepts unknown error type
        const networkError = error instanceof TypeError ? error : new TypeError(String(error));
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(networkError);
    }
    const dataText = await response.text();
    let data = dataText;
    if (dataText.length > 0) {
        try {
            data = JSON.parse(dataText);
        }
        catch (error) {
            console.error('Not a JSON response body.', response, error);
        }
    }
    if (!response.ok) {
        const errorMessage = (data && typeof data === 'object' && 'message' in data
            ? String(data.message)
            : String(data)) || 'Request failed';
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, errorMessage);
    }
    return data;
}


/***/ }),

/***/ "./lib/utils/api-response.js":
/*!***********************************!*\
  !*** ./lib/utils/api-response.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   handleAPIResponse: () => (/* binding */ handleAPIResponse)
/* harmony export */ });
/**
 * Handle API response and extract data or throw error.
 * @param response - API response object
 * @param errorMessage - Default error message if response is error
 * @returns Extracted data from response
 * @throws Error if response status is error or data is missing
 */
function handleAPIResponse(response, errorMessage) {
    if (response.status === 'error') {
        throw new Error(response.message || errorMessage);
    }
    if (!response.data) {
        throw new Error(errorMessage);
    }
    return response.data;
}


/***/ }),

/***/ "./lib/utils/events.js":
/*!*****************************!*\
  !*** ./lib/utils/events.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AppEvents: () => (/* binding */ AppEvents)
/* harmony export */ });
/**
 * Custom event utilities for inter-component communication.
 * Provides type-safe event dispatching and listening.
 */
var AppEvents;
(function (AppEvents) {
    AppEvents.OPEN_SYNTHESIS_WORKBENCH = 'open-synthesis-workbench';
    AppEvents.OPEN_WWC_COPILOT = 'open-wwc-copilot';
    /**
     * Dispatch event to open synthesis workbench.
     */
    function dispatchOpenSynthesisWorkbench(paperIds) {
        window.dispatchEvent(new CustomEvent(AppEvents.OPEN_SYNTHESIS_WORKBENCH, {
            detail: { paperIds }
        }));
    }
    AppEvents.dispatchOpenSynthesisWorkbench = dispatchOpenSynthesisWorkbench;
    /**
     * Dispatch event to open WWC Co-Pilot.
     */
    function dispatchOpenWWCCopilot(paperId, paperTitle) {
        window.dispatchEvent(new CustomEvent(AppEvents.OPEN_WWC_COPILOT, {
            detail: { paperId, paperTitle }
        }));
    }
    AppEvents.dispatchOpenWWCCopilot = dispatchOpenWWCCopilot;
    /**
     * Listen for open synthesis workbench events.
     * @returns Cleanup function to remove listener
     */
    function onOpenSynthesisWorkbench(handler) {
        const listener = ((event) => {
            handler(event.detail);
        });
        window.addEventListener(AppEvents.OPEN_SYNTHESIS_WORKBENCH, listener);
        return () => window.removeEventListener(AppEvents.OPEN_SYNTHESIS_WORKBENCH, listener);
    }
    AppEvents.onOpenSynthesisWorkbench = onOpenSynthesisWorkbench;
    /**
     * Listen for open WWC Co-Pilot events.
     * @returns Cleanup function to remove listener
     */
    function onOpenWWCCopilot(handler) {
        const listener = ((event) => {
            handler(event.detail);
        });
        window.addEventListener(AppEvents.OPEN_WWC_COPILOT, listener);
        return () => window.removeEventListener(AppEvents.OPEN_WWC_COPILOT, listener);
    }
    AppEvents.onOpenWWCCopilot = onOpenWWCCopilot;
})(AppEvents || (AppEvents = {}));


/***/ }),

/***/ "./lib/utils/format.js":
/*!*****************************!*\
  !*** ./lib/utils/format.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   formatCI: () => (/* binding */ formatCI),
/* harmony export */   formatNumber: () => (/* binding */ formatNumber),
/* harmony export */   formatPercent: () => (/* binding */ formatPercent)
/* harmony export */ });
/**
 * Utility functions for formatting numbers and values.
 */
/**
 * Format a decimal value as a percentage.
 * @param value - Decimal value (e.g., 0.85 for 85%)
 * @param decimals - Number of decimal places (default: 1)
 * @returns Formatted percentage string (e.g., "85.0%")
 */
function formatPercent(value, decimals = 1) {
    return `${(value * 100).toFixed(decimals)}%`;
}
/**
 * Format a number with a fixed number of decimal places.
 * @param value - Number to format
 * @param decimals - Number of decimal places (default: 2)
 * @returns Formatted number string
 */
function formatNumber(value, decimals = 2) {
    return value.toFixed(decimals);
}
/**
 * Format a confidence interval as a string.
 * @param lower - Lower bound
 * @param upper - Upper bound
 * @param decimals - Number of decimal places (default: 3)
 * @returns Formatted CI string (e.g., "[0.123, 0.456]")
 */
function formatCI(lower, upper, decimals = 3) {
    return `[${formatNumber(lower, decimals)}, ${formatNumber(upper, decimals)}]`;
}


/***/ }),

/***/ "./lib/utils/hooks.js":
/*!****************************!*\
  !*** ./lib/utils/hooks.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useAsyncOperation: () => (/* binding */ useAsyncOperation)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Custom React hooks for common patterns.
 */

/**
 * Hook for managing async operations with loading and error states.
 *
 * @param operation - Async function to execute
 * @returns Tuple of [isLoading, execute, error]
 *   - isLoading: Boolean indicating if operation is in progress
 *   - execute: Function to execute the operation
 *   - error: Error object if operation failed, null otherwise
 *
 * @example
 * ```typescript
 * const [isLoading, runMetaAnalysis, error] = useAsyncOperation(performMetaAnalysis);
 *
 * const handleRun = async () => {
 *   const result = await runMetaAnalysis(paperIds);
 *   if (result) {
 *     setResult(result);
 *   } else if (error) {
 *     showError('Error', error.message);
 *   }
 * };
 * ```
 */
function useAsyncOperation(operation) {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const execute = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (...args) => {
        setIsLoading(true);
        setError(null);
        try {
            const result = await operation(...args);
            return result;
        }
        catch (err) {
            const error = err instanceof Error ? err : new Error('Unknown error');
            setError(error);
            return undefined;
        }
        finally {
            setIsLoading(false);
        }
    }, [operation]);
    return [isLoading, execute, error];
}


/***/ }),

/***/ "./lib/utils/notifications.js":
/*!************************************!*\
  !*** ./lib/utils/notifications.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   showError: () => (/* binding */ showError),
/* harmony export */   showSuccess: () => (/* binding */ showSuccess),
/* harmony export */   showWarning: () => (/* binding */ showWarning)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Show an error notification to the user.
 * @param title - Error title
 * @param message - Error message
 * @param error - Optional error object for logging
 */
function showError(title, message, error) {
    console.error(`${title}: ${message}`, error);
    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
        title,
        body: message,
        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton()]
    });
}
/**
 * Show a success notification to the user.
 * @param title - Success title
 * @param message - Success message
 */
function showSuccess(title, message) {
    console.log(`${title}: ${message}`);
    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
        title,
        body: message,
        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton()]
    });
}
/**
 * Show a warning notification to the user.
 * @param title - Warning title
 * @param message - Warning message
 */
function showWarning(title, message) {
    console.warn(`${title}: ${message}`);
    (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)({
        title,
        body: message,
        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton()]
    });
}


/***/ }),

/***/ "./lib/utils/paper.js":
/*!****************************!*\
  !*** ./lib/utils/paper.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getPaperKey: () => (/* binding */ getPaperKey),
/* harmony export */   hasFullPDF: () => (/* binding */ hasFullPDF)
/* harmony export */ });
/**
 * Get a unique key for a paper, used for React keys.
 * @param paper - Paper object
 * @returns Unique key string
 */
function getPaperKey(paper) {
    var _a;
    return paper.paperId || ((_a = paper.id) === null || _a === void 0 ? void 0 : _a.toString()) || `paper-${Math.random()}`;
}
/**
 * Check if a paper has a full PDF (not just metadata).
 * @param paper - Paper object
 * @returns True if paper has pdf_path or full_text
 */
function hasFullPDF(paper) {
    return !!(paper.pdf_path || paper.full_text);
}


/***/ }),

/***/ "./lib/utils/retry.js":
/*!****************************!*\
  !*** ./lib/utils/retry.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   retryWithBackoff: () => (/* binding */ retryWithBackoff)
/* harmony export */ });
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Retry a function with exponential backoff.
 * @param fn - Function to retry
 * @param maxRetries - Maximum number of retries
 * @param initialDelay - Initial delay in milliseconds
 * @returns Promise that resolves with function result
 */
async function retryWithBackoff(fn, maxRetries = 3, initialDelay = 1000) {
    let lastError;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            return await fn();
        }
        catch (error) {
            lastError = error instanceof Error ? error : new Error(String(error));
            // Don't retry on 4xx errors (client errors)
            if (error instanceof _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.ResponseError) {
                const status = error.response.status;
                if (status >= 400 && status < 500) {
                    throw error;
                }
            }
            if (attempt < maxRetries) {
                const delay = initialDelay * Math.pow(2, attempt);
                await new Promise(resolve => setTimeout(resolve, delay));
            }
        }
    }
    throw lastError || new Error('Retry failed');
}


/***/ }),

/***/ "./lib/widgets/BiasAssessmentView.js":
/*!*******************************************!*\
  !*** ./lib/widgets/BiasAssessmentView.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BiasAssessmentView: () => (/* binding */ BiasAssessmentView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const BiasAssessmentView = ({ result }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-bias-assessment" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Publication Bias Assessment"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-eggers-test" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Egger's Test"),
            result.eggers_test.intercept_pvalue !== null ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Intercept:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, result.eggers_test.intercept !== null
                        ? result.eggers_test.intercept.toFixed(4)
                        : 'N/A')),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Standard Error:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, result.eggers_test.intercept_se !== null
                        ? result.eggers_test.intercept_se.toFixed(4)
                        : 'N/A')),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "P-value:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, result.eggers_test.intercept_pvalue.toFixed(4))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-eggers-interpretation" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Interpretation:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, result.eggers_test.interpretation)))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, result.eggers_test.interpretation))),
        result.funnel_plot && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-funnel-plot" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Funnel Plot"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-plot" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: `data:image/png;base64,${result.funnel_plot}`, alt: "Funnel Plot", className: "jp-WWCExtension-plot-image" }))))));
};


/***/ }),

/***/ "./lib/widgets/ConflictView.js":
/*!*************************************!*\
  !*** ./lib/widgets/ConflictView.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConflictView: () => (/* binding */ ConflictView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_format__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/format */ "./lib/utils/format.js");


const ConflictView = ({ result }) => {
    const hasFindings = 'findings' in result &&
        result.findings &&
        Object.keys(result.findings).length > 0;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflicts" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Conflict Detection Results"),
        result.status === 'disabled' && result.message && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-error", style: {
                marginBottom: '16px',
                backgroundColor: 'var(--jp-layout-color2)',
                color: 'var(--jp-content-font-color2)',
                border: '1px solid var(--jp-border-color2)',
                padding: '12px'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Conflict Detection Unavailable"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, result.message))),
        result.message && result.status === 'success' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-loading", style: {
                marginBottom: '16px',
                padding: '12px',
                backgroundColor: 'var(--jp-layout-color2)',
                borderRadius: 'var(--jp-border-radius)'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, result.message))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflicts-summary" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                "Found ",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, result.n_contradictions),
                " contradictions across",
                ' ',
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, result.n_papers),
                " papers.")),
        hasFindings && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-findings-preview" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Extracted Key Findings"),
            Object.entries(result.findings).map(([paperId, paperFindings]) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: paperId, className: "jp-WWCExtension-finding-item" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null,
                    "Paper ",
                    paperId,
                    ":"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", null, paperFindings.map((finding, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { key: idx }, finding))))))))),
        result.contradictions.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflicts-empty" }, "No contradictions detected.")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflicts-list" }, result.contradictions.map((conflict, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: idx, className: "jp-WWCExtension-conflict-item" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflict-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null,
                    "Contradiction #",
                    idx + 1),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    "Confidence: ",
                    (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatPercent)(conflict.confidence, 1))),
            conflict.paper1_title && conflict.paper2_title && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflict-papers" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Paper 1:"),
                    " ",
                    conflict.paper1_title),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Paper 2:"),
                    " ",
                    conflict.paper2_title))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflict-findings" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Finding 1:"),
                    " ",
                    conflict.finding1),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Finding 2:"),
                    " ",
                    conflict.finding2)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-conflict-explanation" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Why this was flagged:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                    "The NLI model detected a contradiction with",
                    ' ',
                    (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatPercent)(conflict.confidence, 1),
                    " confidence. This means the model determined that these two findings cannot both be true simultaneously."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Note:"),
                    " Not all flagged contradictions represent genuine conflicts. The model may flag findings that:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null, "Address different topics or interventions (e.g., peer tutoring vs. multimedia instruction)"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null, "Use different methodologies or study different populations"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null, "Make claims that are logically incompatible (true contradictions)")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Review carefully:"),
                    " Consider whether these findings actually contradict each other, or if they simply describe different studies with different interventions or contexts.")))))))));
};


/***/ }),

/***/ "./lib/widgets/DetailView.js":
/*!***********************************!*\
  !*** ./lib/widgets/DetailView.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DetailView: () => (/* binding */ DetailView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_events__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/events */ "./lib/utils/events.js");
/* harmony import */ var _Tabs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Tabs */ "./lib/widgets/Tabs.js");
/* harmony import */ var _utils_format__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/format */ "./lib/utils/format.js");






const DetailView = ({ paper, onClose }) => {
    const [activeTab, setActiveTab] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('overview');
    const openPDF = () => {
        if (paper.id !== undefined) {
            // Open PDF via our backend route
            const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
            const url = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.URLExt.join(settings.baseUrl, 'jupyterlab-research-assistant-wwc-copilot', 'pdf', `?paper_id=${paper.id}`);
            window.open(url, '_blank');
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-view" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                    display: 'flex',
                    gap: '10px',
                    alignItems: 'center',
                    marginBottom: '8px'
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onClose, className: "jp-WWCExtension-button" }, "\u2190 Go Back"),
                paper.id !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: () => {
                        _utils_events__WEBPACK_IMPORTED_MODULE_3__.AppEvents.dispatchOpenWWCCopilot(paper.id, paper.title);
                    }, className: "jp-WWCExtension-button" }, "Open WWC Co-Pilot"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, paper.title),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-meta" },
                paper.authors && paper.authors.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    "Authors:",
                    ' ',
                    paper.authors
                        .map(author => {
                        if (typeof author === 'string') {
                            return author;
                        }
                        // Handle case where author might be an object (for backwards compatibility)
                        return (author === null || author === void 0 ? void 0 : author.name) || 'Unknown';
                    })
                        .join(', '))),
                paper.year && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    "Year: ",
                    paper.year),
                paper.doi && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    "DOI: ",
                    paper.doi),
                paper.citation_count !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    "Citations: ",
                    paper.citation_count)))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Tabs__WEBPACK_IMPORTED_MODULE_4__.Tabs, { tabs: [
                { id: 'overview', label: 'Overview' },
                ...(paper.study_metadata
                    ? [{ id: 'study', label: 'Study Metadata' }]
                    : []),
                ...(paper.learning_science_metadata
                    ? [{ id: 'learning', label: 'Learning Science' }]
                    : [])
            ], activeTab: activeTab, onTabChange: (tabId) => setActiveTab(tabId), className: "jp-WWCExtension-detail-tabs", activeClassName: "active", inactiveClassName: "" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-content" },
            activeTab === 'overview' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, paper.abstract ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Abstract"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, paper.abstract))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { style: {
                        color: 'var(--jp-content-font-color2)',
                        fontStyle: 'italic'
                    } }, "No abstract available for this paper."))))),
            activeTab === 'study' && paper.study_metadata && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Methodology"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, paper.study_metadata.methodology || 'Not specified')),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Sample Sizes"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                        "Baseline: ",
                        paper.study_metadata.sample_size_baseline || 'N/A'),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                        "Endline: ",
                        paper.study_metadata.sample_size_endline || 'N/A')),
                paper.study_metadata.effect_sizes && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Effect Sizes"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Outcome"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Cohen's d"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Standard Error"))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", null, Object.entries(paper.study_metadata.effect_sizes).map(([outcome, es]) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { key: outcome },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, outcome),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_5__.formatNumber)(es.d, 2)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_5__.formatNumber)(es.se, 2))))))))))),
            activeTab === 'learning' && paper.learning_science_metadata && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Learning Domain"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, paper.learning_science_metadata.learning_domain ||
                        'Not specified')),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Intervention Type"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, paper.learning_science_metadata.intervention_type ||
                        'Not specified'))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-detail-actions" }, paper.pdf_path && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: openPDF, className: "jp-WWCExtension-button" }, "Open PDF")))));
};


/***/ }),

/***/ "./lib/widgets/DiscoveryTab.js":
/*!*************************************!*\
  !*** ./lib/widgets/DiscoveryTab.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DiscoveryTab: () => (/* binding */ DiscoveryTab)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./lib/api.js");
/* harmony import */ var _PaperCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PaperCard */ "./lib/widgets/PaperCard.js");
/* harmony import */ var _utils_notifications__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/notifications */ "./lib/utils/notifications.js");
/* harmony import */ var _SearchBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SearchBar */ "./lib/widgets/SearchBar.js");
/* harmony import */ var _ErrorDisplay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ErrorDisplay */ "./lib/widgets/ErrorDisplay.js");
/* harmony import */ var _LoadingState__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./LoadingState */ "./lib/widgets/LoadingState.js");
/* harmony import */ var _utils_paper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/paper */ "./lib/utils/paper.js");








const DiscoveryTab = () => {
    const [query, setQuery] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [results, setResults] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const handleSearch = async () => {
        if (!query.trim()) {
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            const response = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.searchSemanticScholar)(query, 20);
            setResults(response.data);
        }
        catch (err) {
            setError(err instanceof Error ? err.message : 'Search failed');
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleImport = async (paper) => {
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.importPaper)(paper);
            if (result.is_duplicate) {
                (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('Paper Already in Library', `"${paper.title}" is already in your library.`);
            }
            else {
                (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('Paper Imported', `Successfully imported: ${paper.title}`);
            }
        }
        catch (err) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showError)('Import Failed', err instanceof Error ? err.message : 'Unknown error occurred', err instanceof Error ? err : undefined);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-discovery" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SearchBar__WEBPACK_IMPORTED_MODULE_4__.SearchBar, { query: query, onQueryChange: setQuery, onSearch: handleSearch, isLoading: isLoading, placeholder: "Search Semantic Scholar / OpenAlex..." }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ErrorDisplay__WEBPACK_IMPORTED_MODULE_5__.ErrorDisplay, { error: error }),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_LoadingState__WEBPACK_IMPORTED_MODULE_6__.LoadingState, null),
        !isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-results" }, results.map(paper => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_PaperCard__WEBPACK_IMPORTED_MODULE_2__.PaperCard, { key: (0,_utils_paper__WEBPACK_IMPORTED_MODULE_7__.getPaperKey)(paper), paper: paper, onImport: () => handleImport(paper) })))))));
};


/***/ }),

/***/ "./lib/widgets/ErrorDisplay.js":
/*!*************************************!*\
  !*** ./lib/widgets/ErrorDisplay.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ErrorDisplay: () => (/* binding */ ErrorDisplay)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const ErrorDisplay = ({ error }) => {
    if (!error) {
        return null;
    }
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-error" },
        "Error: ",
        error);
};


/***/ }),

/***/ "./lib/widgets/LibraryTab.js":
/*!***********************************!*\
  !*** ./lib/widgets/LibraryTab.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LibraryTab: () => (/* binding */ LibraryTab)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./lib/api.js");
/* harmony import */ var _PaperCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PaperCard */ "./lib/widgets/PaperCard.js");
/* harmony import */ var _utils_notifications__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/notifications */ "./lib/utils/notifications.js");
/* harmony import */ var _SearchBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SearchBar */ "./lib/widgets/SearchBar.js");
/* harmony import */ var _ErrorDisplay__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ErrorDisplay */ "./lib/widgets/ErrorDisplay.js");
/* harmony import */ var _LoadingState__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./LoadingState */ "./lib/widgets/LoadingState.js");
/* harmony import */ var _DetailView__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./DetailView */ "./lib/widgets/DetailView.js");
/* harmony import */ var _utils_paper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/paper */ "./lib/utils/paper.js");
/* harmony import */ var _utils_events__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../utils/events */ "./lib/utils/events.js");










const LibraryTab = () => {
    const [papers, setPapers] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isUploading, setIsUploading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [selectedPaper, setSelectedPaper] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [selectedPapers, setSelectedPapers] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(new Set());
    const fileInputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        loadLibrary();
    }, []);
    const loadLibrary = async () => {
        setIsLoading(true);
        setError(null);
        try {
            const data = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.getLibrary)();
            setPapers(data);
        }
        catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to load library');
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleFileSelect = async (event) => {
        var _a;
        const file = (_a = event.target.files) === null || _a === void 0 ? void 0 : _a[0];
        if (!file) {
            return;
        }
        // Validate file type
        if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
            setError('Please select a PDF file');
            return;
        }
        // Validate file size (max 50MB)
        if (file.size > 50 * 1024 * 1024) {
            setError('File size must be less than 50MB');
            return;
        }
        setIsUploading(true);
        setError(null);
        try {
            // Get AI config from settings if available
            // For now, pass undefined - settings will be read on backend
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.importPDF)(file);
            // Refresh library to show new paper
            await loadLibrary();
            if (result.is_duplicate) {
                if (result.already_has_pdf) {
                    (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('PDF Already in Library', `"${result.paper.title}" already exists in your library with a full PDF.`);
                }
                else {
                    (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('PDF Updated Existing Paper', `"${result.paper.title}" was already in your library (metadata-only). The PDF has been added and the entry updated.`);
                }
            }
            else {
                (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('PDF Uploaded', `Successfully imported: ${result.paper.title}`);
            }
            // Reset file input
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
        }
        catch (err) {
            const errorMessage = err instanceof Error ? err.message : 'PDF upload failed';
            setError(errorMessage);
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showError)('PDF Upload Failed', errorMessage, err instanceof Error ? err : undefined);
        }
        finally {
            setIsUploading(false);
        }
    };
    const handleSearch = async () => {
        if (!searchQuery.trim()) {
            loadLibrary();
            return;
        }
        setIsLoading(true);
        setError(null);
        try {
            const results = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.searchLibrary)(searchQuery);
            setPapers(results);
        }
        catch (err) {
            setError(err instanceof Error ? err.message : 'Search failed');
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleToggleSelection = (paperId) => {
        const newSelection = new Set(selectedPapers);
        if (newSelection.has(paperId)) {
            newSelection.delete(paperId);
        }
        else {
            newSelection.add(paperId);
        }
        setSelectedPapers(newSelection);
    };
    const handleOpenSynthesis = () => {
        const paperIds = Array.from(selectedPapers);
        if (paperIds.length < 2) {
            return;
        }
        // Check if all selected papers have full PDFs
        const selectedPaperObjects = papers.filter(p => p.id !== undefined && paperIds.includes(p.id));
        const metadataOnlyPapers = selectedPaperObjects.filter(p => !(0,_utils_paper__WEBPACK_IMPORTED_MODULE_8__.hasFullPDF)(p));
        if (metadataOnlyPapers.length > 0) {
            const titles = metadataOnlyPapers
                .map(p => p.title)
                .slice(0, 3)
                .join(', ');
            const moreText = metadataOnlyPapers.length > 3
                ? ` and ${metadataOnlyPapers.length - 3} more`
                : '';
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showError)('Cannot Synthesize Metadata-Only Papers', `The following papers are metadata-only (no PDF): ${titles}${moreText}. ` +
                'Please upload PDFs for these papers or only select papers with full PDFs. ' +
                'Papers with full PDFs are marked with "📄 Full PDF" badge.');
            return;
        }
        _utils_events__WEBPACK_IMPORTED_MODULE_9__.AppEvents.dispatchOpenSynthesisWorkbench(paperIds);
    };
    const handleSelectAll = () => {
        if (selectedPapers.size === papers.length) {
            // Deselect all
            setSelectedPapers(new Set());
        }
        else {
            // Select all
            setSelectedPapers(new Set(papers.filter(p => p.id !== undefined).map(p => p.id)));
        }
    };
    const handleDelete = async () => {
        if (selectedPapers.size === 0) {
            return;
        }
        const paperIds = Array.from(selectedPapers);
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.deletePapers)(paperIds);
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('Papers Deleted', `Successfully deleted ${result.deleted_count} paper(s)`);
            // Refresh library to remove deleted papers
            await loadLibrary();
            // Clear selections
            setSelectedPapers(new Set());
        }
        catch (err) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showError)('Delete Failed', err instanceof Error ? err.message : 'Unknown error occurred', err instanceof Error ? err : undefined);
        }
    };
    if (selectedPaper) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_DetailView__WEBPACK_IMPORTED_MODULE_7__.DetailView, { paper: selectedPaper, onClose: () => setSelectedPaper(null) }));
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-library" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginBottom: '0' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SearchBar__WEBPACK_IMPORTED_MODULE_4__.SearchBar, { query: searchQuery, onQueryChange: setSearchQuery, onSearch: handleSearch, isLoading: isLoading, placeholder: "Search your library...", additionalInputs: react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { onChange: async (e) => {
                        const format = e.target.value;
                        if (format) {
                            try {
                                await (0,_api__WEBPACK_IMPORTED_MODULE_1__.exportLibrary)(format);
                                (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showSuccess)('Export Complete', `Library exported as ${format.toUpperCase()}`);
                            }
                            catch (err) {
                                (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_3__.showError)('Export Failed', err instanceof Error ? err.message : 'Unknown error');
                            }
                            e.target.value = ''; // Reset
                        }
                    }, className: "jp-WWCExtension-select" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "Export..."),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "json" }, "Export as JSON"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "csv" }, "Export as CSV"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "bibtex" }, "Export as BibTeX")) })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                display: 'flex',
                gap: '10px',
                alignItems: 'center',
                marginBottom: '10px',
                marginLeft: '8px'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { ref: fileInputRef, type: "file", accept: ".pdf,application/pdf", onChange: handleFileSelect, className: "jp-WWCExtension-file-input", id: "pdf-upload-input", style: { display: 'none' } }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { htmlFor: "pdf-upload-input", className: "jp-WWCExtension-button jp-WWCExtension-synthesis-button", style: { cursor: 'pointer' } }, isUploading ? 'Uploading...' : 'Upload PDF'),
            (() => {
                // Get all selected papers
                const selectedPaperObjects = papers.filter(p => p.id !== undefined && selectedPapers.has(p.id));
                // Count selected papers with full PDFs
                const selectedWithPDFs = selectedPaperObjects.filter(p => (0,_utils_paper__WEBPACK_IMPORTED_MODULE_8__.hasFullPDF)(p));
                // Check if any metadata-only papers are selected
                const selectedMetadataOnly = selectedPaperObjects.filter(p => !(0,_utils_paper__WEBPACK_IMPORTED_MODULE_8__.hasFullPDF)(p));
                // Show button only if: 2+ full-PDF papers selected AND no metadata-only papers selected
                return selectedWithPDFs.length >= 2 &&
                    selectedMetadataOnly.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleOpenSynthesis, className: "jp-WWCExtension-button jp-WWCExtension-synthesis-button" },
                    "Synthesize ",
                    selectedWithPDFs.length,
                    " Studies")) : null;
            })()),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ErrorDisplay__WEBPACK_IMPORTED_MODULE_5__.ErrorDisplay, { error: error }),
        papers.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                display: 'flex',
                gap: '10px',
                alignItems: 'center',
                marginBottom: '16px',
                marginLeft: '8px'
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleSelectAll, className: "jp-WWCExtension-button" }, selectedPapers.size === papers.length
                ? 'Deselect All'
                : 'Select All'),
            selectedPapers.size > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleDelete, className: "jp-WWCExtension-button jp-mod-warn" },
                "Delete ",
                selectedPapers.size,
                " from Library")))),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_LoadingState__WEBPACK_IMPORTED_MODULE_6__.LoadingState, null),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-papers" },
            papers.length === 0 && !isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-empty" }, "No papers found. Use the Discovery tab to search and import papers, or upload a PDF above.")),
            papers.map(paper => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_PaperCard__WEBPACK_IMPORTED_MODULE_2__.PaperCard, { key: (0,_utils_paper__WEBPACK_IMPORTED_MODULE_8__.getPaperKey)(paper), paper: paper, onViewDetails: () => setSelectedPaper(paper), selected: paper.id !== undefined && selectedPapers.has(paper.id), onToggleSelection: paper.id !== undefined
                    ? () => handleToggleSelection(paper.id)
                    : undefined }))))));
};


/***/ }),

/***/ "./lib/widgets/LoadingState.js":
/*!*************************************!*\
  !*** ./lib/widgets/LoadingState.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoadingState: () => (/* binding */ LoadingState)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SkeletonLoader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SkeletonLoader */ "./lib/widgets/SkeletonLoader.js");


const LoadingState = ({ count = 3 }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, Array.from({ length: count }).map((_, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SkeletonLoader__WEBPACK_IMPORTED_MODULE_1__.SkeletonLoader, { key: index })))));
};


/***/ }),

/***/ "./lib/widgets/MetaAnalysisView.js":
/*!*****************************************!*\
  !*** ./lib/widgets/MetaAnalysisView.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MetaAnalysisView: () => (/* binding */ MetaAnalysisView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_format__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/format */ "./lib/utils/format.js");


const MetaAnalysisView = ({ result }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Meta-Analysis Results"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-summary" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Pooled Effect Size:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    "d = ",
                    (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(result.pooled_effect, 3))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "95% Confidence Interval:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatCI)(result.ci_lower, result.ci_upper, 3))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "P-value:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(result.p_value, 4))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "I\u00B2:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                    (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(result.i_squared, 1),
                    "% -",
                    ' ',
                    result.heterogeneity_interpretation
                        ? result.heterogeneity_interpretation.replace(/\s*heterogeneity\s*/gi, '')
                        : 'N/A')),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Number of Studies:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, result.n_studies))),
        result.forest_plot && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-plot" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Forest Plot"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("img", { src: `data:image/png;base64,${result.forest_plot}`, alt: "Forest Plot", className: "jp-WWCExtension-plot-image" }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-studies" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Individual Studies"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { className: "jp-WWCExtension-table" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Study"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Effect Size"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "95% CI"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Weight"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", null, result.studies.map((study, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { key: idx },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, study.study_label),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(study.effect_size, 3)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatCI)(study.ci_lower, study.ci_upper, 3)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatPercent)(study.weight, 1))))))))));
};


/***/ }),

/***/ "./lib/widgets/PaperCard.js":
/*!**********************************!*\
  !*** ./lib/widgets/PaperCard.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaperCard: () => (/* binding */ PaperCard)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_paper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/paper */ "./lib/utils/paper.js");


const PaperCard = ({ paper, onImport, onViewDetails, selected = false, onToggleSelection }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-WWCExtension-paper-card ${selected ? 'jp-WWCExtension-paper-card-selected' : ''}` },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-card-header" },
            onToggleSelection && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-card-checkbox" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: selected, onChange: onToggleSelection, className: "jp-WWCExtension-checkbox", onClick: e => e.stopPropagation() }))),
            onViewDetails && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onViewDetails, className: "jp-WWCExtension-button jp-WWCExtension-view-details-button" }, "View Details"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", { className: `jp-WWCExtension-paper-title ${onViewDetails ? 'jp-mod-clickable' : ''}`, onClick: onViewDetails }, paper.title),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-meta" },
            paper.authors && paper.authors.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-authors" },
                "Authors: ",
                paper.authors.join(', '))),
            paper.year && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-year" },
                "Year: ",
                paper.year)),
            paper.citation_count !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-citations" },
                "Citations: ",
                paper.citation_count))),
        paper.abstract && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-abstract" },
            paper.abstract.substring(0, 200),
            paper.abstract.length > 200 ? '...' : '')),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-status" }, (0,_utils_paper__WEBPACK_IMPORTED_MODULE_1__.hasFullPDF)(paper) ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-WWCExtension-pdf-badge jp-mod-has-pdf" }, "\uD83D\uDCC4 Full PDF")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-WWCExtension-pdf-badge jp-mod-metadata-only" }, "\uD83D\uDCCB Metadata Only"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-paper-actions" }, onImport && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onImport, className: "jp-WWCExtension-button jp-WWCExtension-import-button" }, "Import to Library")))));
};


/***/ }),

/***/ "./lib/widgets/ResearchLibraryPanel.js":
/*!*********************************************!*\
  !*** ./lib/widgets/ResearchLibraryPanel.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResearchLibraryPanel: () => (/* binding */ ResearchLibraryPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _DiscoveryTab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DiscoveryTab */ "./lib/widgets/DiscoveryTab.js");
/* harmony import */ var _LibraryTab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./LibraryTab */ "./lib/widgets/LibraryTab.js");




const ResearchLibraryPanelComponent = () => {
    const [activeTab, setActiveTab] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('discovery');
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-panel" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-tabs" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-WWCExtension-tab ${activeTab === 'discovery' ? 'active' : ''}`, onClick: () => setActiveTab('discovery') }, "Discovery"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-WWCExtension-tab ${activeTab === 'library' ? 'active' : ''}`, onClick: () => setActiveTab('library') }, "Library")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-content" },
            activeTab === 'discovery' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_DiscoveryTab__WEBPACK_IMPORTED_MODULE_2__.DiscoveryTab, null),
            activeTab === 'library' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_LibraryTab__WEBPACK_IMPORTED_MODULE_3__.LibraryTab, null))));
};
class ResearchLibraryPanel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor() {
        super();
        this.addClass('jp-WWCExtension-panel-widget');
        this.id = 'research-library-panel';
        this.title.label = 'Research Library';
        this.title.caption = 'Academic Research Library';
        this.title.closable = true;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ResearchLibraryPanelComponent, null);
    }
}


/***/ }),

/***/ "./lib/widgets/SearchBar.js":
/*!**********************************!*\
  !*** ./lib/widgets/SearchBar.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchBar: () => (/* binding */ SearchBar)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const SearchBar = ({ query, onQueryChange, onSearch, isLoading, placeholder = 'Search...', additionalInputs, searchButtonText = 'Search' }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-search-bar" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", value: query, onChange: e => onQueryChange(e.target.value), onKeyPress: e => {
                if (e.key === 'Enter') {
                    onSearch();
                }
            }, placeholder: placeholder, className: "jp-WWCExtension-input" }),
        additionalInputs,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onSearch, disabled: isLoading || !query.trim(), className: "jp-WWCExtension-button" }, isLoading ? 'Searching...' : searchButtonText)));
};


/***/ }),

/***/ "./lib/widgets/SensitivityAnalysisView.js":
/*!************************************************!*\
  !*** ./lib/widgets/SensitivityAnalysisView.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SensitivityAnalysisView: () => (/* binding */ SensitivityAnalysisView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_format__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/format */ "./lib/utils/format.js");


const SensitivityAnalysisView = ({ result }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-sensitivity-analysis" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Sensitivity Analysis"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-sensitivity-overall" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Overall Effect (All Studies)"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-summary" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-stat" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Pooled Effect:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(result.overall_effect, 3))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-sensitivity-loo" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Leave-One-Out Analysis"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Effect size when each study is removed:"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-studies" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { className: "jp-WWCExtension-table" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Removed Study"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Pooled Effect"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "95% CI"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Difference"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", null, result.leave_one_out.map((loo, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { key: idx },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, loo.removed_study),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(loo.pooled_effect, 3)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatCI)(loo.ci_lower, loo.ci_upper, 3)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { className: Math.abs(loo.difference_from_overall) > 0.2
                                ? 'jp-mod-high-difference'
                                : '' },
                            loo.difference_from_overall > 0 ? '+' : '',
                            (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(loo.difference_from_overall, 3))))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-sensitivity-influence" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Influence Diagnostics"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Studies ranked by influence on overall result:"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-meta-analysis-studies" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { className: "jp-WWCExtension-table" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Study"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Influence Score"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Weight"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", null, "Effect Size"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", null, result.influence_diagnostics.map((diag, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { key: idx },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, diag.study_label),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(diag.influence_score, 4)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null,
                            (diag.weight * 100).toFixed(1),
                            "%"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", null, (0,_utils_format__WEBPACK_IMPORTED_MODULE_1__.formatNumber)(diag.effect_size, 3)))))))))));
};


/***/ }),

/***/ "./lib/widgets/SkeletonLoader.js":
/*!***************************************!*\
  !*** ./lib/widgets/SkeletonLoader.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SkeletonLoader: () => (/* binding */ SkeletonLoader)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const SkeletonLoader = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-skeleton" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-skeleton-title" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-skeleton-line" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-skeleton-line short" })));
};


/***/ }),

/***/ "./lib/widgets/SubgroupAnalysisView.js":
/*!*********************************************!*\
  !*** ./lib/widgets/SubgroupAnalysisView.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SubgroupAnalysisView: () => (/* binding */ SubgroupAnalysisView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MetaAnalysisView__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MetaAnalysisView */ "./lib/widgets/MetaAnalysisView.js");


const SubgroupAnalysisView = ({ result }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-subgroup-analysis" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null,
            "Subgroup Analysis: ",
            result.subgroup_variable),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-subgroup-overall" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Overall Meta-Analysis (All Studies)"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_MetaAnalysisView__WEBPACK_IMPORTED_MODULE_1__.MetaAnalysisView, { result: result.overall })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-subgroup-results" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Results by Subgroup"),
            Object.entries(result.subgroups).map(([subgroupName, subgroupResult]) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: subgroupName, className: "jp-WWCExtension-subgroup-item" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h5", null,
                    subgroupName,
                    " (n=",
                    subgroupResult.n_studies,
                    ")"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_MetaAnalysisView__WEBPACK_IMPORTED_MODULE_1__.MetaAnalysisView, { result: subgroupResult })))))));
};


/***/ }),

/***/ "./lib/widgets/SynthesisWorkbench.js":
/*!*******************************************!*\
  !*** ./lib/widgets/SynthesisWorkbench.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SynthesisWorkbench: () => (/* binding */ SynthesisWorkbench)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../api */ "./lib/api.js");
/* harmony import */ var _MetaAnalysisView__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MetaAnalysisView */ "./lib/widgets/MetaAnalysisView.js");
/* harmony import */ var _ConflictView__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ConflictView */ "./lib/widgets/ConflictView.js");
/* harmony import */ var _SubgroupAnalysisView__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./SubgroupAnalysisView */ "./lib/widgets/SubgroupAnalysisView.js");
/* harmony import */ var _BiasAssessmentView__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./BiasAssessmentView */ "./lib/widgets/BiasAssessmentView.js");
/* harmony import */ var _SensitivityAnalysisView__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./SensitivityAnalysisView */ "./lib/widgets/SensitivityAnalysisView.js");
/* harmony import */ var _utils_notifications__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils/notifications */ "./lib/utils/notifications.js");
/* harmony import */ var _Tabs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Tabs */ "./lib/widgets/Tabs.js");










const SynthesisWorkbenchComponent = ({ paperIds, onClose }) => {
    const [activeTab, setActiveTab] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('meta-analysis');
    const [metaAnalysisResult, setMetaAnalysisResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [conflictResult, setConflictResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [subgroupResult, setSubgroupResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [biasResult, setBiasResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [sensitivityResult, setSensitivityResult] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [subgroupVariable, setSubgroupVariable] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [subgroupAnalysisAttempted, setSubgroupAnalysisAttempted] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleRunMetaAnalysis = async () => {
        setIsLoading(true);
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_2__.performMetaAnalysis)(paperIds);
            setMetaAnalysisResult(result);
            setActiveTab('meta-analysis');
        }
        catch (err) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Meta-Analysis Error', err instanceof Error ? err.message : 'Unknown error', err instanceof Error ? err : undefined);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleDetectConflicts = async () => {
        setIsLoading(true);
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_2__.detectConflicts)(paperIds);
            setConflictResult(result);
            setActiveTab('conflicts');
        }
        catch (err) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Conflict Detection Error', err instanceof Error ? err.message : 'Unknown error', err instanceof Error ? err : undefined);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleRunSubgroupAnalysis = async () => {
        if (!subgroupVariable) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Subgroup Analysis', 'Please select a subgroup variable');
            return;
        }
        setIsLoading(true);
        setSubgroupAnalysisAttempted(true);
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_2__.performSubgroupAnalysis)(paperIds, subgroupVariable);
            setSubgroupResult(result);
            setActiveTab('subgroups');
        }
        catch (err) {
            setSubgroupResult(null); // Clear any previous result on error
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Subgroup Analysis Error', err instanceof Error ? err.message : 'Unknown error', err instanceof Error ? err : undefined);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleAssessBias = async () => {
        if (paperIds.length < 3) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Bias Assessment', 'Publication bias assessment requires at least 3 studies with effect size data.');
            return;
        }
        setIsLoading(true);
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_2__.assessPublicationBias)(paperIds);
            setBiasResult(result);
            setActiveTab('bias');
        }
        catch (err) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Bias Assessment Error', err instanceof Error ? err.message : 'Unknown error', err instanceof Error ? err : undefined);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleRunSensitivityAnalysis = async () => {
        if (paperIds.length < 3) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Sensitivity Analysis', 'Sensitivity analysis requires at least 3 studies with effect size data.');
            return;
        }
        setIsLoading(true);
        try {
            const result = await (0,_api__WEBPACK_IMPORTED_MODULE_2__.performSensitivityAnalysis)(paperIds);
            setSensitivityResult(result);
            setActiveTab('sensitivity');
        }
        catch (err) {
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_8__.showError)('Sensitivity Analysis Error', err instanceof Error ? err.message : 'Unknown error', err instanceof Error ? err : undefined);
        }
        finally {
            setIsLoading(false);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null,
                "Synthesis Workbench (",
                paperIds.length,
                " studies)"),
            onClose && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onClose, className: "jp-WWCExtension-close" }, "\u00D7"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-actions" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-actions-row" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleRunMetaAnalysis, disabled: isLoading, className: "jp-WWCExtension-button" }, "Run Meta-Analysis"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleDetectConflicts, disabled: isLoading, className: "jp-WWCExtension-button" }, "Detect Conflicts")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-actions-row" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: subgroupVariable, onChange: e => setSubgroupVariable(e.target.value), className: "jp-WWCExtension-select" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "Select Subgroup Variable..."),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "age_group" }, "Age Group"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "intervention_type" }, "Intervention Type"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "learning_domain" }, "Learning Domain")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleRunSubgroupAnalysis, disabled: isLoading || !subgroupVariable, className: "jp-WWCExtension-button" }, "Run Subgroup Analysis")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-actions-row" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleAssessBias, disabled: isLoading, className: `jp-WWCExtension-button ${paperIds.length < 3 ? 'jp-mod-muted-gray' : ''}` }, "Assess Publication Bias"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleRunSensitivityAnalysis, disabled: isLoading, className: `jp-WWCExtension-button ${paperIds.length < 3 ? 'jp-mod-muted-gray' : ''}` }, "Sensitivity Analysis"))),
        isLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-loading" }, "Processing...")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_Tabs__WEBPACK_IMPORTED_MODULE_9__.Tabs, { tabs: [
                { id: 'meta-analysis', label: 'Meta-Analysis' },
                {
                    id: 'conflicts',
                    label: 'Conflicts',
                    badge: (conflictResult === null || conflictResult === void 0 ? void 0 : conflictResult.n_contradictions) || 0
                },
                {
                    id: 'subgroups',
                    label: 'Subgroups',
                    badge: subgroupResult ? subgroupResult.n_subgroups : undefined
                },
                { id: 'bias', label: 'Bias Assessment' },
                { id: 'sensitivity', label: 'Sensitivity' }
            ], activeTab: activeTab, onTabChange: (tabId) => setActiveTab(tabId) }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-content" },
            activeTab === 'meta-analysis' && metaAnalysisResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_MetaAnalysisView__WEBPACK_IMPORTED_MODULE_3__.MetaAnalysisView, { result: metaAnalysisResult })),
            activeTab === 'conflicts' && conflictResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ConflictView__WEBPACK_IMPORTED_MODULE_4__.ConflictView, { result: conflictResult })),
            activeTab === 'subgroups' && subgroupResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SubgroupAnalysisView__WEBPACK_IMPORTED_MODULE_5__.SubgroupAnalysisView, { result: subgroupResult })),
            activeTab === 'subgroups' && !subgroupResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-empty" }, subgroupAnalysisAttempted ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "No Subgroup Analysis Could Be Performed"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Subgroup analysis requires at least 2 studies with both effect sizes and the selected subgroup variable metadata. The analysis could not be completed with the current data."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "To perform subgroup analysis, ensure your papers have:"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null, "Effect sizes (run AI extraction if needed)"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                        "The selected subgroup variable (",
                        subgroupVariable || 'select one above',
                        ") in their metadata")))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "No Subgroup Analysis Results"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "To run subgroup analysis, select a subgroup variable from the dropdown above and click \"Run Subgroup Analysis\"."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Subgroup analysis requires at least 2 studies with both effect sizes and the selected subgroup variable metadata."))))),
            activeTab === 'bias' && biasResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_BiasAssessmentView__WEBPACK_IMPORTED_MODULE_6__.BiasAssessmentView, { result: biasResult })),
            activeTab === 'sensitivity' && sensitivityResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SensitivityAnalysisView__WEBPACK_IMPORTED_MODULE_7__.SensitivityAnalysisView, { result: sensitivityResult })),
            !metaAnalysisResult &&
                !conflictResult &&
                !subgroupResult &&
                !biasResult &&
                !sensitivityResult && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-synthesis-empty" }, "Click \"Run Meta-Analysis\" or \"Detect Conflicts\" to begin.")))));
};
class SynthesisWorkbench extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(paperIds) {
        super();
        this.paperIds = paperIds;
        this.addClass('jp-WWCExtension-synthesis-widget');
        this.id = 'synthesis-workbench';
        this.title.label = 'Synthesis Workbench';
        this.title.caption = 'Meta-Analysis & Conflict Detection';
        this.title.closable = true;
    }
    render() {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SynthesisWorkbenchComponent, { paperIds: this.paperIds });
    }
}


/***/ }),

/***/ "./lib/widgets/Tabs.js":
/*!*****************************!*\
  !*** ./lib/widgets/Tabs.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Tabs: () => (/* binding */ Tabs)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const Tabs = ({ tabs, activeTab, onTabChange, className = 'jp-WWCExtension-synthesis-tabs', activeClassName = 'jp-WWCExtension-tab-active', inactiveClassName = 'jp-WWCExtension-tab' }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: className }, tabs.map(tab => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { key: tab.id, className: activeTab === tab.id ? activeClassName : inactiveClassName, onClick: () => onTabChange(tab.id) },
        tab.label,
        tab.badge !== undefined && ` (${tab.badge})`)))));
};


/***/ }),

/***/ "./lib/widgets/WWCCoPilot.js":
/*!***********************************!*\
  !*** ./lib/widgets/WWCCoPilot.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WWCCoPilot: () => (/* binding */ WWCCoPilot)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./lib/api.js");
/* harmony import */ var _utils_notifications__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils/notifications */ "./lib/utils/notifications.js");
/* harmony import */ var _utils_hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/hooks */ "./lib/utils/hooks.js");
/* harmony import */ var _utils_format__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/format */ "./lib/utils/format.js");





const WWCCoPilot = ({ paperId, paperTitle, onClose }) => {
    const [currentStep, setCurrentStep] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('randomization');
    const [assessment, setAssessment] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [judgments, setJudgments] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        chosen_attrition_boundary: 'cautious',
        adjustment_strategy_is_valid: undefined,
        randomization_documented: undefined
    });
    const isRunningRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false); // Prevent concurrent assessment calls
    const steps = [
        'randomization',
        'attrition',
        'baseline',
        'adjustment',
        'review'
    ];
    const stepLabels = {
        randomization: 'Randomization',
        attrition: 'Attrition',
        baseline: 'Baseline Equivalence',
        adjustment: 'Statistical Adjustment',
        review: 'Review & Finalize'
    };
    const getStepIndex = (step) => steps.indexOf(step);
    const progress = ((getStepIndex(currentStep) + 1) / steps.length) * 100;
    // Load saved assessment from localStorage
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const saved = localStorage.getItem(`wwc-assessment-${paperId}`);
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                if (parsed.judgments) {
                    setJudgments(parsed.judgments);
                }
                if (parsed.currentStep) {
                    setCurrentStep(parsed.currentStep);
                }
            }
            catch (e) {
                console.error('Failed to load saved assessment:', e);
            }
        }
    }, [paperId]);
    const saveProgress = () => {
        localStorage.setItem(`wwc-assessment-${paperId}`, JSON.stringify({
            judgments,
            currentStep
        }));
    };
    const runAssessmentWithRequest = async (paperId, judgments) => {
        const request = {
            paper_id: paperId,
            judgments
        };
        return await (0,_api__WEBPACK_IMPORTED_MODULE_1__.runWWCAssessment)(request);
    };
    const [isAssessmentLoading, executeAssessment, assessmentError] = (0,_utils_hooks__WEBPACK_IMPORTED_MODULE_3__.useAsyncOperation)(runAssessmentWithRequest);
    const runAssessment = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        // Prevent concurrent calls
        if (isRunningRef.current) {
            return;
        }
        isRunningRef.current = true;
        try {
            const result = await executeAssessment(paperId, judgments);
            if (result) {
                setAssessment(result);
                saveProgress();
            }
        }
        finally {
            isRunningRef.current = false;
        }
    }, [paperId, judgments, executeAssessment]);
    // Only auto-run assessment when moving to review step (not on every judgment change)
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (currentStep === 'review' && !assessment && !isAssessmentLoading) {
            // Only run if we don't already have an assessment and not currently loading
            runAssessment();
        }
        // Intentionally exclude runAssessment from deps to prevent infinite loops
    }, [currentStep]);
    // Handle errors - only show once per error
    const [lastError, setLastError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (assessmentError && assessmentError !== lastError) {
            setLastError(assessmentError);
            (0,_utils_notifications__WEBPACK_IMPORTED_MODULE_2__.showError)('WWC Assessment Error', assessmentError.message || 'Failed to fetch assessment', assessmentError);
        }
    }, [assessmentError, lastError]);
    const handleNext = () => {
        const currentIndex = getStepIndex(currentStep);
        if (currentIndex < steps.length - 1) {
            setCurrentStep(steps[currentIndex + 1]);
            saveProgress();
        }
    };
    const handlePrevious = () => {
        const currentIndex = getStepIndex(currentStep);
        if (currentIndex > 0) {
            setCurrentStep(steps[currentIndex - 1]);
        }
    };
    const handleStepChange = (step) => {
        setCurrentStep(step);
        saveProgress();
    };
    const getRatingColorClass = (rating) => {
        if (rating.includes('Without Reservations')) {
            return 'jp-type-meets-standards';
        }
        if (rating.includes('With Reservations')) {
            return 'jp-type-meets-with-reservations';
        }
        return 'jp-type-does-not-meet';
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null,
                "WWC Co-Pilot: ",
                paperTitle),
            onClose && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onClose, className: "jp-WWCExtension-close" }, "\u00D7"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-info-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-info-box" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-info-content" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "\u2139\uFE0F About WWC Assessment"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "WWC assessment evaluates studies based on randomization documentation, attrition rates, baseline equivalence, and statistical adjustments. Complete the wizard steps to get your assessment rating."))),
            (assessmentError ||
                (assessment &&
                    (assessment.overall_attrition === undefined ||
                        assessment.rating_justification.some(msg => msg.includes('incomplete') ||
                            msg.includes('Insufficient data'))))) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-warning-box" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-warning-content" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "\u26A0\uFE0F Missing Required Data"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Attrition data was not found in this paper. Without sample sizes and attrition rates, the assessment will default to \"Does Not Meet WWC Standards.\""),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
                        "To complete the assessment, ensure the paper has",
                        ' ',
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", null, "study_metadata"),
                        " with sample sizes and attrition data. This can be added via AI extraction during PDF upload (if configured) or manually."))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-progress" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-progress-bar" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-progress-fill", style: { width: `${progress}%` } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-steps" }, steps.map((step, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { key: step, className: `jp-WWCExtension-step ${currentStep === step ? 'active' : ''} ${getStepIndex(currentStep) > idx ? 'completed' : ''}`, onClick: () => handleStepChange(step) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "step-number" }, idx + 1),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "step-label" }, stepLabels[step])))))),
        isAssessmentLoading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-loading" }, "Running assessment...")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-content" },
            currentStep === 'randomization' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(RandomizationStep, { randomizationDocumented: judgments.randomization_documented, onChange: value => {
                    setJudgments({ ...judgments, randomization_documented: value });
                    saveProgress();
                } })),
            currentStep === 'attrition' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(AttritionStep, { boundary: judgments.chosen_attrition_boundary || 'cautious', onChange: value => {
                    setJudgments({ ...judgments, chosen_attrition_boundary: value });
                    saveProgress();
                }, assessment: assessment })),
            currentStep === 'baseline' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(BaselineStep, { assessment: assessment }),
            currentStep === 'adjustment' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(AdjustmentStep, { adjustmentValid: judgments.adjustment_strategy_is_valid, onChange: value => {
                    setJudgments({
                        ...judgments,
                        adjustment_strategy_is_valid: value
                    });
                    saveProgress();
                } })),
            currentStep === 'review' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ReviewStep, { assessment: assessment, judgments: judgments, onRunAssessment: runAssessment, isLoading: isAssessmentLoading, getRatingColorClass: getRatingColorClass }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-navigation" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handlePrevious, disabled: currentStep === steps[0], className: "jp-WWCExtension-button" }, "Previous"),
            currentStep !== steps[steps.length - 1] ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: handleNext, className: "jp-WWCExtension-button" }, "Next")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: runAssessment, disabled: isAssessmentLoading, className: "jp-WWCExtension-button" }, isAssessmentLoading ? 'Running...' : 'Run Assessment')))));
};
// Individual step components
const RandomizationStep = ({ randomizationDocumented, onChange }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-step-content" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Step 1: Randomization"),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Was randomization properly documented in the study?"),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: randomizationDocumented === undefined
            ? ''
            : String(randomizationDocumented), onChange: e => onChange(e.target.value === 'true'), className: "jp-WWCExtension-select" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "Not specified"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "true" }, "Yes"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "false" }, "No")),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jp-WWCExtension-wwc-help" }, "Randomization must be clearly described in the study methodology.")));
const AttritionStep = ({ boundary, onChange, assessment }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-step-content" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Step 2: Attrition"),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-field" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", null, "Attrition Boundary:"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: boundary, onChange: e => onChange(e.target.value), className: "jp-WWCExtension-select" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "cautious" }, "Cautious (default)"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "optimistic" }, "Optimistic")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jp-WWCExtension-wwc-help" }, "Choose based on whether the intervention could affect who stays in the study.")),
    assessment && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-section" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Attrition Results"),
        assessment.overall_attrition !== null &&
            assessment.overall_attrition !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
            "Overall: ",
            (0,_utils_format__WEBPACK_IMPORTED_MODULE_4__.formatPercent)(assessment.overall_attrition, 1))),
        assessment.differential_attrition !== null &&
            assessment.differential_attrition !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
            "Differential:",
            ' ',
            (0,_utils_format__WEBPACK_IMPORTED_MODULE_4__.formatPercent)(assessment.differential_attrition, 1))),
        assessment.is_high_attrition !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
            "Status:",
            ' ',
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, assessment.is_high_attrition
                ? 'High Attrition'
                : 'Low Attrition')))))));
const BaselineStep = ({ assessment }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-step-content" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Step 3: Baseline Equivalence"),
    (assessment === null || assessment === void 0 ? void 0 : assessment.baseline_effect_size) !== null &&
        (assessment === null || assessment === void 0 ? void 0 : assessment.baseline_effect_size) !== undefined ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-section" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
            "Effect Size (Cohen's d):",
            ' ',
            (0,_utils_format__WEBPACK_IMPORTED_MODULE_4__.formatNumber)(assessment.baseline_effect_size, 3)),
        assessment.baseline_equivalence_satisfied !== undefined && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null,
            "Status:",
            ' ',
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, assessment.baseline_equivalence_satisfied
                ? 'Satisfied'
                : 'Not Satisfied'))))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Baseline equivalence will be calculated after running the assessment."))));
const AdjustmentStep = ({ adjustmentValid, onChange }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-step-content" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Step 4: Statistical Adjustment"),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Was a valid statistical adjustment used?"),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: adjustmentValid === undefined ? '' : String(adjustmentValid), onChange: e => onChange(e.target.value === 'true'), className: "jp-WWCExtension-select" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "Not applicable"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "true" }, "Yes"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "false" }, "No")),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jp-WWCExtension-wwc-help" }, "Required for studies with high attrition or baseline differences.")));
const ReviewStep = ({ assessment, judgments, onRunAssessment, isLoading, getRatingColorClass }) => {
    var _a, _b;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-step-content" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "Step 5: Review & Finalize"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-judgments" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Your Judgments:"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                    "Attrition Boundary:",
                    ' ',
                    judgments.chosen_attrition_boundary || 'cautious'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                    "Randomization Documented:",
                    ' ',
                    ((_a = judgments.randomization_documented) === null || _a === void 0 ? void 0 : _a.toString()) || 'Not specified'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", null,
                    "Adjustment Valid:",
                    ' ',
                    ((_b = judgments.adjustment_strategy_is_valid) === null || _b === void 0 ? void 0 : _b.toString()) ||
                        'Not applicable'))),
        assessment && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-results" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Final Rating"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-WWCExtension-wwc-rating ${getRatingColorClass(assessment.final_rating)}` },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null,
                    "Final Rating: ",
                    assessment.final_rating)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-WWCExtension-wwc-justification" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h4", null, "Justification"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("ul", null, assessment.rating_justification.map((reason, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("li", { key: idx }, reason))))))),
        !assessment && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "Click \"Run Assessment\" to calculate the final WWC rating."))));
};


/***/ })

}]);
//# sourceMappingURL=lib_index_js.8b82be8b54cea43f3742.js.map