- In a picking where the recompute operation is enabled (see Configuration),
  the recompute is available on picking level and on the detailed operations if
  enabled.
- If a putaway rule has been changed after product reservation, click on
  the button 'Recompute putaways'. This will recompute the destination locations
  on all detailed operations that have no done quantity yet and no result package 
  (as all operations for the same package should go to the same destination).
- Moreover, the action is available on picking level and on detailed operation one too.
