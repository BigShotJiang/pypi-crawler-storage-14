"__init__"

import libvirt

from .disk import KernelVirtualDiskDriver
from .hypervisor import KernelVirtualHostDriver
from .snapshot import KernelVirtualSnapshotDriver
from .vm import KernelVirtualMachineDriver

__all__ = [
    "KernelVirtualDiskDriver",
    "KernelVirtualHostDriver",
    "KernelVirtualSnapshotDriver",
    "KernelVirtualMachineDriver",
]


def libvirt_callback(ctx, err):  # pylint: disable=unused-argument
    """Avoid printing error messages"""


libvirt.registerErrorHandler(f=libvirt_callback, ctx=None)
