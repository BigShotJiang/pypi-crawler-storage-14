"""Helper library for manipulation of formatted date/datetime values."""

from .core import add, isoweekday, sub, today, weekday

__version__ = "0.2.0"
