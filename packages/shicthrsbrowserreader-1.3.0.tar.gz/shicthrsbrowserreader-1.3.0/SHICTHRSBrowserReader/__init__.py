# *-* coding: utf-8 *-*
# src\__init__.py
# SHICTHRS Browser Reader
# AUTHOR : SHICTHRS-JNTMTMTM
# Copyright : © 2025-2026 SHICTHRS, Std. All rights reserved.
# lICENSE : GPL-3.0

from colorama import init
init()

from .browser_history.browser_history_processor import SHRBrowserHistoryProcessor

print('\033[1mWelcome to use SHRBrowserReader - browser history reader\033[0m\n|  \033[1;34mGithub : https://github.com/JNTMTMTM/SHICTHRS_BrowserReader\033[0m')
print('|  \033[1mAlgorithms = rule ; Questioning = approval\033[0m')
print('|  \033[1mCopyright : © 2025-2026 SHICTHRS, Std. All rights reserved.\033[0m\n')

__all__ = ['SHRBrowserReader_get_browser_history']

class SHRBrowserReaderException(Exception):
    def __init__(self , message: str) -> None:
        self.message = message
    
    def __str__(self):
        return self.message

def SHRBrowserReader_get_browser_history(browser : str) -> None:
    # browser 'Chrome', 'Firefox', 'Edge', 'Opera', 'OperaGX', 'Brave', 'Vivaldi', 'LibreWolf', 'Safari', 'Epic'
    selected_browser = browser.lower()
    try:
        processor = SHRBrowserHistoryProcessor(SHRBrowserReaderException)
        processor.fetch_history(selected_browser)
        result = processor.save_processed_history()
        if not result:
            raise SHRBrowserReaderException(f"SHRBrowserReader [ERROR.6004] get empty browser history. Browser : {browser}")
        return result
    except Exception as e:
        raise SHRBrowserReaderException(f"SHRBrowserReader [ERROR.6000] unable to get browser history. Browser : {browser} | {str(e)}")
