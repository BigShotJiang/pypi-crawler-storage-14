from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Tuple
import json
import hashlib
import time
import logging

import pyarrow.parquet as pq
import pyarrow as pa
import pyarrow.dataset as ds

import warpdata as wd
from warpdata.core.registry import get_registry
from warpdata.api.management import materialize
from warpdata.engine.duck import get_engine


class BaseWarpDatasetModule:
    """
    Base class for Warp dataset modules with a common contract and
    thin wrappers over warpdata APIs for embeddings.
    """

    # Override in subclasses
    id: str = ""
    version: str = "0.0.0"
    dataset_uri: str = ""  # e.g., "warpdata://math/gsm8k"

    # --- Dataset contract ---
    def get_schema(self) -> Dict[str, Any]:
        """Return the dataset schema from the registry manifest."""
        info = wd.dataset_info(self.dataset_uri)
        return info["manifest"]["schema"]

    def prepare(self, split: str = "", cache_dir: Optional[Path] = None, force: bool = False) -> Path:
        """
        Ensure a materialized parquet with 'rid' exists and return a Forge-friendly
        cache directory: .forgelab/state/datasets/{module_id}/{version}/{split}

        Split is accepted for interface parity; for single-table datasets, it can be
        an empty string or 'default'.
        """
        logger = logging.getLogger(__name__)
        mat_path = materialize(self.dataset_uri, update_registry=False, force=force)

        # Determine target cache dir
        split_dir = split or "default"
        root = (cache_dir or Path.cwd()).resolve()
        forge_dir = root / ".forgelab" / "state" / "datasets" / self.id / self.version / split_dir
        forge_dir.mkdir(parents=True, exist_ok=True)

        # Destination parquet path
        dst_parquet = forge_dir / "materialized.parquet"

        # Copy or link file if missing or force
        if force or not dst_parquet.exists():
            try:
                # Use hardlink when possible for speed
                if dst_parquet.exists():
                    dst_parquet.unlink()
                dst_parquet.hardlink_to(mat_path)
                logger.debug(f"Hardlinked materialized parquet to {dst_parquet}")
            except Exception:
                # Fallback to copy
                import shutil
                shutil.copy2(mat_path, dst_parquet)
                logger.debug(f"Copied materialized parquet to {dst_parquet}")

        # Write/refresh lock manifest
        self._write_lock_manifest(forge_dir, dst_parquet)
        logger.debug(f"Wrote lock manifest in {forge_dir}")

        return forge_dir

    def load(
        self,
        split: str = "",
        format: str = "arrow",
        columns: Optional[List[str]] = None,
        limit: Optional[int] = None,
        filters: Optional[Union[Dict[str, Any], List[Tuple[str, str, Any]]]] = None,
        validate_schema: bool = False,
        schema_allow_extra: bool = True,
    ) -> Union[pa.Table, Any]:
        """
        Load the prepared materialized parquet in requested format.
        Supported: 'arrow', 'pandas', 'duckdb'.
        - filters: supports simple equality filters as dict or list of (col, '==', value)
        - validate_schema: when True, validates columns/dtypes against manifest schema
        """
        mat_dir = self.prepare(split)
        parquet_path = mat_dir / "materialized.parquet"
        if not parquet_path.exists():
            raise FileNotFoundError(f"Materialized parquet not found: {parquet_path}")

        def _apply_filters_arrow(pq_path: Path) -> pa.Table:
            if filters is None:
                table_local = pq.read_table(pq_path, columns=columns, memory_map=True)
                return table_local
            # Build dataset scanner for filter pushdown
            dataset = ds.dataset(str(pq_path))
            filt_expr = None
            if isinstance(filters, dict):
                for k, v in filters.items():
                    expr = (ds.field(k) == v)
                    filt_expr = expr if filt_expr is None else (filt_expr & expr)
            else:
                for (k, op, v) in filters:
                    if op != "==":
                        raise ValueError("Only '==' operator supported in simple filters")
                    expr = (ds.field(k) == v)
                    filt_expr = expr if filt_expr is None else (filt_expr & expr)
            scanner = dataset.scanner(columns=columns, filter=filt_expr)
            return scanner.to_table()

        if format == "arrow":
            table = _apply_filters_arrow(parquet_path)
            if limit:
                table = table.slice(0, limit)
            if validate_schema:
                self._validate_schema(table, allow_extra=schema_allow_extra)
            return table
        elif format == "pandas":
            table = _apply_filters_arrow(parquet_path)
            if limit:
                table = table.slice(0, limit)
            if validate_schema:
                self._validate_schema(table, allow_extra=schema_allow_extra)
            return table.to_pandas()
        elif format == "duckdb":
            engine = get_engine()
            rel = engine.conn.read_parquet(str(parquet_path))
            if columns:
                rel = rel.project(", ".join(f'"{c}"' for c in columns))
            if limit:
                rel = rel.limit(limit)
            return rel
        else:
            raise ValueError(f"Unsupported format: {format}")

    def fingerprint(self) -> str:
        """Compute SHA256 over manifest + provider id/version + schema hash."""
        from warpdata.core.uris import parse_uri

        uri = parse_uri(self.dataset_uri)
        registry = get_registry()
        dataset_ver = registry.get_dataset_version(uri.workspace, uri.name, uri.version or "latest")
        if dataset_ver is None:
            raise ValueError(f"Dataset not found: {self.dataset_uri}")
        manifest = registry.get_manifest(uri.workspace, uri.name, dataset_ver["version_hash"])
        schema = manifest.get("schema", {}) if manifest else {}
        payload = {
            "module_id": self.id,
            "module_version": self.version,
            "dataset": f"{uri.workspace}/{uri.name}",
            "version_hash": dataset_ver["version_hash"],
            "schema": schema,
            "manifest": manifest,
        }
        data = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
        return hashlib.sha256(data).hexdigest()

    # --- Embeddings helpers (delegate to warpdata API) ---
    def add_embeddings(
        self,
        space: str,
        provider: str,
        source: Dict[str, Any],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        distance_metric: str = "cosine",
        batch_size: int = 100,
        return_info: bool = False,
        **kwargs,
    ) -> Union[Path, Dict[str, Any]]:
        p = wd.add_embeddings(
            self.dataset_uri,
            space=space,
            provider=provider,
            source=source,
            model=model,
            dimension=dimension,
            distance_metric=distance_metric,
            batch_size=batch_size,
            **kwargs,
        )
        if not return_info:
            return p
        # Build metadata dict for provenance
        from warpdata.core.uris import parse_uri
        uri = parse_uri(self.dataset_uri)
        reg = get_registry()
        ver = reg.get_dataset_version(uri.workspace, uri.name, uri.version or "latest")
        info = {
            "storage_path": str(p),
            "dataset": f"{uri.workspace}/{uri.name}",
            "version_hash": ver["version_hash"] if ver else None,
            "space": space,
            "provider": provider,
            "model": model,
            "dimension": dimension,
            "distance_metric": distance_metric,
            "created_at": time.time(),
        }
        return info

    def list_embeddings(self, all_versions: bool = False) -> List[Dict[str, Any]]:
        return wd.list_embeddings(self.dataset_uri, all_versions=all_versions)

    def search_embeddings(
        self,
        space: str,
        query: Union[str, List[float]],
        top_k: int = 10,
        distance_metric: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        return wd.search_embeddings(
            self.dataset_uri,
            space=space,
            query=query,
            top_k=top_k,
            distance_metric=distance_metric,
        )

    def join_results(
        self,
        rids: List[int],
        columns: Optional[List[str]] = None,
        as_format: str = "pandas",
    ) -> Any:
        return wd.join_results(self.dataset_uri, rids=rids, columns=columns, as_format=as_format)

    def get_embeddings(
        self,
        space: str,
        rids: Optional[List[int]] = None,
        as_format: str = "arrow",
    ) -> Union[pa.Table, Any]:
        """
        Read vectors for a given space from the registry's storage path.
        Returns rows with [rid, vector]. Optionally filter by rids.
        """
        spaces = self.list_embeddings()
        info = next((s for s in spaces if s["space_name"] == space), None)
        if not info:
            raise ValueError(f"Embedding space '{space}' not found for {self.dataset_uri}")

        vectors_pq = Path(info["storage_path"]) / "vectors.parquet"
        table = pq.read_table(vectors_pq)
        if rids is not None:
            rid_set = set(rids)
            mask = pa.array([rid in rid_set for rid in table["rid"].to_pylist()])
            table = table.filter(mask)
        if as_format == "arrow":
            return table
        elif as_format == "pandas":
            return table.to_pandas()
        else:
            raise ValueError(f"Unsupported as_format: {as_format}")

    def destroy_embeddings(self, space: str, delete_files: bool = False) -> None:
        """Convenience wrapper to remove an embedding space from the dataset."""
        wd.remove_embeddings(self.dataset_uri, space=space, delete_files=delete_files)

    # --- Internals ---
    def _write_lock_manifest(self, target_dir: Path, parquet_path: Path) -> None:
        from warpdata.core.uris import parse_uri
        uri = parse_uri(self.dataset_uri)
        reg = get_registry()
        ver = reg.get_dataset_version(uri.workspace, uri.name, uri.version or "latest")
        manifest = reg.get_manifest(uri.workspace, uri.name, ver["version_hash"]) if ver else {}

        # Compute file stats
        file_bytes = parquet_path.stat().st_size if parquet_path.exists() else 0
        row_count = 0
        try:
            engine = get_engine()
            rel = engine.conn.read_parquet(str(parquet_path))
            row_count = int(rel.count("*").fetchone()[0])
        except Exception:
            pass

        lock = {
            "module_id": self.id,
            "module_version": self.version,
            "dataset": f"{uri.workspace}/{uri.name}",
            "version_hash": ver["version_hash"] if ver else None,
            "schema": manifest.get("schema") if manifest else None,
            "schema_hash": hashlib.sha256(json.dumps(manifest.get("schema", {}), sort_keys=True).encode("utf-8")).hexdigest() if manifest else None,
            "resources": manifest.get("resources", []) if manifest else [],
            "materialized_file": str(parquet_path),
            "file_bytes": file_bytes,
            "row_count": row_count,
            "rid_present": True,
            "created_at": time.time(),
        }

        out = target_dir / "manifest.json"
        out.write_text(json.dumps(lock, indent=2, sort_keys=True))

    def _validate_schema(self, table: pa.Table, allow_extra: bool = True) -> None:
        """Validate Arrow table schema against manifest schema; raise on mismatch."""
        manifest_schema = self.get_schema() or {}
        required_cols = {c["name"] if isinstance(c, dict) and "name" in c else k for k, c in (manifest_schema.get("columns") or {}).items()} if isinstance(manifest_schema.get("columns"), list) else set(manifest_schema.keys())
        # If manifest uses dict mapping, types may be string type names
        if isinstance(manifest_schema.get("columns"), dict):
            type_map = manifest_schema["columns"]
        else:
            type_map = {c.get("name"): c.get("dtype") for c in (manifest_schema.get("columns") or []) if isinstance(c, dict)}

        table_cols = set(table.column_names)
        missing = [c for c in required_cols if c and c not in table_cols]
        if missing:
            raise ValueError(f"Schema validation failed: missing columns {missing}")

        if not allow_extra:
            extra = [c for c in table_cols if c not in required_cols]
            if extra:
                raise ValueError(f"Schema validation failed: unexpected columns {extra}")
