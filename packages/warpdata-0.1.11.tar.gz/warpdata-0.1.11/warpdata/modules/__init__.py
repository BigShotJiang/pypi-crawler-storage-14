"""Warp modules: dataset providers and shared contracts."""

from __future__ import annotations
from typing import Any

from .registry import get_provider_class


def get_module(module_id: str, **kwargs: Any):
    """
    Resolve and instantiate a dataset provider module by its id.

    Uses entry points under group 'warp.datasets' and falls back to
    built-in providers bundled with warpdata.
    """
    cls = get_provider_class(module_id)
    if cls is None:
        raise ValueError(f"Provider not found for module id: {module_id}")
    return cls(**kwargs)

