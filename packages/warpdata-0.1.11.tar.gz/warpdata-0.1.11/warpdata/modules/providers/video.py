from __future__ import annotations
from ..base import BaseWarpDatasetModule


class Dream1KModule(BaseWarpDatasetModule):
    id = "warp.dataset.dream1k"
    version = "1.0.0"
    dataset_uri = "warpdata://video/dream1k"


class Dream1KEventsModule(BaseWarpDatasetModule):
    id = "warp.dataset.dream1k_events"
    version = "1.0.0"
    dataset_uri = "warpdata://video/dream1k-events"

