"""
Mathlib4 Dependency Graph Recipe.

Extracts a large directed concept-dependency graph from mathlib4 (Lean 4's math library).
Captures file-level import relationships, clusters by domain, and extracts graph metrics.

Data structure:
- Main dataset: File-level nodes with metadata and graph metrics
- Edges subdataset: Import dependency edges (different schema - valid subdataset!)

Source: https://github.com/leanprover-community/mathlib4
License: Apache 2.0
"""
from pathlib import Path
from typing import Optional, List, Dict, Set, Tuple
import pandas as pd
import re
import json
from tqdm import tqdm

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset

# Regex patterns for Lean 4
IMPORT_RE = re.compile(r'^import\s+([\w\.]+)', re.MULTILINE)
THEOREM_RE = re.compile(r'\b(theorem|lemma|corollary)\s+(\w+)', re.MULTILINE)
DEFINITION_RE = re.compile(r'\b(def|structure|class|inductive)\s+(\w+)', re.MULTILINE)

# Enhanced extraction patterns
COPYRIGHT_RE = re.compile(r'Copyright \(c\) (\d{4})', re.MULTILINE)
AUTHORS_RE = re.compile(r'^Authors?:\s*(.+)$', re.MULTILINE)
NAMESPACE_RE = re.compile(r'^namespace\s+([\w\.]+)', re.MULTILINE)
ATTRIBUTE_RE = re.compile(r'@\[([^\]]+)\]', re.MULTILINE)


def extract_docstring_metadata(lean_file: Path) -> Dict[str, any]:
    """Extract metadata from Lean file docstring (/-! ... -/)."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return _empty_docstring_metadata()

    # Extract main docstring (/-! ... -/)
    docstring_match = re.search(r'/-!(.*?)-/', text, re.DOTALL)
    if not docstring_match:
        return _empty_docstring_metadata()

    docstring = docstring_match.group(1)

    # Extract copyright year (from header comments)
    copyright_match = COPYRIGHT_RE.search(text[:500])  # Search first 500 chars
    copyright_year = copyright_match.group(1) if copyright_match else None

    # Extract authors
    authors_match = AUTHORS_RE.search(text[:500])
    authors = []
    if authors_match:
        authors_line = authors_match.group(1)
        # Split by comma and clean up
        authors = [a.strip() for a in authors_line.split(',')]

    # Extract title (first line of docstring)
    title_match = re.search(r'#\s*(.+)', docstring)
    title = title_match.group(1).strip() if title_match else ""

    # Check for main sections
    has_main_definitions = bool(re.search(r'##\s*Main definitions', docstring, re.IGNORECASE))
    has_main_theorems = bool(re.search(r'##\s*Main theorems?', docstring, re.IGNORECASE))
    has_main_statements = bool(re.search(r'##\s*Main statements', docstring, re.IGNORECASE))
    has_references = bool(re.search(r'##\s*References', docstring, re.IGNORECASE))
    has_examples = bool(re.search(r'##\s*Examples?', docstring, re.IGNORECASE))

    # Extract main theorems section text
    main_theorems_text = ""
    if has_main_theorems:
        theorems_match = re.search(
            r'##\s*Main theorems?\s*\n(.*?)(?=\n##|\Z)',
            docstring,
            re.DOTALL | re.IGNORECASE
        )
        if theorems_match:
            main_theorems_text = theorems_match.group(1).strip()

    # Extract main definitions section text
    main_definitions_text = ""
    if has_main_definitions:
        defs_match = re.search(
            r'##\s*Main definitions\s*\n(.*?)(?=\n##|\Z)',
            docstring,
            re.DOTALL | re.IGNORECASE
        )
        if defs_match:
            main_definitions_text = defs_match.group(1).strip()

    # Extract references section
    references_text = ""
    if has_references:
        refs_match = re.search(
            r'##\s*References\s*\n(.*?)(?=\n##|\Z)',
            docstring,
            re.DOTALL | re.IGNORECASE
        )
        if refs_match:
            references_text = refs_match.group(1).strip()

    # Count references
    num_references = len(re.findall(r'^\*\s', references_text, re.MULTILINE))

    return {
        'copyright_year': copyright_year,
        'authors': authors,
        'title': title,
        'has_main_definitions': has_main_definitions,
        'has_main_theorems': has_main_theorems,
        'has_main_statements': has_main_statements,
        'has_references': has_references,
        'has_examples': has_examples,
        'num_references': num_references,
        'main_theorems_text': main_theorems_text[:500],  # Truncate to 500 chars
        'main_definitions_text': main_definitions_text[:500],
        'references_text': references_text[:500],
        'docstring_length': len(docstring),
    }


def _empty_docstring_metadata() -> Dict[str, any]:
    """Return empty metadata dict."""
    return {
        'copyright_year': None,
        'authors': [],
        'title': '',
        'has_main_definitions': False,
        'has_main_theorems': False,
        'has_main_statements': False,
        'has_references': False,
        'has_examples': False,
        'num_references': 0,
        'main_theorems_text': '',
        'main_definitions_text': '',
        'references_text': '',
        'docstring_length': 0,
    }


def extract_named_declarations(lean_file: Path, limit: int = 20) -> Dict[str, List[str]]:
    """Extract names of theorems, lemmas, and definitions."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return {'theorems': [], 'lemmas': [], 'definitions': []}

    # Extract theorem/lemma/corollary names with type distinction
    theorems = []
    lemmas = []
    for match in THEOREM_RE.finditer(text):
        decl_type, name = match.groups()
        if decl_type == 'lemma':
            lemmas.append(name)
        else:  # theorem or corollary
            theorems.append(name)

    # Extract def/structure/class/inductive names
    definitions = [match.group(2) for match in DEFINITION_RE.finditer(text)]

    return {
        'theorems': theorems[:limit],
        'lemmas': lemmas[:limit],
        'definitions': definitions[:limit],
    }


def extract_namespace(lean_file: Path) -> Optional[str]:
    """Extract primary namespace from file."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return None

    # Find first namespace declaration
    match = NAMESPACE_RE.search(text)
    return match.group(1) if match else None


def count_attributes(lean_file: Path) -> Dict[str, int]:
    """Count Lean attributes like @[simp], @[to_additive], etc."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return {}

    # Extract all attributes
    attributes = {}
    for match in ATTRIBUTE_RE.finditer(text):
        attr_text = match.group(1)
        # Split by comma to handle multiple attributes in one @[...]
        for attr in attr_text.split(','):
            attr = attr.strip().split()[0]  # Get first word (attribute name)
            attributes[attr] = attributes.get(attr, 0) + 1

    return attributes


# ============================================================================
# AST Extraction Functions (for JSON symbolic representation)
# ============================================================================

def parse_theorem_signature(signature: str) -> Dict[str, any]:
    """
    Parse theorem/lemma/def signature into structured format.

    Args:
        signature: Signature string (e.g., "{m n : ℕ} (hmn : m ≠ n) : Coprime ...")

    Returns:
        Dict with 'params', 'constraints', 'return_type'
    """
    import re

    # Find the position of the last ':' that's not inside any brackets
    # This separates params from return type
    def find_return_type_colon(s: str) -> int:
        """Find the colon that separates params from return type."""
        depth = 0
        last_colon = -1
        for i, char in enumerate(s):
            if char in '{[(':
                depth += 1
            elif char in '}])':
                depth -= 1
            elif char == ':' and depth == 0:
                last_colon = i
        return last_colon

    colon_pos = find_return_type_colon(signature)

    if colon_pos == -1:
        # No colon found, entire thing is return type
        return {
            'params': [],
            'constraints': [],
            'return_type': signature.strip()
        }

    params_str = signature[:colon_pos].strip()
    return_type = signature[colon_pos + 1:].strip()

    # Parse parameters
    params = []
    constraints = []

    # Find implicit params {...}
    implicit_pattern = r'\{([^}]+)\}'
    for match in re.finditer(implicit_pattern, params_str):
        param_content = match.group(1)
        # Parse "name1 name2 : Type"
        if ':' in param_content:
            names_part, type_part = param_content.split(':', 1)
            names = [n.strip() for n in names_part.split()]
            type_str = type_part.strip()

            # Check if it's a typeclass constraint
            if names and names[0] and names[0][0].isupper():  # Typeclass names are capitalized
                constraints.append({'name': names[0], 'type': type_str})
            else:
                for name in names:
                    if name:  # Skip empty
                        params.append({'name': name, 'type': type_str, 'implicit': True})

    # Find explicit params (...)
    explicit_pattern = r'\(([^)]+)\)'
    for match in re.finditer(explicit_pattern, params_str):
        param_content = match.group(1)
        # Parse "name : Type" or "name1 name2 : Type"
        if ':' in param_content:
            names_part, type_part = param_content.split(':', 1)
            names = [n.strip() for n in names_part.split()]
            type_str = type_part.strip()

            for name in names:
                if name:  # Skip empty
                    params.append({'name': name, 'type': type_str, 'implicit': False})

    # Find typeclass constraints [...]
    constraint_pattern = r'\[([^\]]+)\]'
    for match in re.finditer(constraint_pattern, params_str):
        constraint_content = match.group(1)
        # Parse "Monoid M" or "Semigroup α"
        parts = constraint_content.split(maxsplit=1)
        if len(parts) >= 1:
            constraints.append({'name': parts[0], 'type': parts[1] if len(parts) > 1 else ''})

    return {
        'params': params,
        'constraints': constraints,
        'return_type': return_type
    }


def parse_proof_structure(proof_text: str) -> Dict[str, any]:
    """
    Parse proof body into structured format with tactics/terms.

    Args:
        proof_text: Proof text (after := or in theorem body)

    Returns:
        Dict with 'style', 'tactics', 'has_calc', etc.
    """
    proof_text = proof_text.strip()

    # Detect proof style
    has_by = proof_text.startswith('by') or '\nby ' in proof_text
    has_calc = 'calc ' in proof_text or proof_text.startswith('calc ')

    result = {
        'style': 'unknown',
        'has_calc': has_calc,
        'has_forward_reasoning': 'have ' in proof_text or 'obtain ' in proof_text,
        'has_induction': 'induction ' in proof_text,
    }

    if has_calc:
        result['style'] = 'calc'
        # Extract calc steps
        calc_steps = []
        import re
        # Match lines that start with _ or contain :=
        for line in proof_text.split('\n'):
            if line.strip().startswith('_') or ' := ' in line:
                calc_steps.append(line.strip())
        result['calc_steps'] = calc_steps
        return result

    if has_by:
        result['style'] = 'tactic'
        tactics = _extract_tactics(proof_text)
        result['tactics'] = tactics

        # Detect induction cases
        if result['has_induction']:
            induction_cases = _extract_induction_cases(proof_text)
            result['induction_cases'] = induction_cases

        return result

    # Term-mode proof
    result['style'] = 'term'
    result['term_proof'] = proof_text
    return result


def _extract_tactics(proof_text: str) -> List[Dict[str, any]]:
    """Extract individual tactics from proof."""
    import re

    tactics = []

    # Common tactic patterns
    tactic_names = [
        'intro', 'intros', 'apply', 'exact', 'refine', 'use',
        'simp', 'simpa', 'rw', 'rewrite', 'ring', 'ring_nf', 'field_simp',
        'omega', 'linarith', 'nlinarith', 'polyrith',
        'induction', 'cases', 'split', 'constructor',
        'have', 'obtain', 'suffices', 'show',
        'ext', 'funext', 'congr', 'gcongr',
        'rfl', 'trivial', 'contradiction',
        'by_cases', 'wlog', 'cutsat',
        # Additional tactics from mathlib analysis
        'symm', 'trans', 'refl', 'subst',  # Equality/symmetry
        'left', 'right', 'exfalso',  # Logic
        'unfold', 'decide', 'assumption',  # Basic
        'rcases', 'rintro', 'exists',  # Pattern matching
        'norm_num', 'norm_cast', 'positivity',  # Numeric
        'abel', 'group', 'module',  # Algebra
        'push_neg', 'contrapose', 'by_contra',  # Negation
    ]

    # Simple extraction: find tactic names and collect args until next tactic
    lines = proof_text.split('\n')
    for line in lines:
        line = line.strip()
        if not line or line.startswith('--'):
            continue

        for tactic_name in tactic_names:
            # Match tactic at word boundary
            pattern = r'\b' + re.escape(tactic_name) + r'\b(.*)$'
            match = re.search(pattern, line)
            if match:
                args_str = match.group(1).strip()
                # Extract arguments (simplified)
                args = _parse_tactic_args(args_str)
                tactics.append({'name': tactic_name, 'args': args})
                break  # Found tactic, move to next line

    return tactics


def _parse_tactic_args(args_str: str) -> List[str]:
    """Parse tactic arguments (simplified)."""
    if not args_str:
        return []

    # Remove common delimiters
    args_str = args_str.strip()
    if args_str.startswith('[') and ']' in args_str:
        # Extract from [...]
        import re
        match = re.search(r'\[(.*?)\]', args_str)
        if match:
            inner = match.group(1)
            return [a.strip() for a in inner.split(',') if a.strip()]

    # Split by whitespace for simple args
    return [a.strip() for a in args_str.split()[:3] if a.strip()]  # Limit to 3 args


def _extract_induction_cases(proof_text: str) -> List[str]:
    """Extract induction case names."""
    import re
    cases = []
    # Match | casename ... => (allowing pattern vars between case name and =>)
    pattern = r'\|\s*(\w+)[^|]*=>'
    for match in re.finditer(pattern, proof_text):
        cases.append(match.group(1))
    return cases


def extract_proof_dependencies(proof_text: str) -> List[str]:
    """
    Extract theorem/lemma names used in proof.

    Args:
        proof_text: Proof body text

    Returns:
        List of dependency names
    """
    import re

    dependencies = set()

    # Pattern: identifier with optional module path
    # Matches: mul_assoc, Nat.add_comm, fermatNumber, Mathlib.Data.List.basic, etc.
    # Start with lowercase or uppercase (for module names), allow dots
    pattern = r'(?<![a-zA-Z0-9_])([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z0-9_]+)*)(?![a-zA-Z0-9_])'

    # Skip keywords
    keywords = {
        'by', 'have', 'show', 'from', 'fun', 'let', 'in', 'do',
        'if', 'then', 'else', 'match', 'with', 'end',
        'true', 'false', 'sorry', 'admit',
        'rw', 'simp', 'apply', 'exact', 'intro',  # Add common tactics
    }

    for match in re.finditer(pattern, proof_text):
        name = match.group(1)
        if name not in keywords and not name.startswith('_'):
            dependencies.add(name)

    return sorted(list(dependencies))


def extract_attributes(text: str, pos: int) -> List[str]:
    """
    Extract attributes before a declaration (e.g., @[simp], @[to_additive]).

    Args:
        text: Full file text
        pos: Position where declaration starts

    Returns:
        List of attribute names
    """
    import re

    attributes = []

    # Look backwards from pos to find attributes
    # Attributes appear as @[attr1, attr2] or @[attr]
    lines_before = text[:pos].split('\n')[-5:]  # Check last 5 lines

    for line in reversed(lines_before):
        line = line.strip()
        if not line or line.startswith('--'):
            continue

        # Check if line contains a declaration keyword (theorem, def, etc.)
        # If so, this is a previous declaration, stop searching
        if any(kw in line for kw in ['theorem', 'lemma', 'def ', 'instance', 'axiom', 'class ', 'structure', 'inductive']):
            break

        # Match @[...] patterns only on attribute-only lines
        if line.startswith('@['):
            attr_pattern = r'@\[([^\]]+)\]'
            matches = re.findall(attr_pattern, line)
            for match in matches:
                # Split by comma for multiple attributes
                attrs = [a.strip() for a in match.split(',')]
                attributes.extend(attrs)
        elif not line.startswith('@'):
            # Hit non-attribute content, stop
            break

    return list(reversed(attributes))  # Return in original order


def extract_declarations_ast(
    lean_file: Path,
    limit: Optional[int] = None
) -> List[Dict[str, any]]:
    """
    Extract declarations from Lean file as JSON AST.

    Args:
        lean_file: Path to .lean file
        limit: Optional limit on number of declarations

    Returns:
        List of declaration dicts with structure:
        {
            'type': 'theorem' | 'lemma' | 'def' | 'instance',
            'name': str,
            'signature': {...},
            'proof': {...},  # optional
            'dependencies': [...],  # optional
        }
    """
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return []

    import re

    # Collect declarations with (position, decl) tuples for proper ordering
    declarations_with_pos = []

    # Pattern for theorems/lemmas with optional inline attributes
    # Matches: @[simp] theorem name : type := proof
    # Also matches: theorem name : type (no proof)
    # Key: Match params and return type carefully, allowing = in return type
    theorem_pattern = r'(?:@\[([^\]]+)\]\s*)?(theorem|lemma|corollary)\s+(\w+)\s*([^:]*?):\s*(.+?)\s*(?::=\s*(.+?))?(?=\s*(?:\n|$))'

    for match in re.finditer(theorem_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)  # Optional inline attributes
        decl_type = match.group(2)
        name = match.group(3)
        params_before_colon = match.group(4).strip()
        return_type = match.group(5).strip()
        proof_body = match.group(6) if match.group(6) else None

        # Combine params
        full_sig = f"{params_before_colon} : {return_type}" if params_before_colon else return_type

        signature = parse_theorem_signature(full_sig)

        # Extract attributes (both inline and multi-line)
        attrs = []
        if inline_attrs:
            # Parse inline attributes
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        # Also check for multi-line attributes
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        decl = {
            'type': decl_type,
            'name': name,
            'signature': signature,
        }

        if attrs:
            decl['attributes'] = attrs

        if proof_body:
            proof_struct = parse_proof_structure(proof_body)
            decl['proof'] = proof_struct

            # Extract dependencies
            deps = extract_proof_dependencies(proof_body)
            if deps:
                decl['dependencies'] = deps[:20]  # Limit to 20

        declarations_with_pos.append((match.start(), decl))

    # Pattern for definitions with optional inline attributes
    # Matches: @[instance] def name (params) : type := body
    # Key: Definitions always have :=, match signature until :=
    def_pattern = r'(?:@\[([^\]]+)\]\s*)?def\s+(\w+)\s+(.*?)\s*:=\s*(.+?)(?=\s*(?:\n|$))'

    for match in re.finditer(def_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)  # Optional inline attributes
        name = match.group(2)
        full_sig = match.group(3).strip()
        body = match.group(4).strip()

        signature = parse_theorem_signature(full_sig)

        # Extract attributes (both inline and multi-line)
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        decl = {
            'type': 'def',
            'name': name,
            'signature': signature,
            'body': body[:200],  # Truncate body
        }

        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Pattern for instances with optional inline attributes
    instance_pattern = r'(?:@\[([^\]]+)\]\s*)?instance\s+(?:(\w+)\s+:)?\s*(.+?)(?:where|:=)'

    for match in re.finditer(instance_pattern, text, re.MULTILINE):
        inline_attrs = match.group(1)  # Optional inline attributes
        name = match.group(2) if match.group(2) else '<anonymous>'
        signature_str = match.group(3).strip()

        # Extract attributes (both inline and multi-line)
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        decl = {
            'type': 'instance',
            'name': name,
            'signature': parse_theorem_signature(signature_str),
        }

        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Pattern for structures with optional inline attributes
    # Matches: structure Name (params) : Type extends Base where fields
    # Also matches: @[ext] structure Name ...
    # Allows qualified names like Foo.Bar
    # Flexible handling of multiline signatures with : and extends
    # Ends at: double newline, doc comment, or next declaration
    structure_pattern = r'(?:@\[([^\]]+)\]\s*)?structure\s+([\w.]+)(.*?)where\s*(.*?)(?=\n\n|\n/--|\n(?![ \t])(?:structure|class|def|theorem|lemma|instance|axiom|end)|\Z)'

    for match in re.finditer(structure_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)
        name = match.group(2)
        header = match.group(3)  # Everything between name and 'where'
        fields_block = match.group(4).strip() if match.group(4) else ""

        # Parse header to extract type params, type annotation, and extends clause
        type_params = ""
        type_annot = ""
        extends_clause = ""

        # Check for extends clause (must come before 'where')
        extends_match = re.search(r'extends\s+([^\n]+?)(?=\s*$)', header.strip())
        if extends_match:
            extends_clause = extends_match.group(1).strip()
            header = header[:extends_match.start()]  # Remove extends part

        # Check for type annotation (after : and before extends)
        colon_match = re.search(r':\s*(.+?)$', header.strip(), re.DOTALL)
        if colon_match:
            type_annot = colon_match.group(1).strip()
            header = header[:colon_match.start()]  # Remove type annotation

        # What remains is type parameters
        type_params = header.strip()

        # Extract attributes
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        # Parse fields
        fields = []
        for line in fields_block.split('\n'):
            line = line.strip()
            if not line or line.startswith('--'):
                continue
            # Match: fieldName : Type
            field_match = re.match(r'(\w+)\s*:\s*(.+?)(?:$|--)', line)
            if field_match:
                fields.append({
                    'name': field_match.group(1),
                    'type': field_match.group(2).strip()
                })

        decl = {
            'type': 'structure',
            'name': name,
            'fields': fields,
        }

        if type_params:
            decl['type_params'] = type_params
        if extends_clause:
            # Parse extends: "Foo α, Bar β" → ["Foo", "Bar"]
            extends_list = [e.split()[0] for e in extends_clause.split(',')]
            decl['extends'] = [e.strip() for e in extends_list if e.strip()]
        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Pattern for classes (typeclasses) with optional inline attributes
    # Matches: class Name (params) : Type extends Base where methods
    # Also matches: @[class] class Name ...
    # Allows qualified names like AddAction.IsMinimal
    # Flexible handling of multiline signatures with : and extends
    # Ends at: double newline, doc comment, or next declaration
    class_pattern = r'(?:@\[([^\]]+)\]\s*)?class\s+([\w.]+)(.*?)where\s*(.*?)(?=\n\n|\n/--|\n(?![ \t])(?:structure|class|def|theorem|lemma|instance|axiom|end)|\Z)'

    for match in re.finditer(class_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)
        name = match.group(2)
        header = match.group(3)  # Everything between name and 'where'
        fields_block = match.group(4).strip() if match.group(4) else ""

        # Parse header to extract type params, type annotation, and extends clause
        type_params = ""
        type_annot = ""
        extends_clause = ""

        # Check for extends clause (must come before 'where')
        extends_match = re.search(r'extends\s+([^\n]+?)(?=\s*$)', header.strip())
        if extends_match:
            extends_clause = extends_match.group(1).strip()
            header = header[:extends_match.start()]  # Remove extends part

        # Check for type annotation (after : and before extends)
        colon_match = re.search(r':\s*(.+?)$', header.strip(), re.DOTALL)
        if colon_match:
            type_annot = colon_match.group(1).strip()
            header = header[:colon_match.start()]  # Remove type annotation

        # What remains is type parameters
        type_params = header.strip()

        # Extract attributes
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        # Parse fields (methods)
        fields = []
        for line in fields_block.split('\n'):
            line = line.strip()
            if not line or line.startswith('--'):
                continue
            # Match: methodName : Type
            field_match = re.match(r'(\w+)\s*:\s*(.+?)(?:$|--)', line)
            if field_match:
                fields.append({
                    'name': field_match.group(1),
                    'type': field_match.group(2).strip()
                })

        decl = {
            'type': 'class',
            'name': name,
            'fields': fields,
        }

        if type_params:
            decl['type_params'] = type_params
        if extends_clause:
            # Parse extends: "Foo α, Bar β" → ["Foo", "Bar"]
            extends_list = [e.split()[0] for e in extends_clause.split(',')]
            decl['extends'] = [e.strip() for e in extends_list if e.strip()]
        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Pattern for inductive types with optional inline attributes
    # Matches: inductive Name (params) where | constructors deriving Classes
    # Allows qualified names
    # Handles optional deriving clause after constructors
    inductive_pattern = r'(?:@\[([^\]]+)\]\s*)?inductive\s+([\w.]+)(.*?)where\s*(.*?)(?:deriving\s+([^\n]+?))?\s*(?=\n\n|\n/--|\n(?![ \t])(?:inductive|structure|class|def|theorem|lemma|instance|axiom|end)|\Z)'

    for match in re.finditer(inductive_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)
        name = match.group(2)
        type_params = match.group(3).strip() if match.group(3) else ""
        constructors_block = match.group(4).strip() if match.group(4) else ""
        deriving_clause = match.group(5).strip() if match.group(5) else ""

        # Extract attributes
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        # Parse constructors - each line starting with |
        constructors = []
        for line in constructors_block.split('\n'):
            line = line.strip()
            if not line or not line.startswith('|'):
                continue
            # Remove leading | and parse: constructor_name (args)* : Type
            line = line[1:].strip()  # Remove |

            # Get constructor name (first word)
            parts = line.split(None, 1)
            if not parts:
                continue
            ctor_name = parts[0]

            # Find the last colon for the return type (handles multiple param groups)
            colon_idx = line.rfind(':')
            if colon_idx > 0:
                ctor_type = line[colon_idx+1:].strip()
                # Remove trailing comment if any
                if '--' in ctor_type:
                    ctor_type = ctor_type.split('--')[0].strip()

                constructors.append({
                    'name': ctor_name,
                    'type': ctor_type
                })

        decl = {
            'type': 'inductive',
            'name': name,
            'constructors': constructors,
        }

        if type_params:
            decl['type_params'] = type_params
        if deriving_clause:
            # Parse deriving: "Repr, DecidableEq" → ["Repr", "DecidableEq"]
            deriving_list = [d.strip() for d in deriving_clause.split(',')]
            decl['deriving'] = [d for d in deriving_list if d]
        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Pattern for axioms (postulates) - rare construct
    # Matches: axiom name (params) : Type
    axiom_pattern = r'(?:@\[([^\]]+)\]\s*)?axiom\s+(\w+)\s*([^:]*?):\s*(.+?)(?=\s*(?:\n|$))'

    for match in re.finditer(axiom_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)
        name = match.group(2)
        params_str = match.group(3).strip() if match.group(3) else ""
        return_type = match.group(4).strip() if match.group(4) else ""

        # Extract attributes
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        decl = {
            'type': 'axiom',
            'name': name,
            'return_type': return_type,
        }

        if params_str:
            params = parse_theorem_signature(params_str + ' : ' + return_type).get('parameters', [])
            if params:
                decl['parameters'] = params
        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Pattern for abbreviations - type aliases
    # Matches: abbrev name (params) : Type := body
    abbrev_pattern = r'(?:@\[([^\]]+)\]\s*)?abbrev\s+(\w+)\s*([^:]*?):\s*(.+?):=\s*(.+?)(?=\s*(?:\n|$))'

    for match in re.finditer(abbrev_pattern, text, re.DOTALL | re.MULTILINE):
        inline_attrs = match.group(1)
        name = match.group(2)
        params_str = match.group(3).strip() if match.group(3) else ""
        return_type = match.group(4).strip() if match.group(4) else ""
        body = match.group(5).strip() if match.group(5) else ""

        # Extract attributes
        attrs = []
        if inline_attrs:
            inline_list = [a.strip() for a in inline_attrs.split(',')]
            attrs.extend(inline_list)
        multiline_attrs = extract_attributes(text, match.start())
        attrs.extend(multiline_attrs)

        decl = {
            'type': 'abbrev',
            'name': name,
            'return_type': return_type,
            'body': body[:200],  # Truncate like def
        }

        if params_str:
            params = parse_theorem_signature(params_str + ' : ' + return_type).get('parameters', [])
            if params:
                decl['parameters'] = params
        if attrs:
            decl['attributes'] = attrs

        declarations_with_pos.append((match.start(), decl))

    # Sort by position in file
    declarations_with_pos.sort(key=lambda x: x[0])

    # Extract declarations and apply limit
    declarations = [decl for pos, decl in declarations_with_pos]
    if limit:
        declarations = declarations[:limit]

    return declarations


def extract_open_statements(lean_file: Path) -> Dict[str, List[str]]:
    """Extract open namespace statements."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return {'namespaces': [], 'scoped': []}

    import re

    namespaces = []
    scoped = []

    # Match: open Function
    pattern = r'^open\s+([\w\s\.]+)$'
    for match in re.finditer(pattern, text, re.MULTILINE):
        names = match.group(1).split()
        namespaces.extend(names)

    # Match: open scoped BigOperators
    scoped_pattern = r'^open\s+scoped\s+([\w\s\.]+)$'
    for match in re.finditer(scoped_pattern, text, re.MULTILINE):
        names = match.group(1).split()
        scoped.extend(names)

    return {
        'namespaces': list(set(namespaces)),
        'scoped': list(set(scoped))
    }


def extract_sections(lean_file: Path) -> List[str]:
    """Extract section names from file."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return []

    import re

    sections = []
    pattern = r'^section\s+(\w+)'
    for match in re.finditer(pattern, text, re.MULTILINE):
        sections.append(match.group(1))

    return sections


def extract_variable_typeclasses(lean_file: Path) -> Dict[str, int]:
    """Extract typeclasses from variable declarations."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return {}

    import re

    typeclasses = {}

    # Match: variable [Monoid M]
    pattern = r'variable\s+\[([^\]]+)\]'
    for match in re.finditer(pattern, text, re.MULTILINE):
        constraint = match.group(1).strip()
        # Extract typeclass name (first word)
        parts = constraint.split(maxsplit=1)
        if parts:
            tc_name = parts[0]
            typeclasses[tc_name] = typeclasses.get(tc_name, 0) + 1

    return typeclasses


def lean_module_from_path(file_path: Path, root_path: Path) -> str:
    """Convert file path to Lean module name."""
    rel_path = file_path.relative_to(root_path)
    parts = rel_path.with_suffix('').parts
    return '.'.join(['Mathlib'] + list(parts))


def determine_cluster(file_path: Path, mathlib_root: Path) -> str:
    """Determine domain cluster from top-level folder."""
    parts = file_path.relative_to(mathlib_root).parts
    return parts[0] if parts else "unknown"


def extract_imports(lean_file: Path) -> List[str]:
    """Extract import statements from a Lean file."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return []
    return IMPORT_RE.findall(text)


def extract_declarations(lean_file: Path) -> Dict[str, int]:
    """Count theorems, lemmas, and definitions in a Lean file."""
    try:
        text = lean_file.read_text(encoding='utf-8')
    except Exception:
        return {'theorems': 0, 'definitions': 0, 'lines': 0}

    theorems = len(THEOREM_RE.findall(text))
    definitions = len(DEFINITION_RE.findall(text))
    lines = len(text.splitlines())

    return {
        'theorems': theorems,
        'definitions': definitions,
        'lines': lines,
    }


def compute_graph_metrics(edges: List[Tuple[str, str]], nodes: Set[str]) -> Dict[str, Dict[str, float]]:
    """Compute graph metrics using networkx."""
    try:
        import networkx as nx
    except ImportError:
        print("  Warning: networkx not available, skipping graph metrics")
        return {node: {'pagerank': 0.0, 'in_degree': 0, 'out_degree': 0} for node in nodes}

    G = nx.DiGraph()
    G.add_nodes_from(nodes)
    G.add_edges_from(edges)

    # Compute PageRank (importance in dependency graph)
    pagerank = nx.pagerank(G, alpha=0.85)

    # Compute centrality metrics
    metrics = {}
    for node in nodes:
        metrics[node] = {
            'pagerank': pagerank.get(node, 0.0),
            'in_degree': G.in_degree(node),
            'out_degree': G.out_degree(node),
        }

    return metrics


def mathlib4(
    ctx: RecipeContext,
    mathlib_root: str = "./recipes_raw_data/mathlib4/Mathlib",
    compute_metrics: bool = True,
    limit: Optional[int] = None,
) -> RecipeOutput:
    """
    Create Mathlib4 dependency graph dataset.

    Extracts import relationships, domain clusters, and graph metrics from
    Lean 4's mathlib. Creates two datasets:
    1. Main: File nodes with metadata and graph metrics
    2. Edges: Import dependencies (different schema - valid subdataset!)

    Args:
        ctx: Recipe context
        mathlib_root: Path to Mathlib/ folder (default: ./recipes_raw_data/mathlib4/Mathlib)
        compute_metrics: If True, compute PageRank and centrality metrics
        limit: Optional limit on number of files (for testing)

    Returns:
        RecipeOutput with main nodes dataset and edges subdataset

    Main dataset columns:
        Basic metadata:
        - module_name: str - Full module name (e.g., Mathlib.Algebra.Group.Basic)
        - file_path: str - Absolute path to .lean file
        - cluster: str - Top-level domain (Algebra, Topology, Analysis, etc.)
        - namespace: str - Primary namespace (e.g., Nat, List, Function)

        Code metrics:
        - num_imports: int - Number of modules imported
        - num_theorems: int - Count of theorems/lemmas
        - num_definitions: int - Count of definitions/structures
        - lines_of_code: int - Lines in file
        - file_size_bytes: int - File size
        - num_simp_lemmas: int - Count of @[simp] attributes

        Graph metrics:
        - pagerank: float - PageRank score (importance in graph)
        - in_degree: int - Number of modules that import this
        - out_degree: int - Number of modules this imports

        Documentation:
        - copyright_year: str - Year of copyright
        - authors_json: str - List of authors (JSON)
        - title: str - File title from docstring
        - has_main_theorems: bool - Has "Main theorems" section
        - has_references: bool - Has "References" section
        - num_references: int - Count of references
        - docstring_length: int - Length of main docstring
        - main_theorems_text: str - Text of main theorems section
        - references_text: str - Text of references section

        Named declarations (JSON arrays, up to 20):
        - theorem_names_json: str - List of theorem names
        - lemma_names_json: str - List of lemma names
        - definition_names_json: str - List of definition names

        Full AST extraction (NEW!):
        - declarations_json: str - Complete AST for ALL declarations (JSON array)
          Includes 10 types: theorem, lemma, corollary, def, instance,
          structure, class, inductive, axiom, abbrev
          Each declaration has: type, name, signatures, proof metadata,
          dependencies, attributes, fields/constructors, etc.

        Enhanced declaration counts:
        - num_structures: int - Count of structure declarations
        - num_classes: int - Count of class declarations
        - num_inductives: int - Count of inductive types
        - num_instances: int - Count of instance declarations
        - num_axioms: int - Count of axioms
        - num_abbrevs: int - Count of abbreviations
        - total_declarations: int - Total count of all declarations

    Edges subdataset columns (different schema!):
        - source_module: str - Source module name
        - target_module: str - Target module name (imported by source)

    Examples:
        >>> import warpdata as wd
        >>>
        >>> # Create full graph
        >>> result = wd.run_recipe(
        ...     "mathlib4",
        ...     "warpdata://math/mathlib4",
        ...     with_materialize=True
        ... )
        >>>
        >>> # Load nodes
        >>> nodes = wd.load("warpdata://math/mathlib4", as_format="pandas")
        >>> print(f"Modules: {len(nodes)}, Clusters: {nodes['cluster'].nunique()}")
        >>>
        >>> # Load edges (different schema - valid subdataset!)
        >>> edges = wd.load("warpdata://math/mathlib4-edges", as_format="pandas")
        >>> print(f"Import edges: {len(edges)}")
        >>>
        >>> # Find most important modules (high PageRank)
        >>> top_modules = nodes.nlargest(10, 'pagerank')[['module_name', 'cluster', 'pagerank']]
        >>>
        >>> # Analyze by domain
        >>> domain_stats = nodes.groupby('cluster').agg({
        ...     'num_theorems': 'sum',
        ...     'num_definitions': 'sum',
        ...     'pagerank': 'mean'
        ... })
    """
    root = Path(mathlib_root).resolve()

    if not root.exists():
        raise FileNotFoundError(f"Mathlib root not found: {root}")

    print(f"📦 Scanning mathlib4 from {root}...")

    # 1. Find all Lean files
    all_files = sorted([f for f in root.rglob("*.lean") if f.is_file()])

    if limit:
        all_files = all_files[:limit]
        print(f"  Limiting to {limit} files for testing")

    print(f"  Found {len(all_files)} .lean files")

    # 2. Build module mapping and extract metadata
    module_to_file: Dict[str, Path] = {}
    file_records = []
    all_edges = []

    print(f"\n📊 Extracting file metadata and imports...")

    for file_path in tqdm(all_files, desc="Processing files", unit="file"):
        module = lean_module_from_path(file_path, root)
        module_to_file[module] = file_path

        # Extract imports
        imports = extract_imports(file_path)

        # Extract declarations (simple counts)
        decl_counts = extract_declarations(file_path)

        # Extract enhanced metadata
        doc_metadata = extract_docstring_metadata(file_path)
        named_decls = extract_named_declarations(file_path, limit=20)
        namespace = extract_namespace(file_path)
        attributes = count_attributes(file_path)

        # Extract full AST declarations (with all metadata)
        ast_decls = extract_declarations_ast(file_path, limit=None)  # No limit for full extraction

        # Compute counts by declaration type
        ast_counts = {}
        for decl_type in ['theorem', 'lemma', 'corollary', 'def', 'instance',
                          'structure', 'class', 'inductive', 'axiom', 'abbrev']:
            ast_counts[decl_type] = sum(1 for d in ast_decls if d['type'] == decl_type)

        # Build file record
        file_records.append({
            'module_name': module,
            'file_path': str(file_path),
            'cluster': determine_cluster(file_path, root),
            'num_imports': len(imports),
            'num_theorems': decl_counts['theorems'],
            'num_definitions': decl_counts['definitions'],
            'lines_of_code': decl_counts['lines'],
            'file_size_bytes': file_path.stat().st_size,
            # Enhanced metadata
            'copyright_year': doc_metadata['copyright_year'],
            'authors_json': json.dumps(doc_metadata['authors']),
            'title': doc_metadata['title'],
            'namespace': namespace,
            'has_main_definitions': doc_metadata['has_main_definitions'],
            'has_main_theorems': doc_metadata['has_main_theorems'],
            'has_main_statements': doc_metadata['has_main_statements'],
            'has_references': doc_metadata['has_references'],
            'has_examples': doc_metadata['has_examples'],
            'num_references': doc_metadata['num_references'],
            'main_theorems_text': doc_metadata['main_theorems_text'],
            'main_definitions_text': doc_metadata['main_definitions_text'],
            'references_text': doc_metadata['references_text'],
            'docstring_length': doc_metadata['docstring_length'],
            'theorem_names_json': json.dumps(named_decls['theorems']),
            'lemma_names_json': json.dumps(named_decls['lemmas']),
            'definition_names_json': json.dumps(named_decls['definitions']),
            'num_simp_lemmas': attributes.get('simp', 0),
            'num_to_additive': attributes.get('to_additive', 0),
            # Full AST extraction (NEW!)
            'declarations_json': json.dumps(ast_decls),
            # Enhanced declaration counts
            'num_structures': ast_counts['structure'],
            'num_classes': ast_counts['class'],
            'num_inductives': ast_counts['inductive'],
            'num_instances': ast_counts['instance'],
            'num_axioms': ast_counts['axiom'],
            'num_abbrevs': ast_counts['abbrev'],
            'total_declarations': len(ast_decls),
        })

        # Build edges
        for imp in imports:
            # Normalize import to full module name
            full_imp = f"Mathlib.{imp}" if not imp.startswith("Mathlib.") else imp

            # Only add edge if target exists in our file set
            if full_imp in module_to_file:
                all_edges.append({
                    'source_module': module,
                    'target_module': full_imp,
                })

    print(f"  Extracted {len(file_records)} file nodes")
    print(f"  Extracted {len(all_edges)} import edges")

    # 3. Compute graph metrics
    if compute_metrics and file_records:
        print(f"\n🔬 Computing graph metrics (PageRank, centrality)...")

        nodes = {rec['module_name'] for rec in file_records}
        edges_tuples = [(e['source_module'], e['target_module']) for e in all_edges]

        metrics = compute_graph_metrics(edges_tuples, nodes)

        # Add metrics to file records
        for rec in file_records:
            module = rec['module_name']
            rec.update(metrics.get(module, {
                'pagerank': 0.0,
                'in_degree': 0,
                'out_degree': 0,
            }))

        print(f"  ✓ Computed metrics for {len(metrics)} nodes")

    # 4. Create DataFrames
    nodes_df = pd.DataFrame(file_records)
    edges_df = pd.DataFrame(all_edges)

    # 5. Save datasets
    nodes_output = ctx.work_dir / "mathlib4_nodes.parquet"
    edges_output = ctx.work_dir / "mathlib4_edges.parquet"

    nodes_df.to_parquet(nodes_output, index=False)
    edges_df.to_parquet(edges_output, index=False)

    print(f"\n💾 Saved datasets:")
    print(f"  Nodes: {nodes_output}")
    print(f"  Edges: {edges_output}")

    # 6. Compute statistics
    print(f"\n{'='*60}")
    print("Dataset Statistics")
    print(f"{'='*60}")
    print(f"  Total modules: {len(nodes_df):,}")
    print(f"  Total edges: {len(edges_df):,}")
    print(f"  Clusters: {nodes_df['cluster'].nunique()}")

    print(f"\n  Top clusters by module count:")
    cluster_counts = nodes_df['cluster'].value_counts().head(10)
    for cluster, count in cluster_counts.items():
        print(f"    {cluster:30s}: {count:>6,} modules")

    print(f"\n  Content statistics:")
    print(f"    Total theorems: {nodes_df['num_theorems'].sum():,}")
    print(f"    Total definitions: {nodes_df['num_definitions'].sum():,}")
    print(f"    Total lines of code: {nodes_df['lines_of_code'].sum():,}")

    if compute_metrics:
        print(f"\n  Top 5 modules by PageRank:")
        top_pr = nodes_df.nlargest(5, 'pagerank')[['module_name', 'cluster', 'pagerank']]
        for _, row in top_pr.iterrows():
            print(f"    {row['module_name']:50s} ({row['cluster']:15s}) PR={row['pagerank']:.6f}")

    # 7. Create subdataset for edges (different schema!)
    subdatasets = {
        'edges': SubDataset(
            name='edges',
            files=[edges_output],
            description='Import dependency edges (source → target)',
            metadata={'num_edges': len(edges_df)}
        )
    }

    # 8. Build metadata
    metadata = {
        'total_modules': len(nodes_df),
        'total_edges': len(edges_df),
        'num_clusters': int(nodes_df['cluster'].nunique()),
        'total_theorems': int(nodes_df['num_theorems'].sum()),
        'total_definitions': int(nodes_df['num_definitions'].sum()),
        'total_lines': int(nodes_df['lines_of_code'].sum()),
        'clusters': cluster_counts.to_dict(),
        'source': str(mathlib_root),
        'columns': {
            'module_name': {
                'type': 'text',
                'description': 'Full Lean module name (e.g., Mathlib.Algebra.Group.Basic)'
            },
            'cluster': {
                'type': 'categorical',
                'description': 'Top-level mathematical domain (Algebra, Topology, etc.)'
            },
            'pagerank': {
                'type': 'numeric',
                'description': 'PageRank score - importance in dependency graph'
            },
            'in_degree': {
                'type': 'numeric',
                'description': 'Number of modules that import this module'
            },
            'out_degree': {
                'type': 'numeric',
                'description': 'Number of modules this module imports'
            },
            'copyright_year': {
                'type': 'text',
                'description': 'Year of copyright from file header'
            },
            'authors_json': {
                'type': 'json',
                'description': 'List of authors from file header (JSON array)'
            },
            'title': {
                'type': 'text',
                'description': 'Title from docstring (first heading)'
            },
            'namespace': {
                'type': 'categorical',
                'description': 'Primary namespace (e.g., Nat, List, Function)'
            },
            'has_main_theorems': {
                'type': 'boolean',
                'description': 'Has "Main theorems" section in docstring'
            },
            'has_references': {
                'type': 'boolean',
                'description': 'Has "References" section with citations'
            },
            'num_references': {
                'type': 'numeric',
                'description': 'Count of references in References section'
            },
            'theorem_names_json': {
                'type': 'json',
                'description': 'List of theorem names (JSON array, up to 20)'
            },
            'lemma_names_json': {
                'type': 'json',
                'description': 'List of lemma names (JSON array, up to 20)'
            },
            'definition_names_json': {
                'type': 'json',
                'description': 'List of definition names (JSON array, up to 20)'
            },
            'num_simp_lemmas': {
                'type': 'numeric',
                'description': 'Count of @[simp] attributes (simplifier rules)'
            },
            'docstring_length': {
                'type': 'numeric',
                'description': 'Length of main docstring in characters'
            }
        }
    }

    # Track raw data for backup/provenance
    raw_data_sources = []
    if root.exists():
        raw_data_sources.append(root.parent)  # Track mathlib4 root directory

    print(f"\n{'='*60}")
    print("Recipe complete!")
    print(f"{'='*60}")
    print(f"  Main dataset: {len(nodes_df):,} modules")
    print(f"  Edges subdataset: {len(edges_df):,} dependencies")

    return RecipeOutput(
        main=[nodes_output],
        subdatasets=subdatasets,
        metadata=metadata,
        raw_data=raw_data_sources,
    )
