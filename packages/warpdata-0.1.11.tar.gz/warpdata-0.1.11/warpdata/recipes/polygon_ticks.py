"""
Polygon Ticks dataset recipe.

Fetches tick-level data: trades, quotes, NBBO (National Best Bid/Offer).
Highest granularity data for market microstructure analysis.

Source: Polygon.io Trades & Quotes API
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def polygon_ticks(
    ctx: RecipeContext,
    tickers: List[str],
    date: str,
    *,
    data_types: Optional[List[str]] = None,
    limit: int = 50000,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_ticks",
) -> RecipeOutput:
    """
    Create Polygon Ticks dataset with trade/quote tick data.

    Downloads tick-level trades, quotes, and NBBO data.

    Args:
        ctx: Recipe context
        tickers: List of tickers to fetch (e.g., ["SPY", "QQQ"])
        date: Date for tick data (YYYY-MM-DD)
        data_types: List of data types to fetch:
            - "trades": Individual trades with price, size, conditions
            - "quotes": Quote updates with bid/ask
            - "nbbo": National Best Bid/Offer updates
            If None, fetches all types
        limit: Maximum number of ticks per ticker (default: 50000)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with tick data per ticker and data type

    Examples:
        >>> import warpdata as wd
        >>> # Fetch trades for SPY
        >>> result = wd.run_recipe(
        ...     "polygon_ticks",
        ...     "warpdata://ticks/spy-trades-2025-01-17",
        ...     tickers=["SPY"],
        ...     date="2025-01-17",
        ...     data_types=["trades"],
        ...     with_materialize=True
        ... )
        >>> # Fetch all tick types
        >>> result = wd.run_recipe(
        ...     "polygon_ticks",
        ...     "warpdata://ticks/spy-all-2025-01-17",
        ...     tickers=["SPY"],
        ...     date="2025-01-17",
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    if not tickers:
        raise ValueError("Must specify at least one ticker")

    # Default to all data types if not specified
    if data_types is None:
        data_types = ["trades", "quotes", "nbbo"]

    print(f"📊 Fetching Polygon Tick Data for {date}")
    print(f"   Tickers: {', '.join(tickers)}")
    print(f"   Data Types: {', '.join(data_types)}")
    print(f"   Limit: {limit:,} ticks per ticker")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    subdatasets = {}
    metadata = {
        "tickers": tickers,
        "date": date,
        "data_types": data_types,
        "limit": limit,
        "source": "Polygon.io Trades & Quotes API",
    }

    # Process each data type
    for data_type in data_types:
        print(f"\n📈 Processing {data_type}...")

        type_dir = raw_dir / data_type / date
        type_dir.mkdir(parents=True, exist_ok=True)

        all_records = []

        # Fetch data for each ticker
        for ticker in tickers:
            print(f"  Fetching {ticker} {data_type}...")
            json_file = type_dir / f"{ticker.lower()}.json"

            try:
                # Build timestamp filters for the day
                import datetime as dt
                day = dt.datetime.fromisoformat(date).date()
                timestamp_gte = int(dt.datetime.combine(day, dt.time.min).timestamp() * 1000)
                timestamp_lte = int(dt.datetime.combine(day, dt.time.max).timestamp() * 1000)

                # Call appropriate ETL method
                if data_type == "trades":
                    result = etl.fetch_trades(
                        ticker=ticker,
                        limit=limit,
                        timestamp_gte=timestamp_gte,
                        timestamp_lte=timestamp_lte,
                        out=str(json_file)
                    )
                elif data_type == "quotes":
                    result = etl.fetch_quotes(
                        ticker=ticker,
                        limit=limit,
                        timestamp_gte=timestamp_gte,
                        timestamp_lte=timestamp_lte,
                        out=str(json_file)
                    )
                elif data_type == "nbbo":
                    result = etl.fetch_nbbo(
                        ticker=ticker,
                        limit=limit,
                        timestamp_gte=timestamp_gte,
                        timestamp_lte=timestamp_lte,
                        out=str(json_file)
                    )
                else:
                    print(f"    ⚠️  Unknown data type: {data_type}")
                    continue

                count = result.get('count', 0)
                print(f"    ✓ {count:,} ticks")

            except Exception as e:
                print(f"    ⚠️  Error: {e}")
                continue

            # Load and process
            if json_file.exists():
                try:
                    with open(json_file) as f:
                        data = json.load(f)

                    # Handle different response structures
                    results = []
                    if isinstance(data, dict) and 'results' in data:
                        results = data['results']
                    elif isinstance(data, list):
                        results = data

                    # Add ticker and date to each record
                    for record in results:
                        if isinstance(record, dict):
                            record['ticker'] = ticker
                            record['date'] = date

                            # Convert conditions to string if present
                            if 'conditions' in record and isinstance(record['conditions'], list):
                                record['conditions_str'] = ','.join(map(str, record['conditions']))

                            all_records.append(record)

                except Exception as e:
                    print(f"    ⚠️  Failed to parse {json_file}: {e}")

        # Save if we have data
        if all_records:
            print(f"\n  Total ticks for {data_type}: {len(all_records):,}")

            # Convert to DataFrame
            df = pd.DataFrame(all_records)

            # Convert timestamp columns to datetime
            timestamp_cols = ['timestamp', 'participant_timestamp', 'sip_timestamp', 't']
            for col in timestamp_cols:
                if col in df.columns:
                    # Handle both millisecond and nanosecond timestamps
                    try:
                        df[f'{col}_dt'] = pd.to_datetime(df[col], unit='ns', errors='coerce')
                    except:
                        try:
                            df[f'{col}_dt'] = pd.to_datetime(df[col], unit='ms', errors='coerce')
                        except:
                            pass

            # Rename common Polygon shorthand columns
            column_mapping = {
                'p': 'price',
                's': 'size',
                'x': 'exchange',
                'c': 'conditions',
                't': 'timestamp_ns',
                # For quotes
                'ap': 'ask_price',
                'as': 'ask_size',
                'ax': 'ask_exchange',
                'bp': 'bid_price',
                'bs': 'bid_size',
                'bx': 'bid_exchange',
            }

            df = df.rename(columns={k: v for k, v in column_mapping.items() if k in df.columns})

            # Save to parquet
            output_file = ctx.work_dir / f"polygon_ticks_{data_type}.parquet"
            df.to_parquet(output_file, index=False)

            print(f"  ✓ Saved to {output_file.name}")

            # Show sample
            if len(df) > 0:
                print(f"\n  📊 Sample data:")
                display_cols = [c for c in df.columns[:8]]
                print(df[display_cols].head(3).to_string())

            # Add to subdatasets
            subdatasets[data_type] = SubDataset(
                name=data_type,
                files=[output_file],
                description=f"{data_type.upper()} tick data for {', '.join(tickers)} on {date}",
                metadata={
                    "data_type": data_type,
                    "ticks": len(df),
                    "date": date,
                    "tickers": tickers,
                    "columns": list(df.columns),
                }
            )
        else:
            print(f"  ⚠️  No data found for {data_type}")

    if not subdatasets:
        raise ValueError("No tick data downloaded")

    # Use first subdataset as main
    main_files = [list(subdatasets.values())[0].files[0]]

    # Generate documentation
    readme = f"""# Polygon Ticks Dataset

## Overview
Tick-level trades and quotes data from Polygon.io

## Configuration
- **Date**: {date}
- **Tickers**: {', '.join(tickers)}
- **Data Types**: {', '.join(data_types)}
- **Limit**: {limit:,} ticks per ticker

## Data Types

### Trades
Individual trade executions:
- `timestamp_ns` - Nanosecond timestamp
- `price` - Trade price
- `size` - Trade size (shares)
- `exchange` - Exchange code
- `conditions` - Trade conditions/flags
- `tape` - SIP tape (A, B, C)

### Quotes
Quote updates (bid/ask):
- `timestamp_ns` - Nanosecond timestamp
- `bid_price` - Bid price
- `bid_size` - Bid size
- `bid_exchange` - Bid exchange
- `ask_price` - Ask price
- `ask_size` - Ask size
- `ask_exchange` - Ask exchange
- `conditions` - Quote conditions

### NBBO (National Best Bid/Offer)
Consolidated best bid/ask across all exchanges:
- `timestamp_ns` - Nanosecond timestamp
- `bid_price` - Best bid price
- `bid_size` - Aggregated bid size
- `ask_price` - Best ask price
- `ask_size` - Aggregated ask size
- `tape` - SIP tape

## Schema

Fields vary by data type. All types include:
- `ticker` - Ticker symbol
- `date` - Trade date
- `timestamp_*` - Various timestamp fields
- `timestamp_*_dt` - Converted datetime fields

## Usage

```python
import warpdata as wd
import pandas as pd

# Load trade ticks
trades = wd.load("warpdata://ticks/...-trades", as_format="pandas")

# Convert to datetime index
trades['time'] = pd.to_datetime(trades['timestamp_ns'], unit='ns')
trades = trades.set_index('time')

# Resample to 1-second OHLC
ohlc_1s = trades['price'].resample('1S').ohlc()

# Calculate spread from quotes
quotes = wd.load("warpdata://ticks/...-quotes", as_format="pandas")
quotes['spread'] = quotes['ask_price'] - quotes['bid_price']
quotes['spread_bps'] = (quotes['spread'] / quotes['bid_price']) * 10000

# Analyze trade sizes
trades.groupby('exchange')['size'].describe()

# Filter market hours (9:30-16:00 ET)
market_trades = trades.between_time('09:30', '16:00')

# Calculate VWAP
vwap = (trades['price'] * trades['size']).sum() / trades['size'].sum()
```

## Statistics
"""

    for name, subdataset in subdatasets.items():
        readme += f"\n### {name.upper()}\n"
        readme += f"- Ticks: {subdataset.metadata.get('ticks', 0):,}\n"
        readme += f"- Tickers: {len(tickers)}\n"

    readme += f"""

## Notes

- Tick data can be very large (millions of records per day for liquid stocks)
- Timestamps are in nanoseconds for maximum precision
- Exchange codes: https://polygon.io/docs/stocks/get_v3_reference_exchanges
- Condition codes: https://polygon.io/docs/stocks/get_v3_reference_conditions
- Consider using `limit` parameter to control data volume
- For full day data, may need multiple API calls with pagination
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=main_files,
        subdatasets=subdatasets,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
