"""
Multidomain Math dataset recipe.

Synthetic math expressions across multiple domains with axiom targets.
Useful for training models on symbolic math reasoning.

Domains:
- Algebra, SetTheory, Logic, Calculus, LinearAlgebra
- NumberTheory, InformationTheory, Probability, Riemann, Transformer

Task types:
- Axiom proofs (identity, inverse, distributivity, etc.)
- Simplifications
- Random samples

Difficulty levels: easy, medium, hard
"""
from pathlib import Path
from typing import Optional
import json

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def multidomain_math(
    ctx: RecipeContext,
    jsonl_path: Optional[str] = None,
    limit: Optional[int] = None,
) -> RecipeOutput:
    """
    Create Multidomain Math dataset from JSONL.

    Args:
        ctx: Recipe context
        jsonl_path: Path to JSONL file (default: recipes_raw_data/multidomain_math.jsonl)
        limit: Max rows to process (None = all)

    Returns:
        RecipeOutput with dataset

    Dataset columns:
        - id: str - Unique expression ID
        - world: str - Math domain (Algebra, Logic, etc.)
        - task_type: str - Type of task (axiom_identity, axiom_inverse, etc.)
        - difficulty: str - easy/medium/hard
        - expr: str - Expression string
        - unicode: str - Unicode representation
        - latex: str - LaTeX representation
        - tokens: list[str] - Tokenized expression
        - axiom_target: str - Target/answer for the task
        - size: int - Expression tree size
        - depth: int - Expression tree depth
        - vars: list[str] - Variables in expression
        - head: str - Root operator

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "multidomain_math",
        ...     "warpdata://math/multidomain",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("math/multidomain", as_format="pandas")
        >>> algebra = df[df['world'] == 'Algebra']
    """
    # Default path
    if jsonl_path is None:
        jsonl_path = Path(__file__).parent.parent.parent.parent / "recipes_raw_data" / "multidomain_math.jsonl"
    else:
        jsonl_path = Path(jsonl_path)

    if not jsonl_path.exists():
        raise FileNotFoundError(f"JSONL file not found: {jsonl_path}")

    print(f"Loading from {jsonl_path}...")

    records = []
    with open(jsonl_path, 'r') as f:
        for i, line in enumerate(f):
            if limit and i >= limit:
                break

            obj = json.loads(line)

            record = {
                'id': obj.get('id'),
                'world': obj.get('world'),
                'task_type': obj.get('task_type'),
                'difficulty': obj.get('difficulty'),
                'expr': obj.get('expr'),
                'unicode': obj.get('unicode'),
                'latex': obj.get('latex'),
                'tokens': obj.get('tokens'),  # list[str]
                'axiom_target': obj.get('axiom_target'),
                'size': obj.get('size'),
                'depth': obj.get('depth'),
                'vars': obj.get('vars'),  # list[str]
                'head': obj.get('head'),
            }
            records.append(record)

            if (i + 1) % 100000 == 0:
                print(f"  Processed {i + 1:,} rows...")

    print(f"\nTotal rows: {len(records):,}")

    df = pd.DataFrame(records)

    # Stats
    print(f"\nDomains:")
    print(df['world'].value_counts().head(10).to_string())
    print(f"\nTask types:")
    print(df['task_type'].value_counts().head(10).to_string())
    print(f"\nDifficulty:")
    print(df['difficulty'].value_counts().to_string())

    # Save
    output_path = ctx.work_dir / "multidomain_math.parquet"
    df.to_parquet(output_path, index=False)
    print(f"\nSaved to {output_path}")

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_rows': len(df),
            'domains': df['world'].value_counts().to_dict(),
            'task_types': df['task_type'].value_counts().to_dict(),
            'difficulty': df['difficulty'].value_counts().to_dict(),
            'source': str(jsonl_path),
        },
        raw_data=[jsonl_path] if jsonl_path.exists() else [],
    )
