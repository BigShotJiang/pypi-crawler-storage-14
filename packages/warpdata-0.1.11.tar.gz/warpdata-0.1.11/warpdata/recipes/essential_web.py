"""
Essential Web v1.0 dataset recipe.

This recipe builds a normalized text corpus from the
EssentialAI/essential-web-v1.0 dataset on HuggingFace.

Source: https://huggingface.co/datasets/EssentialAI/essential-web-v1.0
License: ODC-By

Core columns (from dataset card):
    - id: int64
    - text: str
    - metadata: dict
    - line_start_n_end_idx: dict
    - quality_signals: dict
    - eai_taxonomy: dict
    - pid: str

Design:
    - Stream the train split and write it out in Parquet chunks to
      keep memory usage bounded.
    - Support a global `limit` (number of examples) and/or `target_gb`
      (approximate bytes of `text`) to control dataset size.
    - Allow optional `data_files` override so callers can explicitly
      include/exclude particular Parquet shards (e.g., to skip HF-
      flagged "unsafe" shards).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional
import json

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from datasets import load_dataset

try:
    from tqdm.auto import tqdm
except Exception:  # pragma: no cover
    tqdm = None

from ..api.recipes import RecipeContext
from .base import RecipeOutput


WRITE_CHUNK_SIZE = 50_000


def essential_web(
    ctx: RecipeContext,
    repo_id: str = "EssentialAI/essential-web-v1.0",
    split: str = "train",
    limit: Optional[int] = None,
    target_gb: Optional[float] = None,
    data_files: Optional[Dict[str, List[str]]] = None,
) -> RecipeOutput:
    """
    Create an Essential Web v1.0 text dataset.

    Args:
        ctx: Recipe context.
        repo_id: HF dataset ID (default: 'EssentialAI/essential-web-v1.0').
        split: Split to load (default: 'train').
        limit: Optional global cap on number of examples. None means
            "no explicit cap".
        target_gb: Optional approximate cap on total UTF-8 text bytes
            (in gigabytes). Uses length of the `text` field. Mutually
            exclusive with `limit`.
        data_files: Optional dict passed through to `load_dataset` to
            explicitly select Parquet shards (e.g., to exclude files
            that HF flags as unsafe). Example:

                data_files={"train": ["train-00000-of-02000.parquet", ...]}

    Returns:
        RecipeOutput with a single Parquet file containing:
            - id: int
            - text: str
            - metadata_json: str             (JSON-encoded metadata)
            - line_start_n_end_idx_json: str (JSON-encoded indices)
            - quality_signals_json: str      (JSON-encoded signals)
            - eai_taxonomy_json: str         (JSON-encoded taxonomy)
            - pid: str
    """
    if limit is not None and target_gb is not None:
        raise ValueError("Specify only one of limit (examples) or target_gb (GB), not both.")

    print(f"Loading Essential Web from {repo_id} (split={split})...")
    if limit is not None:
        print(f"  Global example limit: {limit:,}")
    if target_gb is not None:
        total_bytes_budget = int(target_gb * (1024**3))
        print(f"  Global text byte budget: ~{target_gb:.2f} GB ({total_bytes_budget:,} bytes)")
    else:
        total_bytes_budget = None

    # Resume support: detect existing chunk files and accumulate stats.
    total_examples = 0
    total_bytes = 0
    part_idx = 0
    part_paths: List[Path] = []

    existing_parts = sorted(ctx.work_dir.glob("essential_web_part*.parquet"))

    if existing_parts:
        print(f"\n  Found {len(existing_parts)} existing chunk file(s); "
              f"attempting to resume from previous progress.")
        for p in existing_parts:
            part_paths.append(p)
            name = p.name
            idx = 0
            if "part" in name:
                try:
                    idx_str = name.split("part", 1)[1].split(".parquet", 1)[0]
                    idx = int(idx_str)
                except Exception:
                    idx = 0
            if idx + 1 > part_idx:
                part_idx = idx + 1

            try:
                pf = pq.ParquetFile(p)
                meta = pf.metadata
                if meta is not None and meta.num_rows is not None:
                    total_examples += meta.num_rows
                # Approximate bytes using text column
                tbl = pf.read(columns=["text"])
                texts = tbl["text"].to_pylist()
                total_bytes += sum(len(str(t).encode("utf-8", errors="ignore")) for t in texts)
            except Exception:
                continue

        print(
            f"  Resuming with {total_examples:,} docs "
            f"(~{total_bytes / (1024**3):.2f} GB of text) already written."
        )

    # Helper to merge all part files into a single Parquet in work_dir.
    def merge_parts_to_single() -> Path:
        merged_path = ctx.work_dir / "essential_web.parquet"
        if merged_path.exists():
            merged_path.unlink()

        writer = None
        for p in sorted(part_paths):
            try:
                table = pq.read_table(p)
            except Exception as e:
                print(f"  Warning: failed to read chunk {p}: {e}; skipping.")
                continue
            if writer is None:
                writer = pq.ParquetWriter(merged_path, table.schema)
            writer.write_table(table)
        if writer is not None:
            writer.close()
        return merged_path

    # Early exit if existing chunks already satisfy limits, but always
    # expose a single merged Parquet as the dataset resource.
    if limit is not None and total_examples >= limit:
        print(f"\n  Existing chunks already satisfy limit={limit:,}; no new docs needed.")
        merged_path = merge_parts_to_single()
        return RecipeOutput(
            main=[merged_path],
            metadata={
                "total_examples": total_examples,
                "total_text_bytes": total_bytes,
                "repo_id": repo_id,
                "split": split,
                "limit": limit,
                "target_gb": target_gb,
            },
            raw_data=[
                p
                for p in [
                    Path.home()
                    / ".cache"
                    / "huggingface"
                    / "datasets"
                    / repo_id.replace("/", "___")
                ]
                if p.exists()
            ],
        )

    if total_bytes_budget is not None and total_bytes >= total_bytes_budget:
        print(
            f"\n  Existing chunks already satisfy target_gb≈{target_gb:.2f} GB; "
            "no new docs needed."
        )
        merged_path = merge_parts_to_single()
        return RecipeOutput(
            main=[merged_path],
            metadata={
                "total_examples": total_examples,
                "total_text_bytes": total_bytes,
                "repo_id": repo_id,
                "split": split,
                "limit": limit,
                "target_gb": target_gb,
            },
            raw_data=[
                p
                for p in [
                    Path.home()
                    / ".cache"
                    / "huggingface"
                    / "datasets"
                    / repo_id.replace("/", "___")
                ]
                if p.exists()
            ],
        )

    # Streaming load from HF.
    ds = load_dataset(
        repo_id,
        split=split,
        streaming=True,
        data_files=data_files,
    )

    buffer: List[Dict[str, Any]] = []

    def flush_buffer():
        nonlocal buffer, part_idx
        if not buffer:
            return
        df = pd.DataFrame(buffer)
        table = pa.Table.from_pandas(df, preserve_index=False)
        out_path = ctx.work_dir / f"essential_web_part{part_idx:05d}.parquet"
        pq.write_table(table, out_path)
        part_paths.append(out_path)
        print(
            f"  Saved chunk {part_idx} with {len(df):,} docs "
            f"to {out_path.name}"
        )
        buffer.clear()
        part_idx += 1

    if tqdm is not None:
        data_iter = tqdm(
            ds,
            desc="Streaming Essential Web",
            unit="doc",
            initial=total_examples,
        )
    else:
        data_iter = ds

    for i, ex in enumerate(data_iter):
        if limit is not None and total_examples >= limit:
            print(f"  Reached limit={limit:,}; stopping at index {i:,}")
            break
        if total_bytes_budget is not None and total_bytes >= total_bytes_budget:
            print(
                f"  Reached text byte budget: "
                f"{total_bytes / (1024**3):.2f} GB after {total_examples:,} docs"
            )
            break

        text = str(ex.get("text", ""))
        text_bytes = len(text.encode("utf-8", errors="ignore"))

        # JSON-encode complex dict-like columns to keep a stable schema
        # across all chunks and shards.
        record: Dict[str, Any] = {
            "id": ex.get("id"),
            "text": text,
            "metadata_json": json.dumps(ex.get("metadata", {}), ensure_ascii=False),
            "line_start_n_end_idx_json": json.dumps(
                ex.get("line_start_n_end_idx", {}), ensure_ascii=False
            ),
            "quality_signals_json": json.dumps(
                ex.get("quality_signals", {}), ensure_ascii=False
            ),
            "eai_taxonomy_json": json.dumps(
                ex.get("eai_taxonomy", {}), ensure_ascii=False
            ),
            "pid": str(ex.get("pid", "")),
        }

        buffer.append(record)
        total_examples += 1
        total_bytes += text_bytes

        if len(buffer) >= WRITE_CHUNK_SIZE:
            flush_buffer()

        if total_examples % 100_000 == 0:
            print(
                f"  Processed {total_examples:,} docs "
                f"(~{total_bytes / (1024**3):.2f} GB of text)"
            )

    flush_buffer()

    print(f"\nTotal docs collected: {total_examples:,}")
    print(f"Approx text size: {total_bytes / (1024**3):.2f} GB")

    merged_path = merge_parts_to_single()
    print(f"Merged {len(part_paths)} chunk file(s) into {merged_path}")

    raw_data_paths: List[Path] = []
    hf_cache = (
        Path.home()
        / ".cache"
        / "huggingface"
        / "datasets"
        / repo_id.replace("/", "___")
    )
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[merged_path],
        metadata={
            "total_examples": total_examples,
            "total_text_bytes": total_bytes,
            "repo_id": repo_id,
            "split": split,
            "limit": limit,
            "target_gb": target_gb,
        },
        raw_data=raw_data_paths,
    )
