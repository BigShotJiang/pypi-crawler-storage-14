"""
Project Gutenberg mirror index recipe.

This recipe assumes you have rsynced the official Project Gutenberg
collection locally (as recommended in their mirroring docs) and builds
an index table over the plain-text book files.

It does NOT store the full book text again; instead it records file
paths into your local mirror, so you can:
  - keep raw text in the mirror only, and
  - use this Parquet as a lightweight index for training/processing.

Recommended mirroring (main collection only, example):

    rsync -av --delete aleph.gutenberg.org::gutenberg ./recipes_raw_data/gutenberg

Then run this recipe with:

    warp recipes run gutenberg_mirror \\
      warpdata://text/gutenberg_index \\
      --materialize \\
      -p mirror_root=recipes_raw_data/gutenberg

Output schema (one row per book):
    - book_id: int        – Gutenberg numeric ID
    - rel_path: str       – Path to text file, relative to mirror_root
    - file_path: str      – Absolute path to text file
    - size_bytes: int     – File size in bytes

Notes:
    - All languages and all books in the mirror are included.
    - You can cap the number of indexed books using ``max_books`` for
      testing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def _extract_book_id(stem: str) -> Optional[int]:
    """
    Extract leading integer book ID from a filename stem.

    Examples:
        '1342' -> 1342
        '1342-0' -> 1342
        '1342-8' -> 1342
        'pg1342' -> None (no leading digits)
    """
    digits = []
    for ch in stem:
        if ch.isdigit():
            digits.append(ch)
        else:
            break
    if not digits:
        return None
    try:
        return int("".join(digits))
    except ValueError:
        return None


def _score_candidate(book_id: int, path: Path) -> int:
    """
    Score a candidate text file for a given book ID.

    Higher score = more preferred. Heuristics:
        - <id>-0.txt  : prefer UTF-8 canonical form
        - <id>.txt    : plain .txt
        - <id>-*.txt  : other variants
    """
    name = path.name.lower()
    base = f"{book_id}"

    if name == f"{base}-0.txt":
        return 3
    if name == f"{base}.txt":
        return 2
    if name.startswith(f"{base}-") and name.endswith(".txt"):
        return 1
    return 0


def gutenberg_mirror(
    ctx: RecipeContext,
    mirror_root: str = "recipes_raw_data/gutenberg",
    max_books: Optional[int] = None,
    min_bytes: int = 1024,
) -> RecipeOutput:
    """
    Index a local Project Gutenberg rsync mirror.

    Args:
        ctx: Recipe context.
        mirror_root: Root directory of the rsynced Gutenberg mirror
            (e.g., 'recipes_raw_data/gutenberg').
        max_books: Optional cap on number of books to index. ``None`` means
            "all books discovered".
        min_bytes: Minimum file size (bytes) to accept as a valid book
            text (small files are ignored).

    Returns:
        RecipeOutput with a single Parquet file containing the index.

    Dataset columns:
        - book_id: int
        - rel_path: str
        - file_path: str
        - size_bytes: int
    """
    root = Path(mirror_root)
    if not root.exists():
        raise ValueError(f"Gutenberg mirror root not found: {root}")

    print(f"📚 Indexing Project Gutenberg mirror at: {root}")
    if max_books is not None:
        print(f"   Limiting to at most {max_books:,} books")
    print(f"   Ignoring text files smaller than {min_bytes} bytes")

    # Map from book_id -> (score, Path, size_bytes)
    best: Dict[int, Tuple[int, Path, int]] = {}

    # Walk all .txt files; rely on Gutenberg naming convention where
    # book IDs appear as leading digits in filenames (e.g., 1342-0.txt).
    for path in root.rglob("*.txt"):
        # Skip generated caches if present.
        if any(part.lower() == "cache" for part in path.parts):
            continue

        stem = path.stem
        book_id = _extract_book_id(stem)
        if book_id is None:
            continue

        try:
            size = path.stat().st_size
        except OSError:
            continue

        if size < min_bytes:
            continue

        score = _score_candidate(book_id, path)
        current = best.get(book_id)
        if current is None or score > current[0] or (score == current[0] and size > current[2]):
            best[book_id] = (score, path, size)

    if not best:
        raise ValueError(
            f"No eligible .txt book files found under {root}. "
            "Ensure you rsynced the main Gutenberg collection."
        )

    print(f"   Found {len(best):,} distinct book IDs")

    # Build records, optionally limiting to max_books.
    records: List[dict] = []
    for idx, book_id in enumerate(sorted(best.keys())):
        if max_books is not None and idx >= max_books:
            break

        _, path, size = best[book_id]
        rel_path = str(path.relative_to(root))
        file_path = str(path.resolve())

        records.append(
            {
                "book_id": book_id,
                "rel_path": rel_path,
                "file_path": file_path,
                "size_bytes": size,
            }
        )

        if (idx + 1) % 1000 == 0:
            print(f"   Indexed {idx + 1:,} books...")

    total_books = len(records)
    print(f"\n✅ Completed indexing {total_books:,} books")

    df = pd.DataFrame(records)
    out_path = ctx.work_dir / "gutenberg_mirror_index.parquet"
    df.to_parquet(out_path, index=False)

    print(f"Saved index to {out_path}")

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_books": total_books,
            "mirror_root": str(root.resolve()),
            "min_bytes": min_bytes,
            "max_books": max_books,
        },
        raw_data=[root.resolve()],
    )

