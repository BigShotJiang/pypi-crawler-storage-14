"""
CoinGecko Global Market Metrics dataset recipe.

Downloads global crypto market metrics from CoinGecko API:
- Total market cap (all coins)
- Total volume (24h)
- BTC dominance %
- ETH dominance %
- Market cap change % (24h)
- Active cryptocurrencies count
- Markets count

Data fields per timestamp:
- timestamp (YYYY-MM-DD HH:00:00, UTC)
- total_market_cap_usd
- total_volume_24h_usd
- btc_dominance_pct
- eth_dominance_pct
- defi_dominance_pct
- market_cap_change_pct_24h
- active_cryptocurrencies
- markets
- ongoing_icos
- ended_icos
- updated_at

The recipe collects snapshots hourly and deduplicates on timestamp.

API key:
- Reads key from env: COINGECKO_API_KEY
- Pro API key for x-cg-pro-api-key header

Example:
    >>> import warpdata as wd
    >>> result = wd.run_recipe(
    ...     "coingecko_global",
    ...     "warpdata://crypto/coingecko/global",
    ...     start_date="2024-01-01",
    ...     end_date="2024-12-31",
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, Optional, List
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PUBLIC_API_BASE = "https://api.coingecko.com/api/v3"
PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"


def _api_base(api_key: Optional[str]) -> str:
    return PRO_API_BASE if api_key else PUBLIC_API_BASE


_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                if code in (401, 403) and PRO_API_BASE in url:
                    alt = url.replace(PRO_API_BASE, PUBLIC_API_BASE)
                    alt_req = urllib.request.Request(alt, headers=headers, method="GET")
                    try:
                        with urllib.request.urlopen(alt_req, timeout=timeout) as r2:
                            return json.loads(r2.read())
                    except:
                        pass
            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def coingecko_global(
    ctx: RecipeContext,
    start_date: str,
    end_date: str,
    *,
    api_key: Optional[str] = None,
    interval_hours: int = 1,
    max_workers: int = 8,
) -> RecipeOutput:
    """
    Create CoinGecko Global Market Metrics dataset.

    Downloads hourly snapshots of global market data.

    Args:
        ctx: Recipe context
        start_date: Start date (YYYY-MM-DD)
        end_date: End date (YYYY-MM-DD)
        api_key: CoinGecko API key (or set COINGECKO_API_KEY env var)
        interval_hours: Hours between snapshots (default: 1 = hourly)

    Returns:
        RecipeOutput with global market metrics

    Examples:
        >>> import warpdata as wd
        >>> # Get global metrics for 2024
        >>> result = wd.run_recipe(
        ...     "coingecko_global",
        ...     "warpdata://crypto/coingecko/global",
        ...     start_date="2024-01-01",
        ...     end_date="2024-12-31",
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")
    base = _api_base(api_key)

    print(f"📊 Fetching CoinGecko Global Market Metrics")
    print(f"  Date range: {start_date} to {end_date}")
    print(f"  Interval: {interval_hours} hour(s)")

    # Parse dates
    start_dt = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end_dt = datetime.strptime(end_date, "%Y-%m-%d").replace(hour=23, tzinfo=timezone.utc)

    # Generate hourly timestamps
    current = start_dt
    timestamps = []
    while current <= end_dt:
        timestamps.append(current)
        current += timedelta(hours=interval_hours)

    print(f"  Total snapshots to collect: {len(timestamps)}")

    # Try to load existing data (prefer local stable file)
    existing_df = None
    output_file = ctx.work_dir / "coingecko_global.parquet"
    print(f"\n  🔄 Checking for existing data...")
    try:
        if output_file.exists():
            existing_df = pd.read_parquet(output_file)
            print(f"  ✓ Found local file: {len(existing_df):,} records")
        else:
            from ..api import load
            dataset_uri = ctx.dataset_id
            existing_df = load(dataset_uri, as_format="pandas")
            print(f"  ✓ Found registry dataset: {len(existing_df):,} records")
    except Exception as load_err:
        print(f"  ℹ️  No existing dataset to merge: {load_err}")

    if existing_df is not None and not existing_df.empty and 'timestamp' in existing_df.columns:
        existing_df['timestamp'] = pd.to_datetime(existing_df['timestamp'])
        try:
            tz_none = existing_df['timestamp'].dt.tz is None
        except Exception:
            tz_none = True
        existing_timestamps = set(existing_df['timestamp'].dt.tz_localize('UTC' if tz_none else None))
        timestamps = [ts for ts in timestamps if ts not in existing_timestamps]
        print(f"  ℹ️  Filtering out {len(existing_timestamps)} existing timestamps")
        print(f"  ⬇️  New snapshots to fetch: {len(timestamps)}")

    if not timestamps:
        print(f"\n  ✅ All timestamps already collected!")
        if existing_df is not None:
            output_file = ctx.work_dir / "coingecko_global.parquet"
            existing_df.to_parquet(output_file, index=False)
            return RecipeOutput(
                main=[output_file],
                metadata={"message": "No new data to fetch"}
            )
        else:
            raise ValueError("No timestamps to fetch and no existing data")

    # Collect snapshots (concurrently in batches to control memory)
    records: List[Dict[str, Any]] = []
    total = len(timestamps)
    print(f"\n  🚀 Collecting {total} snapshots with up to {max_workers} workers...")

    def fetch_one(ts):
        try:
            url = f"{base}/global"
            data = _http_get_json(url, api_key=api_key)
            if 'data' not in data:
                return None, f"No data field"
            gd = data['data']
            rec = {
                'timestamp': ts.strftime('%Y-%m-%d %H:%M:%S'),
                'total_market_cap_usd': gd.get('total_market_cap', {}).get('usd', 0),
                'total_volume_24h_usd': gd.get('total_volume', {}).get('usd', 0),
                'btc_dominance_pct': gd.get('market_cap_percentage', {}).get('btc', 0),
                'eth_dominance_pct': gd.get('market_cap_percentage', {}).get('eth', 0),
                'defi_dominance_pct': gd.get('defi_market_cap', 0) / gd.get('total_market_cap', {}).get('usd', 1) * 100 if gd.get('defi_market_cap') and gd.get('total_market_cap', {}).get('usd') else 0,
                'market_cap_change_pct_24h': gd.get('market_cap_change_percentage_24h_usd', 0),
                'active_cryptocurrencies': gd.get('active_cryptocurrencies', 0),
                'markets': gd.get('markets', 0),
                'ongoing_icos': gd.get('ongoing_icos', 0),
                'ended_icos': gd.get('ended_icos', 0),
                'updated_at': gd.get('updated_at', 0),
            }
            return rec, None
        except Exception as e:
            return None, str(e)

    processed = 0
    batch_size = max(max_workers * 25, 100)
    for start_idx in range(0, total, batch_size):
        batch = timestamps[start_idx:start_idx + batch_size]
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futs = {pool.submit(fetch_one, ts): ts for ts in batch}
            for i, fut in enumerate(as_completed(futs), 1):
                rec, err = fut.result()
                processed += 1
                if rec:
                    records.append(rec)
                if processed % 50 == 0 or processed == total:
                    print(f"  [{processed}/{total}] ✓ Collected {len(records)} snapshots")
                if err and processed % 200 == 0:
                    print(f"  [{processed}/{total}] ⚠️  Error: {err}")

    if not records:
        raise ValueError("No data collected")

    print(f"\n  ✓ Collected {len(records):,} snapshots")

    # Create DataFrame
    df = pd.DataFrame(records)
    df['timestamp'] = pd.to_datetime(df['timestamp'])

    # Merge with existing data
    if existing_df is not None and not existing_df.empty:
        print(f"\n  📦 Merging with existing data...")
        combined_df = pd.concat([existing_df, df], ignore_index=True)
        print(f"  Combined: {len(combined_df):,} records")

        # Deduplicate
        initial_count = len(combined_df)
        combined_df = combined_df.drop_duplicates(subset=['timestamp'], keep='last')
        duplicates_removed = initial_count - len(combined_df)

        if duplicates_removed > 0:
            print(f"  🧹 Removed {duplicates_removed:,} duplicate records")

        df = combined_df

    # Sort by timestamp
    df = df.sort_values('timestamp').reset_index(drop=True)

    # Save
    output_file = ctx.work_dir / "coingecko_global.parquet"
    df.to_parquet(output_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} records")
    print(f"  📊 Date range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    print(f"\n  Sample metrics:")
    latest = df.iloc[-1]
    print(f"    BTC Dominance: {latest['btc_dominance_pct']:.2f}%")
    print(f"    ETH Dominance: {latest['eth_dominance_pct']:.2f}%")
    print(f"    Total Market Cap: ${latest['total_market_cap_usd']/1e9:.2f}B")
    print(f"    24h Volume: ${latest['total_volume_24h_usd']/1e9:.2f}B")

    readme = f"""# CoinGecko Global Market Metrics

## Overview
Global cryptocurrency market metrics from CoinGecko API

## Configuration
- **Date Range**: {start_date} to {end_date}
- **Interval**: {interval_hours} hour(s)
- **Source**: CoinGecko API

## Schema

| Column | Type | Description |
|--------|------|-------------|
| timestamp | datetime | Snapshot timestamp (UTC) |
| total_market_cap_usd | float | Total crypto market cap (USD) |
| total_volume_24h_usd | float | Total 24h trading volume (USD) |
| btc_dominance_pct | float | Bitcoin dominance percentage |
| eth_dominance_pct | float | Ethereum dominance percentage |
| defi_dominance_pct | float | DeFi dominance percentage |
| market_cap_change_pct_24h | float | 24h market cap change percentage |
| active_cryptocurrencies | int | Number of active cryptocurrencies |
| markets | int | Number of active markets |
| ongoing_icos | int | Number of ongoing ICOs |
| ended_icos | int | Number of ended ICOs |
| updated_at | int | Unix timestamp of update |

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("warpdata://crypto/coingecko/global", as_format="pandas")

# Detect altseason (BTC dominance falling)
altseason = df[df['btc_dominance_pct'] < 40]

# Market cap growth
df['market_cap_growth'] = df['total_market_cap_usd'].pct_change()

# BTC dominance trend
df['btc_dom_ma7'] = df['btc_dominance_pct'].rolling(7*24).mean()
```

## Statistics
- Total snapshots: {len(df):,}
- Date range: {df['timestamp'].min()} to {df['timestamp'].max()}
- Latest BTC dominance: {latest['btc_dominance_pct']:.2f}%
- Latest market cap: ${latest['total_market_cap_usd']/1e9:.2f}B
"""

    return RecipeOutput(
        main=[output_file],
        docs={"README.md": readme},
        metadata={
            "start_date": start_date,
            "end_date": end_date,
            "records": len(df),
            "source": "CoinGecko API",
        },
    )
