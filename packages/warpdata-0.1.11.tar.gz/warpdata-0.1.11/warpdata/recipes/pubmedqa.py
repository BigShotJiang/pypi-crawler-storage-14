"""
PubMedQA dataset recipe.

This recipe builds a QA corpus from the PubMedQA dataset:

    https://huggingface.co/datasets/qiaojin/PubMedQA

We focus on the \"pqa_labeled\" configuration, which contains
1,000 labeled question–context–answer triples drawn from
PubMed abstracts.

Core fields:
    - pubid: int           – PubMed ID
    - question: str        – Natural language question
    - context: dict        – Source passages and metadata
    - long_answer: str     – Long-form answer/explanation
    - final_decision: str  – Short label ('yes' / 'no' / 'maybe')
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Any

import pandas as pd
from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def pubmedqa(
    ctx: RecipeContext,
    repo_id: str = "qiaojin/PubMedQA",
    config: str = "pqa_labeled",
    split: str = "train",
) -> RecipeOutput:
    """
    Create a PubMedQA question–answer dataset.

    Args:
        ctx: Recipe context.
        repo_id: HuggingFace dataset ID (default: 'qiaojin/PubMedQA').
        config: Dataset configuration (default: 'pqa_labeled').
        split: Split to load (default: 'train').

    Returns:
        RecipeOutput with a single Parquet file containing:
            - pubid: int
            - question: str
            - context: dict
            - long_answer: str
            - final_decision: str
    """
    print(f"Loading PubMedQA from {repo_id} (config={config}, split={split})...")
    ds = load_dataset(repo_id, config, split=split)
    print(f"  Loaded {len(ds):,} examples")

    records: list[Dict[str, Any]] = []
    for ex in ds:
        record: Dict[str, Any] = {
            "pubid": int(ex.get("pubid", 0) or 0),
            "question": str(ex.get("question", "")),
            "context": ex.get("context", {}),
            "long_answer": str(ex.get("long_answer", "")),
            "final_decision": str(ex.get("final_decision", "")),
        }
        records.append(record)

    df = pd.DataFrame(records)
    out_path = ctx.work_dir / "pubmedqa.parquet"
    df.to_parquet(out_path, index=False)
    print(f"Saved to {out_path}")

    # Provenance: HF cache root for this dataset
    raw_data_paths: list[Path] = []
    hf_cache = (
        Path.home()
        / ".cache"
        / "huggingface"
        / "datasets"
        / repo_id.replace("/", "___")
    )
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_examples": len(df),
            "repo_id": repo_id,
            "config": config,
            "split": split,
        },
        raw_data=raw_data_paths,
    )

