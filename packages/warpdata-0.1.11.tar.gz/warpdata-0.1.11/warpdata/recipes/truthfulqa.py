"""
TruthfulQA dataset recipe.

TruthfulQA is a benchmark to measure whether a language model is truthful in
generating answers to questions. The dataset contains questions that some humans
would answer falsely due to misconceptions or false beliefs.

Source: https://huggingface.co/datasets/truthful_qa
Paper: https://arxiv.org/abs/2109.07958

Contains:
- validation: 817 questions across 38 categories
"""
from pathlib import Path
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def truthfulqa(
    ctx: RecipeContext,
    repo_id: str = "truthful_qa",
    config: str = "generation",
) -> RecipeOutput:
    """
    Create TruthfulQA benchmark dataset.

    Downloads TruthfulQA from HuggingFace. Contains questions designed to test
    whether models give truthful answers or fall for common misconceptions.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        config: Which config to use ("generation" or "multiple_choice")

    Returns:
        RecipeOutput with single dataset

    Dataset columns (generation config):
        - type: str - Question type
        - category: str - Question category
        - question: str - The question
        - best_answer: str - The best correct answer
        - correct_answers: list - List of acceptable correct answers
        - incorrect_answers: list - List of incorrect answers
        - source: str - Source of the question

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "truthfulqa",
        ...     "warpdata://nlp/truthfulqa",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/truthfulqa", as_format="pandas")
        >>> # Filter by category
        >>> health = df[df['category'] == 'Health']
    """
    print(f"Loading TruthfulQA from {repo_id} (config: {config})...")

    # Load dataset
    print(f"  Loading validation split...")
    ds = load_dataset(repo_id, config, split="validation")

    print(f"  Processing {len(ds):,} questions...")

    # Process records
    all_records = []

    for example in ds:
        record = {
            'type': example.get('type', ''),
            'category': example.get('category', ''),
            'question': example.get('question', ''),
            'best_answer': example.get('best_answer', ''),
            'correct_answers': example.get('correct_answers', []),
            'incorrect_answers': example.get('incorrect_answers', []),
            'source': example.get('source', ''),
        }
        all_records.append(record)

    print(f"\nTotal questions: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "truthfulqa.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")

    if 'category' in df.columns:
        print(f"\nCategory distribution:")
        print(df['category'].value_counts().to_string())

    if 'type' in df.columns:
        print(f"\nType distribution:")
        print(df['type'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_questions': len(df),
            'categories': df['category'].value_counts().to_dict() if 'category' in df.columns else {},
            'types': df['type'].value_counts().to_dict() if 'type' in df.columns else {},
            'config': config,
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
