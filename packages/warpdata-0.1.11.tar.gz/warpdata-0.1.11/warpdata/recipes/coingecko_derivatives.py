"""
CoinGecko Derivatives Data - Funding Rates, Open Interest, Perpetuals.

Downloads complete derivatives market data including:
- Funding rates (for perpetual swaps)
- Open interest (total positions)
- Basis (futures vs spot spread)
- Volume 24h
- Index price, contract price
- Bid-ask spread
- Contract types (perpetual, futures)

Smart features:
- Deduplicates on (timestamp, market, symbol)
- Tracks existing data to avoid re-downloading
- Filters by exchange, contract type, symbol
- Sorts by open interest or volume

Updates: Every 30 seconds (CoinGecko refresh rate)

API key:
- Requires CoinGecko Pro API key

Example:
    >>> import warpdata as wd
    >>> # Get all derivatives data
    >>> result = wd.run_recipe(
    ...     "coingecko_derivatives",
    ...     "warpdata://crypto/coingecko/derivatives",
    ...     with_materialize=True
    ... )
    >>>
    >>> # Filter by exchange
    >>> result = wd.run_recipe(
    ...     "coingecko_derivatives",
    ...     "warpdata://crypto/coingecko/derivatives_binance",
    ...     exchanges=["binance_futures", "bybit"],
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"

_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def _safe_float(value, default=None):
    """Safely convert to float."""
    if value is None:
        return default
    try:
        return float(value)
    except (ValueError, TypeError):
        return default


def _check_if_should_skip(ctx: RecipeContext, api_key: str) -> bool:
    """
    Check if we should skip download based on existing data.
    Skip if latest data is < 5 minutes old (CoinGecko updates every 30s).
    """
    out_file = ctx.work_dir / "coingecko_derivatives.parquet"
    if not out_file.exists():
        return False

    try:
        from ..api import load
        existing_df = load(ctx.dataset_id, as_format="pandas")

        if len(existing_df) == 0:
            return False

        # Get latest timestamp
        latest_ts = pd.to_datetime(existing_df['fetched_at']).max()
        age_minutes = (pd.Timestamp.now(tz='UTC') - latest_ts).total_seconds() / 60

        if age_minutes < 5:
            print(f"  ⏭️  Skipping: Latest data is {age_minutes:.1f} minutes old (< 5 min threshold)")
            return True

        print(f"  ✓ Latest data is {age_minutes:.1f} minutes old, fetching new snapshot")
        return False

    except Exception as e:
        print(f"  ℹ️  Could not check existing data: {e}")
        return False


def coingecko_derivatives(
    ctx: RecipeContext,
    *,
    exchanges: Optional[List[str]] = None,
    symbols: Optional[List[str]] = None,
    contract_types: Optional[List[str]] = None,
    min_open_interest: Optional[float] = None,
    min_volume_24h: Optional[float] = None,
    api_key: Optional[str] = None,
    force_update: bool = False,
) -> RecipeOutput:
    """
    Create derivatives dataset with funding rates and open interest.

    Smart features:
    - Auto-skips if data < 5 minutes old (CoinGecko updates every 30s)
    - Deduplicates on (fetched_at, market, symbol)
    - Filters by exchange, symbol, contract type
    - Tracks historical snapshots

    Args:
        ctx: Recipe context
        exchanges: Filter by exchange IDs (e.g., ["binance_futures", "bybit"])
        symbols: Filter by symbols (e.g., ["BTCUSDT", "ETHUSDT"])
        contract_types: Filter by type (e.g., ["perpetual", "futures"])
        min_open_interest: Minimum open interest filter
        min_volume_24h: Minimum 24h volume filter
        api_key: CoinGecko Pro API key
        force_update: Force update even if recent data exists

    Returns:
        RecipeOutput with derivatives data

    Examples:
        >>> import warpdata as wd
        >>>
        >>> # All derivatives
        >>> result = wd.run_recipe(
        ...     "coingecko_derivatives",
        ...     "warpdata://crypto/coingecko/derivatives",
        ...     with_materialize=True
        ... )
        >>>
        >>> # Binance + Bybit only
        >>> result = wd.run_recipe(
        ...     "coingecko_derivatives",
        ...     "warpdata://crypto/coingecko/derivatives_top",
        ...     exchanges=["binance_futures", "bybit"],
        ...     with_materialize=True
        ... )
        >>>
        >>> # High volume perpetuals only
        >>> result = wd.run_recipe(
        ...     "coingecko_derivatives",
        ...     "warpdata://crypto/coingecko/derivatives_perps",
        ...     contract_types=["perpetual"],
        ...     min_volume_24h=1000000,
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")

    if not api_key:
        raise ValueError("CoinGecko Pro API key required. Set COINGECKO_API_KEY environment variable.")

    print(f"📊 Fetching CoinGecko Derivatives Data")
    if exchanges:
        print(f"  Exchanges: {', '.join(exchanges)}")
    if symbols:
        print(f"  Symbols: {', '.join(symbols)}")
    if contract_types:
        print(f"  Contract types: {', '.join(contract_types)}")

    # Check if should skip
    if not force_update:
        if _check_if_should_skip(ctx, api_key):
            # Load and return existing
            out_file = ctx.work_dir / "coingecko_derivatives.parquet"
            from ..api import load
            existing_df = load(ctx.dataset_id, as_format="pandas")

            return RecipeOutput(
                main=[out_file],
                docs={"README.md": "Skipped update - data is recent"},
                metadata={
                    "skipped": True,
                    "records": len(existing_df),
                    "source": "CoinGecko Derivatives API",
                },
            )

    print(f"\n  🔄 Fetching derivatives tickers...")

    url = f"{PRO_API_BASE}/derivatives"

    try:
        response = _http_get_json(url, api_key=api_key)

        if not isinstance(response, list):
            raise ValueError(f"Unexpected response type: {type(response)}")

        print(f"  ✓ Fetched {len(response):,} derivatives")

        # Process all derivatives
        fetched_at = datetime.now(timezone.utc).isoformat()
        records = []

        for item in response:
            market = item.get("market", "")
            symbol = item.get("symbol", "")
            contract_type = item.get("contract_type", "")

            # Apply filters
            if exchanges and market and not any(ex in market.lower() for ex in [e.lower() for e in exchanges]):
                continue

            if symbols and symbol and symbol not in symbols:
                continue

            if contract_types and contract_type and contract_type not in contract_types:
                continue

            open_interest = _safe_float(item.get("open_interest"))
            volume_24h = _safe_float(item.get("volume_24h"))

            if min_open_interest and (not open_interest or open_interest < min_open_interest):
                continue

            if min_volume_24h and (not volume_24h or volume_24h < min_volume_24h):
                continue

            # Build record
            record = {
                "fetched_at": fetched_at,
                "market": market,
                "symbol": symbol,
                "index_id": item.get("index_id"),
                "contract_type": contract_type,

                # Prices
                "price": _safe_float(item.get("price")),
                "index_price": _safe_float(item.get("index")),
                "basis": _safe_float(item.get("basis")),

                # Trading metrics
                "funding_rate": _safe_float(item.get("funding_rate")),
                "open_interest": open_interest,
                "volume_24h": volume_24h,
                "spread": _safe_float(item.get("spread")),

                # Changes
                "price_change_24h_pct": _safe_float(item.get("price_percentage_change_24h")),

                # Metadata
                "last_traded_at": item.get("last_traded_at"),
                "expired_at": item.get("expired_at"),
            }

            records.append(record)

        print(f"  ✓ After filters: {len(records):,} derivatives")

        if not records:
            raise ValueError("No derivatives found after filtering")

        # Create DataFrame
        df = pd.DataFrame(records)

        # Sort by open interest
        if "open_interest" in df.columns:
            df = df.sort_values("open_interest", ascending=False)

        # Load existing and append
        out_file = ctx.work_dir / "coingecko_derivatives.parquet"
        if out_file.exists():
            try:
                from ..api import load
                existing_df = load(ctx.dataset_id, as_format="pandas")
                print(f"\n  📦 Found existing dataset: {len(existing_df):,} records")

                df = pd.concat([existing_df, df], ignore_index=True)

                # Deduplicate on (fetched_at, market, symbol)
                initial_count = len(df)
                df = df.drop_duplicates(subset=["fetched_at", "market", "symbol"], keep="last")
                if len(df) < initial_count:
                    print(f"  🧹 Removed {initial_count - len(df):,} duplicates")

            except Exception as e:
                print(f"  ℹ️  No existing dataset: {e}")

        df = df.reset_index(drop=True)

        # Save
        df.to_parquet(out_file, index=False)

        print(f"\n  ✅ Saved {len(df):,} records")

        # Show stats
        if len(df) > 0:
            latest = df[df["fetched_at"] == df["fetched_at"].max()]
            print(f"\n  📈 Latest snapshot ({latest.iloc[0]['fetched_at']}):")
            print(f"     Derivatives: {len(latest):,}")
            print(f"     Unique markets: {latest['market'].nunique()}")
            print(f"     Total open interest: ${latest['open_interest'].sum():,.0f}")
            print(f"     Total 24h volume: ${latest['volume_24h'].sum():,.0f}")

            # Funding rate stats
            perps = latest[latest['contract_type'] == 'perpetual']
            if len(perps) > 0:
                avg_funding = perps['funding_rate'].mean() * 100
                print(f"     Avg funding rate (perps): {avg_funding:.4f}%")

            # Top by OI
            top = latest.nlargest(3, 'open_interest')
            print(f"\n  🏆 Top 3 by Open Interest:")
            for _, row in top.iterrows():
                print(f"     {row['symbol']} on {row['market']}: ${row['open_interest']:,.0f}")

        readme = f"""# CoinGecko Derivatives Data

## Overview
Derivatives market data including funding rates, open interest, and perpetuals

## Data Fields

### Core
- fetched_at: Snapshot timestamp
- market: Exchange name
- symbol: Trading pair
- contract_type: perpetual, futures, etc.

### Prices
- price: Contract price
- index_price: Underlying asset price
- basis: Spread between contract and index

### Trading Metrics
- funding_rate: Funding rate (perpetuals)
- open_interest: Total open positions (USD)
- volume_24h: 24-hour trading volume
- spread: Bid-ask spread

### Changes
- price_change_24h_pct: 24-hour price change

### Metadata
- last_traded_at: Last trade timestamp
- expired_at: Expiration (futures)

## Configuration
- Records: {len(df):,}
- Snapshots: {df["fetched_at"].nunique():,}
- Markets: {df["market"].nunique() if len(df) > 0 else 0}
- Derivatives: {df["symbol"].nunique() if len(df) > 0 else 0}

## Usage

```python
import warpdata as wd

df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Get latest snapshot
latest = df[df["fetched_at"] == df["fetched_at"].max()]

# Top perpetuals by funding rate
perps = latest[latest['contract_type'] == 'perpetual']
high_funding = perps.nlargest(10, 'funding_rate')

# Funding rate arbitrage opportunities
arb = perps[perps['funding_rate'].abs() > 0.001]  # > 0.1%

# Open interest analysis
oi_by_symbol = latest.groupby('symbol')['open_interest'].sum()
```

## Update Frequency
- CoinGecko refreshes: Every 30 seconds
- Auto-skip if data < 5 minutes old
- Historical data: Never deleted (full history preserved)

## Primary Key
- (fetched_at, market, symbol)

## Statistics
- Total records: {len(df):,}
- Time range: {df["fetched_at"].min() if len(df) > 0 else "N/A"} to {df["fetched_at"].max() if len(df) > 0 else "N/A"}
"""

        return RecipeOutput(
            main=[out_file],
            docs={"README.md": readme},
            metadata={
                "records": len(df),
                "snapshots": df["fetched_at"].nunique(),
                "markets": df["market"].nunique() if len(df) > 0 else 0,
                "derivatives": df["symbol"].nunique() if len(df) > 0 else 0,
                "source": "CoinGecko Derivatives API",
            },
        )

    except Exception as e:
        print(f"  ❌ Failed: {e}")
        raise
