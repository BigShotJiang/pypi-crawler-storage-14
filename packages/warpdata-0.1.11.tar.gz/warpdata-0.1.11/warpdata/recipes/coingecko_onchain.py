"""
CoinGecko Onchain token data (prices, volume, market cap, reserves).

Downloads token data from CoinGecko's onchain API endpoints including:
- Simple token prices with full metadata
- Top pools by volume/liquidity
- Network-wide trending tokens

Fully automatic: specify network and optionally top N tokens.
Appends across runs, deduplicates on (timestamp, network, token_address).

API key:
- Requires CoinGecko Pro API key (COINGECKO_API_KEY env var)

Networks supported:
- eth, bsc, polygon_pos, arbitrum, base, avalanche, solana, optimism, fantom, etc.

Example:
    >>> import warpdata as wd
    >>> # Get top 100 tokens on Ethereum with all metadata
    >>> result = wd.run_recipe(
    ...     "coingecko_onchain",
    ...     "warpdata://crypto/coingecko/onchain_eth",
    ...     network="eth",
    ...     top_n=100,
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"

_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def _get_top_pools(network: str, api_key: str, top_n: int = 100, max_workers: int = 10) -> Set[str]:
    """Get top N token addresses from top pools by volume."""
    print(f"  🔄 Discovering top {top_n} tokens from pools...")

    # Get top pools from network trending endpoint
    url = f"{PRO_API_BASE}/onchain/networks/{network}/trending_pools"

    try:
        response = _http_get_json(url, api_key=api_key)
        pools = response.get("data", [])

        token_addresses = set()
        for pool in pools[:top_n * 2]:  # Get 2x to account for quote tokens
            attrs = pool.get("attributes", {})
            base_addr = attrs.get("base_token_address")
            quote_addr = attrs.get("quote_token_address")

            if base_addr:
                token_addresses.add(base_addr.lower())
            if quote_addr:
                token_addresses.add(quote_addr.lower())

            if len(token_addresses) >= top_n:
                break

        result = list(token_addresses)[:top_n]
        print(f"  ✓ Found {len(result)} tokens from trending pools")
        return result

    except Exception as e:
        print(f"  ⚠️  Failed to fetch trending pools: {e}")
        print(f"  ℹ️  Falling back to manual token list")
        return []


def coingecko_onchain(
    ctx: RecipeContext,
    network: str,
    *,
    token_addresses: Optional[List[str]] = None,
    top_n: Optional[int] = None,
    include_market_cap: bool = True,
    include_24hr_vol: bool = True,
    include_24hr_change: bool = True,
    include_reserve: bool = True,
    api_key: Optional[str] = None,
    max_workers: int = 10,
) -> RecipeOutput:
    """
    Create CoinGecko onchain token dataset.

    Fetches token prices and metadata from CoinGecko onchain API.
    100% automatic when using top_n parameter.

    Args:
        ctx: Recipe context
        network: Network ID (eth, bsc, polygon_pos, arbitrum, base, solana, etc.)
        token_addresses: List of token addresses (if None, auto-discover from top_n)
        top_n: Auto-discover top N tokens by volume (default: 100)
        include_market_cap: Include market cap data
        include_24hr_vol: Include 24hr volume
        include_24hr_change: Include 24hr price change
        include_reserve: Include total reserve in USD
        api_key: CoinGecko Pro API key (or set COINGECKO_API_KEY)
        max_workers: Max parallel workers (default: 10)

    Returns:
        RecipeOutput with token price data

    Examples:
        >>> import warpdata as wd
        >>> # Fully automatic - top 100 tokens on Ethereum
        >>> result = wd.run_recipe(
        ...     "coingecko_onchain",
        ...     "warpdata://crypto/coingecko/onchain_eth_top100",
        ...     network="eth",
        ...     top_n=100,
        ...     with_materialize=True
        ... )
        >>>
        >>> # Specific tokens
        >>> result = wd.run_recipe(
        ...     "coingecko_onchain",
        ...     "warpdata://crypto/coingecko/onchain_custom",
        ...     network="eth",
        ...     token_addresses=["0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2"],
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")

    if not api_key:
        raise ValueError("CoinGecko Pro API key required. Set COINGECKO_API_KEY environment variable.")

    print(f"📊 Fetching CoinGecko Onchain Token Data")
    print(f"  Network: {network}")
    print(f"  Max workers: {max_workers}")

    # Auto-discover tokens if needed
    if not token_addresses:
        if not top_n:
            top_n = 100
        token_addresses = _get_top_pools(network, api_key, top_n, max_workers)

        if not token_addresses:
            raise ValueError("Failed to auto-discover tokens. Please provide token_addresses manually.")

    print(f"\n  🪙 Processing {len(token_addresses)} token(s)...")

    # Build query params
    params = {}
    if include_market_cap:
        params["include_market_cap"] = "true"
    if include_24hr_vol:
        params["include_24hr_vol"] = "true"
    if include_24hr_change:
        params["include_24hr_price_change"] = "true"
    if include_reserve:
        params["include_total_reserve_in_usd"] = "true"

    all_records = []
    timestamp = datetime.now(timezone.utc).isoformat()

    # Batch tokens to avoid URL length limits (max ~100 addresses per request)
    batch_size = 100
    batches = [token_addresses[i:i + batch_size] for i in range(0, len(token_addresses), batch_size)]

    def fetch_batch(batch: List[str]) -> List[Dict]:
        try:
            # Join addresses with comma
            addresses = ",".join(batch)
            url = f"{PRO_API_BASE}/onchain/simple/networks/{network}/token_price/{addresses}"

            response = _http_get_json(url, params, api_key=api_key)

            records = []

            # Response structure: data.attributes.{field_name}.{token_address}
            attrs = response.get("data", {}).get("attributes", {})

            # Extract fields
            token_prices = attrs.get("token_prices", {})
            market_caps = attrs.get("market_cap_usd", {})
            volumes = attrs.get("h24_volume_usd", {})
            price_changes = attrs.get("h24_price_change_percentage", {})
            reserves = attrs.get("total_reserve_in_usd", {})

            for token_addr, price_str in token_prices.items():
                token_addr_lower = token_addr.lower()

                # Parse price (comes as string)
                try:
                    price_usd = float(price_str) if price_str else None
                except (ValueError, TypeError):
                    price_usd = None

                record = {
                    "timestamp": timestamp,
                    "network": network,
                    "token_address": token_addr_lower,
                    "price_usd": price_usd,
                }

                # Add optional fields
                if include_market_cap and token_addr_lower in market_caps:
                    try:
                        record["market_cap_usd"] = float(market_caps[token_addr_lower])
                    except (ValueError, TypeError):
                        record["market_cap_usd"] = None

                if include_24hr_vol and token_addr_lower in volumes:
                    try:
                        record["volume_24h_usd"] = float(volumes[token_addr_lower])
                    except (ValueError, TypeError):
                        record["volume_24h_usd"] = None

                if include_24hr_change and token_addr_lower in price_changes:
                    try:
                        record["price_change_24h_pct_usd"] = float(price_changes[token_addr_lower])
                    except (ValueError, TypeError):
                        record["price_change_24h_pct_usd"] = None

                if include_reserve and token_addr_lower in reserves:
                    try:
                        record["total_reserve_usd"] = float(reserves[token_addr_lower])
                    except (ValueError, TypeError):
                        record["total_reserve_usd"] = None

                records.append(record)

            return records

        except Exception as e:
            print(f"    ❌ Batch failed: {e}")
            return []

    # Fetch all batches in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_batch, batch): i for i, batch in enumerate(batches)}

        for future in as_completed(futures):
            batch_idx = futures[future]
            records = future.result()
            all_records.extend(records)
            print(f"    [{len(all_records):,} total] ✓ Batch {batch_idx + 1}/{len(batches)}: {len(records)} tokens")

    if not all_records:
        raise ValueError("No data collected")

    print(f"\n  ✓ Collected {len(all_records):,} token records")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Load existing and append
    out_file = ctx.work_dir / "coingecko_onchain.parquet"
    if out_file.exists():
        try:
            from ..api import load
            existing_df = load(ctx.dataset_id, as_format="pandas")
            print(f"\n  📦 Found existing dataset: {len(existing_df):,} records")

            df = pd.concat([existing_df, df], ignore_index=True)

            # Deduplicate on (timestamp, network, token_address)
            initial_count = len(df)
            df = df.drop_duplicates(subset=["timestamp", "network", "token_address"], keep="last")
            if len(df) < initial_count:
                print(f"  🧹 Removed {initial_count - len(df):,} duplicates")
        except Exception as e:
            print(f"  ℹ️  No existing dataset: {e}")

    # Sort by timestamp desc, then token
    df = df.sort_values(["timestamp", "token_address"], ascending=[False, True])
    df = df.reset_index(drop=True)

    # Save
    df.to_parquet(out_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} records")
    print(f"  📊 Schema: {list(df.columns)}")

    # Show sample stats
    if len(df) > 0:
        latest = df[df["timestamp"] == df["timestamp"].max()]
        print(f"\n  📈 Latest snapshot ({latest.iloc[0]['timestamp']}):")
        print(f"     Tokens: {len(latest):,}")
        if "price_usd" in df.columns:
            print(f"     Price range: ${latest['price_usd'].min():.8f} - ${latest['price_usd'].max():.2f}")
        if "market_cap_usd" in df.columns:
            total_mc = latest["market_cap_usd"].sum()
            print(f"     Total market cap: ${total_mc:,.0f}")

    readme = f"""# CoinGecko Onchain Token Data

## Overview
Token prices and metadata from CoinGecko onchain API

## Configuration
- **Network**: {network}
- **Records**: {len(df):,}
- **Tokens tracked**: {df["token_address"].nunique():,}
- **Snapshots**: {df["timestamp"].nunique():,}

## Schema

{df.dtypes.to_string()}

## Primary Key
- `(timestamp, network, token_address)`

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Get latest prices
latest = df[df["timestamp"] == df["timestamp"].max()]

# Top tokens by market cap
top = latest.nlargest(10, "market_cap_usd")
```

## Statistics
- Total records: {len(df):,}
- Unique tokens: {df["token_address"].nunique():,}
- Time snapshots: {df["timestamp"].nunique():,}
- Network: {network}
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "network": network,
            "tokens": len(token_addresses),
            "records": len(df),
            "snapshots": df["timestamp"].nunique(),
            "source": "CoinGecko Onchain API",
        },
    )
