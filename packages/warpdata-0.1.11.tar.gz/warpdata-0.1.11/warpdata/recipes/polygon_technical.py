"""
Polygon Technical Indicators dataset recipe.

Fetches technical indicators (SMA, EMA, MACD, RSI) for stocks and options.

Source: Polygon.io Technical Indicators API
"""
from pathlib import Path
from typing import List, Optional, Dict, Any
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset


def polygon_technical(
    ctx: RecipeContext,
    tickers: List[str],
    *,
    indicators: Optional[List[str]] = None,
    timespan: str = "day",
    window: Optional[int] = None,
    series_type: str = "close",
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_technical",
) -> RecipeOutput:
    """
    Create Polygon Technical Indicators dataset.

    Downloads technical indicators (SMA, EMA, MACD, RSI) for stocks.

    Args:
        ctx: Recipe context
        tickers: List of tickers to fetch (e.g., ["SPY", "QQQ", "AAPL"])
        indicators: List of indicators to fetch:
            - "sma": Simple Moving Average
            - "ema": Exponential Moving Average
            - "macd": MACD
            - "rsi": Relative Strength Index
            If None, fetches all indicators
        timespan: Timespan for indicators - "day", "minute", "hour", "week", "month"
        window: Window size for indicators (e.g., 50 for 50-day SMA)
            - For SMA/EMA: typically 20, 50, 200
            - For RSI: typically 14
            - For MACD: uses standard 12,26,9
        series_type: Price series - "close", "open", "high", "low"
        start_date: Start date (YYYY-MM-DD, optional)
        end_date: End date (YYYY-MM-DD, optional)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with technical indicator data per ticker and indicator

    Examples:
        >>> import warpdata as wd
        >>> # Fetch 50-day SMA for SPY
        >>> result = wd.run_recipe(
        ...     "polygon_technical",
        ...     "warpdata://technical/spy-sma50",
        ...     tickers=["SPY"],
        ...     indicators=["sma"],
        ...     window=50,
        ...     with_materialize=True
        ... )
        >>> # Fetch all indicators for multiple stocks
        >>> result = wd.run_recipe(
        ...     "polygon_technical",
        ...     "warpdata://technical/tech-stocks",
        ...     tickers=["AAPL", "MSFT", "GOOGL"],
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    if not tickers:
        raise ValueError("Must specify at least one ticker")

    # Default to all indicators if not specified
    if indicators is None:
        indicators = ["sma", "ema", "macd", "rsi"]

    # Set default windows for each indicator if not specified
    default_windows = {
        "sma": 50,
        "ema": 50,
        "rsi": 14,
        "macd": None,  # MACD uses standard 12,26,9
    }

    print(f"📊 Fetching Polygon Technical Indicators")
    print(f"   Tickers: {', '.join(tickers)}")
    print(f"   Indicators: {', '.join(indicators)}")
    print(f"   Timespan: {timespan}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    subdatasets = {}
    metadata = {
        "tickers": tickers,
        "indicators": indicators,
        "timespan": timespan,
        "series_type": series_type,
        "source": "Polygon.io Technical Indicators API",
    }
    if start_date:
        metadata["start_date"] = start_date
    if end_date:
        metadata["end_date"] = end_date

    # Process each indicator
    for indicator in indicators:
        print(f"\n📈 Processing {indicator.upper()}...")

        indicator_dir = raw_dir / indicator
        indicator_dir.mkdir(parents=True, exist_ok=True)

        all_records = []

        # Get window for this indicator
        ind_window = window if window is not None else default_windows.get(indicator)

        # Build params
        params: Dict[str, Any] = {
            "timespan": timespan,
            "series_type": series_type,
        }
        if ind_window is not None:
            params["window"] = ind_window
        if start_date:
            params["timestamp_gte"] = start_date
        if end_date:
            params["timestamp_lte"] = end_date

        # Fetch data for each ticker
        for ticker in tickers:
            window_str = f"_{ind_window}" if ind_window else ""
            print(f"  Fetching {ticker} {indicator.upper()}{window_str}...")
            json_file = indicator_dir / f"{ticker.lower()}{window_str}.json"

            try:
                # Call appropriate ETL method
                if indicator == "sma":
                    result = etl.fetch_stock_sma(
                        ticker=ticker,
                        out=str(json_file),
                        **params
                    )
                elif indicator == "ema":
                    result = etl.fetch_stock_ema(
                        ticker=ticker,
                        out=str(json_file),
                        **params
                    )
                elif indicator == "macd":
                    result = etl.fetch_stock_macd(
                        ticker=ticker,
                        out=str(json_file),
                        **params
                    )
                elif indicator == "rsi":
                    result = etl.fetch_stock_rsi(
                        ticker=ticker,
                        out=str(json_file),
                        **params
                    )
                else:
                    print(f"    ⚠️  Unknown indicator: {indicator}")
                    continue

                print(f"    ✓ {ticker}")

            except Exception as e:
                print(f"    ⚠️  Error: {e}")
                continue

            # Load and process
            if json_file.exists():
                try:
                    with open(json_file) as f:
                        data = json.load(f)

                    # Handle different response structures
                    results = []
                    if isinstance(data, dict) and 'results' in data:
                        results = data['results'].get('values', []) if isinstance(data['results'], dict) else data['results']
                    elif isinstance(data, list):
                        results = data

                    # Add ticker to each record
                    for record in results:
                        if isinstance(record, dict):
                            record['ticker'] = ticker
                            record['indicator'] = indicator
                            if ind_window:
                                record['window'] = ind_window
                            all_records.append(record)

                except Exception as e:
                    print(f"    ⚠️  Failed to parse {json_file}: {e}")

        # Save if we have data
        if all_records:
            print(f"\n  Total records for {indicator}: {len(all_records):,}")

            # Convert to DataFrame
            df = pd.DataFrame(all_records)

            # Convert timestamp if present
            if 'timestamp' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms', errors='coerce')

            # Merge with existing per-indicator subdataset if present
            try:
                from ..api import load
                existing = load(f"{ctx.dataset_id}-{indicator}", as_format="pandas")
                if existing is not None and len(existing) > 0:
                    merged = pd.concat([existing, df], ignore_index=True)
                    key_cols = [c for c in ['timestamp','ticker','indicator','window'] if c in merged.columns]
                    if key_cols:
                        merged = merged.drop_duplicates(subset=key_cols, keep='last')
                    else:
                        merged = merged.drop_duplicates(keep='last')
                    df = merged
                    del existing
            except Exception:
                pass

            # Save to parquet (consolidated per-indicator)
            output_file = ctx.work_dir / f"polygon_technical_{indicator}.parquet"
            df.to_parquet(output_file, index=False)

            print(f"  ✓ Saved to {output_file.name}")

            # Show sample
            if len(df) > 0:
                print(f"\n  📊 Sample data:")
                display_cols = [c for c in ['timestamp', 'ticker', 'value', 'window'] if c in df.columns]
                if display_cols:
                    print(df[display_cols].head(3).to_string())

            # Add to subdatasets
            subdatasets[indicator] = SubDataset(
                name=indicator,
                files=[output_file],
                description=f"{indicator.upper()} indicator for {', '.join(tickers)}",
                metadata={
                    "indicator": indicator,
                    "records": len(df),
                    "window": ind_window,
                    "tickers": tickers,
                    "columns": list(df.columns),
                }
            )
        else:
            print(f"  ⚠️  No data found for {indicator}")

    if not subdatasets:
        raise ValueError("No technical indicator data downloaded")

    # Use first subdataset as main
    main_files = [list(subdatasets.values())[0].files[0]]

    # Generate documentation
    readme = f"""# Polygon Technical Indicators Dataset

## Overview
Technical indicators from Polygon.io

## Configuration
- **Tickers**: {', '.join(tickers)}
- **Indicators**: {', '.join(indicators)}
- **Timespan**: {timespan}
- **Series Type**: {series_type}
{f"- **Date Range**: {start_date} to {end_date}" if start_date and end_date else ""}

## Indicators

### SMA (Simple Moving Average)
Moving average over specified window. Common windows:
- 20-day: Short-term trend
- 50-day: Medium-term trend
- 200-day: Long-term trend

### EMA (Exponential Moving Average)
Weighted moving average giving more weight to recent prices.
More responsive to recent changes than SMA.

### MACD (Moving Average Convergence Divergence)
Trend-following momentum indicator:
- MACD line: 12-day EMA - 26-day EMA
- Signal line: 9-day EMA of MACD line
- Histogram: MACD line - Signal line

### RSI (Relative Strength Index)
Momentum oscillator (0-100):
- > 70: Overbought
- < 30: Oversold
- Typically uses 14-day window

## Schema

Common fields:
- `timestamp` - Date/time of indicator value
- `ticker` - Ticker symbol
- `indicator` - Indicator name
- `value` - Indicator value
- `window` - Window size (for SMA/EMA/RSI)

MACD-specific fields:
- `value` - MACD line
- `signal` - Signal line
- `histogram` - MACD histogram

## Usage

```python
import warpdata as wd
import matplotlib.pyplot as plt

# Load SMA data
sma = wd.load("warpdata://technical/...-sma", as_format="pandas")

# Filter specific ticker
spy_sma = sma[sma['ticker'] == 'SPY']

# Plot indicator over time
spy_sma.plot(x='timestamp', y='value', title='SPY 50-day SMA')

# Combine with price data to find crossovers
# (Load price data separately and merge on timestamp)

# Load multiple indicators for comparison
sma = wd.load("warpdata://technical/...-sma", as_format="pandas")
rsi = wd.load("warpdata://technical/...-rsi", as_format="pandas")
```

## Statistics
"""

    for name, subdataset in subdatasets.items():
        readme += f"\n### {name.upper()}\n"
        readme += f"- Records: {subdataset.metadata.get('records', 0):,}\n"
        if subdataset.metadata.get('window'):
            readme += f"- Window: {subdataset.metadata.get('window')}\n"
        readme += f"- Tickers: {len(tickers)}\n"

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=main_files,
        subdatasets=subdatasets,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
