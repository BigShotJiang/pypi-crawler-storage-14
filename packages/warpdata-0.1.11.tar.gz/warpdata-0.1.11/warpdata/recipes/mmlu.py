"""
MMLU (Massive Multitask Language Understanding) recipe from HF parquet.

Uses CAIS MMLU consolidated parquet files per split under the `all/` folder:
  hf://datasets/cais/mmlu/all/{dev,validation,test}-00000-of-00001.parquet

Schema:
  - question: str
  - subject: str
  - choices_json: str   # JSON array of options
  - n_choices: int
  - answer: int         # index of correct option (0-based)
  - split: str          # dev | validation | test
"""
from __future__ import annotations

from pathlib import Path
from typing import Tuple, List, Dict, Any
import json
import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def _load_split(ctx: RecipeContext, base: str, split: str) -> pd.DataFrame:
    uri = f"{base}/{split}-00000-of-00001.parquet"
    local = ctx.download(uri)
    # Cache filenames lack extension; tell engine it's parquet
    from ..engine.duck import get_engine
    rel = get_engine().read_file(str(local), file_format="parquet")
    df = rel.df()
    # Normalize choices to JSON string and add counts
    def to_json(v):
        try:
            return json.dumps(v, ensure_ascii=False)
        except Exception:
            # Some rows might store as string; keep string wrapped in JSON
            return json.dumps([str(v)], ensure_ascii=False)

    df["choices_json"] = df["choices"].apply(to_json)
    df["n_choices"] = df["choices"].apply(lambda x: len(x) if isinstance(x, (list, tuple)) else 1)
    df["split"] = split
    # Keep only standardized columns
    return df[["question", "subject", "choices_json", "n_choices", "answer", "split"]]


def mmlu(
    ctx: RecipeContext,
    repo_id: str = "cais/mmlu",
    include_splits: Tuple[str, ...] = ("dev", "validation", "test"),
) -> RecipeOutput:
    """
    Create MMLU dataset from HF parquet (CAIS MMLU).
    """
    base = f"hf://datasets/{repo_id}/all"
    parts: List[pd.DataFrame] = []
    for split in include_splits:
        try:
            parts.append(_load_split(ctx, base, split))
        except Exception as e:
            print(f"Warning: failed to load split {split}: {e}")
    if not parts:
        raise RuntimeError("No splits loaded for MMLU")

    df = pd.concat(parts, ignore_index=True)
    out_path = ctx.work_dir / "mmlu.parquet"
    df.to_parquet(out_path, index=False)

    notes = f"""# MMLU

Source: {repo_id}
Splits: {', '.join(include_splits)}
Rows: {len(df)}

Columns:
- question: str
- subject: str
- choices_json: JSON array
- n_choices: int
- answer: int (0-based)
- split: dev|validation|test
"""

    return RecipeOutput(
        main=[out_path],
        metadata={
            "source": repo_id,
            "splits": {s: int((df["split"] == s).sum()) for s in df["split"].unique()},
            "total_rows": int(len(df)),
        },
        docs={"notes.md": notes},
    )

