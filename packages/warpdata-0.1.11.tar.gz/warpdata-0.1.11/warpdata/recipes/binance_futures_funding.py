"""
Binance Futures funding rates dataset recipe.

Fetches funding rate history from Binance USDT-M futures and writes a normalized
Parquet file suitable to join with CoinGecko hourly/daily.

Endpoint: https://fapi.binance.com/fapi/v1/fundingRate

Columns:
- symbol
- funding_time (ms)
- funding_time_iso (UTC ISO string)
- funding_rate (float)

Notes:
- Allows dependency injection of fetch function for tests.
- Uses a global rate limiter (env BINANCE_MIN_INTERVAL, default 0.1s).
"""
from __future__ import annotations

import os
import time
import threading
from typing import Any, Dict, Optional, Callable, List, Tuple
from pathlib import Path
from datetime import datetime, timezone

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput
from concurrent.futures import ThreadPoolExecutor, as_completed
try:
    from tqdm import tqdm  # type: ignore
except Exception:  # pragma: no cover
    tqdm = None


BINANCE_FAPI_BASE = os.environ.get("BINANCE_FAPI_BASE", "https://fapi.binance.com")
_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, timeout: float = 30.0) -> Any:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        # Use a common browser UA to avoid Cloudflare blocks
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    }
    # Attach API key header if provided (not signed; some endpoints require X-MBX-APIKEY)
    api_key = os.environ.get("BINANCE_API_KEY")
    if api_key:
        headers["X-MBX-APIKEY"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")
    global _LAST_REQ_TS
    with _REQ_LOCK:
        # Honor IP limit ~1000 req / 5 min => ~0.3s/request
        min_interval = float(os.environ.get("BINANCE_MIN_INTERVAL", "0.3"))
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.25
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                try:
                    return json.loads(data)
                except Exception:
                    return []
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                # On 403/429, pause a bit longer before retrying in the outer loop
                if code in (403, 429):
                    time.sleep(float(os.environ.get("BINANCE_BACKOFF", "1.0")))
            if attempt < 4:
                time.sleep(backoff)
                backoff *= 2
                continue
            raise


def _build_windows(start_ms: int, end_ms: int, *, step_ms: int) -> List[Tuple[int, int]]:
    windows: List[Tuple[int, int]] = []
    cur = start_ms
    while cur <= end_ms:
        to = min(cur + step_ms - 1, end_ms)
        windows.append((cur, to))
        cur = to + 1
    return windows


def binance_futures_funding(
    ctx: RecipeContext,
    *,
    symbols: List[str],
    start_time: int,
    end_time: int,
    limit: int = 1000,
    max_workers: int = 8,
    fetch_fn: Optional[Callable[[str, Optional[Dict[str, Any]]], Any]] = None,
) -> RecipeOutput:
    """
    Fetch Binance USDT-M futures funding rate history and write Parquet.

    Args:
        ctx: Recipe context
        symbols: List of symbols (e.g., ['BTCUSDT'])
        start_time: Start time (ms)
        end_time: End time (ms)
        limit: Max records per request (<=1000)
        max_workers: Concurrency for requests
        fetch_fn: Optional HTTP fetch override
    """
    fetch = fetch_fn or (lambda url, params: _http_get_json(url, params))

    # Funding occurs every 8 hours => step per window = 8h * limit
    step_ms = 8 * 60 * 60 * 1000 * min(limit, 1000)
    windows = _build_windows(start_time, end_time, step_ms=step_ms)

    rows: List[Dict[str, Any]] = []

    def fetch_one(sym: str, ws: int, we: int) -> List[Dict[str, Any]]:
        # Some regions require the futures/data endpoint; try both
        url1 = f"{BINANCE_FAPI_BASE}/fapi/v1/fundingRate"
        url2 = f"{BINANCE_FAPI_BASE}/futures/data/fundingRate"
        params = {"symbol": sym, "startTime": ws, "endTime": we, "limit": min(limit, 1000)}
        try:
            data = fetch(url1, params)
        except Exception:
            try:
                data = fetch(url2, params)
            except Exception:
                # Give up on this chunk gracefully
                return []
        out: List[Dict[str, Any]] = []
        for d in data or []:
            try:
                ft = int(d.get("fundingTime"))
                rate = float(d.get("fundingRate"))
            except Exception:
                continue
            out.append(
                {
                    "symbol": sym,
                    "funding_time": ft,
                    "funding_time_iso": datetime.fromtimestamp(ft/1000.0, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
                    "funding_rate": rate,
                }
            )
        return out

    tasks = [(sym, ws, we) for sym in symbols for ws, we in windows]
    total = len(tasks)
    print(f"  ⏱️ Funding: {len(symbols)} symbols × {len(windows)} windows → {total} requests")
    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futs = [pool.submit(fetch_one, s, ws, we) for s, ws, we in tasks]
        pbar = tqdm(total=total, desc="funding", leave=False, mininterval=0.5) if (tqdm and total > 10) else None
        for i, fut in enumerate(as_completed(futs), 1):
            try:
                rows.extend(fut.result() or [])
            except Exception as e:
                # Log and continue on 403/429 or other errors
                print(f"    chunk failed: {type(e).__name__}: {str(e)[:120]}")
            finally:
                if pbar:
                    pbar.update(1)
                elif i % 50 == 0 or i == total:
                    print(f"    [{i}/{total}] funding chunks done; rows collected: {len(rows)}")
        if pbar:
            pbar.close()

    df = pd.DataFrame(rows)

    out_file = ctx.work_dir / "binance_futures_funding.parquet"
    out_file.parent.mkdir(parents=True, exist_ok=True)

    # Append + dedup
    import fcntl
    lock_file = out_file.with_suffix('.lock')
    lock_file.touch(exist_ok=True)
    with open(lock_file, 'r') as lf:
        fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
        if out_file.exists():
            try:
                df_old = pd.read_parquet(out_file)
                df = pd.concat([df_old, df], ignore_index=True)
            except Exception:
                pass
        before = len(df)
        df = df.drop_duplicates(subset=["symbol", "funding_time"], keep="last")
        after = len(df)
        if before != after:
            print(f"🧹 Funding dedup: {before} → {after}")
        df.to_parquet(out_file, index=False)

    return RecipeOutput(
        main=[out_file],
        metadata={"source": "binance-futures", "endpoint": "fundingRate", "rows": len(df)},
    )
