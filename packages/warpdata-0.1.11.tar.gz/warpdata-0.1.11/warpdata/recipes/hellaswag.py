"""
HellaSwag dataset recipe.

HellaSwag is a dataset for commonsense natural language inference.
Given a context, the task is to select the most plausible continuation from 4 options.

Source: https://huggingface.co/datasets/Rowan/hellaswag
Paper: https://arxiv.org/abs/1905.07830

Splits:
- train: 39,905 examples
- validation: 10,042 examples
- test: 10,003 examples (labels not public)
"""
from pathlib import Path
from typing import Iterator, Dict, Any, Tuple
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def hellaswag(
    ctx: RecipeContext,
    repo_id: str = "Rowan/hellaswag",
    splits: Tuple[str, ...] = ("train", "validation", "test"),
) -> RecipeOutput:
    """
    Create HellaSwag commonsense reasoning dataset.

    Downloads HellaSwag from HuggingFace and structures it for warpdata.
    Each example has a context and 4 possible endings, with the correct
    ending labeled (except for test split where labels are not public).

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("train", "validation", "test")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - ind: int - Example index
        - activity_label: str - Activity category
        - ctx: str - Context (situation description)
        - ctx_a: str - First part of context
        - ctx_b: str - Second part of context
        - endings: list[str] - All 4 possible endings
        - ending_0: str - First ending
        - ending_1: str - Second ending
        - ending_2: str - Third ending
        - ending_3: str - Fourth ending
        - label: int - Correct ending index (0-3, null for test split)
        - correct_ending: str - The correct ending text
        - source_id: str - Source from ActivityNet/WikiHow
        - split: str - train/validation/test
        - split_type: str - "indomain" or "zeroshot"

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "hellaswag",
        ...     "warpdata://reasoning/hellaswag",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://reasoning/hellaswag", as_format="pandas")
        >>> # Filter to only validation split
        >>> val = df[df['split'] == 'validation']
    """
    from datasets import load_dataset

    print(f"Loading HellaSwag from {repo_id}...")

    # Load all requested splits
    all_records = []

    for split_name in splits:
        print(f"  Loading {split_name} split...")
        ds = load_dataset(repo_id, split=split_name)

        print(f"  Processing {len(ds):,} examples...")

        for example in ds:
            # Parse label (may be string or int, null for test)
            label = None
            if 'label' in example and example['label'] is not None:
                try:
                    label = int(example['label'])
                except (ValueError, TypeError):
                    label = None

            # Extract endings
            endings = example['endings']

            record = {
                'ind': int(example['ind']),
                'activity_label': str(example['activity_label']),
                'ctx': str(example['ctx']),
                'ctx_a': str(example['ctx_a']) if example.get('ctx_a') else None,
                'ctx_b': str(example['ctx_b']) if example.get('ctx_b') else None,
                'endings': endings,  # Keep as list
                'ending_0': endings[0] if len(endings) > 0 else None,
                'ending_1': endings[1] if len(endings) > 1 else None,
                'ending_2': endings[2] if len(endings) > 2 else None,
                'ending_3': endings[3] if len(endings) > 3 else None,
                'label': label,
                'correct_ending': endings[label] if label is not None and 0 <= label < len(endings) else None,
                'source_id': str(example['source_id']),
                'split': split_name,
                'split_type': str(example['split_type']) if example.get('split_type') else None,
            }

            all_records.append(record)

    print(f"\nTotal examples: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "hellaswag.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_examples': len(df),
            'splits': df['split'].value_counts().to_dict(),
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
