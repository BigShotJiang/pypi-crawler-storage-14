"""
Fashion-MNIST dataset recipe.

Zalando's article images dataset - drop-in replacement for MNIST.

Source: https://huggingface.co/datasets/fashion_mnist
Paper: https://arxiv.org/abs/1708.07747

Splits:
- train: 60,000 images
- test: 10,000 images

Classes (10):
T-shirt/top, Trouser, Pullover, Dress, Coat, Sandal, Shirt, Sneaker, Bag, Ankle boot
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

try:
    from datasets import load_dataset
except Exception as e:
    raise RuntimeError(
        "The 'datasets' package is required for the Fashion-MNIST recipe.\n"
        "Install with: pip install datasets\n"
        f"Import error: {e}"
    )

from ..api.recipes import RecipeContext
from .base import RecipeOutput

FASHION_MNIST_LABELS = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot",
]


def _iter_examples(ds, split_name: str, max_samples: Optional[int] = None) -> Iterable[Dict]:
    """Yield normalized Fashion-MNIST records from a HF split."""
    for idx, ex in enumerate(ds):
        if max_samples is not None and idx >= max_samples:
            break

        lbl = int(ex["label"])
        lbl_name = FASHION_MNIST_LABELS[lbl] if 0 <= lbl < len(FASHION_MNIST_LABELS) else str(lbl)

        yield {
            "idx": idx,
            "split": split_name,
            "label": lbl,
            "label_name": lbl_name,
        }


def fashion_mnist(
    ctx: RecipeContext,
    repo_id: str = "fashion_mnist",
    splits: Tuple[str, ...] = ("train", "test"),
    max_samples: Optional[int] = None,
) -> RecipeOutput:
    """
    Build Fashion-MNIST dataset metadata table via HuggingFace.

    Args:
        ctx: Recipe context
        repo_id: HF datasets repo id (default: 'fashion_mnist')
        splits: Which splits to include (default: ('train','test'))
        max_samples: Optional cap per split for quick tests

    Returns:
        RecipeOutput with a single Parquet file
    """
    print(f"📚 Loading Fashion-MNIST from '{repo_id}'...")
    if max_samples:
        print(f"   Note: limiting to {max_samples:,} samples per split")

    all_records: List[Dict] = []

    for split_name in splits:
        print(f"  • Split: {split_name}")
        if max_samples is not None:
            ds = load_dataset(repo_id, split=split_name, streaming=True)
        else:
            ds = load_dataset(repo_id, split=split_name, streaming=False)

        for rec in _iter_examples(ds, split_name=split_name, max_samples=max_samples):
            all_records.append(rec)
        print(f"    added {sum(1 for r in all_records if r['split']==split_name):,} rows")

    if not all_records:
        raise RuntimeError("No rows parsed for Fashion-MNIST")

    df = pd.DataFrame(all_records)
    out_path = ctx.work_dir / "fashion_mnist.parquet"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)

    split_counts = df["split"].value_counts().to_dict()
    n_classes = int(df["label"].nunique()) if "label" in df.columns else 0

    print("✅ Fashion-MNIST Parquet written:")
    print(f"   {out_path}")
    print(f"   rows={len(df):,}, classes={n_classes}, splits={split_counts}")

    raw_paths: List[str] = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_paths.append(str(hf_cache))

    metadata = {
        "source": repo_id,
        "total_rows": len(df),
        "splits": split_counts,
        "num_classes": n_classes,
        "class_names": FASHION_MNIST_LABELS,
        "notes": "Metadata-only table (no image bytes). Use raw HF dataset for images if needed.",
    }

    return RecipeOutput(
        main=[out_path],
        metadata=metadata,
        raw_data=[Path(p) for p in raw_paths],
    )
