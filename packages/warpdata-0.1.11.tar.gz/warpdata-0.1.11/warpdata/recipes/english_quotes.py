"""
English Quotes dataset recipe.

A collection of famous English quotes with authors and topic tags.

Source: https://huggingface.co/datasets/Abirate/english_quotes

Contains:
- train: 2,508 quotes

Categories include inspirational, life, love, philosophy, humor, and more.
"""
from pathlib import Path
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def english_quotes(
    ctx: RecipeContext,
    repo_id: str = "Abirate/english_quotes",
) -> RecipeOutput:
    """
    Create English Quotes dataset.

    Downloads English Quotes from HuggingFace. Each entry contains a quote,
    its author, and topic tags.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - quote: str - The quote text
        - author: str - Quote author
        - tags: list - Topic tags (inspirational, life, love, etc.)

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "english_quotes",
        ...     "warpdata://text/english-quotes",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://text/english-quotes", as_format="pandas")
        >>> # Filter by author
        >>> wilde = df[df['author'] == 'Oscar Wilde']
    """
    print(f"Loading English Quotes from {repo_id}...")

    # Load dataset
    print(f"  Loading train split...")
    ds = load_dataset(repo_id, split="train")

    print(f"  Processing {len(ds):,} quotes...")

    # Process records
    all_records = []

    for example in ds:
        record = {
            'quote': str(example.get('quote', '')),
            'author': str(example.get('author', '')),
            'tags': example.get('tags', []),
        }
        all_records.append(record)

    print(f"\nTotal quotes: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "english_quotes.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")

    if 'author' in df.columns:
        print(f"\nTop authors:")
        print(df['author'].value_counts().head(10).to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_quotes': len(df),
            'top_authors': df['author'].value_counts().head(10).to_dict() if 'author' in df.columns else {},
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
