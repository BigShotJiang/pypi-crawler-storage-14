"""
GSM8K Dataset Recipe with pysymbolizer integration.

Downloads GSM8K from Hugging Face Hub, extracts arithmetic expressions,
and optionally encodes them symbolically with Gödel codes.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Tuple
import re
import json

import numpy as np

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


def _extract_final_answer(answer_text: str) -> Tuple[str, float | None]:
    """Extract final answer from GSM8K format: #### 42"""
    # final answer format: "#### 72"
    m = re.search(r"####\s*([+-]?\d+(?:\.\d+)?)", answer_text)
    if not m:
        return "", None
    txt = m.group(1)
    try:
        val = float(txt)
        # use int when exact
        if val.is_integer():
            val = int(val)
        return txt, val
    except Exception:
        return txt, None


def _extract_exprs(answer_text: str) -> List[Tuple[str, str]]:
    """
    Extract expressions from GSM8K answer text.

    Steps often like: <<48/2=24>> or <<48+24=72>>
    Returns list of (expr, result_str) tuples.
    """
    # steps often like: <<48/2=24>> or <<48+24=72>>
    # return list of (expr, result_str)
    pairs = re.findall(r"<<\s*([^=<>\s][^=<>\n]*?)\s*=\s*([^<>\n]+?)\s*>>", answer_text)
    # sanitize whitespace
    clean = []
    for lhs, rhs in pairs:
        clean.append((lhs.strip(), rhs.strip()))
    return clean


def gsm8k(
    ctx: RecipeContext,
    repo_id: str = "openai/gsm8k",
    revision: str = "main",
    splits: Tuple[str, ...] = ("train", "test"),
    symbolize: bool = True,
    codebook_m: int | None = 16,  # Gödel code length (strict Hamming, small and fast)
) -> RecipeOutput:
    """
    Create GSM8K dataset with optional symbolic encoding via pysymbolizer.

    Downloads GSM8K JSONL files from HuggingFace Hub, extracts arithmetic
    step expressions, and optionally encodes them with Gödel codes for
    strict Hamming geometry.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        revision: Git revision (branch/tag/commit)
        splits: Which splits to include ("train", "test")
        symbolize: If True, use pysymbolizer to encode expressions
        codebook_m: Gödel codebook length (for strict Hamming distance)

    Returns:
        RecipeOutput with main dataset and steps subdataset

    Main dataset columns:
        - id: sample ID
        - split: train or test
        - question: problem text
        - answer: full solution text
        - final_answer_text: extracted final answer string
        - final_answer_value: parsed numeric final answer
        - n_exprs: number of extracted step expressions

    Steps subdataset columns:
        - id: sample ID (foreign key to main)
        - split: train or test
        - step_idx: step index within sample
        - expr: expression string (e.g., "16-3-4")
        - result: result string (e.g., "9")
        - tokens_json: JSON array of symbolic tokens (if symbolize=True)
        - bits_hex: hex-encoded Gödel bitstring (if symbolize=True)

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "gsm8k",
        ...     "warpdata://math/gsm8k",
        ...     with_materialize=True
        ... )
        >>> main = wd.load("warpdata://math/gsm8k", as_format="pandas")
        >>> steps = wd.load("warpdata://math/gsm8k-steps", as_format="pandas")
    """
    try:
        import sympy as sp
        if symbolize:
            from pysymbolizer import adapter_rmode_from_corpus
    except Exception as e:
        if symbolize:
            raise RuntimeError(
                "pysymbolizer + sympy are required for symbolize=True. "
                "pip install pysymbolizer sympy"
            ) from e
        else:
            # If not symbolizing, we still need sympy for basic parsing
            import sympy as sp

    print(f"📊 Processing GSM8K from {repo_id}@{revision}")

    rows_main: List[Dict[str, Any]] = []
    steps_rows: List[Dict[str, Any]] = []
    corpus_exprs: List[sp.Expr] = []  # to build alphabet
    # collect per-row expressions for later encoding
    row_expr_buckets: Dict[Tuple[str, int], List[Tuple[str, str]]] = {}

    sample_id = 0
    for split in splits:
        # HF parquet path
        # Will use your local HF cache automatically via fsspec (hf://)
        src = f"hf://datasets/{repo_id}/{revision}/{split}-00000-of-00001.parquet"
        print(f"   Downloading {split} split from HF Hub...")
        local = ctx.download(src)
        rel = ctx.engine.conn.read_parquet(str(local))
        df = rel.df()  # columns: question, answer

        print(f"   Processing {len(df)} samples from {split}...")
        for _, r in df.iterrows():
            q = str(r.get("question", ""))
            a = str(r.get("answer", ""))

            final_txt, final_val = _extract_final_answer(a)
            exprs = _extract_exprs(a)

            rows_main.append({
                "id": sample_id,
                "split": split,
                "question": q,
                "answer": a,
                "final_answer_text": final_txt,
                "final_answer_value": final_val,
                "n_exprs": len(exprs),
            })

            key = (split, sample_id)
            row_expr_buckets[key] = exprs

            if symbolize and exprs:
                for (lhs, _rhs) in exprs:
                    try:
                        e = sp.sympify(lhs)
                        corpus_exprs.append(e)
                    except Exception:
                        # Skip expressions that can't be parsed
                        pass

            sample_id += 1

    print(f"   Total samples: {len(rows_main)}")
    print(f"   Total expressions: {sum(len(v) for v in row_expr_buckets.values())}")

    # Build a symbolic adapter if requested and we have any expressions
    adapter = None
    if symbolize and corpus_exprs:
        print(f"   Building symbolic adapter from {len(corpus_exprs)} expressions...")
        # R-mode convenience adapter; includes UNK bucket and strict Hamming geometry
        adapter = adapter_rmode_from_corpus(
            corpus_exprs,
            scheme="hadamard",
            m=codebook_m,
        )
        print(f"   Adapter: {adapter}")

    # Build steps subdataset (one row per expression)
    print("   Encoding step expressions...")
    for (split, sid), expr_list in row_expr_buckets.items():
        for idx, (expr_str, result_str) in enumerate(expr_list):
            tokens_json = None
            bits_hex = None

            if adapter is not None:
                try:
                    e = sp.sympify(expr_str)
                    # pack_to_bytes for compact storage
                    packed = adapter.encode_expr(e, flatten=False, pack_to_bytes=True)
                    # tokens via decode to ensure same vocabulary
                    toks = adapter.decode_expr_tokens(adapter.encode_expr(e, flatten=False))
                    tokens_json = json.dumps(toks, ensure_ascii=False)
                    # packed is uint8 array; store as hex
                    bits_hex = np.asarray(packed).tobytes().hex()
                except Exception:
                    # leave tokens/bits as None if encoding fails
                    pass

            steps_rows.append({
                "id": sid,
                "split": split,
                "step_idx": idx,
                "expr": expr_str,
                "result": result_str,
                "tokens_json": tokens_json,
                "bits_hex": bits_hex,
            })

    print(f"   Steps rows: {len(steps_rows)}")

    # Write main
    import pandas as pd
    main_df_rel = ctx.engine.conn.from_df(pd.DataFrame(rows_main))
    main_out = ctx.work_dir / "main.parquet"
    ctx.write_parquet(main_df_rel, main_out)
    print(f"   Wrote main dataset: {main_out}")

    # Write steps if any
    subdatasets = {}
    if steps_rows:
        steps_df_rel = ctx.engine.conn.from_df(pd.DataFrame(steps_rows))
        steps_out = ctx.work_dir / "steps.parquet"
        ctx.write_parquet(steps_df_rel, steps_out)
        print(f"   Wrote steps subdataset: {steps_out}")

        subdatasets["steps"] = SubDataset(
            name="steps",
            files=[steps_out],
            description=(
                "One row per extracted arithmetic step with optional symbolic "
                "tokens and Gödel encoding."
            ),
            filter_sql=None,
            metadata={"symbolize": bool(adapter is not None)},
        )

    # Generate documentation
    notes = f"""# GSM8K (Grade School Math 8K)

## Overview
Grade School Math dataset with 8.5K linguistically diverse grade school math word problems.

## Configuration
- **Splits**: {', '.join(splits)}
- **Total samples**: {len(rows_main)}
- **Total expressions**: {len(steps_rows)}
- **Symbolization**: {bool(adapter is not None)}
- **Source**: {repo_id}@{revision}

## Splits
"""
    for split in splits:
        count = sum(1 for r in rows_main if r["split"] == split)
        notes += f"- **{split}**: {count} samples\n"

    notes += f"""
## Structure

### Main Dataset
Each row represents one problem with:
- `id`: unique sample ID
- `split`: train or test
- `question`: problem statement
- `answer`: full solution with step-by-step reasoning
- `final_answer_text`: extracted final answer (format: #### N)
- `final_answer_value`: parsed numeric value
- `n_exprs`: number of extracted step expressions

### Steps Subdataset
One row per arithmetic step expression:
- `id`: sample ID (links to main dataset)
- `split`: train or test
- `step_idx`: step index within sample
- `expr`: expression string (e.g., "16-3-4")
- `result`: result string (e.g., "9")
"""

    if adapter is not None:
        notes += f"""- `tokens_json`: JSON array of canonical symbolic tokens
- `bits_hex`: hex-encoded Gödel bitstring for Hamming geometry

### Symbolic Encoding
Expressions are canonicalized and encoded using pysymbolizer with:
- **Scheme**: Hadamard (strict Hamming distance)
- **Code length**: {codebook_m} bits per token
- **Vocabulary size**: {adapter.godel.k} tokens
- **Config hash**: {adapter.to_config().get('config_hash', 'unknown')}
"""

    notes += """
## Citation
```
@article{cobbe2021training,
  title={Training Verifiers to Solve Math Word Problems},
  author={Cobbe, Karl and Kosaraju, Vineet and Bavarian, Mohammad and Chen, Mark and Jun, Heewoo and Kaiser, Lukasz and Plappert, Matthias and Tworek, Jerry and Hilton, Jacob and Nakano, Reiichiro and Hesse, Christopher and Schulman, John},
  journal={arXiv preprint arXiv:2110.14168},
  year={2021}
}
```
"""

    readme = f"""# GSM8K Dataset

## Quick Start

```python
import warpdata as wd

# Load main dataset
main = wd.load("warpdata://math/gsm8k", as_format="pandas")

# Load steps subdataset
steps = wd.load("warpdata://math/gsm8k-steps", as_format="pandas")

# Filter by split
train = main[main["split"] == "train"]
test = main[main["split"] == "test"]
```

## Statistics
- Total problems: {len(rows_main)}
- Extracted expressions: {len(steps_rows)}
- Symbolically encoded: {sum(1 for r in steps_rows if r.get('tokens_json') is not None)}
"""

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[main_out],
        subdatasets=subdatasets,
        docs={"notes.md": notes, "README.md": readme},
        metadata={
            "repo_id": repo_id,
            "revision": revision,
            "symbolize": bool(adapter is not None),
            "total_samples": len(rows_main),
            "total_expressions": len(steps_rows),
        },
        raw_data=raw_data_paths,
    )
