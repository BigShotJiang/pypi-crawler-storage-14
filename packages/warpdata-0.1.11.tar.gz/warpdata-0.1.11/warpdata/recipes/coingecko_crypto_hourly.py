"""
Coingecko Crypto HOURLY dataset recipe.

Downloads historical HOURLY data for major crypto assets from the Coingecko API
and stores them in a single combined Parquet file.

Data fields per hour and asset:
- timestamp (YYYY-MM-DD HH:00:00, UTC)
- coin_id (coingecko id)
- symbol
- name
- price
- market_cap
- total_volume

The recipe appends across runs and deduplicates on (timestamp, coin_id).

API key:
- Reads key from env: COINGECKO_API_KEY
- Pro API key for x-cg-pro-api-key header

Notes:
- CoinGecko returns HOURLY data for time ranges between 2-90 days
- For longer periods, use 90-day windows
- Uses /coins/{id}/market_chart/range with ≤90 day windows to get hourly granularity
"""
from __future__ import annotations

import json
import math
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
import threading
from datetime import datetime, timezone, timedelta, date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PUBLIC_API_BASE = "https://api.coingecko.com/api/v3"
PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"


def _api_base(api_key: Optional[str]) -> str:
    """Return appropriate API endpoint.

    Pro API keys require pro-api.coingecko.com.
    Free tier uses api.coingecko.com.
    """
    return PRO_API_BASE if api_key else PUBLIC_API_BASE


def _ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def _sanitize_numeric_fields(df: 'pd.DataFrame') -> 'pd.DataFrame':
    """Sanitize numeric columns for hourly dataset.

    - price: numeric; negatives -> NaN
    - market_cap: numeric; negatives/zeros -> NaN
    - total_volume: numeric; negatives/zeros -> NaN
    """
    import pandas as pd  # local import to avoid hard dep at top for type checkers
    cols = [c for c in ["price", "market_cap", "total_volume"] if c in df.columns]
    if not cols:
        return df
    for c in cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
        df.loc[df[c] < 0, c] = pd.NA
    for c in ["market_cap", "total_volume"]:
        if c in df.columns:
            df.loc[df[c] == 0, c] = pd.NA
    return df


_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    # Attach Pro API key header when key is provided (per official CoinGecko docs)
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")
    # Basic global rate limit across threads
    global _LAST_REQ_TS
    with _REQ_LOCK:
        # Allow tuning via env to avoid 429s/403s
        # Pro API: 500 req/min = 0.12s between requests (use 0.15s to be safe)
        # Free API: ~50 req/min = 1.2s between requests (use 1.5s to be safe)
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()
    # Simple retry/backoff for transient/limit errors
    backoff = 0.5
    last_error = None
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                try:
                    return json.loads(data)
                except Exception:
                    return {"raw": data.decode("utf-8", errors="replace")}
        except Exception as e:
            last_error = e
            import urllib.error

            # Handle HTTPError
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                # Fallback to public API on Demo key error (error_code 10011)
                if code == 400 and PRO_API_BASE in url and "10011" in body:
                    alt = url.replace(PRO_API_BASE, PUBLIC_API_BASE)
                    alt_req = urllib.request.Request(alt, headers=headers, method="GET")
                    try:
                        with urllib.request.urlopen(alt_req, timeout=timeout) as r2:
                            data2 = r2.read()
                            return json.loads(data2)
                    except Exception as fallback_err:
                        err_msg = f"{type(fallback_err).__name__}: {str(fallback_err)[:200]}"
                        raise RuntimeError(f"Demo key requires public endpoint, fallback to {alt} failed: {err_msg}")

                # Retry on 429/403/5xx with backoff
                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    # Last attempt - raise with details
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                # Fallback to public API on auth/forbidden
                if code in (401, 403) and PRO_API_BASE in url:
                    alt = url.replace(PRO_API_BASE, PUBLIC_API_BASE)
                    # Keep the same headers (including User-Agent) to avoid Cloudflare blocks
                    alt_req = urllib.request.Request(alt, headers=headers, method="GET")
                    try:
                        with urllib.request.urlopen(alt_req, timeout=timeout) as r2:
                            data2 = r2.read()
                            return json.loads(data2)
                    except Exception as fallback_err:
                        # Fallback failed - raise original error with context
                        raise RuntimeError(f"HTTP {code} for {full} (fallback also failed) :: {body}")

                # Non-retryable HTTP error
                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            # Non-HTTP error (timeout, connection error, etc.)
            if attempt < 4:
                # Log the error type for debugging
                print(f"    Attempt {attempt+1}/5 failed: {type(e).__name__}: {str(e)[:100]}")
                time.sleep(backoff)
                backoff *= 2
                continue

            # Last attempt - raise with full context
            raise RuntimeError(f"{type(e).__name__} after {attempt+1} attempts: {str(e)}")


def _to_epoch_seconds(d: str) -> int:
    # d is YYYY-MM-DD at 00:00:00 UTC
    dt = datetime.fromisoformat(d).replace(tzinfo=timezone.utc)
    return int(dt.timestamp())

def _to_epoch_seconds_end_inclusive(d: str) -> int:
    """Inclusive end-of-day timestamp for range queries.

    Ensures `to` > `from` even when querying a single day window
    (start == end), which otherwise returns empty arrays from
    CoinGecko /market_chart/range.
    """
    dt = datetime.fromisoformat(d).replace(tzinfo=timezone.utc) + timedelta(days=1) - timedelta(seconds=1)
    return int(dt.timestamp())


def _today_iso() -> str:
    return date.today().isoformat()


def _get_top_coins(vs_currency: str, top_n: int, *, api_key: Optional[str], cache_dir: Path) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    per_page = 250
    pages = math.ceil(top_n / per_page)

    for page in range(1, pages + 1):
        params = {
            "vs_currency": vs_currency,
            "order": "market_cap_desc",
            "per_page": per_page,
            "page": page,
            "sparkline": "false",
        }
        url = f"{_api_base(api_key)}/coins/markets"
        js = _http_get_json(url, params, api_key=api_key)

        # Better error handling with more diagnostic info
        if js is None:
            raise RuntimeError(f"Unexpected response from /coins/markets: None (API may be down or rate limited)")
        if not isinstance(js, list):
            # Show the actual response type and content
            resp_type = type(js).__name__
            resp_preview = str(js)[:300] if js else "empty"
            raise RuntimeError(f"Unexpected response from /coins/markets: expected list, got {resp_type}: {resp_preview}")

        out.extend(js)
        # Small courtesy sleep to avoid hammering
        time.sleep(0.15)

    # Cache the list
    _ensure_dir(cache_dir)
    (cache_dir / f"coins_markets_{vs_currency}.json").write_text(json.dumps(out[:top_n]), encoding="utf-8")
    return out[:top_n]


def _get_coins_list(*, api_key: Optional[str]) -> List[Dict[str, Any]]:
    url = f"{_api_base(api_key)}/coins/list"
    js = _http_get_json(url, None, api_key=api_key)
    if not isinstance(js, list):
        raise RuntimeError(f"Unexpected response from /coins/list: {js}")
    return js


def _get_market_chart(coin_id: str, vs_currency: str, *, api_key: Optional[str], days: Optional[str], start_date: Optional[str], end_date: Optional[str], cache_dir: Path) -> Dict[str, Any]:
    # Cache path naming
    if days:
        cache_file = cache_dir / f"{coin_id}_market_chart_{vs_currency}_{days}.json"
    else:
        cache_file = cache_dir / f"{coin_id}_market_chart_{vs_currency}_{start_date}_to_{end_date}.json"

    if cache_file.exists():
        try:
            cached = json.loads(cache_file.read_text(encoding="utf-8"))
            # Validate shape and non-empty
            if isinstance(cached, dict) and any(k in cached for k in ("prices","market_caps","total_volumes")):
                p = cached.get("prices") or []
                m = cached.get("market_caps") or []
                v = cached.get("total_volumes") or []
                if len(p) > 0 or len(m) > 0 or len(v) > 0:
                    return cached
            # Invalid/empty cache; refetch
        except Exception:
            pass

    params: Dict[str, Any]
    url: str
    params: Dict[str, Any]
    if days:
        allowed_daily = {"1", "7", "14", "30", "90", "180"}
        use_pro = (_api_base(api_key) == PRO_API_BASE and api_key)
        # For Pro and days='max', we prefer chunked range with daily interval to get full daily history
        if use_pro and days.lower() == "max":
            return _get_market_chart_range_daily_chunked(
                coin_id, vs_currency, api_key=api_key,
                start_date="2010-01-01", end_date=_today_iso(), cache_dir=cache_dir
            )
        url = f"{_api_base(api_key)}/coins/{coin_id}/market_chart"
        params = {"vs_currency": vs_currency, "days": days}
        if days in allowed_daily and use_pro:
            params["interval"] = "daily"
    else:
        url = f"{_api_base(api_key)}/coins/{coin_id}/market_chart/range"
        # Default to full history if not provided
        sd = start_date or "2010-01-01"
        ed = end_date or _today_iso()
        params = {
            "vs_currency": vs_currency,
            "from": _to_epoch_seconds(sd),
            # Include the full end day to avoid empty responses
            "to": _to_epoch_seconds_end_inclusive(ed),
        }
    js = _http_get_json(url, params, api_key=api_key)

    # Validate response structure before caching (avoid caching empties)
    is_valid = (
        isinstance(js, dict)
        and any(k in js for k in ("prices", "market_caps", "total_volumes"))
    )
    non_empty = False
    if is_valid:
        p = js.get("prices") or []
        m = js.get("market_caps") or []
        v = js.get("total_volumes") or []
        non_empty = (len(p) > 0 or len(m) > 0 or len(v) > 0)

    if is_valid and non_empty:
        # Write cache only for valid responses
        _ensure_dir(cache_dir)
        cache_file.write_text(json.dumps(js), encoding="utf-8")

    # Courtesy sleep
    time.sleep(0.15)
    return js


def _get_market_chart_range_daily_chunked(
    coin_id: str,
    vs_currency: str,
    *,
    api_key: Optional[str],
    start_date: str,
    end_date: str,
    cache_dir: Path,
) -> Dict[str, Any]:
    """Fetch full daily history by stitching 180-day range windows (Pro key required)."""
    start_dt = datetime.fromisoformat(start_date).date()
    end_dt = datetime.fromisoformat(end_date).date()

    prices_all: List[List[float]] = []
    caps_all: List[List[float]] = []
    vols_all: List[List[float]] = []

    current = start_dt
    step = 180
    while current <= end_dt:
        window_end = min(current + timedelta(days=step), end_dt)
        # Cache per window
        win_cache = cache_dir / f"{coin_id}_range_{current.isoformat()}_{window_end.isoformat()}_{vs_currency}.json"
        if win_cache.exists():
            try:
                js = json.loads(win_cache.read_text(encoding="utf-8"))
                # Discard cached empties to allow refetch after logic fixes
                if isinstance(js, dict):
                    p = js.get("prices") or []
                    m = js.get("market_caps") or []
                    v = js.get("total_volumes") or []
                    if not (len(p) > 0 or len(m) > 0 or len(v) > 0):
                        js = None
            except Exception:
                js = None
        else:
            url = f"{_api_base(api_key)}/coins/{coin_id}/market_chart/range"
            params = {
                "vs_currency": vs_currency,
                "from": _to_epoch_seconds(current.isoformat()),
                # Include the full `window_end` day
                "to": _to_epoch_seconds_end_inclusive(window_end.isoformat()),
            }
            js = _http_get_json(url, params, api_key=api_key)
            # Only cache non-empty responses
            if isinstance(js, dict):
                p = js.get("prices") or []
                m = js.get("market_caps") or []
                v = js.get("total_volumes") or []
                if len(p) > 0 or len(m) > 0 or len(v) > 0:
                    _ensure_dir(cache_dir)
                    win_cache.write_text(json.dumps(js), encoding="utf-8")
        # Merge
        if isinstance(js, dict):
            prices_all.extend(js.get("prices") or [])
            caps_all.extend(js.get("market_caps") or [])
            vols_all.extend(js.get("total_volumes") or [])
        # Advance window (avoid overlapping by +1 day)
        current = window_end + timedelta(days=1)
        time.sleep(0.15)

    return {"prices": prices_all, "market_caps": caps_all, "total_volumes": vols_all}


@dataclass
class CoinMeta:
    id: str
    symbol: str
    name: str


def coingecko_crypto_hourly(
    ctx: RecipeContext,
    *,
    vs_currency: str = "usd",
    top_n: int = 100,
    coin_ids: Optional[List[str]] = None,
    days: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    coingecko_api_key: Optional[str] = None,
    raw_data_dir: Optional[str] = None,
    max_workers: int = 8,
) -> RecipeOutput:
    """
    Create Coingecko Crypto dataset with historical HOURLY data for main assets.

    Args:
        vs_currency: Quote currency (e.g., 'usd')
        top_n: Number of top coins by market cap to include (ignored if coin_ids provided)
        coin_ids: Explicit list of coingecko coin IDs to fetch (optional)
        days: 'max' or None (if None, use start_date/end_date range)
        start_date: YYYY-MM-DD (used when days is None)
        end_date: YYYY-MM-DD (used when days is None)
        coingecko_api_key: API key (or env COINGECKO_API_KEY)
        raw_data_dir: Directory to cache raw JSON
        max_workers: Concurrency for coin downloads

    Returns:
        RecipeOutput with a single combined Parquet file
    """
    api_key = coingecko_api_key or os.environ.get("COINGECKO_API_KEY")

    if not days and (not start_date or not end_date):
        raise ValueError("Provide days='max' or start_date/end_date for a range")

    # Raw data directory
    if raw_data_dir is None:
        raw_data_dir = str(Path.home() / ".warpdata" / "coingecko_raw_data")
    raw_dir = Path(raw_data_dir)
    coins_cache_dir = raw_dir / "coins"
    charts_cache_dir = raw_dir / "market_chart"
    _ensure_dir(coins_cache_dir)
    _ensure_dir(charts_cache_dir)

    # Determine coin list
    coin_metas: List[CoinMeta] = []
    if coin_ids:
        # Map IDs to symbol/name using /coins/list (cheap) and fall back to id
        try:
            all_list = _get_coins_list(api_key=api_key)
            m = {row.get("id"): (row.get("symbol"), row.get("name")) for row in all_list}
        except Exception:
            m = {}
        for cid in coin_ids:
            sym, nm = m.get(cid, (cid, cid))
            coin_metas.append(CoinMeta(id=cid, symbol=sym, name=nm))
    else:
        markets = _get_top_coins(vs_currency, top_n, api_key=api_key, cache_dir=coins_cache_dir)
        for row in markets:
            coin_metas.append(CoinMeta(id=row.get("id"), symbol=row.get("symbol"), name=row.get("name")))

    print(f"📊 Coingecko: {len(coin_metas)} assets (vs={vs_currency})")

    # Check existing data to avoid redundant API calls
    existing_coverage = {}
    out_file = ctx.work_dir / "coingecko_crypto_hourly.parquet"
    if out_file.exists():
        try:
            # Read only required columns for coverage and use vectorized groupby
            df_existing = pd.read_parquet(out_file, columns=["coin_id", "timestamp"])
            cov = df_existing.groupby("coin_id")["timestamp"].agg(["min", "max"]).reset_index()
            existing_coverage = {row["coin_id"]: (row["min"], row["max"]) for _, row in cov.iterrows()}
            print(f"📦 Found existing data for {len(existing_coverage)} coins")
        except Exception as e:
            print(f"⚠️ Could not read existing data: {e}")

    # Filter coins that need downloading
    coins_to_fetch = []
    coins_skipped = []

    # Determine requested date range
    from datetime import datetime, timedelta
    if start_date and end_date:
        req_start = datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%d 00:00:00")
        req_end = datetime.strptime(end_date, "%Y-%m-%d").strftime("%Y-%m-%d 23:00:00")
    elif days:
        # Calculate range from days parameter
        from datetime import date
        end = date.today()
        start = end - timedelta(days=int(days) if days != "max" else 3653)
        req_start = start.strftime("%Y-%m-%d 00:00:00")
        req_end = end.strftime("%Y-%m-%d 23:00:00")
    else:
        # No filtering possible
        req_start = req_end = None

    for meta in coin_metas:
        if req_start and req_end and meta.id in existing_coverage:
            exist_start, exist_end = existing_coverage[meta.id]
            # Debug: uncomment for troubleshooting
            # print(f"  {meta.id}: have [{exist_start}] to [{exist_end}], need [{req_start}] to [{req_end}]")
            # Check if we fully cover the requested range
            if exist_start <= req_start and exist_end >= req_end:
                coins_skipped.append(meta.id)
                continue
        coins_to_fetch.append(meta)

    if coins_skipped:
        print(f"⚡ Skipping {len(coins_skipped)} coins (already have requested range)")
        print(f"🔄 Fetching {len(coins_to_fetch)} coins")

    if not coins_to_fetch:
        print(f"✅ All data already present, no API calls needed")
        # Return existing data without making any API calls
        return [out_file] if out_file.exists() else []

    # Download market charts in parallel
    def fetch_one(meta: CoinMeta) -> Tuple[CoinMeta, Optional[Dict[str, Any]], Optional[str]]:
        try:
            js = _get_market_chart(
                meta.id,
                vs_currency,
                api_key=api_key,
                days=days,
                start_date=start_date,
                end_date=end_date,
                cache_dir=charts_cache_dir,
            )
            # Validate response is not None
            if js is None:
                return (meta, None, "API returned None (possibly timeout or network error)")

            # Validate structure: must contain non-empty arrays
            if not isinstance(js, dict):
                # Show actual response type and content preview
                resp_preview = str(js)[:200] if js else "empty"
                return (meta, None, f"unexpected response type {type(js).__name__}: {resp_preview}")

            prices = js.get("prices")
            mkt_caps = js.get("market_caps")
            vols = js.get("total_volumes")
            if not prices and not mkt_caps and not vols:
                # Inspect error/status fields or show raw response
                error_msg = (
                    js.get("error") or
                    js.get("status", {}).get("error_message") if isinstance(js.get("status"), dict) else js.get("status") or
                    js.get("raw") or
                    json.dumps(js)
                )
                return (meta, None, f"no data returned: {str(error_msg)[:300]}")
            return (meta, js, None)
        except Exception as e:
            # Include exception type in error message for better debugging
            return (meta, None, f"{type(e).__name__}: {str(e)[:300]}")

    results: List[Tuple[CoinMeta, Optional[Dict[str, Any]], Optional[str]]] = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs = [ex.submit(fetch_one, m) for m in coins_to_fetch]
        for i, fut in enumerate(as_completed(futs), 1):
            meta, js, err = fut.result()
            if err:
                print(f"  [{i}/{len(coins_to_fetch)}] ⚠️ {meta.id}: {err}")
            else:
                print(f"  [{i}/{len(coins_to_fetch)}] ✓ {meta.id}")
            results.append((meta, js, err))

    # Build combined frame
    combined_rows: List[Dict[str, Any]] = []
    success = 0
    for meta, js, err in results:
        if not js or not isinstance(js, dict):
            continue
        prices = js.get("prices") or []
        mkt_caps = js.get("market_caps") or []
        volumes = js.get("total_volumes") or []

        # Convert arrays to dicts keyed by hour
        def hourkey(ms: int) -> str:
            # Coingecko timestamps are ms (UTC)
            dt = datetime.utcfromtimestamp(ms / 1000.0)
            return dt.strftime("%Y-%m-%d %H:00:00")

        p_map = {hourkey(ts): val for ts, val in prices if ts is not None}
        m_map = {hourkey(ts): val for ts, val in mkt_caps if ts is not None}
        v_map = {hourkey(ts): val for ts, val in volumes if ts is not None}

        all_hours = sorted(set(p_map.keys()) | set(m_map.keys()) | set(v_map.keys()))
        for h in all_hours:
            combined_rows.append(
                {
                    "timestamp": h,
                    "coin_id": meta.id,
                    "symbol": meta.symbol,
                    "name": meta.name,
                    "price": p_map.get(h),
                    "market_cap": m_map.get(h),
                    "total_volume": v_map.get(h),
                    "vs_currency": vs_currency,
                }
            )
        if all_hours:
            success += 1

    if not combined_rows:
        raise ValueError("No data downloaded from Coingecko")

    df_new = pd.DataFrame(combined_rows)

    # Sanitize numeric fields (negatives/zeros -> NaN where appropriate)
    df_new = _sanitize_numeric_fields(df_new)

    # Append to existing combined file if present (with file locking for thread safety)
    import fcntl
    out_file = ctx.work_dir / "coingecko_crypto_hourly.parquet"

    # Create lock file for coordinating parallel writes
    lock_file = ctx.work_dir / "coingecko_crypto_hourly.lock"
    lock_file.touch(exist_ok=True)

    with open(lock_file, 'r') as lock_fd:
        # Acquire exclusive lock to prevent race conditions with parallel batch workers
        fcntl.flock(lock_fd.fileno(), fcntl.LOCK_EX)
        try:
            # Read existing data if present
            if out_file.exists():
                try:
                    df_old = pd.read_parquet(out_file)
                    df_new = pd.concat([df_old, df_new], ignore_index=True)
                except Exception as e:
                    print(f"⚠️ Failed to read existing parquet: {e}")

            # Deduplicate by (timestamp, coin_id, vs_currency)
            before = len(df_new)
            df_new = df_new.drop_duplicates(subset=["timestamp", "coin_id", "vs_currency"], keep="last")
            after = len(df_new)
            if after != before:
                print(f"🧹 Dedup (coin_id): {before:,} → {after:,}")

            # Additional deduplication: Keep only the main coin for each symbol at each timestamp
            # This prevents pivot issues caused by multiple coin_ids having the same symbol
            # (e.g., WETH on different chains). Strategy: keep the coin with largest market cap.
            before_symbol = len(df_new)
            df_new = df_new.sort_values('market_cap', ascending=False, na_position='last')
            df_new = df_new.drop_duplicates(subset=["timestamp", "symbol", "vs_currency"], keep="first")
            df_new = df_new.sort_values(['timestamp', 'symbol'])
            after_symbol = len(df_new)
            if after_symbol != before_symbol:
                print(f"🧹 Dedup (symbol): {before_symbol:,} → {after_symbol:,} (removed {before_symbol - after_symbol:,} cross-chain duplicates)")

            # Write updated data (inside lock to prevent corruption)
            out_file.parent.mkdir(parents=True, exist_ok=True)
            df_new.to_parquet(out_file, index=False)
        finally:
            # Lock automatically released when context exits
            pass

    # Build README
    readme = f"""# Coingecko Crypto Dataset

Historical daily data (price, market_cap, total_volume) for major crypto assets
from Coingecko. All assets are stored in a single table.

## Configuration
- vs_currency: {vs_currency}
- assets: {len(coin_metas)}
- mode: {{'days': '{days}'}}{f", range: {start_date} → {end_date}" if not days else ''}

## Columns
- date (YYYY-MM-DD, UTC)
- coin_id (coingecko id)
- symbol
- name
- price ({vs_currency})
- market_cap ({vs_currency})
- total_volume ({vs_currency})
- vs_currency

## Usage
```python
import warpdata as wd
df = wd.load("{ctx.dataset_id}", as_format="pandas")
# Filter a single asset
btc = df[df['coin_id'] == 'bitcoin']
```
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "vs_currency": vs_currency,
            "assets": [c.id for c in coin_metas],
            "mode": {"days": days, "start_date": start_date, "end_date": end_date},
            "source": "coingecko",
        },
        raw_data=[raw_dir],
    )
