"""
ArXiv PDF Manifest Recipe.

Scans local PDF directory, computes SHA1 fingerprints, and creates inventory.
Idempotent: re-running will add only new PDFs.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any
import hashlib
import re

from tqdm import tqdm

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput


def _compute_sha1(file_path: Path) -> str:
    """Compute SHA1 hash of file contents."""
    sha1 = hashlib.sha1()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            sha1.update(chunk)
    return sha1.hexdigest()


def _parse_arxiv_id(filename: str) -> str | None:
    """Extract arXiv ID from filename (e.g., '2301.12345.pdf' -> '2301.12345')."""
    # Match patterns like: 2301.12345, 1234.5678v2, hep-th/9901001, etc.
    patterns = [
        r"(\d{4}\.\d{4,5}(?:v\d+)?)",  # Modern: 2301.12345 or 2301.12345v2
        r"([a-z\-]+/\d{7}(?:v\d+)?)",  # Legacy: hep-th/9901001
    ]
    for pattern in patterns:
        match = re.search(pattern, filename, re.IGNORECASE)
        if match:
            return match.group(1)
    return None


def arxiv_pdf_manifest(
    ctx: RecipeContext,
    local_pdf_dir: str = "./recipes_raw_data/arxiv_pdfs",
) -> RecipeOutput:
    """
    Scan local PDF directory and create manifest with SHA1 fingerprints.

    Creates inventory of all available PDFs with:
    - arxiv_id parsed from filename
    - category (if organized in subdirs)
    - absolute path
    - file size and modification time
    - pdf_sha1 fingerprint (for deduplication)

    Args:
        ctx: Recipe context
        local_pdf_dir: Root directory containing PDFs

    Returns:
        RecipeOutput with manifest Parquet

    Schema:
        - arxiv_id: string (e.g., "2301.12345")
        - category: string or null (e.g., "cs.AI")
        - path: string (absolute path to PDF)
        - size_bytes: int64
        - mtime: timestamp (last modified)
        - pdf_sha1: string (hex, 40 chars)
    """
    pdf_dir = Path(local_pdf_dir).resolve()
    if not pdf_dir.exists():
        raise ValueError(f"PDF directory not found: {pdf_dir}")

    print(f"📄 Scanning PDF directory: {pdf_dir}")

    rows: List[Dict[str, Any]] = []

    # Recursively find all PDFs
    pdf_files = list(pdf_dir.rglob("*.pdf"))
    print(f"   Found {len(pdf_files)} PDF files")

    for pdf_path in tqdm(pdf_files, desc="Manifest", unit="pdf"):
        # Parse arXiv ID from filename
        arxiv_id = _parse_arxiv_id(pdf_path.name)
        if not arxiv_id:
            print(f"   ⚠️  Could not parse arXiv ID from: {pdf_path.name}")
            continue

        # Try to extract category from parent directory
        # Support: pdfs/cs.AI/2301.12345.pdf or pdfs/2301.12345.pdf
        category = None
        parent_name = pdf_path.parent.name
        if parent_name != pdf_dir.name and re.match(r"[a-z\-]+\.[A-Z]+", parent_name):
            category = parent_name

        # Compute SHA1 fingerprint
        try:
            pdf_sha1 = _compute_sha1(pdf_path)
        except Exception as e:
            print(f"   ⚠️  Failed to compute SHA1 for {pdf_path.name}: {e}")
            continue

        stat = pdf_path.stat()

        rows.append({
            "arxiv_id": arxiv_id,
            "category": category,
            "path": str(pdf_path),
            "size_bytes": stat.st_size,
            "mtime": stat.st_mtime,
            "pdf_sha1": pdf_sha1,
        })

    print(f"   Successfully parsed {len(rows)} PDFs")

    # Write manifest
    import pandas as pd
    manifest_df = pd.DataFrame(rows)

    # Sort by arxiv_id for deterministic output
    if len(manifest_df) > 0:
        manifest_df = manifest_df.sort_values("arxiv_id")

    manifest_rel = ctx.engine.conn.from_df(manifest_df)
    out_path = ctx.work_dir / "manifest.parquet"
    ctx.write_parquet(manifest_rel, out_path)

    print(f"   Wrote manifest: {out_path}")

    # Generate stats
    unique_ids = manifest_df["arxiv_id"].nunique() if len(manifest_df) > 0 else 0
    total_size_gb = manifest_df["size_bytes"].sum() / (1024**3) if len(manifest_df) > 0 else 0
    categories = manifest_df["category"].value_counts().to_dict() if len(manifest_df) > 0 else {}

    readme = f"""# ArXiv PDF Manifest

## Overview
Inventory of locally available ArXiv PDFs with SHA1 fingerprints for deduplication.

## Statistics
- **Total PDFs**: {len(rows)}
- **Unique arXiv IDs**: {unique_ids}
- **Total size**: {total_size_gb:.2f} GB
- **Source**: {pdf_dir}

## Categories
"""
    for cat, count in sorted(categories.items(), key=lambda x: -x[1])[:20]:
        readme += f"- **{cat or 'uncategorized'}**: {count} PDFs\n"

    readme += """
## Schema
- `arxiv_id`: ArXiv identifier (e.g., "2301.12345")
- `category`: Primary category if organized in subdirectories
- `path`: Absolute path to PDF file
- `size_bytes`: File size in bytes
- `mtime`: Last modification timestamp
- `pdf_sha1`: SHA1 fingerprint (40 hex chars) for deduplication

## Usage
```python
import warpdata as wd
manifest = wd.load("warpdata://arxiv/pdf-manifest", as_format="pandas")
print(f"Available PDFs: {len(manifest)}")
```
"""

    return RecipeOutput(
        main=[out_path],
        subdatasets={},
        docs={"README.md": readme},
        metadata={
            "source": "local_filesystem",
            "pdf_dir": str(pdf_dir),
            "total_pdfs": len(rows),
            "unique_ids": unique_ids,
            "total_size_bytes": int(manifest_df["size_bytes"].sum()) if len(manifest_df) > 0 else 0,
        },
    )
