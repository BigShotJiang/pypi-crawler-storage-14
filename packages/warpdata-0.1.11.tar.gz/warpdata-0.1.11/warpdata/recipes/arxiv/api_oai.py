"""
ArXiv OAI-PMH API client.

Uses Open Archives Initiative Protocol for Metadata Harvesting (OAI-PMH)
for bulk metadata access. Much more reliable than the search API.

https://arxiv.org/help/oa
"""
from __future__ import annotations

import json
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime
from typing import Iterator, Optional

import requests
from tqdm import tqdm

from .api import (
    ArxivPaper,
    create_session,
    load_proxy_credentials,
)

# OAI-PMH endpoint
OAI_PMH_URL = "http://export.arxiv.org/oai2"

# OAI-PMH rate limit - much more lenient than Search API
# ArXiv OAI-PMH is designed for bulk access and can handle fast requests
OAI_RATE_LIMIT_SECONDS = 0.3

# Valid OAI-PMH sets (top-level archives)
# Some archives are accessed via physics:archive format
VALID_OAI_SETS = {
    # Direct top-level sets
    "cs", "math", "stat", "econ", "eess", "q-bio", "q-fin", "physics",
    # Physics sub-archives (need physics: prefix)
    "astro-ph", "cond-mat", "gr-qc", "hep-ex", "hep-lat", "hep-ph", "hep-th",
    "math-ph", "nlin", "nucl-ex", "nucl-th", "quant-ph",
}

# Archives that need physics: prefix in OAI-PMH
PHYSICS_ARCHIVES = {
    "astro-ph", "cond-mat", "gr-qc", "hep-ex", "hep-lat", "hep-ph", "hep-th",
    "math-ph", "nlin", "nucl-ex", "nucl-th", "quant-ph",
}


def _category_to_oai_set(category: str) -> str:
    """Convert arXiv category to OAI-PMH set name.

    ArXiv OAI-PMH uses hierarchical sets:
    - Top-level: cs, math, stat, econ, eess, q-bio, q-fin, physics
    - Physics sub-archives: physics:astro-ph, physics:cond-mat, etc.
    """
    # Extract top-level archive
    if '.' in category:
        archive = category.split('.')[0]
    else:
        archive = category

    # Physics sub-archives need physics: prefix
    if archive in PHYSICS_ARCHIVES:
        return f"physics:{archive}"

    return archive


# XML namespaces
NS = {
    'oai': 'http://www.openarchives.org/OAI/2.0/',
    'arxiv': 'http://arxiv.org/OAI/arXiv/',
}


def _parse_authors(authors_text: str) -> list[str]:
    """Parse authors string into list."""
    if not authors_text:
        return []
    # OAI format: "LastName, FirstName, LastName2, FirstName2"
    # Split by newlines or commas, clean up
    authors = []
    for line in authors_text.strip().split('\n'):
        line = line.strip()
        if line:
            authors.append(line)
    return authors if authors else [authors_text.strip()]


def _parse_record(record: ET.Element) -> Optional[ArxivPaper]:
    """Parse a single OAI-PMH record into ArxivPaper."""
    header = record.find('.//oai:header', NS)
    metadata = record.find('.//arxiv:arXiv', NS)

    if header is None or metadata is None:
        return None

    if header.get('status') == 'deleted':
        return None

    arxiv_id = metadata.findtext('arxiv:id', default='', namespaces=NS)
    if not arxiv_id:
        return None

    # Parse categories
    categories_elem = metadata.find('arxiv:categories', NS)
    categories = categories_elem.text.split() if categories_elem is not None and categories_elem.text else []
    primary_category = categories[0] if categories else 'unknown'

    # Parse dates
    created = metadata.findtext('arxiv:created', default='', namespaces=NS)
    updated = metadata.findtext('arxiv:updated', default='', namespaces=NS) or created

    try:
        published = datetime.strptime(created, "%Y-%m-%d") if created else datetime.now()
    except ValueError:
        published = datetime.now()

    try:
        updated_dt = datetime.strptime(updated, "%Y-%m-%d") if updated else published
    except ValueError:
        updated_dt = published

    # Parse authors
    authors_text = metadata.findtext('arxiv:authors', default='', namespaces=NS)
    authors = _parse_authors(authors_text)

    return ArxivPaper(
        arxiv_id=arxiv_id,
        title=(metadata.findtext('arxiv:title', default='', namespaces=NS) or '').replace('\n', ' ').strip(),
        abstract=(metadata.findtext('arxiv:abstract', default='', namespaces=NS) or '').replace('\n', ' ').strip(),
        authors=authors,
        categories=categories,
        primary_category=primary_category,
        published=published,
        updated=updated_dt,
        pdf_url=f"https://arxiv.org/pdf/{arxiv_id}.pdf",
        abs_url=f"https://arxiv.org/abs/{arxiv_id}",
        doi=metadata.findtext('arxiv:doi', default=None, namespaces=NS),
        journal_ref=metadata.findtext('arxiv:journal-ref', default=None, namespaces=NS),
        comment=metadata.findtext('arxiv:comments', default=None, namespaces=NS),
    )


class OAIHarvester:
    """
    OAI-PMH harvester for bulk arXiv metadata.

    Much faster and more reliable than the search API for bulk access.

    Example:
        harvester = OAIHarvester(proxy_file="scripts/proxy_credentials.txt")
        papers = harvester.harvest(
            from_date="2024-01-01",
            until_date="2024-12-31",
            category="cs.LG",
            limit=1000,
        )
    """

    def __init__(
        self,
        proxy_file: Optional[str] = None,
        use_proxy: bool = True,
        rate_limit: float = OAI_RATE_LIMIT_SECONDS,
    ):
        self.rate_limit = rate_limit
        self._proxy_failed = False

        # Initialize session with proxy
        self._proxies = None
        if use_proxy:
            self._proxies = load_proxy_credentials(proxy_file)
            if self._proxies:
                print(f"   Using proxy: {self._proxies['http'].split('@')[-1]}")

        self._session = create_session(proxies=self._proxies)
        self._last_request_time: Optional[float] = None

    def _wait_for_rate_limit(self) -> None:
        """Enforce rate limiting between requests."""
        if self._last_request_time is not None:
            elapsed = time.time() - self._last_request_time
            if elapsed < self.rate_limit:
                time.sleep(self.rate_limit - elapsed)
        self._last_request_time = time.time()

    def _disable_proxy(self) -> None:
        """Disable proxy and recreate session without it."""
        if self._proxies and not self._proxy_failed:
            print("   ⚠️  Proxy failed, falling back to direct connection")
            self._proxy_failed = True
            self._proxies = None
            self._session = create_session(proxies=None)

    def harvest(
        self,
        from_date: str,
        until_date: str,
        category: Optional[str] = None,
        limit: Optional[int] = None,
        progress: bool = True,
    ) -> list[ArxivPaper]:
        """
        Harvest metadata from arXiv OAI-PMH API.

        Args:
            from_date: Start date (YYYY-MM-DD)
            until_date: End date (YYYY-MM-DD)
            category: arXiv category (e.g., "cs", "cs.LG", "math")
                     Note: OAI-PMH only supports top-level sets (cs, math, etc.)
                     Subcategories like cs.LG are filtered client-side.
            limit: Maximum papers to harvest
            progress: Show progress bar

        Returns:
            List of ArxivPaper objects
        """
        papers: list[ArxivPaper] = []
        resumption_token: Optional[str] = None

        # Handle OAI-PMH set specification
        # - Already an OAI set (contains ':'): use directly, e.g., "physics:astro-ph"
        # - Has '.': convert to OAI set, e.g., "cs.LG" -> "cs"
        # - Plain archive name: use directly, e.g., "cs", "math"
        oai_set = None
        filter_category = None
        if category:
            if ':' in category:
                # Already an OAI set like "physics:astro-ph"
                oai_set = category
                # Extract the archive for filtering (e.g., "astro-ph" from "physics:astro-ph")
                filter_category = category.split(':')[1] if ':' in category else None
            elif '.' in category:
                # Subcategory like "cs.LG" - convert to OAI set
                oai_set = _category_to_oai_set(category)
                filter_category = category  # Will filter results
            else:
                # Top-level archive, might need physics: prefix
                oai_set = _category_to_oai_set(category)

        desc = f"Harvesting {from_date} to {until_date}"
        if category:
            desc += f" [{oai_set or category}]"

        pbar = tqdm(desc=desc, unit=" papers", disable=not progress)

        while True:
            self._wait_for_rate_limit()

            # Build request params
            if resumption_token:
                params = {'verb': 'ListRecords', 'resumptionToken': resumption_token}
            else:
                params = {
                    'verb': 'ListRecords',
                    'from': from_date,
                    'until': until_date,
                    'metadataPrefix': 'arXiv',
                }
                if oai_set:
                    params['set'] = oai_set

            try:
                response = self._session.get(OAI_PMH_URL, params=params, timeout=60)
                response.raise_for_status()
            except requests.exceptions.ProxyError as e:
                self._disable_proxy()
                continue
            except requests.exceptions.ConnectionError as e:
                if self._proxies and not self._proxy_failed:
                    self._disable_proxy()
                    continue
                print(f"\n❌ Connection error: {e}")
                break
            except requests.exceptions.Timeout as e:
                if self._proxies and not self._proxy_failed:
                    self._disable_proxy()
                    continue
                print(f"\n❌ Timeout error: {e}")
                break
            except Exception as e:
                # Try disabling proxy on any error that might be proxy-related
                if self._proxies and not self._proxy_failed:
                    self._disable_proxy()
                    continue
                print(f"\n❌ Error fetching metadata: {e}")
                break

            # Parse XML
            try:
                root = ET.fromstring(response.content)
            except Exception as e:
                print(f"\n❌ Error parsing XML: {e}")
                break

            # Check for OAI errors
            error = root.find('.//oai:error', NS)
            if error is not None:
                error_code = error.get('code', 'unknown')
                if error_code == 'noRecordsMatch':
                    # No records for this query - not an error
                    break
                print(f"\n❌ OAI error: {error_code} - {error.text}")
                break

            # Parse records
            records = root.findall('.//oai:record', NS)
            for record in records:
                paper = _parse_record(record)
                if paper:
                    # Filter by subcategory if specified
                    if filter_category:
                        if filter_category not in paper.categories and paper.primary_category != filter_category:
                            continue
                    papers.append(paper)
                    pbar.update(1)

                    if limit and len(papers) >= limit:
                        pbar.close()
                        return papers

            # Check for resumption token (pagination)
            token_elem = root.find('.//oai:resumptionToken', NS)
            if token_elem is not None and token_elem.text:
                resumption_token = token_elem.text
                # Show progress from token attributes
                complete_size = token_elem.get('completeListSize')
                if complete_size:
                    pbar.total = int(complete_size)
            else:
                # No more pages
                break

        pbar.close()
        return papers

    def harvest_by_year(
        self,
        year: int,
        category: Optional[str] = None,
        limit: Optional[int] = None,
        progress: bool = True,
    ) -> list[ArxivPaper]:
        """
        Convenience method to harvest all papers from a specific year.

        Args:
            year: Year to harvest
            category: Optional category filter
            limit: Maximum papers
            progress: Show progress bar

        Returns:
            List of ArxivPaper objects
        """
        from_date = f"{year}-01-01"

        # Cap until_date at today (arXiv rejects future dates)
        today = datetime.now()
        if year > today.year:
            # Future year - skip entirely
            return []
        elif year == today.year:
            until_date = today.strftime("%Y-%m-%d")
        else:
            until_date = f"{year}-12-31"

        return self.harvest(
            from_date=from_date,
            until_date=until_date,
            category=category,
            limit=limit,
            progress=progress,
        )


def harvest_papers(
    years: list[int],
    papers_per_year: int,
    category_weights: dict[str, float],
    proxy_file: Optional[str] = None,
    use_proxy: bool = True,
    existing_ids: Optional[set[str]] = None,
    progress: bool = True,
    fast_mode: bool = True,
    on_batch_complete: Optional[callable] = None,
) -> list[ArxivPaper]:
    """
    Harvest papers using OAI-PMH with category distribution.

    Args:
        years: Years to harvest
        papers_per_year: Target papers per year
        category_weights: Category -> weight mapping
        proxy_file: Proxy credentials file
        use_proxy: Whether to use proxy
        existing_ids: IDs to skip (for incremental updates)
        progress: Show progress bar
        fast_mode: If True, use top-level categories only (much faster)
        on_batch_complete: Optional callback(papers: list[ArxivPaper]) called after each OAI set
                          Use this to save progress incrementally for interruptible harvesting

    Returns:
        List of ArxivPaper objects, deduplicated
    """
    if existing_ids is None:
        existing_ids = set()

    harvester = OAIHarvester(proxy_file=proxy_file, use_proxy=use_proxy)

    all_papers: dict[str, ArxivPaper] = {}

    if fast_mode:
        # Fast mode: harvest by top-level OAI-PMH set only, filter later
        # This is MUCH faster because OAI-PMH returns full batches (~1000 papers)
        # instead of ~10 papers when filtering for subcategories

        # Extract unique OAI-PMH sets from category weights
        oai_sets = set()
        for cat in category_weights.keys():
            oai_set = _category_to_oai_set(cat)
            oai_sets.add(oai_set)

        # Build set of allowed subcategories for filtering
        allowed_subcats = set(category_weights.keys())

        print(f"   OAI-PMH sets to harvest: {sorted(oai_sets)}")

        for year in years:
            print(f"\n📅 Year {year}:")
            year_papers: dict[str, ArxivPaper] = {}

            for oai_set in sorted(oai_sets):
                if len(year_papers) >= papers_per_year:
                    break

                # Fetch more than needed since we'll filter
                fetch_limit = min(papers_per_year * 3, 5000)

                papers = harvester.harvest_by_year(
                    year=year,
                    category=oai_set,  # OAI-PMH set (e.g., "cs" or "physics:astro-ph")
                    limit=fetch_limit,
                    progress=progress,
                )

                added = 0
                for paper in papers:
                    if len(year_papers) >= papers_per_year:
                        break
                    if paper.arxiv_id in existing_ids:
                        continue
                    if paper.arxiv_id in year_papers:
                        continue
                    if paper.arxiv_id in all_papers:
                        continue

                    # Check if paper matches any allowed subcategory
                    paper_cats = set(paper.categories) | {paper.primary_category}
                    if not (paper_cats & allowed_subcats):
                        continue

                    year_papers[paper.arxiv_id] = paper
                    added += 1

                print(f"   {oai_set}: {added} papers (from {len(papers)} fetched)")

                # Call callback after each OAI set for incremental saving
                if on_batch_complete and added > 0:
                    on_batch_complete(list(all_papers.values()) + list(year_papers.values()))

            all_papers.update(year_papers)
            print(f"   Year total: {len(year_papers)} papers")
    else:
        # Original mode: harvest per subcategory (slower but more precise distribution)
        total_weight = sum(category_weights.values())
        weights = {k: v / total_weight for k, v in category_weights.items()}

        for year in years:
            print(f"\n📅 Year {year}:")
            year_target = papers_per_year
            year_papers: dict[str, ArxivPaper] = {}

            for category, weight in weights.items():
                if len(year_papers) >= year_target:
                    break

                cat_target = max(1, int(weight * year_target))
                fetch_limit = min(cat_target * 2, 2000)

                papers = harvester.harvest_by_year(
                    year=year,
                    category=category,
                    limit=fetch_limit,
                    progress=progress,
                )

                added = 0
                for paper in papers:
                    if paper.arxiv_id in existing_ids:
                        continue
                    if paper.arxiv_id in year_papers:
                        continue
                    if paper.arxiv_id in all_papers:
                        continue

                    year_papers[paper.arxiv_id] = paper
                    added += 1

                    if added >= cat_target or len(year_papers) >= year_target:
                        break

                print(f"   {category}: {added} papers")

            all_papers.update(year_papers)
            print(f"   Year total: {len(year_papers)} papers")

    return list(all_papers.values())
