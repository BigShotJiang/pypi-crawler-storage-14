"""
PDF download with rate limiting and proxy support.

Downloads arXiv PDFs with proper rate limiting, retry logic, and optional proxy.
Supports parallel downloads with workers parameter.
"""
from __future__ import annotations

import hashlib
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

import requests
from tqdm import tqdm

from .api import ArxivPaper, load_proxy_credentials, create_session

# Rate limiting for arXiv PDF downloads
PDF_RATE_LIMIT_SECONDS = 1.0  # 1 second between downloads
PDF_RETRY_DELAY = 5.0  # Delay after rate limit error
PDF_MAX_RETRIES = 3


def compute_sha1(data: bytes) -> str:
    """Compute SHA1 hash of data."""
    return hashlib.sha1(data).hexdigest()


class PDFDownloader:
    """PDF downloader with proxy support and automatic fallback."""

    def __init__(
        self,
        proxy_file: Optional[str] = None,
        use_proxy: bool = True,
        rate_limit: float = PDF_RATE_LIMIT_SECONDS,
        max_retries: int = PDF_MAX_RETRIES,
    ):
        self.rate_limit = rate_limit
        self.max_retries = max_retries
        self._proxy_failed = False

        # Initialize session with proxy if available
        self._proxies = None
        if use_proxy:
            self._proxies = load_proxy_credentials(proxy_file)

        self._session = create_session(proxies=self._proxies)

    def _disable_proxy(self) -> None:
        """Disable proxy and recreate session without it."""
        if self._proxies and not self._proxy_failed:
            print("   ⚠️  Proxy failed for PDF download, falling back to direct connection")
            self._proxy_failed = True
            self._proxies = None
            self._session = create_session(proxies=None)

    def download(
        self,
        paper: ArxivPaper,
        output_dir: Path,
    ) -> Optional[tuple[Path, str]]:
        """
        Download a single PDF from arXiv.

        Args:
            paper: ArxivPaper with pdf_url
            output_dir: Directory to save PDF

        Returns:
            Tuple of (path, sha1) if successful, None if failed
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        # Use arxiv_id as filename
        filename = f"{paper.arxiv_id.replace('/', '_')}.pdf"
        output_path = output_dir / filename

        # Skip if already downloaded
        if output_path.exists():
            with open(output_path, "rb") as f:
                sha1 = compute_sha1(f.read())
            return output_path, sha1

        for attempt in range(self.max_retries):
            try:
                time.sleep(self.rate_limit)

                response = self._session.get(
                    paper.pdf_url,
                    timeout=120,
                    headers={"Accept": "application/pdf"},
                )

                if response.status_code == 429:  # Rate limited
                    print(f"Rate limited, waiting {PDF_RETRY_DELAY}s...")
                    time.sleep(PDF_RETRY_DELAY)
                    continue

                if response.status_code == 404:
                    # Don't print for every 404, just return None
                    return None

                response.raise_for_status()
                pdf_data = response.content

                # Verify it's actually a PDF
                if not pdf_data.startswith(b"%PDF"):
                    return None

                # Save to disk
                with open(output_path, "wb") as f:
                    f.write(pdf_data)

                sha1 = compute_sha1(pdf_data)
                return output_path, sha1

            except requests.exceptions.ProxyError:
                self._disable_proxy()
                if attempt < self.max_retries - 1:
                    continue
                return None

            except requests.exceptions.RequestException as e:
                if attempt == self.max_retries - 1:
                    return None
                # Try disabling proxy on connection errors
                if self._proxies and "proxy" in str(e).lower():
                    self._disable_proxy()
                time.sleep(self.rate_limit * 2)

            except Exception:
                if attempt == self.max_retries - 1:
                    return None
                time.sleep(self.rate_limit)

        return None


def download_pdf(
    paper: ArxivPaper,
    output_dir: Path,
    rate_limit: float = PDF_RATE_LIMIT_SECONDS,
    max_retries: int = PDF_MAX_RETRIES,
    proxy_file: Optional[str] = None,
    use_proxy: bool = True,
) -> Optional[tuple[Path, str]]:
    """
    Download a single PDF from arXiv (convenience function).

    Args:
        paper: ArxivPaper with pdf_url
        output_dir: Directory to save PDF
        rate_limit: Seconds to wait between requests
        max_retries: Maximum retry attempts
        proxy_file: Path to proxy credentials file
        use_proxy: Whether to use proxy

    Returns:
        Tuple of (path, sha1) if successful, None if failed
    """
    downloader = PDFDownloader(
        proxy_file=proxy_file,
        use_proxy=use_proxy,
        rate_limit=rate_limit,
        max_retries=max_retries,
    )
    return downloader.download(paper, output_dir)


def download_pdfs(
    papers: list[ArxivPaper],
    output_dir: Path,
    rate_limit: float = PDF_RATE_LIMIT_SECONDS,
    progress: bool = True,
    workers: int = 1,
    proxy_file: Optional[str] = None,
    use_proxy: bool = True,
) -> dict[str, tuple[Path, str]]:
    """
    Download PDFs for multiple papers.

    Args:
        papers: List of ArxivPaper objects
        output_dir: Directory to save PDFs
        rate_limit: Seconds between downloads
        progress: Show progress bar
        workers: Number of parallel download workers
        proxy_file: Path to proxy credentials file
        use_proxy: Whether to use proxy

    Returns:
        Dict mapping arxiv_id -> (path, sha1) for successful downloads
    """
    output_dir = Path(output_dir)
    results: dict[str, tuple[Path, str]] = {}

    # Create downloader with shared session
    downloader = PDFDownloader(
        proxy_file=proxy_file,
        use_proxy=use_proxy,
        rate_limit=rate_limit,
    )

    if workers <= 1:
        # Sequential download
        for paper in tqdm(papers, desc="Downloading PDFs", disable=not progress):
            result = downloader.download(paper, output_dir)
            if result:
                results[paper.arxiv_id] = result
    else:
        # Parallel download
        def download_one(paper: ArxivPaper) -> tuple[str, Optional[tuple[Path, str]]]:
            result = downloader.download(paper, output_dir)
            return paper.arxiv_id, result

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(download_one, p): p for p in papers}

            with tqdm(total=len(papers), desc="Downloading PDFs", disable=not progress) as pbar:
                for future in as_completed(futures):
                    arxiv_id, result = future.result()
                    if result:
                        results[arxiv_id] = result
                    pbar.update(1)

    success = len(results)
    failed = len(papers) - success
    print(f"Downloaded: {success} success, {failed} failed")

    return results
