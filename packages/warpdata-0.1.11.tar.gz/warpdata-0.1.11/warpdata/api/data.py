"""
Core data loading API for warpdata.

Provides the main functions for loading and inspecting data:
- load(): Load data from any source
- schema(): Inspect data schema
- head(): Preview first N rows
"""
from pathlib import Path
from typing import Union, Optional, Dict, Any, List
import duckdb

from ..core.uris import parse_uri
from ..core.registry import get_registry
from ..core.config import get_config
from ..core.cache import get_cache
from ..engine.duck import get_engine
from ..io.fsspec_fs import get_filesystem

# TODO: Delete this after S3 is fully synced - temporary HF fallback for slow internet
_HF_FALLBACK_MAP = {
    "nlp/openorca": "Open-Orca/OpenOrca",
    "nlp/ag-news": "fancyzhx/ag_news",
    "nlp/yelp-polarity": "fancyzhx/yelp_polarity",
    "nlp/openhermes": "teknium/OpenHermes-2.5",
    "nlp/imdb": "stanfordnlp/imdb",
    "eval/mmlu": "cais/mmlu",
    "video/dream1k": "omni-research/DREAM-1K",
    # "vision/imagenet-1k-images": "ILSVRC/imagenet-1k",  # Requires auth
}


def _try_hf_fallback(workspace: str, name: str) -> Optional[Dict]:
    """
    TODO: Delete this after S3 is fully synced!
    Temporary fallback to load from HuggingFace when S3 pull fails.
    """
    dataset_id = f"{workspace}/{name}"
    hf_id = _HF_FALLBACK_MAP.get(dataset_id)

    if not hf_id:
        return None

    try:
        from .management import register_from_hf_cache, download_hf_samples

        print(f"  🔄 Trying HuggingFace fallback: {hf_id}")

        # First check if already in HF cache
        try:
            register_from_hf_cache(hf_id, dataset_id=f"warpdata://{dataset_id}")
            print(f"  ✅ Linked from HF cache")
        except FileNotFoundError:
            # Not in cache, stream from HF
            print(f"  📥 Streaming from HuggingFace (this may take a while)...")
            from datasets import load_dataset
            ds = load_dataset(hf_id, split="train")

            # Save to warpdata cache
            import pyarrow.parquet as pq
            import pyarrow as pa

            cache = get_cache()
            output_dir = cache.cache_dir / "datasets" / workspace / name
            output_dir.mkdir(parents=True, exist_ok=True)
            output_file = output_dir / "data.parquet"

            # Convert to parquet
            table = ds.data.table if hasattr(ds.data, 'table') else pa.Table.from_pydict(ds.to_dict())
            pq.write_table(table, output_file)

            # Register
            from .management import register_dataset
            register_dataset(
                dataset_id=f"warpdata://{dataset_id}",
                resources=[str(output_file)],
                file_format="parquet",
                metadata={"source": "huggingface_fallback", "hf_id": hf_id}
            )
            print(f"  ✅ Downloaded and registered from HuggingFace")

        # Return the dataset info
        registry = get_registry()
        return registry.get_dataset_version(workspace, name, "latest")

    except Exception as e:
        print(f"  ⚠️  HF fallback failed: {e}")
        return None


def _try_auto_pull(workspace: str, name: str, version: str) -> Optional[Dict]:
    """
    Try to register and pull a dataset from remote storage.

    Returns dataset_info if successful, None otherwise.
    """
    try:
        from .storage import pull_dataset

        dataset_id = f"warpdata://{workspace}/{name}"
        print(f"  📥 Dataset '{workspace}/{name}' not found locally, pulling from remote...")

        pull_dataset(dataset_id=dataset_id)

        # Re-check registry after pull
        registry = get_registry()
        return registry.get_dataset_version(workspace, name, version)
    except Exception as e:
        print(f"  ⚠️  Auto-pull failed: {e}")

        # TODO: Delete this after S3 is fully synced - try HF fallback
        hf_result = _try_hf_fallback(workspace, name)
        if hf_result:
            return hf_result

        return None


def _do_auto_pull(workspace: str, name: str) -> None:
    """
    Pull dataset files from remote storage.

    Raises exception if pull fails.
    """
    from .storage import pull_dataset

    dataset_id = f"warpdata://{workspace}/{name}"
    pull_dataset(dataset_id=dataset_id)


def load(
    source: str,
    as_format: str = "duckdb",
    include_rid: bool = False,
    auto_pull: bool = True,
    limit: Optional[int] = None,
    **options
) -> Union[duckdb.DuckDBPyRelation, Any]:
    """
    Load data from any source.

    Supports:
    - Local files: file:///path/to/file or /path/to/file
    - Remote files: s3://bucket/key, https://example.com/data.csv
    - Registered datasets: warpdata://workspace/name[@version]
    - Glob patterns: /path/to/*.parquet, s3://bucket/*.csv

    Args:
        source: Data source URI or path
        as_format: Output format ('duckdb', 'pandas', 'polars', 'arrow')
        include_rid: If True, include the 'rid' (row ID) column from materialized datasets
        auto_pull: If True, automatically pull dataset from remote storage if not found locally
        limit: Optional row limit. For sharded datasets, only downloads enough shards
               to satisfy the limit (efficient for large remote datasets).
        **options: Additional options for loading

    Returns:
        Data in requested format (default: DuckDB relation)

    Examples:
        >>> import warpdata as wd
        >>> df = wd.load("s3://my-bucket/data.parquet")
        >>> df = wd.load("/local/data.csv", as_format="pandas")
        >>> df = wd.load("warpdata://nlp/imdb@latest")
        >>> df = wd.load("warpdata://vision/coco-train", include_rid=True)  # Include rid column
        >>> df = wd.load("nlp/openhermes")  # Auto-pulls from remote if not found locally
        >>> df = wd.load("text/wikipedia", limit=1000)  # Only downloads enough shards for 1000 rows
    """
    # Support shorthand dataset names without workspace or scheme.
    # If source has no scheme and doesn't exist as a local path, try resolving
    # it as a registered dataset name across workspaces.
    if "://" not in source:
        p = Path(source)
        if not p.exists():
            reg = get_registry()
            # Support shorthand 'workspace/name' as well as plain 'name'
            if "/" in source:
                try:
                    workspace, name = source.split("/", 1)
                except ValueError:
                    workspace, name = None, None
                if workspace and name:
                    info = reg.get_dataset_version(workspace, name, "latest")
                    if info is not None:
                        source = f"warpdata://{workspace}/{name}"
                    elif auto_pull:
                        # Not in registry, try auto-pull from remote
                        pulled_info = _try_auto_pull(workspace, name, "latest")
                        if pulled_info is not None:
                            source = f"warpdata://{workspace}/{name}"
                        # Fall through if pull failed
            if "://" not in source:
                # Find all datasets matching this name across workspaces
                matches = [ds for ds in reg.list_datasets() if ds.get("name") == source]
                if len(matches) == 1:
                    ws = matches[0].get("workspace") or get_config().default_workspace
                    source = f"warpdata://{ws}/{source}"
                elif len(matches) > 1:
                    # Prefer default workspace if present
                    default_ws = get_config().default_workspace
                    preferred = [m for m in matches if m.get("workspace") == default_ws]
                    if len(preferred) == 1:
                        source = f"warpdata://{default_ws}/{source}"
                    else:
                        raise ValueError(
                            "Ambiguous dataset name. Found in workspaces: "
                            + ", ".join(sorted({m.get('workspace') for m in matches}))
                            + ". Specify full ID like 'warpdata://workspace/" + source + "' "
                            + "or set WARPDATA_DEFAULT_WORKSPACE."
                        )

    # Parse URI (after possible rewrite)
    uri = parse_uri(source)

    # Handle warpdata:// URIs (registered datasets)
    if uri.is_warpdata:
        return _load_registered_dataset(uri, as_format, include_rid=include_rid, auto_pull=auto_pull, limit=limit, **options)

    # Handle direct file/remote URIs
    result = _load_direct_uri(source, as_format, **options)

    # Apply limit if specified
    if limit is not None and as_format == "duckdb":
        result = result.limit(limit)
    elif limit is not None:
        # For non-duckdb formats, convert back from duckdb with limit
        engine = get_engine()
        rel = _load_direct_uri(source, "duckdb", **options).limit(limit)
        if as_format == "pandas":
            return engine.to_df(rel, "pandas")
        elif as_format == "polars":
            return engine.to_df(rel, "polars")
        elif as_format == "arrow":
            return engine.to_df(rel, "arrow")

    return result


def _load_direct_uri(source: str, as_format: str = "duckdb", **options) -> Any:
    """
    Load data directly from a file or remote URI.

    Args:
        source: File path or URI
        as_format: Output format
        **options: Additional options

    Returns:
        Data in requested format
    """
    # Get cache
    cache = get_cache()

    # Check if this is a glob pattern
    if "*" in source:
        return _load_glob_pattern(source, as_format, **options)

    # Get local path (downloads if remote)
    try:
        local_path = cache.get(source)
    except Exception as e:
        raise FileNotFoundError(f"Failed to access {source}: {e}")

    # Load with DuckDB
    engine = get_engine()
    relation = engine.read_file(local_path)

    # Convert to requested format
    if as_format == "duckdb":
        return relation
    elif as_format == "pandas":
        return engine.to_df(relation, "pandas")
    elif as_format == "polars":
        try:
            return engine.to_df(relation, "polars")
        except ImportError:
            raise ImportError("polars is not installed. Install with: pip install warpdata[polars]")
    elif as_format == "arrow":
        return engine.to_df(relation, "arrow")
    else:
        raise ValueError(f"Unsupported format: {as_format}")


def _load_glob_pattern(pattern: str, as_format: str = "duckdb", **options) -> Any:
    """
    Load multiple files matching a glob pattern.

    Args:
        pattern: Glob pattern
        as_format: Output format
        **options: Additional options

    Returns:
        Data in requested format
    """
    # Get filesystem
    fs = get_filesystem(pattern)

    # Find matching files
    matches = fs.glob(pattern)

    if not matches:
        raise FileNotFoundError(f"No files found matching pattern: {pattern}")

    # Get cache
    cache = get_cache()

    # Download all files to cache
    local_paths = []
    for match in matches:
        local_path = cache.get(match)
        local_paths.append(local_path)

    # Load all files and union them
    engine = get_engine()
    relation = engine.read_files(local_paths)

    # Convert to requested format
    if as_format == "duckdb":
        return relation
    elif as_format == "pandas":
        return engine.to_df(relation, "pandas")
    elif as_format == "polars":
        try:
            return engine.to_df(relation, "polars")
        except ImportError:
            raise ImportError("polars is not installed. Install with: pip install warpdata[polars]")
    elif as_format == "arrow":
        return engine.to_df(relation, "arrow")
    else:
        raise ValueError(f"Unsupported format: {as_format}")


def _load_registered_dataset(
    uri,
    as_format: str = "duckdb",
    include_rid: bool = False,
    auto_pull: bool = True,
    limit: Optional[int] = None,
    **options
) -> Any:
    """
    Load a registered dataset from the registry.

    Args:
        uri: Parsed warpdata:// URI
        as_format: Output format
        include_rid: If True, load from materialized parquet to include rid column
        auto_pull: If True, automatically pull dataset from remote if not found locally
        limit: Optional row limit. Downloads only enough shards to satisfy the limit.
        **options: Additional options

    Returns:
        Data in requested format
    """
    # Import here to avoid circular dependency
    from ..core.registry import get_registry

    registry = get_registry()

    # Resolve version
    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    # Get dataset version info
    dataset_info = registry.get_dataset_version(workspace, name, version)

    if dataset_info is None:
        if auto_pull:
            # Try to pull from remote
            dataset_info = _try_auto_pull(workspace, name, version)
        if dataset_info is None:
            raise ValueError(f"Dataset not found: {uri}")

    # If include_rid is True, try to load from materialized parquet
    if include_rid:
        cache = get_cache()
        dataset_cache_dir = cache.get_dataset_cache_dir(
            workspace, name, dataset_info["version_hash"]
        )
        materialized_path = dataset_cache_dir / "materialized.parquet"

        if materialized_path.exists():
            # Load directly from materialized parquet which includes rid
            engine = get_engine()
            relation = engine.conn.sql(f"SELECT * FROM read_parquet('{materialized_path}')")

            # Convert to requested format
            if as_format == "duckdb":
                return relation
            elif as_format == "pandas":
                return engine.to_df(relation, "pandas")
            elif as_format == "polars":
                try:
                    return engine.to_df(relation, "polars")
                except ImportError:
                    raise ImportError("polars is not installed. Install with: pip install warpdata[polars]")
            elif as_format == "arrow":
                return engine.to_df(relation, "arrow")
            else:
                raise ValueError(f"Unsupported format: {as_format}")
        else:
            # Materialized file doesn't exist - fall back to normal loading
            # (rid won't be available)
            pass

    # Load manifest
    manifest = registry.get_manifest(workspace, name, dataset_info["version_hash"])

    if manifest is None:
        raise ValueError(f"Manifest not found for {uri}")

    # Get resources from manifest
    resources = manifest.get("resources", [])

    if not resources:
        raise ValueError(f"No resources found in manifest for {uri}")

    # Shard-aware loading: if limit is specified and we have row counts,
    # only download enough shards to satisfy the limit
    resources_to_load = resources
    if limit is not None and len(resources) > 1:
        # Check if resources have row_count metadata
        has_row_counts = all(r.get("row_count") is not None for r in resources)
        if has_row_counts:
            resources_to_load = []
            cumulative_rows = 0
            for resource in resources:
                resources_to_load.append(resource)
                cumulative_rows += resource["row_count"]
                if cumulative_rows >= limit:
                    break
            if len(resources_to_load) < len(resources):
                print(f"  ⚡ Shard-aware: downloading {len(resources_to_load)}/{len(resources)} shards for limit={limit}")

    # Load selected resources
    cache = get_cache()
    local_paths = []

    try:
        for resource in resources_to_load:
            resource_uri = resource["uri"]
            local_path = cache.get(resource_uri)
            local_paths.append(local_path)
    except FileNotFoundError as e:
        if auto_pull:
            # Files missing locally, try to pull from remote
            print(f"  📥 Dataset files not found locally, pulling from remote...")
            _do_auto_pull(workspace, name)

            # Re-fetch dataset info and manifest after pull (URIs may have changed)
            dataset_info = registry.get_dataset_version(workspace, name, version)
            if dataset_info is None:
                raise ValueError(f"Dataset not found after pull: {uri}")
            manifest = registry.get_manifest(workspace, name, dataset_info["version_hash"])
            if manifest is None:
                raise ValueError(f"Manifest not found after pull: {uri}")
            resources = manifest.get("resources", [])
            file_format = manifest.get("format")

            # Re-apply shard selection after pull
            resources_to_load = resources
            if limit is not None and len(resources) > 1:
                has_row_counts = all(r.get("row_count") is not None for r in resources)
                if has_row_counts:
                    resources_to_load = []
                    cumulative_rows = 0
                    for resource in resources:
                        resources_to_load.append(resource)
                        cumulative_rows += resource["row_count"]
                        if cumulative_rows >= limit:
                            break

            # Retry loading after pull with updated resources
            local_paths = []
            for resource in resources_to_load:
                resource_uri = resource["uri"]
                local_path = cache.get(resource_uri)
                local_paths.append(local_path)
        else:
            raise FileNotFoundError(f"Local file not found: {e}") from e

    # Load with DuckDB
    engine = get_engine()
    file_format = manifest.get("format")  # Get format from manifest
    relation = engine.read_files(local_paths, file_format=file_format)

    # Apply limit after loading
    if limit is not None:
        relation = relation.limit(limit)

    # Convert to requested format
    if as_format == "duckdb":
        return relation
    elif as_format == "pandas":
        return engine.to_df(relation, "pandas")
    elif as_format == "polars":
        try:
            return engine.to_df(relation, "polars")
        except ImportError:
            raise ImportError("polars is not installed. Install with: pip install warpdata[polars]")
    elif as_format == "arrow":
        return engine.to_df(relation, "arrow")
    else:
        raise ValueError(f"Unsupported format: {as_format}")


def load_table(
    dataset_id: str,
    table: str,
    as_format: str = "duckdb",
    **options,
):
    """
    Load a specific logical table from a multi-table dataset.

    Tables are stored in the dataset manifest under metadata.tables.

    Args:
        dataset_id: Dataset ID (warpdata://workspace/name)
        table: Table name (e.g., 'signals')
        as_format: Output format ('duckdb', 'pandas', 'polars', 'arrow')

    Returns:
        Data in requested format
    """
    from ..core.registry import get_registry

    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    registry = get_registry()
    version = uri.version or "latest"
    dataset_info = registry.get_dataset_version(uri.workspace, uri.name, version)
    if dataset_info is None:
        raise ValueError(f"Dataset not found: {dataset_id}")

    manifest = registry.get_manifest(uri.workspace, uri.name, dataset_info["version_hash"])
    if manifest is None:
        raise ValueError(f"Manifest not found for {dataset_id}")

    tables = ((manifest.get("metadata") or {}).get("tables") or {})
    if table not in tables:
        raise ValueError(f"Table '{table}' not found in dataset: {dataset_id}")

    table_resources = tables[table]
    if not isinstance(table_resources, list) or not table_resources:
        raise ValueError(f"Table '{table}' has no resources in dataset: {dataset_id}")

    cache = get_cache()
    local_paths = [cache.get(p) for p in table_resources]

    # Load with DuckDB
    engine = get_engine()
    relation = engine.read_files(local_paths)

    if as_format == "duckdb":
        return relation
    elif as_format == "pandas":
        return engine.to_df(relation, "pandas")
    elif as_format == "polars":
        try:
            return engine.to_df(relation, "polars")
        except ImportError:
            raise ImportError("polars is not installed. Install with: pip install warpdata[polars]")
    elif as_format == "arrow":
        return engine.to_df(relation, "arrow")
    else:
        raise ValueError(f"Unsupported format: {as_format}")


def schema(source: str) -> Dict[str, str]:
    """
    Get the schema of a data source.

    Args:
        source: Data source URI or path

    Returns:
        Dictionary mapping column names to types

    Examples:
        >>> import warpdata as wd
        >>> schema = wd.schema("data.parquet")
        >>> print(schema)
        {'id': 'BIGINT', 'name': 'VARCHAR', 'value': 'DOUBLE'}
    """
    # Support shorthand dataset names without workspace or scheme.
    # Match behavior of load(): if no scheme and path doesn't exist locally,
    # attempt to resolve against the registry.
    if "://" not in source:
        p = Path(source)
        if not p.exists():
            reg = get_registry()
            # Support shorthand 'workspace/name' as well as plain 'name'
            if "/" in source:
                try:
                    workspace, name = source.split("/", 1)
                except ValueError:
                    workspace, name = None, None
                if workspace and name:
                    info = reg.get_dataset_version(workspace, name, "latest")
                    if info is not None:
                        source = f"warpdata://{workspace}/{name}"
            if "://" not in source:
                # Find all datasets matching this name across workspaces
                matches = [ds for ds in reg.list_datasets() if ds.get("name") == source]
                if len(matches) == 1:
                    ws = matches[0].get("workspace") or get_config().default_workspace
                    source = f"warpdata://{ws}/{source}"
                elif len(matches) > 1:
                    # Prefer default workspace if present, otherwise ambiguous
                    default_ws = get_config().default_workspace
                    preferred = [m for m in matches if m.get("workspace") == default_ws]
                    if len(preferred) == 1:
                        source = f"warpdata://{default_ws}/{source}"
                    else:
                        raise ValueError(
                            "Ambiguous dataset name. Found in workspaces: "
                            + ", ".join(sorted({m.get('workspace') for m in matches}))
                            + ". Specify full ID like 'warpdata://workspace/" + source + "' "
                            + "or set WARPDATA_DEFAULT_WORKSPACE."
                        )

    # Parse URI (after possible rewrite)
    uri = parse_uri(source)

    # Get cache
    cache = get_cache()

    # For registered datasets, we could get schema from manifest
    # For now, just load the first file
    if uri.is_warpdata:
        # Load a small sample to get schema
        relation = load(source, as_format="duckdb")
        schema_dict = {}
        for col_name, col_type in zip(relation.columns, relation.types):
            schema_dict[col_name] = str(col_type)
        return schema_dict

    # For direct URIs
    local_path = cache.get(source)

    # Get schema using DuckDB
    engine = get_engine()
    return engine.get_schema(local_path)


def head(source: str, n: int = 5, as_format: str = "duckdb") -> Any:
    """
    Preview the first N rows of a data source.

    Args:
        source: Data source URI or path
        n: Number of rows to return (default: 5)
        as_format: Output format ('duckdb', 'pandas', 'polars')

    Returns:
        First N rows in requested format

    Examples:
        >>> import warpdata as wd
        >>> preview = wd.head("data.parquet", n=10)
        >>> print(preview)
    """
    # Load the full data and limit it
    # This is simple but could be optimized to read only N rows
    relation = load(source, as_format="duckdb")
    limited = relation.limit(n)

    # Convert to requested format
    if as_format == "duckdb":
        return limited
    elif as_format == "pandas":
        engine = get_engine()
        return engine.to_df(limited, "pandas")
    elif as_format == "polars":
        try:
            engine = get_engine()
            return engine.to_df(limited, "polars")
        except ImportError:
            raise ImportError("polars is not installed. Install with: pip install warpdata[polars]")
    else:
        raise ValueError(f"Unsupported format: {as_format}")
