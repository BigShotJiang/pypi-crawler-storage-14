"""
Database migrations for warpdata registry.
"""
from pathlib import Path
from typing import List, Tuple
import sqlite3
import re
import threading

# Global lock to prevent concurrent migrations
_migration_lock = threading.Lock()


class Migration:
    """Base class for migrations."""

    version: int
    description: str

    @staticmethod
    def upgrade(conn: sqlite3.Connection):
        """Apply the migration."""
        raise NotImplementedError

    @staticmethod
    def downgrade(conn: sqlite3.Connection):
        """Revert the migration."""
        raise NotImplementedError


def get_migrations_dir() -> Path:
    """Get the migrations directory."""
    return Path(__file__).parent


def discover_migrations() -> List[Tuple[int, type]]:
    """Discover all migration files."""
    migrations_dir = get_migrations_dir()
    migrations = []

    for file in sorted(migrations_dir.glob("*.py")):
        if file.name.startswith("_") or file.name == "__init__.py":
            continue

        # Extract version from filename (e.g., "001_add_raw_data.py" -> 1)
        match = re.match(r"(\d+)_.*\.py", file.name)
        if match:
            version = int(match.group(1))
            # Import the module
            module_name = f"warpdata.migrations.{file.stem}"
            try:
                module = __import__(module_name, fromlist=["Migration"])
                if hasattr(module, "Migration"):
                    migrations.append((version, module.Migration))
            except ImportError:
                pass

    return sorted(migrations, key=lambda x: x[0])


def get_current_version(conn: sqlite3.Connection) -> int:
    """Get current schema version from database."""
    try:
        cursor = conn.execute("SELECT version FROM schema_version ORDER BY version DESC LIMIT 1")
        row = cursor.fetchone()
        return row[0] if row else 0
    except sqlite3.OperationalError:
        # Table doesn't exist yet
        return 0


def init_schema_version(conn: sqlite3.Connection):
    """Initialize schema_version table."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()


def migrate(conn: sqlite3.Connection, target_version: int = None):
    """
    Run migrations to bring database to target version.

    Thread-safe: uses a global lock to prevent concurrent migrations.

    Args:
        conn: Database connection
        target_version: Target version (None = latest)
    """
    with _migration_lock:
        init_schema_version(conn)
        current = get_current_version(conn)
        migrations = discover_migrations()

        if target_version is None:
            target_version = migrations[-1][0] if migrations else 0

        if current >= target_version:
            return  # Already at target or beyond

        # Apply migrations
        for version, migration_class in migrations:
            if current < version <= target_version:
                print(f"Applying migration {version}: {migration_class.description}")
                migration_class.upgrade(conn)
                conn.execute("INSERT INTO schema_version (version) VALUES (?)", (version,))
                conn.commit()
                current = version
