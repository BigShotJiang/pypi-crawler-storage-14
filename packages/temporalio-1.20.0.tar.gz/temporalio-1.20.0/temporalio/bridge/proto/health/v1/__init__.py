from .health_pb2 import HealthCheckRequest, HealthCheckResponse

__all__ = [
    "HealthCheckRequest",
    "HealthCheckResponse",
]
