from pydantic import BaseModel, Field
from typing import Dict, Any

class MainResponseModel(BaseModel):
    user_message: str = Field(..., description="Это текст, который отправишь пользователю.")
    
    service_info: Dict[str, Any] = Field(..., default_factory=dict, description="Служебная информация в json формате")
