from setuptools import setup, find_packages

setup(
    name="ticketdiscount",
    version="0.1.0",
    packages=find_packages(),
    description="Seat discount library for TicketBuddy",
    author="Himaja",
    author_email="Himaja@example.com",
    license="MIT",
)