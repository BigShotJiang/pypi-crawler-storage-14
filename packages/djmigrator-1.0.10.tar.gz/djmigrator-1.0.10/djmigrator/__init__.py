"""
djmigrator - Smart Django migration manager.

This package auto-registers management commands so they work without INSTALLED_APPS.
"""
# Import management module to trigger command registration
try:
    from djmigrator import management  # noqa: F401
except ImportError:
    pass

