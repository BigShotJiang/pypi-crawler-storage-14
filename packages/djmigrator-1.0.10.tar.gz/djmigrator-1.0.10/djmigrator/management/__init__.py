"""
Auto-register management commands so they work without INSTALLED_APPS.
This module patches Django's get_commands to include djmigrator commands.
"""

def _patch_get_commands():
    """Patch Django's get_commands to include djmigrator commands."""
    try:
        from django.core.management import get_commands as django_get_commands
        import django.core.management
        
        # Store original if not already stored
        if not hasattr(django.core.management, '_original_get_commands'):
            django.core.management._original_get_commands = django_get_commands
        
        def patched_get_commands():
            """Patched version that includes djmigrator commands."""
            # Get the original commands
            commands = django.core.management._original_get_commands()
            
            # Add our command if not already present
            if 'smart_makemigrations' not in commands:
                try:
                    # Verify the command class exists
                    from djmigrator.management.commands.smart_makemigrations import Command
                    # Add to the commands dict
                    commands['smart_makemigrations'] = 'djmigrator.management.commands.smart_makemigrations'
                except ImportError:
                    # Command not available
                    pass
            
            return commands
        
        # Patch the function
        django.core.management.get_commands = patched_get_commands
        
        # Also patch the imported function in the module namespace
        try:
            import django.core.management.__init__
            django.core.management.__init__.get_commands = patched_get_commands
        except (AttributeError, ImportError):
            pass
            
    except (ImportError, AttributeError):
        # Django not available or structure different
        pass

# Patch when this module is imported
_patch_get_commands()


