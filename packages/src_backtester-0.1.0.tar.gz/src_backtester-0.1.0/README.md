https://pmonsivaisrivera08.github.io/src_backtester/

check the link for more info