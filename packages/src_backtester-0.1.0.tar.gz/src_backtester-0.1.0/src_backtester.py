import pandas as pd
import pandas_ta as ta 
import numpy as np
import yfinance as yf 
import matplotlib.pyplot as plt 
import inspect
from typing import Tuple, List, Callable, Any, Dict, Optional

# ==============================================================================
# 1. CONSTANTES Y CONFIGURACIÓN DE RIESGO
# ==============================================================================

ANNUALIZATION_FACTOR = 252 # Días de trading en un año
RISK_FREE_RATE = 0.02      # Tasa libre de riesgo anual (2% por defecto)

StrategyFunction = Callable[[pd.DataFrame, Tuple[Any, ...]], pd.Series]

class StrategyConfig:
    """
    Configuración de gestión de riesgo para la estrategia. 
    Todos los parámetros son OPCIONALES y se usan como FILTROS de salida.
    """
    def __init__(self, 
                 take_profit_ratio: Optional[float] = None, # Porcentaje (ej: 0.03 para 3%)
                 stop_loss_ratio: Optional[float] = None,    # Porcentaje (ej: 0.02 para 2%)
                 min_trades: int = 30,
                 min_votes_required: Optional[int] = None): # Mínimo de indicadores en señal de compra (1)
        """
        Inicializa la configuración de riesgo.
        :param take_profit_ratio: Porcentaje de ganancia para cerrar una posición.
        :param stop_loss_ratio: Porcentaje de pérdida para cerrar una posición.
        :param min_trades: Número mínimo de operaciones para validar la estadística.
        :param min_votes_required: Mínimo de indicadores (en la meta-estrategia) que deben votar Largo (1).
        """
        self.take_profit = take_profit_ratio
        self.stop_loss = stop_loss_ratio
        self.min_trades = min_trades
        self.min_votes_required = min_votes_required
        # print(f"-> Configuración de Riesgo: TP={self.take_profit}, SL={self.stop_loss}, Votos={self.min_votes_required}")

# ==============================================================================
# 2. INDICADORES TÉCNICOS BASE Y GENÉRICOS 
# ==============================================================================

# --- Funciones Base ESPECÍFICAS (Lógica de Cruce de Medias Móviles) ---

def _calculate_sma(data: pd.DataFrame, params: Tuple[Any, ...]) -> pd.Series:
    """Cruce de Medias Móviles Simples (SMA). Params: (Rápido, Lento)."""
    if len(params) < 2: raise ValueError("SMA requiere 2 periodos: (Rápido, Lento).")
    fast_p, slow_p = params[0], params[1]
    data.ta.sma(length=fast_p, append=True)
    data.ta.sma(length=slow_p, append=True)
    sma_fast = data[f'SMA_{fast_p}']
    sma_slow = data[f'SMA_{slow_p}']
    # Posición Larga (1) si la SMA Rápida cruza por encima de la SMA Lenta
    position = (sma_fast > sma_slow).fillna(False).astype(int)
    return position

def _calculate_ema(data: pd.DataFrame, params: Tuple[Any, ...]) -> pd.Series:
    """Cruce de Medias Móviles Exponenciales (EMA). Params: (Rápido, Lento)."""
    if len(params) < 2: raise ValueError("EMA requiere 2 periodos: (Rápido, Lento).")
    fast_p, slow_p = params[0], params[1]
    data.ta.ema(length=fast_p, append=True)
    data.ta.ema(length=slow_p, append=True)
    ema_fast = data[f'EMA_{fast_p}']
    ema_slow = data[f'EMA_{slow_p}']
    # Posición Larga (1) si la EMA Rápida cruza por encima de la EMA Lenta
    position = (ema_fast > ema_slow).fillna(False).astype(int)
    return position

def _calculate_macd(data: pd.DataFrame, params: Tuple[Any, ...]) -> pd.Series:
    """MACD Crossover. Params: (Fast, Slow, Signal)."""
    if len(params) < 3: raise ValueError("MACD requiere 3 parámetros: (Fast, Slow, Signal).")
    fast_p, slow_p, signal_p = params
    data.ta.macd(fast=fast_p, slow=slow_p, signal=signal_p, append=True)
    macd_line_col = f'MACD_{fast_p}_{slow_p}_{signal_p}'
    signal_line_col = f'MACDs_{fast_p}_{slow_p}_{signal_p}'
    macd_line = data[macd_line_col]
    signal_line = data[signal_line_col]
    # Compra (1) cuando la línea MACD cruza por encima de la línea de señal
    crossover = (macd_line.shift(1) < signal_line.shift(1)) & (macd_line > signal_line)
    position = pd.Series(0, index=data.index)
    position[crossover] = 1 
    return position.ffill().fillna(0)

# --- Función Genérica para Todos los demás Indicadores de pandas_ta ---

def _calculate_generic_indicator(data: pd.DataFrame, params: Tuple[Any, ...], indicator_name: str) -> pd.Series:
    """
    Función genérica para ejecutar cualquier indicador de pandas_ta.
    Genera una señal de posición simple (1 o 0) basada en la salida del indicador.
    """
    # 1. Obtener la función de pandas_ta
    ta_method = getattr(data.ta, indicator_name.lower(), None)
    if not ta_method:
        # En una ejecución real, esto ya se habría filtrado, pero es una seguridad.
        return pd.Series(0, index=data.index)

    # 2. Preparar argumentos para pandas_ta (similar a la versión anterior)
    kwargs = {}
    sig = inspect.signature(ta_method)
    param_names = list(sig.parameters.keys())
    params_to_use = [p for p in param_names if p not in ['append', 'offset', 'fillna', 'dlength', 'kwargs']]
    
    for i, p_name in enumerate(params_to_use):
        if i < len(params):
            kwargs[p_name] = params[i]
        elif p_name in ['length', 'period']:
            kwargs[p_name] = 14 # Usar valor por defecto

    # 3. Ejecutar el indicador
    ta_method(append=True, **kwargs)
    
    # 4. Generar la Señal (Lógica de Posicionamiento SIMPLE y Generalizada)
    indicator_cols = [col for col in data.columns if indicator_name.lower() in col.lower() and col not in ['Open', 'High', 'Low', 'Close', 'Volume', 'Returns', 'Strategy_Returns', 'Drawdown']]
    
    if not indicator_cols:
         return pd.Series(0, index=data.index)
        
    main_col = indicator_cols[0] 

    # Estrategia 1: Si el indicador es un oscilador de rango fijo (ej: RSI, KDJ, Stoch), usar umbrales (30/70 o K/D)
    # Sin embargo, la lógica de cruce de precio de cierre vs. la línea del indicador es más segura para la mayoría de indicadores dinámicos (como TEMA, VWAP, etc.)
    
    # Estrategia 2: Cierre sobre la línea del indicador (más seguro y aplicable a TEMA, VWAP, etc.)
    # Posición Larga si el precio de Cierre está por encima de la línea del indicador
    position = (data['Close'] > data[main_col]).fillna(False).astype(int)

    # 5. Lógica para KDJ: si es KDJ, la señal es %K > %D
    if indicator_name.upper() == 'KDJ':
        # Buscamos las columnas específicas de KDJ
        kdj_cols = [col for col in data.columns if 'KDJ' in col and ('K' in col or 'D' in col)]
        k_col = next((c for c in kdj_cols if 'K' in c), None)
        d_col = next((c for c in kdj_cols if 'D' in c), None)
        if k_col and d_col:
            position = (data[k_col] > data[d_col]).fillna(False).astype(int)


    return position.reindex(data.index, fill_value=0)


# Mapeo de nombres de indicadores a sus funciones de cálculo
INDICATORS: Dict[str, StrategyFunction] = {
    "SMA": _calculate_sma,
    "EMA": _calculate_ema, 
    "MACD": _calculate_macd, 
    # TEMA se maneja por el indicador genérico
    # BBANDS se maneja por el indicador genérico (usa Close > BBL por defecto)
    # ADX se maneja por el indicador genérico (usa Close > ADX por defecto, lo cual es inusual, pero lo permite)
}

# --- Adición DINÁMICA de todos los indicadores de pandas_ta (Más de 300) ---
# ... (Igual que antes)
ta_methods = [
    attr for attr in dir(ta.DataFrame.ta) 
    if not attr.startswith('_') and callable(getattr(ta.DataFrame.ta, attr))
    and attr.lower() not in ['strategy', 'percent_return', 'all'] 
]

for method_name in ta_methods:
    indicator_name_upper = method_name.upper()
    if indicator_name_upper not in INDICATORS:
        # Crea un wrapper lambda para pasar el nombre del indicador a la función genérica
        INDICATORS[indicator_name_upper] = lambda data, params, name=indicator_name_upper: \
            _calculate_generic_indicator(data, params, name)
        
# ==============================================================================
# 3. EJECUTOR DE META-ESTRATEGIA (GESTIÓN DE RIESGO INCLUIDA)
# ==============================================================================

def _apply_risk_management(df: pd.DataFrame, config: StrategyConfig) -> pd.Series:
    """
    Aplica filtros de Take Profit (TP) y Stop Loss (SL) a las señales base.
    """
    # ... (El código de gestión de riesgo es idéntico al anterior) ...
    position = df['Signal_Base'].copy()
    close_prices = df['Close']
    
    # Iterar sobre las fechas donde la posición pasa de 0 a 1 (Punto de Entrada)
    entry_indices = position[position.diff() == 1].index
    
    for entry_date in entry_indices:
        entry_price = close_prices.loc[entry_date]
        
        # Determinar el punto de salida potencial según la señal base (donde vuelve a 0)
        exit_candidates = position.loc[entry_date:].index[
            (position.loc[entry_date:].shift(1) == 1) & (position.loc[entry_date:] == 0)
        ]
        
        try:
            exit_date_base = exit_candidates[0] if not exit_candidates.empty else df.index[-1]
        except IndexError:
            exit_date_base = df.index[-1]
            
        if entry_date == df.index[-1] and position.iloc[-1] == 1:
             continue
        
        trade_period = df.loc[entry_date:exit_date_base].index
        
        position.loc[entry_date:exit_date_base] = 1 
        
        # Buscar el cierre por SL/TP dentro de este período
        sl_tp_hit = False
        for current_date in trade_period[1:]: 
            current_price = close_prices.loc[current_date]
            
            pnl_ratio = (current_price - entry_price) / entry_price
            
            # Aplicar Take Profit (TP)
            if config.take_profit is not None and pnl_ratio >= config.take_profit:
                sl_tp_hit = True
                position.loc[current_date:] = 0 # Cierra la posición
                break
                
            # Aplicar Stop Loss (SL)
            if config.stop_loss is not None and pnl_ratio <= -config.stop_loss:
                sl_tp_hit = True
                position.loc[current_date:] = 0 # Cierra la posición
                break
        
        if sl_tp_hit:
            # Buscar la siguiente señal de entrada '1' en la señal base (Signal_Base)
            next_entry_candidates = df['Signal_Base'].loc[current_date:].index[
                (df['Signal_Base'].loc[current_date:].shift(1) == 0) & 
                (df['Signal_Base'].loc[current_date:] == 1)
            ]
            
            if not next_entry_candidates.empty:
                next_entry_date = next_entry_candidates[0]
                position.loc[next_entry_date] = 1 
                position.loc[next_entry_date:] = df['Signal_Base'].loc[next_entry_date:]


    return position.ffill().fillna(0) # Asegura que la posición sea 0 o 1


def _meta_strategy_executor(data: pd.DataFrame, 
                          params: Tuple[Any, ...]) -> pd.Series:
    """
    Ejecuta múltiples estrategias de indicadores y combina sus señales.
    """
    # ... (El código de meta-estrategia es idéntico al anterior) ...
    strategy_specs: List[Tuple[str, Tuple[Any, ...]]] = params[0]
    config: StrategyConfig = params[1]
    
    signal_columns = []
    
    # 1. Generar señales individuales de indicadores
    for i, (strategy_name, sub_params) in enumerate(strategy_specs):
        strategy_name_upper = strategy_name.upper()
        indicator_func = INDICATORS.get(strategy_name_upper)
        
        if not indicator_func: 
            print(f"Advertencia: Indicador '{strategy_name}' no encontrado y omitido.")
            continue
            
        position_series = indicator_func(data, sub_params)
        signal_col_name = f'Indicator_Signal_{i}'
        data[signal_col_name] = position_series
        signal_columns.append(signal_col_name)
        
    if not signal_columns:
        return pd.Series(0, index=data.index)

    # 2. Combinación de Señales (Lógica de Votación)
    total_signals = data[signal_columns].sum(axis=1)
    n_strategies = len(signal_columns)
    
    min_votes = config.min_votes_required if config.min_votes_required is not None else (n_strategies / 2)
    
    final_position_mask = total_signals > min_votes 
    data['Signal_Base'] = final_position_mask.astype(int)
    
    # 3. Aplicar Gestión de Riesgo (TP/SL)
    final_position = _apply_risk_management(data, config)
    
    return final_position.reindex(data.index, fill_value=0)

# ==============================================================================
# 4. CLASE BACKTESTER (Cálculo de Métricas)
# ==============================================================================

class Backtester:
    """
    Clase principal para ejecutar backtests.
    Procesa las señales y calcula métricas de rendimiento y riesgo.
    """
    def __init__(self, data: pd.DataFrame):
        """Inicializa el backtester con los datos históricos."""
        if 'Close' not in data.columns:
            raise ValueError("El DataFrame de datos debe tener una columna 'Close'.")
        self.data = data.copy()
        self.results = None

    def _execute_strategy(self, strategy_func: StrategyFunction, params: Any) -> pd.Series:
        """Aplica la función de estrategia a los datos y verifica la señal."""
        signals = strategy_func(self.data, params) 
        
        is_valid_series = isinstance(signals, pd.Series)
        if not is_valid_series or not signals.dropna().isin([0, 1]).all():
             raise TypeError("La función de estrategia debe devolver una Serie de Pandas de POSICIONES (1 o 0).")

        return signals

    # --- MÉTODOS DE CÁLCULO DE MÉTRICAS ---
    
    # ... (Todos los métodos de métricas son idénticos al anterior) ...
    def _calculate_sharpe_ratio(self, strategy_returns: pd.Series) -> float:
        """Sharpe Ratio (Retorno Ajustado por Riesgo)."""
        daily_risk_free_rate = (1 + RISK_FREE_RATE)**(1/ANNUALIZATION_FACTOR) - 1
        excess_returns = strategy_returns - daily_risk_free_rate
        avg_excess_return = excess_returns.mean() * ANNUALIZATION_FACTOR
        volatility = strategy_returns.std() * np.sqrt(ANNUALIZATION_FACTOR)
        if volatility == 0 or np.isnan(volatility): return 0.0
        return avg_excess_return / volatility

    def _calculate_sortino_ratio(self, strategy_returns: pd.Series) -> float:
        """Sortino Ratio (Penaliza solo volatilidad negativa)."""
        daily_risk_free_rate = (1 + RISK_FREE_RATE)**(1/ANNUALIZATION_FACTOR) - 1
        excess_returns = strategy_returns - daily_risk_free_rate
        avg_excess_return = excess_returns.mean() * ANNUALIZATION_FACTOR
        downside_returns = excess_returns[excess_returns < 0]
        if downside_returns.empty: return 999.99 if avg_excess_return > 0 else 0.0
        downside_deviation_annualized = downside_returns.std(ddof=0) * np.sqrt(ANNUALIZATION_FACTOR)
        if downside_deviation_annualized == 0 or np.isnan(downside_deviation_annualized): return 0.0
        return avg_excess_return / downside_deviation_annualized
    
    def _calculate_profit_factor(self, strategy_returns: pd.Series) -> float:
        """Profit Factor (Ganancias Totales / Pérdidas Totales)."""
        returns_clean = strategy_returns.dropna()
        gross_profit = returns_clean[returns_clean > 0].sum()
        gross_loss = -returns_clean[returns_clean < 0].sum()
        if gross_loss == 0 or np.isnan(gross_loss): return 999.99 if gross_profit > 0 else 0.0
        return gross_profit / gross_loss

    def _analyze_trades(self, df: pd.DataFrame) -> Tuple[float, float, float, float, int, float]:
        """Calcula métricas por trade (Expectancy, R/R, etc.)."""
        df_trades = df[['Strategy_Returns', 'Position']].dropna()
        if df_trades.empty: return 0.0, 0.0, 0.0, 0.0, 0, 0.0

        trade_returns = []
        trade_durations = [] 
        trade_groups_id = (df_trades['Position'] != df_trades['Position'].shift(1)).cumsum()
        active_trade_groups = df_trades[df_trades['Position'] == 1].groupby(trade_groups_id)
        
        for group_id, group in active_trade_groups:
            trade_return_series = 1 + group['Strategy_Returns']
            if not trade_return_series.empty:
                net_trade_return = trade_return_series.prod() - 1
                trade_returns.append(net_trade_return)
                trade_durations.append(len(group))

        if not trade_returns: return 0.0, 0.0, 0.0, 0.0, 0, 0.0
            
        trade_returns_series = pd.Series(trade_returns)
        trade_durations_series = pd.Series(trade_durations)
        total_trades = len(trade_returns_series)
        winning_trades = trade_returns_series[trade_returns_series > 0]
        num_wins = len(winning_trades)
        avg_win = winning_trades.mean() if num_wins > 0 else 0.0
        losing_trades = trade_returns_series[trade_returns_series < 0]
        num_losses = len(losing_trades)
        avg_loss = losing_trades.mean() if num_losses > 0 else 0.0
        p_win = num_wins / total_trades if total_trades > 0 else 0.0
        p_loss = num_losses / total_trades if total_trades > 0 else 0.0
        avg_duration_days = trade_durations_series.mean()
        
        return avg_win, avg_loss, p_win, p_loss, total_trades, avg_duration_days

    def _calculate_expectancy(self, avg_win: float, avg_loss: float, p_win: float, p_loss: float) -> float:
        """Expectancy (Ganancia esperada por trade)."""
        return (p_win * avg_win) + (p_loss * avg_loss)

    def _calculate_risk_reward_ratio(self, avg_win: float, avg_loss: float) -> float:
        """Ratio Riesgo/Recompensa (Promedio Ganancia / Promedio Pérdida)."""
        abs_avg_loss = abs(avg_loss)
        if abs_avg_loss == 0.0: return 999.99 if avg_win > 0 else 0.0 
        return abs(avg_win) / abs_avg_loss 

    def run(self, strategy_name: str, strategy_func: StrategyFunction, params: Any, config: StrategyConfig): 
        """Ejecuta el backtest con la función de estrategia y la configuración de riesgo."""
        df = self.data.copy()
        
        print(f"-> Aplicando estrategia '{strategy_name}' con Config: TP={config.take_profit}, SL={config.stop_loss}, Votos={config.min_votes_required}")
        signals = self._execute_strategy(strategy_func, params)
        df['Position'] = signals.reindex(df.index, fill_value=0)

        # Cálculo de rendimientos
        df['Returns'] = df['Close'].pct_change()
        # Se asume posición del día anterior (shift(1)) para evitar mirar al futuro
        df['Strategy_Returns'] = df['Returns'] * df['Position'].shift(1) 

        # Curva de Equity y Drawdown
        df['Cumulative_Strategy_Return'] = (1 + df['Strategy_Returns']).fillna(1).cumprod()
        df['Cumulative_Market_Return'] = (1 + df['Returns']).fillna(1).cumprod()
        cumulative_max = df['Cumulative_Strategy_Return'].cummax()
        df['Drawdown'] = 1 - (df['Cumulative_Strategy_Return'] / cumulative_max)
        
        self.results = df.copy() 
        self.data = df 

        # Cálculo de métricas
        strategy_returns_clean = self.results['Strategy_Returns'].dropna()
        if strategy_returns_clean.empty:
            total_strategy_return, total_market_return = 0, 0
            sharpe_ratio, sortino_ratio, profit_factor, max_drawdown = 0.0, 0.0, 0.0, 0.0
            expectancy, risk_reward_ratio, total_trades, p_win, avg_duration_days = 0.0, 0.0, 0, 0.0, 0.0
        else:
            total_strategy_return = self.results['Cumulative_Strategy_Return'].iloc[-1] - 1
            total_market_return = self.results['Cumulative_Market_Return'].iloc[-1] - 1
            sharpe_ratio = self._calculate_sharpe_ratio(strategy_returns_clean)
            sortino_ratio = self._calculate_sortino_ratio(strategy_returns_clean) 
            profit_factor = self._calculate_profit_factor(strategy_returns_clean)
            max_drawdown = self.results['Drawdown'].max()
            avg_win, avg_loss, p_win, p_loss, total_trades, avg_duration_days = self._analyze_trades(self.results)
            expectancy = self._calculate_expectancy(avg_win, avg_loss, p_win, p_loss)
            risk_reward_ratio = self._calculate_risk_reward_ratio(avg_win, avg_loss)

        avg_duration_months = avg_duration_days / (ANNUALIZATION_FACTOR / 12)

        # Presentación de Resultados
        print("\n--- Resultados del Backtest ---")
        print(f"Ticker: {self.data.attrs.get('ticker', 'N/A')} | Período: {len(self.data)} días")
        print(f"Retorno Acumulado de la Estrategia: {total_strategy_return * 100:.2f}%")
        print(f"Retorno Acumulado del Mercado (Benchmark): {total_market_return * 100:.2f}%")
        print("--- Métricas de Riesgo y Eficiencia ---")
        print(f"Sharpe Ratio (Anualizado): {sharpe_ratio:.2f}") 
        print(f"Sortino Ratio (Anualizado): {sortino_ratio:.2f}") 
        print(f"Máximo Drawdown (MDD): {max_drawdown * 100:.2f}%") 
        print("--- Métricas por Trade ---")
        print(f"Total de Trades Cerrados: {total_trades}")
        if total_trades < config.min_trades:
            print(f"ADVERTENCIA: Total trades ({total_trades}) es menor al mínimo estadístico recomendado ({config.min_trades}).")
        print(f"Duración Promedio de Operación: {avg_duration_days:.2f} días ({avg_duration_months:.2f} meses)")
        print(f"Tasa de Acierto (Prob. de Ganar): {p_win * 100:.2f}%")
        print(f"Profit Factor: {profit_factor:.2f}")
        print(f"Ratio Riesgo/Recompensa (Ganancia/Pérdida): {risk_reward_ratio:.2f} a 1")
        print(f"Expectancy (Ganancia Esperada/Trade): {expectancy * 100:.4f}%") 
        print("------------------------------")
        return self.results

# ==============================================================================
# 5. FUNCIONES DE INTERFAZ Y PLOTEO
# ==============================================================================

def _fetch_data(ticker: str) -> pd.DataFrame:
    """
    Función para obtener datos de acciones usando yfinance, con manejo de errores 
    de descarga y estandarización de columnas.
    """
    print(f"-> Descargando datos históricos para {ticker} (últimos 5 años)...")
    try:
        # Usamos Ticker().history() en lugar de yf.download() para mayor estabilidad
        data = yf.Ticker(ticker).history(period="5y", interval="1d", auto_adjust=False)
        
        if data.empty:
             raise ValueError("Datos vacíos.")

        # Estandarización de nombres de columnas a mayúsculas y simplificación
        data.columns = [col.upper().replace(' ', '_') for col in data.columns]
        
        # Mapeo de columnas: Usamos 'Adj Close' si existe, si no, 'Close'.
        if 'ADJ_CLOSE' in data.columns:
            data['Close'] = data['ADJ_CLOSE']

        required_cols = ['OPEN', 'HIGH', 'LOW', 'CLOSE', 'VOLUME']
        
        # Renombrar a los nombres esperados por pandas_ta y la lógica interna
        col_mapping = {
            'OPEN': 'Open',
            'HIGH': 'High',
            'LOW': 'Low',
            'CLOSE': 'Close',
            'VOLUME': 'Volume'
        }
        
        df_clean = data[[col for col in required_cols if col in data.columns]].rename(columns=col_mapping)
        
        # Verificación final de columnas necesarias
        if not all(col in df_clean.columns for col in ['Open', 'High', 'Low', 'Close', 'Volume']):
            raise ValueError(f"Faltan columnas OHLCV después del mapeo para {ticker}.")

        df_clean = df_clean.dropna()
        df_clean.attrs['ticker'] = ticker
        return df_clean
        
    except Exception as e:
        print(f"Error crítico al intentar descargar datos para {ticker}: {e}")
        # Intento de fallback más simple
        try:
             data = yf.download(ticker, period="5y", interval="1d", progress=False, auto_adjust=True)
             if data.empty or 'Close' not in data.columns:
                  raise ValueError("Fallback fallido.")
             data.columns = [col.upper().replace(' ', '_') for col in data.columns]
             col_mapping = {
                'OPEN': 'Open',
                'HIGH': 'High',
                'LOW': 'Low',
                'CLOSE': 'Close',
                'VOLUME': 'Volume'
             }
             df_clean = data[[col for col in col_mapping.keys() if col in data.columns]].rename(columns=col_mapping)
             df_clean = df_clean.dropna()
             df_clean.attrs['ticker'] = ticker
             return df_clean
        except Exception:
             return pd.DataFrame()


def _plot_results(df: pd.DataFrame, ticker: str, strategy_spec: List[Tuple[str, Tuple[Any, ...]]]):
    """
    Genera gráficos de rendimiento, señales de trading y Drawdown.
    """
    
    if df.empty or 'Cumulative_Strategy_Return' not in df.columns or 'Drawdown' not in df.columns:
        print("No se pueden generar gráficos: el DataFrame de resultados está vacío o incompleto.")
        return

    # Usamos tres subplots principales
    fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(12, 14), sharex=True)
    
    # --- Manejo del Título ---
    spec_names = [f"{spec[0]}{spec[1]}" for spec in strategy_spec]
    title_params = ", ".join(spec_names)
    fig.suptitle(f"Backtest: {ticker} | Estrategia Combinada: {title_params}", fontsize=12)

    # --- Subplot 1: Rendimiento Acumulado (Equity Curve) ---
    df['Cumulative_Strategy_Return'].plot(
        ax=ax1, 
        title='Curva de Equity (Rendimiento Acumulado)', 
        xlabel='', 
        ylabel='Capital Relativo (Base 1.0)', 
        grid=True,
        color='#1f77b4', 
        linewidth=2
    )
    df['Cumulative_Market_Return'].plot(
        ax=ax1, 
        label='Mercado (Benchmark)', 
        color='grey',
        linestyle='--',
        alpha=0.6
    )
    
    # Marcar Drawdowns importantes
    max_drawdown = df['Drawdown'].max()
    max_drawdown_date = df['Drawdown'].idxmax()
    if max_drawdown > 0:
        ax1.axvline(max_drawdown_date, color='red', linestyle=':', alpha=0.6, label=f'MDD: {max_drawdown*100:.1f}%')

    ax1.legend(['Estrategia', 'Mercado (Benchmark)', 'Max Drawdown'])
    
    # --- Subplot 2: Precio y Señales de Trading ---
    ax2_price = ax2
    ax2_price.plot(df.index, df['Close'], label='Precio de Cierre', color='black', alpha=0.7)
    ax2_price.set_ylabel('Precio ($)')
    ax2_price.set_title('Precio de Cierre y Señales de Trading')

    # Ploteo de indicadores (solo los que fueron usados)
    plotted_indicators = []
    for ind_name, ind_params in strategy_spec:
        ind_upper = ind_name.upper()
        # Lógica para plotear los indicadores de cruce más comunes
        if ind_upper == 'SMA':
            col_fast = f'SMA_{ind_params[0]}'
            col_slow = f'SMA_{ind_params[1]}'
            if col_fast in df.columns and col_fast not in plotted_indicators:
                 df[col_fast].plot(ax=ax2_price, label=f'SMA Rápida {ind_params[0]}', color='#2ECC71', linewidth=1.5, alpha=0.8)
                 df[col_slow].plot(ax=ax2_price, label=f'SMA Lenta {ind_params[1]}', color='#E67E22', linewidth=1.5, alpha=0.8)
                 plotted_indicators.append(col_fast)
        elif ind_upper == 'EMA':
            col_fast = f'EMA_{ind_params[0]}'
            col_slow = f'EMA_{ind_params[1]}'
            if col_fast in df.columns and col_fast not in plotted_indicators:
                 df[col_fast].plot(ax=ax2_price, label=f'EMA Rápida {ind_params[0]}', color='#2ECC71', linewidth=1.5, alpha=0.8)
                 df[col_slow].plot(ax=ax2_price, label=f'EMA Lenta {ind_params[1]}', color='#E67E22', linewidth=1.5, alpha=0.8)
                 plotted_indicators.append(col_fast)
        elif ind_upper == 'BBANDS':
             period, dev = ind_params[:2] # Solo se toman los 2 primeros si hay más
             if f'BBM_{period}_{dev}' in df.columns:
                 df[f'BBM_{period}_{dev}'].plot(ax=ax2_price, label='BB Media', color='red', linestyle='-', linewidth=1.5, alpha=0.7)
                 df[f'BBU_{period}_{dev}'].plot(ax=ax2_price, label='BB Superior', color='red', linestyle='--', linewidth=1, alpha=0.5)
                 df[f'BBL_{period}_{dev}'].plot(ax=ax2_price, label='BB Inferior', color='red', linestyle='--', linewidth=1, alpha=0.5)

    # Señales de Entrada/Salida
    entry_points = df[df['Position'].diff() == 1]
    ax2_price.scatter(
        entry_points.index, 
        entry_points['Close'], 
        marker='^', 
        color='green', 
        s=100, 
        label='Compra (Largo)', 
        zorder=5
    )
    exit_points = df[df['Position'].diff() == -1]
    ax2_price.scatter(
        exit_points.index, 
        exit_points['Close'], 
        marker='v', 
        color='red', 
        s=100, 
        label='Venta/Salida', 
        zorder=5
    )

    ax2_price.legend(loc='best')
    ax2_price.grid(True)
    
    # --- Subplot 3: Drawdown (Riesgo) ---
    df['Drawdown'].plot(
        ax=ax3,
        title='Curva de Drawdown Diario (Pérdida Máxima desde el Último Pico)',
        xlabel='Fecha',
        ylabel='Drawdown (%)',
        grid=True,
        color='red',
        linewidth=1.5
    )
    ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: '{:.0%}'.format(y)))
    ax3.fill_between(df.index, df['Drawdown'], 0, color='red', alpha=0.3)
    ax3.axhline(0, color='black', linestyle='--', linewidth=0.5)
    
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


def backtest(ticker: str, *args, config: Optional[StrategyConfig] = None) -> pd.DataFrame:
    """
    Función principal de backtesting con argumentos flexibles.
    """
    if len(args) == 0:
        raise ValueError("Debe proporcionar al menos una estrategia (Nombre, Parámetros).")
    
    # 1. Definir la Configuración de Riesgo (StrategyConfig)
    if config is None:
        config = StrategyConfig() 

    strategy_specs: List[Tuple[str, Tuple[Any, ...]]] = []
    args_strategies = args
    
    # 2. Procesar argumentos de estrategias
    if len(args_strategies) % 2 != 0:
        raise ValueError("Los argumentos de estrategia deben ser pares: (Nombre: str, Parámetros: tuple).")

    for i in range(0, len(args_strategies), 2):
        strategy_name = args_strategies[i]
        params = args_strategies[i+1]
        
        if not isinstance(strategy_name, str) or not isinstance(params, tuple):
             raise TypeError("Los argumentos deben ser pares de (Nombre de Estrategia: str, Parámetros: tuple).")
        
        strategy_name_upper = strategy_name.upper()
        if strategy_name_upper not in INDICATORS:
             # Generar una lista de los primeros 10 indicadores disponibles para la advertencia
             available_indicators = list(INDICATORS.keys())
             raise ValueError(f"Indicador '{strategy_name}' no soportado. Indicadores disponibles: {available_indicators[:10]}... ({len(INDICATORS)} en total)")

        strategy_specs.append((strategy_name, params))
    
    # 3. Determinar la función de ejecución (Simple vs. Meta)
    # Si hay 1 estrategia Y NO hay configuración de riesgo avanzada, se usa la función simple.
    if len(strategy_specs) == 1 and config.take_profit is None and config.stop_loss is None and config.min_votes_required is None:
        # Caso de Estrategia Simple
        strategy_name_for_run = strategy_specs[0][0].upper()
        strategy_func = INDICATORS[strategy_name_for_run]
        params_for_run = strategy_specs[0][1]
        
    else:
        # Caso de Meta-Estrategia (1 o más indicadores CON o SIN gestión de riesgo/votos)
        strategy_name_for_run = "META_ESTRATEGIA"
        strategy_func = _meta_strategy_executor
        params_for_run = (strategy_specs, config) # Se pasa la lista de specs y la config
        
    # 4. Obtener los datos
    data = _fetch_data(ticker)
    if data.empty:
        print("El backtest no se pudo ejecutar debido a que no se obtuvieron datos válidos.")
        return pd.DataFrame()

    # 5. Inicializar y Ejecutar el backtest
    backtester = Backtester(data)
    results_df = backtester.run(strategy_name_for_run, strategy_func, params_for_run, config)
    
    if results_df.empty:
        print("No hay suficientes datos para ejecutar la estrategia y generar resultados.")
        return pd.DataFrame()

    # 6. Generar el gráfico de resultados
    print("\n-> Generando gráfico de rendimiento, señales y drawdown...")
    _plot_results(results_df, ticker, strategy_specs)

    return results_df