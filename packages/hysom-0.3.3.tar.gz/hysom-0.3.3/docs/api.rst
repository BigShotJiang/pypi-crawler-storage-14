API Documentation
=================

.. automodule:: hysom.hysom
   :members: 
   :undoc-members: