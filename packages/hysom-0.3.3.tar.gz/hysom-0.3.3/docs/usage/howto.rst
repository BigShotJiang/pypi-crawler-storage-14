How-To Guides
==============

This section provides How-To guides for using HySOM

.. toctree::
   :maxdepth: 1

   How to prepare your input data for HySOM <../tutorials/preparingInputData>