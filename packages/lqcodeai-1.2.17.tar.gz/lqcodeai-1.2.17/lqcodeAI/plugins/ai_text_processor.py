"""
本地文本处理AI插件 - 演示LocalAI的文本处理能力
"""
from typing import Any, Dict, TypedDict
import re
from collections import Counter
from ..core.local_ai import LocalAI
from ..core.plugin_registry import ai_plugin

class TextProcessResult(TypedDict):
    """文本处理结果类型"""
    original_text: str
    processed_text: str
    statistics: Dict[str, Any]
    operation: str

@ai_plugin(
    name="textprocess",
    description="本地文本处理器 - 支持文本统计、格式化和清理",
    cli_args=[
        {"name": "text", "help": "要处理的文本", "default": "Hello World! 这是一个测试文本。"},
        {"name": "operation", "help": "处理操作", "default": "analyze"}
    ],
    result_type=TextProcessResult,
    plugin_type="local"
)
class TextProcessorAI(LocalAI):
    """本地文本处理器AI功能"""
    
    def ai_textprocess(self, password: str, text: str = "Hello World! 这是一个测试文本。", 
                      operation: str = "analyze") -> TextProcessResult:
        """处理文本
        
        Args:
            password: 访问密码
            text: 要处理的文本
            operation: 处理操作 (analyze, clean, format, count)
            
        Returns:
            TextProcessResult: 包含原文本、处理后文本、统计信息和操作类型的字典
        """
        return self._execute_local(password, text, operation)
    
    def _execute_local(self, password: str, text: str = "Hello World! 这是一个测试文本。", 
                      operation: str = "analyze") -> TextProcessResult:
        """执行本地文本处理"""
        try:
            if operation == "analyze":
                return self._analyze_text(text)
            elif operation == "clean":
                return self._clean_text(text)
            elif operation == "format":
                return self._format_text(text)
            elif operation == "count":
                return self._count_words(text)
            else:
                return {
                    "original_text": text,
                    "processed_text": text,
                    "statistics": {"error": "不支持的操作"},
                    "operation": operation
                }
        except Exception as e:
            return {
                "original_text": text,
                "processed_text": text,
                "statistics": {"error": f"处理错误: {str(e)}"},
                "operation": operation
            }
    
    def _analyze_text(self, text: str) -> TextProcessResult:
        """分析文本统计信息"""
        # 基本统计
        char_count = len(text)
        word_count = len(text.split())
        sentence_count = len(re.findall(r'[.!?]+', text))
        
        # 字符类型统计
        letters = sum(1 for c in text if c.isalpha())
        digits = sum(1 for c in text if c.isdigit())
        spaces = sum(1 for c in text if c.isspace())
        
        # 中英文字符统计
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_chars = sum(1 for c in text if c.isalpha() and ord(c) < 128)
        
        statistics = {
            "字符总数": char_count,
            "单词数": word_count,
            "句子数": sentence_count,
            "字母数": letters,
            "数字数": digits,
            "空格数": spaces,
            "中文字符": chinese_chars,
            "英文字符": english_chars
        }
        
        return {
            "original_text": text,
            "processed_text": text,
            "statistics": statistics,
            "operation": "analyze"
        }
    
    def _clean_text(self, text: str) -> TextProcessResult:
        """清理文本"""
        # 移除多余空格
        cleaned = re.sub(r'\s+', ' ', text)
        # 移除首尾空格
        cleaned = cleaned.strip()
        # 移除特殊字符（保留基本标点）
        cleaned = re.sub(r'[^\w\s.!?，。！？]', '', cleaned)
        
        statistics = {
            "原长度": len(text),
            "清理后长度": len(cleaned),
            "移除字符数": len(text) - len(cleaned)
        }
        
        return {
            "original_text": text,
            "processed_text": cleaned,
            "statistics": statistics,
            "operation": "clean"
        }
    
    def _format_text(self, text: str) -> TextProcessResult:
        """格式化文本"""
        # 首字母大写
        formatted = text.capitalize()
        # 句子首字母大写
        formatted = re.sub(r'([.!?]\s*)([a-z])', 
                          lambda m: m.group(1) + m.group(2).upper(), formatted)
        
        statistics = {
            "原长度": len(text),
            "格式化后长度": len(formatted),
            "修改位置": self._find_changes(text, formatted)
        }
        
        return {
            "original_text": text,
            "processed_text": formatted,
            "statistics": statistics,
            "operation": "format"
        }
    
    def _count_words(self, text: str) -> TextProcessResult:
        """统计词频"""
        # 分词
        words = re.findall(r'\b\w+\b', text.lower())
        # 词频统计
        word_freq = Counter(words)
        # 取前10个高频词
        top_words = dict(word_freq.most_common(10))
        
        statistics = {
            "总词数": len(words),
            "不重复词数": len(word_freq),
            "高频词": top_words
        }
        
        return {
            "original_text": text,
            "processed_text": text,
            "statistics": statistics,
            "operation": "count"
        }
    
    def _find_changes(self, original: str, formatted: str) -> list:
        """找出文本变化的位置"""
        changes = []
        for i, (o, f) in enumerate(zip(original, formatted)):
            if o != f:
                changes.append({"位置": i, "原字符": o, "新字符": f})
        return changes[:5]  # 只返回前5个变化 