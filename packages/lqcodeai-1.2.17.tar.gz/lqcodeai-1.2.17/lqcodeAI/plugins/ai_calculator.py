"""
本地计算器AI插件 - 演示LocalAI插件的使用
"""
from typing import Any, Dict, TypedDict
import math
import re
from ..core.local_ai import LocalAI
from ..core.plugin_registry import ai_plugin

class CalculatorResult(TypedDict):
    """计算器结果类型"""
    expression: str
    result: str
    explanation: str

@ai_plugin(
    name="calculator",
    description="本地计算器 - 支持基本数学运算和函数",
    cli_args=[
        {"name": "expression", "help": "数学表达式", "default": "2+3*4"}
    ],
    result_type=CalculatorResult,
    plugin_type="local"
)
class CalculatorAI(LocalAI):
    """本地计算器AI功能"""
    
    def ai_calculator(self, password: str, expression: str = "2+3*4") -> CalculatorResult:
        """计算数学表达式
        
        Args:
            password: 访问密码
            expression: 数学表达式
            
        Returns:
            CalculatorResult: 包含表达式、结果和解释的字典
        """
        return self._execute_local(password, expression)
    
    def _execute_local(self, password: str, expression: str = "2+3*4") -> CalculatorResult:
        """执行本地计算"""
        try:
            # 清理和验证表达式
            clean_expr = self._clean_expression(expression)
            if not clean_expr:
                return {
                    "expression": expression,
                    "result": "错误",
                    "explanation": "无效的数学表达式"
                }
            
            # 安全计算
            result = self._safe_eval(clean_expr)
            
            return {
                "expression": expression,
                "result": str(result),
                "explanation": f"计算 {expression} = {result}"
            }
            
        except Exception as e:
            return {
                "expression": expression,
                "result": "错误",
                "explanation": f"计算错误: {str(e)}"
            }
    
    def _clean_expression(self, expression: str) -> str:
        """清理数学表达式"""
        # 移除空格
        clean = expression.replace(" ", "")
        
        # 只允许数字、基本运算符和括号
        if not re.match(r'^[0-9+\-*/().\s]+$', clean):
            return ""
        
        # 替换一些常见的数学函数
        clean = clean.replace("sqrt", "math.sqrt")
        clean = clean.replace("sin", "math.sin")
        clean = clean.replace("cos", "math.cos")
        clean = clean.replace("tan", "math.tan")
        clean = clean.replace("log", "math.log")
        clean = clean.replace("pi", "math.pi")
        clean = clean.replace("e", "math.e")
        
        return clean
    
    def _safe_eval(self, expression: str) -> float:
        """安全地计算表达式"""
        # 定义允许的名称
        allowed_names = {
            "math": math,
            "__builtins__": {},
        }
        
        # 安全计算
        result = eval(expression, allowed_names, {})
        
        # 格式化结果
        if isinstance(result, float):
            # 如果是整数，显示为整数
            if result.is_integer():
                return int(result)
            # 否则保留6位小数
            return round(result, 6)
        
        return result 