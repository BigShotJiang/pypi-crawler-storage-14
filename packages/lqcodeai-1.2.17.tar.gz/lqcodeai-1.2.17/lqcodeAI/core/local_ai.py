"""
本地AI插件基类 - 用于不需要与Coze交互的AI功能
"""
from typing import Dict, Any, Optional
from .abstract_ai import AIPlugin

class LocalAI(AIPlugin):
    """本地AI插件基类，用于不需要与Coze交互的AI功能"""
    
    def execute(self, password: str, *args, **kwargs) -> Dict[str, Any]:
        """
        执行本地AI功能
        
        Args:
            password: 访问密码
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        # 基础密码验证
        if not self.validate_password(password):
            return self.format_error("password必须是有效的字符串")
        
        # 调用子类实现的具体方法
        return self._execute_local(password, *args, **kwargs)
    
    def _execute_local(self, password: str, *args, **kwargs) -> Dict[str, Any]:
        """
        执行本地AI功能的具体实现，由子类重写
        
        Args:
            password: 访问密码
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        raise NotImplementedError("子类必须实现_execute_local方法")
    
    def get_plugin_type(self) -> str:
        """获取插件类型"""
        return "LocalAI" 