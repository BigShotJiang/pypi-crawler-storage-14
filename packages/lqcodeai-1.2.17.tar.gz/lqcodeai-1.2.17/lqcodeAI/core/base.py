from typing import Dict, Any, Optional
import requests
import time
import functools
from datetime import datetime, timedelta
import json

from .config import Config
from .abstract_ai import AIPlugin
from cozepy import Coze, COZE_CN_BASE_URL, TokenAuth, Stream, WorkflowEvent, WorkflowEventType

class BaseAI(AIPlugin):
    """AI功能的基础类，提供与Coze交互的功能"""
    
    def __init__(self, config: Optional[Config] = None):
        super().__init__(config)
        self._token_cache = {}
        self._token_expiry = {}
    
    def execute(self, password: str, *args, **kwargs) -> Dict[str, Any]:
        """
        执行Coze AI功能
        
        Args:
            password: 访问密码
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        # 基础密码验证
        if not self.validate_password(password):
            return self.format_error("password必须是有效的字符串")
        
        # 调用子类实现的具体方法
        return self._execute_coze(password, *args, **kwargs)
    
    def _execute_coze(self, password: str, *args, **kwargs) -> Dict[str, Any]:
        """
        执行Coze AI功能的具体实现，由子类重写
        
        Args:
            password: 访问密码
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        raise NotImplementedError("子类必须实现_execute_coze方法")
    
    @functools.lru_cache(maxsize=100)  # 使用默认值100，实际值会在运行时通过self.config.cache_size获取
    def _get_ai_token(self, password: str) -> TokenAuth:
        """获取AI访问令牌（带缓存）"""
        cache_key = f"{password}"
        if cache_key in self._token_cache:
            if datetime.now() < self._token_expiry.get(cache_key, datetime.now()):
                return self._token_cache[cache_key]
        
        res = requests.get(self.config.base_url, params={'password': password}, timeout=10)
        res.raise_for_status()
        data = res.json()
        token = TokenAuth(data['data'])
        self._token_cache[cache_key] = token
        self._token_expiry[cache_key] = datetime.now() + timedelta(hours=self.config.token_expiry_hours)
        return token

    def _execute_workflow(self, password: str, parameters: Dict[str, Any], 
                         max_retries: Optional[int] = None, base_delay: Optional[int] = None) -> Dict[str, Any]:
        """执行工作流的通用方法"""
        max_retries = max_retries or self.config.max_retries
        base_delay = base_delay or self.config.base_delay
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                token_auth = self._get_ai_token(password)
                coze = Coze(auth=token_auth, base_url=COZE_CN_BASE_URL)
                
                workflow_stream = coze.workflows.runs.stream(
                    workflow_id=self.config.workflow_id,
                    parameters=parameters
                )
                
                return self._process_workflow_stream(workflow_stream, coze)
                
            except Exception:
                retry_count += 1
                if retry_count == max_retries:
                    return {"error": "执行失败，请稍后再试"}
                delay = min(base_delay * (2 ** (retry_count - 1)), 30)
                time.sleep(delay)
        
        return {"error": "执行失败，请稍后再试"}

    def _process_workflow_stream(self, workflow_stream: Stream, coze: Coze) -> Dict[str, Any]:
        """处理工作流事件的通用方法"""
        for event in workflow_stream:
            if event.event == WorkflowEventType.MESSAGE:
                if hasattr(event.message, 'content'):
                    return self._parse_content(event.message.content)
            elif event.event == WorkflowEventType.ERROR:
                return {"error": f"工作流错误: {str(event.error)}"}
            elif event.event == WorkflowEventType.INTERRUPT:
                interrupt_result = self._handle_workflow_interrupt(coze, event)
                if interrupt_result:
                    return interrupt_result
        
        return {"error": "未能获取结果，请稍后再试"}

    def _handle_workflow_interrupt(self, coze: Coze, event: WorkflowEvent) -> Optional[Dict[str, Any]]:
        """处理工作流中断事件"""
        try:
            resume_stream = coze.workflows.runs.resume(
                workflow_id=self.config.workflow_id,
                event_id=event.interrupt.interrupt_data.event_id,
                resume_data="继续",
                interrupt_type=event.interrupt.interrupt_data.type,
            )
            
            for resume_event in resume_stream:
                if resume_event.event == WorkflowEventType.MESSAGE:
                    if hasattr(resume_event.message, 'content'):
                        return self._parse_content(resume_event.message.content)
                elif resume_event.event == WorkflowEventType.INTERRUPT:
                    nested_result = self._handle_workflow_interrupt(coze, resume_event)
                    if nested_result:
                        return nested_result
            
            return None
        except Exception:
            return None

    def _parse_content(self, content: Any) -> Dict[str, Any]:
        """解析工作流返回的内容"""
        if isinstance(content, str):
            try:
                content_json = json.loads(content)
                if 'output' in content_json:
                    return self._parse_output(content_json['output'])
                return {"result": str(content_json)}
            except json.JSONDecodeError:
                return {"result": content}
        elif hasattr(content, 'text'):
            return {"result": content.text}
        return {"result": str(content)}

    def _parse_output(self, output: Any) -> Dict[str, Any]:
        """解析output1字段的内容，由子类实现"""
        raise NotImplementedError
    
    def get_plugin_type(self) -> str:
        """获取插件类型"""
        return "CozeAI" 