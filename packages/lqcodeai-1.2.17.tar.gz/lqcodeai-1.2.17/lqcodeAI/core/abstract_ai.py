"""
抽象AI插件基类 - 定义所有AI插件的通用接口
"""
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from .config import Config

class AIPlugin(ABC):
    """AI插件的抽象基类，定义所有AI插件的通用接口"""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = self._validate_config(config)
    
    def _validate_config(self, config: Optional[Config]) -> Config:
        """验证配置的有效性"""
        if config is None:
            return Config()
        if not isinstance(config, Config):
            raise TypeError("config必须是Config类型")
        return config
    
    @abstractmethod
    def execute(self, password: str, *args, **kwargs) -> Dict[str, Any]:
        """
        执行AI功能的抽象方法
        
        Args:
            password: 访问密码
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        pass
    
    def validate_password(self, password: str) -> bool:
        """验证密码的有效性"""
        return password and isinstance(password, str)
    
    def format_error(self, error_msg: str) -> Dict[str, Any]:
        """格式化错误消息"""
        return {"error": error_msg}
    
    def get_plugin_type(self) -> str:
        """获取插件类型"""
        return self.__class__.__name__ 