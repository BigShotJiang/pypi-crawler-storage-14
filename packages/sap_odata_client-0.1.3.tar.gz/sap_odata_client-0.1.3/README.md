# SAP Client (Python)

A lightweight async SAP S/4HANA OData Sales Order client.

Features:

- OAuth2 client credentials
- CSRF token handling
- Async via httpx
- Clean Python module, reusable anywhere

## Install

```bash
pip install sap-odata-client
```
