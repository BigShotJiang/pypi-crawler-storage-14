"""
Helpers
-------
This internal module contains general functions. No direct visibility to the
public API should be done through this module.

"""
