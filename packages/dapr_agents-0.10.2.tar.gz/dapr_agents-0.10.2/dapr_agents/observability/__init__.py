from .instrumentor import DaprAgentsInstrumentor


__all__ = [
    "DaprAgentsInstrumentor",
]
