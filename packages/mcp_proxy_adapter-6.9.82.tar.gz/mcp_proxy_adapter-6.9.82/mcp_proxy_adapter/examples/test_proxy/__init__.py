"""
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com

Test proxy server for MCP Proxy Adapter framework.
This proxy server provides proxy registration endpoints via JSON-RPC commands.
"""

