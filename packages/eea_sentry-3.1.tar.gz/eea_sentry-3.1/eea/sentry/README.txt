Overview
========
eea.sentry is a revolutionary plone package that redefines Plone Add-ons.

  * See more: http://github.com/eea/eea.sentry


Installation
============
  * Go to admin > Site Setup > Add-ons
  * Activate eea.sentry


Authors
=======
  "European Environment Agency", mailto:eea-edw-a-team-alerts@googlegroups.com
