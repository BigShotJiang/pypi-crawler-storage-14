#!/bin/bash
python report_grammar.py
python test_cpu.py
python test_mem.py
