See [docs/about/CONTRIBUTING.md](docs/about/CONTRIBUTING.md)
