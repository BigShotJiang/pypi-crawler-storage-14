This is an example of C parsing. Still WIP.
