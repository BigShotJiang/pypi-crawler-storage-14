This is an implementation of Java SE 16 Edition based on the spec defined in
https://docs.oracle.com/javase/specs/jls/se16/html/jls-19.html

Since the grammar is derived from the official specification, please see the
legal terms from the specification if you plan to use it in your project.
https://docs.oracle.com/javase/specs/jls/se16/html/index.html

The test input file is from the [Spring Boot
project](https://github.com/spring-projects/spring-boot).
