Custom parse table caching example
==================================

Parse table is stored as a python module (`_table.py`). To generate it, in this directory run:

    python compile.py

Then precomputed parse table is used in parser script

    python parser.py
