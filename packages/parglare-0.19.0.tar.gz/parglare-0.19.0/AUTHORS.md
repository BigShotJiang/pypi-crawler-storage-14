##Development Lead

- Igor R. Dejanovic <igor DOT dejanovic AT gmail DOT com>

##Contributors

For a full list of contributors and their activity
see [here](https://github.com/igordejanovic/parglare/graphs/contributors).
