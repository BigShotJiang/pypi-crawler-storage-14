# Third party
from setuptools import setup


setup()
