def get_inline_instances(self, request, obj=None):
    from django.conf import settings
    from djangocms_stories.admin import PostAdmin
    from djangocms_stories.models import Post

    from .admin import PostExtensionInline

    inline_instances = super(PostAdmin, self).get_inline_instances(request, obj)

    if request.resolver_match.url_name == "djangocms_stories_post_change":
        # fetch post from request
        post = Post.objects.get(pk=request.resolver_match.kwargs["object_id"])
        # get template_prefix from config
        template_prefix = post.app_config.template_prefix
        if template_prefix == "djangocms_stories_agenda" or (
            getattr(settings, "DJANGOCMS_STORIES_AGENDA_TEMPLATE_PREFIXES", False)
            and template_prefix in settings.DJANGOCMS_STORIES_AGENDA_TEMPLATE_PREFIXES
        ):
            return inline_instances

    return list(
        filter(
            lambda instance: not isinstance(instance, PostExtensionInline),
            inline_instances,
        )
    )
