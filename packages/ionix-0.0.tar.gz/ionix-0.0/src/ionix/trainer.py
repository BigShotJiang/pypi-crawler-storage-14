import jax
import jax.numpy as jnp
from tqdm.auto import tqdm
from typing import Any, List, Optional, Tuple, Union, Iterable

from .module import IonModule
from .logger import IonLogger
from .callback import IonCallback
from .profiler import IonProfiler
from .types import STAGE


class IonTrainer:
    callbacks: List[IonCallback]
    loggers: List[IonLogger]
    profiler: Optional[IonProfiler]
    val_check_interval: Optional[Union[int, float]]
    check_val_every_n_epoch: int
    log_every_n_steps: int
    enable_progress_bar: bool

    def __init__(
        self,
        max_epochs: int = 1,
        seed: int = 42,
    ):
        self.max_epochs = max_epochs
        self.seed = seed

    def _call_callbacks(self, method_name: str, stage: STAGE, *args, **kwargs):
        if self.callbacks:
            for callback in self.callbacks:
                method = getattr(callback, method_name, None)
                if method:
                    method(self, *args, **kwargs)

    def log(self, key: str, value: Any, *args, **kwargs):
        if self.loggers:
            for logger in self.loggers:
                logger.log(key, value, *args, **kwargs)

    def _flush_loggers(self):
        if self.loggers:
            for logger in self.loggers:
                logger.flush()

    def fit(
        self,
        *,
        model: IonModule,
        train_dataloader: Iterable,
        val_dataloader: Optional[Iterable] = None,
        logger: Optional[Union[IonLogger, Iterable[IonLogger], bool]] = None,
        callbacks: Optional[Union[Iterable[IonCallback], IonCallback]] = None,
        max_epochs: Optional[int] = None,
        min_epochs: Optional[int] = None,
        max_steps: int = -1,
        min_steps: Optional[int] = None,
        val_check_interval: Optional[Union[int, float]] = None,
        check_val_every_n_epoch: Optional[int] = 1,
        log_every_n_steps: Optional[int] = None,
        enable_progress_bar: Optional[bool] = None,
        profiler: Optional[Union[IonProfiler, str]] = None,
    ):
        """
        Fit the model using the provided dataloaders.

        Args:
            model: The IonModule to train.
            train_dataloader: The iterable yielding the training data.
            val_dataloader: The iterable yielding the validation data.
            logger: The IonLogger to use.
            callbacks: The IonCallbacks to use.
            max_epochs: The maximum number of epochs to train for.
            min_epochs: The minimum number of epochs to train for.
            max_steps: The maximum number of steps to train for.
            min_steps: The minimum number of steps to train for.
            val_check_interval: The interval at which to check the validation set.
            check_val_every_n_epoch: The number of epochs between validation checks.
            log_every_n_steps: The number of steps between logging.
            enable_progress_bar: Whether to enable the progress bar.
            profiler: The IonProfiler to use.
        """
        # Handle callbacks normalization
        if callbacks is None:
            self.callbacks = []
        elif isinstance(callbacks, list):
            self.callbacks = callbacks
        else:
            self.callbacks = [callbacks]

        # Handle loggers normalization
        if logger is None or logger is False:
            self.loggers = []
        elif isinstance(logger, list):
            self.loggers = logger
        elif logger is True:
            self.loggers = []
        else:
            self.loggers = [logger]

        # Link trainer to model
        model.trainer = self

        # Handle max_epochs
        max_epochs = max_epochs if max_epochs is not None else self.max_epochs

        # Initialize RNG
        key = jax.random.PRNGKey(self.seed)
        key, init_key = jax.random.split(key)

        # Setup
        self._call_callbacks("setup", model, stage="fit")
        self._call_callbacks("on_fit_start", model)
        self._call_callbacks("on_train_start", model)

        # Training Loop
        self.global_step = 0
        for epoch in range(max_epochs):
            self._call_callbacks("on_train_epoch_start", model)

            train_iterator = iter(train_dataloader)
            if enable_progress_bar:
                pbar = tqdm(train_iterator, desc=f"Epoch {epoch + 1}/{max_epochs}")
            else:
                pbar = train_iterator

            for batch_idx, batch in enumerate(pbar):
                self._call_callbacks("on_train_batch_start", model, batch, batch_idx)

                output = model.training_step(batch, batch_idx)

                self._call_callbacks(
                    "on_train_batch_end", model, output, batch, batch_idx
                )

                self.global_step += 1
                if log_every_n_steps and self.global_step % log_every_n_steps == 0:
                    self._flush_loggers()

            self._call_callbacks("on_train_epoch_end", model)

            # Validation Loop
            should_validate = (
                val_dataloader is not None
                and check_val_every_n_epoch is not None
                and (epoch + 1) % check_val_every_n_epoch == 0
            )

            if should_validate:
                self._call_callbacks("on_validation_start", model)
                self._call_callbacks("on_validation_epoch_start", model)

                val_iterator = iter(val_dataloader)
                for val_batch_idx, val_batch in enumerate(val_iterator):
                    self._call_callbacks(
                        "on_validation_batch_start", model, val_batch, val_batch_idx
                    )

                    val_output = model.validation_step(val_batch, val_batch_idx)

                    self._call_callbacks(
                        "on_validation_batch_end",
                        model,
                        val_output,
                        val_batch,
                        val_batch_idx,
                    )

                self._call_callbacks("on_validation_epoch_end", model)
                self._call_callbacks("on_validation_end", model)

        self._call_callbacks("on_train_end", model)
        self._flush_loggers()  # Flush any remaining metrics
        self._call_callbacks("on_fit_end", model)
        self._call_callbacks("teardown", model, stage="fit")

    def test(
        self,
        model: IonModule,
        test_dataloader: Iterable,
    ):
        raise NotImplementedError
