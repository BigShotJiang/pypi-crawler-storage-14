from typing import Any, Callable, Dict, Tuple, Optional
import jax


class IonModule:
    """
    Base class for models.
    """

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        self.trainer: Optional[Any] = None

    def training_step(self, batch: Any, batch_idx: int) -> Any:
        raise NotImplementedError

    def validation_step(self, batch: Any, batch_idx: int) -> Any:
        raise NotImplementedError

    def test_step(self, batch: Any, batch_idx: int) -> Any:
        raise NotImplementedError

    def log(
        self,
        key: str,
        value: Any,
        *args,
        **kwargs,
    ):
        if self.trainer:
            self.trainer.log(key, value, *args, **kwargs)
