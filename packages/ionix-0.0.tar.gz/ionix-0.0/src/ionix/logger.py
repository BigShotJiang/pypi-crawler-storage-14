from typing import Any, Dict, List, Tuple


class Loggable[T]:
    buffer: List[Tuple[int | None, T]]
    flushable: bool
    show_in_progress: bool

    def __init__(
        self,
        show_in_progress: bool = False,
        flushable: bool = True,
    ):
        self.buffer = []
        self.show_in_progress = show_in_progress
        self.flushable = flushable

    def __call__(self, value: T, step: int | None = None):
        self.buffer.append((step, value))

    def flush(self):
        self.buffer.clear()


class IonLogger:
    loggables: Dict[str, Loggable[Any]] = {}

    def __init__(self, *args, **kwargs):
        pass

    def log[T](self, key: str, value: T, *args, **kwargs):
        if key not in self.loggables:
            self.loggables[key] = Loggable[T](
                *args,
                **kwargs,
            )
        self.loggables[key](value, *args, **kwargs)

    def flush(self):
        """Called by the trainer to flush accumulated metrics."""
        for key, loggable in self.loggables.items():
            if not loggable.flushable:
                continue
            loggable.flush()
