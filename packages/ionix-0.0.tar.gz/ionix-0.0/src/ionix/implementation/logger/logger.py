from pathlib import Path
from typing import Callable, Optional
import matplotlib.pyplot as plt

from ionix.logger import IonLogger


def _mean(values: list[float]) -> float:
    return sum(values) / len(values)


class LocalLogger(IonLogger):
    def __init__(
        self,
        output_dir: Optional[Path | str] = None,
        accumulate_fn: Callable[[list[float]], float] = _mean,
    ):
        super().__init__()
        self.metrics: dict[str, list[float]] = {}
        self.output_dir = Path(output_dir) if output_dir else None
        self.accumulate_fn = accumulate_fn
        if self.output_dir:
            self.output_dir.mkdir(exist_ok=True, parents=True)

    def flush(self, step: int | None = None):
        """Flush accumulated metrics: print, store, plot, and reset buffer."""
        print("=" * 10 + " Step " + str(step) + " " + "=" * 10)
        for key, loggable in self.loggables.items():
            if not loggable.flushable or not loggable.buffer:
                continue
            values = [float(v) for _, v in loggable.buffer]
            accumulated = self.accumulate_fn(values)
            # Store in history
            if key not in self.metrics:
                self.metrics[key] = []
            self.metrics[key].append(accumulated)
            # Print to console
            print(f"{key}: {accumulated}")
            # Plot metric
            if self.output_dir:
                try:
                    filename = self.output_dir / f"{key.replace('/', '_')}.png"
                    plt.figure()
                    plt.plot(self.metrics[key], marker="o")
                    plt.title(key)
                    plt.xlabel("step")
                    plt.ylabel(key)
                    plt.savefig(filename)
                    plt.close()
                except Exception:
                    pass
        print("=" * 30)
        super().flush()

    def plot_metrics(self):
        """Save metric plots to output_dir."""
        if not self.output_dir:
            return

        for key, values in self.metrics.items():
            filename = self.output_dir / f"{key.replace('/', '_')}.png"
            plt.figure()
            plt.plot(values, marker="o")
            plt.title(key)
            plt.xlabel("step")
            plt.ylabel(key)
            plt.savefig(filename)
            plt.close()
