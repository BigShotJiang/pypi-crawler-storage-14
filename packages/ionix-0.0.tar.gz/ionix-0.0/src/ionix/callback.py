from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .trainer import IonTrainer
    from .module import IonModule
    from .types import STAGE


class IonCallback:
    def __init__(self):
        pass

    @property
    def state_key(self) -> str:
        return self.__class__.__qualname__

    def setup(
        self, trainer: "IonTrainer", pl_module: "IonModule", stage: STAGE
    ) -> None:
        pass

    def teardown(
        self, trainer: "IonTrainer", pl_module: "IonModule", stage: STAGE
    ) -> None:
        pass

    def on_fit_start(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_fit_end(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_train_batch_start(
        self, trainer: "IonTrainer", pl_module: "IonModule", batch: Any, batch_idx: int
    ) -> None:
        pass

    def on_train_batch_end(
        self,
        trainer: "IonTrainer",
        pl_module: "IonModule",
        outputs: Any,
        batch: Any,
        batch_idx: int,
    ) -> None:
        pass

    def on_train_epoch_start(
        self, trainer: "IonTrainer", pl_module: "IonModule"
    ) -> None:
        pass

    def on_train_epoch_end(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_validation_epoch_start(
        self, trainer: "IonTrainer", pl_module: "IonModule"
    ) -> None:
        pass

    def on_validation_epoch_end(
        self, trainer: "IonTrainer", pl_module: "IonModule"
    ) -> None:
        pass

    def on_test_epoch_start(
        self, trainer: "IonTrainer", pl_module: "IonModule"
    ) -> None:
        pass

    def on_test_epoch_end(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_validation_batch_start(
        self,
        trainer: "IonTrainer",
        pl_module: "IonModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        pass

    def on_validation_batch_end(
        self,
        trainer: "IonTrainer",
        pl_module: "IonModule",
        outputs: Any,
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        pass

    def on_test_batch_start(
        self,
        trainer: "IonTrainer",
        pl_module: "IonModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        pass

    def on_test_batch_end(
        self,
        trainer: "IonTrainer",
        pl_module: "IonModule",
        outputs: Any,
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        pass

    def on_train_start(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_train_end(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_validation_start(
        self, trainer: "IonTrainer", pl_module: "IonModule"
    ) -> None:
        pass

    def on_validation_end(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_test_start(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass

    def on_test_end(self, trainer: "IonTrainer", pl_module: "IonModule") -> None:
        pass
