from typing import Callable


class IonProfiler:
    def __init__(self):
        pass

    def profile(self, func: Callable):
        pass
