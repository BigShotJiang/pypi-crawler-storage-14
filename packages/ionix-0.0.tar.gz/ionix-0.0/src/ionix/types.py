from typing import Literal

STAGE = Literal["fit", "validate", "test"]
