# Ionix

Ionix is a library for training JAX models. It should be familiar anyone who has used Pytorch Lightning.

Ionix defines a set of interfaces for training and provides some reference implementations for common tasks while remaining as minimal and expandable as possible

## Installation

```bash
uv add ionix
```

or using pip:

```bash
pip install ionix
```
