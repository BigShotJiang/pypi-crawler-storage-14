"""uQCme - Microbial Quality Control Dashboard"""

__version__ = "0.1.0"
