import os
from dataclasses import dataclass
from typing import List, Tuple

import torch
import torch.distributed as dist
import torch.nn as nn

# -----------------------------------------------------------------------------
# Muon optimizer


def zeropower_via_svd(G, steps=None):
    U, S, V = G.svd()
    return U @ V.T


@torch.compile
def zeropower_via_newtonschulz5(G, steps=10, eps=1e-7):
    """
    Newton-Schulz iteration to compute the zeroth power / orthogonalization of G. We opt to use a
    quintic iteration whose coefficients are selected to maximize the slope at zero. For the purpose
    of minimizing steps, it turns out to be empirically effective to keep increasing the slope at
    zero even beyond the point where the iteration no longer converges all the way to one everywhere
    on the interval. This iteration therefore does not produce UV^T but rather something like US'V^T
    where S' is diagonal with S_{ii}' \\sim Uniform(0.5, 1.5), which turns out not to hurt model
    performance at all relative to UV^T, where USV^T = G is the SVD.
    """
    assert len(G.shape) == 2
    a, b, c = (3.4445, -4.7750, 2.0315)
    X = G.bfloat16()
    X /= X.norm() + eps  # ensure top singular value <= 1
    if G.size(0) > G.size(1):
        X = X.T
    for _ in range(steps):
        A = X @ X.T
        B = A @ X
        X = a * X + b * B + c * A @ B
    if G.size(0) > G.size(1):
        X = X.T
    return X


zeropower_backends = dict(
    svd=zeropower_via_svd, newtonschulz5=zeropower_via_newtonschulz5
)


class Muon(torch.optim.Optimizer):
    """
    Muon - MomentUm Orthogonalized by Newton-schulz

    Muon internally runs standard SGD-momentum, and then performs an orthogonalization post-
    processing step, in which each 2D parameter's update is replaced with the nearest orthogonal
    matrix. To efficiently orthogonalize each update, we use a Newton-Schulz iteration, which has
    the advantage that it can be stably run in bfloat16 on the GPU.

    Some warnings:
    - This optimizer assumes that all parameters passed in are 2D.
    - It should not be used for the embedding layer, the final fully connected layer, or any {0,1}-D
    parameters; those should all be optimized by a standard method (e.g., AdamW).
    - To use it with 4D convolutional filters, it works well to just flatten their last 3 dimensions.
    - We believe it is unlikely to work well for training with small batch size.
    - We believe it may not work well for finetuning pretrained models, but we haven't tested this.
    - We have not yet tried this optimizer for training scenarios larger than NanoGPT (124M).

    Arguments:
        lr: The learning rate used by the internal SGD.
        momentum: The momentum used by the internal SGD.
        nesterov: Whether to use Nesterov-style momentum in the internal SGD. (recommended)
        backend: The chosen backend for the orthogonalization step. (recommended: 'newtonschulz5')
        backend_steps: The number of iteration steps to use in the backend, if it is iterative.
    """

    def __init__(
        self,
        params,
        lr=0.02,
        momentum=0.95,
        nesterov=True,
        backend="newtonschulz5",
        backend_steps=5,
    ):
        defaults = dict(
            lr=lr,
            momentum=momentum,
            nesterov=nesterov,
            backend=backend,
            backend_steps=backend_steps,
        )
        super().__init__(params, defaults)

    def step(self):

        for group in self.param_groups:

            lr = group["lr"]
            momentum = group["momentum"]
            zeropower_backend = zeropower_backends[group["backend"]]

            # generate weight updates in distributed fashion
            total_params = sum(p.numel() for p in group["params"])
            updates_flat = torch.zeros(
                total_params, device="cuda", dtype=torch.bfloat16
            )
            curr_idx = 0
            for i, p in enumerate(group["params"]):
                # luckily this will perfectly distribute a transformer with multiple of 4 layers to 8 GPUs
                if i % int(os.environ["WORLD_SIZE"]) == int(os.environ["RANK"]):
                    g = p.grad
                    assert g is not None
                    state = self.state[p]
                    if "momentum_buffer" not in state:
                        state["momentum_buffer"] = torch.zeros_like(g)
                    buf = state["momentum_buffer"]
                    buf.mul_(momentum).add_(g)
                    if group["nesterov"]:
                        g = g.add(buf, alpha=momentum)
                    g = zeropower_backend(g, steps=group["backend_steps"])
                    g *= max(1, g.size(0) / g.size(1)) ** 0.5
                    updates_flat[curr_idx : curr_idx + p.numel()] = g.flatten()
                curr_idx += p.numel()

            # sync updates across devices. we are not memory-constrained so can do this simple deserialization
            dist.all_reduce(updates_flat, op=dist.ReduceOp.SUM)

            # deserialize and apply updates
            curr_idx = 0
            for p in group["params"]:
                g = (
                    updates_flat[curr_idx : curr_idx + p.numel()]
                    .view_as(p.data)
                    .type_as(p.data)
                )
                p.data.add_(g, alpha=-lr)
                curr_idx += p.numel()


@dataclass
class OptimizerConfig:
    # Embedding layer optimizer settings
    embedding_lr: float = 0.3
    embedding_betas: Tuple[float, float] = (0.9, 0.95)

    # Output layer optimizer settings
    output_lr: float = 0.002
    output_betas: Tuple[float, float] = (0.9, 0.95)

    # Transformer blocks optimizer settings
    transformer_lr: float = 0.02
    transformer_momentum: float = 0.95

    # Learning rate schedule settings
    num_iterations: int = 500
    warmup_iters: int = 0
    warmdown_iters: int = 1308


def create_optimizers(
    model: nn.Module, config: OptimizerConfig
) -> Tuple[List[torch.optim.Optimizer], List[torch.optim.lr_scheduler.LRScheduler]]:
    """
    Creates and returns optimizers and schedulers for different parts of the model.

    Args:
        model (nn.Module): The model to optimize (Look at the networks.py file for the model structure).
        config (OptimizerConfig): The configuration for the optimizers.

    Returns:
        optimizers (List[torch.optim.Optimizer]): The optimizers for the different parts of the model.
        schedulers (List[torch.optim.lr_scheduler.LRScheduler]): The schedulers for the different parts of the model.
    """

    # Create optimizers for different parts of the model
    optimizer1 = torch.optim.Adam(
        [model.transformer.wte.weight],
        lr=config.embedding_lr,
        betas=config.embedding_betas,
        fused=True,
    )

    optimizer2 = torch.optim.Adam(
        [model.lm_head.weight],
        lr=config.output_lr,
        betas=config.output_betas,
        fused=True,
    )

    optimizer3 = Muon(
        model.transformer.h.parameters(),
        lr=config.transformer_lr,
        momentum=config.transformer_momentum,
    )

    optimizers = [optimizer1, optimizer2, optimizer3]

    # Create learning rate scheduler
    def get_lr(it):
        assert it <= config.num_iterations
        if it < config.warmup_iters:
            return (it + 1) / config.warmup_iters
        elif it < config.num_iterations - config.warmdown_iters:
            return 1.0
        else:
            decay_ratio = (config.num_iterations - it) / config.warmdown_iters
            return decay_ratio

    schedulers = [torch.optim.lr_scheduler.LambdaLR(opt, get_lr) for opt in optimizers]

    return optimizers, schedulers
