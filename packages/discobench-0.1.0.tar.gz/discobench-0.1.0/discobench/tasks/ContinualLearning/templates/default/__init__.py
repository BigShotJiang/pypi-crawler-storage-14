"""ContinualLearning default template package."""
