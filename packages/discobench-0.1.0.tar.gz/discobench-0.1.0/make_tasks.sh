#!/usr/bin/env bash

# Path to the tasks directory (modify if needed)
TASKS_DIR="discobench/tasks"

# Loop through each subdirectory in tasks/
for task_path in "$TASKS_DIR"/*/; do
    task_name=$(basename "$task_path")

    # Skip utils or any non-task directory you don't want
    if [ "$task_name" = "utils" ]; then
        continue
    fi

    echo "Running: discobench create-task --task-domain $task_name --no-data"
    discobench create-task --task-domain "$task_name"
done
