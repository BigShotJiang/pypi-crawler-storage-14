import abc

from obi_one.core.base import OBIBaseModel


class Task(OBIBaseModel, abc.ABC):
    pass
