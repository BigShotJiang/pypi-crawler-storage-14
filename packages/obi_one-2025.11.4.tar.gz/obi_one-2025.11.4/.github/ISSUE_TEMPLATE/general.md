---
name: General
about: For general OBI tickets (not bugs or feature requests)
title: ''
labels: ''
assignees: james-isbister

---

## Description
Clear & concise 

## Acceptance criteria
- [ ] Include a checkbox list
- [ ] Include a checkbox list
- [ ] Include a checkbox list

## Right panel fields

### Assignee
Will be added by default (the Product Owner)

### Labels
E.g. You can add 'planning' (for QA discussion), 'up next?' (for resource request), or other as applicable

### Type
Bug / Feature / Task

### Projects
Select 'OBI 2025-' project (plus others as relevant)
Priority: P0 (higher), P1, or P2 (lower)
Time estimate: In days
