"""Performance tests - benchmarks and memory usage."""
