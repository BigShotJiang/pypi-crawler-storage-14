"""
X12 EDI Python Toolkit - Test Suite

TDD-driven test suite for the X12 EDI library.
Tests are written FIRST to define expected behavior.
"""
