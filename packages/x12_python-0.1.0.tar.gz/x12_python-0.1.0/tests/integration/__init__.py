"""Integration tests - multi-component interaction tests."""
