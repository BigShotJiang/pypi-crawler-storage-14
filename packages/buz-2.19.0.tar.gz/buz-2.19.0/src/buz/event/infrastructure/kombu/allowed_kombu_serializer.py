from enum import Enum


class AllowedKombuSerializer(str, Enum):
    JSON = "json"
