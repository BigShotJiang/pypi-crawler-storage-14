from enum import Enum


class OutboxSortingCriteria(Enum):
    CREATED_AT = "created_at"
