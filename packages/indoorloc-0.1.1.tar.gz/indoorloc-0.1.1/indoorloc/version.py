"""IndoorLoc version information."""

__version__ = '0.1.1'
__version_info__ = tuple(int(x) for x in __version__.split('.'))

__all__ = ['__version__', '__version_info__']
