from .str_matching import *
from ._smart_dedup import smart_dedup as smart_dedup