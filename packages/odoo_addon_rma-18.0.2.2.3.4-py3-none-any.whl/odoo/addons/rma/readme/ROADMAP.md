- As soon as the picking is selected, the user should select the move,
  but perhaps stock.move \_rec_name could be improved to better show
  what the product of that move is.
- Add RMA reception and/or RMA delivery on several steps - 2 or 3 - like
  normal receptions/deliveries. It should be a separate option inside the
  warehouse definition.
