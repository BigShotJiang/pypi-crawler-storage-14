""" Unit tests for the custom NSGA2 Driver. """

from wisdem.optimization_drivers.nsga2_driver import NSGA2Driver

class TestNSGA2Driver:

    def setup_method(self):

        pass

    def test_sandbox(self):

        pass


##### FIN!!! #####
