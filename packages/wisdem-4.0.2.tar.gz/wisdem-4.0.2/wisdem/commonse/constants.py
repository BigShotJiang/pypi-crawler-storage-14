gravity = 9.80633
eps = 1e-12
RIGID = 1.0e30
