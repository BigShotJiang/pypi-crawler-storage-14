from math import pi

# convert between rotations/minute and radians/second
RPM2RS = pi / 30.0
RS2RPM = 30.0 / pi
