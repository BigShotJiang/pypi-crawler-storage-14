::: python_thingset.response.ThingSetResponse
    options:
        filters: ["!^_"]
