::: python_thingset.response.ThingSetValue
    options:
        filters: ["!^_"]
