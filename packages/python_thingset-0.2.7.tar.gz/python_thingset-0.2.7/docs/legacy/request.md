::: python_thingset.response.ThingSetRequest
    options:
        members:
            - request_name
            - GET
            - EXEC
            - DELETE
            - FETCH
            - CREATE
            - UPDATE
