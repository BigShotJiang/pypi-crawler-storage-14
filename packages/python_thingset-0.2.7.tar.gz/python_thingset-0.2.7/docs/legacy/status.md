::: python_thingset.response.ThingSetStatus
    options:
        members:
            - status_code_name
            - CREATED
            - DELETED
            - CHANGED
            - CONTENT
            - BAD_REQUEST
            - UNAUTHORISED
            - FORBIDDEN
            - NOT_FOUND
            - NOT_ALLOWED
            - REQUEST_INCOMPLETE
            - CONFLICT
            - REQUEST_TOO_LARGE
            - UNSUPPORTED_FORMAT
            - INTERNAL_ERROR
            - NOT_IMPLEMENTED
            - GATEWAY_TIMEOUT
            - NOT_GATEWAY
