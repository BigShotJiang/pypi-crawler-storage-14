To build documentation:

If you don't have Sphinx installed, grab it from http://sphinx-doc.org, or install it with PIP (python3 -m pip install sphinx)

In this directory(sphinx) do...	
	
Linux:
	'make html'

Windows:
	'make_for_windows html'
