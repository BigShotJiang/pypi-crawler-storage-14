from typing import Any, Dict, List
from ..core.discovery_engine import SearchClient
from ..utils.helpers import extract_result_metadata

def discovery_search(
    project_id: str,
    location: str,
    engine_id: str,
    api_key: str,
    query: str,
    total_results: int,
    fields: List[str]
) -> Dict[str, Any]:

    client = SearchClient(project_id, location, engine_id, api_key)
    aggregated = []
    page_token = ""
    page_count = 0

    while len(aggregated) < total_results and page_count < 100:
        page_count += 1

        response = client.search(query, page_token)
        if not response:
            break

        for res in response.results:
            metadata = extract_result_metadata(res, fields)
            aggregated.append(metadata)
            if len(aggregated) >= total_results:
                break

        page_token = getattr(response, "next_page_token", "")
        if not page_token:
            break

    return {
        "query": query,
        "requested": total_results,
        "collected": len(aggregated),
        "results": aggregated,
    }