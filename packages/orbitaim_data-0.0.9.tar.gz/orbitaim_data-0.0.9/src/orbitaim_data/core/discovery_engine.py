import time
import logging as log
from typing import Optional
from google.api_core.client_options import ClientOptions
from google.cloud import discoveryengine_v1 as discoveryengine


class SearchClient:
    def __init__(self, project_id: str, location: str, engine_id: str, api_key: str):
        self.project_id = project_id
        self.location = location
        self.engine_id = engine_id
        self.api_key = api_key

    def search(self, query: str, page_token: str = "", retries: int = 5, delay: int = 5):
        for attempt in range(retries + 1):
            try:
                client_options = ClientOptions(
                    api_key=self.api_key,
                    api_endpoint=f"{self.location}-discoveryengine.googleapis.com"
                    if self.location != "global"
                    else None,
                )

                client = discoveryengine.SearchServiceClient(
                    client_options=client_options
                )

                serving_config = (
                    f"projects/{self.project_id}/locations/{self.location}"
                    f"/collections/default_collection/engines/{self.engine_id}"
                    f"/servingConfigs/default_config"
                )

                req = discoveryengine.SearchRequest(
                    serving_config=serving_config,
                    query=query,
                    page_size=100,
                    page_token=page_token
                )

                return client.search_lite(req, timeout=30)

            except Exception as e:
                log.error(f"[Search Error] {e}")
                if attempt < retries:
                    time.sleep(delay)
                else:
                    return None