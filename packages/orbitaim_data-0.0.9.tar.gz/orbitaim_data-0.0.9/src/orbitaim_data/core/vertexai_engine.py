import time
from typing import Optional
from google.api_core.client_options import ClientOptions
from google.cloud import discoveryengine_v1 as discoveryengine
from google.oauth2 import service_account
import logging as log


def discovery_search_engine_json_only(
    project_id: str,
    location: str,
    engine_id: str,
    json_file: str,
    search_query: str,
    page_token: str = "",
    max_retries: int = 5,
    retry_delay: int = 5,
):
    if not all([project_id, location, engine_id, json_file, search_query]):
        log.error("Missing required parameters in search function.")
        return None

    for retry_count in range(max_retries + 1):
        try:
            credentials = service_account.Credentials.from_service_account_file(json_file)
            client_options = ClientOptions(
                api_endpoint=f"{location}-discoveryengine.googleapis.com"
                if location != "global"
                else None
            )

            client = discoveryengine.SearchServiceClient(
                client_options=client_options,
                credentials=credentials
            )

            serving_config = (
                f"projects/{project_id}/locations/{location}"
                f"/collections/default_collection/engines/{engine_id}"
                f"/servingConfigs/default_config"
            )

            request = discoveryengine.SearchRequest(
                serving_config=serving_config,
                query=search_query,
                page_size=100,
                page_token=page_token,
            )

            return client.search_lite(request, timeout=30)

        except Exception as e:
            log.error(f"Error searching engine {engine_id}: {e}")
            if retry_count < max_retries:
                log.info(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                log.error("Max retries reached. Returning None.")
                return None