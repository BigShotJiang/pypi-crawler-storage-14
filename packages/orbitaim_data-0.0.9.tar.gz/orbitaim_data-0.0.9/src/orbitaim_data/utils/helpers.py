from typing import Dict, Optional, Any, List
import re
from ..web_scrapping.scrape_metadata import (
    extract_snippets_text,
    extract_comprehensive_description,
    extract_comprehensive_date
)

# All fields supported
ALL_FIELDS = {
    "title", "link", "description", "snippets", "formatted_url",
    "display_link", "thumbnail", "favicon", "source", "language",
    "site_name", "author", "keywords", "pubDate",

    # Profile
    "first_name", "last_name", "profile_username", "profile_gender",

    # OG
    "og_title", "og_description", "og_image", "og_url",
    "og_site_name", "og_type", "og_locale",

    # Twitter
    "twitter_title", "twitter_description", "twitter_image",
    "twitter_card", "twitter_site", "twitter_creator",
}


def extract_result_metadata(result, required_fields: List[str]) -> Dict[str, Optional[Any]]:
    """Extract only requested fields from the search result metadata."""
    required_fields = [f for f in required_fields if f in ALL_FIELDS]

    doc_data = result.document.derived_struct_data or {}
    pagemap = doc_data.get("pagemap", {})
    snippets = extract_snippets_text(doc_data)

    data = {
        "title": doc_data.get("title"),
        "link": doc_data.get("link"),
        "description": extract_comprehensive_description(doc_data, pagemap, snippets),
        "pubDate": extract_comprehensive_date(doc_data, pagemap, doc_data.get("link"), snippets, title=doc_data.get("title")),
        "snippets": doc_data.get("snippets"),
        "formatted_url": doc_data.get("formattedUrl"),
        "display_link": doc_data.get("displayLink"),
        "thumbnail": doc_data.get("thumbnail"),
        "favicon": doc_data.get("favicon"),
        "source": doc_data.get("source"),
        "language": doc_data.get("language"),
        "site_name": doc_data.get("site_name"),
        "author": doc_data.get("author"),
        "keywords": doc_data.get("keywords"),

        # Profile defaults
        "first_name": None,
        "last_name": None,
        "profile_username": None,
        "profile_gender": None,
    }

    # Metatags
    metatags = pagemap.get("metatags", [])
    if metatags:
        tag = metatags[0]
        data.update({
            "og_title": tag.get("og:title"),
            "og_description": tag.get("og:description"),
            "og_image": tag.get("og:image"),
            "og_url": tag.get("og:url"),
            "og_site_name": tag.get("og:site_name"),
            "og_type": tag.get("og:type"),
            "og_locale": tag.get("og:locale"),

            "twitter_title": tag.get("twitter:title"),
            "twitter_description": tag.get("twitter:description"),
            "twitter_image": tag.get("twitter:image"),
            "twitter_card": tag.get("twitter:card"),
            "twitter_site": tag.get("twitter:site"),
            "twitter_creator": tag.get("twitter:creator"),

            "first_name": tag.get("profile:first_name"),
            "last_name": tag.get("profile:last_name"),
            "profile_username": tag.get("profile:username"),
            "profile_gender": tag.get("profile:gender"),
        })

    # Return only requested fields
    return {k: data.get(k) for k in required_fields}
