# 示例调用

#重要：：：token必须设置：：：
import chinamindata.min as ts

ts.set_token('')
ts.pro_api('')

import chinamindata.min as ts
#1可以获取大A股票分钟，freq取值1min'、'5min'、'15min'、'30min'、'60min'

df = ts.pro_bar(ts_code = '000001.SZ', start_date = '2010-07-07 09:00:00',
                       end_date = '2024-07-22 15:00:00',freq='60min')
print(df)
#2可以获取大A股票分钟开盘竞价
pro = ts.pro_api()
df=pro.stk_auction_o(trade_date='20251130')
print(df)
df=pro.stk_auction(start_date='2017-01-01', end_date='2018-12-31',)
print(df)
df=pro.stk_auction(start_date='2017-01-01', end_date='2018-12-31',offset=15000)
print(df)
df=pro.stk_auction(ts_code='601677.SH',fields=' trade_date,vol,price,amount,turnover_rate,volume_ratio')
print(df)

# #3可以获取大A股票分钟闭盘竞价
pro = ts.pro_api()
df=pro.stk_auction_c(trade_date='20241122')
print(df)

pro = ts.pro_api()
df=pro.stk_auction(trade_date='20241122')
print(df)

df = pro.stk_mins(ts_code='600000.SH', freq='1min', start_date='2020-08-25 09:00:00', end_date='2023-08-25 19:00:00',offset=2)
print(df)
# #4可以获取大A股票、指数、基金的列表.type取值'stock',"MSCI","CSI","SSE","SZSE","CICC","SW","OTH","E","O"
