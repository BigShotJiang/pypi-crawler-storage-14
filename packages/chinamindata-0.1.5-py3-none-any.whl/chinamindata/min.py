from chinamindata.china_min_open import stk_auction_o1
from chinamindata.china_min_close import stk_auction_c1
from chinamindata.china_min_now import stk_auction_1
from chinamindata.china_min_stk import stk_mins_1
from chinamindata.china_min import pro_bar1

class pro_api:
    def __init__(self, token=None):
        if token is not None:
            self.token = token  # 实例变量，用于内部使用或调试
            set_token(token)

        else:
            self.token = get_token()
            if self.token is None:
                raise ValueError("请设置token")
            else:
                pass


    def stk_auction_o(self,**kwargs):
        return stk_auction_o1(**kwargs)

    def stk_auction_c(self,**kwargs):
        return stk_auction_c1(**kwargs)

    def stk_auction(self,**kwargs):
        return stk_auction_1(**kwargs)

    def stk_mins(self, **kwargs):
        return stk_mins_1(**kwargs)

def pro_bar(ts_code, start_date, end_date,limit='8000',offset='0',freq='60min'):
    return pro_bar1(code=ts_code, start_date=start_date, end_date=end_date, limit=limit, offset=offset, freq=freq)



import pandas as pd
import os

BK = 'bk'

def set_token(token):
    df = pd.DataFrame([token], columns=['token'])
    user_home = os.path.expanduser('~')
    fp = os.path.join(user_home, 'c_m_t.csv')
    df.to_csv(fp, index=False)


def get_token():
    user_home = os.path.expanduser('~')
    fp = os.path.join(user_home, 'c_m_t.csv')
    if os.path.exists(fp):

        df = pd.read_csv(fp)


        return str(df.loc[0]['token'])
    else:

        return "请设置token"

