"""MCP Server for Cricbuzz Cricket"""
