def failed_doc_test():
    """
    This is a DocTest that will fail:

    >>> failed_doc_test()
    123

    But the real test is that the `excludes` argument ot run_doctests() will work.
    """
    pass
