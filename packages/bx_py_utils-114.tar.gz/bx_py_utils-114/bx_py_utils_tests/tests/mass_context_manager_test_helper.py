def foo():
    return 'foo'


def bar():
    return 'bar'


def get_foo_bar():
    return f'{foo()} {bar()}'
