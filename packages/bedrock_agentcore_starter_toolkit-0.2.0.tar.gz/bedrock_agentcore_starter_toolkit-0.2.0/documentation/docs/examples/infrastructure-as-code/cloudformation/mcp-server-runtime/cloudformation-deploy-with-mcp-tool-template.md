```yaml
{% include "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/04-infrastructure-as-code/cloudformation/mcp-server-agentcore-runtime/mcp-server-template.yaml" %}
```

### get_token.py
```python
{% include "https://raw.githubusercontent.com/awslabs/amazon-bedrock-agentcore-samples/refs/heads/main/04-infrastructure-as-code/cloudformation/mcp-server-agentcore-runtime/get_token.py" %}
```
