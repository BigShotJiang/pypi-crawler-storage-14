"""Tests for CLI observability commands."""
