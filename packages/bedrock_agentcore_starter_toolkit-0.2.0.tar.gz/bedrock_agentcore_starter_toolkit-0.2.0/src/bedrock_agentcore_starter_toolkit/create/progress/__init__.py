"""ProgressSink for the create feature."""
