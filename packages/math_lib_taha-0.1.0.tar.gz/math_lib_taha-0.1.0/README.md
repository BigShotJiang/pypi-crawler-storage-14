# My Math Lib

A simple Python library to add two numbers.

## Example

```python
from my_math_lib import add_numbers

print(add_numbers(3, 5))
