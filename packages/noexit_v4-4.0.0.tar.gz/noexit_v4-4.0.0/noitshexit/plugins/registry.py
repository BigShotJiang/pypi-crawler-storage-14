plugins = []

def register(plugin):
    plugins.append(plugin)

def run_all(context):
    for p in plugins:
        try:
            p(context)
        except:
            pass
