def safe_alert(msg, extra=None):
    line = f"[NoExit] {msg}"
    if extra:
        line += " | " + " ".join(map(str, extra))
    print(line)
