import builtins
from .hooks_ast import patch_ast_source

_original_exec = builtins.exec
_original_eval = builtins.eval

def apply_exec_hooks():
    def safe_exec(code, g=None, l=None):
        if isinstance(code, str):
            code = patch_ast_source(code)
        return _original_exec(code, g if g else {}, l if l else {})

    def safe_eval(code, g=None, l=None):
        if isinstance(code, str):
            code = patch_ast_source(code)
        return _original_eval(code, g if g else {}, l if l else {})

    builtins.exec = safe_exec
    builtins.eval = safe_eval
