import builtins
import sys
import os
from ..utils.safe_print import safe_alert

def apply_exit_patches():
    def fake_exit(*args, **kwargs):
        safe_alert("Exit blocked.", args)

    def fake_os_exit(code=0):
        safe_alert(f"os._exit({code}) blocked.")

    builtins.exit = fake_exit
    builtins.quit = fake_exit
    sys.exit = fake_exit
    os._exit = fake_os_exit
