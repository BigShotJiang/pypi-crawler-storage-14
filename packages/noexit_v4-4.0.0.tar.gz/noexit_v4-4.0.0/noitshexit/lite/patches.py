import builtins
import sys
import os

def apply_exit_patches():
    def fake_exit(*args, **kwargs):
        print("[NoExitLite] exit() blocked:", *args)

    def fake_os_exit(code=0):
        print(f"[NoExitLite] os._exit({code}) blocked")

    builtins.exit = fake_exit
    builtins.quit = fake_exit
    sys.exit = fake_exit
    os._exit = fake_os_exit
