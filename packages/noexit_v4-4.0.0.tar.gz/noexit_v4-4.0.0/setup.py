from setuptools import setup, find_packages

setup(
    name="noexit-v4",
    version="4.0.0",
    description="UltraSafe Python library: convert any exit/quit/sys.exit/os._exit to print automatically.",
    author="ITSH",
    packages=find_packages(),
    python_requires=">=3.8",
    include_package_data=True,
)
