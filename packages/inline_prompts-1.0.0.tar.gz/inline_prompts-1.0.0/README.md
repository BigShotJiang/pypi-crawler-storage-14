# Inline Prompts

`Inline Prompts` allows you to write better inline prompts in your python programs.

## Installation

## Examples

```python3
from inline_prompts import inline_prompt as ip

def get_system_prompt():
    prompt = ip("""
        Without the Inline Prompts package,
        prompts written like this would
        have a leading newline,
        and spacing at the start of each newline.
        Inline prompts abstracts that behavior away.
    """)

    return prompt

print(get_system_prompt())
```

Results in
```bash
Without the Inline Prompts package,
prompts written like this would
have a leading newline,
and spacing at the start of each newline.
Inline prompts abstracts that behavior away.
```

Without inline prompts, you would get
```python3

        Without the Inline Prompts package,
        prompts written like this would
        have a leading newline,
        and spacing at the start of each newline.
        Inline prompts abstracts that behavior away.
```

