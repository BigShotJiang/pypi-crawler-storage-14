def inline_prompt(prompt: str) -> str:
    """Process a multi-line string to remove common indentation and leading/trailing blank lines.

    Args:
        prompt: A multi-line string, typically a triple-quoted string literal.

    Returns:
        The processed string with common indentation removed and leading/trailing
        blank lines stripped.
    """
    lines = prompt.split('\n')

    # Strip leading blank lines
    while lines and not lines[0].strip():
        lines.pop(0)

    # Strip trailing blank lines
    while lines and not lines[-1].strip():
        lines.pop()

    if not lines:
        return ""

    # Find minimum indentation among non-empty lines
    min_indent = None
    for line in lines:
        if line.strip():  # Only consider non-empty lines
            indent = len(line) - len(line.lstrip())
            if min_indent is None or indent < min_indent:
                min_indent = indent

    if min_indent is None:
        min_indent = 0

    # Remove the common indentation from all lines
    result_lines = []
    for line in lines:
        if line.strip():  # Non-empty line
            result_lines.append(line[min_indent:])
        else:  # Empty line - preserve as empty
            result_lines.append("")

    return '\n'.join(result_lines)
