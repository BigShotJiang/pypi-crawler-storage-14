"""inline_prompts - A Python package for inline prompts."""

from .core import inline_prompt

__version__ = "1.0.0"
__all__ = ["inline_prompt"]
