# LogMagix-Yuge

> 强大的 Python 日志库 - 支持彩色日志、动态加载动画和多行实时显示

[![Python](https://img.shields.io/badge/Python-3.7+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## ✨ 特性

- 🎨 **彩色日志** - 多种日志级别，美观易读
- 🔄 **动态加载** - 单行 Loader 实时更新
- 📊 **多行显示** - 同时监控多个任务（新功能！）
- 💾 **文件日志** - 自动保存到文件
- 🖥️ **跨平台** - Windows / Linux / macOS

## 📦 安装

```bash
pip install logmagix-yuge
```

或者从源码安装：

```bash
pip install colorama pystyle packaging requests
```

## 🚀 快速开始

### Logger - 彩色日志

```python
from logmagix import Logger

log = Logger(prefix="MyApp")

log.info("应用启动")
log.success("操作成功")
log.warning("警告信息")
log.error("错误信息")
```

### Loader - 单行动态

```python
from logmagix import Loader
import time

# 方式1: 手动控制
loader = Loader(prefix="任务", desc="处理中...").start()
time.sleep(3)
loader.stop()

# 方式2: Context Manager
with Loader(prefix="任务", desc="处理中...", end="完成!"):
    time.sleep(3)
```

### Loader - 多行模式 ⭐ 新功能

```python
from logmagix import Loader
import time

# 创建多个任务（设置 multiline=True）
loader1 = Loader(prefix="任务1", desc="运行中...", multiline=True).start()
loader2 = Loader(prefix="任务2", desc="运行中...", multiline=True).start()
loader3 = Loader(prefix="任务3", desc="运行中...", multiline=True).start()

# 动态更新
loader1.desc = "步骤1: 准备数据..."
loader2.desc = "步骤2: 处理数据..."
loader3.desc = "步骤3: 保存结果..."

time.sleep(3)

# 停止
loader1.stop()
loader2.stop()
loader3.stop()

time.sleep(1)  # 等待自动清理
print("完成！")
```

**效果：**
```
[任务1] [17:00:01] [步骤1: 准备数据...] ⠋
[任务2] [17:00:01] [步骤2: 处理数据...] ⠙
[任务3] [17:00:01] [步骤3: 保存结果...] ⠹

↓ 停止后 ↓

[任务1] [17:00:04] [完成!] ✓
[任务2] [17:00:04] [完成!] ✓
[任务3] [17:00:04] [完成!] ✓
```

## 📖 使用示例

### 动态进度更新

```python
from logmagix import Loader
import time

loader = Loader(prefix="下载", desc="0%", multiline=True).start()

for i in range(1, 101):
    loader.desc = f"下载进度: {i}%"
    time.sleep(0.05)

loader.stop()
time.sleep(1)
```

### 多线程任务监控

```python
from logmagix import Loader
import time
import threading

def worker(task_id):
    loader = Loader(
        prefix=f"线程{task_id}",
        desc="处理中...",
        end="完成!",
        multiline=True
    ).start()

    # 模拟工作
    for i in range(10):
        loader.desc = f"进度: {i*10}%"
        time.sleep(0.3)

    loader.stop()

# 启动 3 个并发任务
threads = [threading.Thread(target=worker, args=(i,)) for i in range(1, 4)]
for t in threads:
    t.start()
for t in threads:
    t.join()

time.sleep(1)
print("所有任务完成！")
```

### 日志级别控制

```python
from logmagix import Logger, LogLevel

# 只显示 WARNING 及以上级别
log = Logger(prefix="MyApp", level=LogLevel.WARNING)

log.debug("不会显示")
log.info("不会显示")
log.warning("会显示")
log.error("会显示")
```

### 文件日志

```python
from logmagix import Logger

log = Logger(
    prefix="MyApp",
    log_file="logs/app.log"
)

log.info("这条日志会同时输出到控制台和文件")
```

## 📚 完整文档

详细文档请查看：[LogMagix使用文档.md](../LogMagix使用文档.md)

## 🎯 API 参考

### Loader 类

```python
Loader(
    prefix: str = "Task",          # 任务名称
    desc: str = "Loading...",      # 描述文本（可更新）
    end: str = "\r",               # 结束文本
    timeout: float = 0.1,          # 动画间隔（单行模式）
    multiline: bool = False        # 多行模式开关
)
```

**方法：**
- `start()` - 启动 Loader
- `stop()` - 停止 Loader

**属性：**
- `desc` - 描述文本（可读写）

### Logger 类

```python
Logger(
    style: int = 1,                # 样式（1=彩色，2=简洁）
    prefix: str = "App",           # 日志前缀
    level: LogLevel = DEBUG,       # 最低日志级别
    log_file: str = None           # 日志文件路径
)
```

**方法：**
- `debug(msg)` - 调试日志
- `info(msg)` - 信息日志
- `warning(msg)` - 警告日志
- `success(msg)` - 成功日志
- `error(msg)` - 错误日志
- `critical(msg)` - 严重错误

## ⚠️ 注意事项

### 多行模式

1. **不要在运行期间使用 `print()`**
   ```python
   # ❌ 错误
   loader.start()
   print("启动")  # 破坏渲染

   # ✅ 正确
   loader.start()
   loader.stop()
   time.sleep(1)
   print("完成")
   ```

2. **等待自动停止**
   ```python
   loader1.stop()
   loader2.stop()
   time.sleep(1)  # 等待 Manager 自动停止
   ```

### 平台兼容性

- ✅ Windows 10+
- ✅ Linux
- ✅ macOS
- ⚠️ Windows 7/8 可能不支持

## 🔧 常见问题

**Q: 多行模式下任务消失了？**

A: 确保没有在运行期间使用 `print()`，并在停止后等待 1 秒。

**Q: 如何改变动画样式？**

A: 修改 `loader.steps` 属性：
```python
loader.steps = ["◐", "◓", "◑", "◒"]
```

**Q: 单行和多行可以混用吗？**

A: 不建议。同一时间应只使用一种模式。

## 📝 更新日志

### v2.x - 多行模式支持

- ✅ 新增多行模式（`multiline=True`）
- ✅ 支持同时显示多个任务
- ✅ 自动生命周期管理
- ✅ 完全向下兼容

### v1.x - 基础功能

- Logger 彩色日志
- Loader 单行动态
- 文件日志支持

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE)

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 👤 作者

LogMagix-Yuge 由 **yuge666** 开发和维护

---

**基于 LogMagix 优化而来**
