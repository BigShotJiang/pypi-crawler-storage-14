from setuptools import setup, find_packages
import re
from pathlib import Path

# 读取版本号而不导入包（避免依赖问题）
def get_version():
    version_file = Path(__file__).parent / "logmagix" / "version.py"
    version_text = version_file.read_text(encoding="utf-8")
    match = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]', version_text, re.MULTILINE)
    if match:
        return match.group(1)
    raise RuntimeError("Unable to find version string.")

setup(
    name="logmagix-yuge",
    version=get_version(),
    packages=find_packages(),
    install_requires=["colorama>=0.4.6", "pystyle>=2.9", "packaging", "requests"],
    author="yuge666",
    description="Beautiful Python Logger with multi-line dynamic display support",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
