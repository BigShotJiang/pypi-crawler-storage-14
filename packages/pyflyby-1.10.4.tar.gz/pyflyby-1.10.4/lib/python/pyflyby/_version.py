# pyflyby/_version.py.

# License for THIS FILE ONLY: CC0 Public Domain Dedication
# http://creativecommons.org/publicdomain/zero/1.0/

import importlib.metadata

__version__ = importlib.metadata.version('pyflyby')
