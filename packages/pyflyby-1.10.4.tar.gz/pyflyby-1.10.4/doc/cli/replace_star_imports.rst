replace-star-imports CLI
========================
.. automodule:: replace-star-imports
   :members:
