"""Alarm system for taskswitch - DING functionality.

This module provides timed alarms with optional repeat functionality,
plus gentle transition tones for randodoro.
"""
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from typing import Optional

import pytz

from .utils import _get_tz, clear_screen


def _play_gentle_transition_tone(duration: float = 15.0) -> None:
    """Play a gentle bell sound for randodoro phase transitions.
    
    Uses the same alarm sound system as DING but plays once.
    
    Args:
        duration: Duration parameter (ignored, kept for compatibility)
    """
    # Just use the same alarm sound as DING, but play it once
    _play_alarm_sound(repeat=1)


def _play_alarm_sound(repeat: int = 3) -> None:
    """Play an alarm sound using system beep with 1.5x volume boost.
    
    Args:
        repeat: Number of beeps to play
    """
    try:
        # Linux: Use beep command or fallback to system bell
        if sys.platform.startswith('linux'):
            # Try multiple bell sounds in sequence for a "ding-ding-ding" effect
            sounds = [
                '/usr/share/sounds/freedesktop/stereo/complete.oga',  # More bell-like
                '/usr/share/sounds/freedesktop/stereo/bell.oga',
            ]
            
            # Try paplay (PulseAudio) with volume boost - 1.5x volume increase
            try:
                for _ in range(repeat):
                    played = False
                    for sound in sounds:
                        if os.path.exists(sound):
                            # Use --volume parameter with paplay (65536 = 100%, 98304 ≈ 150%)
                            result = subprocess.run(['paplay', '--volume=98304', sound], 
                                         check=False, timeout=3, capture_output=True)
                            played = True
                            break
                    if not played:
                        # Fallback to beep if no sound files found
                        print('\a', end='', flush=True)
                    time.sleep(0.3)
                return
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
            
            # Try aplay (ALSA) - note: aplay doesn't have volume control, so increase repeats
            try:
                for _ in range(repeat):
                    played = False
                    for sound in sounds:
                        if os.path.exists(sound):
                            result = subprocess.run(['aplay', sound],
                                         check=False, timeout=3, capture_output=True)
                            played = True
                            break
                    if not played:
                        print('\a', end='', flush=True)
                    time.sleep(0.3)
                return
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass
            
            # Fallback to terminal bell (ASCII BEL character) - more rapid succession for louder effect
            for _ in range(repeat):
                for _ in range(3):  # Triple beep for each repeat (was 2, now 3 for ~1.5x)
                    print('\a', end='', flush=True)
                    time.sleep(0.08)  # Slightly faster for more intensity
                time.sleep(0.25)
                
        # macOS: Use afplay with system sound - play multiple times for volume boost
        elif sys.platform == 'darwin':
            for _ in range(repeat):
                # Play twice rapidly for ~1.5x effect
                for _ in range(2):
                    subprocess.run(['afplay', '/System/Library/Sounds/Glass.aiff'],
                                 check=False, timeout=2, capture_output=True)
                    time.sleep(0.1)
                time.sleep(0.2)
                
        # Windows: Use winsound with increased frequency/duration
        elif sys.platform == 'win32':
            import winsound
            for _ in range(repeat):
                # Play twice for ~1.5x volume effect
                for _ in range(2):
                    winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    time.sleep(0.1)
                time.sleep(0.2)
        
        # Universal fallback: terminal bell with increased intensity
        else:
            for _ in range(repeat):
                for _ in range(3):  # Triple beep (was 2, now 3 for ~1.5x)
                    print('\a', end='', flush=True)
                    time.sleep(0.08)
                time.sleep(0.25)
                
    except Exception:
        # Ultimate fallback: just use terminal bell with increased intensity
        for _ in range(repeat):
            for _ in range(3):  # Triple beep for ~1.5x
                print('\a', end='', flush=True)
                time.sleep(0.08)
            time.sleep(0.25)


class AlarmManager:
    """Manages alarm timers with optional repeating dings."""
    
    def __init__(self):
        """Initialize the alarm manager."""
        self.active_alarm: Optional[threading.Thread] = None
        self.active_alarms: list = []  # List of active alarm threads
        self.cancelled_threads: set = set()  # Set of cancelled thread IDs
        self.shell_ref = None  # Reference to shell for prompt updates
        self.alarm_targets: list = []  # List of (target_datetime, note) tuples for display
    
    def set_alarm(self, hours: float, note: str, repeat_count: int = 0, shell_ref=None) -> None:
        """Set an alarm that will ding after specified hours.
        
        Args:
            hours: Hours from now to set alarm (can be fractional, e.g., 0.5 = 30 min)
            note: Note to display when alarm rings
            repeat_count: Number of additional dings at 5-minute intervals (0 = no repeats)
            shell_ref: Reference to shell instance for updating prompt
        """
        # Cancel any existing alarm
        self.cancel_alarm()
        
        # Reset shell ref
        self.shell_ref = shell_ref
        
        # Calculate target time
        tz = _get_tz()
        target_time = datetime.now(tz) + timedelta(hours=hours)
        self.alarm_targets.append((target_time, note))
        
        # Start alarm in background thread
        self.active_alarm = threading.Thread(
            target=self._alarm_worker,
            args=(hours, note, repeat_count),
            daemon=True
        )
        self.active_alarm.start()
        
        # Also add to active_alarms list for consistent tracking
        self.active_alarms.append(self.active_alarm)
    
    def _alarm_worker(self, hours: float, note: str, repeat_count: int) -> None:
        """Background worker that waits and then rings the alarm.
        
        Args:
            hours: Hours to wait
            note: Note to display
            repeat_count: Number of repeat dings (0 = just 1 ding)
        """
        # Get reference to current thread
        current_thread = threading.current_thread()
        thread_id = id(current_thread)
        
        # Calculate wait time in seconds
        wait_seconds = hours * 3600
        
        # Sleep until first ding
        time.sleep(wait_seconds)
        
        # Check if this specific thread was cancelled
        if thread_id in self.cancelled_threads:
            # Remove self from active list
            if current_thread in self.active_alarms:
                self.active_alarms.remove(current_thread)
            self.cancelled_threads.discard(thread_id)
            return
        
        # Ring the first ding
        is_last_ding = (repeat_count == 0)
        self._ring_alarm(note, 1, repeat_count + 1, is_last_ding)
        
        # Handle repeat dings (3 minutes apart)
        for ding_num in range(2, repeat_count + 2):
            if thread_id in self.cancelled_threads:
                # Remove self from active list
                if current_thread in self.active_alarms:
                    self.active_alarms.remove(current_thread)
                self.cancelled_threads.discard(thread_id)
                return
            
            # Wait 3 minutes (180 seconds)
            time.sleep(180)
            
            if thread_id in self.cancelled_threads:
                # Remove self from active list
                if current_thread in self.active_alarms:
                    self.active_alarms.remove(current_thread)
                self.cancelled_threads.discard(thread_id)
                return
            
            is_last_ding = (ding_num == repeat_count + 1)
            self._ring_alarm(note, ding_num, repeat_count + 1, is_last_ding)
        
        # Clear active alarm references
        self.active_alarm = None
        if current_thread in self.active_alarms:
            self.active_alarms.remove(current_thread)
        # Clean up our thread ID from cancelled set if it's there
        self.cancelled_threads.discard(thread_id)
    
    def _ring_alarm(self, note: str, ding_num: int, total_dings: int, is_last_ding: bool = False) -> None:
        """Ring the alarm and display the note.
        
        Args:
            note: Note to display
            ding_num: Current ding number
            total_dings: Total number of dings
            is_last_ding: Whether this is the final ding
        """
        # Play alarm sound FIRST - single ding
        _play_alarm_sound(repeat=1)
        
        # Clear alarm reference if this is the last ding (so prompt won't show ⏰)
        if is_last_ding:
            self.active_alarm = None
        
        tz = _get_tz()
        current_time = datetime.now(tz).strftime("%H:%M:%S")
        
        # Inline alarm display
        ding_indicator = f" (ding {ding_num}/{total_dings})" if total_dings > 1 else ""
        print(f"\n🔔 DING! [{current_time}]{ding_indicator} - {note}")
        
        # Display the prompt again so user sees current state
        if self.shell_ref:
            try:
                # Update and display the prompt
                self.shell_ref.prompt = self.shell_ref._get_prompt()
                print(self.shell_ref.prompt, end='', flush=True)
            except Exception:
                pass
    
    def cancel_alarm(self) -> bool:
        """Cancel all currently active alarms.
        
        Returns:
            bool: True if an alarm was cancelled, False if no alarm was active
        """
        had_alarms = False
        
        # Mark all active threads for cancellation
        if self.active_alarm and self.active_alarm.is_alive():
            self.cancelled_threads.add(id(self.active_alarm))
            self.active_alarm = None
            had_alarms = True
        
        # Mark all alarms in the list for cancellation
        for thread in self.active_alarms:
            if thread.is_alive():
                self.cancelled_threads.add(id(thread))
                had_alarms = True
        
        # Clear the list (threads will remove themselves)
        self.active_alarms.clear()
        
        # Clear the alarm targets (for clock display)
        self.alarm_targets.clear()
        
        return had_alarms
    
    def is_alarm_active(self) -> bool:
        """Check if any alarms are currently active.
        
        Returns:
            bool: True if any alarm is running
        """
        # Check legacy single alarm
        if self.active_alarm is not None and self.active_alarm.is_alive():
            return True
        
        # Check alarm list and clean up dead threads
        self.active_alarms = [t for t in self.active_alarms if t.is_alive()]
        return len(self.active_alarms) > 0
    
    def get_alarm_info(self) -> Optional[str]:
        """Get information about the active alarm.
        
        Returns:
            str: Info string if alarm is active, None otherwise
        """
        if self.is_alarm_active():
            return "⏰ Alarm active"
        return None
    
    def get_alarm_clocks_display(self) -> str:
        """Get formatted display of all active alarms with time remaining.
        
        Returns:
            str: Formatted string like "⏰(2:30) ⏰(5:15)" or empty string if no alarms
        """
        if not self.alarm_targets:
            return ""
        
        tz = _get_tz()
        now = datetime.now(tz)
        clocks = []
        
        # Clean up expired alarms from targets list
        active_targets = []
        for target_time, note in self.alarm_targets:
            time_remaining = target_time - now
            if time_remaining.total_seconds() > 0:
                active_targets.append((target_time, note))
                # Format as hours:minutes
                total_minutes = int(time_remaining.total_seconds() / 60)
                hours = total_minutes // 60
                minutes = total_minutes % 60
                if hours > 0:
                    clocks.append(f"⏰({hours}:{minutes:02d})")
                else:
                    clocks.append(f"⏰({minutes}m)")
        
        self.alarm_targets = active_targets
        return " ".join(clocks) if clocks else ""


    def set_alarm_chain(self, alarms: list, shell_ref=None) -> None:
        """Set multiple chained alarms from a single command.
        
        Args:
            alarms: List of (repeat_count, hours, note) tuples
            shell_ref: Reference to shell instance for updating prompt
        """
        # Cancel any existing alarms
        self.cancel_alarm()
        
        # Reset shell ref
        self.shell_ref = shell_ref
        
        # Calculate cumulative timing and start each alarm
        tz = _get_tz()
        base_time = datetime.now(tz)
        cumulative_hours = 0.0
        
        for repeat_count, hours, note in alarms:
            cumulative_hours += hours
            
            # Store target time for display
            target_time = base_time + timedelta(hours=cumulative_hours)
            self.alarm_targets.append((target_time, note))
            
            # Start alarm in background thread with cumulative timing
            alarm_thread = threading.Thread(
                target=self._alarm_worker,
                args=(cumulative_hours, note, repeat_count),
                daemon=True
            )
            alarm_thread.start()
            self.active_alarms.append(alarm_thread)


# Global alarm manager instance
_alarm_manager = AlarmManager()


def get_alarm_manager() -> AlarmManager:
    """Get the global alarm manager instance.
    
    Returns:
        AlarmManager: The global alarm manager
    """
    return _alarm_manager
