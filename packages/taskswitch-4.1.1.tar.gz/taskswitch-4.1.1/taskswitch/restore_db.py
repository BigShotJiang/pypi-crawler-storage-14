"""Restore database from markdown backup."""

from taskswitch.models import db, Project, Task, Config
from datetime import datetime
import pytz

# Initialize database
db.init('task_manager.db')
db.connect()

# Clear existing data
print("Clearing existing data...")
Task.delete().execute()
Project.delete().execute()
Config.delete().where(Config.key.in_(['project_counter', 'global_task_counter'])).execute()

# Projects and tasks data
data = {
    'BLOBODORO': [
        ('0247', 'debugz'),
    ],
    'FASTING TRACKER': [
        ('0036', 'wrap in an a ndroid wrapper (iaw??)'),
        ('0346', 'reload clears everything wtf ftw'),
    ],
    'NBA CARD AUDIT': [
        ('0008', 'mark physical binder pages with potential card singles'),
        ('0418', 'get the camby card maybe validated or looked at?'),
    ],
    'UPWORK': [
        ('0251', 'bid for job at 13:30 10272025'),
    ],
    'NEXTCLOUD': [],
    'SSA DEPOSIT SWITCH': [
        ('0021', 'fix my.id log in??'),
    ],
    'CATALOG ANALYZER': [
        ('0052', 'deploy to vps again'),
        ('0053', 'make email work gud againz'),
    ],
    'DOMAIN LANDING': [
        ('0148', 'think about/work on finalizing trapezoid sky stone logo'),
        ('0150', 'figure out how to create a permanent logo base file (inkscape?)'),
    ],
    'ANCHOR': [
        ('0160', 'try to fight for 2021'),
    ],
    'DISPUTED FEES': [
        ('0163', 'bolt'),
        ('0164', 'booking'),
        ('0165', 'flixbus'),
        ('0166', 'print 0164 0163 0162 0165'),
    ],
    'COLLECTION THE GREATEST OCTOBER': [
        ('0208', 'preamble, the lead up, the disaster of theprevioous summer'),
        ('0209', 'the break on the horizon, the fast'),
        ('0210', 'seeds of the vision'),
        ('0211', 'building up; eyes opening'),
        ('0212', 'first blast off'),
        ('0213', 'the textual sequential tyranny & tumults'),
        ('0214', 'the trek to the source'),
        ('0215', 'salt water farraday; the pocket of peace'),
        ('0216', 'steady now'),
        ('0217', 'LIST PROJECTS'),
        ('0218', 'run inmpelemnted integration and ui/ux tests'),
    ],
    'COS OFFICE SOLUTIONS DATA BREACH CASE FOLLOW UP': [
        ('0419', 'trash hicks'),
    ],
    'TASKSWITCH': [
        ('0022', 'simple llm barebons pipelone to format and gather total time and make more better daily log reports'),
        ('0386', 'get a hangle on output logs'),
        ('0409', 'upload to pypi the fixed version'),
        ('0470', "add 'l' super short command; i.e., l 53"),
        ('0475', 'consider spacing shit'),
        ('0476', 'code base cleanup again'),
        ('0487', 'make chaining task feature where you can create task chain blocks with due dates!!!'),
        ('0488', 'unassigned tasks are no longer listed on list proj list'),
        ('0490', 'maybe format the ding alarm screen a little, get soem ideas on that'),
        ('0492', 'change the red alarmt little displaly to only display at the headline when an alarm is active, not for every task'),
        ('0493', 'make sure the alarm persists accross app shutdowns'),
        ('0494', 'make the clocks appear in the headline, "... date | [clock]" (ref 0493) but also, make it so you are able to set up to 3 alarms, and the first one or closest is a red clock, the second an orange clock, and the third a yellow clock; they are also displayed with the number of dings next to them!!!'),
        ('0496', "unhide by name odesn't werk"),
        ('0499', 'batch command shortcuts; anyting that start with list, do "lx", etc;'),
        ('0500', 'add task tack board maybe, aand then u r pickint tasks for the day like daily tacky'),
        ('0501', 'when switchin to break, it no is tell me how much i is spend on this u know but...is no good you know, so is bad'),
        ('0507', 'make current task highlighted in a subtle forest green , if the project is visible on the screen.'),
        ('0508', "make a newly added task clear itself from the confirmation liane after like 10 seconds, so i dont' have to clear screen everyt ime to look at a clean proj"),
        ('0510', "include an option on ding to input a quick summary or review of what you did befor e the ding, if you want to, and append that to the task number as a background descriptor that is only saved to db and shown in the daily log. and then maybe...we should have a command to display descriptions. i guess this is adding a very complex layer which would add task descriptions. ponder this"),
        ('0517', 'maybe is just ask, on ding, is good or is no goodd? for a simple sentiment check; is make, you know, maybe ding tied to task option??? maybe ideas'),
        ('0518', 'maybe add more little icons like the clock through, tastefully; is nice!'),
        ('0529', 'make a way to END projects, not just delete them bruh. some shits be gettin done nah mean'),
        ('0530', 'make way to make numbered but untitled projects disappear in the cli'),
        ('0532', 'add a blobodoro (randodoro) feature, and more louder noises/alarmos'),
        ('0533', 'add truncate project maybe (collapse uncollapse??)'),
        ('0534', 'make is truncate fucken tasks o one is no truncate proj omGOMF OMGMGMGMGOM'),
    ],
    'INFINITY FOLDERS': [
        ('0326', 'publish'),
        ('0370', 'the fuckin alphabetical folders it goes back after add wtf FIXIT'),
        ('0371', "the fuckin i can't read the fuck shit the whole file name folde rname when dading to cats whta the fuck"),
        ('0372', 'do the rename cats do the rename cats OMFG'),
        ('0373', 'Do the so when it is in folder it disapepar form list OMFG \\'),
        ('0376', 'make open all buttons WOAH'),
        ('0393', 'backup some how, the listsings?? how u do that'),
        ('0394', 'when you are s mall windows, all the convos they is apepars on gemin iside bar bro wtf NIGGER SHIT LSUT BITCH'),
    ],
    'BISTARAC': [
        ('0364', 'do the start do the review, get the plan ready'),
    ],
    'INVEST': [
        ('0382', 'research brokers, requirements, establish firm'),
        ('0383', 'finalize value prep / script / ta-lab?'),
    ],
    'BOOKNOTES REBIRTH': [
        ('0396', 'make is good!!! the best now!!'),
    ],
    'GEMINI NOTES': [
        ('0404', 'test !!!'),
    ],
    'FLUXUS NAPKINARY': [
        ('0531', 'do the fucken red dot linking bruh (phase fucken 4, b)'),
    ],
    'BIG LIFTS': [
        ('0463', 'consider glass containers for metrics, workign weight/reps and timer'),
        ('0464', 'consider glass container for bodyweight, lift list?'),
        ('0504', 'make the swipe actions more noticable'),
        ('0511', 'you should be able to access individual lift history from the start screen lift list; in the lift screen itself, the history/session record should bea ccessed by long pressing the metric zone NOT the lift name/headline.'),
        ('0512', 'i believe we need glass cards on the lift screen. implement those'),
        ('0513', 'must get the transitions in control and the sparkle noise on long press.'),
        ('0514', 'we need navigation animations between lifts.'),
        ('0515', 'gotta get the total package size/download size down.'),
        ('0516', 'figure out best way to create logos, iconss, etc. is make nice, tight baby'),
    ],
    'SPEEDING TICKETS': [
        ('0498', 'pay first fine'),
    ],
    'HAXBALL SERVER': [
        ('0495', 'get the headless thing going'),
        ('0497', 'ideateion'),
    ],
    'UNAMED EP': [
        ('0521', 'remaster/polish task0519 loop'),
    ],
    'SYSTEM WIDE LOGO REVAMP': [
        ('0524', 'redo all the logos for everything bro including infinty folders. go big, do it right. stick it to thte provaceturs who hate you for knowing whaty ou know'),
    ],
}

# Create projects and tasks
project_number = 1
max_task_id = 0

print("Creating projects and tasks...")
for project_name, tasks in data.items():
    # Create project
    proj_num = f"{project_number:03d}"
    project = Project.create(
        name=project_name,
        number=proj_num,
        is_priority=False,
        is_hidden=False,
        unhide_date=None
    )
    print(f"Created project: {project_name} ({proj_num})")
    project_number += 1
    
    # Create tasks
    for task_id, description in tasks:
        Task.create(
            task_id=task_id,
            description=description,
            project=project,
            status='open',
            completed_at=None,
            is_value=False,
            deadline=None
        )
        print(f"  - Task {task_id}: {description[:50]}...")
        
        # Track max task ID
        task_num = int(task_id)
        if task_num > max_task_id:
            max_task_id = task_num

# Set counters
Config.insert(key='project_counter', value=str(project_number - 1)).on_conflict(
    conflict_target=[Config.key],
    update={Config.value: str(project_number - 1)}
).execute()

Config.insert(key='global_task_counter', value=str(max_task_id)).on_conflict(
    conflict_target=[Config.key],
    update={Config.value: str(max_task_id)}
).execute()

print(f"\n✅ Database restored!")
print(f"   - {project_number - 1} projects")
print(f"   - {max_task_id} tasks")
print(f"   - Counters: project={project_number - 1}, task={max_task_id}")
