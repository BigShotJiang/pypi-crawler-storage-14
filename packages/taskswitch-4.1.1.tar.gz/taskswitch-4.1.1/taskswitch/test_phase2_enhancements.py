"""Test Phase 2 enhancements: state reload, retry logic, and validation.

This test validates:
1. State reload after critical operations ensures consistency
2. Retry logic handles transient timing issues
3. State validation detects and auto-corrects discrepancies
"""

import threading
import time
from pathlib import Path
import tempfile
import shutil

from taskswitch.db_state_manager import (
    load_state,
    add_project,
    add_task,
    get_task,
    validate_state_consistency,
    _set_config,
    _get_config,
)
from taskswitch.models import db, Project, Task, TimeEntry, Config


def test_state_reload_after_creation():
    """Verify state is reloaded from DB after project/task creation."""
    print("\n=== Test: State Reload After Creation ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        # Create first project (counter becomes 1)
        add_project(state, "TEST1")
        assert state['project_counter'] == 1, "First project should set counter to 1"
        
        # Manually set DB counter to simulate background save
        _set_config('project_counter', 5)
        
        # State dict still has old value
        print(f"Before second project: state={state['project_counter']}, DB={_get_config('project_counter')}")
        
        # Create second project (should reload and get DB value 5, then increment to 6)
        add_project(state, "TEST2")
        
        # Verify state was reloaded from database before incrementing
        # add_project reloads after creation, so state should match DB
        db_counter = int(_get_config('project_counter', 0))
        print(f"After second project: state={state['project_counter']}, DB={db_counter}")
        
        assert state['project_counter'] == db_counter, \
            f"State should match DB after reload, state={state['project_counter']}, db={db_counter}"
        
        print(f"✅ State reloaded from DB: counter={state['project_counter']}")
        
    finally:
        db.close()
        shutil.rmtree(temp_dir)


def test_retry_logic_for_task_queries():
    """Verify retry logic handles delayed task availability."""
    print("\n=== Test: Retry Logic for Task Queries ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        # Create project and task
        add_project(state, "TESTPROJ")
        task_id = add_task(state, "TESTPROJ", "Test task")
        
        # Task should be immediately available
        task = get_task(state, task_id)
        assert task is not None, "Task should be found immediately"
        assert task['id'] == task_id, f"Expected task {task_id}, got {task['id']}"
        
        print(f"✅ Task {task_id} found with retry logic")
        
        # Test non-existent task (should retry and fail gracefully)
        start_time = time.time()
        non_task = get_task(state, "9999")
        elapsed = time.time() - start_time
        
        assert non_task is None, "Non-existent task should return None"
        assert elapsed >= 0.15, f"Should have retried (elapsed={elapsed}s)"  # 0.05 + 0.1 = 0.15s minimum
        
        print(f"✅ Non-existent task handled gracefully (retried in {elapsed:.3f}s)")
        
    finally:
        db.close()
        shutil.rmtree(temp_dir)


def test_state_validation_auto_correction():
    """Verify state validation detects and corrects discrepancies."""
    print("\n=== Test: State Validation Auto-Correction ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        # Set DB counter to 10
        _set_config('project_counter', 10)
        _set_config('global_task_counter', 20)
        
        # Corrupt state dict (simulate race condition)
        state['project_counter'] = 5
        state['global_task_counter'] = 15
        
        print(f"Before validation: state counters = {state['project_counter']}, {state['global_task_counter']}")
        print(f"DB counters = {_get_config('project_counter')}, {_get_config('global_task_counter')}")
        
        # Validate should auto-correct
        result = validate_state_consistency(state)
        
        assert result is True, "Validation should succeed"
        assert state['project_counter'] == 10, \
            f"State should be corrected to DB value 10, got {state['project_counter']}"
        assert state['global_task_counter'] == 20, \
            f"State should be corrected to DB value 20, got {state['global_task_counter']}"
        
        print(f"After validation: state counters = {state['project_counter']}, {state['global_task_counter']}")
        print("✅ State validation auto-corrected discrepancies")
        
    finally:
        db.close()
        shutil.rmtree(temp_dir)


def test_concurrent_operations_with_validation():
    """Verify validation prevents counter drift in concurrent scenarios."""
    print("\n=== Test: Validation Prevents Counter Drift ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        # Simulate concurrent background save that updates counter
        def background_updates():
            for i in range(5):
                time.sleep(0.02)
                # Simulate randodoro worker updating counters
                current = int(_get_config('project_counter', 0))
                _set_config('project_counter', current + 1)
        
        bg_thread = threading.Thread(target=background_updates)
        bg_thread.start()
        
        # Create projects with validation
        for i in range(5):
            validate_state_consistency(state)  # Validate before each operation
            add_project(state, f"P{i}")
            time.sleep(0.03)
        
        bg_thread.join()
        
        # Verify final state is consistent
        validate_state_consistency(state)
        final_counter = state['project_counter']
        db_counter = int(_get_config('project_counter', 0))
        
        print(f"Final state counter: {final_counter}")
        print(f"Final DB counter: {db_counter}")
        
        assert final_counter == db_counter, \
            f"State and DB should match: state={final_counter}, db={db_counter}"
        
        print("✅ Validation prevented counter drift during concurrent operations")
        
    finally:
        db.close()
        shutil.rmtree(temp_dir)


if __name__ == '__main__':
    print("=" * 60)
    print("Phase 2 Enhancement Validation Tests")
    print("=" * 60)
    
    test_state_reload_after_creation()
    test_retry_logic_for_task_queries()
    test_state_validation_auto_correction()
    test_concurrent_operations_with_validation()
    
    print("\n" + "=" * 60)
    print("✅ ALL PHASE 2 TESTS PASSED")
    print("=" * 60)
