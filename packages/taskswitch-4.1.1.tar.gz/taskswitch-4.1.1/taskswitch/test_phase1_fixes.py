"""Test Phase 1 thread safety fixes.

This test validates:
1. Thread locks protect counter operations
2. Atomic transactions ensure database consistency
3. Duplicate save_state() calls removed
4. No race conditions during concurrent project/task creation
"""

import threading
import time
from pathlib import Path
import tempfile
import shutil
import os

from taskswitch.db_state_manager import (
    load_state,
    add_project,
    add_task,
    list_open_projects_and_tasks,
    save_state,
    _next_task_id,
    _get_config,
)
from taskswitch.models import db, Project, Task, TimeEntry, Config


def test_counter_thread_safety():
    """Verify _next_task_id is thread-safe with locks."""
    print("\n=== Test: Counter Thread Safety ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database by binding to new path
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        task_ids = []
        lock = threading.Lock()
        
        def create_task_id():
            tid = _next_task_id(state)
            with lock:
                task_ids.append(tid)
        
        # Create 20 threads that each get a task ID
        threads = []
        for _ in range(20):
            t = threading.Thread(target=create_task_id)
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
        
        # Verify all IDs are unique and sequential
        task_ids.sort()
        print(f"Generated {len(task_ids)} task IDs: {task_ids[:5]}...{task_ids[-5:]}")
        
        assert len(task_ids) == 20, f"Expected 20 IDs, got {len(task_ids)}"
        assert len(set(task_ids)) == 20, f"Duplicate IDs found: {task_ids}"
        
        # Verify they're sequential
        expected = list(range(int(task_ids[0]), int(task_ids[0]) + 20))
        assert task_ids == [str(x).zfill(4) for x in expected], "IDs not sequential"
        
        print("✅ Counter operations are thread-safe")
        
    finally:
        shutil.rmtree(temp_dir)


def test_concurrent_project_creation():
    """Verify project creation is atomic with no lost updates."""
    print("\n=== Test: Concurrent Project Creation ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        def create_projects(start_idx):
            """Create 5 projects from this thread."""
            for i in range(5):
                project_name = f"P{start_idx + i}"
                add_project(state, project_name)
                time.sleep(0.001)  # Small delay to encourage interleaving
        
        # Create 4 threads, each creating 5 projects (20 total)
        threads = []
        for i in range(4):
            t = threading.Thread(target=create_projects, args=(i * 5,))
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
        
        # Reload state from database to verify persistence
        state = load_state()
        inventory = list_open_projects_and_tasks(state)
        
        created_projects = list(inventory.keys())
        print(f"Created {len(created_projects)} projects: {sorted(created_projects)}")
        
        # Verify all 20 projects were created
        assert len(created_projects) == 20, f"Expected 20 projects, got {len(created_projects)}"
        
        # Verify no duplicates
        assert len(set(created_projects)) == 20, f"Duplicate projects found"
        
        # Verify project_counter is correct
        final_counter = state['project_counter']
        print(f"Final project_counter: {final_counter}")
        assert final_counter == 20, f"Expected counter=20, got {final_counter}"
        
        print("✅ Concurrent project creation is atomic")
        
    finally:
        shutil.rmtree(temp_dir)


def test_concurrent_task_creation():
    """Verify task creation is atomic with correct task IDs."""
    print("\n=== Test: Concurrent Task Creation ===")
    
    # Create temp database
    temp_dir = tempfile.mkdtemp()
    db_path = Path(temp_dir) / "test.db"
    
    try:
        # Initialize database
        db.init(str(db_path))
        db.connect()
        db.create_tables([Project, Task, TimeEntry, Config])
        
        state = load_state()
        
        # Create a project first
        add_project(state, "TESTPROJ")
        
        task_ids = []
        lock = threading.Lock()
        
        def create_tasks(start_idx):
            """Create 5 tasks from this thread."""
            for i in range(5):
                tid = add_task(state, "TESTPROJ", f"Task {start_idx + i}")
                with lock:
                    task_ids.append(tid)
                time.sleep(0.001)
        
        # Create 4 threads, each creating 5 tasks (20 total)
        threads = []
        for i in range(4):
            t = threading.Thread(target=create_tasks, args=(i * 5,))
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
        
        # Reload state from database
        state = load_state()
        inventory = list_open_projects_and_tasks(state)
        
        # Get tasks from inventory
        project_tasks = inventory.get('TESTPROJ', [])
        print(f"Created {len(project_tasks)} tasks with IDs: {sorted([t['id'] for t in project_tasks])}")
        
        # Verify all 20 tasks were created
        assert len(project_tasks) == 20, f"Expected 20 tasks, got {len(project_tasks)}"
        
        # Verify no duplicate task IDs
        task_id_set = set(t['id'] for t in project_tasks)
        assert len(task_id_set) == 20, f"Duplicate task IDs found"
        
        # Verify task_counter is correct
        final_counter = state['global_task_counter']
        print(f"Final global_task_counter: {final_counter}")
        assert final_counter == 20, f"Expected counter=20, got {final_counter}"
        
        print("✅ Concurrent task creation is atomic")
        
    finally:
        shutil.rmtree(temp_dir)


def test_no_double_saves():
    """Verify add_project and add_priority don't call save_state."""
    print("\n=== Test: No Double save_state() Calls ===")
    
    # Read the source code to verify save_state was removed
    import inspect
    
    # Check add_project
    add_project_source = inspect.getsource(add_project)
    assert 'save_state(state)' not in add_project_source, \
        "add_project still contains save_state() call"
    print("✅ add_project does not call save_state()")
    
    # Check add_priority (imported separately)
    from taskswitch.db_state_manager import add_priority
    add_priority_source = inspect.getsource(add_priority)
    assert 'save_state(state)' not in add_priority_source, \
        "add_priority still contains save_state() call"
    print("✅ add_priority does not call save_state()")


def test_atomic_transactions():
    """Verify database operations use atomic transactions."""
    print("\n=== Test: Atomic Transactions ===")
    
    import inspect
    
    # Check add_project uses db.atomic()
    add_project_source = inspect.getsource(add_project)
    assert 'with db.atomic():' in add_project_source, \
        "add_project does not use db.atomic()"
    print("✅ add_project uses atomic transaction")
    
    # Check add_task uses db.atomic()
    add_task_source = inspect.getsource(add_task)
    assert 'with db.atomic():' in add_task_source, \
        "add_task does not use db.atomic()"
    print("✅ add_task uses atomic transaction")


if __name__ == '__main__':
    print("=" * 60)
    print("Phase 1 Thread Safety Validation Tests")
    print("=" * 60)
    
    test_no_double_saves()
    test_atomic_transactions()
    test_counter_thread_safety()
    test_concurrent_project_creation()
    test_concurrent_task_creation()
    
    print("\n" + "=" * 60)
    print("✅ ALL PHASE 1 TESTS PASSED")
    print("=" * 60)
