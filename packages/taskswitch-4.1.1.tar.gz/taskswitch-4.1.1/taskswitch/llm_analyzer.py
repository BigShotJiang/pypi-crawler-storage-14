"""LLM-powered daily log analysis using Mistral AI.

This module provides functionality to analyze daily time tracking logs
using Mistral's API to generate insights about productivity patterns,
focus time, project momentum, and actionable suggestions.
"""

import os
from typing import Dict, Optional, Tuple
from datetime import date

try:
    from mistralai import Mistral
except ImportError:
    Mistral = None

from .logging_config import get_logger

logger = get_logger(__name__)


class LLMAnalyzer:
    """Handles LLM-based analysis of daily logs using Mistral API."""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize the LLM analyzer.
        
        Args:
            api_key: Mistral API key. If None, will try to load from config or environment.
        """
        self.api_key = api_key or self._load_api_key()
        self.client = None
        
        if self.api_key and Mistral:
            try:
                self.client = Mistral(api_key=self.api_key)
            except Exception as e:
                logger.error(f"Failed to initialize Mistral client: {e}")
    
    def _load_api_key(self) -> Optional[str]:
        """Load Mistral API key from config or environment.
        
        Priority order:
        1. MISTRAL_API_KEY environment variable
        2. ~/.config/taskswitch/mistral_key
        3. Project config.yaml api_key_file setting
        
        Returns:
            API key string or None if not found.
        """
        # Try environment variable first
        api_key = os.environ.get('MISTRAL_API_KEY')
        if api_key:
            return api_key
        
        # Try user config directory
        user_config_dir = os.path.expanduser('~/.config/taskswitch')
        user_key_file = os.path.join(user_config_dir, 'mistral_key')
        if os.path.exists(user_key_file):
            try:
                with open(user_key_file, 'r') as f:
                    api_key = f.read().strip()
                    if api_key:
                        return api_key
            except Exception as e:
                logger.debug(f"Could not read user config key: {e}")
        
        # Try loading from project config
        try:
            from .config_manager import get_cached_config
            config = get_cached_config()
            api_key_path = config.get('llm', {}).get('api_key_file')
            if api_key_path:
                # Handle both absolute and relative paths
                if not os.path.isabs(api_key_path):
                    # Assume relative to project root
                    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                    api_key_path = os.path.join(project_root, api_key_path)
                
                if os.path.exists(api_key_path):
                    with open(api_key_path, 'r') as f:
                        return f.read().strip()
        except Exception as e:
            logger.debug(f"Could not load API key from config: {e}")
        
        return None
    
    def is_available(self) -> bool:
        """Check if LLM analysis is available.
        
        Returns:
            True if Mistral client is initialized and ready.
        """
        return self.client is not None and Mistral is not None
    
    def analyze_daily_log(self, log_content: str, analysis_date: date) -> Tuple[bool, str]:
        """Analyze a daily log and generate insights.
        
        Args:
            log_content: The enhanced daily log content formatted for LLM analysis.
            analysis_date: The date being analyzed.
        
        Returns:
            Tuple of (success: bool, result: str) where result is either
            the analysis text or an error message.
        """
        if not self.is_available():
            return False, "❌ LLM analysis not available. Install mistralai package and configure API key."
        
        try:
            # Craft the analysis prompt
            prompt = self._create_analysis_prompt(log_content, analysis_date)
            
            # Call Mistral API
            response = self.client.chat.complete(
                model="mistral-small-latest",  # Good balance of speed and quality
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,  # Some creativity but mostly factual
                max_tokens=500,   # Keep it concise
            )
            
            # Extract the response
            if response and response.choices:
                analysis = response.choices[0].message.content.strip()
                return True, analysis
            else:
                return False, "❌ No response from Mistral API"
                
        except Exception as e:
            logger.error(f"LLM analysis failed: {e}")
            return False, f"❌ Analysis error: {str(e)}"
    
    def _create_analysis_prompt(self, log_content: str, analysis_date: date) -> str:
        """Create the prompt for Mistral analysis.
        
        Args:
            log_content: The enhanced daily log content.
            analysis_date: The date being analyzed.
        
        Returns:
            Formatted prompt string.
        """
        day_name = analysis_date.strftime("%A")
        
        prompt = f"""You are analyzing a developer's time tracking log for {analysis_date.isoformat()} ({day_name}).

Your job: Provide BRIEF, DIRECT insights. No fluff. Be casual but useful.

Focus on:
1. Focus patterns - Deep work vs task hopping? Context switching excessive?
2. Project momentum - What's gaining traction? What's stalling?
3. Energy/rhythm - Productive hours, break patterns, work session quality
4. Actionable insights - 2-3 specific suggestions based on the data

Keep response under 250 words. Use bullet points. Be honest - if the day was scattered, say it.

Here's the log:

{log_content}

Provide your analysis:"""
        
        return prompt


# Singleton instance
_analyzer_instance: Optional[LLMAnalyzer] = None


def get_analyzer() -> LLMAnalyzer:
    """Get or create the singleton LLM analyzer instance.
    
    Returns:
        LLMAnalyzer instance.
    """
    global _analyzer_instance
    if _analyzer_instance is None:
        _analyzer_instance = LLMAnalyzer()
    return _analyzer_instance


def save_api_key(api_key: str) -> Tuple[bool, str]:
    """Save API key to user config directory.
    
    Args:
        api_key: The Mistral API key to save.
    
    Returns:
        Tuple of (success: bool, message: str)
    """
    try:
        # Create config directory if it doesn't exist
        config_dir = os.path.expanduser('~/.config/taskswitch')
        os.makedirs(config_dir, exist_ok=True)
        
        # Write key to file
        key_file = os.path.join(config_dir, 'mistral_key')
        with open(key_file, 'w') as f:
            f.write(api_key.strip())
        
        # Set restrictive permissions (user read/write only)
        os.chmod(key_file, 0o600)
        
        return True, f"✓ API key saved to {key_file}"
    except Exception as e:
        return False, f"❌ Failed to save API key: {e}"


def prompt_for_api_key() -> Optional[str]:
    """Interactively prompt user for Mistral API key.
    
    Returns:
        API key string if provided, None if skipped.
    """
    print("\n" + "═" * 70)
    print("  MISTRAL API KEY SETUP")
    print("═" * 70)
    print()
    print("To use AI-powered analysis, you need a Mistral API key.")
    print()
    print("Get a FREE key at: https://console.mistral.ai")
    print("  1. Sign up (free)")
    print("  2. Go to API Keys section")
    print("  3. Create a new key")
    print()
    print("Your key will be saved to ~/.config/taskswitch/mistral_key")
    print()
    
    try:
        api_key = input("Enter your Mistral API key (or press Enter to skip): ").strip()
        
        if not api_key:
            print("\n⚠️  Skipped. You can set it later with MISTRAL_API_KEY env var.")
            return None
        
        # Basic validation (Mistral keys start with alphanumeric)
        if len(api_key) < 20:
            print("\n⚠️  That doesn't look like a valid API key (too short).")
            return None
        
        # Save the key
        success, msg = save_api_key(api_key)
        print(f"\n{msg}")
        
        if success:
            # Clear the cached analyzer instance so it gets reinitialized
            global _analyzer_instance
            _analyzer_instance = None
            return api_key
        
        return None
        
    except (KeyboardInterrupt, EOFError):
        print("\n\n⚠️  Setup cancelled.")
        return None

