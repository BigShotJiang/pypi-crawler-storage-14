"""Randodoro timer system - dynamic random work/rest intervals.

This module implements a sophisticated randomized pomodoro timer with three
commitment tiers and proportional rest periods. Unlike traditional pomodoro,
both work AND rest periods are randomized within constrained ranges to ensure
fairness and adequate recovery.

Features gentle transition tones that gradually fade in 13-17 seconds before
each phase ends, creating a peaceful, mindful transition experience.
"""
import random
import threading
import time
from datetime import datetime
from typing import Optional, Tuple

import pytz

from .logging_config import get_timer_logger
from .utils import _get_tz, clear_screen

# Get logger for randodoro operations
logger = get_timer_logger()

# Commitment tier boundaries (in seconds)
SHORT_MIN = 780   # 13 minutes
SHORT_MAX = 1080  # 18 minutes
MEDIUM_MIN = 1140  # 19 minutes
MEDIUM_MAX = 2220  # 37 minutes
LONG_MIN = 2280   # 38 minutes
LONG_MAX = 2820   # 47 minutes

# Work:Rest ratio ranges for each tier
SHORT_RATIO_MIN = 3.3
SHORT_RATIO_MAX = 4.8
MEDIUM_RATIO_MIN = 2.8
MEDIUM_RATIO_MAX = 3.9
LONG_RATIO_MIN = 2.1
LONG_RATIO_MAX = 2.9


def _format_seconds_mmss(seconds: float) -> str:
    """Format seconds as mm:ss.
    
    Args:
        seconds: Number of seconds
        
    Returns:
        Formatted string in mm:ss format
    """
    total_secs = int(seconds)
    mins = total_secs // 60
    secs = total_secs % 60
    return f"{mins:02d}:{secs:02d}"


def _generate_random_work_time() -> int:
    """Generate a random work time avoiding gaps between tiers.
    
    Generates a work time in one of three ranges with weighted distribution:
    - SHORT: 780-1080s (13-18 min) - 20% probability
    - MEDIUM: 1140-2220s (19-37 min) - 60% probability (most common)
    - LONG: 2280-2820s (38-47 min) - 20% probability
    
    Explicitly avoids gaps: 1081-1139s and 2221-2279s
    
    Returns:
        Random work time in seconds
    """
    # Choose a tier with weighted probability: 20% SHORT, 60% MEDIUM, 20% LONG
    tier = random.choices(['SHORT', 'MEDIUM', 'LONG'], weights=[20, 60, 20], k=1)[0]
    
    if tier == 'SHORT':
        work_time = random.randint(SHORT_MIN, SHORT_MAX)
        logger.debug(f"Generated SHORT work time: {work_time}s ({_format_seconds_mmss(work_time)})")
    elif tier == 'MEDIUM':
        work_time = random.randint(MEDIUM_MIN, MEDIUM_MAX)
        logger.debug(f"Generated MEDIUM work time: {work_time}s ({_format_seconds_mmss(work_time)})")
    else:  # LONG
        work_time = random.randint(LONG_MIN, LONG_MAX)
        logger.debug(f"Generated LONG work time: {work_time}s ({_format_seconds_mmss(work_time)})")
    
    return work_time


def _calculate_rest_time(work_time: int) -> int:
    """Calculate rest time based on work time and commitment tier.
    
    Args:
        work_time: Work time in seconds
        
    Returns:
        Rest time in seconds based on randomized ratio
    """
    # Determine tier and ratio range
    if SHORT_MIN <= work_time <= SHORT_MAX:
        ratio = random.uniform(SHORT_RATIO_MIN, SHORT_RATIO_MAX)
        tier = "SHORT"
    elif MEDIUM_MIN <= work_time <= MEDIUM_MAX:
        ratio = random.uniform(MEDIUM_RATIO_MIN, MEDIUM_RATIO_MAX)
        tier = "MEDIUM"
    elif LONG_MIN <= work_time <= LONG_MAX:
        ratio = random.uniform(LONG_RATIO_MIN, LONG_RATIO_MAX)
        tier = "LONG"
    else:
        # Fallback (should never happen with proper work_time generation)
        ratio = 3.0
        tier = "UNKNOWN"
        logger.warning(f"Work time {work_time}s outside expected ranges, using default ratio")
    
    rest_time = int(work_time / ratio)
    logger.debug(f"Calculated {tier} rest time: {rest_time}s ({_format_seconds_mmss(rest_time)}) with ratio {ratio:.2f}:1")
    
    return rest_time


class RandodoroManager:
    """Manages randodoro work/rest cycles with automatic task switching."""
    
    def __init__(self):
        """Initialize the randodoro manager."""
        self.active_randodoro: Optional[threading.Thread] = None
        self.randodoro_cancelled = False
        self.shell_ref = None  # Reference to shell for prompt updates
        self.state_ref = None  # Reference to state for task switching
        self.current_phase = None  # 'work' or 'rest'
        self.work_time = 0
        self.rest_time = 0
        self.last_task_before_rest = None  # Store task to resume after rest
        self.cycles_completed = 0  # Track completed cycles
        self.previous_work_time = 0  # Track previous cycle work time for display
        self.previous_rest_time = 0  # Track previous cycle rest time for display
        self.state_lock = threading.Lock()  # Protect state modifications from race conditions
    
    def start_randodoro(self, state: dict, shell_ref=None) -> Tuple[bool, str]:
        """Start a new randodoro cycle.
        
        Args:
            state: State dictionary for task switching
            shell_ref: Reference to shell instance for updating prompt
            
        Returns:
            tuple: (success: bool, message: str)
        """
        # If already running, stop it (toggle behavior)
        if self.is_randodoro_active():
            return self.stop_randodoro()
        
        # Reset state
        self.randodoro_cancelled = False
        self.shell_ref = shell_ref
        self.state_ref = state
        self.current_phase = 'work'
        self.last_task_before_rest = None
        
        # Generate random work and rest times
        self.work_time = _generate_random_work_time()
        self.rest_time = _calculate_rest_time(self.work_time)
        
        logger.info(f"Starting randodoro: work={_format_seconds_mmss(self.work_time)}, rest={_format_seconds_mmss(self.rest_time)}")
        
        # Save randodoro enabled state for persistence
        if state:
            with self.state_lock:
                from .db_state_manager import save_state
                state['randodoro_enabled'] = True
                save_state(state)
        
        # Start randodoro in background thread
        self.active_randodoro = threading.Thread(
            target=self._randodoro_worker,
            daemon=True
        )
        self.active_randodoro.start()
        
        return True, "🎲 Randodoro started"
    
    def stop_randodoro(self) -> Tuple[bool, str]:
        """Stop the currently active randodoro.
        
        Returns:
            tuple: (success: bool, message: str)
        """
        if not self.is_randodoro_active():
            return False, "No active randodoro to stop"
        
        self.randodoro_cancelled = True
        self.active_randodoro = None
        
        # Clear randodoro enabled state
        if self.state_ref:
            with self.state_lock:
                from .db_state_manager import save_state
                self.state_ref['randodoro_enabled'] = False
                save_state(self.state_ref)
        
        cycles_msg = f" ({self.cycles_completed} cycle{'s' if self.cycles_completed != 1 else ''} completed)" if self.cycles_completed > 0 else ""
        logger.info(f"Randodoro stopped{cycles_msg}")
        
        return True, f"🎲 Randodoro stopped{cycles_msg}"
    
    def _randodoro_worker(self) -> None:
        """Background worker that manages work/rest cycles."""
        while not self.randodoro_cancelled:
            # Store current cycle times for logging
            current_work_time = self.work_time
            current_rest_time = self.rest_time
            
            logger.info(f"=== NEW CYCLE START ===")
            logger.info(f"Will use: work={_format_seconds_mmss(current_work_time)} ({current_work_time}s), rest={_format_seconds_mmss(current_rest_time)} ({current_rest_time}s)")
            
            # WORK PERIOD
            self.current_phase = 'work'
            logger.info(f"Randodoro work period started: {_format_seconds_mmss(current_work_time)}")
            
            # Calculate when to play gentle transition tone (13-17 seconds before end)
            import random
            warning_offset = random.randint(13, 17)
            sleep_before_warning = max(0, current_work_time - warning_offset)
            
            # Sleep until warning time
            if sleep_before_warning > 0:
                time.sleep(sleep_before_warning)
            
            if self.randodoro_cancelled:
                return
            
            # Play gentle transition tone in background
            if not self.randodoro_cancelled:
                actual_tone_duration = min(warning_offset, current_work_time)
                self._play_gentle_tone_async(actual_tone_duration)
                
                # Sleep for remaining time (tone plays in background)
                remaining_time = current_work_time - sleep_before_warning
                if remaining_time > 0:
                    time.sleep(remaining_time)
            
            if self.randodoro_cancelled:
                return
            
            # Work period ended - display transition (no harsh alarm)
            logger.info(f"Work period complete after {current_work_time}s")
            self._show_randodoro_transition('work', current_work_time)
            self._switch_to_rest()
            
            # REST PERIOD
            self.current_phase = 'rest'
            logger.info(f"Randodoro rest period started: {_format_seconds_mmss(current_rest_time)}")
            
            # Calculate when to play gentle transition tone (13-17 seconds before end)
            import random
            warning_offset = random.randint(13, 17)
            sleep_before_warning = max(0, current_rest_time - warning_offset)
            
            # Sleep until warning time
            if sleep_before_warning > 0:
                time.sleep(sleep_before_warning)
            
            if self.randodoro_cancelled:
                return
            
            # Play gentle transition tone in background
            if not self.randodoro_cancelled:
                actual_tone_duration = min(warning_offset, current_rest_time)
                self._play_gentle_tone_async(actual_tone_duration)
                
                # Sleep for remaining time (tone plays in background)
                remaining_time = current_rest_time - sleep_before_warning
                if remaining_time > 0:
                    time.sleep(remaining_time)
            
            if self.randodoro_cancelled:
                return
            
            # Rest period ended - display transition (no harsh alarm)
            # Store previous times BEFORE displaying so they're available for the message
            self.previous_work_time = current_work_time
            self.previous_rest_time = current_rest_time
            logger.info(f"Rest period complete after {current_rest_time}s")
            self._show_randodoro_transition('rest', current_rest_time)
            self._resume_last_task()
            
            # Cycle completed
            self.cycles_completed += 1
            logger.info(f"Randodoro cycle completed (total: {self.cycles_completed})")
            
            # Record cycle completion in state for daily summary
            if self.state_ref:
                with self.state_lock:
                    from .db_state_manager import save_state
                    tz = _get_tz()
                    cycle_record = {
                        'completed_at': datetime.now(tz).isoformat(),
                        'work_seconds': current_work_time,
                        'rest_seconds': current_rest_time,
                    }
                    randodoro_cycles = self.state_ref.setdefault('randodoro_cycles', [])
                    randodoro_cycles.append(cycle_record)
                    save_state(self.state_ref)
            
            # Generate new random times for next cycle
            self.work_time = _generate_random_work_time()
            self.rest_time = _calculate_rest_time(self.work_time)
            logger.info(f"Generated NEXT cycle times: work={_format_seconds_mmss(self.work_time)} ({self.work_time}s), rest={_format_seconds_mmss(self.rest_time)} ({self.rest_time}s)")
            logger.info(f"=== CYCLE END ===\n")
    
    def _play_gentle_tone_async(self, duration: float) -> None:
        """Play gentle transition tone in a background thread.
        
        Args:
            duration: Duration of the tone in seconds
        """
        from .alarm import _play_gentle_transition_tone
        
        def play_tone():
            try:
                _play_gentle_transition_tone(duration)
            except Exception as e:
                logger.warning(f"Failed to play gentle tone: {e}")
        
        tone_thread = threading.Thread(target=play_tone, daemon=True)
        tone_thread.start()
    
    def _show_randodoro_transition(self, phase: str, duration: int) -> None:
        """Display a simple one-line transition message for work or rest period completion.
        
        No times shown - only announces completion and phase transitions.
        
        Args:
            phase: 'work' or 'rest'
            duration: Duration of the completed period in seconds
        """
        tz = _get_tz()
        current_time = datetime.now(tz).strftime("%H:%M:%S")
        
        # Simple messages with no time durations
        if phase == 'work':
            # Just completed work, starting rest
            print(f"\n∿ Randodoro [{current_time}] - Work period complete")
            print(f"🎲 ☕ Randodoro rest")
        else:  # rest
            # Just completed rest, cycle is done, starting new work
            print(f"\n∿ Randodoro [{current_time}] - Rest period complete")
            print(f"∿ Randodoro cycle completed")
            print(f"🎲 💼 Randodoro work")
        
        # Update shell prompt if reference exists and display it
        if self.shell_ref:
            try:
                self.shell_ref.prompt = self.shell_ref._get_prompt()
                # Display the updated prompt after transition
                print(self.shell_ref.prompt, end='', flush=True)
            except Exception:
                pass
    
    def _switch_to_rest(self) -> None:
        """Switch to REST task for randodoro rest period.
        
        Stores the current active task (if any) to resume after rest.
        Uses REST instead of BREAK to separate randodoro rest from manual breaks.
        """
        if not self.state_ref:
            return
        
        with self.state_lock:
            # Don't switch to REST if already in REST (prevents restart during manual task switches)
            current_task = self.state_ref.get("active_task")
            if current_task == "REST":
                logger.debug("Already in REST mode, skipping switch to prevent timer restart")
                return
            
            # Store the current task to resume later (but only if it's not BREAK)
            if current_task and current_task != "BREAK":
                self.last_task_before_rest = current_task
                logger.debug(f"Stored task to resume after rest: {current_task}")
            
            # Finalize current task and switch to REST
            from .timer import finalize_current_task_time
            finalize_current_task_time(self.state_ref)
            self.state_ref["active_task"] = "REST"
            self.state_ref["start_time"] = datetime.now(pytz.utc)
            self.state_ref.setdefault("task_times", [])
            from .db_state_manager import save_state
            save_state(self.state_ref)
            logger.info("Switched to REST for randodoro rest period")
    
    def _resume_last_task(self) -> None:
        """Resume the last task that was active before the rest period.
        
        If there was no task before rest, just finalize the REST.
        """
        if not self.state_ref:
            return
        
        with self.state_lock:
            from .timer import finalize_current_task_time
            from .db_state_manager import save_state
            
            # Finalize the REST period
            finalize_current_task_time(self.state_ref)
            
            # If there was a task before rest, resume it
            if self.last_task_before_rest:
                self.state_ref["active_task"] = self.last_task_before_rest
                self.state_ref["start_time"] = datetime.now(pytz.utc)
                save_state(self.state_ref)
                logger.info(f"Resumed task after rest: {self.last_task_before_rest}")
            else:
                # No task to resume, just clear active task
                self.state_ref["active_task"] = None
                self.state_ref["start_time"] = None
                save_state(self.state_ref)
                logger.info("No task to resume after rest (continuing without active task)")
    
    def is_randodoro_active(self) -> bool:
        """Check if randodoro is currently active.
        
        Returns:
            bool: True if randodoro is running
        """
        return self.active_randodoro is not None and self.active_randodoro.is_alive()
    
    def get_state_lock(self):
        """Get the state lock for thread-safe state modifications.
        
        Returns:
            threading.Lock: The state lock
        """
        return self.state_lock
    
    def get_randodoro_info(self) -> Optional[str]:
        """Get information about the active randodoro.
        
        Returns:
            str: Info string if randodoro is active, None otherwise
        """
        if self.is_randodoro_active():
            phase_emoji = "💼" if self.current_phase == 'work' else "☕"
            return f"🎲 {phase_emoji} Randodoro {self.current_phase}"
        return None


# Global randodoro manager instance
_randodoro_manager = RandodoroManager()


def get_randodoro_manager() -> RandodoroManager:
    """Get the global randodoro manager instance.
    
    Returns:
        RandodoroManager: The global randodoro manager
    """
    return _randodoro_manager
