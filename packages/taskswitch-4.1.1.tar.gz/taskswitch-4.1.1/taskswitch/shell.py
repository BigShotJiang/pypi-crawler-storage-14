#!/usr/bin/env python3
"""Interactive shell interface using cmd.Cmd for the time tracker application.

This module provides TaskSwitchShell, a cmd.Cmd-based interactive command-line
interface that preserves the original ambiguous input style while providing
a robust command processing framework.
"""
import cmd
from datetime import datetime

import pytz
from colorama import init as colorama_init

from .commands import (
    create_and_switch_task_for_project,
    handle_add_priority,
    handle_add_project,
    handle_add_task,
    handle_analyze,
    handle_analyze_week,
    handle_cancel_ding,
    handle_clear_screen,
    handle_clear_task_deadline,
    handle_delete_project,
    handle_delete_project_by_number,
    handle_delete_task,
    handle_ding,
    handle_end_day,
    handle_end_project,
    handle_end_project_by_number,
    handle_end_tasks,
    handle_force_summary,
    handle_hide_project,
    handle_list_hide,
    handle_list_priority,
    handle_list_projects,
    handle_list_single_project,
    handle_list_tasks,
    handle_project_as_task,
    handle_rando,
    handle_rename_project,
    handle_set_task_deadline,
    handle_start_task,
    handle_start_text_task,
    handle_task_shorthand,
    handle_toggle_single_task_description,
    handle_toggle_task_descriptions,
    handle_toggle_task_value,
    handle_unhide_project,
)
from .display import _format_task_display
from .reporting import check_and_summarize_if_needed
from .db_state_manager import load_state  # Using database backend
from .types import State
from .utils import _get_tz

# Initialize colorama for cross-platform colored output
colorama_init(autoreset=True)

# Import version
from . import __version__


class TaskSwitchShell(cmd.Cmd):
    """Interactive shell for time tracking using cmd.Cmd framework.

    This shell provides both explicit commands (via do_* methods) and ambiguous
    input handling (via default() method) to maintain the flexible input style
    of the original tracker while leveraging cmd.Cmd's robust parsing.

    Attributes:
        intro (str): Welcome message displayed at shell startup.
        prompt (str): Dynamic prompt showing current task status.
        state (State): Application state dictionary.
    """

    # intro is now set dynamically in __init__

    def __init__(self):
        """Initialize the shell, load state, and check for pending summaries."""
        super().__init__()
        self.state = load_state()
        check_and_summarize_if_needed(self.state)
        
        # Track last project used with ADD ## TASK for sticky mode
        self.sticky_project = None
        
        # Generate dynamic intro with current date
        tz = _get_tz()
        current_date = datetime.now(tz)
        date_str = current_date.strftime("%B %d, %Y")
        
        # Initialize header line tracking
        self.header_line_count = 6  # Number of lines in header (including alarm line)
        
        self.intro = f"""
▄▄▄▄▄▄ ▄▄▄   ▄▄▄▄ ▄▄ ▄▄  ▄▄▄▄ ▄▄   ▄▄ ▄▄ ▄▄▄▄▄▄ ▄▄▄▄ ▄▄ ▄▄ 
  ██  ██▀██ ███▄▄ ██▄█▀ ███▄▄ ██ ▄ ██ ██   ██  ██▀▀▀ ██▄██ 
  ██  ██▀██ ▄▄██▀ ██ ██ ▄▄██▀  ▀█▀█▀  ██   ██  ▀████ ██ ██ 

taskswitch | time, task, timeline; zero friction | {date_str}
Type 'LIST COMMANDS' for help
"""
        
        # Check if this is the first startup of the day and auto-start MORNING ROUTINE
        self._check_and_start_morning_routine(current_date)
        
        # Restore randodoro if it was active
        self._restore_randodoro_if_enabled()
        
        # Set initial prompt
        self.prompt = self._get_prompt()
    
    def _restore_randodoro_if_enabled(self) -> None:
        """Restore randodoro if it was enabled when shell last closed."""
        try:
            if self.state.get('randodoro_enabled'):
                from .randodoro import get_randodoro_manager
                manager = get_randodoro_manager()
                success, msg = manager.start_randodoro(self.state, shell_ref=self)
                if success:
                    print(f"∿ {msg} (restored from previous session)")
                else:
                    # Failed to start, clear the flag
                    self.state['randodoro_enabled'] = False
                    from .db_state_manager import save_state
                    save_state(self.state)
        except Exception as e:
            # If restoration fails, clear the flag and log the error
            print(f"Warning: Failed to restore randodoro: {e}")
            self.state['randodoro_enabled'] = False
            from .db_state_manager import save_state
            save_state(self.state)

    def _check_and_start_morning_routine(self, current_date: datetime) -> None:
        """Check if this is first startup of the day and start MORNING ROUTINE if so.
        
        Args:
            current_date: Current datetime in configured timezone
        """
        # Check if there's already an active task
        if self.state.get("active_task"):
            return
        
        # Check if there are any time entries today
        task_times = self.state.get("task_times", [])
        if task_times:
            # Get the most recent entry
            last_entry = task_times[-1]
            end_timestamp_str = last_entry.get("end_timestamp")
            if end_timestamp_str:
                try:
                    end_dt = datetime.fromisoformat(end_timestamp_str.replace("Z", "+00:00"))
                    tz = _get_tz()
                    end_dt_local = end_dt.astimezone(tz)
                    # If last entry was today, don't start MORNING ROUTINE
                    if end_dt_local.date() == current_date.date():
                        return
                except Exception:
                    pass
        
        # No active task and no entries today - start MORNING ROUTINE
        self.state["active_task"] = "MORNING ROUTINE"
        self.state["start_time"] = datetime.now(pytz.utc)
        self.state.setdefault("task_times", [])
        from .db_state_manager import save_state
        save_state(self.state)
        
        # Add a note to the intro
        self.intro = self.intro.rstrip() + "\n\n🌅 Started MORNING ROUTINE\n"

    def parseline(self, line: str):
        """Parse the line into command name and a string containing the arguments.
        
        Override to make commands case-insensitive by uppercasing the command word.
        """
        line = line.strip()
        if not line:
            return None, None, line
        elif line[0] == '?':
            line = 'help ' + line[1:]
        elif line[0] == '!':
            if hasattr(self, 'do_shell'):
                line = 'shell ' + line[1:]
            else:
                return None, None, line
        
        # Split into command and args
        i, n = 0, len(line)
        while i < n and line[i] in self.identchars:
            i = i + 1
        cmd, arg = line[:i], line[i:].strip()
        
        # Uppercase the command for case-insensitive matching
        return cmd.upper(), arg, line

    def _show_command_help(self) -> None:
        """Display comprehensive command reference."""
        help_text = """
═══════════════════════════════════════════════════════════════════════════
                            COMMAND REFERENCE
═══════════════════════════════════════════════════════════════════════════

PROJECT MANAGEMENT
──────────────────────────────────────────────────────────────────────────
  ADD PROJECT <Name>              Create new project
  ADD ### TASK <Description>      Add task by project number
  END ### [### ...]               End one or more projects
  DELETE ### [### ...]            Delete one or more projects
  HIDE <Name> [UNTIL mmdd]        Hide project (optionally until date)
  UNHIDE <Name>                   Unhide project
  RENAME <OldName|###> <NewName>  Rename a project

PRIORITY MANAGEMENT
──────────────────────────────────────────────────────────────────────────
  ADD PRIORITY ### [### ...]      Add projects to priority (max 3)
  END PRIORITY ###                Remove from priority list
  LIST PRIORITY (or LIST PRI)     View priority projects
  LR                              Shortcut for LIST PRIORITY

TASK MANAGEMENT
──────────────────────────────────────────────────────────────────────────
  ####                            Start/resume task by ID
  <text>                          Start projectless task (auto-assigns ID)
  TASK <Description>              Add task to last active project
  MOVE #### ###                   Move task to different project
  END #### [#### ...]             End one or more tasks
  DELETE #### [#### ...]          Delete one or more tasks
  #### !!!                        Flag task as high-value
  #### mmdd                       Set task deadline (year optional: mmddyyyy)
  CLEAR #### DUE                  Clear task deadline
  
  Note: Include mmdd or mmddyyyy in task description to set deadline on creation

VIEWING
──────────────────────────────────────────────────────────────────────────
  LIST PROJECTS (or LIST PROJ)    View all projects and tasks
  LP                              Shortcut for LIST PROJECTS
  LIST PROJ ###                   View single project
  ###                             Quick switch to project view
  LIST ### or ###                 Toggle full/truncated task descriptions
                                  for entire project (Tasks truncate at 65 chars)
  LIST ####                       Toggle full/truncated description for
                                  specific task by ID (persists across views)
  LIST HIDE                       View hidden projects
  LH                              Shortcut for LIST HIDE
  LIST TASKS                      View all tasks
  LT                              Shortcut for LIST TASKS
  LIST COMMANDS                   Show this help
  LC                              Shortcut for LIST COMMANDS

SPECIAL
──────────────────────────────────────────────────────────────────────────
  AUD [date]                      AI-powered daily log audit
                                  Options: yesterday, mmdd, mmddyy
  RANDO                           Start/stop randodoro timer (toggle)
                                  Auto-cycles through random work/rest intervals
  DING [DING...] <hours> <note> [<hours> <note> ...]
                                  Set alarm(s). Chain multiple for custom cycles.
                                  Multiple DINGs = repeat every 3 min
  CLEAR DING                      Cancel all active alarms
  BREAK                           Take a break
  REST                            Extended break
  END DAY                         Stop all tracking for the day
  CLS or CLEAR                    Clear screen
  QUIT                            Exit tracker

═══════════════════════════════════════════════════════════════════════════
"""
        print(help_text)

    def _get_prompt(self) -> str:
        """Generate dynamic prompt showing current task status.

        Returns:
            str: Formatted prompt string with current task info.
        """
        from .alarm import get_alarm_manager
        from .randodoro import get_randodoro_manager
        
        status = _format_task_display(self.state)
        
        # Build indicator line (shown on line 2)
        indicators = []
        
        # Add alarm clocks with time remaining
        alarm_manager = get_alarm_manager()
        alarm_clocks = alarm_manager.get_alarm_clocks_display()
        if alarm_clocks:
            indicators.append(alarm_clocks)
        
        # Add randodoro indicator if active
        randodoro_manager = get_randodoro_manager()
        randodoro_info = randodoro_manager.get_randodoro_info()
        if randodoro_info:
            indicators.append(randodoro_info)
        
        # Format as multi-line prompt:
        # Line 1: Current: [task]
        # Line 2: Indicators (alarm clocks, randodoro)
        # Line 3: Enter next task/command:
        if indicators:
            indicator_line = " ".join(indicators)
            return f"{status}\n{indicator_line}\nEnter next task/command: "
        else:
            return f"{status}\nEnter next task/command: "

    def postcmd(self, stop: bool, line: str) -> bool:
        """Update prompt after each command execution.

        Args:
            stop: Whether to stop the command loop.
            line: The command line that was executed.

        Returns:
            bool: Whether to stop the command loop.
        """
        self.prompt = self._get_prompt()
        return stop
    
    def _resolve_project_identifier(self, identifier: str) -> str:
        """Resolve project number or name to project name.
        
        Args:
            identifier: Either a 1-3 digit project number or project name
            
        Returns:
            Project name (normalized to uppercase)
        """
        # If it's a 1-3 digit number, zero-pad and look up the project name
        if identifier.isdigit() and 1 <= len(identifier) <= 3:
            # Zero-pad to 3 digits
            padded_number = identifier.zfill(3)
            project_numbers = self.state.get('project_numbers', {})
            # Reverse lookup: number -> name
            for name, num in project_numbers.items():
                if num == padded_number:
                    return name.upper()
            # Number not found, return as-is (will fail downstream)
            return identifier.upper()
        # Otherwise, treat as project name
        return identifier.upper()

    def emptyline(self) -> bool:
        """Handle empty input (just pressing Enter).

        Returns:
            bool: False to continue the command loop.
        """
        return False

    # ========== Explicit Command Methods (do_*) ==========

    def do_ADD(self, line: str) -> None:
        """Handle ADD commands: ADD PROJECT, ADD PRIORITY, ADD [Project] TASK, ADD TASK.

        Args:
            line: Everything after 'ADD' keyword.
        """
        tokens = line.split()
        if not tokens:
            print(
                "Unrecognized ADD command. Use 'ADD PROJECT <Name>', 'ADD TASK <Description>', or 'ADD <ProjectName> TASK <Description>'."
            )
            return

        cmd = tokens[0].upper()

        if cmd == "PROJECT":
            pname = " ".join(tokens[1:])
            success, msg = handle_add_project(self.state, pname)
            print(msg)
        elif cmd == "PRIORITY":
            pname = " ".join(tokens[1:])
            success, msg = handle_add_priority(self.state, pname)
            print(msg)
        elif cmd == "TASK":
            # ADD TASK <description> - creates unassigned task
            desc = " ".join(tokens[1:])
            if not desc:
                print("Usage: ADD TASK <Description>")
                return
            from .db_state_manager import add_task_without_project
            tid = add_task_without_project(self.state, desc)
            print(f"Added unassigned task [{tid}] {desc}")
            # Refresh to show the new unassigned task
            handle_list_projects(self.state)
        elif "TASK" in [t.upper() for t in tokens]:
            # ADD <ProjectName|###> TASK <description>
            idx = next(i for i, t in enumerate(tokens) if t.upper() == "TASK")
            identifier = " ".join(tokens[:idx])
            desc = " ".join(tokens[idx + 1 :])
            if not desc:
                print("Usage: ADD <ProjectName> TASK <Description>")
                return
            # Support both project name and project number
            pname = self._resolve_project_identifier(identifier)
            success, msg = handle_add_task(self.state, pname, desc)
            print(msg)
            # Set sticky project for subsequent TASK commands
            if success:
                self.sticky_project = pname
        else:
            print(
                "Unrecognized ADD command. Use 'ADD PROJECT <Name>', 'ADD TASK <Description>', or 'ADD <ProjectName> TASK <Description>'."
            )
    
    def do_TASK(self, line: str) -> None:
        """Handle TASK command - add task to sticky project.
        
        After using 'ADD ## TASK ...', you can use 'TASK ...' to add
        more tasks to the same project without repeating 'ADD ##'.
        
        Args:
            line: Task description
        """
        if not self.sticky_project:
            print("No project context set. Use 'ADD <ProjectName> TASK <Description>' first.")
            return
        
        desc = line.strip()
        if not desc:
            print(f"Usage: TASK <Description> (will add to project '{self.sticky_project}')")
            return
        
        success, msg = handle_add_task(self.state, self.sticky_project, desc)
        print(msg)
    
    def _clear_sticky_project(self) -> None:
        """Clear sticky project context."""
        self.sticky_project = None

    def do_END(self, line: str) -> None:
        """Handle END commands: END DAY, END ###, END PROJECT, END ####, END DING.

        Args:
            line: Everything after 'END' keyword.
        """
        tokens = line.split()
        if not tokens:
            print(
                "Unrecognized END command. Use 'END DAY', 'END PROJECT <Name>', 'END DING', or 'END <####> [<####> ...]'."
            )
            return

        # END DAY - Stop all tracking for the day
        if tokens[0].upper() == "DAY":
            success, msg = handle_end_day(self.state)
            print(msg)
            return
        
        # END DING - Cancel all alarms
        if tokens[0].upper() == "DING":
            success, msg = handle_cancel_ding(self.state)
            print(msg)
            return

        # END ### - Quick project end by number
        if len(tokens) == 1 and tokens[0].isdigit() and len(tokens[0]) == 3:
            success, msg = handle_end_project_by_number(self.state, tokens[0])
            print(msg)
            if success:
                # Refresh the project list after ending a project
                handle_list_projects(self.state)
        elif tokens[0].upper() == "PROJECT":
            pname = " ".join(tokens[1:])
            success, msg = handle_end_project(self.state, pname)
            print(msg)
            if success:
                # Refresh the project list after ending a project
                handle_list_projects(self.state)
        else:
            # END [####] [####] ... - End tasks by IDs
            ids = [t for t in tokens if t.isdigit() and len(t) == 4]
            if ids:
                success, msg = handle_end_tasks(self.state, ids)
                print(msg)
                # Don't refresh again - handle_end_tasks already does contextual refresh
            else:
                print(
                    "Unrecognized END command. Use 'END PROJECT <Name>', 'END DING', or 'END <####> [<####> ...]'."
                )

    def do_DELETE(self, line: str) -> None:
        """Handle DELETE commands: DELETE ###, DELETE PROJECT, DELETE #### [#### ...].

        Args:
            line: Everything after 'DELETE' keyword.
        """
        tokens = line.split()
        if not tokens:
            print(
                "Unrecognized DELETE command. Use 'DELETE PROJECT <Name>' or 'DELETE <####> [<####> ...]'."
            )
            return

        # DELETE ### - Quick project delete by number
        if len(tokens) == 1 and tokens[0].isdigit() and len(tokens[0]) == 3:
            success, msg = handle_delete_project_by_number(self.state, tokens[0])
            print(msg)
            if success:
                handle_list_projects(self.state)
        elif tokens[0].upper() == "PROJECT":
            pname = " ".join(tokens[1:])
            success, msg = handle_delete_project(self.state, pname)
            print(msg)
            if success:
                handle_list_projects(self.state)
        # Support multiple task IDs: DELETE #### #### ####
        elif all(t.isdigit() and len(t) == 4 for t in tokens):
            deleted_count = 0
            for task_id in tokens:
                success, msg = handle_delete_task(self.state, task_id)
                print(msg)
                if success:
                    deleted_count += 1
            if deleted_count > 0:
                # Refresh the display after deletions
                # If we're viewing a specific project, refresh that project view
                last_viewed = self.state.get('last_viewed_project')
                if last_viewed:
                    handle_list_single_project(self.state, last_viewed)
                else:
                    handle_list_projects(self.state)
        else:
            print(
                "Unrecognized DELETE command. Use 'DELETE PROJECT <Name>' or 'DELETE <####> [<####> ...]'."
            )

    def do_LIST(self, line: str) -> None:
        """Handle LIST commands: LIST PROJECTS, LIST PRIORITY, LIST HIDE, LIST TASKS, LIST COMMANDS.
        
        Supports shortcuts: LIST PROJ, LIST PRI, LIST ###
        
        Special toggle commands:
        - LIST #### (4-digit task ID) toggles full/truncated description for that specific task
        - LIST ### (same project twice) toggles all task descriptions in that project

        Args:
            line: Everything after 'LIST' keyword.
        """
        tokens = line.split()
        if not tokens:
            print("Use 'LIST PROJECTS', 'LIST PRIORITY', 'LIST HIDE', 'LIST TASKS', or 'LIST COMMANDS'.")
            return

        cmd = tokens[0].upper()

        # Check if first token is a 4-digit task ID: LIST ####
        if tokens[0].isdigit() and len(tokens[0]) == 4:
            task_id = tokens[0]
            # Toggle this specific task's description
            success, msg = handle_toggle_single_task_description(self.state, task_id)
            if msg:
                print(msg)
        # Check if first token is a 1-3 digit project number
        elif tokens[0].isdigit() and 1 <= len(tokens[0]) <= 3:
            project_identifier = tokens[0]
            
            # Check if we're already viewing this project - if so, toggle all descriptions
            last_viewed = self.state.get('last_viewed_project')
            # Resolve both to project names for comparison
            from taskswitch.commands.project import _resolve_project_number
            current_pname = _resolve_project_number(project_identifier, self.state) if project_identifier.isdigit() else project_identifier.upper()
            last_pname = _resolve_project_number(last_viewed, self.state) if (last_viewed and last_viewed.isdigit()) else (last_viewed.upper() if last_viewed else None)
            
            if last_pname == current_pname:
                # Toggle all task descriptions for this project
                from .db_state_manager import save_state
                current_state = self.state.get("show_full_task_descriptions", False)
                self.state["show_full_task_descriptions"] = not current_state
                save_state(self.state)
                # Refresh the project view
                success, msg = handle_list_single_project(self.state, project_identifier)
                if msg:
                    print(msg)
            else:
                # First time viewing this project - show it with truncated descriptions
                self.state["show_full_task_descriptions"] = False
                success, msg = handle_list_single_project(self.state, project_identifier)
                if msg:
                    print(msg)
        elif cmd == "COMMANDS":
            self._show_command_help()
        elif cmd == "HIDE":
            success, msg = handle_list_hide(self.state)
        elif cmd in ["PROJECTS", "PROJ"]:
            # Check if a specific project identifier is provided
            if len(tokens) > 1:
                # LIST PROJ ### or LIST PROJ ProjectName
                project_identifier = " ".join(tokens[1:])
                
                # Check if we're already viewing this project - if so, toggle all descriptions
                last_viewed = self.state.get('last_viewed_project')
                # Normalize both for comparison
                from taskswitch.commands.project import _resolve_project_number
                current_pname = _resolve_project_number(project_identifier, self.state) if project_identifier.strip().isdigit() else project_identifier.strip().upper()
                last_pname = _resolve_project_number(last_viewed, self.state) if (last_viewed and last_viewed.isdigit()) else (last_viewed.upper() if last_viewed else None)
                
                if last_pname == current_pname:
                    # Toggle all task descriptions
                    from .db_state_manager import save_state
                    current_state = self.state.get("show_full_task_descriptions", False)
                    self.state["show_full_task_descriptions"] = not current_state
                    save_state(self.state)
                    # Refresh the project view
                    success, msg = handle_list_single_project(self.state, project_identifier)
                    if msg:
                        print(msg)
                else:
                    # First time viewing - show with truncated descriptions
                    self.state["show_full_task_descriptions"] = False
                    success, msg = handle_list_single_project(self.state, project_identifier)
                    if msg:
                        print(msg)
            else:
                # Clear last viewed project when viewing all projects
                success, msg = handle_list_projects(self.state)
        elif cmd in ["PRIORITY", "PRI"]:
            success, msg = handle_list_priority(self.state)
        elif cmd == "TASKS":
            pname = " ".join(tokens[1:]) if len(tokens) > 1 else None
            success, msg = handle_list_tasks(self.state, pname)
        else:
            print("Use 'LIST PROJECTS', 'LIST PRIORITY', 'LIST HIDE', 'LIST TASKS', or 'LIST COMMANDS'.")

    def do_LP(self, line: str) -> None:
        """Shortcut for LIST PROJECTS.
        
        Args:
            line: Optional project identifier (number or name).
        """
        # If line has content, treat as LIST PROJ [identifier]
        # Otherwise, treat as LIST PROJ (all projects)
        if line.strip():
            self.do_LIST(f"PROJ {line}")
        else:
            self.do_LIST("PROJ")

    def do_LR(self, line: str) -> None:
        """Shortcut for LIST PRIORITY.
        
        Args:
            line: Ignored (priority list has no parameters).
        """
        self.do_LIST("PRI")

    def do_LH(self, line: str) -> None:
        """Shortcut for LIST HIDE.
        
        Args:
            line: Ignored (hidden list has no parameters).
        """
        self.do_LIST("HIDE")

    def do_LT(self, line: str) -> None:
        """Shortcut for LIST TASKS.
        
        Args:
            line: Optional project name to filter tasks.
        """
        if line.strip():
            self.do_LIST(f"TASKS {line}")
        else:
            self.do_LIST("TASKS")

    def do_LC(self, line: str) -> None:
        """Shortcut for LIST COMMANDS.
        
        Args:
            line: Ignored (commands list has no parameters).
        """
        self.do_LIST("COMMANDS")

    def do_HIDE(self, line: str) -> None:
        """Handle HIDE command: HIDE <ProjectName|###> [<###> <###> ...] [UNTIL mmdd].

        Args:
            line: Everything after 'HIDE' keyword.
        """
        tokens = line.split()
        if not tokens:
            print("Usage: HIDE <ProjectName|###> [<###> <###> ...] [UNTIL mmdd]")
            return

        # Parse HIDE UNTIL syntax
        until = None
        proj_identifiers = []
        
        if "UNTIL" in [t.upper() for t in tokens]:
            try:
                idx = next(i for i, t in enumerate(tokens) if t.upper() == "UNTIL")
                # Everything before UNTIL are the project identifiers
                proj_identifiers = tokens[:idx]
                if idx + 1 < len(tokens):
                    until = tokens[idx + 1]
            except Exception:
                print("Invalid HIDE UNTIL syntax")
                return
        else:
            # No UNTIL keyword - all tokens are project identifiers
            proj_identifiers = tokens

        # Hide each project
        hidden = []
        for proj_identifier in proj_identifiers:
            success, msg = handle_hide_project(self.state, proj_identifier, until)
            if success:
                hidden.append(proj_identifier)
            else:
                print(msg)  # Print error for this specific project
        
        if hidden:
            if len(hidden) == 1:
                until_str = f" until {until}" if until else ""
                print(f"Hidden project: {hidden[0]}{until_str}")
            else:
                until_str = f" until {until}" if until else ""
                print(f"Hidden {len(hidden)} projects: {', '.join(hidden)}{until_str}")

    def do_UNHIDE(self, line: str) -> None:
        """Handle UNHIDE command: UNHIDE <ProjectName|###> [<###> <###> ...].

        Args:
            line: Everything after 'UNHIDE' keyword.
        """
        tokens = line.split()
        if not tokens:
            print("Usage: UNHIDE <ProjectName|###> [<###> <###> ...]")
            return

        # Support chained unhide: UNHIDE 1 2 3 or UNHIDE ProjectName
        unhidden = []
        for proj_identifier in tokens:
            success, msg = handle_unhide_project(self.state, proj_identifier)
            if success:
                # Extract project name from success message
                unhidden.append(proj_identifier)
            else:
                print(msg)  # Print error for this specific project
        
        if unhidden:
            if len(unhidden) == 1:
                print(f"Unhidden project: {unhidden[0]}")
            else:
                print(f"Unhidden {len(unhidden)} projects: {', '.join(unhidden)}")

    def do_RENAME(self, line: str) -> None:
        """Handle RENAME command: RENAME <OldProjectName|###> <NewProjectName>.

        Args:
            line: Everything after 'RENAME' keyword.
        """
        tokens = line.split()
        if len(tokens) < 2:
            print("Usage: RENAME <OldProjectName|###> <NewProjectName>")
            return

        # First token is old identifier (name or number)
        old_identifier = tokens[0]
        # Rest is new name (can be multi-word)
        new_name = " ".join(tokens[1:])
        
        success, msg = handle_rename_project(self.state, old_identifier, new_name)
        print(msg)

    def do_DING(self, line: str) -> None:
        """Handle DING alarm command: DING [DING ...] <hours> <note> [<hours> <note> ...].
        
        Examples:
            DING 0.5 Time for meeting
            DING DING 1 Check on dinner (2 dings, 5 min apart)
            DING 0.5 Focus .5 Break 1 Deep work (chain multiple alarms)
            DING 1 Work DING DING .25 Break (second alarm has repeats)
        
        Args:
            line: Everything after 'DING' keyword.
        """
        tokens = line.split()
        if not tokens:
            print("Usage: DING [DING ...] <hours> <note> [<hours> <note> ...]")
            print("  hours: Time from now (e.g., 0.5 = 30 min, 1 = 1 hour)")
            print("  Multiple DINGs = repeat alarm every 3 minutes")
            print("  Chain alarms: DING 0.5 note1 1 note2 .5 note3")
            return
        
        # Parse chained alarms: collect (repeat_count, hours, note) tuples
        alarms = []
        token_idx = 0
        
        while token_idx < len(tokens):
            # Count additional DINGs for this alarm
            repeat_count = 0
            while token_idx < len(tokens) and tokens[token_idx].upper() == "DING":
                repeat_count += 1
                token_idx += 1
            
            # Next token should be hours (float)
            if token_idx >= len(tokens):
                if alarms:  # If we have some alarms already, that's ok
                    break
                print("Error: Missing hours parameter")
                print("Usage: DING [DING ...] <hours> <note> [<hours> <note> ...]")
                return
            
            try:
                hours = float(tokens[token_idx])
                token_idx += 1
            except ValueError:
                print(f"Error: '{tokens[token_idx]}' is not a valid number for hours")
                return
            
            # Validate hours
            if hours <= 0:
                print("Error: Hours must be greater than 0")
                return
            
            # Collect note tokens until we hit a number or DING
            note_tokens = []
            while token_idx < len(tokens):
                # Check if this looks like the start of next alarm (DING or number)
                if tokens[token_idx].upper() == "DING":
                    break
                try:
                    float(tokens[token_idx])
                    # It's a number, probably next alarm's hours
                    break
                except ValueError:
                    # It's part of the note
                    note_tokens.append(tokens[token_idx])
                    token_idx += 1
            
            if not note_tokens:
                print("Error: Missing note")
                print("Usage: DING [DING ...] <hours> <note> [<hours> <note> ...]")
                return
            
            note = " ".join(note_tokens)
            alarms.append((repeat_count, hours, note))
        
        if not alarms:
            print("Error: No alarms specified")
            return
        
        # Set all alarms
        from .commands import handle_ding_chain
        success, msg = handle_ding_chain(self.state, alarms, shell_ref=self)
        print(msg)

    def do_RANDO(self, line: str) -> None:
        """Handle RANDO command to start/stop randodoro timer.
        
        Toggle behavior: RANDO starts randodoro if not running, stops it if running.
        Randodoro automatically cycles through randomized work/rest periods.
        
        Examples:
            RANDO          Start randodoro (or stop if already running)
        
        Args:
            line: Everything after 'RANDO' keyword (ignored).
        """
        success, msg = handle_rando(self.state, shell_ref=self)
        print(msg)

    def do_AUD(self, line: str) -> None:
        """Handle AUD (audit) command to generate LLM-powered insights.
        
        Analyzes a day's time log using Mistral AI to generate insights about
        productivity patterns, focus time, project momentum, and actionable suggestions.
        
        Usage:
            AUD              Analyze today's log (after 23:59)
            AUD yesterday    Analyze yesterday's log
            AUD mmdd         Analyze specific date (e.g., 1129 = Nov 29)
            AUD mmddyy       Analyze date in another year (e.g., 112924 = Nov 29, 2024)
        
        Args:
            line: Optional date specification (yesterday, mmdd, or mmddyy).
        """
        success, msg = handle_analyze(line)
        print(msg)

    def do_CLEAR(self, line: str) -> None:
        """Handle CLEAR command: CLEAR [####] [DUE].
        
        CLEAR alone clears the screen.
        CLEAR #### DUE clears the deadline from a task.
        CLEAR DING cancels the active alarm.
        
        Args:
            line: Everything after 'CLEAR' keyword.
        """
        tokens = line.split()
        
        if not tokens:
            # CLEAR alone - clear screen
            success, msg = handle_clear_screen(self.state)
            print(msg)
            return
        
        # CLEAR DING - cancel alarm
        if len(tokens) == 1 and tokens[0].upper() == "DING":
            success, msg = handle_cancel_ding(self.state)
            print(msg)
            return
        
        # CLEAR #### DUE - clear task deadline
        if len(tokens) == 2 and tokens[0].isdigit() and len(tokens[0]) == 4 and tokens[1].upper() == "DUE":
            from .commands import handle_clear_task_deadline
            success, msg = handle_clear_task_deadline(self.state, tokens[0])
            print(msg)
            return
        
        print("Usage: CLEAR | CLEAR #### DUE | CLEAR DING")

    def do_QUIT(self, line: str) -> bool:
        """Exit the shell.

        Args:
            line: Ignored.

        Returns:
            bool: True to stop the command loop.
        """
        print("Exiting...")
        return True

    def do_EOF(self, line: str) -> bool:
        """Handle Ctrl+D (EOF) to exit the shell.

        Args:
            line: Ignored.

        Returns:
            bool: True to stop the command loop.
        """
        print("\nExiting...")
        return True

    # ========== Ambiguous Input Handler ==========

    def default(self, line: str) -> None:
        """Handle all ambiguous/shorthand input that doesn't match a do_* method.

        This method preserves the original flexible input style, handling:
        - Task IDs: #### (4 digits)
        - Project names: Any text matching a project
        - TASK shorthand: TASK [Description]
        - Special commands: BREAK, REST, CLS, CLEAR
        - Task operations: #### !!!, #### mmddyyyy
        - Development commands: FORCE_SUMMARY mmddyyyy
        - Default: Start text task (projectless)

        Args:
            line: The unrecognized input line.
        """
        up = line.strip()
        up_upper = up.upper()

        if not up:
            return

        # FORCE_SUMMARY mmddyyyy (development command)
        if up_upper.startswith("FORCE_SUMMARY"):
            parts = up_upper.split()
            if len(parts) == 2 and parts[1].isdigit() and len(parts[1]) == 8:
                success, msg = handle_force_summary(self.state, parts[1])
                print(msg)
            else:
                print("Usage: FORCE_SUMMARY mmddyyyy")
            return

        tokens = up.split()

        # [####] [mmdd] or [####] [mmddyyyy] - Set task deadline
        if (
            len(tokens) == 2
            and tokens[0].isdigit()
            and len(tokens[0]) == 4
            and tokens[1].isdigit()
            and len(tokens[1]) in (4, 8)
        ):
            success, msg = handle_set_task_deadline(self.state, tokens[0], tokens[1])
            print(msg)
            return

        # [####] !!! - Toggle task value flag
        if (
            len(tokens) == 2
            and tokens[0].isdigit()
            and len(tokens[0]) == 4
            and tokens[1] == "!!!"
        ):
            success, msg = handle_toggle_task_value(self.state, tokens[0])
            print(msg)
            return

        # BREAK/REST - Protected keywords for break time (don't create tasks)
        if up_upper in ("BREAK", "REST"):
            from .timer import finalize_current_task_time
            
            # Calculate previous task duration before finalizing
            previous_duration_str = "00:00:00"
            if self.state.get("start_time"):
                task_times = self.state.get("task_times", [])
                if task_times:
                    last_entry = task_times[-1]
                    duration_seconds = last_entry.get("duration_seconds", 0)
                    hours = int(duration_seconds // 3600)
                    minutes = int((duration_seconds % 3600) // 60)
                    seconds = int(duration_seconds % 60)
                    previous_duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            
            finalize_current_task_time(self.state)
            self.state["active_task"] = up_upper
            self.state["start_time"] = datetime.now(pytz.utc)
            self.state.setdefault("task_times", [])
            from .db_state_manager import save_state
            save_state(self.state)
            
            timestamp = self.state["start_time"].astimezone(_get_tz()).strftime("%H:%M:%S")
            from .utils import truncate_task_description
            # Account for "Switched to '' at " prefix (~15-20 chars)
            truncated = truncate_task_description(up_upper, max_length=62)
            print(f"Switched to '{truncated}'\nat {timestamp} | time on previous: {previous_duration_str}")
            return

        # CLS/CLEAR - Clear screen
        if up_upper in ("CLS", "CLEAR"):
            success, msg = handle_clear_screen(self.state)
            print(msg)
            self._clear_sticky_project()  # Clear sticky mode on screen clear
            return

        # Time-tracking logic: Task ID (####) - Check this BEFORE project numbers
        if len(up) == 4 and up.isdigit():
            success, msg = handle_start_task(self.state, up)
            print(msg)
            self._clear_sticky_project()  # Clear sticky mode on task switch
            return

        # 1-3 digit project number: ### (quick project view or toggle)
        if len(up) in (1, 2, 3) and up.isdigit():
            project_identifier = up
            self._clear_sticky_project()  # Clear sticky mode when viewing different project
            
            # Check if this is a toggle command (### when already viewing that project)
            last_viewed = self.state.get('last_viewed_project')
            if last_viewed == project_identifier:
                # Toggle the description display and refresh
                success, msg = handle_toggle_task_descriptions(self.state, project_identifier)
                if msg:
                    print(msg)
            else:
                # First time viewing this project - show it (truncated by default)
                self.state['last_viewed_project'] = project_identifier
                success, msg = handle_list_single_project(self.state, project_identifier)
                if msg:
                    print(msg)
            return

        # Check if input matches existing project name
        proj_lookup = up_upper.strip()
        if proj_lookup in self.state.get("project_tasks", {}):
            success, msg = handle_project_as_task(self.state, proj_lookup)
            print(msg)
            return

        # TASK [Description] shorthand
        if up_upper.startswith("TASK "):
            desc = up[5:]
            success, msg = handle_task_shorthand(self.state, desc)
            print(msg)
            return

        # Default: Start text task (projectless)
        success, msg = handle_start_text_task(self.state, up)
        print(msg)
