"""Visibility and hidden project management command handlers.

This module contains handlers for managing project visibility:
- Listing hidden projects
"""

from typing import Tuple

from ..db_state_manager import list_hide, save_state
from ..display import list_hidden_projects
from ..types import State


def handle_list_hide(state: State) -> Tuple[bool, str]:
    """Handle LIST HIDE command to display hidden projects.

    Args:
        state: State dictionary

    Returns:
        tuple: (success: bool, message: str)
    """
    hidden = list_hide(state)
    list_hidden_projects(hidden)
    # Record user's last view for contextual refresh
    state["last_list_view"] = "HIDE"
    save_state(state)
    return True, ""
