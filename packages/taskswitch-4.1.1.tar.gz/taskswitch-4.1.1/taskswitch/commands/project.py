"""Project management command handlers.

This module contains handlers for project-related commands including:
- Adding, ending, and deleting projects
- Hiding and unhiding projects
- Renaming projects
- Listing projects and single project views
"""

from typing import Optional, Tuple

from ..db_state_manager import (
    add_project,
    delete_project,
    end_project,
    hide_project,
    list_open_projects_and_tasks,
    rename_project,
    save_state,
    unhide_project,
    list_hide as db_list_hide,
)
from ..display import contextual_refresh_for_projects, list_projects, list_hidden_projects
from ..types import State
from ..utils import clear_screen, parse_flexible_date
from ..logging_config import get_commands_logger

logger = get_commands_logger()


def _resolve_project_number(project_identifier: str, state: dict) -> Optional[str]:
    """Helper to resolve a 1-3 digit project number to project name.
    
    Args:
        project_identifier: Numeric string (1-3 digits)
        state: State dictionary
        
    Returns:
        Project name if found, None otherwise
    """
    padded_number = project_identifier.zfill(3)
    inv = {v: k for k, v in state.get("project_numbers", {}).items()}
    return inv.get(padded_number)


def handle_add_project(state: State, project_name: str) -> Tuple[bool, str]:
    """Handle adding a new project.

    Args:
        state: State dictionary
        project_name: Name of the project to add

    Returns:
        tuple: (success: bool, message: str)
    """
    # Validate that project name is not empty
    if not project_name or not project_name.strip():
        return False, "Project name cannot be empty. Usage: ADD PROJECT <name>"
    
    ok = add_project(state, project_name)
    if ok:
        state["active_project"] = project_name.strip().upper()
        save_state(state)
        # contextual refresh for the newly added project
        contextual_refresh_for_projects(state, project_name.strip().upper())
    return ok, f"Added project '{project_name}': {ok}"


def handle_end_project(state: State, project_name: str) -> Tuple[bool, str]:
    """Handle ending a project by name.

    Args:
        state: State dictionary
        project_name: Name of the project to end

    Returns:
        tuple: (success: bool, message: str)
    """
    logger.info(f"Command: END project '{project_name}'")
    ok = end_project(state, project_name)
    if ok:
        contextual_refresh_for_projects(state, project_name.strip().upper())
    return ok, f"Ended project '{project_name}': {ok}"


def handle_end_project_by_number(state: State, project_number: str) -> Tuple[bool, str]:
    """Handle ending a project by 3-digit project number.

    Args:
        state: State dictionary
        project_number: 3-digit project number

    Returns:
        tuple: (success: bool, message: str)
    """
    proj_map = state.get("project_numbers", {})
    inv = {v: k for k, v in proj_map.items()}
    pname = inv.get(project_number)
    if not pname:
        return False, f"Project number '{project_number}' not found."

    ok = end_project(state, pname)
    return ok, f"Ended project '{pname}' (#{project_number}): {ok}"


def handle_delete_project(state: State, project_name: str) -> Tuple[bool, str]:
    """Handle deleting a project by name.

    Args:
        state: State dictionary
        project_name: Name of the project to delete

    Returns:
        tuple: (success: bool, message: str)
    """
    logger.warning(f"Command: DELETE project '{project_name}'")
    ok = delete_project(state, project_name)
    if ok:
        contextual_refresh_for_projects(state, project_name.strip().upper())
    return ok, f"Deleted project '{project_name}': {ok}"


def handle_delete_project_by_number(
    state: State, project_number: str
) -> Tuple[bool, str]:
    """Handle deleting a project by 3-digit project number.

    Args:
        state: State dictionary
        project_number: 3-digit project number

    Returns:
        tuple: (success: bool, message: str)
    """
    proj_map = state.get("project_numbers", {})
    inv = {v: k for k, v in proj_map.items()}
    pname = inv.get(project_number)
    if not pname:
        return False, f"Project number '{project_number}' not found."

    ok = delete_project(state, pname)
    return ok, f"Deleted project '{pname}' (#{project_number}): {ok}"


def handle_hide_project(
    state: State, project_identifier: str, until_date: Optional[str] = None
) -> Tuple[bool, str]:
    """Handle hiding a project.

    Args:
        state: State dictionary
        project_identifier: Project name or 1-3 digit project number
        until_date: Optional date in mmdd or mmddyyyy format until when project should be hidden

    Returns:
        tuple: (success: bool, message: str)
    """
    # Check if identifier is a 1-3 digit project number
    pname = project_identifier
    if project_identifier.isdigit() and 1 <= len(project_identifier) <= 3:
        pname = _resolve_project_number(project_identifier, state)
        if not pname:
            return False, f"Project number '{project_identifier}' not found."
    else:
        pname = project_identifier.strip().upper()

    # Parse until_date if provided
    formatted_until = None
    if until_date:
        formatted_until = parse_flexible_date(until_date)
        if not formatted_until:
            return False, f"Invalid date format: {until_date}. Use mmdd or mmddyyyy."
    
    ok = hide_project(state, pname, formatted_until)
    
    if ok:
        # If user was viewing LIST HIDE, refresh to show updated hidden list
        # Otherwise, refresh to show the project is now hidden from main list
        if state.get("last_list_view") == "HIDE":
            # Stay in HIDE view and refresh it
            clear_screen()
            hidden = db_list_hide(state)
            list_hidden_projects(hidden)
        else:
            # Refresh display immediately to show the project is now hidden
            contextual_refresh_for_projects(state, pname)
    
    return ok, f"Hide project '{pname}': {ok} (until={formatted_until or 'indefinite'})"


def handle_unhide_project(state: State, project_identifier: str) -> Tuple[bool, str]:
    """Handle unhiding a project.

    Args:
        state: State dictionary
        project_identifier: Project name or 1-3 digit project number

    Returns:
        tuple: (success: bool, message: str)
    """
    # Check if identifier is a 1-3 digit project number
    pname = project_identifier
    if project_identifier.isdigit() and 1 <= len(project_identifier) <= 3:
        pname = _resolve_project_number(project_identifier, state)
        if not pname:
            return False, f"Project number '{project_identifier}' not found."
    else:
        pname = project_identifier.strip().upper()

    ok = unhide_project(state, pname)
    
    if ok:
        # Refresh display immediately to show the unhidden project
        contextual_refresh_for_projects(state, pname)
    
    return ok, f"Unhide project '{pname}': {ok}"


def handle_rename_project(state: State, old_identifier: str, new_name: str) -> Tuple[bool, str]:
    """Handle renaming a project.

    Args:
        state: State dictionary
        old_identifier: Current project name or 1-3 digit project number
        new_name: New project name

    Returns:
        tuple: (success: bool, message: str)
    """
    # Resolve old identifier (name or number) to project name
    old_pname = old_identifier.strip().upper()
    if old_identifier.strip().isdigit() and 1 <= len(old_identifier.strip()) <= 3:
        old_pname = _resolve_project_number(old_identifier.strip(), state)
        if not old_pname:
            return False, f"Project number '{old_identifier}' not found."
    
    logger.info(f"Command: RENAME project '{old_pname}' to '{new_name}'")
    ok, msg = rename_project(state, old_pname, new_name)
    
    if ok:
        # Refresh display to show the renamed project
        contextual_refresh_for_projects(state, new_name.strip().upper())
    
    return ok, msg


def handle_list_projects(state: State) -> Tuple[bool, str]:
    """Handle LIST PROJECTS command.

    Args:
        state: State dictionary

    Returns:
        tuple: (success: bool, message: str)
    """
    inv = list_open_projects_and_tasks(state)
    project_numbers = state.get("project_numbers", {})
    list_projects(inv, project_numbers, state)
    # record user's last view - clear specific project view
    state["last_list_view"] = "PROJECTS"
    state["last_viewed_project"] = None
    save_state(state)
    return True, ""


def handle_list_single_project(state: State, project_identifier: str) -> Tuple[bool, str]:
    """Handle LIST PROJECTS ### or LIST PROJECTS ProjectName - show single project only.
    
    Shows the project even if it's hidden (allows viewing hidden projects without unhiding them).

    Args:
        state: State dictionary
        project_identifier: Project name or 1-3 digit project number

    Returns:
        tuple: (success: bool, message: str)
    """
    # Resolve project number to name if needed
    pname = project_identifier.strip().upper()
    if project_identifier.strip().isdigit() and 1 <= len(project_identifier.strip()) <= 3:
        pname = _resolve_project_number(project_identifier.strip(), state)
        if not pname:
            return False, f"Project number '{project_identifier}' not found"
    
    # Get all projects and filter to just the one requested
    inv = list_open_projects_and_tasks(state)
    if pname not in inv:
        return False, f"Project '{pname}' not found"
    
    # Create filtered inventory with just this project
    filtered_inv = {pname: inv[pname]}
    project_numbers = state.get("project_numbers", {})
    
    # Clear screen and display single project (without unassigned tasks)
    # We bypass visibility check by temporarily marking the project as visible
    clear_screen()
    original_hidden = state.get('projects_meta', {}).get(pname, {}).get('hidden', False)
    if original_hidden:
        # Temporarily mark as visible for display only
        if 'projects_meta' not in state:
            state['projects_meta'] = {}
        if pname not in state['projects_meta']:
            state['projects_meta'][pname] = {}
        state['projects_meta'][pname]['hidden'] = False
    
    list_projects(filtered_inv, project_numbers, state, show_unassigned=False)
    
    # Restore original hidden state (don't unhide the project in database)
    if original_hidden:
        state['projects_meta'][pname]['hidden'] = True
    
    # record user's last view - both general and specific project
    state["last_list_view"] = "PROJECTS"
    state["last_viewed_project"] = pname
    save_state(state)
    return True, ""
