"""Timer and alarm command handlers.

This module contains handlers for timer-related commands:
- Ending the day
- Setting DING alarms
- Cancelling alarms
"""

from datetime import datetime, timedelta
from typing import Tuple

from ..display import contextual_refresh_for_projects
from ..timer import post_end_switch_to_end_day
from ..types import State
from ..utils import _get_tz
from ..logging_config import get_commands_logger

logger = get_commands_logger()


def handle_end_day(state: State) -> Tuple[bool, str]:
    """Handle END DAY command - stops all tracking for the day.

    Finalizes the current task and switches to END_DAY state, stopping
    all time tracking. Unlike BREAK, this signals work is done for the day.

    Args:
        state: State dictionary

    Returns:
        tuple: (success: bool, message: str)
    """
    logger.info("Command: END DAY - stopping all tracking")
    
    # Finalize current task and switch to END_DAY
    post_end_switch_to_end_day(state)
    
    # Refresh display
    contextual_refresh_for_projects(state, None)
    
    return True, "Day ended. All tracking stopped."


def handle_ding(state: dict, hours: float, note: str, repeat_count: int = 0, shell_ref=None) -> Tuple[bool, str]:
    """Set an alarm/ding for a specified time.
    
    Args:
        state: State dictionary
        hours: Hours from now to set the alarm
        note: Note/description for the alarm
        repeat_count: Number of additional DINGs (for repeating every 5min)
        shell_ref: Optional reference to the shell (for prompt updates)
        
    Returns:
        tuple: (success: bool, message: str)
    """
    from ..alarm import get_alarm_manager
    
    # Validate hours
    if hours <= 0:
        return False, "Hours must be greater than 0"
    
    # Calculate alarm time
    tz = _get_tz()
    alarm_time = datetime.now(tz) + timedelta(hours=hours)
    alarm_time_str = alarm_time.strftime("%H:%M:%S")
    
    # Set alarm
    alarm_manager = get_alarm_manager()
    alarm_manager.set_alarm(hours, note, repeat_count=repeat_count, shell_ref=shell_ref)
    
    repeat_msg = " (repeating every 5min)" if repeat_count > 0 else ""
    return True, f"Alarm set for {alarm_time_str}{repeat_msg}"


def handle_cancel_ding(state: dict) -> Tuple[bool, str]:
    """Cancel the active alarm/ding.
    
    Args:
        state: State dictionary
        
    Returns:
        tuple: (success: bool, message: str)
    """
    from ..alarm import get_alarm_manager
    
    alarm_manager = get_alarm_manager()
    if alarm_manager.cancel_alarm():
        return True, "Alarm cancelled"
    else:
        return False, "No active alarm to cancel"


def handle_ding_chain(state: dict, alarms: list, shell_ref=None) -> Tuple[bool, str]:
    """Set multiple chained alarms from a single command.
    
    Args:
        state: State dictionary
        alarms: List of (repeat_count, hours, note) tuples
        shell_ref: Optional reference to the shell (for prompt updates)
        
    Returns:
        tuple: (success: bool, message: str)
    """
    from ..alarm import get_alarm_manager
    
    # Validate all alarms first
    cumulative_hours = 0.0
    for repeat_count, hours, note in alarms:
        if hours <= 0:
            return False, "Hours must be greater than 0"
        cumulative_hours += hours
    
    # Set all alarms with cumulative timing
    alarm_manager = get_alarm_manager()
    alarm_manager.set_alarm_chain(alarms, shell_ref=shell_ref)
    
    tz = _get_tz()
    final_time = datetime.now(tz) + timedelta(hours=cumulative_hours)
    final_time_str = final_time.strftime("%H:%M:%S")
    
    alarm_count = len(alarms)
    return True, f"Set {alarm_count} chained alarm(s), ending at {final_time_str}"
