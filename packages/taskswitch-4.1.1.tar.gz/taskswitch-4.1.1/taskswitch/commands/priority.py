"""Priority queue management command handlers.

This module contains handlers for priority list operations:
- Adding projects to priority queue
- Removing projects from priority queue
- Listing priority projects
"""

from typing import Tuple

from ..db_state_manager import (
    add_priority,
    add_project,
    list_open_projects_and_tasks,
    remove_priority,
    save_state,
)
from ..display import contextual_refresh_for_projects, list_priority
from ..types import State
from ..utils import clear_screen


def _resolve_project_number(project_identifier: str, state: dict):
    """Helper to resolve a 1-3 digit project number to project name.
    
    Args:
        project_identifier: Numeric string (1-3 digits)
        state: State dictionary
        
    Returns:
        Project name if found, None otherwise
    """
    padded_number = project_identifier.zfill(3)
    inv = {v: k for k, v in state.get("project_numbers", {}).items()}
    return inv.get(padded_number)


def handle_add_priority(state: State, project_name: str) -> Tuple[bool, str]:
    """Handle adding a project to the priority list.

    Args:
        state: State dictionary
        project_name: Name of the project to add to priority

    Returns:
        tuple: (success: bool, message: str)
    """
    # Ensure project exists before marking priority
    add_project(state, project_name)
    ok = add_priority(state, project_name)
    if ok:
        state["active_project"] = project_name.strip().upper()
        save_state(state)
    return ok, f"Added priority project '{project_name}': {ok}"


def handle_end_priority(state: State, project_identifier: str) -> Tuple[bool, str]:
    """Handle removing a project from the priority list.

    Args:
        state: State dictionary
        project_identifier: Project name or 1-3 digit project number

    Returns:
        tuple: (success: bool, message: str)
    """
    # Resolve project number to name if needed
    pname = project_identifier.strip().upper()
    if project_identifier.strip().isdigit() and 1 <= len(project_identifier.strip()) <= 3:
        pname = _resolve_project_number(project_identifier.strip(), state)
        if not pname:
            return False, f"Project number '{project_identifier}' not found"
    
    ok = remove_priority(state, pname)
    if ok:
        # Refresh display if user was viewing priority list
        contextual_refresh_for_projects(state, pname)
        return True, f"Removed '{pname}' from priority list"
    else:
        return False, f"Project '{pname}' not in priority list"


def handle_list_priority(state: State) -> Tuple[bool, str]:
    """Handle LIST PRIORITY command.

    Args:
        state: State dictionary

    Returns:
        tuple: (success: bool, message: str)
    """
    # Clear screen before displaying priority list
    clear_screen()
    inv = list_open_projects_and_tasks(state)
    priority_projects_list = state.get("priority_projects", [])
    project_numbers = state.get("project_numbers", {})
    list_priority(priority_projects_list, inv, project_numbers, state)
    # record user's last view - clear specific project view
    state["last_list_view"] = "PRIORITY"
    state["last_viewed_project"] = None
    save_state(state)
    return True, ""
