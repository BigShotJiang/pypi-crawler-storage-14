"""Task management command handlers.

This module contains handlers for task-related commands including:
- Adding, ending, and deleting tasks
- Starting and switching tasks
- Moving tasks between projects
- Setting deadlines and value flags
- Toggling task description display
"""

from datetime import datetime
from typing import List, Optional, Tuple

import pytz

from ..db_state_manager import (
    add_task,
    delete_task,
    end_tasks,
    get_task,
    list_open_projects_and_tasks,
    move_task,
    save_state,
)
from ..display import contextual_refresh_for_projects
from ..timer import finalize_current_task_time
from ..types import State
from ..utils import _format_due_date_for_display, _get_tz, parse_flexible_date
from ..logging_config import get_commands_logger

logger = get_commands_logger()


def _resolve_project_number(project_identifier: str, state: dict) -> Optional[str]:
    """Helper to resolve a 1-3 digit project number to project name.
    
    Args:
        project_identifier: Numeric string (1-3 digits)
        state: State dictionary
        
    Returns:
        Project name if found, None otherwise
    """
    padded_number = project_identifier.zfill(3)
    inv = {v: k for k, v in state.get("project_numbers", {}).items()}
    return inv.get(padded_number)


def _format_task_switch_message(state: State, task_key: str) -> str:
    """Format the task switch message with timestamp and previous task duration.
    
    Shows the switched task on first line, then timestamp and previous task duration
    on a second line in format: "at HH:MM:SS | time on previous: HH:MM:SS"
    
    Args:
        state: State dictionary (contains start_time and active_task for calculating previous duration)
        task_key: The new task key being switched to
        
    Returns:
        Formatted message string with newline
    """
    tz = _get_tz()
    timestamp = state["start_time"].astimezone(tz).strftime("%H:%M:%S")
    
    # Calculate previous task duration
    previous_duration_str = "00:00:00"
    if state.get("start_time"):
        # The finalize function was just called, so check if there was a previous task
        # We need to look at the time spent before finalizing
        # Get the last entry from task_times if it exists
        task_times = state.get("task_times", [])
        if task_times:
            last_entry = task_times[-1]
            duration_seconds = last_entry.get("duration_seconds", 0)
            hours = int(duration_seconds // 3600)
            minutes = int((duration_seconds % 3600) // 60)
            seconds = int(duration_seconds % 60)
            previous_duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    
    return f"Switched to '{task_key}'\nat {timestamp} | time on previous: {previous_duration_str}"


def handle_add_task(
    state: State, project_name: str, description: str
) -> Tuple[bool, str]:
    """Handle adding a new task to a project.

    Args:
        state: State dictionary
        project_name: Name of the project
        description: Task description

    Returns:
        tuple: (success: bool, message: str with task_id)
    """
    tid = add_task(state, project_name, description)
    # set the active project to pname
    state["active_project"] = project_name.strip().upper()
    save_state(state)
    # contextual refresh for the project that received the new task
    contextual_refresh_for_projects(state, project_name.strip().upper())
    return True, f"Added task [{tid}] {description} (Project: {project_name})"


def handle_start_task(state: State, task_id: str) -> Tuple[bool, str]:
    """Handle starting/resuming a task by ID.

    Args:
        state: State dictionary
        task_id: 4-digit task ID

    Returns:
        tuple: (success: bool, message: str)
    """
    t = get_task(state, task_id)
    if not t:
        logger.warning(f"Command: START non-existent task '{task_id}'")
        return False, f"Task id '{task_id}' not found."

    # include due date in the active display if present
    desc = t.get("description", "")
    key = f"[{t['id']}] {desc}{_format_due_date_for_display(t)} ({t['project_name']})"
    if state.get("active_task") == key:
        return False, f"Already on '{key}'. No change."

    logger.info(f"Command: START task '{task_id}'")
    finalize_current_task_time(state)
    state["active_task"] = key
    state["start_time"] = datetime.now(pytz.utc)
    state.setdefault("task_times", [])
    save_state(state)

    return True, _format_task_switch_message(state, key)


def handle_start_text_task(state: State, task_text: str) -> Tuple[bool, str]:
    """Handle starting a task by text (creates projectless task).

    Args:
        state: State dictionary
        task_text: Text description of the task

    Returns:
        tuple: (success: bool, message: str)
    """
    key = task_text.upper()
    if state.get("active_task") == key:
        return False, f"Already on '{key}'. No change."

    logger.info(f"Command: START text task (projectless)")
    finalize_current_task_time(state)
    state["active_task"] = key
    state["start_time"] = datetime.now(pytz.utc)
    state.setdefault("task_times", [])
    save_state(state)

    return True, _format_task_switch_message(state, key)


def handle_end_tasks(state: State, task_ids: List[str]) -> Tuple[bool, str]:
    """Handle ending one or more tasks.

    Args:
        state: State dictionary
        task_ids: List of 4-digit task IDs

    Returns:
        tuple: (success: bool, message: str)
    """
    from ..timer import post_end_switch_to_break
    
    logger.info(f"Command: END tasks {task_ids}")
    # call batch end; end_tasks returns mapping
    results = end_tasks(state, task_ids)
    messages = []
    for tid, res in results.items():
        if res.get("ok"):
            messages.append(f"Ended task '{tid}': {res.get('message')}")
        else:
            messages.append(f"Failed to end task '{tid}': {res.get('message')}")

    # contextual refresh for the projects affected by ended tasks BEFORE switching to break
    affected_projects = []
    for tid in task_ids:
        t = state.get("tasks", {}).get(tid)
        if t:
            affected_projects.append(t.get("project_name"))
    contextual_refresh_for_projects(state, affected_projects)

    # After ending tasks, switch to BREAK (start a break timer)
    break_message = post_end_switch_to_break(state)
    messages.append(break_message)

    return True, "\n".join(messages)


def handle_delete_task(state: State, task_id: str) -> Tuple[bool, str]:
    """Handle deleting a task by ID.

    Args:
        state: State dictionary
        task_id: 4-digit task ID

    Returns:
        tuple: (success: bool, message: str)
    """
    logger.warning(f"Command: DELETE task '{task_id}'")
    ok = delete_task(state, task_id)
    return ok, f"Deleted task '{task_id}': {ok}"


def handle_move_task(state: State, task_id: str, project_identifier: str) -> Tuple[bool, str]:
    """Handle moving a task to a different project.

    Args:
        state: State dictionary
        task_id: 4-digit task ID
        project_identifier: Target project name or 1-3 digit project number

    Returns:
        tuple: (success: bool, message: str)
    """
    # Resolve project number to name if needed
    target_pname = project_identifier.strip().upper()
    if project_identifier.strip().isdigit() and 1 <= len(project_identifier.strip()) <= 3:
        target_pname = _resolve_project_number(project_identifier.strip(), state)
        if not target_pname:
            return False, f"Project number '{project_identifier}' not found"
    
    logger.info(f"Command: MOVE task '{task_id}' to project '{target_pname}'")
    ok, msg = move_task(state, task_id, target_pname)
    
    if ok:
        # Refresh display to show the changes
        contextual_refresh_for_projects(state, target_pname)
    
    return ok, msg


def handle_task_shorthand(state: State, description: str) -> Tuple[bool, str]:
    """Handle TASK [Description] shorthand command.

    Args:
        state: State dictionary
        description: Task description

    Returns:
        tuple: (success: bool, message: str)
    """
    ap = state.get("active_project")
    if not ap:
        return (
            False,
            "No active project set. Use 'ADD PROJECT [Name]' or 'ADD [Project] TASK [Desc]')",
        )

    tid = add_task(state, ap, description)
    # After adding a task via the TASK shorthand, perform contextual auto-refresh
    contextual_refresh_for_projects(state, ap.strip().upper())
    return True, f"Added task [{tid}] {description} (Project: {ap})"


def handle_project_as_task(state: State, project_name: str) -> Tuple[bool, str]:
    """Handle entering an existing project name to create and switch to a task.

    Args:
        state: State dictionary
        project_name: Name of the existing project

    Returns:
        tuple: (success: bool, message: str with task_id)
    """
    pname = project_name.strip().upper()
    # create a new task with project name as description
    tid = add_task(state, pname, pname)
    t = state["tasks"][tid]
    task_key = f"[{t['id']}] {t.get('description','')} ({t['project_name']})"
    finalize_current_task_time(state)
    state["active_task"] = task_key
    state["start_time"] = datetime.now(pytz.utc)
    state.setdefault("task_times", [])
    save_state(state)
    
    # Use the formatting helper for consistency
    return True, _format_task_switch_message(state, task_key)


def handle_set_task_deadline(
    state: State, task_id: str, deadline_str: str
) -> Tuple[bool, str]:
    """Handle setting a task deadline ([####] [mmdd] or [####] [mmddyyyy]).

    Args:
        state: State dictionary
        task_id: 4-digit task ID
        deadline_str: Deadline in mmdd (current year) or mmddyyyy format

    Returns:
        tuple: (success: bool, message: str)
    """
    from ..db_state_manager import update_task_deadline
    
    t = get_task(state, task_id)
    if not t:
        return False, f"Task {task_id} not found."

    # Parse flexible date format (mmdd or mmddyyyy)
    formatted_deadline = parse_flexible_date(deadline_str)
    if not formatted_deadline:
        return False, f"Invalid date format: {deadline_str}. Use mmdd or mmddyyyy."
    
    # Update in database
    if not update_task_deadline(task_id, formatted_deadline):
        return False, f"Failed to update deadline for task {task_id}."
    
    # Update in-memory state
    t["deadline_mmddyyyy"] = formatted_deadline
    
    # Extract date parts for display
    mm = int(formatted_deadline[0:2])
    dd = int(formatted_deadline[2:4])
    yyyy = int(formatted_deadline[4:8])

    # Session-aware contextual auto-refresh
    contextual_refresh_for_projects(state, t.get("project_name"))
    return True, f"Task [{task_id}] deadline set to {mm:02d}/{dd:02d}/{yyyy:04d}."


def handle_clear_task_deadline(state: State, task_id: str) -> Tuple[bool, str]:
    """Handle clearing a task's deadline (CLEAR #### DUE).

    Args:
        state: State dictionary
        task_id: 4-digit task ID

    Returns:
        tuple: (success: bool, message: str)
    """
    from ..db_state_manager import update_task_deadline
    
    t = get_task(state, task_id)
    if not t:
        return False, f"Task {task_id} not found."

    # Update in database (None clears the deadline)
    if not update_task_deadline(task_id, None):
        return False, f"Failed to clear deadline for task {task_id}."
    
    # Update in-memory state
    if "deadline_mmddyyyy" in t:
        del t["deadline_mmddyyyy"]

    # Session-aware contextual auto-refresh
    contextual_refresh_for_projects(state, t.get("project_name"))
    return True, f"Task [{task_id}] deadline cleared."


def handle_toggle_task_value(state: State, task_id: str) -> Tuple[bool, str]:
    """Handle toggling a task's value flag ([####] !!!).

    Args:
        state: State dictionary
        task_id: 4-digit task ID

    Returns:
        tuple: (success: bool, message: str)
    """
    from ..db_state_manager import update_task_value_flag
    
    t = get_task(state, task_id)
    if not t:
        return False, f"Task {task_id} not found."

    # Administrative change: toggle value_flag (invert boolean) without touching timers
    current_flag_value = bool(t.get("value_flag"))
    new_value = not current_flag_value
    
    # Update in database
    if not update_task_value_flag(task_id, new_value):
        return False, f"Failed to update task {task_id}."
    
    # Update in-memory state
    t["value_flag"] = new_value

    # Session-aware contextual auto-refresh
    contextual_refresh_for_projects(state, t.get("project_name"))

    if new_value:
        return True, f"Task [{task_id}] marked as high value (!!!)."
    else:
        return True, f"Task [{task_id}] unmarked as high value."


def handle_toggle_single_task_description(state: State, task_id: str) -> Tuple[bool, str]:
    """Toggle the expansion state of a single task description.
    
    If the task is currently truncated, it will be expanded to show the full description.
    If it's already expanded, it will be collapsed back to truncated view.
    
    Args:
        state: State dictionary
        task_id: 4-digit task ID to toggle
        
    Returns:
        tuple: (success: bool, message: str)
    """
    from ..commands.project import handle_list_single_project, handle_list_projects
    
    # Initialize expanded_task_ids if not present
    if "expanded_task_ids" not in state:
        state["expanded_task_ids"] = set()
    
    # Ensure it's a set
    if not isinstance(state["expanded_task_ids"], set):
        state["expanded_task_ids"] = set(state["expanded_task_ids"]) if state["expanded_task_ids"] else set()
    
    # Toggle the task ID in the set
    if task_id in state["expanded_task_ids"]:
        state["expanded_task_ids"].remove(task_id)
        action = "collapsed"
    else:
        state["expanded_task_ids"].add(task_id)
        action = "expanded"
    
    # Save state
    save_state(state)
    
    # Refresh the display based on last viewed project
    last_viewed = state.get('last_viewed_project')
    if last_viewed:
        handle_list_single_project(state, last_viewed)
    else:
        handle_list_projects(state)
    
    return True, f"Task {task_id} description {action}"


def handle_toggle_task_descriptions(state: State, project_identifier: Optional[str] = None) -> Tuple[bool, str]:
    """Toggle between showing all task descriptions in full vs truncated.
    
    This is a global toggle that affects all tasks in the display.
    
    Args:
        state: State dictionary
        project_identifier: Optional project identifier (for compatibility with callers)
        
    Returns:
        tuple: (success: bool, message: str)
    """
    from ..commands.project import handle_list_single_project, handle_list_projects
    
    # Toggle the global setting
    current = state.get("show_full_task_descriptions", False)
    state["show_full_task_descriptions"] = not current
    
    # Save state
    save_state(state)
    
    # Refresh the display based on last viewed project
    last_viewed = state.get('last_viewed_project')
    if last_viewed:
        handle_list_single_project(state, last_viewed)
    else:
        handle_list_projects(state)
    
    status = "enabled" if state["show_full_task_descriptions"] else "disabled"
    return True, f"Full task descriptions {status}"


def handle_list_tasks(
    state: State, project_name: Optional[str] = None
) -> Tuple[bool, str]:
    """Handle LIST TASKS command.

    Args:
        state: State dictionary
        project_name: Optional project name to filter tasks

    Returns:
        tuple: (success: bool, message: str)
    """
    inv = list_open_projects_and_tasks(state)
    if project_name:
        tasks = inv.get(project_name, [])
        if not tasks:
            print(f"No open tasks for project '{project_name}'.")
        else:
            for t in tasks:
                print(f" - [{t['id']}] {t['description']}")
    else:
        for proj, tasks in inv.items():
            print(f"Project: {proj}")
            for t in tasks:
                print(f" - [{t['id']}] {t['description']}")
    return True, ""


def create_and_switch_task_for_project(state: State, project_name: str) -> str:
    """Create a new task using project name as description and switch timer to it.

    Finalizes any currently active task, creates a new task with the project name
    as the description, and immediately starts a timer for that task. Used by the
    TASK shorthand command for quick project switching.

    Args:
        state: State dictionary (modified in place).
        project_name: Name of project for which to create task (normalized to uppercase).

    Returns:
        str: The newly assigned 4-digit task ID.
    """
    pname = project_name.strip().upper()
    # create a new task with project name as description
    tid = add_task(state, pname, pname)
    t = state["tasks"][tid]
    task_key = f"[{t['id']}] {t.get('description','')} ({t['project_name']})"
    finalize_current_task_time(state)
    state["active_task"] = task_key
    state["start_time"] = datetime.now(pytz.utc)
    state.setdefault("task_times", [])
    save_state(state)
    return tid
