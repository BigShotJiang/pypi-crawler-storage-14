"""Command handlers for LLM-powered daily log analysis.

This module provides commands to analyze daily logs using Mistral AI,
generating insights about productivity patterns and actionable suggestions.
"""

from datetime import date, datetime, timedelta
from typing import Tuple

from ..db_state_manager import load_state
from ..llm_analyzer import get_analyzer, prompt_for_api_key
from ..reporting import generate_enhanced_log_for_llm
from ..utils import _get_tz


def handle_analyze(args: str = "") -> Tuple[bool, str]:
    """Analyze today's or a specified day's log using LLM.
    
    Usage:
        AUD           - Analyze today's log (after 23:59)
        AUD yesterday - Analyze yesterday's log
        AUD mmdd      - Analyze specific date (e.g., 1129 = Nov 29 current year)
        AUD mmddyy    - Analyze date in another year (e.g., 112924 = Nov 29, 2024)
    
    Args:
        args: Optional date specification (yesterday, mmdd, or mmddyy).
    
    Returns:
        Tuple of (success: bool, message: str)
    """
    # Parse date argument
    tz = _get_tz()
    now = datetime.now(tz)
    target_date = now.date()
    
    if args:
        args = args.strip().lower()
        
        if args == "yesterday":
            target_date = target_date - timedelta(days=1)
        elif args == "today":
            target_date = target_date
        else:
            # Try to parse as mmdd or mmddyy format
            try:
                if len(args) == 4 and args.isdigit():
                    # mmdd format - use current year
                    month = int(args[:2])
                    day = int(args[2:4])
                    year = now.year
                    target_date = date(year, month, day)
                elif len(args) == 6 and args.isdigit():
                    # mmddyy format
                    month = int(args[:2])
                    day = int(args[2:4])
                    year = 2000 + int(args[4:6])  # Assume 20xx
                    target_date = date(year, month, day)
                else:
                    return False, f"❌ Invalid date format: '{args}'. Use 'yesterday', mmdd, or mmddyy."
            except (ValueError, IndexError):
                return False, f"❌ Invalid date: '{args}'. Use 'yesterday', mmdd (e.g., 1129), or mmddyy (e.g., 112924)."
    
    # Load state
    state = load_state()
    
    # Generate enhanced log for LLM
    try:
        enhanced_log = generate_enhanced_log_for_llm(state, target_date)
    except Exception as e:
        return False, f"❌ Failed to generate log summary: {e}"
    
    # Check if there's any data for this date
    if "Total Active Time: 00:00:00" in enhanced_log:
        return False, f"⚠️  No activity logged for {target_date.isoformat()}. Nothing to analyze."
    
    # Get analyzer and run analysis
    analyzer = get_analyzer()
    
    if not analyzer.is_available():
        # Prompt for API key setup
        print("\n⚠️  Mistral API key not found.")
        api_key = prompt_for_api_key()
        
        if not api_key:
            return False, """
To enable later:
- Set environment variable: export MISTRAL_API_KEY="your-key-here"
- Or save to: ~/.config/taskswitch/mistral_key"""
        
        # Key was saved and cached instance was cleared
        # Get the fresh instance which will reload the key
        analyzer = get_analyzer()
        
        if not analyzer.is_available():
            # Debug info
            debug_info = []
            if not analyzer.api_key:
                debug_info.append("API key not loaded")
            if not analyzer.client:
                debug_info.append("Mistral client not initialized")
            
            debug_msg = f" ({', '.join(debug_info)})" if debug_info else ""
            return False, f"❌ Failed to initialize analyzer{debug_msg}. Try: pip install mistralai"
        
        print("\n✓ Setup complete! Running analysis...\n")
    
    # Run analysis
    success, result = analyzer.analyze_daily_log(enhanced_log, target_date)
    
    if not success:
        return False, result
    
    # Format output
    output_lines = []
    output_lines.append("═" * 70)
    output_lines.append(f"  ANALYSIS: {target_date.isoformat()} ({target_date.strftime('%A')})")
    output_lines.append("═" * 70)
    output_lines.append("")
    output_lines.append(result)
    output_lines.append("")
    output_lines.append("═" * 70)
    
    return True, "\n".join(output_lines)


def handle_analyze_week(args: str = "") -> Tuple[bool, str]:
    """Analyze the current week's logs (future feature).
    
    Args:
        args: Optional arguments.
    
    Returns:
        Tuple of (success: bool, message: str)
    """
    return False, "⚠️  Weekly analysis coming soon! Use 'ANALYZE' for daily analysis."
