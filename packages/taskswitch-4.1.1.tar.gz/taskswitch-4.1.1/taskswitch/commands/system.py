"""System and utility command handlers.

This module contains handlers for system-level commands:
- Clearing the screen
- Force summary (development/debugging)
"""

from datetime import date
from typing import Tuple

from ..reporting import summarize_day
from ..types import State
from ..utils import clear_screen


def handle_clear_screen(state: State) -> Tuple[bool, str]:
    """Handle clear screen command (CLS/CLEAR).

    Args:
        state: State dictionary

    Returns:
        tuple: (success: bool, message: str)
    """
    clear_screen()
    return True, "Screen cleared."


def handle_force_summary(state: State, date_str: str) -> Tuple[bool, str]:
    """Handle FORCE_SUMMARY command for development/debugging.

    Args:
        state: State dictionary
        date_str: Date in mmddyyyy format

    Returns:
        tuple: (success: bool, message: str)
    """
    try:
        mm = int(date_str[0:2])
        dd = int(date_str[2:4])
        yyyy = int(date_str[4:8])
        target = date(yyyy, mm, dd)
        summarize_day(state, target)
        return True, f"Forced summary for {target.isoformat()} completed."
    except Exception:
        return False, "Invalid date for FORCE_SUMMARY. Use mmddyyyy."
