"""Randodoro timer command handler.

This module contains the handler for randodoro timer operations:
- Starting and stopping randodoro timer
"""

from typing import Tuple


def handle_rando(state: dict, shell_ref=None) -> Tuple[bool, str]:
    """Toggle randodoro timer on/off.
    
    Args:
        state: State dictionary
        shell_ref: Optional reference to the shell (for prompt updates)
        
    Returns:
        tuple: (success: bool, message: str)
    """
    from ..randodoro import get_randodoro_manager
    
    randodoro_manager = get_randodoro_manager()
    
    if randodoro_manager.is_randodoro_active():
        return randodoro_manager.stop_randodoro()
    else:
        return randodoro_manager.start_randodoro(state, shell_ref)
