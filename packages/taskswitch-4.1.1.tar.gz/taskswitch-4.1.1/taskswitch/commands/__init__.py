"""Command handlers for the time tracker application.

This package contains modularized command handlers organized by domain:
- project: Project management commands
- task: Task management commands
- priority: Priority queue commands
- visibility: Hidden project commands
- timer: Timer and alarm commands
- randodoro_cmd: Randodoro timer commands
- system: System utility commands

All handlers are re-exported from this module for backward compatibility.
"""

# Project commands
from .project import (
    handle_add_project,
    handle_delete_project,
    handle_delete_project_by_number,
    handle_end_project,
    handle_end_project_by_number,
    handle_hide_project,
    handle_list_projects,
    handle_list_single_project,
    handle_rename_project,
    handle_unhide_project,
)

# Task commands
from .task import (
    create_and_switch_task_for_project,
    handle_add_task,
    handle_clear_task_deadline,
    handle_delete_task,
    handle_end_tasks,
    handle_list_tasks,
    handle_move_task,
    handle_project_as_task,
    handle_set_task_deadline,
    handle_start_task,
    handle_start_text_task,
    handle_task_shorthand,
    handle_toggle_single_task_description,
    handle_toggle_task_descriptions,
    handle_toggle_task_value,
)

# Priority commands
from .priority import (
    handle_add_priority,
    handle_end_priority,
    handle_list_priority,
)

# Visibility commands
from .visibility import (
    handle_list_hide,
)

# Timer commands
from .timer import (
    handle_cancel_ding,
    handle_ding,
    handle_ding_chain,
    handle_end_day,
)

# Randodoro commands
from .randodoro_cmd import (
    handle_rando,
)

# System commands
from .system import (
    handle_clear_screen,
    handle_force_summary,
)

# Analysis commands
from .analyze import (
    handle_analyze,
    handle_analyze_week,
)

__all__ = [
    # Project commands
    "handle_add_project",
    "handle_delete_project",
    "handle_delete_project_by_number",
    "handle_end_project",
    "handle_end_project_by_number",
    "handle_hide_project",
    "handle_list_projects",
    "handle_list_single_project",
    "handle_rename_project",
    "handle_unhide_project",
    # Task commands
    "create_and_switch_task_for_project",
    "handle_add_task",
    "handle_clear_task_deadline",
    "handle_delete_task",
    "handle_end_tasks",
    "handle_list_tasks",
    "handle_move_task",
    "handle_project_as_task",
    "handle_set_task_deadline",
    "handle_start_task",
    "handle_start_text_task",
    "handle_task_shorthand",
    "handle_toggle_single_task_description",
    "handle_toggle_task_descriptions",
    "handle_toggle_task_value",
    # Priority commands
    "handle_add_priority",
    "handle_end_priority",
    "handle_list_priority",
    # Visibility commands
    "handle_list_hide",
    # Timer commands
    "handle_cancel_ding",
    "handle_ding",
    "handle_ding_chain",
    "handle_end_day",
    # Randodoro commands
    "handle_rando",
    # System commands
    "handle_clear_screen",
    "handle_force_summary",
    # Analysis commands
    "handle_analyze",
    "handle_analyze_week",
]
