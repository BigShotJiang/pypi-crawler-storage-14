"""Database-backed state persistence using peewee ORM.

This module provides the same interface as state_manager.py but uses SQLite database
instead of JSON file storage.
"""

import json
import threading
import time
from datetime import datetime, date
from typing import Any, Dict, List, Optional, Tuple

import pytz

from .models import db, Project, Task, TimeEntry, Config
from .types import ProjectMeta, Session, State, Task as TaskType
from .utils import _ensure_dir_for_file
from .logging_config import get_database_logger
from .config_manager import get_cached_config  # Phase 3: For configurable settings

# Get logger for database operations
logger = get_database_logger()

# Thread safety: Lock for counter operations to prevent race conditions
_counter_lock = threading.Lock()

# Phase 2/3: Retry configuration (configurable via config.yaml or environment)
_config = get_cached_config()
_MAX_RETRIES = _config.get('thread_safety', {}).get('retry_max_attempts', 3)
_RETRY_DELAY = _config.get('thread_safety', {}).get('retry_initial_delay_ms', 50) / 1000.0  # Convert ms to seconds

# Phase 3: Performance metrics for monitoring
class _ThreadSafetyMetrics:
    """Thread-safe metrics collection for monitoring race conditions."""
    
    def __init__(self):
        self._lock = threading.Lock()
        self.validation_checks = 0
        self.validation_corrections = 0
        self.retry_attempts = 0
        self.successful_retries = 0
        self.state_reloads = 0
    
    def record_validation(self, corrected: bool):
        with self._lock:
            self.validation_checks += 1
            if corrected:
                self.validation_corrections += 1
    
    def record_retry(self, successful: bool):
        with self._lock:
            self.retry_attempts += 1
            if successful:
                self.successful_retries += 1
    
    def record_reload(self):
        with self._lock:
            self.state_reloads += 1
    
    def get_stats(self) -> Dict[str, int]:
        """Get current metrics snapshot."""
        with self._lock:
            return {
                'validation_checks': self.validation_checks,
                'validation_corrections': self.validation_corrections,
                'retry_attempts': self.retry_attempts,
                'successful_retries': self.successful_retries,
                'state_reloads': self.state_reloads,
            }
    
    def reset(self):
        """Reset all metrics to zero."""
        with self._lock:
            self.validation_checks = 0
            self.validation_corrections = 0
            self.retry_attempts = 0
            self.successful_retries = 0
            self.state_reloads = 0

_metrics = _ThreadSafetyMetrics()


def parse_iso_to_utc(s: Optional[str]) -> Optional[datetime]:
    """Parse an ISO 8601 datetime string and convert to UTC-aware datetime object."""
    if s is None:
        return None
    s2 = s.replace("Z", "+00:00")
    dt = datetime.fromisoformat(s2)
    if dt.tzinfo is None:
        return dt.replace(tzinfo=pytz.utc)
    return dt.astimezone(pytz.utc)


def iso_from_dt(dt: Optional[datetime]) -> Optional[str]:
    """Convert a datetime object to UTC ISO 8601 string format."""
    if dt is None:
        return None
    return dt.astimezone(pytz.utc).isoformat()


def _ensure_db_connected() -> None:
    """Ensure database connection is open."""
    if db.is_closed():
        logger.debug("Opening database connection")
        db.connect()
        logger.info("Database connection established")


def _get_config(key: str, default=None):
    """Get a config value by key."""
    _ensure_db_connected()
    try:
        config = Config.get(Config.key == key)
        return config.value
    except Config.DoesNotExist:
        return default


def _set_config(key: str, value):
    """Set a config value by key."""
    _ensure_db_connected()
    Config.insert(key=key, value=str(value)).on_conflict(
        conflict_target=[Config.key],
        update={Config.value: str(value)}
    ).execute()


def load_state() -> State:
    """Load application state from database.
    
    Returns a state dictionary compatible with the JSON-based interface.
    """
    logger.debug("Loading application state from database")
    _ensure_db_connected()
    
    # Load config values
    active_task = _get_config('active_task')
    start_time_str = _get_config('start_time')
    start_time = parse_iso_to_utc(start_time_str) if start_time_str else None
    active_project = _get_config('active_project')
    last_summary_date = _get_config('last_summary_date')
    global_task_counter = int(_get_config('global_task_counter', 0))
    project_counter = int(_get_config('project_counter', 0))
    last_list_view = _get_config('last_list_view', 'PROJECTS')
    
    # Load priority_projects from JSON
    priority_projects_json = _get_config('priority_projects', '[]')
    priority_projects = json.loads(priority_projects_json) if priority_projects_json else []
    
    # Load randodoro state
    randodoro_enabled_str = _get_config('randodoro_enabled', 'false')
    randodoro_enabled = randodoro_enabled_str.lower() == 'true' if randodoro_enabled_str else False
    
    randodoro_cycles_json = _get_config('randodoro_cycles', '[]')
    randodoro_cycles = json.loads(randodoro_cycles_json) if randodoro_cycles_json else []
    
    # Build project_numbers mapping
    project_numbers = {}
    projects = list(Project.select())
    logger.debug(f"Loaded {len(projects)} projects from database")
    for project in projects:
        project_numbers[project.name] = project.number
    
    # Build projects_meta
    projects_meta = {}
    for project in projects:
        projects_meta[project.name] = {
            'hidden': project.is_hidden,
            'unhide_date': project.unhide_date.strftime('%m%d%Y') if project.unhide_date else None
        }
    
    # Build tasks dictionary
    tasks = {}
    all_tasks = list(Task.select())
    logger.debug(f"Loaded {len(all_tasks)} tasks from database")
    for task in all_tasks:
        tasks[task.task_id] = {
            'id': task.task_id,
            'description': task.description,
            'project_name': task.project.name if task.project else None,
            'status': task.status,
            'value_flag': task.is_value,
            'deadline_mmddyyyy': task.deadline.strftime('%m%d%Y') if task.deadline else None,
        }
        if task.completed_at:
            # Handle both datetime objects and ISO strings (from migration)
            if isinstance(task.completed_at, str):
                tasks[task.task_id]['completed_at'] = task.completed_at
            else:
                tasks[task.task_id]['completed_at'] = task.completed_at.isoformat()
    
    # Build project_tasks mapping
    project_tasks = {}
    for project in Project.select():
        project_tasks[project.name] = [
            task.task_id for task in project.tasks.where(Task.status == 'open')
        ]
    
    # Build task_times list
    task_times = []
    time_entries = list(TimeEntry.select().order_by(TimeEntry.end_timestamp))
    logger.debug(f"Loaded {len(time_entries)} time entries from database")
    for entry in time_entries:
        # Handle both datetime objects and ISO strings (from migration)
        if isinstance(entry.end_timestamp, str):
            end_ts = entry.end_timestamp
        else:
            end_ts = entry.end_timestamp.isoformat()
        
        task_times.append({
            'task_name': entry.task_name,
            'duration_seconds': entry.duration_seconds,
            'end_timestamp': end_ts
        })
    
    logger.info("Application state loaded successfully")
    return {
        'active_task': active_task,
        'start_time': start_time,
        'task_times': task_times,
        'active_project': active_project,
        'priority_projects': priority_projects,
        'project_numbers': project_numbers,
        'projects_meta': projects_meta,
        'project_counter': project_counter,
        'last_summary_date': last_summary_date,
        'global_task_counter': global_task_counter,
        'tasks': tasks,
        'project_tasks': project_tasks,
        'last_list_view': last_list_view,
        'randodoro_enabled': randodoro_enabled,
        'randodoro_cycles': randodoro_cycles,
    }


def validate_state_consistency(state: State, force: bool = False) -> bool:
    """Phase 2/3: Validate state dict matches database and auto-correct if needed.
    
    Phase 3 optimizations:
    - Only validates when randodoro is active (unless forced)
    - Batches database reads to reduce round trips
    
    Args:
        state: State dictionary to validate
        force: If True, validate even when randodoro is inactive
    
    Returns:
        True if state was consistent or successfully corrected
    """
    _ensure_db_connected()
    
    # Phase 3: Skip validation if randodoro is not active (unless forced)
    if not force and not state.get('randodoro_enabled', False):
        logger.debug("Validation skipped: randodoro not active")
        return True
    
    corrections_made = False
    
    # Phase 3: Batch read both counters in one pass
    try:
        db_project_counter = int(_get_config('project_counter', 0))
        db_task_counter = int(_get_config('global_task_counter', 0))
    except Exception as e:
        logger.error(f"Failed to read counters from database: {e}")
        return False
    
    # Validate project_counter
    state_project_counter = int(state.get('project_counter', 0))
    
    if db_project_counter != state_project_counter:
        logger.warning(
            f"Counter mismatch detected: state project_counter={state_project_counter}, "
            f"db project_counter={db_project_counter}. Auto-correcting to DB value."
        )
        state['project_counter'] = db_project_counter
        corrections_made = True
    
    # Validate global_task_counter
    state_task_counter = int(state.get('global_task_counter', 0))
    
    if db_task_counter != state_task_counter:
        logger.warning(
            f"Counter mismatch detected: state global_task_counter={state_task_counter}, "
            f"db global_task_counter={db_task_counter}. Auto-correcting to DB value."
        )
        state['global_task_counter'] = db_task_counter
        corrections_made = True
    
    # Phase 3: Record metrics
    _metrics.record_validation(corrections_made)
    
    if corrections_made:
        logger.info("State consistency validation: corrections applied")
    else:
        logger.debug("State consistency validation: state is consistent")
    
    return True


def save_state(state: State) -> None:
    """Save application state to database.
    
    This is called frequently by other functions, but since we update the database
    immediately on each operation, this can be a lightweight operation that just
    ensures config values are synced.
    """
    logger.debug("Saving state configuration values")
    _ensure_db_connected()
    
    # Update config values
    _set_config('active_task', state.get('active_task') or '')
    _set_config('start_time', iso_from_dt(state.get('start_time')) or '')
    _set_config('active_project', state.get('active_project') or '')
    _set_config('last_summary_date', state.get('last_summary_date') or '')
    _set_config('global_task_counter', int(state.get('global_task_counter', 0)))
    _set_config('project_counter', int(state.get('project_counter', 0)))
    _set_config('last_list_view', state.get('last_list_view', 'PROJECTS'))
    
    # Save priority_projects as JSON
    _set_config('priority_projects', json.dumps(state.get('priority_projects', [])))
    
    # Save randodoro state
    _set_config('randodoro_enabled', 'true' if state.get('randodoro_enabled') else 'false')
    _set_config('randodoro_cycles', json.dumps(state.get('randodoro_cycles', [])))
    logger.debug("State configuration saved")


def _next_task_id(state: State) -> str:
    """Generate next sequential 4-digit task ID - thread-safe."""
    with _counter_lock:
        state["global_task_counter"] = int(state.get("global_task_counter", 0)) + 1
        _set_config('global_task_counter', state["global_task_counter"])
        return f"{state['global_task_counter']:04d}"


def add_project(state: State, project_name: str) -> bool:
    """Create a new project in the database - thread-safe with atomic transaction.
    
    Phase 2: Reloads critical state from database after creation to ensure consistency.
    """
    _ensure_db_connected()
    
    pname = project_name.strip().upper()
    logger.debug(f"Adding project: {pname}")
    
    # Check if project already exists
    existing = Project.select().where(Project.name == pname).count()
    if existing > 0:
        logger.warning(f"Project already exists: {pname}")
        return False
    
    # Use atomic transaction to ensure consistency
    with db.atomic():
        # Generate project number (3-digit zero-padded) - thread-safe
        with _counter_lock:
            state["project_counter"] = int(state.get("project_counter", 0)) + 1
            project_number = f"{state['project_counter']:03d}"
            _set_config('project_counter', state['project_counter'])
        
        # Create project
        Project.create(
            name=pname,
            number=project_number,
            is_priority=False,
            is_hidden=False,
            unhide_date=None
        )
    
    # Phase 2: Reload counter from database to ensure consistency with any background saves
    state['project_counter'] = int(_get_config('project_counter', 0))
    _metrics.record_reload()  # Phase 3: Track reload
    
    # Update in-memory state so number appears immediately
    if 'project_numbers' not in state:
        state['project_numbers'] = {}
    state['project_numbers'][pname] = project_number
    
    if 'projects_meta' not in state:
        state['projects_meta'] = {}
    state['projects_meta'][pname] = {
        'hidden': False,
        'unhide_date': None
    }
    
    if 'project_tasks' not in state:
        state['project_tasks'] = {}
    state['project_tasks'][pname] = []
    
    logger.info(f"Project created: {pname} (#{project_number})")
    # Note: save_state() removed - will be called by command handler
    return True


def add_priority(state: State, project_name: str) -> bool:
    """Add or move a project to the top of the priority list."""
    normalized_project_name = project_name.strip().upper()
    priority_list = state.setdefault("priority_projects", [])

    # Move to front: remove from current position if already present
    if normalized_project_name in priority_list:
        priority_list.remove(normalized_project_name)

    # Insert at the front
    priority_list.insert(0, normalized_project_name)

    # Enforce maximum capacity of 3 items
    while len(priority_list) > 3:
        priority_list.pop()

    # Note: save_state() removed - will be called by command handler
    return True


def get_task_by_description(description: str, projectless_only: bool = False) -> Optional[Dict[str, Any]]:
    """Find a task by its description text.
    
    Args:
        description: Task description to search for
        projectless_only: If True, only search for tasks without a project
        
    Returns:
        Task dictionary if found, None otherwise
    """
    _ensure_db_connected()
    
    try:
        query = Task.select().where(
            Task.description == description,
            Task.status == 'open'
        )
        
        if projectless_only:
            query = query.where(Task.project.is_null())
        
        task = query.get()
        
        return {
            'task_id': task.task_id,
            'description': task.description,
            'status': task.status,
            'is_value': task.is_value,
            'deadline': task.deadline,
            'project_name': task.project.name if task.project else None
        }
    except Task.DoesNotExist:
        return None


def _get_project_by_name_or_number(identifier: str) -> Optional[Project]:
    """Get a project by name or number.
    
    Args:
        identifier: Project name or 3-digit number
        
    Returns:
        Project instance if found, None otherwise
    """
    _ensure_db_connected()
    
    identifier = identifier.strip().upper()
    
    try:
        # Try by name first
        return Project.get(Project.name == identifier)
    except Project.DoesNotExist:
        # Try by number if it looks like a number
        if identifier.isdigit() and 1 <= len(identifier) <= 3:
            padded = identifier.zfill(3)
            try:
                return Project.get(Project.number == padded)
            except Project.DoesNotExist:
                pass
        return None


def add_task(state: State, project_name: str, description: str) -> str:
    """Create a new task in the database - thread-safe with atomic transaction.
    
    Phase 2: Reloads critical state from database after creation to ensure consistency.
    """
    _ensure_db_connected()
    
    pname = project_name.strip().upper()
    logger.debug(f"Adding task to project {pname}")
    
    # Ensure project exists
    try:
        project = Project.get(Project.name == pname)
    except Project.DoesNotExist:
        # Create project if it doesn't exist
        add_project(state, pname)
        project = Project.get(Project.name == pname)
    
    # Generate task ID (thread-safe)
    tid = _next_task_id(state)
    
    # Detect value_flag marker '!!!'
    value_flag = "!!!" in description
    
    # Detect optional deadline in mmdd or mmddyyyy format
    from .utils import parse_flexible_date
    deadline = None
    parts = description.split()
    for p in parts:
        if p.isdigit() and len(p) in (4, 8):
            formatted_date = parse_flexible_date(p)
            if formatted_date:
                # Convert mmddyyyy string to date object
                mm = int(formatted_date[0:2])
                dd = int(formatted_date[2:4])
                yyyy = int(formatted_date[4:8])
                deadline = date(yyyy, mm, dd)
                break
    
    # Create task in atomic transaction
    with db.atomic():
        Task.create(
            task_id=tid,
            description=description,
            project=project,
            status='open',
            completed_at=None,
            is_value=value_flag,
            deadline=deadline
        )
    
    # Phase 2: Reload counter from database to ensure consistency
    state['global_task_counter'] = int(_get_config('global_task_counter', 0))
    _metrics.record_reload()  # Phase 3: Track reload
    
    logger.info(f"Task created: {tid} for project {pname}")
    return tid


def end_task(state: State, task_id: str) -> Tuple[bool, str]:
    """Mark a task as complete in the database."""
    _ensure_db_connected()
    
    try:
        task = Task.get(Task.task_id == task_id)
        task.status = 'complete'
        task.completed_at = datetime.now(pytz.utc)
        task.save()
        logger.info(f"Task completed: {task_id}")
        return True, f"Ended task {task_id}"
    except Task.DoesNotExist:
        logger.warning(f"Attempted to end non-existent task: {task_id}")
        return False, f"Task {task_id} not found"


def end_tasks(state: State, task_ids: List[str]) -> Dict[str, Dict[str, any]]:
    """Mark multiple tasks as complete."""
    results = {}
    for tid in task_ids:
        ok, msg = end_task(state, tid)
        results[tid] = {"ok": bool(ok), "message": msg}
    return results


def add_task_without_project(state: State, description: str) -> str:
    """Create a new task without associating it to any project (projectless task).
    
    Args:
        state: State dictionary
        description: Task description
        
    Returns:
        str: 4-digit task ID
    """
    _ensure_db_connected()
    
    logger.debug(f"Adding projectless task: {description}")
    
    # Generate task ID
    tid = _next_task_id(state)
    
    # Detect value_flag marker '!!!'
    value_flag = "!!!" in description
    
    # Detect optional deadline in mmdd or mmddyyyy format
    from .utils import parse_flexible_date
    deadline = None
    parts = description.split()
    for p in parts:
        if p.isdigit() and len(p) in (4, 8):
            formatted_date = parse_flexible_date(p)
            if formatted_date:
                # Convert mmddyyyy string to date object
                mm = int(formatted_date[0:2])
                dd = int(formatted_date[2:4])
                yyyy = int(formatted_date[4:8])
                deadline = date(yyyy, mm, dd)
                break
    
    # Create task without project (project=None)
    Task.create(
        task_id=tid,
        description=description,
        project=None,  # No project for projectless tasks
        status='open',
        completed_at=None,
        is_value=value_flag,
        deadline=deadline
    )
    
    logger.info(f"Projectless task created: {tid}")
    return tid


def remove_priority(state: State, project_name: str) -> bool:
    """Remove a project from the priority list.
    
    Args:
        state: State dictionary
        project_name: Name of the project to remove from priority
        
    Returns:
        bool: True if project was removed, False if not in priority list
    """
    normalized_project_name = project_name.strip().upper()
    priority_list = state.setdefault("priority_projects", [])
    
    if normalized_project_name in priority_list:
        priority_list.remove(normalized_project_name)
        save_state(state)
        logger.info(f"Removed project from priority: {normalized_project_name}")
        return True
    
    logger.warning(f"Project not in priority list: {normalized_project_name}")
    return False


def end_project(state: State, project_name: str) -> bool:
    """Complete all tasks and delete a project."""
    _ensure_db_connected()
    
    pname = project_name.strip().upper()
    logger.debug(f"Ending project: {pname}")
    
    try:
        project = Project.get(Project.name == pname)
        
        # Complete all tasks
        now = datetime.now(pytz.utc)
        task_count = Task.update(status='complete', completed_at=now).where(
            Task.project == project
        ).execute()
        
        # Delete project
        project.delete_instance()
        
        # Clear active_project if it was this project
        if state.get('active_project') == pname:
            state['active_project'] = None
            save_state(state)
        
        logger.info(f"Project ended: {pname} ({task_count} tasks completed)")
        return True
    except Project.DoesNotExist:
        logger.warning(f"Attempted to end non-existent project: {pname}")
        return False


def delete_project(state: State, project_name: str) -> bool:
    """Permanently delete a project and all its tasks."""
    _ensure_db_connected()
    
    pname = project_name.strip().upper()
    logger.warning(f"Deleting project: {pname}")
    
    try:
        project = Project.get(Project.name == pname)
        
        # Delete all tasks
        task_count = Task.delete().where(Task.project == project).execute()
        
        # Delete project
        project.delete_instance()
        
        # Clear active_project if it was this project
        if state.get('active_project') == pname:
            state['active_project'] = None
            save_state(state)
        
        logger.info(f"Project deleted: {pname} ({task_count} tasks deleted)")
        return True
    except Project.DoesNotExist:
        logger.warning(f"Attempted to delete non-existent project: {pname}")
        return False


def rename_project(state: State, old_name: str, new_name: str) -> Tuple[bool, str]:
    """Rename a project in the database and update state mappings.
    
    Args:
        state: State dictionary
        old_name: Current project name (will be normalized to uppercase)
        new_name: New project name (will be normalized to uppercase)
        
    Returns:
        tuple: (success: bool, message: str)
    """
    _ensure_db_connected()
    
    old_pname = old_name.strip().upper()
    new_pname = new_name.strip().upper()
    
    if old_pname == new_pname:
        return False, "Old and new names are the same."
    
    logger.info(f"Renaming project from '{old_pname}' to '{new_pname}'")
    
    try:
        # Check if old project exists
        project = Project.get(Project.name == old_pname)
        
        # Check if new name already exists
        existing = Project.select().where(Project.name == new_pname).count()
        if existing > 0:
            logger.warning(f"Cannot rename: project '{new_pname}' already exists")
            return False, f"Project '{new_pname}' already exists."
        
        # Update project name
        project.name = new_pname
        project.save()
        
        # Update in-memory state mappings
        if 'project_numbers' in state and old_pname in state['project_numbers']:
            project_number = state['project_numbers'].pop(old_pname)
            state['project_numbers'][new_pname] = project_number
        
        if 'projects_meta' in state and old_pname in state['projects_meta']:
            meta = state['projects_meta'].pop(old_pname)
            state['projects_meta'][new_pname] = meta
        
        if 'project_tasks' in state and old_pname in state['project_tasks']:
            tasks = state['project_tasks'].pop(old_pname)
            state['project_tasks'][new_pname] = tasks
        
        # Update active_project if it was the renamed project
        if state.get('active_project') == old_pname:
            state['active_project'] = new_pname
        
        # Update priority list if project is in it
        priority_projects = state.get('priority_projects', [])
        if old_pname in priority_projects:
            idx = priority_projects.index(old_pname)
            priority_projects[idx] = new_pname
        
        save_state(state)
        
        logger.info(f"Project renamed successfully: '{old_pname}' -> '{new_pname}'")
        return True, f"Project '{old_pname}' renamed to '{new_pname}'."
        
    except Project.DoesNotExist:
        logger.warning(f"Attempted to rename non-existent project: {old_pname}")
        return False, f"Project '{old_pname}' not found."


def get_task(state: State, task_id: str) -> Optional[TaskType]:
    """Retrieve task object by ID.
    
    Phase 2: Implements retry logic to handle transient timing issues
    when task might not be immediately visible due to concurrent operations.
    """
    _ensure_db_connected()
    
    # Phase 2: Retry with exponential backoff
    for attempt in range(_MAX_RETRIES):
        try:
            task = Task.get(Task.task_id == task_id)
            
            # Phase 3: Record successful retry if not first attempt
            if attempt > 0:
                _metrics.record_retry(successful=True)
            
            result = {
                'id': task.task_id,
                'description': task.description,
                'project_name': task.project.name if task.project else None,
                'status': task.status,
                'value_flag': task.is_value,
                'deadline_mmddyyyy': task.deadline.strftime('%m%d%Y') if task.deadline else None,
            }
            if task.completed_at:
                result['completed_at'] = task.completed_at.isoformat()
            return result
        except Task.DoesNotExist:
            if attempt < _MAX_RETRIES - 1:
                # Not the last attempt - wait and retry
                delay = _RETRY_DELAY * (2 ** attempt)  # Exponential backoff
                logger.debug(f"Task {task_id} not found, retrying in {delay}s (attempt {attempt + 1}/{_MAX_RETRIES})")
                time.sleep(delay)
            else:
                # Last attempt failed
                _metrics.record_retry(successful=False)  # Phase 3: Record failed retry
                logger.warning(f"Task {task_id} not found after {_MAX_RETRIES} attempts")
                return None
    
    return None


def update_task_value_flag(task_id: str, value_flag: bool) -> bool:
    """Update the value flag (!!!) for a task in the database.
    
    Args:
        task_id: 4-digit task ID
        value_flag: New value flag state
        
    Returns:
        bool: True if successful, False if task not found
    """
    _ensure_db_connected()
    
    try:
        task = Task.get(Task.task_id == task_id)
        task.is_value = value_flag
        task.save()
        logger.info(f"Updated value flag for task {task_id} to {value_flag}")
        return True
    except Task.DoesNotExist:
        logger.warning(f"Attempted to update value flag for non-existent task: {task_id}")
        return False


def update_task_deadline(task_id: str, deadline_mmddyyyy: Optional[str]) -> bool:
    """Update the deadline for a task in the database.
    
    Args:
        task_id: 4-digit task ID
        deadline_mmddyyyy: Deadline in mmddyyyy format or None to clear
        
    Returns:
        bool: True if successful, False if task not found or invalid date
    """
    _ensure_db_connected()
    
    try:
        task = Task.get(Task.task_id == task_id)
        
        if deadline_mmddyyyy:
            try:
                mm = int(deadline_mmddyyyy[0:2])
                dd = int(deadline_mmddyyyy[2:4])
                yyyy = int(deadline_mmddyyyy[4:8])
                task.deadline = date(yyyy, mm, dd)
            except (ValueError, IndexError):
                logger.warning(f"Invalid deadline format for task {task_id}: {deadline_mmddyyyy}")
                return False
        else:
            task.deadline = None
        
        task.save()
        logger.info(f"Updated deadline for task {task_id} to {deadline_mmddyyyy}")
        return True
    except Task.DoesNotExist:
        logger.warning(f"Attempted to update deadline for non-existent task: {task_id}")
        return False


def delete_task(state: State, task_id: str) -> bool:
    """Permanently delete a single task."""
    _ensure_db_connected()
    
    try:
        task = Task.get(Task.task_id == task_id)
        task.delete_instance()
        return True
    except Task.DoesNotExist:
        return False


def move_task(state: State, task_id: str, target_project_name: str) -> Tuple[bool, str]:
    """Move a task from its current project to a different project.
    
    Args:
        state: State dictionary
        task_id: 4-digit task ID to move
        target_project_name: Name of the target project to move to
        
    Returns:
        tuple: (success: bool, message: str)
    """
    _ensure_db_connected()
    
    target_pname = target_project_name.strip().upper()
    
    try:
        # Get the task
        task = Task.get(Task.task_id == task_id)
        old_project_name = task.project.name if task.project else "(no project)"
        
        # Get or create the target project
        try:
            target_project = Project.get(Project.name == target_pname)
        except Project.DoesNotExist:
            # Create the project if it doesn't exist
            add_project(state, target_pname)
            target_project = Project.get(Project.name == target_pname)
        
        # Move the task
        task.project = target_project
        task.save()
        
        logger.info(f"Moved task {task_id} from '{old_project_name}' to '{target_pname}'")
        return True, f"Moved task [{task_id}] from '{old_project_name}' to '{target_pname}'"
        
    except Task.DoesNotExist:
        logger.warning(f"Attempted to move non-existent task: {task_id}")
        return False, f"Task {task_id} not found"


def hide_project(state: State, project_name: str, until: Optional[str] = None) -> bool:
    """Hide a project from standard project listings."""
    _ensure_db_connected()
    
    pname = project_name.strip().upper()
    
    try:
        project = Project.get(Project.name == pname)
        project.is_hidden = True
        
        # Parse until date if provided (mmddyyyy format)
        unhide_date_str = None
        if until:
            try:
                mm = int(until[0:2])
                dd = int(until[2:4])
                yyyy = int(until[4:8])
                project.unhide_date = date(yyyy, mm, dd)
                unhide_date_str = until
            except Exception:
                project.unhide_date = None
        else:
            project.unhide_date = None
        
        project.save()
        
        # Update in-memory state to reflect the change immediately
        if 'projects_meta' in state and pname in state['projects_meta']:
            state['projects_meta'][pname]['hidden'] = True
            state['projects_meta'][pname]['unhide_date'] = unhide_date_str
        
        logger.info(f"Project hidden: {pname} (until: {unhide_date_str or 'indefinitely'})")
        return True
    except Project.DoesNotExist:
        logger.warning(f"Attempted to hide non-existent project: {pname}")
        return False


def unhide_project(state: State, project_name: str) -> bool:
    """Make a previously hidden project visible."""
    _ensure_db_connected()
    
    pname = project_name.strip().upper()
    
    try:
        project = Project.get(Project.name == pname)
        project.is_hidden = False
        project.unhide_date = None
        project.save()
        
        # Update in-memory state to reflect the change immediately
        if 'projects_meta' in state and pname in state['projects_meta']:
            state['projects_meta'][pname]['hidden'] = False
            state['projects_meta'][pname]['unhide_date'] = None
        
        logger.info(f"Project unhidden: {pname}")
        return True
    except Project.DoesNotExist:
        logger.warning(f"Attempted to unhide non-existent project: {pname}")
        return False


def list_hide(state: State) -> List[Tuple[Optional[str], str, Optional[str]]]:
    """List all currently hidden projects."""
    _ensure_db_connected()
    
    out = []
    for project in Project.select().where(Project.is_hidden == True):
        unhide_date_str = project.unhide_date.strftime('%m%d%Y') if project.unhide_date else None
        out.append((project.number, project.name, unhide_date_str))
    
    return out


def list_open_projects_and_tasks(state: State) -> Dict[str, List[TaskType]]:
    """Build mapping of projects to their open tasks.
    
    Returns all non-hidden projects, even those without tasks, so new projects show up in listings.
    Hidden projects are excluded from the listing.
    """
    _ensure_db_connected()
    
    out = {}
    
    # Get all non-hidden projects (including those without tasks)
    for project in Project.select().where(Project.is_hidden == False):
        open_tasks = []
        for task in project.tasks.where(Task.status == 'open'):
            task_dict = {
                'id': task.task_id,
                'description': task.description,
                'project_name': project.name,
                'status': task.status,
                'value_flag': task.is_value,
                'deadline_mmddyyyy': task.deadline.strftime('%m%d%Y') if task.deadline else None,
            }
            if task.completed_at:
                task_dict['completed_at'] = task.completed_at.isoformat()
            open_tasks.append(task_dict)
        
        # Include all non-hidden projects, even if they have no tasks
        out[project.name] = open_tasks
    
    return out


def get_thread_safety_metrics() -> Dict[str, int]:
    """Phase 3: Get current thread safety metrics for monitoring.
    
    Returns dictionary with:
    - validation_checks: Total number of state validations performed
    - validation_corrections: Number of times state was corrected
    - retry_attempts: Total number of retry attempts for task queries
    - successful_retries: Number of successful retries (task found on retry)
    - state_reloads: Number of times state was reloaded from database
    
    Use this to monitor race condition frequency and system health.
    """
    return _metrics.get_stats()


def reset_thread_safety_metrics() -> None:
    """Phase 3: Reset all thread safety metrics to zero.
    
    Useful for starting fresh monitoring periods or after reviewing metrics.
    """
    _metrics.reset()
    logger.info("Thread safety metrics reset to zero")
