"""Reporting and daily summary generation for the time tracker application.

This module handles daily summary generation, historical reporting, and automated
summary checks.
"""

import os
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Dict, List, Tuple

import pytz

from .config import LOGS_DIR
from .db_state_manager import list_open_projects_and_tasks, save_state  # Using database backend
from .timer import finalize_current_task_time
from .types import State
from .utils import _ensure_dir_for_file, _get_tz, format_time


def summarize_day(state: State, summary_date: date) -> None:
    """Generate a daily summary markdown log for a specific date.

    Creates a comprehensive daily report including:
    - Aggregated task durations (sessions >= 10 seconds)
    - Current project/task inventory snapshot
    - Daily completion log (tasks ended on this date)

    Writes two files:
    - logs/YYYY-MM-DD_log.md (daily summary)
    - logs/completed_history.md (appends completions)

    Args:
        state: State dictionary containing task_times, tasks, and project data.
        summary_date: The date to summarize (uses CET timezone boundaries).
    """
    tz = _get_tz()
    # Finalize current task up to 23:59 CET on the summary date
    cutoff_cet = datetime(
        summary_date.year, summary_date.month, summary_date.day, 23, 59, 0
    )
    cutoff_cet = tz.localize(cutoff_cet)
    cutoff_utc = cutoff_cet.astimezone(pytz.utc)
    finalize_current_task_time(state, until_dt=cutoff_utc)

    # Compute start and end bounds in CET
    start_cet = tz.localize(
        datetime(summary_date.year, summary_date.month, summary_date.day, 0, 0, 0)
    )
    end_cet = cutoff_cet

    # Filter sessions by end_timestamp falling within the CET day and duration >= 10s
    sessions = state.get("task_times", [])
    filtered = []
    for s in sessions:
        try:
            et = datetime.fromisoformat(s["end_timestamp"]).astimezone(tz)
        except Exception:
            continue
        if start_cet <= et <= end_cet and float(s.get("duration_seconds", 0)) >= 10.0:
            filtered.append((s["task_name"], float(s["duration_seconds"]), et))

    # Aggregate durations per task_name
    agg = {}
    for name, dur, et in filtered:
        agg[name] = agg.get(name, 0.0) + dur

    # Build markdown lines
    lines = []
    lines.append(f"# Date: {summary_date.isoformat()}")
    lines.append(f"**Day:** {summary_date.strftime('%A')}")
    lines.append("")
    
    # Randodoro statistics
    randodoro_cycles = state.get("randodoro_cycles", [])
    cycles_today = []
    for cycle in randodoro_cycles:
        try:
            completed_dt = datetime.fromisoformat(cycle["completed_at"]).astimezone(tz)
        except Exception:
            continue
        if start_cet.date() <= completed_dt.date() <= end_cet.date():
            cycles_today.append(cycle)
    
    if cycles_today:
        lines.append("## Randodoro Statistics")
        lines.append(f"**Cycles completed:** {len(cycles_today)}")
        
        # Calculate total work and rest time
        total_work = sum(c.get('work_seconds', 0) for c in cycles_today)
        total_rest = sum(c.get('rest_seconds', 0) for c in cycles_today)
        
        lines.append(f"**Total work time:** {format_time(total_work)}")
        lines.append(f"**Total rest time:** {format_time(total_rest)}")
        
        # Show individual cycles
        if len(cycles_today) > 0:
            lines.append("")
            lines.append("**Cycle details:**")
            for i, cycle in enumerate(cycles_today, 1):
                work_mins = int(cycle.get('work_seconds', 0) // 60)
                work_secs = int(cycle.get('work_seconds', 0) % 60)
                rest_mins = int(cycle.get('rest_seconds', 0) // 60)
                rest_secs = int(cycle.get('rest_seconds', 0) % 60)
                completed_time = datetime.fromisoformat(cycle["completed_at"]).astimezone(tz).strftime('%H:%M')
                lines.append(f"- Cycle {i} @ {completed_time}: Work {work_mins:02d}:{work_secs:02d} → Rest {rest_mins:02d}:{rest_secs:02d}")
        
        lines.append("")
    
    lines.append("## Task totals")
    total_all = 0.0
    for task, secs in sorted(agg.items()):
        fmt = format_time(secs)
        lines.append(f"- {task}: {fmt}")
        total_all += secs

    lines.append("")
    lines.append(f"**Total:** {format_time(total_all)}")

    # Project and Task Inventory
    lines.append("")
    lines.append("## Project and Task Inventory:")
    inv = list_open_projects_and_tasks(state)
    if not inv:
        lines.append("(no open projects/tasks)")
    else:
        for proj, tasks in inv.items():
            lines.append(f"### {proj}")
            for t in tasks:
                lines.append(f"- [{t['id']}] {t['description']}")

    # Daily completion log: list tasks/projects ended on this day
    lines.append("")
    lines.append("## Daily Completion Log")
    completed_today = []
    # tasks dict may have status and we need to check a hypothetical completed_timestamp stored in task object
    for tid, task in (state.get("tasks") or {}).items():
        # completed_at may be stored when ending tasks; check and include if on this date
        comp = task.get("completed_at")
        if not comp:
            continue
        try:
            comp_dt = datetime.fromisoformat(comp).astimezone(tz)
        except Exception:
            continue
        if start_cet.date() <= comp_dt.date() <= end_cet.date():
            completed_today.append((tid, task))

    if not completed_today:
        lines.append("(no tasks/projects completed today)")
    else:
        for tid, task in completed_today:
            lines.append(
                f"- [{tid}] {task.get('description')} (Project: {task.get('project_name')})"
            )

    # Write markdown log file
    _ensure_dir_for_file(os.path.join(LOGS_DIR, f"{summary_date.isoformat()}_log.md"))
    fname = os.path.join(LOGS_DIR, f"{summary_date.isoformat()}_log.md")
    with open(fname, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # Append daily completions to running history
    history_fname = os.path.join(LOGS_DIR, "completed_history.md")
    _ensure_dir_for_file(history_fname)
    with open(history_fname, "a", encoding="utf-8") as hf:
        if completed_today:
            hf.write(f"\n## {summary_date.strftime('%m/%d/%Y')}\n")
            for tid, task in completed_today:
                hf.write(
                    f"- [{tid}] {task.get('description')} (Project: {task.get('project_name')})\n"
                )

    state["last_summary_date"] = summary_date.isoformat()
    save_state(state)


def check_and_summarize_if_needed(state: State) -> bool:
    """Check if daily summaries need generation and create them for unsummarized dates.

    Compares last_summary_date with current date (respecting 23:59 cutoff in local timezone)
    to determine which days need summarization. Generates summaries for all missing dates
    in sequence from last_summary_date+1 to the most recent completable date.

    Uses 23:59 cutoff logic: if current time is before today's 23:59, yesterday is the
    last completable date; otherwise today is completable.

    Args:
        state: State dictionary containing last_summary_date and task_times.

    Returns:
        bool: True if any summaries were generated, False otherwise.
    """
    tz = _get_tz()
    # Anchor 'now' to the configured CET timezone to make cutoff comparisons reliable.
    now_cet = datetime.now(tz)
    today = now_cet.date()
    # Cutoff is today's 23:59 local time. If current local time is past that cutoff,
    # we should consider today as the end_date; otherwise end_date is yesterday.
    cutoff_today = tz.localize(datetime(today.year, today.month, today.day, 23, 59, 0))
    end_date = today if now_cet >= cutoff_today else (today - timedelta(days=1))

    last = state.get("last_summary_date")
    if last is None:
        # If we've never summarized, only summarize the most-recent unprocessed day (end_date)
        start_date = end_date
    else:
        try:
            last_date = date.fromisoformat(last)
            start_date = last_date + timedelta(days=1)
        except Exception:
            # If parsing fails for some reason, fall back to summarizing end_date only
            start_date = end_date

    did_any = False
    if start_date > end_date:
        return False

    cur = start_date
    while cur <= end_date:
        summarize_day(state, cur)
        did_any = True
        cur = cur + timedelta(days=1)

    return did_any


def generate_enhanced_log_for_llm(state: State, summary_date: date) -> str:
    """Generate an LLM-optimized daily summary format for analysis.
    
    Creates a structured, hierarchical summary that groups work by project,
    calculates stats, and minimizes noise for better LLM comprehension.
    
    Args:
        state: State dictionary containing task_times, tasks, and project data.
        summary_date: The date to summarize.
    
    Returns:
        Formatted markdown string optimized for LLM analysis.
    """
    tz = _get_tz()
    
    # Compute start and end bounds in CET
    start_cet = tz.localize(
        datetime(summary_date.year, summary_date.month, summary_date.day, 0, 0, 0)
    )
    end_cet = tz.localize(
        datetime(summary_date.year, summary_date.month, summary_date.day, 23, 59, 0)
    )
    
    # Filter sessions for this day (duration >= 10s)
    sessions = state.get("task_times", [])
    filtered = []
    for s in sessions:
        try:
            et = datetime.fromisoformat(s["end_timestamp"]).astimezone(tz)
        except Exception:
            continue
        if start_cet <= et <= end_cet and float(s.get("duration_seconds", 0)) >= 10.0:
            task_name = s["task_name"]
            duration = float(s["duration_seconds"])
            filtered.append((task_name, duration, et))
    
    # Parse task names to extract project info
    # Format: "[task_id] description (PROJECT)" or just "TASK NAME"
    project_sessions: Dict[str, List[Tuple[str, float]]] = defaultdict(list)
    overhead_sessions: List[Tuple[str, float]] = []
    
    for task_name, duration, _ in filtered:
        # Try to extract project from task name
        project = None
        task_display = task_name
        
        # Check if it's in format "[####] description (PROJECT)"
        if "(" in task_name and task_name.endswith(")"):
            parts = task_name.rsplit("(", 1)
            if len(parts) == 2:
                project = parts[1].rstrip(")")
                task_display = parts[0].strip()
        
        # Check if it's a system task (BREAK, MORNING ROUTINE, etc.)
        if not project and not task_name.startswith("["):
            # This is overhead/break time
            overhead_sessions.append((task_name, duration))
        elif project:
            project_sessions[project].append((task_display, duration))
        else:
            # Task with ID but no project (shouldn't happen much)
            project_sessions["(Unassigned)"].append((task_display, duration))
    
    # Aggregate durations per project and task
    project_totals: Dict[str, float] = {}
    project_tasks: Dict[str, List[Tuple[str, float]]] = {}
    
    for project, tasks in project_sessions.items():
        task_agg: Dict[str, float] = {}
        for task_display, duration in tasks:
            task_agg[task_display] = task_agg.get(task_display, 0.0) + duration
        
        project_total = sum(task_agg.values())
        project_totals[project] = project_total
        project_tasks[project] = sorted(task_agg.items(), key=lambda x: x[1], reverse=True)
    
    # Aggregate overhead
    overhead_agg: Dict[str, float] = {}
    for task_name, duration in overhead_sessions:
        overhead_agg[task_name] = overhead_agg.get(task_name, 0.0) + duration
    overhead_total = sum(overhead_agg.values())
    
    # Calculate totals
    work_total = sum(project_totals.values())
    grand_total = work_total + overhead_total
    
    # Count stats
    num_projects_touched = len([p for p in project_sessions.keys() if p != "(Unassigned)"])
    projects_over_1hr = len([p for p, t in project_totals.items() if t >= 3600])
    
    # Get completed tasks
    completed_today = []
    for tid, task in (state.get("tasks") or {}).items():
        comp = task.get("completed_at")
        if not comp:
            continue
        try:
            comp_dt = datetime.fromisoformat(comp).astimezone(tz)
        except Exception:
            continue
        if start_cet.date() <= comp_dt.date() <= end_cet.date():
            completed_today.append((tid, task))
    
    # Get Randodoro stats
    randodoro_cycles = state.get("randodoro_cycles", [])
    cycles_today = []
    for cycle in randodoro_cycles:
        try:
            completed_dt = datetime.fromisoformat(cycle["completed_at"]).astimezone(tz)
        except Exception:
            continue
        if start_cet.date() <= completed_dt.date() <= end_cet.date():
            cycles_today.append(cycle)
    
    # Build the enhanced log
    lines = []
    day_name = summary_date.strftime("%A")
    
    lines.append(f"# Daily Summary: {summary_date.isoformat()} ({day_name})")
    lines.append("")
    
    # Executive Summary
    lines.append("## Executive Summary")
    lines.append(f"**Total Active Time:** {format_time(grand_total)}")
    lines.append(f"**Projects Touched:** {num_projects_touched} projects")
    lines.append(f"**Tasks Completed:** {len(completed_today)} task{'s' if len(completed_today) != 1 else ''}")
    lines.append(f"**Work Time:** {format_time(work_total)}")
    lines.append(f"**Overhead/Break Time:** {format_time(overhead_total)}")
    if cycles_today:
        lines.append(f"**Randodoro Cycles:** {len(cycles_today)} completed")
    lines.append("")
    
    # Today's Work Sessions (by Project)
    lines.append("## Today's Work Sessions (by Project)")
    lines.append("")
    
    sorted_projects = []
    if not project_totals:
        lines.append("(no project work today)")
        lines.append("")
    else:
        # Sort projects by time spent
        sorted_projects = sorted(project_totals.items(), key=lambda x: x[1], reverse=True)
        
        for project, total_time in sorted_projects:
            hours = int(total_time // 3600)
            mins = int((total_time % 3600) // 60)
            time_str = f"{hours}h {mins}m" if hours > 0 else f"{mins}m"
            
            lines.append(f"### {project} ({time_str})")
            
            # List tasks for this project
            for task_display, task_time in project_tasks[project]:
                lines.append(f"- {task_display} — {format_time(task_time)}")
            
            lines.append("")
    
    # Overhead/Breaks
    if overhead_agg:
        lines.append("### Overhead/Breaks")
        for task_name, duration in sorted(overhead_agg.items(), key=lambda x: x[1], reverse=True):
            lines.append(f"- {task_name} — {format_time(duration)}")
        lines.append("")
    
    # Completed Tasks
    if completed_today:
        lines.append("## Completed Tasks")
        for tid, task in completed_today:
            lines.append(f"- [{tid}] {task.get('description')} (Project: {task.get('project_name')})")
        lines.append("")
    
    # Project Stats
    lines.append("## Project Context")
    inv = list_open_projects_and_tasks(state)
    total_open_projects = len(inv) if inv else 0
    
    lines.append(f"- Total projects in system: {total_open_projects}")
    lines.append(f"- Active projects today: {num_projects_touched}")
    if projects_over_1hr > 0:
        lines.append(f"- Projects with >1hr work: {projects_over_1hr}")
    if sorted_projects:
        most_productive = sorted_projects[0]
        hours = int(most_productive[1] // 3600)
        mins = int((most_productive[1] % 3600) // 60)
        time_str = f"{hours}h {mins}m" if hours > 0 else f"{mins}m"
        lines.append(f"- Most productive: {most_productive[0]} ({time_str})")
    
    # Randodoro details if present
    if cycles_today:
        lines.append("")
        lines.append("## Randodoro Details")
        total_work = sum(c.get('work_seconds', 0) for c in cycles_today)
        total_rest = sum(c.get('rest_seconds', 0) for c in cycles_today)
        lines.append(f"- Cycles: {len(cycles_today)}")
        lines.append(f"- Total work: {format_time(total_work)}")
        lines.append(f"- Total rest: {format_time(total_rest)}")
    
    lines.append("")
    lines.append("---")
    lines.append("[Full task inventory omitted for brevity - available on request]")
    
    return "\n".join(lines)
