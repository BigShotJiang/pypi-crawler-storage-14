//! Utility modules

pub mod error;
