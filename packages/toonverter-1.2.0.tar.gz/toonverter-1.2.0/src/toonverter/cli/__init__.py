"""CLI module for TOON Converter."""

from .main import cli


__all__ = ["cli"]
