"""Version information for TOON Converter."""

__version__ = "1.2.0"
__author__ = "Danesh Patel, Be-Wagile India"
__license__ = "MIT"
