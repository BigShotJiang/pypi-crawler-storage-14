* `Cetmix OÜ <https://cetmix.com>`_:

  * Ivan Sokolov
  * Mikhail Lapin
  * Dessan Hemrayev
  * Maksim Shurupov
