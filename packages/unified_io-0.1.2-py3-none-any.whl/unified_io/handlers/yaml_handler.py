from pathlib import Path
from typing import Dict, Union

import yaml

from .path_handler import create_path


def read_yaml(path: Union[str, Path]) -> Dict:
    """Reads a YAML file into a dictionary.

    ```python
    from unified_io import read_yaml
    ```

    Args:
        path (Union[str, Path]): File path.

    Returns:
        Dict: Dictionary.
    """
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def write_yaml(x: Dict, path: Union[str, Path], kwargs: Dict = None) -> None:
    """Writes a dictionary into a YAML file.

    ```python
    from unified_io import write_yaml
    ```

    Args:
        x (Dict): Dictionary.

        path (Union[str, Path]): File path.

        kwargs (Dict, optional): Keyword arguments to pass to `yaml.safe_dump`. If `None`, `kwargs = {"sort_keys": False, "allow_unicode": True}`. Defaults to None.
    """
    path = create_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    if kwargs is None:
        kwargs = {"sort_keys": False, "allow_unicode": True}

    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(x, f, **kwargs)
