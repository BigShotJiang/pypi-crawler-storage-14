REDIS_PREFIX = "ckanext-pygments:"
