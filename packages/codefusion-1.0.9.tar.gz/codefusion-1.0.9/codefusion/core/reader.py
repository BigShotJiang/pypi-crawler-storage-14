# codefusion/core/reader.py
import logging
from pathlib import Path
import typing as t

logger = logging.getLogger(__name__)

def read_file_content(file_path: Path) -> t.Tuple[t.Optional[str], t.Optional[str]]:
    """
    Reads file content with multiple encoding attempts.
    Returns: (content, error_message)
    - If successful: (content_string, None)
    - If failed: (None, error_string)
    """
    try:
        # Prevent reading excessively large files into memory
        if file_path.stat().st_size > 10 * 1024 * 1024:  # 10MB limit
            logger.warning(f"Skipping large file {file_path} (over 10MB)")
            return None, "ERROR: File is too large to be read (>10MB)."
    except Exception as e:
        logger.warning(f"Could not stat file {file_path}: {e}")
        return None, f"ERROR: Could not access file: {e}"

    encodings = ['utf-8', 'utf-8-sig', 'latin-1', 'cp1252', 'iso-8859-1', 'ascii']
    
    for encoding in encodings:
        try:
            content = file_path.read_text(encoding=encoding)
            # Validate content isn't mostly binary
            if len(content) > 0:
                sample = content[:1000]
                non_printable = sum(1 for c in sample if ord(c) < 32 and c not in '\t\n\r')
                if non_printable / len(sample) > 0.1:
                    continue  # Try next encoding
            return content, None
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception as e:
            logger.warning(f"Error reading {file_path}: {e}")
            return None, f"ERROR: Unable to read file: {e}"
    
    # If all encodings fail
    msg = f"ERROR: Unable to decode file with any supported encoding"
    logger.warning(f"All encoding attempts failed for {file_path}")
    return None, msg
