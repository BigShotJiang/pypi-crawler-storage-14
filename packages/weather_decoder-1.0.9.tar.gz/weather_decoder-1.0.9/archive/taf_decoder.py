#!/usr/bin/env python3
"""
TAF Decoder - A comprehensive parser for TAF (Terminal Aerodrome Forecast) weather reports
"""

import argparse
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple, Union


@dataclass
class TafData:
    """Class to hold decoded TAF data"""
    raw_taf: str
    station_id: str
    issue_time: datetime
    valid_period: Dict
    forecast_periods: List[Dict]
    remarks: str
    remarks_decoded: Dict
    
    def __str__(self) -> str:
        """Return a human-readable string of the decoded TAF"""
        lines = [
            f"TAF for {self.station_id} issued {self.issue_time.day:02d} {self.issue_time.hour:02d}:{self.issue_time.minute:02d} UTC",
            f"Valid from {self.valid_period['from'].day:02d} {self.valid_period['from'].hour:02d}:{self.valid_period['from'].minute:02d} UTC",
            f"Valid to {self.valid_period['to'].day:02d} {self.valid_period['to'].hour:02d}:{self.valid_period['to'].minute:02d} UTC",
        ]
        
        # Add each forecast period
        for i, period in enumerate(self.forecast_periods):
            if i == 0:
                lines.append("\nInitial Forecast:")
            else:
                change_type = period.get('change_type', '')
                time_desc = ''
                
                if period.get('from_time') and period.get('to_time'):
                    from_time = period['from_time']
                    to_time = period['to_time']
                    time_desc = f" from {from_time.day:02d} {from_time.hour:02d}:{from_time.minute:02d} to {to_time.day:02d} {to_time.hour:02d}:{to_time.minute:02d} UTC"
                elif period.get('from_time'):
                    from_time = period['from_time']
                    time_desc = f" {from_time.day:02d} {from_time.hour:02d}:{from_time.minute:02d} UTC"
                
                prob = period.get('probability', 0)
                prob_text = f" (Probability {prob}%)" if prob > 0 else ""
                
                if change_type == 'TEMPO':
                    lines.append(f"\nTemporary conditions{time_desc}{prob_text}:")
                elif change_type == 'BECMG':
                    lines.append(f"\nConditions becoming{time_desc}{prob_text}:")
                elif change_type == 'FM':
                    lines.append(f"\nFrom {from_time.day:02d} {from_time.hour:02d}:{from_time.minute:02d} UTC{prob_text}:")
                elif change_type == 'PROB':
                    lines.append(f"\nProbability {prob}%{time_desc}:")
                else:
                    lines.append(f"\nChange group ({change_type}){time_desc}{prob_text}:")
            
            # Add wind information
            if period.get('wind'):
                lines.append(f"  Wind: {self._format_wind(period['wind'])}")
            
            # Add visibility information
            if period.get('visibility'):
                lines.append(f"  Visibility: {self._format_visibility(period['visibility'])}")
            
            # Add weather phenomena
            if period.get('weather_groups'):
                wx_lines = ["  Weather Phenomena:"]
                for wx in period['weather_groups']:
                    intensity = wx.get('intensity', '')
                    descriptor = wx.get('descriptor', '')
                    phenomena = wx.get('phenomena', [])
                    
                    if intensity or descriptor or phenomena:
                        wx_text = []
                        if intensity:
                            wx_text.append(intensity)
                        if descriptor:
                            wx_text.append(descriptor)
                        if phenomena:
                            wx_text.append(', '.join(phenomena))
                        
                        wx_lines.append(f"    {' '.join(wx_text)}")
                lines.extend(wx_lines)
            
            # Add sky conditions
            if period.get('sky_conditions'):
                sky_lines = ["  Sky Conditions:"]
                for sky in period['sky_conditions']:
                    if sky['type'] == 'CLR' or sky['type'] == 'SKC':
                        sky_lines.append(f"    Clear skies")
                    elif sky['type'] == 'NSC':
                        sky_lines.append(f"    No significant cloud")
                    elif sky['type'] == 'NCD':
                        sky_lines.append(f"    No cloud detected")
                    elif sky['type'] == 'VV':
                        sky_lines.append(f"    Vertical visibility {sky['height']} feet")
                    else:
                        sky_lines.append(f"    {sky['type']} clouds at {sky['height']} feet")
                        if sky.get('cb') or sky.get('tcu'):
                            cb_tcu = 'CB' if sky.get('cb') else 'TCU'
                            sky_lines[-1] += f" ({cb_tcu})"
                lines.extend(sky_lines)
            
            # Add QNH information
            if period.get('qnh'):
                qnh = period['qnh']
                lines.append(f"  Pressure: {qnh['value']} {qnh['unit']}")
            
            # Add temperature information - improved to handle multiple forecasts
            if period.get('temperature_max_list') or period.get('temperature_min_list'):
                temp_line = "  Temperature:"
                
                # Handle max temperatures
                if period.get('temperature_max_list'):
                    max_temps = period['temperature_max_list']
                    for i, temp in enumerate(max_temps):
                        if i > 0:
                            temp_line += ","
                        temp_line += f" max {temp['value']}°C at {temp['time'].strftime('%d/%H:%M')} UTC"
                
                # Handle min temperatures
                if period.get('temperature_min_list'):
                    if period.get('temperature_max_list'):
                        temp_line += ","
                    min_temps = period['temperature_min_list']
                    for i, temp in enumerate(min_temps):
                        if i > 0:
                            temp_line += ","
                        temp_line += f" min {temp['value']}°C at {temp['time'].strftime('%d/%H:%M')} UTC"
                
                lines.append(temp_line)
            # Fallback for backward compatibility
            elif period.get('temperature_min') is not None or period.get('temperature_max') is not None:
                temp_line = "  Temperature:"
                if period.get('temperature_max') is not None:
                    temp_line += f" max {period['temperature_max']}°C at {period.get('temperature_max_time', '').strftime('%d/%H:%M')} UTC"
                if period.get('temperature_min') is not None:
                    if period.get('temperature_max') is not None:
                        temp_line += ","
                    temp_line += f" min {period['temperature_min']}°C at {period.get('temperature_min_time', '').strftime('%d/%H:%M')} UTC"
                lines.append(temp_line)
            
            # Add turbulence if present
            if period.get('turbulence'):
                lines.append(f"  Turbulence: {period['turbulence']}")
            
            # Add icing if present
            if period.get('icing'):
                lines.append(f"  Icing: {period['icing']}")
        
        # Add remarks if present
        if self.remarks:
            lines.append(f"\nRemarks: {self.remarks}")
            if self.remarks_decoded:
                for key, value in self.remarks_decoded.items():
                    if isinstance(value, dict):
                        lines.append(f"  {key}: {', '.join([f'{k}: {v}' for k, v in value.items()])}")
                    elif isinstance(value, list):
                        if value and isinstance(value[0], dict):
                            lines.append(f"  {key}:")
                            for item in value:
                                lines.append(f"    {', '.join([f'{k}: {v}' for k, v in item.items()])}")
                        else:
                            lines.append(f"  {key}: {', '.join(value)}")
                    else:
                        lines.append(f"  {key}: {value}")
        
        return "\n".join(lines)
    
    def _format_wind(self, wind: Dict) -> str:
        """Format wind information into a readable string"""
        if wind.get('direction') == 'VRB':
            dir_text = "Variable"
        else:
            dir_text = f"{wind['direction']}°"
            
        speed_text = f"{wind['speed']} {wind['unit']}"
        
        if wind.get('gust'):
            speed_text += f", gusting to {wind['gust']} {wind['unit']}"
            
        if wind.get('variable_direction'):
            var_dir = wind['variable_direction']
            speed_text += f" (varying between {var_dir[0]}° and {var_dir[1]}°)"
            
        return f"{dir_text} at {speed_text}"
    
    def _format_visibility(self, visibility: Dict) -> str:
        """Format visibility information into a readable string"""
        if visibility.get('is_cavok'):
            return "CAVOK (Ceiling and Visibility OK)"
        
        vis_value = visibility['value']
        vis_unit = visibility['unit']
        
        if vis_value == 9999:
            return "10 km or more"
        elif vis_unit == 'M' and vis_value >= 1000 and vis_value <= 9000:
            # Format meter values to km if 1000 or greater
            km_value = vis_value / 1000
            return f"{km_value:.1f} km" if km_value % 1 != 0 else f"{int(km_value)} km"
        elif vis_value == 0 and visibility.get('is_less_than'):
            return f"Less than {vis_value} {vis_unit}"
        elif visibility.get('is_greater_than'):
            if vis_unit == 'SM':
                return f"Greater than {vis_value} {vis_unit}"
            else:
                # If meters and greater than 1000, convert to km
                if vis_value >= 1000:
                    km_value = vis_value / 1000
                    return f"Greater than {km_value:.1f} km" if km_value % 1 != 0 else f"Greater than {int(km_value)} km"
                return f"Greater than {vis_value} {vis_unit}"
        
        # Handle fractional statute miles
        if vis_unit == 'SM' and isinstance(vis_value, float):
            if vis_value.is_integer():
                return f"{int(vis_value)} {vis_unit}"
            else:
                return f"{vis_value} {vis_unit}"
            
        # Handle meters - convert to km if 1000 or greater
        if vis_unit == 'M' and vis_value >= 1000:
            km_value = vis_value / 1000
            return f"{km_value:.1f} km" if km_value % 1 != 0 else f"{int(km_value)} km"
            
        return f"{vis_value} {vis_unit}"


class TafDecoder:
    """TAF decoder class that parses raw TAF strings"""
    
    # Regular expressions for different TAF components
    STATION_ID_PATTERN = r'^([A-Z][A-Z0-9]{3})'
    DATETIME_PATTERN = r'(\d{2})(\d{2})(\d{2})Z'
    VALID_PERIOD_PATTERN = r'(\d{2})(\d{2})/(\d{2})(\d{2})'
    WIND_PATTERN = r'(\d{3}|VRB)(\d{2,3})(G(\d{2,3}))?(?:KT|MPS|KMH)'
    WIND_VAR_PATTERN = r'(\d{3})V(\d{3})'
    VISIBILITY_PATTERN = r'(?:^|\s)(?:(?:P?(\d{1,4})(?:/(\d))?(SM|KM|M)|(\d{4})(NDV)?|CAVOK|CLR))'
    SKY_PATTERN = r'(SKC|CLR|FEW|SCT|BKN|OVC|VV|///)(\d{3})(CB|TCU|///)?'
    TEMPERATURE_PATTERN = r'T([MX])([M]?)(\d{2})/(\d{2})(\d{2})Z'
    CHANGE_GROUP_PATTERN = r'(BECMG|TEMPO|FM|PROB|TAF AMD)'
    REMARKS_PATTERN = r'RMK\s+(.+)$'
    
    # Dictionaries for decoding different parts of the TAF
    WEATHER_INTENSITY = {
        '-': 'light',
        '+': 'heavy',
        'VC': 'vicinity',
        'RE': 'recent'
    }
    
    WEATHER_DESCRIPTORS = {
        'MI': 'shallow',
        'PR': 'partial',
        'BC': 'patches',
        'DR': 'low drifting',
        'BL': 'blowing',
        'SH': 'shower',
        'TS': 'thunderstorm',
        'FZ': 'freezing'
    }
    
    WEATHER_PHENOMENA = {
        'DZ': 'drizzle',
        'RA': 'rain',
        'SN': 'snow',
        'SG': 'snow grains',
        'IC': 'ice crystals',
        'PL': 'ice pellets',
        'GR': 'hail',
        'GS': 'small hail',
        'UP': 'unknown precipitation',
        'BR': 'mist',
        'FG': 'fog',
        'FU': 'smoke',
        'VA': 'volcanic ash',
        'DU': 'dust',
        'SA': 'sand',
        'HZ': 'haze',
        'PY': 'spray',
        'PO': 'dust whirls',
        'SQ': 'squalls',
        'FC': 'funnel cloud',
        '+FC': 'tornado/waterspout',
        'SS': 'sandstorm',
        'DS': 'duststorm'
    }
    
    SKY_CONDITIONS = {
        'SKC': 'clear',
        'CLR': 'clear',
        'FEW': 'few',
        'SCT': 'scattered',
        'BKN': 'broken',
        'OVC': 'overcast',
        'VV': 'vertical visibility',
        'NSC': 'no significant cloud',
        'NCD': 'no cloud detected',
        '///': 'unknown'
    }
    
    def __init__(self):
        """Initialize the TAF decoder"""
        pass
    
    def decode(self, raw_taf: str) -> TafData:
        """
        Decode a raw TAF string into structured data
        
        Args:
            raw_taf: The raw TAF string to decode
            
        Returns:
            TafData: A structured object containing all decoded TAF components
        """
        taf = raw_taf.strip()
        
        # Preprocess: insert spaces between tokens that might be stuck together
        taf = self._preprocess_taf(taf)
        
        parts = taf.split()
        original_parts = parts.copy()  # Keep a copy for reference
        
        # Extract strict header elements (TAF, station ID, time and valid period)
        header_parts = []
        
        # Extract TAF indicator if present
        if parts and (parts[0] == 'TAF' or parts[0] == 'TAF AMD'):
            header_parts.append(parts.pop(0))
            if parts and parts[0] == 'AMD':  # Handle case where AMD is separate
                header_parts.append(parts.pop(0))
        
        # Extract station ID (ICAO code)
        if parts and re.match(self.STATION_ID_PATTERN, parts[0]):
            station_id = parts.pop(0)
            header_parts.append(station_id)
        else:
            station_id = ""
        
        # Extract issue time
        if parts and re.match(r'\d{6}Z', parts[0]):
            time_str = parts.pop(0)
            header_parts.append(time_str)
            match = re.match(self.DATETIME_PATTERN, time_str)
            if match:
                day, hour, minute = map(int, match.groups())
                # Create datetime object
                current_date = datetime.now(timezone.utc)
                year, month = current_date.year, current_date.month
                
                # Handle month rollover if needed
                if day > current_date.day:
                    month -= 1
                    if month < 1:
                        month = 12
                        year -= 1
                
                issue_time = datetime(year, month, day, hour, minute, tzinfo=timezone.utc)
            else:
                issue_time = datetime.now(timezone.utc)
        else:
            issue_time = datetime.now(timezone.utc)
        
        # Extract valid period
        if parts and re.match(self.VALID_PERIOD_PATTERN, parts[0]):
            period_str = parts.pop(0)
            header_parts.append(period_str)
            match = re.match(self.VALID_PERIOD_PATTERN, period_str)
            if match:
                from_day, from_hour, to_day, to_hour = map(int, match.groups())
                
                # Handle special case where hours are 24
                if from_hour == 24:
                    from_hour = 0
                    from_day += 1
                if to_hour == 24:
                    to_hour = 0
                    to_day += 1
                
                current_date = datetime.now(timezone.utc)
                year, month = current_date.year, current_date.month
                
                # Handle month rollover for from_time
                if from_day > current_date.day:
                    if month == 1:
                        from_time = datetime(year - 1, 12, from_day, from_hour, 0, tzinfo=timezone.utc)
                    else:
                        from_time = datetime(year, month - 1, from_day, from_hour, 0, tzinfo=timezone.utc)
                else:
                    from_time = datetime(year, month, from_day, from_hour, 0, tzinfo=timezone.utc)
                
                # Handle month rollover for to_time
                if to_day < from_day:
                    if month == 12:
                        to_time = datetime(year + 1, 1, to_day, to_hour, 0, tzinfo=timezone.utc)
                    else:
                        to_time = datetime(year, month + 1, to_day, to_hour, 0, tzinfo=timezone.utc)
                else:
                    to_time = datetime(year, month, to_day, to_hour, 0, tzinfo=timezone.utc)
                
                valid_period = {
                    'from': from_time,
                    'to': to_time
                }
            else:
                valid_period = {
                    'from': datetime.now(timezone.utc),
                    'to': datetime.now(timezone.utc)
                }
        else:
            valid_period = {
                'from': datetime.now(timezone.utc),
                'to': datetime.now(timezone.utc)
            }
        
        # Check for wind information in the first element of the remaining parts
        # This is necessary because some TAFs place the wind info right after the valid period
        wind_data = None
        if parts and re.match(self.WIND_PATTERN, parts[0]):
            wind_part = parts[0]
            match = re.match(self.WIND_PATTERN, wind_part)
            if match:
                direction_str = match.group(1)
                speed = int(match.group(2))
                gust = int(match.group(4)) if match.group(4) else None
                unit = 'KT' if wind_part.endswith('KT') else 'MPS' if wind_part.endswith('MPS') else 'KMH'
                
                wind_data = {
                    'direction': 'VRB' if direction_str == 'VRB' else int(direction_str),
                    'speed': speed,
                    'unit': unit
                }
                
                if gust:
                    wind_data['gust'] = gust
        
        # Extract forecast periods
        forecast_periods = self._decode_forecast_periods(taf)
        
        # Add the wind data to the first forecast period if found
        if wind_data and forecast_periods:
            forecast_periods[0]['wind'] = wind_data
        
        # Extract remarks section
        remarks, remarks_decoded = self._decode_remarks(taf)
        
        # Create and return the TafData object
        return TafData(
            raw_taf=raw_taf,
            station_id=station_id,
            issue_time=issue_time,
            valid_period=valid_period,
            forecast_periods=forecast_periods,
            remarks=remarks,
            remarks_decoded=remarks_decoded
        )
    
    def _preprocess_taf(self, taf: str) -> str:
        """
        Preprocess TAF string to insert spaces between tokens that might be stuck together
        
        Args:
            taf: The raw TAF string
            
        Returns:
            Preprocessed TAF string with proper spacing
        """
        # List of tokens that require spacing if stuck together with other tokens
        change_indicators = ['TEMPO', 'BECMG', 'PROB30', 'PROB40']
        cloud_types = ['FEW', 'SCT', 'BKN', 'OVC']
        
        # Specifically handle FM format first (most common issue)
        # Look for FM followed by 6 digits (DDHHMM format)
        fm_pattern = r'FM(\d{6})'
        # Add space before FM if preceded by non-whitespace
        taf = re.sub(r'(\S)FM(\d{6})', r'\1 FM\2', taf)
        # Ensure there's a space after FM digits if followed immediately by text
        taf = re.sub(r'FM(\d{6})(\S)', r'FM\1 \2', taf)
        
        # Insert space before change indicators
        for indicator in change_indicators:
            # Only add space if the indicator is not at the start of a word
            pattern = r'(\S)(' + indicator + r')'
            taf = re.sub(pattern, r'\1 \2', taf)
        
        # Insert space before cloud cover indicators (FEW, SCT, BKN, OVC)
        for cloud_type in cloud_types:
            pattern = r'(\S)(' + cloud_type + r')'
            taf = re.sub(pattern, r'\1 \2', taf)
        
        # Fix specific pattern where PROB is followed by digits without space
        prob_pattern = r'PROB(\d{2})'
        taf = re.sub(prob_pattern + r'(\S)', r'PROB\1 \2', taf)
        
        return taf
    
    def _decode_forecast_periods(self, taf: str) -> List[Dict]:
        """Extract and decode each forecast period in the TAF"""
        # Remove any remarks section first
        main_taf = taf
        if 'RMK' in taf:
            main_taf = taf[:taf.index('RMK')]
        
        # Split the TAF into initial forecast and change groups
        parts = main_taf.split()
        
        # Skip header information (station id, issue time, valid period)
        header_end = 0
        for i, part in enumerate(parts):
            if (part == 'TAF' or part == 'TAF AMD' or 
                re.match(self.STATION_ID_PATTERN, part) or 
                re.match(r'\d{6}Z', part) or 
                re.match(self.VALID_PERIOD_PATTERN, part)):
                header_end = i + 1
            else:
                break
        
        # Set up FM pattern match
        fm_pattern = r'FM(\d{2})(\d{2})(\d{2})'
        
        # Initialize dictionary to track probability values by index
        prob_indices = {}
        
        # Find all indices where change groups start
        change_indices = []
        for i in range(header_end, len(parts)):
            if (parts[i] == 'TEMPO' or parts[i] == 'BECMG' or 
                parts[i].startswith('PROB')):
                # If it's a probability group, track its value
                if parts[i].startswith('PROB'):
                    prob_indices[i] = int(parts[i][4:])
                change_indices.append(i)
            elif re.match(fm_pattern, parts[i]):
                change_indices.append(i)
        
        # Add end of string as the final boundary
        change_indices.append(len(parts))
        
        # Initialize the forecast periods list
        forecast_periods = []
        
        # Process the initial forecast (everything after the header and before the first change group)
        if header_end < change_indices[0] if change_indices else len(parts):
            # All elements between header_end and first change group belong to initial forecast
            initial_elements = parts[header_end:(change_indices[0] if change_indices else len(parts))]
            initial_forecast = {'change_type': 'MAIN'}
            
            # Extract all forecast elements for the initial forecast
            self._extract_forecast_elements(initial_elements, initial_forecast)
            forecast_periods.append(initial_forecast)
        
        # Process each change group
        for i in range(len(change_indices) - 1):
            start_idx = change_indices[i]
            end_idx = change_indices[i + 1]
            
            # Determine the type of change group
            change_indicator = parts[start_idx]
            period = {}
            
            if change_indicator == 'TEMPO':
                period['change_type'] = 'TEMPO'
                # Check for time range
                if start_idx + 1 < len(parts) and re.match(r'\d{4}/\d{4}', parts[start_idx + 1]):
                    time_group = parts[start_idx + 1]
                    from_time, to_time = self._process_time_range(time_group)
                    
                    period['from_time'] = from_time
                    period['to_time'] = to_time
                    
                    # Skip the time group in extraction
                    self._extract_forecast_elements(parts[start_idx + 2:end_idx], period)
                else:
                    self._extract_forecast_elements(parts[start_idx + 1:end_idx], period)
            
            elif change_indicator == 'BECMG':
                period['change_type'] = 'BECMG'
                # Check for time range
                if start_idx + 1 < len(parts) and re.match(r'\d{4}/\d{4}', parts[start_idx + 1]):
                    time_group = parts[start_idx + 1]
                    from_time, to_time = self._process_time_range(time_group)
                    
                    period['from_time'] = from_time
                    period['to_time'] = to_time
                    
                    # Skip the time group in extraction
                    self._extract_forecast_elements(parts[start_idx + 2:end_idx], period)
                else:
                    self._extract_forecast_elements(parts[start_idx + 1:end_idx], period)
            
            elif change_indicator.startswith('PROB'):
                period['change_type'] = 'PROB'
                period['probability'] = int(change_indicator[4:])
                
                # Check for time range
                if start_idx + 1 < len(parts) and re.match(r'\d{4}/\d{4}', parts[start_idx + 1]):
                    time_group = parts[start_idx + 1]
                    from_time, to_time = self._process_time_range(time_group)
                    
                    period['from_time'] = from_time
                    period['to_time'] = to_time
                    
                    # Skip the time group in extraction
                    self._extract_forecast_elements(parts[start_idx + 2:end_idx], period)
                else:
                    self._extract_forecast_elements(parts[start_idx + 1:end_idx], period)
            
            elif re.match(fm_pattern, change_indicator):
                period['change_type'] = 'FM'
                match = re.match(fm_pattern, change_indicator)
                day, hour, minute = match.groups()
                
                day = int(day)
                hour = int(hour)
                minute = int(minute)
                
                current_date = datetime.now(timezone.utc)
                year, month = current_date.year, current_date.month
                
                # Handle month rollover
                if day > current_date.day:
                    if month == 1:
                        from_time = datetime(year - 1, 12, day, hour, minute, tzinfo=timezone.utc)
                    else:
                        from_time = datetime(year, month - 1, day, hour, minute, tzinfo=timezone.utc)
                else:
                    from_time = datetime(year, month, day, hour, minute, tzinfo=timezone.utc)
                
                period['from_time'] = from_time
                
                # Extract the forecast elements, skipping the FM indicator
                self._extract_forecast_elements(parts[start_idx + 1:end_idx], period)
            
            # Check if this change group had a probability associated with it
            if start_idx in prob_indices:
                period['probability'] = prob_indices[start_idx]
            
            forecast_periods.append(period)
        
        return forecast_periods
    
    def _process_time_range(self, time_group: str) -> Tuple[datetime, datetime]:
        """Process a time range string (like '0609/0610') into datetime objects"""
        from_day = int(time_group[0:2])
        from_hour = int(time_group[2:4])
        to_day = int(time_group[5:7])
        to_hour = int(time_group[7:9])
        
        # Handle special case where hours are 24
        if from_hour == 24:
            from_hour = 0
            from_day += 1
        if to_hour == 24:
            to_hour = 0
            to_day += 1
            
        current_date = datetime.now(timezone.utc)
        year, month = current_date.year, current_date.month
        
        # Handle month rollover for from_time
        if from_day > current_date.day:
            if month == 1:
                from_time = datetime(year - 1, 12, from_day, from_hour, 0, tzinfo=timezone.utc)
            else:
                from_time = datetime(year, month - 1, from_day, from_hour, 0, tzinfo=timezone.utc)
        else:
            from_time = datetime(year, month, from_day, from_hour, 0, tzinfo=timezone.utc)
        
        # Handle month rollover for to_time
        if to_day < from_day:
            if month == 12:
                to_time = datetime(year + 1, 1, to_day, to_hour, 0, tzinfo=timezone.utc)
            else:
                to_time = datetime(year, month + 1, to_day, to_hour, 0, tzinfo=timezone.utc)
        else:
            to_time = datetime(year, month, to_day, to_hour, 0, tzinfo=timezone.utc)
        
        return from_time, to_time
    
    def _extract_forecast_elements(self, parts: List[str], period: Dict) -> None:
        """Extract all forecast elements from a section of parts"""
        # Create a copy of parts to avoid modifying the original list
        working_parts = parts.copy()
        
        # Extract wind
        wind = self._extract_wind(working_parts)
        if wind:
            period['wind'] = wind
        
        # Extract visibility
        visibility = self._extract_visibility(working_parts)
        if visibility:
            period['visibility'] = visibility
        
        # Extract weather phenomena - important to keep them isolated to this period
        weather_groups = self._extract_weather(working_parts)
        if weather_groups:
            period['weather_groups'] = weather_groups
        
        # Extract sky conditions - important to keep them isolated to this period
        sky_conditions = self._extract_sky_conditions(working_parts)
        if sky_conditions:
            period['sky_conditions'] = sky_conditions
        
        # Extract QNH (pressure setting)
        qnh = self._extract_qnh(working_parts)
        if qnh:
            period['qnh'] = qnh
        
        # Extract temperature forecasts (TX/TN format)
        self._extract_temperature_forecasts(working_parts, period)
        
        # Check for any remaining parts that might contain specialized information
        if working_parts:
            if 'debug_info' not in period:
                period['debug_info'] = {}
            period['debug_info']['unprocessed_parts'] = working_parts.copy()
    
    def _extract_temperature_forecasts(self, parts: List[str], period: Dict) -> None:
        """Extract temperature forecasts from the TAF period"""
        i = 0
        while i < len(parts):
            # Check for temperature pattern TXM05/0612Z TNM10/0709Z
            tx_match = re.match(r'TX([M]?)(\d{2})/(\d{2})(\d{2})Z', parts[i])
            if tx_match:
                temp_sign = -1 if tx_match.group(1) == 'M' else 1
                temp_val = int(tx_match.group(2))
                day = int(tx_match.group(3))
                hour = int(tx_match.group(4))
                
                # Create datetime
                current_date = datetime.now(timezone.utc)
                year, month = current_date.year, current_date.month
                temp_time = datetime(year, month, day, hour, 0, tzinfo=timezone.utc)
                
                # Handle month rollover
                if day > current_date.day:
                    if month == 1:
                        temp_time = datetime(year - 1, 12, day, hour, 0, tzinfo=timezone.utc)
                    else:
                        temp_time = datetime(year, month - 1, day, hour, 0, tzinfo=timezone.utc)
                
                # Initialize temperature_max_list if it doesn't exist
                if 'temperature_max_list' not in period:
                    period['temperature_max_list'] = []
                
                # Add this temperature to the list
                period['temperature_max_list'].append({
                    'value': temp_sign * temp_val,
                    'time': temp_time
                })
                
                # Also set temperature_max for backward compatibility
                period['temperature_max'] = temp_sign * temp_val
                period['temperature_max_time'] = temp_time
                
                parts.pop(i)
                continue
            
            tn_match = re.match(r'TN([M]?)(\d{2})/(\d{2})(\d{2})Z', parts[i])
            if tn_match:
                temp_sign = -1 if tn_match.group(1) == 'M' else 1
                temp_val = int(tn_match.group(2))
                day = int(tn_match.group(3))
                hour = int(tn_match.group(4))
                
                # Create datetime
                current_date = datetime.now(timezone.utc)
                year, month = current_date.year, current_date.month
                temp_time = datetime(year, month, day, hour, 0, tzinfo=timezone.utc)
                
                # Handle month rollover
                if day > current_date.day:
                    if month == 1:
                        temp_time = datetime(year - 1, 12, day, hour, 0, tzinfo=timezone.utc)
                    else:
                        temp_time = datetime(year, month - 1, day, hour, 0, tzinfo=timezone.utc)
                
                # Initialize temperature_min_list if it doesn't exist
                if 'temperature_min_list' not in period:
                    period['temperature_min_list'] = []
                
                # Add this temperature to the list
                period['temperature_min_list'].append({
                    'value': temp_sign * temp_val,
                    'time': temp_time
                })
                
                # Also set temperature_min for backward compatibility
                period['temperature_min'] = temp_sign * temp_val
                period['temperature_min_time'] = temp_time
                
                parts.pop(i)
                continue
            
            i += 1
    
    def _extract_wind(self, parts: List[str]) -> Optional[Dict]:
        """Extract wind information from the TAF period"""
        for i, part in enumerate(parts):
            # Enhanced wind pattern to match more formats including MPS
            match = re.match(r'(\d{3}|VRB)(\d{2,3})(G(\d{2,3}))?(?:KT|MPS|KMH)', part)
            if match:
                direction_str = match.group(1)
                
                # Handle direction
                if direction_str == 'VRB':
                    direction = 'VRB'
                else:
                    direction = int(direction_str)
                
                # Handle speed
                speed = int(match.group(2))
                
                # Handle gusts if present
                gust = None
                if match.group(4):
                    gust = int(match.group(4))
                
                # Determine unit
                if 'KT' in part:
                    unit = 'KT'
                elif 'MPS' in part:
                    unit = 'MPS'
                elif 'KMH' in part:
                    unit = 'KMH'
                else:
                    unit = 'KT'  # Default
                
                wind = {
                    'direction': direction,
                    'speed': speed,
                    'unit': unit
                }
                
                if gust:
                    wind['gust'] = gust
                
                # Look for variable direction in the next part
                if i + 1 < len(parts):
                    var_match = re.match(self.WIND_VAR_PATTERN, parts[i+1])
                    if var_match:
                        wind['variable_direction'] = (int(var_match.group(1)), int(var_match.group(2)))
                        # Remove the variable direction part as it's been processed
                        parts.pop(i+1)
                
                # Remove the wind part as it's been processed
                parts.pop(i)
                return wind
        
        return None
    
    def _extract_visibility(self, parts: List[str]) -> Optional[Dict]:
        """Extract visibility information from the TAF period"""
        for i, part in enumerate(parts):
            # Check for CAVOK
            if part == 'CAVOK':
                parts.pop(i)
                return {
                    'value': 9999,
                    'unit': 'M',
                    'is_cavok': True
                }
            
            # Check for standard visibility format (4 digits)
            if len(part) == 4 and part.isdigit():
                vis_value = int(part)
                parts.pop(i)
                
                return {
                    'value': vis_value,
                    'unit': 'M',
                    'is_cavok': False
                }
            
            # Check for SM visibility, including P6SM pattern
            sm_match = re.match(r'(P)?(\d+)(?:/(\d+))?SM', part)
            if sm_match:
                is_greater_than = sm_match.group(1) == 'P'
                numerator = int(sm_match.group(2))
                denominator = int(sm_match.group(3)) if sm_match.group(3) else 1
                
                parts.pop(i)
                return {
                    'value': numerator / denominator,
                    'unit': 'SM',
                    'is_cavok': False,
                    'is_greater_than': is_greater_than
                }
        
        return None
    
    def _extract_weather(self, parts: List[str]) -> List[Dict]:
        """Extract weather phenomena from the TAF period"""
        weather_groups = []
        
        i = 0
        while i < len(parts):
            part = parts[i]
            
            # Check for NSW (No Significant Weather)
            if part == 'NSW':
                weather_groups.append({
                    'intensity': '',
                    'descriptor': '',
                    'phenomena': ['no significant weather']
                })
                parts.pop(i)
                continue
            
            # Process weather groups
            has_weather = False
            intensity = ''
            descriptor = ''
            phenomena = []
            
            # Check for intensity prefix
            if part.startswith('+') or part.startswith('-'):
                if part.startswith('+'):
                    intensity = 'heavy'
                    part = part[1:]
                elif part.startswith('-'):
                    intensity = 'light'
                    part = part[1:]
                has_weather = True
            
            # Check for vicinity (VC)
            elif part.startswith('VC'):
                intensity = 'vicinity'
                part = part[2:]
                has_weather = True
            
            # Check for descriptor
            for desc_code, desc_value in self.WEATHER_DESCRIPTORS.items():
                if part.startswith(desc_code):
                    descriptor = desc_value
                    part = part[len(desc_code):]
                    has_weather = True
                    break
            
            # Handle the case where the part is just 'TS' (thunderstorm without precipitation)
            if part == 'TS':
                descriptor = 'thunderstorm'
                has_weather = True
                part = ''
            
            # Check for weather phenomena
            remaining = part
            while remaining and len(remaining) >= 2:
                code = remaining[:2]
                if code in self.WEATHER_PHENOMENA:
                    phenomena.append(self.WEATHER_PHENOMENA[code])
                    remaining = remaining[2:]
                    has_weather = True
                else:
                    break
            
            if has_weather:
                weather_groups.append({
                    'intensity': intensity,
                    'descriptor': descriptor,
                    'phenomena': phenomena
                })
                parts.pop(i)
            else:
                i += 1
        
        return weather_groups
    
    def _extract_sky_conditions(self, parts: List[str]) -> List[Dict]:
        """Extract sky conditions from the TAF period"""
        sky_conditions = []
        
        i = 0
        while i < len(parts):
            part = parts[i]
            
            # Check for sky condition pattern
            match = re.match(self.SKY_PATTERN, part)
            if match:
                sky_type = match.group(1)
                height = int(match.group(2)) * 100  # Convert to feet
                cloud_type = match.group(3) or None
                
                sky = {
                    'type': sky_type,
                    'height': height
                }
                
                if cloud_type == 'CB':
                    sky['cb'] = True
                elif cloud_type == 'TCU':
                    sky['tcu'] = True
                
                sky_conditions.append(sky)
                parts.pop(i)
                continue
            
            # Check for no cloud codes
            elif part in ['SKC', 'CLR', 'NSC', 'NCD']:
                sky_conditions.append({
                    'type': part,
                    'height': None
                })
                parts.pop(i)
                continue
            
            i += 1
        
        return sky_conditions
    
    def _extract_qnh(self, parts: List[str]) -> Optional[Dict]:
        """Extract QNH (pressure setting) information from the TAF period"""
        qnh_pattern = r'Q(\d{4})'  # Updated to match Q followed by 4 digits
        
        for i, part in enumerate(parts):
            match = re.match(qnh_pattern, part)
            if match:
                qnh_value = int(match.group(1))
                
                # For QNH in hPa, the value is typically between 900-1050
                if qnh_value >= 900 and qnh_value <= 1050:
                    unit = 'hPa'
                else:
                    # For inches of mercury in hundredths (e.g., Q2992 = 29.92 inHg)
                    unit = 'inHg'
                    qnh_value = qnh_value / 100.0  # Convert to decimal format
                
                qnh = {
                    'value': qnh_value,
                    'unit': unit
                }
                
                parts.pop(i)
                return qnh
        
        # Also check for alternative QNH formats
        alt_qnh_pattern = r'QNH(\d{4})(?:INS|HPa)?'
        
        for i, part in enumerate(parts):
            match = re.match(alt_qnh_pattern, part)
            if match:
                qnh_value = int(match.group(1))
                
                # Determine unit based on value and suffix
                unit = 'inHg'
                if 'HPa' in part:
                    unit = 'hPa'
                
                # Format value based on unit
                formatted_value = qnh_value
                if unit == 'inHg':
                    formatted_value = qnh_value / 100.0  # Convert to decimal format
                
                qnh = {
                    'value': formatted_value,
                    'unit': unit
                }
                
                parts.pop(i)
                return qnh
        
        # Try A prefix (US-style altimeter)
        alt_pattern = r'A(\d{4})'
        
        for i, part in enumerate(parts):
            match = re.match(alt_pattern, part)
            if match:
                qnh_value = int(match.group(1))
                qnh_value = qnh_value / 100.0  # Convert to decimal format
                
                qnh = {
                    'value': qnh_value,
                    'unit': 'inHg'
                }
                
                parts.pop(i)
                return qnh
        
        return None
    
    def _decode_remarks(self, taf: str) -> Tuple[str, Dict]:
        """Extract and decode the remarks section"""
        match = re.search(self.REMARKS_PATTERN, taf)
        if match:
            remarks = match.group(1)
            
            # Attempt to decode common remarks
            decoded = {}
            
            # Check for specific patterns
            
            # Next forecast information
            nxt_fcst_match = re.search(r'NXT\s+FCST\s+BY\s+(\d{2})Z', remarks)
            if nxt_fcst_match:
                decoded['Next Forecast'] = f"Next forecast will be issued by {nxt_fcst_match.group(1)}:00 UTC"
            
            # Lightning observations
            if 'LTG OBS' in remarks:
                decoded['Lightning'] = "Lightning observed in vicinity"
            
            # Split remarks into individual codes
            remark_codes = remarks.split()
            
            for code in remark_codes:
                # Airport-specific remarks often use airport codes or local abbreviations
                if len(code) == 3 and code.isalpha() and code not in ['RMK', 'NXT', 'OBS', 'LTG', 'AMD', 'COR']:
                    if 'Local Codes' not in decoded:
                        decoded['Local Codes'] = []
                    decoded['Local Codes'].append(code)
                
                # Handle wind shear remarks
                elif code.startswith('WS'):
                    decoded['Wind Shear'] = "Wind shear reported"
                
                # Handle forecast confidence remarks
                elif code in ['CNF', 'CNF+', 'CNF-']:
                    confidence = "normal"
                    if code == 'CNF+':
                        confidence = "high"
                    elif code == 'CNF-':
                        confidence = "low"
                    decoded['Forecast Confidence'] = confidence
                
                # Handle ICAO confidence remarks (70%, 80%, etc.)
                elif re.match(r'C\d{1,2}', code):
                    confidence_pct = code[1:]
                    decoded['Confidence'] = f"{confidence_pct}%"
                
                # Maintenance indicator
                elif code == 'AMD':
                    decoded['Amendment'] = "Forecast has been amended"
                
                # COR - Correction to previously issued forecast
                elif code == 'COR':
                    decoded['Correction'] = "Correction to previously issued forecast"
            
            return remarks, decoded
        else:
            return "", {}


def main():
    """Main function to run the TAF decoder from command line"""
    parser = argparse.ArgumentParser(description='TAF Decoder - Parse and decode TAF weather reports')
    parser.add_argument('taf', nargs='?', help='Raw TAF string to decode')
    parser.add_argument('-f', '--file', help='File containing TAF strings (one per line)')
    
    args = parser.parse_args()
    
    decoder = TafDecoder()
    
    if args.file:
        try:
            with open(args.file, 'r') as f:
                for line in f:
                    taf = line.strip()
                    if taf:
                        decoded = decoder.decode(taf)
                        print(f"\n{'='*50}")
                        print(decoded)
        except FileNotFoundError:
            print(f"Error: File {args.file} not found.")
    elif args.taf:
        decoded = decoder.decode(args.taf)
        print(decoded)
    else:
        # Interactive mode
        print("TAF Decoder - Enter a TAF string to decode (press Ctrl+C to exit):")
        try:
            while True:
                taf = input("> ")
                if taf:
                    decoded = decoder.decode(taf)
                    print(decoded)
                    print()
        except KeyboardInterrupt:
            print("\nExiting...")


if __name__ == "__main__":
    main() 