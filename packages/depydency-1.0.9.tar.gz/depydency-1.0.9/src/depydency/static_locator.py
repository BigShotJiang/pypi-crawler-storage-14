from typing import Type, Any
from depydency.abc_locator_interface import AbcLocatorInterface
from depydency.inject import Inject


class StaticLocator:

    locator: AbcLocatorInterface

    @classmethod
    def get_by_type[DependencyType](
        cls, dependency_type: Type[DependencyType],
        unique_instance: bool = False,
        default_implementation: Type | None = None,
    ) -> DependencyType:
        return cls.locator.get_by_type(dependency_type, unique_instance, default_implementation)
        
    @classmethod
    def get_by_name(
        cls, dependency_name: str,
        unique_instance: bool = False,
        default_value: Any = None,
    ) -> Any:
        return cls.locator.get_by_name(dependency_name, unique_instance, default_value)
