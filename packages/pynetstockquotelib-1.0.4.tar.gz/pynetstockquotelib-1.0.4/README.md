# PyNetstockQuoteLib简介<br>

一款台湾金融市场的证券，期货，期权多合一的轻量级报价API模块，由台湾Netstock公司开发，做到极致化的高效和轻量级。整包大小仅有不到200kb。<br>

**安装方法：pip install PyNetstockQuoteLib**<br>
申请账号请访问公司网站：https://www.netstock.net/<br>
电话：+886-2-25775688<br>
地址：台灣‧台北市松山區105敦化南路一段21號2樓<br>

## 函数列表：<br>
**1，连接**<br>
`def Connect(Address: str, nPort: unsigned short)-> bool: ...`<br>
**2，断开连接**<br>
`def Disconnect() -> None: ...`<br>
**3，登录**<br>
`def Login(UserName: str, Password: str, Software: str, Version: str, Company: str, Branch: str) -> None: ...`<br>
**4，运行阻塞函数**<br>
`def Go() -> None: ...`<br>
**5，注册报价函数**<br>
`def SubscribeToQuote(Symbol: str, Exc: int, sExc: int = -1, rlot:bool = False) -> int: ...`<br>
**6，关闭注册报价**<br>
`def CloseSubscribe(Index: int) -> bool: ...`<br>
**7，注册Tick函数**<br>
`def SubscribeToTick(Symbol: str, Exc: int, sExc: int = -1, rlot:bool = False) -> int: ...`<br>
**8，获得报价**<br>
`def GetQuote(Index: int, Field: int) -> int | float: ...`<br>
**9，获得Tick数据**<br>
`def GetTick(Index:int)-> List[Dict[str, Union[int, float]]]: ...`<br>
**10，获得基本资料(9-16)**<br>
`def GetInfo(Exc:int, Symbol:str, Field:str, sExc:int)-> str: ...`<br>
**11，设置主动回报callback**<br>
`def SetNoticeCallback(callback: Callable[[int, int, object, int], None]) -> None: ...`<br>
**12，设置登录回报函数**<br>
`def SetLoginCallback(callback: Callable[[int, str, int], None]) -> None: ...`<br>
**13，设置交易日资讯回报函数**<br>
`def SetExcInfoCallback(callback: Callable[[int, int], None]) -> None: ...`<br>
**14，设置基本资料更新回报函数**<br>
`def SetStkiCallback(callback: Callable[[int, int, int], None]) -> None: ...`<br>
**15，设置报价回报callback**<br>
`def SetQuoteCallback(callback: Callable[[int, int], None]) -> None: ...`<br>
**16，设置Tick回报函数**<br>
`def SetTickCallback(callback: Callable[[int], None]) -> None: ...`<br>

## 示例1：Quote.py<br>
```python
import PyNetstockQuoteLib as NsQuote

Ind = 0
Ind1 = 0
#登录回报
def OnLogin(Type,pInfo,InfoSize):
    if(Type == 25):
        global Ind,Ind1
        print("登录成功!")
        #登录成功后对商品进行报价订阅
        Ind = NsQuote.SubscribeToQuote("FITX",12,2)
        Ind1 = NsQuote.SubscribeToQuote("2330",1)
    else:
        print("登录失败")        
#报价回报
def OnQuote(Index,Type):
    if(Type == 1):
        global Ind,Ind1
        if(Index == Ind):
            print("Sym:FITX,Last:" + str(NsQuote.GetQuote(Index,4)) + ",Vol:" + str(NsQuote.GetQuote(Index,8)))
        if(Index == Ind1):
            print("Sym:2330,Last:" + str(NsQuote.GetQuote(Index,4)) + ",Vol:" + str(NsQuote.GetQuote(Index,8)))

#启动入口
if NsQuote.Connect("www.netstock.net", 000):
    print("连接成功")
    NsQuote.SetLoginCallback(OnLogin)
    NsQuote.SetQuoteCallback(OnQuote)
    NsQuote.Login("xxxxx", "xxxxx", "csxxx", "0.0", "SNxx", "")
    NsQuote.Go()
else:
    print("连接失败")
print("Over")
```
## 示例2：Tick.py<br>
```python
import PyNetstockQuoteLib as NsQuote

indTick = 0
#登录回报
def OnLogin(Type,pInfo,InfoSize):
    if(Type == 25):
        print("登录成功!")
    else:
        print("登录失败")        
#Tick回报
def OnTick(Index):
    #获得Tick数据,返回字典列表迭代器
    TickList = NsQuote.GetTick(Index)
    #获得Tick总数
    Ticklen = len(TickList)
    count = 0
    #用基本资料获取商品名称
    print(NsQuote.GetInfo(12,"FITX","name"))
    #显示本次Tick信息
    print("Index:" + str(Index) + " TickCount:",str(Ticklen))
    #显示10条数据用于测试
    for Item in TickList:
        print(Item)#Item是字典对象，实际使用时可以用Key取单元数据例如：Item["Last"]
        count = count + 1
        if (count >=10): break
#交易日资讯回报
def OnExcInfo(Type,Exc):
    if(Exc == 12):#收到对应市场交易日资讯后注册（较为单纯）
        global indTick
        indTick = NsQuote.SubscribeToTick("FITX",12,2)
#程序入口
if NsQuote.Connect("www.netstock.net", 000):
    print("连接成功")
    NsQuote.SetLoginCallback(OnLogin)
    NsQuote.SetExcInfoCallback(OnExcInfo)
    NsQuote.SetTickCallback(OnTick)
    NsQuote.Login("xxxxx", "xxxxx", "csxxx", "0.0", "SNxx", "")
    NsQuote.Go()
else:
    print("连接失败")
print("Over")
```