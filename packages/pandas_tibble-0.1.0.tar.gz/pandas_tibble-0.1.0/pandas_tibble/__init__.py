"""
pandas-tibble: R-style DataFrame display for pandas using Rich

Brings R's tibble() output to Python with beautiful formatting,
type annotations, and rich terminal output.

Author: Casper Crause
License: MIT
"""

from .display import (
    tibble,
    glimpse,
)

__version__ = "0.1.0"
__author__ = "Casper Crause"

__all__ = [
    'tibble',
    'glimpse',
    '__version__',
]
