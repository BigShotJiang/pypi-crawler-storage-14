from yaml import safe_dump

from dyngle.command import DyngleCommand


class ListOperationsCommand(DyngleCommand):
    """List all available operations with their descriptions"""

    name = "list-operations"

    @DyngleCommand.wrap
    def execute(self):
        ops = self.app.dyngleverse.operations
        ops_dict = {key: op.description for key, op in ops.items()}
        output = safe_dump({"operations": ops_dict}, default_flow_style=False)
        self.status = "Operations listed successfully"
        return output.rstrip()
