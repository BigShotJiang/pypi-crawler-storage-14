from .pyalamake import AlaMake

alamake = AlaMake()
