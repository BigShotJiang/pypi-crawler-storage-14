"""Constraint marker classes for Pydantic Field validation.

This module provides type-safe constraint markers that can be used in type annotations
with the Hyper type system. Each constraint class uses __class_getitem__ to create
runtime constraint objects (from annotated_types) while appearing as valid type
expressions to type checkers.

Example:
    from hipr.constraints import Ge, Le
    from hipr.config import Hyper

    def my_function(
        period: Hyper[int, Ge[2], Le[100]] = 14,
        threshold: Hyper[float, Ge[0.0], Le[1.0]] = 0.5,
    ) -> float:
        return period * threshold
"""

from __future__ import annotations

import re

from annotated_types import (
  Ge as AtGe,
)
from annotated_types import (
  Gt as AtGt,
)
from annotated_types import (
  Le as AtLe,
)
from annotated_types import (
  Lt as AtLt,
)
from annotated_types import (
  MaxLen as AtMaxLen,
)
from annotated_types import (
  MinLen as AtMinLen,
)
from annotated_types import (
  MultipleOf as AtMultipleOf,
)


class InvalidPatternError(ValueError):
  """Raised when a regex pattern is invalid."""

  pass


__all__ = [
  "Ge",
  "Gt",
  "InvalidPatternError",
  "Le",
  "Lt",
  "MaxLen",
  "MinLen",
  "MultipleOf",
  "Pattern",
]


class Ge:
  """Greater than or equal constraint marker (for numbers).

  Usage: Ge[value] in type annotations creates a constraint that the
  runtime value must be >= the specified value.

  Example:
      age: Hyper[int, Ge[0]] = 25  # age must be >= 0
  """

  def __class_getitem__(cls, value: float) -> AtGe:
    """Support Ge[2] syntax."""
    if not isinstance(value, (int, float)):
      msg = f"Ge constraint requires a numeric value, got {type(value).__name__}"
      raise TypeError(msg)
    return AtGe(value)


class Le:
  """Less than or equal constraint marker (for numbers).

  Usage: Le[value] in type annotations creates a constraint that the
  runtime value must be <= the specified value.

  Example:
      percentage: Hyper[float, Ge[0.0], Le[100.0]] = 50.0
  """

  def __class_getitem__(cls, value: float) -> AtLe:
    """Support Le[100] syntax."""
    if not isinstance(value, (int, float)):
      msg = f"Le constraint requires a numeric value, got {type(value).__name__}"
      raise TypeError(msg)
    return AtLe(value)


class Gt:
  """Greater than constraint marker (for numbers).

  Usage: Gt[value] in type annotations creates a constraint that the
  runtime value must be > the specified value (strict inequality).

  Example:
      epsilon: Hyper[float, Gt[0.0]] = 1e-9  # epsilon must be > 0
  """

  def __class_getitem__(cls, value: float) -> AtGt:
    """Support Gt[0] syntax."""
    if not isinstance(value, (int, float)):
      msg = f"Gt constraint requires a numeric value, got {type(value).__name__}"
      raise TypeError(msg)
    return AtGt(value)


class Lt:
  """Less than constraint marker (for numbers).

  Usage: Lt[value] in type annotations creates a constraint that the
  runtime value must be < the specified value (strict inequality).

  Example:
      probability: Hyper[float, Ge[0.0], Lt[1.0]] = 0.5
  """

  def __class_getitem__(cls, value: float) -> AtLt:
    """Support Lt[10] syntax."""
    if not isinstance(value, (int, float)):
      msg = f"Lt constraint requires a numeric value, got {type(value).__name__}"
      raise TypeError(msg)
    return AtLt(value)


class MinLen:
  """Minimum length constraint marker (for strings, lists, etc.).

  Usage: MinLen[value] in type annotations creates a constraint that the
  runtime value's length must be >= the specified value.

  Example:
      name: Hyper[str, MinLen[1]] = "default"
  """

  def __class_getitem__(cls, value: int) -> AtMinLen:
    """Support MinLen[5] syntax."""
    if not isinstance(value, int):
      msg = f"MinLen constraint requires an integer, got {type(value).__name__}"
      raise TypeError(msg)
    if value < 0:
      msg = f"MinLen constraint requires a non-negative integer, got {value}"
      raise ValueError(msg)
    return AtMinLen(value)


class MaxLen:
  """Maximum length constraint marker (for strings, lists, etc.).

  Usage: MaxLen[value] in type annotations creates a constraint that the
  runtime value's length must be <= the specified value.

  Example:
      name: Hyper[str, MinLen[1], MaxLen[100]] = "default"
  """

  def __class_getitem__(cls, value: int) -> AtMaxLen:
    """Support MaxLen[100] syntax."""
    if not isinstance(value, int):
      msg = f"MaxLen constraint requires an integer, got {type(value).__name__}"
      raise TypeError(msg)
    if value < 0:
      msg = f"MaxLen constraint requires a non-negative integer, got {value}"
      raise ValueError(msg)
    return AtMaxLen(value)


class Pattern:
  """Regex pattern constraint marker (for strings).

  Usage: Pattern[regex] in type annotations creates a constraint that the
  runtime string value must match the specified regex pattern.

  Example:
      code: Hyper[str, Pattern[r'^[A-Z]{3}$']] = "USD"

  Note: This constraint uses a tuple format ("pattern", regex) rather than
  an annotated_types object because annotated_types doesn't have a direct
  Pattern equivalent. Pydantic understands the "pattern" field constraint
  directly. This approach is consistent with Pydantic v2's field validation.
  """

  def __class_getitem__(cls, regex: str) -> tuple[str, str]:
    """Support Pattern[r'^[a-z]+$'] syntax.

    Returns a tuple for Pydantic field validation.

    Raises:
      TypeError: If regex is not a string
      InvalidPatternError: If regex pattern is invalid
    """
    if not isinstance(regex, str):
      msg = f"Pattern constraint requires a string, got {type(regex).__name__}"
      raise TypeError(msg)

    # Validate regex pattern
    try:
      re.compile(regex)
    except re.error as e:
      msg = f"Invalid regex pattern '{regex}': {e}"
      raise InvalidPatternError(msg) from e

    return ("pattern", regex)


class MultipleOf:
  """Multiple of constraint marker (for numbers).

  Usage: MultipleOf[value] in type annotations creates a constraint that the
  runtime value must be a multiple of the specified value.

  Example:
      batch_size: Hyper[int, Ge[1], MultipleOf[8]] = 32
  """

  def __class_getitem__(cls, value: float) -> AtMultipleOf:
    """Support MultipleOf[5] syntax."""
    if not isinstance(value, (int, float)):
      type_name = type(value).__name__
      msg = f"MultipleOf constraint requires a numeric value, got {type_name}"
      raise TypeError(msg)
    if value <= 0:
      msg = f"MultipleOf constraint requires a positive value, got {value}"
      raise ValueError(msg)
    return AtMultipleOf(value)
