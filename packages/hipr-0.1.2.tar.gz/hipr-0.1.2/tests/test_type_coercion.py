"""Test type coercion and type mismatch handling."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from hipr import Ge, Hyper, Le, configurable


def test_string_to_int_coercion() -> None:
  """Test that numeric strings are coerced to int."""

  @configurable
  def process(value: Hyper[int] = 10) -> int:
    return value * 2

  # Pydantic should coerce string to int
  config = process.Config(value="42")  # type: ignore[arg-type]
  assert config.value == 42  # type: ignore[attr-defined]
  assert isinstance(config.value, int)  # type: ignore[attr-defined]


def test_invalid_string_to_int_fails() -> None:
  """Test that non-numeric strings fail validation."""

  @configurable
  def process(value: Hyper[int] = 10) -> int:
    return value

  with pytest.raises(ValidationError):
    process.Config(value="not_a_number")  # type: ignore[arg-type]


def test_float_to_int_coercion() -> None:
  """Test float to int coercion behavior."""

  @configurable
  def process(value: Hyper[int] = 10) -> int:
    return value

  # Pydantic should coerce clean float to int
  config = process.Config(value=42.0)  # type: ignore[arg-type]
  assert config.value == 42  # type: ignore[attr-defined]

  # Fractional float should fail
  with pytest.raises(ValidationError):
    process.Config(value=42.5)  # type: ignore[arg-type]


def test_int_to_float_coercion() -> None:
  """Test int to float coercion."""

  @configurable
  def process(value: Hyper[float] = 1.0) -> float:
    return value

  # Int should coerce to float
  config = process.Config(value=42)  # type: ignore[arg-type]
  assert config.value == 42.0  # type: ignore[attr-defined]
  assert isinstance(config.value, float)  # type: ignore[attr-defined]


def test_bool_to_int_coercion() -> None:
  """Test bool to int coercion behavior."""

  @configurable
  def process(value: Hyper[int] = 10) -> int:
    return value

  # True should become 1, False should become 0
  config_true = process.Config(value=True)  # type: ignore[arg-type]
  assert config_true.value == 1  # type: ignore[attr-defined]

  config_false = process.Config(value=False)  # type: ignore[arg-type]
  assert config_false.value == 0  # type: ignore[attr-defined]


def test_list_type_mismatch() -> None:
  """Test that wrong list element types fail validation."""

  @configurable
  def process(values: Hyper[list[int]] = [1, 2, 3]) -> int:
    return sum(values)

  # List of strings should fail
  with pytest.raises(ValidationError):
    process.Config(values=["a", "b", "c"])  # type: ignore[arg-type]

  # Mixed types should coerce if possible
  config = process.Config(values=[1, 2.0, "3"])  # type: ignore[arg-type,list-item]
  assert config.values == [1, 2, 3]  # type: ignore[attr-defined]


def test_dict_type_mismatch() -> None:
  """Test dict type validation."""

  @configurable
  def process(
    mapping: Hyper[dict[str, int]] = {"a": 1},
  ) -> int:
    return sum(mapping.values())

  # Wrong value types should coerce
  config = process.Config(mapping={"x": "10", "y": 20})  # type: ignore[arg-type,dict-item]
  assert config.mapping == {"x": 10, "y": 20}  # type: ignore[attr-defined]


def test_constraint_on_coerced_value() -> None:
  """Test that constraints apply after type coercion."""

  @configurable
  def process(value: Hyper[int, Ge[0], Le[100]] = 50) -> int:
    return value

  # String "10" should coerce to int 10 and pass constraints
  config = process.Config(value="10")  # type: ignore[arg-type]
  assert config.value == 10  # type: ignore[attr-defined]

  # String "200" should coerce to int 200 but fail Le[100] constraint
  with pytest.raises(ValidationError):
    process.Config(value="200")  # type: ignore[arg-type]


def test_numeric_string_with_whitespace() -> None:
  """Test that numeric strings with whitespace are handled."""

  @configurable
  def process(value: Hyper[int] = 10) -> int:
    return value

  # Pydantic should strip whitespace and coerce
  config = process.Config(value=" 42 ")  # type: ignore[arg-type]
  assert config.value == 42  # type: ignore[attr-defined]


def test_empty_string_to_int_fails() -> None:
  """Test that empty string to int fails."""

  @configurable
  def process(value: Hyper[int] = 10) -> int:
    return value

  with pytest.raises(ValidationError):
    process.Config(value="")  # type: ignore[arg-type]


def test_list_coercion_from_tuple() -> None:
  """Test that tuples are coerced to lists."""

  @configurable
  def process(values: Hyper[list[int]] = [1, 2, 3]) -> int:
    return sum(values)

  # Tuple should coerce to list
  config = process.Config(values=(10, 20, 30))  # type: ignore[arg-type]
  assert config.values == [10, 20, 30]  # type: ignore[attr-defined]
  assert isinstance(config.values, list)  # type: ignore[attr-defined]


def test_float_string_to_float() -> None:
  """Test float string coercion."""

  @configurable
  def process(value: Hyper[float] = 1.0) -> float:
    return value

  # Float string should coerce
  config = process.Config(value="3.14")  # type: ignore[arg-type]
  assert config.value == pytest.approx(3.14)  # type: ignore[attr-defined]
