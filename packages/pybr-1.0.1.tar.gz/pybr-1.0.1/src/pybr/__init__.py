from .cnpj.cnpj import CNPJ
from .cpf.cpf import CPF

__all__ = ["CPF", "CNPJ"]
