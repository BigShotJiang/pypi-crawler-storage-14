from __future__ import annotations

from abc import abstractmethod, ABC
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..building import Building

class ElevatorLogic(ABC):
    def __init__(self, building: Building) -> None:
        self.building: Building = building

    @abstractmethod
    def assign_elevator_targets(self) -> None:
        pass
