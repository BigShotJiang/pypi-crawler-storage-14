from setuptools import setup, find_packages
import os
import re

# Read version from __init__.py
def get_version():
    init_path = os.path.join(os.path.dirname(__file__), "elevator_traffic_analysis", "__init__.py")
    with open(init_path, "r", encoding="utf-8") as f:
        content = f.read()
        match = re.search(r"^__version__\s*=\s*['\"]([^'\"]*)['\"]", content, re.MULTILINE)
        if match:
            return match.group(1)
        raise RuntimeError("Unable to find version string.")

try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except FileNotFoundError:
    long_description = "A Python package for elevator traffic analysis and simulation"

try:
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]
except FileNotFoundError:
    requirements = []

setup(
    name="elevator-traffic-analysis",
    version=get_version(),
    author="tkosman",
    author_email="tymoteusz4development@gmail.com",
    description="A Python package for elevator traffic analysis and simulation",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tkosman/elevator-traffic-analysis",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    extras_require={
        "dev": ["pytest", "tox"],
    },
    entry_points={
        "console_scripts": [
            "elevator-traffic-analysis=elevator_traffic_analysis.__main__:main",
        ],
    },
    include_package_data=True,
    package_data={
        "elevator_traffic_analysis": [],
    },
    data_files=[
        ("scenarios", ["scenarios/*.yaml"]),
    ],
)