from .parquet_extractor import ParquetExtractorAdapterCVM

__all__ = ["ParquetExtractorAdapterCVM"]
