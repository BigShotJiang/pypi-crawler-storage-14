"""
Sufi AI - Unlimited Free LLM Chat
"""

__version__ = "1.0.2"

import requests

# ←←← Yahan apna API key daal do
API_KEY = "SufiLLM-33990wAGjPP6PpdPm2iApi"

def sufi(message):
    url = "https://sufi-api-llm.vercel.app/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "messages": [{"role": "user", "content": message}]
    }
    
    r = requests.post(url, headers=headers, json=data)
    return r.json()["choices"][0]["message"]["content"]

# Bas itna likho aur chalao
while True:
    msg = input("You: ")
    if msg == "exit": break
    print("Sufi AI:", sufi(msg))
    print("-"*50)