class LevelCompliance:
    def __init__(self, data):
        self.critical = data.get("Critical")
