# sage_setup: distribution = sagemath-repl

from sage.all__sagemath_repl import *
