# sage_setup: distribution = sagemath-repl
# This flag gets set to True by sage.doctest.forker.init_sage at the
# beginning of each doctest run.
DOCTEST_MODE = False
