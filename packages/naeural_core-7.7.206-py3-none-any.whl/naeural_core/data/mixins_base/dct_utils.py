from naeural_core.utils.plugins_base.plugin_base_utils import _UtilsBaseMixin

class _DCTUtilsMixin(_UtilsBaseMixin):

  def __init__(self):
    super(_DCTUtilsMixin, self).__init__()
    return
