LOGGER_NAME = "qiniu-mcp"
