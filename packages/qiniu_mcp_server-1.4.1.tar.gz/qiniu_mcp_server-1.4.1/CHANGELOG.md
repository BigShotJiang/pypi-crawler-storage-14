# v1.4.1
- 直播服务修复query_live_traffic_stats

# v1.4.0
- 直播服务增加更多的tools支持

# v1.3.0
- 支持直播服务

# v1.2.3
- 存储请求链接超时调整为 30s
  
# v1.2.2
- 适配 GPT 4 大模型

# v1.2.1
- 处理多媒体签名问题

# v1.2.0
- 支持文件上传至七牛 Bucket

# v1.1.1
- 支持 AK、SK 为空字符串

# v1.1.0
- 支持不配置 AK、SK、Bucket 

# v1.0.0

- 支持 Kodo 服务
- 支持 Dora 服务
- 支持 CDN 服务