from baai_flagdataset_rs import run_flagdataset


if __name__ == "__main__":
    run_flagdataset()
