import argparse
import time


def with_cmdargs():

    root_parser = argparse.ArgumentParser(add_help=False)

    parser = argparse.ArgumentParser(prog='baai-flagdataset', description="baai-flagdataset 命令行工具: [bf]")
    subparsers = parser.add_subparsers(dest='command')

    init_parser = subparsers.add_parser('init', help='init', parents=[root_parser])
    init_parser.add_argument('--network', type=str, default="private", help='network')
    init_parser.add_argument('--bandwidth', type=int, default="100", help='bandwidth')
    init_parser.add_argument('--parallel', type=int, default="200", help='parallel')
    init_parser.set_defaults(func=init_with_cmdargs)

    # merge
    merge_parser = subparsers.add_parser('merge', help='merge', parents=[root_parser])
    merge_parser.set_defaults(func=merge_with_cmdargs)

    cmd_args = parser.parse_args()
    if hasattr(cmd_args, 'func'):
        try:
            cmd_args.func(cmd_args)
        except Exception: # noqa
            pass
        except KeyboardInterrupt:
            print()
            pass
    else:
        parser.print_help()


def init_with_cmdargs(cmd_args):
    import pathlib

    try:
        from ..baai_helper import baai_print
        from ..baai_flagdataset_rs import multi_download, meta_push, wait_for_completion


        baai_print.print_figlet()

        use_path = pathlib.Path(".").absolute().__str__()
        presign = "http://internal-data.baai.ac.cn/api/v1/storage/sign/download/presign"
        network = cmd_args.network
        bandwidth = cmd_args.bandwidth
        parallel = cmd_args.parallel

        print(f"baai-flagdataset: use_path, {use_path}")
        print(f"baai-flagdataset: presign, {presign}")
        print(f"baai-flagdataset: network, {network}")
        print(f"baai-flagdataset: bandwidth, {bandwidth}")
        print(f"baai-flagdataset: parallel, {parallel}")


        multi_download(use_path, presign, network,bandwidth,  parallel)
        meta_push("---start---")
        for meta_bin in (pathlib.Path(".").absolute()/ "meta").glob("*.bin"):
            time.sleep(1)
            meta_push(meta_bin.name)
        meta_push("---end---")


        wait_for_completion()


    except Exception as e:
        print(e)


def merge_with_cmdargs(_cmd_args):
    import pathlib

    from ..baai_helper import baai_print

    baai_print.print_figlet()


    use_path = pathlib.Path(".")
    meta_path = use_path / "meta"
    temp_path = use_path / "temp"
    list_path = temp_path / "meta.list"

    list_sets = set()
    for meta_bin in meta_path.glob("*.bin"):
        list_sets.add(meta_bin.name)

    with open(list_path, "w") as f:
        f.write("---start---\n")
        for list_set in list_sets:
            f.write(list_set + "\n")
        f.write("---end---")

    print(f"baai-flagdataset, merge: {list_path.absolute().__str__()}, count: {len(list_sets)}")
