# httpdrs-bandwidth

* 限制最大带宽
* 限制下载器并发数量
