baai-flagdataset-rs


该项目是 flagdataset 项目的 rust 核心依赖，封装了下载器相关的功能。


## rust


-  rustup


    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

