# Tests for AVM MCP Server
