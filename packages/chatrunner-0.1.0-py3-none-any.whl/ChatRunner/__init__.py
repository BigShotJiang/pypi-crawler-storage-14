# (C) 2025: Hans Georg Schaathun <hasc@ntnu.no>

"""
ChatRunner is not yet prepared as a package.
The directory contains code to use chatrunner.py as module
loaded from the working directory.
"""
