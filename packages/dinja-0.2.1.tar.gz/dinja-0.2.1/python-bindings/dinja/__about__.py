"""Project Info"""

__version__ = "0.2.1"
__license__ = "BSD 3-Clause"
__author__ = "hlop3z"
