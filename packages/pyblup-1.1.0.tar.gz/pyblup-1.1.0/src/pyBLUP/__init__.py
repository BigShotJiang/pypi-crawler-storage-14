from .mlm import *
from .pca import *
from .kfold import *
from .QC import *
from .gwas import *
from .QK import *
__version__ = "1.1.0"
__author__ = "JingxianFU"