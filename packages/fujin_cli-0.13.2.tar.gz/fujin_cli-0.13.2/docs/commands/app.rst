app
===

.. cappa:: fujin.commands.app.App
   :style: terminal
   :terminal-width: 0