rollback
========

.. cappa:: fujin.commands.rollback.Rollback
   :style: terminal
   :terminal-width: 0

