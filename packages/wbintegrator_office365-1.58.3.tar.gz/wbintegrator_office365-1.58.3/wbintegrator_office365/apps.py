from django.apps import AppConfig


class WbintegratorOffice365Config(AppConfig):
    name = "wbintegrator_office365"
