"""CPC helper."""
