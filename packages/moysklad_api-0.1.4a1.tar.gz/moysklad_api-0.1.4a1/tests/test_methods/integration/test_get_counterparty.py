import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Counterparty
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetCounterparty:
    """
    Example with options: --counterparty-id=1234-5678
    """

    async def test_method(
        self, real_client: MoyskladAPI, counterparty_id: str | None, expand: str | None
    ):
        print(expand)
        counterparty = await real_client.get_counterparty(
            counterparty_id=counterparty_id, expand=expand
        )
        assert isinstance(counterparty, Counterparty)
        assert counterparty.id == counterparty_id
        assert counterparty.name is not None

        if expand:
            assert_expand(expand, counterparty)
