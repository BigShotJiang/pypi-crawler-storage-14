import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Demand, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetDemands:
    async def test_method(
        self, real_client: MoyskladAPI, demand_id: str | None, expand: str | None
    ):
        demands = await real_client.get_demands(expand=expand, paginate=True)
        assert isinstance(demands, MetaArray)
        assert all(isinstance(d, Demand) for d in demands.rows)

        if expand:
            for demand in demands.rows:
                assert_expand(expand, demand)
