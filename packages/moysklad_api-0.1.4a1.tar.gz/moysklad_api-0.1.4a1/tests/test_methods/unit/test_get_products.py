import pytest

from moysklad_api.types import Product
from tests.mocked_client import MockedClient


@pytest.mark.asyncio
@pytest.mark.unit
class TestGetProducts:
    async def test_get_products(self, client: MockedClient):
        res = await client.get_products()
        assert isinstance(res, list)
        assert all(isinstance(p, Product) for p in res)
        assert res[0].name == "Product 1"
        assert res[1].name == "Product 2"
