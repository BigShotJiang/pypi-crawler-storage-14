import asyncio

from moysklad_api import MoyskladAPI


class AddAssortment:
    def __init__(self, token: str):
        self.ms_api = MoyskladAPI(token)

    async def __call__(self, *args, **kwargs):
        assortment = await self.ms_api.get_assortment(paginate=True)

        print(f"Тип assortment: {type(assortment)}")
        print(f"Тип rows: {type(assortment.rows)}")
        if assortment.rows:
            print(f"Тип первого элемента: {type(assortment.rows[0])}")
            print(f"Атрибуты первого элемента: {dir(assortment.rows[0])}")
            print(f"TYPE: {assortment.rows[0].owner.meta.type}")


async def main(token: str):
    add_assortment = AddAssortment(token)
    await add_assortment()


if __name__ == "__main__":
    token = "75e97560af03682a11170b886f4611fb567c7756"

    asyncio.run(main(token))
