from typing import Unpack

from moysklad_api.client.default import DefaultParams
from moysklad_api.client.remap import PRODUCTION
from moysklad_api.client.session import BaseSession, Headers, Method
from moysklad_api.loggers import api
from moysklad_api.methods import (
    GetAssortment,
    GetAudit,
    GetCounterparty,
    GetCurrentStock,
    GetEvents,
    GetProduct,
    GetProducts,
    GetStock,
    GetToken,
    MSMethod,
    T,
    UpdateProduct,
    UpdateProducts,
)
from moysklad_api.methods.base import R
from moysklad_api.methods.get_counterparties import GetCounterparties
from moysklad_api.methods.get_demand import GetDemand
from moysklad_api.methods.get_demands import GetDemands
from moysklad_api.types import (
    Assortment,
    Audit,
    Counterparty,
    CurrentStock,
    Demand,
    MetaArray,
    Product,
    ProductUpdate,
    Stock,
    Token,
)
from moysklad_api.utils.token import validate_token


class MoyskladAPI:
    def __init__(self, token: str, session: BaseSession | None = None, **kwargs):
        """
        MoyskladAPI class

        :param token: Moy Sklad API token, obtain a new one from <https://api.moysklad.ru/api/remap/1.2/security/token>.
        :raise TokenValidationError: When token has invalid format,
            this exception will be raised
        """
        validate_token(token)
        if session is None:
            session = BaseSession(
                base=PRODUCTION.url,
                timeout=PRODUCTION.timeout,
            )

        self.__token = token
        self._session_headers = self._create_session_headers(self.__token)
        self._session = session
        self._session.headers = self._session_headers

    @property
    def session(self) -> BaseSession:
        return self._session

    @property
    def base(self) -> str:
        return self._session.base

    @property
    def timeout(self) -> int:
        return self._session.timeout

    @property
    def headers(self) -> Headers:
        return self._session.headers

    @property
    def token(self) -> str:
        return self.__token

    @classmethod
    async def from_credentials(
        cls, username: str, password: str, session: BaseSession | None = None
    ) -> "MoyskladAPI":
        if session is None:
            session = BaseSession(
                base=PRODUCTION.url,
                timeout=PRODUCTION.timeout,
            )

        dummy_api = cls(token="dummy", session=session)
        token = await dummy_api.get_token(username, password)
        api.warning(
            "A new token has been obtained. "
            f"Use this token :code:`{token.access_token}` "
            f"for subsequent requests."
        )
        return cls(token=token.access_token, session=session)

    async def close(self):
        await self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        import asyncio

        asyncio.run(self.close())

    async def __call__(
        self, method: MSMethod[T], self_method: Method | None = Method.GET
    ) -> T | R:
        return await method.call(self.session, self_method)

    async def get_token(self, username: str, password: str) -> Token:
        call = GetToken(
            username=username,
            password=password,
        )
        return await self(call)

    @staticmethod
    def _create_session_headers(token: str) -> Headers:
        return Headers(token=token)

    async def get_assortment(
        self, **params: Unpack[DefaultParams]
    ) -> MetaArray[Assortment]:
        """
        Use this method to get assortment.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/assortment#3-poluchit-assortiment
        """
        call = GetAssortment(params=params)
        return await self(call)

    async def get_counterparty(
        self, counterparty_id: str, **params: Unpack[DefaultParams]
    ) -> Counterparty:
        """
        Use this method to get counterparty by id.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty#3-poluchit-kontragenta

        :param counterparty_id: ID of the counterparty
        :return: On success, counterparty
        """
        call = GetCounterparty(counterparty_id=counterparty_id, params=params)
        return await self(call)

    async def get_counterparties(
        self, **params: Unpack[DefaultParams]
    ) -> MetaArray[Counterparty]:
        """
        Use this method to get list counterparties.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty#3-poluchit-spisok-kontragentov

        :return: On success, list of counterparties
        """
        call = GetCounterparties(params=params)
        return await self(call)

    async def get_product(
        self, product_id: str, **params: Unpack[DefaultParams]
    ) -> Product:
        """
        Use this method to get product by id.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/dictionaries/#suschnosti-towar

        :param product_id: ID of the product
        :return: On success, product
        """
        call = GetProduct(product_id=product_id, params=params)
        return await self(call)

    async def get_products(self, **params: Unpack[DefaultParams]) -> MetaArray[Product]:
        """
        Use this method to get list of products.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/dictionaries/#suschnosti-towar

        :return: On success, list of products
        """
        call = GetProducts(params=params)
        return await self(call)

    async def update_product(
        self,
        product_id: str,
        name: str | None = None,
        description: str | None = None,
        code: str | None = None,
        external_code: str | None = None,
        archived: bool | None = None,
        article: str | None = None,
        group: str | None = None,
        product_folder: str | None = None,
        sale_prices: list[dict] | None = None,
        attributes: list[dict] | None = None,
        barcodes: list[dict] | None = None,
        min_price: dict | None = None,
        uom: str | None = None,
        tracking_type: str | None = None,
        is_serial_trackable: bool | None = None,
        files: list[dict] | None = None,
        images: list[dict] | None = None,
        packs: list[dict] | None = None,
        owner: str | None = None,
        supplier: str | None = None,
        shared: bool | None = None,
        discount_prohibited: bool | None = None,
        use_parent_vat: bool | None = None,
    ) -> ProductUpdate:
        """
        Use this method to update product.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/dictionaries/#suschnosti-towar

        :param product_id: ID of the product to update
        :param name: Name of the product
        :param description: Description of the product
        :param code: Internal code
        :param external_code: External code
        :param archived: Whether the product is archived
        :param article: Article number
        :param group: Product group ID
        :param product_folder: Product folder ID
        :param sale_prices: List of sale prices
        :param attributes: Custom attributes
        :param barcodes: List of barcodes
        :param min_price: Minimum price
        :param uom: Unit of measurement ID
        :param tracking_type: Tracking type (serial/batch)
        :param is_serial_trackable: Is serial trackable
        :param files: Attached files
        :param images: Attached images
        :param packs: Packaging information
        :param owner: Owner ID
        :param supplier: Supplier ID
        :param shared: Whether the product is shared
        :param discount_prohibited: Is discount prohibited
        :param use_parent_vat: Whether to use parent VAT
        :return: On success, updated product
        """
        call = UpdateProduct(
            product_id=product_id,
            name=name,
            description=description,
            code=code,
            external_code=external_code,
            archived=archived,
            article=article,
            group=group,
            product_folder=product_folder,
            sale_prices=sale_prices,
            attributes=attributes,
            barcodes=barcodes,
            min_price=min_price,
            uom=uom,
            tracking_type=tracking_type,
            is_serial_trackable=is_serial_trackable,
            files=files,
            images=images,
            packs=packs,
            owner=owner,
            supplier=supplier,
            shared=shared,
            discount_prohibited=discount_prohibited,
            use_parent_vat=use_parent_vat,
        )
        return await self(call, self_method=Method.PUT)

    async def update_products(
        self, products: list[ProductUpdate]
    ) -> list[ProductUpdate]:
        """
        Use this method to mass update products.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/dictionaries/#suschnosti-towar-massowoe-sozdanie-i-obnowlenie-towarow

        :param products: List products to update
        :return: On success, updated products
        """
        call = UpdateProducts(
            products=products,
        )
        return await self(call, self_method=Method.POST)

    async def get_stock(
        self,
        current: bool = True,
        **params: Unpack[DefaultParams],
    ) -> CurrentStock | MetaArray[Stock]:
        """
        Use this method to get current stock.

        :param current: A brief inventory report is a report that only shows
            the assortment id and whether it is in stock,
            in reserve, or on hold at the time of the request.
        :param params:
        :return:
        """
        call = GetCurrentStock(params=params)
        if not current:
            call = GetStock(params=params)
        return await self(call)

    async def get_demand(
        self,
        demand_id: str,
        **params: Unpack[DefaultParams],
    ) -> Demand:
        """
        Use this method to get demand by id.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand#3-poluchit-otgruzku
        """
        call = GetDemand(demand_id=demand_id, params=params)
        return await self(call)

    async def get_demands(
        self,
        **params: Unpack[DefaultParams],
    ) -> MetaArray[Demand]:
        """
        Use this method to get list of demands.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand#3-poluchit-spisok-otgruzok
        """
        call = GetDemands(params=params)
        return await self(call)

    async def get_audit(
        self,
        audit_id: str,
        get_events: bool = False,
        **params: Unpack[DefaultParams],
    ) -> Audit:
        """
        Use this method to get audit by id.

        Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/audit/audit#1-audit

        :param audit_id:
        :param get_events:
        :return:
        """
        if get_events:
            call = GetEvents(audit_id=audit_id, params=params)
            return await self(call)
        call = GetAudit(audit_id=audit_id, params=params)
        return await self(call)
