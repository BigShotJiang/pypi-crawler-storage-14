from moysklad_api.methods import MSMethod
from moysklad_api.types import Demand, MetaArray


class GetDemands(MSMethod):
    """
    Use this method to get list of demands.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand#3-poluchit-spisok-otgruzok
    """

    __return__ = MetaArray[Demand]
    __api_method__ = "entity/demand"
