from enum import Enum


class EntityType(Enum):
    pass
