from pydantic import BaseModel


class Report(BaseModel):
    pass
