from whisper_assistant.packages.transcriber.main import Transcriber

__all__ = ["Transcriber"]
