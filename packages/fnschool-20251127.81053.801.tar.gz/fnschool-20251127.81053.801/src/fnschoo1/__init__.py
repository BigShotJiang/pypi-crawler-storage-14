#!/usr/bin/env python3
"""Django's command-line utility for administrative tasks."""
import os
import platform
import random
import sys
from pathlib import Path

__version__ = "20251127.81053.801"
