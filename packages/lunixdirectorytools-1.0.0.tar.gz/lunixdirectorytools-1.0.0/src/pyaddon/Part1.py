import os
import sys
import shutil

def main_script_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:

        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
def pwd():
    print(os.listdir(os.getcwd()))
def cd(PATH_TO_NEW_DIRECTORY):
    try:
        if not os.path.exists(PATH_TO_NEW_DIRECTORY):
            os.chdir(PATH_TO_NEW_DIRECTORY)
        else:
            print("It is not an directory.Please enter a path")
    except NotADirectoryError:
        print("It is not an directory")
def ls(PATH):
    try:
        if not os.path.exists(PATH):
            os.listdir(PATH)
        else:
            print("It is not an directory.Please enter a path")
    except NotADirectoryError:
        print("It is not an directory")
def mkdir(Directory_Path):
    try:
        if not os.path.exists(Directory_Path):
            os.mkdir(Directory_Path)
        else:
            print("It is not an directory.Please enter a directory_name")
    except NotADirectoryError:
        print("It is not an directory")
def rmdir(Directory_path):
    try:
        if os.path.exists(Directory_path):
            os.rmdir(Directory_path)
        else:
            print("It is not an directory.Please enter a path")
    except NotADirectoryError:
        print("It is not an directory")
def mkdirs(Directory_PATH):
    try:
        if os.path.exists(Directory_PATH):
            os.makedirs(Directory_PATH)
        else:
            print("It is not an directory.Please enter a path")
    except NotADirectoryError:
        print("It is not an directory")
def du(Directory_PATH):
    try:
        if not os.path.exists(Directory_PATH):
            os.path.getsize(Directory_PATH)
        else:
            print("It is not an directory.Please enter a path")
    except NotADirectoryError:
        print("It is not an directory")
def df(Directory_PATH):
    total, used, free = shutil.disk_usage(Directory_PATH)
    print(f"Path: {Directory_PATH}")
    print(f"Total: {total // (1024**3)} GB")
    print(f"Used: {used // (1024**3)} GB")
    print(f"Free: {free // (1024**3)} GB")

