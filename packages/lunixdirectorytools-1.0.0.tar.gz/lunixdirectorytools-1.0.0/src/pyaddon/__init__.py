# 1. Define the package version number 
__version__ = "0.1.0" 

# 2. Expose Public API 

# CORRECT: Imports the *function* 'mkdir' from the *module* 'dir.py'


__all__ = [
    "mkdir"
]