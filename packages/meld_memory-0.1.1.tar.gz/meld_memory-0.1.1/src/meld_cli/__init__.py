"""Meld CLI - Personal memory system for Claude Code."""

__version__ = "0.1.0"

