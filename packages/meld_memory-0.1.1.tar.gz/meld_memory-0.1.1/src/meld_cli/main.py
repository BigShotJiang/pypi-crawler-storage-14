"""Meld CLI - Main entry point."""

import asyncio
import json
import subprocess
import sys
import webbrowser
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .api import MeldAPI, MeldAPIError
from .config import (
    clear_credentials,
    get_api_url,
    load_credentials,
    save_credentials,
)

console = Console()


@click.group()
@click.version_option()
def cli():
    """Meld - Personal memory system for Claude Code."""
    pass


@cli.command()
def login():
    """Log in to Meld via browser."""
    console.print(Panel.fit("[bold]Meld Login[/bold]"))

    # Check if already logged in
    creds = load_credentials()
    if creds:
        console.print(f"[yellow]Already logged in as {creds.get('email', 'unknown')}[/yellow]")
        if not click.confirm("Log in again?", default=False):
            return

    # Open the sign-in page served by the API
    signin_url = f"{get_api_url()}/signin"

    console.print(f"\n[bold]Opening browser for sign-in...[/bold]")
    webbrowser.open(signin_url)

    console.print(f"Opened: {signin_url}\n")
    console.print("Sign in and copy the token shown on the page.")
    console.print("")

    token = click.prompt("Paste your Clerk session token")

    if not token:
        console.print("[red]No token provided[/red]")
        return

    # Exchange the short-lived Clerk token for a long-lived Meld token
    api = MeldAPI(token=token)

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Exchanging token...", total=None)
            result = asyncio.run(api.exchange_token())
            progress.remove_task(task)

        if "error" in result:
            console.print(f"[red]Error: {result.get('error')}[/red]")
            return

        # Save the long-lived Meld token
        save_credentials(
            token=result.get("access_token", ""),
            user_id=result.get("user_id", ""),
            email=result.get("email", ""),
        )

        expires_days = result.get("expires_in", 0) // 86400
        console.print(f"\n[green]✓[/green] Logged in as {result.get('email', 'user')}")
        console.print(f"[dim]Token valid for {expires_days} days[/dim]")

    except MeldAPIError as e:
        console.print(f"[red]Login failed: {e.message}[/red]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


@cli.command()
def logout():
    """Log out and clear credentials."""
    clear_credentials()
    console.print("[green]✓[/green] Logged out successfully")


@cli.command()
def status():
    """Check Meld status and connection."""
    creds = load_credentials()

    console.print(Panel.fit("[bold]Meld Status[/bold]"))

    # Check credentials
    if creds:
        console.print(f"[green]✓[/green] Logged in as: {creds.get('email', 'unknown')}")
    else:
        console.print("[yellow]⚠[/yellow] Not logged in. Run [bold]meld login[/bold]")
        return

    # Check API connection
    api = MeldAPI()

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Checking API connection...", total=None)
            health = asyncio.run(api.health_check())
            progress.remove_task(task)

        if health.get("status") == "healthy":
            console.print(f"[green]✓[/green] API: Connected ({get_api_url()})")
        else:
            console.print(f"[yellow]⚠[/yellow] API: {health}")
    except Exception as e:
        console.print(f"[red]✗[/red] API: Connection failed - {e}")
        return

    # Get user state
    try:
        state = asyncio.run(api.get_user_state())
        console.print(f"\n[bold]User State:[/bold] {state.get('state')}")
        console.print(f"  Projects: {state.get('content_counts', {}).get('projects', 0)}")
        console.print(f"  Memories: {state.get('content_counts', {}).get('memories', 0)}")

        checkin_info = state.get("checkin_info") or {}
        if checkin_info.get("suggested"):
            console.print(
                f"\n[yellow]ℹ[/yellow] Check-in suggested: {state.get('greeting')}"
            )
    except MeldAPIError as e:
        console.print(f"[red]✗[/red] Failed to get user state: {e.message}")


@cli.command()
def setup():
    """Configure Claude Code to use Meld."""
    console.print(Panel.fit("[bold]Meld Setup for Claude Code[/bold]"))

    # Check if logged in
    creds = load_credentials()
    if not creds:
        console.print("[yellow]⚠[/yellow] Not logged in. Run [bold]meld login[/bold] first.")
        return

    # Claude Code uses two config files:
    # - ~/.claude.json for MCP servers
    # - ~/.claude/settings.json for hooks
    claude_mcp_file = Path.home() / ".claude.json"
    claude_settings_dir = Path.home() / ".claude"
    claude_settings_file = claude_settings_dir / "settings.json"

    if not claude_settings_dir.exists():
        console.print("[yellow]⚠[/yellow] Claude Code not detected (~/.claude not found)")
        console.print("Make sure Claude Code is installed and has been run at least once.")
        return

    console.print(f"[green]✓[/green] Found Claude Code at {claude_settings_dir}")

    # Use the current Python executable (the one running meld)
    # This ensures Claude Code uses the Python that has meld_mcp installed
    python_path = sys.executable

    # Verify meld_mcp is importable from this Python
    result = subprocess.run(
        [python_path, "-c", "import meld_mcp"],
        capture_output=True,
    )
    if result.returncode != 0:
        console.print("[red]✗[/red] meld_mcp not found in this Python installation")
        console.print(f"[dim]Python: {python_path}[/dim]")
        console.print("[yellow]Try: pip install meld-mcp[/yellow]")
        return

    console.print(f"[dim]Using Python: {python_path}[/dim]")

    # === Configure MCP server in ~/.claude.json ===
    mcp_config = {}
    if claude_mcp_file.exists():
        try:
            mcp_config = json.loads(claude_mcp_file.read_text())
        except Exception:
            pass

    if "mcpServers" not in mcp_config:
        mcp_config["mcpServers"] = {}

    # Check if meld is already configured
    if "meld" in mcp_config.get("mcpServers", {}):
        console.print("[green]✓[/green] Meld MCP server already configured")
        if not click.confirm("Update configuration?", default=False):
            return

    mcp_config["mcpServers"]["meld"] = {
        "type": "stdio",
        "command": python_path,
        "args": ["-m", "meld_mcp"],
        "env": {
            "MELD_API_URL": get_api_url(),
        },
        # Auto-approve all meld tools to reduce friction
        "alwaysAllow": [
            "meld_hello",
            "meld_start_checkin",
            "meld_checkin_respond",
            "meld_remember",
            "meld_recall",
            "meld_get_profile",
            "meld_set_slot",
            "meld_list_projects",
            "meld_create_project",
            "meld_update_project",
            "meld_add_interest",
        ],
    }

    claude_mcp_file.write_text(json.dumps(mcp_config, indent=2))
    console.print("[green]✓[/green] Added Meld MCP server to ~/.claude.json")

    # === Configure hooks in ~/.claude/settings.json ===
    settings = {}
    if claude_settings_file.exists():
        try:
            settings = json.loads(claude_settings_file.read_text())
        except Exception:
            pass

    hooks = settings.get("hooks", {})
    if "UserPromptSubmit" not in hooks:
        hooks["UserPromptSubmit"] = []

    # Remove any existing meld_mcp hooks (to update the Python path)
    # Match specifically on "meld_mcp" to avoid removing unrelated hooks
    hooks["UserPromptSubmit"] = [
        hook for hook in hooks.get("UserPromptSubmit", [])
        if "meld_mcp" not in str(hook.get("hooks", []))
    ]

    # Add meld session hook with correct Python path
    hooks["UserPromptSubmit"].append({
        "hooks": [
            {
                "type": "command",
                "command": f"{python_path} -m meld_mcp.hooks",
                "timeout": 5,
            }
        ]
    })
    settings["hooks"] = hooks

    claude_settings_file.write_text(json.dumps(settings, indent=2))
    console.print("[green]✓[/green] Added session hook to ~/.claude/settings.json")

    console.print("\n[bold green]Setup complete![/bold green]")
    console.print("\nRestart Claude Code to activate Meld.")
    console.print("On first prompt, Meld will greet you and offer onboarding.")


@cli.command()
def whoami():
    """Show current user info."""
    creds = load_credentials()
    if not creds:
        console.print("Not logged in. Run [bold]meld login[/bold]")
        return

    console.print(f"Email: {creds.get('email')}")
    console.print(f"User ID: {creds.get('user_id')}")


@cli.command()
def reset():
    """Reset all your Meld data (for testing fresh user experience)."""
    creds = load_credentials()
    if not creds:
        console.print("[yellow]⚠[/yellow] Not logged in. Run [bold]meld login[/bold] first.")
        return

    console.print("[yellow]⚠ This will delete ALL your Meld data:[/yellow]")
    console.print("  - Profile slots (name, etc.)")
    console.print("  - Projects")
    console.print("  - Memories")
    console.print("  - Check-in history")
    console.print("")

    if not click.confirm("Are you sure you want to reset?", default=False):
        console.print("Cancelled.")
        return

    api = MeldAPI()

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Resetting data...", total=None)
            result = asyncio.run(api.reset_user())
            progress.remove_task(task)

        if result.get("reset"):
            # Clear local session markers
            import shutil
            session_dir = Path("/tmp/meld-sessions")
            if session_dir.exists():
                shutil.rmtree(session_dir)

            # Clear local credentials (full reset)
            clear_credentials()

            console.print("\n[green]✓[/green] All data cleared!")
            console.print("Run [bold]meld login[/bold] to start fresh.")
        else:
            console.print(f"[red]Error: {result}[/red]")

    except MeldAPIError as e:
        console.print(f"[red]Reset failed: {e.message}[/red]")
    except Exception as e:
        console.print(f"[red]Error: {e}[/red]")


if __name__ == "__main__":
    cli()
