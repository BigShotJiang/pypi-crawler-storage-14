legumes = [
    "pea",
    "chickpea",
    "bean",
    "lentil",
    "edamame",
    "sprout",
    r"dh?al",
    "rajma",
    "alfalfa",
    "chana",
    "kudzu",
    "pulse",
]
