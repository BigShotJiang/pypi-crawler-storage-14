#!/usr/bin/env python
"""
DjangX CLI.

Provides the management commands interface for DjangX.
"""

import os
import sys
from pathlib import Path

from django.core.management import ManagementUtility

from .conf.management.path import BasePath


def main() -> None:
    """Main entry point for the DjangX CLI."""

    sys.path.insert(0, str(BasePath().base_dir))
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "djangx.conf.settings")

    utility = ManagementUtility(sys.argv)
    utility.prog_name = "djx" if Path(sys.argv[0]).stem.lower() == "djx" else "djangx"
    utility.execute()


if __name__ == "__main__":
    main()
