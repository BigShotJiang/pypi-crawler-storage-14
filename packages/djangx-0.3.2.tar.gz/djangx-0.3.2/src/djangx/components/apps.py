from django.apps import AppConfig


class DjangXComponentsConfig(AppConfig):
    name = "djangx.components"
