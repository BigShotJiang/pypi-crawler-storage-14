import sys
from pathlib import Path
from typing import Optional

from django.core.management.color import color_style


class BasePath:
    """Directory path configuration and validation of DjangX app project structure."""

    def __init__(self):
        self._cwd = Path.cwd()
        self._base_dir: Optional[Path] = None
        self._is_base_dir: Optional[bool] = None

    def _detect_base_dir(self) -> None:
        """Detect if we're in a valid DjangX project and cache the results."""
        apps_py = self._cwd / "app" / "apps.py"

        if apps_py.exists():
            try:
                with open(apps_py, "r", encoding="utf-8") as f:
                    content = f.read()
                if "DjangXAppConfig" in content:
                    self._base_dir = apps_py.resolve().parent.parent
                    self._is_base_dir = True
                else:
                    self._base_dir = self._cwd
                    self._is_base_dir = False
            except (OSError, UnicodeDecodeError):
                self._base_dir = self._cwd
                self._is_base_dir = False
        else:
            self._base_dir = self._cwd
            self._is_base_dir = False

    @property
    def base_dir(self) -> Path:
        if self._base_dir is None:
            self._detect_base_dir()
        assert self._base_dir is not None
        if self._is_base_dir is False:
            print(
                color_style().WARNING(
                    "Not a DjangX root. Navigate to your project root or initialize a new DjangX app."
                )
            )
            sys.exit(1)
        return self._base_dir
