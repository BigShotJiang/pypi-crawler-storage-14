KeyType = str | None
ValueType = str | bool | list | None
TomlSectionType = str | None