"""dspy-cli: A CLI tool for creating and serving DSPy projects."""

__version__ = "0.1.0"
