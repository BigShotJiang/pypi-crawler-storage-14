"""Templates for scaffolding new DSPy projects."""
