"""Code templates for generating DSPy project files."""
