import subprocess
import sys
from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, DataTable, Static
from textual.containers import Container
from textual import log
from typing import Literal

# --- CONFIGURATION & SETUP ---

def run_docker_command(command_parts: list[str]) -> tuple[int, str]:
    """Executes a 'wsl docker' command and returns the exit code and combined output."""
    full_command = ["wsl", "docker"] + command_parts
    log.info(f"Executing: {' '.join(full_command)}")
    
    try:
        result = subprocess.run(
            full_command,
            capture_output=True,
            text=True,
            check=False
        )
        output = (result.stdout + result.stderr).strip()
        return result.returncode, output
    except FileNotFoundError:
        return 1, "Error: 'wsl' command not found. Ensure WSL is installed and accessible."
    except Exception as e:
        return 1, f"Execution failed: {e}"

# --- TEXTUAL APPLICATION CLASS ---

class DockerTUI(App[None]):
    """A Text User Interface (TUI) application executing 'wsl docker' CLI commands."""
    
    mode: Literal["CONTAINERS", "IMAGES", "VOLUMES"] = "CONTAINERS"
    
    BINDINGS = [
        ("q", "quit", "Quit"),
        ("a", "refresh", "Refresh"),
        ("r", "restart_container", "Restart"), # Container Action
        ("x", "stop_container", "Stop"),       # Container Action
        ("s", "start_container", "Start"),     # Container Action
        ("l", "watch_logs", "Logs (L)"),       # Container Action (Enhanced!)
        ("d", "delete_item", "Delete (D)"),    # Generic Delete Action (Fixed!)
        ("p", "show_prune_menu", "Prune/Cleanup"),
        ("c", "set_mode('CONTAINERS')", "Containers (C)"), # Mode Switch
        ("i", "set_mode('IMAGES')", "Images (I)"),         # Mode Switch
        ("v", "set_mode('VOLUMES')", "Volumes (V)"),       # Mode Switch
        ("m", "toggle_multi_select", "Mark/Unmark (M)"), # <-- NEW BINDING
    ]
    
    CSS = """
    #container-list {
        height: 70%;
    }
    #log-panel {
        height: 30%;
        border-top: heavy white;
        padding: 1;
        overflow: scroll;
        text-style: dim;
        color: #ADFF2F;
    }
    """
    selected_row_data = None
    _prune_ready = False  # Add this flag for the double-press check
    _prune_timer = None # <-- ADD THIS LINE
    _selected_items = []      # List to store the data of multi-selected rows
    _multi_select_mode = False # Flag to track if multi-select is active
    def compose(self) -> ComposeResult:
        """Called to compose the app's initial layout."""
        yield Header()
        yield Container(
            DataTable(id="container-list"),
            id="main-area"
        )
        yield Static("Status/Output will be displayed here...", id="log-panel")
        yield Footer()

    def on_mount(self) -> None:
        """Called when the app is ready to run. Used to set up initial data."""
        self.query_one("#log-panel", Static).markup = False
        self.action_set_mode(self.mode)
        
    # --- Mode Switching and Refresh ---
    
    def action_set_mode(self, new_mode: str) -> None:
        """Action to switch the display mode and refresh the table."""
        self.mode = new_mode
        self.update_data_list()
        self.notify(f"View switched to: {self.mode}", severity="information")

    def action_refresh(self) -> None:
        """Refreshes the current list based on the mode."""
        self.update_data_list()
        self.notify(f"{self.mode} list refreshed.", severity="information")

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Saves the data of the currently highlighted row to self.selected_row_data."""
        try:
            table = event.sender
            # Retrieve the row data
            row_data_retrieved = list(table.get_row(event.row_key))
            
            # Check if data was successfully retrieved before assigning
            if row_data_retrieved:
                self.selected_row_data = row_data_retrieved
                # DEBUG NOTIFICATION: See if this fires when you move the cursor
                self.notify(f"Row data set! ID: {row_data_retrieved[0][:8]}", severity="verbose") 
            else:
                self.selected_row_data = None
                self.notify("Row data retrieval failed.", severity="warning")

        except Exception as e:
            # Handle cases where the row key might be invalid 
            self.notify(f"🚨 Row Highlight Error: {e}", severity="error")
            self.selected_row_data = None

    def update_data_list(self) -> None:
        """
        Dynamically updates the DataTable based on the current mode. 
        FIXED: Uses a reliable column removal loop to ensure the column count is zero before adding new ones.
        """
        table = self.query_one(DataTable)
        output_widget = self.query_one("#log-panel", Static)
        
        # Determine columns and command based on mode
        if self.mode == "CONTAINERS":
            columns = ("ID", "Names", "Image", "Status", "Created", "Ports", "Command")
            command = ["ps", "-a", "--no-trunc", "--format", "{{.ID}}\t{{.Names}}\t{{.Image}}\t{{.Status}}\t{{.CreatedAt}}\t{{.Ports}}\t{{.Command}}"]
            item_count = 7
        
        elif self.mode == "IMAGES":
            columns = ("ID", "Repository", "Tag", "Size", "Created")
            command = ["image", "ls", "--no-trunc", "--format", "{{.ID}}\t{{.Repository}}\t{{.Tag}}\t{{.Size}}\t{{.CreatedAt}}"]
            item_count = 5
            
        elif self.mode == "VOLUMES":
            columns = ("Name", "Mountpoint", "Driver", "Scope")
            command = ["volume", "ls", "--format", "{{.Name}}\t{{.Mountpoint}}\t{{.Driver}}\t{{.Scope}}"]
            item_count = 4

        # 1. Clear rows immediately
        table.clear() 

        # 2. Reset and Add Columns (THE CRITICAL FIX AREA)
        
        # Use a loop to remove all existing columns by key (reliable across versions)
        # We fetch the column keys and remove them one by one.
        for column_key in list(table.columns.keys()):
            try:
                table.remove_column(column_key)
            except Exception:
                # Catching any potential errors during removal
                pass 

        # Now, add the new columns with confidence that the table is empty
        try:
            table.add_columns(*columns)
        except Exception as e:
            self.notify(f"🚨 Column creation error: {e}", severity="error")
            return
            
        # 3. Execute Command
        exit_code, output = run_docker_command(command)

        if exit_code != 0:
            self.notify(f"🚨 Failed to get {self.mode} list.", severity="error")
            output_widget.update(output)
            return

        # 4. Parse and Populate Table
        lines = output.split('\n')
        for line in lines:
            if line:
                parts = line.split('\t')
                # IMPORTANT: This check is necessary, but the column count must be correct above!
                if len(parts) == item_count:
                    table.add_row(*parts)
        
        output_widget.update(f"Command success: wsl docker {' '.join(command)}")
    
        # update_container_list = update_data_list
    # --- Container Lifecycle Actions ---
    def action_toggle_multi_select(self) -> None:
            """
            Toggles the multi-select mode, OR marks/unmarks the current row if the mode is already ON.
            """
            table = self.query_one(DataTable)
            
            # Manually retrieve data using the current cursor position (robust method)
            # We need this to check if a row is selected for marking.
            row_data_for_marking = None
            if table.cursor_row is not None:
                 try:
                     row_data_for_marking = list(table.get_row_at(table.cursor_row))
                 except Exception:
                     row_data_for_marking = None
    
            if self._multi_select_mode:
                # --- MODE IS ON: MARK/UNMARK ITEM ---
                if row_data_for_marking:
                    # Use the unique ID (first element) to check for uniqueness
                    item_id = row_data_for_marking[0] 
                    
                    # Check if item is already in the list
                    is_marked = any(item[0] == item_id for item in self._selected_items)
                    
                    if is_marked:
                        # Unmark: Remove the item
                        self._selected_items = [item for item in self._selected_items if item[0] != item_id]
                        self.notify(f"Unmarked: {item_id[:12]} ({len(self._selected_items)} selected)", severity="information", timeout=1)
                    else:
                        # Mark: Add the item
                        self._selected_items.append(row_data_for_marking)
                        self.notify(f"Marked: {item_id[:12]} ({len(self._selected_items)} selected)", severity="warning", timeout=1)
                        
                    # We need to refresh the list to visually show which items are marked
                    self.update_data_list()
                    return # Exit after marking/unmarking, do not toggle mode
    
                # If no row is highlighted, then pressing 'M' exits the mode
                self._multi_select_mode = False
                self._selected_items.clear()
                self.notify("Multi-select mode OFF. Selection cleared.", severity="information")
            
            else:
                # --- MODE IS OFF: TOGGLE ON ---
                self._multi_select_mode = True
                self.notify("Multi-select mode ON. Press 'M' on rows to mark/unmark.", severity="warning")
                # Clear selection in case it had old data
                self._selected_items.clear()
    
            # Final mode update refresh
            self.update_data_list()
            
    def _execute_container_action(self, action: str) -> None:
        """Helper to perform actions (stop, restart, start) on selected container(s)."""
        table = self.query_one(DataTable)
        items_to_process = []
        
        # 1. Determine the list of items to process (Multi-select vs. Single-select)
        if self._multi_select_mode:
            items_to_process = self._selected_items
            if not items_to_process:
                self.notify(f"Select containers to {action} (use 'M' on rows).", severity="warning")
                return
        else:
            # Single-select mode (using the robust fallback logic)
            row_data = self.selected_row_data
            if not row_data and table.cursor_row is not None:
                 try:
                     # Manually retrieve data using the current cursor position
                     row_data = list(table.get_row_at(table.cursor_row))
                 except Exception:
                     row_data = None
            
            if not row_data:
                self.notify(f"Select a container to {action}.", severity="warning")
                return
            
            items_to_process = [row_data]

        # --- DYNAMIC INDEX FINDING (Only needs to run once) ---
        id_index = -1
        name_index = -1
        try:
            column_labels = [str(col.label) for col in table.columns.values()]
            id_index = column_labels.index('ID')
            name_index = column_labels.index('Names')
        except (AttributeError, ValueError):
            self.notify("⚠️ Warning: Column lookup failed. Assuming default column order (ID=0, Names=6).", severity="warning")
            id_index = 0
            name_index = 6
        
        if id_index == -1:
             self.notify("🚨 Error: Required column index 'ID' could not be determined. Refresh (A).", severity="error")
             return
        # --- END DYNAMIC INDEX FINDING ---

        success_count = 0
        total_count = len(items_to_process)
        
        # 2. Process all selected items
        for item_data in items_to_process:
            container_id = item_data[id_index]
            container_name = item_data[name_index]

            command = [action, container_id]
            # Use a non-blocking notification for quick feedback during bulk operation
            self.notify(f"Executing: docker {action} {container_name}...", severity="information", timeout=0.5) 
            
            exit_code, output = run_docker_command(command)
            
            if exit_code == 0:
                self.append_to_log(f"✅ Success: {action} {container_name} ({container_id[:12]})")
                success_count += 1
            else:
                self.append_to_log(f"🚨 FAILED to {action} {container_name}: {output.splitlines()[0]}")

        # 3. Final Notification and Cleanup
        if total_count == 1 and success_count == 1:
             # Single action success
             self.notify(f"✅ Container {container_name} ({container_id[:12]}) {action}ed successfully.", severity="information")
        elif success_count == total_count:
             # Bulk action full success
             self.notify(f"✅ Successfully {action}ed all {total_count} containers.", severity="information")
             # Clear selection after a successful bulk action
             self._selected_items.clear()
        elif success_count > 0:
             # Bulk action partial success
             self.notify(f"⚠️ Partially successful: {success_count}/{total_count} containers {action}ed.", severity="warning")
        else:
             # Bulk action full failure
             self.notify(f"🚨 Failed to {action} any containers.", severity="error")

        self.update_data_list() # Refresh the view to show the status change
        
    def action_restart_container(self) -> None:
        self._execute_container_action("restart")

    def action_stop_container(self) -> None:
        self._execute_container_action("stop")

    def action_start_container(self) -> None:
        self._execute_container_action("start")

    # --- LOG WATCHING (Container Action) ---

    def action_watch_logs(self) -> None:
        """Action for 'l' key: Launches logs in a new Windows Terminal window with useful options."""
        if self.mode != "CONTAINERS":
            self.notify("Logs action is only available in CONTAINER view (Press 'C').", severity="warning")
            return
            
        table = self.query_one(DataTable)
        log_panel = self.query_one("#log-panel", Static)
        
        if table.cursor_row is None or table.row_count == 0:
            self.notify("No container selected to watch logs.", severity="warning")
            return
        
        # --- DYNAMIC INDEX FINDING (FIXED for older Textual versions) ---
        try:
            # FIX: Use table.columns.values() to iterate over column objects
            # and extract the label for compatibility with older versions.
            column_labels = [str(col.label) for col in table.columns.values()]
            
            id_index = column_labels.index('ID')
            name_index = column_labels.index('Names')
            status_index = column_labels.index('Status')
            
        except AttributeError:
            # Fallback if .columns.values() fails (very old versions)
            # We assume the default hardcoded indices if the dynamic method fails
            # This is a less safe fallback but better than crashing.
            self.notify("🚨 Warning: Dynamic column lookup failed. Assuming default column order (ID=0, Status=4, Names=6).", severity="warning")
            id_index = 0
            name_index = 6
            status_index = 4
        except ValueError:
            self.notify("🚨 Error: Could not find 'ID', 'Names', or 'Status' column. Refresh (A) and try again.", severity="error")
            return
        # --- END DYNAMIC INDEX FINDING ---
        
        # Use the dynamic indices to fetch the correct data
        row_data = table.get_row_at(table.cursor_row)
        container_id = row_data[id_index]
        container_name = row_data[name_index]
        container_status = row_data[status_index]

        # Use the flexible check: if the status string contains the word 'up' anywhere.
        status_check = container_status.strip().lower()
        
        if 'up' not in status_check:
            self.notify(f"Container {container_id} is not running (Status: {container_status}). Start it first.", severity="error")
            return
            
        # --- LOG OPTIONS ADDED HERE ---
        # Added -t (timestamps) and --tail 100 (last 100 lines) by default
        docker_logs_options = [
            "logs", 
            "-f", 
            "-t", 
            "--tail", 
            "100", 
            container_id
        ]
        
        launch_command = [
            "wt.exe", 
            "-w", 
            "0", 
            "--title", 
            f"Logs: {container_name} ({container_id})",
            "wsl", 
            "docker", 
        ] + docker_logs_options

        try:
            subprocess.Popen(launch_command, shell=False)
            
            self.notify(f"▶️ Logs launched for {container_name} (Last 100 lines + timestamps) in new terminal.", severity="information")
            self.append_to_log(f"Launched new terminal with command: {' '.join(launch_command)}")
            
        except FileNotFoundError:
             self.notify(f"🚨 Error: wt.exe (Windows Terminal) not found.", severity="error")
             self.append_to_log(f"Error: wt.exe not found. Please install Windows Terminal or verify its path.")
        except Exception as e:
            self.notify(f"🚨 Failed to launch new terminal: {e}", severity="error")
            log.error(f"Failed to launch log terminal: {e}")

    # --- GENERIC DELETE ACTION (D) ---

    def action_delete_item(self) -> None:
        """Deletes the selected Image, Volume, or stopped Container."""
        table = self.query_one(DataTable)
        
        if table.cursor_row is None or table.row_count == 0:
            self.notify("No item selected or list is empty.", severity="warning")
            return
        
        # --- DYNAMIC INDEX FINDING ---
        # --- DYNAMIC INDEX FINDING (FIXED for older Textual versions) ---
        try:
            column_labels = [str(col.label) for col in table.columns.values()]
            id_index = column_labels.index('ID')
            
            status_index = column_labels.index('Status') if self.mode == "CONTAINERS" else None

        except AttributeError:
            # Fallback if dynamic lookup fails
            self.notify("🚨 Warning: Dynamic column lookup failed. Assuming default column order (ID=0, Status=4).", severity="warning")
            id_index = 0
            status_index = 4
        except ValueError:
            self.notify("🚨 Error: Could not find required column(s). Refresh (A) and try again.", severity="error")
            return
        # --- END DYNAMIC INDEX FINDING ---

        row_data = table.get_row_at(table.cursor_row)
        item_id = row_data[id_index]
        
        if self.mode == "CONTAINERS":
            status = row_data[status_index]
            if 'up' in status.strip().lower():
                self.notify("🛑 Container must be stopped before deletion (use 'X' first).", severity="error")
                return
            command = ["rm", item_id]
            
        elif self.mode == "IMAGES":
            command = ["rmi", item_id]
            
        elif self.mode == "VOLUMES":
            command = ["volume", "rm", item_id, "-f"]
        
        
        action_name = f"Delete {self.mode[:-1]}"
        self.notify(f"⏳ Attempting to {action_name}: {item_id}...", severity="warning")
        
        exit_code, output = run_docker_command(command)
        
        if exit_code == 0:
            self.notify(f"✅ {action_name} successful!", severity="information")
            self.append_to_log(f"Output for 'wsl docker {' '.join(command)}':\n{output}")
        else:
            self.notify(f"🚨 {action_name} failed: Check output panel.", severity="error")
            self.append_to_log(f"Command: wsl docker {' '.join(command)}\n\nError Output:\n{output}")
            
        self.update_data_list()


    # --- PRUNE/CLEANUP FUNCTIONALITY (P) ---

    def append_to_log(self, text: str) -> None:
        """
        Helper to safely append text to the log panel and manage its length.
        FIXED to avoid crashing on older textual versions.
        """
        log_panel = self.query_one("#log-panel", Static)
        
        # 1. Safely retrieve existing content to avoid crash
        current_text = log_panel.text if hasattr(log_panel, 'text') else ""
        
        # Remove initial default text if present
        if current_text.strip() == "Status/Output will be displayed here...":
             current_text = ""
        
        # 2. Append new text with a newline
        new_text = current_text + "\n" + text
        
        # 3. Trim the content to prevent memory issues (keeping last 200 lines)
        lines = new_text.splitlines()
        
        log_panel.update("\n".join(lines[-200:]))
        log_panel.scroll_end()


    def action_show_prune_menu(self) -> None:
        """Action for 'p' key: Triggers the destructive system cleanup after a prompt."""
        output_widget = self.query_one("#log-panel", Static)
        output_widget.update("")

        if self._prune_ready:
            # Second press: Execute prune
            
            # FIX: Use the stored timer object and call .stop() instead of .cancel()
            if self._prune_timer:
                self._prune_timer.stop() # <-- THE CRITICAL CHANGE
                
            self._prune_ready = False
            self._execute_full_prune()
            
        else:
            # First press: Set flag and start timer
            self._prune_ready = True
            
            self.notify("⚠️ DESTRUCTIVE ACTION: Confirm System Prune.", severity="warning", timeout=5)
            
            self.append_to_log("--- DOCKER SYSTEM CLEANUP ---")
            self.append_to_log("This will permanently remove unused containers, networks, volumes, and dangling images.")
            self.append_to_log("\n*** CONFIRM: Press 'P' again within 5 seconds to run FULL SYSTEM PRUNE. ***")
            
            # FIX: Store the returned Timer object in a class attribute
            self._prune_timer = self.set_timer(5, self._reset_prune_state, name="prune_timer")

    def _reset_prune_state(self) -> None:
        """Resets the state after the timer runs out."""
        self._prune_ready = False
        self._prune_timer = None # Ensure this line is present
        self.notify("Prune prompt timed out.", severity="information")
        self.append_to_log("\nPrune prompt timed out. Press 'P' to start the confirmation sequence again.")
        
    def _execute_full_prune(self) -> None:
        """Executes all system cleanup commands: containers, volumes, and images."""
        
        self.append_to_log("\n--- Starting Full Docker System Prune ---\n")
        
        prune_commands = [
            ["system", "prune", "-a", "-f"], 
        ]
        
        for cmd in prune_commands:
            command_str = f"wsl docker {' '.join(cmd)}"
            self.append_to_log(f"⏳ Executing: {command_str}...")
            
            exit_code, output = run_docker_command(cmd)
            
            if exit_code == 0:
                self.append_to_log(f"✅ Success. Output:\n{output}\n")
            else:
                self.append_to_log(f"🚨 FAILED. Output:\n{output}\n")
                
        self.append_to_log("--- Full Docker System Prune Complete ---")
        self.notify("✅ System Cleanup finished.", severity="information")

        self.update_data_list()


    # --- BUILT-IN TEXTUAL ACTIONS ---
    
    def action_quit(self) -> None:
        """An action to quit the app."""
        self.exit()

def main():
    """Main entry point for the Nano Whale CLI application."""
    app = DockerTUI()
    app.run()

if __name__ == "__main__":
    main()