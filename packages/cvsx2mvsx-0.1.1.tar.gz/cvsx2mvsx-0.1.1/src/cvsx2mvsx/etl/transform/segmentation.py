from cvsx2mvsx.etl.transform.geometric import GeometricTransformer
from cvsx2mvsx.etl.transform.lattice import LatticeTransformer
from cvsx2mvsx.etl.transform.mesh import MeshTransformer
from cvsx2mvsx.models.cvsx.entry import CVSXEntry
from cvsx2mvsx.models.internal.segmentation import InternalSegmentation


class SegmentationTransformer:
    def __init__(self, cvsx_entry: CVSXEntry, out_dir_path: str) -> None:
        self._cvsx_entry = cvsx_entry
        self._out_dir_path = out_dir_path

    def run(self) -> list[InternalSegmentation]:
        lattice_segmentations = LatticeTransformer(
            cvsx_entry=self._cvsx_entry,
            out_dir_path=self._out_dir_path,
        ).run()
        mesh_segmentations = MeshTransformer(
            cvsx_entry=self._cvsx_entry,
            out_dir_path=self._out_dir_path,
        ).run()
        geometric_segmentations = GeometricTransformer(
            cvsx_entry=self._cvsx_entry,
            out_dir_path=self._out_dir_path,
        ).run()

        segmentations: list[InternalSegmentation] = (
            lattice_segmentations + mesh_segmentations + geometric_segmentations
        )

        return segmentations
