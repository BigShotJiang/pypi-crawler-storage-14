# cvsx2mvsx

Library for converting the CVSX file format into the MVSX file format.

## CLI

```bash
uv run scripts/convert.py examples/emd-1832.cvsx emd-1832.mvsx
```