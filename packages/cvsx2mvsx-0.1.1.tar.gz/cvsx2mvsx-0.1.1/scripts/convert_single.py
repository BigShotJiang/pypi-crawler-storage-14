import os
import shutil
import sys
from zipfile import ZipFile

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from main import convert_cvsx_to_mvsx

CVSX_ZIPPED_DIR = "data/cvsx/zipped"
MVSX_ZIPPED_DIR = "data/mvsx/zipped"
MVSX_UNZIPPED_DIR = "data/mvsx/unzipped"


def convert_single_cvsx(cvsx_path: str):
    if not os.path.isfile(cvsx_path):
        print(f"❌ ERROR: File not found: {cvsx_path}")
        sys.exit(1)

    if not cvsx_path.lower().endswith(".cvsx"):
        print("❌ ERROR: The input must be a .cvsx file.")
        sys.exit(1)

    # Create dirs if needed
    os.makedirs(MVSX_ZIPPED_DIR, exist_ok=True)
    os.makedirs(MVSX_UNZIPPED_DIR, exist_ok=True)

    # Compute relative path under data/cvsx/zipped
    abs_cvsx_path = os.path.abspath(cvsx_path)
    abs_cvsx_root = os.path.abspath(CVSX_ZIPPED_DIR)

    try:
        rel_subdir = os.path.relpath(os.path.dirname(abs_cvsx_path), abs_cvsx_root)
    except ValueError:
        print("❌ ERROR: Input file must be inside data/cvsx/zipped/")
        sys.exit(1)

    # Output folder preserving directory hierarchy
    output_dir = os.path.join(MVSX_ZIPPED_DIR, rel_subdir)
    os.makedirs(output_dir, exist_ok=True)

    base_name = os.path.splitext(os.path.basename(cvsx_path))[0]
    output_mvsx_path = os.path.join(output_dir, f"{base_name}.mvsx")

    print(f"Converting: {cvsx_path}")

    # Run conversion
    convert_cvsx_to_mvsx(cvsx_path, output_mvsx_path)

    # Check that the zip archive was created
    if not os.path.exists(output_mvsx_path):
        print("❌ ERROR: MVSX file not found after conversion.")
        sys.exit(1)

    print(f"✔ Output written to: {output_mvsx_path}")

    # Now unzip without hierarchy
    unzip_target = os.path.join(MVSX_UNZIPPED_DIR, base_name)

    if os.path.exists(unzip_target):
        shutil.rmtree(unzip_target)
    os.makedirs(unzip_target, exist_ok=True)

    print(f"Unzipping → {unzip_target}")

    with ZipFile(output_mvsx_path, "r") as zip_ref:
        zip_ref.extractall(unzip_target)

    print("✔ Done!")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python convert_single.py <path-to-cvsx-file>")
        sys.exit(1)

    convert_single_cvsx(sys.argv[1])
