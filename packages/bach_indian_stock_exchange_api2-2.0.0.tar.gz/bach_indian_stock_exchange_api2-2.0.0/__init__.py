"""MCP Server for Indian Stock Exchange Api2"""
