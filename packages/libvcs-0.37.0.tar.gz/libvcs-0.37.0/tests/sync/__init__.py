"""Tests for libvcs.sync."""
