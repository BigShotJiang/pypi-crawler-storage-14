"""Tests for libvcs.cmd."""
