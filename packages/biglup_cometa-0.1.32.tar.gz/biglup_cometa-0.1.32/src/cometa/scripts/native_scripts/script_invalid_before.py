"""
Copyright 2025 Biglup Labs.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from __future__ import annotations

from ..._ffi import ffi, lib
from ...errors import CardanoError
from ...cbor.cbor_reader import CborReader
from ...cbor.cbor_writer import CborWriter


class ScriptInvalidBefore:
    """
    Represents a time-lock script that requires a minimum slot.

    This script evaluates to true if the lower bound of the transaction validity
    interval is a slot number Y, and Y >= X (the slot number in this script).
    This guarantees that the transaction is included in a slot >= X.
    """

    def __init__(self, ptr) -> None:
        if ptr == ffi.NULL:
            raise CardanoError("ScriptInvalidBefore: invalid handle")
        self._ptr = ptr

    def __del__(self) -> None:
        if getattr(self, "_ptr", ffi.NULL) not in (None, ffi.NULL):
            ptr_ptr = ffi.new("cardano_script_invalid_before_t**", self._ptr)
            lib.cardano_script_invalid_before_unref(ptr_ptr)
            self._ptr = ffi.NULL

    def __enter__(self) -> ScriptInvalidBefore:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        pass

    def __repr__(self) -> str:
        return f"ScriptInvalidBefore(slot={self.slot})"

    @classmethod
    def new(cls, slot: int) -> ScriptInvalidBefore:
        """
        Creates a new ScriptInvalidBefore with the given slot number.

        Args:
            slot: The slot number representing the lower bound of validity.

        Returns:
            A new ScriptInvalidBefore instance.

        Raises:
            CardanoError: If creation fails.
        """
        out = ffi.new("cardano_script_invalid_before_t**")
        err = lib.cardano_script_invalid_before_new(slot, out)
        if err != 0:
            raise CardanoError(
                f"Failed to create ScriptInvalidBefore (error code: {err})"
            )
        return cls(out[0])

    @classmethod
    def from_cbor(cls, reader: CborReader) -> ScriptInvalidBefore:
        """
        Deserializes a ScriptInvalidBefore from CBOR data.

        Args:
            reader: A CborReader positioned at the script data.

        Returns:
            A new ScriptInvalidBefore deserialized from the CBOR data.

        Raises:
            CardanoError: If deserialization fails.
        """
        out = ffi.new("cardano_script_invalid_before_t**")
        err = lib.cardano_script_invalid_before_from_cbor(reader._ptr, out)
        if err != 0:
            raise CardanoError(
                f"Failed to deserialize ScriptInvalidBefore from CBOR (error code: {err})"
            )
        return cls(out[0])

    def to_cbor(self, writer: CborWriter) -> None:
        """
        Serializes the script to CBOR format.

        Args:
            writer: A CborWriter to write the serialized data to.

        Raises:
            CardanoError: If serialization fails.
        """
        err = lib.cardano_script_invalid_before_to_cbor(self._ptr, writer._ptr)
        if err != 0:
            raise CardanoError(
                f"Failed to serialize ScriptInvalidBefore to CBOR (error code: {err})"
            )

    @property
    def slot(self) -> int:
        """
        The slot number representing the lower bound of validity.

        Returns:
            The slot number.
        """
        slot_out = ffi.new("uint64_t*")
        err = lib.cardano_script_invalid_before_get_slot(self._ptr, slot_out)
        if err != 0:
            raise CardanoError(f"Failed to get slot (error code: {err})")
        return int(slot_out[0])

    @slot.setter
    def slot(self, value: int) -> None:
        """
        Sets the slot number.

        Args:
            value: The slot number.

        Raises:
            CardanoError: If setting fails.
        """
        err = lib.cardano_script_invalid_before_set_slot(self._ptr, value)
        if err != 0:
            raise CardanoError(f"Failed to set slot (error code: {err})")

    def __eq__(self, other: object) -> bool:
        """Checks equality with another ScriptInvalidBefore."""
        if not isinstance(other, ScriptInvalidBefore):
            return NotImplemented
        return bool(lib.cardano_script_invalid_before_equals(self._ptr, other._ptr))
