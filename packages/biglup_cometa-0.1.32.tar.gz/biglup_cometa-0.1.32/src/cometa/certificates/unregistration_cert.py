"""
Copyright 2025 Biglup Labs.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from __future__ import annotations

from .._ffi import ffi, lib
from ..errors import CardanoError
from ..cbor.cbor_reader import CborReader
from ..cbor.cbor_writer import CborWriter
from ..common.credential import Credential


class UnregistrationCert:
    """
    Represents an unregistration certificate (Conway era).

    This certificate is used when a stakeholder no longer wants to participate
    in staking. It revokes the stake registration and the associated stake is
    no longer counted when calculating stake pool rewards.

    Note:
        This replaces the deprecated StakeDeregistrationCert after the Conway era.
    """

    def __init__(self, ptr) -> None:
        if ptr == ffi.NULL:
            raise CardanoError("UnregistrationCert: invalid handle")
        self._ptr = ptr

    def __del__(self) -> None:
        if getattr(self, "_ptr", ffi.NULL) not in (None, ffi.NULL):
            ptr_ptr = ffi.new("cardano_unregistration_cert_t**", self._ptr)
            lib.cardano_unregistration_cert_unref(ptr_ptr)
            self._ptr = ffi.NULL

    def __enter__(self) -> UnregistrationCert:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        pass

    def __repr__(self) -> str:
        return f"UnregistrationCert(deposit={self.deposit})"

    @classmethod
    def new(cls, credential: Credential, deposit: int) -> UnregistrationCert:
        """
        Creates a new unregistration certificate.

        Args:
            credential: The stake credential to unregister.
            deposit: The deposit amount to be refunded (in lovelace).

        Returns:
            A new UnregistrationCert instance.

        Raises:
            CardanoError: If creation fails.
        """
        out = ffi.new("cardano_unregistration_cert_t**")
        err = lib.cardano_unregistration_cert_new(credential._ptr, deposit, out)
        if err != 0:
            raise CardanoError(f"Failed to create UnregistrationCert (error code: {err})")
        return cls(out[0])

    @classmethod
    def from_cbor(cls, reader: CborReader) -> UnregistrationCert:
        """
        Deserializes an UnregistrationCert from CBOR data.

        Args:
            reader: A CborReader positioned at the certificate data.

        Returns:
            A new UnregistrationCert deserialized from the CBOR data.

        Raises:
            CardanoError: If deserialization fails.
        """
        out = ffi.new("cardano_unregistration_cert_t**")
        err = lib.cardano_unregistration_cert_from_cbor(reader._ptr, out)
        if err != 0:
            raise CardanoError(
                f"Failed to deserialize UnregistrationCert from CBOR (error code: {err})"
            )
        return cls(out[0])

    def to_cbor(self, writer: CborWriter) -> None:
        """
        Serializes the certificate to CBOR format.

        Args:
            writer: A CborWriter to write the serialized data to.

        Raises:
            CardanoError: If serialization fails.
        """
        err = lib.cardano_unregistration_cert_to_cbor(self._ptr, writer._ptr)
        if err != 0:
            raise CardanoError(
                f"Failed to serialize UnregistrationCert to CBOR (error code: {err})"
            )

    @property
    def credential(self) -> Credential:
        """
        The stake credential being unregistered.

        Returns:
            The Credential associated with this unregistration.
        """
        ptr = lib.cardano_unregistration_cert_get_credential(self._ptr)
        if ptr == ffi.NULL:
            raise CardanoError("Failed to get credential")
        lib.cardano_credential_ref(ptr)
        return Credential(ptr)

    @credential.setter
    def credential(self, value: Credential) -> None:
        """
        Sets the stake credential.

        Args:
            value: The Credential to set.

        Raises:
            CardanoError: If setting fails.
        """
        err = lib.cardano_unregistration_cert_set_credential(self._ptr, value._ptr)
        if err != 0:
            raise CardanoError(f"Failed to set credential (error code: {err})")

    @property
    def deposit(self) -> int:
        """
        The deposit amount to be refunded (in lovelace).

        Returns:
            The deposit amount.
        """
        return int(lib.cardano_unregistration_cert_get_deposit(self._ptr))

    @deposit.setter
    def deposit(self, value: int) -> None:
        """
        Sets the deposit amount.

        Args:
            value: The deposit amount in lovelace.

        Raises:
            CardanoError: If setting fails.
        """
        err = lib.cardano_unregistration_cert_set_deposit(self._ptr, value)
        if err != 0:
            raise CardanoError(f"Failed to set deposit (error code: {err})")
