"""
Copyright 2025 Biglup Labs.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from .coin_selector import CoinSelectorProtocol, CoinSelector
from .python_coin_selector_adapter import CoinSelectorHandle
from .c_coin_selector_wrapper import CCoinSelectorWrapper
from .large_first_coin_selector import LargeFirstCoinSelector

__all__ = [
    # Protocol/Interface
    "CoinSelectorProtocol",
    "CoinSelector",  # Alias for CoinSelectorProtocol
    # Python -> C adapter
    "CoinSelectorHandle",
    # C -> Python wrapper
    "CCoinSelectorWrapper",
    # C-based implementations
    "LargeFirstCoinSelector",
]
