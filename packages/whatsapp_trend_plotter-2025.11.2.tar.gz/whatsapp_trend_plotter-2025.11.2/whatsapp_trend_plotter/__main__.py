from . import command_entry_point

command_entry_point()
