# src/scrapy_waitrequests/sender/base_captcha.py

from abc import ABC, abstractmethod


class BaseCaptchaProvider(ABC):
    """
    Common interface for captcha providers.
    """

    @abstractmethod
    def build_submit_request(self, *, image_or_sitekey, page_url, final_callback, errback=None, meta=None):
        """
        Return a scrapy.Request that submits the captcha to the provider
        and that eventually yields a CaptchaWaitRequest.

        Implementation detail: this request's callback typically:
        - parses the provider's JSON
        - obtains captcha_id
        - yields CaptchaWaitRequest(...)
        """
        raise NotImplementedError

    @abstractmethod
    def build_result_url(self, captcha_id: str) -> str:
        raise NotImplementedError

    @abstractmethod
    def parse_result(self, response):
        """
        Parse provider polling response.

        Returns:
            (status, payload)
            status: "pending" | "ready" | "failed"
            payload: solution token / text / error message
        """
        raise NotImplementedError