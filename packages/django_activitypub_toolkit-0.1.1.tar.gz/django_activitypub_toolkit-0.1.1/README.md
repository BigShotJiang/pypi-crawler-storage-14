### Django ActivityPub Toolkit - add support to ActivityPub in your django applications

## Overview

Django ActivityPub Toolkit is pluggable django app that provides all
the models, views and background tasks to let your application
integrate with any other service that uses
[ActivityPub](https://activitypub.rocks).
