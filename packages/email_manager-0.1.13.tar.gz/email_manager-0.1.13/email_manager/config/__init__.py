from .email_config import EmailConfig

__all__ = ["EmailConfig"]
