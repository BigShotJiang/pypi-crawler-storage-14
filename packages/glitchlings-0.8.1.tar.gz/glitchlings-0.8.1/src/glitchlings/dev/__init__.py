"""Developer-facing utilities for maintaining the Glitchlings repository."""

from .sync_assets import sync_assets

__all__ = ["sync_assets"]
