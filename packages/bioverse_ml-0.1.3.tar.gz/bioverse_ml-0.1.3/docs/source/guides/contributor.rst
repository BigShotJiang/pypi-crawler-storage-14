Contributor Guide
=================