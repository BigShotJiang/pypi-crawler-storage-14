Code Structure
==============