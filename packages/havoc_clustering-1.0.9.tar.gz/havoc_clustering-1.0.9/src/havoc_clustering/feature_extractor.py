import numpy as np
import cv2
import torch
import timm
from torchvision import transforms
from PIL import Image


class FeatureExtractor:
    def __init__(self, device=None):

        print("Loading feature extractor (prov-gigapath)...")

        # --- Device ---
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        # --- Model ---
        # Executing the first time creates a local cache of the model
        self.model = timm.create_model(
            model_name='hf_hub:prov-gigapath/prov-gigapath',
            pretrained=True,
        ).to(self.device).eval()

        self.num_features = self.model.num_features

        # --- Preprocessing pipeline ---
        self.preprocess = transforms.Compose([
            transforms.Resize(256, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(224),
            transforms.ToTensor(),  # converts to [0,1] and CHW
            transforms.Normalize(
                mean=(0.485, 0.456, 0.406),
                std=(0.229, 0.224, 0.225),
            ),
        ])

        print("Finished loading feature extractor")

    def _preprocess_batch(self, batch: np.ndarray) -> torch.Tensor:
        """
        batch: numpy array of shape (N, H, W, 3) from cv2.imread,
               i.e. BGR uint8 images.
        """
        # Ensure shape is (N, H, W, 3)
        if batch.ndim != 4 or batch.shape[-1] != 3:
            raise ValueError(f"Expected batch shape (N, H, W, 3), got {batch.shape}")

        tensors = []
        for img_bgr in batch:
            img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
            pil_img = Image.fromarray(img_rgb)
            tensors.append(self.preprocess(pil_img))

        return torch.stack(tensors, dim=0)

    def process(self, batch: np.ndarray, return_numpy=True, patch_size=256):
        """
        batch: numpy array from cv2 (N, H, W, 3)
        returns: (N, D) feature matrix (numpy or torch tensor)
        """
        if batch is None or len(batch) == 0:
            # Return empty properly-shaped container if you want,
            # but empty list is also fine.
            return np.empty((0, 0), dtype=np.float32) if return_numpy else torch.empty(0, 0)

        x = self._preprocess_batch(batch)

        x = x.to(self.device)
        with torch.no_grad():
            tile_feats = self.model(x)
        tile_feats = patch_feats.cpu()

        if return_numpy:
            return tile_feats.numpy()
        else:
            return tile_feats
