"""FIBO model variants."""
