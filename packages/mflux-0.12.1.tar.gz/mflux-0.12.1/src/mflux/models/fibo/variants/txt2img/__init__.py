"""FIBO text-to-image variant."""
