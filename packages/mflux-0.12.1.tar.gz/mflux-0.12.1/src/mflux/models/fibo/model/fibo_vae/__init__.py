"""FIBO VAE components."""
