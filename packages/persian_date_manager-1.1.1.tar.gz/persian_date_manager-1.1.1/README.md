# Persian Date Manager

یک پکیج قدرتمند برای تاریخ های شمسی

## 📦 نصب

```bash
pip install persian-date-manager

