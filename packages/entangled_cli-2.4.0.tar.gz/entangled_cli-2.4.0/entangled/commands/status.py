from __future__ import annotations
from collections.abc import Iterable
from ..status import list_dependent_files
from ..config import Config, read_config, get_input_files
from pathlib import Path

from rich.console import Console, Group
from rich.columns import Columns
from rich.table import Table
from rich.panel import Panel
from rich.tree import Tree

from .main import main


def tree_from_files(files: Iterable[Path]):
    tree = Tree(label=".")
    dirs = {Path("."): tree}
    for f in sorted(files):
        for p in reversed(f.parents):
            if p not in dirs:
                dirs[p] = dirs[p.parent].add(p.name, style="repr.path")
        _ = dirs[f.parent].add(f.name, style="repr.filename")
    return tree


def files_panel(file_list: Iterable[Path], title: str) -> Panel:
    tree = tree_from_files(file_list)
    return Panel(tree, title=title, border_style="dark_cyan")


def rich_status():
    cfg = Config() | read_config()
    config_table = Table()
    config_table.add_column("name")
    config_table.add_column("value")
    config_table.add_row(
        "Watch list", ", ".join(f"'{pat}'" for pat in cfg.watch_list)
    )
    config_table.add_row(
        "Ignore list", ", ".join(f"'{pat}'" for pat in cfg.ignore_list)
    )
    config_table.add_row("Hooks enabled", ", ".join(cfg.hooks))

    console = Console(color_system="auto")
    group = Group(
        Panel(config_table, title="config", border_style="dark_cyan"),
        Columns(
            [
                files_panel(get_input_files(cfg), "input files"),
                files_panel(list_dependent_files(), "dependent files"),
            ]
        ),
    )

    console.print(group)


@main.command()
def status():
    """Print a status overview."""
    rich_status()
