import logging

client = logging.getLogger("mexc.client")
