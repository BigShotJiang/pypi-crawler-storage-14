from dataclasses import dataclass


@dataclass
class UID:
    uid: str
