import base64
import hashlib
import sys
import tempfile
import subprocess
import os
from Crypto.Cipher import AES

# ==========================
# FUSELOCK LOADER
# ==========================

HARDCODED_KEY = b"ANTITAMPERGODHOLYSSHITUAINTNEVERGETTINGPASTEMELMAOOO"  # 16/24/32 bytes for AES-128/192/256

class Anubis:
    def __init__(self, key):
        self.bs = AES.block_size
        self.key = hashlib.sha256(key).digest()

    def decrypt(self, enc):
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    @staticmethod
    def _unpad(s):
        return s[:-ord(s[-1:])]

def run(encrypted_blocks):
    from traceback import print_exc

    an = Anubis(HARDCODED_KEY)
    src = ""

    for block in encrypted_blocks:
        src += an.decrypt(block) + "\n"

    namespace = {}

    try:
        exec(src, namespace)
    except Exception:
        print("[!] Error while executing payload:")
        print_exc()



# Example usage for encrypted code blocks
if __name__ == "__main__":
    test_blocks = [
        # list of encrypted strings goes here
    ]
    run(test_blocks)
