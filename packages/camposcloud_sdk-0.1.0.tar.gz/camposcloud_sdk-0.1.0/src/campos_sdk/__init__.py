"""CamposCloud Python SDK"""

from .client import CamposClient
from .errors import (
    ApiError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    ServerError,
    NetworkError,
)
from .models.user import User, Session
from .models.application import Application, ApplicationMetrics, WorkerNode, AppFile, DeleteFilesResponse, UploadFileResponse

__version__ = "1.0.0"
__all__ = [
    "CamposClient",
    "ApiError",
    "AuthenticationError", 
    "NotFoundError",
    "ValidationError",
    "ServerError",
    "NetworkError",
    "User",
    "Session",
    "Application",
    "ApplicationMetrics",
    "WorkerNode",
    "AppFile",
    "DeleteFilesResponse",
    "UploadFileResponse",
]