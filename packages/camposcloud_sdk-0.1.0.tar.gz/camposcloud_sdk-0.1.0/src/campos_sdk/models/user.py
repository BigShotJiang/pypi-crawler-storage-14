from datetime import datetime
from pydantic import BaseModel
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    pass

class Session(BaseModel):
    id: str
    device: str
    ip: str
    browser: str
    lastActive: datetime


class User(BaseModel):
    _id: str
    name: str
    isEmail2FAEnabled: bool
    hasClaimedFreePlan: bool
    activeSessions: List[Session]
