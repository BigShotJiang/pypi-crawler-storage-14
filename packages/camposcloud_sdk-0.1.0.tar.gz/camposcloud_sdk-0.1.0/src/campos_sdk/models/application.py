from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field


class ApplicationMetrics(BaseModel):
    timestamp: datetime
    online: bool
    uptime: Optional[int]
    cpuUsagePercent: Optional[float]
    memoryUsageBytes: Optional[int]
    memoryLimitBytes: Optional[int]
    networkRxBytes: Optional[int]
    networkTxBytes: Optional[int]


class WorkerNode(BaseModel):
    _id: str
    nodeName: str


class Application(BaseModel):
    model_config = {"extra": "allow"}
    
    id: str = Field(alias="_id")
    name: str
    status: str
    
    @property
    def _id(self):
        return self.id
    
    def __str__(self):
        return str(self.model_dump())


class AppFile(BaseModel):
    name: str
    path: str
    isFile: bool
    isDirectory: bool
    size: Optional[int]
    createdAt: Optional[datetime]
    modifiedAt: Optional[datetime]


class DeleteFilesResponse(BaseModel):
    success: list[str]
    failed: list[str]

class UploadFileResponse(BaseModel):
    message: str