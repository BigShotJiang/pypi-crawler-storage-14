import requests

from campos_sdk.routes.users import UsersRoute
from campos_sdk.routes.applications import ApplicationsRoute
from campos_sdk.errors import ValidationError

class CamposClient:
    token: str
    session: requests.Session
    base_url: str

    def __init__(self, token: str, base_url: str = "https://api.camposcloud.com/v1/", timeout: int = 30):
        if not token or not token.strip():
            raise ValidationError("Token é obrigatório")
        
        self.token = token
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"Bearer {token}"})
        self.session.timeout = timeout

        self.users = UsersRoute(self.session, self.base_url)
        self.applications = ApplicationsRoute(self.session, self.base_url)