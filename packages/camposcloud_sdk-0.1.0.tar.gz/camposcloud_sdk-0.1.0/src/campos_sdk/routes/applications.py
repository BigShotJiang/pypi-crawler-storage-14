from campos_sdk.errors import handle_response, NetworkError, ValidationError
from campos_sdk.models.application import (
    Application,
    AppFile,
    DeleteFilesResponse,
    UploadFileResponse,
)
from typing import Optional, List, Dict, Any
import requests

class ApplicationWrapper:
    def __init__(self, client: "ApplicationsRoute", app_id: str):
        self._client = client
        self.id = app_id
        self._data = None

    def start(self):
        return self._client.startApplication(self.id)

    def stop(self):
        return self._client.stopApplication(self.id)

    def restart(self):
        return self._client.restartApplication(self.id)

    def update(self, **kwargs):
        self._client.updateApplication(self.id, **kwargs)
        return self

    def delete(self):
        return self._client.deleteApplication(self.id)

    def getFiles(self):
        return self._client.getApplicationFiles(self.id)

    def deleteFiles(self, files: List[str]) -> DeleteFilesResponse:
        return self._client.deleteApplicationFile(self.id, files)
    
    def __str__(self):
        if self._data:
            return str(self._data)
        return f"ApplicationWrapper(id={self.id})"
    
    def __getattr__(self, name):
        if self._data and hasattr(self._data, name):
            return getattr(self._data, name)
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")


class ApplicationsRoute:
    def __init__(self, session: requests.Session, base_url: str):
        self.session = session
        self.base_url = base_url

    def getApplications(
        self, 
        limit: Optional[int] = None,
        page: Optional[int] = None,
        team: Optional[str] = None
    ) -> list[Application]:
        params = {}
        if limit is not None:
            params["limit"] = limit
        if page is not None:
            params["page"] = page
        if team is not None:
            params["team"] = team

        try:
            r = self.session.get(f"{self.base_url}/apps", params=params)
            data = handle_response(r)

            apps_data = data.get("applications", [])

            return [Application(**app) for app in apps_data]
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def getApplication(self, app_id: str) -> ApplicationWrapper:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.get(f"{self.base_url}/apps/{app_id}")
            data = handle_response(r)
            wrapper = ApplicationWrapper(self, app_id)
            wrapper._data = Application(**data)
            return wrapper
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")
    
    def getApplicationData(self, app_id: str) -> Application:
        """Retorna apenas os dados da aplicação sem wrapper."""
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.get(f"{self.base_url}/apps/{app_id}")
            data = handle_response(r)
            return Application(**data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def createApplication(
        self,
        appName: str,
        file: bytes,
        mainFile: str,
        memoryMB: int,
        runtimeEnvironment: str,
        *,
        exposedViaWeb: bool = False,
        autoRestartEnabled: bool = True,
        startupCommand: Optional[str] = None,
        teamId: Optional[str] = None,
    ) -> Application:
        data: dict[str, str] = {
            "appName": appName,
            "mainFile": mainFile,
            "memoryMB": str(memoryMB),
            "runtimeEnvironment": runtimeEnvironment,
            "exposedViaWeb": str(exposedViaWeb).lower(),
            "autoRestartEnabled": str(autoRestartEnabled).lower(),
        }

        if startupCommand:
            data["startupCommand"] = startupCommand
        if teamId:
            data["teamId"] = teamId

        files = {
            "file": ("application.zip", file, "application/zip"),
        }

        try:
            r = self.session.post(f"{self.base_url}/apps/create", data=data, files=files)
            response_data = handle_response(r)
            return Application(**response_data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def updateApplication(
        self,
        app_id: str,
        appName: str,
        memoryMB: int,
        runtimeEnvironment: str,
        startupCommand: str,
        mainFile: Optional[str] = None,
        autoRestartEnabled: Optional[bool] = None,
        exposedViaWeb: Optional[bool] = None,
        environmentVariables: Optional[List[Dict[str, str]]] = None,
        teamId: Optional[str] = None,
    ) -> Application:
        data: dict[str, Any] = {
            "appName": appName,
            "memoryMB": memoryMB,
            "runtimeEnvironment": runtimeEnvironment,
            "startupCommand": startupCommand,
        }

        if mainFile is not None:
            data["mainFile"] = mainFile
        if autoRestartEnabled is not None:
            data["autoRestartEnabled"] = autoRestartEnabled
        if exposedViaWeb is not None:
            data["exposedViaWeb"] = exposedViaWeb
        if environmentVariables is not None:
            data["environmentVariables"] = environmentVariables
        if teamId is not None:
            data["teamId"] = teamId

        try:
            r = self.session.put(f"{self.base_url}/apps/{app_id}/update", json=data)
            response_data = handle_response(r)
            return Application(**response_data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def deleteApplication(self, app_id: str) -> None:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.delete(f"{self.base_url}/apps/{app_id}/delete")
            data = handle_response(r)
            return data
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def startApplication(self, app_id: str) -> Application:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.post(f"{self.base_url}/apps/{app_id}/start")
            data = handle_response(r)
            return Application(**data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def stopApplication(self, app_id: str) -> Application:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.post(f"{self.base_url}/apps/{app_id}/stop")
            data = handle_response(r)
            return Application(**data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def restartApplication(self, app_id: str) -> Application:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.post(f"{self.base_url}/apps/{app_id}/restart")
            data = handle_response(r)
            return Application(**data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def getApplicationFiles(self, app_id: str) -> List[AppFile]:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        
        try:
            r = self.session.get(f"{self.base_url}/apps/{app_id}/files")
            data = handle_response(r)
            return [AppFile(**f) for f in data.get("files", [])]
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def deleteApplicationFile(
        self, app_id: str, files: List[str]
    ) -> DeleteFilesResponse:
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        if not files:
            raise ValidationError("Lista de arquivos não pode estar vazia")
        
        try:
            r = self.session.delete(
                f"{self.base_url}/apps/{app_id}/files", json={"files": files}
            )
            data = handle_response(r)
            return DeleteFilesResponse(**data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def uploadApplicationFile(self, app_id: str, file_path: str) -> UploadFileResponse:
        import os
        
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        if not file_path or not os.path.exists(file_path):
            raise ValidationError("Arquivo não encontrado")
        
        try:
            with open(file_path, "rb") as f:
                r = self.session.post(
                    f"{self.base_url}/apps/{app_id}/upload",
                    files={"file": f},
                )
            data = handle_response(r)
            return UploadFileResponse(**data)
        except (IOError, OSError) as e:
            raise ValidationError(f"Erro ao ler arquivo: {e}")
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")

    def downloadApplicationFile(
        self, app_id: str, file_id: str, file_path: str
    ) -> None:
        import os
        
        if not app_id or not app_id.strip():
            raise ValidationError("app_id é obrigatório")
        if not file_path:
            raise ValidationError("Caminho do arquivo é obrigatório")
        
        try:
            r = self.session.get(f"{self.base_url}/apps/{app_id}/download")
            
            if r.status_code != 200:
                handle_response(r)
            
            with open(file_path, "wb") as f:
                f.write(r.content)
        except (IOError, OSError) as e:
            raise ValidationError(f"Erro ao salvar arquivo: {e}")
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")