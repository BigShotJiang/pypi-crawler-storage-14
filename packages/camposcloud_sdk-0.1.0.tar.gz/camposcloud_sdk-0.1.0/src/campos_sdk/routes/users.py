from campos_sdk.models.user import User
from campos_sdk.errors import handle_response, NetworkError
import requests

class UsersRoute:
    def __init__(self, session: requests.Session, base_url: str):
        self.session = session
        self.base_url = base_url

    def get_me(self) -> User:
        try:
            r = self.session.get(f"{self.base_url}/users/@me")
            data = handle_response(r)
            return User(**data)
        except requests.RequestException as e:
            raise NetworkError(f"Erro de conexão: {e}")
