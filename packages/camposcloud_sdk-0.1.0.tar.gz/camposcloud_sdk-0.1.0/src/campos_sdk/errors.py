class ApiError(Exception):
    """Erro base da API."""
    
    def __init__(self, message: str, status_code: int = None):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class AuthenticationError(ApiError):
    """Erro de autenticação (401, 403)."""
    pass


class NotFoundError(ApiError):
    """Recurso não encontrado (404)."""
    pass


class ValidationError(ApiError):
    """Erro de validação de dados (400, 422)."""
    pass


class ServerError(ApiError):
    """Erro interno do servidor (500+)."""
    pass


class NetworkError(ApiError):
    """Erro de conexão de rede."""
    pass


def handle_response(response):
    """Trata resposta HTTP e levanta exceções apropriadas."""
    if response.status_code == 200:
        try:
            return response.json()
        except ValueError:
            raise ApiError("Resposta inválida do servidor", response.status_code)
    
    error_message = f"Erro {response.status_code}"
    try:
        error_text = response.text or error_message
    except:
        error_text = error_message
    
    if response.status_code == 401:
        raise AuthenticationError(error_text, response.status_code)
    elif response.status_code == 403:
        raise AuthenticationError(error_text, response.status_code)
    elif response.status_code == 404:
        raise NotFoundError(error_text, response.status_code)
    elif response.status_code in (400, 422):
        raise ValidationError(error_text, response.status_code)
    elif response.status_code >= 500:
        raise ServerError(error_text, response.status_code)
    else:
        raise ApiError(error_text, response.status_code)
