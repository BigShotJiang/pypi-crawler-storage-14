from campos_sdk.client import CamposClient

TOKEN = "687addc61d1a9fb15eecaed2:9b3848a0-992e-436e-afb9-8e66e19bb943"


def test_get_apps():
    client = CamposClient(token=TOKEN)
    apps = client.applications.getApplications(team="688feaffd77c39c9550a2407")

    for app in apps:
        print(f"App: {app.name} - Status: {app.status}")


test_get_apps()
