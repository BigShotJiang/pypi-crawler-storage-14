import pytest
from campos_sdk.client import CamposClient
from campos_sdk.models.user import Session
from datetime import datetime
from campos_sdk.models.application import Application

TOKEN = ""

@pytest.mark.user
def test_get_user():
    client = CamposClient(token=TOKEN)

    try:
        user = client.users.get_me()
    except Exception as e:
        print(f"Error: {e}")
        user = None

    if user:
        print(user)

        assert user.name is not None
        assert isinstance(user.activeSessions, list)
        for s in user.activeSessions:
            assert isinstance(s, Session)
            assert isinstance(s.lastActive, datetime)


@pytest.mark.apps
def test_get_apps():
    client = CamposClient(token=TOKEN)

    try:
        apps = client.applications.getApplications()
    except Exception as e:
        print(f"Error: {e}")
        apps = None

    if apps:
        print(apps)

        assert isinstance(apps, list)
        for app in apps:
            assert isinstance(app, Application)


@pytest.mark.apps
def test_get_app():
    client = CamposClient(token=TOKEN)

    try:
        app = client.applications.getApplication("68d25219c6619e18cc5c6685")
    except Exception as e:
        print(f"Error: {e}")
        app = None

    if app:
        print(app)

        assert isinstance(app, Application)


# @pytest.mark.apps
# def test_create_app():
#     client = CamposClient(token=TOKEN)

#     with open("tests/bot_test.zip", "rb") as f:
#         file_bytes = f.read()

#     try:
#         app = client.applications.createApplication(
#             appName="Test App",
#             mainFile="index.py",
#             memoryMB=256,
#             runtimeEnvironment="python",
#             file=file_bytes,
#         )
#     except Exception as e:
#         print(f"Error: {e}")
#         app = None

#     if app:
#         print(app)

#         assert isinstance(app, Application)


# @pytest.mark.apps
# def test_start_app():
#     client = CamposClient(token=TOKEN)

#     try:
#         app = client.applications.startApplication("68d25219c6619e18cc5c6685")
#     except Exception as e:
#         print(f"Error: {e}")
#         app = None

#     if app:
#         print(app)

#         assert isinstance(app, Application)


# @pytest.mark.apps
# def test_stop_app():
#     client = CamposClient(token=TOKEN)

#     try:
#         app = client.applications.stopApplication("68d25219c6619e18cc5c6685")
#     except Exception as e:
#         print(f"Error: {e}")
#         app = None

#     if app:
#         print(app)

#         assert isinstance(app, Application)


# @pytest.mark.apps
# def test_restart_app():
#     client = CamposClient(token=TOKEN)

#     try:
#         app = client.applications.restartApplication("68d25219c6619e18cc5c6685")
#     except Exception as e:
#         print(f"Error: {e}")
#         app = None

#     if app:
#         print(app)

#         assert isinstance(app, Application)


# @pytest.mark.apps
# def test_delete_app():
#     client = CamposClient(token=TOKEN)

#     try:
#         app = client.applications.deleteApplication("68d25219c6619e18cc5c6685")
#     except Exception as e:
#         print(f"Error: {e}")
#         app = None

#     if app:
#         print(app)

#         assert isinstance(app, Application)
