# pydepdoctor

**pydepdoctor** is a CLI tool that automatically fixes Python dependency conflicts in your `requirements.txt` using Google's Gemini AI.

## Features

- **Automated Fixes**: Detects installation errors and asks Gemini to resolve version conflicts.
- **Safe**: Only updates versions; does not add new packages.
- **Retry Loop**: Retries installation up to 5 times until successful.
- **Cross-Platform**: Works on Windows, macOS, and Linux.

## Installation

You can install `pydepdoctor` directly from PyPI:

```bash
pip install pydepdoctor
```

### Global Installation (Recommended)

For a CLI tool like this, it is best to install it globally using `pipx` so it's available everywhere:

```bash
pipx install pydepdoctor
```

### Install from Source

If you want to install from the source code:

1. Clone the repository.
2. Navigate to the root directory.
3. Install using pip:

```bash
pip install .
```

## Usage

### 1. Initialize

First, set up your Gemini API key:

```bash
pydepdoctor init
```

You will be prompted to enter your API key. It will be validated and saved locally.

### 2. Fix Dependencies

Navigate to a project with a problematic `requirements.txt` and run:

```bash
pydepdoctor fix
```

The tool will:

1. Try to install dependencies.
2. If it fails, capture the error.
3. Send the error and `requirements.txt` to Gemini.
4. Apply the fix and retry.

### Running as a Module

You can also run `pydepdoctor` directly as a Python module. This is useful if the CLI command is not in your PATH or if you prefer this style:

```bash
python -m pydepdoctor
```

This is equivalent to running `pydepdoctor fix`. You can also pass commands:

```bash
python -m pydepdoctor init
python -m pydepdoctor fix
```

## Requirements

- Python 3.7+
- A valid Google Gemini API Key

## License

MIT
