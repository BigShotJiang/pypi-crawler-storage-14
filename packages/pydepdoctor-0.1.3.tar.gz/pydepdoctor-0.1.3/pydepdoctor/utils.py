from rich.console import Console
from rich.panel import Panel
from rich.status import Status
from typing import Optional, ContextManager

console = Console()

def log_info(message: str) -> None:
    """Logs an info message."""
    console.print(f"[blue][INFO][/blue] {message}")

def log_success(message: str) -> None:
    """Logs a success message."""
    console.print(f"[green bold][SUCCESS][/green bold] {message}")

def log_warning(message: str) -> None:
    """Logs a warning message."""
    console.print(f"[yellow][WARNING][/yellow] {message}")

def log_error(message: str) -> None:
    """Logs an error message."""
    console.print(f"[red bold][ERROR][/red bold] {message}")

def log_step(step: str) -> None:
    """Logs a step header."""
    console.print(f"\n[cyan bold]=== {step} ===[/cyan bold]")

def print_panel(message: str, title: str = "", style: str = "white") -> None:
    """Prints a message in a panel."""
    console.print(Panel(message, title=title, style=style, expand=False))

def create_spinner(message: str) -> Status:
    """Returns a rich spinner context manager."""
    return console.status(f"[bold green]{message}[/bold green]", spinner="dots")
