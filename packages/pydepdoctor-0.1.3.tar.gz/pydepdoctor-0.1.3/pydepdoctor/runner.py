import subprocess
import sys
from typing import Tuple, Optional

def run_pip_install(requirements_path: str = "requirements.txt") -> Tuple[bool, str]:
    """
    Runs `python -m pip install -r requirements.txt`.
    Returns a tuple (success: bool, output: str).
    If success is False, output contains stderr.
    """
    cmd = [sys.executable, "-m", "pip", "install", "-r", requirements_path]
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            check=False
        )
        
        if result.returncode == 0:
            return True, result.stdout
        else:
            # Combine stdout and stderr for better context if needed, 
            # but primarily we want stderr for errors.
            error_msg = f"STDOUT:\n{result.stdout}\n\nSTDERR:\n{result.stderr}"
            return False, error_msg
            
    except Exception as e:
        return False, str(e)
