import json
import os
from pathlib import Path
from typing import Optional

APP_NAME = "pydepdoctor"
CONFIG_DIR_NAME = ".pydepdoctor"
CONFIG_FILE_NAME = "config.json"

def get_config_dir() -> Path:
    """Returns the path to the configuration directory."""
    home = Path.home()
    config_dir = home / CONFIG_DIR_NAME
    return config_dir

def get_config_file() -> Path:
    """Returns the path to the configuration file."""
    return get_config_dir() / CONFIG_FILE_NAME

def save_api_key(api_key: str) -> None:
    """Saves the API key to the config file."""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    
    config_file = get_config_file()
    config = {"gemini_key": api_key}
    
    with open(config_file, "w") as f:
        json.dump(config, f, indent=4)

def load_api_key() -> Optional[str]:
    """Loads the API key from the config file."""
    config_file = get_config_file()
    
    if not config_file.exists():
        return None
    
    try:
        with open(config_file, "r") as f:
            config = json.load(f)
            return config.get("gemini_key")
    except (json.JSONDecodeError, OSError):
        return None
