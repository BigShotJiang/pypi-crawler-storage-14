import google.generativeai as genai
from typing import Optional
from .utils import log_info, log_error

class GeminiClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel('gemini-2.5-flash')

    def validate_key(self) -> bool:
        """
        Validates the API key by making a simple test request.
        Returns True if valid, False otherwise.
        """
        try:
            response = self.model.generate_content("Hello, are you there?")
            return response.text is not None
        except Exception as e:
            log_error(f"API Key validation failed: {e}")
            return False

    def ask_gemini_to_fix(self, requirements_content: str, error_log: str) -> Optional[str]:
        """
        Sends the requirements and error log to Gemini to fix version conflicts.
        Returns the corrected requirements.txt content or None if failed.
        """
        prompt = f"""
        You are an expert Python dependency manager. I have a `requirements.txt` file that is causing installation errors due to version conflicts.
        
        Here is the original `requirements.txt`:
        ```
        {requirements_content}
        ```
        
        Here is the pip error output:
        ```
        {error_log}
        ```
        
        **INSTRUCTIONS:**
        1. Analyze the error log to identify the version conflicts.
        2. Fix the version specifiers in `requirements.txt` to resolve the conflicts.
        3. **DO NOT** add any new packages. Only modify versions of existing packages.
        4. **DO NOT** remove packages unless they are strictly incompatible and cannot be resolved (try to keep them if possible).
        5. For every line you change, append a comment explaining the change, e.g., `numpy==1.22.0  # FIXED: was 1.21.0`.
        6. Return **ONLY** the content of the corrected `requirements.txt`. Do not include any markdown formatting (like ```), explanations, or extra text. Just the raw file content.
        """
        
        try:
            response = self.model.generate_content(prompt)
            cleaned_text = response.text.strip()
            # Remove markdown code blocks if Gemini adds them despite instructions
            if cleaned_text.startswith("```"):
                cleaned_text = cleaned_text.split("\n", 1)[1]
            if cleaned_text.endswith("```"):
                cleaned_text = cleaned_text.rsplit("\n", 1)[0]
            return cleaned_text.strip()
        except Exception as e:
            log_error(f"Gemini request failed: {e}")
            return None
