import os
from pathlib import Path
from typing import Optional
from .runner import run_pip_install
from .gemini_client import GeminiClient
from .utils import log_info, log_success, log_error, log_warning, log_step, print_panel, create_spinner

MAX_ATTEMPTS = 5
REQUIREMENTS_FILE = "requirements.txt"

def fix_dependencies(api_key: str) -> None:
    """
    Main loop to fix dependencies.
    """
    if not os.path.exists(REQUIREMENTS_FILE):
        log_error(f"{REQUIREMENTS_FILE} not found in the current directory.")
        return

    client = GeminiClient(api_key)
    
    print_panel("Starting Dependency Doctor", style="bold cyan")
    
    for attempt in range(1, MAX_ATTEMPTS + 1):
        log_step(f"Attempt {attempt}/{MAX_ATTEMPTS}")
        
        with create_spinner("Installing dependencies..."):
            success, output = run_pip_install(REQUIREMENTS_FILE)
        
        if success:
            print_panel("Dependencies installed successfully!", title="Success", style="green")
            return
        
        log_warning("Installation failed. Analyzing errors...")
        print_panel(output[-2000:], title="Pip Error Output (Truncated)", style="red")
        
        # Read current requirements
        try:
            with open(REQUIREMENTS_FILE, "r") as f:
                current_requirements = f.read()
        except Exception as e:
            log_error(f"Failed to read {REQUIREMENTS_FILE}: {e}")
            return

        # Ask Gemini to fix
        with create_spinner("Asking Gemini to resolve conflicts..."):
            fixed_requirements = client.ask_gemini_to_fix(current_requirements, output)
        
        if not fixed_requirements:
            print_panel("Gemini failed to provide a fix. Aborting.", title="Failure", style="red")
            return
        
        # Save fixed requirements
        try:
            with open(REQUIREMENTS_FILE, "w") as f:
                f.write(fixed_requirements)
            
            # Simple diff summary
            old_lines = set(current_requirements.splitlines())
            new_lines = set(fixed_requirements.splitlines())
            
            added = new_lines - old_lines
            removed = old_lines - new_lines
            
            if added:
                print_panel("\n".join(added), title="Proposed Changes", style="yellow")
            
            log_info(f"Updated {REQUIREMENTS_FILE} with proposed fix.")
        except Exception as e:
            log_error(f"Failed to write to {REQUIREMENTS_FILE}: {e}")
            return
            
    print_panel(f"Failed to fix dependencies after {MAX_ATTEMPTS} attempts. Re-run pydepdoctor fix", title="Failure", style="red")
