import click
from rich.prompt import Prompt
from .config import save_api_key, load_api_key
from .gemini_client import GeminiClient
from .dependency_fixer import fix_dependencies
from .utils import log_success, log_error, log_info, print_panel, create_spinner

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """pydepdoctor: AI-powered Python dependency fixer."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(fix)

def prompt_for_key() -> str:
    """Prompts the user for the Gemini API key."""
    print_panel("Welcome to pydepdoctor! To get started, we need your Gemini API Key.", title="Setup", style="cyan")
    api_key = Prompt.ask("Please enter your Gemini API Key", password=False)
    return api_key

def validate_and_save_key(api_key: str) -> bool:
    """Validates and saves the API key."""
    with create_spinner("Validating API key..."):
        client = GeminiClient(api_key)
        is_valid = client.validate_key()
    
    if is_valid:
        save_api_key(api_key)
        log_success("API Key validated and saved successfully!")
        return True
    else:
        log_error("Invalid API Key. Please check and try again.")
        return False

@cli.command()
def init():
    """Initialize pydepdoctor with your Gemini API key."""
    api_key = prompt_for_key()
    validate_and_save_key(api_key)

@cli.command()
def fix():
    """Attempt to fix dependency conflicts in requirements.txt."""
    api_key = load_api_key()
    
    if not api_key:
        log_info("API Key not found. Let's set it up.")
        api_key = prompt_for_key()
        if not validate_and_save_key(api_key):
            return

    fix_dependencies(api_key)

if __name__ == "__main__":
    cli()
