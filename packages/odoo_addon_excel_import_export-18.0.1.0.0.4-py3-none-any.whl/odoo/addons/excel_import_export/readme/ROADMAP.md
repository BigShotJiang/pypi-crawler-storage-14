- Module extension e.g., excel_import_export_async, that add ability to
  execute as async process.
