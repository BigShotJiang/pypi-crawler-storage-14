from .story import Story, story


__all__ = ['Story', 'story']