# Custom Measurement Method  
---  
## Overview  
The *Custom* measurement method allows users to perform measurements using pre-recorded patterns stored in a folder of their choice.  

one file is considered as a pattern 

"*.png", "*.jpg", "*.jpeg", "*.bmp", "*.tif", "*.tiff", "*.npy", "*.npz" format can be load.  

This measurement method is useful for the following use cases:  

- Performing **HAS measurements** with a static scene, to repeat measurements.  
- Experimenting with **new low-level imaging methods** if needed.  

| Development Status | Technique Specificity | Measurement Output Format | Example Patterns |
|--------------------|-----------------------|----------------------------|------------------|
| Functional and final | Use of custom patterns | Raw measurements: spectra / masks / metadata | |


## install 
tested with python 3.9
```bash
pip install onepix_custom
```

## 🔗 Source Code  
📁 Access the source code on GitHub:  
👉 [ONE-PIX – Custom Imaging Method](https://github.com/PhotonicsOpenProjects/ONE-PIX/tree/main/plugins/imaging_methods/Custom)

## 🧪 Author & Contributor  
🔧 Made by [POP](https://www.photonics-open-projects.com/) 💡