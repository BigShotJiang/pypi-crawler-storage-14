import numpy as np


class Reconstruction:

    def __init__(self, spectra, patterns_order):
        return

    def image_reconstruction(self):
        pass

    def save_reconstructed_image(
        self, datacube, wavelengths, header, filename, save_path=None
    ):
        pass
