#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
断言模块
"""
from .smart_assertion import SmartAssertion

__all__ = ['SmartAssertion']

