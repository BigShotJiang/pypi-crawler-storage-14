"""Allow package to be run with python -m fastrep."""

from .cli import cli

if __name__ == '__main__':
    cli()