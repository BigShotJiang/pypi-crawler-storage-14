__version__ = "1.3.0"

def main():
    from .main import main as _main
    return _main()