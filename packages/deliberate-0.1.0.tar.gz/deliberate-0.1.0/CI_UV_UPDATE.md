# CI Updated to Use uv

## Changes Made

### Test Job
- **Removed**: `pip install --upgrade pip` and `pip install -e ".[dev]"`
- **Added**: 
  - `astral-sh/setup-uv@v4` action with caching enabled
  - `uv python install` for Python version management
  - `uv sync --dev` for dependency installation
  - `uv run` prefix for all commands (ruff, mypy, pytest)

### Lint Job
- **Removed**: `pip install ruff`
- **Added**: 
  - `astral-sh/setup-uv@v4` action with caching
  - `uv python install 3.11`
  - `uv sync --dev`
  - `uv run` prefix for ruff commands

## Benefits

1. **Faster CI runs**: uv is 10-100x faster than pip
2. **Built-in caching**: uv.lock-based dependency caching
3. **Consistent environments**: Same tool for local dev and CI
4. **Reliable resolution**: Reproducible dependency resolution
5. **Native Python management**: No need for actions/setup-python@v5

## Configuration

```yaml
- name: Install uv
  uses: astral-sh/setup-uv@v4
  with:
    enable-cache: true
    cache-dependency-glob: "uv.lock"

- name: Set up Python ${{ matrix.python-version }}
  run: uv python install ${{ matrix.python-version }}

- name: Install dependencies
  run: uv sync --dev
```

## Running Commands

All commands now use `uv run` prefix:
- `uv run ruff check src/ tests/`
- `uv run mypy src/deliberate/`
- `uv run pytest tests/unit/`
