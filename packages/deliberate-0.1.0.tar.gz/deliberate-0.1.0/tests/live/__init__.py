"""Live tests for deliberate (require real LLM APIs)."""
