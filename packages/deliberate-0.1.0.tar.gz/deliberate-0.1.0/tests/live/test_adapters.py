"""Live tests for LLM adapters.

These tests require real API access and cost money.
They are skipped by default unless RUN_LIVE_LLM_TESTS=1 is set.
"""

import os

import pytest

# Skip all tests in this module unless explicitly enabled
pytestmark = [
    pytest.mark.live_llm,
    pytest.mark.skipif(
        "RUN_LIVE_LLM_TESTS" not in os.environ,
        reason="Live LLM tests disabled (set RUN_LIVE_LLM_TESTS=1 to enable)",
    ),
]


class TestLiveAdapters:
    """Live tests for real LLM adapters."""

    @pytest.mark.asyncio
    async def test_cli_adapter_claude_stdin_handling(self):
        """Test that Claude CLI adapter handles stdin correctly (non-interactive).

        This test verifies that the CLI adapter properly closes stdin when invoking
        subprocess tools, preventing them from blocking on interactive input.

        Cost: ~$0.04 per run
        """
        from deliberate.adapters.cli_adapter import CLIAdapter

        adapter = CLIAdapter(
            name="claude",
            command=["claude", "--print", "-p"],
            timeout_seconds=120,
        )

        response = await adapter.call(
            prompt="Return only the word 'success' and nothing else.",
            working_dir=".",
        )

        assert response.content.strip().lower() == "success"
        assert response.duration_seconds < 120
        assert response.token_usage > 0

    @pytest.mark.asyncio
    async def test_cli_adapter_gemini_stdin_handling(self):
        """Test that Gemini CLI adapter handles stdin correctly (non-interactive).

        Cost: ~$0.01 per run
        """
        from deliberate.adapters.cli_adapter import CLIAdapter

        adapter = CLIAdapter(
            name="gemini",
            command=["gemini", "-y", "--output-format", "json"],
            timeout_seconds=120,
        )

        response = await adapter.call(
            prompt="Return only the word 'success' and nothing else.",
            working_dir=".",
        )

        assert "success" in response.content.lower()
        assert response.duration_seconds < 120
        assert response.token_usage > 0

    @pytest.mark.asyncio
    async def test_api_adapter_smoke(self):
        """Smoke test for API adapter with real LLM."""
        # This would test with a real OpenAI API call
        # Skipped by default to avoid costs
        pytest.skip("Implement when testing with real API")
