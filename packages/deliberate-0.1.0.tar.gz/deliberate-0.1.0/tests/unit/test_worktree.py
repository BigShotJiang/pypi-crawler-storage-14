"""Tests for git worktree management."""

import pytest

from deliberate.git.worktree import WorktreeManager


class TestWorktreeManager:
    """Tests for WorktreeManager."""

    def test_create_worktree(self, temp_git_repo):
        """Should create a new worktree."""
        mgr = WorktreeManager(temp_git_repo)
        worktree = mgr.create("test-wt")

        assert worktree.path.exists()
        assert worktree.name == "test-wt"
        assert (worktree.path / "README.md").exists()

    def test_create_worktree_auto_name(self, temp_git_repo):
        """Should auto-generate name if not provided."""
        mgr = WorktreeManager(temp_git_repo)
        worktree = mgr.create()

        assert worktree.name.startswith("jury-")
        assert len(worktree.name) == 13  # "jury-" + 8 hex chars

    def test_create_duplicate_fails(self, temp_git_repo):
        """Should fail when creating duplicate worktree."""
        mgr = WorktreeManager(temp_git_repo)
        mgr.create("test-wt")

        with pytest.raises(ValueError, match="already exists"):
            mgr.create("test-wt")

    def test_remove_worktree(self, temp_git_repo):
        """Should remove a worktree."""
        mgr = WorktreeManager(temp_git_repo)
        worktree = mgr.create("test-wt")
        wt_path = worktree.path

        mgr.remove("test-wt")

        assert not wt_path.exists()
        assert mgr.active_count == 0

    def test_remove_nonexistent(self, temp_git_repo):
        """Should handle removing nonexistent worktree gracefully."""
        mgr = WorktreeManager(temp_git_repo)
        mgr.remove("nonexistent")  # Should not raise

    def test_get_diff(self, temp_git_repo):
        """Should get diff of changes in worktree."""
        mgr = WorktreeManager(temp_git_repo)
        worktree = mgr.create("test-wt")

        # Make a change
        (worktree.path / "new_file.txt").write_text("Hello\n")

        # Diff should show the new file (untracked files not in diff)
        # Let's stage it first
        import subprocess

        subprocess.run(
            ["git", "add", "new_file.txt"],
            cwd=worktree.path,
            check=True,
        )

        diff = mgr.get_diff(worktree)
        # git diff HEAD shows staged changes
        assert "new_file.txt" in diff or diff == ""  # May vary by git version

    def test_get_status(self, temp_git_repo):
        """Should get status of worktree."""
        mgr = WorktreeManager(temp_git_repo)
        worktree = mgr.create("test-wt")

        # Make a change
        (worktree.path / "new_file.txt").write_text("Hello\n")

        status = mgr.get_status(worktree)
        assert "new_file.txt" in status

    def test_temporary_context_manager(self, temp_git_repo):
        """Should cleanup worktree after context."""
        mgr = WorktreeManager(temp_git_repo)

        with mgr.temporary("test-wt") as worktree:
            wt_path = worktree.path
            assert wt_path.exists()

        assert not wt_path.exists()

    def test_cleanup_all(self, temp_git_repo):
        """Should cleanup all worktrees."""
        mgr = WorktreeManager(temp_git_repo)
        wt1 = mgr.create("wt1")
        wt2 = mgr.create("wt2")

        mgr.cleanup_all()

        assert not wt1.path.exists()
        assert not wt2.path.exists()
        assert mgr.active_count == 0

    def test_list_worktrees(self, temp_git_repo):
        """Should list all active worktrees."""
        mgr = WorktreeManager(temp_git_repo)
        mgr.create("wt1")
        mgr.create("wt2")

        worktrees = mgr.list_worktrees()
        names = [wt.name for wt in worktrees]

        assert "wt1" in names
        assert "wt2" in names
        assert len(worktrees) == 2

    def test_active_count(self, temp_git_repo):
        """Should track active worktree count."""
        mgr = WorktreeManager(temp_git_repo)

        assert mgr.active_count == 0

        mgr.create("wt1")
        assert mgr.active_count == 1

        mgr.create("wt2")
        assert mgr.active_count == 2

        mgr.remove("wt1")
        assert mgr.active_count == 1
