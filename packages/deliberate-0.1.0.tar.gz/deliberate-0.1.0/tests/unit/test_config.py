"""Tests for configuration loading."""

import tempfile

import pytest

from deliberate.config import AgentConfig, DeliberateConfig


class TestConfigLoading:
    """Tests for configuration loading."""

    def test_load_valid_config(self):
        """Should load a valid config file."""
        config_content = """
agents:
  test:
    type: fake
    behavior: echo
    capabilities: [planner]

workflow:
  planning:
    enabled: true
    agents: [test]
  execution:
    enabled: false
    agents: []
  review:
    enabled: false
    agents: []
"""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yaml", delete=False
        ) as f:
            f.write(config_content)
            f.flush()

            config = DeliberateConfig.load(f.name)

            assert "test" in config.agents
            assert config.agents["test"].type == "fake"
            assert config.workflow.planning.enabled is True
            assert config.workflow.execution.enabled is False

    def test_load_missing_file(self):
        """Should raise for missing file."""
        with pytest.raises(FileNotFoundError):
            DeliberateConfig.load("/nonexistent/path.yaml")

    def test_default_config(self):
        """Should create default config without file."""
        config = DeliberateConfig()

        assert config.agents == {}
        assert config.workflow.planning.enabled is True
        assert config.limits.budget.max_total_tokens == 500000

    def test_load_or_default_missing(self):
        """Should return default when file missing."""
        config = DeliberateConfig.load_or_default("/nonexistent/path.yaml")
        assert config is not None
        assert isinstance(config, DeliberateConfig)

    def test_get_agent(self):
        """Should get agent by name."""
        config = DeliberateConfig(
            agents={
                "test": AgentConfig(type="fake", behavior="echo"),
            }
        )

        agent = config.get_agent("test")
        assert agent.type == "fake"

    def test_get_agent_missing(self):
        """Should raise for missing agent."""
        config = DeliberateConfig()

        with pytest.raises(KeyError):
            config.get_agent("nonexistent")

    def test_get_planners(self):
        """Should filter agents by planner capability."""
        config = DeliberateConfig(
            agents={
                "planner1": AgentConfig(
                    type="fake", capabilities=["planner", "executor"]
                ),
                "reviewer1": AgentConfig(type="fake", capabilities=["reviewer"]),
            },
        )
        config.workflow.planning.agents = ["planner1", "reviewer1"]

        planners = config.get_planners()
        assert planners == ["planner1"]


class TestAgentConfig:
    """Tests for AgentConfig."""

    def test_default_values(self):
        """Should have sensible defaults."""
        agent = AgentConfig(type="fake")

        assert agent.command == []
        assert agent.capabilities == ["planner", "executor", "reviewer"]
        assert agent.config.max_tokens == 8000
        assert agent.cost.weight == 1.0

    def test_cli_agent(self):
        """Should accept CLI agent config."""
        agent = AgentConfig(
            type="cli",
            command=["claude", "--print", "-p"],
            capabilities=["planner"],
        )

        assert agent.type == "cli"
        assert agent.command == ["claude", "--print", "-p"]

    def test_mcp_agent(self):
        """Should accept MCP agent config."""
        agent = AgentConfig(
            type="mcp",
            command=["mcp-client"],
            mcp_endpoint="unix:///tmp/mcp.sock",
        )

        assert agent.type == "mcp"
        assert agent.mcp_endpoint == "unix:///tmp/mcp.sock"
