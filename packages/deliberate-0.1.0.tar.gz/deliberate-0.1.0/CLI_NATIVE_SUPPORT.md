# CLI Native Support for Deliberate

## Summary of Native CLI Capabilities

### Claude CLI

**Structured Output:**
- `--json-schema <schema>` - JSON Schema for structured output validation
- `--output-format json` - JSON output (single result)
- `--output-format stream-json` - Realtime streaming JSON

**Headless Operation:**
- `--dangerously-skip-permissions` - Bypass all permission checks
- `-p, --print` - Print response and exit (non-interactive)

**Tool Control:**
- `--tools <tools...>` - Specify available tools (e.g., "Bash,Edit,Read")
- `--allowedTools <tools...>` - Allow specific tools
- `--disallowedTools <tools...>` - Deny specific tools

**Example Command:**
```bash
claude --dangerously-skip-permissions -p --output-format json --json-schema "$SCHEMA" "$TASK"
```

### Gemini CLI

**Structured Output:**
- `-o, --output-format json` - JSON output
- `-o, --output-format stream-json` - Streaming JSON

**Headless Operation:**
- `-y` - YOLO mode (auto-approve all tool calls)
- `-p` - Non-interactive mode

**Example Command:**
```bash
gemini -y -p --output-format json "$TASK"
```

### Codex CLI

**Structured Output:**
- `--output-schema <FILE>` - JSON Schema file for response shape
- `--json` - JSONL output to stdout
- `-o, --output-last-message <FILE>` - Write final message to file

**Headless Operation:**
- `-s danger-full-access` - Full sandbox access
- `-a never` - Never ask for approval
- `--dangerously-bypass-approvals-and-sandbox` - Skip all confirmations

**Example Command:**
```bash
codex exec -s danger-full-access -a never --json "$TASK"
```

## Proposed Adapter Architecture

### 1. Execution Phase Schema

```json
{
  "type": "object",
  "properties": {
    "summary": {
      "type": "string",
      "description": "High-level summary of changes made"
    },
    "changes": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "file": {"type": "string"},
          "description": {"type": "string"}
        }
      }
    },
    "reasoning": {
      "type": "string",
      "description": "Explanation of approach taken"
    }
  },
  "required": ["summary"]
}
```

### 2. Review Phase Schema

```json
{
  "type": "object",
  "properties": {
    "scores": {
      "type": "object",
      "properties": {
        "correctness": {"type": "integer", "minimum": 1, "maximum": 10},
        "code_quality": {"type": "integer", "minimum": 1, "maximum": 10},
        "completeness": {"type": "integer", "minimum": 1, "maximum": 10},
        "clarity": {"type": "integer", "minimum": 1, "maximum": 10}
      },
      "required": ["correctness", "code_quality", "completeness", "clarity"]
    },
    "overall_score": {"type": "integer", "minimum": 1, "maximum": 10},
    "feedback": {"type": "string"},
    "concerns": {
      "type": "array",
      "items": {"type": "string"}
    }
  },
  "required": ["scores", "overall_score", "feedback"]
}
```

### 3. CLI Adapter Enhancements

The adapter should:
1. Auto-detect CLI tool from command[0]
2. Apply appropriate headless flags
3. Add structured output flags with schemas
4. Parse JSON responses
5. Extract token usage from response metadata
6. Use genai-prices for accurate cost calculation

### 4. Cost Calculation with genai-prices

```python
from genai_prices import get_model_price

# Map CLI names to model identifiers
model = "claude-sonnet-4-5-20250929" if "claude" in cmd else \
        "gemini-pro-2.0" if "gemini" in cmd else \
        "o1" if "codex" in cmd else None

price = get_model_price(model)
cost = (input_tokens * price.input_price + output_tokens * price.output_price) / 1_000_000
```

## Implementation Plan

1. Create schema files in `src/deliberate/schemas/`
2. Update `CLIAdapter` to intelligently add flags
3. Add JSON response parsing
4. Integrate genai-prices for cost calculation
5. Test each phase with each agent
6. Validate structured output is parsed correctly
