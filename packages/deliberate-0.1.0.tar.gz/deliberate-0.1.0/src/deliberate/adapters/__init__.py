"""Adapter modules for different LLM backends."""

from deliberate.adapters.base import AdapterResponse, ModelAdapter
from deliberate.adapters.cli_adapter import CLIAdapter
from deliberate.adapters.fake_adapter import FakeAdapter
from deliberate.adapters.mcp_adapter import MCPAdapter

__all__ = ["ModelAdapter", "AdapterResponse", "CLIAdapter", "FakeAdapter", "MCPAdapter"]
