"""Prompt templates for the review phase."""

REVIEW_PROMPT = """Review this code change for the given task.

## Task
{task}

## Summary of Changes
{summary}

## Diff
```diff
{diff}
```

## Scoring Criteria
Score each criterion on a scale of {scale}:
{criteria}

## Instructions
Evaluate the changes and respond with a JSON object:

```json
{{
  "scores": {{
    "correctness": <score>,
    "code_quality": <score>,
    "completeness": <score>,
    "risk": <score>
  }},
  "overall": <average_score>,
  "recommendation": "accept" | "reject" | "revise",
  "reasoning": "<detailed explanation of your evaluation>"
}}
```

Be fair and thorough in your evaluation. Consider:
- Does the code correctly implement the task?
- Is the code clean, readable, and maintainable?
- Are all aspects of the task addressed?
- Are there any risks or potential issues?"""

CRITERIA_DESCRIPTIONS = {
    "correctness": "Does the code correctly implement the required functionality?",
    "code_quality": "Is the code clean, readable, and following best practices?",
    "completeness": "Are all aspects of the task addressed, including edge cases?",
    "risk": "Are there potential issues, bugs, or security concerns? (lower is better for risk)",
}
