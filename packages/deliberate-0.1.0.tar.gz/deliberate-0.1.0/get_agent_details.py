#!/usr/bin/env python3
"""Extract detailed agent responses from deliberate execution."""

import asyncio
import json
from pathlib import Path

from deliberate.config import DeliberateConfig
from deliberate.orchestrator import Orchestrator


async def main():
    # Load config and task
    config = DeliberateConfig.load_or_default(Path("test_cli_review_config.yaml"))
    task = Path("cli_review_task.txt").read_text()

    # Run orchestrator
    orchestrator = Orchestrator(config, Path.cwd())
    result = await orchestrator.run(task)

    # Output full details
    print("\n" + "="*80)
    print("DETAILED EXECUTION RESULTS")
    print("="*80)

    for i, exec_result in enumerate(result.execution_results, 1):
        print(f"\n### Agent {i}: {exec_result.agent} ###")
        print(f"ID: {exec_result.id}")
        print(f"Success: {exec_result.success}")
        print(f"Has Diff: {bool(exec_result.diff)}")
        print(f"Duration: {exec_result.duration_seconds:.1f}s")
        print(f"Tokens: {exec_result.token_usage}")
        print("\n--- Response Summary ---")
        print(exec_result.summary[:2000] if exec_result.summary else "(no summary)")
        if exec_result.error:
            print(f"\nError: {exec_result.error}")
        print("\n" + "-"*80)


if __name__ == "__main__":
    asyncio.run(main())
