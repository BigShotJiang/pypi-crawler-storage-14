"""Tests for MCP Knowledge Graph Skills."""
