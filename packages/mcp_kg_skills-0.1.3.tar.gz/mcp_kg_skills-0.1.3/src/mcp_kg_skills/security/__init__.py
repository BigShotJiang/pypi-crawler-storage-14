"""Security and secret management for MCP Knowledge Graph Skills."""
