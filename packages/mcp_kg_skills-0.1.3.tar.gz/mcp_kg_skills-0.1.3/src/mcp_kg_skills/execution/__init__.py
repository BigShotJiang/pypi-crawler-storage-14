"""Script execution engine for MCP Knowledge Graph Skills."""
