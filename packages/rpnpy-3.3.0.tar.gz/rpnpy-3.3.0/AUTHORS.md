Terry C. Jones (@terrycojones)
Nícolas F. R. A. Prado (@nfraprado)
David J. Pattinson (@davipatti)
