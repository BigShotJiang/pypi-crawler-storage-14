"""CLI module for rpnpy."""

from .rpn import main

__all__ = ["main"]
