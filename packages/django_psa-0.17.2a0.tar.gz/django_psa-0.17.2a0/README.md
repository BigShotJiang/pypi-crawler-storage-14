# django-psa
Django app for working with various PSA REST API. Defines models (tickets, companies, etc.) and callbacks. Used in https://www.topleft.team/

Will provide a sync interface for applications to selectively implement PSA APIs, just import the sync app
and whatever PSA apps you need.