"""SDK exceptions."""


class PopingError(Exception):
    """Base error."""


class APIError(PopingError):
    def __init__(self, status_code: int, message: str, details=None):
        super().__init__(message)
        self.status_code = status_code
        self.details = details or {}


class AuthenticationError(APIError):
    pass


class RateLimitError(APIError):
    def __init__(self, retry_after=None):
        super().__init__(429, "Rate limit exceeded")
        self.retry_after = retry_after


class ResourceNotFoundError(APIError):
    pass
