"""
Storage helper wrapping PopingClient storage endpoints.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from .client import PopingClient


class Storage:
    """
    Convenience wrapper for user/shared storage operations.
    """

    def __init__(self, client: PopingClient, project_id: Optional[str] = None, end_user_id: Optional[str] = None):
        self.client = client
        self.project_id = project_id
        self.end_user_id = end_user_id

    # User storage
    def create_folder(self, name: str, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.create_folder(name, project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    def list_folders(self, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> List[str]:
        return self.client.list_folders(project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    def rename_folder(self, folder_name: str, new_name: str, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.rename_folder(folder_name, new_name, project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    def upload_file(self, file_path: str, folder: Optional[str] = None, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.upload_file(file_path, folder=folder, project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    def list_files(self, project_id: Optional[str] = None, end_user_id: Optional[str] = None, folder: Optional[str] = None) -> Dict[str, Any]:
        return self.client.list_files(project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id, folder=folder)

    def download_file(self, file_id: str, dest_path: str, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> str:
        return self.client.download_file(file_id, dest_path, project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    def download_file_bytes(self, file_id: str, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> bytes:
        dest = os.path.join("/tmp", os.path.basename(file_id) or "download")
        self.download_file(file_id, dest, project_id=project_id, end_user_id=end_user_id)
        with open(dest, "rb") as f:
            return f.read()

    def delete_file(self, file_id: str, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.delete_file(file_id, project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    def delete_folder(self, folder_name: str, project_id: Optional[str] = None, end_user_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.delete_folder(folder_name, project_id=project_id or self.project_id, end_user_id=end_user_id or self.end_user_id)

    # Shared storage
    def create_shared_folder(self, name: str, project_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.create_shared_folder(name, project_id=project_id or self.project_id)

    def list_shared_folders(self, project_id: Optional[str] = None) -> List[str]:
        return self.client.list_shared_folders(project_id=project_id or self.project_id)

    def rename_shared_folder(self, folder_name: str, new_name: str, project_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.rename_shared_folder(folder_name, new_name, project_id=project_id or self.project_id)

    def upload_shared_file(self, file_path: str, folder: Optional[str] = None, project_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.upload_shared_file(file_path, folder=folder, project_id=project_id or self.project_id)

    def list_shared_files(self, project_id: Optional[str] = None, folder: Optional[str] = None) -> Dict[str, Any]:
        return self.client.list_shared_files(project_id=project_id or self.project_id, folder=folder)

    def download_shared_file(self, file_id: str, dest_path: str, project_id: Optional[str] = None) -> str:
        return self.client.download_shared_file(file_id, dest_path, project_id=project_id or self.project_id)

    def delete_shared_file(self, file_id: str, project_id: Optional[str] = None) -> Dict[str, str]:
        return self.client.delete_shared_file(file_id, project_id=project_id or self.project_id)

    def expand_uri(self, uri: str) -> str:
        """
        Placeholder URI expander. For now, return the URI unchanged since
        backend resolves context-aware prefixes.
        """
        return uri
