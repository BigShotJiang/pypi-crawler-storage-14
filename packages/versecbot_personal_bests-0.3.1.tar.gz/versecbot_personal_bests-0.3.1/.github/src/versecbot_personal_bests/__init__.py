from .plugin import PersonalBestsPlugin

__all__ = [
    "PersonalBestsPlugin",
]
