# Iterative Data Reading

::: osmium.FileProcessor
::: osmium.OsmFileIterator
::: osmium.BufferIterator
::: osmium.zip_processors


