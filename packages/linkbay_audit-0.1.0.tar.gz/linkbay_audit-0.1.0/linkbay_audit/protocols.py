"""Protocol interfaces for audit logging."""

from typing import Protocol, Dict, Any, List, Optional, AsyncIterator
from datetime import datetime


class AuditLogStorage(Protocol):
    """
    Protocol for audit log storage.
    
    All implementations must be multi-tenant aware.
    """
    
    async def record_event(
        self,
        tenant_id: str,
        event_data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Record new audit event."""
        ...
    
    async def get_event(
        self,
        tenant_id: str,
        event_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get event by ID."""
        ...
    
    async def search_events(
        self,
        tenant_id: str,
        filters: Dict[str, Any],
        skip: int = 0,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """Search events with filters."""
        ...
    
    async def count_events(
        self,
        tenant_id: str,
        filters: Dict[str, Any],
    ) -> int:
        """Count events matching filters."""
        ...
    
    async def delete_event(
        self,
        tenant_id: str,
        event_id: str,
    ) -> bool:
        """Delete event."""
        ...
    
    async def delete_events_by_user(
        self,
        tenant_id: str,
        user_id: str,
    ) -> int:
        """Delete all events for user (GDPR)."""
        ...
    
    async def anonymize_events_by_user(
        self,
        tenant_id: str,
        user_id: str,
        anonymized_user_id: str = "anonymized",
    ) -> int:
        """Anonymize all events for user (GDPR)."""
        ...
    
    async def export_events(
        self,
        tenant_id: str,
        filters: Dict[str, Any],
    ) -> AsyncIterator[Dict[str, Any]]:
        """
        Stream events for export.
        
        Returns async iterator for memory-efficient exports.
        """
        ...
    
    async def delete_events_before(
        self,
        tenant_id: str,
        before_date: datetime,
    ) -> int:
        """Delete events before date (retention policy)."""
        ...


class EventNotifier(Protocol):
    """
    Protocol for event notifications.
    
    Optional protocol for real-time notifications.
    """
    
    async def notify(
        self,
        tenant_id: str,
        event_type: str,
        event_data: Dict[str, Any],
    ) -> None:
        """Send notification for event."""
        ...


class RedactionStrategy(Protocol):
    """
    Protocol for PII redaction.
    
    Implement custom redaction logic for sensitive fields.
    """
    
    def redact(
        self,
        data: Dict[str, Any],
        fields: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Redact sensitive fields from data.
        
        Args:
            data: Data to redact
            fields: List of field names to redact (None = use defaults)
        
        Returns:
            Redacted data
        """
        ...
