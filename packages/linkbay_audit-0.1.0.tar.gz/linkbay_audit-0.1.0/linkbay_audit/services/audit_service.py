"""Audit logging service."""

from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid

from ..protocols import AuditLogStorage, EventNotifier
from ..schemas import AuditLogCreate, AuditLogResponse, AuditLogFilter, AuditLogListResponse
from ..exceptions import EventNotFoundError
from ..constants import EventType


class AuditService:
    """
    Core audit logging service.
    
    Handles event recording, search, and retrieval.
    """
    
    def __init__(
        self,
        storage: AuditLogStorage,
        notifier: Optional[EventNotifier] = None,
    ):
        """
        Initialize audit service.
        
        Args:
            storage: Audit log storage implementation
            notifier: Optional event notifier for real-time alerts
        """
        self.storage = storage
        self.notifier = notifier
    
    async def record_event(
        self,
        tenant_id: str,
        event_data: AuditLogCreate,
    ) -> AuditLogResponse:
        """
        Record audit event.
        
        Example:
            event = await service.record_event(
                tenant_id="tenant_123",
                event_data=AuditLogCreate(
                    event_type="product_updated",
                    resource="product",
                    resource_id="prod_456",
                    user_id="user_789",
                    action="update",
                    before_snapshot={"price": 100, "stock": 50},
                    after_snapshot={"price": 90, "stock": 50},
                    metadata={"reason": "price_reduction"},
                ),
            )
        """
        event_dict = {
            **event_data.model_dump(),
            "id": str(uuid.uuid4()),
            "tenant_id": tenant_id,
            "created_at": datetime.utcnow(),
        }
        
        created = await self.storage.record_event(tenant_id, event_dict)
        
        if self.notifier:
            await self.notifier.notify(
                tenant_id,
                created["event_type"],
                created,
            )
        
        return AuditLogResponse(**created)
    
    async def get_event(
        self,
        tenant_id: str,
        event_id: str,
    ) -> AuditLogResponse:
        """Get event by ID."""
        event = await self.storage.get_event(tenant_id, event_id)
        
        if not event:
            raise EventNotFoundError(tenant_id, event_id)
        
        return AuditLogResponse(**event)
    
    async def search_events(
        self,
        tenant_id: str,
        filters: AuditLogFilter,
        skip: int = 0,
        limit: int = 100,
    ) -> AuditLogListResponse:
        """
        Search events with filters.
        
        Example:
            # Search all product updates by user in last 30 days
            results = await service.search_events(
                tenant_id="tenant_123",
                filters=AuditLogFilter(
                    resource="product",
                    action="update",
                    user_id="user_789",
                    start_date=datetime.utcnow() - timedelta(days=30),
                ),
                skip=0,
                limit=100,
            )
        """
        filter_dict = filters.model_dump(exclude_none=True)
        
        events = await self.storage.search_events(
            tenant_id, filter_dict, skip, limit
        )
        
        total = await self.storage.count_events(tenant_id, filter_dict)
        
        return AuditLogListResponse(
            events=[AuditLogResponse(**e) for e in events],
            total=total,
            skip=skip,
            limit=limit,
        )
    
    async def get_events_by_resource(
        self,
        tenant_id: str,
        resource: str,
        resource_id: str,
        skip: int = 0,
        limit: int = 100,
    ) -> AuditLogListResponse:
        """
        Get all events for specific resource.
        
        Example:
            # Get all events for order_123
            events = await service.get_events_by_resource(
                tenant_id="tenant_123",
                resource="order",
                resource_id="order_123",
            )
        """
        filters = AuditLogFilter(resource=resource, resource_id=resource_id)
        return await self.search_events(tenant_id, filters, skip, limit)
    
    async def get_events_by_user(
        self,
        tenant_id: str,
        user_id: str,
        skip: int = 0,
        limit: int = 100,
    ) -> AuditLogListResponse:
        """Get all events performed by user."""
        filters = AuditLogFilter(user_id=user_id)
        return await self.search_events(tenant_id, filters, skip, limit)
    
    async def get_events_by_ip(
        self,
        tenant_id: str,
        ip_address: str,
        skip: int = 0,
        limit: int = 100,
    ) -> AuditLogListResponse:
        """Get all events from IP address."""
        filters = AuditLogFilter(ip_address=ip_address)
        return await self.search_events(tenant_id, filters, skip, limit)
    
    async def delete_event(
        self,
        tenant_id: str,
        event_id: str,
    ) -> bool:
        """Delete event (use with caution)."""
        return await self.storage.delete_event(tenant_id, event_id)
