"""Export service for bulk exports."""

from typing import Optional, AsyncIterator
from datetime import datetime
import json
import csv
import io

from ..protocols import AuditLogStorage, RedactionStrategy
from ..schemas import ExportRequest, ExportResult, AuditLogFilter
from ..exceptions import ExportError


class ExportService:
    """
    Export service for bulk audit log exports.
    
    Handles large exports with streaming for memory efficiency.
    """
    
    def __init__(
        self,
        storage: AuditLogStorage,
        redaction_strategy: Optional[RedactionStrategy] = None,
    ):
        """
        Initialize export service.
        
        Args:
            storage: Audit log storage implementation
            redaction_strategy: Optional redaction strategy for PII
        """
        self.storage = storage
        self.redaction_strategy = redaction_strategy
    
    async def export_events(
        self,
        tenant_id: str,
        request: ExportRequest,
    ) -> ExportResult:
        """
        Export events in specified format.
        
        Example:
            # Export all events from last quarter
            result = await service.export_events(
                tenant_id="tenant_123",
                request=ExportRequest(
                    format="csv",
                    filters=AuditLogFilter(
                        start_date=datetime(2024, 1, 1),
                        end_date=datetime(2024, 3, 31),
                    ),
                    include_pii=False,
                ),
            )
            
            print(f"Exported {result.total_records} records")
            print(result.content)
        """
        filters = request.filters.model_dump(exclude_none=True) if request.filters else {}
        
        events = []
        async for event in self.storage.export_events(tenant_id, filters):
            if not request.include_pii and self.redaction_strategy:
                event = self._redact_event(event)
            events.append(event)
        
        if request.format == "jsonl":
            content = self._export_jsonl(events)
        elif request.format == "json":
            content = self._export_json(events)
        elif request.format == "csv":
            content = self._export_csv(events)
        elif request.format == "xml":
            content = self._export_xml(events)
        else:
            raise ExportError(f"Unsupported format: {request.format}")
        
        return ExportResult(
            format=request.format,
            total_records=len(events),
            content=content,
        )
    
    async def stream_export(
        self,
        tenant_id: str,
        request: ExportRequest,
    ) -> AsyncIterator[str]:
        """
        Stream export for large datasets.
        
        Example:
            async for chunk in service.stream_export(tenant_id, request):
                file.write(chunk)
        """
        filters = request.filters.model_dump(exclude_none=True) if request.filters else {}
        
        if request.format == "jsonl":
            async for event in self.storage.export_events(tenant_id, filters):
                if not request.include_pii and self.redaction_strategy:
                    event = self._redact_event(event)
                yield json.dumps(event) + "\n"
        
        elif request.format == "json":
            yield "[\n"
            first = True
            async for event in self.storage.export_events(tenant_id, filters):
                if not request.include_pii and self.redaction_strategy:
                    event = self._redact_event(event)
                if not first:
                    yield ",\n"
                yield json.dumps(event, indent=2)
                first = False
            yield "\n]"
        
        elif request.format == "csv":
            first = True
            async for event in self.storage.export_events(tenant_id, filters):
                if not request.include_pii and self.redaction_strategy:
                    event = self._redact_event(event)
                
                if first:
                    fieldnames = list(event.keys())
                    output = io.StringIO()
                    writer = csv.DictWriter(output, fieldnames=fieldnames)
                    writer.writeheader()
                    yield output.getvalue()
                    first = False
                
                output = io.StringIO()
                writer = csv.DictWriter(output, fieldnames=fieldnames)
                writer.writerow(event)
                yield output.getvalue()
        
        else:
            raise ExportError(f"Streaming not supported for format: {request.format}")
    
    def _redact_event(self, event: dict) -> dict:
        """Redact PII from event."""
        if not self.redaction_strategy:
            return event
        
        redacted = event.copy()
        
        if redacted.get("before_snapshot"):
            redacted["before_snapshot"] = self.redaction_strategy.redact(
                redacted["before_snapshot"]
            )
        
        if redacted.get("after_snapshot"):
            redacted["after_snapshot"] = self.redaction_strategy.redact(
                redacted["after_snapshot"]
            )
        
        if redacted.get("metadata"):
            redacted["metadata"] = self.redaction_strategy.redact(
                redacted["metadata"]
            )
        
        return redacted
    
    def _export_jsonl(self, events: list) -> str:
        """Export as JSONL (JSON Lines)."""
        return "\n".join(json.dumps(e) for e in events)
    
    def _export_json(self, events: list) -> str:
        """Export as JSON."""
        return json.dumps(events, indent=2)
    
    def _export_csv(self, events: list) -> str:
        """Export as CSV."""
        if not events:
            return ""
        
        output = io.StringIO()
        
        fieldnames = [
            "id", "tenant_id", "event_type", "resource", "resource_id",
            "user_id", "action", "created_at", "ip_address", "request_id",
        ]
        
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(events)
        
        return output.getvalue()
    
    def _export_xml(self, events: list) -> str:
        """Export as XML."""
        xml_lines = ['<?xml version="1.0" encoding="UTF-8"?>', '<events>']
        
        for event in events:
            xml_lines.append('  <event>')
            for key, value in event.items():
                if value is not None:
                    xml_lines.append(f'    <{key}>{self._escape_xml(str(value))}</{key}>')
            xml_lines.append('  </event>')
        
        xml_lines.append('</events>')
        return "\n".join(xml_lines)
    
    def _escape_xml(self, text: str) -> str:
        """Escape XML special characters."""
        return (text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&apos;"))
