"""GDPR compliance service."""

from typing import Optional
from datetime import datetime

from ..protocols import AuditLogStorage, RedactionStrategy
from ..schemas import GDPRDeleteRequest, GDPRExportRequest, AnonymizationResult, AuditLogFilter
from ..exceptions import GDPRComplianceError


class GDPRService:
    """
    GDPR compliance service.
    
    Handles right-to-be-forgotten and data export requests.
    """
    
    def __init__(
        self,
        storage: AuditLogStorage,
        redaction_strategy: Optional[RedactionStrategy] = None,
    ):
        """
        Initialize GDPR service.
        
        Args:
            storage: Audit log storage implementation
            redaction_strategy: Optional redaction strategy for PII
        """
        self.storage = storage
        self.redaction_strategy = redaction_strategy
    
    async def delete_user_data(
        self,
        tenant_id: str,
        request: GDPRDeleteRequest,
    ) -> AnonymizationResult:
        """
        Delete or anonymize user data (GDPR right-to-be-forgotten).
        
        Example:
            # Anonymize all events for user
            result = await service.delete_user_data(
                tenant_id="tenant_123",
                request=GDPRDeleteRequest(
                    user_id="user_789",
                    delete_mode="anonymize",
                ),
            )
            
            print(f"Anonymized {result.events_anonymized} events")
        """
        if request.delete_mode == "delete":
            count = await self.storage.delete_events_by_user(
                tenant_id,
                request.user_id,
            )
            
            return AnonymizationResult(
                user_id=request.user_id,
                events_anonymized=count,
                anonymized_user_id="deleted",
            )
        elif request.delete_mode == "anonymize":
            anonymized_id = f"anonymized_{request.user_id[:8]}"
            
            count = await self.storage.anonymize_events_by_user(
                tenant_id,
                request.user_id,
                anonymized_id,
            )
            
            return AnonymizationResult(
                user_id=request.user_id,
                events_anonymized=count,
                anonymized_user_id=anonymized_id,
            )
        else:
            raise GDPRComplianceError(f"Invalid delete mode: {request.delete_mode}")
    
    async def export_user_data(
        self,
        tenant_id: str,
        request: GDPRExportRequest,
    ) -> str:
        """
        Export user data in portable format (GDPR).
        
        Example:
            # Export all user events
            jsonl_data = await service.export_user_data(
                tenant_id="tenant_123",
                request=GDPRExportRequest(
                    user_id="user_789",
                    format="jsonl",
                ),
            )
        """
        filters = {
            "user_id": request.user_id,
        }
        
        if request.start_date:
            filters["start_date"] = request.start_date
        if request.end_date:
            filters["end_date"] = request.end_date
        
        events = []
        async for event in self.storage.export_events(tenant_id, filters):
            if self.redaction_strategy:
                event = self._redact_event(event)
            events.append(event)
        
        if request.format == "jsonl":
            import json
            return "\n".join(json.dumps(e) for e in events)
        
        elif request.format == "json":
            import json
            return json.dumps(events, indent=2)
        
        elif request.format == "csv":
            return self._events_to_csv(events)
        
        else:
            raise GDPRComplianceError(f"Unsupported format: {request.format}")
    
    def _redact_event(self, event: dict) -> dict:
        """Redact PII from event."""
        if not self.redaction_strategy:
            return event
        
        redacted = event.copy()
        
        if redacted.get("before_snapshot"):
            redacted["before_snapshot"] = self.redaction_strategy.redact(
                redacted["before_snapshot"]
            )
        
        if redacted.get("after_snapshot"):
            redacted["after_snapshot"] = self.redaction_strategy.redact(
                redacted["after_snapshot"]
            )
        
        if redacted.get("metadata"):
            redacted["metadata"] = self.redaction_strategy.redact(
                redacted["metadata"]
            )
        
        return redacted
    
    def _events_to_csv(self, events: list) -> str:
        """Convert events to CSV format."""
        import csv
        import io
        
        if not events:
            return ""
        
        output = io.StringIO()
        
        fieldnames = [
            "id", "tenant_id", "event_type", "resource", "resource_id",
            "user_id", "action", "created_at", "ip_address",
        ]
        
        writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(events)
        
        return output.getvalue()
