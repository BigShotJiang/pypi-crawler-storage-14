"""Pydantic schemas for audit logging."""

from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class AuditLogDTO(BaseModel):
    """Audit log data transfer object."""
    id: str
    tenant_id: str
    event_type: str
    resource: str
    resource_id: Optional[str] = None
    user_id: Optional[str] = None
    request_id: Optional[str] = None
    action: str
    before_snapshot: Optional[Dict[str, Any]] = None
    after_snapshot: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    created_at: datetime
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AuditLogCreate(BaseModel):
    """Create audit log request."""
    event_type: str
    resource: str
    resource_id: Optional[str] = None
    user_id: Optional[str] = None
    request_id: Optional[str] = None
    action: str
    before_snapshot: Optional[Dict[str, Any]] = None
    after_snapshot: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AuditLogFilter(BaseModel):
    """Filter parameters for audit log search."""
    event_type: Optional[str] = None
    resource: Optional[str] = None
    resource_id: Optional[str] = None
    user_id: Optional[str] = None
    request_id: Optional[str] = None
    action: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    ip_address: Optional[str] = None


class AuditLogResponse(AuditLogDTO):
    """Audit log response."""
    pass


class AuditLogListResponse(BaseModel):
    """Paginated audit log list response."""
    events: List[AuditLogResponse]
    total: int
    skip: int
    limit: int


class ExportRequest(BaseModel):
    """Export request."""
    format: str = "jsonl"
    filters: Optional[AuditLogFilter] = None
    include_pii: bool = False


class ExportResult(BaseModel):
    """Export result."""
    format: str
    total_records: int
    file_path: Optional[str] = None
    content: Optional[str] = None


class GDPRDeleteRequest(BaseModel):
    """GDPR delete request."""
    user_id: str
    delete_mode: str = "anonymize"


class GDPRExportRequest(BaseModel):
    """GDPR export request."""
    user_id: str
    format: str = "jsonl"
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None


class AnonymizationResult(BaseModel):
    """Anonymization result."""
    user_id: str
    events_anonymized: int
    anonymized_user_id: str
