"""FastAPI router for audit API."""

from typing import Optional
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse

from .services import AuditService, GDPRService, ExportService
from .schemas import (
    AuditLogCreate,
    AuditLogResponse,
    AuditLogListResponse,
    AuditLogFilter,
    ExportRequest,
    ExportResult,
    GDPRDeleteRequest,
    GDPRExportRequest,
    AnonymizationResult,
)
from .exceptions import EventNotFoundError, GDPRComplianceError, ExportError


def create_audit_router(
    get_audit_service: callable,
    get_gdpr_service: callable,
    get_export_service: callable,
    prefix: str = "/audit",
) -> APIRouter:
    """
    Create FastAPI router for audit API.
    
    Example:
        def get_audit_service() -> AuditService:
            storage = get_storage()
            notifier = get_notifier()
            return AuditService(storage, notifier)
        
        router = create_audit_router(
            get_audit_service=get_audit_service,
            get_gdpr_service=get_gdpr_service,
            get_export_service=get_export_service,
            prefix="/api/v1/audit",
        )
        
        app.include_router(router)
    """
    router = APIRouter(prefix=prefix, tags=["audit"])
    
    @router.post(
        "/{tenant_id}/events",
        response_model=AuditLogResponse,
        status_code=status.HTTP_201_CREATED,
    )
    async def record_event(
        tenant_id: str,
        event_data: AuditLogCreate,
        service: AuditService = Depends(get_audit_service),
    ):
        """
        Record audit event.
        
        Requires: audit:write permission
        """
        return await service.record_event(tenant_id, event_data)
    
    @router.get(
        "/{tenant_id}/events",
        response_model=AuditLogListResponse,
    )
    async def list_events(
        tenant_id: str,
        event_type: Optional[str] = None,
        resource: Optional[str] = None,
        resource_id: Optional[str] = None,
        user_id: Optional[str] = None,
        action: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        ip_address: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
        service: AuditService = Depends(get_audit_service),
    ):
        """
        List/search audit events.
        
        Requires: audit:read permission
        """
        filters = AuditLogFilter(
            event_type=event_type,
            resource=resource,
            resource_id=resource_id,
            user_id=user_id,
            action=action,
            start_date=start_date,
            end_date=end_date,
            ip_address=ip_address,
        )
        
        return await service.search_events(tenant_id, filters, skip, limit)
    
    @router.get(
        "/{tenant_id}/events/{event_id}",
        response_model=AuditLogResponse,
    )
    async def get_event(
        tenant_id: str,
        event_id: str,
        service: AuditService = Depends(get_audit_service),
    ):
        """
        Get specific event.
        
        Requires: audit:read permission
        """
        try:
            return await service.get_event(tenant_id, event_id)
        except EventNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    @router.get(
        "/{tenant_id}/resources/{resource}/{resource_id}",
        response_model=AuditLogListResponse,
    )
    async def get_resource_events(
        tenant_id: str,
        resource: str,
        resource_id: str,
        skip: int = 0,
        limit: int = 100,
        service: AuditService = Depends(get_audit_service),
    ):
        """
        Get all events for resource.
        
        Requires: audit:read permission
        """
        return await service.get_events_by_resource(
            tenant_id, resource, resource_id, skip, limit
        )
    
    @router.get(
        "/{tenant_id}/users/{user_id}",
        response_model=AuditLogListResponse,
    )
    async def get_user_events(
        tenant_id: str,
        user_id: str,
        skip: int = 0,
        limit: int = 100,
        service: AuditService = Depends(get_audit_service),
    ):
        """
        Get all events by user.
        
        Requires: audit:read permission
        """
        return await service.get_events_by_user(
            tenant_id, user_id, skip, limit
        )
    
    @router.post(
        "/{tenant_id}/export",
        response_model=ExportResult,
    )
    async def export_events(
        tenant_id: str,
        request: ExportRequest,
        service: ExportService = Depends(get_export_service),
    ):
        """
        Export events in specified format.
        
        Requires: audit:export permission
        """
        try:
            return await service.export_events(tenant_id, request)
        except ExportError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.post(
        "/{tenant_id}/export/stream",
    )
    async def stream_export_events(
        tenant_id: str,
        request: ExportRequest,
        service: ExportService = Depends(get_export_service),
    ):
        """
        Stream export for large datasets.
        
        Requires: audit:export permission
        """
        try:
            media_type = {
                "jsonl": "application/x-ndjson",
                "json": "application/json",
                "csv": "text/csv",
            }.get(request.format, "text/plain")
            
            return StreamingResponse(
                service.stream_export(tenant_id, request),
                media_type=media_type,
            )
        except ExportError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.post(
        "/{tenant_id}/gdpr/delete",
        response_model=AnonymizationResult,
    )
    async def delete_user_data(
        tenant_id: str,
        request: GDPRDeleteRequest,
        service: GDPRService = Depends(get_gdpr_service),
    ):
        """
        Delete or anonymize user data (GDPR).
        
        Requires: gdpr:delete permission
        """
        try:
            return await service.delete_user_data(tenant_id, request)
        except GDPRComplianceError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.post(
        "/{tenant_id}/gdpr/export",
        response_class=StreamingResponse,
    )
    async def export_user_data(
        tenant_id: str,
        request: GDPRExportRequest,
        service: GDPRService = Depends(get_gdpr_service),
    ):
        """
        Export user data for GDPR request.
        
        Requires: gdpr:export permission
        """
        try:
            content = await service.export_user_data(tenant_id, request)
            
            media_type = {
                "jsonl": "application/x-ndjson",
                "json": "application/json",
                "csv": "text/csv",
            }.get(request.format, "text/plain")
            
            return StreamingResponse(
                iter([content]),
                media_type=media_type,
                headers={
                    "Content-Disposition": f"attachment; filename=user_{request.user_id}_data.{request.format}"
                },
            )
        except GDPRComplianceError as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e),
            )
    
    @router.delete(
        "/{tenant_id}/events/{event_id}",
        status_code=status.HTTP_204_NO_CONTENT,
    )
    async def delete_event(
        tenant_id: str,
        event_id: str,
        service: AuditService = Depends(get_audit_service),
    ):
        """
        Delete event (use with caution).
        
        Requires: audit:delete permission
        """
        try:
            await service.delete_event(tenant_id, event_id)
        except EventNotFoundError as e:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=str(e),
            )
    
    return router
