"""Custom exceptions for audit logging."""


class AuditError(Exception):
    """Base exception for audit system."""
    pass


class EventNotFoundError(AuditError):
    """Event not found."""
    def __init__(self, tenant_id: str, event_id: str):
        self.tenant_id = tenant_id
        self.event_id = event_id
        super().__init__(f"Event {event_id} not found in tenant {tenant_id}")


class InvalidFilterError(AuditError):
    """Invalid filter parameters."""
    def __init__(self, message: str):
        super().__init__(f"Invalid filter: {message}")


class ExportError(AuditError):
    """Export operation failed."""
    def __init__(self, message: str):
        super().__init__(f"Export failed: {message}")


class GDPRComplianceError(AuditError):
    """GDPR compliance operation failed."""
    def __init__(self, message: str):
        super().__init__(f"GDPR operation failed: {message}")
