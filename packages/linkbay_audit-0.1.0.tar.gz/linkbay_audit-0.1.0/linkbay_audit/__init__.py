"""
LinkBay-Audit: Protocol-based, database-agnostic audit logging and GDPR compliance.

Multi-tenant audit trail for SaaS applications.
"""

__version__ = "0.1.0"

# Constants and Enums
from .constants import (
    EventType,
    ActionType,
    ExportFormat,
    RetentionPolicy,
)

# Exceptions
from .exceptions import (
    AuditError,
    EventNotFoundError,
    InvalidFilterError,
    ExportError,
    GDPRComplianceError,
)

# Protocols
from .protocols import (
    AuditLogStorage,
    EventNotifier,
    RedactionStrategy,
)

# Schemas
from .schemas import (
    AuditLogDTO,
    AuditLogCreate,
    AuditLogFilter,
    AuditLogResponse,
    AuditLogListResponse,
    ExportRequest,
    ExportResult,
    GDPRDeleteRequest,
    GDPRExportRequest,
    AnonymizationResult,
)

# Services
from .services.audit_service import AuditService
from .services.gdpr_service import GDPRService
from .services.export_service import ExportService

# Router
from .router import create_audit_router

__all__ = [
    # Version
    "__version__",
    # Constants
    "EventType",
    "ActionType",
    "ExportFormat",
    "RetentionPolicy",
    # Exceptions
    "AuditError",
    "EventNotFoundError",
    "InvalidFilterError",
    "ExportError",
    "GDPRComplianceError",
    # Protocols
    "AuditLogStorage",
    "EventNotifier",
    "RedactionStrategy",
    # Schemas
    "AuditLogDTO",
    "AuditLogCreate",
    "AuditLogFilter",
    "AuditLogResponse",
    "AuditLogListResponse",
    "ExportRequest",
    "ExportResult",
    "GDPRDeleteRequest",
    "GDPRExportRequest",
    "AnonymizationResult",
    # Services
    "AuditService",
    "GDPRService",
    "ExportService",
    # Router
    "create_audit_router",
]
