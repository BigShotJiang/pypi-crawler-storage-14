"""Constants and enumerations for audit logging."""

from enum import Enum


class EventType(str, Enum):
    """Audit event types."""
    # User events
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    USER_LOGIN_FAILED = "user_login_failed"
    USER_PASSWORD_CHANGED = "user_password_changed"
    USER_ROLE_CHANGED = "user_role_changed"
    
    # Product events
    PRODUCT_CREATED = "product_created"
    PRODUCT_UPDATED = "product_updated"
    PRODUCT_DELETED = "product_deleted"
    PRODUCT_PUBLISHED = "product_published"
    PRODUCT_UNPUBLISHED = "product_unpublished"
    
    # Order events
    ORDER_CREATED = "order_created"
    ORDER_UPDATED = "order_updated"
    ORDER_CANCELLED = "order_cancelled"
    ORDER_FULFILLED = "order_fulfilled"
    ORDER_REFUNDED = "order_refunded"
    
    # Payment events
    PAYMENT_PROCESSED = "payment_processed"
    PAYMENT_FAILED = "payment_failed"
    PAYMENT_REFUNDED = "payment_refund"
    
    # Inventory events
    INVENTORY_ADJUSTED = "inventory_adjustment"
    INVENTORY_TRANSFERRED = "inventory_transfer"
    
    # Permission events
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_REVOKED = "permission_revoked"
    
    # Data events
    DATA_EXPORTED = "data_exported"
    DATA_IMPORTED = "data_imported"
    DATA_DELETED = "data_deleted"
    
    # GDPR events
    GDPR_EXPORT_REQUESTED = "gdpr_export_requested"
    GDPR_DELETE_REQUESTED = "gdpr_delete_requested"
    GDPR_DATA_ANONYMIZED = "gdpr_data_anonymized"
    
    # System events
    SYSTEM_ERROR = "system_error"
    SYSTEM_WARNING = "system_warning"
    SYSTEM_INFO = "system_info"
    
    # Custom
    CUSTOM = "custom"


class ActionType(str, Enum):
    """Action types for audit events."""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    EXPORT = "export"
    IMPORT = "import"
    LOGIN = "login"
    LOGOUT = "logout"
    GRANT = "grant"
    REVOKE = "revoke"
    APPROVE = "approve"
    REJECT = "reject"
    PUBLISH = "publish"
    UNPUBLISH = "unpublish"
    ANONYMIZE = "anonymize"


class ExportFormat(str, Enum):
    """Export format types."""
    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"
    XML = "xml"


class RetentionPolicy(str, Enum):
    """Retention policy types."""
    DAYS_30 = "30_days"
    DAYS_90 = "90_days"
    DAYS_180 = "180_days"
    YEAR_1 = "1_year"
    YEARS_2 = "2_years"
    YEARS_7 = "7_years"
    FOREVER = "forever"


# Retention policy durations in days
RETENTION_DAYS = {
    RetentionPolicy.DAYS_30: 30,
    RetentionPolicy.DAYS_90: 90,
    RetentionPolicy.DAYS_180: 180,
    RetentionPolicy.YEAR_1: 365,
    RetentionPolicy.YEARS_2: 730,
    RetentionPolicy.YEARS_7: 2555,
    RetentionPolicy.FOREVER: None,
}


# PII fields for redaction
PII_FIELDS = [
    "email",
    "phone",
    "phone_number",
    "address",
    "street",
    "city",
    "postal_code",
    "zip_code",
    "credit_card",
    "card_number",
    "ssn",
    "passport",
    "tax_id",
    "name",
    "first_name",
    "last_name",
    "full_name",
]
