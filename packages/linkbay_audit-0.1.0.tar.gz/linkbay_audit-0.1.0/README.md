# LinkBay-Audit

**Version**: 0.1.0  
**License**: Proprietary  
**Python**: 3.8+  

Protocol-based, database-agnostic audit logging and GDPR event tracking for SaaS multi-tenant ecosystems.

## Project description

LinkBay-Audit fornisce un audit layer centralizzato per l'ecosistema LinkBay. È pensato per raccogliere eventi da `LinkBay-Auth`, `LinkBay-Orders`, `LinkBay-Catalog` e dagli altri servizi della piattaforma, preservando l'indipendenza dallo storage e consentendo policy di compliance differenziate per tenant. L'architettura è pienamente async, mette al centro il multi-tenant e delega a protocolli estendibili tutte le integrazioni infrastrutturali (database, code, sistemi SIEM, storage freddo).

## Principali capacità

- Protocollo `AuditLogStorage` per memorizzare eventi in qualsiasi datastore (SQL, NoSQL, data lake).
- Servizi `AuditService`, `GDPRService`, `ExportService` ottimizzati per workload multi-tenant e streaming export.
- Supporto GDPR nativo: anonimizzazione vs cancellazione, export portabile, strumenti per data subject request.
- Notifiche real-time tramite `EventNotifier` e strategie di redazione con `RedactionStrategy` per minimizzare i dati sensibili.
- Router FastAPI opzionale con dipendenze iniettabili e hook RBAC coerenti con il modello LinkBay-Roles.

## Indice

- [Project description](#project-description)
- [Principali capacità](#principali-capacità)
- [Requisiti](#requisiti)
- [Architettura](#architettura)
- [Use cases tipici](#use-cases-tipici)
- [Integrazione con l'ecosistema LinkBay](#integrazione-con-lecosistema-linkbay)
- [Quick start](#quick-start)
- [Retention & GDPR](#retention--gdpr)
- [Performance & storage](#performance--storage)
- [Security model](#security-model)
- [FAQ performance e sicurezza](#faq-performance-e-sicurezza)
- [Troubleshooting](#troubleshooting)
- [Event types](#event-types)
- [Supporto e licenza](#supporto-e-licenza)

## Requisiti

| Requisito | Dettagli |
| --- | --- |
| Python | 3.8 o superiore |
| Dipendenze core | `pydantic>=2.0.0` |
| Extra opzionali | `linkbay-audit[fastapi]` abilita il router REST |
| Storage consigliati | PostgreSQL + JSONB, MongoDB, S3/data lake per archiviazione fredda |
| Ambienti | Multi-tenant SaaS, workload async, compliance EU |

## Architettura

Zero-coupling design:
- **Protocol-based**: storage, notifiche e redazione sono astratte tramite `Protocol` per eliminare lock-in.
- **Database-agnostic**: nessun ORM o schema imposto; il provider decide come serializzare gli eventi.
- **Multi-tenant first**: ogni API richiede `tenant_id` e le policy di retention sono parametrizzabili per tenant.
- **Async native**: tutti i servizi sono async, pronti per deploy in ambienti uvicorn/anyio.
- **Streaming exports**: `ExportService.stream_export` restituisce `AsyncIterator` per gestire dataset voluminosi.

## Use cases tipici

- Audit delle modifiche prodotto e aggiornamenti catalogo con confronto before/after.
- Tracciamento accessi amministrativi e cambio ruoli su LinkBay-Auth con export per revisori.
- Investigation di contestazioni pagamento partendo da `ORDER_REFUNDED` e tracciando la catena eventi.
- Analisi sicurezza su login sospetti (IP anomali, fail consecutivi) con notifiche verso SIEM.
- Gestione richieste GDPR (DSAR) con export per utente e anonimizzazione selettiva.

## Integrazione con l'ecosistema LinkBay

- `LinkBay-Auth`: impacchetta eventi login/logout e variazione ruoli tramite helper `record_event` con `EventType.USER_*`.
- `LinkBay-Orders`: registra creazione/fulfillment/refund, allegando metadati ordine per dispute.
- `LinkBay-Catalog`: streamma aggiornamenti inventario e prezzi, utile per audit marketing.
- Usa `EventNotifier` per inviare webhook interni al bus di LinkBay-Notifications o a strumenti SIEM esterni.
- Integra il router FastAPI all'interno di LinkBay-Site o LinkBay-Admin sfruttando le stesse dipendenze e policy RBAC.

## Quick start

### 1. Sincronizza i servizi core

```python
from linkbay_audit import AuditService, AuditLogCreate

service = AuditService(storage=your_storage_impl)

event = await service.record_event(
    tenant_id="tenant_123",
    event_data=AuditLogCreate(
        event_type="product_updated",
        resource="product",
        resource_id="prod_456",
        user_id="user_789",
        action="update",
        before_snapshot={"price": 100, "stock": 50},
        after_snapshot={"price": 90, "stock": 50},
        ip_address="192.168.1.1",
        metadata={"reason": "price_reduction"},
    ),
)
```

### 2. Ricerca multi-criterio

```python
from linkbay_audit import AuditLogFilter
from datetime import datetime, timedelta

results = await service.search_events(
    tenant_id="tenant_123",
    filters=AuditLogFilter(
        resource="product",
        user_id="user_789",
        start_date=datetime.utcnow() - timedelta(days=30),
    ),
    limit=100,
)
```

### 3. GDPR: anonimizza vs cancella

```python
from linkbay_audit import GDPRService, GDPRDeleteRequest

gdpr_service = GDPRService(storage=your_storage_impl)

# Anonimizzazione irreversibile del soggetto interessato
result = await gdpr_service.delete_user_data(
    tenant_id="tenant_123",
    request=GDPRDeleteRequest(
        user_id="user_789",
        delete_mode="anonymize",
    ),
)
```

### 4. Export streaming

```python
from linkbay_audit import ExportService, ExportRequest

export_service = ExportService(storage=your_storage_impl)

# Export CSV chunked, compatibile con storage freddo
async for chunk in export_service.stream_export(
    tenant_id="tenant_123",
    request=ExportRequest(format="csv", include_pii=False),
):
    await file.write(chunk)
```

### 5. FastAPI router factory

```python
from fastapi import FastAPI
from linkbay_audit import create_audit_router

app = FastAPI()

router = create_audit_router(
    get_audit_service=get_audit_service,
    get_gdpr_service=get_gdpr_service,
    get_export_service=get_export_service,
    prefix="/api/v1/audit",
)

app.include_router(router)
```

## Retention & GDPR

- **Policy configurabili**: `linkbay_audit.constants.RetentionPolicy` offre valori simbolici (`DAYS_30`, `YEARS_7`, ecc.) da associare a ciascun tenant.
- **Enforcement**: pianifica un job (Celery, APScheduler, cron async) che richiama `AuditLogStorage.delete_events_before` sulla base della retention scelta.

    ```python
    async def enforce_retention(tenant_id: str, retention):
        cutoff = datetime.utcnow() - retention.delta
        deleted = await storage.delete_events_before(tenant_id, cutoff)
        return deleted
    ```

- **Anonimizzazione vs cancellazione**: `GDPRService.delete_user_data` accetta `delete_mode`:
  - `anonymize`: maschera user_id e PII preservando l'audit trail.
  - `delete`: rimuove completamente gli eventi (usa solo quando legittimo).
- **Data portability**: `ExportService` genera stream JSON/CSV filtrabili per soggetto interessato, loggando le richieste via `EventNotifier`.
- **Data minimization**: implementa `RedactionStrategy` per mascherare IP/email di default e sbloccarli solo con flag operativo esplicito.

## Performance & storage

- Struttura gli eventi per partizioni temporali (es. tabelle `audit_events_YYYY_MM`) o bucket S3 per tenere basso l'indice primario.
- Per workload ad alto volume usa storage append-only con compressione (ClickHouse, BigQuery) e un layer ETL che implementi `AuditLogStorage`.
- Gli export chunked riducono la memoria del worker: puoi configurare la dimensione dei blocchi nel provider storage.
- Considera indici su `tenant_id`, `event_type`, `resource_id` per velocizzare le query più frequenti.

## Security model

- **Accesso ai log**: integra il router con LinkBay-Roles e limita lettura/export a ruoli audit/compliance; applica separation of duties tra chi scrive eventi e chi li legge.
- **Cifratura**: la libreria non cifra i dati; fornisci provider `AuditLogStorage` che applicano encryption-at-rest e TLS end-to-end (es. KMS + column-level encryption).
- **Data minimization**: implementa `RedactionStrategy` che maschera PII (IP, email, nomi) prima di persistere; abilita il logging completo solo in ambienti investigativi.
- **Audit dei delete**: registra gli esiti di `delete_user_data` e `delete_event` in un datastore separato o invia notifiche verso LinkBay-Notifications.

## FAQ performance e sicurezza

**Come gestisco export di grandi dimensioni senza impattare il DB?**  
Usa `ExportService.stream_export` con storage che supporti cursor/scroll; esporta direttamente su storage oggetto evitando round-trip in memoria.

**Come verifico che l'anonimizzazione sia irreversibile?**  
Implementa un `RedactionStrategy` deterministicamente non invertibile (hash + salt, tokenizzazione irreversibile) e conserva il salt in un keystore separato o distruggilo dopo l'operazione.

**Quali ruoli dovrebbero poter leggere i log?**  
Consigliato un ruolo `compliance_auditor` read-only, un ruolo `security_officer` con export, e divieto totale per operatori di primo livello.

## Troubleshooting

- **ImportError FastAPI**: installa gli extra `pip install linkbay-audit[fastapi]`.
- **Retention non applicata**: verifica che il job periodico invochi `delete_events_before` e che il provider implementi la query.
- **Eventi con PII non mascherata**: registra un `RedactionStrategy` predefinito nello storage o nel servizio prima di chiamare `record_event`.

## Event types

40+ pre-defined event types:
- **User**: `USER_CREATED`, `USER_LOGIN`, `USER_ROLE_CHANGED`
- **Product**: `PRODUCT_CREATED`, `PRODUCT_UPDATED`, `PRODUCT_PUBLISHED`
- **Order**: `ORDER_CREATED`, `ORDER_FULFILLED`, `ORDER_REFUNDED`
- **Payment**: `PAYMENT_PROCESSED`, `PAYMENT_FAILED`
- **GDPR**: `GDPR_EXPORT_REQUESTED`, `GDPR_DATA_ANONYMIZED`
- **System**: `SYSTEM_ERROR`, `SYSTEM_WARNING`

## Supporto e licenza

- **Supporto**: quagliara.alessio@gmail.com
- **Licenza**: Proprietary © 2025 Alessio Quagliara
