"""Test suite for shadowlib."""
