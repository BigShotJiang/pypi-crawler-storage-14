from strictdoc.core.environment import SDocRuntimeEnvironment

__version__ = "0.15.1"


environment = SDocRuntimeEnvironment(__file__)
