"""
@relation(SDOC-SRS-126, scope=file)
"""


class SDocServerEnvVariable:
    PATH_TO_CONFIG = "PATH_TO_CONFIG"
