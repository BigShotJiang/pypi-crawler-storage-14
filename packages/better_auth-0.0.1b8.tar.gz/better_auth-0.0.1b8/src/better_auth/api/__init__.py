# flake8: noqa

# import apis into api package
from better_auth.api.admin_api import AdminApi
from better_auth.api.default_api import DefaultApi
from better_auth.api.one_tap_api import OneTapApi
from better_auth.api.passkey_api import PasskeyApi
from better_auth.api.two_factor_api import TwoFactorApi

