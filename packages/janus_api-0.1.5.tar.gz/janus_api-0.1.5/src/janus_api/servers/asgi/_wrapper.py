import logging
from typing import Optional, Dict

from janus_api._janus import Janus, JanusSessionManager

# Configure module-level logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# -----------------------------
# ASGI lifespan wrapper
# -----------------------------
class JanusASGILifespanWrapper:
    """
    (example usage in Django)
    # _wrapper.py
    import os
    from django.core.asgi import get_asgi_application
    from django.conf import settings
    from core.asgi import JanusASGILifespanWrapper

    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'conf.settings')
    app = get_asgi_application()
    # pass settings.JANUS (dict) if you want to override defaults
    application = JanusASGILifespanWrapper(app, settings=getattr(settings, 'JANUS', None))
    """

    def __init__(self, app, settings: Optional[Dict] = None):
        self.app = app
        self.settings = {**(settings or {})}
        self.manager = JanusSessionManager(self.settings)
        # Expose manager globally for middleware
        Janus.set_manager(self.manager)

    async def __call__(self, scope, receive, send):
        if scope["type"] == "lifespan":
            await self._handle_lifespan(receive, send)
            return
        # For every non-lifespan request, just forward
        await self.app(scope, receive, send)

    async def _handle_lifespan(self, receive, send):
        while True:
            msg = await receive()
            typ = msg.get("type")
            if typ == "lifespan.startup":
                try:
                    # start manager
                    await self.manager.start()
                    await send({"type": "lifespan.startup.complete"})
                    logger.info("JanusASGILifespanWrapper startup complete")
                except Exception as exc:
                    logger.exception("Startup failed")
                    await send({"type": "lifespan.startup.failed", "message": str(exc)})
            elif typ == "lifespan.shutdown":
                try:
                    await self.manager.stop()
                    await send({"type": "lifespan.shutdown.complete"})
                    logger.info("JanusASGILifespanWrapper shutdown complete")
                except Exception:
                    await send({"type": "lifespan.shutdown.failed"})
                return
            else:
                # ignore other lifespan events
                pass


__all__ = ["JanusASGILifespanWrapper"]