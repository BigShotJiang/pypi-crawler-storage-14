from ._wrapper import JanusASGILifespanWrapper

def get_asgi_application(other_asgi_app, settings=None):
    return JanusASGILifespanWrapper(other_asgi_app, settings=settings)


__all__ = ('get_asgi_application',)