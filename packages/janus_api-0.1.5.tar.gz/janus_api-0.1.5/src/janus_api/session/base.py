"""SessionMeta and AbstractBaseSession with reactive helpers.

This copy is adapted to use create_socket_client above as the transport factory when the
session URL uses ws:// or wss://.
"""
import threading
from typing import AnyStr, Any, Union, Dict, List, Optional

import pyee.asyncio
from decouple import config

from janus_api.core.manager import PluginManager
from janus_api.models import JanusRequest
from janus_api.models.request import AttachPluginRequest, DetachPluginRequest
from janus_api.transport.websocket import WebsocketTransportClient
from janus_api.transport.websocket import create_socket_client, logger

JANUS_SESSION_URL = config("JANUS_SESSION_URL", default="ws://localhost:8188/janus")


async def create_transport(url: AnyStr) -> Any:
    # returns either WebsocketTransportClient (for ws/wss) or another transport (httpx) if needed
    if url.startswith("ws://") or url.startswith("wss://"):
        return await create_socket_client(url)
    # fallback: httpx AsyncClient could be returned here
    import httpx
    return httpx.AsyncClient(base_url=url)


# -------------------------
# SessionMeta
# -------------------------
class SessionMeta(type):
    _instance = None
    _lock = threading.Lock()

    @classmethod
    def __prepare__(metacls, name, bases, **kwargs):
        namespace = super(SessionMeta, metacls).__prepare__(name, bases, **kwargs)
        # placeholders - adapt to your settings
        namespace["__session_url__"] = globals().get("JANUS_SESSION_URL", None)
        # create_transport should be your factory that yields a transport instance (async)
        namespace["__transport__"] = globals().get("create_transport", None)
        namespace["__plugins__"] = globals().get("PluginManager",
                                                 lambda: None)()  # keep external plugin manager usage intact
        return namespace

    def __call__(cls, *args, **kwargs):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__call__(*args, **kwargs)
            return cls._instance


# -------------------------
# AbstractBaseSession
# -------------------------
class AbstractBaseSession(metaclass=SessionMeta):
    __slots__ = ("__session_id", "__events", "__transport", "_plugin_subscription_guard", "_plugins_by_handle",
                 "_plugins_by_name", "_rx_subscription",)

    def __init__(self, *, session_id=None):
        self.__session_id: Optional[Union[str, int]] = session_id
        self.__events = pyee.asyncio.AsyncIOEventEmitter() if pyee is not None else None
        self.__transport = None
        self._plugin_subscription_guard = False
        self._plugins_by_handle: Dict[Any, Any] = {}
        self._plugins_by_name: Dict[str, List[Any]] = {}
        self._rx_subscription = None

    @property
    def id(self) -> Union[str, int]:
        return self.__session_id  # type: ignore

    @id.setter
    def id(self, value):
        self.__session_id = value

    @property
    def plugins(self) -> PluginManager:
        return getattr(self.__class__, "__plugins__")

    @property
    def events(self):
        return self.__events

    @property
    def transport(self) -> WebsocketTransportClient:
        return self.__transport

    async def send(self, data: JanusRequest):
        return await self.transport.send(data)

    async def attach(self, plugin: AnyStr):
        if not self.__session_id:
            raise ValueError("Session ID is not set. Cannot attach plugin.")
        message = AttachPluginRequest(janus="attach", plugin=plugin, session_id=self.id)
        response = await self.send(message)
        assert response.janus == "success"
        plugin_id = response.data.id
        return plugin_id

    async def detach(self, handle_id):
        message = DetachPluginRequest(janus="detach", session_id=self.id, handle_id=handle_id)
        response = await self.send(message)
        assert response.janus == "success"
        try:
            del self.plugins[handle_id]
        except Exception as exc:
            logger.exception("Failed to detach plugin.", exc_info=exc)
        return handle_id

    async def create(self):
        raise NotImplementedError()

    async def destroy(self, **kwargs):
        self.plugins.clear()
        if self.transport:
            try:
                sub = getattr(self, "_rx_subscription", None)
                if sub is not None:
                    try:
                        if hasattr(sub, "dispose"):
                            sub.dispose()
                        elif hasattr(sub, "close"):
                            sub.close()
                        else:
                            try:
                                sub()
                            except Exception:
                                pass
                    except Exception:
                        logger.exception("Failed to dispose rx subscription")
                    finally:
                        self._rx_subscription = None
            except Exception:
                logger.exception("Failed while cleaning up rx subscription")
            # transport.stop will close reactive subject if present
            await self.transport.stop()

    async def _setup(self):
        """set up the connection to the websocket server
        called in the .create() method.
        """
        print(f"Transport Open={bool(self.transport and self.transport.open)}::taking next decision", )
        if self.transport and self.transport.open:
            logger.info(f"Transport Open={bool(self.transport and self.transport.open)}::exiting")
            return
        print(f"Has Session ID={bool(self.id is not None)}::taking next decision")
        if self.id:
            logger.info(f"Has Session ID={bool(self.id is not None)}::exiting")
            return
        cls = self.__class__
        session_url = getattr(cls, "__session_url__", None)
        if session_url is None:
            raise ValueError("session_url must be set in settings.py")
        transport_factory = getattr(cls, "__transport__", None)
        if transport_factory is None:
            raise RuntimeError("transport factory not configured")
        self.__transport = await transport_factory(session_url)
        try:
            rx_conn = self.transport.events
            if rx_conn is not None:
                def _rx_on_next(payload):
                    try:
                        self._route_event(payload)
                    except Exception as exc:
                        logger.exception("Error routing event from reactive stream", exc_info=exc)

                try:
                    self._rx_subscription = rx_conn.subscribe(_rx_on_next, lambda err: logger.error(f"RX event error: {err}", exc_info=err))
                except Exception as exc:
                    logger.exception("Error routing subscription", exc_info=exc)
        except Exception as e:
            logger.exception("Failed to wire transport.reactive to session routing", exc_info=e)

    def _route_event(self, evt):
        logger.info("Routing event %s", evt)
        try:
            plugin_name = getattr(evt, "plugin", None)
            sender = getattr(evt, "from", None)
            payload = getattr(evt, "payload", {})
            pm = self.plugins

            # PluginManager dispatch
            if sender and hasattr(pm, "dispatch"):
                try:
                    pm.dispatch(str(sender), payload)
                    return
                except Exception as e:
                    logger.exception("PluginManager.dispatch failed for %s", plugin_name, exc_info=e)
        except Exception as exc:
            logger.exception("Error routing plugin event", exc_info=exc)

    def __repr__(self):
        return f"{self.__class__.__name__}({self.id=})"

    def __str__(self):
        return str(self.__session_id)
