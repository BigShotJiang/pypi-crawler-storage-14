import typing
from typing import Coroutine

DEFAULT_UUID_LENGTH = 6

import asyncio
import logging
import uuid
from functools import partial
from typing import Optional

from janus_api.models import JanusResponse
from janus_api.plugins import Plugin

logger = logging.getLogger("janus.core.utils")

from asgiref.sync import async_to_sync
from typing import Dict, Any


async def dummy_fn(*args, **kwargs):
    raise AttributeError("Method not implemented in object")


async def _extract_participant_id_from_response(response: JanusResponse) -> Optional[str]:
    """Try common shapes: response.plugindata.data.id, response.data.id, dict forms."""
    plugindata = getattr(response, "plugindata", None)
    if plugindata is not None:
        data = getattr(plugindata, "data", None)
        if data is not None and hasattr(data, "id"):
            return data.id

    # dict-like
    try:
        pd = response.get("plugindata", {})
        d = pd.get("data", {})
        if "id" in d:
            return d["id"]
    except Exception:
        pass
    return None


async def _extract_plugin_id_from_response(response: JanusResponse) -> Optional[str]:
    data = getattr(response, "data", None)
    if data is not None and hasattr(data, "id"):
        return data.id

    try:
        d2 = response.get("data", {})
        if "id" in d2:
            return d2["id"]
    except Exception:
        pass
    return None


def _uuid_str() -> str:
    return str(uuid.uuid4())


# -------------------------
# Option 2: Persistent admin plugin manager
# -------------------------
class PersistentJanusPluginManager:
    """
    Process-global manager that keeps one transient "system" plugin attached and re-uses it.
    It reconnects on failures and serializes attach/detach to avoid races.
    """

    _instance: Optional["PersistentJanusPluginManager"] = None

    def __init__(self):
        # holds the attached plugin object (from janus_api.plugins.Plugin)
        self._plugin: Optional[Plugin] = None
        self._lock = asyncio.Lock()
        # time when plugin was attached (optional)
        self._attached_at: Optional[float] = None

    @classmethod
    def instance(cls) -> "PersistentJanusPluginManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance  # type: ignore

    async def _ensure_attached(self, room_hint: Optional[str] = None) -> Plugin:
        """
        Ensure we have a live attached plugin and return it.
        Attaches a new plugin if none or if the existing plugin failed.
        """
        async with self._lock:
            # quick check
            if self._plugin is not None:
                try:
                    # optionally check plugin health via a lightweight call (exists with short timeout)
                    try:
                        ok = await asyncio.wait_for(getattr(self._plugin, "exists", dummy_fn)(), timeout=2.0)
                        if ok is not False:  # ok could be True / dict / etc; treat not-raising as alive
                            return self._plugin
                    except asyncio.TimeoutError:
                        logger.warning("Persistent plugin exists() timed out; will reattach")
                    except AttributeError:
                        logger.warning("Persistent plugin has no attribute 'exist'; will reattach")
                    except Exception as exc:
                        logger.warning("Persistent plugin health check failed; reattaching", exc_info=exc)
                except Exception:
                    # proceed to reattach
                    pass

            # attach a new plugin
            try:
                from janus_api import Janus
                username = f"system-persistent{('-' + str(room_hint)) if room_hint else ''}"
                plugin = await Plugin.attach(
                    type="videoroom",
                    mode="publisher",
                    username=username,
                    room=room_hint or _uuid_str()[:5],
                    session=Janus.get_session()
                    # note: we do not pass on_rx_event for persistent manager
                )
                self._plugin = plugin  # type: ignore
                self._attached_at = asyncio.get_event_loop().time()
                logger.info("Persistent Janus plugin attached (id=%s)", getattr(plugin, "id", None))
                return plugin  # type: ignore
            except Exception as exc:
                logger.exception("Failed to attach persistent janus plugin: %s", exc)
                # ensure plugin cleared
                self._plugin = None
                self._attached_at = None
                raise

    async def exists(self, room_id: str) -> bool:
        """
        Use the persistent plugin to check existence; attach first if necessary.
        """
        plugin = await self._ensure_attached(room_hint=room_id)
        try:
            # small timeout for exists check
            return bool(await asyncio.wait_for(getattr(plugin, "exists", dummy_fn)(), timeout=3.0))
        except asyncio.TimeoutError:
            logger.warning("Persistent plugin.exists() timed out for room %s", room_id)
            return False
        except AttributeError:
            logger.warning("Persistent plugin has no attribute 'exists'")
            return False
        except Exception as exc:
            logger.exception("Persistent plugin.exists() failed for room %s: %s", room_id, exc)
            # clear plugin so next call reattaches
            await self._safe_detach()
            return False

    async def create(self, room_id: str, create_kwargs: Optional[Dict[str, Any]] = None) -> None:
        """
        Create a room using the persistent plugin (attach if needed).
        """
        plugin = await self._ensure_attached(room_hint=room_id)
        create_kwargs = create_kwargs or {}
        try:
            await asyncio.wait_for(getattr(plugin, "create", dummy_fn)(**create_kwargs), timeout=12.0)
            # verify quickly
            ok = await asyncio.wait_for(getattr(plugin, "exists", dummy_fn)(), timeout=3.0)
            if not ok:
                raise RuntimeError("create did not produce a visible room")
            # success
            return
        except Exception as exc:
            logger.exception("Persistent plugin.create failed for %s: %s", room_id, exc)
            # detach plugin to force reattach next time
            await self._safe_detach()
            raise

    async def _safe_detach(self) -> None:
        """
        Try to detach and clear plugin reference.
        """
        if self._plugin is None:
            return
        try:
            await self._plugin.detach()
        except Exception as exc:
            logger.exception("Failed to detach persistent plugin", exc_info=exc)
        finally:
            self._plugin = None
            self._attached_at = None

    async def close(self) -> None:
        """
        Close the manager and detach plugin; call on process shutdown if desired.
        """
        async with self._lock:
            await self._safe_detach()


def run_coroutine_task[T](coro: typing.Callable[[], Coroutine[typing.Any, typing.Any, T]]):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    asyncio.ensure_future(coro(), loop=loop)
    loop.run_forever()


def sync_call_coroutine[T](
        coro: typing.Callable[[], Coroutine[typing.Any, typing.Any, T]],
        *args,
        **kwargs
) -> T:
    return partial(async_to_sync, coro)(*args, **kwargs)


def generate_short_uuid(length: int = DEFAULT_UUID_LENGTH) -> str:
    return str(uuid.uuid4())[:length]
