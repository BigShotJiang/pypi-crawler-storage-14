# coding: utf-8
import cv2
import os
import time

class Camera:
    def __init__(self, indexes=[0, 1, 2, 3], target_width=640, target_height=480):
        self.cap = None
        self.indexes = indexes
        self.target_width = target_width
        self.target_height = target_height
        self.open_camera()
    
    def open_camera(self):
        """尝试打开摄像头"""
        for idx in self.indexes:
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                # 尝试设置分辨率
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.target_width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.target_height)
                
                # 获取实际设置的分辨率
                actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                
                print(f"摄像头 {idx} 已打开, 分辨率: {actual_width}x{actual_height}")
                self.cap = cap
                return True
        
        print("无法打开任何摄像头")
        return False
    
    def read_frame(self):
        """读取一帧并自动处理错误"""
        if not self.cap or not self.cap.isOpened():
            return False, None
            
        ret, frame = self.cap.read()
        if not ret:
            print("读取帧失败，尝试重新打开摄像头...")
            self.release()
            time.sleep(1)
            if self.open_camera():
                return self.read_frame()
            return False, None
        
        # 调整到目标分辨率
        if frame.shape[1] != self.target_width or frame.shape[0] != self.target_height:
            frame = cv2.resize(frame, (self.target_width, self.target_height))
            
        return True, frame
    
    def get_resolution(self):
        """获取当前分辨率"""
        if self.cap and self.cap.isOpened():
            return (
                int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
                int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            )
        return self.target_width, self.target_height
    
    def release(self):
        """释放摄像头资源"""
        if self.cap and self.cap.isOpened():
            self.cap.release()
            self.cap = None

