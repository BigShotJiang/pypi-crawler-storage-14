#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages
import os

# 读取README文件
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return "EZAI - 简单易用的AI机器人控制库"

# 读取requirements文件
def read_requirements():
    requirements_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    if os.path.exists(requirements_path):
        with open(requirements_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []

setup(
    name="ezai_go2",
    version="1.2.11",
    author="EZAI Team",
    author_email="contact@ezai.com",
    description="Easy AI Robot Control Library for Go2 and Computer Vision",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/ezai-team/ezai",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
            "twine>=4.0",
            "build>=0.7.0",
        ],
        "onnx": [
            "onnx>=1.12.0",
            "onnxruntime>=1.12.0",
        ],
        "rknn": [
            "rknn-toolkit2>=1.5.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "ezai=ezai.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords="robotics, ai, computer-vision, go2, unitree, machine-learning, education",
    project_urls={
        "Bug Reports": "https://github.com/ezai-team/ezai/issues",
        "Source": "https://github.com/ezai-team/ezai",
        "Documentation": "https://ezai.readthedocs.io/",
    },
)