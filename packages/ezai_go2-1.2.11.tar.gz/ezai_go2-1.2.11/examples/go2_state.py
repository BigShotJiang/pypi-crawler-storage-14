import ezai.go2 as go2

interface = "enx00e098611407"
go2_robot = go2.Go2(interface)
go2_robot.init()


while True:
    print("="*30)
    print("执行前当前状态码：",go2_robot.error_code)
    try:
        id = int(input("请输入编号："))
    except ValueError:
        print("请输入整数编号")
        continue
    
    if id == 1:
        go2_robot.StandUp()  # 站起来
    elif id == 2:
        go2_robot.StandDown()  # 坐下
    elif id == 3:
        go2_robot.Hello()  # 打招呼
    elif id == 4:
        go2_robot.Stretch()  # 伸懒腰
    elif id == 5:
        go2_robot.Content()  # 开心
    elif id == 6:
        go2_robot.Dance1()  # 跳舞1
    elif id == 7: 
        go2_robot.Dance2()  # 跳舞2


    print("执行后状态码：",go2_robot.error_code)