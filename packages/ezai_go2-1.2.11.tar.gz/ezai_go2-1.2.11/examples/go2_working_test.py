#!/usr/bin/env python3
"""
工作版本测试 - 使用最简单直接的方法
"""

import os
import sys
import time
import cv2
import numpy as np

os.environ["DISPLAY"] = ":0"

def working_video_test():
    """使用最简单直接的方法"""
    print("=== 工作版本测试 ===")
    
    # 1. 初始化EZAI获取接口
    sys.path.insert(0, '..')
    import ezai.go2 as go2
    
    robot = go2.Go2()
    robot.init()
    interface = robot.interface
    print(f"检测到接口: {interface}")
    
    # 2. 完全按照pipstream.py的方式创建视频流
    pipe_path = "/tmp/working_test_pipe"
    width, height = 1280, 720
    
    # 清理旧管道
    if os.path.exists(pipe_path):
        os.remove(pipe_path)
    
    # 创建管道
    os.mkfifo(pipe_path)
    print("命名管道已创建")
    
    # 启动GStreamer（使用动态接口）
    gst_cmd = (
        "exec gst-launch-1.0 udpsrc address=230.1.1.1 port=1720 multicast-iface=" + interface + " "
        "! application/x-rtp, media=video, encoding-name=H264 ! rtph264depay ! h264parse "
        "! avdec_h264 ! videoconvert ! video/x-raw,format=BGR,width=1280,height=720 "
        "! filesink location=" + pipe_path + " > /dev/null 2>&1 &"
    )
    
    print("启动GStreamer...")
    os.system(gst_cmd)
    time.sleep(3)
    
    try:
        print("开始读取视频...")
        frame_size = width * height * 3
        
        # 完全按照pipstream.py的方式读取
        with open(pipe_path, 'rb') as pipe:
            frame_count = 0
            success_count = 0
            
            while True:
                frame_data = pipe.read(frame_size)
                
                if len(frame_data) == frame_size:
                    frame = np.frombuffer(frame_data, dtype=np.uint8).reshape((height, width, 3))
                    cv2.imshow('Go2视频流 (工作版本)', frame)
                    frame_count += 1
                    success_count += 1
                    
                    if frame_count % 30 == 0:
                        print(f"✅ 成功显示 {success_count} 帧")
                    
                    # 确保窗口刷新
                    cv2.waitKey(1)
                else:
                    # 数据不完整时也要等待，避免CPU占用过高
                    cv2.waitKey(1)
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
    except Exception as e:
        print(f"错误: {e}")
    finally:
        os.system("pkill -f gst-launch")
        if os.path.exists(pipe_path):
            os.remove(pipe_path)
        cv2.destroyAllWindows()
        print("程序结束")

if __name__ == "__main__":
    working_video_test()