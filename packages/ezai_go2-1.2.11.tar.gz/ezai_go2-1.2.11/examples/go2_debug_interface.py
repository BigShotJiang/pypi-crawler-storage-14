#!/usr/bin/env python3
"""
调试网络接口问题
"""

import sys
import os

# 添加父目录到路径
sys.path.insert(0, '..')

try:
    import ezai.go2 as go2
    
    print("=== 调试网络接口 ===")
    
    # 创建Go2实例
    robot = go2.Go2()
    print(f"robot.interface = '{robot.interface}'")
    
    # 初始化
    robot.init()
    print(f"初始化后 robot.interface = '{robot.interface}'")
    
    # 检查是否与pipstream.py一致
    expected_interface = "enx00e0986113a6"
    if robot.interface == expected_interface:
        print(f"✅ 接口匹配: {robot.interface}")
    else:
        print(f"❌ 接口不匹配!")
        print(f"   期望: {expected_interface}")
        print(f"   实际: {robot.interface}")
        print("   这可能是问题所在!")
    
    # 测试手动设置接口
    print("\n=== 测试手动设置接口 ===")
    robot.interface = expected_interface
    print(f"手动设置后: '{robot.interface}'")
    
    # 尝试创建管道
    print("\n=== 测试管道创建 ===")
    pipe_path, size = robot.open_video_pipe()
    if pipe_path:
        print(f"✅ 管道创建成功: {pipe_path}")
        robot.close_video_pipe(pipe_path)
    else:
        print("❌ 管道创建失败")
        
except Exception as e:
    print(f"调试失败: {e}")
    import traceback
    traceback.print_exc()