#!/usr/bin/env python3
"""
最简单的测试 - 完全复制pipstream.py的成功逻辑
"""

import os
import sys
import time
import cv2
import numpy as np

os.environ["DISPLAY"] = ":0"

def simple_test():
    """最简单的测试"""
    print("=== 最简单测试 ===")
    
    # 1. 获取接口
    sys.path.insert(0, '..')
    import ezai.go2 as go2
    
    robot = go2.Go2()
    robot.init()
    interface = robot.interface
    print(f"检测到接口: {interface}")
    
    # 2. 完全复制pipstream.py的逻辑，只是使用动态接口
    pipe_path = "/tmp/simple_test_pipe"
    
    # 清理旧管道
    if os.path.exists(pipe_path):
        os.remove(pipe_path)
    
    # 创建管道
    os.mkfifo(pipe_path)
    print("命名管道已创建")
    
    # 启动GStreamer（使用动态接口，其他完全一样）
    gst_cmd = (
        "exec gst-launch-1.0 udpsrc address=230.1.1.1 port=1720 multicast-iface=" + interface + " "
        "! application/x-rtp, media=video, encoding-name=H264 ! rtph264depay ! h264parse "
        "! avdec_h264 ! videoconvert ! video/x-raw,format=BGR,width=1280,height=720 "
        "! filesink location=" + pipe_path + " > /dev/null 2>&1 &"
    )
    
    print("启动GStreamer...")
    os.system(gst_cmd)
    time.sleep(3)
    
    try:
        print("开始读取视频...")
        width, height = 1280, 720
        frame_size = width * height * 3
        
        # 完全按照pipstream.py的方式
        with open(pipe_path, 'rb') as pipe:
            frame_count = 0
            while True:
                # 读取一帧
                frame_data = pipe.read(frame_size)
                
                if len(frame_data) == frame_size:
                    # 转换为图像并显示
                    frame = np.frombuffer(frame_data, dtype=np.uint8).reshape((height, width, 3))
                    cv2.imshow('Go2视频流 (最简单测试)', frame)
                    frame_count += 1
                    
                    if frame_count % 30 == 0:
                        print(f"✅ 显示第 {frame_count} 帧")
                    
                    # 确保窗口刷新
                    cv2.waitKey(1)
                else:
                    # 数据不完整时也要等待
                    cv2.waitKey(1)
                
                # 检查退出
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
    except Exception as e:
        print(f"错误: {e}")
    finally:
        # 清理
        os.system("pkill -f gst-launch")
        if os.path.exists(pipe_path):
            os.remove(pipe_path)
        cv2.destroyAllWindows()
        print("程序结束")

if __name__ == "__main__":
    simple_test()