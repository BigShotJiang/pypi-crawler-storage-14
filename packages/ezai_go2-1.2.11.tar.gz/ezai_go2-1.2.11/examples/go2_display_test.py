#!/usr/bin/env python3
"""
专门测试显示问题的版本
"""

import os
import sys
import time
import cv2
import numpy as np

# 设置显示环境
os.environ["DISPLAY"] = ":0"

def test_pipstream_display():
    """测试pipstream.py的显示效果"""
    print("=== 测试pipstream.py显示效果 ===")
    
    pipe_path = "/tmp/pipstream_test_pipe"
    interface = "enx00e0986113a6"
    width, height = 1280, 720
    
    # 清理旧管道
    if os.path.exists(pipe_path):
        os.remove(pipe_path)
    
    # 创建管道
    os.mkfifo(pipe_path)
    print("命名管道已创建")
    
    # 启动GStreamer
    gst_cmd = (
        "exec gst-launch-1.0 udpsrc address=230.1.1.1 port=1720 multicast-iface=enx00e0986113a6 "
        "! application/x-rtp, media=video, encoding-name=H264 ! rtph264depay ! h264parse "
        "! avdec_h264 ! videoconvert ! video/x-raw,format=BGR,width=1280,height=720 "
        "! filesink location=" + pipe_path + " > /dev/null 2>&1 &"
    )
    
    print("启动GStreamer...")
    os.system(gst_cmd)
    time.sleep(3)
    
    try:
        print("开始读取视频...")
        frame_size = width * height * 3
        
        # 创建命名窗口并设置大小
        cv2.namedWindow('Pipstream Video', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('Pipstream Video', width, height)
        
        with open(pipe_path, 'rb') as pipe:
            frame_count = 0
            while True:
                frame_data = pipe.read(frame_size)
                
                if len(frame_data) == frame_size:
                    frame = np.frombuffer(frame_data, dtype=np.uint8).reshape((height, width, 3))
                    cv2.imshow('Pipstream Video', frame)
                    frame_count += 1
                    
                    if frame_count % 30 == 0:
                        print(f"pipstream显示第 {frame_count} 帧，尺寸: {frame.shape}")
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                    
    except Exception as e:
        print(f"错误: {e}")
    finally:
        os.system("pkill -f gst-launch")
        if os.path.exists(pipe_path):
            os.remove(pipe_path)
        cv2.destroyAllWindows()

def test_ezai_display():
    """测试EZAI的显示效果"""
    print("\n=== 测试EZAI显示效果 ===")
    
    try:
        sys.path.insert(0, '..')
        import ezai.go2 as go2
        
        robot = go2.Go2()
        robot.init()
        
        # 获取视频读取器
        read_frame, cleanup = robot.get_video_reader(method='pipe')
        
        if read_frame is None:
            print("❌ 无法创建视频读取器")
            return
        
        # 创建命名窗口并设置大小
        cv2.namedWindow('EZAI Video', cv2.WINDOW_NORMAL)
        cv2.resizeWindow('EZAI Video', 1280, 720)
        
        print("开始读取视频...")
        frame_count = 0
        success_count = 0
        
        while True:
            frame = read_frame()
            
            if frame is not None:
                cv2.imshow('EZAI Video', frame)
                frame_count += 1
                success_count += 1
                
                if frame_count % 30 == 0:
                    print(f"EZAI显示第 {success_count} 帧，尺寸: {frame.shape}")
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            else:
                frame_count += 1
                if frame_count % 30 == 0:
                    print(f"等待数据... ({success_count}/{frame_count})")
                time.sleep(0.01)
                
    except Exception as e:
        print(f"❌ EZAI测试失败: {e}")
    finally:
        if cleanup:
            cleanup()
        cv2.destroyAllWindows()

def test_direct_comparison():
    """直接对比两个版本"""
    print("\n=== 直接对比测试 ===")
    
    # 测试pipstream
    print("1. 先测试pipstream.py（5秒）...")
    test_pipstream_display()
    
    input("按Enter继续测试EZAI版本...")
    
    # 测试EZAI
    print("2. 测试EZAI版本...")
    test_ezai_display()

if __name__ == "__main__":
    print("Go2视频流显示对比测试")
    print("=" * 40)
    print("选择测试模式:")
    print("1. pipstream.py显示测试")
    print("2. EZAI显示测试") 
    print("3. 对比测试")
    
    try:
        choice = input("请选择 (1/2/3): ").strip()
        
        if choice == "1":
            test_pipstream_display()
        elif choice == "2":
            test_ezai_display()
        elif choice == "3":
            test_direct_comparison()
        else:
            print("默认运行对比测试...")
            test_direct_comparison()
            
    except KeyboardInterrupt:
        print("\n测试被用户中断")
    except Exception as e:
        print(f"测试异常: {e}")