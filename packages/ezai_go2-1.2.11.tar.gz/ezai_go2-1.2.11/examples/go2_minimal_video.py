#!/usr/bin/env python3
"""
Go2最简视频读取示例
只需要几行代码就能获取Go2视频流
"""

import cv2
import ezai.go2 as go2

# 最简单的使用方式
robot = go2.Go2()
robot.init()

# 自动获取视频读取器
read_frame, cleanup = robot.get_video_reader()

# 读取并显示视频
while True:
    frame = read_frame()  # 获取一帧图像
    if frame is not None:
        cv2.imshow('Go2', frame)  # 显示图像
        if cv2.waitKey(1) & 0xFF == ord('q'):  # 按q退出
            break

# 清理资源
cleanup()
cv2.destroyAllWindows()