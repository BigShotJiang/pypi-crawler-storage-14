SOME_GLOBAL_VARIABLE = "some_global_variable"
