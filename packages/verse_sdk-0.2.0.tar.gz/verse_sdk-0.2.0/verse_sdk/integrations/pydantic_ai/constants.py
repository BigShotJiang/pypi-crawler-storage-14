VENDOR_ANTHROPIC = "anthropic"
VENDOR_OPENAI = "openai"
VENDOR_UNKNOWN = "unknown"
