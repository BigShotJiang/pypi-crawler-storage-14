from typing import TypedDict


class ExporterConfig(TypedDict):
    scopes: list[str] | None
