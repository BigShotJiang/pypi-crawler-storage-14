from .attribute import AttributeProcessor
from .attribute_batch import AttributeBatchSpanProcessor

__all__ = ["AttributeBatchSpanProcessor", "AttributeProcessor"]
