import firebase_admin
from fastapi import HTTPException
from firebase_admin import auth, credentials

from mosaygent.command_runner import run_command
from mosaygent.logger import get_logger

logger = get_logger(__name__)


class FirebaseAuthService:
    """Manages Firebase Authentication user management."""

    async def check_auth_enabled(self) -> dict:
        """Check if Firebase Auth is enabled in the currently configured project."""
        logger.info("Checking if Firebase Auth is enabled")

        project_result = await run_command(
            ["gcloud", "config", "get-value", "project"],
            timeout=5,
            raise_on_error=False
        )

        if not project_result.success or not project_result.stdout.strip():
            logger.error("No GCloud project is currently configured")
            raise HTTPException(
                status_code=400,
                detail="No GCloud project configured. Set a project first using /set-project"
            )

        project_id = project_result.stdout.strip()
        logger.info(f"Checking Firebase Auth for project: {project_id}")

        result = await run_command(
            [
                "gcloud", "services", "list",
                "--enabled",
                "--project", project_id,
                "--filter=name:identitytoolkit.googleapis.com",
                "--format=value(name)"
            ],
            timeout=30,
            raise_on_error=False
        )

        if not result.success:
            logger.error(f"Failed to check Firebase Auth status: {result.stderr}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to check Firebase Auth status: {result.stderr}"
            )

        auth_enabled = "identitytoolkit.googleapis.com" in result.stdout

        if auth_enabled:
            logger.info(f"Firebase Auth is enabled in project {project_id}")
        else:
            logger.info(f"Firebase Auth is not enabled in project {project_id}")

        return {
            "project_id": project_id,
            "auth_enabled": auth_enabled,
        }

    async def get_users_count(self) -> dict:
        """Get the number of registered users in Firebase Auth using Application Default Credentials."""
        logger.info("Fetching Firebase Auth users count")

        try:
            app_name = "auth_count_default"

            try:
                app = firebase_admin.get_app(name=app_name)
                logger.debug("Using existing Firebase Admin app")
            except ValueError:
                logger.info("Initializing Firebase Admin SDK with Application Default Credentials")
                cred = credentials.ApplicationDefault()
                app = firebase_admin.initialize_app(cred, name=app_name)
                logger.info("Successfully initialized Firebase Admin SDK")

            project_id = app.project_id
            logger.info(f"Counting Firebase Auth users for project: {project_id}")

            logger.debug("Listing Firebase Auth users")
            user_count = 0
            page = auth.list_users(app=app)

            while page:
                user_count += len(page.users)
                logger.debug(f"Processed batch, current count: {user_count}")
                page = page.get_next_page()

            logger.info(f"Found {user_count} registered users in project {project_id}")

            return {
                "project_id": project_id,
                "user_count": user_count,
            }

        except auth.UnexpectedResponseError as e:
            logger.error(f"Firebase Auth API error: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"Firebase Auth API error: {str(e)}"
            )
        except Exception as e:
            logger.exception(f"Failed to count Firebase Auth users: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"Failed to count Firebase Auth users: {str(e)}"
            )

