"""
Tradelink Authentication Client

Enterprise authentication client for microservices with Kong/Keycloak integration.
"""

from .config import AuthMode, AuthSettings, get_settings, reset_settings
from .fastapi_utils import (
    get_current_auth,
    get_current_service,
    get_current_user,
    get_optional_auth,
    get_optional_user,
    is_bypass_mode,
    is_using_keycloak,
    is_using_kong,
    require_admin,
    require_customer,
    require_moderator,
    require_roles,
    require_scopes,
    require_service_roles,
    require_supplier,
    require_supplier_or_admin,
    require_user_admin,
    require_user_customer,
    require_user_moderator,
    require_user_roles,
    require_user_supplier,
    verify_hmac_signature,
)
from .middleware import AuthMiddleware
from .s2s_auth import (
    CircuitBreaker,
    CircuitBreakerOpenError,
    CircuitState,
    ServiceAuthClient,
    ServiceToken,
    get_service_auth_client,
)
from .schemas import AuthContext, BaseAuthContext, ServiceContext, UserContext
from .user_auth import HMACVerifier, UserValidator, get_user_validator

__version__ = "0.2.3"

__all__ = [
    # Configuration
    "AuthSettings",
    "AuthMode",
    "get_settings",
    "reset_settings",
    # Schemas & Type Aliases
    "UserContext",
    "ServiceContext",
    "AuthContext",
    "BaseAuthContext",
    # User Authentication
    "UserValidator",
    "HMACVerifier",
    "get_user_validator",
    # Service-to-Service
    "ServiceAuthClient",
    "CircuitBreaker",
    "CircuitBreakerOpenError",
    "CircuitState",
    "ServiceToken",
    "get_service_auth_client",
    # Middleware
    "AuthMiddleware",
    # FastAPI Dependencies
    "get_current_auth",
    "get_current_user",
    "get_current_service",
    "get_optional_auth",
    "get_optional_user",
    "require_roles",
    "require_user_roles",
    "require_service_roles",
    "require_scopes",
    "require_admin",
    "require_supplier",
    "require_customer",
    "require_moderator",
    "require_supplier_or_admin",
    "verify_hmac_signature",
    "require_user_admin",
    "require_user_customer",
    "require_user_supplier",
    "require_user_moderator",
    # Mode Utilities
    "is_using_kong",
    "is_using_keycloak",
    "is_bypass_mode",
]
