# Proto Pretty

A protoc plugin for generating idiomatic Python interfaces for protocol buffers.

## Installation

Install in development mode:

```bash
git clone <repo>
cd proto_pretty
uv sync
```

## Usage

Use with protoc by specifying the `--python_pretty_out` option:

```bash
protoc --python_out=. --python_pretty_out=. your_file.proto
```

This generates:
- `your_file_pb2.py` (standard protoc output)
- `your_file_pretty.py` (idiomatic Python interface)

## Development

Run all checks (tests and static analysis)

```bash
mise check
```

To save generated files during tests for inspection:

```bash
mise test --save -s
```
