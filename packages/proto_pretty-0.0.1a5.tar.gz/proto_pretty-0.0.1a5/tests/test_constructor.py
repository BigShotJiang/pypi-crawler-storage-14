from .helpers import compile_for_test


def test_constructor_allows_building_proto_wrapper():
    proto = """
        syntax = "proto3";

        message Product {
          string name = 1;
          int32 price = 2;
          bool available = 3;
        }
    """

    with compile_for_test({"product.proto": proto}):
        import product_pretty  # type: ignore[import-not-found]

        # Test constructor with keyword arguments
        product = product_pretty.Product(name="Laptop", price=999, available=True)

        assert product.name == "Laptop"
        assert product.price == 999
        assert product.available


def test_empty_builds_a_message_with_all_fields_set_to_default_values():
    proto = """
        syntax = "proto3";

        message Product {
          string name = 1;
          int32 price = 2;
          bool available = 3;
        }
    """

    with compile_for_test({"product.proto": proto}):
        import product_pretty  # type: ignore[import-not-found]

        # Test constructor with keyword arguments
        product = product_pretty.Product.empty()

        assert product.name == ""
        assert product.price == 0
        assert not product.available

        product.name = "name"
        assert product.name == "name"
