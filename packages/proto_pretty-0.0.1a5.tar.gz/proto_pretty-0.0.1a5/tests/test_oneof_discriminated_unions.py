from .helpers import compile_for_test


def test_oneof_generates_discriminated_union_classes():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Check that the discriminated union classes exist
        assert hasattr(test_pretty.Payment, "PaymentMethod")
        payment_method_class = test_pretty.Payment.PaymentMethod

        # Check that all variant classes exist
        assert hasattr(payment_method_class, "CreditCard")
        assert hasattr(payment_method_class, "BankAccount")
        assert hasattr(payment_method_class, "CashAmount")
        assert hasattr(payment_method_class, "NOT_SET")


def test_oneof_discriminated_union_returns_not_set_when_no_field_active():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # When no oneof field is set, should return NOT_SET
        result = payment.payment_method()
        assert result is test_pretty.Payment.PaymentMethod.NOT_SET


def test_oneof_discriminated_union_returns_correct_variant_when_field_set():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # Set credit_card
        payment.credit_card = "1234-5678-9012-3456"
        result = payment.payment_method()
        assert isinstance(result, test_pretty.Payment.PaymentMethod.CreditCard)
        assert result.value == "1234-5678-9012-3456"
        assert result == test_pretty.Payment.PaymentMethod.CreditCard(
            "1234-5678-9012-3456"
        )

        # Set bank_account - should change the variant
        payment.bank_account = "123-456-789"
        result = payment.payment_method()
        assert isinstance(result, test_pretty.Payment.PaymentMethod.BankAccount)
        assert result.value == "123-456-789"

        # Set cash_amount - should change the variant
        payment.cash_amount = 100
        result = payment.payment_method()
        assert isinstance(result, test_pretty.Payment.PaymentMethod.CashAmount)
        assert result.value == 100


def test_oneof_discriminated_union_works_with_enum_fields():
    proto = """
        syntax = "proto3";

        enum Priority {
            LOW = 0;
            MEDIUM = 1;
            HIGH = 2;
        }

        message Task {
            oneof urgency {
                Priority priority = 1;
                int32 deadline_days = 2;
            }
        }
    """

    with compile_for_test({"enum_test.proto": proto}):
        import enum_test_pretty  # type: ignore[import-not-found]

        task = enum_test_pretty.Task()

        # Set priority enum
        task.priority = enum_test_pretty.Priority.HIGH
        result = task.urgency()
        assert isinstance(result, enum_test_pretty.Task.Urgency.Priority)
        assert result.value == enum_test_pretty.Priority.HIGH

        # Set deadline_days
        task.deadline_days = 7
        result = task.urgency()
        assert isinstance(result, enum_test_pretty.Task.Urgency.DeadlineDays)
        assert result.value == 7


def test_oneof_discriminated_union_works_with_message_fields():
    proto = """
        syntax = "proto3";

        message Address {
            string street = 1;
            string city = 2;
        }

        message Contact {
            oneof contact_info {
                string email = 1;
                string phone = 2;
                Address address = 3;
            }
        }
    """

    with compile_for_test({"message_test.proto": proto}):
        import message_test_pretty  # type: ignore[import-not-found]

        contact = message_test_pretty.Contact()

        # Set email
        contact.email = "test@example.com"
        result = contact.contact_info()
        assert isinstance(result, message_test_pretty.Contact.ContactInfo.Email)
        assert result.value == "test@example.com"

        # Set address message
        address = message_test_pretty.Address(street="123 Main St", city="Anytown")
        contact.address = address
        result = contact.contact_info()
        assert isinstance(result, message_test_pretty.Contact.ContactInfo.Address)
        assert result.value.street == "123 Main St"
        assert result.value.city == "Anytown"


def test_oneof_discriminated_union_variants_have_readable_repr():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                int32 cash_amount = 2;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # Test NOT_SET repr
        result = payment.payment_method()
        assert repr(result) == "PaymentMethod.NOT_SET"

        # Test CreditCard repr
        payment.credit_card = "1234"
        result = payment.payment_method()
        assert repr(result) == "PaymentMethod.CreditCard('1234')"

        # Test CashAmount repr
        payment.cash_amount = 100
        result = payment.payment_method()
        assert repr(result) == "PaymentMethod.CashAmount(100)"


def test_multiple_oneof_groups_generate_separate_discriminated_unions():
    proto = """
        syntax = "proto3";

        message MultiOneof {
            oneof group1 {
                string field_a = 1;
                int32 field_b = 2;
            }
            oneof group2 {
                bool field_c = 3;
                string field_d = 4;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        obj = test_pretty.MultiOneof()

        # Both groups should initially return NOT_SET
        assert obj.group1() is test_pretty.MultiOneof.Group1.NOT_SET
        assert obj.group2() is test_pretty.MultiOneof.Group2.NOT_SET

        # Set fields in different groups - they should not interfere
        obj.field_a = "test"
        obj.field_c = True

        result1 = obj.group1()
        result2 = obj.group2()

        assert isinstance(result1, test_pretty.MultiOneof.Group1.FieldA)
        assert result1.value == "test"

        assert isinstance(result2, test_pretty.MultiOneof.Group2.FieldC)
        assert result2.value is True

        # Set another field in group1 - should change group1 but not group2
        obj.field_b = 42

        result1 = obj.group1()
        result2 = obj.group2()

        assert isinstance(result1, test_pretty.MultiOneof.Group1.FieldB)
        assert result1.value == 42

        assert isinstance(result2, test_pretty.MultiOneof.Group2.FieldC)
        assert result2.value is True
