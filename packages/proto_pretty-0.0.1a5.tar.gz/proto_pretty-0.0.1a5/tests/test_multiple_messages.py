from .helpers import compile_for_test


def test_generates_wrappers_for_multiple_proto_messages():
    proto = """
        syntax = "proto3";

        package example;

        message Person {
          string name = 1;
          int32 age = 2;
        }

        message Company {
          string name = 1;
          int32 employee_count = 2;
        }
    """

    with compile_for_test({"company.proto": proto}):
        import company_pretty  # type: ignore[import-not-found]

        person = company_pretty.Person(name="John", age=30)
        assert person.name == "John"
        person.name = "Mark"
        assert person.name == "Mark"

        company = company_pretty.Company(name="ACME", employee_count=100)
        assert company.employee_count == 100
        company.employee_count = 200
        assert company.employee_count == 200
