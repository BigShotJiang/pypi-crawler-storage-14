from .helpers import compile_for_test


def test_optional_fields_can_be_none_or_set_to_values():
    proto = """
        syntax = "proto3";

        enum Status {
          STATUS_UNSPECIFIED = 0;
          STATUS_ACTIVE = 1;
          STATUS_INACTIVE = 2;
        }

        message OptionalTest {
          string name = 1;
          optional string email = 2;
          optional int32 age = 3;
          optional Status status = 4;
        }
    """

    with compile_for_test({"optional.proto": proto}):
        import optional_pretty  # type: ignore[import-not-found]

        # Create with required field only
        obj = optional_pretty.OptionalTest(name="test")

        # Optional fields should be None initially
        assert obj.name == "test"
        assert obj.email is None
        assert obj.age is None
        assert obj.status is None

        # Set optional fields
        obj.email = "test@example.com"
        obj.age = 25
        obj.status = optional_pretty.Status.ACTIVE
        assert obj.email == "test@example.com"
        assert obj.age == 25
        assert obj.status == optional_pretty.Status.ACTIVE

        # Clear optional fields
        obj.email = None
        obj.age = None
        obj.status = None
        assert obj.email is None
        assert obj.age is None
        assert obj.status is None
