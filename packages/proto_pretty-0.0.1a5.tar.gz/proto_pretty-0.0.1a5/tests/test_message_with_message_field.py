from .helpers import compile_for_test


def test_fields_with_message_types_are_handled_by_other_wrappers():
    proto = """
        syntax = "proto3";

        message Inner {
          int32 value = 1;
        }

        message Outer {
          Inner inner = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        outer = test_pretty.Outer()

        # Accessing message field should return wrapper, not protobuf
        inner_wrapper = outer.inner
        assert type(inner_wrapper).__name__ == "Inner"
        assert hasattr(inner_wrapper, "_pb")

        # Should be able to set value on the wrapper
        inner_wrapper.value = 42
        assert outer.inner.value == 42
