from tests.helpers import compile_for_test


def test_has_field_returns_false_for_unset_optional_fields():
    proto = """
        syntax = "proto3";

        message User {
            optional string name = 1;
            optional int32 age = 2;
        }
    """

    with compile_for_test({"user.proto": proto}):
        from user_pretty import User  # type: ignore[import-not-found]

        # Test empty message
        user = User()
        assert user.has_field("name") is False
        assert user.has_field("age") is False

        # Test after setting fields
        user.name = "Alice"
        assert user.has_field("name") is True
        assert user.has_field("age") is False


def test_has_field_tracks_message_field_presence_even_when_field_is_not_optional():
    proto = """
        syntax = "proto3";

        message Address {
            string street = 1;
            string city = 2;
        }

        message Person {
            string name = 1;
            Address address = 2;
            optional Address secondary_address = 3;
        }
    """

    with compile_for_test({"person.proto": proto}):
        from person_pretty import Address, Person  # type: ignore[import-not-found]

        person = Person(name="Bob")

        # Message field should be False initially
        assert person.has_field("address") is False
        assert person.has_field("secondary_address") is False

        # Set message field
        person.address = Address(street="123 Main St", city="Springfield")
        person.secondary_address = Address(
            street="234 Secondary St", city="Springfield"
        )
        assert person.has_field("address") is True
        assert person.has_field("secondary_address") is True


def test_has_field_tracks_oneof_field_variants():
    proto = """
        syntax = "proto3";

        message Contact {
            string name = 1;
            oneof contact_method {
                string email = 2;
                string phone = 3;
            }
        }
    """

    with compile_for_test({"contact.proto": proto}):
        from contact_pretty import Contact  # type: ignore[import-not-found]

        contact = Contact(name="Charlie")

        # Oneof fields (and their group) should be False initially
        assert contact.has_field("contact_method") is False
        assert contact.has_field("email") is False
        assert contact.has_field("phone") is False

        # Set email
        contact.email = "charlie@example.com"
        assert contact.has_field("contact_method") is True
        assert contact.has_field("email") is True
        assert contact.has_field("phone") is False

        # Switch to phone
        contact.phone = "555-1234"
        assert contact.has_field("contact_method") is True
        assert contact.has_field("email") is False
        assert contact.has_field("phone") is True
