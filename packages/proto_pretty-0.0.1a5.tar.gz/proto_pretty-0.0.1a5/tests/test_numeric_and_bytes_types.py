"""Tests for all numeric protobuf types and bytes type."""

from .helpers import compile_for_test


def test_all_numeric_types_compile_and_work():
    """All numeric field types should generate correct Python types."""
    proto = """
        syntax = "proto3";

        message NumericTypesMessage {
          double double_field = 1;
          float float_field = 2;
          int64 int64_field = 3;
          uint64 uint64_field = 4;
          int32 int32_field = 5;
          fixed64 fixed64_field = 6;
          fixed32 fixed32_field = 7;
          bool bool_field = 8;
          string string_field = 9;
          bytes bytes_field = 12;
          uint32 uint32_field = 13;
          sfixed32 sfixed32_field = 15;
          sfixed64 sfixed64_field = 16;
          sint32 sint32_field = 17;
          sint64 sint64_field = 18;
        }
    """

    with compile_for_test({"numeric.proto": proto}):
        import numeric_pretty  # type: ignore[import-not-found]

        # Test creation with all field types
        msg = numeric_pretty.NumericTypesMessage(
            double_field=3.14159,
            float_field=2.5,
            int64_field=-9223372036854775808,  # Min int64
            uint64_field=18446744073709551615,  # Max uint64
            int32_field=-2147483648,  # Min int32
            fixed64_field=12345678901234567890,
            fixed32_field=4294967295,  # Max uint32
            bool_field=True,
            string_field="test string",
            bytes_field=b"test bytes",
            uint32_field=4294967295,  # Max uint32
            sfixed32_field=-2147483648,  # Min int32
            sfixed64_field=-9223372036854775808,  # Min int64
            sint32_field=-123456,
            sint64_field=-1234567890123456789,
        )

        # Verify all values are correctly set
        assert msg.double_field == 3.14159
        assert msg.float_field == 2.5
        assert msg.int64_field == -9223372036854775808
        assert msg.uint64_field == 18446744073709551615
        assert msg.int32_field == -2147483648
        assert msg.fixed64_field == 12345678901234567890
        assert msg.fixed32_field == 4294967295
        assert msg.bool_field is True
        assert msg.string_field == "test string"
        assert msg.bytes_field == b"test bytes"
        assert msg.uint32_field == 4294967295
        assert msg.sfixed32_field == -2147483648
        assert msg.sfixed64_field == -9223372036854775808
        assert msg.sint32_field == -123456
        assert msg.sint64_field == -1234567890123456789


def test_bytes_field_handles_binary_data():
    """Bytes field should handle various binary data correctly."""
    proto = """
        syntax = "proto3";

        message BytesMessage {
          bytes data = 1;
          optional bytes optional_data = 2;
        }
    """

    with compile_for_test({"bytes.proto": proto}):
        import bytes_pretty  # type: ignore[import-not-found]

        # Test with various binary data
        binary_data = bytes([0, 1, 2, 255, 128, 64, 32])
        msg = bytes_pretty.BytesMessage(data=binary_data)

        assert msg.data == binary_data
        assert isinstance(msg.data, bytes)

        # Test with None for optional field
        msg2 = bytes_pretty.BytesMessage(data=b"required", optional_data=None)
        assert msg2.data == b"required"
        assert msg2.optional_data is None


def test_repeated_numeric_types():
    """Repeated numeric fields should work correctly."""
    proto = """
        syntax = "proto3";

        message RepeatedNumericMessage {
          repeated uint64 uint64_list = 1;
          repeated sint32 sint32_list = 2;
          repeated bytes bytes_list = 3;
          repeated fixed32 fixed32_list = 4;
        }
    """

    with compile_for_test({"repeated_numeric.proto": proto}):
        import repeated_numeric_pretty  # type: ignore[import-not-found]

        msg = repeated_numeric_pretty.RepeatedNumericMessage(
            uint64_list=[1, 2, 18446744073709551615],
            sint32_list=[-1, 0, 1, -2147483648, 2147483647],
            bytes_list=[b"first", b"second", b"\x00\x01\x02"],
            fixed32_list=[0, 1, 4294967295],
        )

        assert msg.uint64_list == [1, 2, 18446744073709551615]
        assert msg.sint32_list == [-1, 0, 1, -2147483648, 2147483647]
        assert msg.bytes_list == [b"first", b"second", b"\x00\x01\x02"]
        assert msg.fixed32_list == [0, 1, 4294967295]


def test_optional_numeric_types():
    """Optional numeric fields should support None values."""
    proto = """
        syntax = "proto3";

        message OptionalNumericMessage {
          optional uint64 optional_uint64 = 1;
          optional sint64 optional_sint64 = 2;
          optional bytes optional_bytes = 3;
          optional sfixed32 optional_sfixed32 = 4;
        }
    """

    with compile_for_test({"optional_numeric.proto": proto}):
        import optional_numeric_pretty  # type: ignore[import-not-found]

        # Test with None values
        msg = optional_numeric_pretty.OptionalNumericMessage(
            optional_uint64=None,
            optional_sint64=None,
            optional_bytes=None,
            optional_sfixed32=None,
        )

        assert msg.optional_uint64 is None
        assert msg.optional_sint64 is None
        assert msg.optional_bytes is None
        assert msg.optional_sfixed32 is None

        # Test with actual values
        msg2 = optional_numeric_pretty.OptionalNumericMessage(
            optional_uint64=123456789,
            optional_sint64=-123456789,
            optional_bytes=b"test",
            optional_sfixed32=-42,
        )

        assert msg2.optional_uint64 == 123456789
        assert msg2.optional_sint64 == -123456789
        assert msg2.optional_bytes == b"test"
        assert msg2.optional_sfixed32 == -42


def test_numeric_types_serialization():
    """All numeric types should serialize and deserialize correctly."""
    proto = """
        syntax = "proto3";

        message SerializationTest {
          uint64 large_uint = 1;
          sint64 negative_sint = 2;
          bytes binary_data = 3;
          fixed64 fixed_value = 4;
        }
    """

    with compile_for_test({"serialization.proto": proto}):
        import serialization_pretty  # type: ignore[import-not-found]

        original = serialization_pretty.SerializationTest(
            large_uint=18446744073709551615,  # Max uint64
            negative_sint=-1234567890123456789,
            binary_data=b"\x00\x01\x02\x03\xff\xfe",
            fixed_value=9876543210987654321,
        )

        # Test bytes serialization
        data = bytes(original)
        restored = serialization_pretty.SerializationTest.parse(data)

        assert restored.large_uint == 18446744073709551615
        assert restored.negative_sint == -1234567890123456789
        assert restored.binary_data == b"\x00\x01\x02\x03\xff\xfe"
        assert restored.fixed_value == 9876543210987654321
