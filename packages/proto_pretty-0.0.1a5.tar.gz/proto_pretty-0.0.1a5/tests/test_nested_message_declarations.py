from .helpers import compile_for_test


def test_generates_nested_message_classes():
    proto = """
        syntax = "proto3";

        message Container {
          message Section {
            message Item {
              string value = 1;
            }
            Item item = 1;
          }
          Section section = 1;
        }
    """

    with compile_for_test({"nested.proto": proto}):
        import nested_pretty  # type: ignore[import-not-found]

        assert hasattr(nested_pretty, "Container")
        assert hasattr(nested_pretty.Container, "Section")
        assert hasattr(nested_pretty.Container.Section, "Item")


def test_can_instantiate_deeply_nested_messages():
    proto = """
        syntax = "proto3";

        message Level1 {
          message Level2 {
            message Level3 {
              string data = 1;
            }
            Level3 level3 = 1;
          }
          Level2 level2 = 1;
        }
    """

    with compile_for_test({"deep.proto": proto}):
        import deep_pretty  # type: ignore[import-not-found]

        inner = deep_pretty.Level1.Level2.Level3(data="test")
        assert inner.data == "test"

        middle = deep_pretty.Level1.Level2(level3=inner)
        assert middle.level3.data == "test"

        outer = deep_pretty.Level1(level2=middle)
        assert outer.level2.level3.data == "test"


def test_nested_message_with_enum():
    proto = """
        syntax = "proto3";

        message Wrapper {
          enum Status {
            STATUS_UNSPECIFIED = 0;
            STATUS_ACTIVE = 1;
            STATUS_INACTIVE = 2;
          }

          message Element {
            string name = 1;
            Status status = 2;
          }

          Element element = 1;
        }
    """

    with compile_for_test({"wrapper.proto": proto}):
        import wrapper_pretty  # type: ignore[import-not-found]

        assert hasattr(wrapper_pretty, "Wrapper")
        assert hasattr(wrapper_pretty.Wrapper, "Status")
        assert hasattr(wrapper_pretty.Wrapper, "Element")

        element = wrapper_pretty.Wrapper.Element(
            name="test", status=wrapper_pretty.Wrapper.Status.ACTIVE
        )
        assert element.name == "test"
        assert element.status == wrapper_pretty.Wrapper.Status.ACTIVE


def test_mixed_nested_and_top_level_messages():
    proto = """
        syntax = "proto3";

        message TopLevel {
          string value = 1;
        }

        message Parent {
          message Child {
            string name = 1;
          }
          Child child = 1;
          TopLevel top = 2;
        }
    """

    with compile_for_test({"mixed.proto": proto}):
        import mixed_pretty  # type: ignore[import-not-found]

        assert hasattr(mixed_pretty, "TopLevel")
        assert hasattr(mixed_pretty, "Parent")
        assert hasattr(mixed_pretty.Parent, "Child")

        top = mixed_pretty.TopLevel(value="top")
        child = mixed_pretty.Parent.Child(name="child")
        parent = mixed_pretty.Parent(child=child, top=top)

        assert parent.child.name == "child"
        assert parent.top.value == "top"
