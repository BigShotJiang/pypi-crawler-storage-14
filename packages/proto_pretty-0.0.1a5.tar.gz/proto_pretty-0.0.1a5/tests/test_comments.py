from .helpers import compile_for_test


def test_message_docstring_contains_proto_comment():
    proto = """
        syntax = "proto3";

        // This is a simple message with a field.
        message SimpleMessage {
          int32 value = 1;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        # Check that the docstring includes the proto comment
        assert (
            "This is a simple message with a field."
            in simple_pretty.SimpleMessage.__doc__
        )


def test_field_property_docstring_contains_proto_comment():
    proto = """
        syntax = "proto3";

        message SimpleMessage {
          // This is the value field.
          int32 value = 1;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        wrapper = simple_pretty.SimpleMessage()

        # Check that the getter property has a docstring with the comment
        value_property = type(wrapper).value
        assert "This is the value field." in value_property.fget.__doc__


def test_enum_docstring_contains_proto_comment():
    proto = """
        syntax = "proto3";

        // This is a status enum.
        enum Status {
          // Unknown status.
          STATUS_UNKNOWN = 0;
          // Success status.
          STATUS_SUCCESS = 1;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        # Check that the enum docstring includes the proto comment
        assert "This is a status enum." in simple_pretty.Status.__doc__


def test_enum_docstring_contains_value_comments():
    proto = """
        syntax = "proto3";

        enum Status {
          // Unknown status value
          STATUS_UNKNOWN = 0;
          // Success status value
          STATUS_SUCCESS = 1;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        # For enum values, comments should be in the docstring as inline documentation
        docstring = simple_pretty.Status.__doc__
        assert "Unknown status value" in docstring
        assert "Success status value" in docstring


def test_nested_message_docstring_contains_proto_comment():
    proto = """
        syntax = "proto3";

        message OuterMessage {
          // Nested inner message.
          message InnerMessage {
            // Inner field comment.
            string text = 1;
          }
          InnerMessage inner = 1;
        }
    """

    with compile_for_test({"nested.proto": proto}):
        import nested_pretty  # type: ignore[import-not-found]

        # Check nested message docstring
        assert (
            "Nested inner message." in nested_pretty.OuterMessage.InnerMessage.__doc__
        )

        # Check nested message field comment
        inner_wrapper = nested_pretty.OuterMessage.InnerMessage()
        text_property = type(inner_wrapper).text
        assert "Inner field comment." in text_property.fget.__doc__


def test_nested_enum_docstring_contains_proto_comment():
    proto = """
        syntax = "proto3";

        message Container {
          // Inner status enum.
          enum InnerStatus {
            // Default value.
            INNER_STATUS_DEFAULT = 0;
          }
          InnerStatus status = 1;
        }
    """

    with compile_for_test({"container.proto": proto}):
        import container_pretty  # type: ignore[import-not-found]

        # Check nested enum docstring
        assert "Inner status enum." in container_pretty.Container.InnerStatus.__doc__


def test_message_docstring_handles_multiline_comments():
    proto = """
        syntax = "proto3";

        // This is a multiline comment
        // that spans multiple lines
        // and should be properly handled.
        message MultilineComment {
          int32 value = 1;
        }
    """

    with compile_for_test({"multiline.proto": proto}):
        import multiline_pretty  # type: ignore[import-not-found]

        docstring = multiline_pretty.MultilineComment.__doc__
        assert "This is a multiline comment" in docstring
        assert "that spans multiple lines" in docstring
        assert "and should be properly handled." in docstring


def test_field_docstring_contains_trailing_comments():
    proto = """
        syntax = "proto3";

        message TrailingComments {
          int32 value = 1; // This is a trailing comment
        }
    """

    with compile_for_test({"trailing.proto": proto}):
        import trailing_pretty  # type: ignore[import-not-found]

        wrapper = trailing_pretty.TrailingComments()
        value_property = type(wrapper).value

        # Trailing comments should also be included
        assert "This is a trailing comment" in value_property.fget.__doc__


def test_message_without_comments_generates_default_docstring():
    proto = """
        syntax = "proto3";

        message NoComments {
          int32 value = 1;
        }
    """

    with compile_for_test({"nocomments.proto": proto}):
        import nocomments_pretty  # type: ignore[import-not-found]

        # Should still have a basic docstring even without comments
        assert "Wrapper for" in nocomments_pretty.NoComments.__doc__


def test_message_comment_with_quotes_gets_escaped():
    proto = """
        syntax = "proto3";

        // This message has a "quoted" word in the comment.
        message QuotedComment {
          int32 value = 1;
        }
    """

    with compile_for_test({"quoted.proto": proto}):
        import quoted_pretty  # type: ignore[import-not-found]

        # The docstring should contain the comment with escaped quotes
        docstring = quoted_pretty.QuotedComment.__doc__
        assert 'This message has a "quoted" word in the comment.' in docstring

        # Verify that the generated Python code is syntactically valid
        # by checking that the class can be instantiated (this would fail
        # if the docstring quotes weren't properly escaped)
        instance = quoted_pretty.QuotedComment()
        assert instance is not None


def test_enum_comment_with_quotes_gets_escaped():
    proto = """
        syntax = "proto3";

        // Status enum with "special" values.
        enum Status {
          // Unknown "default" status.
          STATUS_UNKNOWN = 0;
          // Success "good" status.
          STATUS_SUCCESS = 1;
        }
    """

    with compile_for_test({"quoted_enum.proto": proto}):
        import quoted_enum_pretty  # type: ignore[import-not-found]

        # The enum docstring should contain comments with escaped quotes
        docstring = quoted_enum_pretty.Status.__doc__
        assert 'Status enum with "special" values.' in docstring
        assert 'Unknown "default" status.' in docstring
        assert 'Success "good" status.' in docstring

        # Verify the enum can be used (validates syntax)
        assert quoted_enum_pretty.Status.UNKNOWN.value == 0
