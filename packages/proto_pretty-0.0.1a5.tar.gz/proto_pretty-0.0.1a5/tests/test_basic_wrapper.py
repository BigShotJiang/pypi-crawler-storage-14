from .helpers import compile_for_test


def test_generates_wrappers_for_proto_messages():
    proto = """
        syntax = "proto3";

        message SimpleMessage {
          int32 value = 1;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        wrapper = simple_pretty.SimpleMessage(value=0)

        wrapper.value = 42
        assert wrapper.value == 42
        assert wrapper._pb.value == 42
