from .helpers import compile_for_test


def test_cross_file_imports_allow_using_types_from_other_proto_files():
    types_proto = """
        syntax = "proto3";

        message User {
            string name = 1;
        }
    """

    api_proto = """
        syntax = "proto3";

        import "types.proto";

        message CreateUserRequest {
            User user = 1;
        }
    """

    with compile_for_test({"types.proto": types_proto, "api.proto": api_proto}):
        import api_pretty  # type: ignore[import-not-found]
        import types_pretty  # type: ignore[import-not-found]

        # Should be able to create request with user from other file
        user = types_pretty.User(name="Alice")
        request = api_pretty.CreateUserRequest(user=user)

        assert request.user.name == "Alice"


def test_hierarchical_directory_imports_work_with_nested_proto_files():
    models_user_proto = """
        syntax = "proto3";

        message User {
            string username = 1;
            string email = 2;
        }
    """

    services_auth_proto = """
        syntax = "proto3";

        import "models/user.proto";

        message LoginRequest {
            User user = 1;
            string password = 2;
        }

        message LoginResponse {
            bool success = 1;
            User authenticated_user = 2;
        }
    """

    with compile_for_test(
        {
            "models/user.proto": models_user_proto,
            "services/auth.proto": services_auth_proto,
        }
    ):
        import models.user_pretty  # type: ignore[import-not-found]
        import services.auth_pretty  # type: ignore[import-not-found]

        # Should be able to create user from models directory
        user = models.user_pretty.User(username="john_doe", email="john@example.com")

        # Should be able to use user in service from different directory
        login_request = services.auth_pretty.LoginRequest(
            user=user, password="secret123"
        )

        login_response = services.auth_pretty.LoginResponse(
            success=True, authenticated_user=user
        )

        assert login_request.user.username == "john_doe"
        assert login_request.user.email == "john@example.com"
        assert login_request.password == "secret123"

        assert login_response.success
        assert login_response.authenticated_user.username == "john_doe"
