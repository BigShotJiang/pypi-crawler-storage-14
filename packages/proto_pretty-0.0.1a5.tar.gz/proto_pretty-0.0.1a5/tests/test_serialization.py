import pytest
from google.protobuf.message import DecodeError

from .helpers import compile_for_test


def test_bytes_conversion_does_roundtrip_serialization():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create original message
        original = test_pretty.TestMessage(value=42, name="hello")

        # Serialize using bytes()
        data = bytes(original)
        assert isinstance(data, bytes)
        assert len(data) > 0

        # Deserialize using parse()
        restored = test_pretty.TestMessage.parse(data)

        # Verify data integrity
        assert restored.value == 42
        assert restored.name == "hello"


def test_empty_message_supports_bytes_conversion():
    proto = """
        syntax = "proto3";

        message EmptyMessage {
        }
    """

    with compile_for_test({"empty.proto": proto}):
        import empty_pretty  # type: ignore[import-not-found]

        # Create empty message
        original = empty_pretty.EmptyMessage()

        # Serialize and deserialize
        data = bytes(original)
        restored = empty_pretty.EmptyMessage.parse(data)

        # Should work even with empty message
        assert isinstance(restored, empty_pretty.EmptyMessage)

        # Empty messages should still support bracket access but always raise KeyError
        with pytest.raises(KeyError):
            _ = original["any_field"]

        with pytest.raises(KeyError):
            original["any_field"] = "value"


def test_nested_messages_preserve_data_through_bytes_conversion():
    proto = """
        syntax = "proto3";

        message InnerMessage {
          int32 value = 1;
        }

        message OuterMessage {
          string name = 1;
          InnerMessage inner = 2;
        }
    """

    with compile_for_test({"nested.proto": proto}):
        import nested_pretty  # type: ignore[import-not-found]

        # Create nested message
        inner = nested_pretty.InnerMessage(value=123)
        original = nested_pretty.OuterMessage(name="test", inner=inner)

        # Serialize and deserialize
        data = bytes(original)
        restored = nested_pretty.OuterMessage.parse(data)

        # Verify nested data
        assert restored.name == "test"
        assert restored.inner.value == 123


def test_repeated_fields_preserve_data_through_bytes_conversion():
    proto = """
        syntax = "proto3";

        message RepeatedMessage {
          repeated string tags = 1;
          repeated int32 numbers = 2;
        }
    """

    with compile_for_test({"repeated.proto": proto}):
        import repeated_pretty  # type: ignore[import-not-found]

        # Create message with repeated fields
        original = repeated_pretty.RepeatedMessage(
            tags=["tag1", "tag2", "tag3"], numbers=[1, 2, 3, 4, 5]
        )

        # Serialize and deserialize
        data = bytes(original)
        restored = repeated_pretty.RepeatedMessage.parse(data)

        # Verify repeated data
        assert restored.tags == ["tag1", "tag2", "tag3"]
        assert restored.numbers == [1, 2, 3, 4, 5]


def test_parse_raises_error_when_given_invalid_data():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Try to parse invalid data - should raise an exception
        with pytest.raises(DecodeError):
            test_pretty.TestMessage.parse(b"invalid protobuf data")


def test_to_dict_converts_message_to_dictionary():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create message
        original = test_pretty.TestMessage(value=42, name="hello")

        # Convert to dict
        data_dict = original.to_dict()

        # Verify dict structure
        assert isinstance(data_dict, dict)
        assert data_dict["value"] == 42
        assert data_dict["name"] == "hello"


def test_from_dict_creates_message_from_dictionary():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create from dict
        data_dict = {"value": 123, "name": "world"}
        message = test_pretty.TestMessage.from_dict(data_dict)

        # Verify data
        assert message.value == 123
        assert message.name == "world"


def test_dict_conversion_does_roundtrip():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
          repeated string tags = 3;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create original message
        original = test_pretty.TestMessage(value=42, name="test", tags=["tag1", "tag2"])

        # Convert to dict and back
        data_dict = original.to_dict()
        restored = test_pretty.TestMessage.from_dict(data_dict)

        # Verify data integrity
        assert restored.value == 42
        assert restored.name == "test"
        assert restored.tags == ["tag1", "tag2"]


def test_nested_messages_work_with_dict_conversion():
    proto = """
        syntax = "proto3";

        message InnerMessage {
          int32 value = 1;
        }

        message OuterMessage {
          string name = 1;
          InnerMessage inner = 2;
        }
    """

    with compile_for_test({"nested.proto": proto}):
        import nested_pretty  # type: ignore[import-not-found]

        # Create nested message
        inner = nested_pretty.InnerMessage(value=123)
        original = nested_pretty.OuterMessage(name="test", inner=inner)

        # Convert to dict
        data_dict = original.to_dict()

        # Verify nested structure
        assert data_dict["name"] == "test"
        assert isinstance(data_dict["inner"], dict)
        assert data_dict["inner"]["value"] == 123

        # Convert back from dict
        restored = nested_pretty.OuterMessage.from_dict(data_dict)
        assert restored.name == "test"
        assert restored.inner.value == 123


def test_to_json_converts_message_to_json_string():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create message
        original = test_pretty.TestMessage(value=42, name="hello")

        # Convert to JSON
        json_str = original.to_json()

        # Verify JSON structure
        assert isinstance(json_str, str)
        assert "42" in json_str
        assert '"hello"' in json_str
        assert "value" in json_str
        assert "name" in json_str


def test_from_json_creates_message_from_json_string():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create from JSON
        json_str = '{"value": 123, "name": "world"}'
        message = test_pretty.TestMessage.from_json(json_str)

        # Verify data
        assert message.value == 123
        assert message.name == "world"


def test_json_conversion_does_roundtrip():
    proto = """
        syntax = "proto3";

        message TestMessage {
          int32 value = 1;
          string name = 2;
          repeated string tags = 3;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Create original message
        original = test_pretty.TestMessage(value=42, name="test", tags=["tag1", "tag2"])

        # Convert to JSON and back
        json_str = original.to_json()
        restored = test_pretty.TestMessage.from_json(json_str)

        # Verify data integrity
        assert restored.value == 42
        assert restored.name == "test"
        assert restored.tags == ["tag1", "tag2"]


def test_nested_messages_work_with_json_conversion():
    proto = """
        syntax = "proto3";

        message InnerMessage {
          int32 value = 1;
        }

        message OuterMessage {
          string name = 1;
          InnerMessage inner = 2;
        }
    """

    with compile_for_test({"nested.proto": proto}):
        import nested_pretty  # type: ignore[import-not-found]

        # Create nested message
        inner = nested_pretty.InnerMessage(value=123)
        original = nested_pretty.OuterMessage(name="test", inner=inner)

        # Convert to JSON and verify nested structure
        json_str = original.to_json()
        assert "test" in json_str
        assert "123" in json_str
        assert "inner" in json_str

        # Convert back from JSON
        restored = nested_pretty.OuterMessage.from_json(json_str)
        assert restored.name == "test"
        assert restored.inner.value == 123
