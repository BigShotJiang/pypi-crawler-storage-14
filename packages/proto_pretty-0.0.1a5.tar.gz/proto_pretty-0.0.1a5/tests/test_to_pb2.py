from tests.helpers import compile_for_test


def test_to_pb2_returns_underlying_protobuf():
    proto = """
        syntax = "proto3";
        message Person {
          string name = 1;
          int32 age = 2;
        }
    """

    with compile_for_test({"person.proto": proto}):
        import person_pb2  # type: ignore
        import person_pretty  # type: ignore

        person = person_pretty.Person(name="Alice", age=30)

        assert person_pb2.Person(name="Alice", age=30) == person.to_pb2()


def test_to_pb2_with_nested_messages():
    proto = """
        syntax = "proto3";
        message Location {
          string street = 1;
          string city = 2;
        }
        message Employee {
          string name = 1;
          Location location = 2;
        }
    """

    with compile_for_test({"employee.proto": proto}):
        import employee_pb2  # type: ignore
        import employee_pretty  # type: ignore

        location = employee_pretty.Location(street="Main St", city="Town")
        employee = employee_pretty.Employee(name="Bob", location=location)

        expected_location = employee_pb2.Location(street="Main St", city="Town")
        expected_employee = employee_pb2.Employee(
            name="Bob", location=expected_location
        )

        assert expected_location == location.to_pb2()
        assert expected_employee == employee.to_pb2()


def test_to_pb2_with_deeply_nested_messages():
    proto = """
        syntax = "proto3";
        message Level1 {
          message Level2 {
            message Level3 {
              string data = 1;
            }
            Level3 level3 = 1;
          }
          Level2 level2 = 1;
        }
    """

    with compile_for_test({"deep.proto": proto}):
        import deep_pb2  # type: ignore
        import deep_pretty  # type: ignore

        level3 = deep_pretty.Level1.Level2.Level3(data="value")
        level2 = deep_pretty.Level1.Level2(level3=level3)
        level1 = deep_pretty.Level1(level2=level2)

        expected_level3 = deep_pb2.Level1.Level2.Level3(data="value")
        expected_level2 = deep_pb2.Level1.Level2(level3=expected_level3)
        expected_level1 = deep_pb2.Level1(level2=expected_level2)

        assert expected_level3 == level3.to_pb2()
        assert expected_level2 == level2.to_pb2()
        assert expected_level1 == level1.to_pb2()
