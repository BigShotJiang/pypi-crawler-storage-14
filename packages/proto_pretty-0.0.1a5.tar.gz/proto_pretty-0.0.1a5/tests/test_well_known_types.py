"""Tests for Google Protocol Buffers Well-Known Types support."""

import datetime
import os
import time

import pytest

from .helpers import compile_for_test


def test_timestamp_field_uses_native_datetime_type():
    proto = """
        syntax = "proto3";

        import "google/protobuf/timestamp.proto";

        message TestMessage {
          google.protobuf.Timestamp created_at = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept datetime objects
        now = datetime.datetime(2023, 4, 15, 12, 30, 45, 123456, tzinfo=datetime.UTC)
        msg = test_pretty.TestMessage(created_at=now)

        # Should return datetime objects
        assert msg.created_at == now


def test_duration_field_uses_native_timedelta_type():
    proto = """
        syntax = "proto3";

        import "google/protobuf/duration.proto";

        message TestMessage {
          google.protobuf.Duration elapsed_time = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept timedelta objects
        duration = datetime.timedelta(
            hours=2, minutes=30, seconds=15, microseconds=500000
        )
        msg = test_pretty.TestMessage(elapsed_time=duration)

        # Should return timedelta objects
        assert msg.elapsed_time == duration


def test_optional_timestamp_field_supports_none():
    proto = """
        syntax = "proto3";

        import "google/protobuf/timestamp.proto";

        message TestMessage {
          optional google.protobuf.Timestamp updated_at = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept datetime
        now = datetime.datetime(2023, 4, 15, 12, 30, 45, tzinfo=datetime.UTC)
        msg = test_pretty.TestMessage(updated_at=now)
        assert msg.updated_at == now

        msg.updated_at = None
        assert msg.updated_at is None


def test_repeated_timestamp_fields():
    proto = """
        syntax = "proto3";

        import "google/protobuf/timestamp.proto";

        message TestMessage {
          repeated google.protobuf.Timestamp events = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        events = [
            datetime.datetime(2023, 4, 15, 12, 0, 0, tzinfo=datetime.UTC),
            datetime.datetime(2023, 4, 15, 13, 0, 0, tzinfo=datetime.UTC),
        ]

        msg = test_pretty.TestMessage(events=events)
        assert len(msg.events) == 2
        assert all(isinstance(event, datetime.datetime) for event in msg.events)
        assert msg.events == events


def test_timestamp_field_treats_naive_datetimes_as_utc():
    proto = """
        syntax = "proto3";

        import "google/protobuf/timestamp.proto";

        message TestMessage {
          google.protobuf.Timestamp created_at = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        if not hasattr(time, "tzset"):
            pytest.skip("time.tzset is not available on this platform")

        original_tz = os.environ.get("TZ")

        try:
            os.environ["TZ"] = "Etc/GMT-5"
            time.tzset()

            naive_time = datetime.datetime(2023, 4, 15, 12, 30, 45)
            msg = test_pretty.TestMessage(created_at=naive_time)

            expected = naive_time.replace(tzinfo=datetime.UTC)
            assert msg.created_at == expected
        finally:
            if original_tz is None:
                os.environ.pop("TZ", None)
            else:
                os.environ["TZ"] = original_tz
            time.tzset()


def test_well_known_types_serialization():
    proto = """
        syntax = "proto3";

        import "google/protobuf/timestamp.proto";
        import "google/protobuf/duration.proto";

        message TestMessage {
          google.protobuf.Timestamp created_at = 1;
          google.protobuf.Duration elapsed_time = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        created_at = datetime.datetime(
            2023, 4, 15, 12, 30, 45, 123456, tzinfo=datetime.UTC
        )
        elapsed_time = datetime.timedelta(hours=2, minutes=30)

        original = test_pretty.TestMessage(
            created_at=created_at, elapsed_time=elapsed_time
        )

        # Test bytes serialization
        data = bytes(original)
        restored = test_pretty.TestMessage.parse(data)

        assert isinstance(restored.created_at, datetime.datetime)
        assert isinstance(restored.elapsed_time, datetime.timedelta)
        # Note: microsecond precision might be lost in protobuf serialization
        assert restored.created_at.replace(microsecond=0) == created_at.replace(
            microsecond=0
        )
        assert restored.elapsed_time == elapsed_time


def test_string_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.StringValue name = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept string values
        msg = test_pretty.TestMessage(name="John")
        assert msg.name == "John"

        # Should handle updates
        msg.name = "Jane"
        assert msg.name == "Jane"


def test_optional_string_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          optional google.protobuf.StringValue description = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept string
        msg = test_pretty.TestMessage(description="A description")
        assert msg.description == "A description"

        # Should accept None
        msg = test_pretty.TestMessage(description=None)
        assert msg.description is None


def test_repeated_string_value_fields():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          repeated google.protobuf.StringValue tags = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        tags = ["python", "protobuf", "", "testing"]
        msg = test_pretty.TestMessage(tags=tags)

        assert len(msg.tags) == 4
        assert msg.tags[0] == "python"
        assert msg.tags[1] == "protobuf"
        assert msg.tags[2] == ""
        assert msg.tags[3] == "testing"


def test_string_value_serialization():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.StringValue name = 1;
          optional google.protobuf.StringValue description = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        original = test_pretty.TestMessage(name="John", description=None)

        # Test bytes serialization
        data = bytes(original)
        restored = test_pretty.TestMessage.parse(data)

        assert restored.name == "John"
        assert restored.description is None


def test_bool_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.BoolValue enabled = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept bool values
        msg = test_pretty.TestMessage(enabled=True)
        assert msg.enabled is True


def test_int32_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.Int32Value count = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept int values
        msg = test_pretty.TestMessage(count=42)
        assert msg.count == 42

        msg = test_pretty.TestMessage(count=-123)
        assert msg.count == -123


def test_int64_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.Int64Value big_number = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept large int values
        msg = test_pretty.TestMessage(big_number=9223372036854775807)
        assert msg.big_number == 9223372036854775807


def test_float_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.FloatValue temperature = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept float values
        msg = test_pretty.TestMessage(temperature=98.6)
        assert abs(msg.temperature - 98.6) < 0.001


def test_double_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.DoubleValue precision = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept float values with high precision
        msg = test_pretty.TestMessage(precision=3.141592653589793)
        assert abs(msg.precision - 3.141592653589793) < 1e-15


def test_bytes_value_field():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.BytesValue data = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        # Should accept bytes values
        test_data = b"Hello, world!"
        msg = test_pretty.TestMessage(data=test_data)
        assert msg.data == test_data


def test_repeated_primitive_wrapper_fields():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          repeated google.protobuf.BoolValue flags = 1;
          repeated google.protobuf.Int32Value numbers = 2;
          repeated google.protobuf.StringValue names = 3;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        msg = test_pretty.TestMessage(
            flags=[True, False, True],
            numbers=[1, 0, 3, 5],
            names=["alice", "", "bob", "charlie"],
        )

        assert len(msg.flags) == 3
        assert msg.flags[0] is True
        assert msg.flags[1] is False
        assert msg.flags[2] is True

        assert len(msg.numbers) == 4
        assert msg.numbers[0] == 1
        assert msg.numbers[1] == 0
        assert msg.numbers[2] == 3
        assert msg.numbers[3] == 5

        assert len(msg.names) == 4
        assert msg.names[0] == "alice"
        assert msg.names[1] == ""
        assert msg.names[2] == "bob"
        assert msg.names[3] == "charlie"


def test_primitive_wrapper_serialization():
    proto = """
        syntax = "proto3";

        import "google/protobuf/wrappers.proto";

        message TestMessage {
          google.protobuf.BoolValue enabled = 1;
          google.protobuf.Int32Value count = 2;
          google.protobuf.FloatValue temperature = 3;
          google.protobuf.StringValue name = 4;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        original = test_pretty.TestMessage(
            enabled=True, count=42, temperature=98.6, name="test"
        )

        # Test bytes serialization
        data = bytes(original)
        restored = test_pretty.TestMessage.parse(data)

        assert restored.enabled is True
        assert restored.count == 42
        assert abs(restored.temperature - 98.6) < 0.001
        assert restored.name == "test"


def test_well_known_types_dict_conversion():
    proto = """
        syntax = "proto3";

        import "google/protobuf/timestamp.proto";
        import "google/protobuf/duration.proto";

        message TestMessage {
          google.protobuf.Timestamp created_at = 1;
          google.protobuf.Duration elapsed_time = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        created_at = datetime.datetime(2023, 4, 15, 12, 30, 45, tzinfo=datetime.UTC)
        elapsed_time = datetime.timedelta(hours=2, minutes=30)

        original = test_pretty.TestMessage(
            created_at=created_at, elapsed_time=elapsed_time
        )

        # Convert to dict - should use appropriate string representations
        # Note: Protobuf JSON format converts snake_case field names to camelCase
        data_dict = original.to_dict()
        assert "createdAt" in data_dict
        assert "elapsedTime" in data_dict

        # Should be able to create from dict
        restored = test_pretty.TestMessage.from_dict(data_dict)
        assert isinstance(restored.created_at, datetime.datetime)
        assert isinstance(restored.elapsed_time, datetime.timedelta)
