from tests.helpers import compile_for_test


def test_repeated_primitive_fields_support_list_operations():
    proto = """
        syntax = "proto3";

        message TaskList {
            repeated string tasks = 1;
            repeated int32 priorities = 2;
        }
    """

    with compile_for_test({"tasks.proto": proto}):
        from tasks_pretty import TaskList  # type: ignore[import-not-found]

        # Test constructor with default empty lists
        task_list = TaskList()
        assert len(task_list.tasks) == 0
        assert len(task_list.priorities) == 0

        # Test constructor with initial values
        task_list = TaskList(tasks=["buy milk", "walk dog"], priorities=[1, 3])
        assert list(task_list.tasks) == ["buy milk", "walk dog"]
        assert list(task_list.priorities) == [1, 3]

        # Test append operation
        task_list.tasks.append("do homework")
        assert list(task_list.tasks) == ["buy milk", "walk dog", "do homework"]

        # Test extend operation
        task_list.priorities.extend([2, 5])
        assert list(task_list.priorities) == [1, 3, 2, 5]

        # Test assignment
        task_list.tasks = ["new task"]
        assert list(task_list.tasks) == ["new task"]


def test_repeated_message_fields_contain_wrapper_objects():
    proto = """
        syntax = "proto3";

        message Contact {
            string name = 1;
            string email = 2;
        }

        message AddressBook {
            repeated Contact contacts = 1;
        }
    """

    with compile_for_test({"contacts.proto": proto}):
        from contacts_pretty import (  # type: ignore[import-not-found]
            AddressBook,
            Contact,
        )

        # Create some contacts
        contact1 = Contact(name="Alice", email="alice@example.com")
        contact2 = Contact(name="Bob", email="bob@example.com")

        # Test constructor with repeated message fields
        book = AddressBook(contacts=[contact1, contact2])

        # Verify we get wrapper objects back
        assert len(book.contacts) == 2
        assert isinstance(book.contacts[0], Contact)
        assert book.contacts[0].name == "Alice"
        assert book.contacts[1].name == "Bob"

        # Test append with message
        contact3 = Contact(name="Charlie", email="charlie@example.com")
        book.contacts.append(contact3)
        assert len(book.contacts) == 3
        assert book.contacts[2].name == "Charlie"


def test_repeated_enum_fields_contain_enum_values():
    proto = """
        syntax = "proto3";

        enum Priority {
            LOW = 0;
            MEDIUM = 1;
            HIGH = 2;
        }

        message Task {
            repeated Priority urgency_levels = 1;
        }
    """

    with compile_for_test({"task_priority.proto": proto}):
        from task_priority_pretty import (  # type: ignore[import-not-found]
            Priority,
            Task,
        )

        # Test with enum repeated field
        task = Task(urgency_levels=[Priority.HIGH, Priority.LOW])
        assert len(task.urgency_levels) == 2
        assert task.urgency_levels[0] == Priority.HIGH
        assert task.urgency_levels[1] == Priority.LOW

        # Test append with enum
        task.urgency_levels.append(Priority.MEDIUM)
        assert len(task.urgency_levels) == 3
        assert task.urgency_levels[2] == Priority.MEDIUM


def test_repeated_field_to_pb2():
    proto = """
        syntax = "proto3";

        message StringList {
            repeated string items = 1;
        }
    """

    with compile_for_test({"strings.proto": proto}):
        import strings_pb2  # type: ignore[import-not-found]
        from strings_pretty import StringList  # type: ignore[import-not-found]

        # Create pretty wrapper with repeated field
        str_list = StringList(items=["hello", "world"])

        # Convert to pb2 and verify
        pb2_obj = str_list.to_pb2()
        assert isinstance(pb2_obj, strings_pb2.StringList)
        assert pb2_obj.items == ["hello", "world"]

        # Modify through pretty wrapper
        str_list.items.append("!")

        # Convert again and verify changes are reflected
        pb2_obj2 = str_list.to_pb2()
        assert pb2_obj2.items == ["hello", "world", "!"]


def test_repeated_field_from_pb2():
    proto = """
        syntax = "proto3";

        message NumberList {
            repeated int32 numbers = 1;
        }
    """

    with compile_for_test({"numbers.proto": proto}):
        import numbers_pb2  # type: ignore[import-not-found]
        from numbers_pretty import NumberList  # type: ignore[import-not-found]

        # Create pb2 object with repeated field
        pb2_obj = numbers_pb2.NumberList()
        pb2_obj.numbers.extend([1, 2, 3, 4])

        # Create pretty wrapper from pb2
        num_list = NumberList.from_pb2(pb2_obj)
        assert list(num_list.numbers) == [1, 2, 3, 4]

        # Verify modifications work
        num_list.numbers.append(5)
        assert list(num_list.numbers) == [1, 2, 3, 4, 5]
