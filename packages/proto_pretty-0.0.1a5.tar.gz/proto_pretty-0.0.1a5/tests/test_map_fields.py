from .helpers import compile_for_test


def test_map_field_supports_string_to_string_mapping():
    proto = """
        syntax = "proto3";

        message Config {
            map<string, string> properties = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        config = test_pretty.Config()

        # Initially empty
        assert len(config.properties) == 0

        # Set some values
        config.properties["key1"] = "value1"
        config.properties["key2"] = "value2"

        # Check values
        assert config.properties["key1"] == "value1"
        assert config.properties["key2"] == "value2"
        assert len(config.properties) == 2

        # Check iteration
        items = dict(config.properties)
        assert items == {"key1": "value1", "key2": "value2"}


def test_map_field_supports_string_to_int_mapping():
    proto = """
        syntax = "proto3";

        message Scores {
            map<string, int32> player_scores = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        scores = test_pretty.Scores()

        # Set some scores
        scores.player_scores["alice"] = 100
        scores.player_scores["bob"] = 85
        scores.player_scores["charlie"] = 92

        # Check values
        assert scores.player_scores["alice"] == 100
        assert scores.player_scores["bob"] == 85
        assert scores.player_scores["charlie"] == 92

        # Test contains
        assert "alice" in scores.player_scores
        assert "dave" not in scores.player_scores


def skip_test_map_field_supports_message_values():
    proto = """
        syntax = "proto3";

        message Address {
            int32 number = 1;
            string name = 2;
        }

        message AddressBook {
            map<string, Address> addresses = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        book = test_pretty.AddressBook()

        # Create addresses
        home = test_pretty.Address(number=123, name="Main St")
        work = test_pretty.Address(number=456, name="Oak Ave")

        # Set addresses
        book.addresses["home"] = home
        book.addresses["work"] = work

        # Check values
        assert book.addresses["home"].number == 123
        assert book.addresses["home"].name == "Main St"
        assert book.addresses["work"].number == 456
        assert book.addresses["work"].name == "Oak Ave"


def test_map_field_supports_enum_values():
    proto = """
        syntax = "proto3";

        enum Status {
            UNKNOWN = 0;
            ACTIVE = 1;
            INACTIVE = 2;
        }

        message UserStatuses {
            map<string, Status> user_status = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        statuses = test_pretty.UserStatuses()

        # Set statuses
        statuses.user_status["alice"] = test_pretty.Status.ACTIVE
        statuses.user_status["bob"] = test_pretty.Status.INACTIVE

        # Check values
        assert statuses.user_status["alice"] == test_pretty.Status.ACTIVE
        assert statuses.user_status["bob"] == test_pretty.Status.INACTIVE


def test_map_field_provides_dict_like_methods():
    proto = """
        syntax = "proto3";

        message Data {
            map<string, int32> values = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        data = test_pretty.Data()

        # Update with dict
        data.values.update({"a": 1, "b": 2, "c": 3})
        assert len(data.values) == 3

        # Test keys(), values(), items()
        assert set(data.values.keys()) == {"a", "b", "c"}
        assert set(data.values.values()) == {1, 2, 3}
        assert set(data.values.items()) == {("a", 1), ("b", 2), ("c", 3)}

        # Test get()
        assert data.values.get("a") == 1
        assert data.values.get("missing") is None
        assert data.values.get("missing", 42) == 42

        # Test setdefault()
        assert data.values.setdefault("d", 4) == 4
        assert data.values["d"] == 4
        assert data.values.setdefault("d", 99) == 4  # Should not overwrite

        # Test pop()
        value = data.values.pop("a")
        assert value == 1
        assert "a" not in data.values

        # Test popitem()
        key, value = data.values.popitem()
        assert key in ["b", "c", "d"]
        assert value in [2, 3, 4]

        # Test clear()
        data.values.clear()
        assert len(data.values) == 0


def test_map_field_accepts_dict_assignment():
    proto = """
        syntax = "proto3";

        message Config {
            map<string, string> settings = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        config = test_pretty.Config()

        # Assign from dict
        config.settings = {"debug": "true", "timeout": "30", "retries": "3"}

        # Check values
        assert config.settings["debug"] == "true"
        assert config.settings["timeout"] == "30"
        assert config.settings["retries"] == "3"
        assert len(config.settings) == 3


def test_map_field_provides_readable_repr():
    proto = """
        syntax = "proto3";

        message Data {
            map<string, int32> numbers = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        data = test_pretty.Data()
        data.numbers["one"] = 1
        data.numbers["two"] = 2

        # Test repr
        repr_str = repr(data.numbers)
        # Should look like a dictionary representation
        assert "one" in repr_str
        assert "two" in repr_str
        assert "1" in repr_str
        assert "2" in repr_str


def test_map_field_supports_equality_comparison():
    proto = """
        syntax = "proto3";

        message Data {
            map<string, int32> values = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        data1 = test_pretty.Data()
        data1.values["a"] = 1
        data1.values["b"] = 2

        data2 = test_pretty.Data()
        data2.values["a"] = 1
        data2.values["b"] = 2

        # Should be equal
        assert data1.values == data2.values
        assert data1.values == {"a": 1, "b": 2}

        # Should not be equal
        data2.values["c"] = 3
        assert data1.values != data2.values
        assert data1.values != {"a": 1, "b": 2, "c": 3}


def test_nested_messages_support_map_fields():
    proto = """
        syntax = "proto3";

        message Inner {
            map<string, int32> data = 1;
        }

        message Outer {
            Inner inner = 1;
            map<string, Inner> inner_map = 2;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        outer = test_pretty.Outer()

        # Set nested map field
        outer.inner.data["key1"] = 10
        outer.inner.data["key2"] = 20

        # Set map of messages
        inner1 = test_pretty.Inner()
        inner1.data["x"] = 100
        outer.inner_map["first"] = inner1

        inner2 = test_pretty.Inner()
        inner2.data["y"] = 200
        outer.inner_map["second"] = inner2

        # Check values
        assert outer.inner.data["key1"] == 10
        assert outer.inner.data["key2"] == 20
        assert outer.inner_map["first"].data["x"] == 100
        assert outer.inner_map["second"].data["y"] == 200


def test_map_field_accepts_another_map_field_assignment():
    proto = """
        syntax = "proto3";

        message Inner {
            map<string, int32> data = 1;
        }

        message Outer {
            map<string, Inner> inner_map = 1;
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        outer1 = test_pretty.Outer()
        outer2 = test_pretty.Outer()

        inner = test_pretty.Inner()
        inner.data["value"] = 42
        outer1.inner_map["first"] = inner

        outer2.inner_map = outer1.inner_map

        assert "first" in outer2.inner_map
        assert outer2.inner_map["first"].data["value"] == 42
