from .helpers import compile_for_test


def test_bracket_access_gets_field_values():
    proto = """
        syntax = "proto3";

        message SimpleMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        wrapper = simple_pretty.SimpleMessage(value=42, name="test")

        # Test bracket access for getting values
        assert wrapper["value"] == 42
        assert wrapper["name"] == "test"


def test_bracket_access_sets_field_values():
    proto = """
        syntax = "proto3";

        message SimpleMessage {
          int32 value = 1;
          string name = 2;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        wrapper = simple_pretty.SimpleMessage()

        # Test bracket access for setting values
        wrapper["value"] = 123
        wrapper["name"] = "hello"

        assert wrapper["value"] == 123
        assert wrapper["name"] == "hello"
        assert wrapper.value == 123
        assert wrapper.name == "hello"


def test_bracket_access_with_optional_fields():
    proto = """
        syntax = "proto3";

        message OptionalMessage {
          string name = 1;
          optional string email = 2;
          optional int32 age = 3;
        }
    """

    with compile_for_test({"optional.proto": proto}):
        import optional_pretty  # type: ignore[import-not-found]

        wrapper = optional_pretty.OptionalMessage(name="test")

        # Test bracket access with optional fields
        assert wrapper["name"] == "test"
        assert wrapper["email"] is None
        assert wrapper["age"] is None

        # Set optional fields via bracket access
        wrapper["email"] = "test@example.com"
        wrapper["age"] = 25

        assert wrapper["email"] == "test@example.com"
        assert wrapper["age"] == 25


def test_bracket_access_with_enum_fields():
    proto = """
        syntax = "proto3";

        enum Status {
          STATUS_UNSPECIFIED = 0;
          STATUS_ACTIVE = 1;
          STATUS_INACTIVE = 2;
        }

        message MessageWithEnum {
          string name = 1;
          Status status = 2;
        }
    """

    with compile_for_test({"enum.proto": proto}):
        import enum_pretty  # type: ignore[import-not-found]

        wrapper = enum_pretty.MessageWithEnum(
            name="test", status=enum_pretty.Status.ACTIVE
        )

        # Test bracket access with enum fields
        assert wrapper["name"] == "test"
        assert wrapper["status"] == enum_pretty.Status.ACTIVE

        # Set enum field via bracket access
        wrapper["status"] = enum_pretty.Status.INACTIVE
        assert wrapper["status"] == enum_pretty.Status.INACTIVE


def test_bracket_access_with_repeated_fields():
    proto = """
        syntax = "proto3";

        message RepeatedMessage {
          repeated string tags = 1;
          repeated int32 numbers = 2;
        }
    """

    with compile_for_test({"repeated.proto": proto}):
        import repeated_pretty  # type: ignore[import-not-found]

        wrapper = repeated_pretty.RepeatedMessage(
            tags=["tag1", "tag2"], numbers=[1, 2, 3]
        )

        # Test bracket access with repeated fields
        assert wrapper["tags"] == ["tag1", "tag2"]
        assert wrapper["numbers"] == [1, 2, 3]

        # Set repeated fields via bracket access
        wrapper["tags"] = ["new_tag"]
        wrapper["numbers"] = [42]

        assert wrapper["tags"] == ["new_tag"]
        assert wrapper["numbers"] == [42]


def test_bracket_access_with_message_fields():
    proto = """
        syntax = "proto3";

        message InnerMessage {
          int32 value = 1;
        }

        message OuterMessage {
          string name = 1;
          InnerMessage inner = 2;
        }
    """

    with compile_for_test({"nested.proto": proto}):
        import nested_pretty  # type: ignore[import-not-found]

        inner = nested_pretty.InnerMessage(value=42)
        wrapper = nested_pretty.OuterMessage(name="test", inner=inner)

        # Test bracket access with message fields
        assert wrapper["name"] == "test"
        assert wrapper["inner"].value == 42

        # Set message field via bracket access
        new_inner = nested_pretty.InnerMessage(value=123)
        wrapper["inner"] = new_inner

        assert wrapper["inner"].value == 123


def test_bracket_access_raises_keyerror_for_invalid_field():
    proto = """
        syntax = "proto3";

        message SimpleMessage {
          int32 value = 1;
        }
    """

    with compile_for_test({"simple.proto": proto}):
        import simple_pretty  # type: ignore[import-not-found]

        wrapper = simple_pretty.SimpleMessage(value=42)

        # Test that accessing invalid field raises KeyError
        try:
            _ = wrapper["nonexistent"]
            raise AssertionError("Should have raised KeyError")
        except KeyError:
            pass

        # Test that setting invalid field raises KeyError
        try:
            wrapper["nonexistent"] = "value"
            raise AssertionError("Should have raised KeyError")
        except KeyError:
            pass
