from .helpers import compile_for_test


def test_generates_python_enum_for_protobuf_enum():
    proto = """
        syntax = "proto3";

        enum Status {
          STATUS_UNSPECIFIED = 0;
          STATUS_ACTIVE = 1;
          STATUS_INACTIVE = 2;
        }

        message User {
          string name = 1;
          Status status = 2;
        }
    """

    with compile_for_test({"user.proto": proto}):
        from enum import Enum

        import user_pretty  # type: ignore[import-not-found]

        assert hasattr(user_pretty, "Status")
        assert user_pretty.Status.UNSPECIFIED.value == 0
        assert user_pretty.Status.ACTIVE.value == 1
        assert user_pretty.Status.INACTIVE.value == 2
        assert isinstance(user_pretty.Status, type) and issubclass(
            user_pretty.Status, Enum
        )


def test_enum_variants_have_stripped_names_by_default():
    proto = """
        syntax = "proto3";

        enum Priority {
          PRIORITY_UNSPECIFIED = 0;
          PRIORITY_LOW = 1;
          PRIORITY_MEDIUM = 2;
          PRIORITY_HIGH = 3;
          PRIORITY_CRITICAL = 4;
        }
    """

    with compile_for_test({"priority.proto": proto}):
        import priority_pretty  # type: ignore[import-not-found]

        assert hasattr(priority_pretty.Priority, "UNSPECIFIED")
        assert hasattr(priority_pretty.Priority, "LOW")
        assert hasattr(priority_pretty.Priority, "MEDIUM")
        assert hasattr(priority_pretty.Priority, "HIGH")
        assert hasattr(priority_pretty.Priority, "CRITICAL")


def test_enum_values_match_protobuf_tags():
    proto = """
        syntax = "proto3";

        enum Color {
          COLOR_UNSPECIFIED = 0;
          COLOR_RED = 5;
          COLOR_GREEN = 10;
          COLOR_BLUE = 15;
        }
    """

    with compile_for_test({"color.proto": proto}):
        import color_pretty  # type: ignore[import-not-found]

        assert color_pretty.Color.UNSPECIFIED.value == 0
        assert color_pretty.Color.RED.value == 5
        assert color_pretty.Color.GREEN.value == 10
        assert color_pretty.Color.BLUE.value == 15


def test_message_with_enum_field_uses_pretty_enum():
    proto = """
        syntax = "proto3";

        enum State {
          STATE_UNSPECIFIED = 0;
          STATE_PENDING = 1;
          STATE_APPROVED = 2;
          STATE_REJECTED = 3;
        }

        message Request {
          string title = 1;
          State state = 2;
        }
    """

    with compile_for_test({"request.proto": proto}):
        import request_pretty  # type: ignore[import-not-found]

        request = request_pretty.Request(
            title="Test", state=request_pretty.State.PENDING
        )
        assert request.state == request_pretty.State.PENDING
        assert request.state.value == 1

        request.state = request_pretty.State.APPROVED
        assert request.state == request_pretty.State.APPROVED
        assert request.state.value == 2


def test_enum_prefix_stripping_enabled_by_default():
    proto = """
        syntax = "proto3";

        enum Status {
          STATUS_UNSPECIFIED = 0;
          STATUS_ACTIVE = 1;
          STATUS_INACTIVE = 2;
        }
    """

    with compile_for_test({"status.proto": proto}):
        import status_pretty  # type: ignore[import-not-found]

        # With prefix stripping enabled (default), enum values should be stripped
        assert hasattr(status_pretty.Status, "UNSPECIFIED")
        assert hasattr(status_pretty.Status, "ACTIVE")
        assert hasattr(status_pretty.Status, "INACTIVE")
        assert not hasattr(status_pretty.Status, "STATUS_UNSPECIFIED")
        assert status_pretty.Status.UNSPECIFIED.value == 0
        assert status_pretty.Status.ACTIVE.value == 1
        assert status_pretty.Status.INACTIVE.value == 2


def test_enum_prefix_stripping_can_be_disabled():
    proto = """
        syntax = "proto3";

        enum Priority {
          PRIORITY_UNSPECIFIED = 0;
          PRIORITY_LOW = 1;
          PRIORITY_HIGH = 2;
        }
    """

    with compile_for_test(
        {"priority.proto": proto}, env_vars={"PROTO_PRETTY_STRIP_ENUM_PREFIX": "false"}
    ):
        import priority_pretty  # type: ignore[import-not-found]

        # With prefix stripping disabled, enum values should keep original names
        assert hasattr(priority_pretty.Priority, "PRIORITY_UNSPECIFIED")
        assert hasattr(priority_pretty.Priority, "PRIORITY_LOW")
        assert hasattr(priority_pretty.Priority, "PRIORITY_HIGH")
        assert not hasattr(priority_pretty.Priority, "UNSPECIFIED")


def test_enum_prefix_stripping_with_mixed_prefixes_keeps_original_names():
    proto = """
        syntax = "proto3";

        enum Mixed {
          MIXED_A = 0;
          MIXED_B = 1;
          DIFFERENT_C = 2;
        }
    """

    with compile_for_test({"mixed.proto": proto}):
        import mixed_pretty  # type: ignore[import-not-found]

        # Mixed prefixes should fall back to original names
        assert hasattr(mixed_pretty.Mixed, "MIXED_A")
        assert hasattr(mixed_pretty.Mixed, "MIXED_B")
        assert hasattr(mixed_pretty.Mixed, "DIFFERENT_C")
        assert not hasattr(mixed_pretty.Mixed, "A")


def test_enum_prefix_stripping_with_numeric_variants_keeps_original_names():
    proto = """
        syntax = "proto3";

        enum Version {
          VERSION_UNSPECIFIED = 0;
          VERSION_1 = 1;
          VERSION_2 = 2;
        }
    """

    with compile_for_test({"version.proto": proto}):
        import version_pretty  # type: ignore[import-not-found]

        # Numeric variants would create invalid identifiers, so keep original names
        assert hasattr(version_pretty.Version, "VERSION_UNSPECIFIED")
        assert hasattr(version_pretty.Version, "VERSION_1")
        assert hasattr(version_pretty.Version, "VERSION_2")
        assert not hasattr(version_pretty.Version, "UNSPECIFIED")


def test_enum_prefix_stripping_with_empty_suffix_keeps_original_names():
    proto = """
        syntax = "proto3";

        enum State {
          STATE_UNSPECIFIED = 0;
          STATE_ = 1;
          STATE_ACTIVE = 2;
        }
    """

    with compile_for_test({"state.proto": proto}):
        import state_pretty  # type: ignore[import-not-found]

        # Empty suffix would create invalid identifier, so keep original names
        assert hasattr(state_pretty.State, "STATE_UNSPECIFIED")
        assert hasattr(state_pretty.State, "STATE_")
        assert hasattr(state_pretty.State, "STATE_ACTIVE")


def test_nested_enum_prefix_stripping():
    proto = """
        syntax = "proto3";

        message Container {
          enum NestedStatus {
            NESTED_STATUS_UNSPECIFIED = 0;
            NESTED_STATUS_OK = 1;
            NESTED_STATUS_ERROR = 2;
          }

          NestedStatus status = 1;
        }
    """

    with compile_for_test({"container.proto": proto}):
        import container_pretty  # type: ignore[import-not-found]

        # Nested enums should also have prefix stripping applied
        assert hasattr(container_pretty.Container.NestedStatus, "UNSPECIFIED")
        assert hasattr(container_pretty.Container.NestedStatus, "OK")
        assert hasattr(container_pretty.Container.NestedStatus, "ERROR")
        assert not hasattr(
            container_pretty.Container.NestedStatus, "NESTED_STATUS_UNSPECIFIED"
        )


def test_deeply_nested_enum_prefix_stripping():
    proto = """
        syntax = "proto3";

        message Outer {
          message Inner {
            enum DeepStatus {
              DEEP_STATUS_UNSPECIFIED = 0;
              DEEP_STATUS_READY = 1;
              DEEP_STATUS_DONE = 2;
            }
          }
        }
    """

    with compile_for_test({"deep.proto": proto}):
        import deep_pretty  # type: ignore[import-not-found]

        # Deeply nested enums should also have prefix stripping applied
        assert hasattr(deep_pretty.Outer.Inner.DeepStatus, "UNSPECIFIED")
        assert hasattr(deep_pretty.Outer.Inner.DeepStatus, "READY")
        assert hasattr(deep_pretty.Outer.Inner.DeepStatus, "DONE")
