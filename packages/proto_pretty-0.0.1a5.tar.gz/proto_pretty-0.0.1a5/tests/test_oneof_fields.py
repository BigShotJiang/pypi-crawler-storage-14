from .helpers import compile_for_test


def test_oneof_fields_return_none_when_not_active():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # Initially, all oneof fields should return None
        assert payment.credit_card is None
        assert payment.bank_account is None
        assert payment.cash_amount is None


def test_oneof_fields_return_value_when_active():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # Set credit_card and verify it's returned
        payment.credit_card = "1234-5678-9012-3456"
        assert payment.credit_card == "1234-5678-9012-3456"

        # Other variants should still return None
        assert payment.bank_account is None
        assert payment.cash_amount is None


def test_oneof_fields_clear_other_variants_when_set():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # Set credit_card
        payment.credit_card = "1234-5678-9012-3456"
        assert payment.credit_card == "1234-5678-9012-3456"
        assert payment.bank_account is None
        assert payment.cash_amount is None

        # Set bank_account - should clear credit_card
        payment.bank_account = "123-456-789"
        assert payment.credit_card is None
        assert payment.bank_account == "123-456-789"
        assert payment.cash_amount is None

        # Set cash_amount - should clear bank_account
        payment.cash_amount = 100
        assert payment.credit_card is None
        assert payment.bank_account is None
        assert payment.cash_amount == 100


def test_oneof_fields_can_be_set_to_none():
    proto = """
        syntax = "proto3";

        message Payment {
            oneof payment_method {
                string credit_card = 1;
                string bank_account = 2;
                int32 cash_amount = 3;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        payment = test_pretty.Payment()

        # Set a field and then clear it by setting to None
        payment.credit_card = "1234-5678-9012-3456"
        assert payment.credit_card == "1234-5678-9012-3456"

        payment.credit_card = None
        assert payment.credit_card is None
        assert payment.bank_account is None
        assert payment.cash_amount is None


def test_oneof_with_message_fields():
    proto = """
        syntax = "proto3";

        message Address {
            string street = 1;
            string city = 2;
        }

        message Contact {
            oneof contact_info {
                string email = 1;
                string phone = 2;
                Address address = 3;
            }
        }
    """

    with compile_for_test({"message_test.proto": proto}):
        import message_test_pretty  # type: ignore[import-not-found]

        contact = message_test_pretty.Contact()

        # Initially all fields should be None
        assert contact.email is None
        assert contact.phone is None
        assert contact.address is None

        # Set email
        contact.email = "test@example.com"
        assert contact.email == "test@example.com"
        assert contact.phone is None
        assert contact.address is None

        # Set address - should clear email
        address = message_test_pretty.Address(street="123 Main St", city="Anytown")
        contact.address = address
        assert contact.email is None
        assert contact.phone is None
        assert contact.address.street == "123 Main St"
        assert contact.address.city == "Anytown"

        # Clear by setting to None
        contact.address = None
        assert contact.email is None
        assert contact.phone is None
        assert contact.address is None


def test_oneof_with_enum_fields():
    proto = """
        syntax = "proto3";

        enum Priority {
            LOW = 0;
            MEDIUM = 1;
            HIGH = 2;
        }

        message Task {
            oneof urgency {
                Priority priority = 1;
                int32 deadline_days = 2;
            }
        }
    """

    with compile_for_test({"enum_test.proto": proto}):
        import enum_test_pretty  # type: ignore[import-not-found]

        task = enum_test_pretty.Task()

        # Initially all fields should be None
        assert task.priority is None
        assert task.deadline_days is None

        # Set priority
        task.priority = enum_test_pretty.Priority.HIGH
        assert task.priority == enum_test_pretty.Priority.HIGH
        assert task.deadline_days is None

        # Set deadline_days - should clear priority
        task.deadline_days = 7
        assert task.priority is None
        assert task.deadline_days == 7


def test_multiple_oneof_groups():
    proto = """
        syntax = "proto3";

        message MultiOneof {
            oneof group1 {
                string field_a = 1;
                int32 field_b = 2;
            }
            oneof group2 {
                bool field_c = 3;
                string field_d = 4;
            }
        }
    """

    with compile_for_test({"test.proto": proto}):
        import test_pretty  # type: ignore[import-not-found]

        obj = test_pretty.MultiOneof()

        # Initially all fields should be None
        assert obj.field_a is None
        assert obj.field_b is None
        assert obj.field_c is None
        assert obj.field_d is None

        # Set fields from different groups - they should not interfere
        obj.field_a = "test"
        obj.field_c = True
        assert obj.field_a == "test"
        assert obj.field_b is None
        assert obj.field_c is True
        assert obj.field_d is None

        # Set another field in group1 - should clear field_a but not affect group2
        obj.field_b = 42
        assert obj.field_a is None
        assert obj.field_b == 42
        assert obj.field_c is True  # Should remain set
        assert obj.field_d is None

        # Set another field in group2 - should clear field_c but not affect group1
        obj.field_d = "another test"
        assert obj.field_a is None
        assert obj.field_b == 42  # Should remain set
        assert obj.field_c is None
        assert obj.field_d == "another test"
