import black

from .helpers import compile_for_test


def test_generated_code_is_properly_formatted():
    proto = """
        syntax = "proto3";

        enum Status {
          STATUS_UNSPECIFIED = 0;
          STATUS_ACTIVE = 1;
          STATUS_INACTIVE = 2;
        }

        message FormattingTest {
          string name = 1;
          optional string email = 2;
          optional int32 age = 3;
          optional Status status = 4;
          bool active = 5;
        }
    """

    with compile_for_test({"formatting_test.proto": proto}) as temp_dir:
        from pathlib import Path

        temp_path = Path(temp_dir)
        generated_file = temp_path / "formatting_test_pretty.py"

        assert generated_file.exists(), "Generated pretty file should exist"

        generated_content = generated_file.read_text()

        try:
            formatted_content = black.format_str(
                generated_content, mode=black.FileMode()
            )

            assert generated_content == formatted_content, (
                "Generated code should be properly formatted with black. "
                f"Generated:\n{generated_content}\n\nExpected:\n{formatted_content}"
            )

        except ValueError as e:
            # If black can't parse the code, that's a bigger problem
            raise AssertionError(
                f"Generated code has syntax errors and can't be formatted: {e}"
            ) from e
