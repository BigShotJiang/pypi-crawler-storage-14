from tests.helpers import compile_for_test


def test_from_pb2_creates_wrapper_from_protobuf():
    proto = """
        syntax = "proto3";
        message Person {
          string name = 1;
          int32 age = 2;
        }
    """

    with compile_for_test({"person.proto": proto}):
        import person_pb2  # type: ignore
        import person_pretty  # type: ignore

        pb2_person = person_pb2.Person(name="Alice", age=30)
        wrapper_person = person_pretty.Person.from_pb2(pb2_person)

        assert wrapper_person.name == "Alice"
        assert wrapper_person.age == 30
        assert wrapper_person.to_pb2() == pb2_person


def test_from_pb2_with_nested_messages():
    proto = """
        syntax = "proto3";
        message Location {
          string street = 1;
          string city = 2;
        }
        message Employee {
          string name = 1;
          Location location = 2;
        }
    """

    with compile_for_test({"employee.proto": proto}):
        import employee_pb2  # type: ignore
        import employee_pretty  # type: ignore

        pb2_employee = employee_pb2.Employee(
            name="Bob", location=employee_pb2.Location(street="Main St", city="Town")
        )

        wrapper_employee = employee_pretty.Employee.from_pb2(pb2_employee)

        assert wrapper_employee.name == "Bob"
        assert wrapper_employee.location.street == "Main St"
        assert wrapper_employee.location.city == "Town"
        assert wrapper_employee.to_pb2() == pb2_employee


def test_from_pb2_with_deeply_nested_messages():
    proto = """
        syntax = "proto3";
        message Level1 {
          message Level2 {
            message Level3 {
              string data = 1;
            }
            Level3 level3 = 1;
          }
          Level2 level2 = 1;
        }
    """

    with compile_for_test({"deep.proto": proto}):
        import deep_pb2  # type: ignore
        import deep_pretty  # type: ignore

        pb2_level3 = deep_pb2.Level1.Level2.Level3(data="value")
        pb2_level2 = deep_pb2.Level1.Level2(level3=pb2_level3)
        pb2_level1 = deep_pb2.Level1(level2=pb2_level2)

        wrapper = deep_pretty.Level1.from_pb2(pb2_level1)

        assert wrapper.level2.level3.data == "value"
        assert wrapper.to_pb2() == pb2_level1
        assert wrapper.level2.to_pb2() == pb2_level2
        assert wrapper.level2.level3.to_pb2() == pb2_level3
