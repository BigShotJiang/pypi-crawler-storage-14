from __future__ import annotations

from abc import ABC
from typing import Any, Generic, TypeVar

from google.protobuf.json_format import MessageToDict, MessageToJson, Parse, ParseDict
from google.protobuf.message import Message

T = TypeVar("T", bound=Message)
Self = TypeVar("Self", bound="MessageBase")


class MessageBase(Generic[T], ABC):
    """Base class for all generated proto message wrappers."""

    _pb_class: type[T]

    def __init__(self) -> None:
        self._pb = self._pb_class()

    @classmethod
    def from_pb2(cls: type[Self], pb2_obj: T) -> Self:
        """Create wrapper from protobuf object."""
        instance = cls.__new__(cls)
        instance._pb = pb2_obj
        return instance

    def to_pb2(self) -> T:
        """Return underlying protobuf object."""
        return self._pb

    @classmethod
    def empty(cls: type[Self]) -> Self:
        """Create empty instance."""
        return cls.from_pb2(cls._pb_class())

    def __bytes__(self) -> bytes:
        """Serialize message to protobuf bytes.

        Returns:
            Binary protobuf representation of the message.
        """
        return self._pb.SerializeToString()

    @classmethod
    def parse(cls: type[Self], data: bytes) -> Self:
        """Parse message from protobuf bytes.

        Args:
            data: Binary protobuf data.

        Returns:
            New message instance populated with the parsed data.

        Raises:
            DecodeError: If the binary data is not a valid protobuf message.
        """
        pb_obj = cls._pb_class()
        pb_obj.ParseFromString(data)
        return cls.from_pb2(pb_obj)

    def to_dict(
        self,
        *,
        always_print_fields_with_no_presence: bool = False,
        preserving_proto_field_name: bool = False,
    ) -> dict[str, Any]:
        """Convert message to dictionary.

        Args:
            always_print_fields_with_no_presence: If True, include fields that have
                default/zero values (e.g., empty strings, 0, False, empty lists).
            preserving_proto_field_name: If True, use original proto field names
                (snake_case) instead of JSON-style camelCase names.

        Returns:
            Dictionary representation of the message.
        """
        return MessageToDict(
            self._pb,
            always_print_fields_with_no_presence=always_print_fields_with_no_presence,
            preserving_proto_field_name=preserving_proto_field_name,
        )

    @classmethod
    def from_dict(
        cls: type[Self], data: dict[str, Any], *, ignore_unknown_fields: bool = False
    ) -> Self:
        """Create message from dictionary.

        Args:
            data: Dictionary containing message data. Keys can be either camelCase
                (JSON-style) or snake_case (proto field names).
            ignore_unknown_fields: If True, ignore dictionary keys that don't
                correspond to known proto fields. If False, raise ParseError on
                unknown fields.

        Returns:
            New message instance populated with dictionary data.

        Raises:
            ParseError: If ignore_unknown_fields=False and dictionary contains
                unknown field names.
        """
        pb_obj = ParseDict(
            data, cls._pb_class(), ignore_unknown_fields=ignore_unknown_fields
        )
        return cls.from_pb2(pb_obj)

    def to_json(
        self,
        *,
        always_print_fields_with_no_presence: bool = False,
        preserving_proto_field_name: bool = False,
        indent: int = 2,
        sort_keys: bool = False,
    ) -> str:
        """Convert message to JSON string.

        Args:
            always_print_fields_with_no_presence: If True, include fields that have
                default/zero values (e.g., empty strings, 0, False, empty lists).
            preserving_proto_field_name: If True, use original proto field names
                (snake_case) instead of JSON-style camelCase names.
            indent: Number of spaces to use for indentation. Use 0 for compact output.
                Defaults to 2 for readable formatting.
            sort_keys: If True, output JSON object keys in sorted order.

        Returns:
            JSON string representation of the message.
        """
        return MessageToJson(
            self._pb,
            preserving_proto_field_name=preserving_proto_field_name,
            indent=indent,
            sort_keys=sort_keys,
            always_print_fields_with_no_presence=always_print_fields_with_no_presence,
        )

    @classmethod
    def from_json(
        cls: type[Self], json_str: str, *, ignore_unknown_fields: bool = False
    ) -> Self:
        """Create message from JSON string.

        Args:
            json_str: JSON string containing message data. Field names can be either
                camelCase (JSON-style) or snake_case (proto field names).
            ignore_unknown_fields: If True, ignore JSON fields that don't correspond
                to known proto fields. If False, raise ParseError on unknown fields.

        Returns:
            New message instance populated with JSON data.

        Raises:
            ParseError: If ignore_unknown_fields=False and JSON contains unknown
                field names, or if JSON is malformed.
        """
        pb_obj = cls._pb_class()
        Parse(json_str, pb_obj, ignore_unknown_fields=ignore_unknown_fields)
        return cls.from_pb2(pb_obj)
