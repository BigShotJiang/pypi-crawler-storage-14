from collections.abc import ItemsView, Iterator, KeysView, MutableMapping, ValuesView
from typing import Any, TypeVar, overload

from .wrappers import WrapperProtocol

K = TypeVar("K")
V = TypeVar("V")
_T = TypeVar("_T")

_MISSING = object()


class MapField(MutableMapping[K, V]):
    """Proxy for protobuf map fields with automatic wrapper conversion."""

    def __init__(
        self,
        pb_map: Any,
        key_wrapper: WrapperProtocol,
        value_wrapper: WrapperProtocol,
    ) -> None:
        """Initialize proxy with pb2 map field and wrapper classes.

        Args:
            pb_map: The protobuf map field to proxy
            key_wrapper: Class to convert keys (or NoWrapper for primitives)
            value_wrapper: Class to convert values (or NoWrapper for primitives)
        """
        self._pb_map = pb_map
        self._key_wrapper = key_wrapper
        self._value_wrapper = value_wrapper

    def __setitem__(self, key: K, value: V) -> None:
        pb_key = self._key_wrapper.to_pb2(key)
        pb_value = self._value_wrapper.to_pb2(value)
        # For message fields, protobuf maps need special handling
        if hasattr(pb_value, "CopyFrom"):
            # It's a message, use CopyFrom to set the map entry
            self._pb_map[pb_key].CopyFrom(pb_value)
        else:
            # Primitive or enum value, direct assignment
            self._pb_map[pb_key] = pb_value

    def __delitem__(self, key: K) -> None:
        pb_key = self._key_wrapper.to_pb2(key)
        del self._pb_map[pb_key]

    def __iter__(self) -> Iterator[K]:
        for pb_key in self._pb_map:
            yield self._key_wrapper.from_pb2(pb_key)

    def __len__(self) -> int:
        return len(self._pb_map)

    def __contains__(self, key: object) -> bool:
        """Check if key exists in map."""
        try:
            pb_key = self._key_wrapper.to_pb2(key)
            return pb_key in self._pb_map
        except (TypeError, ValueError):
            return False

    def __getitem__(self, key: K) -> V:
        pb_key = self._key_wrapper.to_pb2(key)
        if pb_key not in self._pb_map:
            raise KeyError(key)
        pb_value = self._pb_map[pb_key]
        return self._value_wrapper.from_pb2(pb_value)

    def keys(self) -> KeysView[K]:
        return KeysView(self)

    def values(self) -> ValuesView[V]:
        return ValuesView(self)

    def items(self) -> ItemsView[K, V]:
        return ItemsView(self)

    @overload
    def get(self, key: K, /) -> V | None: ...

    @overload
    def get(self, key: K, /, default: V | _T) -> V | _T: ...

    def get(self, key: K, default: Any = None) -> Any:
        """Get value with default if key doesn't exist."""
        pb_key = self._key_wrapper.to_pb2(key)
        if pb_key in self._pb_map:
            pb_value = self._pb_map[pb_key]
            return self._value_wrapper.from_pb2(pb_value)
        return default

    @overload
    def pop(self, key: K, /) -> V: ...

    @overload
    def pop(self, key: K, /, default: V | _T) -> V | _T: ...

    def pop(self, key: K, default: Any = _MISSING) -> Any:
        try:
            value = self[key]
            del self[key]
            return value
        except KeyError:
            if default is not _MISSING:
                return default
            raise

    def popitem(self) -> tuple[K, V]:
        """Remove and return an arbitrary (key, value) pair."""
        if not self._pb_map:
            raise KeyError("popitem(): dictionary is empty")

        # Get first key from pb2 map
        pb_key = next(iter(self._pb_map))
        pb_value = self._pb_map[pb_key]
        del self._pb_map[pb_key]

        return (
            self._key_wrapper.from_pb2(pb_key),
            self._value_wrapper.from_pb2(pb_value),
        )

    def clear(self) -> None:
        self._pb_map.clear()

    def update(self, *args: Any, **kwargs: Any) -> None:
        """Update map with items from another mapping or iterable."""
        if args:
            other = args[0]
            if hasattr(other, "items"):
                for key, value in other.items():
                    self[key] = value
            else:
                for key, value in other:
                    self[key] = value

        for k, v in kwargs.items():
            # FIXME this shortcut looks dangerous - find a proper and type
            # safe way to implement update
            self[k] = v  # type: ignore[index]

    @overload
    def setdefault(self, key: K, default: None = None, /) -> V | None: ...

    @overload
    def setdefault(self, key: K, default: V, /) -> V: ...

    # FIXME this shouldn't be allowed to be passed None when the value
    # type doesn't include None
    def setdefault(self, key: K, default: Any = None) -> Any:
        """Insert key with default value if key doesn't exist, return value."""
        if key in self:
            return self[key]
        self[key] = default
        return default

    def __repr__(self) -> str:
        items = [f"{key!r}: {value!r}" for key, value in self.items()]
        return "{" + ", ".join(items) + "}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, dict | MapField):
            return False
        return dict(self) == dict(other)
