from dataclasses import dataclass


@dataclass
class ImportStatements:
    """Represents all imports needed for the generated file.

    The import types are separated to allow semantic grouping and template control:

    - imports: Standard Python modules (e.g., "api_pb2")
    - from_imports: Standard Python packages (e.g., "typing" -> ["Literal"])
    - proto_dependencies: Other generated pretty modules (e.g., "types_pretty")

    This separation allows templates to control import ordering, typically:
    1. from __future__ imports
    2. Generated pretty modules (proto_dependencies)
    3. Standard Python modules (imports)
    4. From imports (from_imports)
    """

    imports: set[str]  # "import module" - standard Python modules
    from_imports: dict[str, set[str]]  # "from module import name" - standard packages
    proto_dependencies: set[str]  # "import other_pretty_module" - generated modules

    def __init__(self) -> None:
        self.imports = set()
        self.from_imports = {}
        self.proto_dependencies = set()

    def add_import(self, module: str) -> None:
        """Add a direct import statement."""
        self.imports.add(module)

    def add_from_import(self, module: str, name: str) -> None:
        """Add a from import statement."""
        self.from_imports.setdefault(module, set()).add(name)

    def add_proto_dependency(self, pretty_module: str) -> None:
        """Add import for another generated pretty module."""
        self.proto_dependencies.add(pretty_module)

    def merge(self, other: "ImportStatements") -> None:
        """Merge another ImportStatements object into this one."""
        # Merge imports
        self.imports.update(other.imports)

        # Merge from_imports
        for module, names in other.from_imports.items():
            self.from_imports.setdefault(module, set()).update(names)

        # Merge proto_dependencies
        self.proto_dependencies.update(other.proto_dependencies)
