from pathlib import Path

from jinja2 import Environment, FileSystemLoader


def snake_to_camel_case(name: str) -> str:
    """Convert snake_case to CamelCase."""
    return "".join(word.capitalize() for word in name.split("_"))


def escape_quotes(text: str) -> str:
    """Escape double quotes in text for use in Python docstrings."""
    return text.replace('"', '\\"')


# Get the templates directory
TEMPLATES_DIR = Path(__file__).parent / "templates"

# Create Jinja2 environment
env = Environment(loader=FileSystemLoader(TEMPLATES_DIR))
env.globals["snake_to_camel_case"] = snake_to_camel_case
env.filters["escape_quotes"] = escape_quotes

# Load templates
PRETTY_FILE_TEMPLATE = env.get_template("pretty_file.j2")
ENUM_TEMPLATE = env.get_template("enum.j2")
