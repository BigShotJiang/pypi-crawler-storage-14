from google.protobuf.descriptor_pb2 import FileDescriptorProto
from google.protobuf.internal.containers import RepeatedCompositeFieldContainer

from .comment_extractor import CommentExtractor
from .dependency_resolver import DependencyResolver
from .import_statements import ImportStatements
from .pretty_enum import PrettyEnum
from .pretty_message import PrettyMessage


class PrettyFile:
    def __init__(
        self,
        proto_file: FileDescriptorProto,
        dependency_resolver: DependencyResolver,
        strip_enum_prefix: bool = True,
    ) -> None:
        self._proto_file = proto_file
        self._comment_extractor = CommentExtractor(proto_file)
        self._dependency_resolver = dependency_resolver
        self._strip_enum_prefix = strip_enum_prefix

    def name(self) -> str:
        """The original proto file name."""
        return self._proto_file.name

    def pb2_module_name(self) -> str:
        """The name of the generated _pb2 module."""
        module_name = self._proto_file.name.removesuffix(".proto") + "_pb2"
        # Convert directory separators to Python module notation
        return module_name.replace("/", ".")

    def enum_types(self) -> RepeatedCompositeFieldContainer:
        """The enum types defined in this file."""
        return self._proto_file.enum_type

    def message_types(self) -> RepeatedCompositeFieldContainer:
        """The message types defined in this file."""
        return self._proto_file.message_type

    def pretty_messages(self) -> list[PrettyMessage]:
        """The message types as PrettyMessage objects."""
        return [
            PrettyMessage(
                message_desc,
                self.pb2_module_name(),
                "",
                self._comment_extractor,
                (4, i),
                self._proto_file.name,
                self._dependency_resolver,
                self._strip_enum_prefix,
            )
            for i, message_desc in enumerate(self._proto_file.message_type)
        ]

    def pretty_enums(self) -> list[PrettyEnum]:
        """The enum types as PrettyEnum objects."""
        pretty_enums = []
        for i, enum_desc in enumerate(self._proto_file.enum_type):
            enum_path = (5, i)
            enum_comment, value_comments = self._comment_extractor.extract_enum_data(
                enum_desc, enum_path
            )
            pretty_enums.append(
                PrettyEnum(
                    enum_desc, enum_comment, value_comments, self._strip_enum_prefix
                )
            )
        return pretty_enums

    def get_imports(self) -> ImportStatements:
        """Get all imports needed for this file by collecting from all components."""
        imports = ImportStatements()

        # Add proto dependencies (excluding Google well-known types)
        for dep in self._dependency_resolver.get_dependencies(self._proto_file.name):
            # Skip imports for Google well-known types since we map them to native
            # Python types
            if not dep.imported_file.startswith("google/protobuf/"):
                imports.add_proto_dependency(dep.pretty_module)

        # Collect imports from all messages (includes fields and nested components)
        for message in self.pretty_messages():
            imports.merge(message.get_imports())

        # Collect imports from top-level enums
        for enum in self.pretty_enums():
            imports.merge(enum.get_imports())

        return imports
