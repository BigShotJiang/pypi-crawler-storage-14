# Primitive Python types that don't require special wrapper classes
PRIMITIVE_TYPES = ["str", "int", "bool", "float", "bytes"]
