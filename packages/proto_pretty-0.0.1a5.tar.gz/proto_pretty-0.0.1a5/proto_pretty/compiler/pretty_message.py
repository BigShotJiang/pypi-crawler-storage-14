from google.protobuf.descriptor_pb2 import DescriptorProto
from google.protobuf.internal.containers import RepeatedCompositeFieldContainer

from .comment_extractor import CommentExtractor
from .dependency_resolver import DependencyResolver
from .import_statements import ImportStatements
from .pretty_enum import PrettyEnum
from .pretty_field import PrettyField


class PrettyMessage:
    """Represents a protobuf message and its generated Python interface."""

    def __init__(
        self,
        message_desc: DescriptorProto,
        pb2_module: str,
        parent_path: str,
        comment_extractor: CommentExtractor,
        path: tuple[int, ...],
        current_file: str,
        dependency_resolver: DependencyResolver,
        strip_enum_prefix: bool = True,
    ) -> None:
        self._message_desc = message_desc
        self._pb2_module = pb2_module
        self._parent_path = parent_path
        self._comment_extractor = comment_extractor
        self._path = path
        self._current_file = current_file
        self._dependency_resolver = dependency_resolver
        self._strip_enum_prefix = strip_enum_prefix

    def name(self) -> str:
        """The message name."""
        return self._message_desc.name

    def comment(self) -> str:
        """Get the comment for this message."""
        return self._comment_extractor._location_map.get(self._path, "")

    def pb_class_path(self) -> str:
        """The full Python path to the pb2 class."""
        if self._parent_path:
            return f"{self._pb2_module}.{self._parent_path}{self._message_desc.name}"
        else:
            return f"{self._pb2_module}.{self._message_desc.name}"

    def return_type_annotation(self) -> str:
        """The return type annotation for factory methods."""
        if self._parent_path:
            return f'"{self._parent_path.rstrip(".")}.{self._message_desc.name}"'
        else:
            return f'"{self._message_desc.name}"'

    def pretty_fields(self) -> list[PrettyField]:
        """The fields as PrettyField objects."""
        field_comments = self._comment_extractor.extract_field_comments(
            self._message_desc, self._path
        )
        return [
            PrettyField(
                field_desc,
                self._message_desc,
                field_comments[i],
                self._current_file,
                self._dependency_resolver,
            )
            for i, field_desc in enumerate(self._message_desc.field)
        ]

    def nested_enums(self) -> RepeatedCompositeFieldContainer:
        """The nested enum descriptors."""
        return self._message_desc.enum_type

    def pretty_nested_enums(self) -> list[PrettyEnum]:
        """The nested enum descriptors as PrettyEnum objects."""
        pretty_enums = []
        for i, enum_desc in enumerate(self._message_desc.enum_type):
            enum_path = self._path + (4, i)
            enum_comment, value_comments = self._comment_extractor.extract_enum_data(
                enum_desc, enum_path
            )
            pretty_enums.append(
                PrettyEnum(
                    enum_desc, enum_comment, value_comments, self._strip_enum_prefix
                )
            )
        return pretty_enums

    def nested_messages(self) -> list["PrettyMessage"]:
        """The nested message descriptors as PrettyMessage objects."""
        new_parent_path = (
            f"{self._parent_path}{self._message_desc.name}."
            if self._parent_path
            else f"{self._message_desc.name}."
        )
        return [
            PrettyMessage(
                nested_message,
                self._pb2_module,
                new_parent_path,
                self._comment_extractor,
                self._path + (3, i),
                self._current_file,
                self._dependency_resolver,
                self._strip_enum_prefix,
            )
            for i, nested_message in enumerate(self._message_desc.nested_type)
        ]

    def has_enums(self) -> bool:
        """Check if this message has any enums (direct or nested)."""
        # Check for direct nested enums
        if self._message_desc.enum_type:
            return True

        # Check nested messages recursively
        for nested_message in self.nested_messages():
            if nested_message.has_enums():
                return True

        return False

    def oneof_groups(self) -> dict[str, list[PrettyField]]:
        """Get oneof groups as a mapping from oneof name to list of fields.

        Excludes synthetic oneofs (proto3 optional fields) which are implemented
        as single-field oneofs internally but should not generate oneof union classes.
        """
        groups: dict[str, list[PrettyField]] = {}
        for field in self.pretty_fields():
            if field.is_oneof() and not field.is_optional():
                oneof_name = field.oneof_name()
                if oneof_name not in groups:
                    groups[oneof_name] = []
                groups[oneof_name].append(field)
        return groups

    def presence_field_names(self) -> list[str]:
        """Get list of field names that support presence tracking
        (for has_field Literal type)."""
        field_names = []

        # Add individual fields that have presence
        for field in self.pretty_fields():
            if field.has_presence():
                field_names.append(field.name())

        # Add oneof group names
        field_names.extend(self.oneof_groups().keys())

        return field_names

    def oneof_variant_types(self, oneof_name: str) -> list[str]:
        """Get the variant type names for a oneof group."""
        from .templates import snake_to_camel_case

        oneof_groups = self.oneof_groups()
        if oneof_name not in oneof_groups:
            return []

        # Use fully qualified name to avoid conflicts with top-level message types
        if self._parent_path:
            # For nested messages, include the full path
            message_qualifier = f"{self._parent_path.rstrip('.')}.{self.name()}"
        else:
            # For top-level messages, just use the message name
            message_qualifier = self.name()

        variant_types = []
        for field in oneof_groups[oneof_name]:
            field_name = field.name()
            variant_types.append(
                f"{message_qualifier}.{snake_to_camel_case(oneof_name)}.{snake_to_camel_case(field_name)}"
            )
        return variant_types

    def get_imports(self) -> ImportStatements:
        """Get imports required for this message and all its components."""
        imports = ImportStatements()

        # Add pb2 module import for the underlying protobuf message
        imports.add_import(self._pb2_module)

        # Add MessageBase import for inheritance
        imports.add_from_import("proto_pretty.message_base", "MessageBase")

        # Add imports for presence tracking if needed
        if self.presence_field_names():
            imports.add_from_import("typing", "Literal")

        # Add typing imports for bracket access methods - always generated
        imports.add_from_import("typing", "Any")
        if self.pretty_fields():
            imports.add_from_import("typing", "Literal")
            if len(self.pretty_fields()) > 1:
                imports.add_from_import("typing", "overload")

        # Get imports from all fields
        for field in self.pretty_fields():
            imports.merge(field.get_imports())

        # Get imports from nested enums
        for enum in self.pretty_nested_enums():
            imports.merge(enum.get_imports())

        # Get imports from nested messages
        for nested_message in self.nested_messages():
            imports.merge(nested_message.get_imports())

        return imports
