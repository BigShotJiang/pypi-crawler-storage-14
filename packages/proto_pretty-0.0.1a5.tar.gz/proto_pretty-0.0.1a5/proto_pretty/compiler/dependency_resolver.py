from dataclasses import dataclass

from google.protobuf.descriptor_pb2 import FileDescriptorProto


@dataclass
class ProtoDependency:
    """Represents a dependency between proto files."""

    imported_file: str  # "types.proto"
    pretty_module: str  # "types_pretty"


class DependencyResolver:
    """Resolves dependencies between proto files."""

    def __init__(self, proto_files: list[FileDescriptorProto]) -> None:
        self.files: dict[str, FileDescriptorProto] = {f.name: f for f in proto_files}
        self.dependencies = self._build_dependency_graph()

    def _build_dependency_graph(self) -> dict[str, list[ProtoDependency]]:
        """Build dependency graph from proto files."""
        graph = {}
        for file_desc in self.files.values():
            deps = []
            for imported_file in file_desc.dependency:
                if imported_file in self.files:
                    pretty_module = self._proto_to_pretty_module(imported_file)
                    deps.append(ProtoDependency(imported_file, pretty_module))
            graph[file_desc.name] = deps
        return graph

    def get_dependencies(self, proto_file: str) -> list[ProtoDependency]:
        """Get dependencies for a proto file."""
        return self.dependencies.get(proto_file, [])

    def _proto_to_pretty_module(self, proto_file: str) -> str:
        """Convert proto filename to pretty module name.

        Examples:
            "user.proto" -> "user_pretty"
            "models/user.proto" -> "models.user_pretty"
            "services/auth.proto" -> "services.auth_pretty"
        """
        if proto_file.endswith(".proto"):
            module_path = proto_file[:-6] + "_pretty"
        else:
            module_path = proto_file + "_pretty"

        # Convert directory separators to Python module notation
        return module_path.replace("/", ".")
