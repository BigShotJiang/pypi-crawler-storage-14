"""PrettyField domain object for pretty protobuf code generation."""

from google.protobuf.descriptor_pb2 import DescriptorProto, FieldDescriptorProto

from .constants import PRIMITIVE_TYPES
from .dependency_resolver import DependencyResolver
from .import_statements import ImportStatements
from .wkt_mapping import (
    get_wkt_import_modules,
    get_wkt_python_type,
    get_wkt_wrapper_class,
    is_well_known_type,
)


class PrettyField:
    """Represents a protobuf field and its generated Python interface."""

    def __init__(
        self,
        field_desc: FieldDescriptorProto,
        message_desc: DescriptorProto,
        comment: str,
        current_file: str,
        dependency_resolver: DependencyResolver,
    ) -> None:
        self._field_desc = field_desc
        self._message_desc = message_desc
        self._comment = comment
        self._current_file = current_file
        self._dependency_resolver = dependency_resolver

    def name(self) -> str:
        return self._field_desc.name

    def comment(self) -> str:
        """Get the comment for this field."""
        return self._comment

    def type_signature(self, nullable: bool | None = None) -> str:
        """Get Python type signature for this protobuf field.

        Args:
            nullable: If True, adds | None to all fields. If False, returns
                     base type only.
                     If None (default), adds | None only for optional/oneof fields.
        """
        field_type = self._field_desc.type
        type_name = self._field_desc.type_name

        if (
            field_type == FieldDescriptorProto.TYPE_MESSAGE
            or field_type == FieldDescriptorProto.TYPE_ENUM
        ):
            base_type = self._resolve_nested_type_name(type_name)
        else:
            type_map: dict[int, str] = {
                FieldDescriptorProto.TYPE_BOOL: "bool",
                FieldDescriptorProto.TYPE_BYTES: "bytes",
                FieldDescriptorProto.TYPE_DOUBLE: "float",
                FieldDescriptorProto.TYPE_FIXED32: "int",
                FieldDescriptorProto.TYPE_FIXED64: "int",
                FieldDescriptorProto.TYPE_FLOAT: "float",
                FieldDescriptorProto.TYPE_INT32: "int",
                FieldDescriptorProto.TYPE_INT64: "int",
                FieldDescriptorProto.TYPE_SFIXED32: "int",
                FieldDescriptorProto.TYPE_SFIXED64: "int",
                FieldDescriptorProto.TYPE_SINT32: "int",
                FieldDescriptorProto.TYPE_SINT64: "int",
                FieldDescriptorProto.TYPE_STRING: "str",
                FieldDescriptorProto.TYPE_UINT32: "int",
                FieldDescriptorProto.TYPE_UINT64: "int",
            }
            base_type = type_map[field_type]

        # Handle map fields
        if self.is_map():
            key_type = self.map_key_type()
            value_type = self.map_value_type()
            dict_type = f"dict[{key_type}, {value_type}]"
            if nullable is True:
                return f"{dict_type} | None"
            return dict_type

        # Handle repeated fields
        if self.is_repeated():
            list_type = f"list[{base_type}]"
            if nullable is True:
                return f"{list_type} | None"
            return list_type

        # Handle nullable logic for non-repeated fields
        if nullable is True:
            # Explicitly requested nullable for all fields (e.g., constructors)
            return f"{base_type} | None"
        elif nullable is False:
            # Explicitly requested non-nullable (e.g., for class names in method calls)
            return base_type
        else:
            # Default behavior: nullable only for optional/oneof fields
            if self.is_optional() or self.is_oneof():
                return f"{base_type} | None"
            return base_type

    def _resolve_nested_type_name(self, type_name: str) -> str:
        """Resolve type name to full nested path without leading dots.

        Examples:
            ".mypackage.Container.Section" -> "mypackage.Container.Section"
            ".mypackage.Status" -> "mypackage.Status"
            "Message" -> "Message"
            ".types.User" -> "types_pretty.User" # Cross file
        """
        if not type_name:
            return ""

        # Check for Google well-known types first
        if is_well_known_type(type_name):
            return get_wkt_python_type(type_name)

        # Check if this is a cross-file reference
        if type_name.startswith("."):
            parts = type_name.strip(".").split(".")
            if len(parts) >= 1:
                # Find which file defines this type
                defining_file = self._find_defining_file(type_name)
                if defining_file and defining_file != self._current_file:
                    # This is a cross-file reference
                    pretty_module = self._dependency_resolver._proto_to_pretty_module(
                        defining_file
                    )
                    # Use the simple class name but qualify with module
                    class_name = parts[-1]  # Last part is the class name
                    return f"{pretty_module}.{class_name}"

        # Handle local types (same file)
        if type_name and "." in type_name:
            parts = type_name.strip(".").split(".")
            return ".".join(parts)
        return type_name.split(".")[-1]

    def _find_defining_file(self, type_name: str) -> str | None:
        """Find which proto file defines the given type."""
        # Try to find the file by checking all files
        for file_name, file_desc in self._dependency_resolver.files.items():
            # Check if this file has a message with this name
            for msg in file_desc.message_type:
                # For files without packages, the full name is just .MessageName
                full_name = (
                    f".{file_desc.package}.{msg.name}"
                    if file_desc.package
                    else f".{msg.name}"
                )
                if full_name == type_name:
                    return file_name

            # Check enums too
            for enum in file_desc.enum_type:
                full_name = (
                    f".{file_desc.package}.{enum.name}"
                    if file_desc.package
                    else f".{enum.name}"
                )
                if full_name == type_name:
                    return file_name

        return None

    def is_message(self) -> bool:
        return self._field_desc.type == FieldDescriptorProto.TYPE_MESSAGE

    def is_enum(self) -> bool:
        return self._field_desc.type == FieldDescriptorProto.TYPE_ENUM

    def is_optional(self) -> bool:
        """Check if this field is optional (explicitly marked with
        'optional' keyword)."""
        return self._field_desc.proto3_optional

    def is_oneof(self) -> bool:
        """Check if this field is part of a oneof group."""
        return self._field_desc.HasField("oneof_index")

    def is_repeated(self) -> bool:
        """Check if this field is repeated (array/list)."""
        return (
            self._field_desc.label == FieldDescriptorProto.LABEL_REPEATED
            and not self.is_map()
        )

    def is_map(self) -> bool:
        """Check if this field is a map (key-value pairs).
        Note that maps are implemented as repeated instances of messages
        named `<field_name>Entry`
        which has the `map_entry` option set to `true`.
        """
        if self._field_desc.label != FieldDescriptorProto.LABEL_REPEATED:
            return False

        if self._field_desc.type != FieldDescriptorProto.TYPE_MESSAGE:
            return False

        # Find the nested message descriptor for the Entry type
        type_name = self._field_desc.type_name
        entry_name = type_name.split(".")[-1]

        for nested_type in self._message_desc.nested_type:
            if nested_type.name == entry_name:
                # Check if this is a map entry using the map_entry option
                return nested_type.options.map_entry

        return False

    def has_presence(self) -> bool:
        """
        Check if this field supports presence tracking
        (can be used with HasField).
        """
        if self.is_repeated() or self.is_map():
            return False

        if self.is_optional():
            return True

        if self.is_oneof():
            return True

        if self.is_message():
            return True

        # Regular primitive fields (string, int32, etc.) without optional
        # don't have presence
        return False

    def oneof_name(self) -> str:
        """Get the name of the oneof group this field belongs to."""
        if not self.is_oneof():
            raise ValueError(f"Field '{self.name()}' is not part of a oneof group")

        oneof_index = self._field_desc.oneof_index
        if oneof_index >= len(self._message_desc.oneof_decl):
            raise ValueError(
                f"Invalid oneof index {oneof_index} for field '{self.name()}'"
            )

        return self._message_desc.oneof_decl[oneof_index].name

    def full_class_path(self) -> list[str]:
        """Get the full class path for type resolution.

        Examples:
            ".mypackage.Container.Section" -> ["mypackage", "Container", "Section"]
            ".mypackage.Status" -> ["mypackage", "Status"]
            "Message" -> ["Message"]
        """
        if self._field_desc.type_name:
            return self._field_desc.type_name.strip(".").split(".")
        else:
            return [self.type_signature()]

    def pb_field_path(self) -> str:
        """Get the path to access this field on the protobuf object."""
        return f"self._pb.{self.name()}"

    def element_type(self) -> str:
        """Get the element type for repeated fields (without list wrapper)."""
        field_type = self._field_desc.type
        type_name = self._field_desc.type_name

        if (
            field_type == FieldDescriptorProto.TYPE_MESSAGE
            or field_type == FieldDescriptorProto.TYPE_ENUM
        ):
            return self._resolve_nested_type_name(type_name)
        else:
            type_map: dict[int, str] = {
                FieldDescriptorProto.TYPE_DOUBLE: "float",
                FieldDescriptorProto.TYPE_FLOAT: "float",
                FieldDescriptorProto.TYPE_INT64: "int",
                FieldDescriptorProto.TYPE_UINT64: "int",
                FieldDescriptorProto.TYPE_INT32: "int",
                FieldDescriptorProto.TYPE_FIXED64: "int",
                FieldDescriptorProto.TYPE_FIXED32: "int",
                FieldDescriptorProto.TYPE_BOOL: "bool",
                FieldDescriptorProto.TYPE_STRING: "str",
                FieldDescriptorProto.TYPE_BYTES: "bytes",
                FieldDescriptorProto.TYPE_UINT32: "int",
                FieldDescriptorProto.TYPE_SFIXED32: "int",
                FieldDescriptorProto.TYPE_SFIXED64: "int",
                FieldDescriptorProto.TYPE_SINT32: "int",
                FieldDescriptorProto.TYPE_SINT64: "int",
            }
            return type_map[field_type]

    def map_key_type(self) -> str:
        """Get the key type for map fields."""
        if not self.is_map():
            raise ValueError(f"Field '{self.name()}' is not a map field")

        try:
            key_field = next(
                field
                for field in self._get_map_entry_type().field
                if field.name == "key"
            )

        except StopIteration:
            raise ValueError(
                f"Map Entry type missing 'key' field for '{self.name()}'"
            ) from None

        return self._field_type_to_python_type(key_field.type, key_field.type_name)

    def map_value_type(self) -> str:
        """Get the value type for map fields."""
        if not self.is_map():
            raise ValueError(f"Field '{self.name()}' is not a map field")

        try:
            value_field = next(
                field
                for field in self._get_map_entry_type().field
                if field.name == "value"
            )
        except StopIteration:
            raise ValueError(
                f"Map Entry type missing 'value' field for '{self.name()}'"
            ) from None

        return self._field_type_to_python_type(value_field.type, value_field.type_name)

    def _get_map_entry_type(self) -> DescriptorProto:
        """Get the Entry message descriptor for a map field."""
        type_name = self._field_desc.type_name
        entry_name = type_name.split(".")[-1]

        for nested_type in self._message_desc.nested_type:
            if nested_type.name == entry_name:
                return nested_type

        raise ValueError(f"Could not find Entry type for map field '{self.name()}'")

    def _field_type_to_python_type(self, field_type: int, type_name: str) -> str:
        """Convert protobuf field type to Python type string."""
        if (
            field_type == FieldDescriptorProto.TYPE_MESSAGE
            or field_type == FieldDescriptorProto.TYPE_ENUM
        ):
            return self._resolve_nested_type_name(type_name)
        else:
            type_map: dict[int, str] = {
                FieldDescriptorProto.TYPE_DOUBLE: "float",
                FieldDescriptorProto.TYPE_FLOAT: "float",
                FieldDescriptorProto.TYPE_INT64: "int",
                FieldDescriptorProto.TYPE_UINT64: "int",
                FieldDescriptorProto.TYPE_INT32: "int",
                FieldDescriptorProto.TYPE_FIXED64: "int",
                FieldDescriptorProto.TYPE_FIXED32: "int",
                FieldDescriptorProto.TYPE_BOOL: "bool",
                FieldDescriptorProto.TYPE_STRING: "str",
                FieldDescriptorProto.TYPE_BYTES: "bytes",
                FieldDescriptorProto.TYPE_UINT32: "int",
                FieldDescriptorProto.TYPE_SFIXED32: "int",
                FieldDescriptorProto.TYPE_SFIXED64: "int",
                FieldDescriptorProto.TYPE_SINT32: "int",
                FieldDescriptorProto.TYPE_SINT64: "int",
            }
            return type_map.get(field_type, "str")

    def _get_wrapper_for_field_type(self, field_type: int, python_type: str) -> str:
        """Get the wrapper class name for any field type (used by repeated
        and map fields)."""
        # Check for well-known types first
        if is_well_known_type(self._field_desc.type_name):
            wrapper_class = get_wkt_wrapper_class(self._field_desc.type_name)
            return f"{wrapper_class}()"

        # Primitive types use NoWrapper
        if python_type in PRIMITIVE_TYPES:
            return "NoWrapper()"

        # Enum types use EnumWrapper
        if field_type == FieldDescriptorProto.TYPE_ENUM:
            return f"EnumWrapper({python_type})"

        # Message types use the class directly
        return python_type

    def _get_wrapper_for_map_field(self, field_name: str, python_type: str) -> str:
        if not self.is_map():
            raise ValueError(f"Field '{self.name()}' is not a map field")

        # Find the field type from the map entry
        entry_type = self._get_map_entry_type()
        if entry_type:
            field = next((f for f in entry_type.field if f.name == field_name), None)
            if field:
                return self._get_wrapper_for_field_type(field.type, python_type)

        # Fallback - assume it's a message type
        return python_type

    def map_key_wrapper(self) -> str:
        return self._get_wrapper_for_map_field("key", self.map_key_type())

    def map_value_wrapper(self) -> str:
        return self._get_wrapper_for_map_field("value", self.map_value_type())

    def repeated_field_wrapper(self) -> str:
        """Get the wrapper class name for repeated field elements."""
        if not self.is_repeated():
            raise ValueError(f"Field '{self.name()}' is not a repeated field")

        return self._get_wrapper_for_field_type(
            self._field_desc.type, self.element_type()
        )

    def is_wkt_field(self) -> bool:
        """Check if this field is a well-known type."""
        return is_well_known_type(self._field_desc.type_name)

    def wkt_wrapper_class(self) -> str:
        """Get the wrapper class name for this WKT field."""
        if not self.is_wkt_field():
            raise ValueError(f"Field {self.name()} is not a well-known type")
        return get_wkt_wrapper_class(self._field_desc.type_name)

    def get_imports(self) -> ImportStatements:
        """Get imports required for this field."""
        imports = ImportStatements()

        # Add imports for well-known types
        if self.is_wkt_field():
            # Add any required module imports
            for module in get_wkt_import_modules(self._field_desc.type_name):
                imports.add_import(module)
            # Add wrapper class import
            wrapper_class = self.wkt_wrapper_class()
            imports.add_from_import("proto_pretty.wrappers", wrapper_class)

        # Add imports based on field type
        if self.is_repeated():
            imports.add_from_import("proto_pretty.repeated_field", "RepeatedField")

            # Add wrapper imports for repeated fields
            if self.element_type() in PRIMITIVE_TYPES and not self.is_wkt_field():
                imports.add_from_import("proto_pretty.wrappers", "NoWrapper")
            elif self.is_enum():
                imports.add_from_import("proto_pretty.wrappers", "EnumWrapper")

        elif self.is_map():
            imports.add_from_import("proto_pretty.map_field", "MapField")

            # Add wrapper imports for map fields
            key_type = self.map_key_type()
            value_type = self.map_value_type()
            if key_type in PRIMITIVE_TYPES or value_type in PRIMITIVE_TYPES:
                imports.add_from_import("proto_pretty.wrappers", "NoWrapper")
            if self._field_desc.type == FieldDescriptorProto.TYPE_MESSAGE:
                # Check if map values are enums
                entry_type = self._get_map_entry_type()
                if entry_type:
                    for entry_field in entry_type.field:
                        if entry_field.type == FieldDescriptorProto.TYPE_ENUM:
                            imports.add_from_import(
                                "proto_pretty.wrappers", "EnumWrapper"
                            )
                            break

        return imports
