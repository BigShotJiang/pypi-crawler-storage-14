"""PrettyEnum domain object for pretty protobuf code generation."""

import re

from google.protobuf.descriptor_pb2 import EnumDescriptorProto

from .import_statements import ImportStatements
from .templates import ENUM_TEMPLATE


class PrettyEnum:
    """Represents a protobuf enum and its generated Python interface."""

    def __init__(
        self,
        enum_desc: EnumDescriptorProto,
        comment: str,
        value_comments: list[str],
        strip_prefix: bool = True,
    ) -> None:
        self._enum_desc = enum_desc
        self._comment = comment
        self._value_comments = value_comments
        self._strip_prefix = strip_prefix

    def name(self) -> str:
        """The enum name."""
        return self._enum_desc.name

    def comment(self) -> str:
        """Get the comment for this enum."""
        return self._comment

    def values(self) -> list[dict]:
        """The processed enum values."""
        values = []
        stripped_names = (
            self._calculate_stripped_names() if self._strip_prefix else None
        )

        for i, value in enumerate(self._enum_desc.value):
            value_comment = (
                self._value_comments[i] if i < len(self._value_comments) else ""
            )
            name = stripped_names[i] if stripped_names else value.name
            values.append(
                {
                    "name": name,
                    "number": value.number,
                    "comment": value_comment,
                }
            )
        return values

    def get_imports(self) -> ImportStatements:
        """Get imports required for this enum."""
        imports = ImportStatements()
        imports.add_from_import("enum", "Enum")
        return imports

    def _calculate_stripped_names(self) -> list[str] | None:
        """Strip enum prefix if ALL values have it AND result in valid identifiers."""
        # Convert CamelCase enum name to SCREAMING_SNAKE_CASE for prefix matching
        # e.g., "NestedStatus" -> "NESTED_STATUS_"
        enum_name = self._enum_desc.name

        snake_case = re.sub("([a-z0-9])([A-Z])", r"\1_\2", enum_name)
        enum_prefix = f"{snake_case.upper()}_"

        values = [v.name for v in self._enum_desc.value]

        # Check if ALL values have the prefix
        if not all(v.startswith(enum_prefix) for v in values):
            return None

        # Check if ALL stripped names are valid Python identifiers
        stripped = [v.removeprefix(enum_prefix) for v in values]
        if not all(name.isidentifier() for name in stripped):
            return None

        return stripped

    def render(self) -> str:
        """Generate the Python enum class code."""
        return ENUM_TEMPLATE.render(
            enum_name=self.name(),
            enum_values=self.values(),
            enum_comment=self.comment(),
        )
