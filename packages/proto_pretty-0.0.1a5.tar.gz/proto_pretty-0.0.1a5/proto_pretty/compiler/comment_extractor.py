from google.protobuf.descriptor_pb2 import (
    DescriptorProto,
    EnumDescriptorProto,
    FileDescriptorProto,
)


class CommentExtractor:
    """Extract comments from protobuf SourceCodeInfo."""

    def __init__(self, proto_file: FileDescriptorProto) -> None:
        self._proto_file = proto_file
        self._location_map: dict[tuple[int, ...], str] = {}
        self._build_location_map()

    def _build_location_map(self) -> None:
        """Build a map from path tuples to comment strings."""
        if not self._proto_file.source_code_info:
            return

        for location in self._proto_file.source_code_info.location:
            path_tuple = tuple(location.path)

            # Combine leading and trailing comments
            comments = []
            if location.leading_comments:
                comments.append(location.leading_comments.strip())
            if location.trailing_comments:
                comments.append(location.trailing_comments.strip())

            # Join multiple detached leading comments
            for detached_comment in location.leading_detached_comments:
                comments.append(detached_comment.strip())

            if comments:
                # Join all comments with double newline to separate different
                # comment blocks
                combined_comment = "\n\n".join(comments)
                # Clean up the comment - remove comment markers and extra whitespace
                cleaned_comment = self._clean_comment(combined_comment)
                if cleaned_comment:
                    self._location_map[path_tuple] = cleaned_comment

    def _clean_comment(self, comment: str) -> str:
        """Clean up a raw comment string."""
        if not comment:
            return ""

        # Split into lines and clean each line
        lines = comment.split("\n")
        cleaned_lines = []

        for line in lines:
            # Remove leading/trailing whitespace
            line = line.strip()
            # Remove comment markers (// and /* */)
            if line.startswith("//"):
                line = line[2:].lstrip()
            elif line.startswith("/*") and line.endswith("*/"):
                line = line[2:-2].strip()
            elif line.startswith("*"):
                # Handle multi-line comments with * prefix
                line = line[1:].lstrip()

            if line:  # Only add non-empty lines
                cleaned_lines.append(line)

        return "\n".join(cleaned_lines)

    def extract_enum_data(
        self, enum_desc: EnumDescriptorProto, enum_path: tuple[int, ...]
    ) -> tuple[str, list[str]]:
        """Extract comment and value comments for an enum."""
        enum_comment = self._location_map.get(enum_path, "")

        value_comments = []
        for j in range(len(enum_desc.value)):
            value_path = enum_path + (2, j)
            value_comment = self._location_map.get(value_path, "")
            value_comments.append(value_comment)

        return enum_comment, value_comments

    def extract_field_comments(
        self, message_desc: DescriptorProto, message_path: tuple[int, ...]
    ) -> list[str]:
        """Extract comments for all fields in a message."""
        field_comments = []
        for i in range(len(message_desc.field)):
            field_path = message_path + (2, i)
            field_comment = self._location_map.get(field_path, "")
            field_comments.append(field_comment)
        return field_comments
