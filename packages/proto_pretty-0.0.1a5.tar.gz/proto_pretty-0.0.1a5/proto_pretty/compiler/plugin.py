#!/usr/bin/env python3
"""Protoc plugin for generating idiomatic Python interfaces."""

import os
import sys
from pathlib import Path

import black
from google.protobuf.compiler import plugin_pb2 as plugin
from google.protobuf.descriptor_pb2 import FileDescriptorProto

from .dependency_resolver import DependencyResolver
from .pretty_file import PrettyFile
from .templates import PRETTY_FILE_TEMPLATE


def format_generated_code(code: str) -> str:
    try:
        formatted_code = black.format_str(code, mode=black.FileMode())
        return formatted_code
    except Exception as e:
        print(f"Warning: Failed to format generated code: {e}", file=sys.stderr)
        return code


def generate_pretty_file(
    proto_file: FileDescriptorProto,
    dependency_resolver: DependencyResolver,
    strip_enum_prefix: bool = True,
) -> tuple[str, str]:
    """Generate idiomatic Python interface for a proto file."""
    pretty_file = PrettyFile(proto_file, dependency_resolver, strip_enum_prefix)

    proto_extension = ".proto"
    if pretty_file.name().endswith(proto_extension):
        pretty_name = pretty_file.name()[: -len(proto_extension)] + "_pretty.py"
    else:
        pretty_name = pretty_file.name() + "_pretty.py"

    content = PRETTY_FILE_TEMPLATE.render(pretty_file=pretty_file)

    # Format the generated code with black
    formatted_content = format_generated_code(content)

    return pretty_name, formatted_content


def main() -> None:
    """Main plugin entry point."""
    data = sys.stdin.buffer.read()
    request = plugin.CodeGeneratorRequest()
    request.ParseFromString(data)

    response = plugin.CodeGeneratorResponse()

    # Declare support for proto3 optional fields
    response.supported_features = (
        plugin.CodeGeneratorResponse.Feature.FEATURE_PROTO3_OPTIONAL
    )

    # Check environment variable for stripping enum prefixes (default: true)
    strip_enum_prefix = (
        os.getenv("PROTO_PRETTY_STRIP_ENUM_PREFIX", "true").lower() == "true"
    )

    # Create dependency resolver
    dependency_resolver = DependencyResolver(list(request.proto_file))

    # Track all directories that need __init__.py files
    init_dirs = set()

    for proto_file in request.proto_file:
        # Skip generating pretty files for Google well-known types
        if proto_file.name and proto_file.name.startswith("google/protobuf/"):
            continue

        filename, content = generate_pretty_file(
            proto_file, dependency_resolver, strip_enum_prefix
        )

        f = response.file.add()
        f.name = filename
        f.content = content

        # Track directories that need __init__.py files
        # E.g., "services/auth/login_pretty.py" needs
        # "services/__init__.py" and "services/auth/__init__.py"
        file_path = Path(filename)
        for parent in file_path.parents:
            if parent == Path("."):
                break
            init_dirs.add(parent)

    # Generate __init__.py files for all directories
    for dir_path in init_dirs:
        init_file = response.file.add()
        init_file.name = str(dir_path / "__init__.py")
        init_file.content = ""  # Empty __init__.py

    sys.stdout.buffer.write(response.SerializeToString())


if __name__ == "__main__":
    main()
