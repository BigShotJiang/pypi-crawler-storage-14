"""Centralized mapping and utilities for Google Protocol Buffers Well-Known Types."""

from typing import Any

# Central mapping of WKT type names to their information
WKT_MAPPING: dict[str, Any] = {
    ".google.protobuf.Timestamp": {
        "python_type": "datetime.datetime",
        "wrapper_class": "TimestampWrapper",
        "import_modules": ["datetime"],
    },
    ".google.protobuf.Duration": {
        "python_type": "datetime.timedelta",
        "wrapper_class": "DurationWrapper",
        "import_modules": ["datetime"],
    },
    ".google.protobuf.StringValue": {
        "python_type": "str",
        "wrapper_class": "StringValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.BoolValue": {
        "python_type": "bool",
        "wrapper_class": "BoolValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.Int32Value": {
        "python_type": "int",
        "wrapper_class": "Int32ValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.Int64Value": {
        "python_type": "int",
        "wrapper_class": "Int64ValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.UInt32Value": {
        "python_type": "int",
        "wrapper_class": "UInt32ValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.UInt64Value": {
        "python_type": "int",
        "wrapper_class": "UInt64ValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.FloatValue": {
        "python_type": "float",
        "wrapper_class": "FloatValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.DoubleValue": {
        "python_type": "float",
        "wrapper_class": "DoubleValueWrapper",
        "import_modules": [],
    },
    ".google.protobuf.BytesValue": {
        "python_type": "bytes",
        "wrapper_class": "BytesValueWrapper",
        "import_modules": [],
    },
}


def is_well_known_type(type_name: str) -> bool:
    """Check if a type name is a supported well-known type."""
    return type_name in WKT_MAPPING


def get_wkt_python_type(type_name: str) -> str:
    """Get the Python type for a WKT type name."""
    wkt_info = WKT_MAPPING.get(type_name)
    if not wkt_info:
        raise ValueError(f"Unknown WKT type: {type_name}")
    return wkt_info["python_type"]


def get_wkt_wrapper_class(type_name: str) -> str:
    """Get the wrapper class name for a WKT type name."""
    wkt_info = WKT_MAPPING.get(type_name)
    if not wkt_info:
        raise ValueError(f"Unknown WKT type: {type_name}")
    return wkt_info["wrapper_class"]


def get_wkt_import_modules(type_name: str) -> list[str]:
    """Get the modules that need to be imported for a WKT type."""
    wkt_info = WKT_MAPPING.get(type_name)
    if not wkt_info:
        raise ValueError(f"Unknown WKT type: {type_name}")

    return wkt_info["import_modules"]
