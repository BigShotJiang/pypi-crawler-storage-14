"""Wrapper classes for converting between protobuf and Python types."""

import datetime
from typing import Any, Protocol


class WrapperProtocol(Protocol):
    """Protocol for wrapper classes that convert between pb2 and Python objects."""

    def from_pb2(self, value: Any) -> Any:
        """Convert from pb2 object to wrapper."""
        ...

    def to_pb2(self, value: Any) -> Any:
        """Convert from wrapper to pb2 object."""
        ...


class NoWrapper(WrapperProtocol):
    """Identity wrapper for primitive types that don't need conversion."""

    def from_pb2(self, value: Any) -> Any:
        return value

    def to_pb2(self, value: Any) -> Any:
        return value


class EnumWrapper(WrapperProtocol):
    """Wrapper for enum types."""

    def __init__(self, enum_class: type) -> None:
        self.enum_class = enum_class

    def from_pb2(self, value: Any) -> Any:
        return self.enum_class(value)

    def to_pb2(self, value: Any) -> Any:
        return value.value


class TimestampWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf Timestamp type."""

    def from_pb2(self, value: Any) -> datetime.datetime:
        """Convert from protobuf Timestamp to datetime.datetime."""
        return datetime.datetime.fromtimestamp(
            value.seconds + value.nanos / 1e9, tz=datetime.UTC
        )

    def to_pb2(self, value: datetime.datetime) -> Any:
        """Convert from datetime.datetime to protobuf Timestamp."""
        from google.protobuf import timestamp_pb2

        if value.tzinfo is None:
            aware_value = value.replace(tzinfo=datetime.UTC)
        else:
            aware_value = value.astimezone(datetime.UTC)

        ts = timestamp_pb2.Timestamp()
        ts.FromDatetime(aware_value)
        return ts


class DurationWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf Duration type."""

    def from_pb2(self, value: Any) -> datetime.timedelta:
        """Convert from protobuf Duration to datetime.timedelta."""
        return datetime.timedelta(
            seconds=value.seconds, microseconds=value.nanos // 1000
        )

    def to_pb2(self, value: datetime.timedelta) -> Any:
        """Convert from datetime.timedelta to protobuf Duration."""
        from google.protobuf import duration_pb2

        dur = duration_pb2.Duration()
        total_seconds = value.total_seconds()
        dur.seconds = int(total_seconds)
        dur.nanos = int((total_seconds % 1) * 1e9)
        return dur


class StringValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf StringValue type."""

    def from_pb2(self, value: Any) -> str:
        """Convert from protobuf StringValue to str."""
        return value.value

    def to_pb2(self, value: str) -> Any:
        """Convert from str to protobuf StringValue."""
        from google.protobuf import wrappers_pb2

        sv = wrappers_pb2.StringValue()
        sv.value = value
        return sv


class BoolValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf BoolValue type."""

    def from_pb2(self, value: Any) -> bool:
        """Convert from protobuf BoolValue to bool."""
        return value.value

    def to_pb2(self, value: bool) -> Any:
        """Convert from bool to protobuf BoolValue."""
        from google.protobuf import wrappers_pb2

        bv = wrappers_pb2.BoolValue()
        bv.value = value
        return bv


class Int32ValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf Int32Value type."""

    def from_pb2(self, value: Any) -> int:
        """Convert from protobuf Int32Value to int."""
        return value.value

    def to_pb2(self, value: int) -> Any:
        """Convert from int to protobuf Int32Value."""
        from google.protobuf import wrappers_pb2

        iv = wrappers_pb2.Int32Value()
        iv.value = value
        return iv


class Int64ValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf Int64Value type."""

    def from_pb2(self, value: Any) -> int:
        """Convert from protobuf Int64Value to int."""
        return value.value

    def to_pb2(self, value: int) -> Any:
        """Convert from int to protobuf Int64Value."""
        from google.protobuf import wrappers_pb2

        iv = wrappers_pb2.Int64Value()
        iv.value = value
        return iv


class UInt32ValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf UInt32Value type."""

    def from_pb2(self, value: Any) -> int:
        """Convert from protobuf UInt32Value to int."""
        return value.value

    def to_pb2(self, value: int) -> Any:
        """Convert from int to protobuf UInt32Value."""
        from google.protobuf import wrappers_pb2

        uv = wrappers_pb2.UInt32Value()
        uv.value = value
        return uv


class UInt64ValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf UInt64Value type."""

    def from_pb2(self, value: Any) -> int:
        """Convert from protobuf UInt64Value to int."""
        return value.value

    def to_pb2(self, value: int) -> Any:
        """Convert from int to protobuf UInt64Value."""
        from google.protobuf import wrappers_pb2

        uv = wrappers_pb2.UInt64Value()
        uv.value = value
        return uv


class FloatValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf FloatValue type."""

    def from_pb2(self, value: Any) -> float:
        """Convert from protobuf FloatValue to float."""
        return value.value

    def to_pb2(self, value: float) -> Any:
        """Convert from float to protobuf FloatValue."""
        from google.protobuf import wrappers_pb2

        fv = wrappers_pb2.FloatValue()
        fv.value = value
        return fv


class DoubleValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf DoubleValue type."""

    def from_pb2(self, value: Any) -> float:
        """Convert from protobuf DoubleValue to float."""
        return value.value

    def to_pb2(self, value: float) -> Any:
        """Convert from float to protobuf DoubleValue."""
        from google.protobuf import wrappers_pb2

        dv = wrappers_pb2.DoubleValue()
        dv.value = value
        return dv


class BytesValueWrapper(WrapperProtocol):
    """Wrapper for Google Protobuf BytesValue type."""

    def from_pb2(self, value: Any) -> bytes:
        """Convert from protobuf BytesValue to bytes."""
        return value.value

    def to_pb2(self, value: bytes) -> Any:
        """Convert from bytes to protobuf BytesValue."""
        from google.protobuf import wrappers_pb2

        bv = wrappers_pb2.BytesValue()
        bv.value = value
        return bv
