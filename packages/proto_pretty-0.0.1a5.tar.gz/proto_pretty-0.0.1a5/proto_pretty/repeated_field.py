from collections.abc import Iterable, Iterator, MutableSequence
from typing import Any, TypeVar, overload

from .wrappers import WrapperProtocol

T = TypeVar("T")


class RepeatedField(MutableSequence[T]):
    """Proxy for protobuf repeated fields with automatic wrapper conversion."""

    def __init__(self, pb_field: Any, wrapper_class: WrapperProtocol) -> None:
        """Initialize proxy with pb2 repeated field and wrapper class.

        Args:
            pb_field: The protobuf repeated field to proxy
            wrapper_class: Class to convert elements (or NoWrapper for primitives)
        """
        self._pb_field = pb_field
        self._wrapper_class = wrapper_class

    @overload
    def __getitem__(self, index: int) -> T: ...

    @overload
    def __getitem__(self, index: slice) -> MutableSequence[T]: ...

    def __getitem__(self, index: int | slice) -> T | MutableSequence[T]:
        """Get item(s) with wrapper conversion."""
        if isinstance(index, slice):
            return [
                self._wrapper_class.from_pb2(item) for item in self._pb_field[index]
            ]
        return self._wrapper_class.from_pb2(self._pb_field[index])

    @overload
    def __setitem__(self, index: int, value: T) -> None: ...

    @overload
    def __setitem__(self, index: slice, value: Iterable[T]) -> None: ...

    def __setitem__(self, index: int | slice, value: T | Iterable[T]) -> None:
        """Set item(s) with pb2 conversion."""
        if isinstance(index, slice):
            if not hasattr(value, "__iter__"):
                raise TypeError("Can only assign iterable to slice")
            pb_values = [self._wrapper_class.to_pb2(item) for item in value]  # type: ignore
            self._pb_field[index] = pb_values
        else:
            self._pb_field[index] = self._wrapper_class.to_pb2(value)

    def __delitem__(self, index: int | slice) -> None:
        """Delete item(s) from the pb2 field."""
        del self._pb_field[index]

    def __len__(self) -> int:
        """Return length of the pb2 field."""
        return len(self._pb_field)

    def __iter__(self) -> Iterator[T]:
        """Iterate over wrapped elements."""
        for item in self._pb_field:
            yield self._wrapper_class.from_pb2(item)

    def append(self, value: T) -> None:
        """Append item with pb2 conversion."""
        self._pb_field.append(self._wrapper_class.to_pb2(value))

    def extend(self, values: Iterable[T]) -> None:
        """Extend with multiple items with pb2 conversion."""
        pb_values = [self._wrapper_class.to_pb2(value) for value in values]
        self._pb_field.extend(pb_values)

    def insert(self, index: int, value: T) -> None:
        """Insert item at index with pb2 conversion."""
        self._pb_field.insert(index, self._wrapper_class.to_pb2(value))

    def remove(self, value: T) -> None:
        """Remove first occurrence of value."""
        pb_value = self._wrapper_class.to_pb2(value)
        self._pb_field.remove(pb_value)

    def pop(self, index: int = -1) -> T:
        """Remove and return item at index with wrapper conversion."""
        pb_item = self._pb_field.pop(index)
        return self._wrapper_class.from_pb2(pb_item)

    def clear(self) -> None:
        """Remove all items from the pb2 field."""
        self._pb_field.clear()

    def count(self, value: T) -> int:
        """Count occurrences of value."""
        pb_value = self._wrapper_class.to_pb2(value)
        return self._pb_field.count(pb_value)

    def index(self, value: T, start: int = 0, stop: int | None = None) -> int:
        """Find index of first occurrence of value."""
        pb_value = self._wrapper_class.to_pb2(value)
        if stop is None:
            return self._pb_field.index(pb_value, start)
        return self._pb_field.index(pb_value, start, stop)

    def reverse(self) -> None:
        """Reverse the pb2 field in place."""
        self._pb_field.reverse()

    def __repr__(self) -> str:
        """String representation showing wrapped elements."""
        return f"[{', '.join(repr(item) for item in self)}]"

    def __eq__(self, other: object) -> bool:
        """Compare with another sequence."""
        if not isinstance(other, list | RepeatedField):
            return False
        return list(self) == list(other)
