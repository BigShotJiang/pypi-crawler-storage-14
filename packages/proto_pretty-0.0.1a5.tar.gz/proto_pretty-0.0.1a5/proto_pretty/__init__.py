"""Proto Pretty - A protoc plugin for generating idiomatic Python interfaces."""

__version__ = "0.1.0"
