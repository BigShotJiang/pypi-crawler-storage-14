<!--

This documentation was created with the assistance of the GeekBot language model and Den*Ram

-->

# 🐍 SnakeScan: Your Go-To Python Port Scanner

✨ A powerful and flexible Python library for all your port scanning needs. ✨

[![PyPI](https://img.shields.io/pypi/v/SnakeScan?color=blue&label=PyPI)](https://pypi.org/project/SnakeScan/)

[![MIT License](https://img.shields.io/badge/License-MIT-green)](https://opensource.org/licenses/MIT)

[![Python 3.7+](https://img.shields.io/badge/Python-3.7+-brightgreen)](https://www.python.org/)

[![Status: Beta](https://img.shields.io/badge/Status-Beta-yellow)](https://github.com/yourusername/SnakeScan/releases)  <!-- Replace yourusername with yours -->

[![Platforms](https://img.shields.io/badge/Platforms-macOS%20%7C%20Linux%20%7C%20Windows-lightgrey)](https://www.python.org/)

**SnakeScan** is designed to be both easy to use and incredibly versatile. Whether you're performing basic single port checks or diving into advanced subnet scans and real-time monitoring, SnakeScan has you covered.

## 🌟 Key Features:

*   **Unmatched Flexibility:** Scan single ports, defined ranges, or pre-configured sets with ease.

*   **Blazing Fast Multithreading:** Leverage multithreading for significantly faster scanning speeds.

*   **Get the Details:** Retrieve valuable information about IP addresses (supports both IPv4 and IPv6).

*   **Real-time Monitoring with Watcher:** Keep a constant eye on critical ports and their statuses.

*   **Intuitive Design:** Clean and simple command-line parameters and API for effortless use.

## ⬇️ Installation:

Get started with SnakeScan in seconds!

bash

pip install SnakeScan

## ⚙️ Command Line Usage: Unleash the Power!

### 💡 Mastering Attribute Usage:

*   **-p**: Specify ports to scan (single or ranges).  **Important:** When specifying ranges, the beginning of the range is only included from the second time.  For example, to scan from 80 to 443, use `79-443`.  Examples: `snake -p 80,443`  or `snake -p 80,3437,8080,20-30,79-443`

*   **-h**:  Display a complete list of available attributes and their descriptions. Example: `snake -h` or `snake -help`

*   **-sp**: Use a predefined set of common ports for scanning with `ProcessPoolExecutor`.  Example: `snake -sp`

*   **-v**: Show the current version of the SnakeScan library. Example: `snake -v`

*   **-gs**:  Retrieve the SSL/TLS certificate from a specified website.  Example: `snake www.google.com -gs` (Without specifying a host, you’ll encounter a connection error).

*   **-t**: Enable multithreading to speed up your port scans. Example: `snake -t`

*   **-ch**: Scan a subnet to discover other IP addresses on the network. Example: `snake -ch`

*   **-l**: Display your public IP address (requires an active internet connection). Example: `snake -l`

*   **-i**:  Show detailed information about a specific IP address (supports both IPv4 and IPv6). Example: `snake www.google.com -i`

## 💻 Python Code Integration:

### ⏱️  Watcher: The Real-Time Port Sentinel!

`Watcher` allows you to continuously monitor the status of a designated port.

python

from SnakeScan import Watcher

watcher = Watcher("localhost", 53, 2)  # Host, port, check interval (in seconds)

watcher.start()  # Begin monitoring!

#### `Watcher` Command Set:

*   `Watcher.start()` - Starts the port monitoring process.

*   `Watcher.stop()` - Halts the port monitoring process.

---

**Latest Update:** 1.7.5 (Enhanced port designations for even clearer understanding)

