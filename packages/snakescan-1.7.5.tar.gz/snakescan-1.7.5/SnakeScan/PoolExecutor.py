import socket
from termcolor import colored
from concurrent.futures import ProcessPoolExecutor

ports = {
    20: "FTP-Data",
    21: "FTP-Control",
    22: "SSH",
    23: "Telnet",
    24: "Priv-mail",
    25: "SMTP",
    29: "MSG-ICP",
    31: "MSG-AUTH",
    33: "DSP",
    35: "Priv-print",
    41: "Graphics",
    42: "WINS",
    43: "Whois",
    48: "AUDITD",
    57: "Priv-term",
    59: "Priv-file",
    63: "WHOISPP",
    66: "SQL-NET",
    75: "Priv-dial",
    80: "HTTP",
    109: "POP2",
    110: "POP3",
    113: "ident",
    115: "SFTP",
    118: "SQLServ",
    119: "NNTP",
    139: "NetBIOS-SSN",
    143: "IMAP",
    179: "BGP",
    194: "IRC",
    199: "SMUX",
    200: "SRC",
    220: "IMAP3",
    311: "ASIP-WEBADMIN",
    344: "PDAP",
    345: "PAWSERV",
    346: "ZSERV",
    347: "FATSERV",
    401: "UPS",
    413: "SMSP",
    427: "SVRLOC",
    443: "HTTPS",
    444: "SNPP",
    606: "URM",
    607: "NQS",
    631: "IPP",
    636: "LDAPS",
    639: "MSDP",
    646: "LDP",
    647: "DHCP-FAILOVER",
    648: "RRP",
    753: "RRH",
    830: "NETCONF-SSH",
    831: "NETCONF-BEEP",
    832: "NETCONFSOAPHTTP",
    833: "NETCONFSOAPBEEP",
    861: "OWAMP-CONTROL",
    862: "TWAPM-CONTROL",
    873: "RSYNC",
    989: "FTPS-DATA",
    990: "FTPS",
    995: "POP3S",
    1038: "MTQP",
    1080: "SOCKS",
    1194: "OpenVPN",
    1433: "SQL server",
    1723: "PPTP",
    2222: "SSH",
    3128: "HTTP",
    3268: "LDAP",
    3306: "MySQL",
    3389: "RDP",
    3455: "RSVP",
    3632: "Distributed compiler",
    3689: "DAAP",
    5432: "PostgreSQL",
    5900: "VNC",
    8000: "HTTP",
    8080: "HTTP",
    8443: "HTTPS",
    8888: "HTTP",
    10000: "Webmin",
}


def is_port_open_threads(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.settimeout(1)
            s.connect((host, port))
        except (OSError, socket.timeout):
            try:
                print(f"Closed{colored('|X|','red')}-->{ports.get(port)}|{port}|")
            except:
                print(f"Closed{colored('|X|','red')}-->|{port}|")
        else:
            print(f"Open{colored('|√|','green')}-->{ports.get(port)}|{port}|")


def PoolProcessExecutor(host):
    with ProcessPoolExecutor(max_workers=None) as executor:
        try:
            for port in ports.keys():
                future = executor.submit(is_port_open_threads, host, port)

        except Exception as e:
            print(e)
