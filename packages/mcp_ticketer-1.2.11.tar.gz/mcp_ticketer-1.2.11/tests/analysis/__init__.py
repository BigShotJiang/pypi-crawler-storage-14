"""Tests for analysis module."""
