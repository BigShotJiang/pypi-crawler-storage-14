"""
AbuLang - Complete AbuLang Integration for Python
Enables all AbuLang commands and syntax in Python environment
"""

__version__ = "4.1.1"
__author__ = "Abu"

from AbuLangModule import (
    enable_abulang,
    disable_abulang,
    help_abulang,
    exec_abulang,
    fix_abulang_syntax,
)

import builtins
show = builtins.show if hasattr(builtins, 'show') else None
ask = builtins.ask if hasattr(builtins, 'ask') else None
libra = builtins.libra if hasattr(builtins, 'libra') else None
plus = builtins.plus if hasattr(builtins, 'plus') else None
minus = builtins.minus if hasattr(builtins, 'minus') else None
multi = builtins.multi if hasattr(builtins, 'multi') else None
divid = builtins.divid if hasattr(builtins, 'divid') else None
expon = builtins.expon if hasattr(builtins, 'expon') else None
modul = builtins.modul if hasattr(builtins, 'modul') else None
absof = builtins.absof if hasattr(builtins, 'absof') else None
sumup = builtins.sumup if hasattr(builtins, 'sumup') else None
avera = builtins.avera if hasattr(builtins, 'avera') else None
strip = builtins.strip if hasattr(builtins, 'strip') else None
lower = builtins.lower if hasattr(builtins, 'lower') else None
upper = builtins.upper if hasattr(builtins, 'upper') else None
replc = builtins.replc if hasattr(builtins, 'replc') else None
findt = builtins.findt if hasattr(builtins, 'findt') else None
lengt = builtins.lengt if hasattr(builtins, 'lengt') else None
isolate = builtins.isolate if hasattr(builtins, 'isolate') else None
pausi = builtins.pausi if hasattr(builtins, 'pausi') else None
exitp = builtins.exitp if hasattr(builtins, 'exitp') else None
readf = builtins.readf if hasattr(builtins, 'readf') else None
write = builtins.write if hasattr(builtins, 'write') else None
get_line = builtins.get_line if hasattr(builtins, 'get_line') else None
save_as = builtins.save_as if hasattr(builtins, 'save_as') else None
switch = builtins.switch if hasattr(builtins, 'switch') else None
assign_compare = builtins.assign_compare if hasattr(builtins, 'assign_compare') else None
local = builtins.local if hasattr(builtins, 'local') else None
local_to_global = builtins.local_to_global if hasattr(builtins, 'local_to_global') else None
save_local = builtins.save_local if hasattr(builtins, 'save_local') else None

__all__ = [
    'enable_abulang', 'disable_abulang', 'help_abulang', 'exec_abulang', 'fix_abulang_syntax',
    'show', 'ask', 'libra', 'plus', 'minus', 'multi', 'divid', 'expon', 'modul', 'absof',
    'sumup', 'avera', 'strip', 'lower', 'upper', 'replc', 'findt', 'lengt', 'isolate',
    'pausi', 'exitp', 'readf', 'write', 'get_line', 'save_as', 'switch', 'assign_compare',
    'local', 'local_to_global', 'save_local',
]
