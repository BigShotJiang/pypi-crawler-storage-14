NAME='transformation_toupper'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['toupper']
