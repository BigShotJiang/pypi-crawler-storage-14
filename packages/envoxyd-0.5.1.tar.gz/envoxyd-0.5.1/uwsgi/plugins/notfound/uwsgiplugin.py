NAME='notfound'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['notfound']
