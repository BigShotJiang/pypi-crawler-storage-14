
from datetime import datetime

def get_time_stamp():
    current_timestamp = datetime.now().timestamp()
    return current_timestamp