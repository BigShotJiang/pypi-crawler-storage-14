"""
PyMoji Executor Module ⚙️

Executes emoji code directly.
"""

from __future__ import annotations
import sys
from io import StringIO
from typing import Any
from .translator import emoji_to_python


def run_emoji(emoji_code: str, globals_dict: dict | None = None, 
               locals_dict: dict | None = None) -> Any:
    """
    Execute emoji code and return the result.
    
    Args:
        emoji_code: String containing Python code with emojis
        globals_dict: Optional globals dictionary
        locals_dict: Optional locals dictionary
        
    Returns:
        Result of the execution
        
    Example:
        >>> run_emoji("🖨️('Hello PyMoji!')")
        Hello PyMoji!
    """
    python_code = emoji_to_python(emoji_code)
    
    if globals_dict is None:
        globals_dict = {}
    if locals_dict is None:
        locals_dict = globals_dict  # Use same dict for both
    
    # Execute the code
    exec(python_code, globals_dict, locals_dict)
    
    # Return locals in case variables were defined
    return locals_dict


def run_emoji_file(filepath: str, encoding: str = 'utf-8') -> Any:
    """
    Execute an emoji code file.
    
    Args:
        filepath: Path to the .pymoji file
        encoding: File encoding (default: utf-8)
        
    Returns:
        Result of the execution
        
    Example:
        >>> run_emoji_file('my_script.pymoji')
    """
    with open(filepath, 'r', encoding=encoding) as f:
        emoji_code = f.read()
    
    return run_emoji(emoji_code)


def eval_emoji(emoji_expression: str, globals_dict: dict | None = None,
                locals_dict: dict | None = None) -> Any:
    """
    Evaluate an emoji expression and return the result.
    
    Args:
        emoji_expression: Single emoji expression
        globals_dict: Optional globals dictionary
        locals_dict: Optional locals dictionary
        
    Returns:
        Result of the evaluation
        
    Example:
        >>> eval_emoji("2 ➕ 2")
        4
    """
    python_expression = emoji_to_python(emoji_expression)
    
    if globals_dict is None:
        globals_dict = {}
    if locals_dict is None:
        locals_dict = {}
    
    return eval(python_expression, globals_dict, locals_dict)


def run_emoji_interactive():
    """
    Start an interactive PyMoji REPL (Read-Eval-Print Loop).
    
    Example:
        >>> from pymoji import run_emoji_interactive
        >>> run_emoji_interactive()
        PyMoji Interactive Shell 🐍✨
        Type 'exit()' or 'quit()' to exit
        >>> 🖨️('Hello!')
        Hello!
    """
    print("PyMoji Interactive Shell 🐍✨")
    print("Type 'exit()' or 'quit()' to exit")
    print("Type 'help()' for available emoji mappings\n")
    
    globals_dict = {}
    locals_dict = {}
    
    while True:
        try:
            # Get input
            emoji_input = input(">>> ")
            
            # Check for exit commands
            if emoji_input.strip() in ['exit()', 'quit()']:
                print("Goodbye! 👋")
                break
            
            # Check for help
            if emoji_input.strip() == 'help()':
                print_emoji_help()
                continue
            
            # Skip empty lines
            if not emoji_input.strip():
                continue
            
            # Try to evaluate first (for expressions)
            try:
                result = eval_emoji(emoji_input, globals_dict, locals_dict)
                if result is not None:
                    print(result)
            except SyntaxError:
                # If eval fails, try exec (for statements)
                run_emoji(emoji_input, globals_dict, locals_dict)
                
        except KeyboardInterrupt:
            print("\nKeyboardInterrupt")
            continue
        except EOFError:
            print("\nGoodbye! 👋")
            break
        except Exception as e:
            print(f"Error: {e}")


def print_emoji_help():
    """Print available emoji mappings."""
    from .mappings import EMOJI_TO_KEYWORD, EMOJI_TO_BUILTIN, EMOJI_TO_OPERATOR
    
    print("\n📋 PyMoji Cheat Sheet:\n")
    
    print("Keywords:")
    for emoji, keyword in sorted(EMOJI_TO_KEYWORD.items(), key=lambda x: x[1]):
        print(f"  {emoji}  → {keyword}")
    
    print("\nBuilt-in Functions:")
    for emoji, func in sorted(EMOJI_TO_BUILTIN.items(), key=lambda x: x[1]):
        print(f"  {emoji}  → {func}()")
    
    print("\nOperators:")
    for emoji, op in sorted(EMOJI_TO_OPERATOR.items(), key=lambda x: x[1]):
        print(f"  {emoji}  → {op}")
    
    print()
