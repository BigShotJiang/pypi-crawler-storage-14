"""
PyMoji Translator Module 🔄

Translates between emoji code and Python code.
"""

from __future__ import annotations
import re
from typing import Optional, Tuple
from .mappings import ALL_EMOJI_MAPPINGS, ALL_REVERSE_MAPPINGS


def emoji_to_python(emoji_code: str) -> str:
    """
    Convert emoji code to valid Python code.
    
    Args:
        emoji_code: String containing Python code with emojis
        
    Returns:
        Valid Python code with keywords instead of emojis
        
    Example:
        >>> emoji_to_python("📦 greet(name):\\n    🖨️(f'Hello {name}!')")
        "def greet(name):\\n    print(f'Hello {name}!')"
    """
    python_code = emoji_code
    
    # Sort by length (descending) to handle multi-character emojis first
    sorted_mappings = sorted(
        ALL_EMOJI_MAPPINGS.items(),
        key=lambda x: len(x[0]),
        reverse=True
    )
    
    for emoji, keyword in sorted_mappings:
        # Use word boundaries to avoid partial replacements
        # But be careful with emojis - they don't have word boundaries
        python_code = python_code.replace(emoji, keyword)
    
    return python_code


def python_to_emoji(python_code: str) -> str:
    """
    Convert Python code to emoji code.
    
    Args:
        python_code: Valid Python code
        
    Returns:
        Python code with emojis instead of keywords
        
    Example:
        >>> python_to_emoji("def greet(name):\\n    print(f'Hello {name}!')")
        "📦 greet(name):\\n    🖨️(f'Hello {name}!')"
    """
    emoji_code = python_code
    
    # Sort by length (descending) to handle longer keywords first
    sorted_mappings = sorted(
        ALL_REVERSE_MAPPINGS.items(),
        key=lambda x: len(x[0]),
        reverse=True
    )
    
    for keyword, emoji in sorted_mappings:
        # Use word boundaries to only replace whole words
        pattern = r'\b' + re.escape(keyword) + r'\b'
        emoji_code = re.sub(pattern, emoji, emoji_code)
    
    return emoji_code


def validate_emoji_code(emoji_code: str) -> tuple[bool, str]:
    """
    Validate if emoji code can be converted to valid Python.
    
    Args:
        emoji_code: String containing emoji code
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        python_code = emoji_to_python(emoji_code)
        compile(python_code, '<string>', 'exec')
        return True, ""
    except SyntaxError as e:
        return False, f"Syntax Error: {e}"
    except Exception as e:
        return False, f"Error: {e}"


def get_emoji_for_keyword(keyword: str) -> str | None:
    """
    Get the emoji representation for a Python keyword.
    
    Args:
        keyword: Python keyword or built-in function name
        
    Returns:
        Emoji string or None if not found
    """
    return ALL_REVERSE_MAPPINGS.get(keyword)


def get_keyword_for_emoji(emoji: str) -> str | None:
    """
    Get the Python keyword for an emoji.
    
    Args:
        emoji: Emoji character
        
    Returns:
        Keyword string or None if not found
    """
    return ALL_EMOJI_MAPPINGS.get(emoji)
