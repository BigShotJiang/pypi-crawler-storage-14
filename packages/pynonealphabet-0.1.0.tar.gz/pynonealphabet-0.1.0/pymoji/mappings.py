"""
PyMoji Emoji-to-Keyword Mappings 🗺️

This module contains all the mappings between emojis and Python keywords,
operators, and built-in functions.
"""

# Keywords
EMOJI_TO_KEYWORD = {
    # Control Flow
    '❓': 'if',
    '❔': 'elif',
    '❗': 'else',
    '🔁': 'for',
    '♾️': 'while',
    '🛑': 'break',
    '⏭️': 'continue',
    '⏸️': 'pass',
    '↩️': 'return',
    '🎁': 'yield',
    
    # Logical Operators
    '＆': 'and',
    '｜': 'or',
    '¬': 'not',
    '🟰': 'is',
    '📥': 'in',
    
    # Functions & Classes
    '📦': 'def',
    '🏛️': 'class',
    'λ': 'lambda',
    
    # Exceptions
    '🔬': 'try',
    '🚨': 'except',
    '🏁': 'finally',
    '💥': 'raise',
    '✓': 'assert',
    
    # Imports
    '📚': 'import',
    '📖': 'from',
    '🏷️': 'as',
    
    # Values
    '✅': 'True',
    '❌': 'False',
    '∅': 'None',
    
    # Variables & Scope
    '🌍': 'global',
    '🏠': 'nonlocal',
    '🗑️': 'del',
    
    # Async
    '⚡': 'async',
    '⏳': 'await',
    
    # Context
    '🤝': 'with',
}

# Built-in Functions (optional, for extra fun!)
EMOJI_TO_BUILTIN = {
    '🖨️': 'print',
    '⌨️': 'input',
    '📏': 'len',
    '🔢': 'int',
    '📝': 'str',
    '📋': 'list',
    '📖': 'dict',
    '🎲': 'range',
    '➕': 'sum',
    '📊': 'enumerate',
    '🔄': 'zip',
    '🎯': 'map',
    '🔍': 'filter',
    '✂️': 'slice',
    '📐': 'abs',
    '🔺': 'max',
    '🔻': 'min',
    '🎭': 'type',
    '🆔': 'id',
    '📂': 'open',
}

# Operators (optional)
EMOJI_TO_OPERATOR = {
    '➕': '+',
    '➖': '-',
    '✖️': '*',
    '➗': '/',
    '📍': '%',
    '🔋': '**',
    '🟰': '==',
    '≠': '!=',
    '⬅️': '<=',
    '➡️': '>=',
    '◀️': '<',
    '▶️': '>',
}

# Reverse mappings
KEYWORD_TO_EMOJI = {v: k for k, v in EMOJI_TO_KEYWORD.items()}
BUILTIN_TO_EMOJI = {v: k for k, v in EMOJI_TO_BUILTIN.items()}
OPERATOR_TO_EMOJI = {v: k for k, v in EMOJI_TO_OPERATOR.items()}

# Combined mapping for easy access
ALL_EMOJI_MAPPINGS = {
    **EMOJI_TO_KEYWORD,
    **EMOJI_TO_BUILTIN,
    **EMOJI_TO_OPERATOR,
}

ALL_REVERSE_MAPPINGS = {
    **KEYWORD_TO_EMOJI,
    **BUILTIN_TO_EMOJI,
    **OPERATOR_TO_EMOJI,
}
