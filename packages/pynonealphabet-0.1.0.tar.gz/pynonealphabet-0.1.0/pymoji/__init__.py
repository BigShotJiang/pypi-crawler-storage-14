"""
PyMoji - Programming in Emojis! 🐍✨

A fun Python module that allows you to write Python code using emojis instead of keywords.
Making programming accessible to everyone, even those who prefer pictures over words!

Example:
    >>> from pymoji import emoji_to_python, run_emoji
    >>> code = "📦 hello():\\n    🖨️('Hello World!')"
    >>> python_code = emoji_to_python(code)
    >>> run_emoji(code)
    Hello World!
"""

__version__ = "0.1.0"
__author__ = "PyMoji Contributors"

from .translator import emoji_to_python, python_to_emoji
from .executor import run_emoji, run_emoji_file, eval_emoji
from .mappings import EMOJI_TO_KEYWORD, KEYWORD_TO_EMOJI

__all__ = [
    'emoji_to_python',
    'python_to_emoji',
    'run_emoji',
    'run_emoji_file',
    'eval_emoji',
    'EMOJI_TO_KEYWORD',
    'KEYWORD_TO_EMOJI',
]
