# PyMoji 🐍✨

**Programming in Emojis!**

PyMoji is a fun Python module that lets you write Python code using emojis instead of keywords. Making programming accessible and fun for everyone - even those who prefer pictures over words!

## 🌐 Try It Online!

**Live Playground: [www.pymoji.org](https://www.pymoji.org)**

Write and run emoji code directly in your browser - no installation needed!

## Why PyMoji? 🤔

- **Visual Learning**: Emojis make code more visual and memorable
- **Fun**: Programming should be enjoyable!
- **Educational**: Great for teaching programming concepts
- **Universal**: Emojis transcend language barriers
- **Absurd**: Because why not? 😄

## Installation 📦

```bash
pip install pynonealphabet
```

Or install from source:

```bash
git clone https://github.com/yourusername/pymoji.git
cd pymoji
pip install -e .
```

## Quick Start 🚀

### Hello World

```python
from pymoji import run_emoji

emoji_code = """
🖨️('Hello, PyMoji World! 🌍')
"""

run_emoji(emoji_code)
```

### Functions

```python
from pymoji import run_emoji

emoji_code = """
📦 greet(name):
    🖨️(f'Hello, {name}! 👋')

greet('PyMoji')
"""

run_emoji(emoji_code)
```

### Loops

```python
from pymoji import run_emoji

emoji_code = """
🔁 i 📥 🎲(5):
    🖨️(f'Count: {i}')
"""

run_emoji(emoji_code)
```

### Conditionals

```python
from pymoji import run_emoji

emoji_code = """
x = 10

❓ x ▶️ 5:
    🖨️('x is greater than 5')
❔ x 🟰 5:
    🖨️('x is 5')
❗:
    🖨️('x is less than 5')
"""

run_emoji(emoji_code)
```

## Emoji Cheat Sheet 📋

### Keywords

| Emoji | Keyword | Description |
|-------|---------|-------------|
| 📦 | `def` | Define function |
| 🏛️ | `class` | Define class |
| ❓ | `if` | If statement |
| ❔ | `elif` | Else if |
| ❗ | `else` | Else |
| 🔁 | `for` | For loop |
| ♾️ | `while` | While loop |
| 🛑 | `break` | Break loop |
| ⏭️ | `continue` | Continue loop |
| ↩️ | `return` | Return value |
| 🎁 | `yield` | Yield (generator) |
| 🔬 | `try` | Try block |
| 🚨 | `except` | Exception handler |
| 🏁 | `finally` | Finally block |
| 💥 | `raise` | Raise exception |
| ✓ | `assert` | Assert statement |
| 📚 | `import` | Import module |
| 📖 | `from` | From import |
| 🏷️ | `as` | Import as |
| ✅ | `True` | Boolean True |
| ❌ | `False` | Boolean False |
| ∅ | `None` | None value |
| ＆ | `and` | Logical AND |
| ｜ | `or` | Logical OR |
| ¬ | `not` | Logical NOT |
| 🟰 | `is` | Identity check |
| 📥 | `in` | Membership test |
| 🌍 | `global` | Global variable |
| 🏠 | `nonlocal` | Nonlocal variable |
| 🗑️ | `del` | Delete |
| ⚡ | `async` | Async function |
| ⏳ | `await` | Await async |
| 🤝 | `with` | Context manager |
| λ | `lambda` | Lambda function |

### Built-in Functions

| Emoji | Function | Description |
|-------|----------|-------------|
| 🖨️ | `print` | Print output |
| ⌨️ | `input` | Get user input |
| 📏 | `len` | Get length |
| 🔢 | `int` | Convert to integer |
| 📝 | `str` | Convert to string |
| 📋 | `list` | Create list |
| 🎲 | `range` | Create range |
| 🔄 | `zip` | Zip iterables |
| 📊 | `enumerate` | Enumerate |
| 🎯 | `map` | Map function |
| 🔍 | `filter` | Filter |
| 🔺 | `max` | Maximum value |
| 🔻 | `min` | Minimum value |
| ➕ | `sum` | Sum values |

### Operators

| Emoji | Operator | Description |
|-------|----------|-------------|
| ➕ | `+` | Addition |
| ➖ | `-` | Subtraction |
| ✖️ | `*` | Multiplication |
| ➗ | `/` | Division |
| 📍 | `%` | Modulo |
| 🔋 | `**` | Power |
| 🟰 | `==` | Equal to |
| ≠ | `!=` | Not equal |
| ◀️ | `<` | Less than |
| ▶️ | `>` | Greater than |
| ⬅️ | `<=` | Less or equal |
| ➡️ | `>=` | Greater or equal |

## Advanced Usage 🎓

### Translating Between Formats

```python
from pymoji import emoji_to_python, python_to_emoji

# Convert emoji to Python
emoji_code = "📦 hello(): 🖨️('Hi!')"
python_code = emoji_to_python(emoji_code)
print(python_code)  # def hello(): print('Hi!')

# Convert Python to emoji
python_code = "def hello(): print('Hi!')"
emoji_code = python_to_emoji(python_code)
print(emoji_code)  # 📦 hello(): 🖨️('Hi!')
```

### Interactive REPL

Run the PyMoji interactive shell:

```bash
pymoji
```

Or from Python:

```python
from pymoji import run_emoji_interactive
run_emoji_interactive()
```

### Running .pymoji Files

Save your emoji code in a `.pymoji` file:

```python
# my_script.pymoji
📦 fibonacci(n):
    ❓ n ⬅️ 1:
        ↩️ n
    ❗:
        ↩️ fibonacci(n-1) ➕ fibonacci(n-2)

🖨️(fibonacci(10))
```

Then run it:

```python
from pymoji import run_emoji_file
run_emoji_file('my_script.pymoji')
```

## Examples 📚

Check out the `examples/` directory for more:

- `hello_world.py` - Simple hello world
- `functions_loops.py` - Functions and loops
- `fibonacci.py` - Fibonacci generator
- `classes.py` - Object-oriented programming

## Testing 🧪

Run the test suite:

```bash
python -m pytest tests/
```

Or:

```bash
python tests/test_pymoji.py
```

## API Reference 📖

### `emoji_to_python(emoji_code: str) -> str`
Convert emoji code to valid Python code.

### `python_to_emoji(python_code: str) -> str`
Convert Python code to emoji code.

### `run_emoji(emoji_code: str, globals_dict=None, locals_dict=None) -> dict`
Execute emoji code and return locals dictionary.

### `run_emoji_file(filepath: str, encoding='utf-8') -> dict`
Execute a .pymoji file.

### `eval_emoji(emoji_expression: str, globals_dict=None, locals_dict=None) -> Any`
Evaluate an emoji expression and return the result.

### `run_emoji_interactive()`
Start an interactive PyMoji REPL.

## Contributing 🤝

Contributions are welcome! Here are some ideas:

- Add more emoji mappings
- Improve error messages
- Add syntax highlighting
- Create a VS Code extension
- Build a web playground
- Add more examples

## License 📄

MIT License - See LICENSE file for details.

## Disclaimer ⚠️

PyMoji is a fun educational project. For production code, please use regular Python! 😄

## Credits 👏

Created with ❤️ by the PyMoji community.

Inspired by the joy of programming and the universal language of emojis! 🌍✨

---

**Happy emoji coding!** 🎉🐍
