"""
PyMoji Test Suite 🧪

Tests for the PyMoji module.
"""

import unittest
from pymoji import (
    emoji_to_python,
    python_to_emoji,
    run_emoji,
    eval_emoji,
    EMOJI_TO_KEYWORD,
    KEYWORD_TO_EMOJI
)


class TestTranslation(unittest.TestCase):
    """Test emoji to Python translation."""
    
    def test_simple_if(self):
        emoji_code = "❓ x ▶️ 5:\n    🖨️('big')"
        python_code = emoji_to_python(emoji_code)
        self.assertIn('if', python_code)
        self.assertIn('print', python_code)
    
    def test_function_definition(self):
        emoji_code = "📦 hello():\n    🖨️('hi')"
        python_code = emoji_to_python(emoji_code)
        self.assertIn('def', python_code)
        self.assertIn('print', python_code)
    
    def test_for_loop(self):
        emoji_code = "🔁 i 📥 🎲(5):\n    🖨️(i)"
        python_code = emoji_to_python(emoji_code)
        self.assertIn('for', python_code)
        self.assertIn('in', python_code)
        self.assertIn('range', python_code)
    
    def test_reverse_translation(self):
        python_code = "def hello():\n    print('hi')"
        emoji_code = python_to_emoji(python_code)
        self.assertIn('📦', emoji_code)
        self.assertIn('🖨️', emoji_code)
    
    def test_logical_operators(self):
        emoji_code = "x ＆ y"
        python_code = emoji_to_python(emoji_code)
        self.assertIn('and', python_code)


class TestExecution(unittest.TestCase):
    """Test emoji code execution."""
    
    def test_simple_print(self):
        emoji_code = "🖨️('test')"
        # Should not raise an error
        try:
            run_emoji(emoji_code)
            success = True
        except Exception:
            success = False
        self.assertTrue(success)
    
    def test_variable_assignment(self):
        emoji_code = "x = 42"
        result = run_emoji(emoji_code)
        self.assertEqual(result.get('x'), 42)
    
    def test_eval_expression(self):
        result = eval_emoji("2 ➕ 3")
        self.assertEqual(result, 5)
    
    def test_function_execution(self):
        emoji_code = """
📦 add(a, b):
    ↩️ a + b

result = add(3, 4)
"""
        locals_dict = run_emoji(emoji_code)
        self.assertEqual(locals_dict.get('result'), 7)


class TestMappings(unittest.TestCase):
    """Test emoji mappings."""
    
    def test_all_keywords_mapped(self):
        python_keywords = [
            'if', 'elif', 'else', 'for', 'while', 'break', 'continue',
            'def', 'class', 'return', 'yield', 'try', 'except', 'finally',
            'import', 'from', 'as', 'True', 'False', 'None', 'and', 'or',
            'not', 'is', 'in', 'with', 'raise', 'assert', 'pass', 'global',
            'nonlocal', 'del', 'async', 'await', 'lambda'
        ]
        
        for keyword in python_keywords:
            self.assertIn(keyword, KEYWORD_TO_EMOJI,
                         f"Keyword '{keyword}' not mapped to emoji")
    
    def test_emoji_uniqueness(self):
        # Each emoji should map to only one keyword
        emojis = list(EMOJI_TO_KEYWORD.keys())
        self.assertEqual(len(emojis), len(set(emojis)),
                        "Duplicate emojis found in mapping")
    
    def test_bidirectional_mapping(self):
        # Test that emoji -> keyword -> emoji works
        for emoji, keyword in EMOJI_TO_KEYWORD.items():
            reverse_emoji = KEYWORD_TO_EMOJI.get(keyword)
            self.assertEqual(emoji, reverse_emoji,
                           f"Bidirectional mapping failed for {keyword}")


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and error handling."""
    
    def test_empty_code(self):
        result = run_emoji("")
        self.assertIsInstance(result, dict)
    
    def test_mixed_emoji_python(self):
        # Should work with mix of emojis and regular Python
        emoji_code = "📦 test():\n    return 42"
        python_code = emoji_to_python(emoji_code)
        self.assertIn('def', python_code)
        self.assertIn('return', python_code)
    
    def test_nested_structures(self):
        emoji_code = """
📦 outer():
    📦 inner():
        ↩️ 42
    ↩️ inner()
"""
        try:
            run_emoji(emoji_code)
            success = True
        except Exception:
            success = False
        self.assertTrue(success)


if __name__ == '__main__':
    print("🧪 Running PyMoji Tests...\n")
    unittest.main(verbosity=2)
