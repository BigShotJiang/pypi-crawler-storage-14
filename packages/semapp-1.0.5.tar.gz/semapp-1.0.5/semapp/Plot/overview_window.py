"""
Overview window for displaying wafer mapping with image thumbnails.
"""

import os
import numpy as np
import pandas as pd
from PIL import Image
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QMessageBox, QPushButton, QHBoxLayout, QFileDialog
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication, QKeyEvent
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
import matplotlib.pyplot as plt


class OverviewWindow(QWidget):
    """
    A window that displays a full-screen overview of the wafer mapping
    with image thumbnails at each coordinate position.
    """
    
    def __init__(self, coordinates, image_list, tiff_path, is_complus4t_mode=False, 
                 image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the overview window.
        
        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
            image_list: List of PIL Images from the TIFF file
            tiff_path: Path to the TIFF file
            is_complus4t_mode: Boolean indicating if in COMPLUS4T mode
            image_type: Image type index (for normal mode)
            number_type: Number of image types (for normal mode)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(parent)
        
        # Set window flags FIRST, before creating any widgets
        self.setWindowFlags(Qt.Window | Qt.WindowStaysOnTopHint)
        
        self.coordinates = coordinates
        self.image_list = image_list
        self.tiff_path = tiff_path
        self.is_complus4t_mode = is_complus4t_mode
        self.image_type = image_type
        self.number_type = number_type
        self.button_frame = button_frame
        
        # Thumbnail size (adjust based on number of images)
        self.thumbnail_size = self._calculate_thumbnail_size()
        
        self.setWindowTitle("Overview - Wafer Mapping")
        self._setup_ui()
        self._create_overview_plot()
        print(f"[DEBUG] OverviewWindow __init__ complete")
    
    def keyPressEvent(self, event):
        """Handle key press events - close on Escape key."""
        if event.key() == Qt.Key_Escape:
            self.close()
        else:
            super().keyPressEvent(event)
    
    def save_overview(self):
        """Save the overview plot to a file using the canvas."""
        # Disable save button during save operation
        save_button = self.findChild(QPushButton, "save_button")
        if save_button:
            save_button.setEnabled(False)
            save_button.setText("Saving...")
        
        # Process events to update UI
        from PyQt5.QtWidgets import QApplication
        QApplication.processEvents()
        
        # Open file dialog to choose save location
        file_path, selected_filter = QFileDialog.getSaveFileName(
            self,
            "Save Overview",
            "overview.png",
            "PNG Files (*.png);;PDF Files (*.pdf);;SVG Files (*.svg);;All Files (*)"
        )
        
        if file_path:
            try:
                print(f"[DEBUG] Starting save to: {file_path}")
                
                # Determine DPI based on file format (lower for memory efficiency)
                if file_path.lower().endswith('.pdf'):
                    dpi = 150  # Lower DPI for PDF
                elif file_path.lower().endswith('.svg'):
                    dpi = 100  # SVG is vector, DPI less critical
                else:
                    dpi = 150  # Reduced from 300 for PNG to save memory
                
                # Save using canvas print_figure (more efficient than figure.savefig)
                self.canvas.print_figure(
                    file_path,
                    dpi=dpi,
                    bbox_inches='tight',  # Remove extra whitespace
                    facecolor='white',  # White background
                    edgecolor='none',
                    format=None,  # Let matplotlib determine format from extension
                    pad_inches=0.1  # Small padding
                )
                
                # Force garbage collection
                import gc
                gc.collect()
                
                print(f"[DEBUG] Overview saved to: {file_path}")
            except Exception as e:
                print(f"[DEBUG] Error saving overview: {e}")
                import traceback
                traceback.print_exc()
                # Show error message
                msg = QMessageBox()
                msg.setIcon(QMessageBox.Critical)
                msg.setText(f"Error saving overview:\n{str(e)}")
                msg.setWindowTitle("Save Error")
                msg.exec_()
            finally:
                # Re-enable save button
                if save_button:
                    save_button.setEnabled(True)
                    save_button.setText("💾 Save")
    
    def _calculate_thumbnail_size(self):
        """Calculate appropriate thumbnail size based on number of images."""
        if self.coordinates is None or len(self.coordinates) == 0:
            return 50
        
        num_images = len(self.coordinates)
        
        # Adjust thumbnail size based on number of images
        if num_images < 50:
            return 80
        elif num_images < 100:
            return 60
        elif num_images < 200:
            return 40
        else:
            return 30
    
    def _setup_ui(self):
        """Set up the UI components."""
        # Get screen size for figure sizing
        screen = QGuiApplication.primaryScreen().geometry()
        print(f"[DEBUG] Screen size: {screen.width()}x{screen.height()}")
        
        # Create main layout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Create button layout for buttons (top right)
        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(10, 10, 10, 10)
        button_layout.addStretch()  # Push buttons to the right
        
        # Create save button
        save_button = QPushButton("💾 Save")
        save_button.setObjectName("save_button")  # Set object name for later reference
        save_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 2px solid #388E3C;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
            QPushButton:pressed {
                background-color: #2E7D32;
            }
            QPushButton:disabled {
                background-color: #CCCCCC;
                color: #666666;
            }
        """)
        save_button.clicked.connect(self.save_overview)
        save_button.setFixedSize(100, 35)
        button_layout.addWidget(save_button)
        
        # Create close button
        close_button = QPushButton("✕ Close")
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 2px solid #D32F2F;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
            QPushButton:pressed {
                background-color: #B71C1C;
            }
        """)
        close_button.clicked.connect(self.close)
        close_button.setFixedSize(100, 35)
        button_layout.addWidget(close_button)
        
        main_layout.addLayout(button_layout)
        
        # Create matplotlib figure and canvas (full screen size)
        self.figure = Figure(figsize=(screen.width()/100, screen.height()/100), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        main_layout.addWidget(self.canvas)
        
        # Set window flags BEFORE creating widgets to ensure it appears on top
        # Note: Window flags should be set before adding widgets
        print(f"[DEBUG] Setting window flags...")
    
    def _create_overview_plot(self):
        """Create the overview plot with image thumbnails."""
        if self.coordinates is None or self.coordinates.empty:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No coordinates available', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        self.ax = self.figure.add_subplot(111)
        self.ax.set_xlabel('X (mm)', fontsize=32)  # Doubled from 16
        self.ax.set_ylabel('Y (mm)', fontsize=32)  # Doubled from 16
        
        # Double the font size for tick labels (xtick and ytick)
        self.ax.tick_params(axis='both', which='major', labelsize=32)  # Doubled from default ~16
        
        # Get coordinates
        x_coords = self.coordinates['X'].values
        y_coords = self.coordinates['Y'].values
        
        # Apply *10 scaling factor for display (convert cm to mm)
        x_coords_scaled = x_coords * 10
        y_coords_scaled = y_coords * 10
        
        # Calculate radius for scaling (also scaled by 10)
        max_val = max(abs(x_coords_scaled).max(), abs(y_coords_scaled).max())
        
        if pd.isna(max_val) or not np.isfinite(max_val):
            radius = 100  # 10 * 10
        elif max_val <= 50:  # 5 * 10
            radius = 50
        elif max_val <= 75:  # 7.5 * 10
            radius = 75
        elif max_val <= 100:  # 10 * 10
            radius = 100
        elif max_val <= 150:  # 15 * 10
            radius = 150
        else:
            radius = max_val
        
        # Set limits (scaled by 10)
        self.ax.set_xlim(-radius - 10, radius + 10)
        self.ax.set_ylim(-radius - 10, radius + 10)
        
        # Draw circle (radius scaled by 10)
        circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
        self.ax.add_patch(circle)
        self.ax.set_aspect('equal')
        
        # No grid (removed)
        
        # Place image thumbnails at each coordinate (using scaled coordinates)
        self._place_image_thumbnails(x_coords_scaled, y_coords_scaled, radius)
        
        self.figure.subplots_adjust(left=0.1, right=0.95, top=0.95, bottom=0.1)
        self.canvas.draw()
    
    def _place_image_thumbnails(self, x_coords, y_coords, radius):
        """
        Place image thumbnails at each coordinate position.
        
        Args:
            x_coords: Array of X coordinates
            y_coords: Array of Y coordinates
            radius: Radius for scaling
        """
        if not self.image_list or len(self.image_list) == 0:
            # If no images, just show points
            self.ax.scatter(x_coords, y_coords, color='blue', marker='o', s=50, alpha=0.5)
            return
        
        # Calculate image spacing to avoid overlap
        # Estimate spacing based on radius and number of points
        num_points = len(x_coords)
        spacing_factor = (2 * radius) / max(num_points ** 0.5, 1)
        
        # Place thumbnails
        for idx, (x, y) in enumerate(zip(x_coords, y_coords)):
            try:
                # Get the corresponding image
                if self.is_complus4t_mode:
                    # COMPLUS4T: use defect_id to get image
                    defect_id = int(self.coordinates.iloc[idx]['defect_id'])
                    image_idx = defect_id - 1  # defect_id starts at 1, index starts at 0
                else:
                    # Normal mode: use image_type and number_type if available
                    if self.image_type is not None and self.number_type is not None:
                        image_idx = self.image_type + (idx * self.number_type)
                    else:
                        # Fallback: try to get from button_frame
                        if self.button_frame:
                            result = self.button_frame.get_selected_image()
                            if result is not None:
                                img_type, num_type = result
                                image_idx = img_type + (idx * num_type)
                            else:
                                image_idx = idx
                        else:
                            image_idx = idx
                
                # Check if image index is valid
                if 0 <= image_idx < len(self.image_list):
                    pil_image = self.image_list[image_idx]
                    
                    # Resize image to thumbnail size
                    thumbnail = pil_image.resize(
                        (self.thumbnail_size, self.thumbnail_size),
                        Image.Resampling.LANCZOS
                    )
                    
                    # Convert PIL to numpy array
                    img_array = np.array(thumbnail.convert('RGB'))
                    
                    # Create OffsetImage for matplotlib
                    im = OffsetImage(img_array, zoom=1.0)
                    
                    # Create AnnotationBbox to place image at coordinate
                    ab = AnnotationBbox(im, (x, y), frameon=False, pad=0)
                    self.ax.add_artist(ab)
                else:
                    # If image not available, show a small point
                    self.ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
                    
            except Exception as e:
                # If error loading image, show a small point
                print(f"Error loading image for coordinate ({x}, {y}): {e}")
                self.ax.scatter([x], [y], color='gray', marker='o', s=20, alpha=0.5)
        
        # Also show points for reference (semi-transparent)
        self.ax.scatter(x_coords, y_coords, color='red', marker='o', s=5, alpha=0.2)

