"""
A class to manage and display frames in the UI, providing functionality
for plotting and saving combined screenshots of images and plots.
"""
import os
import numpy as np
import glob
import re
import pandas as pd
import cv2
from PIL import Image
from semapp.Processing.threshold import SEMThresholdProcessor
from semapp.Processing.klarf_reader import extract_positions
from PyQt5.QtWidgets import QFrame, QGroupBox, QWidget, QVBoxLayout, QPushButton, \
    QGridLayout, QLabel, QFileDialog, QProgressDialog, QMessageBox
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from semapp.Plot.utils import create_savebutton
from semapp.Plot.styles import OPEN_BUTTON_STYLE, MESSAGE_BOX_STYLE, FRAME_STYLE
from semapp.Plot.overview_window import OverviewWindow

# Constants
FRAME_SIZE = 600
CANVAS_SIZE = 600
radius = 10

class PlotFrame(QWidget):
    """
    A class to manage and display frames in the UI.
    
    Provides functionality for:
    - Opening and displaying TIFF images
    - Plotting coordinate mappings
    - Interactive defect selection
    - Overview window with image thumbnails
    
    Attributes:
        layout (QGridLayout): Main layout for the frame
        button_frame (ButtonFrame): Reference to button controls
        frame_left (QFrame): Left frame for image display
        frame_right (QFrame): Right frame for plot display
        coordinates (pd.DataFrame): DataFrame with defect coordinates
        image_list (list): List of PIL Image objects
        current_tiff_path (str): Path to currently loaded TIFF file
        is_complus4t_mode (bool): Flag indicating COMPLUS4T mode
    """

    def __init__(self, layout, button_frame):
        """
        Initialize the PlotFrame class.
        
        Sets up UI components, initializes variables, and creates
        the left and right frames for image and plot display.

        Args:
            layout (QGridLayout): The layout to which the frames will be added.
            button_frame (ButtonFrame): The button frame containing control elements.
        """
        super().__init__()
        self.layout = layout
        self.button_frame = button_frame
        
        # Initialize state
        self.coordinates = None
        self.image_list = []
        self.current_index = 0
        self.canvas_connection_id = None
        self.selected_wafer = None
        self.radius = None
        self.is_complus4t_mode = False  # COMPLUS4T mode detected
        self.show_thresholded = True  # Toggle for threshold display
        self.current_tiff_path = None  # Store current TIFF file path
        self.last_clicked_position = None  # Store last clicked position (x, y)
        self.overview_window = None  # Store reference to overview window to prevent garbage collection
        
        self._setup_frames()
        self._setup_plot()
        self._setup_controls()

    def _setup_frames(self):
        """Initialize left and right display frames."""
        # Left frame for images
        self.frame_left = self._create_frame()
        self.frame_left_layout = QVBoxLayout()
        self.frame_left.setLayout(self.frame_left_layout)
        
        # Right frame for plots
        self.frame_right = self._create_frame()
        self.frame_right_layout = QGridLayout()
        self.frame_right.setLayout(self.frame_right_layout)
        
        # Add frames to main layout (shifted down by 1 row)
        self.layout.addWidget(self.frame_left, 3, 0, 1, 3)
        self.layout.addWidget(self.frame_right, 3, 3, 1, 3)

    def _create_frame(self):
        """Create a styled frame with fixed size."""
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        frame.setStyleSheet(FRAME_STYLE)
        frame.setFixedSize(FRAME_SIZE+100, FRAME_SIZE)
        return frame

    def _setup_plot(self):
        """Initialize matplotlib figure and canvas."""
        self.figure = Figure(figsize=(5, 5))
        self.ax = self.figure.add_subplot(111)
        self.canvas = FigureCanvas(self.figure)
        self.frame_right_layout.addWidget(self.canvas)
        
        # Initialize image display
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.frame_left_layout.addWidget(self.image_label)

    def _setup_controls(self):
        """Set up control buttons."""
        create_savebutton(self.layout, self.frame_left, self.frame_right, self.button_frame)
        
        open_button = QPushButton('Open TIFF', self)
        open_button.setStyleSheet(OPEN_BUTTON_STYLE)
        open_button.clicked.connect(self.open_tiff)
        self.layout.addWidget(open_button, 1, 5, 1, 1)  # Takes 1 row
        
        overview_button = QPushButton('Overview', self)
        overview_button.setStyleSheet(OPEN_BUTTON_STYLE)
        overview_button.clicked.connect(self.show_overview)
        self.layout.addWidget(overview_button, 2, 5, 1, 1)  # Below Open TIFF
    
    def extract_positions(self, filepath, wafer_id=None):
        """
        Extract defect positions from KLARF file.
        Wrapper method that calls the klarf_reader module.
        
        Args:
            filepath: Path to the KLARF (.001) file
            wafer_id: Specific wafer ID to extract (for COMPLUS4T files with multiple wafers)
                     If None, extracts all defects (normal mode)
        
        Returns:
            pd.DataFrame: DataFrame with columns ["defect_id", "X", "Y", "defect_size"]
        """
        # Call the klarf_reader function
        self.coordinates = extract_positions(filepath, wafer_id=wafer_id)
        return self.coordinates

    def open_tiff(self):
        """Handle TIFF file opening and display."""
        self.selected_wafer = self.button_frame.get_selected_option()
        
        if not all([self.selected_wafer]):
            self._reset_display()
            return

        # Check if COMPLUS4T mode is active
        dirname = self.button_frame.folder_var_changed()
        is_complus4t = self._check_complus4t_mode(dirname)
        self.is_complus4t_mode = is_complus4t  # Store mode for later use
        
        if is_complus4t:
            # COMPLUS4T mode: .001 and .tiff files in parent directory
            folder_path = dirname
            
            # Find the .001 file with the selected wafer ID in parent directory
            matching_files = glob.glob(os.path.join(dirname, '*.001'))
            recipe_path = None
            
            for file_path in matching_files:
                if self._is_wafer_in_klarf(file_path, self.selected_wafer):
                    recipe_path = file_path
                    break
            
            # Find the only .tiff file in the parent directory
            tiff_files = glob.glob(os.path.join(dirname, '*.tiff'))
            if not tiff_files:
                tiff_files = glob.glob(os.path.join(dirname, '*.tif'))
            
            if tiff_files:
                tiff_path = tiff_files[0]
            else:
                self._reset_display()
                return
            
            # Extract positions for the specific wafer
            self.coordinates = self.extract_positions(recipe_path, wafer_id=self.selected_wafer)
        else:
            # Normal mode: subfolders
            folder_path = os.path.join(dirname, str(self.selected_wafer))
            
            # Find the first .001 file in the selected folder
            matching_files = glob.glob(os.path.join(folder_path, '*.001'))

            # Sort the files to ensure consistent ordering
            if matching_files:
                recipe_path = matching_files[0]
            else:
                recipe_path = None  
            
            tiff_path = os.path.join(folder_path, "data.tif")

            if not os.path.isfile(tiff_path):
                self._reset_display()
                return
            
            # Extract all positions (normal mode)
            self.coordinates = self.extract_positions(recipe_path)     

        self._load_tiff(tiff_path)
        self._update_plot()
        
        # Set reference to plot_frame in button_frame for slider updates
        self.button_frame.plot_frame = self

        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"Wafer {self.selected_wafer} opened successfully")
        msg.setWindowTitle("Wafer Opened")
        msg.setStyleSheet(MESSAGE_BOX_STYLE)
        msg.exec_()

    def _check_complus4t_mode(self, dirname):
        """Check if we are in COMPLUS4T mode (.001 files with COMPLUS4T in parent directory)."""
        if not dirname or not os.path.exists(dirname):
            return False
        
        # Check for .001 files with COMPLUS4T in the parent directory
        matching_files = glob.glob(os.path.join(dirname, '*.001'))
        for file_path in matching_files:
            try:
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content:
                        return True
            except Exception:
                pass
        
        return False

    def _is_wafer_in_klarf(self, file_path, wafer_id):
        """Check if a specific wafer ID is in the KLARF file."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                pattern = r'WaferID\s+"@' + str(wafer_id) + r'"'
                return re.search(pattern, content) is not None
        except Exception:
            return False

    def _reset_display(self):
        """
        Resets the display by clearing the figure and reinitializing the subplot.
        Also clears the frame_left_layout to remove any existing widgets.
        """
        # Clear all widgets from the left frame layout
        while self.frame_left_layout.count():
            item = self.frame_left_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()  # Properly delete the widget

        # Recreate the image label in the left frame
        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.frame_left_layout.addWidget(self.image_label)

        # Clear the figure associated with the canvas
        self.figure.clear()
        self.ax = self.figure.add_subplot(111)  # Create a new subplot
        self.plot_mapping_tpl(self.ax)  # Plot the default template

        # Disconnect any existing signal connection
        if self.canvas_connection_id is not None:
            self.canvas.mpl_disconnect(self.canvas_connection_id)
            self.canvas_connection_id = None

        self.canvas.draw()  # Redraw the updated canvas

    def _update_plot(self):
        """
        Updates the plot with the current wafer mapping.
        Ensures the plot is clean before adding new data.
        """
        if hasattr(self, 'ax') and self.ax:
            self.ax.clear()  # Clear the existing plot
        else:
            self.ax = self.figure.add_subplot(111)  # Create new axes

        self.plot_mapping_tpl(self.ax)  # Plot wafer mapping

        # Ensure only one connection to the button press event
        if self.canvas_connection_id is not None:
            self.canvas.mpl_disconnect(self.canvas_connection_id)

        self.canvas_connection_id = self.canvas.mpl_connect(
            'button_press_event', self.on_click)
        self.canvas.draw()

    def show_image(self):
        """
        Displays the current image from the image list in the QLabel with threshold applied.
        """
        if self.image_list:
            # Check if current_index is valid (for KRONOS/COMPLUS4T, there's no current_index)
            if not hasattr(self, 'current_index') or self.current_index is None:
                # For KRONOS/COMPLUS4T mode, use first image
                self.current_index = 0
            
            # Ensure current_index is within bounds
            if self.current_index >= len(self.image_list):
                self.current_index = 0
            
            print(f"Showing image {self.current_index} of {len(self.image_list)}")
            pil_image = self.image_list[self.current_index]
            print(f"Original image mode: {pil_image.mode}, size: {pil_image.size}")
            
            # Get threshold value from button frame
            threshold = 255  # Default threshold (matches slider default)
            if self.button_frame and hasattr(self.button_frame, 'get_threshold_value'):
                threshold = self.button_frame.get_threshold_value()
            
            print(f"Using threshold: {threshold}")
            
            # Apply threshold processing
            processed_image = self._apply_threshold(pil_image, threshold)
            print(f"Processed image mode: {processed_image.mode}, size: {processed_image.size}")
            
            # Convert to RGBA for display
            processed_image = processed_image.convert("RGBA")
            data = processed_image.tobytes("raw", "RGBA")
            qimage = QImage(data, processed_image.width, processed_image.height,
                            QImage.Format_RGBA8888)
            pixmap = QPixmap.fromImage(qimage)
            
            # Scale image to fit the frame while maintaining aspect ratio
            frame_size = self.frame_left.size()
            # Account for frame margins/padding (use ~95% of frame size)
            max_width = int(frame_size.width() * 0.95)
            max_height = int(frame_size.height() * 0.95)
            
            # Scale pixmap to fit within frame bounds while keeping aspect ratio
            scaled_pixmap = pixmap.scaled(max_width, max_height, 
                                         Qt.KeepAspectRatio, 
                                         Qt.SmoothTransformation)
            
            self.image_label.setPixmap(scaled_pixmap)
            print(f"Image displayed successfully (original: {pixmap.width()}x{pixmap.height()}, scaled: {scaled_pixmap.width()}x{scaled_pixmap.height()}, frame: {max_width}x{max_height})")
        else:
            print("No images in image_list")
    
    def _apply_threshold(self, pil_image, threshold):
        """
        Apply threshold processing to a PIL image using SEMThresholdProcessor.
        
        Args:
            pil_image: PIL Image object
            threshold: Threshold value (1-255)
            
        Returns:
            PIL Image with threshold applied
        """
        try:
            # Debug: Print image info
            print(f"Original image mode: {pil_image.mode}, size: {pil_image.size}")
            print(f"Threshold: {threshold}")
            
            # Convert PIL to numpy array
            img_array = np.array(pil_image)
            print(f"Image shape: {img_array.shape}, dtype: {img_array.dtype}")
            print(f"Image min: {img_array.min()}, max: {img_array.max()}")
            
            # Convert to grayscale if needed
            if len(img_array.shape) == 3:
                if img_array.shape[2] == 4:  # RGBA
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGBA2GRAY)
                elif img_array.shape[2] == 3:  # RGB
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                else:
                    gray = img_array[:, :, 0]
            else:
                gray = img_array
            
            print(f"Grayscale shape: {gray.shape}, min: {gray.min()}, max: {gray.max()}")
            
            # Apply smoothing with kernel size 3
            kernel_size = 3
            image_smooth = cv2.GaussianBlur(gray, (kernel_size, kernel_size), 0)
            
            # Apply thresholding
            _, binary_image = cv2.threshold(image_smooth, threshold, 255, cv2.THRESH_BINARY)
            
            print(f"Binary shape: {binary_image.shape}, min: {binary_image.min()}, max: {binary_image.max()}")
            
            # Find contours (same as threshold.py)
            contours, _ = cv2.findContours(binary_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Filter contours by size (same as threshold.py)
            min_size = 2  # Default minimum particle size
            if self.button_frame and hasattr(self.button_frame, 'get_min_size_value'):
                min_size = self.button_frame.get_min_size_value()
            
            detected_particles = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area > min_size:
                    detected_particles.append({
                        'area': area,
                        'contour': contour
                    })
            
            print(f"Found {len(detected_particles)} particles")
            
            # Create visualization: show contours on original image (same as threshold.py)
            original_with_contours = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
            
            # Draw contours on original image
            for particle in detected_particles:
                cv2.fillPoly(original_with_contours, [particle['contour']], (0, 255, 0))  # Green fill
            
            print(f"Contour image shape: {original_with_contours.shape}, min: {original_with_contours.min()}, max: {original_with_contours.max()}")
            
            # Use the original image with contours
            result = original_with_contours
            
            print(f"Result shape: {result.shape}, min: {result.min()}, max: {result.max()}")
            
            # Convert back to PIL Image
            return Image.fromarray(result.astype(np.uint8))
            
        except Exception as e:
            print(f"Error in _apply_threshold: {e}")
            # Return original image if threshold fails
            return pil_image
    

    def plot_mapping_tpl(self, ax):
        """Plots the mapping of the wafer with coordinate points."""
        ax.set_xlabel('X (cm)', fontsize=20)
        ax.set_ylabel('Y (cm)', fontsize=20)
        
        if self.coordinates is not None:
            # Get all coordinates
            x_coords = self.coordinates['X']
            y_coords = self.coordinates['Y']
            defect_size = self.coordinates['defect_size']
            
            # Determine color based on mode
            if self.is_complus4t_mode:
                # Mode COMPLUS4T: color based on slider threshold
                threshold = 0.0  # Default threshold
                result = self.button_frame.get_selected_image()
                if result is not None:
                    threshold = result[0]  # Slider value in nm
                
                # Red if size >= threshold, blue otherwise
                colors = ['blue' if size >= threshold else 'red' for size in defect_size]
            else:
                # Normal mode: color based on fixed threshold (10 nm)
                colors = ['blue' if size > 1.0e+01 else 'red' for size in defect_size]
            
            ax.scatter(x_coords, y_coords, color=colors, marker='o',
                       s=100, label='Positions')

            # Calculate the maximum value for scaling using ALL coordinates
            if len(self.coordinates) == 0:
                # No defects found, use default radius
                radius = 10
                max_val = 10
            else:
                x_coords_all = self.coordinates['X']
                y_coords_all = self.coordinates['Y']
                max_val = max(abs(x_coords_all).max(), abs(y_coords_all).max())
                
                # Check for NaN or Inf values
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 10
                    max_val = 10
                elif max_val <= 5:
                    radius = 5
                elif max_val <= 7.5:
                    radius = 7.5
                elif max_val <= 10:
                    radius = 10
                elif max_val <= 15:
                    radius = 15
                else:
                    radius = max_val  # fallback for > 15

            self.radius = radius
            
            # Set limits based on the radius
            ax.set_xlim(-radius - 1, radius + 1)
            ax.set_ylim(-radius - 1, radius + 1)

            circle = plt.Circle((0, 0), radius, color='black',
                                fill=False, linewidth=0.5)
            ax.add_patch(circle)
            ax.set_aspect('equal')
            
            # Add grid
            ax.grid(True, alpha=0.3, linestyle='-', linewidth=0.5)
            ax.set_axisbelow(True)
        else:
            # No coordinates available
            pass
        

        ax.figure.subplots_adjust(left=0.15, right=0.95, top=0.90, bottom=0.1)
        self.canvas.draw()

    def on_click(self, event):
        """
        Handles mouse click events on the plot, identifying the closest point
        and updating the plot with a red circle around the selected point.

        :param event: The event generated by the mouse click.
        """
        result = self.button_frame.get_selected_image()
        if result is not None:
            self.image_type, self_number_type = result
        else:
            return

        if event.inaxes:
            x_pos = event.xdata
            y_pos = event.ydata

            # Store the clicked position for filename generation (will be updated with closest point)
            self.last_clicked_position = (x_pos, y_pos)

            if self.coordinates is not None and not self.coordinates.empty:
                distances = np.sqrt((self.coordinates['X'] - x_pos) ** 2 +
                                    (self.coordinates['Y'] - y_pos) ** 2)
                closest_idx = distances.idxmin()
                closest_pt = self.coordinates.iloc[closest_idx]
                
                # Update stored position with closest point coordinates
                self.last_clicked_position = (closest_pt['X'], closest_pt['Y'])
                
                # Replot with a red circle around the selected point
                self.ax.clear()  # Clear the existing plot
                self.plot_mapping_tpl(self.ax)
                self.ax.scatter([closest_pt['X']], [closest_pt['Y']],
                                color='green', marker='o', s=100,
                                label='Selected point')
                coord_text = f"{closest_pt['X']:.1f} / {closest_pt['Y']:.1f}"
                self.ax.text(-self.radius -0.5, self.radius-0.5, coord_text, fontsize=16, color='black')
                self.canvas.draw()

                # Update the image based on the selected point
                if self.is_complus4t_mode:
                    # COMPLUS4T mode: use DEFECTID from KLARF file
                    defect_id = int(closest_pt['defect_id'])
                    # DEFECTID starts at 1, but Python indices start at 0
                    result = defect_id - 1
                else:
                    # Normal mode: use DataFrame index (original behavior)
                    result = self.image_type + (closest_idx * self_number_type)
                
                self.current_index = result
                
                # Check if index is valid
                if 0 <= self.current_index < len(self.image_list):
                    self.show_image()

    def _load_tiff(self, tiff_path):
        """Load and prepare TIFF images for display.
        
        Args:
            tiff_path: Path to the TIFF file to load
        """
        try:
            self.current_tiff_path = tiff_path  # Store the current TIFF path
            img = Image.open(tiff_path)
            self.image_list = []

            # Load all TIFF pages and resize them
            while True:
                resized_img = img.copy().resize((CANVAS_SIZE, CANVAS_SIZE),
                                              Image.Resampling.LANCZOS)
                self.image_list.append(resized_img)
                try:
                    img.seek(img.tell() + 1)  # Move to next page
                except EOFError:
                    break  # No more pages

            self.current_index = 0
            self.show_image()  # Display first image
            
        except Exception as e:
            # Error loading TIFF file
            pass
            self._reset_display()

    def show_overview(self):
        """Show overview of the wafer data with image thumbnails."""
        print("[DEBUG] show_overview called")
        
        # Check if coordinates and images are available
        if self.coordinates is None or (hasattr(self.coordinates, 'empty') and self.coordinates.empty):
            print("[DEBUG] No coordinates available")
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No coordinates available. Please open a TIFF file first.")
            msg.setWindowTitle("Overview")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
            return
        
        if not self.image_list or len(self.image_list) == 0:
            print("[DEBUG] No images available")
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText("No images available. Please open a TIFF file first.")
            msg.setWindowTitle("Overview")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
            return
        
        print(f"[DEBUG] Coordinates: {len(self.coordinates)} entries")
        print(f"[DEBUG] Images: {len(self.image_list)} images")
        print(f"[DEBUG] COMPLUS4T mode: {self.is_complus4t_mode}")
        
        # Get image type settings for normal mode
        image_type = None
        number_type = None
        if not self.is_complus4t_mode and self.button_frame:
            result = self.button_frame.get_selected_image()
            if result is not None:
                image_type, number_type = result
                print(f"[DEBUG] Image type: {image_type}, Number type: {number_type}")
        
        try:
            # Close previous overview window if it exists
            if self.overview_window is not None:
                self.overview_window.close()
                self.overview_window = None
            
            # Create and show overview window
            print("[DEBUG] Creating OverviewWindow...")
            self.overview_window = OverviewWindow(
                coordinates=self.coordinates,
                image_list=self.image_list,
                tiff_path=self.current_tiff_path,
                is_complus4t_mode=self.is_complus4t_mode,
                image_type=image_type,
                number_type=number_type,
                button_frame=self.button_frame,
                parent=None  # Set parent to None to make it a separate window
            )
            print("[DEBUG] OverviewWindow created, showing...")
            
            # Process events to ensure window is ready
            from PyQt5.QtWidgets import QApplication
            QApplication.processEvents()
            
            # Show the window first
            self.overview_window.show()
            QApplication.processEvents()
            
            # Then set to fullscreen
            from PyQt5.QtCore import Qt
            self.overview_window.setWindowState(Qt.WindowFullScreen)
            QApplication.processEvents()
            
            # Bring to front
            self.overview_window.raise_()
            self.overview_window.activateWindow()
            QApplication.processEvents()
            
            print(f"[DEBUG] OverviewWindow should be visible now. Is visible: {self.overview_window.isVisible()}, Is active: {self.overview_window.isActiveWindow()}")
        except Exception as e:
            print(f"[DEBUG] Error creating/showing OverviewWindow: {e}")
            import traceback
            traceback.print_exc()
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText(f"Error opening overview: {str(e)}")
            msg.setWindowTitle("Error")
            msg.setStyleSheet(MESSAGE_BOX_STYLE)
            msg.exec_()
    
    def get_current_image_path(self):
        """Get the path of the currently displayed image."""
        if self.current_tiff_path and self.image_list:
            return self.current_tiff_path
        return None
    