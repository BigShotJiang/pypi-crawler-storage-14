"""
Toast notification widget for non-intrusive user feedback.
"""

from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout
from PyQt5.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, QPoint
from PyQt5.QtGui import QFont


class ToastNotification(QWidget):
    """
    A toast notification widget that appears temporarily to show messages.
    Non-intrusive and auto-dismisses after a set duration.
    """
    
    def __init__(self, message, parent=None, duration=3000, notification_type="info"):
        """
        Initialize the toast notification.
        
        Args:
            message: Text message to display
            parent: Parent widget
            duration: Duration in milliseconds before auto-dismiss
            notification_type: Type of notification ("info", "success", "warning", "error")
        """
        super().__init__(parent)
        
        self.duration = duration
        self.notification_type = notification_type
        
        # Set window flags for frameless, always on top, tooltip behavior
        self.setWindowFlags(
            Qt.ToolTip | 
            Qt.FramelessWindowHint | 
            Qt.WindowStaysOnTopHint
        )
        
        # Set up styles based on notification type
        self._setup_style()
        
        # Create layout and label
        layout = QVBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        label = QLabel(message)
        label.setWordWrap(True)
        font = QFont()
        font.setPointSize(10)
        label.setFont(font)
        label.setAlignment(Qt.AlignCenter)
        
        layout.addWidget(label)
        self.setLayout(layout)
        
        # Adjust size to content
        self.adjustSize()
        
    def _setup_style(self):
        """Set up the style based on notification type."""
        colors = {
            "info": {
                "bg": "#2196F3",
                "border": "#1976D2"
            },
            "success": {
                "bg": "#4CAF50",
                "border": "#388E3C"
            },
            "warning": {
                "bg": "#FF9800",
                "border": "#F57C00"
            },
            "error": {
                "bg": "#F44336",
                "border": "#D32F2F"
            }
        }
        
        color = colors.get(self.notification_type, colors["info"])
        
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {color['bg']};
                color: white;
                border: 2px solid {color['border']};
                border-radius: 8px;
                padding: 5px;
            }}
            QLabel {{
                background-color: transparent;
                color: white;
                border: none;
            }}
        """)
    
    def show_toast(self):
        """
        Show the toast notification with fade-in animation.
        Auto-dismisses after the specified duration.
        """
        if self.parent():
            # Position relative to parent
            parent_rect = self.parent().geometry()
            x = parent_rect.right() - self.width() - 20
            y = parent_rect.top() + 20
            self.move(x, y)
        else:
            # Center on screen if no parent
            from PyQt5.QtGui import QGuiApplication
            screen = QGuiApplication.primaryScreen().geometry()
            x = (screen.width() - self.width()) // 2
            y = screen.height() - self.height() - 50
            self.move(x, y)
        
        # Set initial opacity for fade-in
        self.setWindowOpacity(0.0)
        self.show()
        
        # Fade-in animation
        fade_in = QPropertyAnimation(self, b"windowOpacity")
        fade_in.setDuration(300)
        fade_in.setStartValue(0.0)
        fade_in.setEndValue(1.0)
        fade_in.setEasingCurve(QEasingCurve.InOutQuad)
        fade_in.start()
        
        # Auto-dismiss after duration
        QTimer.singleShot(self.duration, self._dismiss)
    
    def _dismiss(self):
        """Dismiss the toast with fade-out animation."""
        fade_out = QPropertyAnimation(self, b"windowOpacity")
        fade_out.setDuration(300)
        fade_out.setStartValue(1.0)
        fade_out.setEndValue(0.0)
        fade_out.setEasingCurve(QEasingCurve.InOutQuad)
        fade_out.finished.connect(self.close)
        fade_out.start()


def show_toast(parent, message, duration=3000, notification_type="info"):
    """
    Convenience function to show a toast notification.
    
    Args:
        parent: Parent widget
        message: Message to display
        duration: Duration in milliseconds
        notification_type: Type of notification
    
    Returns:
        ToastNotification: The created toast widget
    """
    toast = ToastNotification(message, parent, duration, notification_type)
    toast.show_toast()
    return toast

