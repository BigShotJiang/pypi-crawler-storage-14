"""Module for buttons"""
# pylint: disable=no-name-in-module, trailing-whitespace, too-many-branches, too-many-statements


import sys
import os
import time
import re
from PyQt5.QtWidgets import QApplication 
from PyQt5.QtWidgets import (
    QWidget, QButtonGroup, QPushButton, QLabel, QGroupBox, QGridLayout,
    QFileDialog, QProgressDialog, QRadioButton, QSizePolicy, QSlider)
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from semapp.Layout.toast import show_toast 
from semapp.Processing.processing import Process
from semapp.Layout.styles import (
    RADIO_BUTTON_STYLE,
    SETTINGS_BUTTON_STYLE,
    RUN_BUTTON_STYLE,
    GROUP_BOX_STYLE,
    WAFER_BUTTON_DEFAULT_STYLE,
    WAFER_BUTTON_EXISTING_STYLE,
    WAFER_BUTTON_MISSING_STYLE,
    SELECT_BUTTON_STYLE,
    PATH_LABEL_STYLE,
)
from semapp.Layout.settings import SettingsWindow

class ButtonFrame(QWidget):
    """Class to create the various buttons of the interface"""

    def __init__(self, layout):
        super().__init__()
        self.layout = layout
        self.folder_path = None
        self.check_vars = {}
        self.common_class = None
        self.folder_path_label = None
        self.radio_vars = {} 
        self.selected_option = None
        self.selected_image = None
        self.table_data = None
        self.table_vars = None
        self.image_slider = None  # Slider for COMPLUS4T mode
        self.slider_value = 0  # Current slider value
        self.image_group_box = None  # Store reference to image type group box
        self.plot_frame = None  # Reference to plot frame for updates
        
        # Threshold slider components
        self.threshold_slider = None  # Slider for threshold (0-255)
        self.threshold_value = 255  # Current threshold value (default 255)
        self.threshold_label = None  # Label for threshold value
        
        # Min size slider components
        self.min_size_slider = None  # Slider for minimum particle size (1-100)
        self.min_size_value = 2  # Current min size value
        self.min_size_label = None  # Label for min size value
        
        # Store references to all buttons for enabling/disabling
        self.all_buttons = []
        self.all_radio_buttons = []

        self.split_rename = QRadioButton("Split .tif and rename (w/ tag)")
        self.split_rename_all = QRadioButton("Split .tif and rename (w/ tag)")
        self.clean = QRadioButton("Clean")
        self.clean_all = QRadioButton("Clean Batch")
        self.create_folder = QRadioButton("Create folders")
        
        # New threshold and mapping buttons
        self.threshold = QRadioButton("Threshold")
        self.mapping = QRadioButton("Mapping")
        self.threshold_all = QRadioButton("Threshold")
        self.mapping_all = QRadioButton("Mapping")

        self.line_edits = {}

        tool_radiobuttons = [self.split_rename,
                             self.split_rename_all, self.clean_all,
                             self.create_folder, self.threshold, self.mapping,
                             self.threshold_all, self.mapping_all, self.clean]

        for radiobutton in tool_radiobuttons:
            radiobutton.setStyleSheet(RADIO_BUTTON_STYLE)
            # Store reference for enabling/disabling
            self.all_radio_buttons.append(radiobutton)

        # Example of adding them to a layout
        self.entries = {}
        self.dirname = None
        self.dirname = None


        max_characters = 30  # Set character limit
        if self.dirname:
            self.display_text = self.dirname if len(
                self.dirname) <= max_characters else self.dirname[
                                                     :max_characters] + '...'

        # Get the user's folder path (C:\Users\XXXXX)
        self.user_folder = os.path.expanduser(
            "~")  # This gets C:\Users\XXXXX

        # Define the new folder you want to create
        self.new_folder = os.path.join(self.user_folder, "SEM")


        # Create the folder if it doesn't exist
        self.create_directory(self.new_folder)

        self.button_group = QButtonGroup(self)

        self.init_ui()

    def create_directory(self, path):
        """Create the directory if it does not exist."""
        if not os.path.exists(path):
            os.makedirs(path)

    def init_ui(self):
        """Initialize the user interface"""
        # Add widgets to the grid layout provided by the main window

        self.settings_window = SettingsWindow()
        self.dir_box()
        self.create_wafer()
        self.create_radiobuttons_other()
        self.create_radiobuttons()
        self.create_radiobuttons_all()
        self.image_radiobuttons()
        self.create_threshold_slider()
        self.add_settings_button()
        self.create_run_button()
        self.update_wafer()
        self.settings_window.data_updated.connect(self.refresh_radiobuttons)


    def add_settings_button(self):
        """Add a Settings button that opens a new dialog"""
        self.settings_button = QPushButton("Settings")
        self.settings_button.setStyleSheet(SETTINGS_BUTTON_STYLE)
        self.settings_button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.settings_button.clicked.connect(self.open_settings_window)
        
        # Store reference for enabling/disabling
        self.all_buttons.append(self.settings_button)

        self.layout.addWidget(self.settings_button, 0, 4, 1, 1)

    def open_settings_window(self):
        """Open the settings window"""

        self.settings_window.exec_()

    def dir_box(self):
        """Create a smaller directory selection box"""

        # Create layout for this frame
        frame_dir = QGroupBox("Directory")

        frame_dir.setStyleSheet(GROUP_BOX_STYLE)

        # Button for selecting folder
        self.select_folder_button = QPushButton("Select Parent Folder...")
        self.select_folder_button.setStyleSheet(SELECT_BUTTON_STYLE)
        
        # Store reference for enabling/disabling
        self.all_buttons.append(self.select_folder_button)

        # Create layout for the frame and reduce its margins
        frame_dir_layout = QGridLayout()
        frame_dir_layout.setContentsMargins(5, 20, 5, 5)  # Reduced margins
        frame_dir.setLayout(frame_dir_layout)

        # label for folder path
        if self.dirname:
            self.folder_path_label = QLabel(self.display_text)
        else:
            self.folder_path_label = QLabel()

        self.folder_path_label.setStyleSheet(PATH_LABEL_STYLE)

        # Connect the button to folder selection method
        self.select_folder_button.clicked.connect(self.on_select_folder_and_update)

        # Add widgets to layout
        frame_dir_layout.addWidget(self.select_folder_button, 0, 0, 1, 1)
        frame_dir_layout.addWidget(self.folder_path_label, 1, 0, 1, 1)

        # Add frame to the main layout with a smaller footprint
        self.layout.addWidget(frame_dir, 0, 0)

    def folder_var_changed(self):
        """Update parent folder"""
        return self.dirname

    def on_select_folder_and_update(self):
        """Method to select folder and update checkbuttons"""
        self.select_folder()
        self.update_wafer()
        self.image_radiobuttons()  # Refresh image type widget (radio buttons or slider)
        self.create_threshold_slider()  # Refresh threshold slider
        
        # Check for KRONOS and launch detection if found
        if self._check_kronos_in_dirname():
            self.launch_detection_automatically()

    def update_wafer(self):
        """Update the appearance of radio buttons based on the existing
        subdirectories in the specified directory."""
        if self.dirname:
            # List the subdirectories in the specified directory
            subdirs = [d for d in os.listdir(self.dirname) if
                       os.path.isdir(os.path.join(self.dirname, d))]

            # If there are no subdirectories, search for wafers in KLARF files
            wafer_ids = []
            if not subdirs:
                wafer_ids = self.extract_wafer_ids_from_klarf()

            # Update the style of radio buttons based on the subdirectory presence
            for number in range(1, 27):
                radio_button = self.radio_vars.get(number)
                if radio_button:
                    if str(number) in subdirs or number in wafer_ids:
                        radio_button.setStyleSheet(WAFER_BUTTON_EXISTING_STYLE)
                    else:
                        radio_button.setStyleSheet(WAFER_BUTTON_MISSING_STYLE)
        else:
            # Default style for all radio buttons if no directory is specified
            for number in range(1, 27):
                radio_button = self.radio_vars.get(number)
                radio_button.setStyleSheet(WAFER_BUTTON_MISSING_STYLE)

    def extract_wafer_ids_from_klarf(self):
        """Extract wafer IDs from KLARF files (.001) that contain COMPLUS4T."""
        wafer_ids = []
        
        if not self.dirname:
            return wafer_ids
        
        # Search for .001 files
        try:
            files = [f for f in os.listdir(self.dirname) 
                    if f.endswith('.001') and os.path.isfile(os.path.join(self.dirname, f))]
            
            for file in files:
                file_path = os.path.join(self.dirname, file)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        
                        # Check if file contains "COMPLUS4T"
                        if 'COMPLUS4T' in content:
                            # Search for all lines with WaferID
                            # Pattern to extract number in quotes after WaferID
                            pattern = r'WaferID\s+"@(\d+)"'
                            matches = re.findall(pattern, content)
                            
                            # Add found IDs (converted to int)
                            for match in matches:
                                wafer_id = int(match)
                                if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                    wafer_ids.append(wafer_id)
                except Exception as e:
                    pass  # Error reading file
        
        except Exception as e:
            pass  # Error listing files
        
        return wafer_ids

    def create_wafer(self):
        """Create a grid of radio buttons for wafer slots with exclusive selection."""
        group_box = QGroupBox("Wafer Slots")  # Add a title to the group
        group_box.setStyleSheet(GROUP_BOX_STYLE)  

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)  # Reduce internal margins
        wafer_layout.setSpacing(5)  # Reduce spacing between widgets

        

        # Add radio buttons from 1 to 24, with 12 buttons per row
        for number in range(1, 27):
            radio_button = QRadioButton(str(number))
            radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)

            # Connect the radio button to a handler for exclusive selection
            radio_button.toggled.connect(self.get_selected_option)
            self.radio_vars[number] = radio_button

            # Calculate the row and column for each radio button in the layout
            row = (number - 1) // 13  # Row starts at 0
            col = (number - 1) % 13  # Column ranges from 0 to 12

            wafer_layout.addWidget(radio_button, row, col)

        group_box.setLayout(wafer_layout)

        # Add the QGroupBox to the main layout (updated position - takes 2 rows)
        self.layout.addWidget(group_box, 1, 0, 2, 3)

    def get_selected_option(self):
        """Ensure only one radio button is selected at a time and track the selected button."""
        selected_number = None  # Variable to store the selected radio button number

        # Iterate over all radio buttons
        for number, radio_button in self.radio_vars.items():
            if radio_button.isChecked():
                selected_number = number  # Track the currently selected radio button

        if selected_number is not None:
            self.selected_option = selected_number  # Store the selected option for further use
            return self.selected_option

    def image_radiobuttons(self):
        """Create a grid of radio buttons or slider for image type selection."""
        # Remove old widget if it exists
        if self.image_group_box is not None:
            self.layout.removeWidget(self.image_group_box)
            self.image_group_box.deleteLater()
            self.image_group_box = None
        
        # Reset variables
        self.image_slider = None
        self.table_vars = None
        self.slider_value = 0
        
        # Check if COMPLUS4T mode
        is_complus4t = self._check_complus4t_in_dirname()
        # Check if KRONOS mode
        is_kronos = self._check_kronos_in_dirname()
        
        # Change title based on mode
        title = "Defect Size (um)" if (is_complus4t or is_kronos) else "Image type"
        group_box = QGroupBox(title)
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        self.image_group_box = group_box
        
        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)
        
        if is_complus4t or is_kronos:
            # COMPLUS4T mode: create slider from 0 to 100 nm
            self.image_slider = QSlider(Qt.Horizontal)
            self.image_slider.setMinimum(0)
            self.image_slider.setMaximum(100)
            self.image_slider.setValue(0)
            self.image_slider.setTickPosition(QSlider.TicksBelow)
            self.image_slider.setTickInterval(10)
            self.image_slider.valueChanged.connect(self.on_slider_changed)
            
            self.slider_value_label = QLabel("0 um")
            self.slider_value_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: white;")
            self.slider_value_label.setFixedWidth(80)  # Fixed width for label
            
            wafer_layout.addWidget(self.image_slider, 0, 0, 1, 1)
            wafer_layout.addWidget(self.slider_value_label, 0, 1, 1, 1)
        else:
            # Normal mode: create radio buttons
            self.table_data = self.settings_window.get_table_data()
            number = len(self.table_data)
            
            self.table_vars = {}
            
            for i in range(number):
                label = str(self.table_data[i]["Scale"]) + " - " + str(
                    self.table_data[i]["Image Type"])
                radio_button = QRadioButton(label)
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self.get_selected_image)
                self.table_vars[i] = radio_button
                
                row = (i) // 4
                col = (i) % 4
                wafer_layout.addWidget(radio_button, row, col)
        
        group_box.setLayout(wafer_layout)
        self.layout.addWidget(group_box, 1, 4, 2, 1)  # Takes 2 rows
    
    def create_threshold_slider(self):
        """Create a threshold slider for image processing (1-255)."""
        # Remove old threshold slider if it exists
        if self.threshold_slider is not None or self.min_size_slider is not None:
            # Find and remove the threshold group box from layout
            for i in range(self.layout.count()):
                widget = self.layout.itemAt(i).widget()
                if widget and hasattr(widget, 'title') and widget.title() == "Threshold":
                    self.layout.removeWidget(widget)
                    widget.deleteLater()
                    break
        
        group_box = QGroupBox("Threshold")
        group_box.setStyleSheet(GROUP_BOX_STYLE)
        
        threshold_layout = QGridLayout()
        threshold_layout.setContentsMargins(2, 20, 2, 2)
        threshold_layout.setSpacing(5)
        
        # Create threshold slider (0-255)
        self.threshold_slider = QSlider(Qt.Horizontal)
        self.threshold_slider.setMinimum(0)
        self.threshold_slider.setMaximum(255)
        self.threshold_slider.setTickPosition(QSlider.TicksBelow)
        self.threshold_slider.setTickInterval(25)
        
        # Initialize threshold value and label BEFORE connecting signal
        self.threshold_value = 255  # Initialize threshold value to match slider default
        self.threshold_label = QLabel("255")
        self.threshold_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: #F5F5F5;")
        self.threshold_label.setFixedWidth(50)  # Fixed width for label
        
        # Connect signal AFTER initializing values
        self.threshold_slider.valueChanged.connect(self.on_threshold_changed)
        
        # Set slider value AFTER connecting signal (this will trigger on_threshold_changed)
        self.threshold_slider.setValue(255)  # Default threshold
        
        # Create label for threshold range (0-255) to the right of value label
        self.threshold_range_label = QLabel("(0-255)")
        self.threshold_range_label.setStyleSheet("color: black; font-size: 20px; background-color: #F5F5F5;")
        
        # Create min size slider (1-100)
        self.min_size_slider = QSlider(Qt.Horizontal)
        self.min_size_slider.setMinimum(1)
        self.min_size_slider.setMaximum(100)
        self.min_size_slider.setValue(2)  # Default min size
        self.min_size_slider.setTickPosition(QSlider.TicksBelow)
        self.min_size_slider.setTickInterval(10)
        self.min_size_slider.valueChanged.connect(self.on_min_size_changed)
        
        # Create label for min size value (to the right of slider)
        self.min_size_label = QLabel("2")
        self.min_size_label.setStyleSheet("color: black; font-size: 20px; font-weight: bold; background-color: #F5F5F5;")
        self.min_size_label.setFixedWidth(50)  # Fixed width for label
        
        # Create label for min size unit (um) to the right of value label
        self.min_size_unit_label = QLabel("(um)")
        self.min_size_unit_label.setStyleSheet("color: black; font-size: 20px; background-color: #F5F5F5;")
        
        # Add widgets to layout - labels to the right
        threshold_layout.addWidget(self.threshold_slider, 0, 0, 1, 1)
        threshold_layout.addWidget(self.threshold_label, 0, 1, 1, 1)
        threshold_layout.addWidget(self.threshold_range_label, 0, 2, 1, 1)
        threshold_layout.addWidget(self.min_size_slider, 1, 0, 1, 1)
        threshold_layout.addWidget(self.min_size_label, 1, 1, 1, 1)
        threshold_layout.addWidget(self.min_size_unit_label, 1, 2, 1, 1)
        
        group_box.setLayout(threshold_layout)
        
        # Add to main layout in position (1,3,2,1) - takes 2 rows
        self.layout.addWidget(group_box, 1, 3, 2, 1)
    
    def on_threshold_changed(self, value):
        """Handle threshold slider value changes."""
        self.threshold_value = value
        self.threshold_label.setText(str(value))
        
        # Trigger plot update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, '_update_plot'):
            self.plot_frame._update_plot()
        
        # Trigger image update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, 'show_image'):
            self.plot_frame.show_image()
    
    def on_min_size_changed(self, value):
        """Handle min size slider value changes."""
        self.min_size_value = value
        self.min_size_label.setText(str(value))
        
        # Trigger plot update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, '_update_plot'):
            self.plot_frame._update_plot()
        
        # Trigger image update if plot_frame is available
        if self.plot_frame and hasattr(self.plot_frame, 'show_image'):
            self.plot_frame.show_image()
    
    def get_threshold_value(self):
        """Get the current threshold value."""
        return self.threshold_value
    
    def get_min_size_value(self):
        """Get the current min size value."""
        return self.min_size_value
    
    def get_processing_parameters(self):
        """Get all processing parameters including threshold and min size."""
        return {
            'threshold': self.threshold_value,
            'min_size': self.min_size_value,
            'defect_size_threshold': self.slider_value if self.image_slider else None
        }
    
    def _check_complus4t_in_dirname(self):
        if not self.dirname or not os.path.exists(self.dirname):
            return False
        
        try:
            files = [f for f in os.listdir(self.dirname) 
                    if f.endswith('.001') and os.path.isfile(os.path.join(self.dirname, f))]
            
            for file in files:
                file_path = os.path.join(self.dirname, file)
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                        if 'COMPLUS4T' in content:
                            return True
                except Exception as e:
                    pass  # Error reading file
        except Exception as e:
            pass  # Error listing files
        
        return False
    
    def _check_kronos_in_dirname(self):
        """Check if KRONOS is present in KLARF files in the directory and subdirectories (only checks first 10 lines)."""
        print("\n[DEBUG] _check_kronos_in_dirname called")
        print(f"[DEBUG] dirname: {self.dirname}")
        
        if not self.dirname or not os.path.exists(self.dirname):
            print("[DEBUG] dirname is None or doesn't exist")
            return False
        
        print(f"[DEBUG] dirname exists: {os.path.exists(self.dirname)}")
        
        try:
            # Search in parent directory and all subdirectories
            files = []
            print(f"[DEBUG] Searching for .001 files in: {self.dirname}")
            
            # Check parent directory
            all_items = os.listdir(self.dirname)
            print(f"[DEBUG] Total items in parent directory: {len(all_items)}")
            for item in all_items:
                item_path = os.path.join(self.dirname, item)
                if os.path.isfile(item_path) and item.endswith('.001'):
                    files.append(item_path)
                    print(f"[DEBUG]   Found .001 file in parent: {item}")
                elif os.path.isdir(item_path):
                    print(f"[DEBUG]   Found subdirectory: {item}")
                    # Search in subdirectory
                    try:
                        sub_items = os.listdir(item_path)
                        for sub_item in sub_items:
                            sub_item_path = os.path.join(item_path, sub_item)
                            if os.path.isfile(sub_item_path) and sub_item.endswith('.001'):
                                files.append(sub_item_path)
                                print(f"[DEBUG]     Found .001 file in subdirectory {item}: {sub_item}")
                    except Exception as e:
                        print(f"[DEBUG]     Error reading subdirectory {item}: {e}")
            
            print(f"[DEBUG] Total .001 files found: {len(files)}")
            for f in files:
                print(f"[DEBUG]   - {f}")
            
            if not files:
                print("[DEBUG] No .001 files found")
                return False
            
            for file_path in files:
                print(f"[DEBUG] Checking file: {os.path.basename(file_path)}")
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        # Only read first 10 lines
                        for i, line in enumerate(f):
                            if i >= 10:  # Stop after 10 lines
                                print(f"[DEBUG]   Read {i+1} lines, stopping")
                                break
                            print(f"[DEBUG]   Line {i+1}: {line.strip()[:80]}")  # Print first 80 chars
                            if 'KRONOS' in line:
                                print(f"[DEBUG]   *** KRONOS FOUND in line {i+1}! ***")
                                return True
                    print(f"[DEBUG]   No KRONOS found in {os.path.basename(file_path)}")
                except Exception as e:
                    print(f"[DEBUG]   Error reading file {file_path}: {e}")
        except Exception as e:
            print(f"[DEBUG] Error listing files: {e}")
        
        print("[DEBUG] KRONOS not found in any .001 file")
        return False
    
    def launch_detection_automatically(self):
        """Launch detection automatically when KRONOS is detected."""
        from semapp.Processing.detection import Detection
        from PyQt5.QtWidgets import QMessageBox
        
        try:
            print("\n" + "="*60)
            print("KRONOS DETECTED - Launching automatic detection")
            print("="*60)
            
            # Initialize detector
            detector = Detection(dirname=self.dirname)
            
            # Find all subdirectories (1, 2, 3, etc.)
            subdirs = [d for d in os.listdir(self.dirname) 
                      if os.path.isdir(os.path.join(self.dirname, d)) and d.isdigit()]
            subdirs.sort(key=lambda x: int(x))
            
            if not subdirs:
                print("No numbered subdirectories found")
                return
            
            print(f"Found {len(subdirs)} subdirectories to process")
            
            # Process each subdirectory
            for subdir in subdirs:
                subdir_path = os.path.join(self.dirname, subdir)
                csv_path = os.path.join(subdir_path, "detection_results.csv")
                
                # Skip if already processed
                if os.path.exists(csv_path):
                    print(f"Skipping {subdir} (already has detection_results.csv)")
                    continue
                
                print(f"\nProcessing subdirectory: {subdir}")
                
                # Find TIFF files in subdirectory
                tiff_files = []
                for root, dirs, files in os.walk(subdir_path):
                    for file in files:
                        if file.lower().endswith(('.tif', '.tiff')):
                            tiff_files.append(os.path.join(root, file))
                
                if not tiff_files:
                    print(f"No TIFF files found in {subdir}")
                    continue
                
                # Accumulate all results for this subdirectory
                all_results = {}
                
                # Process each TIFF file
                for tiff_file in tiff_files:
                    print(f"  Processing: {os.path.basename(tiff_file)}")
                    file_results = detector.detect_numbers_in_tiff(tiff_file, verbose=False)
                    
                    # Store results with file path as key
                    all_results[tiff_file] = file_results
                
                # Save all results to CSV in the subdirectory (once per subdirectory)
                if all_results:
                    detector.save_results_to_csv(all_results, csv_path)
                    total_pages = sum(len(r) if isinstance(r, list) else 1 for r in all_results.values())
                    print(f"  Saved {total_pages} results from {len(all_results)} files to {csv_path}")
                
                print(f"Completed processing {subdir}")
            
            print("\n" + "="*60)
            print("AUTOMATIC DETECTION COMPLETED")
            print("="*60)
            
            # Show completion message
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"Automatic detection completed for {len(subdirs)} subdirectories")
            msg.setWindowTitle("Detection Complete")
            msg.exec_()
            
        except Exception as e:
            print(f"Error during automatic detection: {e}")
            import traceback
            traceback.print_exc()
            
            # Show error message
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Warning)
            msg.setText(f"Error during detection: {str(e)}")
            msg.setWindowTitle("Detection Error")
            msg.exec_()
    
    def on_slider_changed(self, value):
        """Handle slider value changes and trigger plot update."""
        self.slider_value = value
        self.slider_value_label.setText(f"{value} um")
        
        # Trigger plot refresh if plot_frame exists
        if self.plot_frame is not None:
            self.plot_frame._update_plot()

    def refresh_radiobuttons(self):
        """Recreates the radio buttons after updating the data in Settings."""
        self.image_radiobuttons()  # Call your method to recreate the radio buttons

    def get_selected_image(self):
        """Track the selected radio button or slider value."""
        # Check if in COMPLUS4T mode (slider)
        if self.image_slider is not None:
            # Return slider value (0-100) as image type
            return self.slider_value, 1
        
        # Normal mode: radio buttons
        selected_number = None
        if self.table_vars:
            n_types = len(self.table_vars.items())
            # Iterate over all radio buttons
            for number, radio_button in self.table_vars.items():
                if radio_button.isChecked():
                    selected_number = number
            
            if selected_number is not None:
                self.selected_image = selected_number
                return self.selected_image, n_types
        
        return None

    def create_radiobuttons(self):
        """Create radio buttons for tools and a settings button."""

        # Create a QGroupBox for "Functions (Wafer)"
        frame = QGroupBox("Functions (Wafer)")
        frame.setStyleSheet(GROUP_BOX_STYLE)

        frame_layout = QGridLayout(frame)

        # Add radio buttons to the frame layout
        frame_layout.addWidget(self.split_rename, 0, 0)
        frame_layout.addWidget(self.threshold, 1, 0)
        frame_layout.addWidget(self.mapping, 2, 0)
        frame_layout.setContentsMargins(5, 20, 5, 5)
        # Add the frame to the main layout
        self.layout.addWidget(frame, 0, 2)  # Add frame to main layout

        # Add buttons to the shared button group
        self.button_group.addButton(self.split_rename)
        self.button_group.addButton(self.threshold)
        self.button_group.addButton(self.mapping)

    def create_radiobuttons_all(self):
        """Create radio buttons for tools and a settings button."""

        # Create a QGroupBox for "Functions (Lot)"
        frame = QGroupBox("Functions (Lot)")
        frame.setStyleSheet(GROUP_BOX_STYLE)

        frame_layout = QGridLayout(frame)

        # Add radio buttons to the frame layout
        frame_layout.addWidget(self.split_rename_all, 0, 0)
        frame_layout.addWidget(self.threshold_all, 1, 0)
        frame_layout.addWidget(self.mapping_all, 2, 0)

        frame_layout.setContentsMargins(5, 20, 5, 5)
        # Add the frame to the main layout
        self.layout.addWidget(frame, 0, 3)  # Add frame to main layout

        # Add buttons to the shared button group
        self.button_group.addButton(self.split_rename_all)
        self.button_group.addButton(self.threshold_all)
        self.button_group.addButton(self.mapping_all)

    
    def create_radiobuttons_other(self):
        """Create radio buttons for tools and a settings button."""

        # Create a QGroupBox for "Functions (Other)"
        frame = QGroupBox("Functions (Other)")
        frame.setStyleSheet(GROUP_BOX_STYLE)

        frame_layout = QGridLayout(frame)

        # Add radio buttons to the frame layout
        frame_layout.addWidget(self.create_folder, 0, 0)
        frame_layout.addWidget(self.clean, 1, 0)
        frame_layout.addWidget(self.clean_all, 2, 0)
        frame_layout.setContentsMargins(5, 20, 5, 5)

        # Add the frame to the main layout
        self.layout.addWidget(frame, 0, 1)  # Add frame to main layout

        # Add buttons to the shared button group
        self.button_group.addButton(self.create_folder)
        self.button_group.addButton(self.clean)
        self.button_group.addButton(self.clean_all)

    def select_folder(self):
        """Select a parent folder"""
        folder = QFileDialog.getExistingDirectory(self, "Select a Folder")

        if folder:
            self.dirname = folder
            max_characters = 20  # Set character limit

            # Truncate text if it exceeds the limit
            display_text = self.dirname if len(
                self.dirname) <= max_characters else self.dirname[
                                                     :max_characters] + '...'
            self.folder_path_label.setText(display_text)

    def create_run_button(self):
        """Create a button to run data processing"""

        # Create the QPushButton
        self.run_button = QPushButton("Run function")
        self.run_button.setStyleSheet(RUN_BUTTON_STYLE)
        self.run_button.setFixedWidth(150)
        self.run_button.clicked.connect(self.run_data_processing)
        
        # Store reference for enabling/disabling
        self.all_buttons.append(self.run_button)

        # Add the button to the layout at position (0, 3)
        self.layout.addWidget(self.run_button, 0, 5)
    
    def set_buttons_enabled(self, enabled):
        """
        Enable or disable all buttons and radio buttons.
        
        Args:
            enabled: Boolean, True to enable, False to disable
        """
        # Enable/disable all push buttons
        for button in self.all_buttons:
            if button:
                button.setEnabled(enabled)
        
        # Enable/disable all radio buttons
        for radio_button in self.all_radio_buttons:
            if radio_button:
                radio_button.setEnabled(enabled)
        
        # Enable/disable tool radio buttons
        tool_radiobuttons = [
            self.split_rename, self.split_rename_all, self.clean_all,
            self.create_folder, self.threshold, self.mapping,
            self.threshold_all, self.mapping_all, self.clean
        ]
        for radiobutton in tool_radiobuttons:
            if radiobutton:
                radiobutton.setEnabled(enabled)
        
        # Enable/disable wafer radio buttons
        for radio_button in self.radio_vars.values():
            if radio_button:
                radio_button.setEnabled(enabled)

    def run_data_processing(self):
        """Handles photoluminescence data processing and updates progress."""

        scale_data = self.new_folder + os.sep + "settings_data.json"
        wafer_number= self.get_selected_option()


        if not self.dirname or not any([self.clean.isChecked()
                                        or not self.split_rename.isChecked()
                                        or not self.clean_all.isChecked()
                                        or not self.split_rename_all.isChecked()
                                        or self.threshold.isChecked()
                                        or self.mapping.isChecked()
                                        or self.threshold_all.isChecked()
                                        or self.mapping_all.isChecked()
                                        ]):
            show_toast(self, "Please select a folder and a function", 
                      duration=2000, notification_type="warning")
            return
        
        # Disable all buttons and set wait cursor
        self.set_buttons_enabled(False)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        
        try:
            # Show toast notification
            show_toast(self, "Processing in progress...", 
                      duration=1000, notification_type="info")

            # Initialize processing classes
            sem_class = Process(self.dirname, wafer=wafer_number, scale = scale_data)
            total_steps = 0
            if self.split_rename.isChecked():
                total_steps = 3
            if self.clean.isChecked():
                total_steps = 1

            if self.split_rename_all.isChecked():
                total_steps = 3
            if self.clean_all.isChecked():
                total_steps = 1
            if self.create_folder.isChecked():
                total_steps = 1

            if self.threshold.isChecked():
                total_steps = 1
            if self.mapping.isChecked():
                total_steps = 1
            if self.threshold_all.isChecked():
                total_steps = 1
            if self.mapping_all.isChecked():
                total_steps = 1


            progress_dialog = QProgressDialog("Data processing in progress...",
                                              "Cancel", 0, total_steps, self)

            font = QFont()
            font.setPointSize(20)  # Set the font size to 14
            # (or any size you prefer)
            progress_dialog.setFont(font)

            progress_dialog.setWindowTitle("Processing")
            progress_dialog.setWindowModality(Qt.ApplicationModal)
            progress_dialog.setAutoClose(
                False)  # Ensure the dialog is not closed automatically
            progress_dialog.setCancelButton(None)  # Hide the cancel button
            progress_dialog.resize(400, 150)  # Set a larger size for the dialog

            progress_dialog.show()

            QApplication.processEvents()

            def execute_with_timer(task_name, task_function, *args, **kwargs):
                """Executes a task and displays the time taken."""
                start_time = time.time()
                progress_dialog.setLabelText(task_name)
                QApplication.processEvents()  # Ensures the interface is updated
                
                # For long-running tasks, we need to process events periodically
                # This is especially important for rename operations
                task_function(*args, **kwargs)
                
                # Process events one more time after task completion
                QApplication.processEvents()
                
                elapsed_time = time.time() - start_time
                pass  # Task completed

            if self.split_rename.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean)
                execute_with_timer("Create folders",
                                   sem_class.organize_and_rename_files)

                execute_with_timer("Split w/ tag", sem_class.split_tiff)
                execute_with_timer("Rename w/ tag", sem_class.rename)
                self.update_wafer()

            if self.split_rename_all.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean_all)
                execute_with_timer("Create folders",
                                   sem_class.organize_and_rename_files)

                execute_with_timer("Split w/ tag", sem_class.split_tiff_all)
                execute_with_timer("Rename w/ tag", sem_class.rename_all)
                self.update_wafer()

            if self.clean.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean)

            if self.clean_all.isChecked():
                execute_with_timer("Cleaning of folders", sem_class.clean_all)

            if self.create_folder.isChecked():
                execute_with_timer("Create folders", sem_class.organize_and_rename_files)
                self.update_wafer()

            if self.threshold.isChecked():
                execute_with_timer("Threshold processing", self.process_threshold_wafer)
            
            if self.mapping.isChecked():
                execute_with_timer("Mapping processing", self.process_mapping_wafer)
            
            if self.threshold_all.isChecked():
                execute_with_timer("Threshold processing (all)", self.process_threshold_all)
            
            if self.mapping_all.isChecked():
                execute_with_timer("Mapping processing (all)", self.process_mapping_all)

            progress_dialog.close()
            
            # Show success toast
            show_toast(self, "Processing completed successfully!", 
                      duration=3000, notification_type="success")
        
        except Exception as e:
            # Show error toast
            show_toast(self, f"Error during processing: {str(e)}", 
                      duration=4000, notification_type="error")
            print(f"Error in run_data_processing: {e}")
        
        finally:
            # Re-enable all buttons and restore cursor
            self.set_buttons_enabled(True)
            QApplication.restoreOverrideCursor()

    def process_threshold_wafer(self):
        """Process threshold for selected wafer."""
        selected_wafer = self.get_selected_option()
        if not selected_wafer:
            print("No wafer selected")
            return
        
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        # Create wafer path
        wafer_path = os.path.join(self.dirname, str(selected_wafer))
        
        if not os.path.exists(wafer_path):
            print(f"Wafer directory not found: {wafer_path}")
            return
        
        print(f"Processing threshold for wafer {selected_wafer}")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Path: {wafer_path}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Get coordinates and image settings from plot_frame
        if not hasattr(self.plot_frame, 'coordinates') or self.plot_frame.coordinates is None:
            print("No coordinates available in plot_frame")
            return
        
        # Get image type settings
        image_result = self.get_selected_image()
        if image_result is None:
            print("No image type selected")
            return
        
        image_type, number_type = image_result
        
        # Get scale from settings
        scale = "5x5"  # Default scale
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale = first_entry["Scale"]
        
        # Process directory (without plot_sem_data)
        results = processor.process_merged_tiff_directory(
            wafer_path, 
            self.plot_frame.coordinates,
            image_type,
            number_type,
            scale,
            show_results=False
        )
        
        # Consolidate CSV files
        consolidated_path = processor.consolidate_csv_files(wafer_path)
        
        print(f"Threshold processing completed for wafer {selected_wafer}")
        print(f"Consolidated CSV saved to: {consolidated_path}")
    
    def process_mapping_wafer(self):
        """Process mapping for selected wafer."""
        selected_wafer = self.get_selected_option()
        if not selected_wafer:
            print("No wafer selected")
            return
        
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        # Create wafer path
        wafer_path = os.path.join(self.dirname, str(selected_wafer))
        
        if not os.path.exists(wafer_path):
            print(f"Wafer directory not found: {wafer_path}")
            return
        
        print(f"Processing mapping for wafer {selected_wafer}")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Path: {wafer_path}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Plot SEM data (mapping)
        plot_files = processor.plot_sem_data(wafer_path, show_results=False)
        
        print(f"Mapping processing completed for wafer {selected_wafer}")
        print(f"Plot files created: {plot_files}")
    
    def process_threshold_all(self):
        """Process threshold for all wafers."""
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        print(f"Processing threshold for all wafers")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Parent directory: {self.dirname}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Get coordinates and image settings from plot_frame
        if not hasattr(self.plot_frame, 'coordinates') or self.plot_frame.coordinates is None:
            print("No coordinates available in plot_frame")
            return
        
        # Get image type settings
        image_result = self.get_selected_image()
        if image_result is None:
            print("No image type selected")
            return
        
        image_type, number_type = image_result
        
        # Get scale from settings
        scale = "5x5"  # Default scale
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale = first_entry["Scale"]
        
        # Process parent directory (all wafers)
        results = processor.process_merged_tiff_directory(
            self.dirname, 
            self.plot_frame.coordinates,
            image_type,
            number_type,
            scale,
            show_results=False
        )
        
        # Consolidate CSV files
        consolidated_path = processor.consolidate_csv_files(self.dirname)
        
        print(f"Threshold processing completed for all wafers")
        print(f"Consolidated CSV saved to: {consolidated_path}")
    
    def process_mapping_all(self):
        """Process mapping for all wafers."""
        # Get parameters from sliders
        threshold = self.get_threshold_value()
        min_size = self.get_min_size_value()
        
        # Get image size from settings data
        image_size_um = 5.0  # Default value
        if hasattr(self, 'settings_window') and self.settings_window:
            settings_data = self.settings_window.data
            if settings_data and len(settings_data) > 0:
                first_entry = settings_data[0]
                if "Scale" in first_entry:
                    scale_str = first_entry["Scale"]
                    try:
                        if 'x' in scale_str:
                            image_size_um = float(scale_str.split('x')[0])
                        else:
                            image_size_um = float(scale_str)
                    except (ValueError, IndexError):
                        image_size_um = 5.0
        
        print(f"Processing mapping for all wafers")
        print(f"Parameters: threshold={threshold}, min_size={min_size}, image_size={image_size_um}")
        print(f"Parent directory: {self.dirname}")
        
        # Create processor with parameters from sliders
        from semapp.Processing.threshold import SEMThresholdProcessor
        processor = SEMThresholdProcessor(
            threshold=threshold,
            min_size=min_size,
            image_size_um=image_size_um,
            save_results=True,
            verbose=True
        )
        
        # Plot SEM data (mapping) for all wafers
        plot_files = processor.plot_sem_data(self.dirname, show_results=False)
        
        print(f"Mapping processing completed for all wafers")
        print(f"Plot files created: {plot_files}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    settings_window = SettingsWindow()
    settings_window.show()
    sys.exit(app.exec_())
