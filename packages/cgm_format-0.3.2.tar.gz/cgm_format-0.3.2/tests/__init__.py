"""Tests for cgm_format package."""

