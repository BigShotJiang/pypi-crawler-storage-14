"""FSSpec Toolset."""

from __future__ import annotations

from llmling_agent_toolsets.fsspec_toolset.toolset import FSSpecTools

__all__ = ["FSSpecTools"]
