"""Executable examples."""
