"""Example using agents as a tool."""

TITLE = "Download workers"
ICON = "octicon:download-16"
