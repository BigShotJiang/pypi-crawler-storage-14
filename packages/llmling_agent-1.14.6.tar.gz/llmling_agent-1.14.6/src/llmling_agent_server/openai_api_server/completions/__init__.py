"""Completions API."""
