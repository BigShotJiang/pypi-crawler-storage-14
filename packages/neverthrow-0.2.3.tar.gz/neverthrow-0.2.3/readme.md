# neverthrow.py

a smol implementation of the either monad for python
