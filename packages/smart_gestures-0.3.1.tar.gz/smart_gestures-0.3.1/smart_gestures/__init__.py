"""Smart Gesture Package

"""

from . import alphabet
from . import gestures

__all__ = ["alphabet", "gestures"]
