# coding: utf-8

"""
PostFinance Python SDK

This library allows to interact with the PostFinance payment service.

Copyright owner: Wallee AG
Website: https://www.postfinance.ch/en/private.html
Developer email: ecosystem-team@wallee.com

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""


from __future__ import annotations
import json
from enum import Enum
from typing_extensions import Self


class PaymentLinkAddressHandlingMode(str, Enum):
    """
    The address handling mode controls if the address is required and how it is enforced to be provided.
    """

    """
    allowed enum values
    """
    NOT_REQUIRED = 'NOT_REQUIRED'
    REQUIRED_IN_URL = 'REQUIRED_IN_URL'
    REQUIRED_ON_PAYMENT_PAGE = 'REQUIRED_ON_PAYMENT_PAGE'

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        """Create an instance of PaymentLinkAddressHandlingMode from a JSON string"""
        return cls(json.loads(json_str))


