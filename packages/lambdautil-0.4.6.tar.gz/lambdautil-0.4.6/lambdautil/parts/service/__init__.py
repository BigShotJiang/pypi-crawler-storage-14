main_code = '''\'\'\'
The code for an example AWS Lambda function integrated with API Gateway
\'\'\'
import os
import json
import datetime
import logging

from flask import request
from zevon import FlaskLambda

# LambdaUtil deployer expects this to be called \'lambda_handler\'
lambda_handler = FlaskLambda(__name__)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def create_json_dump(o):
    \'\'\'
    Another helper function for JSON serialization
    \'\'\'
    if isinstance(o, datetime.datetime):
        return str(o)

    if isinstance(o, datetime.date):
        return str(o)

    if isinstance(o, bytes):
        return o.decode('utf-8')

    return None


@lambda_handler.route(\'/\', methods=[\'GET\'])
def get_ok():
    \'\'\'
    Redirect to the README doc

    Args:
        None

    Returns:
        tuple of (body, status code, content type) that API Gateway understands
    \'\'\'
    logger.debug('get_ok() called')
    return (
        'OK',
        200,
        {'Content-Type': 'text/plain'}
    )


@lambda_handler.route(\'/doc\', methods=[\'GET\'])
def document():
    \'\'\'
    Redirect to the README doc

    Args:
        None

    Returns:
        tuple of (body, status code, content type) that API Gateway understands
    \'\'\'
    logger.debug('document() called')

    slash_html = \'\'\'<html xmlns="http://www.w3.org/1999/xhtml">
      <head>
        <title>Lambtool Readme</title>
        <meta http-equiv="refresh" content="0;URL='https://github.com/muckamuck/LambdaUtil/blob/master/README.md'" />
      </head>
      <body></body>
    </html>
    \'\'\'

    return (
        slash_html,
        200,
        {'Content-Type': 'text/html'}
    )


@lambda_handler.route(\'/answer\', methods=[\'GET\'])
def get_answer():
    \'\'\'
    Example of getting something from config parameters

    Args:
        None

    Returns:
        tuple of (body, status code, content type) that API Gateway understands
    \'\'\'
    logger.debug('get_answer() called')
    answer = os.environ.get(\'ANSWER\', \'0\')
    args = json.dumps(request.args.copy(), indent=2)
    msg = f\'answer = {answer}  args = {args}\'

    return (
        msg,
        200,
        {'Content-Type': 'text/plain'}
    )


@lambda_handler.route(\'/example\', methods=[\'GET\', \'POST\'])
def handle_example():
    \'\'\'
    A contrived example function that will return some meta-data about the
    invocation.

    Args:
        None

    Returns:
        tuple of (body, status code, content type) that API Gateway understands
    \'\'\'
    logger.debug('handle_example() called')
    data = {
        'form': request.form.copy(),
        'args': request.args.copy(),
        'json': request.json
    }
    return (
        json.dumps(data, indent=4, sort_keys=True),
        200,
        {'Content-Type': 'application/json'}
    )


@lambda_handler.route('/event', methods=['GET'])
def handle_event():
    \'\'\'
    Return the event as application/json

    Args:
        None

    Returns:
        tuple of (body, status code, content type) that API Gateway understands
    \'\'\'
    logger.debug('handle_event() called')
    return (
        json.dumps(lambda_handler.get_event(), default=create_json_dump, indent=2),
        200,
        {'Content-Type': 'application/json'}
    )


if __name__ == '__main__':
    lambda_handler.run(debug=True)
'''

requirements_txt = '''zevon>=0.3'''


if __name__ == '__main__':
    print(main_code, end='')
