import os
import shutil
import sys
import tomllib
import tomli_w

def get_init_config(path):
    if not os.path.exists(path):
        return {}
    with open(path, "rb") as f:
        return tomllib.load(f)

def cmake_project_init(project_name="", libs=[]):
    path = os.path.expanduser("~/.cpptools/default_init.toml")
    custom_config = get_init_config(path)
    path = os.path.join(os.path.dirname(__file__), "default.toml")
    default_config = get_init_config(path)
    if os.path.exists("cpptools.toml"):
        print("init failed cause cpptools.toml already exists")
        return

    if os.path.isdir("src"):
        print("init failed cause src directory already exists")
        return

    os.makedirs("src")
    with open("src/main.cpp", "w") as f:
        f.write("#include <iostream>\n")
        f.write(f"\nint main(int argc,char *argv[]) {{\n")
        f.write(f'    std::cout << "Hello, World!" << std::endl;\n')
        f.write("    return 0;\n")
        f.write("}\n")

    with open("cpptools.toml", "wb") as f:
        d = {}
        if project_name=="":
            project_name = custom_config.get("project_name", default_config.get("project_name", "demo"))
        d["project_name"] = project_name
        d["cmake_version"] = custom_config.get("cmake_version", default_config.get("cmake_version", "3.30"))
        d["cpp_version"] = custom_config.get("cpp_version", default_config.get("cpp_version", 23))
        d["generator"] = custom_config.get("generator", default_config.get("generator", "Ninja"))
        d["libs"] = {}
        for lib in libs:
            if lib in custom_config.get("libs", default_config.get("libs", {})):
                d["libs"][lib] = custom_config.get("libs", default_config.get("libs", {}))[lib]
        tomli_w.dump(d, f)

def cmake_project_configure():
    try:
        print("cpptools configure project...")
        if not os.path.exists("cpptools.toml"):
            print("configure failed cause cpptools.toml not found")
            return
        with open("cpptools.toml", "rb") as f:
            c = tomllib.load(f)

            with open("CMakeLists.txt", "w") as f:
                inc = []
                env = []
                lks = []
                project_name = c["project_name"]
                f.write(f"cmake_minimum_required(VERSION {c['cmake_version']})\n")
                f.write(f"\nset(project_name {project_name})\n")
                f.write("project(${project_name})\n")
                f.write(f"\nset(CMAKE_CXX_STANDARD {c['cpp_version']})\n")
                f.write("set(CMAKE_CXX_STANDARD_REQUIRED ON)\n")

                for lib in c["libs"].values():
                    f.write("\n")
                    name = lib["name"]
                    header_only = lib["header_only"]
                    home = lib["home"]

                    if name.lower() == "opencv":
                        f.write("set(OpenCV_RUNTIME vc16)\n")
                        f.write('set(OpenCV_ARCH "x64")\n')
                    elif name.lower() in ["qt", "qt6", "qt5"]:
                        f.write("set(CMAKE_AUTOMOC ON)\n")
                        f.write("set(CMAKE_AUTOUIC ON)\n")
                        f.write("set(CMAKE_AUTORCC ON)\n\n")

                    if header_only:
                        inc.append(home)
                    else:
                        components = lib.get("components", [])
                        bin = lib.get("bin", "")
                        lk = lib.get("links", [])
                        f.write(f"set({name}_DIR {home})\n")
                        if len(components) == 0:
                            f.write(f"find_package({name} REQUIRED)\n")
                        else:
                            f.write(f'find_package({name} COMPONENTS {" ".join(components)} REQUIRED)\n')
                        lks.extend(lk)
                        inc.append(f"${{{name}_INCLUDE_DIRS}}")
                        if bin:
                            env.append(bin)

                f.write('\nfile(GLOB src_files "src/*.cpp")\n')
                f.write("\nadd_executable(${project_name} ${src_files})\n")

                f.write(f"\ntarget_include_directories(${{project_name}} PRIVATE\n{' '*27}src\n{'\n'.join([' '*27 + i for i in inc])}\n{' '*27})\n")
                f.write(f"\ntarget_link_libraries(${{project_name}} PRIVATE\n{"\n".join([' '*22 + i for i in lks])}\n{' '*22})\n")

            os.makedirs(".vscode", exist_ok=True)
            with open(".vscode/launch.json", "w") as f:
                s = f"""
        {{
            // Use IntelliSense to learn about possible attributes.
            // Hover to view descriptions of existing attributes.
            // For more information, visit: https://go.microsoft.com/fwlink/?linkid=830387
            "version": "0.2.0",
            "configurations": [
                {{
                    "type": "lldb",
                    "request": "launch",
                    "name": "lldb {project_name}",
                    "program": "${{workspaceFolder}}/build/{project_name}.exe",
                    "args": [],
                    "cwd": "${{workspaceFolder}}/build",
                    "preLaunchTask": "CMake: build",
                    "env": {{
                        "PATH": "${{env:PATH}};{";".join(env)}"
                    }}
                }}
            ]
        }}"""

                f.write(s)

            with open(".vscode/settings.json", "w") as f:
                f.write(
                    f"""
        {{
            "cmake.environment": {{
                "PATH": "${{env:PATH}};{";".join(env)}"
            }}
        }}
        """
                )

            print("quick start configuration finished!")
    except Exception as e:
        print(e)
