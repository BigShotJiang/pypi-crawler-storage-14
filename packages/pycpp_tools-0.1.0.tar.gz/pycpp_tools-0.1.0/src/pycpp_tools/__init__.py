from .pybind11 import pybind11_init
from .general import cmake_project_init,cmake_project_configure
import argparse
import os
import shutil

def remove(path):
    try:
        if os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            shutil.rmtree(path)
    except:
        pass

def cpp_tools():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command")
    pybind11_parser = subparsers.add_parser("pybind11", help="pybind11 related operations")
    pybind11_parser.add_argument("--init", action="store_true", help="initialize a new pybind11 project")
    pybind11_parser.add_argument("--name", type=str, default="demo", help="the name of the project")
    clean_parser = subparsers.add_parser("clean", help="clean the directory")
    init_parser = subparsers.add_parser("init", help="initialize a new cmake c++ project")
    init_parser.add_argument("--name", type=str, default="demo", help="the name of the project")
    init_parser.add_argument("--libs", type=str, nargs="*", default=[], help="the libraries of the project (multiple allowed)")
    configure_parser = subparsers.add_parser("configure", help="configure the project")
    args = parser.parse_args()
    if args.command == "pybind11":
        if args.init:
            pybind11_init(args.name)
        else:
            pybind11_parser.print_help()
    elif args.command == "clean":
        for i in os.listdir("."):
            remove(i)
    elif args.command == "init":
        cmake_project_init(args.name,args.libs)
    elif args.command == "configure":
        cmake_project_configure()
    else:
        parser.print_help()
