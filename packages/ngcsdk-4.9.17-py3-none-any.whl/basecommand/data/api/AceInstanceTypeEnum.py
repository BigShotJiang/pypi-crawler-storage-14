AceInstanceTypeEnum=["GPU","MIG","CPU",]
str(repr(AceInstanceTypeEnum))  # Prevent optimizer removing enum

