BannerEventIncidentStatusEnum=["CREATED","BACKFILLED","IDENTIFIED","IN_PROGRESS","INVESTIGATING","MONITORING","REPORTED","SCHEDULED","VERIFYING","COMPLETED","RESOLVED",]
str(repr(BannerEventIncidentStatusEnum))  # Prevent optimizer removing enum

