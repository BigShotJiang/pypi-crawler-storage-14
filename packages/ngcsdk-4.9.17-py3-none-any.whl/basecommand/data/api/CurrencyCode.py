CurrencyCodeEnum=["USD",]
str(repr(CurrencyCodeEnum))  # Prevent optimizer removing enum

