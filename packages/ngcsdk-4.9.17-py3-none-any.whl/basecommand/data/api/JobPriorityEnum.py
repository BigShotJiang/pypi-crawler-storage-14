JobPriorityEnum=["HIGH","NORMAL","LOW",]
str(repr(JobPriorityEnum))  # Prevent optimizer removing enum

