AceTypeEnum=["PERSONAL","PRIVATE","PUBLIC",]
str(repr(AceTypeEnum))  # Prevent optimizer removing enum

