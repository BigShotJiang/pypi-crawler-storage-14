ReleaseTypeEnum=["BETA","GA","EA","FEATURE","PRODUCTION","LTSB",]
str(repr(ReleaseTypeEnum))  # Prevent optimizer removing enum

