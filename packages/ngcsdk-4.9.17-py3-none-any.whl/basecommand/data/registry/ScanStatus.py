ScanStatusEnum=["NOT_SCANNED","IN_PROGRESS","SCAN_COMPLETE","SCAN_FAILED",]
str(repr(ScanStatusEnum))  # Prevent optimizer removing enum

