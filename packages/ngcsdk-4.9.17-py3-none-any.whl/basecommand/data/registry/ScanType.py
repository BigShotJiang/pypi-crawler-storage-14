ScanTypeEnum=["VULNERABILITY","LICENSE",]
str(repr(ScanTypeEnum))  # Prevent optimizer removing enum

