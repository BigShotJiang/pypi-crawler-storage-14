# Pyarmor 9.0.0 (basic), 009666, 2025-12-01T20:11:41.185053
from .pyarmor_runtime import __pyarmor__
