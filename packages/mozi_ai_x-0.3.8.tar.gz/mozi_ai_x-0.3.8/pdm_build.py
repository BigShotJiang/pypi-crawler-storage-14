from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from pdm.backend.hooks.base import Context


def pdm_build_hook_enabled(context: Context) -> bool:  # type: ignore[override]
    # Enable for all targets so we can obfuscate both wheel and sdist.
    return True


def pdm_build_initialize(context: Context) -> None:  # type: ignore[override]
    # Obfuscate for both wheel and sdist targets.
    if context.target not in {"wheel", "sdist"}:
        return

    # Prepare obfuscated sources into ${BUILD_DIR}/src
    build_src = context.ensure_build_dir() / "src"
    src_root = context.root / "src"
    pkg_src = src_root / "mozi_ai_x"

    # Clean previous obf output to avoid mixing
    if build_src.exists():
        shutil.rmtree(build_src)
    build_pkg = build_src / "mozi_ai_x"
    build_pkg.parent.mkdir(parents=True, exist_ok=True)

    # Obfuscate whole package once and store runtime inside the package (-i)
    py = _python_executable()
    pyarmor_cmd = py.with_name("pyarmor.exe" if os.name == "nt" else "pyarmor")
    cmd = [
        os.fspath(pyarmor_cmd),
        "gen",
        "-i",  # store runtime inside package and adjust imports
        "--prefix",
        "mozi_ai_x",
        "--outer",
        "--exclude",
        "*/__init__.py",
        "--output",
        os.fspath(build_src),
        "-r",
        os.fspath(pkg_src),
    ]
    print(f"[pdm_build] Running: {' '.join(cmd)}")
    try:
        subprocess.check_call(cmd, cwd=os.fspath(context.root))
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            "PyArmor obfuscation failed. Ensure license is valid and network reachable for license verification."
        ) from e

    # Duplicate runtime to build root as well to satisfy relative import
    # used by PyArmor when prefixing. Some generated package runtimes may
    # re-export from parent-level runtime.
    for rt in (build_pkg).glob("pyarmor_runtime_*"):
        dst = context.build_dir / rt.name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(rt, dst)

    # Fix package runtime import to avoid circular relative import.
    # Replace in mozi_ai_x/pyarmor_runtime_XXXX/__init__.py:
    #   from ..pyarmor_runtime_XXXX import __pyarmor__
    # with:
    #   from .pyarmor_runtime import __pyarmor__
    for rt in (build_pkg).glob("pyarmor_runtime_*/__init__.py"):
        try:
            text = rt.read_text(encoding="utf-8")
        except Exception:
            continue
        if "from ..pyarmor_runtime_" in text and "__pyarmor__" in text:
            fixed = []
            for line in text.splitlines():
                if line.strip().startswith("from ..pyarmor_runtime_") and "__pyarmor__" in line:
                    fixed.append("from .pyarmor_runtime import __pyarmor__")
                else:
                    fixed.append(line)
            rt.write_text("\n".join(fixed), encoding="utf-8")

    # Restore plain __init__.py files to avoid running __pyarmor__ at package
    # import boundaries. This reduces sensitivity to import context.
    for init_src in pkg_src.rglob("__init__.py"):
        rel = init_src.relative_to(pkg_src)
        init_dst = build_pkg / rel
        if init_dst.exists():
            shutil.copy2(init_src, init_dst)

    # Ensure py.typed is present
    typed_src = pkg_src / "py.typed"
    if typed_src.exists():
        shutil.copy2(typed_src, build_pkg / "py.typed")


def pdm_build_update_files(context: Context, files: dict[str, Path]) -> None:  # type: ignore[override]
    # Replace the entire mozi_ai_x package with obfuscated one from ${BUILD_DIR}/src/mozi_ai_x
    build_src = context.build_dir / "src"
    build_pkg = build_src / "mozi_ai_x"

    # Drop any existing entries for mozi_ai_x from file map
    for key in list(files.keys()):
        k = Path(key).as_posix()
        if k.startswith("mozi_ai_x/") or k.startswith("src/mozi_ai_x/"):
            files.pop(key, None)

    # Add everything from build_pkg recursively
    for p in build_pkg.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(build_src).as_posix()  # mozi_ai_x/...
        files[rel] = p


def _python_executable() -> Path:
    # Use current Python executable
    return Path(os.environ.get("PDM_PYTHON", os.sys.executable))
