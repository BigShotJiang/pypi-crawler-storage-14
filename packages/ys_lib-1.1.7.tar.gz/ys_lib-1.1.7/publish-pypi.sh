#!/bin/bash
set -ex
flit publish --pypirc .pypirc --repository pypi