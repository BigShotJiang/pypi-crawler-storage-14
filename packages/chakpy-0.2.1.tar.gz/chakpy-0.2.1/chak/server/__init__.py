"""
Chak Server Module

Provides WebSocket and HTTP gateway for Chak AI SDK.
"""

from .app import serve

__all__ = ["serve"]
