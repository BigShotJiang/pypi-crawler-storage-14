# How-To Guides

This section contains practical, focused guides for common pico-fastapi scenarios.

- [Session Shopping Cart](session-cart.md)
- [Apply Settings (DI)](settings-applied.md)
- [WebSocket Chat](websocket-chat.md)

