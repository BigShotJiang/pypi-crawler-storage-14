import discord
from discord.ui import View, Button
from typing import List, Optional

class _PaginatorView(View):
    def __init__(self, ctx_interaction_or_message, pages: List[discord.Embed], *, timeout: Optional[float] = 60.0):
        super().__init__(timeout=timeout)
        self.pages = pages
        self.index = 0
        self.owner_id = None
        # sometimes used with interaction or message
        try:
            self.owner_id = ctx_interaction_or_message.user.id
        except Exception:
            try:
                self.owner_id = ctx_interaction_or_message.author.id
            except Exception:
                self.owner_id = None

    async def _update(self, interaction: discord.Interaction):
        await interaction.response.edit_message(embed=self.pages[self.index], view=self)

    @discord.ui.button(label="<", style=discord.ButtonStyle.secondary)
    async def prev(self, button: Button, interaction: discord.Interaction):
        if self.owner_id and interaction.user.id != self.owner_id:
            return await interaction.response.send_message("Not for you", ephemeral=True)
        self.index = max(0, self.index - 1)
        await self._update(interaction)

    @discord.ui.button(label=">", style=discord.ButtonStyle.secondary)
    async def next(self, button: Button, interaction: discord.Interaction):
        if self.owner_id and interaction.user.id != self.owner_id:
            return await interaction.response.send_message("Not for you", ephemeral=True)
        self.index = min(len(self.pages) - 1, self.index + 1)
        await self._update(interaction)

async def paginator(interaction: discord.Interaction, pages: List[discord.Embed], *, ephemeral: bool = False):
    view = _PaginatorView(interaction, pages)
    await interaction.response.send_message(embed=pages[0], view=view, ephemeral=ephemeral)
