import discord
from typing import Optional, List, Dict, Any

def create_embed(title: Optional[str] = None, description: Optional[str] = None) -> discord.Embed:
    e = discord.Embed(title=title or discord.Embed.Empty, description=description or discord.Embed.Empty)
    return e

# small helper to add fields more ergonomically
def add_fields(embed: discord.Embed, fields: List[Dict[str, Any]]) -> discord.Embed:
    for f in fields:
        embed.add_field(name=f.get("name", "\u200b"), value=f.get("value", "\u200b"), inline=f.get("inline", False))
    return embed
