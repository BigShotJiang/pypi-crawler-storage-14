# SolarVox Bot Helper (Python)
A lightweight helper package for building Discord bots using **discord.py 2.x**, inspired by the SolarVox NPM package.

This library provides:
- 🚀 Easy bot creation (`create_bot`)
- 📦 Automatic command & event loader
- ⏱️ Cooldown Manager (per-user, per-command)
- 🧱 Simple JSON database
- 🎨 Embed builder & field helpers
- 📑 Button paginator with Discord UI

Perfect for clean, modular bot development.

---

## ⭐ Installation

```
pip install solarvox-bot-helper-py
```



---

## 📁 Folder Structure

Typical bot layout:

```
mybot/
├── main.py
├── commands/
│   └── ping.py
└── events/
    └── ready.py
```

---

## 🚀 Quick Start

### **main.py**
```python
from solarvox_bot_helper import create_bot
from discord import Intents
import os

TOKEN = os.getenv("TOKEN")

bot = create_bot(
    token=TOKEN,
    commands_path="./commands",
    events_path="./events",
    intents=Intents.default()
)

bot.run(TOKEN)
```

---

### **commands/ping.py**
```python
import discord
from discord import app_commands
from solarvox_bot_helper import create_embed

async def setup(bot):
    @app_commands.command(name="ping", description="Ping command")
    async def ping(interaction: discord.Interaction):
        await interaction.response.send_message(
            embed=create_embed("Pong!", "Bot is online")
        )

    bot.tree.add_command(ping)
```

---

### **events/ready.py**
```python
name = "ready"

async def run(bot, *args):
    print(f"{bot.user} is online!")
```

---

## 🧩 Extra Utilities

### Cooldowns
```python
from solarvox_bot_helper import CooldownManager
cd = CooldownManager()

if not cd.try_use("ping", user.id, 5000):
    return await interaction.response.send_message("Cooldown!")
```

---

### JSON Database
```python
from solarvox_bot_helper import JSONDatabase

db = JSONDatabase("data.json")
db.set("coins", 100)
print(db.get("coins"))
```

---

### Paginator
```python
from solarvox_bot_helper import paginator

await paginator(interaction, pages=[embed1, embed2, embed3])
```

---

## 🛠️ Contributing
Pull requests and improvements are welcome!

---

## 📄 License
MIT License
