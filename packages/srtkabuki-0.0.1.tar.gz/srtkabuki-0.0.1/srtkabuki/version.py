MAJOR = 0
MINOR = 0
MINI = 1

version = f"{MAJOR}.{MINOR}.{MINI}"
