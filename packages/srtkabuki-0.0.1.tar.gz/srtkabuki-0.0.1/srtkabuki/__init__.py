"""
srtkabuki.__init__.py
"""

from .srtkabuki import SRTKabuki
from .dgram import datagramer
