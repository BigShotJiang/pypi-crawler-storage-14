# PDF 页面转图片 MCP 服务

仅提供一个工具：`convert_pdf_to_images`，用于将 PDF 页面渲染为 JPEG/PNG 图片。

## 运行

```bash
uv run pdf-mcp-server
```

或：

```bash
$env:PYTHONPATH="src"; python -c "import pdf_mcp.server; pdf_mcp.server.main()"
```

## 工具：convert_pdf_to_images

- `input_path` (str) 输入 PDF 文件路径
- `output_dir` (str) 输出目录路径
- `format` (str) 图片格式：`jpeg` 或 `png`
- `quality` (int) JPEG 质量 (1-100)
- `dpi` (int) 图片渲染 DPI
- `pages` (str, 可选) 页面范围，如 `"1-3,5,7-10"` 或 `"all"`
- `prefix` (str, 可选) 输出文件名前缀

## 依赖

- `fastmcp`
- `pymupdf` (fitz)

## License

MIT
