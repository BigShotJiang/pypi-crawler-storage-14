from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import fitz  # type: ignore

from .utils import ensure_directory, ensure_parent_dir, get_file_stats, parse_page_range, resolve_output_dir


@dataclass
class ImageFile:
    path: Path
    size: int


@dataclass
class PDFToImageResult:
    input_path: Path
    output_dir: Path
    format: str
    quality: int
    dpi: int
    page_numbers: list[int]
    files: list[ImageFile]


def _to_path(path_like: str) -> Path:
    return Path(path_like).expanduser().resolve()


def _render_page_to_image(
    page: fitz.Page,
    image_format: str,
    dpi: int,
    quality: int,
) -> bytes:
    scale = dpi / 72.0
    matrix = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=matrix, alpha=image_format == "png")
    if image_format == "png":
        return pix.tobytes("png")
    return pix.tobytes("jpg", jpg_quality=quality)


def pdf_to_image(
    input_path: str,
    output_dir: str,
    format: str = "jpeg",
    quality: int = 80,
    dpi: int = 150,
    pages: Optional[str] = None,
    prefix: Optional[str] = None,
) -> PDFToImageResult:
    image_format = format.lower()
    if image_format not in {"jpeg", "jpg", "png"}:
        raise ValueError("图片格式仅支持 jpeg 或 png")
    if image_format == "jpg":
        image_format = "jpeg"

    source_path = _to_path(input_path)
    if not source_path.exists():
        raise FileNotFoundError(f"文件不存在: {source_path}")
    if source_path.suffix.lower() != ".pdf":
        raise ValueError("输入文件必须为PDF")

    doc = fitz.open(source_path)
    total_pages = doc.page_count
    if total_pages == 0:
        raise ValueError("输入PDF为空")

    page_numbers = parse_page_range(pages, total_pages)
    resolved_output_dir = resolve_output_dir(source_path, output_dir)
    ensure_directory(resolved_output_dir)
    base_name = prefix or source_path.stem

    files: list[ImageFile] = []
    for page_number in page_numbers:
        page = doc.load_page(page_number - 1)
        image_bytes = _render_page_to_image(page, image_format, dpi, quality)
        output_name = f"{base_name}_{page_number:03d}.{ 'jpg' if image_format == 'jpeg' else 'png'}"
        output_path = resolved_output_dir / output_name
        ensure_parent_dir(output_path)
        output_path.write_bytes(image_bytes)
        stats = get_file_stats(output_path)
        files.append(ImageFile(path=output_path, size=stats.size))

    doc.close()

    return PDFToImageResult(
        input_path=source_path,
        output_dir=resolved_output_dir,
        format=image_format,
        quality=quality,
        dpi=dpi,
        page_numbers=page_numbers,
        files=files,
    )
