"""PDF MCP Server using FastMCP."""

from __future__ import annotations

import logging
from typing import Optional

from fastmcp import FastMCP

from .pdf_tools import pdf_to_image

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("PDF 页面转图片")


@mcp.tool()
def convert_pdf_to_images(
    input_path: str,
    output_dir: str,
    format: str = "jpeg",
    quality: int = 80,
    dpi: int = 150,
    pages: Optional[str] = None,
    prefix: Optional[str] = None,
) -> str:
    """将PDF页面转换为图片。
    
    Args:
        input_path: 输入PDF文件路径
        output_dir: 输出目录路径
        format: 图片格式，"jpeg" 或 "png"
        quality: JPEG质量 (1-100)
        dpi: 图片分辨率
        pages: 页面范围，如 "1-3,5,7-10" 或 "all"
        prefix: 输出文件名前缀
    
    Returns:
        转换结果的详细信息
    """
    
    try:
        result = pdf_to_image(input_path, output_dir, format, quality, dpi, pages, prefix)
        total_size = sum(f.size for f in result.files)
        from .utils import format_file_size
        
        return (
            f"✅ PDF转图片成功\n"
            f"输出目录: {result.output_dir}\n"
            f"格式: {result.format.upper()}\n"
            f"DPI: {result.dpi}\n"
            f"质量: {result.quality}\n"
            f"转换页数: {len(result.page_numbers)}\n"
            f"生成文件数: {len(result.files)}\n"
            f"总大小: {format_file_size(total_size)}"
        )
    
    except Exception as e:
        logger.error(f"转换PDF失败: {e}")
        raise


def main():
    """启动MCP服务器。"""
    mcp.run()


if __name__ == "__main__":
    main()
