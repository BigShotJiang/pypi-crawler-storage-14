SELECT
    groname AS group_name,
    grosysid AS group_id,
    grosysid AS group_list
FROM pg_group
