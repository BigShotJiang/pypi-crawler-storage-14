TablesColumns = tuple[list[dict], list[dict]]
