SELECT
    canvas_key,
    type,
    role,
    user_key
FROM `{project_id}.{dataset_id}.canvas_permissions`
