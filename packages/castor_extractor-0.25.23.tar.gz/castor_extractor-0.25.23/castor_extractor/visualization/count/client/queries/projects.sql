SELECT
    key,
    name
FROM `{project_id}.{dataset_id}.projects`

