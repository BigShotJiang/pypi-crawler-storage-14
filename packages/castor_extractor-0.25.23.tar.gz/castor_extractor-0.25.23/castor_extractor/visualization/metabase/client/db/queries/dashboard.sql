SELECT
    *
FROM
    {schema}.report_dashboard
