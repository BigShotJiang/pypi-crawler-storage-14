# Changelog

All notable changes to the Kusari Inspector MCP Server will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2024-11-21

### Added
- Initial public release
- MCP server wrapping Kusari CLI for security scanning
- Automatic Kusari CLI installation and updates
- OAuth2 authentication with Kusari Cloud
- Scan local changes (diff-based scanning)
- Full repository security audit
- Real-time scan progress updates
- Clickable console URLs for detailed results
- Support for Python 3.10+
- Automatic installation helper (`kusari-inspector-setup`)
- Environment variable and config file support
- Comprehensive error handling and user feedback

### Security Scanning Features
- Vulnerability detection (deps.dev, govulncheck, Trivy)
- Secret scanning (TruffleHog)
- SAST analysis (Semgrep)
- SBOM generation (cdxgen)
- License compliance checking
- OpenSSF Scorecard analysis

### Infrastructure
- AWS Lambda execution for all scans
- Secure token storage in `~/.kusari/tokens.json`
- Cross-platform support (macOS, Linux)
- Automatic CLI version management

[Unreleased]: https://github.com/kusaridev/kusari-inspector-mcp/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/kusaridev/kusari-inspector-mcp/releases/tag/v0.1.0
