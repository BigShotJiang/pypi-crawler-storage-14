#!/usr/bin/env python3
"""
Installation helper for Kusari Inspector MCP Server
Supports multiple MCP clients: Claude Code, Cursor, Windsurf, Cline, etc.
"""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, Optional, Tuple


# Client configuration
CLIENT_CONFIGS = {
    "claude": {
        "name": "Claude Code",
        "cli_command": "claude",
        "config_paths": {
            "darwin": Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
            "linux": Path.home() / ".config" / "claude" / "claude_desktop_config.json",
            "win32": Path.home() / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json",
        },
        "supports_cli": True,
        "server_key": "kusari-inspector",
    },
    "cursor": {
        "name": "Cursor",
        "cli_command": None,
        "config_paths": {
            "darwin": Path.home() / "Library" / "Application Support" / "Cursor" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "linux": Path.home() / ".config" / "Cursor" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "win32": Path.home() / "AppData" / "Roaming" / "Cursor" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
    "windsurf": {
        "name": "Windsurf",
        "cli_command": None,
        "config_paths": {
            "darwin": Path.home() / "Library" / "Application Support" / "Windsurf" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "linux": Path.home() / ".config" / "Windsurf" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "win32": Path.home() / "AppData" / "Roaming" / "Windsurf" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
    "cline": {
        "name": "Cline (VS Code)",
        "cli_command": None,
        "config_paths": {
            "darwin": Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "linux": Path.home() / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "win32": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
    "vscode": {
        "name": "VS Code (Cline)",
        "cli_command": None,
        "config_paths": {
            "darwin": Path.home() / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "linux": Path.home() / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
            "win32": Path.home() / "AppData" / "Roaming" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
    "copilot": {
        "name": "GitHub Copilot CLI",
        "cli_command": None,
        "config_paths": {
            # GitHub Copilot doesn't currently support MCP, but keeping for future
            "darwin": Path.home() / "Library" / "Application Support" / "GitHub Copilot" / "mcp_config.json",
            "linux": Path.home() / ".config" / "github-copilot" / "mcp_config.json",
            "win32": Path.home() / "AppData" / "Roaming" / "GitHub Copilot" / "mcp_config.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
    "continue": {
        "name": "Continue (VS Code)",
        "cli_command": None,
        "config_paths": {
            "darwin": Path.home() / ".continue" / "config.json",
            "linux": Path.home() / ".continue" / "config.json",
            "win32": Path.home() / ".continue" / "config.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
    "antigravity": {
        "name": "Antigravity",
        "cli_command": None,
        "config_paths": {
            "darwin": Path.home() / "Library" / "Application Support" / "Antigravity" / "mcp_config.json",
            "linux": Path.home() / ".config" / "antigravity" / "mcp_config.json",
            "win32": Path.home() / "AppData" / "Roaming" / "Antigravity" / "mcp_config.json",
        },
        "supports_cli": False,
        "server_key": "kusari-inspector",
    },
}


def find_python_executable() -> str:
    """Find the Python executable being used"""
    return sys.executable


def get_client_config(client: str) -> Dict:
    """Get configuration for a specific client"""
    if client not in CLIENT_CONFIGS:
        raise ValueError(f"Unknown client: {client}. Supported clients: {', '.join(CLIENT_CONFIGS.keys())}")
    return CLIENT_CONFIGS[client]


def get_config_path(client: str) -> Path:
    """Get the config file path for the current platform"""
    config = get_client_config(client)
    platform = sys.platform
    if platform not in config["config_paths"]:
        raise ValueError(f"Unsupported platform: {platform}")
    return config["config_paths"][platform]


def create_server_config() -> Dict:
    """Create the MCP server configuration"""
    python_path = find_python_executable()
    return {
        "command": python_path,
        "args": ["-m", "kusari_inspector_mcp.server"],
        "env": {
            "CONSOLE_URL": "https://console.us.kusari.cloud/",
            "API_ENDPOINT": "https://platform.api.us.kusari.cloud/"
        }
    }


def install_via_cli(client: str, config: Dict, verbose: bool = False) -> bool:
    """Install using client's CLI if available"""
    cli_cmd = config["cli_command"]
    if not cli_cmd:
        return False

    # Check if CLI is available
    if not shutil.which(cli_cmd):
        if verbose:
            print(f"'{cli_cmd}' CLI not found, falling back to manual configuration")
        return False

    python_path = find_python_executable()
    server_key = config["server_key"]

    try:
        # Register with client CLI
        result = subprocess.run(
            [
                cli_cmd, "mcp", "add",
                "--transport", "stdio",
                server_key,
                "--",
                python_path,
                "-m", "kusari_inspector_mcp.server"
            ],
            capture_output=True,
            text=True,
            check=False
        )

        if result.returncode == 0:
            return True
        else:
            if verbose:
                print(f"CLI registration failed: {result.stderr}")
            return False

    except Exception as e:
        if verbose:
            print(f"Failed to use CLI: {e}")
        return False


def install_via_config_file(client: str, config: Dict, verbose: bool = False) -> bool:
    """Install by editing the config file"""
    try:
        config_path = get_config_path(client)
        server_key = config["server_key"]
        server_config = create_server_config()

        # Ensure directory exists
        config_path.parent.mkdir(parents=True, exist_ok=True)

        # Read existing config or create new one
        if config_path.exists():
            with open(config_path, 'r') as f:
                try:
                    full_config = json.load(f)
                except json.JSONDecodeError:
                    full_config = {}
        else:
            full_config = {}

        # Handle Continue's special config format
        if client == "continue":
            # Continue uses experimental.modelContextProtocolServers array format
            if "experimental" not in full_config:
                full_config["experimental"] = {}
            if "modelContextProtocolServers" not in full_config["experimental"]:
                full_config["experimental"]["modelContextProtocolServers"] = []

            # Create Continue-specific server config
            continue_server = {
                "name": server_key,
                "transport": {
                    "type": "stdio",
                    "command": server_config["command"],
                    "args": server_config["args"]
                }
            }

            # Add env vars if present
            if server_config.get("env"):
                continue_server["transport"]["env"] = server_config["env"]

            # Check if already configured
            servers = full_config["experimental"]["modelContextProtocolServers"]
            existing_idx = next((i for i, s in enumerate(servers) if s.get("name") == server_key), None)

            if existing_idx is not None:
                servers[existing_idx] = continue_server
            else:
                servers.append(continue_server)
        else:
            # Standard MCP config format (Claude, Cursor, Windsurf, etc.)
            if "mcpServers" not in full_config:
                full_config["mcpServers"] = {}

            full_config["mcpServers"][server_key] = server_config

        # Write back the config
        with open(config_path, 'w') as f:
            json.dump(full_config, f, indent=2)

        if verbose:
            print(f"Updated config file: {config_path}")

        return True

    except Exception as e:
        print(f"ERROR: Failed to update config file: {e}")
        return False


def show_post_install_instructions(client: str, config: Dict):
    """Show instructions after installation"""
    client_name = config["name"]

    print("\n" + "=" * 70)
    print("Installation Complete!")
    print("=" * 70)

    print(f"\nKusari Inspector has been configured for {client_name}.")
    print("\nNext steps:")

    if client == "claude":
        print("1. Reload VS Code: Cmd+Shift+P → 'Developer: Reload Window'")
        print("2. Check MCP status - you should see 'kusari-inspector' running")
        print("3. Ask Claude to scan: 'Claude, scan my local changes for security issues'")
    elif client in ["cursor", "windsurf"]:
        print(f"1. Restart {client_name}")
        print("2. Open the Cline extension")
        print("3. Check MCP settings to verify 'kusari-inspector' is listed")
        print("4. Ask Cline to scan: 'Scan my code for security vulnerabilities'")
    elif client in ["cline", "vscode"]:
        print("1. Reload VS Code: Cmd+Shift+P → 'Developer: Reload Window'")
        print("2. Open the Cline extension")
        print("3. Check MCP settings to verify 'kusari-inspector' is listed")
        print("4. Ask Cline to scan: 'Scan my code for security vulnerabilities'")
    elif client == "continue":
        print("1. Reload VS Code: Cmd+Shift+P → 'Developer: Reload Window'")
        print("2. Open the Continue extension")
        print("3. In agent mode, type '@' and select 'MCP' to access Kusari tools")
        print("4. Ask Continue to scan: 'Scan my code for security vulnerabilities'")
        print("\nNote: MCP can only be used in agent mode in Continue")
    elif client == "copilot":
        print("Note: GitHub Copilot MCP support is experimental")
        print("1. Restart your IDE")
        print("2. Check Copilot settings for MCP configuration")
    elif client == "antigravity":
        print("1. Restart Antigravity")
        print("2. Check MCP settings to verify 'kusari-inspector' is configured")

    print("\nFor authentication:")
    print("- On first use, your browser will open to authenticate with Kusari")
    print("- Credentials are saved to ~/.kusari/tokens.json")

    print("\n" + "=" * 70)


def show_manual_instructions(client: str, config: Dict):
    """Show manual installation instructions"""
    config_path = get_config_path(client)
    server_config = create_server_config()
    server_key = config["server_key"]

    print("\n" + "=" * 70)
    print("MANUAL INSTALLATION")
    print("=" * 70)

    print(f"\nIf automatic installation failed, manually edit the config file:")
    print(f"\nConfig file location:")
    print(f"  {config_path}")

    print(f"\nAdd this to the 'mcpServers' section:")
    print(json.dumps({server_key: server_config}, indent=2))

    print("\nThen restart your IDE/application.")


def install_for_client(client: str, verbose: bool = False) -> bool:
    """Install the MCP server for a specific client"""
    print("=" * 70)
    print(f"Kusari Inspector MCP Server - Installation")
    print("=" * 70)
    print()

    # Validate Python version
    if sys.version_info < (3, 10):
        print(f"ERROR: Python 3.10+ required (you have {sys.version_info.major}.{sys.version_info.minor})")
        return False

    # Get client configuration
    try:
        config = get_client_config(client)
    except ValueError as e:
        print(f"ERROR: {e}")
        return False

    client_name = config["name"]
    print(f"Configuring for: {client_name}")
    print(f"Python: {sys.version_info.major}.{sys.version_info.minor}")
    print(f"Executable: {find_python_executable()}")
    print()

    # Try CLI installation first if supported
    if config["supports_cli"]:
        print(f"Attempting automatic installation via {config['cli_command']} CLI...")
        if install_via_cli(client, config, verbose):
            print(f"✓ Successfully registered with {client_name} CLI")
            show_post_install_instructions(client, config)
            return True
        else:
            print(f"CLI installation failed, trying manual config file method...")

    # Fall back to config file method
    print(f"Configuring {client_name} via config file...")
    if install_via_config_file(client, config, verbose):
        print(f"✓ Successfully configured {client_name}")
        show_post_install_instructions(client, config)
        return True
    else:
        show_manual_instructions(client, config)
        return False


def uninstall_for_client(client: str) -> bool:
    """Uninstall the MCP server from a specific client"""
    print("=" * 70)
    print(f"Kusari Inspector MCP Server - Uninstallation")
    print("=" * 70)
    print()

    try:
        config = get_client_config(client)
        config_path = get_config_path(client)
        server_key = config["server_key"]

        if not config_path.exists():
            print(f"No configuration found for {config['name']}")
            return True

        # Read config file
        with open(config_path, 'r') as f:
            full_config = json.load(f)

        removed = False

        # Handle Continue's special format
        if client == "continue":
            if "experimental" in full_config and "modelContextProtocolServers" in full_config["experimental"]:
                servers = full_config["experimental"]["modelContextProtocolServers"]
                # Remove server with matching name
                new_servers = [s for s in servers if s.get("name") != server_key]
                if len(new_servers) < len(servers):
                    full_config["experimental"]["modelContextProtocolServers"] = new_servers
                    removed = True
        else:
            # Standard MCP config format
            if "mcpServers" in full_config and server_key in full_config["mcpServers"]:
                del full_config["mcpServers"][server_key]
                removed = True

        if removed:
            # Write back
            with open(config_path, 'w') as f:
                json.dump(full_config, f, indent=2)

            print(f"✓ Removed Kusari Inspector from {config['name']}")
            print(f"\nRestart {config['name']} for changes to take effect.")
            return True
        else:
            print(f"Kusari Inspector was not configured for {config['name']}")
            return True

    except Exception as e:
        print(f"ERROR: Failed to uninstall: {e}")
        return False


def main():
    """Main installation helper (legacy compatibility)"""
    # This is kept for backward compatibility with `kusari-inspector-setup` command
    return install_for_client("claude", verbose=True)


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
