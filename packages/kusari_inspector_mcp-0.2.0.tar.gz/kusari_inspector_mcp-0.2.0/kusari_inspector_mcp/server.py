#!/usr/bin/env python3
"""
Kusari Inspector MCP Server
Provides security scanning tools to Claude Code via the Kusari CLI
"""

import argparse
import asyncio
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio

# Use relative imports when running as a package
try:
    from .cli_wrapper import KusariCLI, ScanResult, ScanStatus
except ImportError:
    # Fallback for direct execution
    from cli_wrapper import KusariCLI, ScanResult, ScanStatus


# Load configuration
def load_config() -> Dict[str, Any]:
    """Load configuration from config.yaml or environment variables"""
    config_path = Path(__file__).parent / "config.yaml"

    # Default configuration
    config = {
        "console_url": os.getenv("CONSOLE_URL", "https://console.us.kusari.cloud/"),
        "api_endpoint": os.getenv("API_ENDPOINT", "https://platform.api.us.kusari.cloud/"),
        "auth_endpoint": os.getenv("AUTH_ENDPOINT", "https://auth.us.kusari.cloud/"),
        "client_id": os.getenv("CLIENT_ID", "4lnk6jccl3hc4lkcudai5lt36u"),
        "verbose": os.getenv("VERBOSE", "false").lower() == "true",
    }

    # Override with config file if it exists
    if config_path.exists():
        with open(config_path, 'r') as f:
            file_config = yaml.safe_load(f)
            if file_config:
                # Update config with values from file
                if "api_endpoint" in file_config:
                    config["api_endpoint"] = file_config["api_endpoint"]
                if "console_url" in file_config:
                    config["console_url"] = file_config["console_url"]
                if "auth_endpoint" in file_config:
                    config["auth_endpoint"] = file_config["auth_endpoint"]
                if "client_id" in file_config:
                    config["client_id"] = file_config["client_id"]
                if "verbose" in file_config:
                    config["verbose"] = file_config["verbose"]

    return config


# Initialize server
app = Server("kusari-inspector")
config = load_config()
cli = KusariCLI(config)


@app.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools"""
    return [
        Tool(
            name="scan_local_changes",
            description="Scan uncommitted changes in the current git repository for security vulnerabilities, secrets, and SAST issues. This performs a diff-based scan of your local changes using AWS Lambda.",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_path": {
                        "type": "string",
                        "description": "Path to the git repository to scan. Defaults to current directory."
                    },
                    "base_ref": {
                        "type": "string",
                        "description": "Base git reference for diff (e.g., 'HEAD', 'main', 'origin/main'). Defaults to 'HEAD'.",
                        "default": "HEAD"
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="scan_full_repo",
            description="Perform a comprehensive security audit of the entire repository including OpenSSF Scorecard analysis, full dependency scanning, vulnerability detection, and SAST analysis using AWS Lambda. This is more thorough but takes longer than a diff scan.",
            inputSchema={
                "type": "object",
                "properties": {
                    "repo_path": {
                        "type": "string",
                        "description": "Path to the git repository to scan. Defaults to current directory."
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="check_scan_status",
            description="Check the status of a previously submitted scan. Use the scan_id returned from a previous scan operation.",
            inputSchema={
                "type": "object",
                "properties": {
                    "scan_id": {
                        "type": "string",
                        "description": "The scan ID returned from a previous scan operation"
                    }
                },
                "required": ["scan_id"]
            }
        ),
        Tool(
            name="get_scan_results",
            description="Retrieve detailed results from a completed scan. Returns comprehensive security analysis including vulnerabilities, secrets, SAST findings, and recommendations.",
            inputSchema={
                "type": "object",
                "properties": {
                    "scan_id": {
                        "type": "string",
                        "description": "The scan ID to retrieve results for"
                    }
                },
                "required": ["scan_id"]
            }
        ),
        Tool(
            name="scan_dependencies",
            description="Scan dependencies from a specific bundle file. Advanced usage for custom workflows.",
            inputSchema={
                "type": "object",
                "properties": {
                    "bundle_path": {
                        "type": "string",
                        "description": "Path to the Kusari Inspector bundle tarball (.tar.bz2)"
                    },
                    "scan_type": {
                        "type": "string",
                        "enum": ["diff", "full"],
                        "description": "Type of scan to perform",
                        "default": "diff"
                    }
                },
                "required": ["bundle_path"]
            }
        )
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls"""

    try:
        if name == "scan_local_changes":
            return await handle_scan_local_changes(arguments)

        elif name == "scan_full_repo":
            return await handle_scan_full_repo(arguments)

        elif name == "check_scan_status":
            return await handle_check_scan_status(arguments)

        elif name == "get_scan_results":
            return await handle_get_scan_results(arguments)

        elif name == "scan_dependencies":
            return await handle_scan_dependencies(arguments)

        else:
            return [TextContent(
                type="text",
                text=f"Unknown tool: {name}"
            )]

    except Exception as e:
        return [TextContent(
            type="text",
            text=f"Error executing {name}: {str(e)}\n\nPlease check your configuration and try again."
        )]


async def handle_scan_local_changes(arguments: dict) -> list[TextContent]:
    """Handle scan_local_changes tool"""
    repo_path = arguments.get("repo_path", os.getcwd())
    base_ref = arguments.get("base_ref", "HEAD")

    try:
        # Run the scan (authentication and workspace checks handled internally)
        result = cli.scan_diff(
            repo_path=repo_path,
            base_ref=base_ref,
            wait=True,
            output_format="markdown"
        )

        return [TextContent(
            type="text",
            text=format_scan_result(result, repo_path)
        )]

    except Exception as e:
        return [TextContent(
            type="text",
            text=f"Failed to scan local changes: {str(e)}"
        )]


async def handle_scan_full_repo(arguments: dict) -> list[TextContent]:
    """Handle scan_full_repo tool"""
    repo_path = arguments.get("repo_path", os.getcwd())

    try:
        # Run the scan (authentication and workspace checks handled internally)
        result = cli.scan_full(
            repo_path=repo_path,
            wait=True
        )

        return [TextContent(
            type="text",
            text=format_scan_result(result, repo_path)
        )]

    except Exception as e:
        return [TextContent(
            type="text",
            text=f"Failed to scan repository: {str(e)}"
        )]


async def handle_check_scan_status(arguments: dict) -> list[TextContent]:
    """Handle check_scan_status tool"""
    scan_id = arguments["scan_id"]

    # Note: The CLI-based approach doesn't support async status checking
    # since the CLI waits for results. This tool is kept for API compatibility.
    return [TextContent(
        type="text",
        text="Status checking is not available in CLI mode. The CLI waits for scan completion automatically."
    )]


async def handle_get_scan_results(arguments: dict) -> list[TextContent]:
    """Handle get_scan_results tool"""
    scan_id = arguments["scan_id"]

    # Note: The CLI-based approach doesn't support retrieving past results
    # since the CLI outputs results directly. This tool is kept for API compatibility.
    return [TextContent(
        type="text",
        text="Result retrieval is not available in CLI mode. Scan results are returned immediately when the scan completes."
    )]


async def handle_scan_dependencies(arguments: dict) -> list[TextContent]:
    """Handle scan_dependencies tool"""
    bundle_path = arguments["bundle_path"]
    scan_type = arguments.get("scan_type", "diff")

    # Note: The CLI doesn't support scanning pre-built bundles directly
    # This would require expanding the bundle and scanning the repo
    return [TextContent(
        type="text",
        text="Bundle scanning is not available in CLI mode. Please use scan_local_changes or scan_full_repo instead."
    )]


def format_scan_result(result: ScanResult, repo_path: Optional[str] = None) -> str:
    """Format scan result for display"""
    output = []

    # Display console URL prominently if available
    if result.console_url:
        output.append("=" * 80)
        output.append("📊 View Detailed Results in Kusari Console:")
        output.append(f"   {result.console_url}")
        output.append("=" * 80)
        output.append("")

    if result.error:
        output.append("ERROR:")
        output.append(result.error)
        output.append("")
        return "\n".join(output)

    # Display analysis results if completed
    if result.status == ScanStatus.SUCCESS and result.results:
        output.append(result.results)

    return "\n".join(output)


async def run_server():
    """Run the MCP server via stdio"""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options()
        )


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        prog="kusari-inspector-mcp",
        description="Kusari Inspector MCP Server - Security scanning for AI assistants"
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Install subcommand
    install_parser = subparsers.add_parser(
        'install',
        help='Install and configure the MCP server for a specific client'
    )
    install_parser.add_argument(
        'client',
        choices=['claude', 'cursor', 'windsurf', 'cline', 'vscode', 'copilot'],
        help='The MCP client to configure (e.g., claude, cursor, windsurf)'
    )
    install_parser.add_argument(
        '--verbose',
        action='store_true',
        help='Enable verbose output during installation'
    )

    # Uninstall subcommand (for future use)
    uninstall_parser = subparsers.add_parser(
        'uninstall',
        help='Remove the MCP server configuration from a client'
    )
    uninstall_parser.add_argument(
        'client',
        choices=['claude', 'cursor', 'windsurf', 'cline', 'vscode', 'copilot'],
        help='The MCP client to remove configuration from'
    )

    args = parser.parse_args()

    # If no command specified, run the MCP server (default behavior for stdio)
    if args.command is None:
        asyncio.run(run_server())
    elif args.command == 'install':
        # Import here to avoid circular imports
        try:
            from .install_helper import install_for_client
        except ImportError:
            from install_helper import install_for_client

        success = install_for_client(args.client, verbose=getattr(args, 'verbose', False))
        sys.exit(0 if success else 1)
    elif args.command == 'uninstall':
        try:
            from .install_helper import uninstall_for_client
        except ImportError:
            from install_helper import uninstall_for_client

        success = uninstall_for_client(args.client)
        sys.exit(0 if success else 1)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
