#!/usr/bin/env python3
"""
Kusari CLI Wrapper
Wraps the Kusari CLI binary and provides a Python interface for the MCP server
"""

import json
import os
import re
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional, Dict, Any

try:
    from .cli_installer import KusariCLIInstaller
except ImportError:
    from cli_installer import KusariCLIInstaller


class ScanStatus(Enum):
    """Scan status enumeration"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    ERROR = "error"


@dataclass
class ScanResult:
    """Result from a scan operation"""
    scan_id: str
    status: ScanStatus
    results: Optional[str] = None
    error: Optional[str] = None
    message: Optional[str] = None
    console_url: Optional[str] = None  # Link to view results in web console


class KusariCLI:
    """Wrapper for the Kusari CLI binary"""

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the CLI wrapper

        Args:
            config: Configuration dictionary with console_url, api_endpoint, auth_endpoint, client_id, etc.
        """
        self.config = config
        self.installer = KusariCLIInstaller()

        # Ensure CLI is installed
        self.cli_path = self.installer.ensure_installed()

        # Extract configuration
        self.console_url = config.get("console_url", "https://console.us.kusari.cloud/")
        self.platform_url = config.get("api_endpoint", "https://platform.api.us.kusari.cloud/")
        self.auth_endpoint = config.get("auth_endpoint", "https://auth.us.kusari.cloud/")
        self.client_id = config.get("client_id", "4lnk6jccl3hc4lkcudai5lt36u")
        self.verbose = config.get("verbose", False)

    def _run_command(
        self,
        args: list[str],
        cwd: Optional[str] = None,
        capture_output: bool = True,
        timeout: int = 600,
        stream_output: bool = True
    ) -> subprocess.CompletedProcess:
        """
        Run a kusari CLI command with real-time output streaming

        Args:
            args: Command arguments (without 'kusari' prefix)
            cwd: Working directory for the command
            capture_output: Whether to capture stdout/stderr
            timeout: Command timeout in seconds
            stream_output: Whether to stream output in real-time

        Returns:
            CompletedProcess object

        Raises:
            subprocess.TimeoutExpired: If command times out
            subprocess.CalledProcessError: If command fails
        """
        cmd = [str(self.cli_path)] + args

        # Add global flags
        if self.console_url:
            cmd.extend(["--console-url", self.console_url])
        if self.verbose:
            cmd.append("--verbose")

        try:
            if stream_output and capture_output:
                # Stream output in real-time while capturing it using threads
                import threading
                import time
                from queue import Queue

                process = subprocess.Popen(
                    cmd,
                    cwd=cwd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    bufsize=1,  # Line buffered
                    universal_newlines=True
                )

                stdout_lines = []
                stderr_lines = []

                # Queues to collect output from threads
                stdout_queue = Queue()
                stderr_queue = Queue()

                def read_stream(stream, queue, line_list):
                    """Read from stream and add to queue and list"""
                    try:
                        for line in iter(stream.readline, ''):
                            if line:
                                line = line.rstrip('\n\r')
                                # Capture ALL lines, even empty ones
                                queue.put(line)
                                line_list.append(line)
                    except Exception as e:
                        # Log exception for debugging
                        import sys
                        print(f"Error reading stream: {e}", file=sys.stderr)
                    finally:
                        stream.close()

                # Start reader threads
                stdout_thread = threading.Thread(
                    target=read_stream,
                    args=(process.stdout, stdout_queue, stdout_lines)
                )
                stderr_thread = threading.Thread(
                    target=read_stream,
                    args=(process.stderr, stderr_queue, stderr_lines)
                )

                stdout_thread.daemon = True
                stderr_thread.daemon = True
                stdout_thread.start()
                stderr_thread.start()

                start_time = time.time()

                # Wait for process to complete with timeout
                while process.poll() is None:
                    if timeout and (time.time() - start_time) > timeout:
                        process.kill()
                        raise subprocess.TimeoutExpired(cmd, timeout)
                    time.sleep(0.1)

                # Wait for threads to finish reading
                stdout_thread.join(timeout=1)
                stderr_thread.join(timeout=1)

                returncode = process.wait()

                # Create CompletedProcess object
                result = subprocess.CompletedProcess(
                    args=cmd,
                    returncode=returncode,
                    stdout='\n'.join(stdout_lines),
                    stderr='\n'.join(stderr_lines)
                )
                return result
            else:
                # Original behavior without streaming
                result = subprocess.run(
                    cmd,
                    cwd=cwd,
                    capture_output=capture_output,
                    text=True,
                    timeout=timeout,
                    check=False  # Don't raise on non-zero exit
                )
                return result
        except subprocess.TimeoutExpired as e:
            raise RuntimeError(f"Command timed out after {timeout}s: {' '.join(cmd)}") from e
        except Exception as e:
            raise RuntimeError(f"Failed to run command: {e}") from e

    def auth_login(self) -> bool:
        """
        Authenticate with Kusari Platform

        Returns:
            True if login successful, False otherwise
        """
        try:
            # Build auth login command with platform URL, auth endpoint and client ID
            args = ["auth", "login"]

            # Add platform URL if configured
            if self.platform_url:
                args.extend(["--platform-url", self.platform_url])

            # Add auth endpoint if configured
            if self.auth_endpoint:
                args.extend(["--auth-endpoint", self.auth_endpoint])

            # Add client ID if configured
            if self.client_id:
                args.extend(["--client-id", self.client_id])

            result = self._run_command(
                args,
                timeout=300  # 5 minutes for interactive login
            )

            return result.returncode == 0

        except Exception:
            return False

    def is_workspace_configured(self) -> bool:
        """
        Check if workspace is configured (workspace.json exists)

        Returns:
            True if workspace.json exists, False otherwise
        """
        workspace_file = Path.home() / ".kusari" / "workspace.json"
        return workspace_file.exists()

    def is_authenticated(self) -> bool:
        """
        Check if user is authenticated with a valid (non-expired) token

        Returns:
            True if authenticated with valid token, False otherwise
        """
        token_file = Path.home() / ".kusari" / "tokens.json"

        if not token_file.exists():
            return False

        # Check if token is expired
        try:
            with open(token_file, 'r') as f:
                tokens = json.load(f)

            # Check if we have access_token and expiry
            if not tokens.get("access_token"):
                return False

            # Check expiry if available
            expiry_str = tokens.get("expiry")
            if expiry_str:
                # Parse ISO 8601 format: "2025-11-24T15:30:00Z"
                try:
                    expiry = datetime.fromisoformat(expiry_str.replace('Z', '+00:00'))
                    now = datetime.now(timezone.utc)

                    # Add 5 minute buffer to refresh before actual expiry
                    if expiry <= now:
                        return False

                except (ValueError, AttributeError):
                    # If we can't parse expiry, consider token invalid to be safe
                    return False

            return True

        except (json.JSONDecodeError, IOError):
            return False

    def ensure_authenticated(self) -> tuple[bool, Optional[str]]:
        """
        Ensure user is authenticated and workspace is configured

        Returns:
            Tuple of (success: bool, error_message: Optional[str])
            - (True, None) if authenticated and workspace configured
            - (False, error_message) if workspace not configured or auth fails
        """
        # First check if workspace is configured (required for first-time setup)
        if not self.is_workspace_configured():
            error_msg = (
                "❌ Workspace not configured!\n\n"
                "This appears to be your first time using kusari-cli. You must complete the initial setup in your terminal:\n\n"
                "1. Run: kusari auth login\n"
                "2. Follow the prompts to authenticate and select your workspace\n"
                "3. After completing the setup, your workspace will be cached and you can use the MCP server\n\n"
                "Once you've completed the terminal setup, restart the MCP server."
            )
            return False, error_msg

        # Check authentication - workspace is already configured
        if self.is_authenticated():
            return True, None

        # Token is expired or missing - automatically trigger login
        # This is safe because workspace.json exists (user has logged in before)
        print("Authentication required (token expired or missing). Starting login flow...")
        success = self.auth_login()
        if success:
            return True, None
        else:
            return False, "Authentication failed. Please try again."

    def _extract_console_url(self, output: str) -> Optional[str]:
        """
        Extract the console URL from CLI output

        Args:
            output: CLI output text

        Returns:
            Console URL if found, None otherwise
        """
        # Look for pattern:
        # "Once completed, you can see results at: https://console.us.kusari.cloud/workspaces/..."
        pattern = r'Once completed, you can see results at:\s*(https://console\.[a-z]+\.kusari\.cloud/[^\s]+)'

        match = re.search(pattern, output)
        if match:
            return match.group(1)

        return None

    def scan_diff(
        self,
        repo_path: str,
        base_ref: str = "HEAD",
        wait: bool = True,
        output_format: str = "markdown",
        _retry: bool = True
    ) -> ScanResult:
        """
        Scan repository changes (diff-based scan)

        Args:
            repo_path: Path to the git repository
            base_ref: Git reference to compare against (default: HEAD)
            wait: Wait for scan to complete (default: True)
            output_format: Output format - "markdown" or "sarif" (default: markdown)
            _retry: Internal flag to prevent infinite retry loops

        Returns:
            ScanResult object with scan results
        """
        # Ensure authentication and workspace configuration before scanning
        auth_success, auth_error = self.ensure_authenticated()
        if not auth_success:
            return ScanResult(
                scan_id="cli-scan",
                status=ScanStatus.ERROR,
                error=auth_error or "Authentication failed. Unable to proceed with scan.",
                message="Authentication required"
            )

        try:
            args = [
                "repo", "scan",
                repo_path,
                base_ref,
                "--platform-url", self.platform_url,
                "--output-format", output_format
            ]

            if wait:
                args.append("--wait")
            else:
                args.extend(["--wait=false"])

            result = self._run_command(args, timeout=600)

            if result.returncode == 0:
                # Success - parse the output
                output = result.stdout.strip()
                stderr_output = result.stderr.strip()

                # Extract console URL from both stdout and stderr (CLI outputs to stderr)
                combined_output = output + "\n" + stderr_output
                console_url = self._extract_console_url(combined_output)

                # Include CLI progress/status messages from stderr
                full_output = ""
                if stderr_output:
                    full_output += "=== Scan Progress ===\n"
                    full_output += stderr_output + "\n\n"

                full_output += "=== Analysis Results ===\n"
                full_output += output

                return ScanResult(
                    scan_id="cli-scan",  # CLI doesn't expose scan ID separately
                    status=ScanStatus.SUCCESS,
                    results=full_output,
                    message="Scan completed successfully",
                    console_url=console_url
                )
            else:
                # Error occurred
                error_msg = result.stderr.strip() if result.stderr else result.stdout.strip()

                # Check if it's an auth error (expired token) and we haven't retried yet
                if _retry and ("auth error" in error_msg.lower() or "token is expired" in error_msg.lower()):
                    # Try to re-authenticate and retry once
                    print("Authentication error detected. Attempting to re-authenticate...")
                    if self.auth_login():
                        print("Re-authentication successful. Retrying scan...")
                        # Retry the scan once (with _retry=False to prevent infinite loop)
                        return self.scan_diff(repo_path, base_ref, wait, output_format, _retry=False)
                    else:
                        return ScanResult(
                            scan_id="cli-scan",
                            status=ScanStatus.ERROR,
                            error="Authentication failed after re-login attempt",
                            message="Authentication required"
                        )

                return ScanResult(
                    scan_id="cli-scan",
                    status=ScanStatus.FAILED,
                    error=error_msg,
                    message="Scan failed"
                )

        except Exception as e:
            return ScanResult(
                scan_id="cli-scan",
                status=ScanStatus.ERROR,
                error=str(e),
                message="Error executing scan"
            )

    def scan_full(
        self,
        repo_path: str,
        wait: bool = True,
        _retry: bool = True
    ) -> ScanResult:
        """
        Perform full repository risk check

        Args:
            repo_path: Path to the git repository
            wait: Wait for scan to complete (default: True)
            _retry: Internal flag to prevent infinite retry loops

        Returns:
            ScanResult object with scan results
        """
        # Ensure authentication and workspace configuration before scanning
        auth_success, auth_error = self.ensure_authenticated()
        if not auth_success:
            return ScanResult(
                scan_id="cli-scan-full",
                status=ScanStatus.ERROR,
                error=auth_error or "Authentication failed. Unable to proceed with scan.",
                message="Authentication required"
            )

        try:
            args = [
                "repo", "risk-check",
                repo_path,
                "--platform-url", self.platform_url
            ]

            if wait:
                args.append("--wait")
            else:
                args.extend(["--wait=false"])

            result = self._run_command(args, timeout=1800)  # 30 minutes for full scan

            if result.returncode == 0:
                # Success - parse the output
                output = result.stdout.strip()
                stderr_output = result.stderr.strip()

                # Extract console URL from both stdout and stderr (CLI outputs to stderr)
                combined_output = output + "\n" + stderr_output
                console_url = self._extract_console_url(combined_output)

                # Include CLI progress/status messages from stderr
                full_output = ""
                if stderr_output:
                    full_output += "=== Scan Progress ===\n"
                    full_output += stderr_output + "\n\n"

                full_output += "=== Analysis Results ===\n"
                full_output += output

                return ScanResult(
                    scan_id="cli-scan-full",
                    status=ScanStatus.SUCCESS,
                    results=full_output,
                    message="Full scan completed successfully",
                    console_url=console_url
                )
            else:
                # Error occurred
                error_msg = result.stderr.strip() if result.stderr else result.stdout.strip()

                # Check if it's an auth error (expired token) and we haven't retried yet
                if _retry and ("auth error" in error_msg.lower() or "token is expired" in error_msg.lower()):
                    # Try to re-authenticate and retry once
                    print("Authentication error detected. Attempting to re-authenticate...")
                    if self.auth_login():
                        print("Re-authentication successful. Retrying scan...")
                        # Retry the scan once (with _retry=False to prevent infinite loop)
                        return self.scan_full(repo_path, wait, _retry=False)
                    else:
                        return ScanResult(
                            scan_id="cli-scan-full",
                            status=ScanStatus.ERROR,
                            error="Authentication failed after re-login attempt",
                            message="Authentication required"
                        )

                return ScanResult(
                    scan_id="cli-scan-full",
                    status=ScanStatus.FAILED,
                    error=error_msg,
                    message="Full scan failed"
                )

        except Exception as e:
            return ScanResult(
                scan_id="cli-scan-full",
                status=ScanStatus.ERROR,
                error=str(e),
                message="Error executing full scan"
            )

    def get_version(self) -> Optional[str]:
        """
        Get the version of the installed CLI

        Returns:
            Version string or None if not available
        """
        return self.installer.get_installed_version()


def main():
    """CLI for testing the wrapper"""
    config = {
        "console_url": "https://console.us.kusari.cloud/",
        "api_endpoint": "https://platform.api.us.kusari.cloud/",
        "verbose": True
    }

    cli = KusariCLI(config)
    print(f"CLI Version: {cli.get_version()}")
    print(f"Is authenticated: {cli.is_authenticated()}")

    # Test authentication
    if not cli.is_authenticated():
        print("\nAuthentication required. Starting login flow...")
        success = cli.auth_login()
        print(f"Login result: {success}")


if __name__ == "__main__":
    main()
