#!/usr/bin/env python3
"""
CLI interface for Kusari Inspector MCP Server
"""

import argparse
import sys
from typing import Optional

from .install_helper import (
    CLIENT_CONFIGS,
    install_for_client,
    uninstall_for_client,
)


def list_clients():
    """List all supported clients"""
    print("Supported MCP clients:")
    print()
    for key, config in CLIENT_CONFIGS.items():
        cli_support = "✓ CLI support" if config["supports_cli"] else "✗ No CLI"
        print(f"  {key:15} - {config['name']:25} ({cli_support})")
    print()


def main(argv: Optional[list] = None):
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        prog="kusari-inspector-mcp",
        description="Kusari Inspector MCP Server - Security scanning for AI assistants",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  kusari-inspector-mcp install claude      # Install for Claude Code
  kusari-inspector-mcp install cursor      # Install for Cursor
  kusari-inspector-mcp install windsurf    # Install for Windsurf
  kusari-inspector-mcp list                # List all supported clients
  kusari-inspector-mcp uninstall claude    # Uninstall from Claude Code

Supported clients: claude, cursor, windsurf, cline, vscode, continue, copilot, antigravity
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Install command
    install_parser = subparsers.add_parser(
        "install", help="Install MCP server for a specific client"
    )
    install_parser.add_argument(
        "client",
        choices=list(CLIENT_CONFIGS.keys()),
        help="Client to install for",
    )
    install_parser.add_argument(
        "-v", "--verbose", action="store_true", help="Verbose output"
    )

    # Uninstall command
    uninstall_parser = subparsers.add_parser(
        "uninstall", help="Uninstall MCP server from a specific client"
    )
    uninstall_parser.add_argument(
        "client",
        choices=list(CLIENT_CONFIGS.keys()),
        help="Client to uninstall from",
    )

    # List command
    subparsers.add_parser("list", help="List all supported clients")

    # Parse arguments
    args = parser.parse_args(argv)

    # Handle commands
    if args.command == "install":
        success = install_for_client(args.client, verbose=args.verbose)
        sys.exit(0 if success else 1)
    elif args.command == "uninstall":
        success = uninstall_for_client(args.client)
        sys.exit(0 if success else 1)
    elif args.command == "list":
        list_clients()
        sys.exit(0)
    else:
        # No command specified - show help and default to Claude install for backward compat
        if len(sys.argv) == 1:
            # Called with no arguments - default behavior (Claude install)
            print("No command specified. Running default installation for Claude Code...")
            print("(Use 'kusari-inspector-mcp install <client>' for other clients)")
            print()
            success = install_for_client("claude", verbose=True)
            sys.exit(0 if success else 1)
        else:
            parser.print_help()
            sys.exit(1)


if __name__ == "__main__":
    main()
