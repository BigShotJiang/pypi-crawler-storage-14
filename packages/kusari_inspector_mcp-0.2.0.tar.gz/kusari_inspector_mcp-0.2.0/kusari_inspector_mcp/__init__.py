"""
Kusari Inspector MCP Server

An MCP (Model Context Protocol) server that provides security scanning capabilities
via the Kusari platform. Integrates with Claude Code and other MCP-compatible clients.
"""

__version__ = "0.1.0"
__author__ = "Kusari"
__email__ = "support@kusari.dev"

from .server import main
from .cli_wrapper import KusariCLI, ScanResult, ScanStatus
from .cli_installer import KusariCLIInstaller

__all__ = [
    "main",
    "KusariCLI",
    "ScanResult",
    "ScanStatus",
    "KusariCLIInstaller",
]
