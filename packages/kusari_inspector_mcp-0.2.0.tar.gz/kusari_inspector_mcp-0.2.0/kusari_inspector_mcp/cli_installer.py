#!/usr/bin/env python3
"""
Kusari CLI Installer
Handles downloading and installing the Kusari CLI binary
"""

import json
import os
import platform
import sys
import tarfile
import urllib.request
from pathlib import Path
from typing import Optional


class KusariCLIInstaller:
    """Manages installation and detection of Kusari CLI binary"""

    # GitHub release information
    GITHUB_REPO = "kusaridev/kusari-cli"
    GITHUB_API_URL = "https://api.github.com/repos/kusaridev/kusari-cli/releases/latest"

    def __init__(self, install_dir: Optional[Path] = None):
        """
        Initialize the installer

        Args:
            install_dir: Directory to install the CLI binary. Defaults to ~/.kusari/bin
        """
        if install_dir is None:
            self.install_dir = Path.home() / ".kusari" / "bin"
        else:
            self.install_dir = Path(install_dir)

        self.binary_name = "kusari"
        self.binary_path = self.install_dir / self.binary_name
        self.version_file = self.install_dir / ".kusari_version"

    def get_platform_info(self) -> tuple[str, str]:
        """
        Detect the current platform and architecture

        Returns:
            Tuple of (platform, architecture) e.g., ("darwin", "all") or ("linux", "amd64")
        """
        system = platform.system().lower()
        machine = platform.machine().lower()

        # Map platform names
        if system == "darwin":
            return ("darwin", "all")  # macOS uses universal binary
        elif system == "linux":
            if machine in ["x86_64", "amd64"]:
                return ("linux", "amd64")
            elif machine in ["aarch64", "arm64"]:
                return ("linux", "arm64")
            else:
                raise RuntimeError(f"Unsupported Linux architecture: {machine}")
        elif system == "windows":
            raise RuntimeError("Windows is not currently supported by this installer")
        else:
            raise RuntimeError(f"Unsupported operating system: {system}")

    def get_latest_version(self) -> Optional[str]:
        """
        Fetch the latest release version from GitHub API

        Returns:
            Latest version string (e.g., "v0.12.0") or None if failed
        """
        try:
            with urllib.request.urlopen(self.GITHUB_API_URL, timeout=10) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode())
                    return data.get("tag_name")
                return None
        except Exception as e:
            print(f"Warning: Failed to fetch latest version: {e}")
            return None

    def get_download_url(self, version: str) -> str:
        """
        Get the download URL for the current platform

        Args:
            version: Version to download (e.g., "v0.12.0")

        Returns:
            Download URL for the platform-specific tarball
        """
        plat, arch = self.get_platform_info()
        # Remove 'v' prefix if present
        version_num = version.lstrip('v')

        filename = f"kusari-cli_{version_num}_{plat}_{arch}.tar.gz"
        url = f"https://github.com/{self.GITHUB_REPO}/releases/download/{version}/{filename}"

        return url

    def is_installed(self) -> bool:
        """
        Check if Kusari CLI is already installed

        Returns:
            True if the binary exists and is executable
        """
        return self.binary_path.exists() and os.access(self.binary_path, os.X_OK)

    def get_installed_version(self) -> Optional[str]:
        """
        Get the version of the installed CLI

        Returns:
            Version string (e.g., "v0.12.0") or None if not installed or version cannot be determined
        """
        if not self.is_installed():
            return None

        # Read version from the version file
        if self.version_file.exists():
            try:
                return self.version_file.read_text().strip()
            except Exception:
                return None

        # No version file - binary exists but version unknown
        return None

    def download_and_install(self, version: str, force: bool = False) -> Path:
        """
        Download and install the Kusari CLI

        Args:
            version: Version to install (e.g., "v0.12.0")
            force: Force reinstall even if already installed

        Returns:
            Path to the installed binary
        """
        # Check if already installed
        if self.is_installed() and not force:
            print(f"Kusari CLI already installed at {self.binary_path}")
            return self.binary_path

        print(f"Installing Kusari CLI {version}...")

        # Create install directory
        self.install_dir.mkdir(parents=True, exist_ok=True)

        # Get download URL
        url = self.get_download_url(version)
        print(f"Downloading from {url}...")

        # Download the tarball
        try:
            tarball_path = self.install_dir / "kusari-cli.tar.gz"
            urllib.request.urlretrieve(url, tarball_path)

            # Extract the tarball
            print("Extracting...")
            with tarfile.open(tarball_path, 'r:gz') as tar:
                # Find the kusari binary in the tarball
                for member in tar.getmembers():
                    if member.name.endswith('/kusari') or member.name == 'kusari':
                        member.name = self.binary_name
                        # Use data filter to avoid deprecation warning
                        tar.extract(member, self.install_dir, filter='data')
                        break

            # Make executable
            os.chmod(self.binary_path, 0o755)

            # Save version information
            self.version_file.write_text(version)

            # Clean up tarball
            tarball_path.unlink()

            print(f"Successfully installed Kusari CLI {version} to {self.binary_path}")
            return self.binary_path

        except Exception as e:
            raise RuntimeError(f"Failed to install Kusari CLI: {e}")

    def compare_versions(self, v1: str, v2: str) -> int:
        """
        Compare two version strings

        Args:
            v1: First version (e.g., "v0.12.0")
            v2: Second version (e.g., "v0.13.0")

        Returns:
            -1 if v1 < v2, 0 if v1 == v2, 1 if v1 > v2
        """
        # Remove 'v' prefix if present
        v1_clean = v1.lstrip('v')
        v2_clean = v2.lstrip('v')

        # Split into parts and compare
        v1_parts = [int(x) for x in v1_clean.split('.')]
        v2_parts = [int(x) for x in v2_clean.split('.')]

        # Pad shorter version with zeros
        while len(v1_parts) < len(v2_parts):
            v1_parts.append(0)
        while len(v2_parts) < len(v1_parts):
            v2_parts.append(0)

        # Compare parts
        for p1, p2 in zip(v1_parts, v2_parts):
            if p1 < p2:
                return -1
            elif p1 > p2:
                return 1
        return 0

    def ensure_installed(self, check_updates: bool = True) -> Path:
        """
        Ensure Kusari CLI is installed, checking for updates if requested

        Args:
            check_updates: If True, checks for and installs latest version

        Returns:
            Path to the CLI binary
        """
        # Get latest version from GitHub
        latest_version = None
        if check_updates:
            latest_version = self.get_latest_version()
            if latest_version:
                print(f"Latest Kusari CLI version: {latest_version}")

        # Check if CLI is installed
        if not self.is_installed():
            # Not installed - install latest or fallback version
            version_to_install = latest_version or "v0.12.0"
            print(f"Kusari CLI not found. Installing {version_to_install}...")
            return self.download_and_install(version_to_install)

        # CLI is installed - check if we need to update
        installed_version = self.get_installed_version()

        if installed_version:
            print(f"Installed Kusari CLI version: {installed_version}")

            # Check if update is available
            if check_updates and latest_version:
                try:
                    if self.compare_versions(installed_version, latest_version) < 0:
                        print(f"Updating Kusari CLI from {installed_version} to {latest_version}...")
                        return self.download_and_install(latest_version, force=True)
                    else:
                        print(f"Kusari CLI is up to date ({installed_version})")
                except Exception as e:
                    print(f"Warning: Failed to compare versions: {e}")
        else:
            # Binary exists but no version info - update to latest
            if check_updates and latest_version:
                print(f"Kusari CLI version unknown. Updating to {latest_version}...")
                return self.download_and_install(latest_version, force=True)

        return self.binary_path

    def get_cli_path(self) -> Path:
        """
        Get the path to the CLI binary

        Returns:
            Path to the binary
        """
        return self.binary_path


def main():
    """CLI for testing the installer"""
    installer = KusariCLIInstaller()

    print(f"Platform: {installer.get_platform_info()}")
    print(f"Install directory: {installer.install_dir}")
    print(f"Binary path: {installer.binary_path}")
    print(f"Is installed: {installer.is_installed()}")

    if installer.is_installed():
        print(f"Installed version: {installer.get_installed_version()}")
    else:
        print(f"Not installed")

    print("\n" + "="*60)
    print("Ensuring latest version is installed...")
    print("="*60 + "\n")

    installer.ensure_installed(check_updates=True)

    print(f"\nFinal installed version: {installer.get_installed_version()}")


if __name__ == "__main__":
    main()
