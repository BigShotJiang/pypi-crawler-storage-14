def noop():
    """A placeholder utility."""
    return None
