from typing import Any

type MeshLike = Any
type PointSetLike = Any
type PolyDataLike = Any
type UnstructuredGridLike = Any
