# GIF 动画生成器 MCP

一个专门用于将多张图片合成 GIF 动画的模型上下文协议（MCP）服务器。

## 功能特性

- **GIF 动画创建**：将多张图片转换为动画 GIF
- **高级控制选项**：
  - 帧持续时间控制（1-10000ms）
  - 循环次数设置
  - 颜色模式选择（RGB/索引色/灰度）
  - 图像增强（亮度/对比度/饱和度调整）
  - 播放模式（正常/乒乓球效果）
  - 缓动曲线（ease-in/ease-out/ease-in-out）
- **智能尺寸处理**：
  - 多种尺寸策略（auto/min/max/custom）
  - 多种调整模式（fit/fill/stretch）
  - 灵活的对齐方式
- **智能命名**：自动文件命名，防止重复

## 安装

### 从 PyPI 安装
```bash
pip install gif-animation-mcp
```

### 开发安装
```bash
git clone https://github.com/mcpcn/gif-animation-mcp
cd gif-animation-mcp
pip install -e .
```

## 配置

### MCP 配置示例

```json
{
  "mcpServers": {
    "GIF Animation MCP": {
      "command": "uvx",
      "args": ["gif-animation-mcp"],
      "env": {}
    }
  }
}
```

## 可用工具

### convert_images_to_gif
将多张图片转换为 GIF 动画。

**参数**：
- `input_files` (list, 必需): 图片文件路径列表
- `output_dir` (str, 可选): 输出目录路径，默认为第一个文件所在目录
- `file_name` (str, 可选): 自定义文件名，默认自动命名
- `duration` (int, 可选): 每帧持续时间(毫秒)，范围 1-10000，默认 100
- `loop` (int, 可选): 循环次数，0 表示无限循环，默认 0
- `color_mode` (str, 可选): 颜色模式，可选 'RGB'(全彩色)、'P'(索引色)、'L'(灰度)，默认 'RGB'
- `color_count` (int, 可选): 颜色数量，范围 2-256，用于 'P' 和 'L' 模式，默认 256
- `brightness` (float, 可选): 亮度，范围 0.0-5.0，默认 1.0
- `contrast` (float, 可选): 对比度，范围 0.0-5.0，默认 1.0
- `saturation` (float, 可选): 饱和度，范围 0.0-5.0，默认 1.0
- `ping_pong` (bool, 可选): 乒乓球播放模式，默认 False
- `easing` (str, 可选): 缓动曲线，可选 'none'、'ease-in'、'ease-out'、'ease-in-out'，默认 'none'
- `easing_strength` (float, 可选): 缓动强度，范围 0.1-5.0，默认 1.0
- `size_strategy` (str, 可选): 尺寸策略，可选 'auto'、'min_size'、'max_size'、'custom'，默认 'auto'
- `resize_mode` (str, 可选): 调整模式，可选 'fit'、'fill'、'stretch'，默认 'fit'
- `alignment` (str, 可选): 对齐方式，可选 'center'、'top_left'、'top_right'、'bottom_left'、'bottom_right'，默认 'center'
- `target_width` (int, 可选): 自定义宽度，仅在 size_strategy='custom' 时使用
- `target_height` (int, 可选): 自定义高度，仅在 size_strategy='custom' 时使用
- `background_color` (str, 可选): 背景色，支持 CSS 颜色名或十六进制，默认 'black'

## 支持的格式

### 输入格式
- JPEG (.jpg, .jpeg)
- PNG (.png)
- BMP (.bmp)
- TIFF (.tif, .tiff)
- WEBP (.webp)
- HEIC/HEIF (.heic, .heif)
- AVIF (.avif)

### 输出格式
- GIF (.gif)

## 使用方法

### 命令行
```bash
gif-animation-mcp
```

### 作为 MCP 服务器
服务器通过标准输入输出运行，可以与任何 MCP 兼容的客户端集成。

## 系统要求

- Python 3.10+
- Pillow (PIL) 用于图片处理

## 许可证

本项目采用 MIT 许可证 - 详情请参阅 [LICENSE](LICENSE) 文件。
