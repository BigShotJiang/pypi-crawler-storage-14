"""Main Entry Point for the GIF Animation MCP Server."""

from .gif_converter import convert_images_to_gif

from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, ErrorData
from mcp import McpError
import gc
import sys
from typing import Union, Any, Optional


mcp = FastMCP("gif-animation-mcp")


def ok(msg: str) -> Union[TextContent, list]:
    """Create a Success Response."""
    return TextContent(type="text", text=msg)


def error(msg: str, data: Any = None) -> None:
    """Raise an Error - FastMCP will handle the error propagation."""
    raise McpError(ErrorData(code=-1, message=msg, data=data))


@mcp.tool(
    "convert_images_to_gif",
    description=(
        "将多张图片合成GIF动画。支持丰富的自定义选项:\n"
        "- 帧控制: 持续时间(1-10000ms)、循环次数\n"
        "- 颜色模式: RGB(全彩)、P(索引色)、L(灰度)\n"
        "- 图像增强: 亮度、对比度、饱和度调整(0.0-5.0)\n"
        "- 播放效果: 乒乓球模式、缓动曲线(ease-in/out/in-out)\n"
        "- 尺寸处理: 多种策略(auto/min/max/custom)和调整模式(fit/fill/stretch)\n"
        "- 对齐方式: center/top_left/top_right/bottom_left/bottom_right\n\n"
        "参数:\n"
        "- input_files (list, 必需): 图片文件路径列表\n"
        "- output_dir (str, 可选): 输出目录，默认为第一个文件所在目录\n"
        "- file_name (str, 可选): 自定义文件名(不含扩展名)，默认自动命名\n"
        "- duration (int, 可选): 每帧持续时间毫秒数，范围1-10000，默认100\n"
        "- loop (int, 可选): 循环次数，0=无限循环，默认0\n"
        "- color_mode (str, 可选): 颜色模式 RGB/P/L，默认RGB\n"
        "- color_count (int, 可选): P和L模式的颜色数量2-256，默认256\n"
        "- brightness (float, 可选): 亮度0.0-5.0，默认1.0\n"
        "- contrast (float, 可选): 对比度0.0-5.0，默认1.0\n"
        "- saturation (float, 可选): 饱和度0.0-5.0，默认1.0\n"
        "- ping_pong (bool, 可选): 乒乓球播放模式，默认False\n"
        "- easing (str, 可选): 缓动曲线 none/ease-in/ease-out/ease-in-out，默认none\n"
        "- easing_strength (float, 可选): 缓动强度0.1-5.0，默认1.0\n"
        "- size_strategy (str, 可选): 尺寸策略 auto/min_size/max_size/custom，默认auto\n"
        "- resize_mode (str, 可选): 调整模式 fit/fill/stretch，默认fit\n"
        "- alignment (str, 可选): 对齐方式 center/top_left/top_right/bottom_left/bottom_right，默认center\n"
        "- target_width (int, 可选): 自定义宽度，仅在size_strategy=custom时使用\n"
        "- target_height (int, 可选): 自定义高度，仅在size_strategy=custom时使用\n"
        "- background_color (str, 可选): fit模式的背景色，支持CSS颜色名或十六进制，默认black"
    )
)
def convert_images_to_gif_tool(
    input_files: list,
    file_name: Optional[str] = None,
    output_dir: Optional[str] = None,
    duration: int = 100,
    loop: int = 0,
    color_mode: str = "RGB",
    color_count: int = 256,
    brightness: float = 1.0,
    contrast: float = 1.0,
    saturation: float = 1.0,
    ping_pong: bool = False,
    easing: str = "none",
    easing_strength: float = 1.0,
    size_strategy: str = "auto",
    resize_mode: str = "fit",
    alignment: str = "center",
    target_width: Optional[int] = None,
    target_height: Optional[int] = None,
    background_color: str = "black"
) -> TextContent:
    """Convert Multiple Images to Animated GIF."""
    try:
        # First validate inputs before processing
        if not input_files or not isinstance(input_files, list):
            raise McpError(ErrorData(
                code=-1,
                message="Failed to Create GIF: input_files must be a non-empty list of file paths",
                data={"input_files": input_files, "duration": duration, "color_mode": color_mode}
            ))

        # Capture stdout/stderr to collect warnings
        import io
        from contextlib import redirect_stdout, redirect_stderr

        output_buffer = io.StringIO()
        with redirect_stdout(output_buffer), redirect_stderr(output_buffer):
            result = convert_images_to_gif(
                input_files, file_name, output_dir, duration, loop, color_mode, color_count,
                brightness, contrast, saturation, ping_pong, easing, easing_strength,
                size_strategy, resize_mode, alignment, target_width, target_height, background_color
            )

        # Check if there were warnings
        output_text = output_buffer.getvalue()
        warnings = []
        if "(WARNING)" in output_text:
            warnings = [line.strip() for line in output_text.split('\n') if "(WARNING)" in line]

        if warnings:
            return ok(f"Successfully created GIF: {result}\n\n(WARNING) Warnings:\n" + "\n".join(warnings))
        else:
            return ok(f"Successfully created GIF: {result}")

    except McpError:
        raise
    except Exception as e:
        raise McpError(ErrorData(
            code=-1,
            message=f"Failed to Create GIF: {str(e)}",
            data={
                "input_files": input_files,
                "duration": duration,
                "color_mode": color_mode
            }
        ))
    finally:
        gc.collect()


def main():
    """Run the MCP Server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
