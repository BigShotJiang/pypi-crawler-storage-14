"""GIF Animation MCP - Convert Images to GIF Animations."""

__version__ = "0.1.0"
