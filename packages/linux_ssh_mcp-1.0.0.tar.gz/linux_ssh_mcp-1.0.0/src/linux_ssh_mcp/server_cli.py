"""Simplified CLI for server management."""

import click
import asyncio
from pathlib import Path

from .config_manager import ConfigManager


@click.group(name="srv")
@click.pass_context
def server_cli(ctx):
    """Server management commands."""
    ctx.ensure_object(dict)


@server_cli.command()
@click.pass_context
def ls(ctx):
    """List all servers."""
    config = ConfigManager()
    servers = config.list_servers()

    if not servers:
        click.echo("No servers configured.")
        return

    click.echo("\nConfigured Servers:")
    click.echo("-" * 80)

    for server in servers:
        status = "Unknown"
        status_color = "yellow"

        click.echo(f"ID: {click.style(server.id, fg='cyan', bold=True)}")
        click.echo(f"  Name: {server.name}")
        click.echo(f"  Host: {server.host}:{server.port}")
        click.echo(f"  User: {server.username}")
        auth_method = server.auth_method.value if hasattr(server.auth_method, 'value') else server.auth_method
        click.echo(f"  Auth: {auth_method}")
        click.echo(f"  Tags: {', '.join(server.tags) if server.tags else 'None'}")
        click.echo()


@server_cli.command()
@click.option("-i", "--interactive", is_flag=True, help="Interactive mode")
@click.option("--host", "-h", help="Host address")
@click.option("--user", "-u", help="Username")
@click.option("--port", "-p", type=int, default=22, help="SSH port")
@click.option("--auth", "-a", type=click.Choice(["password", "ssh_key"]), help="Auth method")
@click.option("--key", "-k", help="SSH key path")
@click.argument("server_id")
@click.argument("host_arg", required=False)
@click.pass_context
def add(ctx, interactive, host, user, port, auth, key, server_id, host_arg):
    """Add a new server.

    Usage:
        add <server_id> <host>          # Quick add with interactive prompts
        add <server_id> --interactive   # Full interactive mode
        add my-server 192.168.1.100 -u root -a password
    """
    config = ConfigManager()

    # Check if server already exists
    if config.get_server(server_id):
        click.echo(f"❌ Server '{server_id}' already exists!", err=True)
        return

    # Determine host
    actual_host = host or host_arg
    if not actual_host:
        actual_host = click.prompt("Host address")

    if interactive:
        # Full interactive mode
        from .config_manager import getpass, AuthMethod
        click.echo(f"\n🔧 Adding server '{server_id}'")

        username = user or click.prompt("Username")
        auth_method = click.prompt(
            "Auth method",
            type=click.Choice(["password", "ssh_key"]),
            default="password"
        )

        password = None
        ssh_key_path = None

        if auth_method == "password":
            password = click.prompt("Password", hide_input=True, confirmation_prompt=True)
        else:
            ssh_key_path = key or click.prompt("SSH key path", default="~/.ssh/id_rsa")

        name = click.prompt("Server name", default=f"Server {server_id}")
        tags = click.prompt("Tags (comma-separated)", default="", show_default=False).strip()
        tag_list = [t.strip() for t in tags.split(",")] if tags else []

        from .models import ServerConfig
        server_config = ServerConfig(
            id=server_id,
            name=name,
            host=actual_host,
            port=port,
            username=username,
            auth_method=AuthMethod(auth_method),
            password=password,
            ssh_key_path=ssh_key_path,
            tags=tag_list
        )

    else:
        # Quick add mode with available parameters
        from .models import ServerConfig, AuthMethod

        username = user or click.prompt("Username")
        auth_method = auth or click.prompt("Auth method", type=click.Choice(["password", "ssh_key"]))

        if auth_method == "password":
            password = click.prompt("Password", hide_input=True, confirmation_prompt=True)
        else:
            ssh_key_path = key or click.prompt("SSH key path", default="~/.ssh/id_rsa")
            password = None

        server_config = ServerConfig(
            id=server_id,
            name=f"Server {server_id}",
            host=actual_host,
            port=port,
            username=username,
            auth_method=AuthMethod(auth_method),
            password=password,
            ssh_key_path=ssh_key_path,
            tags=[]
        )

    # Test connection
    click.echo(f"\n🔌 Testing connection to {actual_host}...")
    test_result = asyncio.run(config._test_connection(server_config))

    if not test_result["success"]:
        if not click.confirm(f"❌ Connection failed: {test_result['error']}\nSave anyway?"):
            click.echo("Operation cancelled.")
            return

    # Save configuration
    config.servers[server_id] = server_config
    if config.save_config():
        click.echo(f"✅ Server '{server_id}' added successfully!")
    else:
        click.echo("❌ Failed to save configuration!", err=True)


@server_cli.command()
@click.argument("server_id")
@click.pass_context
def rm(ctx, server_id):
    """Remove a server."""
    config = ConfigManager()

    server = config.get_server(server_id)
    if not server:
        click.echo(f"❌ Server '{server_id}' not found!", err=True)
        return

    click.echo(f"\nRemoving server '{server_id}':")
    click.echo(f"  Name: {server.name}")
    click.echo(f"  Host: {server.host}")
    click.echo(f"  User: {server.username}")

    if click.confirm("Are you sure?"):
        result = config.remove_server(server_id, confirm=False)
        if result["success"]:
            click.echo(f"✅ Server '{server_id}' removed successfully!")
        else:
            click.echo(f"❌ Failed to remove server: {result['error']}", err=True)


@server_cli.command()
@click.argument("server_id")
@click.pass_context
def test(ctx, server_id):
    """Test connection to a server."""
    config = ConfigManager()

    server = config.get_server(server_id)
    if not server:
        click.echo(f"❌ Server '{server_id}' not found!", err=True)
        return

    click.echo(f"Testing connection to {server.host}...")

    result = asyncio.run(config._test_connection(server))

    if result["success"]:
        click.echo(f"✅ Connection successful!")
        click.echo(f"   User: {result.get('user', 'unknown')}")
        click.echo(f"   {result.get('message', '')}")
    else:
        click.echo(f"❌ Connection failed: {result['error']}")


@server_cli.command()
@click.argument("server_id")
@click.pass_context
def pwd(ctx, server_id):
    """Update server password."""
    config = ConfigManager()

    server = config.get_server(server_id)
    if not server:
        click.echo(f"❌ Server '{server_id}' not found!", err=True)
        return

    if server.auth_method.value != "password":
        click.echo(f"❌ Server '{server_id}' uses {server.auth_method.value} authentication!", err=True)
        return

    click.echo(f"\n🔐 Update password for '{server_id}'")
    click.echo(f"Host: {server.host}")
    click.echo(f"User: {server.username}")

    result = config.update_server_password(server_id)
    if result["success"]:
        click.echo(f"✅ {result['message']}")
    else:
        click.echo(f"❌ {result['error']}", err=True)


@server_cli.command()
@click.argument("server_id")
@click.pass_context
def info(ctx, server_id):
    """Show server details."""
    config = ConfigManager()

    server = config.get_server(server_id)
    if not server:
        click.echo(f"❌ Server '{server_id}' not found!", err=True)
        return

    click.echo(f"\n📋 Server Details: {server_id}")
    click.echo("-" * 50)
    click.echo(f"Name:     {server.name}")
    click.echo(f"Host:     {server.host}:{server.port}")
    click.echo(f"Username: {server.username}")
    click.echo(f"Auth:     {server.auth_method.value}")

    if server.ssh_key_path:
        click.echo(f"SSH Key:  {server.ssh_key_path}")

    click.echo(f"Tags:     {', '.join(server.tags) if server.tags else 'None'}")

    # Test connection
    click.echo(f"\n🔌 Testing connection...")
    result = asyncio.run(config._test_connection(server))

    if result["success"]:
        click.echo(f"✅ Status: Connected")
        click.echo(f"   User: {result.get('user', 'unknown')}")
    else:
        click.echo(f"❌ Status: {result['error']}")


@server_cli.command()
@click.option("-o", "--output", help="Export file path")
@click.pass_context
def export(ctx, output):
    """Export configuration."""
    config = ConfigManager()

    result = config.export_config(output)
    if result["success"]:
        click.echo(f"✅ Configuration exported to {result['export_file']}")
    else:
        click.echo(f"❌ Export failed: {result['error']}", err=True)


@server_cli.command()
@click.pass_context
def status(ctx):
    """Show overall status."""
    config = ConfigManager()
    servers = config.list_servers()

    if not servers:
        click.echo("No servers configured.")
        return

    click.echo(f"\nServer Status Summary")
    click.echo("=" * 50)
    click.echo(f"Total servers: {len(servers)}")

    # Group by tags
    tag_count = {}
    auth_count = {}

    for server in servers:
        for tag in server.tags:
            tag_count[tag] = tag_count.get(tag, 0) + 1

        auth_method = server.auth_method.value if hasattr(server.auth_method, 'value') else server.auth_method
        auth_count[auth_method] = auth_count.get(auth_method, 0) + 1

    if tag_count:
        click.echo(f"\nBy Tags:")
        for tag, count in sorted(tag_count.items()):
            click.echo(f"   {tag}: {count}")

    if auth_count:
        click.echo(f"\nBy Auth Method:")
        for auth, count in sorted(auth_count.items()):
            click.echo(f"   {auth}: {count}")

    click.echo(f"\nConfig file: {config.config_file}")


# Register with main CLI
def register_cli(cli_group):
    """Register server commands with main CLI."""
    cli_group.add_command(server_cli)