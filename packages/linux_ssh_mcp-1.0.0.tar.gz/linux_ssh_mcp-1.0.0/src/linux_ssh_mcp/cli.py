"""Command line interface for Linux SSH MCP Server."""

import asyncio
import click
import structlog
import sys
from pathlib import Path

from .server import LinuxSSHMCPServer
from .models import ServerConfig, AuthMethod

logger = structlog.get_logger(__name__)


@click.group()
@click.version_option(version="1.0.0", prog_name="linux-ssh-mcp")
def main():
    """Linux SSH MCP Server - Secure SSH-based MCP server for Linux system management."""
    pass


@main.command()
@click.option('--config', '-c', type=click.Path(exists=True), help='Configuration file path')
@click.option('--log-level', default='INFO', type=click.Choice(['DEBUG', 'INFO', 'WARNING', 'ERROR']), help='Log level')
@click.option('--port', type=int, default=None, help='Port for HTTP server (if used)')
def run(config: str, log_level: str, port: int):
    """Run the MCP server."""
    # Configure logging
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer()
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    import logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=getattr(logging, log_level.upper())
    )

    async def server_main():
        server = LinuxSSHMCPServer()
        try:
            logger.info("Starting Linux SSH MCP Server")
            await server.run()
        except KeyboardInterrupt:
            logger.info("Received shutdown signal")
        except Exception as e:
            logger.error("Server error", error=str(e))
        finally:
            await server.shutdown()

    try:
        asyncio.run(server_main())
    except KeyboardInterrupt:
        print("\nServer stopped by user")
    except Exception as e:
        print(f"Server failed to start: {e}")
        sys.exit(1)


@main.command()
@click.argument('server_id')
@click.argument('host')
@click.argument('username')
@click.option('--port', default=22, help='SSH port')
@click.option('--auth-method', type=click.Choice(['password', 'ssh_key']), default='ssh_key', help='Authentication method')
@click.option('--ssh-key-path', help='Path to SSH private key')
@click.option('--password', help='SSH password')
@click.option('--tags', help='Comma-separated list of tags')
def add_server(server_id: str, host: str, username: str, port: int, auth_method: str, ssh_key_path: str, password: str, tags: str):
    """Add a new server configuration."""
    try:
        # Parse tags
        tag_list = [tag.strip() for tag in tags.split(',')] if tags else []

        # Create server config
        config = ServerConfig(
            id=server_id,
            name=f"Server {server_id}",
            host=host,
            port=port,
            username=username,
            auth_method=AuthMethod(auth_method),
            ssh_key_path=ssh_key_path,
            password=password,
            tags=tag_list
        )

        # Save to config file
        config_file = Path("config/servers.yaml")
        config_file.parent.mkdir(parents=True, exist_ok=True)

        # For now, just print the config (in a real implementation, we'd save it)
        print(f"Server configuration created:")
        print(f"  ID: {config.id}")
        print(f"  Host: {config.host}:{config.port}")
        print(f"  Username: {config.username}")
        print(f"  Auth Method: {config.auth_method}")
        print(f"  Tags: {', '.join(config.tags)}")
        print(f"\nConfiguration would be saved to: {config_file}")

    except Exception as e:
        print(f"Error adding server: {e}")
        sys.exit(1)


@main.command()
@click.option('--test-connection', is_flag=True, help='Test connections to all servers')
def list_servers(test_connection: bool):
    """List configured servers."""
    from .server import LinuxSSHMCPServer

    async def list():
        server = LinuxSSHMCPServer()
        servers = server.ssh_manager.list_servers()

        if not servers:
            print("No servers configured")
            return

        print(f"Configured servers ({len(servers)}):")
        print("-" * 60)

        for server_id in servers:
            config = server.ssh_manager.get_server_info(server_id)
            if config:
                status = server.ssh_manager.get_server_status(server_id)
                print(f"ID: {config.id}")
                print(f"  Name: {config.name}")
                print(f"  Host: {config.host}:{config.port}")
                print(f"  Username: {config.username}")
                print(f"  Auth Method: {config.auth_method}")
                print(f"  Tags: {', '.join(config.tags)}")
                print(f"  Status: {status.value}")

                if test_connection:
                    print("  Testing connection...", end=" ")
                    try:
                        await server.ssh_manager.connect(server_id)
                        test_result = await server.ssh_manager.test_connection(server_id)
                        if test_result:
                            print("✓ Success")
                        else:
                            print("✗ Failed")
                    except Exception as e:
                        print(f"✗ Error: {e}")

                print()

    asyncio.run(list())


@main.command()
@click.argument('server_id')
@click.argument('command')
@click.option('--timeout', default=30, help='Command timeout in seconds')
def test_command(server_id: str, command: str, timeout: int):
    """Test command execution on a server."""
    from .server import LinuxSSHMCPServer
    from .config_manager import ConfigManager

    async def test():
        # Load server configuration
        config_manager = ConfigManager()
        server_config = config_manager.get_server(server_id)

        if not server_config:
            print(f"Server '{server_id}' not found in configuration")
            return

        server = LinuxSSHMCPServer()

        # Add server from configuration
        server.ssh_manager.add_server(server_config)

        # Connect to server
        connected = await server.ssh_manager.connect(server_id)
        if not connected:
            print(f"Failed to connect to server '{server_id}'")
            return

        print(f"Testing command on {server_id}: {command}")
        print("-" * 50)

        try:
            result = await server.ssh_manager.execute_command(server_id, command, timeout)

            print(f"Exit Code: {result.exit_code}")
            print(f"Success: {result.success}")
            print(f"Execution Time: {result.execution_time:.2f}s")

            if result.stdout:
                print(f"\nSTDOUT:\n{result.stdout}")

            if result.stderr:
                print(f"\nSTDERR:\n{result.stderr}")

        except Exception as e:
            print(f"Error executing command: {e}")

    asyncio.run(test())


@main.command()
def init_config():
    """Initialize configuration directory and files."""
    config_dir = Path("config")
    logs_dir = Path("logs")

    print("Initializing configuration...")

    # Create directories
    config_dir.mkdir(exist_ok=True)
    logs_dir.mkdir(exist_ok=True)

    # Create example configuration files
    servers_config = """# SSH Server Configuration
servers:
  - id: "example-server"
    name: "Example Linux Server"
    host: "192.168.1.100"
    port: 22
    username: "your_username"
    auth_method: "ssh_key"
    ssh_key_path: "~/.ssh/id_rsa"
    tags: ["example", "production"]
"""

    security_config = """# Security Configuration
max_file_size: 52428800  # 50MB
allowed_paths:
  - "/home"
  - "/tmp"
  - "/var/tmp"
forbidden_paths:
  - "/"
  - "/root"
  - "/boot"
  - "/sys"
  - "/proc"
  - "/dev"
enable_audit_log: true
audit_log_file: "logs/audit.log"
session_timeout: 3600  # 1 hour
"""

    # Write configuration files
    (config_dir / "servers.yaml").write_text(servers_config)
    (config_dir / "security.yaml").write_text(security_config)

    print("+ Created config directory")
    print("+ Created logs directory")
    print("+ Created example server configuration: config/servers.yaml")
    print("+ Created security configuration: config/security.yaml")
    print("\nConfiguration initialized. Please edit the files to match your environment.")


from .server_cli import register_cli

# Register server management commands
register_cli(main)

@main.command()
def servers():
    """List all configured servers (alias for srv ls)."""
    from .config_manager import ConfigManager
    config = ConfigManager()
    servers = config.list_servers()

    if not servers:
        click.echo("No servers configured.")
        return

    click.echo("\nConfigured Servers:")
    click.echo("-" * 80)

    for server in servers:
        auth_method = server.auth_method.value if hasattr(server.auth_method, 'value') else server.auth_method
        click.echo(f"ID: {click.style(server.id, fg='cyan', bold=True)}")
        click.echo(f"  Name: {server.name}")
        click.echo(f"  Host: {server.host}:{server.port}")
        click.echo(f"  User: {server.username}")
        click.echo(f"  Auth: {auth_method}")
        click.echo(f"  Tags: {', '.join(server.tags) if server.tags else 'None'}")
        click.echo()


@main.command()
@click.argument("server_id")
@click.pass_context
def status(ctx, server_id):
    """Check server status (alias for srv test)."""
    from .config_manager import ConfigManager
    import asyncio

    config = ConfigManager()
    server = config.get_server(server_id)
    if not server:
        click.echo(f"Server '{server_id}' not found!", err=True)
        return

    click.echo(f"Testing connection to {server.host}...")
    result = asyncio.run(config._test_connection(server))

    if result["success"]:
        click.echo(f"Status: Connected")
        click.echo(f"   User: {result.get('user', 'unknown')}")
        click.echo(f"   {result.get('message', '')}")
    else:
        click.echo(f"Status: {result['error']}")


@main.command()
def tools():
    """List all available MCP tools."""
    click.echo("\nLinux SSH MCP - Available Tools")
    click.echo("=" * 60)

    tools = [
        {
            "name": "list_servers",
            "description": "List all configured SSH servers",
            "usage": "list_servers()",
            "category": "Connection Management"
        },
        {
            "name": "connect_server",
            "description": "Connect to a SSH server",
            "usage": "connect_server(server_id: str)",
            "category": "Connection Management"
        },
        {
            "name": "disconnect_server",
            "description": "Disconnect from a SSH server",
            "usage": "disconnect_server(server_id: str)",
            "category": "Connection Management"
        },
        {
            "name": "test_connection",
            "description": "Test connection to a SSH server",
            "usage": "test_connection(server_id: str)",
            "category": "Connection Management"
        },
        {
            "name": "get_system_info",
            "description": "Get system information from a server",
            "usage": "get_system_info(server_id: str, category: str)",
            "category": "System Information",
            "options": ["system", "cpu", "memory", "disk", "network", "processes", "services"]
        },
        {
            "name": "file_operations",
            "description": "Perform file operations (read, write, list, delete, move, copy)",
            "usage": "file_operations(server_id: str, operation: str, path: str, ...)",
            "category": "File Management",
            "options": ["read", "write", "list", "delete", "move", "copy"]
        },
        {
            "name": "process_manager",
            "description": "Manage processes (list, kill, get details)",
            "usage": "process_manager(server_id: str, operation: str, ...)",
            "category": "Process Management",
            "options": ["list", "kill", "details"]
        },
        {
            "name": "service_manager",
            "description": "Manage system services (list, status, start, stop, restart, enable, disable, logs)",
            "usage": "service_manager(server_id: str, operation: str, service: str)",
            "category": "Service Management",
            "options": ["list", "status", "start", "stop", "restart", "enable", "disable", "logs"]
        },
        {
            "name": "execute_command",
            "description": "Execute a command on the server",
            "usage": "execute_command(server_id: str, command: str, timeout: int = 30, category: str)",
            "category": "Command Execution",
            "options": ["system_info", "file_operations", "text_processing", "network", "processes", "services", "packages", "docker", "kubernetes", "general"]
        }
    ]

    # Group tools by category
    categories = {}
    for tool in tools:
        cat = tool["category"]
        if cat not in categories:
            categories[cat] = []
        categories[cat].append(tool)

    # Display tools by category
    for category, category_tools in categories.items():
        click.echo(f"\n{category}")
        click.echo("-" * 40)
        for tool in category_tools:
            click.echo(f"- {click.style(tool['name'], fg='cyan', bold=True)}")
            click.echo(f"  Description: {tool['description']}")
            click.echo(f"  Usage: {click.style(tool['usage'], fg='green')}")
            if "options" in tool:
                click.echo(f"  Options: {', '.join([click.style(opt, fg='yellow') for opt in tool['options']])}")
            click.echo()

    click.echo("=" * 60)
    click.echo("Note: These tools are available when running the MCP server")
    click.echo("   Command: python -m linux_ssh_mcp.cli run")


# 简短命令别名
@main.command()
@click.argument('server_id')
@click.argument('host')
@click.argument('username')
@click.option('--port', default=22, help='SSH port')
@click.option('--auth-method', type=click.Choice(['password', 'ssh_key']), default='ssh_key', help='Authentication method')
@click.option('--ssh-key-path', help='Path to SSH private key')
@click.option('--password', help='SSH password')
@click.option('--tags', help='Comma-separated list of tags')
def add(server_id: str, host: str, username: str, port: int, auth_method: str, ssh_key_path: str, password: str, tags: str):
    """Add a new server (alias for add-server)."""
    import click
    ctx = click.get_current_context()
    ctx.invoke(add_server, server_id=server_id, host=host, username=username, port=port,
               auth_method=auth_method, ssh_key_path=ssh_key_path, password=password, tags=tags)


@main.command()
@click.option('--test-connection', is_flag=True, help='Test connections to all servers')
def ls(test_connection: bool):
    """List configured servers (alias for list-servers)."""
    import click
    ctx = click.get_current_context()
    ctx.invoke(list_servers, test_connection=test_connection)


@main.command()
def init():
    """Initialize configuration (alias for init-config)."""
    from pathlib import Path
    config_dir = Path("config")
    logs_dir = Path("logs")

    print("Initializing configuration...")

    # Create directories
    config_dir.mkdir(exist_ok=True)
    logs_dir.mkdir(exist_ok=True)

    # Create example configuration files
    servers_config = """# SSH Server Configuration
servers:
  - id: "example-server"
    name: "Example Linux Server"
    host: "192.168.1.100"
    port: 22
    username: "your_username"
    auth_method: "ssh_key"
    ssh_key_path: "~/.ssh/id_rsa"
    tags: ["example", "production"]
"""

    security_config = """# Security Configuration
max_file_size: 52428800  # 50MB
allowed_paths:
  - "/home"
  - "/tmp"
  - "/var/tmp"
forbidden_paths:
  - "/"
  - "/root"
  - "/boot"
  - "/sys"
  - "/proc"
  - "/dev"
enable_audit_log: true
audit_log_file: "logs/audit.log"
session_timeout: 3600  # 1 hour
command_categories:
  system_info:
    - "uname"
    - "df"
    - "free"
    - "ps"
  file_operations:
    - "ls"
    - "cat"
    - "grep"
    - "find"
  docker:
    - "docker"
    - "docker-compose"
  kubernetes:
    - "kubectl"
    - "kubeadm"
"""

    # Write configuration files
    with open("config/servers.yaml", "w") as f:
        f.write(servers_config)
    with open("config/security.yaml", "w") as f:
        f.write(security_config)

    print("Configuration initialized successfully!")
    print("Created:")
    print("  - config/servers.yaml")
    print("  - config/security.yaml")


@main.command()
@click.argument('server_id')
@click.argument('command')
@click.option('--timeout', default=30, help='Command timeout in seconds')
def exec(server_id: str, command: str, timeout: int):
    """Execute command on server (alias for test)."""
    import click
    ctx = click.get_current_context()
    ctx.invoke(test_command, server_id=server_id, command=command, timeout=timeout)


@main.command()
@click.argument('server_id')
@click.argument('new_id')
@click.option('--name', help='New server name (optional)')
@click.option('--no-confirm', is_flag=True, help='Skip confirmation prompt')
def rename(server_id: str, new_id: str, name: str, no_confirm: bool):
    """Rename a server configuration."""
    from .config_manager import ConfigManager

    config_manager = ConfigManager()
    result = config_manager.rename_server(
        server_id=server_id,
        new_id=new_id,
        new_name=name,
        confirm=not no_confirm
    )

    if result["success"]:
        click.echo(f"{result['message']}")
        click.echo(f"   Old ID: {result['old_id']} → New ID: {result['new_id']}")
        click.echo(f"   Old Name: {result['old_name']} → New Name: {result['new_name']}")
    else:
        click.echo(f"Error: {result['error']}", err=True)
        sys.exit(1)


@main.command()
@click.argument('server_id')
@click.argument('new_id')
@click.option('--name', help='New server name (optional)')
@click.option('--no-confirm', is_flag=True, help='Skip confirmation prompt')
def mv(server_id: str, new_id: str, name: str, no_confirm: bool):
    """Rename a server (alias for rename)."""
    import click
    ctx = click.get_current_context()
    ctx.invoke(rename, server_id=server_id, new_id=new_id, name=name, no_confirm=no_confirm)


if __name__ == "__main__":
    main()