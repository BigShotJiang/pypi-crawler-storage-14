"""SSH connection manager for Linux MCP server."""

import asyncio
import asyncssh
from typing import Dict, Optional, Any, List
from datetime import datetime
import structlog

from .models import ServerConfig, ServerStatus, CommandResult

logger = structlog.get_logger(__name__)


class SSHManager:
    """Manages SSH connections to Linux servers."""

    def __init__(self):
        self.connections: Dict[str, asyncssh.SSHClientConnection] = {}
        self.servers: Dict[str, ServerConfig] = {}
        self.connection_status: Dict[str, ServerStatus] = {}

    def add_server(self, config: ServerConfig) -> None:
        """Add a server configuration."""
        self.servers[config.id] = config
        self.connection_status[config.id] = ServerStatus.DISCONNECTED
        logger.info("Added server configuration", server_id=config.id, host=config.host)

    async def connect(self, server_id: str) -> bool:
        """Connect to a server."""
        if server_id not in self.servers:
            logger.error("Server configuration not found", server_id=server_id)
            return False

        config = self.servers[server_id]
        if self.connection_status[server_id] == ServerStatus.CONNECTED:
            return True

        try:
            self.connection_status[server_id] = ServerStatus.CONNECTING
            logger.info("Connecting to server", server_id=server_id, host=config.host)

            # Prepare connection parameters
            connect_kwargs = {
                "host": config.host,
                "port": config.port,
                "username": config.username,
                "connect_timeout": config.timeout,
                "known_hosts": None,  # Disable host key checking entirely
                "client_keys": None,
                "agent_forwarding": False,
                "x11_forwarding": False
            }

            # Add authentication method
            if config.auth_method == "ssh_key":
                if config.ssh_key_path:
                    connect_kwargs["client_keys"] = [config.ssh_key_path]
                if config.ssh_key_password:
                    connect_kwargs["passphrase"] = config.ssh_key_password
            elif config.auth_method == "password" and config.password:
                connect_kwargs["password"] = config.password

            # Establish connection
            connection = await asyncssh.connect(**connect_kwargs)
            self.connections[server_id] = connection
            self.connection_status[server_id] = ServerStatus.CONNECTED

            logger.info("Successfully connected to server", server_id=server_id)
            return True

        except Exception as e:
            self.connection_status[server_id] = ServerStatus.ERROR
            logger.error("Failed to connect to server",
                        server_id=server_id,
                        host=config.host,
                        error=str(e))
            return False

    async def disconnect(self, server_id: str) -> None:
        """Disconnect from a server."""
        if server_id in self.connections:
            try:
                self.connections[server_id].close()
                await self.connections[server_id].wait_closed()
                del self.connections[server_id]
                self.connection_status[server_id] = ServerStatus.DISCONNECTED
                logger.info("Disconnected from server", server_id=server_id)
            except Exception as e:
                logger.error("Error disconnecting from server",
                            server_id=server_id,
                            error=str(e))

    async def disconnect_all(self) -> None:
        """Disconnect from all servers."""
        for server_id in list(self.connections.keys()):
            await self.disconnect(server_id)

    def get_server_status(self, server_id: str) -> ServerStatus:
        """Get connection status for a server."""
        return self.connection_status.get(server_id, ServerStatus.DISCONNECTED)

    def list_servers(self) -> List[str]:
        """List all configured server IDs."""
        return list(self.servers.keys())

    def get_server_info(self, server_id: str) -> Optional[ServerConfig]:
        """Get server configuration."""
        return self.servers.get(server_id)

    async def execute_command(
        self,
        server_id: str,
        command: str,
        timeout: Optional[float] = None,
        input_data: Optional[str] = None
    ) -> CommandResult:
        """Execute a command on a server."""
        if server_id not in self.servers:
            return CommandResult(
                host=server_id,
                command=command,
                success=False,
                stdout="",
                stderr=f"Server {server_id} not configured",
                exit_code=-1,
                execution_time=0,
                timestamp=datetime.now()
            )

        # Connect if not connected
        if self.connection_status[server_id] != ServerStatus.CONNECTED:
            if not await self.connect(server_id):
                return CommandResult(
                    host=server_id,
                    command=command,
                    success=False,
                    stdout="",
                    stderr=f"Failed to connect to server {server_id}",
                    exit_code=-1,
                    execution_time=0,
                    timestamp=datetime.now()
                )

        connection = self.connections[server_id]
        start_time = datetime.now()

        try:
            logger.info("Executing command",
                       server_id=server_id,
                       host=self.servers[server_id].host,
                       command=command)

            # Execute command
            result = await connection.run(
                command,
                timeout=timeout or 30,
                input=input_data or ""
            )

            execution_time = (datetime.now() - start_time).total_seconds()

            command_result = CommandResult(
                host=server_id,
                command=command,
                success=result.exit_status == 0,
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.exit_status,
                execution_time=execution_time,
                timestamp=datetime.now()
            )

            logger.info("Command executed",
                       server_id=server_id,
                       command=command,
                       success=command_result.success,
                       exit_code=result.exit_status,
                       execution_time=execution_time)

            return command_result

        except asyncio.TimeoutError:
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.error("Command execution timeout",
                        server_id=server_id,
                        command=command,
                        timeout=timeout or 30)

            return CommandResult(
                host=server_id,
                command=command,
                success=False,
                stdout="",
                stderr=f"Command execution timeout after {timeout or 30} seconds",
                exit_code=-1,
                execution_time=execution_time,
                timestamp=datetime.now()
            )

        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds()
            logger.error("Command execution failed",
                        server_id=server_id,
                        command=command,
                        error=str(e))

            return CommandResult(
                host=server_id,
                command=command,
                success=False,
                stdout="",
                stderr=f"Command execution failed: {str(e)}",
                exit_code=-1,
                execution_time=execution_time,
                timestamp=datetime.now()
            )

    async def execute_command_interactive(
        self,
        server_id: str,
        command: str,
        timeout: Optional[float] = None
    ) -> asyncssh.SSHServerProcess:
        """Execute an interactive command (returns process object)."""
        if server_id not in self.servers:
            raise ValueError(f"Server {server_id} not configured")

        if self.connection_status[server_id] != ServerStatus.CONNECTED:
            await self.connect(server_id)

        connection = self.connections[server_id]

        logger.info("Starting interactive command",
                   server_id=server_id,
                   command=command)

        process = await connection.create_process(
            command,
            timeout=timeout or 30
        )

        return process

    async def test_connection(self, server_id: str) -> bool:
        """Test connection to a server."""
        try:
            result = await self.execute_command(server_id, "echo 'connection_test'")
            return result.success and "connection_test" in result.stdout
        except Exception:
            return False

    async def get_server_info_remote(self, server_id: str) -> Dict[str, Any]:
        """Get basic server information via SSH."""
        commands = {
            "hostname": "hostname",
            "uname": "uname -a",
            "uptime": "uptime",
            "whoami": "whoami",
            "pwd": "pwd",
            "date": "date"
        }

        info = {}
        for key, cmd in commands.items():
            result = await self.execute_command(server_id, cmd, timeout=10)
            if result.success:
                info[key] = result.stdout.strip()
            else:
                info[key] = f"Error: {result.stderr}"

        return info