"""Security validation module for Linux MCP server."""

import re
import os
from typing import Dict, List, Optional, Set, Any
from pathlib import Path
from datetime import datetime

from .models import SecurityConfig


class SecurityValidator:
    """Validates operations for security compliance."""

    def __init__(self, config: SecurityConfig):
        self.config = config
        self.dangerous_patterns = self._load_dangerous_patterns()
        self.allowed_commands = self._load_allowed_commands()

    def _load_dangerous_patterns(self) -> List[re.Pattern]:
        """Load dangerous command patterns."""
        patterns = [
            r'rm\s+-rf\s+/',          # Delete root directory
            r'dd\s+if=/dev/zero',     # Zero out disk
            r':\(\)\{\s*\}\:\&\s*;', # Fork bomb
            r'sudo\s+su\s+root',      # Switch to root
            r'chmod\s+777\s+/',       # Root directory 777 permissions
            r'format\s+',             # Format disk
            r'fdisk\s+',              # Disk partitioning
            r'mkfs\.',                # Create filesystem
            r'wget\s+.*\|\s*sh',      # Download and execute
            r'curl\s+.*\|\s*bash',    # Download and execute
            r'>>\s*/etc/passwd',      # Modify passwd file
            r'>>\s*/etc/shadow',      # Modify shadow file
            r'crontab\s+-e',          # Edit crontab
            r'echo\s+.*>\s*/etc/sudoers', # Modify sudoers
            r'shutdown\s+',           # Shutdown system
            r'reboot\s+',             # Reboot system
            r'poweroff\s+',           # Power off system
            r'init\s+[0-6]',          # Change runlevel
            r'kill\s+-9\s+1',         # Kill init process
            r'\.\./\.\./\.\./',       # Directory traversal
        ]
        return [re.compile(pattern, re.IGNORECASE) for pattern in patterns]

    def _load_allowed_commands(self) -> Dict[str, List[str]]:
        """Load allowed commands by category."""
        commands = {
            "system_info": [
                "uname", "hostname", "uptime", "who", "w", "id", "date",
                "cat", "less", "more", "head", "tail", "grep", "wc", "sort",
                "df", "du", "free", "top", "htop", "ps", "pstree",
                "lscpu", "lsblk", "lsusb", "lspci", "dmidecode"
            ],
            "file_operations": [
                "ls", "cd", "pwd", "find", "locate", "which", "whereis",
                "cp", "mv", "rm", "rmdir", "mkdir", "touch",
                "chmod", "chown", "chgrp", "stat", "file",
                "tar", "zip", "unzip", "gzip", "gunzip"
            ],
            "text_processing": [
                "cat", "echo", "printf", "sed", "awk", "tr", "cut",
                "join", "paste", "split", "sort", "uniq", "wc"
            ],
            "network": [
                "ping", "traceroute", "tracepath", "mtr",
                "netstat", "ss", "lsof", "ip", "ifconfig",
                "route", "arp", "dig", "nslookup", "host"
            ],
            "processes": [
                "ps", "top", "htop", "kill", "killall", "pgrep", "pkill",
                "nice", "renice", "nohup", "jobs", "bg", "fg"
            ],
            "services": [
                "systemctl", "service", "chkconfig", "update-rc.d",
                "journalctl", "initctl"
            ],
            "packages": [
                "apt", "apt-get", "apt-cache", "dpkg", "dpkg-query",
                "yum", "yum-config-manager", "rpm", "rpmquery",
                "dnf", "dnf-plugin", "pacman", "yaourt"
            ],
            "docker": [
                "docker", "docker-compose", "docker-compose-plugin"
            ],
            "kubernetes": [
                "kubectl", "kubeadm", "kubelet", "kubecfg",
                "helm", "kustomize"
            ]
        }

        # Merge with user-defined whitelist
        for category, user_commands in self.config.command_whitelist.items():
            if category not in commands:
                commands[category] = []
            commands[category].extend(user_commands)

        # Remove duplicates
        for category in commands:
            commands[category] = list(set(commands[category]))

        return commands

    async def validate_path(self, path: str, operation: str = "read") -> Dict[str, Any]:
        """Validate file path for security."""
        try:
            # Normalize path
            normalized_path = os.path.normpath(path)

            # Check for path traversal
            if ".." in path or path.startswith("../"):
                return {
                    "allowed": False,
                    "reason": "Path traversal attempt detected",
                    "path": path
                }

            # Check against forbidden paths
            abs_path = os.path.abspath(normalized_path)
            for forbidden in self.config.forbidden_paths:
                if abs_path.startswith(os.path.abspath(forbidden)):
                    return {
                        "allowed": False,
                        "reason": f"Access to forbidden path '{forbidden}' is not allowed",
                        "path": path,
                        "forbidden_path": forbidden
                    }

            # Check against allowed paths (if configured)
            if self.config.allowed_paths:
                allowed = False
                for allowed_path in self.config.allowed_paths:
                    if abs_path.startswith(os.path.abspath(allowed_path)):
                        allowed = True
                        break

                if not allowed:
                    return {
                        "allowed": False,
                        "reason": f"Path '{path}' is not in allowed paths list",
                        "path": path,
                        "allowed_paths": self.config.allowed_paths
                    }

            # Additional checks for write operations
            if operation in ["write", "delete", "move"]:
                dangerous_extensions = {".exe", ".bat", ".cmd", ".scr", ".vbs", ".js", ".jar", ".sh"}
                file_ext = os.path.splitext(abs_path)[1].lower()
                if file_ext in dangerous_extensions:
                    return {
                        "allowed": False,
                        "reason": f"Writing executable files with extension '{file_ext}' is not allowed",
                        "path": path,
                        "extension": file_ext
                    }

                # Check file size for write operations
                if os.path.exists(abs_path):
                    try:
                        file_size = os.path.getsize(abs_path)
                        if file_size > self.config.max_file_size:
                            return {
                                "allowed": False,
                                "reason": f"File size ({file_size} bytes) exceeds maximum allowed ({self.config.max_file_size} bytes)",
                                "path": path,
                                "current_size": file_size,
                                "max_size": self.config.max_file_size
                            }
                    except OSError:
                        pass  # File might not be accessible

            return {
                "allowed": True,
                "reason": "Path validation passed",
                "path": path,
                "normalized_path": normalized_path
            }

        except Exception as e:
            return {
                "allowed": False,
                "reason": f"Path validation error: {str(e)}",
                "path": path
            }

    async def validate_command(self, command: str, category: str = "general") -> Dict[str, Any]:
        """Validate command for security."""
        try:
            # Clean up command
            clean_command = ' '.join(command.split())

            # Check dangerous patterns
            for pattern in self.dangerous_patterns:
                if pattern.search(clean_command):
                    return {
                        "allowed": False,
                        "reason": f"Dangerous command pattern detected: {pattern.pattern}",
                        "command": command,
                        "matched_pattern": pattern.pattern
                    }

            # Extract base command
            parts = clean_command.split()
            if not parts:
                return {
                    "allowed": False,
                    "reason": "Empty command",
                    "command": command
                }

            base_command = parts[0]
            # Handle absolute paths
            if base_command.startswith('/'):
                base_command = os.path.basename(base_command)

            # Check against allowed commands
            all_allowed = set()
            for cmd_list in self.allowed_commands.values():
                all_allowed.update(cmd_list)

            # For specific categories, check against those
            if category in self.allowed_commands:
                category_commands = set(self.allowed_commands[category])
                if base_command not in category_commands and base_command not in all_allowed:
                    return {
                        "allowed": False,
                        "reason": f"Command '{base_command}' is not allowed in category '{category}'",
                        "command": command,
                        "base_command": base_command,
                        "category": category,
                        "suggestions": list(category_commands)[:10]
                    }

            # For general category, check against all allowed
            elif category == "general":
                if base_command not in all_allowed:
                    return {
                        "allowed": False,
                        "reason": f"Command '{base_command}' is not in the allowed commands list",
                        "command": command,
                        "base_command": base_command,
                        "suggestions": list(all_allowed)[:20]
                    }

            # Additional checks for non-privileged operations
            if category not in ["admin", "advanced"]:
                # Check for sudo usage
                if clean_command.startswith("sudo "):
                    return {
                        "allowed": False,
                        "reason": "sudo commands are not allowed in basic operations",
                        "command": command
                    }

                # Check for pipes in non-advanced categories
                if "|" in clean_command and category not in ["advanced", "admin"]:
                    return {
                        "allowed": False,
                        "reason": "Command pipes are not allowed in this category",
                        "command": command
                    }

                # Check for shell redirections
                if any(op in clean_command for op in [">>", ">", "2>", "2>>"]) and category not in ["file_operations", "admin"]:
                    return {
                        "allowed": False,
                        "reason": "Command redirection is not allowed in this category",
                        "command": command
                    }

                # Check for background execution
                if clean_command.endswith("&") and category not in ["admin", "advanced"]:
                    return {
                        "allowed": False,
                        "reason": "Background execution is not allowed in this category",
                        "command": command
                    }

            return {
                "allowed": True,
                "reason": "Command validation passed",
                "command": command,
                "base_command": base_command,
                "category": category
            }

        except Exception as e:
            return {
                "allowed": False,
                "reason": f"Command validation error: {str(e)}",
                "command": command
            }

    def validate_file_size(self, size: int) -> Dict[str, Any]:
        """Validate file size."""
        if size > self.config.max_file_size:
            return {
                "allowed": False,
                "reason": f"File size ({size} bytes) exceeds maximum allowed ({self.config.max_file_size} bytes)",
                "size": size,
                "max_size": self.config.max_file_size
            }

        return {
            "allowed": True,
            "reason": "File size validation passed",
            "size": size
        }

    def get_command_suggestions(self, category: str, prefix: str = "") -> List[str]:
        """Get command suggestions for a category."""
        if category not in self.allowed_commands:
            return []

        commands = self.allowed_commands[category]
        if prefix:
            commands = [cmd for cmd in commands if cmd.startswith(prefix)]

        return sorted(commands)[:20]  # Limit to 20 suggestions

    def audit_operation(self, operation: str, host: str, user: str,
                       command: Optional[str] = None, path: Optional[str] = None,
                       success: bool = True, details: Dict[str, Any] = None) -> Dict[str, Any]:
        """Create an audit log entry."""
        if not self.config.enable_audit_log:
            return {"audited": False}

        audit_entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": operation,
            "host": host,
            "user": user,
            "command": command,
            "path": path,
            "success": success,
            "details": details or {}
        }

        return {
            "audited": True,
            "entry": audit_entry,
            "log_file": self.config.audit_log_file
        }