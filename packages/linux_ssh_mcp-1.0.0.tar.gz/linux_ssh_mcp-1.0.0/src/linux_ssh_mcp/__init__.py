"""
Linux SSH MCP Server

A secure MCP server for managing Linux systems via SSH connections.
Provides AI assistants with safe and controlled access to Linux system operations.
"""

__version__ = "1.0.0"
__author__ = "MCP Development Team"
__email__ = "dev@example.com"

from .server import LinuxSSHMCPServer

__all__ = ["LinuxSSHMCPServer"]