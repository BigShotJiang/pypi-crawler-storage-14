"""File manager module."""

import asyncio
import structlog
from typing import Dict, Any, Optional
from datetime import datetime

logger = structlog.get_logger(__name__)


class FileManager:
    """Module for file operations."""

    def __init__(self, ssh_manager, security_validator):
        self.ssh_manager = ssh_manager
        self.security = security_validator
        self.max_file_size = 50 * 1024 * 1024  # 50MB

    async def file_operations(self, host_id: str, operation: str, path: str, **kwargs) -> Dict[str, Any]:
        """Perform file operations."""
        try:
            # Security validation
            security_check = await self.security.validate_path(path, operation)
            if not security_check["allowed"]:
                return {"error": f"Path validation failed: {security_check['reason']}"}

            if operation == "read":
                return await self._read_file(host_id, path)
            elif operation == "write":
                return await self._write_file(host_id, path, kwargs.get("content", ""))
            elif operation == "list":
                return await self._list_directory(host_id, path)
            elif operation == "delete":
                return await self._delete_file(host_id, path)
            elif operation == "move":
                return await self._move_file(host_id, path, kwargs.get("destination", ""))
            elif operation == "copy":
                return await self._copy_file(host_id, path, kwargs.get("destination", ""))
            else:
                return {"error": f"Unsupported operation: {operation}"}

        except Exception as e:
            logger.error("File operation failed", host_id=host_id, operation=operation, path=path, error=str(e))
            return {"error": f"Operation failed: {str(e)}"}

    async def _read_file(self, host_id: str, path: str) -> Dict[str, Any]:
        """Read file content."""
        # Check file size
        size_result = await self.ssh_manager.execute_command(host_id, f"stat -c%s '{path}' 2>/dev/null")
        if size_result.success:
            try:
                file_size = int(size_result.stdout.strip())
                if file_size > self.max_file_size:
                    return {
                        "error": f"File too large ({file_size} bytes). Max size: {self.max_file_size} bytes"
                    }
            except ValueError:
                pass

        # Read file
        result = await self.ssh_manager.execute_command(host_id, f"cat '{path}'")
        if result.success:
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "operation": "read",
                "path": path,
                "content": result.stdout,
                "success": True
            }
        else:
            return {"error": f"Failed to read file: {result.stderr}"}

    async def _write_file(self, host_id: str, path: str, content: str) -> Dict[str, Any]:
        """Write content to file."""
        content_size = len(content.encode('utf-8'))
        if content_size > self.max_file_size:
            return {
                "error": f"Content too large ({content_size} bytes). Max size: {self.max_file_size} bytes"
            }

        # Create directory if needed
        dir_path = "/".join(path.split("/")[:-1])
        if dir_path:
            await self.ssh_manager.execute_command(host_id, f"mkdir -p '{dir_path}'")

        # Write file using temporary file approach
        temp_path = f"/tmp/mcp_write_{datetime.now().timestamp()}"

        try:
            # Write to temp file
            write_result = await self.ssh_manager.execute_command(host_id, f"cat > '{temp_path}'", input_data=content)
            if not write_result.success:
                return {"error": f"Failed to write temporary file: {write_result.stderr}"}

            # Move to final location
            move_result = await self.ssh_manager.execute_command(host_id, f"mv '{temp_path}' '{path}'")
            if move_result.success:
                return {
                    "host": host_id,
                    "timestamp": datetime.now().isoformat(),
                    "operation": "write",
                    "path": path,
                    "bytes_written": content_size,
                    "success": True
                }
            else:
                # Cleanup temp file
                await self.ssh_manager.execute_command(host_id, f"rm -f '{temp_path}'")
                return {"error": f"Failed to move file: {move_result.stderr}"}

        except Exception as e:
            # Cleanup temp file
            await self.ssh_manager.execute_command(host_id, f"rm -f '{temp_path}'")
            return {"error": f"Write operation failed: {str(e)}"}

    async def _list_directory(self, host_id: str, path: str) -> Dict[str, Any]:
        """List directory contents."""
        result = await self.ssh_manager.execute_command(host_id, f"ls -la '{path}'")
        if result.success:
            lines = result.stdout.strip().split('\n')[1:]  # Skip total line
            items = []
            for line in lines:
                if line.strip():
                    parts = line.strip().split(None, 8)
                    if len(parts) >= 9:
                        items.append({
                            "permissions": parts[0],
                            "owner": parts[2],
                            "group": parts[3],
                            "size": parts[4],
                            "name": parts[8],
                            "is_directory": parts[0].startswith('d')
                        })

            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "operation": "list",
                "path": path,
                "items": items,
                "total_count": len(items),
                "success": True
            }
        else:
            return {"error": f"Failed to list directory: {result.stderr}"}

    async def _delete_file(self, host_id: str, path: str) -> Dict[str, Any]:
        """Delete file or directory."""
        # Check if path exists
        check_result = await self.ssh_manager.execute_command(host_id, f"test -e '{path}'")
        if not check_result.success:
            return {"error": f"Path does not exist: {path}"}

        # Check if it's a directory
        is_dir_result = await self.ssh_manager.execute_command(host_id, f"test -d '{path}'")
        if is_dir_result.success:
            delete_cmd = f"rm -rf '{path}'"
        else:
            delete_cmd = f"rm -f '{path}'"

        result = await self.ssh_manager.execute_command(host_id, delete_cmd)
        if result.success:
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "operation": "delete",
                "path": path,
                "success": True
            }
        else:
            return {"error": f"Failed to delete: {result.stderr}"}

    async def _move_file(self, host_id: str, source: str, destination: str) -> Dict[str, Any]:
        """Move file or directory."""
        if not destination:
            return {"error": "Destination path is required for move operation"}

        result = await self.ssh_manager.execute_command(host_id, f"mv '{source}' '{destination}'")
        if result.success:
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "operation": "move",
                "source": source,
                "destination": destination,
                "success": True
            }
        else:
            return {"error": f"Failed to move: {result.stderr}"}

    async def _copy_file(self, host_id: str, source: str, destination: str) -> Dict[str, Any]:
        """Copy file or directory."""
        if not destination:
            return {"error": "Destination path is required for copy operation"}

        # Use cp -r for directories
        check_dir = await self.ssh_manager.execute_command(host_id, f"test -d '{source}'")
        copy_cmd = f"cp -r '{source}' '{destination}'" if check_dir.success else f"cp '{source}' '{destination}'"

        result = await self.ssh_manager.execute_command(host_id, copy_cmd)
        if result.success:
            return {
                "host": host_id,
                "timestamp": datetime.now().isoformat(),
                "operation": "copy",
                "source": source,
                "destination": destination,
                "success": True
            }
        else:
            return {"error": f"Failed to copy: {result.stderr}"}