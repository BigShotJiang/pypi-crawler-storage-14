"""Data models for Linux SSH MCP server."""

from typing import Dict, List, Optional, Any, Union
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, validator


class ServerStatus(str, Enum):
    """Server connection status."""
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    ERROR = "error"


class AuthMethod(str, Enum):
    """SSH authentication methods."""
    PASSWORD = "password"
    SSH_KEY = "ssh_key"
    AGENT = "agent"


class ServerConfig(BaseModel):
    """SSH server configuration."""
    id: str = Field(..., description="Unique server identifier")
    name: str = Field(..., description="Human readable server name")
    host: str = Field(..., description="Server hostname or IP address")
    port: int = Field(22, description="SSH port number")
    username: str = Field(..., description="SSH username")
    auth_method: AuthMethod = Field(AuthMethod.SSH_KEY, description="Authentication method")
    ssh_key_path: Optional[str] = Field(None, description="Path to SSH private key")
    ssh_key_password: Optional[str] = Field(None, description="Password for SSH key")
    password: Optional[str] = Field(None, description="SSH password")
    tags: List[str] = Field(default_factory=list, description="Server tags")
    timeout: int = Field(30, description="Connection timeout in seconds")

    class Config:
        use_enum_values = True


class SystemInfo(BaseModel):
    """System information model."""
    host: str
    timestamp: datetime
    os_info: Dict[str, str]
    hostname: str
    uptime: str
    load_average: List[float]
    cpu_info: Dict[str, Any]
    memory_info: Dict[str, Any]
    disk_info: Dict[str, Any]
    network_info: Dict[str, Any]


class ProcessInfo(BaseModel):
    """Process information model."""
    user: str
    pid: int
    cpu_percent: str
    memory_percent: str
    vsz: str
    rss: str
    tty: str
    stat: str
    start: str
    time: str
    command: str


class ServiceInfo(BaseModel):
    """Service information model."""
    name: str
    load: str
    active: str
    sub: str
    description: str


class FileInfo(BaseModel):
    """File/directory information model."""
    permissions: str
    links: int
    owner: str
    group: str
    size: str
    month: str
    day: str
    time: str
    name: str

    @property
    def is_directory(self) -> bool:
        """Check if this is a directory."""
        return self.permissions.startswith('d')

    @property
    def is_executable(self) -> bool:
        """Check if this file is executable."""
        return not self.is_directory and 'x' in self.permissions[-3:]


class CommandResult(BaseModel):
    """Command execution result model."""
    host: str
    command: str
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time: float
    timestamp: datetime


class MCPResponse(BaseModel):
    """MCP tool response model."""
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class AuditLog(BaseModel):
    """Audit log entry model."""
    timestamp: datetime
    operation: str
    host: str
    user: str
    command: Optional[str] = None
    path: Optional[str] = None
    success: bool
    duration: float
    details: Dict[str, Any] = Field(default_factory=dict)


class SecurityConfig(BaseModel):
    """Security configuration model."""
    max_file_size: int = Field(50 * 1024 * 1024, description="Maximum file size in bytes")
    allowed_paths: List[str] = Field(default_factory=list, description="Allowed base paths")
    forbidden_paths: List[str] = Field(default_factory=list, description="Forbidden paths")
    command_whitelist: Dict[str, List[str]] = Field(default_factory=dict, description="Allowed commands by category")
    enable_audit_log: bool = Field(True, description="Enable audit logging")
    audit_log_file: str = Field("logs/audit.log", description="Audit log file path")
    session_timeout: int = Field(3600, description="Session timeout in seconds")

    @validator('allowed_paths', pre=True, always=True)
    def set_default_allowed_paths(cls, v):
        if not v:
            return ["/home", "/tmp", "/var/tmp", "/opt"]
        return v

    @validator('forbidden_paths', pre=True, always=True)
    def set_default_forbidden_paths(cls, v):
        if not v:
            return ["/", "/root", "/boot", "/sys", "/proc", "/dev"]
        return v