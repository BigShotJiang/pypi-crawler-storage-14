# Linux SSH MCP Server

一个安全的基于SSH的MCP服务器，用于Linux系统管理，为AI助手提供安全可控的Linux系统访问能力。

## 功能特性

### 🔒 安全性第一
- **多层安全验证**: 路径验证、命令过滤、权限控制
- **危险模式检测**: 自动识别和阻止危险命令
- **路径遍历防护**: 防止目录遍历攻击
- **审计日志**: 完整的操作记录和追踪
- **文件大小限制**: 防止资源滥用

### 🖥️ 系统管理功能
- **系统信息**: CPU、内存、磁盘、网络监控
- **文件管理**: 安全的文件读写、目录操作
- **进程管理**: 进程列表、终止、详细信息查看
- **服务管理**: systemd/sysvinit服务管理
- **命令执行**: 分类命令执行和安全验证

### 🚀 高级特性
- **多服务器管理**: 同时管理多台Linux服务器
- **连接池**: 高效的SSH连接管理
- **实时监控**: 系统状态实时更新
- **错误处理**: 智能错误分析和解决建议

## 安装

### 从源码安装

```bash
# 克隆仓库
git clone https://github.com/your-org/linux-ssh-mcp.git
cd linux-ssh-mcp

# 安装依赖
pip install -e .

# 或安装开发依赖
pip install -e ".[dev]"
```

### 使用pip安装

```bash
pip install linux-ssh-mcp
```

## 快速开始

### 1. 初始化配置

```bash
linux-mcp-server init-config
```

这将创建配置目录和示例配置文件。

### 2. 配置服务器

编辑 `config/servers.yaml`:

```yaml
servers:
  - id: "web-server-01"
    name: "Web服务器1"
    host: "192.168.1.10"
    port: 22
    username: "admin"
    auth_method: "ssh_key"
    ssh_key_path: "~/.ssh/id_rsa"
    tags: ["web", "production"]
```

### 3. 运行服务器

```bash
# 基本运行
linux-mcp-server run

# 指定日志级别
linux-mcp-server run --log-level DEBUG

# 加载配置文件
linux-mcp-server run --config config/servers.yaml
```

### 4. 配置Claude Desktop

在Claude Desktop的配置文件中添加:

```json
{
  "mcpServers": {
    "linux-ssh-mcp": {
      "command": "linux-mcp-server",
      "args": ["run"],
      "env": {}
    }
  }
}
```

## 使用说明

### CLI命令

#### 服务器管理
```bash
# 添加服务器
linux-mcp-server add-server my-server 192.168.1.100 admin --auth-method ssh_key --ssh-key-path ~/.ssh/id_rsa

# 列出服务器
linux-mcp-server list-servers

# 测试连接
linux-mcp-server list-servers --test-connection

# 测试命令
linux-mcp-server test-command my-server "uname -a"
```

### MCP工具

当与AI助手一起使用时，可以使用以下工具:

#### 连接管理
- `list_servers`: 列出所有配置的服务器
- `connect_server`: 连接到指定服务器
- `disconnect_server`: 断开服务器连接
- `test_connection`: 测试服务器连接

#### 系统信息
- `get_system_info`: 获取系统信息
  - `category`: system, cpu, memory, disk, network, processes, services

#### 文件操作
- `file_operations`: 文件操作
  - `operation`: read, write, list, delete, move, copy
  - `path`: 文件路径
  - `content`: 文件内容（写入操作）

#### 进程管理
- `process_manager`: 进程管理
  - `operation`: list, kill, details
  - `pid`: 进程ID
  - `filter_name`: 进程名过滤器

#### 服务管理
- `service_manager`: 服务管理
  - `operation`: list, status, start, stop, restart, enable, disable, logs
  - `service`: 服务名称

#### 命令执行
- `execute_command`: 执行命令
  - `command`: 要执行的命令
  - `category`: 命令类别（用于安全验证）

## 安全配置

### 路径访问控制

编辑 `config/security.yaml`:

```yaml
# 允许访问的基础路径
allowed_paths:
  - "/home"
  - "/tmp"
  - "/var/tmp"
  - "/opt/projects"

# 禁止访问的路径
forbidden_paths:
  - "/"
  - "/root"
  - "/boot"
  - "/sys"
  - "/proc"
  - "/dev"

# 最大文件大小 (字节)
max_file_size: 52428800  # 50MB
```

### 命令白名单

```yaml
# 按类别允许的命令
command_whitelist:
  system_info:
    - "uname"
    - "cat"
    - "df"
    - "free"
    - "ps"

  file_operations:
    - "ls"
    - "cat"
    - "grep"
    - "find"
    - "chmod"
```

## 开发

### 环境设置

```bash
# 克隆仓库
git clone https://github.com/your-org/linux-ssh-mcp.git
cd linux-ssh-mcp

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows

# 安装开发依赖
pip install -e ".[dev]"

# 安装pre-commit钩子
pre-commit install
```

### 代码质量

```bash
# 代码格式化
black src/
isort src/

# 代码检查
flake8 src/
mypy src/

# 运行测试
pytest

# 测试覆盖率
pytest --cov=linux_ssh_mcp --cov-report=html
```

### 构建和发布

```bash
# 构建包
python -m build

# 发布到PyPI（测试）
python -m twine upload --repository testpypi dist/*

# 发布到PyPI
python -m twine upload dist/*
```

## 架构

```
linux-ssh-mcp/
├── src/linux_ssh_mcp/
│   ├── __init__.py          # 包初始化
│   ├── cli.py              # 命令行接口
│   ├── server.py           # 主MCP服务器
│   ├── models.py           # 数据模型
│   ├── ssh_manager.py      # SSH连接管理
│   ├── security_validator.py # 安全验证
│   └── modules/            # 功能模块
│       ├── system_info.py  # 系统信息
│       ├── file_manager.py # 文件管理
│       ├── service_manager.py # 服务管理
│       └── process_manager.py # 进程管理
├── config/                 # 配置文件
├── tests/                  # 测试文件
├── docs/                   # 文档
└── pyproject.toml        # 项目配置
```

## 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 贡献

欢迎贡献代码！请查看 [CONTRIBUTING.md](CONTRIBUTING.md) 了解详情。

## 支持

- 问题报告: [GitHub Issues](https://github.com/your-org/linux-ssh-mcp/issues)
- 功能请求: [GitHub Discussions](https://github.com/your-org/linux-ssh-mcp/discussions)
- 文档: [GitHub Wiki](https://github.com/your-org/linux-ssh-mcp/wiki)

## 更新日志

查看 [CHANGELOG.md](CHANGELOG.md) 了解版本更新详情。