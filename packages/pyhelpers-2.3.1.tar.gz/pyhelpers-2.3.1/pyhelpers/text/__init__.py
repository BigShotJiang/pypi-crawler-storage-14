"""
Manipulation of textual data.
"""

from .preprocessing import *
from .similarity import *
