"""
Settings of working environment.
"""

from .configurations import *
from .preferences import *
