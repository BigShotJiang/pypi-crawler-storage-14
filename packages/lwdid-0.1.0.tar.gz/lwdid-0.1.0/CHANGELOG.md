# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-01-XX

### Added
- Initial release of the lwdid package
- Implements Lee and Wooldridge (2025) difference-in-differences method for small cross-sectional samples
- Four transformation methods:
  - `demean`: Unit-specific demeaning (Procedure 2.1)
  - `detrend`: Unit-specific detrending (Procedure 3.1)
  - `demeanq`: Quarterly demeaning with seasonal effects
  - `detrendq`: Quarterly detrending with seasonal effects
- Variance estimation options:
  - Homoskedastic OLS (exact t-based inference under CLM assumptions)
  - HC1/HC3 heteroskedasticity-robust standard errors
  - Cluster-robust standard errors
- Randomization inference:
  - Bootstrap (with replacement)
  - Permutation (Fisher randomization inference)
- Period-specific treatment effect estimates
- Time-invariant control variables with automatic centering
- Result visualization (residualized outcome plots)
- Export to Excel, CSV, and LaTeX formats
- Comprehensive exception hierarchy for informative error messages
- Validated against Lee and Wooldridge (2025) Table 3 results
