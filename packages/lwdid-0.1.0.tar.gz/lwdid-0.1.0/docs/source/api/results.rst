   215 - ``ri_pvalue``: Randomization inference p-value (if ``ri=True``)
   216 - ``ri_method``: Randomization inference method (``'permutation'`` or ``'bootstrap'``)
   217 - ``rireps``: Total number of RI replications requested
   218 - ``ri_valid``: Number of successful RI replications
   219 - ``ri_failed``: Number of failed RI replications
   220 - ``ri_seed``: Random seed used for RI (if provided)
   79    # Randomization inference summary (no full distribution stored)
   80    print(f"RI p-value: {results.ri_pvalue:.4f}")
   81    print(f"RI method: {results.ri_method}")
   82    print(f"Valid replications: {results.ri_valid}/{results.rireps}")
   74    results = lwdid(
   75        data, 'y', 'd', 'unit', 'year', 'post', 'demean',
   76        ri=True, rireps=1000, seed=42
   77    )
   78 
Results Module (results)
========================

The results module provides the ``LWDIDResults`` class, which stores and presents
estimation results from the ``lwdid()`` function.

LWDIDResults Class
------------------

.. autoclass:: lwdid.LWDIDResults
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__

Examples
--------

Accessing Core Estimates
~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

   from lwdid import lwdid

   results = lwdid(data, 'outcome', 'd', 'unit', 'year', 'post', 'demean')

   # Point estimate and inference
   print(f"ATT: {results.att:.4f}")
   print(f"Standard Error: {results.se_att:.4f}")
   print(f"t-statistic: {results.t_stat:.4f}")
   print(f"p-value: {results.pvalue:.4f}")
   print(f"95% CI: [{results.ci_lower:.4f}, {results.ci_upper:.4f}]")
   print(f"Degrees of freedom: {results.df_inference}")

Sample Information
~~~~~~~~~~~~~~~~~~

.. code-block:: python

   # Sample composition
   print(f"Total observations: {results.nobs}")
   print(f"Treated units: {results.n_treated}")
   print(f"Control units: {results.n_control}")
   print(f"Pre-treatment periods: {results.K}")
   print(f"First post-treatment period: {results.tpost1}")

Period-Specific Effects
~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

   # Access period-by-period estimates
   period_effects = results.att_by_period

   # DataFrame with columns:
   # period, tindex, beta, se, ci_lower, ci_upper, tstat, pval, N
   print(period_effects)

   # Filter to specific periods
   post_2000 = period_effects[period_effects['period'] >= 2000]

   # Check for pre-treatment effects (parallel trends test)
   pre_treatment = period_effects[period_effects['tindex'] < results.tpost1]
   significant_pre = pre_treatment[pre_treatment['pval'] < 0.05]
   if len(significant_pre) > 0:
       print("Warning: Significant pre-treatment effects detected")

Randomization Inference Results
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

   results = lwdid(data, 'y', 'd', 'unit', 'year', 'post', 'demean',
                   ri=True, rireps=1000, seed=42)

   # RI p-value
   print(f"RI p-value: {results.ri_pvalue:.4f}")
   print(f"RI method: {results.ri_method}")
   print(f"Valid replications: {results.ri_valid}/{results.rireps}")
   print(f"Failed replications: {results.ri_failed}")
   print(f"Random seed: {results.ri_seed}")

Printing Summary
~~~~~~~~~~~~~~~~

.. code-block:: python

   # Print formatted summary to console
   results.summary()

   # Or capture as string
   summary_text = str(results)

Visualization
~~~~~~~~~~~~~

.. code-block:: python

   # Basic plot
   results.plot()

   # Customized plot
   results.plot(
       figsize=(12, 6),
       title='Treatment Effects Over Time',
       ylabel='Log Cigarette Sales',
       xlabel='Year'
   )

Exporting Results
~~~~~~~~~~~~~~~~~

**Excel Export:**

.. code-block:: python

   # Export to Excel with multiple sheets
   results.to_excel('results.xlsx')

   # This creates:
   # - Summary sheet: Main ATT estimate and sample info
   # - ByPeriod sheet: Period-specific estimates
   # - RI sheet: Randomization inference results (if ri=True)

**CSV Export:**

.. code-block:: python

   # Export period-specific estimates to CSV
   results.to_csv('period_effects.csv')

**LaTeX Export:**

.. code-block:: python

   # Export publication-ready LaTeX table
   results.to_latex('table.tex')

   # Include in your LaTeX document:
   # \input{table.tex}

Working with Results Programmatically
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

   # Extract specific information
   att_estimate = results.att
   standard_error = results.se_att

   # Construct custom confidence interval (e.g., 90%)
   from scipy import stats
   alpha = 0.10
   t_crit = stats.t.ppf(1 - alpha/2, results.df_inference)
   ci_90_lower = results.att - t_crit * results.se_att
   ci_90_upper = results.att + t_crit * results.se_att
   print(f"90% CI: [{ci_90_lower:.4f}, {ci_90_upper:.4f}]")

   # Combine results from multiple specifications
   specs = []
   for rolling in ['demean', 'detrend']:
       for vce in [None, 'hc3']:
           res = lwdid(data, 'y', 'd', 'unit', 'year', 'post', rolling, vce=vce)
           specs.append({
               'rolling': rolling,
               'vce': vce or 'ols',
               'att': res.att,
               'se': res.se_att,
               'pvalue': res.pvalue
           })

   import pandas as pd
   comparison = pd.DataFrame(specs)
   print(comparison)

Attributes Reference
--------------------

Core Estimates
~~~~~~~~~~~~~~

- ``att``: Average treatment effect on the treated
- ``se_att``: Standard error of ATT
- ``t_stat``: t-statistic for testing H₀: ATT = 0
- ``pvalue``: Two-sided p-value
- ``ci_lower``: Lower bound of 95% confidence interval
- ``ci_upper``: Upper bound of 95% confidence interval
- ``df_inference``: Degrees of freedom for t-based inference

Sample Information
~~~~~~~~~~~~~~~~~~

- ``nobs``: Number of observations in the regression
- ``n_treated``: Number of treated units
- ``n_control``: Number of control units
- ``K``: Number of pre-treatment periods
- ``tpost1``: First post-treatment period index

Period-Specific Results
~~~~~~~~~~~~~~~~~~~~~~~

- ``att_by_period``: DataFrame with period-specific treatment effects

Randomization Inference
~~~~~~~~~~~~~~~~~~~~~~~

- ``ri_pvalue``: Randomization inference p-value (if ``ri=True``)
- ``ri_method``: Method used ('permutation' or 'bootstrap')
- ``rireps``: Total number of RI replications requested
- ``ri_valid``: Number of successful RI replications
- ``ri_failed``: Number of failed RI replications
- ``ri_seed``: Random seed used for RI (if provided)

Methods Reference
-----------------

- ``summary()``: Print formatted summary of results
- ``plot()``: Visualize treatment effects over time
- ``to_excel(path)``: Export results to Excel file
- ``to_csv(path)``: Export period-specific effects to CSV
- ``to_latex(path)``: Export results to LaTeX table

See Also
--------

- :func:`lwdid.lwdid` - Main estimation function
- :doc:`../user_guide` - Comprehensive usage guide
- :doc:`../quickstart` - Quick start tutorial
