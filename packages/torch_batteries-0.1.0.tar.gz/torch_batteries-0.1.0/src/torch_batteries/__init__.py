"""
torch-batteries: A lightweight Python package for PyTorch workflow abstractions.
"""

__version__ = "0.1.0"
__author__ = ["Michal Szczygiel", "Arkadiusz Paterak", "Antoni Zięciak"]
