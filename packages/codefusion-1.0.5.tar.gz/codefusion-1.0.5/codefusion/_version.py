# Static version file
__version__ = "1.0.5"
version = "1.0.5"
__version_tuple__ = (1, 0, 5)
version_tuple = (1, 0, 5)
