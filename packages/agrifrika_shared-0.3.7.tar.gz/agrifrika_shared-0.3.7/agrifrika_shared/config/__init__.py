"""
Configuration and environment settings.
"""
