import os
import time
import threading
from typing import Optional
from .utils import http_post_with_retry

_LOCK = threading.Lock()
_CLIENT = None

class PhoenixClient:
    """
    Lightweight client to send traces to Phoenix.
    Uses PHOENIX_BASE_URL env var if base_url not provided.
    """

    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None, timeout: int = 5):
        self.base_url = (base_url or os.getenv("PHOENIX_BASE_URL") or "").rstrip("/")
        if not self.base_url:
            raise RuntimeError("PHOENIX_BASE_URL must be set for PhoenixClient")
        self.api_key = api_key or os.getenv("PHOENIX_API_KEY")
        self.timeout = timeout
        self.headers = {"Content-Type": "application/json"}
        if self.api_key:
            self.headers["Authorization"] = f"Bearer {self.api_key}"

    def send_trace(self, project_id: str, user_id: str, session_id: str, messages: list, model: str, tokens: int, cost: float, metadata: dict = None):
        payload = {
            "trace_id": f"trace-{int(time.time()*1000)}",
            "session_id": session_id,
            "user_id": user_id,
            "messages": messages,
            "model": model,
            "tokens": tokens,
            "cost": cost,
            "timestamp": int(time.time()*1000),
            "metadata": metadata or {}
        }
        url = f"{self.base_url}/v1/projects/{project_id}/traces"
        return http_post_with_retry(url, payload, headers=self.headers, retries=3, timeout=self.timeout)

def register(base_url: Optional[str] = None, api_key: Optional[str] = None):
    """
    Create global client (singleton). Safe to call multiple times.
    """
    global _CLIENT
    with _LOCK:
        if _CLIENT is None:
            _CLIENT = PhoenixClient(base_url=base_url, api_key=api_key)
    return _CLIENT

def get_client() -> PhoenixClient:
    global _CLIENT
    if _CLIENT is None:
        # lazy register from env
        _CLIENT = PhoenixClient()
    return _CLIENT
