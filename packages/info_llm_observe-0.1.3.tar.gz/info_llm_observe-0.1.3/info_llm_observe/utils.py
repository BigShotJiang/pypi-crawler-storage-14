import time
import requests

def http_post_with_retry(url, json_payload, headers=None, retries=3, backoff=2, timeout=5):
    """
    Simple retry wrapper around requests.post for transient failures.
    Returns requests.Response or raises last exception.
    """
    last_exc = None
    for i in range(retries):
        try:
            r = requests.post(url, json=json_payload, headers=headers or {}, timeout=timeout)
            return r
        except Exception as e:
            last_exc = e
            time.sleep(backoff ** i)
    raise last_exc
