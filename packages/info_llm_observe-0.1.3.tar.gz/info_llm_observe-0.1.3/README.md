# info-llm-observe

Lightweight instrumentation wrapper that sends traces to Phoenix observability.

Usage:

```py
from info_llm_observe import register, instrument

# optional: register explicitly (will also read PHOENIX_BASE_URL env var)
register(base_url="http://phoenix-host")

@instrument(project_id="UHJvamVjdDo1", user_id="alice", session_id="s1")
def call_llm(prompt: str):
    # call your model...
    return "response"
