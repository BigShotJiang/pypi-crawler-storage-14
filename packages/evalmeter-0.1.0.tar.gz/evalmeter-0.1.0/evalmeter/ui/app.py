"""Streamlit UI for EvalMeter."""

import json
from datetime import datetime

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from evalmeter.storage.database import Database
from evalmeter.utils.config import Config

# Page config
st.set_page_config(
    page_title="EvalMeter Dashboard",
    page_icon="📊",
    layout="wide",
)

# Initialize
config = Config()
db = Database(config.get_db_path())

# Title
st.title("📊 EvalMeter Dashboard")
st.markdown("Measure AI Quality with Precision - Powered by AWS Bedrock")

# Sidebar
st.sidebar.header("Navigation")
page = st.sidebar.radio("Go to", ["Experiments", "Experiment Details", "Compare"])

if page == "Experiments":
    st.header("📊 Experiments")

    # Get experiments
    experiments = db.list_experiments(limit=50)

    if not experiments:
        st.info("No experiments found. Run your first evaluation!")
        st.code("evalmeter run --data data.csv --experiment my-first-eval")
    else:
        # Create DataFrame
        exp_data = []
        for exp in experiments:
            metrics = db.get_metrics(exp.id)
            results = db.get_results(exp.id)

            # Calculate average score
            avg_score = 0
            if metrics:
                scores = [m["metric_value"] for m in metrics if "mean" in m["metric_name"]]
                avg_score = sum(scores) / len(scores) if scores else 0

            exp_data.append(
                {
                    "ID": exp.id[:8],
                    "Name": exp.name,
                    "Model": exp.model_id.split(".")[-1],
                    "Status": exp.status.value,
                    "Samples": len(results),
                    "Avg Score": f"{avg_score:.3f}",
                    "Created": exp.created_at,
                }
            )

        df = pd.DataFrame(exp_data)

        # Display table
        st.dataframe(
            df,
            use_container_width=True,
            hide_index=True,
        )

        # Metrics
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Experiments", len(experiments))
        with col2:
            completed = sum(1 for e in experiments if e.status.value == "completed")
            st.metric("Completed", completed)
        with col3:
            total_samples = sum(len(db.get_results(e.id)) for e in experiments)
            st.metric("Total Samples", total_samples)
        with col4:
            if exp_data:
                avg_all = sum(float(e["Avg Score"]) for e in exp_data) / len(exp_data)
                st.metric("Avg Score", f"{avg_all:.3f}")

elif page == "Experiment Details":
    st.header("🔍 Experiment Details")

    # Get experiments
    experiments = db.list_experiments(limit=50)

    if not experiments:
        st.info("No experiments found.")
    else:
        # Select experiment
        exp_names = {f"{e.name} ({e.id[:8]})": e.id for e in experiments}
        selected = st.selectbox("Select Experiment", list(exp_names.keys()))

        if selected:
            exp_id = exp_names[selected]
            experiment = db.get_experiment(exp_id)
            metrics = db.get_metrics(exp_id)
            results = db.get_results(exp_id)

            # Display experiment info
            col1, col2 = st.columns(2)
            with col1:
                st.subheader("Experiment Info")
                st.write(f"**Name:** {experiment.name}")
                st.write(f"**Model:** {experiment.model_id}")
                st.write(f"**Status:** {experiment.status.value}")
                st.write(f"**Dataset:** {experiment.dataset_path}")
                st.write(f"**Created:** {experiment.created_at}")

            with col2:
                st.subheader("Metrics")
                if metrics:
                    for metric in metrics:
                        st.metric(
                            metric["metric_name"],
                            f"{metric['metric_value']:.4f}",
                        )
                else:
                    st.info("No metrics available")

            # Results
            st.subheader("Results")

            if results:
                # Parse scores
                results_data = []
                for r in results:
                    scores = json.loads(r["scores"])
                    row = {
                        "Input": r["input_text"][:50] + "...",
                        "Output": r["output_text"][:50] + "...",
                        "Expected": r["expected_text"][:50] + "...",
                    }
                    row.update(scores)
                    results_data.append(row)

                results_df = pd.DataFrame(results_data)
                st.dataframe(results_df, use_container_width=True)

                # Score distribution
                st.subheader("Score Distribution")

                # Get first score column
                score_cols = [c for c in results_df.columns if c not in ["Input", "Output", "Expected"]]
                if score_cols:
                    selected_metric = st.selectbox("Select Metric", score_cols)

                    fig = px.histogram(
                        results_df,
                        x=selected_metric,
                        nbins=20,
                        title=f"{selected_metric} Distribution",
                    )
                    st.plotly_chart(fig, use_container_width=True)

            else:
                st.info("No results available")

elif page == "Compare":
    st.header("⚖️ Compare Experiments")

    experiments = db.list_experiments(limit=50)

    if len(experiments) < 2:
        st.info("Need at least 2 experiments to compare.")
    else:
        # Select experiments
        exp_names = {f"{e.name} ({e.id[:8]})": e.id for e in experiments}

        col1, col2 = st.columns(2)
        with col1:
            exp1 = st.selectbox("Experiment 1", list(exp_names.keys()), key="exp1")
        with col2:
            exp2 = st.selectbox("Experiment 2", list(exp_names.keys()), key="exp2")

        if exp1 and exp2 and exp1 != exp2:
            exp1_id = exp_names[exp1]
            exp2_id = exp_names[exp2]

            # Get metrics
            metrics1 = db.get_metrics(exp1_id)
            metrics2 = db.get_metrics(exp2_id)

            # Create comparison DataFrame
            comparison_data = []
            metric_names = set([m["metric_name"] for m in metrics1 + metrics2])

            for metric_name in metric_names:
                m1 = next((m for m in metrics1 if m["metric_name"] == metric_name), None)
                m2 = next((m for m in metrics2 if m["metric_name"] == metric_name), None)

                comparison_data.append(
                    {
                        "Metric": metric_name,
                        "Experiment 1": m1["metric_value"] if m1 else 0,
                        "Experiment 2": m2["metric_value"] if m2 else 0,
                        "Difference": (m1["metric_value"] if m1 else 0)
                        - (m2["metric_value"] if m2 else 0),
                    }
                )

            comparison_df = pd.DataFrame(comparison_data)

            # Display comparison
            st.dataframe(comparison_df, use_container_width=True)

            # Bar chart
            fig = go.Figure(
                data=[
                    go.Bar(name="Experiment 1", x=comparison_df["Metric"], y=comparison_df["Experiment 1"]),
                    go.Bar(name="Experiment 2", x=comparison_df["Metric"], y=comparison_df["Experiment 2"]),
                ]
            )
            fig.update_layout(barmode="group", title="Metric Comparison")
            st.plotly_chart(fig, use_container_width=True)

# Footer
st.sidebar.markdown("---")
st.sidebar.markdown("**EvalMeter v0.1.0**")
st.sidebar.markdown("Measure AI Quality with Precision")
