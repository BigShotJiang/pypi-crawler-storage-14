"""FastAPI server for EvalMeter UI."""

from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from evalmeter.storage.database import Database
from evalmeter.utils.config import Config

app = FastAPI(title="EvalMeter API", version="0.1.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize
config = Config()
db = Database(config.get_db_path())


# Models
class ExperimentSummary(BaseModel):
    id: str
    name: str
    project_id: Optional[str] = None
    model_id: str
    status: str
    dataset_path: str
    created_at: str
    samples_count: int
    avg_score: float
    comments: Optional[str] = None


class ExperimentDetail(BaseModel):
    id: str
    name: str
    project_id: Optional[str] = None
    model_id: str
    status: str
    dataset_path: str
    created_at: str
    updated_at: Optional[str] = None
    comments: Optional[str] = None
    config: dict


class Metric(BaseModel):
    metric_name: str
    metric_value: float


class Result(BaseModel):
    id: str
    input_text: str
    output_text: str
    expected_text: str
    scores: dict
    latency_ms: float


# Routes
@app.get("/")
def root():
    return {"message": "EvalMeter API", "version": "0.1.0"}


@app.get("/api/experiments", response_model=List[ExperimentSummary])
def list_experiments(limit: int = 50):
    """List all experiments."""
    experiments = db.list_experiments(limit=limit)
    
    result = []
    for exp in experiments:
        try:
            results = db.get_results(exp.id)
            metrics = db.get_metrics(exp.id)
            
            # Calculate average score
            avg_score = 0.0
            if metrics:
                scores = [m["metric_value"] for m in metrics if "mean" in m["metric_name"]]
                avg_score = sum(scores) / len(scores) if scores else 0.0
            
            # Handle status - it might be a string or enum
            status_str = exp.status.value if hasattr(exp.status, 'value') else str(exp.status)
            
            result.append(
                ExperimentSummary(
                    id=exp.id,
                    name=exp.name,
                    project_id=exp.project_id,
                    model_id=exp.model_id,
                    status=status_str,
                    dataset_path=exp.dataset_path,
                    created_at=str(exp.created_at) if exp.created_at else "",
                    samples_count=len(results),
                    avg_score=avg_score,
                    comments=exp.comments,
                )
            )
        except Exception as e:
            # Skip experiments that cause errors
            print(f"Error processing experiment {exp.id}: {e}")
            continue
    
    return result


@app.get("/api/experiments/{experiment_id}", response_model=ExperimentDetail)
def get_experiment(experiment_id: str):
    """Get experiment details."""
    import json
    
    experiment = db.get_experiment(experiment_id)
    
    if not experiment:
        raise HTTPException(status_code=404, detail="Experiment not found")
    
    # Parse config if it's a JSON string
    config_dict = {}
    if experiment.config:
        if isinstance(experiment.config, str):
            try:
                config_dict = json.loads(experiment.config)
            except:
                config_dict = {}
        elif isinstance(experiment.config, dict):
            config_dict = experiment.config
    
    return ExperimentDetail(
        id=experiment.id,
        name=experiment.name,
        project_id=experiment.project_id,
        model_id=experiment.model_id,
        status=experiment.status.value if hasattr(experiment.status, 'value') else str(experiment.status),
        dataset_path=experiment.dataset_path,
        created_at=str(experiment.created_at) if experiment.created_at else "",
        updated_at=str(experiment.updated_at) if hasattr(experiment, 'updated_at') and experiment.updated_at else None,
        comments=experiment.comments,
        config=config_dict,
    )


@app.get("/api/experiments/{experiment_id}/metrics", response_model=List[Metric])
def get_metrics(experiment_id: str):
    """Get experiment metrics."""
    metrics = db.get_metrics(experiment_id)
    
    return [
        Metric(metric_name=m["metric_name"], metric_value=m["metric_value"])
        for m in metrics
    ]


@app.get("/api/experiments/{experiment_id}/results", response_model=List[Result])
def get_results(experiment_id: str, limit: int = 100):
    """Get experiment results."""
    import json
    
    all_results = db.get_results(experiment_id)
    results = all_results[:limit] if limit else all_results
    
    parsed_results = []
    for r in results:
        # Parse scores if it's a JSON string
        scores = r["scores"]
        if isinstance(scores, str):
            try:
                scores = json.loads(scores)
            except:
                scores = {}
        elif not isinstance(scores, dict):
            scores = {}
        
        # Parse metadata to get latency
        metadata = r.get("metadata", "{}")
        if isinstance(metadata, str):
            try:
                metadata_dict = json.loads(metadata)
                latency_ms = metadata_dict.get("latency_ms", 0.0)
            except:
                latency_ms = 0.0
        else:
            latency_ms = 0.0
        
        parsed_results.append(
            Result(
                id=r["id"],
                input_text=r["input_text"] or "",
                output_text=r["output_text"] or "",
                expected_text=r["expected_text"] or "",
                scores=scores,
                latency_ms=latency_ms,
            )
        )
    
    return parsed_results


@app.get("/api/stats")
def get_stats():
    """Get overall statistics."""
    experiments = db.list_experiments(limit=1000)
    
    total_experiments = len(experiments)
    completed = sum(1 for e in experiments if e.status.value == "completed")
    running = sum(1 for e in experiments if e.status.value == "running")
    failed = sum(1 for e in experiments if e.status.value == "failed")
    
    total_samples = sum(len(db.get_results(e.id)) for e in experiments)
    
    # Calculate average score across all experiments
    all_scores = []
    for exp in experiments:
        metrics = db.get_metrics(exp.id)
        if metrics:
            scores = [m["metric_value"] for m in metrics if "mean" in m["metric_name"]]
            if scores:
                all_scores.append(sum(scores) / len(scores))
    
    avg_score = sum(all_scores) / len(all_scores) if all_scores else 0.0
    
    return {
        "total_experiments": total_experiments,
        "completed": completed,
        "running": running,
        "failed": failed,
        "total_samples": total_samples,
        "avg_score": avg_score,
    }


@app.get("/api/projects")
def list_projects():
    """Get list of unique project IDs."""
    projects = db.get_unique_projects()
    return {"projects": projects}


@app.get("/api/projects/{project_id}/experiments")
def get_project_experiments(project_id: str):
    """Get all experiments for a project with progress data."""
    experiments = db.get_experiments_by_project(project_id)
    
    progress_data = []
    for exp in experiments:
        metrics = db.get_metrics(exp.id)
        
        # Calculate average score
        avg_score = 0.0
        if metrics:
            scores = [m["metric_value"] for m in metrics if "mean" in m["metric_name"]]
            avg_score = sum(scores) / len(scores) if scores else 0.0
        
        progress_data.append({
            "id": exp.id,
            "name": exp.name,
            "created_at": str(exp.created_at) if exp.created_at else "",
            "avg_score": avg_score,
            "status": exp.status.value if hasattr(exp.status, 'value') else str(exp.status),
            "comments": exp.comments,
        })
    
    return {
        "project_id": project_id,
        "experiments": progress_data,
        "total_experiments": len(progress_data),
    }


def main():
    """Run the API server."""
    import uvicorn
    
    uvicorn.run(app, host="0.0.0.0", port=8000)


if __name__ == "__main__":
    main()
