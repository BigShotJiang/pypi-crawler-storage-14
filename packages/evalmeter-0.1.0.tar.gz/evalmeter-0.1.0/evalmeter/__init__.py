"""
EvalMeter - Comprehensive evaluation library for Gen AI applications using AWS Bedrock.

Measure AI Quality with Precision - Powered by AWS Bedrock (Anthropic Claude Sonnet 4.5)
"""

__version__ = "0.1.0"

from evalmeter.core.evaluator import Evaluator
from evalmeter.core.evaluators.base import EvaluatorBase, EvaluationResult
from evalmeter.storage.database import Database

__all__ = [
    "Evaluator",
    "EvaluatorBase",
    "EvaluationResult",
    "Database",
]
