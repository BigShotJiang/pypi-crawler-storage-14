"""Configuration management."""

import os
from pathlib import Path


class Config:
    """Configuration manager."""

    def __init__(self):
        self.home_dir = Path.home() / ".evalmeter"
        self.home_dir.mkdir(parents=True, exist_ok=True)

    def get_db_path(self) -> str:
        """Get database path."""
        return str(self.home_dir / "evalmeter.db")

    def get_aws_region(self) -> str:
        """Get AWS region from environment or default."""
        return os.getenv("AWS_DEFAULT_REGION", "us-east-1")

    def get_default_model(self) -> str:
        """Get default Bedrock model ID."""
        return os.getenv(
            "BEDROCK_MODEL_ID",
            "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        )
