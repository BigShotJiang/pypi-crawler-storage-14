"""SQLite database operations."""

import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from evalmeter.storage.models import Experiment, ExperimentStatus, Metric, Result


class Database:
    """SQLite database manager."""

    def __init__(self, db_path: str):
        """Initialize database connection."""
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        """Create database tables if they don't exist."""
        cursor = self.conn.cursor()

        # Experiments table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS experiments (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                project_id TEXT,
                model_id TEXT NOT NULL,
                dataset_path TEXT NOT NULL,
                status TEXT NOT NULL,
                comments TEXT,
                config TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Add indexes for project_id
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_experiments_project ON experiments(project_id)"
        )

        # Results table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS results (
                id TEXT PRIMARY KEY,
                experiment_id TEXT NOT NULL,
                input_text TEXT,
                output_text TEXT,
                expected_text TEXT,
                scores TEXT,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (experiment_id) REFERENCES experiments(id)
            )
        """)

        # Metrics table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                id TEXT PRIMARY KEY,
                experiment_id TEXT NOT NULL,
                metric_name TEXT NOT NULL,
                metric_value REAL NOT NULL,
                aggregation_type TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (experiment_id) REFERENCES experiments(id)
            )
        """)

        # Create indexes
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_results_experiment ON results(experiment_id)"
        )
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_metrics_experiment ON metrics(experiment_id)"
        )

        self.conn.commit()

    def create_experiment(self, experiment: Experiment) -> str:
        """Create a new experiment."""
        experiment_id = str(uuid.uuid4())
        cursor = self.conn.cursor()

        cursor.execute(
            """
            INSERT INTO experiments (id, name, project_id, model_id, dataset_path, status, comments, config)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                experiment_id,
                experiment.name,
                experiment.project_id,
                experiment.model_id,
                experiment.dataset_path,
                experiment.status.value,
                experiment.comments,
                experiment.config,
            ),
        )

        self.conn.commit()
        return experiment_id

    def get_experiment(self, experiment_id: str) -> Optional[Experiment]:
        """Get experiment by ID."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM experiments WHERE id = ?", (experiment_id,))
        row = cursor.fetchone()

        if row:
            # Handle status - default to completed if None or invalid
            status_value = row["status"]
            try:
                status = ExperimentStatus(status_value) if status_value else ExperimentStatus.COMPLETED
            except ValueError:
                status = ExperimentStatus.COMPLETED
            
            return Experiment(
                id=row["id"],
                name=row["name"],
                project_id=row["project_id"] if "project_id" in row.keys() else None,
                model_id=row["model_id"],
                dataset_path=row["dataset_path"],
                status=status,
                comments=row["comments"] if "comments" in row.keys() else None,
                config=row["config"],
                created_at=row["created_at"],
                updated_at=row["updated_at"],
            )
        return None

    def list_experiments(self, limit: int = 10) -> List[Experiment]:
        """List recent experiments."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM experiments ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )

        experiments = []
        for row in cursor.fetchall():
            # Handle status - default to completed if None or invalid
            status_value = row["status"]
            try:
                status = ExperimentStatus(status_value) if status_value else ExperimentStatus.COMPLETED
            except ValueError:
                status = ExperimentStatus.COMPLETED
            
            experiments.append(
                Experiment(
                    id=row["id"],
                    name=row["name"],
                    project_id=row["project_id"] if "project_id" in row.keys() else None,
                    model_id=row["model_id"],
                    dataset_path=row["dataset_path"],
                    status=status,
                    comments=row["comments"] if "comments" in row.keys() else None,
                    config=row["config"],
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                )
            )

        return experiments

    def update_experiment_status(self, experiment_id: str, status: ExperimentStatus):
        """Update experiment status."""
        cursor = self.conn.cursor()
        cursor.execute(
            """
            UPDATE experiments 
            SET status = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?
        """,
            (status.value, experiment_id),
        )
        self.conn.commit()

    def create_result(
        self,
        experiment_id: str,
        input_text: str,
        output_text: str,
        expected_text: str,
        scores: str,
        metadata: str,
    ) -> str:
        """Create a new result."""
        result_id = str(uuid.uuid4())
        cursor = self.conn.cursor()

        cursor.execute(
            """
            INSERT INTO results 
            (id, experiment_id, input_text, output_text, expected_text, scores, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
            (result_id, experiment_id, input_text, output_text, expected_text, scores, metadata),
        )

        self.conn.commit()
        return result_id

    def get_results(self, experiment_id: str) -> List[dict]:
        """Get all results for an experiment."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM results WHERE experiment_id = ? ORDER BY created_at",
            (experiment_id,),
        )

        results = []
        for row in cursor.fetchall():
            results.append(dict(row))

        return results

    def create_metric(
        self,
        experiment_id: str,
        metric_name: str,
        metric_value: float,
        aggregation_type: str,
    ) -> str:
        """Create a new metric."""
        metric_id = str(uuid.uuid4())
        cursor = self.conn.cursor()

        cursor.execute(
            """
            INSERT INTO metrics 
            (id, experiment_id, metric_name, metric_value, aggregation_type)
            VALUES (?, ?, ?, ?, ?)
        """,
            (metric_id, experiment_id, metric_name, metric_value, aggregation_type),
        )

        self.conn.commit()
        return metric_id

    def get_metrics(self, experiment_id: str) -> List[dict]:
        """Get all metrics for an experiment."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM metrics WHERE experiment_id = ?",
            (experiment_id,),
        )

        metrics = []
        for row in cursor.fetchall():
            metrics.append(dict(row))

        return metrics

    def get_experiments_by_project(self, project_id: str) -> List[Experiment]:
        """Get all experiments for a project."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT * FROM experiments WHERE project_id = ? ORDER BY created_at ASC",
            (project_id,),
        )

        experiments = []
        for row in cursor.fetchall():
            # Handle status - default to completed if None or invalid
            status_value = row["status"]
            try:
                status = ExperimentStatus(status_value) if status_value else ExperimentStatus.COMPLETED
            except ValueError:
                status = ExperimentStatus.COMPLETED
            
            experiments.append(
                Experiment(
                    id=row["id"],
                    name=row["name"],
                    project_id=row["project_id"] if "project_id" in row.keys() else None,
                    model_id=row["model_id"],
                    dataset_path=row["dataset_path"],
                    status=status,
                    comments=row["comments"] if "comments" in row.keys() else None,
                    config=row["config"],
                    created_at=row["created_at"],
                    updated_at=row["updated_at"],
                )
            )

        return experiments
    
    def get_unique_projects(self) -> List[str]:
        """Get list of unique project IDs."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT DISTINCT project_id FROM experiments WHERE project_id IS NOT NULL ORDER BY project_id"
        )
        return [row[0] for row in cursor.fetchall()]

    def close(self):
        """Close database connection."""
        self.conn.close()
