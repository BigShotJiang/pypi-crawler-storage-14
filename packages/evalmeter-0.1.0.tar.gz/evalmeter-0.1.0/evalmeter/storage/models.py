"""Data models for storage."""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Optional


class ExperimentStatus(str, Enum):
    """Experiment status enum."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Experiment:
    """Experiment model."""

    name: str
    model_id: str
    dataset_path: str
    status: ExperimentStatus
    config: str  # JSON string
    project_id: Optional[str] = None
    comments: Optional[str] = None
    id: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


@dataclass
class Result:
    """Evaluation result model."""

    experiment_id: str
    input_text: str
    output_text: str
    expected_text: str
    scores: str  # JSON string
    metadata: str  # JSON string
    id: Optional[str] = None
    created_at: Optional[datetime] = None


@dataclass
class Metric:
    """Aggregated metric model."""

    experiment_id: str
    metric_name: str
    metric_value: float
    aggregation_type: str  # mean, min, max, etc.
    id: Optional[str] = None
    created_at: Optional[datetime] = None
