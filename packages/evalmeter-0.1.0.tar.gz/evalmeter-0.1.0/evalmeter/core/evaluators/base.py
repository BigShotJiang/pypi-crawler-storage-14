"""Base evaluator class."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict


@dataclass
class EvaluationResult:
    """Result of an evaluation."""

    score: float  # Score between 0 and 1
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Validate score is between 0 and 1."""
        if not 0 <= self.score <= 1:
            raise ValueError(f"Score must be between 0 and 1, got {self.score}")


class EvaluatorBase(ABC):
    """Base class for all evaluators."""

    def __init__(self, name: str, **kwargs):
        """
        Initialize evaluator.

        Args:
            name: Evaluator name
            **kwargs: Additional configuration
        """
        self.name = name
        self.config = kwargs

    @abstractmethod
    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """
        Evaluate the output against expected.

        Args:
            input_text: Input/prompt text
            output_text: Model output to evaluate
            expected_text: Expected/ground truth output
            **kwargs: Additional evaluation parameters

        Returns:
            EvaluationResult with score and metadata
        """
        pass

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name='{self.name}')"
