"""Heuristic evaluators for simple text matching."""

import re
from difflib import SequenceMatcher

from evalmeter.core.evaluators.base import EvaluatorBase, EvaluationResult


class ExactMatchEvaluator(EvaluatorBase):
    """Exact string match evaluator."""

    def __init__(self, case_sensitive: bool = False, **kwargs):
        super().__init__(name="exact_match", **kwargs)
        self.case_sensitive = case_sensitive

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Check if output exactly matches expected."""
        if not expected_text:
            return EvaluationResult(score=0.0, metadata={"error": "No expected text provided"})

        output = output_text if self.case_sensitive else output_text.lower()
        expected = expected_text if self.case_sensitive else expected_text.lower()

        # Strip whitespace
        output = output.strip()
        expected = expected.strip()

        match = output == expected
        score = 1.0 if match else 0.0

        return EvaluationResult(
            score=score,
            metadata={
                "match": match,
                "output_length": len(output_text),
                "expected_length": len(expected_text),
            },
        )


class FuzzyMatchEvaluator(EvaluatorBase):
    """Fuzzy string match evaluator using SequenceMatcher."""

    def __init__(self, threshold: float = 0.8, **kwargs):
        super().__init__(name="fuzzy_match", **kwargs)
        self.threshold = threshold

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Calculate fuzzy match score."""
        if not expected_text:
            return EvaluationResult(score=0.0, metadata={"error": "No expected text provided"})

        # Calculate similarity ratio
        similarity = SequenceMatcher(None, output_text.strip(), expected_text.strip()).ratio()

        return EvaluationResult(
            score=similarity,
            metadata={
                "similarity": similarity,
                "threshold": self.threshold,
                "passes_threshold": similarity >= self.threshold,
            },
        )


class ContainsEvaluator(EvaluatorBase):
    """Check if output contains expected text."""

    def __init__(self, case_sensitive: bool = False, **kwargs):
        super().__init__(name="contains", **kwargs)
        self.case_sensitive = case_sensitive

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Check if output contains expected text."""
        if not expected_text:
            return EvaluationResult(score=0.0, metadata={"error": "No expected text provided"})

        output = output_text if self.case_sensitive else output_text.lower()
        expected = expected_text if self.case_sensitive else expected_text.lower()

        contains = expected in output
        score = 1.0 if contains else 0.0

        return EvaluationResult(
            score=score,
            metadata={
                "contains": contains,
                "expected_text": expected_text,
            },
        )


class RegexMatchEvaluator(EvaluatorBase):
    """Regular expression match evaluator."""

    def __init__(self, pattern: str = None, **kwargs):
        super().__init__(name="regex_match", **kwargs)
        self.pattern = pattern

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Check if output matches regex pattern."""
        # Use expected_text as pattern if not provided in init
        pattern = self.pattern or expected_text

        if not pattern:
            return EvaluationResult(score=0.0, metadata={"error": "No pattern provided"})

        try:
            match = re.search(pattern, output_text)
            score = 1.0 if match else 0.0

            metadata = {
                "pattern": pattern,
                "match": match is not None,
            }

            if match:
                metadata["matched_text"] = match.group(0)
                metadata["match_start"] = match.start()
                metadata["match_end"] = match.end()

            return EvaluationResult(score=score, metadata=metadata)

        except re.error as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"Invalid regex pattern: {str(e)}"},
            )
