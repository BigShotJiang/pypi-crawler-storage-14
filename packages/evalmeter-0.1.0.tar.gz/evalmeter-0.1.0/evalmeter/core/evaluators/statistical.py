"""Statistical evaluators for text similarity."""

import Levenshtein
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge import Rouge

from evalmeter.core.evaluators.base import EvaluatorBase, EvaluationResult


class BLEUEvaluator(EvaluatorBase):
    """BLEU score evaluator for text similarity."""

    def __init__(self, **kwargs):
        super().__init__(name="bleu", **kwargs)
        self.smoothing = SmoothingFunction()

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Calculate BLEU score."""
        if not expected_text:
            return EvaluationResult(score=0.0, metadata={"error": "No expected text provided"})

        # Tokenize
        reference = [expected_text.split()]
        hypothesis = output_text.split()

        # Calculate BLEU score with smoothing
        try:
            bleu_score = sentence_bleu(
                reference,
                hypothesis,
                smoothing_function=self.smoothing.method1,
            )
        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"BLEU calculation failed: {str(e)}"},
            )

        return EvaluationResult(
            score=bleu_score,
            metadata={
                "bleu_score": bleu_score,
                "reference_length": len(reference[0]),
                "hypothesis_length": len(hypothesis),
            },
        )


class ROUGEEvaluator(EvaluatorBase):
    """ROUGE score evaluator for text similarity."""

    def __init__(self, **kwargs):
        super().__init__(name="rouge", **kwargs)
        self.scorer = Rouge()

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Calculate ROUGE scores."""
        if not expected_text:
            return EvaluationResult(score=0.0, metadata={"error": "No expected text provided"})

        try:
            # Rouge library requires non-empty strings
            if not output_text.strip() or not expected_text.strip():
                return EvaluationResult(score=0.0, metadata={"error": "Empty text provided"})
            
            scores = self.scorer.get_scores(output_text, expected_text)[0]

            # Use ROUGE-L F1 as primary score
            primary_score = scores["rouge-l"]["f"]

            metadata = {
                "rouge-1_precision": scores["rouge-1"]["p"],
                "rouge-1_recall": scores["rouge-1"]["r"],
                "rouge-1_fmeasure": scores["rouge-1"]["f"],
                "rouge-2_precision": scores["rouge-2"]["p"],
                "rouge-2_recall": scores["rouge-2"]["r"],
                "rouge-2_fmeasure": scores["rouge-2"]["f"],
                "rouge-l_precision": scores["rouge-l"]["p"],
                "rouge-l_recall": scores["rouge-l"]["r"],
                "rouge-l_fmeasure": scores["rouge-l"]["f"],
            }

            return EvaluationResult(score=primary_score, metadata=metadata)

        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"ROUGE calculation failed: {str(e)}"},
            )


class LevenshteinEvaluator(EvaluatorBase):
    """Levenshtein distance evaluator (normalized edit distance)."""

    def __init__(self, **kwargs):
        super().__init__(name="levenshtein", **kwargs)

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Calculate normalized Levenshtein similarity."""
        if not expected_text:
            return EvaluationResult(score=0.0, metadata={"error": "No expected text provided"})

        # Calculate edit distance
        distance = Levenshtein.distance(output_text, expected_text)

        # Normalize by max length
        max_len = max(len(output_text), len(expected_text))
        if max_len == 0:
            similarity = 1.0
        else:
            similarity = 1.0 - (distance / max_len)

        return EvaluationResult(
            score=similarity,
            metadata={
                "edit_distance": distance,
                "similarity": similarity,
                "output_length": len(output_text),
                "expected_length": len(expected_text),
            },
        )


class CosineSimilarityEvaluator(EvaluatorBase):
    """Cosine similarity evaluator using embeddings."""

    def __init__(
        self, 
        model_id: str = None, 
        aws_region: str = "us-east-1", 
        **kwargs
    ):
        super().__init__(name="cosine_similarity", **kwargs)
        # Always use Titan Embeddings V2, ignore passed model_id
        self.model_id = "amazon.titan-embed-text-v2:0"
        self.aws_region = aws_region
        self._bedrock_client = None

    def _get_bedrock_client(self):
        """Lazy initialization of Bedrock client."""
        if self._bedrock_client is None:
            import boto3
            self._bedrock_client = boto3.client(
                service_name="bedrock-runtime",
                region_name=self.aws_region,
            )
        return self._bedrock_client

    def _get_embedding(self, text: str) -> list:
        """Get embedding vector for text using Bedrock Titan Embeddings V2."""
        import json
        
        client = self._get_bedrock_client()
        
        # Prepare request for Titan Embeddings V2
        request_body = json.dumps({
            "inputText": text,
            "dimensions": 1024,  # Titan V2 supports 256, 512, 1024
            "normalize": True     # Normalize for cosine similarity
        })
        
        try:
            response = client.invoke_model(
                modelId=self.model_id,
                body=request_body,
                contentType="application/json",
                accept="application/json"
            )
            
            response_body = json.loads(response["body"].read())
            embedding = response_body.get("embedding", [])
            
            return embedding
            
        except Exception as e:
            raise RuntimeError(f"Failed to get embedding: {str(e)}")

    def _cosine_similarity(self, vec1: list, vec2: list) -> float:
        """Calculate cosine similarity between two vectors."""
        import math
        
        # Dot product
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        
        # Magnitudes
        magnitude1 = math.sqrt(sum(a * a for a in vec1))
        magnitude2 = math.sqrt(sum(b * b for b in vec2))
        
        # Avoid division by zero
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        # Cosine similarity
        similarity = dot_product / (magnitude1 * magnitude2)
        
        # Normalize to 0-1 range (cosine similarity is -1 to 1)
        normalized_similarity = (similarity + 1) / 2
        
        return normalized_similarity

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Calculate cosine similarity using embeddings."""
        if not expected_text:
            return EvaluationResult(
                score=0.0, 
                metadata={"error": "No expected text provided"}
            )

        if not output_text:
            return EvaluationResult(
                score=0.0,
                metadata={"error": "No output text provided"}
            )

        try:
            # Get embeddings for both texts
            output_embedding = self._get_embedding(output_text)
            expected_embedding = self._get_embedding(expected_text)
            
            # Calculate cosine similarity
            similarity = self._cosine_similarity(output_embedding, expected_embedding)
            
            return EvaluationResult(
                score=similarity,
                metadata={
                    "cosine_similarity": similarity,
                    "embedding_model": self.model_id,
                    "embedding_dimensions": len(output_embedding),
                    "output_length": len(output_text),
                    "expected_length": len(expected_text),
                },
            )
            
        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"Cosine similarity calculation failed: {str(e)}"},
            )
