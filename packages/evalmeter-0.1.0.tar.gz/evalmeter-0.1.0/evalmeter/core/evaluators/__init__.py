"""Evaluator implementations."""

from evalmeter.core.evaluators.base import EvaluatorBase, EvaluationResult
from evalmeter.core.evaluators.heuristic import (
    ExactMatchEvaluator,
    FuzzyMatchEvaluator,
    ContainsEvaluator,
    RegexMatchEvaluator,
)
from evalmeter.core.evaluators.statistical import (
    BLEUEvaluator,
    ROUGEEvaluator,
    LevenshteinEvaluator,
    CosineSimilarityEvaluator,
)
from evalmeter.core.evaluators.llm_judge import (
    FactualityEvaluator,
    RelevanceEvaluator,
    CoherenceEvaluator,
    CompletenessEvaluator,
)

# Registry of available evaluators
EVALUATOR_REGISTRY = {
    # Heuristic
    "exact_match": ExactMatchEvaluator,
    "fuzzy_match": FuzzyMatchEvaluator,
    "contains": ContainsEvaluator,
    "regex_match": RegexMatchEvaluator,
    # Statistical
    "bleu": BLEUEvaluator,
    "rouge": ROUGEEvaluator,
    "levenshtein": LevenshteinEvaluator,
    "cosine_similarity": CosineSimilarityEvaluator,
    # LLM-as-Judge
    "factuality": FactualityEvaluator,
    "relevance": RelevanceEvaluator,
    "coherence": CoherenceEvaluator,
    "completeness": CompletenessEvaluator,
}


def get_evaluator(name: str, **kwargs) -> EvaluatorBase:
    """
    Get evaluator instance by name.

    Args:
        name: Evaluator name
        **kwargs: Additional arguments for evaluator

    Returns:
        Evaluator instance

    Raises:
        ValueError: If evaluator name is not found
    """
    if name not in EVALUATOR_REGISTRY:
        available = ", ".join(EVALUATOR_REGISTRY.keys())
        raise ValueError(f"Unknown evaluator: {name}. Available: {available}")

    evaluator_class = EVALUATOR_REGISTRY[name]
    return evaluator_class(**kwargs)


def list_evaluators() -> list[str]:
    """List all available evaluators."""
    return list(EVALUATOR_REGISTRY.keys())


__all__ = [
    "EvaluatorBase",
    "EvaluationResult",
    "get_evaluator",
    "list_evaluators",
    "EVALUATOR_REGISTRY",
]
