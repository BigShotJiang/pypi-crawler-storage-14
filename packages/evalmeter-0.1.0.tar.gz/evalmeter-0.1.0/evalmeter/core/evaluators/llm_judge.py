"""LLM-as-judge evaluators using AWS Bedrock."""

import json
from typing import Optional

from evalmeter.core.bedrock_client import BedrockClient
from evalmeter.core.evaluators.base import EvaluatorBase, EvaluationResult


class LLMJudgeEvaluator(EvaluatorBase):
    """Base class for LLM-as-judge evaluators."""

    def __init__(
        self,
        name: str,
        model_id: str = "us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        aws_region: str = "us-east-1",
        **kwargs,
    ):
        super().__init__(name=name, **kwargs)
        self.client = BedrockClient(model_id=model_id, aws_region=aws_region)

    def _parse_score_from_response(self, response: str) -> float:
        """Parse score from LLM response."""
        try:
            # Try to parse as JSON
            data = json.loads(response)
            if "score" in data:
                return float(data["score"])
            elif "rating" in data:
                return float(data["rating"]) / 10.0  # Normalize 1-10 to 0-1
        except (json.JSONDecodeError, ValueError):
            pass

        # Try to extract number from text
        import re

        numbers = re.findall(r"\b([0-9](?:\.[0-9]+)?)\b", response)
        if numbers:
            score = float(numbers[0])
            # Normalize if needed
            if score > 1.0:
                score = score / 10.0
            return min(max(score, 0.0), 1.0)

        return 0.5  # Default to neutral score


class FactualityEvaluator(LLMJudgeEvaluator):
    """Evaluate factual accuracy using LLM."""

    def __init__(self, **kwargs):
        super().__init__(name="factuality", **kwargs)

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Evaluate factual accuracy."""
        prompt = f"""You are an expert fact-checker. Evaluate the factual accuracy of the output compared to the expected answer.

Input Question: {input_text}

Expected Answer: {expected_text}

Actual Output: {output_text}

Evaluate the factual accuracy on a scale of 0 to 1, where:
- 1.0 = Completely accurate, all facts are correct
- 0.7-0.9 = Mostly accurate with minor issues
- 0.4-0.6 = Partially accurate
- 0.1-0.3 = Mostly inaccurate
- 0.0 = Completely inaccurate or contradicts facts

Respond in JSON format:
{{
  "score": <float between 0 and 1>,
  "reasoning": "<brief explanation>",
  "issues": ["<list of factual issues if any>"]
}}"""

        try:
            response = self.client.invoke(prompt, temperature=0.0)
            content = response["content"]

            # Parse JSON response
            try:
                data = json.loads(content)
                score = float(data.get("score", 0.5))
                reasoning = data.get("reasoning", "")
                issues = data.get("issues", [])
            except (json.JSONDecodeError, ValueError):
                score = self._parse_score_from_response(content)
                reasoning = content
                issues = []

            return EvaluationResult(
                score=score,
                metadata={
                    "reasoning": reasoning,
                    "issues": issues,
                    "raw_response": content,
                },
            )

        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"Evaluation failed: {str(e)}"},
            )


class RelevanceEvaluator(LLMJudgeEvaluator):
    """Evaluate answer relevance using LLM."""

    def __init__(self, **kwargs):
        super().__init__(name="relevance", **kwargs)

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Evaluate answer relevance."""
        prompt = f"""You are an expert evaluator. Assess how relevant the output is to the input question.

Input Question: {input_text}

Output: {output_text}

Evaluate the relevance on a scale of 0 to 1, where:
- 1.0 = Perfectly relevant, directly answers the question
- 0.7-0.9 = Mostly relevant with minor tangents
- 0.4-0.6 = Partially relevant
- 0.1-0.3 = Barely relevant
- 0.0 = Completely irrelevant

Respond in JSON format:
{{
  "score": <float between 0 and 1>,
  "reasoning": "<brief explanation>"
}}"""

        try:
            response = self.client.invoke(prompt, temperature=0.0)
            content = response["content"]

            try:
                data = json.loads(content)
                score = float(data.get("score", 0.5))
                reasoning = data.get("reasoning", "")
            except (json.JSONDecodeError, ValueError):
                score = self._parse_score_from_response(content)
                reasoning = content

            return EvaluationResult(
                score=score,
                metadata={"reasoning": reasoning, "raw_response": content},
            )

        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"Evaluation failed: {str(e)}"},
            )


class CoherenceEvaluator(LLMJudgeEvaluator):
    """Evaluate response coherence using LLM."""

    def __init__(self, **kwargs):
        super().__init__(name="coherence", **kwargs)

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Evaluate response coherence."""
        prompt = f"""You are an expert evaluator. Assess the coherence and logical flow of the output.

Output: {output_text}

Evaluate the coherence on a scale of 0 to 1, where:
- 1.0 = Perfectly coherent, logical, and well-structured
- 0.7-0.9 = Mostly coherent with minor issues
- 0.4-0.6 = Somewhat coherent but has logical gaps
- 0.1-0.3 = Poorly structured and hard to follow
- 0.0 = Incoherent and illogical

Respond in JSON format:
{{
  "score": <float between 0 and 1>,
  "reasoning": "<brief explanation>"
}}"""

        try:
            response = self.client.invoke(prompt, temperature=0.0)
            content = response["content"]

            try:
                data = json.loads(content)
                score = float(data.get("score", 0.5))
                reasoning = data.get("reasoning", "")
            except (json.JSONDecodeError, ValueError):
                score = self._parse_score_from_response(content)
                reasoning = content

            return EvaluationResult(
                score=score,
                metadata={"reasoning": reasoning, "raw_response": content},
            )

        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"Evaluation failed: {str(e)}"},
            )


class CompletenessEvaluator(LLMJudgeEvaluator):
    """Evaluate answer completeness using LLM."""

    def __init__(self, **kwargs):
        super().__init__(name="completeness", **kwargs)

    def evaluate(
        self,
        input_text: str,
        output_text: str,
        expected_text: str = "",
        **kwargs,
    ) -> EvaluationResult:
        """Evaluate answer completeness."""
        prompt = f"""You are an expert evaluator. Assess how complete the output is in answering the question.

Input Question: {input_text}

Expected Answer: {expected_text}

Actual Output: {output_text}

Evaluate the completeness on a scale of 0 to 1, where:
- 1.0 = Fully complete, covers all aspects
- 0.7-0.9 = Mostly complete with minor omissions
- 0.4-0.6 = Partially complete
- 0.1-0.3 = Incomplete, missing major points
- 0.0 = Does not address the question

Respond in JSON format:
{{
  "score": <float between 0 and 1>,
  "reasoning": "<brief explanation>",
  "missing_points": ["<list of missing information>"]
}}"""

        try:
            response = self.client.invoke(prompt, temperature=0.0)
            content = response["content"]

            try:
                data = json.loads(content)
                score = float(data.get("score", 0.5))
                reasoning = data.get("reasoning", "")
                missing = data.get("missing_points", [])
            except (json.JSONDecodeError, ValueError):
                score = self._parse_score_from_response(content)
                reasoning = content
                missing = []

            return EvaluationResult(
                score=score,
                metadata={
                    "reasoning": reasoning,
                    "missing_points": missing,
                    "raw_response": content,
                },
            )

        except Exception as e:
            return EvaluationResult(
                score=0.0,
                metadata={"error": f"Evaluation failed: {str(e)}"},
            )
