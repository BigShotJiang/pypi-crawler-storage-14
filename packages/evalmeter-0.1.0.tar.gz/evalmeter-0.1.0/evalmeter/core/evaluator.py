"""Main Evaluator class for running evaluations."""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union

from evalmeter.core.data_loader import DataLoader
from evalmeter.core.evaluators import get_evaluator
from evalmeter.storage.database import Database
from evalmeter.storage.models import Experiment, ExperimentStatus
from evalmeter.utils.config import Config


class EvaluationResults:
    """Container for evaluation results."""

    def __init__(self, experiment_id: str, results: List[Dict], metrics: Dict):
        self.experiment_id = experiment_id
        self.results = results
        self.metrics = metrics

    def summary(self) -> str:
        """Generate a summary of the evaluation results."""
        lines = [
            f"\n{'='*60}",
            f"Experiment: {self.experiment_id}",
            f"{'='*60}",
            f"Total samples: {len(self.results)}",
            f"\nMetrics:",
        ]

        for metric_name, value in self.metrics.items():
            lines.append(f"  {metric_name}: {value:.4f}")

        lines.append(f"{'='*60}\n")
        return "\n".join(lines)

    def __iter__(self):
        """Allow iteration over results."""
        return iter(self.results)

    def __len__(self):
        """Return number of results."""
        return len(self.results)


class Evaluator:
    """Main evaluator class for running Gen AI evaluations."""

    def __init__(
        self,
        model_id: str = "anthropic.claude-sonnet-4-20250514",
        aws_region: str = "us-east-1",
        db_path: Optional[str] = None,
    ):
        """
        Initialize the Evaluator.

        Args:
            model_id: AWS Bedrock model ID
            aws_region: AWS region for Bedrock
            db_path: Path to SQLite database (default: ~/.bedrock-eval/bedrock_eval.db)
        """
        self.model_id = model_id
        self.aws_region = aws_region
        self.config = Config()

        # Initialize database
        if db_path is None:
            db_path = self.config.get_db_path()
        self.db = Database(db_path)

    def run(
        self,
        data_path: Union[str, Path],
        experiment_name: Optional[str] = None,
        project_id: Optional[str] = None,
        comments: Optional[str] = None,
        evaluators: Optional[List[str]] = None,
        **kwargs,
    ) -> EvaluationResults:
        """
        Run evaluation on the provided dataset.

        Args:
            data_path: Path to data file (CSV, JSONL, JSON, Parquet)
            experiment_name: Name for this experiment
            evaluators: List of evaluator names to run
            **kwargs: Additional configuration options

        Returns:
            EvaluationResults object with results and metrics
        """
        # Load data
        data_loader = DataLoader()
        data = data_loader.load(data_path)

        # Generate experiment name if not provided
        if experiment_name is None:
            experiment_name = f"eval_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

        # Create experiment record
        experiment = Experiment(
            name=experiment_name,
            project_id=project_id,
            model_id=self.model_id,
            dataset_path=str(data_path),
            status=ExperimentStatus.RUNNING,
            comments=comments,
            config=json.dumps(
                {
                    "evaluators": evaluators or ["accuracy"],
                    "aws_region": self.aws_region,
                    **kwargs,
                }
            ),
        )
        experiment_id = self.db.create_experiment(experiment)

        try:
            # Initialize evaluators
            if evaluators is None:
                evaluators = ["exact_match"]

            evaluator_instances = []
            for eval_name in evaluators:
                evaluator_instances.append(
                    get_evaluator(
                        eval_name,
                        model_id=self.model_id,
                        aws_region=self.aws_region,
                    )
                )

            # Run evaluations
            all_results = []
            for idx, row in data.iterrows():
                input_text = row.get("input", "")
                output_text = row.get("output", "")
                expected_text = row.get("expected", "")

                # Run each evaluator
                scores = {}
                for evaluator in evaluator_instances:
                    result = evaluator.evaluate(
                        input_text=input_text,
                        output_text=output_text,
                        expected_text=expected_text,
                    )
                    scores[evaluator.name] = result.score
                    scores.update(result.metadata)

                # Store result
                result_data = {
                    "input": input_text,
                    "output": output_text,
                    "expected": expected_text,
                    "scores": scores,
                }
                all_results.append(result_data)

                # Save to database
                self.db.create_result(
                    experiment_id=experiment_id,
                    input_text=input_text,
                    output_text=output_text,
                    expected_text=expected_text,
                    scores=json.dumps(scores),
                    metadata=json.dumps({}),
                )

            # Calculate aggregate metrics
            metrics = self._calculate_metrics(all_results, evaluators)

            # Save metrics to database
            for metric_name, metric_value in metrics.items():
                self.db.create_metric(
                    experiment_id=experiment_id,
                    metric_name=metric_name,
                    metric_value=metric_value,
                    aggregation_type="mean",
                )

            # Update experiment status
            self.db.update_experiment_status(experiment_id, ExperimentStatus.COMPLETED)

            return EvaluationResults(experiment_id, all_results, metrics)

        except Exception as e:
            # Update experiment status to failed
            self.db.update_experiment_status(experiment_id, ExperimentStatus.FAILED)
            raise e

    def _calculate_metrics(
        self, results: List[Dict], evaluator_names: List[str]
    ) -> Dict[str, float]:
        """Calculate aggregate metrics from results."""
        metrics = {}

        for eval_name in evaluator_names:
            scores = [r["scores"].get(eval_name, 0) for r in results if eval_name in r["scores"]]
            if scores:
                metrics[f"{eval_name}_mean"] = sum(scores) / len(scores)
                metrics[f"{eval_name}_min"] = min(scores)
                metrics[f"{eval_name}_max"] = max(scores)

        return metrics

    def list_experiments(self, limit: int = 10) -> List[Experiment]:
        """List recent experiments."""
        return self.db.list_experiments(limit=limit)

    def get_experiment(self, experiment_id: str) -> Optional[Experiment]:
        """Get experiment by ID."""
        return self.db.get_experiment(experiment_id)

    def get_results(self, experiment_id: str) -> List[Dict]:
        """Get all results for an experiment."""
        return self.db.get_results(experiment_id)
