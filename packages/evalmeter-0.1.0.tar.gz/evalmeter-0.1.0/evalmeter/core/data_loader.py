"""Data loader for various file formats."""

import json
from pathlib import Path
from typing import Union

import pandas as pd


class DataLoader:
    """Load evaluation data from various file formats."""

    SUPPORTED_FORMATS = [".csv", ".jsonl", ".json", ".parquet"]

    def load(self, file_path: Union[str, Path]) -> pd.DataFrame:
        """
        Load data from file.

        Args:
            file_path: Path to data file

        Returns:
            pandas DataFrame with columns: input, output, expected

        Raises:
            ValueError: If file format is not supported
            FileNotFoundError: If file doesn't exist
        """
        file_path = Path(file_path)

        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        suffix = file_path.suffix.lower()

        if suffix == ".csv":
            return self._load_csv(file_path)
        elif suffix == ".jsonl":
            return self._load_jsonl(file_path)
        elif suffix == ".json":
            return self._load_json(file_path)
        elif suffix == ".parquet":
            return self._load_parquet(file_path)
        else:
            raise ValueError(
                f"Unsupported file format: {suffix}. "
                f"Supported formats: {', '.join(self.SUPPORTED_FORMATS)}"
            )

    def _load_csv(self, file_path: Path) -> pd.DataFrame:
        """Load CSV file."""
        df = pd.read_csv(file_path)
        return self._validate_dataframe(df)

    def _load_jsonl(self, file_path: Path) -> pd.DataFrame:
        """Load JSONL file."""
        records = []
        with open(file_path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    records.append(json.loads(line))
        df = pd.DataFrame(records)
        return self._validate_dataframe(df)

    def _load_json(self, file_path: Path) -> pd.DataFrame:
        """Load JSON file."""
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Handle both list of records and dict with records key
        if isinstance(data, list):
            df = pd.DataFrame(data)
        elif isinstance(data, dict) and "records" in data:
            df = pd.DataFrame(data["records"])
        else:
            raise ValueError("JSON must be a list of records or dict with 'records' key")

        return self._validate_dataframe(df)

    def _load_parquet(self, file_path: Path) -> pd.DataFrame:
        """Load Parquet file."""
        df = pd.read_parquet(file_path)
        return self._validate_dataframe(df)

    def _validate_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Validate and normalize DataFrame.

        Required columns: input, output
        Optional columns: expected

        Args:
            df: Input DataFrame

        Returns:
            Validated DataFrame

        Raises:
            ValueError: If required columns are missing
        """
        required_cols = ["input", "output"]
        missing_cols = [col for col in required_cols if col not in df.columns]

        if missing_cols:
            raise ValueError(
                f"Missing required columns: {', '.join(missing_cols)}. "
                f"Available columns: {', '.join(df.columns)}"
            )

        # Add expected column if missing
        if "expected" not in df.columns:
            df["expected"] = ""

        # Ensure all values are strings
        for col in ["input", "output", "expected"]:
            df[col] = df[col].fillna("").astype(str)

        return df
