"""AWS Bedrock client for LLM-as-judge evaluation."""

import json
from typing import Dict, Optional

import boto3
from botocore.exceptions import ClientError


class BedrockClient:
    """Client for AWS Bedrock API."""

    def __init__(self, model_id: str, aws_region: str = "us-east-1"):
        """
        Initialize Bedrock client.

        Args:
            model_id: Bedrock model ID (e.g., anthropic.claude-sonnet-4-20250514)
            aws_region: AWS region
        """
        self.model_id = model_id
        self.aws_region = aws_region
        self.client = boto3.client("bedrock-runtime", region_name=aws_region)

    def invoke(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 1024,
        temperature: float = 0.0,
        **kwargs,
    ) -> Dict:
        """
        Invoke Bedrock model.

        Args:
            prompt: User prompt
            system_prompt: System prompt (optional)
            max_tokens: Maximum tokens to generate
            temperature: Temperature for sampling
            **kwargs: Additional model parameters

        Returns:
            Response dict with 'content' and 'usage' keys

        Raises:
            ClientError: If API call fails
        """
        # Prepare messages
        messages = [{"role": "user", "content": prompt}]

        # Prepare request body for Claude
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": messages,
        }

        if system_prompt:
            body["system"] = system_prompt

        # Add any additional parameters
        body.update(kwargs)

        try:
            # Invoke model
            response = self.client.invoke_model(
                modelId=self.model_id,
                body=json.dumps(body),
            )

            # Parse response
            response_body = json.loads(response["body"].read())

            # Extract content
            content = response_body.get("content", [])
            if content and isinstance(content, list):
                text = content[0].get("text", "")
            else:
                text = ""

            return {
                "content": text,
                "usage": response_body.get("usage", {}),
                "stop_reason": response_body.get("stop_reason", ""),
            }

        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            error_message = e.response["Error"]["Message"]
            raise RuntimeError(
                f"Bedrock API error ({error_code}): {error_message}"
            ) from e

    def invoke_with_json_response(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs,
    ) -> Dict:
        """
        Invoke model and parse JSON response.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            **kwargs: Additional parameters

        Returns:
            Parsed JSON response

        Raises:
            ValueError: If response is not valid JSON
        """
        response = self.invoke(prompt, system_prompt, **kwargs)
        content = response["content"]

        try:
            # Try to parse as JSON
            return json.loads(content)
        except json.JSONDecodeError:
            # Try to extract JSON from markdown code blocks
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
                return json.loads(json_str)
            elif "```" in content:
                json_str = content.split("```")[1].split("```")[0].strip()
                return json.loads(json_str)
            else:
                raise ValueError(f"Could not parse JSON from response: {content}")
