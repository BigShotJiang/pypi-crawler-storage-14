"""Command-line interface for EvalMeter."""

import json
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from evalmeter import Evaluator
from evalmeter.core.evaluators import list_evaluators
from evalmeter.storage.database import Database
from evalmeter.utils.config import Config

console = Console()


@click.group()
@click.version_option(version="0.1.0")
def main():
    """EvalMeter - Measure AI Quality with Precision using AWS Bedrock."""
    pass


@main.command()
@click.option(
    "--data",
    "-d",
    required=True,
    type=click.Path(exists=True),
    help="Path to data file (CSV, JSONL, JSON, Parquet)",
)
@click.option(
    "--experiment",
    "-e",
    help="Experiment name (auto-generated if not provided)",
)
@click.option(
    "--project",
    "-p",
    help="Project ID to group related experiments",
)
@click.option(
    "--comments",
    "-c",
    help="Comments or notes about this experiment",
)
@click.option(
    "--model",
    "-m",
    help="Bedrock model ID (default: claude-sonnet-4-20250514)",
)
@click.option(
    "--evals",
    help="Comma-separated list of evaluators to run (default: accuracy)",
)
@click.option(
    "--region",
    default="us-east-1",
    help="AWS region (default: us-east-1)",
)
def run(data, experiment, project, comments, model, evals, region):
    """Run evaluation on a dataset."""
    console.print("\n[bold blue]📊 Starting EvalMeter...[/bold blue]\n")

    # Parse evaluators
    evaluator_list = None
    if evals:
        evaluator_list = [e.strip() for e in evals.split(",")]
        console.print(f"[green]Evaluators:[/green] {', '.join(evaluator_list)}")

    # Initialize evaluator
    config = Config()
    model_id = model or config.get_default_model()

    console.print(f"[green]Model:[/green] {model_id}")
    console.print(f"[green]Region:[/green] {region}")
    console.print(f"[green]Data:[/green] {data}")
    if project:
        console.print(f"[green]Project:[/green] {project}")
    if comments:
        console.print(f"[green]Comments:[/green] {comments}")
    console.print()

    try:
        evaluator = Evaluator(model_id=model_id, aws_region=region)

        # Run evaluation
        with console.status("[bold green]Running evaluation..."):
            results = evaluator.run(
                data_path=data,
                experiment_name=experiment,
                project_id=project,
                comments=comments,
                evaluators=evaluator_list,
            )

        # Display results
        console.print("\n[bold green]✓ Evaluation Complete![/bold green]\n")
        console.print(results.summary())

        console.print(f"[dim]Experiment ID: {results.experiment_id}[/dim]")
        if project:
            console.print(f"[dim]Project: {project}[/dim]")
        console.print(f"[dim]View details: evalmeter show {results.experiment_id}[/dim]\n")

    except Exception as e:
        console.print(f"\n[bold red]✗ Error:[/bold red] {str(e)}\n", style="red")
        sys.exit(1)


@main.command()
@click.option("--limit", "-n", default=10, help="Number of experiments to show")
def list(limit):
    """List recent experiments."""
    config = Config()
    db = Database(config.get_db_path())

    experiments = db.list_experiments(limit=limit)

    if not experiments:
        console.print("\n[yellow]No experiments found.[/yellow]\n")
        return

    # Create table
    table = Table(title=f"Recent Experiments (showing {len(experiments)})")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("Model", style="blue")
    table.add_column("Status", style="magenta")
    table.add_column("Created", style="dim")

    for exp in experiments:
        # Truncate ID for display
        short_id = exp.id[:8] if exp.id else "N/A"
        status_emoji = {
            "completed": "✓",
            "running": "⏳",
            "failed": "✗",
            "pending": "⏸",
        }.get(exp.status.value, "?")

        table.add_row(
            short_id,
            exp.name,
            exp.model_id.split(".")[-1] if exp.model_id else "N/A",
            f"{status_emoji} {exp.status.value}",
            str(exp.created_at)[:19] if exp.created_at else "N/A",
        )

    console.print("\n")
    console.print(table)
    console.print("\n[dim]Use 'evalmeter show <id>' to view details[/dim]\n")


@main.command()
@click.argument("experiment_id")
@click.option("--json", "output_json", is_flag=True, help="Output as JSON")
def show(experiment_id, output_json):
    """Show experiment details."""
    config = Config()
    db = Database(config.get_db_path())

    # Get experiment
    experiment = db.get_experiment(experiment_id)
    if not experiment:
        console.print(f"\n[red]Experiment not found: {experiment_id}[/red]\n")
        sys.exit(1)

    # Get metrics
    metrics = db.get_metrics(experiment_id)
    results = db.get_results(experiment_id)

    if output_json:
        # Output as JSON
        data = {
            "experiment": {
                "id": experiment.id,
                "name": experiment.name,
                "model_id": experiment.model_id,
                "status": experiment.status.value,
                "created_at": str(experiment.created_at),
            },
            "metrics": metrics,
            "results_count": len(results),
        }
        console.print(json.dumps(data, indent=2))
    else:
        # Display formatted output
        console.print(f"\n[bold]Experiment: {experiment.name}[/bold]")
        console.print(f"[dim]ID: {experiment.id}[/dim]")
        console.print(f"Model: {experiment.model_id}")
        console.print(f"Status: {experiment.status.value}")
        console.print(f"Dataset: {experiment.dataset_path}")
        console.print(f"Created: {experiment.created_at}")
        console.print(f"\n[bold]Metrics:[/bold]")

        for metric in metrics:
            console.print(f"  {metric['metric_name']}: {metric['metric_value']:.4f}")

        console.print(f"\n[dim]Total results: {len(results)}[/dim]\n")


@main.command()
def ui():
    """Launch the web UI."""
    console.print("\n[bold blue]📊 Launching EvalMeter UI...[/bold blue]\n")

    try:
        import subprocess

        # Get the path to the Streamlit app
        from evalmeter.ui import app

        app_path = Path(app.__file__)

        # Launch Streamlit
        subprocess.run(["streamlit", "run", str(app_path)])

    except ImportError:
        console.print(
            "[red]Streamlit not installed. Install with: pip install streamlit[/red]\n"
        )
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Error launching UI: {str(e)}[/red]\n")
        sys.exit(1)


@main.command()
def evaluators():
    """List available evaluators."""
    evals = list_evaluators()

    console.print("\n[bold]Available Evaluators:[/bold]\n")

    # Group by type
    heuristic = [e for e in evals if e in ["exact_match", "fuzzy_match", "contains", "regex_match"]]
    statistical = [e for e in evals if e in ["bleu", "rouge", "levenshtein", "cosine_similarity"]]
    llm_judge = [e for e in evals if e in ["factuality", "relevance", "coherence", "completeness"]]

    console.print("[bold cyan]Heuristic:[/bold cyan]")
    for e in heuristic:
        console.print(f"  • {e}")

    console.print("\n[bold cyan]Statistical:[/bold cyan]")
    for e in statistical:
        console.print(f"  • {e}")

    console.print("\n[bold cyan]LLM-as-Judge:[/bold cyan]")
    for e in llm_judge:
        console.print(f"  • {e}")

    console.print(
        "\n[dim]Use with: evalmeter run --data data.csv --evals factuality,bleu[/dim]\n"
    )


if __name__ == "__main__":
    main()
