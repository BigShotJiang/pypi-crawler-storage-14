# Project Tracking Guide

## Overview

Projects in EvalMeter help you organize related experiments and track progress over time. This is essential for:
- Comparing different approaches
- Visualizing improvements
- Understanding what changes led to better results
- Documenting your experimentation journey

---

## Creating Projects

Projects are created automatically when you use the `--project` flag:

```bash
evalmeter run --data test.csv \
  --project "my-project" \
  --experiment "experiment-1" \
  --evals "factuality,relevance"
```

---

## Project Workflow Example

### Scenario: Improving a Q&A Chatbot

#### Step 1: Baseline
```bash
evalmeter run --data qa_test.csv \
  --project "chatbot-v2" \
  --experiment "baseline" \
  --comments "Initial baseline with default GPT-4 prompts. No context, no RAG." \
  --evals "factuality,relevance,coherence,completeness"
```

**Note:** Always specify `--evals` to choose which metrics to run. Without it, only `exact_match` runs by default.

**Results:**
- factuality: 0.75
- relevance: 0.85
- coherence: 0.80
- completeness: 0.65

#### Step 2: Improved Prompts
```bash
evalmeter run --data qa_test.csv \
  --project "chatbot-v2" \
  --experiment "improved-prompts" \
  --comments "Updated system prompt with better instructions. Added examples of good answers. Specified answer format." \
  --evals "factuality,relevance,coherence,completeness"
```

**Results:**
- factuality: 0.82 ↑
- relevance: 0.90 ↑
- coherence: 0.88 ↑
- completeness: 0.72 ↑

#### Step 3: Add RAG
```bash
evalmeter run --data qa_test.csv \
  --project "chatbot-v2" \
  --experiment "with-rag" \
  --comments "Added RAG with Pinecone vector DB. Top-3 retrieval. Embeddings from text-embedding-ada-002." \
  --evals "factuality,relevance,coherence,completeness"
```

**Results:**
- factuality: 0.91 ↑
- relevance: 0.95 ↑
- coherence: 0.85 ↓
- completeness: 0.88 ↑

#### Step 4: Fine-tune RAG
```bash
evalmeter run --data qa_test.csv \
  --project "chatbot-v2" \
  --experiment "rag-optimized" \
  --comments "Increased retrieval to top-5. Added re-ranking. Improved prompt to better integrate context." \
  --evals "factuality,relevance,coherence,completeness"
```

**Results:**
- factuality: 0.93 ↑
- relevance: 0.96 ↑
- coherence: 0.92 ↑
- completeness: 0.90 ↑

---

## Viewing Projects in the UI

### 1. Navigate to Projects Page
Click **Projects** in the sidebar to see all your projects.

### 2. Select a Project
Click on **chatbot-v2** to see:
- List of all experiments in chronological order
- Progress chart showing metrics over time
- Summary statistics

### 3. Progress Chart
The chart shows:
- X-axis: Experiments in chronological order
- Y-axis: Metric scores (0.0 - 1.0)
- Multiple lines: One for each metric
- Hover: See exact values

**Example visualization:**
```
1.0 ┤                                    ●─ relevance
    │                              ●───●
0.9 ┤                        ●───●         ●─ factuality
    │                  ●───●
0.8 ┤            ●───●                     ●─ coherence
    │      ●───●
0.7 ┤●───●                                 ●─ completeness
    │
0.6 ┤
    └─────────────────────────────────────
      baseline  improved  with-rag  optimized
```

### 4. Experiment Details
Click any experiment to see:
- Full metrics breakdown
- Sample-level results
- Comments explaining changes
- Configuration used

---

## Best Practices

### 1. Use Descriptive Project Names
```bash
# Good
--project "customer-support-bot-v3"
--project "summarization-model-2024"

# Not ideal
--project "test"
--project "project1"
```

### 2. Use Descriptive Experiment Names
```bash
# Good
--experiment "baseline-gpt4"
--experiment "with-rag-pinecone"
--experiment "fine-tuned-on-domain-data"

# Not ideal
--experiment "test1"
--experiment "exp2"
```

### 3. Always Add Comments
```bash
# Good
--comments "Baseline with GPT-4, temperature 0.7, no system prompt"
--comments "Added RAG with top-3 retrieval from Pinecone. Using ada-002 embeddings."
--comments "Increased temperature to 0.9 for more creative responses. Added few-shot examples."

# Not ideal
--comments "test"
--comments "trying something"
```

### 4. Document What Changed
Include in comments:
- **What** changed (e.g., "Added RAG", "Changed temperature")
- **Why** you made the change (e.g., "to improve factuality", "to reduce hallucinations")
- **Observations** (e.g., "coherence decreased slightly", "much slower inference")

### 5. Run Same Evaluators
For meaningful comparisons, use the same evaluators across experiments:

```bash
# Define evaluators once
EVALS="factuality,relevance,coherence,completeness"

# Use consistently
evalmeter run --data test.csv --project "my-project" --experiment "exp1" --evals "$EVALS"
evalmeter run --data test.csv --project "my-project" --experiment "exp2" --evals "$EVALS"
evalmeter run --data test.csv --project "my-project" --experiment "exp3" --evals "$EVALS"
```

### 6. Use Same Test Data
Keep your test dataset consistent to ensure fair comparisons:

```bash
# Always use the same test file
TEST_DATA="test_data_v1.csv"

evalmeter run --data "$TEST_DATA" --project "my-project" --experiment "exp1"
evalmeter run --data "$TEST_DATA" --project "my-project" --experiment "exp2"
```

---

## Advanced: Comparing Across Projects

You can also compare experiments from different projects:

```bash
# Project A: GPT-4 based
evalmeter run --data test.csv \
  --project "gpt4-chatbot" \
  --experiment "baseline"

# Project B: Claude based
evalmeter run --data test.csv \
  --project "claude-chatbot" \
  --experiment "baseline"
```

Then in the UI:
1. Go to **Compare** page
2. Select experiments from different projects
3. View side-by-side comparison

---

## CLI Commands for Projects

### List all projects
```bash
# Not directly available, but you can see projects in:
evalmeter list
```

### List experiments in a project
```bash
# Filter by project name when viewing in UI
# Or use database queries (advanced)
```

### View project progress
```bash
# Best viewed in the UI
# Navigate to Projects → [project-name]
```

---

## Example: A/B Testing

Compare two different approaches:

```bash
# Approach A: GPT-4 with RAG
evalmeter run --data test.csv \
  --project "ab-test-2024" \
  --experiment "approach-a-gpt4-rag" \
  --comments "GPT-4 with Pinecone RAG, top-3 retrieval" \
  --evals "factuality,relevance,coherence"

# Approach B: Claude with fine-tuning
evalmeter run --data test.csv \
  --project "ab-test-2024" \
  --experiment "approach-b-claude-finetuned" \
  --comments "Claude Sonnet 3.5 fine-tuned on 1000 examples" \
  --evals "factuality,relevance,coherence"
```

View in UI to see which approach performs better!

---

## Tips for Long-term Tracking

### 1. Version Your Test Data
```bash
# Include version in filename
test_data_v1.csv
test_data_v2.csv

# Or in comments
--comments "Using test_data_v1.csv (100 samples, balanced difficulty)"
```

### 2. Track Model Versions
```bash
--comments "GPT-4-turbo-2024-04-09, temperature 0.7"
--comments "Claude Sonnet 3.5 (20240620), temperature 0.5"
```

### 3. Document Infrastructure Changes
```bash
--comments "Switched from OpenAI to Bedrock. Same model (GPT-4), different API."
--comments "Upgraded Pinecone from p1 to p2 pods. Faster retrieval."
```

### 4. Regular Checkpoints
```bash
# Weekly checkpoints
evalmeter run --data test.csv \
  --project "production-monitoring" \
  --experiment "checkpoint-2024-11-26" \
  --comments "Weekly production quality check"
```

---

## Summary

Projects in EvalMeter help you:
- ✅ Organize related experiments
- ✅ Track progress over time
- ✅ Visualize improvements
- ✅ Document changes
- ✅ Make data-driven decisions

**Start using projects today to level up your AI evaluation workflow!**
