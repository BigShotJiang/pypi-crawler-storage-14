# EvalMeter Evaluators Guide

Complete reference for all 12 evaluators in EvalMeter.

## Overview

EvalMeter provides 12 evaluators across 3 categories:
- **5 Heuristic** - Fast, rule-based matching
- **4 Statistical** - Mathematical text similarity
- **4 LLM-as-Judge** - AI-powered evaluation

---

## Heuristic Evaluators

### 1. exact_match

**Binary exact string matching**

```python
evaluator = get_evaluator("exact_match", case_sensitive=False)
result = evaluator.evaluate(
    input_text="What is 2+2?",
    output_text="4",
    expected_text="4"
)
# score: 1.0 (match) or 0.0 (no match)
```

**Use Cases:**
- Classification tasks
- Short answers
- Multiple choice questions

---

### 2. fuzzy_match

**Similarity ratio using SequenceMatcher**

```python
evaluator = get_evaluator("fuzzy_match", threshold=0.8)
result = evaluator.evaluate(
    input_text="Spell 'receive'",
    output_text="recieve",  # typo
    expected_text="receive"
)
# score: 0.93 (high similarity despite typo)
```

**Use Cases:**
- Typo tolerance
- Spelling variations
- Approximate matching

---

### 3. contains

**Substring matching**

```python
evaluator = get_evaluator("contains", case_sensitive=False)
result = evaluator.evaluate(
    input_text="What is the capital of France?",
    output_text="The capital of France is Paris, a beautiful city",
    expected_text="Paris"
)
# score: 1.0 (contains) or 0.0 (doesn't contain)
```

**Use Cases:**
- Long-form answers
- Key phrase detection
- Flexible matching

---

### 4. regex_match

**Regular expression pattern matching**

```python
evaluator = get_evaluator("regex_match", pattern=r'\d{4}-\d{2}-\d{2}')
result = evaluator.evaluate(
    input_text="What's today's date?",
    output_text="Today is 2025-11-26",
    expected_text=""
)
# score: 1.0 (matches pattern) or 0.0 (doesn't match)
```

**Use Cases:**
- Format validation (emails, dates, phone numbers)
- Pattern detection
- Structured data extraction

---

## Statistical Evaluators

### 5. bleu

**N-gram precision for text similarity**

```python
evaluator = get_evaluator("bleu")
result = evaluator.evaluate(
    input_text="Translate: Hello",
    output_text="Bonjour",
    expected_text="Bonjour"
)
# score: 0.0-1.0 (higher = better overlap)
```

**Use Cases:**
- Translation quality
- Text generation
- Paraphrasing

**Metadata:**
- `bleu_score`: Overall BLEU score
- `reference_length`: Reference text length
- `hypothesis_length`: Output text length

---

### 6. rouge

**Recall-oriented matching for summarization**

```python
evaluator = get_evaluator("rouge")
result = evaluator.evaluate(
    input_text="Summarize this article",
    output_text="AI is transforming industries",
    expected_text="Artificial intelligence is revolutionizing various sectors"
)
# score: 0.0-1.0 (ROUGE-L F1 score)
```

**Use Cases:**
- Summarization quality
- Content overlap
- Information retrieval

**Metadata:**
- `rouge-1_precision`, `rouge-1_recall`, `rouge-1_fmeasure`
- `rouge-2_precision`, `rouge-2_recall`, `rouge-2_fmeasure`
- `rouge-l_precision`, `rouge-l_recall`, `rouge-l_fmeasure`

---

### 7. levenshtein

**Edit distance similarity**

```python
evaluator = get_evaluator("levenshtein")
result = evaluator.evaluate(
    input_text="Spell 'kitten'",
    output_text="sitting",
    expected_text="kitten"
)
# score: 0.0-1.0 (1.0 = identical, 0.0 = completely different)
```

**Use Cases:**
- Text similarity
- Typo detection
- String comparison

**Metadata:**
- `edit_distance`: Number of edits needed
- `similarity`: Normalized similarity score
- `output_length`, `expected_length`

---

### 8. cosine_similarity

**Semantic similarity using embeddings**

```python
evaluator = get_evaluator("cosine_similarity")
result = evaluator.evaluate(
    input_text="What is AI?",
    output_text="AI is computer intelligence",
    expected_text="Artificial Intelligence is machine learning"
)
# score: 0.0-1.0 (semantic similarity)
```

**Use Cases:**
- Semantic similarity
- Meaning comparison
- Paraphrase detection
- Cross-language similarity

**Metadata:**
- `cosine_similarity`: Similarity score
- `embedding_model`: Model used (Titan Embeddings V2)
- `embedding_dimensions`: Vector dimensions (1024)

**Note:** Uses AWS Bedrock Titan Embeddings V2. See [AWS Bedrock Pricing](https://aws.amazon.com/bedrock/pricing/) for costs.

---

## LLM-as-Judge Evaluators

### 9. factuality

**Factual correctness evaluation**

```python
evaluator = get_evaluator("factuality")
result = evaluator.evaluate(
    input_text="What is the capital of France?",
    output_text="Paris",
    expected_text="Paris"
)
# score: 0.0-1.0 (1.0 = factually correct)
```

**Use Cases:**
- Fact checking
- Accuracy verification
- Knowledge validation

**Metadata:**
- `reasoning`: Explanation of score
- `issues`: List of factual errors
- `raw_response`: Full LLM response

---

### 10. relevance

**Answer relevance to question**

```python
evaluator = get_evaluator("relevance")
result = evaluator.evaluate(
    input_text="What is photosynthesis?",
    output_text="Photosynthesis is how plants make food using sunlight",
    expected_text="Photosynthesis is the process where plants convert light energy"
)
# score: 0.0-1.0 (1.0 = highly relevant)
```

**Use Cases:**
- Relevance checking
- Answer quality
- Topic adherence

**Metadata:**
- `reasoning`: Explanation of relevance
- `raw_response`: Full LLM response

---

### 11. coherence

**Response structure and clarity**

```python
evaluator = get_evaluator("coherence")
result = evaluator.evaluate(
    input_text="Explain how a car works",
    output_text="A car has an engine. The engine burns fuel. This creates power. Power moves the wheels.",
    expected_text="A car works by burning fuel in an engine to create power that moves the wheels"
)
# score: 0.0-1.0 (1.0 = highly coherent)
```

**Use Cases:**
- Quality assessment
- Readability checking
- Structure evaluation

**Metadata:**
- `reasoning`: Explanation of coherence
- `raw_response`: Full LLM response

---

### 12. completeness

**Answer coverage and thoroughness**

```python
evaluator = get_evaluator("completeness")
result = evaluator.evaluate(
    input_text="Explain photosynthesis including inputs and outputs",
    output_text="Plants use sunlight to make food",
    expected_text="Plants use sunlight, water, and CO2 to produce glucose and oxygen"
)
# score: 0.4 (incomplete - missing details)
```

**Use Cases:**
- Coverage verification
- Thoroughness checking
- Missing information detection

**Metadata:**
- `reasoning`: Explanation of completeness
- `missing_points`: List of missing information
- `raw_response`: Full LLM response

---

## Choosing Evaluators

### For Classification
```bash
--evals "exact_match"
```

### For Text Generation
```bash
--evals "bleu,rouge,cosine_similarity"
```

### For Question Answering
```bash
--evals "cosine_similarity,factuality,relevance,completeness"
```

### For Summarization
```bash
--evals "rouge,cosine_similarity,coherence"
```

### Comprehensive Evaluation
```bash
--evals "exact_match,bleu,rouge,levenshtein,cosine_similarity,factuality,relevance,coherence,completeness"
```

---

## Cost & Performance

| Evaluator | Cost | Speed | Semantic Understanding |
|-----------|------|-------|----------------------|
| Heuristic (5) | Free | ⚡⚡⚡ | ❌ |
| Statistical (3) | Free | ⚡⚡⚡ | ❌ |
| Cosine Similarity | AWS Bedrock (Titan) | ⚡⚡ | ✅ |
| LLM-as-Judge (4) | AWS Bedrock (Claude) | ⚡ | ✅✅ |

**Pricing**: Refer to [AWS Bedrock Pricing](https://aws.amazon.com/bedrock/pricing/) for current rates on Titan Embeddings and Claude models.

---

## Best Practices

1. **Start with free metrics** - Use heuristic and statistical evaluators first
2. **Add semantic understanding** - Use cosine_similarity for meaning comparison
3. **Validate with LLM judges** - Use for final quality assessment
4. **Combine multiple evaluators** - Get comprehensive view of quality
5. **Track over time** - Use project tracking to monitor improvements

---

## Examples

See `examples/` directory for:
- Basic evaluation examples
- Custom evaluator implementations
- Batch processing scripts
- Project tracking workflows
