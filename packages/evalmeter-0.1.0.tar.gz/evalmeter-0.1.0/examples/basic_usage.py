"""Basic usage example for EvalMeter."""

from evalmeter import Evaluator

# Initialize evaluator
evaluator = Evaluator(
    model_id="anthropic.claude-sonnet-4-20250514",
    aws_region="us-east-1",
)

# Run evaluation
results = evaluator.run(
    data_path="sample_data.csv",
    experiment_name="basic-example",
    evaluators=["accuracy", "bleu", "factuality"],
)

# Print summary
print(results.summary())

# Access individual results
print("\nFirst 3 results:")
for i, result in enumerate(results):
    if i >= 3:
        break
    print(f"\nResult {i+1}:")
    print(f"  Input: {result['input']}")
    print(f"  Output: {result['output']}")
    print(f"  Scores: {result['scores']}")
