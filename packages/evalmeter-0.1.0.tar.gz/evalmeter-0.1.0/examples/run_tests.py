"""
Test script for EvalMeter - Run various evaluation scenarios
"""

from evalmeter import Evaluator
import os

def test_basic_evaluation():
    """Test basic evaluation with simple Q&A"""
    print("\n" + "="*60)
    print("TEST 1: Basic Evaluation (Exact Match)")
    print("="*60)
    
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    results = evaluator.run(
        data_path="test_data_basic.csv",
        experiment_name="test-basic-exact-match",
        evaluators=["accuracy", "fuzzy_match"]
    )
    
    print(results.summary())
    return results


def test_statistical_evaluation():
    """Test statistical evaluators (BLEU, ROUGE)"""
    print("\n" + "="*60)
    print("TEST 2: Statistical Evaluation (BLEU, ROUGE)")
    print("="*60)
    
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    results = evaluator.run(
        data_path="test_data_qa.csv",
        experiment_name="test-statistical-qa",
        evaluators=["bleu", "rouge", "levenshtein"]
    )
    
    print(results.summary())
    return results


def test_llm_judge_evaluation():
    """Test LLM-as-judge evaluators"""
    print("\n" + "="*60)
    print("TEST 3: LLM-as-Judge Evaluation (Factuality, Relevance)")
    print("="*60)
    print("⚠️  This test will make API calls to AWS Bedrock")
    print("    Make sure you have AWS credentials configured")
    
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    results = evaluator.run(
        data_path="test_data_qa.csv",
        experiment_name="test-llm-judge-qa",
        evaluators=["factuality", "relevance", "coherence"]
    )
    
    print(results.summary())
    return results


def test_mixed_quality():
    """Test with mixed quality responses"""
    print("\n" + "="*60)
    print("TEST 4: Mixed Quality Responses")
    print("="*60)
    
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    results = evaluator.run(
        data_path="test_data_mixed_quality.csv",
        experiment_name="test-mixed-quality",
        evaluators=["accuracy", "fuzzy_match", "levenshtein"]
    )
    
    print(results.summary())
    
    # Show some individual results
    print("\n📊 Sample Results:")
    for i, result in enumerate(results):
        if i >= 3:
            break
        print(f"\n  Result {i+1}:")
        print(f"    Input: {result['input'][:50]}...")
        print(f"    Output: {result['output'][:50]}...")
        print(f"    Expected: {result['expected'][:50]}...")
        print(f"    Scores: {result['scores']}")
    
    return results


def test_jsonl_format():
    """Test JSONL data format"""
    print("\n" + "="*60)
    print("TEST 5: JSONL Format")
    print("="*60)
    
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    results = evaluator.run(
        data_path="test_data.jsonl",
        experiment_name="test-jsonl-format",
        evaluators=["accuracy", "bleu"]
    )
    
    print(results.summary())
    return results


def test_json_format():
    """Test JSON data format"""
    print("\n" + "="*60)
    print("TEST 6: JSON Format")
    print("="*60)
    
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    results = evaluator.run(
        data_path="test_data.json",
        experiment_name="test-json-format",
        evaluators=["accuracy", "rouge"]
    )
    
    print(results.summary())
    return results


def main():
    """Run all tests"""
    print("\n" + "🚀"*30)
    print("EvalMeter Test Suite")
    print("🚀"*30)
    
    # Change to examples directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    try:
        # Test 1: Basic evaluation (no API calls)
        test_basic_evaluation()
        
        # Test 2: Statistical evaluation (no API calls)
        test_statistical_evaluation()
        
        # Test 4: Mixed quality (no API calls)
        test_mixed_quality()
        
        # Test 5: JSONL format (no API calls)
        test_jsonl_format()
        
        # Test 6: JSON format (no API calls)
        test_json_format()
        
        # Test 3: LLM-as-judge (requires API calls - run last)
        print("\n" + "⚠️ "*30)
        print("The next test will make API calls to AWS Bedrock")
        print("This will incur costs. Press Ctrl+C to skip.")
        print("⚠️ "*30)
        
        response = input("\nContinue with LLM-as-judge test? (y/n): ")
        if response.lower() == 'y':
            test_llm_judge_evaluation()
        else:
            print("\n⏭️  Skipping LLM-as-judge test")
        
        print("\n" + "✅"*30)
        print("All tests completed!")
        print("✅"*30)
        
        print("\n📊 View results:")
        print("  - Run: evalmeter list")
        print("  - Launch UI: evalmeter ui")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Tests interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Error: {str(e)}")
        print("\nMake sure:")
        print("  1. AWS credentials are configured")
        print("  2. Bedrock model access is enabled")
        print("  3. You're in the examples directory")


if __name__ == "__main__":
    main()
