#!/usr/bin/env python3
"""
Quick test script for EvalMeter - No AWS required!
Tests heuristic and statistical evaluators only.
"""

from evalmeter import Evaluator
import os

def main():
    print("\n" + "📊"*30)
    print("EvalMeter Quick Test (No AWS Required)")
    print("📊"*30)
    
    # Change to examples directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    print("\n✅ Testing heuristic and statistical evaluators...")
    print("   (No API calls will be made)\n")
    
    # Initialize evaluator
    evaluator = Evaluator(
        model_id="anthropic.claude-sonnet-4-20250514",
        aws_region="us-east-1"
    )
    
    # Test 1: Basic exact match
    print("="*60)
    print("Test 1: Basic Exact Match (10 samples)")
    print("="*60)
    
    results1 = evaluator.run(
        data_path="test_data_basic.csv",
        experiment_name="quick-test-exact-match",
        evaluators=["accuracy", "fuzzy_match"]
    )
    
    print(results1.summary())
    
    # Test 2: Statistical evaluation
    print("\n" + "="*60)
    print("Test 2: Statistical Evaluation (5 samples)")
    print("="*60)
    
    results2 = evaluator.run(
        data_path="test_data_qa.csv",
        experiment_name="quick-test-statistical",
        evaluators=["bleu", "rouge", "levenshtein"]
    )
    
    print(results2.summary())
    
    # Show sample results
    print("\n" + "="*60)
    print("Sample Results from Test 2")
    print("="*60)
    
    for i, result in enumerate(results2):
        if i >= 2:  # Show first 2 results
            break
        print(f"\n📝 Result {i+1}:")
        print(f"   Input: {result['input'][:60]}...")
        print(f"   Output: {result['output'][:60]}...")
        print(f"   Expected: {result['expected'][:60]}...")
        print(f"   Scores:")
        for metric, score in result['scores'].items():
            if isinstance(score, (int, float)):
                print(f"     - {metric}: {score:.3f}")
    
    # Summary
    print("\n" + "✅"*30)
    print("Quick Test Complete!")
    print("✅"*30)
    
    print("\n📊 What was tested:")
    print("   ✓ Exact match evaluator")
    print("   ✓ Fuzzy match evaluator")
    print("   ✓ BLEU score")
    print("   ✓ ROUGE score")
    print("   ✓ Levenshtein distance")
    
    print("\n📈 View your results:")
    print("   - List experiments: evalmeter list")
    print("   - Show details: evalmeter show <experiment-id>")
    print("   - Launch UI: evalmeter ui")
    
    print("\n💡 Next steps:")
    print("   - Try LLM-as-judge: python run_tests.py")
    print("   - Create your own data: edit test_data_basic.csv")
    print("   - Read the docs: cat README.md")
    
    print("\n🎉 EvalMeter is working correctly!\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print("\nTroubleshooting:")
        print("  1. Make sure you're in the examples directory")
        print("  2. Install EvalMeter: pip install -e ../")
        print("  3. Check that sample data files exist")
        exit(1)
