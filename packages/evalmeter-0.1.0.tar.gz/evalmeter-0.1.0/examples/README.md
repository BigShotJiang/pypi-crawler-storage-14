# EvalMeter Examples

This directory contains sample data and test scripts to help you get started with EvalMeter.

## 📁 Sample Data Files

### 1. `test_data_basic.csv` (10 samples)
Simple Q&A pairs with exact matches. Perfect for testing:
- Exact match evaluator
- Fuzzy match evaluator
- Basic accuracy metrics

**Use case**: Testing basic functionality without API calls

### 2. `test_data_qa.csv` (5 samples)
Longer explanatory answers. Good for testing:
- BLEU score
- ROUGE score
- Levenshtein distance
- LLM-as-judge evaluators

**Use case**: Testing statistical and semantic similarity

### 3. `test_data_mixed_quality.csv` (15 samples)
Mix of correct, partially correct, and incorrect answers. Tests:
- Score distribution
- Different quality levels
- Edge cases

**Use case**: Realistic evaluation scenarios

### 4. `test_data_code.csv` (5 samples)
Code snippets and programming questions. Tests:
- Code similarity
- Functional equivalence

**Use case**: Evaluating code generation

### 5. `test_data.jsonl` (5 samples)
JSONL format with AI/ML questions.

**Use case**: Testing JSONL data loading

### 6. `test_data.json` (5 samples)
JSON format with tech questions.

**Use case**: Testing JSON data loading

## 🚀 Quick Start

### Option 1: CLI (Recommended for beginners)

```bash
# Navigate to examples directory
cd evalmeter/examples

# Test with basic data (no API calls)
evalmeter run --data test_data_basic.csv --experiment "my-first-test"

# Test with statistical evaluators
evalmeter run --data test_data_qa.csv --evals bleu,rouge,levenshtein

# Test with LLM-as-judge (requires AWS Bedrock)
evalmeter run --data test_data_qa.csv --evals factuality,relevance

# View results
evalmeter list
evalmeter ui
```

### Option 2: Python Script

```bash
# Run the comprehensive test suite
cd evalmeter/examples
python run_tests.py
```

### Option 3: Python API

```bash
# Run the basic usage example
cd evalmeter/examples
python basic_usage.py
```

## 📊 Test Scenarios

### Scenario 1: Quick Test (No API Calls)
```bash
evalmeter run --data test_data_basic.csv --evals accuracy,fuzzy_match
```
- **Time**: ~1 second
- **Cost**: $0 (no API calls)
- **Tests**: Heuristic evaluators only

### Scenario 2: Statistical Analysis (No API Calls)
```bash
evalmeter run --data test_data_qa.csv --evals bleu,rouge,levenshtein
```
- **Time**: ~2-3 seconds
- **Cost**: $0 (no API calls)
- **Tests**: Statistical similarity metrics

### Scenario 3: LLM-as-Judge (Requires AWS)
```bash
evalmeter run --data test_data_qa.csv --evals factuality,relevance,coherence
```
- **Time**: ~30-60 seconds (5 samples × 3 evaluators)
- **Cost**: ~$0.01-0.05 (depends on response length)
- **Tests**: Claude-based evaluation

### Scenario 4: Comprehensive (All Evaluators)
```bash
evalmeter run --data test_data_mixed_quality.csv \
  --evals accuracy,fuzzy_match,bleu,rouge,factuality
```
- **Time**: ~2-3 minutes (15 samples × 5 evaluators)
- **Cost**: ~$0.05-0.15
- **Tests**: All evaluation methods

## 🎓 Understanding the Results

### Accuracy Score
- **1.0**: Perfect match
- **0.0**: No match
- **Use**: Exact string comparison

### BLEU Score
- **1.0**: Perfect similarity
- **0.5-0.8**: Good similarity
- **<0.5**: Low similarity
- **Use**: Text similarity (common in translation)

### ROUGE Score
- **1.0**: Perfect overlap
- **0.7-0.9**: High overlap
- **<0.5**: Low overlap
- **Use**: Summarization quality

### Levenshtein Similarity
- **1.0**: Identical strings
- **0.8-0.9**: Very similar
- **<0.7**: Different strings
- **Use**: Edit distance

### Factuality (LLM-as-Judge)
- **1.0**: Completely accurate
- **0.7-0.9**: Mostly accurate
- **0.4-0.6**: Partially accurate
- **<0.4**: Inaccurate
- **Use**: Fact checking

## 💡 Tips

### 1. Start Small
Begin with `test_data_basic.csv` (10 samples) to verify setup.

### 2. Test Without API Calls First
Use heuristic and statistical evaluators before LLM-as-judge:
```bash
evalmeter run --data test_data_basic.csv --evals accuracy,bleu
```

### 3. Monitor Costs
LLM-as-judge evaluators make API calls. Start with small datasets:
- 5 samples × 1 evaluator ≈ $0.01
- 10 samples × 3 evaluators ≈ $0.05
- 100 samples × 3 evaluators ≈ $0.50

### 4. Use the UI
The Streamlit UI makes it easy to explore results:
```bash
evalmeter ui
```

### 5. Compare Experiments
Run multiple experiments with different evaluators and compare:
```bash
evalmeter run --data test_data_qa.csv --evals bleu --experiment "test-bleu"
evalmeter run --data test_data_qa.csv --evals rouge --experiment "test-rouge"
evalmeter ui  # Compare in UI
```

## 🔧 Troubleshooting

### "No module named 'evalmeter'"
```bash
cd evalmeter
pip install -e .
```

### "Access Denied" (AWS Bedrock)
1. Check AWS credentials: `aws sts get-caller-identity`
2. Enable Bedrock model access in AWS Console
3. Verify IAM permissions

### "File not found"
Make sure you're in the examples directory:
```bash
cd evalmeter/examples
```

## 📚 Next Steps

1. **Modify sample data**: Edit CSV files to test your own use cases
2. **Create custom evaluators**: See `../evalmeter/core/evaluators/`
3. **Integrate into your workflow**: Use the Python API in your code
4. **Scale up**: Test with larger datasets
5. **Share results**: Export from UI or use `evalmeter show <id> --json`

## 🎯 Example Workflows

### Workflow 1: Evaluate a Chatbot
```bash
# Create your data
cat > my_chatbot_data.csv << EOF
input,output,expected
"Hello","Hi there!","Hi! How can I help?"
"What's your name?","I'm an AI assistant","I'm an AI assistant"
EOF

# Run evaluation
evalmeter run --data my_chatbot_data.csv \
  --evals accuracy,relevance,coherence \
  --experiment "chatbot-v1"

# View results
evalmeter ui
```

### Workflow 2: Compare Model Versions
```bash
# Evaluate model v1
evalmeter run --data test_data_qa.csv \
  --evals factuality,bleu \
  --experiment "model-v1"

# Evaluate model v2 (with different outputs)
evalmeter run --data test_data_qa_v2.csv \
  --evals factuality,bleu \
  --experiment "model-v2"

# Compare in UI
evalmeter ui  # Use "Compare" tab
```

### Workflow 3: Continuous Evaluation
```python
# In your CI/CD pipeline
from evalmeter import Evaluator

evaluator = Evaluator()
results = evaluator.run(
    data_path="test_suite.csv",
    experiment_name=f"ci-{build_number}",
    evaluators=["accuracy", "factuality"]
)

# Fail if score below threshold
if results.metrics["factuality_mean"] < 0.8:
    raise Exception("Quality threshold not met!")
```

## 📞 Need Help?

- Check the main [README](../README.md)
- Read the [SETUP guide](../SETUP.md)
- Open an issue on GitHub
- Review the [Architecture docs](../ARCHITECTURE.md)

Happy evaluating! 📊
