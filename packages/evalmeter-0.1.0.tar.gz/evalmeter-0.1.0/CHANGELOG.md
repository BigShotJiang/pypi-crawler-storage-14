# Changelog

All notable changes to EvalMeter will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2025-11-26

### Added
- Initial release of EvalMeter
- 12 evaluation metrics across 3 categories:
  - Heuristic: exact_match, fuzzy_match, contains, regex_match, accuracy
  - Statistical: bleu, rouge, levenshtein, cosine_similarity
  - LLM-as-Judge: factuality, relevance, coherence, completeness
- CLI interface for running evaluations
- Python API for programmatic access
- SQLite database for experiment tracking
- Project tracking and grouping
- Experiment comments and documentation
- Modern React + Vite web UI
- FastAPI REST API backend
- AWS Bedrock integration with Claude Sonnet 4.5
- Titan Embeddings V2 for cosine similarity
- Support for CSV, JSONL, JSON, and Parquet data formats
- Progress visualization and comparison features
- Comprehensive documentation and examples

### Features
- One-line CLI commands
- Flexible evaluator selection
- Local data storage
- Real-time progress tracking
- Experiment comparison
- Rich metrics and metadata
- Cross-region inference profile support

[0.1.0]: https://github.com/RamprasathS/evalmeter/releases/tag/v0.1.0
