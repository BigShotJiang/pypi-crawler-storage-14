# Contributing to EvalMeter

Thank you for your interest in contributing to EvalMeter! This document provides guidelines and instructions for contributing.

## 🤝 How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear description of the problem
- Steps to reproduce
- Expected vs actual behavior
- Environment details (Python version, OS, AWS region)
- Error messages or logs

### Suggesting Features

Feature requests are welcome! Please:
- Check existing issues first
- Describe the feature and use case
- Explain why it would be useful
- Provide examples if possible

### Pull Requests

1. **Fork the repository**
   ```bash
   git clone https://github.com/RamprasathS/evalmeter.git
   cd evalmeter
   ```

2. **Create a branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Write clean, readable code
   - Follow existing code style
   - Add tests for new features
   - Update documentation

4. **Test your changes**
   ```bash
   # Install dev dependencies
   pip install -e ".[dev]"
   
   # Run tests
   pytest
   
   # Check code style
   black evalmeter/
   ruff check evalmeter/
   ```

5. **Commit and push**
   ```bash
   git add .
   git commit -m "Add: your feature description"
   git push origin feature/your-feature-name
   ```

6. **Create Pull Request**
   - Go to GitHub and create a PR
   - Describe your changes
   - Link related issues
   - Wait for review

## 📝 Code Style

- Follow PEP 8
- Use type hints
- Write docstrings for functions and classes
- Keep functions focused and small
- Use meaningful variable names

### Example

```python
def evaluate_text(
    input_text: str,
    output_text: str,
    expected_text: str = "",
    **kwargs,
) -> EvaluationResult:
    """
    Evaluate text output against expected text.
    
    Args:
        input_text: Input prompt or question
        output_text: Model output to evaluate
        expected_text: Expected or reference output
        **kwargs: Additional evaluation parameters
        
    Returns:
        EvaluationResult with score and metadata
    """
    # Implementation
    pass
```

## 🧪 Testing

- Write tests for new features
- Ensure existing tests pass
- Aim for high code coverage
- Test edge cases

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=evalmeter

# Run specific test
pytest tests/test_evaluators.py
```

## 📚 Documentation

- Update README.md for user-facing changes
- Add docstrings to new functions/classes
- Update CHANGELOG.md
- Add examples if applicable

## 🎯 Adding New Evaluators

To add a new evaluator:

1. **Create evaluator class**
   ```python
   # evalmeter/core/evaluators/your_evaluator.py
   from evalmeter.core.evaluators.base import EvaluatorBase, EvaluationResult
   
   class YourEvaluator(EvaluatorBase):
       def __init__(self, **kwargs):
           super().__init__(name="your_evaluator", **kwargs)
       
       def evaluate(self, input_text, output_text, expected_text, **kwargs):
           # Your logic here
           score = calculate_score(output_text, expected_text)
           
           return EvaluationResult(
               score=score,
               metadata={"your_metric": score}
           )
   ```

2. **Register evaluator**
   ```python
   # evalmeter/core/evaluators/__init__.py
   from evalmeter.core.evaluators.your_evaluator import YourEvaluator
   
   EVALUATOR_REGISTRY = {
       # ... existing evaluators
       "your_evaluator": YourEvaluator,
   }
   ```

3. **Add to CLI display**
   ```python
   # evalmeter/cli.py
   # Add to appropriate category in evaluators() function
   ```

4. **Write tests**
   ```python
   # tests/test_your_evaluator.py
   def test_your_evaluator():
       evaluator = YourEvaluator()
       result = evaluator.evaluate(
           input_text="test",
           output_text="output",
           expected_text="expected"
       )
       assert 0 <= result.score <= 1
   ```

5. **Update documentation**
   - Add to README.md evaluators table
   - Add examples
   - Update CHANGELOG.md

## 🔄 Development Workflow

1. **Setup development environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # or `venv\Scripts\activate` on Windows
   pip install -e ".[dev]"
   ```

2. **Make changes**
   - Write code
   - Add tests
   - Update docs

3. **Test locally**
   ```bash
   pytest
   black evalmeter/
   ruff check evalmeter/
   ```

4. **Submit PR**
   - Push to your fork
   - Create pull request
   - Respond to feedback

## 📋 Commit Message Guidelines

Use clear, descriptive commit messages:

- `Add: new feature description`
- `Fix: bug description`
- `Update: what was updated`
- `Refactor: what was refactored`
- `Docs: documentation changes`
- `Test: test additions or changes`

## 🐛 Debugging

- Use `print()` or `logging` for debugging
- Test with small datasets first
- Check AWS credentials and permissions
- Verify Bedrock model access

## 📞 Getting Help

- Open an issue for questions
- Join discussions on GitHub
- Check existing issues and PRs

## 🎉 Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Mentioned in release notes
- Credited in documentation

Thank you for contributing to EvalMeter! 🙏
