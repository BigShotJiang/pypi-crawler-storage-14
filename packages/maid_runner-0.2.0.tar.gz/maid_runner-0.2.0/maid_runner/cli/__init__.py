"""MAID Runner CLI package."""
