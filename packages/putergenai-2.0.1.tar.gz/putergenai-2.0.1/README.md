# PuterGenAI

[![PyPI version](https://badge.fury.io/py/putergenai.svg)](https://pypi.org/project/putergenai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An asynchronous Python client for the Puter.com API, enabling easy integration with AI chat models.

## Features

- Asynchronous API client for Puter.com
- Support for multiple AI models (GPT, Claude, etc.)
- Streaming and non-streaming responses
- Simple authentication via username/password
- Configurable options: temperature, model selection, etc.

## Installation

Install from PyPI:

```bash
pip install putergenai
```

Or install from source:

```bash
git clone https://github.com/Nerve11/putergenai.git
cd putergenai
pip install -e .
```

## Quick Start

```python
import asyncio
from putergenai import PuterClient

async def main():
    async with PuterClient() as client:
        await client.login('your_username', 'your_password')

        messages = [
            {'role': 'user', 'content': 'Hello!'}
        ]

        # Non-streaming response
        result = await client.ai_chat(messages=messages)
        print(result)

        # Streaming response
        async for content, model in await client.ai_chat(messages=messages, options={'stream': True}):
            print(content, end='')

asyncio.run(main())
```

## Detailed Example

See [examples/example.py](examples/example.py) for a complete interactive example with model selection, streaming options, and error handling.

## Configuration Options

When calling `ai_chat`, you can pass options:

- `model`: Specify the AI model (e.g., 'gpt-5', 'claude-4', etc.)
- `stream`: Enable/disable streaming (boolean)
- `temperature`: Adjust creativity/randomness (0.0-2.0)

## Requirements

- Python >= 3.11
- Dependencies: aiohttp, aiofiles, certifi, pillow, customtkinter, cryptography, flask, keyring

## Development

To set up for development:

```bash
pip install -e .[dev]
```

Run tests:

```bash
pytest
```

Lint code:

```bash
black src/
flake8 src/
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Issues

Report bugs or request features at: https://github.com/Nerve11/putergenai/issues
