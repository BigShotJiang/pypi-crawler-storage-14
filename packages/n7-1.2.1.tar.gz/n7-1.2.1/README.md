# cli-nseven
nseven global cli

## Install in os pypi test

(pix requirement)
```bash
# install global machine
pipx install --index-url https://test.pypi.org/simple/ --pip-args="--extra-index-url https://pypi.org/simple/" n7
```

## Install in os pypi prod
```bash
# to later
```

## Dev Install

- Terminal command to execute in the cloned project
```bash
python3.13 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

- Install the project (bin) in dev mode for development usage
```bash
# equivalent to npm link
pip install -e .
```

## Test use

- Run tests with pytest
```bash
pytest
# verbose
pytest -v 
```

## Tools

- Run formatter
```bash
black .
```

- Run Linter
```bash
ruff check
```

- Run type checking on code
```bash
mypy .
```

- Execute one for that
  (if n7 install mode dev in project)
```bash
n7 py-lint
or
n7 py-lint --fix
```