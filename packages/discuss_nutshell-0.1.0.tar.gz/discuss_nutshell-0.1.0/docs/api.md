# ::: discuss_nutshell
