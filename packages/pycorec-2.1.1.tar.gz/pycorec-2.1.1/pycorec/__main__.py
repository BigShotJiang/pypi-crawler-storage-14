# pycorec/__main__.py

from .pycorec import main as _main


def main() -> None:
    _main()


if __name__ == "__main__":
    main()
