"""Runtime utilities for containerized module execution."""

