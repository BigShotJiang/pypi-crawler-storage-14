"""
Class containing error conditions that are exposed to the user.
"""

from samcli.commands.exceptions import UserException


class InvokeContextException(UserException):
    """
    Something went wrong invoking the function.
    """


class InvalidSamTemplateException(UserException):
    """
    The template provided was invalid and not able to transform into a Standard CloudFormation Template
    """


class SamTemplateNotFoundException(UserException):
    """
    The SAM Template provided could not be found
    """


class DebugContextException(UserException):
    """
    Something went wrong when creating the DebugContext
    """


class ImageBuildException(UserException):
    """
    Image failed to build
    """


class CredentialsRequired(UserException):
    """
    Credentials were not given when Required
    """


class ResourceNotFound(UserException):
    """
    The Resource requested was not found
    """


class InvalidLayerVersionArn(UserException):
    """
    The LayerVersion Arn given in the template is Invalid
    """


class UnsupportedIntrinsic(UserException):
    """
    Value from a template has an Intrinsic that is unsupported
    """


class NotAvailableInRegion(UserException):
    """
    Calling service not available (launched) in specified region
    """


class InvalidFunctionPropertyType(UserException):
    """
    Function property given in the template is Invalid
    """


class DockerDistributionAPIError(UserException):
    """
    There was an unknown error from the docker daemon.

    This could be either an error from the Docker client (SAM) to the daemon's internal
    API or it could be an error from the Docker registry.
    """


class SchemaPermissionsError(UserException):
    """
    You don't have the neccesary permissions to create shareable test events.

    Update your role to have the necessary permissions or change your event sharing settings to private.

    Learn more: https://docs.aws.amazon.com/lambda/latest/dg/testing-functions.html#creating-shareable-events
    """
