"""Test suite initialization for eval package."""

# This file makes the tests directory a Python package
