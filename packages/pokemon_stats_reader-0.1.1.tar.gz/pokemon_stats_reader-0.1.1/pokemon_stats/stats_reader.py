"""
Módulo para leer estadísticas de Pokémon desde archivos CSV
"""
import pandas as pd
from typing import List, Optional
from functools import lru_cache
import os


class PokemonStatsReader:
    """
    Clase para leer y consultar estadísticas de Pokémon desde CSV
    Implementa caching para optimizar lecturas repetidas
    """
    
    def __init__(self, csv_path: str = "estadisticas_grupos.csv"):
        """
        Inicializa el lector de estadísticas
        
        Args:
            csv_path: Ruta al archivo CSV con estadísticas
        """
        self.csv_path = csv_path
        self._df: Optional[pd.DataFrame] = None
        self._load_data()
    
    def _load_data(self):
        """Carga los datos del CSV (con caché)"""
        if not os.path.exists(self.csv_path):
            raise FileNotFoundError(
                f"No se encontró el archivo CSV: {self.csv_path}\n"
                "Asegúrate de ejecutar main.py primero para generar el archivo."
            )
        
        self._df = pd.read_csv(self.csv_path)
        print(f"✓ Datos cargados desde {self.csv_path}")
    
    @property
    @lru_cache(maxsize=1)
    def df(self) -> pd.DataFrame:
        """Propiedad con cache para acceder al DataFrame"""
        return self._df
    
    def get_grupos_pokemon(self) -> List[str]:
        """
        Obtiene la lista de todos los grupos de Pokémon
        
        Returns:
            Lista con nombres de grupos
            
        Example:
            >>> reader = PokemonStatsReader()
            >>> grupos = reader.get_grupos_pokemon()
            >>> print(grupos)
            ['monster', 'water1', 'bug', ...]
        """
        if self._df is None:
            self._load_data()
        
        return self._df['grupo'].tolist()
    
    def get_altura_media_grupo(self, grupo: str) -> Optional[float]:
        """
        Obtiene la altura media de un grupo específico
        
        Args:
            grupo: Nombre del grupo de Pokémon
            
        Returns:
            Altura media del grupo o None si no existe
            
        Example:
            >>> reader = PokemonStatsReader()
            >>> altura = reader.get_altura_media_grupo('monster')
            >>> print(f"Altura media: {altura}")
            Altura media: 12.5
        """
        if self._df is None:
            self._load_data()
        
        result = self._df[self._df['grupo'] == grupo]
        
        if result.empty:
            print(f"Advertencia: No se encontró el grupo '{grupo}'")
            return None
        
        return float(result['altura_media'].iloc[0])
    
    def get_peso_medio_grupo(self, grupo: str) -> Optional[float]:
        """
        Obtiene el peso medio de un grupo específico
        
        Args:
            grupo: Nombre del grupo de Pokémon
            
        Returns:
            Peso medio del grupo o None si no existe
            
        Example:
            >>> reader = PokemonStatsReader()
            >>> peso = reader.get_peso_medio_grupo('monster')
            >>> print(f"Peso medio: {peso}")
            Peso medio: 850.3
        """
        if self._df is None:
            self._load_data()
        
        result = self._df[self._df['grupo'] == grupo]
        
        if result.empty:
            print(f"Advertencia: No se encontró el grupo '{grupo}'")
            return None
        
        return float(result['peso_medio'].iloc[0])
    
    def get_all_stats(self) -> pd.DataFrame:
        """
        Obtiene todas las estadísticas como DataFrame
        
        Returns:
            DataFrame con todas las estadísticas
        """
        if self._df is None:
            self._load_data()
        
        return self._df.copy()
    
    def get_grupo_stats(self, grupo: str) -> Optional[dict]:
        """
        Obtiene todas las estadísticas de un grupo específico
        
        Args:
            grupo: Nombre del grupo
            
        Returns:
            Diccionario con todas las estadísticas del grupo
        """
        if self._df is None:
            self._load_data()
        
        result = self._df[self._df['grupo'] == grupo]
        
        if result.empty:
            return None
        
        return result.iloc[0].to_dict()
