"""
Paquete pokemon_stats - Lee estadísticas de Pokémon desde CSV

Este paquete proporciona métodos para consultar estadísticas de grupos de Pokémon.
"""
__version__ = "0.1.0"
__author__ = "Tu Nombre"
__license__ = "MIT"

from .stats_reader import PokemonStatsReader

__all__ = ['PokemonStatsReader']
