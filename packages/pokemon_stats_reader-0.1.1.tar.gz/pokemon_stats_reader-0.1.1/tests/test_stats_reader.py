"""
Tests unitarios para el módulo pokemon_stats

Ejecutar con: pytest tests/
"""
import pytest
import pandas as pd
import os
import sys

# Agregar el directorio padre al path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from pokemon_stats.stats_reader import PokemonStatsReader


@pytest.fixture
def sample_csv(tmp_path):
    """Fixture que crea un CSV de prueba"""
    csv_file = tmp_path / "test_estadisticas.csv"
    data = {
        'grupo': ['monster', 'water1', 'bug'],
        'cantidad_pokemon': [45, 38, 28],
        'altura_media': [12.5, 9.2, 6.8],
        'peso_medio': [850.3, 425.7, 145.2]
    }
    df = pd.DataFrame(data)
    df.to_csv(csv_file, index=False)
    return str(csv_file)


@pytest.fixture
def reader(sample_csv):
    """Fixture que crea un PokemonStatsReader con datos de prueba"""
    return PokemonStatsReader(sample_csv)


class TestPokemonStatsReader:
    """Suite de tests para PokemonStatsReader"""
    
    def test_init_with_valid_file(self, sample_csv):
        """Test: Inicialización con archivo válido"""
        reader = PokemonStatsReader(sample_csv)
        assert reader is not None
        assert reader._df is not None
    
    def test_init_with_invalid_file(self):
        """Test: Inicialización con archivo inexistente"""
        with pytest.raises(FileNotFoundError):
            PokemonStatsReader("archivo_inexistente.csv")
    
    def test_get_grupos_pokemon(self, reader):
        """Test: Obtener lista de grupos"""
        grupos = reader.get_grupos_pokemon()
        assert isinstance(grupos, list)
        assert len(grupos) == 3
        assert 'monster' in grupos
        assert 'water1' in grupos
        assert 'bug' in grupos
    
    def test_get_grupos_pokemon_order(self, reader):
        """Test: Orden de grupos"""
        grupos = reader.get_grupos_pokemon()
        assert grupos == ['monster', 'water1', 'bug']
    
    def test_get_altura_media_grupo_existing(self, reader):
        """Test: Obtener altura media de grupo existente"""
        altura = reader.get_altura_media_grupo('monster')
        assert altura is not None
        assert isinstance(altura, float)
        assert altura == 12.5
    
    def test_get_altura_media_grupo_nonexistent(self, reader):
        """Test: Obtener altura media de grupo inexistente"""
        altura = reader.get_altura_media_grupo('dragon')
        assert altura is None
    
    def test_get_peso_medio_grupo_existing(self, reader):
        """Test: Obtener peso medio de grupo existente"""
        peso = reader.get_peso_medio_grupo('water1')
        assert peso is not None
        assert isinstance(peso, float)
        assert peso == 425.7
    
    def test_get_peso_medio_grupo_nonexistent(self, reader):
        """Test: Obtener peso medio de grupo inexistente"""
        peso = reader.get_peso_medio_grupo('fairy')
        assert peso is None
    
    def test_get_all_stats(self, reader):
        """Test: Obtener todas las estadísticas"""
        df = reader.get_all_stats()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 3
        assert list(df.columns) == ['grupo', 'cantidad_pokemon', 'altura_media', 'peso_medio']
    
    def test_get_grupo_stats_existing(self, reader):
        """Test: Obtener estadísticas de grupo existente"""
        stats = reader.get_grupo_stats('bug')
        assert stats is not None
        assert isinstance(stats, dict)
        assert stats['grupo'] == 'bug'
        assert stats['cantidad_pokemon'] == 28
        assert stats['altura_media'] == 6.8
        assert stats['peso_medio'] == 145.2
    
    def test_get_grupo_stats_nonexistent(self, reader):
        """Test: Obtener estadísticas de grupo inexistente"""
        stats = reader.get_grupo_stats('flying')
        assert stats is None
    
    def test_multiple_calls_same_result(self, reader):
        """Test: Múltiples llamadas devuelven el mismo resultado (cache)"""
        grupos1 = reader.get_grupos_pokemon()
        grupos2 = reader.get_grupos_pokemon()
        assert grupos1 == grupos2
    
    def test_altura_media_all_groups(self, reader):
        """Test: Verificar altura media para todos los grupos"""
        grupos = reader.get_grupos_pokemon()
        expected = {'monster': 12.5, 'water1': 9.2, 'bug': 6.8}
        
        for grupo in grupos:
            altura = reader.get_altura_media_grupo(grupo)
            assert altura == expected[grupo]
    
    def test_peso_medio_all_groups(self, reader):
        """Test: Verificar peso medio para todos los grupos"""
        grupos = reader.get_grupos_pokemon()
        expected = {'monster': 850.3, 'water1': 425.7, 'bug': 145.2}
        
        for grupo in grupos:
            peso = reader.get_peso_medio_grupo(grupo)
            assert peso == expected[grupo]


@pytest.mark.parametrize("grupo,expected_altura", [
    ('monster', 12.5),
    ('water1', 9.2),
    ('bug', 6.8),
])
def test_altura_parametrized(reader, grupo, expected_altura):
    """Test parametrizado para altura media"""
    altura = reader.get_altura_media_grupo(grupo)
    assert altura == expected_altura


@pytest.mark.parametrize("grupo,expected_peso", [
    ('monster', 850.3),
    ('water1', 425.7),
    ('bug', 145.2),
])
def test_peso_parametrized(reader, grupo, expected_peso):
    """Test parametrizado para peso medio"""
    peso = reader.get_peso_medio_grupo(grupo)
    assert peso == expected_peso


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
