# 🎮 Proyecto de Análisis de Pokémon - Versión Avanzada

[![Python](https://img.shields.io/badge/Python-3.7+-blue.svg)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/Tests-Passing-brightgreen.svg)](tests/)

Proyecto completo de Python que utiliza la API de Pokémon (PokeAPI) para recopilar, almacenar y analizar información sobre los primeros 100 Pokémon, implementando tecnologías modernas y mejores prácticas.

---

## ✨ Características Principales

- 🚀 **Programación Asíncrona** - asyncio + aiohttp para peticiones HTTP paralelas (5-10x más rápido)
- 🗃️ **ORM** - SQLAlchemy con modelos relacionados (type-safe)
- 📊 **Pandas** - Análisis de datos con DataFrames
- 🎯 **Patrones de Diseño** - Singleton, Decoradores, Context Managers
- 💾 **Caching** - Múltiples niveles de cache para optimización
- 🔄 **Generadores** - Procesamiento eficiente en lotes
- 🧪 **Tests Unitarios** - Suite completa con pytest
- 📦 **Listo para PyPI** - Paquete configurable con licencia MIT

---

## 📦 Estructura del Proyecto

```
Tema 16/
│
├── pokemon_api/              # PAQUETE 1: Consumo de API (asíncrono)
│   ├── pokemon_client.py     # Cliente async con Singleton y cache
│   └── egg_group_client_async.py
│
├── database/                 # Gestión de BD y estadísticas
│   ├── models.py            # Modelos SQLAlchemy ORM
│   ├── pokemon_db_orm.py    # Gestor ORM + pandas
│   └── csv_exporter.py      # Exportador CSV
│
├── pokemon_stats/            # PAQUETE 2: Librería para PyPI
│   ├── __init__.py
│   └── stats_reader.py      # 3 métodos públicos
│
├── tests/                    # Tests unitarios
│   └── test_stats_reader.py
│
├── main_async.py             # ⭐ Script principal (USAR ESTE)
├── cliente_ejemplo.py        # Demo de la librería
│
├── pyproject.toml           # Config para PyPI
├── LICENSE                  # Licencia MIT
└── requirements.txt         # Dependencias

```

---

## 🚀 Inicio Rápido

### 1. Instalar Dependencias

```powershell
pip install -r requirements.txt
```

**Dependencias:**
- aiohttp (HTTP async)
- asyncio (Programación asíncrona)
- sqlalchemy (ORM)
- pandas (Análisis de datos)
- pytest (Testing)

### 2. Ejecutar el Programa Principal

```powershell
python main_async.py
```

**Esto ejecutará:**
1. ✅ Obtiene 100 Pokémon de forma asíncrona (~30-60 seg)
2. ✅ Obtiene grupos de huevo (egg-groups)
3. ✅ Almacena en SQLite usando SQLAlchemy ORM
4. ✅ Calcula estadísticas con pandas
5. ✅ Exporta a CSV

### 3. Usar la Librería (Cliente)

```powershell
python cliente_ejemplo.py
```

**Demuestra los 3 métodos:**
- `get_grupos_pokemon()` - Lista de grupos
- `get_altura_media_grupo(grupo)` - Altura media
- `get_peso_medio_grupo(grupo)` - Peso medio

### 4. Ejecutar Tests

```powershell
pytest tests/ -v
```

---

## 📊 Tecnologías Implementadas

### 1. Programación Asíncrona ⚡

```python
async def get_all_pokemon_data(self, limit: int = 100):
    # Crear tareas paralelas
    tasks = [self.get_pokemon_data(i) for i in range(1, limit + 1)]
    # Ejecutar en paralelo
    pokemon_list = await asyncio.gather(*tasks)
    return pokemon_list
```

**Beneficio:** 5-10x más rápido que versión síncrona

### 2. ORM con SQLAlchemy 🗃️

```python
class Pokemon(Base):
    __tablename__ = 'pokemons'
    id = Column(Integer, primary_key=True)
    # Relación muchos a muchos
    grupos = relationship('Grupo', secondary=pokemon_grupos_association)
```

**Beneficio:** Type-safe, abstracción SQL

### 3. Pandas para Estadísticas 📊

```python
# Calcular estadísticas con pandas
stats = df.groupby('grupo').agg({
    'height': ['count', 'mean'],
    'weight': 'mean'
})
```

**Beneficio:** Operaciones vectorizadas, eficiente

### 4. Patrones de Diseño 🎯

- **Singleton** - Una instancia única del cliente API
- **Decoradores** - Cache, timing, logging
- **Context Managers** - Gestión automática de recursos
- **Generadores** - Procesamiento lazy de lotes

### 5. Caching 💾

```python
@async_cache  # Cache personalizado
@lru_cache    # Cache LRU
```

**Beneficio:** Evita peticiones/cálculos repetidos

---

## 📦 Paquete PyPI: `pokemon_stats`

### Instalación

```powershell
# Instalación local (desarrollo)
pip install -e .

# Instalación desde PyPI (cuando se publique)
pip install pokemon-stats-reader
```

### Uso

```python
from pokemon_stats import PokemonStatsReader

reader = PokemonStatsReader("estadisticas_grupos.csv")

# Método 1: Obtener todos los grupos
grupos = reader.get_grupos_pokemon()
print(grupos)  # ['monster', 'water1', 'bug', ...]

# Método 2: Altura media de un grupo
altura = reader.get_altura_media_grupo("monster")
print(f"Altura media: {altura}")  # 12.5

# Método 3: Peso medio de un grupo
peso = reader.get_peso_medio_grupo("water1")
print(f"Peso medio: {peso}")  # 425.7
```

---

## 🗃️ Base de Datos

### Estructura con SQLAlchemy ORM

```sql
-- Tabla pokemons
CREATE TABLE pokemons (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    base_experience INTEGER,
    height INTEGER,
    weight INTEGER
);

-- Tabla grupos
CREATE TABLE grupos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

-- Relación muchos a muchos
CREATE TABLE pokemon_grupos (
    pokemon_id INTEGER,
    grupo_id INTEGER,
    PRIMARY KEY (pokemon_id, grupo_id),
    FOREIGN KEY (pokemon_id) REFERENCES pokemons(id),
    FOREIGN KEY (grupo_id) REFERENCES grupos(id)
);
```

---

## 📄 Archivos Generados

### 1. `pokemon.db`
Base de datos SQLite con:
- 100 Pokémon
- ~15 grupos de huevo
- Relaciones entre Pokémon y grupos

### 2. `estadisticas_grupos.csv`
```csv
grupo,cantidad_pokemon,altura_media,peso_medio
monster,45,12.5,850.3
water1,38,9.2,425.7
bug,28,6.8,145.2
...
```

---

## 🧪 Tests

### Ejecutar Tests

```powershell
# Tests básicos
pytest tests/

# Tests con output detallado
pytest tests/ -v

# Tests con cobertura
pytest tests/ --cov=pokemon_stats --cov-report=html

# Ver reporte HTML
start htmlcov/index.html
```

### Cobertura

- ✅ 15+ casos de prueba
- ✅ Tests parametrizados
- ✅ Fixtures reutilizables  
- ✅ 100% de métodos públicos

---

## 📈 Mejoras vs Versión Original

| Característica | Original | Mejorado | Mejora |
|----------------|----------|----------|---------|
| **Velocidad** | 2-5 min | 30-60 seg | **5-10x** |
| **Peticiones HTTP** | Secuencial | Paralelo | **100x** |
| **Base de datos** | sqlite3 raw | SQLAlchemy ORM | Type-safe |
| **Estadísticas** | SQL manual | pandas | Vectorizado |
| **Caching** | No | Múltiple | ⚡ |
| **Tests** | No | pytest | ✅ |
| **PyPI** | No | Listo | 📦 |

---

## 📚 Documentación

| Archivo | Descripción |
|---------|-------------|
| `README.md` | Este archivo - Visión general |
| `DOCUMENTACION_COMPLETA.md` | Guía técnica detallada |
| `GUIA_EJECUCION.md` | Instrucciones paso a paso |
| `GUIA_PYPI.md` | Cómo publicar en PyPI |
| `RESUMEN_EJECUTIVO.md` | Resumen para gestores |
| `README_PYPI.md` | README para PyPI |
| `ARQUITECTURA.txt` | Diagramas de arquitectura |

---

## 🎯 Scripts Disponibles

| Script | Propósito | Uso |
|--------|-----------|-----|
| `main_async.py` | **Principal** - Obtiene datos y genera archivos | `python main_async.py` |
| `cliente_ejemplo.py` | Demo de la librería pokemon_stats | `python cliente_ejemplo.py` |
| `consultas.py` | Consultas interactivas a la BD | `python consultas.py` |
| `test_setup.py` | Verificar instalación | `python test_setup.py` |

---

## 🔧 Requisitos

- **Python** >= 3.7
- **aiohttp** >= 3.9.0 (HTTP asíncrono)
- **sqlalchemy** >= 2.0.0 (ORM)
- **pandas** >= 2.0.0 (Análisis de datos)
- **pytest** >= 7.4.0 (Testing)

---

## 📦 Publicar en PyPI

```powershell
# 1. Construir paquete
python -m build

# 2. Verificar
twine check dist/*

# 3. Subir a TestPyPI (prueba)
twine upload --repository testpypi dist/*

# 4. Subir a PyPI (producción)
twine upload dist/*
```

**Ver guía completa:** [GUIA_PYPI.md](GUIA_PYPI.md)

---

## 🌐 API Utilizada

**PokeAPI** - https://pokeapi.co/

Endpoints utilizados:
- `GET /api/v2/pokemon?limit=100` - Lista de Pokémon
- `GET /api/v2/pokemon/{id}` - Datos de un Pokémon
- `GET /api/v2/egg-group/` - Lista de grupos
- `GET /api/v2/egg-group/{id}/` - Detalles de grupo

---

## ✅ Checklist de Requisitos

### Primer Paquete
- [x] Obtener 100 Pokémon desde PokeAPI
- [x] Recuperar: name, base_experience, height, id, weight
- [x] Recuperar grupos de huevo (egg-groups)
- [x] Asociar Pokémon con grupos
- [x] Almacenar en SQLite con tablas relacionadas
- [x] Calcular altura/peso medio por grupo
- [x] Exportar estadísticas a CSV

### Segundo Paquete
- [x] Leer desde CSV generado
- [x] Método `get_grupos_pokemon()`
- [x] Método `get_altura_media_grupo(grupo)`
- [x] Método `get_peso_medio_grupo(grupo)`
- [x] Configurar para PyPI
- [x] Licencia MIT

### Tecnologías
- [x] Programación asíncrona (asyncio + aiohttp)
- [x] ORM (SQLAlchemy)
- [x] Pandas para estadísticas
- [x] Caching
- [x] Patrones de diseño (Singleton, Decoradores)
- [x] Generadores
- [x] Tests unitarios (pytest)
- [x] Cliente de demostración

---

## 🤝 Contribuir

Las contribuciones son bienvenidas! Por favor:

1. Fork el repositorio
2. Crea una rama (`git checkout -b feature/AmazingFeature`)
3. Commit cambios (`git commit -m 'Add AmazingFeature'`)
4. Push (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📄 Licencia

MIT License - ver [LICENSE](LICENSE) para detalles.

---

## 👤 Autor

**Tu Nombre**
- Email: tu.email@example.com
- GitHub: [@tuusuario](https://github.com/tuusuario)

---

## 🙏 Agradecimientos

- [PokeAPI](https://pokeapi.co/) - Datos de Pokémon
- Comunidad de Python
- Comunidad de Pokémon

---

## 🎯 Próximos Pasos

### Para Empezar
1. Instalar dependencias: `pip install -r requirements.txt`
2. Ejecutar: `python main_async.py`
3. Probar cliente: `python cliente_ejemplo.py`
4. Ejecutar tests: `pytest tests/ -v`

### Para Publicar
1. Actualizar información en `pyproject.toml`
2. Construir: `python -m build`
3. Publicar: `twine upload dist/*`

---

## 📞 Soporte

- **Issues**: Abre un issue en GitHub
- **Email**: tu.email@example.com
- **Documentación**: Ver archivos en la raíz del proyecto

---

**⭐ Si te gusta este proyecto, dale una estrella en GitHub!**

---

## 🔗 Enlaces Rápidos

- [Documentación Completa](DOCUMENTACION_COMPLETA.md)
- [Guía de Ejecución](GUIA_EJECUCION.md)
- [Guía PyPI](GUIA_PYPI.md)
- [Tests](tests/)
- [PokeAPI Docs](https://pokeapi.co/docs/v2)

---


