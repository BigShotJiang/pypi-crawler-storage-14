# TRTC Migration Assistant

![mcpServer](https://developer.qcloudimg.com/http-save/900000/f9ab7acfbfdd1a1dc398fe0c15a09932.svg)

TRTC Migration Assistant 是 [TRTC云助手](https://cloud.tencent.com/product/trtccopilot?Is=sdk-topnav) 团队为 [腾讯云TRTC](https://cloud.tencent.com/product/trtc?Is=sdk-topnav) 打造的快速迁移MCP工具，可以在AI的帮助下快速将集成其他RTC厂商的业务代码迁移到腾讯云TRTC。

## 1. 功能

在支持MCP的AI工具中，选择或复制集成其他RTC厂商的业务代码，然后使用如下提示词提问

```
"xxxxxx" 这是xx友商的代码，帮我迁移到TRTC
```

该工具会解析源代码中对其他RTC厂商的接口调用，并提供迁移到TRTC对应的接口，文档和迁移指引，AI会根据这些信息进行准确的迁移，写出迁移后的代码。

## 2. 准备事项

### 2.1 AI工具

准备一个支持MCP的AI工具，例如`CodeBuddy`, `Cursor`, `VSCode`等

### 2.2 访问密钥

该工具通过腾讯云的云API提供服务，云API通过签名机制保证数据传输的安全性，该方式需要您在腾讯云申请安全凭证，即`SecretID`和`SecretKey`。

同时为了最小化该安全凭证的权限，推荐您在[腾讯云控制台](https://console.cloud.tencent.com/cam/user/create?systemType=FastCreateV2)新建一个子用户，并只对该用户授予`QcloudTrtccopilotFullAccess`权限(该权限是用于访问`TRTC云助手`)，并在[密钥管理](https://console.cloud.tencent.com/cam/capi)处获取上述子用户的`SecretID`和`SecretKey`用于访问该服务。


## 3. 安装使用

安装该MCP有2种方式，分别是本地配置和使用托管的在线服务

### 3.1 本地配置

该方式需要您本地电脑有安装Python的包管理工具[uv](https://docs.astral.sh/uv/getting-started/installation/)

然后在AI工具的MCP页面做如下配置，在`TENCENTCLOUD_SECRET_ID`和`TENCENTCLOUD_SECRET_KEY`处填入第2步获取的安全凭证(对应`SecretID`和`SecretKey`)。

```json
{
  "mcpServers": {
    "trtc-migration-assistant": {
      "command": "uvx",
      "args": [
        "trtc-migration-assistant"
      ],
      "env": {
        "TENCENTCLOUD_SECRET_ID": "",
        "TENCENTCLOUD_SECRET_KEY": ""
      }
    }
  }
} 
```

### 3.2 使用托管服务

如果您不方便在自己的电脑上安装`uv`，本服务已在腾讯云开发者平台托管，您可以配置在线的连接

该方式需要您在[腾讯云开发者平台](https://cloud.tencent.com/developer/mcp)找到`trtc-migration-assistant`，在页面右侧`连接服务`的部分输入前面获取到的`SecretID`和`SecretKey`，点击`连接Server`获取对应的MCP Server配置，例如：

```json
{
  "mcpServers": {
    "trtc-migration-assistant": {
      "type": "sse",
      "url": "xxx"
    }
  }
}
```

注意上面的JSON仅为示例，需要您在腾讯云开发者平台获取自己的配置，然后将该配置设置到AI工具中即可