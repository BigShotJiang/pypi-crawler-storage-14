"""Tests for mcp-refactoring."""
