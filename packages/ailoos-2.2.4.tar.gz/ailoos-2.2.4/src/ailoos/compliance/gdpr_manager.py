"""
GDPRManager - Gestión completa de GDPR para AILOOS.

Implementa:
- Gestión de consentimientos
- Derecho al olvido (right to be forgotten)
- Exportación de datos
- Auditoría de procesamiento de datos
"""

import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from sqlalchemy.orm import Session

from ..utils.logging import get_logger

logger = get_logger(__name__)


@dataclass
class ConsentRecord:
    """Registro de consentimiento GDPR."""
    consent_id: str
    user_id: str
    purpose: str  # "marketing", "analytics", "necessary", etc.
    granted: bool
    granted_at: datetime
    expires_at: Optional[datetime] = None
    withdrawn_at: Optional[datetime] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DataProcessingRecord:
    """Registro de procesamiento de datos."""
    processing_id: str
    user_id: str
    purpose: str
    legal_basis: str  # "consent", "contract", "legitimate_interest", etc.
    data_categories: List[str]  # "personal", "financial", "health", etc.
    recipients: List[str]  # who receives the data
    retention_period: str  # "1year", "2years", etc.
    processed_at: datetime
    controller: str  # who is responsible
    metadata: Dict[str, Any] = field(default_factory=dict)


class GDPRManager:
    """
    Gestor completo de cumplimiento GDPR.

    Maneja consentimientos, derecho al olvido, exportación de datos
    y auditoría de procesamiento de datos personales.
    """

    def __init__(self, db_session: Optional[Session] = None):
        self.db_session = db_session
        self.consents: Dict[str, ConsentRecord] = {}
        self.processing_records: Dict[str, DataProcessingRecord] = {}
        self._initialized = False

    def initialize(self):
        """Inicializar el gestor GDPR."""
        if not self._initialized:
            # Cargar consentimientos desde base de datos si existe
            self._load_consents_from_db()
            self._load_processing_records_from_db()
            self._initialized = True
            logger.info("✅ GDPRManager inicializado")

    def _load_consents_from_db(self):
        """Cargar consentimientos desde base de datos."""
        # TODO: Implementar carga desde DB cuando se creen las tablas
        pass

    def _load_processing_records_from_db(self):
        """Cargar registros de procesamiento desde base de datos."""
        # TODO: Implementar carga desde DB
        pass

    def grant_consent(self, user_id: str, purpose: str, ip_address: Optional[str] = None,
                     user_agent: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Otorgar consentimiento para un propósito específico.

        Args:
            user_id: ID del usuario
            purpose: Propósito del consentimiento
            ip_address: Dirección IP del usuario
            user_agent: User agent del navegador
            metadata: Metadatos adicionales

        Returns:
            ID del consentimiento otorgado
        """
        consent_id = f"consent_{user_id}_{purpose}_{datetime.now().timestamp()}"

        consent = ConsentRecord(
            consent_id=consent_id,
            user_id=user_id,
            purpose=purpose,
            granted=True,
            granted_at=datetime.now(),
            expires_at=self._calculate_expiry(purpose),
            ip_address=ip_address,
            user_agent=user_agent,
            metadata=metadata or {}
        )

        self.consents[consent_id] = consent
        self._save_consent_to_db(consent)

        # Registrar procesamiento de datos
        self._record_data_processing(
            user_id=user_id,
            purpose=f"consent_granted_{purpose}",
            legal_basis="consent",
            data_categories=["consent_data"],
            recipients=["system"],
            retention_period="2years",
            controller="GDPRManager"
        )

        logger.info(f"✅ Consentimiento otorgado: {consent_id} para {user_id}")
        return consent_id

    def withdraw_consent(self, user_id: str, purpose: str) -> bool:
        """
        Retirar consentimiento para un propósito específico.

        Args:
            user_id: ID del usuario
            purpose: Propósito del consentimiento

        Returns:
            True si se retiró exitosamente
        """
        # Buscar consentimiento activo
        active_consent = None
        for consent in self.consents.values():
            if (consent.user_id == user_id and
                consent.purpose == purpose and
                consent.granted and
                consent.withdrawn_at is None):
                active_consent = consent
                break

        if not active_consent:
            logger.warning(f"No se encontró consentimiento activo para {user_id}:{purpose}")
            return False

        active_consent.withdrawn_at = datetime.now()
        self._update_consent_in_db(active_consent)

        # Registrar procesamiento
        self._record_data_processing(
            user_id=user_id,
            purpose=f"consent_withdrawn_{purpose}",
            legal_basis="consent",
            data_categories=["consent_data"],
            recipients=["system"],
            retention_period="2years",
            controller="GDPRManager"
        )

        logger.info(f"✅ Consentimiento retirado: {active_consent.consent_id}")
        return True

    def check_consent(self, user_id: str, purpose: str) -> bool:
        """
        Verificar si existe consentimiento válido para un propósito.

        Args:
            user_id: ID del usuario
            purpose: Propósito a verificar

        Returns:
            True si hay consentimiento válido
        """
        for consent in self.consents.values():
            if (consent.user_id == user_id and
                consent.purpose == purpose and
                consent.granted and
                consent.withdrawn_at is None):
                # Verificar expiración
                if consent.expires_at and datetime.now() > consent.expires_at:
                    continue
                return True
        return False

    def right_to_be_forgotten(self, user_id: str) -> Dict[str, Any]:
        """
        Implementar derecho al olvido (Right to be Forgotten).

        Args:
            user_id: ID del usuario a eliminar

        Returns:
            Resultado de la operación
        """
        deleted_data = {
            "consents_deleted": 0,
            "processing_records_deleted": 0,
            "user_data_deleted": False,
            "timestamp": datetime.now().isoformat()
        }

        # Eliminar consentimientos
        consents_to_delete = [cid for cid, c in self.consents.items() if c.user_id == user_id]
        for consent_id in consents_to_delete:
            del self.consents[consent_id]
            deleted_data["consents_deleted"] += 1

        # Eliminar registros de procesamiento
        records_to_delete = [rid for rid, r in self.processing_records.items() if r.user_id == user_id]
        for record_id in records_to_delete:
            del self.processing_records[record_id]
            deleted_data["processing_records_deleted"] += 1

        # TODO: Eliminar datos del usuario de otras tablas
        # Esto requeriría integración con otros servicios

        # Registrar la eliminación
        self._record_data_processing(
            user_id=user_id,
            purpose="right_to_be_forgotten",
            legal_basis="legal_obligation",
            data_categories=["all_personal_data"],
            recipients=["system"],
            retention_period="none",
            controller="GDPRManager"
        )

        logger.info(f"✅ Derecho al olvido aplicado para usuario {user_id}: {deleted_data}")
        return deleted_data

    def export_user_data(self, user_id: str, format: str = "json") -> Dict[str, Any]:
        """
        Exportar todos los datos personales del usuario.

        Args:
            user_id: ID del usuario
            format: Formato de exportación ("json", "xml", etc.)

        Returns:
            Datos exportados del usuario
        """
        export_data = {
            "user_id": user_id,
            "export_timestamp": datetime.now().isoformat(),
            "format": format,
            "consents": [],
            "processing_records": [],
            "user_profile": {},
            "metadata": {
                "gdpr_compliant": True,
                "export_purpose": "data_portability"
            }
        }

        # Agregar consentimientos
        for consent in self.consents.values():
            if consent.user_id == user_id:
                export_data["consents"].append({
                    "consent_id": consent.consent_id,
                    "purpose": consent.purpose,
                    "granted": consent.granted,
                    "granted_at": consent.granted_at.isoformat(),
                    "expires_at": consent.expires_at.isoformat() if consent.expires_at else None,
                    "withdrawn_at": consent.withdrawn_at.isoformat() if consent.withdrawn_at else None,
                    "metadata": consent.metadata
                })

        # Agregar registros de procesamiento
        for record in self.processing_records.values():
            if record.user_id == user_id:
                export_data["processing_records"].append({
                    "processing_id": record.processing_id,
                    "purpose": record.purpose,
                    "legal_basis": record.legal_basis,
                    "data_categories": record.data_categories,
                    "recipients": record.recipients,
                    "retention_period": record.retention_period,
                    "processed_at": record.processed_at.isoformat(),
                    "controller": record.controller,
                    "metadata": record.metadata
                })

        # TODO: Agregar datos de perfil de usuario desde otras tablas

        # Registrar la exportación
        self._record_data_processing(
            user_id=user_id,
            purpose="data_export",
            legal_basis="consent",
            data_categories=["exported_data"],
            recipients=["user"],
            retention_period="export_only",
            controller="GDPRManager"
        )

        logger.info(f"✅ Datos exportados para usuario {user_id}")
        return export_data

    def get_consent_history(self, user_id: str) -> List[Dict[str, Any]]:
        """
        Obtener historial de consentimientos del usuario.

        Args:
            user_id: ID del usuario

        Returns:
            Lista de consentimientos históricos
        """
        history = []
        for consent in self.consents.values():
            if consent.user_id == user_id:
                history.append({
                    "consent_id": consent.consent_id,
                    "purpose": consent.purpose,
                    "granted": consent.granted,
                    "granted_at": consent.granted_at.isoformat(),
                    "expires_at": consent.expires_at.isoformat() if consent.expires_at else None,
                    "withdrawn_at": consent.withdrawn_at.isoformat() if consent.withdrawn_at else None,
                    "status": self._get_consent_status(consent)
                })

        return sorted(history, key=lambda x: x["granted_at"], reverse=True)

    def audit_data_processing(self, user_id: Optional[str] = None,
                           purpose: Optional[str] = None,
                           date_from: Optional[datetime] = None,
                           date_to: Optional[datetime] = None) -> List[Dict[str, Any]]:
        """
        Auditar procesamiento de datos.

        Args:
            user_id: Filtrar por usuario (opcional)
            purpose: Filtrar por propósito (opcional)
            date_from: Fecha desde (opcional)
            date_to: Fecha hasta (opcional)

        Returns:
            Lista de registros de procesamiento
        """
        results = []

        for record in self.processing_records.values():
            # Aplicar filtros
            if user_id and record.user_id != user_id:
                continue
            if purpose and record.purpose != purpose:
                continue
            if date_from and record.processed_at < date_from:
                continue
            if date_to and record.processed_at > date_to:
                continue

            results.append({
                "processing_id": record.processing_id,
                "user_id": record.user_id,
                "purpose": record.purpose,
                "legal_basis": record.legal_basis,
                "data_categories": record.data_categories,
                "recipients": record.recipients,
                "retention_period": record.retention_period,
                "processed_at": record.processed_at.isoformat(),
                "controller": record.controller,
                "metadata": record.metadata
            })

        return sorted(results, key=lambda x: x["processed_at"], reverse=True)

    def _calculate_expiry(self, purpose: str) -> Optional[datetime]:
        """Calcular fecha de expiración del consentimiento."""
        expiry_rules = {
            "marketing": timedelta(days=365),
            "analytics": timedelta(days=365),
            "necessary": None,  # No expira
            "profiling": timedelta(days=180),
        }
        delta = expiry_rules.get(purpose)
        return datetime.now() + delta if delta else None

    def _get_consent_status(self, consent: ConsentRecord) -> str:
        """Obtener estado actual del consentimiento."""
        if consent.withdrawn_at:
            return "withdrawn"
        if consent.expires_at and datetime.now() > consent.expires_at:
            return "expired"
        if consent.granted:
            return "active"
        return "inactive"

    def _record_data_processing(self, user_id: str, purpose: str, legal_basis: str,
                              data_categories: List[str], recipients: List[str],
                              retention_period: str, controller: str,
                              metadata: Optional[Dict[str, Any]] = None):
        """Registrar procesamiento de datos."""
        processing_id = f"processing_{user_id}_{purpose}_{datetime.now().timestamp()}"

        record = DataProcessingRecord(
            processing_id=processing_id,
            user_id=user_id,
            purpose=purpose,
            legal_basis=legal_basis,
            data_categories=data_categories,
            recipients=recipients,
            retention_period=retention_period,
            processed_at=datetime.now(),
            controller=controller,
            metadata=metadata or {}
        )

        self.processing_records[processing_id] = record
        self._save_processing_record_to_db(record)

    def _save_consent_to_db(self, consent: ConsentRecord):
        """Guardar consentimiento en base de datos."""
        # TODO: Implementar persistencia en DB
        pass

    def _update_consent_in_db(self, consent: ConsentRecord):
        """Actualizar consentimiento en base de datos."""
        # TODO: Implementar actualización en DB
        pass

    def _save_processing_record_to_db(self, record: DataProcessingRecord):
        """Guardar registro de procesamiento en base de datos."""
        # TODO: Implementar persistencia en DB
        pass