import os
import json
import asyncio
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime

try:
    from ..blockchain.wallet_manager import get_wallet_manager, WalletManager
    from ..blockchain.staking_manager import get_staking_manager, StakingManager
    from ..marketplace import marketplace
except ImportError:
    # Fallback para desarrollo
    WalletManager = None
    StakingManager = None
    marketplace = None


class WalletMonitor:
    """Monitor de wallet real para el CLI de AILOOS."""

    def __init__(self, user_id: str = "default_user"):
        self.user_id = user_id
        self.wallet_manager = None
        self.staking_manager = None
        self._initialize_managers()

    def _initialize_managers(self):
        """Inicializar gestores de wallet y staking."""
        try:
            if WalletManager:
                self.wallet_manager = get_wallet_manager()
            if StakingManager:
                self.staking_manager = get_staking_manager()
        except Exception as e:
            print(f"Warning: Could not initialize wallet managers: {e}")

    async def get_wallet_balance(self) -> Dict[str, Any]:
        """Obtiene balance real de la wallet."""
        try:
            if not self.wallet_manager:
                return self._get_mock_balance()

            # Obtener wallets del usuario
            user_wallets = self.wallet_manager.get_user_wallets(self.user_id)
            if not user_wallets:
                # Crear wallet si no existe
                result = await self.wallet_manager.create_wallet(self.user_id, "cli")
                if result['success']:
                    wallet_id = result['wallet_id']
                    balance_info = await self.wallet_manager.get_wallet_balance(wallet_id)
                    return self._format_balance_info(balance_info)
                else:
                    return self._get_mock_balance()

            # Usar primera wallet
            wallet = user_wallets[0]
            balance_info = await self.wallet_manager.get_wallet_balance(wallet.wallet_id)
            return self._format_balance_info(balance_info)

        except Exception as e:
            print(f"Error getting wallet balance: {e}")
            return self._get_mock_balance()

    def _format_balance_info(self, balance_info: Dict[str, Any]) -> Dict[str, Any]:
        """Formatea información de balance."""
        if 'error' in balance_info:
            return self._get_mock_balance()

        return {
            'address': balance_info.get('address', 'unknown'),
            'balance': balance_info.get('total_balance', 0.0),
            'available': balance_info.get('available_balance', 0.0),
            'staked': balance_info.get('staked_amount', 0.0),
            'rewards': balance_info.get('rewards_earned', 0.0),
            'last_updated': balance_info.get('last_updated', datetime.now().isoformat())
        }

    def _get_mock_balance(self) -> Dict[str, Any]:
        """Balance simulado para desarrollo."""
        return {
            'address': f'0x{os.urandom(20).hex()}',
            'balance': 150.75,
            'available': 100.50,
            'staked': 50.25,
            'rewards': 12.34,
            'last_updated': datetime.now().isoformat()
        }

    async def get_staking_info(self) -> Dict[str, Any]:
        """Obtiene información de staking."""
        try:
            if not self.staking_manager:
                return self._get_mock_staking()

            # Obtener wallets del usuario
            user_wallets = self.wallet_manager.get_user_wallets(self.user_id) if self.wallet_manager else []
            if not user_wallets:
                return self._get_mock_staking()

            wallet_id = user_wallets[0].wallet_id
            staking_info = self.staking_manager.get_staking_info(wallet_id)

            return {
                'total_staked': staking_info.get('total_staked', 0.0),
                'apy': staking_info.get('apy', 15.5),
                'rewards_earned': staking_info.get('rewards_earned', 0.0),
                'positions': staking_info.get('positions', []),
                'voting_power': staking_info.get('voting_power', 0.0)
            }

        except Exception as e:
            print(f"Error getting staking info: {e}")
            return self._get_mock_staking()

    def _get_mock_staking(self) -> Dict[str, Any]:
        """Información de staking simulada."""
        return {
            'total_staked': 50.25,
            'apy': 15.5,
            'rewards_earned': 8.75,
            'positions': [
                {'amount': 25.0, 'apy': 15.5, 'lock_period': 30, 'start_date': '2024-01-01'},
                {'amount': 25.25, 'apy': 15.5, 'lock_period': 60, 'start_date': '2024-02-01'}
            ],
            'voting_power': 75.25
        }

    async def get_transaction_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Obtiene historial de transacciones."""
        try:
            if not self.wallet_manager:
                return self._get_mock_transactions(limit)

            user_wallets = self.wallet_manager.get_user_wallets(self.user_id)
            if not user_wallets:
                return self._get_mock_transactions(limit)

            wallet_id = user_wallets[0].wallet_id
            transactions = self.wallet_manager.get_transaction_history(wallet_id, limit)

            return [{
                'date': tx.get('timestamp', datetime.now().isoformat()),
                'type': tx.get('tx_type', 'unknown'),
                'amount': tx.get('amount', 0.0),
                'description': tx.get('description', ''),
                'status': tx.get('status', 'confirmed')
            } for tx in transactions]

        except Exception as e:
            print(f"Error getting transaction history: {e}")
            return self._get_mock_transactions(limit)

    def _get_mock_transactions(self, limit: int) -> List[Dict[str, Any]]:
        """Transacciones simuladas."""
        return [
            {
                'date': '2024-01-15T10:30:00Z',
                'type': 'reward',
                'amount': 5.0,
                'description': 'Training reward',
                'status': 'confirmed'
            },
            {
                'date': '2024-01-10T14:20:00Z',
                'type': 'stake',
                'amount': 25.0,
                'description': 'Token staking',
                'status': 'confirmed'
            }
        ][:limit]

    async def get_governance_info(self) -> Dict[str, Any]:
        """Obtiene información de gobernanza."""
        try:
            if not self.staking_manager:
                return self._get_mock_governance()

            # Obtener propuestas activas
            proposals = []
            if hasattr(self.staking_manager, 'governance_proposals'):
                proposals = list(self.staking_manager.governance_proposals.values())

            # Calcular poder de voto
            staking_info = await self.get_staking_info()
            voting_power = staking_info.get('voting_power', 0.0)

            return {
                'voting_power': voting_power,
                'active_proposals': len(proposals),
                'proposals': proposals[:5],  # Últimas 5
                'participation_rate': 0.0  # TODO: calcular
            }

        except Exception as e:
            print(f"Error getting governance info: {e}")
            return self._get_mock_governance()

    def _get_mock_governance(self) -> Dict[str, Any]:
        """Información de gobernanza simulada."""
        return {
            'voting_power': 75.25,
            'active_proposals': 3,
            'proposals': [
                {'id': 'PROP-001', 'title': 'Increase context window', 'status': 'voting'},
                {'id': 'PROP-002', 'title': 'Add medical training', 'status': 'draft'}
            ],
            'participation_rate': 0.0
        }

    async def get_all_wallet_info(self) -> Dict[str, Any]:
        """Obtiene toda la información de wallet."""
        balance = await self.get_wallet_balance()
        staking = await self.get_staking_info()
        governance = await self.get_governance_info()
        transactions = await self.get_transaction_history(5)

        return {
            'balance': balance,
            'staking': staking,
            'governance': governance,
            'recent_transactions': transactions,
            'last_updated': datetime.now().isoformat()
        }