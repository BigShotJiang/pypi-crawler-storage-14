"""
Rollback Manager for Blue-Green Deployments.

Manages automatic and manual rollbacks, maintains deployment history,
and ensures safe reversion to previous stable states.
"""

import logging
import time
import shutil
import os
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from enum import Enum


class RollbackStrategy(Enum):
    IMMEDIATE = "immediate"
    GRADUAL = "gradual"
    SAFE = "safe"


@dataclass
class DeploymentSnapshot:
    """
    Represents a snapshot of a deployment state.
    """
    timestamp: float
    environment: str
    version: str
    config: Dict[str, Any]
    health_status: Dict[str, Any]
    traffic_distribution: Dict[str, float]
    artifacts_path: Optional[str] = None


class RollbackManager:
    """
    Manages rollback operations for blue-green deployments.

    Maintains deployment history and provides safe rollback capabilities.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the Rollback Manager.

        Args:
            config: Configuration dictionary containing:
                - max_snapshots: Maximum number of snapshots to keep
                - rollback_strategy: Default rollback strategy
                - backup_path: Path for storing deployment backups
                - auto_rollback_threshold: Error threshold for auto-rollback
        """
        self.config = config
        self.logger = logging.getLogger(__name__)

        self.max_snapshots = config.get('max_snapshots', 10)
        self.rollback_strategy = RollbackStrategy(config.get('rollback_strategy', 'safe'))
        self.backup_path = config.get('backup_path', '/tmp/blue_green_backups')
        self.auto_rollback_threshold = config.get('auto_rollback_threshold', 50.0)

        # Deployment snapshots
        self.snapshots: List[DeploymentSnapshot] = []

        # Ensure backup directory exists
        os.makedirs(self.backup_path, exist_ok=True)

    def create_snapshot(self, environment: str, version: str, config: Dict[str, Any],
                       health_status: Dict[str, Any], traffic_distribution: Dict[str, float]) -> str:
        """
        Create a snapshot of the current deployment state.

        Args:
            environment: Environment being snapshotted
            version: Deployment version
            config: Deployment configuration
            health_status: Current health status
            traffic_distribution: Current traffic distribution

        Returns:
            str: Snapshot ID
        """
        timestamp = time.time()
        snapshot_id = f"{environment}_{version}_{int(timestamp)}"

        snapshot = DeploymentSnapshot(
            timestamp=timestamp,
            environment=environment,
            version=version,
            config=config.copy(),
            health_status=health_status.copy(),
            traffic_distribution=traffic_distribution.copy()
        )

        # Create backup of artifacts if configured
        if self.config.get('backup_artifacts', False):
            artifacts_path = self._backup_artifacts(environment, snapshot_id)
            snapshot.artifacts_path = artifacts_path

        self.snapshots.append(snapshot)

        # Maintain snapshot limit
        if len(self.snapshots) > self.max_snapshots:
            oldest = self.snapshots.pop(0)
            if oldest.artifacts_path and os.path.exists(oldest.artifacts_path):
                shutil.rmtree(oldest.artifacts_path)

        self.logger.info(f"Created snapshot {snapshot_id} for {environment}")
        return snapshot_id

    def rollback(self, target_snapshot: Optional[str] = None,
                strategy: Optional[RollbackStrategy] = None) -> bool:
        """
        Perform a rollback operation.

        Args:
            target_snapshot: Specific snapshot ID to rollback to (latest if None)
            strategy: Rollback strategy to use

        Returns:
            bool: True if rollback successful, False otherwise
        """
        if not self.snapshots:
            self.logger.error("No snapshots available for rollback")
            return False

        # Determine target snapshot
        if target_snapshot:
            snapshot = self._find_snapshot(target_snapshot)
            if not snapshot:
                self.logger.error(f"Snapshot {target_snapshot} not found")
                return False
        else:
            # Use latest snapshot
            snapshot = self.snapshots[-1]

        rollback_strategy = strategy or self.rollback_strategy
        self.logger.info(f"Starting rollback to snapshot {snapshot.version} using {rollback_strategy.value} strategy")

        try:
            if rollback_strategy == RollbackStrategy.IMMEDIATE:
                return self._immediate_rollback(snapshot)
            elif rollback_strategy == RollbackStrategy.GRADUAL:
                return self._gradual_rollback(snapshot)
            elif rollback_strategy == RollbackStrategy.SAFE:
                return self._safe_rollback(snapshot)
            else:
                self.logger.error(f"Unknown rollback strategy: {rollback_strategy}")
                return False
        except Exception as e:
            self.logger.error(f"Rollback failed: {e}")
            return False

    def _immediate_rollback(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Perform immediate rollback.

        Args:
            snapshot: Target snapshot

        Returns:
            bool: True if successful
        """
        self.logger.info(f"Performing immediate rollback to {snapshot.version}")

        # Restore configuration
        if not self._restore_configuration(snapshot):
            return False

        # Restore artifacts if available
        if snapshot.artifacts_path and not self._restore_artifacts(snapshot):
            return False

        # The actual traffic switching would be handled by EnvironmentSwitcher
        # This manager just prepares the state

        self.logger.info("Immediate rollback completed")
        return True

    def _gradual_rollback(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Perform gradual rollback.

        Args:
            snapshot: Target snapshot

        Returns:
            bool: True if successful
        """
        self.logger.info(f"Performing gradual rollback to {snapshot.version}")

        # Similar to immediate but with gradual traffic shifting
        # The gradual switching would be coordinated with EnvironmentSwitcher

        if not self._restore_configuration(snapshot):
            return False

        if snapshot.artifacts_path and not self._restore_artifacts(snapshot):
            return False

        self.logger.info("Gradual rollback completed")
        return True

    def _safe_rollback(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Perform safe rollback with validation.

        Args:
            snapshot: Target snapshot

        Returns:
            bool: True if successful
        """
        self.logger.info(f"Performing safe rollback to {snapshot.version}")

        # Validate that the snapshot is still viable
        if not self._validate_snapshot(snapshot):
            self.logger.error("Snapshot validation failed, aborting safe rollback")
            return False

        # Perform the rollback
        if not self._immediate_rollback(snapshot):
            return False

        # Additional validation after rollback
        if not self._post_rollback_validation(snapshot):
            self.logger.warning("Post-rollback validation failed, but rollback completed")
            # Still return True as the rollback itself succeeded

        self.logger.info("Safe rollback completed")
        return True

    def _restore_configuration(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Restore deployment configuration from snapshot.

        Args:
            snapshot: Snapshot to restore from

        Returns:
            bool: True if successful
        """
        try:
            # In a real implementation, this would restore:
            # - Environment variables
            # - Configuration files
            # - Database schema changes
            # - Service configurations

            self.logger.info(f"Restoring configuration for {snapshot.environment}")
            # Simulate restoration
            time.sleep(1)

            return True
        except Exception as e:
            self.logger.error(f"Configuration restoration failed: {e}")
            return False

    def _restore_artifacts(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Restore deployment artifacts from backup.

        Args:
            snapshot: Snapshot to restore from

        Returns:
            bool: True if successful
        """
        if not snapshot.artifacts_path or not os.path.exists(snapshot.artifacts_path):
            self.logger.warning("No artifacts backup available")
            return True

        try:
            # In a real implementation, this would:
            # - Restore container images
            # - Restore application binaries
            # - Restore configuration files

            self.logger.info(f"Restoring artifacts from {snapshot.artifacts_path}")
            # Simulate restoration
            time.sleep(2)

            return True
        except Exception as e:
            self.logger.error(f"Artifacts restoration failed: {e}")
            return False

    def _backup_artifacts(self, environment: str, snapshot_id: str) -> str:
        """
        Create backup of deployment artifacts.

        Args:
            environment: Environment to backup
            snapshot_id: Snapshot identifier

        Returns:
            str: Path to backup
        """
        backup_path = os.path.join(self.backup_path, snapshot_id)

        try:
            os.makedirs(backup_path, exist_ok=True)

            # In a real implementation, this would backup:
            # - Container images
            # - Configuration files
            # - Database backups if needed

            # Create a simple marker file
            with open(os.path.join(backup_path, 'backup_info.txt'), 'w') as f:
                f.write(f"Backup for {environment} at {time.time()}\n")

            self.logger.info(f"Created artifacts backup at {backup_path}")
            return backup_path
        except Exception as e:
            self.logger.error(f"Artifacts backup failed: {e}")
            return ""

    def _validate_snapshot(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Validate that a snapshot is still viable for rollback.

        Args:
            snapshot: Snapshot to validate

        Returns:
            bool: True if valid
        """
        # Check if snapshot is not too old
        max_age = self.config.get('max_snapshot_age', 7 * 24 * 3600)  # 7 days
        if time.time() - snapshot.timestamp > max_age:
            self.logger.warning(f"Snapshot {snapshot.version} is too old")
            return False

        # Check if artifacts still exist
        if snapshot.artifacts_path and not os.path.exists(snapshot.artifacts_path):
            self.logger.warning(f"Snapshot artifacts missing for {snapshot.version}")
            return False

        return True

    def _post_rollback_validation(self, snapshot: DeploymentSnapshot) -> bool:
        """
        Perform validation after rollback.

        Args:
            snapshot: Snapshot that was rolled back to

        Returns:
            bool: True if validation passes
        """
        # In a real implementation, this would:
        # - Run health checks
        # - Validate service functionality
        # - Check metrics

        self.logger.info("Performing post-rollback validation")
        # Simulate validation
        time.sleep(1)

        return True

    def _find_snapshot(self, snapshot_id: str) -> Optional[DeploymentSnapshot]:
        """
        Find a snapshot by ID.

        Args:
            snapshot_id: Snapshot identifier

        Returns:
            DeploymentSnapshot or None
        """
        for snapshot in self.snapshots:
            if f"{snapshot.environment}_{snapshot.version}_{int(snapshot.timestamp)}" == snapshot_id:
                return snapshot
        return None

    def get_rollback_history(self) -> List[Dict[str, Any]]:
        """
        Get rollback history.

        Returns:
            list: List of rollback operations
        """
        return [
            {
                'timestamp': snapshot.timestamp,
                'environment': snapshot.environment,
                'version': snapshot.version,
                'traffic_distribution': snapshot.traffic_distribution
            }
            for snapshot in self.snapshots
        ]

    def cleanup_old_snapshots(self, max_age_days: int = 7):
        """
        Clean up old snapshots.

        Args:
            max_age_days: Maximum age in days
        """
        max_age_seconds = max_age_days * 24 * 3600
        current_time = time.time()

        to_remove = []
        for snapshot in self.snapshots:
            if current_time - snapshot.timestamp > max_age_seconds:
                to_remove.append(snapshot)

        for snapshot in to_remove:
            self.snapshots.remove(snapshot)
            if snapshot.artifacts_path and os.path.exists(snapshot.artifacts_path):
                shutil.rmtree(snapshot.artifacts_path)

        if to_remove:
            self.logger.info(f"Cleaned up {len(to_remove)} old snapshots")

    def should_auto_rollback(self, error_rate: float) -> bool:
        """
        Determine if automatic rollback should be triggered.

        Args:
            error_rate: Current error rate percentage

        Returns:
            bool: True if auto-rollback should trigger
        """
        return error_rate >= self.auto_rollback_threshold