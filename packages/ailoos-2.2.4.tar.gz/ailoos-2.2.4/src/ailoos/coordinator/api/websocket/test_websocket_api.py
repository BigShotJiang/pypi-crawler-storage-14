"""
Basic tests for WebSocket API endpoints.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import Mock, patch, AsyncMock
import json


@pytest.mark.asyncio
async def test_websocket_connections_endpoint():
    """Test listing WebSocket connections."""
    from ...websocket.manager import manager
    from .websocket_api import router

    # Mock manager data
    with patch.object(manager, 'active_connections', {
        'session1': {'node1': Mock(), 'node2': Mock()},
        'session2': {'node3': Mock()}
    }):
        with patch.object(manager, 'connection_metadata', {
            'session1': {
                'node1': {'connected_at': Mock(isoformat=lambda: '2023-01-01T00:00:00')},
                'node2': {'connected_at': Mock(isoformat=lambda: '2023-01-01T00:00:00')}
            }
        }):
            # This would need a proper test client setup
            # For now, just verify the endpoint exists
            assert router is not None


@pytest.mark.asyncio
async def test_websocket_stats_endpoint():
    """Test WebSocket stats endpoint."""
    from ...websocket.manager import manager
    from ...websocket.room_manager import room_manager
    from ...websocket.message_broker import message_broker

    # Mock data
    with patch.object(manager, 'active_connections', {'session1': {'node1': Mock()}}):
        with patch.object(room_manager, 'room_subscriptions', {'room1': set()}):
            with patch.object(message_broker, 'get_stats', new_callable=AsyncMock) as mock_stats:
                mock_stats.return_value = {"queue_size": 5}

                # Verify mocks are set up
                assert len(manager.active_connections) == 1
                assert len(room_manager.room_subscriptions) == 1


@pytest.mark.asyncio
async def test_broadcast_message():
    """Test broadcasting messages via WebSocket API."""
    from ...websocket.message_broker import message_broker

    with patch.object(message_broker, 'publish', new_callable=AsyncMock) as mock_publish:
        mock_publish.return_value = None

        # Verify mock is set up
        assert mock_publish is not None


@pytest.mark.asyncio
async def test_session_websocket_connection():
    """Test session WebSocket endpoint connection."""
    from .session_websocket import router

    # Verify router exists
    assert router is not None

    # Check that the WebSocket endpoint is registered
    routes = [route for route in router.routes if hasattr(route, 'path')]
    websocket_routes = [route for route in routes if getattr(route, 'path', '').startswith('/ws/sessions')]
    assert len(websocket_routes) > 0


@pytest.mark.asyncio
async def test_metrics_websocket_endpoints():
    """Test metrics WebSocket endpoints."""
    from .metrics_websocket import router

    # Verify router exists
    assert router is not None

    # Check for WebSocket routes
    routes = [route for route in router.routes if hasattr(route, 'path')]
    websocket_routes = [route for route in routes if getattr(route, 'path', '').startswith('/ws/metrics')]
    assert len(websocket_routes) > 0


@pytest.mark.asyncio
async def test_alerts_websocket_endpoints():
    """Test alerts WebSocket endpoints."""
    from .alerts_websocket import router

    # Verify router exists
    assert router is not None

    # Check for WebSocket routes
    routes = [route for route in router.routes if hasattr(route, 'path')]
    websocket_routes = [route for route in routes if getattr(route, 'path', '').startswith('/ws/alerts')]
    assert len(websocket_routes) > 0


@pytest.mark.asyncio
async def test_federated_websocket_endpoints():
    """Test federated WebSocket endpoints."""
    from .federated_websocket import router

    # Verify router exists
    assert router is not None

    # Check for WebSocket routes
    routes = [route for route in router.routes if hasattr(route, 'path')]
    websocket_routes = [route for route in routes if getattr(route, 'path', '').startswith('/ws/federated')]
    assert len(websocket_routes) > 0


def test_websocket_api_router_import():
    """Test that WebSocket API router can be imported."""
    try:
        from .websocket_api import router as websocket_api_router
        assert websocket_api_router is not None
    except ImportError as e:
        pytest.fail(f"Failed to import websocket_api router: {e}")


def test_session_websocket_router_import():
    """Test that session WebSocket router can be imported."""
    try:
        from .session_websocket import router as session_websocket_router
        assert session_websocket_router is not None
    except ImportError as e:
        pytest.fail(f"Failed to import session_websocket router: {e}")


def test_metrics_websocket_router_import():
    """Test that metrics WebSocket router can be imported."""
    try:
        from .metrics_websocket import router as metrics_websocket_router
        assert metrics_websocket_router is not None
    except ImportError as e:
        pytest.fail(f"Failed to import metrics_websocket router: {e}")


def test_alerts_websocket_router_import():
    """Test that alerts WebSocket router can be imported."""
    try:
        from .alerts_websocket import router as alerts_websocket_router
        assert alerts_websocket_router is not None
    except ImportError as e:
        pytest.fail(f"Failed to import alerts_websocket router: {e}")


def test_federated_websocket_router_import():
    """Test that federated WebSocket router can be imported."""
    try:
        from .federated_websocket import router as federated_websocket_router
        assert federated_websocket_router is not None
    except ImportError as e:
        pytest.fail(f"Failed to import federated_websocket router: {e}")


def test_websocket_module_init():
    """Test that the WebSocket module __init__.py exports are correct."""
    try:
        from . import (
            websocket_api_router,
            session_websocket_router,
            metrics_websocket_router,
            alerts_websocket_router,
            federated_websocket_router
        )

        assert websocket_api_router is not None
        assert session_websocket_router is not None
        assert metrics_websocket_router is not None
        assert alerts_websocket_router is not None
        assert federated_websocket_router is not None

    except ImportError as e:
        pytest.fail(f"Failed to import from websocket module __init__: {e}")


@pytest.mark.asyncio
async def test_websocket_authentication_validation():
    """Test that WebSocket endpoints validate authentication."""
    from ...auth.jwt import verify_token

    # Mock invalid token
    with patch.object(verify_token, 'side_effect', Exception("Invalid token")):
        # This would test actual WebSocket connection rejection
        # For now, just verify the verify_token function exists
        assert verify_token is not None


def test_websocket_message_types():
    """Test that WebSocket message types are available."""
    try:
        from ...websocket.message_types import WebSocketMessageFactory

        # Test creating different message types
        session_msg = WebSocketMessageFactory.create_session_update(
            session_id="test_session",
            update_type="test",
            data={"test": "data"}
        )
        assert session_msg is not None

        alert_msg = WebSocketMessageFactory.create_system_alert(
            alert_type="test",
            message="Test alert",
            data={"test": "data"}
        )
        assert alert_msg is not None

        metrics_msg = WebSocketMessageFactory.create_metrics_update(
            metrics_type="test",
            data={"test": "data"}
        )
        assert metrics_msg is not None

        federated_msg = WebSocketMessageFactory.create_federated_event(
            event_type="test",
            message="Test event",
            data={"test": "data"}
        )
        assert federated_msg is not None

    except ImportError as e:
        pytest.fail(f"Failed to import WebSocket message types: {e}")


def test_room_manager_integration():
    """Test that room manager is properly integrated."""
    try:
        from ...websocket.room_manager import room_manager

        # Test basic room operations
        assert hasattr(room_manager, 'join_room')
        assert hasattr(room_manager, 'leave_room')
        assert hasattr(room_manager, 'broadcast_to_room')

    except ImportError as e:
        pytest.fail(f"Failed to import room manager: {e}")


def test_message_broker_integration():
    """Test that message broker is properly integrated."""
    try:
        from ...websocket.message_broker import message_broker

        # Test basic broker operations
        assert hasattr(message_broker, 'publish')
        assert hasattr(message_broker, 'get_stats')

    except ImportError as e:
        pytest.fail(f"Failed to import message broker: {e}")