"""
gRPC service for federated inference in AILOOS FASE 4.

This provides high-performance gRPC endpoints for federated inference operations.
"""

import asyncio
import json
import time
from typing import List, Dict, Any
from concurrent import futures
import logging

# gRPC imports (conditional)
try:
    import grpc
    from grpc import aio
    GRPC_AVAILABLE = True
except ImportError:
    grpc = None
    aio = None
    GRPC_AVAILABLE = False

# Import local modules
from ....inference.api import EmpoorioLMInferenceAPI, InferenceConfig
from ....marketplace.registry.model_registry import get_model_registry
from ...auth.jwt import verify_token
from ..endpoints.inference import _authenticate_wallet, _encrypt_response, _decrypt_request

logger = logging.getLogger(__name__)


# gRPC message definitions (simplified - in production use protobuf)
class FederatedQueryRequest:
    def __init__(self, model_id: str = "", prompt: str = "", max_tokens: int = 512,
                 temperature: float = 0.7, top_p: float = 0.9, top_k: int = 50,
                 stream: bool = False, encrypted: bool = False, wallet_signature: str = ""):
        self.model_id = model_id
        self.prompt = prompt
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.top_p = top_p
        self.top_k = top_k
        self.stream = stream
        self.encrypted = encrypted
        self.wallet_signature = wallet_signature


class FederatedQueryResponse:
    def __init__(self, text: str = "", usage: Dict[str, Any] = None,
                 model_version: str = "", federated_nodes: List[str] = None,
                 processing_time: float = 0.0, encrypted: bool = False):
        self.text = text
        self.usage = usage or {}
        self.model_version = model_version
        self.federated_nodes = federated_nodes or []
        self.processing_time = processing_time
        self.encrypted = encrypted


class InferenceStatusResponse:
    def __init__(self, status: str = "", federated_coordinator_status: str = "",
                 model_registry_status: str = "", active_models: List[str] = None,
                 federated_nodes: List[Dict[str, Any]] = None, metrics: Dict[str, Any] = None):
        self.status = status
        self.federated_coordinator_status = federated_coordinator_status
        self.model_registry_status = model_registry_status
        self.active_models = active_models or []
        self.federated_nodes = federated_nodes or []
        self.metrics = metrics or {}


class FederatedInferenceServicer:
    """
    gRPC servicer for federated inference operations.
    """

    def __init__(self):
        self.inference_coordinator = None
        self.model_registry = None
        self._initialize_services()

    def _initialize_services(self):
        """Initialize inference coordinator and model registry."""
        try:
            # Initialize inference coordinator
            config = InferenceConfig()
            self.inference_coordinator = EmpoorioLMInferenceAPI(config)

            # Initialize model registry
            self.model_registry = get_model_registry()

            logger.info("✅ gRPC Federated Inference Servicer initialized")

        except Exception as e:
            logger.error(f"❌ Error initializing gRPC servicer: {e}")

    async def FederatedQuery(self, request, context):
        """
        Perform federated inference query via gRPC.

        Args:
            request: FederatedQueryRequest
            context: gRPC context

        Returns:
            FederatedQueryResponse
        """
        try:
            start_time = time.time()

            # Validate model exists
            if self.model_registry:
                model_info = await self.model_registry._get_model(request.model_id)
                if not model_info:
                    context.set_code(grpc.StatusCode.NOT_FOUND)
                    context.set_details(f"Model {request.model_id} not found")
                    return FederatedQueryResponse()

            # Authenticate wallet if signature provided
            if request.wallet_signature:
                await _authenticate_wallet(request.wallet_signature, request.model_id)

            # Process encrypted request
            prompt = request.prompt
            if request.encrypted:
                prompt = await _decrypt_request(prompt)

            # Perform inference
            if self.inference_coordinator and self.inference_coordinator.is_loaded:
                from ....inference.api import InferenceRequest as APIInferenceRequest
                inference_request = APIInferenceRequest(
                    prompt=prompt,
                    max_tokens=request.max_tokens,
                    temperature=request.temperature,
                    top_p=request.top_p,
                    top_k=request.top_k,
                    stream=False
                )
                response = await self.inference_coordinator.generate(inference_request)
                generated_text = response.text
            else:
                # Fallback - return error
                context.set_code(grpc.StatusCode.UNAVAILABLE)
                context.set_details("Inference coordinator not available")
                return FederatedQueryResponse()

            # Encrypt response if requested
            if request.encrypted:
                generated_text = await _encrypt_response(generated_text)

            processing_time = time.time() - start_time

            return FederatedQueryResponse(
                text=generated_text,
                usage=getattr(response, 'usage', {}),
                model_version=request.model_id,
                federated_nodes=["grpc-coordinator-node"],
                processing_time=processing_time,
                encrypted=request.encrypted
            )

        except Exception as e:
            logger.error(f"gRPC FederatedQuery error: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Inference error: {str(e)}")
            return FederatedQueryResponse()

    async def GetFederatedStatus(self, request, context):
        """
        Get federated inference service status via gRPC.

        Args:
            request: Empty request
            context: gRPC context

        Returns:
            InferenceStatusResponse
        """
        try:
            # Get coordinator status
            coordinator_status = "healthy" if self.inference_coordinator and self.inference_coordinator.is_loaded else "unhealthy"

            # Get model registry status
            registry_status = "healthy" if self.model_registry else "unhealthy"

            # Get active models
            active_models = []
            if self.model_registry:
                try:
                    models = await self.model_registry.query_models({"status": "published"})
                    active_models = [m['model_id'] for m in models]
                except Exception:
                    active_models = []

            # Placeholder data
            federated_nodes = [{"node_id": "grpc-coordinator", "status": "active", "models": active_models}]
            metrics = {"grpc_requests": 0, "grpc_throughput": 0.0}

            return InferenceStatusResponse(
                status="healthy" if coordinator_status == "healthy" and registry_status == "healthy" else "degraded",
                federated_coordinator_status=coordinator_status,
                model_registry_status=registry_status,
                active_models=active_models,
                federated_nodes=federated_nodes,
                metrics=metrics
            )

        except Exception as e:
            logger.error(f"gRPC GetFederatedStatus error: {e}")
            context.set_code(grpc.StatusCode.INTERNAL)
            context.set_details(f"Status error: {str(e)}")
            return InferenceStatusResponse()


async def serve_grpc(port: int = 50051):
    """
    Start gRPC server for federated inference.

    Args:
        port: Port to listen on
    """
    if not GRPC_AVAILABLE:
        logger.warning("gRPC not available. Install grpcio to enable gRPC support.")
        return

    try:
        server = aio.server(futures.ThreadPoolExecutor(max_workers=10))
        # Note: In production, add proper service registration here
        # server.add_insecure_port(f"[::]:{port}")

        logger.info(f"🚀 gRPC Federated Inference Server starting on port {port}")
        await server.start()
        await server.wait_for_termination()

    except Exception as e:
        logger.error(f"❌ Error starting gRPC server: {e}")


# Utility functions
def create_grpc_service():
    """
    Create and return gRPC service instance.

    Returns:
        FederatedInferenceServicer instance
    """
    return FederatedInferenceServicer()


if __name__ == "__main__":
    # Test gRPC service
    print("🧪 Testing gRPC Federated Inference Service...")

    if GRPC_AVAILABLE:
        servicer = create_grpc_service()
        print("✅ gRPC service created successfully")

        # Note: In production, start the server
        # asyncio.run(serve_grpc())
    else:
        print("⚠️ gRPC not available - install grpcio for gRPC support")