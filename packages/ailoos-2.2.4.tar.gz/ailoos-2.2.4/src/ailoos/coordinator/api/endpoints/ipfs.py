"""
IPFS API Endpoints - Gestión automática de IPFS para usuarios no técnicos
Implementa instalación, configuración y conexión automática de IPFS.
"""

import asyncio
import json
import os
import platform
import subprocess
import time
from typing import Dict, Any, Optional, List
import aiohttp
import psutil
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

from ....infrastructure.ipfs_embedded import IPFSManager, create_ipfs_manager
from ....utils.logging import get_logger

logger = get_logger(__name__)
router = APIRouter()

# Modelos Pydantic
class IPFSConfig(BaseModel):
    endpoint: Optional[str] = "http://localhost:5001"
    gateway: Optional[str] = "http://localhost:8080"

class IPFSStatusResponse(BaseModel):
    connected: bool
    endpoint: Optional[str] = None
    gateway: Optional[str] = None
    version: Optional[str] = None
    peers: Optional[int] = 0
    error: Optional[str] = None
    daemon_running: bool = False
    auto_setup_available: bool = True

class IPFSInstallResponse(BaseModel):
    success: bool
    message: str
    progress: Optional[str] = None
    daemon_started: bool = False

# Estado global para el gestor IPFS
ipfs_manager: Optional[IPFSManager] = None
installation_task: Optional[asyncio.Task] = None

async def get_ipfs_manager() -> IPFSManager:
    """Obtiene o crea el gestor IPFS."""
    global ipfs_manager
    if ipfs_manager is None:
        try:
            ipfs_manager = await create_ipfs_manager()
            logger.info("✅ IPFS Manager creado exitosamente")
        except Exception as e:
            logger.error(f"❌ Error creando IPFS Manager: {e}")
            raise HTTPException(status_code=500, detail="Error inicializando IPFS")
    return ipfs_manager

def is_ipfs_daemon_running() -> bool:
    """Verifica si el daemon de IPFS está ejecutándose."""
    try:
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            if proc.info['name'] == 'ipfs' and 'daemon' in proc.info.get('cmdline', []):
                return True
        return False
    except Exception as e:
        logger.warning(f"Error verificando daemon IPFS: {e}")
        return False

async def check_ipfs_connectivity(endpoint: str = "http://localhost:5001") -> Dict[str, Any]:
    """Verifica la conectividad con IPFS."""
    try:
        timeout = aiohttp.ClientTimeout(total=5)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(f"{endpoint}/api/v0/version") as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "connected": True,
                        "version": data.get("Version", "unknown"),
                        "endpoint": endpoint
                    }
    except Exception as e:
        logger.debug(f"IPFS no disponible en {endpoint}: {e}")

    return {"connected": False, "error": "IPFS daemon no responde"}

async def get_ipfs_peers(endpoint: str = "http://localhost:5001") -> int:
    """Obtiene el número de peers conectados."""
    try:
        timeout = aiohttp.ClientTimeout(total=5)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(f"{endpoint}/api/v0/swarm/peers") as response:
                if response.status == 200:
                    data = await response.json()
                    return len(data.get("Peers", []))
    except Exception as e:
        logger.debug(f"Error obteniendo peers IPFS: {e}")
    return 0

async def configure_ipfs_cors(endpoint: str = "http://localhost:5001"):
    """Configura CORS automáticamente para desarrollo."""
    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            # Configurar headers CORS
            cors_headers = {
                "Access-Control-Allow-Origin": ["*"],
                "Access-Control-Allow-Methods": ["PUT", "POST", "GET"],
                "Access-Control-Allow-Headers": ["*"]
            }

            for header, values in cors_headers.items():
                async with session.post(
                    f"{endpoint}/api/v0/config",
                    params={"arg": f"API.HTTPHeaders.{header}", "arg": json.dumps(values)}
                ) as response:
                    if response.status != 200:
                        logger.warning(f"Error configurando CORS header {header}")

            logger.info("✅ CORS configurado automáticamente para IPFS")
    except Exception as e:
        logger.warning(f"Error configurando CORS: {e}")

async def install_ipfs_daemon(progress_callback=None) -> Dict[str, Any]:
    """Instala y configura IPFS automáticamente."""
    system = platform.system().lower()
    arch = platform.machine().lower()

    try:
        if progress_callback:
            progress_callback("Verificando sistema operativo...")

        if system == "darwin":  # macOS
            if progress_callback:
                progress_callback("Instalando IPFS en macOS...")

            # Verificar si brew está disponible
            try:
                subprocess.run(["brew", "--version"], check=True, capture_output=True)
                # Instalar con brew
                subprocess.run(["brew", "install", "ipfs"], check=True)
                logger.info("✅ IPFS instalado con Homebrew")
            except subprocess.CalledProcessError:
                # Fallback: descargar manualmente
                if progress_callback:
                    progress_callback("Homebrew no disponible, descargando manualmente...")
                await download_ipfs_binary(system, arch, progress_callback)

        elif system == "linux":
            if progress_callback:
                progress_callback("Instalando IPFS en Linux...")
            await download_ipfs_binary(system, arch, progress_callback)

        elif system == "windows":
            if progress_callback:
                progress_callback("Instalando IPFS en Windows...")
            await download_ipfs_binary(system, arch, progress_callback)

        else:
            raise Exception(f"Sistema operativo no soportado: {system}")

        if progress_callback:
            progress_callback("Inicializando repositorio IPFS...")

        # Inicializar repositorio IPFS
        result = subprocess.run(["ipfs", "init"], capture_output=True, text=True)
        if result.returncode != 0:
            # Si ya está inicializado, continuar
            if "already initialized" not in result.stderr:
                raise Exception(f"Error inicializando IPFS: {result.stderr}")

        if progress_callback:
            progress_callback("Configurando IPFS...")

        # Configurar gateway por defecto
        subprocess.run(["ipfs", "config", "Addresses.Gateway", "/ip4/127.0.0.1/tcp/8080"], check=True)

        if progress_callback:
            progress_callback("Iniciando daemon IPFS...")

        # Iniciar daemon en background
        process = subprocess.Popen(["ipfs", "daemon"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        # Esperar a que esté listo
        max_attempts = 30
        for attempt in range(max_attempts):
            if progress_callback:
                progress_callback(f"Esperando que IPFS esté listo... ({attempt + 1}/{max_attempts})")

            await asyncio.sleep(2)

            # Verificar conectividad
            connectivity = await check_ipfs_connectivity()
            if connectivity["connected"]:
                if progress_callback:
                    progress_callback("Configurando CORS...")

                # Configurar CORS
                await configure_ipfs_cors()

                if progress_callback:
                    progress_callback("¡IPFS instalado y configurado exitosamente!")

                return {
                    "success": True,
                    "message": "IPFS instalado y configurado automáticamente",
                    "daemon_started": True
                }

        # Si no se conectó, pero el proceso sigue corriendo
        if process.poll() is None:
            return {
                "success": True,
                "message": "IPFS daemon iniciado, esperando conexión...",
                "daemon_started": True
            }

        raise Exception("IPFS daemon no pudo iniciarse correctamente")

    except Exception as e:
        logger.error(f"Error instalando IPFS: {e}")
        return {
            "success": False,
            "message": f"Error instalando IPFS: {str(e)}",
            "daemon_started": False
        }

async def download_ipfs_binary(system: str, arch: str, progress_callback=None):
    """Descarga el binario de IPFS."""
    import urllib.request
    import tarfile
    import zipfile

    # Mapear arquitectura
    if arch in ["x86_64", "amd64"]:
        arch = "amd64"
    elif arch in ["arm64", "aarch64"]:
        arch = "arm64"
    else:
        arch = "386"

    # URL de descarga (versión estable)
    version = "0.21.0"
    if system == "darwin":
        filename = f"kubo_v{version}_darwin-{arch}.tar.gz"
    elif system == "linux":
        filename = f"kubo_v{version}_linux-{arch}.tar.gz"
    elif system == "windows":
        filename = f"kubo_v{version}_windows-{arch}.zip"
    else:
        raise Exception(f"Sistema no soportado: {system}-{arch}")

    url = f"https://dist.ipfs.tech/kubo/v{version}/{filename}"

    try:
        if progress_callback:
            progress_callback(f"Descargando IPFS desde {url}...")

        # Descargar archivo
        with urllib.request.urlopen(url) as response:
            data = response.read()

        # Guardar archivo temporal
        temp_path = f"/tmp/{filename}"
        with open(temp_path, "wb") as f:
            f.write(data)

        if progress_callback:
            progress_callback("Extrayendo archivos...")

        # Extraer
        if filename.endswith(".tar.gz"):
            with tarfile.open(temp_path, "r:gz") as tar:
                tar.extractall("/tmp")
            binary_dir = f"/tmp/kubo"
        elif filename.endswith(".zip"):
            with zipfile.ZipFile(temp_path, "r") as zip_ref:
                zip_ref.extractall("/tmp")
            binary_dir = f"/tmp/kubo"
        else:
            raise Exception("Formato de archivo no soportado")

        # Copiar binario a /usr/local/bin o directorio en PATH
        import shutil
        binary_path = os.path.join(binary_dir, "ipfs")
        target_path = "/usr/local/bin/ipfs"

        # Crear directorio si no existe
        os.makedirs(os.path.dirname(target_path), exist_ok=True)

        # Copiar con permisos de ejecución
        shutil.copy2(binary_path, target_path)
        os.chmod(target_path, 0o755)

        if progress_callback:
            progress_callback("Binario IPFS instalado correctamente")

    except Exception as e:
        raise Exception(f"Error descargando IPFS: {e}")

@router.get("/status", response_model=IPFSStatusResponse)
async def get_ipfs_status():
    """Obtiene el estado actual de IPFS."""
    try:
        daemon_running = is_ipfs_daemon_running()

        if daemon_running:
            # Verificar conectividad
            connectivity = await check_ipfs_connectivity()
            if connectivity["connected"]:
                peers = await get_ipfs_peers()
                return IPFSStatusResponse(
                    connected=True,
                    endpoint="http://localhost:5001",
                    gateway="http://localhost:8080",
                    version=connectivity.get("version"),
                    peers=peers,
                    daemon_running=True
                )
            else:
                return IPFSStatusResponse(
                    connected=False,
                    error="IPFS daemon ejecutándose pero no responde",
                    daemon_running=True
                )
        else:
            return IPFSStatusResponse(
                connected=False,
                error="IPFS daemon no está ejecutándose",
                daemon_running=False
            )

    except Exception as e:
        logger.error(f"Error obteniendo estado IPFS: {e}")
        return IPFSStatusResponse(
            connected=False,
            error=f"Error verificando IPFS: {str(e)}",
            daemon_running=False
        )

@router.post("/connect", response_model=IPFSStatusResponse)
async def connect_ipfs(config: IPFSConfig):
    """Conecta a IPFS con configuración automática."""
    try:
        # Verificar si daemon está corriendo
        if not is_ipfs_daemon_running():
            raise HTTPException(status_code=400, detail="IPFS daemon no está ejecutándose. Use /install primero.")

        # Verificar conectividad
        connectivity = await check_ipfs_connectivity(config.endpoint)
        if not connectivity["connected"]:
            raise HTTPException(status_code=400, detail="No se puede conectar al daemon IPFS")

        # Obtener manager y conectar
        manager = await get_ipfs_manager()
        await manager.start()

        # Configurar CORS si es necesario
        await configure_ipfs_cors(config.endpoint)

        # Obtener peers
        peers = await get_ipfs_peers(config.endpoint)

        return IPFSStatusResponse(
            connected=True,
            endpoint=config.endpoint,
            gateway=config.gateway,
            version=connectivity.get("version"),
            peers=peers,
            daemon_running=True
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error conectando a IPFS: {e}")
        raise HTTPException(status_code=500, detail=f"Error conectando a IPFS: {str(e)}")

@router.post("/disconnect")
async def disconnect_ipfs():
    """Desconecta de IPFS."""
    try:
        global ipfs_manager
        if ipfs_manager:
            await ipfs_manager.stop()
            ipfs_manager = None

        return {"success": True, "message": "Desconectado de IPFS"}

    except Exception as e:
        logger.error(f"Error desconectando IPFS: {e}")
        raise HTTPException(status_code=500, detail=f"Error desconectando: {str(e)}")

@router.post("/install", response_model=IPFSInstallResponse)
async def install_ipfs(background_tasks: BackgroundTasks):
    """Instala y configura IPFS automáticamente."""
    global installation_task

    # Verificar si ya hay una instalación en progreso
    if installation_task and not installation_task.done():
        return IPFSInstallResponse(
            success=False,
            message="Instalación de IPFS ya en progreso",
            progress="Instalación en curso..."
        )

    # Verificar si ya está instalado y funcionando
    if is_ipfs_daemon_running():
        connectivity = await check_ipfs_connectivity()
        if connectivity["connected"]:
            return IPFSInstallResponse(
                success=True,
                message="IPFS ya está instalado y funcionando",
                daemon_started=True
            )

    # Iniciar instalación en background
    progress_messages = []

    def progress_callback(message: str):
        progress_messages.append(message)
        logger.info(f"IPFS Install Progress: {message}")

    async def install_task():
        try:
            result = await install_ipfs_daemon(progress_callback)
            return result
        except Exception as e:
            logger.error(f"Error en instalación IPFS: {e}")
            return {
                "success": False,
                "message": f"Error instalando IPFS: {str(e)}",
                "daemon_started": False
            }

    installation_task = asyncio.create_task(install_task())
    background_tasks.add_task(lambda: None)  # Placeholder para background tasks

    try:
        # Esperar un poco para ver progreso inicial
        await asyncio.sleep(2)

        if installation_task.done():
            result = installation_task.result()
            return IPFSInstallResponse(**result)
        else:
            return IPFSInstallResponse(
                success=True,
                message="Instalación de IPFS iniciada",
                progress="Iniciando instalación...",
                daemon_started=False
            )

    except Exception as e:
        return IPFSInstallResponse(
            success=False,
            message=f"Error iniciando instalación: {str(e)}",
            daemon_started=False
        )

@router.get("/install/progress")
async def get_install_progress():
    """Obtiene el progreso de la instalación."""
    global installation_task

    if not installation_task:
        return {"status": "not_started"}

    if installation_task.done():
        try:
            result = installation_task.result()
            return {
                "status": "completed",
                "result": result
            }
        except Exception as e:
            return {
                "status": "failed",
                "error": str(e)
            }
    else:
        return {
            "status": "in_progress",
            "message": "Instalación en curso..."
        }

@router.get("/peers")
async def get_ipfs_peers_endpoint():
    """Obtiene información de peers IPFS."""
    try:
        if not is_ipfs_daemon_running():
            raise HTTPException(status_code=400, detail="IPFS daemon no ejecutándose")

        peers_count = await get_ipfs_peers()

        # Intentar obtener lista detallada de peers
        try:
            timeout = aiohttp.ClientTimeout(total=5)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post("http://localhost:5001/api/v0/swarm/peers") as response:
                    if response.status == 200:
                        data = await response.json()
                        peers = []
                        for peer in data.get("Peers", [])[:10]:  # Limitar a 10 peers
                            peers.append({
                                "peer_id": peer.get("Peer", "unknown"),
                                "addresses": peer.get("Addr", []),
                                "connected": True,
                                "last_seen": int(time.time())
                            })

                        return {"peers": peers, "total": peers_count}
        except Exception:
            pass

        return {"peers": [], "total": peers_count}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error obteniendo peers IPFS: {e}")
        raise HTTPException(status_code=500, detail=f"Error obteniendo peers: {str(e)}")

@router.get("/pinned")
async def get_ipfs_pinned():
    """Obtiene contenido pineado en IPFS."""
    try:
        manager = await get_ipfs_manager()
        pinned = await manager.list_pinned()
        return {"pinned": pinned}

    except Exception as e:
        logger.error(f"Error obteniendo contenido pineado: {e}")
        raise HTTPException(status_code=500, detail=f"Error obteniendo contenido pineado: {str(e)}")

@router.post("/publish")
async def publish_to_ipfs(data: Dict[str, Any], metadata: Optional[Dict[str, Any]] = None):
    """Publica datos en IPFS."""
    try:
        manager = await get_ipfs_manager()
        cid = await manager.publish_data(json.dumps(data).encode(), metadata)
        return {"cid": cid, "success": True}

    except Exception as e:
        logger.error(f"Error publicando en IPFS: {e}")
        raise HTTPException(status_code=500, detail=f"Error publicando: {str(e)}")

@router.get("/get/{cid}")
async def get_from_ipfs(cid: str):
    """Obtiene datos desde IPFS."""
    try:
        manager = await get_ipfs_manager()
        data = await manager.get_data(cid)
        return json.loads(data.decode())

    except Exception as e:
        logger.error(f"Error obteniendo desde IPFS: {e}")
        raise HTTPException(status_code=404, detail=f"Contenido no encontrado: {str(e)}")