"""
API endpoints for system metrics and monitoring.
Provides REST APIs for detailed system metrics including node statistics,
session performance, P2P network metrics, system health, and historical data.
"""

from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, Query, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
import asyncio
from functools import lru_cache
import time

from ...database.connection import get_db
from ...auth.dependencies import get_current_user, require_admin, get_current_admin
from ...models.schemas import (
    NodeMetricsResponse,
    SessionMetricsResponse,
    P2PMetricsResponse,
    SystemHealthResponse,
    HistoricalMetricsResponse,
    AggregatedMetricsResponse,
    MetricsQuery,
    APIResponse,
    PaginatedResponse
)
from ...services.node_service import NodeService
from ...services.session_service import SessionService
from ...core.exceptions import CoordinatorException
# from ...utils.monitoring import SystemMonitor  # Commented out - module not found
# from ...networking.p2p_communication import P2PNetwork  # Commented out - module not found


router = APIRouter()
node_service = NodeService()
session_service = SessionService()
system_monitor = None  # SystemMonitor disabled due to missing module
p2p_network = None  # P2PNetwork disabled due to missing module

# Cache for expensive metrics calculations
@lru_cache(maxsize=32)
def _cached_aggregated_metrics(cache_key: str, timestamp: int) -> Dict[str, Any]:
    """Cache aggregated metrics for 5 minutes."""
    # Implementation will be added in the service layer
    return {}

# Cache for historical data
@lru_cache(maxsize=16)
def _cached_historical_metrics(metric_type: str, time_range: str, aggregation: str) -> List[Dict[str, Any]]:
    """Cache historical metrics for 10 minutes."""
    # Implementation will be added in the service layer
    return []


@router.get("/health", response_model=APIResponse)
async def get_system_health(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get overall system health status."""
    try:
        # Get system metrics
        health_data = await system_monitor.get_health_status()

        # Get database status
        db_status = "healthy"  # Simplified - could check actual DB connection

        # Get P2P network status
        p2p_status = await p2p_network.get_network_status()

        # Aggregate health response
        overall_status = "healthy"
        if health_data.get("cpu_usage", 0) > 90 or health_data.get("memory_usage", 0) > 90:
            overall_status = "warning"
        if not p2p_status.get("connected", True):
            overall_status = "critical"

        response = SystemHealthResponse(
            overall_status=overall_status,
            database_status=db_status,
            coordinator_status="healthy",
            p2p_network_status="healthy" if p2p_status.get("connected", True) else "disconnected",
            active_nodes=await node_service.get_active_nodes_count(db),
            active_sessions=await session_service.get_active_sessions_count(db),
            total_memory_usage_mb=health_data.get("memory_usage", 0),
            total_cpu_usage_percent=health_data.get("cpu_usage", 0),
            disk_usage_percent=health_data.get("disk_usage", 0),
            uptime_seconds=health_data.get("uptime", 0),
            last_health_check=datetime.utcnow()
        )

        return APIResponse(data=response)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving system health: {str(e)}")


@router.get("/nodes", response_model=PaginatedResponse)
async def get_node_metrics(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of records to return"),
    status: Optional[str] = Query(None, description="Filter by node status"),
    sort_by: str = Query("reputation_score", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order: asc or desc"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get detailed metrics for all nodes."""
    try:
        # Validate sort parameters
        valid_sort_fields = ["reputation_score", "total_contributions", "total_rewards_earned", "created_at", "last_heartbeat"]
        valid_sort_orders = ["asc", "desc"]

        if sort_by not in valid_sort_fields:
            raise HTTPException(status_code=400, detail=f"Invalid sort_by. Must be one of: {valid_sort_fields}")
        if sort_order not in valid_sort_orders:
            raise HTTPException(status_code=400, detail=f"Invalid sort_order. Must be one of: {valid_sort_orders}")

        # Validate status filter
        if status and status not in ["active", "inactive", "suspended", "verified", "unverified"]:
            raise HTTPException(status_code=400, detail="Invalid status filter")

        nodes_data = await node_service.get_nodes_with_metrics(
            db=db,
            skip=skip,
            limit=limit,
            status=status,
            sort_by=sort_by,
            sort_order=sort_order
        )

        # Convert to response format
        node_metrics = []
        for node in nodes_data["nodes"]:
            metrics = NodeMetricsResponse(
                node_id=node["id"],
                status=node["status"],
                reputation_score=node["reputation_score"],
                total_contributions=node["total_contributions"],
                total_rewards_earned=node["total_rewards_earned"],
                avg_training_time=node.get("avg_training_time"),
                avg_accuracy=node.get("avg_accuracy"),
                last_heartbeat=node.get("last_heartbeat"),
                uptime_percentage=node.get("uptime_percentage", 0.0),
                hardware_specs=node.get("hardware_specs")
            )
            node_metrics.append(metrics)

        return PaginatedResponse(
            data=node_metrics,
            total=nodes_data["total"],
            page=(skip // limit) + 1,
            page_size=limit,
            total_pages=(nodes_data["total"] + limit - 1) // limit
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving node metrics: {str(e)}")


@router.get("/nodes/{node_id}", response_model=APIResponse)
async def get_node_detailed_metrics(
    node_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get detailed metrics for a specific node."""
    try:
        # Validate node_id format (should be a valid identifier)
        if not node_id or len(node_id.strip()) == 0:
            raise HTTPException(status_code=400, detail="Invalid node_id")

        # Check if user has permission to view this node's metrics
        if current_user.get("roles") and "admin" not in current_user.get("roles", []) and current_user.get("node_id") != node_id:
            raise HTTPException(status_code=403, detail="Access denied to node metrics")

        node_data = await node_service.get_node_metrics_by_id(db=db, node_id=node_id)

        if not node_data:
            raise HTTPException(status_code=404, detail="Node not found")

        response = NodeMetricsResponse(
            node_id=node_data["id"],
            status=node_data["status"],
            reputation_score=node_data["reputation_score"],
            total_contributions=node_data["total_contributions"],
            total_rewards_earned=node_data["total_rewards_earned"],
            avg_training_time=node_data.get("avg_training_time"),
            avg_accuracy=node_data.get("avg_accuracy"),
            last_heartbeat=node_data.get("last_heartbeat"),
            uptime_percentage=node_data.get("uptime_percentage", 0.0),
            hardware_specs=node_data.get("hardware_specs")
        )

        return APIResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving node metrics: {str(e)}")


@router.get("/sessions", response_model=PaginatedResponse)
async def get_session_metrics(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of records to return"),
    status: Optional[str] = Query(None, description="Filter by session status"),
    sort_by: str = Query("created_at", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order: asc or desc"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get detailed metrics for all sessions."""
    try:
        sessions_data = await session_service.get_sessions_with_metrics(
            db=db,
            skip=skip,
            limit=limit,
            status=status,
            sort_by=sort_by,
            sort_order=sort_order
        )

        # Convert to response format
        session_metrics = []
        for session in sessions_data["sessions"]:
            metrics = SessionMetricsResponse(
                session_id=session["id"],
                status=session["status"],
                current_round=session["current_round"],
                total_rounds=session["total_rounds"],
                active_participants=session["active_participants"],
                total_participants=session["total_participants"],
                avg_accuracy=session.get("avg_accuracy"),
                avg_training_time=session.get("avg_training_time"),
                total_rewards_distributed=session["total_rewards_distributed"],
                created_at=session["created_at"],
                completed_at=session.get("completed_at")
            )
            session_metrics.append(metrics)

        return PaginatedResponse(
            data=session_metrics,
            total=sessions_data["total"],
            page=(skip // limit) + 1,
            page_size=limit,
            total_pages=(sessions_data["total"] + limit - 1) // limit
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving session metrics: {str(e)}")


@router.get("/p2p", response_model=APIResponse)
async def get_p2p_metrics(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get P2P network metrics."""
    try:
        p2p_data = await p2p_network.get_network_metrics()

        response = P2PMetricsResponse(
            total_connections=p2p_data.get("total_connections", 0),
            avg_latency_ms=p2p_data.get("avg_latency_ms", 0.0),
            messages_per_second=p2p_data.get("messages_per_second", 0.0),
            data_transferred_mb=p2p_data.get("data_transferred_mb", 0.0),
            active_peers=p2p_data.get("active_peers", 0),
            network_health_score=p2p_data.get("network_health_score", 0.0),
            connection_failures=p2p_data.get("connection_failures", 0),
            bandwidth_usage_mbps=p2p_data.get("bandwidth_usage_mbps", 0.0)
        )

        return APIResponse(data=response)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving P2P metrics: {str(e)}")


@router.get("/aggregated", response_model=APIResponse)
async def get_aggregated_metrics(
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get aggregated metrics for dashboard overview."""
    try:
        # Create cache key based on current time (5-minute windows)
        cache_timestamp = int(time.time() // 300) * 300  # 5-minute intervals
        cache_key = f"aggregated_{cache_timestamp}"

        # Try to get from cache first
        cached_data = _cached_aggregated_metrics(cache_key, cache_timestamp)
        if cached_data:
            return APIResponse(data=AggregatedMetricsResponse(**cached_data))

        # Calculate fresh metrics
        node_metrics = await node_service.get_aggregated_node_metrics(db)
        session_metrics = await session_service.get_aggregated_session_metrics(db)
        p2p_metrics = await p2p_network.get_network_metrics()
        health_metrics = await system_monitor.get_health_status()

        # Calculate performance indicators
        performance_indicators = {
            "total_active_nodes": node_metrics.get("active_count", 0),
            "total_sessions_completed": session_metrics.get("completed_count", 0),
            "avg_network_latency": p2p_metrics.get("avg_latency_ms", 0),
            "system_load": health_metrics.get("cpu_usage", 0),
            "federation_efficiency": session_metrics.get("avg_completion_rate", 0.0)
        }

        response_data = AggregatedMetricsResponse(
            node_metrics=node_metrics,
            session_metrics=session_metrics,
            p2p_metrics=p2p_metrics,
            system_health=health_metrics,
            performance_indicators=performance_indicators
        )

        # Cache the result in background
        background_tasks.add_task(_cached_aggregated_metrics, cache_key, cache_timestamp, response_data.dict())

        return APIResponse(data=response_data)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving aggregated metrics: {str(e)}")


@router.get("/historical/{metric_type}", response_model=APIResponse)
async def get_historical_metrics(
    metric_type: str,
    time_range: str = Query("24h", description="Time range: 1h, 24h, 7d, 30d"),
    aggregation: str = Query("avg", description="Aggregation: avg, sum, max, min"),
    granularity: str = Query("5m", description="Granularity: 1m, 5m, 1h, 1d"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get historical metrics data."""
    try:
        # Validate metric_type
        valid_metric_types = [
            "cpu_usage", "memory_usage", "disk_usage", "network_latency",
            "active_nodes", "active_sessions", "training_accuracy", "rewards_distributed"
        ]
        if metric_type not in valid_metric_types:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid metric_type. Must be one of: {valid_metric_types}"
            )

        # Validate parameters
        valid_ranges = ["1h", "24h", "7d", "30d"]
        valid_aggregations = ["avg", "sum", "max", "min"]
        valid_granularities = ["1m", "5m", "1h", "1d"]

        if time_range not in valid_ranges:
            raise HTTPException(status_code=400, detail=f"Invalid time_range. Must be one of: {valid_ranges}")
        if aggregation not in valid_aggregations:
            raise HTTPException(status_code=400, detail=f"Invalid aggregation. Must be one of: {valid_aggregations}")
        if granularity not in valid_granularities:
            raise HTTPException(status_code=400, detail=f"Invalid granularity. Must be one of: {valid_granularities}")

        # Validate granularity vs time_range compatibility
        if time_range == "1h" and granularity in ["1h", "1d"]:
            raise HTTPException(status_code=400, detail="Granularity too large for 1h time range")
        if time_range == "24h" and granularity == "1d":
            raise HTTPException(status_code=400, detail="Granularity too large for 24h time range")

        # Try cache first
        cache_key = f"{metric_type}_{time_range}_{aggregation}_{granularity}"
        cached_data = _cached_historical_metrics(cache_key, time_range, aggregation)
        if cached_data:
            response = HistoricalMetricsResponse(
                metric_type=metric_type,
                time_range=time_range,
                data_points=cached_data,
                aggregation_type=aggregation,
                total_data_points=len(cached_data)
            )
            return APIResponse(data=response)

        # Get historical data from service
        historical_data = await system_monitor.get_historical_metrics(
            metric_type=metric_type,
            time_range=time_range,
            aggregation=aggregation,
            granularity=granularity
        )

        response = HistoricalMetricsResponse(
            metric_type=metric_type,
            time_range=time_range,
            data_points=historical_data,
            aggregation_type=aggregation,
            total_data_points=len(historical_data)
        )

        return APIResponse(data=response)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving historical metrics: {str(e)}")


@router.get("/realtime/snapshot", response_model=APIResponse)
async def get_realtime_snapshot(
    include_details: bool = Query(False, description="Include detailed metrics"),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get real-time snapshot of all metrics."""
    try:
        # Rate limiting check - prevent too frequent requests
        # This would be implemented with a proper rate limiter in production

        # Gather all metrics concurrently with timeout
        tasks = [
            asyncio.wait_for(node_service.get_realtime_node_metrics(db), timeout=5.0),
            asyncio.wait_for(session_service.get_realtime_session_metrics(db), timeout=5.0),
            asyncio.wait_for(p2p_network.get_realtime_network_metrics(), timeout=5.0),
            asyncio.wait_for(system_monitor.get_realtime_system_metrics(), timeout=5.0)
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Handle exceptions and validate data
        node_data, session_data, p2p_data, system_data = results
        validated_results = []

        for i, result in enumerate(results):
            if isinstance(result, Exception):
                print(f"Error in realtime metric {i}: {result}")
                validated_results.append({})  # Use empty dict as fallback
            elif isinstance(result, dict):
                validated_results.append(result)
            else:
                validated_results.append({})  # Invalid data type

        node_data, session_data, p2p_data, system_data = validated_results

        # Combine into response
        snapshot = {
            "timestamp": datetime.utcnow(),
            "node_metrics": node_data,
            "session_metrics": session_data,
            "p2p_metrics": p2p_data,
            "system_metrics": system_data
        }

        if include_details:
            # Add detailed breakdowns with timeout protection
            try:
                detailed_tasks = [
                    asyncio.wait_for(node_service.get_detailed_node_metrics(db), timeout=10.0),
                    asyncio.wait_for(session_service.get_detailed_session_metrics(db), timeout=10.0)
                ]
                detailed_results = await asyncio.gather(*detailed_tasks, return_exceptions=True)

                for i, result in enumerate(detailed_results):
                    if isinstance(result, Exception):
                        print(f"Error in detailed metric {i}: {result}")
                        detailed_results[i] = []
                    elif not isinstance(result, list):
                        detailed_results[i] = []

                snapshot["detailed_node_metrics"] = detailed_results[0]
                snapshot["detailed_session_metrics"] = detailed_results[1]
            except Exception as e:
                print(f"Error getting detailed metrics: {e}")
                snapshot["detailed_node_metrics"] = []
                snapshot["detailed_session_metrics"] = []

        return APIResponse(data=snapshot)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving realtime snapshot: {str(e)}")


@router.post("/cache/clear", response_model=APIResponse)
async def clear_metrics_cache(
    cache_type: str = Query("all", description="Cache type to clear: all, aggregated, historical"),
    current_user: dict = Depends(require_admin)
):
    """Clear metrics cache (admin only)."""
    try:
        if cache_type in ["all", "aggregated"]:
            _cached_aggregated_metrics.cache_clear()

        if cache_type in ["all", "historical"]:
            _cached_historical_metrics.cache_clear()

        return APIResponse(message=f"Cache cleared successfully for type: {cache_type}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error clearing cache: {str(e)}")


@router.get("/performance/kpis", response_model=APIResponse)
async def get_performance_kpis(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get key performance indicators."""
    try:
        # Calculate KPIs
        kpis = await system_monitor.calculate_kpis(db)

        return APIResponse(data=kpis)

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving KPIs: {str(e)}")