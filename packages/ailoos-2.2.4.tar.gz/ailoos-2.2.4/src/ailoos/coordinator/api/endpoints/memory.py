"""
Memory API endpoints.
Provides REST endpoints for managing conversational memory of EmpoorioLM, including statistics, listing items, adding new items, deleting specific items, and clearing all memory.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

from fastapi import APIRouter, HTTPException, Depends, Query
from pydantic import BaseModel, Field, validator
from sqlalchemy.orm import Session

from ...database.connection import get_db
from ...auth.jwt import get_current_user
from ....memory.service import MemoryService
from ....settings.service import SettingsService

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class MemoryItemRequest(BaseModel):
    """Request model for creating memory items."""
    content: str = Field(..., description="Memory content", min_length=1, max_length=10000)
    importance: float = Field(1.0, description="Importance level (0.0-1.0)", ge=0.0, le=1.0)
    category: str = Field("general", description="Memory category")
    tags: Optional[List[str]] = Field(None, description="List of tags")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")

    @validator('category')
    def validate_category(cls, v):
        valid_categories = ["general", "personal", "factual", "emotional", "contextual"]
        if v not in valid_categories:
            raise ValueError(f'category must be one of: {valid_categories}')
        return v


class MemoryItemResponse(BaseModel):
    """Response model for memory items."""
    id: str
    user_id: int
    content: str
    importance: float
    timestamp: datetime
    category: str
    tags: List[str]
    metadata: Dict[str, Any]
    compressed: bool
    original_length: int
    access_count: int
    last_accessed: Optional[datetime]


class MemoryStatsResponse(BaseModel):
    """Response model for memory statistics."""
    user_id: int
    total_items: int
    compressed_items: int
    average_importance: float
    oldest_item: Optional[datetime]
    newest_item: Optional[datetime]
    categories_count: Dict[str, int]
    total_access_count: int


class MemoryUsageSummaryResponse(BaseModel):
    """Response model for memory usage summary."""
    user_id: int
    current_usage: int
    max_capacity: int
    usage_percentage: float
    compressed_items: int
    compression_rate: float
    average_importance: float
    categories: Dict[str, int]
    total_access_count: int
    memory_health: str


class MemoryCleanupResponse(BaseModel):
    """Response model for memory cleanup operations."""
    initial_count: int
    compressed: int
    deleted: int
    final_count: int


# Helper functions
def get_user_id_from_token(current_user: Dict) -> int:
    """Extract user ID from JWT token payload."""
    try:
        # Assuming user_id is stored in token sub field as integer
        return int(current_user.get('sub', '').split('_')[-1])
    except (ValueError, IndexError):
        raise HTTPException(status_code=400, detail="Invalid user ID in token")


def memory_item_to_response(item) -> MemoryItemResponse:
    """Convert MemoryItem to response model."""
    return MemoryItemResponse(**item.to_dict())


def memory_stats_to_response(stats) -> MemoryStatsResponse:
    """Convert MemoryStats to response model."""
    return MemoryStatsResponse(**stats.to_dict())


# API Endpoints
@router.get("/stats", response_model=MemoryUsageSummaryResponse,
            summary="Obtener estadísticas de uso de memoria",
            description="""
            Obtiene un resumen completo del uso de memoria conversacional del usuario actual.

            **Incluye:**
            - Uso actual vs capacidad máxima
            - Porcentaje de uso
            - Estadísticas de compresión
            - Distribución por categorías
            - Estado de salud de la memoria

            **Códigos de respuesta:**
            - 200: Estadísticas obtenidas exitosamente
            - 401: Usuario no autenticado
            - 404: Usuario no encontrado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Estadísticas de memoria obtenidas exitosamente",
                    "content": {
                        "application/json": {
                            "example": {
                                "user_id": 1,
                                "current_usage": 45,
                                "max_capacity": 256,
                                "usage_percentage": 17.6,
                                "compressed_items": 5,
                                "compression_rate": 11.1,
                                "average_importance": 0.75,
                                "categories": {"general": 20, "personal": 15, "factual": 10},
                                "total_access_count": 150,
                                "memory_health": "healthy"
                            }
                        }
                    }
                }
            })
async def get_memory_stats(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current user's memory usage statistics.

    - Returns comprehensive memory usage summary
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize services
        settings_service = SettingsService()
        memory_service = MemoryService(settings_service=settings_service)

        # Get memory usage summary
        summary = memory_service.get_memory_usage_summary(user_id)

        return MemoryUsageSummaryResponse(**summary)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get memory stats error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/items", response_model=List[MemoryItemResponse],
            summary="Listar ítems de memoria con filtros",
            description="""
            Lista ítems de memoria conversacional del usuario actual con filtros opcionales.

            **Filtros disponibles:**
            - category: Filtrar por categoría ("general", "personal", "factual", "emotional", "contextual")
            - min_importance: Importancia mínima (0.0-1.0)
            - max_importance: Importancia máxima (0.0-1.0)
            - tags: Lista de etiquetas (separadas por coma)
            - since: Fecha desde (ISO 8601)
            - until: Fecha hasta (ISO 8601)
            - limit: Número máximo de resultados (1-1000, default: 50)
            - include_compressed: Incluir ítems comprimidos (default: true)
            - sort_by: Campo de ordenamiento ("importance", "timestamp", "access_count")
            - sort_order: Orden ("asc", "desc")

            **Códigos de respuesta:**
            - 200: Ítems listados exitosamente
            - 400: Parámetros inválidos
            - 401: Usuario no autenticado
            - 500: Error interno del servidor
            """,
            responses={
                200: {
                    "description": "Ítems de memoria listados exitosamente",
                    "content": {
                        "application/json": {
                            "example": [
                                {
                                    "id": "abc12345",
                                    "user_id": 1,
                                    "content": "El usuario prefiere respuestas en español",
                                    "importance": 0.9,
                                    "timestamp": "2023-11-10T23:34:24.032Z",
                                    "category": "personal",
                                    "tags": ["preferencia", "idioma"],
                                    "metadata": {},
                                    "compressed": False,
                                    "original_length": 0,
                                    "access_count": 5,
                                    "last_accessed": "2023-11-10T23:35:00.000Z"
                                }
                            ]
                        }
                    }
                }
            })
async def list_memory_items(
    category: Optional[str] = Query(None, description="Filter by category"),
    min_importance: Optional[float] = Query(None, description="Minimum importance (0.0-1.0)", ge=0.0, le=1.0),
    max_importance: Optional[float] = Query(None, description="Maximum importance (0.0-1.0)", ge=0.0, le=1.0),
    tags: Optional[str] = Query(None, description="Comma-separated list of tags"),
    since: Optional[datetime] = Query(None, description="Start date (ISO 8601)"),
    until: Optional[datetime] = Query(None, description="End date (ISO 8601)"),
    limit: int = Query(50, description="Maximum number of results", ge=1, le=1000),
    include_compressed: bool = Query(True, description="Include compressed items"),
    sort_by: str = Query("importance", description="Sort field"),
    sort_order: str = Query("desc", description="Sort order"),
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    List memory items with optional filters.

    - Supports advanced filtering and sorting
    - Requires authentication
    """
    try:
        # Validate sort_by
        valid_sort_fields = ["importance", "timestamp", "access_count"]
        if sort_by not in valid_sort_fields:
            raise HTTPException(status_code=400, detail=f"sort_by must be one of: {valid_sort_fields}")

        # Validate sort_order
        if sort_order not in ["asc", "desc"]:
            raise HTTPException(status_code=400, detail="sort_order must be 'asc' or 'desc'")

        # Parse tags
        tags_list = None
        if tags:
            tags_list = [tag.strip() for tag in tags.split(",") if tag.strip()]

        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize services
        settings_service = SettingsService()
        memory_service = MemoryService(settings_service=settings_service)

        # Query memory items
        items = memory_service.query_memory(
            user_id=user_id,
            category=category,
            min_importance=min_importance,
            max_importance=max_importance,
            tags=tags_list,
            since=since,
            until=until,
            limit=limit,
            include_compressed=include_compressed,
            sort_by=sort_by,
            sort_order=sort_order
        )

        # Convert to response models
        response_items = [memory_item_to_response(item) for item in items]

        return response_items

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"List memory items error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/items", response_model=MemoryItemResponse,
             summary="Añadir nuevo ítem de memoria",
             description="""
             Añade un nuevo ítem a la memoria conversacional del usuario actual.

             **Campos requeridos:**
             - content: Contenido de la memoria (1-10000 caracteres)

             **Campos opcionales:**
             - importance: Nivel de importancia (0.0-1.0, default: 1.0)
             - category: Categoría ("general", "personal", "factual", "emotional", "contextual", default: "general")
             - tags: Lista de etiquetas
             - metadata: Metadatos adicionales

             **Códigos de respuesta:**
             - 201: Ítem creado exitosamente
             - 400: Datos inválidos
             - 401: Usuario no autenticado
             - 409: Límite de memoria excedido
             - 500: Error interno del servidor
             """,
             status_code=201,
             responses={
                 201: {
                     "description": "Ítem de memoria creado exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "id": "def67890",
                                 "user_id": 1,
                                 "content": "Nueva información importante sobre el usuario",
                                 "importance": 0.8,
                                 "timestamp": "2023-11-10T23:34:24.032Z",
                                 "category": "personal",
                                 "tags": ["nuevo", "importante"],
                                 "metadata": {"source": "conversation"},
                                 "compressed": False,
                                 "original_length": 0,
                                 "access_count": 0,
                                 "last_accessed": None
                             }
                         }
                     }
                 },
                 409: {
                     "description": "Límite de memoria excedido",
                     "content": {
                         "application/json": {
                             "example": {"detail": "Memory limit exceeded (256 items). Cannot add new item."}
                         }
                     }
                 }
             })
async def create_memory_item(
    request: MemoryItemRequest,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Create a new memory item.

    - Adds new conversational memory item
    - Automatically manages memory limits
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize services
        settings_service = SettingsService()
        memory_service = MemoryService(settings_service=settings_service)

        # Create memory item
        item = memory_service.add_memory_item(
            user_id=user_id,
            content=request.content,
            importance=request.importance,
            category=request.category,
            tags=request.tags,
            metadata=request.metadata
        )

        # Convert to response model
        response_item = memory_item_to_response(item)

        logger.info(f"Memory item created for user ID: {user_id}, item ID: {item.id}")
        return response_item

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Create memory item error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/items/{item_id}", response_model=Dict[str, str],
               summary="Eliminar ítem específico de memoria",
               description="""
               Elimina un ítem específico de la memoria conversacional del usuario actual.

               **Parámetros de ruta:**
               - item_id: ID del ítem de memoria a eliminar

               **Códigos de respuesta:**
               - 200: Ítem eliminado exitosamente
               - 401: Usuario no autenticado
               - 404: Ítem no encontrado
               - 500: Error interno del servidor
               """,
               responses={
                   200: {
                       "description": "Ítem de memoria eliminado exitosamente",
                       "content": {
                           "application/json": {
                               "example": {"message": "Memory item deleted successfully"}
                           }
                       }
                   },
                   404: {
                       "description": "Ítem no encontrado",
                       "content": {
                           "application/json": {
                               "example": {"detail": "Memory item not found"}
                           }
                       }
                   }
               })
async def delete_memory_item(
    item_id: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Delete a specific memory item.

    - Removes memory item by ID
    - Requires authentication and ownership
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize services
        settings_service = SettingsService()
        memory_service = MemoryService(settings_service=settings_service)

        # Delete memory item
        success = memory_service.delete_memory_item(item_id, user_id)

        if not success:
            raise HTTPException(status_code=404, detail="Memory item not found")

        logger.info(f"Memory item deleted: {item_id} for user ID: {user_id}")
        return {"message": "Memory item deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete memory item error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/items", response_model=MemoryCleanupResponse,
               summary="Limpiar toda la memoria conversacional",
               description="""
               Elimina todos los ítems de memoria conversacional del usuario actual.

               **Advertencia:** Esta operación no se puede deshacer.

               **Códigos de respuesta:**
               - 200: Memoria limpiada exitosamente
               - 401: Usuario no autenticado
               - 500: Error interno del servidor
               """,
               responses={
                   200: {
                       "description": "Memoria limpiada exitosamente",
                       "content": {
                           "application/json": {
                               "example": {
                                   "initial_count": 45,
                                   "compressed": 0,
                                   "deleted": 45,
                                   "final_count": 0
                               }
                           }
                       }
                   }
               })
async def clear_all_memory(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Clear all conversational memory for current user.

    - Removes all memory items
    - This operation cannot be undone
    - Requires authentication
    """
    try:
        # Get user ID from token
        user_id = get_user_id_from_token(current_user)

        # Initialize services
        settings_service = SettingsService()
        memory_service = MemoryService(settings_service=settings_service)

        # Clear all memory (force cleanup with aggressive deletion)
        result = memory_service.force_memory_cleanup(user_id)

        # Adjust result format for response
        cleanup_result = MemoryCleanupResponse(
            initial_count=result['initial_count'],
            compressed=result['compressed'],
            deleted=result['deleted'],
            final_count=result['final_count']
        )

        logger.info(f"All memory cleared for user ID: {user_id}, deleted {result['deleted']} items")
        return cleanup_result

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Clear all memory error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")