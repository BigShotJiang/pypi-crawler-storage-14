"""
User Management API endpoints.
Provides complete user registration, authentication, and profile management.
"""

import re
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Tuple, List
import logging

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr, Field, validator
import bcrypt
import jwt

from ...database.connection import get_db
from ...models.base import User, RefreshToken, RevokedToken, AuditLog, OAuthProvider, OAuthToken, EmailVerificationToken, PasswordResetToken
from ...config.settings import settings
from ...auth.jwt import get_current_user, create_user_token, verify_token, revoke_token, create_refresh_token
# from ...auth.permissions import require_permissions  # Commented out - function not defined

logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


# Pydantic models for request/response
class UserRegistrationRequest(BaseModel):
    """User registration request model."""
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)
    full_name: Optional[str] = Field(None, max_length=255)

    @validator('username')
    def username_alphanumeric(cls, v):
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Username must contain only letters, numbers, underscores, and hyphens')
        return v

    @validator('password')
    def password_strength(cls, v):
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one digit')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character')
        return v


class UserLoginRequest(BaseModel):
    """User login request model."""
    username_or_email: str = Field(..., min_length=1)
    password: str = Field(..., min_length=1)


class TokenResponse(BaseModel):
    """Token response model."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: Dict[str, Any]


class UserProfileResponse(BaseModel):
    """User profile response model."""
    id: str
    username: str
    email: str
    full_name: Optional[str]
    role: str
    is_active: bool
    is_verified: bool
    last_login_at: Optional[datetime]
    created_at: datetime
    updated_at: datetime

    # Extended profile fields
    avatar_url: Optional[str]
    bio: Optional[str]
    website: Optional[str]
    location: Optional[str]
    timezone: Optional[str]
    language: str = "es"

    # Usage statistics
    total_sessions_participated: int = 0
    total_contributions_made: int = 0
    total_rewards_earned: float = 0.0
    reputation_score: float = 0.0
    trust_level: str = "basic"
    last_activity_at: Optional[datetime]
    api_calls_count: int = 0
    storage_used_bytes: int = 0
    models_created_count: int = 0

    # OAuth connections
    oauth_providers: Optional[Dict[str, bool]] = None


class PasswordChangeRequest(BaseModel):
    """Password change request model."""
    current_password: str
    new_password: str = Field(..., min_length=8, max_length=128)

    @validator('new_password')
    def password_strength(cls, v):
        if not re.search(r'[A-Z]', v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not re.search(r'\d', v):
            raise ValueError('Password must contain at least one digit')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Password must contain at least one special character')
        return v


class UserUpdateRequest(BaseModel):
    """User update request model."""
    full_name: Optional[str] = Field(None, max_length=255)
    preferences: Optional[Dict[str, Any]] = None
    avatar_url: Optional[str] = Field(None, max_length=500)
    bio: Optional[str] = Field(None, max_length=1000)
    website: Optional[str] = Field(None, max_length=255)
    location: Optional[str] = Field(None, max_length=255)
    timezone: Optional[str] = Field(None, max_length=50)
    language: Optional[str] = Field(None, max_length=10)


class UserStatsResponse(BaseModel):
    """User statistics response model."""
    total_sessions_participated: int
    total_contributions_made: int
    total_rewards_earned: float
    reputation_score: float
    trust_level: str
    last_activity_at: Optional[datetime]
    api_calls_count: int
    storage_used_bytes: int
    models_created_count: int
    account_age_days: int
    average_session_duration: Optional[float]
    contribution_success_rate: float


class OAuthCallbackRequest(BaseModel):
    """OAuth callback request model."""
    code: str
    state: Optional[str] = None
    provider: str = Field(..., pattern=r'^(github|google|metamask)$')


class OAuthProviderResponse(BaseModel):
    """OAuth provider response model."""
    name: str
    is_connected: bool
    connected_at: Optional[datetime]
    profile_url: Optional[str]


# Helper functions
def hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash."""
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))


def create_user_tokens(user: User, db: Session) -> Tuple[str, str]:
    """Create access and refresh tokens for a user."""
    # Create access token
    permissions = ["user:read", "user:profile"]
    if user.role == "admin":
        permissions.extend(["admin:read", "admin:write"])

    access_token = create_user_token(
        user_id=user.id,
        permissions=permissions
    )

    # Create refresh token
    refresh_token, refresh_jti = create_refresh_token(
        subject=user.id,
        token_type="user",
        db=db
    )

    return access_token, refresh_token


def log_user_action(db: Session, user_id: str, action: str, entity_type: str = "user",
                   entity_id: str = None, old_values: Dict = None, new_values: Dict = None,
                   ip_address: str = None, user_agent: str = None):
    """Log user actions for audit purposes."""
    audit_log = AuditLog(
        entity_type=entity_type,
        entity_id=entity_id or user_id,
        action=action,
        user_id=user_id,
        old_values=old_values,
        new_values=new_values,
        ip_address=ip_address,
        user_agent=user_agent
    )
    db.add(audit_log)
    db.commit()

async def send_verification_email(email: str, user_id: str, db: Session = None):
    """
    Send a verification email to the user.
    Generates a verification token, stores it in DB, and sends email.
    """
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    import secrets

    try:
        # Generate verification token
        verification_token = secrets.token_urlsafe(32)

        # Store token in DB with expiry (24 hours)
        if db:
            token_record = EmailVerificationToken(
                token=verification_token,
                user_id=user_id,
                email=email,
                expires_at=datetime.utcnow() + timedelta(hours=24)
            )
            db.add(token_record)
            db.commit()

        # Construct verification URL
        base_url = "https://app.ailoos.com"  # Should come from config
        verification_link = f"{base_url}/verify-email?token={verification_token}"

        # SMTP configuration (should come from config)
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        smtp_username = "noreply@ailoos.com"
        smtp_password = "password"  # Should come from environment variables

        # Create message
        msg = MIMEMultipart()
        msg['From'] = smtp_username
        msg['To'] = email
        msg['Subject'] = "Verificación de cuenta AILOOS"

        body = f"""
        ¡Bienvenido a AILOOS!

        Para verificar tu cuenta, haz clic en el siguiente enlace:
        {verification_link}

        Este enlace expirará en 24 horas.

        Si no solicitaste esta verificación, ignora este mensaje.

        Saludos,
        El equipo de AILOOS
        """

        msg.attach(MIMEText(body, 'plain'))

        # Send email
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password)
        text = msg.as_string()
        server.sendmail(smtp_username, email, text)
        server.quit()

        logger.info(f"📧 Verification email sent to {email} for user {user_id}")

    except Exception as e:
        logger.error(f"Failed to send verification email to {email}: {e}")
        # In production, we might implement a retry system or queue
        raise HTTPException(status_code=500, detail="Failed to send verification email")


async def send_password_reset_email(email: str, user_id: str, db: Session = None):
    """
    Send a password reset email to the user.
    """
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    import secrets

    try:
        # Generate reset token
        reset_token = secrets.token_urlsafe(32)

        # Store token in DB with expiry (1 hour)
        if db:
            token_record = PasswordResetToken(
                token=reset_token,
                user_id=user_id,
                email=email,
                expires_at=datetime.utcnow() + timedelta(hours=1)
            )
            db.add(token_record)
            db.commit()

        # Construct reset URL
        base_url = "https://app.ailoos.com"
        reset_link = f"{base_url}/reset-password?token={reset_token}"

        # SMTP configuration
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        smtp_username = "noreply@ailoos.com"
        smtp_password = "password"

        # Create message
        msg = MIMEMultipart()
        msg['From'] = smtp_username
        msg['To'] = email
        msg['Subject'] = "Restablecer contraseña AILOOS"

        body = f"""
        Restablecer contraseña

        Haz clic en el siguiente enlace para restablecer tu contraseña:
        {reset_link}

        Este enlace expirará en 1 hora.

        Si no solicitaste este restablecimiento, ignora este mensaje.

        Saludos,
        El equipo de AILOOS
        """

        msg.attach(MIMEText(body, 'plain'))

        # Send email
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password)
        text = msg.as_string()
        server.sendmail(smtp_username, email, text)
        server.quit()

        logger.info(f"📧 Password reset email sent to {email} for user {user_id}")

    except Exception as e:
        logger.error(f"Failed to send password reset email to {email}: {e}")
        raise HTTPException(status_code=500, detail="Failed to send password reset email")


def get_oauth_provider_config(provider: str, db: Session) -> OAuthProvider:
    """Get OAuth provider configuration."""
    oauth_provider = db.query(OAuthProvider).filter(
        OAuthProvider.name == provider,
        OAuthProvider.is_active == True
    ).first()

    if not oauth_provider:
        raise HTTPException(status_code=400, detail=f"OAuth provider {provider} not configured")

    return oauth_provider


async def exchange_oauth_code(provider: str, code: str, db: Session) -> Dict[str, Any]:
    """Exchange OAuth authorization code for access token."""
    import aiohttp

    oauth_config = get_oauth_provider_config(provider, db)

    token_data = {
        'client_id': oauth_config.client_id,
        'client_secret': oauth_config.client_secret,
        'code': code,
        'grant_type': 'authorization_code',
        'redirect_uri': f"https://app.ailoos.com/auth/{provider}/callback"
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(oauth_config.token_url, data=token_data) as response:
            if response.status != 200:
                raise HTTPException(status_code=400, detail="Failed to exchange OAuth code")

            token_response = await response.json()

    return token_response


async def get_oauth_user_info(provider: str, access_token: str, wallet_address: Optional[str] = None) -> Dict[str, Any]:
    """Get user information from OAuth provider."""
    import aiohttp

    if provider == 'metamask':
        # For MetaMask, we use the wallet address directly
        if not wallet_address:
            raise HTTPException(status_code=400, detail="Wallet address required for MetaMask")
        return {
            'id': wallet_address,
            'login': wallet_address[:10] + '...',  # Shortened address
            'name': f'Wallet {wallet_address[:6]}...{wallet_address[-4:]}',
            'email': None,  # Wallets don't have emails
            'avatar_url': None,
            'html_url': f'https://etherscan.io/address/{wallet_address}'
        }

    urls = {
        'github': 'https://api.github.com/user',
        'google': 'https://www.googleapis.com/oauth2/v2/userinfo'
    }

    if provider not in urls:
        raise HTTPException(status_code=400, detail=f"Unsupported OAuth provider: {provider}")

    headers = {'Authorization': f'Bearer {access_token}'}

    async with aiohttp.ClientSession() as session:
        async with session.get(urls[provider], headers=headers) as response:
            if response.status != 200:
                raise HTTPException(status_code=400, detail="Failed to get user info from OAuth provider")

            user_info = await response.json()

    return user_info


# API Endpoints

@router.get("/oauth/{provider}/url", response_model=Dict[str, str])
async def get_oauth_url(provider: str, db: Session = Depends(get_db)):
    """
    Get OAuth authorization URL for the specified provider.

    - Generates authorization URL for GitHub, Google, or MetaMask
    - Returns URL that frontend can redirect user to
    """
    try:
        oauth_config = get_oauth_provider_config(provider, db)

        if provider == 'metamask':
            # MetaMask doesn't use traditional OAuth flow
            return {
                "url": "metamask://",  # Frontend handles MetaMask connection
                "provider": provider
            }

        import secrets
        state = secrets.token_urlsafe(32)

        params = {
            'client_id': oauth_config.client_id,
            'redirect_uri': f"https://app.ailoos.com/auth/{provider}/callback",
            'scope': oauth_config.scope,
            'state': state,
            'response_type': 'code'
        }

        if provider == 'google':
            params['access_type'] = 'offline'
            params['prompt'] = 'consent'

        from urllib.parse import urlencode
        query_string = urlencode(params)
        auth_url = f"{oauth_config.authorization_url}?{query_string}"

        return {
            "url": auth_url,
            "provider": provider,
            "state": state
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get OAuth URL error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/oauth/{provider}/callback", response_model=TokenResponse)
async def oauth_callback(
    request: OAuthCallbackRequest,
    db: Session = Depends(get_db)
):
    """
    Handle OAuth callback and create/update user account.

    - Exchanges authorization code for access token
    - Gets user info from OAuth provider
    - Creates or updates user account
    - Returns authentication tokens
    """
    try:
        # Exchange code for token
        token_response = await exchange_oauth_code(request.provider, request.code, db)

        # Get user info
        user_info = await get_oauth_user_info(
            request.provider,
            token_response.get('access_token'),
            wallet_address=request.state if request.provider == 'metamask' else None
        )

        # Find or create user
        provider_user_id = user_info['id']
        oauth_token = db.query(OAuthToken).filter(
            OAuthToken.provider == request.provider,
            OAuthToken.provider_user_id == provider_user_id,
            OAuthToken.is_active == True
        ).first()

        if oauth_token:
            # Existing user
            user = oauth_token.user
        else:
            # Check if user exists by email (for GitHub/Google)
            user = None
            if user_info.get('email'):
                user = db.query(User).filter(User.email == user_info['email']).first()

            if not user:
                # Create new user
                user_id = f"user_{request.provider}_{provider_user_id}_{int(datetime.utcnow().timestamp())}"
                user = User(
                    id=user_id,
                    username=user_info.get('login') or f"{request.provider}_{provider_user_id[:8]}",
                    email=user_info.get('email'),
                    full_name=user_info.get('name'),
                    avatar_url=user_info.get('avatar_url'),
                    role="user",
                    is_active=True,
                    is_verified=True,  # OAuth users are pre-verified
                    **({f"{request.provider}_id": provider_user_id} if request.provider != 'metamask' else {'wallet_address': provider_user_id})
                )
                db.add(user)
                db.commit()
                db.refresh(user)

                # Log registration
                log_user_action(
                    db=db,
                    user_id=user.id,
                    action="oauth_register",
                    entity_type="user",
                    entity_id=user.id,
                    new_values={"provider": request.provider, "provider_user_id": provider_user_id}
                )

        # Create/update OAuth token
        if oauth_token:
            oauth_token.access_token = token_response.get('access_token')
            oauth_token.refresh_token = token_response.get('refresh_token')
            oauth_token.expires_at = datetime.utcnow() + timedelta(seconds=token_response.get('expires_in', 3600))
            oauth_token.updated_at = datetime.utcnow()
        else:
            oauth_token = OAuthToken(
                user_id=user.id,
                provider=request.provider,
                provider_user_id=provider_user_id,
                access_token=token_response.get('access_token'),
                refresh_token=token_response.get('refresh_token'),
                expires_at=datetime.utcnow() + timedelta(seconds=token_response.get('expires_in', 3600)),
                scope=token_response.get('scope')
            )
            db.add(oauth_token)

        db.commit()

        # Create session tokens
        access_token, refresh_token = create_user_tokens(user, db)

        # Update last login
        user.last_login_at = datetime.utcnow()
        user.last_activity_at = datetime.utcnow()
        db.commit()

        # Log login
        log_user_action(
            db=db,
            user_id=user.id,
            action="oauth_login",
            entity_type="user",
            entity_id=user.id
        )

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=settings.auth.jwt_expiration_hours * 3600,
            user={
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role,
                "is_verified": user.is_verified
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"OAuth callback error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/oauth/providers", response_model=Dict[str, OAuthProviderResponse])
async def get_oauth_providers(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get available OAuth providers and user's connected accounts.

    - Returns list of configured OAuth providers
    - Shows which providers user has connected
    """
    try:
        # Get configured providers
        providers = db.query(OAuthProvider).filter(OAuthProvider.is_active == True).all()

        # Get user's OAuth connections
        user_oauth = db.query(OAuthToken).filter(
            OAuthToken.user_id == current_user.sub,
            OAuthToken.is_active == True
        ).all()

        connected_providers = {token.provider: token for token in user_oauth}

        result = {}
        for provider in providers:
            is_connected = provider.name in connected_providers
            token = connected_providers.get(provider.name)

            result[provider.name] = OAuthProviderResponse(
                name=provider.name,
                is_connected=is_connected,
                connected_at=token.created_at if token else None,
                profile_url=f"https://{provider.name}.com/{token.provider_user_id}" if token and provider.name == 'github' else None
            )

        return result

    except Exception as e:
        logger.error(f"Get OAuth providers error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/oauth/{provider}")
async def disconnect_oauth_provider(
    provider: str,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Disconnect OAuth provider from user account.

    - Removes OAuth token and connection
    - User can still login with other methods
    """
    try:
        oauth_token = db.query(OAuthToken).filter(
            OAuthToken.user_id == current_user.sub,
            OAuthToken.provider == provider,
            OAuthToken.is_active == True
        ).first()

        if not oauth_token:
            raise HTTPException(status_code=404, detail="OAuth provider not connected")

        oauth_token.is_active = False
        oauth_token.updated_at = datetime.utcnow()
        db.commit()

        # Log disconnection
        log_user_action(
            db=db,
            user_id=current_user.sub,
            action="oauth_disconnect",
            entity_type="user",
            entity_id=current_user.sub,
            old_values={"provider": provider}
        )

        return {"message": f"{provider.title()} disconnected successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Disconnect OAuth provider error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/stats", response_model=UserStatsResponse)
async def get_user_stats(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get comprehensive user statistics and usage data.

    - Returns detailed usage statistics
    - Includes participation metrics and performance data
    """
    try:
        user = db.query(User).filter(User.id == current_user.sub).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Calculate account age
        account_age_days = (datetime.utcnow() - user.created_at).days

        # Calculate contribution success rate (mock for now)
        contribution_success_rate = 0.95 if user.total_contributions_made > 0 else 0.0

        # Get average session duration (mock for now - would need session logs)
        average_session_duration = 3600.0  # 1 hour default

        return UserStatsResponse(
            total_sessions_participated=user.total_sessions_participated,
            total_contributions_made=user.total_contributions_made,
            total_rewards_earned=user.total_rewards_earned,
            reputation_score=user.reputation_score,
            trust_level=user.trust_level,
            last_activity_at=user.last_activity_at,
            api_calls_count=user.api_calls_count,
            storage_used_bytes=user.storage_used_bytes,
            models_created_count=user.models_created_count,
            account_age_days=account_age_days,
            average_session_duration=average_session_duration,
            contribution_success_rate=contribution_success_rate
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get user stats error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/verify-email")
async def verify_email(
    token: str,
    db: Session = Depends(get_db)
):
    """
    Verify user email address using verification token.

    - Validates token and marks email as verified
    - Token expires after 24 hours
    """
    try:
        # Find verification token
        verification_token = db.query(EmailVerificationToken).filter(
            EmailVerificationToken.token == token,
            EmailVerificationToken.is_used == False,
            EmailVerificationToken.expires_at > datetime.utcnow()
        ).first()

        if not verification_token:
            raise HTTPException(status_code=400, detail="Invalid or expired verification token")

        # Get user
        user = db.query(User).filter(User.id == verification_token.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Mark email as verified
        user.is_verified = True
        user.email_verified_at = datetime.utcnow()
        user.updated_at = datetime.utcnow()

        # Mark token as used
        verification_token.is_used = True

        db.commit()

        # Log verification
        log_user_action(
            db=db,
            user_id=user.id,
            action="email_verified",
            entity_type="user",
            entity_id=user.id
        )

        return {"message": "Email verified successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Email verification error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/resend-verification")
async def resend_verification_email(
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Resend email verification to current user.

    - Generates new verification token
    - Sends verification email
    """
    try:
        user = db.query(User).filter(User.id == current_user.sub).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        if user.is_verified:
            raise HTTPException(status_code=400, detail="Email already verified")

        # Send verification email
        background_tasks.add_task(send_verification_email, user.email, user.id, db)

        return {"message": "Verification email sent"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Resend verification error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/forgot-password")
async def forgot_password(
    email: str,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Initiate password reset process.

    - Generates reset token
    - Sends reset email
    - Token expires in 1 hour
    """
    try:
        user = db.query(User).filter(User.email == email).first()
        if not user:
            # Don't reveal if email exists or not for security
            return {"message": "If the email exists, a reset link has been sent"}

        # Send reset email
        background_tasks.add_task(send_password_reset_email, email, user.id, db)

        return {"message": "If the email exists, a reset link has been sent"}

    except Exception as e:
        logger.error(f"Forgot password error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/reset-password")
async def reset_password(
    token: str,
    new_password: str,
    db: Session = Depends(get_db)
):
    """
    Reset user password using reset token.

    - Validates token
    - Updates password
    - Revokes all existing refresh tokens
    """
    try:
        # Validate new password
        if not re.search(r'[A-Z]', new_password):
            raise HTTPException(status_code=400, detail='Password must contain at least one uppercase letter')
        if not re.search(r'[a-z]', new_password):
            raise HTTPException(status_code=400, detail='Password must contain at least one lowercase letter')
        if not re.search(r'\d', new_password):
            raise HTTPException(status_code=400, detail='Password must contain at least one digit')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', new_password):
            raise HTTPException(status_code=400, detail='Password must contain at least one special character')
        if len(new_password) < 8 or len(new_password) > 128:
            raise HTTPException(status_code=400, detail='Password must be between 8 and 128 characters')

        # Find reset token
        reset_token = db.query(PasswordResetToken).filter(
            PasswordResetToken.token == token,
            PasswordResetToken.is_used == False,
            PasswordResetToken.expires_at > datetime.utcnow()
        ).first()

        if not reset_token:
            raise HTTPException(status_code=400, detail="Invalid or expired reset token")

        # Get user
        user = db.query(User).filter(User.id == reset_token.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Update password
        user.password_hash = hash_password(new_password)
        user.updated_at = datetime.utcnow()

        # Mark token as used
        reset_token.is_used = True

        # Revoke all refresh tokens for security
        refresh_tokens = db.query(RefreshToken).filter(
            RefreshToken.user_id == user.id,
            RefreshToken.is_revoked == False
        ).all()

        for token in refresh_tokens:
            token.is_revoked = True
            revoke_token(token.token_jti, token.token_type, user.id, "password_reset", db)

        db.commit()

        # Log password reset
        log_user_action(
            db=db,
            user_id=user.id,
            action="password_reset",
            entity_type="user",
            entity_id=user.id
        )

        return {"message": "Password reset successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Reset password error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


# API Endpoints
@router.post("/register", response_model=Dict[str, Any],
             summary="Registrar nuevo usuario",
             description="""
             Crea una nueva cuenta de usuario en el sistema AILOOS.

             **Proceso:**
             - Valida los datos de entrada (username, email, contraseña)
             - Verifica que no existan usuarios duplicados
             - Crea la cuenta de usuario con estado inactivo
             - Envía email de verificación (tarea en segundo plano)

             **Requisitos de contraseña:**
             - Mínimo 8 caracteres
             - Al menos una letra mayúscula
             - Al menos una letra minúscula
             - Al menos un dígito
             - Al menos un carácter especial (!@#$%^&*(),.?":{}|<>)

             **Códigos de respuesta:**
             - 200: Usuario registrado exitosamente
             - 400: Datos inválidos o usuario ya existe
             - 500: Error interno del servidor
             """,
             responses={
                 200: {
                     "description": "Usuario registrado exitosamente",
                     "content": {
                         "application/json": {
                             "example": {
                                 "message": "User registered successfully",
                                 "user_id": "user_john_doe_1640995200",
                                 "requires_verification": True
                             }
                         }
                     }
                 },
                 400: {
                     "description": "Datos inválidos o usuario ya existe",
                     "content": {
                         "application/json": {
                             "example": {"detail": "Username already registered"}
                         }
                     }
                 }
             })
async def register_user(
    request: UserRegistrationRequest,
    background_tasks: BackgroundTasks,
    request_obj: Request,
    db: Session = Depends(get_db)
):
    """
    Register a new user account.

    - Validates input data
    - Checks for existing users
    - Creates user account
    - Sends verification email (background task)
    """
    try:
        # Check if username already exists
        existing_user = db.query(User).filter(
            (User.username == request.username) | (User.email == request.email)
        ).first()

        if existing_user:
            if existing_user.username == request.username:
                raise HTTPException(status_code=400, detail="Username already registered")
            else:
                raise HTTPException(status_code=400, detail="Email already registered")

        # Hash password
        password_hash = hash_password(request.password)

        # Create user
        user = User(
            id=f"user_{request.username}_{int(datetime.utcnow().timestamp())}",
            username=request.username,
            email=request.email,
            password_hash=password_hash,
            full_name=request.full_name,
            role="user",  # Default role
            is_active=True,
            is_verified=False
        )

        db.add(user)
        db.commit()
        db.refresh(user)

        # Log registration
        log_user_action(
            db=db,
            user_id=user.id,
            action="register",
            entity_type="user",
            entity_id=user.id,
            new_values={"username": user.username, "email": user.email},
            ip_address=request_obj.client.host,
            user_agent=request_obj.headers.get("user-agent")
        )

        # Send verification email (background task)
        background_tasks.add_task(send_verification_email, user.email, user.id, db)

        return {
            "message": "User registered successfully",
            "user_id": user.id,
            "requires_verification": True
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User registration error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/login", response_model=TokenResponse,
             summary="Iniciar sesión de usuario",
             description="""
             Autentica al usuario y devuelve tokens de acceso.

             **Proceso:**
             - Valida las credenciales (username/email + contraseña)
             - Verifica el estado de la cuenta (activa, no bloqueada)
             - Genera tokens JWT de acceso y refresh
             - Registra el login en el sistema de auditoría

             **Bloqueo de cuenta:**
             - Después de 5 intentos fallidos, la cuenta se bloquea por 30 minutos

             **Códigos de respuesta:**
             - 200: Login exitoso con tokens
             - 401: Credenciales inválidas o cuenta bloqueada/desactivada
             - 500: Error interno del servidor
             """,
             responses={
                 200: {
                     "description": "Login exitoso",
                     "content": {
                         "application/json": {
                             "example": {
                                 "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
                                 "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
                                 "token_type": "bearer",
                                 "expires_in": 3600,
                                 "user": {
                                     "id": "user_john_doe_1640995200",
                                     "username": "john_doe",
                                     "email": "john@example.com",
                                     "full_name": "John Doe",
                                     "role": "user",
                                     "is_verified": True
                                 }
                             }
                         }
                     }
                 },
                 401: {
                     "description": "Credenciales inválidas",
                     "content": {
                         "application/json": {
                             "example": {"detail": "Invalid credentials"}
                         }
                     }
                 }
             })
async def login_user(
    request: UserLoginRequest,
    request_obj: Request,
    db: Session = Depends(get_db)
):
    """
    Authenticate user and return access tokens.

    - Validates credentials
    - Checks account status
    - Returns access and refresh tokens
    """
    try:
        # Find user by username or email
        user = db.query(User).filter(
            (User.username == request.username_or_email) |
            (User.email == request.username_or_email)
        ).first()

        if not user:
            raise HTTPException(status_code=401, detail="Invalid credentials")

        # Check if account is active
        if not user.is_active:
            raise HTTPException(status_code=401, detail="Account is deactivated")

        # Check if account is locked
        if user.locked_until and datetime.utcnow() < user.locked_until:
            raise HTTPException(status_code=401, detail="Account is temporarily locked")

        # Verify password
        if not verify_password(request.password, user.password_hash):
            # Increment login attempts
            user.login_attempts += 1

            # Lock account after 5 failed attempts
            if user.login_attempts >= 5:
                user.locked_until = datetime.utcnow() + timedelta(minutes=30)

            db.commit()
            raise HTTPException(status_code=401, detail="Invalid credentials")

        # Reset login attempts on successful login
        user.login_attempts = 0
        user.last_login_at = datetime.utcnow()
        user.locked_until = None
        db.commit()

        # Create tokens
        access_token, refresh_token = create_user_tokens(user, db)

        # Log login
        log_user_action(
            db=db,
            user_id=user.id,
            action="login",
            entity_type="user",
            entity_id=user.id,
            ip_address=request_obj.client.host,
            user_agent=request_obj.headers.get("user-agent")
        )

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=settings.auth.jwt_expiration_hours * 3600,  # Convert to seconds
            user={
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role,
                "is_verified": user.is_verified
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"User login error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/refresh", response_model=TokenResponse)
async def refresh_access_token(
    refresh_token: str,
    db: Session = Depends(get_db)
):
    """
    Refresh access token using refresh token.

    - Validates refresh token
    - Creates new access token
    - Returns new token pair
    """
    try:
        # Verify refresh token
        token_data = verify_token(refresh_token, db)

        if token_data.type != "user":
            raise HTTPException(status_code=401, detail="Invalid token type")

        # Get user
        user = db.query(User).filter(User.id == token_data.sub).first()
        if not user or not user.is_active:
            raise HTTPException(status_code=401, detail="User not found or inactive")

        # Create new tokens
        access_token, new_refresh_token = create_user_tokens(user, db)

        return TokenResponse(
            access_token=access_token,
            refresh_token=new_refresh_token,
            token_type="bearer",
            expires_in=settings.auth.jwt_expiration_hours * 3600,
            user={
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role,
                "is_verified": user.is_verified
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Token refresh error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/logout")
async def logout_user(
    current_user: Dict = Depends(get_current_user),
    request_obj: Request = None,
    db: Session = Depends(get_db)
):
    """
    Logout user by revoking refresh tokens.

    - Revokes all refresh tokens for user
    - Logs logout action
    """
    try:
        # Revoke all refresh tokens for user
        refresh_tokens = db.query(RefreshToken).filter(
            RefreshToken.user_id == current_user.sub,
            RefreshToken.is_revoked == False
        ).all()

        for token in refresh_tokens:
            token.is_revoked = True
            revoke_token(token.token_jti, token.token_type, current_user.sub, "logout", db)

        db.commit()

        # Log logout
        log_user_action(
            db=db,
            user_id=current_user.sub,
            action="logout",
            entity_type="user",
            entity_id=current_user.sub,
            ip_address=getattr(request_obj.client, 'host', None) if request_obj else None,
            user_agent=request_obj.headers.get("user-agent") if request_obj else None
        )

        return {"message": "Logged out successfully"}

    except Exception as e:
        logger.error(f"User logout error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/profile", response_model=UserProfileResponse)
async def get_user_profile(
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get current user profile.

    - Returns complete user profile information including stats and OAuth connections
    - Requires authentication
    """
    try:
        user = db.query(User).filter(User.id == current_user.sub).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Get OAuth connections
        oauth_tokens = db.query(OAuthToken).filter(
            OAuthToken.user_id == user.id,
            OAuthToken.is_active == True
        ).all()

        oauth_providers = {}
        for token in oauth_tokens:
            oauth_providers[token.provider] = True

        # Calculate account age
        account_age_days = (datetime.utcnow() - user.created_at).days

        return UserProfileResponse(
            id=user.id,
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            role=user.role,
            is_active=user.is_active,
            is_verified=user.is_verified,
            last_login_at=user.last_login_at,
            created_at=user.created_at,
            updated_at=user.updated_at,
            avatar_url=user.avatar_url,
            bio=user.bio,
            website=user.website,
            location=user.location,
            timezone=user.timezone,
            language=user.language,
            total_sessions_participated=user.total_sessions_participated,
            total_contributions_made=user.total_contributions_made,
            total_rewards_earned=user.total_rewards_earned,
            reputation_score=user.reputation_score,
            trust_level=user.trust_level,
            last_activity_at=user.last_activity_at,
            api_calls_count=user.api_calls_count,
            storage_used_bytes=user.storage_used_bytes,
            models_created_count=user.models_created_count,
            oauth_providers=oauth_providers
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get user profile error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/profile", response_model=UserProfileResponse)
async def update_user_profile(
    request: UserUpdateRequest,
    current_user: Dict = Depends(get_current_user),
    request_obj: Request = None,
    db: Session = Depends(get_db)
):
    """
    Update current user profile.

    - Updates complete user profile information
    - Logs changes for audit
    """
    try:
        user = db.query(User).filter(User.id == current_user.sub).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Store old values for audit
        old_values = {
            "full_name": user.full_name,
            "preferences": user.preferences,
            "avatar_url": user.avatar_url,
            "bio": user.bio,
            "website": user.website,
            "location": user.location,
            "timezone": user.timezone,
            "language": user.language
        }

        # Update fields
        if request.full_name is not None:
            user.full_name = request.full_name
        if request.preferences is not None:
            user.preferences = request.preferences
        if request.avatar_url is not None:
            user.avatar_url = request.avatar_url
        if request.bio is not None:
            user.bio = request.bio
        if request.website is not None:
            user.website = request.website
        if request.location is not None:
            user.location = request.location
        if request.timezone is not None:
            user.timezone = request.timezone
        if request.language is not None:
            user.language = request.language

        user.updated_at = datetime.utcnow()
        user.last_activity_at = datetime.utcnow()
        db.commit()
        db.refresh(user)

        # Log update
        log_user_action(
            db=db,
            user_id=user.id,
            action="profile_update",
            entity_type="user",
            entity_id=user.id,
            old_values=old_values,
            new_values={
                "full_name": user.full_name,
                "preferences": user.preferences,
                "avatar_url": user.avatar_url,
                "bio": user.bio,
                "website": user.website,
                "location": user.location,
                "timezone": user.timezone,
                "language": user.language
            },
            ip_address=getattr(request_obj.client, 'host', None) if request_obj else None,
            user_agent=request_obj.headers.get("user-agent") if request_obj else None
        )

        # Get OAuth connections for response
        oauth_tokens = db.query(OAuthToken).filter(
            OAuthToken.user_id == user.id,
            OAuthToken.is_active == True
        ).all()

        oauth_providers = {}
        for token in oauth_tokens:
            oauth_providers[token.provider] = True

        return UserProfileResponse(
            id=user.id,
            username=user.username,
            email=user.email,
            full_name=user.full_name,
            role=user.role,
            is_active=user.is_active,
            is_verified=user.is_verified,
            last_login_at=user.last_login_at,
            created_at=user.created_at,
            updated_at=user.updated_at,
            avatar_url=user.avatar_url,
            bio=user.bio,
            website=user.website,
            location=user.location,
            timezone=user.timezone,
            language=user.language,
            total_sessions_participated=user.total_sessions_participated,
            total_contributions_made=user.total_contributions_made,
            total_rewards_earned=user.total_rewards_earned,
            reputation_score=user.reputation_score,
            trust_level=user.trust_level,
            last_activity_at=user.last_activity_at,
            api_calls_count=user.api_calls_count,
            storage_used_bytes=user.storage_used_bytes,
            models_created_count=user.models_created_count,
            oauth_providers=oauth_providers
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update user profile error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post("/change-password")
async def change_password(
    request: PasswordChangeRequest,
    current_user: Dict = Depends(get_current_user),
    request_obj: Request = None,
    db: Session = Depends(get_db)
):
    """
    Change user password.

    - Verifies current password
    - Updates password hash
    - Revokes all existing refresh tokens
    """
    try:
        user = db.query(User).filter(User.id == current_user.sub).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Verify current password
        if not verify_password(request.current_password, user.password_hash):
            raise HTTPException(status_code=400, detail="Current password is incorrect")

        # Hash new password
        new_password_hash = hash_password(request.new_password)

        # Update password
        user.password_hash = new_password_hash
        user.updated_at = datetime.utcnow()
        db.commit()

        # Revoke all refresh tokens for security
        refresh_tokens = db.query(RefreshToken).filter(
            RefreshToken.user_id == user.id,
            RefreshToken.is_revoked == False
        ).all()

        for token in refresh_tokens:
            token.is_revoked = True
            revoke_token(token.token_jti, token.token_type, user.id, "password_change", db)

        db.commit()

        # Log password change
        log_user_action(
            db=db,
            user_id=user.id,
            action="password_change",
            entity_type="user",
            entity_id=user.id,
            ip_address=getattr(request_obj.client, 'host', None) if request_obj else None,
            user_agent=request_obj.headers.get("user-agent") if request_obj else None
        )

        return {"message": "Password changed successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Change password error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete("/account")
async def delete_user_account(
    current_user: Dict = Depends(get_current_user),
    request_obj: Request = None,
    db: Session = Depends(get_db)
):
    """
    Delete user account.

    - Deactivates user account
    - Revokes all tokens
    - Logs deletion for compliance
    """
    try:
        user = db.query(User).filter(User.id == current_user.sub).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        # Deactivate account instead of hard delete for compliance
        user.is_active = False
        user.updated_at = datetime.utcnow()
        db.commit()

        # Revoke all tokens
        refresh_tokens = db.query(RefreshToken).filter(
            RefreshToken.user_id == user.id,
            RefreshToken.is_revoked == False
        ).all()

        for token in refresh_tokens:
            token.is_revoked = True
            revoke_token(token.token_jti, token.token_type, user.id, "account_deletion", db)

        db.commit()

        # Log account deletion
        log_user_action(
            db=db,
            user_id=user.id,
            action="account_deletion",
            entity_type="user",
            entity_id=user.id,
            old_values={"is_active": True},
            new_values={"is_active": False},
            ip_address=getattr(request_obj.client, 'host', None) if request_obj else None,
            user_agent=request_obj.headers.get("user-agent") if request_obj else None
        )

        return {"message": "Account deleted successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Delete account error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")


# Admin endpoints
@router.get("/admin/users", response_model=Dict[str, Any])
async def list_users(
    skip: int = 0,
    limit: int = 100,
    current_user: Dict = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    List all users (admin only).

    - Returns paginated list of users
    - Requires admin permissions
    """
    try:
        users = db.query(User).offset(skip).limit(limit).all()
        total = db.query(User).count()

        return {
            "users": [
                {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "full_name": user.full_name,
                    "role": user.role,
                    "is_active": user.is_active,
                    "is_verified": user.is_verified,
                    "created_at": user.created_at
                }
                for user in users
            ],
            "total": total,
            "skip": skip,
            "limit": limit
        }

    except Exception as e:
        logger.error(f"List users error: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.put("/admin/users/{user_id}/status")
async def update_user_status(
    user_id: str,
    is_active: bool,
    current_user: Dict = Depends(get_current_user),
    request_obj: Request = None,
    db: Session = Depends(get_db)
):
    """
    Update user account status (admin only).

    - Activates or deactivates user accounts
    - Requires admin permissions
    """
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        old_status = user.is_active
        user.is_active = is_active
        user.updated_at = datetime.utcnow()
        db.commit()

        # Log status change
        log_user_action(
            db=db,
            user_id=current_user.sub,
            action="user_status_change",
            entity_type="user",
            entity_id=user_id,
            old_values={"is_active": old_status},
            new_values={"is_active": is_active},
            ip_address=getattr(request_obj.client, 'host', None) if request_obj else None,
            user_agent=request_obj.headers.get("user-agent") if request_obj else None
        )

        return {"message": f"User {'activated' if is_active else 'deactivated'} successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Update user status error: {e}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Internal server error")