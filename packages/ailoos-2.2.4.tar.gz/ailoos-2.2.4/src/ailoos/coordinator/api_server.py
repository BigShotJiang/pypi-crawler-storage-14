#!/usr/bin/env python3
"""
Servidor API completo para AILOOS con endpoints para nodos, sesiones y modelos.
Servidor REST principal que integra todos los componentes del sistema.
"""

import asyncio
import time
import uuid
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from passlib.context import CryptContext
import jwt

from ..core.logging import get_logger
from ..core.config import get_config
from ..federated.coordinator import FederatedCoordinator
from ..data.registry import get_dataset_registry
from ..data.dataset_manager import get_dataset_manager
from ..federated.session import FederatedSession

logger = get_logger(__name__)

# Seguridad
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer()


# Modelos Pydantic para API
class UserCredentials(BaseModel):
    """Credenciales de usuario."""
    username: str
    password: str


class TokenResponse(BaseModel):
    """Response con token de acceso."""
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class NodeAuthRequest(BaseModel):
    """Request de autenticación de nodo."""
    node_id: str
    node_secret: str
    public_key: str
    timestamp: str
    signature: str
    capabilities: List[str] = Field(default_factory=list)


class NodeAuthResponse(BaseModel):
    """Response de autenticación de nodo."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    node_id: str


class NodeInfo(BaseModel):
    """Información de nodo."""
    node_id: str
    status: str
    capabilities: Dict[str, Any]
    registered_at: str
    last_seen: str
    sessions_joined: List[str]


class SessionInfo(BaseModel):
    """Información de sesión."""
    session_id: str
    model_name: str
    status: str
    participants: List[str]
    current_round: int
    total_rounds: int
    created_at: str
    min_nodes: int
    max_nodes: int
    dataset_requirements: Optional[Dict[str, Any]]


class ModelInfo(BaseModel):
    """Información de modelo."""
    model_id: str
    name: str
    version: str
    framework: str
    size_bytes: int
    created_at: str
    owner_id: str
    is_public: bool
    tags: List[str]


class DatasetInfo(BaseModel):
    """Información de dataset."""
    dataset_id: str
    name: str
    description: str
    owner_id: str
    cid: str
    size_bytes: int
    num_samples: int
    data_format: str
    tags: List[str]
    quality_score: float
    privacy_level: str
    created_at: str
    access_count: int


class CreateSessionRequest(BaseModel):
    """Request para crear sesión."""
    model_name: str
    min_nodes: int = 3
    max_nodes: int = 100
    rounds: int = 5
    dataset_requirements: Optional[Dict[str, Any]] = None
    privacy_budget: float = 1.0


class RegisterNodeRequest(BaseModel):
    """Request para registrar nodo."""
    node_id: str
    capabilities: Dict[str, Any] = Field(default_factory=dict)
    public_key: Optional[str] = None


class UploadModelRequest(BaseModel):
    """Request para subir modelo."""
    name: str
    framework: str
    model_data: bytes
    is_public: bool = False
    tags: List[str] = Field(default_factory=list)


class RegisterDatasetRequest(BaseModel):
    """Request para registrar dataset."""
    name: str
    description: str
    data_format: str
    schema: Dict[str, Any]
    tags: List[str] = Field(default_factory=list)
    privacy_level: str = "public"


class ModelUpdateRequest(BaseModel):
    """Request para enviar actualización de modelo."""
    node_id: str
    session_id: str
    round_num: int
    model_weights: Dict[str, List[float]]
    num_samples: int
    accuracy: float = 0.0
    loss: float = 0.0
    metadata: Dict[str, Any] = Field(default_factory=dict)
    timestamp: str


class LeaveSessionRequest(BaseModel):
    """Request para abandonar sesión."""
    node_id: str


class SystemStatus(BaseModel):
    """Estado del sistema."""
    status: str
    version: str
    uptime_seconds: float
    active_sessions: int
    registered_nodes: int
    total_datasets: int
    ipfs_connected: bool
    timestamp: str


@dataclass
class APIServer:
    """Servidor API completo para AILOOS."""

    app: FastAPI = None
    config: Any = None
    federated_coordinator: FederatedCoordinator = None
    dataset_registry: Any = None
    dataset_manager: Any = None
    start_time: float = field(default_factory=time.time)

    # Simulación de usuarios (en producción usar base de datos)
    users: Dict[str, Dict[str, Any]] = field(default_factory=lambda: {
        "admin": {
            "password": "$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewfLkIwFzqkM5wS",  # "admin"
            "role": "admin"
        }
    })

    # Tokens activos (en producción usar Redis/JWT)
    active_tokens: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def __post_init__(self):
        if self.config is None:
            self.config = get_config()
        if self.federated_coordinator is None:
            self.federated_coordinator = FederatedCoordinator(self.config)
        if self.dataset_registry is None:
            self.dataset_registry = get_dataset_registry()
        if self.dataset_manager is None:
            self.dataset_manager = get_dataset_manager()
        if self.app is None:
            self.app = self._create_app()

        logger.info("🌐 AILOOS API Server initialized with full endpoints")

    def _create_app(self) -> FastAPI:
        """Crear aplicación FastAPI completa."""

        @asynccontextmanager
        async def lifespan(app: FastAPI):
            # Startup
            logger.info("Starting AILOOS API Server")
            yield
            # Shutdown
            logger.info("Shutting down AILOOS API Server")

        app = FastAPI(
            title="AILOOS API Server",
            description="API REST completa para el ecosistema AILOOS",
            version="1.0.0",
            lifespan=lifespan
        )

        # CORS
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # Dependency para autenticación
        async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
            token = credentials.credentials
            if token not in self.active_tokens:
                raise HTTPException(status_code=401, detail="Invalid token")
            return self.active_tokens[token]["username"]

        # Routes de autenticación
        @app.post("/auth/login", response_model=TokenResponse)
        async def login(credentials: UserCredentials):
            """Autenticar usuario."""
            user = self.users.get(credentials.username)
            if not user or not pwd_context.verify(credentials.password, user["password"]):
                raise HTTPException(status_code=401, detail="Invalid credentials")

            # Generar token simple (en producción usar JWT)
            token = str(uuid.uuid4())
            self.active_tokens[token] = {
                "username": credentials.username,
                "role": user["role"],
                "created_at": time.time()
            }

            return TokenResponse(access_token=token, expires_in=3600)

        @app.post("/auth/logout")
        async def logout(credentials: HTTPAuthorizationCredentials = Depends(security)):
            """Cerrar sesión."""
            token = credentials.credentials
            if token in self.active_tokens:
                del self.active_tokens[token]
            return {"message": "Logged out successfully"}

        @app.post("/auth/nodes/login", response_model=NodeAuthResponse)
        async def node_login(request: NodeAuthRequest):
            """Autenticar nodo."""
            try:
                # Verificar firma del nodo (simplificada)
                # En producción, verificar criptográficamente
                if not request.node_id or not request.signature:
                    raise HTTPException(status_code=400, detail="Invalid request")

                # Registrar nodo si no existe
                node_info = self.federated_coordinator.register_node(request.node_id)

                # Generar tokens JWT para el nodo
                import jwt
                import secrets

                payload = {
                    "node_id": request.node_id,
                    "type": "node",
                    "exp": int(time.time()) + 3600,  # 1 hora
                    "iat": int(time.time())
                }

                # Usar clave secreta simple (en producción usar claves asimétricas)
                secret_key = "ailoos_node_secret_key_2024"
                access_token = jwt.encode(payload, secret_key, algorithm="HS256")

                refresh_payload = {
                    "node_id": request.node_id,
                    "type": "refresh",
                    "exp": int(time.time()) + 86400,  # 24 horas
                    "iat": int(time.time())
                }
                refresh_token = jwt.encode(refresh_payload, secret_key, algorithm="HS256")

                # Almacenar token activo
                token_id = secrets.token_hex(16)
                self.active_tokens[token_id] = {
                    "node_id": request.node_id,
                    "type": "node",
                    "created_at": time.time()
                }

                return NodeAuthResponse(
                    access_token=access_token,
                    refresh_token=refresh_token,
                    expires_in=3600,
                    node_id=request.node_id
                )

            except Exception as e:
                logger.error(f"Node authentication failed: {e}")
                raise HTTPException(status_code=401, detail="Authentication failed")

        @app.post("/auth/nodes/refresh", response_model=NodeAuthResponse)
        async def node_refresh_token(refresh_token: str):
            """Renovar token de nodo."""
            try:
                # Verificar refresh token
                secret_key = "ailoos_node_secret_key_2024"
                payload = jwt.decode(refresh_token, secret_key, algorithms=["HS256"])

                if payload.get("type") != "refresh":
                    raise HTTPException(status_code=400, detail="Invalid token type")

                node_id = payload["node_id"]

                # Generar nuevo access token
                new_payload = {
                    "node_id": node_id,
                    "type": "node",
                    "exp": int(time.time()) + 3600,
                    "iat": int(time.time())
                }
                access_token = jwt.encode(new_payload, secret_key, algorithm="HS256")

                return NodeAuthResponse(
                    access_token=access_token,
                    refresh_token=refresh_token,  # Reutilizar refresh token
                    expires_in=3600,
                    node_id=node_id
                )

            except jwt.ExpiredSignatureError:
                raise HTTPException(status_code=401, detail="Refresh token expired")
            except Exception as e:
                logger.error(f"Token refresh failed: {e}")
                raise HTTPException(status_code=401, detail="Invalid refresh token")

        # Routes de nodos
        @app.post("/nodes", response_model=NodeInfo)
        async def register_node(request: RegisterNodeRequest, username: str = Depends(get_current_user)):
            """Registrar nuevo nodo."""
            try:
                node_info = self.federated_coordinator.register_node(request.node_id)
                return NodeInfo(
                    node_id=node_info["node_id"],
                    status=node_info["status"],
                    capabilities=request.capabilities,
                    registered_at=node_info["registered_at"],
                    last_seen=datetime.now().isoformat(),
                    sessions_joined=node_info["sessions_joined"]
                )
            except Exception as e:
                logger.error(f"Failed to register node: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/nodes", response_model=List[NodeInfo])
        async def list_nodes(username: str = Depends(get_current_user)):
            """Listar nodos registrados."""
            nodes = []
            for node_id in self.federated_coordinator.node_registry:
                node_info = self.federated_coordinator.get_node_info(node_id)
                nodes.append(NodeInfo(
                    node_id=node_info["node_id"],
                    status=node_info["status"],
                    capabilities={},  # TODO: Add real capabilities
                    registered_at=node_info["registered_at"],
                    last_seen=datetime.now().isoformat(),
                    sessions_joined=node_info["sessions_joined"]
                ))
            return nodes

        @app.get("/nodes/{node_id}", response_model=NodeInfo)
        async def get_node(node_id: str, username: str = Depends(get_current_user)):
            """Obtener información de nodo específico."""
            node_info = self.federated_coordinator.get_node_info(node_id)
            if not node_info:
                raise HTTPException(status_code=404, detail="Node not found")

            return NodeInfo(
                node_id=node_info["node_id"],
                status=node_info["status"],
                capabilities={},
                registered_at=node_info["registered_at"],
                last_seen=datetime.now().isoformat(),
                sessions_joined=node_info["sessions_joined"]
            )

        @app.get("/nodes/{node_id}/status")
        async def get_node_status(node_id: str, username: str = Depends(get_current_user)):
            """Obtener estado detallado de nodo."""
            try:
                status = self.federated_coordinator.get_node_status(node_id)
                return status
            except Exception as e:
                raise HTTPException(status_code=404, detail=str(e))

        # Routes de sesiones
        @app.post("/sessions", response_model=SessionInfo)
        async def create_session(request: CreateSessionRequest, username: str = Depends(get_current_user)):
            """Crear nueva sesión federada."""
            try:
                session = self.federated_coordinator.create_session(
                    session_id=f"session_{uuid.uuid4().hex[:8]}",
                    model_name=request.model_name,
                    min_nodes=request.min_nodes,
                    max_nodes=request.max_nodes,
                    rounds=request.rounds
                )

                return SessionInfo(
                    session_id=session.session_id,
                    model_name=session.model_name,
                    status=session.status,
                    participants=list(session.participants),
                    current_round=session.current_round,
                    total_rounds=session.total_rounds,
                    created_at=datetime.now().isoformat(),
                    min_nodes=session.min_nodes,
                    max_nodes=session.max_nodes,
                    dataset_requirements=request.dataset_requirements
                )
            except Exception as e:
                logger.error(f"Failed to create session: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/sessions", response_model=List[SessionInfo])
        async def list_sessions(username: str = Depends(get_current_user)):
            """Listar sesiones activas."""
            sessions = self.federated_coordinator.get_active_sessions()
            return [
                SessionInfo(
                    session_id=s["session_id"],
                    model_name=s["model_name"],
                    status=s["status"],
                    participants=[],  # TODO: Add real participants
                    current_round=s["current_round"],
                    total_rounds=s["total_rounds"],
                    created_at=datetime.now().isoformat(),
                    min_nodes=3,
                    max_nodes=100,
                    dataset_requirements=None
                )
                for s in sessions
            ]

        @app.get("/sessions/{session_id}", response_model=SessionInfo)
        async def get_session(session_id: str, username: str = Depends(get_current_user)):
            """Obtener información de sesión específica."""
            session = self.federated_coordinator.get_session(session_id)
            if not session:
                raise HTTPException(status_code=404, detail="Session not found")

            return SessionInfo(
                session_id=session.session_id,
                model_name=session.model_name,
                status=session.status,
                participants=list(session.participants),
                current_round=session.current_round,
                total_rounds=session.total_rounds,
                created_at=datetime.now().isoformat(),
                min_nodes=session.min_nodes,
                max_nodes=session.max_nodes,
                dataset_requirements=None
            )

        @app.post("/sessions/{session_id}/join")
        async def join_session(session_id: str, node_id: str, username: str = Depends(get_current_user)):
            """Unir nodo a sesión."""
            try:
                success = self.federated_coordinator.add_node_to_session(session_id, node_id)
                if not success:
                    raise HTTPException(status_code=400, detail="Failed to join session")
                return {"message": f"Node {node_id} joined session {session_id}"}
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/start")
        async def start_session(session_id: str, background_tasks: BackgroundTasks, username: str = Depends(get_current_user)):
            """Iniciar sesión."""
            try:
                result = self.federated_coordinator.start_training(session_id)
                background_tasks.add_task(self._run_session_training, session_id)
                return result
            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/leave")
        async def leave_session(session_id: str, request: LeaveSessionRequest, username: str = Depends(get_current_user)):
            """Abandonar sesión."""
            try:
                # Verificar que el nodo esté en la sesión
                session = self.federated_coordinator.get_session(session_id)
                if not session or request.node_id not in session.participants:
                    raise HTTPException(status_code=404, detail="Node not in session")

                success = self.federated_coordinator.remove_node_from_session(session_id, request.node_id)
                if not success:
                    raise HTTPException(status_code=400, detail="Failed to leave session")

                return {"message": f"Node {request.node_id} left session {session_id}"}
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to leave session: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.post("/sessions/{session_id}/updates")
        async def submit_model_update(session_id: str, request: ModelUpdateRequest, username: str = Depends(get_current_user)):
            """Enviar actualización de modelo."""
            try:
                # Verificar que el nodo esté en la sesión
                session = self.federated_coordinator.get_session(session_id)
                if not session or request.node_id not in session.participants:
                    raise HTTPException(status_code=403, detail="Node not authorized for this session")

                success = self.federated_coordinator.submit_model_update(
                    session_id,
                    request.node_id,
                    {
                        "weights": request.model_weights,
                        "samples_used": request.num_samples,
                        "accuracy": request.accuracy,
                        "loss": request.loss,
                        "metadata": request.metadata
                    }
                )

                if not success:
                    raise HTTPException(status_code=400, detail="Failed to submit model update")

                return {"message": "Model update submitted successfully"}
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to submit model update: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/sessions/{session_id}/round")
        async def get_round_info(session_id: str, username: str = Depends(get_current_user)):
            """Obtener información de la ronda actual."""
            try:
                session = self.federated_coordinator.get_session(session_id)
                if not session:
                    raise HTTPException(status_code=404, detail="Session not found")

                return {
                    "session_id": session.session_id,
                    "round_num": session.current_round,
                    "total_rounds": session.total_rounds,
                    "status": session.status,
                    "participants": list(session.participants),
                    "min_nodes": session.min_nodes,
                    "max_nodes": session.max_nodes,
                    "model_name": session.model_name
                }
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to get round info: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        @app.get("/sessions/{session_id}/model")
        async def get_global_model(session_id: str, username: str = Depends(get_current_user)):
            """Obtener modelo global actual."""
            try:
                session = self.federated_coordinator.get_session(session_id)
                if not session:
                    raise HTTPException(status_code=404, detail="Session not found")

                # Obtener modelo global (simulado por ahora)
                global_model = getattr(session, 'global_model', None)
                if not global_model:
                    raise HTTPException(status_code=404, detail="No global model available")

                return {
                    "session_id": session.session_id,
                    "round_num": session.current_round,
                    "model_weights": global_model.get("weights", {}),
                    "updated_at": datetime.now().isoformat(),
                    "metadata": global_model.get("metadata", {})
                }
            except HTTPException:
                raise
            except Exception as e:
                logger.error(f"Failed to get global model: {e}")
                raise HTTPException(status_code=500, detail=str(e))

        # Routes de modelos
        @app.get("/models", response_model=List[ModelInfo])
        async def list_models(username: str = Depends(get_current_user)):
            """Listar modelos disponibles."""
            # TODO: Implementar registro de modelos
            return []

        @app.get("/models/{model_id}", response_model=ModelInfo)
        async def get_model(model_id: str, username: str = Depends(get_current_user)):
            """Obtener información de modelo."""
            # TODO: Implementar
            raise HTTPException(status_code=404, detail="Model not found")

        # Routes de datasets
        @app.get("/datasets", response_model=List[DatasetInfo])
        async def list_datasets(
            owner_id: Optional[str] = Query(None),
            tags: List[str] = Query(None),
            username: str = Depends(get_current_user)
        ):
            """Listar datasets."""
            datasets = self.dataset_registry.list_datasets(owner_id=owner_id, tags=tags)
            return [
                DatasetInfo(
                    dataset_id=d.dataset_id,
                    name=d.name,
                    description=d.description,
                    owner_id=d.owner_id,
                    cid=d.cid,
                    size_bytes=d.size_bytes,
                    num_samples=d.num_samples,
                    data_format=d.data_format,
                    tags=d.tags,
                    quality_score=d.quality_score,
                    privacy_level=d.privacy_level,
                    created_at=d.created_at,
                    access_count=d.access_count
                )
                for d in datasets
            ]

        @app.get("/datasets/{dataset_id}", response_model=DatasetInfo)
        async def get_dataset(dataset_id: str, username: str = Depends(get_current_user)):
            """Obtener información de dataset."""
            dataset = self.dataset_registry.get_dataset(dataset_id)
            if not dataset:
                raise HTTPException(status_code=404, detail="Dataset not found")

            return DatasetInfo(
                dataset_id=dataset.dataset_id,
                name=dataset.name,
                description=dataset.description,
                owner_id=dataset.owner_id,
                cid=dataset.cid,
                size_bytes=dataset.size_bytes,
                num_samples=dataset.num_samples,
                data_format=dataset.data_format,
                tags=dataset.tags,
                quality_score=dataset.quality_score,
                privacy_level=dataset.privacy_level,
                created_at=dataset.created_at,
                access_count=dataset.access_count
            )

        @app.get("/datasets/{dataset_id}/download")
        async def download_dataset(dataset_id: str, output_path: str, username: str = Depends(get_current_user)):
            """Descargar dataset."""
            success, message = await self.dataset_registry.download_dataset(dataset_id, output_path)
            if not success:
                raise HTTPException(status_code=500, detail=message)
            return {"message": message}

        # Routes del sistema
        @app.get("/status", response_model=SystemStatus)
        async def get_system_status():
            """Obtener estado del sistema."""
            registry_stats = self.dataset_registry.get_registry_stats()
            global_status = self.federated_coordinator.get_global_status()

            return SystemStatus(
                status="healthy",
                version="1.0.0",
                uptime_seconds=time.time() - self.start_time,
                active_sessions=global_status["active_sessions"],
                registered_nodes=global_status["registered_nodes"],
                total_datasets=registry_stats["total_datasets"],
                ipfs_connected=registry_stats["ipfs_connected"],
                timestamp=datetime.now().isoformat()
            )

        @app.get("/health")
        async def health_check():
            """Health check endpoint."""
            return {"status": "healthy", "timestamp": datetime.now().isoformat()}

        return app

    async def _run_session_training(self, session_id: str):
        """Ejecutar entrenamiento de sesión en background."""
        try:
            logger.info(f"Starting training for session {session_id}")

            session = self.federated_coordinator.get_session(session_id)
            if not session:
                return

            # Simular rondas
            for round_num in range(session.total_rounds):
                logger.info(f"Session {session_id}: Round {round_num + 1}")

                # Esperar actualizaciones
                await asyncio.sleep(10)

                # Agregar si hay suficientes updates
                if hasattr(session, 'model_updates') and len(session.model_updates) >= session.min_nodes:
                    self.federated_coordinator.aggregate_models(session_id)

            logger.info(f"Training completed for session {session_id}")

        except Exception as e:
            logger.error(f"Error in session training {session_id}: {e}")

    def start_server(self, host: str = "0.0.0.0", port: int = 8000):
        """Iniciar servidor."""
        logger.info(f"Starting AILOOS API Server on {host}:{port}")
        uvicorn.run(
            self.app,
            host=host,
            port=port,
            log_level="info"
        )

    async def start_async(self, host: str = "0.0.0.0", port: int = 8000):
        """Iniciar servidor de forma asíncrona."""
        config = uvicorn.Config(
            self.app,
            host=host,
            port=port,
            log_level="info"
        )
        server = uvicorn.Server(config)
        await server.serve()


# Instancia global
_api_server: Optional[APIServer] = None


def get_api_server() -> APIServer:
    """Obtener instancia global del servidor API."""
    global _api_server

    if _api_server is None:
        _api_server = APIServer()

    return _api_server


def start_api_server(host: str = "0.0.0.0", port: int = 8000):
    """Función de conveniencia para iniciar el servidor API."""
    server = get_api_server()
    server.start_server(host, port)


if __name__ == "__main__":
    start_api_server()