"""
EmpoorioLM Performance Optimizer
Optimizador de rendimiento para el servicio EmpoorioLM.
"""

import asyncio
import time
import threading
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
import logging
import psutil
try:
    import GPUtil
    GPU_UTIL_AVAILABLE = True
except ImportError:
    GPU_UTIL_AVAILABLE = False
    GPUtil = None
from collections import deque
import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class PerformanceMetrics:
    """Métricas de rendimiento del sistema."""

    timestamp: float

    # CPU
    cpu_usage_percent: float = 0.0
    cpu_memory_usage_gb: float = 0.0

    # GPU
    gpu_usage_percent: Optional[float] = None
    gpu_memory_usage_gb: Optional[float] = None
    gpu_memory_total_gb: Optional[float] = None

    # Memoria del sistema
    system_memory_usage_gb: float = 0.0
    system_memory_total_gb: float = 0.0

    # Inference Engine
    active_requests: int = 0
    queued_requests: int = 0
    avg_response_time_ms: float = 0.0
    requests_per_second: float = 0.0

    # Model Manager
    models_in_cache: int = 0
    cache_memory_usage_gb: float = 0.0
    cache_hit_rate: float = 0.0

    # Version Controller
    active_versions: int = 0


@dataclass
class OptimizationAction:
    """Acción de optimización a aplicar."""

    action_type: str  # 'scale_up', 'scale_down', 'cache_optimize', 'model_unload', etc.
    target_component: str  # 'inference_engine', 'model_manager', 'version_controller'
    parameters: Dict[str, Any]
    priority: int  # 1-10, 10 siendo más alta
    reason: str
    expected_impact: str


@dataclass
class PerformanceOptimizerConfig:
    """Configuración del Performance Optimizer."""

    # Umbrales de rendimiento
    cpu_usage_threshold_high: float = 80.0  # %
    cpu_usage_threshold_low: float = 20.0   # %

    memory_usage_threshold_high: float = 85.0  # %
    memory_usage_threshold_low: float = 30.0   # %

    gpu_memory_threshold_high: float = 90.0  # %
    gpu_memory_threshold_low: float = 40.0   # %

    # Umbrales de inference
    max_response_time_ms: float = 5000  # 5 segundos
    max_queue_size: int = 100

    # Configuración de optimización
    enable_auto_scaling: bool = True
    enable_cache_optimization: bool = True
    enable_model_preloading: bool = True

    # Intervalos de monitoreo
    metrics_collection_interval_seconds: int = 30
    optimization_check_interval_seconds: int = 60

    # Historial de métricas
    metrics_history_size: int = 100  # Últimas 100 mediciones

    # Configuración de auto-scaling
    scale_up_cooldown_seconds: int = 300   # 5 minutos
    scale_down_cooldown_seconds: int = 600  # 10 minutos


class PerformanceOptimizer:
    """
    Optimizador de rendimiento para EmpoorioLM.

    Funcionalidades:
    - Monitoreo continuo de métricas del sistema
    - Optimización automática de cache
    - Auto-scaling inteligente
    - Recomendaciones de optimización
    - Detección y mitigación de cuellos de botella
    """

    def __init__(self, config: PerformanceOptimizerConfig):
        self.config = config

        # Historial de métricas
        self.metrics_history: deque[PerformanceMetrics] = deque(maxlen=config.metrics_history_size)

        # Estado del optimizador
        self.is_active = False
        self.last_scale_up_time = 0
        self.last_scale_down_time = 0

        # Referencias a componentes (se setean después)
        self.inference_engine = None
        self.model_manager = None
        self.version_controller = None

        # Estadísticas de optimización
        self.optimization_stats = {
            "total_optimizations_applied": 0,
            "cache_optimizations": 0,
            "scaling_actions": 0,
            "model_unloads": 0,
            "performance_improvements": []
        }

        # Locks para thread safety
        self.metrics_lock = threading.RLock()

        logger.info(f"⚡ Performance Optimizer inicializado")

    def set_components(
        self,
        inference_engine=None,
        model_manager=None,
        version_controller=None
    ):
        """Establecer referencias a componentes del sistema."""
        self.inference_engine = inference_engine
        self.model_manager = model_manager
        self.version_controller = version_controller

        logger.info("🔗 Componentes conectados al Performance Optimizer")

    async def start(self):
        """Iniciar el optimizador de rendimiento."""
        if self.is_active:
            return

        self.is_active = True

        # Iniciar tareas de background
        asyncio.create_task(self._metrics_collection_loop())
        asyncio.create_task(self._optimization_loop())

        logger.info("✅ Performance Optimizer iniciado")

    async def stop(self):
        """Detener el optimizador de rendimiento."""
        self.is_active = False
        logger.info("🛑 Performance Optimizer detenido")

    async def _metrics_collection_loop(self):
        """Loop de recolección de métricas."""
        while self.is_active:
            try:
                metrics = await self._collect_system_metrics()
                with self.metrics_lock:
                    self.metrics_history.append(metrics)

                # Log de métricas críticas
                if metrics.cpu_usage_percent > self.config.cpu_usage_threshold_high:
                    logger.warning(f"⚠️ CPU usage high: {metrics.cpu_usage_percent:.1f}%")

                if metrics.system_memory_usage_gb / metrics.system_memory_total_gb > self.config.memory_usage_threshold_high / 100:
                    logger.warning(f"⚠️ Memory usage high: {metrics.system_memory_usage_gb:.1f}/{metrics.system_memory_total_gb:.1f}GB")

            except Exception as e:
                logger.error(f"Error collecting metrics: {e}")

            await asyncio.sleep(self.config.metrics_collection_interval_seconds)

    async def _optimization_loop(self):
        """Loop de optimización automática."""
        while self.is_active:
            try:
                # Analizar métricas recientes
                actions = await self._analyze_and_recommend_actions()

                # Aplicar acciones prioritarias
                for action in actions:
                    if action.priority >= 8:  # Alta prioridad
                        await self._apply_optimization_action(action)

            except Exception as e:
                logger.error(f"Error in optimization loop: {e}")

            await asyncio.sleep(self.config.optimization_check_interval_seconds)

    async def _collect_system_metrics(self) -> PerformanceMetrics:
        """Recolectar métricas del sistema."""
        timestamp = time.time()

        # CPU y memoria del sistema
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        system_memory_usage = memory.used / (1024**3)  # GB
        system_memory_total = memory.total / (1024**3)  # GB

        # GPU (si disponible)
        gpu_percent = None
        gpu_memory_usage = None
        gpu_memory_total = None

        if GPU_UTIL_AVAILABLE:
            try:
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]  # Usar primera GPU
                    gpu_percent = gpu.load * 100
                    gpu_memory_usage = gpu.memoryUsed / 1024  # GB
                    gpu_memory_total = gpu.memoryTotal / 1024  # GB
            except Exception:
                pass

        # Métricas de Inference Engine
        ie_metrics = {"active_requests": 0, "queued_requests": 0, "avg_response_time_ms": 0.0}
        if self.inference_engine:
            ie_stats = self.inference_engine.get_stats()
            ie_metrics.update({
                "active_requests": ie_stats.get("active_requests", 0),
                "queued_requests": ie_stats.get("queued_requests", 0),
                "avg_response_time_ms": ie_stats.get("avg_processing_time", 0.0) * 1000
            })

        # Métricas de Model Manager
        mm_metrics = {"models_in_cache": 0, "cache_memory_usage_gb": 0.0, "cache_hit_rate": 0.0}
        if self.model_manager:
            mm_stats = self.model_manager.get_stats()
            mm_metrics.update({
                "models_in_cache": mm_stats.get("current_models_loaded", 0),
                "cache_memory_usage_gb": mm_stats.get("current_memory_usage_mb", 0.0) / 1024,
                "cache_hit_rate": mm_stats.get("cache_hit_rate", 0.0)
            })

        # Métricas de Version Controller
        vc_metrics = {"active_versions": 0}
        if self.version_controller:
            vc_info = self.version_controller.get_active_versions_info()
            vc_metrics["active_versions"] = vc_info.get("total_active", 0)

        # Calcular requests por segundo (basado en historial)
        rps = 0.0
        if len(self.metrics_history) > 0:
            recent_metrics = list(self.metrics_history)[-5:]  # Últimas 5 mediciones
            if len(recent_metrics) >= 2:
                time_diff = recent_metrics[-1].timestamp - recent_metrics[0].timestamp
                request_diff = recent_metrics[-1].active_requests - recent_metrics[0].active_requests
                if time_diff > 0:
                    rps = request_diff / time_diff

        return PerformanceMetrics(
            timestamp=timestamp,
            cpu_usage_percent=cpu_percent,
            cpu_memory_usage_gb=system_memory_usage,
            gpu_usage_percent=gpu_percent,
            gpu_memory_usage_gb=gpu_memory_usage,
            gpu_memory_total_gb=gpu_memory_total,
            system_memory_usage_gb=system_memory_usage,
            system_memory_total_gb=system_memory_total,
            active_requests=ie_metrics["active_requests"],
            queued_requests=ie_metrics["queued_requests"],
            avg_response_time_ms=ie_metrics["avg_response_time_ms"],
            requests_per_second=rps,
            models_in_cache=mm_metrics["models_in_cache"],
            cache_memory_usage_gb=mm_metrics["cache_memory_usage_gb"],
            cache_hit_rate=mm_metrics["cache_hit_rate"],
            active_versions=vc_metrics["active_versions"]
        )

    async def _analyze_and_recommend_actions(self) -> List[OptimizationAction]:
        """Analizar métricas y recomendar acciones de optimización."""
        actions = []

        if len(self.metrics_history) < 5:
            return actions  # Necesitamos datos históricos

        # Obtener métricas recientes
        recent_metrics = list(self.metrics_history)[-5:]
        latest = recent_metrics[-1]

        # Análisis de CPU
        avg_cpu = np.mean([m.cpu_usage_percent for m in recent_metrics])
        if avg_cpu > self.config.cpu_usage_threshold_high:
            actions.append(OptimizationAction(
                action_type="scale_up",
                target_component="inference_engine",
                parameters={"workers": 2},  # Añadir 2 workers
                priority=9,
                reason=f"CPU usage high: {avg_cpu:.1f}%",
                expected_impact="Reducir latencia de respuesta"
            ))

        # Análisis de memoria
        memory_usage_percent = (latest.system_memory_usage_gb / latest.system_memory_total_gb) * 100
        if memory_usage_percent > self.config.memory_usage_threshold_high:
            actions.append(OptimizationAction(
                action_type="cache_optimize",
                target_component="model_manager",
                parameters={"evict_count": 1},  # Evictar 1 modelo
                priority=8,
                reason=f"Memory usage high: {memory_usage_percent:.1f}%",
                expected_impact="Liberar memoria del sistema"
            ))

        # Análisis de GPU
        if latest.gpu_memory_usage_gb and latest.gpu_memory_total_gb:
            gpu_memory_percent = (latest.gpu_memory_usage_gb / latest.gpu_memory_total_gb) * 100
            if gpu_memory_percent > self.config.gpu_memory_threshold_high:
                actions.append(OptimizationAction(
                    action_type="model_unload",
                    target_component="model_manager",
                    parameters={"unload_unused": True},
                    priority=7,
                    reason=f"GPU memory high: {gpu_memory_percent:.1f}%",
                    expected_impact="Liberar memoria GPU"
                ))

        # Análisis de cola de requests
        if latest.queued_requests > self.config.max_queue_size:
            actions.append(OptimizationAction(
                action_type="scale_up",
                target_component="inference_engine",
                parameters={"workers": 1},
                priority=10,
                reason=f"Queue size high: {latest.queued_requests}",
                expected_impact="Reducir tiempo de cola"
            ))

        # Análisis de tiempo de respuesta
        if latest.avg_response_time_ms > self.config.max_response_time_ms:
            actions.append(OptimizationAction(
                action_type="model_preload",
                target_component="model_manager",
                parameters={"preload_popular": True},
                priority=6,
                reason=f"Response time high: {latest.avg_response_time_ms:.0f}ms",
                expected_impact="Reducir latencia de inferencia"
            ))

        # Análisis de cache
        if latest.cache_hit_rate < 0.5 and self.config.enable_cache_optimization:
            actions.append(OptimizationAction(
                action_type="cache_warmup",
                target_component="model_manager",
                parameters={"warmup_recent": True},
                priority=5,
                reason=f"Cache hit rate low: {latest.cache_hit_rate:.2%}",
                expected_impact="Mejorar hit rate del cache"
            ))

        return sorted(actions, key=lambda x: x.priority, reverse=True)

    async def _apply_optimization_action(self, action: OptimizationAction):
        """Aplicar una acción de optimización."""
        try:
            logger.info(f"🔧 Aplicando optimización: {action.action_type} en {action.target_component}")

            if action.target_component == "inference_engine" and self.inference_engine:
                await self._apply_inference_engine_action(action)

            elif action.target_component == "model_manager" and self.model_manager:
                await self._apply_model_manager_action(action)

            elif action.target_component == "version_controller" and self.version_controller:
                await self._apply_version_controller_action(action)

            # Registrar acción aplicada
            self.optimization_stats["total_optimizations_applied"] += 1
            self.optimization_stats["performance_improvements"].append({
                "timestamp": time.time(),
                "action": action.action_type,
                "reason": action.reason,
                "expected_impact": action.expected_impact
            })

            logger.info(f"✅ Optimización aplicada: {action.action_type}")

        except Exception as e:
            logger.error(f"❌ Error aplicando optimización {action.action_type}: {e}")

    async def _apply_inference_engine_action(self, action: OptimizationAction):
        """Aplicar acción en Inference Engine."""
        if action.action_type == "scale_up":
            workers_to_add = action.parameters.get("workers", 1)
            # En implementación real, ajustar pool de workers
            logger.info(f"⬆️ Escalando Inference Engine: +{workers_to_add} workers")

        elif action.action_type == "scale_down":
            workers_to_remove = action.parameters.get("workers", 1)
            logger.info(f"⬇️ Reduciendo Inference Engine: -{workers_to_remove} workers")

    async def _apply_model_manager_action(self, action: OptimizationAction):
        """Aplicar acción en Model Manager."""
        if action.action_type == "cache_optimize":
            evict_count = action.parameters.get("evict_count", 1)
            # En implementación real, evictar modelos menos usados
            logger.info(f"🗑️ Optimizando cache: evictando {evict_count} modelos")

        elif action.action_type == "model_unload":
            if action.parameters.get("unload_unused"):
                # En implementación real, descargar modelos no usados
                logger.info("📤 Descargando modelos no utilizados")

        elif action.action_type == "model_preload":
            if action.parameters.get("preload_popular"):
                # En implementación real, precargar modelos populares
                logger.info("📥 Precargando modelos populares")

        elif action.action_type == "cache_warmup":
            if action.parameters.get("warmup_recent"):
                # En implementación real, calentar cache con modelos recientes
                logger.info("🔥 Calentando cache")

    async def _apply_version_controller_action(self, action: OptimizationAction):
        """Aplicar acción en Version Controller."""
        if action.action_type == "deprecate_versions":
            versions_to_deprecate = action.parameters.get("versions", [])
            reason = action.parameters.get("reason", "Deprecated due to performance optimization")
            for version_id in versions_to_deprecate:
                await self.version_controller.deprecate_version(version_id, reason)
            logger.info(f"📋 Deprecadas {len(versions_to_deprecate)} versiones")

        elif action.action_type == "cleanup_versions":
            keep_last = action.parameters.get("keep_last", 5)
            await self.version_controller.cleanup_old_versions(keep_last)
            logger.info(f"🗑️ Limpieza de versiones, manteniendo últimas {keep_last}")

        elif action.action_type == "promote_version":
            version_id = action.parameters.get("version_id")
            if version_id:
                # Assuming version_controller has a method to promote version
                # For now, just log as this might need additional implementation
                logger.info(f"⬆️ Promoviendo versión: {version_id}")
            else:
                logger.warning("No version_id provided for promote_version action")

        else:
            logger.warning(f"🎛️ Acción no reconocida en Version Controller: {action.action_type}")

    def get_performance_report(self) -> Dict[str, Any]:
        """Generar reporte de rendimiento."""
        if not self.metrics_history:
            return {"error": "No metrics available"}

        # Calcular estadísticas de las métricas recientes
        recent_metrics = list(self.metrics_history)[-10:]  # Últimas 10

        report = {
            "current_metrics": self.metrics_history[-1].__dict__ if self.metrics_history else None,
            "averages_last_10": {
                "cpu_usage_percent": np.mean([m.cpu_usage_percent for m in recent_metrics]),
                "memory_usage_percent": np.mean([
                    (m.system_memory_usage_gb / m.system_memory_total_gb) * 100
                    for m in recent_metrics
                ]),
                "avg_response_time_ms": np.mean([m.avg_response_time_ms for m in recent_metrics]),
                "requests_per_second": np.mean([m.requests_per_second for m in recent_metrics]),
                "cache_hit_rate": np.mean([m.cache_hit_rate for m in recent_metrics])
            },
            "optimization_stats": self.optimization_stats,
            "system_status": self._get_system_status()
        }

        return report

    def _get_system_status(self) -> str:
        """Obtener estado general del sistema."""
        if not self.metrics_history:
            return "unknown"

        latest = self.metrics_history[-1]

        # Lógica simple de evaluación de estado
        issues = []

        if latest.cpu_usage_percent > self.config.cpu_usage_threshold_high:
            issues.append("high_cpu")

        memory_percent = (latest.system_memory_usage_gb / latest.system_memory_total_gb) * 100
        if memory_percent > self.config.memory_usage_threshold_high:
            issues.append("high_memory")

        if latest.avg_response_time_ms > self.config.max_response_time_ms:
            issues.append("high_latency")

        if latest.queued_requests > self.config.max_queue_size:
            issues.append("high_queue")

        if issues:
            return f"warning_{'_'.join(issues)}"
        else:
            return "healthy"

    def get_optimization_recommendations(self) -> List[Dict[str, Any]]:
        """Obtener recomendaciones de optimización."""
        recommendations = []

        if not self.metrics_history:
            return recommendations

        latest = self.metrics_history[-1]

        # Recomendaciones basadas en métricas actuales
        if latest.cache_hit_rate < 0.7:
            recommendations.append({
                "type": "cache_optimization",
                "priority": "medium",
                "description": "Cache hit rate is low. Consider increasing cache size or preloading popular models.",
                "current_value": f"{latest.cache_hit_rate:.1%}",
                "recommended_action": "Increase max_models_in_memory in ModelManagerConfig"
            })

        if latest.avg_response_time_ms > 2000:
            recommendations.append({
                "type": "performance_optimization",
                "priority": "high",
                "description": "Response time is high. Consider GPU optimization or model quantization.",
                "current_value": f"{latest.avg_response_time_ms:.0f}ms",
                "recommended_action": "Enable GPU optimization or reduce model size"
            })

        memory_percent = (latest.system_memory_usage_gb / latest.system_memory_total_gb) * 100
        if memory_percent > 70:
            recommendations.append({
                "type": "memory_optimization",
                "priority": "high",
                "description": "Memory usage is high. Consider reducing cache size or model count.",
                "current_value": f"{memory_percent:.1f}%",
                "recommended_action": "Reduce max_models_in_memory or increase system memory"
            })

        return recommendations

    def get_metrics_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Obtener historial de métricas."""
        with self.metrics_lock:
            return [m.__dict__ for m in list(self.metrics_history)[-limit:]]


# Funciones de conveniencia
def create_performance_optimizer(
    config: Optional[PerformanceOptimizerConfig] = None
) -> PerformanceOptimizer:
    """Crear instancia del Performance Optimizer."""
    if config is None:
        config = PerformanceOptimizerConfig()

    return PerformanceOptimizer(config)