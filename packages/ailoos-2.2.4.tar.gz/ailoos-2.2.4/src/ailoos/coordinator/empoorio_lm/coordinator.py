"""
EmpoorioLM Coordinator
Sistema central que coordina el entrenamiento federado de EmpoorioLM v1.0.
Recolecta pesos de nodos, los agrega y crea nuevas versiones del modelo.
"""

import asyncio
import json
import time
import hashlib
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
import logging
from dataclasses import dataclass, field
from datetime import datetime

from ...models.empoorio_lm import EmpoorioLM, EmpoorioLMConfig
from .aggregator import EmpoorioLMAggregator
from .version_manager import EmpoorioLMVersionManager
from ...federated.p2p_protocol import P2PProtocol, P2PMessage, P2PMessageType, PeerInfo, ConnectionState
from ...federated.node_communicator import NodeCommunicator, NodeUpdate
from ...verification.training_prover import TrainingProver, TrainingProof, TrainingParameters, create_training_prover
from ...verification.contribution_verifier import ContributionVerifier, VerificationResult, create_contribution_verifier
from ...core.config import Config

logger = logging.getLogger(__name__)


@dataclass
class EmpoorioLMTrainingSession:
    """Sesión de entrenamiento federado para EmpoorioLM."""

    session_id: str
    model_version: str
    start_time: float
    num_rounds: int
    current_round: int = 0
    status: str = "initializing"

    # Nodos participantes
    registered_nodes: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    active_nodes: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # Datos de rondas
    round_data: Dict[int, Dict[str, Any]] = field(default_factory=dict)

    # Estadísticas
    total_contributions: int = 0
    total_training_time: float = 0.0
    total_samples_processed: int = 0

    # Modelo global
    global_model_path: Optional[str] = None
    global_weights: Optional[Dict[str, Any]] = None


@dataclass
class EmpoorioLMCoordinatorConfig:
    """Configuración del coordinador EmpoorioLM."""

    # Configuración básica
    coordinator_id: str = "empoorio_lm_coordinator_v1"
    max_rounds_per_session: int = 10
    min_nodes_per_round: int = 2
    max_nodes_per_round: int = 100

    # Timeouts
    round_timeout_seconds: int = 3600  # 1 hora
    node_registration_timeout: int = 300  # 5 minutos

    # Configuración de agregación
    aggregation_method: str = "fedavg"  # fedavg, fednova, scaffold
    min_contributions_per_round: int = 2

    # Configuración de calidad
    quality_threshold: float = 0.7  # Umbral mínimo de calidad
    enable_quality_filtering: bool = True

    # Configuración de almacenamiento
    models_dir: str = "./models/empoorio_lm"
    sessions_dir: str = "./data/sessions"
    checkpoints_dir: str = "./data/checkpoints"

    # Configuración de IPFS
    enable_ipfs_pinning: bool = True
    ipfs_pin_replicas: int = 3

    # Configuración P2P
    enable_p2p: bool = True
    p2p_host: str = "0.0.0.0"
    p2p_port: int = 8443
    cert_dir: str = "./certs"
    enable_secure_aggregation: bool = True


class EmpoorioLMCoordinator:
    """
    Coordinador principal para el entrenamiento federado de EmpoorioLM.

    Este sistema:
    1. Gestiona sesiones de entrenamiento federado
    2. Recolecta pesos de nodos participantes
    3. Agrega pesos usando algoritmos optimizados
    4. Crea nuevas versiones de EmpoorioLM
    5. Gestiona el ciclo de vida del modelo
    """

    def __init__(self, config: EmpoorioLMCoordinatorConfig):
        self.config = config

        # Componentes principales
        self.aggregator = EmpoorioLMAggregator()
        self.version_manager = EmpoorioLMVersionManager()

        # Estado del sistema
        self.active_sessions: Dict[str, EmpoorioLMTrainingSession] = {}
        self.completed_sessions: Dict[str, EmpoorioLMTrainingSession] = {}

        # Modelo base
        self.base_model: Optional[EmpoorioLM] = None
        self.current_global_model: Optional[EmpoorioLM] = None

        # Estadísticas globales
        self.total_sessions_created: int = 0
        self.total_nodes_registered: int = 0
        self.total_contributions_processed: int = 0

        # Componentes P2P
        self.p2p_protocol: Optional[P2PProtocol] = None
        self.node_communicator: Optional[NodeCommunicator] = None
        self.p2p_enabled: bool = False

        # Componentes ZKP para verificación criptográfica
        self.training_prover: Optional[TrainingProver] = None
        self.contribution_verifier: Optional[ContributionVerifier] = None
        self.zkp_enabled: bool = True  # Habilitado por defecto para seguridad

        # Crear directorios necesarios
        self._create_directories()

        # Inicializar P2P si está habilitado
        if self.config.enable_p2p:
            self._initialize_p2p()

        # Inicializar componentes ZKP
        self._initialize_zkp_components()

        logger.info(f"🎯 EmpoorioLM Coordinator inicializado: {config.coordinator_id}")

    def _create_directories(self):
        """Crear directorios necesarios para el coordinador."""
        dirs = [
            self.config.models_dir,
            self.config.sessions_dir,
            self.config.checkpoints_dir,
            self.config.cert_dir
        ]

        for dir_path in dirs:
            Path(dir_path).mkdir(parents=True, exist_ok=True)

    def _initialize_p2p(self):
        """Inicializar componentes P2P."""
        try:
            # Crear protocolo P2P
            self.p2p_protocol = P2PProtocol(
                node_id=self.config.coordinator_id,
                host=self.config.p2p_host,
                port=self.config.p2p_port,
                cert_dir=self.config.cert_dir,
                enable_tls=True
            )

            # Crear comunicador de nodos
            self.node_communicator = NodeCommunicator(
                node_id=self.config.coordinator_id,
                host=self.config.p2p_host,
                port=self.config.p2p_port,
                cert_dir=self.config.cert_dir
            )

            # Registrar handlers para mensajes P2P
            self._register_p2p_handlers()

            self.p2p_enabled = True
            logger.info("✅ P2P components initialized for coordinator")

        except Exception as e:
            logger.error(f"❌ Error initializing P2P components: {e}")
            self.p2p_enabled = False

    def _initialize_zkp_components(self):
        """Inicializar componentes ZKP para verificación criptográfica."""
        try:
            # Crear configuración base
            config = Config()

            # Inicializar TrainingProver para generar pruebas
            self.training_prover = create_training_prover(config)
            logger.info("✅ TrainingProver initialized for ZKP generation")

            # Inicializar ContributionVerifier para validar contribuciones
            self.contribution_verifier = create_contribution_verifier(config)
            logger.info("✅ ContributionVerifier initialized for ZKP validation")

            self.zkp_enabled = True
            logger.info("🔐 ZKP components initialized successfully")

        except Exception as e:
            logger.error(f"❌ Error initializing ZKP components: {e}")
            self.zkp_enabled = False
            self.training_prover = None
            self.contribution_verifier = None

    async def initialize_base_model(self, model_config: Optional[EmpoorioLMConfig] = None) -> bool:
        """
        Inicializar el modelo base de EmpoorioLM.

        Args:
            model_config: Configuración del modelo (opcional)

        Returns:
            True si se inicializó correctamente
        """
        try:
            if model_config is None:
                model_config = EmpoorioLMConfig()

            self.base_model = EmpoorioLM(model_config)

            # Crear versión inicial
            version_id = await self.version_manager.create_version(
                model=self.base_model,
                version_name="v1.0.0-base",
                description="Modelo base EmpoorioLM v1.0",
                metadata={
                    "type": "base_model",
                    "created_by": "coordinator",
                    "federated_ready": True,
                    "p2p_enabled": self.p2p_enabled
                }
            )

            # Iniciar componentes P2P si están disponibles
            if self.p2p_enabled:
                await self._start_p2p_network()

            logger.info(f"✅ Modelo base EmpoorioLM inicializado: {version_id}")
            return True

        except Exception as e:
            logger.error(f"❌ Error inicializando modelo base: {e}")
            return False

    async def _start_p2p_network(self):
        """Iniciar la red P2P para el coordinador."""
        try:
            if self.p2p_protocol:
                await self.p2p_protocol.start()
                logger.info("🌐 P2P network started for coordinator")

            if self.node_communicator:
                await self.node_communicator.initialize()
                logger.info("📡 Node communicator initialized")

        except Exception as e:
            logger.error(f"❌ Error starting P2P network: {e}")

    def _register_p2p_handlers(self):
        """Registrar handlers para mensajes P2P."""
        if not self.p2p_protocol:
            return

        # Handler para registro de nodos
        self.p2p_protocol.register_message_handler(
            P2PMessageType.HANDSHAKE_COMPLETE,
            self._handle_node_registration_p2p
        )

        # Handler para contribuciones de nodos
        self.p2p_protocol.register_message_handler(
            P2PMessageType.MODEL_UPDATE,
            self._handle_node_contribution_p2p
        )

        # Handler para coordinación de rondas
        self.p2p_protocol.register_message_handler(
            P2PMessageType.AGGREGATION_REQUEST,
            self._handle_round_coordination_p2p
        )

        logger.info("📨 P2P message handlers registered")

    async def create_training_session(
        self,
        session_name: str,
        num_rounds: int = 5,
        target_nodes: Optional[int] = None
    ) -> Optional[str]:
        """
        Crear una nueva sesión de entrenamiento federado.

        Args:
            session_name: Nombre descriptivo de la sesión
            num_rounds: Número de rondas de entrenamiento
            target_nodes: Número objetivo de nodos (opcional)

        Returns:
            ID de la sesión creada o None si falló
        """
        try:
            session_id = f"empoorio_lm_session_{int(time.time())}_{hashlib.md5(session_name.encode()).hexdigest()[:8]}"

            session = EmpoorioLMTrainingSession(
                session_id=session_id,
                model_version="v1.0.0",
                start_time=time.time(),
                num_rounds=num_rounds,
                status="waiting_for_nodes"
            )

            self.active_sessions[session_id] = session
            self.total_sessions_created += 1

            # Guardar estado de la sesión
            await self._save_session_state(session)

            logger.info(f"✅ Sesión de entrenamiento creada: {session_id} ({num_rounds} rondas)")
            return session_id

        except Exception as e:
            logger.error(f"❌ Error creando sesión: {e}")
            return None

    async def register_node(
        self,
        session_id: str,
        node_id: str,
        node_info: Dict[str, Any]
    ) -> bool:
        """
        Registrar un nodo en una sesión de entrenamiento.

        Args:
            session_id: ID de la sesión
            node_id: ID del nodo
            node_info: Información del nodo (hardware, capacidad, etc.)

        Returns:
            True si se registró correctamente
        """
        if session_id not in self.active_sessions:
            logger.error(f"❌ Sesión no encontrada: {session_id}")
            return False

        session = self.active_sessions[session_id]

        if node_id in session.registered_nodes:
            logger.warning(f"⚠️ Nodo ya registrado: {node_id}")
            return True

        # Validar información del nodo
        if not self._validate_node_info(node_info):
            logger.error(f"❌ Información de nodo inválida: {node_id}")
            return False

        # Registrar nodo
        session.registered_nodes[node_id] = {
            "node_info": node_info,
            "registered_at": time.time(),
            "status": "registered",
            "contributions": 0,
            "last_activity": time.time()
        }

        session.active_nodes[node_id] = session.registered_nodes[node_id]
        self.total_nodes_registered += 1

        # Si P2P está habilitado, registrar peer en la red P2P
        if self.p2p_enabled and self.p2p_protocol:
            await self._register_node_in_p2p_network(session_id, node_id, node_info)

        # Verificar si podemos iniciar la sesión
        if len(session.active_nodes) >= self.config.min_nodes_per_round:
            session.status = "ready_to_start"
            logger.info(f"🎯 Sesión {session_id} lista para iniciar ({len(session.active_nodes)} nodos)")

        # Guardar estado actualizado
        await self._save_session_state(session)

        logger.info(f"✅ Nodo registrado en sesión {session_id}: {node_id}")
        return True

    async def _register_node_in_p2p_network(self, session_id: str, node_id: str, node_info: Dict[str, Any]):
        """Registrar un nodo en la red P2P."""
        try:
            # Extraer información de conexión P2P del node_info
            p2p_host = node_info.get("p2p_host", "127.0.0.1")
            p2p_port = node_info.get("p2p_port", 8443)

            # Crear PeerInfo
            peer_info = PeerInfo(
                node_id=node_id,
                host=p2p_host,
                port=p2p_port,
                public_key=b'',  # Se obtendrá durante handshake
                connection_state=ConnectionState.DISCONNECTED
            )

            # Añadir peer a la lista conocida
            self.p2p_protocol.add_peer(peer_info)

            # Intentar conectar al peer
            await self.p2p_protocol.connect_to_peer(peer_info)

            logger.info(f"🔗 Nodo {node_id} registrado en red P2P")

        except Exception as e:
            logger.error(f"❌ Error registrando nodo {node_id} en P2P: {e}")

    def _validate_node_info(self, node_info: Dict[str, Any]) -> bool:
        """Validar información básica del nodo."""
        required_fields = ["hardware_type", "compute_capacity", "memory_gb"]

        for field in required_fields:
            if field not in node_info:
                logger.warning(f"Campo requerido faltante: {field}")
                return False

        # Validar capacidad computacional mínima
        if node_info.get("compute_capacity", 0) < 1:
            logger.warning("Capacidad computacional insuficiente")
            return False

        return True

    async def start_round(self, session_id: str) -> bool:
        """
        Iniciar una nueva ronda de entrenamiento.

        Args:
            session_id: ID de la sesión

        Returns:
            True si la ronda se inició correctamente
        """
        if session_id not in self.active_sessions:
            logger.error(f"❌ Sesión no encontrada: {session_id}")
            return False

        session = self.active_sessions[session_id]

        if session.status != "ready_to_start" and session.current_round >= session.num_rounds:
            logger.error(f"❌ No se puede iniciar ronda en estado: {session.status}")
            return False

        # Preparar nueva ronda
        session.current_round += 1
        round_num = session.current_round

        session.round_data[round_num] = {
            "start_time": time.time(),
            "status": "active",
            "node_contributions": {},
            "expected_nodes": len(session.active_nodes),
            "received_contributions": 0
        }

        session.status = "round_active"

        # Notificar a nodos vía P2P si está disponible
        if self.p2p_enabled:
            await self._notify_round_start_p2p(session_id, round_num, session.active_nodes)
        else:
            # Notificación tradicional (WebSocket/API)
            logger.info(f"🎯 Ronda {round_num} iniciada en sesión {session_id}")

        # Guardar estado
        await self._save_session_state(session)

        return True

    async def _notify_round_start_p2p(self, session_id: str, round_num: int, active_nodes: Dict[str, Any]):
        """Notificar inicio de ronda vía P2P."""
        try:
            for node_id in active_nodes.keys():
                if self.p2p_protocol and node_id in self.p2p_protocol.get_connected_peers():
                    message = P2PMessage(
                        message_id=f"round_start_{session_id}_{round_num}_{node_id}_{int(time.time())}",
                        message_type=P2PMessageType.AGGREGATION_REQUEST,
                        sender_id=self.config.coordinator_id,
                        receiver_id=node_id,
                        timestamp=time.time(),
                        payload={
                            "session_id": session_id,
                            "round_num": round_num,
                            "action": "start_round",
                            "deadline": time.time() + self.config.round_timeout_seconds,
                            "expected_contributions": len(active_nodes)
                        }
                    )

                    # Firmar mensaje
                    message.signature = self.p2p_protocol._sign_message(message)

                    # Enviar mensaje
                    await self.p2p_protocol._send_message_to_peer(node_id, message)

            logger.info(f"📡 Ronda {round_num} notificada vía P2P a {len(active_nodes)} nodos")

        except Exception as e:
            logger.error(f"❌ Error notificando ronda vía P2P: {e}")

    async def submit_node_contribution(
        self,
        session_id: str,
        node_id: str,
        model_weights: Dict[str, Any],
        training_metrics: Dict[str, Any],
        training_data_stats: Optional[Dict[str, Any]] = None,
        training_parameters: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Recibir contribución de un nodo (pesos entrenados) con verificación ZKP.

        Args:
            session_id: ID de la sesión
            node_id: ID del nodo
            model_weights: Pesos del modelo entrenado
            training_metrics: Métricas de entrenamiento
            training_data_stats: Estadísticas de los datos de entrenamiento (requerido para ZKP)
            training_parameters: Parámetros de entrenamiento especificados (requerido para ZKP)

        Returns:
            True si la contribución fue aceptada y verificada
        """
        if session_id not in self.active_sessions:
            logger.error(f"❌ Sesión no encontrada: {session_id}")
            return False

        session = self.active_sessions[session_id]

        if node_id not in session.active_nodes:
            logger.error(f"❌ Nodo no registrado en sesión: {node_id}")
            return False

        round_num = session.current_round
        if round_num not in session.round_data:
            logger.error(f"❌ Ronda no activa: {round_num}")
            return False

        # Validación básica inicial
        if not self._validate_contribution(model_weights, training_metrics):
            logger.error(f"❌ Contribución inválida de nodo: {node_id}")
            return False

        # Generar TrainingProof si ZKP está habilitado
        training_proof = None
        verification_result = None

        if self.zkp_enabled and self.training_prover and self.contribution_verifier:
            try:
                # Preparar datos para ZKP
                data_stats = training_data_stats or self._extract_training_data_stats(training_metrics)
                train_params = training_parameters or self._extract_training_parameters(training_metrics)

                # Generar prueba de entrenamiento
                training_proof = await self._generate_training_proof(
                    node_id, session_id, round_num, data_stats, train_params,
                    training_metrics, model_weights
                )

                if training_proof:
                    # Verificar la contribución usando ZKP
                    verification_result = await self._verify_contribution_with_zkp(
                        node_id, session_id, round_num, training_proof,
                        model_weights, training_metrics
                    )

                    if not verification_result or not verification_result.is_valid:
                        logger.error(f"❌ Verificación ZKP fallida para nodo {node_id}: {verification_result.failure_reasons if verification_result else 'Sin resultado'}")
                        return False

                    logger.info(f"✅ Verificación ZKP exitosa para nodo {node_id} (confianza: {verification_result.confidence_score:.2f})")
                else:
                    logger.warning(f"⚠️ No se pudo generar TrainingProof para nodo {node_id}, continuando sin ZKP")
            except Exception as e:
                logger.error(f"❌ Error en verificación ZKP para nodo {node_id}: {e}")
                if self.zkp_enabled:
                    # Si ZKP es requerido, fallar la contribución
                    return False

        # Almacenar contribución con información ZKP
        contribution_data = {
            "weights": model_weights,
            "metrics": training_metrics,
            "submitted_at": time.time(),
            "node_info": session.active_nodes[node_id],
            "data_fingerprint": training_metrics.get("data_fingerprint", self._generate_data_fingerprint(training_metrics)),
            "zkp_enabled": self.zkp_enabled,
            "training_proof": training_proof,
            "verification_result": verification_result
        }

        session.round_data[round_num]["node_contributions"][node_id] = contribution_data

        session.round_data[round_num]["received_contributions"] += 1
        session.active_nodes[node_id]["contributions"] += 1
        session.active_nodes[node_id]["last_activity"] = time.time()

        session.total_contributions += 1
        self.total_contributions_processed += 1

        # Actualizar estadísticas globales
        session.total_training_time += training_metrics.get("training_time", 0)
        session.total_samples_processed += training_metrics.get("samples_processed", 0)

        logger.info(f"✅ Contribución recibida y verificada de {node_id} en ronda {round_num}")

        # Verificar si la ronda está completa
        await self._check_round_completion(session)

        # Guardar estado
        await self._save_session_state(session)

        return True

    async def submit_node_contribution_p2p(self, message: P2PMessage) -> bool:
        """
        Recibir contribución de un nodo vía P2P.

        Args:
            message: Mensaje P2P con la contribución

        Returns:
            True si la contribución fue aceptada
        """
        try:
            payload = message.payload
            session_id = payload.get("session_id")
            node_id = message.sender_id
            model_weights = payload.get("model_weights", {})
            training_metrics = payload.get("training_metrics", {})

            # Usar el método estándar de contribución
            return await self.submit_node_contribution(session_id, node_id, model_weights, training_metrics)

        except Exception as e:
            logger.error(f"❌ Error procesando contribución P2P de {message.sender_id}: {e}")
            return False

    def _validate_contribution(
        self,
        model_weights: Dict[str, Any],
        training_metrics: Dict[str, Any]
    ) -> bool:
        """Validar que la contribución del nodo sea válida."""
        # Verificar que tenga pesos
        if not model_weights or not isinstance(model_weights, dict):
            return False

        # Verificar métricas básicas
        required_metrics = ["accuracy", "loss", "training_time"]
        for metric in required_metrics:
            if metric not in training_metrics:
                return False

        # Verificar rangos razonables
        if not (0 <= training_metrics["accuracy"] <= 1):
            return False

        if training_metrics["loss"] < 0:
            return False

        if training_metrics["training_time"] <= 0:
            return False

        return True

    async def _check_round_completion(self, session: EmpoorioLMTrainingSession):
        """Verificar si una ronda está completa y proceder con la agregación."""
        round_num = session.current_round
        round_data = session.round_data[round_num]

        expected = round_data["expected_nodes"]
        received = round_data["received_contributions"]

        if received >= min(expected, self.config.min_contributions_per_round):
            # Ronda completa - proceder con agregación
            logger.info(f"🎯 Ronda {round_num} completa ({received}/{expected} contribuciones)")

            round_data["status"] = "aggregating"
            round_data["end_time"] = time.time()

            # Agregar pesos
            success = await self._aggregate_round_contributions(session, round_num)

            if success:
                round_data["status"] = "completed"

                # Verificar si la sesión está completa
                if round_num >= session.num_rounds:
                    await self._complete_session(session)
                else:
                    # Preparar siguiente ronda
                    session.status = "ready_to_start"
            else:
                round_data["status"] = "aggregation_failed"
                logger.error(f"❌ Falló agregación en ronda {round_num}")

    async def _aggregate_round_contributions(
        self,
        session: EmpoorioLMTrainingSession,
        round_num: int
    ) -> bool:
        """
        Agregar las contribuciones de una ronda.

        Args:
            session: Sesión de entrenamiento
            round_num: Número de ronda

        Returns:
            True si la agregación fue exitosa
        """
        try:
            round_data = session.round_data[round_num]
            contributions = round_data["node_contributions"]

            if len(contributions) < self.config.min_contributions_per_round:
                logger.error(f"Insuficientes contribuciones para ronda {round_num}")
                return False

            # Extraer pesos y métricas
            node_weights = {}
            node_metrics = {}

            for node_id, contribution in contributions.items():
                node_weights[node_id] = contribution["weights"]
                node_metrics[node_id] = contribution["metrics"]

            # Usar agregación segura si está habilitada
            if self.config.enable_secure_aggregation and self.p2p_protocol:
                success = await self._aggregate_secure_round_contributions(session, round_num, node_weights, node_metrics)
            else:
                # Agregación estándar
                success = await self._aggregate_standard_round_contributions(session, round_num, node_weights, node_metrics)

            if success:
                # Distribuir modelo actualizado vía P2P si está disponible
                if self.p2p_enabled:
                    await self._distribute_updated_model_p2p(session, round_num)

            return success

        except Exception as e:
            logger.error(f"❌ Error en agregación: {e}")
            return False

    async def _aggregate_standard_round_contributions(
        self,
        session: EmpoorioLMTrainingSession,
        round_num: int,
        node_weights: Dict[str, Any],
        node_metrics: Dict[str, Any]
    ) -> bool:
        """Agregación estándar de contribuciones."""
        # Agregar pesos usando el aggregator
        aggregated_weights = await self.aggregator.aggregate_weights(
            node_weights=node_weights,
            aggregation_method=self.config.aggregation_method,
            quality_weights=self._calculate_quality_weights(node_metrics)
        )

        if aggregated_weights is None:
            logger.error("Falló agregación de pesos")
            return False

        # Actualizar modelo global
        session.global_weights = aggregated_weights

        # Crear nueva versión del modelo
        version_name = f"v1.0.{round_num}"
        description = f"EmpoorioLM {version_name} - Ronda {round_num} federada"

        version_id = await self.version_manager.create_version(
            model_weights=aggregated_weights,
            version_name=version_name,
            description=description,
            metadata={
                "session_id": session.session_id,
                "round": round_num,
                "num_contributions": len(node_weights),
                "aggregation_method": self.config.aggregation_method,
                "federated_training": True,
                "secure_aggregation": False
            }
        )

        session.global_model_path = version_id
        logger.info(f"✅ Modelo agregado y versionado: {version_name}")
        return True

    async def _aggregate_secure_round_contributions(
        self,
        session: EmpoorioLMTrainingSession,
        round_num: int,
        node_weights: Dict[str, Any],
        node_metrics: Dict[str, Any]
    ) -> bool:
        """Agregación segura de contribuciones usando SecureAggregationProtocol."""
        try:
            # Iniciar sesión de agregación segura
            aggregation_id = await self.p2p_protocol.initiate_secure_aggregation(
                session_id=session.session_id,
                participants=list(node_weights.keys()),
                aggregation_type="fedavg"
            )

            if not aggregation_id:
                logger.error("Falló iniciar agregación segura")
                return False

            # Esperar a que se complete la agregación segura
            # (En implementación real, esto sería asíncrono con callbacks)
            await asyncio.sleep(5)  # Simular tiempo de agregación

            # Por ahora, usar agregación estándar como fallback
            # TODO: Implementar recuperación de resultados de agregación segura
            return await self._aggregate_standard_round_contributions(session, round_num, node_weights, node_metrics)

        except Exception as e:
            logger.error(f"❌ Error en agregación segura: {e}")
            # Fallback a agregación estándar
            return await self._aggregate_standard_round_contributions(session, round_num, node_weights, node_metrics)

    async def _distribute_updated_model_p2p(self, session: EmpoorioLMTrainingSession, round_num: int):
        """Distribuir modelo actualizado vía P2P."""
        try:
            if not session.global_weights or not self.p2p_protocol:
                return

            # Crear mensaje de actualización de modelo
            for node_id in session.active_nodes.keys():
                if node_id in self.p2p_protocol.get_connected_peers():
                    message = P2PMessage(
                        message_id=f"model_update_{session.session_id}_{round_num}_{node_id}_{int(time.time())}",
                        message_type=P2PMessageType.MODEL_UPDATE,
                        sender_id=self.config.coordinator_id,
                        receiver_id=node_id,
                        timestamp=time.time(),
                        payload={
                            "session_id": session.session_id,
                            "round_num": round_num,
                            "model_weights": session.global_weights,
                            "model_version": session.global_model_path,
                            "metadata": {
                                "aggregation_method": self.config.aggregation_method,
                                "secure_aggregation": self.config.enable_secure_aggregation
                            }
                        }
                    )

                    # Firmar mensaje
                    message.signature = self.p2p_protocol._sign_message(message)

                    # Enviar mensaje
                    await self.p2p_protocol._send_message_to_peer(node_id, message)

            logger.info(f"📤 Modelo actualizado distribuido vía P2P a {len(session.active_nodes)} nodos")

        except Exception as e:
            logger.error(f"❌ Error distribuyendo modelo vía P2P: {e}")

    def _calculate_quality_weights(self, node_metrics: Dict[str, Dict[str, Any]]) -> Dict[str, float]:
        """Calcular pesos de calidad para la agregación basada en métricas."""
        quality_weights = {}

        for node_id, metrics in node_metrics.items():
            # Peso basado en accuracy y estabilidad
            accuracy_weight = metrics.get("accuracy", 0.5)
            loss_weight = 1.0 / (1.0 + metrics.get("loss", 1.0))  # Menor loss = mayor peso

            # Combinar métricas
            quality_weights[node_id] = (accuracy_weight + loss_weight) / 2.0

        return quality_weights

    async def _complete_session(self, session: EmpoorioLMTrainingSession):
        """Completar una sesión de entrenamiento."""
        session.status = "completed"
        session.end_time = time.time()

        # Mover a sesiones completadas
        self.completed_sessions[session.session_id] = session
        del self.active_sessions[session.session_id]

        # Crear resumen final
        summary = {
            "session_id": session.session_id,
            "total_rounds": session.num_rounds,
            "final_model_version": session.global_model_path,
            "total_contributions": session.total_contributions,
            "total_training_time": session.total_training_time,
            "total_samples_processed": session.total_samples_processed,
            "active_nodes": len(session.active_nodes),
            "completion_time": session.end_time - session.start_time
        }

        # Guardar resumen
        summary_path = Path(self.config.sessions_dir) / f"{session.session_id}_summary.json"
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2, default=str)

        logger.info(f"🎉 Sesión completada: {session.session_id}")
        logger.info(f"📊 Resumen: {summary}")

    async def _save_session_state(self, session: EmpoorioLMTrainingSession):
        """Guardar estado de la sesión en disco."""
        session_path = Path(self.config.sessions_dir) / f"{session.session_id}_state.json"

        # Convertir a diccionario serializable
        session_dict = {
            "session_id": session.session_id,
            "model_version": session.model_version,
            "start_time": session.start_time,
            "num_rounds": session.num_rounds,
            "current_round": session.current_round,
            "status": session.status,
            "registered_nodes": session.registered_nodes,
            "active_nodes": session.active_nodes,
            "round_data": session.round_data,
            "total_contributions": session.total_contributions,
            "total_training_time": session.total_training_time,
            "total_samples_processed": session.total_samples_processed,
            "global_model_path": session.global_model_path
        }

        with open(session_path, 'w') as f:
            json.dump(session_dict, f, indent=2, default=str)

    def get_session_status(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Obtener estado de una sesión."""
        session = self.active_sessions.get(session_id) or self.completed_sessions.get(session_id)
        if not session:
            return None

        return {
            "session_id": session.session_id,
            "status": session.status,
            "current_round": session.current_round,
            "total_rounds": session.num_rounds,
            "active_nodes": len(session.active_nodes),
            "total_contributions": session.total_contributions,
            "progress": session.current_round / session.num_rounds if session.num_rounds > 0 else 0
        }

    def _generate_data_fingerprint(self, training_metrics: Dict[str, Any]) -> str:
        """
        Generar un fingerprint único de los datos de entrenamiento.

        Args:
            training_metrics: Métricas de entrenamiento que incluyen información de datos

        Returns:
            Hash SHA256 que representa los datos de entrenamiento
        """
        # Crear una representación canónica de los datos de entrenamiento
        data_components = []

        # Incluir métricas que identifican los datos
        data_components.append(f"samples:{training_metrics.get('samples_processed', 0)}")
        data_components.append(f"accuracy:{training_metrics.get('accuracy', 0):.6f}")
        data_components.append(f"loss:{training_metrics.get('loss', 0):.6f}")
        data_components.append(f"training_time:{training_metrics.get('training_time', 0):.2f}")

        # Incluir información adicional si está disponible
        if "dataset_hash" in training_metrics:
            data_components.append(f"dataset_hash:{training_metrics['dataset_hash']}")
        if "data_size" in training_metrics:
            data_components.append(f"data_size:{training_metrics['data_size']}")
        if "batch_size" in training_metrics:
            data_components.append(f"batch_size:{training_metrics['batch_size']}")

        # Crear string canónico y hashear
        canonical_string = "|".join(data_components)
        fingerprint = hashlib.sha256(canonical_string.encode('utf-8')).hexdigest()

        logger.debug(f"📋 Generado data fingerprint: {fingerprint[:16]}...")
        return fingerprint

    async def _generate_training_proof(
        self,
        node_id: str,
        session_id: str,
        round_number: int,
        training_data_stats: Dict[str, Any],
        training_parameters: Dict[str, Any],
        training_results: Dict[str, Any],
        model_parameters: Dict[str, Any]
    ) -> Optional[TrainingProof]:
        """
        Generar una prueba ZKP de entrenamiento para un nodo.

        Args:
            node_id: ID del nodo
            session_id: ID de la sesión
            round_number: Número de ronda
            training_data_stats: Estadísticas de datos de entrenamiento
            training_parameters: Parámetros de entrenamiento
            training_results: Resultados del entrenamiento
            model_parameters: Parámetros del modelo

        Returns:
            TrainingProof o None si falla
        """
        if not self.training_prover:
            logger.warning("TrainingProver no disponible para generar prueba")
            return None

        try:
            # Crear metadatos adicionales para la prueba
            training_metadata = {
                "session_id": session_id,
                "round_number": round_number,
                "coordinator_id": self.config.coordinator_id,
                "zkp_enabled": True,
                "federated_round": round_number
            }

            # Generar la prueba usando el TrainingProver
            proof = await self.training_prover.generate_training_proof(
                node_id=node_id,
                session_id=session_id,
                round_number=round_number,
                training_data_stats=training_data_stats,
                training_parameters=TrainingParameters(**training_parameters),
                training_results=training_results,
                model_parameters=model_parameters,
                training_metadata=training_metadata
            )

            logger.info(f"🔐 TrainingProof generada para nodo {node_id}: {proof.proof_id}")
            return proof

        except Exception as e:
            logger.error(f"❌ Error generando TrainingProof para nodo {node_id}: {e}")
            return None

    async def _verify_contribution_with_zkp(
        self,
        node_id: str,
        session_id: str,
        round_number: int,
        training_proof: TrainingProof,
        model_parameters: Dict[str, Any],
        training_metadata: Dict[str, Any]
    ) -> Optional[VerificationResult]:
        """
        Verificar una contribución usando ZKP.

        Args:
            node_id: ID del nodo
            session_id: ID de la sesión
            round_number: Número de ronda
            training_proof: Prueba ZKP de entrenamiento
            model_parameters: Parámetros del modelo
            training_metadata: Metadatos del entrenamiento

        Returns:
            VerificationResult o None si falla
        """
        if not self.contribution_verifier:
            logger.warning("ContributionVerifier no disponible para verificación")
            return None

        try:
            # Crear ID único para la contribución
            contribution_id = f"{node_id}_{session_id}_{round_number}_{int(time.time())}"

            # Obtener contexto de sesión para verificación mejorada
            session_context = self._get_session_context_for_verification(session_id)

            # Verificar la contribución
            verification_result = await self.contribution_verifier.verify_contribution(
                node_id=node_id,
                session_id=session_id,
                round_number=round_number,
                contribution_id=contribution_id,
                training_proof=training_proof,
                model_parameters=model_parameters,
                training_metadata=training_metadata,
                session_context=session_context
            )

            logger.info(f"🔍 Verificación ZKP completada para {node_id}: {'VÁLIDA' if verification_result.is_valid else 'INVÁLIDA'}")
            return verification_result

        except Exception as e:
            logger.error(f"❌ Error verificando contribución ZKP para nodo {node_id}: {e}")
            return None

    def _extract_training_data_stats(self, training_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extraer estadísticas de datos de entrenamiento de las métricas.

        Args:
            training_metrics: Métricas de entrenamiento

        Returns:
            Estadísticas de datos estructuradas
        """
        return {
            'num_samples': training_metrics.get('samples_processed', 1000),
            'data_variance': training_metrics.get('data_variance', 0.5),
            'distribution_hash': training_metrics.get('dataset_hash', ''),
            'data_size_mb': training_metrics.get('data_size_mb', 10.0)
        }

    def _extract_training_parameters(self, training_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extraer parámetros de entrenamiento de las métricas.

        Args:
            training_metrics: Métricas de entrenamiento

        Returns:
            Parámetros de entrenamiento estructurados
        """
        return {
            'epochs': training_metrics.get('epochs_completed', 1),
            'batch_size': training_metrics.get('batch_size_used', 32),
            'learning_rate': training_metrics.get('learning_rate', 0.001),
            'optimizer': training_metrics.get('optimizer', 'adam'),
            'loss_function': training_metrics.get('loss_function', 'cross_entropy'),
            'min_accuracy_threshold': training_metrics.get('min_accuracy_threshold', 0.5),
            'max_training_time': training_metrics.get('max_training_time', 3600),
            'required_data_samples': training_metrics.get('required_samples', 100)
        }

    def _get_session_context_for_verification(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Obtener contexto de sesión para mejorar la verificación.

        Args:
            session_id: ID de la sesión

        Returns:
            Contexto de sesión o None
        """
        if session_id not in self.active_sessions:
            return None

        session = self.active_sessions[session_id]
        return {
            'session_id': session.session_id,
            'current_round': session.current_round,
            'total_nodes': len(session.active_nodes),
            'session_start_time': session.start_time,
            'round_start_time': session.round_data.get(session.current_round, {}).get('start_time')
        }

    def get_coordinator_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas del coordinador."""
        stats = {
            "active_sessions": len(self.active_sessions),
            "completed_sessions": len(self.completed_sessions),
            "total_sessions_created": self.total_sessions_created,
            "total_nodes_registered": self.total_nodes_registered,
            "total_contributions_processed": self.total_contributions_processed,
            "current_model_version": self.version_manager.get_latest_version(),
            "p2p_enabled": self.p2p_enabled,
            "zkp_enabled": self.zkp_enabled
        }

        # Añadir estadísticas P2P si están disponibles
        if self.p2p_protocol:
            p2p_stats = self.p2p_protocol.get_stats()
            stats.update({
                "p2p_connected_peers": len(self.p2p_protocol.get_connected_peers()),
                "p2p_messages_sent": p2p_stats.get("messages_sent", 0),
                "p2p_messages_received": p2p_stats.get("messages_received", 0),
                "p2p_handshakes_completed": p2p_stats.get("handshakes_completed", 0)
            })

        # Añadir estadísticas ZKP si están disponibles
        if self.contribution_verifier:
            zkp_stats = self.contribution_verifier.get_verifier_stats()
            stats.update({
                "zkp_verifications_total": zkp_stats.get("verification_stats", {}).get("total_verifications", 0),
                "zkp_verifications_successful": zkp_stats.get("verification_stats", {}).get("successful_verifications", 0),
                "zkp_verifications_failed": zkp_stats.get("verification_stats", {}).get("failed_verifications", 0),
                "zkp_average_verification_time_ms": zkp_stats.get("verification_stats", {}).get("average_verification_time_ms", 0.0),
                "zkp_cached_results": zkp_stats.get("cache_stats", {}).get("cached_results", 0)
            })

        if self.training_prover:
            prover_stats = self.training_prover.get_prover_stats()
            stats.update({
                "zkp_proofs_generated": prover_stats.get("total_training_proofs", 0),
                "zkp_proofs_verified": prover_stats.get("verified_training_proofs", 0),
                "zkp_average_proof_time_ms": prover_stats.get("average_verification_time_ms", 0.0)
            })

        return stats

    # Handlers para mensajes P2P

    async def _handle_node_registration_p2p(self, message: P2PMessage):
        """Manejar registro de nodo vía P2P."""
        try:
            payload = message.payload
            node_id = message.sender_id
            session_id = payload.get("session_id")
            node_info = payload.get("node_info", {})

            logger.info(f"📝 Nodo {node_id} registrándose vía P2P en sesión {session_id}")

            # Registrar nodo usando el método estándar
            success = await self.register_node(session_id, node_id, node_info)

            if success:
                # Enviar confirmación
                response = P2PMessage(
                    message_id=f"registration_ack_{node_id}_{int(time.time())}",
                    message_type=P2PMessageType.HANDSHAKE_COMPLETE,
                    sender_id=self.config.coordinator_id,
                    receiver_id=node_id,
                    timestamp=time.time(),
                    payload={
                        "status": "registered",
                        "session_id": session_id,
                        "coordinator_id": self.config.coordinator_id
                    }
                )

                if self.p2p_protocol:
                    response.signature = self.p2p_protocol._sign_message(response)
                    await self.p2p_protocol._send_message_to_peer(node_id, response)

        except Exception as e:
            logger.error(f"❌ Error manejando registro P2P de {message.sender_id}: {e}")

    async def _handle_node_contribution_p2p(self, message: P2PMessage):
        """Manejar contribución de nodo vía P2P."""
        try:
            await self.submit_node_contribution_p2p(message)
        except Exception as e:
            logger.error(f"❌ Error manejando contribución P2P de {message.sender_id}: {e}")

    async def _handle_round_coordination_p2p(self, message: P2PMessage):
        """Manejar coordinación de rondas vía P2P."""
        try:
            payload = message.payload
            action = payload.get("action")

            if action == "round_complete":
                # Un nodo indica que completó su ronda
                session_id = payload.get("session_id")
                node_id = message.sender_id

                logger.info(f"✅ Nodo {node_id} completó ronda en sesión {session_id}")

                # Aquí podríamos implementar lógica adicional para coordinación distribuida
                # Por ahora, solo logueamos

        except Exception as e:
            logger.error(f"❌ Error manejando coordinación de ronda P2P de {message.sender_id}: {e}")


# Funciones de conveniencia
async def create_empoorio_lm_coordinator(
    coordinator_config: Optional[EmpoorioLMCoordinatorConfig] = None
) -> EmpoorioLMCoordinator:
    """Crear instancia del coordinador EmpoorioLM."""
    if coordinator_config is None:
        coordinator_config = EmpoorioLMCoordinatorConfig()

    coordinator = EmpoorioLMCoordinator(coordinator_config)

    # Inicializar modelo base
    await coordinator.initialize_base_model()

    return coordinator