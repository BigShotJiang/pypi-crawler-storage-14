"""
Model Service - Gestión completa de modelos en el coordinador.
Implementación real para operaciones CRUD de modelos.
"""

import uuid
import hashlib
import os
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc

from ...core.logging import get_logger
from ..models.base import Model
from ..models.schemas import ModelCreate, ModelUpdate, ModelUpload
from enum import Enum


class ModelStatus(str, Enum):
    """Estados posibles de un modelo."""
    CREATED = "created"
    TRAINING = "training"
    TRAINED = "trained"
    PUBLISHED = "published"
    ARCHIVED = "archived"
    FAILED = "failed"
from ...infrastructure.ipfs_embedded import IPFSManager
from ..core.exceptions import CoordinatorException

logger = get_logger(__name__)


class ModelService:
    """
    Servicio completo para gestión de modelos.
    Maneja operaciones CRUD, versionado, publicación y métricas.
    """

    def __init__(self):
        self.ipfs_manager: Optional[IPFSManager] = None

    async def initialize(self):
        """Inicializar el servicio con dependencias."""
        # Inicializar IPFS Manager
        try:
            self.ipfs_manager = IPFSManager()
            await self.ipfs_manager.start()
            logger.info("✅ IPFS Manager initialized and started for Model Service.")
        except Exception as e:
            logger.error(f"❌ Failed to initialize IPFS Manager for Model Service: {e}")
            # Decide whether to raise or continue with degraded functionality
            raise CoordinatorException(f"IPFS Manager initialization failed: {e}", status_code=500)
        
        logger.info("✅ Model service initialized")

    async def create_model(self, db: Session, model_data: ModelCreate, created_by: str) -> Model:
        """
        Crear un nuevo modelo.

        Args:
            db: Sesión de base de datos
            model_data: Datos del modelo a crear
            created_by: ID del usuario/admin que crea el modelo

        Returns:
            Modelo creado
        """
        try:
            # Generar ID único
            model_id = str(uuid.uuid4())

            # Crear modelo en BD
            db_model = Model(
                id=model_id,
                name=model_data.name,
                model_type=model_data.model_type,
                version=model_data.version or "1.0.0",
                status=ModelStatus.CREATED.value,
                is_public=False,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                architecture=model_data.config or {},
                hyperparameters={},
                metrics=model_data.metrics or {}
            )

            db.add(db_model)
            db.commit()
            db.refresh(db_model)

            logger.info(f"✅ Model created: {model_id} - {model_data.name}")
            return db_model

        except Exception as e:
            # Solo hacer rollback si la sesión lo soporta
            if hasattr(db, 'rollback'):
                db.rollback()
            logger.error(f"❌ Error creating model: {e}")
            raise CoordinatorException(f"Error creating model: {str(e)}", status_code=500)

    def _validate_model_file(self, filename: str) -> bool:
        """Validate model file extension."""
        allowed_extensions = {'.pkl', '.h5', '.pt', '.onnx', '.pb', '.tflite', '.joblib'}
        _, ext = os.path.splitext(filename.lower())
        return ext in allowed_extensions

    def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of file."""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()

    async def upload_model(self, db: Session, model_upload: ModelUpload, uploaded_by: str) -> Model:
        """
        Upload and store a model file.

        Args:
            db: Database session
            model_upload: Model upload data with file
            uploaded_by: ID of the user/node uploading

        Returns:
            Created model with file stored
        """
        try:
            # Validate file extension
            if not self._validate_model_file(model_upload.file.filename):
                raise CoordinatorException(
                    f"Invalid file type. Allowed: .pkl, .h5, .pt, .onnx, .pb, .tflite, .joblib",
                    status_code=400
                )

            # Create models directory if not exists
            models_dir = Path("data/models")
            models_dir.mkdir(parents=True, exist_ok=True)

            # Generate unique filename
            model_id = str(uuid.uuid4())
            file_extension = os.path.splitext(model_upload.file.filename)[1]
            filename = f"{model_id}{file_extension}"
            file_path = models_dir / filename

            # Save file temporarily to calculate hash
            temp_path = file_path.with_suffix('.tmp')
            with open(temp_path, "wb") as buffer:
                content = await model_upload.file.read()
                buffer.write(content)

            # Calculate file hash and size
            file_hash = self._calculate_file_hash(str(temp_path))
            file_size = temp_path.stat().st_size

            # Move to final location
            temp_path.rename(file_path)

            # Store in IPFS if available
            ipfs_cid = None
            if self.ipfs_manager:
                try:
                    ipfs_cid = await self.ipfs_manager.publish_file(str(file_path), {"model_id": model_id})
                    logger.info(f"✅ Model {model_id} stored in IPFS with CID: {ipfs_cid}")
                except Exception as e:
                    logger.warning(f"⚠️ Failed to store model {model_id} in IPFS: {e}")

            # Create model record
            db_model = Model(
                id=model_id,
                name=model_upload.name,
                model_type=model_upload.model_type,
                description=model_upload.description,
                version=model_upload.version or "1.0.0",
                tags=model_upload.tags or [],
                status=ModelStatus.CREATED.value,
                is_public=False,
                storage_location=str(file_path),
                ipfs_cid=ipfs_cid,
                file_hash=file_hash,
                file_size=file_size,
                owner_node_id=uploaded_by,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )

            db.add(db_model)
            db.commit()
            db.refresh(db_model)

            logger.info(f"✅ Model uploaded: {model_id} - {model_upload.name} ({file_size} bytes)")
            return db_model

        except CoordinatorException:
            raise
        except Exception as e:
            if hasattr(db, 'rollback'):
                db.rollback()
            logger.error(f"❌ Error uploading model: {e}")
            raise CoordinatorException(f"Error uploading model: {str(e)}", status_code=500)

    def get_model(self, db: Session, model_id: str) -> Optional[Model]:
        """
        Obtener un modelo por ID.

        Args:
            db: Sesión de base de datos
            model_id: ID del modelo

        Returns:
            Modelo o None si no existe
        """
        return db.query(Model).filter(Model.id == model_id).first()

    def list_models(
        self,
        db: Session,
        skip: int = 0,
        limit: int = 100,
        model_type: Optional[str] = None,
        session_id: Optional[str] = None,
        is_public: Optional[bool] = None,
        status: Optional[str] = None,
        created_by: Optional[str] = None
    ) -> List[Model]:
        """
        Listar modelos con filtros opcionales.

        Args:
            db: Sesión de base de datos
            skip: Número de registros a saltar
            limit: Número máximo de registros
            model_type: Filtrar por tipo de modelo
            session_id: Filtrar por ID de sesión
            is_public: Filtrar por visibilidad pública
            status: Filtrar por estado
            created_by: Filtrar por creador

        Returns:
            Lista de modelos
        """
        query = db.query(Model)

        # Aplicar filtros
        if model_type:
            query = query.filter(Model.model_type == model_type)
        if session_id:
            query = query.filter(Model.session_id == session_id)
        if is_public is not None:
            query = query.filter(Model.is_public == is_public)
        if status:
            query = query.filter(Model.status == status)
        if created_by:
            query = query.filter(Model.created_by == created_by)

        # Ordenar por fecha de creación (más recientes primero)
        query = query.order_by(desc(Model.created_at))

        return query.offset(skip).limit(limit).all()

    async def update_model(self, db: Session, model_id: str, model_update: ModelUpdate, updated_by: str) -> Model:
        """
        Actualizar un modelo.

        Args:
            db: Sesión de base de datos
            model_id: ID del modelo
            model_update: Datos a actualizar
            updated_by: ID del usuario que actualiza

        Returns:
            Modelo actualizado
        """
        try:
            model = self.get_model(db, model_id)
            if not model:
                raise CoordinatorException(f"Model {model_id} not found", status_code=404)

            # Actualizar campos
            update_data = model_update.dict(exclude_unset=True)
            for field, value in update_data.items():
                if hasattr(model, field):
                    setattr(model, field, value)

            model.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(model)

            logger.info(f"✅ Model updated: {model_id}")
            return model

        except CoordinatorException:
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"❌ Error updating model: {e}")
            raise CoordinatorException(f"Error updating model: {str(e)}", status_code=500)

    async def delete_model(self, db: Session, model_id: str) -> bool:
        """
        Eliminar un modelo.

        Args:
            db: Sesión de base de datos
            model_id: ID del modelo

        Returns:
            True si se eliminó correctamente
        """
        try:
            model = self.get_model(db, model_id)
            if not model:
                raise CoordinatorException(f"Model {model_id} not found", status_code=404)

            # Si el modelo está publicado en IPFS, intentar despinear
            if model.ipfs_cid and self.ipfs_manager:
                try:
                    await self.ipfs_manager.unpin_content(model.ipfs_cid)
                except Exception as e:
                    logger.warning(f"⚠️ Could not unpin model {model_id} from IPFS: {e}")

            db.delete(model)
            db.commit()

            logger.info(f"✅ Model deleted: {model_id}")
            return True

        except CoordinatorException:
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"❌ Error deleting model: {e}")
            raise CoordinatorException(f"Error deleting model: {str(e)}", status_code=500)

    async def publish_model(self, db: Session, model_id: str, published_by: str) -> Model:
        """
        Publicar un modelo para hacerlo públicamente disponible.

        Args:
            db: Sesión de base de datos
            model_id: ID del modelo
            published_by: ID del usuario que publica

        Returns:
            Modelo publicado
        """
        try:
            model = self.get_model(db, model_id)
            if not model:
                raise CoordinatorException(f"Model {model_id} not found", status_code=404)

            if model.status != ModelStatus.TRAINED:
                raise CoordinatorException(f"Model {model_id} is not trained yet", status_code=400)

            # Publicar en IPFS si no está ya publicado
            if not model.ipfs_cid:
                if not self.ipfs_manager:
                    raise CoordinatorException("IPFS Manager not initialized", status_code=500)
                
                if not model.storage_location:
                    raise CoordinatorException(f"Model {model_id} has no storage location defined.", status_code=400)

                # Usar el path real del modelo
                real_model_path = Path(model.storage_location)
                if not real_model_path.exists():
                    raise CoordinatorException(f"Model file not found at {real_model_path}", status_code=404)

                model.ipfs_cid = await self.ipfs_manager.publish_file(str(real_model_path), model_metadata={"model_id": model_id})
                logger.info(f"✅ Model {model_id} published to IPFS with CID: {model.ipfs_cid}")

            model.is_public = True
            model.published_at = datetime.utcnow()
            model.published_by = published_by
            model.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(model)

            logger.info(f"✅ Model published: {model_id}")
            return model

        except CoordinatorException:
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"❌ Error publishing model: {e}")
            raise CoordinatorException(f"Error publishing model: {str(e)}", status_code=500)

    async def unpublish_model(self, db: Session, model_id: str) -> Model:
        """
        Despublicar un modelo.

        Args:
            db: Sesión de base de datos
            model_id: ID del modelo

        Returns:
            Modelo despublicado
        """
        try:
            model = self.get_model(db, model_id)
            if not model:
                raise CoordinatorException(f"Model {model_id} not found", status_code=404)

            model.is_public = False
            model.published_at = None
            model.published_by = None
            model.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(model)

            logger.info(f"✅ Model unpublished: {model_id}")
            return model

        except CoordinatorException:
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"❌ Error unpublishing model: {e}")
            raise CoordinatorException(f"Error unpublishing model: {str(e)}", status_code=500)

    def get_models_by_session(self, db: Session, session_id: str) -> List[Model]:
        """
        Obtener todos los modelos de una sesión.

        Args:
            db: Sesión de base de datos
            session_id: ID de la sesión

        Returns:
            Lista de modelos de la sesión
        """
        return db.query(Model).filter(Model.session_id == session_id).all()

    def get_public_models(
        self,
        db: Session,
        model_type: Optional[str] = None,
        limit: int = 100
    ) -> List[Model]:
        """
        Obtener modelos públicos.

        Args:
            db: Sesión de base de datos
            model_type: Filtrar por tipo de modelo
            limit: Número máximo de modelos

        Returns:
            Lista de modelos públicos
        """
        query = db.query(Model).filter(
            and_(Model.is_public == True, Model.status == ModelStatus.TRAINED)
        )

        if model_type:
            query = query.filter(Model.model_type == model_type)

        return query.order_by(desc(Model.published_at)).limit(limit).all()

    async def update_model_metrics(
        self,
        db: Session,
        model_id: str,
        metrics: Dict[str, Any],
        global_parameters_hash: Optional[str] = None
    ) -> Model:
        """
        Actualizar métricas de un modelo.

        Args:
            db: Sesión de base de datos
            model_id: ID del modelo
            metrics: Nuevas métricas
            global_parameters_hash: Hash de parámetros globales

        Returns:
            Modelo actualizado
        """
        try:
            model = self.get_model(db, model_id)
            if not model:
                raise CoordinatorException(f"Model {model_id} not found", status_code=404)

            # Actualizar métricas
            if model.metrics:
                model.metrics.update(metrics)
            else:
                model.metrics = metrics

            if global_parameters_hash:
                model.global_parameters_hash = global_parameters_hash

            model.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(model)

            logger.info(f"✅ Model metrics updated: {model_id}")
            return model

        except CoordinatorException:
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"❌ Error updating model metrics: {e}")
            raise CoordinatorException(f"Error updating model metrics: {str(e)}", status_code=500)

    def get_model_versions(self, db: Session, name: str, model_type: str) -> List[Model]:
        """
        Obtener todas las versiones de un modelo por nombre y tipo.

        Args:
            db: Sesión de base de datos
            name: Nombre del modelo
            model_type: Tipo del modelo

        Returns:
            Lista de versiones del modelo
        """
        return db.query(Model).filter(
            and_(Model.name == name, Model.model_type == model_type)
        ).order_by(desc(Model.version)).all()

    def get_latest_model_version(self, db: Session, name: str, model_type: str) -> Optional[Model]:
        """
        Obtener la versión más reciente de un modelo.

        Args:
            db: Sesión de base de datos
            name: Nombre del modelo
            model_type: Tipo del modelo

        Returns:
            Última versión del modelo o None
        """
        return db.query(Model).filter(
            and_(Model.name == name, Model.model_type == model_type)
        ).order_by(desc(Model.version)).first()

    def get_total_models(self, db: Session) -> int:
        """Obtener el número total de modelos."""
        return db.query(Model).count()

    def get_models_by_status(self, db: Session, status: ModelStatus) -> List[Model]:
        """Obtener modelos por estado."""
        return db.query(Model).filter(Model.status == status).all()


# Instancia global del servicio
model_service = ModelService()