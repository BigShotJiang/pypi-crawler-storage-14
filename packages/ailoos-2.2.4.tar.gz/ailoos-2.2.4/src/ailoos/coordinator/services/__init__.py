"""
AILOOS Coordinator Services - FASE 4 Model Management System
Servicios completos de gestión de modelos con integración federada.
"""

# Servicios existentes (FASE 3 y anteriores)
from .model_service import model_service
from .admin_service import *
from .concurrent_download_service import *
from .contribution_service import *
from .hibernation_service import *
from .node_service import *
from .reward_service import *
from .round_service import *
from .session_service import *

# Servicios FASE 4 - Model Management
from .model_registry import ModelRegistry, ModelLineage, model_registry
from .model_lifecycle_manager import ModelLifecycleManager, LifecycleStage, LifecycleTransition, model_lifecycle_manager
from .model_validator import ModelValidator, ModelValidationType, model_validator
from .model_version_controller import ModelVersionController, VersionControlAction, model_version_controller
from .model_quality_monitor import ModelQualityMonitor, DriftType, AlertSeverity, QualityMetrics, model_quality_monitor

# Sistema integrado
from .model_management_integration import ModelManagementIntegration, model_management_system

__all__ = [
    # Servicios existentes
    'model_service',
    'admin_service',
    'concurrent_download_service',
    'contribution_service',
    'hibernation_service',
    'node_service',
    'reward_service',
    'round_service',
    'session_service',

    # Servicios FASE 4
    'ModelRegistry',
    'ModelLineage',
    'model_registry',
    'ModelLifecycleManager',
    'LifecycleStage',
    'LifecycleTransition',
    'model_lifecycle_manager',
    'ModelValidator',
    'ModelValidationType',
    'model_validator',
    'ModelVersionController',
    'VersionControlAction',
    'model_version_controller',
    'ModelQualityMonitor',
    'DriftType',
    'AlertSeverity',
    'QualityMetrics',
    'model_quality_monitor',

    # Sistema integrado
    'ModelManagementIntegration',
    'model_management_system'
]