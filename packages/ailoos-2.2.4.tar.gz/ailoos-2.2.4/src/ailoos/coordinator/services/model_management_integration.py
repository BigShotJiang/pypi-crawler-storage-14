"""
Model Management Integration - Integración completa de servicios de gestión de modelos FASE 4
Sistema unificado que conecta todos los servicios de gestión de modelos con el sistema federado existente.
"""

import asyncio
import os
from typing import Dict, List, Any, Optional
from pathlib import Path

from ...core.logging import get_logger
from ...infrastructure.ipfs_embedded import IPFSManager

# Servicios FASE 3 (federated)
from ...federated.federated_version_manager import FederatedVersionManager
from ...federated.version_validator import VersionValidator
from ...federated.ipfs_version_distributor import IPFSVersionDistributor
from ...federated.rollback_coordinator import RollbackCoordinator

# Servicios FASE 4 (model management)
from .model_registry import ModelRegistry
from .model_lifecycle_manager import ModelLifecycleManager
from .model_validator import ModelValidator
from .model_version_controller import ModelVersionController
from .model_quality_monitor import ModelQualityMonitor

logger = get_logger(__name__)


class ModelManagementIntegration:
    """
    Integración completa del sistema de gestión de modelos FASE 4.
    Coordina todos los servicios y proporciona una interfaz unificada.
    """

    def __init__(self, base_data_dir: str = "data"):
        """
        Inicializar la integración de gestión de modelos.

        Args:
            base_data_dir: Directorio base para datos
        """
        self.base_data_dir = Path(base_data_dir)
        self.base_data_dir.mkdir(exist_ok=True)

        # Componentes FASE 3
        self.ipfs_manager: Optional[IPFSManager] = None
        self.version_manager: Optional[FederatedVersionManager] = None
        self.base_validator: Optional[VersionValidator] = None
        self.distributor: Optional[IPFSVersionDistributor] = None
        self.rollback_coordinator: Optional[RollbackCoordinator] = None

        # Servicios FASE 4
        self.registry: Optional[ModelRegistry] = None
        self.lifecycle_manager: Optional[ModelLifecycleManager] = None
        self.validator: Optional[ModelValidator] = None
        self.version_controller: Optional[ModelVersionController] = None
        self.quality_monitor: Optional[ModelQualityMonitor] = None

        # Estado de inicialización
        self.is_initialized = False
        self.is_running = False

        logger.info("🚀 ModelManagementIntegration initialized")

    async def initialize(self) -> bool:
        """
        Inicializar todos los componentes del sistema.

        Returns:
            True si la inicialización fue exitosa
        """
        try:
            logger.info("🔧 Starting Model Management System initialization...")

            # 1. Inicializar IPFS Manager
            await self._init_ipfs_manager()

            # 2. Inicializar componentes FASE 3
            await self._init_fase3_components()

            # 3. Inicializar servicios FASE 4
            await self._init_fase4_services()

            # 4. Conectar servicios
            await self._connect_services()

            # 5. Configurar callbacks
            await self._setup_callbacks()

            self.is_initialized = True
            logger.info("✅ Model Management System fully initialized")

            return True

        except Exception as e:
            logger.error(f"❌ Failed to initialize Model Management System: {e}")
            await self._cleanup_on_failure()
            return False

    async def _init_ipfs_manager(self):
        """Inicializar IPFS Manager."""
        logger.info("📡 Initializing IPFS Manager...")
        self.ipfs_manager = IPFSManager()
        await self.ipfs_manager.start()
        logger.info("✅ IPFS Manager initialized")

    async def _init_fase3_components(self):
        """Inicializar componentes de FASE 3."""
        logger.info("🔄 Initializing FASE 3 components...")

        # Federated Version Manager
        registry_path = self.base_data_dir / "federated_registry.json"
        self.version_manager = FederatedVersionManager(
            registry_path=str(registry_path),
            ipfs_manager=self.ipfs_manager,
            min_validations=3,
            validation_timeout_hours=24
        )
        await self.version_manager.initialize()

        # Version Validator
        self.base_validator = VersionValidator(
            version_manager=self.version_manager,
            validation_timeout_seconds=3600,
            min_validation_score=0.7
        )

        # IPFS Version Distributor
        self.distributor = IPFSVersionDistributor(
            ipfs_manager=self.ipfs_manager,
            version_manager=self.version_manager,
            max_concurrent_distributions=10,
            replication_factor=3
        )
        await self.distributor.start()

        # Rollback Coordinator
        self.rollback_coordinator = RollbackCoordinator(
            version_manager=self.version_manager,
            distributor=self.distributor,
            auto_rollback_enabled=True,
            max_concurrent_rollbacks=1
        )
        await self.rollback_coordinator.start()

        logger.info("✅ FASE 3 components initialized")

    async def _init_fase4_services(self):
        """Inicializar servicios de FASE 4."""
        logger.info("🆕 Initializing FASE 4 services...")

        # Model Registry
        registry_path = self.base_data_dir / "model_registry.json"
        self.registry = ModelRegistry(
            federated_version_manager=self.version_manager,
            ipfs_manager=self.ipfs_manager,
            registry_path=str(registry_path)
        )
        await self.registry.initialize()

        # Model Lifecycle Manager
        self.lifecycle_manager = ModelLifecycleManager(
            version_manager=self.version_manager,
            validator=self.base_validator,
            distributor=self.distributor,
            registry=self.registry
        )

        # Model Validator
        self.validator = ModelValidator(
            base_validator=self.base_validator,
            registry=self.registry
        )

        # Model Version Controller
        self.version_controller = ModelVersionController(
            version_manager=self.version_manager,
            distributor=self.distributor,
            rollback_coordinator=self.rollback_coordinator,
            registry=self.registry,
            ipfs_manager=self.ipfs_manager
        )

        # Model Quality Monitor
        self.quality_monitor = ModelQualityMonitor(
            registry=self.registry,
            lifecycle_manager=self.lifecycle_manager,
            rollback_coordinator=self.rollback_coordinator,
            monitoring_window_hours=24,
            check_interval_minutes=15
        )

        logger.info("✅ FASE 4 services initialized")

    async def _connect_services(self):
        """Conectar servicios entre sí."""
        logger.info("🔗 Connecting services...")

        # Conectar callbacks entre servicios
        # Lifecycle Manager -> Registry
        self.lifecycle_manager.add_lifecycle_callback(self._on_lifecycle_event)

        # Quality Monitor -> Lifecycle Manager
        self.quality_monitor.add_alert_callback(self._on_quality_alert)

        # Version Controller -> Registry
        # (Ya conectado a través de inicialización)

        logger.info("✅ Services connected")

    async def _setup_callbacks(self):
        """Configurar callbacks del sistema."""
        logger.info("📡 Setting up system callbacks...")

        # Callback para eventos del ciclo de vida
        async def lifecycle_event_handler(model_name, transition, new_stage):
            logger.info(f"🔄 Lifecycle event: {model_name} -> {new_stage.value} ({transition.value})")

            # Si el modelo entra en producción, iniciar monitoreo
            if new_stage.name == "PRODUCTION":
                await self.quality_monitor.start_monitoring()

        # Callback para alertas de calidad
        async def quality_alert_handler(alert):
            logger.warning(f"🚨 Quality alert: {alert.model_name} - {alert.message}")

            # Si es una alerta crítica, notificar al administrador
            if alert.severity.name == "CRITICAL":
                await self._handle_critical_alert(alert)

        # Registrar callbacks
        self.lifecycle_manager.add_lifecycle_callback(lifecycle_event_handler)
        self.quality_monitor.add_alert_callback(quality_alert_handler)

        logger.info("✅ System callbacks configured")

    async def _on_lifecycle_event(self, model_name: str, transition, new_stage):
        """Manejador de eventos del ciclo de vida."""
        logger.info(f"🔄 Lifecycle transition: {model_name} {transition.value} -> {new_stage.value}")

    async def _on_quality_alert(self, alert):
        """Manejador de alertas de calidad."""
        logger.warning(f"🚨 Quality alert: {alert.model_name} - {alert.severity.value} - {alert.message}")

    async def _handle_critical_alert(self, alert):
        """Manejar alertas críticas."""
        logger.error(f"🚨🚨 CRITICAL ALERT: {alert.model_name} - {alert.message}")

        # En producción, aquí se enviarían notificaciones por email/SMS
        # y se podrían pausar inferencias automáticamente

    async def start(self) -> bool:
        """
        Iniciar el sistema de gestión de modelos.

        Returns:
            True si el inicio fue exitoso
        """
        if not self.is_initialized:
            logger.error("System not initialized. Call initialize() first.")
            return False

        if self.is_running:
            return True

        try:
            logger.info("▶️ Starting Model Management System...")

            # Iniciar monitoreo de calidad
            await self.quality_monitor.start_monitoring()

            self.is_running = True
            logger.info("✅ Model Management System started")

            return True

        except Exception as e:
            logger.error(f"❌ Failed to start Model Management System: {e}")
            return False

    async def stop(self):
        """Detener el sistema de gestión de modelos."""
        if not self.is_running:
            return

        logger.info("⏹️ Stopping Model Management System...")

        try:
            # Detener servicios en orden inverso
            if self.quality_monitor:
                await self.quality_monitor.stop_monitoring()

            if self.rollback_coordinator:
                await self.rollback_coordinator.stop()

            if self.distributor:
                await self.distributor.stop()

            if self.ipfs_manager:
                await self.ipfs_manager.stop()

            self.is_running = False
            logger.info("✅ Model Management System stopped")

        except Exception as e:
            logger.error(f"❌ Error stopping Model Management System: {e}")

    async def _cleanup_on_failure(self):
        """Limpiar recursos en caso de fallo de inicialización."""
        try:
            if self.quality_monitor:
                await self.quality_monitor.stop_monitoring()
            if self.rollback_coordinator:
                await self.rollback_coordinator.stop()
            if self.distributor:
                await self.distributor.stop()
            if self.ipfs_manager:
                await self.ipfs_manager.stop()
        except Exception as e:
            logger.warning(f"Cleanup error: {e}")

    # API pública unificada

    async def register_model(self, model_data, creator_node: str, parent_models: List[str] = None) -> str:
        """Registrar un nuevo modelo."""
        return await self.registry.register_model(model_data, creator_node, parent_models)

    async def create_version(self, model_name: str, version_data: bytes, metadata: Dict[str, Any], creator_node: str) -> str:
        """Crear nueva versión de modelo."""
        return await self.version_controller.create_version(model_name, version_data, metadata, creator_node)

    async def promote_to_production(self, model_name: str, version_id: str, user: str) -> bool:
        """Promover versión a producción."""
        return await self.version_controller.promote_version(model_name, version_id, user)

    async def rollback_model(self, model_name: str, from_version: str, to_version: str, user: str) -> str:
        """Ejecutar rollback."""
        return await self.version_controller.rollback_version(model_name, from_version, to_version, user)

    async def report_quality_metrics(self, model_name: str, metrics) -> bool:
        """Reportar métricas de calidad."""
        return await self.quality_monitor.report_metrics(model_name, metrics)

    async def get_model_status(self, model_name: str) -> Dict[str, Any]:
        """Obtener estado completo de un modelo."""
        try:
            lifecycle_stage = await self.lifecycle_manager.get_current_stage(model_name)
            active_version = await self.registry.get_active_version(model_name)
            active_alerts = await self.quality_monitor.get_active_alerts(model_name)
            recent_metrics = await self.quality_monitor.get_model_metrics(model_name, hours=1)

            return {
                'model_name': model_name,
                'lifecycle_stage': lifecycle_stage.value if lifecycle_stage else None,
                'active_version': active_version.version_id if active_version else None,
                'active_alerts': len(active_alerts),
                'recent_metrics_count': len(recent_metrics),
                'is_healthy': len(active_alerts) == 0
            }
        except Exception as e:
            logger.error(f"Error getting model status: {e}")
            return {'error': str(e)}

    def get_system_status(self) -> Dict[str, Any]:
        """Obtener estado del sistema completo."""
        return {
            'is_initialized': self.is_initialized,
            'is_running': self.is_running,
            'registry_stats': self.registry.get_registry_stats() if self.registry else {},
            'quality_stats': self.quality_monitor.get_monitoring_stats() if self.quality_monitor else {},
            'version_stats': self.version_controller.get_version_stats() if self.version_controller else {},
            'lifecycle_stats': self.lifecycle_manager.get_lifecycle_stats() if self.lifecycle_manager else {}
        }

    async def health_check(self) -> Dict[str, Any]:
        """Verificación de salud del sistema."""
        health_status = {
            'overall_health': 'healthy',
            'components': {},
            'issues': []
        }

        # Verificar componentes FASE 3
        components_to_check = {
            'ipfs_manager': self.ipfs_manager,
            'version_manager': self.version_manager,
            'base_validator': self.base_validator,
            'distributor': self.distributor,
            'rollback_coordinator': self.rollback_coordinator
        }

        for name, component in components_to_check.items():
            if component is None:
                health_status['components'][name] = 'not_initialized'
                health_status['issues'].append(f"{name} not initialized")
                health_status['overall_health'] = 'unhealthy'
            else:
                health_status['components'][name] = 'initialized'

        # Verificar servicios FASE 4
        services_to_check = {
            'registry': self.registry,
            'lifecycle_manager': self.lifecycle_manager,
            'validator': self.validator,
            'version_controller': self.version_controller,
            'quality_monitor': self.quality_monitor
        }

        for name, service in services_to_check.items():
            if service is None:
                health_status['components'][name] = 'not_initialized'
                health_status['issues'].append(f"{name} not initialized")
                health_status['overall_health'] = 'unhealthy'
            else:
                health_status['components'][name] = 'initialized'

        # Verificar estado de ejecución
        if not self.is_running:
            health_status['issues'].append("System not running")
            health_status['overall_health'] = 'stopped'

        return health_status


# Instancia global del sistema integrado
model_management_system = ModelManagementIntegration()