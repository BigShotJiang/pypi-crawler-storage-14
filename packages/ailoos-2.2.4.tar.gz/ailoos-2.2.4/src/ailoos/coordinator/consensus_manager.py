"""
Gestor de consenso ligero para coordinadores distribuidos.
Implementa protocolo de consenso basado en quorum con tolerancia a fallos bizantinos básicos.
"""

import asyncio
import hashlib
import json
import logging
import time
import threading
from typing import Dict, List, Any, Optional, Tuple, Set, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import random

logger = logging.getLogger(__name__)


class ConsensusPhase(Enum):
    """Fases del protocolo de consenso."""
    PROPOSAL = "proposal"
    VOTING = "voting"
    COMMIT = "commit"
    DECIDED = "decided"


class NodeRole(Enum):
    """Roles de nodos en el consenso."""
    LEADER = "leader"
    FOLLOWER = "follower"
    CANDIDATE = "candidate"


class ConsensusResult(Enum):
    """Resultados posibles del consenso."""
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    TIMEOUT = "timeout"
    FAILED = "failed"


@dataclass
class ConsensusProposal:
    """Propuesta de consenso."""
    proposal_id: str
    proposer_id: str
    operation: str  # 'create_session', 'start_session', 'update_model', etc.
    data: Dict[str, Any]
    timestamp: float
    signatures: Dict[str, str] = field(default_factory=dict)  # node_id -> signature
    votes: Dict[str, str] = field(default_factory=dict)  # node_id -> vote ('yes', 'no')
    status: ConsensusResult = ConsensusResult.TIMEOUT
    quorum_size: int = 0
    timeout_at: float = 0.0


@dataclass
class ConsensusMessage:
    """Mensaje de consenso entre nodos."""
    message_id: str
    sender_id: str
    phase: ConsensusPhase
    proposal_id: str
    data: Any
    signature: Optional[str] = None
    timestamp: float = field(default_factory=time.time)


class ByzantineFaultDetector:
    """
    Detector básico de fallos bizantinos usando firmas digitales.
    """

    def __init__(self, node_id: str):
        self.node_id = node_id
        self.known_keys: Dict[str, str] = {}  # node_id -> public_key

    def register_node_key(self, node_id: str, public_key: str):
        """Registra la clave pública de un nodo."""
        self.known_keys[node_id] = public_key

    def sign_message(self, message: str) -> str:
        """Firma un mensaje (simplificado - en producción usar crypto real)."""
        # En producción: usar ECDSA o similar
        content = f"{message}_{self.node_id}_{int(time.time())}"
        return hashlib.sha256(content.encode()).hexdigest()[:32]

    def verify_signature(self, message: str, signature: str, node_id: str) -> bool:
        """Verifica firma de un mensaje."""
        if node_id not in self.known_keys:
            return False

        # En producción: verificar firma criptográfica real
        expected = hashlib.sha256(f"{message}_{node_id}_{int(time.time())}".encode()).hexdigest()[:32]
        return signature == expected

    def detect_byzantine_behavior(self, proposal: ConsensusProposal) -> List[str]:
        """Detecta comportamiento potencialmente bizantino."""
        suspicious_nodes = []

        # Verificar firmas inválidas
        for node_id, signature in proposal.signatures.items():
            message = f"{proposal.proposal_id}_{proposal.operation}"
            if not self.verify_signature(message, signature, node_id):
                suspicious_nodes.append(node_id)

        # Detectar votos contradictorios (simplificado)
        vote_counts = {}
        for node_id, vote in proposal.votes.items():
            if vote not in ['yes', 'no']:
                suspicious_nodes.append(node_id)
            else:
                vote_counts[vote] = vote_counts.get(vote, 0) + 1

        return list(set(suspicious_nodes))


class LightweightConsensus:
    """
    Protocolo de consenso ligero basado en quorum.
    Inspirado en Raft pero simplificado para operaciones críticas del coordinador.
    """

    def __init__(self, node_id: str, total_nodes: int, quorum_size: Optional[int] = None):
        self.node_id = node_id
        self.total_nodes = total_nodes
        self.quorum_size = quorum_size or (total_nodes // 2 + 1)

        # Estado del consenso
        self.current_term = 0
        self.role = NodeRole.FOLLOWER
        self.voted_for: Optional[str] = None
        self.leader_id: Optional[str] = None

        # Propuestas activas
        self.active_proposals: Dict[str, ConsensusProposal] = {}
        self.proposal_history: Dict[str, ConsensusProposal] = {}

        # Timeouts
        self.election_timeout = random.uniform(1.0, 2.0)
        self.heartbeat_timeout = 0.5
        self.proposal_timeout = 30.0  # 30 segundos para consenso

        # Timestamps
        self.last_heartbeat = time.time()
        self.last_election = time.time()

        # Tolerancia a fallos bizantinos
        self.fault_detector = ByzantineFaultDetector(node_id)

        # Locks para thread safety
        self.state_lock = threading.RLock()

        logger.info(f"⚖️ Lightweight Consensus initialized for node {node_id} (quorum: {self.quorum_size}/{self.total_nodes})")

    def is_leader(self) -> bool:
        """Verifica si este nodo es el líder."""
        return self.role == NodeRole.LEADER

    def get_quorum_size(self) -> int:
        """Obtiene el tamaño del quorum requerido."""
        return self.quorum_size

    async def propose_operation(self, operation: str, data: Dict[str, Any]) -> Optional[str]:
        """
        Propone una operación para consenso.

        Args:
            operation: Tipo de operación ('create_session', 'start_session', etc.)
            data: Datos de la operación

        Returns:
            ID de la propuesta o None si falla
        """
        if not self.is_leader():
            logger.warning(f"❌ Node {self.node_id} is not leader, cannot propose")
            return None

        proposal_id = f"proposal_{self.node_id}_{self.current_term}_{int(time.time() * 1000)}"

        proposal = ConsensusProposal(
            proposal_id=proposal_id,
            proposer_id=self.node_id,
            operation=operation,
            data=data,
            timestamp=time.time(),
            quorum_size=self.quorum_size,
            timeout_at=time.time() + self.proposal_timeout
        )

        # Firmar la propuesta
        message = f"{proposal_id}_{operation}"
        proposal.signatures[self.node_id] = self.fault_detector.sign_message(message)

        with self.state_lock:
            self.active_proposals[proposal_id] = proposal

        logger.info(f"📤 Proposed operation: {operation} (ID: {proposal_id})")

        # Iniciar votación
        await self._start_voting(proposal)

        return proposal_id

    async def _start_voting(self, proposal: ConsensusProposal):
        """Inicia el proceso de votación para una propuesta."""
        # En implementación real, enviar mensajes a otros nodos
        logger.debug(f"🗳️ Started voting for proposal {proposal.proposal_id}")

        # Simular recepción de votos (en producción: esperar mensajes reales)
        asyncio.create_task(self._collect_votes(proposal))

    async def _collect_votes(self, proposal: ConsensusProposal):
        """Recopila votos para una propuesta."""
        try:
            # Esperar un tiempo por votos
            await asyncio.sleep(self.proposal_timeout / 3)

            with self.state_lock:
                if proposal.proposal_id not in self.active_proposals:
                    return

                # Contar votos
                yes_votes = sum(1 for vote in proposal.votes.values() if vote == 'yes')
                no_votes = sum(1 for vote in proposal.votes.values() if vote == 'no')

                # Verificar quorum
                if yes_votes >= self.quorum_size:
                    proposal.status = ConsensusResult.ACCEPTED
                    await self._commit_proposal(proposal)
                elif no_votes >= self.quorum_size:
                    proposal.status = ConsensusResult.REJECTED
                    await self._finalize_proposal(proposal)
                elif time.time() > proposal.timeout_at:
                    proposal.status = ConsensusResult.TIMEOUT
                    await self._finalize_proposal(proposal)

        except Exception as e:
            logger.error(f"❌ Error collecting votes for {proposal.proposal_id}: {e}")
            proposal.status = ConsensusResult.FAILED
            await self._finalize_proposal(proposal)

    async def _commit_proposal(self, proposal: ConsensusProposal):
        """Confirma una propuesta aceptada."""
        logger.info(f"✅ Proposal {proposal.proposal_id} committed with quorum")

        # Ejecutar la operación
        await self._execute_operation(proposal)

        # Notificar a otros nodos
        await self._broadcast_commit(proposal)

        # Finalizar
        await self._finalize_proposal(proposal)

    async def _execute_operation(self, proposal: ConsensusProposal):
        """Ejecuta la operación acordada."""
        try:
            operation = proposal.operation
            data = proposal.data

            if operation == 'create_session':
                logger.info(f"🏗️ Creating session: {data.get('session_id')}")
                # Aquí iría la lógica real de creación de sesión
            elif operation == 'start_session':
                logger.info(f"🚀 Starting session: {data.get('session_id')}")
                # Lógica de inicio de sesión
            elif operation == 'update_model':
                logger.info(f"📝 Updating model: {data.get('model_id')}")
                # Lógica de actualización de modelo
            else:
                logger.warning(f"⚠️ Unknown operation: {operation}")

        except Exception as e:
            logger.error(f"❌ Error executing operation {proposal.operation}: {e}")

    async def _broadcast_commit(self, proposal: ConsensusProposal):
        """Difunde el commit a otros nodos."""
        # En implementación real: enviar mensajes de commit
        logger.debug(f"📢 Broadcasting commit for {proposal.proposal_id}")

    async def _finalize_proposal(self, proposal: ConsensusProposal):
        """Finaliza una propuesta."""
        with self.state_lock:
            if proposal.proposal_id in self.active_proposals:
                del self.active_proposals[proposal.proposal_id]

            self.proposal_history[proposal.proposal_id] = proposal

        logger.debug(f"🏁 Finalized proposal {proposal.proposal_id} with status {proposal.status.value}")

    async def receive_vote(self, proposal_id: str, voter_id: str, vote: str, signature: str):
        """Recibe un voto de otro nodo."""
        with self.state_lock:
            if proposal_id not in self.active_proposals:
                logger.warning(f"⚠️ Received vote for unknown proposal {proposal_id}")
                return

            proposal = self.active_proposals[proposal_id]

            # Verificar firma
            message = f"{proposal_id}_{proposal.operation}"
            if not self.fault_detector.verify_signature(message, signature, voter_id):
                logger.warning(f"⚠️ Invalid signature from {voter_id} for proposal {proposal_id}")
                return

            # Registrar voto
            proposal.votes[voter_id] = vote
            proposal.signatures[voter_id] = signature

            logger.debug(f"🗳️ Received vote from {voter_id}: {vote} for {proposal_id}")

    async def handle_election_timeout(self):
        """Maneja timeout de elección."""
        if self.role == NodeRole.FOLLOWER and time.time() - self.last_heartbeat > self.election_timeout:
            await self._start_election()

    async def _start_election(self):
        """Inicia proceso de elección."""
        self.current_term += 1
        self.role = NodeRole.CANDIDATE
        self.voted_for = self.node_id

        logger.info(f"🗳️ Node {self.node_id} starting election for term {self.current_term}")

        # En implementación real: enviar RequestVote RPCs
        # Por simplicidad, asumir que gana la elección
        await asyncio.sleep(random.uniform(0.1, 0.5))
        await self._become_leader()

    async def _become_leader(self):
        """Convierte este nodo en líder."""
        self.role = NodeRole.LEADER
        self.leader_id = self.node_id

        logger.info(f"👑 Node {self.node_id} became leader for term {self.current_term}")

        # Iniciar heartbeats
        asyncio.create_task(self._send_heartbeats())

    async def _send_heartbeats(self):
        """Envía heartbeats periódicos."""
        while self.role == NodeRole.LEADER:
            try:
                await asyncio.sleep(self.heartbeat_timeout)
                # En implementación real: enviar AppendEntries RPCs vacíos
                self.last_heartbeat = time.time()
            except asyncio.CancelledError:
                break

    def get_consensus_status(self) -> Dict[str, Any]:
        """Obtiene el estado actual del consenso."""
        return {
            'node_id': self.node_id,
            'role': self.role.value,
            'current_term': self.current_term,
            'leader_id': self.leader_id,
            'quorum_size': self.quorum_size,
            'total_nodes': self.total_nodes,
            'active_proposals': len(self.active_proposals),
            'last_heartbeat': self.last_heartbeat
        }


class ConsensusManager:
    """
    Gestor principal de consenso para el coordinador.
    Coordina múltiples instancias de consenso y maneja recuperación de particiones.
    """

    def __init__(self, node_id: str, total_nodes: int = 3, consensus_timeout: float = 30.0):
        self.node_id = node_id
        self.total_nodes = total_nodes
        self.consensus_timeout = consensus_timeout

        # Instancia de consenso
        self.consensus = LightweightConsensus(node_id, total_nodes)

        # Estado de particiones de red
        self.network_partitions: Dict[str, float] = {}  # node_id -> detection_time
        self.partition_recovery_timeout = 300.0  # 5 minutos

        # Callbacks para eventos
        self.callbacks: Dict[str, List[Callable]] = {
            'consensus_reached': [],
            'consensus_failed': [],
            'partition_detected': [],
            'partition_resolved': []
        }

        # Estado de operaciones críticas
        self.critical_operations = {
            'create_session',
            'start_session',
            'complete_session',
            'update_global_model',
            'merge_models'
        }

        logger.info(f"🎯 ConsensusManager initialized for node {node_id}")

    def register_callback(self, event: str, callback: Callable):
        """Registra callback para evento."""
        if event in self.callbacks:
            self.callbacks[event].append(callback)

    async def propose_critical_operation(self, operation: str, data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Propone una operación crítica para consenso.

        Args:
            operation: Tipo de operación
            data: Datos de la operación

        Returns:
            (éxito, mensaje)
        """
        if operation not in self.critical_operations:
            return False, f"Operation {operation} is not critical"

        # Verificar conectividad de red
        if self._has_network_partition():
            return False, "Network partition detected, consensus unavailable"

        try:
            proposal_id = await self.consensus.propose_operation(operation, data)

            if proposal_id:
                # Esperar resultado del consenso
                result = await self._wait_for_consensus_result(proposal_id)

                if result == ConsensusResult.ACCEPTED:
                    await self._trigger_callbacks('consensus_reached', operation, data)
                    return True, f"Consensus reached for {operation}"
                else:
                    await self._trigger_callbacks('consensus_failed', operation, data, result)
                    return False, f"Consensus failed: {result.value}"
            else:
                return False, "Failed to propose operation"

        except Exception as e:
            logger.error(f"❌ Error in consensus for {operation}: {e}")
            return False, f"Consensus error: {str(e)}"

    async def _wait_for_consensus_result(self, proposal_id: str) -> ConsensusResult:
        """Espera el resultado de una propuesta."""
        start_time = time.time()

        while time.time() - start_time < self.consensus_timeout:
            await asyncio.sleep(0.1)

            # Verificar estado de la propuesta
            with self.consensus.state_lock:
                if proposal_id in self.consensus.proposal_history:
                    proposal = self.consensus.proposal_history[proposal_id]
                    return proposal.status

        return ConsensusResult.TIMEOUT

    def _has_network_partition(self) -> bool:
        """Verifica si hay particiones de red activas."""
        current_time = time.time()
        active_partitions = [
            node_id for node_id, detection_time in self.network_partitions.items()
            if current_time - detection_time < self.partition_recovery_timeout
        ]
        return len(active_partitions) > 0

    async def detect_partition(self, node_id: str):
        """Detecta partición de red con un nodo."""
        if node_id not in self.network_partitions:
            self.network_partitions[node_id] = time.time()
            await self._trigger_callbacks('partition_detected', node_id)
            logger.warning(f"⚠️ Network partition detected with {node_id}")

    async def resolve_partition(self, node_id: str):
        """Resuelve partición de red con un nodo."""
        if node_id in self.network_partitions:
            del self.network_partitions[node_id]
            await self._trigger_callbacks('partition_resolved', node_id)
            logger.info(f"🔄 Network partition resolved with {node_id}")

    async def _trigger_callbacks(self, event: str, *args, **kwargs):
        """Dispara callbacks para un evento."""
        for callback in self.callbacks[event]:
            try:
                await callback(*args, **kwargs)
            except Exception as e:
                logger.error(f"❌ Consensus callback error: {e}")

    async def start_consensus_service(self):
        """Inicia el servicio de consenso."""
        asyncio.create_task(self._election_monitor())
        asyncio.create_task(self._partition_monitor())
        logger.info("🚀 Consensus service started")

    async def stop_consensus_service(self):
        """Detiene el servicio de consenso."""
        logger.info("🛑 Consensus service stopped")

    async def _election_monitor(self):
        """Monitorea timeouts de elección."""
        while True:
            try:
                await asyncio.sleep(0.1)
                await self.consensus.handle_election_timeout()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Election monitor error: {e}")

    async def _partition_monitor(self):
        """Monitorea recuperación de particiones."""
        while True:
            try:
                await asyncio.sleep(60)  # Verificar cada minuto
                current_time = time.time()

                recovered = []
                for node_id, detection_time in self.network_partitions.items():
                    if current_time - detection_time > self.partition_recovery_timeout:
                        recovered.append(node_id)

                for node_id in recovered:
                    await self.resolve_partition(node_id)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"❌ Partition monitor error: {e}")

    def get_status(self) -> Dict[str, Any]:
        """Obtiene estado completo del gestor de consenso."""
        return {
            'node_id': self.node_id,
            'consensus': self.consensus.get_consensus_status(),
            'network_partitions': list(self.network_partitions.keys()),
            'critical_operations': list(self.critical_operations),
            'consensus_timeout': self.consensus_timeout
        }


# Instancia global
_consensus_manager: Optional[ConsensusManager] = None


def get_consensus_manager(node_id: str, **kwargs) -> ConsensusManager:
    """Obtiene la instancia global del gestor de consenso."""
    global _consensus_manager
    if _consensus_manager is None:
        _consensus_manager = ConsensusManager(node_id, **kwargs)
    return _consensus_manager


async def start_consensus_service(node_id: str, **kwargs):
    """Inicia el servicio de consenso."""
    manager = get_consensus_manager(node_id, **kwargs)
    await manager.start_consensus_service()
    return manager