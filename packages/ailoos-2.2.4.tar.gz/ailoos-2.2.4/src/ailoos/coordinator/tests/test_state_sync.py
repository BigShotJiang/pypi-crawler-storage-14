"""
Pruebas para el protocolo de sincronización de estado distribuido.
"""

import asyncio
import pytest
import time
from unittest.mock import Mock, patch

from src.ailoos.coordinator.state_sync import (
    StateSync,
    VectorClock,
    StateUpdate,
    Conflict,
    ConflictResolutionStrategy
)


class TestVectorClock:
    """Pruebas para VectorClock."""

    def test_vector_clock_creation(self):
        """Prueba creación básica de vector clock."""
        vc = VectorClock(node_id="node1")
        assert vc.node_id == "node1"
        assert vc.counters == {}

    def test_vector_clock_increment(self):
        """Prueba incremento de vector clock."""
        vc = VectorClock(node_id="node1")
        vc = vc.increment("node1")
        assert vc.counters["node1"] == 1

        vc = vc.increment("node2")
        assert vc.counters["node1"] == 1
        assert vc.counters["node2"] == 1

    def test_vector_clock_merge(self):
        """Prueba fusión de vector clocks."""
        vc1 = VectorClock(node_id="node1", counters={"node1": 2, "node2": 1})
        vc2 = VectorClock(node_id="node2", counters={"node1": 1, "node2": 3})

        merged = vc1.merge(vc2)
        assert merged.counters["node1"] == 2
        assert merged.counters["node2"] == 3

    def test_vector_clock_comparison(self):
        """Prueba comparación de vector clocks."""
        vc1 = VectorClock(node_id="node1", counters={"node1": 1, "node2": 1})
        vc2 = VectorClock(node_id="node2", counters={"node1": 1, "node2": 2})

        # vc2 > vc1
        assert vc1.compare(vc2) == -1
        assert vc2.compare(vc1) == 1

        # vc1 == vc1
        vc3 = VectorClock(node_id="node1", counters={"node1": 1, "node2": 1})
        assert vc1.compare(vc3) == 0

        # incomparable
        vc4 = VectorClock(node_id="node3", counters={"node1": 2, "node3": 1})
        assert vc1.compare(vc4) is None


class TestStateUpdate:
    """Pruebas para StateUpdate."""

    def test_state_update_creation(self):
        """Prueba creación de actualización de estado."""
        vc = VectorClock(node_id="node1")
        update = StateUpdate(
            update_id="test_123",
            node_id="node1",
            timestamp=time.time(),
            vector_clock=vc,
            operation="create",
            key="test_key",
            value="test_value"
        )

        assert update.update_id == "test_123"
        assert update.node_id == "node1"
        assert update.operation == "create"
        assert update.key == "test_key"
        assert update.value == "test_value"
        assert update.checksum != ""

    def test_state_update_validation(self):
        """Prueba validación de checksum."""
        vc = VectorClock(node_id="node1")
        update = StateUpdate(
            update_id="test_123",
            node_id="node1",
            timestamp=time.time(),
            vector_clock=vc,
            operation="create",
            key="test_key",
            value="test_value"
        )

        assert update.is_valid()

        # Modificar datos debería invalidar checksum
        update.value = "modified"
        assert not update.is_valid()


class TestStateSync:
    """Pruebas para StateSync."""

    @pytest.fixture
    def state_sync(self):
        """Fixture para StateSync."""
        return StateSync(node_id="test_node")

    def test_state_sync_initialization(self, state_sync):
        """Prueba inicialización de StateSync."""
        assert state_sync.node_id == "test_node"
        assert state_sync.local_state == {}
        assert len(state_sync.peers) == 0
        assert len(state_sync.pending_updates) == 0

    def test_update_local_state(self, state_sync):
        """Prueba actualización de estado local."""
        update = state_sync.update_local_state("test_key", "test_value", "create")

        assert update.node_id == "test_node"
        assert update.key == "test_key"
        assert update.value == "test_value"
        assert update.operation == "create"
        assert state_sync.local_state["test_key"] == "test_value"
        assert len(state_sync.pending_updates) == 1

    @pytest.mark.asyncio
    async def test_synchronize_with_peer(self, state_sync):
        """Prueba sincronización con peer."""
        # Crear estado remoto simulado
        remote_state = {"remote_key": "remote_value"}
        remote_updates = [{
            "update_id": "remote_123",
            "node_id": "peer1",
            "timestamp": time.time(),
            "vector_clock": {"node_id": "peer1", "counters": {"peer1": 1}},
            "operation": "create",
            "key": "remote_key",
            "value": "remote_value",
            "checksum": "dummy_checksum"
        }]

        # Agregar peer primero
        state_sync.add_peer("peer1")

        # Mock para evitar validación de checksum
        with patch.object(StateUpdate, 'is_valid', return_value=True):
            success, conflicts = await state_sync.synchronize_with_peer(
                "peer1", remote_state, remote_updates
            )

        assert success
        assert len(conflicts) == 0
        assert "peer1" in state_sync.peers

    def test_get_sync_status(self, state_sync):
        """Prueba obtención de estado de sincronización."""
        status = state_sync.get_sync_status()

        assert status["node_id"] == "test_node"
        assert "vector_clock" in status
        assert "pending_updates_count" in status
        assert "active_peers" in status

    def test_add_remove_peer(self, state_sync):
        """Prueba agregar y remover peers."""
        state_sync.add_peer("peer1")
        assert "peer1" in state_sync.peers

        state_sync.remove_peer("peer1")
        assert "peer1" not in state_sync.peers


class TestConflictResolution:
    """Pruebas para resolución de conflictos."""

    def test_conflict_creation(self):
        """Prueba creación de conflicto."""
        vc1 = VectorClock(node_id="node1", counters={"node1": 1})
        vc2 = VectorClock(node_id="node2", counters={"node2": 1})

        local_update = StateUpdate(
            update_id="local_123",
            node_id="node1",
            timestamp=time.time(),
            vector_clock=vc1,
            operation="update",
            key="test_key",
            value="local_value"
        )

        remote_update = StateUpdate(
            update_id="remote_456",
            node_id="node2",
            timestamp=time.time(),
            vector_clock=vc2,
            operation="update",
            key="test_key",
            value="remote_value"
        )

        conflict = Conflict(
            key="test_key",
            local_update=local_update,
            remote_update=remote_update
        )

        assert conflict.key == "test_key"
        assert conflict.local_update.value == "local_value"
        assert conflict.remote_update.value == "remote_value"

    def test_conflict_resolution_strategies(self):
        """Prueba estrategias de resolución de conflictos."""
        vc1 = VectorClock(node_id="node1", counters={"node1": 1})
        vc2 = VectorClock(node_id="node2", counters={"node2": 1})

        # Local más reciente
        local_update = StateUpdate(
            update_id="local_123",
            node_id="node1",
            timestamp=time.time() + 1,  # Más reciente
            vector_clock=vc1,
            operation="update",
            key="test_key",
            value="local_value"
        )

        remote_update = StateUpdate(
            update_id="remote_456",
            node_id="node2",
            timestamp=time.time(),
            vector_clock=vc2,
            operation="update",
            key="test_key",
            value="remote_value"
        )

        conflict = Conflict(
            key="test_key",
            local_update=local_update,
            remote_update=remote_update
        )

        # Latest writer wins
        resolved = conflict.resolve(ConflictResolutionStrategy.LATEST_WRITER_WINS)
        assert resolved == local_update

        # Vector clock priority (incomparable, usa timestamp)
        resolved = conflict.resolve(ConflictResolutionStrategy.VECTOR_CLOCK_PRIORITY)
        assert resolved == local_update


if __name__ == "__main__":
    pytest.main([__file__])