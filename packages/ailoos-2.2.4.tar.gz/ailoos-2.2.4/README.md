# AILOOS - Unified SDK for Computer Nodes

AILOOS is a comprehensive SDK for federated learning on computer nodes, featuring privacy-preserving machine learning and secure data infrastructure.

## 🚀 Installation

Install the unified SDK for computer nodes:

```bash
pip install ailoos
```

This provides both the CLI interface and Python SDK for users and developers alike.

## 🎛️ Interactive Dashboard

AILOOS includes a web-based dashboard for system management:

```bash
# Launch the interactive dashboard
ailoos-dashboard

# Or run all APIs together
python scripts/run_dashboard.py
```

**Dashboard Features:**
- 🔄 **Data Refinery**: Real-time pipeline monitoring and management
- 💻 **Hardware Monitor**: Live system metrics and alerts
- 🤖 **Federated Learning**: Mission control and node orchestration
- 📊 **Real-time Updates**: WebSocket-powered live data
- 🎨 **Modern UI**: Responsive web interface

**Access Points:**
- **Dashboard**: http://localhost:3000/dashboard
- **API**: http://localhost:8003 (unified API)
- **WebSocket**: ws://localhost:8003/ws/dashboard

## 📋 Requirements

- Python 3.8+
- Internet connection for IPFS operations

## 🛠️ Quick Start

### Unified Experience

```bash
# Install the SDK
pip install ailoos

# Launch the interface
ailoos
```

```python
from ailoos import quick_setup

# Setup AILOOS automatically
success = quick_setup(verbose=True)
if success:
    print("AILOOS is ready!")
```

### Configuration

```bash
# Initialize configuration
ailoos config init

# Show current configuration
ailoos config show

# Set configuration values
ailoos config set node.coordinator_url "http://localhost:5001"
```

### Start Federated Node

```python
import asyncio
from ailoos import start_federated_node

# Start a federated learning node
await start_federated_node()
```

## 📚 Key Features

- **Federated Learning**: Privacy-preserving distributed training on computer nodes
- **Secure Data Infrastructure**: PII scrubbing and IPFS integration
- **Zero Configuration**: Automatic setup and discovery

## 🔧 Advanced Usage

### Data Processing

```python
from ailoos.data.dataset_manager import dataset_manager

# Process a dataset with automatic PII scrubbing
result = dataset_manager.process_text_file(
    file_path="data.txt",
    dataset_name="my_dataset",
    shard_size_mb=10
)
```

## 📖 Documentation

For complete documentation, visit:
- [GitHub Repository](https://github.com/empoorio/ailoos)
- [Official Documentation](https://docs.ailoos.dev)
- [CLI Documentation](ailoos-cli/README.md)

## 🛠️ Development & Publishing

### Testing Locally
```bash
# Test CLI before publishing
./test-cli-local.sh
```

### Publishing CLI to npm
```bash
# Publish CLI to npm registry
./publish-cli.sh
```

### Building Python SDK
```bash
# Build and publish Python package
python setup.py sdist bdist_wheel
twine upload dist/*
```

## 📝 License

Copyright © 2024 AILOOS Technologies & Empoorio Ecosystem. All rights reserved.

## 📞 Support

- **Email**: dev@empoorio.com
- **GitHub Issues**: [github.com/empoorio/ailoos/issues](https://github.com/empoorio/ailoos/issues)
- **Discord**: https://discord.gg/ailoos

---

**AILOOS** - *Unified SDK for Computer Nodes.* 🚀

## 🎯 Quick Reference

| Component | Install | Run | Purpose |
|-----------|---------|-----|---------|
| **Unified SDK** | `pip install ailoos` | `ailoos` | All-in-one CLI and SDK |
