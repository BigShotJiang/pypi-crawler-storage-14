#!/bin/bash
# Script to prune unsigned Docker images from Google Cloud Artifact Registry
# Usage: ./prune_unsigned_images.sh <project_id> <location> <repository>

set -e

if [ $# -ne 3 ]; then
    echo "Usage: $0 <project_id> <location> <repository>"
    echo "Example: $0 my-project us-central1 my-repo"
    echo "Ensure COSIGN_PUBLIC_KEY environment variable is set"
    exit 1
fi

PROJECT_ID=$1
LOCATION=$2
REPOSITORY=$3

if [ -z "$COSIGN_PUBLIC_KEY" ]; then
    echo "Error: COSIGN_PUBLIC_KEY environment variable is not set"
    exit 1
fi

echo "Pruning unsigned images from repository: $REPOSITORY in project: $PROJECT_ID location: $LOCATION"

# List images
IMAGES=$(gcloud artifacts docker images list --repository="$REPOSITORY" --location="$LOCATION" --project="$PROJECT_ID" --format="value(name)")

DELETED_COUNT=0

echo "$IMAGES" | while IFS= read -r IMAGE_URI; do
    if [ -z "$IMAGE_URI" ]; then
        continue
    fi

    echo "Checking signature for: $IMAGE_URI"

    # Try to verify the image signature
    if ! cosign verify --key env://COSIGN_PUBLIC_KEY "$IMAGE_URI" > /dev/null 2>&1; then
        echo "Image is unsigned or verification failed: $IMAGE_URI"
        echo "Deleting unsigned image: $IMAGE_URI"
        gcloud artifacts docker images delete "$IMAGE_URI" --quiet --project="$PROJECT_ID" --location="$LOCATION"
        ((DELETED_COUNT++))
    else
        echo "Image is signed: $IMAGE_URI"
    fi
done

echo "Pruning completed. Deleted $DELETED_COUNT unsigned images."