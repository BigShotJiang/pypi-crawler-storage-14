#!/usr/bin/env python3
"""
Script para ejecutar el bucle de entrenamiento federado real - FASE REAL-5
Demuestra el sistema completo con EmpoorioLM + AdamW + TenSEAL + Blockchain.
"""

import asyncio
import logging
import argparse
import json
import sys
from pathlib import Path

# Añadir el directorio raíz al path
sys.path.insert(0, str(Path(__file__).parent.parent))

from ailoos.federated import (
    create_real_federated_training_loop,
    FederatedTrainingConfig,
    run_real_federated_training_demo
)
from ailoos.core.logging import setup_logging


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Ejecutar bucle de entrenamiento federado real - FASE REAL-5"
    )

    parser.add_argument(
        "--session-id",
        type=str,
        default="real_federated_session",
        help="ID de la sesión de entrenamiento"
    )

    parser.add_argument(
        "--num-rounds",
        type=int,
        default=5,
        help="Número de rondas de entrenamiento"
    )

    parser.add_argument(
        "--min-participants",
        type=int,
        default=3,
        help="Número mínimo de participantes por ronda"
    )

    parser.add_argument(
        "--datasets",
        type=str,
        nargs="+",
        default=["wikitext", "openwebtext"],
        help="Datasets a utilizar"
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=8,
        help="Tamaño del batch"
    )

    parser.add_argument(
        "--max-length",
        type=int,
        default=512,
        help="Longitud máxima de secuencia"
    )

    parser.add_argument(
        "--num-shards",
        type=int,
        default=10,
        help="Número de shards para datos federados"
    )

    parser.add_argument(
        "--use-tenseal",
        action="store_true",
        default=False,
        help="Habilitar TenSEAL para privacidad homomórfica"
    )

    parser.add_argument(
        "--enable-rewards",
        action="store_true",
        default=True,
        help="Habilitar sistema de recompensas blockchain"
    )

    parser.add_argument(
        "--checkpoint-dir",
        type=str,
        default="./federated_checkpoints",
        help="Directorio para checkpoints"
    )

    parser.add_argument(
        "--output-file",
        type=str,
        default="./federated_training_results.json",
        help="Archivo de salida para resultados"
    )

    parser.add_argument(
        "--demo",
        action="store_true",
        default=False,
        help="Ejecutar demo simplificada"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="Logging detallado"
    )

    return parser.parse_args()


async def run_custom_training(args):
    """Ejecutar entrenamiento personalizado con configuración específica."""
    print("🤖 AILOOS - REAL FEDERATED TRAINING LOOP")
    print("=" * 60)
    print(f"📋 Session ID: {args.session_id}")
    print(f"🎯 Rounds: {args.num_rounds}")
    print(f"👥 Min Participants: {args.min_participants}")
    print(f"📚 Datasets: {', '.join(args.datasets)}")
    print(f"🔐 TenSEAL: {'Enabled' if args.use_tenseal else 'Disabled'}")
    print(f"💰 Rewards: {'Enabled' if args.enable_rewards else 'Disabled'}")
    print()

    # Crear configuración
    config = FederatedTrainingConfig(
        num_rounds=args.num_rounds,
        min_participants_per_round=args.min_participants,
        datasets=args.datasets,
        batch_size=args.batch_size,
        max_length=args.max_length,
        num_shards=args.num_shards,
        use_tenseal=args.use_tenseal,
        enable_blockchain_rewards=args.enable_rewards,
        checkpoint_dir=args.checkpoint_dir
    )

    # Crear bucle de entrenamiento
    training_loop = create_real_federated_training_loop(args.session_id, config)

    try:
        # Inicializar entrenamiento
        print("1️⃣ Inicializando entrenamiento...")
        if not await training_loop.initialize_training():
            print("❌ Error en inicialización")
            return False

        # Simular participantes (en producción vendrían de registro real)
        num_participants = max(args.min_participants + 2, 5)  # Al menos 5 para demo
        participants = [f"node_{i+1}" for i in range(num_participants)]
        print(f"\n2️⃣ Registrando {len(participants)} participantes...")

        for node_id in participants:
            wallet = await training_loop.register_participant(node_id, {"hardware": "cpu"})
            print(f"   ✅ {node_id} -> {wallet[:20]}...")

        # Ejecutar rondas de entrenamiento
        completed_rounds = 0

        for round_num in range(1, args.num_rounds + 1):
            print(f"\n🎯 RONDA {round_num}/{args.num_rounds}")
            print("-" * 40)

            # Seleccionar participantes para esta ronda
            round_participants = participants[:args.min_participants]
            if len(participants) > args.min_participants:
                # Rotar participantes para diversidad
                start_idx = (round_num - 1) % (len(participants) - args.min_participants + 1)
                round_participants = participants[start_idx:start_idx + args.min_participants]

            print(f"👥 Participantes: {', '.join(round_participants)}")

            # Iniciar ronda
            round_config = await training_loop.start_round(round_num, round_participants)

            # Simular actualizaciones de nodos (en producción vendrían de nodos reales)
            node_updates = {}
            base_accuracy = 0.65 + (round_num - 1) * 0.02  # Mejora progresiva
            base_loss = 2.5 - (round_num - 1) * 0.15

            for node_id in round_participants:
                # Añadir variación por nodo para realismo
                node_variation = hash(node_id) % 100 / 1000  # Pequeña variación
                node_updates[node_id] = {
                    "weights": training_loop.model.state_dict(),
                    "samples_processed": 100 + (hash(node_id) % 50),  # 100-149 samples
                    "accuracy": base_accuracy + node_variation,
                    "loss": base_loss - node_variation,
                    "training_time": 8.0 + node_variation * 4,  # 8-12 segundos
                    "gradient_norm": 0.8 + node_variation,
                    "public_key": f"pk_{node_id}"
                }

            print(f"📦 Generadas {len(node_updates)} actualizaciones de nodos")

            # Recopilar actualizaciones
            if await training_loop.collect_node_updates(node_updates):
                # Agregar y actualizar modelo global
                round_result = await training_loop.aggregate_and_update_global_model()

                print("   📊 Resultados de la ronda:")
                print(f"   📉 Loss: {round_result.global_loss:.4f}")
                print(f"   📈 Accuracy: {round_result.global_accuracy:.2f}")
                print(f"   🔄 Convergence: {round_result.convergence_score:.4f}")
                print(f"   📊 Learning Progress: {round_result.learning_progress:.4f}")
                print(f"   💰 Rewards: {sum(round_result.rewards_distributed.values()):.2f} DRACMA")
                print(f"   🔗 Blockchain TXs: {len(round_result.blockchain_transactions)}")

                training_loop.round_results.append(round_result)
                completed_rounds += 1

                # Verificar si continuar
                should_continue, reason = training_loop.should_continue_training()
                if not should_continue:
                    print(f"   🛑 Entrenamiento detenido: {reason}")
                    break
            else:
                print("   ❌ No se pudieron recopilar suficientes actualizaciones")
                break

        # Resultados finales
        if completed_rounds > 0:
            print("\n🎉 ENTRENAMIENTO FEDERADO COMPLETADO")
            print("=" * 60)

            stats = training_loop.get_training_stats()
            final_round = training_loop.round_results[-1]

            print(f"✅ Rondas completadas: {completed_rounds}/{args.num_rounds}")
            print(f"📈 Accuracy final: {final_round.global_accuracy:.2f}")
            print(f"📉 Loss final: {final_round.global_loss:.4f}")
            print(f"💰 Total rewards: {stats['rewards_stats']['total_distributed']:.2f} DRACMA")
            print(f"🔄 Estado sincronizado: {stats['sync_stats']['last_sync_round']} rondas")
            print(f"📂 Checkpoints: {args.checkpoint_dir}")

            # Guardar resultados
            results_summary = {
                "session_id": args.session_id,
                "configuration": {
                    "num_rounds": args.num_rounds,
                    "min_participants": args.min_participants,
                    "datasets": args.datasets,
                    "use_tenseal": args.use_tenseal,
                    "enable_rewards": args.enable_rewards
                },
                "results": {
                    "completed_rounds": completed_rounds,
                    "final_accuracy": final_round.global_accuracy,
                    "final_loss": final_round.global_loss,
                    "total_rewards": stats['rewards_stats']['total_distributed'],
                    "learning_validation": stats['learning_validation'],
                    "rounds_detail": [
                        {
                            "round": r.round_number,
                            "accuracy": r.global_accuracy,
                            "loss": r.global_loss,
                            "participants": len(r.participants),
                            "rewards": sum(r.rewards_distributed.values()),
                            "blockchain_txs": len(r.blockchain_transactions)
                        } for r in training_loop.round_results
                    ]
                },
                "timestamp": asyncio.get_event_loop().time()
            }

            # Guardar resultados en archivo
            with open(args.output_file, 'w', encoding='utf-8') as f:
                json.dump(results_summary, f, indent=2, ensure_ascii=False)

            print(f"💾 Resultados guardados en: {args.output_file}")

            # Guardar checkpoint final
            checkpoint_path = await training_loop.save_checkpoint()
            print(f"💾 Checkpoint final: {checkpoint_path}")

            return True
        else:
            print("❌ No se completó ninguna ronda de entrenamiento")
            return False

    except Exception as e:
        print(f"❌ Error durante el entrenamiento: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return False


async def main():
    """Función principal."""
    args = parse_arguments()

    # Configurar logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    setup_logging(level=log_level)

    try:
        if args.demo:
            # Ejecutar demo simplificada
            print("🎭 Ejecutando demo simplificada...")
            results = await run_real_federated_training_demo()
            if "error" in results:
                print(f"❌ Error en demo: {results['error']}")
                return 1
            else:
                print("✅ Demo completada exitosamente")
                return 0
        else:
            # Ejecutar entrenamiento personalizado
            success = await run_custom_training(args)
            return 0 if success else 1

    except KeyboardInterrupt:
        print("\n⚠️ Entrenamiento interrumpido por el usuario")
        return 1
    except Exception as e:
        print(f"❌ Error fatal: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)