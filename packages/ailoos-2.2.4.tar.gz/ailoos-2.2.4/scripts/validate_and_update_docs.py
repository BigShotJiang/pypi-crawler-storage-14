#!/usr/bin/env python3
"""
Validación de resultados de benchmarks contra baselines existentes y actualización automática de documentación.

Este script:
- Compara nuevos resultados de benchmarks con los existentes en reports/
- Valida consistencia de métricas
- Genera alertas de regresión
- Actualiza automáticamente README.md y docs/ con nuevos resultados
- Incluye análisis de tendencias y generación de changelog
- Se integra con el pipeline CI/CD

Uso:
    python scripts/validate_and_update_docs.py --new-results-dir ./reports --baseline-dir ./reports --docs-dir ./docs --readme ./README.md
"""

import os
import sys
import json
import logging
import argparse
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import statistics
import re
from collections import defaultdict

# Configuración de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('benchmark_validation.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@dataclass
class ValidationConfig:
    """Configuración de validación."""
    # Thresholds para detectar regresiones (porcentaje)
    throughput_regression_threshold: float = -10.0  # -10% es regresión
    latency_regression_threshold: float = 10.0     # +10% es regresión
    error_rate_regression_threshold: float = 5.0    # +5% absoluto es regresión
    memory_regression_threshold: float = 20.0       # +20% es regresión

    # Thresholds para validación de consistencia
    min_throughput_ops_per_sec: float = 0.0
    max_reasonable_latency_ms: float = 600000.0  # 10 minutos máximo razonable para operaciones masivas
    max_error_rate: float = 100.0  # máximo 100%

    # Configuración de tendencias
    min_results_for_trend: int = 3
    trend_analysis_days: int = 30

    # Configuración de actualización de docs
    update_readme: bool = True
    update_docs: bool = True
    generate_changelog: bool = True

    # Configuración de alertas
    alert_on_regression: bool = True
    alert_severity_levels: Dict[str, float] = field(default_factory=lambda: {
        'low': 5.0,
        'medium': 15.0,
        'high': 30.0,
        'critical': 50.0
    })


@dataclass
class BenchmarkResult:
    """Resultado individual de benchmark."""
    suite_name: str
    backend: str
    benchmark_type: str
    operation: str
    data_size: int
    iterations: int
    total_time_ms: float
    avg_time_ms: float
    min_time_ms: float
    max_time_ms: float
    throughput_ops_per_sec: float
    memory_usage_mb: Optional[float]
    error_rate: float
    timestamp: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            'suite_name': self.suite_name,
            'backend': self.backend,
            'benchmark_type': self.benchmark_type,
            'operation': self.operation,
            'data_size': self.data_size,
            'iterations': self.iterations,
            'total_time_ms': self.total_time_ms,
            'avg_time_ms': self.avg_time_ms,
            'min_time_ms': self.min_time_ms,
            'max_time_ms': self.max_time_ms,
            'throughput_ops_per_sec': self.throughput_ops_per_sec,
            'memory_usage_mb': self.memory_usage_mb,
            'error_rate': self.error_rate,
            'timestamp': self.timestamp
        }


@dataclass
class ValidationResult:
    """Resultado de validación."""
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    regressions: List[Dict[str, Any]] = field(default_factory=list)
    improvements: List[Dict[str, Any]] = field(default_factory=list)


class BenchmarkValidator:
    """Validador principal de benchmarks."""

    def __init__(self, config: ValidationConfig):
        self.config = config
        self.new_results: List[BenchmarkResult] = []
        self.baseline_results: List[BenchmarkResult] = []
        self.validation_result = ValidationResult(True)

    def load_results(self, new_results_dir: str, baseline_dir: str) -> bool:
        """
        Carga resultados nuevos y baselines.

        Args:
            new_results_dir: Directorio con resultados nuevos
            baseline_dir: Directorio con resultados baseline

        Returns:
            True si se cargaron correctamente
        """
        try:
            # Cargar resultados nuevos
            self.new_results = self._load_results_from_dir(new_results_dir)
            logger.info(f"✅ Cargados {len(self.new_results)} resultados nuevos")

            # Cargar resultados baseline
            self.baseline_results = self._load_results_from_dir(baseline_dir)
            logger.info(f"✅ Cargados {len(self.baseline_results)} resultados baseline")

            return True

        except Exception as e:
            logger.error(f"❌ Error cargando resultados: {e}")
            self.validation_result.errors.append(f"Error cargando resultados: {e}")
            return False

    def _load_results_from_dir(self, results_dir: str) -> List[BenchmarkResult]:
        """Carga resultados desde un directorio."""
        results = []

        if not os.path.exists(results_dir):
            logger.warning(f"Directorio no existe: {results_dir}")
            return results

        # Buscar archivos JSON de resultados
        for file_path in Path(results_dir).glob("benchmark_results_*.json"):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # Parsear resultados
                if 'results' in data:
                    for suite in data['results']:
                        suite_results = self._parse_suite_results(suite)
                        results.extend(suite_results)

            except Exception as e:
                logger.warning(f"Error cargando {file_path}: {e}")
                continue

        return results

    def _parse_suite_results(self, suite_data: Dict[str, Any]) -> List[BenchmarkResult]:
        """Parsea resultados de una suite."""
        results = []

        suite_name = suite_data.get('suite_name', 'unknown')
        backend = suite_data.get('backend', 'unknown')

        for result_data in suite_data.get('results', []):
            try:
                result = BenchmarkResult(
                    suite_name=suite_name,
                    backend=backend,
                    benchmark_type=result_data.get('benchmark_type', 'unknown'),
                    operation=result_data.get('operation', 'unknown'),
                    data_size=result_data.get('data_size', 0),
                    iterations=result_data.get('iterations', 0),
                    total_time_ms=result_data.get('total_time_ms', 0.0),
                    avg_time_ms=result_data.get('avg_time_ms', 0.0),
                    min_time_ms=result_data.get('min_time_ms', 0.0),
                    max_time_ms=result_data.get('max_time_ms', 0.0),
                    throughput_ops_per_sec=result_data.get('throughput_ops_per_sec', 0.0),
                    memory_usage_mb=result_data.get('memory_usage_mb'),
                    error_rate=result_data.get('error_rate', 0.0),
                    timestamp=result_data.get('timestamp', 0.0)
                )
                results.append(result)

            except Exception as e:
                logger.warning(f"Error parseando resultado: {e}")
                continue

        return results

    def validate_consistency(self) -> ValidationResult:
        """
        Valida consistencia de los resultados nuevos.

        Returns:
            ValidationResult con estado de validación
        """
        logger.info("🔍 Validando consistencia de resultados...")

        for result in self.new_results:
            # Validar throughput
            if result.throughput_ops_per_sec < self.config.min_throughput_ops_per_sec:
                self.validation_result.warnings.append(
                    f"Throughput negativo o cero en {result.suite_name}/{result.operation}: {result.throughput_ops_per_sec}"
                )

            # Validar latencia
            if result.avg_time_ms < 0 or result.avg_time_ms > self.config.max_reasonable_latency_ms:
                self.validation_result.errors.append(
                    f"Latencia inválida en {result.suite_name}/{result.operation}: {result.avg_time_ms}ms"
                )

            # Validar error rate
            if result.error_rate < 0 or result.error_rate > self.config.max_error_rate:
                self.validation_result.errors.append(
                    f"Error rate inválido en {result.suite_name}/{result.operation}: {result.error_rate}%"
                )

            # Validar tiempos
            if result.min_time_ms > result.avg_time_ms or result.max_time_ms < result.avg_time_ms:
                self.validation_result.warnings.append(
                    f"Tiempos inconsistentes en {result.suite_name}/{result.operation}: "
                    f"min={result.min_time_ms}, avg={result.avg_time_ms}, max={result.max_time_ms}"
                )

        # Marcar como inválido si hay errores críticos
        if self.validation_result.errors:
            self.validation_result.is_valid = False

        logger.info(f"✅ Validación completada: {len(self.validation_result.errors)} errores, {len(self.validation_result.warnings)} advertencias")
        return self.validation_result

    def compare_with_baselines(self) -> ValidationResult:
        """
        Compara resultados nuevos con baselines para detectar regresiones.

        Returns:
            ValidationResult con comparaciones
        """
        logger.info("📊 Comparando con baselines...")

        if not self.baseline_results:
            logger.warning("No hay resultados baseline para comparar")
            return self.validation_result

        # Agrupar resultados por suite/operation/data_size
        new_grouped = self._group_results(self.new_results)
        baseline_grouped = self._group_results(self.baseline_results)

        for key, new_results in new_grouped.items():
            if key not in baseline_grouped:
                continue

            baseline_results = baseline_grouped[key]

            # Calcular métricas promedio para comparación
            new_avg_throughput = statistics.mean(r.throughput_ops_per_sec for r in new_results)
            baseline_avg_throughput = statistics.mean(r.throughput_ops_per_sec for r in baseline_results)

            new_avg_latency = statistics.mean(r.avg_time_ms for r in new_results)
            baseline_avg_latency = statistics.mean(r.avg_time_ms for r in baseline_results)

            new_avg_error_rate = statistics.mean(r.error_rate for r in new_results)
            baseline_avg_error_rate = statistics.mean(r.error_rate for r in baseline_results)

            # Detectar regresiones
            throughput_change = ((new_avg_throughput - baseline_avg_throughput) / baseline_avg_throughput) * 100
            latency_change = ((new_avg_latency - baseline_avg_latency) / baseline_avg_latency) * 100
            error_rate_change = new_avg_error_rate - baseline_avg_error_rate

            regression_info = {
                'suite_operation': key,
                'throughput_change_pct': throughput_change,
                'latency_change_pct': latency_change,
                'error_rate_change_pct': error_rate_change,
                'new_throughput': new_avg_throughput,
                'baseline_throughput': baseline_avg_throughput,
                'new_latency': new_avg_latency,
                'baseline_latency': baseline_avg_latency
            }

            # Check for regressions
            if throughput_change < self.config.throughput_regression_threshold:
                self.validation_result.regressions.append({
                    **regression_info,
                    'type': 'throughput_regression',
                    'severity': self._calculate_severity(abs(throughput_change))
                })

            if latency_change > self.config.latency_regression_threshold:
                self.validation_result.regressions.append({
                    **regression_info,
                    'type': 'latency_regression',
                    'severity': self._calculate_severity(latency_change)
                })

            if error_rate_change > self.config.error_rate_regression_threshold:
                self.validation_result.regressions.append({
                    **regression_info,
                    'type': 'error_rate_regression',
                    'severity': self._calculate_severity(error_rate_change)
                })

            # Check for improvements
            if throughput_change > abs(self.config.throughput_regression_threshold):
                self.validation_result.improvements.append({
                    **regression_info,
                    'type': 'throughput_improvement'
                })

            if latency_change < -abs(self.config.latency_regression_threshold):
                self.validation_result.improvements.append({
                    **regression_info,
                    'type': 'latency_improvement'
                })

        logger.info(f"✅ Comparación completada: {len(self.validation_result.regressions)} regresiones, {len(self.validation_result.improvements)} mejoras")
        return self.validation_result

    def _group_results(self, results: List[BenchmarkResult]) -> Dict[str, List[BenchmarkResult]]:
        """Agrupa resultados por suite/operation/data_size."""
        grouped = defaultdict(list)

        for result in results:
            key = f"{result.suite_name}/{result.operation}/{result.data_size}"
            grouped[key].append(result)

        return dict(grouped)

    def _calculate_severity(self, change_pct: float) -> str:
        """Calcula severidad de una regresión."""
        for level, threshold in sorted(self.config.alert_severity_levels.items(), key=lambda x: x[1]):
            if change_pct >= threshold:
                return level
        return 'low'

    def analyze_trends(self) -> Dict[str, Any]:
        """
        Analiza tendencias en los resultados.

        Returns:
            Diccionario con análisis de tendencias
        """
        logger.info("📈 Analizando tendencias...")

        if len(self.baseline_results) < self.config.min_results_for_trend:
            logger.warning("Insuficientes resultados para análisis de tendencias")
            return {}

        # Ordenar resultados por timestamp
        all_results = sorted(self.new_results + self.baseline_results, key=lambda x: x.timestamp)

        # Agrupar por suite/operation
        trends = {}

        grouped = defaultdict(list)
        for result in all_results:
            key = f"{result.suite_name}/{result.operation}"
            grouped[key].append(result)

        for key, results in grouped.items():
            if len(results) < self.config.min_results_for_trend:
                continue

            # Calcular tendencias
            throughputs = [r.throughput_ops_per_sec for r in results]
            latencies = [r.avg_time_ms for r in results]
            timestamps = [r.timestamp for r in results]

            try:
                throughput_trend = self._calculate_trend(timestamps, throughputs)
                latency_trend = self._calculate_trend(timestamps, latencies)

                trends[key] = {
                    'throughput_trend_pct': throughput_trend,
                    'latency_trend_pct': latency_trend,
                    'data_points': len(results),
                    'time_span_days': (max(timestamps) - min(timestamps)) / (24 * 3600)
                }

            except Exception as e:
                logger.warning(f"Error calculando tendencia para {key}: {e}")
                continue

        logger.info(f"✅ Análisis de tendencias completado para {len(trends)} suites")
        return trends

    def _calculate_trend(self, timestamps: List[float], values: List[float]) -> float:
        """Calcula la tendencia porcentual usando regresión lineal simple."""
        import numpy as np

        if len(timestamps) != len(values) or len(values) < 2:
            return 0.0

        # Normalizar timestamps a días desde el inicio
        t0 = min(timestamps)
        x = np.array([(t - t0) / (24 * 3600) for t in timestamps])
        y = np.array(values)

        # Regresión lineal
        if np.std(x) == 0:
            return 0.0

        slope = np.polyfit(x, y, 1)[0]

        # Calcular cambio porcentual por día
        avg_value = np.mean(y)
        if avg_value == 0:
            return 0.0

        daily_change_pct = (slope / avg_value) * 100
        return daily_change_pct

    def update_documentation(self, readme_path: str, docs_dir: str) -> bool:
        """
        Actualiza documentación con nuevos resultados.

        Args:
            readme_path: Path al README.md
            docs_dir: Directorio de documentación

        Returns:
            True si se actualizó correctamente
        """
        logger.info("📝 Actualizando documentación...")

        try:
            # Actualizar README.md
            if self.config.update_readme and os.path.exists(readme_path):
                self._update_readme(readme_path)

            # Actualizar docs/
            if self.config.update_docs and os.path.exists(docs_dir):
                self._update_docs(docs_dir)

            logger.info("✅ Documentación actualizada")
            return True

        except Exception as e:
            logger.error(f"❌ Error actualizando documentación: {e}")
            return False

    def _update_readme(self, readme_path: str):
        """Actualiza README.md con resultados de benchmarks."""
        with open(readme_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Encontrar sección de benchmarks
        benchmark_section_pattern = r'(## 🚀 Benchmarks.*?)(\n## |\n### |\Z)'
        match = re.search(benchmark_section_pattern, content, re.DOTALL)

        if match:
            # Generar nueva sección de benchmarks
            new_benchmark_section = self._generate_benchmark_section()

            # Reemplazar sección existente
            content = content.replace(match.group(1), new_benchmark_section)

        else:
            # Añadir sección al final
            content += "\n" + self._generate_benchmark_section()

        # Escribir archivo actualizado
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(content)

    def _generate_benchmark_section(self) -> str:
        """Genera sección de benchmarks para README."""
        section = "## 🚀 Benchmarks\n\n"

        # Resumen general
        total_operations = len(self.new_results)
        avg_throughput = statistics.mean(r.throughput_ops_per_sec for r in self.new_results) if self.new_results else 0
        avg_latency = statistics.mean(r.avg_time_ms for r in self.new_results) if self.new_results else 0

        section += f"### 📊 Resumen de Rendimiento\n\n"
        section += f"- **Total de operaciones benchmarkeadas**: {total_operations}\n"
        section += f"- **Throughput promedio**: {avg_throughput:.2f} ops/seg\n"
        section += f"- **Latencia promedio**: {avg_latency:.2f} ms\n"
        section += f"- **Última actualización**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"

        # Resultados por suite
        section += "### 📈 Resultados por Suite\n\n"
        section += "| Suite | Backend | Operación | Throughput (ops/seg) | Latencia (ms) |\n"
        section += "|-------|---------|-----------|---------------------|---------------|\n"

        # Agrupar y mostrar top resultados
        suite_summary = defaultdict(list)
        for result in self.new_results:
            key = f"{result.suite_name}/{result.backend}"
            suite_summary[key].append(result)

        for suite_key, results in list(suite_summary.items())[:10]:  # Top 10
            avg_throughput = statistics.mean(r.throughput_ops_per_sec for r in results)
            avg_latency = statistics.mean(r.avg_time_ms for r in results)
            suite_name, backend = suite_key.split('/', 1)

            section += f"| {suite_name} | {backend} | {results[0].operation} | {avg_throughput:.2f} | {avg_latency:.2f} |\n"

        section += "\n*Para resultados completos, ver [reports/](reports/) y [docs/benchmark_results.md](docs/benchmark_results.md)*\n\n"

        return section

    def _update_docs(self, docs_dir: str):
        """Actualiza archivos en docs/."""
        # Crear archivo de resultados detallados
        benchmark_results_path = os.path.join(docs_dir, 'benchmark_results.md')

        with open(benchmark_results_path, 'w', encoding='utf-8') as f:
            f.write("# 📊 Resultados de Benchmarks\n\n")
            f.write(f"Última actualización: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")

            # Resultados detallados
            f.write("## 📈 Resultados Detallados\n\n")

            for result in self.new_results[:50]:  # Limitar a 50 para no hacer archivo demasiado grande
                f.write(f"### {result.suite_name} - {result.backend}\n\n")
                f.write(f"- **Operación**: {result.operation}\n")
                f.write(f"- **Tipo**: {result.benchmark_type}\n")
                f.write(f"- **Tamaño de datos**: {result.data_size}\n")
                f.write(f"- **Iteraciones**: {result.iterations}\n")
                f.write(f"- **Throughput**: {result.throughput_ops_per_sec:.2f} ops/seg\n")
                f.write(f"- **Latencia promedio**: {result.avg_time_ms:.2f} ms\n")
                f.write(f"- **Latencia min/max**: {result.min_time_ms:.2f}/{result.max_time_ms:.2f} ms\n")
                f.write(f"- **Error rate**: {result.error_rate:.2f}%\n")
                if result.memory_usage_mb:
                    f.write(f"- **Uso de memoria**: {result.memory_usage_mb:.2f} MB\n")
                f.write(f"- **Timestamp**: {datetime.fromtimestamp(result.timestamp).strftime('%Y-%m-%d %H:%M:%S')}\n\n")

    def generate_changelog(self, changelog_path: str) -> bool:
        """
        Genera changelog con cambios en benchmarks.

        Args:
            changelog_path: Path al archivo CHANGELOG.md

        Returns:
            True si se generó correctamente
        """
        logger.info("📝 Generando changelog...")

        try:
            # Leer changelog existente
            existing_content = ""
            if os.path.exists(changelog_path):
                with open(changelog_path, 'r', encoding='utf-8') as f:
                    existing_content = f.read()

            # Generar nueva entrada
            new_entry = self._generate_changelog_entry()

            # Insertar al inicio
            if existing_content.startswith('# Changelog'):
                # Encontrar primera sección de versión
                version_pattern = r'(# \d+\.\d+\.\d+.*?)(\n# |\Z)'
                match = re.search(version_pattern, existing_content, re.DOTALL)

                if match:
                    insert_pos = match.start()
                    updated_content = existing_content[:insert_pos] + new_entry + existing_content[insert_pos:]
                else:
                    updated_content = existing_content + "\n" + new_entry
            else:
                updated_content = f"# Changelog\n\n{new_entry}{existing_content}"

            # Escribir archivo actualizado
            with open(changelog_path, 'w', encoding='utf-8') as f:
                f.write(updated_content)

            logger.info("✅ Changelog actualizado")
            return True

        except Exception as e:
            logger.error(f"❌ Error generando changelog: {e}")
            return False

    def _generate_changelog_entry(self) -> str:
        """Genera entrada de changelog."""
        timestamp = datetime.now().strftime('%Y-%m-%d')

        entry = f"## [{timestamp}] Benchmark Results Update\n\n"

        # Regresiones
        if self.validation_result.regressions:
            entry += "### ⚠️ Regresiones Detectadas\n\n"
            for regression in self.validation_result.regressions:
                severity = regression.get('severity', 'low')
                emoji = {'low': '⚠️', 'medium': '🟡', 'high': '🟠', 'critical': '🔴'}.get(severity, '⚠️')

                if regression['type'] == 'throughput_regression':
                    entry += f"- {emoji} **Throughput regression** en {regression['suite_operation']}: {regression['throughput_change_pct']:+.1f}% "
                    entry += f"({regression['baseline_throughput']:.2f} → {regression['new_throughput']:.2f} ops/seg)\n"
                elif regression['type'] == 'latency_regression':
                    entry += f"- {emoji} **Latency regression** en {regression['suite_operation']}: {regression['latency_change_pct']:+.1f}% "
                    entry += f"({regression['baseline_latency']:.2f} → {regression['new_latency']:.2f} ms)\n"
                elif regression['type'] == 'error_rate_regression':
                    entry += f"- {emoji} **Error rate increase** en {regression['suite_operation']}: {regression['error_rate_change_pct']:+.1f}%\n"

            entry += "\n"

        # Mejoras
        if self.validation_result.improvements:
            entry += "### ✅ Mejoras Detectadas\n\n"
            for improvement in self.validation_result.improvements:
                if improvement['type'] == 'throughput_improvement':
                    entry += f"- 🚀 **Throughput improvement** en {improvement['suite_operation']}: {improvement['throughput_change_pct']:+.1f}% "
                    entry += f"({improvement['baseline_throughput']:.2f} → {improvement['new_throughput']:.2f} ops/seg)\n"
                elif improvement['type'] == 'latency_improvement':
                    entry += f"- ⚡ **Latency improvement** en {improvement['suite_operation']}: {improvement['latency_change_pct']:+.1f}% "
                    entry += f"({improvement['baseline_latency']:.2f} → {improvement['new_latency']:.2f} ms)\n"

            entry += "\n"

        # Estadísticas generales
        total_operations = len(self.new_results)
        avg_throughput = statistics.mean(r.throughput_ops_per_sec for r in self.new_results) if self.new_results else 0

        entry += "### 📊 Estadísticas Generales\n\n"
        entry += f"- Total de operaciones benchmarkeadas: {total_operations}\n"
        entry += f"- Throughput promedio: {avg_throughput:.2f} ops/seg\n"
        entry += f"- Suites testeadas: {len(set(r.suite_name for r in self.new_results))}\n"
        entry += f"- Backends testeados: {len(set(r.backend for r in self.new_results))}\n\n"

        return entry

    def generate_alerts(self) -> List[str]:
        """
        Genera alertas basadas en validación.

        Returns:
            Lista de mensajes de alerta
        """
        alerts = []

        # Alertas de errores de validación
        if self.validation_result.errors:
            alerts.append(f"🚨 ERRORES DE VALIDACIÓN: {len(self.validation_result.errors)} errores encontrados")
            for error in self.validation_result.errors[:5]:  # Top 5
                alerts.append(f"  • {error}")

        # Alertas de regresiones críticas
        critical_regressions = [r for r in self.validation_result.regressions if r.get('severity') in ['high', 'critical']]
        if critical_regressions:
            alerts.append(f"🔴 REGRESIONES CRÍTICAS: {len(critical_regressions)} regresiones críticas detectadas")
            for regression in critical_regressions:
                alerts.append(f"  • {regression['type']} en {regression['suite_operation']}")

        # Alertas de advertencias
        if self.validation_result.warnings:
            alerts.append(f"⚠️ ADVERTENCIAS: {len(self.validation_result.warnings)} advertencias")

        return alerts

    def run_validation_pipeline(self, new_results_dir: str, baseline_dir: str,
                              readme_path: str, docs_dir: str, changelog_path: str) -> bool:
        """
        Ejecuta el pipeline completo de validación.

        Returns:
            True si todo el pipeline se ejecutó correctamente
        """
        logger.info("🚀 Iniciando pipeline de validación de benchmarks...")

        success = True

        # 1. Cargar resultados
        if not self.load_results(new_results_dir, baseline_dir):
            return False

        # 2. Validar consistencia
        validation = self.validate_consistency()
        if not validation.is_valid:
            logger.error("❌ Validación de consistencia fallida")
            success = False

        # 3. Comparar con baselines
        self.compare_with_baselines()

        # 4. Analizar tendencias
        trends = self.analyze_trends()

        # 5. Generar alertas
        alerts = self.generate_alerts()
        for alert in alerts:
            logger.warning(alert)

        # 6. Actualizar documentación
        if not self.update_documentation(readme_path, docs_dir):
            success = False

        # 7. Generar changelog
        if self.config.generate_changelog:
            if not self.generate_changelog(changelog_path):
                success = False

        # 8. Reporte final
        self._generate_final_report(trends, alerts)

        logger.info(f"✅ Pipeline completado {'con éxito' if success else 'con errores'}")
        return success

    def _generate_final_report(self, trends: Dict[str, Any], alerts: List[str]):
        """Genera reporte final."""
        logger.info("📋 Reporte Final de Validación:")
        logger.info(f"  • Resultados nuevos: {len(self.new_results)}")
        logger.info(f"  • Resultados baseline: {len(self.baseline_results)}")
        logger.info(f"  • Errores de validación: {len(self.validation_result.errors)}")
        logger.info(f"  • Advertencias: {len(self.validation_result.warnings)}")
        logger.info(f"  • Regresiones detectadas: {len(self.validation_result.regressions)}")
        logger.info(f"  • Mejoras detectadas: {len(self.validation_result.improvements)}")
        logger.info(f"  • Suites con tendencias analizadas: {len(trends)}")
        logger.info(f"  • Alertas generadas: {len(alerts)}")


def main():
    """Función principal."""
    parser = argparse.ArgumentParser(description='Validación de benchmarks y actualización de documentación')
    parser.add_argument('--new-results-dir', type=str, default='./reports',
                       help='Directorio con resultados nuevos')
    parser.add_argument('--baseline-dir', type=str, default='./reports',
                       help='Directorio con resultados baseline')
    parser.add_argument('--readme', type=str, default='./README.md',
                       help='Path al README.md')
    parser.add_argument('--docs-dir', type=str, default='./docs',
                       help='Directorio de documentación')
    parser.add_argument('--changelog', type=str, default='./CHANGELOG.md',
                       help='Path al CHANGELOG.md')
    parser.add_argument('--throughput-threshold', type=float, default=-10.0,
                       help='Threshold de regresión de throughput (%)')
    parser.add_argument('--latency-threshold', type=float, default=10.0,
                       help='Threshold de regresión de latencia (%)')
    parser.add_argument('--no-update-docs', action='store_true',
                       help='No actualizar documentación')
    parser.add_argument('--no-changelog', action='store_true',
                       help='No generar changelog')

    args = parser.parse_args()

    # Configuración
    config = ValidationConfig(
        throughput_regression_threshold=args.throughput_threshold,
        latency_regression_threshold=args.latency_threshold,
        update_readme=not args.no_update_docs,
        update_docs=not args.no_update_docs,
        generate_changelog=not args.no_changelog
    )

    # Ejecutar validación
    validator = BenchmarkValidator(config)
    success = validator.run_validation_pipeline(
        args.new_results_dir,
        args.baseline_dir,
        args.readme,
        args.docs_dir,
        args.changelog
    )

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()