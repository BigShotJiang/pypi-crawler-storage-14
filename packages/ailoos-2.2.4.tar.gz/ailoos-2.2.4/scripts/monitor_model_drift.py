#!/usr/bin/env python3
"""
Script para monitorear deriva del modelo EmpoorioLM.

Uso:
    python scripts/monitor_model_drift.py --model_path ./models/empoorio_lm/v1.0.0 --history_file ./drift_history.json --check

Opciones:
    --model_path: Ruta del modelo a monitorear
    --history_file: Archivo para almacenar historial de métricas
    --check: Realizar verificación inmediata de deriva
    --report: Generar reporte de deriva para los últimos días
    --days: Número de días para el reporte (default: 7)
    --baseline: Establecer nuevas métricas de referencia
"""

import argparse
import sys
import asyncio
import json
from pathlib import Path

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.inference.model_drift_monitor import create_drift_monitor, DriftThresholds
from transformers import AutoTokenizer
from ailoos.models.empoorio_lm import EmpoorioLM


async def main():
    parser = argparse.ArgumentParser(description="Monitorear deriva del modelo EmpoorioLM")
    parser.add_argument("--model_path", required=True, help="Ruta del modelo a monitorear")
    parser.add_argument("--tokenizer_name", default="gpt2", help="Nombre del tokenizer")
    parser.add_argument("--history_file", default="./drift_history.json",
                       help="Archivo para historial de métricas")
    parser.add_argument("--check", action="store_true",
                       help="Realizar verificación inmediata de deriva")
    parser.add_argument("--report", action="store_true",
                       help="Generar reporte de deriva")
    parser.add_argument("--days", type=int, default=7,
                       help="Número de días para el reporte")
    parser.add_argument("--baseline", action="store_true",
                       help="Establecer nuevas métricas de referencia")
    parser.add_argument("--thresholds", nargs=4, type=float,
                       default=[0.1, 0.05, 0.05, 0.1],
                       help="Umbrales: perplexity, bleu, rouge, similarity")

    args = parser.parse_args()

    print("📊 Monitor de Deriva del Modelo EmpoorioLM")
    print(f"   Modelo: {args.model_path}")
    print(f"   Historial: {args.history_file}")

    try:
        # Cargar modelo y tokenizer
        print("\n📥 Cargando modelo y tokenizer...")
        model = EmpoorioLM.from_pretrained(args.model_path)
        model.eval()

        tokenizer = AutoTokenizer.from_pretrained(args.tokenizer_name)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        # Dataset de referencia (puede ser configurable)
        reference_dataset = [
            "¿Cuál es la capital de Francia?",
            "Explica la teoría de la relatividad en términos simples",
            "Escribe un poema corto sobre la naturaleza",
            "¿Cómo funciona la fotosíntesis?",
            "Traduce 'Hello world' al español",
            "¿Qué es el aprendizaje automático?",
            "Describe los planetas del sistema solar",
            "Escribe una receta simple de pasta",
            "¿Cuál es la diferencia entre IA y machine learning?",
            "Explica el concepto de blockchain"
        ]

        # Configurar umbrales
        thresholds = DriftThresholds(
            perplexity_threshold=args.thresholds[0],
            bleu_threshold=args.thresholds[1],
            rouge_threshold=args.thresholds[2],
            similarity_threshold=args.thresholds[3]
        )

        # Crear monitor
        print("🔧 Inicializando monitor de deriva...")
        monitor = await create_drift_monitor(
            model=model,
            tokenizer=tokenizer,
            reference_dataset=reference_dataset,
            history_file=args.history_file
        )

        # Operaciones
        if args.baseline:
            print("\n🎯 Estableciendo baseline...")
            success = await monitor.establish_baseline()
            if success:
                print("✅ Baseline establecido exitosamente")
            else:
                print("❌ Error estableciendo baseline")
                return

        if args.check:
            print("\n🔍 Verificando deriva...")
            result = await monitor.check_drift()

            print("📊 Resultados de verificación:")
            print(f"   Deriva detectada: {result['drift_detected']}")
            if result['drift_detected']:
                print(f"   Razones: {result['reason']}")
                print("   📈 Cambios detectados:")
                changes = result['changes']
                print(f"      Perplexity: {changes['perplexity']:.3f}")
                print(f"      BLEU: {changes['bleu']:.3f}")
                print(f"      ROUGE: {changes['rouge']:.3f}")
                print(f"      Similitud: {changes['similarity']:.3f}")

            print(f"   Alertas consecutivas: {result['consecutive_alerts']}")

        if args.report:
            print(f"\n📈 Generando reporte de deriva ({args.days} días)...")
            report = await monitor.get_drift_report(days=args.days)

            print("📊 Reporte de Deriva:")
            print(f"   Período: {args.days} días")
            print(f"   Mediciones totales: {report['total_measurements']}")
            print(f"   Tendencia: {report['trend']}")

            if report['latest_metrics']:
                latest = report['latest_metrics']
                print("   Últimas métricas:")
                print(f"      Perplexity: {latest['perplexity']:.3f}")
                print(f"      BLEU: {latest['bleu_score']:.3f}")
                print(f"      ROUGE: {latest['rouge_score']:.3f}")
                print(f"      Similitud: {latest['semantic_similarity']:.3f}")

            if report.get('baseline_comparison'):
                bc = report['baseline_comparison']
                if bc['drift_detected']:
                    print("   ⚠️ Deriva detectada vs baseline:")
                    print(f"      Razones: {bc['reason']}")

        print("\n✅ Operación completada exitosamente")

    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())