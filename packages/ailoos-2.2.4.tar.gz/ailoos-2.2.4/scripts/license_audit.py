#!/usr/bin/env python3
"""
License Audit Script for EmpoorioLM Dependencies
Uses ScanCode to scan Python requirements and generate license compliance reports.
"""

import subprocess
import sys
import os
import json
from pathlib import Path
from typing import Dict, List, Optional
import argparse

class LicenseAuditor:
    def __init__(self, requirements_file: str = "requirements.txt"):
        self.requirements_file = Path(requirements_file)
        self.output_dir = Path("reports")
        self.output_dir.mkdir(exist_ok=True)

    def check_scancode_installed(self) -> bool:
        """Check if ScanCode is installed."""
        try:
            result = subprocess.run(
                ["scancode", "--version"],
                capture_output=True,
                text=True,
                check=True
            )
            print(f"✅ ScanCode version: {result.stdout.strip()}")
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("❌ ScanCode not found. Installing...")
            return False

    def install_scancode(self) -> bool:
        """Install ScanCode using pip."""
        try:
            subprocess.run([
                sys.executable, "-m", "pip", "install", "scancode-toolkit"
            ], check=True)
            print("✅ ScanCode installed successfully")
            return True
        except subprocess.CalledProcessError as e:
            print(f"❌ Failed to install ScanCode: {e}")
            return False

    def run_license_scan(self) -> Optional[Dict]:
        """Run ScanCode license scan on requirements.txt."""
        if not self.requirements_file.exists():
            print(f"❌ Requirements file not found: {self.requirements_file}")
            return None

        output_file = self.output_dir / "license_scan.json"

        try:
            # Run ScanCode with license detection
            cmd = [
                "scancode",
                "--license",
                "--license-text",
                "--json", str(output_file),
                str(self.requirements_file)
            ]

            print(f"🔍 Scanning licenses for {self.requirements_file}...")
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)

            print("✅ License scan completed")

            # Load and return results
            with open(output_file, 'r') as f:
                return json.load(f)

        except subprocess.CalledProcessError as e:
            print(f"❌ License scan failed: {e}")
            if e.stderr:
                print(f"Error output: {e.stderr}")
            return None

    def analyze_licenses(self, scan_results: Dict) -> Dict:
        """Analyze scan results and categorize licenses."""
        licenses_found = {}
        risky_licenses = {
            'GPL', 'LGPL', 'AGPL',  # Copyleft licenses
            'MS-PL', 'BSD-4-Clause',  # Potentially problematic
        }

        compliant_licenses = {
            'MIT', 'Apache-2.0', 'BSD-2-Clause', 'BSD-3-Clause',
            'ISC', 'CC0-1.0', 'Unlicense'
        }

        for file_result in scan_results.get('files', []):
            for license_info in file_result.get('licenses', []):
                license_key = license_info.get('key', 'unknown')
                if license_key not in licenses_found:
                    licenses_found[license_key] = {
                        'count': 0,
                        'files': [],
                        'risk_level': 'unknown'
                    }

                licenses_found[license_key]['count'] += 1
                licenses_found[license_key]['files'].append(file_result['path'])

                # Determine risk level
                if license_key in risky_licenses:
                    licenses_found[license_key]['risk_level'] = 'high'
                elif license_key in compliant_licenses:
                    licenses_found[license_key]['risk_level'] = 'low'
                else:
                    licenses_found[license_key]['risk_level'] = 'medium'

        return {
            'summary': {
                'total_licenses': len(licenses_found),
                'high_risk': len([l for l in licenses_found.values() if l['risk_level'] == 'high']),
                'medium_risk': len([l for l in licenses_found.values() if l['risk_level'] == 'medium']),
                'low_risk': len([l for l in licenses_found.values() if l['risk_level'] == 'low']),
            },
            'licenses': licenses_found
        }

    def generate_report(self, analysis: Dict) -> str:
        """Generate a human-readable license compliance report."""
        report = []
        report.append("# License Compliance Report for EmpoorioLM")
        report.append("")
        report.append("## Summary")
        report.append(f"- Total unique licenses found: {analysis['summary']['total_licenses']}")
        report.append(f"- High risk licenses: {analysis['summary']['high_risk']}")
        report.append(f"- Medium risk licenses: {analysis['summary']['medium_risk']}")
        report.append(f"- Low risk licenses: {analysis['summary']['low_risk']}")
        report.append("")

        if analysis['summary']['high_risk'] > 0:
            report.append("⚠️  **WARNING**: High-risk licenses detected!")
            report.append("Review the following licenses for compliance:")
            report.append("")

        report.append("## License Details")
        for license_key, info in analysis['licenses'].items():
            risk_icon = {
                'high': '🔴',
                'medium': '🟡',
                'low': '🟢',
                'unknown': '⚪'
            }.get(info['risk_level'], '⚪')

            report.append(f"### {risk_icon} {license_key} ({info['risk_level']} risk)")
            report.append(f"- Used in {info['count']} file(s)")
            report.append("- Files:")
            for file in info['files'][:5]:  # Limit to first 5 files
                report.append(f"  - {file}")
            if len(info['files']) > 5:
                report.append(f"  - ... and {len(info['files']) - 5} more")
            report.append("")

        return "\n".join(report)

    def save_report(self, report: str, filename: str = "license_compliance_report.md"):
        """Save the report to a file."""
        report_file = self.output_dir / filename
        with open(report_file, 'w') as f:
            f.write(report)
        print(f"📄 Report saved to: {report_file}")

    def run_audit(self) -> bool:
        """Run the complete license audit process."""
        print("🚀 Starting License Audit for EmpoorioLM Dependencies")
        print("=" * 60)

        # Check/install ScanCode
        if not self.check_scancode_installed():
            if not self.install_scancode():
                return False

        # Run license scan
        scan_results = self.run_license_scan()
        if not scan_results:
            return False

        # Analyze results
        analysis = self.analyze_licenses(scan_results)

        # Generate and save report
        report = self.generate_report(analysis)
        self.save_report(report)

        # Print summary
        print("\n📊 Audit Summary:")
        print(f"   Total licenses: {analysis['summary']['total_licenses']}")
        print(f"   High risk: {analysis['summary']['high_risk']}")
        print(f"   Medium risk: {analysis['summary']['medium_risk']}")
        print(f"   Low risk: {analysis['summary']['low_risk']}")

        # Exit with error if high-risk licenses found
        if analysis['summary']['high_risk'] > 0:
            print("\n❌ Audit FAILED: High-risk licenses detected!")
            return False

        print("\n✅ Audit PASSED: No high-risk licenses found")
        return True

def main():
    parser = argparse.ArgumentParser(description="License Audit for EmpoorioLM Dependencies")
    parser.add_argument(
        '--requirements',
        default='requirements.txt',
        help='Path to requirements file (default: requirements.txt)'
    )
    parser.add_argument(
        '--output-dir',
        default='reports',
        help='Output directory for reports (default: reports)'
    )

    args = parser.parse_args()

    auditor = LicenseAuditor(args.requirements)
    auditor.output_dir = Path(args.output_dir)
    auditor.output_dir.mkdir(exist_ok=True)

    success = auditor.run_audit()
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()