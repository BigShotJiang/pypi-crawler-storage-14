#!/bin/bash
# Script to generate Cosign keys and set up GCP Secret Manager secrets
# Run this script to initialize Cosign signing for AILOOS images

set -e

PROJECT_ID=${PROJECT_ID:-$(gcloud config get-value project)}

echo "Setting up Cosign secrets for project: $PROJECT_ID"

# Generate Cosign key pair
echo "Generating Cosign key pair..."
cosign generate-key-pair

# Check if keys were generated
if [ ! -f "cosign.key" ] || [ ! -f "cosign.pub" ]; then
    echo "Error: Cosign key files not found"
    exit 1
fi

# Create secrets in GCP Secret Manager
echo "Creating COSIGN_PRIVATE_KEY secret..."
gcloud secrets create COSIGN_PRIVATE_KEY \
    --data-file=cosign.key \
    --project="$PROJECT_ID" \
    --labels=purpose=cosign-signing

echo "Creating COSIGN_PUBLIC_KEY secret..."
gcloud secrets create COSIGN_PUBLIC_KEY \
    --data-file=cosign.pub \
    --project="$PROJECT_ID" \
    --labels=purpose=cosign-verification

# Clean up local key files
echo "Cleaning up local key files..."
rm cosign.key cosign.pub

echo "✅ Cosign secrets setup complete!"
echo "Private key stored in: projects/$PROJECT_ID/secrets/COSIGN_PRIVATE_KEY"
echo "Public key stored in: projects/$PROJECT_ID/secrets/COSIGN_PUBLIC_KEY"
echo ""
echo "Make sure your Cloud Build service account has access to these secrets."
echo "Grant the 'Secret Manager Secret Accessor' role to the Cloud Build service account."