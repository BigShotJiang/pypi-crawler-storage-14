#!/usr/bin/env python3
"""
Test Script for AILOOS Unified API Gateway
==========================================

Script completo para probar el API Gateway de AILOOS.
Hace requests a todos los endpoints principales y valida respuestas.
"""

import asyncio
import aiohttp
import json
import time
from typing import Dict, Any, List
import logging

# Configuración
API_BASE_URL = "http://localhost:8000"
TIMEOUT = 30  # segundos

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class APITester:
    """Tester completo para el API Gateway de AILOOS."""

    def __init__(self, base_url: str = API_BASE_URL):
        self.base_url = base_url.rstrip('/')
        self.session: aiohttp.ClientSession = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=TIMEOUT))
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()

    async def make_request(self, method: str, endpoint: str, data: Dict[str, Any] = None, headers: Dict[str, str] = None) -> Dict[str, Any]:
        """Hace una request HTTP y retorna el resultado."""
        url = f"{self.base_url}{endpoint}"

        try:
            if method.upper() == 'GET':
                async with self.session.get(url, headers=headers) as response:
                    return await self._process_response(response, endpoint)
            elif method.upper() == 'POST':
                async with self.session.post(url, json=data, headers=headers) as response:
                    return await self._process_response(response, endpoint)
            else:
                raise ValueError(f"Método HTTP no soportado: {method}")
        except Exception as e:
            logger.error(f"Error en request {method} {endpoint}: {e}")
            return {"success": False, "error": str(e), "endpoint": endpoint}

    async def _process_response(self, response: aiohttp.ClientResponse, endpoint: str) -> Dict[str, Any]:
        """Procesa la respuesta HTTP."""
        try:
            if response.status >= 200 and response.status < 300:
                if response.content_type == 'application/json':
                    data = await response.json()
                else:
                    data = await response.text()

                return {
                    "success": True,
                    "status_code": response.status,
                    "endpoint": endpoint,
                    "data": data
                }
            else:
                error_text = await response.text()
                return {
                    "success": False,
                    "status_code": response.status,
                    "endpoint": endpoint,
                    "error": error_text
                }
        except Exception as e:
            return {
                "success": False,
                "endpoint": endpoint,
                "error": f"Error procesando respuesta: {e}"
            }

    async def test_health_endpoint(self) -> Dict[str, Any]:
        """Test del endpoint de health check."""
        logger.info("🩺 Testing /v1/health endpoint...")
        return await self.make_request('GET', '/v1/health')

    async def test_chat_completions(self) -> Dict[str, Any]:
        """Test del endpoint de chat completions."""
        logger.info("💬 Testing /v1/chat/completions endpoint...")

        test_messages = [
            {"role": "user", "content": "Hola, ¿qué puedes hacer?"},
            {"role": "user", "content": "Explícame qué es el aprendizaje federado"},
            {"role": "user", "content": "Genera una historia corta"}
        ]

        results = []
        for i, messages in enumerate(test_messages):
            logger.info(f"   Testing message {i+1}: {messages['content'][:50]}...")

            data = {
                "messages": messages,
                "model": "empoorio-lm",
                "temperature": 0.7,
                "max_tokens": 100
            }

            result = await self.make_request('POST', '/v1/chat/completions', data)
            results.append(result)

            # Pequeña pausa para no sobrecargar
            await asyncio.sleep(0.5)

        return results

    async def test_vision_analyze(self) -> Dict[str, Any]:
        """Test del endpoint de análisis de visión."""
        logger.info("👁️ Testing /v1/vision/analyze endpoint...")

        # Nota: Este endpoint probablemente fallará ya que EmpoorioVision no está implementado
        data = {
            "prompt": "Describe esta imagen",
            "image_base64": "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="  # 1x1 pixel PNG
        }

        return await self.make_request('POST', '/v1/vision/analyze', data)

    async def test_workflow_execute(self) -> Dict[str, Any]:
        """Test del endpoint de ejecución de workflows."""
        logger.info("⚙️ Testing /v1/workflow/execute endpoint...")

        # Usar un template simple que debería existir
        data = {
            "template_id": "simple_analysis",
            "parameters": {
                "input_text": "Analizar este texto de prueba",
                "analysis_type": "sentiment"
            }
        }

        return await self.make_request('POST', '/v1/workflow/execute', data)

    async def test_rate_limiting(self) -> Dict[str, Any]:
        """Test del rate limiting."""
        logger.info("🚦 Testing rate limiting...")

        # Hacer muchas requests rápidas para probar el rate limit
        results = []
        for i in range(15):  # Más que el límite de 10 por minuto
            result = await self.make_request('GET', '/v1/health')
            results.append(result)

            if i >= 10 and not result.get("success", False):
                logger.info(f"   Rate limit activado en request {i+1}")
                break

            await asyncio.sleep(0.1)  # Muy rápida para activar rate limit

        return results

    async def run_all_tests(self) -> Dict[str, Any]:
        """Ejecuta todos los tests."""
        logger.info("🚀 Iniciando tests completos del API Gateway de AILOOS")
        logger.info("=" * 60)

        start_time = time.time()

        # Ejecutar tests
        results = {
            "health": await self.test_health_endpoint(),
            "chat_completions": await self.test_chat_completions(),
            "vision_analyze": await self.test_vision_analyze(),
            "workflow_execute": await self.test_workflow_execute(),
            "rate_limiting": await self.test_rate_limiting()
        }

        total_time = time.time() - start_time

        # Generar resumen
        summary = self._generate_summary(results, total_time)

        results["summary"] = summary

        logger.info("=" * 60)
        logger.info("✅ Tests completados")
        logger.info(".2f")
        logger.info(f"📊 Resumen: {summary['total_tests']} tests, {summary['passed']} pasaron, {summary['failed']} fallaron")

        return results

    def _generate_summary(self, results: Dict[str, Any], total_time: float) -> Dict[str, Any]:
        """Genera un resumen de los resultados."""
        total_tests = 0
        passed = 0
        failed = 0

        details = {}

        # Contar tests de health
        total_tests += 1
        if results["health"].get("success"):
            passed += 1
            details["health"] = "✅ PASSED"
        else:
            failed += 1
            details["health"] = f"❌ FAILED: {results['health'].get('error', 'Unknown error')}"

        # Contar tests de chat completions
        chat_results = results["chat_completions"]
        if isinstance(chat_results, list):
            total_tests += len(chat_results)
            chat_passed = sum(1 for r in chat_results if r.get("success"))
            passed += chat_passed
            failed += len(chat_results) - chat_passed
            details["chat_completions"] = f"✅ {chat_passed}/{len(chat_results)} PASSED"
        else:
            total_tests += 1
            if chat_results.get("success"):
                passed += 1
                details["chat_completions"] = "✅ PASSED"
            else:
                failed += 1
                details["chat_completions"] = "❌ FAILED"

        # Contar tests de visión (siempre falla por ahora)
        total_tests += 1
        vision_result = results["vision_analyze"]
        if vision_result.get("success"):
            passed += 1
            details["vision_analyze"] = "✅ PASSED"
        else:
            failed += 1
            details["vision_analyze"] = "❌ FAILED (Expected - EmpoorioVision not implemented)"

        # Contar tests de workflow
        total_tests += 1
        workflow_result = results["workflow_execute"]
        if workflow_result.get("success"):
            passed += 1
            details["workflow_execute"] = "✅ PASSED"
        else:
            failed += 1
            details["workflow_execute"] = f"❌ FAILED: {workflow_result.get('error', 'Unknown error')}"

        # Contar tests de rate limiting
        rate_results = results["rate_limiting"]
        if isinstance(rate_results, list):
            # Verificar que algunos fallaron por rate limit
            rate_limited = any(not r.get("success", False) for r in rate_results)
            total_tests += 1
            if rate_limited:
                passed += 1
                details["rate_limiting"] = "✅ PASSED (Rate limit activado)"
            else:
                failed += 1
                details["rate_limiting"] = "❌ FAILED (Rate limit no activado)"

        return {
            "total_tests": total_tests,
            "passed": passed,
            "failed": failed,
            "success_rate": f"{(passed/total_tests)*100:.1f}%" if total_tests > 0 else "0%",
            "total_time": ".2f",
            "details": details
        }

async def main():
    """Función principal."""
    print("🧪 AILOOS API Gateway Test Suite")
    print("=================================")
    print()

    async with APITester() as tester:
        results = await tester.run_all_tests()

        # Guardar resultados
        with open("api_test_results.json", "w", encoding="utf-8") as f:
            # Convertir a JSON serializable
            json_results = json.dumps(results, indent=2, ensure_ascii=False, default=str)
            f.write(json_results)

        print()
        print("📄 Resultados guardados en: api_test_results.json")

        # Mostrar resumen final
        summary = results.get("summary", {})
        print()
        print("📊 RESUMEN FINAL:")
        print(f"   Total Tests: {summary.get('total_tests', 0)}")
        print(f"   Passed: {summary.get('passed', 0)}")
        print(f"   Failed: {summary.get('failed', 0)}")
        print(f"   Success Rate: {summary.get('success_rate', '0%')}")
        print(f"   Total Time: {summary.get('total_time', '0.00s')}")

        print()
        print("📋 DETALLES POR ENDPOINT:")
        for endpoint, status in summary.get("details", {}).items():
            print(f"   {endpoint}: {status}")

if __name__ == "__main__":
    asyncio.run(main())