#!/bin/bash

# 🧪 Test Production Deployment
# Verifies that AILOOS is properly deployed and working

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

BACKEND_URL="http://localhost:8000"
FRONTEND_URL="https://www.ailoos.com"

print_status() {
    echo -e "${BLUE}[TEST]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[PASS]${NC} $1"
}

print_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Test backend health
test_backend() {
    print_status "Testing backend health..."

    if curl -f -s "$BACKEND_URL/v1/health" > /dev/null 2>&1; then
        # Get detailed health response
        HEALTH_RESPONSE=$(curl -s "$BACKEND_URL/v1/health")

        # Check if all services are healthy
        if echo "$HEALTH_RESPONSE" | grep -q '"status": "healthy"'; then
            print_success "Backend is healthy"

            # Check individual services
            if echo "$HEALTH_RESPONSE" | grep -q '"empoorio_lm": "healthy"'; then
                print_success "EmpoorioLM service is healthy"
            else
                print_fail "EmpoorioLM service is not healthy"
            fi

            if echo "$HEALTH_RESPONSE" | grep -q '"empoorio_vision": "healthy"'; then
                print_success "EmpoorioVision service is healthy"
            else
                print_warning "EmpoorioVision service is not healthy (optional)"
            fi

            if echo "$HEALTH_RESPONSE" | grep -q '"workflow_engine": "healthy"'; then
                print_success "WorkflowEngine service is healthy"
            else
                print_fail "WorkflowEngine service is not healthy"
            fi
        else
            print_fail "Backend status is not healthy"
            echo "Response: $HEALTH_RESPONSE"
        fi
    else
        print_fail "Cannot connect to backend at $BACKEND_URL"
        print_status "Make sure the backend is running: python -m src.ailoos.api.gateway"
        return 1
    fi
}

# Test backend API endpoints
test_backend_apis() {
    print_status "Testing backend API endpoints..."

    # Test EmpoorioLM generation (mock response)
    if curl -f -s -X POST "$BACKEND_URL/api/v1/empoorio-lm/generate" \
        -H "Content-Type: application/json" \
        -d '{"prompt": "Hola", "max_tokens": 50}' > /dev/null 2>&1; then
        print_success "EmpoorioLM API endpoint is responding"
    else
        print_fail "EmpoorioLM API endpoint is not responding"
    fi

    # Test workflow execution
    if curl -f -s -X POST "$BACKEND_URL/v1/workflow/execute" \
        -H "Content-Type: application/json" \
        -d '{"template_id": "test", "parameters": {"input_text": "test"}}' > /dev/null 2>&1; then
        print_success "Workflow API endpoint is responding"
    else
        print_fail "Workflow API endpoint is not responding"
    fi
}

# Test frontend connectivity
test_frontend() {
    print_status "Testing frontend connectivity..."

    # Test if frontend is accessible
    if curl -f -s -I "$FRONTEND_URL" > /dev/null 2>&1; then
        print_success "Frontend is accessible at $FRONTEND_URL"
    else
        print_warning "Frontend is not accessible at $FRONTEND_URL"
        print_status "This might be normal if DNS hasn't propagated yet"
        print_status "Try accessing directly via Vercel deployment URL"
    fi
}

# Test CORS configuration
test_cors() {
    print_status "Testing CORS configuration..."

    # Test CORS headers from frontend origin
    CORS_TEST=$(curl -s -I -H "Origin: $FRONTEND_URL" "$BACKEND_URL/v1/health" | grep -i "access-control-allow-origin")

    if [ -n "$CORS_TEST" ]; then
        print_success "CORS headers are properly configured"
    else
        print_fail "CORS headers are missing"
        print_status "Frontend may not be able to connect to backend"
    fi
}

# Main test function
main() {
    echo "🧪 AILOOS Production Deployment Test"
    echo "===================================="
    echo ""

    local all_passed=true

    # Run all tests
    test_backend || all_passed=false
    test_backend_apis || all_passed=false
    test_frontend || all_passed=false
    test_cors || all_passed=false

    echo ""
    echo "===================================="

    if $all_passed; then
        print_success "🎉 All tests passed! AILOOS is properly deployed."
        echo ""
        echo "Your application is live at:"
        echo "- Frontend: $FRONTEND_URL"
        echo "- Backend: $BACKEND_URL (internal)"
        echo ""
        echo "Next steps:"
        echo "1. Configure DNS records for your domains"
        echo "2. Test the full application flow"
        echo "3. Monitor logs and performance"
    else
        print_fail "❌ Some tests failed. Please check the issues above."
        echo ""
        echo "Common fixes:"
        echo "1. Make sure backend is running: ./scripts/deploy_production.sh"
        echo "2. Check firewall settings for port 8000"
        echo "3. Verify Vercel deployment is successful"
        echo "4. Check DNS configuration"
        exit 1
    fi
}

# Run tests
main "$@"