#!/usr/bin/env python3
"""
Demo del Workflow Engine - FASE 9: Workflows Multimodales
========================================================

Esta demo muestra cómo el WorkflowEngine orquesta automáticamente
procesos complejos que combinan visión, expertos y herramientas.
"""

import asyncio
import logging
import sys
from pathlib import Path

# Añadir el directorio raíz al path
script_dir = Path(__file__).parent
root_dir = script_dir.parent
sys.path.insert(0, str(root_dir))

from src.ailoos.workflows.engine import WorkflowEngine
from src.ailoos.workflows.templates import create_document_analysis_workflow
from src.ailoos.workflows.validators import validate_workflow_result
from src.ailoos.models.empoorio_lm.expert_system import create_expert_manager
from src.ailoos.inference.api import InferenceConfig, EmpoorioLMInferenceAPI

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger("Workflow_Demo")


async def demo_document_analysis_workflow():
    """Demo del workflow de análisis de documentos."""
    logger.info("🎯 INICIANDO DEMO: Workflow de Análisis de Documentos")
    logger.info("=" * 60)

    try:
        # 1. Inicializar componentes
        logger.info("🏗️ Inicializando componentes del sistema...")

        # Crear gestor de expertos
        expert_manager = create_expert_manager("models/experts")

        # Crear API de inferencia (simulada para demo)
        inference_config = InferenceConfig()
        inference_api = EmpoorioLMInferenceAPI(inference_config)

        # Crear motor de workflows
        engine = WorkflowEngine(expert_manager, inference_api)

        # 2. Crear workflow desde template
        logger.info("📋 Creando workflow desde template...")
        template = create_document_analysis_workflow(domain="legal")
        workflow_id = "demo_document_analysis_001"

        # Datos de entrada simulados (en producción vendría de una imagen real)
        input_data = {
            "image_path": "/path/to/invoice.jpg",
            "document_type": "invoice",
            "expected_fields": ["amount", "vendor", "date"]
        }

        # Instanciar workflow con parámetros
        steps = template.instantiate({
            "domain": "legal",
            "language": "es"
        })

        logger.info(f"✅ Workflow creado: {len(steps)} pasos")
        for i, step in enumerate(steps, 1):
            logger.info(f"   {i}. {step.step_id} ({step.step_type}) - {step.description}")

        # 3. Ejecutar workflow
        logger.info("🚀 Ejecutando workflow...")
        result = await engine.execute_workflow(workflow_id, steps, input_data)

        # 4. Mostrar resultados
        logger.info("📊 RESULTADOS DE EJECUCIÓN:")
        logger.info(f"   Tiempo de ejecución: {result.execution_time:.2f}s")
        logger.info(f"   Pasos ejecutados: {len(result.steps_executed)}")
        logger.info(f"   Estado final: {'✅ Éxito' if result.success else '❌ Falló'}")

        if result.errors:
            logger.warning("   Errores encontrados:")
            for error in result.errors:
                logger.warning(f"     - {error}")

        # Mostrar output estructurado
        if result.final_output:
            logger.info("📄 OUTPUT ESTRUCTURADO:")
            if isinstance(result.final_output, dict):
                for key, value in result.final_output.items():
                    if isinstance(value, str) and len(value) > 100:
                        logger.info(f"   {key}: {value[:100]}...")
                    else:
                        logger.info(f"   {key}: {value}")
            else:
                logger.info(f"   Output: {result.final_output}")

        # 5. Validar resultados
        logger.info("🔍 Validando calidad del workflow...")
        validation_result = validate_workflow_result(result, "document_analysis")

        logger.info("📋 RESULTADOS DE VALIDACIÓN:")
        logger.info(f"   Validación general: {'✅ Superada' if validation_result['overall_success'] else '❌ Fallida'}")
        logger.info(".1f"        logger.info(f"   Puntaje: {validation_result['score']:.1f}/1.0")

        if validation_result['issues']:
            logger.warning("   Problemas encontrados:")
            for issue in validation_result['issues']:
                logger.warning(f"     - {issue}")

        # 6. Mostrar detalles de pasos
        logger.info("🔍 DETALLES DE EJECUCIÓN POR PASO:")
        for step_id, step_result in result.step_results.items():
            step_type = step_result.get('step_type', 'unknown')
            logger.info(f"   📍 {step_id} ({step_type}):")
            if 'confidence' in step_result:
                logger.info(".2f"            if 'extracted_text' in step_result:
                text_preview = step_result['extracted_text'][:50] + "..." if len(step_result['extracted_text']) > 50 else step_result['extracted_text']
                logger.info(f"       Texto: {text_preview}")
            if 'expert_response' in step_result:
                response_preview = step_result['expert_response'][:50] + "..." if len(step_result['expert_response']) > 50 else step_result['expert_response']
                logger.info(f"       Respuesta: {response_preview}")

        # 7. Resumen final
        logger.info("=" * 60)
        if result.success and validation_result['overall_success']:
            logger.info("🎉 DEMO COMPLETADA EXITOSAMENTE")
            logger.info("✅ El Workflow Engine funciona correctamente")
            logger.info("✅ La orquestación multimodal está operativa")
            logger.info("✅ FASE 9: Workflows Multimodales - VALIDADO")
        else:
            logger.warning("⚠️ DEMO COMPLETADA CON OBSERVACIONES")
            logger.info("El sistema básico funciona, pero hay aspectos a mejorar")

        logger.info("=" * 60)

        return result.success and validation_result['overall_success']

    except Exception as e:
        logger.error(f"❌ Error en demo: {e}")
        import traceback
        traceback.print_exc()
        return False


async def demo_invoice_audit_workflow():
    """Demo del workflow de auditoría de facturas."""
    logger.info("💰 DEMO COMPLEMENTARIA: Workflow de Auditoría de Facturas")
    logger.info("=" * 50)

    try:
        # Configuración simplificada
        expert_manager = create_expert_manager("models/experts")
        inference_config = InferenceConfig()
        inference_api = EmpoorioLMInferenceAPI(inference_config)
        engine = WorkflowEngine(expert_manager, inference_api)

        # Usar template de auditoría de facturas
        from src.ailoos.workflows.templates import INVOICE_AUDIT_TEMPLATE
        template = INVOICE_AUDIT_TEMPLATE
        workflow_id = "demo_invoice_audit_001"

        # Datos de entrada simulados
        input_data = {
            "image_path": "/path/to/invoice.pdf",
            "expected_amount": 1250.00,
            "tax_rate": 0.21
        }

        # Ejecutar workflow
        steps = template.instantiate({"tax_rate": "0.21"})
        result = await engine.execute_workflow(workflow_id, steps, input_data)

        logger.info(f"Resultado auditoría: {'✅ Válida' if result.success else '❌ Inválida'}")
        logger.info(".2f"
        return result.success

    except Exception as e:
        logger.error(f"Error en demo de facturas: {e}")
        return False


async def main():
    """Función principal de la demo."""
    logger.info("🚀 DEMO DEL WORKFLOW ENGINE - FASE 9")
    logger.info("Orquestación automática de procesos multimodales")
    logger.info("=" * 60)

    # Demo principal: Análisis de documentos
    success1 = await demo_document_analysis_workflow()

    print("\n" + "="*60)

    # Demo complementaria: Auditoría de facturas
    success2 = await demo_invoice_audit_workflow()

    # Resumen final
    print("\n" + "="*60)
    print("🏆 RESUMEN FINAL DE DEMOS")
    print("="*60)
    print(f"Análisis de Documentos: {'✅ Éxito' if success1 else '❌ Falló'}")
    print(f"Auditoría de Facturas: {'✅ Éxito' if success2 else '❌ Falló'}")

    if success1 and success2:
        print("\n🎉 TODAS LAS DEMOS SUPERADAS")
        print("✅ FASE 9: Workflows Multimodales OPERATIVA")
        print("✅ La automatización inteligente está lista")
    else:
        print("\n⚠️ ALGUNAS DEMOS CON OBSERVACIONES")
        print("El sistema básico funciona, se necesitan ajustes")

    print("="*60)


if __name__ == "__main__":
    asyncio.run(main())