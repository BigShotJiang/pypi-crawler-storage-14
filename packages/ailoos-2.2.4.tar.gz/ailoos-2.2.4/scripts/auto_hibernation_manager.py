#!/usr/bin/env python3
"""
Script para gestión automática de hibernación y zero-scaling.
Ejecutar periódicamente (ej: cada 5-10 minutos) para mantener costos óptimos.
"""

import asyncio
import logging
import sys
import os
from datetime import datetime

# Agregar src al path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from ailoos.core.config import Config
from ailoos.core.database import get_db_session
from ailoos.coordinator.services.admin_service import AdminService

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s'
)
logger = logging.getLogger(__name__)


async def run_auto_hibernation_cycle():
    """Ejecuta un ciclo completo de hibernación automática."""
    logger.info("Starting auto-hibernation cycle")

    config = Config()
    admin_service = AdminService(config)

    try:
        async with get_db_session(config) as db:
            # 1. Ejecutar hibernación automática de nodos
            hibernation_result = await admin_service.run_auto_hibernation(
                db=db,
                inactivity_threshold_minutes=30,
                contribution_threshold_hours=24,
                max_hibernations=5,
                admin_user_id="system"
            )

            logger.info(f"Hibernation result: {hibernation_result}")

            # 2. Ejecutar ciclo de auto-scaling
            scaling_result = await admin_service.run_auto_scaling_cycle(db)

            logger.info(f"Auto-scaling result: {scaling_result}")

            # 3. Obtener estadísticas finales
            hibernation_stats = await admin_service.get_hibernation_stats(db)
            scaling_status = await admin_service.get_scaling_status()

            logger.info(f"Final hibernation stats: {hibernation_stats}")
            logger.info(f"Final scaling status: {scaling_status}")

            return {
                "hibernation": hibernation_result,
                "scaling": scaling_result,
                "stats": hibernation_stats,
                "scaling_status": scaling_status,
                "timestamp": datetime.utcnow().isoformat()
            }

    except Exception as e:
        logger.error(f"Error in auto-hibernation cycle: {e}")
        raise


async def main():
    """Función principal."""
    try:
        result = await run_auto_hibernation_cycle()
        logger.info("Auto-hibernation cycle completed successfully")
        print(f"Result: {result}")
        return 0
    except Exception as e:
        logger.error(f"Auto-hibernation cycle failed: {e}")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)