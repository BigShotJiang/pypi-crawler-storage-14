#!/usr/bin/env python3
"""
Context Extension Script for EmpoorioLM MoE
Extiende el contexto del modelo MoE de 1K a 8K tokens usando NTK-Aware RoPE.
"""

import torch
import torch.nn as nn
from pathlib import Path
from typing import Optional, Dict, Any
import argparse
import logging
import sys
import json

# Add models directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.empoorio_lm.config import EmpoorioLMConfig
from models.empoorio_lm.model import EmpoorioLM

logger = logging.getLogger(__name__)


class ContextExtender:
    """
    Extends model context using NTK-Aware RoPE.
    """

    def __init__(self, original_config: EmpoorioLMConfig, extended_config: EmpoorioLMConfig):
        self.original_config = original_config
        self.extended_config = extended_config

        # Validate compatibility
        self._validate_extension()

    def _validate_extension(self):
        """Validate that extension is compatible."""
        # Get effective context sizes
        original_context = getattr(self.original_config, 'max_context_size', self.original_config.max_position_embeddings)
        extended_context = self.extended_config.max_context_size

        assert extended_context > original_context, \
            f"Extended context ({extended_context}) must be larger than original ({original_context})"
        assert self.extended_config.use_rope, "Extended model must use RoPE"
        assert self.extended_config.hidden_size == self.original_config.hidden_size, \
            "Hidden size must match"

        logger.info("✅ Context extension validation passed")

    def extend_model_context(self, original_model: EmpoorioLM) -> EmpoorioLM:
        """
        Extend model context by updating RoPE and config.

        Args:
            original_model: Model with original context

        Returns:
            Model with extended context
        """
        logger.info("🔄 Extending model context...")

        # Create new model with extended config
        extended_model = EmpoorioLM(self.extended_config)

        # Copy all weights from original model
        extended_model.load_state_dict(original_model.state_dict(), strict=False)

        # The RoPE will be automatically configured for the new context size
        logger.info(f"✅ Context extended from {self.original_config.max_context_size} to {self.extended_config.max_context_size}")

        return extended_model

    @classmethod
    def extend_context_pipeline(
        cls,
        model_path: str,
        extended_context_size: int,
        output_path: str,
        device: str = "auto"
    ) -> str:
        """
        Complete pipeline to extend model context.

        Args:
            model_path: Path to original model
            extended_context_size: New context size
            output_path: Where to save extended model
            device: Device to use

        Returns:
            Path to extended model
        """
        logger.info(f"🔄 Extending context from {model_path} to {extended_context_size} tokens...")

        # Load original model
        model_path = Path(model_path)
        original_config = EmpoorioLMConfig.load_config(str(model_path / "config.json"))

        # Ensure original config has max_context_size for comparison
        if not hasattr(original_config, 'max_context_size') or original_config.max_context_size is None:
            original_config.max_context_size = original_config.max_position_embeddings

        # Create extended config
        extended_config = EmpoorioLMConfig(
            vocab_size=original_config.vocab_size,
            hidden_size=original_config.hidden_size,
            num_layers=original_config.num_layers,
            num_heads=original_config.num_heads,
            max_position_embeddings=original_config.max_position_embeddings,  # Keep original for compatibility
            use_moe=original_config.use_moe,
            num_experts=original_config.num_experts if original_config.use_moe else 8,
            moe_layers=original_config.moe_layers if original_config.use_moe else [4, 7, 10],
            top_k=original_config.top_k if original_config.use_moe else 2,
            use_rope=True,  # Enable RoPE for extended context
            max_context_size=extended_context_size,  # Extended context
            device=device
        )

        # Load original model
        original_model = EmpoorioLM.from_pretrained(model_path, original_config)

        # Create extender
        extender = cls(original_config, extended_config)

        # Extend model
        extended_model = extender.extend_model_context(original_model)

        # Save extended model
        output_path = Path(output_path)
        output_path.mkdir(parents=True, exist_ok=True)
        extended_model.save_pretrained(output_path)

        logger.info(f"✅ Extended model saved to {output_path}")

        # Print summary
        cls._print_extension_summary(original_config, extended_config, original_model, extended_model)

        return str(output_path)

    @staticmethod
    def _print_extension_summary(
        original_config: EmpoorioLMConfig,
        extended_config: EmpoorioLMConfig,
        original_model: EmpoorioLM,
        extended_model: EmpoorioLM
    ):
        """Print summary of context extension."""
        print("\n" + "="*60)
        print("📏 CONTEXT EXTENSION SUMMARY")
        print("="*60)

        print(f"Original Context: {original_config.max_context_size} tokens")
        print(f"Extended Context: {extended_config.max_context_size} tokens")
        print(f"Context Multiplier: {extended_config.max_context_size / original_config.max_context_size:.1f}x")

        print(f"\nRoPE: {'Enabled' if extended_config.use_rope else 'Disabled'}")
        print(f"NTK-Aware: {'Enabled' if extended_config.max_context_size > 4096 else 'Not needed'}")

        if extended_config.use_moe:
            print(f"\nMoE Configuration Preserved:")
            print(f"  Experts: {extended_config.num_experts}")
            print(f"  Top-K: {extended_config.top_k}")
            print(f"  MoE Layers: {extended_config.moe_layers}")

        print("\n✅ Context extension completed successfully!")
        print("="*60)


def main():
    """Main function for command-line usage."""
    parser = argparse.ArgumentParser(description="Extend EmpoorioLM context using NTK-Aware RoPE")
    parser.add_argument("--model_path", required=True, help="Path to original model directory")
    parser.add_argument("--extended_context", type=int, default=8192, help="Extended context size in tokens")
    parser.add_argument("--output_path", required=True, help="Output path for extended model")
    parser.add_argument("--device", choices=["auto", "cpu", "cuda", "mps"], default="auto", help="Compute device")

    args = parser.parse_args()

    # Setup logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    try:
        # Run context extension
        output_path = ContextExtender.extend_context_pipeline(
            model_path=args.model_path,
            extended_context_size=args.extended_context,
            output_path=args.output_path,
            device=args.device
        )

        print(f"\n🎉 Context extension completed! Extended model saved to: {output_path}")

    except Exception as e:
        logger.error(f"❌ Context extension failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()