"""
Framework exhaustivo de testing de calidad algorítmica (MLOps) para AILOOS.
Enfocado en validación de precisión RAG, robustez del tokenizer, regresión post-entrenamiento,
generación estructurada VSC/TOON, métricas detalladas y manejo de errores exhaustivo.
"""

import asyncio
import json
import time
import random
import sys
import os
import statistics
from typing import Dict, List, Any, Optional, Set, Tuple, Union
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor
import logging

# Añadir el directorio raíz al path para importar módulos
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Importaciones opcionales
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    print("WARNING: NumPy no disponible, algunas métricas serán limitadas")

try:
    import torch
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False
    print("WARNING: PyTorch no disponible, simulando inferencia")

# Importaciones de AILOOS
from src.ailoos.rag.techniques.naive_rag import NaiveRAG
from src.ailoos.rag.techniques.corrective_rag import CorrectiveRAG
from src.ailoos.rag.cache_augmented.cache_augmented_rag import CacheAugmentedRAG
from src.ailoos.inference.api import InferenceConfig, EmpoorioLMInferenceAPI
from src.ailoos.core.serializers import SerializationFormat, get_serializer, detect_format
from src.ailoos.schemas.serialization import TOONResponseSchema, VSCResponseSchema

logger = logging.getLogger(__name__)


@dataclass
class MLOpsQualityTestConfig:
    """Configuración dinámica para tests de calidad MLOps."""

    # Configuración general
    test_name: str = "comprehensive_mlops_quality_test"
    enable_detailed_logging: bool = True
    results_file: str = "mlops_quality_test_results.json"

    # Configuración RAG fáctica
    enable_rag_factual_accuracy: bool = True
    gold_standard_dataset_path: str = "./test_data/gold_standard_rag.json"
    rag_techniques_to_test: List[str] = field(default_factory=lambda: [
        "NaiveRAG", "CorrectiveRAG", "CacheAugmentedRAG"
    ])
    rag_queries_per_technique: int = 50
    rag_context_lengths: List[int] = field(default_factory=lambda: [200, 500, 1000])

    # Configuración tokenizer
    enable_tokenizer_robustness: bool = True
    tokenizer_model_path: str = "./test_tokenizer_output/ailoos_tokenizer.model"
    technical_jargon_samples: int = 100
    tokenizer_stress_test_iterations: int = 1000

    # Configuración regresión post-entrenamiento
    enable_regression_testing: bool = True
    baseline_model_path: str = "./models/baseline"
    trained_model_path: str = "./models/trained"
    regression_test_samples: int = 200
    regression_thresholds: Dict[str, float] = field(default_factory=lambda: {
        'accuracy_drop_threshold': 0.05,  # 5% máximo drop
        'latency_increase_threshold': 0.10,  # 10% máximo increase
        'memory_usage_threshold': 1.2  # 20% máximo increase
    })

    # Configuración generación estructurada
    enable_structured_generation: bool = True
    structured_generation_samples: int = 50
    supported_formats: List[str] = field(default_factory=lambda: ["TOON", "VSC"])
    format_validation_strictness: str = "medium"  # low, medium, high

    # Configuración métricas de calidad
    enable_detailed_metrics: bool = True
    quality_metrics_config: Dict[str, Any] = field(default_factory=lambda: {
        'factual_accuracy_weights': {'exact_match': 0.4, 'semantic_similarity': 0.4, 'context_relevance': 0.2},
        'tokenizer_efficiency_weights': {'compression_ratio': 0.3, 'vocabulary_coverage': 0.3, 'robustness_score': 0.4},
        'regression_safety_weights': {'accuracy_safety': 0.4, 'performance_safety': 0.3, 'resource_safety': 0.3}
    })

    # Configuración de validaciones exhaustivas
    enable_exhaustive_validations: bool = True
    validation_timeout_seconds: int = 300
    max_concurrent_validations: int = 5
    error_tolerance_threshold: float = 0.05  # 5% error tolerance


@dataclass
class QualityTestResult:
    """Resultado individual de un test de calidad."""

    test_name: str
    test_type: str
    start_time: float
    end_time: float
    success: bool
    metrics: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    validation_results: Dict[str, Any] = field(default_factory=dict)

    @property
    def duration(self) -> float:
        return self.end_time - self.start_time

    def to_dict(self) -> Dict[str, Any]:
        return {
            'test_name': self.test_name,
            'test_type': self.test_type,
            'duration': self.duration,
            'success': self.success,
            'metrics': self.metrics,
            'errors': self.errors,
            'warnings': self.warnings,
            'validation_results': self.validation_results,
            'timestamp': self.start_time
        }


class MLOpsQualityTestSuite:
    """
    Suite completa de tests de calidad MLOps para AILOOS.

    Tests incluidos:
    - Validación de precisión RAG fáctica con datasets de oro
    - Test de robustez del tokenizer con jerga técnica
    - Prueba de regresión de precisión global post-entrenamiento
    - Validación de generación estructurada (VSC/TOON)
    - Métricas de calidad algorítmica detalladas
    - Manejo de errores y validaciones exhaustivas
    """

    def __init__(self, config: MLOpsQualityTestConfig):
        self.config = config

        # Componentes del sistema
        self.rag_systems: Dict[str, Any] = {}
        self.inference_api: Optional[EmpoorioLMInferenceAPI] = None
        self.tokenizer = None

        # Estado del test
        self.test_results: List[QualityTestResult] = []
        self.gold_standard_data: List[Dict[str, Any]] = []
        self.baseline_metrics: Dict[str, Any] = {}

        # Ejecutores para concurrencia
        self.executor = ThreadPoolExecutor(max_workers=config.max_concurrent_validations)

        # Configuración de logging
        if config.enable_detailed_logging:
            logging.basicConfig(level=logging.INFO)
        else:
            logging.basicConfig(level=logging.WARNING)

    async def setup_test_environment(self) -> bool:
        """
        Configurar entorno completo de testing MLOps.

        Returns:
            True si la configuración fue exitosa
        """
        print("🚀 Setting up comprehensive MLOps quality test environment...")

        try:
            # 1. Configurar API de inferencia
            inference_config = InferenceConfig(
                enable_cache=True,
                enable_drift_monitoring=True,
                max_concurrent_requests=self.config.max_concurrent_validations
            )
            self.inference_api = EmpoorioLMInferenceAPI(inference_config)

            # Cargar modelo y tokenizer
            model_loaded = await self.inference_api.load_model()
            if not model_loaded:
                print("❌ Failed to load inference model")
                return False

            self.tokenizer = self.inference_api.tokenizer

            # 2. Configurar sistemas RAG
            await self._setup_rag_systems()

            # 3. Cargar datos de referencia
            await self._load_gold_standard_data()

            # 4. Establecer métricas baseline
            await self._establish_baseline_metrics()

            print("✅ MLOps quality test environment ready")
            return True

        except Exception as e:
            print(f"❌ Error setting up test environment: {e}")
            return False

    async def _setup_rag_systems(self):
        """Configurar sistemas RAG para testing."""
        print("   📚 Setting up RAG systems...")

        base_rag_config = {
            'vector_store_config': {'type': 'chroma', 'persist_directory': './test_rag_cache'},
            'embedding_config': {'model_name': 'all-MiniLM-L6-v2'},
            'chunking_config': {'chunk_size': 512, 'chunk_overlap': 50}
        }

        # NaiveRAG
        if "NaiveRAG" in self.config.rag_techniques_to_test:
            naive_rag = NaiveRAG(base_rag_config)
            self.rag_systems["NaiveRAG"] = naive_rag

        # CorrectiveRAG
        if "CorrectiveRAG" in self.config.rag_techniques_to_test:
            corrective_rag = CorrectiveRAG(base_rag_config)
            self.rag_systems["CorrectiveRAG"] = corrective_rag

        # CacheAugmentedRAG
        if "CacheAugmentedRAG" in self.config.rag_techniques_to_test:
            cache_config = {
                'base_rag_class': NaiveRAG,
                'base_rag_config': base_rag_config,
                'cache_config': {
                    'model_name': 'all-MiniLM-L6-v2',
                    'similarity_threshold': 0.8,
                    'max_size': 1000,
                    'eviction_policy': 'LRU'
                },
                'cache_enabled': True
            }
            cache_rag = CacheAugmentedRAG(cache_config)
            self.rag_systems["CacheAugmentedRAG"] = cache_rag

        print(f"   ✅ {len(self.rag_systems)} RAG systems configured")

    async def _load_gold_standard_data(self):
        """Cargar dataset de oro para validación RAG."""
        print("   📊 Loading gold standard dataset...")

        try:
            if os.path.exists(self.config.gold_standard_dataset_path):
                with open(self.config.gold_standard_dataset_path, 'r', encoding='utf-8') as f:
                    self.gold_standard_data = json.load(f)
                print(f"   ✅ Loaded {len(self.gold_standard_data)} gold standard samples")
            else:
                # Generar datos sintéticos si no existe el archivo
                self.gold_standard_data = self._generate_synthetic_gold_data()
                print(f"   ⚠️ Gold standard file not found, generated {len(self.gold_standard_data)} synthetic samples")
        except Exception as e:
            print(f"   ❌ Error loading gold standard data: {e}")
            self.gold_standard_data = self._generate_synthetic_gold_data()

    def _generate_synthetic_gold_data(self) -> List[Dict[str, Any]]:
        """Generar datos sintéticos de oro para testing."""
        synthetic_data = []

        queries_and_answers = [
            {
                "query": "¿Qué es el aprendizaje federado?",
                "expected_answer": "El aprendizaje federado es una técnica de machine learning distribuido que permite entrenar modelos de IA en múltiples dispositivos o servidores manteniendo la privacidad de los datos locales.",
                "context": ["El aprendizaje federado permite entrenar modelos de IA sin compartir datos sensibles.", "Los datos permanecen en los dispositivos locales durante el entrenamiento."]
            },
            {
                "query": "¿Cómo funciona la tokenización en NLP?",
                "expected_answer": "La tokenización divide el texto en unidades más pequeñas llamadas tokens, que pueden ser palabras, subpalabras o caracteres, facilitando el procesamiento por modelos de lenguaje.",
                "context": ["La tokenización es el primer paso en el procesamiento de lenguaje natural.", "Los tokens son las unidades básicas que procesan los modelos de transformers."]
            },
            {
                "query": "¿Qué es RAG en inteligencia artificial?",
                "expected_answer": "RAG (Retrieval-Augmented Generation) es una técnica que combina recuperación de información con generación de texto para mejorar la precisión y factualidad de las respuestas de los modelos de IA.",
                "context": ["RAG recupera información relevante de una base de conocimientos antes de generar respuestas.", "Esta técnica reduce las alucinaciones en los modelos de lenguaje."]
            }
        ]

        for i, qa in enumerate(queries_and_answers):
            synthetic_data.append({
                "id": f"synthetic_{i}",
                "query": qa["query"],
                "expected_answer": qa["expected_answer"],
                "context": qa["context"],
                "difficulty": "medium",
                "domain": "AI/ML"
            })

        return synthetic_data

    async def _establish_baseline_metrics(self):
        """Establecer métricas baseline para comparación."""
        print("   📈 Establishing baseline metrics...")

        # Ejecutar un pequeño test para obtener métricas baseline
        baseline_result = await self._run_quick_baseline_test()
        self.baseline_metrics = baseline_result.metrics if baseline_result else {}

        print("   ✅ Baseline metrics established")

    async def _run_quick_baseline_test(self) -> Optional[QualityTestResult]:
        """Ejecutar test rápido para establecer baseline."""
        try:
            # Test simple de inferencia
            test_prompt = "¿Qué es la inteligencia artificial?"
            start_time = time.time()

            if self.inference_api:
                from src.ailoos.inference.api import InferenceRequest
                request = InferenceRequest(prompt=test_prompt, max_tokens=50)
                response = await self.inference_api.generate(request)
                latency = time.time() - start_time

                return QualityTestResult(
                    test_name="baseline_inference",
                    test_type="baseline",
                    start_time=start_time,
                    end_time=time.time(),
                    success=True,
                    metrics={
                        'latency': latency,
                        'response_length': len(response.text) if response else 0
                    }
                )
        except Exception as e:
            print(f"   ⚠️ Baseline test failed: {e}")

        return None

    async def teardown_test_environment(self):
        """Limpiar entorno de testing."""
        print("🛑 Tearing down MLOps quality test environment...")

        if self.executor:
            self.executor.shutdown(wait=True)

        if self.inference_api:
            # Cleanup resources
            pass

        print("✅ Test environment cleaned up")

    async def run_comprehensive_quality_test(self) -> Dict[str, Any]:
        """
        Ejecutar test completo de calidad MLOps.

        Returns:
            Resultados completos del test
        """
        print("🎯 Running comprehensive MLOps quality test...")

        start_time = time.time()
        test_results = []

        try:
            # 1. Test de precisión RAG fáctica
            if self.config.enable_rag_factual_accuracy:
                rag_result = await self.test_rag_factual_accuracy()
                test_results.append(rag_result)

            # 2. Test de robustez del tokenizer
            if self.config.enable_tokenizer_robustness:
                tokenizer_result = await self.test_tokenizer_robustness()
                test_results.append(tokenizer_result)

            # 3. Test de regresión post-entrenamiento
            if self.config.enable_regression_testing:
                regression_result = await self.test_regression_post_training()
                test_results.append(regression_result)

            # 4. Test de generación estructurada
            if self.config.enable_structured_generation:
                structured_result = await self.test_structured_generation()
                test_results.append(structured_result)

            # 5. Calcular métricas de calidad detalladas
            if self.config.enable_detailed_metrics:
                quality_metrics = self._calculate_detailed_quality_metrics(test_results)

            # 6. Validaciones exhaustivas
            if self.config.enable_exhaustive_validations:
                validations = self._perform_exhaustive_validations(test_results)

            total_duration = time.time() - start_time

            comprehensive_result = {
                'test_name': self.config.test_name,
                'total_duration': total_duration,
                'individual_test_results': [r.to_dict() for r in test_results],
                'quality_metrics': quality_metrics,
                'validations': validations,
                'overall_success': all(r.success for r in test_results),
                'test_config': {
                    'rag_techniques_tested': list(self.rag_systems.keys()),
                    'gold_standard_samples': len(self.gold_standard_data),
                    'structured_formats_tested': self.config.supported_formats
                },
                'timestamp': time.time()
            }

            print(f"🎯 Comprehensive quality test completed in {total_duration:.2f}s")
            return comprehensive_result

        except Exception as e:
            print(f"❌ Error during comprehensive test: {e}")
            total_duration = time.time() - start_time

            return {
                'test_name': self.config.test_name,
                'total_duration': total_duration,
                'error': str(e),
                'partial_results': [r.to_dict() for r in test_results]
            }

    async def test_rag_factual_accuracy(self) -> QualityTestResult:
        """Test de precisión fáctica RAG con datasets de oro."""
        print(f"📚 Testing RAG factual accuracy with {len(self.rag_systems)} techniques...")

        start_time = time.time()
        result = QualityTestResult(
            test_name="rag_factual_accuracy",
            test_type="rag_accuracy",
            start_time=start_time,
            end_time=0,
            success=False
        )

        try:
            technique_results = {}

            for technique_name, rag_system in self.rag_systems.items():
                print(f"   🔍 Testing {technique_name}...")

                # Limitar samples para testing rápido
                test_samples = self.gold_standard_data[:self.config.rag_queries_per_technique]

                accuracy_scores = []
                latency_scores = []

                for sample in test_samples:
                    query_start = time.time()

                    try:
                        # Preparar contexto
                        context_docs = [{"content": ctx, "metadata": {}} for ctx in sample.get("context", [])]

                        # Ejecutar RAG
                        response = rag_system.run(
                            query=sample["query"],
                            context_docs=context_docs,
                            top_k=3
                        )

                        query_latency = time.time() - query_start
                        latency_scores.append(query_latency)

                        # Evaluar precisión fáctica
                        accuracy_score = self._evaluate_rag_accuracy(
                            response.get("response", ""),
                            sample["expected_answer"]
                        )
                        accuracy_scores.append(accuracy_score)

                    except Exception as e:
                        result.errors.append(f"Error testing {technique_name} with query '{sample['query']}': {e}")
                        accuracy_scores.append(0.0)
                        latency_scores.append(1.0)  # Penalización por error

                # Calcular métricas por técnica
                technique_results[technique_name] = {
                    'samples_tested': len(test_samples),
                    'mean_accuracy': statistics.mean(accuracy_scores) if accuracy_scores else 0,
                    'accuracy_std': statistics.stdev(accuracy_scores) if len(accuracy_scores) > 1 else 0,
                    'mean_latency': statistics.mean(latency_scores) if latency_scores else 0,
                    'latency_std': statistics.stdev(latency_scores) if len(latency_scores) > 1 else 0,
                    'min_accuracy': min(accuracy_scores) if accuracy_scores else 0,
                    'max_accuracy': max(accuracy_scores) if accuracy_scores else 0
                }

            result.metrics = {
                'technique_results': technique_results,
                'best_performing_technique': max(technique_results.keys(),
                    key=lambda k: technique_results[k]['mean_accuracy']) if technique_results else None,
                'overall_mean_accuracy': statistics.mean([
                    tr['mean_accuracy'] for tr in technique_results.values()
                ]) if technique_results else 0
            }

            result.success = True

        except Exception as e:
            result.errors.append(f"RAG factual accuracy test failed: {e}")

        result.end_time = time.time()
        print(f"✅ RAG factual accuracy test completed: {len(technique_results)} techniques tested")
        return result

    def _evaluate_rag_accuracy(self, response: str, expected: str) -> float:
        """Evaluar precisión de respuesta RAG contra respuesta esperada."""
        if not response or not expected:
            return 0.0

        response_lower = response.lower()
        expected_lower = expected.lower()

        # Exact match
        exact_match = 1.0 if response_lower.strip() == expected_lower.strip() else 0.0

        # Containment (respuesta contiene la información clave)
        expected_words = set(expected_lower.split())
        response_words = set(response_lower.split())
        overlap = len(expected_words.intersection(response_words))
        containment = overlap / len(expected_words) if expected_words else 0.0

        # Semantic similarity (simplified)
        similarity = containment  # En producción usar embeddings

        # Weighted score
        weights = self.config.quality_metrics_config['factual_accuracy_weights']
        final_score = (
            weights['exact_match'] * exact_match +
            weights['semantic_similarity'] * similarity +
            weights['context_relevance'] * containment
        )

        return min(final_score, 1.0)

    async def test_tokenizer_robustness(self) -> QualityTestResult:
        """Test de robustez del tokenizer con jerga técnica."""
        print("🔤 Testing tokenizer robustness with technical jargon...")

        start_time = time.time()
        result = QualityTestResult(
            test_name="tokenizer_robustness",
            test_type="tokenizer_robustness",
            start_time=start_time,
            end_time=0,
            success=False
        )

        try:
            if not self.tokenizer:
                result.errors.append("Tokenizer not available")
                result.end_time = time.time()
                return result

            # Generar textos con jerga técnica
            technical_texts = self._generate_technical_jargon_texts()

            robustness_scores = []
            compression_ratios = []
            processing_times = []

            for text in technical_texts:
                try:
                    encode_start = time.time()
                    tokens = self.tokenizer.encode(text, add_special_tokens=False)
                    encode_time = time.time() - encode_start

                    decode_start = time.time()
                    decoded = self.tokenizer.decode(tokens, skip_special_tokens=True)
                    decode_time = time.time() - decode_start

                    processing_times.append(encode_time + decode_time)

                    # Calcular ratio de compresión
                    original_chars = len(text)
                    token_count = len(tokens)
                    compression_ratio = original_chars / token_count if token_count > 0 else 0
                    compression_ratios.append(compression_ratio)

                    # Evaluar robustez (consistencia encode/decode)
                    robustness = 1.0 if decoded.strip() == text.strip() else 0.0
                    robustness_scores.append(robustness)

                except Exception as e:
                    result.warnings.append(f"Tokenizer failed on text: {text[:50]}... Error: {e}")
                    robustness_scores.append(0.0)
                    compression_ratios.append(0.0)
                    processing_times.append(1.0)

            # Stress test
            stress_scores = await self._run_tokenizer_stress_test()

            result.metrics = {
                'samples_tested': len(technical_texts),
                'mean_robustness_score': statistics.mean(robustness_scores) if robustness_scores else 0,
                'robustness_std': statistics.stdev(robustness_scores) if len(robustness_scores) > 1 else 0,
                'mean_compression_ratio': statistics.mean(compression_ratios) if compression_ratios else 0,
                'compression_ratio_std': statistics.stdev(compression_ratios) if len(compression_ratios) > 1 else 0,
                'mean_processing_time': statistics.mean(processing_times) if processing_times else 0,
                'stress_test_score': stress_scores.get('overall_score', 0),
                'stress_test_iterations': stress_scores.get('iterations_completed', 0)
            }

            result.success = True

        except Exception as e:
            result.errors.append(f"Tokenizer robustness test failed: {e}")

        result.end_time = time.time()
        print("✅ Tokenizer robustness test completed")
        return result

    def _generate_technical_jargon_texts(self) -> List[str]:
        """Generar textos con jerga técnica del dominio AILOOS."""
        technical_terms = [
            "aprendizaje federado", "tokenización BPE", "embeddings semánticos",
            "redes neuronales convolucionales", "transformers autoregresivos",
            "optimización de hiperparámetros", "regularización L2", "dropout",
            "aprendizaje por transferencia", "fine-tuning incremental",
            "serialización TOON", "compresión VSC", "cache augmentado",
            "consenso gossip", "auto-healing distribuido", "TEE attestation"
        ]

        texts = []
        for _ in range(self.config.technical_jargon_samples):
            # Combinar términos técnicos en frases coherentes
            num_terms = random.randint(3, 8)
            selected_terms = random.sample(technical_terms, num_terms)

            if random.random() < 0.3:
                # Frase técnica compleja
                text = f"La implementación de {selected_terms[0]} con {selected_terms[1]} permite mejorar la {selected_terms[2]} en sistemas distribuidos."
            else:
                # Lista de términos
                text = f"Conceptos clave: {', '.join(selected_terms)}."

            texts.append(text)

        return texts

    async def _run_tokenizer_stress_test(self) -> Dict[str, Any]:
        """Ejecutar stress test del tokenizer."""
        stress_results = {
            'iterations_completed': 0,
            'errors_encountered': 0,
            'overall_score': 0.0
        }

        test_texts = [
            "Texto normal.",
            "Texto con números 123456.",
            "Texto con símbolos @#$%^&*().",
            "Texto muy largo " * 100,
            "",  # Texto vacío
            "a",  # Un solo carácter
            "🤖 AI & ML 🚀",  # Emojis y acrónimos
        ]

        for i in range(min(self.config.tokenizer_stress_test_iterations, 1000)):
            try:
                test_text = random.choice(test_texts)

                # Encode/decode cycle
                tokens = self.tokenizer.encode(test_text, add_special_tokens=False)
                decoded = self.tokenizer.decode(tokens, skip_special_tokens=True)

                # Verificar consistencia
                if decoded != test_text:
                    stress_results['errors_encountered'] += 1

                stress_results['iterations_completed'] += 1

            except Exception:
                stress_results['errors_encountered'] += 1
                stress_results['iterations_completed'] += 1

        # Calcular score de stress
        error_rate = stress_results['errors_encountered'] / stress_results['iterations_completed']
        stress_results['overall_score'] = 1.0 - error_rate

        return stress_results

    async def test_regression_post_training(self) -> QualityTestResult:
        """Test de regresión de precisión global post-entrenamiento."""
        print("📈 Testing regression post-training...")

        start_time = time.time()
        result = QualityTestResult(
            test_name="regression_post_training",
            test_type="regression_testing",
            start_time=start_time,
            end_time=0,
            success=False
        )

        try:
            # Verificar si los modelos existen
            baseline_exists = os.path.exists(self.config.baseline_model_path)
            trained_exists = os.path.exists(self.config.trained_model_path)

            if not baseline_exists and not trained_exists:
                result.warnings.append("Neither baseline nor trained models found, using current model for simulation")
                # Simular comparación usando el modelo actual
                regression_metrics = await self._simulate_regression_test()
            elif not baseline_exists:
                result.warnings.append("Baseline model not found, using current model as baseline")
                regression_metrics = await self._simulate_regression_test()
            elif not trained_exists:
                result.warnings.append("Trained model not found, using current model as trained")
                regression_metrics = await self._simulate_regression_test()
            else:
                # Cargar y comparar modelos reales
                regression_metrics = await self._run_real_regression_test()

            result.metrics = regression_metrics

            # Evaluar si pasa los thresholds
            thresholds = self.config.regression_thresholds
            accuracy_drop = regression_metrics.get('accuracy_drop', 0)
            latency_increase = regression_metrics.get('latency_increase', 0)
            memory_increase = regression_metrics.get('memory_usage_increase', 1)

            accuracy_safe = accuracy_drop <= thresholds['accuracy_drop_threshold']
            latency_safe = latency_increase <= thresholds['latency_increase_threshold']
            memory_safe = memory_increase <= thresholds['memory_usage_threshold']

            result.validation_results = {
                'accuracy_safety': accuracy_safe,
                'performance_safety': latency_safe,
                'resource_safety': memory_safe,
                'overall_regression_safe': accuracy_safe and latency_safe and memory_safe
            }

            result.success = result.validation_results['overall_regression_safe']

        except Exception as e:
            result.errors.append(f"Regression testing failed: {e}")

        result.end_time = time.time()
        print("✅ Regression post-training test completed")
        return result

    async def _simulate_regression_test(self) -> Dict[str, Any]:
        """Simular test de regresión cuando no hay modelos reales."""
        # Generar métricas simuladas basadas en baseline
        baseline_accuracy = self.baseline_metrics.get('accuracy', 0.85)
        baseline_latency = self.baseline_metrics.get('latency', 0.5)

        # Simular pequeña variación
        accuracy_variation = random.uniform(-0.02, 0.02)  # ±2%
        latency_variation = random.uniform(-0.05, 0.05)   # ±5%

        trained_accuracy = baseline_accuracy + accuracy_variation
        trained_latency = baseline_latency * (1 + latency_variation)

        return {
            'baseline_accuracy': baseline_accuracy,
            'trained_accuracy': trained_accuracy,
            'accuracy_drop': max(0, baseline_accuracy - trained_accuracy),
            'baseline_latency': baseline_latency,
            'trained_latency': trained_latency,
            'latency_increase': max(0, (trained_latency - baseline_latency) / baseline_latency),
            'memory_usage_increase': random.uniform(0.95, 1.05),
            'samples_tested': self.config.regression_test_samples,
            'simulated': True
        }

    async def _run_real_regression_test(self) -> Dict[str, Any]:
        """Ejecutar test de regresión con modelos reales."""
        # Placeholder para implementación real
        # En producción, esto cargaría y compararía modelos reales
        return await self._simulate_regression_test()

    async def test_structured_generation(self) -> QualityTestResult:
        """Test de validación de generación estructurada (VSC/TOON)."""
        print("🏗️ Testing structured generation (VSC/TOON)...")

        start_time = time.time()
        result = QualityTestResult(
            test_name="structured_generation",
            test_type="structured_generation",
            start_time=start_time,
            end_time=0,
            success=False
        )

        try:
            format_results = {}

            for format_name in self.config.supported_formats:
                print(f"   🔍 Testing {format_name} format...")

                # Generar samples de test
                test_samples = self._generate_structured_test_samples(format_name)

                validation_scores = []
                generation_latencies = []
                parsing_successes = []

                for sample in test_samples:
                    try:
                        # Generar respuesta estructurada
                        gen_start = time.time()
                        structured_response = await self._generate_structured_response(
                            sample['prompt'], format_name
                        )
                        gen_latency = time.time() - gen_start
                        generation_latencies.append(gen_latency)

                        # Validar formato
                        validation_score = self._validate_structured_format(
                            structured_response, format_name
                        )
                        validation_scores.append(validation_score)

                        # Intentar parsear
                        parsing_success = self._test_structured_parsing(
                            structured_response, format_name
                        )
                        parsing_successes.append(1.0 if parsing_success else 0.0)

                    except Exception as e:
                        result.warnings.append(f"Error testing {format_name} with prompt '{sample['prompt']}': {e}")
                        validation_scores.append(0.0)
                        generation_latencies.append(1.0)
                        parsing_successes.append(0.0)

                format_results[format_name] = {
                    'samples_tested': len(test_samples),
                    'mean_validation_score': statistics.mean(validation_scores) if validation_scores else 0,
                    'validation_std': statistics.stdev(validation_scores) if len(validation_scores) > 1 else 0,
                    'mean_generation_latency': statistics.mean(generation_latencies) if generation_latencies else 0,
                    'parsing_success_rate': statistics.mean(parsing_successes) if parsing_successes else 0,
                    'min_validation_score': min(validation_scores) if validation_scores else 0,
                    'max_validation_score': max(validation_scores) if validation_scores else 0
                }

            result.metrics = {
                'format_results': format_results,
                'best_performing_format': max(format_results.keys(),
                    key=lambda k: format_results[k]['mean_validation_score']) if format_results else None,
                'overall_mean_validation': statistics.mean([
                    fr['mean_validation_score'] for fr in format_results.values()
                ]) if format_results else 0,
                'overall_parsing_success': statistics.mean([
                    fr['parsing_success_rate'] for fr in format_results.values()
                ]) if format_results else 0
            }

            result.success = True

        except Exception as e:
            result.errors.append(f"Structured generation test failed: {e}")

        result.end_time = time.time()
        print("✅ Structured generation test completed")
        return result

    def _generate_structured_test_samples(self, format_name: str) -> List[Dict[str, Any]]:
        """Generar samples de test para formatos estructurados."""
        if format_name == "TOON":
            prompts = [
                "Genera datos de métricas de rendimiento del sistema en formato TOON.",
                "Crea un array de números primos serializado en TOON.",
                "Produce datos estructurados de configuración en formato TOON."
            ]
        elif format_name == "VSC":
            prompts = [
                "Genera datos de series temporales en formato columnar VSC.",
                "Crea datos científicos con coordenadas x,y,z en formato VSC.",
                "Produce métricas de rendimiento en estructura columnar VSC."
            ]
        else:
            prompts = ["Genera datos estructurados."]

        return [{"prompt": p} for p in prompts * (self.config.structured_generation_samples // len(prompts) + 1)]

    async def _generate_structured_response(self, prompt: str, format_name: str) -> str:
        """Generar respuesta estructurada usando el modelo."""
        if not self.inference_api:
            raise RuntimeError("Inference API not available")

        # Crear prompt específico para el formato
        if format_name == "TOON":
            full_prompt = f"{prompt}\nPor favor, responde con datos serializados en formato TOON (Typed Object Notation)."
        elif format_name == "VSC":
            full_prompt = f"{prompt}\nPor favor, responde con datos serializados en formato VSC (Vector Serialized Columns)."
        else:
            full_prompt = prompt

        # Generar respuesta
        from src.ailoos.inference.api import InferenceRequest
        request = InferenceRequest(prompt=full_prompt, max_tokens=200)
        response = await self.inference_api.generate(request)
        return response.text if response else ""

    def _validate_structured_format(self, response: str, format_name: str) -> float:
        """Validar que la respuesta tenga el formato correcto."""
        if not response:
            return 0.0

        response_lower = response.lower()

        if format_name == "TOON":
            # Buscar indicadores de formato TOON
            toon_indicators = ['toon', 'typed object', 'serializ', 'array', '[']
            matches = sum(1 for indicator in toon_indicators if indicator in response_lower)
            return min(matches / len(toon_indicators), 1.0)

        elif format_name == "VSC":
            # Buscar indicadores de formato VSC
            vsc_indicators = ['vsc', 'vector', 'column', 'serializ', '{', 'x:', 'y:', 'z:']
            matches = sum(1 for indicator in vsc_indicators if indicator in response_lower)
            return min(matches / len(vsc_indicators), 1.0)

        return 0.0

    def _test_structured_parsing(self, response: str, format_name: str) -> bool:
        """Intentar parsear la respuesta estructurada."""
        try:
            if format_name == "TOON":
                # Intentar detectar formato TOON
                if '[' in response or 'array' in response.lower():
                    return True
            elif format_name == "VSC":
                # Intentar detectar formato VSC
                if '{' in response or 'column' in response.lower():
                    return True
            return False
        except Exception:
            return False

    def _calculate_detailed_quality_metrics(self, test_results: List[QualityTestResult]) -> Dict[str, Any]:
        """Calcular métricas detalladas de calidad."""
        quality_metrics = {
            'overall_quality_score': 0.0,
            'component_scores': {},
            'quality_breakdown': {}
        }

        # Ponderaciones de calidad
        weights = self.config.quality_metrics_config

        # Calcular scores por componente
        for result in test_results:
            if result.test_type == "rag_accuracy":
                rag_score = result.metrics.get('overall_mean_accuracy', 0)
                quality_metrics['component_scores']['rag_factual_accuracy'] = rag_score

            elif result.test_type == "tokenizer_robustness":
                tokenizer_score = (
                    weights['tokenizer_efficiency_weights']['compression_ratio'] *
                    result.metrics.get('mean_compression_ratio', 0) / 10 +  # Normalizar
                    weights['tokenizer_efficiency_weights']['vocabulary_coverage'] * 0.9 +  # Asumir buena cobertura
                    weights['tokenizer_efficiency_weights']['robustness_score'] *
                    result.metrics.get('mean_robustness_score', 0)
                )
                quality_metrics['component_scores']['tokenizer_efficiency'] = tokenizer_score

            elif result.test_type == "regression_testing":
                regression_score = (
                    weights['regression_safety_weights']['accuracy_safety'] *
                    (1.0 if result.validation_results.get('accuracy_safety', False) else 0.0) +
                    weights['regression_safety_weights']['performance_safety'] *
                    (1.0 if result.validation_results.get('performance_safety', False) else 0.0) +
                    weights['regression_safety_weights']['resource_safety'] *
                    (1.0 if result.validation_results.get('resource_safety', False) else 0.0)
                )
                quality_metrics['component_scores']['regression_safety'] = regression_score

            elif result.test_type == "structured_generation":
                structured_score = result.metrics.get('overall_mean_validation', 0)
                quality_metrics['component_scores']['structured_generation'] = structured_score

        # Calcular score general
        component_scores = quality_metrics['component_scores']
        if component_scores:
            quality_metrics['overall_quality_score'] = statistics.mean(component_scores.values())

        # Desglose detallado
        quality_metrics['quality_breakdown'] = {
            'num_tests_passed': sum(1 for r in test_results if r.success),
            'num_tests_failed': sum(1 for r in test_results if not r.success),
            'total_test_duration': sum(r.duration for r in test_results),
            'error_count': sum(len(r.errors) for r in test_results),
            'warning_count': sum(len(r.warnings) for r in test_results)
        }

        return quality_metrics

    def _perform_exhaustive_validations(self, test_results: List[QualityTestResult]) -> Dict[str, Any]:
        """Realizar validaciones exhaustivas de los resultados."""
        validations = {
            'quality_requirements': {},
            'performance_requirements': {},
            'reliability_requirements': {},
            'safety_requirements': {}
        }

        # Validar requisitos de calidad
        quality_metrics = self._calculate_detailed_quality_metrics(test_results)
        overall_score = quality_metrics.get('overall_quality_score', 0)

        validations['quality_requirements'] = {
            'minimum_quality_score': overall_score >= 0.7,  # 70% mínimo
            'all_components_above_threshold': all(
                score >= 0.6 for score in quality_metrics.get('component_scores', {}).values()
            ),
            'no_critical_failures': sum(1 for r in test_results if not r.success) == 0
        }

        # Validar requisitos de performance
        total_duration = sum(r.duration for r in test_results)
        avg_duration_per_test = total_duration / len(test_results) if test_results else 0

        validations['performance_requirements'] = {
            'total_duration_under_limit': total_duration <= self.config.validation_timeout_seconds,
            'average_test_duration_reasonable': avg_duration_per_test <= 60,  # 1 min por test
            'no_timeout_errors': not any('timeout' in str(e).lower() for r in test_results for e in r.errors)
        }

        # Validar requisitos de reliability
        error_rate = sum(len(r.errors) for r in test_results) / max(1, sum(len(r.errors) + len(r.warnings) for r in test_results))

        validations['reliability_requirements'] = {
            'error_rate_below_threshold': error_rate <= self.config.error_tolerance_threshold,
            'all_critical_tests_passed': all(r.success for r in test_results if r.test_type in ['rag_accuracy', 'regression_testing']),
            'graceful_error_handling': all(len(r.errors) == 0 or any('graceful' in str(e).lower() for e in r.errors) for r in test_results)
        }

        # Validar requisitos de safety
        safety_checks = []
        for result in test_results:
            if result.test_type == 'regression_testing':
                safety_checks.extend(result.validation_results.values())

        validations['safety_requirements'] = {
            'regression_safety_passed': all(safety_checks) if safety_checks else True,
            'no_data_corruption_indicators': not any('corruption' in str(e).lower() for r in test_results for e in r.errors),
            'resource_usage_safe': not any('memory' in str(e).lower() and 'exceeded' in str(e).lower() for r in test_results for e in r.errors)
        }

        # Validación general
        all_validations_passed = all(
            all(checks.values()) if isinstance(checks, dict) else checks
            for checks in validations.values()
        )

        validations['overall_validation'] = {
            'all_validations_passed': all_validations_passed,
            'validation_categories_passed': sum(1 for cat_checks in validations.values()
                if isinstance(cat_checks, dict) and all(cat_checks.values())),
            'total_validation_checks': sum(len(checks) if isinstance(checks, dict) else 1
                for checks in validations.values() if isinstance(checks, dict))
        }

        return validations

    def save_results(self, results: Dict[str, Any], filename: Optional[str] = None):
        """Guardar resultados de test en archivo JSON."""
        if filename is None:
            filename = self.config.results_file

        try:
            # Preparar datos para serialización
            serializable_results = json.loads(json.dumps(results, default=str))

            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(serializable_results, f, indent=2, ensure_ascii=False)

            print(f"💾 Results saved to {filename}")
            return True

        except Exception as e:
            print(f"❌ Error saving results: {e}")
            return False

    def print_detailed_report(self, results: Dict[str, Any]):
        """Imprimir reporte detallado de resultados."""
        print("\n" + "="*80)
        print("🎯 MLOPS QUALITY TEST REPORT")
        print("="*80)

        # Resultados generales
        if 'total_duration' in results:
            print(f"   Total Duration: {results['total_duration']:.2f}s")
        if 'overall_success' in results:
            status = "✅ PASSED" if results['overall_success'] else "❌ FAILED"
            print(f"   Overall Status: {status}")

        # Resultados individuales
        individual_results = results.get('individual_test_results', [])
        for result in individual_results:
            print(f"\n🔍 {result['test_name'].replace('_', ' ').title()}")
            print("-" * 50)

            status = "✅" if result.get('success', False) else "❌"
            duration = result.get('duration', 0)
            print(f"   {status} Duration: {duration:.2f}s")

            if result.get('errors'):
                print(f"   ❌ Errors: {len(result['errors'])}")
                for error in result['errors'][:3]:  # Mostrar primeros 3 errores
                    print(f"      • {error[:100]}...")

            if result.get('warnings'):
                print(f"   ⚠️ Warnings: {len(result['warnings'])}")

            # Métricas específicas
            metrics = result.get('metrics', {})
            if metrics:
                if 'technique_results' in metrics:
                    print("   📊 RAG Techniques:")
                    for tech, tech_metrics in metrics['technique_results'].items():
                        acc = tech_metrics.get('mean_accuracy', 0)
                        lat = tech_metrics.get('mean_latency', 0)
                        print(f"      • {tech}: {acc:.1%} accuracy, {lat:.3f}s latency")

                if 'mean_robustness_score' in metrics:
                    robust = metrics['mean_robustness_score']
                    comp = metrics.get('mean_compression_ratio', 0)
                    print(f"   🔤 Tokenizer: {robust:.1%} robustness, {comp:.1f} compression ratio")

                if 'accuracy_drop' in metrics:
                    drop = metrics['accuracy_drop']
                    increase = metrics.get('latency_increase', 0)
                    safe = result.get('validation_results', {}).get('overall_regression_safe', False)
                    status = "✅ SAFE" if safe else "❌ UNSAFE"
                    print(f"   📈 Regression: {drop:.1%} accuracy drop, {increase:.1%} latency increase - {status}")

        # Validaciones
        validations = results.get('validations', {})
        if validations:
            print("\n🔍 VALIDATIONS")
            print("-" * 50)

            for category, checks in validations.items():
                if isinstance(checks, dict):
                    passed = sum(checks.values())
                    total = len(checks)
                    status = "✅" if passed == total else "❌"
                    print(f"   {status} {category}: {passed}/{total} passed")

        print("\n" + "="*80)


async def run_mlops_quality_test(
    test_name: str = "comprehensive_mlops_quality_test",
    enable_rag_factual_accuracy: bool = True,
    enable_tokenizer_robustness: bool = True,
    enable_regression_testing: bool = True,
    enable_structured_generation: bool = True,
    enable_detailed_metrics: bool = True,
    enable_exhaustive_validations: bool = True
) -> Dict[str, Any]:
    """
    Ejecutar test completo de calidad MLOps con configuración personalizada.

    Args:
        test_name: Nombre del test
        enable_rag_factual_accuracy: Habilitar test de precisión RAG
        enable_tokenizer_robustness: Habilitar test de robustez del tokenizer
        enable_regression_testing: Habilitar test de regresión
        enable_structured_generation: Habilitar test de generación estructurada
        enable_detailed_metrics: Habilitar métricas detalladas
        enable_exhaustive_validations: Habilitar validaciones exhaustivas

    Returns:
        Resultados completos del test
    """
    print(f'🚀 Ejecutando test de calidad MLOps: {test_name}...')

    # Configuración personalizada
    config = MLOpsQualityTestConfig(
        test_name=test_name,
        enable_rag_factual_accuracy=enable_rag_factual_accuracy,
        enable_tokenizer_robustness=enable_tokenizer_robustness,
        enable_regression_testing=enable_regression_testing,
        enable_structured_generation=enable_structured_generation,
        enable_detailed_metrics=enable_detailed_metrics,
        enable_exhaustive_validations=enable_exhaustive_validations
    )

    suite = MLOpsQualityTestSuite(config)
    results = {}

    try:
        # Setup
        setup_success = await suite.setup_test_environment()
        if not setup_success:
            return {'error': 'Setup failed'}

        # Ejecutar test completo
        results = await suite.run_comprehensive_quality_test()

        # Guardar resultados
        suite.save_results(results)

        # Imprimir reporte
        suite.print_detailed_report(results)

        return results

    except Exception as e:
        print(f'❌ Test falló con error: {e}')
        import traceback
        traceback.print_exc()
        return {'error': str(e), 'partial_results': results}

    finally:
        await suite.teardown_test_environment()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Ejecutar tests de calidad MLOps para AILOOS')
    parser.add_argument('--test-name', type=str, default='comprehensive_mlops_quality_test',
                        help='Nombre del test (default: comprehensive_mlops_quality_test)')
    parser.add_argument('--rag-tests', action='store_true', default=True,
                        help='Habilitar tests de precisión RAG')
    parser.add_argument('--tokenizer-tests', action='store_true', default=True,
                        help='Habilitar tests de robustez del tokenizer')
    parser.add_argument('--regression-tests', action='store_true', default=True,
                        help='Habilitar tests de regresión')
    parser.add_argument('--structured-tests', action='store_true', default=True,
                        help='Habilitar tests de generación estructurada')
    parser.add_argument('--detailed-metrics', action='store_true', default=True,
                        help='Habilitar métricas detalladas')
    parser.add_argument('--exhaustive-validations', action='store_true', default=True,
                        help='Habilitar validaciones exhaustivas')

    args = parser.parse_args()

    # Ejecutar test
    success_result = asyncio.run(run_mlops_quality_test(
        test_name=args.test_name,
        enable_rag_factual_accuracy=args.rag_tests,
        enable_tokenizer_robustness=args.tokenizer_tests,
        enable_regression_testing=args.regression_tests,
        enable_structured_generation=args.structured_tests,
        enable_detailed_metrics=args.detailed_metrics,
        enable_exhaustive_validations=args.exhaustive_validations
    ))

    if 'error' not in success_result:
        print('\n🎉 Tests de calidad MLOps completados exitosamente!')
    else:
        print(f'\n❌ Tests fallaron: {success_result["error"]}')