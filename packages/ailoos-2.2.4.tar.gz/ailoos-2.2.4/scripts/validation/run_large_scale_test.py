"""
Script para ejecutar tests de integración P2P/IPFS a gran escala sin pytest.
"""

import asyncio
import json
import time
import random
import sys
import os

# Añadir el directorio raíz al path para importar módulos
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Importaciones simplificadas, evitando pytest
try:
    import torch
    HAS_TORCH = True
    print("Using PyTorch for tensor operations")
except ImportError:
    HAS_TORCH = False
    print("WARNING: PyTorch not available, using NumPy fallback for tensor operations")

# NumPy is now required for metrics, so we import it separately.
try:
    import numpy as np
except ImportError:
    print("ERROR: NumPy not available, which is required for metrics. Installing...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy"])
    import numpy as np
    print("NumPy installed successfully")

# Copia de las clases necesarias del archivo de test para evitar dependencias
import asyncio
import time
import random
import json
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass, field

@dataclass
class VirtualNode:
    """Nodo virtual para simulación a gran escala con un protocolo de gossip más robusto."""
    node_id: str
    host: str = "127.0.0.1"
    port: int = 0
    is_active: bool = True
    last_heartbeat: float = 0.0
    model_weights: Optional[Dict[str, Any]] = None
    received_chunks: Dict[str, bytes] = field(default_factory=dict)
    
    # Store de metadatos con versiones para un diffing eficiente
    metadata_store: Dict[str, Tuple[Any, int]] = field(default_factory=dict)
    
    failure_probability: float = 0.005
    recovery_time: float = 0.0
    consecutive_failures: int = 0
    max_consecutive_failures: int = 3
    recovery_attempts: int = 0
    max_recovery_attempts: int = 5
    
    # Atributos para el nuevo protocolo de gossip
    last_reconciliation: float = 0.0
    reconciliation_interval: float = 1.5  # Reconciliar cada 1.5 segundos para mejor propagación

    def update_metadata(self, metadata: Dict[str, Any], increment_version: bool = True):
        """Actualiza los metadatos. Si increment_version es True, aumenta la versión."""
        for key, value in metadata.items():
            current_version = self.metadata_store.get(key, (None, 0))[1]
            # Solo actualiza si el valor es diferente para no crear versiones innecesarias
            if self.metadata_store.get(key, (None, None))[0] != value:
                new_version = current_version + 1 if increment_version else current_version
                self.metadata_store[key] = (value, new_version)

    def get_metadata_digest(self) -> Dict[str, int]:
        """Devuelve un resumen (digest) de los metadatos (key -> version)."""
        return {key: version for key, (value, version) in self.metadata_store.items()}

    def simulate_failure(self) -> bool:
        """Simular fallo aleatorio."""
        if random.random() < self.failure_probability:
            self.is_active = False
            self.recovery_time = time.time() + random.uniform(5, 15)  # Aumentado para redes grandes
            self.consecutive_failures += 1
            self.recovery_attempts = 0
            return True
        return False

    def attempt_recovery(self) -> bool:
        """Intentar recuperación con múltiples intentos."""
        if not self.is_active and time.time() >= self.recovery_time:
            # Simular probabilidad de éxito en recuperación
            success_probability = 0.9 - (self.recovery_attempts * 0.05)  # Disminuye con intentos
            if random.random() < success_probability:
                self.is_active = True
                self.consecutive_failures = 0
                self.recovery_attempts = 0
                return True
            else:
                self.recovery_attempts += 1
                if self.recovery_attempts < self.max_recovery_attempts:
                    # Reintentar con delay progresivo
                    delay = random.uniform(2, 5) * (self.recovery_attempts + 1)
                    self.recovery_time = time.time() + delay
                # Si excede max intentos, queda fallido
                return False
        return False

    def send_heartbeat(self) -> float:
        """Enviar heartbeat simulado."""
        self.last_heartbeat = time.time()
        return random.uniform(0.01, 0.1)

@dataclass
class LargeScaleTestConfig:
    """Configuración para tests a gran escala."""
    num_nodes: int = 100
    simulation_duration: int = 120  # Aumentado para permitir recuperaciones
    tick_interval: float = 0.1
    model_size_mb: int = 10
    chunk_size_kb: int = 1024
    gossip_fanout: int = 15  # Aumentado para mejor propagación
    heartbeat_interval: int = 10
    failure_rate: float = 0.005  # Reducido para mejor estabilidad
    ipfs_concurrent_uploads: int = 10
    ipfs_concurrent_distributions: int = 20

class VirtualP2PNetwork:
    """Red P2P virtual para simulación."""

    def __init__(self, config: LargeScaleTestConfig):
        self.config = config
        self.nodes: Dict[str, VirtualNode] = {}
        self.message_queue: asyncio.Queue = asyncio.Queue()
        self.network_delays: Dict[Tuple[str, str], float] = {}
        self.is_running = False
        self.stats = {
            'messages_sent': 0,
            'gossip_messages': 0,
            'model_messages': 0,
        }

    def reset_stats(self):
        """Reset network statistics."""
        self.stats = {
            'messages_sent': 0,
            'gossip_messages': 0,
            'model_messages': 0,
        }

    def create_nodes(self) -> List[VirtualNode]:
        """Crear nodos virtuales."""
        nodes = []
        for i in range(self.config.num_nodes):
            node_id = f"node_{i:04d}"
            port = 8000 + i

            node = VirtualNode(
                node_id=node_id,
                host="127.0.0.1",
                port=port,
                failure_probability=self.config.failure_rate
            )

            node.model_weights = self._generate_random_model()
            self.nodes[node_id] = node
            nodes.append(node)

        self._generate_network_topology()
        return nodes

    def _generate_random_model(self) -> Dict[str, Any]:
        """Generar modelo simulado."""
        model = {}
        total_params = (self.config.model_size_mb * 1024 * 1024) // 4

        for i in range(10):
            layer_size = total_params // 10
            if layer_size < 100:
                layer_size = 100
            shape = (max(1, layer_size // 100), min(100, layer_size))
            if HAS_TORCH:
                model[f"layer_{i}"] = torch.randn(*shape)
            else:
                model[f"layer_{i}"] = np.random.randn(*shape).astype(np.float32)

        return model

    def _generate_network_topology(self):
        """Generar topología de red con delays simulados."""
        node_ids = list(self.nodes.keys())

        for i, node_a in enumerate(node_ids):
            for j, node_b in enumerate(node_ids[i+1:], i+1):
                distance_factor = random.uniform(0.01, 1.0)
                self.network_delays[(node_a, node_b)] = distance_factor
                self.network_delays[(node_b, node_a)] = distance_factor

    def send_message(self, from_node: str, to_node: str, message: Dict[str, Any]):
        """
        Pone un mensaje en la cola después de una demora simulada, sin bloquear.
        Lanza una nueva tarea para manejar la espera.
        """
        try:
            if from_node not in self.nodes or to_node not in self.nodes:
                return False
            if not self.nodes[from_node].is_active or not self.nodes[to_node].is_active:
                return False

            # Control de congestión simple para evitar que la cola explote
            if self.message_queue.qsize() > 100 * self.config.num_nodes:
                return False  # Descartar mensaje

            delay = self.network_delays.get((from_node, to_node), 0.1) * random.uniform(0.7, 1.3)

            async def delayed_put():
                await asyncio.sleep(delay)
                await self.message_queue.put({
                    'from': from_node, 'to': to_node, 'message': message,
                    'timestamp': time.time(), 'delay': delay
                })

            asyncio.create_task(delayed_put())

            self.stats['messages_sent'] += 1
            if message.get('type', '').startswith('gossip'):
                self.stats['gossip_messages'] += 1
            elif message.get('type') == 'model_distribution':
                self.stats['model_messages'] += 1
            
            return True

        except Exception:
            return False

    def broadcast_message(self, from_node: str, message: Dict[str, Any], fanout: int = 5):
        """Broadcast simulado con fanout limitado."""
        if not self.nodes[from_node].is_active:
            return 0

        active_peers = [n for n in self.nodes.keys() if n != from_node and self.nodes[n].is_active]
        
        # Asegurarse de que el tamaño de la muestra no exceda la población
        num_targets = min(fanout, len(active_peers))
        if num_targets == 0:
            return 0
            
        target_nodes = random.sample(active_peers, num_targets)

        sent_count = 0
        for target_node in target_nodes:
            if self.send_message(from_node, target_node, message):
                sent_count += 1

        return sent_count

    async def process_message_queue(self):
        """Procesar cola de mensajes."""
        while self.is_running:
            try:
                message_data = await asyncio.wait_for(self.message_queue.get(), timeout=0.1)

                from_node = message_data['from']
                to_node = message_data['to']
                message = message_data['message']

                if to_node in self.nodes and self.nodes[to_node].is_active:
                    await self._deliver_message(to_node, message)

            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Error processing message queue: {e}")
                continue
            finally:
                try:
                    self.message_queue.task_done()
                except ValueError:
                    pass

    async def _deliver_message(self, node_id: str, message: Dict[str, Any]):
        """Entregar mensaje a un nodo y enrutarlo al manejador adecuado."""
        node = self.nodes.get(node_id)
        if not node or not node.is_active:
            return

        msg_type = message.get('type', 'unknown')

        handlers = {
            'gossip': self._handle_gossip_message,
            'gossip_pull_request': self._handle_gossip_pull_request,
            'gossip_pull_response': self._handle_gossip_pull_response,
            'model_distribution': self._handle_model_distribution,
            'heartbeat': self._handle_heartbeat,
        }

        handler = handlers.get(msg_type)
        if handler:
            await handler(node, message)

    async def _handle_gossip_message(self, node: VirtualNode, message: Dict[str, Any]):
        """Manejar un mensaje de gossip (push)."""
        metadata = message.get('metadata', {})
        
        # Comprobar si la versión que recibimos es más nueva
        key = list(metadata.keys())[0]
        new_value, new_version = metadata[key]
        current_version = node.metadata_store.get(key, (None, 0))[1]

        if new_version <= current_version:
            return # Ya tenemos esta versión o una más nueva

        node.update_metadata({key: new_value}, increment_version=False)
        node.metadata_store[key] = (new_value, new_version) # Forzar la versión del emisor

        # Re-propagar el mensaje
        self.broadcast_message(node.node_id, message, self.config.gossip_fanout)

    async def _handle_gossip_pull_request(self, node: VirtualNode, message: Dict[str, Any]):
        """Manejar una solicitud de pull, comparar digests y responder."""
        peer_digest = message.get('digest', {})
        node_digest = node.get_metadata_digest()

        # Encontrar qué necesita el peer (lo que yo tengo y él no, o con versión más nueva)
        updates_for_peer = {}
        for key, (value, version) in node.metadata_store.items():
            if key not in peer_digest or version > peer_digest[key]:
                updates_for_peer[key] = (value, version)
        
        # No hay nada que el peer no sepa ya
        if not updates_for_peer:
            return

        response_message = {
            'type': 'gossip_pull_response',
            'from': node.node_id,
            'updates': updates_for_peer
        }
        self.send_message(node.node_id, message['from'], response_message)

    async def _handle_gossip_pull_response(self, node: VirtualNode, message: Dict[str, Any]):
        """Manejar una respuesta de pull, actualizando el estado local."""
        updates = message.get('updates', {})
        for key, (value, version) in updates.items():
            current_version = node.metadata_store.get(key, (None, 0))[1]
            if version > current_version:
                node.metadata_store[key] = (value, version)

    async def _handle_model_distribution(self, node: VirtualNode, message: Dict[str, Any]):
        """Manejar distribución de modelo."""
        chunk_id = message.get('chunk_id')
        chunk_data = message.get('data')

        if chunk_id and chunk_data:
            node.received_chunks[chunk_id] = chunk_data

    async def _handle_heartbeat(self, node: VirtualNode, message: Dict[str, Any]):
        """Manejar heartbeat."""
        node.last_heartbeat = time.time()

    async def start_simulation(self):
        """Iniciar simulación de red."""
        self.is_running = True
        asyncio.create_task(self.process_message_queue())

    async def stop_simulation(self):
        """Detener simulación de red."""
        self.is_running = False
        await self.message_queue.join()

    def get_network_stats(self) -> Dict[str, Any]:
        """Obtener estadísticas de la red."""
        active_nodes = sum(1 for n in self.nodes.values() if n.is_active)
        total_messages = self.message_queue.qsize()

        return {
            'total_nodes': len(self.nodes),
            'active_nodes': active_nodes,
            'inactive_nodes': len(self.nodes) - active_nodes,
            'messages_in_queue': total_messages,
            'network_uptime': time.time() - getattr(self, 'start_time', time.time())
        }

class LargeScaleP2PTestSuite:
    """Suite de tests para escenarios P2P/IPFS a gran escala."""

    def __init__(self, config: LargeScaleTestConfig):
        self.config = config
        self.network = VirtualP2PNetwork(config)
        self.nodes = []
        self.test_results = {}
        self._background_simulation_task: Optional[asyncio.Task] = None
        self.total_failures = 0
        self.total_recoveries = 0
        self.simulation_end_time = None

    async def setup_test_environment(self):
        """Configurar entorno de test y arrancar la simulación de fondo."""
        print(f"🚀 Setting up large-scale test environment with {self.config.num_nodes} nodes...")

        self.nodes = self.network.create_nodes()
        self.simulation_end_time = time.time() + self.config.simulation_duration
        await self.network.start_simulation()

        # Arrancar la simulación de red (fallos, recuperación, reconciliación) en segundo plano
        self._background_simulation_task = asyncio.create_task(self._run_background_simulation())

        print("✅ Test environment ready")

    async def teardown_test_environment(self):
        """Limpiar entorno de test y detener la simulación de fondo."""
        print("🛑 Tearing down test environment...")

        # Detener la simulación de fondo
        if self._background_simulation_task:
            self._background_simulation_task.cancel()
            try:
                await self._background_simulation_task
            except asyncio.CancelledError:
                pass # La cancelación es esperada

        await self.network.stop_simulation()

        print("✅ Test environment cleaned up")

    async def reset_node_states(self):
        """Reset all nodes to a clean, active state."""
        # print("🔄 Reiniciando el estado de los nodos...")
        self.network.reset_stats()
        self.total_failures = 0
        self.total_recoveries = 0
        for node in self.nodes:
            node.is_active = True
            node.last_heartbeat = 0.0
            node.received_chunks.clear()
            node.metadata_store.clear()
            node.recovery_time = 0.0
            node.consecutive_failures = 0

        # Clear any pending messages from the queue
        while not self.network.message_queue.empty():
            try:
                self.network.message_queue.get_nowait()
                self.network.message_queue.task_done()
            except (asyncio.QueueEmpty, ValueError):
                break
        # print("✅ Estado de los nodos reiniciado.")

    async def run_simulation_tick(self) -> Dict[str, Any]:
        """Ejecutar un tick de simulación, incluyendo fallos, recuperaciones y reconciliación de gossip."""
        failed_nodes, recovered_nodes, heartbeat_nodes = [], [], []

        for node in self.nodes:
            if time.time() <= self.simulation_end_time and node.simulate_failure():
                failed_nodes.append(node.node_id)
                continue

            if node.attempt_recovery():
                recovered_nodes.append(node.node_id)

            if node.is_active:
                # Iniciar reconciliación de gossip periódicamente
                if time.time() - node.last_reconciliation > node.reconciliation_interval:
                    node.last_reconciliation = time.time()

                    # Elegir un peer aleatorio (que no sea él mismo)
                    peers = [p for p in self.nodes if p.node_id != node.node_id and p.is_active]
                    if peers:
                        target_peer = random.choice(peers)

                        request_message = {
                            'type': 'gossip_pull_request',
                            'from': node.node_id,
                            'digest': node.get_metadata_digest()
                        }
                        self.network.send_message(node.node_id, target_peer.node_id, request_message)

                # Enviar heartbeats
                if random.random() < 0.1:
                    response_time = node.send_heartbeat()
                    heartbeat_nodes.append((node.node_id, response_time))

        # Acumular estadísticas globales
        self.total_failures += len(failed_nodes)
        self.total_recoveries += len(recovered_nodes)

        return {
            'failed_nodes': failed_nodes,
            'recovered_nodes': recovered_nodes,
            'heartbeat_nodes': heartbeat_nodes,
            'network_stats': self.network.get_network_stats()
        }

    async def test_model_distribution_at_scale(self) -> Dict[str, Any]:
        """Test de distribución de modelos vía IPFS con miles de nodos."""
        print(f"📦 Testing model distribution with {self.config.num_nodes} nodes...")

        start_time = time.time()

        try:
            model_chunks = self._create_model_chunks()

            coordinator_nodes = random.sample(self.nodes, min(10, len(self.nodes)))

            distribution_tasks = []
            for i, coordinator in enumerate(coordinator_nodes):
                chunk_batch = model_chunks[i::len(coordinator_nodes)]
                task = self._distribute_chunks_from_coordinator(coordinator, chunk_batch)
                distribution_tasks.append(task)

            results = await asyncio.gather(*distribution_tasks, return_exceptions=True)

            # Calcular métricas de distribución
            total_chunks_distributed = sum(len(r) for r in results if isinstance(r, list))
            successful_distributions = sum(1 for r in results if isinstance(r, list) and len(r) > 0)

            # Validaciones exhaustivas de distribución
            nodes_with_chunks = sum(1 for node in self.nodes if node.received_chunks)
            total_chunks_received = sum(len(node.received_chunks) for node in self.nodes)
            avg_chunks_per_node = total_chunks_received / len(self.nodes) if self.nodes else 0
    
            # Verificar integridad de chunks: todos los chunks deben ser únicos y válidos
            all_received_chunk_ids = set()
            for node in self.nodes:
                all_received_chunk_ids.update(node.received_chunks.keys())
    
            chunks_integrity = len(all_received_chunk_ids) >= len(model_chunks) * 0.9  # Al menos 90% de chunks distribuidos
    
            # Verificar que los datos de chunks sean consistentes
            chunk_data_consistency = True
            expected_chunk_ids = {chunk_id for chunk_id, _ in model_chunks}
            for node in self.nodes:
                for chunk_id in node.received_chunks:
                    if chunk_id not in expected_chunk_ids:
                        chunk_data_consistency = False
                        break
                if not chunk_data_consistency:
                    break
    
            duration = time.time() - start_time
    
            result = {
                'test_name': 'model_distribution_at_scale',
                'duration': duration,
                'total_chunks': len(model_chunks),
                'chunks_distributed': total_chunks_distributed,
                'successful_coordinators': successful_distributions,
                'total_coordinators': len(coordinator_nodes),
                'distribution_rate': total_chunks_distributed / duration if duration > 0 else 0,
                'success_rate': total_chunks_distributed / len(model_chunks) if model_chunks else 0,
                'nodes_receiving_chunks': nodes_with_chunks,
                'total_chunks_received': total_chunks_received,
                'avg_chunks_per_node': avg_chunks_per_node,
                'chunks_integrity': chunks_integrity,
                'chunk_data_consistency': chunk_data_consistency
            }

        except Exception as e:
            print(f"❌ Error in model distribution test: {e}")
            duration = time.time() - start_time
            result = {
                'test_name': 'model_distribution_at_scale',
                'duration': duration,
                'error': str(e)
            }

        print(f"✅ Model distribution test completed: {result.get('chunks_distributed', 0)}/{result.get('total_chunks', 0)} chunks distributed")
        return result

    def _create_model_chunks(self) -> List[Tuple[str, bytes]]:
        """Crear chunks simulados del modelo."""
        chunks = []
        total_size = self.config.model_size_mb * 1024 * 1024
        chunk_size = self.config.chunk_size_kb * 1024

        num_chunks = total_size // chunk_size
        if total_size % chunk_size > 0:
            num_chunks += 1

        for i in range(num_chunks):
            chunk_id = f"chunk_{i:06d}"
            chunk_data = b'x' * min(chunk_size, total_size - i * chunk_size)
            chunks.append((chunk_id, chunk_data))

        return chunks

    async def _distribute_chunks_from_coordinator(self, coordinator: VirtualNode,
                                                chunks: List[Tuple[str, bytes]]) -> List[str]:
        """Distribuir chunks desde un coordinador."""
        distributed_chunks = set()

        for chunk_id, chunk_data in chunks:
            if not coordinator.is_active:
                break

            available_nodes = [n for n in self.nodes if n.is_active and n != coordinator]
            if not available_nodes:
                break

            # Estrategia de distribución unificada y más robusta
            if self.config.num_nodes <= 10:
                # Para redes pequeñas, un número fijo es suficiente
                num_targets = min(3, len(available_nodes))
            else:
                # Para redes grandes, usar un porcentaje de la red o el fanout para asegurar la propagación
                num_targets = min(max(self.config.gossip_fanout, int(len(available_nodes) * 0.15)), len(available_nodes))
            
            target_nodes = random.sample(available_nodes, num_targets)

            for target_node in target_nodes:
                message = {
                    'type': 'model_distribution',
                    'chunk_id': chunk_id,
                    'data': chunk_data,
                    'from': coordinator.node_id,
                    'timestamp': time.time()
                }

                if self.network.send_message(coordinator.node_id, target_node.node_id, message):
                    distributed_chunks.add(chunk_id)

            await asyncio.sleep(0.001)

        return list(distributed_chunks)

    async def test_gossip_consensus_at_scale(self) -> Dict[str, Any]:
        """Test de consenso gossip con el nuevo protocolo de reconciliación de fondo."""
        print(f"🗣️ Testing gossip consensus with {self.config.num_nodes} nodes...")

        start_time = time.time()

        test_metadata = {
            f'model_version_{random.randint(0, 1000)}': f'v3.{random.randint(0, 100)}',
            f'federation_round_{random.randint(0, 1000)}': random.randint(0, 1000)
        }

        initiator_nodes = random.sample(self.nodes, min(5, len(self.nodes)))
        for initiator in initiator_nodes:
            await self._initiate_gossip_consensus(initiator, test_metadata)

        # Con el protocolo de reconciliación corriendo en fondo, solo necesitamos esperar
        propagation_time = 35 + self.config.num_nodes * 0.8
        propagation_time = min(propagation_time, 120) # Cap aumentado
        await asyncio.sleep(propagation_time)

        # Verificar el estado final del consenso
        sample_nodes = self.nodes
        consensus_reached = 0
        for node in sample_nodes:
            # Comprobar si el nodo tiene toda la metadata de la prueba
            if all(key in node.metadata_store for key in test_metadata):
                consensus_reached += 1
        
        # Calcular la salud de la red (consistencia del estado)
        metadata_counts = [len(node.metadata_store) for node in self.nodes]
        if len(metadata_counts) > 1 and np:
            network_health_stddev = np.std(metadata_counts)
        else:
            network_health_stddev = 0

        duration = time.time() - start_time

        result = {
            'test_name': 'gossip_consensus_at_scale',
            'duration': duration,
            'consensus_checks': len(sample_nodes),
            'consensus_reached': consensus_reached,
            'consensus_rate': consensus_reached / len(sample_nodes) if sample_nodes else 0,
            'gossip_propagation_time': propagation_time,
            'network_health_stddev': network_health_stddev
        }

        print(f"✅ Gossip consensus test completed: {consensus_reached}/{len(sample_nodes)} nodes reached consensus")
        return result

    async def _initiate_gossip_consensus(self, initiator: VirtualNode, metadata: Dict[str, Any]):
        """Iniciar consenso gossip desde un nodo usando el nuevo sistema de versiones."""
        if not initiator.is_active:
            return

        # Actualizar el estado local del iniciador con la nueva información
        initiator.update_metadata(metadata)

        # Propagar solo la nueva información
        for key, value in metadata.items():
            versioned_value = initiator.metadata_store[key]
            gossip_message = {
                'type': 'gossip',
                'metadata': {key: versioned_value},
                'from': initiator.node_id,
                'timestamp': time.time()
            }
            # Hacer un broadcast inicial para arrancar la propagación
            self.network.broadcast_message(initiator.node_id, gossip_message, self.config.gossip_fanout)
            await asyncio.sleep(0.01) # Pequeña pausa entre envíos de claves distintas

    async def test_auto_healing_at_scale(self) -> Dict[str, Any]:
        """Test de auto-healing y fault tolerance. Observa la simulación de fondo."""
        print(f"🩹 Probando Auto-Healing with {self.config.num_nodes} nodes...")

        start_time = time.time()
        initial_active = sum(1 for n in self.nodes if n.is_active)

        # La simulación (fallos/recuperaciones) ya está corriendo en segundo plano.
        # Este test ahora solo necesita esperar a que la simulación transcurra.
        await asyncio.sleep(self.config.simulation_duration)

        # Cool-down period to allow nodes to recover after simulation
        print("⏳ Iniciando período de enfriamiento para esperar la estabilización de los nodos...")
        cooldown_duration = 30 + int(self.config.num_nodes * 1.2)  # Adaptativo: 90s para 50 nodos
        cooldown_end_time = time.time() + cooldown_duration
        while time.time() < cooldown_end_time:
            if all(n.is_active for n in self.nodes):
                break
            await asyncio.sleep(0.5)

        if all(n.is_active for n in self.nodes):
            print("✅ Todos los nodos se estabilizaron tras el período de enfriamiento.")
        else:
            active_count = sum(1 for n in self.nodes if n.is_active)
            print(f"⚠️ Alerta: No todos los nodos se estabilizaron. Activos: {active_count}/{len(self.nodes)}")

        final_active = sum(1 for n in self.nodes if n.is_active)
        duration = time.time() - start_time

        # Contar eventos de healing durante la simulación
        healing_events = 0
        for node in self.nodes:
            if node.consecutive_failures > 0:
                healing_events += 1

        result = {
            'test_name': 'auto_healing_at_scale',
            'duration': duration,
            'initial_active_nodes': initial_active,
            'final_active_nodes': final_active,
            'node_stability': final_active / initial_active if initial_active > 0 else 0,
            'healing_events': healing_events,
            'total_failure_events': self.total_failures,
            'total_recovery_events': self.total_recoveries,
        }

        print(f"✅ Auto-healing test completed: {final_active}/{initial_active} nodes stable")
        return result

    async def run_end_to_end_test(self) -> Dict[str, Any]:
        """Ejecutar test end-to-end completo combinando todos los escenarios."""
        print("🎯 Running end-to-end large-scale P2P/IPFS test...")

        start_time = time.time()

        # Run tests sequentially to avoid interference and ensure predictable results
        test_results = []
        test_results.append(await self.test_model_distribution_at_scale())
        test_results.append(await self.test_gossip_consensus_at_scale())
        test_results.append(await self.test_auto_healing_at_scale())

        duration = time.time() - start_time

        results = {}
        for result in test_results:
            if isinstance(result, dict):
                results[result['test_name']] = result

        network_stats = self.network.get_network_stats()
        active_nodes = network_stats['active_nodes']
        total_nodes = network_stats['total_nodes']

        # Validar resultados individuales para determinar el éxito general
        md_res = results.get('model_distribution_at_scale', {})
        gc_res = results.get('gossip_consensus_at_scale', {})
        ah_res = results.get('auto_healing_at_scale', {})

        num_nodes = self.config.num_nodes
        # Estándares altos pero realistas: consenso siempre 100%, estabilidad 95%+ para redes grandes
        min_consensus = 1.0  # Consenso debe ser perfecto
        min_stability = 1.0 if num_nodes <= 10 else 0.95  # Estabilidad 95%+ para redes grandes

        md_success = md_res.get('success_rate', 0) >= 0.99  # Distribución exitosa
        gc_success = gc_res.get('consensus_rate', 0) >= min_consensus
        ah_success = ah_res.get('node_stability', 0) >= min_stability

        overall_success = md_success and gc_success and ah_success

        end_to_end_result = {
            'test_name': 'end_to_end_large_scale_test',
            'duration': duration,
            'network_stats': network_stats,
            'network_stability': active_nodes / total_nodes if total_nodes > 0 else 0,
            'individual_test_results': results,
            'overall_success': overall_success,
            'success_details': {
                'model_distribution': md_success,
                'gossip_consensus': gc_success,
                'auto_healing': ah_success,
            }
        }

        print(f"🎯 End-to-end test completed in {duration:.2f}s with {active_nodes}/{total_nodes} nodes stable")
        return end_to_end_result

    async def _run_background_simulation(self):
        """Ejecutar simulación de red en background durante los tests."""
        try:
            while True:
                await self.run_simulation_tick()
                await asyncio.sleep(self.config.tick_interval)
        except asyncio.CancelledError:
            pass


async def run_adaptive_large_scale_test(num_nodes: int):
    """Ejecutar test adaptativo según el número de nodos."""
    print(f'🚀 Ejecutando test de integración P2P/IPFS con {num_nodes} nodos...')

    # Configuraciones adaptativas dinámicas según el número de nodos para escalabilidad completa
    def get_config_params(num_nodes):
        # Calcular parámetros dinámicamente basados en num_nodes
        # Duration: aumenta con num_nodes para permitir propagación en redes grandes
        duration = min(30 + num_nodes * 2, 300)  # Cap en 300s para evitar tests demasiado largos

        # Failure_rate: disminuye con num_nodes para estabilidad en redes grandes
        failure_rate = max(0.001, 0.01 - num_nodes * 0.00005)

        # Model_size: escala con num_nodes (más nodos = más chunks para distribución realista)
        model_size = min(1 + num_nodes // 10, 50)  # Cap en 50MB para evitar modelos demasiado grandes

        # Fanout: aumenta con num_nodes para mejor propagación en redes grandes
        fanout = min(3 + num_nodes // 5, 50)  # Cap en 50 para evitar sobrecarga

        return {
            'duration': duration,
            'failure_rate': failure_rate,
            'model_size': model_size,
            'fanout': fanout
        }

    params = get_config_params(num_nodes)

    config = LargeScaleTestConfig(
        num_nodes=num_nodes,
        simulation_duration=params['duration'],
        failure_rate=params['failure_rate'],
        model_size_mb=params['model_size'],
        gossip_fanout=params['fanout']
    )

    suite = LargeScaleP2PTestSuite(config)
    results = {}

    try:
        await suite.setup_test_environment()

        # Test 1: Model Distribution
        await suite.reset_node_states()
        print('\n📦 Probando Distribución de Modelos...')
        start_time = time.time()
        results['model_distribution'] = await suite.test_model_distribution_at_scale()
        results['model_distribution']['start_time'] = start_time

        # Test 2: Gossip Consensus
        await suite.reset_node_states()
        print('\n🗣️ Probando Consenso Gossip...')
        start_time = time.time()
        results['gossip_consensus'] = await suite.test_gossip_consensus_at_scale()
        results['gossip_consensus']['start_time'] = start_time

        # Test 3: Auto-healing
        await suite.reset_node_states()
        print('\n🩹 Probando Auto-Healing...')
        start_time = time.time()
        results['auto_healing'] = await suite.test_auto_healing_at_scale()
        results['auto_healing']['start_time'] = start_time

        # Test End-to-End
        await suite.reset_node_states()
        print('\n🎯 Ejecutando Test End-to-End...')
        start_time = time.time()
        results['end_to_end'] = await suite.run_end_to_end_test()
        results['end_to_end']['start_time'] = start_time

        # --- RESUMEN DETALLADO Y VALIDACIÓN ---
        print('\n' + '='*80)
        print(f'🎯 RESUMEN DETALLADO DEL TEST CON {num_nodes} NODOS')
        print('='*80)

        # 1. Realizar toda la validación primero para generar la lista de problemas.
        all_passed = True
        issues = []

        # Validar model distribution
        md_result = results.get('model_distribution', {})
        if md_result.get('chunks_distributed', 0) < md_result.get('total_chunks', 1):
            all_passed = False
            issues.append("Model distribution: No se distribuyeron todos los chunks")

        # Validar gossip consensus
        gc_result = results.get('gossip_consensus', {})
        consensus_rate = gc_result.get('consensus_rate', 0)
        # El 100% de consenso es ideal, pero poco realista en redes distribuidas no deterministas.
        # Un umbral ligeramente inferior al 100% para >10 nodos es un indicador más práctico de salud de la red.
        if num_nodes <= 5:
            min_consensus = 1.0
        else:
            min_consensus = 0.95 # 95% es un objetivo robusto y realista para redes con fallos

        if consensus_rate < min_consensus:
            all_passed = False
            issues.append(f"Gossip consensus: Tasa de consenso del {consensus_rate:.1%} por debajo del {min_consensus:.1%} requerido")

        # Validar auto-healing con estándares realistas
        ah_result = results.get('auto_healing', {})
        stability = ah_result.get('node_stability', 0)
        min_stability = 1.0 if num_nodes <= 10 else 0.95  # 100% para pequeñas, 95%+ para grandes
        if stability < min_stability:
            all_passed = False
            issues.append(f"Auto-healing: Estabilidad de nodos del {stability:.1%} por debajo del {min_stability:.1%} requerido")

        # Validar end-to-end
        et_result = results.get('end_to_end', {})
        if not et_result.get('overall_success', False):
            all_passed = False
            issues.append("End-to-end test: Falló la validación general interna")

        # 2. Imprimir el resumen detallado usando la lista de problemas para el estado.
        for test_name, result in results.items():
            # Determinar si la prueba específica está en la lista de problemas.
            test_passed = not any(test_name.replace('_', ' ') in issue.lower() for issue in issues)
            
            status = '✅' if test_passed else '❌'
            duration = result.get('duration', 0)
            print(f'\n{status} Test: {test_name.replace("_", " ").title()} ({duration:.2f}s)')
            print('-' * 45)

            if not result:
                print("    Sin datos de resultado.")
                continue

            if test_name == 'model_distribution':
                print(f"    - Chunks: {result.get('chunks_distributed', 'N/A')} distribuidos de {result.get('total_chunks', 'N/A')} totales")
                print(f"    - Tasa de Éxito (Chunks): {result.get('success_rate', 0.0):.1%}")
            elif test_name == 'gossip_consensus':
                print(f"    - Nodos en Consenso: {result.get('consensus_reached', 'N/A')} de {result.get('consensus_checks', 'N/A')} verificados")
                print(f"    - Tasa de Consenso: {result.get('consensus_rate', 0.0):.1%}")
                stddev = result.get('network_health_stddev', -1)
                print(f"    - Salud de la Red (Desv. Est.): {stddev:.2f}" if stddev >= 0 else "    - Salud de la Red (Desv. Est.): N/A")
            elif test_name == 'auto_healing':
                print(f"    - Estabilidad de Nodos: {result.get('node_stability', 0.0):.1%} ({result.get('final_active_nodes', 'N/A')}/{result.get('initial_active_nodes', 'N/A')})")
                print(f"    - Total Fallos / Recuperaciones: {result.get('total_failure_events', 'N/A')} / {result.get('total_recovery_events', 'N/A')}")
            elif test_name == 'end_to_end':
                print(f"    - Estabilidad Final de la Red: {result.get('network_stability', 0.0):.1%}")
                et_details = result.get('success_details', {})
                md_ok = '✅' if et_details.get('model_distribution', False) else '❌'
                gc_ok = '✅' if et_details.get('gossip_consensus', False) else '❌'
                ah_ok = '✅' if et_details.get('auto_healing', False) else '❌'
                print(f"    - Resultados Sub-tests: Dist({md_ok}), Consenso({gc_ok}), Recuperación({ah_ok})")

        # 3. Imprimir el resultado final.
        if all_passed:
            print('\n' + '='*80)
            print('🎉 TODOS LOS TESTS PASARON! La integración P2P/IPFS funciona perfectamente.')
            print('='*80)

            # Guardar resultados
            filename = f'large_scale_test_results_{num_nodes}_nodes.json'
            with open(filename, 'w') as f:
                # Usar un default=str para manejar tipos no serializables si los hubiera
                json.dump(results, f, indent=2, default=str)
            print(f'💾 Resultados guardados en {filename}')
        else:
            print('\n' + '='*80)
            print('❌ ALGUNOS TESTS FALLARON:')
            for issue in issues:
                print(f'  - {issue}')
            print('='*80)


        return all_passed, results

    except Exception as e:
        print(f'❌ Test falló con error: {e}')
        import traceback
        traceback.print_exc()
        return False, results

    finally:
        await suite.teardown_test_environment()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='Ejecutar tests P2P/IPFS a gran escala')
    parser.add_argument('--nodes', type=int, default=25, choices=range(2, 101),
                        help='Número de nodos para el test (2-100, default: 25)')
    parser.add_argument('--duration', type=int, default=30,
                       help='Duración de simulación en segundos (default: 30)')

    args = parser.parse_args()

    # Ejecutar test con configuración adaptada al número de nodos
    success, results = asyncio.run(run_adaptive_large_scale_test(args.nodes))

    print(f'\nResultado final: {"ÉXITO" if success else "FALLÓ"}')