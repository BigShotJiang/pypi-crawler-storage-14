#!/usr/bin/env python3
"""
FASE REAL-7: DEMO STANDALONE DE ENTRENAMIENTO FEDERADO LINGÜÍSTICO
Demuestra aprendizaje colaborativo de lenguaje sin dependencias AILOOS.
"""

import asyncio
import torch
import torch.nn as nn
import random
from typing import Dict, List, Any
from dataclasses import dataclass


@dataclass
class FederatedConfig:
    """Configuración básica del sistema federado."""
    num_nodes: int = 3
    rounds: int = 4
    local_epochs: int = 2
    learning_rate: float = 0.01


class SimpleLanguageModel(nn.Module):
    """Modelo de lenguaje simple para demo."""

    def __init__(self, vocab_size=100, embed_dim=32):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, embed_dim, batch_first=True)
        self.linear = nn.Linear(embed_dim, vocab_size)

    def forward(self, x):
        embedded = self.embed(x)
        output, _ = self.lstm(embedded)
        return self.linear(output)


class FederatedLinguisticNode:
    """Nodo federado que entrena un modelo de lenguaje."""

    def __init__(self, node_id: str, vocab_size=100):
        self.node_id = node_id
        self.vocab_size = vocab_size
        self.model = SimpleLanguageModel(vocab_size)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=0.01)

        # Datos locales (simulando distribución de datos)
        self.local_texts = self._generate_local_texts()
        self.local_data = self._prepare_data()

        # Historial de entrenamiento
        self.training_history = []

    def _generate_local_texts(self) -> List[str]:
        """Generar textos locales únicos para cada nodo."""
        base_words = ["hello", "world", "machine", "learning", "ai", "neural", "network", "data"]
        node_texts = []

        # Cada nodo tiene textos ligeramente diferentes
        for i in range(10):
            words = random.sample(base_words, 3)
            text = f"{self.node_id} {' '.join(words)} example {i}"
            node_texts.append(text)

        return node_texts

    def _prepare_data(self) -> List[Dict[str, torch.Tensor]]:
        """Preparar datos de entrenamiento."""
        data = []
        for text in self.local_texts:
            # Codificación simple: cada caracter como token
            tokens = [ord(c) % self.vocab_size for c in text.lower() if c.isalpha() or c == ' ']
            if len(tokens) > 2:
                input_seq = torch.tensor(tokens[:-1], dtype=torch.long)
                target_seq = torch.tensor(tokens[1:], dtype=torch.long)
                data.append({'input': input_seq, 'target': target_seq})
        return data

    def train_local(self, global_weights: Dict[str, torch.Tensor], epochs: int) -> Dict[str, Any]:
        """Entrenar localmente con pesos globales."""
        # Cargar pesos globales
        self.model.load_state_dict(global_weights)

        criterion = nn.CrossEntropyLoss()
        total_loss = 0
        total_acc = 0

        for epoch in range(epochs):
            epoch_loss = 0
            epoch_acc = 0

            for batch in self.local_data:
                self.optimizer.zero_grad()

                output = self.model(batch['input'].unsqueeze(0))
                loss = criterion(output.view(-1, self.vocab_size), batch['target'])

                loss.backward()
                self.optimizer.step()

                epoch_loss += loss.item()

                # Calcular accuracy
                pred = output.argmax(dim=-1).squeeze()
                acc = (pred == batch['target']).float().mean().item()
                epoch_acc += acc

            avg_epoch_loss = epoch_loss / len(self.local_data)
            avg_epoch_acc = epoch_acc / len(self.local_data)

            total_loss += avg_epoch_loss
            total_acc += avg_epoch_acc

        avg_loss = total_loss / epochs
        avg_acc = total_acc / epochs

        # Guardar en historial
        self.training_history.append({
            'loss': avg_loss,
            'accuracy': avg_acc,
            'epochs': epochs
        })

        return {
            'node_id': self.node_id,
            'weights': self.model.state_dict(),
            'loss': avg_loss,
            'accuracy': avg_acc,
            'samples': len(self.local_data),
            'training_time': epochs * 0.1  # Simulado
        }


class FederatedCoordinator:
    """Coordinador simple del entrenamiento federado."""

    def __init__(self, config: FederatedConfig):
        self.config = config
        self.global_model = SimpleLanguageModel()
        self.nodes = []
        self.round_results = []

        # Métricas globales
        self.global_loss_history = []
        self.global_acc_history = []

    def add_node(self, node: FederatedLinguisticNode):
        """Añadir nodo al sistema federado."""
        self.nodes.append(node)

    def aggregate_weights(self, node_updates: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        """Agregar pesos de manera federada (FedAvg simple)."""
        if not node_updates:
            return self.global_model.state_dict()

        # Promediar pesos de todos los nodos
        global_weights = {}
        total_samples = sum(update['samples'] for update in node_updates)

        for key in self.global_model.state_dict().keys():
            weighted_sum = torch.zeros_like(self.global_model.state_dict()[key])

            for update in node_updates:
                weight = update['samples'] / total_samples
                weighted_sum += weight * update['weights'][key]

            global_weights[key] = weighted_sum

        return global_weights

    def evaluate_global_model(self) -> Dict[str, float]:
        """Evaluar modelo global."""
        self.global_model.eval()

        # Evaluar en datos de prueba simples
        test_texts = ["hello world", "machine learning", "ai systems"]
        total_loss = 0
        total_acc = 0

        criterion = nn.CrossEntropyLoss()

        for text in test_texts:
            tokens = [ord(c) % 100 for c in text.lower() if c.isalpha() or c == ' ']
            if len(tokens) > 1:
                input_seq = torch.tensor(tokens[:-1], dtype=torch.long).unsqueeze(0)
                target_seq = torch.tensor(tokens[1:], dtype=torch.long)

                with torch.no_grad():
                    output = self.global_model(input_seq)
                    loss = criterion(output.view(-1, 100), target_seq)
                    pred = output.argmax(dim=-1).squeeze()
                    acc = (pred == target_seq).float().mean().item()

                total_loss += loss.item()
                total_acc += acc

        avg_loss = total_loss / len(test_texts)
        avg_acc = total_acc / len(test_texts)

        return {'loss': avg_loss, 'accuracy': avg_acc}

    async def run_federated_training(self):
        """Ejecutar entrenamiento federado completo."""
        print("🔥 FASE REAL-7: ENTRENAMIENTO FEDERADO LINGÜÍSTICO")
        print("=" * 60)
        print("Múltiples nodos colaborando en aprendizaje de lenguaje")
        print()

        print(f"✅ Sistema configurado: {len(self.nodes)} nodos, {self.config.rounds} rondas")
        for node in self.nodes:
            print(f"   - {node.node_id}: {len(node.local_texts)} textos locales")

        # Estado inicial
        global_weights = self.global_model.state_dict()
        initial_eval = self.evaluate_global_model()
        print("
📊 Estado inicial:"        print(".4f"        print(".2f"
        # Rondas de entrenamiento federado
        print("
🎯 INICIANDO ENTRENAMIENTO FEDERADO"        print("=" * 40)

        for round_num in range(1, self.config.rounds + 1):
            print(f"\n🎯 RONDA {round_num}/{self.config.rounds}")
            print("-" * 30)

            # Entrenamiento local en cada nodo
            print("🔄 Entrenamiento local...")
            node_updates = []

            for node in self.nodes:
                update = node.train_local(global_weights, self.config.local_epochs)
                node_updates.append(update)
                print(".4f"
            # Agregación federada
            print("📦 Agregando conocimiento...")
            new_global_weights = self.aggregate_weights(node_updates)
            self.global_model.load_state_dict(new_global_weights)

            # Evaluación global
            round_eval = self.evaluate_global_model()
            self.global_loss_history.append(round_eval['loss'])
            self.global_acc_history.append(round_eval['accuracy'])

            print("✅ Resultado de ronda:")
            print(".4f"            print(".2f"
            # Actualizar pesos para siguiente ronda
            global_weights = new_global_weights

            # Simular distribución de recompensas
            total_reward = 10.0 * len(self.nodes)
            reward_per_node = total_reward / len(self.nodes)
            print(".2f"
            await asyncio.sleep(0.1)  # Simular tiempo de procesamiento

        # Resultados finales
        await self._show_final_results(initial_eval)

    async def _show_final_results(self, initial_eval: Dict[str, float]):
        """Mostrar resultados finales."""
        print("\n" + "=" * 60)
        print("🎊 RESULTADOS FINALES - APRENDIZAJE FEDERADO LINGÜÍSTICO")
        print("=" * 60)

        if self.global_loss_history:
            final_loss = self.global_loss_history[-1]
            initial_loss = initial_eval['loss']
            improvement = (initial_loss - final_loss) / initial_loss * 100

            print("📊 MÉTRICAS GLOBALES:")
            print(".4f"            print(".4f"            print(".1f"
            # Mostrar progreso por ronda
            print("
📈 PROGRESO POR RONDA:"            for i, (loss, acc) in enumerate(zip(self.global_loss_history, self.global_acc_history)):
                print("4d"
            # Estadísticas de nodos
            print("
🎯 CONTRIBUCIÓN DE NODOS:"            total_samples = sum(len(node.local_data) for node in self.nodes)
            print(f"   📊 Total muestras procesadas: {total_samples}")
            print(f"   🔄 Total rondas de entrenamiento: {self.config.rounds}")
            print(f"   💰 Recompensas simuladas: {10.0 * len(self.nodes) * self.config.rounds:.2f} tokens")

            # Verificación de aprendizaje lingüístico federado
            learning_achieved = final_loss < initial_loss * 0.7 and improvement > 20

            if learning_achieved:
                print("
🎉 ¡APRENDIZAJE FEDERADO LINGÜÍSTICO CONFIRMADO!"                print("✅ Múltiples nodos colaboraron exitosamente")
                print("✅ Loss lingüística reducida significativamente")
                print("✅ Conocimiento distribuido fusionado correctamente")
                print("✅ Arquitectura federada validada")
                print("\n🏆 FASE REAL-7: ÉXITO TOTAL")
                print("💡 El sistema federado APRENDE LENGUAJE COLECTIVAMENTE")
                print("🚀 LISTO PARA ESCALADO GLOBAL CON EMPOORIOLM")
            else:
                print("\n⚠️ Aprendizaje limitado - revisar configuración")
        else:
            print("❌ No se completaron rondas de entrenamiento")


async def main():
    """Función principal de la demo."""
    print("🤖 DEMO STANDALONE: APRENDIZAJE FEDERADO LINGÜÍSTICO")
    print("Sin dependencias AILOOS - implementación pura PyTorch")
    print()

    # Configuración
    config = FederatedConfig(
        num_nodes=3,
        rounds=4,
        local_epochs=2
    )

    # Crear coordinador
    coordinator = FederatedCoordinator(config)

    # Crear nodos
    for i in range(config.num_nodes):
        node = FederatedLinguisticNode(f"linguistic_node_{i+1}")
        coordinator.add_node(node)

    # Ejecutar entrenamiento federado
    try:
        await coordinator.run_federated_training()
        return 0
    except Exception as e:
        print(f"❌ Error en demo: {e}")
        return 1


if __name__ == "__main__":
    exit(asyncio.run(main()))