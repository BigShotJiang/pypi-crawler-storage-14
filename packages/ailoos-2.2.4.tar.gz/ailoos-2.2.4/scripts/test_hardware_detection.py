#!/usr/bin/env python3
"""
Comprehensive test script for hardware detection system.
Tests role assignment, configuration generation, and integration for SCOUT and FORGE scenarios.
"""

import pytest
import unittest.mock as mock
import sys
from pathlib import Path
from typing import Dict, Any
from dataclasses import dataclass

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.core.node_roles import NodeRole, get_role_capabilities, validate_node_for_role
from ailoos.core.role_config import RoleConfigManager


@dataclass
class MockHardwareCapabilities:
    """Mock hardware capabilities for testing."""
    cpu_cores: int = 4
    cpu_frequency_mhz: float = 2500.0
    cpu_name: str = "Intel Core i5"
    total_memory_gb: float = 8.0
    available_memory_gb: float = 7.0
    total_storage_gb: float = 256.0
    available_storage_gb: float = 200.0
    gpu_available: bool = False
    gpu_count: int = 0
    gpu_name: str = ""
    gpu_memory_gb: float = 0.0
    cuda_available: bool = False
    cuda_version: str = ""
    performance_score: float = 1.5
    os: str = "Linux"
    architecture: str = "x86_64"
    python_version: str = "3.9.0"


class TestHardwareDetectionScenarios:
    """Test different hardware detection scenarios."""

    def setup_method(self):
        """Setup before each test."""
        self.mock_detector = None

    def teardown_method(self):
        """Cleanup after each test."""
        if self.mock_detector:
            self.mock_detector.stop()

    def mock_hardware_detector(self, capabilities: MockHardwareCapabilities):
        """Mock the HardwareDetector to return specific capabilities."""
        from scripts.hardware_detector import HardwareCapabilities, HardwareDetector

        # Create mock capabilities object
        mock_caps = HardwareCapabilities()
        for key, value in capabilities.__dict__.items():
            setattr(mock_caps, key, value)

        # Mock the detector
        self.mock_detector = mock.patch.object(HardwareDetector, 'detect_hardware', return_value=mock_caps)
        self.mock_detector.start()

        return mock_caps

    def test_scout_low_end_cpu_only(self):
        """Test SCOUT role assignment for low-end CPU-only system."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=2,
            total_memory_gb=4.0,
            available_memory_gb=3.5,
            performance_score=0.8
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "SCOUT"
        assert config["node_role"] == "SCOUT"
        assert config["inference_config"]["device"] == "cpu"
        assert config["inference_config"]["max_batch_size"] <= 4
        assert config["training_config"]["device"] == "cpu"
        assert config["resource_limits"]["cpu_limit"] == "2"

    def test_scout_mid_range_with_small_gpu(self):
        """Test SCOUT role for mid-range system with small GPU."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=6,
            total_memory_gb=16.0,
            available_memory_gb=14.0,
            gpu_available=True,
            gpu_count=1,
            gpu_name="NVIDIA GTX 1650",
            gpu_memory_gb=4.0,
            cuda_available=True,
            performance_score=2.2  # Below 2.5 threshold
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "SCOUT"
        assert config["node_role"] == "SCOUT"
        assert config["inference_config"]["device"] == "cpu"  # SCOUT uses CPU
        assert config["resource_limits"]["gpu_limit"] == 0

    def test_forge_high_end_with_large_gpu(self):
        """Test FORGE role for high-end system with large GPU."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=12,
            total_memory_gb=32.0,
            available_memory_gb=28.0,
            gpu_available=True,
            gpu_count=1,
            gpu_name="NVIDIA RTX 3080",
            gpu_memory_gb=12.0,
            cuda_available=True,
            performance_score=3.8
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "FORGE"
        assert config["node_role"] == "FORGE"
        assert config["inference_config"]["device"] == "cuda"
        assert config["inference_config"]["max_batch_size"] >= 8
        assert config["training_config"]["device"] == "cuda"
        assert config["resource_limits"]["gpu_limit"] == 1

    def test_forge_high_end_cpu_only(self):
        """Test FORGE role for high-end CPU-only system."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=16,
            total_memory_gb=64.0,
            available_memory_gb=60.0,
            performance_score=3.0  # Above 2.5 threshold
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "FORGE"
        assert config["node_role"] == "FORGE"
        assert config["inference_config"]["device"] == "cpu"
        assert config["inference_config"]["max_batch_size"] >= 8

    def test_edge_case_very_low_cpu(self):
        """Test edge case with very low CPU cores."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=1,
            total_memory_gb=2.0,
            available_memory_gb=1.5,
            performance_score=0.3
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "SCOUT"
        assert config["inference_config"]["max_batch_size"] == 1
        assert config["resource_limits"]["cpu_limit"] == "1"

    def test_edge_case_high_memory_no_gpu(self):
        """Test edge case with high memory but no GPU."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=8,
            total_memory_gb=128.0,
            available_memory_gb=120.0,
            performance_score=2.8  # Above threshold due to memory
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "FORGE"
        assert config["inference_config"]["device"] == "cpu"
        assert config["inference_config"]["memory_limit_gb"] >= 64.0

    def test_apple_silicon_mps(self):
        """Test Apple Silicon with MPS support."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=8,
            total_memory_gb=16.0,
            available_memory_gb=14.0,
            gpu_available=True,
            gpu_name="Apple Silicon GPU",
            performance_score=2.6
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "FORGE"
        assert config["inference_config"]["device"] == "cpu"  # MPS not detected by torch check

    def test_multiple_gpus(self):
        """Test system with multiple GPUs."""
        capabilities = MockHardwareCapabilities(
            cpu_cores=16,
            total_memory_gb=64.0,
            available_memory_gb=60.0,
            gpu_available=True,
            gpu_count=2,
            gpu_name="NVIDIA RTX 3090",
            gpu_memory_gb=24.0,
            cuda_available=True,
            performance_score=4.5
        )

        mock_caps = self.mock_hardware_detector(capabilities)

        from scripts.hardware_detector import HardwareDetector
        detector = HardwareDetector()
        detected_caps = detector.detect_hardware()
        role = detector.assign_role(detected_caps)
        config = detector.generate_config(role, detected_caps)

        assert role == "FORGE"
        assert config["resource_limits"]["gpu_limit"] == 2
        assert config["optimization_settings"]["tensor_parallel_size"] >= 2


class TestRoleConfigIntegration:
    """Test integration with RoleConfigManager."""

    def test_role_config_manager_integration(self):
        """Test full integration with RoleConfigManager."""
        # Mock hardware detector in RoleConfigManager
        capabilities = MockHardwareCapabilities(
            cpu_cores=8,
            total_memory_gb=16.0,
            gpu_available=True,
            gpu_memory_gb=8.0,
            cuda_available=True,
            performance_score=3.0
        )

        with mock.patch('ailoos.core.role_config.HardwareDetector') as mock_hd_class:
            mock_detector = mock.Mock()
            mock_hd_class.return_value = mock_detector

            # Create mock capabilities object
            from scripts.hardware_detector import HardwareCapabilities
            mock_caps = HardwareCapabilities()
            for key, value in capabilities.__dict__.items():
                setattr(mock_caps, key, value)

            mock_detector.detect_hardware.return_value = mock_caps
            mock_detector.assign_role.return_value = "FORGE"
            mock_detector.generate_config.return_value = {
                "node_role": "FORGE",
                "inference_config": {"device": "cuda", "max_batch_size": 16},
                "training_config": {"device": "cuda", "batch_size": 16},
                "resource_limits": {"cpu_limit": "8", "memory_limit": "16Gi", "gpu_limit": 1},
                "optimization_settings": {"enable_caching": True}
            }

            manager = RoleConfigManager()
            hardware_config = manager.load_hardware_config()
            merged_config = manager.apply_role_settings()

            assert hardware_config["assigned_role"] == "FORGE"
            assert merged_config["role"]["name"] == "forge"
            assert merged_config["inference"]["device"] == "cuda"

    def test_role_validation(self):
        """Test role validation against hardware requirements."""
        # Test SCOUT validation - SCOUT max_memory_gb=8, so needs >= 8*0.8=6.4
        scout_caps = get_role_capabilities(NodeRole.SCOUT)
        scout_hardware = {
            "memory_gb": 7.0,  # Above max_memory_gb * 0.8 = 6.4
            "cpu_cores": 4,    # Meets max_cpu_cores = 4
            "gpu": "NVIDIA GTX 1050"  # Has GPU
        }
        assert validate_node_for_role(scout_hardware, NodeRole.SCOUT)

        # Test FORGE validation - FORGE max_memory_gb=64, needs >=64*0.8=51.2
        forge_caps = get_role_capabilities(NodeRole.FORGE)
        forge_hardware = {
            "memory_gb": 60.0,  # Above max_memory_gb * 0.8 = 51.2
            "cpu_cores": 16,    # Meets max_cpu_cores = 16
            "gpu": "NVIDIA RTX 3080"
        }
        assert validate_node_for_role(forge_hardware, NodeRole.FORGE)


class TestConfigurationGeneration:
    """Test configuration generation logic."""

    def test_scout_config_details(self):
        """Test detailed SCOUT configuration."""
        from scripts.hardware_detector import HardwareDetector, HardwareCapabilities

        caps = HardwareCapabilities()
        caps.cpu_cores = 4
        caps.total_memory_gb = 8.0
        caps.gpu_available = False
        caps.performance_score = 1.2

        detector = HardwareDetector()
        config = detector.generate_config("SCOUT", caps)

        assert config["inference_config"]["device"] == "cpu"
        assert config["inference_config"]["max_batch_size"] == 4  # min(4, cpu_cores)
        assert config["inference_config"]["memory_limit_gb"] == 4.0  # min(4.0, total_memory * 0.5)
        assert config["inference_config"]["precision"] == "fp32"
        assert not config["inference_config"]["enable_quantization"]
        assert config["inference_config"]["max_concurrent_requests"] == 2

        assert config["training_config"]["device"] == "cpu"
        assert config["training_config"]["batch_size"] == 1
        assert not config["training_config"]["enable_mixed_precision"]

        assert config["resource_limits"]["cpu_limit"] == "2"  # str(min(cpu_cores, 2))
        assert config["resource_limits"]["memory_limit"] == "2Gi"
        assert config["resource_limits"]["gpu_limit"] == 0

    def test_forge_config_details(self):
        """Test detailed FORGE configuration."""
        from scripts.hardware_detector import HardwareDetector, HardwareCapabilities

        caps = HardwareCapabilities()
        caps.cpu_cores = 16
        caps.total_memory_gb = 64.0
        caps.gpu_available = True
        caps.gpu_count = 1
        caps.gpu_memory_gb = 16.0
        caps.cuda_available = True
        caps.performance_score = 4.0

        detector = HardwareDetector()
        config = detector.generate_config("FORGE", caps)

        assert config["inference_config"]["device"] == "cuda"
        assert config["inference_config"]["max_batch_size"] == 32  # Since gpu_memory >=16, use 32
        assert config["inference_config"]["memory_limit_gb"] == 12.8  # gpu_memory * 0.8
        assert config["inference_config"]["precision"] == "fp16"
        assert config["inference_config"]["enable_quantization"]
        assert config["inference_config"]["max_concurrent_requests"] == 10

        assert config["training_config"]["device"] == "cuda"
        assert config["training_config"]["batch_size"] == 32
        assert config["training_config"]["enable_mixed_precision"]

        assert config["resource_limits"]["cpu_limit"] == "16"
        assert config["resource_limits"]["memory_limit"] == "64Gi"
        assert config["resource_limits"]["gpu_limit"] == 1


class TestPerformanceScoreCalculation:
    """Test performance score calculation."""

    def test_performance_score_components(self):
        """Test individual components of performance score."""
        from scripts.hardware_detector import HardwareDetector, HardwareCapabilities

        # Test CPU score
        caps = HardwareCapabilities()
        caps.cpu_cores = 8  # Should give score of min(8/16, 1.0) = 0.5
        caps.total_memory_gb = 8  # min(8/32, 1.0) = 0.25
        caps.gpu_available = False

        detector = HardwareDetector()
        detector.capabilities = caps
        detector._calculate_performance_score()

        expected_cpu_score = min(8 / 16.0, 1.0)  # 0.5
        expected_mem_score = min(8 / 32.0, 1.0)  # 0.25
        expected_total = expected_cpu_score + expected_mem_score  # 0.75

        assert abs(caps.performance_score - expected_total) < 0.01

    def test_gpu_score_bonus(self):
        """Test GPU score bonuses."""
        from scripts.hardware_detector import HardwareDetector, HardwareCapabilities

        caps = HardwareCapabilities()
        caps.cpu_cores = 4
        caps.total_memory_gb = 8
        caps.gpu_available = True
        caps.gpu_memory_gb = 12.0  # High-end GPU
        caps.gpu_count = 1

        detector = HardwareDetector()
        detector.capabilities = caps
        detector._calculate_performance_score()

        # Should get base scores + GPU score
        # GPU score = 2.0 (for >=8GB) * (min(gpu_count,4)/4) = 2.0 * (1/4) = 0.5
        expected_cpu = min(4 / 16.0, 1.0)  # 0.25
        expected_mem = min(8 / 32.0, 1.0)  # 0.25
        expected_gpu = 2.0 * (min(1, 4) / 4.0)  # 0.5
        expected_total = expected_cpu + expected_mem + expected_gpu  # 1.0

        assert abs(caps.performance_score - expected_total) < 0.01


if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])