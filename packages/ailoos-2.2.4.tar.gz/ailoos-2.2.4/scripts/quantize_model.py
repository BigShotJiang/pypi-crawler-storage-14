#!/usr/bin/env python3
"""
Script para cuantizar modelos EmpoorioLM usando Bitsandbytes.

Uso:
    python scripts/quantize_model.py --model_path ./models/empoorio_lm/v1.0.0 --output_path ./models/empoorio_lm/v1.0.0-quantized-int8 --quantization_type int8

Opciones:
    --model_path: Ruta del modelo original
    --output_path: Ruta donde guardar el modelo cuantizado
    --quantization_type: Tipo de cuantización (int8, int4)
    --double_quant: Usar double quantization para INT4 (default: True)
    --validate: Validar cuantización después de completar (default: False)
"""

import argparse
import sys
import os
from pathlib import Path

# Añadir src al path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ailoos.inference.quantization import quantize_empoorio_model, ModelQuantizer
from transformers import AutoTokenizer


def main():
    parser = argparse.ArgumentParser(description="Cuantizar modelo EmpoorioLM")
    parser.add_argument("--model_path", required=True, help="Ruta del modelo original")
    parser.add_argument("--output_path", required=True, help="Ruta para guardar modelo cuantizado")
    parser.add_argument("--quantization_type", default="int8", choices=["int8", "int4"],
                       help="Tipo de cuantización")
    parser.add_argument("--double_quant", action="store_true", default=True,
                       help="Usar double quantization para INT4")
    parser.add_argument("--validate", action="store_true",
                       help="Validar cuantización después de completar")
    parser.add_argument("--test_prompts", nargs="+", default=[
        "¿Cuál es la capital de España?",
        "Explica brevemente qué es la inteligencia artificial",
        "Escribe un haiku sobre el mar"
    ], help="Prompts para validación")

    args = parser.parse_args()

    print("🔧 Iniciando cuantización del modelo EmpoorioLM")
    print(f"   Modelo original: {args.model_path}")
    print(f"   Modelo cuantizado: {args.output_path}")
    print(f"   Tipo: {args.quantization_type}")
    print(f"   Double quant: {args.double_quant}")
    print(f"   Validar: {args.validate}")

    try:
        # Cuantizar modelo
        print("\n📦 Cuantizando modelo...")
        result = quantize_empoorio_model(
            model_path=args.model_path,
            output_path=args.output_path,
            quantization_type=args.quantization_type,
            double_quant=args.double_quant
        )

        print("✅ Cuantización completada exitosamente!")
        print(f"   Memoria usada: {result['memory_usage']}")

        # Validar si se solicita
        if args.validate:
            print("\n🔍 Validando cuantización...")

            # Cargar tokenizer para validación
            tokenizer_name = "gpt2"  # Asumir GPT-2 por defecto
            tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

            # Cargar modelos para comparación
            quantizer = ModelQuantizer()

            # Cargar modelo original (temporalmente)
            print("   Cargando modelo original para comparación...")
            from ailoos.models.empoorio_lm import EmpoorioLM
            original_model = EmpoorioLM.from_pretrained(args.model_path)
            original_model.eval()

            # Cargar modelo cuantizado
            print("   Cargando modelo cuantizado...")
            quantized_model = EmpoorioLM.from_pretrained(args.output_path)
            quantized_model.eval()

            # Validar
            validation_results = quantizer.validate_quantization(
                original_model=original_model,
                quantized_model=quantized_model,
                test_prompts=args.test_prompts,
                tokenizer=tokenizer
            )

            print("✅ Validación completada:")
            print(f"   Prompts probados: {len(validation_results['generation_quality'])}")

            for i, quality in enumerate(validation_results['generation_quality']):
                print(f"   Prompt {i+1}: Similitud = {quality['similarity_score']:.3f}")

        print(f"\n🎉 Proceso completado! Modelo guardado en: {args.output_path}")

    except Exception as e:
        print(f"❌ Error durante la cuantización: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()