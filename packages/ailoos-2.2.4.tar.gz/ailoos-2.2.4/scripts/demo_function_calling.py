#!/usr/bin/env python3
"""
Demo de Function Calling con EmpoorioLM
Muestra cómo EmpoorioLM puede usar herramientas externas para resolver consultas.
"""

import asyncio
import logging
from pathlib import Path
import sys

# Añadir el directorio raíz al path
sys.path.append(str(Path(__file__).parent.parent))

from models.empoorio_lm.config import get_config_for_model_size
from models.empoorio_lm.model import EmpoorioLM
from src.ailoos.tools import (
    create_function_calling_processor,
    register_builtin_tools,
    tool_registry
)

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def setup_system():
    """Configura el sistema completo de function calling."""
    logger.info("🚀 Configurando sistema de Function Calling...")

    # 1. Configurar modelo EmpoorioLM con function calling habilitado
    config = get_config_for_model_size("small", use_moe=False)
    config.use_function_calling = True
    config.max_length = 512  # Respuestas más cortas para demos

    logger.info("🤖 Inicializando EmpoorioLM...")
    model = EmpoorioLM(config)

    # 2. Registrar herramientas built-in
    logger.info("🔧 Registrando herramientas built-in...")
    await register_builtin_tools(tool_registry)

    # 3. Crear procesador de function calling
    logger.info("⚙️ Inicializando procesador de function calling...")
    processor = await create_function_calling_processor()
    processor.set_tool_tokens(config.tool_call_token, config.tool_call_end_token)

    logger.info("✅ Sistema configurado exitosamente!")
    return model, processor


async def demo_calculator(model, processor):
    """Demo de calculadora."""
    print("\n" + "="*60)
    print("🧮 DEMO: Calculadora")
    print("="*60)

    query = "Calcula cuánto es 2349 multiplicado por 1293"
    print(f"Usuario: {query}")

    # Crear prompt con información de herramientas
    prompt = processor.create_tool_calling_prompt(query)

    # Generar respuesta (en producción, esto vendría del modelo entrenado)
    # Para demo, simulamos una respuesta que incluye tool call
    simulated_response = f"""Para calcular 2349 × 1293, necesito usar la calculadora.

<tool_call>{{"name": "calculator", "parameters": {{"operation": "*", "x": 2349, "y": 1293}}}}</tool_call>"""

    print(f"EmpoorioLM: {simulated_response}")

    # Procesar la respuesta con tools
    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")


async def demo_datetime(model, processor):
    """Demo de fecha y hora."""
    print("\n" + "="*60)
    print("📅 DEMO: Fecha y Hora")
    print("="*60)

    query = "¿Qué día es hoy y qué hora es?"
    print(f"Usuario: {query}")

    prompt = processor.create_tool_calling_prompt(query)

    # Simular respuesta con tool call
    simulated_response = f"""El usuario pregunta por la fecha y hora actual. Necesito consultar la herramienta de datetime.

<tool_call>{{"name": "datetime", "parameters": {{"operation": "now"}}}}</tool_call>
<tool_call>{{"name": "datetime", "parameters": {{"operation": "today"}}}}</tool_call>
<tool_call>{{"name": "datetime", "parameters": {{"operation": "weekday"}}}}</tool_call>"""

    print(f"EmpoorioLM: {simulated_response}")

    # Procesar respuesta
    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")


async def demo_web_search(model, processor):
    """Demo de búsqueda web."""
    print("\n" + "="*60)
    print("🌐 DEMO: Búsqueda Web")
    print("="*60)

    query = "¿Cuál es el precio actual de Bitcoin?"
    print(f"Usuario: {query}")

    prompt = processor.create_tool_calling_prompt(query)

    # Simular respuesta con tool call
    simulated_response = f"""Para obtener el precio actual de Bitcoin, necesito buscar en la web información actualizada.

<tool_call>{{"name": "web_search", "parameters": {{"query": "bitcoin price USD", "max_results": 3}}}}</tool_call>"""

    print(f"EmpoorioLM: {simulated_response}")

    # Procesar respuesta
    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")


async def demo_multiple_tools(model, processor):
    """Demo usando múltiples herramientas en una sola respuesta."""
    print("\n" + "="*60)
    print("🔧 DEMO: Múltiples Herramientas")
    print("="*60)

    query = "Calcula la raíz cuadrada de 144 y dime qué día es hoy"
    print(f"Usuario: {query}")

    prompt = processor.create_tool_calling_prompt(query)

    # Simular respuesta con múltiples tool calls
    simulated_response = f"""El usuario pide dos cosas diferentes:
1. Calcular la raíz cuadrada de 144
2. Saber qué día es hoy

Necesito usar dos herramientas diferentes.

<tool_call>{{"name": "calculator", "parameters": {{"operation": "sqrt", "x": 144}}}}</tool_call>

<tool_call>{{"name": "datetime", "parameters": {{"operation": "today"}}}}</tool_call>"""

    print(f"EmpoorioLM: {simulated_response}")

    # Procesar respuesta
    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")


async def demo_error_handling(model, processor):
    """Demo de manejo de errores."""
    print("\n" + "="*60)
    print("❌ DEMO: Manejo de Errores")
    print("="*60)

    query = "Calcula la raíz cuadrada de -1"
    print(f"Usuario: {query}")

    prompt = processor.create_tool_calling_prompt(query)

    # Simular respuesta con tool call que fallará
    simulated_response = f"""El usuario pide la raíz cuadrada de un número negativo, lo cual es matemáticamente inválido.

<tool_call>{{"name": "calculator", "parameters": {{"operation": "sqrt", "x": -1}}}}</tool_call>"""

    print(f"EmpoorioLM: {simulated_response}")

    # Procesar respuesta
    result = await processor.process_response_with_tools(simulated_response)

    print(f"\nResultado final: {result.final_response}")


async def show_system_info(processor):
    """Muestra información del sistema."""
    print("\n" + "="*60)
    print("ℹ️ INFORMACIÓN DEL SISTEMA")
    print("="*60)

    # Mostrar herramientas disponibles
    tools = processor.registry.list_tools()
    print(f"🔧 Herramientas registradas: {len(tools)}")

    for tool in tools:
        print(f"  • {tool.name}: {tool.description}")
        print(f"    Categoría: {tool.category}")
        print(f"    Parámetros: {list(tool.parameters.keys())}")

    print(f"\n📊 Métricas del sistema:")
    metrics = processor.registry.get_metrics()
    for tool_name, tool_metrics in metrics.items():
        calls = tool_metrics.get('calls', 0)
        successes = tool_metrics.get('successes', 0)
        failures = tool_metrics.get('failures', 0)
        print(f"  • {tool_name}: {calls} llamadas ({successes} exitosas, {failures} fallidas)")


async def main():
    """Función principal de la demo."""
    print("🎯 DEMO: Function Calling con EmpoorioLM")
    print("Este demo muestra cómo EmpoorioLM puede usar herramientas externas.")
    print("Nota: En producción, el modelo generaría las tool calls automáticamente.")

    try:
        # Configurar sistema
        model, processor = await setup_system()

        # Mostrar información del sistema
        await show_system_info(processor)

        # Ejecutar demos
        await demo_calculator(model, processor)
        await demo_datetime(model, processor)
        await demo_web_search(model, processor)
        await demo_multiple_tools(model, processor)
        await demo_error_handling(model, processor)

        print("\n" + "="*60)
        print("🎉 ¡Demo completada exitosamente!")
        print("="*60)
        print("\nResumen de lo logrado:")
        print("✅ Sistema de herramientas configurado")
        print("✅ Function calling operativo")
        print("✅ Ejecución segura de tools")
        print("✅ Manejo de errores robusto")
        print("✅ Procesamiento de múltiples tools")
        print("\n🚀 EmpoorioLM ahora puede interactuar con el mundo real!")

    except Exception as e:
        logger.error(f"Error en demo: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)