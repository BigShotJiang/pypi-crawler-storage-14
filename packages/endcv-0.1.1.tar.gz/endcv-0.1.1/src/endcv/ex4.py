EX4 = r"""print("4.1) Compute the absolute difference between two images using OpenCV.")

import cv2

M1 = cv2.imread(r'D:\Studies\Sem-7\Image Processing and Computer Vision\Model\images\image1.jpg', cv2.IMREAD_GRAYSCALE)
M2 = cv2.imread(r'D:\Studies\Sem-7\Image Processing and Computer Vision\Model\images\image2.jpg', cv2.IMREAD_GRAYSCALE)

if M1 is None or M2 is None:
    print("Error: One of the images was not found!")
    exit()

M2 = cv2.resize(M2, (M1.shape[1], M1.shape[0]))
Out = cv2.absdiff(M1, M2)

cv2.imshow('Absolute Difference', Out)
cv2.waitKey(0)
cv2.destroyAllWindows()

print("\n\n========== HOG FEATURE EXTRACTION ==========")

import cv2
import numpy as np
from skimage.feature import hog
import matplotlib.pyplot as plt

img_path = r'D:\Studies\Sem-7\Image Processing and Computer Vision\Model\images\image1.jpg'
img = cv2.imread(img_path)

if img is None:
    raise FileNotFoundError("Image not found! Check the file path.")

img = cv2.resize(img, (64, 128))
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray = gray.astype(np.float32) / 255.0

gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=1)
gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=1)

mag, angle = cv2.cartToPolar(gx, gy, angleInDegrees=True)

features, hog_image = hog(gray,
                          orientations=9,
                          pixels_per_cell=(8, 8),
                          cells_per_block=(2, 2),
                          block_norm='L2-Hys',
                          visualize=True)

np.set_printoptions(precision=3, suppress=True)

print("\n🟢 Gradient X (gx):\n", gx)
print("\n🟢 Gradient Y (gy):\n", gy)
print("\n🟢 Magnitude:\n", mag)
print("\n🟢 Orientation (degrees):\n", angle)
print("\n🟢 HOG Feature Vector (first 100 values):\n", features[:100])
print("\n✅ Total HOG feature length:", len(features))

plt.figure(figsize=(10,6))
plt.subplot(2,2,1), plt.imshow(gray, cmap='gray'), plt.title('Grayscale Image')
plt.subplot(2,2,2), plt.imshow(mag, cmap='gray'), plt.title('Gradient Magnitude')
plt.subplot(2,2,3), plt.imshow(angle, cmap='hsv'), plt.title('Gradient Orientation')
plt.subplot(2,2,4), plt.imshow(hog_image, cmap='gray'), plt.title('HOG Visualization')
plt.tight_layout()
plt.show()
"""
def get4():
    print(EX4)