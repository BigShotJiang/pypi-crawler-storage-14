EX5 = r"""print("5) Fruit Classification with and without Data Augmentation")

import os
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras import layers, models


DATASET_ROOT = "/kaggle/input/fruits-classification/Fruits Classification"   
# DATASET_ROOT = "/content/Fruits Classification"                           

train_path = os.path.join(DATASET_ROOT, "train")
valid_path = os.path.join(DATASET_ROOT, "valid")
test_path  = os.path.join(DATASET_ROOT, "test")

IMG_SIZE = 150
BATCH = 32

train_no_aug_gen = ImageDataGenerator(rescale=1./255)

train_aug_gen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=40,
    horizontal_flip=True,
    vertical_flip=True,
    brightness_range=[0.5, 1.5],
    shear_range=0.2,
    zoom_range=0.2
)

val_test_gen = ImageDataGenerator(rescale=1./255)

train_no_aug = train_no_aug_gen.flow_from_directory(
    train_path, target_size=(IMG_SIZE,IMG_SIZE), batch_size=BATCH, class_mode="categorical"
)

train_aug = train_aug_gen.flow_from_directory(
    train_path, target_size=(IMG_SIZE,IMG_SIZE), batch_size=BATCH, class_mode="categorical"
)

valid_data = val_test_gen.flow_from_directory(
    valid_path, target_size=(IMG_SIZE,IMG_SIZE), batch_size=BATCH, class_mode="categorical"
)

test_data = val_test_gen.flow_from_directory(
    test_path, target_size=(IMG_SIZE,IMG_SIZE), batch_size=BATCH, class_mode="categorical"
)

print("\nTraining Images:", train_no_aug.samples)
print("Validation Images:", valid_data.samples)
print("Testing Images:", test_data.samples)

batch_x, batch_y = next(train_no_aug)
class_names = list(train_no_aug.class_indices.keys())

plt.figure(figsize=(12,4))
for i in range(5):
    plt.subplot(1,5,i+1)
    plt.imshow(batch_x[i])
    plt.title(class_names[batch_y[i].argmax()])
    plt.axis("off")
plt.show()

def create_cnn(num_classes):

    model = models.Sequential([
        layers.Conv2D(32,(3,3),activation='relu', input_shape=(IMG_SIZE,IMG_SIZE,3)),
        layers.MaxPooling2D(),

        layers.Conv2D(64,(3,3),activation='relu'),
        layers.MaxPooling2D(),

        layers.Conv2D(128,(3,3),activation='relu'),
        layers.GlobalAveragePooling2D(),

        layers.Dense(128, activation='relu'),
        layers.Dense(num_classes, activation='softmax')
    ])

    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    return model

num_classes = len(class_names)

print("\nTraining CNN WITHOUT augmentation…")
cnn_no_aug = create_cnn(num_classes)

history_no_aug = cnn_no_aug.fit(
    train_no_aug, validation_data=valid_data, epochs=10
)

test_loss1, test_acc1 = cnn_no_aug.evaluate(test_data)
print(f"\nTest Accuracy WITHOUT Augmentation: {test_acc1*100:.2f}%")

print("\nTraining CNN WITH augmentation…")
cnn_aug = create_cnn(num_classes)

history_aug = cnn_aug.fit(
    train_aug, validation_data=valid_data, epochs=10
)

test_loss2, test_acc2 = cnn_aug.evaluate(test_data)
print(f"\nTest Accuracy WITH Augmentation: {test_acc2*100:.2f}%")

plt.figure(figsize=(10,5))
plt.plot(history_no_aug.history['val_accuracy'], label="No Augmentation")
plt.plot(history_aug.history['val_accuracy'], label="With Augmentation")
plt.title("Validation Accuracy Comparison")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.legend()
plt.show()

print("\n===================== FINAL ACCURACY COMPARISON =====================")
print(f"CNN WITHOUT Augmentation Accuracy : {test_acc1*100:.2f}%")
print(f"CNN WITH Augmentation Accuracy    : {test_acc2*100:.2f}%")
print("======================================================================")
"""
def get5():
    print(EX5)