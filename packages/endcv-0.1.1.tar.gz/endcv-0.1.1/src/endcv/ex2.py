EX2 =r"""print("2) Image Classification on CIFAR-10 and MNIST Datasets using ANN and CNN Models.")

import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import numpy as np

print("========== CIFAR-10 DATASET ==========")

(x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()

print("Training samples:", x_train.shape[0])
print("Testing samples:", x_test.shape[0])

class_names = ['Airplane','Automobile','Bird','Cat','Deer',
               'Dog','Frog','Horse','Ship','Truck']

plt.figure(figsize=(10,5))
for i in range(5):
    plt.subplot(1,5,i+1)
    plt.imshow(x_train[i])
    plt.title(class_names[int(y_train[i])])
    plt.axis('off')
plt.show()

x_train_norm = x_train / 255.0
x_test_norm = x_test / 255.0

ann_model = models.Sequential([
    layers.Flatten(input_shape=(32,32,3)),
    layers.Dense(256, activation='relu'),
    layers.Dense(10, activation='softmax')
])

ann_model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])

print("\nTraining ANN (CIFAR-10)...")
ann_history = ann_model.fit(x_train_norm, y_train, epochs=10, validation_split=0.2)

ann_test_loss, ann_test_acc = ann_model.evaluate(x_test_norm, y_test)
print(f"ANN Test Accuracy (CIFAR-10): {ann_test_acc * 100:.2f}%")

cnn_model = models.Sequential([
    layers.Conv2D(32,(3,3),activation='relu',input_shape=(32,32,3)),
    layers.MaxPooling2D(2,2),

    layers.Conv2D(64,(3,3),activation='relu'),
    layers.MaxPooling2D(2,2),

    layers.Conv2D(128,(3,3),activation='relu'),
    layers.GlobalAveragePooling2D(),

    layers.Dense(128,activation='relu'),
    layers.Dense(10,activation='softmax')
])

cnn_model.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])

print("\nTraining CNN (CIFAR-10)...")
cnn_history = cnn_model.fit(x_train_norm, y_train, epochs=10, validation_split=0.2)

cnn_test_loss, cnn_test_acc = cnn_model.evaluate(x_test_norm, y_test)
print(f"CNN Test Accuracy (CIFAR-10): {cnn_test_acc * 100:.2f}%")

print("\n\n========== MNIST DIGIT DATASET ==========")

(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()


print("Training samples:", x_train.shape[0])
print("Testing samples:", x_test.shape[0])

plt.figure(figsize=(10,4))
for i in range(5):
    plt.subplot(1,5,i+1)
    plt.imshow(x_train[i], cmap='gray')
    plt.title(str(y_train[i]))
    plt.axis('off')
plt.show()

x_train_norm = x_train / 255.0
x_test_norm = x_test / 255.0

x_train_cnn = x_train_norm.reshape(-1, 28, 28, 1)
x_test_cnn  = x_test_norm.reshape(-1, 28, 28, 1)

mnist_ann = models.Sequential([
    layers.Flatten(input_shape=(28,28)),
    layers.Dense(256, activation='relu'),
    layers.Dense(10, activation='softmax')
])

mnist_ann.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])

print("\nTraining ANN (MNIST)...")
mnist_ann.fit(x_train_norm, y_train, epochs=10, validation_split=0.2)

mnist_ann_loss, mnist_ann_acc = mnist_ann.evaluate(x_test_norm, y_test)
print(f"ANN Test Accuracy (MNIST): {mnist_ann_acc * 100:.2f}%")

mnist_cnn = models.Sequential([
    layers.Conv2D(32,(3,3),activation='relu', input_shape=(28,28,1)),
    layers.MaxPooling2D(2,2),

    layers.Conv2D(64,(3,3),activation='relu'),
    layers.MaxPooling2D(2,2),

    layers.GlobalAveragePooling2D(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')
])

mnist_cnn.compile(optimizer='adam',
                  loss='sparse_categorical_crossentropy',
                  metrics=['accuracy'])

print("\nTraining CNN (MNIST)...")
mnist_cnn.fit(x_train_cnn, y_train, epochs=10, validation_split=0.2)

mnist_cnn_loss, mnist_cnn_acc = mnist_cnn.evaluate(x_test_cnn, y_test)
print(f"CNN Test Accuracy (MNIST): {mnist_cnn_acc * 100:.2f}%")
"""
def get2():
    print(EX2)