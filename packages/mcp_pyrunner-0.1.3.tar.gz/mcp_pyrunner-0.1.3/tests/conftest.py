"""Pytest configuration"""
import pytest
