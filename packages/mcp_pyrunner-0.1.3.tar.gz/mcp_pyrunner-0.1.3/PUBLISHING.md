# Publishing to PyPI

Guide to publish `mcp-codemode` to PyPI so users can install with `uvx mcp-codemode`.

## Prerequisites

### 1. Create PyPI Account

1. Go to [https://pypi.org/account/register/](https://pypi.org/account/register/)
2. Create your account
3. Verify your email

### 2. Create TestPyPI Account (Optional but Recommended)

1. Go to [https://test.pypi.org/account/register/](https://test.pypi.org/account/register/)
2. Create account (separate from PyPI)
3. Use this to test publishing before going to production PyPI

### 3. Create API Tokens

**For PyPI:**
1. Log into [https://pypi.org](https://pypi.org)
2. Go to Account Settings → API tokens
3. Click "Add API token"
4. Name: `mcp-codemode-upload`
5. Scope: "Entire account" (for first publish) or "Project: mcp-codemode" (after first publish)
6. Copy the token (starts with `pypi-`)

**For TestPyPI (optional):**
1. Log into [https://test.pypi.org](https://test.pypi.org)
2. Repeat same steps
3. Copy the token (starts with `pypi-`)

### 4. Configure Tokens Locally

```bash
# Create/edit ~/.pypirc
cat > ~/.pypirc << 'EOF'
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-YOUR-PYPI-TOKEN-HERE

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-YOUR-TESTPYPI-TOKEN-HERE
EOF

# Secure the file
chmod 600 ~/.pypirc
```

## Publishing Process

### Option 1: Using UV (Recommended)

```bash
# 1. Make sure you're on main branch with latest changes
git checkout main
git pull origin main

# 2. Clean any previous builds
rm -rf dist/ build/ *.egg-info

# 3. Build the package
uv build

# 4. Check the build
ls -lh dist/

# You should see:
# - mcp_codemode-0.1.0-py3-none-any.whl
# - mcp_codemode-0.1.0.tar.gz

# 5. Test the package locally (optional)
uv pip install dist/mcp_codemode-0.1.0-py3-none-any.whl --force-reinstall

# 6. Publish to TestPyPI first (recommended)
uv publish --publish-url https://test.pypi.org/legacy/

# 7. Test install from TestPyPI
uvx --index-url https://test.pypi.org/simple/ mcp-codemode

# 8. If everything works, publish to real PyPI
uv publish
```

### Option 2: Using Twine (Alternative)

```bash
# 1. Install twine
uv pip install twine

# 2. Build
uv build

# 3. Check the package
twine check dist/*

# 4. Upload to TestPyPI (optional)
twine upload --repository testpypi dist/*

# 5. Upload to PyPI
twine upload dist/*
```

## Verification

After publishing to PyPI:

```bash
# Wait 1-2 minutes for PyPI to index

# Test installation
uvx mcp-codemode --version

# Should output: mcp-codemode 0.1.0
```

## Updating Version

When you want to release a new version:

1. **Update version in `pyproject.toml`:**
   ```toml
   [project]
   version = "0.2.0"  # Increment version
   ```

2. **Update version in `src/mcp_codemode/__init__.py`:**
   ```python
   __version__ = "0.2.0"
   ```

3. **Commit the version bump:**
   ```bash
   git add pyproject.toml src/mcp_codemode/__init__.py
   git commit -m "chore: Bump version to 0.2.0"
   git tag v0.2.0
   git push origin main --tags
   ```

4. **Rebuild and publish:**
   ```bash
   rm -rf dist/
   uv build
   uv publish
   ```

## Version Naming Convention

Follow [Semantic Versioning](https://semver.org/):

- **0.1.0** → Initial release
- **0.1.1** → Bug fixes
- **0.2.0** → New features (streaming output)
- **1.0.0** → First stable release

## Common Issues

### "File already exists"

You can't re-upload the same version. Increment the version number.

### "Invalid authentication credentials"

Check your `~/.pypirc` token or use `uv publish --token pypi-YOUR-TOKEN`.

### "Package name already taken"

Someone else registered `mcp-codemode`. You'll need to:
1. Choose a different name (e.g., `mcp-codemode-anas`)
2. Update `pyproject.toml` name field
3. Or request transfer if it's abandoned

## GitHub Actions (Optional Automation)

Create `.github/workflows/publish.yml` for automatic publishing on tags:

```yaml
name: Publish to PyPI

on:
  push:
    tags:
      - 'v*'

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install uv
        uses: astral-sh/setup-uv@v2

      - name: Build package
        run: uv build

      - name: Publish to PyPI
        env:
          UV_PUBLISH_TOKEN: ${{ secrets.PYPI_TOKEN }}
        run: uv publish
```

Add your PyPI token to GitHub:
1. Go to repo Settings → Secrets → Actions
2. Add secret: `PYPI_TOKEN` = your PyPI token

Then to publish:
```bash
git tag v0.1.0
git push origin v0.1.0
# GitHub Actions will automatically build and publish
```

## Quick Reference

```bash
# Test build locally
uv build

# Publish to TestPyPI
uv publish --publish-url https://test.pypi.org/legacy/

# Publish to PyPI
uv publish

# Or with explicit token
uv publish --token pypi-YOUR-TOKEN-HERE
```

## Next Steps After Publishing

1. Update README.md to remove "(when published)" note
2. Test `uvx mcp-codemode` from fresh machine
3. Update configurations to use `uvx` instead of `uv run --directory`
4. Announce on:
   - Twitter/X
   - Reddit (r/Python, r/LocalLLaMA)
   - Hacker News
   - Model Context Protocol community
