"""Allow running as python -m mcp_codemode"""
from mcp_codemode import main

main()
