# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
"""Init file for azureml-contrib-piepline-step/azureml/contrib/pipeline ."""
__path__ = __import__('pkgutil').extend_path(__path__, __name__)
