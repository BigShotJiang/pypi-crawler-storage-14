"""
SMSWapi Client Module
Contains the main SMSWapi client class with all API methods.

API Documentation: https://smswapi.com/dashboard/docs
"""

import requests
from typing import Optional, List, Dict, Any, Union

from .exceptions import (
    SMSWapiError,
    AuthenticationError,
    PermissionError,
    ValidationError,
    InsufficientCreditsError,
)


class SMSWapi:
    """
    SMSWapi client for interacting with the WhatsApp & SMS API.
    
    Example with instance config:
        >>> client = SMSWapi(secret="your_api_secret")
        >>> client.get_credits()
    
    Example with global config:
        >>> import smswapi
        >>> smswapi.API_SECRET = "your_api_secret"
        >>> client = SMSWapi()
        >>> client.get_credits()
    """
    
    def __init__(
        self,
        secret: Optional[str] = None,
        base_url: Optional[str] = None,
        default_country_code: Optional[str] = None,
        timeout: Optional[int] = None
    ):
        """
        Initialize SMSWapi client.
        
        Args:
            secret: Your SMSWapi API secret (uses global API_SECRET if not provided)
            base_url: API base URL (uses global BASE_URL if not provided)
            default_country_code: Default country code for phone numbers
            timeout: Request timeout in seconds
        """
        self._secret = secret
        self._base_url = base_url
        self._default_country_code = default_country_code
        self._timeout = timeout
    
    @property
    def secret(self) -> str:
        """Get the API secret (instance or global)."""
        from . import config
        return self._secret if self._secret is not None else config.API_SECRET
    
    @property
    def base_url(self) -> str:
        """Get the base URL (instance or global)."""
        from . import config
        return self._base_url if self._base_url is not None else config.BASE_URL
    
    @property
    def default_country_code(self) -> str:
        """Get the default country code (instance or global)."""
        from . import config
        return self._default_country_code if self._default_country_code is not None else config.DEFAULT_COUNTRY_CODE
    
    @property
    def timeout(self) -> int:
        """Get the timeout (instance or global)."""
        from . import config
        return self._timeout if self._timeout is not None else config.TIMEOUT

    # =========================================================================
    # INTERNAL HELPERS
    # =========================================================================
    
    def _get_secret(self, secret: Optional[str] = None) -> str:
        """Get API secret from parameter or instance/global config."""
        key = secret if secret is not None else self.secret
        if not key:
            raise ValueError(
                "API secret is required. Set smswapi.API_SECRET or pass secret parameter."
            )
        return key

    def _format_phone(self, phone: str, country_code: Optional[str] = None) -> str:
        """Format phone number with country code."""
        phone = "".join(c for c in phone if c.isdigit() or c == "+")
        phone = phone.lstrip("+")
        
        code = country_code or self.default_country_code
        if code:
            code = code.lstrip("+")
            if not phone.startswith(code):
                return f"+{code}{phone}"
        
        return f"+{phone}" if not phone.startswith("+") else phone

    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        secret: Optional[str] = None,
        use_form_data: bool = False
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the SMSWapi API.
        
        Args:
            method: HTTP method (GET, POST)
            endpoint: API endpoint
            params: Query parameters
            data: Form data for POST requests
            files: Files to upload
            secret: Optional API secret override
            use_form_data: Whether to send data as multipart/form-data
        
        Returns:
            API response as dictionary
        """
        url = self.base_url.rstrip("/") + "/" + endpoint.lstrip("/")
        
        # Initialize params dict if None
        if params is None:
            params = {}
        
        # Add secret to params for GET requests, or to data for POST
        api_secret = self._get_secret(secret)
        
        try:
            if method.upper() == "GET":
                params["secret"] = api_secret
                response = requests.get(url, params=params, timeout=self.timeout)
            elif method.upper() == "POST":
                if data is None:
                    data = {}
                data["secret"] = api_secret
                
                if files:
                    # Multipart form data with files
                    response = requests.post(url, data=data, files=files, timeout=self.timeout)
                elif use_form_data:
                    # Multipart form data without files
                    response = requests.post(url, data=data, timeout=self.timeout)
                else:
                    # URL encoded form data
                    response = requests.post(url, data=data, timeout=self.timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            result = response.json()
            
            # Check for API-level errors
            status = result.get("status")
            if status != 200:
                message = result.get("message", "Unknown error")
                if "permission" in message.lower():
                    raise PermissionError(f"API Error {status}: {message}")
                elif "authentication" in message.lower() or "secret" in message.lower():
                    raise AuthenticationError(f"API Error {status}: {message}")
                elif "credit" in message.lower() or "balance" in message.lower():
                    raise InsufficientCreditsError(f"API Error {status}: {message}")
                else:
                    raise SMSWapiError(f"API Error {status}: {message}")
            
            return result
            
        except requests.exceptions.JSONDecodeError as e:
            raise SMSWapiError(f"Invalid JSON response: {response.text}") from e
        except requests.exceptions.ConnectionError as e:
            raise SMSWapiError(f"Connection error: {str(e)}") from e
        except requests.exceptions.Timeout as e:
            raise SMSWapiError(f"Request timeout: {str(e)}") from e
        except requests.exceptions.RequestException as e:
            raise SMSWapiError(f"Request failed: {str(e)}") from e

    # =========================================================================
    # ACCOUNT ENDPOINTS
    # =========================================================================
    
    def get_credits(self, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get remaining credits/balance.
        Requires "get_credits" API permission.
        
        Returns:
            {
                "status": 200,
                "message": "Remaining Credits",
                "data": {"credits": "798.634", "currency": "GBP"}
            }
        """
        return self._make_request("GET", "/get/credits", secret=secret)
    
    def get_subscription(self, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get subscription package info.
        Requires "get_subscription" API permission.
        """
        return self._make_request("GET", "/get/subscription", secret=secret)

    # =========================================================================
    # PARTNERS ENDPOINTS
    # =========================================================================
    
    def get_earnings(self, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get partner earnings.
        Requires "get_earnings" API permission.
        """
        return self._make_request("GET", "/get/earnings", secret=secret)

    # =========================================================================
    # CONTACTS ENDPOINTS
    # =========================================================================
    
    def create_contact(
        self,
        phone: str,
        name: str,
        groups: Union[str, List[str]],
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a contact.
        Requires "create_contact" API permission.
        
        Args:
            phone: Contact phone number (E.164 or local format)
            name: Contact name
            groups: Group ID(s) - comma-separated string or list
            country_code: Optional country code override
        """
        if isinstance(groups, list):
            groups = ",".join(str(g) for g in groups)
        
        data = {
            "phone": self._format_phone(phone, country_code),
            "name": name,
            "groups": groups
        }
        return self._make_request("POST", "/create/contact", data=data, use_form_data=True, secret=secret)
    
    def create_group(self, name: str, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a contact group.
        Requires "create_group" API permission.
        
        Args:
            name: Group name
        """
        return self._make_request("POST", "/create/group", data={"name": name}, use_form_data=True, secret=secret)
    
    def delete_contact(self, contact_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a contact.
        Requires "delete_contact" API permission.
        
        Args:
            contact_id: Contact ID
        """
        return self._make_request("GET", "/delete/contact", params={"id": contact_id}, secret=secret)
    
    def delete_group(self, group_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a contact group.
        Requires "delete_group" API permission.
        
        Args:
            group_id: Group ID
        """
        return self._make_request("GET", "/delete/group", params={"id": group_id}, secret=secret)
    
    def delete_unsubscribed(self, contact_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete an unsubscribed contact.
        Requires "delete_unsubscribed" API permission.
        
        Args:
            contact_id: Contact ID
        """
        return self._make_request("GET", "/delete/unsubscribed", params={"id": contact_id}, secret=secret)
    
    def get_contacts(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get contacts list.
        Requires "get_contacts" API permission.
        
        Args:
            limit: Results per page (default: 10)
            page: Page number (default: 1)
        """
        return self._make_request("GET", "/get/contacts", params={"limit": limit, "page": page}, secret=secret)
    
    def get_groups(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get contact groups list.
        Requires "get_groups" API permission.
        
        Args:
            limit: Results per page (default: 10)
            page: Page number (default: 1)
        """
        return self._make_request("GET", "/get/groups", params={"limit": limit, "page": page}, secret=secret)
    
    def get_unsubscribed(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get unsubscribed contacts list.
        Requires "get_unsubscribed" API permission.
        
        Args:
            limit: Results per page (default: 10)
            page: Page number (default: 1)
        """
        return self._make_request("GET", "/get/unsubscribed", params={"limit": limit, "page": page}, secret=secret)

    # =========================================================================
    # OTP ENDPOINTS
    # =========================================================================
    
    def send_otp(
        self,
        phone: str,
        message: str,
        otp_type: str = "sms",
        expire: int = 300,
        priority: int = 2,
        account: Optional[str] = None,
        mode: Optional[str] = None,
        device: Optional[str] = None,
        gateway: Optional[Union[str, int]] = None,
        sim: Optional[int] = None,
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send a one-time password.
        Requires "otp" API permission.
        
        Use {{otp}} in message to include the OTP.
        
        Args:
            phone: Recipient phone number (E.164 format)
            message: OTP message (use {{otp}} shortcode)
            otp_type: "sms" or "whatsapp"
            expire: Expiration time in seconds (default: 300)
            priority: For WhatsApp only - 1=immediate, 2=queued
            account: WhatsApp account unique ID (for whatsapp type)
            mode: "devices" or "credits" (for sms type)
            device: Device unique ID (for sms devices mode)
            gateway: Gateway/partner device ID (for sms credits mode)
            sim: SIM slot 1 or 2 (for sms devices mode)
            country_code: Optional country code override
        
        Returns:
            Response with OTP data including the generated code
        """
        data = {
            "phone": self._format_phone(phone, country_code),
            "message": message,
            "type": otp_type,
            "expire": expire,
            "priority": priority
        }
        
        if account:
            data["account"] = account
        if mode:
            data["mode"] = mode
        if device:
            data["device"] = device
        if gateway:
            data["gateway"] = gateway
        if sim:
            data["sim"] = sim
        
        return self._make_request("POST", "/send/otp", data=data, use_form_data=True, secret=secret)
    
    def verify_otp(self, otp: str, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Verify a one-time password.
        Requires "otp" API permission.
        
        Args:
            otp: The OTP code to verify
        """
        return self._make_request("GET", "/get/otp", params={"otp": otp}, secret=secret)

    # =========================================================================
    # SMS ENDPOINTS
    # =========================================================================
    
    def send_sms(
        self,
        phone: str,
        message: str,
        mode: str = "credits",
        device: Optional[str] = None,
        gateway: Optional[Union[str, int]] = None,
        sim: Optional[int] = None,
        priority: int = 0,
        shortener: Optional[int] = None,
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send a single SMS message.
        Requires "sms_send" API permission.
        
        Args:
            phone: Recipient phone number
            message: Message text (spintax supported)
            mode: "devices" or "credits"
            device: Device unique ID (required for devices mode)
            gateway: Gateway/partner device ID (required for credits mode)
            sim: SIM slot 1 or 2 (for devices mode)
            priority: 0 or 1 = high (immediate), 2 = normal (queued)
            shortener: Shortener ID for link shortening
            country_code: Optional country code override
        """
        data = {
            "phone": self._format_phone(phone, country_code),
            "message": message,
            "mode": mode,
            "priority": priority
        }
        
        if device:
            data["device"] = device
        if gateway:
            data["gateway"] = gateway
        if sim:
            data["sim"] = sim
        if shortener:
            data["shortener"] = shortener
        
        return self._make_request("POST", "/send/sms", data=data, use_form_data=True, secret=secret)
    
    def send_sms_bulk(
        self,
        message: str,
        campaign: str,
        mode: str = "credits",
        numbers: Optional[Union[str, List[str]]] = None,
        groups: Optional[Union[str, List[str]]] = None,
        device: Optional[str] = None,
        gateway: Optional[Union[str, int]] = None,
        sim: Optional[int] = None,
        priority: int = 0,
        shortener: Optional[int] = None,
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send bulk SMS messages.
        Requires "sms_send_bulk" API permission.
        
        Args:
            message: Message text (spintax and shortcodes supported)
            campaign: Campaign name
            mode: "devices" or "credits"
            numbers: Phone numbers (comma-separated string or list)
            groups: Contact group IDs (comma-separated string or list)
            device: Device unique ID (required for devices mode)
            gateway: Gateway/partner device ID (required for credits mode)
            sim: SIM slot 1 or 2 (for devices mode)
            priority: 0 or 1 = high, 2 = normal
            shortener: Shortener ID
            country_code: Optional country code override
        """
        data = {
            "message": message,
            "campaign": campaign,
            "mode": mode,
            "priority": priority
        }
        
        if numbers:
            if isinstance(numbers, list):
                numbers = ",".join(self._format_phone(n, country_code) for n in numbers)
            data["numbers"] = numbers
        if groups:
            if isinstance(groups, list):
                groups = ",".join(str(g) for g in groups)
            data["groups"] = groups
        if device:
            data["device"] = device
        if gateway:
            data["gateway"] = gateway
        if sim:
            data["sim"] = sim
        if shortener:
            data["shortener"] = shortener
        
        return self._make_request("POST", "/send/sms.bulk", data=data, use_form_data=True, secret=secret)
    
    def get_sms_sent(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get sent SMS messages.
        Requires "get_sms_sent" API permission.
        """
        return self._make_request("GET", "/get/sms.sent", params={"limit": limit, "page": page}, secret=secret)
    
    def get_sms_received(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get received SMS messages.
        Requires "get_sms_received" API permission.
        """
        return self._make_request("GET", "/get/sms.received", params={"limit": limit, "page": page}, secret=secret)
    
    def get_sms_pending(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get pending SMS messages.
        Requires "get_sms_pending" API permission.
        """
        return self._make_request("GET", "/get/sms.pending", params={"limit": limit, "page": page}, secret=secret)
    
    def get_sms_campaigns(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get SMS campaigns.
        Requires "get_sms_campaigns" API permission.
        """
        return self._make_request("GET", "/get/sms.campaigns", params={"limit": limit, "page": page}, secret=secret)
    
    def get_sms_message(
        self,
        message_id: int,
        message_type: str = "sent",
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get a single SMS message by ID.
        Requires "get_sms_sent" or "get_sms_received" API permission.
        
        Args:
            message_id: Message ID
            message_type: "sent" or "received"
        """
        return self._make_request(
            "GET", "/get/sms.message",
            params={"id": message_id, "type": message_type},
            secret=secret
        )
    
    def delete_sms_sent(self, message_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a sent SMS message.
        Requires "delete_sms_sent" API permission.
        """
        return self._make_request("GET", "/delete/sms.sent", params={"id": message_id}, secret=secret)
    
    def delete_sms_received(self, message_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a received SMS message.
        Requires "delete_sms_received" API permission.
        """
        return self._make_request("GET", "/delete/sms.received", params={"id": message_id}, secret=secret)
    
    def delete_sms_campaign(self, campaign_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete an SMS campaign.
        Requires "delete_sms_campaign" API permission.
        """
        return self._make_request("GET", "/delete/sms.campaign", params={"id": campaign_id}, secret=secret)
    
    def start_sms_campaign(self, campaign_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Start/resume an SMS campaign.
        Requires "start_sms_campaign" API permission.
        """
        return self._make_request("GET", "/remote/start.sms", params={"campaign": campaign_id}, secret=secret)
    
    def stop_sms_campaign(self, campaign_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Stop/pause an SMS campaign.
        Requires "stop_sms_campaign" API permission.
        """
        return self._make_request("GET", "/remote/stop.sms", params={"campaign": campaign_id}, secret=secret)

    # =========================================================================
    # GATEWAYS ENDPOINTS
    # =========================================================================
    
    def get_rates(self, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get gateway rates.
        Requires "get_rates" API permission.
        
        Returns available gateways and partner devices with their rates.
        """
        return self._make_request("GET", "/get/rates", secret=secret)

    # =========================================================================
    # WHATSAPP ENDPOINTS
    # =========================================================================
    
    def send_whatsapp(
        self,
        recipient: str,
        message: str,
        account: str,
        msg_type: str = "text",
        priority: int = 2,
        media_file: Optional[Any] = None,
        media_url: Optional[str] = None,
        media_type: Optional[str] = None,
        document_file: Optional[Any] = None,
        document_url: Optional[str] = None,
        document_name: Optional[str] = None,
        document_type: Optional[str] = None,
        shortener: Optional[int] = None,
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send a single WhatsApp message.
        Requires "wa_send" API permission.
        
        Args:
            recipient: Phone number or WhatsApp group address
            message: Message or caption (spintax supported)
            account: WhatsApp account unique ID
            msg_type: "text", "media", or "document"
            priority: 1=immediate, 2=queued (default)
            media_file: Media file to upload (for media type)
            media_url: Direct URL to media file (for media type)
            media_type: "image", "audio", "video" (required with media_url)
            document_file: Document file to upload (for document type)
            document_url: Direct URL to document (for document type)
            document_name: Document filename with extension
            document_type: "pdf", "xml", "xls", "xlsx", "doc", "docx"
            shortener: Shortener ID for link shortening
            country_code: Optional country code override
        """
        data = {
            "account": account,
            # Don't format group addresses (they contain @g.us)
            "recipient": recipient if "@" in recipient else self._format_phone(recipient, country_code),
            "message": message,
            "type": msg_type,
            "priority": priority
        }
        
        files = {}
        
        if media_url:
            data["media_url"] = media_url
        if media_type:
            data["media_type"] = media_type
        if media_file:
            files["media_file"] = media_file
        
        if document_url:
            data["document_url"] = document_url
        if document_name:
            data["document_name"] = document_name
        if document_type:
            data["document_type"] = document_type
        if document_file:
            files["document_file"] = document_file
        
        if shortener:
            data["shortener"] = shortener
        
        return self._make_request(
            "POST", "/send/whatsapp",
            data=data,
            files=files if files else None,
            use_form_data=True,
            secret=secret
        )
    
    def send_whatsapp_bulk(
        self,
        message: str,
        campaign: str,
        account: str,
        msg_type: str = "text",
        recipients: Optional[Union[str, List[str]]] = None,
        groups: Optional[Union[str, List[str]]] = None,
        media_file: Optional[Any] = None,
        media_url: Optional[str] = None,
        media_type: Optional[str] = None,
        document_file: Optional[Any] = None,
        document_url: Optional[str] = None,
        document_name: Optional[str] = None,
        document_type: Optional[str] = None,
        shortener: Optional[int] = None,
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send bulk WhatsApp messages.
        Requires "wa_send_bulk" API permission.
        
        Args:
            message: Message or caption (spintax and shortcodes supported)
            campaign: Campaign name
            account: WhatsApp account unique ID
            msg_type: "text", "media", or "document"
            recipients: Phone numbers/group addresses (comma-separated or list)
            groups: Contact group IDs (comma-separated or list)
            media_file: Media file to upload
            media_url: Direct URL to media file
            media_type: "image", "audio", "video"
            document_file: Document file to upload
            document_url: Direct URL to document
            document_name: Document filename with extension
            document_type: "pdf", "xml", "xls", "xlsx", "doc", "docx"
            shortener: Shortener ID
            country_code: Optional country code override
        """
        data = {
            "account": account,
            "campaign": campaign,
            "message": message,
            "type": msg_type
        }
        
        if recipients:
            if isinstance(recipients, list):
                recipients = ",".join(self._format_phone(r, country_code) for r in recipients)
            data["recipients"] = recipients
        if groups:
            if isinstance(groups, list):
                groups = ",".join(str(g) for g in groups)
            data["groups"] = groups
        
        files = {}
        
        if media_url:
            data["media_url"] = media_url
        if media_type:
            data["media_type"] = media_type
        if media_file:
            files["media_file"] = media_file
        
        if document_url:
            data["document_url"] = document_url
        if document_name:
            data["document_name"] = document_name
        if document_type:
            data["document_type"] = document_type
        if document_file:
            files["document_file"] = document_file
        
        if shortener:
            data["shortener"] = shortener
        
        return self._make_request(
            "POST", "/send/whatsapp.bulk",
            data=data,
            files=files if files else None,
            use_form_data=True,
            secret=secret
        )
    
    def get_wa_accounts(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get WhatsApp accounts.
        Requires "get_wa_accounts" API permission.
        """
        return self._make_request("GET", "/get/wa.accounts", params={"limit": limit, "page": page}, secret=secret)
    
    def get_wa_sent(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get sent WhatsApp chats.
        Requires "get_wa_sent" API permission.
        """
        return self._make_request("GET", "/get/wa.sent", params={"limit": limit, "page": page}, secret=secret)
    
    def get_wa_received(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get received WhatsApp chats.
        Requires "get_wa_received" API permission.
        """
        return self._make_request("GET", "/get/wa.received", params={"limit": limit, "page": page}, secret=secret)
    
    def get_wa_pending(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get pending WhatsApp chats.
        Requires "get_wa_pending" API permission.
        """
        return self._make_request("GET", "/get/wa.pending", params={"limit": limit, "page": page}, secret=secret)
    
    def get_wa_campaigns(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get WhatsApp campaigns.
        Requires "get_wa_campaigns" API permission.
        """
        return self._make_request("GET", "/get/wa.campaigns", params={"limit": limit, "page": page}, secret=secret)
    
    def get_wa_message(
        self,
        message_id: int,
        message_type: str = "sent",
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get a single WhatsApp message by ID.
        Requires "get_wa_sent" or "get_wa_received" API permission.
        
        Args:
            message_id: Message ID
            message_type: "sent" or "received"
        """
        return self._make_request(
            "GET", "/get/wa.message",
            params={"id": message_id, "type": message_type},
            secret=secret
        )
    
    def get_wa_groups(self, unique: str, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get WhatsApp groups for an account.
        Requires "get_wa_groups" API permission.
        
        Args:
            unique: WhatsApp account unique ID
        """
        return self._make_request("GET", "/get/wa.groups", params={"unique": unique}, secret=secret)
    
    def delete_wa_sent(self, chat_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a sent WhatsApp chat.
        Requires "delete_wa_sent" API permission.
        """
        return self._make_request("GET", "/delete/wa.sent", params={"id": chat_id}, secret=secret)
    
    def delete_wa_received(self, chat_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a received WhatsApp chat.
        Requires "delete_wa_received" API permission.
        """
        return self._make_request("GET", "/delete/wa.received", params={"id": chat_id}, secret=secret)
    
    def delete_wa_campaign(self, campaign_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a WhatsApp campaign.
        Requires "delete_wa_campaign" API permission.
        """
        return self._make_request("GET", "/delete/wa.campaign", params={"id": campaign_id}, secret=secret)
    
    def delete_wa_account(self, unique: str, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a WhatsApp account.
        Requires "delete_wa_account" API permission.
        
        Args:
            unique: WhatsApp account unique ID
        """
        return self._make_request("GET", "/delete/wa.account", params={"unique": unique}, secret=secret)
    
    def start_wa_campaign(self, campaign_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Start/resume a WhatsApp campaign.
        Requires "start_wa_campaign" API permission.
        """
        return self._make_request("GET", "/remote/start.chats", params={"campaign": campaign_id}, secret=secret)
    
    def stop_wa_campaign(self, campaign_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Stop/pause a WhatsApp campaign.
        Requires "stop_wa_campaign" API permission.
        """
        return self._make_request("GET", "/remote/stop.chats", params={"campaign": campaign_id}, secret=secret)
    
    def validate_whatsapp(
        self,
        phone: str,
        unique: str,
        country_code: Optional[str] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Validate if a phone number exists on WhatsApp.
        Requires "validate_wa_phone" API permission.
        
        Args:
            phone: Phone number (E.164 format)
            unique: WhatsApp account unique ID to use for validation
            country_code: Optional country code override
        """
        return self._make_request(
            "GET", "/validate/whatsapp",
            params={"phone": self._format_phone(phone, country_code), "unique": unique},
            secret=secret
        )

    # =========================================================================
    # WHATSAPP ACCOUNT LINKING
    # =========================================================================
    
    def get_wa_servers(self, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get available WhatsApp servers.
        Requires "create_whatsapp" API permission.
        """
        return self._make_request("GET", "/get/wa.servers", secret=secret)
    
    def link_whatsapp(self, sid: Optional[int] = None, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Create a QR code to link a new WhatsApp account.
        Requires "create_whatsapp" API permission.
        
        Args:
            sid: Optional server ID (auto-selected if not provided)
        
        Returns:
            Response with qrstring, qrimagelink, and infolink
        """
        params = {}
        if sid:
            params["sid"] = sid
        return self._make_request("GET", "/create/wa.link", params=params, secret=secret)
    
    def relink_whatsapp(
        self,
        unique: str,
        sid: Optional[int] = None,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Create a QR code to relink an existing WhatsApp account.
        Requires "create_whatsapp" API permission.
        
        Args:
            unique: WhatsApp account unique ID
            sid: Optional server ID
        
        Returns:
            Response with qrstring and qrimagelink
        """
        params = {"unique": unique}
        if sid:
            params["sid"] = sid
        return self._make_request("GET", "/create/wa.relink", params=params, secret=secret)
    
    def get_wa_qr(self, token: str) -> Dict[str, Any]:
        """
        Get WhatsApp QR code image.
        Requires "create_whatsapp" API permission.
        
        Args:
            token: Token from link_whatsapp response
        
        Note: This returns image data, not JSON
        """
        url = f"{self.base_url}/get/wa.qr?token={token}"
        response = requests.get(url, timeout=self.timeout)
        return {"url": url, "content": response.content}
    
    def get_wa_info(self, token: str) -> Dict[str, Any]:
        """
        Get WhatsApp account info after linking.
        Requires "create_whatsapp" API permission.
        
        Args:
            token: Token from link_whatsapp response
        """
        url = f"{self.base_url}/get/wa.info?token={token}"
        response = requests.get(url, timeout=self.timeout)
        return response.json()

    # =========================================================================
    # ANDROID DEVICE ENDPOINTS
    # =========================================================================
    
    def get_devices(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get linked Android devices.
        Requires "get_devices" API permission.
        """
        return self._make_request("GET", "/get/devices", params={"limit": limit, "page": page}, secret=secret)
    
    def send_ussd(
        self,
        code: str,
        sim: int,
        device: str,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Send a USSD request.
        Requires "ussd" API permission.
        
        Args:
            code: MMI/USSD code (e.g., "*123#")
            sim: SIM slot number (1 or 2)
            device: Device unique ID
        """
        data = {
            "code": code,
            "sim": sim,
            "device": device
        }
        return self._make_request("POST", "/send/ussd", data=data, use_form_data=True, secret=secret)
    
    def get_ussd(
        self,
        limit: int = 10,
        page: int = 1,
        secret: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get USSD requests.
        Requires "get_ussd" API permission.
        """
        return self._make_request("GET", "/get/ussd", params={"limit": limit, "page": page}, secret=secret)
    
    def delete_ussd(self, ussd_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a USSD request.
        Requires "delete_ussd" API permission.
        """
        return self._make_request("GET", "/delete/ussd", params={"id": ussd_id}, secret=secret)
    
    def delete_notification(self, notification_id: int, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete an Android notification.
        Requires "delete_notification" API permission.
        """
        return self._make_request("GET", "/delete/notification", params={"id": notification_id}, secret=secret)

    # =========================================================================
    # MISCELLANEOUS ENDPOINTS
    # =========================================================================
    
    def get_shorteners(self, secret: Optional[str] = None) -> Dict[str, Any]:
        """
        Get available URL shorteners.
        Requires "get_shorteners" API permission.
        """
        return self._make_request("GET", "/get/shorteners", secret=secret)
