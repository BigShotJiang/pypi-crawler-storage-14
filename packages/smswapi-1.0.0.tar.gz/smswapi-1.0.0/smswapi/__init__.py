"""
SMSWapi Python Module
A production-ready Python wrapper for the SMSWapi WhatsApp & SMS API.

Usage:
    import smswapi
    
    # Set your API secret globally
    smswapi.API_SECRET = "your_api_secret_here"
    
    # Create a client and use any method
    client = smswapi.SMSWapi()
    
    # Get credits
    credits = client.get_credits()
    
    # Send WhatsApp message
    client.send_whatsapp(
        recipient="1234567890",
        message="Hello!",
        account="your_wa_account_unique_id"
    )
    
    # Send SMS
    client.send_sms(
        phone="1234567890",
        message="Hello via SMS!",
        mode="credits",
        gateway="your_gateway_id"
    )
    
    # Or create a client with its own secret
    client = smswapi.SMSWapi(secret="your_api_secret")

API Documentation: https://smswapi.com/dashboard/docs
"""

# Import exceptions
from .exceptions import (
    SMSWapiError,
    AuthenticationError,
    PermissionError,
    RateLimitError,
    ValidationError,
    InsufficientCreditsError,
)

# Import the main client class
from .client import SMSWapi

# Allow setting config variables directly on the module
from . import config as _config


def __getattr__(name):
    """Allow getting config variables from module level."""
    if name in ("API_SECRET", "BASE_URL", "TIMEOUT", "DEFAULT_COUNTRY_CODE"):
        return getattr(_config, name)
    raise AttributeError(f"module 'smswapi' has no attribute '{name}'")


def __setattr__(name, value):
    """Allow setting config variables at module level."""
    if name in ("API_SECRET", "BASE_URL", "TIMEOUT", "DEFAULT_COUNTRY_CODE"):
        setattr(_config, name, value)
    else:
        raise AttributeError(f"module 'smswapi' has no attribute '{name}'")


# Export all public classes and exceptions
__all__ = [
    # Configuration (accessible via module attributes)
    "API_SECRET",
    "BASE_URL",
    "TIMEOUT",
    "DEFAULT_COUNTRY_CODE",
    # Exceptions
    "SMSWapiError",
    "AuthenticationError",
    "PermissionError",
    "RateLimitError",
    "ValidationError",
    "InsufficientCreditsError",
    # Main client class
    "SMSWapi",
]

__version__ = "1.0.0"
