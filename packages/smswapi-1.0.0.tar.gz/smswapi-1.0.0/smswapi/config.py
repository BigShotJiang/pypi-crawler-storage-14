"""
SMSWapi Configuration Module
Global configuration variables for the SMSWapi client.
"""

# Your SMSWapi API secret (from Tools -> API Keys page)
API_SECRET: str = ""

# API base URL
BASE_URL: str = "https://smswapi.com/api"

# Request timeout in seconds
TIMEOUT: int = 30

# Default country code for phone numbers (e.g., "44" for UK, "40" for Romania)
DEFAULT_COUNTRY_CODE: str = ""
