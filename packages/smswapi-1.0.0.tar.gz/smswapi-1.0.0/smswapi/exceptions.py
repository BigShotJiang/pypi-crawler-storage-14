"""
SMSWapi Exceptions Module
Custom exceptions for the SMSWapi client.
"""


class SMSWapiError(Exception):
    """Base exception for SMSWapi errors."""
    pass


class AuthenticationError(SMSWapiError):
    """Raised when API authentication fails (invalid secret)."""
    pass


class PermissionError(SMSWapiError):
    """Raised when API key lacks required permission."""
    pass


class RateLimitError(SMSWapiError):
    """Raised when API rate limit is exceeded."""
    pass


class ValidationError(SMSWapiError):
    """Raised when request validation fails."""
    pass


class InsufficientCreditsError(SMSWapiError):
    """Raised when account has insufficient credits."""
    pass
