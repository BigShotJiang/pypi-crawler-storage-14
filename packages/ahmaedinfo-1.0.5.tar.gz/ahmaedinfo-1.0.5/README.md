# Ahmaedinfo AI — Python API Wrapper  
سريع • خفيف • يدعم الذاكرة • يدعم المحادثة • يعمل على جميع المنصّات  

![PyPI](https://img.shields.io/pypi/v/ahmaedinfo)
![Downloads](https://img.shields.io/pypi/dm/ahmaedinfo)
![License](https://img.shields.io/badge/License-MIT-blue.svg)
![Python](https://img.shields.io/badge/Python-3.8+-blue)

---

## 🚀 ما هو Ahmaedinfo AI ؟

**Ahmaedinfo** مكتبة Python رسمية للتعامل مع واجهة الذكاء الاصطناعي  
المقدمة من **Ahmaedinfo API**.

تم تصميم المكتبة لتكون:
- خفيفة  
- سريعة  
- نظيفة في الاستخدام  
- سهلة الدمج مع أي أداة / بوت / سكربت  
- تعمل على جميع الأنظمة (Linux, Termux, Windows, Android/Pydroid)  

وتحتوي على:
- 🧠 ذاكرة محادثة (Conversation Memory)  
- 💬 وضع دردشة جاهز Chat Mode  
- 🎨 ألوان Terminal  
- 🔁 إعادة المحاولة Retry System  
- ✔ تنظيف النصوص Clean Output  
- 🔧 تخصيص كامل عبر config.py  

---

## 📦 التثبيت

```bash
pip install ahmaedinfo


---

⚡ مثال سريع

from ahmaedinfo import AI

print(AI("Hello, how are you?"))


---

💬 وضع الدردشة في الطرفية (Terminal Chat Mode)

from ahmaedinfo import chat

chat()


---

🧠 الذاكرة (Conversation Memory)

المكتبة تخزن تلقائياً آخر 20 رسالة في:

memory.json

لتوفير ردود أكثر دقة وسياقًا.


---

🔧 الإعدادات (config.py)

API_KEY = "ahmaedinfo"
BASE_URL = "https://ahmaedinfo.serv00.net/doce-Ahmaedinfo.php"
MEMORY_PATH = "/home/username/path/memory.json"

يمكنك:

تغيير المفتاح

تغيير الرابط

تعطيل الذاكرة

استخدام مسار مخصص



---

🧩 مثال متقدم (عميل كامل)

from ahmaedinfo import Client

bot = Client(color=True, animate=False)

while True:
    msg = input("You: ")
    if msg.lower() == "exit":
        break
    reply = bot.ask(msg)
    print("AI:", reply)


---

🔥 مميزات المكتبة

✔ تصميم بسيط
✔ دعم كامل للترمينال
✔ دعم البوتات (Telegram / Discord)
✔ دعم الذاكرة
✔ دعم وضع المحادثة
✔ سرعة في الاتصال
✔ مكتبة نظيفة وبدون تبعيات كثيرة


---

🌍 روابط مهمة

🔗 المستودع الرسمي

https://github.com/Ahmaedinfo/ahmaedinfo

🔗 صفحة المكتبة على PyPI

https://pypi.org/project/ahmaedinfo

🔗 API الرسمي

https://ahmaedinfo.serv00.net/doce-Ahmaedinfo.php

🔗 قناة التحديثات

https://t.me/Ahmaed_dev1


---

📝 الرخصة (MIT License)

المشروع مفتوح المصدر بالكامل ويمكن استخدامه بحرية في أي مشروع شخصي أو تجاري.

MIT License
Copyright (c) 2025


---

⭐ دعم المشروع

إذا أعجبتك المكتبة:

ضع ⭐ على GitHub

شاركها مع أصدقائك

قم باستخدامها في مشاريعك


pip install ahmaedinfo

⬆️ هذا يكفي لدعم استمرار التطوير ❤️
