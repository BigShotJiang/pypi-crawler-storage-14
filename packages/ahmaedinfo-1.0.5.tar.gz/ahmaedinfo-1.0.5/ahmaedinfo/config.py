import os

BASE_URL = "https://ahmaedinfo.serv00.net/api/api.php"
API_KEY = "ahmaedinfo"

ROOT = os.path.expanduser("~")
MEMORY_PATH = os.path.join(ROOT, ".ahmaedinfo_memory.json")

if not os.path.exists(MEMORY_PATH):
    with open(MEMORY_PATH, "w") as f:
        f.write('{"messages": []}')
