"""D402-enabled A2A client for IATP with payment support."""

import asyncio
import logging
import json
import base64
from typing import Optional, Dict, Any
from a2a.client import A2AClient, A2ACardResolver
from a2a.types import Message, TextPart, TaskState
import httpx

from ..d402.client import D402IATPClient, create_iatp_payment_client
from ..d402.models import D402PaymentInfo
from ..d402.types import d402PaymentRequiredResponse, PaymentRequirements

logger = logging.getLogger(__name__)


class D402A2AClient:
    """A2A client with d402 payment support for IATP.
    
    This client automatically handles d402 payments when communicating with
    utility agents that require payment.
    """
    
    def __init__(
        self,
        agent_endpoint: str,
        payment_client: Optional[D402IATPClient] = None,
        max_payment_usd: Optional[float] = None
    ):
        """Initialize the d402-enabled A2A client.
        
        Args:
            agent_endpoint: URL of the utility agent
            payment_client: Optional pre-configured D402IATPClient
            max_payment_usd: Optional maximum payment amount per request
        """
        self.agent_endpoint = agent_endpoint
        self.payment_client = payment_client
        self.max_payment_usd = max_payment_usd
        
        # Resolve agent card
        self.card_resolver = A2ACardResolver(agent_endpoint)
        self.agent_card = self.card_resolver.get_agent_card()
        
        # Extract d402 payment information if available
        self.d402_info = self._extract_d402_info()
        
        # Initialize A2A client
        self.a2a_client = A2AClient(
            agent_card=self.agent_card,
            credentials=None  # d402 handles payment authorization
        )
    
    def _extract_d402_info(self) -> Optional[D402PaymentInfo]:
        """Extract d402 payment information from agent card."""
        metadata = self.agent_card.metadata or {}
        d402_data = metadata.get("d402")
        
        if d402_data and d402_data.get("enabled"):
            return D402PaymentInfo(**d402_data)
        return None
    
    async def send_message_with_payment(
        self,
        message: str,
        skill_id: Optional[str] = None
    ) -> str:
        """Send a message to the agent, automatically handling d402 payment if required.
        
        Args:
            message: The message to send to the agent
            skill_id: Optional specific skill to invoke
            
        Returns:
            Agent's response text
            
        Raises:
            ValueError: If payment is required but no payment client is configured
            RuntimeError: If task execution fails
        """
        # Prepare the message
        msg = Message(
            role="user",
            parts=[TextPart(text=message)]
        )
        
        # Prepare headers (will add payment header if needed)
        headers = {}
        
        # Try to send the request
        async with httpx.AsyncClient(timeout=300.0) as http_client:
            # First attempt without payment to see if it's required
            try:
                # Use A2A client's send_task method
                task = await self.a2a_client.send_task(
                    id=str(asyncio.get_event_loop().time()),
                    message=msg
                )
                
                # Extract response
                return self._extract_response(task)
                
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 402:
                    # Payment required - handle d402 flow
                    return await self._handle_payment_required(
                        http_client, e.response, message, skill_id
                    )
                else:
                    raise
    
    async def _handle_payment_required(
        self,
        http_client: httpx.AsyncClient,
        response: httpx.Response,
        message: str,
        skill_id: Optional[str]
    ) -> str:
        """Handle 402 Payment Required response.
        
        Args:
            http_client: HTTP client for making requests
            response: 402 response with payment requirements
            message: Original message to send
            skill_id: Optional skill ID
            
        Returns:
            Agent's response after successful payment
            
        Raises:
            ValueError: If payment client not configured or requirements not met
        """
        if not self.payment_client:
            raise ValueError(
                "Payment is required but no payment client configured. "
                "Please provide a payment_client when initializing D402A2AClient."
            )
        
        # Parse payment requirements
        try:
            payment_response = d402PaymentRequiredResponse(**response.json())
        except Exception as e:
            raise ValueError(f"Invalid payment requirements: {e}")
        
        # Select payment requirements
        try:
            selected_requirements = self.payment_client.select_payment_requirements(
                accepts=payment_response.accepts,
                network_filter=None,  # Accept any network
                scheme_filter="exact"  # Only support exact scheme
            )
        except Exception as e:
            raise ValueError(f"Cannot satisfy payment requirements: {e}")
        
        # Check if amount is within maximum
        if self.max_payment_usd:
            # Convert to USD (assuming USDC with 6 decimals)
            amount_usd = int(selected_requirements.max_amount_required) / 1_000_000
            if amount_usd > self.max_payment_usd:
                raise ValueError(
                    f"Payment amount ${amount_usd:.2f} exceeds maximum ${self.max_payment_usd:.2f}"
                )
        
        # Create payment header
        payment_header = self.payment_client.create_payment_header(
            payment_requirements=selected_requirements,
            d402_version=1
        )
        
        # Retry request with payment header
        headers = {"X-PAYMENT": payment_header}
        
        # Make the A2A request with payment
        msg = Message(
            role="user",
            parts=[TextPart(text=message)]
        )
        
        # Send task with payment (we need to make raw HTTP request with headers)
        # Since A2AClient doesn't support custom headers, we'll make the request directly
        request_data = {
            "jsonrpc": "2.0",
            "id": str(asyncio.get_event_loop().time()),
            "method": "message/send",
            "params": {
                "message": msg.model_dump()
            }
        }
        
        response = await http_client.post(
            self.agent_endpoint,
            json=request_data,
            headers={"Content-Type": "application/json", **headers}
        )
        
        if response.status_code == 402:
            raise RuntimeError(f"Payment failed: {response.json().get('error', 'Unknown error')}")
        
        response.raise_for_status()
        
        # Parse JSON-RPC response
        result = response.json()
        if "error" in result:
            raise RuntimeError(f"Agent error: {result['error']}")
        
        # Extract the response text
        task_result = result.get("result", {})
        if isinstance(task_result, dict):
            messages = task_result.get("messages", [])
            for msg in messages:
                if msg.get("role") == "agent":
                    parts = msg.get("parts", [])
                    return " ".join(
                        part.get("text", "")
                        for part in parts
                        if part.get("type") == "text"
                    )
        
        return str(task_result)
    
    def _extract_response(self, task) -> str:
        """Extract text response from task result."""
        if task.status.state == TaskState.COMPLETED:
            # Look for agent's response in messages
            for msg in task.messages:
                if msg.role == "agent":
                    response_text = ""
                    for part in msg.parts:
                        if hasattr(part, 'text'):
                            response_text += part.text
                    return response_text
            
            # If no agent message, check artifacts
            if task.artifacts:
                response_text = ""
                for artifact in task.artifacts:
                    for part in artifact.parts:
                        if hasattr(part, 'text'):
                            response_text += part.text
                return response_text
            
            return "Task completed but no response found"
        else:
            raise RuntimeError(f"Task failed with state: {task.status.state}")


def create_d402_a2a_client(
    agent_endpoint: str,
    payment_private_key: Optional[str] = None,
    max_payment_usd: Optional[float] = 10.0,
    agent_contract_address: Optional[str] = None
) -> D402A2AClient:
    """Convenience function to create an d402-enabled A2A client.
    
    Args:
        agent_endpoint: URL of the utility agent
        payment_private_key: Optional private key for payments (hex encoded)
        max_payment_usd: Maximum payment per request in USD
        agent_contract_address: Optional client agent contract address
        
    Returns:
        Configured D402A2AClient
        
    Example:
        # Create client with payment support
        client = create_d402_a2a_client(
            agent_endpoint="https://agent.example.com",
            payment_private_key="0x...",
            max_payment_usd=5.0
        )
        
        # Send message (automatically handles payment if required)
        response = await client.send_message_with_payment(
            "Analyze sentiment of: 'Stock prices are rising'"
        )
        print(response)
    """
    payment_client = None
    if payment_private_key:
        payment_client = create_iatp_payment_client(
            private_key=payment_private_key,
            max_value_usd=max_payment_usd,
            agent_contract_address=agent_contract_address
        )
    
    return D402A2AClient(
        agent_endpoint=agent_endpoint,
        payment_client=payment_client,
        max_payment_usd=max_payment_usd
    )

