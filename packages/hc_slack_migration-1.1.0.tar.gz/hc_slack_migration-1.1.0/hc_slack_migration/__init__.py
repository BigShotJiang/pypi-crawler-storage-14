__version__ = "1.1.0"

def main():
    from .main import main as _main
    return _main()