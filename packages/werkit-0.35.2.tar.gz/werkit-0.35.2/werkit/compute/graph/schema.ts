export interface MyModel {
  title: string
  description: string
  count: number
}

export type Vector3 = [number, number, number]
