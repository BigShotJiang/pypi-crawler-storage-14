# src/discera_service/capabilities/image_gen.py
from __future__ import annotations

import os
import html
import base64
from io import BytesIO
from typing import Any, Dict, List, Optional

import torch
from diffusers import StableDiffusionXLPipeline

from diffusers import DPMSolverMultistepScheduler

import logging
log = logging.getLogger("discera.image_gen")


_PIPE: Optional[StableDiffusionXLPipeline] = None  # module-level singleton


class ImageGenCapability:
    """
    Discera capability: image_gen
    - Text-to-image via SDXL
    - Returns HTML snippet + base64 PNG for UI display
    """
    name = "image_gen"
    _pipe: Optional[StableDiffusionXLPipeline] = None

    # ---------- Descriptor & assets ----------
    @staticmethod
    def descriptor() -> Dict[str, Any]:
        return {
            "name": ImageGenCapability.name,
            "description": (
                "Generates images from text prompts using local Stable Diffusion XL. "
                "Returns a base64-encoded PNG and minimal CSS/JS for rendering."
            ),
            "intents": ["image_generation", "visualization", "art", "diagram"],
            "examples": [
                "Generate a futuristic city skyline at sunset.",
                "Create a diagram of the water cycle.",
                "Draw a cartoon cat riding a bicycle.",
            ],
            "tags": ["image", "generation", "art", "visual", "diagram", "picture"],
            "excludes": [],
        }

    @staticmethod
    def assets() -> Dict[str, List[str]]:
        css = r"""
.image-gen-result {
  margin: 12px 0;
  text-align: center;
}
.image-gen-result img {
  max-width: 100%;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.12);
  background: #222;
}
.image-gen-caption {
  margin-top: 8px;
  color: #9ca3af;
  font-size: 0.92rem;
}
.prompt-desc {
  font-size: 0.4rem;
}

"""
        # (We keep JS empty; rendering is handled by the HTML snippet we return.)
        return {"css": [css], "js": []}

    # ---------- Model loading ----------

    def _extract(self, args: Any, hints: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract prompt and generation knobs from args/hints with robust coercion.
        Applies safe defaults and clamps to VRAM-friendly ranges.

        Returns:
          {
            "prompt": str,
            "negative": str,
            "width": int,
            "height": int,
            "steps": int,
            "guidance": float,
            "seed": Optional[int],
            "concise": bool,
          }
        """

        # --- helpers --------------------------------------------------------------
        def pick(*vals, default=None):
            """Return the first non-empty value among vals (treat '', 'none', 'null' as empty)."""
            for v in vals:
                if v is None:
                    continue
                s = str(v).strip() if isinstance(v, str) else v
                if s in ("", "none", "null"):
                    continue
                return v
            return default

        def to_int(val, default, *, lo=None, hi=None):
            """Coerce val to int with default and optional bounds."""
            if val is None or (isinstance(val, str) and val.strip().lower() in ("", "none", "null")):
                v = default
            else:
                try:
                    v = int(val) if isinstance(val, int) else int(float(str(val)))
                except Exception:
                    v = default
            if lo is not None:
                v = max(lo, v)
            if hi is not None:
                v = min(hi, v)
            return v

        def to_float(val, default, *, lo=None, hi=None):
            """Coerce val to float with default and optional bounds."""
            if val is None or (isinstance(val, str) and val.strip().lower() in ("", "none", "null")):
                v = default
            else:
                try:
                    v = float(val)
                except Exception:
                    v = default
            if lo is not None:
                v = max(lo, v)
            if hi is not None:
                v = min(hi, v)
            return v

        # --- prompt & options -----------------------------------------------------
        prompt = (
                getattr(args, "question", None)
                or (args.get("question") if isinstance(args, dict) else "")
                or ""
        ).strip()

        negative = (
                pick(
                    hints.get("negative"),
                    (args.get("negative") if isinstance(args, dict) else None),
                    getattr(args, "negative", None),
                    default=""
                ) or ""
        ).strip()

        # Defaults chosen for 8 GB GPUs; adjust if you have more/less VRAM
        width = to_int(
            pick(hints.get("width"), (args.get("width") if isinstance(args, dict) else None),
                 getattr(args, "width", None)),
            default=640, lo=256, hi=1024
        )
        height = to_int(
            pick(hints.get("height"), (args.get("height") if isinstance(args, dict) else None),
                 getattr(args, "height", None)),
            default=512, lo=256, hi=1024
        )
        steps = to_int(
            pick(hints.get("steps"), (args.get("steps") if isinstance(args, dict) else None),
                 getattr(args, "steps", None)),
            default=22, lo=10, hi=50
        )
        guidance = to_float(
            pick(hints.get("guidance"), (args.get("guidance") if isinstance(args, dict) else None),
                 getattr(args, "guidance", None)),
            default=7.0, lo=1.0, hi=12.0
        )

        # Tighten caps for typical 8 GB cards; raise caps if you have more VRAM
        width = max(256, min(int(width), 832))
        height = max(256, min(int(height), 832))
        steps = max(10, min(int(steps), 28))
        guidance = max(1.0, min(float(guidance), 9.0))

        # Seed (optional)
        seed_val = pick(
            hints.get("seed"),
            (args.get("seed") if isinstance(args, dict) else None),
            getattr(args, "seed", None),
            default=None
        )
        try:
            seed = int(seed_val) if seed_val is not None and str(seed_val).strip().lower() not in ("", "none",
                                                                                                   "null") else None
        except Exception:
            seed = None

        # Concise mode flag
        concise = bool(
            pick(
                hints.get("concise"),
                (args.get("concise") if isinstance(args, dict) else None),
                getattr(args, "concise", None),
                default=False
            )
        )

        return {
            "prompt": prompt,
            "negative": negative,
            "width": width,
            "height": height,
            "steps": steps,
            "guidance": guidance,
            "seed": seed,
            "concise": concise,
        }

    def _extract(self, args: Any, hints: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract prompt and generation knobs from args/hints with robust coercion.
        Applies safe defaults and clamps to VRAM-friendly ranges.

        Returns:
          {
            "prompt": str,
            "negative": str,
            "width": int,
            "height": int,
            "steps": int,
            "guidance": float,
            "seed": Optional[int],
            "concise": bool,
          }
        """

        # --- helpers --------------------------------------------------------------
        def pick(*vals, default=None):
            """Return the first non-empty value among vals (treat '', 'none', 'null' as empty)."""
            for v in vals:
                if v is None:
                    continue
                s = str(v).strip() if isinstance(v, str) else v
                if s in ("", "none", "null"):
                    continue
                return v
            return default

        def to_int(val, default, *, lo=None, hi=None):
            """Coerce val to int with default and optional bounds."""
            if val is None or (isinstance(val, str) and val.strip().lower() in ("", "none", "null")):
                v = default
            else:
                try:
                    v = int(val) if isinstance(val, int) else int(float(str(val)))
                except Exception:
                    v = default
            if lo is not None:
                v = max(lo, v)
            if hi is not None:
                v = min(hi, v)
            return v

        def to_float(val, default, *, lo=None, hi=None):
            """Coerce val to float with default and optional bounds."""
            if val is None or (isinstance(val, str) and val.strip().lower() in ("", "none", "null")):
                v = default
            else:
                try:
                    v = float(val)
                except Exception:
                    v = default
            if lo is not None:
                v = max(lo, v)
            if hi is not None:
                v = min(hi, v)
            return v

        # --- prompt & options -----------------------------------------------------
        prompt = (
                getattr(args, "question", None)
                or (args.get("question") if isinstance(args, dict) else "")
                or ""
        ).strip()

        negative = (
                pick(
                    hints.get("negative"),
                    (args.get("negative") if isinstance(args, dict) else None),
                    getattr(args, "negative", None),
                    default=""
                ) or ""
        ).strip()

        # Defaults chosen for 8 GB GPUs; adjust if you have more/less VRAM
        width = to_int(
            pick(hints.get("width"), (args.get("width") if isinstance(args, dict) else None),
                 getattr(args, "width", None)),
            default=640, lo=256, hi=1024
        )
        height = to_int(
            pick(hints.get("height"), (args.get("height") if isinstance(args, dict) else None),
                 getattr(args, "height", None)),
            default=512, lo=256, hi=1024
        )
        steps = to_int(
            pick(hints.get("steps"), (args.get("steps") if isinstance(args, dict) else None),
                 getattr(args, "steps", None)),
            default=22, lo=10, hi=50
        )
        guidance = to_float(
            pick(hints.get("guidance"), (args.get("guidance") if isinstance(args, dict) else None),
                 getattr(args, "guidance", None)),
            default=7.0, lo=1.0, hi=12.0
        )

        # Tighten caps for typical 8 GB cards; raise caps if you have more VRAM
        width = max(256, min(int(width), 832))
        height = max(256, min(int(height), 832))
        steps = max(10, min(int(steps), 28))
        guidance = max(1.0, min(float(guidance), 9.0))

        # Seed (optional)
        seed_val = pick(
            hints.get("seed"),
            (args.get("seed") if isinstance(args, dict) else None),
            getattr(args, "seed", None),
            default=None
        )
        try:
            seed = int(seed_val) if seed_val is not None and str(seed_val).strip().lower() not in ("", "none",
                                                                                                   "null") else None
        except Exception:
            seed = None

        # Concise mode flag
        concise = bool(
            pick(
                hints.get("concise"),
                (args.get("concise") if isinstance(args, dict) else None),
                getattr(args, "concise", None),
                default=False
            )
        )

        return {
            "prompt": prompt,
            "negative": negative,
            "width": width,
            "height": height,
            "steps": steps,
            "guidance": guidance,
            "seed": seed,
            "concise": concise,
        }

    def _get_pipe(self) -> StableDiffusionXLPipeline:
        """
        Lazy-load the SDXL pipeline once per process; reuse thereafter.
        Prefers local weights. Respects HF_HOME/TRANSFORMERS_CACHE/DIFFUSERS_CACHE.
        Uses CPU/GPU offload (sequential) to keep VRAM in check for 8 GB GPUs.
        """
        global _PIPE
        if _PIPE is not None:
            return _PIPE

        # --- cache directories / local weights ---
        hf_home = os.getenv("HF_HOME", "/models/hf")
        os.environ.setdefault("HF_HOME", hf_home)
        os.environ.setdefault("TRANSFORMERS_CACHE", hf_home)
        os.environ.setdefault("DIFFUSERS_CACHE", hf_home)

        local_dir = os.getenv("SDXL_MODEL_DIR")  # e.g., /models/sdxl-base-1.0
        model_id = os.getenv("SDXL_MODEL_ID", "stabilityai/stable-diffusion-xl-base-1.0")

        use_cuda = torch.cuda.is_available()
        dtype = torch.float16 if use_cuda else torch.float32

        # --- load pipeline (local preferred) ---
        if local_dir and os.path.isdir(local_dir):
            pipe = StableDiffusionXLPipeline.from_pretrained(
                local_dir, local_files_only=True, torch_dtype=dtype
            )
        else:
            pipe = StableDiffusionXLPipeline.from_pretrained(
                model_id, torch_dtype=dtype, cache_dir=hf_home
            )

        # --- VRAM savers: VAE slicing / tiling ---
        try:
            if hasattr(pipe, "enable_vae_slicing"):
                pipe.enable_vae_slicing()
            if hasattr(pipe, "vae") and hasattr(pipe.vae, "enable_tiling"):
                pipe.vae.enable_tiling()
        except Exception:
            pass

        # --- attention slicing (safe with offload) ---
        try:
            pipe.enable_attention_slicing()
        except Exception:
            pass

        # --- offload (choose one; sequential preferred) ---
        try:
            pipe.enable_sequential_cpu_offload()
        except Exception:
            try:
                pipe.enable_model_cpu_offload()
            except Exception:
                pass

        # --- memory-efficient attention (xFormers preferred; SDPA fallback) ---
        try:
            pipe.enable_xformers_memory_efficient_attention()
        except Exception:
            try:
                torch.set_float32_matmul_precision("medium")
            except Exception:
                pass

        try:
            pipe.scheduler = DPMSolverMultistepScheduler.from_config(pipe.scheduler.config)
        except Exception:
            pass
        # IMPORTANT: do NOT call pipe.to("cuda") when offloading is enabled.
        # Offload modes manage device placement automatically.

        _PIPE = pipe
        return pipe

    # ---------- Helper ----------
    @staticmethod
    def _html_for_image(b64: str, prompt: str, caption: str = "") -> str:
        safe_prompt = html.escape(prompt or "")
        cap = html.escape(caption or "")
        return (
            f'<div class="image-gen-result">'
            f'<img src="data:image/png;base64,{b64}" alt="{safe_prompt}" loading="on">'
            f'<p class="prompt-desc"><strong>Prompt:</strong> {safe_prompt}</p>'
            f'{(" · " + cap) if cap else ""}'
            f'</div>'
            f'</div>'
        )

    # ---------- Execution ----------
    def run_once(self, args: Any, **kwargs) -> Dict[str, Any]:
        hints: Dict[str, Any] = kwargs.get("hints") or {}
        p = self._extract(args, hints)

        # --- prompt & options -----------------------------------------------------
        # Accept both "question" and "q" (the SSE endpoint sends q=)
        prompt = (
            # object attribute first
                getattr(args, "question", None)
                # dict key "question"
                or (args.get("question") if isinstance(args, dict) else None)
                # dict key "q" (alias used by /api/stream/ask)
                or (args.get("q") if isinstance(args, dict) else None)
                # hints.prompt (optional future alias)
                or (hints.get("prompt") if isinstance(hints, dict) else None)
                or ""
        )
        prompt = str(prompt).strip()

        if not prompt:
            return {
                "answer": "Please provide a prompt for image generation.",
                "image_base64": "",
                "meta": {"capability": self.name, "error": "missing_prompt"},
            }

        log.info("[image_gen] prompt=%r width=%s height=%s steps=%s guidance=%s",
                 p["prompt"], p["width"], p["height"], p["steps"], p["guidance"])

        try:
            pipe = self._get_pipe()
            # Decide device once
            device = "cuda" if torch.cuda.is_available() else "cpu"

            # Build a generator:
            # - If the user provided a seed -> deterministic run
            # - Else -> randomize per-request so images vary
            seed_used = None
            if p["seed"] is not None:
                seed_used = int(p["seed"])
                generator = torch.Generator(device=device).manual_seed(seed_used)
            else:
                # Secure random seed so every request differs
                import os
                seed_used = int.from_bytes(os.urandom(8), "big")
                generator = torch.Generator(device=device).manual_seed(seed_used)

            with torch.inference_mode():
                image = pipe(
                    prompt=prompt,
                    negative_prompt=p["negative"] or None,
                    width=p["width"],
                    height=p["height"],
                    num_inference_steps=p["steps"],
                    guidance_scale=p["guidance"],
                    generator=generator,
                ).images[0]

            buf = BytesIO()
            image.save(buf, format="PNG")
            image_b64 = base64.b64encode(buf.getvalue()).decode("utf-8")

            # Build HTML (concise: no long caption)
            caption = "Rendered via local SDXL" if not p["concise"] else ""
            html_block = self._html_for_image(image_b64, prompt, caption)

            return {
                "answer": html_block,       # front-end renders this directly
                "image_base64": image_b64,  # also available to the UI if needed
                "meta": {
                    "capability": self.name,
                    "prompt": prompt,
                    "negative": p["negative"],
                    "width": p["width"],
                    "height": p["height"],
                    "steps": p["steps"],
                    "guidance": p["guidance"],
                    "seed_requested": p["seed"],   # what caller asked for
                    "seed_used": seed_used,
                    "device": "cuda" if torch.cuda.is_available() else "cpu",
                },
            }

        except Exception as ex:
            md = (
                "### Image Generation Error\n"
                f"**Prompt:** {html.escape(prompt)}\n\n"
                f"Sorry, image generation failed: `{ex}`"
            )
            return {
                "answer": md,
                "image_base64": "",
                "meta": {"capability": self.name, "prompt": prompt, "error": str(ex)},
            }

    async def run_stream(self, args: Any, **kwargs):
        # No token-by-token progress from diffusers; stream a few events for consistency
        yield {"event": "generation_started", "data": {"capability": self.name}}
        result = self.run_once(args, **kwargs)
        # Ask FE to inject capability assets (CSS) once per session
        try:
            yield {"event": "assets", "data": {"css": self.assets().get("css", []), "js": self.assets().get("js", [])}}
        except Exception:
            pass
        yield {"event": "token", "data": result["answer"]}
        yield {"event": "generation_done", "data": {}}
        yield {"event": "done", "data": {}}

def register(registry):
    registry.register(ImageGenCapability())
