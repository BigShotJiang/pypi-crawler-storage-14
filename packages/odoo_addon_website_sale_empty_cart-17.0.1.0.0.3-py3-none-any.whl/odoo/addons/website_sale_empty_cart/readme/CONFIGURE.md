To configure this module, you need to:

- To enable (or disable) the cart empty button for a website, go to Website / Configuration / Settings. Then search the "Cart Empty Button" and edit its value.
