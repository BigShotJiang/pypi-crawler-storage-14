from enum import Enum

class ChargingState(Enum):
    On = True
    Off = False
    