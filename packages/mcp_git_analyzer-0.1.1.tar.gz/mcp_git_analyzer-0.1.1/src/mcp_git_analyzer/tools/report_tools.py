"""Report generation tools for analyzed repositories."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from mcp_git_analyzer.db import Database
from mcp_git_analyzer.tools.analysis_tools import AnalysisTools
from mcp_git_analyzer.tools.search_tools import SearchTools


ReportType = Literal["summary", "detailed", "dependencies", "architecture"]
OutputFormat = Literal["json", "markdown", "html"]


class ReportTools:
    """Generate analysis reports from repository data."""
    
    def __init__(
        self, 
        db: Database, 
        analysis_tools: AnalysisTools, 
        search_tools: SearchTools
    ):
        self.db = db
        self.analysis = analysis_tools
        self.search = search_tools
    
    def generate_report(
        self,
        repo_id: int,
        report_type: ReportType = "summary",
        output_format: OutputFormat = "markdown",
        save_path: str | None = None
    ) -> dict:
        """
        Generate an analysis report for a repository.
        
        Args:
            repo_id: Repository ID
            report_type: Type of report to generate
                - "summary": High-level overview with key statistics
                - "detailed": Full analysis with all symbols and patterns
                - "dependencies": Focus on imports and external dependencies
                - "architecture": Class hierarchy and call graph visualization
            output_format: Output format ("json", "markdown", "html")
            save_path: Optional file path to save the report
        
        Returns:
            Dict with status, report content, and save location if applicable
        """
        # Get repository summary as base data
        summary = self.analysis.get_repo_summary(repo_id)
        if summary.get("status") != "success":
            return summary
        
        # Generate report data based on type
        if report_type == "summary":
            report_data = self._generate_summary_report(repo_id, summary)
        elif report_type == "detailed":
            report_data = self._generate_detailed_report(repo_id, summary)
        elif report_type == "dependencies":
            report_data = self._generate_dependency_report(repo_id, summary)
        elif report_type == "architecture":
            report_data = self._generate_architecture_report(repo_id, summary)
        else:
            return {"status": "error", "message": f"Unknown report type: {report_type}"}
        
        # Format report
        if output_format == "json":
            report_content = self._format_as_json(report_data)
        elif output_format == "markdown":
            report_content = self._format_as_markdown(report_data, report_type)
        elif output_format == "html":
            report_content = self._format_as_html(report_data, report_type)
        else:
            return {"status": "error", "message": f"Unknown output format: {output_format}"}
        
        result = {
            "status": "success",
            "report_type": report_type,
            "output_format": output_format,
            "report": report_content,
            "saved_to": None
        }
        
        # Save to file if path provided
        if save_path:
            try:
                save_result = self._save_report(report_content, save_path, output_format)
                result["saved_to"] = save_result
            except Exception as e:
                result["save_error"] = str(e)
        
        return result
    
    def _generate_summary_report(self, repo_id: int, summary: dict) -> dict:
        """Generate high-level summary report data."""
        repo = summary.get("repository", {})
        
        return {
            "title": f"Repository Analysis Summary: {repo.get('name', 'Unknown')}",
            "generated_at": datetime.now().isoformat(),
            "repository": {
                "id": repo.get("id"),
                "name": repo.get("name"),
                "url": repo.get("url"),
                "last_analyzed": repo.get("last_analyzed")
            },
            "overview": {
                "languages": summary.get("languages", []),
                "total_files": sum(lang.get("file_count", 0) for lang in summary.get("languages", [])),
                "total_lines": sum(lang.get("total_lines", 0) for lang in summary.get("languages", []))
            },
            "symbols": {
                "counts": summary.get("symbol_counts", {}),
                "total": sum(summary.get("symbol_counts", {}).values())
            },
            "patterns": {
                "top_patterns": summary.get("top_patterns", [])[:5]
            },
            "key_classes": summary.get("key_classes", [])[:5]
        }
    
    def _generate_detailed_report(self, repo_id: int, summary: dict) -> dict:
        """Generate detailed report with all symbols and patterns."""
        repo = summary.get("repository", {})
        
        # Get all symbols
        all_symbols = self.search.list_symbols(repo_id, "all", limit=1000)
        symbols_list = all_symbols.get("symbols", [])
        
        # Get all patterns
        all_patterns = self.search.find_patterns("all", repo_id=repo_id)
        patterns_list = all_patterns.get("patterns", [])
        
        # Get all imports
        all_imports = self.search.find_imports(repo_id=repo_id, limit=500)
        imports_list = all_imports.get("imports", [])
        
        # Get call graph
        call_graph = self.analysis.get_call_graph(repo_id, output_format="json")
        
        return {
            "title": f"Detailed Repository Analysis: {repo.get('name', 'Unknown')}",
            "generated_at": datetime.now().isoformat(),
            "repository": {
                "id": repo.get("id"),
                "name": repo.get("name"),
                "url": repo.get("url"),
                "last_analyzed": repo.get("last_analyzed")
            },
            "overview": {
                "languages": summary.get("languages", []),
                "total_files": sum(lang.get("file_count", 0) for lang in summary.get("languages", [])),
                "total_lines": sum(lang.get("total_lines", 0) for lang in summary.get("languages", []))
            },
            "symbols": {
                "counts": summary.get("symbol_counts", {}),
                "total": sum(summary.get("symbol_counts", {}).values()),
                "all_symbols": symbols_list
            },
            "patterns": {
                "summary": summary.get("top_patterns", []),
                "all_patterns": patterns_list
            },
            "imports": {
                "summary": summary.get("top_imports", []),
                "all_imports": imports_list
            },
            "call_graph": {
                "nodes": call_graph.get("nodes", []),
                "edges": call_graph.get("edges", []),
                "statistics": call_graph.get("statistics", {})
            },
            "key_classes": summary.get("key_classes", [])
        }
    
    def _generate_dependency_report(self, repo_id: int, summary: dict) -> dict:
        """Generate dependency-focused report."""
        repo = summary.get("repository", {})
        
        # Get all imports
        all_imports = self.search.find_imports(repo_id=repo_id, limit=500)
        imports_list = all_imports.get("imports", [])
        
        # Analyze external dependencies
        external_deps: dict[str, dict] = {}
        internal_deps: dict[str, dict] = {}
        
        for imp in imports_list:
            module = imp.get("module", "")
            is_relative = imp.get("is_relative", False)
            
            if is_relative:
                if module not in internal_deps:
                    internal_deps[module] = {"module": module, "count": 0, "files": []}
                internal_deps[module]["count"] += 1
                if imp.get("file_path") not in internal_deps[module]["files"]:
                    internal_deps[module]["files"].append(imp.get("file_path"))
            else:
                # Classify as standard library or third-party
                base_module = module.split(".")[0] if module else ""
                if base_module not in external_deps:
                    external_deps[base_module] = {
                        "module": base_module,
                        "count": 0,
                        "files": [],
                        "submodules": set()
                    }
                external_deps[base_module]["count"] += 1
                if module != base_module:
                    external_deps[base_module]["submodules"].add(module)
                if imp.get("file_path") not in external_deps[base_module]["files"]:
                    external_deps[base_module]["files"].append(imp.get("file_path"))
        
        # Convert sets to lists for JSON serialization
        for dep in external_deps.values():
            dep["submodules"] = list(dep["submodules"])
        
        # Sort by usage count
        sorted_external = sorted(
            external_deps.values(), 
            key=lambda x: x["count"], 
            reverse=True
        )
        sorted_internal = sorted(
            internal_deps.values(), 
            key=lambda x: x["count"], 
            reverse=True
        )
        
        return {
            "title": f"Dependency Analysis: {repo.get('name', 'Unknown')}",
            "generated_at": datetime.now().isoformat(),
            "repository": {
                "id": repo.get("id"),
                "name": repo.get("name"),
                "url": repo.get("url")
            },
            "summary": {
                "total_imports": len(imports_list),
                "external_modules": len(external_deps),
                "internal_modules": len(internal_deps)
            },
            "external_dependencies": sorted_external,
            "internal_dependencies": sorted_internal,
            "top_dependencies": summary.get("top_imports", [])[:10]
        }
    
    def _generate_architecture_report(self, repo_id: int, summary: dict) -> dict:
        """Generate architecture-focused report with call graph."""
        repo = summary.get("repository", {})
        
        # Get all classes with their methods
        classes_result = self.search.list_symbols(repo_id, "class", limit=500)
        classes = classes_result.get("symbols", [])
        
        # Build class hierarchy
        class_hierarchy: list[dict] = []
        for cls in classes:
            # Get methods for this class
            methods = self.db.execute(
                """SELECT s.name, s.signature, s.docstring, s.start_line, s.end_line, s.metadata
                   FROM symbols s
                   WHERE s.parent_id = ?
                   ORDER BY s.start_line""",
                (cls.get("id"),)
            )
            
            class_info = {
                "name": cls.get("name"),
                "signature": cls.get("signature"),
                "docstring": cls.get("docstring"),
                "file": cls.get("file_path"),
                "line_range": cls.get("line_range"),
                "methods": [
                    {
                        "name": m["name"],
                        "signature": m["signature"],
                        "docstring": m.get("docstring"),
                        "line_range": [m["start_line"], m["end_line"]]
                    }
                    for m in methods
                ],
                "method_count": len(methods)
            }
            class_hierarchy.append(class_info)
        
        # Sort by method count
        class_hierarchy.sort(key=lambda x: x["method_count"], reverse=True)
        
        # Get call graph in both formats
        call_graph_json = self.analysis.get_call_graph(repo_id, output_format="json")
        call_graph_mermaid = self.analysis.get_call_graph(repo_id, output_format="mermaid")
        
        # Get file structure with symbol distribution
        files_result = self.db.execute(
            """SELECT f.path, f.language, f.line_count,
                      COUNT(s.id) as symbol_count,
                      SUM(CASE WHEN s.type = 'function' THEN 1 ELSE 0 END) as function_count,
                      SUM(CASE WHEN s.type = 'class' THEN 1 ELSE 0 END) as class_count,
                      SUM(CASE WHEN s.type = 'method' THEN 1 ELSE 0 END) as method_count
               FROM files f
               LEFT JOIN symbols s ON s.file_id = f.id
               WHERE f.repo_id = ?
               GROUP BY f.id
               ORDER BY symbol_count DESC""",
            (repo_id,)
        )
        
        file_distribution = [
            {
                "path": row["path"],
                "language": row["language"],
                "line_count": row["line_count"],
                "symbol_count": row["symbol_count"] or 0,
                "function_count": row["function_count"] or 0,
                "class_count": row["class_count"] or 0,
                "method_count": row["method_count"] or 0
            }
            for row in files_result
        ]
        
        return {
            "title": f"Architecture Analysis: {repo.get('name', 'Unknown')}",
            "generated_at": datetime.now().isoformat(),
            "repository": {
                "id": repo.get("id"),
                "name": repo.get("name"),
                "url": repo.get("url")
            },
            "overview": {
                "languages": summary.get("languages", []),
                "total_classes": len(class_hierarchy),
                "total_files": len(file_distribution)
            },
            "class_hierarchy": class_hierarchy,
            "file_distribution": file_distribution,
            "call_graph": {
                "json": {
                    "nodes": call_graph_json.get("nodes", []),
                    "edges": call_graph_json.get("edges", []),
                    "statistics": call_graph_json.get("statistics", {})
                },
                "mermaid": call_graph_mermaid.get("diagram", "")
            }
        }
    
    # =========================================================================
    # Output Formatters
    # =========================================================================
    
    def _format_as_json(self, data: dict) -> str:
        """Format report data as JSON string."""
        return json.dumps(data, indent=2, ensure_ascii=False, default=str)
    
    def _format_as_markdown(self, data: dict, report_type: ReportType) -> str:
        """Format report data as Markdown."""
        lines: list[str] = []
        
        # Header
        lines.append(f"# {data.get('title', 'Analysis Report')}")
        lines.append("")
        lines.append(f"*Generated: {data.get('generated_at', 'Unknown')}*")
        lines.append("")
        
        # Repository info
        repo = data.get("repository", {})
        lines.append("## Repository Information")
        lines.append("")
        lines.append(f"- **Name:** {repo.get('name', 'Unknown')}")
        lines.append(f"- **URL:** {repo.get('url', 'N/A')}")
        if repo.get("last_analyzed"):
            lines.append(f"- **Last Analyzed:** {repo.get('last_analyzed')}")
        lines.append("")
        
        # Type-specific sections
        if report_type == "summary":
            lines.extend(self._format_summary_sections(data))
        elif report_type == "detailed":
            lines.extend(self._format_detailed_sections(data))
        elif report_type == "dependencies":
            lines.extend(self._format_dependency_sections(data))
        elif report_type == "architecture":
            lines.extend(self._format_architecture_sections(data))
        
        return "\n".join(lines)
    
    def _format_summary_sections(self, data: dict) -> list[str]:
        """Format summary report sections as Markdown."""
        lines: list[str] = []
        
        # Overview
        overview = data.get("overview", {})
        lines.append("## Overview")
        lines.append("")
        lines.append(f"- **Total Files:** {overview.get('total_files', 0)}")
        lines.append(f"- **Total Lines:** {overview.get('total_lines', 0):,}")
        lines.append("")
        
        # Languages
        languages = overview.get("languages", [])
        if languages:
            lines.append("### Language Breakdown")
            lines.append("")
            lines.append("| Language | Files | Lines |")
            lines.append("|----------|-------|-------|")
            for lang in languages:
                lines.append(f"| {lang.get('language', 'Unknown')} | {lang.get('file_count', 0)} | {lang.get('total_lines', 0):,} |")
            lines.append("")
        
        # Symbols
        symbols = data.get("symbols", {})
        counts = symbols.get("counts", {})
        if counts:
            lines.append("## Symbol Statistics")
            lines.append("")
            lines.append(f"**Total Symbols:** {symbols.get('total', 0)}")
            lines.append("")
            for stype, count in counts.items():
                lines.append(f"- {stype.capitalize()}: {count}")
            lines.append("")
        
        # Top Patterns
        patterns = data.get("patterns", {}).get("top_patterns", [])
        if patterns:
            lines.append("## Top Detected Patterns")
            lines.append("")
            lines.append("| Type | Pattern | Occurrences |")
            lines.append("|------|---------|-------------|")
            for p in patterns:
                lines.append(f"| {p.get('pattern_type', '')} | {p.get('pattern_name', '')} | {p.get('count', 0)} |")
            lines.append("")
        
        # Key Classes
        key_classes = data.get("key_classes", [])
        if key_classes:
            lines.append("## Key Classes")
            lines.append("")
            for cls in key_classes:
                lines.append(f"### `{cls.get('name', 'Unknown')}`")
                lines.append("")
                lines.append(f"- **File:** `{cls.get('file_path', 'Unknown')}`")
                lines.append(f"- **Methods:** {cls.get('method_count', 0)}")
                if cls.get("docstring"):
                    lines.append(f"- **Description:** {cls.get('docstring')[:200]}...")
                lines.append("")
        
        return lines
    
    def _format_detailed_sections(self, data: dict) -> list[str]:
        """Format detailed report sections as Markdown."""
        lines: list[str] = []
        
        # Include summary sections first
        lines.extend(self._format_summary_sections(data))
        
        # All Patterns
        all_patterns = data.get("patterns", {}).get("all_patterns", [])
        if all_patterns:
            lines.append("## All Detected Patterns")
            lines.append("")
            lines.append("| Type | Pattern | Confidence | Evidence |")
            lines.append("|------|---------|------------|----------|")
            for p in all_patterns[:50]:  # Limit to 50 for readability
                evidence = p.get("evidence", "")[:50]
                lines.append(
                    f"| {p.get('pattern_type', '')} | {p.get('pattern_name', '')} | "
                    f"{p.get('confidence', 0):.2f} | {evidence}... |"
                )
            if len(all_patterns) > 50:
                lines.append(f"\n*... and {len(all_patterns) - 50} more patterns*")
            lines.append("")
        
        # All Symbols (grouped by type)
        all_symbols = data.get("symbols", {}).get("all_symbols", [])
        if all_symbols:
            lines.append("## All Symbols")
            lines.append("")
            
            # Group by type
            by_type: dict[str, list] = {}
            for sym in all_symbols:
                stype = sym.get("type", "unknown")
                if stype not in by_type:
                    by_type[stype] = []
                by_type[stype].append(sym)
            
            for stype, symbols in by_type.items():
                lines.append(f"### {stype.capitalize()}s ({len(symbols)})")
                lines.append("")
                for sym in symbols[:30]:  # Limit per type
                    lines.append(f"- `{sym.get('signature', sym.get('name', 'Unknown'))}` - `{sym.get('file_path', '')}`")
                if len(symbols) > 30:
                    lines.append(f"\n*... and {len(symbols) - 30} more {stype}s*")
                lines.append("")
        
        # Call Graph Statistics
        call_graph = data.get("call_graph", {})
        stats = call_graph.get("statistics", {})
        if stats:
            lines.append("## Call Graph Statistics")
            lines.append("")
            lines.append(f"- **Total Nodes:** {stats.get('total_nodes', 0)}")
            lines.append(f"- **Total Edges:** {stats.get('total_edges', 0)}")
            lines.append(f"- **External Calls:** {stats.get('external_calls', 0)}")
            lines.append(f"- **Resolved Calls:** {stats.get('resolved_calls', 0)}")
            lines.append("")
        
        return lines
    
    def _format_dependency_sections(self, data: dict) -> list[str]:
        """Format dependency report sections as Markdown."""
        lines: list[str] = []
        
        # Summary
        summary = data.get("summary", {})
        lines.append("## Dependency Summary")
        lines.append("")
        lines.append(f"- **Total Imports:** {summary.get('total_imports', 0)}")
        lines.append(f"- **External Modules:** {summary.get('external_modules', 0)}")
        lines.append(f"- **Internal Modules:** {summary.get('internal_modules', 0)}")
        lines.append("")
        
        # External Dependencies
        external = data.get("external_dependencies", [])
        if external:
            lines.append("## External Dependencies")
            lines.append("")
            lines.append("| Module | Usage Count | Used In Files | Submodules |")
            lines.append("|--------|-------------|---------------|------------|")
            for dep in external[:20]:
                files_count = len(dep.get("files", []))
                submodules = ", ".join(dep.get("submodules", [])[:3])
                if len(dep.get("submodules", [])) > 3:
                    submodules += "..."
                lines.append(
                    f"| {dep.get('module', '')} | {dep.get('count', 0)} | "
                    f"{files_count} | {submodules or '-'} |"
                )
            if len(external) > 20:
                lines.append(f"\n*... and {len(external) - 20} more modules*")
            lines.append("")
        
        # Internal Dependencies
        internal = data.get("internal_dependencies", [])
        if internal:
            lines.append("## Internal Dependencies")
            lines.append("")
            lines.append("| Module | Usage Count | Used In Files |")
            lines.append("|--------|-------------|---------------|")
            for dep in internal[:20]:
                files_count = len(dep.get("files", []))
                lines.append(
                    f"| {dep.get('module', '') or '(relative)'} | "
                    f"{dep.get('count', 0)} | {files_count} |"
                )
            if len(internal) > 20:
                lines.append(f"\n*... and {len(internal) - 20} more modules*")
            lines.append("")
        
        return lines
    
    def _format_architecture_sections(self, data: dict) -> list[str]:
        """Format architecture report sections as Markdown."""
        lines: list[str] = []
        
        # Overview
        overview = data.get("overview", {})
        lines.append("## Architecture Overview")
        lines.append("")
        lines.append(f"- **Total Classes:** {overview.get('total_classes', 0)}")
        lines.append(f"- **Total Files:** {overview.get('total_files', 0)}")
        lines.append("")
        
        # Languages
        languages = overview.get("languages", [])
        if languages:
            lines.append("### Language Distribution")
            lines.append("")
            for lang in languages:
                lines.append(
                    f"- **{lang.get('language', 'Unknown')}:** "
                    f"{lang.get('file_count', 0)} files, {lang.get('total_lines', 0):,} lines"
                )
            lines.append("")
        
        # Class Hierarchy
        class_hierarchy = data.get("class_hierarchy", [])
        if class_hierarchy:
            lines.append("## Class Hierarchy")
            lines.append("")
            for cls in class_hierarchy[:10]:
                lines.append(f"### `{cls.get('name', 'Unknown')}`")
                lines.append("")
                lines.append(f"- **File:** `{cls.get('file', 'Unknown')}`")
                lines.append(f"- **Lines:** {cls.get('line_range', [0, 0])[0]}-{cls.get('line_range', [0, 0])[1]}")
                lines.append(f"- **Methods:** {cls.get('method_count', 0)}")
                if cls.get("docstring"):
                    lines.append(f"- **Description:** {cls.get('docstring')[:150]}...")
                lines.append("")
                
                methods = cls.get("methods", [])
                if methods:
                    lines.append("**Methods:**")
                    lines.append("")
                    for method in methods[:10]:
                        lines.append(f"  - `{method.get('name', 'Unknown')}` (lines {method.get('line_range', [0, 0])[0]}-{method.get('line_range', [0, 0])[1]})")
                    if len(methods) > 10:
                        lines.append(f"  - *... and {len(methods) - 10} more methods*")
                    lines.append("")
            
            if len(class_hierarchy) > 10:
                lines.append(f"*... and {len(class_hierarchy) - 10} more classes*")
                lines.append("")
        
        # File Distribution
        file_distribution = data.get("file_distribution", [])
        if file_distribution:
            lines.append("## File Distribution")
            lines.append("")
            lines.append("| File | Lines | Functions | Classes | Methods |")
            lines.append("|------|-------|-----------|---------|---------|")
            for f in file_distribution[:20]:
                lines.append(
                    f"| `{f.get('path', '')}` | {f.get('line_count', 0)} | "
                    f"{f.get('function_count', 0)} | {f.get('class_count', 0)} | "
                    f"{f.get('method_count', 0)} |"
                )
            if len(file_distribution) > 20:
                lines.append(f"\n*... and {len(file_distribution) - 20} more files*")
            lines.append("")
        
        # Call Graph (Mermaid)
        mermaid = data.get("call_graph", {}).get("mermaid", "")
        if mermaid:
            lines.append("## Call Graph")
            lines.append("")
            lines.append("```mermaid")
            lines.append(mermaid)
            lines.append("```")
            lines.append("")
        
        return lines
    
    def _format_as_html(self, data: dict, report_type: ReportType) -> str:
        """Format report data as HTML."""
        # Convert Markdown to HTML with basic styling
        md_content = self._format_as_markdown(data, report_type)
        
        html_parts = [
            "<!DOCTYPE html>",
            "<html lang='en'>",
            "<head>",
            "  <meta charset='UTF-8'>",
            "  <meta name='viewport' content='width=device-width, initial-scale=1.0'>",
            f"  <title>{data.get('title', 'Analysis Report')}</title>",
            "  <style>",
            "    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; line-height: 1.6; }",
            "    h1 { border-bottom: 2px solid #333; padding-bottom: 10px; }",
            "    h2 { color: #2c3e50; margin-top: 30px; border-bottom: 1px solid #ddd; padding-bottom: 5px; }",
            "    h3 { color: #34495e; }",
            "    table { border-collapse: collapse; width: 100%; margin: 15px 0; }",
            "    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }",
            "    th { background-color: #f5f5f5; font-weight: 600; }",
            "    tr:nth-child(even) { background-color: #fafafa; }",
            "    code { background-color: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-family: 'Monaco', 'Consolas', monospace; }",
            "    pre { background-color: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; }",
            "    .mermaid { background-color: #fff; padding: 20px; }",
            "    ul { padding-left: 20px; }",
            "    em { color: #666; }",
            "  </style>",
            "  <script src='https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js'></script>",
            "  <script>mermaid.initialize({startOnLoad:true});</script>",
            "</head>",
            "<body>",
        ]
        
        # Convert Markdown to HTML (basic conversion)
        html_content = self._md_to_html(md_content)
        html_parts.append(html_content)
        
        html_parts.extend([
            "</body>",
            "</html>"
        ])
        
        return "\n".join(html_parts)
    
    def _md_to_html(self, md: str) -> str:
        """Convert basic Markdown to HTML."""
        import re
        
        lines = md.split("\n")
        html_lines: list[str] = []
        in_table = False
        in_code_block = False
        in_list = False
        
        for line in lines:
            # Code blocks
            if line.startswith("```"):
                if in_code_block:
                    if "mermaid" in html_lines[-1] if html_lines else "":
                        html_lines.append("</div>")
                    else:
                        html_lines.append("</code></pre>")
                    in_code_block = False
                else:
                    lang = line[3:].strip()
                    if lang == "mermaid":
                        html_lines.append("<div class='mermaid'>")
                    else:
                        html_lines.append(f"<pre><code class='language-{lang}'>")
                    in_code_block = True
                continue
            
            if in_code_block:
                html_lines.append(line)
                continue
            
            # Tables
            if line.startswith("|"):
                if not in_table:
                    html_lines.append("<table>")
                    in_table = True
                
                if line.replace("|", "").replace("-", "").strip() == "":
                    continue  # Skip separator line
                
                cells = [c.strip() for c in line.split("|")[1:-1]]
                if not any(html_lines[-1:]) or "<table>" in html_lines[-1]:
                    html_lines.append("<thead><tr>")
                    for cell in cells:
                        html_lines.append(f"<th>{self._inline_md(cell)}</th>")
                    html_lines.append("</tr></thead><tbody>")
                else:
                    html_lines.append("<tr>")
                    for cell in cells:
                        html_lines.append(f"<td>{self._inline_md(cell)}</td>")
                    html_lines.append("</tr>")
                continue
            elif in_table:
                html_lines.append("</tbody></table>")
                in_table = False
            
            # Headers
            if line.startswith("# "):
                html_lines.append(f"<h1>{self._inline_md(line[2:])}</h1>")
            elif line.startswith("## "):
                html_lines.append(f"<h2>{self._inline_md(line[3:])}</h2>")
            elif line.startswith("### "):
                html_lines.append(f"<h3>{self._inline_md(line[4:])}</h3>")
            # Lists
            elif line.startswith("- "):
                if not in_list:
                    html_lines.append("<ul>")
                    in_list = True
                html_lines.append(f"<li>{self._inline_md(line[2:])}</li>")
            elif line.startswith("  - "):
                html_lines.append(f"<li style='margin-left:20px'>{self._inline_md(line[4:])}</li>")
            elif in_list and line.strip() == "":
                html_lines.append("</ul>")
                in_list = False
            # Paragraphs
            elif line.strip():
                html_lines.append(f"<p>{self._inline_md(line)}</p>")
            else:
                if in_list:
                    html_lines.append("</ul>")
                    in_list = False
        
        # Close any open tags
        if in_table:
            html_lines.append("</tbody></table>")
        if in_list:
            html_lines.append("</ul>")
        
        return "\n".join(html_lines)
    
    def _inline_md(self, text: str) -> str:
        """Convert inline Markdown to HTML."""
        import re
        
        # Bold
        text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', text)
        # Italic
        text = re.sub(r'\*(.+?)\*', r'<em>\1</em>', text)
        # Code
        text = re.sub(r'`(.+?)`', r'<code>\1</code>', text)
        
        return text
    
    def _save_report(
        self, 
        content: str, 
        save_path: str, 
        output_format: OutputFormat
    ) -> str:
        """Save report to file."""
        path = Path(save_path)
        
        # Add extension if not present
        ext_map = {"json": ".json", "markdown": ".md", "html": ".html"}
        expected_ext = ext_map.get(output_format, "")
        if not path.suffix:
            path = path.with_suffix(expected_ext)
        
        # Create directory if needed
        path.parent.mkdir(parents=True, exist_ok=True)
        
        # Write file
        path.write_text(content, encoding="utf-8")
        
        return str(path.resolve())
