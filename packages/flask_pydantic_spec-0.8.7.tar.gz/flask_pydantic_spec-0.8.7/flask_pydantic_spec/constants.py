OPENAPI_SCHEMA_TEMPLATE = "#/components/schemas/{model}"
