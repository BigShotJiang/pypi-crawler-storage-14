"""MCP Server for Weather Api167"""
