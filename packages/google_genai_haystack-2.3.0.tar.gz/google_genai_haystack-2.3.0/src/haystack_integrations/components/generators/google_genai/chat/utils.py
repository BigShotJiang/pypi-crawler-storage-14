# SPDX-FileCopyrightText: 2023-present deepset GmbH <info@deepset.ai>
#
# SPDX-License-Identifier: Apache-2.0

from typing import Any, Union


def remove_key_from_schema(
    schema: Union[dict[str, Any], list[Any], Any], target_key: str
) -> Union[dict[str, Any], list[Any], Any]:
    """
    Recursively traverse a schema and remove all occurrences of the target key.


    :param schema: The schema dictionary/list/value to process
    :param target_key: The key to remove from all dictionaries in the schema

    :returns: The schema with the target key removed from all nested dictionaries
    """
    if isinstance(schema, dict):
        # Create a new dict without the target key
        result = {}
        for k, v in schema.items():
            if k != target_key:
                result[k] = remove_key_from_schema(v, target_key)
        return result

    elif isinstance(schema, list):
        return [remove_key_from_schema(item, target_key) for item in schema]

    return schema
