---
name: General feature request
about: Suggest a general feature, or feature within an already existing step
title: ''
type: Feature
assignees: ''

---

## Checklist

- [ ] I have searched the issue tracker for relevant or duplicate issues.

## I want to suggest some general feature

Topgrade should...

## More information

<!-- Assuming that someone else implements the feature,
please state if you know how to test it from a side branch of Topgrade. -->

- [ ] I am able and willing to implement this feature myself
