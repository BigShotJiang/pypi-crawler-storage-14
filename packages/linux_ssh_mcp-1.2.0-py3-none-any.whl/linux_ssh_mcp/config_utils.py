#!/usr/bin/env python3
"""
配置文件路径处理工具模块
解决pip安装环境下配置文件位置不统一的问题
"""

import os
import sys
import json
import platform
import time
from pathlib import Path
from typing import Optional, Dict, Any
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()


# Configuration path caching to improve performance
_config_path_cache = {}
_cache_timeout = 300  # 5 minutes


def get_config_file_path(config_name: str = "servers.json") -> str:
    """
    获取配置文件路径，支持多种环境和安装方式

    Args:
        config_name: 配置文件名，默认为"servers.json"

    Returns:
        配置文件的绝对路径
    """
    # Check cache first
    cache_key = config_name
    current_time = time.time()

    if cache_key in _config_path_cache:
        cached_path, cached_time = _config_path_cache[cache_key]
        if current_time - cached_time < _cache_timeout:
            return cached_path

    # 路径搜索优先级（从高到低）：
    # 1. 环境变量指定的路径
    # 2. 用户主目录下的 .ssh-mcp 目录
    # 3. 平台特定的配置目录
    # 4. 当前工作目录（用于向后兼容）

    candidate_paths = []

    # 1. 检查环境变量
    env_config_path = os.environ.get("SSH_MCP_CONFIG_PATH")
    if env_config_path:
        candidate_paths.append(Path(env_config_path) / config_name)

    # 2. 用户主目录配置
    home_config_dir = Path.home() / ".ssh-mcp"
    candidate_paths.append(home_config_dir / config_name)

    # 3. 平台特定配置目录
    if platform.system() == "Windows":
        # Windows: %APPDATA%/ssh-mcp/
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            platform_config_dir = Path(appdata) / "ssh-mcp"
            candidate_paths.append(platform_config_dir / config_name)
    else:
        # Linux/Mac: ~/.config/ssh-mcp/
        default_config = str(Path.home() / ".config")
        config_home = os.environ.get("XDG_CONFIG_HOME", default_config)
        platform_config_dir = Path(config_home) / "ssh-mcp"
        candidate_paths.append(platform_config_dir / config_name)

    # 4. 当前工作目录（向后兼容）
    candidate_paths.append(Path.cwd() / config_name)

    # 5. 项目根目录（开发环境）
    if getattr(sys, "frozen", False):
        # 如果是打包的可执行文件
        if platform.system() == "Windows":
            _ = Path(sys.executable).parent
        else:
            _ = Path(sys.executable).parent
    else:
        # 如果是源码运行，尝试找到项目根目录
        try:
            current_file = Path(__file__).resolve()
            # 从 src/linux_ssh_mcp/config_utils.py 回退到项目根目录
            project_root = current_file.parent.parent.parent
            candidate_paths.append(project_root / config_name)
        except (NameError, AttributeError):
            # 如果无法确定项目根目录，跳过
            pass

    # 搜索第一个已存在的配置文件
    for config_path in candidate_paths:
        if config_path.exists():
            result_path = str(config_path)
            _config_path_cache[cache_key] = (result_path, current_time)
            return result_path

    # 如果都不存在，选择第一个可用的路径（优先用户主目录）
    for config_path in candidate_paths:
        try:
            # 尝试创建目录
            config_path.parent.mkdir(parents=True, exist_ok=True)
            result_path = str(config_path)
            _config_path_cache[cache_key] = (result_path, current_time)
            return result_path
        except (PermissionError, OSError):
            continue

    # 如果所有路径都不可用，回退到当前工作目录
    result_path = str(Path.cwd() / config_name)
    _config_path_cache[cache_key] = (result_path, current_time)
    return result_path


def clear_config_cache():
    """Clear the configuration path cache"""
    global _config_path_cache
    _config_path_cache.clear()


def get_config_file_path_cached(config_name: str = "servers.json") -> str:
    """
    获取配置文件路径，支持多种环境和安装方式

    Args:
        config_name: 配置文件名，默认为"servers.json"

    Returns:
        配置文件的绝对路径
    """
    # 路径搜索优先级（从高到低）：
    # 1. 环境变量指定的路径
    # 2. 用户主目录下的 .ssh-mcp 目录
    # 3. 平台特定的配置目录
    # 4. 当前工作目录（用于向后兼容）

    candidate_paths = []

    # 1. 检查环境变量
    env_config_path = os.environ.get("SSH_MCP_CONFIG_PATH")
    if env_config_path:
        candidate_paths.append(Path(env_config_path) / config_name)

    # 2. 用户主目录配置
    home_config_dir = Path.home() / ".ssh-mcp"
    candidate_paths.append(home_config_dir / config_name)

    # 3. 平台特定配置目录
    if platform.system() == "Windows":
        # Windows: %APPDATA%/ssh-mcp/
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            platform_config_dir = Path(appdata) / "ssh-mcp"
            candidate_paths.append(platform_config_dir / config_name)
    else:
        # Linux/Mac: ~/.config/ssh-mcp/
        default_config = str(Path.home() / ".config")
        config_home = os.environ.get("XDG_CONFIG_HOME", default_config)
        platform_config_dir = Path(config_home) / "ssh-mcp"
        candidate_paths.append(platform_config_dir / config_name)

    # 4. 当前工作目录（向后兼容）
    candidate_paths.append(Path.cwd() / config_name)

    # 5. 项目根目录（开发环境）
    if getattr(sys, "frozen", False):
        # 如果是打包的可执行文件
        if platform.system() == "Windows":
            _ = Path(sys.executable).parent
        else:
            _ = Path(sys.executable).parent
    else:
        # 如果是源码运行，尝试找到项目根目录
        try:
            current_file = Path(__file__).resolve()
            # 从 src/linux_ssh_mcp/config_utils.py 回退到项目根目录
            project_root = current_file.parent.parent.parent
            candidate_paths.append(project_root / config_name)
        except (NameError, AttributeError):
            # 如果无法确定项目根目录，跳过
            pass

    # 搜索第一个已存在的配置文件
    for config_path in candidate_paths:
        if config_path.exists():
            return str(config_path)

    # 如果都不存在，选择第一个可用的路径（优先用户主目录）
    for config_path in candidate_paths:
        try:
            # 尝试创建目录
            config_path.parent.mkdir(parents=True, exist_ok=True)
            return str(config_path)
        except (PermissionError, OSError):
            continue

    # 如果所有路径都不可用，回退到当前工作目录
    return str(Path.cwd() / config_name)


def load_config_file(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    加载配置文件

    Args:
        config_path: 配置文件路径，如果为None则使用默认路径

    Returns:
        配置字典
    """
    if config_path is None:
        config_path = get_config_file_path("config.json")

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"配置文件不存在: {config_path}")
        return {}
    except json.JSONDecodeError as e:
        print(f"配置文件格式错误: {e}")
        return {}
    except Exception as e:
        print(f"加载配置文件失败: {e}")
        return {}


def save_config_file(
    config_data: Dict[str, Any], config_path: Optional[str] = None
) -> bool:
    """
    保存配置文件

    Args:
        config_data: 配置数据字典
        config_path: 配置文件路径，如果为None则使用默认路径

    Returns:
        保存是否成功
    """
    if config_path is None:
        config_path = get_config_file_path("config.json")

    try:
        # 确保配置目录存在
        Path(config_path).parent.mkdir(parents=True, exist_ok=True)

        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config_data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"保存配置文件失败: {e}")
        return False


def get_setting_value(key: str, default_value: Any = None) -> Any:
    """
    获取配置值，支持嵌套键 (如 "grafana.url")

    Args:
        key: 配置键，支持点分隔的嵌套键
        default_value: 默认值

    Returns:
        配置值
    """
    # 首先检查环境变量
    env_key = f"SSH_MCP_{key.upper().replace('.', '_')}"
    env_value = os.getenv(env_key)
    if env_value is not None:
        # 尝试转换数据类型
        if isinstance(default_value, bool):
            return env_value.lower() in ("true", "1", "yes", "on")
        elif isinstance(default_value, int):
            try:
                return int(env_value)
            except ValueError:
                pass
        elif isinstance(default_value, float):
            try:
                return float(env_value)
            except ValueError:
                pass
        return env_value

    # 然后检查配置文件
    config = load_config_file()
    keys = key.split(".")
    value = config

    try:
        for k in keys:
            value = value[k]
        return value
    except (KeyError, TypeError):
        return default_value


def validate_config() -> bool:
    """
    验证配置的有效性

    Returns:
        配置是否有效
    """
    try:
        from .settings import Settings

        settings = Settings.from_file(get_config_file_path("config.json"))
        return settings.validate()
    except Exception as e:
        print(f"配置验证失败: {e}")
        return False


def create_default_config() -> bool:
    """
    创建默认配置文件

    Returns:
        创建是否成功
    """
    template_path = (
        Path(__file__).parent.parent.parent / "config_template.json"
    )
    config_path = get_config_file_path("config.json")

    try:
        if template_path.exists():
            # 使用模板文件
            with open(template_path, "r", encoding="utf-8") as f:
                config_data = json.load(f)
        else:
            # 创建基本配置
            config_data = {
                "grafana": {
                    "url": "https://localhost:3000",
                    "username": "",
                    "password": "",
                    "api_key": "",
                    "timeout": 30,
                    "verify_ssl": True,
                },
                "security": {
                    "session_timeout": 3600,
                    "max_sessions_per_user": 10,
                    "password_min_length": 8,
                },
                "connection": {
                    "default_ssh_port": 22,
                    "connection_timeout": 30,
                    "command_timeout": 300,
                },
                "monitoring": {"prometheus_port": 8000, "log_level": "INFO"},
            }

        return save_config_file(config_data, config_path)
    except Exception as e:
        print(f"创建默认配置失败: {e}")
        return False


def get_config_directory() -> str:
    """
    获取配置文件目录路径

    Returns:
        配置目录的绝对路径
    """
    config_path = get_config_file_path()
    return str(Path(config_path).parent)


def ensure_config_exists(config_path: Optional[str] = None) -> str:
    """
    确保配置文件存在，如果不存在则创建默认配置

    Args:
        config_path: 可选的配置文件路径，如果不提供则使用默认路径

    Returns:
        配置文件的路径
    """
    if config_path is None:
        config_path = get_config_file_path()

    config_file = Path(config_path)

    # 如果配置文件不存在，创建默认配置
    if not config_file.exists():
        try:
            # 确保目录存在
            config_file.parent.mkdir(parents=True, exist_ok=True)

            # 创建默认配置
            default_config = {
                "version": "1.0",
                "servers": {},
                "created_at": (
                    str(Path(config_path).stat().st_mtime)
                    if config_file.exists()
                    else ""
                ),
                "description": "Linux SSH MCP 服务器配置文件",
            }

            with open(config_file, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=2, ensure_ascii=False)

        except (PermissionError, OSError) as e:
            raise RuntimeError(f"无法创建配置文件 {config_path}: {e}")

    return str(config_file)


def get_default_servers_config() -> Dict[str, Any]:
    """
    获取默认的服务器配置结构

    Returns:
        默认配置字典
    """
    return {
        "version": "1.0",
        "servers": {},
        "settings": {
            "default_timeout": 30,
            "default_port": 22,
            "default_username": "root",
            "connection_pool_size": 10,
            "auto_save": True,
        },
        "description": "Linux SSH MCP 服务器配置文件",
    }


def validate_config_file(config_path: str) -> bool:
    """
    验证配置文件格式是否正确

    Args:
        config_path: 配置文件路径

    Returns:
        配置文件是否有效
    """
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)

        # 基本结构验证
        if not isinstance(config, dict):
            return False

        # 检查是否包含 servers 字段
        if "servers" not in config:
            return False

        # 验证 servers 字段格式
        if not isinstance(config["servers"], dict):
            return False

        # 验证每个服务器配置
        for server_id, server_config in config["servers"].items():
            if not isinstance(server_config, dict):
                return False

            required_fields = ["id", "host", "port", "username"]
            for field in required_fields:
                if field not in server_config:
                    return False

        return True

    except (json.JSONDecodeError, FileNotFoundError, PermissionError):
        return False


def get_config_info() -> Dict[str, Any]:
    """
    获取配置文件信息，用于调试和诊断

    Returns:
        包含配置文件信息的字典
    """
    config_path = get_config_file_path()
    config_file = Path(config_path)

    info = {
        "config_path": config_path,
        "config_directory": str(config_file.parent),
        "config_exists": config_file.exists(),
        "platform": platform.system(),
        "python_version": sys.version,
        "environment_variables": {
            "SSH_MCP_CONFIG_PATH": os.environ.get("SSH_MCP_CONFIG_PATH"),
            "XDG_CONFIG_HOME": os.environ.get("XDG_CONFIG_HOME"),
            "APPDATA": (
                os.environ.get("APPDATA")
                if platform.system() == "Windows" else None
            ),
        },
        "candidate_paths": [],
    }

    # 添加候选路径信息
    home_config_dir = Path.home() / ".ssh-mcp"
    info["candidate_paths"].append(str(home_config_dir / "servers.json"))

    if platform.system() == "Windows":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            platform_config_dir = Path(appdata) / "ssh-mcp"
            servers_json_path = str(platform_config_dir / "servers.json")
        info["candidate_paths"].append(servers_json_path)
    else:
        default_config = str(Path.home() / ".config")
        config_home = os.environ.get("XDG_CONFIG_HOME", default_config)
        platform_config_dir = Path(config_home) / "ssh-mcp"
        servers_json_path = str(platform_config_dir / "servers.json")
        info["candidate_paths"].append(servers_json_path)

    info["candidate_paths"].append(str(Path.cwd() / "servers.json"))

    if config_file.exists():
        try:
            stat = config_file.stat()
            info["file_info"] = {
                "size": stat.st_size,
                "modified": stat.st_mtime,
                "is_readable": os.access(config_path, os.R_OK),
                "is_writable": os.access(config_path, os.W_OK),
                "is_valid": validate_config_file(config_path),
            }
        except OSError as e:
            info["file_info"] = {"error": str(e)}

    return info


if __name__ == "__main__":
    # 测试配置文件路径检测
    print("=== Linux SSH MCP 配置文件路径检测 ===")
    info = get_config_info()

    print(f"配置文件路径: {info['config_path']}")
    print(f"配置目录: {info['config_directory']}")
    print(f"文件是否存在: {info['config_exists']}")
    print(f"平台: {info['platform']}")

    if info.get("file_info"):
        file_info = info["file_info"]
        print(f"文件大小: {file_info.get('size', 'N/A')} 字节")
        print(f"文件可读: {file_info.get('is_readable', 'N/A')}")
        print(f"文件可写: {file_info.get('is_writable', 'N/A')}")
        print(f"配置有效: {file_info.get('is_valid', 'N/A')}")

    print("\n候选路径:")
    for i, path in enumerate(info["candidate_paths"], 1):
        exists = Path(path).exists()
        print(f"  {i}. {path} {'✓' if exists else '✗'}")
