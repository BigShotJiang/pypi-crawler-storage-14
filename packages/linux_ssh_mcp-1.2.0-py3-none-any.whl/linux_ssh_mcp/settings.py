#!/usr/bin/env python3
"""
配置设置模块

集中管理所有配置项，避免硬编码，支持环境变量和配置文件
"""

import os
from typing import Optional, Dict, Any
from pathlib import Path
from dataclasses import dataclass
import json


@dataclass
class GrafanaSettings:
    """Grafana相关配置"""

    url: str = "https://localhost:3000"
    username: str = ""
    password: str = ""
    api_key: Optional[str] = None
    timeout: int = 30
    verify_ssl: bool = True

    @classmethod
    def from_env(cls) -> "GrafanaSettings":
        """从环境变量加载配置"""
        return cls(
            url=os.getenv("GRAFANA_URL", "https://localhost:3000"),
            username=os.getenv("GRAFANA_USERNAME", ""),
            password=os.getenv("GRAFANA_PASSWORD", ""),
            api_key=os.getenv("GRAFANA_API_KEY"),
            timeout=int(os.getenv("GRAFANA_TIMEOUT", "30")),
            verify_ssl=os.getenv("GRAFANA_VERIFY_SSL", "true").lower() == "true",
        )


@dataclass
class SecuritySettings:
    """安全相关配置"""

    session_timeout: int = 3600  # 1小时
    max_sessions_per_user: int = 10
    password_min_length: int = 8
    api_key_prefix: str = "sshmcp_"
    bcrypt_rounds: int = 12
    token_length: int = 32
    session_id_length: int = 32

    @classmethod
    def from_env(cls) -> "SecuritySettings":
        """从环境变量加载配置"""
        return cls(
            session_timeout=int(os.getenv("SSH_MCP_SESSION_TIMEOUT", "3600")),
            max_sessions_per_user=int(os.getenv("SSH_MCP_MAX_SESSIONS_PER_USER", "10")),
            password_min_length=int(os.getenv("SSH_MCP_PASSWORD_MIN_LENGTH", "8")),
            api_key_prefix=os.getenv("SSH_MCP_API_KEY_PREFIX", "sshmcp_"),
            bcrypt_rounds=int(os.getenv("SSH_MCP_BCRYPT_ROUNDS", "12")),
            token_length=int(os.getenv("SSH_MCP_TOKEN_LENGTH", "32")),
            session_id_length=int(os.getenv("SSH_MCP_SESSION_ID_LENGTH", "32")),
        )


@dataclass
class ConnectionSettings:
    """连接相关配置"""

    default_ssh_port: int = 22
    connection_timeout: int = 30
    command_timeout: int = 300
    max_concurrent_connections: int = 100
    connection_pool_size: int = 50
    retry_attempts: int = 3
    retry_delay: float = 1.0

    @classmethod
    def from_env(cls) -> "ConnectionSettings":
        """从环境变量加载配置"""
        return cls(
            default_ssh_port=int(os.getenv("SSH_MCP_DEFAULT_PORT", "22")),
            connection_timeout=int(os.getenv("SSH_MCP_CONNECTION_TIMEOUT", "30")),
            command_timeout=int(os.getenv("SSH_MCP_COMMAND_TIMEOUT", "300")),
            max_concurrent_connections=int(os.getenv("SSH_MCP_MAX_CONCURRENT", "100")),
            connection_pool_size=int(os.getenv("SSH_MCP_POOL_SIZE", "50")),
            retry_attempts=int(os.getenv("SSH_MCP_RETRY_ATTEMPTS", "3")),
            retry_delay=float(os.getenv("SSH_MCP_RETRY_DELAY", "1.0")),
        )


@dataclass
class MonitoringSettings:
    """监控相关配置"""

    prometheus_port: int = 8000
    metrics_update_interval: int = 60
    health_check_interval: int = 30
    log_level: str = "INFO"
    log_file_path: Optional[str] = None
    enable_audit_log: bool = True

    @classmethod
    def from_env(cls) -> "MonitoringSettings":
        """从环境变量加载配置"""
        return cls(
            prometheus_port=int(os.getenv("SSH_MCP_PROMETHEUS_PORT", "8000")),
            metrics_update_interval=int(os.getenv("SSH_MCP_METRICS_INTERVAL", "60")),
            health_check_interval=int(os.getenv("SSH_MCP_HEALTH_CHECK_INTERVAL", "30")),
            log_level=os.getenv("SSH_MCP_LOG_LEVEL", "INFO"),
            log_file_path=os.getenv("SSH_MCP_LOG_FILE"),
            enable_audit_log=os.getenv("SSH_MCP_ENABLE_AUDIT_LOG", "true").lower()
            == "true",
        )


class Settings:
    """主配置类"""

    def __init__(self):
        self.grafana = GrafanaSettings.from_env()
        self.security = SecuritySettings.from_env()
        self.connection = ConnectionSettings.from_env()
        self.monitoring = MonitoringSettings.from_env()

    @classmethod
    def from_file(cls, config_path: str) -> "Settings":
        """从配置文件加载设置"""
        if not os.path.exists(config_path):
            return cls()

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config_data = json.load(f)

            settings = cls()

            # 更新Grafana设置
            if "grafana" in config_data:
                grafana_config = config_data["grafana"]
                for key, value in grafana_config.items():
                    if hasattr(settings.grafana, key):
                        setattr(settings.grafana, key, value)

            # 更新安全设置
            if "security" in config_data:
                security_config = config_data["security"]
                for key, value in security_config.items():
                    if hasattr(settings.security, key):
                        setattr(settings.security, key, value)

            # 更新连接设置
            if "connection" in config_data:
                connection_config = config_data["connection"]
                for key, value in connection_config.items():
                    if hasattr(settings.connection, key):
                        setattr(settings.connection, key, value)

            # 更新监控设置
            if "monitoring" in config_data:
                monitoring_config = config_data["monitoring"]
                for key, value in monitoring_config.items():
                    if hasattr(settings.monitoring, key):
                        setattr(settings.monitoring, key, value)

            return settings

        except Exception as e:
            print(f"配置文件加载失败，使用默认设置: {e}")
            return cls()

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "grafana": {
                "url": self.grafana.url,
                "username": self.grafana.username,
                "password": "***",  # 隐藏密码
                "api_key": "***" if self.grafana.api_key else None,
                "timeout": self.grafana.timeout,
                "verify_ssl": self.grafana.verify_ssl,
            },
            "security": {
                "session_timeout": self.security.session_timeout,
                "max_sessions_per_user": self.security.max_sessions_per_user,
                "password_min_length": self.security.password_min_length,
                "api_key_prefix": self.security.api_key_prefix,
                "bcrypt_rounds": self.security.bcrypt_rounds,
            },
            "connection": {
                "default_ssh_port": self.connection.default_ssh_port,
                "connection_timeout": self.connection.connection_timeout,
                "command_timeout": self.connection.command_timeout,
                "max_concurrent_connections": self.connection.max_concurrent_connections,
                "connection_pool_size": self.connection.connection_pool_size,
            },
            "monitoring": {
                "prometheus_port": self.monitoring.prometheus_port,
                "metrics_update_interval": self.monitoring.metrics_update_interval,
                "health_check_interval": self.monitoring.health_check_interval,
                "log_level": self.monitoring.log_level,
                "enable_audit_log": self.monitoring.enable_audit_log,
            },
        }

    def validate(self) -> bool:
        """验证配置的有效性"""
        errors = []

        # 验证端口范围
        if not (
            1 <= self.grafana.url.split(":")[-1].split("/")[0].isdigit()
            and 1 <= int(self.grafana.url.split(":")[-1].split("/")[0]) <= 65535
        ):
            errors.append("Grafana端口必须在1-65535范围内")

        if not (1 <= self.monitoring.prometheus_port <= 65535):
            errors.append("Prometheus端口必须在1-65535范围内")

        # 验证超时值
        if self.grafana.timeout <= 0:
            errors.append("Grafana超时时间必须大于0")

        if self.connection.connection_timeout <= 0:
            errors.append("SSH连接超时时间必须大于0")

        # 验证会话设置
        if self.security.session_timeout <= 0:
            errors.append("会话超时时间必须大于0")

        if self.security.max_sessions_per_user <= 0:
            errors.append("每用户最大会话数必须大于0")

        # 验证密码设置
        if self.security.password_min_length < 4:
            errors.append("密码最小长度不能小于4")

        if errors:
            print("配置验证失败:")
            for error in errors:
                print(f"  - {error}")
            return False

        return True


# 全局设置实例
settings = Settings()
