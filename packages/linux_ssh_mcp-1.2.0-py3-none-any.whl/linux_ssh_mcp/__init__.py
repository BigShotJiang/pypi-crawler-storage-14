"""
Linux SSH MCP - Main Package
"""

from .ssh_manager import SSHManager, ServerConfig
from .auth import AuthManager
from .__version__ import __version__ as version_from_version_file
from .__version__ import __author__ as author_from_version_file
from .__version__ import __email__ as email_from_version_file

# Use centralized version from __version__.py
__version__ = version_from_version_file
__author__ = author_from_version_file
__email__ = email_from_version_file

__all__ = [
    "SSHManager",
    "ServerConfig",
    "AuthManager",
    "__version__",
    "__author__",
    "__email__",
]
