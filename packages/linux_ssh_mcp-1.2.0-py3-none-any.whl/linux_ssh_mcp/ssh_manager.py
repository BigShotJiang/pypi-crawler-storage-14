#!/usr/bin/env python3
"""
SSH连接管理模块
"""

import asyncio
import asyncssh
import json
import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import time
from .config_utils import (
    get_config_file_path,
    ensure_config_exists,
    validate_config_file,
    get_default_servers_config,
)


class ServerStatus(Enum):
    """服务器状态枚举"""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


@dataclass
class ServerConfig:
    """服务器配置"""

    id: str
    host: str
    port: int = 22
    username: str = "root"
    password: Optional[str] = None
    timeout: int = 30
    private_key: Optional[str] = None

    def __post_init__(self):
        if not self.id:
            raise ValueError("服务器ID不能为空")
        if not self.host:
            raise ValueError("主机地址不能为空")


@dataclass
class CommandResult:
    """命令执行结果"""

    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time: float
    command: str


class SSHManager:
    """SSH连接管理器"""

    def __init__(
        self,
        use_pooling: bool = True,
        config_file: Optional[str] = None,
        auto_create_config: bool = True,
    ):
        """
        初始化SSH连接管理器

        Args:
            use_pooling: 是否启用连接池
            config_file: 配置文件路径，如果为None则使用默认路径检测
            auto_create_config: 是否自动创建配置文件（如果不存在）
        """
        self.use_pooling = use_pooling

        # 如果没有指定配置文件路径，使用智能路径检测
        if config_file is None:
            self.config_file = get_config_file_path("servers.json")
        else:
            self.config_file = config_file

        # 如果启用自动创建，确保配置文件存在
        if auto_create_config:
            try:
                self.config_file = ensure_config_exists(self.config_file)
            except RuntimeError as e:
                print(f"[WARN] {e}")
                print(f"[WARN] 将使用当前工作目录的配置文件: {self.config_file}")

        self.servers: Dict[str, ServerConfig] = {}
        self.connections: Dict[str, Any] = {}
        self.stats = {
            "total_connections": 0,
            "successful_connections": 0,
            "failed_connections": 0,
            "total_commands": 0,
            "successful_commands": 0,
            "failed_commands": 0,
        }

        # 加载服务器配置
        self._load_servers()
        self.stats["total_connections"] = 0  # Reset connection stats on startup

    def get_config_info(self) -> Dict[str, Any]:
        """
        获取配置文件信息，用于诊断和调试

        Returns:
            包含配置文件信息的字典
        """
        from .config_utils import get_config_info as get_utils_config_info

        # 获取基础配置信息
        config_info = get_utils_config_info()

        # 添加SSHManager特定的信息
        config_info.update(
            {
                "manager_config_file": self.config_file,
                "loaded_servers": len(self.servers),
                "server_ids": list(self.servers.keys()),
                "connection_pool_enabled": self.use_pooling,
                "active_connections": len(self.connections),
            }
        )

        return config_info

    def find_duplicate_servers(self, host: str, port: int) -> List[str]:
        """查找具有相同主机和端口的服务器ID列表"""
        duplicates = []
        for server_id, server_config in self.servers.items():
            if server_config.host == host and server_config.port == port:
                duplicates.append(server_id)
        return duplicates

    def get_server_conflicts(self, config: ServerConfig) -> Dict[str, Any]:
        """检查服务器配置冲突"""
        conflicts = {
            "id_conflict": config.id in self.servers,
            "host_conflicts": [],
            "warnings": [],
        }

        # 检查主机+端口冲突
        host_duplicates = self.find_duplicate_servers(config.host, config.port)
        if host_duplicates:
            conflicts["host_conflicts"] = host_duplicates

        # 生成警告信息
        if conflicts["id_conflict"]:
            old_config = self.servers[config.id]
            if old_config.host != config.host or old_config.port != config.port:
                conflicts["warnings"].append(
                    f"服务器ID '{config.id}' 已存在但指向不同的主机地址"
                )

        return conflicts

    def add_server(self, config: ServerConfig, confirm_overwrite: bool = True) -> bool:
        """添加服务器配置，检测重复并提示覆盖"""

        # 检查ID重复
        if config.id in self.servers:
            old_config = self.servers[config.id]
            print(f"服务器ID '{config.id}' 已存在:")
            print(
                f"  现有配置: {old_config.host}:{old_config.port} ({old_config.username})"
            )
            print(f"  新配置:   {config.host}:{config.port} ({config.username})")

            if confirm_overwrite:
                # 在交互模式下需要用户确认，在非交互模式下直接覆盖
                if hasattr(self, "_interactive_mode") and self._interactive_mode:
                    try:
                        response = (
                            input(f"是否覆盖服务器 '{config.id}' 的配置? (y/N): ")
                            .strip()
                            .lower()
                        )
                        if response not in ["y", "yes", "是"]:
                            print("操作已取消")
                            return False
                    except (EOFError, KeyboardInterrupt):
                        print("\n操作已取消")
                        return False

        # 检查主机+端口重复 (仅警告，不阻止)
        host_duplicates = self.find_duplicate_servers(config.host, config.port)
        if host_duplicates:
            for duplicate_id in host_duplicates:
                if duplicate_id != config.id:  # 不要报告自己
                    print(
                        f"警告: 主机 {config.host}:{config.port} 已在服务器 '{duplicate_id}' 中配置"
                    )

        self.servers[config.id] = config
        self._save_servers()

        action = "已更新" if config.id in self.servers else "已添加"
        print(f"服务器 '{config.id}' {action}: {config.host}:{config.port}")
        return True

    def remove_server(self, server_id: str) -> bool:
        """移除服务器配置"""
        if server_id in self.servers:
            # 关闭连接
            if server_id in self.connections:
                asyncio.create_task(self._close_connection(server_id))
            del self.servers[server_id]
            self._save_servers()
            return True
        return False

    def list_servers(self) -> List[str]:
        """列出所有服务器ID"""
        return list(self.servers.keys())

    def get_server_config(self, server_id: str) -> Optional[ServerConfig]:
        """获取服务器配置"""
        return self.servers.get(server_id)

    async def execute_command(
        self, server_id: str, command: str, timeout: Optional[int] = None
    ) -> CommandResult:
        """Execute SSH command"""
        if server_id not in self.servers:
            return CommandResult(
                success=False,
                stdout="",
                stderr=f"Server {server_id} not found",
                exit_code=1,
                execution_time=0.0,
                command=command,
            )

        start_time = time.time()
        self.stats["total_commands"] += 1

        try:
            connection = await self._get_connection(server_id)
            if not connection:
                raise Exception(f"Failed to connect to server {server_id}")

            print(f"Executing command: {command} (server: {server_id})")

            # Execute the command
            result = await connection.run(command, timeout=timeout or 30)

            command_result = CommandResult(
                success=result.exit_status == 0,
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.exit_status,
                execution_time=time.time() - start_time,
                command=command,
            )

            if command_result.success:
                self.stats["successful_commands"] += 1
            else:
                self.stats["failed_commands"] += 1

            return command_result

        except Exception as e:
            result = CommandResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=1,
                execution_time=time.time() - start_time,
                command=command,
            )

            self.stats["failed_commands"] += 1
            return result

    async def get_server_status(self, server_id: str) -> ServerStatus:
        """获取服务器状态"""
        if server_id not in self.servers:
            return ServerStatus.ERROR

        try:
            # Check if we have a valid pooled connection
            if self.use_pooling and server_id in self.connections:
                connection = self.connections[server_id]
                if connection.is_closing():
                    return ServerStatus.DISCONNECTED
                # Test connection with a quick command
                result = await connection.run('echo "status_check"', timeout=5)
                return (
                    ServerStatus.CONNECTED
                    if result.exit_status == 0
                    else ServerStatus.ERROR
                )
            else:
                # No pooled connection, try to create one for status check
                config = self.servers[server_id]
                connect_kwargs = {
                    "host": config.host,
                    "port": config.port,
                    "username": config.username,
                    "connect_timeout": min(config.timeout, 10),
                    "known_hosts": None,
                    "disable_trivial_auth": True,  # Important for password auth
                    "agent_path": None,
                    "gss_auth": False,
                    "kbdint_auth": False,
                    "encryption_algs": [
                        "aes128-ctr",
                        "aes192-ctr",
                        "aes256-ctr",
                        "aes128-gcm@openssh.com",
                        "aes256-gcm@openssh.com",
                    ],
                }

                if config.password:
                    connect_kwargs["password"] = config.password
                    connect_kwargs["preferred_auth"] = ["password"]
                    connect_kwargs["client_keys"] = []  # Disable key auth completely
                    connect_kwargs["public_key_auth"] = []  # Disable public key auth
                elif config.private_key:
                    connect_kwargs["client_keys"] = [config.private_key]
                    connect_kwargs["preferred_auth"] = ["publickey"]

                # Quick connection test
                test_connection = await asyncssh.connect(**connect_kwargs)
                result = await test_connection.run('echo "status_check"', timeout=5)
                test_connection.close()
                await test_connection.wait_closed()

                return (
                    ServerStatus.CONNECTED
                    if result.exit_status == 0
                    else ServerStatus.ERROR
                )

        except Exception as e:
            print(f"Status check failed for {server_id}: {e}")
            return ServerStatus.DISCONNECTED

    async def test_connection(self, server_id: str) -> bool:
        """Test server connection with a fresh connection"""
        try:
            # Create a fresh connection for testing (don't use pooled connection)
            config = self.servers[server_id]

            connect_kwargs = {
                "host": config.host,
                "port": config.port,
                "username": config.username,
                "connect_timeout": min(
                    config.timeout, 10
                ),  # Use shorter timeout for testing
                "known_hosts": None,
                "disable_trivial_auth": True,  # Important for password auth
                "agent_path": None,
                "gss_auth": False,
                "kbdint_auth": False,
                "encryption_algs": [
                    "aes128-ctr",
                    "aes192-ctr",
                    "aes256-ctr",
                    "aes128-gcm@openssh.com",
                    "aes256-gcm@openssh.com",
                ],
            }

            if config.password:
                connect_kwargs["password"] = config.password
                # Only use password authentication
                connect_kwargs["preferred_auth"] = ["password"]
                connect_kwargs["client_keys"] = []  # Disable key auth completely
                connect_kwargs["public_key_auth"] = []  # Disable public key auth
            elif config.private_key:
                connect_kwargs["client_keys"] = [config.private_key]
                connect_kwargs["preferred_auth"] = ["publickey"]

            # Create temporary connection for testing
            test_connection = await asyncssh.connect(**connect_kwargs)

            # Test the connection by running a simple command
            result = await test_connection.run('echo "connection_test"', timeout=5)

            # Close the test connection
            test_connection.close()
            await test_connection.wait_closed()

            return result.exit_status == 0

        except Exception as e:
            print(f"Connection test failed for {server_id}: {e}")
            return False

    async def _close_connection(self, server_id: str) -> None:
        """Close connection"""
        if server_id in self.connections:
            connection = self.connections[server_id]
            try:
                connection.close()
                await connection.wait_closed()
            except Exception as e:
                print(f"Error closing connection for {server_id}: {e}")
            finally:
                del self.connections[server_id]

    async def cleanup_connections(self) -> None:
        """Clean up all connections"""
        for server_id in list(self.connections.keys()):
            await self._close_connection(server_id)
        print("All SSH connections cleaned up")

    def get_performance_metrics(self) -> Dict[str, Any]:
        """获取性能指标"""
        success_rate = 0.0
        if self.stats["total_connections"] > 0:
            success_rate = (
                self.stats["successful_connections"] / self.stats["total_connections"]
            )

        command_success_rate = 0.0
        if self.stats["total_commands"] > 0:
            command_success_rate = (
                self.stats["successful_commands"] / self.stats["total_commands"]
            )

        return {
            "ssh_connections": {
                "total": self.stats["total_connections"],
                "successful": self.stats["successful_connections"],
                "failed": self.stats["failed_connections"],
                "success_rate": success_rate,
                "active_connections": len(self.connections),
            },
            "ssh_commands": {
                "total": self.stats["total_commands"],
                "successful": self.stats["successful_commands"],
                "failed": self.stats["failed_commands"],
                "success_rate": command_success_rate,
            },
            "servers": {
                "total": len(self.servers),
                "configured": len(self.servers),
                "connected": len(self.connections),
            },
        }

    def add_server_runtime(
        self,
        server_id: str,
        host: str,
        port: int = 22,
        username: str = "root",
        password: Optional[str] = None,
        timeout: int = 30,
        private_key: Optional[str] = None,
        persistent: bool = True,
        confirm_overwrite: bool = True,
    ) -> bool:
        """Add server at runtime with optional persistence and overwrite support"""
        try:
            # Validate input parameters
            if not server_id or not host or not username:
                print("Invalid parameters: server_id, host, and username are required")
                return False

            config = ServerConfig(
                id=server_id,
                host=host,
                port=port,
                username=username,
                password=password,
                timeout=timeout,
                private_key=private_key,
            )

            # Use the unified add_server method for consistent behavior
            return self.add_server(config, confirm_overwrite=confirm_overwrite)

        except Exception as e:
            print(f"Failed to add server: {e}")
            return False

    def remove_server_runtime(self, server_id: str) -> bool:
        """Remove server at runtime"""
        try:
            if server_id in self.servers:
                # Close existing connection
                if server_id in self.connections:
                    asyncio.create_task(self._close_connection(server_id))

                del self.servers[server_id]
                self._save_servers()
                print(f"Server '{server_id}' removed successfully")
                return True
            else:
                print(f"Server '{server_id}' not found")
                return False
        except Exception as e:
            print(f"Failed to remove server: {e}")
            return False

    def update_server_config(self, server_id: str, **kwargs) -> bool:
        """Update server configuration"""
        try:
            if server_id not in self.servers:
                print(f"Server '{server_id}' not found")
                return False

            config = self.servers[server_id]
            for key, value in kwargs.items():
                if hasattr(config, key):
                    setattr(config, key, value)

            self._save_servers()
            print(f"Server '{server_id}' configuration updated")
            return True
        except Exception as e:
            print(f"Failed to update server config: {e}")
            return False

    def import_servers_from_dict(
        self, servers_data: Dict[str, Dict], overwrite: bool = False
    ) -> int:
        """Import servers from dictionary with unified overwrite behavior"""
        imported_count = 0
        skipped_count = 0
        try:
            for server_id, server_data in servers_data.items():
                if server_id in self.servers and not overwrite:
                    print(f"Server '{server_id}' already exists, skipping")
                    skipped_count += 1
                    continue

                if "password" in server_data and server_data["password"] == "":
                    server_data["password"] = None

                config = ServerConfig(**server_data)

                # Use unified add_server method, but disable confirmation for batch operations
                if self.add_server(config, confirm_overwrite=False):
                    imported_count += 1
                else:
                    print(f"Failed to import server '{server_id}'")

            print(f"Imported {imported_count} servers successfully")
            if skipped_count > 0:
                print(
                    f"Skipped {skipped_count} existing servers (use overwrite=True to replace)"
                )

            return imported_count
        except Exception as e:
            print(f"Failed to import servers: {e}")
            return imported_count

    def export_servers_to_dict(self) -> Dict[str, Dict]:
        """Export servers to dictionary"""
        try:
            data = {}
            for server_id, config in self.servers.items():
                config_dict = asdict(config)
                # Mask password for security
                if config_dict.get("password"):
                    config_dict["password"] = "***"
                data[server_id] = config_dict
            return data
        except Exception as e:
            print(f"Failed to export servers: {e}")
            return {}

    def load_servers_from_file(self, file_path: str, overwrite: bool = False) -> int:
        """Load servers from external file"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return self.import_servers_from_dict(data, overwrite)
        except Exception as e:
            print(f"Failed to load servers from file: {e}")
            return 0

    def save_servers_to_file(
        self, file_path: str, include_passwords: bool = False
    ) -> bool:
        """Save servers to external file"""
        try:
            data = {}
            for server_id, config in self.servers.items():
                config_dict = asdict(config)
                if not include_passwords and config_dict.get("password"):
                    config_dict["password"] = None
                data[server_id] = config_dict

            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            print(f"Servers saved to {file_path}")
            return True
        except Exception as e:
            print(f"Failed to save servers to file: {e}")
            return False

    def _load_servers(self) -> None:
        """Load servers from config file"""
        try:
            if not os.path.exists(self.config_file):
                print(f"[INFO] 配置文件不存在: {self.config_file}")
                print("[INFO] 将创建新的配置文件")
                return

            # 验证配置文件格式
            if not validate_config_file(self.config_file):
                print(f"[WARN] 配置文件格式无效: {self.config_file}")
                print("[WARN] 将创建新的配置文件")
                return

            with open(self.config_file, "r", encoding="utf-8") as f:
                data = json.load(f)

                # 支持新的配置文件格式（包含servers字段）
                if isinstance(data, dict) and "servers" in data:
                    servers_data = data["servers"]
                else:
                    # 向后兼容：旧格式的配置文件
                    servers_data = data
                    print("[INFO] 检测到旧格式配置文件，建议升级到新格式")

                if not isinstance(servers_data, dict):
                    print("[WARN] 配置文件中的servers字段格式无效")
                    return

                # 批量处理服务器配置，减少异常处理开销
                loaded_count = 0
                skipped_count = 0

                for server_id, server_data in servers_data.items():
                    try:
                        # Validate required fields early to avoid processing invalid data
                        required_fields = ["id", "host", "port", "username"]
                        if not all(field in server_data for field in required_fields):
                            print(f"[WARN] 服务器配置缺少必需字段，跳过: {server_id}")
                            skipped_count += 1
                            continue

                        # Convert password to None if it's empty string
                        if server_data.get("password") == "":
                            server_data["password"] = None

                        # Create server config
                        self.servers[server_id] = ServerConfig(**server_data)
                        loaded_count += 1

                    except Exception as e:
                        print(f"[WARN] 加载服务器配置失败 {server_id}: {e}")
                        skipped_count += 1
                        continue

                print(f"[INFO] 成功加载 {loaded_count} 个服务器配置")
                if skipped_count > 0:
                    print(f"[WARN] 跳过了 {skipped_count} 个无效配置")

        except json.JSONDecodeError as e:
            print(f"[ERROR] 配置文件JSON格式错误: {e}")
            print("[ERROR] 请检查配置文件格式或删除文件以重新创建")
        except PermissionError as e:
            print(f"[ERROR] 没有权限读取配置文件: {e}")
        except Exception as e:
            print(f"[ERROR] 加载配置文件时发生未知错误: {e}")
            print(f"[ERROR] 配置文件: {self.config_file}")

    def _save_servers(self) -> None:
        """Save servers to config file"""
        try:
            # 确保配置文件目录存在
            config_dir = os.path.dirname(self.config_file)
            if config_dir:
                os.makedirs(config_dir, exist_ok=True)

            # 准备服务器配置数据
            servers_data = {}
            for server_id, config in self.servers.items():
                # Convert config to dict
                config_dict = asdict(config)
                servers_data[server_id] = config_dict

            # 使用新的配置文件格式
            config_data = get_default_servers_config()
            config_data["servers"] = servers_data
            config_data["last_updated"] = time.strftime("%Y-%m-%d %H:%M:%S")
            config_data["server_count"] = len(self.servers)

            # 备份现有配置文件
            backup_file = None
            if os.path.exists(self.config_file):
                backup_file = f"{self.config_file}.backup"
                try:
                    import shutil

                    shutil.copy2(self.config_file, backup_file)
                except Exception as e:
                    print(f"[WARN] 备份配置文件失败: {e}")

            # 写入新配置
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)

            print(f"[OK] 配置已保存到: {self.config_file}")
            if backup_file:
                print(f"[INFO] 备份文件: {backup_file}")

        except PermissionError as e:
            print(f"[ERROR] 没有权限写入配置文件: {e}")
            print("[ERROR] 请检查文件权限或指定其他配置文件路径")
            print(f"[ERROR] 配置文件: {self.config_file}")
        except OSError as e:
            print(f"[ERROR] 文件系统错误: {e}")
            print("[ERROR] 请检查磁盘空间和路径有效性")
        except Exception as e:
            print(f"[ERROR] 保存配置文件时发生未知错误: {e}")
            print(f"[ERROR] 配置文件: {self.config_file}")
            import traceback

            print(f"[DEBUG] 错误详情: {traceback.format_exc()}")

    async def _get_connection(
        self, server_id: str
    ) -> Optional[asyncssh.SSHClientConnection]:
        """Get or create SSH connection"""
        if server_id not in self.servers:
            return None

        # Check if we have a pooled connection that is still valid
        if self.use_pooling and server_id in self.connections:
            connection = self.connections[server_id]
            try:
                # Test if connection is still alive by running a simple command
                if connection.is_closing():
                    # Connection is closing, remove it and create a new one
                    await self._close_connection(server_id)
                else:
                    return connection
            except (asyncssh.ConnectionLost, asyncssh.BreakConnection, OSError):
                # Connection is broken, remove it and create a new one
                try:
                    await self._close_connection(server_id)
                except (asyncssh.ConnectionLost, OSError, Exception):
                    # Silently cleanup failed connection
                    if server_id in self.connections:
                        del self.connections[server_id]

        self.stats["total_connections"] += 1
        config = self.servers[server_id]

        try:
            # Create connection options
            connect_kwargs = {
                "host": config.host,
                "port": config.port,
                "username": config.username,
                "connect_timeout": config.timeout,
                "known_hosts": None,  # Disable host key checking for simplicity
                "disable_trivial_auth": True,  # Important for password auth
                "agent_path": None,  # Disable SSH agent
                "gss_auth": False,  # Disable GSS authentication
                "kbdint_auth": False,  # Disable keyboard-interactive auth
                "encryption_algs": [
                    "aes128-ctr",
                    "aes192-ctr",
                    "aes256-ctr",
                    "aes128-gcm@openssh.com",
                    "aes256-gcm@openssh.com",
                ],
            }

            # Add password or key authentication
            if config.password:
                connect_kwargs["password"] = config.password
                connect_kwargs["preferred_auth"] = ["password"]
                connect_kwargs["client_keys"] = []  # Disable key auth completely
                connect_kwargs["public_key_auth"] = []  # Disable public key auth
            elif config.private_key:
                connect_kwargs["client_keys"] = [config.private_key]
                connect_kwargs["preferred_auth"] = ["publickey"]

            print(f"Connecting to {config.host}:{config.port} as {config.username}...")
            connection = await asyncssh.connect(**connect_kwargs)

            if self.use_pooling:
                self.connections[server_id] = connection

            self.stats["successful_connections"] += 1
            print(f"Successfully connected to {server_id}")
            return connection

        except (
            asyncssh.ConnectionLost,
            asyncssh.BreakConnection,
            asyncssh.PermissionDenied,
            asyncssh.AuthenticationFailed,
            OSError,
            ConnectionError,
        ) as e:
            self.stats["failed_connections"] += 1
            print(f"Failed to connect to {server_id}: {e}")
            raise e
        except Exception as e:
            self.stats["failed_connections"] += 1
            print(f"Unexpected connection error to {server_id}: {e}")
            raise e
