"""Version information for linux_ssh_mcp package."""

__version__ = "1.2.0"
__author__ = "SSH MCP Development Team"
__email__ = "dev@sshmcp.com"
__license__ = "MIT"
