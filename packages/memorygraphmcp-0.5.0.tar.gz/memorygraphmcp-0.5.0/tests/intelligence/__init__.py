"""Tests for the intelligence layer."""
