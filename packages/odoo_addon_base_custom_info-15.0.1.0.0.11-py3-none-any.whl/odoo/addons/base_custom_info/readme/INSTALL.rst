This module serves as a base for other modules that implement this behavior in
concrete models.

This module is a technical dependency and is to be installed in parallel to
other modules.
