To enable the main *Custom Info* menu:

#. Enable *Settings > General Settings > Manage custom information*.

To enable partner's custom info tab:

#. Enable *Settings > General Settings > Edit custom information in partners*.
