* `Tecnativa <https://www.tecnativa.com>`__:

  * Rafael Blasco <rafael.blasco@tecnativa.com>
  * Carlos Dauden <carlos.dauden@tecnativa.com>
  * Sergio Teruel <sergio.teruel@tecnativa.com>
  * Jairo Llopis <jairo.llopis@tecnativa.com>
  * Pedro M. Baeza <pedro.baeza@tecnativa.com>
  * Alexandre Díaz <alexandre.diaz@tecnativa.com>
* Creu Blanca:

  * Enric Tobella <etobella@creublanca.es>
* Solvos:

  * David Alonso <david.alonso@solvos.es>
* Ecosoft:

  * Kitti U. <kittiu@ecosoft.co.th> (migration to v14)
