To create a module that supports custom information, just depend on this module
and inherit from the ``custom.info`` model.

See an example in the ``product_custom_info`` addon.
