# Copyright 2015 Antiun Ingeniería S.L. - Sergio Teruel
# Copyright 2015 Antiun Ingeniería S.L. - Carlos Dauden
# Copyright 2016 Jairo Llopis <jairo.llopis@tecnativa.com>
# License LGPL-3 - See http://www.gnu.org/licenses/lgpl-3.0.html

from . import (
    custom_info_template,
    custom_info_property,
    custom_info_category,
    custom_info_option,
    custom_info_value,
    custom_info,
    res_partner,
    ir_actions_act_window_view,
    ir_ui_view,
)
