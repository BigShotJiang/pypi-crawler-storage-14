::

    CERN

    EUROPEAN ORGANISATION FOR NUCLEAR RESEARCH


    Program name:                 MAD --- Methodical Accelerator Design

    CERN program library entry:   T5001

    Authors or contacts:          mad@cern.ch
                                  BE-ABP Group
                                  CERN
                                  CH-1211 GENEVA 23
                                  SWITZERLAND


    Copyright CERN, Geneva 1990 - Copyright and any other appropriate legal
    protection of this computer program and associated documentation reserved
    in all countries of the world. Organisations collaborating with CERN may
    receive this program and documentation freely and without charge. CERN
    undertakes no obligation for the maintenance of this program, nor
    responsibility for its correctness, and accepts no liability whatsoever
    resulting from its use. Program and documentation are provided solely for
    the use of the organisation to which they are distributed. This program
    may not be copied or otherwise distributed without permission. This
    message must be retained on this and any other authorised copies. The
    material cannot be sold. CERN should be given credit in all references.
