from typing import TypeVar, Literal

INTERFACE_VERSION = TypeVar("INTERFACE_VERSION", bound=Literal["0.4.1"])
