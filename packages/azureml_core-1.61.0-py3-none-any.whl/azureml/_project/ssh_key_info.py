# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import collections
SSHKeyInfo = collections.namedtuple("SSHKeyInfo", ["private_key_file", "passphrase"])
