# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from azureml._cli import aml_cli


if __name__ == '__main__':
    aml_cli.start_cli()
