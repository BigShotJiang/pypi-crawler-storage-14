# Testing

Use `uv run pytest` to run any tests, as it will include other dev dependencies. Running `pytest` directly will NOT include these dependencies.

See `pyproject.toml` for more details.