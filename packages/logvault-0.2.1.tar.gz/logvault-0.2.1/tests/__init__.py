"""Tests for LogVault Python SDK"""
