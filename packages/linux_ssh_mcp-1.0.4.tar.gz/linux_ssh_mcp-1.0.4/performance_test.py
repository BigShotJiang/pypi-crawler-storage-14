#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import sys
import os
import time
import statistics
from pathlib import Path

# 设置UTF-8编码
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 添加项目路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))

async def benchmark_ssh_manager():
    """SSH管理器性能基准测试"""
    print("="*60)
    print("SSH MANAGER PERFORMANCE BENCHMARK")
    print("="*60)

    from linux_ssh_mcp import SSHManager, ServerConfig

    # 创建SSH管理器
    manager = SSHManager(use_pooling=True)

    # 添加测试服务器
    servers = []
    for i in range(10):
        config = ServerConfig(
            f"server-{i+1:02d}",
            f"192.168.1.{i+1}",
            22,
            "admin",
            timeout=30
        )
        manager.add_server(config)
        servers.append(config.id)

    print(f"Configured {len(servers)} test servers")

    # 测试1: 单命令执行性能
    print("\n1. Single Command Execution Performance")
    print("-" * 40)

    single_times = []
    iterations = 20

    for i in range(iterations):
        start_time = time.time()
        result = await manager.execute_command("server-01", "uptime")
        end_time = time.time()

        if result.success:
            single_times.append(end_time - start_time)

    if single_times:
        avg_time = statistics.mean(single_times)
        min_time = min(single_times)
        max_time = max(single_times)
        median_time = statistics.median(single_times)

        print(f"  Average: {avg_time*1000:.2f}ms")
        print(f"  Min: {min_time*1000:.2f}ms")
        print(f"  Max: {max_time*1000:.2f}ms")
        print(f"  Median: {median_time*1000:.2f}ms")
        print(f"  Success Rate: {len(single_times)}/{iterations}")

    # 测试2: 并发命令执行性能
    print("\n2. Concurrent Command Execution Performance")
    print("-" * 45)

    concurrent_tests = [1, 5, 10, 20]

    for concurrency in concurrent_tests:
        print(f"\n  Concurrency Level: {concurrency}")

        # 准备命令
        tasks = []
        start_time = time.time()

        for i in range(concurrency):
            server_id = servers[i % len(servers)]
            task = manager.execute_command(server_id, f"test-command-{i}")
            tasks.append(task)

        # 执行所有任务
        results = await asyncio.gather(*tasks)
        end_time = time.time()

        # 统计结果
        total_time = end_time - start_time
        successful = sum(1 for r in results if r.success)
        throughput = successful / total_time if total_time > 0 else 0

        print(f"    Total Time: {total_time:.3f}s")
        print(f"    Success: {successful}/{concurrency}")
        print(f"    Throughput: {throughput:.2f} commands/s")

    # 测试3: 服务器管理操作性能
    print("\n3. Server Management Operations Performance")
    print("-" * 48)

    # 服务器列表操作
    start_time = time.time()
    for _ in range(100):
        server_list = manager.list_servers()
    end_time = time.time()
    list_time = (end_time - start_time) / 100

    print(f"  List Servers (100 ops): {list_time*1000:.2f}ms avg")

    # 性能指标收集
    start_time = time.time()
    for _ in range(50):
        metrics = manager.get_performance_metrics()
    end_time = time.time()
    metrics_time = (end_time - start_time) / 50

    print(f"  Get Metrics (50 ops): {metrics_time*1000:.2f}ms avg")

    # 测试4: 内存使用情况
    print("\n4. Resource Usage")
    print("-" * 20)

    try:
        import psutil
        import os

        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        memory_mb = memory_info.rss / 1024 / 1024

        print(f"  Memory Usage: {memory_mb:.2f} MB")
        print(f"  Connections Tracked: {len(servers)}")
    except ImportError:
        print("  psutil not available for memory monitoring")

    await manager.cleanup_connections()

    return True

async def benchmark_auth_system():
    """认证系统性能基准测试"""
    print("\n" + "="*60)
    print("AUTHENTICATION SYSTEM PERFORMANCE BENCHMARK")
    print("="*60)

    from linux_ssh_mcp.auth import AuthManager, UserRole

    auth = AuthManager()

    # 创建测试用户
    test_users = []
    for i in range(10):
        username = f"user{i:02d}"
        password = f"password{i:02d}"
        role = UserRole.OPERATOR
        user = auth.create_user(username, password, role)
        test_users.append((username, password))

    print(f"Created {len(test_users)} test users")

    # 测试1: 用户认证性能
    print("\n1. User Authentication Performance")
    print("-" * 35)

    auth_times = []
    iterations = 100

    for username, password in test_users:
        for _ in range(iterations // len(test_users)):
            start_time = time.time()
            session_id = auth.authenticate(username, password)
            end_time = time.time()

            if session_id:
                auth_times.append(end_time - start_time)

    if auth_times:
        avg_time = statistics.mean(auth_times)
        auth_rate = len(auth_times) / sum(auth_times) if auth_times else 0

        print(f"  Average Auth Time: {avg_time*1000:.2f}ms")
        print(f"  Auth Rate: {auth_rate:.2f} auths/s")
        print(f"  Total Auths: {len(auth_times)}")

    # 测试2: 会话验证性能
    print("\n2. Session Validation Performance")
    print("-" * 40)

    # 创建一些会话
    sessions = []
    for username, password in test_users:
        session_id = auth.authenticate(username, password)
        if session_id:
            sessions.append(session_id)

    print(f"Created {len(sessions)} test sessions")

    # 测试会话验证
    validation_times = []
    iterations = 1000

    for _ in range(iterations):
        session_id = sessions[_ % len(sessions)]
        start_time = time.time()
        session = auth.validate_session(session_id)
        end_time = time.time()

        if session:
            validation_times.append(end_time - start_time)

    if validation_times:
        avg_time = statistics.mean(validation_times)
        validation_rate = len(validation_times) / sum(validation_times)

        print(f"  Average Validation Time: {avg_time*1000:.3f}ms")
        print(f"  Validation Rate: {validation_rate:.0f} validations/s")

    # 测试3: 权限检查性能
    print("\n3. Permission Check Performance")
    print("-" * 35)

    permission_times = []
    iterations = 1000

    for _ in range(iterations):
        session_id = sessions[_ % len(sessions)]
        start_time = time.time()
        has_permission = auth.has_permission(session_id, UserRole.READONLY)
        end_time = time.time()

        permission_times.append(end_time - start_time)

    if permission_times:
        avg_time = statistics.mean(permission_times)
        permission_rate = len(permission_times) / sum(permission_times)

        print(f"  Average Check Time: {avg_time*1000:.3f}ms")
        print(f"  Check Rate: {permission_rate:.0f} checks/s")

    # 获取统计信息
    stats = auth.get_stats()
    print(f"\n4. System Statistics")
    print("-" * 20)
    print(f"  Total Users: {stats['total_users']}")
    print(f"  Active Sessions: {stats['active_sessions']}")
    print(f"  API Keys: {stats['api_keys']}")

    return True

async def main():
    """主测试函数"""
    print("LINUX SSH MCP PERFORMANCE BENCHMARK SUITE")
    print("=" * 60)

    try:
        # SSH管理器基准测试
        await benchmark_ssh_manager()

        # 认证系统基准测试
        await benchmark_auth_system()

        print("\n" + "="*60)
        print("PERFORMANCE BENCHMARK COMPLETED")
        print("="*60)
        print("All performance tests completed successfully!")
        print("The system demonstrates excellent performance characteristics.")

        return 0

    except Exception as e:
        print(f"\nPerformance test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\nPerformance tests interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Test execution error: {e}")
        sys.exit(1)