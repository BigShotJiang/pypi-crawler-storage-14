#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import sys
import os
import json
import tempfile
from pathlib import Path

# 设置UTF-8编码
os.environ['PYTHONIOENCODING'] = 'utf-8'

# 添加项目路径
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))

class TestReporter:
    """测试报告器"""

    def __init__(self):
        self.test_results = []
        self.start_time = None
        self.end_time = None

    def start_test(self, name):
        """开始测试"""
        print(f"\n[TEST] {name}")
        self.start_time = asyncio.get_event_loop().time()

    def report_result(self, name, success, message=""):
        """报告测试结果"""
        end_time = asyncio.get_event_loop().time()
        duration = end_time - self.start_time if self.start_time else 0

        status = "PASS" if success else "FAIL"
        print(f"  [{status}] {name}")
        if message:
            print(f"    -> {message}")

        self.test_results.append({
            "name": name,
            "status": status,
            "duration": duration,
            "message": message
        })

    def generate_report(self):
        """生成测试报告"""
        total = len(self.test_results)
        passed = len([r for r in self.test_results if r["status"] == "PASS"])

        print(f"\n" + "="*60)
        print(f"INTEGRATION TEST REPORT")
        print(f"="*60)
        print(f"Total Tests: {total}")
        print(f"Passed: {passed}")
        print(f"Failed: {total - passed}")
        print(f"Success Rate: {passed/total*100:.1f}%")
        print(f"Total Duration: {sum(r['duration'] for r in self.test_results):.2f}s")

        print(f"\nDetailed Results:")
        print("-" * 40)
        for result in self.test_results:
            status_symbol = "✓" if result["status"] == "PASS" else "✗"
            print(f"{status_symbol} {result['name']} ({result['duration']:.2f}s)")
            if result["message"]:
                print(f"  {result['message']}")

        return passed == total

async def test_ssh_manager_integration():
    """测试SSH管理器集成"""
    reporter = TestReporter()

    # 测试1: 创建SSH管理器
    reporter.start_test("SSH Manager Creation")
    try:
        from linux_ssh_mcp import SSHManager, ServerConfig

        manager = SSHManager(use_pooling=True)
        reporter.report_result("SSH Manager Creation", True, "Manager created with pooling enabled")
    except Exception as e:
        reporter.report_result("SSH Manager Creation", False, str(e))
        return reporter.test_results

    # 测试2: 添加多个服务器
    reporter.start_test("Multiple Server Management")
    try:
        servers = [
            ServerConfig("web-01", "192.168.1.10", 22, "admin"),
            ServerConfig("web-02", "192.168.1.11", 22, "admin"),
            ServerConfig("db-01", "192.168.1.20", 22, "root"),
            ServerConfig("cache-01", "192.168.1.30", 22, "redis")
        ]

        for server in servers:
            manager.add_server(server)

        server_list = manager.list_servers()
        reporter.report_result(
            "Multiple Server Management",
            len(server_list) == 4,
            f"Added {len(server_list)} servers"
        )
    except Exception as e:
        reporter.report_result("Multiple Server Management", False, str(e))

    # 测试3: 并发命令执行
    reporter.start_test("Concurrent Command Execution")
    try:
        commands = [
            ("web-01", "uptime"),
            ("web-02", "df -h"),
            ("db-01", "ps aux | head -5"),
            ("cache-01", "free -m")
        ]

        # 并发执行命令
        tasks = []
        for server_id, command in commands:
            task = manager.execute_command(server_id, command)
            tasks.append(task)

        results = await asyncio.gather(*tasks)

        successful = sum(1 for r in results if r.success)
        reporter.report_result(
            "Concurrent Command Execution",
            successful == len(commands),
            f"{successful}/{len(commands)} commands executed successfully"
        )
    except Exception as e:
        reporter.report_result("Concurrent Command Execution", False, str(e))

    # 测试4: 性能指标收集
    reporter.start_test("Performance Metrics Collection")
    try:
        metrics = manager.get_performance_metrics()

        required_keys = ["ssh_connections", "ssh_commands", "servers"]
        has_all_keys = all(key in metrics for key in required_keys)

        reporter.report_result(
            "Performance Metrics Collection",
            has_all_keys,
            f"Collected metrics: {list(metrics.keys())}"
        )
    except Exception as e:
        reporter.report_result("Performance Metrics Collection", False, str(e))

    # 测试5: 连接清理
    reporter.start_test("Connection Cleanup")
    try:
        await manager.cleanup_connections()
        reporter.report_result("Connection Cleanup", True, "Connections cleaned up successfully")
    except Exception as e:
        reporter.report_result("Connection Cleanup", False, str(e))

    return reporter.test_results

async def test_auth_system_integration():
    """测试认证系统集成"""
    reporter = TestReporter()

    # 测试1: 认证管理器创建
    reporter.start_test("Auth Manager Creation")
    try:
        from linux_ssh_mcp.auth import AuthManager, UserRole, AuthMethod

        auth_manager = AuthManager()
        reporter.report_result("Auth Manager Creation", True, "Auth manager created")
    except Exception as e:
        reporter.report_result("Auth Manager Creation", False, str(e))
        return reporter.test_results

    # 测试2: 用户创建和认证
    reporter.start_test("User Creation and Authentication")
    try:
        # 创建不同角色的用户
        users = [
            ("readonly_user", "readonly123", UserRole.READONLY),
            ("operator_user", "operator123", UserRole.OPERATOR),
            ("admin_user", "admin123", UserRole.ADMIN),
            ("superuser", "super123", UserRole.SUPERUSER)
        ]

        created_users = []
        for username, password, role in users:
            user = auth_manager.create_user(username, password, role)
            created_users.append(user)

        # 测试认证
        test_user = created_users[0]
        session_id = auth_manager.authenticate(test_user.username, users[0][1])

        reporter.report_result(
            "User Creation and Authentication",
            session_id is not None,
            f"Created {len(created_users)} users and authenticated successfully"
        )
    except Exception as e:
        reporter.report_result("User Creation and Authentication", False, str(e))

    # 测试3: 权限验证
    reporter.start_test("Permission Verification")
    try:
        # 使用superuser会话（应该有所有权限）
        super_session = auth_manager.authenticate("superuser", "super123")

        permissions_test = [
            (UserRole.READONLY, True),
            (UserRole.OPERATOR, True),
            (UserRole.ADMIN, True),
            (UserRole.SUPERUSER, True)
        ]

        all_permissions_ok = True
        for required_role, should_have in permissions_test:
            has_permission = auth_manager.has_permission(super_session, required_role)
            if has_permission != should_have:
                all_permissions_ok = False
                break

        reporter.report_result(
            "Permission Verification",
            all_permissions_ok,
            "Superuser permissions verified"
        )
    except Exception as e:
        reporter.report_result("Permission Verification", False, str(e))

    # 测试4: API密钥认证
    reporter.start_test("API Key Authentication")
    try:
        # 获取用户的API密钥
        user = auth_manager.get_user("admin_user")
        if user and user.api_key:
            api_session = auth_manager.authenticate_api_key(user.api_key)

            reporter.report_result(
                "API Key Authentication",
                api_session is not None,
                "API key authentication successful"
            )
        else:
            reporter.report_result("API Key Authentication", False, "No API key found")
    except Exception as e:
        reporter.report_result("API Key Authentication", False, str(e))

    # 测试5: 会话管理
    reporter.start_test("Session Management")
    try:
        # 创建多个会话
        session_ids = []
        for i in range(3):
            session_id = auth_manager.authenticate("operator_user", "operator123")
            if session_id:
                session_ids.append(session_id)

        # 验证会话
        valid_sessions = 0
        for session_id in session_ids:
            session = auth_manager.validate_session(session_id)
            if session:
                valid_sessions += 1

        # 清理会话
        for session_id in session_ids:
            auth_manager.logout(session_id)

        reporter.report_result(
            "Session Management",
            valid_sessions == len(session_ids),
            f"Managed {len(session_ids)} sessions successfully"
        )
    except Exception as e:
        reporter.report_result("Session Management", False, str(e))

    # 测试6: 统计信息
    reporter.start_test("Auth Statistics")
    try:
        stats = auth_manager.get_stats()

        required_stats = ["total_users", "active_sessions", "api_keys", "users_by_role"]
        has_all_stats = all(key in stats for key in required_stats)

        reporter.report_result(
            "Auth Statistics",
            has_all_stats,
            f"Stats: {stats['total_users']} users, {stats['api_keys']} API keys"
        )
    except Exception as e:
        reporter.report_result("Auth Statistics", False, str(e))

    return reporter.test_results

async def test_file_operations():
    """测试文件操作"""
    reporter = TestReporter()

    # 测试1: 配置文件读写
    reporter.start_test("Configuration File Operations")
    try:
        config_data = {
            "ssh": {
                "timeout": 30,
                "max_connections": 100
            },
            "auth": {
                "session_timeout": 3600,
                "max_sessions": 10
            }
        }

        # 写入配置文件
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(config_data, f, indent=2)
            temp_file = f.name

        # 读取配置文件
        with open(temp_file, 'r') as f:
            loaded_data = json.load(f)

        # 清理临时文件
        os.unlink(temp_file)

        config_match = loaded_data == config_data
        reporter.report_result(
            "Configuration File Operations",
            config_match,
            "Configuration file read/write successful"
        )
    except Exception as e:
        reporter.report_result("Configuration File Operations", False, str(e))

    # 测试2: 日志文件操作
    reporter.start_test("Log File Operations")
    try:
        log_messages = [
            "INFO: SSH connection established",
            "INFO: Command executed successfully",
            "WARNING: High memory usage detected",
            "ERROR: Connection timeout"
        ]

        with tempfile.NamedTemporaryFile(mode='w', suffix='.log', delete=False) as f:
            log_file = f.name
            for message in log_messages:
                f.write(f"{message}\n")

        # 读取日志文件
        with open(log_file, 'r') as f:
            log_content = f.readlines()

        # 清理临时文件
        os.unlink(log_file)

        reporter.report_result(
            "Log File Operations",
            len(log_content) == len(log_messages),
            f"Processed {len(log_content)} log entries"
        )
    except Exception as e:
        reporter.report_result("Log File Operations", False, str(e))

    return reporter.test_results

async def test_deployment_readiness():
    """测试部署就绪性"""
    reporter = TestReporter()

    # 测试1: Docker配置检查
    reporter.start_test("Docker Configuration")
    try:
        docker_files = [
            "docker-compose.yml",
            "Dockerfile"
        ]

        docker_ready = 0
        for file_name in docker_files:
            file_path = project_root / file_name
            if file_path.exists():
                docker_ready += 1

        reporter.report_result(
            "Docker Configuration",
            docker_ready == len(docker_files),
            f"Docker files: {docker_ready}/{len(docker_files)}"
        )
    except Exception as e:
        reporter.report_result("Docker Configuration", False, str(e))

    # 测试2: Kubernetes配置检查
    reporter.start_test("Kubernetes Configuration")
    try:
        k8s_files = [
            "kubernetes/deployment.yaml",
            "kubernetes/configmap.yaml"
        ]

        k8s_ready = 0
        for file_name in k8s_files:
            file_path = project_root / file_name
            if file_path.exists():
                k8s_ready += 1

        reporter.report_result(
            "Kubernetes Configuration",
            k8s_ready == len(k8s_files),
            f"Kubernetes files: {k8s_ready}/{len(k8s_files)}"
        )
    except Exception as e:
        reporter.report_result("Kubernetes Configuration", False, str(e))

    # 测试3: 部署脚本检查
    reporter.start_test("Deployment Scripts")
    try:
        script_files = [
            "scripts/deploy.sh",
            "scripts/monitoring-setup.sh"
        ]

        scripts_ready = 0
        for file_name in script_files:
            file_path = project_root / file_name
            if file_path.exists() and os.access(file_path, os.X_OK):
                scripts_ready += 1

        reporter.report_result(
            "Deployment Scripts",
            scripts_ready == len(script_files),
            f"Executable scripts: {scripts_ready}/{len(script_files)}"
        )
    except Exception as e:
        reporter.report_result("Deployment Scripts", False, str(e))

    return reporter.test_results

async def main():
    """主测试函数"""
    print("="*60)
    print("LINUX SSH MCP INTEGRATION TEST SUITE")
    print("="*60)

    test_suites = [
        ("SSH Manager Integration", test_ssh_manager_integration),
        ("Authentication System Integration", test_auth_system_integration),
        ("File Operations", test_file_operations),
        ("Deployment Readiness", test_deployment_readiness)
    ]

    all_results = []

    for suite_name, test_func in test_suites:
        print(f"\n{'='*60}")
        print(f"RUNNING: {suite_name}")
        print(f"{'='*60}")

        try:
            results = await test_func()
            all_results.extend(results)
        except Exception as e:
            print(f"ERROR: Test suite '{suite_name}' failed: {e}")
            all_results.append({
                "name": suite_name,
                "status": "FAIL",
                "duration": 0,
                "message": str(e)
            })

    # 生成最终报告
    total_tests = len(all_results)
    passed_tests = len([r for r in all_results if r["status"] == "PASS"])

    print(f"\n{'='*60}")
    print(f"FINAL TEST REPORT")
    print(f"{'='*60}")
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {total_tests - passed_tests}")
    print(f"Success Rate: {passed_tests/total_tests*100:.1f}%")

    if passed_tests == total_tests:
        print("\n🎉 ALL INTEGRATION TESTS PASSED!")
        print("The Linux SSH MCP system is ready for deployment!")
        return 0
    elif passed_tests >= total_tests * 0.9:
        print(f"\n✅ MOST TESTS PASSED ({passed_tests}/{total_tests})")
        print("The system is mostly ready for deployment.")
        return 0
    else:
        print(f"\n❌ TOO MANY TESTS FAILED ({total_tests - passed_tests}/{total_tests})")
        print("Please address the failing tests before deployment.")
        return 1

if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\nTests interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\nTest execution error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)