#!/bin/bash

# Linux SSH MCP Deployment Script
# This script handles the deployment of SSH MCP in various environments

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
COMPOSE_FILE="$PROJECT_ROOT/docker-compose.yml"
K8S_DIR="$PROJECT_ROOT/kubernetes"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."

    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed or not in PATH"
        exit 1
    fi

    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        log_error "Docker Compose is not installed or not in PATH"
        exit 1
    fi

    # Check kubectl if Kubernetes deployment
    if [[ "$1" == "kubernetes" ]]; then
        if ! command -v kubectl &> /dev/null; then
            log_error "kubectl is not installed or not in PATH"
            exit 1
        fi
    fi

    log_success "Prerequisites check passed"
}

# Function to create environment file
create_env_file() {
    local env_file="$PROJECT_ROOT/.env"

    if [[ ! -f "$env_file" ]]; then
        log_info "Creating .env file..."

        cat > "$env_file" << EOF
# Linux SSH MCP Environment Variables
COMPOSE_PROJECT_NAME=ssh-mcp

# Database Configuration
POSTGRES_DB=sshmcp
POSTGRES_USER=postgres
POSTGRES_PASSWORD=$(openssl rand -base64 32)
POSTGRES_REPLICATION_USER=replicator
POSTGRES_REPLICATION_PASSWORD=$(openssl rand -base64 32)

# Redis Configuration
REDIS_PASSWORD=

# Application Configuration
SECRET_KEY=$(openssl rand -base64 64)
LOG_LEVEL=INFO
METRICS_ENABLED=true
CLUSTER_MODE=true

# Grafana Configuration
GF_SECURITY_ADMIN_PASSWORD=$(openssl rand -base64 16)
GF_USERS_ALLOW_SIGN_UP=false

# Monitoring
PROMETHEUS_RETENTION=200h
PROMETHEUS_STORAGE_SIZE=20Gi
GRAFANA_STORAGE_SIZE=10Gi

# Storage Sizes
POSTGRES_STORAGE_SIZE=20Gi
REDIS_STORAGE_SIZE=8Gi
ELASTICSEARCH_STORAGE_SIZE=30Gi
RABBITMQ_STORAGE_SIZE=10Gi
EOF

        log_success ".env file created"
    else
        log_warning ".env file already exists, skipping creation"
    fi
}

# Function to generate SSL certificates
generate_ssl_certs() {
    local ssl_dir="$PROJECT_ROOT/docker/nginx/ssl"

    if [[ ! -f "$ssl_dir/cert.pem" ]]; then
        log_info "Generating SSL certificates..."

        mkdir -p "$ssl_dir"

        # Generate self-signed certificate
        openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout "$ssl_dir/key.pem" \
            -out "$ssl_dir/cert.pem" \
            -subj "/C=US/ST=State/L=City/O=Organization/CN=ssh-mcp.example.com"

        log_success "SSL certificates generated"
    else
        log_warning "SSL certificates already exist, skipping generation"
    fi
}

# Function to deploy with Docker Compose
deploy_docker_compose() {
    log_info "Deploying with Docker Compose..."

    check_prerequisites docker-compose
    create_env_file
    generate_ssl_certs

    # Create necessary directories
    mkdir -p "$PROJECT_ROOT/logs"
    mkdir -p "$PROJECT_ROOT/config"
    mkdir -p "$PROJECT_ROOT/data"

    # Build and start services
    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" down
        docker-compose -f "$COMPOSE_FILE" build
        docker-compose -f "$COMPOSE_FILE" up -d
    else
        docker compose -f "$COMPOSE_FILE" down
        docker compose -f "$COMPOSE_FILE" build
        docker compose -f "$COMPOSE_FILE" up -d
    fi

    log_success "Docker Compose deployment completed"

    # Show service status
    show_service_status
}

# Function to deploy to Kubernetes
deploy_kubernetes() {
    log_info "Deploying to Kubernetes..."

    check_prerequisites kubernetes

    # Create namespace
    kubectl apply -f "$K8S_DIR/configmap.yaml"

    # Create secrets
    create_kubernetes_secrets

    # Apply deployment
    kubectl apply -f "$K8S_DIR/deployment.yaml"

    # Wait for deployment to be ready
    log_info "Waiting for deployment to be ready..."
    kubectl wait --for=condition=available --timeout=300s deployment/ssh-mcp -n ssh-mcp

    log_success "Kubernetes deployment completed"

    # Show deployment status
    show_kubernetes_status
}

# Function to create Kubernetes secrets
create_kubernetes_secrets() {
    log_info "Creating Kubernetes secrets..."

    # Database secrets
    kubectl create secret generic ssh-mcp-secrets \
        --from-literal=database-url="postgresql://postgres:password@postgres-primary:5432/sshmcp" \
        --from-literal=redis-url="redis://redis-cluster:6379" \
        --namespace=ssh-mcp \
        --dry-run=client -o yaml | kubectl apply -f -

    # SSH keys secret (empty for now, user should add their keys)
    kubectl create secret generic ssh-mcp-keys \
        --from-literal=id_rsa="" \
        --from-literal=id_rsa.pub="" \
        --namespace=ssh-mcp \
        --dry-run=client -o yaml | kubectl apply -f -

    log_success "Kubernetes secrets created"
}

# Function to show service status
show_service_status() {
    log_info "Service status:"

    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" ps
    else
        docker compose -f "$COMPOSE_FILE" ps
    fi

    echo ""
    log_info "Access URLs:"
    echo "  - SSH MCP API: http://localhost:8000"
    echo "  - Web Interface: http://localhost:5000"
    echo "  - Grafana: http://localhost:3000 (admin/admin)"
    echo "  - Prometheus: http://localhost:9090"
    echo "  - Kibana: http://localhost:5601"
}

# Function to show Kubernetes status
show_kubernetes_status() {
    log_info "Kubernetes deployment status:"

    kubectl get all -n ssh-mcp

    echo ""
    log_info "Access URLs:"
    echo "  - Service: kubectl port-forward service/ssh-mcp-service 8000:8000 -n ssh-mcp"
    echo "  - Grafana: kubectl port-forward deployment/grafana 3000:3000 -n ssh-mcp"
    echo "  - Prometheus: kubectl port-forward deployment/prometheus 9090:9090 -n ssh-mcp"
}

# Function to run health checks
run_health_checks() {
    log_info "Running health checks..."

    # Check main service
    if curl -f http://localhost:8000/health &> /dev/null; then
        log_success "Main service is healthy"
    else
        log_error "Main service health check failed"
    fi

    # Check web interface
    if curl -f http://localhost:5000 &> /dev/null; then
        log_success "Web interface is healthy"
    else
        log_error "Web interface health check failed"
    fi

    # Check Grafana
    if curl -f http://localhost:3000/api/health &> /dev/null; then
        log_success "Grafana is healthy"
    else
        log_warning "Grafana health check failed (may still be starting)"
    fi

    # Check Prometheus
    if curl -f http://localhost:9090/-/healthy &> /dev/null; then
        log_success "Prometheus is healthy"
    else
        log_warning "Prometheus health check failed (may still be starting)"
    fi
}

# Function to cleanup deployment
cleanup() {
    log_info "Cleaning up deployment..."

    if [[ "$1" == "docker-compose" ]]; then
        if command -v docker-compose &> /dev/null; then
            docker-compose -f "$COMPOSE_FILE" down -v
        else
            docker compose -f "$COMPOSE_FILE" down -v
        fi
    elif [[ "$1" == "kubernetes" ]]; then
        kubectl delete -f "$K8S_DIR/deployment.yaml" --ignore-not-found=true
        kubectl delete -f "$K8S_DIR/configmap.yaml" --ignore-not-found=true
        kubectl delete namespace ssh-mcp --ignore-not-found=true
    fi

    log_success "Cleanup completed"
}

# Function to show logs
show_logs() {
    local service="$1"

    if [[ "$1" == "docker-compose" ]]; then
        if command -v docker-compose &> /dev/null; then
            docker-compose -f "$COMPOSE_FILE" logs -f
        else
            docker compose -f "$COMPOSE_FILE" logs -f
        fi
    elif [[ "$1" == "kubernetes" ]]; then
        kubectl logs -f deployment/ssh-mcp -n ssh-mcp
    fi
}

# Function to scale services
scale_service() {
    local service="$1"
    local replicas="$2"

    if [[ "$1" == "docker-compose" ]]; then
        if command -v docker-compose &> /dev/null; then
            docker-compose -f "$COMPOSE_FILE" up -d --scale "$service=$replicas"
        else
            docker compose -f "$COMPOSE_FILE" up -d --scale "$service=$replicas"
        fi
    elif [[ "$1" == "kubernetes" ]]; then
        kubectl scale deployment/ssh-mcp --replicas="$replicas" -n ssh-mcp
    fi

    log_success "Scaled $service to $replicas replicas"
}

# Function to backup data
backup_data() {
    local backup_dir="$PROJECT_ROOT/backups/$(date +%Y%m%d_%H%M%S)"

    log_info "Creating backup in $backup_dir..."

    mkdir -p "$backup_dir"

    # Backup Docker volumes
    if command -v docker &> /dev/null; then
        # Backup PostgreSQL
        docker exec ssh-mcp-postgres-primary pg_dump -U postgres sshmcp > "$backup_dir/postgres.sql"

        # Backup Redis
        docker exec ssh-mcp-redis redis-cli BGSAVE
        docker cp ssh-mcp-redis:/data/dump.rdb "$backup_dir/redis.rdb"
    fi

    # Backup configuration files
    cp "$PROJECT_ROOT/.env" "$backup_dir/"
    cp -r "$PROJECT_ROOT/config" "$backup_dir/"

    log_success "Backup completed: $backup_dir"
}

# Function to restore data
restore_data() {
    local backup_dir="$1"

    if [[ ! -d "$backup_dir" ]]; then
        log_error "Backup directory not found: $backup_dir"
        exit 1
    fi

    log_info "Restoring data from $backup_dir..."

    # Restore PostgreSQL
    if [[ -f "$backup_dir/postgres.sql" ]]; then
        docker exec -i ssh-mcp-postgres-primary psql -U postgres sshmcp < "$backup_dir/postgres.sql"
    fi

    # Restore Redis
    if [[ -f "$backup_dir/redis.rdb" ]]; then
        docker cp "$backup_dir/redis.rdb" ssh-mcp-redis:/data/dump.rdb
        docker restart ssh-mcp-redis
    fi

    log_success "Restore completed"
}

# Show usage information
usage() {
    cat << EOF
Linux SSH MCP Deployment Script

Usage: $0 <command> [options]

Commands:
    deploy <method>        Deploy the application
        Methods:
            docker-compose    Deploy with Docker Compose (default)
            kubernetes        Deploy to Kubernetes cluster

    scale <service> <n>    Scale a service to n replicas
    logs                    Show logs for all services
    status                  Show deployment status
    health                  Run health checks
    backup                  Create data backup
    restore <backup_dir>    Restore data from backup
    cleanup <method>        Clean up deployment
    help                    Show this help message

Examples:
    $0 deploy docker-compose
    $0 deploy kubernetes
    $0 scale ssh-mcp-main 3
    $0 logs
    $0 health
    $0 backup
    $0 restore /path/to/backup

Environment Variables:
    COMPOSE_PROJECT_NAME    Docker Compose project name
    LOG_LEVEL              Application log level (default: INFO)
    METRICS_ENABLED        Enable metrics collection (default: true)
EOF
}

# Main script execution
main() {
    case "${1:-}" in
        deploy)
            case "${2:-docker-compose}" in
                docker-compose|"")
                    deploy_docker_compose
                    ;;
                kubernetes)
                    deploy_kubernetes
                    ;;
                *)
                    log_error "Unknown deployment method: $2"
                    usage
                    exit 1
                    ;;
            esac
            ;;
        scale)
            if [[ $# -lt 3 ]]; then
                log_error "Scale command requires service name and replica count"
                usage
                exit 1
            fi
            scale_service "$2" "$3"
            ;;
        logs)
            show_logs
            ;;
        status)
            if [[ -f "$COMPOSE_FILE" ]]; then
                show_service_status
            else
                show_kubernetes_status
            fi
            ;;
        health)
            run_health_checks
            ;;
        backup)
            backup_data
            ;;
        restore)
            if [[ $# -lt 2 ]]; then
                log_error "Restore command requires backup directory"
                usage
                exit 1
            fi
            restore_data "$2"
            ;;
        cleanup)
            case "${2:-docker-compose}" in
                docker-compose|"")
                    cleanup docker-compose
                    ;;
                kubernetes)
                    cleanup kubernetes
                    ;;
                *)
                    log_error "Unknown cleanup method: $2"
                    usage
                    exit 1
                    ;;
            esac
            ;;
        help|"")
            usage
            ;;
        *)
            log_error "Unknown command: $1"
            usage
            exit 1
            ;;
    esac
}

# Execute main function with all arguments
main "$@"