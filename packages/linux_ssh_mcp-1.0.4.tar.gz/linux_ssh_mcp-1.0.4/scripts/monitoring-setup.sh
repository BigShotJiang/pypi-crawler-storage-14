#!/bin/bash

# Linux SSH MCP Monitoring Setup Script
# This script sets up complete monitoring with Prometheus and Grafana

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Default configuration
PROMETHEUS_URL="http://localhost:9090"
GRAFANA_URL="http://localhost:3000"
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin"
PROMETHEUS_DATASOURCE="SSH-MCP-Prometheus"

# Function to create Prometheus configuration
create_prometheus_config() {
    log_info "Creating Prometheus configuration..."

    local prometheus_dir="$PROJECT_ROOT/docker/prometheus"
    mkdir -p "$prometheus_dir/rules"

    cat > "$prometheus_dir/prometheus.yml" << 'EOF'
global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    cluster: 'ssh-mcp'
    replica: 'prometheus-1'

rule_files:
  - "/etc/prometheus/rules/*.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets: []

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: 'ssh-mcp'
    static_configs:
      - targets: ['ssh-mcp-main:8000', 'ssh-mcp-secondary:8000']
    metrics_path: '/metrics'
    scrape_interval: 30s
    scrape_timeout: 10s

  - job_name: 'ssh-mcp-web'
    static_configs:
      - targets: ['ssh-mcp-main:5000', 'ssh-mcp-secondary:5000']
    metrics_path: '/metrics'
    scrape_interval: 30s
    scrape_timeout: 10s

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres-primary:5432']
    metrics_path: '/metrics'

  - job_name: 'redis'
    static_configs:
      - targets: ['redis-cluster:6379']
    metrics_path: '/metrics'

  - job_name: 'nginx'
    static_configs:
      - targets: ['nginx-lb:9113']
    metrics_path: '/metrics'

  - job_name: 'node-exporter'
    static_configs:
      - targets: ['node-exporter:9100']

  - job_name: 'cadvisor'
    static_configs:
      - targets: ['cadvisor:8080']
    metrics_path: '/metrics'

  - job_name: 'docker'
    static_configs:
      - targets: ['docker-exporter:9323']
EOF

    # Create alerting rules
    cat > "$prometheus_dir/rules/alerts.yml" << 'EOF'
groups:
- name: ssh-mcp.rules
  rules:
  # System alerts
  - alert: HighCPUUsage
    expr: cpu_usage_percent > 80
    for: 5m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High CPU usage detected"
      description: "CPU usage is {{ $value }}% for more than 5 minutes"

  - alert: CriticalCPUUsage
    expr: cpu_usage_percent > 95
    for: 2m
    labels:
      severity: critical
      service: ssh-mcp
    annotations:
      summary: "Critical CPU usage detected"
      description: "CPU usage is {{ $value }}% for more than 2 minutes"

  - alert: HighMemoryUsage
    expr: memory_usage_percent > 85
    for: 5m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High memory usage detected"
      description: "Memory usage is {{ $value }}% for more than 5 minutes"

  - alert: CriticalMemoryUsage
    expr: memory_usage_percent > 95
    for: 2m
    labels:
      severity: critical
      service: ssh-mcp
    annotations:
      summary: "Critical memory usage detected"
      description: "Memory usage is {{ $value }}% for more than 2 minutes"

  # SSH connection alerts
  - alert: HighConnectionCount
    expr: sum(ssh_connections_active) > 100
    for: 2m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High SSH connection count"
      description: "{{ $value }} active SSH connections detected"

  - alert: SSHConnectionFailure
    expr: rate(ssh_connections_total{status="failed"}[5m]) > 0.1
    for: 1m
    labels:
      severity: critical
      service: ssh-mcp
    annotations:
      summary: "SSH connection failures detected"
      description: "High rate of SSH connection failures: {{ $value }} connections/sec"

  # Command execution alerts
  - alert: HighCommandFailureRate
    expr: rate(ssh_commands_total{status="failed"}[5m]) / rate(ssh_commands_total[5m]) > 0.1
    for: 3m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High SSH command failure rate"
      description: "SSH command failure rate is {{ $value | humanizePercentage }}"

  - alert: SlowCommandExecution
    expr: histogram_quantile(0.95, rate(ssh_command_duration_seconds_bucket[5m])) > 30
    for: 5m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "Slow SSH command execution"
      description: "95th percentile command execution time is {{ $value }}s"

  # Task queue alerts
  - alert: HighTaskQueueLength
    expr: sum(task_queue_length) > 50
    for: 5m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High task queue length"
      description: "Task queue has {{ $value }} pending tasks"

  - alert: TaskExecutionFailure
    expr: rate(task_total{status="failed"}[5m]) > 0.05
    for: 2m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High task failure rate"
      description: "Task failure rate is {{ $value | humanizePercentage }}"

  # Cache alerts
  - alert: LowCacheHitRate
    expr: rate(cache_hits_total[5m]) / (rate(cache_hits_total[5m]) + rate(cache_misses_total[5m])) < 0.8
    for: 5m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "Low cache hit rate"
      description: "Cache hit rate is {{ $value | humanizePercentage }}"

  # Application alerts
  - alert: ApplicationDown
    expr: up{job="ssh-mcp"} == 0
    for: 1m
    labels:
      severity: critical
      service: ssh-mcp
    annotations:
      summary: "SSH MCP application is down"
      description: "{{ $labels.instance }} has been down for more than 1 minute"

  - alert: HighErrorRate
    expr: rate(app_requests_total{status=~"5.."}[5m]) / rate(app_requests_total[5m]) > 0.05
    for: 3m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High application error rate"
      description: "Application error rate is {{ $value | humanizePercentage }}"

  - alert: SlowApplicationResponse
    expr: histogram_quantile(0.95, rate(app_request_duration_seconds_bucket[5m])) > 5
    for: 5m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "Slow application response time"
      description: "95th percentile response time is {{ $value }}s"

  # Authentication alerts
  - alert: HighAuthFailureRate
    expr: rate(auth_attempts_total{status="failed"}[5m]) / rate(auth_attempts_total[5m]) > 0.2
    for: 2m
    labels:
      severity: warning
      service: ssh-mcp
    annotations:
      summary: "High authentication failure rate"
      description: "Authentication failure rate is {{ $value | humanizePercentage }}"

  - alert: BruteForceAttack
    expr: rate(auth_attempts_total{status="failed"}[1m]) > 10
    for: 1m
    labels:
      severity: critical
      service: ssh-mcp
    annotations:
      summary: "Potential brute force attack detected"
      description: "{{ $value }} failed authentication attempts per minute"
EOF

    log_success "Prometheus configuration created"
}

# Function to create Grafana provisioning configuration
create_grafana_config() {
    log_info "Creating Grafana provisioning configuration..."

    local grafana_dir="$PROJECT_ROOT/docker/grafana"
    mkdir -p "$grafana_dir/provisioning/datasources"
    mkdir -p "$grafana_dir/provisioning/dashboards"
    mkdir -p "$grafana_dir/dashboards"

    # Create datasource provisioning
    cat > "$grafana_dir/provisioning/datasources/prometheus.yml" << EOF
apiVersion: 1

datasources:
  - name: $PROMETHEUS_DATASOURCE
    type: prometheus
    access: proxy
    url: $PROMETHEUS_URL
    isDefault: true
    editable: true
    jsonData:
      httpMethod: POST
      manageAlerts: true
      prometheusType: Prometheus
      prometheusVersion: 2.40.0
      cacheLevel: High
      disableRecordingRules: false
      incrementalQueryOverlapWindow: 10m
EOF

    # Create dashboard provisioning
    cat > "$grafana_dir/provisioning/dashboards/ssh-mcp.yml" << EOF
apiVersion: 1

providers:
  - name: 'ssh-mcp-dashboards'
    orgId: 1
    folder: ''
    type: file
    disableDeletion: false
    updateIntervalSeconds: 10
    allowUiUpdates: true
    options:
      path: /var/lib/grafana/dashboards
EOF

    log_success "Grafana provisioning configuration created"
}

# Function to create Grafana dashboards
create_grafana_dashboards() {
    log_info "Creating Grafana dashboards..."

    local grafana_dir="$PROJECT_ROOT/docker/grafana/dashboards"

    # Main dashboard
    python3 - << 'PYTHON_EOF'
import json
import os

dashboard = {
    "dashboard": {
        "id": None,
        "title": "SSH MCP Overview",
        "tags": ["ssh", "mcp", "overview"],
        "timezone": "browser",
        "panels": [
            {
                "id": 1,
                "title": "Active SSH Connections",
                "type": "stat",
                "gridPos": {"h": 8, "w": 6, "x": 0, "y": 0},
                "targets": [
                    {
                        "expr": "sum(ssh_connections_active)",
                        "refId": "A"
                    }
                ],
                "fieldConfig": {
                    "defaults": {
                        "unit": "short",
                        "thresholds": {
                            "steps": [
                                {"color": "green", "value": null},
                                {"color": "yellow", "value": 50},
                                {"color": "red", "value": 100}
                            ]
                        }
                    }
                }
            },
            {
                "id": 2,
                "title": "Command Success Rate",
                "type": "stat",
                "gridPos": {"h": 8, "w": 6, "x": 6, "y": 0},
                "targets": [
                    {
                        "expr": "rate(ssh_commands_successful_total[5m]) / rate(ssh_commands_total[5m]) * 100",
                        "refId": "A"
                    }
                ],
                "fieldConfig": {
                    "defaults": {
                        "unit": "percent",
                        "thresholds": {
                            "steps": [
                                {"color": "red", "value": null},
                                {"color": "yellow", "value": 90},
                                {"color": "green", "value": 95}
                            ]
                        }
                    }
                }
            },
            {
                "id": 3,
                "title": "CPU Usage",
                "type": "stat",
                "gridPos": {"h": 8, "w": 6, "x": 12, "y": 0},
                "targets": [
                    {
                        "expr": "cpu_usage_percent",
                        "refId": "A"
                    }
                ],
                "fieldConfig": {
                    "defaults": {
                        "unit": "percent",
                        "thresholds": {
                            "steps": [
                                {"color": "green", "value": null},
                                {"color": "yellow", "value": 70},
                                {"color": "red", "value": 90}
                            ]
                        }
                    }
                }
            },
            {
                "id": 4,
                "title": "Memory Usage",
                "type": "stat",
                "gridPos": {"h": 8, "w": 6, "x": 18, "y": 0},
                "targets": [
                    {
                        "expr": "memory_usage_percent",
                        "refId": "A"
                    }
                ],
                "fieldConfig": {
                    "defaults": {
                        "unit": "percent",
                        "thresholds": {
                            "steps": [
                                {"color": "green", "value": null},
                                {"color": "yellow", "value": 80},
                                {"color": "red", "value": 95}
                            ]
                        }
                    }
                }
            }
        ],
        "time": {
            "from": "now-1h",
            "to": "now"
        },
        "refresh": "30s",
        "schemaVersion": 36,
        "version": 1
    }
}

# Write dashboard to file
grafana_dir = os.environ.get('GRAFANA_DIR', '/tmp/grafana/dashboards')
os.makedirs(grafana_dir, exist_ok=True)

with open(f'{grafana_dir}/ssh-mcp-overview.json', 'w') as f:
    json.dump(dashboard, f, indent=2)

print("Grafana dashboard created successfully")
PYTHON_EOF

    log_success "Grafana dashboards created"
}

# Function to wait for services to be ready
wait_for_services() {
    log_info "Waiting for services to be ready..."

    # Wait for Prometheus
    local prometheus_ready=false
    for i in {1..30}; do
        if curl -s "$PROMETHEUS_URL/-/healthy" > /dev/null 2>&1; then
            prometheus_ready=true
            break
        fi
        sleep 2
    done

    if [[ "$prometheus_ready" == true ]]; then
        log_success "Prometheus is ready"
    else
        log_error "Prometheus is not ready after 60 seconds"
        return 1
    fi

    # Wait for Grafana
    local grafana_ready=false
    for i in {1..30}; do
        if curl -s "$GRAFANA_URL/api/health" > /dev/null 2>&1; then
            grafana_ready=true
            break
        fi
        sleep 2
    done

    if [[ "$grafana_ready" == true ]]; then
        log_success "Grafana is ready"
    else
        log_error "Grafana is not ready after 60 seconds"
        return 1
    fi
}

# Function to setup Grafana datasources and dashboards
setup_grafana() {
    log_info "Setting up Grafana datasources and dashboards..."

    # Create Grafana API token
    local token_response=$(curl -s -X POST \
        "$GRAFANA_URL/api/auth/keys" \
        -H "Content-Type: application/json" \
        -u "$GRAFANA_USER:$GRAFANA_PASSWORD" \
        -d '{"name":"ssh-mcp-setup","role":"admin"}' | jq -r '.key // empty')

    if [[ -n "$token_response" ]]; then
        log_info "Created Grafana API token"
    else
        log_warning "Could not create Grafana API token, using existing credentials"
    fi

    # Use Python script to setup Grafana integration
    python3 - << PYTHON_EOF
import sys
sys.path.append('$PROJECT_ROOT/src')

try:
    from linux_ssh_mcp.monitoring.grafana_integration import GrafanaIntegration

    grafana = GrafanaIntegration(
        grafana_url='$GRAFANA_URL',
        api_key='$token_response' if '$token_response' else None,
        username='$GRAFANA_USER',
        password='$GRAFANA_PASSWORD'
    )

    success = grafana.setup_complete_monitoring('$PROMETHEUS_URL')

    if success:
        print("Grafana monitoring setup completed successfully")
    else:
        print("Grafana monitoring setup failed")
        sys.exit(1)

except Exception as e:
    print(f"Error setting up Grafana: {e}")
    sys.exit(1)
PYTHON_EOF
}

# Function to validate monitoring setup
validate_monitoring() {
    log_info "Validating monitoring setup..."

    # Check Prometheus targets
    log_info "Checking Prometheus targets..."
    curl -s "$PROMETHEUS_URL/api/v1/targets" | jq '.data.activeTargets[] | select(.health != "up") | {job: .labels.job, instance: .labels.instance, health: .health, lastError: .lastError}'

    # Check Grafana datasources
    log_info "Checking Grafana datasources..."
    curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" "$GRAFANA_URL/api/datasources" | jq '.[] | {name: .name, type: .type, url: .url, access: .access}'

    # Check Grafana dashboards
    log_info "Checking Grafana dashboards..."
    curl -s -u "$GRAFANA_USER:$GRAFANA_PASSWORD" "$GRAFANA_URL/api/search?query=ssh" | jq '.[] | {title: .title, uid: .uid, uri: .uri}'

    log_success "Monitoring validation completed"
}

# Function to show monitoring URLs
show_monitoring_info() {
    cat << EOF
${GREEN}Monitoring setup completed successfully!${NC}

${BLUE}Access URLs:${NC}
  - Prometheus: $PROMETHEUS_URL
  - Grafana: $GRAFANA_URL

${BLUE}Grafana Login:${NC}
  - Username: $GRAFANA_USER
  - Password: $GRAFANA_PASSWORD

${BLUE}Available Dashboards:${NC}
  - SSH MCP Overview
  - SSH MCP Alerting

${BLUE}Next Steps:${NC}
  1. Visit Grafana and explore the dashboards
  2. Set up alert notifications
  3. Customize dashboards as needed
  4. Configure alert routing (optional)

${YELLOW}Note:${NC} Make sure the SSH MCP application is running to see metrics data.
EOF
}

# Function to clean up monitoring
cleanup_monitoring() {
    log_info "Cleaning up monitoring setup..."

    # Remove Docker containers
    if docker ps -a | grep -q "prometheus\|grafana"; then
        docker stop prometheus grafana 2>/dev/null || true
        docker rm prometheus grafana 2>/dev/null || true
    fi

    # Remove configuration files
    rm -rf "$PROJECT_ROOT/docker/prometheus"
    rm -rf "$PROJECT_ROOT/docker/grafana"

    log_success "Monitoring cleanup completed"
}

# Function to show usage
usage() {
    cat << EOF
Linux SSH MCP Monitoring Setup Script

Usage: $0 <command>

Commands:
    setup           Set up complete monitoring with Prometheus and Grafana
    validate        Validate monitoring configuration
    info            Show monitoring access information
    cleanup         Clean up monitoring setup
    help            Show this help message

Environment Variables:
    PROMETHEUS_URL          Prometheus URL (default: http://localhost:9090)
    GRAFANA_URL            Grafana URL (default: http://localhost:3000)
    GRAFANA_USER           Grafana username (default: admin)
    GRAFANA_PASSWORD       Grafana password (default: admin)

Examples:
    $0 setup
    $0 validate
    $0 info
    $0 cleanup
EOF
}

# Main execution
main() {
    export GRAFANA_DIR="$PROJECT_ROOT/docker/grafana/dashboards"

    case "${1:-}" in
        setup)
            create_prometheus_config
            create_grafana_config
            create_grafana_dashboards
            wait_for_services
            setup_grafana
            validate_monitoring
            show_monitoring_info
            ;;
        validate)
            validate_monitoring
            ;;
        info)
            show_monitoring_info
            ;;
        cleanup)
            cleanup_monitoring
            ;;
        help|"")
            usage
            ;;
        *)
            log_error "Unknown command: $1"
            usage
            exit 1
            ;;
    esac
}

# Execute main function
main "$@"