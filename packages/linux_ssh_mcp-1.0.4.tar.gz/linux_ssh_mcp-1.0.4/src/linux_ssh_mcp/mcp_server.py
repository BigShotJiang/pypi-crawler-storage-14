#!/usr/bin/env python3
"""
Linux SSH MCP Server - Model Context Protocol Server
"""

import asyncio
import json
import sys
import logging
from typing import Any, Dict, List, Optional, Sequence

from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.types import (
    Resource, Tool, TextContent, ImageContent, EmbeddedResource,
    LoggingLevel, CallToolRequest, ListToolsRequest
)

from .ssh_manager import SSHManager, ServerConfig
from .auth import AuthManager, UserRole


# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global SSH Manager
ssh_manager = SSHManager()


class LinuxSSHMCP:
    """Linux SSH MCP Server"""

    def __init__(self):
        self.server = Server("linux-ssh-mcp")
        self.setup_handlers()

    def setup_handlers(self):
        """Setup MCP server handlers"""

        @self.server.list_tools()
        async def handle_list_tools() -> List[Tool]:
            """List available tools"""
            return [
                Tool(
                    name="list_servers",
                    description="List all configured SSH servers",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    }
                ),
                Tool(
                    name="execute_command",
                    description="Execute a command on a remote SSH server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID"
                            },
                            "command": {
                                "type": "string",
                                "description": "Command to execute"
                            },
                            "timeout": {
                                "type": "number",
                                "description": "Command timeout in seconds (optional)"
                            }
                        },
                        "required": ["server", "command"]
                    }
                ),
                Tool(
                    name="add_server",
                    description="Add a new SSH server configuration",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "name": {"type": "string", "description": "Server name/ID"},
                            "host": {"type": "string", "description": "Server hostname or IP"},
                            "port": {"type": "number", "description": "SSH port (default: 22)"},
                            "username": {"type": "string", "description": "SSH username"},
                            "password": {"type": "string", "description": "SSH password (optional)"},
                            "timeout": {"type": "number", "description": "Connection timeout (default: 30)"}
                        },
                        "required": ["name", "host", "username"]
                    }
                ),
                Tool(
                    name="test_connection",
                    description="Test SSH connection to a server",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID"
                            }
                        },
                        "required": ["server"]
                    }
                ),
                Tool(
                    name="get_server_status",
                    description="Get status information for servers",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID (optional, if not provided returns all servers)"
                            }
                        }
                    }
                ),
                Tool(
                    name="remove_server",
                    description="Remove a server configuration",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "server": {
                                "type": "string",
                                "description": "Server name/ID"
                            }
                        },
                        "required": ["server"]
                    }
                )
            ]

        @self.server.call_tool()
        async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool calls"""
            try:
                if name == "list_servers":
                    servers = ssh_manager.list_servers()
                    result = []
                    for server_id in servers:
                        config = ssh_manager.get_server_config(server_id)
                        if config:
                            result.append({
                                "id": server_id,
                                "host": config.host,
                                "port": config.port,
                                "username": config.username
                            })

                    return [TextContent(
                        type="text",
                        text=json.dumps(result, indent=2)
                    )]

                elif name == "execute_command":
                    server = arguments.get("server")
                    command = arguments.get("command")
                    timeout = arguments.get("timeout")

                    if not server or not command:
                        return [TextContent(
                            type="text",
                            text="Error: server and command are required"
                        )]

                    result = await ssh_manager.execute_command(server, command, timeout)

                    response = {
                        "success": result.success,
                        "stdout": result.stdout,
                        "stderr": result.stderr,
                        "exit_code": result.exit_code,
                        "execution_time": result.execution_time,
                        "command": result.command
                    }

                    return [TextContent(
                        type="text",
                        text=json.dumps(response, indent=2)
                    )]

                elif name == "add_server":
                    name_arg = arguments.get("name")
                    host = arguments.get("host")
                    port = arguments.get("port", 22)
                    username = arguments.get("username")
                    password = arguments.get("password")
                    timeout = arguments.get("timeout", 30)

                    if not all([name_arg, host, username]):
                        return [TextContent(
                            type="text",
                            text="Error: name, host, and username are required"
                        )]

                    config = ServerConfig(
                        id=name_arg,
                        host=host,
                        port=port,
                        username=username,
                        password=password,
                        timeout=timeout
                    )

                    try:
                        ssh_manager.add_server(config)

                        # Test connection
                        connection_test = await ssh_manager.test_connection(name_arg)

                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": True,
                                "message": f"Server '{name_arg}' added successfully",
                                "connection_test": connection_test
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "test_connection":
                    server = arguments.get("server")
                    if not server:
                        return [TextContent(
                            type="text",
                            text="Error: server name is required"
                        )]

                    try:
                        is_connected = await ssh_manager.test_connection(server)
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "server": server,
                                "connected": is_connected,
                                "message": "Connection successful" if is_connected else "Connection failed"
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "server": server,
                                "connected": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                elif name == "get_server_status":
                    server = arguments.get("server")

                    if server:
                        # Get specific server status
                        config = ssh_manager.get_server_config(server)
                        if not config:
                            return [TextContent(
                                type="text",
                                text=json.dumps({"error": f"Server '{server}' not found"}, indent=2)
                            )]

                        try:
                            status = await ssh_manager.get_server_status(server)
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "server": server,
                                    "host": config.host,
                                    "port": config.port,
                                    "username": config.username,
                                    "status": status.value
                                }, indent=2)
                            )]
                        except Exception as e:
                            return [TextContent(
                                type="text",
                                text=json.dumps({
                                    "server": server,
                                    "status": "error",
                                    "error": str(e)
                                }, indent=2)
                            )]
                    else:
                        # Get all servers status
                        servers = ssh_manager.list_servers()
                        result = []
                        for server_id in servers:
                            config = ssh_manager.get_server_config(server_id)
                            if config:
                                try:
                                    status = await ssh_manager.get_server_status(server_id)
                                    result.append({
                                        "server": server_id,
                                        "host": config.host,
                                        "port": config.port,
                                        "username": config.username,
                                        "status": status.value
                                    })
                                except Exception as e:
                                    result.append({
                                        "server": server_id,
                                        "host": config.host,
                                        "port": config.port,
                                        "username": config.username,
                                        "status": "error",
                                        "error": str(e)
                                    })

                        return [TextContent(
                            type="text",
                            text=json.dumps(result, indent=2)
                        )]

                elif name == "remove_server":
                    server = arguments.get("server")
                    if not server:
                        return [TextContent(
                            type="text",
                            text="Error: server name is required"
                        )]

                    try:
                        success = ssh_manager.remove_server(server)
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": success,
                                "message": f"Server '{server}' removed successfully" if success else f"Server '{server}' not found"
                            }, indent=2)
                        )]
                    except Exception as e:
                        return [TextContent(
                            type="text",
                            text=json.dumps({
                                "success": False,
                                "error": str(e)
                            }, indent=2)
                        )]

                else:
                    return [TextContent(
                        type="text",
                        text=f"Unknown tool: {name}"
                    )]

            except Exception as e:
                logger.error(f"Error in tool {name}: {e}")
                return [TextContent(
                    type="text",
                    text=json.dumps({"error": str(e)}, indent=2)
                )]

    async def run(self):
        """Run the MCP server"""
        # Setup stdin/stdout communication using the current MCP API
        from mcp.server.stdio import stdio_server

        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="linux-ssh-mcp",
                    server_version="1.0.3",
                    capabilities=self.server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={}
                    )
                )
            )


async def main():
    """Main entry point"""
    try:
        logger.info("Starting Linux SSH MCP Server")
        mcp_server = LinuxSSHMCP()
        await mcp_server.run()
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}")
        sys.exit(1)


def main_sync():
    """Synchronous entry point"""
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()