#!/usr/bin/env python3
"""
Grafana integration for Linux SSH MCP

Provides dashboard configuration and data visualization integration with Grafana.
"""

import json
import requests
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta


class GrafanaIntegration:
    """Grafana dashboard and visualization management"""

    def __init__(self, grafana_url: str = "http://localhost:3000",
                 api_key: Optional[str] = None, username: str = "admin",
                 password: str = "admin"):
        self.grafana_url = grafana_url.rstrip('/')
        self.api_key = api_key
        self.username = username
        self.password = password
        self.session = requests.Session()
        self._authenticated = False

    def authenticate(self) -> bool:
        """Authenticate with Grafana"""
        try:
            if self.api_key:
                # Use API key authentication
                self.session.headers.update({
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                })
                self._authenticated = True
            else:
                # Use username/password authentication
                auth_data = {
                    "user": self.username,
                    "password": self.password
                }
                response = self.session.post(
                    f"{self.grafana_url}/api/login",
                    json=auth_data
                )
                if response.status_code == 200:
                    token = response.json().get('id')
                    self.session.headers.update({
                        'Authorization': f'Bearer {token}',
                        'Content-Type': 'application/json'
                    })
                    self._authenticated = True
                else:
                    print(f"Grafana authentication failed: {response.text}")
                    return False

            print("Grafana authentication successful")
            return True

        except Exception as e:
            print(f"Error authenticating with Grafana: {e}")
            return False

    def create_datasource(self, name: str, prometheus_url: str) -> bool:
        """Create Prometheus datasource"""
        if not self._authenticated:
            if not self.authenticate():
                return False

        datasource_data = {
            "name": name,
            "type": "prometheus",
            "access": "proxy",
            "url": prometheus_url,
            "database": "",
            "user": "",
            "password": "",
            "basicAuth": False,
            "basicAuthUser": "",
            "basicAuthPassword": "",
            "withCredentials": False,
            "isDefault": True,
            "jsonData": {
                "httpMethod": "POST",
                "manageAlerts": True,
                "prometheusType": "Prometheus",
                "prometheusVersion": "2.40.0",
                "cacheLevel": "High",
                "disableRecordingRules": False,
                "incrementalQueryOverlapWindow": "10m"
            },
            "secureJsonData": {}
        }

        try:
            response = self.session.post(
                f"{self.grafana_url}/api/datasources",
                json=datasource_data
            )
            if response.status_code in [200, 409]:  # 409 = datasource already exists
                print(f"Datasource '{name}' created successfully")
                return True
            else:
                print(f"Failed to create datasource: {response.text}")
                return False

        except Exception as e:
            print(f"Error creating datasource: {e}")
            return False

    def create_dashboard(self, dashboard_config: Dict[str, Any]) -> bool:
        """Create a Grafana dashboard"""
        if not self._authenticated:
            if not self.authenticate():
                return False

        try:
            # Wrap dashboard config as required by Grafana API
            payload = {
                "dashboard": dashboard_config,
                "folderId": 0,
                "overwrite": True
            }

            response = self.session.post(
                f"{self.grafana_url}/api/dashboards/db",
                json=payload
            )
            if response.status_code == 200:
                result = response.json()
                dashboard_url = f"{self.grafana_url}/{result.get('url', '')}"
                print(f"Dashboard created successfully: {dashboard_url}")
                return True
            else:
                print(f"Failed to create dashboard: {response.text}")
                return False

        except Exception as e:
            print(f"Error creating dashboard: {e}")
            return False

    def create_ssh_mcp_dashboard(self, prometheus_datasource: str = "Prometheus") -> Dict[str, Any]:
        """Create SSH MCP dashboard configuration"""
        dashboard = {
            "id": None,
            "title": "SSH MCP Monitoring",
            "tags": ["ssh", "mcp", "monitoring"],
            "timezone": "browser",
            "panels": [
                # Overview section
                {
                    "id": 1,
                    "title": "SSH Connections",
                    "type": "stat",
                    "gridPos": {"h": 8, "w": 6, "x": 0, "y": 0},
                    "targets": [
                        {
                            "expr": "sum(ssh_connections_active)",
                            "refId": "A",
                            "datasource": prometheus_datasource
                        }
                    ],
                    "fieldConfig": {
                        "defaults": {
                            "color": {"mode": "palette-classic"},
                            "custom": {"displayMode": "list", "orientation": "horizontal"},
                            "mappings": [],
                            "thresholds": {
                                "steps": [
                                    {"color": "green", "value": null},
                                    {"color": "yellow", "value": 50},
                                    {"color": "red", "value": 100}
                                ]
                            },
                            "unit": "short"
                        },
                        "overrides": []
                    }
                },
                {
                    "id": 2,
                    "title": "Success Rate",
                    "type": "stat",
                    "gridPos": {"h": 8, "w": 6, "x": 6, "y": 0},
                    "targets": [
                        {
                            "expr": "rate(ssh_commands_successful_total[5m]) / rate(ssh_commands_total[5m]) * 100",
                            "refId": "A",
                            "datasource": prometheus_datasource
                        }
                    ],
                    "fieldConfig": {
                        "defaults": {
                            "unit": "percent",
                            "thresholds": {
                                "steps": [
                                    {"color": "red", "value": null},
                                    {"color": "yellow", "value": 90},
                                    {"color": "green", "value": 95}
                                ]
                            }
                        }
                    }
                },
                {
                    "id": 3,
                    "title": "Active Tasks",
                    "type": "stat",
                    "gridPos": {"h": 8, "w": 6, "x": 12, "y": 0},
                    "targets": [
                        {
                            "expr": "sum(task_queue_length)",
                            "refId": "A",
                            "datasource": prometheus_datasource
                        }
                    ],
                    "fieldConfig": {
                        "defaults": {
                            "unit": "short",
                            "thresholds": {
                                "steps": [
                                    {"color": "green", "value": null},
                                    {"color": "yellow", "value": 20},
                                    {"color": "red", "value": 50}
                                ]
                            }
                        }
                    }
                },
                {
                    "id": 4,
                    "title": "Cache Hit Rate",
                    "type": "stat",
                    "gridPos": {"h": 8, "w": 6, "x": 18, "y": 0},
                    "targets": [
                        {
                            "expr": "cache_hits_total / (cache_hits_total + cache_misses_total) * 100",
                            "refId": "A",
                            "datasource": prometheus_datasource
                        }
                    ],
                    "fieldConfig": {
                        "defaults": {
                            "unit": "percent",
                            "thresholds": {
                                "steps": [
                                    {"color": "red", "value": null},
                                    {"color": "yellow", "value": 80},
                                    {"color": "green", "value": 90}
                                ]
                            }
                        }
                    }
                },

                # System metrics section
                {
                    "id": 5,
                    "title": "CPU Usage",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 8},
                    "targets": [
                        {
                            "expr": "cpu_usage_percent",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "CPU %"
                        }
                    ],
                    "yAxes": [
                        {"max": 100, "min": 0, "unit": "percent"},
                        {"max": null, "min": null}
                    ]
                },
                {
                    "id": 6,
                    "title": "Memory Usage",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 8},
                    "targets": [
                        {
                            "expr": "memory_usage_percent",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "Memory %"
                        }
                    ],
                    "yAxes": [
                        {"max": 100, "min": 0, "unit": "percent"},
                        {"max": null, "min": null}
                    ]
                },

                # SSH metrics section
                {
                    "id": 7,
                    "title": "Command Execution Time",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 16},
                    "targets": [
                        {
                            "expr": "histogram_quantile(0.95, rate(ssh_command_duration_seconds_bucket[5m]))",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "95th percentile"
                        },
                        {
                            "expr": "histogram_quantile(0.50, rate(ssh_command_duration_seconds_bucket[5m]))",
                            "refId": "B",
                            "datasource": prometheus_datasource,
                            "legendFormat": "50th percentile"
                        }
                    ],
                    "yAxes": [
                        {"max": null, "min": 0, "unit": "s"},
                        {"max": null, "min": null}
                    ]
                },
                {
                    "id": 8,
                    "title": "Commands per Server",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 16},
                    "targets": [
                        {
                            "expr": "rate(ssh_commands_total[5m])",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "{{server_id}}"
                        }
                    ],
                    "yAxes": [
                        {"max": null, "min": 0, "unit": "reqps"},
                        {"max": null, "min": null}
                    ]
                },

                # Task queue section
                {
                    "id": 9,
                    "title": "Task Queue Length",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 24},
                    "targets": [
                        {
                            "expr": "task_queue_length",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "{{priority}} - {{status}}"
                        }
                    ],
                    "yAxes": [
                        {"max": null, "min": 0, "unit": "short"},
                        {"max": null, "min": null}
                    ]
                },
                {
                    "id": 10,
                    "title": "Task Execution Time",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 24},
                    "targets": [
                        {
                            "expr": "histogram_quantile(0.95, rate(task_execution_duration_seconds_bucket[5m]))",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "95th percentile - {{task_type}}"
                        }
                    ],
                    "yAxes": [
                        {"max": null, "min": 0, "unit": "s"},
                        {"max": null, "min": null}
                    ]
                },

                # Batch operations section
                {
                    "id": 11,
                    "title": "Batch Operation Duration",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 0, "y": 32},
                    "targets": [
                        {
                            "expr": "histogram_quantile(0.95, rate(batch_duration_seconds_bucket[5m]))",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "95th percentile - {{operation_type}}"
                        }
                    ],
                    "yAxes": [
                        {"max": null, "min": 0, "unit": "s"},
                        {"max": null, "min": null}
                    ]
                },
                {
                    "id": 12,
                    "title": "Cache Performance",
                    "type": "graph",
                    "gridPos": {"h": 8, "w": 12, "x": 12, "y": 32},
                    "targets": [
                        {
                            "expr": "rate(cache_hits_total[5m])",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "legendFormat": "Hits - {{cache_type}}"
                        },
                        {
                            "expr": "rate(cache_misses_total[5m])",
                            "refId": "B",
                            "datasource": prometheus_datasource,
                            "legendFormat": "Misses - {{cache_type}}"
                        }
                    ],
                    "yAxes": [
                        {"max": null, "min": 0, "unit": "reqps"},
                        {"max": null, "min": null}
                    ]
                }
            ],
            "time": {
                "from": "now-1h",
                "to": "now"
            },
            "refresh": "30s",
            "schemaVersion": 36,
            "version": 1,
            "uid": "ssh-mcp-dashboard"
        }

        return dashboard

    def create_alerting_dashboard(self, prometheus_datasource: str = "Prometheus") -> Dict[str, Any]:
        """Create alerting dashboard configuration"""
        dashboard = {
            "id": None,
            "title": "SSH MCP Alerting",
            "tags": ["ssh", "mcp", "alerts"],
            "timezone": "browser",
            "panels": [
                {
                    "id": 1,
                    "title": "System Alerts",
                    "type": "table",
                    "gridPos": {"h": 8, "w": 24, "x": 0, "y": 0},
                    "targets": [
                        {
                            "expr": "ALERTS{job=\"ssh-mcp\", alertname=~\"High.*Usage\"}",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "format": "table"
                        }
                    ],
                    "fieldConfig": {
                        "defaults": {
                            "color": {"mode": "thresholds"},
                            "thresholds": {
                                "steps": [
                                    {"color": "green", "value": null},
                                    {"color": "red", "value": 1}
                                ]
                            }
                        }
                    }
                },
                {
                    "id": 2,
                    "title": "Connection Alerts",
                    "type": "table",
                    "gridPos": {"h": 8, "w": 24, "x": 0, "y": 8},
                    "targets": [
                        {
                            "expr": "ALERTS{job=\"ssh-mcp\", alertname=~\".*Connection.*\"}",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "format": "table"
                        }
                    ]
                },
                {
                    "id": 3,
                    "title": "Performance Alerts",
                    "type": "table",
                    "gridPos": {"h": 8, "w": 24, "x": 0, "y": 16},
                    "targets": [
                        {
                            "expr": "ALERTS{job=\"ssh-mcp\", alertname=~\".*Performance.*\"}",
                            "refId": "A",
                            "datasource": prometheus_datasource,
                            "format": "table"
                        }
                    ]
                }
            ],
            "time": {
                "from": "now-6h",
                "to": "now"
            },
            "refresh": "1m",
            "schemaVersion": 36,
            "version": 1,
            "uid": "ssh-mcp-alerts"
        }

        return dashboard

    def setup_complete_monitoring(self, prometheus_url: str) -> bool:
        """Setup complete monitoring with datasources and dashboards"""
        print("Setting up Grafana monitoring...")

        # Create datasource
        if not self.create_datasource("SSH-MCP-Prometheus", prometheus_url):
            return False

        # Create main dashboard
        main_dashboard = self.create_ssh_mcp_dashboard("SSH-MCP-Prometheus")
        if not self.create_dashboard(main_dashboard):
            return False

        # Create alerting dashboard
        alerts_dashboard = self.create_alerting_dashboard("SSH-MCP-Prometheus")
        if not self.create_dashboard(alerts_dashboard):
            return False

        print("Grafana monitoring setup completed successfully")
        print(f"Access Grafana at: {self.grafana_url}")
        print(f"Default login: {self.username}")

        return True

    def export_dashboard_json(self, dashboard_config: Dict[str, Any], filename: str):
        """Export dashboard configuration to JSON file"""
        try:
            with open(filename, 'w') as f:
                json.dump(dashboard_config, f, indent=2)
            print(f"Dashboard exported to {filename}")
        except Exception as e:
            print(f"Error exporting dashboard: {e}")

    def import_dashboard_json(self, filename: str) -> Optional[Dict[str, Any]]:
        """Import dashboard configuration from JSON file"""
        try:
            with open(filename, 'r') as f:
                dashboard = json.load(f)
            print(f"Dashboard imported from {filename}")
            return dashboard
        except Exception as e:
            print(f"Error importing dashboard: {e}")
            return None