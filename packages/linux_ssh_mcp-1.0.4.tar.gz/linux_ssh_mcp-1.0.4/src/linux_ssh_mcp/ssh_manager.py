#!/usr/bin/env python3
"""
SSH连接管理模块
"""

import asyncio
import asyncssh
import json
import os
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
import time


class ServerStatus(Enum):
    """服务器状态枚举"""
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


@dataclass
class ServerConfig:
    """服务器配置"""
    id: str
    host: str
    port: int = 22
    username: str = "root"
    password: Optional[str] = None
    timeout: int = 30
    private_key: Optional[str] = None

    def __post_init__(self):
        if not self.id:
            raise ValueError("服务器ID不能为空")
        if not self.host:
            raise ValueError("主机地址不能为空")


@dataclass
class CommandResult:
    """命令执行结果"""
    success: bool
    stdout: str
    stderr: str
    exit_code: int
    execution_time: float
    command: str


class SSHManager:
    """SSH连接管理器"""

    def __init__(self, use_pooling: bool = True, config_file: str = "servers.json"):
        self.use_pooling = use_pooling
        self.config_file = config_file
        self.servers: Dict[str, ServerConfig] = {}
        self.connections: Dict[str, Any] = {}
        self.stats = {
            "total_connections": 0,
            "successful_connections": 0,
            "failed_connections": 0,
            "total_commands": 0,
            "successful_commands": 0,
            "failed_commands": 0
        }
        self._load_servers()
        self.stats["total_connections"] = 0  # Reset connection stats on startup

    def add_server(self, config: ServerConfig) -> None:
        """添加服务器配置"""
        self.servers[config.id] = config
        self._save_servers()
        print(f"Added server: {config.id} ({config.host}:{config.port})")

    def remove_server(self, server_id: str) -> bool:
        """移除服务器配置"""
        if server_id in self.servers:
            # 关闭连接
            if server_id in self.connections:
                asyncio.create_task(self._close_connection(server_id))
            del self.servers[server_id]
            self._save_servers()
            return True
        return False

    def list_servers(self) -> List[str]:
        """列出所有服务器ID"""
        return list(self.servers.keys())

    def get_server_config(self, server_id: str) -> Optional[ServerConfig]:
        """获取服务器配置"""
        return self.servers.get(server_id)

    async def execute_command(self, server_id: str, command: str,
                            timeout: Optional[int] = None) -> CommandResult:
        """Execute SSH command"""
        if server_id not in self.servers:
            return CommandResult(
                success=False,
                stdout="",
                stderr=f"Server {server_id} not found",
                exit_code=1,
                execution_time=0.0,
                command=command
            )

        start_time = time.time()
        self.stats["total_commands"] += 1

        try:
            connection = await self._get_connection(server_id)
            if not connection:
                raise Exception(f"Failed to connect to server {server_id}")

            print(f"Executing command: {command} (server: {server_id})")

            # Execute the command
            result = await connection.run(command, timeout=timeout or 30)

            command_result = CommandResult(
                success=result.exit_status == 0,
                stdout=result.stdout,
                stderr=result.stderr,
                exit_code=result.exit_status,
                execution_time=time.time() - start_time,
                command=command
            )

            if command_result.success:
                self.stats["successful_commands"] += 1
            else:
                self.stats["failed_commands"] += 1

            return command_result

        except Exception as e:
            result = CommandResult(
                success=False,
                stdout="",
                stderr=str(e),
                exit_code=1,
                execution_time=time.time() - start_time,
                command=command
            )

            self.stats["failed_commands"] += 1
            return result

    async def get_server_status(self, server_id: str) -> ServerStatus:
        """获取服务器状态"""
        if server_id not in self.servers:
            return ServerStatus.ERROR

        # 简化状态检查
        try:
            # 模拟连接测试
            config = self.servers[server_id]
            await asyncio.sleep(0.01)  # 模拟网络延迟
            return ServerStatus.CONNECTED
        except Exception:
            return ServerStatus.DISCONNECTED

    async def test_connection(self, server_id: str) -> bool:
        """Test server connection"""
        try:
            connection = await self._get_connection(server_id)
            return connection is not None
        except Exception:
            return False

    async def _close_connection(self, server_id: str) -> None:
        """Close connection"""
        if server_id in self.connections:
            connection = self.connections[server_id]
            connection.close()
            await connection.wait_closed()
            del self.connections[server_id]

    async def cleanup_connections(self) -> None:
        """Clean up all connections"""
        for server_id in list(self.connections.keys()):
            await self._close_connection(server_id)
        print("All SSH connections cleaned up")

    def get_performance_metrics(self) -> Dict[str, Any]:
        """获取性能指标"""
        success_rate = 0.0
        if self.stats["total_connections"] > 0:
            success_rate = self.stats["successful_connections"] / self.stats["total_connections"]

        command_success_rate = 0.0
        if self.stats["total_commands"] > 0:
            command_success_rate = self.stats["successful_commands"] / self.stats["total_commands"]

        return {
            "ssh_connections": {
                "total": self.stats["total_connections"],
                "successful": self.stats["successful_connections"],
                "failed": self.stats["failed_connections"],
                "success_rate": success_rate,
                "active_connections": len(self.connections)
            },
            "ssh_commands": {
                "total": self.stats["total_commands"],
                "successful": self.stats["successful_commands"],
                "failed": self.stats["failed_commands"],
                "success_rate": command_success_rate
            },
            "servers": {
                "total": len(self.servers),
                "configured": len(self.servers),
                "connected": len(self.connections)
            }
        }

    def _load_servers(self) -> None:
        """Load servers from config file"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for server_id, server_data in data.items():
                        # Convert password to None if it's empty string
                        if 'password' in server_data and server_data['password'] == '':
                            server_data['password'] = None
                        self.servers[server_id] = ServerConfig(**server_data)
        except Exception as e:
            print(f"Warning: Failed to load servers config: {e}")

    def _save_servers(self) -> None:
        """Save servers to config file"""
        try:
            data = {}
            for server_id, config in self.servers.items():
                # Convert config to dict
                config_dict = asdict(config)
                data[server_id] = config_dict

            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Warning: Failed to save servers config: {e}")

    async def _get_connection(self, server_id: str) -> Optional[asyncssh.SSHClientConnection]:
        """Get or create SSH connection"""
        if server_id not in self.servers:
            return None

        if self.use_pooling and server_id in self.connections:
            return self.connections[server_id]

        self.stats["total_connections"] += 1
        config = self.servers[server_id]

        try:
            # Create connection options
            connect_kwargs = {
                'host': config.host,
                'port': config.port,
                'username': config.username,
                'connect_timeout': config.timeout,
                'known_hosts': None  # Disable host key checking for simplicity
            }

            # Add password or key authentication
            if config.password:
                connect_kwargs['password'] = config.password
            elif config.private_key:
                connect_kwargs['client_keys'] = [config.private_key]

            connection = await asyncssh.connect(**connect_kwargs)

            if self.use_pooling:
                self.connections[server_id] = connection

            self.stats["successful_connections"] += 1
            return connection

        except Exception as e:
            self.stats["failed_connections"] += 1
            raise e