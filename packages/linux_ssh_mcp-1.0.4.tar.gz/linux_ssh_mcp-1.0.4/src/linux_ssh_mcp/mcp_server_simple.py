#!/usr/bin/env python3
"""
Linux SSH MCP Server - Simple Test Version
"""

import asyncio
import json
import sys
import logging
from typing import Any, Dict, List

from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.types import (
    Resource, Tool, TextContent, ImageContent, EmbeddedResource,
    LoggingLevel
)

from .ssh_manager import SSHManager, ServerConfig

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global SSH Manager
ssh_manager = SSHManager()


def create_server():
    """Create and configure the MCP server"""
    server = Server("linux-ssh-mcp")

    @server.list_tools()
    async def handle_list_tools() -> List[Tool]:
        """List available tools"""
        return [
            Tool(
                name="list_servers",
                description="List all configured SSH servers",
                inputSchema={
                    "type": "object",
                    "properties": {},
                }
            ),
            Tool(
                name="execute_command",
                description="Execute a command on a remote SSH server",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "server": {"type": "string", "description": "Server name/ID"},
                        "command": {"type": "string", "description": "Command to execute"}
                    },
                    "required": ["server", "command"]
                }
            ),
            Tool(
                name="test_connection",
                description="Test SSH connection to a server",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "server": {"type": "string", "description": "Server name/ID"}
                    },
                    "required": ["server"]
                }
            )
        ]

    @server.call_tool()
    async def handle_call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
        """Handle tool calls"""
        try:
            if name == "list_servers":
                servers = ssh_manager.list_servers()
                result = []
                for server_id in servers:
                    config = ssh_manager.get_server_config(server_id)
                    if config:
                        result.append({
                            "id": server_id,
                            "host": config.host,
                            "port": config.port,
                            "username": config.username
                        })

                return [TextContent(
                    type="text",
                    text=json.dumps(result, indent=2)
                )]

            elif name == "execute_command":
                server = arguments.get("server")
                command = arguments.get("command")

                if not server or not command:
                    return [TextContent(
                        type="text",
                        text="Error: server and command are required"
                    )]

                result = await ssh_manager.execute_command(server, command)

                response = {
                    "success": result.success,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "exit_code": result.exit_code,
                    "execution_time": result.execution_time,
                    "command": result.command
                }

                return [TextContent(
                    type="text",
                    text=json.dumps(response, indent=2)
                )]

            elif name == "test_connection":
                server = arguments.get("server")
                if not server:
                    return [TextContent(
                        type="text",
                        text="Error: server name is required"
                    )]

                try:
                    is_connected = await ssh_manager.test_connection(server)
                    return [TextContent(
                        type="text",
                        text=json.dumps({
                            "server": server,
                            "connected": is_connected,
                            "message": "Connection successful" if is_connected else "Connection failed"
                        }, indent=2)
                    )]
                except Exception as e:
                    return [TextContent(
                        type="text",
                        text=json.dumps({
                            "server": server,
                            "connected": False,
                            "error": str(e)
                        }, indent=2)
                    )]

            else:
                return [TextContent(
                    type="text",
                    text=f"Unknown tool: {name}"
                )]

        except Exception as e:
            logger.error(f"Error in tool {name}: {e}")
            return [TextContent(
                type="text",
                text=json.dumps({"error": str(e)}, indent=2)
            )]

    return server


async def main():
    """Main entry point"""
    try:
        logger.info("Starting Linux SSH MCP Server")

        # Create the server
        server = create_server()

        # Use the stdio transport
        from mcp.server.stdio import stdio_server

        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="linux-ssh-mcp",
                    server_version="1.0.3",
                    capabilities=server.get_capabilities(
                        notification_options=NotificationOptions(),
                        experimental_capabilities={}
                    )
                )
            )
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


def main_sync():
    """Synchronous entry point"""
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()