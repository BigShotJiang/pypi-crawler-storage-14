# Linux SSH MCP (Model Context Protocol)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](https://www.docker.com/)
[![Kubernetes](https://img.shields.io/badge/kubernetes-ready-blue.svg)](https://kubernetes.io/)

A comprehensive Linux SSH management system built with Model Context Protocol (MCP) integration, providing advanced SSH connection management, monitoring, task queuing, and distributed deployment capabilities.

## 🚀 Features

### Core Features
- **Multi-Server SSH Management**: Manage multiple Linux servers through a unified interface
- **Connection Pooling**: Optimized connection management with reusable SSH connections
- **Asynchronous Operations**: High-performance async/await architecture
- **Task Queue System**: Advanced queuing with priority management and retry logic
- **Multi-Layer Caching**: Memory, disk, and distributed caching for performance optimization
- **Batch Operations**: Execute commands across multiple servers with various strategies
- **Real-time Monitoring**: Comprehensive performance monitoring and alerting

### Advanced Features
- **Web Interface**: Flask-based graphical configuration and monitoring dashboard
- **Authentication & Authorization**: Multi-method auth with role-based access control
- **Distributed Deployment**: Docker and Kubernetes support with auto-scaling
- **Monitoring Integration**: Prometheus metrics and Grafana dashboards
- **Security Features**: API keys, rate limiting, session management, audit logging
- **Health Checks**: Automated health monitoring and recovery

## 📋 Requirements

- Python 3.8+
- Docker & Docker Compose (for containerized deployment)
- Kubernetes (optional, for distributed deployment)
- Redis (for caching and session management)
- PostgreSQL (for data persistence)

## 🛠️ Quick Start

### Option 1: Docker Compose (Recommended)

1. **Clone and Setup**
   ```bash
   git clone <repository-url>
   cd linux-ssh-mcp
   chmod +x scripts/*.sh
   ```

2. **Deploy**
   ```bash
   ./scripts/deploy.sh deploy docker-compose
   ```

3. **Access Services**
   - API: http://localhost:8000
   - Web Interface: http://localhost:5000
   - Grafana: http://localhost:3000 (admin/admin)
   - Prometheus: http://localhost:9090

### Option 2: Kubernetes Deployment

1. **Deploy to Kubernetes**
   ```bash
   ./scripts/deploy.sh deploy kubernetes
   ```

2. **Access Services**
   ```bash
   kubectl port-forward service/ssh-mcp-service 8000:8000 -n ssh-mcp
   ```

### Option 3: Python Development

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run Basic Example**
   ```bash
   python examples/basic_usage.py
   ```

3. **Run Web Interface**
   ```bash
   python -m web_interface.app
   ```

## 📖 Documentation

### Core Documentation
- [API Documentation](docs/API_DOCUMENTATION.md) - Complete API reference
- [Configuration Guide](docs/CONFIGURATION.md) - Setup and configuration
- [Security Guide](docs/SECURITY.md) - Security features and best practices
- [Monitoring Guide](docs/MONITORING.md) - Monitoring and alerting

### Examples
- [Basic Usage](examples/basic_usage.py) - Getting started examples
- [Batch Operations](examples/batch_operations.py) - Advanced batch processing
- [Web Interface](web_interface/) - Complete web-based management

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Web Interface │    │   REST API      │    │  MCP Protocol   │
│   (Flask/UI)    │◄──►│   (FastAPI)     │◄──►│  (Integration)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ Authentication  │    │  Task Queue     │    │  Cache System   │
│   & AuthZ       │    │  (Priority)     │    │  (Multi-Level)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SSH Management Core                           │
│  ┌─────────────┐ ┌─────────────┐ ┌───────────────────────────┐ │
│  │ Connection  │ │   Batch     │ │     Performance           │ │
│  │    Pool     │ │ Optimizer   │ │     Monitor               │ │
│  └─────────────┘ └─────────────┘ └───────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Infrastructure                              │
│  ┌─────────────┐ ┌─────────────┐ ┌───────────────────────────┐ │
│  │ PostgreSQL  │ │    Redis    │ │     Monitoring            │ │
│  │  (Database) │ │   (Cache)   │ │  (Prometheus/Grafana)     │ │
│  └─────────────┘ └─────────────┘ └───────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## 🔧 Configuration

### Environment Variables
```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/sshmcp

# Redis
REDIS_URL=redis://localhost:6379

# Application
SECRET_KEY=your-secret-key
LOG_LEVEL=INFO
CLUSTER_MODE=true

# Monitoring
METRICS_ENABLED=true
PROMETHEUS_PORT=9090
```

### Server Configuration
```python
from linux_ssh_mcp import SSHManager, ServerConfig

# Create manager
ssh_manager = SSHManager(use_pooling=True)

# Add server
config = ServerConfig(
    id="web-server-01",
    host="192.168.1.100",
    port=22,
    username="admin",
    password="password",
    timeout=30
)

ssh_manager.add_server(config)
```

## 📊 Monitoring

### Built-in Metrics
- **System Metrics**: CPU, memory, disk usage
- **SSH Metrics**: Connection count, command execution time, success rates
- **Application Metrics**: Request rates, response times, error rates
- **Task Queue Metrics**: Queue length, execution time, failure rates
- **Cache Metrics**: Hit rates, memory usage, eviction counts

### Grafana Dashboards
- **Overview Dashboard**: System health and key metrics
- **Performance Dashboard**: Detailed performance analysis
- **Alerting Dashboard**: Active alerts and notifications

### Prometheus Alerts
- High CPU/Memory usage
- SSH connection failures
- Command execution failures
- Task queue bottlenecks
- Application downtime

## 🔒 Security

### Authentication Methods
- Password authentication
- API key authentication
- SSH key authentication
- Token-based authentication
- LDAP integration
- OAuth 2.0 support

### Security Features
- Rate limiting
- IP whitelisting
- Session management
- Password strength validation
- Audit logging
- SSL/TLS encryption

## 🚀 Deployment

### Docker Deployment
```bash
# Single command deployment
./scripts/deploy.sh deploy docker-compose

# Scale services
./scripts/deploy.sh scale ssh-mcp-main 3

# Monitor deployment
./scripts/deploy.sh status
```

### Kubernetes Deployment
```bash
# Deploy to Kubernetes
./scripts/deploy.sh deploy kubernetes

# Check deployment status
kubectl get all -n ssh-mcp

# Scale deployment
kubectl scale deployment/ssh-mcp --replicas=5 -n ssh-mcp
```

### Monitoring Setup
```bash
# Setup complete monitoring
./scripts/monitoring-setup.sh setup

# Validate monitoring
./scripts/monitoring-setup.sh validate
```

## 📝 API Usage

### REST API Examples
```bash
# Get server list
curl http://localhost:8000/api/servers

# Add new server
curl -X POST http://localhost:8000/api/servers \
  -H "Content-Type: application/json" \
  -d '{"id": "new-server", "host": "192.168.1.101", "username": "admin"}'

# Execute command
curl -X POST http://localhost:8000/api/execute \
  -H "Content-Type: application/json" \
  -d '{"server_id": "web-server-01", "command": "uptime"}'
```

### Python API Examples
```python
# Basic SSH connection
result = await ssh_manager.execute_command("web-server-01", "uptime")
print(f"Output: {result.stdout}")
print(f"Duration: {result.execution_time}s")

# Batch operations
from linux_ssh_mcp.batch_optimizer import BatchCommand

commands = [
    BatchCommand("cmd1", "server1", "uptime"),
    BatchCommand("cmd2", "server2", "df -h")
]

result = await batch_optimizer.execute_batch(commands)
print(f"Completed: {result.completed_commands}/{result.total_commands}")
```

## 🧪 Testing

### Run Tests
```bash
# Run all tests
python -m pytest tests/

# Run specific test category
python -m pytest tests/test_ssh_manager.py

# Run with coverage
python -m pytest --cov=linux_ssh_mcp tests/
```

### Integration Tests
```bash
# Test SSH connections
python examples/basic_usage.py

# Test batch operations
python examples/batch_operations.py

# Test web interface
curl http://localhost:5000
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Setup
```bash
# Clone repository
git clone <repository-url>
cd linux-ssh-mcp

# Install development dependencies
pip install -r requirements-dev.txt

# Run linting
flake8 src/
black src/

# Run type checking
mypy src/
```

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

### Documentation
- [API Documentation](docs/API_DOCUMENTATION.md)
- [Configuration Guide](docs/CONFIGURATION.md)
- [Troubleshooting Guide](docs/TROUBLESHOOTING.md)

### Community
- GitHub Issues: Report bugs and request features
- Discussions: Ask questions and share ideas
- Wiki: Community-contributed guides

### Contributing
- [Contributing Guide](CONTRIBUTING.md)
- [Code of Conduct](CODE_OF_CONDUCT.md)

## 🗺️ Roadmap

### Version 1.1 (Planned)
- [ ] Enhanced web interface with real-time updates
- [ ] Advanced scheduling and cron jobs
- [ ] Plugin system for custom integrations
- [ ] Enhanced security features

### Version 1.2 (Future)
- [ ] Multi-cloud deployment support
- [ ] Advanced analytics and ML integration
- [ ] Mobile application
- [ ] Enhanced backup and disaster recovery

## 📊 Performance

### Benchmarks
- **Connection Establishment**: <100ms (pooled), <500ms (new)
- **Command Execution**: <1s average for simple commands
- **Batch Operations**: Linear scaling with parallel execution
- **Memory Usage**: ~50MB base + ~1MB per connection
- **CPU Usage**: ~5% idle, up to 80% under heavy load

### Scalability
- **Max Concurrent Connections**: 1000+ per instance
- **Max Concurrent Tasks**: 500+ per instance
- **Horizontal Scaling**: Auto-scaling support
- **High Availability**: 99.9% uptime with proper configuration

---

**Built with ❤️ for the Linux SSH management community**