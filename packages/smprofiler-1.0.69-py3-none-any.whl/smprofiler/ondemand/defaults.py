
FEATURE_MATRIX_WITH_INTENSITIES = 'feature_matrix with intensities'
FEATURE_MATRIX_WITH_INTENSITIES_SUBSAMPLE_WHOLE_STUDY = 'feature matrix whole study subsample'
WHOLE_STUDY_SUBSAMPLE_BINARY_ONLY = 'whole study subsample binary portion'
