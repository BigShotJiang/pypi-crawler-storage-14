"""Classes that provide metric calculation on demand."""
