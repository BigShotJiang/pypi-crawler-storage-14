DROP TABLE study_lookup;
