VIRTUAL_SAMPLE = 'UMAP virtual sample'
VIRTUAL_SAMPLE_SPEC1 = (VIRTUAL_SAMPLE, 'UMAP virtual sample feature matrix')
VIRTUAL_SAMPLE_SPEC2 = (VIRTUAL_SAMPLE, 'UMAP virtual sample centroids')
VIRTUAL_SAMPLE_COMPRESSED = 'umap_data_brotli'