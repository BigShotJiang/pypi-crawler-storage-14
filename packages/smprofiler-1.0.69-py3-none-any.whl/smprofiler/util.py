"""Utilities used across the smprofiler package."""

STRFTIME_FORMAT = r"%Y-%m-%d %H:%M:%S"
