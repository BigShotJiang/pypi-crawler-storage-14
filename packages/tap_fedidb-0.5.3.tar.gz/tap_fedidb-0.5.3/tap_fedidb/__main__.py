"""Tap executable."""

from __future__ import annotations

from tap_fedidb import TapFediDB

TapFediDB.cli()
