"""
a.k.a Clean Slate Utils
"""

__version__ = "1.19.0"
