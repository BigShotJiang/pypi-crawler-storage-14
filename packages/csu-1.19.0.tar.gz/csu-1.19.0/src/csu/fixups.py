from django.utils.translation import gettext_lazy

# fixup broken translation
gettext_lazy("Ensure this field has at least {min_length} characters.")
