import os
import sys
from pathlib import Path
import platform

# 导入yaml模块（在打包和安装时都应包含这个依赖）
import yaml

# 添加当前目录到Python路径，使其可以直接运行
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入日志模块
from shortcutkey.logger import logger
from shortcutkey.lang_manager import _


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, default_config_path=None):
        """初始化配置管理器"""
        # 获取用户配置目录
        if sys.platform == 'win32':
            self.user_config_dir = Path(os.environ['APPDATA']) / '.shortcutkey'
        else:
            self.user_config_dir = Path.home() / '.shortcutkey'
        
        self.config_file = self.user_config_dir / 'config.yaml'
        self.default_config_path = default_config_path
        
        # 确保配置目录存在
        try:
            self.user_config_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"创建配置目录: {self.user_config_dir}")
        except Exception as e:
            logger.error(f"创建配置目录失败: {str(e)}")
        
        logger.info(f"ConfigManager初始化，配置文件路径: {self.config_file}")
        logger.info(f"默认配置路径: {self.default_config_path}")
    
    def has_config(self):
        """检查配置文件是否存在"""
        result = self.config_file.exists()
        logger.debug(f"检查配置文件是否存在: {self.config_file}, 结果: {result}")
        return result
    
    def get_config(self):
        """获取配置"""
        if not self.has_config():
            logger.info("用户配置文件不存在，尝试加载默认配置")
            if self.default_config_path and os.path.exists(self.default_config_path):
                try:
                    with open(self.default_config_path, 'r', encoding='utf-8') as f:
                        default_config = yaml.safe_load(f) or {}
                    logger.info(f"成功加载默认配置: {self.default_config_path}")
                    return default_config
                except Exception as e:
                    logger.error(f"加载默认配置失败: {str(e)}")
            return {}
        
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f) or {}
                logger.info(f"成功读取配置文件: {self.config_file}, 配置内容: {config}")
                return config
        except Exception as e:
            logger.error(f"读取配置文件失败: {str(e)}")
            return {}
    
    def save_config(self, config):
        """保存配置"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
            logger.info(f"配置已成功保存到: {self.config_file}, 配置内容: {config}")
            
            # 自动触发配置热加载
            self._trigger_config_reload()
            
        except Exception as e:
            logger.error(f"保存配置文件失败: {str(e)}")
    
    def _trigger_config_reload(self):
        """触发配置重新加载"""
        try:
            # 创建重载信号文件
            user_home = os.path.expanduser("~")
            pid_dir = os.path.join(user_home, ".shortcutkey")
            reload_signal_file = os.path.join(pid_dir, "reload_signal")
            
            # 确保目录存在
            if not os.path.exists(pid_dir):
                os.makedirs(pid_dir)
            
            # 创建信号文件
            with open(reload_signal_file, 'w') as f:
                import time
                f.write(str(time.time()))
            
            logger.info("配置重载信号已发送，配置将立即生效")
            # print(_('config_effective'))
            
        except Exception as e:
            logger.error(f"发送配置重载信号失败: {str(e)}")
            # 这里不抛出异常，因为即使热加载失败，配置也已经保存成功
    
    def setup_configuration(self):
        """设置配置"""
        print(_('config_wizard_title'))
        print(_('config_wizard_prompt'))
        
        config = {
            'shortcuts': []
        }
        
        while True:
            print(_('add_shortcut_prompt'))
            
            # 获取程序路径
            print(_('enter_app_path'))
            print(_('path_tip'))
            
            # 根据操作系统提供不同的提示
            if platform.system() == 'Darwin':  # macOS
                print(_('mac_app_path_hint'))
            elif platform.system() == 'Windows':
                print(_('windows_app_path_hint'))
            else:  # Linux
                print(_('linux_app_path_hint'))
            
            app_path = input(_('app_path_or_name') + ' ').strip()
            
            # 获取快捷键
            if platform.system() == 'Darwin':  # macOS
                print("\n" + _('mac_hotkey_prompt'))
                print(_('hotkey_example').format(modifier="cmd+shift", key="c"))
                modifier_keys = "cmd+shift"
            else:  # Windows 和 Linux
                print("\n" + _('win_linux_hotkey_prompt'))
                print(_('hotkey_example').format(modifier="ctrl+shift", key="c"))
                modifier_keys = "ctrl+shift"
            
            # 获取用户输入的字母
            while True:
                key_input = input(_('enter_letter') + ' ').strip().lower()
                # 验证输入是否为单个字母
                if len(key_input) == 1 and key_input.isalpha():
                    # 自动组合完整快捷键
                    hotkey = f"{modifier_keys}+{key_input}"
                    print(_('hotkey_created').format(hotkey=hotkey))
                    break
                else:
                    print(_('error_single_letter'))
            
            # 获取程序名称（可选，用于显示）
            app_name = input(_('app_display_name') + ' ').strip() or app_path
            
            # 添加到配置
            config['shortcuts'].append({
                'name': app_name,
                'path': app_path,
                'hotkey': hotkey
            })
            
            # 是否继续添加
            if input("\n" + _('continue_adding') + ' ').lower() != 'y':
                break
        
        # 保存配置
        self.save_config(config)
        print("\n" + _('config_saved_to').format(config_file=self.config_file))