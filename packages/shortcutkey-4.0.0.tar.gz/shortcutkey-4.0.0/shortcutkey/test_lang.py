#!/usr/bin/env python3
# 测试语言管理器是否能正确加载翻译键

import sys
from pathlib import Path

# 添加项目根目录到Python路径，确保可以正确导入模块
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# 导入语言管理器
from shortcutkey.lang_manager import _, get_lang_manager

def test_basic_translation():
    """测试基本的翻译功能"""
    print("=== 测试基本翻译功能 ===")
    # 测试configure_hotkeys.title键
    title = _('configure_hotkeys.title')
    print(f"configure_hotkeys.title = {title}")
    assert title != 'configure_hotkeys.title', "翻译键未能正确转换"
    print("✓ 基本翻译功能测试通过")

def test_lang_manager_state():
    """测试语言管理器的状态"""
    print("\n=== 测试语言管理器状态 ===")
    lang_manager = get_lang_manager()
    print(f"当前语言: {lang_manager.language}")
    print(f"语言文件路径: {lang_manager.language_file_path}")
    
    # 检查语言文件是否被正确加载
    if lang_manager.language_file_path and lang_manager.language_file_path.exists():
        print("✓ 语言文件存在且已加载")
    else:
        print("✗ 警告: 语言文件未找到或无法加载")
    
    # 检查翻译字典
    print(f"翻译字典类型: {type(lang_manager.translations)}")
    print(f"支持的语言: {list(lang_manager.translations.keys())}")
    
    # 检查当前语言是否在翻译字典中
    current_lang = lang_manager.language
    if current_lang in lang_manager.translations:
        print(f"\n当前语言'{current_lang}'的翻译项:")
        lang_dict = lang_manager.translations[current_lang]
        print(f"顶层翻译键数量: {len(lang_dict)}")
        print(f"顶层翻译键: {list(lang_dict.keys())}")
        
        # 检查configure_hotkeys是否存在
        if 'configure_hotkeys' in lang_dict:
            print("✓ configure_hotkeys键存在")
            print(f"configure_hotkeys中的键: {list(lang_dict['configure_hotkeys'].keys())}")
            
            # 检查title键是否存在
            if 'title' in lang_dict['configure_hotkeys']:
                print(f"✓ title键存在，值为: {lang_dict['configure_hotkeys']['title']}")
            else:
                print("✗ title键不存在")
        else:
            print("✗ configure_hotkeys键不存在")
    else:
        print(f"✗ 当前语言'{current_lang}'不在翻译字典中")

def test_multiple_translation_keys():
    """测试多个翻译键"""
    print("\n=== 测试多个翻译键 ===")
    test_keys = [
        'configure_hotkeys.title',
        'configure_hotkeys.select_operation',
        'configure_hotkeys.add_hotkey',
        'config_effective'
    ]
    
    for key in test_keys:
        value = _(key)
        print(f"{key} = {value}")
        assert value != key, f"翻译键'{key}'未能正确转换"
    
    print("✓ 多个翻译键测试通过")

def test_language_switching():
    """测试语言切换功能"""
    print("\n=== 测试语言切换功能 ===")
    lang_manager = get_lang_manager()
    original_lang = lang_manager.language
    
    # 尝试切换语言
    if 'en' in lang_manager.translations and original_lang != 'en':
        print(f"切换到英语...")
        lang_manager.set_language('en')
        en_title = _('configure_hotkeys.title')
        print(f"英语标题: {en_title}")
        
        # 切换回原来的语言
        print(f"切换回原始语言 '{original_lang}'...")
        lang_manager.set_language(original_lang)
        original_title = _('configure_hotkeys.title')
        print(f"原始语言标题: {original_title}")
        
        assert en_title != original_title, "语言切换后标题应该不同"
        print("✓ 语言切换功能测试通过")
    else:
        print("跳过语言切换测试，因为英语翻译不可用或已是当前语言")

def test_formatting():
    """测试带参数的翻译格式化"""
    print("\n=== 测试带参数的翻译格式化 ===")
    # 假设存在带参数的翻译键
    if _('hotkey_example') != 'hotkey_example':
        try:
            formatted = _('hotkey_example', modifier='ctrl+shift', key='c')
            print(f"格式化后的翻译: {formatted}")
            print("✓ 翻译格式化测试通过")
        except Exception as e:
            print(f"✗ 翻译格式化失败: {e}")
    else:
        print("跳过翻译格式化测试，hotkey_example键未找到")

def main():
    """运行所有测试"""
    print("开始测试语言管理器...\n")
    
    try:
        test_basic_translation()
        test_lang_manager_state()
        test_multiple_translation_keys()
        test_language_switching()
        test_formatting()
        
        print("\n=== 所有测试完成 ===")
        print("如果没有看到错误信息，说明翻译功能正常工作！")
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
    except Exception as e:
        print(f"\n❌ 测试过程中出现异常: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    main()