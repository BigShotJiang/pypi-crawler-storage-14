## Paptools

To install this package, just run:

```pip install paptools```


If you want to install from the test repository, run:

```pip install --index-url https://test.pypi.org/simple \
            --extra-index-url https://pypi.org/simple \
            paptools
```