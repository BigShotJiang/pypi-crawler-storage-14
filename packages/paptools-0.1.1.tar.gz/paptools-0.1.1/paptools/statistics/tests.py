import numpy as np
from ..core.number import Number
from ..core.array import Array

def significance_test(x: Number, y: Number) -> np.ndarray:
    pass
    