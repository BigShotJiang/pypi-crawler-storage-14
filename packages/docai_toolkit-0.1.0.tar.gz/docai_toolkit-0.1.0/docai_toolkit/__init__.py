"""DocAI Toolkit package (renamed to avoid PyPI conflicts)."""

__all__ = ["config"]
