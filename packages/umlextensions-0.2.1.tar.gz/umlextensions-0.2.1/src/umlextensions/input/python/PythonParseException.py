
class PythonParseException(Exception):
    pass
