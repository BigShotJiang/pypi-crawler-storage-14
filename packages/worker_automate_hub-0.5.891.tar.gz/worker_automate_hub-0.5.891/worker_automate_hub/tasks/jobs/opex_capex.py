import difflib
import getpass
import os
import re
import warnings
import time
import uuid
from datetime import datetime, timedelta
import pyautogui
import pytesseract
import win32clipboard
from PIL import Image, ImageEnhance
from pywinauto.application import Application
from pywinauto.keyboard import send_keys
from pywinauto.timings import TimeoutError as PywTimeout, wait_until
from pywinauto_recorder.player import set_combobox
from rich.console import Console
import sys
import asyncio
from pywinauto import Desktop

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..","..","..")))
from worker_automate_hub.api.ahead_service import save_xml_to_downloads
from worker_automate_hub.api.client import (
    get_config_by_name,
    get_status_nf_emsys,
    get_dados_nf_emsys,
)
from worker_automate_hub.models.dto.rpa_historico_request_dto import (
    RpaHistoricoStatusEnum,
    RpaRetornoProcessoDTO,
    RpaTagDTO,
    RpaTagEnum,
)
from worker_automate_hub.models.dto.rpa_processo_entrada_dto import (
    RpaProcessoEntradaDTO,
)
from worker_automate_hub.utils.logger import logger
from worker_automate_hub.utils.util import (
    cod_icms,
    delete_xml,
    error_after_xml_imported,
    get_xml,
    import_nfe,
    incluir_registro,
    is_window_open,
    is_window_open_by_class,
    itens_not_found_supplier,
    kill_all_emsys,
    login_emsys,
    rateio_despesa,
    select_documento_type,
    set_variable,
    tipo_despesa,
    type_text_into_field,
    warnings_after_xml_imported,
    worker_sleep,
    zerar_icms,
    check_nota_importada,
)

pyautogui.PAUSE = 0.5
pyautogui.FAILSAFE = False
console = Console()

BASE_PATH = r"assets\entrada_notas"
# BASE_PATH = r"C:\Users\automatehub\Documents\GitHub\worker-automate-hub\assets\entrada_notas"


async def get_ultimo_item():
    console.print("[ITENS] Iniciando função get_ultimo_item...", style="bold cyan")
    send_keys("^({END})")
    await worker_sleep(2)
    send_keys("+{F10}")
    await worker_sleep(1)
    send_keys("{DOWN 2}")
    await worker_sleep(1)
    send_keys("{ENTER}")
    await worker_sleep(2)
    console.print("[ITENS] Conectando na janela 'Alteração de Item' para obter último índice...", style="cyan")
    app = Application().connect(title="Alteração de Item")
    main_window = app["Alteração de Item"]
    main_window.set_focus()
    edit = main_window.child_window(class_name="TDBIEditCode", found_index=0)
    index_ultimo_item = int(edit.window_text())
    console.print(f"[ITENS] Último item encontrado: {index_ultimo_item}", style="bold green")
    try:
        btn_cancelar = main_window.child_window(title="&Cancelar")
        btn_cancelar.click()
    except Exception as error:
        btn_cancelar = main_window.child_window(title="Cancelar")
        btn_cancelar.click()
        console.print(f"[ITENS] Erro ao fechar janela get_ultimo_item: {error}", style="bold yellow")
    await worker_sleep(1)
    return index_ultimo_item    


async def opex_capex(task: RpaProcessoEntradaDTO) -> RpaRetornoProcessoDTO:
    """
    Processo que realiza entrada de notas no ERP EMSys(Linx ).
    """
    numero_nota = None  # para uso no finally
    try:
        console.print("\n================ INÍCIO PROCESSO opex_capex ================\n", style="bold blue")
        console.print(f"[TASK] Dados da task recebida: {task}", style="cyan")

        # Get config from BOF
        console.print("[ETAPA 1] Buscando configuração de login_emsys via API...", style="bold cyan")
        config = await get_config_by_name("login_emsys")
        console.print("[ETAPA 1] Configuração 'login_emsys' obtida com sucesso.", style="bold green")

        # Seta config entrada na var nota para melhor entendimento
        nota = task.configEntrada
        console.print(f"[ETAPA 1] ConfigEntrada (nota): {nota}", style="cyan")

        multiplicador_timeout = int(float(task.sistemas[0].timeout))
        console.print(f"[ETAPA 1] Timeout multiplicador definido como: {multiplicador_timeout}", style="cyan")
        set_variable("timeout_multiplicador", multiplicador_timeout)

        # Fecha a instancia do emsys - caso esteja aberta
        console.print("[ETAPA 2] Fechando instâncias do EMSys se existirem...", style="bold cyan")
        await kill_all_emsys()
        data_atual = datetime.now().strftime("%d/%m/%Y")
        console.print(f"[ETAPA 2] Data atual: {data_atual}", style="cyan")

        # Buscar número da nota
        console.print("[ETAPA 3] Preparando dados da nota para consulta na API...", style="bold cyan")
        numero_nota = nota.get("numeroNota")
        serie_nota = nota.get("serieNota")
        fornecedor = nota.get("fornecedorCnpj")
        centro_custo = nota.get("centroCusto")
        centro_custo = centro_custo.split("-")[0].strip().lstrip("0")

        console.print(f"[ETAPA 3] NumeroNota={numero_nota} | Serie={serie_nota} | FornecedorCNPJ={fornecedor} | CentroCusto={centro_custo}", style="cyan")

        try:
            console.print("[ETAPA 4] Consultando dados da NF no EMSys via get_dados_nf_emsys...", style="bold cyan")
            dados_nf = await get_dados_nf_emsys(
                numero_nota=numero_nota,
                serie_nota=serie_nota,
                fornecedor=fornecedor
            )
            console.print(f"[ETAPA 4] Retorno get_dados_nf_emsys: {dados_nf}", style="cyan")

            # Se a API retornou erro
            if isinstance(dados_nf, dict) and "erro" in dados_nf:
                console.print("[ETAPA 4] Erro retornado pela API de dados NF.", style="bold red")
                console.print(f"[ETAPA 4] Detalhes erro API: {dados_nf['erro']}", style="red")
                nf_chave_acesso = None

            # Se retornou lista mas está vazia
            elif isinstance(dados_nf, list) and not dados_nf:
                console.print("[ETAPA 4] Nenhum dado encontrado para a nota na API.", style="bold yellow")
                nf_chave_acesso = None

            # Se retornou lista com dados
            else:
                nf_chave_acesso = dados_nf[0].get("chaveNfe")
                console.print(f"[ETAPA 4] Chave da NF obtida: {nf_chave_acesso}", style="bold green")

        except Exception as e:
            observacao = f"[ERRO ETAPA 4] Erro ao buscar nota via get_dados_nf_emsys: {e}"
            console.print(observacao, style="bold red")
            logger.error(observacao)
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=observacao,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)]
            )

        # Download XML
        console.print("[ETAPA 5] Iniciando download do XML da NF...", style="bold cyan")
        await save_xml_to_downloads(nf_chave_acesso)
        console.print("[ETAPA 5] XML baixado com sucesso.", style="bold green")

        console.print("[ETAPA 6] Consultando status da NF no EMSys via get_status_nf_emsys...", style="bold cyan")
        status_nf_emsys = await get_status_nf_emsys(nf_chave_acesso)
        console.print(f"[ETAPA 6] Status NF EMSys: {status_nf_emsys}", style="cyan")

        empresa_codigo = dados_nf[0]["empresaCodigo"]
        cfop = dados_nf[0]["numeroDoCfop"]
        cfops_itens = [item["cfopProduto"] for item in dados_nf[0]["itens"]]
        console.print(f"[ETAPA 6] EmpresaCodigo={empresa_codigo} | CFOP NF={cfop} | CFOPs Itens={cfops_itens}", style="cyan")

        if status_nf_emsys.get("status") == "Lançada":
            console.print(
                "\\Nota fiscal já lançada, processo finalizado...", style="bold green"
            )
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno="Nota fiscal já lançada",
                status=RpaHistoricoStatusEnum.Descartado,
            )
        else:
            console.print("\\Nota fiscal não lançada, iniciando o processo...", style="yellow")
        
        console.print("[ETAPA 7] Iniciando EMSys3_29.exe...", style="bold cyan")
        app = Application(backend="win32").start("C:\\Rezende\\EMSys3\\EMSys3_29.exe")
        warnings.filterwarnings(
            "ignore",
            category=UserWarning,
            message="32-bit application should be automated using 32-bit Python",
        )
        console.print("[ETAPA 7] EMSys iniciando...", style="bold green")

        console.print("[ETAPA 7] Realizando login no EMSys pelo login_emsys...", style="bold cyan")
        return_login = await login_emsys(config.conConfiguracao, app, task, filial_origem = empresa_codigo)

        if return_login.sucesso == True:
            console.print("[ETAPA 8] Login realizado com sucesso. Acessando menu 'Nota Fiscal de Entrada'...", style="bold green")
            type_text_into_field(
                "Nota Fiscal de Entrada", app["TFrmMenuPrincipal"]["Edit"], True, "50"
            )
            pyautogui.press("enter")
            await worker_sleep(2)
            pyautogui.press("enter")
            console.print(
                f"[ETAPA 8] Pesquisa: 'Nota Fiscal de Entrada' realizada com sucesso",
                style="bold green",
            )
        else:
            logger.info(f"[ETAPA 8] Error Message login: {return_login.retorno}")
            console.print(f"[ETAPA 8] Error Message login: {return_login.retorno}", style="bold red")
            return return_login

        await worker_sleep(6)

        # Procura campo documento
        console.print("[ETAPA 9] Selecionando tipo de documento: NOTA FISCAL DE ENTRADA ELETRONICA - DANFE...", style="bold cyan")
        document_type = await select_documento_type(
            "NOTA FISCAL DE ENTRADA ELETRONICA - DANFE"
        )
        if document_type.sucesso == True:
            console.log(document_type.retorno, style="bold green")
        else:
            console.print("[ETAPA 9] Falha ao selecionar tipo de documento.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=document_type.retorno,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        await worker_sleep(4)

        # Clica em 'Importar-Nfe'
        console.print("[ETAPA 10] Iniciando importação da NFe (XML)...", style="bold cyan")
        imported_nfe = await import_nfe()
        if imported_nfe.sucesso == True:
            console.log(imported_nfe.retorno, style="bold green")
        else:
            console.print("[ETAPA 10] Falha na importação da NFe.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=imported_nfe.retorno,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        await worker_sleep(5)

        console.print("[ETAPA 11] Buscando XML importado no EMSys via get_xml...", style="bold cyan")
        await get_xml(nf_chave_acesso)
        console.print("[ETAPA 11] get_xml concluído.", style="bold green")
        
        await worker_sleep(10)

        # VERIFICANDO A EXISTENCIA DE WARNINGS
        console.print("[ETAPA 12] Verificando existência de pop-up 'Warning' após importação do XML...", style="bold cyan")
        warning_pop_up = await is_window_open("Warning")
        if warning_pop_up["IsOpened"] == True:
            console.print("[ETAPA 12] Pop-up Warning encontrado, tratando via warnings_after_xml_imported...", style="yellow")
            warning_work = await warnings_after_xml_imported()
            if warning_work.sucesso == True:
                console.log(warning_work.retorno, style="bold green")
            else:
                console.print("[ETAPA 12] Falha ao tratar Warning após XML.", style="bold red")
                return RpaRetornoProcessoDTO(
                    sucesso=False,
                    retorno=warning_work.retorno,
                    status=RpaHistoricoStatusEnum.Falha,
                    tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
                )

        # VERIFICANDO A EXISTENCIA DE ERRO
        console.print("[ETAPA 13] Verificando existência de pop-up 'Erro' após importação do XML...", style="bold cyan")
        erro_pop_up = await is_window_open("Erro")
        if erro_pop_up["IsOpened"] == True:
            console.print("[ETAPA 13] Pop-up Erro encontrado, tratando via error_after_xml_imported...", style="bold red")
            error_work = await error_after_xml_imported()
            return RpaRetornoProcessoDTO(
                sucesso=error_work.sucesso,
                retorno=error_work.retorno,
                status=error_work.status,
                tags=error_work.tags
            )
        
        await worker_sleep(3)

        console.print("[ETAPA 14] Conectando na janela 'Informações para importação da Nota Fiscal Eletrônica'...", style="bold cyan")
        app = Application().connect(
            title="Informações para importação da Nota Fiscal Eletrônica"
        )
        main_window = app["Informações para importação da Nota Fiscal Eletrônica"]

        # =======================
        # === BLOCO CFOP COM RETRY
        # =======================
        console.print(f"[CFOP] Iniciando processo de seleção da Natureza de Operação (CFOP: {cfop})...", style="bold cyan")

        # Mapeamento CFOP -> (lista, código exibido no combobox)
        cfop_map = {
            "1556": (['5101', '5102', '5103', '5104'], "1.556"),
            "1407": (['5401', '5403', '5404', '5405'], "1.407"),
            "2407": (['6104', '6401', '6403', '6405'], "2.407")
        }

        cfop_str = str(cfop)
        cfop_key_escolhido = None
        codigo_combo_escolhido = None

        # Descobre qual chave do mapa usar
        for key, (lista, codigo_combo) in cfop_map.items():
            if cfop_str in lista:
                cfop_key_escolhido = key
                codigo_combo_escolhido = codigo_combo
                break

        console.print(f"[CFOP] CFOP NF: {cfop_str} | CFOP key escolhida: {cfop_key_escolhido} | Código combo: {codigo_combo_escolhido}", style="cyan")

        if not cfop_key_escolhido:
            msg = "Erro mapeado, CFOP diferente de início com 540 ou 510, necessário ação manual ou ajuste no robô..."
            console.print(f"[CFOP] {msg}", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=msg,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)]
            )

        max_tentativas_cfop = 3
        selecionou_cfop = False

        for tentativa in range(1, max_tentativas_cfop + 1):
            try:
                console.print(
                    f"[CFOP] Tentando selecionar Natureza de Operação (CFOP) - tentativa {tentativa}/{max_tentativas_cfop}...",
                    style="bold cyan",
                )

                combo_box_natureza_operacao = main_window.child_window(
                    class_name="TDBIComboBox", found_index=0
                )

                # Garante foco / clique no combo
                combo_box_natureza_operacao.set_focus()
                combo_box_natureza_operacao.click_input()
                await worker_sleep(1)

                texto_alvo_parcial = f"{cfop_key_escolhido}-COMPRA DE MERCADORIAS SEM ESTOQUE"
                texto_alvo_codigo = str(codigo_combo_escolhido)

                console.print(f"[CFOP] Buscando opção que contenha '{texto_alvo_parcial}' e '{texto_alvo_codigo}'...", style="cyan")

                # Percorre as opções do combo
                for opc in combo_box_natureza_operacao.item_texts():
                    if (texto_alvo_parcial in opc) and (texto_alvo_codigo in opc):
                        console.print(f"[CFOP] Opção candidata encontrada: {opc}", style="cyan")
                        combo_box_natureza_operacao.select(opc)
                        send_keys("{ENTER}")
                        await worker_sleep(1)

                        # Valida se algo ficou selecionado
                        texto_final = combo_box_natureza_operacao.window_text().strip()
                        console.print(f"[CFOP] Texto final no combo: '{texto_final}'", style="cyan")
                        if texto_alvo_codigo in texto_final or cfop_key_escolhido in texto_final:
                            selecionou_cfop = True
                            console.print(
                                f"[CFOP] Natureza de Operação selecionada com sucesso: {texto_final}",
                                style="bold green",
                            )
                            break

                if selecionou_cfop:
                    break
                else:
                    console.print(
                        "[CFOP] Não foi possível confirmar a seleção da Natureza de Operação. Tentando novamente...",
                        style="yellow",
                    )
                    await worker_sleep(2)

            except Exception as e:
                console.print(
                    f"[CFOP] Erro ao selecionar Natureza de Operação na tentativa {tentativa}/{max_tentativas_cfop}: {e}",
                    style="bold red",
                )
                await worker_sleep(2)

        if not selecionou_cfop:
            msg = "Não foi possível selecionar a Natureza de Operação (CFOP) após múltiplas tentativas."
            console.print(f"[CFOP] {msg}", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=msg,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        console.print(f"[CFOP] CFOP selecionado com base em {cfop_key_escolhido}. CFOP original da NF: {cfop}", style="bold green")
        # =======================
        # === FIM BLOCO CFOP COM RETRY
        # =======================

        await worker_sleep(3)

        # INTERAGINDO COM O CAMPO ALMOXARIFADO
        console.print("[ALMOXARIFADO] Iniciando preenchimento do almoxarifado...", style="bold cyan")
        fornecedor_nome = dados_nf[0]["fornecedorNome"]
        empresaCodigo = dados_nf[0]["empresaCodigo"]
        console.print(
            f"[ALMOXARIFADO] Fornecedor: {fornecedor_nome} | EmpresaCodigo: {empresaCodigo}",
            style="cyan"
        )
        console.print(
            f"[ALMOXARIFADO] Inserindo informação do Almoxarifado para empresa_codigo={empresa_codigo}...",
            style="cyan"
        )
        try:
            new_app = Application(backend="uia").connect(
                title="Informações para importação da Nota Fiscal Eletrônica"
            )
            window = new_app["Informações para importação da Nota Fiscal Eletrônica"]
            edit = window.child_window(
                class_name="TDBIEditCode", found_index=3, control_type="Edit"
            )
            if empresa_codigo == '1':
                valor_almoxarifado = empresaCodigo + "60"
            else:
                valor_almoxarifado = empresaCodigo + "50"
            console.print(f"[ALMOXARIFADO] Valor a ser inserido no almoxarifado: {valor_almoxarifado}", style="cyan")
            edit.set_edit_text(valor_almoxarifado)
            edit.type_keys("{TAB}")
            console.print("[ALMOXARIFADO] Almoxarifado preenchido com sucesso.", style="bold green")
        except Exception as e:
            console.print(f"[ALMOXARIFADO] Erro ao iterar itens de almoxarifado: {e}", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Erro ao iterar itens de almoxarifado: {e}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        await worker_sleep(3)
        console.print("[DESPESA] Inserindo conta contábil / tipo de despesa...", style="bold cyan")
        despesa = nota.get('contaContabil')
        console.print(f"[DESPESA] Conta contábil original: {despesa}", style="cyan")
        despesa = despesa.split("-")[0].strip()
        console.print(f"[DESPESA] Conta contábil tratada (apenas código): {despesa}", style="cyan")
        tipo_despesa_work = await tipo_despesa(despesa)
        if tipo_despesa_work.sucesso == True:
            console.log(tipo_despesa_work.retorno, style="bold green")
        else:
            console.print("[DESPESA] Falha na função tipo_despesa.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=tipo_despesa_work.retorno,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )
        await worker_sleep(5)
        
        try:
            console.print("[DESPESA] Verificando se existe tela de busca de tipo de despesa (TFrmBuscaGeralDialog)...", style="bold cyan")
            # Conectar à aplicação
            app = Application(backend="win32").connect(class_name="TFrmBuscaGeralDialog")

            # Acessar a janela buscar 
            janela = app.window(class_name="TFrmBuscaGeralDialog")
            janela.set_focus()
            # Clicar em cancelar
            janela.child_window(title="&Cancelar", class_name="TBitBtn").click()
            console.print("[DESPESA] Tela de busca de tipo de despesa encontrada. Tipo de despesa não localizado.", style="yellow")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno="Tipo de Despesa / conta contábil não localizado",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)]
            )
        except:
            console.print("[DESPESA] Tela de busca de tipo de despesa não apareceu. Seguindo fluxo normalmente.", style="cyan")
            pass

        await worker_sleep(3)
        
        # INTERAGINDO COM O CHECKBOX ZERAR ICMS
        console.print("[ICMS] Ativando checkbox 'Zerar ICMS'...", style="bold cyan")
        checkbox_zerar_icms = await zerar_icms()
        if checkbox_zerar_icms.sucesso == True:
            console.log(checkbox_zerar_icms.retorno, style="bold green")
        else:
            console.print("[ICMS] Falha na função zerar_icms.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=checkbox_zerar_icms.retorno,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        # INTERAGINDO COM O CAMPO DE CODIGO DO ICMS
        console.print("[ICMS] Definindo código ICMS conforme CFOP mapeado...", style="bold cyan")
        if cfop_key_escolhido == '1556':
            codigo_icms = '33'
        else:
            codigo_icms = '20'
        console.print(f"[ICMS] Código ICMS escolhido: {codigo_icms}", style="cyan")
        cod_icms_work = await cod_icms(codigo_icms)
        if cod_icms_work.sucesso == True:
            console.log(cod_icms_work.retorno, style="bold green")
        else:
            console.print("[ICMS] Falha na função cod_icms.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=cod_icms_work.retorno,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        await worker_sleep(3)

        # INTERAGINDO COM O CAMPO Manter Natureza de Operação selecionada
        console.print(
            "[CFOP] Selecionando a opção 'Manter Natureza de Operação selecionada'...",
            style="bold cyan"
        )
        checkbox = window.child_window(
            title="Manter Natureza de Operação selecionada",
            class_name="TDBICheckBox",
        )
        if not checkbox.get_toggle_state() == 1:
            checkbox.click()
            console.print(
                "[CFOP] Opção 'Manter Natureza de Operação selecionada' marcada com sucesso.",
                style="bold green"
            )
        else:
            console.print(
                "[CFOP] Opção 'Manter Natureza de Operação selecionada' já estava marcada.",
                style="cyan"
            )

        await worker_sleep(3)
        console.print("[CFOP] Clicando em OK para confirmar informações da importação...", style="bold cyan")

        max_attempts = 3
        i = 0
        while i < max_attempts:
            console.print(f"[CFOP] Tentativa {i+1}/{max_attempts} de clicar no botão OK...", style="cyan")
            try:
                try:
                    btn_ok = main_window.child_window(title="Ok")
                    btn_ok.click()
                    console.print("[CFOP] Clique no botão 'Ok' realizado (rótulo 'Ok').", style="cyan")
                except:
                    btn_ok = main_window.child_window(title="&Ok")
                    btn_ok.click()
                    console.print("[CFOP] Clique no botão '&Ok' realizado.", style="cyan")
            except:
                console.print("[CFOP] Não foi possível clicar no botão OK nesta tentativa.", style="yellow")

            await worker_sleep(3)

            console.print(
                "[CFOP] Verificando se a tela 'Informações para importação da Nota Fiscal Eletrônica' ainda está aberta...",
                style="cyan"
            )

            try:
                informacao_nf_eletronica = await is_window_open(
                    "Informações para importação da Nota Fiscal Eletrônica"
                )
                if not informacao_nf_eletronica["IsOpened"]:
                    console.print(
                        "[CFOP] Tela de Informações para importação fechada. Prosseguindo...",
                        style="bold green"
                    )
                    break
                else:
                    console.print(
                        "[CFOP] Tela ainda aberta após clique em OK.",
                        style="yellow"
                    )
            except Exception as e:
                console.print(
                    f"[CFOP] Erro ao verificar tela de informações: {e}. Tentativa {i + 1}/{max_attempts}.",
                    style="bold red"
                )

            i += 1

        if i == max_attempts:
            msg = "Número máximo de tentativas atingido, Não foi possivel finalizar os trabalhos na tela de Informações para importação da Nota Fiscal Eletrônica"
            console.print(f"[CFOP] {msg}", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=msg,
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        await worker_sleep(10)

        # Verificando itens não localizados ou NCM
        console.print("[ITENS] Verificando pop-up de itens não localizados / NCM (TFrmAguarde / TMessageForm)...", style="bold cyan")
        try:
            itens_by_supplier = await is_window_open_by_class("TFrmAguarde", "TMessageForm")
            console.print(f"[ITENS] Retorno is_window_open_by_class: {itens_by_supplier}", style="cyan")

            if itens_by_supplier["IsOpened"] == True:
                console.print("[ITENS] Pop-up de itens não localizados encontrado. Chamando itens_not_found_supplier...", style="yellow")
                itens_by_supplier_work = await itens_not_found_supplier(nota.get("nfe"))

                if not itens_by_supplier_work.sucesso:
                    console.print("[ITENS] Tratativa de itens não localizados retornou falha.", style="bold red")
                    return itens_by_supplier_work

        except Exception as error:
            console.print(
                f"[ITENS] Falha ao verificar a existência de POP-UP de itens não localizados: {error}",
                style="bold red"
            )
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Falha ao verificar a existência de POP-UP de itens não localizados: {error}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        await worker_sleep(10)
                
        # Clicar em itens da nota via imagem
        console.print("[ITENS] Localizando botão 'Itens da Nota' via imagem (itens_nota.png)...", style="bold cyan")
        imagem = fr"{BASE_PATH}\itens_nota.png"
        
        # Tenta localizar a imagem na tela
        tentativas_img = 0
        while True:
            tentativas_img += 1
            console.print(f"[ITENS] Tentativa {tentativas_img} de localizar imagem itens_nota.png...", style="cyan")
            local = pyautogui.locateCenterOnScreen(imagem, confidence=0.8)  # 0.8 = 80% de precisão
            if local:
                pyautogui.click(local)   # Clica no centro da imagem
                console.print("[ITENS] Imagem 'itens_nota.png' encontrada e clicada com sucesso!", style="bold green")
                break
            else:
                console.print("[ITENS] Imagem 'itens_nota.png' não encontrada, tentando novamente...", style="yellow")
                time.sleep(1)

        await worker_sleep(3)
        console.print("[ITENS] Clicando em 'Itens da nota' por coordenada (fallback)...", style="cyan")
        pyautogui.click(791, 379)
        await worker_sleep(2)

        console.print("[ITENS] Obtendo índice do último item via get_ultimo_item()...", style="bold cyan")
        index_item_atual = 0
        index_ultimo_item = await get_ultimo_item()
        console.print(f"[ITENS] Index último item retornado: {index_ultimo_item}", style="bold green")
        
        try:
            console.print("[ITENS] Iniciando loop para tratar ICMS/IPI item a item...", style="bold cyan")
            while index_item_atual < index_ultimo_item:
                console.print(f"[ITENS] Início do processamento do item índice {index_item_atual + 1}/{index_ultimo_item}...", style="cyan")
                send_keys("^({HOME})")
                await worker_sleep(1)

                if index_item_atual > 0:
                    send_keys("{DOWN " + str(index_item_atual) + "}")

                await worker_sleep(2)
                send_keys("+{F10}")
                await worker_sleep(1)
                send_keys("{DOWN 2}")
                await worker_sleep(1)
                send_keys("{ENTER}")

                await worker_sleep(2)
                app = Application().connect(title="Alteração de Item")
                main_window = app["Alteração de Item"]

                main_window.set_focus()

                edit = main_window.child_window(
                    class_name="TDBIEditCode", found_index=0
                )
                index_item_atual += 1
                console.print(f"[ITENS] Ítem atual no final da execução da tela: {index_item_atual}", style="cyan")
                await worker_sleep(1)

                # Listas
                lista_icms_090 = ["5101", "5102", "5103", "5104"]
                lista_icms_060 = ["5401", "5403", "5404", "5405", "6104", "6401", "6403", "6404", "6405"]

                # Conecta à janela
                console.print("[ITENS] Conectando na janela TFrmAlteraItemNFE para ajuste ICMS/IPI...", style="cyan")
                app = Application().connect(class_name="TFrmAlteraItemNFE")
                main_window = app["TFrmAlteraItemNFE"]
                main_window.set_focus()

                # Localiza o combobox
                tipo_icms = main_window.child_window(class_name="TDBIComboBox", found_index=5)

                # Define o texto da opção desejada
                if cfop in lista_icms_090:
                    opcao_desejada = "090 - ICMS NACIONAL OUTRAS"
                elif cfop in lista_icms_060:
                    opcao_desejada = "060 - ICMS - SUBSTITUICAO TRIBUTARIA 060"
                else:
                    opcao_desejada = None

                console.print(f"[ITENS] CFOP item={cfop} | Opção ICMS desejada: {opcao_desejada}", style="cyan")

                # Seleciona no combobox
                if opcao_desejada:
                    try:
                        tipo_icms.select(opcao_desejada)
                        send_keys("{ENTER}")
                        console.print(f"[ITENS] Tipo ICMS '{opcao_desejada}' selecionado com sucesso.", style="bold green")
                    except Exception as e:
                        console.print(f"[ITENS] Erro ao selecionar opção ICMS no combobox: {e}", style="bold red")

                    # Localize o combobox do IPI
                    combo = main_window.child_window(class_name="TDBIComboBox", found_index=4)
                    console.print("[ITENS] Selecionando IPI 0% no combobox de IPI...", style="cyan")
                    
                    # Seleciona diretamente o texto
                    combo.select("IPI 0%")
                    console.print("[ITENS] IPI 0% selecionado com sucesso.", style="bold green")
                            
                    # Clicar em alterar
                    console.print("[ITENS] Clicando em 'Alterar' para confirmar mudanças do item...", style="cyan")
                    main_window.child_window(class_name="TDBIBitBtn", found_index=3).click()
                else:
                    console.print("[ITENS] Nenhuma opção ICMS mapeada para este CFOP de item. Item será mantido como está.", style="yellow")

                await worker_sleep(5)
        except Exception as e:
            console.print(f"[ITENS] Erro geral ao trabalhar nas alterações dos itens: {e}", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Erro aotrabalhar nas alterações dos itens: {e}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        console.print("[ITENS] Finalizado o tratamento de todos os itens. Verificando pop-up de confirmação TMessageForm...", style="bold cyan")
        try:
            app = Application().connect(class_name="TMessageForm")
            main_window = app["TMessageForm"]
            btn_ok = main_window.child_window(title="&Yes", class_name="TButton")
            btn_ok.click_input()
            console.print("[ITENS] Pop-up TMessageForm confirmado com &Yes.", style="bold green")
        except:
            console.print("[ITENS] Nenhum pop-up TMessageForm de confirmação encontrado. Seguindo...", style="cyan")
            pass
        await worker_sleep(10)
        
        console.print("[PAGAMENTOS] Navegando pela janela de Nota Fiscal de Entrada (TFrmNotaFiscalEntrada)...", style="bold cyan")
        app = Application().connect(class_name="TFrmNotaFiscalEntrada")
        main_window = app["TFrmNotaFiscalEntrada"]

        # Clicar em pagamentos
        console.print("[PAGAMENTOS] Localizando aba/aba de 'Pagamentos' via imagem pagamentos.png...", style="bold cyan")
        imagem = fr"{BASE_PATH}\pagamentos.png"

        tentativas_pag = 0
        # Tenta localizar a imagem na tela
        while True:
            tentativas_pag += 1
            console.print(f"[PAGAMENTOS] Tentativa {tentativas_pag} de localizar 'pagamentos.png'...", style="cyan")
            local = pyautogui.locateCenterOnScreen(imagem, confidence=0.9)
            if local:
                pyautogui.click(local)   # Clica no centro da imagem
                console.print("[PAGAMENTOS] Imagem 'pagamentos.png' encontrada e clicada com sucesso!", style="bold green")
                break
            else:
                console.print("[PAGAMENTOS] Imagem 'pagamentos.png' não encontrada, tentando novamente...", style="yellow")
                time.sleep(1)

        await worker_sleep(3)

        console.print("[PAGAMENTOS] Localizando controles de 'Pagamento' na tela...", style="bold cyan")
        panel_TPage = main_window.child_window(class_name="TPage", title="Formulario")
        panel_TTabSheet = panel_TPage.child_window(class_name="TPageControl")
        panel_TabPagamento = panel_TTabSheet.child_window(title="Pagamento")
        console.print("[PAGAMENTOS] Controles localizados. Selecionando tipo de cobrança...", style="cyan")

        # Combo alvo (ajuste found_index se precisar)
        tipo_cobranca = panel_TTabSheet.child_window(class_name="TDBIComboBox", found_index=0)

        # Ordem de preferência
        opcoes = [
            "BANCO DO BRASIL BOLETO FIDC",
            "BANCO DO BRASIL BOLETO",
            "BOLETO",
        ]
        console.print(f"[PAGAMENTOS] Ordem de preferência tipo de cobrança: {opcoes}", style="cyan")

        # 1) Tenta .select() direto (não digita nada)
        selecionado = None
        for alvo in opcoes:
            try:
                tipo_cobranca.select(alvo)
                if tipo_cobranca.window_text().strip().lower() == alvo.lower():
                    selecionado = alvo
                    console.print(f"[PAGAMENTOS] Tipo de cobrança selecionado diretamente via .select(): {alvo}", style="bold green")
                    break
            except Exception:
                console.print(f"[PAGAMENTOS] Falha ao selecionar opção '{alvo}' via .select(). Tentando próximas opções...", style="yellow")
                pass

        # 2) Abre a LISTA e seleciona o item exato (sem digitar)
        if not selecionado:
            console.print("[PAGAMENTOS] Tentando selecionar tipo de cobrança abrindo dropdown (ALT+DOWN)...", style="bold cyan")
            tipo_cobranca.set_focus()
            tipo_cobranca.click_input()
            send_keys('%{DOWN}')  # ALT+DOWN para abrir o dropdown
            # tenta achar a janela da lista (Delphi/Win32)
            lista = None
            app = tipo_cobranca.app
            for crit in (dict(title="||List"), dict(class_name="ComboLBox"), dict(class_name_re=".*(List|Combo).*")):
                try:
                    cand = app.window(**crit)
                    if cand.exists(timeout=0.5):
                        lista = cand
                        console.print(f"[PAGAMENTOS] Janela de lista de combo encontrada por critério: {crit}", style="cyan")
                        break
                except Exception:
                    pass

            if lista:
                console.print("[PAGAMENTOS] Lendo textos da lista de opções de cobrança...", style="cyan")
                # tenta selecionar por índice (texto exato)
                try:
                    itens = [t.strip() for t in lista.texts() if str(t).strip()]
                    console.print(f"[PAGAMENTOS] Itens encontrados na lista: {itens}", style="cyan")
                except Exception:
                    itens = []
                    console.print("[PAGAMENTOS] Falha ao ler textos da lista de opções.", style="yellow")

                idx_alvo = -1
                alvo_escolhido = None
                for alvo in opcoes:
                    for i, t in enumerate(itens):
                        if t.lower() == alvo.lower():
                            idx_alvo = i
                            alvo_escolhido = alvo
                            console.print(f"[PAGAMENTOS] Opção '{alvo}' encontrada na lista no índice {i}.", style="cyan")
                            break
                    if idx_alvo >= 0:
                        break

                if idx_alvo >= 0:
                    try:
                        lista.select(idx_alvo)
                        console.print(f"[PAGAMENTOS] Opção '{alvo_escolhido}' selecionada na lista via .select(idx).", style="bold green")
                    except Exception:
                        # fallback por teclas sem digitar texto do item
                        console.print("[PAGAMENTOS] Falha no select(index). Usando fallback setas para descer até o item...", style="yellow")
                        send_keys('{HOME}')
                        for _ in range(idx_alvo):
                            send_keys('{DOWN}')
                    send_keys('{ENTER}')
                    try:
                        wait_until(2, 0.2, lambda: tipo_cobranca.window_text().strip() != "")
                    except PywTimeout:
                        console.print("[PAGAMENTOS] Timeout aguardando texto no combo de cobrança.", style="yellow")
                        pass
                    if tipo_cobranca.window_text().strip().lower() == alvo_escolhido.lower():
                        selecionado = alvo_escolhido
                        console.print(f"[PAGAMENTOS] Tipo de cobrança confirmado após ENTER: {selecionado}", style="bold green")
                else:
                    # fallback só com setas (sem digitar): vai ao topo e desce checando
                    console.print("[PAGAMENTOS] Não encontrou item por índice. Usando fallback navegando com setas...", style="yellow")
                    send_keys('{HOME}')
                    vistos = set()
                    for _ in range(60):
                        atual = tipo_cobranca.window_text().strip()
                        if atual.lower() in (o.lower() for o in opcoes):
                            send_keys('{ENTER}')
                            selecionado = atual
                            console.print(f"[PAGAMENTOS] Tipo de cobrança selecionado via navegação por setas: {selecionado}", style="bold green")
                            break
                        if atual.lower() in vistos:
                            # deu a volta
                            send_keys('{ESC}')
                            console.print("[PAGAMENTOS] Deu a volta na lista de tipos de cobrança. Abortando navegação.", style="yellow")
                            break
                        vistos.add(atual.lower())
                        send_keys('{DOWN}')

        # (opcional) validação dura
        if not selecionado or selecionado.lower() not in (o.lower() for o in opcoes):
            erro_tipo = tipo_cobranca.window_text().strip()
            console.print(f"[PAGAMENTOS] Não foi possível selecionar uma opção válida de cobrança. Ficou: '{erro_tipo}'", style="bold red")
            raise RuntimeError(f"Não consegui selecionar uma opção válida. Ficou: '{erro_tipo}'")

        console.print(f"[PAGAMENTOS] Tipo de cobrança final selecionado: {selecionado}", style="bold green")

        # Ajuste da data de vencimento
        console.print("[PAGAMENTOS] Calculando e ajustando data de vencimento da parcela...", style="bold cyan")
        dt_vencimento_nota = nota.get("dataVencimento")  # vem como '2025-09-26'
        data_atual = datetime.now().date()
        console.print(f"[PAGAMENTOS] Data vencimento original (configEntrada): {dt_vencimento_nota}", style="cyan")

        # Converte para date (formato yyyy-mm-dd → ISO)
        data_vencimento = datetime.strptime(dt_vencimento_nota, "%Y-%m-%d").date()

        # Se o vencimento for hoje ou já passou, joga para próximo dia útil
        if data_vencimento <= data_atual:
            console.print("[PAGAMENTOS] Data de vencimento original é hoje ou já passou. Ajustando para próximo dia útil...", style="yellow")
            data_vencimento = data_atual + timedelta(days=1)

            # Ajusta para cair só em dias úteis
            while data_vencimento.weekday() >= 5:  # 5 = sábado, 6 = domingo
                data_vencimento += timedelta(days=1)

        # Converter para string (formato brasileiro dd/mm/yyyy)
        data_vencimento_str = data_vencimento.strftime("%d/%m/%Y")
        console.print(f"[PAGAMENTOS] Nova data de vencimento calculada: {data_vencimento_str}", style="bold green")

        # Inserir no campo
        console.print("[PAGAMENTOS] Inserindo data de vencimento no campo TDBIEditDate (found_index=0)...", style="cyan")
        data_venc = panel_TTabSheet.child_window(
            class_name="TDBIEditDate", found_index=0
        )

        data_venc.set_edit_text(data_vencimento_str)
                    
        console.print("[PAGAMENTOS] Incluindo registro de parcela (delete + inclui novamente)...", style="bold cyan")

        try:
            console.print("[PAGAMENTOS] Excluindo parcela existente (se houver)...", style="cyan")
            deletar_parcela = main_window.child_window(class_name="TDBIBitBtn", found_index=0).click_input()
            await worker_sleep(3)
            app_del = Application().connect(class_name="TMessageForm")
            main_del = app_del["TMessageForm"]
            btn_ok = main_del.child_window(title="&Yes", class_name="TButton")
            btn_ok.click_input()
            console.print("[PAGAMENTOS] Parcela antiga excluída com sucesso.", style="bold green")
            await worker_sleep(3)

            valor = main_window.child_window(class_name="TDBIEditNumber", found_index=7)
            valor_encontrado = valor.window_text()
            console.print(f"[PAGAMENTOS] Valor da parcela lido do campo index 7 (antes de tratar ponto): {valor_encontrado}", style="cyan")
            valor_encontrado = valor_encontrado.replace(".","")
            console.print(f"[PAGAMENTOS] Valor da parcela após remover '.': {valor_encontrado}", style="cyan")

            await worker_sleep(3)

            # Localiza o campo onde deseja inserir (índice 3)
            inserir_valor = main_window.child_window(class_name="TDBIEditNumber", found_index=3)

            # Insere o valor capturado no campo de índice 3
            console.print("[PAGAMENTOS] Inserindo valor tratado no campo index 3...", style="cyan")
            inserir_valor.set_focus()
            send_keys("^a{DEL}")               # limpa o campo
            send_keys(valor_encontrado) 

            console.print("[PAGAMENTOS] Incluindo nova parcela...", style="cyan")
            incluir_parcela = main_window.child_window(class_name="TDBIBitBtn", found_index=1).click_input() 
            console.print("[PAGAMENTOS] Parcela incluída com sucesso.", style="bold green")
        except Exception as e:
            console.print(f"[PAGAMENTOS] Erro ao excluir/incluir parcela de pagamento: {e}. Prosseguindo com fallback de inclusão de registro.", style="yellow")

        console.print("[PAGAMENTOS] Tentando incluir registro via imagem IncluirRegistro.png...", style="bold cyan")
        try:
            inserir_registro = pyautogui.locateOnScreen(fr"{BASE_PATH}\IncluirRegistro.png", confidence=0.8)
            pyautogui.click(inserir_registro)
            console.print("[PAGAMENTOS] Botão de 'Incluir Registro' clicado via imagem com sucesso.", style="bold green")
        except Exception as e:
            console.print(
                f"[PAGAMENTOS] Não foi possivel incluir o registro utilizando reconhecimento de imagem, Error: {e}...\n tentando inserir via posição...",
                style="yellow"
            )
            await incluir_registro()
            console.print("[PAGAMENTOS] Fallback incluir_registro() executado.", style="cyan")

        await worker_sleep(10)
       
        # ================= MELHORIA: POP-UP VARIAÇÃO, WARNING E RATEIO =================
        console.print(
            "[RATEIO] Tratando pop-ups e aguardando tela de Rateio da Despesa...",
            style="bold cyan"
        )

        # 1) POP-UP de Itens que Ultrapassam a Variação Máxima de Custo
        try:
            console.print(
                "[RATEIO] Verificando existência de pop-up 'Itens que Ultrapassam a Variação Máxima de Custo'...",
                style="cyan"
            )
            itens_variacao_maxima = await is_window_open_by_class(
                "TFrmTelaSelecao", "TFrmTelaSelecao"
            )
            console.print(f"[RATEIO] Retorno is_window_open_by_class para TFrmTelaSelecao: {itens_variacao_maxima}", style="cyan")

            if itens_variacao_maxima.get("IsOpened"):
                console.print(
                    "[RATEIO] Pop-up de Itens que Ultrapassam a Variação Máxima de Custo encontrado. Confirmando...",
                    style="yellow"
                )
                app_sel = Application().connect(class_name="TFrmTelaSelecao")
                win_sel = app_sel["TFrmTelaSelecao"]
                win_sel.set_focus()
                # normalmente ALT+O (Ok)
                send_keys("%o")
                console.print(
                    "[RATEIO] POP-UP de Itens que Ultrapassam a Variação Máxima de Custo tratado (ALT+O).",
                    style="bold green"
                )
        except Exception as error:
            console.print(
                f"[RATEIO] Falha ao verificar POP-UP de itens que ultrapassam a variação máxima de custo: {error}",
                style="bold red"
            )

        await worker_sleep(2)

        # 2) Verifica se a tela de Rateio já está aberta
        console.print("[RATEIO] Verificando se a tela de 'Rateio da Despesa' já está aberta...", style="bold cyan")
        rateio_aberto = False
        try:
            rateio_win = Desktop(backend="uia").window(title_re=".*Rateio.*")
            rateio_aberto = rateio_win.exists(timeout=1)
            console.print(f"[RATEIO] Tela de rateio aberta? {rateio_aberto}", style="cyan")
        except Exception as e:
            console.print(f"[RATEIO] Erro ao verificar tela de rateio: {e}", style="yellow")
            rateio_aberto = False

        # 3) Warning de soma dos pagamentos x valor da nota (só se não abriu Rateio ainda)
        if not rateio_aberto:
            console.print(
                "[RATEIO] Tela de rateio não aberta ainda. Verificando Warning de soma de pagamentos x valor da nota...",
                style="cyan"
            )
            try:
                warning_app = Application().connect(title="Warning")
                warning_pop_up_pagamentos = warning_app["Warning"]
                existe_warning_pagamentos = warning_pop_up_pagamentos.exists(timeout=1)
            except Exception:
                existe_warning_pagamentos = False

            if existe_warning_pagamentos:
                console.print(
                    "[RATEIO] Warning encontrado: soma dos pagamentos não bate com o valor da nota. Finalizando com erro de negócio.",
                    style="bold red"
                )
                return RpaRetornoProcessoDTO(
                    sucesso=False,
                    retorno="A soma dos pagamentos não bate com o valor da nota.",
                    status=RpaHistoricoStatusEnum.Falha,
                    tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)]
                )
            else:
                console.print(
                    "[RATEIO] Warning de soma dos pagamentos não encontrado. Seguindo com o processo...",
                    style="bold green"
                )
        else:
            console.print(
                "[RATEIO] Tela de Rateio da Despesa já está aberta. Ignorando validação de Warning de pagamentos.",
                style="cyan"
            )

        # 4) Espera DEFINITIVAMENTE pela tela de Rateio da Despesa
        console.print("[RATEIO] Aguardando a tela 'Rateio da Despesa' (title_re='.*Rateio.*')...", style="bold cyan")
        try:
            rateio_win = Desktop(backend="uia").window(title_re=".*Rateio.*")
            rateio_win.wait("exists enabled visible ready", timeout=30)
            console.print(
                "[RATEIO] Tela 'Rateio da Despesa' encontrada. Prosseguindo com o rateio...",
                style="bold green"
            )
        except Exception as e:
            console.print(f"[RATEIO] Erro ao aguardar tela de Rateio: {e}", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Número máximo de tentativas atingido. A tela para Rateio da Despesa não foi encontrada.",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

        # 5) Agora sim chama o rateio_despesa
        console.print("[RATEIO] Chamando função rateio_despesa()...", style="bold cyan")
        despesa_rateio_work = await rateio_despesa(empresaCodigo)
        if despesa_rateio_work.sucesso == True:
            console.log(despesa_rateio_work.retorno, style="bold green")
        else:
            console.print("[RATEIO] Falha ao executar rateio_despesa.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=despesa_rateio_work.retorno,
                status=RpaHistoricoStatusEnum.Falha,
                tags=despesa_rateio_work.tags
            )
        # ================= FIM MELHORIA =================

        # Verifica se a info 'Nota fiscal incluida' está na tela
        console.print("[FINALIZAÇÃO] Aguardando possíveis warnings finais e validação da nota lançada...", style="bold cyan")
        await worker_sleep(15)
        warning_pop_up = await is_window_open("Warning")
        if warning_pop_up["IsOpened"] == True:
            console.print("[FINALIZAÇÃO] Pop-up 'Warning' encontrado no fim do fluxo. Capturando mensagem com OCR...", style="yellow")
            app = Application().connect(title="Warning")
            main_window = app["Warning"]
            main_window.set_focus()

            console.print(f"[FINALIZAÇÃO] Obtendo texto do Warning via screenshot + OCR...", style="cyan")

            window_rect = main_window.rectangle()
            screenshot = pyautogui.screenshot(
                region=(
                    window_rect.left,
                    window_rect.top,
                    window_rect.width(),
                    window_rect.height(),
                )
            )
            username = getpass.getuser()
            path_to_png = f"C:\\Users\\{username}\\Downloads\\warning_popup_{nota.get('nfe')}.png"
            screenshot.save(path_to_png)
            console.print(f"[FINALIZAÇÃO] Print do Warning salvo em {path_to_png}", style="cyan")

            console.print(
                "[FINALIZAÇÃO] Preparando a imagem para maior resolução e assertividade no OCR...",
                style="cyan"
            )
            image = Image.open(path_to_png)
            image = image.convert("L")
            enhancer = ImageEnhance.Contrast(image)
            image = enhancer.enhance(2.0)
            image.save(path_to_png)
            console.print("[FINALIZAÇÃO] Imagem preparada com sucesso. Iniciando OCR...", style="cyan")
            captured_text = pytesseract.image_to_string(Image.open(path_to_png))
            console.print(
                f"[FINALIZAÇÃO] Texto capturado do Warning: {captured_text}",
                style="bold green"
            )
            os.remove(path_to_png)
            console.print("[FINALIZAÇÃO] Arquivo de imagem do Warning removido.", style="cyan")
            if 'movimento não permitido' in captured_text.lower():
                console.print("[FINALIZAÇÃO] Warning mapeado: movimento não permitido (livro fechado).", style="bold red")
                return RpaRetornoProcessoDTO(
                    sucesso=False,
                    retorno=f"Filial: {empresaCodigo} está com o livro fechado ou encerrado, verificar com o setor fiscal",
                    status=RpaHistoricoStatusEnum.Falha,
                    tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)]
                )
            else:
                console.print("[FINALIZAÇÃO] Warning não mapeado. Retornando como erro técnico com mensagem completa do OCR.", style="bold red")
                return RpaRetornoProcessoDTO(
                    sucesso=False,
                    retorno=f"Warning não mapeado para seguimento do robo, mensagem: {captured_text}",
                    status=RpaHistoricoStatusEnum.Falha,
                    tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
                )
            
        await worker_sleep(3)

        console.print("[FINALIZAÇÃO] Verificando se a nota foi lançada via check_nota_importada...", style="bold cyan")
        nf_imported = await check_nota_importada(dados_nf[0].get("chaveNfe"))
        console.print(f"[FINALIZAÇÃO] Retorno check_nota_importada: sucesso={nf_imported.sucesso} | retorno={nf_imported.retorno}", style="cyan")
        if nf_imported.sucesso == True:
            await worker_sleep(3)
            console.print("[FINALIZAÇÃO] Validando status da NF no EMSys via get_status_nf_emsys...", style="bold cyan")
            nf_chave_acesso = int(dados_nf[0].get("chaveNfe"))
            status_nf_emsys = await get_status_nf_emsys(nf_chave_acesso)
            console.print(f"[FINALIZAÇÃO] Status NF EMSys pós-lançamento: {status_nf_emsys}", style="cyan")
            if status_nf_emsys.get("status") == "Lançada":
                console.print("\n[FINALIZAÇÃO] Nota lançada com sucesso, processo finalizado...", style="bold green")
                return RpaRetornoProcessoDTO(
                    sucesso=True,
                    retorno="Nota Lançada com sucesso!",
                    status=RpaHistoricoStatusEnum.Sucesso,
                )
            else:
                console.print("[FINALIZAÇÃO] Pop-up de nota incluída encontrado, porém status retornou diferente de 'Lançada'.", style="bold red")
                return RpaRetornoProcessoDTO(
                    sucesso=False,
                    retorno=f"Pop-up nota incluida encontrada, porém nota encontrada como 'já lançada' trazendo as seguintes informações: {nf_imported.retorno}",
                    status=RpaHistoricoStatusEnum.Falha,
                    tags=[RpaTagDTO(descricao=RpaTagEnum.Negocio)]
                )
        else:
            console.print("[FINALIZAÇÃO] check_nota_importada retornou falha. Nota não confirmada como lançada.", style="bold red")
            return RpaRetornoProcessoDTO(
                sucesso=False,
                retorno=f"Erro ao lançar nota, erro: {nf_imported.retorno}",
                status=RpaHistoricoStatusEnum.Falha,
                tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
            )

    except Exception as ex:
        observacao = f"[ERRO GERAL] Erro Processo Entrada de Notas: {str(ex)}"
        logger.error(observacao)
        console.print(observacao, style="bold red")
        return RpaRetornoProcessoDTO(
            sucesso=False,
            retorno=observacao,
            status=RpaHistoricoStatusEnum.Falha,
            tags=[RpaTagDTO(descricao=RpaTagEnum.Tecnico)]
        )

    finally:
        # Deleta o xml
        console.print("[FINALLY] Iniciando limpeza de XML (delete_xml)...", style="bold cyan")
        try:
            if numero_nota:
                await delete_xml(numero_nota)
                console.print(f"[FINALLY] XML da nota {numero_nota} deletado com sucesso.", style="bold green")
            else:
                console.print("[FINALLY] numero_nota é None, não foi possível chamar delete_xml com parâmetro válido.", style="yellow")
        except Exception as e:
            console.print(f"[FINALLY] Falha ao deletar XML da nota {numero_nota}: {e}", style="bold red")
        console.print("\n================ FIM PROCESSO opex_capex ================\n", style="bold blue")
