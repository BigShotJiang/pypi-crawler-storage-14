# Toms-structures
<div align="left">

<img alt="GitHub release (latest by date including pre-releases" src="https://img.shields.io/github/v/release/Revelate123/structures?include_prereleases">

<img alt="GitHub top language" src="https://img.shields.io/github/languages/top/Revelate123/structures?style=flat">

</div>

## Description

A library of structural engineering calculations which are commonly calculated using either excel spreadsheets or by hand.
This project aims to fill the gap between expensive full blown industry software (e.g. FEA tools such as spacegass/ETABS/etc) which are reliable and correct but not warranted on smaller scale projects,
and the world of excel spreadsheets and hand calculations, which are often difficult to maintain, program, version, and test accurately but used extensively for small projects or isolated checking.

This project is currently in early alpha.


## Installation
Install from PyPI using:

`$ pip install toms-structures`


## Usage

`from structures import ..`

## Demo



## Project Created & Maintained by
Thomas Duffett

Code formatting tools
- black formatter
- pylint
