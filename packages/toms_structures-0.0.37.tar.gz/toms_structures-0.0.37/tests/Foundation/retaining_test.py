import pytest

#def test_object_creation():
    #rtw = retaining.RetainingWall(footing_length=1000, footing_depth=300, heel=0, wall_thickness=190, wall_height=1000)
    #assert(rtw)

