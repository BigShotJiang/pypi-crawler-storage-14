This module hides documentation, support, shortcuts, account menu items on the top-right corner of the webclient.
