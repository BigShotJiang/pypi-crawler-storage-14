Upon installing the module, user menu item presentation will be stripped down to look like the below image:
  .. image:: ../static/img/userscreen.png
