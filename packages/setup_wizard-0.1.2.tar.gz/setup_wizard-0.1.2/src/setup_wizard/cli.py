from __future__ import annotations

import argparse
from typing import Optional

from .config import load_config
from .prompts import log, section, console
from .health import print_health_summary, clear_results
from .steps.repo_info_step import run_repo_info
from .steps.venv_step import ensure_venv
from .steps.deps_step import install_dependencies
from .steps.env_file_step import ensure_env_file
from .steps.dev_tools_step import install_dev_tools
from .steps.vscode_step import setup_vscode
from .steps.app_health_step import run_health_checks
from .steps.readme_step import maybe_open_readme


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="setup-wizard",
        description="Interactive project setup wizard.",
    )
    parser.add_argument(
        "--config",
        help="Path to setup_wizard JSON config (default: ./setup_wizard.json)",
    )
    parser.add_argument(
        "--python",
        help="Target Python interpreter for the virtualenv "
        "(e.g. /usr/bin/python3.14 or C:\\Python314\\python.exe).",
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="Only run health checks, do not modify the environment.",
    )
    parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Run non-destructive steps without prompting (auto-yes).",
    )
    return parser


def main(argv: Optional[list[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    cfg = load_config(args.config)
    auto_yes = bool(args.yes)

    console.print()
    console.rule(f"[bold]Setup Wizard for {cfg['project_name']}[/bold]")

    clear_results()

    # Always show repo info if possible
    run_repo_info(auto_yes=auto_yes)

    if args.check_only:
        # Only run health checks – expect env/venv already set up.
        run_health_checks(cfg, auto_yes=auto_yes)
        print_health_summary()
        return

    # venv
    venv_ok = ensure_venv(cfg, args.python, auto_yes=auto_yes)

    # deps
    if venv_ok:
        install_dependencies(cfg, auto_yes=auto_yes)
        install_dev_tools(cfg, auto_yes=auto_yes)
    else:
        log("Skipping dependency/dev tool installation because venv is not available.")

    # env file
    ensure_env_file(cfg, auto_yes=auto_yes)

    # VSCode integration
    setup_vscode(cfg, auto_yes=auto_yes)

    # Health checks
    if venv_ok:
        run_health_checks(cfg, auto_yes=auto_yes)

    # README
    maybe_open_readme(cfg, auto_yes=auto_yes)

    # Summary
    print_health_summary()
