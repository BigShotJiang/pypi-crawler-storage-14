from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step


def setup_vscode(cfg: Dict[str, Any], auto_yes: bool) -> None:
    vscode_cfg = cfg.get("vscode") or {}
    if not vscode_cfg.get("enable_launch", False):
        return

    section("VSCode integration")

    vscode_dir = Path(".vscode")
    vscode_dir.mkdir(exist_ok=True)

    launch_path = vscode_dir / "launch.json"
    entry_module = vscode_cfg.get("entry_module", "src")

    # --- load existing launch.json if present ---
    launch_data: Dict[str, Any] = {}
    if launch_path.exists():
        try:
            launch_text = launch_path.read_text(encoding="utf-8")
            launch_data = json.loads(launch_text) if launch_text.strip() else {}
            log(
                f"Found existing {launch_path}, will try to merge configuration into it."
            )
        except Exception:
            warn(f"Existing {launch_path} is not valid JSON.")
            if not ask_yes_no(
                "launch.json seems invalid. Overwrite it with a fresh one from the wizard?",
                default=False,
                auto_yes=auto_yes,
            ):
                record_step(
                    "vscode", "skipped", "Invalid launch.json, user skipped overwrite"
                )
                return
            launch_data = {}

    # Ensure base structure
    if not isinstance(launch_data, dict):
        launch_data = {}

    configs = launch_data.get("configurations")
    if not isinstance(configs, list):
        configs = []

    debug_name = (
        vscode_cfg.get("debug_name") or cfg.get("project_name") or "Python: Run app"
    )

    extra_env = vscode_cfg.get("extra_env") or None
    cwd = vscode_cfg.get("cwd") or None

    # New config to add (or skip if already there)
    new_config = {
        "name": debug_name,
        "type": "python",
        "request": "launch",
        "module": entry_module,
        "justMyCode": True,
        "envFile": cfg["paths"]["env_file"],
    }

    if extra_env:
        new_config["env"] = extra_env

    if cwd:
        new_config["cwd"] = cwd

    # Check if a config with the same name already exists
    if any(c.get("name") == new_config["name"] for c in configs):
        log(
            f"VSCode launch configuration already contains '{new_config['name']}', not adding another."
        )
        launch_status = "skipped"
        detail = "Existing config with same name"
    else:
        log(
            "I can add a new VSCode debug configuration for the app without "
            "removing your existing configurations."
        )
        if ask_yes_no(
            "Add a 'Python: Run app' configuration to launch.json?",
            default=True,
            auto_yes=auto_yes,
        ):
            configs.append(new_config)
            launch_status = "done"
            detail = "Appended new configuration"
        else:
            launch_status = "skipped"
            detail = "User skipped adding configuration"

    # Write back only if we actually changed or created something
    launch_data.setdefault("version", "0.2.0")
    launch_data["configurations"] = configs

    try:
        launch_path.write_text(json.dumps(launch_data, indent=2), encoding="utf-8")
        if launch_status == "done":
            log(f"Updated VSCode launch configuration at {launch_path}")
        else:
            log(
                f"Kept existing VSCode launch configuration at {launch_path} unchanged."
            )
    except Exception as e:
        warn(f"Failed to write VSCode launch configuration: {e}")
        record_step("vscode", "failed", f"write error: {e}")
        return

    # Formatter setting (unchanged from before, but still optional)
    formatter_status = "skipped"
    if vscode_cfg.get("use_black_formatter", False):
        log(
            "I can also configure VSCode to use Black as the code formatter for this "
            "workspace and enable format-on-save."
        )
        if ask_yes_no(
            "Set Black as the default formatter for this project?",
            default=True,
            auto_yes=auto_yes,
        ):
            settings_path = vscode_dir / "settings.json"
            settings: Dict[str, Any] = {}
            if settings_path.exists():
                try:
                    settings = json.loads(settings_path.read_text(encoding="utf-8"))
                except Exception:
                    warn(
                        "Existing .vscode/settings.json is not valid JSON; overwriting."
                    )

            settings.update(
                {
                    "python.formatting.provider": "black",
                    "editor.formatOnSave": True,
                }
            )
            try:
                settings_path.write_text(
                    json.dumps(settings, indent=2), encoding="utf-8"
                )
                log(f"Updated VSCode settings at {settings_path}")
                formatter_status = "done"
            except Exception as e:
                warn(f"Failed to write VSCode settings: {e}")
                formatter_status = "failed"
        else:
            formatter_status = "skipped"
            log("Skipping VSCode formatter configuration.")

    # Record combined status
    combined_detail = f"launch={launch_status}, formatter={formatter_status}"
    if "failed" in combined_detail:
        record_step("vscode", "failed", combined_detail)
    elif "done" in combined_detail:
        record_step("vscode", "done", combined_detail)
    else:
        record_step("vscode", "skipped", combined_detail)
