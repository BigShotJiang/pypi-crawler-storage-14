"""
Aeonica Memory - Fast, explainable FAISS-backed memory for LLM agents and RAG systems

Built on battle-tested FAISS with an optimized pipeline, explainability features,
and developer-friendly API.

Quick Start:
    from aeonica_memory import MemoryClient

    # Initialize
    client = MemoryClient()

    # Add memories
    client.add("py_1", "Python uses indentation for code blocks")
    client.add("js_1", "JavaScript uses curly braces for code blocks")

    # Query with explainability
    results = client.query("How does Python structure code?")

    for r in results:
        print(f"{r.id}: {r.content}")
        print(f"  Confidence: {r.confidence_depth}")
        print(f"  Why: {r.explanation}")

LangChain Integration:
    from aeonica_memory.integrations.langchain import AeonicaVectorStore

    vectorstore = AeonicaVectorStore()
    vectorstore.add_texts(["doc1", "doc2"])
    retriever = vectorstore.as_retriever()

Features:
    - FAISS-backed semantic search
    - Explainability (confidence depth, schemas, reasoning)
    - Metadata filtering with operators ($gt, $in, etc.)
    - Persistence (save/load)
    - LangChain integration
    - Web playground
"""

from .memory.memory_client import MemoryClient, RetrievalResult

__version__ = "0.1.0"
__author__ = "Aeonica Labs"
__email__ = "support@aeonica.dev"

__all__ = [
    "MemoryClient",
    "RetrievalResult",
    "__version__",
]


def get_version() -> str:
    """Return the package version"""
    return __version__
