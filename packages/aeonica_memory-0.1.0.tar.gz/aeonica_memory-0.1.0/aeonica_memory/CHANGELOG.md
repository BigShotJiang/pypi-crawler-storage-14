# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2024-12-01

### Added

#### Core Memory SDK
- `MemoryClient` - FAISS-backed semantic memory with explainability
- CRUD operations: `add`, `add_batch`, `get`, `update`, `delete`, `clear`, `list_ids`
- Metadata filtering with operators: `$gt`, `$gte`, `$lt`, `$lte`, `$in`, `$nin`, `$ne`, `$contains`
- Persistence: `save()` and `load()` for full state serialization
- Explainability: confidence depth, schema detection, natural language explanations

#### Governance Module
- **Audit Log** (`audit_log.py`)
  - Append-only, hash-chained operation logging
  - Tamper detection via `verify_chain()`
  - Operation history queries

- **Merkle State Proofs** (`merkle.py`)
  - Compute state roots over memory
  - Generate inclusion proofs for specific memories
  - Third-party verifiable proofs

- **Compliant Deletion** (`deletion.py`)
  - GDPR-style deletion with cryptographic certificates
  - Pre/post state roots for verification
  - Batch deletion support
  - Third-party certificate verification

- **Temporal Memory** (`temporal.py`)
  - Exponential, linear, step decay functions
  - Importance scoring
  - Auto-expiration
  - Access tracking

- **Retrieval Tracing** (`tracing.py`)
  - Full RAG query traces
  - Latency analysis
  - A/B testing support
  - Human-readable trace reports

#### Integrations
- LangChain `VectorStore` and `Retriever` implementations

#### CLI & Tools
- `aeonica-memory` CLI with playground command
- Web playground for interactive exploration

### Testing
- 81 passing tests (40 core + 41 governance)
- Integration tests with real MemoryClient

---

## [Unreleased]

### Planned
- Governance dashboard UI
- `aeonica-memory serve` HTTP API
- Advanced compliance reports
- Multi-tenant support
