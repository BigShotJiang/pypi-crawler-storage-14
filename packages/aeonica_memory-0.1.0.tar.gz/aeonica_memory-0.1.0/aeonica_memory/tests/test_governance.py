"""
Tests for the Aeonica Memory Governance Module

Tests:
- AuditLog: append-only logging, hash chains, verification
- StateProver: Merkle trees, inclusion proofs
- DeletionCertifier: compliant deletion with certificates
- TemporalMemory: decay functions, importance scoring
- RetrievalTracer: query tracing and analysis
"""

import pytest
import tempfile
import os
import json
import time
from datetime import datetime, timezone, timedelta
from unittest.mock import MagicMock, patch

# Import governance components
from aeonica_memory.governance import (
    # Audit
    AuditLog,
    AuditEntry,
    OperationType,
    hash_content,
    hash_metadata,
    # Proofs
    MerkleTree,
    StateProver,
    StateProof,
    InclusionProof,
    # Deletion
    DeletionCertifier,
    DeletionCertificate,
    BatchDeletionCertificate,
    verify_deletion_certificate_standalone,
    # Temporal
    TemporalMemory,
    TemporalMetadata,
    ExponentialDecay,
    LinearDecay,
    StepDecay,
    NoDecay,
    ImportanceScorer,
    # Tracing
    RetrievalTracer,
    RetrievalTrace,
    TraceEvent,
    TraceEventType,
    create_retrieval_report,
)


# =============================================================================
# AUDIT LOG TESTS
# =============================================================================

class TestAuditLog:
    """Tests for AuditLog"""

    def test_in_memory_audit_log(self):
        """Test basic in-memory audit log"""
        audit = AuditLog()

        entry = audit.log_add(
            memory_id="doc_1",
            content_hash="sha256:abc123",
            metadata_hash="sha256:def456"
        )

        assert entry.entry_id == "audit_00000000"
        assert entry.operation == OperationType.ADD
        assert entry.memory_ids == ["doc_1"]
        assert audit.entry_count == 1

    def test_file_audit_log(self):
        """Test audit log with file persistence"""
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            log_path = f.name

        try:
            # Create and populate log
            audit = AuditLog(log_path)
            audit.log_add("doc_1", "sha256:abc")
            audit.log_add("doc_2", "sha256:def")
            audit.log_delete("doc_1")

            assert audit.entry_count == 3

            # Reload from file
            audit2 = AuditLog(log_path)
            assert audit2.entry_count == 3
            assert audit2.last_entry.operation == OperationType.DELETE
        finally:
            os.unlink(log_path)

    def test_hash_chain_integrity(self):
        """Test hash chain is valid"""
        audit = AuditLog()

        audit.log_add("doc_1", "sha256:a")
        audit.log_add("doc_2", "sha256:b")
        audit.log_update("doc_1", "sha256:a", "sha256:c")
        audit.log_delete("doc_2")

        # Chain should be valid
        assert audit.verify_chain() is True

        # First entry should have no previous hash
        entries = list(audit)
        assert entries[0].previous_hash is None

        # Each subsequent entry links to previous
        for i in range(1, len(entries)):
            assert entries[i].previous_hash == entries[i-1].compute_hash()

    def test_get_history(self):
        """Test getting operation history for a memory"""
        audit = AuditLog()

        audit.log_add("doc_1", "sha256:a")
        audit.log_add("doc_2", "sha256:b")
        audit.log_update("doc_1", "sha256:a", "sha256:c")
        audit.log_query("test query", ["doc_1", "doc_2"], "trace_1")

        history = audit.get_history("doc_1")
        assert len(history) == 3  # add, update, query

    def test_get_state_root_at(self):
        """Test retrieving state root at timestamp"""
        audit = AuditLog()

        audit.log_add("doc_1", "sha256:a", state_root="root_1")
        time.sleep(0.01)
        t1 = datetime.now(timezone.utc).isoformat()
        time.sleep(0.01)
        audit.log_add("doc_2", "sha256:b", state_root="root_2")

        # Before any entries
        assert audit.get_state_root_at("2020-01-01T00:00:00+00:00") is None

        # At t1 (after first add)
        assert audit.get_state_root_at(t1) == "root_1"

        # At end
        assert audit.last_state_root == "root_2"

    def test_hash_helpers(self):
        """Test hash helper functions"""
        content_hash = hash_content("test content")
        assert content_hash.startswith("sha256:")
        assert len(content_hash) == 71  # sha256: + 64 hex chars

        metadata_hash = hash_metadata({"key": "value", "num": 123})
        assert metadata_hash.startswith("sha256:")


# =============================================================================
# MERKLE TREE TESTS
# =============================================================================

class TestMerkleTree:
    """Tests for MerkleTree and StateProver"""

    def test_empty_tree(self):
        """Test empty tree has defined root"""
        tree = MerkleTree()
        root = tree.build()
        assert root.startswith("sha256:")

    def test_single_leaf(self):
        """Test tree with single leaf"""
        tree = MerkleTree()
        tree.add_leaf("doc_1", "sha256:abc")
        root = tree.build()
        assert root.startswith("sha256:")

    def test_multiple_leaves(self):
        """Test tree with multiple leaves"""
        tree = MerkleTree()
        tree.add_leaf("doc_1", "sha256:a")
        tree.add_leaf("doc_2", "sha256:b")
        tree.add_leaf("doc_3", "sha256:c")
        root = tree.build()
        assert root.startswith("sha256:")

    def test_inclusion_proof(self):
        """Test generating and verifying inclusion proofs"""
        tree = MerkleTree()
        tree.add_leaf("doc_1", "sha256:a")
        tree.add_leaf("doc_2", "sha256:b")
        tree.add_leaf("doc_3", "sha256:c")
        tree.add_leaf("doc_4", "sha256:d")
        tree.build()

        # Get proof for doc_2
        proof = tree.get_inclusion_proof("doc_2")
        assert proof is not None
        assert proof.memory_id == "doc_2"
        assert proof.memory_hash == "sha256:b"

        # Verify proof
        assert MerkleTree.verify_inclusion_proof(proof) is True

        # Non-existent memory
        assert tree.get_inclusion_proof("doc_99") is None

    def test_proof_serialization(self):
        """Test proof serialization/deserialization"""
        tree = MerkleTree()
        tree.add_leaf("doc_1", "sha256:a")
        tree.add_leaf("doc_2", "sha256:b")
        tree.build()

        proof = tree.get_inclusion_proof("doc_1")
        json_str = proof.to_json()

        # Deserialize
        proof2 = InclusionProof.from_json(json_str)
        assert proof2.memory_id == proof.memory_id
        assert proof2.state_root == proof.state_root

        # Verify deserialized proof
        assert MerkleTree.verify_inclusion_proof(proof2) is True

    def test_state_prover_with_mock_client(self):
        """Test StateProver with mock client"""
        # Mock client
        mock_client = MagicMock()
        mock_client.list_ids.return_value = ["doc_1", "doc_2"]

        mock_memory1 = MagicMock()
        mock_memory1.content = "content 1"
        mock_memory1.metadata = {"key": "value1"}

        mock_memory2 = MagicMock()
        mock_memory2.content = "content 2"
        mock_memory2.metadata = {"key": "value2"}

        mock_client.get.side_effect = lambda x: mock_memory1 if x == "doc_1" else mock_memory2
        mock_client.__len__ = lambda self: 2

        prover = StateProver(mock_client)

        # Compute state root
        root = prover.compute_state_root()
        assert root.startswith("sha256:")

        # Prove inclusion
        proof = prover.prove_inclusion("doc_1")
        assert proof is not None
        assert prover.verify_proof(proof) is True


# =============================================================================
# DELETION CERTIFIER TESTS
# =============================================================================

class TestDeletionCertifier:
    """Tests for DeletionCertifier"""

    def test_deletion_certificate_structure(self):
        """Test DeletionCertificate dataclass"""
        cert = DeletionCertificate(
            certificate_id="del_123",
            memory_id="doc_1",
            deletion_timestamp="2025-03-15T10:00:00+00:00",
            pre_state_root="sha256:pre",
            post_state_root="sha256:post",
            content_hash="sha256:content",
            index_rebuilt=True
        )

        # Test serialization
        json_str = cert.to_json()
        assert "del_123" in json_str

        # Test deserialization
        cert2 = DeletionCertificate.from_json(json_str)
        assert cert2.certificate_id == cert.certificate_id
        assert cert2.index_rebuilt is True

    def test_certificate_signature(self):
        """Test certificate signature computation"""
        cert = DeletionCertificate(
            certificate_id="del_123",
            memory_id="doc_1",
            deletion_timestamp="2025-03-15T10:00:00+00:00",
            pre_state_root="sha256:pre",
            post_state_root="sha256:post",
            content_hash="sha256:content"
        )

        sig = cert.compute_signature()
        assert sig.startswith("sha256:")

        # Same data = same signature
        sig2 = cert.compute_signature()
        assert sig == sig2

    def test_standalone_verification(self):
        """Test standalone certificate verification"""
        cert = DeletionCertificate(
            certificate_id="del_123",
            memory_id="doc_1",
            deletion_timestamp="2025-03-15T10:00:00+00:00",
            pre_state_root="sha256:pre123",
            post_state_root="sha256:post456",
            content_hash="sha256:content789"
        )

        # Add deletion proof
        proof_data = f"{cert.pre_state_root}|DELETE|{cert.memory_id}|{cert.post_state_root}"
        import hashlib
        cert.deletion_proof = "sha256:" + hashlib.sha256(proof_data.encode()).hexdigest()

        # Verify
        result = verify_deletion_certificate_standalone(cert.to_json())
        assert result["verified"] is True
        assert result["checks"]["timestamp_valid"] is True
        assert result["checks"]["deletion_proof_valid"] is True

    def test_certifier_with_mock_client(self):
        """Test DeletionCertifier with mock client"""
        mock_client = MagicMock()
        mock_memory = MagicMock()
        mock_memory.content = "test content"
        mock_memory.metadata = {"key": "value"}

        mock_client.get.return_value = mock_memory
        mock_client.delete.return_value = True
        mock_client.list_ids.return_value = []
        mock_client.rebuild_index = MagicMock()

        certifier = DeletionCertifier(mock_client)
        cert = certifier.delete_with_certificate("doc_1", reason="test deletion")

        assert cert is not None
        assert cert.memory_id == "doc_1"
        assert cert.content_hash.startswith("sha256:")
        assert cert.index_rebuilt is True
        mock_client.rebuild_index.assert_called_once()


# =============================================================================
# TEMPORAL MEMORY TESTS
# =============================================================================

class TestDecayFunctions:
    """Tests for decay functions"""

    def test_exponential_decay(self):
        """Test exponential decay"""
        decay = ExponentialDecay(half_life_days=30)

        # At t=0, score should be 1.0
        assert decay.compute(0, 0.5) == pytest.approx(1.0)

        # At half-life, score should be ~0.5
        assert decay.compute(30, 0.5) == pytest.approx(0.5, rel=0.01)

        # High importance decays slower
        high_imp = decay.compute(30, 0.9)
        low_imp = decay.compute(30, 0.1)
        assert high_imp > low_imp

    def test_linear_decay(self):
        """Test linear decay"""
        decay = LinearDecay(max_age_days=90)

        # At t=0, score should be 1.0
        assert decay.compute(0, 0.5) == pytest.approx(1.0)

        # At half max age, score should be ~0.5
        assert decay.compute(45, 0.5) == pytest.approx(0.5, rel=0.01)

        # At/after max age, score should be min_score
        assert decay.compute(90, 0.5) == 0.0
        assert decay.compute(100, 0.5) == 0.0

    def test_step_decay(self):
        """Test step decay"""
        decay = StepDecay(steps=[
            (7, 1.0),
            (30, 0.7),
            (90, 0.3),
        ])

        assert decay.compute(5, 0.5) == pytest.approx(1.0, rel=0.1)
        assert decay.compute(15, 0.5) == pytest.approx(0.7, rel=0.1)
        assert decay.compute(60, 0.5) == pytest.approx(0.3, rel=0.1)

    def test_no_decay(self):
        """Test no decay"""
        decay = NoDecay()
        assert decay.compute(0, 0.5) == 1.0
        assert decay.compute(1000, 0.1) == 1.0


class TestImportanceScorer:
    """Tests for ImportanceScorer"""

    def test_basic_scoring(self):
        """Test basic importance scoring"""
        scorer = ImportanceScorer()

        # High explicit importance
        score = scorer.from_signals(explicit_importance=0.9, access_count=0)
        assert score > 0.4  # Weighted towards explicit

        # High access count
        score = scorer.from_signals(explicit_importance=0.5, access_count=100)
        assert score > 0.5  # Boosted by access

    def test_temporal_metadata_scoring(self):
        """Test scoring from TemporalMetadata"""
        scorer = ImportanceScorer()

        meta = TemporalMetadata(
            created_at=datetime.now(timezone.utc).isoformat(),
            importance=0.8,
            access_count=10,
            last_accessed=datetime.now(timezone.utc).isoformat()
        )

        score = scorer.compute(meta)
        assert 0.5 < score < 1.0


class TestTemporalMemory:
    """Tests for TemporalMemory"""

    def test_temporal_add(self):
        """Test adding with temporal metadata"""
        mock_client = MagicMock()
        temporal = TemporalMemory(mock_client)

        temporal.add("doc_1", "test content", importance=0.8)

        # Verify add was called with temporal metadata
        mock_client.add.assert_called_once()
        call_args = mock_client.add.call_args
        metadata = call_args[0][2]  # Third positional arg
        assert "_temporal_metadata" in metadata
        assert metadata["_temporal_metadata"]["importance"] == 0.8

    def test_temporal_expiration(self):
        """Test memory expiration"""
        meta = TemporalMetadata(
            created_at=datetime.now(timezone.utc).isoformat(),
            expires_at=(datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        )
        assert meta.is_expired() is True

        meta2 = TemporalMetadata(
            created_at=datetime.now(timezone.utc).isoformat(),
            expires_at=(datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        )
        assert meta2.is_expired() is False

    def test_temporal_metadata_age(self):
        """Test age calculation"""
        meta = TemporalMetadata(
            created_at=(datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
        )
        assert 4.9 < meta.age_days() < 5.1


# =============================================================================
# RETRIEVAL TRACER TESTS
# =============================================================================

class TestRetrievalTracer:
    """Tests for RetrievalTracer"""

    def test_start_trace(self):
        """Test starting a trace"""
        mock_client = MagicMock()
        tracer = RetrievalTracer(mock_client)

        trace = tracer.start_trace("test query", top_k=5)

        assert trace.trace_id.startswith("trace_")
        assert trace.query_text == "test query"
        assert trace.top_k_requested == 5
        assert len(trace.events) == 1
        assert trace.events[0].event_type == TraceEventType.QUERY_START

    def test_record_events(self):
        """Test recording events"""
        mock_client = MagicMock()
        tracer = RetrievalTracer(mock_client)

        trace = tracer.start_trace("test query")
        tracer.record_event(trace.trace_id, TraceEventType.EMBEDDING_START)
        tracer.record_embedding(trace.trace_id, "all-MiniLM-L6-v2", 50.0)
        tracer.record_search(trace.trace_id, 10, 25.0)

        assert len(trace.events) == 4
        assert trace.embedding_model == "all-MiniLM-L6-v2"

    def test_record_results(self):
        """Test recording retrieval results"""
        mock_client = MagicMock()
        tracer = RetrievalTracer(mock_client)

        trace = tracer.start_trace("test query", top_k=2)

        results = [
            {"id": "doc_1", "content": "first result content", "score": 0.9},
            {"id": "doc_2", "content": "second result content", "score": 0.8},
        ]
        tracer.record_results(trace.trace_id, results)

        assert len(trace.retrieved_documents) == 2
        assert trace.retrieved_documents[0].memory_id == "doc_1"
        assert trace.retrieved_documents[0].score == 0.9
        assert trace.final_results == ["doc_1", "doc_2"]

    def test_complete_trace(self):
        """Test completing a trace"""
        mock_client = MagicMock()
        tracer = RetrievalTracer(mock_client)

        trace = tracer.start_trace("test query")
        time.sleep(0.01)
        completed = tracer.complete_trace(trace.trace_id)

        assert completed is not None
        assert completed.end_time is not None
        assert completed.total_latency_ms > 0

    def test_traced_query(self):
        """Test traced_query convenience method"""
        mock_client = MagicMock()
        mock_client.query.return_value = [
            {"id": "doc_1", "content": "result 1", "score": 0.9}
        ]

        tracer = RetrievalTracer(mock_client)
        results = tracer.traced_query("test query", top_k=5)

        assert len(results) == 1
        assert "trace_id" in results[0]

        trace = tracer.get_latest_trace()
        assert trace is not None
        assert trace.total_latency_ms is not None

    def test_analyze_trace(self):
        """Test trace analysis"""
        mock_client = MagicMock()
        mock_client.query.return_value = [
            {"id": "doc_1", "content": "result 1", "score": 0.9},
            {"id": "doc_2", "content": "result 2", "score": 0.7},
        ]

        tracer = RetrievalTracer(mock_client)
        tracer.traced_query("test query", top_k=5)

        trace = tracer.get_latest_trace()
        analysis = tracer.analyze_trace(trace.trace_id)

        assert analysis is not None
        assert analysis["result_count"] == 2
        assert "scores" in analysis
        assert analysis["scores"]["max"] == 0.9
        assert "potential_issues" in analysis

    def test_compare_traces(self):
        """Test trace comparison"""
        mock_client = MagicMock()
        mock_client.query.side_effect = [
            [{"id": "doc_1", "score": 0.9}, {"id": "doc_2", "score": 0.8}],
            [{"id": "doc_2", "score": 0.85}, {"id": "doc_3", "score": 0.7}],
        ]

        tracer = RetrievalTracer(mock_client)
        tracer.traced_query("query 1", top_k=2)
        trace1_id = tracer.get_latest_trace().trace_id

        tracer.traced_query("query 2", top_k=2)
        trace2_id = tracer.get_latest_trace().trace_id

        comparison = tracer.compare_traces(trace1_id, trace2_id)

        assert comparison is not None
        assert "doc_2" in comparison["comparison"]["result_overlap"]
        assert "doc_1" in comparison["comparison"]["only_in_trace_1"]
        assert "doc_3" in comparison["comparison"]["only_in_trace_2"]
        assert 0 < comparison["comparison"]["jaccard_similarity"] < 1

    def test_create_retrieval_report(self):
        """Test human-readable report generation"""
        trace = RetrievalTrace(
            trace_id="trace_test123",
            query_text="What is the policy?",
            query_hash="sha256:abc",
            start_time="2025-03-15T10:00:00+00:00",
            end_time="2025-03-15T10:00:01+00:00",
            total_latency_ms=150.5,
            top_k_requested=5,
            final_results=["doc_1", "doc_2"],
        )

        report = create_retrieval_report(trace)

        assert "trace_test123" in report
        assert "What is the policy?" in report
        assert "150.50ms" in report

    def test_trace_eviction(self):
        """Test old traces are evicted"""
        mock_client = MagicMock()
        mock_client.query.return_value = []

        tracer = RetrievalTracer(mock_client, max_traces=3)

        # Add 5 traces
        for i in range(5):
            tracer.traced_query(f"query {i}", top_k=1)

        # Should only have 3 traces
        traces = tracer.list_traces()
        assert len(traces) == 3


# =============================================================================
# INTEGRATION TESTS
# =============================================================================

class TestGovernanceIntegration:
    """Integration tests for governance components"""

    def test_audit_with_state_proofs(self):
        """Test audit log with state proofs"""
        mock_client = MagicMock()
        mock_client.list_ids.return_value = ["doc_1"]
        mock_memory = MagicMock()
        mock_memory.content = "test"
        mock_memory.metadata = {}
        mock_client.get.return_value = mock_memory

        audit = AuditLog()
        prover = StateProver(mock_client)

        # Log with state root
        state_root = prover.compute_state_root()
        entry = audit.log_add("doc_1", "sha256:content", state_root=state_root)

        assert entry.state_root == state_root
        assert audit.verify_chain() is True

    def test_deletion_with_audit(self):
        """Test deletion certifier with audit log"""
        mock_client = MagicMock()
        mock_memory = MagicMock()
        mock_memory.content = "sensitive data"
        mock_memory.metadata = {"key": "value"}  # Non-empty metadata
        mock_client.get.return_value = mock_memory
        mock_client.delete.return_value = True
        mock_client.list_ids.return_value = []
        mock_client.rebuild_index = MagicMock()

        audit = AuditLog()
        certifier = DeletionCertifier(mock_client, audit_log=audit)

        cert = certifier.delete_with_certificate("doc_1", reason="GDPR request")

        assert cert is not None
        # Audit entry ID should be set when audit log is provided
        assert cert.audit_entry_id is not None
        assert cert.audit_entry_id.startswith("audit_")

        # Verify audit recorded it
        history = audit.get_history("doc_1")
        assert len(history) == 1
        assert history[0].operation == OperationType.DELETE_WITH_CERT
        assert history[0].details.get("reason") == "GDPR request"


# =============================================================================
# REAL MEMORY CLIENT INTEGRATION TESTS
# =============================================================================

class TestGovernanceWithRealClient:
    """Integration tests using the real MemoryClient"""

    @pytest.fixture
    def real_client(self):
        """Create a real MemoryClient for testing"""
        from aeonica_memory import MemoryClient
        client = MemoryClient(backend="faiss", explainability=True)
        client.add("doc_1", "Python is a programming language", {"topic": "programming"})
        client.add("doc_2", "JavaScript runs in browsers", {"topic": "programming"})
        client.add("doc_3", "Machine learning uses neural networks", {"topic": "AI"})
        return client

    def test_temporal_memory_with_real_client(self, real_client):
        """Test TemporalMemory works with real MemoryClient results"""
        temporal = TemporalMemory(real_client, auto_track_access=False)

        # Add with temporal metadata
        temporal.add("doc_4", "Temporal test content", importance=0.8)

        # Query should work with real RetrievalResult dataclasses
        results = temporal.query("programming language", top_k=3)

        assert len(results) > 0
        # Results should be dicts now
        assert isinstance(results[0], dict)
        assert "id" in results[0]
        assert "content" in results[0]
        assert "combined_score" in results[0]
        assert "temporal_score" in results[0]

    def test_retrieval_tracer_with_real_client(self, real_client):
        """Test RetrievalTracer works with real MemoryClient results"""
        tracer = RetrievalTracer(real_client)

        # traced_query should work with real RetrievalResult dataclasses
        results = tracer.traced_query("programming", top_k=2)

        assert len(results) > 0
        # Results should be dicts with trace_id added
        assert isinstance(results[0], dict)
        assert "trace_id" in results[0]
        assert "id" in results[0]
        assert "content" in results[0]

        # Trace should be recorded
        trace = tracer.get_latest_trace()
        assert trace is not None
        assert len(trace.final_results) == len(results)
        assert trace.total_latency_ms > 0

    def test_tracer_record_results_with_real_results(self, real_client):
        """Test record_results handles RetrievalResult dataclasses"""
        tracer = RetrievalTracer(real_client)

        # Get real results (RetrievalResult dataclasses)
        real_results = real_client.query("Python", top_k=2)

        # Start a trace
        trace = tracer.start_trace("Python query")

        # record_results should handle dataclasses
        tracer.record_results(trace.trace_id, real_results)

        # Verify documents were recorded
        assert len(trace.retrieved_documents) == len(real_results)
        assert trace.retrieved_documents[0].memory_id == real_results[0].id
        assert trace.retrieved_documents[0].score == real_results[0].score

    def test_temporal_decay_with_real_results(self, real_client):
        """Test temporal scoring actually modifies result ranking"""
        temporal = TemporalMemory(
            real_client,
            decay_function=ExponentialDecay(half_life_days=1),  # Fast decay for testing
            auto_track_access=False
        )

        # Query and verify temporal scores are added
        results = temporal.query("machine learning AI", top_k=3)

        assert len(results) > 0
        for r in results:
            assert "temporal_score" in r
            assert "combined_score" in r
            assert "semantic_score" in r
            # Temporal score should be 1.0 for fresh data (no temporal metadata)
            assert r["temporal_score"] == 1.0

    def test_tracer_analysis_with_real_client(self, real_client):
        """Test trace analysis with real results"""
        tracer = RetrievalTracer(real_client)

        results = tracer.traced_query("programming", top_k=3)
        trace = tracer.get_latest_trace()

        analysis = tracer.analyze_trace(trace.trace_id)

        assert analysis is not None
        assert analysis["result_count"] == len(results)
        assert "scores" in analysis
        assert analysis["scores"]["max"] <= 1.0
        assert analysis["scores"]["min"] >= 0.0
        assert "latency_breakdown" in analysis


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
