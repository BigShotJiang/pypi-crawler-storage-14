"""
Comprehensive tests for Aeonica MemoryClient

Run with:
    pytest aeonica_memory/tests/test_memory_client.py -v
"""

import pytest
import tempfile
import shutil
from pathlib import Path

from aeonica_memory import MemoryClient, RetrievalResult


class TestMemoryClientBasics:
    """Test basic CRUD operations"""

    def test_create_client(self):
        """Test client initialization"""
        client = MemoryClient()
        assert client is not None
        assert client.backend == "faiss"
        assert client.explainability == True

    def test_create_client_no_explainability(self):
        """Test client without explainability"""
        client = MemoryClient(explainability=False)
        assert client.explainability == False

    def test_add_single_memory(self):
        """Test adding a single memory"""
        client = MemoryClient()
        client.add("mem_1", "Python uses indentation")

        assert len(client) == 1
        assert "mem_1" in client

    def test_add_with_metadata(self):
        """Test adding memory with metadata"""
        client = MemoryClient()
        client.add("mem_1", "Python uses indentation", metadata={"lang": "python", "topic": "syntax"})

        memory = client.get("mem_1")
        assert memory is not None
        assert memory.metadata["lang"] == "python"
        assert memory.metadata["topic"] == "syntax"

    def test_add_batch(self):
        """Test batch adding memories"""
        client = MemoryClient()
        batch = [
            ("mem_1", "Python uses indentation", {}),
            ("mem_2", "JavaScript uses braces", {}),
            ("mem_3", "Ruby uses end keyword", {}),
        ]
        client.add_batch(batch)

        assert len(client) == 3
        assert "mem_1" in client
        assert "mem_2" in client
        assert "mem_3" in client

    def test_get_memory(self):
        """Test getting a specific memory"""
        client = MemoryClient()
        client.add("mem_1", "Test content", metadata={"key": "value"})

        result = client.get("mem_1")
        assert result is not None
        assert result.id == "mem_1"
        assert result.content == "Test content"
        assert result.metadata["key"] == "value"

    def test_get_nonexistent(self):
        """Test getting non-existent memory returns None"""
        client = MemoryClient()
        result = client.get("nonexistent")
        assert result is None

    def test_delete_memory(self):
        """Test deleting a memory"""
        client = MemoryClient()
        client.add("mem_1", "Test content")
        assert len(client) == 1

        deleted = client.delete("mem_1")
        assert deleted == True
        assert len(client) == 0
        assert "mem_1" not in client

    def test_delete_nonexistent(self):
        """Test deleting non-existent memory returns False"""
        client = MemoryClient()
        deleted = client.delete("nonexistent")
        assert deleted == False

    def test_update_content(self):
        """Test updating memory content"""
        client = MemoryClient()
        client.add("mem_1", "Original content")

        updated = client.update("mem_1", content="Updated content")
        assert updated == True

        memory = client.get("mem_1")
        assert memory.content == "Updated content"

    def test_update_metadata(self):
        """Test updating memory metadata"""
        client = MemoryClient()
        client.add("mem_1", "Content", metadata={"v": 1})

        client.update("mem_1", metadata={"v": 2, "new_key": "value"})

        memory = client.get("mem_1")
        assert memory.metadata["v"] == 2
        assert memory.metadata["new_key"] == "value"

    def test_clear(self):
        """Test clearing all memories"""
        client = MemoryClient()
        client.add_batch([
            ("mem_1", "Content 1", {}),
            ("mem_2", "Content 2", {}),
        ])
        assert len(client) == 2

        client.clear()
        assert len(client) == 0

    def test_list_ids(self):
        """Test listing all memory IDs"""
        client = MemoryClient()
        client.add_batch([
            ("a", "Content A", {}),
            ("b", "Content B", {}),
            ("c", "Content C", {}),
        ])

        ids = client.list_ids()
        assert set(ids) == {"a", "b", "c"}


class TestMemoryClientQuery:
    """Test query functionality"""

    @pytest.fixture
    def client_with_data(self):
        """Create client with test data"""
        client = MemoryClient()
        client.add_batch([
            ("py_1", "Python uses indentation for code blocks", {"lang": "python"}),
            ("py_2", "Python enforces whitespace significance", {"lang": "python"}),
            ("py_3", "Python is a high-level programming language", {"lang": "python"}),
            ("js_1", "JavaScript uses curly braces for blocks", {"lang": "javascript"}),
            ("js_2", "JavaScript runs in web browsers", {"lang": "javascript"}),
            ("rb_1", "Ruby uses end keyword for blocks", {"lang": "ruby"}),
        ])
        return client

    def test_basic_query(self, client_with_data):
        """Test basic semantic query"""
        results = client_with_data.query("How does Python structure code?", top_k=3)

        assert len(results) == 3
        assert all(isinstance(r, RetrievalResult) for r in results)

        # Python-related results should rank higher
        top_ids = [r.id for r in results]
        assert any(id.startswith("py") for id in top_ids)

    def test_query_with_explainability(self, client_with_data):
        """Test query returns explainability fields"""
        results = client_with_data.query("Python code structure", top_k=2, explain=True)

        for r in results:
            assert r.explanation is not None
            assert len(r.explanation) > 0

    def test_query_without_explainability(self):
        """Test query without explainability"""
        client = MemoryClient(explainability=False)
        client.add("mem_1", "Test content")

        results = client.query("test", top_k=1)
        assert len(results) == 1
        # Should still work, just no explanations
        assert results[0].content == "Test content"

    def test_query_top_k(self, client_with_data):
        """Test top_k parameter"""
        results_2 = client_with_data.query("programming", top_k=2)
        results_5 = client_with_data.query("programming", top_k=5)

        assert len(results_2) == 2
        assert len(results_5) == 5

    def test_query_scores_ordered(self, client_with_data):
        """Test results are ordered by score descending"""
        results = client_with_data.query("Python indentation", top_k=5)

        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)


class TestMetadataFiltering:
    """Test metadata filtering functionality"""

    @pytest.fixture
    def client_with_metadata(self):
        """Create client with varied metadata"""
        client = MemoryClient()
        client.add_batch([
            ("doc_1", "Python programming basics", {"lang": "python", "level": 1, "tags": ["beginner", "tutorial"]}),
            ("doc_2", "Advanced Python decorators", {"lang": "python", "level": 3, "tags": ["advanced"]}),
            ("doc_3", "JavaScript fundamentals", {"lang": "javascript", "level": 1, "tags": ["beginner"]}),
            ("doc_4", "React components", {"lang": "javascript", "level": 2, "tags": ["intermediate", "react"]}),
            ("doc_5", "Machine learning intro", {"lang": "python", "level": 2, "tags": ["ml", "beginner"]}),
        ])
        return client

    def test_exact_match_filter(self, client_with_metadata):
        """Test exact match filtering"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filters={"lang": "python"}
        )

        assert all(r.metadata["lang"] == "python" for r in results)

    def test_operator_gt_filter(self, client_with_metadata):
        """Test greater than filter"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filters={"level": {"$gt": 1}}
        )

        assert all(r.metadata["level"] > 1 for r in results)

    def test_operator_gte_filter(self, client_with_metadata):
        """Test greater than or equal filter"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filters={"level": {"$gte": 2}}
        )

        assert all(r.metadata["level"] >= 2 for r in results)

    def test_operator_in_filter(self, client_with_metadata):
        """Test $in operator"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filters={"lang": {"$in": ["python", "ruby"]}}
        )

        assert all(r.metadata["lang"] in ["python", "ruby"] for r in results)

    def test_operator_ne_filter(self, client_with_metadata):
        """Test not equals filter"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filters={"lang": {"$ne": "python"}}
        )

        assert all(r.metadata["lang"] != "python" for r in results)

    def test_combined_filters(self, client_with_metadata):
        """Test multiple filters combined"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filters={"lang": "python", "level": {"$gte": 2}}
        )

        for r in results:
            assert r.metadata["lang"] == "python"
            assert r.metadata["level"] >= 2

    def test_custom_filter_function(self, client_with_metadata):
        """Test custom filter function"""
        results = client_with_metadata.query(
            "programming",
            top_k=10,
            filter_fn=lambda m: "beginner" in m.get("tags", [])
        )

        for r in results:
            assert "beginner" in r.metadata.get("tags", [])


class TestPersistence:
    """Test save/load functionality"""

    def test_save_and_load(self):
        """Test saving and loading memories"""
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_memories"

            # Create and save
            client1 = MemoryClient()
            client1.add_batch([
                ("mem_1", "First memory", {"key": "value1"}),
                ("mem_2", "Second memory", {"key": "value2"}),
            ])
            client1.save(str(save_path))

            # Load into new client
            client2 = MemoryClient()
            client2.load(str(save_path))

            # Verify
            assert len(client2) == 2
            assert "mem_1" in client2
            assert "mem_2" in client2

            mem1 = client2.get("mem_1")
            assert mem1.content == "First memory"
            assert mem1.metadata["key"] == "value1"

    def test_load_and_query(self):
        """Test that loaded memories are queryable"""
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = Path(tmpdir) / "test_memories"

            # Create and save
            client1 = MemoryClient()
            client1.add_batch([
                ("py_1", "Python uses indentation", {}),
                ("js_1", "JavaScript uses braces", {}),
            ])
            client1.save(str(save_path))

            # Load and query
            client2 = MemoryClient()
            client2.load(str(save_path))

            results = client2.query("Python code structure", top_k=2)
            assert len(results) >= 1
            # Python memory should be retrievable
            ids = [r.id for r in results]
            assert "py_1" in ids or results[0].content.lower().find("python") >= 0

    def test_save_no_path_raises(self):
        """Test save without path raises error"""
        client = MemoryClient()
        with pytest.raises(ValueError):
            client.save()

    def test_load_nonexistent_raises(self):
        """Test load nonexistent path raises error"""
        client = MemoryClient()
        with pytest.raises(FileNotFoundError):
            client.load("/nonexistent/path")


class TestExplainability:
    """Test explainability features"""

    @pytest.fixture
    def client_with_clusters(self):
        """Create client with clustered data for schema detection"""
        client = MemoryClient()
        # Add related memories to trigger clustering
        client.add_batch([
            ("auth_1", "OAuth 2.0 uses token-based authentication", {}),
            ("auth_2", "JWT tokens provide stateless authentication", {}),
            ("auth_3", "API keys authenticate requests", {}),
            ("auth_4", "Bearer tokens in HTTP headers", {}),
            ("db_1", "SQL SELECT queries data from tables", {}),
            ("db_2", "PostgreSQL is a relational database", {}),
        ])
        return client

    def test_confidence_depth(self, client_with_clusters):
        """Test confidence depth is returned"""
        results = client_with_clusters.query("authentication tokens", top_k=3, explain=True)

        # Auth-related results should have higher confidence (more similar memories)
        for r in results:
            assert r.confidence_depth is not None

    def test_schema_detection(self, client_with_clusters):
        """Test schema detection for clustered memories"""
        # Schemas require min_cluster_size (default 3)
        results = client_with_clusters.query("authentication", top_k=3, explain=True)

        # At least some results should have schema labels
        has_schema = any(r.schema_label is not None for r in results)
        # This might not always trigger depending on similarity threshold
        # So we just verify the field exists
        assert all(hasattr(r, 'schema_label') for r in results)

    def test_explanation_text(self, client_with_clusters):
        """Test explanation text is generated"""
        results = client_with_clusters.query("database queries", top_k=2, explain=True)

        for r in results:
            assert r.explanation is not None
            assert len(r.explanation) > 10  # Some meaningful text


class TestStats:
    """Test statistics functionality"""

    def test_get_stats_empty(self):
        """Test stats for empty client"""
        client = MemoryClient()
        stats = client.get_stats()

        assert stats["total_memories"] == 0
        assert stats["backend"] == "faiss"
        assert stats["explainability_enabled"] == True

    def test_get_stats_with_data(self):
        """Test stats with data"""
        client = MemoryClient()
        client.add_batch([
            ("mem_1", "Content 1", {}),
            ("mem_2", "Content 2", {}),
            ("mem_3", "Content 3", {}),
        ])

        stats = client.get_stats()
        assert stats["total_memories"] == 3


class TestEdgeCases:
    """Test edge cases and error handling"""

    def test_empty_query(self):
        """Test querying with empty string"""
        client = MemoryClient()
        client.add("mem_1", "Some content")

        # Should not crash
        results = client.query("", top_k=1)
        assert isinstance(results, list)

    def test_unicode_content(self):
        """Test Unicode content handling"""
        client = MemoryClient()
        client.add("mem_1", "日本語テスト", metadata={"lang": "ja"})
        client.add("mem_2", "Ελληνικά", metadata={"lang": "el"})
        client.add("mem_3", "עברית", metadata={"lang": "he"})

        assert len(client) == 3

        # Should be queryable
        results = client.query("日本語", top_k=1)
        assert len(results) >= 1

    def test_very_long_content(self):
        """Test handling very long content"""
        client = MemoryClient()
        long_content = "word " * 10000  # ~50KB of text
        client.add("mem_1", long_content)

        assert len(client) == 1
        results = client.query("word", top_k=1)
        assert len(results) == 1

    def test_special_characters_in_id(self):
        """Test IDs with special characters"""
        client = MemoryClient()
        client.add("mem/with/slashes", "Content 1")
        client.add("mem:with:colons", "Content 2")
        client.add("mem.with.dots", "Content 3")

        assert "mem/with/slashes" in client
        assert "mem:with:colons" in client
        assert "mem.with.dots" in client

    def test_duplicate_id_overwrites(self):
        """Test that adding duplicate ID overwrites and count stays correct"""
        client = MemoryClient()
        client.add("mem_1", "Original content")
        assert len(client) == 1

        client.add("mem_1", "New content")

        # Should still have only one memory (not 2)
        assert len(client) == 1
        memory = client.get("mem_1")
        assert memory.content == "New content"

    def test_rebuild_index_after_update(self):
        """Test that rebuild_index makes updates queryable"""
        client = MemoryClient()
        client.add("mem_1", "Python programming language")
        client.add("mem_2", "JavaScript web development")

        # Update content
        client.update("mem_1", content="Ruby programming language")

        # Rebuild to sync FAISS
        client.rebuild_index()

        # Query should now find Ruby content
        results = client.query("Ruby", top_k=2)
        assert any("Ruby" in r.content for r in results)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
