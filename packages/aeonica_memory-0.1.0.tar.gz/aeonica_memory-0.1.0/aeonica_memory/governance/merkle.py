"""
Merkle Tree State Proofs for Aeonica Memory

Provides cryptographic proofs of memory state at any point in time.
Used for compliance, auditing, and proving "what the AI knew when."

Features:
- Build Merkle tree from memory state
- Generate inclusion proofs for specific memories
- Verify proofs independently
- Reconstruct state roots at historical timestamps

Example:
    prover = StateProver(client)

    # Get current state root
    root = prover.compute_state_root()

    # Prove a specific memory was in the state
    proof = prover.prove_inclusion("doc_1")

    # Verify the proof (can be done by third party)
    is_valid = StateProver.verify_proof(proof)

    # Prove a query result came from specific state
    query_proof = prover.prove_retrieval(trace_id)
"""

import hashlib
import json
from dataclasses import dataclass, asdict, field
from typing import List, Optional, Dict, Any, Tuple
from datetime import datetime, timezone


@dataclass
class MerkleNode:
    """A node in the Merkle tree"""
    hash: str
    left: Optional["MerkleNode"] = None
    right: Optional["MerkleNode"] = None
    data: Optional[str] = None  # Only for leaf nodes (memory_id)

    def is_leaf(self) -> bool:
        return self.left is None and self.right is None


@dataclass
class InclusionProof:
    """
    Proof that a memory is included in a specific state

    Attributes:
        memory_id: The memory being proven
        memory_hash: Hash of the memory content + metadata
        state_root: The Merkle root being proven against
        proof_path: List of (hash, position) tuples for verification
        timestamp: When the proof was generated
    """
    memory_id: str
    memory_hash: str
    state_root: str
    proof_path: List[Tuple[str, str]]  # [(hash, "left"|"right"), ...]
    timestamp: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "InclusionProof":
        return cls(**data)

    def to_json(self) -> str:
        """Serialize to JSON for storage/transmission"""
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_json(cls, json_str: str) -> "InclusionProof":
        """Deserialize from JSON"""
        return cls.from_dict(json.loads(json_str))


@dataclass
class StateProof:
    """
    Proof of complete memory state at a point in time

    Used for compliance: "This was the complete knowledge state at timestamp T"

    Attributes:
        state_root: Merkle root of the state
        memory_count: Number of memories in state
        memory_ids: List of all memory IDs (optional, for small states)
        timestamp: When the state was captured
        audit_entry_id: Link to audit log entry
    """
    state_root: str
    memory_count: int
    timestamp: str
    audit_entry_id: Optional[str] = None
    memory_ids: Optional[List[str]] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


class MerkleTree:
    """
    Merkle tree implementation for memory state proofs

    Builds a binary hash tree from memory entries where:
    - Leaf nodes are hashes of individual memories
    - Internal nodes are hashes of their children
    - Root hash uniquely identifies the entire state

    Example:
        tree = MerkleTree()

        # Add memory hashes
        tree.add_leaf("doc_1", hash_of_doc_1)
        tree.add_leaf("doc_2", hash_of_doc_2)

        # Build tree and get root
        root = tree.build()

        # Generate inclusion proof
        proof = tree.get_inclusion_proof("doc_1")
    """

    def __init__(self):
        self._leaves: List[Tuple[str, str]] = []  # [(memory_id, hash), ...]
        self._root: Optional[MerkleNode] = None
        self._leaf_indices: Dict[str, int] = {}  # memory_id -> leaf index

    def add_leaf(self, memory_id: str, memory_hash: str) -> None:
        """Add a leaf node (memory) to the tree"""
        self._leaf_indices[memory_id] = len(self._leaves)
        self._leaves.append((memory_id, memory_hash))
        self._root = None  # Invalidate cached root

    def clear(self) -> None:
        """Clear all leaves"""
        self._leaves.clear()
        self._leaf_indices.clear()
        self._root = None

    def build(self) -> str:
        """
        Build the Merkle tree and return the root hash

        Returns:
            Root hash of the tree
        """
        if not self._leaves:
            # Empty tree has a defined empty root
            return "sha256:" + hashlib.sha256(b"empty").hexdigest()

        # Create leaf nodes
        nodes = []
        for memory_id, memory_hash in self._leaves:
            # Leaf hash includes memory_id for uniqueness
            leaf_data = f"{memory_id}:{memory_hash}"
            leaf_hash = "sha256:" + hashlib.sha256(leaf_data.encode()).hexdigest()
            nodes.append(MerkleNode(hash=leaf_hash, data=memory_id))

        # Build tree bottom-up
        while len(nodes) > 1:
            next_level = []
            for i in range(0, len(nodes), 2):
                left = nodes[i]
                # If odd number of nodes, duplicate the last one
                right = nodes[i + 1] if i + 1 < len(nodes) else nodes[i]

                # Parent hash is hash of children
                combined = left.hash + right.hash
                parent_hash = "sha256:" + hashlib.sha256(combined.encode()).hexdigest()
                parent = MerkleNode(hash=parent_hash, left=left, right=right)
                next_level.append(parent)

            nodes = next_level

        self._root = nodes[0]
        return self._root.hash

    @property
    def root_hash(self) -> Optional[str]:
        """Get the root hash (builds tree if needed)"""
        if self._root is None and self._leaves:
            self.build()
        return self._root.hash if self._root else None

    def get_inclusion_proof(self, memory_id: str) -> Optional[InclusionProof]:
        """
        Generate a proof that a memory is included in the tree

        Args:
            memory_id: The memory to prove

        Returns:
            InclusionProof or None if memory not in tree
        """
        if memory_id not in self._leaf_indices:
            return None

        if self._root is None:
            self.build()

        leaf_idx = self._leaf_indices[memory_id]
        memory_hash = self._leaves[leaf_idx][1]

        # Build proof path by traversing tree
        proof_path = self._build_proof_path(leaf_idx)

        return InclusionProof(
            memory_id=memory_id,
            memory_hash=memory_hash,
            state_root=self._root.hash,
            proof_path=proof_path,
            timestamp=datetime.now(timezone.utc).isoformat()
        )

    def _build_proof_path(self, leaf_idx: int) -> List[Tuple[str, str]]:
        """Build the proof path for a leaf"""
        if not self._leaves:
            return []

        # Rebuild the tree structure tracking the path
        # This is a simplified approach - rebuild leaf hashes
        nodes = []
        for memory_id, memory_hash in self._leaves:
            leaf_data = f"{memory_id}:{memory_hash}"
            leaf_hash = "sha256:" + hashlib.sha256(leaf_data.encode()).hexdigest()
            nodes.append(leaf_hash)

        proof_path = []
        idx = leaf_idx

        while len(nodes) > 1:
            next_level = []
            for i in range(0, len(nodes), 2):
                left_hash = nodes[i]
                right_hash = nodes[i + 1] if i + 1 < len(nodes) else nodes[i]

                # If our index is in this pair, record the sibling
                if i <= idx < i + 2:
                    if idx == i:
                        # We're the left node, sibling is right
                        proof_path.append((right_hash, "right"))
                    else:
                        # We're the right node, sibling is left
                        proof_path.append((left_hash, "left"))
                    # Update index for next level
                    idx = i // 2

                combined = left_hash + right_hash
                parent_hash = "sha256:" + hashlib.sha256(combined.encode()).hexdigest()
                next_level.append(parent_hash)

            nodes = next_level

        return proof_path

    @staticmethod
    def verify_inclusion_proof(proof: InclusionProof) -> bool:
        """
        Verify an inclusion proof

        This can be done by anyone with the proof - no access to the
        original data or tree structure is needed.

        Args:
            proof: The inclusion proof to verify

        Returns:
            True if proof is valid
        """
        # Start with leaf hash
        leaf_data = f"{proof.memory_id}:{proof.memory_hash}"
        current_hash = "sha256:" + hashlib.sha256(leaf_data.encode()).hexdigest()

        # Walk up the proof path
        for sibling_hash, position in proof.proof_path:
            if position == "left":
                combined = sibling_hash + current_hash
            else:  # right
                combined = current_hash + sibling_hash

            current_hash = "sha256:" + hashlib.sha256(combined.encode()).hexdigest()

        # Should match the state root
        return current_hash == proof.state_root


class StateProver:
    """
    High-level interface for generating state proofs

    Integrates with MemoryClient to provide:
    - Current state root computation
    - Historical state reconstruction
    - Inclusion proofs for specific memories
    - Retrieval proofs linking queries to state

    Example:
        prover = StateProver(memory_client)

        # Compute current state root
        root = prover.compute_state_root()

        # Generate proof for a memory
        proof = prover.prove_inclusion("doc_1")

        # Verify externally
        is_valid = prover.verify_proof(proof)
    """

    def __init__(self, memory_client):
        """
        Initialize StateProver

        Args:
            memory_client: MemoryClient instance to generate proofs for
        """
        self._client = memory_client
        self._tree = MerkleTree()

    def compute_state_root(self) -> str:
        """
        Compute the current state root

        Returns:
            Merkle root hash of current memory state
        """
        self._tree.clear()

        # Add all memories to tree
        for memory_id in self._client.list_ids():
            memory = self._client.get(memory_id)
            if memory:
                # Hash content + metadata
                memory_hash = self._hash_memory(memory_id, memory.content, memory.metadata)
                self._tree.add_leaf(memory_id, memory_hash)

        return self._tree.build()

    def _hash_memory(self, memory_id: str, content: str, metadata: Optional[Dict]) -> str:
        """Compute hash of a memory"""
        data = {
            "id": memory_id,
            "content_hash": hashlib.sha256(content.encode()).hexdigest(),
            "metadata_hash": hashlib.sha256(
                json.dumps(metadata or {}, sort_keys=True).encode()
            ).hexdigest()
        }
        return "sha256:" + hashlib.sha256(
            json.dumps(data, sort_keys=True).encode()
        ).hexdigest()

    def prove_inclusion(self, memory_id: str) -> Optional[InclusionProof]:
        """
        Prove a memory is included in the current state

        Args:
            memory_id: Memory to prove

        Returns:
            InclusionProof or None if memory doesn't exist
        """
        # Rebuild tree to ensure current state
        self.compute_state_root()
        return self._tree.get_inclusion_proof(memory_id)

    def verify_proof(self, proof: InclusionProof) -> bool:
        """Verify an inclusion proof"""
        return MerkleTree.verify_inclusion_proof(proof)

    def get_state_proof(self, include_ids: bool = True) -> StateProof:
        """
        Get a complete state proof

        Args:
            include_ids: Whether to include list of memory IDs

        Returns:
            StateProof capturing current state
        """
        root = self.compute_state_root()
        memory_ids = self._client.list_ids() if include_ids else None

        return StateProof(
            state_root=root,
            memory_count=len(self._client),
            timestamp=datetime.now(timezone.utc).isoformat(),
            memory_ids=memory_ids
        )

    def prove_retrieval(
        self,
        retrieved_ids: List[str],
        query_hash: str
    ) -> Dict[str, Any]:
        """
        Prove a retrieval result came from a specific state

        Args:
            retrieved_ids: List of memory IDs that were retrieved
            query_hash: Hash of the query

        Returns:
            Dict containing state root, individual proofs, and metadata
        """
        state_root = self.compute_state_root()

        # Generate proof for each retrieved memory
        proofs = []
        for memory_id in retrieved_ids:
            proof = self._tree.get_inclusion_proof(memory_id)
            if proof:
                proofs.append(proof.to_dict())

        return {
            "state_root": state_root,
            "query_hash": query_hash,
            "retrieved_count": len(retrieved_ids),
            "retrieved_ids": retrieved_ids,
            "inclusion_proofs": proofs,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
