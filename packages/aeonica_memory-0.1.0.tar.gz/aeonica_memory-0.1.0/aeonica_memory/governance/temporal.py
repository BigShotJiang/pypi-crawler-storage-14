"""
Temporal Memory with Decay and Importance Scoring for Aeonica Memory

Provides time-aware memory management where:
- Memories decay in relevance over time
- Importance scores boost or diminish decay
- Access patterns affect memory strength
- Expired memories can be auto-archived or deleted

This enables more human-like memory behavior:
- Recent information is more readily available
- Important memories persist longer
- Frequently accessed memories stay strong
- Stale information naturally fades

Example:
    temporal = TemporalMemory(client, decay_function=ExponentialDecay(half_life_days=30))

    # Add with importance
    temporal.add("doc_1", "Critical policy update", importance=0.9)

    # Query with temporal scoring
    results = temporal.query("policy", include_temporal_scores=True)

    # Run maintenance (archive expired, boost accessed)
    temporal.run_maintenance()
"""

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional, Dict, Any, List, Callable, Tuple
from enum import Enum
import json


class DecayType(str, Enum):
    """Types of decay functions"""
    EXPONENTIAL = "exponential"
    LINEAR = "linear"
    STEP = "step"
    NONE = "none"


@dataclass
class TemporalMetadata:
    """
    Temporal metadata attached to each memory

    Attributes:
        created_at: When the memory was created
        last_accessed: When it was last retrieved
        access_count: Number of times retrieved
        importance: Base importance score (0-1)
        decay_rate: Custom decay rate (overrides default)
        expires_at: Optional hard expiration timestamp
        archived: Whether memory is archived (excluded from queries)
        temporal_boost: Temporary boost to relevance
    """
    created_at: str
    last_accessed: Optional[str] = None
    access_count: int = 0
    importance: float = 0.5
    decay_rate: Optional[float] = None
    expires_at: Optional[str] = None
    archived: bool = False
    temporal_boost: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TemporalMetadata":
        return cls(**data)

    def age_seconds(self) -> float:
        """Get age in seconds"""
        created = datetime.fromisoformat(self.created_at.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        return (now - created).total_seconds()

    def age_days(self) -> float:
        """Get age in days"""
        return self.age_seconds() / 86400

    def is_expired(self) -> bool:
        """Check if memory has expired"""
        if not self.expires_at:
            return False
        expires = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        return datetime.now(timezone.utc) > expires


class DecayFunction(ABC):
    """
    Abstract base class for decay functions

    Decay functions determine how relevance decreases over time.
    The decay score is multiplied with semantic similarity.
    """

    @abstractmethod
    def compute(self, age_days: float, importance: float = 0.5) -> float:
        """
        Compute decay score for a given age

        Args:
            age_days: Age of memory in days
            importance: Importance score (0-1)

        Returns:
            Decay score between 0 and 1
        """
        pass

    @abstractmethod
    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dict"""
        pass


class ExponentialDecay(DecayFunction):
    """
    Exponential decay: score = e^(-λt)

    Where λ = ln(2) / half_life

    This models natural forgetting - memories decay quickly at first,
    then level off. Important memories decay slower.

    Example:
        decay = ExponentialDecay(half_life_days=30)

        # After 30 days, score = 0.5
        # After 60 days, score = 0.25
        # After 90 days, score = 0.125
    """

    def __init__(
        self,
        half_life_days: float = 30.0,
        importance_factor: float = 2.0,
        min_score: float = 0.01
    ):
        """
        Args:
            half_life_days: Days until memory reaches 50% relevance
            importance_factor: How much importance extends half-life
            min_score: Minimum score (memories never fully decay)
        """
        self.half_life_days = half_life_days
        self.importance_factor = importance_factor
        self.min_score = min_score
        self._lambda = math.log(2) / half_life_days

    def compute(self, age_days: float, importance: float = 0.5) -> float:
        # Adjust half-life based on importance
        # High importance = slower decay
        adjusted_lambda = self._lambda / (1 + (importance - 0.5) * self.importance_factor)
        score = math.exp(-adjusted_lambda * age_days)
        return max(score, self.min_score)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": DecayType.EXPONENTIAL.value,
            "half_life_days": self.half_life_days,
            "importance_factor": self.importance_factor,
            "min_score": self.min_score
        }


class LinearDecay(DecayFunction):
    """
    Linear decay: score = 1 - (age / max_age)

    Simple linear decrease until reaching zero (or min_score).
    Good for memories that should fully expire after a set period.

    Example:
        decay = LinearDecay(max_age_days=90)

        # After 30 days, score = 0.67
        # After 60 days, score = 0.33
        # After 90 days, score = 0.0 (or min_score)
    """

    def __init__(
        self,
        max_age_days: float = 90.0,
        importance_factor: float = 1.5,
        min_score: float = 0.0
    ):
        """
        Args:
            max_age_days: Days until memory reaches 0 relevance
            importance_factor: How much importance extends max age
            min_score: Minimum score
        """
        self.max_age_days = max_age_days
        self.importance_factor = importance_factor
        self.min_score = min_score

    def compute(self, age_days: float, importance: float = 0.5) -> float:
        # Adjust max age based on importance
        adjusted_max = self.max_age_days * (1 + (importance - 0.5) * self.importance_factor)
        if age_days >= adjusted_max:
            return self.min_score
        score = 1 - (age_days / adjusted_max)
        return max(score, self.min_score)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": DecayType.LINEAR.value,
            "max_age_days": self.max_age_days,
            "importance_factor": self.importance_factor,
            "min_score": self.min_score
        }


class StepDecay(DecayFunction):
    """
    Step decay: score drops at defined thresholds

    Useful for regulatory contexts where data has defined retention periods.

    Example:
        decay = StepDecay(steps=[
            (7, 1.0),    # 0-7 days: full relevance
            (30, 0.7),   # 7-30 days: 70% relevance
            (90, 0.3),   # 30-90 days: 30% relevance
            (365, 0.1),  # 90-365 days: 10% relevance
        ])
    """

    def __init__(
        self,
        steps: List[Tuple[float, float]],
        importance_factor: float = 1.0,
        min_score: float = 0.0
    ):
        """
        Args:
            steps: List of (days, score) tuples, sorted by days ascending
            importance_factor: How much importance affects scores
            min_score: Score after the last step
        """
        self.steps = sorted(steps, key=lambda x: x[0])
        self.importance_factor = importance_factor
        self.min_score = min_score

    def compute(self, age_days: float, importance: float = 0.5) -> float:
        # Find applicable step
        score = self.min_score
        for days, step_score in self.steps:
            if age_days <= days:
                score = step_score
                break

        # Apply importance modifier
        importance_boost = (importance - 0.5) * self.importance_factor * 0.2
        return min(1.0, max(self.min_score, score + importance_boost))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": DecayType.STEP.value,
            "steps": self.steps,
            "importance_factor": self.importance_factor,
            "min_score": self.min_score
        }


class NoDecay(DecayFunction):
    """No decay - memories never lose relevance due to time"""

    def compute(self, age_days: float, importance: float = 0.5) -> float:
        return 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {"type": DecayType.NONE.value}


class ImportanceScorer:
    """
    Computes importance scores for memories

    Combines multiple signals:
    - Explicit importance (user-provided)
    - Access frequency
    - Recency of access
    - Content-based heuristics (keywords, length, etc.)

    Example:
        scorer = ImportanceScorer()

        # Compute importance from metadata
        score = scorer.compute(temporal_metadata)

        # Or from signals
        score = scorer.from_signals(
            explicit_importance=0.7,
            access_count=50,
            days_since_access=5
        )
    """

    def __init__(
        self,
        access_weight: float = 0.3,
        recency_weight: float = 0.2,
        explicit_weight: float = 0.5,
        access_log_base: float = 10.0,
        recency_half_life: float = 7.0
    ):
        """
        Args:
            access_weight: Weight for access frequency signal
            recency_weight: Weight for recency of access signal
            explicit_weight: Weight for explicit importance
            access_log_base: Log base for normalizing access counts
            recency_half_life: Half-life for recency decay (days)
        """
        self.access_weight = access_weight
        self.recency_weight = recency_weight
        self.explicit_weight = explicit_weight
        self.access_log_base = access_log_base
        self.recency_half_life = recency_half_life

        # Normalize weights
        total = access_weight + recency_weight + explicit_weight
        self.access_weight /= total
        self.recency_weight /= total
        self.explicit_weight /= total

    def compute(self, temporal_meta: TemporalMetadata) -> float:
        """
        Compute importance from temporal metadata

        Args:
            temporal_meta: TemporalMetadata object

        Returns:
            Importance score between 0 and 1
        """
        # Access frequency signal
        access_signal = self._normalize_access_count(temporal_meta.access_count)

        # Recency signal (how recently was it accessed)
        recency_signal = self._compute_recency(temporal_meta.last_accessed)

        # Explicit importance
        explicit_signal = temporal_meta.importance

        # Weighted combination
        score = (
            self.access_weight * access_signal +
            self.recency_weight * recency_signal +
            self.explicit_weight * explicit_signal
        )

        # Add any temporary boost
        score = min(1.0, score + temporal_meta.temporal_boost)

        return score

    def from_signals(
        self,
        explicit_importance: float = 0.5,
        access_count: int = 0,
        days_since_access: Optional[float] = None
    ) -> float:
        """
        Compute importance from individual signals

        Args:
            explicit_importance: User-provided importance
            access_count: Number of times accessed
            days_since_access: Days since last access (None if never accessed)

        Returns:
            Importance score
        """
        access_signal = self._normalize_access_count(access_count)

        if days_since_access is None:
            recency_signal = 0.0
        else:
            # Convert to timestamp
            last_access = datetime.now(timezone.utc) - timedelta(days=days_since_access)
            recency_signal = self._compute_recency(last_access.isoformat())

        return (
            self.access_weight * access_signal +
            self.recency_weight * recency_signal +
            self.explicit_weight * explicit_importance
        )

    def _normalize_access_count(self, count: int) -> float:
        """Normalize access count to 0-1 using log scale"""
        if count == 0:
            return 0.0
        return min(1.0, math.log(count + 1, self.access_log_base))

    def _compute_recency(self, last_accessed: Optional[str]) -> float:
        """Compute recency score from last access timestamp"""
        if not last_accessed:
            return 0.0

        last = datetime.fromisoformat(last_accessed.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        days_ago = (now - last).total_seconds() / 86400

        # Exponential decay from last access
        decay_rate = math.log(2) / self.recency_half_life
        return math.exp(-decay_rate * days_ago)


class TemporalMemory:
    """
    Time-aware memory wrapper for MemoryClient

    Adds temporal dimensions to semantic memory:
    - Decay: Older memories have lower relevance
    - Importance: Critical memories persist longer
    - Access tracking: Frequently used memories stay strong
    - Expiration: Memories can auto-expire

    Example:
        from aeonica_memory import MemoryClient
        from aeonica_memory.governance import TemporalMemory, ExponentialDecay

        client = MemoryClient()
        temporal = TemporalMemory(client, decay_function=ExponentialDecay(half_life_days=30))

        # Add with importance
        temporal.add("policy_update", "New vacation policy...", importance=0.8)

        # Add with expiration
        temporal.add("temp_notice", "Office closed tomorrow",
                    expires_in_days=2, importance=0.6)

        # Query with temporal scoring
        results = temporal.query("vacation policy")
        # Results ranked by semantic similarity * temporal score

        # Get temporal metadata
        meta = temporal.get_temporal_metadata("policy_update")
        print(f"Age: {meta.age_days()} days, accessed {meta.access_count} times")

        # Run maintenance
        archived, deleted = temporal.run_maintenance(
            archive_threshold=0.1,  # Archive if temporal score < 0.1
            delete_expired=True
        )
    """

    TEMPORAL_META_KEY = "_temporal_metadata"

    def __init__(
        self,
        memory_client,
        decay_function: Optional[DecayFunction] = None,
        importance_scorer: Optional[ImportanceScorer] = None,
        auto_track_access: bool = True
    ):
        """
        Initialize temporal memory

        Args:
            memory_client: MemoryClient instance
            decay_function: Decay function to use (default: ExponentialDecay)
            importance_scorer: Importance scorer (default: ImportanceScorer())
            auto_track_access: Automatically track access on queries
        """
        self._client = memory_client
        self._decay = decay_function or ExponentialDecay()
        self._scorer = importance_scorer or ImportanceScorer()
        self._auto_track = auto_track_access

    def add(
        self,
        memory_id: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        importance: float = 0.5,
        expires_in_days: Optional[float] = None,
        decay_rate: Optional[float] = None
    ) -> None:
        """
        Add a memory with temporal metadata

        Args:
            memory_id: Unique identifier
            content: Text content
            metadata: Additional metadata
            importance: Importance score (0-1)
            expires_in_days: Days until expiration (None = never)
            decay_rate: Custom decay rate (overrides default)
        """
        now = datetime.now(timezone.utc)

        # Create temporal metadata
        temporal_meta = TemporalMetadata(
            created_at=now.isoformat(),
            importance=importance,
            decay_rate=decay_rate,
            expires_at=(
                (now + timedelta(days=expires_in_days)).isoformat()
                if expires_in_days else None
            )
        )

        # Merge with user metadata
        full_metadata = metadata.copy() if metadata else {}
        full_metadata[self.TEMPORAL_META_KEY] = temporal_meta.to_dict()

        self._client.add(memory_id, content, full_metadata)

    def query(
        self,
        query_text: str,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
        include_archived: bool = False,
        temporal_weight: float = 0.3
    ) -> List[Dict[str, Any]]:
        """
        Query with temporal-aware scoring

        Final score = (1 - temporal_weight) * semantic_score + temporal_weight * temporal_score

        Args:
            query_text: Query text
            top_k: Number of results
            filters: Metadata filters
            include_archived: Include archived memories
            temporal_weight: Weight of temporal score (0-1)

        Returns:
            List of results with temporal metadata (as dicts)
        """
        # Get more results than needed for re-ranking
        raw_results = self._client.query(query_text, top_k=top_k * 3, filters=filters)

        # Apply temporal scoring
        scored_results = []
        for result in raw_results:
            # Convert to dict if it's a dataclass (RetrievalResult)
            result_dict = self._to_dict(result)

            temporal_meta = self._get_temporal_meta(result_dict)

            # Skip archived unless requested
            if temporal_meta and temporal_meta.archived and not include_archived:
                continue

            # Skip expired
            if temporal_meta and temporal_meta.is_expired():
                continue

            # Compute temporal score
            if temporal_meta:
                importance = self._scorer.compute(temporal_meta)
                temporal_score = self._decay.compute(
                    temporal_meta.age_days(),
                    importance
                )
            else:
                temporal_score = 1.0  # No temporal data = full score

            # Combine scores
            semantic_score = self._get_score(result_dict)
            final_score = (
                (1 - temporal_weight) * semantic_score +
                temporal_weight * temporal_score
            )

            result_dict["temporal_score"] = temporal_score
            result_dict["combined_score"] = final_score
            result_dict["semantic_score"] = semantic_score

            if temporal_meta:
                result_dict["age_days"] = temporal_meta.age_days()
                result_dict["importance"] = importance
                result_dict["access_count"] = temporal_meta.access_count

            scored_results.append(result_dict)

        # Sort by combined score
        scored_results.sort(key=lambda x: x["combined_score"], reverse=True)

        # Track access for top results
        if self._auto_track:
            for result in scored_results[:top_k]:
                self._track_access(result.get("id") or result.get("memory_id"))

        return scored_results[:top_k]

    def _to_dict(self, result: Any) -> Dict[str, Any]:
        """Convert result to dict, handling both dicts and dataclasses"""
        if isinstance(result, dict):
            return result
        # Handle dataclass (RetrievalResult)
        if hasattr(result, '__dataclass_fields__'):
            from dataclasses import asdict
            return asdict(result)
        # Handle object with __dict__
        if hasattr(result, '__dict__'):
            return vars(result)
        # Fallback: try to extract common attributes
        return {
            "id": getattr(result, "id", None),
            "content": getattr(result, "content", ""),
            "score": getattr(result, "score", 0.0),
            "metadata": getattr(result, "metadata", {}),
        }

    def _get_score(self, result: Dict[str, Any]) -> float:
        """Extract score from result dict"""
        return result.get("score", result.get("similarity", 0.5))

    def _get_temporal_meta(self, result: Dict[str, Any]) -> Optional[TemporalMetadata]:
        """Extract temporal metadata from result"""
        metadata = result.get("metadata") or {}
        temporal_data = metadata.get(self.TEMPORAL_META_KEY)
        if temporal_data:
            return TemporalMetadata.from_dict(temporal_data)
        return None

    def _track_access(self, memory_id: str) -> None:
        """Record access to a memory"""
        if not memory_id:
            return

        memory = self._client.get(memory_id)
        if not memory:
            return

        metadata = memory.metadata or {}
        temporal_data = metadata.get(self.TEMPORAL_META_KEY)

        if temporal_data:
            temporal_meta = TemporalMetadata.from_dict(temporal_data)
            temporal_meta.access_count += 1
            temporal_meta.last_accessed = datetime.now(timezone.utc).isoformat()
            metadata[self.TEMPORAL_META_KEY] = temporal_meta.to_dict()
            self._client.update(memory_id, metadata=metadata)

    def get_temporal_metadata(self, memory_id: str) -> Optional[TemporalMetadata]:
        """Get temporal metadata for a memory"""
        memory = self._client.get(memory_id)
        if not memory or not memory.metadata:
            return None

        temporal_data = memory.metadata.get(self.TEMPORAL_META_KEY)
        if temporal_data:
            return TemporalMetadata.from_dict(temporal_data)
        return None

    def update_importance(self, memory_id: str, importance: float) -> bool:
        """Update importance score for a memory"""
        memory = self._client.get(memory_id)
        if not memory:
            return False

        metadata = memory.metadata or {}
        temporal_data = metadata.get(self.TEMPORAL_META_KEY)

        if temporal_data:
            temporal_meta = TemporalMetadata.from_dict(temporal_data)
            temporal_meta.importance = importance
            metadata[self.TEMPORAL_META_KEY] = temporal_meta.to_dict()
            self._client.update(memory_id, metadata=metadata)
            return True

        return False

    def boost_memory(self, memory_id: str, boost: float, duration_days: float) -> bool:
        """
        Temporarily boost a memory's relevance

        Args:
            memory_id: Memory to boost
            boost: Boost amount (added to score)
            duration_days: How long boost lasts

        Returns:
            Success boolean
        """
        memory = self._client.get(memory_id)
        if not memory:
            return False

        metadata = memory.metadata or {}
        temporal_data = metadata.get(self.TEMPORAL_META_KEY)

        if temporal_data:
            temporal_meta = TemporalMetadata.from_dict(temporal_data)
            temporal_meta.temporal_boost = boost
            # Note: In production, you'd track boost expiration separately
            metadata[self.TEMPORAL_META_KEY] = temporal_meta.to_dict()
            self._client.update(memory_id, metadata=metadata)
            return True

        return False

    def archive(self, memory_id: str) -> bool:
        """Archive a memory (exclude from queries but keep for compliance)"""
        memory = self._client.get(memory_id)
        if not memory:
            return False

        metadata = memory.metadata or {}
        temporal_data = metadata.get(self.TEMPORAL_META_KEY)

        if temporal_data:
            temporal_meta = TemporalMetadata.from_dict(temporal_data)
            temporal_meta.archived = True
            metadata[self.TEMPORAL_META_KEY] = temporal_meta.to_dict()
            self._client.update(memory_id, metadata=metadata)
            return True

        return False

    def unarchive(self, memory_id: str) -> bool:
        """Restore an archived memory"""
        memory = self._client.get(memory_id)
        if not memory:
            return False

        metadata = memory.metadata or {}
        temporal_data = metadata.get(self.TEMPORAL_META_KEY)

        if temporal_data:
            temporal_meta = TemporalMetadata.from_dict(temporal_data)
            temporal_meta.archived = False
            metadata[self.TEMPORAL_META_KEY] = temporal_meta.to_dict()
            self._client.update(memory_id, metadata=metadata)
            return True

        return False

    def run_maintenance(
        self,
        archive_threshold: Optional[float] = None,
        delete_expired: bool = True
    ) -> Dict[str, List[str]]:
        """
        Run maintenance tasks

        Args:
            archive_threshold: Archive memories with temporal score below this
            delete_expired: Delete memories past their expiration date

        Returns:
            Dict with lists of archived and deleted memory IDs
        """
        archived = []
        deleted = []

        for memory_id in self._client.list_ids():
            memory = self._client.get(memory_id)
            if not memory or not memory.metadata:
                continue

            temporal_data = memory.metadata.get(self.TEMPORAL_META_KEY)
            if not temporal_data:
                continue

            temporal_meta = TemporalMetadata.from_dict(temporal_data)

            # Check expiration
            if delete_expired and temporal_meta.is_expired():
                self._client.delete(memory_id)
                deleted.append(memory_id)
                continue

            # Check archive threshold
            if archive_threshold is not None and not temporal_meta.archived:
                importance = self._scorer.compute(temporal_meta)
                temporal_score = self._decay.compute(
                    temporal_meta.age_days(),
                    importance
                )

                if temporal_score < archive_threshold:
                    self.archive(memory_id)
                    archived.append(memory_id)

        return {"archived": archived, "deleted": deleted}

    def get_decay_function(self) -> DecayFunction:
        """Get the current decay function"""
        return self._decay

    def set_decay_function(self, decay: DecayFunction) -> None:
        """Set the decay function"""
        self._decay = decay

    def compute_temporal_score(self, memory_id: str) -> Optional[float]:
        """Compute current temporal score for a memory"""
        temporal_meta = self.get_temporal_metadata(memory_id)
        if not temporal_meta:
            return None

        importance = self._scorer.compute(temporal_meta)
        return self._decay.compute(temporal_meta.age_days(), importance)
