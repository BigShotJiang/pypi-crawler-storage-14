"""
Retrieval Tracing for Aeonica Memory

Full observability into RAG retrievals:
- Trace each query from input to output
- Record all retrieved documents with scores
- Track latency at each stage
- Link traces to audit log entries
- Debug why certain documents were/weren't retrieved

This is essential for:
- RAG debugging ("why did it retrieve X instead of Y?")
- Compliance ("what knowledge informed this decision?")
- Performance optimization
- A/B testing retrieval strategies

Example:
    tracer = RetrievalTracer(client)

    # Start a trace
    trace = tracer.start_trace("What is the vacation policy?")

    # Query (internally records retrieval)
    results = tracer.traced_query("What is the vacation policy?", trace_id=trace.trace_id)

    # Complete trace
    tracer.complete_trace(trace.trace_id)

    # Analyze
    analysis = tracer.analyze_trace(trace.trace_id)
    print(f"Retrieved {analysis['result_count']} docs in {analysis['total_latency_ms']}ms")

    # Export for debugging
    trace_json = tracer.export_trace(trace.trace_id)
"""

import uuid
import time
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Tuple
from enum import Enum


class TraceEventType(str, Enum):
    """Types of trace events"""
    QUERY_START = "query_start"
    EMBEDDING_START = "embedding_start"
    EMBEDDING_COMPLETE = "embedding_complete"
    SEARCH_START = "search_start"
    SEARCH_COMPLETE = "search_complete"
    FILTER_APPLIED = "filter_applied"
    RERANK_START = "rerank_start"
    RERANK_COMPLETE = "rerank_complete"
    RESULT_SELECTED = "result_selected"
    RESULT_EXCLUDED = "result_excluded"
    QUERY_COMPLETE = "query_complete"
    ERROR = "error"
    CUSTOM = "custom"


@dataclass
class TraceEvent:
    """
    A single event in a retrieval trace

    Attributes:
        event_type: Type of event
        timestamp: ISO 8601 timestamp
        latency_ms: Time since trace start
        data: Event-specific data
    """
    event_type: TraceEventType
    timestamp: str
    latency_ms: float
    data: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["event_type"] = self.event_type.value
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TraceEvent":
        data = dict(data)
        data["event_type"] = TraceEventType(data["event_type"])
        return cls(**data)


@dataclass
class RetrievedDocument:
    """
    A document retrieved during a trace

    Attributes:
        memory_id: Document ID
        content_preview: First N characters of content
        score: Similarity/relevance score
        rank: Position in results (1-indexed)
        metadata: Document metadata
        included: Whether it was included in final results
        exclusion_reason: Why it was excluded (if applicable)
    """
    memory_id: str
    content_preview: str
    score: float
    rank: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    included: bool = True
    exclusion_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RetrievedDocument":
        return cls(**data)


@dataclass
class RetrievalTrace:
    """
    Complete trace of a retrieval operation

    Attributes:
        trace_id: Unique trace identifier
        query_text: Original query
        query_hash: SHA-256 hash of query
        start_time: When trace started
        end_time: When trace completed
        total_latency_ms: Total retrieval time
        events: Timeline of events
        retrieved_documents: All documents considered
        final_results: IDs of documents returned
        filters_applied: Filters used in query
        top_k_requested: Number of results requested
        embedding_model: Model used for embeddings
        error: Error message if failed
        metadata: Additional trace metadata
    """
    trace_id: str
    query_text: str
    query_hash: str
    start_time: str
    end_time: Optional[str] = None
    total_latency_ms: Optional[float] = None
    events: List[TraceEvent] = field(default_factory=list)
    retrieved_documents: List[RetrievedDocument] = field(default_factory=list)
    final_results: List[str] = field(default_factory=list)
    filters_applied: Optional[Dict[str, Any]] = None
    top_k_requested: int = 5
    embedding_model: Optional[str] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["events"] = [e.to_dict() if isinstance(e, TraceEvent) else e for e in self.events]
        d["retrieved_documents"] = [
            r.to_dict() if isinstance(r, RetrievedDocument) else r
            for r in self.retrieved_documents
        ]
        return d

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RetrievalTrace":
        data = dict(data)
        data["events"] = [
            TraceEvent.from_dict(e) if isinstance(e, dict) else e
            for e in data.get("events", [])
        ]
        data["retrieved_documents"] = [
            RetrievedDocument.from_dict(r) if isinstance(r, dict) else r
            for r in data.get("retrieved_documents", [])
        ]
        return cls(**data)

    @classmethod
    def from_json(cls, json_str: str) -> "RetrievalTrace":
        return cls.from_dict(json.loads(json_str))


class RetrievalTracer:
    """
    Full observability for RAG retrievals

    Records everything about a retrieval:
    - Query text and hash
    - Timing at each stage
    - All documents considered
    - Scores and rankings
    - Why documents were included/excluded
    - Final results

    Example:
        tracer = RetrievalTracer(memory_client)

        # Simple usage
        results = tracer.traced_query("What is the policy?", top_k=5)
        trace = tracer.get_latest_trace()
        print(trace.to_json())

        # Detailed usage
        trace_id = tracer.start_trace("What is the policy?")
        tracer.record_event(trace_id, TraceEventType.CUSTOM, {"note": "starting"})
        results = client.query("What is the policy?")
        tracer.record_results(trace_id, results)
        tracer.complete_trace(trace_id)

        # Analysis
        analysis = tracer.analyze_trace(trace_id)
        print(f"P95 latency: {analysis['latency_p95_ms']}ms")
    """

    def __init__(
        self,
        memory_client,
        content_preview_length: int = 100,
        max_traces: int = 1000,
        audit_log: Optional["AuditLog"] = None
    ):
        """
        Initialize tracer

        Args:
            memory_client: MemoryClient instance
            content_preview_length: Characters to include in content preview
            max_traces: Maximum traces to keep in memory
            audit_log: Optional AuditLog to link traces
        """
        self._client = memory_client
        self._preview_length = content_preview_length
        self._max_traces = max_traces
        self._audit = audit_log

        self._traces: Dict[str, RetrievalTrace] = {}
        self._trace_order: List[str] = []  # For LRU eviction
        self._start_times: Dict[str, float] = {}

    def start_trace(
        self,
        query_text: str,
        filters: Optional[Dict[str, Any]] = None,
        top_k: int = 5,
        metadata: Optional[Dict[str, Any]] = None
    ) -> RetrievalTrace:
        """
        Start a new retrieval trace

        Args:
            query_text: The query text
            filters: Filters to apply
            top_k: Number of results requested
            metadata: Additional trace metadata

        Returns:
            The new RetrievalTrace
        """
        import hashlib

        trace_id = f"trace_{uuid.uuid4().hex[:16]}"
        now = datetime.now(timezone.utc)
        start_time = time.time()

        trace = RetrievalTrace(
            trace_id=trace_id,
            query_text=query_text,
            query_hash="sha256:" + hashlib.sha256(query_text.encode()).hexdigest(),
            start_time=now.isoformat(),
            filters_applied=filters,
            top_k_requested=top_k,
            metadata=metadata or {}
        )

        # Record start event
        trace.events.append(TraceEvent(
            event_type=TraceEventType.QUERY_START,
            timestamp=now.isoformat(),
            latency_ms=0,
            data={"query_length": len(query_text), "filters": filters, "top_k": top_k}
        ))

        # Store trace
        self._traces[trace_id] = trace
        self._trace_order.append(trace_id)
        self._start_times[trace_id] = start_time

        # Evict old traces if needed
        self._evict_if_needed()

        return trace

    def _evict_if_needed(self) -> None:
        """Evict oldest traces if over limit"""
        while len(self._traces) > self._max_traces:
            oldest_id = self._trace_order.pop(0)
            del self._traces[oldest_id]
            self._start_times.pop(oldest_id, None)

    def record_event(
        self,
        trace_id: str,
        event_type: TraceEventType,
        data: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Record an event in a trace

        Args:
            trace_id: Trace ID
            event_type: Type of event
            data: Event data
        """
        if trace_id not in self._traces:
            return

        trace = self._traces[trace_id]
        now = datetime.now(timezone.utc)
        latency = (time.time() - self._start_times[trace_id]) * 1000

        trace.events.append(TraceEvent(
            event_type=event_type,
            timestamp=now.isoformat(),
            latency_ms=latency,
            data=data or {}
        ))

    def record_embedding(
        self,
        trace_id: str,
        model: str,
        latency_ms: float
    ) -> None:
        """Record embedding generation"""
        if trace_id not in self._traces:
            return

        trace = self._traces[trace_id]
        trace.embedding_model = model

        self.record_event(trace_id, TraceEventType.EMBEDDING_COMPLETE, {
            "model": model,
            "embedding_latency_ms": latency_ms
        })

    def record_search(
        self,
        trace_id: str,
        candidates_count: int,
        latency_ms: float
    ) -> None:
        """Record vector search"""
        self.record_event(trace_id, TraceEventType.SEARCH_COMPLETE, {
            "candidates_count": candidates_count,
            "search_latency_ms": latency_ms
        })

    def _to_dict(self, result: Any) -> Dict[str, Any]:
        """Convert result to dict, handling both dicts and dataclasses"""
        if isinstance(result, dict):
            return result
        # Handle dataclass (RetrievalResult)
        if hasattr(result, '__dataclass_fields__'):
            from dataclasses import asdict
            return asdict(result)
        # Handle object with __dict__
        if hasattr(result, '__dict__'):
            return vars(result)
        # Fallback: try to extract common attributes
        return {
            "id": getattr(result, "id", None),
            "content": getattr(result, "content", ""),
            "score": getattr(result, "score", 0.0),
            "metadata": getattr(result, "metadata", {}),
        }

    def _get_id(self, result: Any) -> str:
        """Extract ID from result (dict or dataclass)"""
        if isinstance(result, dict):
            return result.get("id") or result.get("memory_id", "unknown")
        return getattr(result, "id", None) or getattr(result, "memory_id", "unknown")

    def record_results(
        self,
        trace_id: str,
        results: List[Any],
        all_candidates: Optional[List[Any]] = None
    ) -> None:
        """
        Record retrieval results

        Args:
            trace_id: Trace ID
            results: Final results returned (dicts or RetrievalResult dataclasses)
            all_candidates: All candidates considered (including excluded)
        """
        if trace_id not in self._traces:
            return

        trace = self._traces[trace_id]

        # Convert results to dicts for uniform handling
        results_as_dicts = [self._to_dict(r) for r in results]
        result_ids = {d.get("id") or d.get("memory_id") for d in results_as_dicts}

        # Record all candidates if provided
        candidates = all_candidates if all_candidates else results
        for i, doc in enumerate(candidates):
            doc_dict = self._to_dict(doc)
            memory_id = doc_dict.get("id") or doc_dict.get("memory_id", f"unknown_{i}")
            content = doc_dict.get("content", "")
            score = doc_dict.get("score", doc_dict.get("similarity", 0.0))

            # Check if included in final results
            included = memory_id in result_ids

            retrieved = RetrievedDocument(
                memory_id=memory_id,
                content_preview=content[:self._preview_length] + ("..." if len(content) > self._preview_length else ""),
                score=score,
                rank=i + 1,
                metadata=doc_dict.get("metadata") or {},
                included=included,
                exclusion_reason=None if included else "Below top_k threshold"
            )

            trace.retrieved_documents.append(retrieved)

            # Record event for each result
            event_type = TraceEventType.RESULT_SELECTED if included else TraceEventType.RESULT_EXCLUDED
            self.record_event(trace_id, event_type, {
                "memory_id": memory_id,
                "score": score,
                "rank": i + 1
            })

        # Store final result IDs
        trace.final_results = [
            d.get("id") or d.get("memory_id")
            for d in results_as_dicts
        ]

    def record_error(self, trace_id: str, error: str) -> None:
        """Record an error"""
        if trace_id not in self._traces:
            return

        trace = self._traces[trace_id]
        trace.error = error

        self.record_event(trace_id, TraceEventType.ERROR, {"error": error})

    def complete_trace(self, trace_id: str) -> Optional[RetrievalTrace]:
        """
        Complete a trace

        Args:
            trace_id: Trace ID

        Returns:
            Completed trace or None if not found
        """
        if trace_id not in self._traces:
            return None

        trace = self._traces[trace_id]
        now = datetime.now(timezone.utc)

        trace.end_time = now.isoformat()
        trace.total_latency_ms = (time.time() - self._start_times[trace_id]) * 1000

        self.record_event(trace_id, TraceEventType.QUERY_COMPLETE, {
            "result_count": len(trace.final_results),
            "total_latency_ms": trace.total_latency_ms
        })

        # Link to audit log if available
        if self._audit is not None:
            from .audit_log import OperationType
            self._audit.log_query(
                query_text=trace.query_text,
                retrieved_ids=trace.final_results,
                trace_id=trace_id
            )

        return trace

    def traced_query(
        self,
        query_text: str,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Perform a query with full tracing

        This is a convenience method that wraps the entire query process.

        Args:
            query_text: Query text
            top_k: Number of results
            filters: Metadata filters
            metadata: Trace metadata

        Returns:
            Query results as dicts (with trace_id added)
        """
        # Start trace
        trace = self.start_trace(query_text, filters=filters, top_k=top_k, metadata=metadata)

        try:
            # Record embedding start
            self.record_event(trace.trace_id, TraceEventType.EMBEDDING_START, {})

            # Perform query
            embed_start = time.time()
            self.record_event(trace.trace_id, TraceEventType.SEARCH_START, {})

            results = self._client.query(query_text, top_k=top_k, filters=filters)

            search_time = (time.time() - embed_start) * 1000
            self.record_search(trace.trace_id, len(results), search_time)

            # Record results
            self.record_results(trace.trace_id, results)

            # Complete trace
            self.complete_trace(trace.trace_id)

            # Convert results to dicts and add trace_id
            results_as_dicts = [self._to_dict(r) for r in results]
            for r in results_as_dicts:
                r["trace_id"] = trace.trace_id

            return results_as_dicts

        except Exception as e:
            self.record_error(trace.trace_id, str(e))
            self.complete_trace(trace.trace_id)
            raise

    def get_trace(self, trace_id: str) -> Optional[RetrievalTrace]:
        """Get a trace by ID"""
        return self._traces.get(trace_id)

    def get_latest_trace(self) -> Optional[RetrievalTrace]:
        """Get the most recent trace"""
        if not self._trace_order:
            return None
        return self._traces.get(self._trace_order[-1])

    def list_traces(
        self,
        limit: int = 100,
        query_contains: Optional[str] = None
    ) -> List[RetrievalTrace]:
        """
        List traces

        Args:
            limit: Maximum traces to return
            query_contains: Filter by query text containing this string

        Returns:
            List of traces (newest first)
        """
        traces = []
        for trace_id in reversed(self._trace_order):
            trace = self._traces.get(trace_id)
            if not trace:
                continue

            if query_contains and query_contains.lower() not in trace.query_text.lower():
                continue

            traces.append(trace)
            if len(traces) >= limit:
                break

        return traces

    def analyze_trace(self, trace_id: str) -> Optional[Dict[str, Any]]:
        """
        Analyze a trace for debugging

        Returns detailed analysis including:
        - Latency breakdown
        - Score distribution
        - Filter effectiveness
        - Potential issues

        Args:
            trace_id: Trace ID

        Returns:
            Analysis dict or None if trace not found
        """
        trace = self.get_trace(trace_id)
        if not trace:
            return None

        # Basic stats
        analysis = {
            "trace_id": trace_id,
            "query_text": trace.query_text,
            "total_latency_ms": trace.total_latency_ms,
            "result_count": len(trace.final_results),
            "candidates_considered": len(trace.retrieved_documents),
            "filters_applied": trace.filters_applied,
            "had_error": trace.error is not None
        }

        # Score analysis
        scores = [doc.score for doc in trace.retrieved_documents]
        if scores:
            analysis["scores"] = {
                "min": min(scores),
                "max": max(scores),
                "mean": sum(scores) / len(scores),
                "top_score": scores[0] if scores else None
            }

            # Score distribution
            included_scores = [doc.score for doc in trace.retrieved_documents if doc.included]
            excluded_scores = [doc.score for doc in trace.retrieved_documents if not doc.included]

            if included_scores:
                analysis["included_score_range"] = (min(included_scores), max(included_scores))
            if excluded_scores:
                analysis["excluded_score_range"] = (min(excluded_scores), max(excluded_scores))

        # Latency breakdown
        latencies = {}
        for i, event in enumerate(trace.events):
            if event.event_type == TraceEventType.EMBEDDING_COMPLETE:
                latencies["embedding_ms"] = event.data.get("embedding_latency_ms", event.latency_ms)
            elif event.event_type == TraceEventType.SEARCH_COMPLETE:
                latencies["search_ms"] = event.data.get("search_latency_ms", event.latency_ms)

        analysis["latency_breakdown"] = latencies

        # Potential issues
        issues = []

        if trace.total_latency_ms and trace.total_latency_ms > 1000:
            issues.append("High latency (>1s)")

        if len(trace.final_results) < trace.top_k_requested:
            issues.append(f"Fewer results than requested ({len(trace.final_results)}/{trace.top_k_requested})")

        if scores and max(scores) < 0.3:
            issues.append("Low max similarity score - query may not match corpus well")

        if scores and len(scores) > 1:
            score_gap = scores[0] - scores[1] if len(scores) > 1 else 0
            if score_gap < 0.05:
                issues.append("Small gap between top scores - results may be ambiguous")

        analysis["potential_issues"] = issues

        return analysis

    def compare_traces(
        self,
        trace_id_1: str,
        trace_id_2: str
    ) -> Optional[Dict[str, Any]]:
        """
        Compare two traces

        Useful for A/B testing retrieval strategies.

        Args:
            trace_id_1: First trace ID
            trace_id_2: Second trace ID

        Returns:
            Comparison dict or None if traces not found
        """
        trace1 = self.get_trace(trace_id_1)
        trace2 = self.get_trace(trace_id_2)

        if not trace1 or not trace2:
            return None

        # Result overlap
        results1 = set(trace1.final_results)
        results2 = set(trace2.final_results)

        overlap = results1 & results2
        only_in_1 = results1 - results2
        only_in_2 = results2 - results1

        # Jaccard similarity
        jaccard = len(overlap) / len(results1 | results2) if results1 | results2 else 0

        return {
            "trace_1": {
                "trace_id": trace_id_1,
                "query": trace1.query_text,
                "result_count": len(results1),
                "latency_ms": trace1.total_latency_ms
            },
            "trace_2": {
                "trace_id": trace_id_2,
                "query": trace2.query_text,
                "result_count": len(results2),
                "latency_ms": trace2.total_latency_ms
            },
            "comparison": {
                "result_overlap": list(overlap),
                "only_in_trace_1": list(only_in_1),
                "only_in_trace_2": list(only_in_2),
                "jaccard_similarity": jaccard,
                "latency_diff_ms": (trace1.total_latency_ms or 0) - (trace2.total_latency_ms or 0)
            }
        }

    def export_trace(self, trace_id: str) -> Optional[str]:
        """Export trace as JSON"""
        trace = self.get_trace(trace_id)
        if trace:
            return trace.to_json()
        return None

    def export_all_traces(self) -> str:
        """Export all traces as JSON array"""
        traces = [self._traces[tid].to_dict() for tid in self._trace_order]
        return json.dumps(traces, indent=2)

    def clear_traces(self) -> None:
        """Clear all traces"""
        self._traces.clear()
        self._trace_order.clear()
        self._start_times.clear()


def create_retrieval_report(trace: RetrievalTrace) -> str:
    """
    Create a human-readable report from a trace

    Args:
        trace: RetrievalTrace to report on

    Returns:
        Formatted report string
    """
    lines = [
        "=" * 60,
        "RETRIEVAL TRACE REPORT",
        "=" * 60,
        f"Trace ID: {trace.trace_id}",
        f"Query: \"{trace.query_text}\"",
        f"Time: {trace.start_time}",
        f"Total Latency: {trace.total_latency_ms:.2f}ms" if trace.total_latency_ms else "Incomplete",
        "",
        "PARAMETERS:",
        f"  Top K Requested: {trace.top_k_requested}",
        f"  Filters: {trace.filters_applied or 'None'}",
        f"  Embedding Model: {trace.embedding_model or 'Default'}",
        "",
        "RESULTS:",
        f"  Documents Returned: {len(trace.final_results)}",
        f"  Candidates Considered: {len(trace.retrieved_documents)}",
        "",
    ]

    if trace.retrieved_documents:
        lines.append("TOP RETRIEVED DOCUMENTS:")
        for doc in trace.retrieved_documents[:10]:
            status = "INCLUDED" if doc.included else "excluded"
            lines.append(f"  [{doc.rank}] {doc.memory_id} (score: {doc.score:.4f}) - {status}")
            lines.append(f"      \"{doc.content_preview}\"")

    if trace.error:
        lines.extend(["", f"ERROR: {trace.error}"])

    lines.extend(["", "EVENT TIMELINE:"])
    for event in trace.events:
        lines.append(f"  +{event.latency_ms:.1f}ms: {event.event_type.value}")

    lines.append("=" * 60)

    return "\n".join(lines)
