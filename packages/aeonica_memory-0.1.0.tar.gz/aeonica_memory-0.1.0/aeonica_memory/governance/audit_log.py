"""
Append-Only Audit Log for Aeonica Memory

Every memory operation is logged with:
- Operation type (add, update, delete, query)
- Timestamp (ISO 8601)
- Memory ID(s) involved
- Content hash (for data integrity)
- State root (Merkle root at time of operation)
- Metadata hash

The log is append-only and tamper-evident via hash chaining.

Example:
    audit = AuditLog("./audit.jsonl")

    # Log an add operation
    entry = audit.log_add(
        memory_id="doc_1",
        content_hash="sha256:abc123...",
        metadata_hash="sha256:def456...",
        state_root="sha256:xyz789..."
    )

    # Verify log integrity
    is_valid = audit.verify_chain()

    # Get all operations for a memory
    history = audit.get_history("doc_1")

    # Get state at timestamp
    state = audit.get_state_at("2025-03-15T10:00:00Z")
"""

import json
import hashlib
import time
from datetime import datetime, timezone
from dataclasses import dataclass, asdict, field
from enum import Enum
from typing import List, Optional, Dict, Any, Iterator
from pathlib import Path
import threading


class OperationType(str, Enum):
    """Types of memory operations"""
    ADD = "add"
    ADD_BATCH = "add_batch"
    UPDATE = "update"
    DELETE = "delete"
    DELETE_WITH_CERT = "delete_with_certificate"
    QUERY = "query"
    CLEAR = "clear"
    REBUILD_INDEX = "rebuild_index"
    SAVE = "save"
    LOAD = "load"


@dataclass
class AuditEntry:
    """
    A single audit log entry

    Attributes:
        entry_id: Unique identifier for this entry
        timestamp: ISO 8601 timestamp
        operation: Type of operation
        memory_ids: List of memory IDs involved
        content_hash: SHA-256 hash of content (for adds/updates)
        metadata_hash: SHA-256 hash of metadata
        state_root: Merkle root of memory state after operation
        previous_hash: Hash of previous log entry (chain link)
        details: Additional operation-specific details
    """
    entry_id: str
    timestamp: str
    operation: OperationType
    memory_ids: List[str]
    content_hash: Optional[str] = None
    metadata_hash: Optional[str] = None
    state_root: Optional[str] = None
    previous_hash: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        d = asdict(self)
        d["operation"] = self.operation.value
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditEntry":
        """Create from dictionary"""
        data = dict(data)  # Copy to avoid mutation
        data["operation"] = OperationType(data["operation"])
        return cls(**data)

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of this entry"""
        # Deterministic serialization
        data = {
            "entry_id": self.entry_id,
            "timestamp": self.timestamp,
            "operation": self.operation.value,
            "memory_ids": sorted(self.memory_ids),
            "content_hash": self.content_hash,
            "metadata_hash": self.metadata_hash,
            "state_root": self.state_root,
            "previous_hash": self.previous_hash,
        }
        json_str = json.dumps(data, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(json_str.encode()).hexdigest()


class AuditLog:
    """
    Append-only, tamper-evident audit log for memory operations

    Features:
    - Every operation logged with timestamp and hashes
    - Hash chain for tamper detection
    - Query history by memory ID or time range
    - Verify integrity of entire log

    Example:
        audit = AuditLog("./memory_audit.jsonl")

        # Operations are logged automatically when integrated with MemoryClient
        # Or log manually:
        entry = audit.log_operation(
            operation=OperationType.ADD,
            memory_ids=["doc_1"],
            content_hash=hash_content("..."),
            state_root=merkle_root
        )

        # Verify chain integrity
        if audit.verify_chain():
            print("Audit log is intact")

        # Get history for compliance
        history = audit.get_history("doc_1")
        for entry in history:
            print(f"{entry.timestamp}: {entry.operation.value}")
    """

    def __init__(self, log_path: Optional[str] = None, auto_flush: bool = True):
        """
        Initialize audit log

        Args:
            log_path: Path to audit log file (JSONL format). None for in-memory only.
            auto_flush: Whether to flush after each write (safer, slightly slower)
        """
        self.log_path = Path(log_path) if log_path else None
        self.auto_flush = auto_flush
        self._entries: List[AuditEntry] = []
        self._last_hash: Optional[str] = None
        self._entry_counter = 0
        self._lock = threading.Lock()

        # Load existing log if present
        if self.log_path and self.log_path.exists():
            self._load_existing()

    def _load_existing(self) -> None:
        """Load existing audit log from disk"""
        with open(self.log_path, "r") as f:
            for line in f:
                line = line.strip()
                if line:
                    data = json.loads(line)
                    entry = AuditEntry.from_dict(data)
                    self._entries.append(entry)
                    self._last_hash = entry.compute_hash()
                    # Extract counter from entry_id
                    try:
                        counter = int(entry.entry_id.split("_")[1])
                        self._entry_counter = max(self._entry_counter, counter + 1)
                    except (IndexError, ValueError):
                        self._entry_counter += 1

    def _generate_entry_id(self) -> str:
        """Generate unique entry ID"""
        entry_id = f"audit_{self._entry_counter:08d}"
        self._entry_counter += 1
        return entry_id

    def _get_timestamp(self) -> str:
        """Get current ISO 8601 timestamp"""
        return datetime.now(timezone.utc).isoformat()

    def log_operation(
        self,
        operation: OperationType,
        memory_ids: List[str],
        content_hash: Optional[str] = None,
        metadata_hash: Optional[str] = None,
        state_root: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ) -> AuditEntry:
        """
        Log an operation to the audit log

        Args:
            operation: Type of operation
            memory_ids: Memory IDs involved
            content_hash: Hash of content (for adds/updates)
            metadata_hash: Hash of metadata
            state_root: Merkle root after operation
            details: Additional details

        Returns:
            The created AuditEntry
        """
        with self._lock:
            entry = AuditEntry(
                entry_id=self._generate_entry_id(),
                timestamp=self._get_timestamp(),
                operation=operation,
                memory_ids=memory_ids,
                content_hash=content_hash,
                metadata_hash=metadata_hash,
                state_root=state_root,
                previous_hash=self._last_hash,
                details=details or {}
            )

            # Update chain
            self._last_hash = entry.compute_hash()
            self._entries.append(entry)

            # Persist
            if self.log_path:
                self._write_entry(entry)

            return entry

    def _write_entry(self, entry: AuditEntry) -> None:
        """Write entry to log file"""
        with open(self.log_path, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")
            if self.auto_flush:
                f.flush()

    # Convenience methods for specific operations

    def log_add(
        self,
        memory_id: str,
        content_hash: str,
        metadata_hash: Optional[str] = None,
        state_root: Optional[str] = None
    ) -> AuditEntry:
        """Log an add operation"""
        return self.log_operation(
            operation=OperationType.ADD,
            memory_ids=[memory_id],
            content_hash=content_hash,
            metadata_hash=metadata_hash,
            state_root=state_root
        )

    def log_add_batch(
        self,
        memory_ids: List[str],
        content_hashes: List[str],
        state_root: Optional[str] = None
    ) -> AuditEntry:
        """Log a batch add operation"""
        return self.log_operation(
            operation=OperationType.ADD_BATCH,
            memory_ids=memory_ids,
            state_root=state_root,
            details={"content_hashes": content_hashes, "count": len(memory_ids)}
        )

    def log_update(
        self,
        memory_id: str,
        old_content_hash: Optional[str],
        new_content_hash: Optional[str],
        state_root: Optional[str] = None
    ) -> AuditEntry:
        """Log an update operation"""
        return self.log_operation(
            operation=OperationType.UPDATE,
            memory_ids=[memory_id],
            content_hash=new_content_hash,
            state_root=state_root,
            details={"old_content_hash": old_content_hash}
        )

    def log_delete(
        self,
        memory_id: str,
        state_root: Optional[str] = None
    ) -> AuditEntry:
        """Log a delete operation"""
        return self.log_operation(
            operation=OperationType.DELETE,
            memory_ids=[memory_id],
            state_root=state_root
        )

    def log_query(
        self,
        query_text: str,
        retrieved_ids: List[str],
        trace_id: str,
        state_root: Optional[str] = None
    ) -> AuditEntry:
        """Log a query operation"""
        return self.log_operation(
            operation=OperationType.QUERY,
            memory_ids=retrieved_ids,
            state_root=state_root,
            details={
                "query_hash": "sha256:" + hashlib.sha256(query_text.encode()).hexdigest(),
                "trace_id": trace_id,
                "result_count": len(retrieved_ids)
            }
        )

    # Query methods

    def get_history(self, memory_id: str) -> List[AuditEntry]:
        """
        Get all operations involving a specific memory ID

        Args:
            memory_id: The memory ID to look up

        Returns:
            List of AuditEntry objects in chronological order
        """
        return [e for e in self._entries if memory_id in e.memory_ids]

    def get_entries_in_range(
        self,
        start: Optional[str] = None,
        end: Optional[str] = None
    ) -> List[AuditEntry]:
        """
        Get entries in a time range

        Args:
            start: ISO 8601 start timestamp (inclusive)
            end: ISO 8601 end timestamp (inclusive)

        Returns:
            List of AuditEntry objects
        """
        entries = []
        for entry in self._entries:
            if start and entry.timestamp < start:
                continue
            if end and entry.timestamp > end:
                continue
            entries.append(entry)
        return entries

    def get_state_root_at(self, timestamp: str) -> Optional[str]:
        """
        Get the state root at or before a specific timestamp

        Args:
            timestamp: ISO 8601 timestamp

        Returns:
            State root hash, or None if no entries before timestamp
        """
        state_root = None
        for entry in self._entries:
            if entry.timestamp > timestamp:
                break
            if entry.state_root:
                state_root = entry.state_root
        return state_root

    def get_entry_by_id(self, entry_id: str) -> Optional[AuditEntry]:
        """Get a specific entry by ID"""
        for entry in self._entries:
            if entry.entry_id == entry_id:
                return entry
        return None

    # Verification

    def verify_chain(self) -> bool:
        """
        Verify the integrity of the entire audit log

        Checks that each entry's previous_hash matches the computed hash
        of the previous entry, ensuring no tampering.

        Returns:
            True if chain is valid, False if tampering detected
        """
        if not self._entries:
            return True

        # First entry should have no previous hash
        if self._entries[0].previous_hash is not None:
            return False

        # Check chain
        for i in range(1, len(self._entries)):
            expected_hash = self._entries[i - 1].compute_hash()
            actual_hash = self._entries[i].previous_hash
            if expected_hash != actual_hash:
                return False

        return True

    def verify_entry(self, entry_id: str) -> bool:
        """
        Verify a specific entry is part of valid chain

        Args:
            entry_id: Entry ID to verify

        Returns:
            True if entry is valid and chain to it is intact
        """
        for i, entry in enumerate(self._entries):
            if entry.entry_id == entry_id:
                # Verify chain up to this entry
                return self._verify_chain_to(i)
        return False

    def _verify_chain_to(self, index: int) -> bool:
        """Verify chain up to and including index"""
        if index == 0:
            return self._entries[0].previous_hash is None

        for i in range(1, index + 1):
            expected_hash = self._entries[i - 1].compute_hash()
            if self._entries[i].previous_hash != expected_hash:
                return False
        return True

    # Properties

    @property
    def entry_count(self) -> int:
        """Number of entries in the log"""
        return len(self._entries)

    @property
    def last_entry(self) -> Optional[AuditEntry]:
        """Most recent entry"""
        return self._entries[-1] if self._entries else None

    @property
    def last_state_root(self) -> Optional[str]:
        """Most recent state root"""
        for entry in reversed(self._entries):
            if entry.state_root:
                return entry.state_root
        return None

    def __iter__(self) -> Iterator[AuditEntry]:
        """Iterate over all entries"""
        return iter(self._entries)

    def __len__(self) -> int:
        return len(self._entries)


def hash_content(content: str) -> str:
    """Helper: Compute SHA-256 hash of content"""
    return "sha256:" + hashlib.sha256(content.encode()).hexdigest()


def hash_metadata(metadata: Dict[str, Any]) -> str:
    """Helper: Compute SHA-256 hash of metadata"""
    json_str = json.dumps(metadata, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(json_str.encode()).hexdigest()
