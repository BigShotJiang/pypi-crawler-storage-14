"""
Aeonica Memory Governance Module

Provides audit logging, cryptographic proofs, and compliance features for regulated industries.

Features:
- Append-only audit log for all memory operations
- Merkle tree state proofs (prove what AI knew at any point in time)
- Compliant deletion with certificates (GDPR "right to be forgotten")
- Temporal memory with decay and importance scoring
- Full retrieval tracing for RAG debugging

Example:
    from aeonica_memory import MemoryClient
    from aeonica_memory.governance import AuditLog, StateProver, DeletionCertifier

    # Enable governance features
    client = MemoryClient(
        audit_log="./audit.jsonl",
        enable_proofs=True,
        temporal_mode=True
    )

    # All operations are logged and provable
    client.add("doc_1", "Patient history...", metadata={"category": "medical"})

    # Prove retrieval came from specific knowledge state
    results = client.query("patient symptoms")
    proof = client.prove_retrieval(results.trace_id)

    # Compliant deletion with certificate
    cert = client.delete_with_certificate("doc_1")
    # cert contains cryptographic proof of deletion
"""

from .audit_log import AuditLog, AuditEntry, OperationType, hash_content, hash_metadata
from .merkle import MerkleTree, StateProver, StateProof, InclusionProof
from .deletion import (
    DeletionCertifier,
    DeletionCertificate,
    BatchDeletionCertificate,
    verify_deletion_certificate_standalone
)
from .temporal import (
    TemporalMemory,
    TemporalMetadata,
    DecayFunction,
    ExponentialDecay,
    LinearDecay,
    StepDecay,
    NoDecay,
    ImportanceScorer
)
from .tracing import (
    RetrievalTracer,
    RetrievalTrace,
    TraceEvent,
    RetrievedDocument,
    TraceEventType,
    create_retrieval_report
)

__all__ = [
    # Audit
    "AuditLog",
    "AuditEntry",
    "OperationType",
    "hash_content",
    "hash_metadata",
    # Proofs
    "MerkleTree",
    "StateProver",
    "StateProof",
    "InclusionProof",
    # Deletion
    "DeletionCertifier",
    "DeletionCertificate",
    "BatchDeletionCertificate",
    "verify_deletion_certificate_standalone",
    # Temporal
    "TemporalMemory",
    "TemporalMetadata",
    "DecayFunction",
    "ExponentialDecay",
    "LinearDecay",
    "StepDecay",
    "NoDecay",
    "ImportanceScorer",
    # Tracing
    "RetrievalTracer",
    "RetrievalTrace",
    "TraceEvent",
    "RetrievedDocument",
    "TraceEventType",
    "create_retrieval_report",
]
