#!/usr/bin/env python3
"""
Aeonica Memory - Governed AI Memory Demo
=========================================

Run this to see what makes Aeonica different from Pinecone/Chroma/FAISS:
  - Audit trail for every operation
  - Merkle proofs (prove what AI knew when)
  - GDPR-compliant deletion with certificates
  - Temporal memory (decay, importance)
  - RAG retrieval tracing

Usage:
    pip install aeonica-memory
    python demo_governed_memory.py

~60 seconds to run the full demo.
"""

import time

print("=" * 70)
print("AEONICA MEMORY - Governed AI Memory Demo")
print("=" * 70)
print()

# ============================================================================
# 1. Basic Memory Operations
# ============================================================================

print("[1/5] BASIC MEMORY OPERATIONS")
print("-" * 40)

from aeonica_memory import MemoryClient

client = MemoryClient(explainability=True)

# Add some memories
client.add("policy_001", "Employees get 20 days PTO per year", {"type": "hr", "year": 2024})
client.add("policy_002", "Remote work is allowed 3 days per week", {"type": "hr", "year": 2024})
client.add("policy_003", "Health insurance covers 80% of costs", {"type": "benefits", "year": 2024})
client.add("incident_001", "Server outage on 2024-03-15, resolved in 2 hours", {"type": "incident"})

print(f"  Added {len(client)} memories")

# Query with explainability
results = client.query("What is the vacation policy?", top_k=2)
print(f"\n  Query: 'What is the vacation policy?'")
for r in results:
    print(f"    [{r.score:.3f}] {r.content[:60]}...")
    if r.explanation:
        print(f"            Reason: {r.explanation[:50]}...")

print()

# ============================================================================
# 2. Audit Trail
# ============================================================================

print("[2/5] AUDIT TRAIL (tamper-evident)")
print("-" * 40)

from aeonica_memory.governance import AuditLog, OperationType

audit = AuditLog()  # In production: AuditLog("./aeonica_audit.jsonl")

# Log operations
audit.log_add("policy_001", content_hash="sha256:abc123")
audit.log_add("policy_002", content_hash="sha256:def456")
audit.log_query("vacation policy", retrieved_ids=["policy_001"], trace_id="trace_001")
audit.log_delete("policy_002")

print(f"  Logged {audit.entry_count} operations")
print(f"  Chain intact: {audit.verify_chain()}")

# Show recent entries
print("\n  Recent audit entries:")
for entry in list(audit)[-3:]:
    print(f"    {entry.timestamp[:19]} | {entry.operation.value:12} | {entry.memory_ids}")

print()

# ============================================================================
# 3. Merkle State Proofs
# ============================================================================

print("[3/5] MERKLE STATE PROOFS")
print("-" * 40)

from aeonica_memory.governance import StateProver, MerkleTree

prover = StateProver(client)

# Compute state root
root = prover.compute_state_root()
print(f"  Current state root: {root[:40]}...")

# Generate inclusion proof
proof = prover.prove_inclusion("policy_001")
if proof:
    print(f"\n  Inclusion proof for 'policy_001':")
    print(f"    Memory hash: {proof.memory_hash[:40]}...")
    print(f"    Proof path length: {len(proof.proof_path)} nodes")

    # Verify (anyone can do this without accessing the data)
    verified = MerkleTree.verify_inclusion_proof(proof)
    print(f"    Verification: {'VALID' if verified else 'INVALID'}")

print()

# ============================================================================
# 4. GDPR-Compliant Deletion with Certificate
# ============================================================================

print("[4/5] GDPR-COMPLIANT DELETION")
print("-" * 40)

from aeonica_memory.governance import DeletionCertifier

# Add user data
client.add("user_123_profile", "John Doe, john@example.com, preferences...", {"user_id": "123"})
print(f"  Added user data: 'user_123_profile'")

# User requests deletion (GDPR Article 17)
certifier = DeletionCertifier(client, audit_log=audit, state_prover=prover)
cert = certifier.delete_with_certificate(
    "user_123_profile",
    reason="GDPR Article 17 request",
    rebuild_index=True  # Eliminates semantic residue from FAISS
)

if cert:
    print(f"\n  Deletion certificate generated:")
    print(f"    Certificate ID: {cert.certificate_id}")
    print(f"    Pre-state root:  {cert.pre_state_root[:40]}...")
    print(f"    Post-state root: {cert.post_state_root[:40]}...")
    print(f"    Content hash:    {cert.content_hash[:40]}...")
    print(f"    Index rebuilt:   {cert.index_rebuilt}")

    # Verify memory is gone
    print(f"\n  Memory exists after deletion: {client.get('user_123_profile') is not None}")

print()

# ============================================================================
# 5. Temporal Memory & RAG Tracing
# ============================================================================

print("[5/5] TEMPORAL MEMORY & RAG TRACING")
print("-" * 40)

from aeonica_memory.governance import TemporalMemory, ExponentialDecay, RetrievalTracer

# Temporal memory with decay
temporal = TemporalMemory(
    client,
    decay_function=ExponentialDecay(half_life_days=30),
    auto_track_access=False
)

# Add with importance scores
temporal.add("critical_policy", "Emergency procedures must be followed", importance=0.95)
temporal.add("routine_notice", "Coffee machine is in the break room", importance=0.2)

# Query with temporal scoring
results = temporal.query("emergency procedures", top_k=2, temporal_weight=0.3)
print(f"  Temporal query results:")
for r in results:
    print(f"    [{r['combined_score']:.3f}] {r['content'][:40]}...")
    print(f"            Semantic: {r['semantic_score']:.3f}, Temporal: {r['temporal_score']:.3f}")

# RAG Tracing
tracer = RetrievalTracer(client)
traced_results = tracer.traced_query("What are the HR policies?", top_k=3)

trace = tracer.get_latest_trace()
analysis = tracer.analyze_trace(trace.trace_id)

print(f"\n  RAG Trace Analysis:")
print(f"    Trace ID:     {trace.trace_id}")
print(f"    Total latency: {trace.total_latency_ms:.1f}ms")
print(f"    Results:      {analysis['result_count']}")
print(f"    Score range:  {analysis['scores']['min']:.3f} - {analysis['scores']['max']:.3f}")
if analysis['potential_issues']:
    print(f"    Issues:       {', '.join(analysis['potential_issues'])}")

print()

# ============================================================================
# Summary
# ============================================================================

print("=" * 70)
print("SUMMARY: What Aeonica gives you that others don't")
print("=" * 70)
print("""
  1. AUDIT TRAIL     - Every memory operation logged with hash chains
  2. STATE PROOFS    - Merkle trees prove "what the AI knew when"
  3. GDPR DELETION   - Cryptographic certificates for compliance
  4. TEMPORAL MEMORY - Decay, importance, expiration built-in
  5. RAG TRACING     - Debug why retrievals succeed or fail

  All in ONE library: pip install aeonica-memory

  GitHub:  https://github.com/aeonica-labs/aeonica-memory
  PyPI:    https://pypi.org/project/aeonica-memory/
""")
