"""
LangChain Integration for Aeonica Memory

Provides:
- AeonicaVectorStore: Drop-in replacement for Chroma/FAISS/Pinecone
- AeonicaRetriever: LangChain Retriever interface

Usage:
    from aeonica_memory.integrations.langchain import AeonicaVectorStore

    # Create vector store
    vectorstore = AeonicaVectorStore()

    # Add documents
    vectorstore.add_texts(["doc1", "doc2"], metadatas=[{"source": "a"}, {"source": "b"}])

    # Search
    results = vectorstore.similarity_search("query", k=5)

    # Use as retriever in chain
    retriever = vectorstore.as_retriever()
    chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
"""

from typing import Any, Dict, Iterable, List, Optional, Tuple, Type
import uuid

# Core Aeonica
from ..memory.memory_client import MemoryClient, RetrievalResult

# LangChain imports - try multiple versions for compatibility
try:
    # LangChain >= 0.1
    from langchain_core.documents import Document
    from langchain_core.vectorstores import VectorStore
    from langchain_core.retrievers import BaseRetriever
    from langchain_core.callbacks import CallbackManagerForRetrieverRun
    LANGCHAIN_AVAILABLE = True
    LANGCHAIN_VERSION = "core"
except ImportError:
    try:
        # LangChain < 0.1
        from langchain.schema import Document
        from langchain.vectorstores.base import VectorStore
        from langchain.retrievers import BaseRetriever
        from langchain.callbacks.manager import CallbackManagerForRetrieverRun
        LANGCHAIN_AVAILABLE = True
        LANGCHAIN_VERSION = "legacy"
    except ImportError:
        LANGCHAIN_AVAILABLE = False
        LANGCHAIN_VERSION = None
        # Create dummy classes for import to succeed
        class Document:
            def __init__(self, page_content: str = "", metadata: dict = None):
                self.page_content = page_content
                self.metadata = metadata or {}

        class VectorStore:
            pass

        class BaseRetriever:
            pass

        CallbackManagerForRetrieverRun = None


class AeonicaVectorStore(VectorStore if LANGCHAIN_AVAILABLE else object):
    """
    LangChain VectorStore implementation backed by Aeonica Memory

    Drop-in replacement for Chroma, FAISS, Pinecone with added explainability.

    Example:
        from langchain.chains import RetrievalQA
        from langchain.llms import OpenAI
        from aeonica_memory.integrations.langchain import AeonicaVectorStore

        # Create vector store
        vectorstore = AeonicaVectorStore()

        # Add documents
        texts = ["Python uses indentation", "JavaScript uses braces"]
        vectorstore.add_texts(texts, metadatas=[{"lang": "python"}, {"lang": "js"}])

        # Use in chain
        qa = RetrievalQA.from_chain_type(
            llm=OpenAI(),
            retriever=vectorstore.as_retriever()
        )
        result = qa.run("How does Python structure code?")
    """

    def __init__(
        self,
        client: Optional[MemoryClient] = None,
        explainability: bool = True,
        embedding_model: str = "all-MiniLM-L6-v2",
        storage_path: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize Aeonica VectorStore

        Args:
            client: Existing MemoryClient (creates new one if None)
            explainability: Enable explainability features
            embedding_model: Sentence transformer model name
            storage_path: Path for persistence
        """
        if not LANGCHAIN_AVAILABLE:
            raise ImportError(
                "LangChain not installed. Install with:\n"
                "  pip install langchain-core\n"
                "or:\n"
                "  pip install langchain"
            )

        self._client = client or MemoryClient(
            explainability=explainability,
            embedding_model=embedding_model,
            storage_path=storage_path
        )
        self._explainability = explainability

    @property
    def embeddings(self) -> Any:
        """Return embeddings model (required by some LangChain code)"""
        return self._client.retriever.embedder

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[dict]] = None,
        ids: Optional[List[str]] = None,
        **kwargs: Any
    ) -> List[str]:
        """
        Add texts to the vector store

        Args:
            texts: Texts to add
            metadatas: Optional list of metadata dicts
            ids: Optional list of IDs (generated if not provided)

        Returns:
            List of IDs of added documents
        """
        texts_list = list(texts)
        n = len(texts_list)

        # Generate IDs if not provided
        if ids is None:
            ids = [str(uuid.uuid4()) for _ in range(n)]

        # Handle metadatas
        if metadatas is None:
            metadatas = [{} for _ in range(n)]

        # Build batch
        batch = list(zip(ids, texts_list, metadatas))

        # Add to Aeonica
        self._client.add_batch(batch)

        return ids

    def add_documents(
        self,
        documents: List[Document],
        ids: Optional[List[str]] = None,
        **kwargs: Any
    ) -> List[str]:
        """
        Add LangChain Documents to the vector store

        Args:
            documents: List of Document objects
            ids: Optional list of IDs

        Returns:
            List of IDs of added documents
        """
        texts = [doc.page_content for doc in documents]
        metadatas = [doc.metadata for doc in documents]
        return self.add_texts(texts, metadatas=metadatas, ids=ids, **kwargs)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> List[Document]:
        """
        Search for documents similar to query

        Args:
            query: Search query
            k: Number of results
            filter: Metadata filter dict

        Returns:
            List of Document objects
        """
        results = self._client.query(
            query,
            top_k=k,
            explain=self._explainability,
            filters=filter
        )

        documents = []
        for r in results:
            # Add explainability to metadata
            metadata = dict(r.metadata) if r.metadata else {}
            if self._explainability:
                metadata["_aeonica_score"] = r.score
                metadata["_aeonica_confidence"] = r.confidence_depth
                metadata["_aeonica_schema"] = r.schema_label
                metadata["_aeonica_explanation"] = r.explanation

            documents.append(Document(
                page_content=r.content,
                metadata=metadata
            ))

        return documents

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> List[Tuple[Document, float]]:
        """
        Search with similarity scores

        Args:
            query: Search query
            k: Number of results
            filter: Metadata filter

        Returns:
            List of (Document, score) tuples
        """
        results = self._client.query(
            query,
            top_k=k,
            explain=self._explainability,
            filters=filter
        )

        docs_with_scores = []
        for r in results:
            metadata = dict(r.metadata) if r.metadata else {}
            if self._explainability:
                metadata["_aeonica_confidence"] = r.confidence_depth
                metadata["_aeonica_schema"] = r.schema_label
                metadata["_aeonica_explanation"] = r.explanation

            doc = Document(page_content=r.content, metadata=metadata)
            docs_with_scores.append((doc, r.score))

        return docs_with_scores

    def similarity_search_with_relevance_scores(
        self,
        query: str,
        k: int = 4,
        **kwargs: Any
    ) -> List[Tuple[Document, float]]:
        """Alias for similarity_search_with_score"""
        return self.similarity_search_with_score(query, k, **kwargs)

    def max_marginal_relevance_search(
        self,
        query: str,
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any
    ) -> List[Document]:
        """
        MMR search for diversity

        Note: Basic implementation - fetches more and deduplicates.
        Full MMR would require embedding access.
        """
        # For now, just return regular search
        # TODO: Implement proper MMR with embedding reranking
        return self.similarity_search(query, k=k, filter=filter, **kwargs)

    def delete(self, ids: Optional[List[str]] = None, **kwargs: Any) -> Optional[bool]:
        """
        Delete documents by ID

        Args:
            ids: List of document IDs to delete

        Returns:
            True if successful
        """
        if ids is None:
            return False

        for doc_id in ids:
            self._client.delete(doc_id)

        return True

    @classmethod
    def from_texts(
        cls,
        texts: List[str],
        embedding: Any = None,  # Ignored - Aeonica uses its own embeddings
        metadatas: Optional[List[dict]] = None,
        ids: Optional[List[str]] = None,
        **kwargs: Any
    ) -> "AeonicaVectorStore":
        """
        Create vector store from texts

        Args:
            texts: List of texts
            embedding: Ignored (Aeonica uses built-in embeddings)
            metadatas: Optional metadata list
            ids: Optional ID list

        Returns:
            AeonicaVectorStore instance
        """
        store = cls(**kwargs)
        store.add_texts(texts, metadatas=metadatas, ids=ids)
        return store

    @classmethod
    def from_documents(
        cls,
        documents: List[Document],
        embedding: Any = None,
        ids: Optional[List[str]] = None,
        **kwargs: Any
    ) -> "AeonicaVectorStore":
        """
        Create vector store from Documents

        Args:
            documents: List of Document objects
            embedding: Ignored
            ids: Optional ID list

        Returns:
            AeonicaVectorStore instance
        """
        store = cls(**kwargs)
        store.add_documents(documents, ids=ids)
        return store

    def as_retriever(self, **kwargs: Any) -> "AeonicaRetriever":
        """
        Return as a LangChain Retriever

        Args:
            **kwargs: Passed to retriever (search_kwargs, etc.)

        Returns:
            AeonicaRetriever instance
        """
        search_kwargs = kwargs.get("search_kwargs", {})
        return AeonicaRetriever(
            vectorstore=self,
            search_kwargs=search_kwargs
        )

    def save_local(self, path: str) -> None:
        """Save to local disk"""
        self._client.save(path)

    @classmethod
    def load_local(cls, path: str, **kwargs: Any) -> "AeonicaVectorStore":
        """Load from local disk"""
        store = cls(**kwargs)
        store._client.load(path)
        return store


class AeonicaRetriever(BaseRetriever if LANGCHAIN_AVAILABLE else object):
    """
    LangChain Retriever backed by Aeonica Memory

    Use this in LangChain chains:
        retriever = AeonicaRetriever(vectorstore=vectorstore)
        chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)
    """

    vectorstore: AeonicaVectorStore = None
    search_kwargs: dict = {}

    class Config:
        arbitrary_types_allowed = True

    def __init__(
        self,
        vectorstore: AeonicaVectorStore,
        search_kwargs: Optional[dict] = None,
        **kwargs
    ):
        """
        Initialize retriever

        Args:
            vectorstore: AeonicaVectorStore instance
            search_kwargs: Arguments passed to similarity_search (k, filter, etc.)
        """
        if LANGCHAIN_AVAILABLE:
            super().__init__(**kwargs)

        self.vectorstore = vectorstore
        self.search_kwargs = search_kwargs or {}

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """
        Get documents relevant to query

        Args:
            query: Search query
            run_manager: Callback manager (optional)

        Returns:
            List of relevant Documents
        """
        return self.vectorstore.similarity_search(query, **self.search_kwargs)

    async def _aget_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """Async version (currently just calls sync)"""
        return self._get_relevant_documents(query, run_manager=run_manager)


# Convenience function
def create_aeonica_vectorstore(
    texts: Optional[List[str]] = None,
    metadatas: Optional[List[dict]] = None,
    explainability: bool = True,
    **kwargs
) -> AeonicaVectorStore:
    """
    Convenience function to create an Aeonica vector store

    Args:
        texts: Optional texts to add immediately
        metadatas: Optional metadata for texts
        explainability: Enable explainability features

    Returns:
        AeonicaVectorStore instance

    Example:
        vectorstore = create_aeonica_vectorstore(
            texts=["doc1", "doc2"],
            metadatas=[{"source": "a"}, {"source": "b"}]
        )
    """
    store = AeonicaVectorStore(explainability=explainability, **kwargs)
    if texts:
        store.add_texts(texts, metadatas=metadatas)
    return store
