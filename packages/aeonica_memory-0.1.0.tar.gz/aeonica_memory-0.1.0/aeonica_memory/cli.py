"""
Aeonica Memory CLI

Commands:
    aeonica-memory playground    Launch local web playground
    aeonica-memory --version     Show version
"""

import sys
import argparse
from . import __version__


def main():
    """CLI entrypoint"""
    parser = argparse.ArgumentParser(
        description="Aeonica Memory - Fast, explainable FAISS-backed memory",
        prog="aeonica-memory"
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Playground command
    playground_parser = subparsers.add_parser(
        "playground",
        help="Launch local web playground for querying memories"
    )
    playground_parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to run playground on (default: 8000)"
    )
    playground_parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1)"
    )

    args = parser.parse_args()

    if args.command == "playground":
        launch_playground(host=args.host, port=args.port)
    elif args.command is None:
        parser.print_help()
        sys.exit(1)


def launch_playground(host: str = "127.0.0.1", port: int = 8000):
    """Launch the web playground"""
    try:
        from .playground import app
        import uvicorn
    except ImportError:
        print("⚠️  Playground dependencies not installed")
        print("   Install with: pip install 'aeonica-memory[playground]'")
        sys.exit(1)

    print("=" * 70)
    print("Aeonica Memory Playground")
    print("=" * 70)
    print()
    print(f"🚀 Starting playground at http://{host}:{port}")
    print("   Press Ctrl+C to stop")
    print()

    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
