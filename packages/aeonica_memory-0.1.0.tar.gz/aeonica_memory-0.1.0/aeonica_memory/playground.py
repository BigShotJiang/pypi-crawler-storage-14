"""
Aeonica Memory Playground - Simple web UI for demos

A minimal FastAPI app that lets you:
- Add memories
- Query with explainability
- See confidence, schemas, and reasoning
"""

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
import json

from aeonica_memory import MemoryClient

# Initialize FastAPI
app = FastAPI(title="Aeonica Memory Playground")

# Global memory client (in-memory for demo)
client = MemoryClient(backend="faiss", explainability=True)

# Add some demo memories by default
DEMO_MEMORIES = [
    ("py_1", "Python uses indentation for code blocks instead of braces"),
    ("py_2", "Python enforces indentation rules for code structure"),
    ("py_3", "Indentation in Python is syntactically significant"),
    ("js_1", "JavaScript uses curly braces to define code blocks"),
    ("js_2", "JavaScript code blocks are wrapped in curly braces"),
    ("auth_1", "OAuth 2.0 uses token-based authentication"),
    ("auth_2", "JWT tokens provide stateless authentication"),
    ("db_1", "SQL SELECT queries retrieve data from databases"),
]


@app.on_event("startup")
async def load_demo_memories():
    """Load demo memories on startup"""
    batch = [(mid, content, {}) for mid, content in DEMO_MEMORIES]
    client.add_batch(batch)
    print(f"✓ Loaded {len(DEMO_MEMORIES)} demo memories")


# API Models
class AddMemoryRequest(BaseModel):
    id: str
    content: str
    metadata: Optional[dict] = {}


class QueryRequest(BaseModel):
    query: str
    top_k: int = 5
    explain: bool = True


class QueryResult(BaseModel):
    id: str
    content: str
    score: float
    confidence_depth: Optional[str]
    schema_label: Optional[str]
    explanation: Optional[str]


# API Routes
@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the playground UI"""
    return HTML_TEMPLATE


@app.post("/api/add")
async def add_memory(req: AddMemoryRequest):
    """Add a memory"""
    client.add(req.id, req.content, req.metadata)
    return {"status": "success", "id": req.id}


@app.post("/api/query")
async def query_memories(req: QueryRequest) -> List[QueryResult]:
    """Query memories with explainability"""
    results = client.query(req.query, top_k=req.top_k, explain=req.explain)

    return [
        QueryResult(
            id=r.id,
            content=r.content,
            score=r.score,
            confidence_depth=r.confidence_depth,
            schema_label=r.schema_label,
            explanation=r.explanation
        )
        for r in results
    ]


@app.get("/api/stats")
async def get_stats():
    """Get memory statistics"""
    return client.get_stats()


# Simple HTML template (no external dependencies)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Aeonica Memory Playground</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: #667eea;
            font-size: 32px;
            margin-bottom: 10px;
        }
        .subtitle {
            color: #666;
            font-size: 16px;
        }
        .stats {
            background: rgba(255,255,255,0.1);
            padding: 10px 20px;
            border-radius: 5px;
            color: white;
            margin-top: 15px;
            display: inline-block;
        }
        .query-panel {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .input-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            color: #333;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 16px;
            font-family: inherit;
        }
        input[type="text"]:focus, textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        button {
            background: #667eea;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        button:hover {
            background: #764ba2;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .results {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .result-item {
            border-left: 4px solid #667eea;
            padding: 20px;
            margin-bottom: 20px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .result-id {
            font-weight: 700;
            color: #667eea;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .result-content {
            font-size: 16px;
            color: #333;
            margin-bottom: 10px;
        }
        .result-meta {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        .result-meta strong {
            color: #333;
        }
        .explanation {
            background: #fff;
            padding: 12px;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 14px;
            color: #555;
            border-left: 3px solid #764ba2;
        }
        .loading {
            text-align: center;
            padding: 40px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🧠 Aeonica Memory Playground</h1>
            <p class="subtitle">Fast, explainable FAISS-backed memory with confidence depth, schema detection, and natural language reasoning</p>
            <div class="stats" id="stats">Loading stats...</div>
        </div>

        <div class="query-panel">
            <div class="input-group">
                <label for="query">Query</label>
                <input
                    type="text"
                    id="query"
                    placeholder="How does Python structure code?"
                    value="How does Python structure code?"
                >
            </div>
            <div class="input-group">
                <label for="top_k">Results to return</label>
                <input type="text" id="top_k" value="5" style="width: 100px;">
            </div>
            <button onclick="runQuery()">Query Memories</button>
        </div>

        <div class="results" id="results">
            <p class="loading">Enter a query above to see results with explainability</p>
        </div>
    </div>

    <script>
        // Load stats on page load
        async function loadStats() {
            const response = await fetch('/api/stats');
            const stats = await response.json();
            document.getElementById('stats').innerHTML = `
                📊 ${stats.total_memories} memories |
                🎯 ${stats.total_schemas} schemas detected |
                📈 ${stats.avg_cluster_size.toFixed(1)} avg cluster size
            `;
        }

        // Run query
        async function runQuery() {
            const query = document.getElementById('query').value;
            const top_k = parseInt(document.getElementById('top_k').value);

            if (!query) {
                alert('Please enter a query');
                return;
            }

            // Show loading
            document.getElementById('results').innerHTML = '<p class="loading">Querying...</p>';

            // Query API
            const response = await fetch('/api/query', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({query, top_k, explain: true})
            });

            const results = await response.json();

            // Render results
            if (results.length === 0) {
                document.getElementById('results').innerHTML = '<p class="loading">No results found</p>';
                return;
            }

            let html = '<h2 style="margin-bottom: 20px;">Results</h2>';
            results.forEach((r, i) => {
                html += `
                    <div class="result-item">
                        <div class="result-id">[${i+1}] ${r.id}</div>
                        <div class="result-content">${r.content}</div>
                        <div class="result-meta"><strong>Score:</strong> ${r.score.toFixed(3)}</div>
                        ${r.confidence_depth ? `<div class="result-meta"><strong>Confidence:</strong> ${r.confidence_depth}</div>` : ''}
                        ${r.schema_label ? `<div class="result-meta"><strong>Schema:</strong> ${r.schema_label}</div>` : ''}
                        ${r.explanation ? `<div class="explanation"><strong>Why:</strong> ${r.explanation}</div>` : ''}
                    </div>
                `;
            });

            document.getElementById('results').innerHTML = html;

            // Refresh stats
            loadStats();
        }

        // Load stats on page load
        loadStats();

        // Allow Enter key to submit
        document.getElementById('query').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') runQuery();
        });
    </script>
</body>
</html>
"""
