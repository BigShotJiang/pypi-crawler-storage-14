"""
Setup script for velora-meta package
"""

from setuptools import setup, find_packages
import pathlib

HERE = pathlib.Path(__file__).parent
README = (HERE / "README.md").read_text()

setup(
    name="velora-meta",
    version="1.0.0",
    description="Meta-regime detection for adaptive trading strategies",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/VELORA/velora-meta",
    author="VELORA Development Team",
    author_email="dev@velora.ai",
    license="MIT",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="trading quantitative-finance meta-learning regime-detection algorithmic-trading",
    packages=find_packages(exclude=["tests", "experiments"]),
    python_requires=">=3.8",
    install_requires=[
        "torch>=1.10.0",
        "numpy>=1.20.0",
        "pandas>=1.3.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=22.0.0",
            "flake8>=4.0.0",
            "mypy>=0.950",
        ],
        "full": [
            "yfinance>=0.2.0",
            "matplotlib>=3.5.0",
            "seaborn>=0.12.0",
        ],
    },
    project_urls={
        "Bug Reports": "https://github.com/VELORA/velora-meta/issues",
        "Documentation": "https://github.com/VELORA/velora-meta/blob/main/VELORA_PROOF_BOOK.md",
        "Source": "https://github.com/VELORA/velora-meta",
    },
)
