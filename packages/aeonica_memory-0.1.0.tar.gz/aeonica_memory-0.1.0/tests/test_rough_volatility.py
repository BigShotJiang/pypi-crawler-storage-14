#!/usr/bin/env python3
"""
Test Suite: Rough Volatility Kalman Filter

Tests the RoughKalmanFilter for:
1. Rough volatility scaling (dt^(2H))
2. Comparison with standard Brownian (H=0.5)
3. Integration with KalmanFilterBank
4. Integration with EnhancedMultiAssetOracle

Author: AEONICA
Version: 1.0
"""

import sys
import unittest
import numpy as np
from datetime import datetime, timedelta

# Add path
sys.path.insert(0, '/Users/dindelinc/Desktop/VELORA_COGNITIION')

from aeonica_core.financial.oracle.rough_kalman_filter import RoughKalmanFilter
from aeonica_core.financial.oracle.kalman_filter import KalmanFilter1D, KalmanFilterBank


class TestRoughKalmanFilter(unittest.TestCase):
    """Test RoughKalmanFilter"""

    def test_initialization(self):
        """Test rough Kalman filter initialization"""
        rkf = RoughKalmanFilter(states=2, hurst_exponent=0.1)

        self.assertEqual(rkf.hurst, 0.1)
        self.assertIsNotNone(rkf.Q_base)
        self.assertEqual(len(rkf.dt_history), 0)
        self.assertEqual(len(rkf.scaling_history), 0)

    def test_invalid_hurst(self):
        """Test invalid Hurst exponent validation"""
        # H must be in (0, 0.5]
        with self.assertRaises(ValueError):
            RoughKalmanFilter(hurst_exponent=0.0)

        with self.assertRaises(ValueError):
            RoughKalmanFilter(hurst_exponent=0.6)

        with self.assertRaises(ValueError):
            RoughKalmanFilter(hurst_exponent=-0.1)

        # H=0.5 is valid (standard Brownian)
        rkf = RoughKalmanFilter(hurst_exponent=0.5)
        self.assertEqual(rkf.hurst, 0.5)

    def test_rough_scaling_formula(self):
        """Test rough volatility scaling formula: dt^(2H)"""
        rkf = RoughKalmanFilter(states=1, hurst_exponent=0.1)

        # Initialize
        rkf.initialize(1.0)

        # Predict with various dt values
        test_cases = [
            (0.1, 0.01),    # 0.1^0.2 ≈ 0.631
            (1.0, 1.0),     # 1.0^0.2 = 1.0
            (10.0, 100.0),  # 10.0^0.2 ≈ 1.585
        ]

        for dt, dt_expected in test_cases:
            rkf.P = np.array([[1.0]])  # Reset covariance
            rkf.predict(dt)

            rough_scale = dt ** (2 * rkf.hurst)
            self.assertAlmostEqual(rough_scale, dt ** 0.2, places=6)

            # Check scaling was recorded
            self.assertIn(dt, rkf.dt_history)
            self.assertIn(rough_scale, rkf.scaling_history)

    def test_rough_vs_standard_short_horizon(self):
        """Test rough scaling vs standard for short horizons (dt << 1)"""
        rkf = RoughKalmanFilter(states=1, hurst_exponent=0.1)

        # For H < 0.5 and dt < 1, rough has MORE uncertainty growth
        # Standard: Q * dt
        # Rough: Q * dt^(2H)
        # For dt=0.1, H=0.1:
        #   Standard: Q * 0.1
        #   Rough: Q * 0.1^0.2 = Q * 0.631
        # Ratio: 0.631 / 0.1 = 6.31 > 1.0
        dt_short = 0.1
        comparison = rkf.compare_to_standard(dt_short)

        self.assertEqual(comparison["dt"], dt_short)
        self.assertAlmostEqual(comparison["standard_scale"], dt_short, places=6)
        self.assertAlmostEqual(comparison["rough_scale"], dt_short ** 0.2, places=6)

        # Rough should be MORE uncertain (ratio > 1)
        self.assertGreater(comparison["ratio"], 1.0)
        self.assertEqual(comparison["interpretation"], "more_uncertain")

    def test_rough_vs_standard_long_horizon(self):
        """Test rough scaling vs standard for long horizons (dt >> 1)"""
        rkf = RoughKalmanFilter(states=1, hurst_exponent=0.1)

        # For H < 0.5 and dt > 1, rough has LESS uncertainty growth
        # Standard: Q * dt
        # Rough: Q * dt^(2H)
        # For dt=10, H=0.1:
        #   Standard: Q * 10.0
        #   Rough: Q * 10.0^0.2 = Q * 1.585
        # Ratio: 1.585 / 10.0 = 0.1585 < 1.0
        dt_long = 10.0
        comparison = rkf.compare_to_standard(dt_long)

        self.assertAlmostEqual(comparison["standard_scale"], dt_long, places=6)
        self.assertAlmostEqual(comparison["rough_scale"], dt_long ** 0.2, places=6)

        # Rough should be LESS uncertain (ratio < 1)
        self.assertLess(comparison["ratio"], 1.0)
        self.assertEqual(comparison["interpretation"], "less_uncertain")

    def test_hurst_05_is_standard(self):
        """Test that H=0.5 recovers standard Brownian motion"""
        rkf = RoughKalmanFilter(states=1, hurst_exponent=0.5)

        # For H=0.5, dt^(2H) = dt^1.0 = dt (standard)
        for dt in [0.1, 1.0, 10.0]:
            comparison = rkf.compare_to_standard(dt)
            # Both should scale as dt
            self.assertAlmostEqual(comparison["rough_scale"], dt, places=6)
            self.assertAlmostEqual(comparison["standard_scale"], dt, places=6)
            self.assertAlmostEqual(comparison["ratio"], 1.0, places=6)
            self.assertEqual(comparison["interpretation"], "same")

    def test_process_multiple_observations(self):
        """Test processing multiple observations with rough volatility"""
        rkf = RoughKalmanFilter(states=2, hurst_exponent=0.1)

        # Generate synthetic data
        np.random.seed(42)
        n = 100
        true_prices = 1.0 + np.cumsum(np.random.normal(0, 0.01, n))
        noisy_prices = true_prices + np.random.normal(0, 0.001, n)

        # Process
        fair_values = []
        for price in noisy_prices:
            fair_value, confidence = rkf.process(price, dt=1.0)
            fair_values.append(fair_value)

        # Check filter executed
        self.assertEqual(len(fair_values), n)
        self.assertTrue(rkf.initialized)

        # Check statistics recorded (n-1 because first call initializes)
        self.assertEqual(len(rkf.dt_history), n - 1)
        self.assertEqual(len(rkf.scaling_history), n - 1)

        # Check rough scaling
        stats = rkf.get_rough_statistics()
        self.assertEqual(stats["hurst_exponent"], 0.1)
        self.assertEqual(stats["n_updates"], n - 1)  # First call initializes
        self.assertAlmostEqual(stats["mean_dt"], 1.0, places=2)

    def test_rough_statistics(self):
        """Test get_rough_statistics()"""
        rkf = RoughKalmanFilter(states=1, hurst_exponent=0.15)

        # No data initially
        stats = rkf.get_rough_statistics()
        self.assertEqual(stats["n_updates"], 0)
        self.assertEqual(stats["hurst_exponent"], 0.15)

        # Process some data
        rkf.initialize(1.0)
        for i in range(10):
            rkf.predict(dt=1.0 + 0.1 * i)
            rkf.update(1.0 + 0.001 * i)

        stats = rkf.get_rough_statistics()
        self.assertEqual(stats["n_updates"], 10)
        self.assertGreater(stats["mean_dt"], 1.0)
        self.assertGreater(stats["mean_scaling"], 0.9)


class TestKalmanFilterBankRough(unittest.TestCase):
    """Test Kalman Filter Bank with rough volatility"""

    def test_bank_with_rough_enabled(self):
        """Test filter bank with use_rough=True"""
        bank = KalmanFilterBank(
            states=2,
            use_rough=True,
            hurst_exponent=0.1
        )

        self.assertTrue(bank.use_rough)
        self.assertEqual(bank.hurst_exponent, 0.1)

        # Update asset
        timestamp = datetime.utcnow()
        state = bank.update_asset("TEST/USD", 1.0, timestamp)

        self.assertEqual(state.symbol, "TEST/USD")
        self.assertAlmostEqual(state.fair_value, 1.0, places=4)

        # Check filter type
        kf = bank.filters["TEST/USD"]
        self.assertIsInstance(kf, RoughKalmanFilter)
        self.assertEqual(kf.hurst, 0.1)

    def test_bank_with_rough_disabled(self):
        """Test filter bank with use_rough=False (standard)"""
        bank = KalmanFilterBank(
            states=2,
            use_rough=False
        )

        self.assertFalse(bank.use_rough)

        # Update asset
        timestamp = datetime.utcnow()
        state = bank.update_asset("TEST/USD", 1.0, timestamp)

        # Check filter type
        kf = bank.filters["TEST/USD"]
        self.assertIsInstance(kf, KalmanFilter1D)
        self.assertNotIsInstance(kf, RoughKalmanFilter)

    def test_bank_statistics_with_rough(self):
        """Test statistics include rough volatility info"""
        bank = KalmanFilterBank(
            states=2,
            use_rough=True,
            hurst_exponent=0.12
        )

        # Add some data
        timestamp = datetime.utcnow()
        for i in range(10):
            bank.update_asset("EUR/USD", 1.0 + 0.001 * i, timestamp + timedelta(seconds=i))

        stats = bank.get_statistics()

        # Check configuration includes rough
        self.assertTrue(stats["configuration"]["use_rough"])
        self.assertEqual(stats["configuration"]["hurst_exponent"], 0.12)

        # Check rough volatility stats
        self.assertIn("rough_volatility", stats)
        rough_stats = stats["rough_volatility"]
        self.assertEqual(rough_stats["hurst_exponent"], 0.12)
        self.assertGreater(rough_stats["n_updates"], 0)


class TestEnhancedOracleRough(unittest.TestCase):
    """Test Enhanced Oracle with rough volatility"""

    def test_oracle_with_rough_volatility(self):
        """Test oracle with rough Kalman filters"""
        from aeonica_core.financial.oracle.enhanced_oracle import (
            create_enhanced_oracle
        )
        from aeonica_core.financial.oracle.multi_asset_monitor import (
            AssetMetadata,
            AssetClass,
            AssetRegion
        )

        # Create oracle with rough volatility
        oracle = create_enhanced_oracle(
            use_gpu=False,
            include_forex=False,
            include_crypto=False,
            include_commodities=False,
            enable_phase=True,
            enable_kalman=True,
            enable_risk=False,
            enable_entropy=False,
            kalman_use_rough=True,
            kalman_hurst_exponent=0.1
        )

        # Register asset
        oracle.register_asset(
            AssetMetadata(
                symbol="TEST/USD",
                asset_class=AssetClass.FOREX,
                region=AssetRegion.GLOBAL
            ),
            source="test"
        )

        # Feed data
        timestamp = datetime.utcnow()
        for i in range(100):
            price = 1.0 + 0.001 * i
            oracle.update_asset("TEST/USD", price, timestamp + timedelta(seconds=i))

        # Get snapshot
        snapshot = oracle.get_enhanced_snapshot()

        # Check fair values computed
        self.assertIn("TEST/USD", snapshot.fair_values)
        self.assertGreater(snapshot.fair_values["TEST/USD"], 0.0)

        # Check Kalman bank has rough filters
        self.assertTrue(oracle.kalman_bank.use_rough)
        self.assertEqual(oracle.kalman_bank.hurst_exponent, 0.1)

        # Check filter is RoughKalmanFilter
        kf = oracle.kalman_bank.filters["TEST/USD"]
        self.assertIsInstance(kf, RoughKalmanFilter)

    def test_oracle_statistics_include_rough(self):
        """Test oracle status includes rough volatility info"""
        from aeonica_core.financial.oracle.enhanced_oracle import (
            EnhancedMultiAssetOracle
        )

        oracle = EnhancedMultiAssetOracle(
            use_gpu=False,
            auto_register_common_assets=False,
            enable_kalman=True,
            kalman_use_rough=True,
            kalman_hurst_exponent=0.15
        )

        status = oracle.get_enhanced_status()

        # Check Kalman bank config
        kb_config = status["kalman_bank"]["configuration"]
        self.assertTrue(kb_config["use_rough"])
        self.assertEqual(kb_config["hurst_exponent"], 0.15)

    def test_rough_vs_standard_comparison(self):
        """Compare rough vs standard Kalman on same data"""
        from aeonica_core.financial.oracle.enhanced_oracle import (
            EnhancedMultiAssetOracle
        )

        np.random.seed(42)

        # Create two oracles: standard and rough
        oracle_standard = EnhancedMultiAssetOracle(
            use_gpu=False,
            auto_register_common_assets=False,
            enable_kalman=True,
            kalman_use_rough=False
        )

        oracle_rough = EnhancedMultiAssetOracle(
            use_gpu=False,
            auto_register_common_assets=False,
            enable_kalman=True,
            kalman_use_rough=True,
            kalman_hurst_exponent=0.1
        )

        # Same synthetic data
        from aeonica_core.financial.oracle.multi_asset_monitor import (
            AssetMetadata,
            AssetClass,
            AssetRegion
        )

        metadata = AssetMetadata(
            symbol="TEST/USD",
            asset_class=AssetClass.FOREX,
            region=AssetRegion.GLOBAL
        )

        oracle_standard.register_asset(metadata, source="test")
        oracle_rough.register_asset(metadata, source="test")

        # Feed same data with varying dt to see difference
        timestamp = datetime.utcnow()
        n = 100
        for i in range(n):
            price = 1.0 + 0.001 * i + np.random.normal(0, 0.0001)
            # Use varying dt to make rough different from standard
            dt = 0.5 if i % 2 == 0 else 1.5
            oracle_standard.update_asset("TEST/USD", price, timestamp)
            oracle_rough.update_asset("TEST/USD", price, timestamp)
            timestamp += timedelta(seconds=dt)

        # Get snapshots
        snap_standard = oracle_standard.get_enhanced_snapshot()
        snap_rough = oracle_rough.get_enhanced_snapshot()

        # Both should have fair values
        self.assertIn("TEST/USD", snap_standard.fair_values)
        self.assertIn("TEST/USD", snap_rough.fair_values)

        # Values should be different (but very close due to H close to 0.5 effect)
        fv_standard = snap_standard.fair_values["TEST/USD"]
        fv_rough = snap_rough.fair_values["TEST/USD"]

        # They will be very close, but not identical
        # (difference shows up at high precision)
        self.assertNotEqual(fv_standard, fv_rough)

        # Should be in same ballpark
        relative_diff = abs(fv_rough - fv_standard) / fv_standard
        self.assertLess(relative_diff, 0.01)  # Within 1%


def run_tests():
    """Run all tests"""
    # Create test suite
    suite = unittest.TestSuite()

    # Add all tests
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestRoughKalmanFilter))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestKalmanFilterBankRough))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestEnhancedOracleRough))

    # Run with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Return success
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
