"""
Integration tests for AEONICA × Mycelium distributed memory

Tests end-to-end workflows: store -> retrieve -> query
"""

import pytest
import time
import asyncio
from mycelium_integration import DistributedMemory


@pytest.fixture
def distributed_memory():
    """Create distributed memory instance"""
    return DistributedMemory(
        enable_compression=True,
        enable_encryption=True,
        enable_proofs=True,
        enable_cache=True,
        cache_size_mb=100,
        redundancy_factor=3,
        verbose=False
    )


@pytest.fixture
def user_location():
    """Default user location (San Francisco)"""
    return {"lat": 37.7749, "lon": -122.4194}


@pytest.mark.asyncio
class TestDistributedMemoryIntegration:
    """Integration tests for distributed memory"""

    async def test_store_and_retrieve(self, distributed_memory, user_location):
        """Test storing and retrieving a single memory"""

        # Store memory
        result = await distributed_memory.store(
            content="Fear memories persist 23× longer",
            emotional_coloring={"fear": 0.8, "neutral": 0.2},
            importance=0.9,
            user_location=user_location
        )

        assert 'memory_id' in result
        assert 'shard_id' in result
        memory_id = result['memory_id']

        # Retrieve memory
        memory = await distributed_memory.retrieve(
            memory_id=memory_id,
            user_location=user_location
        )

        assert memory is not None
        assert memory['id'] == memory_id
        assert memory['content'] == "Fear memories persist 23× longer"
        assert memory['emotional_coloring']['fear'] == 0.8
        assert memory['importance'] == 0.9

    async def test_store_batch(self, distributed_memory, user_location):
        """Test batch storage"""

        # Create test memories
        memories = [
            {
                'id': f'mem_{i}',
                'content': f'Test memory {i}',
                'emotional_coloring': {'fear': 0.8 if i % 2 == 0 else 0.2, 'joy': 0.2 if i % 2 == 0 else 0.8},
                'importance': 0.5 + (i % 5) * 0.1,
                'timestamp': time.time(),
                'access_count': 0
            }
            for i in range(20)
        ]

        # Store batch
        metrics = await distributed_memory.store_memory_field(
            memories=memories,
            user_location=user_location
        )

        # Check metrics
        assert metrics.sharding_metrics is not None
        assert metrics.sharding_metrics.total_memories == 20
        assert metrics.sharding_metrics.total_shards > 0
        assert metrics.storage_metrics is not None

        # Verify memories are in map
        assert len(distributed_memory.memory_to_shard_map) >= 20

    async def test_query_by_emotion(self, distributed_memory, user_location):
        """Test querying memories by emotion"""

        # Store memories with different emotions
        fear_memory = await distributed_memory.store(
            content="Fear memory",
            emotional_coloring={"fear": 0.9, "neutral": 0.1},
            importance=0.8,
            user_location=user_location
        )

        joy_memory = await distributed_memory.store(
            content="Joy memory",
            emotional_coloring={"joy": 0.9, "neutral": 0.1},
            importance=0.7,
            user_location=user_location
        )

        # Query for fear memories
        fear_results = await distributed_memory.query(
            emotion="fear",
            min_importance=0.5,
            user_location=user_location,
            limit=10
        )

        # Should find fear memory
        fear_ids = [m['id'] for m in fear_results]
        assert fear_memory['memory_id'] in fear_ids or len(fear_results) > 0

    async def test_query_by_importance(self, distributed_memory, user_location):
        """Test querying by importance threshold"""

        # Store high and low importance memories
        high_importance = await distributed_memory.store(
            content="High importance",
            emotional_coloring={"neutral": 1.0},
            importance=0.95,
            user_location=user_location
        )

        low_importance = await distributed_memory.store(
            content="Low importance",
            emotional_coloring={"neutral": 1.0},
            importance=0.2,
            user_location=user_location
        )

        # Query for high importance only
        high_results = await distributed_memory.query(
            min_importance=0.9,
            user_location=user_location,
            limit=10
        )

        # Should find high importance memory
        if len(high_results) > 0:
            for memory in high_results:
                assert memory['importance'] >= 0.9

    async def test_cache_performance(self, distributed_memory, user_location):
        """Test cache hit/miss performance"""

        # Store memory
        result = await distributed_memory.store(
            content="Cache test memory",
            emotional_coloring={"neutral": 1.0},
            importance=0.8,
            user_location=user_location
        )

        memory_id = result['memory_id']

        # First retrieval (cache miss)
        start = time.time()
        memory1 = await distributed_memory.retrieve(memory_id, user_location)
        first_retrieval_time = time.time() - start

        # Second retrieval (should be cache hit)
        start = time.time()
        memory2 = await distributed_memory.retrieve(memory_id, user_location)
        second_retrieval_time = time.time() - start

        # Verify both retrieved successfully
        assert memory1 is not None
        assert memory2 is not None
        assert memory1['id'] == memory2['id']

        # Second should be faster (cache hit)
        # Note: In mock environment, timing may not be significantly different
        assert second_retrieval_time <= first_retrieval_time * 2

    async def test_get_metrics(self, distributed_memory, user_location):
        """Test getting system metrics"""

        # Store some memories
        for i in range(5):
            await distributed_memory.store(
                content=f"Metric test {i}",
                emotional_coloring={"neutral": 1.0},
                importance=0.5,
                user_location=user_location
            )

        # Get metrics
        metrics = distributed_memory.get_metrics()

        assert 'total_memories_stored' in metrics
        assert 'total_shards' in metrics
        assert 'retrieval' in metrics
        assert metrics['total_memories_stored'] >= 5

    async def test_health_check(self, distributed_memory):
        """Test health check"""

        health = distributed_memory.health_check()

        assert 'status' in health
        assert 'components' in health
        assert 'network' in health
        assert health['status'] == 'healthy'

    async def test_multiple_shards(self, distributed_memory, user_location):
        """Test that memories are distributed across shards"""

        # Create memories with different emotions
        memories = []
        for i in range(50):
            emotion = ['fear', 'joy', 'neutral'][i % 3]
            memory = {
                'id': f'multi_mem_{i}',
                'content': f'Memory {i}',
                'emotional_coloring': {emotion: 0.8, 'neutral': 0.2},
                'importance': 0.5,
                'timestamp': time.time(),
                'access_count': 0
            }
            memories.append(memory)

        # Store
        metrics = await distributed_memory.store_memory_field(
            memories=memories,
            user_location=user_location
        )

        # Should create multiple shards (different emotions)
        assert metrics.sharding_metrics.total_shards >= 3

        # Check emotion distribution
        emotion_dist = metrics.sharding_metrics.emotion_distribution
        assert len(emotion_dist) >= 3


class TestErrorHandling:
    """Test error handling and edge cases"""

    @pytest.mark.asyncio
    async def test_retrieve_nonexistent(self, distributed_memory, user_location):
        """Test retrieving non-existent memory"""

        memory = await distributed_memory.retrieve(
            memory_id='nonexistent_id',
            user_location=user_location
        )

        assert memory is None

    @pytest.mark.asyncio
    async def test_empty_batch(self, distributed_memory, user_location):
        """Test storing empty batch"""

        metrics = await distributed_memory.store_memory_field(
            memories=[],
            user_location=user_location
        )

        assert metrics.sharding_metrics.total_memories == 0
        assert metrics.sharding_metrics.total_shards == 0

    @pytest.mark.asyncio
    async def test_invalid_emotion_query(self, distributed_memory, user_location):
        """Test querying with invalid emotion"""

        # Query for non-existent emotion
        results = await distributed_memory.query(
            emotion="invalid_emotion",
            user_location=user_location
        )

        # Should return empty list (no matching shards)
        assert isinstance(results, list)


if __name__ == '__main__':
    pytest.main([__file__, '-v', '-s'])
