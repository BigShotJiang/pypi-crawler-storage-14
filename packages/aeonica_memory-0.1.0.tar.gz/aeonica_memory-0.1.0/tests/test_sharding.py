"""
Unit tests for emotional sharding strategy

Tests the emotion-based memory sharding implementation.
"""

import pytest
import time
from mycelium_integration.sharding.emotional_shard_strategy import (
    EmotionalShardingStrategy,
    MemoryShard,
    ShardingMetrics
)


@pytest.fixture
def sample_memories():
    """Generate sample memories for testing"""
    memories = []

    # Create memories with different emotions
    for i in range(100):
        emotion_idx = i % 3
        emotions = ['fear', 'joy', 'neutral']
        dominant_emotion = emotions[emotion_idx]

        memory = {
            'id': f'mem_{i}',
            'content': f'Test memory {i} about {dominant_emotion}',
            'emotional_coloring': {
                dominant_emotion: 0.8,
                'neutral': 0.2
            },
            'importance': 0.5 + (i % 5) * 0.1,
            'timestamp': time.time() - (i * 3600),
            'access_count': i % 10
        }
        memories.append(memory)

    return memories


@pytest.fixture
def sharding_strategy():
    """Create sharding strategy instance"""
    return EmotionalShardingStrategy(
        shard_size_target_mb=1,
        max_memories_per_shard=30,
        enable_compression=True,
        verbose=False
    )


class TestEmotionalSharding:
    """Test emotional sharding strategy"""

    def test_group_by_emotion(self, sharding_strategy, sample_memories):
        """Test grouping memories by dominant emotion"""

        emotion_groups = sharding_strategy._group_by_emotion(sample_memories)

        # Should have 3 emotion groups (fear, joy, neutral)
        assert len(emotion_groups) == 3
        assert 'fear' in emotion_groups
        assert 'joy' in emotion_groups
        assert 'neutral' in emotion_groups

        # Each group should have ~33 memories
        for emotion, group in emotion_groups.items():
            assert len(group) > 0
            assert len(group) <= len(sample_memories)

    def test_get_dominant_emotion(self, sharding_strategy):
        """Test extracting dominant emotion from memory"""

        memory = {
            'emotional_coloring': {
                'fear': 0.8,
                'joy': 0.2,
                'neutral': 0.1
            }
        }

        dominant = sharding_strategy._get_dominant_emotion(memory)
        assert dominant == 'fear'

    def test_get_dominant_emotion_neutral_fallback(self, sharding_strategy):
        """Test neutral fallback when no emotions"""

        memory = {
            'emotional_coloring': {}
        }

        dominant = sharding_strategy._get_dominant_emotion(memory)
        assert dominant == 'neutral'

    def test_subdivide_cluster_small(self, sharding_strategy):
        """Test subdivision of small cluster (no subdivision needed)"""

        memories = [{'id': f'mem_{i}'} for i in range(20)]

        sub_clusters = sharding_strategy._subdivide_cluster('fear', memories)

        # Small cluster should not be subdivided
        assert len(sub_clusters) == 1
        assert len(sub_clusters[0]) == 20

    def test_subdivide_cluster_large(self, sharding_strategy):
        """Test subdivision of large cluster"""

        # Create cluster larger than max_memories_per_shard (30)
        memories = [{'id': f'mem_{i}'} for i in range(100)]

        sub_clusters = sharding_strategy._subdivide_cluster('fear', memories)

        # Should be subdivided into multiple clusters
        assert len(sub_clusters) > 1

        # Each sub-cluster should be <= max size
        for cluster in sub_clusters:
            assert len(cluster) <= sharding_strategy.max_memories_per_shard

        # Total memories should be preserved
        total = sum(len(c) for c in sub_clusters)
        assert total == 100

    def test_shard_memory_field(self, sharding_strategy, sample_memories):
        """Test complete sharding operation"""

        shards, metrics = sharding_strategy.shard_memory_field(sample_memories)

        # Should create shards
        assert len(shards) > 0

        # Check shard structure
        for shard in shards:
            assert isinstance(shard, MemoryShard)
            assert shard.num_memories > 0
            assert shard.compressed_size_bytes > 0
            assert shard.compression_ratio > 0
            assert 0 <= shard.avg_importance <= 1.0

        # Check metrics
        assert isinstance(metrics, ShardingMetrics)
        assert metrics.total_memories == len(sample_memories)
        assert metrics.total_shards == len(shards)
        assert metrics.overall_compression_ratio > 1.0

    def test_shard_memory_field_empty(self, sharding_strategy):
        """Test sharding with empty memory list"""

        shards, metrics = sharding_strategy.shard_memory_field([])

        assert len(shards) == 0
        assert metrics.total_memories == 0
        assert metrics.total_shards == 0

    def test_create_shard(self, sharding_strategy):
        """Test shard creation"""

        memories = [
            {
                'id': 'mem_1',
                'content': 'Test memory',
                'emotional_coloring': {'fear': 0.8},
                'importance': 0.9,
                'timestamp': time.time(),
                'access_count': 5
            }
        ]

        shard = sharding_strategy._create_shard(
            shard_index=0,
            emotion='fear',
            memories=memories
        )

        assert shard.shard_index == 0
        assert shard.emotion_cluster == 'fear'
        assert shard.num_memories == 1
        assert 'mem_1' in shard.memory_ids
        assert shard.compressed_size_bytes > 0
        assert len(shard.compressed_data) > 0
        assert shard.checksum is not None

    def test_emotion_distribution(self, sharding_strategy):
        """Test emotion distribution calculation"""

        memories = [
            {'emotional_coloring': {'fear': 0.8, 'joy': 0.2}},
            {'emotional_coloring': {'fear': 0.6, 'joy': 0.4}},
        ]

        distribution = sharding_strategy._calculate_emotion_distribution(memories)

        assert 'fear' in distribution
        assert 'joy' in distribution
        assert distribution['fear'] == 0.7  # (0.8 + 0.6) / 2
        assert distribution['joy'] == 0.3  # (0.2 + 0.4) / 2

    def test_compression_ratio(self, sharding_strategy, sample_memories):
        """Test that compression actually reduces size"""

        # Create shards
        shards, metrics = sharding_strategy.shard_memory_field(sample_memories)

        # Check overall compression
        assert metrics.overall_compression_ratio > 1.0

        # Check individual shards
        for shard in shards:
            assert shard.compression_ratio > 1.0
            assert shard.compressed_size_bytes < shard.original_size_bytes


class TestShardDataModel:
    """Test MemoryShard data model"""

    def test_shard_creation(self):
        """Test creating a shard"""

        shard = MemoryShard(
            shard_id='test_shard',
            shard_index=0,
            emotion_cluster='fear',
            emotion_distribution={'fear': 0.8},
            memory_ids=['mem_1', 'mem_2'],
            num_memories=2,
            compressed_data=b'test_data',
            compression_ratio=2.0,
            original_size_bytes=100,
            compressed_size_bytes=50,
            earliest_timestamp=1000.0,
            latest_timestamp=2000.0,
            avg_importance=0.7,
            created_at=time.time(),
            checksum='abc123'
        )

        assert shard.shard_id == 'test_shard'
        assert shard.num_memories == 2
        assert shard.compression_ratio == 2.0

    def test_shard_validation_num_memories(self):
        """Test shard validation - must have memories"""

        with pytest.raises(AssertionError, match="at least one memory"):
            MemoryShard(
                shard_id='test',
                shard_index=0,
                emotion_cluster='fear',
                emotion_distribution={},
                memory_ids=[],
                num_memories=0,  # Invalid: 0 memories
                compressed_data=b'',
                compression_ratio=1.0,
                original_size_bytes=0,
                compressed_size_bytes=0,
                earliest_timestamp=0,
                latest_timestamp=0,
                avg_importance=0.5,
                created_at=0,
                checksum=''
            )

    def test_shard_validation_importance(self):
        """Test shard validation - importance must be [0, 1]"""

        with pytest.raises(AssertionError, match="Importance must be"):
            MemoryShard(
                shard_id='test',
                shard_index=0,
                emotion_cluster='fear',
                emotion_distribution={},
                memory_ids=['mem_1'],
                num_memories=1,
                compressed_data=b'',
                compression_ratio=1.0,
                original_size_bytes=0,
                compressed_size_bytes=0,
                earliest_timestamp=0,
                latest_timestamp=0,
                avg_importance=1.5,  # Invalid: > 1.0
                created_at=0,
                checksum=''
            )


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
