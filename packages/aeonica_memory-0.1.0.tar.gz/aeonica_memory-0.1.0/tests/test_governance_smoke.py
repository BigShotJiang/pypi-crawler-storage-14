#!/usr/bin/env python3
"""
Governance Engine Smoke Test

Quick validation that all components work in the current environment.
Reports which optional dependencies are available.

Run:
    python3 tests/test_governance_smoke.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
from datetime import datetime


def check_dependencies():
    """Check which optional dependencies are available"""
    print("=" * 60)
    print("DEPENDENCY CHECK")
    print("=" * 60)

    deps = {}

    # PyTorch
    try:
        import torch
        deps['torch'] = torch.__version__
        deps['cuda'] = torch.cuda.is_available()
        if deps['cuda']:
            deps['cuda_device'] = torch.cuda.get_device_name(0)
    except ImportError:
        deps['torch'] = None
        deps['cuda'] = False

    # Cryptography
    try:
        import cryptography
        deps['cryptography'] = cryptography.__version__
    except ImportError:
        deps['cryptography'] = None

    # CuPy
    try:
        import cupy
        deps['cupy'] = cupy.__version__
    except ImportError:
        deps['cupy'] = None

    print(f"  PyTorch:      {deps['torch'] or 'NOT INSTALLED'}")
    print(f"  CUDA:         {deps['cuda_device'] if deps['cuda'] else 'NOT AVAILABLE'}")
    print(f"  Cryptography: {deps['cryptography'] or 'NOT INSTALLED (using HMAC fallback)'}")
    print(f"  CuPy:         {deps['cupy'] or 'NOT INSTALLED'}")
    print()

    return deps


def test_trace_logging():
    """Test trace logging pipeline"""
    print("TEST 1: Trace Logging")
    print("-" * 40)

    from aeonica_core.governance.trace_logger import (
        TraceLogger, FileTraceStore, RequestTrace,
        EffectiveStrategy, SolverResult, RegimeType, SolverMode, ConfidenceLevel
    )

    # Create in-memory store for testing
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        store = FileTraceStore(tmpdir)
        logger = TraceLogger(store=store, buffer_size=5)

        # Log a trace
        trace = logger.log_request(
            species="test_species",
            policy_id="TEST_POLICY",
            regime=RegimeType.STABLE,
            isp_id="test_isp",
            effective_strategy=EffectiveStrategy(constellation_threshold=0.75),
            rtt_raw=[10.0, 12.0, 15.0, 11.0, 13.0],
            rtt_corrected=[9.5, 11.5, 14.5, 10.5, 12.5],
            solver_result=SolverResult(
                mode=SolverMode.CONSTELLATION,
                confidence=ConfidenceLevel.HIGH,
                anchors_used=5,
            ),
            ground_truth_km=5.0,
        )

        # Flush and reload
        logger.flush()
        loaded = store.load_traces(limit=1)

        # Convert to tensor
        tensor = store.to_tensor(loaded)

        print(f"  ✓ Logged trace: {trace.request_id[:8]}...")
        print(f"  ✓ Hash: {trace.hash}")
        print(f"  ✓ Loaded back: {len(loaded)} traces")
        print(f"  ✓ Tensor shape: {tensor.shape}")
        assert tensor.shape == (1, 64), f"Expected (1, 64), got {tensor.shape}"

    print("  ✓ PASS")
    return True


def test_decision_capsule():
    """Test decision capsule signing/verification"""
    print("\nTEST 2: Decision Capsules")
    print("-" * 40)

    from aeonica_core.governance.decision_capsule import (
        DecisionCapsule, CapsuleSigner, CapsuleVerifier, DecisionType
    )

    # Create and sign capsule
    signer = CapsuleSigner(signer_id="smoke-test")

    capsule = DecisionCapsule.create(
        species="test",
        policy_id="TEST",
        constellation_threshold=0.7,
        probe_count=5,
        mode="CONSTELLATION",
        regime="STABLE",
        isp_profile_id="test_isp",
        decision_type=DecisionType.GEOLOCATION,
        confidence="HIGH",
        anchors_used=5,
        result_data={"lat": 33.0, "lng": -84.0},
    )

    signed = signer.sign(capsule)

    # Verify (use verifier created from signer's public key)
    verifier = CapsuleVerifier.from_signer(signer)
    is_valid = verifier.verify(signed)

    print(f"  ✓ Created capsule: {signed.capsule_id[:8]}...")
    print(f"  ✓ Content hash: {signed.content_hash[:16]}...")
    print(f"  ✓ Signature type: {'ed25519' if not signed.signature.startswith('hmac:') else 'hmac-fallback'}")
    print(f"  ✓ Verification: {'VALID' if is_valid else 'INVALID'}")
    assert is_valid, "Capsule verification failed"

    print("  ✓ PASS")
    return True


def test_replay_engine():
    """Test GPU replay engine"""
    print("\nTEST 3: Replay Engine")
    print("-" * 40)

    from aeonica_core.governance.replay_engine import GPUReplayEngine, PolicyVariant
    from aeonica_core.governance.trace_logger import (
        RequestTrace, EffectiveStrategy, SolverResult, RegimeType, SolverMode, ConfidenceLevel
    )

    # Create synthetic traces
    traces = []
    for i in range(10):
        trace = RequestTrace(
            species="test",
            policy_id="TEST",
            regime=RegimeType.STABLE,
            isp_id="isp_0",
            effective_strategy=EffectiveStrategy(constellation_threshold=0.7),
            rtt_raw=[10 + i, 12, 15, 11, 13],
            rtt_corrected=[9.5 + i, 11.5, 14.5, 10.5, 12.5],
            solver_result=SolverResult(confidence=ConfidenceLevel.HIGH, anchors_used=5),
            ground_truth_km=5.0 + i,
        )
        traces.append(trace)

    # Create variants
    variants = PolicyVariant.generate_grid(
        constellation_threshold=[0.5, 0.7, 0.9],
        probe_count=[3, 5],
    )

    # Run replay
    engine = GPUReplayEngine(device='cpu')  # Force CPU for smoke test
    result = engine.replay(traces, variants, verbose=False)

    print(f"  ✓ Traces: {len(traces)}")
    print(f"  ✓ Variants: {len(variants)}")
    print(f"  ✓ Evaluations: {len(traces) * len(variants)}")
    print(f"  ✓ Time: {result.replay_time_seconds:.3f}s")
    print(f"  ✓ Device: {result.device}")

    best_var, best_met = result.best_variant()
    print(f"  ✓ Best threshold: {best_var.constellation_threshold}")

    print("  ✓ PASS")
    return True


def test_species_evolution():
    """Test species genome evolution"""
    print("\nTEST 4: Species Evolution")
    print("-" * 40)

    from aeonica_core.governance.species_evolver import (
        SpeciesEvolver, SpeciesGenome, EvolutionConfig
    )
    from aeonica_core.governance.trace_logger import (
        RequestTrace, EffectiveStrategy, SolverResult, RegimeType, ConfidenceLevel
    )

    # Create minimal traces
    traces = []
    for i in range(20):
        trace = RequestTrace(
            species="test",
            policy_id="TEST",
            regime=RegimeType.STABLE,
            isp_id="isp_0",
            effective_strategy=EffectiveStrategy(),
            rtt_raw=[10 + i % 5, 12, 15, 11, 13],
            rtt_corrected=[9.5 + i % 5, 11.5, 14.5, 10.5, 12.5],
            solver_result=SolverResult(confidence=ConfidenceLevel.HIGH, anchors_used=5),
            ground_truth_km=5.0 + i % 10,
        )
        traces.append(trace)

    # Base genome
    base = SpeciesGenome(species_id="test_species", version=1)

    # Quick evolution (2 generations, small population)
    config = EvolutionConfig(population_size=8, generations=2)
    evolver = SpeciesEvolver(device='cpu', config=config)

    result = evolver.evolve(traces, base, generations=2, population_size=8, verbose=False)

    print(f"  ✓ Base species: {base.species_id}")
    print(f"  ✓ Generations: {result.generations_run}")
    print(f"  ✓ Best fitness: {result.best_fitness:.4f}")
    print(f"  ✓ Evolved threshold: {result.best_genome.constellation_threshold:.3f}")
    print(f"  ✓ Time: {result.evolution_time_seconds:.2f}s")

    print("  ✓ PASS")
    return True


def test_health_index():
    """Test health index"""
    print("\nTEST 5: Health Index")
    print("-" * 40)

    from aeonica_core.governance.health_index import HealthIndex, HealthStatus

    health = HealthIndex()

    # Update some anchors
    for i in range(5):
        health.update_anchor(
            anchor_id="anchor_a",
            rtt_mean=15.0,
            rtt_variance=1.0,
            regime="STABLE",
            region="us-east",
        )
        health.update_anchor(
            anchor_id="anchor_b",
            rtt_mean=25.0,
            rtt_variance=5.0,  # Higher variance = lower health
            regime="VOLATILE" if i > 2 else "STABLE",
            region="us-west",
        )

    # Check health
    health_a = health.get_anchor_health("anchor_a")
    health_b = health.get_anchor_health("anchor_b")

    print(f"  ✓ Anchor A health: {health_a.score_1h:.2f} ({health_a.status.value})")
    print(f"  ✓ Anchor B health: {health_b.score_1h:.2f} ({health_b.status.value})")

    # Routing recommendations
    recs = health.get_routing_recommendations(min_health=0.5)
    print(f"  ✓ Healthy anchors: {len(recs['healthy_anchors'])}")

    print("  ✓ PASS")
    return True


def test_batched_solver():
    """Test batched TDOA solver"""
    print("\nTEST 6: Batched Solver")
    print("-" * 40)

    from aeonica_core.governance.batched_solver import BatchedTDOASolver

    solver = BatchedTDOASolver(device='cpu')

    # Synthetic data
    n_requests = 10
    n_anchors = 5

    # Random anchor positions (US)
    anchor_positions = np.array([
        [33.7, -84.4],   # Atlanta
        [41.9, -87.6],   # Chicago
        [32.8, -96.8],   # Dallas
        [47.6, -122.3],  # Seattle
        [40.7, -74.0],   # NYC
    ])

    # Random RTT (10-50ms)
    rtt_matrix = np.random.uniform(10, 50, (n_requests, n_anchors))

    # Solve
    result = solver.solve_batch(rtt_matrix, anchor_positions, verbose=False)

    print(f"  ✓ Requests: {n_requests}")
    print(f"  ✓ Anchors: {n_anchors}")
    print(f"  ✓ Solve time: {result.solve_time_ms:.1f}ms")
    print(f"  ✓ Mean confidence: {result.confidences.mean():.2f}")
    print(f"  ✓ Sample location: ({result.latitudes[0]:.2f}, {result.longitudes[0]:.2f})")

    print("  ✓ PASS")
    return True


def main():
    """Run all smoke tests"""
    print()
    print("=" * 60)
    print("  GOVERNANCE ENGINE SMOKE TEST")
    print("=" * 60)
    print()

    deps = check_dependencies()

    results = {}

    tests = [
        ("Trace Logging", test_trace_logging),
        ("Decision Capsules", test_decision_capsule),
        ("Replay Engine", test_replay_engine),
        ("Species Evolution", test_species_evolution),
        ("Health Index", test_health_index),
        ("Batched Solver", test_batched_solver),
    ]

    for name, test_fn in tests:
        try:
            results[name] = test_fn()
        except Exception as e:
            print(f"\n  ✗ FAIL: {e}")
            results[name] = False
            import traceback
            traceback.print_exc()

    # Summary
    print()
    print("=" * 60)
    print("SUMMARY")
    print("=" * 60)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for name, passed_test in results.items():
        icon = "✓" if passed_test else "✗"
        print(f"  {icon} {name}")

    print()
    print(f"Result: {passed}/{total} tests passed")

    if passed == total:
        print("\n✓ All smoke tests passed! Environment ready.")
    else:
        print("\n⚠ Some tests failed. Check errors above.")

    # Recommendations
    print()
    print("RECOMMENDATIONS:")
    if not deps.get('torch'):
        print("  • Install PyTorch for GPU acceleration: pip install torch")
    if not deps.get('cuda'):
        print("  • CUDA not available - GPU features will fall back to CPU")
    if not deps.get('cryptography'):
        print("  • Install cryptography for ed25519 signatures: pip install cryptography")

    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
