#!/usr/bin/env python3
"""
Test Suite: Copula Backtest Framework

Tests the validation framework for copula-based VaR forecasts:
1. Kupiec POF (Proportion of Failures) test
2. Christoffersen Conditional Coverage test
3. Rosenblatt PIT diagnostics

Author: AEONICA
Version: 1.0
"""

import sys
import unittest
import numpy as np
from datetime import datetime

# Add path
sys.path.insert(0, '/Users/dindelinc/Desktop/VELORA_COGNITIION')

from aeonica_core.financial.oracle.copula_backtests import (
    CopulaBacktestEngine,
    KupiecTestResult,
    ChristoffersenTestResult,
    RosenblattPITResult
)


class TestKupiecPOF(unittest.TestCase):
    """Test Kupiec POF test"""

    def setUp(self):
        """Set up backtest engine"""
        self.backtester = CopulaBacktestEngine()
        np.random.seed(42)

    def test_correct_var_model(self):
        """Test Kupiec with correctly calibrated VaR"""
        n = 1000
        confidence = 0.99
        expected_rate = 1 - confidence

        # Generate losses from standard normal
        losses = np.random.normal(0, 1, n)

        # VaR at 99% should be ~2.33σ
        var_forecasts = np.full(n, stats.norm.ppf(confidence))

        # Run Kupiec test
        result = self.backtester.kupiec_test(losses, var_forecasts, confidence)

        # Check structure
        self.assertIsInstance(result, KupiecTestResult)
        self.assertEqual(result.confidence_level, confidence)
        self.assertEqual(result.n_observations, n)

        # Should NOT reject H0 (model is correct)
        # With n=1000, expected ~10 breaches, allow 5-20 range
        self.assertGreaterEqual(result.observed_breaches, 0)
        self.assertLess(result.observed_breaches, 50)  # Sanity check

        # p-value should be reasonable (> 0.05 ideally, but can vary)
        self.assertGreaterEqual(result.p_value, 0.0)
        self.assertLessEqual(result.p_value, 1.0)

    def test_underestimated_var(self):
        """Test Kupiec with underestimated VaR (too many breaches)"""
        n = 1000
        confidence = 0.99

        # Generate losses
        losses = np.random.normal(0, 1, n)

        # VaR too low (1σ instead of 2.33σ)
        var_forecasts = np.full(n, 1.0)

        # Run Kupiec test
        result = self.backtester.kupiec_test(losses, var_forecasts, confidence)

        # Should have many more breaches than expected (~160 vs ~10)
        self.assertGreater(result.observed_breaches, result.expected_breaches * 2)

        # Should reject H0 (model is wrong)
        # Note: With high breach rate, may or may not reject depending on sample
        self.assertIsNotNone(result.reject_h0)

    def test_overestimated_var(self):
        """Test Kupiec with overestimated VaR (too few breaches)"""
        n = 1000
        confidence = 0.99

        # Generate losses
        losses = np.random.normal(0, 1, n)

        # VaR too high (5σ instead of 2.33σ)
        var_forecasts = np.full(n, 5.0)

        # Run Kupiec test
        result = self.backtester.kupiec_test(losses, var_forecasts, confidence)

        # Should have very few breaches
        self.assertLess(result.observed_breaches, result.expected_breaches * 0.5)

    def test_edge_case_no_breaches(self):
        """Test Kupiec with zero breaches"""
        n = 100
        confidence = 0.99

        # All losses below VaR
        losses = np.random.normal(-2, 0.1, n)
        var_forecasts = np.full(n, 0.0)

        result = self.backtester.kupiec_test(losses, var_forecasts, confidence)

        self.assertEqual(result.observed_breaches, 0)
        self.assertEqual(result.breach_rate, 0.0)

    def test_edge_case_all_breaches(self):
        """Test Kupiec with all breaches"""
        n = 100
        confidence = 0.99

        # All losses above VaR
        losses = np.random.normal(2, 0.1, n)
        var_forecasts = np.full(n, 0.0)

        result = self.backtester.kupiec_test(losses, var_forecasts, confidence)

        self.assertEqual(result.observed_breaches, n)
        self.assertEqual(result.breach_rate, 1.0)

    def test_serialization(self):
        """Test KupiecTestResult to_dict()"""
        n = 100
        confidence = 0.95

        losses = np.random.normal(0, 1, n)
        var_forecasts = np.full(n, 1.65)

        result = self.backtester.kupiec_test(losses, var_forecasts, confidence)
        d = result.to_dict()

        # Check keys
        self.assertIn("confidence_level", d)
        self.assertIn("observed_breaches", d)
        self.assertIn("lr_statistic", d)
        self.assertIn("p_value", d)
        self.assertIn("status", d)

        # Check values
        self.assertEqual(d["confidence_level"], confidence)
        self.assertIn(d["status"], ["PASS", "FAIL"])


class TestChristoffersen(unittest.TestCase):
    """Test Christoffersen conditional coverage test"""

    def setUp(self):
        """Set up backtest engine"""
        self.backtester = CopulaBacktestEngine()
        np.random.seed(123)

    def test_correct_independent_breaches(self):
        """Test Christoffersen with correct VaR and independent breaches"""
        n = 1000
        confidence = 0.99

        # Generate i.i.d. losses
        losses = np.random.normal(0, 1, n)
        var_forecasts = np.full(n, stats.norm.ppf(confidence))

        result = self.backtester.christoffersen_test(losses, var_forecasts, confidence)

        # Check structure
        self.assertIsInstance(result, ChristoffersenTestResult)
        self.assertEqual(result.confidence_level, confidence)

        # Check components
        self.assertGreaterEqual(result.p_value_uc, 0.0)  # Unconditional coverage
        self.assertGreaterEqual(result.p_value_ind, 0.0)  # Independence
        self.assertGreaterEqual(result.p_value_cc, 0.0)  # Conditional coverage

        # LR_cc = LR_uc + LR_ind
        self.assertAlmostEqual(result.lr_cc, result.lr_uc + result.lr_ind, places=6)

    def test_clustered_breaches(self):
        """Test Christoffersen with clustered (dependent) breaches"""
        n = 1000
        confidence = 0.99

        # Generate losses with volatility clustering (GARCH-like)
        vol = np.ones(n)
        for i in range(1, n):
            # Volatility persistence
            vol[i] = 0.05 + 0.9 * vol[i-1] + 0.05 * np.random.randn()**2

        losses = np.random.randn(n) * np.sqrt(vol)

        # Constant VaR (wrong for time-varying volatility)
        var_forecasts = np.full(n, stats.norm.ppf(confidence))

        result = self.backtester.christoffersen_test(losses, var_forecasts, confidence)

        # Should detect clustering via independence test
        # (p_value_ind should be low, but depends on sample)
        self.assertIsNotNone(result.p_value_ind)

        # Check transition matrix
        total_transitions = result.n_00 + result.n_01 + result.n_10 + result.n_11
        self.assertGreater(total_transitions, 0)

    def test_serialization(self):
        """Test ChristoffersenTestResult to_dict()"""
        n = 100
        confidence = 0.95

        losses = np.random.normal(0, 1, n)
        var_forecasts = np.full(n, 1.65)

        result = self.backtester.christoffersen_test(losses, var_forecasts, confidence)
        d = result.to_dict()

        # Check keys
        self.assertIn("lr_uc", d)
        self.assertIn("lr_ind", d)
        self.assertIn("lr_cc", d)
        self.assertIn("breach_clustering", d)
        self.assertIn("status", d)

        # Check breach clustering structure
        bc = d["breach_clustering"]
        self.assertIn("n_00", bc)
        self.assertIn("n_01", bc)
        self.assertIn("n_10", bc)
        self.assertIn("n_11", bc)


class TestRosenblattPIT(unittest.TestCase):
    """Test Rosenblatt PIT diagnostics"""

    def setUp(self):
        """Set up backtest engine"""
        self.backtester = CopulaBacktestEngine()
        np.random.seed(456)

    def test_correct_copula_specification(self):
        """Test PIT with correctly specified copula"""
        n = 500

        # Generate from independence copula (product copula)
        u = np.random.uniform(0, 1, n)
        v = np.random.uniform(0, 1, n)

        # Independence copula CDF: C(u, v) = u * v
        def independence_copula_cdf(u_val, v_val):
            return u_val * v_val

        result = self.backtester.rosenblatt_pit_test(u, v, independence_copula_cdf)

        # Check structure
        self.assertIsInstance(result, RosenblattPITResult)
        self.assertEqual(result.n_observations, n)

        # Both KS and CvM p-values should be > 0.05 (not reject)
        # Note: With small n, may occasionally fail by chance
        self.assertGreaterEqual(result.ks_p_value, 0.0)
        self.assertGreaterEqual(result.cvm_p_value, 0.0)
        self.assertLessEqual(result.ks_p_value, 1.0)
        self.assertLessEqual(result.cvm_p_value, 1.0)

        # PIT values should be in [0, 1]
        if result.pit_values is not None:
            self.assertTrue(np.all(result.pit_values >= 0))
            self.assertTrue(np.all(result.pit_values <= 1))

    def test_misspecified_copula(self):
        """Test PIT with misspecified copula"""
        n = 500

        # Generate from Clayton copula (lower tail dependence)
        theta = 2.0
        u = np.random.uniform(0, 1, n)
        w = np.random.uniform(0, 1, n)
        v = (u ** (-theta) * (w ** (-theta / (1 + theta)) - 1) + 1) ** (-1 / theta)

        # But test with independence copula (wrong!)
        def independence_copula_cdf(u_val, v_val):
            return u_val * v_val

        result = self.backtester.rosenblatt_pit_test(u, v, independence_copula_cdf)

        # Should detect misspecification
        # (at least one p-value should be low, but depends on sample)
        self.assertIsNotNone(result.copula_adequate)

    def test_serialization(self):
        """Test RosenblattPITResult to_dict()"""
        n = 100

        u = np.random.uniform(0, 1, n)
        v = np.random.uniform(0, 1, n)

        def independence_copula_cdf(u_val, v_val):
            return u_val * v_val

        result = self.backtester.rosenblatt_pit_test(u, v, independence_copula_cdf)
        d = result.to_dict()

        # Check keys
        self.assertIn("ks_statistic", d)
        self.assertIn("ks_p_value", d)
        self.assertIn("cvm_statistic", d)
        self.assertIn("cvm_p_value", d)
        self.assertIn("copula_adequate", d)
        self.assertIn("status", d)


class TestBacktestEngine(unittest.TestCase):
    """Test CopulaBacktestEngine orchestration"""

    def setUp(self):
        """Set up backtest engine"""
        self.backtester = CopulaBacktestEngine()

    def test_test_history(self):
        """Test that engine records test history"""
        n = 100
        confidence = 0.95

        losses = np.random.normal(0, 1, n)
        var_forecasts = np.full(n, 1.65)

        # Run multiple tests
        self.backtester.kupiec_test(losses, var_forecasts, confidence)
        self.backtester.christoffersen_test(losses, var_forecasts, confidence)

        u = np.random.uniform(0, 1, n)
        v = np.random.uniform(0, 1, n)
        def copula_cdf(u_val, v_val):
            return u_val * v_val
        self.backtester.rosenblatt_pit_test(u, v, copula_cdf)

        # Check history
        summary = self.backtester.get_test_summary()

        self.assertEqual(summary["total_tests"], 3)
        self.assertEqual(summary["tests_by_type"]["kupiec"], 1)
        self.assertEqual(summary["tests_by_type"]["christoffersen"], 1)
        self.assertEqual(summary["tests_by_type"]["rosenblatt_pit"], 1)

    def test_multiple_confidence_levels(self):
        """Test backtests at multiple confidence levels"""
        n = 500
        losses = np.random.normal(0, 1, n)

        for confidence in [0.95, 0.975, 0.99]:
            var_forecasts = np.full(n, stats.norm.ppf(confidence))

            kupiec = self.backtester.kupiec_test(losses, var_forecasts, confidence)
            christoffersen = self.backtester.christoffersen_test(losses, var_forecasts, confidence)

            # Check both run without error
            self.assertEqual(kupiec.confidence_level, confidence)
            self.assertEqual(christoffersen.confidence_level, confidence)

        # Should have 6 tests total (3 confidence levels × 2 test types)
        summary = self.backtester.get_test_summary()
        self.assertEqual(summary["total_tests"], 6)


def run_tests():
    """Run all tests"""
    # Import scipy.stats at module level for tests
    import scipy.stats as stats
    globals()['stats'] = stats

    # Create test suite
    suite = unittest.TestSuite()

    # Add all tests
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestKupiecPOF))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestChristoffersen))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestRosenblattPIT))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestBacktestEngine))

    # Run with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Return success
    return result.wasSuccessful()


if __name__ == "__main__":
    # Import scipy.stats at module level
    import scipy.stats as stats

    success = run_tests()
    sys.exit(0 if success else 1)
