#!/usr/bin/env python3
"""
Test Suite: Entropy Tokenomics Engine

Tests the EntropyTokenomicsEngine for:
1. Shannon entropy computation
2. Risk entropy computation
3. Composite entropy scoring
4. PMC emission calculation
5. Historical tracking
6. Integration with oracle

Author: AEONICA
Version: 1.0
"""

import sys
import unittest
import numpy as np
from datetime import datetime, timedelta

# Add path
sys.path.insert(0, '/Users/dindelinc/Desktop/VELORA_COGNITIION')

from aeonica_core.financial.oracle.entropy_tokenomics import (
    EntropyTokenomicsEngine,
    EntropyMetrics,
    PMCEmissionEvent
)
from aeonica_core.financial.oracle.actuarial_risk import (
    ActuarialRiskEngine,
    RiskMetrics,
    GPDParameters
)


class TestEntropyTokenomicsEngine(unittest.TestCase):
    """Test EntropyTokenomicsEngine"""

    def setUp(self):
        """Set up test engine"""
        self.engine = EntropyTokenomicsEngine(
            base_emission_rate=100.0,
            beta=2.0,
            entropy_window=100,
            n_bins=20
        )

    def test_initialization(self):
        """Test engine initialization"""
        self.assertEqual(self.engine.base_emission_rate, 100.0)
        self.assertEqual(self.engine.beta, 2.0)
        self.assertEqual(self.engine.entropy_window, 100)
        self.assertEqual(self.engine.n_bins, 20)
        self.assertEqual(self.engine.total_pmc_emitted, 0.0)
        self.assertEqual(len(self.engine.entropy_history), 0)

    def test_shannon_entropy_uniform(self):
        """Test Shannon entropy for uniform distribution (max entropy)"""
        # Uniform random distribution should have high entropy
        np.random.seed(42)
        returns = np.random.uniform(-0.01, 0.01, 1000)

        H, diagnostics = self.engine.compute_shannon_entropy(returns)

        # Should be close to 1.0 (max entropy)
        self.assertGreater(H, 0.8)
        self.assertLessEqual(H, 1.0)
        self.assertEqual(diagnostics["n_returns"], 1000)
        self.assertGreater(diagnostics["n_bins_used"], 15)

    def test_shannon_entropy_concentrated(self):
        """Test Shannon entropy for concentrated distribution (low entropy)"""
        # Concentrated distribution around 0 should have low entropy
        np.random.seed(42)
        returns = np.random.normal(0, 0.0001, 1000)

        H, diagnostics = self.engine.compute_shannon_entropy(returns)

        # Should be present (note: with only 20 bins, concentrated normal still spreads)
        self.assertGreaterEqual(H, 0.0)
        self.assertLessEqual(H, 1.0)

        # Compare to uniform - should be lower
        uniform_returns = np.random.uniform(-0.01, 0.01, 1000)
        H_uniform, _ = self.engine.compute_shannon_entropy(uniform_returns)
        self.assertLess(H, H_uniform)  # Concentrated should have less entropy than uniform

    def test_shannon_entropy_insufficient_data(self):
        """Test Shannon entropy with insufficient data"""
        returns = np.array([0.001, 0.002])

        H, diagnostics = self.engine.compute_shannon_entropy(returns)

        # Should return neutral entropy
        self.assertEqual(H, 0.5)
        self.assertEqual(diagnostics["reason"], "insufficient_data")

    def test_risk_entropy_no_risk(self):
        """Test risk entropy with no risk metrics"""
        H, diagnostics = self.engine.compute_risk_entropy(None)

        self.assertEqual(H, 0.5)  # Neutral
        self.assertEqual(diagnostics["reason"], "no_risk_metrics")

    def test_risk_entropy_cat_switch(self):
        """Test risk entropy when cat switch is active"""
        # Create mock risk metrics with cat switch active
        risk_metrics = RiskMetrics(
            timestamp=datetime.utcnow(),
            n_loss_events=100,
            var_95=0.08,
            var_975=0.1,
            var_99=0.12,
            es_95=0.12,
            es_975=0.15,
            es_99=0.18,
            loss_frequency=0.05,
            horizon_seconds=30.0,
            expected_loss=0.01,
            risk_charge=0.02,
            cat_switch_active=True,
            tail_probability=0.5,
            loss_limit=0.2,
            gpd_params=None
        )

        H, diagnostics = self.engine.compute_risk_entropy(risk_metrics)

        # Should be max entropy (1.0)
        self.assertEqual(H, 1.0)
        self.assertEqual(diagnostics["reason"], "cat_switch_active")

    def test_risk_entropy_normal(self):
        """Test risk entropy under normal conditions"""
        risk_metrics = RiskMetrics(
            timestamp=datetime.utcnow(),
            n_loss_events=100,
            var_95=0.008,
            var_975=0.01,
            var_99=0.012,
            es_95=0.012,
            es_975=0.015,
            es_99=0.018,
            loss_frequency=0.01,  # 0.01 losses/sec
            horizon_seconds=30.0,
            expected_loss=0.001,
            risk_charge=0.001,
            cat_switch_active=False,
            tail_probability=0.1,
            loss_limit=0.05,
            gpd_params=None
        )

        H, diagnostics = self.engine.compute_risk_entropy(risk_metrics)

        # Should be moderate (combining tail prob and frequency)
        self.assertGreater(H, 0.0)
        self.assertLess(H, 0.5)
        self.assertEqual(diagnostics["cat_switch"], False)

    def test_topology_entropy_placeholder(self):
        """Test topology entropy (currently placeholder)"""
        H, diagnostics = self.engine.compute_topology_entropy(None)

        # Should return neutral until TDA is implemented
        self.assertEqual(H, 0.5)
        self.assertEqual(diagnostics["reason"], "topology_not_implemented")

    def test_composite_entropy_computation(self):
        """Test composite entropy computation"""
        np.random.seed(42)
        returns = np.random.normal(0, 0.005, 1000)

        risk_metrics = RiskMetrics(
            timestamp=datetime.utcnow(),
            n_loss_events=100,
            var_95=0.008,
            var_975=0.01,
            var_99=0.012,
            es_95=0.012,
            es_975=0.015,
            es_99=0.018,
            loss_frequency=0.01,
            horizon_seconds=30.0,
            expected_loss=0.001,
            risk_charge=0.001,
            cat_switch_active=False,
            tail_probability=0.1,
            loss_limit=0.05,
            gpd_params=None
        )

        metrics = self.engine.compute_entropy_metrics(
            returns=returns,
            risk_metrics=risk_metrics
        )

        # Check all components are computed
        self.assertIsNotNone(metrics.shannon_entropy)
        self.assertIsNotNone(metrics.risk_entropy)
        self.assertIsNotNone(metrics.topology_entropy)
        self.assertIsNotNone(metrics.composite_entropy)

        # Composite should be weighted average
        expected_composite = (
            self.engine.weight_shannon * metrics.shannon_entropy +
            self.engine.weight_risk * metrics.risk_entropy +
            self.engine.weight_topology * metrics.topology_entropy
        )
        self.assertAlmostEqual(metrics.composite_entropy, expected_composite, places=6)

        # Check PMC emission
        self.assertGreater(metrics.pmc_emission_multiplier, 0.0)
        self.assertGreater(metrics.pmc_emission_rate, 0.0)

    def test_pmc_emission_formula(self):
        """Test PMC emission formula: Rate = R_base * (1 - H)^β"""
        np.random.seed(42)
        returns = np.random.normal(0, 0.005, 1000)

        metrics = self.engine.compute_entropy_metrics(returns=returns)

        # Verify formula
        expected_multiplier = (1 - metrics.composite_entropy) ** self.engine.beta
        expected_rate = self.engine.base_emission_rate * expected_multiplier

        self.assertAlmostEqual(metrics.pmc_emission_multiplier, expected_multiplier, places=6)
        self.assertAlmostEqual(metrics.pmc_emission_rate, expected_rate, places=6)

    def test_pmc_emission_extremes(self):
        """Test PMC emission at entropy extremes"""
        # Create engine with beta=2
        engine = EntropyTokenomicsEngine(base_emission_rate=100.0, beta=2.0)

        # High entropy (chaotic) → Low emission
        high_entropy_metrics = EntropyMetrics(
            timestamp=datetime.utcnow(),
            shannon_entropy=0.9,
            risk_entropy=0.9,
            topology_entropy=0.9,
            composite_entropy=0.9
        )
        high_entropy_metrics.pmc_emission_multiplier = (1 - 0.9) ** 2.0
        high_entropy_metrics.pmc_emission_rate = 100.0 * high_entropy_metrics.pmc_emission_multiplier

        # (1 - 0.9)^2 = 0.1^2 = 0.01
        self.assertAlmostEqual(high_entropy_metrics.pmc_emission_multiplier, 0.01, places=6)
        self.assertAlmostEqual(high_entropy_metrics.pmc_emission_rate, 1.0, places=6)

        # Low entropy (stable) → High emission
        low_entropy_metrics = EntropyMetrics(
            timestamp=datetime.utcnow(),
            shannon_entropy=0.1,
            risk_entropy=0.1,
            topology_entropy=0.1,
            composite_entropy=0.1
        )
        low_entropy_metrics.pmc_emission_multiplier = (1 - 0.1) ** 2.0
        low_entropy_metrics.pmc_emission_rate = 100.0 * low_entropy_metrics.pmc_emission_multiplier

        # (1 - 0.1)^2 = 0.9^2 = 0.81
        self.assertAlmostEqual(low_entropy_metrics.pmc_emission_multiplier, 0.81, places=6)
        self.assertAlmostEqual(low_entropy_metrics.pmc_emission_rate, 81.0, places=6)

    def test_entropy_history_tracking(self):
        """Test entropy history is recorded"""
        np.random.seed(42)

        # Compute entropy multiple times
        for i in range(10):
            returns = np.random.normal(0, 0.005, 1000)
            self.engine.compute_entropy_metrics(returns=returns)

        # Check history
        self.assertEqual(len(self.engine.entropy_history), 10)
        self.assertEqual(self.engine.total_computations, 10)

    def test_emission_event_tracking(self):
        """Test PMC emission events are recorded"""
        np.random.seed(42)

        # First computation (no event yet)
        returns1 = np.random.normal(0, 0.005, 1000)
        metrics1 = self.engine.compute_entropy_metrics(returns=returns1)

        self.assertEqual(len(self.engine.emission_events), 0)
        self.assertEqual(self.engine.total_pmc_emitted, 0.0)

        # Second computation (creates first event)
        import time
        time.sleep(0.1)  # Small delay to create time interval
        returns2 = np.random.normal(0, 0.005, 1000)
        metrics2 = self.engine.compute_entropy_metrics(returns=returns2)

        self.assertEqual(len(self.engine.emission_events), 1)
        self.assertGreater(self.engine.total_pmc_emitted, 0.0)

        # Check event details
        event = self.engine.emission_events[0]
        self.assertGreater(event.duration_seconds, 0.0)
        self.assertGreater(event.pmc_earned, 0.0)
        self.assertGreater(event.emission_rate, 0.0)

    def test_cumulative_pmc_earned(self):
        """Test cumulative PMC calculation over time period"""
        np.random.seed(42)

        start_time = datetime.utcnow()

        # Generate events over time
        for i in range(5):
            returns = np.random.normal(0, 0.005, 1000)
            self.engine.compute_entropy_metrics(returns=returns)
            import time
            time.sleep(0.05)

        end_time = datetime.utcnow()

        # Get cumulative PMC
        total_pmc = self.engine.get_cumulative_pmc_earned(start_time, end_time)

        # Should match total emitted
        self.assertAlmostEqual(total_pmc, self.engine.total_pmc_emitted, places=6)
        self.assertGreater(total_pmc, 0.0)

    def test_cumulative_pmc_time_window(self):
        """Test cumulative PMC for specific time window"""
        np.random.seed(42)

        # Event at T=0
        t0 = datetime.utcnow()
        self.engine.compute_entropy_metrics(returns=np.random.normal(0, 0.005, 1000))

        import time
        time.sleep(0.05)

        # Event at T=0.05
        t1 = datetime.utcnow()
        self.engine.compute_entropy_metrics(returns=np.random.normal(0, 0.005, 1000))

        time.sleep(0.05)

        # Event at T=0.10
        t2 = datetime.utcnow()
        self.engine.compute_entropy_metrics(returns=np.random.normal(0, 0.005, 1000))

        time.sleep(0.05)

        # Event at T=0.15
        t3 = datetime.utcnow()
        self.engine.compute_entropy_metrics(returns=np.random.normal(0, 0.005, 1000))

        # Get PMC for middle window only (T=0.05 to T=0.10)
        window_pmc = self.engine.get_cumulative_pmc_earned(t1, t2)

        # Should be less than total
        self.assertGreater(window_pmc, 0.0)
        self.assertLess(window_pmc, self.engine.total_pmc_emitted)

    def test_recent_entropy_window(self):
        """Test recent entropy calculation"""
        np.random.seed(42)

        # Generate events
        for i in range(5):
            returns = np.random.normal(0, 0.005, 1000)
            self.engine.compute_entropy_metrics(returns=returns)
            import time
            time.sleep(0.02)

        # Get recent entropy (last 1 second)
        recent = self.engine.get_recent_entropy(window_seconds=1.0)

        self.assertIsNotNone(recent)
        self.assertGreater(recent, 0.0)
        self.assertLess(recent, 1.0)

    def test_statistics(self):
        """Test engine statistics"""
        np.random.seed(42)

        # Generate some events
        for i in range(3):
            returns = np.random.normal(0, 0.005, 1000)
            self.engine.compute_entropy_metrics(returns=returns)
            import time
            time.sleep(0.02)

        stats = self.engine.get_statistics()

        # Check all fields present
        self.assertEqual(stats["total_computations"], 3)
        self.assertGreater(stats["total_pmc_emitted"], 0.0)
        self.assertEqual(stats["entropy_history_size"], 3)
        self.assertEqual(stats["emission_events"], 2)  # N-1 events
        self.assertIsNotNone(stats["last_computation"])
        self.assertEqual(stats["config"]["base_emission_rate"], 100.0)
        self.assertEqual(stats["config"]["beta"], 2.0)

    def test_reset_emission_tracking(self):
        """Test resetting emission tracking"""
        np.random.seed(42)

        # Generate events
        for i in range(3):
            returns = np.random.normal(0, 0.005, 1000)
            self.engine.compute_entropy_metrics(returns=returns)
            import time
            time.sleep(0.02)

        # Check we have emissions
        self.assertGreater(self.engine.total_pmc_emitted, 0.0)
        self.assertGreater(len(self.engine.emission_events), 0)

        # Reset
        self.engine.reset_emission_tracking()

        # Check cleared
        self.assertEqual(self.engine.total_pmc_emitted, 0.0)
        self.assertEqual(len(self.engine.emission_events), 0)

        # History should still be there
        self.assertEqual(len(self.engine.entropy_history), 3)

    def test_entropy_metrics_serialization(self):
        """Test EntropyMetrics to_dict()"""
        metrics = EntropyMetrics(
            timestamp=datetime(2025, 1, 1, 12, 0, 0),
            shannon_entropy=0.6,
            risk_entropy=0.4,
            topology_entropy=0.5,
            composite_entropy=0.5,
            pmc_emission_multiplier=0.25,
            pmc_emission_rate=25.0,
            n_returns=1000,
            returns_std=0.005,
            tail_probability=0.1
        )

        d = metrics.to_dict()

        self.assertEqual(d["shannon_entropy"], 0.6)
        self.assertEqual(d["risk_entropy"], 0.4)
        self.assertEqual(d["composite_entropy"], 0.5)
        self.assertEqual(d["pmc_emission_rate"], 25.0)
        self.assertEqual(d["n_returns"], 1000)

    def test_emission_event_serialization(self):
        """Test PMCEmissionEvent to_dict()"""
        event = PMCEmissionEvent(
            timestamp=datetime(2025, 1, 1, 12, 0, 0),
            duration_seconds=60.0,
            pmc_earned=1.5,
            emission_rate=90.0,
            composite_entropy=0.3
        )

        d = event.to_dict()

        self.assertEqual(d["duration_seconds"], 60.0)
        self.assertEqual(d["pmc_earned"], 1.5)
        self.assertEqual(d["emission_rate"], 90.0)
        self.assertEqual(d["composite_entropy"], 0.3)


class TestEntropyIntegration(unittest.TestCase):
    """Test entropy integration with oracle"""

    def test_integration_with_oracle(self):
        """Test EntropyTokenomicsEngine integrated with oracle"""
        from aeonica_core.financial.oracle.enhanced_oracle import (
            create_enhanced_oracle
        )
        from aeonica_core.financial.oracle.multi_asset_monitor import (
            AssetMetadata,
            AssetClass,
            AssetRegion
        )

        # Create oracle with entropy enabled
        oracle = create_enhanced_oracle(
            use_gpu=False,
            include_forex=False,
            include_crypto=False,
            include_commodities=False,
            enable_phase=True,
            enable_kalman=True,
            enable_risk=True,
            enable_entropy=True
        )

        # Register test assets
        oracle.register_asset(
            AssetMetadata(
                symbol="TEST/USD",
                asset_class=AssetClass.FOREX,
                region=AssetRegion.GLOBAL
            ),
            source="test"
        )

        # Feed data
        np.random.seed(42)
        base_price = 1.0
        timestamp = datetime.utcnow()

        for i in range(200):
            price = base_price + np.cumsum(np.random.normal(0, 0.005, 1))[0]
            oracle.update_asset("TEST/USD", price, timestamp + timedelta(seconds=i))
            base_price = price

            # Record some losses for risk engine
            if i > 0 and i % 20 == 0:
                loss = abs(np.random.normal(0, 0.01))
                oracle.risk_engine.record_loss(loss, timestamp + timedelta(seconds=i))

        # Get enhanced snapshot
        snapshot = oracle.get_enhanced_snapshot()

        # Check entropy metrics present
        self.assertIsNotNone(snapshot.entropy_metrics)
        self.assertGreater(snapshot.entropy_metrics.composite_entropy, 0.0)
        self.assertGreater(snapshot.entropy_metrics.pmc_emission_rate, 0.0)

        # Check performance
        self.assertGreater(snapshot.entropy_computation_ms, 0.0)
        self.assertLess(snapshot.entropy_computation_ms, 100.0)  # Should be fast

    def test_entropy_in_status(self):
        """Test entropy engine appears in system status"""
        from aeonica_core.financial.oracle.enhanced_oracle import (
            EnhancedMultiAssetOracle
        )

        oracle = EnhancedMultiAssetOracle(
            use_gpu=False,
            auto_register_common_assets=False,
            enable_entropy=True
        )

        status = oracle.get_enhanced_status()

        # Check entropy enabled
        self.assertTrue(status["enhancements"]["entropy_enabled"])
        self.assertIn("entropy_engine", status)

        # Check entropy stats
        entropy_stats = status["entropy_engine"]
        self.assertEqual(entropy_stats["total_computations"], 0)
        self.assertEqual(entropy_stats["total_pmc_emitted"], 0.0)


def run_tests():
    """Run all tests"""
    # Create test suite
    suite = unittest.TestSuite()

    # Add all tests
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestEntropyTokenomicsEngine))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestEntropyIntegration))

    # Run with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Return success
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
