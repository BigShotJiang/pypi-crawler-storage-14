#!/usr/bin/env python3
"""
Test Suite: Systemic Risk Metrics

Tests Adrian-Brunnermeier systemic risk measures:
1. CoVaR & ΔCoVaR
2. MES & LRMES
3. SRISK

Author: AEONICA
Version: 1.0
"""

import sys
import unittest
import numpy as np

# Add path
sys.path.insert(0, '/Users/dindelinc/Desktop/VELORA_COGNITIION')

from aeonica_core.financial.oracle.systemic_risk_metrics import (
    SystemicRiskEngine,
    CoVaRMetrics,
    MESMetrics,
    SRISKMetrics
)


class TestCoVaR(unittest.TestCase):
    """Test CoVaR computation"""

    def setUp(self):
        """Set up systemic risk engine"""
        self.engine = SystemicRiskEngine()
        np.random.seed(42)

    def test_covar_independent_institutions(self):
        """Test CoVaR with independent institutions"""
        n = 1000

        # Independent losses
        losses_i = np.abs(np.random.normal(0, 1, n))
        losses_j = np.abs(np.random.normal(0, 1, n))

        covar = self.engine.compute_covar(
            losses_i=losses_i,
            losses_j=losses_j,
            institution_i="Bank A",
            institution_j="Bank B",
            quantile=0.99
        )

        # Check structure
        self.assertIsInstance(covar, CoVaRMetrics)
        self.assertEqual(covar.institution_i, "Bank A")
        self.assertEqual(covar.institution_j, "Bank B")
        self.assertEqual(covar.quantile, 0.99)

        # ΔCoVaR should be small for independent institutions
        # (distress of i doesn't affect j much)
        self.assertIsNotNone(covar.delta_covar)

        # Correlation should be near zero
        self.assertLess(abs(covar.correlation_ij), 0.2)

    def test_covar_correlated_institutions(self):
        """Test CoVaR with correlated institutions"""
        n = 1000

        # Generate correlated losses
        rho = 0.8
        z = np.random.normal(0, 1, n)
        losses_i = np.abs(z + np.random.normal(0, 0.5, n))
        losses_j = np.abs(rho * z + np.sqrt(1 - rho**2) * np.random.normal(0, 1, n))

        covar = self.engine.compute_covar(
            losses_i=losses_i,
            losses_j=losses_j,
            institution_i="Bank A",
            institution_j="Bank B",
            quantile=0.99,
            tail_dependence_lower=0.5
        )

        # ΔCoVaR should be positive and significant
        # (distress of i increases risk of j)
        self.assertGreater(covar.delta_covar, 0)

        # Correlation should be moderate to high (rho=0.8 target, but sample varies)
        self.assertGreater(covar.correlation_ij, 0.3)

        # CoVaR distress > CoVaR normal
        self.assertGreater(covar.covar_distress, covar.covar_normal)

    def test_covar_quantiles(self):
        """Test CoVaR at different quantiles"""
        n = 500
        losses_i = np.abs(np.random.normal(0, 1, n))
        losses_j = np.abs(np.random.normal(0, 1, n))

        for quantile in [0.95, 0.975, 0.99]:
            covar = self.engine.compute_covar(
                losses_i=losses_i,
                losses_j=losses_j,
                institution_i="A",
                institution_j="B",
                quantile=quantile
            )

            # Check quantile recorded
            self.assertEqual(covar.quantile, quantile)

            # CoVaR values should be positive
            self.assertGreaterEqual(covar.covar_normal, 0)
            self.assertGreaterEqual(covar.covar_distress, 0)

    def test_covar_serialization(self):
        """Test CoVaRMetrics to_dict()"""
        n = 100
        losses_i = np.abs(np.random.normal(0, 1, n))
        losses_j = np.abs(np.random.normal(0, 1, n))

        covar = self.engine.compute_covar(
            losses_i=losses_i,
            losses_j=losses_j,
            institution_i="EUR/USD",
            institution_j="GBP/USD",
            quantile=0.99
        )

        d = covar.to_dict()

        # Check keys
        self.assertIn("institution_i", d)
        self.assertIn("institution_j", d)
        self.assertIn("delta_covar", d)
        self.assertIn("covar_normal", d)
        self.assertIn("covar_distress", d)
        self.assertIn("correlation_ij", d)


class TestMES(unittest.TestCase):
    """Test MES computation"""

    def setUp(self):
        """Set up systemic risk engine"""
        self.engine = SystemicRiskEngine()
        np.random.seed(123)

    def test_mes_basic(self):
        """Test MES with basic setup"""
        n = 1000

        # Generate system losses (market)
        losses_system = np.abs(np.random.normal(0, 1, n))

        # Generate institution losses (correlated with system)
        losses_i = 0.5 * losses_system + 0.5 * np.abs(np.random.normal(0, 1, n))

        mes = self.engine.compute_mes(
            losses_i=losses_i,
            losses_system=losses_system,
            institution="Bank A",
            quantile=0.95
        )

        # Check structure
        self.assertIsInstance(mes, MESMetrics)
        self.assertEqual(mes.institution, "Bank A")
        self.assertEqual(mes.system_quantile, 0.95)

        # MES should be positive
        self.assertGreaterEqual(mes.mes, 0)

        # LRMES should be in [0, 1]
        self.assertGreaterEqual(mes.lrmes, 0)
        self.assertLessEqual(mes.lrmes, 1)

        # Should have tail events
        self.assertGreater(mes.n_tail_events, 0)

    def test_mes_high_beta(self):
        """Test MES with high beta (systemically important)"""
        n = 1000

        # System losses
        losses_system = np.abs(np.random.normal(0, 1, n))

        # High beta institution (amplifies system moves)
        beta = 2.0
        losses_i = beta * losses_system + np.abs(np.random.normal(0, 0.5, n))

        mes = self.engine.compute_mes(
            losses_i=losses_i,
            losses_system=losses_system,
            institution="High Beta Bank",
            quantile=0.95
        )

        # Tail beta should be positive and significant
        self.assertGreater(mes.tail_beta, 0.5)

        # MES should be high (loses more when system crashes)
        self.assertGreater(mes.mes, 0)

    def test_mes_insufficient_tail_events(self):
        """Test MES with insufficient tail events"""
        n = 50  # Small sample

        losses_system = np.abs(np.random.normal(0, 1, n))
        losses_i = np.abs(np.random.normal(0, 1, n))

        mes = self.engine.compute_mes(
            losses_i=losses_i,
            losses_system=losses_system,
            institution="Bank",
            quantile=0.99  # Very high quantile → few tail events
        )

        # Should handle gracefully
        self.assertIsNotNone(mes.mes)
        self.assertGreaterEqual(mes.mes, 0)

    def test_mes_serialization(self):
        """Test MESMetrics to_dict()"""
        n = 500
        losses_system = np.abs(np.random.normal(0, 1, n))
        losses_i = 0.8 * losses_system + 0.2 * np.abs(np.random.normal(0, 1, n))

        mes = self.engine.compute_mes(
            losses_i=losses_i,
            losses_system=losses_system,
            institution="EUR/USD",
            quantile=0.95
        )

        d = mes.to_dict()

        # Check keys
        self.assertIn("institution", d)
        self.assertIn("mes", d)
        self.assertIn("lrmes", d)
        self.assertIn("tail_beta", d)
        self.assertIn("normal_beta", d)


class TestSRISK(unittest.TestCase):
    """Test SRISK computation"""

    def setUp(self):
        """Set up systemic risk engine"""
        self.engine = SystemicRiskEngine()

    def test_srisk_well_capitalized(self):
        """Test SRISK for well-capitalized institution"""
        lrmes = 0.3  # 30% expected loss in crisis
        market_value = 100_000_000  # $100M
        equity = 20_000_000  # $20M
        k = 0.08  # 8% capital requirement

        srisk = self.engine.compute_srisk(
            lrmes=lrmes,
            market_value=market_value,
            equity=equity,
            institution="Bank A",
            k=k
        )

        # Check structure
        self.assertIsInstance(srisk, SRISKMetrics)
        self.assertEqual(srisk.institution, "Bank A")
        self.assertEqual(srisk.k, k)

        # Should be well-capitalized (SRISK ≤ 0)
        # SRISK = 0.08 * 100M - (1 - 0.3) * 20M = 8M - 14M = -6M
        self.assertTrue(srisk.capital_adequate)
        self.assertLessEqual(srisk.srisk, 0)

    def test_srisk_undercapitalized(self):
        """Test SRISK for undercapitalized institution"""
        lrmes = 0.8  # 80% expected loss in crisis (very exposed)
        market_value = 100_000_000  # $100M
        equity = 5_000_000  # $5M (low equity)
        k = 0.08

        srisk = self.engine.compute_srisk(
            lrmes=lrmes,
            market_value=market_value,
            equity=equity,
            institution="Risky Bank",
            k=k
        )

        # Should be undercapitalized (SRISK > 0)
        # SRISK = 0.08 * 100M - (1 - 0.8) * 5M = 8M - 1M = 7M
        self.assertFalse(srisk.capital_adequate)
        self.assertGreater(srisk.srisk, 0)

    def test_srisk_high_leverage(self):
        """Test SRISK with high leverage"""
        lrmes = 0.5
        market_value = 50_000_000
        equity = 2_000_000  # Very low equity → high leverage
        k = 0.10  # Higher capital requirement

        srisk = self.engine.compute_srisk(
            lrmes=lrmes,
            market_value=market_value,
            equity=equity,
            institution="Leveraged Bank",
            k=k,
            leverage=25.0  # 25x leverage
        )

        # High leverage institution
        self.assertEqual(srisk.leverage, 25.0)
        self.assertGreater(srisk.leverage, 10)

    def test_srisk_serialization(self):
        """Test SRISKMetrics to_dict()"""
        srisk = self.engine.compute_srisk(
            lrmes=0.4,
            market_value=100_000_000,
            equity=15_000_000,
            institution="Test Bank",
            k=0.08
        )

        d = srisk.to_dict()

        # Check keys
        self.assertIn("institution", d)
        self.assertIn("srisk", d)
        self.assertIn("capital_adequate", d)
        self.assertIn("market_value", d)
        self.assertIn("equity", d)
        self.assertIn("leverage", d)


class TestSystemicRiskEngine(unittest.TestCase):
    """Test SystemicRiskEngine orchestration"""

    def setUp(self):
        """Set up engine"""
        self.engine = SystemicRiskEngine()

    def test_engine_statistics(self):
        """Test engine statistics tracking"""
        n = 200
        losses_i = np.abs(np.random.normal(0, 1, n))
        losses_j = np.abs(np.random.normal(0, 1, n))
        losses_system = (losses_i + losses_j) / 2

        # Run multiple computations
        self.engine.compute_covar(losses_i, losses_j, "A", "B", 0.99)
        self.engine.compute_mes(losses_i, losses_system, "A", 0.95)
        self.engine.compute_srisk(0.4, 100e6, 20e6, "A")

        stats = self.engine.get_statistics()

        # Should have 3 computations
        self.assertEqual(stats["total_computations"], 3)

    def test_full_systemic_risk_workflow(self):
        """Test complete workflow: CoVaR → MES → SRISK"""
        np.random.seed(456)
        n = 1000

        # Generate correlated institutions
        z = np.random.normal(0, 1, n)
        losses_a = np.abs(z + np.random.normal(0, 0.5, n))
        losses_b = np.abs(0.7 * z + 0.3 * np.random.normal(0, 1, n))
        losses_system = (losses_a + losses_b) / 2

        # 1. Compute CoVaR (spillover from A to B)
        covar = self.engine.compute_covar(
            losses_i=losses_a,
            losses_j=losses_b,
            institution_i="Bank A",
            institution_j="Bank B",
            quantile=0.99
        )

        self.assertGreater(covar.delta_covar, 0)  # A affects B

        # 2. Compute MES (A's loss when system crashes)
        mes = self.engine.compute_mes(
            losses_i=losses_a,
            losses_system=losses_system,
            institution="Bank A",
            quantile=0.95
        )

        self.assertGreater(mes.mes, 0)
        self.assertGreater(mes.lrmes, 0)

        # 3. Compute SRISK (A's capital shortfall)
        srisk = self.engine.compute_srisk(
            lrmes=mes.lrmes,
            market_value=100_000_000,
            equity=15_000_000,
            institution="Bank A",
            k=0.08
        )

        self.assertIsNotNone(srisk.srisk)
        self.assertIsNotNone(srisk.capital_adequate)

        # All three metrics computed
        self.assertEqual(self.engine.computation_count, 3)


def run_tests():
    """Run all tests"""
    # Create test suite
    suite = unittest.TestSuite()

    # Add all tests
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestCoVaR))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestMES))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestSRISK))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestSystemicRiskEngine))

    # Run with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Return success
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
