"""
Performance statistics module for backtesting framework.
"""

from typing import Dict, List, Optional, Tuple, Union
import numpy as np
import pandas as pd
from addict import Dict

from ..core.validators import DataValidator


class PerformanceStats:
    """Comprehensive performance statistics for strategy evaluation."""

    def __init__(self,
                 strategy_returns: pd.Series,
                 benchmark_returns: pd.Series,
                 trading_days: int = 252):
        """
        Initialize performance statistics.

        Args:
            strategy_returns: Daily strategy returns (pct_change format)
            benchmark_returns: Daily benchmark returns (pct_change format)
            trading_days: Number of trading days per year
        """
        self.strategy_returns = self._validate_and_prepare_returns(strategy_returns)
        self.benchmark_returns = self._validate_and_prepare_returns(benchmark_returns)
        self.trading_days = trading_days

        self.stats: Dict = Dict()

    @staticmethod
    def _validate_and_prepare_returns(returns: pd.Series) -> pd.Series:
        """Validate and prepare returns data."""
        DataValidator.validate_price_data(returns.to_frame())

        # Ensure datetime index
        returns.index = pd.to_datetime(returns.index)

        # Handle NaN values
        if returns.isna().any():
            returns = returns.fillna(0)

        return returns

    def calculate_basic_metrics(self) -> None:
        """Calculate basic performance metrics."""
        # Annual return
        cum_return = (1 + self.strategy_returns).cumprod()
        total_days = (cum_return.index[-1] - cum_return.index[0]).days
        years = total_days / 365.25

        self.stats.annual_return = (cum_return.iloc[-1] ** (1/years) - 1) if years > 0 else 0

        # Annual volatility
        self.stats.annual_volatility = self.strategy_returns.std() * np.sqrt(self.trading_days)

        # Sharpe ratio (assuming 0% risk-free rate)
        excess_returns = self.strategy_returns
        if excess_returns.std() > 0:
            self.stats.sharpe_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(self.trading_days)
        else:
            self.stats.sharpe_ratio = 0

    def calculate_risk_metrics(self) -> None:
        """Calculate risk-related metrics."""
        # Maximum drawdown
        cum_strategy = (1 + self.strategy_returns).cumprod()
        self.stats.max_drawdown = self._calculate_max_drawdown(cum_strategy)

        # Drawdown list
        self.stats.max_drawdown_list = self._get_drawdown_events(cum_strategy)

    def calculate_benchmark_metrics(self) -> None:
        """Calculate benchmark-relative metrics."""
        # Excess return (alpha)
        cum_strategy = (1 + self.strategy_returns).cumprod()
        cum_benchmark = (1 + self.benchmark_returns).cumprod()

        # Align series
        common_index = cum_strategy.index.intersection(cum_benchmark.index)
        if len(common_index) > 0:
            aligned_strategy = cum_strategy.reindex(common_index)
            aligned_benchmark = cum_benchmark.reindex(common_index)

            total_years = len(common_index) / self.trading_days
            if total_years > 0:
                strategy_cagr = (aligned_strategy.iloc[-1] / aligned_strategy.iloc[0]) ** (1/total_years) - 1
                benchmark_cagr = (aligned_benchmark.iloc[-1] / aligned_benchmark.iloc[0]) ** (1/total_years) - 1
                self.stats.excess_return = strategy_cagr - benchmark_cagr
            else:
                self.stats.excess_return = 0
        else:
            self.stats.excess_return = 0

        # Information ratio
        excess_returns = self.strategy_returns - self.benchmark_returns
        if excess_returns.std() > 0:
            self.stats.information_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(self.trading_days)
        else:
            self.stats.information_ratio = 0

        # Excess volatility
        self.stats.excess_volatility = excess_returns.std() * np.sqrt(self.trading_days)

    @staticmethod
    def _calculate_max_drawdown(cumulative_returns: pd.Series) -> float:
        """Calculate maximum drawdown."""
        running_max = cumulative_returns.cummax()
        drawdown = cumulative_returns / running_max - 1
        return drawdown.min()

    def _get_drawdown_events(self, cumulative_returns: pd.Series, threshold: float = 0.02) -> pd.DataFrame:
        """
        Get list of drawdown events exceeding threshold.

        Args:
            cumulative_returns: Cumulative returns series
            threshold: Minimum drawdown threshold (default: 2%)

        Returns:
            DataFrame with drawdown events
        """
        running_max = cumulative_returns.cummax()
        drawdown = cumulative_returns / running_max - 1

        # Find drawdown periods
        in_drawdown = drawdown < 0
        drawdown_periods = []

        if in_drawdown.any():
            # Find drawdown start and end points
            drawdown_starts = in_drawdown & ~in_drawdown.shift(1).fillna(False)
            drawdown_ends = (~in_drawdown) & in_drawdown.shift(1).fillna(False)

            starts = drawdown_starts[drawdown_starts].index
            ends = drawdown_ends[drawdown_ends].index

            # If still in drawdown at the end
            if in_drawdown.iloc[-1] and len(ends) == 0:
                ends = pd.DatetimeIndex([cumulative_returns.index[-1]])

            # Pair starts and ends
            if len(starts) > 0 and len(ends) > 0:
                min_len = min(len(starts), len(ends))
                for i in range(min_len):
                    start_date = starts[i]
                    end_date = ends[i] if i < len(ends) else cumulative_returns.index[-1]

                    drawdown_depth = drawdown.loc[start_date:end_date].min()

                    if drawdown_depth < -threshold:
                        duration = (end_date - start_date).days
                        drawdown_periods.append({
                            'begin_dt': start_date.strftime('%Y%m%d'),
                            'end_dt': end_date.strftime('%Y%m%d'),
                            'ratio': drawdown_depth,
                            'datelen': duration
                        })

        if drawdown_periods:
            return pd.DataFrame(drawdown_periods)
        else:
            return pd.DataFrame(columns=['begin_dt', 'end_dt', 'ratio', 'datelen'])

    def calculate_all_metrics(self) -> None:
        """Calculate all performance metrics."""
        self.calculate_basic_metrics()
        self.calculate_risk_metrics()
        self.calculate_benchmark_metrics()

    def get_summary(self) -> Dict:
        """Get summary of all calculated metrics."""
        if not self.stats:
            self.calculate_all_metrics()
        return self.stats


class Stats:
    """Backward compatibility wrapper for PerformanceStats."""

    def __init__(self, sret: pd.Series, bret: pd.Series):
        """
        Initialize for backward compatibility.

        Args:
            sret: Strategy returns
            bret: Benchmark returns
        """
        self._perf_stats = PerformanceStats(sret, bret)
        self.stats = self._perf_stats.stats

    def run(self) -> None:
        """Run performance calculation."""
        self._perf_stats.calculate_all_metrics()
        self.stats = self._perf_stats.stats

    # Backward compatibility for static methods
    @staticmethod
    def _mdd(cum_val: pd.Series) -> int:
        """
        Calculate maximum drawdown dates (backward compatibility).

        Args:
            cum_val: Cumulative values

        Returns:
            Combined begin and end date string
        """
        backmax = cum_val.cummax()
        drawdown = cum_val / backmax - 1.0
        end = drawdown.idxmin()
        begin = cum_val.index.get_loc(backmax[end])
        return int(cum_val.index[begin].strftime('%Y%m%d') + end.strftime('%Y%m%d'))

    @classmethod
    def _get_max_drawdown_list(cls, cum_val: pd.Series, threshold: float = 2e-2) -> pd.DataFrame:
        """
        Get maximum drawdown list (backward compatibility).

        Args:
            cum_val: Cumulative values
            threshold: Drawdown threshold

        Returns:
            DataFrame of drawdown events
        """
        perf_stats = PerformanceStats(pd.Series(index=cum_val.index, data=0), pd.Series(index=cum_val.index, data=0))
        return perf_stats._get_drawdown_events(cum_val, threshold)


# Backward compatibility alias
Stats = Stats
