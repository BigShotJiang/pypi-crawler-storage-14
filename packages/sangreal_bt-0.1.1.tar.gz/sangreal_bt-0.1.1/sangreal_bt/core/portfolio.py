"""
Portfolio management module for the backtesting framework.
"""

from typing import Dict, Tuple, Optional, List
import pandas as pd
import numpy as np

from ..utils.helpers import normalize_weights, safe_divide


class PortfolioManager:
    """Manages portfolio positions, weights, and performance."""

    def __init__(self, config):
        """
        Initialize portfolio manager.

        Args:
            config: BacktestConfig instance
        """
        self.config = config
        self.positions: Dict[str, pd.DataFrame] = {
            'asset': pd.DataFrame(),
            'future': pd.DataFrame()
        }
        self.current_weights: Dict[str, pd.DataFrame] = {
            'asset': pd.DataFrame(),
            'future': pd.DataFrame()
        }
        self._universe_value_cache: Dict[str, pd.DataFrame] = {}

    def set_positions(self, asset_positions: pd.DataFrame, future_positions: pd.DataFrame) -> None:
        """
        Set portfolio positions.

        Args:
            asset_positions: Asset positions DataFrame
            future_positions: Future positions DataFrame
        """
        self.positions['asset'] = asset_positions.copy()
        self.positions['future'] = future_positions.copy()

    def set_weights(self, asset_weights: pd.DataFrame, future_weights: pd.DataFrame) -> None:
        """
        Set portfolio weights.

        Args:
            asset_weights: Asset weights DataFrame
            future_weights: Future weights DataFrame
        """
        self.current_weights['asset'] = asset_weights.copy()
        self.current_weights['future'] = future_weights.copy()

    def get_universe_value(self, price_data: pd.DataFrame, signal_type: str) -> pd.DataFrame:
        """
        Calculate universe returns for signal.

        Args:
            price_data: Price data DataFrame
            signal_type: Type of signal ('asset' or 'future')

        Returns:
            DataFrame of universe returns
        """
        if signal_type in self._universe_value_cache:
            return self._universe_value_cache[signal_type]

        signal = self.current_weights[signal_type]
        if signal.empty:
            return pd.DataFrame()

        # Reindex price data to match signal columns
        df = price_data.reindex(signal.columns, axis=1)

        if self.config.matching_type == "next_bar":
            # Combine close and next day's open for accurate returns
            close_data = df.copy()
            # Get next day's open data (will be provided by calling function)
            open_data = df.reindex(signal.index)
            combined_data = pd.concat([close_data, open_data], axis=0, sort=False)
            combined_data.sort_index(inplace=True)
            df = combined_data

        # Calculate returns
        returns = df.pct_change()
        returns[np.isinf(returns)] = 0
        returns = returns.shift(-1).fillna(0)

        self._universe_value_cache[signal_type] = returns
        return returns

    def calculate_portfolio_returns(self,
                                  signal: pd.DataFrame,
                                  commission_factor: Tuple[float, float],
                                  price_returns: pd.DataFrame) -> Tuple[pd.Series, pd.DataFrame]:
        """
        Calculate portfolio returns including commission.

        Args:
            signal: Portfolio weights signal
            commission_factor: Commission rates (long, short)
            price_returns: Price returns for universe

        Returns:
            Tuple of (cumulative returns, final holdings)
        """
        if signal.empty:
            return pd.Series(dtype=float), pd.DataFrame(columns=["date", "stockid", "weight"])

        # Get trading dates
        trade_dates = price_returns.index

        # Process signal
        signal_filled = signal.fillna(0)

        # Calculate cumulative returns for rebalancing
        cum_returns = np.exp(np.log1p(price_returns.shift(1).fillna(0)).cumsum())
        signal_all = signal_filled.reindex(index=trade_dates).ffill()

        # Update weights during holding period
        signal_all = signal_all * cum_returns

        # Get weight adjustment factor
        weight_factor = cum_returns.reindex(signal_filled.index).reindex(signal_all.index).ffill()
        signal_all = safe_divide(signal_all, weight_factor)

        # Normalize weights
        signal_all = normalize_weights(signal_all)

        # Get final holdings
        if not signal_all.empty:
            last_date = signal_all.iloc[-1].name
            holdings = signal_all.iloc[-1].to_frame("weight").dropna()
            holdings.index.name = "stockid"
            holdings.reset_index(inplace=True)
            holdings.sort_values("weight", ascending=False, inplace=True)
            holdings["date"] = last_date
            holdings = holdings[holdings.weight.abs() > 1e-6].copy()
        else:
            holdings = pd.DataFrame(columns=["date", "stockid", "weight"])

        # Calculate portfolio returns
        portfolio_returns = (signal_all * price_returns).sum(axis=1)
        portfolio_returns = portfolio_returns.shift(1).fillna(0)

        # Apply commission
        commission_costs = self._calculate_commission(signal_all, signal_filled, commission_factor, trade_dates)
        portfolio_returns += commission_costs

        # Convert to cumulative returns
        cumulative_returns = np.exp(np.log1p(portfolio_returns).cumsum())
        cumulative_returns = cumulative_returns[cumulative_returns.index.second == 0]

        return cumulative_returns, holdings

    def _calculate_commission(self,
                             signal_all: pd.DataFrame,
                             signal_filled: pd.DataFrame,
                             commission_factor: Tuple[float, float],
                             trade_dates: pd.DatetimeIndex) -> pd.Series:
        """
        Calculate commission costs.

        Args:
            signal_all: All portfolio weights
            signal_filled: Filled signal weights
            commission_factor: Commission rates (long, short)
            trade_dates: Trading dates

        Returns:
            Commission costs Series
        """
        # Calculate weight changes
        weight_changes = signal_all.fillna(0).diff().reindex(signal_filled.index)

        # Separate long and short changes
        long_changes = (weight_changes + weight_changes.abs()) / 2
        short_changes = (weight_changes.abs() - weight_changes) / 2

        # Calculate commission costs
        commission_costs = (
            -1 * long_changes.sum(axis=1) * commission_factor[0]
            - short_changes.sum(axis=1) * commission_factor[1]
        ).fillna(0)

        commission_costs = commission_costs.reindex(trade_dates).fillna(0)
        return commission_costs

    def calculate_hedge_returns(self, long_returns: pd.Series, short_returns: pd.Series) -> pd.Series:
        """
        Calculate hedged returns from long and short positions.

        Args:
            long_returns: Long position returns
            short_returns: Short position returns

        Returns:
            Hedged returns Series
        """
        # Handle empty cases
        if short_returns.empty:
            short_returns = long_returns.copy()
            short_returns.iloc[:] = 1

        if long_returns.empty:
            long_returns = short_returns.copy()
            long_returns.iloc[:] = 1

        # Get trading dates
        trade_dates = self.current_weights['asset'].index
        if self.config.matching_type == "next_bar":
            trade_dates -= self.config.SHIFT_TIME

        trade_dates = trade_dates[trade_dates <= self.config.end_dt]

        # Calculate adjustment factors
        long_adj_factor = long_returns.reindex(trade_dates).reindex(long_returns.index).ffill().fillna(1)
        short_adj_factor = short_returns.reindex(trade_dates).reindex(short_returns.index).ffill().fillna(1)

        # Adjust returns for cash flows
        long_adj = safe_divide(long_returns, long_adj_factor)
        short_adj = safe_divide(short_returns, short_adj_factor)

        # Calculate hedge ratio
        ratio = safe_divide(short_adj, long_adj).shift(1)

        # Calculate hedged returns
        long_returns_change = long_returns.pct_change().fillna(0)
        short_returns_change = short_returns.pct_change().fillna(0)

        hedge_returns = (
            long_returns_change + short_returns_change * ratio
        ) / safe_divide(1 + ratio - safe_divide(1, long_adj.shift(1)))

        hedge_returns = (1 + hedge_returns).fillna(1).cumprod()
        return hedge_returns

    def get_turnover(self, signal_type: str, total_days: int) -> float:
        """
        Calculate portfolio turnover rate.

        Args:
            signal_type: Type of signal ('asset' or 'future')
            total_days: Total number of days in the period

        Returns:
            Annualized turnover rate
        """
        signal = self.current_weights[signal_type]
        if signal.empty:
            return 0.0

        # Remove cash column if present
        signal_clean = signal.drop(["cash"], axis=1, errors="ignore")

        # Calculate turnover
        turnover = signal_clean.fillna(0).diff().abs().sum(axis=1).sum()
        return turnover / total_days * 252 if total_days > 0 else 0.0

    def clear_cache(self) -> None:
        """Clear cached calculations."""
        self._universe_value_cache.clear()