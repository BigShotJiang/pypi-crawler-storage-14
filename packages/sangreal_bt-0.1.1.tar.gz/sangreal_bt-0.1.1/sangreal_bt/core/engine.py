"""
Core backtesting engine for the framework.
"""

from typing import Dict, Optional, Tuple, Union
import pandas as pd
import numpy as np
from addict import Dict

from .config import BacktestConfig
from .portfolio import PortfolioManager
from .validators import DataValidator
from ..datafeed.datafeed import DataBase
from ..utils.helpers import clean_signal_data, prepare_three_column_signal, ensure_datetime_index, safe_divide


class BacktestEngine:
    """Core backtesting engine that orchestrates the backtesting process."""

    def __init__(self, config: Optional[BacktestConfig] = None):
        """
        Initialize backtesting engine.

        Args:
            config: Backtest configuration. If None, uses default config.
        """
        self.config = config or BacktestConfig()
        self.portfolio_manager = PortfolioManager(self.config)
        self.datafeed: Optional[DataBase] = None
        self.signals: Dict[str, pd.DataFrame] = {"asset": pd.DataFrame(), "future": pd.DataFrame()}
        self.results: Dict = Dict()

    def set_config(self, config: BacktestConfig) -> None:
        """
        Update backtesting configuration.

        Args:
            config: New configuration
        """
        self.config = config
        self.portfolio_manager.config = config

    def add_data(self, datafeed: DataBase) -> None:
        """
        Add market data to the engine.

        Args:
            datafeed: Data source containing market data
        """
        if not isinstance(datafeed, DataBase):
            raise TypeError("Data must be a DataBase instance")

        self.datafeed = datafeed

        # Adjust date range based on data availability
        data_start, data_end = datafeed.get_date_range()
        # Ensure both are pandas Timestamps for comparison
        if isinstance(self.config.begin_dt, str):
            self.config.begin_dt = pd.to_datetime(self.config.begin_dt)
        if isinstance(self.config.end_dt, str):
            self.config.end_dt = pd.to_datetime(self.config.end_dt)

        self.config.begin_dt = max(self.config.begin_dt, data_start)
        self.config.end_dt = min(self.config.end_dt, data_end)

    def add_signal(self, signal: pd.DataFrame) -> None:
        """
        Add trading signals to the engine.

        Args:
            signal: Trading signals DataFrame. Can be either:
                   - Wide format: datetime index, stock symbols as columns
                   - Long format: columns 'date', 'stockid', 'weight'
        """
        DataValidator.validate_signal_data(signal)

        # Clean and prepare signal data
        signal_clean = clean_signal_data(signal)

        # Convert long format to wide format if needed
        if isinstance(signal_clean.index[0], (int, np.integer)):
            signal_wide = prepare_three_column_signal(signal_clean)
        else:
            signal_wide = signal_clean

        # Store original signal for results
        signal_long = signal_wide.unstack().reset_index()
        signal_long.columns = ["stockid", "date", "weight"]
        self.results.signal = signal_long

        # Separate asset and future signals
        signal_columns = signal_wide.columns
        asset_columns = signal_columns[~signal_columns.isin(self.config.INDEX_FUTURES)]
        future_columns = signal_columns[signal_columns.isin(self.config.INDEX_FUTURES)]

        asset_signal = signal_wide[asset_columns].copy()
        future_signal = signal_wide[future_columns].copy()

        # Only add cash weights if there are positions
        if not asset_signal.empty:
            asset_signal = self._add_cash_weights(asset_signal)
        if not future_signal.empty:
            future_signal = self._add_cash_weights(future_signal)

        # Apply time shift for next_bar matching
        if self.config.matching_type == "next_bar":
            asset_signal.index = asset_signal.index + self.config.SHIFT_TIME
            future_signal.index = future_signal.index + self.config.SHIFT_TIME

        self.signals["asset"] = asset_signal
        self.signals["future"] = future_signal

        self.portfolio_manager.set_weights(asset_signal, future_signal)

    def _add_cash_weights(self, signal: pd.DataFrame) -> pd.DataFrame:
        """
        Add cash weights to ensure sum of absolute weights equals 1.

        Args:
            signal: Signal DataFrame

        Returns:
            Signal with cash weights added
        """
        signal_sum = signal.sum(axis=1)
        cash_weights = 1 * np.sign(signal_sum + 1e-8) - signal_sum
        signal_with_cash = signal.copy()
        signal_with_cash["cash"] = cash_weights
        return signal_with_cash

    def run(self, calculate_stats: bool = True, calculate_relative: bool = False) -> None:
        """
        Run the backtest.

        Args:
            calculate_stats: Whether to calculate performance statistics
            calculate_relative: Whether to calculate relative returns vs benchmark
        """
        self._validate_ready_state()

        # Prepare data
        self._prepare_market_data()

        # Calculate returns for each signal type
        asset_returns, asset_holdings = self._calculate_signal_returns("asset", self.config.commission)
        future_returns, future_holdings = self._calculate_signal_returns("future", self.config.fcommission)

        # Calculate hedged returns
        hedge_returns = self.portfolio_manager.calculate_hedge_returns(asset_returns, future_returns)

        # Combine all returns
        nav_data = self._combine_returns(asset_returns, future_returns, hedge_returns)

        # Calculate benchmark
        self._add_benchmark(nav_data)

        # Calculate relative returns if requested
        if calculate_relative:
            self._calculate_relative_returns(nav_data)

        # Store results
        self.results.nav = nav_data
        self.results.holdings = pd.concat([asset_holdings, future_holdings], axis=0)
        self.results.holdings = self.results.holdings[self.results.holdings["stockid"] != "cash"].copy()
        self.results.benchmark = self.config.benchmark

        # Calculate performance statistics
        if calculate_stats:
            self._calculate_performance_stats(nav_data)

        # Calculate turnover
        self._calculate_turnover(nav_data)

    def _validate_ready_state(self) -> None:
        """Validate that engine is ready to run backtest."""
        if self.datafeed is None:
            raise ValueError("No data feed provided. Call add_data() first.")

        if not any(not signal.empty for signal in self.signals.values()):
            raise ValueError("No signals provided. Call add_signal() first.")

    def _prepare_market_data(self) -> None:
        """Prepare market data for backtesting."""
        if self.datafeed is None:
            raise ValueError("Data feed not set")

        # Get price data
        self.open_prices = self.datafeed.get_price_data('open')
        self.close_prices = self.datafeed.get_price_data('close')

        # Filter by date range
        self.open_prices = self.open_prices.loc[self.config.begin_dt:self.config.end_dt].copy()
        self.close_prices = self.close_prices.loc[self.config.begin_dt:self.config.end_dt].copy()

        # Prepare open prices (shift for next_bar matching)
        self.open_prices = self.open_prices.shift(-1)
        self.open_prices.index = self.open_prices.index + self.config.SHIFT_TIME

        # Add cash as constant price
        self.open_prices["cash"] = 1.0
        self.close_prices["cash"] = 1.0

    def _calculate_signal_returns(self, signal_type: str, commission: Tuple[float, float]) -> Tuple[pd.Series, pd.DataFrame]:
        """
        Calculate returns for a specific signal type.

        Args:
            signal_type: Type of signal ('asset' or 'future')
            commission: Commission rates (long, short)

        Returns:
            Tuple of (cumulative returns, final holdings)
        """
        signal = self.signals[signal_type]
        if signal.empty:
            return pd.Series(dtype=float), pd.DataFrame(columns=["date", "stockid", "weight"])

        # Calculate universe returns
        price_returns = self.portfolio_manager.get_universe_value(self.close_prices, signal_type)

        # Calculate portfolio returns
        returns, holdings = self.portfolio_manager.calculate_portfolio_returns(
            signal, commission, price_returns
        )

        return returns, holdings

    def _combine_returns(self, asset_returns: pd.Series, future_returns: pd.Series, hedge_returns: pd.Series) -> pd.DataFrame:
        """Combine all return series into a single DataFrame."""
        returns_dict = {
            "asset": asset_returns,
            "future": future_returns,
            "hedge": hedge_returns
        }

        # Filter out empty series and combine
        valid_returns = {k: v for k, v in returns_dict.items() if not v.empty}

        if not valid_returns:
            return pd.DataFrame()

        return pd.concat(valid_returns, axis=1, sort=False)

    def _add_benchmark(self, nav_data: pd.DataFrame) -> None:
        """Add benchmark returns to nav data."""
        if self.config.benchmark:
            # Use provided benchmark
            benchmark_data = self.close_prices.reindex([self.config.benchmark], axis=1)
            if benchmark_data.empty:
                raise ValueError("Invalid benchmark symbol")

            benchmark_nav = benchmark_data / benchmark_data.dropna().iloc[0]
            nav_data[self.config.benchmark] = benchmark_nav.iloc[:, 0]
        else:
            # Use fixed rate as benchmark
            daily_return = np.exp(np.log1p(self.config.fixed_rate) / 252) - 1
            benchmark_nav = pd.Series(1.0, index=nav_data.index, dtype=float)
            benchmark_nav = (1 + daily_return).cumprod()
            benchmark_nav.iloc[0] = 1.0
            nav_data["benchmark"] = benchmark_nav

            # Update config.benchmark for consistency
            self.config.benchmark = "benchmark"

    def _calculate_relative_returns(self, nav_data: pd.DataFrame) -> None:
        """Calculate returns relative to benchmark."""
        if "hedge" not in nav_data.columns:
            return

        # Get trading dates from signal
        trade_dates = self.results.signal["date"]
        trade_dates = trade_dates[
            (trade_dates <= self.config.end_dt) & (trade_dates >= self.config.begin_dt)
        ].unique()

        if len(trade_dates) > 0:
            nav_data["relative"] = self._get_relative_returns(
                nav_data["hedge"], nav_data[self.config.benchmark], trade_dates
            )

    @staticmethod
    def _get_relative_returns(strategy: pd.Series, benchmark: pd.Series, trade_dates: list) -> pd.Series:
        """
        Calculate relative returns between strategy and benchmark.

        Args:
            strategy: Strategy cumulative returns
            benchmark: Benchmark cumulative returns
            trade_dates: List of trading dates

        Returns:
            Relative returns Series
        """
        trade_dates = pd.to_datetime(trade_dates)

        # Calculate adjustment factors for cash flows
        strategy_adj_factor = strategy.reindex(trade_dates).reindex(strategy.index).ffill().fillna(1)
        benchmark_adj_factor = benchmark.reindex(trade_dates).reindex(benchmark.index).ffill().fillna(1)

        # Adjust for cash flows
        strategy_adj = safe_divide(strategy, strategy_adj_factor)
        benchmark_adj = safe_divide(benchmark, benchmark_adj_factor)

        # Calculate relative returns
        relative_returns = (strategy_adj - benchmark_adj + 1).pct_change().fillna(0)

        # Fix trading dates returns
        trading_returns = (
            strategy.pct_change().fillna(0) - benchmark.pct_change().fillna(0)
        ).loc[trade_dates]

        relative_returns.loc[trade_dates] = trading_returns

        # Convert to cumulative
        return (relative_returns + 1).cumprod()

    def _calculate_performance_stats(self, nav_data: pd.DataFrame) -> None:
        """Calculate performance statistics."""
        if "hedge" not in nav_data.columns:
            return

        # Calculate daily returns
        strategy_returns = nav_data["hedge"].pct_change().fillna(0)
        benchmark_returns = nav_data[self.config.benchmark].pct_change().fillna(0)

        # Import here to avoid circular imports
        from ..stats.stats import PerformanceStats

        # Calculate statistics
        stats_calculator = PerformanceStats(strategy_returns, benchmark_returns)
        stats_calculator.calculate_all_metrics()

        self.results.stats = stats_calculator.stats

    def _calculate_turnover(self, nav_data: pd.DataFrame) -> None:
        """Calculate portfolio turnover."""
        total_days = len(nav_data)

        asset_turnover = self.portfolio_manager.get_turnover("asset", total_days)
        future_turnover = self.portfolio_manager.get_turnover("future", total_days)

        self.results.stats.turnover = asset_turnover + future_turnover

    def get_results(self) -> Dict:
        """Get backtest results."""
        if not self.results:
            raise ValueError("No results available. Run backtest first.")
        return self.results