"""
Data validation utilities for the backtesting framework.
"""

import pandas as pd
import numpy as np
from typing import Union, Optional, Set


class DataValidationError(Exception):
    """Custom exception for data validation errors."""
    pass


class DataValidator:
    """Utility class for validating input data."""

    @staticmethod
    def validate_signal_data(signal: pd.DataFrame) -> None:
        """
        Validate signal DataFrame format.

        Args:
            signal: DataFrame containing trading signals

        Raises:
            DataValidationError: If signal format is invalid
        """
        if not isinstance(signal, pd.DataFrame):
            raise DataValidationError("Signal data must be a DataFrame")

        if signal.empty:
            raise DataValidationError("Signal data cannot be empty")

        # Check if it's in three-column format (date, stockid, weight)
        if isinstance(signal.index[0], (int, np.integer)):
            required_columns = {"date", "stockid", "weight"}
            signal_columns = set(signal.columns.str.lower())

            if not required_columns.issubset(signal_columns):
                raise DataValidationError(
                    f"Signal must contain columns: {required_columns}. "
                    f"Found: {signal_columns}"
                )

    @staticmethod
    def validate_price_data(price_data: pd.DataFrame) -> None:
        """
        Validate price DataFrame format.

        Args:
            price_data: DataFrame containing price data

        Raises:
            DataValidationError: If price data format is invalid
        """
        if not isinstance(price_data, pd.DataFrame):
            raise DataValidationError("Price data must be a DataFrame")

        if price_data.empty:
            raise DataValidationError("Price data cannot be empty")

        # Check if index is datetime
        if not isinstance(price_data.index, pd.DatetimeIndex):
            raise DataValidationError("Price data index must be DatetimeIndex")

    @staticmethod
    def validate_commission(commission: tuple, name: str = "commission") -> None:
        """
        Validate commission tuple format.

        Args:
            commission: Commission tuple (long_rate, short_rate)
            name: Name of the commission parameter for error messages

        Raises:
            DataValidationError: If commission format is invalid
        """
        if not isinstance(commission, (tuple, list)) or len(commission) != 2:
            raise DataValidationError(f"{name} must be tuple like (0.1, 0.1)")

        if not all(isinstance(rate, (int, float)) for rate in commission):
            raise DataValidationError(f"{name} values must be numeric")

    @staticmethod
    def validate_date_range(begin_dt: pd.Timestamp, end_dt: pd.Timestamp) -> None:
        """
        Validate date range.

        Args:
            begin_dt: Start date
            end_dt: End date

        Raises:
            DataValidationError: If date range is invalid
        """
        if begin_dt >= end_dt:
            raise DataValidationError("begin_dt must be earlier than end_dt")

    @staticmethod
    def validate_matching_type(matching_type: str) -> None:
        """
        Validate matching type parameter.

        Args:
            matching_type: Order matching type

        Raises:
            DataValidationError: If matching type is invalid
        """
        if matching_type not in ("next_bar", "current_bar"):
            raise DataValidationError("matching_type must be 'next_bar' or 'current_bar'")

    @staticmethod
    def validate_portfolio_weights(weights: pd.Series) -> None:
        """
        Validate portfolio weights.

        Args:
            weights: Series of portfolio weights

        Raises:
            DataValidationError: If weights are invalid
        """
        if not isinstance(weights, pd.Series):
            raise DataValidationError("Weights must be a pandas Series")

        # Check for extreme weights
        if weights.abs().max() > 10:  # Warn about extremely large weights
            import warnings
            warnings.warn("Portfolio weights contain extreme values (>1000%)")

        # Check for NaN values
        if weights.isna().any():
            raise DataValidationError("Portfolio weights cannot contain NaN values")