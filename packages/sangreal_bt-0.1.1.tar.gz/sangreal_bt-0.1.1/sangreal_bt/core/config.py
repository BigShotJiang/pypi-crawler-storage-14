"""
Configuration management for backtesting framework.
"""

from dataclasses import dataclass, field
from typing import Tuple, Optional
import datetime as dt
import pandas as pd
from pandas.tseries.offsets import Second


@dataclass
class BacktestConfig:
    """Configuration for backtesting parameters."""

    begin_dt: pd.Timestamp = field(
        default_factory=lambda: pd.to_datetime("20010101"),
        metadata={"description": "Backtest start date"}
    )

    end_dt: pd.Timestamp = field(
        default_factory=lambda: pd.to_datetime(dt.date.today()),
        metadata={"description": "Backtest end date"}
    )

    matching_type: str = field(
        default="next_bar",
        metadata={"description": "Order matching type: 'next_bar' or 'current_bar'"}
    )

    benchmark: str = field(
        default="",
        metadata={"description": "Benchmark symbol"}
    )

    commission: Tuple[float, float] = field(
        default=(0.0, 0.0),
        metadata={"description": "Stock commission (long, short)"}
    )

    fcommission: Tuple[float, float] = field(
        default=(0.0, 0.0),
        metadata={"description": "Future commission (long, short)"}
    )

    fixed_rate: float = field(
        default=4e-2,
        metadata={"description": "Fixed annual interest rate for benchmark"}
    )

    # Time shift constants
    SHIFT_TIME = Second(1)

    # Index futures symbols
    INDEX_FUTURES = (
        "IH", "IF", "IC", "IM",  # 股指期货
        "TS", "TF", "T", "TL",   # 国债期货
    )

    def __post_init__(self):
        """Validate configuration after initialization."""
        self._validate_commission()
        self._validate_matching_type()
        self._validate_dates()

    def _validate_commission(self) -> None:
        """Validate commission tuples."""
        if len(self.commission) != 2:
            raise ValueError("commission must be tuple like (0.1, 0.1)!")
        if len(self.fcommission) != 2:
            raise ValueError("fcommission must be tuple like (0.1, 0.1)!")

    def _validate_matching_type(self) -> None:
        """Validate matching type."""
        if self.matching_type not in ("next_bar", "current_bar"):
            raise ValueError("matching_type must be 'next_bar' or 'current_bar'")

    def _validate_dates(self) -> None:
        """Validate date range."""
        if self.begin_dt >= self.end_dt:
            raise ValueError("begin_dt must be earlier than end_dt")

    @classmethod
    def from_dict(cls, config_dict: dict) -> "BacktestConfig":
        """Create config from dictionary."""
        # Convert string dates to timestamps
        if "begin_dt" in config_dict:
            config_dict["begin_dt"] = pd.to_datetime(config_dict["begin_dt"])
        if "end_dt" in config_dict:
            config_dict["end_dt"] = pd.to_datetime(config_dict["end_dt"])

        return cls(**config_dict)