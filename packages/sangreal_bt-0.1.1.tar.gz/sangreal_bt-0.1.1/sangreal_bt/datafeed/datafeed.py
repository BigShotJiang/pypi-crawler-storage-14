"""
Data feed module for handling market data.
"""

from abc import ABC, abstractmethod
from typing import Optional, Union, Dict, Any
import pandas as pd
import numpy as np

from ..core.validators import DataValidator


class DataBase(ABC):
    """Abstract base class for data sources."""

    REQUIRED_COLUMNS = {'date', 'stockid', 'open', 'close'}

    def __init__(self):
        self.open: Optional[pd.DataFrame] = None
        self.close: Optional[pd.DataFrame] = None
        self._validated: bool = False

    @abstractmethod
    def load_data(self, *args, **kwargs) -> None:
        """Load data from source."""
        pass

    def _validate_data_structure(self, data: pd.DataFrame) -> None:
        """Validate data structure."""
        DataValidator.validate_price_data(data)

    def get_price_data(self, price_type: str = 'close') -> pd.DataFrame:
        """
        Get price data for specified type.

        Args:
            price_type: Type of price data ('open' or 'close')

        Returns:
            Price data DataFrame

        Raises:
            ValueError: If price_type is invalid
            AttributeError: If data hasn't been loaded
        """
        if price_type not in ['open', 'close']:
            raise ValueError("price_type must be 'open' or 'close'")

        if not self._validated:
            raise AttributeError("Data hasn't been properly loaded")

        price_data = getattr(self, price_type)
        if price_data is None:
            raise AttributeError(f"{price_type} price data not available")

        return price_data.copy()

    def get_date_range(self) -> tuple:
        """Get the date range of loaded data."""
        if not self._validated:
            raise AttributeError("Data hasn't been properly loaded")

        if self.open is not None and not self.open.empty:
            return self.open.index[0], self.open.index[-1]
        elif self.close is not None and not self.close.empty:
            return self.close.index[0], self.close.index[-1]
        else:
            raise ValueError("No data available")

    def get_symbols(self) -> list:
        """Get list of available symbols."""
        if not self._validated:
            raise AttributeError("Data hasn't been properly loaded")

        if self.open is not None:
            return self.open.columns.tolist()
        elif self.close is not None:
            return self.close.columns.tolist()
        else:
            return []


class DataPandas(DataBase):
    """Data source for pandas DataFrame input."""

    def __init__(self, data: pd.DataFrame):
        """
        Initialize with pandas DataFrame.

        Args:
            data: DataFrame containing OHLC data with columns:
                  date, stockid, open, close

        Example:
            >>> data = pd.DataFrame({
            ...     'date': ['2023-01-01', '2023-01-01'],
            ...     'stockid': ['AAPL', 'GOOGL'],
            ...     'open': [100.0, 150.0],
            ...     'close': [105.0, 155.0]
            ... })
            >>> datafeed = DataPandas(data)
        """
        super().__init__()
        self._raw_data = data
        self.load_data()

    def load_data(self) -> None:
        """Load and process data from DataFrame with optimized memory usage."""
        if not isinstance(self._raw_data, pd.DataFrame):
            raise ValueError('data must be DataFrame')

        # Create a copy to avoid modifying original data
        data = self._raw_data.copy()

        # Normalize column names
        data.columns = [c.lower() for c in data.columns]

        # Validate required columns
        missing_columns = self.REQUIRED_COLUMNS - set(data.columns)
        if missing_columns:
            raise ValueError(f'data must contain columns: {missing_columns}')

        # Standardize column names
        data.rename({'date': 'trade_dt', 'stockid': 'sid'}, axis=1, inplace=True)

        # Convert dates to datetime
        data['trade_dt'] = pd.to_datetime(data['trade_dt'])

        # Optimized pivot using pandas' more efficient methods
        try:
            # Try faster pivot method for newer pandas versions
            self.open = pd.pivot_table(data, values='open', index='trade_dt', columns='sid', aggfunc='first')
            self.close = pd.pivot_table(data, values='close', index='trade_dt', columns='sid', aggfunc='first')
        except Exception:
            # Fallback to standard pivot
            self.open = data.pivot(values='open', index='trade_dt', columns='sid')
            self.close = data.pivot(values='close', index='trade_dt', columns='sid')

        # Sort by date
        self.open.sort_index(inplace=True)
        self.close.sort_index(inplace=True)

        # Optimize memory usage
        from ..utils.optimize import MemoryOptimizer
        self.open = MemoryOptimizer.reduce_memory_usage(self.open, verbose=False)
        self.close = MemoryOptimizer.reduce_memory_usage(self.close, verbose=False)

        # Validate processed data
        self._validate_data_structure(self.open)
        self._validate_data_structure(self.close)

        self._validated = True

    def add_price_data(self, price_type: str, data: pd.DataFrame) -> None:
        """
        Add additional price data.

        Args:
            price_type: Type of price ('open' or 'close')
            data: Price data DataFrame
        """
        if price_type not in ['open', 'close']:
            raise ValueError("price_type must be 'open' or 'close'")

        DataValidator.validate_price_data(data)
        setattr(self, price_type, data)


class DataCSV(DataBase):
    """Data source for CSV files."""

    def __init__(self, file_path: str, **kwargs):
        """
        Initialize with CSV file path.

        Args:
            file_path: Path to CSV file
            **kwargs: Additional arguments for pd.read_csv
        """
        super().__init__()
        self.file_path = file_path
        self.read_kwargs = kwargs

    def load_data(self) -> None:
        """Load data from CSV file."""
        data = pd.read_csv(self.file_path, **self.read_kwargs)
        pandas_datafeed = DataPandas(data)

        self.open = pandas_datafeed.open
        self.close = pandas_datafeed.close
        self._validated = True


# Backward compatibility aliases
DataBase = DataBase
DataPandas = DataPandas
