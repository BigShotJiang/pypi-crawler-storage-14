"""
Helper functions for the backtesting framework.
"""

import pandas as pd
import numpy as np
from typing import Union


def normalize_weights(weights: pd.DataFrame, axis: int = 1) -> pd.DataFrame:
    """
    Normalize portfolio weights to sum to absolute value of 1.

    Args:
        weights: DataFrame of portfolio weights
        axis: Axis along which to normalize (1 for rows, 0 for columns)

    Returns:
        Normalized weights DataFrame
    """
    return weights.div(weights.sum(axis=axis).abs(), axis=axis - 1)


def calculate_turnover(signal: pd.DataFrame, days: int) -> float:
    """
    Calculate portfolio turnover rate.

    Args:
        signal: Portfolio weights over time
        days: Number of trading days in period

    Returns:
        Annualized turnover rate
    """
    turnover = signal.fillna(0).diff().abs().sum(axis=1).sum()
    return turnover / days * 252


def clean_signal_data(signal: pd.DataFrame) -> pd.DataFrame:
    """
    Clean and prepare signal data for processing.

    Args:
        signal: Raw signal data

    Returns:
        Cleaned signal data
    """
    signal = signal.copy()

    # Remove cash column if present to avoid conflicts
    signal.drop(["cash"], axis=1, inplace=True, errors="ignore")

    # Ensure datetime index
    if not isinstance(signal.index, pd.DatetimeIndex):
        signal.index = pd.to_datetime(signal.index)

    return signal


def prepare_three_column_signal(signal: pd.DataFrame) -> pd.DataFrame:
    """
    Convert three-column format (date, stockid, weight) to pivot table.

    Args:
        signal: Signal data in three-column format

    Returns:
        Pivoted signal data
    """
    # Normalize column names
    signal.columns = [c.lower() for c in signal.columns]

    # Validate required columns
    required_columns = {"date", "stockid", "weight"}
    missing_columns = required_columns - set(signal.columns)

    if missing_columns:
        raise ValueError(f"Missing required columns: {missing_columns}")

    # Pivot to get stock weights over time
    return signal.pivot(values="weight", index="date", columns="stockid")


def ensure_datetime_index(data: Union[pd.DataFrame, pd.Series]) -> Union[pd.DataFrame, pd.Series]:
    """
    Ensure data has a datetime index.

    Args:
        data: Input DataFrame or Series

    Returns:
        Data with datetime index
    """
    if not isinstance(data.index, pd.DatetimeIndex):
        data.index = pd.to_datetime(data.index)
    return data


def safe_divide(numerator: Union[pd.DataFrame, pd.Series],
                denominator: Union[pd.DataFrame, pd.Series],
                fill_value: float = 0.0) -> Union[pd.DataFrame, pd.Series]:
    """
    Safe division with handling for division by zero.

    Args:
        numerator: Numerator
        denominator: Denominator
        fill_value: Value to use when division by zero occurs

    Returns:
        Result of safe division
    """
    result = numerator / denominator
    result = result.replace([np.inf, -np.inf], fill_value)
    result = result.fillna(fill_value)
    return result