"""
Vectorized portfolio calculations for maximum performance.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Union


class VectorizedPortfolioCalculator:
    """Ultra-fast portfolio calculations using pure vectorization."""

    @staticmethod
    def calculate_portfolio_returns_vectorized(signal: pd.DataFrame,
                                             price_returns: pd.DataFrame,
                                             commission: Tuple[float, float]) -> Tuple[pd.Series, pd.DataFrame]:
        """
        Vectorized portfolio return calculation for maximum performance.

        Args:
            signal: Portfolio weights DataFrame [time, assets]
            price_returns: Asset returns DataFrame [time, assets]
            commission: Commission rates (long, short)

        Returns:
            Tuple of (portfolio_returns, final_holdings)
        """
        if signal.empty or price_returns.empty:
            return pd.Series(dtype=float), pd.DataFrame(columns=["date", "stockid", "weight"])

        # Step 1: Efficient data alignment
        common_dates = signal.index.intersection(price_returns.index)
        common_assets = signal.columns.intersection(price_returns.columns)

        if len(common_dates) == 0 or len(common_assets) == 0:
            return pd.Series(dtype=float), pd.DataFrame(columns=["date", "stockid", "weight"])

        # Align data using reindex (fast operation)
        signal_aligned = signal.reindex(common_dates, columns=common_assets)
        returns_aligned = price_returns.reindex(common_dates, columns=common_assets)

        # Step 2: Vectorized forward fill
        signal_ffill = signal_aligned.ffill()

        # Step 3: Calculate cumulative wealth factors for rebalancing
        cum_returns = (1 + returns_aligned.shift(1).fillna(0)).cumprod()

        # Step 4: Apply rebalancing weights (vectorized)
        signal_with_rebalancing = signal_ffill * cum_returns

        # Step 5: Calculate portfolio returns (fully vectorized)
        portfolio_returns = (signal_with_rebalancing * returns_aligned).sum(axis=1)

        # Step 6: Calculate commission (vectorized)
        weight_diff = signal_with_rebalancing.diff()
        long_commission = np.maximum(weight_diff, 0).sum(axis=1) * commission[0]
        short_commission = np.maximum(-weight_diff, 0).sum(axis=1) * commission[1]

        # Apply commission
        portfolio_returns -= (long_commission + short_commission).fillna(0)

        # Step 7: Shift for next-day execution
        portfolio_returns = portfolio_returns.shift(1).fillna(0)

        # Step 8: Calculate cumulative returns
        cumulative_returns = (1 + portfolio_returns).cumprod()

        # Keep only complete bars (remove partial data)
        complete_bars = cumulative_returns.index.second == 0
        final_returns = cumulative_returns[complete_bars]

        # Step 9: Calculate final holdings
        final_holdings = VectorizedPortfolioCalculator._calculate_final_holdings(
            signal_ffill, common_assets
        )

        return final_returns, final_holdings

    @staticmethod
    def _calculate_final_holdings(signal: pd.DataFrame, assets: pd.Index) -> pd.DataFrame:
        """Calculate final holdings efficiently."""
        if signal.empty:
            return pd.DataFrame(columns=["date", "stockid", "weight"])

        # Get last non-zero weights
        last_weights = signal.ffill().iloc[-1]

        # Filter non-zero weights
        non_zero_mask = last_weights.abs() > 1e-6
        if not non_zero_mask.any():
            return pd.DataFrame(columns=["date", "stockid", "weight"])

        # Create holdings DataFrame
        valid_assets = assets[non_zero_mask]
        holdings = pd.DataFrame({
            'stockid': valid_assets,
            'weight': last_weights[non_zero_mask].values,
            'date': signal.index[-1]
        })

        return holdings.sort_values('weight', ascending=False)

    @staticmethod
    def calculate_hedge_returns_vectorized(long_returns: pd.Series,
                                        short_returns: pd.Series,
                                        rebalance_dates: pd.DatetimeIndex) -> pd.Series:
        """
        Vectorized hedge return calculation.

        Args:
            long_returns: Long position returns
            short_returns: Short position returns
            rebalance_dates: Rebalancing dates

        Returns:
            Hedged returns Series
        """
        # Handle empty series
        if long_returns.empty:
            long_returns = pd.Series(1.0, index=short_returns.index)
        if short_returns.empty:
            short_returns = pd.Series(1.0, index=long_returns.index)

        # Align series
        common_index = long_returns.index.intersection(short_returns.index)
        if len(common_index) == 0:
            return pd.Series(1.0, dtype=float)

        long_aligned = long_returns.reindex(common_index)
        short_aligned = short_returns.reindex(common_index)

        # Calculate returns (vectorized)
        long_pct = long_aligned.pct_change().fillna(0)
        short_pct = short_aligned.pct_change().fillna(0)

        # Calculate hedge ratio at rebalance points
        hedge_ratios = pd.Series(1.0, index=common_index)

        # Apply rebalancing adjustments
        for date in rebalance_dates:
            if date in common_index:
                # Simple hedge ratio calculation
                if long_aligned.loc[date] != 0:
                    hedge_ratios.loc[date:] = short_aligned.loc[date] / long_aligned.loc[date]

        # Calculate hedged returns (vectorized)
        shifted_ratios = hedge_ratios.shift(1).fillna(1.0)

        hedge_returns = (long_pct + short_pct * shifted_ratios) / (1 + shifted_ratios - 1/long_aligned.shift(1).fillna(1.0))
        hedge_returns = (1 + hedge_returns).fillna(1).cumprod()

        return hedge_returns

    @staticmethod
    def calculate_turnover_vectorized(signal: pd.DataFrame, total_days: int) -> float:
        """
        Vectorized turnover calculation.

        Args:
            signal: Signal DataFrame
            total_days: Total trading days

        Returns:
            Annualized turnover rate
        """
        if signal.empty or total_days == 0:
            return 0.0

        # Remove cash column if present
        signal_clean = signal.drop(['cash'], axis=1, errors='ignore')

        if signal_clean.empty:
            return 0.0

        # Vectorized turnover calculation
        weight_changes = signal_clean.diff().abs()
        total_turnover = weight_changes.sum().sum()

        return total_turnover / total_days * 252


class OptimizedDataPipeline:
    """Optimized data processing pipeline for maximum throughput."""

    @staticmethod
    def optimize_signal_pipeline(signal_df: pd.DataFrame,
                                price_df: pd.DataFrame,
                                config: dict) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Optimized end-to-end signal processing pipeline.

        Args:
            signal_df: Signal DataFrame
            price_df: Price DataFrame
            config: Configuration dictionary

        Returns:
            Tuple of (processed_signal, price_returns)
        """
        # Step 1: Fast data preprocessing
        signal_processed = OptimizedDataPipeline._preprocess_signal_fast(signal_df)
        price_processed = OptimizedDataPipeline._preprocess_price_fast(price_df)

        # Step 2: Fast pivot and alignment
        signal_wide = OptimizedDataPipeline._fast_pivot_optimized(signal_processed)

        # Step 3: Calculate returns efficiently
        price_returns = OptimizedDataPipeline._calculate_returns_fast(price_processed)

        # Step 4: Align data
        final_signal, final_returns = OptimizedDataPipeline._align_data_fast(
            signal_wide, price_returns, config
        )

        return final_signal, final_returns

    @staticmethod
    def _preprocess_signal_fast(signal_df: pd.DataFrame) -> pd.DataFrame:
        """Fast signal preprocessing."""
        # Column normalization (vectorized)
        signal_df.columns = [col.lower() for col in signal_df.columns]

        # Date conversion (fast)
        if 'date' in signal_df.columns:
            signal_df['date'] = pd.to_datetime(signal_df['date'])

        return signal_df

    @staticmethod
    def _preprocess_price_fast(price_df: pd.DataFrame) -> pd.DataFrame:
        """Fast price preprocessing."""
        # Column normalization
        price_df.columns = [col.lower() for col in price_df.columns]

        # Date conversion and sorting
        if 'date' in price_df.columns:
            price_df['date'] = pd.to_datetime(price_df['date'])
            price_df = price_df.sort_values('date')

        return price_df

    @staticmethod
    def _fast_pivot_optimized(signal_df: pd.DataFrame) -> pd.DataFrame:
        """Optimized pivot operation."""
        if signal_df.empty:
            return pd.DataFrame()

        # Use pandas built-in fast pivot for larger datasets
        if len(signal_df) > 5000:
            try:
                # Use crosstab for better performance on large data
                pivoted = pd.crosstab(
                    index=signal_df['date'],
                    columns=signal_df['stockid'],
                    values=signal_df['weight'],
                    aggfunc='sum',
                    fill_value=0
                )
                return pivoted
            except Exception:
                pass

        # Fallback to standard pivot
        return signal_df.pivot(
            values='weight',
            index='date',
            columns='stockid'
        ).fillna(0)

    @staticmethod
    def _calculate_returns_fast(price_df: pd.DataFrame) -> pd.DataFrame:
        """Fast return calculation."""
        if 'close' in price_df.columns and 'open' in price_df.columns:
            # Calculate close-to-close returns
            close_pivot = price_df.pivot(
                values='close',
                index='date',
                columns='stockid'
            )

            returns = close_pivot.pct_change()
            returns[np.isinf(returns)] = 0
            returns = returns.fillna(0)

            return returns
        else:
            return pd.DataFrame()

    @staticmethod
    def _align_data_fast(signal: pd.DataFrame,
                         returns: pd.DataFrame,
                         config: dict) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Fast data alignment."""
        # Get common date range
        start_date = config.get('begin_dt', signal.index.min())
        end_date = config.get('end_dt', signal.index.max())

        # Convert to datetime if needed
        if isinstance(start_date, str):
            start_date = pd.to_datetime(start_date)
        if isinstance(end_date, str):
            end_date = pd.to_datetime(end_date)

        # Filter date range
        date_mask = (signal.index >= start_date) & (signal.index <= end_date)
        signal_filtered = signal.loc[date_mask]

        # Align assets
        common_assets = signal_filtered.columns.intersection(returns.columns)
        signal_aligned = signal_filtered[common_assets]
        returns_aligned = returns[common_assets]

        return signal_aligned, returns_aligned