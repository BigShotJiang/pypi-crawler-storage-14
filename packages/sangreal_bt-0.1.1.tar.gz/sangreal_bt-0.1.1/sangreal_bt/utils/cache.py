"""
Caching utilities for performance optimization.
"""

import functools
import hashlib
import pickle
from typing import Any, Callable, Dict, Optional, Tuple
import pandas as pd


def result_cache(maxsize: int = 128):
    """
    Decorator for caching function results based on input data hash.

    Args:
        maxsize: Maximum number of cached results
    """
    def decorator(func: Callable) -> Callable:
        cache = {}

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key based on function name and arguments
            key_parts = [func.__name__]

            # Add DataFrame hashes for pandas objects
            for arg in args:
                if isinstance(arg, pd.DataFrame):
                    # Use data hash for DataFrames
                    key_parts.append(hash_pandas_object(arg))
                elif hasattr(arg, '__hash__'):
                    key_parts.append(str(hash(arg)))
                else:
                    key_parts.append(str(arg))

            # Add kwargs
            for k, v in sorted(kwargs.items()):
                if isinstance(v, pd.DataFrame):
                    key_parts.append(f"{k}={hash_pandas_object(v)}")
                else:
                    key_parts.append(f"{k}={v}")

            cache_key = '|'.join(key_parts)

            # Check cache
            if cache_key in cache:
                if len(cache) >= maxsize:
                    # Remove oldest entry (simple LRU)
                    oldest_key = next(iter(cache))
                    del cache[oldest_key]
                return cache[cache_key]

            # Compute result
            result = func(*args, **kwargs)

            # Store in cache
            cache[cache_key] = result

            return result

        # Add cache management methods
        wrapper.cache_clear = cache.clear
        wrapper.cache_info = lambda: {'size': len(cache), 'maxsize': maxsize}

        return wrapper

    return decorator


def hash_pandas_object(obj: pd.DataFrame) -> str:
    """
    Create a hash for pandas DataFrame.

    Args:
        obj: pandas DataFrame

    Returns:
        Hash string
    """
    # Use pandas.util.hash_pandas_object if available (pandas >= 1.1.0)
    try:
        from pandas.util import hash_pandas_object as pd_hash
        return hashlib.md5(pd_hash(obj).values).hexdigest()
    except ImportError:
        # Fallback method
        return hashlib.md5(pd.util.hash_pandas_object(obj).values).hexdigest()


class PerformanceCache:
    """Global performance cache for expensive computations."""

    def __init__(self, maxsize: int = 256):
        self.cache: Dict[str, Any] = {}
        self.maxsize = maxsize
        self.access_order: list = []

    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if key in self.cache:
            # Move to end (LRU)
            if key in self.access_order:
                self.access_order.remove(key)
            self.access_order.append(key)
            return self.cache[key]
        return None

    def set(self, key: str, value: Any) -> None:
        """Set value in cache."""
        # Remove oldest if at capacity
        if len(self.cache) >= self.maxsize and key not in self.cache:
            oldest_key = self.access_order.pop(0)
            del self.cache[oldest_key]

        self.cache[key] = value
        if key not in self.access_order:
            self.access_order.append(key)

    def clear(self) -> None:
        """Clear all cache entries."""
        self.cache.clear()
        self.access_order.clear()

    def size(self) -> int:
        """Get current cache size."""
        return len(self.cache)


# Global cache instance
_global_cache = PerformanceCache()


def get_global_cache() -> PerformanceCache:
    """Get the global performance cache instance."""
    return _global_cache


@result_cache(maxsize=64)
def cached_pivot(data: pd.DataFrame, values: str, index: str, columns: str, aggfunc: str = 'first') -> pd.DataFrame:
    """
    Cached version of pivot operation.

    Args:
        data: Input DataFrame
        values: Values column
        index: Index column
        columns: Columns to pivot
        aggfunc: Aggregation function

    Returns:
        Pivoted DataFrame
    """
    return pd.pivot_table(data, values=values, index=index, columns=columns, aggfunc=aggfunc)


@result_cache(maxsize=32)
def cached_pct_change(data: pd.DataFrame, periods: int = 1) -> pd.DataFrame:
    """
    Cached version of pct_change operation.

    Args:
        data: Input DataFrame
        periods: Number of periods for pct_change

    Returns:
        DataFrame with percentage changes
    """
    return data.pct_change(periods=periods)


@result_cache(maxsize=16)
def cached_ffill(data: pd.DataFrame, limit: Optional[int] = None) -> pd.DataFrame:
    """
    Cached version of forward fill operation.

    Args:
        data: Input DataFrame
        limit: Maximum number of consecutive NaN values to fill

    Returns:
        DataFrame with forward-filled values
    """
    return data.ffill(limit=limit)