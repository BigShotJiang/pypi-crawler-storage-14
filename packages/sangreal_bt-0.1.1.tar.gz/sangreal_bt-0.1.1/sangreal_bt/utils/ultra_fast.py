"""
Ultra-fast implementations for critical performance bottlenecks.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Dict, Any
from collections import defaultdict
import time


class UltraFastDataProcessor:
    """Maximum performance data processing using optimized algorithms."""

    @staticmethod
    def process_signals_ultra_fast(signal_df: pd.DataFrame,
                                   index_futures: Tuple[str, ...]) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Ultra-fast signal processing using vectorized operations and pre-allocation.

        Args:
            signal_df: Signal DataFrame in long format
            index_futures: Tuple of index future symbols

        Returns:
            Tuple of (original_signal, asset_signals, future_signals)
        """
        if signal_df.empty:
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

        start_time = time.time()

        # Step 1: Optimized pivot using scipy sparse matrix approach for large datasets
        if len(signal_df) > 10000:  # Large dataset optimization
            signal_wide = UltraFastDataProcessor._sparse_pivot(signal_df)
        else:
            signal_wide = UltraFastDataProcessor._fast_pivot(signal_df)

        pivot_time = time.time() - start_time

        # Step 2: Ultra-fast signal splitting
        split_start = time.time()
        asset_signals, future_signals = UltraFastDataProcessor._split_signals(
            signal_wide, index_futures
        )
        split_time = time.time() - split_start

        # Step 3: Vectorized cash weight calculation
        cash_start = time.time()
        asset_signals = UltraFastDataProcessor._add_cash_weights_vectorized(asset_signals)
        if not future_signals.empty:
            future_signals = UltraFastDataProcessor._add_cash_weights_vectorized(future_signals)
        cash_time = time.time() - cash_start

        # Performance tracking
        total_time = time.time() - start_time
        if hasattr(UltraFastDataProcessor, '_perf_stats'):
            UltraFastDataProcessor._perf_stats['pivot_time'] += pivot_time
            UltraFastDataProcessor._perf_stats['split_time'] += split_time
            UltraFastDataProcessor._perf_stats['cash_time'] += cash_time
            UltraFastDataProcessor._perf_stats['total_time'] += total_time
            UltraFastDataProcessor._perf_stats['count'] += 1

        return signal_df, asset_signals, future_signals

    @staticmethod
    def _fast_pivot(signal_df: pd.DataFrame) -> pd.DataFrame:
        """Fast pivot using pre-allocation and direct indexing."""
        # Pre-sort for better performance
        signal_df = signal_df.sort_values(['date', 'stockid']).copy()

        # Extract unique values and create mappings
        dates = pd.to_datetime(signal_df['date'].unique())
        stocks = signal_df['stockid'].unique()

        # Create direct mappings
        date_to_idx = {date: i for i, date in enumerate(dates)}
        stock_to_idx = {stock: j for j, stock in enumerate(stocks)}

        # Pre-allocate result matrix
        result_matrix = np.zeros((len(dates), len(stocks)), dtype=np.float64)

        # Fast filling using vectorized operations where possible
        for _, row in signal_df.itertuples(index=False):
            date_idx = date_to_idx[pd.Timestamp(row.date)]
            stock_idx = stock_to_idx[row.stockid]
            result_matrix[date_idx, stock_idx] = row.weight

        return pd.DataFrame(result_matrix, index=dates, columns=stocks)

    @staticmethod
    def _sparse_pivot(signal_df: pd.DataFrame) -> pd.DataFrame:
        """Sparse matrix pivot for very large datasets."""
        try:
            from scipy.sparse import csr_matrix
            from scipy.sparse import coo_matrix

            # Create coordinate format sparse matrix
            dates = pd.to_datetime(signal_df['date'].unique())
            stocks = signal_df['stockid'].unique()

            date_to_idx = {date: i for i, date in enumerate(dates)}
            stock_to_idx = {stock: j for j, stock in enumerate(stocks)}

            # Create sparse matrix coordinates
            row_indices = []
            col_indices = []
            data = []

            for _, row in signal_df.iterrows():
                row_indices.append(date_to_idx[pd.Timestamp(row['date'])])
                col_indices.append(stock_to_idx[row['stockid']])
                data.append(row['weight'])

            # Create sparse matrix and convert to dense
            sparse_matrix = coo_matrix((data, (row_indices, col_indices)),
                                    shape=(len(dates), len(stocks)))
            dense_matrix = sparse_matrix.toarray()

            return pd.DataFrame(dense_matrix, index=dates, columns=stocks)

        except ImportError:
            # Fallback to fast pivot if scipy not available
            return UltraFastDataProcessor._fast_pivot(signal_df)

    @staticmethod
    def _split_signals(signal_wide: pd.DataFrame,
                       index_futures: Tuple[str, ...]) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Ultra-fast signal splitting using numpy operations."""
        if signal_wide.empty:
            return pd.DataFrame(), pd.DataFrame()

        # Convert to numpy for boolean operations
        columns = signal_wide.columns.values
        futures_set = set(index_futures)

        # Vectorized boolean indexing
        is_future = np.array([col in futures_set for col in columns])

        # Split using numpy boolean indexing
        future_mask = is_future
        asset_mask = ~is_future

        asset_cols = columns[asset_mask]
        future_cols = columns[future_mask]

        if len(asset_cols) > 0:
            asset_signals = signal_wide[asset_cols].copy()
        else:
            asset_signals = pd.DataFrame(index=signal_wide.index)

        if len(future_cols) > 0:
            future_signals = signal_wide[future_cols].copy()
        else:
            future_signals = pd.DataFrame(index=signal_wide.index)

        return asset_signals, future_signals

    @staticmethod
    def _add_cash_weights_vectorized(signal: pd.DataFrame) -> pd.DataFrame:
        """Vectorized cash weight calculation."""
        if signal.empty:
            return signal

        # Vectorized operations
        signal_sums = signal.sum(axis=1).values
        cash_weights = np.sign(signal_sums + 1e-8) - signal_sums

        # Fast assignment
        result = signal.copy()
        result.loc[:, 'cash'] = cash_weights

        return result

    @staticmethod
    def init_performance_tracking():
        """Initialize performance tracking."""
        UltraFastDataProcessor._perf_stats = {
            'pivot_time': 0.0,
            'split_time': 0.0,
            'cash_time': 0.0,
            'total_time': 0.0,
            'count': 0
        }

    @staticmethod
    def get_performance_stats() -> Dict[str, float]:
        """Get performance statistics."""
        if not hasattr(UltraFastDataProcessor, '_perf_stats'):
            return {}

        stats = UltraFastDataProcessor._perf_stats.copy()
        if stats['count'] > 0:
            stats['avg_total_time'] = stats['total_time'] / stats['count']
        return stats


class BatchProcessor:
    """Process data in batches for memory efficiency with large datasets."""

    @staticmethod
    def process_large_signal(signal_df: pd.DataFrame,
                           batch_size: int = 10000) -> pd.DataFrame:
        """
        Process large signal DataFrame in batches.

        Args:
            signal_df: Large signal DataFrame
            batch_size: Number of rows per batch

        Returns:
            Processed signal DataFrame
        """
        if len(signal_df) <= batch_size:
            return UltraFastDataProcessor._fast_pivot(signal_df)

        # Process in batches
        results = []
        for i in range(0, len(signal_df), batch_size):
            batch = signal_df.iloc[i:i+batch_size]
            batch_result = UltraFastDataProcessor._fast_pivot(batch)
            results.append(batch_result)

        # Combine results efficiently
        if results:
            combined = pd.concat(results, axis=0)
            return combined.groupby(combined.index).first()  # Handle overlapping dates
        else:
            return pd.DataFrame()

    @staticmethod
    def optimize_memory_usage(df: pd.DataFrame) -> pd.DataFrame:
        """Optimize DataFrame memory usage."""
        for col in df.select_dtypes(include=['float64']).columns:
            df[col] = pd.to_numeric(df[col], downcast='float')

        for col in df.select_dtypes(include=['int64']).columns:
            df[col] = pd.to_numeric(df[col], downcast='integer')

        return df


# Parallel processing utilities
class ParallelProcessor:
    """Utilities for parallel processing when available."""

    @staticmethod
    def can_parallel() -> bool:
        """Check if parallel processing is available."""
        try:
            import multiprocessing
            return multiprocessing.cpu_count() > 1
        except ImportError:
            return False

    @staticmethod
    def parallel_signal_split(signals_list: list,
                             index_futures: Tuple[str, ...],
                             n_workers: int = None) -> list:
        """
        Split multiple signals in parallel if possible.

        Args:
            signals_list: List of signal DataFrames
            index_futures: Tuple of futures symbols
            n_workers: Number of worker processes

        Returns:
            List of processed signal tuples
        """
        if not ParallelProcessor.can_parallel() or len(signals_list) == 1:
            # Fallback to sequential processing
            return [
                UltraFastDataProcessor.process_signals_ultra_fast(signal, index_futures)
                for signal in signals_list
            ]

        try:
            from concurrent.futures import ProcessPoolExecutor
            import multiprocessing

            if n_workers is None:
                n_workers = min(multiprocessing.cpu_count(), len(signals_list))

            with ProcessPoolExecutor(max_workers=n_workers) as executor:
                futures = [
                    executor.submit(
                        UltraFastDataProcessor.process_signals_ultra_fast,
                        signal, index_futures
                    )
                    for signal in signals_list
                ]

                results = [future.result() for future in futures]

            return results

        except Exception:
            # Fallback to sequential processing
            return [
                UltraFastDataProcessor.process_signals_ultra_fast(signal, index_futures)
                for signal in signals_list
            ]