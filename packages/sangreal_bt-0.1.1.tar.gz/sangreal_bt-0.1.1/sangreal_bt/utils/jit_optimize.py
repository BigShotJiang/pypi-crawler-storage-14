"""
Numba JIT accelerated functions for maximum performance.
"""

import numpy as np
from numba import jit, prange
import pandas as pd
from typing import Tuple

# 尝试导入numba，如果不可用则提供fallback
try:
    from numba import jit, prange, types
    from numba.typed import Dict
    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False

    def jit(*args, **kwargs):
        """Fallback decorator when numba is not available."""
        def decorator(func):
            return func
        return decorator

    def prange(x):
        """Fallback for prange."""
        return range(x)


@jit(nopython=True, cache=True)
def fast_portfolio_returns_numba(weights_matrix: np.ndarray,
                                returns_matrix: np.ndarray,
                                commission_long: float,
                                commission_short: float) -> np.ndarray:
    """
    Numba-accelerated portfolio return calculation.

    Args:
        weights_matrix: Portfolio weights [time, assets]
        returns_matrix: Asset returns [time, assets]
        commission_long: Long commission rate
        commission_short: Short commission rate

    Returns:
        Portfolio returns array
    """
    n_times, n_assets = weights_matrix.shape
    portfolio_returns = np.zeros(n_times)

    # Forward fill weights
    ff_weights = np.zeros_like(weights_matrix)
    for i in range(n_times):
        if i == 0:
            ff_weights[i] = weights_matrix[i]
        else:
            for j in range(n_assets):
                if weights_matrix[i, j] != 0:
                    ff_weights[i, j] = weights_matrix[i, j]
                else:
                    ff_weights[i, j] = ff_weights[i-1, j]

    # Calculate portfolio returns and commission
    for i in range(n_times):
        portfolio_return = 0.0

        # Calculate return from holdings
        for j in range(n_assets):
            portfolio_return += ff_weights[i, j] * returns_matrix[i, j]

        # Calculate commission
        if i > 0:
            commission = 0.0
            for j in range(n_assets):
                weight_change = ff_weights[i, j] - ff_weights[i-1, j]
                if weight_change > 0:
                    commission += weight_change * commission_long
                elif weight_change < 0:
                    commission += -weight_change * commission_short

            portfolio_return -= commission

        portfolio_returns[i] = portfolio_return

    return portfolio_returns


@jit(nopython=True, cache=True)
def fast_add_cash_weights_numba(weights_matrix: np.ndarray) -> np.ndarray:
    """
    Numba-accelerated cash weights calculation.

    Args:
        weights_matrix: Portfolio weights matrix [time, assets]

    Returns:
        Weights matrix with cash column added
    """
    n_times, n_assets = weights_matrix.shape
    result = np.zeros((n_times, n_assets + 1))

    for i in range(n_times):
        weight_sum = 0.0
        for j in range(n_assets):
            weight_sum += weights_matrix[i, j]
            result[i, j] = weights_matrix[i, j]

        # Add cash weights
        cash_weight = np.sign(weight_sum + 1e-8) - weight_sum
        result[i, n_assets] = cash_weight

    return result


@jit(nopython=True, cache=True)
def fast_turnover_numba(weights_matrix: np.ndarray, total_days: int) -> float:
    """
    Numba-accelerated turnover calculation.

    Args:
        weights_matrix: Portfolio weights matrix [time, assets]
        total_days: Total trading days

    Returns:
        Annualized turnover rate
    """
    if weights_matrix.shape[0] <= 1:
        return 0.0

    n_times, n_assets = weights_matrix.shape
    turnover = 0.0

    for i in range(1, n_times):
        for j in range(n_assets):
            turnover += abs(weights_matrix[i, j] - weights_matrix[i-1, j])

    return turnover / total_days * 252


class FastSignalProcessor:
    """Ultra-fast signal processing using optimized algorithms."""

    @staticmethod
    def fast_pivot_long_format(signal_df: pd.DataFrame) -> pd.DataFrame:
        """
        Ultra-fast pivot operation for long-format signal data.

        Args:
            signal_df: DataFrame with columns ['date', 'stockid', 'weight']

        Returns:
            Pivoted DataFrame
        """
        if signal_df.empty:
            return pd.DataFrame()

        # Pre-sort for better cache locality
        signal_df = signal_df.sort_values(['date', 'stockid']).copy()

        # Get unique dates and stocks
        dates = pd.to_datetime(signal_df['date'].unique())
        stocks = signal_df['stockid'].unique()

        # Create result matrix directly
        result_array = np.zeros((len(dates), len(stocks)))

        # Build mapping for faster lookup
        date_to_idx = {date: i for i, date in enumerate(dates)}
        stock_to_idx = {stock: j for j, stock in enumerate(stocks)}

        # Fill matrix
        for _, row in signal_df.iterrows():
            date_idx = date_to_idx[pd.Timestamp(row['date'])]
            stock_idx = stock_to_idx[row['stockid']]
            result_array[date_idx, stock_idx] = row['weight']

        # Create DataFrame
        result = pd.DataFrame(
            result_array,
            index=dates,
            columns=stocks
        )

        return result

    @staticmethod
    def split_signals_optimized(signal_wide: pd.DataFrame,
                               futures_tuple: Tuple[str, ...]) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Optimized signal splitting using numpy operations.

        Args:
            signal_wide: Wide format signal DataFrame
            futures_tuple: Tuple of futures symbols

        Returns:
            Tuple of (asset_signals, future_signals)
        """
        if signal_wide.empty:
            return pd.DataFrame(), pd.DataFrame()

        columns = signal_wide.columns.values
        futures_set = set(futures_tuple)

        # Use numpy boolean indexing for maximum speed
        is_future = np.array([col in futures_set for col in columns])

        future_cols = columns[is_future]
        asset_cols = columns[~is_future]

        asset_signals = signal_wide[asset_cols].copy()
        future_signals = signal_wide[future_cols].copy()

        return asset_signals, future_signals


# Utility functions for dataframe conversion
def dataframe_to_numpy_fast(df: pd.DataFrame) -> np.ndarray:
    """Convert DataFrame to numpy array efficiently."""
    return df.to_numpy(dtype=np.float64)


def numpy_to_dataframe_fast(arr: np.ndarray,
                           index: pd.Index,
                           columns: pd.Index) -> pd.DataFrame:
    """Convert numpy array to DataFrame efficiently."""
    return pd.DataFrame(arr, index=index, columns=columns)


# Performance decorator for automatic fallback
def auto_jit(nopython: bool = True, cache: bool = True):
    """Auto-jit decorator with fallback when numba is not available."""
    def decorator(func):
        if NUMBA_AVAILABLE:
            return jit(nopython=nopython, cache=cache)(func)
        else:
            return func
    return decorator


# High-performance portfolio calculator
class UltraFastPortfolio:
    """Maximum performance portfolio calculations."""

    @staticmethod
    def calculate_returns(signal: pd.DataFrame,
                         returns: pd.DataFrame,
                         commission: Tuple[float, float]) -> pd.Series:
        """
        Ultra-fast portfolio return calculation.

        Args:
            signal: Portfolio weights DataFrame
            returns: Asset returns DataFrame
            commission: Commission rates (long, short)

        Returns:
            Portfolio returns Series
        """
        if signal.empty or returns.empty:
            return pd.Series(dtype=float)

        # Align data
        common_index = signal.index.intersection(returns.index)
        common_cols = signal.columns.intersection(returns.columns)

        if len(common_index) == 0 or len(common_cols) == 0:
            return pd.Series(dtype=float)

        # Convert to numpy for maximum speed
        signal_np = signal.reindex(common_index, columns=common_cols).to_numpy()
        returns_np = returns.reindex(common_index, columns=common_cols).to_numpy()

        # Use numba acceleration
        portfolio_returns_np = fast_portfolio_returns_numba(
            signal_np, returns_np, commission[0], commission[1]
        )

        # Convert back to pandas
        result = pd.Series(portfolio_returns_np, index=common_index)

        # Shift for next-day execution
        result = result.shift(1).fillna(0)

        return result