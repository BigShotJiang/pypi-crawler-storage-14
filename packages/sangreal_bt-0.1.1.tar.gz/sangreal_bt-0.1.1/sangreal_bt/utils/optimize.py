"""
Performance optimization utilities for sangreal_bt.
"""

import numpy as np
import pandas as pd
from typing import Tuple, Optional, Dict
import warnings


class OptimizedSignalProcessor:
    """Optimized signal processing with vectorized operations."""

    @staticmethod
    def fast_signal_pivot(signal_df: pd.DataFrame) -> pd.DataFrame:
        """
        Fast pivot operation for signal data using vectorized operations.

        Args:
            signal_df: DataFrame with columns ['date', 'stockid', 'weight']

        Returns:
            Pivoted signal DataFrame
        """
        if signal_df.empty:
            return pd.DataFrame()

        # Pre-sort for better performance
        signal_df = signal_df.sort_values(['date', 'stockid']).copy()

        # Use faster pivot method
        try:
            # Try the fast path first
            result = signal_df.pivot_table(
                values='weight',
                index='date',
                columns='stockid',
                aggfunc='sum',  # Handle duplicate dates/stocks
                fill_value=0
            )
        except Exception:
            # Fallback to slower but more robust method
            result = signal_df.pivot(values='weight', index='date', columns='stockid')
            result = result.fillna(0)

        return result

    @staticmethod
    def fast_prepare_signals(signal_wide: pd.DataFrame, index_futures: Tuple[str, ...]) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Fast signal preparation using vectorized operations.

        Args:
            signal_wide: Wide format signal DataFrame
            index_futures: Tuple of index future symbols

        Returns:
            Tuple of (asset_signals, future_signals)
        """
        if signal_wide.empty:
            return pd.DataFrame(), pd.DataFrame()

        # Vectorized column classification
        is_future = signal_wide.columns.isin(index_futures)

        # Split using boolean indexing (faster than set operations)
        future_cols = signal_wide.columns[is_future]
        asset_cols = signal_wide.columns[~is_future]

        asset_signals = signal_wide[asset_cols].copy()
        future_signals = signal_wide[future_cols].copy()

        return asset_signals, future_signals

    @staticmethod
    def fast_add_cash_weights(signal: pd.DataFrame) -> pd.DataFrame:
        """
        Fast cash weight calculation using vectorized operations.

        Args:
            signal: Signal DataFrame

        Returns:
            Signal with cash weights added
        """
        if signal.empty:
            return signal

        # Vectorized sum along axis
        signal_sum = signal.sum(axis=1)

        # Vectorized cash calculation
        cash_weights = np.sign(signal_sum + 1e-8) - signal_sum

        # Fast assignment
        result = signal.copy()
        result['cash'] = cash_weights.values

        return result


class OptimizedPortfolioCalculator:
    """Optimized portfolio calculations with minimal memory allocation."""

    @staticmethod
    def fast_portfolio_returns(signal: pd.DataFrame,
                             price_returns: pd.DataFrame,
                             commission_rates: Tuple[float, float]) -> pd.Series:
        """
        Fast portfolio return calculation with optimized memory usage.

        Args:
            signal: Portfolio weights
            price_returns: Asset returns
            commission_rates: Commission rates (long, short)

        Returns:
            Portfolio returns Series
        """
        if signal.empty or price_returns.empty:
            return pd.Series(dtype=float)

        # Align data efficiently
        common_index = signal.index.intersection(price_returns.index)
        if len(common_index) == 0:
            return pd.Series(dtype=float)

        signal_aligned = signal.reindex(common_index)
        returns_aligned = price_returns.reindex(signal_aligned.columns, axis=1)

        # Forward fill signals (vectorized)
        signal_ffill = signal_aligned.ffill()

        # Portfolio return calculation (vectorized)
        portfolio_return = (signal_ffill * returns_aligned).sum(axis=1)

        # Commission calculation (optimized)
        weight_diff = signal_ffill.diff()
        long_commission = (np.maximum(weight_diff, 0).sum(axis=1) * commission_rates[0])
        short_commission = (np.maximum(-weight_diff, 0).sum(axis=1) * commission_rates[1])

        # Apply commission
        portfolio_return -= (long_commission + short_commission).fillna(0)

        # Shift for next day execution
        portfolio_return = portfolio_return.shift(1).fillna(0)

        return portfolio_return


class MemoryOptimizer:
    """Utilities for optimizing memory usage."""

    @staticmethod
    def optimize_dataframe_dtypes(df: pd.DataFrame) -> pd.DataFrame:
        """
        Optimize DataFrame dtypes to reduce memory usage.

        Args:
            df: Input DataFrame

        Returns:
            Memory-optimized DataFrame
        """
        optimized_df = df.copy()

        for col in optimized_df.columns:
            col_type = optimized_df[col].dtype

            if col_type != 'object':
                col_min = optimized_df[col].min()
                col_max = optimized_df[col].max()

                if str(col_type)[:3] == 'int':
                    if col_min > np.iinfo(np.int8).min and col_max < np.iinfo(np.int8).max:
                        optimized_df[col] = optimized_df[col].astype(np.int16)
                    elif col_min > np.iinfo(np.int16).min and col_max < np.iinfo(np.int16).max:
                        optimized_df[col] = optimized_df[col].astype(np.int32)

                elif str(col_type)[:5] == 'float':
                    if col_min > np.finfo(np.float16).min and col_max < np.finfo(np.float16).max:
                        optimized_df[col] = optimized_df[col].astype(np.float32)

        return optimized_df

    @staticmethod
    def reduce_memory_usage(df: pd.DataFrame, verbose: bool = False) -> pd.DataFrame:
        """
        Reduce memory usage of DataFrame by optimizing data types.

        Args:
            df: Input DataFrame
            verbose: Whether to print memory usage reduction

        Returns:
            Memory-optimized DataFrame
        """
        start_mem = df.memory_usage().sum() / 1024**2
        optimized_df = MemoryOptimizer.optimize_dataframe_dtypes(df)
        end_mem = optimized_df.memory_usage().sum() / 1024**2

        if verbose:
            print(f'Memory usage reduced from {start_mem:.2f} MB to {end_mem:.2f} MB '
                  f'({100 * (start_mem - end_mem) / start_mem:.1f}% reduction)')

        return optimized_df