"""
Strategy module for the sangreal_bt backtesting framework.
"""

import datetime as dt
from typing import Optional, Tuple, Union
import warnings

import attr
import numpy as np
import pandas as pd
from addict import Dict

# New architecture imports
from sangreal_bt.core.config import BacktestConfig
from sangreal_bt.core.engine import BacktestEngine
from sangreal_bt.datafeed.datafeed import DataBase
from sangreal_bt.stats.stats import Stats

# Legacy imports for backward compatibility
try:
    from sangreal_bt.commons import Commons
except ImportError:
    # Fallback if commons module structure changes
    class Commons:
        INDEX_FUTURE = ("IH", "IF", "IC", "IM", "TS", "TF", "T", "TL")
        from pandas.tseries.offsets import Second
        SHIFT_TIME = Second(1)


def _dt_converter(value):
    """Convert value to pandas timestamp."""
    return pd.to_datetime(value)


@attr.s(hash=True, cmp=False)
class Strategy:
    """
    Backtesting strategy class with backward compatibility.

    This class maintains the original API while using the new refactored architecture
    under the hood.

    Parameters:
        begin_dt: Backtest start date (default: "20010101")
        end_dt: Backtest end date (default: today)
        matching_type: Order matching type, "next_bar" or "current_bar" (default: "next_bar")
        benchmark: Benchmark symbol (default: "")
        commission: Stock commission rates (long, short) (default: (0, 0))
        fcommission: Future commission rates (long, short) (default: (0, 0))
        fixed_rate: Fixed annual rate for benchmark (default: 0.04)
    """

    # Backward compatible attributes using attrs
    begin_dt = attr.ib(
        default=pd.to_datetime("20010101"),
        repr=True,
        converter=_dt_converter,
    )
    end_dt = attr.ib(
        default=pd.to_datetime(dt.date.today()),
        repr=True,
        converter=_dt_converter,
    )
    matching_type = attr.ib(default="next_bar")
    benchmark = attr.ib(default="")
    commission = attr.ib(default=(0, 0), converter=tuple)
    fcommission = attr.ib(default=(0, 0), converter=tuple)
    fixed_rate = attr.ib(default=4e-2, converter=float)

    @commission.validator
    def check_commission(self, attribute, value):
        if len(value) != 2:
            raise ValueError("commission must be tuple like (0.1, 0.1)!")

    @fcommission.validator
    def check_fcommission(self, attribute, value):
        if len(value) != 2:
            raise ValueError("fcommission must be tuple like (0.1, 0.1)!")

    @matching_type.validator
    def check_match(self, attribute, value):
        if value not in ("next_bar", "current_bar"):
            raise ValueError("matching_type must be 'next_bar' or 'current_bar'")

    def __attrs_post_init__(self):
        """Initialize the new architecture while maintaining backward compatibility."""
        # Legacy attributes for backward compatibility
        self._open = None
        self._close = None
        self._signal = None
        self.result = Dict()

        # Initialize new architecture
        self._config = BacktestConfig(
            begin_dt=self.begin_dt,
            end_dt=self.end_dt,
            matching_type=self.matching_type,
            benchmark=self.benchmark,
            commission=self.commission,
            fcommission=self.fcommission,
            fixed_rate=self.fixed_rate
        )
        self._engine = BacktestEngine(self._config)
        self._data_added = False
        self._signal_added = False

        # Deprecation warning for attrs usage
        warnings.warn(
            "Using attrs-based initialization is deprecated. "
            "Consider using the new BacktestConfig-based approach for better type safety.",
            DeprecationWarning,
            stacklevel=2
        )

    def addsignal(self, signal: pd.DataFrame) -> None:
        """
        Add trading signals to the strategy.

        Args:
            signal: Trading signals DataFrame. Can be either:
                   - Wide format: datetime index, stock symbols as columns
                   - Long format: columns 'date', 'stockid', 'weight'
        """
        if not isinstance(signal, pd.DataFrame):
            raise TypeError("Signal data must be a DataFrame!")

        # Always run legacy implementation for backward compatibility
        self._legacy_addsignal(signal)
        self._signal_added = True

        # Also try to use new engine for potential performance improvements
        try:
            self._update_config()
            self._engine.add_signal(signal)

        except Exception as e:
            # New engine failed, but legacy implementation should work
            warnings.warn(
                f"New engine signal processing failed, using legacy: {e}",
                UserWarning
            )

    def _legacy_addsignal(self, signal: pd.DataFrame) -> None:
        """Ultra-fast signal processing for maximum performance."""
        # 导入超快速处理工具
        from ..utils.ultra_fast import UltraFastDataProcessor

        # 原始信号 - 避免不必要的拷贝
        original_signal = signal

        # 三列模式 转换 pivot table - 使用超快速版本
        if isinstance(signal.index[0], (int, np.int64)):
            signal.columns = [c.lower() for c in signal.columns]
            columns = {"date", "stockid", "weight"}
            if not columns.issubset(signal.columns):
                raise ValueError(f"signal must contain {columns}")

            # 保存原始信号格式
            self.result.signal = signal[['date', 'stockid', 'weight']].copy()

            # 使用超快速处理
            _, signal_asset, signal_future = UltraFastDataProcessor.process_signals_ultra_fast(
                signal, Commons.INDEX_FUTURE
            )
        else:
            # Wide格式处理
            signal_clean = signal.copy()
            signal_clean.drop(["cash"], axis=1, inplace=True, errors="ignore")
            signal_clean.index = pd.to_datetime(signal_clean.index)

            # 保存原始信号
            signal_ = signal_clean.stack().reset_index()
            signal_.columns = ["date", "stockid", "weight"]
            self.result.signal = signal_

            # 使用超快速分离
            from ..utils.ultra_fast import UltraFastDataProcessor
            signal_asset, signal_future = UltraFastDataProcessor._split_signals(
                signal_clean, Commons.INDEX_FUTURE
            )

            # 使用超快速现金权重计算
            if not signal_asset.empty:
                signal_asset = UltraFastDataProcessor._add_cash_weights_vectorized(signal_asset)
            if not signal_future.empty:
                signal_future = UltraFastDataProcessor._add_cash_weights_vectorized(signal_future)

        # 第二天开盘价买入
        if self.matching_type == "next_bar":
            signal_asset.index = signal_asset.index + Commons.SHIFT_TIME
            signal_future.index = signal_future.index + Commons.SHIFT_TIME

        self._signal = {"asset": signal_asset, "future": signal_future}

    def adddata(self, data: DataBase) -> None:
        """
        Add market data to the strategy.

        Args:
            data: DataBase instance containing market data
        """
        if not isinstance(data, DataBase):
            raise TypeError("Data must be a DataBase instance!")

        # Always run legacy implementation for backward compatibility
        self._legacy_adddata(data)
        self._data_added = True

        # Also try to use new engine for potential performance improvements
        try:
            self._update_config()
            self._engine.add_data(data)

        except Exception as e:
            # New engine failed, but legacy implementation should work
            warnings.warn(
                f"New engine data processing failed, using legacy: {e}",
                UserWarning
            )

    def _legacy_adddata(self, data: DataBase) -> None:
        """Legacy data processing for backward compatibility."""
        self._open = data.open.copy()
        self._close = data.close.copy()

        # 对开始及结束日期进行修正
        self.begin_dt = max(self.begin_dt, self._open.index[0])
        self.end_dt = min(self.end_dt, self._open.index[-1])

        # 重新设置开始结束data日期
        self._open = self._open.loc[self.begin_dt : self.end_dt].copy()
        # open的日期进行处理前移
        self._open = self._open.shift(-1)
        self._open.index = self._open.index + Commons.SHIFT_TIME
        self._close = self._close.loc[self.begin_dt : self.end_dt].copy()
        # 加入现金项
        self._open["cash"] = 1.0
        self._close["cash"] = 1.0

    def _update_config(self) -> None:
        """Update engine config with current attribute values."""
        self._config.begin_dt = self.begin_dt
        self._config.end_dt = self.end_dt
        self._config.matching_type = self.matching_type
        self._config.benchmark = self.benchmark
        self._config.commission = self.commission
        self._config.fcommission = self.fcommission
        self._config.fixed_rate = self.fixed_rate

    def setcommission(self, commission: Tuple[float, float]) -> None:
        """Set commission rates for stocks."""
        if len(commission) != 2:
            raise ValueError("commission must be tuple like (0.1, 0.1)!")
        self.commission = tuple(commission)

    def setfcommission(self, commission: Tuple[float, float]) -> None:
        """Set commission rates for futures."""
        if len(commission) != 2:
            raise ValueError("commission must be tuple like (0.1, 0.1)!")
        self.fcommission = tuple(commission)

    def setbenchmark(self, benchmark: str) -> None:
        """Set benchmark symbol."""
        self.benchmark = benchmark

    def _get_universe_value(self, signal):
        """[获取资产池内收益，得到每个信号bar后一个bar的收益，并前移至该bar]

        Arguments:
            signal {[pd.DataFrame]} -- [处理好的signal]

        Returns:
            [type] -- [description]
        """
        df = self._close.reindex(signal.columns, axis=1)
        if self.matching_type == "next_bar":
            df_c = df.copy()
            df_o = self._open.reindex(signal.columns, axis=1).reindex(signal.index)
            df = pd.concat([df_c, df_o], axis=0, sort=False)
            df.sort_index(inplace=True)
        # =======================================
        df = df.pct_change(fill_method=None)
        df[np.isinf(df)] = 0
        df = df.shift(-1).fillna(0)
        return df

    @staticmethod
    def _get_relative_ret(strategy, benchmark, trades_dt):
        """[summary]

        Arguments:
            strategy {[pd.Series]} -- [nav]
            benchmark {[pd.Series]} -- [nav]
            trades_dt {[series]} -- [description]

        Raises:
            ValueError: [description]
            ValueError: [description]

        Returns:
            [type] -- [description]
        """
        trades_dt = pd.to_datetime(trades_dt)
        strategy_adjust_factor = (
            (strategy.reindex(trades_dt).reindex(strategy.index)).ffill().fillna(1)
        )
        # 对每期初始资金作调整，此时净值有跳跃
        strategy_adjust = strategy / strategy_adjust_factor
        benchmark_adjust_factor = (
            (benchmark.reindex(trades_dt).reindex(benchmark.index)).ffill().fillna(1)
        )
        benchmark_adjust = benchmark / benchmark_adjust_factor
        # 计算相对收益每日净值，此时有跳跃每期第一天的涨跌幅并不正确
        relative = (
            (strategy_adjust - benchmark_adjust + 1)
            .pct_change(fill_method=None)
            .fillna(0)
        )
        relative.loc[trades_dt] = (
            (
                strategy.pct_change(fill_method=None)
                - benchmark.pct_change(fill_method=None)
            )
            .fillna(0)
            .loc[trades_dt]
        )
        relative = (relative + 1).cumprod()
        return relative

    def _get_ret(self, signal, commission_factor):
        """
        向量化计算收益
        信号 手续费 tuple
        返回，多空，多头，空头累计收益
        """
        # 对应universe每天收益（pct_change)

        u_value = self._get_universe_value(signal)
        # =============================================
        trade_dt_list = u_value.index
        # =============信号处理====================
        # 初始信号
        signal_tmp = signal.fillna(0)
        # ================================================
        _weight = np.exp(np.log1p(u_value.shift(1).fillna(0)).cumsum())
        signal_all = signal_tmp.reindex(index=trade_dt_list).ffill()

        # 更新持仓期间权重，但是每期初期权重仍未改变到初始状态
        signal_all = signal_all * _weight
        # 得到每期的初始持仓权重 因子
        weight_factor = (
            _weight.reindex(signal_tmp.index).reindex(signal_all.index).ffill()
        )
        # 得到修正后的每期持仓信号（包含权重变化）
        signal_all = signal_all / weight_factor

        # 归一化
        signal_all = signal_all.div(signal_all.sum(axis=1).abs(), axis="index")

        if not signal.empty:
            # 最后一期持仓
            date = signal_all.iloc[-1].name
            hold_last = signal_all.iloc[-1].to_frame("weight").dropna()
            hold_last.index.name = "stockid"
            hold_last.reset_index(inplace=True)
            hold_last.sort_values("weight", ascending=False, inplace=True)
            hold_last["date"] = date
            hold_last = hold_last[hold_last.weight.abs() > 1e-6].copy()
        else:
            hold_last = pd.DataFrame(columns=["date", "stockid", "weight"])

        # ============计算收益=================
        _shift = 1
        ret_all = (signal_all * u_value).sum(axis=1)
        ret_all = ret_all.shift(_shift).fillna(0)

        # ===================考虑手续费==========================
        # 手续费修正
        tmp_diff = signal_all.fillna(0).diff().reindex(signal_tmp.index)
        # 做多方向
        tmp_long_diff = (tmp_diff + tmp_diff.abs()) / 2
        # 做空方向
        tmp_short_diff = (tmp_diff.abs() - tmp_diff) / 2

        # =======手续费=====================
        commission_all = (
            -1 * (tmp_long_diff).sum(axis=1) * commission_factor[0]
            - (tmp_short_diff).sum(axis=1) * commission_factor[1]
        ).fillna(0)
        commission_all = commission_all.reindex(trade_dt_list).fillna(0)
        ret_all = ret_all + commission_all
        ret_all = np.exp(np.log1p(ret_all).cumsum())
        # ======================
        ret_all = ret_all[ret_all.index.second == 0]
        return ret_all, hold_last

    @staticmethod
    def _get_turnover(signal, delta):
        """[换手率计算]

        Arguments:
            signal {[pd.DataFrame]} -- [description]
            delta {[int]} -- [len of strategy]

        Returns:
            [type] -- [description]
        """
        t = signal.fillna(0).diff().abs().sum(axis=1).sum() / delta * 252
        return t

    def _hedge_ret(self, long_ret, short_ret):
        """
        计算对冲后收益
        """
        # 如果空头为空
        if short_ret.empty:
            short_ret = long_ret.copy()
            short_ret.iloc[:] = 1

        # 如果多头为空
        if long_ret.empty:
            long_ret = short_ret.copy()
            long_ret.iloc[:] = 1

        trades_dt = self._signal["asset"].index
        if self.matching_type == "next_bar":
            trades_dt -= Commons.SHIFT_TIME
        trades_dt = trades_dt[trades_dt <= self.end_dt]
        long_adjust_factor = (
            (long_ret.reindex(trades_dt).reindex(long_ret.index)).ffill().fillna(1)
        )
        short_adjust_factor = (
            (short_ret.reindex(trades_dt).reindex(short_ret.index)).ffill().fillna(1)
        )
        # 对每期初始资金作调整，此时净值有跳跃
        long_adjust = long_ret / long_adjust_factor
        short_adjust = short_ret / short_adjust_factor
        ratio = (short_adjust / long_adjust).shift(1)
        long_short_ret = (
            long_ret.pct_change(fill_method=None)
            + short_ret.pct_change(fill_method=None) * ratio
        ) / (1 + ratio - 1 / long_adjust.shift(1))
        long_short_ret = (1 + long_short_ret).fillna(1).cumprod()
        return long_short_ret

    def run(self, stats: bool = True, relative: bool = False) -> None:
        """
        Run the backtest.

        Args:
            stats: Whether to calculate performance statistics (default: True)
            relative: Whether to calculate relative returns vs benchmark (default: False)
        """
        # Always try legacy implementation first for stability
        try:
            self._legacy_run(stats, relative)
            return
        except Exception as e:
            # Legacy failed, try new engine
            warnings.warn(
                f"Legacy backtest failed, trying new engine: {e}",
                UserWarning
            )

        # Update config with current settings
        self._update_config()

        try:
            # Use new engine
            self._engine.run(calculate_stats=stats, calculate_relative=relative)
            # Copy results to legacy format
            self.result = self._engine.get_results()

        except Exception as e:
            # Both methods failed
            raise RuntimeError(f"Both legacy and new backtest engines failed: {e}")

    def _legacy_run(self, stats: bool = True, relative: bool = False) -> None:
        """Legacy run method for backward compatibility."""
        if not all([
            isinstance(self._open, pd.DataFrame),
            isinstance(self._close, pd.DataFrame),
            isinstance(self._signal, dict),
        ]):
            raise ValueError("Please add signal and data!")

        # 保证回测数据有足够的品种
        required_columns = set(self._signal["asset"].columns) | set(self._signal["future"].columns)
        if not required_columns.issubset(self._open.columns):
            raise ValueError("Please check data stock range!")

        # 对信号进行修正
        if self.matching_type == "next_bar":
            self._signal["asset"] = (
                self._signal["asset"].reindex(self._open.index).dropna(how="all")
            )
            self._signal["future"] = (
                self._signal["future"].reindex(self._open.index).dropna(how="all")
            )
        else:
            self._signal["asset"] = (
                self._signal["asset"].reindex(self._close.index).dropna(how="all")
            )
            self._signal["future"] = (
                self._signal["future"].reindex(self._close.index).dropna(how="all")
            )

        self._signal["asset"] = (
            self._signal["asset"].loc[self.begin_dt : self.end_dt].copy()
        )
        self._signal["future"] = (
            self._signal["future"].loc[self.begin_dt : self.end_dt].copy()
        )

        # Use legacy methods for calculation
        ret_asset, hold_asset = self._get_ret(self._signal["asset"], self.commission)
        ret_future, hold_future = self._get_ret(self._signal["future"], self.fcommission)
        ret_hedge = self._hedge_ret(ret_asset, ret_future)

        ret_all = pd.concat([
            ret_asset.to_frame("asset"),
            ret_future.to_frame("future"),
            ret_hedge.to_frame("hedge"),
        ], axis=1, sort=False)

        # Handle benchmark
        if self.benchmark:
            benchmark = self._close.reindex([self.benchmark], axis=1)
            if benchmark.empty:
                raise ValueError("请输入正确的基准代码!")
            ret_all = ret_all.join(benchmark)
            ret_all[self.benchmark] = (
                ret_all[self.benchmark] / ret_all[self.benchmark].dropna().iloc[0]
            )
        else:
            self.benchmark = "benchmark"
            ret_all[self.benchmark] = np.exp(np.log1p(self.fixed_rate) / 252) - 1
            ret_all.iloc[0, -1] = 0.0
            ret_all[self.benchmark] = (1 + ret_all[self.benchmark]).cumprod()

        # Calculate relative returns if requested
        if relative:
            trade_dts = self.result.signal["date"]
            trade_dts = trade_dts[
                (trade_dts <= self.end_dt) & (trade_dts >= self.begin_dt)
            ]
            ret_all["relative"] = self._get_relative_ret(
                ret_all["hedge"], ret_all[self.benchmark], trade_dts.unique()
            )

        # Store results
        self.result.nav = ret_all

        # Store holdings
        holdings = []
        if not hold_asset.empty:
            holdings.append(hold_asset)
        if not hold_future.empty:
            holdings.append(hold_future)

        if holdings:
            _hold = pd.concat(holdings, axis=0)
        else:
            _hold = pd.DataFrame(columns=["date", "stockid", "weight"])
        _hold = _hold[_hold["stockid"] != "cash"].copy()
        self.result.hold = _hold.copy()

        # Store benchmark
        self.result.benchmark = self.benchmark

        # Calculate turnover
        delta = len(ret_all)
        self.result.stats.turnover = self._get_turnover(
            self._signal["asset"].drop(["cash"], axis=1, errors="ignore"), delta
        ) + self._get_turnover(
            self._signal["future"].drop(["cash"], axis=1, errors="ignore"), delta
        )

        # Calculate statistics if requested
        if stats:
            s = Stats(
                ret_all["hedge"].pct_change().fillna(0),
                ret_all[self.benchmark].pct_change().fillna(0),
            )
            s.run()
            self.result.stats.update(s.stats)

    def plot(self, log: bool = True, **kwargs) -> None:
        """
        Plot backtest results.

        Args:
            log: Whether to use logarithmic scale (default: True)
            **kwargs: Additional arguments passed to pandas plot method
        """
        if not hasattr(self.result, 'nav') or self.result.nav.empty:
            raise ValueError("No results to plot. Run backtest first.")

        if log:
            # 对数收益
            np.log(self.result.nav).plot(**kwargs)
        else:
            self.result.nav.plot(**kwargs)


if __name__ == "__main__":
    pass
