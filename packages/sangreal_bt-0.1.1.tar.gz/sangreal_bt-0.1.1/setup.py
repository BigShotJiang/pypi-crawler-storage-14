from setuptools import setup, find_packages
import os

# Read README file if it exists
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

setup(
    name='sangreal_bt',
    version='0.1.1',
    description='Vectorized backtesting framework for quantitative trading',
    long_description=read_readme(),
    long_description_content_type='text/markdown',
    author='liubola',
    author_email='lby3523@gmail.com',
    maintainer='liubola',
    maintainer_email='lby3523@gmail.com',
    license='GPL-3.0',
    url='https://github.com/liubola/sangreal-bt',
    project_urls={
        'Bug Reports': 'https://github.com/liubola/sangreal-bt/issues',
        'Source': 'https://github.com/liubola/sangreal-bt',
    },
    packages=find_packages(exclude=['tests', 'tests.*']),
    python_requires='>=3.7',
    install_requires=[
        'pandas>=1.3.0',
        'numpy>=1.19.0',
        'empyrical>=0.5.5',
        'attrs>=21.0.0',
        'addict>=2.4.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0.0',
            'pytest-cov>=2.10.0',
            'black>=21.0.0',
            'flake8>=3.8.0',
            'mypy>=0.800',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Financial and Insurance Industry',
        'Topic :: Office/Business :: Financial :: Investment',
        'Topic :: Scientific/Engineering :: Mathematics',
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Operating System :: OS Independent',
    ],
    keywords='quantitative trading, backtesting, finance, vectorized, investment',
    include_package_data=True,
    zip_safe=False,
)
