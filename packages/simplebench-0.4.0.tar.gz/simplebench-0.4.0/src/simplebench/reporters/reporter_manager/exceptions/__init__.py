"""ErrorTags for ReporterManager exceptions."""
from simplebench.reporters.reporter_manager.exceptions.manager import _ReporterManagerErrorTag

__all__ = [
    "_ReporterManagerErrorTag",
]
