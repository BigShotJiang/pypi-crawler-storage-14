"""Enums for the simplebench.graph.matplotlib package."""
from simplebench.reporters.graph.matplotlib.enums.style import Style

__all__ = [
    "Style",
]
