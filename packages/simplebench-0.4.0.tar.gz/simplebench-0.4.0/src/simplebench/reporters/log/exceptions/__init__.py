"""simplebench.reporters.log.exceptions package initialization."""

from .report_log_metadata import _ReportLogMetadataErrorTag

__all__ = [
    "_ReportLogMetadataErrorTag",
]
