This module extends `base_external_dbsource`, allowing you to connect to
foreign MSSQL databases using SQLAlchemy.
