To configure this module, you need to:

1.  Database sources can be configured in Settings \> Technical \>
    Database Structure \> Database sources.
