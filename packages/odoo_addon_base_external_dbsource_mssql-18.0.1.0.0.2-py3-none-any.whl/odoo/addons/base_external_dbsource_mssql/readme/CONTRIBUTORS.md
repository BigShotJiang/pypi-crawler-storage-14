  - Daniel Reis \<<dreis.pt@hotmail.com>\>

  - Maxime Chambreuil \<<maxime.chambreuil@savoirfairelinux.com>\>

  - Gervais Naoussi \<<gervaisnaoussi@gmail.com>\>

  - Dave Lasley \<<dave@laslabs.com>\>

  -   - [Tecnativa](https://www.tecnativa.com):

          - Sergio Teruel
          - Carolina Fernandez

  - Andrea Cattalani ([Moduon](https://www.moduon.team/))
