To install this module, you need to:

  - Install & configure FreeTDS driver (tdsodbc package)
  - Install `sqlalchemy` & `pymssql` python libraries
  - Install `base_external_dbsource` Odoo module
