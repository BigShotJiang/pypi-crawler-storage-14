#mySQLDBCtrlAPI

## History of version
Version 1.2511.26: 2025/11/26<BR>
Fixed CUF_DB_OpenSQL(...) return failure when Null data.

Version 1.2511.06: 2025/11/25<BR>
Fixed Eof() bugs.


Version 1.2511.06: 2025/11/06<BR>
Fixed utf8 and big5(latin) encode bugs.

Version 1.2510.23: 2025/10/22<BR>
Fixed version bugs.

Version 1.2510.22: 2025/10/22<BR>
1.Add string decode method (translage utf8 charset -> utf-8)
2.Add Eof() procedure 
3.Fixed CUF_DB_ExecSQL() and CUF_DB_OpenSQL() bugs.


Version 0.1.2: 2025/10/09<BR>
Add string decode method (translage big5 charset -> utf-8)

Version 0.1.1: 2025/09/19<BR>
Fixed some bugs.
