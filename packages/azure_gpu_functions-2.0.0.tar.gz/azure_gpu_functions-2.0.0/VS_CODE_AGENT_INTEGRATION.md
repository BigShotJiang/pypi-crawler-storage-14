# VS Code Agent Integration with MCP Server

This guide shows how to use the MCP server with VS Code agents (like Cline, Roo Code, or Claude Code) to easily launch large training and inference tasks on GPU infrastructure.

## 🚀 Quick Start

### 1. Install VS Code Agent Extension

Choose one of these MCP-compatible agents:

```vscode-extensions
saoudrizwan.claude-dev,rooveterinaryinc.roo-cline,anthropic.claude-code,automatalabs.copilot-mcp
```

### 2. Configure MCP Server

Create or update your VS Code MCP configuration:

**For Cline/Roo Code:**
- Open VS Code Settings (Ctrl/Cmd + ,)
- Search for "cline" or "roo"
- Add MCP server configuration:

```json
{
  "cline.mcpServers": {
    "gpu-training": {
      "command": "python3",
      "args": ["ray_mcp_server.py"],
      "cwd": "/Users/xcallens/xdev/appfunctiongpu",
      "env": {
        "PYTHONPATH": "/Users/xcallens/xdev/appfunctiongpu",
        "RAY_ADDRESS": "auto"
      }
    }
  }
}
```

**For Claude Code:**
Create `~/.claude/config.json`:

```json
{
  "mcpServers": {
    "gpu-training": {
      "command": "python3",
      "args": ["ray_mcp_server.py"],
      "cwd": "/Users/xcallens/xdev/appfunctiongpu"
    }
  }
}
```

### 3. Start Using the Agent

Once configured, you can ask the VS Code agent to:

```
"Launch a medium-sized DialoGPT training job on T4 GPU"
"Start inference on the latest trained model"
"Check the status of my training session"
"Pause the current training and get cost estimate"
"Resume training from checkpoint"
```

## 🎯 Available MCP Commands

### Training Management
- **Launch Training**: `launch_training` - Start new training jobs
- **Pause Training**: `pause_training` - Pause running jobs
- **Resume Training**: `resume_training` - Resume from checkpoint
- **Snapshot Training**: `snapshot_training` - Create training snapshots
- **Training Status**: `get_training_status` - Monitor progress
- **Completion Estimate**: `estimate_completion_time` - Time remaining
- **Cost Estimation**: `get_cost_estimate` - Pre-launch cost calculation
- **Cost Monitoring**: `monitor_cost` - Real-time cost tracking

### Cluster Management
- **Cluster Status**: `get_cluster_status` - Ray cluster health
- **Node Status**: `get_node_status` - Individual node status
- **Scale Cluster**: `scale_cluster` - Adjust cluster size

## 💡 Example Agent Interactions

### Launch Training
```
User: "Start a large DialoGPT training job with custom learning rate"

Agent: I'll use the MCP server to launch training...
- Config: large (batch_size: 16, epochs: 10)
- GPU: A100 ($4.80/hr)
- Estimated cost: $48.00
- Launching training session: train_12345

✅ Training launched successfully!
Session ID: train_12345
Status: running
```

### Monitor Progress
```
User: "How's my training doing?"

Agent: Checking training status via MCP...
- Session: train_12345
- Progress: 35% complete
- Current epoch: 3.5/10
- Estimated time remaining: 4.2 hours
- Current cost: $16.80
- GPU utilization: 92%
```

### Cost Management
```
User: "What's the cost estimate for a small training job?"

Agent: Getting cost estimate from MCP server...
- Configuration: small
- GPU Type: T4 ($1.60/hr)
- Estimated duration: 2 hours
- Total cost: $3.20
- Cost per epoch: $0.32
```

## 🔧 Advanced Configuration

### Environment Variables
```bash
export PYTHONPATH="/Users/xcallens/xdev/appfunctiongpu"
export RAY_ADDRESS="auto"
export AZURE_STORAGE_CONNECTION_STRING="your_connection_string"
```

### Custom Training Configs
Add to `training_functions.py`:

```python
TRAINING_CONFIGS["custom"] = {
    "model_name": "microsoft/DialoGPT-medium",
    "batch_size": 8,
    "learning_rate": 5e-5,
    "num_epochs": 5,
    "max_length": 512,
    "estimated_duration_min": 15
}
```

### Multi-GPU Training
```python
# For distributed training
config = {
    "num_gpus": 4,
    "distributed": True,
    "strategy": "ddp"  # DistributedDataParallel
}
```

## 📊 Agent Workflow Examples

### Complete Training Workflow
1. **Planning**: Agent analyzes requirements and selects optimal config
2. **Cost Estimation**: Pre-launch cost calculation and approval
3. **Launch**: Start training with monitoring
4. **Monitoring**: Real-time progress and cost tracking
5. **Control**: Pause/resume/snapshot as needed
6. **Completion**: Automatic notification and results summary

### Inference Workflow
1. **Model Selection**: Choose from available trained models
2. **Resource Allocation**: Select appropriate GPU for inference
3. **Batch Processing**: Configure batch size and optimization
4. **Execution**: Run inference with performance monitoring
5. **Results**: Collect and analyze outputs

## 🛠️ Troubleshooting

### Common Issues

**MCP Server Not Connecting:**
```bash
# Check if server is running
ps aux | grep ray_mcp_server

# Start manually
cd /Users/xcallens/xdev/appfunctiongpu
python3 ray_mcp_server.py
```

**Ray Cluster Issues:**
```bash
# Check Ray status
ray status

# Restart Ray
ray stop
ray start --head
```

**GPU Not Available:**
```python
# Check GPU status
from training_functions import check_gpu_availability
print(check_gpu_availability())
```

### Debug Mode
Enable debug logging in VS Code:
```json
{
  "cline.debug": true,
  "cline.mcpServers": {
    "gpu-training": {
      "command": "python3",
      "args": ["ray_mcp_server.py", "--debug"],
      "cwd": "/Users/xcallens/xdev/appfunctiongpu"
    }
  }
}
```

## 🎨 Custom Agent Prompts

### Training Specialist Agent
```
You are a GPU training specialist. Use the MCP server to:
1. Analyze training requirements
2. Select optimal configurations
3. Estimate costs before launching
4. Monitor training progress
5. Handle interruptions gracefully
6. Provide completion summaries
```

### Cost Optimization Agent
```
You are a cost optimization expert. Use MCP to:
1. Compare training costs across configurations
2. Monitor real-time spending
3. Suggest cost-saving measures
4. Track budget vs actual spending
5. Recommend optimal GPU types
```

## 📈 Performance Metrics

The MCP server provides:
- **Real-time monitoring**: GPU utilization, memory usage, training progress
- **Cost tracking**: Per-second cost calculation, budget alerts
- **Performance analytics**: Training speed, convergence metrics
- **Resource optimization**: Automatic scaling recommendations

## 🔒 Security Considerations

- **API Keys**: Store Azure credentials securely
- **Network Security**: Use HTTPS for production deployments
- **Access Control**: Implement authentication for MCP server
- **Cost Limits**: Set budget limits and alerts

## 🚀 Production Deployment

For production use:

1. **Deploy to Azure Functions**: Use the provided function_app.py
2. **Configure Auto-scaling**: Set up Ray cluster auto-scaling
3. **Monitoring**: Integrate with Azure Monitor
4. **Backup**: Regular model checkpoints and snapshots

## 📚 Additional Resources

- [MCP Protocol Documentation](https://modelcontextprotocol.io/)
- [Ray Documentation](https://docs.ray.io/)
- [Azure Functions Documentation](https://docs.microsoft.com/azure/azure-functions/)
- [VS Code Agent Extensions](https://marketplace.visualstudio.com/)

---

**Ready to launch your first training job?** Ask your VS Code agent: *"Launch a small DialoGPT training job and monitor its progress!"*