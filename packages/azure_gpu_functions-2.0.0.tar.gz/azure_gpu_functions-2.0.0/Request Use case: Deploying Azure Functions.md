# Azure Container Apps GPU Quota Request

## Problem Description

We are attempting to deploy Azure Functions with GPU acceleration for AI/ML workloads using PyTorch, but are blocked by insufficient GPU quota in Azure Container Apps.

**Current Issue:**
- Deployment fails with quota error: "Regional max quota limit threshold hit"
- Current quota: 0 for both Consumption GPU types in Sweden Central
- Need GPU support for PyTorch model inference and GPU availability testing

**Impact:**
- Unable to deploy GPU-accelerated Azure Functions for AI/ML workloads
- Development and testing of PyTorch applications blocked
- Cannot validate GPU functionality in serverless environment

## Recommended Solution

Request quota increases for Azure Container Apps Consumption GPU workloads to enable deployment of GPU-accelerated Azure Functions.

**Requested Quotas:**

1. **A100 GPUs (Heavy Workloads):**
   - Quota Type: Managed Environment Consumption NCA100 Gpus
   - Region: Sweden Central
   - Requested Limit: 24 vCPU
   - GPU Profile: Consumption-GPU-NC24-A100 (1x NVIDIA A100 80GB GPU)
   - Use Case: Intensive PyTorch models, large matrix operations, production workloads

2. **T4 GPUs (Development/Testing):**
   - Quota Type: Managed Environment Consumption T4 Gpus
   - Region: Sweden Central
   - Requested Limit: 16 vCPU
   - GPU Profile: Consumption-GPU-NC16-T4 (1x NVIDIA T4 16GB GPU)
   - Use Case: Development testing, smaller models, cost-effective validation

## Additional Details

**Technical Requirements:**
- Azure Container Apps environment with GPU workload profiles
- PyTorch 2.9.1+cu121 with CUDA 12.1 support
- Azure Functions 4.4.1 runtime
- Container image: CUDA 12.1 + Python 3.11 base

**Business Justification:**
- AI/ML application development and deployment
- GPU-accelerated model inference in serverless environment
- Cost-effective scaling with Consumption GPUs (pay-per-use)
- Support for both development/testing (T4) and production (A100) workloads

**Current Infrastructure:**
- Subscription: amacp-tst-ne-gem-01 (283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba)
- Azure Container Registry: acrgpufunctest.azurecr.io
- Region: Sweden Central (selected for Consumption GPU availability)
- All other Azure resources (storage, Log Analytics) already provisioned

**Timeline Requirements:**
- Quota approval needed to complete deployment within 1-2 weeks
- Consumption GPUs preferred over dedicated (faster approval, serverless scaling)

**Expected Outcome:**
- Deploy GPU-enabled Azure Functions for PyTorch workloads
- Validate GPU functionality with /api/gpu-status and /api/gpu-test endpoints
- Enable flexible scaling between T4 (development) and A100 (production) GPUs