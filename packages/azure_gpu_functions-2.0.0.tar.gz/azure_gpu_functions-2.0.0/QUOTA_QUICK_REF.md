# 🚀 A100 GPU Quota Request - Quick Reference

## Essential Information
- **Subscription**: `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba`
- **Region**: `North Europe`
- **GPU Type**: `NVIDIA A100 (NC24ads_A100_v4)`
- **Requested Cores**: `24` (for 1 instance)
- **Use Case**: LLM training for Amadeus test environment

## Quick Steps

### 1. Submit Request
🌐 **Azure Portal**: [portal.azure.com](https://portal.azure.com) → Help + support → New support request

### 2. Request Details
```
Issue type: Service and subscription limits (quotas)
Quota type: Compute-VM (cores-vCPUs) subscription limit increases
Location: North Europe
VM Series: NCads A100 v4 Series
New vCPU Limit: 24
```

### 3. Business Justification
```
Project: Large Language Model training for Amadeus applications
Environment: Test/Development
Duration: 3-6 months
Usage: 1-3 concurrent A100 instances, scale-to-zero capability
Models: Mistral 70B and similar large language models
```

### 4. Expected Timeline
- **Response**: 2-3 business days
- **Approval**: 5-10 business days
- **Activation**: Immediate after approval

### 5. After Approval
```bash
# Deploy infrastructure
cd /Users/xcallens/xdev/appfunctiongpu
./deploy.sh

# Test GPU availability
python test_function.py https://your-function-url
```

## 📞 Emergency Contacts
- **Azure Support**: Create ticket in portal
- **Account Manager**: Contact Amadeus Azure team
- **Technical Issues**: Reference main guide: `A100_QUOTA_REQUEST_GUIDE.md`

---
**💡 Tip**: Keep your ticket number handy for follow-ups!