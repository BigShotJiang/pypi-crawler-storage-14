# 🚀 Simple GPU Function Deployment Guide

## Quick Start

Your Azure session has expired. Follow these steps to deploy:

### 1️⃣ Login to Azure
```bash
./login.sh
```
This will:
- Logout from expired session
- Login to Azure with your credentials
- Set the correct subscription

### 2️⃣ Deploy the Function
```bash
./deploy_simple.sh
```
This will:
- Create resource group in North Europe
- Create container registry
- Build and push the GPU-enabled Docker image
- Create Container Apps environment with A100 GPU support
- Deploy the Azure Function with GPU

**Expected deployment time:** 5-10 minutes

### 3️⃣ Test the GPU Function
```bash
./test_gpu_function.sh <your-function-url>
```
The URL will be displayed at the end of deployment.

## What Gets Deployed

### Simple GPU Test Function
Three endpoints to test A100 GPU:

| **Endpoint** | **Purpose** | **Returns** |
|-------------|-------------|-------------|
| `/api/health` | Health check | Service status |
| `/api/gpu-status` | GPU info | CUDA, PyTorch, memory details |
| `/api/gpu-test` | GPU computation | Matrix multiplication test |

### Azure Resources
- **Container Apps Environment**: With NC4as-A100-v4 workload profile
- **Function App**: 4 vCPU A100, 64GB RAM, auto-scaling (0-1 replicas)
- **Container Registry**: Stores the GPU-enabled container image
- **Storage Account**: Required for Azure Functions runtime
- **Log Analytics**: For monitoring and diagnostics

## Key Features

✅ **4 vCPU A100 GPU** - Uses your available quota  
✅ **Scale to Zero** - $0 when idle, saves costs  
✅ **PyTorch + CUDA 12.1** - Ready for GPU computing  
✅ **Auto-scaling** - Cold start ~30-60 seconds  
✅ **No azd required** - Uses only Azure CLI  

## Cost Estimates

| **State** | **Cost** |
|----------|----------|
| **Idle (scaled to zero)** | ~$0/hour |
| **Running (with GPU)** | ~$1.75/hour |
| **Monthly (8h/day)** | ~$420 |

## Troubleshooting

### Authentication Issues
```bash
# Re-login
./login.sh
```

### Check Deployment Status
```bash
az containerapp show \
  --name func-gpu-test \
  --resource-group rg-llm-gpu-function-test \
  --query properties.provisioningState
```

### View Logs
```bash
az containerapp logs show \
  --name func-gpu-test \
  --resource-group rg-llm-gpu-function-test \
  --follow
```

### Cleanup Resources
```bash
az group delete --name rg-llm-gpu-function-test --yes --no-wait
```

## Next Steps

After successful deployment:

1. **Test GPU availability** - Verify A100 is detected
2. **Check performance** - Run matrix multiplication test
3. **Monitor costs** - Set up billing alerts
4. **Scale up** - Add more complex GPU workloads

## Expected Test Results

### GPU Status Response
```json
{
  "gpu": {
    "status": "success",
    "gpu_available": true,
    "device_name": "NVIDIA A100-PCIE-40GB",
    "cuda_version": "12.1",
    "memory_total_gb": 40.0,
    "memory_free_gb": 38.5
  },
  "system": {
    "cpu_count": 4,
    "memory_total_gb": 64.0
  }
}
```

### GPU Test Response
```json
{
  "status": "success",
  "test": "matrix_multiplication",
  "matrix_size": "1000x1000",
  "computation_time_seconds": 0.0234,
  "device": "NVIDIA A100-PCIE-40GB"
}
```

## Files Created

- `function_app_simple.py` - Simplified GPU test function
- `requirements_simple.txt` - Minimal dependencies (PyTorch + Azure Functions)
- `Dockerfile.simple` - CUDA 12.1 + Python 3.11 container
- `deploy_simple.sh` - Automated deployment script
- `login.sh` - Azure authentication helper
- `test_gpu_function.sh` - Function testing script

🎯 **Ready to deploy!** Run `./login.sh` to get started.
