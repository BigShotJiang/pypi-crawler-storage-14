# Training Registry and Artifacts Backup Management System

A comprehensive SQLite-based registry system for tracking training sessions, models, artifacts, and automated backup management for Azure Functions GPU training applications.

## 🚀 Features

### Core Functionality
- **Training Session Tracking**: Complete lifecycle management of LLM training sessions
- **Artifact Management**: Automatic registration and backup of model checkpoints, training results, logs, and configurations
- **Docker Image Registry**: Track and manage training container images with metadata
- **Automated Backup**: Azure Storage integration with local fallback for comprehensive artifact backup
- **Cost Tracking**: Integration with training cost analysis and optimization
- **Real-time Monitoring**: MCP server integration for live training session monitoring

### Backup Management
Following the established pattern from `Artifacts Backed Up.md`:

```
Model Checkpoints (12 files): checkpoints → model-checkpoints container
Training Results (35 files): results → training-results container
Training Logs (3 files): logs → training-logs container
Docker Images: cab2c49f07b3acr.azurecr.io/deepproblog-training-optimized:20251122_224555
```

### Key Benefits
- **🚀 Massive Speed Improvements**: Pre-built optimized images reduce container build time from 45-60 minutes to <5 minutes
- **💰 Cost Reduction**: Automated artifact management and storage optimization
- **📊 Comprehensive Analytics**: Detailed training metrics, cost analysis, and performance tracking
- **🔄 Automated Operations**: Background monitoring, auto-recovery, and scheduled maintenance
- **☁️ Cloud Integration**: Seamless Azure Storage and Container Registry integration

## 📋 Table of Contents

- [Installation](#installation)
- [Configuration](#configuration)
- [API Reference](#api-reference)
- [Usage Examples](#usage-examples)
- [Backup Management](#backup-management)
- [Integration with Azure Functions](#integration-with-azure-functions)
- [Testing](#testing)
- [Architecture](#architecture)

## 🛠️ Installation

### Prerequisites
- Python 3.8+
- SQLite3
- Azure CLI (for Azure Storage integration)
- Azure Storage Account (optional, local fallback available)

### Install Dependencies

```bash
pip install azure-storage-blob azure-identity
```

### Initialize Registry

```python
from training_registry import get_training_registry

# Initialize with default database
registry = get_training_registry()

# Or specify custom database path
registry = get_training_registry("path/to/training_registry.db")
```

## ⚙️ Configuration

### Environment Variables

```bash
# Azure Storage Configuration (optional)
AZURE_STORAGE_ACCOUNT_NAME=your_storage_account
AZURE_STORAGE_CONTAINER_NAME=training-registry

# Registry Configuration
TRAINING_REGISTRY_DB_PATH=training_registry.db
BACKUP_RETENTION_DAYS=90
```

### Azure Storage Setup

1. Create Azure Storage Account
2. Create containers for different artifact types:
   - `model-checkpoints`
   - `training-results`
   - `training-logs`
   - `training-configs`
   - `training-data`

3. Configure Azure CLI authentication:
   ```bash
   az login
   ```

## 📚 API Reference

### TrainingRegistry Class

#### Core Methods

```python
class TrainingRegistry:
    def create_training_session(self, session: TrainingSession) -> bool
    def update_training_session(self, session_id: str, updates: Dict[str, Any]) -> bool
    def get_training_session(self, session_id: str) -> Optional[TrainingSession]
    def list_training_sessions(self, status: Optional[str] = None, limit: int = 50) -> List[TrainingSession]

    def register_artifact(self, artifact: ModelArtifact) -> bool
    def get_session_artifacts(self, session_id: str, artifact_type: Optional[str] = None) -> List[ModelArtifact]

    def register_docker_image(self, image: DockerImage) -> bool
    def get_session_images(self, session_id: str) -> List[DockerImage]

    def backup_training_artifacts(self, session_id: str, backup_type: str = "full") -> Dict[str, Any]
    def get_registry_stats(self) -> Dict[str, Any]
    def cleanup_old_sessions(self, days: int = 90) -> int
```

#### Data Classes

```python
@dataclass
class TrainingSession:
    session_id: str
    training_type: str  # 'small', 'medium', 'large', 'xl'
    model_name: str
    framework: str  # 'pytorch', 'tensorflow'
    status: str  # 'initializing', 'training', 'completed', 'failed'
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    cost_usd: Optional[float] = None
    gpu_type: str = "T4"
    config: Dict[str, Any] = None
    metrics: Dict[str, Any] = None
    error_message: Optional[str] = None

@dataclass
class ModelArtifact:
    artifact_id: str
    session_id: str
    artifact_type: str  # 'checkpoint', 'result', 'log', 'config'
    filename: str
    file_path: str
    file_size_bytes: int
    checksum: str
    backup_location: Optional[str] = None
    backup_status: str = "pending"

@dataclass
class DockerImage:
    image_id: str
    session_id: str
    image_name: str
    image_tag: str
    registry_url: str
    build_time: datetime
    base_image: Optional[str] = None
    size_gb: Optional[float] = None
    status: str = "active"
```

### Convenience Functions

```python
def register_training_session(session_id: str, training_type: str, model_name: str,
                            framework: str, config: Dict[str, Any] = None) -> bool

def complete_training_session(session_id: str, metrics: Dict[str, Any] = None,
                            cost_usd: float = None, error_message: Optional[str] = None) -> bool

def register_artifact(session_id: str, artifact_type: str, file_path: str,
                     backup_location: Optional[str] = None) -> bool

def backup_session_artifacts(session_id: str) -> Dict[str, Any]

def get_registry_stats() -> Dict[str, Any]
```

## 💡 Usage Examples

### Basic Training Session Management

```python
from training_registry import register_training_session, complete_training_session, register_artifact
import uuid

# Start a training session
session_id = str(uuid.uuid4())
config = {
    "model_name": "mistralai/Mistral-7B-v0.1",
    "batch_size": 8,
    "learning_rate": 2e-5,
    "num_epochs": 3,
    "gpu_type": "T4"
}

success = register_training_session(
    session_id=session_id,
    training_type="large",
    model_name=config["model_name"],
    framework="pytorch",
    config=config
)

# Register artifacts during training
register_artifact(session_id, "checkpoint", "./checkpoints/model_epoch_1.bin")
register_artifact(session_id, "log", "./logs/training.log")
register_artifact(session_id, "config", "./config/training_config.json")

# Complete the session
complete_training_session(
    session_id=session_id,
    metrics={
        "final_loss": 0.234,
        "validation_accuracy": 0.89,
        "training_samples": 10000
    },
    cost_usd=2.45
)
```

### Automated Backup Management

```python
from training_registry import backup_session_artifacts

# Perform comprehensive backup
backup_result = backup_session_artifacts(session_id)

print(f"Backup completed: {backup_result['total_files']} files")
print(f"Total size: {backup_result['total_size_bytes'] / (1024*1024):.2f} MB")

# Backup result includes:
# - Artifacts by type with upload counts
# - Docker images information
# - Backup summary file location
```

### Registry Statistics and Analytics

```python
from training_registry import get_registry_stats

stats = get_registry_stats()

print("Registry Statistics:")
print(f"Total Sessions: {stats['training_sessions']['total']}")
print(f"Completed: {stats['training_sessions']['completed']}")
print(f"Total Cost: ${stats['training_sessions']['total_cost_usd']:.2f}")
print(f"Artifacts: {stats['artifacts']['total']} ({stats['artifacts']['backed_up']} backed up)")
print(f"Storage Used: {stats['artifacts']['total_size_gb']:.2f} GB")
```

### Docker Image Management

```python
from training_registry import get_training_registry
from datetime import datetime

registry = get_training_registry()

# Register a Docker image
from training_registry import DockerImage
import uuid

image = DockerImage(
    image_id=str(uuid.uuid4()),
    session_id=session_id,
    image_name="deepproblog-training-optimized",
    image_tag="20251122_224555",
    registry_url="cab2c49f07b3acr.azurecr.io",
    build_time=datetime.utcnow(),
    size_gb=15.2,
    base_image="mcr.microsoft.com/azureml/openmpi4.1.0-cuda11.8-cudnn8-ubuntu22.04-py38"
)

registry.register_docker_image(image)
```

## 🔄 Backup Management

### Automated Backup Process

The system automatically creates backups following this structure:

```
backups/
├── {session_id}/
│   ├── checkpoints/
│   │   ├── model_epoch_1.bin
│   │   ├── model_epoch_2.bin
│   │   └── ...
│   ├── results/
│   │   ├── training_metrics.json
│   │   └── evaluation_results.json
│   ├── logs/
│   │   ├── training.log
│   │   └── system.log
│   └── backup_summary.md
```

### Backup Summary Format

Each backup generates a comprehensive summary file:

```markdown
# Training Session Backup Summary
Session ID: 12345678-1234-1234-1234-123456789abc
Training Type: large
Model Name: mistralai/Mistral-7B-v0.1
Backup Timestamp: 2025-11-23T10:30:00Z

## Artifacts Backed Up:
Checkpoints (12 files): checkpoints → model-checkpoints container
Results (35 files): results → training-results container
Logs (3 files): logs → training-logs container

## Docker Images Backed Up:
deepproblog-training-optimized:20251122_224555
Registry: cab2c49f07b3acr.azurecr.io
Build Time: 2025-11-22T22:45:55Z
Size: 15.20 GB

## Backup Statistics:
- Total Files: 50
- Total Size: 2.34 GB
- Backup Location: training-registry/backups/12345678-1234-1234-1234-123456789abc

## 🚀 Future Training Benefits
- Pre-built optimized images available
- Time Saved: ~50-55 minutes per training run (using cached artifacts)
- Cost Reduction: Reduced container build time and storage costs
```

## 🔗 Integration with Azure Functions

### HTTP API Endpoints

The registry integrates with Azure Functions through dedicated endpoints:

#### Management Routes (`/manage?action=...`)

```bash
# Get registry statistics
GET /manage?action=registry-stats

# Get training sessions from registry
GET /manage?action=registry-sessions&status=completed&limit=50

# Backup session artifacts
GET /manage?action=backup-artifacts&session_id=12345678-1234-1234-1234-123456789abc

# Cleanup old registry entries
GET /manage?action=cleanup-registry&days=90
```

#### Registry Routes (`/registry?action=...`)

```bash
# Get comprehensive registry statistics
GET /registry?action=stats

# Get training sessions
GET /registry?action=sessions&status=completed&limit=50

# Get artifacts for a session
GET /registry?action=artifacts&session_id=12345678-1234-1234-1234-123456789abc

# Register new artifact
POST /registry?action=register-artifact
{
  "session_id": "12345678-1234-1234-1234-123456789abc",
  "artifact_type": "checkpoint",
  "file_path": "/path/to/model.bin"
}

# Register Docker image
POST /registry?action=register-docker-image
{
  "session_id": "12345678-1234-1234-1234-123456789abc",
  "image_name": "training-image",
  "image_tag": "v1.0",
  "registry_url": "acr.azurecr.io",
  "build_time": "2025-11-23T10:00:00Z",
  "size_gb": 10.5
}

# Backup session artifacts
POST /registry?action=backup-session
{
  "session_id": "12345678-1234-1234-1234-123456789abc"
}

# Cleanup registry
POST /registry?action=cleanup
{
  "days": 90
}
```

### Integration Example

```python
# In your training function
from training_registry import register_training_session, complete_training_session, register_artifact, backup_session_artifacts

@app.function_name("TrainLLM")
def train_llm(req: func.HttpRequest) -> func.HttpResponse:
    session_id = str(uuid.uuid4())

    # Register session
    register_training_session(
        session_id=session_id,
        training_type="large",
        model_name="mistralai/Mistral-7B-v0.1",
        framework="pytorch"
    )

    try:
        # Training logic here...
        # ...

        # Register artifacts
        register_artifact(session_id, "checkpoint", output_dir / "model.bin")
        register_artifact(session_id, "log", output_dir / "training.log")

        # Complete session
        complete_training_session(session_id, metrics=training_metrics, cost_usd=cost)

        # Backup everything
        backup_result = backup_session_artifacts(session_id)

        return func.HttpResponse(
            json.dumps({
                "status": "success",
                "session_id": session_id,
                "backup": backup_result
            }),
            status_code=200
        )

    except Exception as e:
        complete_training_session(session_id, error_message=str(e))
        raise
```

## 🧪 Testing

### Run Test Suite

```bash
python test_training_registry.py
```

### Test Coverage

The test suite covers:
- ✅ Training session CRUD operations
- ✅ Artifact registration and retrieval
- ✅ Docker image management
- ✅ Backup operation tracking
- ✅ Registry statistics
- ✅ Convenience functions
- ✅ Cleanup operations
- ✅ Backup summary generation

### Manual Testing

```python
# Test basic functionality
from training_registry import get_training_registry
import uuid

registry = get_training_registry(":memory:")  # In-memory database for testing

# Create test session
session_id = str(uuid.uuid4())
session = TrainingSession(
    session_id=session_id,
    training_type="test",
    model_name="test-model",
    framework="pytorch",
    status="running",
    start_time=datetime.utcnow()
)

assert registry.create_training_session(session)
assert registry.get_training_session(session_id) is not None

print("✅ Basic functionality test passed")
```

## 🏗️ Architecture

### Database Schema

```sql
-- Training sessions
CREATE TABLE training_sessions (
    session_id TEXT PRIMARY KEY,
    training_type TEXT NOT NULL,
    model_name TEXT NOT NULL,
    framework TEXT NOT NULL,
    status TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT,
    duration_seconds REAL,
    cost_usd REAL,
    gpu_type TEXT DEFAULT 'T4',
    config TEXT,  -- JSON
    metrics TEXT,  -- JSON
    error_message TEXT,
    created_at TEXT NOT NULL
);

-- Model artifacts
CREATE TABLE model_artifacts (
    artifact_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    filename TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size_bytes INTEGER NOT NULL,
    checksum TEXT NOT NULL,
    backup_location TEXT,
    backup_status TEXT DEFAULT 'pending',
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES training_sessions (session_id)
);

-- Docker images
CREATE TABLE docker_images (
    image_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    image_name TEXT NOT NULL,
    image_tag TEXT NOT NULL,
    registry_url TEXT NOT NULL,
    build_time TEXT NOT NULL,
    base_image TEXT,
    size_gb REAL,
    status TEXT DEFAULT 'active',
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES training_sessions (session_id)
);

-- Backup operations
CREATE TABLE backup_operations (
    backup_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    backup_type TEXT NOT NULL,
    status TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT,
    total_files INTEGER DEFAULT 0,
    total_size_bytes INTEGER DEFAULT 0,
    destination TEXT NOT NULL,
    error_message TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES training_sessions (session_id)
);
```

### Component Integration

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Azure Functions │    │  Training       │    │  Azure Storage  │
│  Application    │◄──►│  Registry       │◄──►│  Containers     │
│                 │    │  (SQLite)       │    │                 │
└─────────────────┘    └──────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│  Ray Monitor    │    │  MCP Server      │    │  Model Storage  │
│  (Real-time)    │    │  (WebSocket)     │    │  (Caching)      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

### Performance Optimizations

- **Indexed Queries**: Optimized database indexes for fast lookups
- **Batch Operations**: Efficient bulk artifact registration
- **Lazy Loading**: On-demand loading of large datasets
- **Connection Pooling**: SQLite connection reuse for better performance
- **Background Processing**: Asynchronous backup operations

## 📊 Monitoring and Analytics

### Registry Statistics

```python
stats = registry.get_registry_stats()

{
  "training_sessions": {
    "total": 150,
    "completed": 142,
    "failed": 8,
    "active": 3,
    "total_cost_usd": 2345.67,
    "avg_duration_seconds": 3600.5
  },
  "artifacts": {
    "total": 2500,
    "backed_up": 2450,
    "total_size_bytes": 107374182400,
    "total_size_gb": 100.0
  },
  "docker_images": {
    "total": 45
  },
  "backups": {
    "total": 148,
    "successful": 145
  }
}
```

### Cost Analysis Integration

The registry integrates with cost analysis for comprehensive training economics:

- **Per-Session Cost Tracking**: Detailed cost breakdown per training run
- **Artifact Storage Costs**: Azure Storage cost optimization
- **Time-to-Value Metrics**: Training completion time vs. cost analysis
- **ROI Calculations**: Cost-benefit analysis for different training configurations

## 🔧 Maintenance

### Regular Cleanup

```python
# Clean up sessions older than 90 days
cleaned_count = registry.cleanup_old_sessions(days=90)
print(f"Cleaned up {cleaned_count} old sessions")
```

### Database Optimization

```python
# Rebuild indexes for better performance
# (SQLite automatically manages this, but can be triggered manually if needed)

# Vacuum database to reclaim space
import sqlite3
with sqlite3.connect("training_registry.db") as conn:
    conn.execute("VACUUM")
```

### Backup Strategy

- **Automated Backups**: Daily registry database backups
- **Artifact Retention**: Configurable retention policies
- **Cross-Region Replication**: Azure Storage geo-redundancy
- **Disaster Recovery**: Point-in-time restore capabilities

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add comprehensive tests
4. Ensure all tests pass
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Check the troubleshooting guide
- Review the API documentation
- Open an issue on GitHub
- Contact the development team

---

**Built for Azure Functions GPU Training Applications**
*Comprehensive artifact management for production ML training workflows*