# GPU Deployment Blocker - Environment Creation Issue

## Problem

**Azure Container Apps GPU workload profiles CANNOT be added via Azure CLI after environment creation.**

Error message:
```
(GPUWorkloadProfileCannotBeAddedToExistingEnvironment) The workload profile for GPU cannot be added after the managed environment creation.
```

## Root Cause

According to Microsoft documentation:
> "You can only add a Dedicated GPU workload profile when initially creating an environment."

The Azure CLI command `az containerapp env create` does NOT support adding GPU workload profiles during environment creation. The `--enable-workload-profiles` flag only enables the general workload profiles feature, but doesn't allow specifying GPU profiles at creation time.

## Attempted Solutions

1. ✅ **Tried**: `az containerapp env workload-profile add` after environment creation
   - ❌ **Result**: Error - GPU profiles cannot be added after creation

2. ✅ **Tried**: Delete and recreate environment with `--enable-workload-profiles`, then add GPU profile
   - ❌ **Result**: Same error - GPU profiles must be added DURING creation

3. ✅ **Tried**: Using both "NC24-A100" (Dedicated) and "Consumption-GPU-NC24-A100" profile types
   - ❌ **Result**: Both failed with the same error

## Available Workarounds

### Option 1: Azure Portal (Recommended for this scenario)

Create the Container Apps environment through the Azure Portal:

1. Go to Azure Portal → Container Apps
2. Create new environment
3. Select region: **North Europe** (has A100 support)
4. Enable "Workload profiles"
5. Add GPU workload profile:
   - Type: **NC24-A100** (Dedicated)
   - Name: `gpua100`
   - Min nodes: 1
   - Max nodes: 1

### Option 2: ARM Template or Bicep

Create an ARM template or Bicep file that defines the environment with the GPU workload profile included in the initial configuration.

Example Bicep snippet:
```bicep
resource env 'Microsoft.App/managedEnvironments@2023-05-01' = {
  name: 'gpu-func-env'
  location: 'northeurope'
  properties: {
    workloadProfiles: [
      {
        name: 'Consumption'
        workloadProfileType: 'Consumption'
      }
      {
        name: 'gpua100'
        workloadProfileType: 'NC24-A100'
        minimumCount: 1
        maximumCount: 1
      }
    ]
  }
}
```

### Option 3: Azure Functions with Consumption GPU (if supported)

Instead of Dedicated GPU workload profiles, explore if Azure Functions supports Consumption GPU profiles (serverless GPUs) which might have different creation requirements.

## GPU Quota Status

- ✅ **Have quota**: NC4as-A100-v4 (4 vCPU A100) in North Europe
- ✅ **Region supports**: NC24-A100 workload profile in North Europe
- ❌ **Blocker**: Cannot create environment with GPU profile via CLI

## Recommended Next Steps

1. **Create environment via Azure Portal** with GPU workload profile
2. **OR** Create Bicep/ARM template for infrastructure-as-code approach
3. Once environment exists with GPU profile, deploy the container app using existing `deploy_gpu_only.sh` script

## Alternative: Try Serverless Consumption GPU

If available for Azure Functions, Consumption GPU profiles might not have the same restriction. Need to verify if:
- `Consumption-GPU-NC24-A100` exists as a workload profile type
- It can be added to existing environments
- Azure Functions supports running on Consumption GPU profiles

## Files Ready for Deployment

Once environment is created with GPU support:

- ✅ `function_app_simple.py` - GPU test function
- ✅ `Dockerfile.simple` - CUDA 12.1 + PyTorch container
- ✅ `requirements_simple.txt` - Python dependencies
- ✅ `deploy_gpu_only.sh` - Deploy script (skip build, use existing image)
- ✅ Container image built and pushed to ACR: `acrgpufunctest.azurecr.io/gpu-function-simple:latest`

## Conclusion

The Azure CLI does not currently support creating Container Apps environments with GPU workload profiles. Must use either:
1. Azure Portal (fastest/easiest)
2. ARM/Bicep templates (infrastructure-as-code, repeatable)

**Action Required**: Create the environment using one of these methods before proceeding with function deployment.
