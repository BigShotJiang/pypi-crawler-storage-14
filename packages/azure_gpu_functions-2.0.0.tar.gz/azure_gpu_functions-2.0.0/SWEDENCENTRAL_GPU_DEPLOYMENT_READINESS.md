# Sweden Central GPU Deployment Readiness

## Overview
This document outlines the deployment strategy for GPU-accelerated Azure Functions in Sweden Central once the quota approvals are received from Azure support.

## Current Status
- ✅ **Container App Environment Created**: `gpu-env-quota-sr-2511200050003342`
- ✅ **Resource ID Provided**: Submitted to Azure support (SR 2511200050003342)
- ⏳ **Quota Approval Pending**: A100 GPUs (24) and T4 GPUs (16)
- ✅ **Deployment Scripts Ready**: Both A100 and T4 deployment prepared

## Environment Details
```
Resource Group: rg-gpu-quota-swedencentral
Location: Sweden Central
Environment: gpu-env-quota-sr-2511200050003342
Subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba
```

## Deployment Scripts

### 1. Deploy A100 GPU Function
```bash
./deploy_swedencentral_gpu.sh A100
```
**Specifications:**
- GPU: NVIDIA A100 (80GB HBM2e)
- Performance: ~488 TFLOPs FP32
- vCPU: 24 cores
- RAM: 220GB
- Use Case: Production workloads, large models

### 2. Deploy T4 GPU Function
```bash
./deploy_swedencentral_gpu.sh T4
```
**Specifications:**
- GPU: NVIDIA T4 (16GB GDDR6)
- Performance: ~65 TFLOPs FP32
- vCPU: 8 cores
- RAM: 56GB
- Use Case: Development, testing, smaller models

### 3. Test Deployments
```bash
# Test A100 deployment
./test_swedencentral_gpu.sh A100

# Test T4 deployment
./test_swedencentral_gpu.sh T4
```

## Workflow After Quota Approval

### Step 1: Verify Quota Approval
```bash
# Check available GPU profiles in Sweden Central
az containerapp env workload-profile list-supported --location swedencentral --query "[?properties.category=='GPU']"
```

Expected output should include:
- `Consumption-GPU-NC24-A100`
- `Consumption-GPU-NC8as-T4`

### Step 2: Deploy A100 Function
```bash
./deploy_swedencentral_gpu.sh A100
```

### Step 3: Test A100 Training
```bash
./test_swedencentral_gpu.sh A100
```

### Step 4: Deploy T4 Function
```bash
./deploy_swedencentral_gpu.sh T4
```

### Step 5: Test T4 Training
```bash
./test_swedencentral_gpu.sh T4
```

## Expected Test Results

### A100 GPU Performance
- **Training Time**: 2-5 seconds per epoch
- **Memory Usage**: 2-8 GB peak
- **Accuracy**: 85-95% after 50 epochs
- **Device**: cuda (A100 detected)

### T4 GPU Performance
- **Training Time**: 5-15 seconds per epoch
- **Memory Usage**: 1-4 GB peak
- **Accuracy**: 80-90% after 50 epochs
- **Device**: cuda (T4 detected)

## Function Endpoints

Once deployed, each function will provide these endpoints:

```
Health Check:     https://[function-url]/api/health
GPU Status:       https://[function-url]/api/gpu-status
GPU Test:         https://[function-url]/api/gpu-test
GPU Training:     https://[function-url]/api/gpu-training
```

### Training API Examples

**Default Training (10 epochs):**
```bash
curl https://[function-url]/api/gpu-training
```

**Custom Training:**
```bash
curl -X POST https://[function-url]/api/gpu-training \
  -H 'Content-Type: application/json' \
  -d '{"epochs": 50, "batch_size": 256, "learning_rate": 0.001}'
```

## Architecture

### Container App Environment
- **Environment**: `gpu-env-quota-sr-2511200050003342`
- **Workload Profiles**:
  - `gpu-a100-profile`: Consumption-GPU-NC24-A100
  - `gpu-t4-profile`: Consumption-GPU-NC8as-T4

### Functions
- **A100 Function**: `gpu-function-a100-training`
- **T4 Function**: `gpu-function-t4-training`
- **Container Image**: `acrgpuquotaswedencentral.azurecr.io/gpu-function-simple:latest`

### Neural Network Model
- **Architecture**: 784→128→64→10 (SimpleNet)
- **Dataset**: Synthetic MNIST-like (60k samples)
- **Framework**: PyTorch 2.9.1+cu121
- **Training**: Configurable epochs, batch size, learning rate

## Monitoring & Troubleshooting

### Check Function Status
```bash
az containerapp show --name gpu-function-a100-training --resource-group rg-gpu-quota-swedencentral
```

### View Logs
```bash
az containerapp logs show --name gpu-function-a100-training --resource-group rg-gpu-quota-swedencentral
```

### Check Workload Profiles
```bash
az containerapp env workload-profile list --name gpu-env-quota-sr-2511200050003342 --resource-group rg-gpu-quota-swedencentral
```

## Next Steps

1. **Monitor Support Ticket**: Check SR 2511200050003342 for quota approval
2. **Deploy A100 First**: Test production-grade GPU performance
3. **Deploy T4 Second**: Validate development/testing capabilities
4. **Performance Comparison**: Compare A100 vs T4 training metrics
5. **Scale Testing**: Test multiple concurrent training jobs

## Files Updated/Created
- `deploy_swedencentral_gpu.sh`: Unified deployment script for both GPU types
- `test_swedencentral_gpu.sh`: Comprehensive testing script for both GPUs
- `SWEDENCENTRAL_GPU_DEPLOYMENT_READINESS.md`: This documentation

## Contact
For issues with deployment or testing, check the Azure support ticket or function logs.