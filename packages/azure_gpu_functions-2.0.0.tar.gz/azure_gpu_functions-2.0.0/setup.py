"""
Setup script for Azure GPU Functions package
"""

from setuptools import setup, find_packages
import os

# Read README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# Read requirements
def read_requirements(filename):
    with open(filename, "r") as f:
        return [line.strip() for line in f if line.strip() and not line.startswith("#")]

# Core requirements (minimal)
install_requires = [
    "numpy>=1.24.0",
    "requests>=2.31.0",
    "psutil>=5.9.0",
    "GPUtil>=1.4.0",
]

# Optional requirements
extras_require = {
    "azure": [
        "azure-storage-blob>=12.18.0",
        "azure-identity>=1.15.0",
        "azure-mgmt-costmanagement>=4.0.1",
        "azure-mgmt-monitor>=6.0.2",
    ],
    "ml": [
        "torch>=2.1.0",
        "torchvision>=0.16.0",
        "transformers>=4.35.0",
        "datasets>=2.14.0",
        "accelerate>=0.24.0",
        "peft>=0.6.0",
        "tokenizers>=0.15.0",
        "scikit-learn>=1.3.0",
        "pandas>=2.1.0",
        "matplotlib>=3.8.0",
    ],
    "distributed": [
        "ray[default]>=2.9.0",
        "ray[serve]>=2.9.0",
        "ray[tune]>=2.9.0",
    ],
    "monitoring": [
        "websockets>=12.0",
        "fastapi>=0.104.1",
        "uvicorn>=0.24.0",
        "prometheus-client>=0.19.0",
        "opentelemetry-distro>=0.43b0",
        "opentelemetry-instrumentation>=0.43b0",
    ],
    "all": [],  # Will be populated below
}

# Add all optional dependencies to "all"
for deps in extras_require.values():
    if deps != extras_require["all"]:
        extras_require["all"].extend(deps)

setup(
    name="azure-gpu-functions",
    version="2.0.0",
    author="Amadeus GPU Training Team",
    author_email="gpu-training@amadeus.com",
    description="GPU-accelerated machine learning training for Azure Functions with distributed computing, monitoring, and cost optimization",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pxcallen_amadeus/azureGPUtrainingappfunc",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=install_requires,
    extras_require=extras_require,
    entry_points={
        "console_scripts": [
            "azure-gpu-trainer=azure_gpu_functions.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "azure_gpu_functions": ["*.md", "*.txt"],
    },
    keywords="azure gpu functions machine-learning distributed-training ray monitoring cost-optimization",
    project_urls={
        "Bug Reports": "https://github.com/pxcallen_amadeus/azureGPUtrainingappfunc/issues",
        "Source": "https://github.com/pxcallen_amadeus/azureGPUtrainingappfunc",
        "Documentation": "https://github.com/pxcallen_amadeus/azureGPUtrainingappfunc/blob/main/FRAMEWORK_GUIDE.md",
    },
)