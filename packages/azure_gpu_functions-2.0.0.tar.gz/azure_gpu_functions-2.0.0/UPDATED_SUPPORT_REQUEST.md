# Updated Support Request Description

## For Your Azure Portal Support Request:

### **Description to Add:**

```
Requesting quota increases for Azure Container Apps Consumption GPU workloads.

Use case: Deploying Azure Functions with GPU support for AI/ML workloads using PyTorch.

Requirements:

1. A100 GPUs (heavy workloads):
   - Region: Sweden Central
   - Quota type: Managed Environment Consumption NCA100 Gpus
   - Requested quota: 24 vCPU (NC24-A100 profile for intensive PyTorch models)
   - GPU type: NVIDIA A100 80GB

2. T4 GPUs (development/testing):
   - Region: Sweden Central
   - Quota type: Managed Environment Consumption T4 Gpus
   - Requested quota: 16 vCPU (for smaller tests and development workloads)
   - GPU type: NVIDIA T4 16GB

Current quotas: 0 for both types
Needed for: GPU-accelerated Azure Functions running PyTorch models in development and production scenarios

This will enable flexible serverless GPU scaling for containerized Azure Functions with both high-performance A100 and cost-effective T4 options.
```

### **How to Add Multiple Quotas:**

1. In the "Problem Details" section, click "Enter details" for the first quota (A100)
2. After saving the first quota, click "Add another quota" for the second quota (T4)
3. Add the description above in "Additional Details"

### **Expected Approval Timeline:**
- **Consumption GPUs**: 1-2 business days (faster than dedicated)
- **Both quotas**: May be approved together or separately

### **Post-Approval Next Steps:**
- I'll create deployment scripts for both GPU types
- A100 for production workloads, T4 for development/testing
- Both will use identical PyTorch code but different GPU hardware</content>
<parameter name="filePath">/Users/xcallens/xdev/appfunctiongpu/UPDATED_SUPPORT_REQUEST.md