# Docker Caching Strategy for Azure GPU Functions

## Overview
This document outlines the caching optimizations implemented to reduce training preparation time based on build log analysis.

## Key Optimizations

### 1. Multi-Stage Build Architecture
- **System Dependencies Stage**: Caches OS packages (build-essential, git, etc.)
- **Python Dependencies Stage**: Caches pip packages separately
- **PyTorch/ML Libraries Stage**: Isolates large CUDA downloads
- **Git Repositories Stage**: Caches cloned repositories
- **Final Runtime Stage**: Minimal runtime image

### 2. Layer Caching Strategies

#### Pip Cache Mounts
```dockerfile
RUN --mount=type=cache,target=/root/.cache/pip \
    pip install --no-cache-dir -r requirements.txt
```
- Mounts host pip cache directory
- Prevents re-downloading packages on rebuilds
- Uses `--no-cache-dir` to avoid container cache bloat

#### Git Shallow Cloning
```dockerfile
RUN git clone --depth 1 https://github.com/ML-KULeuven/deepproblog.git
```
- `--depth 1` clones only latest commit
- Reduces clone time from minutes to seconds
- Cached in separate layer for rebuilds

#### BuildKit Cache Mounts
```dockerfile
RUN --mount=type=cache,target=/tmp/git-cache \
    git clone --depth 1 https://github.com/ML-KULeuven/deepproblog.git /tmp/deepproblog
```
- Uses BuildKit cache mounts for persistent caching
- Survives container rebuilds
- Faster subsequent builds

### 3. Build Context Optimization

#### .dockerignore File
- Excludes unnecessary files from build context
- Reduces context size and transfer time
- Prevents cache invalidation from irrelevant changes

#### Copy Order Optimization
```dockerfile
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . /home/site/wwwroot
```
- Copy requirements first for dependency caching
- Application code copied last to preserve cache

### 4. Failure Prevention

#### Fixed COPY Issue
- Original: `COPY ../comm/ ./comm/` (failed - outside context)
- Optimized: `COPY . /home/site/wwwroot/` (includes all needed files)
- Build context now includes comm directory

#### Health Checks
```dockerfile
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD python -c "import torch; print('GPU available:', torch.cuda.is_available())"
```
- Verifies GPU availability post-build
- Prevents deployment of broken containers

### 5. Performance Improvements

#### Expected Time Reductions
- **Initial Build**: ~15-20 minutes (large downloads)
- **Subsequent Builds**: ~2-5 minutes (cached layers)
- **Dependency Changes Only**: ~30 seconds (pip cache)
- **Code Changes Only**: ~10 seconds (final layer only)

#### Cache Efficiency
- System packages: Cached permanently
- Python packages: Cached until requirements.txt changes
- Git repos: Cached until repository updates
- Models: Optional caching for frequently used models

### 6. Build Script Enhancements

#### BuildKit Integration
```bash
export DOCKER_BUILDKIT=1
docker build --cache-from $IMAGE_NAME:latest
```
- Enables advanced caching features
- Uses inline cache for registry-based caching

#### Incremental Builds
- Supports cache-from for registry-based caching
- Allows pushing cached layers to registry

## Usage

### Standard Build
```bash
./build_optimized.sh
```

### With Custom Tag
```bash
./build_optimized.sh my-registry/azure-gpu-functions v1.1.0
```

### With Push
```bash
./build_optimized.sh my-registry/azure-gpu-functions latest push
```

## Monitoring Cache Effectiveness

### Check Cache Usage
```bash
docker build --progress=plain  # Shows cache hits/misses
```

### Cache Statistics
```bash
docker system df  # Shows cache size
docker builder prune  # Clean old cache
```

## Troubleshooting

### Cache Issues
- Clear cache: `docker builder prune -a`
- Force rebuild: `docker build --no-cache`

### Build Failures
- Check BuildKit: `echo $DOCKER_BUILDKIT`
- Enable BuildKit: `export DOCKER_BUILDKIT=1`

### Performance Issues
- Use faster storage for cache mounts
- Consider registry-based caching for CI/CD

## Future Optimizations

1. **Registry Caching**: Push intermediate layers to Azure Container Registry
2. **Model Pre-caching**: Cache frequently used ML models in base images
3. **Parallel Builds**: Use multi-platform builds for different architectures
4. **Dependency Pinning**: Pin all versions for reproducible builds