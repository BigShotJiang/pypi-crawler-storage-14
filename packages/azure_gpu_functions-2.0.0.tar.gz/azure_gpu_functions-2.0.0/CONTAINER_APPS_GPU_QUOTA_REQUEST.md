# Container Apps GPU Quota Request Guide

## Issue

Deployment failed with quota error:
```
Regional max quota limit threshold hit. The subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba 
cannot have more than 0 SubscriptionNCA100Gpus in region North Europe.
```

## Root Cause

**Azure Container Apps uses DIFFERENT quota than Azure Virtual Machines!**

- ✅ **You have**: `NC4as-A100-v4` quota (4 vCPU) - for **Virtual Machines**
- ❌ **You need**: `SubscriptionNCA100Gpus` quota - for **Container Apps**
- 📊 **Current quota**: 0 SubscriptionNCA100Gpus in North Europe

## **CRITICAL ISSUE: Only Consumption GPU Quotas Available**

### ❌ **Problem**: Your subscription only shows "Consumption" GPU options
The Azure Portal only displays these quota types for your subscription:
- `Managed Environment Consumption NCA100 Gpus` (serverless A100)
- `Managed Environment Consumption T4 Gpus` (serverless T4)
- ❌ `Managed Environment Subscription NCA100 Gpus` (dedicated A100) - **NOT AVAILABLE**

### **What This Means:**

| Quota Type | GPU Type | Scaling | Cost | Use Case |
|------------|----------|---------|------|----------|
| **Consumption** | Serverless A100/T4 | Scale-to-zero | Pay-per-use | Development/testing |
| **Subscription** | Dedicated A100 | Always-on | Hourly | Production workloads |

### **Your Options:**

### **Option 1: Use Consumption GPU (RECOMMENDED - FASTER APPROVAL)**
- **Select BOTH**:
  - `Managed Environment Consumption NCA100 Gpus` (A100 GPUs)
  - `Managed Environment Consumption T4 Gpus` (T4 GPUs)
- **Region**: `Sweden Central` (supports both Consumption GPU types)
- **New limits**: 
  - A100: 24 vCPU (for intensive PyTorch workloads)
  - T4: 16 vCPU (for smaller tests and development)
- **Pros**: Faster approval (1-2 days), flexible GPU options, serverless scaling
- **Cons**: Scale-to-zero (not always-on)

### **GPU Comparison for Your Use Cases:**

| GPU Type | Memory | Use Case | Cost | Best For |
|----------|--------|----------|------|----------|
| **A100** | 80GB | Heavy PyTorch models, large matrices | Higher | Production workloads, complex ML |
| **T4** | 16GB | Light testing, smaller models | Lower | Development, quick validation |

### **Option 2: Request Dedicated GPU Access**
Contact Azure Support to enable dedicated GPU quotas (may take longer)

#### **Option 2: Contact Azure Support for Dedicated GPU Access**
Your subscription may need Enterprise Agreement or specific enablement for dedicated GPUs.

## Available GPU Workload Profiles in North Europe

| Profile | vCPU | Memory | GPUs | Quota Required |
|---------|------|--------|------|----------------|
| NC24-A100 | 24 | 220GB | 1x A100 | SubscriptionNCA100Gpus |
| NC48-A100 | 48 | 440GB | 2x A100 | SubscriptionNCA100Gpus |
| NC96-A100 | 96 | 880GB | 4x A100 | SubscriptionNCA100Gpus |

**Minimum requirement**: NC24-A100 (1 node = 24 vCPU, 1 A100 GPU)

## How to Request Container Apps GPU Quota

### Option 1: Azure Portal (Recommended)

**Note**: You can request multiple GPU quotas in a single support ticket by adding multiple quota details.

1. **Open Support Request**:
   - Go to: https://portal.azure.com/#view/Microsoft_Azure_Support/NewSupportRequestV4Blade
   - Or: Azure Portal → Help + Support → New support request

2. **Basic Information**:
   - Issue type: **Service and subscription limits (quotas)**
   - Subscription: Select `amacp-tst-ne-gem-01` (283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba)
   - Quota type: **Container Apps**
   - Click **Next**

3. **Problem Details**:
   - Click **Enter details** (first quota - A100)
     - Quota type: `Managed Environment Consumption NCA100 Gpus`
     - Region: `Sweden Central`
     - New limit: `24`
     - Click **Save and continue**
   - Click **Add another quota** (second quota - T4)
     - Quota type: `Managed Environment Consumption T4 Gpus`
     - Region: `Sweden Central`
     - New limit: `16`
     - Click **Save and continue**

4. **Additional Details**:
   - Severity: Choose based on urgency
   - Preferred contact method: Email/Phone
   - Description:
     ```
     Requesting quota increases for Azure Container Apps Consumption GPU workloads.

     Use case: Deploying Azure Functions with GPU support for AI/ML workloads using PyTorch.

     Requirements:
     1. A100 GPUs (heavy workloads):
        - Region: Sweden Central
        - Quota type: Managed Environment Consumption NCA100 Gpus
        - Requested quota: 24 vCPU (NC24-A100 profile for intensive PyTorch models)
        - GPU type: NVIDIA A100 80GB

     2. T4 GPUs (development/testing):
        - Region: Sweden Central
        - Quota type: Managed Environment Consumption T4 Gpus
        - Requested quota: 16 vCPU (for smaller tests and development workloads)
        - GPU type: NVIDIA T4 16GB

     Current quotas: 0 for both types
     Needed for: GPU-accelerated Azure Functions running PyTorch models in development and production scenarios
     ```

5. **Review + Create**: Submit the request

### Option 2: Azure CLI

```bash
# This creates a support ticket (requires support plan)
az support tickets create \
    --ticket-name "ContainerApps-GPU-Quota-Request" \
    --title "Request Container Apps GPU Quota - SubscriptionNCA100Gpus" \
    --description "Request quota for SubscriptionNCA100Gpus in North Europe region for GPU-enabled Container Apps" \
    --problem-classification-id "/providers/Microsoft.Support/services/<service-id>/problemClassifications/<classification-id>" \
    --severity "moderate" \
    --contact-first-name "Your" \
    --contact-last-name "Name" \
    --contact-method "email" \
    --contact-email "your.email@company.com" \
    --contact-timezone "W. Europe Standard Time" \
    --contact-country "FR"
```

### CORRECTIONS NEEDED:

**❌ Current Selection Issues:**
- Quota type: "Managed Environment **Consumption** NCA100 Gpus" → Should be "**Subscription**"
- Region: "Sweden Central" → Should be "**North Europe**" (where your resources are)
- "Managed Environment" field shows "Response not found" → This indicates wrong quota type

**✅ Correct Selections:**
- Quota type: **"Managed Environment Subscription NCA100 Gpus"**
- Region: **"North Europe"**
- New limit: **24**

### Why These Corrections Matter:

1. **Consumption vs Subscription**: 
   - Consumption = Serverless GPU (scale-to-zero, different billing)
   - Subscription = Dedicated GPU (always-on, what you need for A100)

2. **Region**: North Europe is where:
   - Your subscription is located
   - Your ACR registry exists (`acrgpufunctest.azurecr.io`)
   - Your Log Analytics workspace exists
   - Your storage account exists

3. **Quota Type**: "SubscriptionNCA100Gpus" is specifically for dedicated GPU workloads

### Default Quota

According to Microsoft documentation:
> "Customers with enterprise agreements and pay-as-you-go customers have A100 and T4 quota enabled by default."

However, your subscription shows 0 quota. You may need to:
1. Check if subscription is enterprise/pay-as-you-go
2. Request quota enablement if not default
3. Verify billing/subscription status

### Regional Availability

GPU workload profiles are available in limited regions:
- ✅ **North Europe** - NC24/48/96-A100
- ✅ **West US 3** - NC24/48/96-A100
- ✅ **Australia East** - Consumption GPU T4
- ✅ **Sweden Central** - Consumption GPU T4/A100

## Estimated Timeline

- **Standard quota request**: 1-3 business days
- **Large quota request**: May require additional review
- **Initial response**: Usually within 24 hours

## What Happens After Quota Approval

Once quota is approved for both GPU types:

### **Deployment Options:**

**For Heavy Workloads (A100 GPUs):**
```bash
# Update scripts for A100 deployment
cd /Users/xcallens/xdev/appfunctiongpu
./deploy_bicep_gpu_env.sh  # Uses Consumption-GPU-NC24-A100 profile
./deploy_gpu_function.sh
```

**For Development/Testing (T4 GPUs):**
```bash
# Update scripts for T4 deployment
cd /Users/xcallens/xdev/appfunctiongpu
./deploy_bicep_gpu_env_t4.sh  # Uses Consumption-GPU-NC16-T4 profile
./deploy_gpu_function.sh
```

### **Testing Both Deployments:**
```bash
# Test A100 deployment
curl https://<a100-function-url>/api/gpu-status
curl https://<a100-function-url>/api/gpu-test

# Test T4 deployment  
curl https://<t4-function-url>/api/gpu-status
curl https://<t4-function-url>/api/gpu-test
```

### **GPU Selection Logic:**
- **A100 (80GB)**: Large PyTorch models, complex matrix operations, production workloads
- **T4 (16GB)**: Development testing, smaller models, cost-effective validation

## Alternative: Use Different Region

If North Europe quota takes too long, consider:

**West US 3**:
- Same GPU profiles available (NC24/48/96-A100)
- Request quota in West US 3 instead
- Update deployment scripts to use `westus3` location

**Sweden Central** (Consumption GPU):
- Serverless GPU (scale-to-zero)
- May have different quota availability
- Update scripts to use `swedencentral` and `Consumption-GPU-NC24-A100` profile type

## Current Deployment Status

- ✅ Bicep template created and working
- ✅ Infrastructure code ready
- ✅ Container image built and in ACR
- ✅ Function code ready
- ❌ **Blocked by**: GPU quota (SubscriptionNCA100Gpus = 0)

## Next Steps

1. **Submit quota request** (see Option 1 above)
2. **Wait for approval** (1-3 business days typically)
3. **Run deployment** once quota is approved:
   ```bash
   cd /Users/xcallens/xdev/appfunctiongpu
   ./deploy_bicep_gpu_env.sh
   ./deploy_gpu_function.sh
   ```

## Reference Links

- [Container Apps GPU Quota Requests](https://learn.microsoft.com/en-us/azure/container-apps/quota-requests)
- [Serverless GPUs in Container Apps](https://learn.microsoft.com/en-us/azure/container-apps/gpu-serverless-overview)
- [Workload Profiles Overview](https://learn.microsoft.com/en-us/azure/container-apps/workload-profiles-overview)
- [Azure Quota Management](https://portal.azure.com/#view/Microsoft_Azure_Capacity/QuotaMenuBlade/~/overview)
