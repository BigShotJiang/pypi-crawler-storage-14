# Contributing to Azure Functions GPU Training Framework

Thank you for your interest in contributing to the Azure Functions GPU Training Framework! This document provides guidelines and information for contributors.

## 🚀 Quick Start

1. **Fork** the repository on GitHub
2. **Clone** your fork locally:
   ```bash
   git clone https://github.com/your-username/azureGPUtrainingappfunc.git
   cd azureGPUtrainingappfunc
   ```
3. **Set up** the development environment:
   ```bash
   ./setup.sh
   ```
4. **Create** a feature branch:
   ```bash
   git checkout -b feature/your-feature-name
   ```

## 📋 Development Workflow

### 1. Code Style
- Use **Black** for code formatting
- Follow **PEP 8** guidelines
- Use type hints for function parameters and return values
- Write descriptive commit messages

### 2. Testing
- Run tests before committing:
  ```bash
  ./scripts/test.sh
  ```
- Add tests for new features
- Ensure all tests pass

### 3. Documentation
- Update README.md for significant changes
- Add docstrings to new functions and classes
- Update API documentation in `docs/`

## 🏗️ Architecture Guidelines

### Project Structure
```
src/
├── functions/     # Azure Functions endpoints
├── models/        # Model management and training
├── storage/       # Azure Storage clients
├── experiments/   # Experiment tracking
└── utils/         # Utilities and helpers
```

### Key Principles
- **Modularity**: Keep components loosely coupled
- **Reusability**: Design for multiple projects
- **Shared Resources**: Use common storage for models/datasets
- **Experiment Tracking**: Log all training runs
- **Error Handling**: Graceful failure with proper logging

## 🔧 Making Changes

### Adding New Features
1. Create a feature branch from `main`
2. Implement the feature with tests
3. Update documentation
4. Submit a pull request

### Bug Fixes
1. Create a bug fix branch from `main`
2. Write a test that reproduces the bug
3. Fix the bug
4. Ensure all tests pass

### Azure Functions Endpoints
When adding new endpoints:
- Follow RESTful conventions
- Add proper error handling
- Include input validation
- Update API documentation

### Storage Integration
When modifying storage:
- Maintain backward compatibility
- Update both blob and table storage
- Handle connection errors gracefully
- Document storage schema changes

## 🧪 Testing

### Running Tests
```bash
# Run all tests
./scripts/test.sh

# Run specific test file
python -m pytest tests/unit/test_specific.py -v

# Run with coverage
python -m pytest --cov=src tests/
```

### Writing Tests
- Place tests in `tests/` directory
- Use descriptive test names
- Test both success and failure cases
- Mock external dependencies (Azure services)

## 📝 Pull Request Process

1. **Update** the README.md with details of changes if needed
2. **Update** the version numbers in any examples files
3. **Ensure** CI passes all checks
4. **Request review** from maintainers
5. **Merge** after approval

### PR Checklist
- [ ] Tests pass
- [ ] Code is formatted with Black
- [ ] Documentation updated
- [ ] No linting errors
- [ ] Backward compatibility maintained
- [ ] Security considerations addressed

## 🔒 Security

- Never commit secrets or credentials
- Use Azure Key Vault for sensitive data
- Follow principle of least privilege
- Validate all inputs
- Handle errors without exposing sensitive information

## 📞 Getting Help

- **Issues**: Use GitHub issues for bugs and feature requests
- **Discussions**: Use GitHub discussions for questions
- **Documentation**: Check README.md and docs/ first

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

Thank you for contributing to the Azure Functions GPU Training Framework! 🎉