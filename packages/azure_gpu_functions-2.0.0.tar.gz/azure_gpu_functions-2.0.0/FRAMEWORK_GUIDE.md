# Amadeus Azure Functions GPU Training Framework

## 🎓 Framework Overview for Amadeus Teams

This framework provides a complete, production-ready solution for GPU-accelerated machine learning training and testing on Azure Functions. Designed specifically for Amadeus teams, apprentices, and interns to learn and implement scalable AI/ML solutions.

### 🎯 Learning Objectives

After working with this framework, you'll understand:
- **Azure Functions** architecture and deployment patterns
- **GPU computing** on Azure with cost optimization
- **Distributed training** using Ray framework
- **Infrastructure as Code** with Bicep templates
- **Container optimization** for ML workloads
- **Performance monitoring** and cost analysis
- **Real-time dashboards** for operational visibility

---

## 📚 Framework Architecture

### Core Components

```
├── 🏗️ Infrastructure Layer (Bicep)
│   ├── Azure Container Apps with GPU support
│   ├── Azure Storage for model caching
│   ├── Application Insights for monitoring
│   └── Azure Container Registry
│
├── 🐳 Container Layer (Docker)
│   ├── Multi-stage builds with dependency caching
│   ├── CUDA optimization for GPU workloads
│   ├── Model preloading during build
│   └── Background service initialization
│
├── ⚡ Function Layer (Python)
│   ├── HTTP-triggered GPU testing functions
│   ├── Background model caching workers
│   ├── Real-time monitoring endpoints
│   └── Cost analysis calculators
│
└── 🎛️ Monitoring Layer (WebSocket + REST)
    ├── Interactive testing dashboard
    ├── Real-time performance metrics
    └── Historical data visualization
```

### Key Design Patterns

1. **Caching Strategy**: Multi-level caching (build-time → runtime → cloud storage)
2. **Cost Optimization**: GPU usage tracking with automatic cost calculation
3. **Scalability**: Serverless architecture with horizontal scaling
4. **Observability**: Comprehensive logging and monitoring
5. **Testing**: Automated test suites for validation

---

## 🚀 Getting Started (Step-by-Step Guide)

### Prerequisites Setup

1. **Azure Account & CLI**
   ```bash
   # Install Azure CLI
   brew install azure-cli

   # Login to Azure
   az login

   # Set your subscription
   az account set --subscription "your-subscription-id"
   ```

2. **GPU Quota Approval**
   - Navigate to Azure Portal → Subscriptions → Quota
   - Request GPU quota for your region (Sweden Central recommended)
   - A100: 24 instances, T4: 16 instances typically approved

3. **Local Development Environment**
   ```bash
   # Install Python dependencies
   pip install -r requirements.txt

   # Install Azure Functions Core Tools
   brew tap azure/functions
   brew install azure-functions-core-tools@4
   ```

### 🏃‍♂️ Quick Start Tutorial

#### Step 1: Local GPU Testing

```bash
# 1. Test your local GPU setup
python3 test_gpu_standalone.py

# Expected output: GPU availability, performance metrics
# ✅ GPU Available: True
# ✅ CUDA Version: 11.8
# 📊 Matrix Multiplication: 45.2 TFLOPS (87% efficiency)
```

#### Step 2: Interactive Testing

```bash
# 2. Run the interactive testing menu
./run_gpu_tests.sh

# Choose options:
# 1. Matrix Multiplication Test
# 2. Tensor Operations Test
# 3. Memory Bandwidth Test
# 4. Compute Intensity Test
```

#### Step 3: Launch Dashboard

```bash
# 3. Start the monitoring dashboard
./launch_dashboard.sh

# Opens browser at: http://localhost:7071/api/dashboard
# Features: Real-time metrics, cost tracking, test history
```

#### Step 4: Deploy to Azure

```bash
# 4. Deploy GPU testing system
./scripts/deploy_simple.sh

# Monitor deployment progress
az containerapp logs show --name gpu-testing-app --resource-group your-rg --follow
```

---

## 🎓 Learning Modules

### Module 1: GPU Computing Fundamentals

#### Understanding GPU Architecture
- **CUDA Cores**: Parallel processing units
- **Memory Hierarchy**: Global, Shared, Local memory
- **Thread Blocks**: GPU execution units
- **Performance Metrics**: TFLOPS, bandwidth, efficiency

#### Cost Optimization
```python
# GPU cost calculation example
gpu_costs = {
    'T4': 1.60,    # $/hour
    'A100': 4.80   # $/hour
}

def calculate_cost(gpu_type, hours_used):
    return gpu_costs[gpu_type] * hours_used
```

#### Performance Testing
```python
import torch
import time

def benchmark_gpu():
    # Create large tensors
    a = torch.randn(4096, 4096).cuda()
    b = torch.randn(4096, 4096).cuda()

    # Time matrix multiplication
    start = time.time()
    c = torch.mm(a, b)
    torch.cuda.synchronize()  # Wait for GPU completion
    end = time.time()

    return (end - start) * 1000  # milliseconds
```

### Module 2: Azure Functions Architecture

#### Function Types
- **HTTP Triggers**: REST API endpoints
- **Timer Triggers**: Scheduled tasks
- **Queue Triggers**: Event-driven processing
- **Blob Triggers**: File processing

#### Scaling Patterns
- **Consumption Plan**: Pay-per-execution
- **Premium Plan**: Pre-warmed instances
- **Dedicated Plan**: Always-on instances

#### GPU Function Implementation
```python
import azure.functions as func
import torch

app = func.FunctionApp()

@app.function_name(name="gpu-test")
@app.route(route="gpu-test", methods=["POST"])
async def gpu_test_function(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # GPU operations
        if torch.cuda.is_available():
            device = torch.device("cuda")
            # Your GPU code here
            result = {"gpu_available": True, "device_count": torch.cuda.device_count()}
        else:
            result = {"gpu_available": False}

        return func.HttpResponse(json.dumps(result), mimetype="application/json")
    except Exception as e:
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
```

### Module 3: Container Optimization

#### Multi-Stage Docker Builds
```dockerfile
# Stage 1: Dependencies
FROM python:3.9-slim as dependencies
COPY requirements.txt .
RUN pip install --user -r requirements.txt

# Stage 2: Models (cache layer)
FROM dependencies as models
RUN python -c "from transformers import pipeline; pipeline('text-generation', model='gpt2')"

# Stage 3: Runtime
FROM nvidia/cuda:11.8-runtime-ubuntu20.04
COPY --from=models /root/.cache/huggingface /root/.cache/huggingface
# Your application code
```

#### Model Caching Strategy
```python
class ModelCache:
    def __init__(self, storage_account, container_name):
        self.blob_service = BlobServiceClient.from_connection_string(storage_account)
        self.container = container_name
        self.local_cache = Path.home() / ".cache" / "models"

    async def get_model(self, model_name):
        # Check local cache first
        local_path = self.local_cache / model_name
        if local_path.exists():
            return local_path

        # Download from blob storage
        blob_client = self.blob_service.get_blob_client(self.container, model_name)
        await blob_client.download_to_path(local_path)
        return local_path
```

### Module 4: Distributed Training with Ray

#### Ray Fundamentals
```python
import ray

# Initialize Ray cluster
ray.init()

@ray.remote
def train_worker(config):
    # Individual training worker
    model = load_model(config["model_name"])
    optimizer = torch.optim.Adam(model.parameters(), lr=config["lr"])

    for epoch in range(config["epochs"]):
        # Training loop
        loss = train_epoch(model, optimizer, data)
        ray.tune.report(loss=loss)

    return {"final_loss": loss}

# Hyperparameter optimization
analysis = ray.tune.run(
    train_worker,
    config={
        "lr": ray.tune.loguniform(1e-5, 1e-1),
        "model_name": ray.tune.choice(["gpt2", "bert-base"])
    }
)
```

#### MCP Server Integration
```python
from ray_mcp_server import get_mcp_server

class MCPTrainingCallback:
    def __init__(self, session_id):
        self.mcp = get_mcp_server()
        self.session_id = session_id

    def on_epoch_end(self, epoch, logs):
        # Send real-time updates
        self.mcp.monitor_actor.update_training_session.remote(
            self.session_id,
            {
                "epoch": epoch,
                "loss": logs["loss"],
                "timestamp": datetime.utcnow().isoformat()
            }
        )
```

### Module 5: Infrastructure as Code

#### Bicep Template Structure
```bicep
// main.bicep
param location string = 'swedencentral'
param environment string = 'dev'

resource storage 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: 'gpu${environment}storage${uniqueString(resourceGroup().id)}'
  location: location
  sku: { name: 'Standard_LRS' }
  kind: 'StorageV2'
}

resource containerApp 'Microsoft.App/containerApps@2022-11-01-preview' = {
  name: 'gpu-${environment}-app'
  location: location
  properties: {
    environmentId: containerAppsEnvironment.id
    template: {
      containers: [{
        image: 'your-registry.azurecr.io/gpu-app:latest'
        resources: {
          cpu: '2.0'
          memory: '8.0Gi'
          gpu: '1'  // GPU allocation
        }
      }]
    }
  }
}
```

#### Deployment Automation
```bash
# Deploy infrastructure
az deployment group create \
  --resource-group gpu-training-rg \
  --template-file infra/main.bicep \
  --parameters environment=dev location=swedencentral

# Build and push container
az acr build \
  --registry gpu${environment}acr \
  --image gpu-app:latest \
  --file Dockerfile .
```

---

## 🧪 Testing & Validation Framework

### Automated Test Suite

#### GPU Testing Scripts
```bash
# Run comprehensive GPU tests
python3 test_gpu_enhanced.py

# Test specific functionality
python3 -m pytest tests/ -v -k "gpu"

# Performance benchmarking
python3 scripts/performance_benchmark.py --gpu-type T4 --duration 300
```

#### Training Validation
```bash
# Test enhanced training function
python3 test_enhanced_training.py

# Validate MCP server integration
python3 test_mcp_integration.py

# End-to-end training test
python3 scripts/training_e2e_test.py --model-size medium --gpu-type A100
```

### Monitoring & Debugging

#### Application Insights Integration
```python
from opencensus.ext.azure.trace_exporter import AzureExporter
from opencensus.trace import config_integration
import logging

# Configure Azure monitoring
config_integration.trace_integrations(['requests'])
AzureExporter(connection_string=os.environ['APPLICATIONINSIGHTS_CONNECTION_STRING'])

# Structured logging
logger = logging.getLogger(__name__)
logger.info("GPU test started", extra={
    "gpu_type": "T4",
    "test_type": "matrix_multiplication",
    "matrix_size": 2048
})
```

#### Real-time Dashboard
```html
<!DOCTYPE html>
<html>
<head>
    <title>GPU Training Dashboard</title>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
    <div id="gpu-utilization"></div>
    <div id="cost-tracking"></div>
    <div id="performance-metrics"></div>

    <script>
        // Real-time updates via WebSocket
        const ws = new WebSocket('ws://localhost:8765');

        ws.onmessage = function(event) {
            const data = JSON.parse(event.data);
            updateDashboard(data);
        };
    </script>
</body>
</html>
```

---

## 📊 Performance Optimization

### GPU Memory Management
```python
def optimize_gpu_memory():
    # Clear cache between operations
    torch.cuda.empty_cache()

    # Use mixed precision
    scaler = torch.cuda.amp.GradScaler()

    with torch.cuda.amp.autocast():
        output = model(input)
        loss = criterion(output, target)

    scaler.scale(loss).backward()
    scaler.step(optimizer)
    scaler.update()
```

### Cost Optimization Strategies
```python
class CostOptimizer:
    def __init__(self):
        self.gpu_costs = {'T4': 1.60, 'A100': 4.80}

    def recommend_gpu_type(self, workload_type):
        """Recommend GPU based on workload"""
        recommendations = {
            'light_training': 'T4',
            'heavy_training': 'A100',
            'inference': 'T4',
            'development': 'T4'
        }
        return recommendations.get(workload_type, 'T4')

    def calculate_optimal_batch_size(self, gpu_type, model_size):
        """Calculate optimal batch size for cost efficiency"""
        base_batch_sizes = {
            'T4': {'small': 16, 'medium': 8, 'large': 4},
            'A100': {'small': 32, 'medium': 16, 'large': 8}
        }
        return base_batch_sizes[gpu_type][model_size]
```

### Caching Optimization
```python
class SmartCache:
    def __init__(self):
        self.lru_cache = {}
        self.max_size = 10

    def get(self, key):
        if key in self.lru_cache:
            # Move to front (most recently used)
            self.lru_cache[key] = self.lru_cache.pop(key)
            return self.lru_cache[key]
        return None

    def put(self, key, value):
        if key in self.lru_cache:
            self.lru_cache.pop(key)
        elif len(self.lru_cache) >= self.max_size:
            # Remove least recently used
            self.lru_cache.pop(next(iter(self.lru_cache)))

        self.lru_cache[key] = value
```

---

## 🚀 Deployment Patterns

### Development Environment
```bash
# Local development with hot reload
func start --verbose --port 7071

# Test with local GPU
python3 test_gpu_standalone.py

# Debug with logging
func start --verbose --csharp
```

### Staging Environment
```bash
# Deploy to staging with limited resources
az containerapp create \
  --name gpu-app-staging \
  --resource-group staging-rg \
  --image your-registry.azurecr.io/gpu-app:staging \
  --cpu 2 --memory 8Gi \
  --min-replicas 1 --max-replicas 3 \
  --enable-dapr \
  --dapr-app-id gpu-app-staging
```

### Production Environment
```bash
# Production deployment with GPU
az containerapp create \
  --name gpu-training-prod \
  --resource-group production-rg \
  --image your-registry.azurecr.io/gpu-app:v1.0.0 \
  --cpu 4 --memory 16Gi \
  --gpu 1 \
  --min-replicas 2 --max-replicas 10 \
  --scale-rules '[
    {
      "name": "gpu-queue",
      "azure-queue": {
        "accountName": "prodstorage",
        "queueName": "gpu-jobs",
        "length": 10
      }
    }
  ]'
```

---

## 🔧 Troubleshooting Guide

### Common Issues & Solutions

#### 1. GPU Not Available
```bash
# Check GPU status
nvidia-smi

# Verify CUDA installation
nvcc --version

# Check PyTorch CUDA
python3 -c "import torch; print(torch.cuda.is_available())"
```

#### 2. Slow Model Loading
```bash
# Check cache directories
ls -la ~/.cache/huggingface/
ls -la /tmp/.cache/

# Verify Azure Storage permissions
az storage container list --account-name yourstorage --auth-mode login
```

#### 3. Function Timeout
```python
# Increase timeout in host.json
{
  "functionTimeout": "00:30:00",  // 30 minutes for GPU training
  "extensions": {
    "http": {
      "routePrefix": "api",
      "maxOutstandingRequests": 200,
      "maxConcurrentRequests": 100
    }
  }
}
```

#### 4. Memory Issues
```python
# Monitor GPU memory
def monitor_gpu_memory():
    return {
        'allocated': torch.cuda.memory_allocated() / 1024**3,  # GB
        'cached': torch.cuda.memory_reserved() / 1024**3,     # GB
        'total': torch.cuda.get_device_properties(0).total_memory / 1024**3
    }
```

---

## 📚 Advanced Topics

### Custom GPU Kernels
```python
import torch
from torch.utils.cpp_extension import load

# Custom CUDA kernel for optimized operations
cuda_kernel = load(
    name='custom_ops',
    sources=['kernels/custom_ops.cu'],
    extra_cuda_cflags=['-O3']
)

def optimized_matrix_multiply(a, b):
    return cuda_kernel.optimized_mm(a, b)
```

### Distributed Training Patterns
```python
import torch.distributed as dist
import torch.multiprocessing as mp

def setup_distributed(rank, world_size):
    # Initialize process group
    dist.init_process_group(
        backend='nccl',
        init_method='tcp://127.0.0.1:23456',
        rank=rank,
        world_size=world_size
    )

    # Set device
    torch.cuda.set_device(rank)

def cleanup_distributed():
    dist.destroy_process_group()
```

### Model Quantization
```python
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

def quantize_model(model_name):
    # Load model
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto"
    )

    # Apply quantization
    model = torch.quantization.quantize_dynamic(
        model, {torch.nn.Linear}, dtype=torch.qint8
    )

    return model
```

---

## 🎓 Learning Resources

### Recommended Reading
1. **Azure Functions Documentation**: https://docs.microsoft.com/azure/azure-functions/
2. **CUDA Programming Guide**: https://docs.nvidia.com/cuda/cuda-c-programming-guide/
3. **Ray Documentation**: https://docs.ray.io/
4. **PyTorch Performance Tuning**: https://pytorch.org/tutorials/

### Online Courses
- **Azure Fundamentals**: AZ-900 certification
- **Machine Learning on Azure**: DP-100 certification
- **CUDA Programming**: NVIDIA's CUDA training

### Community Resources
- **Azure Functions Community**: https://github.com/Azure/Azure-Functions
- **PyTorch Forums**: https://discuss.pytorch.org/
- **Ray Slack Community**: https://ray.io/community/

---

## 🤝 Contributing to the Framework

### Code Standards
```python
# Use type hints
def train_model(model: nn.Module, data: DataLoader) -> Dict[str, float]:
    """Train model with proper documentation"""
    pass

# Follow naming conventions
class GPUPerformanceMonitor:
    def __init__(self, gpu_type: str):
        self.gpu_type = gpu_type
        self.metrics = {}

    def measure_performance(self, operation: str) -> float:
        """Measure GPU operation performance"""
        pass
```

### Testing Requirements
```python
import pytest
from unittest.mock import Mock, patch

class TestGPUFunctions:
    @pytest.fixture
    def mock_gpu_available(self):
        with patch('torch.cuda.is_available', return_value=True):
            yield

    def test_matrix_multiplication(self, mock_gpu_available):
        # Test implementation
        result = gpu_test_matrix_multiplication(1024)
        assert result['performance'] > 0
        assert 'efficiency' in result
```

### Documentation Standards
- Use Google-style docstrings
- Include type hints for all functions
- Provide usage examples
- Document performance characteristics

---

## 📞 Support & Getting Help

### Internal Amadeus Resources
- **Team Slack**: #azure-gpu-training
- **Confluence**: Azure Functions GPU Framework
- **Jira**: GPU-TRAINING project

### External Support
- **Azure Support**: https://azure.microsoft.com/support/
- **GitHub Issues**: Report bugs and feature requests
- **Stack Overflow**: Tag questions with `azure-functions` and `gpu`

### Escalation Path
1. Check this documentation first
2. Search existing issues on GitHub
3. Ask in team Slack channel
4. Create Jira ticket for complex issues
5. Contact Azure support for platform issues

---

## 🎉 Success Metrics

### Learning Outcomes
- [ ] Understand Azure Functions architecture
- [ ] Implement GPU-accelerated functions
- [ ] Deploy containerized ML applications
- [ ] Optimize costs for GPU workloads
- [ ] Monitor and troubleshoot production systems

### Framework Adoption
- [ ] Deployed to production environment
- [ ] Used by multiple Amadeus teams
- [ ] Integrated with existing ML pipelines
- [ ] Cost savings achieved through optimization
- [ ] Performance benchmarks established

---

*This framework is designed to accelerate the learning journey for Amadeus teams while providing production-ready solutions for GPU-accelerated machine learning workloads on Azure.*

**Happy Learning! 🚀**