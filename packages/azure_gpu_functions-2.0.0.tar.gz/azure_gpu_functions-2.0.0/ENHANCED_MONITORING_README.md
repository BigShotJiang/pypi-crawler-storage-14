# Enhanced Azure GPU Functions Monitoring

This project now includes enhanced monitoring capabilities for Azure GPU Functions with comprehensive port management, real-time dashboard, and command center integration.

## New Features

### 1. Port Management System

The port management system provides utilities for checking port availability, monitoring processes, and performing health checks on services.

#### Usage

```python
from azure_gpu_functions.utils.port_manager import PortManager, PortHealthChecker

# Check if a port is open
is_open = PortManager.is_port_open("localhost", 8765)

# Check multiple service ports
services = [
    {"name": "mcp_server", "host": "localhost", "port": 8765},
    {"name": "dashboard", "host": "localhost", "port": 8080}
]
port_status = PortManager.check_service_ports(services)

# Perform health checks
health_checker = PortHealthChecker()
health_status = health_checker.check_service_health(
    "localhost:8765", "localhost", 8765, "/health"
)
```

### 2. Enhanced Dashboard

The dashboard provides real-time monitoring with Ray cluster integration and an interactive command center.

#### Features

- **System Metrics**: CPU, memory, and disk usage
- **Ray Cluster Status**: Available CPUs/GPUs, node count, memory usage
- **Task Monitoring**: Running, pending, failed, and completed tasks
- **Active Commands**: Real-time command execution tracking
- **Alerts System**: Recent system alerts and notifications
- **Command Center**: Interactive command execution interface

#### Usage

```python
from azure_gpu_functions.dashboard import get_enhanced_dashboard, start_enhanced_dashboard

# Get dashboard instance
dashboard = get_enhanced_dashboard()

# Get dashboard data
data = dashboard.get_dashboard_data()

# Generate HTML dashboard
html = dashboard.get_dashboard_html()

# Start web dashboard server
start_enhanced_dashboard(host="0.0.0.0", port=8080)
```

### 3. Enhanced MCP Server

The MCP server now includes new message types for port management, dashboard data retrieval, and command execution.

#### New Message Types

- **`check_ports`**: Check availability of multiple service ports
  ```json
  {
    "type": "check_ports",
    "id": "request_123",
    "services": [
      {"name": "mcp_server", "host": "localhost", "port": 8765}
    ]
  }
  ```

- **`get_port_status`**: Get detailed status of a specific port
  ```json
  {
    "type": "get_port_status",
    "id": "request_124",
    "host": "localhost",
    "port": 8765,
    "health_endpoint": "/health"
  }
  ```

- **`get_dashboard_data`**: Retrieve comprehensive dashboard data
  ```json
  {
    "type": "get_dashboard_data",
    "id": "request_125"
  }
  ```

- **`execute_command`**: Execute commands through the command center
  ```json
  {
    "type": "execute_command",
    "id": "request_126",
    "command": "check_system_status",
    "args": {"detailed": true}
  }
  ```

#### Enhanced Capabilities

The server now reports these additional capabilities:
- `port_management`: Port checking and health monitoring
- `dashboard`: Real-time dashboard data and metrics
- `command_center`: Command execution and history tracking

## Running the Enhanced System

### 1. Start the MCP Server

```bash
python -m azure_gpu_functions.mcp_server
```

The server will start on `ws://localhost:8765` with enhanced capabilities.

### 2. Start the Dashboard (Optional)

```bash
python -c "from azure_gpu_functions.dashboard import start_enhanced_dashboard; start_enhanced_dashboard()"
```

The dashboard will be available at `http://localhost:8080`.

### 3. Test the System

Run the test script to validate all functionality:

```bash
python test_enhanced_features.py
```

## Integration with Ray

The enhanced system integrates with Ray clusters for distributed monitoring:

- **Cluster Status**: Real-time CPU/GPU availability and node information
- **Task Monitoring**: Track running, pending, and failed tasks
- **Resource Tracking**: Memory and compute resource utilization
- **Distributed Commands**: Execute commands across Ray cluster nodes

## Optional Dependencies

The system gracefully handles missing optional dependencies:

- `ray`: For distributed cluster monitoring
- `websockets`: For WebSocket communication
- `psutil`: For detailed system metrics
- `GPUtil`: For GPU monitoring
- `requests`: For HTTP health checks

If these libraries are not available, the system will fall back to basic functionality.

## Security Considerations

- Port management includes process identification to prevent unauthorized access
- Command center execution is sandboxed and logged
- Dashboard access should be secured in production environments
- MCP server WebSocket connections should use secure protocols (WSS) in production

## Testing

Run the comprehensive test suite:

```bash
python test_enhanced_features.py
```

This will test:
- Port management functionality
- Dashboard data retrieval and HTML generation
- MCP server capabilities and message processing
- Command center execution
- Optional dependency handling

## Future Enhancements

- Web-based dashboard with real-time updates
- Authentication and authorization for dashboard access
- Advanced command center with predefined command templates
- Integration with Azure Monitor and Application Insights
- Alerting and notification systems
- Historical data storage and analytics