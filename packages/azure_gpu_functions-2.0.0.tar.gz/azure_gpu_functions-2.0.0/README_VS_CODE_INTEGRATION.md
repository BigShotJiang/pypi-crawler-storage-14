# VS Code Agent Integration for Ray MCP Server

This integration enables VS Code agents (like Cline, Roo Code, Claude Code) to easily launch and manage large-scale GPU training and inference tasks through natural language commands.

## Quick Start

1. **Install VS Code Agent Extension**
   - Install [Cline](https://marketplace.visualstudio.com/items?itemName=saoudrizwan.cline) or [Roo Code](https://marketplace.visualstudio.com/items?itemName=RooVeterinaryInc.roo-cline)
   - Configure the MCP server using `mcp-config.json`

2. **Launch Training via Agent**
   ```
   "Launch a small training job on T4 GPUs for my chatbot model"
   ```

3. **Monitor Progress**
   ```
   "Check the status of training session vscode_agent_small_1234567890"
   ```

4. **Get Cost Estimates**
   ```
   "How much would it cost to train a medium model on A100 GPUs?"
   ```

## MCP Server Configuration

The `mcp-config.json` file configures the MCP server for VS Code agents:

```json
{
  "mcpServers": {
    "ray-training": {
      "command": "python3",
      "args": ["/Users/xcallens/xdev/appfunctiongpu/ray_mcp_server.py"],
      "env": {
        "PYTHONPATH": "/Users/xcallens/xdev/appfunctiongpu",
        "RAY_ADDRESS": "auto"
      }
    }
  }
}
```

## Available Training Configurations

- **small**: GPT-2 Small (117M params), batch_size=8, epochs=3
- **medium**: GPT-2 Medium (345M params), batch_size=4, epochs=2
- **large**: GPT-2 Large (774M params), batch_size=2, epochs=1

## Agent Commands Examples

### Launch Training
```
"Start a medium-sized training job for my language model"
"Launch training with the large configuration on A100 GPUs"
"Begin small training for chatbot development"
```

### Monitor Training
```
"What's the status of session vscode_agent_medium_1234567890?"
"Check progress on my current training job"
"How much has the training cost so far?"
```

### Cost Estimation
```
"Estimate cost for large model training on V100"
"How expensive would medium training be on T4 GPUs?"
"Show me cost breakdown for small training"
```

### Control Operations
```
"Pause the training session vscode_agent_small_1234567890"
"Resume training for session vscode_agent_medium_1234567890"
"Take a snapshot of the current training state"
```

## Helper Script

Use `vscode_agent_helper.py` for programmatic access:

```bash
# Launch training
python3 vscode_agent_helper.py launch small T4

# Monitor training
python3 vscode_agent_helper.py monitor vscode_agent_small_1234567890

# Get cost estimate
python3 vscode_agent_helper.py estimate medium A100

# List configurations
python3 vscode_agent_helper.py configs
```

## Real-time Monitoring

The MCP server provides real-time updates through WebSocket connections, allowing agents to:

- Monitor training progress live
- Track costs as they accrue
- Receive notifications of completion/failures
- Get performance metrics updates

## Troubleshooting

### Common Issues

1. **MCP Server Not Connecting**
   - Ensure `ray_mcp_server.py` is executable
   - Check Python path and dependencies
   - Verify Ray cluster is running

2. **Training Launch Fails**
   - Check available GPU resources
   - Verify training data format
   - Ensure Ray cluster has sufficient memory

3. **Cost Estimation Errors**
   - Confirm GPU type availability
   - Check pricing data freshness
   - Verify configuration exists

### Logs and Debugging

- MCP server logs: Check terminal output when starting the server
- Ray logs: Use `ray logs` command for cluster diagnostics
- Agent logs: Check VS Code output panel for agent-specific errors

## Advanced Features

### Custom Training Configurations

Add new configurations in `training_functions.py`:

```python
TRAINING_CONFIGS["custom"] = {
    "model_name": "gpt2-xl",
    "batch_size": 1,
    "num_epochs": 1,
    "learning_rate": 5e-5,
    "max_length": 1024
}
```

### Environment Variables

Set these for custom deployments:

- `RAY_ADDRESS`: Ray cluster address (default: "auto")
- `GPU_TYPE`: Default GPU type for cost calculations
- `MAX_COST_LIMIT`: Maximum allowed training cost in USD

### WebSocket Integration

For advanced agent integrations, connect directly to the MCP WebSocket server:

```python
import websockets
import json

async def connect_to_mcp():
    uri = "ws://localhost:8765"
    async with websockets.connect(uri) as websocket:
        # Send MCP messages
        await websocket.send(json.dumps({
            "type": "launch_training",
            "id": "ws_client_1",
            "config_name": "small"
        }))

        # Receive responses
        response = await websocket.recv()
        print(f"Response: {response}")
```

## Security Considerations

- The MCP server runs locally and only accepts connections from VS Code agents
- Training data is processed in-memory and not persisted
- Cost estimates are based on public cloud pricing (may vary)
- GPU resources are managed through Ray's security model

## Contributing

To extend the VS Code agent integration:

1. Add new MCP message types in `ray_mcp_server.py`
2. Update agent helper functions in `vscode_agent_helper.py`
3. Document new features in this README
4. Test with multiple VS Code agent extensions

## Support

For issues with VS Code agent integration:

1. Check the [VS_CODE_AGENT_INTEGRATION.md](VS_CODE_AGENT_INTEGRATION.md) guide
2. Verify MCP server configuration
3. Test with the helper script
4. Check Ray cluster status and logs

The integration provides a seamless way to manage enterprise-grade GPU training through natural language commands in your development environment.