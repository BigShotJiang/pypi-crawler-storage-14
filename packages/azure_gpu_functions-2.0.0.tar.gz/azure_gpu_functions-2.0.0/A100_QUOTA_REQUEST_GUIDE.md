# Azure A100 GPU Quota Request Guide

## 🎯 **Overview**

This guide will help you request **NVIDIA A100 GPU quota** in Azure for your LLM training project on the **Amadeus test subscription**. A100 GPUs are required for running the Azure Functions with GPU support for training large language models like Mistral 70B.

## 📋 **Prerequisites**

Before requesting GPU quota, ensure you have:

- ✅ Access to Azure subscription: `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba`
- ✅ **Contributor** or **Owner** role on the subscription
- ✅ Valid business justification for GPU usage
- ✅ Understanding of expected costs and usage patterns

## 🔍 **Step 1: Check Current Quota**

First, verify your current GPU quota and usage in North Europe:

### Option A: Azure CLI
```bash
# Login to Azure
az login

# Set subscription
az account set --subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba

# Check current quota for Container Apps in North Europe
az containerapp env show-custom-domain-verification-id --subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba

# Check compute quota
az vm list-usage --location northeurope --query "[?contains(name.value, 'GPU') || contains(name.value, 'NC')]"
```

### Option B: Azure Portal
1. Navigate to [Azure Portal](https://portal.azure.com)
2. Go to **Subscriptions** → Select your subscription: `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba`
3. Select **Usage + quotas** from the left menu
4. Filter by:
   - **Location**: `North Europe`
   - **Provider**: `Microsoft.Compute` or `Microsoft.App`
   - **Resource**: Search for "GPU" or "NC"

## 📝 **Step 2: Prepare Your Request**

### Required Information

Gather the following details for your quota request:

| **Field** | **Value** | **Description** |
|-----------|-----------|-----------------|
| **Subscription ID** | `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba` | Amadeus test subscription |
| **Location** | `North Europe` | Target region for deployment |
| **Resource Type** | `Container Apps - GPU Workload Profiles` | Service requiring GPU |
| **GPU Type** | `NVIDIA A100 (NC24ads_A100_v4)` | Specific GPU model |
| **Quota Type** | `Cores` | Unit of measurement |
| **Current Limit** | `0` (likely) | Current quota limit |
| **New Limit** | `24` (recommended) | Requested quota limit |
| **Expected Usage** | `1-3 instances` | Concurrent GPU instances |
| **Duration** | `3-6 months` | Testing and development period |

### Business Justification Template

```
Subject: GPU Quota Request - LLM Training for Amadeus Test Environment

Business Justification:
- Project: Large Language Model (LLM) training and fine-tuning for Amadeus applications
- Technology: Azure Functions on Container Apps with NVIDIA A100 GPU support
- Models: Training custom models based on Mistral 70B and similar large language models
- Environment: Test/Development environment for proof of concept
- Timeline: 3-6 months for testing and validation
- Team: AI/ML development team working on modernizing Amadeus applications

Technical Requirements:
- NVIDIA A100 GPU with 80GB memory for large model training
- Container Apps environment with GPU workload profiles
- Serverless scaling for cost optimization
- North Europe region for data locality and compliance

Expected Usage Pattern:
- Training sessions: 2-4 hours per session, 2-3 times per week
- Development testing: 1-2 hours per day during development
- Peak usage: 1-3 concurrent A100 instances
- Off-hours: Scale to zero for cost optimization
```

## 🎫 **Step 3: Submit Support Request**

### Method 1: Azure Portal (Recommended)

1. **Navigate to Support**
   - Go to [Azure Portal](https://portal.azure.com)
   - Click **Help + support** in the left menu
   - Select **New support request**

2. **Problem Description**
   - **Issue type**: `Service and subscription limits (quotas)`
   - **Subscription**: Select `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba`
   - **Quota type**: `Compute-VM (cores-vCPUs) subscription limit increases`
   - **Problem type**: `Container Apps`

3. **Quota Details**
   - **Deployment model**: `Resource Manager`
   - **Location**: `North Europe`
   - **VM Series**: `NCads A100 v4 Series`
   - **New vCPU Limit**: `24` (for 1 NC24ads_A100_v4 instance)

4. **Additional Details**
   ```
   Resource Type: Azure Container Apps with GPU Workload Profiles
   GPU Model: NVIDIA A100 (NC24ads_A100_v4)
   Use Case: Large Language Model training and inference for Amadeus test environment
   Expected Usage: 1-3 concurrent instances, scale-to-zero capability
   Project Duration: 3-6 months (testing phase)
   ```

5. **Contact Information**
   - Provide your Amadeus contact details
   - **Preferred contact method**: Email
   - **Language**: English

### Method 2: Azure CLI Support Request

```bash
# Create support request via CLI
az support tickets create \
  --ticket-name "A100-GPU-Quota-Request-$(date +%Y%m%d)" \
  --title "A100 GPU Quota Request for Container Apps - Amadeus Test" \
  --description "Request for NVIDIA A100 GPU quota in North Europe for LLM training on Container Apps" \
  --problem-classification "/providers/Microsoft.Support/services/quota_service_guid/problemClassifications/quota_problemClassification_guid" \
  --severity "minimal" \
  --contact-details '{
    "country": "FR",
    "firstName": "Your",
    "lastName": "Name", 
    "primaryEmailAddress": "your.email@amadeus.com",
    "preferredContactMethod": "email",
    "preferredTimeZone": "Central European Standard Time"
  }'
```

## ⏰ **Step 4: Request Timeline**

### Expected Processing Times

| **Quota Type** | **Typical Response Time** | **Approval Time** |
|----------------|---------------------------|-------------------|
| Standard GPU Quota | 1-2 business days | 3-5 business days |
| A100 Specialized Quota | 2-3 business days | 5-10 business days |
| Large Quota Requests | 3-5 business days | 7-14 business days |

### Follow-up Process

1. **Acknowledgment**: You'll receive a ticket number within 2-4 hours
2. **Initial Review**: Microsoft will review within 1-2 business days
3. **Additional Information**: May request clarification (respond promptly)
4. **Approval/Denial**: Final decision typically within 5-10 business days
5. **Quota Activation**: Usually immediate after approval

## 📊 **Step 5: Monitor Request Status**

### Azure Portal Monitoring

1. Go to **Help + support** → **All support requests**
2. Find your request by ticket number
3. Monitor status updates and respond to any questions

### CLI Monitoring

```bash
# List all support tickets
az support tickets list --query "[?contains(title, 'A100')]"

# Get specific ticket details
az support tickets show --ticket-name "your-ticket-name"
```

## 💰 **Step 6: Cost Planning**

### A100 GPU Pricing (North Europe - Estimated)

| **Instance Type** | **GPU Memory** | **Hourly Rate** | **Daily Cost** | **Monthly Cost** |
|-------------------|----------------|-----------------|----------------|------------------|
| NC24ads_A100_v4 | 80GB A100 | ~$3.50/hour | ~$84/day | ~$2,520/month |
| **Scale-to-Zero** | When idle | $0/hour | $0/day | **Significant Savings** |

### Cost Optimization Tips

- ✅ **Use serverless scaling** - Scale to zero when not training
- ✅ **Schedule training jobs** - Run during off-peak hours
- ✅ **Monitor usage** - Set up billing alerts
- ✅ **Optimize model size** - Use LoRA fine-tuning for efficiency
- ✅ **Batch processing** - Process multiple datasets together

## 🔧 **Step 7: Post-Approval Setup**

Once your quota is approved:

### 1. Verify Quota Increase
```bash
# Check updated quota
az vm list-usage --location northeurope --query "[?contains(name.value, 'NCads A100')]"
```

### 2. Deploy Your Infrastructure
```bash
cd /Users/xcallens/xdev/appfunctiongpu
./deploy.sh
```

### 3. Test GPU Availability
```bash
python test_function.py https://your-function-app-url.azurecontainerapps.io
```

## 🚨 **Troubleshooting**

### Common Issues and Solutions

#### ❌ **"Quota request denied"**
- **Cause**: Insufficient business justification or region capacity
- **Solution**: 
  - Provide more detailed use case
  - Consider alternative regions (West Europe, East US)
  - Start with smaller quota (12 cores instead of 24)

#### ❌ **"Resource not available in region"**
- **Cause**: A100 not available in North Europe
- **Solution**:
  - Check alternative regions: West Europe, East US
  - Use T4 GPUs as alternative (smaller but still capable)

#### ❌ **"Deployment fails with quota exceeded"**
- **Cause**: Quota approved but not reflected yet
- **Solution**:
  - Wait 1-2 hours for quota propagation
  - Try alternative subscription regions
  - Contact support with approval details

### Alternative GPU Options

If A100 quota is not available:

| **GPU Type** | **Memory** | **Performance** | **Cost** | **Use Case** |
|--------------|------------|-----------------|----------|--------------|
| A100 (Preferred) | 80GB | Highest | High | Large models (70B+) |
| T4 | 16GB | Good | Lower | Smaller models (<10B) |
| V100 | 32GB | Good | Medium | Medium models (10-30B) |

## 📞 **Support Contacts**

### Escalation Path

1. **Standard Support**: Use Azure portal support request
2. **Account Team**: Contact your Amadeus Azure account manager
3. **Microsoft FastTrack**: If available for your organization
4. **Premier Support**: If you have premium support contract

### Contact Information Template

```
Name: [Your Name]
Company: Amadeus
Email: [your.email@amadeus.com]
Subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba
Project: LLM GPU Training for Amadeus Test Environment
Urgency: Medium (Development/Testing)
```

## ✅ **Pre-Deployment Checklist**

Before submitting your quota request:

- [ ] Verified current quota usage
- [ ] Prepared detailed business justification
- [ ] Confirmed subscription access and permissions
- [ ] Estimated costs and obtained budget approval
- [ ] Identified alternative regions if needed
- [ ] Prepared technical requirements documentation
- [ ] Set up monitoring and billing alerts
- [ ] Reviewed compliance and security requirements

## 🎉 **Success Indicators**

Your quota request is likely to be approved if:

- ✅ Clear business justification tied to legitimate AI/ML development
- ✅ Amadeus organization with established Azure relationship
- ✅ Reasonable resource requirements (not requesting excessive quota)
- ✅ Test/development environment (lower risk than production)
- ✅ Detailed technical specifications and usage patterns
- ✅ Commitment to cost monitoring and optimization

---

**📞 Need Help?** If you encounter issues during the quota request process, refer to the troubleshooting section above or contact your Azure account team for assistance.