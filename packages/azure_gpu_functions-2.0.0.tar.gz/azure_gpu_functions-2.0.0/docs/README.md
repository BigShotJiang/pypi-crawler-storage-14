# Azure Function with GPU Support for LLM Training

This project creates an Azure Function app with NVIDIA A100 GPU support for training and running inference on large language models like Mistral 70B.

## Architecture Overview

- **Azure Functions on Azure Container Apps** with GPU workload profiles
- **NVIDIA A100 GPU** support for compute-intensive training
- **Container-based deployment** with CUDA libraries
- **Serverless scaling** from 0 to multiple instances
- **Secure storage** with Azure Key Vault and managed identities

## Project Structure

```
appfunctiongpu/
├── function_app.py              # Main Azure Function code
├── host.json                    # Function host configuration  
├── local.settings.json          # Local development settings
├── requirements.txt             # Python dependencies
├── Dockerfile                   # Container configuration
├── azure.yaml                   # Azure Developer CLI config
├── infra/                       # Infrastructure as Code
│   ├── main.bicep              # Main Bicep template
│   ├── abbreviations.json      # Resource naming conventions
│   └── modules/                # Bicep modules
│       ├── container-apps-env.bicep
│       ├── function-app.bicep
│       ├── container-registry.bicep
│       ├── log-analytics.bicep
│       ├── app-insights.bicep
│       ├── key-vault.bicep
│       └── storage-account.bicep
└── .azure/                     # Azure deployment settings
```

## Features

### 🚀 **Azure Functions**
- **Python v2 programming model** with modern async support
- **HTTP triggers** for training and inference endpoints
- **System status** endpoint for GPU monitoring
- **30-minute timeout** for long-running training jobs

### 🔥 **GPU Capabilities** 
- **NVIDIA A100 GPU** support with 80GB memory
- **CUDA 12.1** with PyTorch GPU acceleration
- **LoRA fine-tuning** for efficient model adaptation
- **Mixed precision training** (FP16) for memory optimization

### 📊 **ML Libraries**
- **PyTorch** with CUDA support
- **Transformers** for Hugging Face models
- **PEFT** for parameter-efficient fine-tuning
- **Datasets** for data processing
- **Accelerate** for distributed training

### ☁️ **Azure Services**
- **Container Apps Environment** with GPU workload profiles
- **Application Insights** for monitoring and telemetry
- **Key Vault** for secure configuration management
- **Container Registry** for custom images
- **Storage Account** for function runtime

## Deployment Guide

### Prerequisites

1. **Azure CLI** and **Azure Developer CLI (azd)**
   ```bash
   # Install Azure CLI
   brew install azure-cli
   
   # Install Azure Developer CLI
   brew install azd
   ```

2. **Azure Subscription** with GPU quota
   - Subscription ID: `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba`
   - Location: `North Europe`
   - **📝 REQUEST A100 GPU QUOTA** - See dedicated guides:
     - 📋 **[Complete Guide](A100_QUOTA_REQUEST_GUIDE.md)** - Detailed step-by-step instructions
     - 🚀 **[Quick Reference](QUOTA_QUICK_REF.md)** - Essential information only
     - 📝 **[Request Template](QUOTA_REQUEST_TEMPLATE.md)** - Copy-paste template for Azure Portal
     - 🔍 **[Pre-flight Check](check_quota_readiness.sh)** - Run before submitting request

3. **Docker** for local container building
   ```bash
   brew install docker
   ```

### Step 1: Login to Azure

```bash
# Login to Azure
az login

# Set subscription
az account set --subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba

# Login to Azure Developer CLI
azd auth login
```

### Step 2: Initialize Environment

```bash
# Navigate to project directory
cd /Users/xcallens/xdev/appfunctiongpu

# Initialize azd environment
azd env new llm-gpu-function-test

# Set environment variables
azd env set AZURE_LOCATION northeurope
azd env set AZURE_SUBSCRIPTION_ID 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba
```

### Step 3: Deploy Infrastructure

```bash
# Preview deployment
azd provision --preview

# Deploy infrastructure
azd provision
```

### Step 4: Build and Deploy Application

```bash
# Build container and deploy
azd deploy
```

## API Endpoints

### 1. System Status
- **Endpoint**: `GET /api/status`
- **Purpose**: Check GPU availability and system resources
- **Response**:
  ```json
  {
    "status": "healthy",
    "system_info": {
      "cpu_count": 4,
      "memory_total_gb": 16.0,
      "gpus": [{
        "name": "NVIDIA A100-SXM4-80GB",
        "memory_total_mb": 81920,
        "gpu_utilization": 0
      }]
    },
    "gpu_info": {
      "gpu_available": true,
      "device_name": "NVIDIA A100-SXM4-80GB",
      "memory_total_gb": 80.0
    }
  }
  ```

### 2. Train LLM
- **Endpoint**: `POST /api/train`
- **Purpose**: Fine-tune LLM with custom training data
- **Request Body**:
  ```json
  {
    "training_data": [
      "Example training text 1",
      "Example training text 2"
    ],
    "model_name": "mistralai/Mistral-7B-v0.1",
    "epochs": 3,
    "learning_rate": 2e-5
  }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "training_completed": true,
    "training_duration_seconds": 1800,
    "training_stats": {
      "train_loss": 0.45,
      "train_samples": 100,
      "epochs_completed": 3
    }
  }
  ```

### 3. LLM Inference
- **Endpoint**: `POST /api/inference`
- **Purpose**: Run inference on trained model
- **Request Body**:
  ```json
  {
    "prompt": "What is machine learning?",
    "max_length": 512,
    "temperature": 0.7
  }
  ```
- **Response**:
  ```json
  {
    "status": "success",
    "prompt": "What is machine learning?",
    "generated_text": "Machine learning is a subset of artificial intelligence...",
    "model_used": "mistralai/Mistral-7B-v0.1"
  }
  ```

## Local Development

### Build Container Locally
```bash
docker build -t llm-function-gpu .
```

### Run Container Locally (with GPU)
```bash
docker run --gpus all -p 8090:80 \
  -e AzureWebJobsStorage="UseDevelopmentStorage=true" \
  llm-function-gpu
```

### Test Functions
```bash
# Test system status
curl http://localhost:8090/api/status

# Test training
curl -X POST http://localhost:8090/api/train \
  -H "Content-Type: application/json" \
  -d '{"training_data": ["Hello world"], "epochs": 1}'
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MODEL_NAME` | HuggingFace model name | `mistralai/Mistral-7B-v0.1` |
| `BATCH_SIZE` | Training batch size | `1` |
| `MAX_SEQUENCE_LENGTH` | Maximum token sequence length | `4096` |
| `LEARNING_RATE` | Training learning rate | `2e-5` |
| `NUM_TRAIN_EPOCHS` | Number of training epochs | `3` |
| `GRADIENT_ACCUMULATION_STEPS` | Gradient accumulation | `8` |

### GPU Configuration

- **GPU Type**: NVIDIA A100 (80GB memory)
- **CUDA Version**: 12.1
- **Memory Management**: Configured for efficient allocation
- **Scale**: 0 to 3 instances based on demand

## Monitoring

### Application Insights
- Function execution metrics
- GPU utilization tracking
- Error and exception logging
- Custom telemetry for training metrics

### Log Analytics
- Container logs and system metrics
- GPU resource consumption
- Performance and scaling insights

## Security

- **Managed Identity** for Azure service authentication
- **Key Vault** integration for secrets
- **Private container registry** with RBAC
- **Network isolation** options available

## Cost Optimization

- **Scale to zero** when not in use
- **A100 GPU** charged per second of usage
- **Consumption-based** billing model
- **Efficient resource allocation**

## Troubleshooting

### Common Issues

1. **GPU Not Available**
   - Ensure A100 quota is approved
   - Check workload profile configuration
   - Verify CUDA driver installation

2. **Out of Memory Errors**
   - Reduce batch size
   - Use gradient accumulation
   - Enable mixed precision training

3. **Cold Start Issues**
   - Consider minimum replicas for warm instances
   - Optimize container startup time
   - Use smaller base models for faster loading

### Support Resources

- Azure Container Apps Documentation
- NVIDIA GPU Development Guides  
- PyTorch CUDA Troubleshooting
- Azure Functions GPU Support

## Next Steps

1. **Request A100 GPU quota** for your subscription
2. **Deploy and test** the infrastructure
3. **Upload training data** to storage accounts
4. **Monitor performance** through Application Insights
5. **Scale configuration** based on usage patterns