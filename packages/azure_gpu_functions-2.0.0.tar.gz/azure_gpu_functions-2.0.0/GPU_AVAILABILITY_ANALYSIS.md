# GPU Options Available for Azure Container Apps in GEM TST Landing Zone

## Current Quota Status
- **Subscription**: `amacp-tst-ne-gem-01`
- **Available GPU Quotas**: Consumption GPUs only (A100 and T4)
- **Dedicated GPU Access**: Not available (requires Enterprise Agreement)
- **GPU Preview Features**: Not registered (DedicatedGPUPreview, ConsumptionGPUPreview, ConsumptionGPUIgnite2024)

## Available GPU Workload Profiles (Ranked by Computational Power)

### 🥇 **NC96-A100** (Dedicated - Not Available)
- **GPU**: 4x NVIDIA A100 80GB
- **FP32 FLOPs**: ~1,953 TFLOPs
- **Memory**: 320 GB HBM2e
- **vCPU**: 96 cores
- **RAM**: 880 GB
- **Quota Required**: SubscriptionNCA100Gpus = 96
- **Status**: ❌ Not available in your subscription
- **Use Case**: Maximum performance for large-scale AI workloads

### 🥈 **NC48-A100** (Dedicated - Not Available)
- **GPU**: 2x NVIDIA A100 80GB
- **FP32 FLOPs**: ~977 TFLOPs
- **Memory**: 160 GB HBM2e
- **vCPU**: 48 cores
- **RAM**: 440 GB
- **Quota Required**: SubscriptionNCA100Gpus = 48
- **Status**: ❌ Not available in your subscription
- **Use Case**: High-performance AI model training/inference

### 🥉 **NC24-A100** (Dedicated - Not Available)
- **GPU**: 1x NVIDIA A100 80GB
- **FP32 FLOPs**: ~488 TFLOPs
- **Memory**: 80 GB HBM2e
- **vCPU**: 24 cores
- **RAM**: 220 GB
- **Quota Required**: SubscriptionNCA100Gpus = 24
- **Status**: ❌ Not available in your subscription
- **Use Case**: Production AI workloads, complex PyTorch models

---

## ✅ **Available in Your Subscription (Consumption GPUs)**

### 🏆 **Consumption-GPU-NC24-A100** (Highest Performance Available)
- **GPU**: 1x NVIDIA A100 80GB
- **FP32 FLOPs**: ~488 TFLOPs (same as dedicated NC24-A100)
- **Memory**: 80 GB HBM2e
- **vCPU**: 24 cores
- **RAM**: 220 GB
- **Scaling**: Serverless (scale-to-zero)
- **Quota Required**: Managed Environment Consumption NCA100 Gpus = 24
- **Status**: ✅ **AVAILABLE** (requested in support ticket)
- **Cost**: Pay-per-use (more cost-effective for intermittent workloads)
- **Use Case**: **RECOMMENDED** - Full A100 performance for PyTorch workloads

### 🥈 **Consumption-GPU-NC16-T4** (Development/Testing)
- **GPU**: 1x NVIDIA T4 16GB
- **FP32 FLOPs**: ~65 TFLOPs
- **Memory**: 16 GB GDDR6
- **vCPU**: 16 cores
- **RAM**: 64 GB
- **Scaling**: Serverless (scale-to-zero)
- **Quota Required**: Managed Environment Consumption T4 Gpus = 16
- **Status**: ✅ **AVAILABLE** (requested in support ticket)
- **Cost**: Lower than A100 (good for development)
- **Use Case**: Development, testing, smaller models, cost optimization

## Performance Comparison

| GPU Profile | FP32 FLOPs | Memory | vCPU | Scaling | Cost Model | Status |
|-------------|------------|--------|------|---------|------------|--------|
| **NC96-A100** | 1,953 T | 320GB | 96 | Always-on | Hourly | ❌ Unavailable |
| **NC48-A100** | 977 T | 160GB | 48 | Always-on | Hourly | ❌ Unavailable |
| **NC24-A100** | 488 T | 80GB | 24 | Always-on | Hourly | ❌ Unavailable |
| **Consumption A100** | **488 T** | **80GB** | **24** | **Serverless** | **Pay-per-use** | ✅ **Available** |
| **Consumption T4** | 65 T | 16GB | 16 | Serverless | Pay-per-use | ✅ **Available** |

## Recommendation for Your Use Case

### **Primary Choice: Consumption A100**
- **Why**: Same A100 hardware as dedicated GPUs, full PyTorch compatibility
- **Performance**: Identical to NC24-A100 (488 TFLOPs)
- **Cost**: Pay-per-use instead of always-on (cost-effective for testing)
- **Scaling**: Serverless (automatically scales to zero when not in use)

### **Secondary Choice: Consumption T4**
- **Why**: Available immediately, good for development/testing
- **Performance**: Sufficient for smaller PyTorch models and validation
- **Cost**: Lower cost than A100
- **Use Case**: Development environment, quick testing, cost optimization

## Next Steps

1. **Wait for Quota Approval** (1-2 business days)
2. **Deploy A100 First**: Use Consumption-GPU-NC24-A100 for full performance testing
3. **Fallback to T4**: If A100 quota takes longer, use T4 for initial validation
4. **Production Decision**: Choose based on workload requirements and cost analysis

## Technical Notes

- **PyTorch Compatibility**: All GPUs support CUDA 12.1 and PyTorch 2.9.1+cu121
- **Function Code**: Same code works on all GPU types (automatic GPU detection)
- **Scaling**: Consumption GPUs provide better cost efficiency for intermittent workloads
- **Cold Starts**: Similar performance across all GPU types

**Bottom Line**: You have access to A100-level performance through Consumption GPUs, which provides the same computational power as dedicated GPUs but with serverless scaling benefits.