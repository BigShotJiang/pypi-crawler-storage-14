"""
Azure GPU Functions - A comprehensive library for GPU-accelerated machine learning
on Azure Functions with distributed training, monitoring, and cost optimization.

This package provides:
- GPU-accelerated model training with Ray distributed computing
- Real-time monitoring via MCP (Model Context Protocol) server
- Azure Blob Storage integration for model caching
- Cost analysis and optimization tools
- Easy integration with Azure Functions and Container Apps

Example usage:
    from azure_gpu_functions import GPUTrainer, MCPMonitor, ModelStorage

    # Initialize components
    trainer = GPUTrainer()
    monitor = MCPMonitor()
    storage = ModelStorage()

    # Start training with monitoring
    await trainer.train_with_monitoring(model_config, monitor)
"""

__version__ = "1.1.0"
__author__ = "Amadeus GPU Training Team"
__description__ = "GPU-accelerated ML training for Azure Functions"

# Optional imports with fallbacks
try:
    from .training import GPUTrainer, EnhancedRayTrainer
    _training_available = True
except ImportError:
    _training_available = False
    GPUTrainer = None
    EnhancedRayTrainer = None

try:
    from .mcp_server import MCPMonitor, RayMCPServer
    _mcp_available = True
except ImportError:
    _mcp_available = False
    MCPMonitor = None
    RayMCPServer = None

try:
    from .monitoring import RayMonitor, CostAnalyzer
    _monitoring_available = True
except ImportError:
    _monitoring_available = False
    RayMonitor = None
    CostAnalyzer = None

try:
    from .storage import ModelStorage, BlobStorageManager
    _storage_available = True
except ImportError:
    _storage_available = False
    ModelStorage = None
    BlobStorageManager = None

# Build __all__ dynamically based on what's available
__all__ = []
if _training_available:
    __all__.extend(["GPUTrainer", "EnhancedRayTrainer"])
if _mcp_available:
    __all__.extend(["MCPMonitor", "RayMCPServer"])
if _monitoring_available:
    __all__.extend(["RayMonitor", "CostAnalyzer"])
if _storage_available:
    __all__.extend(["ModelStorage", "BlobStorageManager"])