"""
Cost Estimation and Budget Management System for Azure GPU Functions
Provides cost forecasting, budget tracking, and cost optimization recommendations.
"""

import asyncio
import json
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import sqlite3
import threading

logger = logging.getLogger(__name__)

class CostCategory(Enum):
    COMPUTE = "compute"
    STORAGE = "storage"
    NETWORK = "network"
    GPU = "gpu"
    OTHER = "other"

class BudgetStatus(Enum):
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    EXCEEDED = "exceeded"

@dataclass
class CostEstimate:
    """Cost estimation for a training job"""
    job_id: str
    model_name: str
    estimated_epochs: int
    estimated_time_hours: float
    estimated_cost: float
    cost_breakdown: Dict[str, float]
    confidence_level: float  # 0-1
    created_at: datetime
    parameters: Dict[str, Any]

@dataclass
class Budget:
    """Budget configuration and tracking"""
    team_id: str
    name: str
    total_budget: float
    period_start: datetime
    period_end: datetime
    alerts_enabled: bool = True
    alert_thresholds: Dict[str, float] = None
    used_budget: float = 0.0

    def __post_init__(self):
        if self.alert_thresholds is None:
            self.alert_thresholds = {
                "warning": 0.8,  # 80% of budget
                "critical": 0.95  # 95% of budget
            }

@dataclass
class CostHistory:
    """Historical cost data"""
    job_id: str
    team_id: str
    model_name: str
    actual_cost: float
    actual_time_hours: float
    actual_epochs: int
    cost_breakdown: Dict[str, float]
    timestamp: datetime
    status: str

class CostEstimator:
    """Estimates costs for GPU training jobs"""

    def __init__(self, db_path: str = "cost_data.db"):
        self.db_path = db_path
        self._init_db()
        self._load_historical_data()

    def _init_db(self):
        """Initialize SQLite database for cost data"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS cost_history (
                    job_id TEXT PRIMARY KEY,
                    team_id TEXT,
                    model_name TEXT,
                    actual_cost REAL,
                    actual_time_hours REAL,
                    actual_epochs INTEGER,
                    cost_breakdown TEXT,
                    timestamp TEXT,
                    status TEXT
                )
            ''')
            conn.execute('''
                CREATE TABLE IF NOT EXISTS budgets (
                    team_id TEXT PRIMARY KEY,
                    name TEXT,
                    total_budget REAL,
                    period_start TEXT,
                    period_end TEXT,
                    alerts_enabled INTEGER,
                    alert_thresholds TEXT,
                    used_budget REAL
                )
            ''')
            conn.commit()

    def _load_historical_data(self):
        """Load historical cost data for analysis"""
        self.historical_data = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute('SELECT * FROM cost_history ORDER BY timestamp DESC')
                for row in cursor.fetchall():
                    cost_history = CostHistory(
                        job_id=row[0],
                        team_id=row[1],
                        model_name=row[2],
                        actual_cost=row[3],
                        actual_time_hours=row[4],
                        actual_epochs=row[5],
                        cost_breakdown=json.loads(row[6]),
                        timestamp=datetime.fromisoformat(row[7]),
                        status=row[8]
                    )
                    self.historical_data.append(cost_history)
        except Exception as e:
            logger.warning(f"Failed to load historical data: {e}")

    def estimate_cost(self, model_name: str, epochs: int, batch_size: int = 32,
                     model_size_gb: float = 1.0, gpu_type: str = "V100",
                     region: str = "eastus") -> CostEstimate:
        """
        Estimate cost for a training job based on parameters

        Args:
            model_name: Name of the model being trained
            epochs: Number of training epochs
            batch_size: Training batch size
            model_size_gb: Size of model in GB
            gpu_type: Type of GPU (V100, A100, etc.)
            region: Azure region

        Returns:
            CostEstimate object with detailed breakdown
        """
        job_id = f"estimate_{model_name}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"

        # Base cost rates (per hour) - these would be configurable
        gpu_rates = {
            "V100": 2.50,  # $2.50/hour
            "A100": 3.20,  # $3.20/hour
            "T4": 0.35,    # $0.35/hour
        }

        storage_rate = 0.02  # $0.02/GB/hour
        network_rate = 0.01  # $0.01/GB transferred

        # Estimate training time based on historical data and parameters
        estimated_time = self._estimate_training_time(model_name, epochs, batch_size, model_size_gb)

        # Calculate costs
        gpu_cost = estimated_time * gpu_rates.get(gpu_type, 1.0)
        storage_cost = estimated_time * model_size_gb * storage_rate
        network_cost = estimated_time * 0.1 * network_rate  # Assume 100MB/hour network usage

        total_cost = gpu_cost + storage_cost + network_cost

        cost_breakdown = {
            "gpu": gpu_cost,
            "storage": storage_cost,
            "network": network_cost,
            "other": total_cost * 0.05  # 5% overhead
        }

        # Calculate confidence based on historical data availability
        confidence = self._calculate_confidence(model_name, epochs)

        return CostEstimate(
            job_id=job_id,
            model_name=model_name,
            estimated_epochs=epochs,
            estimated_time_hours=estimated_time,
            estimated_cost=total_cost,
            cost_breakdown=cost_breakdown,
            confidence_level=confidence,
            created_at=datetime.utcnow(),
            parameters={
                "batch_size": batch_size,
                "model_size_gb": model_size_gb,
                "gpu_type": gpu_type,
                "region": region
            }
        )

    def _estimate_training_time(self, model_name: str, epochs: int, batch_size: int,
                               model_size_gb: float) -> float:
        """Estimate training time based on historical data and model parameters"""

        # Base time estimates (hours per epoch) for different model types
        base_times = {
            "bert": 0.5,      # ~30 minutes per epoch
            "gpt": 2.0,       # ~2 hours per epoch
            "resnet": 0.25,   # ~15 minutes per epoch
            "transformer": 1.5,  # ~1.5 hours per epoch
            "default": 1.0    # 1 hour per epoch default
        }

        # Extract model type from name
        model_type = "default"
        for key in base_times.keys():
            if key.lower() in model_name.lower():
                model_type = key
                break

        base_time_per_epoch = base_times[model_type]

        # Adjust for batch size (smaller batches = longer training)
        batch_factor = max(1.0, 32.0 / batch_size)  # Normalize to batch_size=32

        # Adjust for model size
        size_factor = max(1.0, model_size_gb / 1.0)  # Normalize to 1GB

        # Look for historical data for this model
        similar_jobs = [h for h in self.historical_data if h.model_name == model_name]
        if similar_jobs:
            # Use historical average time per epoch
            avg_time_per_epoch = sum(h.actual_time_hours / h.actual_epochs for h in similar_jobs) / len(similar_jobs)
            estimated_time = avg_time_per_epoch * epochs
        else:
            # Use base estimate
            estimated_time = base_time_per_epoch * epochs * batch_factor * size_factor

        return max(0.1, estimated_time)  # Minimum 6 minutes

    def _calculate_confidence(self, model_name: str, epochs: int) -> float:
        """Calculate confidence level for cost estimate"""
        similar_jobs = [h for h in self.historical_data if h.model_name == model_name]

        if not similar_jobs:
            return 0.3  # Low confidence for new models

        # Higher confidence with more historical data
        confidence = min(0.9, len(similar_jobs) / 10.0)  # Max 90% confidence

        # Adjust for epoch similarity
        epoch_similarity = sum(1 for h in similar_jobs if abs(h.actual_epochs - epochs) / epochs < 0.5)
        confidence *= (epoch_similarity / len(similar_jobs)) if similar_jobs else 0.5

        return max(0.1, confidence)

    def record_actual_cost(self, job_id: str, team_id: str, model_name: str,
                          actual_cost: float, actual_time_hours: float,
                          actual_epochs: int, cost_breakdown: Dict[str, float],
                          status: str = "completed"):
        """Record actual cost data for a completed job"""
        cost_history = CostHistory(
            job_id=job_id,
            team_id=team_id,
            model_name=model_name,
            actual_cost=actual_cost,
            actual_time_hours=actual_time_hours,
            actual_epochs=actual_epochs,
            cost_breakdown=cost_breakdown,
            timestamp=datetime.utcnow(),
            status=status
        )

        # Save to database
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                INSERT OR REPLACE INTO cost_history
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                cost_history.job_id,
                cost_history.team_id,
                cost_history.model_name,
                cost_history.actual_cost,
                cost_history.actual_time_hours,
                cost_history.actual_epochs,
                json.dumps(cost_history.cost_breakdown),
                cost_history.timestamp.isoformat(),
                cost_history.status
            ))
            conn.commit()

        # Update historical data cache
        self.historical_data.insert(0, cost_history)

        logger.info(f"Recorded actual cost for job {job_id}: ${actual_cost:.2f}")

    def get_cost_history(self, team_id: Optional[str] = None, model_name: Optional[str] = None,
                        limit: int = 100) -> List[CostHistory]:
        """Get cost history with optional filtering"""
        query = "SELECT * FROM cost_history WHERE 1=1"
        params = []

        if team_id:
            query += " AND team_id = ?"
            params.append(team_id)

        if model_name:
            query += " AND model_name = ?"
            params.append(model_name)

        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(query, params)
            history = []
            for row in cursor.fetchall():
                history.append(CostHistory(
                    job_id=row[0],
                    team_id=row[1],
                    model_name=row[2],
                    actual_cost=row[3],
                    actual_time_hours=row[4],
                    actual_epochs=row[5],
                    cost_breakdown=json.loads(row[6]),
                    timestamp=datetime.fromisoformat(row[7]),
                    status=row[8]
                ))
            return history

class BudgetManager:
    """Manages team budgets and cost tracking"""

    def __init__(self, db_path: str = "cost_data.db"):
        self.db_path = db_path
        self.cost_estimator = CostEstimator(db_path)
        self._lock = threading.Lock()

    def create_budget(self, team_id: str, name: str, total_budget: float,
                     period_days: int = 30) -> Budget:
        """Create a new budget for a team"""
        now = datetime.utcnow()
        budget = Budget(
            team_id=team_id,
            name=name,
            total_budget=total_budget,
            period_start=now,
            period_end=now + timedelta(days=period_days)
        )

        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                INSERT OR REPLACE INTO budgets
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                budget.team_id,
                budget.name,
                budget.total_budget,
                budget.period_start.isoformat(),
                budget.period_end.isoformat(),
                1 if budget.alerts_enabled else 0,
                json.dumps(budget.alert_thresholds),
                budget.used_budget
            ))
            conn.commit()

        logger.info(f"Created budget for team {team_id}: ${total_budget:.2f}")
        return budget

    def get_budget(self, team_id: str) -> Optional[Budget]:
        """Get budget for a team"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute('SELECT * FROM budgets WHERE team_id = ?', (team_id,))
            row = cursor.fetchone()
            if row:
                return Budget(
                    team_id=row[0],
                    name=row[1],
                    total_budget=row[2],
                    period_start=datetime.fromisoformat(row[3]),
                    period_end=datetime.fromisoformat(row[4]),
                    alerts_enabled=bool(row[5]),
                    alert_thresholds=json.loads(row[6]),
                    used_budget=row[7]
                )
        return None

    def update_budget_usage(self, team_id: str, additional_cost: float):
        """Update budget usage for a team"""
        with self._lock:
            budget = self.get_budget(team_id)
            if budget:
                budget.used_budget += additional_cost

                with sqlite3.connect(self.db_path) as conn:
                    conn.execute('''
                        UPDATE budgets SET used_budget = ? WHERE team_id = ?
                    ''', (budget.used_budget, team_id))
                    conn.commit()

                logger.info(f"Updated budget for team {team_id}: used ${budget.used_budget:.2f} of ${budget.total_budget:.2f}")

    def check_budget_status(self, team_id: str) -> Tuple[BudgetStatus, float, Dict[str, Any]]:
        """Check budget status and return alerts if needed"""
        budget = self.get_budget(team_id)
        if not budget:
            return BudgetStatus.HEALTHY, 0.0, {}

        usage_ratio = budget.used_budget / budget.total_budget

        if usage_ratio >= 1.0:
            status = BudgetStatus.EXCEEDED
        elif usage_ratio >= budget.alert_thresholds.get("critical", 0.95):
            status = BudgetStatus.CRITICAL
        elif usage_ratio >= budget.alert_thresholds.get("warning", 0.8):
            status = BudgetStatus.WARNING
        else:
            status = BudgetStatus.HEALTHY

        remaining_budget = budget.total_budget - budget.used_budget
        days_remaining = (budget.period_end - datetime.utcnow()).days

        alerts = {}
        if status != BudgetStatus.HEALTHY:
            alerts = {
                "status": status.value,
                "usage_ratio": usage_ratio,
                "remaining_budget": remaining_budget,
                "days_remaining": days_remaining,
                "message": self._generate_alert_message(status, usage_ratio, remaining_budget, days_remaining)
            }

        return status, usage_ratio, alerts

    def _generate_alert_message(self, status: BudgetStatus, usage_ratio: float,
                               remaining_budget: float, days_remaining: int) -> str:
        """Generate alert message based on budget status"""
        if status == BudgetStatus.WARNING:
            return f"Budget warning: {usage_ratio:.1%} used, ${remaining_budget:.2f} remaining ({days_remaining} days left)"
        elif status == BudgetStatus.CRITICAL:
            return f"Budget critical: {usage_ratio:.1%} used, ${remaining_budget:.2f} remaining ({days_remaining} days left)"
        elif status == BudgetStatus.EXCEEDED:
            return f"Budget exceeded: ${-remaining_budget:.2f} over budget ({days_remaining} days left)"
        return ""

    def get_cost_forecast(self, team_id: str, planned_jobs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Forecast costs for planned jobs and check against budget"""
        budget = self.get_budget(team_id)
        if not budget:
            return {"error": "No budget found for team"}

        total_estimated_cost = 0.0
        job_estimates = []

        for job in planned_jobs:
            estimate = self.cost_estimator.estimate_cost(
                model_name=job.get("model_name", "unknown"),
                epochs=job.get("epochs", 10),
                batch_size=job.get("batch_size", 32),
                model_size_gb=job.get("model_size_gb", 1.0),
                gpu_type=job.get("gpu_type", "V100")
            )
            total_estimated_cost += estimate.estimated_cost
            job_estimates.append(asdict(estimate))

        remaining_budget = budget.total_budget - budget.used_budget
        projected_usage = budget.used_budget + total_estimated_cost
        projected_ratio = projected_usage / budget.total_budget

        forecast = {
            "current_usage": budget.used_budget,
            "remaining_budget": remaining_budget,
            "total_estimated_cost": total_estimated_cost,
            "projected_usage": projected_usage,
            "projected_ratio": projected_ratio,
            "budget_status": self.check_budget_status(team_id)[0].value,
            "job_estimates": job_estimates,
            "recommendations": self._generate_recommendations(projected_ratio, budget)
        }

        return forecast

    def _generate_recommendations(self, projected_ratio: float, budget: Budget) -> List[str]:
        """Generate cost optimization recommendations"""
        recommendations = []

        if projected_ratio > 1.0:
            recommendations.append("Projected costs exceed budget. Consider reducing epochs or using smaller models.")
        elif projected_ratio > 0.9:
            recommendations.append("High budget utilization projected. Monitor costs closely.")
        elif projected_ratio > 0.7:
            recommendations.append("Moderate budget utilization. Consider cost optimization opportunities.")

        # Add general recommendations
        recommendations.extend([
            "Use spot instances for non-critical training jobs",
            "Consider model quantization to reduce GPU memory requirements",
            "Monitor training efficiency and stop early if convergence is achieved",
            "Use data parallelism for larger batch sizes to improve GPU utilization"
        ])

        return recommendations

    def get_team_cost_summary(self, team_id: str, days: int = 30) -> Dict[str, Any]:
        """Get comprehensive cost summary for a team"""
        cutoff_date = datetime.utcnow() - timedelta(days=days)

        # Get cost history
        history = self.cost_estimator.get_cost_history(team_id=team_id)
        recent_history = [h for h in history if h.timestamp >= cutoff_date]

        # Get budget
        budget = self.get_budget(team_id)

        # Calculate metrics
        total_cost = sum(h.actual_cost for h in recent_history)
        avg_cost_per_job = total_cost / len(recent_history) if recent_history else 0
        total_training_time = sum(h.actual_time_hours for h in recent_history)
        avg_time_per_job = total_training_time / len(recent_history) if recent_history else 0

        # Cost by model
        cost_by_model = {}
        for h in recent_history:
            if h.model_name not in cost_by_model:
                cost_by_model[h.model_name] = {"total_cost": 0, "job_count": 0, "total_time": 0}
            cost_by_model[h.model_name]["total_cost"] += h.actual_cost
            cost_by_model[h.model_name]["job_count"] += 1
            cost_by_model[h.model_name]["total_time"] += h.actual_time_hours

        summary = {
            "team_id": team_id,
            "period_days": days,
            "total_cost": total_cost,
            "job_count": len(recent_history),
            "avg_cost_per_job": avg_cost_per_job,
            "total_training_time": total_training_time,
            "avg_time_per_job": avg_time_per_job,
            "cost_by_model": cost_by_model,
            "budget_info": asdict(budget) if budget else None,
            "budget_status": self.check_budget_status(team_id)[2] if budget else None
        }

        return summary