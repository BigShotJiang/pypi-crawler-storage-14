"""
GPU Training Module for Azure Functions
Provides GPU-accelerated machine learning training capabilities with Ray distributed computing.
"""

import asyncio
import json
import logging
import os
import tempfile
import time
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
import psutil
import GPUtil
import uuid

# Optional imports
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    from transformers import (
        AutoTokenizer, AutoModelForCausalLM,
        TrainingArguments, Trainer, TrainerCallback,
        DataCollatorForLanguageModeling
    )
    from datasets import Dataset
    from peft import LoraConfig, get_peft_model, TaskType
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False

try:
    from ray import tune
    from ray.tune.schedulers import ASHAScheduler
    from ray.tune.search.hyperopt import HyperOptSearch
    RAY_AVAILABLE = True
except ImportError:
    RAY_AVAILABLE = False
try:
    import tensorflow as tf
    from tensorflow.keras import layers, models
    from tensorflow.keras.optimizers import Adam
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False

# Local imports (will be available when packaged)
try:
    from .monitoring import RayMonitor, CostAnalyzer
    from .mcp_server import MCPMonitor
    from .storage import ModelStorage
except ImportError:
    # Fallback for development
    try:
        from ray_monitor import get_ray_monitor, CostAnalyzer
        from ray_mcp_server import get_mcp_server
        from model_storage import get_model_storage
    except ImportError:
        # Mock implementations for testing
        def get_ray_monitor():
            return None
        def get_mcp_server():
            return None
        def get_model_storage():
            return None
        CostAnalyzer = None

logger = logging.getLogger(__name__)


class GPUTrainer:
    """Main GPU training class for Azure Functions"""

    def __init__(self,
                 storage_account: Optional[str] = None,
                 container_name: str = "models",
                 enable_monitoring: bool = True,
                 enable_mcp: bool = True):
        """
        Initialize GPU Trainer

        Args:
            storage_account: Azure storage account name
            container_name: Azure storage container name
            enable_monitoring: Enable Ray monitoring
            enable_mcp: Enable MCP server integration
        """
        self.storage_account = storage_account
        self.container_name = container_name
        self.enable_monitoring = enable_monitoring
        self.enable_mcp = enable_mcp

        # Initialize components
        self.monitor = None
        self.mcp_server = None
        self.storage = None

        if enable_monitoring:
            try:
                self.monitor = RayMonitor()
            except Exception as e:
                logger.warning(f"Failed to initialize Ray monitor: {e}")

        if enable_mcp:
            try:
                self.mcp_server = MCPMonitor()
            except Exception as e:
                logger.warning(f"Failed to initialize MCP server: {e}")

        try:
            self.storage = ModelStorage(storage_account, container_name)
        except Exception as e:
            logger.warning(f"Failed to initialize model storage: {e}")

    async def train_llm(self,
                       model_name: str,
                       training_data: List[Dict],
                       config: Dict[str, Any],
                       session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Train a Large Language Model with GPU acceleration

        Args:
            model_name: HuggingFace model name
            training_data: List of training samples
            config: Training configuration
            session_id: Optional session ID for tracking

        Returns:
            Training results dictionary
        """
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError("Transformers library not available. Install with: pip install transformers datasets peft")

        if session_id is None:
            session_id = str(uuid.uuid4())

        try:
            # Start monitoring session
            if self.mcp_server:
                training_config = {
                    "training_type": "llm_finetuning",
                    "model_name": model_name,
                    "framework": "pytorch",
                    "epochs": config.get("num_epochs", 3),
                    "learning_rate": config.get("learning_rate", 5e-5),
                    "batch_size": config.get("batch_size", 8),
                    "gpu_type": self._detect_gpu_type(),
                    "training_samples": len(training_data),
                    "use_lora": config.get("use_lora", True),
                    "session_id": session_id
                }
                await self.mcp_server.start_training_session(session_id, training_config)

            # Prepare model and tokenizer
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token

            model = AutoModelForCausalLM.from_pretrained(model_name)

            # Apply LoRA if requested
            if config.get("use_lora", True):
                lora_config = LoraConfig(
                    r=16,
                    lora_alpha=32,
                    target_modules=["q_proj", "v_proj"],
                    lora_dropout=0.05,
                    bias="none",
                    task_type=TaskType.CAUSAL_LM
                )
                model = get_peft_model(model, lora_config)

            # Prepare dataset
            def tokenize_function(examples):
                return tokenizer(
                    examples["text"],
                    truncation=True,
                    padding="max_length",
                    max_length=config.get("max_length", 512)
                )

            dataset = Dataset.from_list(training_data)
            tokenized_dataset = dataset.map(tokenize_function, batched=True)
            tokenized_dataset = tokenized_dataset.remove_columns(["text"])

            # Training arguments
            training_args = TrainingArguments(
                output_dir=tempfile.mkdtemp(),
                num_train_epochs=config.get("num_epochs", 3),
                per_device_train_batch_size=config.get("batch_size", 8),
                learning_rate=config.get("learning_rate", 5e-5),
                weight_decay=0.01,
                logging_steps=10,
                save_steps=500,
                evaluation_strategy="no",
                save_strategy="epoch",
                load_best_model_at_end=False,
                report_to=[],
            )

            # Custom callback for MCP monitoring
            class MCPTrainingCallback(TrainerCallback):
                def __init__(self, mcp_server, session_id):
                    self.mcp_server = mcp_server
                    self.session_id = session_id

                def on_log(self, args, state, control, logs=None, **kwargs):
                    if logs and self.mcp_server:
                        metrics = {
                            "epoch": state.epoch,
                            "global_step": state.global_step,
                            "learning_rate": logs.get("learning_rate", 0),
                            "loss": logs.get("loss", 0),
                            "train_samples": len(tokenized_dataset),
                            "timestamp": datetime.utcnow().isoformat()
                        }
                        try:
                            asyncio.create_task(
                                self.mcp_server.update_training_session(self.session_id, metrics)
                            )
                        except:
                            pass

            # Initialize trainer
            trainer = Trainer(
                model=model,
                args=training_args,
                train_dataset=tokenized_dataset,
                data_collator=DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False),
                callbacks=[MCPTrainingCallback(self.mcp_server, session_id)] if self.mcp_server else []
            )

            # Train the model
            trainer.train()

            # Save model
            model_save_path = config.get("output_dir", tempfile.mkdtemp())
            trainer.save_model(model_save_path)

            # Upload to storage if available
            model_url = None
            if self.storage:
                try:
                    model_url = await self.storage.upload_model(model_save_path, f"{model_name}_{session_id}")
                except Exception as e:
                    logger.warning(f"Failed to upload model: {e}")

            # End monitoring session
            if self.mcp_server:
                final_metrics = {
                    "status": "completed",
                    "epochs_completed": config.get("num_epochs", 3),
                    "final_loss": trainer.state.log_history[-1].get("loss", 0) if trainer.state.log_history else 0,
                    "training_samples": len(training_data),
                    "model_saved": True,
                    "model_url": model_url,
                    "timestamp": datetime.utcnow().isoformat()
                }
                await self.mcp_server.end_training_session(session_id, final_metrics)

            return {
                "status": "success",
                "session_id": session_id,
                "model_name": model_name,
                "training_samples": len(training_data),
                "epochs_completed": config.get("num_epochs", 3),
                "model_path": model_save_path,
                "model_url": model_url,
                "final_loss": trainer.state.log_history[-1].get("loss", 0) if trainer.state.log_history else 0
            }

        except Exception as e:
            logger.error(f"Training failed: {e}")

            # End session with error
            if self.mcp_server:
                error_data = {
                    "status": "failed",
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
                await self.mcp_server.end_training_session(session_id, error_data)

            raise

    def _detect_gpu_type(self) -> str:
        """Detect GPU type for monitoring"""
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu_name = gpus[0].name.lower()
                if "a100" in gpu_name:
                    return "A100"
                elif "t4" in gpu_name:
                    return "T4"
                else:
                    return gpu_name
        except:
            pass
        return "unknown"


class EnhancedRayTrainer(GPUTrainer):
    """Enhanced trainer with Ray distributed training and hyperparameter optimization"""

    async def train_with_ray_distributed_enhanced(self,
                                                 config: Dict[str, Any],
                                                 training_data: List[Dict],
                                                 session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Enhanced distributed training with Ray Tune hyperparameter optimization

        Args:
            config: Training configuration
            training_data: Training data samples
            session_id: Optional session ID

        Returns:
            Training results with hyperparameter optimization results
        """
        if not RAY_AVAILABLE:
            raise ImportError("Ray library not available. Install with: pip install ray[default,tune]")

        if session_id is None:
            session_id = str(uuid.uuid4())

        try:
            import ray
            ray.init(ignore_reinit_error=True)

            # Start MCP monitoring
            if self.mcp_server:
                training_config = {
                    "training_type": "distributed_enhanced",
                    "model_name": config.get("model_name", "unknown"),
                    "framework": "pytorch",
                    "epochs": config.get("num_epochs", 3),
                    "learning_rate": config.get("learning_rate", 5e-5),
                    "batch_size": config.get("batch_size", 8),
                    "gpu_type": self._detect_gpu_type(),
                    "training_samples": len(training_data),
                    "distributed": True,
                    "use_lora": config.get("use_lora", False),
                    "session_id": session_id
                }
                await self.mcp_server.start_training_session(session_id, training_config)

            # Training function for Ray Tune
            def train_func(config_ray, checkpoint_dir=None):
                """Training function for Ray Tune trials"""
                try:
                    # Simulate training with hyperparameter
                    import random
                    import math

                    epochs = config.get("num_epochs", 3)
                    total_steps = epochs * (len(training_data) // config.get("batch_size", 8))

                    loss = 2.0
                    for epoch in range(epochs):
                        for step in range(total_steps // epochs):
                            loss = loss * 0.95 + random.uniform(-0.1, 0.1)
                            loss = max(0.1, min(loss, 5.0))

                            if step % 10 == 0 and self.mcp_server:
                                metrics = {
                                    "epoch": epoch,
                                    "global_step": epoch * (total_steps // epochs) + step,
                                    "learning_rate": config_ray.get("learning_rate", 5e-5),
                                    "loss": loss,
                                    "train_samples": len(training_data),
                                    "timestamp": datetime.utcnow().isoformat()
                                }
                                try:
                                    asyncio.create_task(
                                        self.mcp_server.update_training_session(session_id, metrics)
                                    )
                                except:
                                    pass

                    return {
                        "loss": loss,
                        "steps": total_steps,
                        "epochs_completed": epochs,
                        "learning_rate": config_ray.get("learning_rate", 5e-5)
                    }

                except Exception as e:
                    return {"error": str(e), "status": "failed"}

            # Ray Tune configuration
            search_space = {
                "learning_rate": tune.loguniform(1e-5, 5e-4),
            }

            tune_config = {
                "num_samples": config.get("num_samples", 5),
                "scheduler": ASHAScheduler(
                    metric="loss",
                    mode="min",
                    max_t=max(1, config.get("num_epochs", 3) // 2),
                    grace_period=1
                ),
                "resources_per_trial": {
                    "cpu": config.get("cpu_per_trial", 1),
                    "gpu": config.get("gpu_per_trial", 0)
                },
            }

            # Run hyperparameter optimization
            analysis = tune.run(train_func, config=search_space, **tune_config)

            # Get best results
            best_trial = analysis.get_best_trial("loss", "min", "last")
            best_result = best_trial.last_result
            best_config = best_trial.config

            # End MCP session
            if self.mcp_server:
                final_session_data = {
                    "status": "completed",
                    "best_loss": best_result.get("loss", 0),
                    "best_learning_rate": best_config.get("learning_rate", 0),
                    "total_trials": len(analysis.trials),
                    "training_samples": len(training_data),
                    "epochs_completed": config.get("num_epochs", 3),
                    "timestamp": datetime.utcnow().isoformat()
                }
                await self.mcp_server.end_training_session(session_id, final_session_data)

            return {
                "status": "success",
                "session_id": session_id,
                "training_stats": {
                    "best_loss": best_result.get("loss", 0),
                    "best_learning_rate": best_config.get("learning_rate", 0),
                    "total_trials": len(analysis.trials),
                    "train_samples": len(training_data),
                    "epochs_completed": config.get("num_epochs", 3),
                    "distributed": True,
                    "mcp_monitored": self.mcp_server is not None
                },
                "ray_tune_results": {
                    "best_trial_id": best_trial.trial_id,
                    "all_trials": [
                        {
                            "trial_id": trial.trial_id,
                            "loss": trial.last_result.get("loss", 0),
                            "learning_rate": trial.config.get("learning_rate", 0),
                            "status": trial.status
                        } for trial in analysis.trials
                    ]
                }
            }

        except Exception as e:
            logger.error(f"Enhanced distributed training failed: {e}")

            if self.mcp_server:
                error_data = {
                    "status": "failed",
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
                await self.mcp_server.end_training_session(session_id, error_data)

            raise