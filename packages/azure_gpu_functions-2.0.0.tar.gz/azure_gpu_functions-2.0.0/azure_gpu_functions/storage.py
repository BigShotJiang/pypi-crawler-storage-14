"""
Storage Module for Azure GPU Functions
Handles model storage, caching, and Azure Blob Storage integration.
"""

import os
import asyncio
import logging
import tempfile
import shutil
import hashlib
from typing import Optional, Dict, Any, List
from pathlib import Path

# Optional Azure imports
try:
    from azure.storage.blob import BlobServiceClient
    from azure.identity import DefaultAzureCredential
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False

logger = logging.getLogger(__name__)


class ModelStorage:
    """Model storage and caching manager"""

    def __init__(self,
                 storage_account_name: Optional[str] = None,
                 container_name: str = "models",
                 local_cache_dir: Optional[str] = None):
        """
        Initialize model storage

        Args:
            storage_account_name: Azure storage account name
            container_name: Azure storage container name
            local_cache_dir: Local cache directory path
        """
        self.storage_account_name = storage_account_name or os.environ.get("AZURE_STORAGE_ACCOUNT")
        self.container_name = container_name
        self.local_cache_dir = local_cache_dir or os.environ.get(
            "MODEL_CACHE_DIR",
            "/tmp/.cache/huggingface" if os.name != 'nt' else os.path.expanduser("~/.cache/huggingface")
        )

        # Ensure cache directory exists
        os.makedirs(self.local_cache_dir, exist_ok=True)

        # Initialize Azure clients
        self.blob_service_client = None
        self._init_azure_clients()

    def _init_azure_clients(self):
        """Initialize Azure Storage clients"""
        if not AZURE_AVAILABLE:
            logger.warning("Azure Storage libraries not available")
            return

        try:
            if self.storage_account_name:
                account_url = f"https://{self.storage_account_name}.blob.core.windows.net"
                credential = DefaultAzureCredential()
                self.blob_service_client = BlobServiceClient(
                    account_url=account_url,
                    credential=credential
                )
                logger.info(f"Azure Blob Storage client initialized for account: {self.storage_account_name}")
            else:
                logger.warning("No Azure Storage account configured, using local cache only")
        except Exception as e:
            logger.error(f"Failed to initialize Azure clients: {e}")
            self.blob_service_client = None

    def _get_model_cache_path(self, model_name: str) -> str:
        """Get local cache path for a model"""
        # Create a safe directory name from model name
        safe_name = "".join(c for c in model_name if c.isalnum() or c in ('_', '-', '.')).rstrip()
        if not safe_name:
            safe_name = hashlib.md5(model_name.encode()).hexdigest()[:8]

        return os.path.join(self.local_cache_dir, safe_name)

    async def download_model(self,
                           model_name: str,
                           local_path: Optional[str] = None,
                           force_download: bool = False) -> Optional[str]:
        """
        Download model from Azure Blob Storage or use local cache

        Args:
            model_name: Model name/identifier
            local_path: Specific local path to save model
            force_download: Force download even if cached

        Returns:
            Local path to model files
        """
        if not local_path:
            local_path = self._get_model_cache_path(model_name)

        # Check if model is already cached
        if os.path.exists(local_path) and not force_download:
            logger.info(f"Using cached model: {local_path}")
            return local_path

        # Try to download from Azure Blob Storage
        if self.blob_service_client:
            try:
                container_client = self.blob_service_client.get_container_client(self.container_name)

                # List blobs with model prefix
                blobs = container_client.list_blobs(name_starts_with=model_name)
                downloaded_files = []

                os.makedirs(local_path, exist_ok=True)

                async def download_blob(blob):
                    blob_client = container_client.get_blob_client(blob.name)
                    local_file_path = os.path.join(local_path, os.path.basename(blob.name))

                    # Download blob
                    download_stream = await blob_client.download_blob()
                    with open(local_file_path, 'wb') as f:
                        download_stream.readinto(f)

                    downloaded_files.append(local_file_path)
                    logger.info(f"Downloaded: {blob.name} -> {local_file_path}")

                # Download all model files
                tasks = [download_blob(blob) for blob in blobs]
                await asyncio.gather(*tasks)

                if downloaded_files:
                    logger.info(f"Model downloaded successfully: {model_name}")
                    return local_path

            except Exception as e:
                logger.warning(f"Failed to download model from Azure: {e}")

        # Fallback: assume model is available locally or via HuggingFace
        logger.info(f"Model not found in Azure storage, assuming local/HF availability: {model_name}")
        return None

    async def upload_model(self,
                          local_path: str,
                          model_name: str,
                          metadata: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Upload model to Azure Blob Storage

        Args:
            local_path: Local path to model files
            model_name: Model name for storage
            metadata: Additional metadata

        Returns:
            Azure blob URL if successful
        """
        if not self.blob_service_client:
            logger.warning("Azure Blob Storage not configured")
            return None

        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)

            # Ensure container exists
            await container_client.create_container()

            uploaded_files = []

            # Upload all files in the directory
            if os.path.isdir(local_path):
                for root, dirs, files in os.walk(local_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        blob_name = f"{model_name}/{os.path.relpath(file_path, local_path)}"

                        blob_client = container_client.get_blob_client(blob_name)

                        with open(file_path, 'rb') as f:
                            await blob_client.upload_blob(f, overwrite=True)

                        uploaded_files.append(blob_name)
            else:
                # Upload single file
                blob_name = f"{model_name}/{os.path.basename(local_path)}"
                blob_client = container_client.get_blob_client(blob_name)

                with open(local_path, 'rb') as f:
                    await blob_client.upload_blob(f, overwrite=True)

                uploaded_files.append(blob_name)

            # Upload metadata if provided
            if metadata:
                metadata_blob = f"{model_name}/metadata.json"
                metadata_client = container_client.get_blob_client(metadata_blob)
                await metadata_client.upload_blob(
                    json.dumps(metadata).encode('utf-8'),
                    overwrite=True,
                    content_type='application/json'
                )

            blob_url = f"https://{self.storage_account_name}.blob.core.windows.net/{self.container_name}/{model_name}"
            logger.info(f"Model uploaded successfully: {blob_url}")
            return blob_url

        except Exception as e:
            logger.error(f"Failed to upload model: {e}")
            return None

    def list_cached_models(self) -> List[str]:
        """List locally cached models"""
        if not os.path.exists(self.local_cache_dir):
            return []

        models = []
        for item in os.listdir(self.local_cache_dir):
            item_path = os.path.join(self.local_cache_dir, item)
            if os.path.isdir(item_path):
                models.append(item)

        return models

    async def list_remote_models(self) -> List[str]:
        """List models available in Azure Blob Storage"""
        if not self.blob_service_client:
            return []

        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            blobs = container_client.list_blobs()

            models = set()
            async for blob in blobs:
                model_name = blob.name.split('/')[0]
                models.add(model_name)

            return list(models)

        except Exception as e:
            logger.error(f"Failed to list remote models: {e}")
            return []

    def clear_cache(self, model_name: Optional[str] = None, older_than_days: Optional[int] = None):
        """
        Clear local model cache

        Args:
            model_name: Specific model to clear (None for all)
            older_than_days: Clear models older than specified days
        """
        try:
            if model_name:
                cache_path = self._get_model_cache_path(model_name)
                if os.path.exists(cache_path):
                    shutil.rmtree(cache_path)
                    logger.info(f"Cleared cache for model: {model_name}")
            else:
                # Clear all cache
                if os.path.exists(self.local_cache_dir):
                    shutil.rmtree(self.local_cache_dir)
                    os.makedirs(self.local_cache_dir, exist_ok=True)
                    logger.info("Cleared all model cache")

        except Exception as e:
            logger.error(f"Failed to clear cache: {e}")

    def get_cache_info(self) -> Dict[str, Any]:
        """Get cache information"""
        try:
            total_size = 0
            model_count = 0

            if os.path.exists(self.local_cache_dir):
                for root, dirs, files in os.walk(self.local_cache_dir):
                    for file in files:
                        total_size += os.path.getsize(os.path.join(root, file))
                    model_count += len(dirs)

            return {
                "cache_dir": self.local_cache_dir,
                "total_size_bytes": total_size,
                "total_size_gb": round(total_size / (1024**3), 2),
                "model_count": model_count,
                "azure_storage_enabled": self.blob_service_client is not None
            }

        except Exception as e:
            logger.error(f"Failed to get cache info: {e}")
            return {"error": str(e)}


class BlobStorageManager:
    """Simplified blob storage manager for general use"""

    def __init__(self,
                 storage_account_name: Optional[str] = None,
                 container_name: str = "data"):
        self.storage_account_name = storage_account_name or os.environ.get("AZURE_STORAGE_ACCOUNT")
        self.container_name = container_name
        self.blob_service_client = None

        if AZURE_AVAILABLE and self.storage_account_name:
            try:
                account_url = f"https://{self.storage_account_name}.blob.core.windows.net"
                credential = DefaultAzureCredential()
                self.blob_service_client = BlobServiceClient(
                    account_url=account_url,
                    credential=credential
                )
            except Exception as e:
                logger.error(f"Failed to initialize blob storage: {e}")

    async def upload_file(self,
                         local_path: str,
                         blob_name: str,
                         content_type: Optional[str] = None) -> Optional[str]:
        """Upload file to blob storage"""
        if not self.blob_service_client:
            return None

        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            await container_client.create_container()

            blob_client = container_client.get_blob_client(blob_name)

            with open(local_path, 'rb') as f:
                await blob_client.upload_blob(
                    f,
                    overwrite=True,
                    content_type=content_type
                )

            blob_url = f"https://{self.storage_account_name}.blob.core.windows.net/{self.container_name}/{blob_name}"
            return blob_url

        except Exception as e:
            logger.error(f"Failed to upload file: {e}")
            return None

    async def download_file(self, blob_name: str, local_path: str) -> bool:
        """Download file from blob storage"""
        if not self.blob_service_client:
            return False

        try:
            container_client = self.blob_service_client.get_container_client(self.container_name)
            blob_client = container_client.get_blob_client(blob_name)

            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            with open(local_path, 'wb') as f:
                download_stream = await blob_client.download_blob()
                await download_stream.readinto(f)

            return True

        except Exception as e:
            logger.error(f"Failed to download file: {e}")
            return False