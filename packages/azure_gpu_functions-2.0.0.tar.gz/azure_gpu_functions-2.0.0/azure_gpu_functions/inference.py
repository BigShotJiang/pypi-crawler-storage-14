"""
Inference Service for Azure GPU Functions
Provides high-performance inference capabilities with model caching and parallel processing.
Optimized for cost-effective GPUs like T4 with super-fast response times.
"""

import asyncio
import logging
import threading
import time
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
import hashlib
import pickle
import os
from pathlib import Path
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor

# Optional imports for ML frameworks
try:
    import torch
    import transformers
    from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoModelForCausalLM
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None
    transformers = None

try:
    import tensorflow as tf
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False
    tf = None

logger = logging.getLogger(__name__)

class InferenceFramework(Enum):
    PYTORCH = "pytorch"
    TENSORFLOW = "tensorflow"
    ONNX = "onnx"
    CUSTOM = "custom"

class ModelTask(Enum):
    TEXT_CLASSIFICATION = "text_classification"
    TEXT_GENERATION = "text_generation"
    QUESTION_ANSWERING = "question_answering"
    TOKEN_CLASSIFICATION = "token_classification"
    IMAGE_CLASSIFICATION = "image_classification"
    OBJECT_DETECTION = "object_detection"
    CUSTOM = "custom"

@dataclass
class InferenceRequest:
    """Request for model inference"""
    model_id: str
    model_version: Optional[str]
    inputs: Union[str, Dict[str, Any], List[Any]]
    parameters: Dict[str, Any] = None
    request_id: Optional[str] = None
    priority: int = 1  # 1=low, 5=high

    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}
        if self.request_id is None:
            # Generate request ID based on content hash
            content = f"{self.model_id}_{self.model_version}_{str(self.inputs)}_{str(self.parameters)}"
            self.request_id = hashlib.md5(content.encode()).hexdigest()[:8]

@dataclass
class InferenceResult:
    """Result of model inference"""
    request_id: str
    outputs: Any
    model_id: str
    model_version: str
    processing_time_ms: float
    gpu_memory_used_mb: Optional[float] = None
    confidence_scores: Optional[List[float]] = None
    error: Optional[str] = None
    cached: bool = False

class ModelCache:
    """LRU cache for loaded models with memory management"""

    def __init__(self, max_memory_gb: float = 8.0, max_models: int = 10):
        self.max_memory_gb = max_memory_gb
        self.max_models = max_models
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.access_times: Dict[str, float] = {}
        self.memory_usage: Dict[str, float] = {}
        self._lock = threading.Lock()

    def get(self, model_key: str) -> Optional[Dict[str, Any]]:
        """Get model from cache"""
        with self._lock:
            if model_key in self.cache:
                self.access_times[model_key] = time.time()
                return self.cache[model_key]
        return None

    def put(self, model_key: str, model_data: Dict[str, Any], memory_gb: float):
        """Put model in cache with memory management"""
        with self._lock:
            # Check if we need to evict models
            while (len(self.cache) >= self.max_models or
                   sum(self.memory_usage.values()) + memory_gb > self.max_memory_gb):
                self._evict_lru()

            self.cache[model_key] = model_data
            self.access_times[model_key] = time.time()
            self.memory_usage[model_key] = memory_gb

    def _evict_lru(self):
        """Evict least recently used model"""
        if not self.access_times:
            return

        lru_key = min(self.access_times, key=self.access_times.get)
        del self.cache[lru_key]
        del self.access_times[lru_key]
        del self.memory_usage[lru_key]

        # Clean up model resources
        if TORCH_AVAILABLE and torch.cuda.is_available():
            torch.cuda.empty_cache()

    def clear(self):
        """Clear all cached models"""
        with self._lock:
            self.cache.clear()
            self.access_times.clear()
            self.memory_usage.clear()

            if TORCH_AVAILABLE and torch.cuda.is_available():
                torch.cuda.empty_cache()

class InferenceEngine:
    """Core inference engine with caching and parallel processing"""

    def __init__(self, cache_memory_gb: float = 4.0, max_workers: int = 4):
        self.model_cache = ModelCache(max_memory_gb=cache_memory_gb)
        self.executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="inference")
        self.model_registry = None  # Will be set by InferenceService
        self._lock = threading.Lock()

    def load_model(self, model_id: str, model_version: Optional[str] = None,
                  framework: InferenceFramework = InferenceFramework.PYTORCH) -> Dict[str, Any]:
        """
        Load model with caching. Returns cached model if available.
        """
        cache_key = f"{model_id}_{model_version or 'latest'}"

        # Check cache first
        cached_model = self.model_cache.get(cache_key)
        if cached_model:
            logger.info(f"Model {model_id} loaded from cache")
            return cached_model

        # Load from registry
        if not self.model_registry:
            raise ValueError("Model registry not set")

        try:
            # Download model if not local
            model_path = self.model_registry.download_model(model_id, model_version)

            # Load model based on framework
            if framework == InferenceFramework.PYTORCH:
                model_data = self._load_pytorch_model(model_path, model_id)
            elif framework == InferenceFramework.TENSORFLOW:
                model_data = self._load_tensorflow_model(model_path, model_id)
            else:
                raise ValueError(f"Unsupported framework: {framework}")

            # Estimate memory usage
            memory_gb = self._estimate_model_memory(model_data)

            # Cache the model
            self.model_cache.put(cache_key, model_data, memory_gb)

            logger.info(f"Model {model_id} loaded and cached (memory: {memory_gb:.2f}GB)")
            return model_data

        except Exception as e:
            logger.error(f"Failed to load model {model_id}: {e}")
            raise

    def _load_pytorch_model(self, model_path: str, model_id: str) -> Dict[str, Any]:
        """Load PyTorch model"""
        if not TORCH_AVAILABLE:
            raise ImportError("PyTorch not available")

        # Determine model type from model_id or metadata
        model_type = self._infer_model_type(model_id)

        if model_type == ModelTask.TEXT_CLASSIFICATION:
            model = AutoModelForSequenceClassification.from_pretrained(model_path)
            tokenizer = AutoTokenizer.from_pretrained(model_path)
        elif model_type == ModelTask.TEXT_GENERATION:
            model = AutoModelForCausalLM.from_pretrained(model_path)
            tokenizer = AutoTokenizer.from_pretrained(model_path)
        else:
            # Generic model loading
            try:
                model = torch.load(model_path)
                tokenizer = None
            except:
                raise ValueError(f"Cannot load model {model_id}: unsupported format")

        # Move to GPU if available (prefer T4 or similar cost-effective GPUs)
        device = self._get_optimal_device()
        if device.type == 'cuda':
            model = model.to(device)

        return {
            'model': model,
            'tokenizer': tokenizer,
            'device': device,
            'framework': InferenceFramework.PYTORCH,
            'model_type': model_type
        }

    def _load_tensorflow_model(self, model_path: str, model_id: str) -> Dict[str, Any]:
        """Load TensorFlow model"""
        if not TF_AVAILABLE:
            raise ImportError("TensorFlow not available")

        model = tf.saved_model.load(model_path)

        return {
            'model': model,
            'framework': InferenceFramework.TENSORFLOW,
            'model_type': self._infer_model_type(model_id)
        }

    def _get_optimal_device(self):
        """Get optimal device for inference (prefer cost-effective GPUs)"""
        if TORCH_AVAILABLE and torch.cuda.is_available():
            # Prefer T4 GPUs for cost-effective inference
            for i in range(torch.cuda.device_count()):
                gpu_name = torch.cuda.get_device_name(i)
                if 'T4' in gpu_name or 'Tesla T4' in gpu_name:
                    return torch.device(f'cuda:{i}')

            # Fallback to any available GPU
            return torch.device('cuda:0')

        # Return CPU device or mock device when torch not available
        if TORCH_AVAILABLE:
            return torch.device('cpu')
        else:
            # Mock device for when torch is not available
            return type('MockDevice', (), {'type': 'cpu'})()

    def _infer_model_type(self, model_id: str) -> ModelTask:
        """Infer model task type from model ID"""
        model_id_lower = model_id.lower()

        if any(keyword in model_id_lower for keyword in ['bert', 'roberta', 'distilbert']):
            return ModelTask.TEXT_CLASSIFICATION
        elif any(keyword in model_id_lower for keyword in ['gpt', 'llama', 'falcon']):
            return ModelTask.TEXT_GENERATION
        elif 'qa' in model_id_lower or 'question' in model_id_lower:
            return ModelTask.QUESTION_ANSWERING
        else:
            return ModelTask.CUSTOM

    def _estimate_model_memory(self, model_data: Dict[str, Any]) -> float:
        """Estimate memory usage of loaded model"""
        try:
            if model_data['framework'] == InferenceFramework.PYTORCH:
                model = model_data['model']
                if hasattr(model, 'parameters'):
                    # Rough estimate: 4 bytes per parameter + overhead
                    param_count = sum(p.numel() for p in model.parameters())
                    memory_bytes = param_count * 4 * 2  # *2 for gradients/optimizer state
                    return memory_bytes / (1024**3)
        except:
            pass

        # Default estimate
        return 1.0

    async def run_inference(self, request: InferenceRequest) -> InferenceResult:
        """Run inference asynchronously"""
        start_time = time.time()

        try:
            # Load model
            model_data = await asyncio.get_event_loop().run_in_executor(
                self.executor, self.load_model, request.model_id, request.model_version
            )

            # Run inference
            result = await asyncio.get_event_loop().run_in_executor(
                self.executor, self._run_inference_sync, request, model_data
            )

            processing_time = (time.time() - start_time) * 1000  # ms

            return InferenceResult(
                request_id=request.request_id,
                outputs=result['outputs'],
                model_id=request.model_id,
                model_version=request.model_version or 'latest',
                processing_time_ms=processing_time,
                gpu_memory_used_mb=result.get('gpu_memory_mb'),
                confidence_scores=result.get('confidence_scores'),
                cached=result.get('cached', False)
            )

        except Exception as e:
            processing_time = (time.time() - start_time) * 1000
            return InferenceResult(
                request_id=request.request_id,
                outputs=None,
                model_id=request.model_id,
                model_version=request.model_version or 'latest',
                processing_time_ms=processing_time,
                error=str(e)
            )

    def _run_inference_sync(self, request: InferenceRequest, model_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run inference synchronously"""
        model = model_data['model']
        device = model_data.get('device', torch.device('cpu'))

        try:
            if model_data['framework'] == InferenceFramework.PYTORCH:
                return self._run_pytorch_inference(request, model_data)
            elif model_data['framework'] == InferenceFramework.TENSORFLOW:
                return self._run_tensorflow_inference(request, model_data)
            else:
                raise ValueError(f"Unsupported framework: {model_data['framework']}")

        except Exception as e:
            logger.error(f"Inference failed: {e}")
            raise

    def _run_pytorch_inference(self, request: InferenceRequest, model_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run PyTorch inference"""
        model = model_data['model']
        tokenizer = model_data.get('tokenizer')
        device = model_data['device']
        model_type = model_data['model_type']

        # Prepare inputs
        if isinstance(request.inputs, str) and tokenizer:
            inputs = tokenizer(request.inputs, return_tensors='pt', truncation=True, padding=True)
            inputs = {k: v.to(device) for k, v in inputs.items()}
        elif isinstance(request.inputs, dict):
            inputs = {k: torch.tensor(v).to(device) if not isinstance(v, torch.Tensor) else v.to(device)
                     for k, v in request.inputs.items()}
        else:
            raise ValueError("Unsupported input format")

        # Run inference
        with torch.no_grad():
            if model_type == ModelTask.TEXT_GENERATION:
                # Generation parameters
                max_length = request.parameters.get('max_length', 50)
                temperature = request.parameters.get('temperature', 1.0)
                do_sample = request.parameters.get('do_sample', True)

                outputs = model.generate(
                    **inputs,
                    max_length=max_length,
                    temperature=temperature,
                    do_sample=do_sample,
                    pad_token_id=tokenizer.eos_token_id if tokenizer else None
                )

                # Decode outputs
                if tokenizer:
                    generated_texts = tokenizer.batch_decode(outputs, skip_special_tokens=True)
                    result_outputs = generated_texts
                else:
                    result_outputs = outputs.tolist()

            else:
                # Classification or other tasks
                outputs = model(**inputs)
                logits = outputs.logits

                if model_type == ModelTask.TEXT_CLASSIFICATION:
                    probabilities = torch.softmax(logits, dim=-1)
                    predictions = torch.argmax(probabilities, dim=-1)
                    confidence_scores = probabilities.max(dim=-1).values.tolist()

                    result_outputs = {
                        'predictions': predictions.tolist(),
                        'probabilities': probabilities.tolist(),
                        'labels': [model.config.id2label.get(pred.item(), str(pred.item()))
                                 for pred in predictions]
                    }
                else:
                    result_outputs = logits.tolist()

        # GPU memory usage
        gpu_memory_mb = None
        if device.type == 'cuda':
            gpu_memory_mb = torch.cuda.memory_allocated(device) / (1024**2)

        return {
            'outputs': result_outputs,
            'gpu_memory_mb': gpu_memory_mb,
            'confidence_scores': confidence_scores if 'confidence_scores' in locals() else None
        }

    def _run_tensorflow_inference(self, request: InferenceRequest, model_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run TensorFlow inference"""
        model = model_data['model']

        # TensorFlow inference implementation
        # (Simplified - would need to be expanded based on specific model types)
        result_outputs = {"tensorflow_inference": "not_implemented"}

        return {
            'outputs': result_outputs,
            'gpu_memory_mb': None,
            'confidence_scores': None
        }

class InferenceService:
    """High-level inference service with batch processing and monitoring"""

    def __init__(self, max_concurrent_requests: int = 10, cache_memory_gb: float = 4.0):
        self.engine = InferenceEngine(cache_memory_gb=cache_memory_gb)
        self.max_concurrent_requests = max_concurrent_requests
        self.semaphore = asyncio.Semaphore(max_concurrent_requests)
        self.request_queue = asyncio.Queue()
        self.processing_tasks = set()

        # Initialize model registry
        try:
            from .model_registry import ModelRegistry
            self.engine.model_registry = ModelRegistry()
        except ImportError:
            logger.warning("Model registry not available")

        # Start background processing
        self._running = True
        self._processor_task = asyncio.create_task(self._process_queue())

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.shutdown()

    async def shutdown(self):
        """Shutdown the service"""
        self._running = False
        if self._processor_task:
            self._processor_task.cancel()
            try:
                await self._processor_task
            except asyncio.CancelledError:
                pass

        # Clear cache
        self.engine.model_cache.clear()

        # Shutdown executor
        self.engine.executor.shutdown(wait=True)

    async def infer(self, request: InferenceRequest) -> InferenceResult:
        """Submit inference request"""
        async with self.semaphore:
            return await self.engine.run_inference(request)

    async def infer_batch(self, requests: List[InferenceRequest]) -> List[InferenceResult]:
        """Submit batch inference requests"""
        tasks = [self.infer(request) for request in requests]
        return await asyncio.gather(*tasks)

    async def _process_queue(self):
        """Process queued requests"""
        while self._running:
            try:
                # Get next request with timeout
                request = await asyncio.wait_for(self.request_queue.get(), timeout=1.0)

                # Process request
                task = asyncio.create_task(self._process_single_request(request))
                self.processing_tasks.add(task)
                task.add_done_callback(self.processing_tasks.discard)

            except asyncio.TimeoutError:
                continue
            except Exception as e:
                logger.error(f"Queue processing error: {e}")

    async def _process_single_request(self, request: InferenceRequest):
        """Process a single inference request"""
        try:
            result = await self.engine.run_inference(request)
            # Here you could send results to callbacks, WebSocket clients, etc.
            logger.info(f"Inference completed for request {request.request_id}: {result.processing_time_ms:.1f}ms")
        except Exception as e:
            logger.error(f"Request processing failed: {e}")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        memory_usage = self.engine.model_cache.memory_usage
        return {
            'cached_models': len(self.engine.model_cache.cache),
            'total_memory_gb': sum(memory_usage.values()),
            'memory_by_model': memory_usage,
            'max_memory_gb': self.engine.model_cache.max_memory_gb
        }

    def preload_model(self, model_id: str, model_version: Optional[str] = None):
        """Preload model into cache"""
        try:
            self.engine.load_model(model_id, model_version)
            logger.info(f"Model {model_id} preloaded into cache")
        except Exception as e:
            logger.error(f"Failed to preload model {model_id}: {e}")

# Global inference service instance
_inference_service = None

def get_inference_service() -> InferenceService:
    """Get global inference service instance"""
    global _inference_service
    if _inference_service is None:
        _inference_service = InferenceService()
    return _inference_service

async def initialize_inference_service():
    """Initialize the global inference service"""
    global _inference_service
    if _inference_service is None:
        _inference_service = InferenceService()
        logger.info("Inference service initialized")
    return _inference_service

async def shutdown_inference_service():
    """Shutdown the global inference service"""
    global _inference_service
    if _inference_service:
        await _inference_service.shutdown()
        _inference_service = None
        logger.info("Inference service shutdown")