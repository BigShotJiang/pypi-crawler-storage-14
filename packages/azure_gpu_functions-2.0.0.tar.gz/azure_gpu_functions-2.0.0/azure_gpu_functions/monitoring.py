"""
Monitoring Module for Azure GPU Functions
Provides system monitoring, cost analysis, and performance tracking.
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import psutil
import GPUtil
import os

# Optional imports
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    from azure.identity import DefaultAzureCredential
    from azure.mgmt.costmanagement import CostManagementClient
    from azure.mgmt.costmanagement.models import QueryDefinition, TimeframeType, GranularityType
    AZURE_AVAILABLE = True
except ImportError:
    AZURE_AVAILABLE = False

try:
    from prometheus_client import Counter, Gauge, Histogram, CollectorRegistry
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False

logger = logging.getLogger(__name__)


class RayMonitor:
    """Distributed monitoring system using Ray"""

    def __init__(self):
        self.start_time = time.time()
        self.training_sessions = {}
        self.cost_data = {}
        self.system_metrics = []
        self.gpu_metrics = []

        # Initialize Azure clients if available
        if AZURE_AVAILABLE:
            try:
                self.credential = DefaultAzureCredential()
                self.subscription_id = os.environ.get("AZURE_SUBSCRIPTION_ID")
                self.resource_group = os.environ.get("AZURE_RESOURCE_GROUP")
                self.cost_client = CostManagementClient(self.credential, self.subscription_id) if self.subscription_id else None
            except Exception as e:
                logger.warning(f"Failed to initialize Azure clients: {e}")
                self.cost_client = None
        else:
            self.cost_client = None

        # Initialize Prometheus metrics if available
        if PROMETHEUS_AVAILABLE:
            try:
                self.registry = CollectorRegistry()
                self.gpu_utilization = Gauge('gpu_utilization_percent', 'GPU utilization percentage',
                                           ['gpu_id', 'gpu_name'], registry=self.registry)
                self.gpu_memory_used = Gauge('gpu_memory_used_mb', 'GPU memory used in MB',
                                           ['gpu_id', 'gpu_name'], registry=self.registry)
                self.training_duration = Histogram('training_duration_seconds', 'Training duration in seconds',
                                                 registry=self.registry)
                self.training_cost = Counter('training_cost_usd', 'Training cost in USD',
                                           ['session_id', 'gpu_type'], registry=self.registry)
            except Exception as e:
                logger.warning(f"Failed to initialize Prometheus metrics: {e}")
                self.registry = None
        else:
            self.registry = None

    def collect_system_metrics(self) -> Dict[str, Any]:
        """Collect comprehensive system metrics"""
        try:
            # CPU metrics
            cpu_metrics = {
                "cpu_count": psutil.cpu_count(),
                "cpu_count_logical": psutil.cpu_count(logical=True),
                "cpu_usage_percent": psutil.cpu_percent(interval=0.1),
                "cpu_freq_current": psutil.cpu_freq().current if psutil.cpu_freq() else None,
            }

            # Memory metrics
            memory = psutil.virtual_memory()
            memory_metrics = {
                "memory_total_gb": round(memory.total / (1024**3), 2),
                "memory_available_gb": round(memory.available / (1024**3), 2),
                "memory_used_gb": round(memory.used / (1024**3), 2),
                "memory_percent": memory.percent,
            }

            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_metrics = {
                "disk_total_gb": round(disk.total / (1024**3), 2),
                "disk_used_gb": round(disk.used / (1024**3), 2),
                "disk_free_gb": round(disk.free / (1024**3), 2),
                "disk_percent": disk.percent,
            }

            # GPU metrics
            gpu_metrics = []
            try:
                gpus = GPUtil.getGPUs()
                for gpu in gpus:
                    gpu_info = {
                        "id": gpu.id,
                        "name": gpu.name,
                        "uuid": gpu.uuid,
                        "load": gpu.load * 100,
                        "memory_used": gpu.memoryUsed,
                        "memory_total": gpu.memoryTotal,
                        "memory_free": gpu.memoryFree,
                        "memory_util": gpu.memoryUtil * 100,
                        "temperature": gpu.temperature,
                    }
                    gpu_metrics.append(gpu_info)

                    # Update Prometheus metrics if available
                    if self.registry:
                        self.gpu_utilization.labels(gpu_id=str(gpu.id), gpu_name=gpu.name).set(gpu.load * 100)
                        self.gpu_memory_used.labels(gpu_id=str(gpu.id), gpu_name=gpu.name).set(gpu.memoryUsed)

            except Exception as e:
                logger.warning(f"Failed to collect GPU metrics: {e}")

            metrics = {
                "timestamp": datetime.utcnow().isoformat(),
                "cpu": cpu_metrics,
                "memory": memory_metrics,
                "disk": disk_metrics,
                "gpu": gpu_metrics,
                "uptime_seconds": time.time() - self.start_time
            }

            self.system_metrics.append(metrics)
            return metrics

        except Exception as e:
            logger.error(f"Failed to collect system metrics: {e}")
            return {"error": str(e), "timestamp": datetime.utcnow().isoformat()}

    def start_training_session(self, session_id: str, config: Dict[str, Any]):
        """Start tracking a training session"""
        self.training_sessions[session_id] = {
            "config": config,
            "start_time": time.time(),
            "metrics": [],
            "status": "active"
        }
        logger.info(f"Started training session: {session_id}")

    def update_training_session(self, session_id: str, metrics: Dict[str, Any]):
        """Update training session metrics"""
        if session_id in self.training_sessions:
            self.training_sessions[session_id]["metrics"].append({
                "timestamp": time.time(),
                "data": metrics
            })

    def end_training_session(self, session_id: str, final_data: Dict[str, Any]):
        """End training session"""
        if session_id in self.training_sessions:
            session = self.training_sessions[session_id]
            session["end_time"] = time.time()
            session["duration"] = session["end_time"] - session["start_time"]
            session["status"] = "completed"
            session["final_data"] = final_data

            # Update Prometheus metrics if available
            if self.registry and session["duration"]:
                self.training_duration.observe(session["duration"])

            logger.info(f"Ended training session: {session_id}, duration: {session['duration']:.2f}s")

    def get_training_sessions(self) -> Dict[str, Any]:
        """Get all training sessions"""
        return self.training_sessions

    def get_cost_analysis(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """Get cost analysis for training sessions"""
        try:
            if not self.cost_client:
                return {"error": "Azure cost management not available"}

            # Get cost data from Azure
            if session_id and session_id in self.training_sessions:
                session = self.training_sessions[session_id]
                duration_hours = (session.get("duration", 0) / 3600)

                # Estimate costs based on GPU type and duration
                gpu_type = session["config"].get("gpu_type", "unknown")
                cost_per_hour = self._get_gpu_cost_per_hour(gpu_type)
                estimated_cost = duration_hours * cost_per_hour

                return {
                    "session_id": session_id,
                    "duration_hours": duration_hours,
                    "gpu_type": gpu_type,
                    "cost_per_hour": cost_per_hour,
                    "estimated_cost_usd": estimated_cost,
                    "timestamp": datetime.utcnow().isoformat()
                }
            else:
                # Return summary for all sessions
                total_cost = 0
                session_costs = {}

                for sid, session in self.training_sessions.items():
                    if session.get("duration"):
                        duration_hours = session["duration"] / 3600
                        gpu_type = session["config"].get("gpu_type", "unknown")
                        cost_per_hour = self._get_gpu_cost_per_hour(gpu_type)
                        cost = duration_hours * cost_per_hour
                        total_cost += cost
                        session_costs[sid] = cost

                return {
                    "total_estimated_cost_usd": total_cost,
                    "session_costs": session_costs,
                    "currency": "USD",
                    "timestamp": datetime.utcnow().isoformat()
                }

        except Exception as e:
            logger.error(f"Failed to get cost analysis: {e}")
            return {"error": str(e), "timestamp": datetime.utcnow().isoformat()}

    def _get_gpu_cost_per_hour(self, gpu_type: str) -> float:
        """Get cost per hour for GPU type"""
        cost_map = {
            "A100": 4.80,  # $4.80/hour for A100
            "T4": 1.60,    # $1.60/hour for T4
            "V100": 3.20,  # Estimated
            "P100": 2.40,  # Estimated
        }
        return cost_map.get(gpu_type, 2.0)  # Default $2/hour

    def get_system_metrics_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get historical system metrics"""
        return self.system_metrics[-limit:] if self.system_metrics else []

    def get_prometheus_metrics(self) -> Optional[str]:
        """Get Prometheus metrics as string"""
        if self.registry:
            from prometheus_client import generate_latest
            return generate_latest(self.registry).decode('utf-8')
        return None


class CostAnalyzer:
    """Cost analysis utilities"""

    def __init__(self, subscription_id: Optional[str] = None):
        self.subscription_id = subscription_id or os.environ.get("AZURE_SUBSCRIPTION_ID")
        self.cost_client = None

        if AZURE_AVAILABLE and self.subscription_id:
            try:
                credential = DefaultAzureCredential()
                self.cost_client = CostManagementClient(credential, self.subscription_id)
            except Exception as e:
                logger.warning(f"Failed to initialize cost client: {e}")

    def get_azure_costs(self,
                       start_date: Optional[str] = None,
                       end_date: Optional[str] = None,
                       resource_group: Optional[str] = None) -> Dict[str, Any]:
        """
        Get Azure costs for specified period

        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            resource_group: Resource group name

        Returns:
            Cost data dictionary
        """
        if not self.cost_client:
            return {"error": "Azure cost management not configured"}

        try:
            # Set default dates (last 30 days)
            if not start_date:
                start_date = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")
            if not end_date:
                end_date = datetime.utcnow().strftime("%Y-%m-%d")

            # Build query
            query = QueryDefinition(
                type="ActualCost",
                timeframe=TimeframeType.CUSTOM,
                time_period={
                    "from": f"{start_date}T00:00:00Z",
                    "to": f"{end_date}T23:59:59Z"
                },
                dataset={
                    "granularity": GranularityType.DAILY,
                    "aggregation": {
                        "totalCost": {"name": "Cost", "function": "Sum"}
                    }
                }
            )

            if resource_group:
                query.dataset["filter"] = {
                    "dimensions": {
                        "name": "ResourceGroupName",
                        "operator": "In",
                        "values": [resource_group]
                    }
                }

            # Execute query
            result = self.cost_client.query.usage(self.subscription_id, query)

            # Process results
            cost_data = []
            total_cost = 0

            if result.rows:
                for row in result.rows:
                    cost_item = {
                        "date": row[1],  # Date column
                        "cost": float(row[0]),  # Cost column
                        "currency": row[2] if len(row) > 2 else "USD"
                    }
                    cost_data.append(cost_item)
                    total_cost += cost_item["cost"]

            return {
                "total_cost": total_cost,
                "currency": "USD",
                "period": {"start": start_date, "end": end_date},
                "daily_costs": cost_data,
                "resource_group": resource_group,
                "timestamp": datetime.utcnow().isoformat()
            }

        except Exception as e:
            logger.error(f"Failed to get Azure costs: {e}")
            return {"error": str(e), "timestamp": datetime.utcnow().isoformat()}