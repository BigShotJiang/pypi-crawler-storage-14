"""
Command-line interface for Azure GPU Functions
"""

import argparse
import asyncio
import json
import sys
from typing import Optional

from .training import GPUTrainer, EnhancedRayTrainer
from .monitoring import RayMonitor
from .mcp_server import MCPMonitor, RayMCPServer


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description="Azure GPU Functions - GPU-accelerated ML training for Azure",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Train a model with basic configuration
  azure-gpu-trainer train --model gpt2 --data training_data.json --config config.json

  # Start MCP monitoring server
  azure-gpu-trainer monitor --host 0.0.0.0 --port 8765

  # Get system metrics
  azure-gpu-trainer metrics

  # Run enhanced distributed training
  azure-gpu-trainer train-enhanced --model bert-base --data data.json --config config.json
        """
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Train command
    train_parser = subparsers.add_parser("train", help="Train a model")
    train_parser.add_argument("--model", required=True, help="Model name (HuggingFace)")
    train_parser.add_argument("--data", required=True, help="Training data file (JSON)")
    train_parser.add_argument("--config", required=True, help="Training config file (JSON)")
    train_parser.add_argument("--output", help="Output directory")
    train_parser.add_argument("--session-id", help="Training session ID")

    # Enhanced training command
    enhanced_parser = subparsers.add_parser("train-enhanced", help="Enhanced distributed training")
    enhanced_parser.add_argument("--model", required=True, help="Model name")
    enhanced_parser.add_argument("--data", required=True, help="Training data file (JSON)")
    enhanced_parser.add_argument("--config", required=True, help="Training config file (JSON)")
    enhanced_parser.add_argument("--session-id", help="Training session ID")

    # Monitor command
    monitor_parser = subparsers.add_parser("monitor", help="Start MCP monitoring server")
    monitor_parser.add_argument("--host", default="0.0.0.0", help="Server host")
    monitor_parser.add_argument("--port", type=int, default=8765, help="Server port")

    # Metrics command
    metrics_parser = subparsers.add_parser("metrics", help="Get system metrics")
    metrics_parser.add_argument("--format", choices=["json", "text"], default="text",
                               help="Output format")

    # Version command
    subparsers.add_parser("version", help="Show version information")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    try:
        if args.command == "version":
            from . import __version__
            print(f"Azure GPU Functions v{__version__}")

        elif args.command == "train":
            asyncio.run(train_model(args))

        elif args.command == "train-enhanced":
            asyncio.run(train_enhanced(args))

        elif args.command == "monitor":
            asyncio.run(start_monitor(args))

        elif args.command == "metrics":
            asyncio.run(show_metrics(args))

    except KeyboardInterrupt:
        print("\nInterrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


async def train_model(args):
    """Train a model using basic trainer"""
    # Load training data
    with open(args.data, 'r') as f:
        training_data = json.load(f)

    # Load config
    with open(args.config, 'r') as f:
        config = json.load(f)

    # Initialize trainer
    trainer = GPUTrainer()

    print(f"🚀 Starting training for model: {args.model}")
    print(f"📊 Training samples: {len(training_data)}")
    print(f"⚙️ Config: {config}")

    # Train the model
    result = await trainer.train_llm(args.model, training_data, config, args.session_id)

    print("✅ Training completed!")
    print(json.dumps(result, indent=2))


async def train_enhanced(args):
    """Train using enhanced distributed trainer"""
    # Load training data
    with open(args.data, 'r') as f:
        training_data = json.load(f)

    # Load config
    with open(args.config, 'r') as f:
        config = json.load(f)

    # Initialize trainer
    trainer = EnhancedRayTrainer()

    print(f"🚀 Starting enhanced distributed training for model: {args.model}")
    print(f"📊 Training samples: {len(training_data)}")
    print(f"⚙️ Config: {config}")

    # Train the model
    result = await trainer.train_with_ray_distributed_enhanced(config, training_data, args.session_id)

    print("✅ Enhanced training completed!")
    print(json.dumps(result, indent=2))


async def start_monitor(args):
    """Start MCP monitoring server"""
    print(f"🚀 Starting MCP monitoring server on {args.host}:{args.port}")

    server = MCPMonitor(args.host, args.port)
    await server.connect()

    # Start the server
    ray_server = RayMCPServer(args.host, args.port)
    await ray_server.start_server()


async def show_metrics(args):
    """Show system metrics"""
    monitor = RayMonitor()
    metrics = monitor.collect_system_metrics()

    if args.format == "json":
        print(json.dumps(metrics, indent=2))
    else:
        print("📊 System Metrics")
        print(f"CPU Usage: {metrics['cpu']['cpu_usage_percent']:.1f}%")
        print(f"Memory Usage: {metrics['memory']['memory_percent']:.1f}%")
        print(f"Disk Usage: {metrics['disk']['disk_percent']:.1f}%")

        if metrics['gpu']:
            print(f"GPU Count: {len(metrics['gpu'])}")
            for i, gpu in enumerate(metrics['gpu']):
                print(f"  GPU {i}: {gpu['name']} - {gpu['load']:.1f}% load, {gpu['memory_util']:.1f}% memory")
        else:
            print("No GPUs detected")


if __name__ == "__main__":
    main()