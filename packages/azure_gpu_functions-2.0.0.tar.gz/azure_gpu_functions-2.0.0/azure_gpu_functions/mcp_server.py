"""
MCP Server Module for Azure GPU Functions
Provides monitoring and control capabilities via WebSocket connections.
"""

import asyncio
import json
import logging
import websockets
from typing import Dict, List, Optional, Any
from datetime import datetime
import os
from dataclasses import asdict

# Local imports
get_ray_monitor = None
CostAnalyzer = None

try:
    from .monitoring import RayMonitor, CostAnalyzer
    get_ray_monitor = None  # Not available in this import
except ImportError:
    try:
        from ray_monitor import get_ray_monitor, CostAnalyzer
    except ImportError:
        get_ray_monitor = None
        CostAnalyzer = None

logger = logging.getLogger(__name__)


class RayMCPServer:
    """Ray MCP Server for monitoring and control via WebSocket"""

    def __init__(self, host: str = "0.0.0.0", port: int = 8765):
        self.host = host
        self.port = port
        self.connected_clients = set()
        self.monitor_actor = None
        self.training_sessions = {}

        # MCP capabilities
        self.capabilities = {
            "monitoring": {
                "system_metrics": True,
                "gpu_metrics": True,
                "training_sessions": True,
                "cost_analysis": True,
            },
            "control": {
                "start_training": True,
                "stop_training": True,
                "scale_resources": True,
            },
            "analytics": {
                "performance_analysis": True,
                "cost_optimization": True,
                "resource_utilization": True,
            }
        }

        # Initialize monitor
        try:
            if get_ray_monitor:
                self.monitor_actor = get_ray_monitor()
        except Exception as e:
            logger.warning(f"Failed to initialize Ray monitor: {e}")

        # Initialize inference service
        self.inference_service = None
        try:
            from .inference import InferenceService
            self.inference_service = InferenceService()
            logger.info("Inference service initialized")
        except Exception as e:
            logger.warning(f"Failed to initialize inference service: {e}")

    async def start_server(self):
        """Start the MCP WebSocket server"""
        try:
            server = await websockets.serve(
                self.handle_client,
                self.host,
                self.port
            )
            logger.info(f"MCP Server started on ws://{self.host}:{self.port}")
            await server.wait_closed()
        except Exception as e:
            logger.error(f"Failed to start MCP server: {e}")
            raise

    async def handle_client(self, websocket, path):
        """Handle individual client connections"""
        self.connected_clients.add(websocket)
        try:
            async for message in websocket:
                try:
                    data = json.loads(message)
                    response = await self.process_message(data)
                    await websocket.send(json.dumps(response))
                except json.JSONDecodeError:
                    await websocket.send(json.dumps({
                        "error": "Invalid JSON message",
                        "timestamp": datetime.utcnow().isoformat()
                    }))
                except Exception as e:
                    logger.error(f"Error processing message: {e}")
                    await websocket.send(json.dumps({
                        "error": str(e),
                        "timestamp": datetime.utcnow().isoformat()
                    }))
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.connected_clients.remove(websocket)

    async def process_message(self, message: Dict[str, Any]) -> Dict[str, Any]:
        """Process incoming MCP messages"""
        message_type = message.get("type", "")
        request_id = message.get("id", "unknown")

        try:
            if message_type == "get_system_metrics":
                return await self._get_system_metrics(request_id)

            elif message_type == "get_training_sessions":
                return await self._get_training_sessions(request_id)

            elif message_type == "start_training_session":
                return await self._start_training_session(message, request_id)

            elif message_type == "update_training_session":
                return await self._update_training_session(message, request_id)

            elif message_type == "end_training_session":
                return await self._end_training_session(message, request_id)

            elif message_type == "get_cost_analysis":
                return await self._get_cost_analysis(message, request_id)

            elif message_type == "check_ports":
                return await self._check_ports(message, request_id)

            elif message_type == "get_port_status":
                return await self._get_port_status(message, request_id)

            elif message_type == "get_dashboard_data":
                return await self._get_dashboard_data(request_id)

            elif message_type == "execute_command":
                return await self._execute_command(message, request_id)

            elif message_type == "submit_batch_operations":
                return await self._submit_batch_operations(message, request_id)

            elif message_type == "get_batch_status":
                return await self._get_batch_status(message, request_id)

            elif message_type == "get_batch_status_batch":
                return await self._get_batch_status_batch(message, request_id)

            elif message_type == "estimate_cost":
                return await self._estimate_cost(message, request_id)

            elif message_type == "get_cost_history":
                return await self._get_cost_history(message, request_id)

            elif message_type == "create_budget":
                return await self._create_budget(message, request_id)

            elif message_type == "get_budget_status":
                return await self._get_budget_status(message, request_id)

            elif message_type == "register_model":
                return await self._register_model(message, request_id)

            elif message_type == "list_models":
                return await self._list_models(message, request_id)

            elif message_type == "download_model":
                return await self._download_model(message, request_id)

            elif message_type == "get_model_metadata":
                return await self._get_model_metadata(message, request_id)

            elif message_type == "run_inference":
                return await self._run_inference(message, request_id)

            elif message_type == "run_batch_inference":
                return await self._run_batch_inference(message, request_id)

            elif message_type == "get_inference_stats":
                return await self._get_inference_stats(message, request_id)

            elif message_type == "preload_model":
                return await self._preload_model(message, request_id)

            elif message_type == "get_capabilities":
                return self._get_capabilities(request_id)

            elif message_type == "ping":
                return {"type": "pong", "id": request_id, "timestamp": datetime.utcnow().isoformat()}

            else:
                return {
                    "error": f"Unknown message type: {message_type}",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

        except Exception as e:
            logger.error(f"Error processing message type {message_type}: {e}")
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_system_metrics(self, request_id: str) -> Dict[str, Any]:
        """Get system metrics"""
        try:
            if self.monitor_actor:
                metrics = await self.monitor_actor.get_system_metrics.remote()
            else:
                # Fallback metrics
                import psutil
                metrics = {
                    "cpu_percent": psutil.cpu_percent(interval=1),
                    "memory_percent": psutil.virtual_memory().percent,
                    "disk_usage": psutil.disk_usage('/').percent,
                    "timestamp": datetime.utcnow().isoformat()
                }

            return {
                "type": "system_metrics",
                "id": request_id,
                "data": metrics,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_training_sessions(self, request_id: str) -> Dict[str, Any]:
        """Get active training sessions"""
        return {
            "type": "training_sessions",
            "id": request_id,
            "data": self.training_sessions,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _start_training_session(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Start a new training session"""
        session_id = message.get("session_id", "")
        config = message.get("config", {})

        if session_id:
            self.training_sessions[session_id] = {
                "config": config,
                "status": "active",
                "start_time": datetime.utcnow().isoformat(),
                "metrics": []
            }

        return {
            "type": "training_session_started",
            "id": request_id,
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _update_training_session(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Update training session metrics"""
        session_id = message.get("session_id", "")
        metrics = message.get("metrics", {})

        if session_id in self.training_sessions:
            self.training_sessions[session_id]["metrics"].append({
                "data": metrics,
                "timestamp": datetime.utcnow().isoformat()
            })

        return {
            "type": "training_session_updated",
            "id": request_id,
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _end_training_session(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """End a training session"""
        session_id = message.get("session_id", "")
        final_data = message.get("final_data", {})

        if session_id in self.training_sessions:
            self.training_sessions[session_id]["status"] = "completed"
            self.training_sessions[session_id]["end_time"] = datetime.utcnow().isoformat()
            self.training_sessions[session_id]["final_data"] = final_data

        return {
            "type": "training_session_ended",
            "id": request_id,
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _get_cost_analysis(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get cost analysis"""
        try:
            if self.monitor_actor and CostAnalyzer:
                session_id = message.get("session_id", "")
                cost_data = await self.monitor_actor.get_cost_analysis.remote(session_id)
            else:
                cost_data = {"error": "Cost analysis not available"}

            return {
                "type": "cost_analysis",
                "id": request_id,
                "data": cost_data,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _check_ports(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Check port availability"""
        try:
            from .utils.port_manager import PortManager
            services = message.get("services", [])
            port_status = PortManager.check_service_ports(services)

            return {
                "type": "port_status",
                "id": request_id,
                "data": port_status,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": f"Port checking not available: {str(e)}",
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_port_status(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get detailed port status"""
        try:
            from .utils.port_manager import PortManager, PortHealthChecker

            host = message.get("host", "localhost")
            port = message.get("port")
            health_endpoint = message.get("health_endpoint")

            if port is None:
                return {
                    "error": "Port number required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            # Check basic port status
            is_open = PortManager.is_port_open(host, int(port))
            process_info = PortManager.get_port_process(int(port)) if is_open else None

            # Check health if endpoint provided
            health_checker = PortHealthChecker()
            health_status = None
            if health_endpoint:
                health_status = health_checker.check_service_health(
                    f"{host}:{port}", host, int(port), health_endpoint
                )

            return {
                "type": "port_details",
                "id": request_id,
                "data": {
                    "host": host,
                    "port": port,
                    "open": is_open,
                    "process": process_info,
                    "health": health_status
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_dashboard_data(self, request_id: str) -> Dict[str, Any]:
        """Get comprehensive dashboard data"""
        try:
            from .dashboard import get_enhanced_dashboard

            dashboard = get_enhanced_dashboard()
            dashboard_data = dashboard.get_dashboard_data()

            return {
                "type": "dashboard_data",
                "id": request_id,
                "data": dashboard_data,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": f"Dashboard data not available: {str(e)}",
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _execute_command(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Execute a command through the command center"""
        try:
            from .dashboard import get_enhanced_dashboard

            command = message.get("command", "")
            args = message.get("args", {})

            if not command:
                return {
                    "error": "Command required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            dashboard = get_enhanced_dashboard()
            command_id = dashboard.command_center.execute_command(command, args)

            return {
                "type": "command_started",
                "id": request_id,
                "command_id": command_id,
                "command": command,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    def _get_capabilities(self, request_id: str) -> Dict[str, Any]:
        """Get MCP server capabilities"""
        # Update capabilities to include new features
        enhanced_capabilities = self.capabilities.copy()
        enhanced_capabilities.update({
            "port_management": {
                "check_ports": True,
                "get_port_status": True,
                "port_health_check": True,
            },
            "dashboard": {
                "get_dashboard_data": True,
                "real_time_metrics": True,
            },
            "command_center": {
                "execute_command": True,
                "command_history": True,
            },
            "batch_processing": {
                "submit_batch_operations": True,
                "get_batch_status": True,
                "get_batch_status_batch": True,
            },
            "cost_management": {
                "estimate_cost": True,
                "get_cost_history": True,
                "create_budget": True,
                "get_budget_status": True,
            },
            "model_registry": {
                "register_model": True,
                "list_models": True,
                "download_model": True,
                "get_model_metadata": True,
            },
            "inference": {
                "run_inference": True,
                "run_batch_inference": True,
                "get_inference_stats": True,
                "preload_model": True,
                "model_caching": True,
                "parallel_processing": True,
            }
        })

        return {
            "type": "capabilities",
            "id": request_id,
            "data": enhanced_capabilities,
            "server_info": {
                "name": "Enhanced Ray MCP Server for Azure GPU Functions",
                "version": "2.0.0",
                "features": ["port_management", "dashboard", "command_center", "ray_integration", "batch_processing", "cost_management", "model_registry"],
                "host": self.host,
                "port": self.port
            },
            "timestamp": datetime.utcnow().isoformat()
        }

    async def _submit_batch_operations(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Submit batch operations for processing"""
        try:
            from .batch_processor import submit_batch_operations

            operations = message.get("operations", [])
            if not operations:
                return {
                    "error": "Operations list required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            batch_id = submit_batch_operations(operations)

            return {
                "type": "batch_submitted",
                "id": request_id,
                "batch_id": batch_id,
                "operation_count": len(operations),
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_batch_status(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get status of a batch operation"""
        try:
            from .batch_processor import batch_processor

            batch_id = message.get("batch_id")
            if not batch_id:
                return {
                    "error": "Batch ID required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            status = batch_processor.get_batch_status(batch_id)
            if not status:
                return {
                    "error": f"Batch {batch_id} not found",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            return {
                "type": "batch_status",
                "id": request_id,
                "data": status,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_batch_status_batch(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get status of multiple batch operations"""
        try:
            from .batch_processor import get_batch_operations_status

            batch_ids = message.get("batch_ids", [])
            if not batch_ids:
                return {
                    "error": "Batch IDs list required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            status_batch = get_batch_operations_status(batch_ids)

            return {
                "type": "batch_status_batch",
                "id": request_id,
                "data": status_batch,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _estimate_cost(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Estimate cost for a training job"""
        try:
            from .cost_management import CostEstimator

            estimator = CostEstimator()
            estimate = estimator.estimate_cost(
                model_name=message.get("model_name", "unknown"),
                epochs=message.get("epochs", 10),
                batch_size=message.get("batch_size", 32),
                model_size_gb=message.get("model_size_gb", 1.0),
                gpu_type=message.get("gpu_type", "V100")
            )

            return {
                "type": "cost_estimate",
                "id": request_id,
                "data": asdict(estimate),
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_cost_history(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get cost history"""
        try:
            from .cost_management import CostEstimator

            estimator = CostEstimator()
            team_id = message.get("team_id")
            model_name = message.get("model_name")
            limit = message.get("limit", 100)

            history = estimator.get_cost_history(team_id=team_id, model_name=model_name, limit=limit)

            return {
                "type": "cost_history",
                "id": request_id,
                "data": [asdict(h) for h in history],
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _create_budget(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Create a budget for a team"""
        try:
            from .cost_management import BudgetManager

            manager = BudgetManager()
            budget = manager.create_budget(
                team_id=message["team_id"],
                name=message["name"],
                total_budget=message["total_budget"],
                period_days=message.get("period_days", 30)
            )

            return {
                "type": "budget_created",
                "id": request_id,
                "data": asdict(budget),
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_budget_status(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get budget status for a team"""
        try:
            from .cost_management import BudgetManager

            manager = BudgetManager()
            team_id = message.get("team_id", "default")
            status, ratio, alerts = manager.check_budget_status(team_id)

            return {
                "type": "budget_status",
                "id": request_id,
                "data": {
                    "team_id": team_id,
                    "status": status.value,
                    "usage_ratio": ratio,
                    "alerts": alerts
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _register_model(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Register a model in the registry"""
        try:
            from .model_registry import ModelRegistry, ModelType

            registry = ModelRegistry()
            metadata = registry.register_model(
                name=message["name"],
                model_type=ModelType(message["model_type"]),
                framework=message["framework"],
                architecture=message["architecture"],
                model_path=message["model_path"],
                created_by=message.get("created_by", "system"),
                description=message.get("description", ""),
                tags=message.get("tags", []),
                performance_metrics=message.get("performance_metrics", {}),
                training_config=message.get("training_config", {}),
                dependencies=message.get("dependencies", [])
            )

            return {
                "type": "model_registered",
                "id": request_id,
                "data": asdict(metadata),
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _list_models(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """List models in the registry"""
        try:
            from .model_registry import ModelRegistry, ModelType, ModelStatus

            registry = ModelRegistry()

            # Parse filters
            model_type = ModelType(message["model_type"]) if "model_type" in message else None
            framework = message.get("framework")
            tags = message.get("tags", [])
            status = ModelStatus(message["status"]) if "status" in message else None

            models = registry.list_models(
                model_type=model_type,
                framework=framework,
                tags=tags,
                status=status
            )

            return {
                "type": "models_list",
                "id": request_id,
                "data": [asdict(model) for model in models],
                "count": len(models),
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _download_model(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Download a model from the registry"""
        try:
            from .model_registry import ModelRegistry

            registry = ModelRegistry()
            download_path = registry.download_model(
                model_id=message["model_id"],
                version=message.get("version"),
                download_path=message.get("download_path"),
                downloaded_by=message.get("downloaded_by", "system"),
                purpose=message.get("purpose", "inference")
            )

            return {
                "type": "model_downloaded",
                "id": request_id,
                "data": {
                    "model_id": message["model_id"],
                    "version": message.get("version", "latest"),
                    "download_path": download_path,
                    "downloaded_at": datetime.utcnow().isoformat()
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _run_inference(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Run inference on a model"""
        try:
            if not self.inference_service:
                return {
                    "error": "Inference service not available",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            model_id = message.get("model_id")
            input_data = message.get("input_data")
            parameters = message.get("parameters", {})

            if not model_id or input_data is None:
                return {
                    "error": "Model ID and input data required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            result = await self.inference_service.run_inference(
                model_id=model_id,
                input_data=input_data,
                parameters=parameters
            )

            return {
                "type": "inference_result",
                "id": request_id,
                "data": result,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _run_batch_inference(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Run batch inference on a model"""
        try:
            if not self.inference_service:
                return {
                    "error": "Inference service not available",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            model_id = message.get("model_id")
            input_batch = message.get("input_batch", [])
            parameters = message.get("parameters", {})

            if not model_id or not input_batch:
                return {
                    "error": "Model ID and input batch required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            results = await self.inference_service.run_batch_inference(
                model_id=model_id,
                input_batch=input_batch,
                parameters=parameters
            )

            return {
                "type": "batch_inference_result",
                "id": request_id,
                "data": results,
                "batch_size": len(input_batch),
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _get_inference_stats(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Get inference statistics"""
        try:
            if not self.inference_service:
                return {
                    "error": "Inference service not available",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            model_id = message.get("model_id")
            stats = self.inference_service.get_inference_stats(model_id=model_id)

            return {
                "type": "inference_stats",
                "id": request_id,
                "data": stats,
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }

    async def _preload_model(self, message: Dict[str, Any], request_id: str) -> Dict[str, Any]:
        """Preload a model for faster inference"""
        try:
            if not self.inference_service:
                return {
                    "error": "Inference service not available",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            model_id = message.get("model_id")
            if not model_id:
                return {
                    "error": "Model ID required",
                    "id": request_id,
                    "timestamp": datetime.utcnow().isoformat()
                }

            success = await self.inference_service.preload_model(model_id=model_id)

            return {
                "type": "model_preloaded",
                "id": request_id,
                "data": {
                    "model_id": model_id,
                    "success": success
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            return {
                "error": str(e),
                "id": request_id,
                "timestamp": datetime.utcnow().isoformat()
            }


class MCPMonitor:
    """Simplified MCP monitoring interface"""

    def __init__(self, host: str = "localhost", port: int = 8765):
        self.host = host
        self.port = port
        self.websocket = None
        self.connected = False

    async def connect(self):
        """Connect to MCP server"""
        try:
            uri = f"ws://{self.host}:{self.port}"
            self.websocket = await websockets.connect(uri)
            self.connected = True
            logger.info(f"Connected to MCP server at {uri}")
        except Exception as e:
            logger.error(f"Failed to connect to MCP server: {e}")
            self.connected = False

    async def disconnect(self):
        """Disconnect from MCP server"""
        if self.websocket:
            await self.websocket.close()
            self.connected = False

    async def send_message(self, message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Send message to MCP server"""
        if not self.connected:
            await self.connect()

        if self.websocket:
            try:
                await self.websocket.send(json.dumps(message))
                response = await self.websocket.recv()
                return json.loads(response)
            except Exception as e:
                logger.error(f"Failed to send message: {e}")
                return None
        return None

    async def start_training_session(self, session_id: str, config: Dict[str, Any]):
        """Start training session"""
        message = {
            "type": "start_training_session",
            "id": f"start_{session_id}",
            "session_id": session_id,
            "config": config
        }
        return await self.send_message(message)

    async def update_training_session(self, session_id: str, metrics: Dict[str, Any]):
        """Update training session metrics"""
        message = {
            "type": "update_training_session",
            "id": f"update_{session_id}",
            "session_id": session_id,
            "metrics": metrics
        }
        return await self.send_message(message)

    async def end_training_session(self, session_id: str, final_data: Dict[str, Any]):
        """End training session"""
        message = {
            "type": "end_training_session",
            "id": f"end_{session_id}",
            "session_id": session_id,
            "final_data": final_data
        }
        return await self.send_message(message)

    async def get_system_metrics(self):
        """Get system metrics"""
        message = {
            "type": "get_system_metrics",
            "id": "metrics_request"
        }
        response = await self.send_message(message)
        return response.get("data") if response else None

    async def get_capabilities(self):
        """Get MCP server capabilities"""
        message = {
            "type": "get_capabilities",
            "id": "capabilities_request"
        }
        response = await self.send_message(message)
        return response.get("data") if response else None