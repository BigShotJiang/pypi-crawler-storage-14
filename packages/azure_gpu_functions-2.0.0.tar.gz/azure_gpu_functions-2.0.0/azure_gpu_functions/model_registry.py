"""
Model Registry and Management System for Azure GPU Functions
Manages pretrained and custom models with versioning, metadata, and lifecycle management.
"""

import asyncio
import json
import logging
import os
import shutil
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import sqlite3
import threading
from pathlib import Path

logger = logging.getLogger(__name__)

class ModelType(Enum):
    PRETRAINED = "pretrained"
    CUSTOM = "custom"
    FINE_TUNED = "fine_tuned"

class ModelStatus(Enum):
    AVAILABLE = "available"
    TRAINING = "training"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"

@dataclass
class ModelMetadata:
    """Metadata for a model"""
    model_id: str
    name: str
    version: str
    model_type: ModelType
    status: ModelStatus
    framework: str  # pytorch, tensorflow, etc.
    architecture: str  # bert, gpt, resnet, etc.
    size_bytes: int
    size_gb: float
    created_at: datetime
    updated_at: datetime
    created_by: str
    description: str = ""
    tags: List[str] = None
    performance_metrics: Dict[str, Any] = None
    training_config: Dict[str, Any] = None
    dependencies: List[str] = None
    checksum: str = ""

    def __post_init__(self):
        if self.tags is None:
            self.tags = []
        if self.performance_metrics is None:
            self.performance_metrics = {}
        if self.training_config is None:
            self.training_config = {}
        if self.dependencies is None:
            self.dependencies = []

@dataclass
class ModelVersion:
    """Model version information"""
    model_id: str
    version: str
    parent_version: Optional[str]
    created_at: datetime
    changes: str = ""
    performance_delta: Dict[str, float] = None

    def __post_init__(self):
        if self.performance_delta is None:
            self.performance_delta = {}

class ModelRegistry:
    """Registry for managing models and their metadata"""

    def __init__(self, storage_path: str = "model_storage", db_path: str = "model_registry.db"):
        self.storage_path = Path(storage_path)
        self.db_path = db_path
        self.storage_path.mkdir(exist_ok=True)
        self._init_db()
        self._lock = threading.Lock()

    def _init_db(self):
        """Initialize SQLite database for model registry"""
        with sqlite3.connect(self.db_path) as conn:
            # Models table
            conn.execute('''
                CREATE TABLE IF NOT EXISTS models (
                    model_id TEXT PRIMARY KEY,
                    name TEXT,
                    version TEXT,
                    model_type TEXT,
                    status TEXT,
                    framework TEXT,
                    architecture TEXT,
                    size_bytes INTEGER,
                    size_gb REAL,
                    created_at TEXT,
                    updated_at TEXT,
                    created_by TEXT,
                    description TEXT,
                    tags TEXT,
                    performance_metrics TEXT,
                    training_config TEXT,
                    dependencies TEXT,
                    checksum TEXT
                )
            ''')

            # Versions table
            conn.execute('''
                CREATE TABLE IF NOT EXISTS versions (
                    model_id TEXT,
                    version TEXT,
                    parent_version TEXT,
                    created_at TEXT,
                    changes TEXT,
                    performance_delta TEXT,
                    PRIMARY KEY (model_id, version)
                )
            ''')

            # Downloads table for tracking usage
            conn.execute('''
                CREATE TABLE IF NOT EXISTS downloads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    model_id TEXT,
                    version TEXT,
                    downloaded_by TEXT,
                    downloaded_at TEXT,
                    purpose TEXT
                )
            ''')

            conn.commit()

    def register_model(self, name: str, model_type: ModelType, framework: str,
                      architecture: str, model_path: str, created_by: str,
                      description: str = "", tags: List[str] = None,
                      performance_metrics: Dict[str, Any] = None,
                      training_config: Dict[str, Any] = None,
                      dependencies: List[str] = None) -> ModelMetadata:
        """
        Register a new model in the registry

        Args:
            name: Model name
            model_type: Type of model (pretrained, custom, fine_tuned)
            framework: ML framework (pytorch, tensorflow, etc.)
            architecture: Model architecture (bert, gpt, resnet, etc.)
            model_path: Path to the model file
            created_by: User/team who created the model
            description: Model description
            tags: List of tags for categorization
            performance_metrics: Model performance metrics
            training_config: Training configuration used
            dependencies: List of dependencies

        Returns:
            ModelMetadata object
        """
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file not found: {model_path}")

        # Calculate file size and checksum
        size_bytes = os.path.getsize(model_path)
        size_gb = size_bytes / (1024**3)

        with open(model_path, 'rb') as f:
            checksum = hashlib.sha256(f.read()).hexdigest()

        # Generate model ID and initial version
        model_id = f"{name.lower().replace(' ', '_')}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
        version = "1.0.0"

        # Copy model to storage
        storage_dir = self.storage_path / model_id / version
        storage_dir.mkdir(parents=True, exist_ok=True)
        storage_path = storage_dir / f"{name}.model"

        shutil.copy2(model_path, storage_path)

        # Create metadata
        metadata = ModelMetadata(
            model_id=model_id,
            name=name,
            version=version,
            model_type=model_type,
            status=ModelStatus.AVAILABLE,
            framework=framework,
            architecture=architecture,
            size_bytes=size_bytes,
            size_gb=size_gb,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            created_by=created_by,
            description=description,
            tags=tags or [],
            performance_metrics=performance_metrics or {},
            training_config=training_config or {},
            dependencies=dependencies or [],
            checksum=checksum
        )

        # Save to database
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    INSERT INTO models VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    metadata.model_id,
                    metadata.name,
                    metadata.version,
                    metadata.model_type.value,
                    metadata.status.value,
                    metadata.framework,
                    metadata.architecture,
                    metadata.size_bytes,
                    metadata.size_gb,
                    metadata.created_at.isoformat(),
                    metadata.updated_at.isoformat(),
                    metadata.created_by,
                    metadata.description,
                    json.dumps(metadata.tags),
                    json.dumps(metadata.performance_metrics),
                    json.dumps(metadata.training_config),
                    json.dumps(metadata.dependencies),
                    metadata.checksum
                ))

                # Create version entry
                conn.execute('''
                    INSERT INTO versions VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    model_id,
                    version,
                    None,  # No parent version for initial version
                    metadata.created_at.isoformat(),
                    "Initial version",
                    json.dumps({})
                ))

                conn.commit()

        logger.info(f"Registered model {model_id} v{version}: {name}")
        return metadata

    def update_model_version(self, model_id: str, new_model_path: str,
                           changes: str = "", performance_delta: Dict[str, float] = None,
                           updated_by: str = "system") -> ModelMetadata:
        """
        Create a new version of an existing model

        Args:
            model_id: ID of the model to update
            new_model_path: Path to the new model file
            changes: Description of changes
            performance_delta: Performance changes compared to previous version
            updated_by: User who updated the model

        Returns:
            Updated ModelMetadata
        """
        # Get current metadata
        current_metadata = self.get_model_metadata(model_id)
        if not current_metadata:
            raise ValueError(f"Model {model_id} not found")

        # Calculate new version
        current_version_parts = current_metadata.version.split('.')
        new_version = f"{current_version_parts[0]}.{current_version_parts[1]}.{int(current_version_parts[2]) + 1}"

        # Calculate file size and checksum
        size_bytes = os.path.getsize(new_model_path)
        size_gb = size_bytes / (1024**3)

        with open(new_model_path, 'rb') as f:
            checksum = hashlib.sha256(f.read()).hexdigest()

        # Copy model to storage
        storage_dir = self.storage_path / model_id / new_version
        storage_dir.mkdir(parents=True, exist_ok=True)
        storage_path = storage_dir / f"{current_metadata.name}.model"

        shutil.copy2(new_model_path, storage_path)

        # Update metadata
        current_metadata.version = new_version
        current_metadata.size_bytes = size_bytes
        current_metadata.size_gb = size_gb
        current_metadata.updated_at = datetime.utcnow()
        current_metadata.checksum = checksum

        if performance_delta:
            # Update performance metrics with deltas
            for key, delta in performance_delta.items():
                if key in current_metadata.performance_metrics:
                    current_metadata.performance_metrics[key] += delta
                else:
                    current_metadata.performance_metrics[key] = delta

        # Save to database
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    UPDATE models SET
                        version = ?, size_bytes = ?, size_gb = ?, updated_at = ?,
                        performance_metrics = ?, checksum = ?
                    WHERE model_id = ?
                ''', (
                    new_version,
                    size_bytes,
                    size_gb,
                    current_metadata.updated_at.isoformat(),
                    json.dumps(current_metadata.performance_metrics),
                    checksum,
                    model_id
                ))

                # Create version entry
                conn.execute('''
                    INSERT INTO versions VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    model_id,
                    new_version,
                    current_metadata.version,
                    current_metadata.updated_at.isoformat(),
                    changes,
                    json.dumps(performance_delta or {})
                ))

                conn.commit()

        logger.info(f"Updated model {model_id} to version {new_version}")
        return current_metadata

    def get_model_metadata(self, model_id: str) -> Optional[ModelMetadata]:
        """Get metadata for a specific model"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute('SELECT * FROM models WHERE model_id = ?', (model_id,))
            row = cursor.fetchone()
            if row:
                return ModelMetadata(
                    model_id=row[0],
                    name=row[1],
                    version=row[2],
                    model_type=ModelType(row[3]),
                    status=ModelStatus(row[4]),
                    framework=row[5],
                    architecture=row[6],
                    size_bytes=row[7],
                    size_gb=row[8],
                    created_at=datetime.fromisoformat(row[9]),
                    updated_at=datetime.fromisoformat(row[10]),
                    created_by=row[11],
                    description=row[12],
                    tags=json.loads(row[13]),
                    performance_metrics=json.loads(row[14]),
                    training_config=json.loads(row[15]),
                    dependencies=json.loads(row[16]),
                    checksum=row[17]
                )
        return None

    def list_models(self, model_type: Optional[ModelType] = None,
                   framework: Optional[str] = None, tags: List[str] = None,
                   status: Optional[ModelStatus] = None) -> List[ModelMetadata]:
        """List models with optional filtering"""
        query = "SELECT * FROM models WHERE 1=1"
        params = []

        if model_type:
            query += " AND model_type = ?"
            params.append(model_type.value)

        if framework:
            query += " AND framework = ?"
            params.append(framework)

        if status:
            query += " AND status = ?"
            params.append(status.value)

        query += " ORDER BY updated_at DESC"

        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute(query, params)
            models = []
            for row in cursor.fetchall():
                model = ModelMetadata(
                    model_id=row[0],
                    name=row[1],
                    version=row[2],
                    model_type=ModelType(row[3]),
                    status=ModelStatus(row[4]),
                    framework=row[5],
                    architecture=row[6],
                    size_bytes=row[7],
                    size_gb=row[8],
                    created_at=datetime.fromisoformat(row[9]),
                    updated_at=datetime.fromisoformat(row[10]),
                    created_by=row[11],
                    description=row[12],
                    tags=json.loads(row[13]),
                    performance_metrics=json.loads(row[14]),
                    training_config=json.loads(row[15]),
                    dependencies=json.loads(row[16]),
                    checksum=row[17]
                )

                # Filter by tags if specified
                if tags:
                    if not any(tag in model.tags for tag in tags):
                        continue

                models.append(model)

            return models

    def download_model(self, model_id: str, version: Optional[str] = None,
                      download_path: Optional[str] = None, downloaded_by: str = "system",
                      purpose: str = "inference") -> str:
        """
        Download a model from the registry

        Args:
            model_id: ID of the model to download
            version: Specific version to download (latest if None)
            download_path: Path to download to (auto-generated if None)
            downloaded_by: User downloading the model
            purpose: Purpose of download

        Returns:
            Path to downloaded model file
        """
        metadata = self.get_model_metadata(model_id)
        if not metadata:
            raise ValueError(f"Model {model_id} not found")

        # Use specified version or latest
        target_version = version or metadata.version

        # Check if version exists
        storage_dir = self.storage_path / model_id / target_version
        if not storage_dir.exists():
            raise ValueError(f"Version {target_version} not found for model {model_id}")

        model_file = storage_dir / f"{metadata.name}.model"
        if not model_file.exists():
            raise ValueError(f"Model file not found for {model_id} v{target_version}")

        # Generate download path
        if download_path is None:
            download_dir = Path("downloads") / model_id / target_version
            download_dir.mkdir(parents=True, exist_ok=True)
            download_path = download_dir / f"{metadata.name}_v{target_version}.model"

        # Copy model file
        shutil.copy2(model_file, download_path)

        # Record download
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    INSERT INTO downloads (model_id, version, downloaded_by, downloaded_at, purpose)
                    VALUES (?, ?, ?, ?, ?)
                ''', (
                    model_id,
                    target_version,
                    downloaded_by,
                    datetime.utcnow().isoformat(),
                    purpose
                ))
                conn.commit()

        logger.info(f"Downloaded model {model_id} v{target_version} to {download_path}")
        return str(download_path)

    def get_model_versions(self, model_id: str) -> List[ModelVersion]:
        """Get all versions of a model"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute('SELECT * FROM versions WHERE model_id = ? ORDER BY created_at DESC',
                                (model_id,))
            versions = []
            for row in cursor.fetchall():
                versions.append(ModelVersion(
                    model_id=row[0],
                    version=row[1],
                    parent_version=row[2],
                    created_at=datetime.fromisoformat(row[3]),
                    changes=row[4],
                    performance_delta=json.loads(row[5])
                ))
            return versions

    def update_model_status(self, model_id: str, status: ModelStatus):
        """Update the status of a model"""
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('''
                    UPDATE models SET status = ?, updated_at = ? WHERE model_id = ?
                ''', (status.value, datetime.utcnow().isoformat(), model_id))
                conn.commit()

        logger.info(f"Updated model {model_id} status to {status.value}")

    def delete_model(self, model_id: str, force: bool = False):
        """
        Delete a model from the registry

        Args:
            model_id: ID of the model to delete
            force: Force deletion even if model is in use
        """
        metadata = self.get_model_metadata(model_id)
        if not metadata:
            raise ValueError(f"Model {model_id} not found")

        # Check if model is being used (has recent downloads)
        if not force:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute('''
                    SELECT COUNT(*) FROM downloads
                    WHERE model_id = ? AND downloaded_at > ?
                ''', (model_id, (datetime.utcnow() - timedelta(days=30)).isoformat()))
                recent_downloads = cursor.fetchone()[0]
                if recent_downloads > 0:
                    raise ValueError(f"Model {model_id} has {recent_downloads} recent downloads. Use force=True to delete.")

        # Delete from storage
        model_dir = self.storage_path / model_id
        if model_dir.exists():
            shutil.rmtree(model_dir)

        # Delete from database
        with self._lock:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute('DELETE FROM models WHERE model_id = ?', (model_id,))
                conn.execute('DELETE FROM versions WHERE model_id = ?', (model_id,))
                conn.execute('DELETE FROM downloads WHERE model_id = ?', (model_id,))
                conn.commit()

        logger.info(f"Deleted model {model_id}")

    def get_registry_stats(self) -> Dict[str, Any]:
        """Get statistics about the model registry"""
        with sqlite3.connect(self.db_path) as conn:
            # Model counts by type
            cursor = conn.execute('SELECT model_type, COUNT(*) FROM models GROUP BY model_type')
            type_counts = {row[0]: row[1] for row in cursor.fetchall()}

            # Model counts by status
            cursor = conn.execute('SELECT status, COUNT(*) FROM models GROUP BY status')
            status_counts = {row[0]: row[1] for row in cursor.fetchall()}

            # Total storage used
            cursor = conn.execute('SELECT SUM(size_bytes) FROM models')
            total_size_bytes = cursor.fetchone()[0] or 0
            total_size_gb = total_size_bytes / (1024**3)

            # Download statistics
            cursor = conn.execute('SELECT COUNT(*), COUNT(DISTINCT model_id) FROM downloads')
            total_downloads, unique_models_downloaded = cursor.fetchone()

            # Recent downloads (last 30 days)
            thirty_days_ago = (datetime.utcnow() - timedelta(days=30)).isoformat()
            cursor = conn.execute('SELECT COUNT(*) FROM downloads WHERE downloaded_at > ?', (thirty_days_ago,))
            recent_downloads = cursor.fetchone()[0]

        return {
            "total_models": sum(type_counts.values()),
            "models_by_type": type_counts,
            "models_by_status": status_counts,
            "total_storage_gb": total_size_gb,
            "total_downloads": total_downloads,
            "unique_models_downloaded": unique_models_downloaded,
            "recent_downloads": recent_downloads
        }

    def search_models(self, query: str, limit: int = 50) -> List[ModelMetadata]:
        """Search models by name, description, or tags"""
        query_lower = query.lower()
        all_models = self.list_models()

        matching_models = []
        for model in all_models:
            if (query_lower in model.name.lower() or
                query_lower in model.description.lower() or
                any(query_lower in tag.lower() for tag in model.tags)):
                matching_models.append(model)

        return matching_models[:limit]