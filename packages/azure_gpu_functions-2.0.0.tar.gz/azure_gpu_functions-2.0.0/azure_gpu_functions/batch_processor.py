"""
Batch Processing System for Azure GPU Functions
Provides efficient batch operations to avoid blocking VS Code agent with individual commands.
"""

import asyncio
import json
import logging
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import queue
import uuid

logger = logging.getLogger(__name__)

class BatchOperationType(Enum):
    COST_ESTIMATION = "cost_estimation"
    MODEL_REGISTRATION = "model_registration"
    TRAINING_STATUS_CHECK = "training_status_check"
    BUDGET_CHECK = "budget_check"
    MODEL_DOWNLOAD = "model_download"
    SYSTEM_METRICS = "system_metrics"

class BatchOperationStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class BatchOperation:
    """Represents a single operation in a batch"""
    operation_id: str
    operation_type: BatchOperationType
    parameters: Dict[str, Any]
    status: BatchOperationStatus = BatchOperationStatus.PENDING
    result: Optional[Any] = None
    error: Optional[str] = None
    created_at: datetime = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    priority: int = 0  # Higher priority = processed first

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.utcnow()

@dataclass
class BatchJob:
    """Represents a batch of operations"""
    batch_id: str
    operations: List[BatchOperation]
    status: BatchOperationStatus = BatchOperationStatus.PENDING
    created_at: datetime = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    progress: Dict[str, Any] = None
    callback: Optional[Callable] = None

    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.utcnow()
        if self.progress is None:
            self.progress = {"total": len(self.operations), "completed": 0, "failed": 0}

class BatchProcessor:
    """Processes batches of operations efficiently"""

    def __init__(self, max_workers: int = 4, queue_size: int = 1000):
        self.max_workers = max_workers
        self.operation_queue = queue.PriorityQueue(maxsize=queue_size)
        self.active_batches: Dict[str, BatchJob] = {}
        self.completed_batches: Dict[str, BatchJob] = {}
        self.workers = []
        self.running = False
        self._lock = threading.Lock()

        # Initialize operation handlers
        self.operation_handlers = {
            BatchOperationType.COST_ESTIMATION: self._handle_cost_estimation,
            BatchOperationType.MODEL_REGISTRATION: self._handle_model_registration,
            BatchOperationType.TRAINING_STATUS_CHECK: self._handle_training_status_check,
            BatchOperationType.BUDGET_CHECK: self._handle_budget_check,
            BatchOperationType.MODEL_DOWNLOAD: self._handle_model_download,
            BatchOperationType.SYSTEM_METRICS: self._handle_system_metrics,
        }

    def start(self):
        """Start the batch processor"""
        if self.running:
            return

        self.running = True
        logger.info(f"Starting batch processor with {self.max_workers} workers")

        # Start worker threads
        for i in range(self.max_workers):
            worker = threading.Thread(target=self._worker_loop, name=f"BatchWorker-{i}")
            worker.daemon = True
            worker.start()
            self.workers.append(worker)

    def stop(self):
        """Stop the batch processor"""
        if not self.running:
            return

        self.running = False
        logger.info("Stopping batch processor")

        # Wait for workers to finish
        for worker in self.workers:
            worker.join(timeout=5)

        self.workers.clear()

    def submit_batch(self, operations: List[Dict[str, Any]], callback: Optional[Callable] = None) -> str:
        """
        Submit a batch of operations for processing

        Args:
            operations: List of operation dictionaries with 'type' and 'parameters'
            callback: Optional callback function to call when batch completes

        Returns:
            Batch ID
        """
        batch_id = str(uuid.uuid4())

        # Create batch operations
        batch_operations = []
        for op_data in operations:
            operation = BatchOperation(
                operation_id=str(uuid.uuid4()),
                operation_type=BatchOperationType(op_data['type']),
                parameters=op_data.get('parameters', {}),
                priority=op_data.get('priority', 0)
            )
            batch_operations.append(operation)

        # Create batch job
        batch_job = BatchJob(
            batch_id=batch_id,
            operations=batch_operations,
            callback=callback
        )

        with self._lock:
            self.active_batches[batch_id] = batch_job

        # Queue operations for processing
        for operation in batch_operations:
            self.operation_queue.put((-operation.priority, operation.operation_id, batch_id))

        logger.info(f"Submitted batch {batch_id} with {len(batch_operations)} operations")
        return batch_id

    def get_batch_status(self, batch_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a batch job"""
        with self._lock:
            if batch_id in self.active_batches:
                batch = self.active_batches[batch_id]
            elif batch_id in self.completed_batches:
                batch = self.completed_batches[batch_id]
            else:
                return None

        return {
            "batch_id": batch.batch_id,
            "status": batch.status.value,
            "progress": batch.progress,
            "created_at": batch.created_at.isoformat(),
            "started_at": batch.started_at.isoformat() if batch.started_at else None,
            "completed_at": batch.completed_at.isoformat() if batch.completed_at else None,
            "operations": [
                {
                    "operation_id": op.operation_id,
                    "type": op.operation_type.value,
                    "status": op.status.value,
                    "error": op.error,
                    "created_at": op.created_at.isoformat(),
                    "started_at": op.started_at.isoformat() if op.started_at else None,
                    "completed_at": op.completed_at.isoformat() if op.completed_at else None,
                }
                for op in batch.operations
            ]
        }

    def cancel_batch(self, batch_id: str) -> bool:
        """Cancel a batch job"""
        with self._lock:
            if batch_id in self.active_batches:
                batch = self.active_batches[batch_id]
                batch.status = BatchOperationStatus.CANCELLED
                batch.completed_at = datetime.utcnow()

                # Cancel all pending operations
                for op in batch.operations:
                    if op.status == BatchOperationStatus.PENDING:
                        op.status = BatchOperationStatus.CANCELLED
                        op.completed_at = datetime.utcnow()

                # Move to completed
                self.completed_batches[batch_id] = batch
                del self.active_batches[batch_id]

                logger.info(f"Cancelled batch {batch_id}")
                return True

        return False

    def _worker_loop(self):
        """Main worker loop for processing operations"""
        while self.running:
            try:
                # Get next operation (with timeout to allow shutdown)
                try:
                    priority, operation_id, batch_id = self.operation_queue.get(timeout=1)
                except queue.Empty:
                    continue

                # Process the operation
                self._process_operation(operation_id, batch_id)

                self.operation_queue.task_done()

            except Exception as e:
                logger.error(f"Error in worker loop: {e}")

    def _process_operation(self, operation_id: str, batch_id: str):
        """Process a single operation"""
        with self._lock:
            if batch_id not in self.active_batches:
                return  # Batch was cancelled

            batch = self.active_batches[batch_id]
            operation = next((op for op in batch.operations if op.operation_id == operation_id), None)

            if not operation:
                return

            # Update operation status
            operation.status = BatchOperationStatus.PROCESSING
            operation.started_at = datetime.utcnow()

            # Update batch status if this is the first operation
            if batch.started_at is None:
                batch.started_at = datetime.utcnow()
                batch.status = BatchOperationStatus.PROCESSING

        try:
            # Execute the operation
            handler = self.operation_handlers.get(operation.operation_type)
            if handler:
                result = handler(operation.parameters)
                operation.result = result
                operation.status = BatchOperationStatus.COMPLETED
            else:
                raise ValueError(f"No handler for operation type: {operation.operation_type}")

        except Exception as e:
            operation.status = BatchOperationStatus.FAILED
            operation.error = str(e)
            logger.error(f"Operation {operation_id} failed: {e}")

        finally:
            operation.completed_at = datetime.utcnow()

            # Check if batch is complete
            with self._lock:
                batch.progress["completed"] = sum(1 for op in batch.operations if op.status == BatchOperationStatus.COMPLETED)
                batch.progress["failed"] = sum(1 for op in batch.operations if op.status == BatchOperationStatus.FAILED)

                if batch.progress["completed"] + batch.progress["failed"] == batch.progress["total"]:
                    # Batch is complete
                    batch.status = BatchOperationStatus.COMPLETED
                    batch.completed_at = datetime.utcnow()

                    # Move to completed batches
                    self.completed_batches[batch_id] = batch
                    del self.active_batches[batch_id]

                    # Call callback if provided
                    if batch.callback:
                        try:
                            batch.callback(batch)
                        except Exception as e:
                            logger.error(f"Error in batch callback: {e}")

                    logger.info(f"Completed batch {batch_id}: {batch.progress['completed']} succeeded, {batch.progress['failed']} failed")

    # Operation handlers
    def _handle_cost_estimation(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle cost estimation operation"""
        try:
            from .cost_management import CostEstimator
            estimator = CostEstimator()
            estimate = estimator.estimate_cost(
                model_name=params.get("model_name", "unknown"),
                epochs=params.get("epochs", 10),
                batch_size=params.get("batch_size", 32),
                model_size_gb=params.get("model_size_gb", 1.0),
                gpu_type=params.get("gpu_type", "V100")
            )
            return asdict(estimate)
        except Exception as e:
            raise Exception(f"Cost estimation failed: {e}")

    def _handle_model_registration(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle model registration operation"""
        try:
            from .model_registry import ModelRegistry, ModelType
            registry = ModelRegistry()
            metadata = registry.register_model(
                name=params["name"],
                model_type=ModelType(params["model_type"]),
                framework=params["framework"],
                architecture=params["architecture"],
                model_path=params["model_path"],
                created_by=params.get("created_by", "system"),
                description=params.get("description", ""),
                tags=params.get("tags", []),
                performance_metrics=params.get("performance_metrics", {}),
                training_config=params.get("training_config", {}),
                dependencies=params.get("dependencies", [])
            )
            return asdict(metadata)
        except Exception as e:
            raise Exception(f"Model registration failed: {e}")

    def _handle_training_status_check(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle training status check operation"""
        try:
            # This would integrate with your training monitoring system
            # For now, return mock status
            return {
                "job_id": params.get("job_id", "unknown"),
                "status": "running",
                "progress": 0.5,
                "current_epoch": 5,
                "total_epochs": 10,
                "estimated_time_remaining": "2h 30m",
                "last_updated": datetime.utcnow().isoformat()
            }
        except Exception as e:
            raise Exception(f"Training status check failed: {e}")

    def _handle_budget_check(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle budget check operation"""
        try:
            from .cost_management import BudgetManager
            manager = BudgetManager()
            team_id = params.get("team_id", "default")
            status, ratio, alerts = manager.check_budget_status(team_id)
            return {
                "team_id": team_id,
                "status": status.value,
                "usage_ratio": ratio,
                "alerts": alerts
            }
        except Exception as e:
            raise Exception(f"Budget check failed: {e}")

    def _handle_model_download(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle model download operation"""
        try:
            from .model_registry import ModelRegistry
            registry = ModelRegistry()
            download_path = registry.download_model(
                model_id=params["model_id"],
                version=params.get("version"),
                downloaded_by=params.get("downloaded_by", "system"),
                purpose=params.get("purpose", "inference")
            )
            return {
                "model_id": params["model_id"],
                "version": params.get("version", "latest"),
                "download_path": download_path,
                "downloaded_at": datetime.utcnow().isoformat()
            }
        except Exception as e:
            raise Exception(f"Model download failed: {e}")

    def _handle_system_metrics(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Handle system metrics operation"""
        try:
            # This would integrate with your monitoring system
            # For now, return mock metrics
            return {
                "cpu_percent": 45.2,
                "memory_percent": 67.8,
                "gpu_utilization": 78.5,
                "disk_usage": 234.5,  # GB used
                "network_io": 125.3,  # MB/s
                "timestamp": datetime.utcnow().isoformat()
            }
        except Exception as e:
            raise Exception(f"System metrics check failed: {e}")

class BatchStatusMonitor:
    """Monitors batch processing status and provides real-time updates"""

    def __init__(self, batch_processor: BatchProcessor):
        self.batch_processor = batch_processor
        self.status_cache: Dict[str, Dict[str, Any]] = {}
        self.cache_timeout = 30  # seconds

    def get_batch_status_batch(self, batch_ids: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Get status for multiple batches in a single call

        Args:
            batch_ids: List of batch IDs to check

        Returns:
            Dictionary with batch statuses
        """
        results = {"statuses": [], "not_found": []}

        for batch_id in batch_ids:
            status = self.batch_processor.get_batch_status(batch_id)
            if status:
                # Update cache
                self.status_cache[batch_id] = {
                    "status": status,
                    "cached_at": datetime.utcnow()
                }
                results["statuses"].append(status)
            else:
                results["not_found"].append(batch_id)

        return results

    def get_cached_status(self, batch_id: str) -> Optional[Dict[str, Any]]:
        """Get cached status if still valid"""
        if batch_id in self.status_cache:
            cached_data = self.status_cache[batch_id]
            if (datetime.utcnow() - cached_data["cached_at"]).seconds < self.cache_timeout:
                return cached_data["status"]
            else:
                # Cache expired, remove it
                del self.status_cache[batch_id]

        return None

    def cleanup_cache(self, max_age_seconds: int = 3600):
        """Clean up old cache entries"""
        cutoff_time = datetime.utcnow() - timedelta(seconds=max_age_seconds)
        to_remove = []

        for batch_id, cached_data in self.status_cache.items():
            if cached_data["cached_at"] < cutoff_time:
                to_remove.append(batch_id)

        for batch_id in to_remove:
            del self.status_cache[batch_id]

        if to_remove:
            logger.info(f"Cleaned up {len(to_remove)} expired cache entries")

# Global instances
batch_processor = BatchProcessor()
batch_monitor = BatchStatusMonitor(batch_processor)

def start_batch_processor():
    """Start the global batch processor"""
    batch_processor.start()

def stop_batch_processor():
    """Stop the global batch processor"""
    batch_processor.stop()

def submit_batch_operations(operations: List[Dict[str, Any]], callback: Optional[Callable] = None) -> str:
    """Submit operations for batch processing"""
    return batch_processor.submit_batch(operations, callback)

def get_batch_operations_status(batch_ids: List[str]) -> Dict[str, List[Dict[str, Any]]]:
    """Get status for multiple batch operations"""
    return batch_monitor.get_batch_status_batch(batch_ids)