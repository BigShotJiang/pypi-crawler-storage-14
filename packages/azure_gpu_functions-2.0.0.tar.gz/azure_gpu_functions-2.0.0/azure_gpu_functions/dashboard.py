"""
Enhanced Dashboard and Command Center for Azure GPU Functions
Provides real-time monitoring, Ray cluster integration, and command center functionality.
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
import threading
import os

# Optional imports
try:
    import ray
    RAY_AVAILABLE = True
except ImportError:
    RAY_AVAILABLE = False

try:
    import websockets
    WEBSOCKETS_AVAILABLE = True
except ImportError:
    WEBSOCKETS_AVAILABLE = False

try:
    from .port_manager import PortManager, PortHealthChecker
    from .mcp_server import RayMCPServer, MCPMonitor
except ImportError:
    # Fallback for development
    try:
        from port_manager import PortManager, PortHealthChecker
        from ray_mcp_server import RayMCPServer, MCPMonitor
    except ImportError:
        PortManager = None
        PortHealthChecker = None
        RayMCPServer = None
        MCPMonitor = None

logger = logging.getLogger(__name__)


class DashboardMetrics:
    """Real-time metrics collection for the dashboard"""

    def __init__(self):
        self.metrics = {}
        self.history = {}
        self.alerts = []
        self.update_interval = 5  # seconds

    def update_metric(self, category: str, metric_name: str, value: Any):
        """Update a metric value"""
        if category not in self.metrics:
            self.metrics[category] = {}
            self.history[category] = {}

        if metric_name not in self.history[category]:
            self.history[category][metric_name] = []

        # Update current value
        self.metrics[category][metric_name] = {
            "value": value,
            "timestamp": datetime.utcnow().isoformat(),
            "last_update": time.time()
        }

        # Add to history (keep last 1000 points)
        self.history[category][metric_name].append({
            "value": value,
            "timestamp": datetime.utcnow().isoformat()
        })

        if len(self.history[category][metric_name]) > 1000:
            self.history[category][metric_name] = self.history[category][metric_name][-1000:]

    def get_metric(self, category: str, metric_name: str) -> Optional[Dict[str, Any]]:
        """Get current metric value"""
        return self.metrics.get(category, {}).get(metric_name)

    def get_metric_history(self, category: str, metric_name: str, limit: int = 100) -> List[Dict[str, Any]]:
        """Get metric history"""
        return self.history.get(category, {}).get(metric_name, [])[-limit:]

    def add_alert(self, alert_type: str, message: str, severity: str = "info"):
        """Add an alert"""
        alert = {
            "type": alert_type,
            "message": message,
            "severity": severity,
            "timestamp": datetime.utcnow().isoformat(),
            "id": f"{alert_type}_{int(time.time())}"
        }
        self.alerts.append(alert)

        # Keep only last 100 alerts
        if len(self.alerts) > 100:
            self.alerts = self.alerts[-100:]

        logger.info(f"Alert added: {alert_type} - {message}")

    def get_alerts(self, severity: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """Get alerts, optionally filtered by severity"""
        alerts = self.alerts
        if severity:
            alerts = [a for a in alerts if a["severity"] == severity]
        return alerts[-limit:]

    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get comprehensive dashboard data"""
        return {
            "metrics": self.metrics,
            "alerts": self.get_alerts(limit=10),
            "timestamp": datetime.utcnow().isoformat(),
            "uptime": time.time() - getattr(self, '_start_time', time.time())
        }


class RayClusterMonitor:
    """Monitor Ray cluster status and resources"""

    def __init__(self):
        self.cluster_info = {}
        self.node_info = {}
        self.task_info = {}
        self.last_update = 0
        self.update_interval = 10  # seconds

    def update_cluster_status(self):
        """Update Ray cluster status"""
        if not RAY_AVAILABLE or not ray.is_initialized():
            return

        try:
            current_time = time.time()
            if current_time - self.last_update < self.update_interval:
                return

            # Get cluster resources
            resources = ray.cluster_resources()
            available_resources = ray.available_resources()

            self.cluster_info = {
                "total_cpus": resources.get("CPU", 0),
                "available_cpus": available_resources.get("CPU", 0),
                "total_gpus": resources.get("GPU", 0),
                "available_gpus": available_resources.get("GPU", 0),
                "total_memory_gb": resources.get("memory", 0) / (1024**3),
                "available_memory_gb": available_resources.get("memory", 0) / (1024**3),
                "nodes": len(ray.nodes()),
                "timestamp": datetime.utcnow().isoformat()
            }

            # Get node information
            nodes = ray.nodes()
            self.node_info = {}
            for node in nodes:
                node_id = node["NodeID"]
                self.node_info[node_id] = {
                    "alive": node["Alive"],
                    "node_manager_address": node["NodeManagerAddress"],
                    "resources_total": node["ResourcesTotal"],
                    "resources_available": node.get("ResourcesAvailable", {}),
                    "state": node["state"]
                }

            # Get task information
            tasks = ray.tasks()
            self.task_info = {
                "total_tasks": len(tasks),
                "pending_tasks": len([t for t in tasks.values() if t["state"] == "PENDING"]),
                "running_tasks": len([t for t in tasks.values() if t["state"] == "RUNNING"]),
                "finished_tasks": len([t for t in tasks.values() if t["state"] == "FINISHED"]),
                "failed_tasks": len([t for t in tasks.values() if t["state"] == "FAILED"])
            }

            self.last_update = current_time

        except Exception as e:
            logger.error(f"Failed to update Ray cluster status: {e}")

    def get_cluster_status(self) -> Dict[str, Any]:
        """Get current cluster status"""
        self.update_cluster_status()
        return {
            "cluster": self.cluster_info,
            "nodes": self.node_info,
            "tasks": self.task_info
        }


class CommandCenter:
    """Command center for managing GPU training operations"""

    def __init__(self):
        self.active_commands = {}
        self.command_history = []
        self.max_history = 1000

    def execute_command(self, command: str, args: Optional[Dict[str, Any]] = None,
                       callback: Optional[Callable] = None) -> str:
        """
        Execute a command in the command center.

        Args:
            command: Command name
            args: Command arguments
            callback: Optional callback function

        Returns:
            Command execution ID
        """
        command_id = f"cmd_{int(time.time())}_{hash(command) % 1000}"

        command_record = {
            "id": command_id,
            "command": command,
            "args": args or {},
            "status": "running",
            "start_time": datetime.utcnow().isoformat(),
            "end_time": None,
            "result": None,
            "error": None
        }

        self.active_commands[command_id] = command_record

        # Execute command asynchronously
        def run_command():
            try:
                result = self._execute_command_impl(command, args)
                command_record["status"] = "completed"
                command_record["result"] = result
            except Exception as e:
                command_record["status"] = "failed"
                command_record["error"] = str(e)
                logger.error(f"Command {command_id} failed: {e}")
            finally:
                command_record["end_time"] = datetime.utcnow().isoformat()
                if callback:
                    callback(command_record)

        thread = threading.Thread(target=run_command, daemon=True)
        thread.start()

        return command_id

    def _execute_command_impl(self, command: str, args: Optional[Dict[str, Any]]) -> Any:
        """Execute command implementation"""
        if command == "start_training":
            return self._start_training(args)
        elif command == "stop_training":
            return self._stop_training(args)
        elif command == "get_system_status":
            return self._get_system_status()
        elif command == "scale_resources":
            return self._scale_resources(args)
        elif command == "check_ports":
            return self._check_ports(args)
        else:
            raise ValueError(f"Unknown command: {command}")

    def _start_training(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Start a training job"""
        # Implementation would integrate with training module
        return {
            "status": "started",
            "job_id": f"train_{int(time.time())}",
            "config": args
        }

    def _stop_training(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Stop a training job"""
        job_id = args.get("job_id")
        # Implementation would integrate with training module
        return {
            "status": "stopped",
            "job_id": job_id
        }

    def _get_system_status(self) -> Dict[str, Any]:
        """Get system status"""
        if PortManager:
            return PortManager.check_service_ports()
        return {"error": "Port manager not available"}

    def _scale_resources(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Scale resources"""
        # Implementation would integrate with Ray/autoscaling
        return {
            "status": "scaled",
            "new_resources": args
        }

    def _check_ports(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Check port availability"""
        if PortManager:
            services = args.get("services", [])
            return PortManager.check_service_ports(services)
        return {"error": "Port manager not available"}

    def get_command_status(self, command_id: str) -> Optional[Dict[str, Any]]:
        """Get status of a command"""
        return self.active_commands.get(command_id)

    def get_command_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get command execution history"""
        # Move completed commands to history
        completed_commands = []
        for cmd_id, cmd in list(self.active_commands.items()):
            if cmd["status"] in ["completed", "failed"]:
                completed_commands.append(cmd)
                del self.active_commands[cmd_id]

        self.command_history.extend(completed_commands)

        # Keep history size manageable
        if len(self.command_history) > self.max_history:
            self.command_history = self.command_history[-self.max_history:]

        return self.command_history[-limit:]

    def get_active_commands(self) -> Dict[str, Dict[str, Any]]:
        """Get currently active commands"""
        return self.active_commands.copy()


class EnhancedDashboard:
    """Enhanced dashboard with Ray cluster and MCP integration"""

    def __init__(self, host: str = "0.0.0.0", port: int = 8080):
        self.host = host
        self.port = port
        self.metrics = DashboardMetrics()
        self.ray_monitor = RayClusterMonitor()
        self.command_center = CommandCenter()
        self.mcp_clients = {}
        self.running = False

        # Initialize start time
        self.metrics._start_time = time.time()

    def start_dashboard(self):
        """Start the enhanced dashboard"""
        self.running = True

        # Start background monitoring
        self._start_background_monitoring()

        logger.info(f"Enhanced Dashboard started on http://{self.host}:{self.port}")

    def stop_dashboard(self):
        """Stop the dashboard"""
        self.running = False
        logger.info("Enhanced Dashboard stopped")

    def _start_background_monitoring(self):
        """Start background monitoring tasks"""
        def monitoring_loop():
            while self.running:
                try:
                    self._update_system_metrics()
                    self._update_ray_metrics()
                    self._check_alerts()
                    time.sleep(5)  # Update every 5 seconds
                except Exception as e:
                    logger.error(f"Error in monitoring loop: {e}")
                    time.sleep(10)

        thread = threading.Thread(target=monitoring_loop, daemon=True)
        thread.start()

    def _update_system_metrics(self):
        """Update system metrics"""
        try:
            import psutil

            # CPU metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            self.metrics.update_metric("system", "cpu_percent", cpu_percent)

            # Memory metrics
            memory = psutil.virtual_memory()
            self.metrics.update_metric("system", "memory_percent", memory.percent)
            self.metrics.update_metric("system", "memory_used_gb", memory.used / (1024**3))

            # Disk metrics
            disk = psutil.disk_usage('/')
            self.metrics.update_metric("system", "disk_percent", disk.percent)

        except Exception as e:
            logger.error(f"Failed to update system metrics: {e}")

    def _update_ray_metrics(self):
        """Update Ray cluster metrics"""
        try:
            cluster_status = self.ray_monitor.get_cluster_status()

            # Update cluster metrics
            for key, value in cluster_status.get("cluster", {}).items():
                if key != "timestamp":
                    self.metrics.update_metric("ray", key, value)

            # Update task metrics
            for key, value in cluster_status.get("tasks", {}).items():
                self.metrics.update_metric("ray_tasks", key, value)

        except Exception as e:
            logger.error(f"Failed to update Ray metrics: {e}")

    def _check_alerts(self):
        """Check for system alerts"""
        try:
            # Check CPU usage
            cpu_metric = self.metrics.get_metric("system", "cpu_percent")
            if cpu_metric and cpu_metric["value"] > 90:
                self.metrics.add_alert("high_cpu", f"CPU usage is {cpu_metric['value']:.1f}%", "warning")

            # Check memory usage
            memory_metric = self.metrics.get_metric("system", "memory_percent")
            if memory_metric and memory_metric["value"] > 95:
                self.metrics.add_alert("high_memory", f"Memory usage is {memory_metric['value']:.1f}%", "critical")

            # Check Ray cluster health
            if RAY_AVAILABLE and ray.is_initialized():
                cluster_status = self.ray_monitor.get_cluster_status()
                if cluster_status.get("cluster", {}).get("nodes", 0) == 0:
                    self.metrics.add_alert("ray_cluster", "No Ray nodes available", "critical")

        except Exception as e:
            logger.error(f"Failed to check alerts: {e}")

    def get_dashboard_html(self) -> str:
        """Generate enhanced dashboard HTML"""
        dashboard_data = self.metrics.get_dashboard_data()
        ray_status = self.ray_monitor.get_cluster_status()
        active_commands = self.command_center.get_active_commands()

        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced Azure GPU Functions Dashboard</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #333;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            padding: 20px;
        }}
        .card {{
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border: 1px solid #e0e0e0;
        }}
        .metric {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }}
        .metric-value {{
            font-size: 24px;
            font-weight: bold;
            color: #667eea;
        }}
        .status-healthy {{ color: #28a745; }}
        .status-warning {{ color: #ffc107; }}
        .status-critical {{ color: #dc3545; }}
        .alert-list {{
            max-height: 200px;
            overflow-y: auto;
        }}
        .alert {{
            padding: 8px;
            margin-bottom: 5px;
            border-radius: 4px;
            border-left: 4px solid;
        }}
        .alert-info {{ border-left-color: #17a2b8; background-color: #d1ecf1; }}
        .alert-warning {{ border-left-color: #ffc107; background-color: #fff3cd; }}
        .alert-critical {{ border-left-color: #dc3545; background-color: #f8d7da; }}
        .command-center {{
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-top: 10px;
        }}
        .command-input {{
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
        }}
        .btn {{
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 10px;
        }}
        .btn:hover {{ background: #5a67d8; }}
        .ray-status {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
        }}
        .ray-node {{
            background: #f8f9fa;
            padding: 10px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }}
        .refresh-btn {{
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }}
        .refresh-btn:hover {{ background: #218838; }}
    </style>
</head>
<body>
    <button class="refresh-btn" onclick="location.reload()">🔄 Refresh</button>

    <div class="container">
        <div class="header">
            <h1>🚀 Enhanced Azure GPU Functions Dashboard</h1>
            <p>Real-time monitoring with Ray cluster integration</p>
            <div style="margin-top: 10px; font-size: 14px;">
                Last updated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')}
            </div>
        </div>

        <div class="grid">
            <!-- System Metrics -->
            <div class="card">
                <h3>🖥️ System Status</h3>
                <div class="metric">
                    <span>CPU Usage</span>
                    <span class="metric-value">{dashboard_data['metrics'].get('system', {}).get('cpu_percent', {}).get('value', 'N/A')}%</span>
                </div>
                <div class="metric">
                    <span>Memory Usage</span>
                    <span class="metric-value">{dashboard_data['metrics'].get('system', {}).get('memory_percent', {}).get('value', 'N/A')}%</span>
                </div>
                <div class="metric">
                    <span>Disk Usage</span>
                    <span class="metric-value">{dashboard_data['metrics'].get('system', {}).get('disk_percent', {}).get('value', 'N/A')}%</span>
                </div>
            </div>

            <!-- Ray Cluster Status -->
            <div class="card">
                <h3>⚡ Ray Cluster</h3>
                <div class="ray-status">
                    <div>
                        <div class="metric">
                            <span>CPUs</span>
                            <span class="metric-value">{ray_status.get('cluster', {}).get('available_cpus', 'N/A')}/{ray_status.get('cluster', {}).get('total_cpus', 'N/A')}</span>
                        </div>
                        <div class="metric">
                            <span>GPUs</span>
                            <span class="metric-value">{ray_status.get('cluster', {}).get('available_gpus', 'N/A')}/{ray_status.get('cluster', {}).get('total_gpus', 'N/A')}</span>
                        </div>
                    </div>
                    <div>
                        <div class="metric">
                            <span>Nodes</span>
                            <span class="metric-value">{ray_status.get('cluster', {}).get('nodes', 'N/A')}</span>
                        </div>
                        <div class="metric">
                            <span>Memory (GB)</span>
                            <span class="metric-value">{f"{ray_status.get('cluster', {}).get('available_memory_gb', 'N/A'):.1f}" if isinstance(ray_status.get('cluster', {}).get('available_memory_gb'), (int, float)) else ray_status.get('cluster', {}).get('available_memory_gb', 'N/A')}/{f"{ray_status.get('cluster', {}).get('total_memory_gb', 'N/A'):.1f}" if isinstance(ray_status.get('cluster', {}).get('total_memory_gb'), (int, float)) else ray_status.get('cluster', {}).get('total_memory_gb', 'N/A')}</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ray Tasks -->
            <div class="card">
                <h3>📊 Ray Tasks</h3>
                <div class="metric">
                    <span>Running</span>
                    <span class="metric-value status-healthy">{ray_status.get('tasks', {}).get('running_tasks', 0)}</span>
                </div>
                <div class="metric">
                    <span>Pending</span>
                    <span class="metric-value status-warning">{ray_status.get('tasks', {}).get('pending_tasks', 0)}</span>
                </div>
                <div class="metric">
                    <span>Failed</span>
                    <span class="metric-value status-critical">{ray_status.get('tasks', {}).get('failed_tasks', 0)}</span>
                </div>
                <div class="metric">
                    <span>Completed</span>
                    <span class="metric-value">{ray_status.get('tasks', {}).get('finished_tasks', 0)}</span>
                </div>
            </div>

            <!-- Active Commands -->
            <div class="card">
                <h3>⚙️ Active Commands</h3>
                {''.join([f'''
                <div class="metric">
                    <span>{cmd['command']}</span>
                    <span class="metric-value status-healthy">{cmd['status']}</span>
                </div>''' for cmd in active_commands.values()])}
                {f'<div style="text-align: center; color: #666;">No active commands</div>' if not active_commands else ''}
            </div>

            <!-- Alerts -->
            <div class="card">
                <h3>🚨 Recent Alerts</h3>
                <div class="alert-list">
                    {''.join([f'''
                    <div class="alert alert-{alert['severity']}">
                        <strong>{alert['type']}</strong>: {alert['message']}
                        <br><small>{alert['timestamp']}</small>
                    </div>''' for alert in dashboard_data['alerts']])}
                    {f'<div style="text-align: center; color: #666;">No recent alerts</div>' if not dashboard_data['alerts'] else ''}
                </div>
            </div>

            <!-- Command Center -->
            <div class="card">
                <h3>🎮 Command Center</h3>
                <div class="command-center">
                    <input type="text" id="commandInput" class="command-input" placeholder="Enter command (e.g., check_ports, get_system_status)">
                    <button class="btn" onclick="executeCommand()">Execute</button>
                    <button class="btn" onclick="showCommandHistory()">History</button>
                </div>
                <div id="commandOutput" style="margin-top: 10px; font-family: monospace; background: #f8f9fa; padding: 10px; border-radius: 4px; max-height: 150px; overflow-y: auto;"></div>
            </div>
        </div>
    </div>

    <script>
        let commandHistory = [];

        function executeCommand() {{
            const commandInput = document.getElementById('commandInput');
            const command = commandInput.value.trim();
            if (!command) return;

            const output = document.getElementById('commandOutput');
            output.innerHTML = '<div style="color: #666;">Executing command...</div>';

            // Simulate command execution (in real implementation, this would make an API call)
            setTimeout(() => {{
                const result = `Command executed: ${{command}}<br>Status: Success<br>Result: Command completed at ${{new Date().toISOString()}}`;
                output.innerHTML = result;
                commandHistory.push({{command, result, timestamp: new Date().toISOString()}});
            }}, 1000);

            commandInput.value = '';
        }}

        function showCommandHistory() {{
            const output = document.getElementById('commandOutput');
            if (commandHistory.length === 0) {{
                output.innerHTML = '<div style="color: #666;">No command history</div>';
                return;
            }}

            let html = '<div style="font-weight: bold; margin-bottom: 10px;">Command History:</div>';
            commandHistory.slice(-5).forEach((item, index) => {{
                html += `<div style="margin-bottom: 8px; padding: 5px; background: white; border-radius: 3px;">
                    <strong>${{item.command}}</strong><br>
                    <small>${{item.timestamp}}</small><br>
                    ${{item.result}}
                </div>`;
            }});
            output.innerHTML = html;
        }}

        // Auto-refresh every 30 seconds
        setInterval(() => {{
            location.reload();
        }}, 30000);
    </script>
</body>
</html>
        """

        return html

    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get comprehensive dashboard data"""
        return {
            "system_metrics": self.metrics.get_metric("system", "cpu_percent"),
            "ray_status": self.ray_monitor.get_cluster_status(),
            "active_commands": self.command_center.get_active_commands(),
            "alerts": self.metrics.get_alerts(limit=10),
            "timestamp": datetime.utcnow().isoformat()
        }


# Global dashboard instance
dashboard = EnhancedDashboard()

def get_enhanced_dashboard():
    """Get the enhanced dashboard instance"""
    return dashboard

def start_enhanced_dashboard(host: str = "0.0.0.0", port: int = 8080):
    """Start the enhanced dashboard"""
    dashboard = get_enhanced_dashboard()
    dashboard.host = host
    dashboard.port = port
    dashboard.start_dashboard()
    return dashboard