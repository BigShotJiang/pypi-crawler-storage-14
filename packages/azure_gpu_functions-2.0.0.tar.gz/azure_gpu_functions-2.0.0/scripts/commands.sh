#!/bin/bash
"""
Training Resource Management Command Reference
Shows all available monitoring and cleanup commands
"""

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${BLUE}🔍 Training Resource Management Commands${NC}"
echo "=========================================="
echo ""

echo -e "${CYAN}📊 MONITORING COMMANDS${NC}"
echo "------------------------"

echo -e "${GREEN}🔍 Quick Health Check (Recommended)${NC}"
echo "  ./scripts/health_check.sh"
echo "  → Monitors all resources and shows summary"
echo ""

echo -e "${GREEN}📈 Performance Monitoring${NC}"
echo "  python scripts/performance_monitor.py"
echo "  → Measures startup times, cache performance, GPU usage"
echo ""

echo -e "${GREEN}🔬 Detailed Resource Check${NC}"
echo "  python scripts/check_training_resources.py"
echo "  → Comprehensive check of all training resources"
echo ""

echo -e "${CYAN}🧹 CLEANUP COMMANDS${NC}"
echo "--------------------"

echo -e "${GREEN}🧽 Safe Cleanup (Dry-run)${NC}"
echo "  python scripts/cleanup_resources.py --monitoring-report resource_check_report.json"
echo "  → Shows what would be cleaned without actually doing it"
echo ""

echo -e "${GREEN}🧹 Automatic Cleanup${NC}"
echo "  ./scripts/health_check.sh --auto-cleanup"
echo "  → Monitors and automatically cleans orphaned resources"
echo ""

echo -e "${GREEN}💥 Emergency Cleanup${NC}"
echo "  ./scripts/health_check.sh --emergency"
echo "  → KILLS ALL training-related processes (use with caution!)"
echo ""

echo -e "${GREEN}🔧 Manual Cleanup${NC}"
echo "  python scripts/cleanup_resources.py --wet-run --monitoring-report resource_check_report.json"
echo "  → Performs actual cleanup based on monitoring report"
echo ""

echo -e "${CYAN}⏰ AUTOMATION COMMANDS${NC}"
echo "-----------------------"

echo -e "${GREEN}⚙️ Setup Automated Monitoring${NC}"
echo "  ./scripts/setup_cron_monitor.sh"
echo "  → Interactive setup of periodic monitoring"
echo ""

echo -e "${GREEN}🔄 Manual Cron Run${NC}"
echo "  ./scripts/cron_monitor.sh"
echo "  → Run automated monitoring manually"
echo ""

echo -e "${CYAN}🧪 TRAINING PERFORMANCE TESTING${NC}"
echo "---------------------------------"

echo -e "${GREEN}🧪 Quick Training Tests${NC}"
echo "  ./scripts/quick_training_test.sh all"
echo "  → Test all training types quickly"
echo ""

echo -e "${GREEN}🎯 Test Specific Type${NC}"
echo "  ./scripts/quick_training_test.sh small"
echo "  ./scripts/quick_training_test.sh medium --framework tensorflow"
echo "  → Test individual training types"
echo ""

echo -e "${GREEN}💾 Test Caching Performance${NC}"
echo "  ./scripts/quick_training_test.sh cache"
echo "  → Measure caching effectiveness"
echo ""

echo -e "${GREEN}📊 Comprehensive Performance Test${NC}"
echo "  ./scripts/training_performance_test.sh"
echo "  → Full test suite with 10 iterations (30-60 min)"
echo ""

echo -e "${CYAN}📋 REPORTS AND LOGS${NC}"
echo "--------------------"

echo -e "${YELLOW}📊 Generated Reports:${NC}"
echo "  resource_check_report.json           → Resource monitoring results"
echo "  cleanup_report.json                  → Cleanup actions performed"
echo "  performance_report.json              → Performance metrics"
echo "  training_performance_results.json    → Training test results"
echo "  training_performance_report_*.md     → Training performance report"
echo "  resource_monitor.log                 → Automated monitoring logs"
echo "  training_performance_test_*.log      → Training test logs"
echo ""

echo -e "${YELLOW}📁 Report Locations:${NC}"
echo "  $PROJECT_DIR/*.json"
echo "  $PROJECT_DIR/*.md"
echo "  $PROJECT_DIR/*.log"
echo ""

echo -e "${CYAN}🔧 ENVIRONMENT VARIABLES${NC}"
echo "---------------------------"

echo -e "${PURPLE}Required:${NC}"
echo "  AZURE_SUBSCRIPTION_ID    → Your Azure subscription ID"
echo "  AZURE_RESOURCE_GROUP     → Resource group name"
echo "  AZURE_FUNCTION_APP_NAME  → Function app name"
echo "  FUNCTION_URI             → Function app URL"
echo ""

echo -e "${PURPLE}Optional:${NC}"
echo "  ALERT_EMAIL              → Email for alerts"
echo "  SLACK_WEBHOOK_URL        → Slack webhook for alerts"
echo ""

echo -e "${CYAN}⚠️ SAFETY NOTES${NC}"
echo "---------------"

echo -e "${RED}🚨 Emergency cleanup kills ALL processes matching:${NC}"
echo "  - Ray processes (*ray*)"
echo "  - GPU processes (cuda, gpu, torch, tensorflow)"
echo "  - Training processes (*training*, *train*)"
echo ""

echo -e "${YELLOW}💡 Best Practices:${NC}"
echo "  1. Always run monitoring first to see what needs cleanup"
echo "  2. Use dry-run mode to preview cleanup actions"
echo "  3. Set up automated monitoring for production"
echo "  4. Configure alerts for orphaned resources"
echo "  5. Regularly review logs and reports"
echo ""

echo -e "${CYAN}🚀 QUICK START${NC}"
echo "--------------"

echo -e "${GREEN}1. Set environment variables:${NC}"
echo "   export AZURE_SUBSCRIPTION_ID='your-id'"
echo "   export AZURE_RESOURCE_GROUP='your-rg'"
echo "   export AZURE_FUNCTION_APP_NAME='your-app'"
echo "   export FUNCTION_URI='https://your-app.azurewebsites.net'"
echo ""

echo -e "${GREEN}2. Run health check:${NC}"
echo "   ./scripts/health_check.sh"
echo ""

echo -e "${GREEN}3. Setup automation:${NC}"
echo "   ./scripts/setup_cron_monitor.sh"
echo ""

echo -e "${BLUE}🎯 Ready to monitor and cleanup training resources!${NC}"