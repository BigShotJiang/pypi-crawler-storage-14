#!/bin/bash

# Test GPU-enabled Azure Function
# Usage: ./test_gpu_function.sh <function-url>

if [ -z "$1" ]; then
    echo "Usage: $0 <function-url>"
    echo "Example: $0 https://func-gpu-test.example.azurecontainerapps.io"
    exit 1
fi

FUNCTION_URL="$1"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${BLUE}🧪 Testing GPU-enabled Azure Function${NC}"
echo "======================================"
echo "URL: $FUNCTION_URL"
echo ""

# Test 1: Health check
echo -e "${YELLOW}1️⃣  Testing health endpoint...${NC}"
curl -s "$FUNCTION_URL/api/health" | jq '.'
echo ""
echo ""

# Test 2: GPU status
echo -e "${YELLOW}2️⃣  Checking GPU status (may take 30-60s for cold start)...${NC}"
curl -s "$FUNCTION_URL/api/gpu-status" | jq '.'
echo ""
echo ""

# Test 3: GPU computation test
echo -e "${YELLOW}3️⃣  Running GPU computation test...${NC}"
curl -s "$FUNCTION_URL/api/gpu-test" | jq '.'
echo ""
echo ""

echo -e "${GREEN}✅ Testing complete!${NC}"
