#!/bin/bash

# Azure Function with GPU Support - Deployment Script
# For Amadeus test subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
ENVIRONMENT_NAME="llm-gpu-function-test"
PROJECT_NAME="appfunctiongpu"

echo -e "${BLUE}🚀 Azure Function with GPU Support Deployment${NC}"
echo -e "${BLUE}=================================================${NC}"
echo ""
echo -e "${YELLOW}Target Subscription:${NC} $SUBSCRIPTION_ID"
echo -e "${YELLOW}Target Location:${NC} $LOCATION"
echo -e "${YELLOW}Environment Name:${NC} $ENVIRONMENT_NAME"
echo ""

# Check prerequisites
echo -e "${BLUE}📋 Checking Prerequisites...${NC}"

# Check Azure CLI
if ! command -v az &> /dev/null; then
    echo -e "${RED}❌ Azure CLI not found. Please install: brew install azure-cli${NC}"
    exit 1
else
    echo -e "${GREEN}✅ Azure CLI found${NC}"
fi

# Check Azure Developer CLI
if ! command -v azd &> /dev/null; then
    echo -e "${RED}❌ Azure Developer CLI not found. Please install: brew install azd${NC}"
    exit 1
else
    echo -e "${GREEN}✅ Azure Developer CLI found${NC}"
fi

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${RED}❌ Docker not found. Please install: brew install docker${NC}"
    exit 1
else
    echo -e "${GREEN}✅ Docker found${NC}"
fi

echo ""

# Login to Azure
echo -e "${BLUE}🔐 Azure Authentication...${NC}"
echo "Please ensure you're logged in to Azure..."

# Check if already logged in
if ! az account show --subscription $SUBSCRIPTION_ID &> /dev/null; then
    echo -e "${YELLOW}⚠️  Not logged in or subscription not accessible. Running az login...${NC}"
    az login
fi

# Set subscription
echo -e "${BLUE}🔧 Setting Azure subscription...${NC}"
az account set --subscription $SUBSCRIPTION_ID

# Get current user info
CURRENT_USER=$(az account show --query user.name -o tsv)
PRINCIPAL_ID=$(az ad signed-in-user show --query id -o tsv)

echo -e "${GREEN}✅ Logged in as: $CURRENT_USER${NC}"
echo -e "${GREEN}✅ Principal ID: $PRINCIPAL_ID${NC}"

# Login to Azure Developer CLI
echo -e "${BLUE}🔧 Azure Developer CLI authentication...${NC}"
if ! azd auth login --check-status &> /dev/null; then
    echo -e "${YELLOW}⚠️  Not logged in to azd. Running azd auth login...${NC}"
    azd auth login
fi

echo ""

# GPU Quota Check
echo -e "${BLUE}📊 Checking GPU Quota Availability...${NC}"
echo -e "${YELLOW}⚠️  Important: Ensure you have requested A100 GPU quota in North Europe${NC}"
echo -e "${YELLOW}   Submit a support request if you haven't already done so.${NC}"
echo ""

# Initialize azd environment
echo -e "${BLUE}🏗️  Initializing Azure Developer CLI Environment...${NC}"

# Create environment if it doesn't exist
if ! azd env list | grep -q $ENVIRONMENT_NAME; then
    echo -e "${BLUE}Creating new environment: $ENVIRONMENT_NAME${NC}"
    azd env new $ENVIRONMENT_NAME
else
    echo -e "${GREEN}✅ Environment $ENVIRONMENT_NAME already exists${NC}"
fi

# Select the environment
azd env select $ENVIRONMENT_NAME

# Set environment variables
echo -e "${BLUE}🔧 Configuring environment variables...${NC}"
azd env set AZURE_LOCATION $LOCATION
azd env set AZURE_SUBSCRIPTION_ID $SUBSCRIPTION_ID
azd env set principalId $PRINCIPAL_ID

echo -e "${GREEN}✅ Environment configured${NC}"
echo ""

# Preview infrastructure deployment
echo -e "${BLUE}👀 Previewing Infrastructure Deployment...${NC}"
echo -e "${YELLOW}⏳ This may take a few minutes...${NC}"

if azd provision --preview; then
    echo -e "${GREEN}✅ Infrastructure preview successful${NC}"
else
    echo -e "${RED}❌ Infrastructure preview failed${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}📋 Infrastructure Preview Complete!${NC}"
echo -e "${YELLOW}The following resources will be created:${NC}"
echo -e "${BLUE}• Resource Group${NC}"
echo -e "${BLUE}• Container Apps Environment with A100 GPU workload profile${NC}"
echo -e "${BLUE}• Container Registry${NC}"
echo -e "${BLUE}• Storage Account${NC}"
echo -e "${BLUE}• Key Vault${NC}"
echo -e "${BLUE}• Log Analytics Workspace${NC}"
echo -e "${BLUE}• Application Insights${NC}"
echo -e "${BLUE}• Azure Function on Container Apps${NC}"
echo ""

# Ask for confirmation
read -p "Do you want to proceed with the deployment? (y/N): " -r
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}⚠️  Deployment cancelled by user${NC}"
    exit 0
fi

echo ""

# Deploy infrastructure
echo -e "${BLUE}🏗️  Deploying Infrastructure...${NC}"
echo -e "${YELLOW}⏳ This may take 15-20 minutes...${NC}"

if azd provision; then
    echo -e "${GREEN}✅ Infrastructure deployment successful${NC}"
else
    echo -e "${RED}❌ Infrastructure deployment failed${NC}"
    exit 1
fi

echo ""

# Build and deploy application
echo -e "${BLUE}🐳 Building and Deploying Application...${NC}"
echo -e "${YELLOW}⏳ Building container image with GPU support...${NC}"

if azd deploy; then
    echo -e "${GREEN}✅ Application deployment successful${NC}"
else
    echo -e "${RED}❌ Application deployment failed${NC}"
    exit 1
fi

echo ""

# Get deployment outputs
echo -e "${BLUE}📊 Deployment Summary${NC}"
echo -e "${BLUE}===================${NC}"

# Get function app URL
FUNCTION_APP_URI=$(azd env get-values | grep AZURE_FUNCTION_APP_URI | cut -d'=' -f2 | tr -d '"')
RESOURCE_GROUP_NAME=$(azd env get-values | grep AZURE_RESOURCE_GROUP_NAME | cut -d'=' -f2 | tr -d '"')

echo -e "${GREEN}✅ Deployment completed successfully!${NC}"
echo ""
echo -e "${YELLOW}📋 Deployment Details:${NC}"
echo -e "${BLUE}• Function App URL:${NC} $FUNCTION_APP_URI"
echo -e "${BLUE}• Resource Group:${NC} $RESOURCE_GROUP_NAME"
echo -e "${BLUE}• Location:${NC} $LOCATION"
echo -e "${BLUE}• Subscription:${NC} $SUBSCRIPTION_ID"
echo ""
echo -e "${YELLOW}🔗 Useful Links:${NC}"
echo -e "${BLUE}• Azure Portal:${NC} https://portal.azure.com/#@amadeus.com/resource/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP_NAME"
echo -e "${BLUE}• Function App:${NC} $FUNCTION_APP_URI"
echo ""

# Test endpoints
echo -e "${BLUE}🧪 Testing Deployment...${NC}"

if curl -s "$FUNCTION_APP_URI/api/status" > /dev/null; then
    echo -e "${GREEN}✅ Function App is responding${NC}"
    echo -e "${BLUE}• Status endpoint:${NC} $FUNCTION_APP_URI/api/status"
    echo -e "${BLUE}• Training endpoint:${NC} $FUNCTION_APP_URI/api/train"
    echo -e "${BLUE}• Inference endpoint:${NC} $FUNCTION_APP_URI/api/inference"
else
    echo -e "${YELLOW}⚠️  Function App may still be starting up. Try the status endpoint in a few minutes.${NC}"
fi

echo ""
echo -e "${GREEN}🎉 Deployment Complete!${NC}"
echo -e "${YELLOW}Next Steps:${NC}"
echo -e "${BLUE}1. Test the status endpoint to verify GPU availability${NC}"
echo -e "${BLUE}2. Upload training data and test the training endpoint${NC}"
echo -e "${BLUE}3. Monitor performance through Application Insights${NC}"
echo -e "${BLUE}4. Scale configuration based on usage patterns${NC}"
echo ""
echo -e "${GREEN}Happy GPU-powered LLM training! 🚀${NC}"