#!/bin/bash
"""
Setup Cron Job for Automated Resource Monitoring
Configures periodic monitoring and cleanup of training resources
"""

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CRON_SCRIPT="$SCRIPT_DIR/cron_monitor.sh"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}⏰ Setup Automated Resource Monitoring${NC}"
echo "======================================="

# Check if cron script exists
if [[ ! -x "$CRON_SCRIPT" ]]; then
    echo -e "${RED}❌ Cron script not found or not executable: $CRON_SCRIPT${NC}"
    exit 1
fi

# Check if jq is available (needed for JSON parsing)
if ! command -v jq >/dev/null 2>&1; then
    echo -e "${YELLOW}⚠️ jq not found. Installing...${NC}"
    if command -v brew >/dev/null 2>&1; then
        brew install jq
    elif command -v apt-get >/dev/null 2>&1; then
        sudo apt-get update && sudo apt-get install -y jq
    else
        echo -e "${RED}❌ Please install jq manually: https://stedolan.github.io/jq/${NC}"
        exit 1
    fi
fi

# Function to add cron job
add_cron_job() {
    local schedule="$1"
    local job_name="$2"

    # Check if cron job already exists
    if crontab -l 2>/dev/null | grep -q "$CRON_SCRIPT"; then
        echo -e "${YELLOW}⚠️ Cron job already exists. Updating...${NC}"
        # Remove existing job
        crontab -l 2>/dev/null | grep -v "$CRON_SCRIPT" | crontab -
    fi

    # Add new cron job
    (crontab -l 2>/dev/null; echo "$schedule $CRON_SCRIPT # $job_name") | crontab -

    echo -e "${GREEN}✅ Cron job added: $job_name${NC}"
    echo "   Schedule: $schedule"
}

# Function to show current cron jobs
show_cron_jobs() {
    echo -e "${BLUE}📋 Current Cron Jobs:${NC}"
    crontab -l | grep -E "(cron_monitor|health_check)" || echo "   No monitoring jobs found"
}

# Menu for schedule selection
echo "Select monitoring frequency:"
echo "1) Every 15 minutes"
echo "2) Every 30 minutes"
echo "3) Every hour"
echo "4) Every 4 hours"
echo "5) Twice daily (every 12 hours)"
echo "6) Daily"
echo "7) Custom schedule"
echo ""

read -p "Enter your choice (1-7): " choice

case $choice in
    1)
        schedule="*/15 * * * *"
        job_name="Training Resource Monitor (15min)"
        ;;
    2)
        schedule="*/30 * * * *"
        job_name="Training Resource Monitor (30min)"
        ;;
    3)
        schedule="0 * * * *"
        job_name="Training Resource Monitor (hourly)"
        ;;
    4)
        schedule="0 */4 * * *"
        job_name="Training Resource Monitor (4h)"
        ;;
    5)
        schedule="0 */12 * * *"
        job_name="Training Resource Monitor (12h)"
        ;;
    6)
        schedule="0 2 * * *"
        job_name="Training Resource Monitor (daily)"
        ;;
    7)
        echo "Enter custom cron schedule (e.g., '0 */6 * * *' for every 6 hours):"
        read -p "Schedule: " schedule
        job_name="Training Resource Monitor (custom)"
        ;;
    *)
        echo -e "${RED}❌ Invalid choice${NC}"
        exit 1
        ;;
esac

# Add the cron job
add_cron_job "$schedule" "$job_name"

# Show current cron jobs
echo ""
show_cron_jobs

# Test the cron job
echo ""
echo -e "${YELLOW}🧪 Testing cron job...${NC}"
if "$CRON_SCRIPT"; then
    echo -e "${GREEN}✅ Cron job test successful${NC}"
else
    echo -e "${RED}❌ Cron job test failed${NC}"
    echo "Check the logs at $PROJECT_DIR/resource_monitor.log"
fi

# Setup environment variables
echo ""
echo -e "${BLUE}🔧 Environment Setup:${NC}"
echo "Add these environment variables to your shell profile (~/.bashrc, ~/.zshrc, etc.):"
echo ""
echo "# Training Resource Monitoring"
echo "export AZURE_SUBSCRIPTION_ID=\"$AZURE_SUBSCRIPTION_ID\""
echo "export AZURE_RESOURCE_GROUP=\"$AZURE_RESOURCE_GROUP\""
echo "export AZURE_FUNCTION_APP_NAME=\"$AZURE_FUNCTION_APP_NAME\""
echo "export FUNCTION_URI=\"$FUNCTION_URI\""
echo ""
echo "# Optional: Alert notifications"
echo "# export ALERT_EMAIL=\"your-email@example.com\""
echo "# export SLACK_WEBHOOK_URL=\"https://hooks.slack.com/your-webhook\""

# Create log rotation (optional)
echo ""
echo -e "${YELLOW}📝 Log Rotation:${NC}"
echo "Consider setting up logrotate for $PROJECT_DIR/resource_monitor.log"
echo "Example logrotate config (/etc/logrotate.d/training-monitor):"
echo ""
echo "$PROJECT_DIR/resource_monitor.log {"
echo "    daily"
echo "    rotate 7"
echo "    compress"
echo "    missingok"
echo "    notifempty"
echo "}"

echo ""
echo -e "${GREEN}🎯 Setup completed!${NC}"
echo ""
echo "The monitoring system will:"
echo "  🔍 Check for orphaned training resources"
echo "  🧹 Automatically cleanup orphaned processes"
echo "  📊 Generate reports and logs"
echo "  📤 Send alerts if configured"
echo ""
echo "Monitor logs at: $PROJECT_DIR/resource_monitor.log"
echo "Reports at: $PROJECT_DIR/resource_check_report.json"

# Optional: Setup systemd timer as alternative
if command -v systemctl >/dev/null 2>&1; then
    echo ""
    echo -e "${YELLOW}💡 Alternative: Systemd Timer${NC}"
    echo "For more reliable scheduling on Linux, consider using systemd timers instead of cron."
    echo "Run: ./scripts/setup_systemd_timer.sh"
fi