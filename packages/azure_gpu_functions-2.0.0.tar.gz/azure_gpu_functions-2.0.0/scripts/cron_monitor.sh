#!/bin/bash
"""
Cron Job Script for Automated Resource Monitoring
Run this script periodically to monitor and cleanup training resources
"""

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
LOG_FILE="$PROJECT_DIR/resource_monitor.log"
LOCK_FILE="$PROJECT_DIR/.resource_monitor.lock"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Prevent multiple instances
if [[ -f "$LOCK_FILE" ]]; then
    echo -e "${YELLOW}⚠️ Resource monitor already running (lock file exists)${NC}"
    exit 1
fi

# Create lock file
touch "$LOCK_FILE"
trap 'rm -f "$LOCK_FILE"' EXIT

# Logging function
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $*" | tee -a "$LOG_FILE"
}

log "🔍 Starting automated resource monitoring"

# Check if health check script exists
if [[ ! -x "$SCRIPT_DIR/health_check.sh" ]]; then
    log "❌ Health check script not found or not executable: $SCRIPT_DIR/health_check.sh"
    exit 1
fi

# Run health check with auto-cleanup
cd "$PROJECT_DIR"

# Check for orphaned resources
ORPHANED_COUNT=0

# Run monitoring first
log "📊 Running resource monitoring..."
if python3 "$SCRIPT_DIR/check_training_resources.py" >> "$LOG_FILE" 2>&1; then
    log "✅ Resource monitoring completed"

    # Check results
    if [[ -f "$PROJECT_DIR/resource_check_report.json" ]]; then
        # Count orphaned resources
        RAY_ORPHANED=$(jq '.ray_sessions.orphaned_processes | length' "$PROJECT_DIR/resource_check_report.json" 2>/dev/null || echo "0")
        GPU_ORPHANED=$(jq '.gpu_resources.orphaned_gpu_processes | length' "$PROJECT_DIR/resource_check_report.json" 2>/dev/null || echo "0")
        SESSION_ORPHANED=$(jq '.training_sessions.orphaned_sessions | length' "$PROJECT_DIR/resource_check_report.json" 2>/dev/null || echo "0")

        ORPHANED_COUNT=$((RAY_ORPHANED + GPU_ORPHANED + SESSION_ORPHANED))

        if [[ $ORPHANED_COUNT -gt 0 ]]; then
            log "🚨 Found $ORPHANED_COUNT orphaned resources - running cleanup"

            # Run cleanup
            if "$SCRIPT_DIR/health_check.sh" --auto-cleanup >> "$LOG_FILE" 2>&1; then
                log "✅ Automatic cleanup completed"

                # Check cleanup results
                if [[ -f "$PROJECT_DIR/cleanup_report.json" ]]; then
                    CLEANED=$(jq '.cleaned_resources' "$PROJECT_DIR/cleanup_report.json" 2>/dev/null || echo "0")
                    ERRORS=$(jq '.errors | length' "$PROJECT_DIR/cleanup_report.json" 2>/dev/null || echo "0")

                    log "🧹 Cleanup results: $CLEANED resources cleaned, $ERRORS errors"

                    if [[ $ERRORS -gt 0 ]]; then
                        log "❌ Cleanup completed with errors - check cleanup_report.json"
                    fi
                fi
            else
                log "❌ Automatic cleanup failed"
            fi
        else
            log "✅ No orphaned resources found"
        fi
    else
        log "❌ Resource check report not generated"
    fi
else
    log "❌ Resource monitoring failed"
fi

# Clean up old log files (keep last 7 days)
find "$PROJECT_DIR" -name "resource_check_report.json.*" -mtime +7 -delete 2>/dev/null || true
find "$PROJECT_DIR" -name "cleanup_report.json.*" -mtime +7 -delete 2>/dev/null || true

# Archive current reports with timestamp
if [[ -f "$PROJECT_DIR/resource_check_report.json" ]]; then
    TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
    cp "$PROJECT_DIR/resource_check_report.json" "$PROJECT_DIR/resource_check_report.json.$TIMESTAMP"
fi

if [[ -f "$PROJECT_DIR/cleanup_report.json" ]]; then
    TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
    cp "$PROJECT_DIR/cleanup_report.json" "$PROJECT_DIR/cleanup_report.json.$TIMESTAMP"
fi

log "🎯 Automated resource monitoring completed"

# Optional: Send email alert if issues found
if [[ $ORPHANED_COUNT -gt 0 ]] && [[ -n "$ALERT_EMAIL" ]]; then
    echo "Subject: Training Resource Alert: $ORPHANED_COUNT orphaned resources detected

Automated resource monitoring found $ORPHANED_COUNT orphaned training resources.
Check the logs at $LOG_FILE for details.

Reports:
- $PROJECT_DIR/resource_check_report.json
- $PROJECT_DIR/cleanup_report.json" | \
    sendmail "$ALERT_EMAIL" 2>/dev/null || log "Failed to send email alert"
fi

# Optional: Send Slack alert
if [[ $ORPHANED_COUNT -gt 0 ]] && [[ -n "$SLACK_WEBHOOK_URL" ]]; then
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"🚨 Training Resource Alert: $ORPHANED_COUNT orphaned resources detected. Check logs: $LOG_FILE\"}" \
        "$SLACK_WEBHOOK_URL" 2>/dev/null || log "Failed to send Slack alert"
fi