#!/bin/bash

# Quick Training Test Runner
# Runs individual training tests for validation

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Configuration
FUNCTION_URL="${FUNCTION_URL:-http://localhost:7071/api/train}"
FUNCTION_KEY="${FUNCTION_KEY:-test_key}"

# Sample training data (smaller for quick tests)
SAMPLE_DATA='[
    "Hello world, this is a test.",
    "Machine learning is powerful.",
    "Natural language processing helps.",
    "Deep learning models learn patterns.",
    "Training data affects performance."
]'

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log() {
    echo -e "${BLUE}[$(date '+%H:%M:%S')]${NC} $*" >&2
}

success() {
    echo -e "${GREEN}✓ $*${NC}" >&2
}

error() {
    echo -e "${RED}✗ $*${NC}" >&2
}

warning() {
    echo -e "${YELLOW}⚠ $*${NC}" >&2
}

# Test single training type
test_training_type() {
    local training_type="$1"
    local framework="${2:-pytorch}"
    local expected_duration="${3:-60}"

    log "Testing $training_type training with $framework..."

    local payload=$(cat << EOF
{
    "training_data": $SAMPLE_DATA,
    "training_type": "$training_type",
    "framework": "$framework",
    "enable_cost_tracking": true
}
EOF
)

    local start_time=$(date +%s)
    local response_file=$(mktemp)

    # Make request
    local http_code=$(curl -s -w "%{http_code}" \
        -H "Content-Type: application/json" \
        -H "x-functions-key: $FUNCTION_KEY" \
        -X POST \
        -d "$payload" \
        -o "$response_file" \
        --max-time 300 \
        "$FUNCTION_URL")

    local end_time=$(date +%s)
    local duration=$((end_time - start_time))

    if [ "$http_code" = "200" ]; then
        # Parse response
        if command -v jq >/dev/null 2>&1; then
            local status=$(jq -r '.status' "$response_file" 2>/dev/null)
            local training_duration=$(jq -r '.training_duration_seconds' "$response_file" 2>/dev/null)
            local cost=$(jq -r '.cost_analysis.total_cost_usd' "$response_file" 2>/dev/null)

            if [ "$status" = "success" ]; then
                success "$training_type ($framework) - Duration: ${duration}s, Training: ${training_duration}s, Cost: \$${cost}"
                echo "SUCCESS|$training_type|$framework|$duration|$training_duration|$cost"
            else
                error "$training_type ($framework) - Failed: $status"
                echo "FAILED|$training_type|$framework|$duration|0|0"
            fi
        else
            success "$training_type ($framework) - HTTP 200 (jq not available for details)"
            echo "SUCCESS|$training_type|$framework|$duration|unknown|unknown"
        fi
    else
        error "$training_type ($framework) - HTTP $http_code"
        if [ -s "$response_file" ]; then
            warning "Response: $(cat "$response_file" | head -c 200)"
        fi
        echo "FAILED|$training_type|$framework|$duration|0|0"
    fi

    rm -f "$response_file"
}

# Run all training types
test_all_types() {
    log "Running quick test of all training types..."

    local results_file=$(mktemp)
    local total_cost=0
    local total_time=0
    local success_count=0
    local total_count=0

    # Test each type
    for type in small medium large xl; do
        for framework in pytorch tensorflow; do
            # Skip TensorFlow for XL (not implemented)
            if [ "$framework" = "tensorflow" ] && [ "$type" = "xl" ]; then
                continue
            fi

            total_count=$((total_count + 1))
            result=$(test_training_type "$type" "$framework")
            echo "$result" >> "$results_file"

            if [[ $result == SUCCESS* ]]; then
                success_count=$((success_count + 1))
                # Extract cost and time
                cost=$(echo "$result" | cut -d'|' -f6)
                time_taken=$(echo "$result" | cut -d'|' -f4)
                if [[ $cost =~ ^[0-9.]+$ ]]; then
                    total_cost=$(echo "$total_cost + $cost" | bc 2>/dev/null || echo "$total_cost")
                fi
                if [[ $time_taken =~ ^[0-9]+$ ]]; then
                    total_time=$((total_time + time_taken))
                fi
            fi

            # Small delay between tests
            sleep 1
        done
    done

    # Summary
    echo
    log "Test Summary:"
    echo "Total Tests: $total_count"
    echo "Successful: $success_count"
    echo "Failed: $((total_count - success_count))"
    echo "Success Rate: $((success_count * 100 / total_count))%"
    echo "Total Time: ${total_time}s"
    printf "Total Cost: \$%.4f\n" "$total_cost"

    # Cleanup
    rm -f "$results_file"
}

# Test caching performance
test_caching() {
    log "Testing caching performance..."

    # First run (should be slower)
    log "First run (cache miss expected)..."
    start_time=$(date +%s.%3N)
    test_training_type "small" "pytorch" > /dev/null
    first_duration=$(echo "$(date +%s.%3N) - $start_time" | bc 2>/dev/null || echo "0")

    sleep 2

    # Second run (should be faster due to caching)
    log "Second run (cache hit expected)..."
    start_time=$(date +%s.%3N)
    test_training_type "small" "pytorch" > /dev/null
    second_duration=$(echo "$(date +%s.%3N) - $start_time" | bc 2>/dev/null || echo "0")

    # Calculate improvement
    if (( $(echo "$first_duration > $second_duration" | bc -l 2>/dev/null || echo "0") )); then
        improvement=$(echo "($first_duration - $second_duration) / $first_duration * 100" | bc -l 2>/dev/null || echo "0")
        printf "Caching improvement: %.1f%% faster\n" "$improvement"
        success "Caching is working effectively"
    else
        warning "No significant caching improvement detected"
    fi
}

# Show usage
usage() {
    cat << EOF
Quick Training Test Runner

Usage: $0 [OPTIONS] [COMMAND]

Commands:
    all         Run tests for all training types (default)
    small       Test small training type
    medium      Test medium training type
    large       Test large training type
    xl          Test XL training type
    cache       Test caching performance
    help        Show this help

Options:
    --framework FRAMEWORK    Specify framework (pytorch or tensorflow)
    --url URL                Function URL (default: $FUNCTION_URL)
    --key KEY                Function key (default: $FUNCTION_KEY)

Examples:
    $0 all                    # Test all types
    $0 small                  # Test small type only
    $0 medium --framework tensorflow  # Test medium with TensorFlow
    $0 cache                  # Test caching performance

Environment Variables:
    FUNCTION_URL              Azure Function URL
    FUNCTION_KEY              Azure Function key

EOF
}

# Parse arguments
COMMAND="all"
FRAMEWORK="pytorch"

while [[ $# -gt 0 ]]; do
    case $1 in
        --framework)
            FRAMEWORK="$2"
            shift 2
            ;;
        --url)
            FUNCTION_URL="$2"
            shift 2
            ;;
        --key)
            FUNCTION_KEY="$2"
            shift 2
            ;;
        small|medium|large|xl|all|cache|help)
            COMMAND="$1"
            shift
            ;;
        *)
            error "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Execute command
case $COMMAND in
    all)
        test_all_types
        ;;
    small|medium|large|xl)
        test_training_type "$COMMAND" "$FRAMEWORK"
        ;;
    cache)
        test_caching
        ;;
    help|--help|-h)
        usage
        ;;
    *)
        error "Unknown command: $COMMAND"
        usage
        exit 1
        ;;
esac