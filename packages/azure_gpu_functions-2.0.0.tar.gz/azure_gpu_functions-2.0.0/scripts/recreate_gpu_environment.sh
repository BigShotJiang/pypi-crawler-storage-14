#!/bin/bash

# Recreate Container Apps environment WITH GPU support
set -e

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_GROUP="rg-llm-gpu-function-test"
ENVIRONMENT="gpu-func-env"
LOG_WORKSPACE="log-gpu-func-test"
WORKLOAD_PROFILE_NAME="gpua100"
WORKLOAD_PROFILE_TYPE="NC24-A100"

echo "🔄 Recreating Container Apps Environment with GPU Support"
echo "=========================================================="

# Set subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Delete existing environment (if exists)
echo ""
echo "🗑️  Deleting existing environment..."
az containerapp env delete \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --yes 2>&1 || echo "Note: Environment may not exist"

echo ""
echo "⏳ Waiting for deletion to complete (30 seconds)..."
sleep 30

# Get Log Analytics workspace ID
echo ""
echo "📊 Getting Log Analytics workspace..."
LOG_WORKSPACE_ID=$(az monitor log-analytics workspace show \
    --workspace-name "$LOG_WORKSPACE" \
    --resource-group "$RESOURCE_GROUP" \
    --query customerId -o tsv)

LOG_WORKSPACE_KEY=$(az monitor log-analytics workspace get-shared-keys \
    --workspace-name "$LOG_WORKSPACE" \
    --resource-group "$RESOURCE_GROUP" \
    --query primarySharedKey -o tsv)

# Create NEW environment WITH GPU workload profile
echo ""
echo "🌍 Creating NEW Container Apps environment WITH GPU support..."
az containerapp env create \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --logs-workspace-id "$LOG_WORKSPACE_ID" \
    --logs-workspace-key "$LOG_WORKSPACE_KEY" \
    --enable-workload-profiles

echo ""
echo "⚡ Adding GPU workload profile (NC24-A100)..."
az containerapp env workload-profile add \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --workload-profile-type "$WORKLOAD_PROFILE_TYPE" \
    --min-nodes 1 \
    --max-nodes 1

# Verify workload profiles
echo ""
echo "📋 Verifying workload profiles..."
az containerapp env workload-profile list \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    -o table

echo ""
echo "✅ GPU Environment Created Successfully!"
echo ""
echo "Workload profiles available:"
echo "  - Consumption (default)"
echo "  - $WORKLOAD_PROFILE_NAME (NC24-A100: 24 vCPU, 220GB RAM, 1x A100 GPU)"
echo ""
echo "Next step: Run deploy_gpu_only.sh to deploy the function"
