#!/usr/bin/env python3
"""
Performance Monitoring Script for Azure Functions GPU Training
Monitors startup times, model loading performance, and caching effectiveness
"""

import asyncio
import time
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import aiohttp
import psutil
import GPUtil
from azure.monitor import MonitorClient
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
import matplotlib.pyplot as plt
import pandas as pd

class PerformanceMonitor:
    def __init__(self, function_uri: str, storage_account: str, container_name: str):
        self.function_uri = function_uri.rstrip('/')
        self.storage_account = storage_account
        self.container_name = container_name
        self.credential = DefaultAzureCredential()

        # Initialize Azure clients
        self.blob_service = BlobServiceClient(
            account_url=f"https://{storage_account}.blob.core.windows.net",
            credential=self.credential
        )

        # Performance metrics storage
        self.metrics = {
            'startup_times': [],
            'model_load_times': [],
            'cache_hit_rates': [],
            'gpu_utilization': [],
            'memory_usage': [],
            'cold_starts': 0,
            'total_requests': 0
        }

        # Test configurations
        self.test_models = [
            'gpt2',
            'microsoft/DialoGPT-medium',
            'mistralai/Mistral-7B-v0.1'
        ]

    async def measure_startup_time(self) -> float:
        """Measure function cold start time"""
        start_time = time.time()

        try:
            async with aiohttp.ClientSession() as session:
                # Trigger a cold start by calling status endpoint
                async with session.get(f"{self.function_uri}/api/status") as response:
                    if response.status == 200:
                        startup_time = time.time() - start_time
                        self.metrics['startup_times'].append({
                            'timestamp': datetime.now().isoformat(),
                            'duration': startup_time,
                            'type': 'cold_start'
                        })
                        return startup_time
        except Exception as e:
            print(f"Error measuring startup time: {e}")

        return 0.0

    async def measure_model_loading(self, model_name: str) -> Dict:
        """Measure model loading performance"""
        payload = {
            'action': 'load_model',
            'model': model_name,
            'cache_only': True
        }

        start_time = time.time()
        cache_hit = False

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.function_uri}/api/model-management",
                    json=payload,
                    headers={'Content-Type': 'application/json'}
                ) as response:
                    if response.status == 200:
                        result = await response.json()
                        load_time = time.time() - start_time
                        cache_hit = result.get('cache_hit', False)

                        metric = {
                            'timestamp': datetime.now().isoformat(),
                            'model': model_name,
                            'duration': load_time,
                            'cache_hit': cache_hit,
                            'size_mb': result.get('model_size', 0)
                        }

                        self.metrics['model_load_times'].append(metric)
                        return metric

        except Exception as e:
            print(f"Error measuring model loading for {model_name}: {e}")

        return {}

    async def collect_system_metrics(self):
        """Collect GPU and memory utilization"""
        try:
            # GPU metrics
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu = gpus[0]  # Primary GPU
                self.metrics['gpu_utilization'].append({
                    'timestamp': datetime.now().isoformat(),
                    'utilization': gpu.load * 100,
                    'memory_used': gpu.memoryUsed,
                    'memory_total': gpu.memoryTotal,
                    'temperature': gpu.temperature
                })

            # Memory metrics
            memory = psutil.virtual_memory()
            self.metrics['memory_usage'].append({
                'timestamp': datetime.now().isoformat(),
                'used_percent': memory.percent,
                'used_gb': memory.used / (1024**3),
                'available_gb': memory.available / (1024**3)
            })

        except Exception as e:
            print(f"Error collecting system metrics: {e}")

    async def check_cache_effectiveness(self):
        """Analyze cache hit rates and storage usage"""
        try:
            container_client = self.blob_service.get_container_client(self.container_name)

            # Count cached models
            cached_models = 0
            total_size = 0

            async for blob in container_client.list_blobs():
                cached_models += 1
                total_size += blob.size

            # Calculate cache hit rate from recent requests
            recent_loads = [m for m in self.metrics['model_load_times']
                          if datetime.fromisoformat(m['timestamp']) > datetime.now() - timedelta(hours=1)]

            if recent_loads:
                cache_hits = sum(1 for m in recent_loads if m['cache_hit'])
                hit_rate = (cache_hits / len(recent_loads)) * 100
            else:
                hit_rate = 0.0

            self.metrics['cache_hit_rates'].append({
                'timestamp': datetime.now().isoformat(),
                'hit_rate': hit_rate,
                'cached_models': cached_models,
                'total_cache_size_gb': total_size / (1024**3)
            })

        except Exception as e:
            print(f"Error checking cache effectiveness: {e}")

    async def run_performance_test(self, duration_minutes: int = 5):
        """Run comprehensive performance test"""
        print("🚀 Starting performance monitoring test...")
        print(f"Duration: {duration_minutes} minutes")
        print("=" * 50)

        end_time = datetime.now() + timedelta(minutes=duration_minutes)

        while datetime.now() < end_time:
            # Measure startup time
            startup_time = await self.measure_startup_time()
            if startup_time > 0:
                print(f"🚀 Startup time: {startup_time:.2f}s")
            # Test model loading for each test model
            for model in self.test_models:
                metric = await self.measure_model_loading(model)
                if metric:
                    status = "CACHE HIT" if metric['cache_hit'] else "DOWNLOAD"
                    print(f"📦 {model}: {metric['duration']:.2f}s ({status})")
            # Collect system metrics
            await self.collect_system_metrics()

            # Check cache effectiveness
            await self.check_cache_effectiveness()

            # Wait before next iteration
            await asyncio.sleep(30)  # 30 second intervals

        print("\n✅ Performance test completed!")

    def generate_report(self) -> Dict:
        """Generate performance report"""
        report = {
            'test_summary': {
                'total_requests': len(self.metrics['startup_times']),
                'cold_starts': len([s for s in self.metrics['startup_times'] if s['type'] == 'cold_start']),
                'average_startup_time': 0.0,
                'cache_hit_rate': 0.0,
                'total_model_loads': len(self.metrics['model_load_times'])
            },
            'metrics': self.metrics,
            'recommendations': []
        }

        # Calculate averages
        if self.metrics['startup_times']:
            startup_times = [s['duration'] for s in self.metrics['startup_times']]
            report['test_summary']['average_startup_time'] = sum(startup_times) / len(startup_times)

        if self.metrics['cache_hit_rates']:
            hit_rates = [c['hit_rate'] for c in self.metrics['cache_hit_rates']]
            report['test_summary']['cache_hit_rate'] = sum(hit_rates) / len(hit_rates)

        # Generate recommendations
        avg_startup = report['test_summary']['average_startup_time']
        if avg_startup > 10:
            report['recommendations'].append("Consider increasing pre-warmed instances for faster cold starts")
        elif avg_startup < 2:
            report['recommendations'].append("Excellent startup performance! Caching is working effectively")

        cache_rate = report['test_summary']['cache_hit_rate']
        if cache_rate < 80:
            report['recommendations'].append("Consider preloading more frequently used models")
        else:
            report['recommendations'].append("Cache hit rate is optimal")

        return report

    def save_report(self, filename: str = "performance_report.json"):
        """Save performance report to file"""
        report = self.generate_report()

        with open(filename, 'w') as f:
            json.dump(report, f, indent=2, default=str)

        print(f"📊 Performance report saved to {filename}")

        # Generate summary
        print("\n📈 Performance Summary:")
        print(f"  Average Startup Time: {report['test_summary']['average_startup_time']:.2f}s")
        print(f"  Total Requests: {report['test_summary']['total_requests']}")
        print(f"  Cache Hit Rate: {report['test_summary']['cache_hit_rate']:.1f}%")
        print(f"  Total Model Loads: {report['test_summary']['total_model_loads']}")

        if report['recommendations']:
            print("\n💡 Recommendations:")
            for rec in report['recommendations']:
                print(f"  • {rec}")

async def main():
    # Configuration - update these values based on your deployment
    FUNCTION_URI = os.getenv("FUNCTION_URI", "https://your-function-app.azurewebsites.net")
    STORAGE_ACCOUNT = os.getenv("AZURE_STORAGE_ACCOUNT", "your-storage-account")
    CONTAINER_NAME = os.getenv("MODEL_STORAGE_CONTAINER", "models")

    # Initialize monitor
    monitor = PerformanceMonitor(FUNCTION_URI, STORAGE_ACCOUNT, CONTAINER_NAME)

    # Run performance test
    await monitor.run_performance_test(duration_minutes=5)

    # Generate and save report
    monitor.save_report()

if __name__ == "__main__":
    asyncio.run(main())