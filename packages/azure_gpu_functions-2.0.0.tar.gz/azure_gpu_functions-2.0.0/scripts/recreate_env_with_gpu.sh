#!/bin/bash

# This script deletes and recreates the Container Apps environment with GPU support
# GPU workload profiles MUST be added during environment creation, not after
set -e

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_GROUP="rg-llm-gpu-function-test"
CONTAINER_REGISTRY="acrgpufunctest"
FUNCTION_APP="func-gpu-test"
ENVIRONMENT="gpu-func-env"
IMAGE_NAME="gpu-function-simple:latest"
LOG_WORKSPACE="log-gpu-func-test"
WORKLOAD_PROFILE_NAME="gpua100"
WORKLOAD_PROFILE_TYPE="NC24-A100"

echo "🔄 CRITICAL: Recreating Environment with GPU Support"
echo "====================================================="
echo ""
echo "⚠️  GPU workload profiles MUST be added during environment creation"
echo "⚠️  The existing environment does NOT support GPU profiles"
echo ""

# Set subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Delete existing environment
echo "🗑️  Deleting existing environment..."
az containerapp env delete \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --yes

echo ""
echo "⏳ Waiting for deletion to complete (60 seconds)..."
sleep 60

# Get Log Analytics workspace credentials
echo ""
echo "📊 Getting Log Analytics workspace credentials..."
LOG_WORKSPACE_ID=$(az monitor log-analytics workspace show \
    --workspace-name "$LOG_WORKSPACE" \
    --resource-group "$RESOURCE_GROUP" \
    --query customerId -o tsv)

LOG_WORKSPACE_KEY=$(az monitor log-analytics workspace get-shared-keys \
    --workspace-name "$LOG_WORKSPACE" \
    --resource-group "$RESOURCE_GROUP" \
    --query primarySharedKey -o tsv)

echo "✅ Log Analytics credentials retrieved"

# Create environment with workload profiles enabled
echo ""
echo "🌍 Creating NEW Container Apps environment (with workload profiles enabled)..."
az containerapp env create \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --logs-workspace-id "$LOG_WORKSPACE_ID" \
    --logs-workspace-key "$LOG_WORKSPACE_KEY" \
    --enable-workload-profiles

echo "✅ Environment created with workload profiles support"

# Add GPU workload profile
echo ""
echo "⚡ Adding GPU workload profile (NC24-A100: 24 vCPU, 220GB RAM, 1x A100 GPU)..."
az containerapp env workload-profile add \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --workload-profile-type "$WORKLOAD_PROFILE_TYPE" \
    --min-nodes 1 \
    --max-nodes 1

echo "✅ GPU workload profile added successfully"

# Verify workload profiles
echo ""
echo "📋 Verifying workload profiles..."
az containerapp env workload-profile list \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    -o table

echo ""
echo "✅ GPU Environment Setup Complete!"
echo "==================================="
echo ""
echo "Available workload profiles:"
echo "  - Consumption (default, serverless)"
echo "  - $WORKLOAD_PROFILE_NAME ($WORKLOAD_PROFILE_TYPE: 24 vCPU, 220GB RAM, 1x A100 80GB GPU)"
echo ""
echo "Next step: Deploy the Azure Function with GPU support"
echo "Run: ./deploy_gpu_function.sh"
