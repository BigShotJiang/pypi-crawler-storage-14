#!/bin/bash

# Training Performance Test Script
# Tests 10 training executions across different types (Small, Medium, Large, XL)
# Measures launch speed, ensures caching, and calculates costs

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
LOG_FILE="$SCRIPT_DIR/training_performance_test_$(date +%Y%m%d_%H%M%S).log"
RESULTS_FILE="$SCRIPT_DIR/training_performance_results.json"

# Configuration
FUNCTION_URL="${FUNCTION_URL:-http://localhost:7071/api/train}"
FUNCTION_KEY="${FUNCTION_KEY:-test_key}"
TEST_ITERATIONS=10

# Training configurations for testing
TRAINING_TYPES=("small" "medium" "large" "xl")
FRAMEWORKS=("pytorch" "tensorflow")

# Sample training data
SAMPLE_DATA='[
    "Hello world, this is a test sentence for training.",
    "Machine learning is fascinating and powerful.",
    "Natural language processing helps computers understand text.",
    "Deep learning models can learn complex patterns.",
    "Training data quality affects model performance.",
    "Fine-tuning adapts pre-trained models to specific tasks.",
    "GPU acceleration speeds up neural network training.",
    "Distributed training scales model training across multiple devices.",
    "Model caching reduces startup time and costs.",
    "Cost optimization is important for production ML systems."
]'

# Logging function
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $*" | tee -a "$LOG_FILE"
}

# Initialize results
init_results() {
    cat > "$RESULTS_FILE" << EOF
{
    "test_metadata": {
        "start_time": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
        "test_iterations": $TEST_ITERATIONS,
        "function_url": "$FUNCTION_URL",
        "environment": "azure_functions_gpu"
    },
    "training_results": [],
    "performance_metrics": {
        "total_tests": 0,
        "successful_tests": 0,
        "failed_tests": 0,
        "average_launch_time_seconds": 0,
        "average_training_duration_seconds": 0,
        "total_cost_usd": 0,
        "cache_hit_rate": 0
    },
    "caching_analysis": {
        "dependencies_cached": false,
        "models_cached": false,
        "artifacts_cached": false
    }
}
EOF
}

# Update results with test outcome
update_results() {
    local test_result="$1"
    local jq_filter

    # Add test result to array
    jq_filter=".training_results += [$test_result]"
    jq "$jq_filter" "$RESULTS_FILE" > "${RESULTS_FILE}.tmp" && mv "${RESULTS_FILE}.tmp" "$RESULTS_FILE"

    # Update performance metrics
    local total_tests=$(jq '.training_results | length' "$RESULTS_FILE")
    local successful_tests=$(jq '[.training_results[] | select(.status == "success")] | length' "$RESULTS_FILE")
    local failed_tests=$((total_tests - successful_tests))

    local avg_launch_time=$(jq '[.training_results[] | select(.launch_time_seconds) | .launch_time_seconds] | if length > 0 then add / length else 0 end' "$RESULTS_FILE")
    local avg_training_duration=$(jq '[.training_results[] | select(.training_duration_seconds) | .training_duration_seconds] | if length > 0 then add / length else 0 end' "$RESULTS_FILE")
    local total_cost=$(jq '[.training_results[] | select(.cost_usd) | .cost_usd] | add' "$RESULTS_FILE")

    jq_filter=".performance_metrics = {
        \"total_tests\": $total_tests,
        \"successful_tests\": $successful_tests,
        \"failed_tests\": $failed_tests,
        \"average_launch_time_seconds\": $avg_launch_time,
        \"average_training_duration_seconds\": $avg_training_duration,
        \"total_cost_usd\": $total_cost,
        \"cache_hit_rate\": 0
    }"
    jq "$jq_filter" "$RESULTS_FILE" > "${RESULTS_FILE}.tmp" && mv "${RESULTS_FILE}.tmp" "$RESULTS_FILE"
}

# Run single training test
run_training_test() {
    local test_id="$1"
    local training_type="$2"
    local framework="$3"
    local iteration="$4"

    log "Starting test $test_id: $training_type training with $framework (iteration $iteration)"

    local start_time=$(date +%s.%3N)
    local launch_start=$start_time

    # Prepare request payload
    local payload=$(cat << EOF
{
    "training_data": $SAMPLE_DATA,
    "training_type": "$training_type",
    "framework": "$framework",
    "enable_cost_tracking": true
}
EOF
)

    # Make HTTP request and capture timing
    local response_file=$(mktemp)
    local curl_start=$(date +%s.%3N)

    local http_code=$(curl -s -w "%{http_code}" \
        -H "Content-Type: application/json" \
        -H "x-functions-key: $FUNCTION_KEY" \
        -X POST \
        -d "$payload" \
        -o "$response_file" \
        "$FUNCTION_URL" 2>/dev/null)

    local curl_end=$(date +%s.%3N)
    local request_duration=$(echo "$curl_end - $curl_start" | bc 2>/dev/null || echo "0")

    local end_time=$(date +%s.%3N)
    local total_duration=$(echo "$end_time - $start_time" | bc 2>/dev/null || echo "0")

    # Parse response
    local status="unknown"
    local training_duration=0
    local cost_usd=0
    local error_msg=""

    if [ "$http_code" = "200" ]; then
        # Parse successful response
        if command -v jq >/dev/null 2>&1; then
            status=$(jq -r '.status // "unknown"' "$response_file" 2>/dev/null || echo "parse_error")
            training_duration=$(jq -r '.training_duration_seconds // 0' "$response_file" 2>/dev/null || echo "0")
            cost_usd=$(jq -r '.cost_analysis.total_cost_usd // 0' "$response_file" 2>/dev/null || echo "0")
        else
            # Fallback parsing without jq
            if grep -q '"status": "success"' "$response_file"; then
                status="success"
            fi
        fi
        log "Test $test_id completed successfully (HTTP $http_code)"
    else
        status="failed"
        error_msg="HTTP $http_code"
        log "Test $test_id failed (HTTP $http_code)"
    fi

    # Calculate launch time (time to first response)
    local launch_time=$(echo "$curl_end - $launch_start" | bc 2>/dev/null || echo "0")

    # Create test result JSON
    local test_result=$(cat << EOF
{
    "test_id": "$test_id",
    "training_type": "$training_type",
    "framework": "$framework",
    "iteration": $iteration,
    "status": "$status",
    "http_code": "$http_code",
    "launch_time_seconds": $launch_time,
    "request_duration_seconds": $request_duration,
    "training_duration_seconds": $training_duration,
    "total_duration_seconds": $total_duration,
    "cost_usd": $cost_usd,
    "error_message": "$error_msg",
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF
)

    # Update results
    update_results "$test_result"

    # Cleanup
    rm -f "$response_file"

    return 0
}

# Check caching status
check_caching() {
    log "Checking dependency and artifact caching status..."

    # Check if models are cached
    local model_cache_dir="$HOME/.cache/huggingface"
    if [ -d "$model_cache_dir" ] && [ "$(find "$model_cache_dir" -name "*.bin" -o -name "*.safetensors" | wc -l)" -gt 0 ]; then
        log "✓ Model artifacts are cached"
        jq '.caching_analysis.models_cached = true' "$RESULTS_FILE" > "${RESULTS_FILE}.tmp" && mv "${RESULTS_FILE}.tmp" "$RESULTS_FILE"
    else
        log "✗ Model artifacts not cached"
    fi

    # Check Python packages
    if python3 -c "import torch, transformers, datasets, peft" 2>/dev/null; then
        log "✓ Python dependencies are available"
        jq '.caching_analysis.dependencies_cached = true' "$RESULTS_FILE" > "${RESULTS_FILE}.tmp" && mv "${RESULTS_FILE}.tmp" "$RESULTS_FILE"
    else
        log "✗ Python dependencies not available"
    fi
}

# Generate test report
generate_report() {
    log "Generating performance test report..."

    local report_file="$SCRIPT_DIR/training_performance_report_$(date +%Y%m%d_%H%M%S).md"

    cat > "$report_file" << EOF
# Training Performance Test Report

Generated: $(date)

## Test Summary

- **Total Tests**: $(jq '.performance_metrics.total_tests' "$RESULTS_FILE")
- **Successful Tests**: $(jq '.performance_metrics.successful_tests' "$RESULTS_FILE")
- **Failed Tests**: $(jq '.performance_metrics.failed_tests' "$RESULTS_FILE")
- **Success Rate**: $(jq '(.performance_metrics.successful_tests / .performance_metrics.total_tests * 100)' "$RESULTS_FILE")%

## Performance Metrics

- **Average Launch Time**: $(jq '.performance_metrics.average_launch_time_seconds' "$RESULTS_FILE") seconds
- **Average Training Duration**: $(jq '.performance_metrics.average_training_duration_seconds' "$RESULTS_FILE") seconds
- **Total Cost**: \$ $(jq '.performance_metrics.total_cost_usd' "$RESULTS_FILE")

## Caching Analysis

- **Dependencies Cached**: $(jq '.caching_analysis.dependencies_cached' "$RESULTS_FILE")
- **Models Cached**: $(jq '.caching_analysis.models_cached' "$RESULTS_FILE")
- **Artifacts Cached**: $(jq '.caching_analysis.artifacts_cached' "$RESULTS_FILE")

## Training Type Performance

| Training Type | Tests | Success Rate | Avg Launch (s) | Avg Duration (s) | Avg Cost (\$) |
|---------------|-------|--------------|----------------|------------------|--------------|
EOF

    # Add per-type statistics
    for type in "${TRAINING_TYPES[@]}"; do
        local type_results=$(jq ".training_results[] | select(.training_type == \"$type\")" "$RESULTS_FILE")
        local type_count=$(echo "$type_results" | jq -s 'length')
        local type_success=$(echo "$type_results" | jq -s '[.[] | select(.status == "success")] | length')
        local type_success_rate=0
        if [ "$type_count" -gt 0 ]; then
            type_success_rate=$(echo "scale=2; $type_success / $type_count * 100" | bc 2>/dev/null || echo "0")
        fi
        local type_avg_launch=$(echo "$type_results" | jq -s '[.[] | select(.launch_time_seconds) | .launch_time_seconds] | if length > 0 then add / length else 0 end')
        local type_avg_duration=$(echo "$type_results" | jq -s '[.[] | select(.training_duration_seconds) | .training_duration_seconds] | if length > 0 then add / length else 0 end')
        local type_avg_cost=$(echo "$type_results" | jq -s '[.[] | select(.cost_usd) | .cost_usd] | if length > 0 then add / length else 0 end')

        cat >> "$report_file" << EOF
| $type | $type_count | ${type_success_rate}% | $type_avg_launch | $type_avg_duration | $type_avg_cost |
EOF
    done

    cat >> "$report_file" << EOF

## Recommendations

EOF

    # Add recommendations based on results
    local avg_launch=$(jq '.performance_metrics.average_launch_time_seconds' "$RESULTS_FILE")
    if (( $(echo "$avg_launch > 30" | bc -l 2>/dev/null || echo "0") )); then
        echo "- **Launch Time**: Consider optimizing model loading and caching to reduce launch times" >> "$report_file"
    fi

    local success_rate=$(jq '(.performance_metrics.successful_tests / .performance_metrics.total_tests * 100)' "$RESULTS_FILE")
    if (( $(echo "$success_rate < 80" | bc -l 2>/dev/null || echo "0") )); then
        echo "- **Success Rate**: Investigate and fix failing tests to improve reliability" >> "$report_file"
    fi

    if [ "$(jq '.caching_analysis.models_cached' "$RESULTS_FILE")" = "false" ]; then
        echo "- **Caching**: Implement model caching to reduce startup times and costs" >> "$report_file"
    fi

    cat >> "$report_file" << EOF

## Detailed Results

See \`$RESULTS_FILE\` for complete JSON results and \`$LOG_FILE\` for execution logs.

EOF

    log "Report generated: $report_file"
}

# Main execution
main() {
    log "Starting Training Performance Test Suite"
    log "Test iterations: $TEST_ITERATIONS"
    log "Function URL: $FUNCTION_URL"

    # Initialize results file
    init_results

    # Check caching status
    check_caching

    # Run tests
    local test_counter=1
    for ((i=1; i<=TEST_ITERATIONS; i++)); do
        for training_type in "${TRAINING_TYPES[@]}"; do
            for framework in "${FRAMEWORKS[@]}"; do
                # Skip TensorFlow for large/XL if not available
                if [ "$framework" = "tensorflow" ] && [ "$training_type" = "xl" ]; then
                    continue
                fi

                run_training_test "$test_counter" "$training_type" "$framework" "$i"
                test_counter=$((test_counter + 1))

                # Small delay between tests
                sleep 2
            done
        done
    done

    # Generate final report
    generate_report

    log "Training Performance Test Suite completed"
    log "Results: $RESULTS_FILE"
    log "Logs: $LOG_FILE"
}

# Run main function
main "$@"