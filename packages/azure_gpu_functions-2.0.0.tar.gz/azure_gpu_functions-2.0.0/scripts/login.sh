#!/bin/bash

# Azure login and deployment helper script

TENANT_ID="7d7761c0-8b7a-49bb-8975-a6aa1be7c38b"
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"

echo "🔐 Azure Authentication Required"
echo "================================="
echo ""
echo "Your Azure session has expired. Please login again."
echo ""

# Logout first
echo "Logging out..."
az logout 2>/dev/null || true

# Login
echo ""
echo "Please login with your Azure credentials..."
az login --tenant "$TENANT_ID" --scope "https://management.core.windows.net//.default"

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Login successful!"
    echo ""
    
    # Set subscription
    echo "Setting subscription..."
    az account set --subscription "$SUBSCRIPTION_ID"
    
    echo ""
    echo "✅ Authentication complete!"
    echo ""
    echo "You can now run the deployment:"
    echo "  ./deploy_simple.sh"
    echo ""
else
    echo ""
    echo "❌ Login failed. Please try again."
    exit 1
fi
