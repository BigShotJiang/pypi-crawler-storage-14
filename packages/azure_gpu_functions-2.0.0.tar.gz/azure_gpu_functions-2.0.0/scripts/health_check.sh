#!/bin/bash
"""
Training Resource Health Check Script
Combines monitoring and cleanup operations
"""

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
MONITORING_REPORT="$PROJECT_DIR/resource_check_report.json"
CLEANUP_REPORT="$PROJECT_DIR/cleanup_report.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Default settings
DRY_RUN=true
EMERGENCY=false
AUTO_CLEANUP=false

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --wet-run)
            DRY_RUN=false
            shift
            ;;
        --emergency)
            EMERGENCY=true
            DRY_RUN=false
            shift
            ;;
        --auto-cleanup)
            AUTO_CLEANUP=true
            shift
            ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --wet-run      Perform actual cleanup (not dry-run)"
            echo "  --emergency    Emergency cleanup - kill ALL training processes"
            echo "  --auto-cleanup Automatically cleanup orphaned resources"
            echo "  --help         Show this help message"
            echo ""
            echo "Environment Variables:"
            echo "  FUNCTION_URI   Azure Function URI for API calls"
            echo "  AZURE_SUBSCRIPTION_ID  Azure subscription ID"
            echo "  AZURE_RESOURCE_GROUP   Azure resource group name"
            echo "  AZURE_FUNCTION_APP_NAME Function app name"
            exit 0
            ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

echo -e "${BLUE}🔍 Training Resource Health Check${NC}"
echo "=================================="

# Function to check if Python script exists and is executable
check_python_script() {
    local script="$1"
    if [[ ! -f "$script" ]]; then
        echo -e "${RED}❌ Python script not found: $script${NC}"
        exit 1
    fi

    if [[ ! -x "$script" ]]; then
        echo -e "${YELLOW}⚠️ Making script executable: $script${NC}"
        chmod +x "$script"
    fi
}

# Check required scripts
check_python_script "$SCRIPT_DIR/check_training_resources.py"
check_python_script "$SCRIPT_DIR/cleanup_resources.py"

# Step 1: Run monitoring
echo -e "${YELLOW}📊 Step 1: Running resource monitoring...${NC}"
cd "$PROJECT_DIR"

if [[ -n "$FUNCTION_URI" ]]; then
    python3 "$SCRIPT_DIR/check_training_resources.py"
else
    echo -e "${YELLOW}ℹ️ FUNCTION_URI not set, skipping training session checks${NC}"
    python3 "$SCRIPT_DIR/check_training_resources.py"
fi

# Check if monitoring found issues
if [[ -f "$MONITORING_REPORT" ]]; then
    # Check for orphaned resources in the report
    ORPHANED_PROCESSES=$(jq '.ray_sessions.orphaned_processes | length' "$MONITORING_REPORT" 2>/dev/null || echo "0")
    ORPHANED_GPU=$(jq '.gpu_resources.orphaned_gpu_processes | length' "$MONITORING_REPORT" 2>/dev/null || echo "0")
    ORPHANED_SESSIONS=$(jq '.training_sessions.orphaned_sessions | length' "$MONITORING_REPORT" 2>/dev/null || echo "0")

    TOTAL_ORPHANED=$((ORPHANED_PROCESSES + ORPHANED_GPU + ORPHANED_SESSIONS))

    if [[ $TOTAL_ORPHANED -gt 0 ]]; then
        echo -e "${RED}🚨 Found $TOTAL_ORPHANED orphaned resources!${NC}"
        echo "   - Ray processes: $ORPHANED_PROCESSES"
        echo "   - GPU processes: $ORPHANED_GPU"
        echo "   - Training sessions: $ORPHANED_SESSIONS"

        if [[ "$AUTO_CLEANUP" == "true" ]] || [[ "$EMERGENCY" == "true" ]]; then
            echo -e "${YELLOW}🧹 Step 2: Running cleanup...${NC}"

            CLEANUP_ARGS=""
            if [[ "$DRY_RUN" == "false" ]]; then
                CLEANUP_ARGS="$CLEANUP_ARGS --wet-run"
            fi

            if [[ "$EMERGENCY" == "true" ]]; then
                CLEANUP_ARGS="$CLEANUP_ARGS --emergency"
            fi

            if [[ -n "$FUNCTION_URI" ]]; then
                CLEANUP_ARGS="$CLEANUP_ARGS --function-uri $FUNCTION_URI"
            fi

            python3 "$SCRIPT_DIR/cleanup_resources.py" $CLEANUP_ARGS --monitoring-report "$MONITORING_REPORT"

            # Check cleanup results
            if [[ -f "$CLEANUP_REPORT" ]]; then
                CLEANED_RESOURCES=$(jq '.cleaned_resources' "$CLEANUP_REPORT" 2>/dev/null || echo "0")
                CLEANUP_ERRORS=$(jq '.errors | length' "$CLEANUP_REPORT" 2>/dev/null || echo "0")

                if [[ $CLEANUP_ERRORS -gt 0 ]]; then
                    echo -e "${RED}❌ Cleanup completed with $CLEANUP_ERRORS errors${NC}"
                else
                    echo -e "${GREEN}✅ Cleanup completed successfully - $CLEANED_RESOURCES resources cleaned${NC}"
                fi
            fi
        else
            echo -e "${YELLOW}💡 To cleanup automatically, run with --auto-cleanup${NC}"
            echo -e "${YELLOW}💡 For emergency cleanup (kills ALL processes), use --emergency${NC}"
        fi
    else
        echo -e "${GREEN}✅ No orphaned resources found - system is clean!${NC}"
    fi
else
    echo -e "${RED}❌ Monitoring report not generated${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}📋 Summary:${NC}"
echo "  📊 Monitoring Report: $MONITORING_REPORT"
if [[ -f "$CLEANUP_REPORT" ]]; then
    echo "  🧹 Cleanup Report: $CLEANUP_REPORT"
fi
echo ""
echo -e "${GREEN}🎯 Health check completed!${NC}"

# Optional: Send alert if issues found
if [[ $TOTAL_ORPHANED -gt 0 ]] && [[ -n "$SLACK_WEBHOOK_URL" ]]; then
    echo -e "${YELLOW}📤 Sending alert to Slack...${NC}"
    curl -X POST -H 'Content-type: application/json' \
        --data "{\"text\":\"🚨 Training Resource Alert: $TOTAL_ORPHANED orphaned resources detected\"}" \
        "$SLACK_WEBHOOK_URL" 2>/dev/null || true
fi