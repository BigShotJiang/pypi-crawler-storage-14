#!/bin/bash

# Sweden Central GPU Training Test Script
# Tests neural network training functionality on approved GPU quotas
# Supports both A100 and T4 GPU testing

set -e

# GPU Type Selection
GPU_TYPE=${1:-"A100"}  # Default to A100, can pass "T4" as argument

# Configuration - Using the quota-approved environment
RESOURCE_GROUP="rg-gpu-quota-swedencentral"

case $GPU_TYPE in
    "A100")
        FUNCTION_NAME="gpu-function-a100-training"
        EXPECTED_DEVICE="cuda"
        ;;
    "T4")
        FUNCTION_NAME="gpu-function-t4-training"
        EXPECTED_DEVICE="cuda"
        ;;
    *)
        echo "❌ Invalid GPU type. Use 'A100' or 'T4'"
        exit 1
        ;;
esac

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🧠 Sweden Central $GPU_TYPE GPU Training Test Script${NC}"
echo "=================================================="
echo ""

# Get function URL
FUNCTION_URL=$(az containerapp show \
    --name $FUNCTION_NAME \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv 2>/dev/null)

if [ -z "$FUNCTION_URL" ]; then
    echo -e "${RED}❌ Function $FUNCTION_NAME not found. Please deploy first.${NC}"
    echo -e "${YELLOW}Run: ./deploy_swedencentral_gpu.sh $GPU_TYPE${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Function URL: https://$FUNCTION_URL${NC}"
echo ""

# Function to test endpoint
test_endpoint() {
    local url=$1
    local description=$2
    local expected_status=${3:-200}

    echo -e "${YELLOW}Testing: $description${NC}"
    echo -e "${BLUE}URL: $url${NC}"

    response=$(curl -s -w "\nHTTPSTATUS:%{http_code}" "$url")
    http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    body=$(echo "$response" | sed -e 's/HTTPSTATUS:.*//g')

    if [ "$http_code" -eq "$expected_status" ]; then
        echo -e "${GREEN}✅ HTTP $http_code - Success${NC}"

        # Parse and display key metrics for training
        if [[ $url == *"gpu-training"* ]]; then
            echo -e "${BLUE}Training Results:${NC}"

            # Extract key metrics
            training_time=$(echo "$body" | jq -r '.results.total_training_time_seconds // empty' 2>/dev/null)
            final_loss=$(echo "$body" | jq -r '.results.final_loss // empty' 2>/dev/null)
            test_accuracy=$(echo "$body" | jq -r '.results.test_accuracy // empty' 2>/dev/null)
            memory_peak=$(echo "$body" | jq -r '.results.memory_peak_gb // empty' 2>/dev/null)
            device=$(echo "$body" | jq -r '.device // empty' 2>/dev/null)

            if [ -n "$training_time" ]; then
                echo "  ⏱️  Training Time: $training_time seconds"
            fi
            if [ -n "$final_loss" ]; then
                echo "  📉 Final Loss: $final_loss"
            fi
            if [ -n "$test_accuracy" ]; then
                echo "  🎯 Test Accuracy: $test_accuracy"
            fi
            if [ -n "$memory_peak" ]; then
                echo "  🧠 Memory Peak: $memory_peak GB"
            fi
            if [ -n "$device" ]; then
                echo "  💻 Device: $device"
                if [ "$device" = "$EXPECTED_DEVICE" ]; then
                    echo -e "  ${GREEN}✅ GPU detected correctly${NC}"
                else
                    echo -e "  ${RED}❌ Expected $EXPECTED_DEVICE but got $device${NC}"
                fi
            fi
        fi

        # Display response body for non-training endpoints
        if [[ $url != *"gpu-training"* ]]; then
            echo -e "${BLUE}Response:${NC}"
            echo "$body" | jq '.' 2>/dev/null || echo "$body"
        fi

    else
        echo -e "${RED}❌ HTTP $http_code - Failed${NC}"
        echo -e "${RED}Response: $body${NC}"
        return 1
    fi

    echo ""
}

# Test 1: Health Check
test_endpoint "https://$FUNCTION_URL/api/health" "Health Check"

# Test 2: GPU Status
test_endpoint "https://$FUNCTION_URL/api/gpu-status" "GPU Status Check"

# Test 3: GPU Test (matrix multiplication)
test_endpoint "https://$FUNCTION_URL/api/gpu-test" "GPU Test (Matrix Multiplication)"

# Test 4: Default GPU Training (10 epochs)
echo -e "${BLUE}🧠 Testing $GPU_TYPE GPU Training Scenarios${NC}"
echo "=========================================="
test_endpoint "https://$FUNCTION_URL/api/gpu-training" "Default GPU Training (10 epochs)"

# Test 5: Extended Training (50 epochs)
test_endpoint "https://$FUNCTION_URL/api/gpu-training?epochs=50" "Extended GPU Training (50 epochs)"

# Test 6: Large Batch Training
test_endpoint "https://$FUNCTION_URL/api/gpu-training?batch_size=256" "Large Batch GPU Training (256 batch size)"

# Test 7: Custom Training Parameters
echo -e "${YELLOW}Testing: Custom GPU Training Parameters${NC}"
echo -e "${BLUE}URL: https://$FUNCTION_URL/api/gpu-training${NC}"

custom_response=$(curl -s -X POST \
    -H "Content-Type: application/json" \
    -d '{"epochs": 20, "batch_size": 64, "learning_rate": 0.01}' \
    -w "\nHTTPSTATUS:%{http_code}" \
    "https://$FUNCTION_URL/api/gpu-training")

custom_http_code=$(echo "$custom_response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
custom_body=$(echo "$custom_response" | sed -e 's/HTTPSTATUS:.*//g')

if [ "$custom_http_code" -eq "200" ]; then
    echo -e "${GREEN}✅ HTTP 200 - Custom Training Success${NC}"

    # Extract custom training metrics
    custom_time=$(echo "$custom_body" | jq -r '.results.total_training_time_seconds // empty' 2>/dev/null)
    custom_accuracy=$(echo "$custom_body" | jq -r '.results.test_accuracy // empty' 2>/dev/null)

    if [ -n "$custom_time" ]; then
        echo "  ⏱️  Custom Training Time: $custom_time seconds"
    fi
    if [ -n "$custom_accuracy" ]; then
        echo "  🎯 Custom Test Accuracy: $custom_accuracy"
    fi
else
    echo -e "${RED}❌ HTTP $custom_http_code - Custom Training Failed${NC}"
fi

echo ""
echo -e "${GREEN}🎉 $GPU_TYPE GPU Training Tests Complete!${NC}"
echo ""
echo -e "${BLUE}📊 Test Summary:${NC}"
echo "  ✅ Health Check"
echo "  ✅ GPU Status"
echo "  ✅ GPU Matrix Test"
echo "  ✅ Default Training (10 epochs)"
echo "  ✅ Extended Training (50 epochs)"
echo "  ✅ Large Batch Training"
echo "  ✅ Custom Parameters Training"
echo ""
echo -e "${YELLOW}💡 $GPU_TYPE GPU Performance Expectations:${NC}"

if [ "$GPU_TYPE" = "A100" ]; then
    echo "  • Training Time: 2-5 seconds per epoch"
    echo "  • Memory Usage: 2-8 GB peak"
    echo "  • Accuracy: 85-95% after 50 epochs"
    echo "  • Device: cuda (A100 GPU)"
else
    echo "  • Training Time: 5-15 seconds per epoch"
    echo "  • Memory Usage: 1-4 GB peak"
    echo "  • Accuracy: 80-90% after 50 epochs"
    echo "  • Device: cuda (T4 GPU)"
fi

echo ""
echo -e "${GREEN}✅ $GPU_TYPE GPU validation successful!${NC}"