#!/bin/bash

# CPU-Only Test Deployment for Azure Functions
# This script deploys the GPU function to a CPU-only environment to validate functionality
# before switching to GPU once quota is approved

set -e

echo "🚀 Starting CPU-only test deployment..."

# Configuration
RESOURCE_GROUP="rg-gpu-func-test"
LOCATION="swedencentral"  # Changed to Sweden Central for Consumption GPU availability
ENVIRONMENT_NAME="gpu-func-env-cpu-test"
ACR_NAME="acrgpufunctest"
STORAGE_ACCOUNT_NAME="stgpufunctest"
LOG_ANALYTICS_NAME="log-gpu-func-test"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}📋 Configuration:${NC}"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION"
echo "  Environment: $ENVIRONMENT_NAME"
echo "  ACR: $ACR_NAME"
echo "  Storage: $STORAGE_ACCOUNT_NAME"
echo ""

# Check if logged in to Azure
echo -e "${YELLOW}🔐 Checking Azure login...${NC}"
if ! az account show > /dev/null 2>&1; then
    echo -e "${RED}❌ Not logged in to Azure. Please run 'az login' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Azure login confirmed${NC}"

# Create resource group if it doesn't exist
echo -e "${YELLOW}📁 Creating resource group...${NC}"
az group create --name $RESOURCE_GROUP --location $LOCATION --output none

# Get Log Analytics credentials
echo -e "${YELLOW}📊 Getting Log Analytics credentials...${NC}"
LOG_ANALYTICS_ID=$(az monitor diagnostic-settings list --resource /subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP --query "[0].workspaceId" -o tsv 2>/dev/null || echo "")

if [ -z "$LOG_ANALYTICS_ID" ]; then
    echo -e "${YELLOW}🔧 Creating Log Analytics workspace...${NC}"
    az monitor log-analytics workspace create \
        --resource-group $RESOURCE_GROUP \
        --name $LOG_ANALYTICS_NAME \
        --location $LOCATION \
        --output none

    LOG_ANALYTICS_ID=$(az monitor log-analytics workspace show \
        --resource-group $RESOURCE_GROUP \
        --name $LOG_ANALYTICS_NAME \
        --query id -o tsv)
fi

LOG_ANALYTICS_KEY=$(az monitor log-analytics workspace get-shared-keys \
    --resource-group $RESOURCE_GROUP \
    --name $LOG_ANALYTICS_NAME \
    --query primarySharedKey -o tsv)

echo -e "${GREEN}✅ Log Analytics configured${NC}"

# Create storage account if it doesn't exist
echo -e "${YELLOW}💾 Creating storage account...${NC}"
az storage account create \
    --name $STORAGE_ACCOUNT_NAME \
    --resource-group $RESOURCE_GROUP \
    --location $LOCATION \
    --sku Standard_LRS \
    --output none 2>/dev/null || echo "Storage account already exists"

STORAGE_CONNECTION_STRING=$(az storage account show-connection-string \
    --name $STORAGE_ACCOUNT_NAME \
    --resource-group $RESOURCE_GROUP \
    --output tsv)

echo -e "${GREEN}✅ Storage account configured${NC}"

# Deploy CPU-only Container Apps environment
echo -e "${YELLOW}🏗️  Deploying CPU-only Container Apps environment...${NC}"

# Create parameters file for CPU deployment
cat > infrastructure/main.parameters.cpu.json << EOF
{
    "\$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
    "contentVersion": "1.0.0.0",
    "parameters": {
        "location": {
            "value": "$LOCATION"
        },
        "environmentName": {
            "value": "$ENVIRONMENT_NAME"
        },
        "logAnalyticsCustomerId": {
            "value": "$(basename $LOG_ANALYTICS_ID)"
        },
        "logAnalyticsSharedKey": {
            "value": "$LOG_ANALYTICS_KEY"
        },
        "gpuWorkloadProfileName": {
            "value": "cpu-test-profile"
        },
        "gpuWorkloadProfileType": {
            "value": "NC24-A100"
        },
        "gpuMinNodes": {
            "value": 0
        },
        "gpuMaxNodes": {
            "value": 0
        }
    }
}
EOF

# Deploy Bicep template
az deployment group create \
    --resource-group $RESOURCE_GROUP \
    --template-file infrastructure/main.bicep \
    --parameters infrastructure/main.parameters.cpu.json \
    --output none

echo -e "${GREEN}✅ CPU-only environment deployed${NC}"

# Get environment details
ENVIRONMENT_ID=$(az containerapp env show \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --query id -o tsv)

echo -e "${GREEN}✅ Environment ID: $ENVIRONMENT_ID${NC}"

# Deploy the function app (CPU-only for testing)
echo -e "${YELLOW}🚀 Deploying Azure Function (CPU-only test)...${NC}"

az containerapp create \
    --name gpu-function-cpu-test \
    --resource-group $RESOURCE_GROUP \
    --environment $ENVIRONMENT_ID \
    --image $ACR_NAME.azurecr.io/gpu-function-simple:latest \
    --registry-server $ACR_NAME.azurecr.io \
    --registry-username $ACR_NAME \
    --registry-password $(az acr credential show --name $ACR_NAME --query passwords[0].value -o tsv) \
    --cpu 1.0 \
    --memory 2.0Gi \
    --min-replicas 0 \
    --max-replicas 1 \
    --workload-profile-name Consumption \
    --target-port 80 \
    --ingress external \
    --output none

echo -e "${GREEN}✅ Azure Function deployed (CPU-only)${NC}"

# Get function URL
FUNCTION_URL=$(az containerapp show \
    --name gpu-function-cpu-test \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv)

echo ""
echo -e "${GREEN}🎉 CPU-Only Test Deployment Complete!${NC}"
echo ""
echo -e "${BLUE}📋 Test URLs:${NC}"
echo "  Health Check: https://$FUNCTION_URL/api/health"
echo "  GPU Status:   https://$FUNCTION_URL/api/gpu-status"
echo "  GPU Test:     https://$FUNCTION_URL/api/gpu-test"
echo ""
echo -e "${YELLOW}⚠️  Note: GPU endpoints will show 'No GPU available' since we're using CPU-only${NC}"
echo "     This validates the function logic works before GPU quota approval."
echo ""
echo -e "${BLUE}🔄 Next Steps:${NC}"
echo "  1. Test the function endpoints above"
echo "  2. Wait for GPU quota approval"
echo "  3. Run GPU deployment: ./deploy_gpu_function.sh"
echo ""
echo -e "${GREEN}✅ Ready for GPU upgrade once quota is approved!${NC}"