#!/bin/bash

# Simple deployment script for Azure Function with GPU using Azure CLI only
# No Azure Developer CLI (azd) required

set -e

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_GROUP="rg-llm-gpu-function-test"
CONTAINER_REGISTRY="acrgpufunctest"
FUNCTION_APP="func-gpu-test"
ENVIRONMENT="gpu-func-env"
IMAGE_NAME="gpu-function-simple:latest"
WORKLOAD_PROFILE_NAME="gpua100"
WORKLOAD_PROFILE_TYPE="NC24-A100"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🚀 Simple Azure Function GPU Deployment${NC}"
echo "=========================================="
echo ""
echo "Subscription: $SUBSCRIPTION_ID"
echo "Location: $LOCATION"
echo "Resource Group: $RESOURCE_GROUP"
echo ""

# Check Azure CLI
echo -e "${YELLOW}📋 Checking prerequisites...${NC}"
if ! command -v az &> /dev/null; then
    echo -e "${RED}❌ Azure CLI not found. Please install: brew install azure-cli${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Azure CLI found${NC}"

# Set subscription
echo -e "${YELLOW}🔧 Setting Azure subscription...${NC}"
az account set --subscription "$SUBSCRIPTION_ID"
echo -e "${GREEN}✅ Subscription set${NC}"

# Create resource group
echo -e "${YELLOW}📦 Creating resource group...${NC}"
az group create \
    --name "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --tags "project=llm-gpu-test" "environment=test" || true
echo -e "${GREEN}✅ Resource group ready${NC}"

# Create container registry
echo -e "${YELLOW}🏗️  Creating container registry...${NC}"
az acr create \
    --resource-group "$RESOURCE_GROUP" \
    --name "$CONTAINER_REGISTRY" \
    --sku Standard \
    --admin-enabled true \
    --location "$LOCATION" || true
echo -e "${GREEN}✅ Container registry ready${NC}"

# Build and push container image
echo -e "${YELLOW}🐳 Building container image...${NC}"
az acr build \
    --registry "$CONTAINER_REGISTRY" \
    --image "$IMAGE_NAME" \
    --file Dockerfile.simple \
    .
echo -e "${GREEN}✅ Container image built and pushed${NC}"

# Create Log Analytics workspace
echo -e "${YELLOW}📊 Creating Log Analytics workspace...${NC}"
WORKSPACE_NAME="log-gpu-func-test"
az monitor log-analytics workspace create \
    --resource-group "$RESOURCE_GROUP" \
    --workspace-name "$WORKSPACE_NAME" \
    --location "$LOCATION" || true

WORKSPACE_ID=$(az monitor log-analytics workspace show \
    --resource-group "$RESOURCE_GROUP" \
    --workspace-name "$WORKSPACE_NAME" \
    --query customerId -o tsv)

WORKSPACE_KEY=$(az monitor log-analytics workspace get-shared-keys \
    --resource-group "$RESOURCE_GROUP" \
    --workspace-name "$WORKSPACE_NAME" \
    --query primarySharedKey -o tsv)

echo -e "${GREEN}✅ Log Analytics workspace ready${NC}"

# Create Container Apps environment with GPU
echo -e "${YELLOW}🌍 Creating Container Apps environment with GPU support...${NC}"
az containerapp env create \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --logs-workspace-id "$WORKSPACE_ID" \
    --logs-workspace-key "$WORKSPACE_KEY" \
    --enable-workload-profiles || true

# Add Consumption GPU workload profile to the environment
echo -e "${YELLOW}⚡ Adding GPU workload profile (NC24-A100)...${NC}"
az containerapp env workload-profile add \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --workload-profile-type "$WORKLOAD_PROFILE_TYPE" \
    --min-nodes 1 \
    --max-nodes 1 || echo -e "${YELLOW}Note: GPU profile may already exist${NC}"

echo -e "${GREEN}✅ GPU environment ready (NC24-A100 with 1x A100 GPU)${NC}"

# Get ACR credentials
echo -e "${YELLOW}🔑 Getting container registry credentials...${NC}"
ACR_SERVER=$(az acr show --name "$CONTAINER_REGISTRY" --query loginServer -o tsv)
ACR_USERNAME=$(az acr credential show --name "$CONTAINER_REGISTRY" --query username -o tsv)
ACR_PASSWORD=$(az acr credential show --name "$CONTAINER_REGISTRY" --query passwords[0].value -o tsv)

# Create storage account for Functions
echo -e "${YELLOW}💾 Creating storage account...${NC}"
STORAGE_NAME="stgpufunctest${RANDOM}"
az storage account create \
    --name "$STORAGE_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --location "$LOCATION" \
    --sku Standard_LRS || true

STORAGE_CONNECTION=$(az storage account show-connection-string \
    --name "$STORAGE_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query connectionString -o tsv)

echo -e "${GREEN}✅ Storage account ready${NC}"

# Deploy Container App with GPU
echo -e "${YELLOW}🚀 Deploying Azure Function with GPU...${NC}"
az containerapp create \
    --name "$FUNCTION_APP" \
    --resource-group "$RESOURCE_GROUP" \
    --environment "$ENVIRONMENT" \
    --image "$ACR_SERVER/$IMAGE_NAME" \
    --registry-server "$ACR_SERVER" \
    --registry-username "$ACR_USERNAME" \
    --registry-password "$ACR_PASSWORD" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --cpu 4.0 \
    --memory 32Gi \
    --min-replicas 0 \
    --max-replicas 1 \
    --ingress external \
    --target-port 80 \
    --env-vars \
        "FUNCTIONS_WORKER_RUNTIME=python" \
        "FUNCTIONS_EXTENSION_VERSION=~4" \
        "AzureWebJobsStorage=$STORAGE_CONNECTION" \
        "NVIDIA_VISIBLE_DEVICES=all" \
        "CUDA_VISIBLE_DEVICES=0" \
        "PYTHON_ISOLATE_WORKER_DEPENDENCIES=1"

echo -e "${GREEN}✅ Function deployed!${NC}"

# Get Function URL
FUNCTION_URL=$(az containerapp show \
    --name "$FUNCTION_APP" \
    --resource-group "$RESOURCE_GROUP" \
    --query properties.configuration.ingress.fqdn -o tsv)

echo ""
echo -e "${GREEN}=========================================="
echo "🎉 Deployment Complete!"
echo "==========================================${NC}"
echo ""
echo -e "${BLUE}Function URL:${NC} https://$FUNCTION_URL"
echo ""
echo -e "${YELLOW}Test the GPU endpoints:${NC}"
echo "  Health check:  curl https://$FUNCTION_URL/api/health"
echo "  GPU status:    curl https://$FUNCTION_URL/api/gpu-status"
echo "  GPU test:      curl https://$FUNCTION_URL/api/gpu-test"
echo ""
echo -e "${YELLOW}💡 The function will auto-scale to zero when idle (saves costs!)${NC}"
echo -e "${YELLOW}💡 First request may take 30-60 seconds (cold start + GPU init)${NC}"
echo ""

# Save configuration
cat > deployment-info.txt << EOF
Deployment Information
======================
Date: $(date)
Subscription: $SUBSCRIPTION_ID
Resource Group: $RESOURCE_GROUP
Location: $LOCATION
Container Registry: $ACR_SERVER
Function App: $FUNCTION_APP
Function URL: https://$FUNCTION_URL

Test Commands:
--------------
# Health check
curl https://$FUNCTION_URL/api/health

# GPU status
curl https://$FUNCTION_URL/api/gpu-status

# GPU computation test
curl https://$FUNCTION_URL/api/gpu-test

Cleanup Command:
----------------
az group delete --name $RESOURCE_GROUP --yes --no-wait
EOF

echo -e "${GREEN}✅ Deployment info saved to deployment-info.txt${NC}"
