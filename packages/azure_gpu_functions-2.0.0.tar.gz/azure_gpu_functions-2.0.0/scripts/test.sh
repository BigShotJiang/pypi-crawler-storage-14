#!/bin/bash

# Azure Functions GPU Training Framework Test Script

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "Testing Azure Functions GPU Training Framework..."
echo "================================================="

# Test Python imports (without Azure dependencies)
echo "Testing Python module imports..."
cd "$PROJECT_ROOT"

python3 -c "
import sys
sys.path.insert(0, '.')

# Test basic utility imports
try:
    from src.utils.config import Config
    print('✓ Config module')
except Exception as e:
    print(f'✗ Config module: {e}')

try:
    from src.utils.logging import get_logger
    print('✓ Logging module')
except Exception as e:
    print(f'✗ Logging module: {e}')

try:
    from src.utils.gpu_utils import GPUManager
    print('✓ GPU utils module')
except Exception as e:
    print(f'✗ GPU utils module: {e}')

print('Basic modules test completed.')
"

# Test file structure
echo ""
echo "Testing file structure..."

# Check required directories
directories=(
    "src/functions"
    "src/models"
    "src/storage"
    "src/experiments"
    "src/utils"
    "config"
    "infrastructure"
    "scripts"
    "tests"
    "docs"
)

for dir in "${directories[@]}"; do
    if [ -d "$dir" ]; then
        echo "✓ Directory: $dir"
    else
        echo "✗ Missing directory: $dir"
    fi
done

# Check required files
files=(
    "README.md"
    "requirements.txt"
    "host.json"
    "Dockerfile"
    "config/config.template.json"
    "scripts/deploy.sh"
    ".gitignore"
    "src/functions/__init__.py"
    "src/utils/config.py"
    "src/utils/logging.py"
    "src/utils/gpu_utils.py"
    "src/storage/blob_client.py"
    "src/storage/table_client.py"
    "src/experiments/tracker.py"
    "src/models/registry.py"
    "src/models/trainer.py"
)

for file in "${files[@]}"; do
    if [ -f "$file" ]; then
        echo "✓ File: $file"
    else
        echo "✗ Missing file: $file"
    fi
done

echo ""
echo "Testing configuration template..."
if [ -f "config/config.template.json" ]; then
    if python3 -c "import json; json.load(open('config/config.template.json'))"; then
        echo "✓ Configuration template is valid JSON"
    else
        echo "✗ Configuration template is invalid JSON"
    fi
fi

echo ""
echo "Testing requirements file..."
if [ -f "requirements.txt" ]; then
    echo "✓ Requirements file exists"
    # Count dependencies
    dep_count=$(wc -l < requirements.txt)
    echo "  - Contains $dep_count dependencies"
else
    echo "✗ Requirements file missing"
fi

echo ""
echo "Framework structure test completed!"
echo ""
echo "Next steps:"
echo "1. Copy config/config.template.json to config.json and update values"
echo "2. Install dependencies: pip install -r requirements.txt"
echo "3. Run deployment: ./scripts/deploy.sh A100"
echo "4. Test deployment: ./scripts/deploy.sh test A100"