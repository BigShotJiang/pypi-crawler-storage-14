#!/bin/bash

# Test Script for CPU vs GPU Function Validation
# This script tests the Azure Function deployment and shows the difference
# between CPU-only and GPU-enabled deployments

set -e

# Configuration
RESOURCE_GROUP="rg-gpu-func-test"
FUNCTION_NAME_CPU="gpu-function-cpu-test"
FUNCTION_NAME_GPU="gpu-function-gpu-test"  # Will be created after GPU quota approval

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🧪 Azure Functions CPU vs GPU Test Validation${NC}"
echo "=============================================="
echo ""

# Function to test endpoint
test_endpoint() {
    local url=$1
    local description=$2

    echo -e "${YELLOW}Testing: $description${NC}"
    echo -e "${BLUE}URL: $url${NC}"

    if curl -s -o /dev/null -w "%{http_code}" "$url" | grep -q "200"; then
        echo -e "${GREEN}✅ HTTP 200 - Success${NC}"

        # Get response body for GPU-related endpoints
        if [[ $url == *"gpu"* ]]; then
            response=$(curl -s "$url")
            echo -e "${BLUE}Response:${NC}"
            echo "$response" | jq '.' 2>/dev/null || echo "$response"
        fi
    else
        echo -e "${RED}❌ Failed to connect${NC}"
        return 1
    fi
    echo ""
}

# Test CPU deployment
echo -e "${YELLOW}🔍 Testing CPU-Only Deployment${NC}"
echo "=================================="

CPU_URL=$(az containerapp show \
    --name $FUNCTION_NAME_CPU \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv 2>/dev/null)

if [ -z "$CPU_URL" ]; then
    echo -e "${RED}❌ CPU function not found. Run ./deploy_cpu_test.sh first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ CPU Function URL: https://$CPU_URL${NC}"
echo ""

# Test CPU endpoints
test_endpoint "https://$CPU_URL/api/health" "Health Check (CPU)"
test_endpoint "https://$CPU_URL/api/gpu-status" "GPU Status (CPU - should show no GPU)"
test_endpoint "https://$CPU_URL/api/gpu-test" "GPU Test (CPU - should fail gracefully)"

# Test GPU deployment (if exists)
echo -e "${YELLOW}🔍 Checking GPU Deployment Status${NC}"
echo "==================================="

GPU_URL=$(az containerapp show \
    --name $FUNCTION_NAME_GPU \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv 2>/dev/null)

if [ -z "$GPU_URL" ]; then
    echo -e "${YELLOW}⚠️  GPU function not deployed yet.${NC}"
    echo -e "${BLUE}💡 This is expected if GPU quota is not approved yet.${NC}"
    echo ""
    echo -e "${GREEN}📋 To deploy GPU version after quota approval:${NC}"
    echo "  1. Wait for quota approval (1-2 business days)"
    echo "  2. Run: ./deploy_bicep_gpu_env.sh"
    echo "  3. Run: ./deploy_gpu_function.sh"
    echo "  4. Re-run this test script"
    echo ""
else
    echo -e "${GREEN}✅ GPU Function URL: https://$GPU_URL${NC}"
    echo ""

    # Test GPU endpoints
    test_endpoint "https://$GPU_URL/api/health" "Health Check (GPU)"
    test_endpoint "https://$GPU_URL/api/gpu-status" "GPU Status (GPU - should show A100/T4)"
    test_endpoint "https://$GPU_URL/api/gpu-test" "GPU Test (GPU - should run on GPU)"
fi

echo ""
echo -e "${BLUE}📊 Test Results Summary${NC}"
echo "========================"

# Check if CPU function is working
if curl -s -o /dev/null -w "%{http_code}" "https://$CPU_URL/api/health" | grep -q "200"; then
    echo -e "${GREEN}✅ CPU Function: Working (validates function logic)${NC}"
else
    echo -e "${RED}❌ CPU Function: Not working${NC}"
fi

# Check GPU function status
if [ -n "$GPU_URL" ]; then
    if curl -s -o /dev/null -w "%{http_code}" "https://$GPU_URL/api/health" | grep -q "200"; then
        echo -e "${GREEN}✅ GPU Function: Working (GPU acceleration active)${NC}"

        # Check if GPU is actually detected
        gpu_response=$(curl -s "https://$GPU_URL/api/gpu-status")
        if echo "$gpu_response" | grep -q "A100\|T4\|GPU available"; then
            echo -e "${GREEN}✅ GPU Detection: GPU hardware detected${NC}"
        else
            echo -e "${YELLOW}⚠️  GPU Detection: GPU not detected (check workload profile)${NC}"
        fi
    else
        echo -e "${RED}❌ GPU Function: Not working${NC}"
    fi
else
    echo -e "${YELLOW}⏳ GPU Function: Waiting for quota approval${NC}"
fi

echo ""
echo -e "${BLUE}🎯 Validation Complete${NC}"
echo ""
echo -e "${GREEN}✅ CPU test validates: Function logic, HTTP triggers, container deployment${NC}"
echo -e "${GREEN}✅ GPU test validates: GPU hardware access, PyTorch CUDA support, performance${NC}"
echo ""
echo -e "${BLUE}💡 Next: Wait for quota approval, then deploy GPU version for full validation${NC}"