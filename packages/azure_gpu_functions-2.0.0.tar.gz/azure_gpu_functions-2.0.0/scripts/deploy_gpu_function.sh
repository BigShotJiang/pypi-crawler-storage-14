#!/bin/bash

# Deploy Azure Function with GPU to Container Apps
# Requires: Container Apps environment with GPU workload profile (created via Bicep)
set -e

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_GROUP="rg-llm-gpu-function-test"
CONTAINER_REGISTRY="acrgpufunctest"
FUNCTION_APP="func-gpu-test"
ENVIRONMENT="gpu-func-env"
IMAGE_NAME="gpu-function-simple:latest"
WORKLOAD_PROFILE_NAME="gpua100"

echo "🚀 Deploying Azure Function with GPU Support"
echo "============================================="
echo ""

# Set subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Verify environment exists with GPU profile
echo "🔍 Verifying GPU environment..."
if ! az containerapp env show --name "$ENVIRONMENT" --resource-group "$RESOURCE_GROUP" &>/dev/null; then
    echo "❌ ERROR: Container Apps environment '$ENVIRONMENT' not found!"
    echo "   Please run: ./deploy_bicep_gpu_env.sh first"
    exit 1
fi

# Verify GPU workload profile exists
echo "🔍 Verifying GPU workload profile..."
if ! az containerapp env workload-profile list \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --query "[?name=='$WORKLOAD_PROFILE_NAME']" -o tsv | grep -q "$WORKLOAD_PROFILE_NAME"; then
    echo "❌ ERROR: GPU workload profile '$WORKLOAD_PROFILE_NAME' not found!"
    echo "   Available profiles:"
    az containerapp env workload-profile list \
        --name "$ENVIRONMENT" \
        --resource-group "$RESOURCE_GROUP" \
        -o table
    exit 1
fi

echo "✅ GPU environment and workload profile verified"

# Get ACR credentials
echo ""
echo "🔑 Getting container registry credentials..."
ACR_SERVER=$(az acr show --name "$CONTAINER_REGISTRY" --query loginServer -o tsv)
ACR_USERNAME=$(az acr credential show --name "$CONTAINER_REGISTRY" --query username -o tsv)
ACR_PASSWORD=$(az acr credential show --name "$CONTAINER_REGISTRY" --query passwords[0].value -o tsv)

echo "✅ ACR credentials retrieved"
echo "   Server: $ACR_SERVER"

# Get storage connection
echo ""
echo "💾 Getting storage account connection..."
STORAGE_NAME=$(az storage account list --resource-group "$RESOURCE_GROUP" --query "[0].name" -o tsv)
STORAGE_CONNECTION=$(az storage account show-connection-string \
    --name "$STORAGE_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query connectionString -o tsv)

echo "✅ Storage connection retrieved"
echo "   Storage: $STORAGE_NAME"

# Delete existing container app if it exists
echo ""
echo "🗑️  Checking for existing container app..."
if az containerapp show --name "$FUNCTION_APP" --resource-group "$RESOURCE_GROUP" &>/dev/null; then
    echo "⚠️  Existing container app found. Deleting..."
    az containerapp delete \
        --name "$FUNCTION_APP" \
        --resource-group "$RESOURCE_GROUP" \
        --yes
    echo "✅ Existing container app deleted"
else
    echo "✅ No existing container app found"
fi

# Deploy Container App with GPU
echo ""
echo "🚀 Deploying Azure Function with GPU..."
echo "   Image: $ACR_SERVER/$IMAGE_NAME"
echo "   Workload Profile: $WORKLOAD_PROFILE_NAME (NC24-A100)"
echo "   CPU: 4.0 cores"
echo "   Memory: 32Gi"
echo ""

az containerapp create \
    --name "$FUNCTION_APP" \
    --resource-group "$RESOURCE_GROUP" \
    --environment "$ENVIRONMENT" \
    --image "$ACR_SERVER/$IMAGE_NAME" \
    --registry-server "$ACR_SERVER" \
    --registry-username "$ACR_USERNAME" \
    --registry-password "$ACR_PASSWORD" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --cpu 4.0 \
    --memory 32Gi \
    --min-replicas 0 \
    --max-replicas 1 \
    --ingress external \
    --target-port 80 \
    --env-vars \
        "FUNCTIONS_WORKER_RUNTIME=python" \
        "FUNCTIONS_EXTENSION_VERSION=~4" \
        "AzureWebJobsStorage=$STORAGE_CONNECTION" \
        "NVIDIA_VISIBLE_DEVICES=all" \
        "CUDA_VISIBLE_DEVICES=0" \
        "PYTHON_ISOLATE_WORKER_DEPENDENCIES=1"

# Get Function URL
echo ""
echo "🌐 Getting function URL..."
FUNCTION_URL=$(az containerapp show \
    --name "$FUNCTION_APP" \
    --resource-group "$RESOURCE_GROUP" \
    --query properties.configuration.ingress.fqdn -o tsv)

echo ""
echo "✅ Deployment Complete!"
echo "======================="
echo ""
echo "Function URL: https://$FUNCTION_URL"
echo ""
echo "Test endpoints:"
echo "  Health check:  curl https://$FUNCTION_URL/api/health"
echo "  GPU status:    curl https://$FUNCTION_URL/api/gpu-status"
echo "  GPU test:      curl https://$FUNCTION_URL/api/gpu-test"
echo ""
echo "Expected GPU: NVIDIA A100 80GB (CUDA 12.1)"
echo ""
echo "Note: First cold start may take 5-10 minutes to pull the container image"
echo "      and initialize the GPU drivers."
