#!/bin/bash

# Deploy Container Apps Environment with GPU Support using Bicep
set -e

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_GROUP="rg-llm-gpu-function-test"
ENVIRONMENT="gpu-func-env"
LOG_WORKSPACE="log-gpu-func-test"
BICEP_FILE="infrastructure/main.bicep"
PARAMS_FILE="infrastructure/main.parameters.json"

echo "🚀 Deploying Container Apps Environment with GPU Support (Bicep)"
echo "================================================================="
echo ""

# Set subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Delete existing environment if it exists
echo "🗑️  Checking for existing environment..."
if az containerapp env show --name "$ENVIRONMENT" --resource-group "$RESOURCE_GROUP" &>/dev/null; then
    echo "⚠️  Existing environment found. Deleting..."
    az containerapp env delete \
        --name "$ENVIRONMENT" \
        --resource-group "$RESOURCE_GROUP" \
        --yes
    
    echo "⏳ Waiting for deletion to complete (60 seconds)..."
    sleep 60
else
    echo "✅ No existing environment found"
fi

# Get Log Analytics workspace credentials
echo ""
echo "📊 Getting Log Analytics workspace credentials..."
LOG_WORKSPACE_ID=$(az monitor log-analytics workspace show \
    --workspace-name "$LOG_WORKSPACE" \
    --resource-group "$RESOURCE_GROUP" \
    --query customerId -o tsv)

LOG_WORKSPACE_KEY=$(az monitor log-analytics workspace get-shared-keys \
    --workspace-name "$LOG_WORKSPACE" \
    --resource-group "$RESOURCE_GROUP" \
    --query primarySharedKey -o tsv)

echo "✅ Log Analytics credentials retrieved"
echo "   Customer ID: $LOG_WORKSPACE_ID"

# Update parameters file with actual Log Analytics values
echo ""
echo "📝 Updating parameters file with Log Analytics credentials..."
cat > "$PARAMS_FILE" << EOF
{
  "\$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "location": {
      "value": "$LOCATION"
    },
    "environmentName": {
      "value": "$ENVIRONMENT"
    },
    "logAnalyticsCustomerId": {
      "value": "$LOG_WORKSPACE_ID"
    },
    "logAnalyticsSharedKey": {
      "value": "$LOG_WORKSPACE_KEY"
    },
    "gpuWorkloadProfileName": {
      "value": "gpua100"
    },
    "gpuWorkloadProfileType": {
      "value": "NC24-A100"
    },
    "gpuMinNodes": {
      "value": 1
    },
    "gpuMaxNodes": {
      "value": 1
    }
  }
}
EOF

echo "✅ Parameters file updated"

# Deploy Bicep template
echo ""
echo "🌍 Deploying Bicep template..."
echo "   Template: $BICEP_FILE"
echo "   Parameters: $PARAMS_FILE"
echo "   Resource Group: $RESOURCE_GROUP"
echo ""

DEPLOYMENT_NAME="gpu-env-deployment-$(date +%Y%m%d-%H%M%S)"

az deployment group create \
    --name "$DEPLOYMENT_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --template-file "$BICEP_FILE" \
    --parameters "$PARAMS_FILE" \
    --verbose

# Get deployment outputs
echo ""
echo "📋 Deployment outputs..."
az deployment group show \
    --name "$DEPLOYMENT_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query properties.outputs -o json | jq

# Verify workload profiles
echo ""
echo "✅ Verifying workload profiles..."
az containerapp env workload-profile list \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    -o table

# Show environment details
echo ""
echo "📊 Environment details..."
az containerapp env show \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --query "{name:name, location:location, provisioningState:properties.provisioningState, defaultDomain:properties.defaultDomain, staticIp:properties.staticIp}" \
    -o json | jq

echo ""
echo "✅ GPU Environment Deployment Complete!"
echo "========================================"
echo ""
echo "Environment: $ENVIRONMENT"
echo "Location: $LOCATION"
echo "Workload Profiles:"
echo "  - Consumption (serverless)"
echo "  - gpua100 (NC24-A100: 24 vCPU, 220GB RAM, 1x A100 80GB GPU)"
echo ""
echo "Next step: Deploy the Azure Function with GPU support"
echo "Run: ./deploy_gpu_function.sh"
