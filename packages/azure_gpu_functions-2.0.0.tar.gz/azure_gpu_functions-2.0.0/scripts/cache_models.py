#!/usr/bin/env python3
"""
Model Caching Script for Azure Functions GPU Training
Pre-downloads and caches commonly used models to speed up cold starts
"""

import os
import sys
import logging
from typing import List, Dict, Any

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Set cache directory
CACHE_DIR = "/home/site/wwwroot/.cache/huggingface"
os.environ["HF_HOME"] = CACHE_DIR
os.environ["TRANSFORMERS_CACHE"] = CACHE_DIR

def cache_models():
    """Cache commonly used models and tokenizers"""

    # List of models to pre-cache (commonly used ones)
    models_to_cache = [
        {
            "name": "mistralai/Mistral-7B-v0.1",
            "description": "Default model for the application"
        },
        {
            "name": "microsoft/DialoGPT-medium",
            "description": "Alternative conversational model"
        },
        {
            "name": "gpt2",
            "description": "Lightweight GPT-2 model for testing"
        }
    ]

    logger.info("Starting model caching process...")

    for model_info in models_to_cache:
        model_name = model_info["name"]
        description = model_info["description"]

        try:
            logger.info(f"Caching model: {model_name} ({description})")

            # Import here to avoid issues if transformers not installed yet
            from transformers import AutoTokenizer, AutoModelForCausalLM
            import torch

            # Cache tokenizer first (lighter weight)
            logger.info(f"Downloading tokenizer for {model_name}")
            tokenizer = AutoTokenizer.from_pretrained(
                model_name,
                cache_dir=CACHE_DIR,
                trust_remote_code=True
            )

            # Cache model (only config and tokenizer for now, full model on demand)
            logger.info(f"Downloading model config for {model_name}")
            model = AutoModelForCausalLM.from_pretrained(
                model_name,
                cache_dir=CACHE_DIR,
                trust_remote_code=True,
                config_only=True  # Only download config, not weights
            )

            logger.info(f"Successfully cached {model_name}")

        except Exception as e:
            logger.error(f"Failed to cache {model_name}: {str(e)}")
            # Continue with other models
            continue

    logger.info("Model caching process completed")

def cache_pytorch_dependencies():
    """Cache PyTorch and related dependencies"""

    try:
        logger.info("Caching PyTorch dependencies...")

        import torch
        import torchvision
        import torchaudio

        # Force CUDA cache initialization if CUDA available
        if torch.cuda.is_available():
            logger.info("CUDA available, initializing CUDA cache")
            # Create a small tensor to initialize CUDA context
            x = torch.randn(1, device='cuda')
            del x
            torch.cuda.empty_cache()
        else:
            logger.info("CUDA not available, skipping CUDA cache initialization")

        logger.info("PyTorch dependencies cached successfully")

    except Exception as e:
        logger.error(f"Failed to cache PyTorch dependencies: {str(e)}")

def main():
    """Main caching function"""

    logger.info("Azure Functions Model Caching Script")
    logger.info("=" * 50)

    try:
        # Cache PyTorch dependencies first
        cache_pytorch_dependencies()

        # Cache models
        cache_models()

        logger.info("All caching operations completed successfully")

    except Exception as e:
        logger.error(f"Caching script failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()