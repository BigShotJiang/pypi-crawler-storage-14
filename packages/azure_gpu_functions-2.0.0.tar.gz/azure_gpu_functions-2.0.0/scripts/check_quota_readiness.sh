#!/bin/bash

# A100 GPU Quota Request Pre-flight Checklist
# Verify readiness before submitting quota request

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_PROVIDER="Microsoft.App"
GPU_RESOURCE="NCads A100 v4 Series"

echo -e "${BLUE}🔍 A100 GPU Quota Request - Pre-flight Checklist${NC}"
echo -e "${BLUE}=================================================${NC}"
echo ""

# Check 1: Azure CLI and Authentication
echo -e "${BLUE}1. Checking Azure CLI and Authentication...${NC}"

if ! command -v az &> /dev/null; then
    echo -e "${RED}❌ Azure CLI not found. Please install: brew install azure-cli${NC}"
    exit 1
else
    echo -e "${GREEN}✅ Azure CLI found${NC}"
fi

# Check if logged in
if ! az account show --subscription $SUBSCRIPTION_ID &> /dev/null; then
    echo -e "${RED}❌ Not authenticated or no access to subscription${NC}"
    echo -e "${YELLOW}   Run: az login${NC}"
    exit 1
else
    CURRENT_USER=$(az account show --subscription $SUBSCRIPTION_ID --query user.name -o tsv)
    echo -e "${GREEN}✅ Authenticated as: $CURRENT_USER${NC}"
fi

echo ""

# Check 2: Subscription Access and Role
echo -e "${BLUE}2. Verifying Subscription Access...${NC}"

SUBSCRIPTION_NAME=$(az account show --subscription $SUBSCRIPTION_ID --query name -o tsv 2>/dev/null || echo "Unknown")
echo -e "${GREEN}✅ Subscription: $SUBSCRIPTION_NAME ($SUBSCRIPTION_ID)${NC}"

# Check if user has required permissions
USER_ROLES=$(az role assignment list --assignee $(az ad signed-in-user show --query id -o tsv) --scope "/subscriptions/$SUBSCRIPTION_ID" --query "[].roleDefinitionName" -o tsv 2>/dev/null || echo "")

if [[ $USER_ROLES == *"Owner"* ]] || [[ $USER_ROLES == *"Contributor"* ]]; then
    echo -e "${GREEN}✅ Sufficient permissions (Owner/Contributor role found)${NC}"
else
    echo -e "${YELLOW}⚠️  Warning: May need Owner or Contributor role for quota requests${NC}"
    echo -e "${YELLOW}   Current roles: $USER_ROLES${NC}"
fi

echo ""

# Check 3: Current Quota Usage
echo -e "${BLUE}3. Checking Current GPU Quota...${NC}"

# Get current compute quotas
echo -e "${YELLOW}📊 Checking current quotas in $LOCATION...${NC}"

QUOTA_INFO=$(az vm list-usage --location $LOCATION --query "[?contains(name.value, 'NC') || contains(name.value, 'GPU')]" -o table 2>/dev/null || echo "Error fetching quota")

if [[ $QUOTA_INFO == *"Error"* ]]; then
    echo -e "${YELLOW}⚠️  Could not fetch current quota information${NC}"
    echo -e "${YELLOW}   This is normal - you may not have any GPU quota yet${NC}"
else
    echo -e "${GREEN}✅ Current GPU-related quotas:${NC}"
    echo "$QUOTA_INFO"
fi

echo ""

# Check 4: Regional Availability
echo -e "${BLUE}4. Checking Regional Availability...${NC}"

# Check if A100 is available in the region
AVAILABLE_SKUS=$(az vm list-skus --location $LOCATION --query "[?contains(name, 'NC') && contains(name, 'A100')]" -o table 2>/dev/null || echo "Error")

if [[ $AVAILABLE_SKUS == *"NC24ads_A100_v4"* ]]; then
    echo -e "${GREEN}✅ A100 instances (NC24ads_A100_v4) available in $LOCATION${NC}"
elif [[ $AVAILABLE_SKUS == *"Error"* ]]; then
    echo -e "${YELLOW}⚠️  Could not verify SKU availability${NC}"
else
    echo -e "${RED}❌ A100 instances may not be available in $LOCATION${NC}"
    echo -e "${YELLOW}   Consider alternative regions: West Europe, East US${NC}"
fi

echo ""

# Check 5: Container Apps Service Registration
echo -e "${BLUE}5. Checking Service Provider Registration...${NC}"

PROVIDER_STATUS=$(az provider show --namespace Microsoft.App --query registrationState -o tsv 2>/dev/null || echo "Error")

if [[ $PROVIDER_STATUS == "Registered" ]]; then
    echo -e "${GREEN}✅ Microsoft.App provider is registered${NC}"
elif [[ $PROVIDER_STATUS == "NotRegistered" ]]; then
    echo -e "${YELLOW}⚠️  Microsoft.App provider not registered${NC}"
    echo -e "${YELLOW}   Registering now...${NC}"
    az provider register --namespace Microsoft.App
    echo -e "${GREEN}✅ Microsoft.App provider registration initiated${NC}"
else
    echo -e "${YELLOW}⚠️  Could not verify Microsoft.App provider status${NC}"
fi

echo ""

# Check 6: Cost and Budget Planning
echo -e "${BLUE}6. Cost Planning Assessment...${NC}"

echo -e "${GREEN}✅ A100 GPU Cost Estimates (North Europe):${NC}"
echo -e "${BLUE}   • NC24ads_A100_v4: ~$3.50/hour (~$2,520/month if always running)${NC}"
echo -e "${BLUE}   • With scale-to-zero: Significant cost savings when idle${NC}"
echo -e "${BLUE}   • Recommended: Set up billing alerts for cost monitoring${NC}"

echo ""

# Check 7: Documentation Readiness
echo -e "${BLUE}7. Documentation and Justification Readiness...${NC}"

if [[ -f "A100_QUOTA_REQUEST_GUIDE.md" ]]; then
    echo -e "${GREEN}✅ A100 quota request guide available${NC}"
else
    echo -e "${YELLOW}⚠️  Quota request guide not found${NC}"
fi

if [[ -f "README.md" ]]; then
    echo -e "${GREEN}✅ Project documentation available${NC}"
else
    echo -e "${YELLOW}⚠️  Project README not found${NC}"
fi

echo ""

# Check 8: Project Readiness
echo -e "${BLUE}8. Project Deployment Readiness...${NC}"

# Check if required files exist
FILES_TO_CHECK=("function_app.py" "Dockerfile" "requirements.txt" "infra/main.bicep" "azure.yaml")
ALL_FILES_PRESENT=true

for file in "${FILES_TO_CHECK[@]}"; do
    if [[ -f "$file" ]]; then
        echo -e "${GREEN}✅ $file present${NC}"
    else
        echo -e "${RED}❌ $file missing${NC}"
        ALL_FILES_PRESENT=false
    fi
done

if $ALL_FILES_PRESENT; then
    echo -e "${GREEN}✅ All required project files present${NC}"
else
    echo -e "${YELLOW}⚠️  Some project files are missing${NC}"
fi

echo ""

# Summary and Next Steps
echo -e "${BLUE}📋 Pre-flight Checklist Summary${NC}"
echo -e "${BLUE}===============================${NC}"

echo -e "${GREEN}✅ Ready to proceed with quota request if all items above are green${NC}"
echo ""
echo -e "${YELLOW}📝 Next Steps:${NC}"
echo -e "${BLUE}1. Review the complete guide: A100_QUOTA_REQUEST_GUIDE.md${NC}"
echo -e "${BLUE}2. Go to Azure Portal: https://portal.azure.com${NC}"
echo -e "${BLUE}3. Navigate to: Help + support → New support request${NC}"
echo -e "${BLUE}4. Use the template and information from the guide${NC}"
echo ""

echo -e "${YELLOW}🎯 Key Information for Your Request:${NC}"
echo -e "${BLUE}   • Subscription: $SUBSCRIPTION_ID${NC}"
echo -e "${BLUE}   • Location: $LOCATION${NC}"
echo -e "${BLUE}   • Resource: Container Apps with A100 GPU${NC}"
echo -e "${BLUE}   • Quota: 24 vCPUs (NCads A100 v4 Series)${NC}"
echo -e "${BLUE}   • Use Case: LLM training for Amadeus test environment${NC}"
echo ""

echo -e "${GREEN}🚀 Good luck with your quota request!${NC}"
echo -e "${GREEN}   Estimated approval time: 5-10 business days${NC}"

exit 0