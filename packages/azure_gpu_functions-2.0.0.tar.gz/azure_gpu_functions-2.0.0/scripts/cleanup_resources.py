#!/usr/bin/env python3
"""
Training Resource Cleanup Script
Automatically cleans up orphaned training resources to prevent cost overruns
"""

import asyncio
import json
import os
import signal
import subprocess
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import psutil
import GPUtil
import ray
import logging
import argparse

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TrainingResourceCleanup:
    def __init__(self, dry_run: bool = True):
        self.dry_run = dry_run
        self.cleanup_log = []

        # Configuration
        self.max_training_duration_hours = 24
        self.cleanup_threshold_minutes = 30
        self.force_cleanup_threshold_hours = 48  # Force cleanup after this time

    def log_action(self, action: str, details: str = ""):
        """Log cleanup actions"""
        timestamp = datetime.now().isoformat()
        log_entry = f"[{timestamp}] {action}"
        if details:
            log_entry += f" - {details}"

        self.cleanup_log.append(log_entry)
        logger.info(log_entry)

        if not self.dry_run:
            print(f"🧹 {action}")
            if details:
                print(f"   {details}")

    async def cleanup_orphaned_processes(self, process_list: List[Dict], process_type: str) -> int:
        """Clean up orphaned processes"""
        cleaned_count = 0

        for proc_info in process_list:
            pid = proc_info['pid']
            name = proc_info['name']
            age_hours = proc_info['age_hours']

            try:
                if psutil.pid_exists(pid):
                    if self.dry_run:
                        self.log_action(f"WOULD KILL {process_type} process",
                                      f"PID {pid} ({name}, age: {age_hours:.1f}h)")
                    else:
                        # Send SIGTERM first
                        os.kill(pid, signal.SIGTERM)
                        await asyncio.sleep(2)  # Wait for graceful shutdown

                        # Check if still running
                        if psutil.pid_exists(pid):
                            # Force kill if still running
                            os.kill(pid, signal.SIGKILL)
                            self.log_action(f"FORCE KILLED {process_type} process",
                                          f"PID {pid} ({name})")

                        cleaned_count += 1
                else:
                    self.log_action(f"Process already dead", f"PID {pid} ({name})")

            except (ProcessLookupError, PermissionError) as e:
                self.log_action(f"Failed to kill {process_type} process",
                              f"PID {pid} ({name}): {e}")

        return cleaned_count

    async def cleanup_ray_sessions(self, ray_info: Dict) -> int:
        """Clean up orphaned Ray sessions"""
        cleaned_count = 0

        # Clean up orphaned Ray processes
        orphaned_processes = ray_info.get('orphaned_processes', [])
        if orphaned_processes:
            cleaned = await self.cleanup_orphaned_processes(orphaned_processes, "Ray")
            cleaned_count += cleaned

        # Clean up old Ray actors (if Ray is running)
        if ray_info.get('ray_running', False) and not self.dry_run:
            try:
                actors = ray.state.actors()
                current_time = time.time() * 1000  # milliseconds

                for actor_id, actor_info in actors.items():
                    start_time = actor_info.get('start_time_ms', 0)
                    if start_time > 0:
                        age_hours = (current_time - start_time) / (1000 * 60 * 60)

                        # Clean up actors older than force cleanup threshold
                        if age_hours > self.force_cleanup_threshold_hours:
                            try:
                                # Kill the actor
                                ray.kill(ray.get_actor(actor_id))
                                self.log_action("Cleaned up old Ray actor",
                                              f"ID: {actor_id}, age: {age_hours:.1f}h")
                                cleaned_count += 1
                            except Exception as e:
                                self.log_action("Failed to kill Ray actor",
                                              f"ID: {actor_id}: {e}")

            except Exception as e:
                self.log_action("Error cleaning up Ray actors", str(e))

        return cleaned_count

    async def cleanup_gpu_processes(self, gpu_info: Dict) -> int:
        """Clean up orphaned GPU processes"""
        cleaned_count = 0

        orphaned_processes = gpu_info.get('orphaned_gpu_processes', [])
        if orphaned_processes:
            cleaned = await self.cleanup_orphaned_processes(orphaned_processes, "GPU")
            cleaned_count += cleaned

        return cleaned_count

    async def cleanup_training_sessions(self, training_info: Dict, function_uri: str) -> int:
        """Clean up orphaned training sessions via API"""
        cleaned_count = 0

        orphaned_sessions = training_info.get('orphaned_sessions', [])
        if not orphaned_sessions or self.dry_run:
            if orphaned_sessions:
                for session in orphaned_sessions:
                    self.log_action("WOULD STOP training session",
                                  f"ID: {session.get('id', 'unknown')}, duration: {session.get('duration_hours', 0):.1f}h")
            return cleaned_count

        # Stop orphaned training sessions via API
        import aiohttp

        try:
            async with aiohttp.ClientSession() as session:
                for session in orphaned_sessions:
                    session_id = session.get('id')
                    if session_id:
                        # Call API to stop training session
                        payload = {
                            'action': 'stop_training',
                            'session_id': session_id,
                            'reason': 'orphaned_session_cleanup'
                        }

                        async with session.post(
                            f"{function_uri}/api/training-control",
                            json=payload,
                            headers={'Content-Type': 'application/json'}
                        ) as response:
                            if response.status == 200:
                                self.log_action("Stopped orphaned training session",
                                              f"ID: {session_id}")
                                cleaned_count += 1
                            else:
                                error_text = await response.text()
                                self.log_action("Failed to stop training session",
                                              f"ID: {session_id}, status: {response.status}, error: {error_text}")

        except Exception as e:
            self.log_action("Error stopping training sessions", str(e))

        return cleaned_count

    async def cleanup_azure_resources(self, azure_info: Dict) -> int:
        """Clean up orphaned Azure resources"""
        cleaned_count = 0

        # This would require Azure management APIs
        # For now, just log recommendations
        function_app = azure_info.get('function_app', {})
        running_instances = function_app.get('running_instances', [])

        if running_instances and len(running_instances) > 1:  # More than expected
            if self.dry_run:
                self.log_action("WOULD SCALE DOWN Azure Function instances",
                              f"Current: {len(running_instances)}, Recommended: 1")
            else:
                # Would need Azure management client to scale down
                self.log_action("Azure Function scaling down requires manual intervention",
                              "Use Azure Portal or CLI to scale down instances")

        return cleaned_count

    async def emergency_cleanup(self) -> int:
        """Emergency cleanup - kill all training-related processes"""
        cleaned_count = 0

        if self.dry_run:
            self.log_action("EMERGENCY CLEANUP (DRY RUN)",
                          "Would kill all training-related processes")
            return cleaned_count

        self.log_action("🚨 STARTING EMERGENCY CLEANUP",
                      "This will kill ALL training-related processes!")

        # Kill all Ray processes
        ray_processes = []
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                if 'ray' in proc.info['name'].lower():
                    ray_processes.append(proc.info['pid'])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        for pid in ray_processes:
            try:
                os.kill(pid, signal.SIGKILL)
                self.log_action("Emergency killed Ray process", f"PID: {pid}")
                cleaned_count += 1
            except Exception as e:
                self.log_action("Failed to kill Ray process", f"PID: {pid}: {e}")

        # Kill GPU training processes
        training_processes = []
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                cmdline = ' '.join(proc.info.get('cmdline', [])).lower()
                if any(keyword in cmdline for keyword in ['training', 'train', 'cuda', 'gpu', 'torch', 'tensorflow']):
                    training_processes.append(proc.info['pid'])
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        for pid in training_processes:
            try:
                os.kill(pid, signal.SIGTERM)
                await asyncio.sleep(1)
                if psutil.pid_exists(pid):
                    os.kill(pid, signal.SIGKILL)
                self.log_action("Emergency killed training process", f"PID: {pid}")
                cleaned_count += 1
            except Exception as e:
                self.log_action("Failed to kill training process", f"PID: {pid}: {e}")

        return cleaned_count

    async def run_cleanup(self, monitoring_data: Dict, function_uri: Optional[str] = None,
                         emergency: bool = False) -> Dict:
        """Run cleanup based on monitoring data"""
        cleanup_results = {
            'start_time': datetime.now().isoformat(),
            'dry_run': self.dry_run,
            'emergency_mode': emergency,
            'cleaned_resources': 0,
            'errors': []
        }

        try:
            if emergency:
                self.log_action("🚨 EMERGENCY CLEANUP MODE ACTIVATED")
                cleaned = await self.emergency_cleanup()
                cleanup_results['cleaned_resources'] += cleaned
            else:
                # Normal cleanup based on monitoring data

                # Clean up Ray sessions
                ray_info = monitoring_data.get('ray_sessions', {})
                cleaned = await self.cleanup_ray_sessions(ray_info)
                cleanup_results['cleaned_resources'] += cleaned

                # Clean up GPU processes
                gpu_info = monitoring_data.get('gpu_resources', {})
                cleaned = await self.cleanup_gpu_processes(gpu_info)
                cleanup_results['cleaned_resources'] += cleaned

                # Clean up training sessions
                if function_uri:
                    training_info = monitoring_data.get('training_sessions', {})
                    cleaned = await self.cleanup_training_sessions(training_info, function_uri)
                    cleanup_results['cleaned_resources'] += cleaned

                # Clean up Azure resources
                azure_info = monitoring_data.get('azure_resources', {})
                cleaned = await self.cleanup_azure_resources(azure_info)
                cleanup_results['cleaned_resources'] += cleaned

        except Exception as e:
            error_msg = f"Cleanup error: {e}"
            self.log_action("CLEANUP ERROR", error_msg)
            cleanup_results['errors'].append(error_msg)

        cleanup_results['end_time'] = datetime.now().isoformat()
        cleanup_results['cleanup_log'] = self.cleanup_log

        return cleanup_results

    def save_cleanup_report(self, cleanup_results: Dict, filename: str = "cleanup_report.json"):
        """Save cleanup report to file"""
        with open(filename, 'w') as f:
            json.dump(cleanup_results, f, indent=2, default=str)

        print(f"🧹 Cleanup report saved to {filename}")

    def print_cleanup_summary(self, cleanup_results: Dict):
        """Print cleanup summary"""
        print("\n" + "="*60)
        print("🧹 CLEANUP SUMMARY")
        print("="*60)

        print(f"Dry Run: {'Yes' if cleanup_results['dry_run'] else 'No'}")
        print(f"Emergency Mode: {'Yes' if cleanup_results['emergency_mode'] else 'No'}")
        print(f"Resources Cleaned: {cleanup_results['cleaned_resources']}")
        print(f"Errors: {len(cleanup_results['errors'])}")

        if cleanup_results['errors']:
            print("\n❌ ERRORS:")
            for error in cleanup_results['errors']:
                print(f"   {error}")

        print("\n📋 CLEANUP LOG:")
        for log_entry in cleanup_results['cleanup_log'][-10:]:  # Last 10 entries
            print(f"   {log_entry}")

        print(f"\n⏱️ Cleanup completed in: {cleanup_results.get('duration_seconds', 0):.2f}s")
        print("="*60)

async def main():
    parser = argparse.ArgumentParser(description='Training Resource Cleanup Script')
    parser.add_argument('--dry-run', action='store_true', default=True,
                       help='Run in dry-run mode (default: True)')
    parser.add_argument('--wet-run', action='store_true',
                       help='Run actual cleanup (overrides dry-run)')
    parser.add_argument('--emergency', action='store_true',
                       help='Emergency cleanup - kill ALL training processes')
    parser.add_argument('--function-uri', type=str,
                       help='Azure Function URI for API-based cleanup')
    parser.add_argument('--monitoring-report', type=str,
                       help='Path to monitoring report JSON file')

    args = parser.parse_args()

    # Determine run mode
    dry_run = not args.wet_run if not args.emergency else False

    if args.emergency:
        print("🚨 EMERGENCY MODE: This will kill ALL training-related processes!")
        confirm = input("Are you sure? Type 'YES' to continue: ")
        if confirm != 'YES':
            print("Emergency cleanup cancelled.")
            return

    # Initialize cleanup
    cleanup = TrainingResourceCleanup(dry_run=dry_run)

    # Load monitoring data
    monitoring_data = {}
    if args.monitoring_report and os.path.exists(args.monitoring_report):
        with open(args.monitoring_report, 'r') as f:
            monitoring_data = json.load(f)
        print(f"📊 Loaded monitoring data from {args.monitoring_report}")
    else:
        print("⚠️ No monitoring data provided. Run check_training_resources.py first")
        print("   or provide --monitoring-report path")
        return

    # Run cleanup
    print(f"🧹 Starting cleanup (dry_run={dry_run}, emergency={args.emergency})...")
    cleanup_results = await cleanup.run_cleanup(monitoring_data, args.function_uri, args.emergency)

    # Print summary
    cleanup.print_cleanup_summary(cleanup_results)

    # Save report
    cleanup.save_cleanup_report(cleanup_results)

if __name__ == "__main__":
    asyncio.run(main())