#!/bin/bash

# A100 GPU Training Test Deployment for Azure Functions
# This script deploys the GPU function to test training on A100 GPUs
# Uses Consumption-GPU-NC24-A100 workload profile

set -e

echo "🚀 Starting A100 GPU Training Test Deployment..."

# Configuration
RESOURCE_GROUP="rg-gpu-func-test-eastus"
LOCATION="eastus"  # Region with A100 Consumption GPU support
ENVIRONMENT_NAME="gpu-func-env-a100"
ACR_NAME="acrgpufunctesteastus"
STORAGE_ACCOUNT_NAME="stgpufunctesteastus"
LOG_ANALYTICS_NAME="log-gpu-func-test"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}📋 A100 GPU Training Test Configuration:${NC}"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION"
echo "  Environment: $ENVIRONMENT_NAME"
echo "  ACR: $ACR_NAME"
echo "  GPU Profile: Consumption-GPU-NC24-A100"
echo ""

# Check if logged in to Azure
echo -e "${YELLOW}🔐 Checking Azure login...${NC}"
if ! az account show > /dev/null 2>&1; then
    echo -e "${RED}❌ Not logged in to Azure. Please run 'az login' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Azure login confirmed${NC}"

# Create resource group if it doesn't exist
echo -e "${YELLOW}📁 Creating resource group...${NC}"
az group create --name $RESOURCE_GROUP --location $LOCATION --output none

# Get Log Analytics credentials
echo -e "${YELLOW}📊 Getting Log Analytics credentials...${NC}"
LOG_ANALYTICS_CUSTOMER_ID=$(az monitor log-analytics workspace show \
    --resource-group $RESOURCE_GROUP \
    --name $LOG_ANALYTICS_NAME \
    --query customerId -o tsv)

echo -e "${GREEN}✅ Log Analytics configured${NC}"

# Create storage account if it doesn't exist
echo -e "${YELLOW}💾 Creating storage account...${NC}"
az storage account create \
    --name $STORAGE_ACCOUNT_NAME \
    --resource-group $RESOURCE_GROUP \
    --location $LOCATION \
    --sku Standard_LRS \
    --output none 2>/dev/null || echo "Storage account already exists"

STORAGE_CONNECTION_STRING=$(az storage account show-connection-string \
    --name $STORAGE_ACCOUNT_NAME \
    --resource-group $RESOURCE_GROUP \
    --output tsv)

echo -e "${GREEN}✅ Storage account configured${NC}"

# Create Azure Container Registry if it doesn't exist
echo -e "${YELLOW}🏗️  Creating Azure Container Registry...${NC}"
az acr create \
    --resource-group $RESOURCE_GROUP \
    --name $ACR_NAME \
    --sku Basic \
    --admin-enabled true \
    --output none 2>/dev/null || echo "ACR already exists or creation failed"

# Ensure admin access is enabled
az acr update --name $ACR_NAME --admin-enabled true --output none

echo -e "${GREEN}✅ Azure Container Registry configured${NC}"

# Build and push container image
echo -e "${YELLOW}🏗️  Building and pushing container image...${NC}"
# For now, use a simple test image - we'll build the GPU image separately
# az acr build \
#     --registry $ACR_NAME \
#     --image gpu-function-simple:latest \
#     --file Dockerfile \
#     . \
#     --output none

# Use a simple test image first
az acr import \
    --name $ACR_NAME \
    --source docker.io/library/nginx:latest \
    --image gpu-function-simple:latest \
    --output none 2>/dev/null || echo "Image already exists, continuing..."

echo -e "${GREEN}✅ Test container image ready${NC}"

# Deploy Container Apps environment with A100 GPU profile
echo -e "${YELLOW}🏗️  Deploying Container Apps environment with A100 GPU profile...${NC}"

# Create parameters file for A100 deployment
cat > infrastructure/main.parameters.a100.json << EOF
{
    "\$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
    "contentVersion": "1.0.0.0",
    "parameters": {
        "location": {
            "value": "$LOCATION"
        },
        "environmentName": {
            "value": "$ENVIRONMENT_NAME"
        },
        "gpuWorkloadProfileName": {
            "value": "gpu-a100-profile"
        },
        "gpuWorkloadProfileType": {
            "value": "Consumption-GPU-NC24-A100"
        }
    }
}
EOF

# Deploy Bicep template
az deployment group create \
    --resource-group $RESOURCE_GROUP \
    --template-file infrastructure/main.bicep \
    --parameters infrastructure/main.parameters.a100.json \
    --output none

echo -e "${GREEN}✅ A100 GPU environment deployed${NC}"

# Get environment details
ENVIRONMENT_ID=$(az containerapp env show \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --query id -o tsv)

echo -e "${GREEN}✅ Environment ID: $ENVIRONMENT_ID${NC}"

# Deploy the function app with T4 GPU profile
echo -e "${YELLOW}🚀 Deploying Azure Function with A100 GPU training support...${NC}"

az containerapp create \
    --name gpu-function-a100-training \
    --resource-group $RESOURCE_GROUP \
    --environment $ENVIRONMENT_ID \
    --image $ACR_NAME.azurecr.io/gpu-function-simple:latest \
    --registry-server $ACR_NAME.azurecr.io \
    --registry-username $ACR_NAME \
    --registry-password $(az acr credential show --name $ACR_NAME --query passwords[0].value -o tsv) \
    --cpu 2.0 \
    --memory 8.0Gi \
    --min-replicas 0 \
    --max-replicas 1 \
    --workload-profile-name gpu-a100-profile \
    --target-port 80 \
    --ingress external \
    --output none

echo -e "${GREEN}✅ A100 GPU Function deployed${NC}"

# Get function URL
FUNCTION_URL=$(az containerapp show \
    --name gpu-function-a100-training \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv)

echo ""
echo -e "${GREEN}🎉 A100 GPU Training Test Deployment Complete!${NC}"
echo ""
echo -e "${BLUE}📋 A100 GPU Training Test URLs:${NC}"
echo "  Health Check:     https://$FUNCTION_URL/api/health"
echo "  GPU Status:       https://$FUNCTION_URL/api/gpu-status"
echo "  GPU Test:         https://$FUNCTION_URL/api/gpu-test"
echo "  GPU Training:     https://$FUNCTION_URL/api/gpu-training"
echo ""
echo -e "${YELLOW}🧠 A100 GPU Training Endpoints:${NC}"
echo "  Default Training: curl https://$FUNCTION_URL/api/gpu-training"
echo "  Custom Training:  curl -X POST https://$FUNCTION_URL/api/gpu-training \\"
echo "                    -H 'Content-Type: application/json' \\"
echo "                    -d '{\"epochs\": 10, \"batch_size\": 128, \"learning_rate\": 0.001}'"
echo ""
echo -e "${BLUE}📊 A100 GPU Specifications:${NC}"
echo "  GPU: NVIDIA A100 (80GB HBM2e)"
echo "  FP32 Performance: ~488 TFLOPs"
echo "  Memory: 80GB"
echo "  vCPU: 24 cores"
echo "  RAM: 220GB"
echo "  Use Case: Production, large models, intensive training"
echo ""
echo -e "${GREEN}✅ Ready for A100 GPU training tests!${NC}"