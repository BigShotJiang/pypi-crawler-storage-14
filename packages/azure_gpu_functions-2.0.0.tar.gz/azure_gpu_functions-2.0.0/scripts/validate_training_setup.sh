#!/bin/bash

# Simple Training Validation Test
# Tests that the training types are properly configured

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "🔍 Validating Training Types Configuration"
echo "=========================================="

# Check if function_app.py exists and has training configs
if [ ! -f "$PROJECT_DIR/function_app.py" ]; then
    echo "❌ function_app.py not found"
    exit 1
fi

echo "✅ function_app.py found"

# Check if training configs are defined
if grep -q "TRAINING_CONFIGS" "$PROJECT_DIR/function_app.py"; then
    echo "✅ Training configurations found in function_app.py"
else
    echo "❌ Training configurations not found"
    exit 1
fi

# Check if training functions are defined
functions=("train_with_pytorch" "prepare_training_data")
for func in "${functions[@]}"; do
    if grep -q "def $func" "$PROJECT_DIR/function_app.py"; then
        echo "✅ Function $func found"
    else
        echo "❌ Function $func not found"
        exit 1
    fi
done

# Check training types
training_types=("small" "medium" "large" "xl")
for type in "${training_types[@]}"; do
    if grep -q "\"$type\":" "$PROJECT_DIR/function_app.py"; then
        echo "✅ Training type '$type' configured"
    else
        echo "❌ Training type '$type' not found"
        exit 1
    fi
done

# Check requirements.txt has necessary packages
required_packages=("torch" "transformers" "datasets" "peft")
for package in "${required_packages[@]}"; do
    if grep -q "$package" "$PROJECT_DIR/requirements.txt"; then
        echo "✅ Package $package found in requirements.txt"
    else
        echo "❌ Package $package not found in requirements.txt"
        exit 1
    fi
done

# Check if test scripts exist
test_scripts=("quick_training_test.sh" "training_performance_test.sh")
for script in "${test_scripts[@]}"; do
    if [ -x "$SCRIPT_DIR/$script" ]; then
        echo "✅ Test script $script is executable"
    else
        echo "❌ Test script $script not found or not executable"
        exit 1
    fi
done

echo ""
echo "🎉 All training type validations passed!"
echo ""
echo "Next steps:"
echo "1. Deploy the function app: ./deploy_with_caching.sh"
echo "2. Run quick tests: ./scripts/quick_training_test.sh all"
echo "3. Run full performance test: ./scripts/training_performance_test.sh"
echo ""
echo "Environment variables needed:"
echo "  FUNCTION_URL=https://your-function-app.azurewebsites.net"
echo "  FUNCTION_KEY=your-function-key"