#!/bin/bash

# A100 GPU Training Test Script
# Tests the neural network training functionality on A100 GPUs

set -e

# Configuration
RESOURCE_GROUP="rg-gpu-func-test-eastus"
FUNCTION_NAME="gpu-function-a100-training"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🧠 A100 GPU Training Test Script${NC}"
echo "================================="
echo ""

# Function to test endpoint
test_endpoint() {
    local url=$1
    local description=$2
    local expected_status=${3:-200}

    echo -e "${YELLOW}Testing: $description${NC}"
    echo -e "${BLUE}URL: $url${NC}"

    response=$(curl -s -w "\nHTTPSTATUS:%{http_code}" "$url")
    http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    body=$(echo "$response" | sed -e 's/HTTPSTATUS:.*//g')

    if [ "$http_code" -eq "$expected_status" ]; then
        echo -e "${GREEN}✅ HTTP $http_code - Success${NC}"

        # Parse and display key metrics for training
        if [[ $url == *"gpu-training"* ]]; then
            echo -e "${BLUE}Training Results:${NC}"

            # Extract key metrics
            training_time=$(echo "$body" | jq -r '.results.total_training_time_seconds // empty' 2>/dev/null)
            final_loss=$(echo "$body" | jq -r '.results.final_loss // empty' 2>/dev/null)
            test_accuracy=$(echo "$body" | jq -r '.results.test_accuracy // empty' 2>/dev/null)
            memory_peak=$(echo "$body" | jq -r '.results.memory_peak_gb // empty' 2>/dev/null)
            device=$(echo "$body" | jq -r '.device // empty' 2>/dev/null)

            if [ -n "$training_time" ]; then
                echo "  ⏱️  Training Time: $training_time seconds"
            fi
            if [ -n "$final_loss" ]; then
                echo "  📉 Final Loss: $final_loss"
            fi
            if [ -n "$test_accuracy" ]; then
                echo "  🎯 Test Accuracy: $(echo "$test_accuracy * 100" | bc -l | xargs printf "%.2f")%"
            fi
            if [ -n "$memory_peak" ]; then
                echo "  🧠 Peak Memory: $memory_peak GB"
            fi
            if [ -n "$device" ]; then
                echo "  🎮 Device: $device"
            fi
        elif [[ $url == *"gpu-status"* ]]; then
            # Check if T4 GPU is detected
            gpu_name=$(echo "$body" | jq -r '.gpu.device_name // empty' 2>/dev/null)
            if [[ $gpu_name == *"T4"* ]]; then
                echo -e "${GREEN}✅ T4 GPU detected: $gpu_name${NC}"
            elif [[ $gpu_name == *"Tesla T4"* ]]; then
                echo -e "${GREEN}✅ Tesla T4 GPU detected${NC}"
            else
                echo -e "${YELLOW}⚠️  GPU detected: $gpu_name (not T4)${NC}"
            fi
        fi
    else
        echo -e "${RED}❌ HTTP $http_code - Failed${NC}"
        echo -e "${RED}Response: $body${NC}"
        return 1
    fi
    echo ""
}

# Get function URL
echo -e "${YELLOW}🔍 Getting T4 GPU Function URL...${NC}"
FUNCTION_URL=$(az containerapp show \
    --name $FUNCTION_NAME \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv 2>/dev/null)

if [ -z "$FUNCTION_URL" ]; then
    echo -e "${RED}❌ T4 GPU function not found. Run ./deploy_t4_training.sh first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ T4 GPU Function URL: https://$FUNCTION_URL${NC}"
echo ""

# Test basic endpoints
echo -e "${YELLOW}🔍 Testing Basic Functionality${NC}"
echo "=================================="

test_endpoint "https://$FUNCTION_URL/api/health" "Health Check"
test_endpoint "https://$FUNCTION_URL/api/gpu-status" "T4 GPU Status Check"

# Test GPU computation
echo -e "${YELLOW}🔍 Testing T4 GPU Computation${NC}"
echo "=================================="

test_endpoint "https://$FUNCTION_URL/api/gpu-test" "T4 GPU Matrix Multiplication Test"

# Test training with different configurations
echo -e "${YELLOW}🧠 Testing T4 GPU Neural Network Training${NC}"
echo "=============================================="

echo -e "${BLUE}Test 1: Default Training (5 epochs, 64 batch size)${NC}"
test_endpoint "https://$FUNCTION_URL/api/gpu-training" "T4 GPU Default Training"

echo -e "${BLUE}Test 2: Extended Training (10 epochs, 128 batch size)${NC}"
curl -s -X POST "https://$FUNCTION_URL/api/gpu-training" \
    -H "Content-Type: application/json" \
    -d '{"epochs": 10, "batch_size": 128, "learning_rate": 0.001}' \
    -w "\nHTTPSTATUS:%{http_code}" | \
{
    response=$(cat)
    http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    body=$(echo "$response" | sed -e 's/HTTPSTATUS:.*//g')

    if [ "$http_code" -eq "200" ]; then
        echo -e "${GREEN}✅ HTTP 200 - Extended Training Success${NC}"

        # Extract and display metrics
        training_time=$(echo "$body" | jq -r '.results.total_training_time_seconds // empty' 2>/dev/null)
        final_loss=$(echo "$body" | jq -r '.results.final_loss // empty' 2>/dev/null)
        test_accuracy=$(echo "$body" | jq -r '.results.test_accuracy // empty' 2>/dev/null)

        echo -e "${BLUE}Extended Training Results:${NC}"
        echo "  ⏱️  Training Time: $training_time seconds"
        echo "  📉 Final Loss: $final_loss"
        echo "  🎯 Test Accuracy: $(echo "$test_accuracy * 100" | bc -l | xargs printf "%.2f")%"
    else
        echo -e "${RED}❌ HTTP $http_code - Extended Training Failed${NC}"
    fi
}
echo ""

echo -e "${YELLOW}🧠 Testing T4 GPU Memory Efficiency${NC}"
echo "========================================"

echo -e "${BLUE}Test 3: Large Batch Training (stress test memory)${NC}"
curl -s -X POST "https://$FUNCTION_URL/api/gpu-training" \
    -H "Content-Type: application/json" \
    -d '{"epochs": 3, "batch_size": 256, "learning_rate": 0.01}' \
    -w "\nHTTPSTATUS:%{http_code}" | \
{
    response=$(cat)
    http_code=$(echo "$response" | tr -d '\n' | sed -e 's/.*HTTPSTATUS://')
    body=$(echo "$response" | jq -r '.results.memory_peak_gb // empty' 2>/dev/null)

    if [ "$http_code" -eq "200" ] && [ -n "$body" ]; then
        echo -e "${GREEN}✅ Memory Test Passed${NC}"
        echo -e "${BLUE}Peak Memory Usage: $body GB (T4 has 16GB total)${NC}"

        # Check if memory usage is reasonable for T4
        memory_gb=$(echo "$body" | bc -l 2>/dev/null || echo "0")
        if (( $(echo "$memory_gb < 12" | bc -l) )); then
            echo -e "${GREEN}✅ Memory usage is efficient for T4 GPU${NC}"
        else
            echo -e "${YELLOW}⚠️  High memory usage detected${NC}"
        fi
    else
        echo -e "${RED}❌ Memory test failed${NC}"
    fi
}
echo ""

# Performance analysis
echo -e "${BLUE}📊 A100 GPU Training Performance Analysis${NC}"
echo "==========================================="

echo -e "${GREEN}✅ A100 GPU Specifications:${NC}"
echo "  • GPU: NVIDIA A100"
echo "  • Memory: 80GB HBM2e"
echo "  • FP32 Performance: ~488 TFLOPs"
echo "  • Architecture: Ampere"
echo "  • Use Case: Production, large models, intensive training"
echo ""

echo -e "${GREEN}✅ Training Test Results:${NC}"
echo "  • Neural Network: 3-layer MLP (784→128→64→10)"
echo "  • Dataset: 10,000 synthetic samples"
echo "  • Task: 10-class classification"
echo "  • Framework: PyTorch 2.9.1+cu121"
echo ""

echo -e "${BLUE}💡 A100 GPU Training Insights:${NC}"
echo "  • Exceptional performance for large-scale training"
echo "  • Massive memory capacity for huge models"
echo "  • Multi-instance GPU support for distributed training"
echo "  • Optimized for production ML workloads"
echo "  • Best for high-throughput training pipelines"
echo ""

echo -e "${GREEN}🎉 A100 GPU Training Tests Complete!${NC}"
echo ""
echo -e "${BLUE}Next Steps:${NC}"
echo "  1. Review training performance metrics above"
echo "  2. Scale to larger models with A100's capacity"
echo "  3. Consider distributed training for maximum performance"
echo ""
echo -e "${GREEN}✅ A100 GPU training validation successful!${NC}"