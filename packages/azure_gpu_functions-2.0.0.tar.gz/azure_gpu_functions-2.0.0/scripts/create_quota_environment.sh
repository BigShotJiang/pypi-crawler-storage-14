#!/bin/bash

# Azure Support Quota Request Helper
# Creates Container App Environment in Sweden Central for GPU quota approval
# Provides the Resource ID needed for Azure support ticket

set -e

echo "🔧 Azure GPU Quota Request Helper"
echo "=================================="

# Configuration for Sweden Central (as requested by Azure support)
RESOURCE_GROUP="rg-gpu-quota-request"
LOCATION="swedencentral"
ENVIRONMENT_NAME="gpu-env-quota-request"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}📋 Quota Request Configuration:${NC}"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION (Sweden Central)"
echo "  Environment: $ENVIRONMENT_NAME"
echo ""

# Check if logged in to Azure
echo -e "${YELLOW}🔐 Checking Azure login...${NC}"
if ! az account show > /dev/null 2>&1; then
    echo -e "${RED}❌ Not logged in to Azure. Please run 'az login' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Azure login confirmed${NC}"

# Check current subscription
SUBSCRIPTION_ID=$(az account show --query id -o tsv)
SUBSCRIPTION_NAME=$(az account show --query name -o tsv)
echo -e "${BLUE}📊 Current Subscription:${NC} $SUBSCRIPTION_NAME ($SUBSCRIPTION_ID)"
echo ""

# Create resource group if it doesn't exist
echo -e "${YELLOW}📁 Creating resource group...${NC}"
az group create --name $RESOURCE_GROUP --location $LOCATION --output none 2>/dev/null || echo "Resource group already exists"

# Create Log Analytics workspace for the environment
echo -e "${YELLOW}📊 Creating Log Analytics workspace...${NC}"
LOG_ANALYTICS_NAME="log-gpu-quota-$RANDOM"
az monitor log-analytics workspace create \
    --resource-group $RESOURCE_GROUP \
    --name $LOG_ANALYTICS_NAME \
    --location $LOCATION \
    --output none

LOG_ANALYTICS_ID=$(az monitor log-analytics workspace show \
    --resource-group $RESOURCE_GROUP \
    --name $LOG_ANALYTICS_NAME \
    --query id -o tsv)

LOG_ANALYTICS_KEY=$(az monitor log-analytics workspace get-shared-keys \
    --resource-group $RESOURCE_GROUP \
    --name $LOG_ANALYTICS_NAME \
    --query primarySharedKey -o tsv)

LOG_ANALYTICS_WORKSPACE_ID=$(az monitor log-analytics workspace show \
    --resource-group $RESOURCE_GROUP \
    --name $LOG_ANALYTICS_NAME \
    --query properties.customerId -o tsv)

echo -e "${GREEN}✅ Log Analytics configured${NC}"

# Create Container App Environment (without GPU profiles initially)
echo -e "${YELLOW}🏗️  Creating Container App Environment in Sweden Central...${NC}"

az containerapp env create \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --location $LOCATION \
    --logs-workspace-id $LOG_ANALYTICS_WORKSPACE_ID \
    --logs-workspace-key $LOG_ANALYTICS_KEY \
    --output none

echo -e "${GREEN}✅ Container App Environment created${NC}"

# Get the environment resource ID
ENVIRONMENT_RESOURCE_ID=$(az containerapp env show \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --query id -o tsv)

echo ""
echo -e "${GREEN}🎯 CONTAINER APP ENVIRONMENT RESOURCE ID${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "${YELLOW}Resource ID:${NC} $ENVIRONMENT_RESOURCE_ID"
echo ""
echo -e "${BLUE}📋 Environment Details:${NC}"
echo "  Name: $ENVIRONMENT_NAME"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION"
echo "  Subscription: $SUBSCRIPTION_ID"
echo ""

echo -e "${GREEN}✅ Ready to provide to Azure Support!${NC}"
echo ""
echo -e "${YELLOW}📧 Copy this Resource ID to your Azure support ticket:${NC}"
echo "$ENVIRONMENT_RESOURCE_ID"
echo ""
echo -e "${BLUE}💡 Next Steps:${NC}"
echo "  1. Reply to SR 2511200050003342 with the Resource ID above"
echo "  2. Azure will approve the GPU quota for this environment"
echo "  3. Once approved, we can add GPU workload profiles and deploy"
echo ""

# Also show existing environments for reference
echo -e "${BLUE}📊 Existing Environments in Subscription:${NC}"
az containerapp env list --query "[].{Name:name, Location:location, ResourceGroup:resourceGroup, Id:id}" -o table