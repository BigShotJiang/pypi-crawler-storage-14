#!/bin/bash

# Sweden Central GPU Deployment Script
# Deploys GPU functions to the quota-approved environment in Sweden Central
# Supports both A100 and T4 GPU profiles once quotas are approved

set -e

echo "🚀 Sweden Central GPU Deployment Script"
echo "======================================"

# Configuration - Using the quota-approved environment
RESOURCE_GROUP="rg-gpu-quota-swedencentral"
LOCATION="swedencentral"
ENVIRONMENT_NAME="gpu-env-quota-sr-2511200050003342"
ACR_NAME="acrgpuquotaswedencentral"

# GPU Profile Selection
GPU_TYPE=${1:-"A100"}  # Default to A100, can pass "T4" as argument

case $GPU_TYPE in
    "A100")
        WORKLOAD_PROFILE_NAME="gpu-a100-profile"
        WORKLOAD_PROFILE_TYPE="Consumption-GPU-NC24-A100"
        FUNCTION_NAME="gpu-function-a100-training"
        GPU_SPECS="NVIDIA A100 (80GB HBM2e) - 488 TFLOPs"
        ;;
    "T4")
        WORKLOAD_PROFILE_NAME="gpu-t4-profile"
        WORKLOAD_PROFILE_TYPE="Consumption-GPU-NC8as-T4"
        FUNCTION_NAME="gpu-function-t4-training"
        GPU_SPECS="NVIDIA T4 (16GB GDDR6) - 65 TFLOPs"
        ;;
    *)
        echo "❌ Invalid GPU type. Use 'A100' or 'T4'"
        exit 1
        ;;
esac

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}📋 Sweden Central $GPU_TYPE GPU Deployment Configuration:${NC}"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION"
echo "  Environment: $ENVIRONMENT_NAME"
echo "  ACR: $ACR_NAME"
echo "  GPU Profile: $WORKLOAD_PROFILE_TYPE"
echo "  GPU Specs: $GPU_SPECS"
echo ""

# Check if logged in to Azure
echo -e "${YELLOW}🔐 Checking Azure login...${NC}"
if ! az account show > /dev/null 2>&1; then
    echo -e "${RED}❌ Not logged in to Azure. Please run 'az login' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Azure login confirmed${NC}"

# Verify we're in the correct subscription
CURRENT_SUBSCRIPTION=$(az account show --query id -o tsv)
if [ "$CURRENT_SUBSCRIPTION" != "283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba" ]; then
    echo -e "${RED}❌ Wrong subscription. Please switch to subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba${NC}"
    echo -e "${YELLOW}Run: az account set --subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Correct subscription confirmed${NC}"

# Check if environment exists
echo -e "${YELLOW}🔍 Checking Container App Environment...${NC}"
if ! az containerapp env show --name $ENVIRONMENT_NAME --resource-group $RESOURCE_GROUP > /dev/null 2>&1; then
    echo -e "${RED}❌ Environment $ENVIRONMENT_NAME not found in $RESOURCE_GROUP${NC}"
    echo -e "${YELLOW}Please ensure the quota request environment exists${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Environment exists${NC}"

# Create Azure Container Registry if it doesn't exist
echo -e "${YELLOW}🏗️  Setting up Azure Container Registry...${NC}"
az acr create \
    --resource-group $RESOURCE_GROUP \
    --name $ACR_NAME \
    --sku Basic \
    --admin-enabled true \
    --output none 2>/dev/null || echo "ACR already exists"

# Ensure admin access is enabled
az acr update --name $ACR_NAME --admin-enabled true --output none

echo -e "${GREEN}✅ Azure Container Registry ready${NC}"

# Build and push the GPU container image
echo -e "${YELLOW}🏗️  Building and pushing GPU container image...${NC}"

# Build the image with GPU support
az acr build \
    --registry $ACR_NAME \
    --image gpu-function-simple:latest \
    --file Dockerfile.simple \
    . \
    --output none

echo -e "${GREEN}✅ GPU container image built and pushed${NC}"

# Get environment ID
ENVIRONMENT_ID=$(az containerapp env show \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --query id -o tsv)

echo -e "${GREEN}✅ Environment ID: $ENVIRONMENT_ID${NC}"

# Add GPU workload profile to environment (if not already added)
echo -e "${YELLOW}🔧 Adding $GPU_TYPE GPU workload profile to environment...${NC}"

# Check if profile already exists
EXISTING_PROFILES=$(az containerapp env workload-profile list \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --query "[].name" -o tsv)

if echo "$EXISTING_PROFILES" | grep -q "^${WORKLOAD_PROFILE_NAME}$"; then
    echo -e "${BLUE}ℹ️  GPU workload profile already exists${NC}"
else
    # Add the GPU workload profile
    az containerapp env workload-profile set \
        --name $ENVIRONMENT_NAME \
        --resource-group $RESOURCE_GROUP \
        --workload-profile-name $WORKLOAD_PROFILE_NAME \
        --workload-profile-type $WORKLOAD_PROFILE_TYPE \
        --min-nodes 0 \
        --max-nodes 1 \
        --output none

    echo -e "${GREEN}✅ GPU workload profile added${NC}"
fi

# Deploy the function app with GPU profile
echo -e "${YELLOW}🚀 Deploying Azure Function with $GPU_TYPE GPU support...${NC}"

# Set CPU and memory based on GPU type
if [ "$GPU_TYPE" = "A100" ]; then
    CPU_CORES="4.0"
    MEMORY="16.0Gi"
else
    CPU_CORES="2.0"
    MEMORY="8.0Gi"
fi

az containerapp create \
    --name $FUNCTION_NAME \
    --resource-group $RESOURCE_GROUP \
    --environment $ENVIRONMENT_ID \
    --image $ACR_NAME.azurecr.io/gpu-function-simple:latest \
    --registry-server $ACR_NAME.azurecr.io \
    --registry-username $ACR_NAME \
    --registry-password $(az acr credential show --name $ACR_NAME --query passwords[0].value -o tsv) \
    --cpu $CPU_CORES \
    --memory $MEMORY \
    --min-replicas 0 \
    --max-replicas 1 \
    --workload-profile-name $WORKLOAD_PROFILE_NAME \
    --target-port 80 \
    --ingress external \
    --output none

echo -e "${GREEN}✅ $GPU_TYPE GPU Function deployed${NC}"

# Get function URL
FUNCTION_URL=$(az containerapp show \
    --name $FUNCTION_NAME \
    --resource-group $RESOURCE_GROUP \
    --query properties.configuration.ingress.fqdn -o tsv)

echo ""
echo -e "${GREEN}🎉 $GPU_TYPE GPU Deployment Complete!${NC}"
echo ""
echo -e "${BLUE}📋 $GPU_TYPE GPU Function URLs:${NC}"
echo "  Health Check:     https://$FUNCTION_URL/api/health"
echo "  GPU Status:       https://$FUNCTION_URL/api/gpu-status"
echo "  GPU Test:         https://$FUNCTION_URL/api/gpu-test"
echo "  GPU Training:     https://$FUNCTION_URL/api/gpu-training"
echo ""
echo -e "${YELLOW}🧠 $GPU_TYPE GPU Training Endpoints:${NC}"
echo "  Default Training: curl https://$FUNCTION_URL/api/gpu-training"
echo "  Custom Training:  curl -X POST https://$FUNCTION_URL/api/gpu-training \\"
echo "                    -H 'Content-Type: application/json' \\"
echo "                    -d '{\"epochs\": 10, \"batch_size\": 128, \"learning_rate\": 0.001}'"
echo ""
echo -e "${BLUE}📊 $GPU_TYPE GPU Specifications:${NC}"
if [ "$GPU_TYPE" = "A100" ]; then
    echo "  GPU: NVIDIA A100 (80GB HBM2e)"
    echo "  FP32 Performance: ~488 TFLOPs"
    echo "  Memory: 80GB"
    echo "  vCPU: 24 cores"
    echo "  RAM: 220GB"
    echo "  Use Case: Production, large models, intensive training"
else
    echo "  GPU: NVIDIA T4 (16GB GDDR6)"
    echo "  FP32 Performance: ~65 TFLOPs"
    echo "  Memory: 16GB"
    echo "  vCPU: 8 cores"
    echo "  RAM: 56GB"
    echo "  Use Case: Development, testing, smaller models"
fi
echo ""
echo -e "${GREEN}✅ Ready for $GPU_TYPE GPU training tests!${NC}"
echo ""
echo -e "${YELLOW}🧪 Run tests with:${NC}"
echo "  ./test_swedencentral_gpu.sh $GPU_TYPE"