#!/usr/bin/env python3
"""
Training Resource Monitor and Cleanup Script
Checks for orphaned training resources and ensures proper cleanup
"""

import asyncio
import json
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import aiohttp
import psutil
import GPUtil
from azure.monitor import MonitorClient
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from azure.mgmt.containerinstance import ContainerInstanceManagementClient
from azure.mgmt.containerapps import ContainerAppsAPIClient
import ray
import subprocess
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TrainingResourceMonitor:
    def __init__(self, subscription_id: str, resource_group: str, function_app_name: str):
        self.subscription_id = subscription_id
        self.resource_group = resource_group
        self.function_app_name = function_app_name
        self.credential = DefaultAzureCredential()

        # Initialize Azure clients
        self.container_client = ContainerAppsAPIClient(self.credential, self.subscription_id)
        self.monitor_client = MonitorClient(self.credential, self.subscription_id)

        # Local monitoring
        self.local_processes = []
        self.gpu_processes = []

        # Configuration
        self.max_training_duration_hours = 24  # Maximum allowed training time
        self.cleanup_threshold_minutes = 30    # Time after which to consider resources orphaned

    async def check_azure_function_instances(self) -> Dict:
        """Check for running Azure Function instances"""
        try:
            # Get function app status
            function_app = await self.container_client.container_apps.get(
                self.resource_group, self.function_app_name
            )

            instances = {
                'function_app': {
                    'name': function_app.name,
                    'provisioning_state': function_app.provisioning_state,
                    'running_instances': getattr(function_app, 'instances', []),
                    'environment_id': function_app.managed_environment_id,
                    'last_modified': function_app.system_data.last_modified_at.isoformat() if function_app.system_data else None
                }
            }

            # Check for active revisions
            revisions = await self.container_client.container_apps.list_revisions(
                self.resource_group, self.function_app_name
            )
            instances['active_revisions'] = [rev.name for rev in revisions if rev.properties.active]

            return instances

        except Exception as e:
            logger.error(f"Error checking Azure Function instances: {e}")
            return {'error': str(e)}

    async def check_ray_sessions(self) -> Dict:
        """Check for active Ray sessions and processes"""
        ray_info = {
            'ray_running': False,
            'active_sessions': [],
            'orphaned_processes': [],
            'gpu_usage': []
        }

        try:
            # Check if Ray is running locally
            if ray.is_initialized():
                ray_info['ray_running'] = True

                # Get Ray cluster info
                try:
                    cluster_info = ray.cluster_resources()
                    ray_info['cluster_resources'] = cluster_info
                except Exception as e:
                    ray_info['cluster_error'] = str(e)

                # Get active actors (training sessions)
                try:
                    actors = ray.state.actors()
                    ray_info['active_actors'] = len(actors)

                    # Check for training-related actors
                    training_actors = []
                    for actor_id, actor_info in actors.items():
                        if 'training' in actor_info.get('name', '').lower() or 'train' in actor_info.get('name', '').lower():
                            training_actors.append({
                                'id': actor_id,
                                'name': actor_info.get('name'),
                                'state': actor_info.get('state'),
                                'start_time': actor_info.get('start_time_ms', 0) / 1000 if actor_info.get('start_time_ms') else None
                            })

                    ray_info['training_actors'] = training_actors

                except Exception as e:
                    ray_info['actors_error'] = str(e)

            # Check for Ray processes
            ray_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
                try:
                    if 'ray' in proc.info['name'].lower():
                        cmdline = proc.info.get('cmdline', [])
                        create_time = datetime.fromtimestamp(proc.info['create_time'])

                        ray_processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'cmdline': ' '.join(cmdline) if cmdline else '',
                            'create_time': create_time.isoformat(),
                            'age_hours': (datetime.now() - create_time).total_seconds() / 3600
                        })

                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            ray_info['ray_processes'] = ray_processes

            # Check for orphaned Ray processes (running > threshold)
            threshold_age = self.cleanup_threshold_minutes / 60
            ray_info['orphaned_processes'] = [
                proc for proc in ray_processes
                if proc['age_hours'] > threshold_age
            ]

        except Exception as e:
            logger.error(f"Error checking Ray sessions: {e}")
            ray_info['error'] = str(e)

        return ray_info

    async def check_gpu_resources(self) -> Dict:
        """Check GPU resource usage and orphaned GPU processes"""
        gpu_info = {
            'gpus_available': 0,
            'gpu_processes': [],
            'orphaned_gpu_processes': [],
            'gpu_utilization': []
        }

        try:
            # Get GPU information
            gpus = GPUtil.getGPUs()
            gpu_info['gpus_available'] = len(gpus)

            for i, gpu in enumerate(gpus):
                gpu_info['gpu_utilization'].append({
                    'id': i,
                    'name': gpu.name,
                    'utilization': gpu.load * 100,
                    'memory_used': gpu.memoryUsed,
                    'memory_total': gpu.memoryTotal,
                    'temperature': gpu.temperature
                })

            # Check for GPU processes
            gpu_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time', 'memory_info']):
                try:
                    # Check if process is using GPU (simplified check)
                    if any(keyword in ' '.join(proc.info.get('cmdline', [])).lower()
                          for keyword in ['cuda', 'gpu', 'nvidia', 'torch', 'tensorflow', 'training']):
                        create_time = datetime.fromtimestamp(proc.info['create_time'])
                        age_hours = (datetime.now() - create_time).total_seconds() / 3600

                        gpu_processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'cmdline': ' '.join(proc.info.get('cmdline', []))[:100] + '...' if len(proc.info.get('cmdline', [])) > 10 else ' '.join(proc.info.get('cmdline', [])),
                            'create_time': create_time.isoformat(),
                            'age_hours': age_hours,
                            'memory_mb': proc.info['memory_info'].rss / (1024 * 1024) if proc.info['memory_info'] else 0
                        })

                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

            gpu_info['gpu_processes'] = gpu_processes

            # Identify orphaned GPU processes
            threshold_age = self.cleanup_threshold_minutes / 60
            gpu_info['orphaned_gpu_processes'] = [
                proc for proc in gpu_processes
                if proc['age_hours'] > threshold_age
            ]

        except Exception as e:
            logger.error(f"Error checking GPU resources: {e}")
            gpu_info['error'] = str(e)

        return gpu_info

    async def check_training_sessions(self, function_uri: str) -> Dict:
        """Check for active training sessions via API"""
        training_info = {
            'active_sessions': [],
            'completed_sessions': [],
            'orphaned_sessions': [],
            'total_cost': 0.0
        }

        try:
            async with aiohttp.ClientSession() as session:
                # Get Ray monitoring status
                async with session.get(f"{function_uri}/api/ray-monitoring?action=status") as response:
                    if response.status == 200:
                        data = await response.json()
                        training_info.update(data.get('training_sessions', {}))

                        # Check for orphaned sessions (running too long)
                        for session in training_info.get('active_sessions', []):
                            start_time = datetime.fromisoformat(session.get('start_time', datetime.now().isoformat()))
                            duration_hours = (datetime.now() - start_time).total_seconds() / 3600

                            if duration_hours > self.max_training_duration_hours:
                                training_info['orphaned_sessions'].append({
                                    **session,
                                    'duration_hours': duration_hours,
                                    'reason': f'Exceeded max duration ({self.max_training_duration_hours}h)'
                                })

        except Exception as e:
            logger.error(f"Error checking training sessions: {e}")
            training_info['error'] = str(e)

        return training_info

    async def check_azure_costs(self, days: int = 7) -> Dict:
        """Check Azure costs for the resource group"""
        cost_info = {
            'total_cost': 0.0,
            'costs_by_service': {},
            'costs_by_day': [],
            'estimated_monthly': 0.0
        }

        try:
            # This would require Azure Cost Management API access
            # For now, return placeholder
            cost_info['note'] = 'Azure Cost Management API access required for detailed cost analysis'

        except Exception as e:
            logger.error(f"Error checking Azure costs: {e}")
            cost_info['error'] = str(e)

        return cost_info

    def generate_cleanup_recommendations(self, monitoring_data: Dict) -> List[str]:
        """Generate cleanup recommendations based on monitoring data"""
        recommendations = []

        # Check for orphaned Ray processes
        ray_info = monitoring_data.get('ray_sessions', {})
        orphaned_ray = ray_info.get('orphaned_processes', [])
        if orphaned_ray:
            recommendations.append(f"🧹 Found {len(orphaned_ray)} orphaned Ray processes running > {self.cleanup_threshold_minutes} minutes")
            for proc in orphaned_ray:
                recommendations.append(f"   - Kill Ray process PID {proc['pid']} (age: {proc['age_hours']:.1f}h)")

        # Check for orphaned GPU processes
        gpu_info = monitoring_data.get('gpu_resources', {})
        orphaned_gpu = gpu_info.get('orphaned_gpu_processes', [])
        if orphaned_gpu:
            recommendations.append(f"🖥️ Found {len(orphaned_gpu)} orphaned GPU processes running > {self.cleanup_threshold_minutes} minutes")
            for proc in orphaned_gpu:
                recommendations.append(f"   - Kill GPU process PID {proc['pid']} ({proc['name']}, age: {proc['age_hours']:.1f}h)")

        # Check for long-running training sessions
        training_info = monitoring_data.get('training_sessions', {})
        orphaned_sessions = training_info.get('orphaned_sessions', [])
        if orphaned_sessions:
            recommendations.append(f"🏃 Found {len(orphaned_sessions)} training sessions running > {self.max_training_duration_hours} hours")
            for session in orphaned_sessions:
                recommendations.append(f"   - Stop training session {session.get('id', 'unknown')} (duration: {session.get('duration_hours', 0):.1f}h)")

        # Check Azure Function instances
        azure_info = monitoring_data.get('azure_resources', {})
        function_app = azure_info.get('function_app', {})
        if function_app.get('running_instances'):
            recommendations.append(f"⚡ Azure Function has {len(function_app['running_instances'])} running instances - verify if needed")

        # General recommendations
        if not recommendations:
            recommendations.append("✅ No orphaned resources detected - system is clean")
        else:
            recommendations.insert(0, "🚨 Cleanup Required:")
            recommendations.append("\n💡 To cleanup automatically, run: python cleanup_resources.py --auto")

        return recommendations

    async def run_full_check(self, function_uri: Optional[str] = None) -> Dict:
        """Run comprehensive resource check"""
        logger.info("🔍 Starting comprehensive resource check...")

        monitoring_data = {}

        # Check Azure resources
        logger.info("📊 Checking Azure Function instances...")
        monitoring_data['azure_resources'] = await self.check_azure_function_instances()

        # Check Ray sessions
        logger.info("🌟 Checking Ray sessions...")
        monitoring_data['ray_sessions'] = await self.check_ray_sessions()

        # Check GPU resources
        logger.info("🖥️ Checking GPU resources...")
        monitoring_data['gpu_resources'] = await self.check_gpu_resources()

        # Check training sessions if function URI provided
        if function_uri:
            logger.info("🏃 Checking training sessions...")
            monitoring_data['training_sessions'] = await self.check_training_sessions(function_uri)

        # Check costs
        logger.info("💰 Checking costs...")
        monitoring_data['costs'] = await self.check_azure_costs()

        # Generate recommendations
        monitoring_data['recommendations'] = self.generate_cleanup_recommendations(monitoring_data)

        # Add timestamp
        monitoring_data['timestamp'] = datetime.now().isoformat()
        monitoring_data['check_duration_seconds'] = time.time()

        logger.info("✅ Resource check completed")
        return monitoring_data

    def save_report(self, monitoring_data: Dict, filename: str = "resource_check_report.json"):
        """Save monitoring report to file"""
        with open(filename, 'w') as f:
            json.dump(monitoring_data, f, indent=2, default=str)

        print(f"📊 Resource check report saved to {filename}")

    def print_summary(self, monitoring_data: Dict):
        """Print human-readable summary"""
        print("\n" + "="*60)
        print("🔍 TRAINING RESOURCE MONITORING SUMMARY")
        print("="*60)

        # Azure Resources
        azure = monitoring_data.get('azure_resources', {})
        if 'function_app' in azure:
            fa = azure['function_app']
            print(f"⚡ Azure Function: {fa.get('name', 'Unknown')}")
            print(f"   Status: {fa.get('provisioning_state', 'Unknown')}")
            print(f"   Running Instances: {len(fa.get('running_instances', []))}")

        # Ray Sessions
        ray_info = monitoring_data.get('ray_sessions', {})
        print(f"🌟 Ray Running: {ray_info.get('ray_running', False)}")
        print(f"   Active Actors: {ray_info.get('active_actors', 0)}")
        print(f"   Orphaned Processes: {len(ray_info.get('orphaned_processes', []))}")

        # GPU Resources
        gpu_info = monitoring_data.get('gpu_resources', {})
        print(f"🖥️ GPUs Available: {gpu_info.get('gpus_available', 0)}")
        print(f"   GPU Processes: {len(gpu_info.get('gpu_processes', []))}")
        print(f"   Orphaned GPU Processes: {len(gpu_info.get('orphaned_gpu_processes', []))}")

        # Training Sessions
        training = monitoring_data.get('training_sessions', {})
        if training:
            print(f"🏃 Active Training Sessions: {len(training.get('active_sessions', []))}")
            print(f"   Orphaned Sessions: {len(training.get('orphaned_sessions', []))}")

        # Recommendations
        recommendations = monitoring_data.get('recommendations', [])
        if recommendations:
            print("\n💡 RECOMMENDATIONS:")
            for rec in recommendations:
                print(f"   {rec}")

        print(f"\n📅 Check completed at: {monitoring_data.get('timestamp', 'Unknown')}")
        print("="*60)

async def main():
    # Configuration - update these values based on your deployment
    SUBSCRIPTION_ID = os.getenv("AZURE_SUBSCRIPTION_ID", "283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba")
    RESOURCE_GROUP = os.getenv("AZURE_RESOURCE_GROUP", "rg-gpu-functions")
    FUNCTION_APP_NAME = os.getenv("AZURE_FUNCTION_APP_NAME", "your-function-app")
    FUNCTION_URI = os.getenv("FUNCTION_URI", None)

    # Initialize monitor
    monitor = TrainingResourceMonitor(SUBSCRIPTION_ID, RESOURCE_GROUP, FUNCTION_APP_NAME)

    # Run full check
    monitoring_data = await monitor.run_full_check(FUNCTION_URI)

    # Print summary
    monitor.print_summary(monitoring_data)

    # Save detailed report
    monitor.save_report(monitoring_data)

if __name__ == "__main__":
    asyncio.run(main())