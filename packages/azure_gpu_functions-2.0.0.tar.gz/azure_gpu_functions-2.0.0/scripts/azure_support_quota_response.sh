#!/bin/bash

# Azure Support Quota Request Helper
# Creates Container App Environment in Sweden Central for GPU quota approval
# Provides the Resource ID needed for Azure support ticket SR 2511200050003342

set -e

echo "🔧 Azure GPU Quota Request Helper"
echo "=================================="
echo "Support Ticket: SR 2511200050003342"
echo "Request: Container Apps quota for Managed Environment"
echo "       - Consumption NCA100 GPUs to 24"
echo "       - T4 GPUs to 16"
echo "Region: Sweden Central"
echo ""

# Configuration for Sweden Central (as requested by Azure support)
RESOURCE_GROUP="rg-gpu-quota-swedencentral"
LOCATION="swedencentral"
ENVIRONMENT_NAME="gpu-env-quota-sr-2511200050003342"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}📋 Quota Request Configuration:${NC}"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION (Sweden Central)"
echo "  Environment: $ENVIRONMENT_NAME"
echo "  Subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
echo ""

# Check if logged in to Azure
echo -e "${YELLOW}🔐 Checking Azure login...${NC}"
if ! az account show > /dev/null 2>&1; then
    echo -e "${RED}❌ Not logged in to Azure. Please run 'az login' first.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Azure login confirmed${NC}"

# Verify we're in the correct subscription
CURRENT_SUBSCRIPTION=$(az account show --query id -o tsv)
if [ "$CURRENT_SUBSCRIPTION" != "283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba" ]; then
    echo -e "${RED}❌ Wrong subscription. Please switch to subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba${NC}"
    echo -e "${YELLOW}Run: az account set --subscription 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Correct subscription confirmed${NC}"

# Create resource group if it doesn't exist
echo -e "${YELLOW}📁 Creating resource group...${NC}"
az group create --name $RESOURCE_GROUP --location $LOCATION --output none 2>/dev/null || echo "Resource group already exists"

# Create Container App Environment (without GPU profiles initially)
echo -e "${YELLOW}🏗️  Creating Container App Environment in Sweden Central...${NC}"

az containerapp env create \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --location $LOCATION \
    --output none

echo -e "${GREEN}✅ Container App Environment created${NC}"

# Get the environment resource ID
ENVIRONMENT_RESOURCE_ID=$(az containerapp env show \
    --name $ENVIRONMENT_NAME \
    --resource-group $RESOURCE_GROUP \
    --query id -o tsv)

echo ""
echo -e "${GREEN}🎯 CONTAINER APP ENVIRONMENT RESOURCE ID${NC}"
echo -e "${BLUE}========================================${NC}"
echo -e "${YELLOW}Resource ID:${NC} $ENVIRONMENT_RESOURCE_ID"
echo ""
echo -e "${BLUE}📋 Environment Details:${NC}"
echo "  Name: $ENVIRONMENT_NAME"
echo "  Resource Group: $RESOURCE_GROUP"
echo "  Location: $LOCATION"
echo "  Subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
echo ""

echo -e "${GREEN}✅ Ready to provide to Azure Support!${NC}"
echo ""
echo -e "${YELLOW}📧 Copy this Resource ID to your Azure support reply:${NC}"
echo "$ENVIRONMENT_RESOURCE_ID"
echo ""
echo -e "${BLUE}💡 Response Template:${NC}"
echo "Hello Azure Support,"
echo ""
echo "Regarding SR 2511200050003342 for Container Apps quota approval:"
echo ""
echo "Container App Environment Resource ID:"
echo "$ENVIRONMENT_RESOURCE_ID"
echo ""
echo "Please approve the requested quotas:"
echo "- Consumption NCA100 GPUs: 24"
echo "- T4 GPUs: 16"
echo "- Region: Sweden Central"
echo "- Subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
echo ""
echo "Thank you,"
echo "Xavier CALLENS"
echo ""

# Also show existing environments for reference
echo -e "${BLUE}📊 All Environments in Subscription:${NC}"
az containerapp env list --query "[].{Name:name, Location:location, ResourceGroup:resourceGroup, Id:id}" -o table