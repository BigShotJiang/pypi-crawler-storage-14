#!/bin/bash

# Deploy GPU workload profile and container app (skip image build)
set -e

# Configuration
SUBSCRIPTION_ID="283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba"
LOCATION="northeurope"
RESOURCE_GROUP="rg-llm-gpu-function-test"
CONTAINER_REGISTRY="acrgpufunctest"
FUNCTION_APP="func-gpu-test"
ENVIRONMENT="gpu-func-env"
IMAGE_NAME="gpu-function-simple:latest"
WORKLOAD_PROFILE_NAME="gpua100"
WORKLOAD_PROFILE_TYPE="NC24-A100"

echo "🚀 Deploying GPU Function (using existing image)"
echo "=================================================="

# Set subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Add GPU workload profile
echo "⚡ Adding GPU workload profile (NC24-A100)..."
az containerapp env workload-profile add \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --workload-profile-type "$WORKLOAD_PROFILE_TYPE" \
    --min-nodes 1 \
    --max-nodes 1 2>&1 || echo "Note: GPU profile may already exist"

# Verify workload profiles
echo ""
echo "📋 Verifying workload profiles..."
az containerapp env workload-profile list \
    --name "$ENVIRONMENT" \
    --resource-group "$RESOURCE_GROUP" \
    -o table

# Get ACR credentials
echo ""
echo "🔑 Getting container registry credentials..."
ACR_SERVER=$(az acr show --name "$CONTAINER_REGISTRY" --query loginServer -o tsv)
ACR_USERNAME=$(az acr credential show --name "$CONTAINER_REGISTRY" --query username -o tsv)
ACR_PASSWORD=$(az acr credential show --name "$CONTAINER_REGISTRY" --query passwords[0].value -o tsv)

# Get storage connection
STORAGE_NAME=$(az storage account list --resource-group "$RESOURCE_GROUP" --query "[0].name" -o tsv)
STORAGE_CONNECTION=$(az storage account show-connection-string \
    --name "$STORAGE_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query connectionString -o tsv)

# Deploy Container App with GPU
echo ""
echo "🚀 Deploying Azure Function with GPU..."
az containerapp create \
    --name "$FUNCTION_APP" \
    --resource-group "$RESOURCE_GROUP" \
    --environment "$ENVIRONMENT" \
    --image "$ACR_SERVER/$IMAGE_NAME" \
    --registry-server "$ACR_SERVER" \
    --registry-username "$ACR_USERNAME" \
    --registry-password "$ACR_PASSWORD" \
    --workload-profile-name "$WORKLOAD_PROFILE_NAME" \
    --cpu 4.0 \
    --memory 32Gi \
    --min-replicas 0 \
    --max-replicas 1 \
    --ingress external \
    --target-port 80 \
    --env-vars \
        "FUNCTIONS_WORKER_RUNTIME=python" \
        "FUNCTIONS_EXTENSION_VERSION=~4" \
        "AzureWebJobsStorage=$STORAGE_CONNECTION" \
        "NVIDIA_VISIBLE_DEVICES=all" \
        "CUDA_VISIBLE_DEVICES=0" \
        "PYTHON_ISOLATE_WORKER_DEPENDENCIES=1"

# Get Function URL
echo ""
FUNCTION_URL=$(az containerapp show \
    --name "$FUNCTION_APP" \
    --resource-group "$RESOURCE_GROUP" \
    --query properties.configuration.ingress.fqdn -o tsv)

echo ""
echo "✅ Deployment Complete!"
echo "======================="
echo ""
echo "Function URL: https://$FUNCTION_URL"
echo ""
echo "Test commands:"
echo "  curl https://$FUNCTION_URL/api/health"
echo "  curl https://$FUNCTION_URL/api/gpu-status"
echo "  curl https://$FUNCTION_URL/api/gpu-test"
echo ""
