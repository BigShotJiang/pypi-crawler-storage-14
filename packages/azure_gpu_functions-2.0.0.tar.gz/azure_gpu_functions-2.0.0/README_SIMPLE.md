# ✅ Ready to Deploy - Simple GPU Function

## 🎯 What You Have

A **simplified Azure Function** to test A100 GPU availability with 3 endpoints:
- ✅ Health check
- ✅ GPU status (device info, memory, CUDA version)
- ✅ GPU computation test (matrix multiplication)

## 🚀 Deploy Now (3 Steps)

### Step 1: Login to Azure
Your session expired. Re-authenticate:
```bash
./login.sh
```

### Step 2: Deploy
```bash
./deploy_simple.sh
```
**Time:** ~5-10 minutes

### Step 3: Test
```bash
./test_gpu_function.sh <your-function-url>
```

The deployment script will display the function URL at the end.

## 📊 What Gets Deployed

| **Resource** | **Configuration** |
|-------------|-------------------|
| **GPU** | NC4as-A100-v4 (4 vCPU, 40GB VRAM) |
| **Memory** | 64GB RAM |
| **Scaling** | 0-1 replicas (auto-scale) |
| **Cost (idle)** | $0/hour |
| **Cost (active)** | ~$1.75/hour |
| **Region** | North Europe |

## 🧪 Test Endpoints

Once deployed, test with:

```bash
# Health check
curl https://<function-url>/api/health

# GPU status  
curl https://<function-url>/api/gpu-status

# GPU computation test
curl https://<function-url>/api/gpu-test
```

## 💡 Key Differences from Original

This simplified version:
- ✅ **No azd required** - Uses only Azure CLI
- ✅ **Simpler code** - Just GPU testing, no LLM training
- ✅ **Faster deployment** - Smaller dependencies
- ✅ **Same GPU** - NC4as-A100-v4 (your available quota)
- ✅ **Same cost savings** - Scale to zero when idle

## 📝 Files Overview

| **File** | **Purpose** |
|---------|------------|
| `login.sh` | Re-authenticate to Azure |
| `deploy_simple.sh` | Deploy all resources |
| `test_gpu_function.sh` | Test GPU endpoints |
| `function_app_simple.py` | GPU test function code |
| `Dockerfile.simple` | CUDA 12.1 container |
| `requirements_simple.txt` | PyTorch + Azure Functions |

## 🔄 After Testing

If GPU works correctly, you can:
1. Keep this simple version for testing
2. Deploy the full LLM training version (original `function_app.py`)
3. Extend with your own GPU workloads

## 🧹 Cleanup

To remove all resources:
```bash
az group delete --name rg-llm-gpu-function-test --yes --no-wait
```

---

**👉 Start here:** `./login.sh`
