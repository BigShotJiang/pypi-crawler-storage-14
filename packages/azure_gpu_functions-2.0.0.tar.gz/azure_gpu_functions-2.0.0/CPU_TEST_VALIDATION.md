# CPU-Only Test Deployment for Azure Functions GPU Validation

## Overview

This approach provides a **staged validation** of your Azure Functions GPU deployment:

1. **Phase 1 (CPU Test)**: Validate function logic and Azure infrastructure
2. **Phase 2 (GPU Deployment)**: Switch to GPU once quota is approved

## Why CPU-First Testing?

### ✅ **Validates Core Functionality**
- Azure Functions HTTP triggers work correctly
- Container deployment and scaling functions
- Application logic executes without errors
- Network connectivity and ingress configuration

### ✅ **Faster Deployment**
- No quota dependency for initial testing
- Immediate validation of setup
- Identifies configuration issues early

### ✅ **Risk-Free Testing**
- CPU resources are always available
- No GPU quota consumption during testing
- Easy cleanup if needed

## Test Deployment Architecture

### CPU-Only Environment
```
Container Apps Environment (Sweden Central)
├── Workload Profile: Consumption (CPU-only)
├── Function App: gpu-function-cpu-test
├── Resources: 1 CPU, 2GB RAM
└── Scaling: 0-1 replicas
```

### GPU Environment (After Quota Approval)
```
Container Apps Environment (Sweden Central)
├── Workload Profile: Consumption (CPU)
├── Workload Profile: Consumption-GPU-NC24-A100 (A100 GPU)
├── Workload Profile: Consumption-GPU-NC16-T4 (T4 GPU)
├── Function App: gpu-function-gpu-test
├── Resources: 24 vCPU, 220GB RAM, 1x A100 GPU
└── Scaling: 0-1 replicas (serverless)
```

## Test Scenarios

### Phase 1: CPU Validation
```bash
# Deploy CPU-only test
./deploy_cpu_test.sh

# Test all endpoints
./test_cpu_vs_gpu.sh
```

**Expected Results:**
- `/api/health` → ✅ HTTP 200 (function running)
- `/api/gpu-status` → ⚠️ "No GPU available" (expected on CPU)
- `/api/gpu-test` → ⚠️ Graceful failure (no GPU hardware)

### Phase 2: GPU Validation (After Quota)
```bash
# Deploy GPU environment
./deploy_bicep_gpu_env.sh

# Deploy GPU function
./deploy_gpu_function.sh

# Test GPU functionality
./test_cpu_vs_gpu.sh
```

**Expected Results:**
- `/api/health` → ✅ HTTP 200 (function running)
- `/api/gpu-status` → ✅ Shows A100/T4 GPU details
- `/api/gpu-test` → ✅ PyTorch matrix multiplication on GPU

## Files Created

### `deploy_cpu_test.sh`
- Deploys CPU-only Container Apps environment
- Creates Azure Function with Consumption workload profile
- Configures all necessary Azure resources
- Provides test URLs for validation

### `test_cpu_vs_gpu.sh`
- Automated testing of both CPU and GPU deployments
- Validates HTTP endpoints and responses
- Shows clear pass/fail status for each test
- Provides guidance for next steps

### `infrastructure/main.parameters.cpu.json`
- Bicep parameters for CPU-only deployment
- Zero GPU nodes (CPU consumption only)
- Sweden Central region for Consumption GPU compatibility

## Validation Checklist

### ✅ **CPU Test Success Criteria**
- [ ] Function deploys without errors
- [ ] Health endpoint returns HTTP 200
- [ ] GPU status shows "No GPU available" (expected)
- [ ] GPU test fails gracefully (no crash)
- [ ] Container logs show normal operation

### ✅ **GPU Test Success Criteria** (After Quota)
- [ ] GPU environment deploys successfully
- [ ] Function deploys to GPU workload profile
- [ ] GPU status shows hardware details (A100/T4)
- [ ] GPU test executes on GPU hardware
- [ ] PyTorch CUDA operations succeed

## Switching from CPU to GPU

### Automatic Transition
The same function code works on both CPU and GPU:

```python
# Function detects GPU automatically
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

# Same code runs on CPU or GPU
tensor = torch.randn(1000, 1000).to(device)
result = torch.mm(tensor, tensor)
```

### Deployment Changes
- **Environment**: Same Container Apps environment
- **Workload Profile**: `Consumption` → `Consumption-GPU-NC24-A100`
- **Resources**: 1 CPU → 24 vCPU + A100 GPU
- **Scaling**: Same serverless behavior

## Cost Comparison

| Deployment Type | Cost/Month | Use Case |
|----------------|------------|----------|
| **CPU Test** | ~$10-20 | Development validation |
| **GPU A100** | ~$500-1000 | Production workloads |
| **GPU T4** | ~$100-300 | Development/testing |

## Next Steps

1. **Run CPU Test**: `./deploy_cpu_test.sh`
2. **Validate Function**: `./test_cpu_vs_gpu.sh`
3. **Wait for Quota**: Monitor support ticket
4. **Deploy GPU**: Run GPU deployment scripts after approval
5. **Final Validation**: Confirm GPU acceleration works

## Troubleshooting

### CPU Deployment Issues
- Check Azure CLI login: `az account show`
- Verify resource group exists: `az group list`
- Check Container Apps quota: `az containerapp env list`

### Function Test Failures
- Check function logs: `az containerapp logs show`
- Verify container image: `az acr repository show`
- Test manually: `curl https://<url>/api/health`

### GPU Quota Issues
- Check support ticket status
- Verify quota in portal: Azure → Quotas
- Contact support if delayed beyond 2 business days

## Summary

This CPU-first approach provides **immediate validation** of your Azure Functions setup while waiting for GPU quota approval. It ensures your PyTorch application logic works correctly before investing in GPU resources, and provides a clear migration path to GPU acceleration once quota is available.