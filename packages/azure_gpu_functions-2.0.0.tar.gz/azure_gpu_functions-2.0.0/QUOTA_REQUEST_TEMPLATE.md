# Azure Support Request Template - A100 GPU Quota

## Copy-Paste Template for Azure Portal Support Request

### Basic Information
```
Issue type: Service and subscription limits (quotas)
Subscription: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba (amacp-tst-ne-gem-01)
Quota type: Compute-VM (cores-vCPUs) subscription limit increases
Problem type: Container Apps
```

### Quota Details
```
Deployment model: Resource Manager
Location: North Europe
VM Series: NCads A100 v4 Series
SKU Family: NCads A100 v4 Series
New vCPU Limit: 24
```

### Subject Line
```
A100 GPU Quota Request for Container Apps - Amadeus Test Environment - LLM Training
```

### Description (Copy this into the description field)
```
QUOTA REQUEST: NVIDIA A100 GPU for Azure Container Apps

Subscription Details:
- Subscription ID: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba
- Subscription Name: amacp-tst-ne-gem-01
- Organization: Amadeus
- Environment: Test/Development

Resource Requirements:
- Service: Azure Container Apps with GPU Workload Profiles
- Location: North Europe
- GPU Type: NVIDIA A100 (NC24ads_A100_v4)
- Requested vCPU Quota: 24 cores (equivalent to 1 NC24ads_A100_v4 instance)
- Current Quota: 0 (no GPU quota currently assigned)

Business Justification:
Our team at Amadeus is developing AI/ML capabilities for modernizing our travel technology platform. We require A100 GPU resources for:

1. Large Language Model (LLM) Training and Fine-tuning
   - Training custom models based on Mistral 70B and similar large language models
   - Fine-tuning for travel industry-specific use cases
   - Research and development of conversational AI for customer service

2. Technical Architecture
   - Azure Functions on Container Apps with GPU workload profiles
   - Serverless scaling with scale-to-zero capability for cost optimization
   - Container-based deployment with CUDA 12.1 and PyTorch
   - Integration with Azure AI services and storage solutions

3. Usage Patterns
   - Training Sessions: 2-4 hours per session, 2-3 times per week
   - Development Testing: 1-2 hours per day during active development
   - Peak Concurrent Usage: 1-3 A100 instances maximum
   - Idle Time: Scale to zero when not in use (significant cost savings)

4. Project Timeline
   - Phase: Proof of concept and testing
   - Duration: 3-6 months for initial development and validation
   - Future: May expand based on successful outcomes

5. Technical Benefits
   - A100's 80GB memory is required for large models (70B+ parameters)
   - Tensor Cores provide optimal performance for transformer architectures
   - Mixed precision training capabilities for memory efficiency
   - Fast model loading and inference for responsive applications

6. Cost Management
   - Implementing auto-scaling to minimize costs during idle periods
   - Monitoring and alerting configured for budget management
   - Using efficient training techniques (LoRA) to reduce compute requirements
   - Estimated usage: 20-40 hours per week during active development

This quota request supports Amadeus's strategic initiative to integrate advanced AI capabilities into our travel technology platform, enhancing customer experience and operational efficiency.

Technical Contact: [Your Name] - [your.email@amadeus.com]
Business Contact: [Manager Name] - [manager.email@amadeus.com]

Thank you for considering our request. We are committed to responsible usage and cost optimization.
```

### Additional Information Fields
```
Severity: Minimal (this is development/testing, not production critical)
Problem started time: [Current date]
How many users affected: Development team (approximately 3-5 developers)
Preferred contact method: Email
Business hours: Central European Time (CET)
```

### Contact Information
```
First Name: [Your First Name]
Last Name: [Your Last Name]
Company: Amadeus
Email: [your.email@amadeus.com]
Phone: [Your phone number]
Country: France
Time Zone: Central European Standard Time
Preferred Contact Method: Email
```

## 📋 Checklist Before Submitting

- [ ] Verified subscription ID: `283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba`
- [ ] Confirmed you have Contributor/Owner role on subscription
- [ ] Customized contact information with your details
- [ ] Reviewed business justification for accuracy
- [ ] Estimated costs and obtained budget approval if needed
- [ ] Set "Severity" to "Minimal" (this is not production-critical)
- [ ] Double-checked location: "North Europe"
- [ ] Requested reasonable quota: 24 vCPUs (1 A100 instance)

## 🎯 Expected Response

- **Acknowledgment**: Ticket created within 2-4 hours
- **Initial Review**: Microsoft response within 1-2 business days
- **Possible Follow-up**: May request additional clarification
- **Final Decision**: Typically within 5-10 business days for A100 requests
- **Quota Activation**: Usually immediate after approval

## 📞 Follow-up Actions

1. **Save your ticket number** for reference
2. **Respond promptly** to any Microsoft follow-up questions
3. **Monitor status** in Azure Portal → Help + support → All support requests
4. **Prepare for deployment** - review deployment scripts while waiting

## 🔄 If Request is Denied

Common reasons and solutions:
- **Insufficient justification**: Provide more technical details about LLM training requirements
- **Regional capacity**: Consider West Europe or East US as alternatives
- **Quota too large**: Start with smaller request (12 vCPUs) and expand later
- **Account history**: Ensure subscription has been used responsibly

## Alternative Regions to Consider

If North Europe is not available:
1. **West Europe** (recommended alternative)
2. **East US** (good performance, established capacity)
3. **South Central US** (backup option)

Remember to update your deployment configuration if using an alternative region.

---

**💡 Pro Tip**: Keep this template handy and customize the contact information before submitting. Having detailed technical justification significantly improves approval chances!