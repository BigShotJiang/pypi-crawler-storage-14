# Azure GPU Functions

[![PyPI version](https://badge.fury.io/py/azure-gpu-functions.svg)](https://pypi.org/project/azure-gpu-functions/)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **⚠️ SECURITY NOTICE**: Version 1.0.0 has been yanked from PyPI due to hardcoded Azure credentials. Always use version 1.0.1 or later.

GPU-accelerated machine learning training for Azure Functions with distributed computing, real-time monitoring, and cost optimization.

## 🚀 Features

- **GPU-Accelerated Training**: Leverage Azure GPU instances (A100, T4) for ML training
- **Distributed Computing**: Ray-based distributed training with hyperparameter optimization
- **Real-Time Monitoring**: MCP (Model Context Protocol) server for live training metrics
- **Cost Optimization**: Automatic cost analysis and resource utilization tracking
- **Azure Integration**: Seamless integration with Azure Functions, Blob Storage, and Container Apps
- **Model Caching**: Intelligent model storage and caching system
- **Easy Deployment**: Infrastructure as Code with Bicep templates
- **Security-First**: Environment variable-only configuration, no hardcoded credentials

## 📦 Installation

### Basic Installation
```bash
pip install azure-gpu-functions
```

### Full Installation (with all features)
```bash
pip install azure-gpu-functions[all]
```

### Selective Installation
```bash
# Core functionality only
pip install azure-gpu-functions

# Add Azure integration
pip install azure-gpu-functions[azure]

# Add ML libraries
pip install azure-gpu-functions[ml]

# Add distributed computing
pip install azure-gpu-functions[distributed]

# Add monitoring capabilities
pip install azure-gpu-functions[monitoring]
```

## ✅ Package Status

**✅ READY FOR DISTRIBUTION**

The package has been successfully tested and built:
- ✅ All imports work correctly
- ✅ Optional dependencies handled gracefully
- ✅ CLI interface functional
- ✅ Wheel package built successfully
- ✅ All tests pass
- ✅ Security audit completed (version 1.0.1)

## 🔒 Security

**Important Security Update in v1.0.1**

Version 1.0.1 includes critical security improvements:
- **No hardcoded credentials**: All Azure resource configuration now requires explicit environment variables
- **Environment-only configuration**: Removed all default Azure resource names and sensitive values
- **Secure authentication**: Uses Azure's DefaultAzureCredential for secure, token-based authentication

### Required Environment Variables

Before using the package, set these environment variables:

```bash
# Azure Authentication (required for Azure features)
AZURE_CLIENT_ID=your_client_id
AZURE_CLIENT_SECRET=your_client_secret
AZURE_TENANT_ID=your_tenant_id

# Azure Resources (required for storage and deployment)
AZURE_STORAGE_ACCOUNT=your_storage_account
AZURE_RESOURCE_GROUP=your_resource_group
AZURE_SUBSCRIPTION_ID=your_subscription_id
AZURE_CONTAINER_NAME=your_container_name

# Optional: Model Caching
MODEL_CACHE_DIR=/path/to/cache

# Optional: MCP Server
MCP_HOST=0.0.0.0
MCP_PORT=8765
```

### Migration from v1.0.0 to v1.0.1

If you were using v1.0.0, update to v1.0.1 and ensure all Azure configuration is provided via environment variables. The package will no longer work with hardcoded values.

## 🚀 Publishing to PyPI

### Prerequisites
1. Create a PyPI account at https://pypi.org/
2. Install build and publishing tools:
```bash
pip install build twine
```

### Build and Publish
```bash
# Build the package
python -m build

# Test upload to TestPyPI first
twine upload --repository testpypi dist/*

# Upload to production PyPI
twine upload dist/*
```

### Verify Installation
```bash
# Test installation from TestPyPI
pip install --index-url https://test.pypi.org/simple/ azure-gpu-functions

# Test the package
python -c "import azure_gpu_functions; print('Success!')"

# Check installed version
pip show azure-gpu-functions
```

### Current Versions
- **Latest (Recommended)**: `1.0.1` - Security hardened, environment variable-only configuration
- **Yanked (Deprecated)**: `1.0.0` - **SECURITY RISK** - Contains hardcoded Azure credentials. This version has been yanked from PyPI and should never be used.

## 🔧 Quick Start

### Basic Model Training

```python
import asyncio
from azure_gpu_functions import GPUTrainer

async def main():
    # Initialize trainer
    trainer = GPUTrainer()

    # Prepare training data
    training_data = [
        {"text": "Hello world example"},
        {"text": "Another training sample"},
        # ... more data
    ]

    # Configure training
    config = {
        "num_epochs": 3,
        "batch_size": 8,
        "learning_rate": 5e-5,
        "max_length": 512,
        "use_lora": True
    }

    # Train model
    result = await trainer.train_llm(
        model_name="gpt2",
        training_data=training_data,
        config=config
    )

    print(f"Training completed! Loss: {result['final_loss']}")

asyncio.run(main())
```

### Enhanced Distributed Training

```python
import asyncio
from azure_gpu_functions import EnhancedRayTrainer

async def main():
    trainer = EnhancedRayTrainer()

    config = {
        "model_name": "bert-base-uncased",
        "num_epochs": 5,
        "batch_size": 16,
        "learning_rate": 2e-5,
        "num_samples": 10,  # Hyperparameter optimization trials
        "use_lora": False
    }

    training_data = [
        {"text": "Sample training text"},
        # ... more data
    ]

    result = await trainer.train_with_ray_distributed_enhanced(
        config=config,
        training_data=training_data
    )

    print(f"Best loss: {result['training_stats']['best_loss']}")
    print(f"Total trials: {result['training_stats']['total_trials']}")

asyncio.run(main())
```

### Real-Time Monitoring

```python
import asyncio
from azure_gpu_functions import MCPMonitor

async def main():
    # Connect to MCP server
    monitor = MCPMonitor(host="localhost", port=8765)
    await monitor.connect()

    # Get system metrics
    metrics = await monitor.get_system_metrics()
    print(f"GPU utilization: {metrics['gpu'][0]['load']}%")

    # Start training session
    await monitor.start_training_session("session_123", {
        "model_name": "gpt2",
        "gpu_type": "A100"
    })

asyncio.run(main())
```

### Model Storage

```python
import asyncio
from azure_gpu_functions import ModelStorage

async def main():
    # Initialize storage
    storage = ModelStorage(
        storage_account_name="your_storage_account",
        container_name="models"
    )

    # Upload model
    model_url = await storage.upload_model(
        local_path="/path/to/model",
        model_name="my_fine_tuned_model"
    )

    # Download model
    local_path = await storage.download_model("my_fine_tuned_model")

asyncio.run(main())
```

## 🖥️ Command Line Interface

The package includes a CLI tool for common operations:

```bash
# Train a model
azure-gpu-trainer train --model gpt2 --data training.json --config config.json

# Enhanced distributed training
azure-gpu-trainer train-enhanced --model bert --data data.json --config config.json

# Start monitoring server
azure-gpu-trainer monitor --host 0.0.0.0 --port 8765

# Show system metrics
azure-gpu-trainer metrics

# Show version
azure-gpu-trainer version
```

## 🏗️ Architecture

```
azure_gpu_functions/
├── training.py          # Core training classes (GPUTrainer, EnhancedRayTrainer)
├── mcp_server.py       # MCP monitoring server and client
├── monitoring.py        # System monitoring and cost analysis
├── storage.py           # Model storage and caching
├── utils/               # Utility modules
│   ├── config.py        # Configuration management
│   ├── gpu_utils.py     # GPU utilities
│   └── logging.py       # Logging utilities
├── cli.py               # Command-line interface
└── __init__.py          # Package initialization
```

## 🔧 Configuration

### Environment Variables

```bash
# Azure Storage
AZURE_STORAGE_ACCOUNT=your_storage_account
AZURE_RESOURCE_GROUP=your_resource_group
AZURE_SUBSCRIPTION_ID=your_subscription_id

# Model Caching
MODEL_CACHE_DIR=/path/to/cache

# MCP Server
MCP_HOST=0.0.0.0
MCP_PORT=8765
```

### Azure Setup

1. **GPU Quota**: Ensure you have approved GPU quotas in your Azure subscription
2. **Storage Account**: Create an Azure Storage account for model storage
3. **Container Apps**: Deploy using the provided Bicep templates

## 📊 Monitoring & Cost Analysis

### System Metrics
- CPU/GPU utilization
- Memory usage
- Disk I/O
- Network traffic

### Cost Tracking
- Per-GPU-hour costs
- Training session costs
- Azure resource costs
- Cost optimization recommendations

### Real-Time Monitoring
- WebSocket-based MCP server
- Prometheus metrics export
- Training progress tracking
- Resource utilization alerts

## 🚀 Deployment

### Azure Container Apps

```bash
# Deploy with GPU support
./scripts/deploy_gpu_function.sh

# Deploy CPU version for testing
./scripts/deploy_cpu_test.sh
```

### Local Development

```bash
# Start local Azure Functions
func start --verbose

# Start MCP monitoring server
azure-gpu-trainer monitor

# Run GPU tests
./scripts/run_gpu_tests.sh
```

## 📚 Documentation

- [Framework Guide](FRAMEWORK_GUIDE.md) - Comprehensive educational documentation
- [API Reference](docs/api.md) - Detailed API documentation
- [Deployment Guide](docs/deployment.md) - Step-by-step deployment instructions
- [Examples](examples/) - Code examples and tutorials

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built for the Amadeus GPU Training Team
- Inspired by Azure Functions and Ray distributed computing
- Thanks to the HuggingFace and PyTorch communities

## 📞 Support

- [GitHub Issues](https://github.com/pxcallen_amadeus/azureGPUtrainingappfunc/issues)
- [Documentation](https://github.com/pxcallen_amadeus/azureGPUtrainingappfunc/blob/main/FRAMEWORK_GUIDE.md)
- Email: gpu-training@amadeus.com