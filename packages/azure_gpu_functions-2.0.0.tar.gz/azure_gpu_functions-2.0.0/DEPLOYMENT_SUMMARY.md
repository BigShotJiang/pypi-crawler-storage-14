# Azure Function GPU Deployment Summary

## Overview
Simple Azure Function deployment to test A100 GPU availability on Azure Container Apps using Consumption GPU workload profiles.

## Configuration
- **Subscription**: 283fe8b3-dfc1-4c4e-9cd4-c8b78b5ddcba
- **Region**: North Europe
- **Resource Group**: rg-llm-gpu-function-test
- **Container Registry**: acrgpufunctest.azurecr.io
- **Function App**: func-gpu-test
- **Environment**: gpu-func-env

## GPU Configuration
- **Workload Profile Type**: Consumption-GPU-NC24-A100
- **Workload Profile Name**: gpua100 (friendly name)
- **vCPU**: 24 (using 8.0 for container app)
- **Memory**: 220GB (using 56Gi for container app)
- **GPU**: 1x NVIDIA A100 (80GB)
- **Scaling**: 0 to 1 replicas (scale-to-zero enabled)

## Function Endpoints
Once deployed, the function will have 3 HTTP endpoints:

1. **Health Check**: `/api/health`
   - Returns basic function status
   - No GPU initialization required

2. **GPU Status**: `/api/gpu-status`
   - Returns detailed GPU information
   - Shows A100 GPU details and availability
   - Includes CUDA version, device name, memory stats

3. **GPU Test**: `/api/gpu-test`
   - Performs actual GPU computation (matrix multiplication)
   - Demonstrates GPU is working correctly
   - Measures computation time

## Container Image
- **Base Image**: nvidia/cuda:12.1.0-runtime-ubuntu22.04
- **Python**: 3.11
- **PyTorch**: 2.9.1 with CUDA 12.1 support
- **Azure Functions Core Tools**: 4.4.1
- **Image Size**: ~4GB (includes all CUDA libraries)

## Deployment Process
1. Build container image with CUDA runtime and PyTorch
2. Push image to Azure Container Registry
3. Create Container Apps environment with Consumption workload profile enabled
4. Add Consumption-GPU-NC24-A100 workload profile
5. Deploy container app with GPU configuration

## Key Learnings
1. **Consumption GPU profiles** don't support min/max node configuration (they auto-scale)
2. **Workload profile must be added** before deploying the container app
3. **Friendly names** can be used for workload profiles (e.g., "gpua100" instead of full type name)
4. **CPU/memory limits** should match or be less than the workload profile capacity
5. **Consumption GPU** is perfect for scale-to-zero AI workloads

## Testing Commands
After deployment, test using:

```bash
# Get the function URL from deployment output
FUNCTION_URL="<your-function-url>"

# Test health endpoint
curl https://$FUNCTION_URL/api/health

# Check GPU status
curl https://$FUNCTION_URL/api/gpu-status

# Run GPU computation test
curl https://$FUNCTION_URL/api/gpu-test
```

## Expected Results
- **First request**: May take 30-60 seconds (cold start + GPU initialization)
- **Subsequent requests**: Much faster (~1-3 seconds)
- **GPU Detection**: Should show NVIDIA A100 with ~80GB memory
- **CUDA Version**: 12.1

## Cost Optimization
- **Scale to Zero**: Function scales to 0 replicas when idle (no GPU cost)
- **Per-Second Billing**: Only pay for GPU when processing requests
- **Auto-Scaling**: Automatically scales up when requests arrive

## Troubleshooting
1. **Cold Start**: First request is slow - this is expected for GPU initialization
2. **GPU Not Detected**: Check container logs for CUDA errors
3. **Memory Issues**: A100 has 80GB VRAM - plenty for testing
4. **Timeout**: Increase function timeout if needed for longer workloads

## Next Steps
Once this simple GPU test is working:
1. Deploy full LLM training workload
2. Test with actual model inference
3. Monitor GPU utilization and costs
4. Optimize cold start with artifact streaming
