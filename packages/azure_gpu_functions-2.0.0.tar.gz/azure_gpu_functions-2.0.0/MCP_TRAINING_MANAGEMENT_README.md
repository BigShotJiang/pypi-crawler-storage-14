# MCP Server Training Management Capabilities

This document describes the enhanced MCP (Model Context Protocol) server capabilities for managing large-scale GPU training jobs on Azure Functions.

## Overview

The MCP server now provides comprehensive training management features including launch, pause, resume, snapshot, cost estimation, and real-time monitoring for large training jobs on GPU infrastructure.

## New Capabilities

### 1. Training Launch (`launch_training`)
Launch a new training job with full management support.

**HTTP Endpoint:** `POST /api/training?action=launch`

**MCP Message Type:** `launch_training`

**Parameters:**
- `config_name`: Training configuration ("small", "medium", "large", "xl")
- `training_data`: Array of training text samples
- `custom_config`: Optional custom training parameters
- `session_id`: Optional custom session ID

**Response:**
```json
{
  "type": "training_launched",
  "session_id": "training_1234567890.123",
  "config": {...},
  "status": "running",
  "timestamp": "2025-11-23T..."
}
```

### 2. Training Pause (`pause_training`)
Pause a running training job and save current state.

**HTTP Endpoint:** `POST /api/training?action=pause`

**MCP Message Type:** `pause_training`

**Parameters:**
- `session_id`: Training session ID
- `reason`: Optional pause reason

### 3. Training Resume (`resume_training`)
Resume a paused training job from checkpoint.

**HTTP Endpoint:** `POST /api/training?action=resume`

**MCP Message Type:** `resume_training`

**Parameters:**
- `session_id`: Training session ID
- `checkpoint_path`: Optional checkpoint path

### 4. Training Snapshot (`snapshot_training`)
Create a manual snapshot of current training state.

**HTTP Endpoint:** `POST /api/training?action=snapshot`

**MCP Message Type:** `snapshot_training`

**Parameters:**
- `session_id`: Training session ID
- `snapshot_name`: Optional snapshot name

### 5. Completion Time Estimation (`estimate_completion_time`)
Estimate remaining time to complete training.

**HTTP Endpoint:** `GET /api/training?action=estimate-completion&session_id=...`

**MCP Message Type:** `estimate_completion_time`

**Response:**
```json
{
  "type": "completion_time_estimate",
  "estimate_data": {
    "progress_percent": 45.2,
    "elapsed_seconds": 1800,
    "estimated_remaining_seconds": 2200,
    "estimated_completion_time": "2025-11-23T15:30:00"
  }
}
```

### 6. Cost Estimation (`get_cost_estimate`)
Get cost estimate for a training configuration before launching.

**HTTP Endpoint:** `POST /api/training?action=cost-estimate`

**MCP Message Type:** `get_cost_estimate`

**Parameters:**
- `config_name`: Training configuration
- `custom_config`: Optional custom parameters
- `gpu_type`: GPU type ("T4", "A100", etc.)

**Response:**
```json
{
  "type": "cost_estimate",
  "cost_estimate": {
    "total_cost_usd": 2.40,
    "hourly_rate": 1.60,
    "estimated_duration_hours": 1.5,
    "gpu_type": "T4"
  }
}
```

### 7. Cost Monitoring (`monitor_cost`)
Monitor real-time costs for running training jobs.

**HTTP Endpoint:** `GET /api/training?action=cost-monitor&session_id=...`

**MCP Message Type:** `monitor_cost`

**Response:**
```json
{
  "type": "cost_monitoring",
  "cost_data": {
    "session_id": "training_123",
    "elapsed_seconds": 3600,
    "current_cost": 1.60,
    "gpu_type": "T4"
  }
}
```

### 8. Training Status (`get_training_status`)
Get detailed status of a training job including real-time metrics.

**HTTP Endpoint:** `GET /api/training?action=status&session_id=...`

**MCP Message Type:** `get_training_status`

## Training Configurations

### Small
- Model: DialoGPT-small
- Batch Size: 2
- Epochs: 1
- Estimated Duration: 5 minutes

### Medium
- Model: DialoGPT-small
- Batch Size: 1
- Epochs: 2
- Estimated Duration: 15 minutes

### Large
- Model: DialoGPT-medium
- Batch Size: 1
- Epochs: 3
- Estimated Duration: 45 minutes

### XL
- Model: DialoGPT-medium
- Batch Size: 1
- Epochs: 5
- Estimated Duration: 120 minutes

## Cost Structure

### GPU Pricing (per hour)
- T4: $1.60
- A100: $4.80
- CPU: $0.02

### Cost Optimization Features
- Automatic cost tracking per session
- Real-time cost monitoring
- Cost estimation before launch
- Cost alerts and thresholds

## Usage Examples

### Launch Training via HTTP
```bash
curl -X POST "https://your-function.azurewebsites.net/api/training?action=launch" \
  -H "Content-Type: application/json" \
  -d '{
    "config_name": "medium",
    "training_data": ["Sample text 1", "Sample text 2"],
    "session_id": "my_training_session"
  }'
```

### Get Cost Estimate
```bash
curl -X POST "https://your-function.azurewebsites.net/api/training?action=cost-estimate" \
  -H "Content-Type: application/json" \
  -d '{
    "config_name": "large",
    "gpu_type": "A100"
  }'
```

### Monitor Training Status
```bash
curl "https://your-function.azurewebsites.net/api/training?action=status&session_id=my_training_session"
```

## MCP WebSocket API

Connect to the MCP server via WebSocket for real-time updates:

```javascript
const ws = new WebSocket('ws://localhost:8765');

ws.onmessage = (event) => {
  const data = JSON.parse(event.data);
  console.log('MCP Update:', data);
};

// Launch training
ws.send(JSON.stringify({
  type: 'launch_training',
  id: 'request_1',
  config_name: 'medium',
  training_data: ['text1', 'text2']
}));
```

## Integration with Ray Cluster

The MCP server integrates with Ray for distributed training and cluster management:

- Automatic scaling based on training requirements
- Resource optimization across nodes
- Fault tolerance and recovery
- Real-time cluster monitoring

## Monitoring and Alerts

- Real-time training progress updates
- Cost threshold alerts
- GPU utilization monitoring
- Automatic failure detection and recovery
- Training completion notifications

## Security

All endpoints require Azure Function authentication keys. MCP WebSocket connections include session-based authentication.

## Error Handling

The system provides comprehensive error handling with detailed error messages and automatic retry mechanisms for transient failures.