# T4 GPU Training Test Setup

## Overview
This setup provides GPU training validation on Azure Container Apps using NVIDIA T4 Consumption GPUs (16GB VRAM, ~65 TFLOPs). The T4 serves as development/testing hardware while waiting for A100 quota approval.

## Components

### 1. Azure Function (`function_app_simple.py`)
- **Endpoint**: `/api/gpu-training`
- **Model**: SimpleNet (784→128→64→10) neural network
- **Dataset**: Synthetic MNIST-like data (60k samples)
- **Training**: Configurable epochs, batch size, learning rate
- **Monitoring**: GPU memory usage, training metrics, accuracy

### 2. Deployment Script (`deploy_t4_training.sh`)
- **Profile**: Consumption-GPU-NC16-T4 (16 vCPU, 32GB RAM, 1x T4 GPU)
- **Resources**: Container Apps environment, function app, storage
- **Workflow**: Automated deployment with GPU workload assignment

### 3. Testing Script (`test_t4_training.sh`)
- **Validation**: GPU detection, CUDA availability, training performance
- **Scenarios**: Default (10 epochs), Extended (50 epochs), Large batch (100)
- **Metrics**: Training time, memory usage, final accuracy, GPU utilization

## Usage

### Prerequisites
- Azure CLI installed and authenticated
- T4 Consumption GPU quota approved (16 vCPU)
- Subscription with Container Apps access

### Deployment
```bash
./deploy_t4_training.sh
```

### Testing
```bash
./test_t4_training.sh
```

## Expected Results

### GPU Detection
- CUDA available: True
- GPU count: 1
- GPU name: Tesla T4
- Memory: ~16GB

### Training Performance (Estimated)
- Default (10 epochs): ~2-3 minutes, 85-90% accuracy
- Extended (50 epochs): ~10-15 minutes, 90-95% accuracy
- Large batch (100): ~5-8 minutes, 80-85% accuracy

### Memory Usage
- Model: ~50MB
- Dataset: ~200MB
- Peak training: ~2-3GB (well within 16GB limit)

## Next Steps

1. **Wait for T4 Quota**: Monitor support ticket for approval
2. **Deploy & Test**: Run scripts to validate T4 training
3. **A100 Migration**: Once approved, update scripts for A100 profile
4. **Performance Comparison**: Compare T4 vs A100 training metrics

## Architecture Notes

- **Consumption GPUs**: Same hardware as dedicated, serverless scaling
- **Memory Efficient**: Model designed for T4's 16GB constraint
- **Scalable**: Easy migration to A100 (80GB) for larger models
- **Cost Effective**: Pay-per-use GPU compute for development

## Troubleshooting

- **Quota Issues**: Check Azure portal → Subscriptions → Usage + quotas
- **Deployment Failures**: Verify resource group and subscription permissions
- **GPU Detection**: Ensure CUDA runtime in container image
- **Memory Errors**: Reduce batch size or model complexity

## Files Modified/Created
- `function_app_simple.py`: Added `/api/gpu-training` endpoint
- `deploy_t4_training.sh`: T4 deployment automation
- `test_t4_training.sh`: Comprehensive training validation
- `infrastructure/main.parameters.t4.json`: T4-specific parameters