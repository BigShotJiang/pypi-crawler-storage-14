# Enhanced Azure GPU Functions - Cost Management, Model Registry & Batch Processing

This project now includes comprehensive cost estimation, budget management, model registry, and batch processing capabilities for Azure GPU Functions training.

## 🆕 New Features

### 1. 💰 Cost Estimation & Budget Management

**Estimate training costs based on epochs, time forecasting, and maintain cost history with global budget management.**

#### Key Components

- **CostEstimator**: Estimates costs based on model parameters, epochs, and GPU types
- **BudgetManager**: Manages team budgets with alerts and forecasting
- **Cost History**: Tracks actual vs estimated costs for continuous improvement

#### Usage

```python
from azure_gpu_functions.cost_management import CostEstimator, BudgetManager

# Estimate training cost
estimator = CostEstimator()
estimate = estimator.estimate_cost(
    model_name="bert-base",
    epochs=10,
    batch_size=16,
    gpu_type="V100"
)
print(f"Estimated cost: ${estimate.estimated_cost:.2f}")

# Create and manage budget
manager = BudgetManager()
budget = manager.create_budget("team_alpha", "Team Alpha Budget", 5000.0)

# Check budget status
status, ratio, alerts = manager.check_budget_status("team_alpha")
if alerts:
    print(f"Budget alert: {alerts['message']}")
```

#### Cost Estimation Parameters

- **Model Name**: Used for historical data lookup and baseline calculations
- **Epochs**: Number of training epochs
- **Batch Size**: Training batch size (affects GPU utilization)
- **Model Size**: Size in GB (affects storage costs)
- **GPU Type**: V100, A100, T4, etc. (affects compute costs)

#### Budget Management

- **Team-based budgets** with configurable periods
- **Automatic alerts** at warning (80%) and critical (95%) thresholds
- **Cost forecasting** for planned training jobs
- **Historical tracking** of actual spending

### 2. 📦 Model Registry & Management

**Manage pretrained and custom models in a common repository with versioning and metadata tracking.**

#### Key Components

- **ModelRegistry**: Central registry for all models
- **Version Control**: Track model versions with changes and performance deltas
- **Metadata Management**: Store performance metrics, training config, dependencies
- **Download Tracking**: Monitor model usage and access patterns

#### Usage

```python
from azure_gpu_functions.model_registry import ModelRegistry, ModelType

registry = ModelRegistry()

# Register a new model
metadata = registry.register_model(
    name="bert-finetuned-sst2",
    model_type=ModelType.FINE_TUNED,
    framework="pytorch",
    architecture="bert",
    model_path="/path/to/model.pkl",
    created_by="data_science_team",
    performance_metrics={"accuracy": 0.92, "f1_score": 0.91}
)

# List models with filtering
models = registry.list_models(
    model_type=ModelType.FINE_TUNED,
    framework="pytorch",
    tags=["sentiment-analysis"]
)

# Download a model
download_path = registry.download_model(metadata.model_id, version="1.0.0")
```

#### Model Types

- **PRETRAINED**: Base pretrained models (BERT, GPT, ResNet, etc.)
- **CUSTOM**: Models trained from scratch
- **FINE_TUNED**: Models fine-tuned on specific datasets

#### Model Metadata

- **Performance metrics**: Accuracy, F1-score, loss, etc.
- **Training configuration**: Hyperparameters, dataset info
- **Dependencies**: Required libraries and versions
- **Tags**: For categorization and search
- **Version history**: Changes and performance improvements

### 3. 🔄 Batch Processing System

**Avoid blocking VS Code agent with efficient batch operations instead of individual curl commands.**

#### Key Components

- **BatchProcessor**: Multi-threaded operation processing
- **BatchMonitor**: Real-time status tracking
- **Priority Queue**: Handle operations by priority
- **Status Aggregation**: Get status for multiple batches efficiently

#### Usage

```python
from azure_gpu_functions.batch_processor import submit_batch_operations, get_batch_operations_status

# Submit multiple operations as a batch
operations = [
    {
        "type": "cost_estimation",
        "parameters": {"model_name": "bert", "epochs": 10}
    },
    {
        "type": "system_metrics",
        "parameters": {}
    },
    {
        "type": "budget_check",
        "parameters": {"team_id": "team_alpha"}
    }
]

batch_id = submit_batch_operations(operations)

# Check status of multiple batches
statuses = get_batch_operations_status([batch_id, "other_batch_id"])
for status in statuses["statuses"]:
    print(f"Batch {status['batch_id']}: {status['status']}")
```

#### Supported Batch Operations

- **cost_estimation**: Estimate training costs
- **model_registration**: Register new models
- **training_status_check**: Check training job status
- **budget_check**: Verify budget compliance
- **model_download**: Download models from registry
- **system_metrics**: Get system performance metrics

## 🚀 MCP Server Integration

The MCP server now supports batch operations and new message types:

### New Message Types

#### Batch Operations
```json
{
  "type": "submit_batch_operations",
  "id": "batch_123",
  "operations": [
    {
      "type": "cost_estimation",
      "parameters": {"model_name": "bert", "epochs": 10}
    }
  ]
}
```

#### Cost Management
```json
{
  "type": "estimate_cost",
  "id": "cost_123",
  "model_name": "bert-base",
  "epochs": 10,
  "gpu_type": "V100"
}
```

#### Model Registry
```json
{
  "type": "register_model",
  "id": "model_123",
  "name": "bert-finetuned",
  "model_type": "fine_tuned",
  "framework": "pytorch",
  "architecture": "bert",
  "model_path": "/path/to/model.pkl"
}
```

## 📊 Dashboard Integration

The enhanced dashboard now includes:

- **Cost Analytics**: Budget usage, cost trends, forecasting
- **Model Inventory**: Registry statistics, popular models
- **Batch Operations**: Monitor batch processing status
- **Team Budgets**: Budget alerts and compliance tracking

## 🛠️ Installation & Setup

### Prerequisites

```bash
pip install dataclasses-json sqlite3  # Usually included in Python 3.7+
```

### Database Setup

The system uses SQLite databases that are created automatically:
- `cost_data.db`: Cost history and budget data
- `model_registry.db`: Model metadata and versions

### Starting the System

```python
# Start batch processor
from azure_gpu_functions.batch_processor import start_batch_processor
start_batch_processor()

# Start MCP server
from azure_gpu_functions.mcp_server import RayMCPServer
server = RayMCPServer()
await server.start_server()
```

## 🧪 Testing

Run comprehensive tests:

```bash
# Test all components
python test_comprehensive_system.py

# Test individual components
python test_enhanced_features.py
```

## 📈 Cost Estimation Algorithm

### Time Estimation

1. **Historical Data**: Uses actual training times for similar models
2. **Baseline Calculation**: Falls back to model-type specific baselines
3. **Parameter Adjustment**: Adjusts for batch size, model size, and GPU type

### Cost Calculation

- **GPU Costs**: Based on hourly rates for different GPU types
- **Storage Costs**: Calculated based on model size and retention period
- **Network Costs**: Estimated data transfer costs
- **Overhead**: 5% additional overhead for management and monitoring

### Confidence Scoring

- **High Confidence**: >90% (extensive historical data)
- **Medium Confidence**: 50-90% (some historical data)
- **Low Confidence**: <50% (new model types or limited data)

## 💼 Budget Management

### Alert System

- **Warning**: 80% budget utilization
- **Critical**: 95% budget utilization
- **Exceeded**: 100%+ budget utilization

### Forecasting

- **Planned Jobs**: Estimate costs for upcoming training jobs
- **Trend Analysis**: Predict future spending based on historical patterns
- **Recommendations**: Suggest cost optimization strategies

## 🔍 Model Registry Features

### Search & Discovery

- **Text Search**: Search by name, description, or tags
- **Filter Options**: Filter by type, framework, status, tags
- **Performance Filtering**: Find models by performance metrics

### Version Management

- **Semantic Versioning**: Major.Minor.Patch versioning
- **Change Tracking**: Document what changed in each version
- **Performance Delta**: Track performance improvements/regressions

### Access Control

- **Download Tracking**: Monitor who downloads models and when
- **Usage Analytics**: Understand model popularity and usage patterns
- **Audit Trail**: Complete history of model lifecycle events

## ⚡ Batch Processing Benefits

### Performance

- **Parallel Processing**: Multiple operations processed simultaneously
- **Priority Queue**: High-priority operations processed first
- **Resource Pooling**: Efficient use of system resources

### Reliability

- **Non-blocking**: Operations don't block the VS Code agent
- **Error Isolation**: Failures in one operation don't affect others
- **Status Tracking**: Real-time progress monitoring

### Scalability

- **Horizontal Scaling**: Add more worker threads as needed
- **Queue Management**: Handle operation bursts gracefully
- **Resource Limits**: Configurable limits prevent resource exhaustion

## 🔧 Configuration

### Cost Estimation

```python
# GPU hourly rates (customize for your region/pricing)
gpu_rates = {
    "V100": 2.50,
    "A100": 3.20,
    "T4": 0.35,
}
```

### Batch Processing

```python
# Configure batch processor
batch_processor = BatchProcessor(
    max_workers=8,      # Number of worker threads
    queue_size=1000     # Maximum queued operations
)
```

### Model Registry

```python
# Configure storage paths
registry = ModelRegistry(
    storage_path="custom/model/storage",
    db_path="custom/registry.db"
)
```

## 📋 API Reference

### Cost Management

- `estimate_cost(model_name, epochs, batch_size, model_size_gb, gpu_type)` → CostEstimate
- `record_actual_cost(job_id, team_id, model_name, actual_cost, actual_time, actual_epochs, cost_breakdown, status)`
- `create_budget(team_id, name, total_budget, period_days)` → Budget
- `check_budget_status(team_id)` → (BudgetStatus, usage_ratio, alerts)

### Model Registry

- `register_model(name, model_type, framework, architecture, model_path, created_by, ...)` → ModelMetadata
- `list_models(model_type, framework, tags, status)` → List[ModelMetadata]
- `download_model(model_id, version, download_path, downloaded_by, purpose)` → str
- `get_model_metadata(model_id)` → ModelMetadata

### Batch Processing

- `submit_batch_operations(operations, callback)` → batch_id
- `get_batch_operations_status(batch_ids)` → Dict[str, List[Dict]]
- `start_batch_processor()` / `stop_batch_processor()`

## 🚨 Best Practices

### Cost Management

1. **Regular Monitoring**: Check budget status weekly
2. **Accurate Estimation**: Use historical data for better forecasts
3. **Cost Optimization**: Consider spot instances and model quantization
4. **Budget Alerts**: Set up notifications for budget thresholds

### Model Registry

1. **Version Control**: Always create new versions for changes
2. **Metadata**: Include comprehensive performance metrics and training details
3. **Tagging**: Use consistent tags for easy discovery
4. **Cleanup**: Archive or delete unused models regularly

### Batch Processing

1. **Batch Size**: Group related operations together
2. **Priority**: Use priority for time-sensitive operations
3. **Monitoring**: Track batch completion and handle failures
4. **Resource Limits**: Set appropriate worker limits for your system

## 🔮 Future Enhancements

- **Cloud Integration**: Direct integration with Azure Cost Management
- **Advanced Analytics**: ML-based cost prediction models
- **Model Serving**: Built-in model deployment and serving
- **Collaborative Features**: Team sharing and collaboration tools
- **Automated Optimization**: AI-driven cost and performance optimization

## 📞 Support

For issues or questions:
1. Check the comprehensive test suite: `python test_comprehensive_system.py`
2. Review the API documentation above
3. Check logs for detailed error information
4. Ensure all optional dependencies are properly handled

---

**🎯 This enhanced system provides production-ready cost management, model registry, and batch processing capabilities that scale with your Azure GPU Functions deployment while avoiding VS Code agent blocking through efficient batch operations.**