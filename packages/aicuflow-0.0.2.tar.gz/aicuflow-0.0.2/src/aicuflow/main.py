import webbrowser

def main():
    """
    called by our cli script aicuflow
    """
    webbrowser.open("https://aicuflow.com")
