def test_a():
    pass

def test_b():
    pass