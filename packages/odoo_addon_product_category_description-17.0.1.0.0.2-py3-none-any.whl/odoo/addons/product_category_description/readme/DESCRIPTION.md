This module adds a field 'description' on product category level.
