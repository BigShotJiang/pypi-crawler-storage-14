#!/usr/bin/env sh

version=${1:-0.0.0}

sed -i "s/^version = .*$/version = \"${version}\"/g" pyproject.toml
