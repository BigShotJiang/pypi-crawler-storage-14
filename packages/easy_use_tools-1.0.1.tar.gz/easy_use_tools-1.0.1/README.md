# 通用工具集
这是一个通用工具集, 适用于>=Python3.8

## 1. 准备
### 1.1 安装依赖
```
pip3 install --upgrade packaging setuptools wheel twine
```

## 2. 命令说明
### 2.1 本地安装使用
```
python setup.py install
```
### 2.2 打包
```
python setup.py sdist bdist_wheel
```
在当前dist目录下的两个文件是要上传到 PyPi 网站上供别人下载安装的（*.tar.gz、*.whl）

### 2.3 配置文件检查
```
python3 setup.py check
```

### 2.4 上传前检查
```
twine check dist/*
```
### 2.4 执行上传
```
twine upload dist/*
```
### 2.5 清理
```
rm -rf build/ dist/ *.egg-info/
```