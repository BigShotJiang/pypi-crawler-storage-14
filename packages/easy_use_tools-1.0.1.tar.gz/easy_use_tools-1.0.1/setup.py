# coding=utf-8
import setuptools  # 导入setuptools打包工具
from pathlib import Path

def parse_requirements(filename):
    """使用 packaging 包安全地解析 requirements.txt"""
    try:
        from packaging.requirements import Requirement
    except ImportError:
        # 回退方案：如果packaging不可用，尝试简单处理
        return simple_parse_requirements(filename)

    requirements = []
    file_path = Path(filename)

    if not file_path.exists():
        return requirements

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            # 跳过空行和注释
            if not line or line.startswith('#'):
                continue
            try:
                # 使用packaging验证并规范化需求字符串
                req = Requirement(line)
                requirements.append(str(req))
            except Exception:
                # 如果解析失败，回退到原始行
                requirements.append(line)

    return requirements


def simple_parse_requirements(filename):
    """简化的解析器，作为回退方案"""
    file_path = Path(filename)
    if not file_path.exists():
        return []

    with open(file_path, 'r', encoding='utf-8') as f:
        return [
            line.strip() for line in f
            if line.strip() and not line.startswith('#')
        ]


with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="easy_use_tools",  # 用自己的名替换其中的YOUR_USERNAME_
    version="1.0.1",  # 包版本号，便于维护版本,保证每次发布都是版本都是唯一的
    author="yuanyang.li",  # 作者，可以写自己的姓名
    author_email="yuanyang.edison.li@gmail.com",  # 作者联系方式，可写自己的邮箱地址
    description="An easy use tools package",  # 包的简述
    long_description=long_description,  # 包的详细介绍，一般在README.md文件内
    long_description_content_type="text/markdown",
    url="https://github.com/XXX",  # 自己项目地址，比如github的项目地址
    license_files=['LICENSE'],
    packages=setuptools.find_packages(),
    # 依赖管理
    install_requires=parse_requirements('requirements'),
    # install_requires=[  # 项目运行所依赖的第三方包列表
    #     "requests >= 2.25.1",  # 可以指定版本
    #     "shortuuid",  # 也可以不指定版本，但建议指定
    #     "PyYAML >= 5.4.1",
    #     # 注意：通常不推荐使用"pandas"这样宽泛的声明，最好指明最低版本
    # ],
    entry_points={
        "console_scripts" : ['show_info = easy_use_tools.manage:run']
    }, #安装成功后，在命令行输入show_infot easy_use_tools.manage.py中的run了, 格式：'命令名=包.模块:函数'
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',  # 对python的最低版本要求
)