# coding=utf-8
def run():
    print("This is manage run entry")