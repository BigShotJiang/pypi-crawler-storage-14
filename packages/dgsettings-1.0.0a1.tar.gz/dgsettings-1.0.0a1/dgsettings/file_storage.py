import os
import yaml
import json
from .storage import ConfigStorageBase


class FileConfigStorage(ConfigStorageBase):
    def __init__(self, filename: str, use_yaml: bool = True, encoding: str = 'utf-8', auto_reload: bool = True):
        super().__init__(auto_reload=auto_reload)
        self.filename = filename
        self.use_yaml = use_yaml
        self.encoding = encoding
        self.last_mtime = None

    def load(self) -> dict:
        with open(self.filename, encoding=self.encoding) as f:
            data = yaml.safe_load(f) if self.use_yaml else json.load(f)
        self.last_mtime = os.path.getmtime(self.filename)
        return data

    def save(self, data: dict):
        with open(self.filename, 'w', encoding=self.encoding) as f:
            if self.use_yaml:
                yaml.dump(data, f, allow_unicode=True, sort_keys=False)
            else:
                json.dump(data, f, indent=2, ensure_ascii=False)
        self.last_mtime = os.path.getmtime(self.filename)

    def has_changed(self) -> bool:
        if not self.auto_reload:
            return False
        try:
            mtime = os.path.getmtime(self.filename)
            if self.last_mtime is None:
                self.last_mtime = mtime
                return False
            changed = mtime != self.last_mtime
            if changed:
                self.last_mtime = mtime
            return changed
        except Exception:
            return False
