"""Basic tests for f1gp package"""

import f1gp


def test_version():
    """Test that version is defined"""
    assert hasattr(f1gp, "__version__")
    assert isinstance(f1gp.__version__, str)


def test_import():
    """Test that the package can be imported"""
    assert f1gp is not None
