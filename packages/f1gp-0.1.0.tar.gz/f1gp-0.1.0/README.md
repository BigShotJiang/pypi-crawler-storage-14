# F1gp

## Installation

You can install f1gp using pip:

```bash
pip install f1gp
```

For development installation:

```bash
pip install -e ".[dev]"
```

## Usage

```python
import f1gp

# Your code here
```

## Features

- Feature 1
- Feature 2
- Feature 3

## Development

### Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/f1gp.git
cd f1gp
```

2. Install development dependencies:
```bash
pip install -e ".[dev]"
```

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black f1gp tests
```

### Type Checking

```bash
mypy f1gp
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Publishing to PyPI

To publish this package to PyPI:

1. Install build tools:
```bash
pip install build twine
```

2. Build the package:
```bash
python -m build
```

3. Upload to TestPyPI (optional, for testing):
```bash
python -m twine upload --repository testpypi dist/*
```

4. Upload to PyPI:
```bash
python -m twine upload dist/*
```

Make sure you have a PyPI account and have configured your credentials before publishing.
