"""
f1gp - A Python package for scientific exploration
"""

__version__ = "0.1.0"
__author__ = "Andy Casey"
__email__ = "acasey@flatironinstitute.org"

# Add your package exports here
__all__ = []
