import asyncio
from functools import wraps
import logging
import random
from patchright.async_api import Page
from phantomwright._impl._user_sim._mouse_move_sim import async_mouse_move
from phantomwright._impl._user_sim._mouse_wheel_sim import async_mouse_wheel

logger = logging.getLogger(__name__)


async def _user_sim_hook(self, *args, **kwargs):
    url = kwargs.get("url")
    if url is None and args:
        url = args[0]
    logger.info(f"Navigating to {url} (async)")
    await async_mouse_move(self)
    await asyncio.sleep(random.uniform(0.1, 0.3))
    await async_mouse_wheel(self)


if not hasattr(Page.goto, "_pre_hooks"):
    _original_goto = Page.goto

    @wraps(_original_goto)
    async def _hooked_goto(self, *args, **kwargs):
        for hook in _hooked_goto._pre_hooks:
            await hook(self, *args, **kwargs)
        return await _original_goto(self, *args, **kwargs)

    _hooked_goto._pre_hooks = []
    Page.goto = _hooked_goto

if _user_sim_hook not in Page.goto._pre_hooks:
    Page.goto._pre_hooks.append(_user_sim_hook)
