# Copyright 2025 BBDevs
# Licensed under the Apache License, Version 2.0

"""System command module.

Author: A M (am@bbdevs.com)

Created At: 21 Nov 2025
"""

__all__ = []
