# BotServer v2 - Multi-Bot Trading Platform

Stateless trading bot client that connects to Django gRPC server. Supports running multiple bots in parallel from YAML configuration.

**🆕 NEW:** Multi-bot mode with Pydantic v2 configuration!

## 🚀 Quick Start

### 1. Create Configuration

```bash
# Copy example configuration
cp bots.yaml.example bots.yaml

# Edit bots.yaml with your bot UUIDs
# Each bot needs unique UUID matching Django Bot.id
```

### 2. List Available Bots

```bash
ENV=dev ./run_bot.py --list
```

### 3. Run Bots

```bash
# Run all enabled bots
ENV=dev ./run_bot.py

# Run specific bot
ENV=dev ./run_bot.py --bot scalper-01

# Run multiple bots
ENV=dev ./run_bot.py --bot scalper-01 --bot hedge-bot-main
```

## 📋 Features

✅ **Multi-Bot Mode** - Run multiple bots from `bots.yaml`
✅ **Pydantic v2 Config** - Type-safe configuration with validation
✅ **Stateless Design** - No database, all data via gRPC
✅ **Bidirectional gRPC** - Real-time communication with Django
✅ **Auto-Reconnect** - Exponential backoff on connection loss
✅ **Hot Config Reload** - Update config without restart
✅ **Parallel Execution** - All bots run concurrently

## 📝 Configuration

### bots.yaml (Multi-Bot Mode - Recommended)

```yaml
version: 2.1.0
django_grpc_host: localhost:50051
use_tls: false

bots:
  - name: scalper-01
    bot_id: 76d75095-b7b0-496c-b70f-310e3907f2b6
    enabled: true
    exchange: binance
    strategy: listing_scalper
    heartbeat_interval: 30
    custom_settings:
      max_position_usdt: 1000
      leverage: 3

  - name: hedge-bot-main
    bot_id: abdc2387-3bd7-400e-aa77-cf33da65f44c
    enabled: true
    exchange: bybit
    strategy: hedge_arbitrage
```

### .env.dev / .env.prod (Connection Only)

```bash
# Django gRPC Server
DJANGO_GRPC_HOST=localhost:50051
USE_TLS=false

# Authentication
DJANGO_SECRET_KEY=your-secret-key

# Logging
LOG_LEVEL=INFO
```

**⚠️ IMPORTANT:** `BOT_ID` was removed from `.env` files! All bot UUIDs are now managed in `bots.yaml`.

## 🎮 Usage

### Multi-Bot Mode (Default)

```bash
# List available bots
./run_bot.py --list

# Run all enabled bots
ENV=dev ./run_bot.py

# Run specific bot
ENV=dev ./run_bot.py --bot scalper-01

# Run multiple bots
ENV=dev ./run_bot.py --bot scalper-01 --bot hedge-bot-main
```

### Single-Bot Mode (Legacy)

```bash
# For backward compatibility
BOT_ID=<uuid> ENV=dev ./run_bot.py --single
```

**Direct execution**:
```bash
python -m botserver.main --bot-id <uuid>
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DJANGO_GRPC_HOST` | `localhost:50051` | gRPC server address |
| `BOT_ID` | (required) | Bot UUID from Django |
| `DJANGO_SECRET_KEY` | (required) | API key for authentication |
| `USE_TLS` | `false` | Enable TLS for gRPC |
| `LOG_LEVEL` | `INFO` | Logging level (DEBUG/INFO/WARNING/ERROR) |

## Project Structure

```
botserver/
├── src/botserver/
│   ├── main.py              # Entry point
│   ├── core/                # Bot core logic
│   ├── grpc_client/      # gRPC client
│   ├── services/            # Trading services
│   ├── supervisor/          # Bot lifecycle management
│   └── config/              # Configuration
├── run_bot.py               # Launcher script
├── requirements.txt         # Dependencies
└── .env.dev                 # Environment config
```

## Features

- **Stateless architecture** - All configuration from Django
- **Bidirectional gRPC streaming** - Real-time commands & metrics
- **Auto-reconnection** - Handles network failures
- **Heartbeat monitoring** - 30s keepalive to Django
- **Interactive CLI** - Environment selection
- **Logging** - Structured logging with levels

## Development

```bash
# Run tests
pytest tests/

# Check code
python -m botserver.main --help
```

## Troubleshooting

**Connection refused:**
```bash
# Check Django gRPC server is running
curl localhost:50051
# or
grpcurl -plaintext localhost:50051 list
```

**Invalid BOT_ID:**
- Ensure BOT_ID is valid UUID format
- Check bot exists in Django database

**TLS errors:**
- Set `USE_TLS=false` for local development
- For production, ensure certificates are configured

## Architecture

```
┌─────────────┐           gRPC Stream          ┌─────────────┐
│  Bot Client │ ◄──────────────────────────► │   Django    │
│  (botserver)│                                │   Backend   │
└─────────────┘                                └─────────────┘
      │                                               │
      ├─ BotCore (trading logic)                     ├─ gRPC Server
      ├─ StreamingClient                             ├─ Database
      ├─ Services (exchange APIs)                    └─ RQ Workers
      └─ Supervisor (lifecycle)
```

## Related Projects

- **Django Backend**: `../django` - Main API & gRPC server
- **Schemas**: `@schemas/` - Protobuf definitions
- **Docs**: `@docs/` - Architecture & design docs
