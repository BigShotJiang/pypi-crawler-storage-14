"""Base trading bot class.

Developers extend TradingBot and implement on_signal().
All infrastructure is handled by BotClient.
"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, ClassVar, Optional, Type

from pydantic import BaseModel
from stockapis_bot.utils import get_logger

from ..exceptions import BotNotRunningError
from ..models.config import BotConfig
from ..models.enums import BotState
from ..models.execution import OrderResult, SignalDecision
from ..models.trading import AccountBalance, TickerInfo, TradingSignal
from ..utils.bot_id import generate_bot_id

if TYPE_CHECKING:
    from .client import BotClient

logger = get_logger(__name__)


class BotSettings(BaseModel):
    """Base settings model. Override in subclass for custom settings."""

    pass


class TradingBot(ABC):
    """Abstract base class for custom trading bots.

    Developers extend this class and implement on_signal().
    All infrastructure (gRPC, exchange, signals) is handled by BotClient.

    Example:
        class ScalperSettings(BotSettings):
            min_confidence: float = 0.7
            position_size: Decimal = 100
            symbols: list[str] = ["BTCUSDT"]

        class MyBot(TradingBot):
            settings_schema = ScalperSettings  # ← Define settings schema

            async def on_signal(self, signal: TradingSignal) -> SignalDecision:
                # Access typed settings
                if signal.confidence < self.settings.min_confidence:
                    return SignalDecision.skip("Low confidence")

                qty = await self.calculate_quantity(signal.symbol, 100, 10)
                return SignalDecision.buy(qty, "High confidence")

        # Just pass name - bot_id is auto-generated from it
        bot = MyBot(name="my-scalper")
        # bot.settings = ScalperSettings(...)  # Defaults applied

        client = BotClient.create(bot, config)
        await client.run()
    """

    # Override in subclass to define custom settings schema
    settings_schema: ClassVar[Type[BotSettings]] = BotSettings

    def __init__(self, name: str, bot_id: Optional[str] = None) -> None:
        """Initialize trading bot.

        Args:
            name: Bot name (used for UUID generation and display)
            bot_id: Optional explicit bot ID. If not provided, auto-generated from name.

        Note:
            bot_id is auto-generated from name using UUID5 (deterministic).
            Same name always produces the same UUID on any machine.
        """
        self.name = name
        self.bot_id = bot_id if bot_id else generate_bot_id(name)
        self.state = BotState.INITIALIZING
        self._config: Optional[BotConfig] = None
        self._client: Optional["BotClient"] = None
        # Initialize settings with defaults from schema
        self.settings: BotSettings = self.settings_schema()

    @property
    def config(self) -> Optional[BotConfig]:
        """Current bot configuration from Django."""
        return self._config

    @property
    def is_running(self) -> bool:
        """Check if bot is in running state."""
        return self.state == BotState.RUNNING

    @property
    def is_active(self) -> bool:
        """Check if bot is active (running and configured)."""
        if self._config is None:
            return False
        return self.is_running and self._config.active

    # === ABSTRACT METHODS (must implement) ===

    @abstractmethod
    async def on_signal(self, signal: TradingSignal) -> SignalDecision:
        """Process incoming trading signal.

        This is the main method to implement. Called for each trading signal.
        Return SignalDecision with action (BUY/SELL/SKIP).

        Args:
            signal: Trading signal to process

        Returns:
            SignalDecision with action and optional quantity

        Example:
            async def on_signal(self, signal: TradingSignal) -> SignalDecision:
                if not self._is_valid_signal(signal):
                    return SignalDecision.skip("Invalid signal")

                qty = await self.calculate_quantity(
                    symbol=signal.symbol,
                    usdt_amount=100,
                    leverage=10
                )

                if signal.is_buy_signal:
                    return SignalDecision.buy(qty, "Buy signal")
                elif signal.is_sell_signal:
                    return SignalDecision.sell(qty, "Sell signal")

                return SignalDecision.skip("Unknown signal type")
        """
        ...

    # === LIFECYCLE HOOKS (optional override) ===

    async def on_start(self) -> None:
        """Called when bot starts.

        Override to perform initialization tasks.
        """
        logger.info(f"Bot {self.name} started")

    async def on_stop(self, reason: str) -> None:
        """Called when bot stops.

        Override to perform cleanup tasks.

        Args:
            reason: Reason for stopping
        """
        logger.info(f"Bot {self.name} stopped: {reason}")

    async def on_pause(self, reason: str) -> None:
        """Called when bot is paused.

        Args:
            reason: Reason for pausing
        """
        logger.info(f"Bot {self.name} paused: {reason}")

    async def on_resume(self) -> None:
        """Called when bot resumes from pause."""
        logger.info(f"Bot {self.name} resumed")

    async def on_config_update(self, config: BotConfig, raw_settings: dict[str, Any]) -> None:
        """Called when configuration is updated from Django.

        Parses raw_settings into typed self.settings using settings_schema.
        Override to add custom logic after settings are updated.

        Args:
            config: Bot configuration (enabled, active, etc.)
            raw_settings: Raw settings dict from Django (parsed into self.settings)
        """
        self._config = config
        # Parse raw settings into typed Pydantic model
        self.settings = self.settings_schema(**raw_settings)
        logger.info(f"Bot {self.name} config updated: {self.settings}")

    async def on_error(self, error: Exception) -> None:
        """Called when an error occurs.

        Override to implement custom error handling.

        Args:
            error: The exception that occurred
        """
        logger.error(f"Bot {self.name} error: {error}")

    # === TRADING METHODS (provided by SDK) ===

    async def buy(
        self,
        symbol: str,
        quantity: str,
        reduce_only: bool = False,
    ) -> OrderResult:
        """Place market BUY order.

        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')
            quantity: Order quantity
            reduce_only: If True, only reduce position (futures)

        Returns:
            Order execution result
        """
        self._ensure_client()
        return await self._client.place_order(
            symbol=symbol,
            side="BUY",
            quantity=quantity,
            reduce_only=reduce_only,
        )

    async def sell(
        self,
        symbol: str,
        quantity: str,
        reduce_only: bool = False,
    ) -> OrderResult:
        """Place market SELL order.

        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')
            quantity: Order quantity
            reduce_only: If True, only reduce position (futures)

        Returns:
            Order execution result
        """
        self._ensure_client()
        return await self._client.place_order(
            symbol=symbol,
            side="SELL",
            quantity=quantity,
            reduce_only=reduce_only,
        )

    async def get_ticker(self, symbol: str) -> TickerInfo:
        """Get current price for symbol.

        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')

        Returns:
            Current ticker info with price
        """
        self._ensure_client()
        return await self._client.get_ticker(symbol)

    async def get_balance(self) -> AccountBalance:
        """Get account balance.

        Returns:
            Current account balance
        """
        self._ensure_client()
        return await self._client.get_balance()

    async def calculate_quantity(
        self,
        symbol: str,
        usdt_amount: float,
        leverage: int = 1,
    ) -> str:
        """Calculate order quantity from USDT amount.

        Uses exchange info to determine proper precision.

        Args:
            symbol: Trading pair
            usdt_amount: Amount in USDT to trade
            leverage: Leverage to apply (futures only)

        Returns:
            Formatted quantity string
        """
        self._ensure_client()
        return await self._client.calculate_quantity(
            symbol=symbol,
            usdt_amount=usdt_amount,
            leverage=leverage,
        )

    async def set_leverage(self, symbol: str, leverage: int) -> bool:
        """Set leverage for futures trading.

        Args:
            symbol: Trading pair
            leverage: Leverage value (1-125)

        Returns:
            True if successful
        """
        self._ensure_client()
        return await self._client.set_leverage(symbol=symbol, leverage=leverage)

    # === SETTINGS SCHEMA METHODS ===

    def get_settings_schema(self) -> dict[str, Any]:
        """Get JSON Schema for settings (Pydantic v2).

        Used by Django to store schema for frontend form generation.

        Returns:
            JSON Schema dict
        """
        return self.settings_schema.model_json_schema()

    def get_default_settings(self) -> dict[str, Any]:
        """Get default settings values.

        Used by Django to initialize settings when bot registers.

        Returns:
            Default settings as dict
        """
        return self.settings_schema().model_dump()

    # === INTERNAL METHODS ===

    def _set_client(self, client: "BotClient") -> None:
        """Set client reference (called by BotClient)."""
        self._client = client

    def _ensure_client(self) -> "BotClient":
        """Ensure client is set and return it."""
        if self._client is None:
            raise BotNotRunningError(
                message="Bot client not initialized. "
                "Create BotClient and call run() first.",
                bot_id=self.bot_id,
            )
        return self._client

    def _set_state(self, state: BotState) -> None:
        """Set bot state."""
        old_state = self.state
        self.state = state
        logger.debug(f"Bot {self.name} state: {old_state} -> {state}")
