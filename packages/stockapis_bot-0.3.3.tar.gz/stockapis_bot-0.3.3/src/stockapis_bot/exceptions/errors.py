"""
Complete exception hierarchy for BotClient SDK.

NO bare except, NO generic Exception catching.
All exceptions include structured error details.
"""

from typing import Optional

from pydantic import BaseModel, Field


class ErrorDetails(BaseModel):
    """Structured error details for logging and reporting."""

    code: str
    message: str
    context: dict[str, str] = Field(default_factory=dict)


class BotClientError(Exception):
    """Base exception for all BotClient errors."""

    def __init__(
        self,
        message: str,
        code: str,
        context: Optional[dict[str, str]] = None,
    ) -> None:
        self.message = message
        self.code = code
        self.context = context or {}
        super().__init__(message)

    def to_details(self) -> ErrorDetails:
        """Convert to structured error details."""
        return ErrorDetails(
            code=self.code,
            message=self.message,
            context=self.context,
        )

    def __str__(self) -> str:
        if self.context:
            ctx = ", ".join(f"{k}={v}" for k, v in self.context.items())
            return f"[{self.code}] {self.message} ({ctx})"
        return f"[{self.code}] {self.message}"


# === Connection Errors ===


class ConnectionError(BotClientError):
    """Base for all connection-related errors."""

    pass


class GRPCConnectionError(ConnectionError):
    """Failed to connect to gRPC server."""

    def __init__(
        self,
        message: str = "Failed to connect to gRPC server",
        host: str = "",
        port: int = 0,
    ) -> None:
        super().__init__(
            message=message,
            code="GRPC_CONNECTION_ERROR",
            context={"host": host, "port": str(port)} if host else None,
        )


class GRPCStreamError(ConnectionError):
    """gRPC stream interrupted or failed."""

    def __init__(
        self,
        message: str = "gRPC stream error",
        details: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="GRPC_STREAM_ERROR",
            context={"details": details} if details else None,
        )


class RedisConnectionError(ConnectionError):
    """Failed to connect to Redis."""

    def __init__(
        self,
        message: str = "Failed to connect to Redis",
        host: str = "",
        port: int = 0,
    ) -> None:
        super().__init__(
            message=message,
            code="REDIS_CONNECTION_ERROR",
            context={"host": host, "port": str(port)} if host else None,
        )


# === Exchange Errors ===


class ExchangeError(BotClientError):
    """Base for all exchange-related errors."""

    pass


class ExchangeConnectionError(ExchangeError):
    """Failed to connect to exchange API."""

    def __init__(
        self,
        message: str = "Failed to connect to exchange",
        exchange: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="EXCHANGE_CONNECTION_ERROR",
            context={"exchange": exchange} if exchange else None,
        )


class ExchangeAuthenticationError(ExchangeError):
    """Invalid API credentials."""

    def __init__(
        self,
        message: str = "Invalid API credentials",
        exchange: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="EXCHANGE_AUTH_ERROR",
            context={"exchange": exchange} if exchange else None,
        )


class OrderExecutionError(ExchangeError):
    """Failed to execute order."""

    def __init__(
        self,
        message: str,
        symbol: str = "",
        side: str = "",
        error_code: str = "",
    ) -> None:
        ctx: dict[str, str] = {}
        if symbol:
            ctx["symbol"] = symbol
        if side:
            ctx["side"] = side
        if error_code:
            ctx["error_code"] = error_code
        super().__init__(
            message=message,
            code="ORDER_EXECUTION_ERROR",
            context=ctx if ctx else None,
        )


class InsufficientBalanceError(ExchangeError):
    """Not enough balance for order."""

    def __init__(
        self,
        message: str = "Insufficient balance",
        required: str = "",
        available: str = "",
    ) -> None:
        ctx: dict[str, str] = {}
        if required:
            ctx["required"] = required
        if available:
            ctx["available"] = available
        super().__init__(
            message=message,
            code="INSUFFICIENT_BALANCE",
            context=ctx if ctx else None,
        )


class InvalidSymbolError(ExchangeError):
    """Symbol not supported by exchange."""

    def __init__(
        self,
        symbol: str,
        exchange: str = "",
    ) -> None:
        super().__init__(
            message=f"Symbol '{symbol}' not supported",
            code="INVALID_SYMBOL",
            context={"symbol": symbol, "exchange": exchange} if exchange else {"symbol": symbol},
        )


# === Validation Errors ===


class ValidationError(BotClientError):
    """Base for validation errors."""

    pass


class ConfigValidationError(ValidationError):
    """Invalid configuration."""

    def __init__(
        self,
        message: str,
        field: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="CONFIG_VALIDATION_ERROR",
            context={"field": field} if field else None,
        )


class SignalValidationError(ValidationError):
    """Invalid trading signal."""

    def __init__(
        self,
        message: str,
        signal_id: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="SIGNAL_VALIDATION_ERROR",
            context={"signal_id": signal_id} if signal_id else None,
        )


# === Business Logic Errors ===


class BusinessError(BotClientError):
    """Base for business logic errors."""

    pass


class BotNotRunningError(BusinessError):
    """Bot is not in running state."""

    def __init__(
        self,
        message: str = "Bot is not running",
        bot_id: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="BOT_NOT_RUNNING",
            context={"bot_id": bot_id} if bot_id else None,
        )


class SignalRejectedError(BusinessError):
    """Signal was rejected by bot logic."""

    def __init__(
        self,
        message: str,
        reason: str = "",
    ) -> None:
        super().__init__(
            message=message,
            code="SIGNAL_REJECTED",
            context={"reason": reason} if reason else None,
        )


class PositionLimitError(BusinessError):
    """Position size limit exceeded."""

    def __init__(
        self,
        message: str = "Position limit exceeded",
        current: str = "",
        limit: str = "",
    ) -> None:
        ctx: dict[str, str] = {}
        if current:
            ctx["current"] = current
        if limit:
            ctx["limit"] = limit
        super().__init__(
            message=message,
            code="POSITION_LIMIT_EXCEEDED",
            context=ctx if ctx else None,
        )
