"""Redis signal listener for pub/sub."""

import asyncio
import json
from typing import AsyncIterator, Optional

from stockapis_bot.utils import get_logger

from ..exceptions import RedisConnectionError
from ..models.config import RedisConfig
from ..models.enums import SignalType
from ..models.trading import TradingSignal

logger = get_logger(__name__)


class RedisSignalListener:
    """Redis pub/sub listener for trading signals.

    Listens to a Redis channel and yields TradingSignal objects.

    Example:
        config = RedisConfig(host="localhost", channel="trading_signals")
        listener = RedisSignalListener(config)
        await listener.connect()

        async for signal in listener.listen():
            print(f"Received: {signal.symbol}")
    """

    def __init__(self, config: RedisConfig) -> None:
        """Initialize Redis listener.

        Args:
            config: Redis connection configuration
        """
        self._config = config
        self._redis: Optional[object] = None
        self._pubsub: Optional[object] = None
        self._connected = False

    @property
    def is_connected(self) -> bool:
        """Check if connected to Redis."""
        return self._connected

    async def connect(self) -> bool:
        """Connect to Redis.

        Returns:
            True if connection successful.

        Raises:
            RedisConnectionError: If connection fails.
        """
        try:
            import redis.asyncio as aioredis

            self._redis = aioredis.from_url(
                self._config.url,
                decode_responses=True,
            )

            # Test connection
            await self._redis.ping()  # type: ignore

            # Subscribe to channel
            self._pubsub = self._redis.pubsub()  # type: ignore
            await self._pubsub.subscribe(self._config.channel)  # type: ignore

            self._connected = True
            logger.info(
                f"Connected to Redis at {self._config.host}:{self._config.port}, "
                f"channel: {self._config.channel}"
            )
            return True

        except ImportError:
            logger.error(
                "redis package not installed. "
                "Install with: pip install redis"
            )
            raise RedisConnectionError(
                message="redis package not installed",
                host=self._config.host,
                port=self._config.port,
            )
        except Exception as e:
            logger.error(f"Redis connection failed: {e}")
            self._connected = False
            raise RedisConnectionError(
                message=str(e),
                host=self._config.host,
                port=self._config.port,
            ) from e

    async def disconnect(self) -> None:
        """Disconnect from Redis."""
        if self._pubsub:
            await self._pubsub.unsubscribe(self._config.channel)  # type: ignore
            await self._pubsub.close()  # type: ignore
        if self._redis:
            await self._redis.close()  # type: ignore

        self._pubsub = None
        self._redis = None
        self._connected = False
        logger.info("Disconnected from Redis")

    async def listen(self) -> AsyncIterator[TradingSignal]:
        """Listen for trading signals.

        Yields:
            Trading signals from Redis channel.
        """
        if not self._connected or self._pubsub is None:
            logger.warning("Not connected to Redis")
            return

        logger.info(f"Listening for signals on channel: {self._config.channel}")

        try:
            async for message in self._pubsub.listen():  # type: ignore
                if message["type"] != "message":
                    continue

                signal = self._parse_message(message["data"])
                if signal:
                    yield signal

        except asyncio.CancelledError:
            logger.info("Signal listener cancelled")
        except Exception as e:
            logger.error(f"Signal listener error: {e}")

    def _parse_message(self, data: str) -> Optional[TradingSignal]:
        """Parse message into TradingSignal.

        Args:
            data: JSON message data

        Returns:
            TradingSignal if valid, None otherwise.
        """
        try:
            payload = json.loads(data)
            return TradingSignal(
                symbol=payload.get("symbol", ""),
                signal_type=SignalType(payload.get("signal_type", "INFO")),
                source=payload.get("source", "unknown"),
                confidence=payload.get("confidence", 0.5),
                price=payload.get("price"),
                metadata={
                    str(k): str(v)
                    for k, v in payload.get("metadata", {}).items()
                },
            )
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Failed to parse signal: {e}")
            return None
