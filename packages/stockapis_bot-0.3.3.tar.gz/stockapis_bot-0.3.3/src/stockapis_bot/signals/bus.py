"""Signal bus for distributing trading signals."""

import asyncio
from typing import Callable, Awaitable

from stockapis_bot.utils import get_logger

from ..models.trading import TradingSignal

logger = get_logger(__name__)

SignalHandler = Callable[[TradingSignal], Awaitable[None]]


class SignalBus:
    """In-memory signal bus for distributing trading signals.

    Allows multiple handlers to subscribe to signals.
    Useful for testing or local signal distribution.
    """

    def __init__(self) -> None:
        """Initialize signal bus."""
        self._handlers: list[SignalHandler] = []
        self._queue: asyncio.Queue[TradingSignal] = asyncio.Queue()

    def subscribe(self, handler: SignalHandler) -> None:
        """Subscribe a handler to receive signals.

        Args:
            handler: Async function to call with each signal
        """
        self._handlers.append(handler)
        logger.debug(f"Handler subscribed, total: {len(self._handlers)}")

    def unsubscribe(self, handler: SignalHandler) -> None:
        """Unsubscribe a handler.

        Args:
            handler: Handler to remove
        """
        if handler in self._handlers:
            self._handlers.remove(handler)
            logger.debug(f"Handler unsubscribed, total: {len(self._handlers)}")

    async def publish(self, signal: TradingSignal) -> None:
        """Publish a signal to all handlers.

        Args:
            signal: Trading signal to publish
        """
        logger.debug(f"Publishing signal: {signal.symbol} {signal.signal_type}")

        tasks = [self._call_handler(handler, signal) for handler in self._handlers]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _call_handler(
        self,
        handler: SignalHandler,
        signal: TradingSignal,
    ) -> None:
        """Call handler with error handling."""
        try:
            await handler(signal)
        except Exception as e:
            logger.error(f"Handler error: {e}")

    async def enqueue(self, signal: TradingSignal) -> None:
        """Add signal to queue for processing.

        Args:
            signal: Trading signal to enqueue
        """
        await self._queue.put(signal)

    async def dequeue(self) -> TradingSignal:
        """Get next signal from queue.

        Returns:
            Next trading signal
        """
        return await self._queue.get()

    def queue_size(self) -> int:
        """Get current queue size.

        Returns:
            Number of signals in queue
        """
        return self._queue.qsize()
