"""Execution and result models."""

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from .enums import OrderSide, OrderType, SignalAction


class OrderResult(BaseModel):
    """Result of order execution from exchange."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    success: bool
    order_id: Optional[str] = Field(default=None)
    symbol: Optional[str] = Field(default=None)
    side: Optional[OrderSide] = Field(default=None)
    order_type: OrderType = Field(default=OrderType.MARKET)
    quantity: Optional[str] = Field(default=None)
    price: Optional[str] = Field(default=None)
    filled_quantity: Optional[str] = Field(default=None)
    average_price: Optional[str] = Field(default=None)
    status: Optional[str] = Field(default=None)
    error: Optional[str] = Field(default=None)
    raw_response: dict[str, str] = Field(default_factory=dict)

    @property
    def is_filled(self) -> bool:
        """Check if order was filled."""
        return self.success and self.status in {"FILLED", "filled"}

    @property
    def error_message(self) -> str:
        """Get error message or empty string."""
        return self.error or ""


class ExecutionReport(BaseModel):
    """Execution report sent to Django via gRPC."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    execution_id: str
    symbol: str
    side: OrderSide
    quantity: str
    price: str
    filled_quantity: str
    average_price: str
    fee: str = Field(default="0")
    fee_currency: str = Field(default="USDT")
    status: str = Field(default="filled")
    exchange: str = Field(default="binance")
    order_type: str = Field(default="market")
    exchange_order_id: Optional[str] = Field(default=None)

    @classmethod
    def from_order_result(
        cls,
        execution_id: str,
        result: OrderResult,
        exchange: str = "binance",
    ) -> "ExecutionReport":
        """Create execution report from order result."""
        return cls(
            execution_id=execution_id,
            symbol=result.symbol or "",
            side=result.side or OrderSide.BUY,
            quantity=result.quantity or "0",
            price=result.average_price or result.price or "0",
            filled_quantity=result.filled_quantity or "0",
            average_price=result.average_price or "0",
            status=result.status or "unknown",
            exchange=exchange,
            order_type=result.order_type.value.lower(),
            exchange_order_id=result.order_id,
        )


class SignalDecision(BaseModel):
    """Bot's decision on how to handle a signal."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    action: SignalAction
    quantity: Optional[str] = Field(default=None)
    price: Optional[str] = Field(default=None)
    reason: Optional[str] = Field(default=None)
    metadata: dict[str, str] = Field(default_factory=dict)

    @classmethod
    def buy(cls, quantity: str, reason: str = "") -> "SignalDecision":
        """Create a BUY decision."""
        return cls(action=SignalAction.BUY, quantity=quantity, reason=reason)

    @classmethod
    def sell(cls, quantity: str, reason: str = "") -> "SignalDecision":
        """Create a SELL decision."""
        return cls(action=SignalAction.SELL, quantity=quantity, reason=reason)

    @classmethod
    def skip(cls, reason: str) -> "SignalDecision":
        """Create a SKIP decision."""
        return cls(action=SignalAction.SKIP, reason=reason)

    @property
    def should_trade(self) -> bool:
        """Check if this decision requires trading."""
        return self.action in {SignalAction.BUY, SignalAction.SELL}
