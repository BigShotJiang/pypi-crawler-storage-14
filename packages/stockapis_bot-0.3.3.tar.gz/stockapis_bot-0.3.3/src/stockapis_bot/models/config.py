"""Configuration models for botclient.

Uses shared.settings as the source of truth for environment configuration.
These models add validation and botclient-specific functionality.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Annotated, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from stockapis_bot.utils import (
    BinanceSettings,
    GrpcSettings,
    RedisSettings,
    get_settings,
)

from .enums import Direction, Environment, MarketType


# Built-in infrastructure configs per environment.
# Users only need to provide credentials (API keys) in .env.
ENVIRONMENTS: dict[Environment, dict] = {
    Environment.DEV: {
        "grpc": {
            "host": "localhost",
            "port": 50051,
            "use_tls": False,
        },
        "redis": {
            "host": "localhost",
            "port": 6379,
        },
    },
    Environment.PROD: {
        "grpc": {
            "host": "grpc.stockapis.com",
            "port": 443,
            "use_tls": True,
        },
        "redis": None,  # PROD uses gRPC only (no direct Redis access)
    },
}


# Re-export shared settings for convenience
__all__ = [
    "Environment",
    "ENVIRONMENTS",
    "ExchangeConfig",
    "GRPCConfig",
    "RedisConfig",
    "TradingParams",
    "BotConfig",
    "ClientConfig",
]


class ExchangeConfig(BaseModel):
    """Exchange connection configuration with validation."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    name: str = Field(default="binance", description="Exchange name (binance, bybit)")
    api_key: str
    api_secret: str
    testnet: bool = Field(default=True, description="Use testnet environment")
    market_type: MarketType = Field(default=MarketType.SWAP, description="Market type")

    @field_validator("name")
    @classmethod
    def validate_exchange_name(cls, v: str) -> str:
        """Normalize and validate exchange name."""
        normalized = v.lower().strip()
        valid_exchanges = {"binance", "bybit"}
        if normalized not in valid_exchanges:
            raise ValueError(f"Unsupported exchange: {v}. Valid: {valid_exchanges}")
        return normalized

    @classmethod
    def from_settings(
        cls,
        binance: BinanceSettings | None = None,
        market_type: MarketType = MarketType.SWAP,
    ) -> ExchangeConfig:
        """Create from shared BinanceSettings."""
        if binance is None:
            binance = get_settings().binance
        return cls(
            name="binance",
            api_key=binance.api_key,
            api_secret=binance.api_secret,
            testnet=binance.testnet,
            market_type=market_type,
        )


class GRPCConfig(BaseModel):
    """gRPC connection configuration with additional options."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    host: str = Field(default="localhost", description="gRPC server host")
    port: Annotated[int, Field(gt=0, le=65535)] = Field(default=50051)
    api_key: str
    use_tls: bool = Field(default=False, description="Enable TLS/SSL")
    timeout_seconds: Annotated[int, Field(gt=0, le=300)] = Field(default=30)
    reconnect_interval: Annotated[int, Field(gt=0, le=60)] = Field(
        default=5, description="Reconnect interval in seconds"
    )

    @property
    def address(self) -> str:
        """Get gRPC address string."""
        return f"{self.host}:{self.port}"

    @classmethod
    def from_settings(
        cls,
        grpc: GrpcSettings | None = None,
        env: Environment | None = None,
    ) -> GRPCConfig:
        """Create from shared GrpcSettings with optional environment override.

        If env is provided, infrastructure config (host, port, use_tls) comes from
        built-in ENVIRONMENTS. Only api_key is read from settings.
        """
        if grpc is None:
            grpc = get_settings().grpc

        if env is not None:
            env_config = ENVIRONMENTS[env]["grpc"]
            return cls(
                host=env_config["host"],
                port=env_config["port"],
                use_tls=env_config["use_tls"],
                api_key=grpc.api_key,
            )

        return cls(
            host=grpc.host,
            port=grpc.port,
            api_key=grpc.api_key,
            use_tls=grpc.use_tls,
        )


class RedisConfig(BaseModel):
    """Redis connection configuration."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    host: str = Field(default="localhost")
    port: Annotated[int, Field(gt=0, le=65535)] = Field(default=6379)
    db: Annotated[int, Field(ge=0, le=15)] = Field(default=0)
    password: Optional[str] = Field(default=None)
    channel: str = Field(default="trading_signals", description="Redis pub/sub channel")

    @property
    def url(self) -> str:
        """Get Redis URL string."""
        if self.password:
            return f"redis://:{self.password}@{self.host}:{self.port}/{self.db}"
        return f"redis://{self.host}:{self.port}/{self.db}"

    @classmethod
    def from_settings(
        cls,
        redis: RedisSettings | None = None,
        env: Environment | None = None,
    ) -> RedisConfig | None:
        """Create from shared RedisSettings with optional environment override.

        If env is provided, infrastructure config (host, port) comes from
        built-in ENVIRONMENTS. Password and channel are read from settings.
        Returns None if environment has no Redis config (e.g., PROD).
        """
        if redis is None:
            redis = get_settings().redis

        if env is not None:
            env_config = ENVIRONMENTS[env]["redis"]
            if env_config is None:
                return None  # No Redis in this environment
            return cls(
                host=env_config["host"],
                port=env_config["port"],
                password=redis.password,
                channel=redis.channel,
            )

        return cls(
            host=redis.host,
            port=redis.port,
            password=redis.password,
            channel=redis.channel,
        )


class TradingParams(BaseModel):
    """Trading parameters - configured from Django."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    symbol: Annotated[str, Field(min_length=1, max_length=20)]
    direction: Direction = Field(default=Direction.LONG)
    amount_usdt: Annotated[Decimal, Field(gt=0)] = Field(default=Decimal("100.0"))
    leverage: Annotated[int, Field(ge=1, le=125)] = Field(default=10)
    max_position_size: Annotated[Decimal, Field(gt=0)] = Field(default=Decimal("1000.0"))
    stop_loss_pct: Annotated[Decimal, Field(ge=0, le=1)] = Field(
        default=Decimal("0.05"), description="Stop loss percentage (0.05 = 5%)"
    )
    take_profit_pct: Annotated[Decimal, Field(ge=0, le=1)] = Field(
        default=Decimal("0.10"), description="Take profit percentage (0.10 = 10%)"
    )
    allowed_sources: list[str] = Field(
        default_factory=lambda: ["listing", "technical"],
        description="Allowed signal sources",
    )
    min_confidence: Annotated[float, Field(ge=0, le=1)] = Field(
        default=0.5, description="Minimum signal confidence to act"
    )

    @field_validator("symbol")
    @classmethod
    def normalize_symbol(cls, v: str) -> str:
        """Normalize symbol format (remove separators, uppercase)."""
        return v.upper().replace("/", "").replace("-", "").replace("_", "")


class BotConfig(BaseModel):
    """Bot metadata from Django via gRPC.

    Note: Bot-specific settings are in raw_settings dict,
    which the bot parses into its own settings_schema.
    """

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    bot_id: str
    name: str
    enabled: bool = Field(default=True, description="Whether bot is enabled")
    active: bool = Field(default=False, description="Whether bot is actively trading")
    description: str = Field(default="")


class ClientConfig(BaseModel):
    """BotClient initialization configuration."""

    model_config = ConfigDict(validate_assignment=True, extra="forbid")

    bot_id: str
    bot_name: str
    grpc: GRPCConfig
    exchange: Optional[ExchangeConfig] = Field(default=None)
    redis: Optional[RedisConfig] = Field(default=None)
    heartbeat_interval: Annotated[int, Field(gt=0, le=300)] = Field(
        default=30, description="Heartbeat interval in seconds"
    )

    @classmethod
    def from_settings(
        cls,
        bot_id: str,
        bot_name: str,
        env: Environment | None = None,
        include_exchange: bool = True,
        include_redis: bool = True,
    ) -> ClientConfig:
        """Create full ClientConfig from shared settings.

        Args:
            bot_id: Bot unique identifier
            bot_name: Bot display name
            env: Environment (DEV/PROD). If provided, uses built-in infrastructure
                 configs. Only credentials (api_key, password) are read from .env.
            include_exchange: Include Binance exchange adapter
            include_redis: Include Redis signal listener
        """
        settings = get_settings()
        return cls(
            bot_id=bot_id,
            bot_name=bot_name,
            grpc=GRPCConfig.from_settings(settings.grpc, env=env),
            exchange=ExchangeConfig.from_settings(settings.binance) if include_exchange else None,
            redis=RedisConfig.from_settings(settings.redis, env=env) if include_redis else None,
        )
