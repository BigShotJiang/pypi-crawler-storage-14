"""
Settings for stockapis-bot using pydantic-settings.

Uses double underscore prefix for environment variable grouping:
    GRPC__HOST -> settings.grpc.host
    REDIS__HOST -> settings.redis.host
    BINANCE__API_KEY -> settings.binance.api_key

.env file search order:
    1. Current working directory (.env) - PyPI users
    2. examples/.env - development

Usage:
    from stockapis_bot.utils import get_settings
    settings = get_settings()

    settings.grpc.host
    settings.binance.api_key
"""

from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_env_file() -> str | None:
    """Find .env file in search paths."""
    package_root = Path(__file__).parent.parent.parent.parent

    search_paths = [
        Path.cwd() / ".env",
        package_root / "examples" / ".env",
        package_root / "debug" / ".env",
    ]

    for path in search_paths:
        if path.exists():
            return str(path)

    return None


class RedisSettings(BaseModel):
    """Redis settings."""
    host: str = "localhost"
    port: int = 6379
    password: Optional[str] = None
    channel: str = "trading_signals"

    @property
    def url(self) -> str:
        """Get Redis URL."""
        if self.password:
            return f"redis://:{self.password}@{self.host}:{self.port}"
        return f"redis://{self.host}:{self.port}"


class BinanceSettings(BaseModel):
    """Binance settings."""
    api_key: str = ""
    api_secret: str = ""
    testnet: bool = True


class GrpcSettings(BaseModel):
    """gRPC settings."""
    host: str = "localhost"
    port: int = 50051
    api_key: str = ""
    use_tls: bool = False

    @property
    def address(self) -> str:
        """Get gRPC address."""
        return f"{self.host}:{self.port}"


class Settings(BaseSettings):
    """Settings for stockapis-bot."""

    model_config = SettingsConfigDict(
        env_file_encoding="utf-8",
        env_nested_delimiter="__",
        extra="ignore",
    )

    redis: RedisSettings = RedisSettings()
    binance: BinanceSettings = BinanceSettings()
    grpc: GrpcSettings = GrpcSettings()


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    env_file = _find_env_file()
    return Settings(_env_file=env_file)


def clear_settings_cache() -> None:
    """Clear settings cache (useful for testing)."""
    get_settings.cache_clear()
