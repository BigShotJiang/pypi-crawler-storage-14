"""Prompt templates."""

from .llm_agent import LLMAgentTemplates, default_templates

__all__ = [
    "default_templates",
    "LLMAgentTemplates",
]
