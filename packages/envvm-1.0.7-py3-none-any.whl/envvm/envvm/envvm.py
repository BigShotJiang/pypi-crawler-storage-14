import os
import subprocess
from prompt_toolkit import prompt
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter
from prompt_toolkit.shortcuts import CompleteStyle
from envvm.validators.validators import (
    EnvVarValidator,
    EnvVarNameValidator,
    OperationValidator,
    PathValidator
)

from .othersenv import others_dict
from .uvenv import uv_dict
from .vagrantenv import vagrant_dict
from .gitenv import git_dict


class ENVVM():
    def list(self, x=False):
        """列出系统中所有环境变量
        
        Args:
            x: 如果为True，则通过prompt_toolkit的FuzzyCompleter让用户选择需要查看的变量并查看其值
        
        如果x为False，直接打印所有环境变量及其值。
        如果x为True，提供交互式模糊搜索界面让用户选择特定环境变量查看。
        """
        if x:
            env_keys = sorted(os.environ.keys())
            completer = FuzzyCompleter(WordCompleter(env_keys))
            validator = EnvVarValidator()
            selected = prompt("选择环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
            print(f"{selected}={os.environ[selected]}")
        else:
            for key, value in sorted(os.environ.items()):
                print(f"{key}={value}")

    def setenv(self, custom_env_name=None):
        """永久添加环境变量，支持从预定义字典中模糊选择
        
        Args:
            custom_env_name: 可选的环境变量名，如果指定则直接设置该变量，否则从字典中选择
        
        合并uv_dict、vagrant_dict和others_dict三个预定义字典。
        如果指定了custom_env_name，直接使用该名称；否则提供交互式模糊搜索界面选择。
        如果环境变量已存在，会提示用户确认是否覆盖。
        使用setx命令永久设置环境变量到Windows注册表。
        
        Raises:
            subprocess.CalledProcessError: 当setx命令执行失败时
        """
        # 合并三个字典
        merged_dict = {**uv_dict, **vagrant_dict, **others_dict, **git_dict}
        
        # 如果用户指定了环境变量名，直接使用
        if custom_env_name:
            selected_key = custom_env_name
        else:
            # 获取所有环境变量名作为提示选项
            env_keys = sorted(merged_dict.keys())
            completer = FuzzyCompleter(WordCompleter(env_keys))
            validator = EnvVarNameValidator(env_keys)
            
            # 让用户选择环境变量名
            selected_key = prompt("选择要设置的环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        # 如果 selected_key 为PATH 则直接退出 并提示用户 使用 update_path 进行操作
        if selected_key.upper() == 'PATH':
            print("错误: PATH 环境变量不能通过此方法设置")
            print("请使用 update_path 方法来操作 PATH 环境变量")
            return
        
        # 检查环境变量是否已经设置
        if selected_key in os.environ:
            current_value = os.environ[selected_key]
            print(f"警告: 环境变量 {selected_key} 已经设置")
            print(f"当前值: {current_value}")
            confirm = prompt("是否要覆盖现有值? (y/n): ")
            if confirm.lower() != 'y':
                print("操作已取消")
                return
        
        # 获取该环境变量的配置（如果存在于字典中）
        env_config = merged_dict.get(selected_key, {})
        templates = env_config.get("templates", []) if env_config else []
        
        # 如果有模板值，提供模糊选择
        if templates:
            template_completer = FuzzyCompleter(WordCompleter(templates))
            selected_value = prompt(f"输入 {selected_key} 的值: ", completer=template_completer, complete_style=CompleteStyle.MULTI_COLUMN)
        else:
            # 如果环境变量不在字典中或没有模板，直接输入
            selected_value = prompt(f"输入 {selected_key} 的值: ")
        
        # 使用 setx 永久设置环境变量
        try:
            subprocess.run(['setx', selected_key, selected_value], 
                         check=True, capture_output=True, text=True)
            
            # 同时在当前进程环境中设置
            os.environ[selected_key] = selected_value
            
            print(f"成功设置环境变量: {selected_key}={selected_value}")
            print("注意: 需要重启终端或重新登录才能在新进程中生效")
        except subprocess.CalledProcessError as e:
            print(f"设置失败: {e.stderr}")
        except Exception as e:
            print(f"设置失败: {str(e)}")
    
    def delenv(self):
        """通过模糊补全让用户选择需要操作的环境变量，然后永久删除这个环境变量
        
        提供交互式模糊搜索界面让用户选择要删除的环境变量。
        显示当前值并要求用户确认删除操作。
        使用reg delete命令从Windows注册表中永久删除环境变量。
        PATH环境变量不可删除，会直接返回错误提示。
        
        Raises:
            subprocess.CalledProcessError: 当reg delete命令执行失败时
        """
        # 获取所有环境变量名作为提示选项
        env_keys = sorted(os.environ.keys())
        completer = FuzzyCompleter(WordCompleter(env_keys))
        validator = EnvVarValidator()
        
        # 让用户选择要删除的环境变量
        selected_key = prompt("选择要删除的环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        # 如果 selected_key 为PATH 则直接退出 并告诉用户不可删除
        if selected_key.upper() == 'PATH':
            print("错误: PATH 环境变量不可删除")
            print("PATH 是系统关键环境变量，删除后可能导致系统无法正常工作")
            return
        
        # 检查环境变量是否存在
        if selected_key not in os.environ:
            print(f"错误: 环境变量 {selected_key} 不存在")
            return
        
        # 显示当前值并确认删除
        current_value = os.environ[selected_key]
        print(f"环境变量: {selected_key}")
        print(f"当前值: {current_value}")
        confirm = prompt("确认删除此环境变量? (y/n): ")
        
        if confirm.lower() != 'y':
            print("操作已取消")
            return
        
        # 永久删除环境变量
        try:
            # 使用 setx 删除用户环境变量（设置为空字符串）
            subprocess.run(['reg', 'delete', 'HKCU\\Environment', '/v', selected_key, '/f'], 
                         check=True, capture_output=True, text=True)
            
            # 从当前进程环境中删除
            if selected_key in os.environ:
                del os.environ[selected_key]
            
            print(f"成功删除环境变量: {selected_key}")
            print("注意: 需要重启终端或重新登录才能在新进程中生效")
        except subprocess.CalledProcessError as e:
            print(f"删除失败: {e.stderr}")
        except Exception as e:
            print(f"删除失败: {str(e)}")
            

    def list_path(self):
        """获取PATH的值并使用人类可读的方式输出
        
        读取PATH环境变量的值，按分隔符拆分后逐行显示。
        每行显示序号和对应的路径，便于用户查看和管理。
        """
        path_value = os.environ.get('PATH', '')
        if not path_value:
            print("PATH 环境变量未设置")
            return
        
        paths = path_value.split(os.pathsep)
        print(f"PATH 包含 {len(paths)} 个路径:\n")
        for i, path in enumerate(paths, 1):
            print(f"{i:3d}. {path}")
            
    def update_path(self):
        """更新PATH环境变量，支持添加和删除路径
        
        提供交互式界面让用户选择操作类型（add或del）。
        添加操作：输入新路径后添加到PATH末尾，自动检查重复。
        删除操作：提供模糊搜索选择要删除的路径，需要确认后执行。
        使用reg命令直接操作Windows注册表中的用户PATH环境变量。
        
        Raises:
            subprocess.CalledProcessError: 当reg命令执行失败时
        """
        # 让用户选择操作类型
        operations = ['add', 'del']
        completer = FuzzyCompleter(WordCompleter(operations))
        validator = OperationValidator(operations)
        operation = prompt("选择操作 (add/del): ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        if operation == 'add':
            # 添加路径到PATH
            new_path = prompt("输入要添加的路径: ").strip()
            
            if not new_path:
                print("错误: 路径不能为空")
                return
            
            # 获取当前用户的PATH值
            try:
                result = subprocess.run(['reg', 'query', 'HKCU\\Environment', '/v', 'Path'],
                                      capture_output=True, text=True, check=True)
                
                # 解析注册表输出
                for line in result.stdout.split('\n'):
                    if 'Path' in line and 'REG_' in line:
                        current_path = line.split('REG_EXPAND_SZ', 1)[-1].strip() if 'REG_EXPAND_SZ' in line else line.split('REG_SZ', 1)[-1].strip()
                        break
                else:
                    current_path = ''
            except subprocess.CalledProcessError:
                current_path = ''
            
            # 拆分PATH并去重
            paths = [p.strip() for p in current_path.split(';') if p.strip()]
            
            # 检查路径是否已存在
            if new_path in paths:
                print(f"路径已存在于PATH中: {new_path}")
                return
            
            # 添加新路径到尾部
            paths.append(new_path)
            new_path_value = ';'.join(paths)
            
            # 更新注册表
            try:
                subprocess.run(['reg', 'add', 'HKCU\\Environment', '/v', 'Path', '/t', 'REG_EXPAND_SZ', '/d', new_path_value, '/f'],
                             check=True, capture_output=True, text=True)
                print(f"成功添加路径到PATH: {new_path}")
                print("注意: 需要重启终端或重新登录才能在新进程中生效")
            except subprocess.CalledProcessError as e:
                print(f"添加失败: {e.stderr}")
            except Exception as e:
                print(f"添加失败: {str(e)}")
                
        elif operation == 'del':
            # 从PATH中删除路径
            try:
                result = subprocess.run(['reg', 'query', 'HKCU\\Environment', '/v', 'Path'],
                                      capture_output=True, text=True, check=True)
                
                # 解析注册表输出
                for line in result.stdout.split('\n'):
                    if 'Path' in line and 'REG_' in line:
                        current_path = line.split('REG_EXPAND_SZ', 1)[-1].strip() if 'REG_EXPAND_SZ' in line else line.split('REG_SZ', 1)[-1].strip()
                        break
                else:
                    print("错误: 无法读取PATH环境变量")
                    return
            except subprocess.CalledProcessError:
                print("错误: 无法读取PATH环境变量")
                return
            
            # 拆分PATH
            paths = [p.strip() for p in current_path.split(';') if p.strip()]
            
            if not paths:
                print("PATH为空，没有可删除的路径")
                return
            
            # 让用户选择要删除的路径
            path_completer = FuzzyCompleter(WordCompleter(paths))
            path_validator = PathValidator(paths)
            selected_path = prompt("选择要删除的路径: ", completer=path_completer, validator=path_validator, complete_style=CompleteStyle.MULTI_COLUMN)
            
            if selected_path not in paths:
                print(f"错误: 路径不存在于PATH中: {selected_path}")
                return
            
            # 确认删除
            confirm = prompt(f"确认删除路径: {selected_path}? (y/n): ")
            if confirm.lower() != 'y':
                print("操作已取消")
                return
            
            # 删除路径
            paths.remove(selected_path)
            new_path_value = ';'.join(paths)
            
            # 更新注册表
            try:
                subprocess.run(['reg', 'add', 'HKCU\\Environment', '/v', 'Path', '/t', 'REG_EXPAND_SZ', '/d', new_path_value, '/f'],
                             check=True, capture_output=True, text=True)
                print(f"成功从PATH中删除路径: {selected_path}")
                print("注意: 需要重启终端或重新登录才能在新进程中生效")
            except subprocess.CalledProcessError as e:
                print(f"删除失败: {e.stderr}")
            except Exception as e:
                print(f"删除失败: {str(e)}")
        else:
            print("错误: 无效的操作，请选择 add 或 del")