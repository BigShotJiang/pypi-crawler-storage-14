
others_dict={
    
    "YAZI_FILE_ONE":{
        "meta":"用来设置git的file.exe的位置",
        "templates":[
            r"C:\Program Files\Git\usr\bin\file.exe",
        ]
    }
}