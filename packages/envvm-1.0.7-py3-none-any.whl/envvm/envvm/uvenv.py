

uv_dict = {
    "UV_BREAK_SYSTEM_PACKAGES": {
        "meta": "允许在系统 Python 环境中安装包"
    },
    "UV_BUILD_CONSTRAINT": {
        "meta": "构建时的约束文件路径"
    },
    "UV_CACHE_DIR": {
        "meta": "缓存目录路径"
    },
    "UV_COMPILE_BYTECODE": {
        "meta": "安装时编译 Python 字节码"
    },
    "UV_COMPILE_BYTECODE_TIMEOUT": {
        "meta": "字节码编译超时时间(秒)"
    },
    "UV_CONCURRENT_BUILDS": {
        "meta": "并发构建数量"
    },
    "UV_CONCURRENT_DOWNLOADS": {
        "meta": "并发下载数量"
    },
    "UV_CONCURRENT_INSTALLS": {
        "meta": "并发安装数量"
    },
    "UV_CONFIG_FILE": {
        "meta": "配置文件路径"
    },
    "UV_CONSTRAINT": {
        "meta": "约束文件路径"
    },
    "UV_CREDENTIALS_DIR": {
        "meta": "凭证存储目录"
    },
    "UV_CUSTOM_COMPILE_COMMAND": {
        "meta": "自定义编译命令"
    },
    "UV_DEFAULT_INDEX": {
        "meta": "默认包索引 URL"
    },
    "UV_DEV": {
        "meta": "启用开发依赖"
    },
    "UV_DOWNLOAD_URL": {
        "meta": "uv 下载地址"
    },
    "UV_ENV_FILE": {
        "meta": "环境变量文件路径"
    },
    "UV_EXCLUDE": {
        "meta": "排除的包"
    },
    "UV_EXCLUDE_NEWER": {
        "meta": "排除指定日期后发布的包"
    },
    "UV_EXTRA_INDEX_URL": {
        "meta": "额外的包索引 URL"
    },
    "UV_FIND_LINKS": {
        "meta": "查找链接的路径或 URL"
    },
    "UV_FORK_STRATEGY": {
        "meta": "依赖解析的分叉策略"
    },
    "UV_FROZEN": {
        "meta": "冻结模式,不更新锁文件"
    },
    "UV_GITHUB_TOKEN": {
        "meta": "GitHub 访问令牌"
    },
    "UV_GIT_LFS": {
        "meta": "启用 Git LFS 支持"
    },
    "UV_HTTP_RETRIES": {
        "meta": "HTTP 请求重试次数"
    },
    "UV_HTTP_TIMEOUT": {
        "meta": "HTTP 请求超时时间(秒)"
    },
    "UV_INDEX": {
        "meta": "包索引配置"
    },
    "UV_INDEX_STRATEGY": {
        "meta": "索引搜索策略"
    },
    "UV_INDEX_URL": {
        "meta": "包索引 URL"
    },
    "UV_INDEX_XXX_PASSWORD": {
        "meta": "索引认证密码(XXX为索引名)"
    },
    "UV_INDEX_XXX_USERNAME": {
        "meta": "索引认证用户名(XXX为索引名)"
    },
    "UV_INIT_BUILD_BACKEND": {
        "meta": "初始化项目时的构建后端"
    },
    "UV_INSECURE_HOST": {
        "meta": "允许不安全连接的主机"
    },
    "UV_INSECURE_NO_ZIP_VALIDATION": {
        "meta": "跳过 ZIP 文件验证"
    },
    "UV_INSTALLER_GHE_BASE_URL": {
        "meta": "GitHub Enterprise 基础 URL"
    },
    "UV_INSTALLER_GITHUB_BASE_URL": {
        "meta": "GitHub 基础 URL"
    },
    "UV_INSTALL_DIR": {
        "meta": "uv 安装目录"
    },
    "UV_ISOLATED": {
        "meta": "隔离模式,忽略配置文件"
    },
    "UV_KEYRING_PROVIDER": {
        "meta": "密钥环提供者"
    },
    "UV_LIBC": {
        "meta": "指定 libc 实现(glibc/musl)"
    },
    "UV_LINK_MODE": {
        "meta": "包链接模式(copy/hardlink/symlink)"
    },
    "UV_LOCKED": {
        "meta": "锁定模式,要求锁文件最新"
    },
    "UV_LOG_CONTEXT": {
        "meta": "日志上下文信息"
    },
    "UV_MANAGED_PYTHON": {
        "meta": "使用 uv 管理的 Python"
    },
    "UV_NATIVE_TLS": {
        "meta": "使用系统原生 TLS"
    },
    "UV_NO_BINARY": {
        "meta": "禁用所有二进制包"
    },
    "UV_NO_BINARY_PACKAGE": {
        "meta": "禁用指定包的二进制版本"
    },
    "UV_NO_BUILD": {
        "meta": "禁用所有源码构建"
    },
    "UV_NO_BUILD_ISOLATION": {
        "meta": "禁用构建隔离"
    },
    "UV_NO_BUILD_PACKAGE": {
        "meta": "禁用指定包的源码构建"
    },
    "UV_NO_CACHE": {
        "meta": "禁用缓存"
    },
    "UV_NO_CONFIG": {
        "meta": "忽略配置文件"
    },
    "UV_NO_DEFAULT_GROUPS": {
        "meta": "不安装默认依赖组"
    },
    "UV_NO_DEV": {
        "meta": "不安装开发依赖"
    },
    "UV_NO_EDITABLE": {
        "meta": "不使用可编辑安装"
    },
    "UV_NO_ENV_FILE": {
        "meta": "不加载环境变量文件"
    },
    "UV_NO_GITHUB_FAST_PATH": {
        "meta": "禁用 GitHub 快速路径"
    },
    "UV_NO_GROUP": {
        "meta": "排除的依赖组"
    },
    "UV_NO_HF_TOKEN": {
        "meta": "不使用 HuggingFace 令牌"
    },
    "UV_NO_INSTALLER_METADATA": {
        "meta": "不写入安装器元数据"
    },
    "UV_NO_MANAGED_PYTHON": {
        "meta": "不使用 uv 管理的 Python"
    },
    "UV_NO_MODIFY_PATH": {
        "meta": "不修改 PATH 环境变量"
    },
    "UV_NO_PROGRESS": {
        "meta": "禁用进度条显示"
    },
    "UV_NO_SOURCES": {
        "meta": "忽略 tool.uv.sources"
    },
    "UV_NO_SYNC": {
        "meta": "不自动同步环境"
    },
    "UV_NO_VERIFY_HASHES": {
        "meta": "不验证哈希值"
    },
    "UV_NO_WRAP": {
        "meta": "禁用输出换行"
    },
    "UV_OFFLINE": {
        "meta": "离线模式"
    },
    "UV_OVERRIDE": {
        "meta": "覆盖文件路径"
    },
    "UV_PRERELEASE": {
        "meta": "预发布版本处理策略"
    },
    "UV_PREVIEW": {
        "meta": "启用预览功能"
    },
    "UV_PREVIEW_FEATURES": {
        "meta": "启用的预览功能列表"
    },
    "UV_PROJECT": {
        "meta": "项目目录路径"
    },
    "UV_PROJECT_ENVIRONMENT": {
        "meta": "项目虚拟环境路径"
    },
    "UV_PUBLISH_CHECK_URL": {
        "meta": "发布前检查的 URL"
    },
    "UV_PUBLISH_INDEX": {
        "meta": "发布目标索引"
    },
    "UV_PUBLISH_PASSWORD": {
        "meta": "发布认证密码"
    },
    "UV_PUBLISH_TOKEN": {
        "meta": "发布认证令牌"
    },
    "UV_PUBLISH_URL": {
        "meta": "发布目标 URL"
    },
    "UV_PUBLISH_USERNAME": {
        "meta": "发布认证用户名"
    },
    "UV_PYPY_INSTALL_MIRROR": {
        "meta": "PyPy 安装镜像 URL"
    },
    "UV_PYTHON": {
        "meta": "Python 解释器路径或版本"
    },
    "UV_PYTHON_BIN_DIR": {
        "meta": "Python 可执行文件目录"
    },
    "UV_PYTHON_CACHE_DIR": {
        "meta": "Python 缓存目录"
    },
    "UV_PYTHON_CPYTHON_BUILD": {
        "meta": "CPython 构建变体"
    },
    "UV_PYTHON_DOWNLOADS": {
        "meta": "Python 下载策略"
    },
    "UV_PYTHON_DOWNLOADS_JSON_URL": {
        "meta": "Python 下载元数据 URL"
    },
    "UV_PYTHON_GRAALPY_BUILD": {
        "meta": "GraalPy 构建变体"
    },
    "UV_PYTHON_INSTALL_BIN": {
        "meta": "Python 安装的 bin 目录"
    },
    "UV_PYTHON_INSTALL_DIR": {
        "meta": "Python 安装目录"
    },
    "UV_PYTHON_INSTALL_MIRROR": {
        "meta": "Python 安装镜像 URL"
    },
    "UV_PYTHON_INSTALL_REGISTRY": {
        "meta": "Python 安装注册表"
    },
    "UV_PYTHON_PREFERENCE": {
        "meta": "Python 版本偏好策略"
    },
    "UV_PYTHON_PYODIDE_BUILD": {
        "meta": "Pyodide 构建变体"
    },
    "UV_PYTHON_PYPY_BUILD": {
        "meta": "PyPy 构建变体"
    },
    "UV_REQUEST_TIMEOUT": {
        "meta": "请求超时时间(秒)"
    },
    "UV_REQUIRE_HASHES": {
        "meta": "要求所有依赖有哈希值"
    },
    "UV_RESOLUTION": {
        "meta": "依赖解析策略"
    },
    "UV_S3_ENDPOINT_URL": {
        "meta": "S3 端点 URL"
    },
    "UV_SKIP_WHEEL_FILENAME_CHECK": {
        "meta": "跳过 wheel 文件名检查"
    },
    "UV_STACK_SIZE": {
        "meta": "栈大小限制"
    },
    "UV_SYSTEM_PYTHON": {
        "meta": "使用系统 Python"
    },
    "UV_TEST_NO_HTTP_RETRY_DELAY": {
        "meta": "测试时禁用 HTTP 重试延迟"
    },
    "UV_TOOL_BIN_DIR": {
        "meta": "工具可执行文件目录"
    },
    "UV_TOOL_DIR": {
        "meta": "工具安装目录"
    },
    "UV_TORCH_BACKEND": {
        "meta": "PyTorch 后端(cpu/cuda/rocm等)"
    },
    "UV_UNMANAGED_INSTALL": {
        "meta": "非托管安装路径"
    },
    "UV_UPLOAD_HTTP_TIMEOUT": {
        "meta": "上传超时时间(秒)"
    },
    "UV_VENV_CLEAR": {
        "meta": "创建虚拟环境前清空目录"
    },
    "UV_VENV_SEED": {
        "meta": "虚拟环境预装 pip/setuptools"
    },
    "UV_WORKING_DIRECTORY": {
        "meta": "工作目录路径"
    },
}
