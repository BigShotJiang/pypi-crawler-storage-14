

vagrant_dict = {
    "CFLAGS": {
        "meta": "C 编译器标志"
    },
    "CPPFLAGS": {
        "meta": "C 预处理器标志"
    },
    "CURL_CA_BUNDLE": {
        "meta": "CA 证书包路径"
    },
    "LDFLAGS": {
        "meta": "链接器标志"
    },
    "SSL_CERT_FILE": {
        "meta": "SSL 证书文件路径"
    },
    "VAGRANT_ALIAS_FILE": {
        "meta": "命令别名文件路径"
    },
    "VAGRANT_ALLOW_PLUGIN_SOURCE_ERRORS": {
        "meta": "允许插件源错误"
    },
    "VAGRANT_BOX_UPDATE_CHECK_DISABLE": {
        "meta": "禁用 box 更新检查"
    },
    "VAGRANT_CHECKPOINT_DISABLE": {
        "meta": "禁用版本检查点"
    },
    "VAGRANT_CWD": {
        "meta": "工作目录路径"
    },
    "VAGRANT_DEBUG_LAUNCHER": {
        "meta": "启用启动器调试"
    },
    "VAGRANT_DEFAULT_PROVIDER": {
        "meta": "默认虚拟化提供者",
        "templates": [
            r"virtualbox",
            r"hyperv",
        ]
    },
    "VAGRANT_DEFAULT_TEMPLATE": {
        "meta": "默认 Vagrantfile 模板"
    },
    "VAGRANT_DETECTED_ARCH": {
        "meta": "检测到的系统架构"
    },
    "VAGRANT_DETECTED_OS": {
        "meta": "检测到的操作系统"
    },
    "VAGRANT_DISABLE_RESOLV_REPLACE": {
        "meta": "禁用 resolv.conf 替换"
    },
    "VAGRANT_DISABLE_VBOXSYMLINKCREATE": {
        "meta": "禁用 VirtualBox 符号链接创建"
    },
    "VAGRANT_DISABLE_SMBMFSYMLINKS": {
        "meta": "禁用 SMB 符号链接"
    },
    "VAGRANT_DOTFILE_PATH": {
        "meta": ".vagrant 目录路径"
    },
    "VAGRANT_ENABLE_RESOLV_REPLACE": {
        "meta": "启用 resolv.conf 替换"
    },
    "VAGRANT_FORCE_COLOR": {
        "meta": "强制彩色输出"
    },
    "VAGRANT_HOME": {
        "meta": "Vagrant 主目录",
        "templates": [
            r"E:\VagrantHome",
        ]
    },
    "VAGRANT_IGNORE_WINRM_PLUGIN": {
        "meta": "忽略 WinRM 插件"
    },
    "VAGRANT_INSTALL_LOCAL_PLUGINS": {
        "meta": "安装本地插件"
    },
    "VAGRANT_IS_HYPERV_ADMIN": {
        "meta": "是否为 Hyper-V 管理员"
    },
    "VAGRANT_LOCAL_PLUGINS_LOAD": {
        "meta": "加载本地插件"
    },
    "VAGRANT_LOG": {
        "meta": "日志级别(debug/info/warn/error)"
    },
    "VAGRANT_MAX_REBOOT_RETRY_DURATION": {
        "meta": "重启重试最大时长(秒)"
    },
    "VAGRANT_NO_COLOR": {
        "meta": "禁用彩色输出"
    },
    "VAGRANT_NO_PARALLEL": {
        "meta": "禁用并行操作"
    },
    "VAGRANT_NO_PLUGINS": {
        "meta": "禁用所有插件"
    },
    "VAGRANT_POWERSHELL_VERSION_DETECTION_TIMEOUT": {
        "meta": "PowerShell 版本检测超时(秒)"
    },
    "VAGRANT_PREFERRED_POWERSHELL": {
        "meta": "首选 PowerShell 路径"
    },
    "VAGRANT_PREFERRED_PROVIDERS": {
        "meta": "首选提供者列表"
    },
    "VAGRANT_PREFER_SYSTEM_BIN": {
        "meta": "优先使用系统二进制文件"
    },
    "VAGRANT_SUPPRESS_GO_EXPERIMENTAL_WARNING": {
        "meta": "抑制 Go 实验性警告"
    },
    "VAGRANT_DISABLE_WINCURL": {
        "meta": "禁用 Windows curl"
    },
    "VAGRANT_SERVER_URL": {
        "meta": "Vagrant Cloud 服务器 URL"
    },
    "VAGRANT_SERVER_ACCESS_TOKEN_BY_URL": {
        "meta": "按 URL 设置访问令牌"
    },
    "VAGRANT_SKIP_SUBPROCESS_JAILBREAK": {
        "meta": "跳过子进程隔离"
    },
    "VAGRANT_USER_AGENT_PROVISIONAL_STRING": {
        "meta": "自定义 User-Agent 字符串"
    },
    "VAGRANT_USE_VAGRANT_TRIGGERS": {
        "meta": "使用 Vagrant 触发器"
    },
    "VAGRANT_VAGRANTFILE": {
        "meta": "Vagrantfile 文件名"
    },
    "VAGRANT_WINPTY_DISABLE": {
        "meta": "禁用 winpty"
    },
}
