import os
from prompt_toolkit.validation import Validator, ValidationError


class EnvVarValidator(Validator):
    """验证输入的环境变量名是否存在
    
    检查用户输入的环境变量名是否在当前系统环境变量中存在。
    如果不存在，抛出ValidationError异常。
    """
    
    def validate(self, document):
        text = document.text
        if text and text not in os.environ:
            raise ValidationError(
                message=f"环境变量 '{text}' 不存在",
                cursor_position=len(text)
            )


class EnvVarNameValidator(Validator):
    """验证输入的环境变量名是否在提供的字典中
    
    检查用户输入的环境变量名是否在预定义的有效名称列表中。
    如果不在列表中，抛出ValidationError异常。
    """
    
    def __init__(self, valid_names):
        self.valid_names = valid_names
    
    def validate(self, document):
        text = document.text
        if text and text not in self.valid_names:
            raise ValidationError(
                message=f"环境变量名 '{text}' 不在可选列表中",
                cursor_position=len(text)
            )


class OperationValidator(Validator):
    """验证操作类型是否有效
    
    检查用户输入的操作类型是否在允许的操作列表中。
    如果不在列表中，抛出ValidationError异常并显示可用操作。
    """
    
    def __init__(self, valid_operations):
        self.valid_operations = valid_operations
    
    def validate(self, document):
        text = document.text
        if text and text not in self.valid_operations:
            raise ValidationError(
                message=f"操作 '{text}' 无效，请选择: {', '.join(self.valid_operations)}",
                cursor_position=len(text)
            )


class PathValidator(Validator):
    """验证路径是否在PATH环境变量中
    
    检查用户输入的路径是否在当前PATH环境变量的路径列表中。
    如果不在列表中，抛出ValidationError异常。
    """
    
    def __init__(self, valid_paths):
        self.valid_paths = valid_paths
    
    def validate(self, document):
        text = document.text
        if text and text not in self.valid_paths:
            raise ValidationError(
                message=f"路径 '{text}' 不在PATH中",
                cursor_position=len(text)
            )
