import fire
from envvm.envvm.envvm import ENVVM


class ENTRY(ENVVM):
    pass


def main() -> None:
    try:
        fire.Fire(ENTRY)
    except KeyboardInterrupt:
        print("\n操作已取消")
        exit(0)