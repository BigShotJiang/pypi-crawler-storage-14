# gazix

Gazix is a python framework that facilitates the interaction with the GitLab API.
