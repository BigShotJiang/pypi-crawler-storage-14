# Changelog

All notable changes to the CzechFabric SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.2] - 2025-01-27

### Fixed
- **CRITICAL**: Fixed bug where `format="tone"` (default) returned the literal string `"null"` instead of valid TONE output
- Root cause: When backend returns tone format, `result.data` is `None` and tone text is in `result.content[0].text`
- Fix: Modified `_call_tool()` to extract text from `result.content` when `result.data` is `None`
- Fix: Updated all tool methods to use new `_format_response()` helper that properly handles tone format
- All 13 tools now correctly return TONE format strings instead of `"null"`

### Testing
- Verified tone format returns valid TONE strings for all tools
- Verified JSON format still returns dicts correctly
- Verified default format (tone) works correctly
- All format combinations tested and working

## [2.0.1] - 2025-01-27

### Fixed
- Fixed missing exports in `tools/__init__.py` that prevented importing `TransportTools`, `RoutingTools`, and `AirQualityTools` directly
- Users can now import helper classes: `from czechfabric_sdk.tools import TransportTools, RoutingTools, AirQualityTools`

### Testing
- All 13 tools verified working against live MCP server
- All imports verified working
- Packaging verified correct

## [2.0.0] - 2025-01-XX

### 🎉 Stable Release - Complete Backend Mirror

This is the first stable release of CzechFabric SDK, providing a perfect 1:1 mirror of the backend system.

### Added

#### Complete Tool Coverage (13 Tools)
- **Transport Tools (9 tools)**:
  - `get_departures` - Real-time public transport departures
  - `departures_by_coordinates` - Find nearest stop and get departures
  - `suggest_departure_stops_nearby` - Suggest nearby stops with departures
  - `geocode` - Convert place/stop names to coordinates
  - `reverse_geocode` - Find nearest stop to coordinates
  - `plan_route_mapycz` - Mapy.cz route planning with step-by-step instructions
  - `find_all_stops_near` - Find all stops within radius
  - `get_stop_metadata` - Retrieve detailed stop information
  - `list_all_stops` - List all stops with optional filters

- **Air Quality Tools (4 tools)**:
  - `get_air_quality_near_location` - Current air quality near location
  - `get_air_quality_by_district` - Aggregated air quality by district
  - `get_air_quality_history` - Historical air quality data and trends
  - `list_air_quality_components` - List all measured pollutants

#### Core Features
- **Type-Safe Models**: Complete Pydantic models matching backend schemas exactly
- **Format Support**: TONE, JSON, and both formats for all tools
- **Async & Sync**: Full async support with sync wrapper (`SyncCzechFabricClient`)
- **Validation**: Input validation before API calls with proper error messages
- **Error Handling**: Comprehensive exception types (NetworkError, ValidationError, etc.)
- **Tool Discovery**: Dynamic tool listing and metadata access
- **Retry Logic**: Automatic retry with exponential backoff
- **Caching**: Optional response caching for geocoding

#### Developer Experience
- **Helper Methods**: Domain-organized tool access (`client.tools.transport`, `client.tools.air_quality`)
- **Version Compatibility**: Automatic version checking and schema drift detection
- **Strict Mode**: Optional strict mode for production environments
- **Type Hints**: Complete type annotations throughout

#### Documentation
- Complete API reference for all 13 tools
- Examples for async and sync usage
- Troubleshooting guide
- Migration guide from v1.x

### Changed

- **Breaking**: Complete SDK rebuild - all models and methods match backend exactly
- **Breaking**: Version bumped to 2.0.0 to reflect major changes
- All tool signatures updated to match backend exactly
- All response models rebuilt from backend schemas

### Fixed

- Fixed missing tools (4 tools were missing in v1.x)
- Fixed schema mismatches between SDK and backend
- Fixed format parameter handling
- Fixed coordinate validation

### Security

- Proper API key handling with BearerAuth
- Input validation prevents injection attacks
- Secure error messages (no sensitive data leakage)

### Testing

- Comprehensive test suite with 18+ tests
- All 13 tools tested with real API
- Schema parity tests
- Format handling tests
- Validation tests

### Audit Summary

- **Ground Truth Audit**: Complete audit of backend repository
- **Tool Count**: 13 tools verified (100% coverage)
- **Schema Parity**: All models match backend exactly
- **Parameter Parity**: All parameters match backend exactly
- **Format Support**: All tools support tone/json/both

### Known Limitations

1. **Air Quality Tools Return Dicts**: Air quality tools return plain dicts, not Pydantic models (matches backend behavior)
2. **Sync Client Limitation**: Sync client cannot be used from async context (creates new event loop)
3. **Version Checking**: Version checking relies on tool count as proxy (backend should expose `/version` endpoint)

### Migration from v1.x

If upgrading from v1.x:

1. Update imports - all models now in `czechfabric_sdk.models`
2. Update method calls - some method names changed to match backend
3. Add format parameter - all tools now support `format` parameter
4. Use TransportMode enum - replace string modes with `TransportMode.METRO`, etc.

Example migration:
```python
# Old (v1.x)
result = await client.get_departures("Anděl")

# New (v2.0.0)
result = await client.get_departures(
    "Anděl",
    when="now",
    mode=TransportMode.METRO,
    format="json"
)
```

---

## Version History

- **v2.0.0** (2025-01-XX) - Stable release, complete backend mirror
- **v1.x** - Legacy versions (deprecated)

---

## Versioning Policy

- **Major** (X.0.0): Breaking changes, incompatible API changes
- **Minor** (0.X.0): New tools, new features, backward compatible
- **Patch** (0.0.X): Bug fixes, backward compatible

---

## Support

- **Documentation**: https://czechfabric.cz/docs/sdk
- **Issues**: https://github.com/czechfabric/czechfabric-sdk/issues
- **Email**: support@czechfabric.cz
