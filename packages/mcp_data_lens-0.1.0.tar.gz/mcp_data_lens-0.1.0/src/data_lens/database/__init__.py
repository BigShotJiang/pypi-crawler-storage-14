from .client import DuckDBClient

__all__ = ["DuckDBClient"]
