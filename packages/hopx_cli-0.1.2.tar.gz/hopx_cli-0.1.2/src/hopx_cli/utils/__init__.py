"""Utility functions and helpers for the Hopx CLI."""
