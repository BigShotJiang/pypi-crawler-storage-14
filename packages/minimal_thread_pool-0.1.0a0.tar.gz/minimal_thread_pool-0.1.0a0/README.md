# minimal-thread-pool

A minimal Python 2+ thread pool designed for clarity, without reliance on `concurrent.futures`.

## Features

- **Explicit:** If any submitted job raises an exception, the corresponding worker thread terminates loudly.
- **Easy lifecycle:** Add tasks, then call `.join()` to wait for completion. Pull results as soon as they are ready.

## Installation

```bash
pip install minimal-thread-pool
```

## Usage

```python
from __future__ import print_function
import time
import random
from minimal_thread_pool import MinimalThreadPool


def slow_square(x):
    time.sleep(random.randint(1, 10))
    return x * x


pool = MinimalThreadPool(num_threads=2)
for i in range(10):
    # def add_task(self, func, *args, **kwargs)
    pool.add_task(slow_square, i)

# Retrieve results (order not guaranteed)
for thread_index, result in pool.results():
    print('Worker %d returned %s' % (thread_index, result))

# Wait for all tasks
pool.join()
```

## Contributing

Contributions are welcome! Please submit pull requests or open issues on the GitHub repository.

## License

This project is licensed under the [MIT License](LICENSE).