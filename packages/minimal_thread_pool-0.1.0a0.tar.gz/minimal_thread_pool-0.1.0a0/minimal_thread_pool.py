# Copyright (c) 2025 Jifeng Wu
# Licensed under the MIT License. See LICENSE file in the project root for full license information.
import sys

if sys.version_info < (3,):
    from Queue import Queue
else:
    from queue import Queue
from threading import Thread
from typing import Callable, Tuple, List, Iterator, TypeVar

R = TypeVar('R')


class MinimalThreadPool:
    def __init__(
            self,
            num_threads,  # type: int
    ):
        self.task_queue = Queue()  # type: Queue
        self.result_queue = Queue()  # type: Queue
        self.closed = False
        self.total_tasks_submitted = 0
        self.total_tasks_completed = 0
        self.threads = []  # type: List[Thread]
        for i in range(num_threads):
            t = Thread(target=self.worker, args=(i,))
            t.daemon = True
            t.start()
            self.threads.append(t)

    def worker(
            self,
            thread_index,  # type: int
    ):
        while True:
            task = self.task_queue.get()
            if task is None:
                self.task_queue.task_done()
                break
            func, args, kwargs = task
            result = func(*args, **kwargs)
            self.result_queue.put((thread_index, result))
            self.task_queue.task_done()

    def add_task(
            self,
            func,  # type: Callable[..., R]
            *args,
            **kwargs
    ):
        if self.closed:
            raise RuntimeError('Cannot add task to closed ThreadPool')
        self.total_tasks_submitted += 1
        self.task_queue.put((func, args, kwargs))

    def join(self):
        """Wait until all scheduled tasks are done."""
        self.task_queue.join()

    def results(self):
        # type: (...) -> Iterator[Tuple[int, R]]
        """Yields results as soon as they are available. Yields one result per completed task."""
        while self.total_tasks_completed < self.total_tasks_submitted:
            thread_index, result = self.result_queue.get()
            self.total_tasks_completed += 1
            yield thread_index, result
