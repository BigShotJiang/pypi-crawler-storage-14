"""Integration tests for metaphor_machine package."""
