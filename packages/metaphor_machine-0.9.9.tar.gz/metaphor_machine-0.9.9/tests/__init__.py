"""Metaphor Machine test suite."""
