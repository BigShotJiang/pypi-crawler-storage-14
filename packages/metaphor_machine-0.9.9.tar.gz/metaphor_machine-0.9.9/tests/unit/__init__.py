"""Unit tests for metaphor_machine package."""
