"""Command-line interface for the Metaphor Machine."""

from metaphor_machine.cli.main import cli, main

__all__ = ["cli", "main"]
