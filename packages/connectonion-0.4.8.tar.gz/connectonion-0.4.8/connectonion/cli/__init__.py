"""ConnectOnion CLI module."""

__version__ = "0.0.1b5"