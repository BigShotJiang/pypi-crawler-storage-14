"""
SQLite-based registry for dataset metadata and versioning.

Stores:
- Dataset definitions
- Version manifests
- Resource metadata
- Embedding spaces
"""
import json
import os
import sqlite3
from pathlib import Path
from typing import Optional, Dict, Any, List
from contextlib import contextmanager

from .config import get_config
from .utils import ensure_dir


class Registry:
    """
    Local SQLite registry for dataset management.
    """

    def __init__(self, db_path: Optional[Path] = None):
        """
        Initialize registry.

        Args:
            db_path: Path to SQLite database (uses config if not provided)
        """
        if db_path is None:
            db_path = get_config().registry_db

        self.db_path = db_path

        # Ensure parent directory exists
        ensure_dir(self.db_path.parent)

        # Initialize database
        self._init_db()

    def _init_db(self):
        """Initialize database schema."""
        with self._connect() as conn:
            # Skip initialization if database is read-only
            try:
                # Enable WAL mode for better concurrency
                conn.execute("PRAGMA journal_mode=WAL")

                # Datasets table
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS datasets (
                        workspace TEXT NOT NULL,
                        name TEXT NOT NULL,
                        latest_version TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (workspace, name)
                    )
                    """
                )

                # Versions table
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS versions (
                        workspace TEXT NOT NULL,
                        name TEXT NOT NULL,
                        version_hash TEXT NOT NULL,
                        manifest_json TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (workspace, name, version_hash),
                        FOREIGN KEY (workspace, name) REFERENCES datasets(workspace, name)
                    )
                    """
                )

                # Resources table (files that make up a dataset version)
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS resources (
                        workspace TEXT NOT NULL,
                        name TEXT NOT NULL,
                        version_hash TEXT NOT NULL,
                        uri TEXT NOT NULL,
                        checksum TEXT,
                        size INTEGER,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (workspace, name, version_hash)
                            REFERENCES versions(workspace, name, version_hash)
                    )
                    """
                )

                # Embeddings spaces table
                conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS embeddings_spaces (
                        workspace TEXT NOT NULL,
                        name TEXT NOT NULL,
                        version_hash TEXT NOT NULL,
                        space_name TEXT NOT NULL,
                        provider TEXT NOT NULL,
                        model TEXT NOT NULL,
                        dimension INTEGER NOT NULL,
                        distance_metric TEXT DEFAULT 'cosine',
                        storage_path TEXT NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        PRIMARY KEY (workspace, name, version_hash, space_name),
                        FOREIGN KEY (workspace, name, version_hash)
                            REFERENCES versions(workspace, name, version_hash)
                    )
                    """
                )

                conn.commit()

                # Run migrations to latest version
                from ..migrations import migrate
                migrate(conn)

            except sqlite3.OperationalError:
                # Read-only database - skip schema initialization
                pass

    @contextmanager
    def _connect(self):
        """Context manager for database connections."""
        # Check if database exists and is read-only
        if self.db_path.exists() and not os.access(self.db_path, os.W_OK):
            # Open in read-only mode
            conn = sqlite3.connect(f"file:{self.db_path}?mode=ro", uri=True)
        else:
            # Normal read-write mode (will create if doesn't exist)
            conn = sqlite3.connect(str(self.db_path))

        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    def register_dataset(
        self,
        workspace: str,
        name: str,
        version_hash: str,
        manifest: Dict[str, Any],
        parent_workspace: Optional[str] = None,
        parent_name: Optional[str] = None,
        dataset_type: str = "main"
    ) -> str:
        """
        Register a new dataset version.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Content-based version hash
            manifest: Version manifest (schema, resources, etc.)
            parent_workspace: Parent workspace name (for subdatasets)
            parent_name: Parent dataset name (for subdatasets)
            dataset_type: Dataset type ("main" or "subdataset")

        Returns:
            Version hash
        """
        with self._connect() as conn:
            # Insert or update dataset
            conn.execute(
                """
                INSERT INTO datasets (workspace, name, latest_version, updated_at,
                                     parent_workspace, parent_name, dataset_type)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?)
                ON CONFLICT(workspace, name) DO UPDATE SET
                    latest_version = excluded.latest_version,
                    updated_at = CURRENT_TIMESTAMP,
                    parent_workspace = excluded.parent_workspace,
                    parent_name = excluded.parent_name,
                    dataset_type = excluded.dataset_type
                """,
                (workspace, name, version_hash, parent_workspace, parent_name, dataset_type),
            )

            # Insert version
            manifest_json = json.dumps(manifest)
            conn.execute(
                """
                INSERT OR REPLACE INTO versions (workspace, name, version_hash, manifest_json)
                VALUES (?, ?, ?, ?)
                """,
                (workspace, name, version_hash, manifest_json),
            )

            # Insert resources
            for resource in manifest.get("resources", []):
                conn.execute(
                    """
                    INSERT OR REPLACE INTO resources (workspace, name, version_hash, uri, checksum, size)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        workspace,
                        name,
                        version_hash,
                        resource["uri"],
                        resource.get("checksum"),
                        resource.get("size"),
                    ),
                )

            conn.commit()

        return version_hash

    def get_dataset_version(
        self, workspace: str, name: str, version: str = "latest"
    ) -> Optional[Dict[str, Any]]:
        """
        Get information about a dataset version.

        Args:
            workspace: Workspace name
            name: Dataset name
            version: Version (hash or 'latest')

        Returns:
            Dataset version info, or None if not found
        """
        with self._connect() as conn:
            if version == "latest":
                # Get latest version
                row = conn.execute(
                    """
                    SELECT latest_version as version_hash, created_at, updated_at
                    FROM datasets
                    WHERE workspace = ? AND name = ?
                    """,
                    (workspace, name),
                ).fetchone()
            else:
                # Get specific version
                row = conn.execute(
                    """
                    SELECT version_hash, created_at
                    FROM versions
                    WHERE workspace = ? AND name = ? AND version_hash = ?
                    """,
                    (workspace, name, version),
                ).fetchone()

            if row is None:
                return None

            return dict(row)

    def get_manifest(
        self, workspace: str, name: str, version_hash: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get the manifest for a dataset version.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Version hash

        Returns:
            Manifest dictionary, or None if not found
        """
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT manifest_json
                FROM versions
                WHERE workspace = ? AND name = ? AND version_hash = ?
                """,
                (workspace, name, version_hash),
            ).fetchone()

            if row is None:
                return None

            return json.loads(row["manifest_json"])

    def list_datasets(self, workspace: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all registered datasets.

        Args:
            workspace: Filter by workspace (optional)

        Returns:
            List of dataset info dictionaries
        """
        with self._connect() as conn:
            if workspace:
                rows = conn.execute(
                    """
                    SELECT workspace, name, latest_version, created_at, updated_at
                    FROM datasets
                    WHERE workspace = ?
                    ORDER BY workspace, name
                    """,
                    (workspace,),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT workspace, name, latest_version, created_at, updated_at
                    FROM datasets
                    ORDER BY workspace, name
                    """
                ).fetchall()

            return [dict(row) for row in rows]

    def list_subdatasets(self, workspace: str, name: str) -> List[Dict[str, Any]]:
        """
        List all subdatasets of a given dataset.

        Args:
            workspace: Parent workspace name
            name: Parent dataset name

        Returns:
            List of subdataset info dictionaries with schema and description
        """
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT d.workspace, d.name, d.latest_version, d.created_at, d.updated_at,
                       d.dataset_type
                FROM datasets d
                WHERE d.parent_workspace = ? AND d.parent_name = ?
                ORDER BY d.name
                """,
                (workspace, name),
            ).fetchall()

            subdatasets = []
            for row in rows:
                subdataset_info = dict(row)

                # Get manifest for schema and metadata
                if row["latest_version"]:
                    manifest = self.get_manifest(
                        row["workspace"], row["name"], row["latest_version"]
                    )
                    if manifest:
                        subdataset_info["schema"] = manifest.get("schema", {})
                        subdataset_info["description"] = manifest.get("metadata", {}).get("description", "")

                subdatasets.append(subdataset_info)

            return subdatasets

    def remove_dataset(self, workspace: str, name: str, version_hash: Optional[str] = None):
        """
        Remove a dataset or specific version from the registry.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Optional version to remove (removes all if not specified)
        """
        with self._connect() as conn:
            if version_hash:
                # Remove specific version
                conn.execute(
                    "DELETE FROM versions WHERE workspace = ? AND name = ? AND version_hash = ?",
                    (workspace, name, version_hash)
                )

                # Check if there are other versions
                remaining = conn.execute(
                    "SELECT COUNT(*) as count FROM versions WHERE workspace = ? AND name = ?",
                    (workspace, name)
                ).fetchone()

                if remaining["count"] == 0:
                    # No more versions, remove dataset entry
                    conn.execute(
                        "DELETE FROM datasets WHERE workspace = ? AND name = ?",
                        (workspace, name)
                    )
                else:
                    # Update latest_version to most recent remaining version
                    latest = conn.execute(
                        """
                        SELECT version_hash FROM versions
                        WHERE workspace = ? AND name = ?
                        ORDER BY created_at DESC LIMIT 1
                        """,
                        (workspace, name)
                    ).fetchone()

                    if latest:
                        conn.execute(
                            """
                            UPDATE datasets
                            SET latest_version = ?, updated_at = CURRENT_TIMESTAMP
                            WHERE workspace = ? AND name = ?
                            """,
                            (latest["version_hash"], workspace, name)
                        )
            else:
                # Remove all versions
                conn.execute(
                    "DELETE FROM versions WHERE workspace = ? AND name = ?",
                    (workspace, name)
                )
                conn.execute(
                    "DELETE FROM datasets WHERE workspace = ? AND name = ?",
                    (workspace, name)
                )

            conn.commit()

    def register_embedding_space(
        self,
        workspace: str,
        name: str,
        version_hash: str,
        space_name: str,
        provider: str,
        model: str,
        dimension: int,
        distance_metric: str,
        storage_path: str,
    ):
        """
        Register an embedding space for a dataset version.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Version hash
            space_name: Embedding space name
            provider: Provider name
            model: Model name
            dimension: Vector dimension
            distance_metric: Distance metric
            storage_path: Path to embedding storage
        """
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO embeddings_spaces
                (workspace, name, version_hash, space_name, provider, model, dimension, distance_metric, storage_path)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    workspace,
                    name,
                    version_hash,
                    space_name,
                    provider,
                    model,
                    dimension,
                    distance_metric,
                    storage_path,
                ),
            )
            conn.commit()

    def list_embedding_spaces(
        self, workspace: str, name: str, version_hash: str
    ) -> List[Dict[str, Any]]:
        """
        List all embedding spaces for a dataset version.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Version hash

        Returns:
            List of embedding space info dictionaries
        """
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT space_name, provider, model, dimension, distance_metric, storage_path, created_at
                FROM embeddings_spaces
                WHERE workspace = ? AND name = ? AND version_hash = ?
                ORDER BY created_at
                """,
                (workspace, name, version_hash),
            ).fetchall()

            return [dict(row) for row in rows]

    def list_embedding_spaces_for_dataset(
        self, workspace: str, name: str
    ) -> List[Dict[str, Any]]:
        """
        List embedding spaces across all versions for a dataset.

        Returns entries including the version_hash for each space.
        """
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT version_hash, space_name, provider, model, dimension, distance_metric, storage_path, created_at
                FROM embeddings_spaces
                WHERE workspace = ? AND name = ?
                ORDER BY created_at
                """,
                (workspace, name),
            ).fetchall()

            return [dict(row) for row in rows]

    def get_embedding_space(
        self, workspace: str, name: str, version_hash: str, space_name: str
    ) -> Optional[Dict[str, Any]]:
        """Get a single embedding space row."""
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT space_name, provider, model, dimension, distance_metric, storage_path, created_at
                FROM embeddings_spaces
                WHERE workspace = ? AND name = ? AND version_hash = ? AND space_name = ?
                LIMIT 1
                """,
                (workspace, name, version_hash, space_name),
            ).fetchone()
            return dict(row) if row else None

    def remove_embedding_space(
        self, workspace: str, name: str, version_hash: str, space_name: str
    ) -> None:
        """Delete an embedding space registration for a dataset version."""
        with self._connect() as conn:
            conn.execute(
                """
                DELETE FROM embeddings_spaces
                WHERE workspace = ? AND name = ? AND version_hash = ? AND space_name = ?
                """,
                (workspace, name, version_hash, space_name),
            )
            conn.commit()

    def register_raw_data_source(
        self,
        workspace: str,
        name: str,
        version_hash: str,
        source_type: str,
        source_path: str,
        content_hash: Optional[str] = None,
        size: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Register a raw data source for a dataset version.

        Deduplicates by source_path - if the same path is already registered
        for this dataset version, it will be skipped.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Version hash
            source_type: Type of source (e.g., 'pdf', 'sqlite', 'csv', 'directory')
            source_path: Path to source file/directory
            content_hash: Content hash (SHA256)
            size: Size in bytes
            metadata: Additional metadata
        """
        with self._connect() as conn:
            # Check if this source already exists for this dataset version
            existing = conn.execute(
                """
                SELECT 1 FROM raw_data_sources
                WHERE workspace = ? AND name = ? AND version_hash = ? AND source_path = ?
                """,
                (workspace, name, version_hash, source_path),
            ).fetchone()

            if existing:
                # Already registered, skip
                return

            conn.execute(
                """
                INSERT INTO raw_data_sources
                (workspace, name, version_hash, source_type, source_path, content_hash, size, metadata_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    workspace,
                    name,
                    version_hash,
                    source_type,
                    source_path,
                    content_hash,
                    size,
                    json.dumps(metadata) if metadata else None,
                ),
            )
            conn.commit()

    def list_raw_data_sources(
        self, workspace: str, name: str, version_hash: str
    ) -> List[Dict[str, Any]]:
        """
        List raw data sources for a dataset version.

        Args:
            workspace: Workspace name
            name: Dataset name
            version_hash: Version hash

        Returns:
            List of raw data source info dictionaries
        """
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT source_type, source_path, content_hash, size, metadata_json, created_at
                FROM raw_data_sources
                WHERE workspace = ? AND name = ? AND version_hash = ?
                ORDER BY created_at
                """,
                (workspace, name, version_hash),
            ).fetchall()

            results = []
            for row in rows:
                d = dict(row)
                if d.get("metadata_json"):
                    d["metadata"] = json.loads(d["metadata_json"])
                    del d["metadata_json"]
                results.append(d)
            return results


# Global registry instance
_global_registry: Optional[Registry] = None


def get_registry() -> Registry:
    """
    Get the global registry instance.

    Returns:
        Registry instance
    """
    global _global_registry

    if _global_registry is None:
        _global_registry = Registry()

    return _global_registry


def reset_registry():
    """Reset the global registry (useful for testing)."""
    global _global_registry
    _global_registry = None
