"""
ArXiv Populate Recipe.

Unified recipe for populating arXiv paper datasets with:
- Smart paper selection (per-year quotas, category weights)
- PDF download with rate limiting
- Text extraction
- Incremental updates with proper merging
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Optional

import pandas as pd
from tqdm import tqdm

from ...api.recipes import RecipeContext
from ..base import RecipeOutput
from .api import ArxivAPI, ArxivPaper, DEFAULT_PROXY_FILE
from .api_oai import OAIHarvester, harvest_papers
from .selection import SelectionConfig, select_papers, DEFAULT_CATEGORY_WEIGHTS
from .download import PDFDownloader, compute_sha1
from .extract import extract_text_from_pdf, analyze_content


def arxiv_populate(
    ctx: RecipeContext,
    papers_per_year: int = 500,
    years: Optional[list[int]] = None,
    category_weights: Optional[dict[str, float]] = None,
    download_pdfs: bool = True,
    extract_text: bool = True,
    max_pages: Optional[int] = None,
    pdf_cache_dir: Optional[str] = None,
    merge_existing: bool = True,
    proxy_file: Optional[str] = None,
    use_proxy: bool = True,
    workers: int = 1,
    use_oai: bool = True,
) -> RecipeOutput:
    """
    Populate arXiv dataset with papers.

    Fetches papers from arXiv (using OAI-PMH for bulk or Search API),
    downloads PDFs, extracts text, and merges with existing dataset.

    Args:
        ctx: Recipe context
        papers_per_year: Target number of papers per year
        years: Years to fetch (default: [2020, 2021, 2022, 2023, 2024])
        category_weights: Category -> weight mapping for distribution
                         (default: DEFAULT_CATEGORY_WEIGHTS focused on ML/AI)
        download_pdfs: Whether to download PDFs
        extract_text: Whether to extract text from PDFs
        max_pages: Max pages to extract per PDF (None = all)
        pdf_cache_dir: Directory to cache PDFs (default: ctx.work_dir/pdfs)
        merge_existing: Whether to merge with existing dataset
        proxy_file: Path to proxy credentials file (default: scripts/proxy_credentials.txt)
        use_proxy: Whether to use proxy (default: True)
        workers: Number of parallel workers for PDF download/extraction (default: 1)
        use_oai: Use OAI-PMH API for bulk harvesting (default: True, recommended)
                 Set to False to use Search API (slower, more rate-limited)

    Returns:
        RecipeOutput with papers dataset

    Example:
        >>> import warpdata as wd
        >>> wd.run_recipe(
        ...     "arxiv_populate",
        ...     "warpdata://arxiv/papers",
        ...     papers_per_year=500,
        ...     years=[2023, 2024, 2025],
        ...     workers=4,
        ... )
    """
    # Parse years if passed as string from CLI (e.g., "[2023,2024,2025]")
    if years is None:
        years = [2020, 2021, 2022, 2023, 2024]
    elif isinstance(years, str):
        import json
        try:
            years = json.loads(years)
        except json.JSONDecodeError:
            # Try eval as fallback for simple lists
            years = eval(years)

    if category_weights is None:
        category_weights = DEFAULT_CATEGORY_WEIGHTS.copy()
    elif isinstance(category_weights, str):
        import json
        try:
            category_weights = json.loads(category_weights)
        except json.JSONDecodeError:
            category_weights = eval(category_weights)

    pdf_dir = Path(pdf_cache_dir) if pdf_cache_dir else ctx.work_dir / "pdfs"
    pdf_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("ArXiv Populate")
    print("=" * 70)
    print(f"  Papers per year: {papers_per_year}")
    print(f"  Years: {years}")
    print(f"  Categories: {len(category_weights)}")
    print(f"  Download PDFs: {download_pdfs}")
    print(f"  Extract text: {extract_text}")
    print(f"  Workers: {workers}")
    print(f"  Proxy: {use_proxy}")
    print(f"  API: {'OAI-PMH (bulk)' if use_oai else 'Search API'}")
    print("=" * 70)

    # Load existing dataset for incremental updates
    existing_df: Optional[pd.DataFrame] = None
    existing_ids: set[str] = set()

    if merge_existing:
        try:
            import warpdata as wd
            existing_df = wd.load(str(ctx.uri), as_format="pandas")
            existing_ids = set(existing_df["arxiv_id"].dropna().unique())
            print(f"\n[0] Loaded existing dataset: {len(existing_df)} papers")
            print(f"    Existing IDs to skip: {len(existing_ids)}")
        except Exception:
            print("\n[0] No existing dataset found (fresh start)")

    # Step 1: Select papers from arXiv API
    if use_oai:
        print(f"\n[1/3] Harvesting papers via OAI-PMH (bulk)...")
        papers = harvest_papers(
            years=years,
            papers_per_year=papers_per_year,
            category_weights=category_weights,
            proxy_file=proxy_file,
            use_proxy=use_proxy,
            existing_ids=existing_ids,
            progress=True,
        )
    else:
        print(f"\n[1/3] Selecting papers from Search API...")
        config = SelectionConfig(
            papers_per_year=papers_per_year,
            years=years,
            category_weights=category_weights,
            existing_ids=existing_ids,
        )
        api = ArxivAPI(proxy_file=proxy_file, use_proxy=use_proxy)
        papers = select_papers(config, api=api, progress=True)

    print(f"    Selected {len(papers)} new papers")

    if not papers:
        print("\n⚠️  No new papers to process")
        if existing_df is not None:
            # Return existing dataset
            out_path = ctx.work_dir / "papers.parquet"
            rel = ctx.engine.conn.from_df(existing_df)
            ctx.write_parquet(rel, out_path)
            return RecipeOutput(
                main=[out_path],
                subdatasets={},
                docs={"README.md": "# ArXiv Papers\n\nNo new papers to add.\n"},
                metadata={"total_papers": len(existing_df), "new_papers": 0},
            )
        else:
            # Empty dataset
            empty_df = pd.DataFrame({"arxiv_id": []})
            out_path = ctx.work_dir / "papers.parquet"
            rel = ctx.engine.conn.from_df(empty_df)
            ctx.write_parquet(rel, out_path)
            return RecipeOutput(
                main=[out_path],
                subdatasets={},
                docs={"README.md": "# ArXiv Papers\n\nNo papers found.\n"},
                metadata={"total_papers": 0, "new_papers": 0},
            )

    # Step 2: Download PDFs and extract text
    print(f"\n[2/3] Processing papers (download={download_pdfs}, extract={extract_text}, workers={workers})...")

    # Create PDF downloader with proxy support
    downloader = None
    if download_pdfs:
        downloader = PDFDownloader(
            proxy_file=proxy_file,
            use_proxy=use_proxy,
        )

    def process_paper(paper: ArxivPaper) -> dict:
        """Process a single paper: download PDF and extract text."""
        row = paper.to_dict()
        row["pdf_path"] = None
        row["pdf_sha1"] = None
        row["full_content"] = None
        row["content_length"] = 0
        row["has_full_content"] = False
        row["extraction_method"] = None
        row["extraction_error"] = None
        row["extraction_timestamp"] = None
        row["has_equations"] = None
        row["has_figures"] = None
        row["has_tables"] = None
        row["has_code"] = None

        if download_pdfs and downloader:
            result = downloader.download(paper, pdf_dir)
            if result:
                pdf_path, pdf_sha1 = result
                row["pdf_path"] = str(pdf_path)
                row["pdf_sha1"] = pdf_sha1

                if extract_text:
                    text, error = extract_text_from_pdf(pdf_path, max_pages=max_pages)
                    row["extraction_timestamp"] = datetime.now().isoformat()

                    if text:
                        row["full_content"] = text
                        row["content_length"] = len(text)
                        row["has_full_content"] = True
                        row["extraction_method"] = "fast-text"

                        # Analyze content
                        features = analyze_content(text)
                        row.update(features)

        return row

    rows: list[dict] = []
    success_count = 0
    failed_count = 0

    if workers <= 1:
        # Sequential processing
        for paper in tqdm(papers, desc="Processing", unit="paper"):
            row = process_paper(paper)
            rows.append(row)
            if row.get("has_full_content") or (not download_pdfs) or (download_pdfs and not extract_text and row.get("pdf_sha1")):
                success_count += 1
            else:
                failed_count += 1
    else:
        # Parallel processing
        from concurrent.futures import ThreadPoolExecutor, as_completed

        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(process_paper, p): p for p in papers}

            with tqdm(total=len(papers), desc="Processing", unit="paper") as pbar:
                for future in as_completed(futures):
                    row = future.result()
                    rows.append(row)
                    if row.get("has_full_content") or (not download_pdfs) or (download_pdfs and not extract_text and row.get("pdf_sha1")):
                        success_count += 1
                    else:
                        failed_count += 1
                    pbar.update(1)

    print(f"    Processed: {success_count} success, {failed_count} failed")

    # Step 3: Merge with existing dataset
    print(f"\n[3/3] Building final dataset...")

    new_df = pd.DataFrame(rows)

    if merge_existing and existing_df is not None:
        # Ensure schema compatibility
        for col in new_df.columns:
            if col not in existing_df.columns:
                existing_df[col] = None
        for col in existing_df.columns:
            if col not in new_df.columns:
                new_df[col] = None

        # Merge (new papers first, then existing)
        final_df = pd.concat([new_df, existing_df], ignore_index=True)

        # Dedupe by arxiv_id (keep first = new)
        final_df = final_df.drop_duplicates(subset=["arxiv_id"], keep="first")
        print(f"    Merged: {len(new_df)} new + {len(existing_df)} existing = {len(final_df)} total")
    else:
        final_df = new_df
        print(f"    Total papers: {len(final_df)}")

    # Sort by year/month descending
    if "year" in final_df.columns:
        final_df = final_df.sort_values(["year", "month"], ascending=[False, False])

    # Write output
    out_path = ctx.work_dir / "papers.parquet"
    rel = ctx.engine.conn.from_df(final_df)
    ctx.write_parquet(rel, out_path)

    # Generate stats
    stats = _compute_stats(final_df)

    readme = _generate_readme(
        stats=stats,
        papers_per_year=papers_per_year,
        years=years,
        category_weights=category_weights,
        download_pdfs=download_pdfs,
        extract_text=extract_text,
        new_papers=len(new_df),
        ctx_uri=str(ctx.uri),
    )

    print("\n" + "=" * 70)
    print("✅ ArXiv Populate Complete!")
    print(f"   Total papers: {len(final_df)}")
    print(f"   New papers: {len(new_df)}")
    if extract_text:
        print(f"   With text: {stats['with_text']}")
    print("=" * 70)

    return RecipeOutput(
        main=[out_path],
        subdatasets={},
        docs={"README.md": readme},
        metadata={
            "total_papers": len(final_df),
            "new_papers": len(new_df),
            "papers_per_year": papers_per_year,
            "years": years,
            "categories": list(category_weights.keys()),
            "download_pdfs": download_pdfs,
            "extract_text": extract_text,
            **stats,
        },
    )


def _compute_stats(df: pd.DataFrame) -> dict:
    """Compute statistics from DataFrame."""
    stats = {
        "total": len(df),
        "with_text": 0,
        "with_equations": 0,
        "with_figures": 0,
        "with_tables": 0,
        "with_code": 0,
        "avg_content_length": 0,
        "category_counts": {},
        "year_counts": {},
    }

    if len(df) == 0:
        return stats

    if "has_full_content" in df.columns:
        stats["with_text"] = int(df["has_full_content"].sum())

    if "has_equations" in df.columns:
        stats["with_equations"] = int(df["has_equations"].astype(bool).fillna(False).sum())
    if "has_figures" in df.columns:
        stats["with_figures"] = int(df["has_figures"].astype(bool).fillna(False).sum())
    if "has_tables" in df.columns:
        stats["with_tables"] = int(df["has_tables"].astype(bool).fillna(False).sum())
    if "has_code" in df.columns:
        stats["has_code"] = int(df["has_code"].astype(bool).fillna(False).sum())

    if "content_length" in df.columns and stats["with_text"] > 0:
        text_df = df[df["has_full_content"] == True]
        stats["avg_content_length"] = int(text_df["content_length"].mean())

    if "primary_category" in df.columns:
        stats["category_counts"] = df["primary_category"].value_counts().to_dict()

    if "year" in df.columns:
        stats["year_counts"] = df["year"].value_counts().to_dict()

    return stats


def _generate_readme(
    stats: dict,
    papers_per_year: int,
    years: list[int],
    category_weights: dict[str, float],
    download_pdfs: bool,
    extract_text: bool,
    new_papers: int,
    ctx_uri: str,
) -> str:
    """Generate README documentation."""
    readme = f"""# ArXiv Papers Dataset

## Overview
Curated arXiv papers with metadata, PDFs, and extracted text.

## Statistics
- **Total papers**: {stats['total']}
- **New papers added**: {new_papers}
- **With extracted text**: {stats['with_text']}
- **Average content length**: {stats['avg_content_length']:,} chars
- **With equations**: {stats['with_equations']}
- **With figures**: {stats['with_figures']}
- **With tables**: {stats['with_tables']}

## Configuration
- **Papers per year**: {papers_per_year}
- **Years**: {years}
- **Download PDFs**: {download_pdfs}
- **Extract text**: {extract_text}

## Category Distribution
Target weights:
"""

    for cat, weight in sorted(category_weights.items(), key=lambda x: -x[1])[:15]:
        readme += f"- **{cat}**: {weight:.1%}\n"

    readme += "\n## Actual Distribution (by primary category)\n"
    for cat, count in sorted(stats.get("category_counts", {}).items(), key=lambda x: -x[1])[:15]:
        readme += f"- **{cat}**: {count} papers\n"

    readme += "\n## Papers by Year\n"
    for year, count in sorted(stats.get("year_counts", {}).items(), reverse=True):
        readme += f"- **{year}**: {count} papers\n"

    readme += f"""
## Schema
- `arxiv_id`: arXiv identifier (e.g., "2301.12345")
- `title`: Paper title
- `abstract`: Paper abstract
- `authors`: List of author names
- `categories`: List of arXiv categories
- `primary_category`: Main category
- `published`: Publication date (ISO format)
- `updated`: Last update date
- `year`, `month`: Extracted from published date
- `pdf_url`: URL to PDF
- `abs_url`: URL to abstract page
- `doi`: DOI if available
- `journal_ref`: Journal reference if available
- `pdf_path`: Local path to downloaded PDF
- `pdf_sha1`: SHA1 hash of PDF
- `full_content`: Extracted text content
- `content_length`: Character count
- `has_full_content`: True if text extracted
- `has_equations`, `has_figures`, `has_tables`, `has_code`: Content flags

## Usage

```python
import warpdata as wd

# Load dataset
papers = wd.load("{ctx_uri}", as_format="pandas")
print(f"Total papers: {{len(papers)}}")

# Filter by category
ml_papers = papers[papers["primary_category"] == "cs.LG"]
print(f"ML papers: {{len(ml_papers)}}")

# Filter by year
recent = papers[papers["year"] >= 2023]
print(f"Recent papers: {{len(recent)}}")

# Get papers with text
with_text = papers[papers["has_full_content"]]
print(f"With text: {{len(with_text)}}")
```

## Incremental Updates
Run the recipe again to add new papers:
```python
wd.run_recipe(
    "arxiv_populate",
    "{ctx_uri}",
    papers_per_year=100,
    years=[2024],  # Only fetch 2024
)
```
"""

    return readme
