"""
Paper selection strategies.

Implements smart paper selection with:
- Per-year quotas
- Category weights for balanced distribution
- Deduplication
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from tqdm import tqdm

from .api import ArxivAPI, ArxivPaper

# Default category weights (sum to 1.0)
# Focused on ML/AI, NLP, CV, Math, and related fields
DEFAULT_CATEGORY_WEIGHTS: dict[str, float] = {
    # Machine Learning & AI
    "cs.LG": 0.15,   # Machine Learning
    "cs.AI": 0.08,   # Artificial Intelligence
    "stat.ML": 0.08,  # Statistics - Machine Learning

    # NLP & Language
    "cs.CL": 0.12,   # Computation and Language

    # Computer Vision
    "cs.CV": 0.12,   # Computer Vision

    # Math (relevant to ML)
    "math.OC": 0.05,  # Optimization and Control
    "math.ST": 0.05,  # Statistics Theory
    "math.PR": 0.03,  # Probability

    # Neural/Cognitive
    "cs.NE": 0.05,   # Neural and Evolutionary Computing
    "q-bio.NC": 0.02,  # Neurons and Cognition

    # Information Theory & Crypto
    "cs.IT": 0.04,   # Information Theory
    "cs.CR": 0.03,   # Cryptography

    # Robotics & Systems
    "cs.RO": 0.04,   # Robotics
    "cs.SY": 0.03,   # Systems and Control

    # Other CS
    "cs.DS": 0.03,   # Data Structures and Algorithms
    "cs.IR": 0.03,   # Information Retrieval

    # Physics (ML applications)
    "physics.comp-ph": 0.02,  # Computational Physics
    "quant-ph": 0.03,  # Quantum Physics
}


@dataclass
class SelectionConfig:
    """Configuration for paper selection."""
    papers_per_year: int = 500
    years: list[int] = None
    category_weights: dict[str, float] = None
    existing_ids: set[str] = None  # IDs to skip (for incremental updates)
    sort_by: str = "submittedDate"  # submittedDate, relevance
    sort_order: str = "descending"

    def __post_init__(self):
        if self.years is None:
            self.years = [2020, 2021, 2022, 2023, 2024]
        if self.category_weights is None:
            self.category_weights = DEFAULT_CATEGORY_WEIGHTS.copy()
        if self.existing_ids is None:
            self.existing_ids = set()


def _normalize_weights(weights: dict[str, float]) -> dict[str, float]:
    """Normalize weights to sum to 1.0."""
    total = sum(weights.values())
    if total == 0:
        return weights
    return {k: v / total for k, v in weights.items()}


def select_papers(
    config: SelectionConfig,
    api: Optional[ArxivAPI] = None,
    progress: bool = True,
) -> list[ArxivPaper]:
    """
    Select papers according to configuration.

    Uses category weights to distribute papers proportionally.
    For each year, fetches papers from each category proportionally to its weight.

    Args:
        config: Selection configuration
        api: ArxivAPI instance (created if not provided)
        progress: Show progress bar

    Returns:
        List of selected papers (deduplicated by arxiv_id)
    """
    if api is None:
        api = ArxivAPI()

    weights = _normalize_weights(config.category_weights)
    all_papers: dict[str, ArxivPaper] = {}  # arxiv_id -> paper (for dedup)

    total_to_fetch = len(config.years) * config.papers_per_year
    desc = f"Fetching papers ({config.papers_per_year}/year × {len(config.years)} years)"

    with tqdm(total=total_to_fetch, desc=desc, disable=not progress) as pbar:
        for year in config.years:
            year_papers: dict[str, ArxivPaper] = {}
            year_target = config.papers_per_year

            # Calculate papers per category for this year
            category_targets = {
                cat: max(1, int(weight * year_target))
                for cat, weight in weights.items()
            }

            for category, target in category_targets.items():
                if len(year_papers) >= year_target:
                    break

                # Fetch more than needed to account for year filtering and duplicates
                # Year filtering is client-side, so we need to fetch more
                fetch_count = min(target * 10, 1000)

                try:
                    papers = api.search(
                        category=category,
                        year=year,
                        max_results=fetch_count,
                        sort_by=config.sort_by,
                        sort_order=config.sort_order,
                    )
                except Exception as e:
                    print(f"Warning: Failed to fetch {category}/{year}: {e}")
                    continue

                if not papers:
                    # Try without year filter and filter client-side
                    try:
                        papers = api.search(
                            category=category,
                            year=None,
                            max_results=fetch_count,
                            sort_by=config.sort_by,
                            sort_order=config.sort_order,
                        )
                        # Filter to target year
                        papers = [p for p in papers if p.year == year]
                    except Exception as e:
                        print(f"Warning: Retry failed for {category}/{year}: {e}")
                        continue

                added = 0
                for paper in papers:
                    # Skip if already have this paper or in existing set
                    if paper.arxiv_id in year_papers:
                        continue
                    if paper.arxiv_id in all_papers:
                        continue
                    if paper.arxiv_id in config.existing_ids:
                        continue

                    year_papers[paper.arxiv_id] = paper
                    added += 1

                    if added >= target or len(year_papers) >= year_target:
                        break

                pbar.update(added)

            # Add year's papers to total
            all_papers.update(year_papers)

    return list(all_papers.values())


def select_papers_simple(
    papers_per_year: int = 500,
    years: Optional[list[int]] = None,
    category_weights: Optional[dict[str, float]] = None,
    existing_ids: Optional[set[str]] = None,
    progress: bool = True,
) -> list[ArxivPaper]:
    """
    Convenience function for paper selection.

    Args:
        papers_per_year: Target papers per year
        years: List of years to fetch (default: 2020-2024)
        category_weights: Category -> weight mapping (default: DEFAULT_CATEGORY_WEIGHTS)
        existing_ids: Set of arxiv_ids to skip
        progress: Show progress bar

    Returns:
        List of selected papers
    """
    config = SelectionConfig(
        papers_per_year=papers_per_year,
        years=years,
        category_weights=category_weights,
        existing_ids=existing_ids,
    )
    return select_papers(config, progress=progress)
