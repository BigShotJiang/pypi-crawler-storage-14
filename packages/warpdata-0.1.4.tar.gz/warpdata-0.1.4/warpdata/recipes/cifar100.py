"""
CIFAR-100 dataset recipe.

Creates a compact, metadata-only Parquet for CIFAR-100 via HuggingFace
(`datasets`), mirroring the ImageNet-1k recipe pattern. Images are not
embedded in the Parquet; instead we record split and labels so the file
stays small and fast to load.

Splits:
- train: 50,000 examples
- test: 10,000 examples

Columns:
- idx: int                Example index within split
- split: str              "train" or "test"
- label: int              Fine label id [0..99]
- label_name: str         Fine label name
- coarse_label: int?      Optional (if provided by HF dataset)
- coarse_label_name: str? Optional (if provided by HF dataset)
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd

try:
    from datasets import load_dataset  # type: ignore
except Exception as e:  # pragma: no cover - import-time guidance
    raise RuntimeError(
        "The 'datasets' package is required for the CIFAR-100 recipe.\n"
        "Install with: pip install datasets\n"
        f"Import error: {e}"
    )

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def _iter_examples(ds, split_name: str, max_samples: Optional[int] = None) -> Iterable[Dict]:
    """Yield normalized CIFAR-100 records from a HF split."""
    # Detect label field names defensively (HF config variations)
    has_fine = "fine_label" in ds.features
    has_label = "label" in ds.features
    has_coarse = "coarse_label" in ds.features

    # Resolve label names if available
    label_names: Optional[List[str]] = None
    coarse_names: Optional[List[str]] = None
    if has_fine:
        try:
            label_names = list(ds.features["fine_label"].names)  # type: ignore[attr-defined]
        except Exception:
            label_names = None
    elif has_label:
        try:
            label_names = list(ds.features["label"].names)  # type: ignore[attr-defined]
        except Exception:
            label_names = None
    if has_coarse:
        try:
            coarse_names = list(ds.features["coarse_label"].names)  # type: ignore[attr-defined]
        except Exception:
            coarse_names = None

    for idx, ex in enumerate(ds):
        if max_samples is not None and idx >= max_samples:
            break

        # Fine label id/name
        if has_fine:
            lbl = int(ex["fine_label"])  # type: ignore[index]
        elif has_label:
            lbl = int(ex["label"])  # type: ignore[index]
        else:
            raise KeyError("CIFAR-100 example missing fine label field ('fine_label'/'label')")
        lbl_name = label_names[lbl] if label_names and 0 <= lbl < len(label_names) else None

        # Coarse label id/name (optional)
        if has_coarse:
            clbl = int(ex["coarse_label"])  # type: ignore[index]
            clbl_name = (
                coarse_names[clbl] if coarse_names and 0 <= clbl < len(coarse_names) else None
            )
        else:
            clbl, clbl_name = None, None

        rec = {
            "idx": idx,
            "split": split_name,
            "label": lbl,
            "label_name": lbl_name,
        }
        if clbl is not None:
            rec["coarse_label"] = clbl
        if clbl_name is not None:
            rec["coarse_label_name"] = clbl_name

        yield rec


def cifar100(
    ctx: RecipeContext,
    repo_id: str = "cifar100",
    splits: Tuple[str, ...] = ("train", "test"),
    max_samples: Optional[int] = None,
) -> RecipeOutput:
    """
    Build CIFAR-100 dataset metadata table via HuggingFace.

    Args:
        ctx: Recipe context
        repo_id: HF datasets repo id (default: 'cifar100')
        splits: Which splits to include (default: ('train','test'))
        max_samples: Optional cap per split for quick tests

    Returns:
        RecipeOutput with a single Parquet file under the dataset cache
    """
    print(f"📚 Loading CIFAR-100 from '{repo_id}'...")
    if max_samples:
        print(f"   Note: limiting to {max_samples:,} samples per split")

    all_records: List[Dict] = []

    for split_name in splits:
        print(f"  • Split: {split_name}")
        # Stream only if max_samples specified; otherwise let HF load fully
        if max_samples is not None:
            ds = load_dataset(repo_id, split=split_name, streaming=True)
        else:
            ds = load_dataset(repo_id, split=split_name, streaming=False)

        for rec in _iter_examples(ds, split_name=split_name, max_samples=max_samples):
            all_records.append(rec)
        print(f"    added {sum(1 for _ in [r for r in all_records if r['split']==split_name]):,} rows")

    if not all_records:
        raise RuntimeError("No rows parsed for CIFAR-100")

    df = pd.DataFrame(all_records)
    out_path = ctx.work_dir / "cifar100.parquet"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_path, index=False)

    # Basic stats
    split_counts = df["split"].value_counts().to_dict()
    n_classes = int(df["label"].nunique()) if "label" in df.columns else 0

    print("✅ CIFAR-100 Parquet written:")
    print(f"   {out_path}")
    print(f"   rows={len(df):,}, classes={n_classes}, splits={split_counts}")

    # Track HF cache as raw provenance if present
    raw_paths: List[str] = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_paths.append(str(hf_cache))

    metadata = {
        "source": repo_id,
        "total_rows": len(df),
        "splits": split_counts,
        "num_classes": n_classes,
        "notes": "Metadata-only table (no image bytes). Use raw HF dataset for images if needed.",
    }

    return RecipeOutput(
        main=[out_path],
        metadata=metadata,
        raw_data=[Path(p) for p in raw_paths],
    )

