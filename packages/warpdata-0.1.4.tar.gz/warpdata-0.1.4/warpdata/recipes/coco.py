"""
COCO Dataset Recipe.

Processes COCO (Common Objects in Context) dataset from a local folder with
images and annotations (instances, captions, or both).

Supports standard COCO layouts:
  - <root>/train2017, <root>/val2017, <root>/annotations/instances_*.json
  - <root>/train2014, <root>/val2014, etc.

Output datasets:
- main: All splits combined
- train: Training split only
- val: Validation split only
- test: Test split only (if present)
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional, Set
import json

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def _detect_splits(root: Path) -> List[str]:
    """Auto-detect COCO splits in directory."""
    candidates = [
        "train2017", "val2017", "test2017",
        "train2014", "val2014",
        "train", "val", "test",
    ]
    found = [c for c in candidates if (root / c).exists()]
    return found if found else ["train"]


def _normalize_split(split: str) -> str:
    """Normalize split name to train/val/test."""
    sl = split.lower()
    if sl.startswith("train"):
        return "train"
    if sl.startswith("val"):
        return "val"
    if sl.startswith("test"):
        return "test"
    return split


def _load_json_safe(path: Path) -> Optional[Dict]:
    """Load JSON file with error handling."""
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"   Warning: Failed to load {path}: {e}")
        return None


def _annotation_paths(root: Path, split: str) -> Tuple[Optional[Path], Optional[Path]]:
    """Find instances and captions annotation files for split."""
    ann_dir = root / "annotations"
    inst = ann_dir / f"instances_{split}.json"
    caps = ann_dir / f"captions_{split}.json"
    return (inst if inst.exists() else None,
            caps if caps.exists() else None)


def _build_instances_index(inst_doc: Dict) -> Tuple[Dict[int, Dict], Dict[int, List[Dict]], Dict[int, str]]:
    """Build indexes from instances annotation file."""
    images = {img["id"]: img for img in inst_doc.get("images", [])}
    cats = {c["id"]: c.get("name") for c in inst_doc.get("categories", [])}

    annos: Dict[int, List[Dict]] = {}
    for a in inst_doc.get("annotations", []):
        img_id = a.get("image_id")
        if img_id is None:
            continue
        lst = annos.setdefault(img_id, [])
        lst.append({
            "category_id": a.get("category_id"),
            "category": cats.get(a.get("category_id")),
            "bbox": a.get("bbox"),  # [x, y, width, height]
            "area": a.get("area"),
            "iscrowd": a.get("iscrowd", 0),
        })

    return images, annos, cats


def _build_captions_index(caps_doc: Dict) -> Dict[int, List[str]]:
    """Build captions index from captions annotation file."""
    caps: Dict[int, List[str]] = {}
    for a in caps_doc.get("annotations", []):
        img_id = a.get("image_id")
        if img_id is None:
            continue
        caps.setdefault(img_id, []).append(a.get("caption", ""))
    return caps


def _discover_images(img_root: Path) -> List[Path]:
    """Discover all image files in directory."""
    images = []
    for p in img_root.rglob("*"):
        if p.is_file() and p.suffix.lower() in IMG_EXTS:
            images.append(p)
    return images


def coco(
    ctx: RecipeContext,
    data_dir: str,
    task: str = "both",
    create_split_subdatasets: bool = True,
) -> RecipeOutput:
    """
    Create COCO dataset with images and annotations.

    Args:
        ctx: Recipe context
        data_dir: Directory containing COCO data (images and annotations)
        task: Which annotations to include: "instances", "captions", or "both"
        create_split_subdatasets: If True, create separate datasets per split

    Returns:
        RecipeOutput with main dataset and optional split subdatasets

    Main dataset columns:
        - image_id: COCO image ID
        - file_name: Image filename
        - image_path: Absolute path to image
        - rel_path: Relative path within split
        - width: Image width in pixels
        - height: Image height in pixels
        - split: Normalized split name (train/val/test)
        - split_raw: Original split name (e.g., train2017)
        - instances_json: JSON array of instance annotations
        - captions_json: JSON array of all captions
        - first_caption: First caption (scalar, for embeddings)
        - all_captions: All captions concatenated (scalar, for embeddings)
        - categories: Comma-separated category names (scalar, for filtering)
        - num_instances: Number of instances
        - num_captions: Number of captions
        - total_area: Sum of all instance areas
        - has_crowd: Whether any instance is crowd annotation
        - gold_present: Whether gold annotations are present

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "coco",
        ...     "warpdata://vision/coco",
        ...     data_dir="./recipes_raw_data/coco",
        ...     task="both"
        ... )
        >>> main = wd.load("warpdata://vision/coco", as_format="pandas")
        >>> train = wd.load("warpdata://vision/coco-train", as_format="pandas")
    """
    data_path = Path(data_dir)
    print(f"📊 Processing COCO dataset from {data_path}")

    if not data_path.exists():
        raise ValueError(f"Data directory not found: {data_path}")

    # Detect splits
    splits = _detect_splits(data_path)
    print(f"   Found splits: {splits}")

    # Process each split
    all_records = []
    split_stats = {}

    for split in splits:
        print(f"\n   Processing split: {split}")

        # Determine image root
        img_root = data_path / split if (data_path / split).exists() else data_path

        # Load annotations
        p_inst, p_caps = _annotation_paths(data_path, split)

        inst_doc = None
        caps_doc = None

        if task in ("instances", "both") and p_inst:
            print(f"      Loading instances: {p_inst.name}")
            inst_doc = _load_json_safe(p_inst)

        if task in ("captions", "both") and p_caps:
            print(f"      Loading captions: {p_caps.name}")
            caps_doc = _load_json_safe(p_caps)

        # Build indexes
        images_idx: Dict[int, Dict] = {}
        inst_idx: Dict[int, List[Dict]] = {}
        cats: Dict[int, str] = {}

        if inst_doc:
            images_idx, inst_idx, cats = _build_instances_index(inst_doc)
            print(f"      Found {len(images_idx)} images, {sum(len(v) for v in inst_idx.values())} instances")

        caps_idx: Dict[int, List[str]] = {}
        if caps_doc:
            caps_idx = _build_captions_index(caps_doc)
            print(f"      Found {sum(len(v) for v in caps_idx.values())} captions")

        # Process images
        img_files: List[Tuple[int, Path, Dict]] = []

        if images_idx:
            # Use images from annotations
            for img_id, meta in images_idx.items():
                fn = meta.get("file_name")
                imgp = img_root / fn if fn else None
                if imgp and imgp.exists():
                    img_files.append((img_id, imgp, meta))
        else:
            # Discover images from filesystem
            print(f"      Discovering images in {img_root}")
            for p in _discover_images(img_root):
                # Try to extract image_id from filename
                stem = p.stem
                try:
                    # COCO filenames often like: 000000012345.jpg
                    img_id = int(stem.lstrip("0") or "0")
                except Exception:
                    img_id = hash(stem) % (2**31)  # Fallback to hash

                meta = {"id": img_id, "file_name": p.name}
                img_files.append((img_id, p, meta))

        print(f"      Processing {len(img_files)} images")

        # Build records
        for img_id, imgp, meta in img_files:
            instances = inst_idx.get(img_id, []) if inst_idx else []
            captions = caps_idx.get(img_id, []) if caps_idx else []

            # Extract useful scalar fields for embeddings/filtering
            first_caption = captions[0].strip() if captions else None
            all_captions_text = " ".join(c.strip() for c in captions) if captions else None

            # Extract category information
            categories = list(set(inst.get("category") for inst in instances if inst.get("category")))
            categories_str = ", ".join(sorted(categories)) if categories else None

            # Calculate instance statistics
            total_area = sum(inst.get("area", 0) for inst in instances)
            has_crowd = any(inst.get("iscrowd", 0) == 1 for inst in instances)

            record = {
                "image_id": img_id,
                "file_name": meta.get("file_name", imgp.name),
                "image_path": str(imgp.resolve()),
                "rel_path": str(imgp.relative_to(img_root)),
                "width": meta.get("width"),
                "height": meta.get("height"),
                "split": _normalize_split(split),
                "split_raw": split,
                # JSON arrays for complete data
                "instances_json": json.dumps(instances) if instances else None,
                "captions_json": json.dumps(captions) if captions else None,
                # Scalar fields for embeddings and filtering
                "first_caption": first_caption,
                "all_captions": all_captions_text,
                "categories": categories_str,
                "num_instances": len(instances),
                "num_captions": len(captions),
                "total_area": total_area,
                "has_crowd": has_crowd,
                "gold_present": bool(instances or captions),
            }

            all_records.append(record)

        split_stats[split] = {
            "images": len(img_files),
            "instances": sum(len(v) for v in inst_idx.values()) if inst_idx else 0,
            "captions": sum(len(v) for v in caps_idx.values()) if caps_idx else 0,
        }

    print(f"\n   Total records: {len(all_records)}")

    # Convert to DataFrame and load into DuckDB
    import pandas as pd
    df = pd.DataFrame(all_records)
    main_relation = ctx.engine.conn.from_df(df)

    # Write main dataset
    main_out = ctx.work_dir / "main.parquet"
    ctx.write_parquet(main_relation, main_out)
    print(f"   Wrote main dataset: {main_out}")

    # Create split subdatasets
    subdatasets = {}

    if create_split_subdatasets:
        for split in splits:
            norm_split = _normalize_split(split)
            split_out = ctx.filter_and_write(
                main_relation,
                ctx.work_dir / f"{norm_split}.parquet",
                filter_sql=f"split = '{norm_split}'"
            )

            subdatasets[norm_split] = SubDataset(
                name=norm_split,
                files=[split_out],
                description=f"COCO {norm_split} split",
                filter_sql=f"split = '{norm_split}'",
                metadata=split_stats.get(split, {})
            )
            print(f"   Created {norm_split} subdataset")

    # Generate documentation
    total_images = len(all_records)
    total_instances = sum(r["num_instances"] for r in all_records)
    total_captions = sum(r["num_captions"] for r in all_records)
    images_with_gold = sum(1 for r in all_records if r["gold_present"])

    notes = f"""# COCO (Common Objects in Context)

## Overview
Microsoft COCO dataset for object detection, segmentation, and captioning.

## Configuration
- **Task**: {task}
- **Splits**: {', '.join(splits)}
- **Total Images**: {total_images:,}
- **Images with Annotations**: {images_with_gold:,}
- **Total Instances**: {total_instances:,}
- **Total Captions**: {total_captions:,}

## Split Statistics
"""

    for split, stats in split_stats.items():
        norm = _normalize_split(split)
        notes += f"""
### {norm.title()} ({split})
- Images: {stats['images']:,}
- Instances: {stats['instances']:,}
- Captions: {stats['captions']:,}
"""

    notes += """
## Structure

### Main Dataset
Each row represents one image with:
- `image_id`: COCO image ID
- `file_name`: Image filename
- `image_path`: Absolute path to image file
- `rel_path`: Relative path within split directory
- `width`, `height`: Image dimensions
- `split`: Normalized split name (train/val/test)
- `split_raw`: Original split name (e.g., train2017)

**Annotations (JSON arrays):**
- `instances_json`: JSON array of instance annotations
- `captions_json`: JSON array of all captions

**Scalar fields (for embeddings and filtering):**
- `first_caption`: First caption (ready for text embeddings)
- `all_captions`: All captions concatenated with spaces
- `categories`: Comma-separated category names (e.g., "person, car, dog")
- `num_instances`: Number of instances
- `num_captions`: Number of captions
- `total_area`: Sum of all instance areas in pixels²
- `has_crowd`: Boolean, whether any instance is crowd annotation
- `gold_present`: Boolean, whether annotations are present

### Instance Format
Each instance in `instances_json`:
```json
{
  "category_id": 1,
  "category": "person",
  "bbox": [x, y, width, height],
  "area": 12345.67,
  "iscrowd": 0
}
```

## Usage Notes

**For embeddings:**
- Use `first_caption` or `all_captions` columns (scalar text)
- No need to parse JSON for basic caption embeddings

**For detailed analysis:**
- Use `json.loads(row['instances_json'])` to parse instances
- Use `json.loads(row['captions_json'])` to parse all captions
- `bbox` format: [x, y, width, height] in pixels
- `iscrowd=1` indicates crowd annotation (don't penalize for missing)

**For filtering:**
- Use `categories` to filter by object type (e.g., WHERE categories LIKE '%person%')
- Use `num_instances` to filter by complexity
- Use `has_crowd` to exclude/include crowd annotations

## Citation
```
@inproceedings{lin2014microsoft,
  title={Microsoft COCO: Common objects in context},
  author={Lin, Tsung-Yi and Maire, Michael and Belongie, Serge and others},
  booktitle={ECCV},
  year={2014}
}
```
"""

    readme = f"""# COCO Dataset

## Quick Start

```python
import warpdata as wd
import json

# Load main dataset
data = wd.load("{ctx.dataset_id}", as_format="pandas")

# Load specific split
train = wd.load("{ctx.dataset_id}-train", as_format="pandas")

# Use scalar caption fields (no JSON parsing needed!)
for _, row in train.head(5).iterrows():
    print(f"Image {{row['image_id']}}")
    print(f"  Caption: {{row['first_caption']}}")
    print(f"  Categories: {{row['categories']}}")
    print(f"  Objects: {{row['num_instances']}}")

# Add caption embeddings (easy!)
wd.add_embeddings(
    "{ctx.dataset_id}",
    space="caption-embeddings",
    provider="sentence-transformers",
    model="sentence-transformers/all-MiniLM-L6-v2",
    source={{"columns": ["first_caption"]}},
    distance_metric="cosine"
)

# Parse full annotations when needed
for _, row in train.iterrows():
    if row['instances_json']:
        instances = json.loads(row['instances_json'])
        print(f"Image {{row['image_id']}}: {{len(instances)}} objects")
```

## Statistics
- Total images: {total_images:,}
- Images with annotations: {images_with_gold:,}
- Total instances: {total_instances:,}
- Total captions: {total_captions:,}

## Splits
{chr(10).join(f"- **{_normalize_split(s)}**: {split_stats[s]['images']:,} images" for s in splits)}
"""

    # Track raw data for backup/provenance
    raw_data_sources = []
    if data_path.exists():
        raw_data_sources.append(data_path)  # Track the entire COCO directory

    return RecipeOutput(
        main=[main_out],
        subdatasets=subdatasets,
        docs={"notes.md": notes, "README.md": readme},
        metadata={
            "task": task,
            "splits": splits,
            "total_images": total_images,
            "total_instances": total_instances,
            "total_captions": total_captions,
            "images_with_gold": images_with_gold,
            "split_stats": split_stats,
        },
        raw_data=raw_data_sources,
    )
