"""
Tested 143k Python Alpaca dataset recipe.

This dataset contains 143,000 tested Python instruction-response pairs from Vezora.
Each example includes an instruction, optional input, and a Python code solution or explanation.

Source: https://huggingface.co/datasets/Vezora/Tested-143k-Python-Alpaca

Dataset contains high-quality instruction-response pairs specifically focused on Python programming tasks.
"""
from pathlib import Path
from typing import Tuple
import pandas as pd
import json

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def python_alpaca(
    ctx: RecipeContext,
    repo_id: str = "Vezora/Tested-143k-Python-Alpaca",
    split: str = "train",
) -> RecipeOutput:
    """
    Create Tested Python Alpaca instruction-following dataset.

    Downloads the 143k Tested Python Alpaca dataset from HuggingFace. Contains instruction-response
    pairs focused on Python programming tasks including code generation, debugging, and explanations.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        split: Which split to include (default: "train")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - id: int - Row index
        - instruction: str - The instruction or question
        - input: str - Additional context or input (may be empty)
        - output: str - The response, usually containing Python code or explanation
        - has_input: bool - Whether the input field is non-empty
        - output_length: int - Character length of output

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "python_alpaca",
        ...     "warpdata://nlp/python-alpaca",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/python-alpaca", as_format="pandas")
        >>> # Filter by has_input
        >>> with_context = df[df['has_input']]
    """
    print(f"Loading Tested Python Alpaca from {repo_id}...")

    # Load dataset from HuggingFace
    print(f"  Loading {split} split...")

    try:
        # Try loading via datasets library first
        ds = load_dataset(repo_id, split=split)

        # Process records
        all_records = []
        for idx, example in enumerate(ds):
            instruction = example.get('instruction', '')
            input_text = example.get('input', '')
            output = example.get('output', '')

            record = {
                'id': idx,
                'instruction': instruction,
                'input': input_text,
                'output': output,
                'has_input': bool(input_text and input_text.strip()),
                'output_length': len(output),
            }
            all_records.append(record)

    except Exception as e:
        print(f"  Could not load via datasets library, trying manual JSON loading...")
        # Fallback: try loading the JSON file directly
        json_path = Path.home() / ".cache" / "huggingface" / "hub" / f"datasets--{repo_id.replace('/', '--')}" / "snapshots"

        # Find the most recent snapshot
        if json_path.exists():
            snapshots = sorted(json_path.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
            if snapshots:
                json_file = snapshots[0] / "143k-Tested-Python-Alpaca-Vezora.json"
                if json_file.exists():
                    print(f"  Loading from {json_file}...")
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)

                    all_records = []
                    for idx, example in enumerate(data):
                        instruction = example.get('instruction', '')
                        input_text = example.get('input', '')
                        output = example.get('output', '')

                        record = {
                            'id': idx,
                            'instruction': instruction,
                            'input': input_text,
                            'output': output,
                            'has_input': bool(input_text and input_text.strip()),
                            'output_length': len(output),
                        }
                        all_records.append(record)
                else:
                    raise FileNotFoundError(f"Could not find JSON file at {json_file}")
            else:
                raise FileNotFoundError(f"No snapshots found in {json_path}")
        else:
            raise FileNotFoundError(f"HuggingFace cache not found at {json_path}")

    print(f"  Processing {len(all_records):,} examples...")
    print(f"\nTotal examples: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Statistics
    with_input = df['has_input'].sum()
    without_input = len(df) - with_input
    avg_output_length = df['output_length'].mean()

    print(f"\nDataset statistics:")
    print(f"  Examples with input context: {with_input:,} ({100*with_input/len(df):.1f}%)")
    print(f"  Examples without input: {without_input:,} ({100*without_input/len(df):.1f}%)")
    print(f"  Average output length: {avg_output_length:.0f} characters")
    print(f"  Min output length: {df['output_length'].min()}")
    print(f"  Max output length: {df['output_length'].max()}")

    # Write to output
    output_path = ctx.work_dir / "python_alpaca.parquet"
    df.to_parquet(output_path, index=False)

    print(f"\nSaved to {output_path}")

    # Generate documentation
    readme = f"""# Tested 143k Python Alpaca Dataset

## Overview
A high-quality dataset of 143,000 tested instruction-response pairs focused on Python programming.
Each example contains an instruction (question or task), optional input context, and a detailed
response typically containing Python code or explanations.

## Quick Start

```python
import warpdata as wd

# Load dataset
df = wd.load("warpdata://nlp/python-alpaca", as_format="pandas")

# Filter examples with additional input context
with_context = df[df['has_input']]

# Filter by output length
short_examples = df[df['output_length'] < 500]
```

## Statistics
- **Total examples**: {len(df):,}
- **Examples with input context**: {with_input:,} ({100*with_input/len(df):.1f}%)
- **Examples without input**: {without_input:,} ({100*without_input/len(df):.1f}%)
- **Average output length**: {avg_output_length:.0f} characters
- **Output length range**: {df['output_length'].min()} - {df['output_length'].max()} characters

## Schema

| Column | Type | Description |
|--------|------|-------------|
| id | int | Unique example identifier |
| instruction | str | The instruction or question |
| input | str | Additional context (may be empty) |
| output | str | Response with Python code/explanation |
| has_input | bool | Whether input field is non-empty |
| output_length | int | Character length of output |

## Source
- **Repository**: {repo_id}
- **URL**: https://huggingface.co/datasets/{repo_id}

## Use Cases
- Python code generation
- Programming instruction following
- Code explanation and documentation
- Algorithm implementation
- Debugging assistance
"""

    notes = f"""# Tested 143k Python Alpaca

## Dataset Overview
This dataset contains {len(df):,} high-quality instruction-response pairs focused on Python programming tasks.

## Configuration
- **Source**: {repo_id}
- **Split**: {split}
- **Total examples**: {len(df):,}

## Content Distribution
- Examples with additional input: {with_input:,}
- Examples without additional input: {without_input:,}
- Average output length: {avg_output_length:.0f} characters

## Typical Use Cases
1. Training code generation models
2. Fine-tuning on Python-specific tasks
3. Instruction following for programming
4. Code explanation and documentation generation
"""

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "hub" / f"datasets--{repo_id.replace('/', '--')}"
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        docs={"README.md": readme, "notes.md": notes},
        metadata={
            'total_examples': len(df),
            'examples_with_input': int(with_input),
            'examples_without_input': int(without_input),
            'avg_output_length': float(avg_output_length),
            'min_output_length': int(df['output_length'].min()),
            'max_output_length': int(df['output_length'].max()),
            'repo_id': repo_id,
            'split': split,
        },
        raw_data=raw_data_paths,
    )
