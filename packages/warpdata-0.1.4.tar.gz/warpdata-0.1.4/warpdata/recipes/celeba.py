"""
CelebA (Celebrity Faces Attributes) Dataset Recipe.

CelebA is a large-scale face attributes dataset with 200K+ celebrity images,
each annotated with 40 attribute labels.

Source: http://mmlab.ie.cuhk.edu.hk/projects/CelebA.html
Paper: Liu et al. "Deep Learning Face Attributes in the Wild" (ICCV 2015)

Attributes (40):
- Appearance: Attractive, Blurry, Chubby, Oval_Face, Pale_Skin, Young
- Hair: Bald, Bangs, Black_Hair, Blond_Hair, Brown_Hair, Gray_Hair, Receding_Hairline,
        Straight_Hair, Wavy_Hair
- Facial hair: 5_o_Clock_Shadow, Goatee, Mustache, No_Beard, Sideburns
- Facial features: Arched_Eyebrows, Bags_Under_Eyes, Big_Lips, Big_Nose, Bushy_Eyebrows,
                   Double_Chin, High_Cheekbones, Narrow_Eyes, Pointy_Nose, Rosy_Cheeks
- Accessories: Eyeglasses, Wearing_Earrings, Wearing_Hat, Wearing_Lipstick,
               Wearing_Necklace, Wearing_Necktie
- Expression: Heavy_Makeup, Mouth_Slightly_Open, Smiling
- Gender: Male

Total images: ~200K
"""
from pathlib import Path
from typing import Optional, List
import pandas as pd
import numpy as np

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, EmbeddingConfig


def celeba(
    ctx: RecipeContext,
    celeba_root: str = "./recipes_raw_data/celeba",
    limit: Optional[int] = None,
    add_embeddings: bool = False,
    embeddings_model: str = "openai/clip-vit-base-patch32",
) -> RecipeOutput:
    """
    Create CelebA face attributes dataset.

    Processes local CelebA data (images + attributes CSV) into a unified dataset.

    All 40 attributes are available as boolean columns. Filter at query time - no
    subdatasets needed since all data shares the same schema.

    Args:
        ctx: Recipe context
        celeba_root: Root directory containing img_align_celeba/ and list_attr_celeba.csv
        limit: Optional limit on number of images (for testing)
        add_embeddings: Whether to add image embeddings
        embeddings_model: Model for embeddings (if add_embeddings=True)

    Returns:
        RecipeOutput with main dataset

    Dataset columns:
        - image_id: str - Image filename (e.g., "000001.jpg")
        - image_path: str - Absolute path to image file
        - <attribute>: bool - 40 binary attributes (True/False)

    Examples:
        >>> import warpdata as wd
        >>> from warpdata.loaders import ImageColumn
        >>>
        >>> # Create dataset
        >>> result = wd.run_recipe(
        ...     "celeba",
        ...     "warpdata://vision/celeba",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://vision/celeba", as_format="pandas")
        >>>
        >>> # Filter at query time (efficient - no duplicated data)
        >>> young_smiling_females = df[(~df['Male']) & df['Smiling'] & df['Young']]
        >>> males = df[df['Male']]
        >>> attractive = df[df['Attractive']]
        >>>
        >>> # Lazy load images
        >>> images = ImageColumn(df['image_path'])
        >>> img = images[0]  # PIL.Image
        >>> img.show()
        >>>
        >>> # Load batch of filtered images
        >>> male_images = ImageColumn(males['image_path'])
        >>> batch = male_images[0:10]  # List of PIL.Image
        >>> arrays = male_images.to_array(slice(0, 10), size=(224, 224))  # As numpy arrays
    """
    root = Path(celeba_root).resolve()

    # Validate paths
    img_dir = root / "img_align_celeba"
    attr_csv = root / "list_attr_celeba.csv"

    if not img_dir.exists():
        raise FileNotFoundError(f"Image directory not found: {img_dir}")
    if not attr_csv.exists():
        raise FileNotFoundError(f"Attributes CSV not found: {attr_csv}")

    print(f"Loading CelebA from {root}...")
    print(f"  Images: {img_dir}")
    print(f"  Attributes: {attr_csv}")

    # Load attributes CSV
    print(f"\nLoading attributes...")
    df_all = pd.read_csv(attr_csv)
    print(f"  Loaded {len(df_all):,} records with {len(df_all.columns)-1} attributes")

    # Convert -1/1 to boolean (True/False)
    # -1 means attribute is absent, 1 means present
    attribute_columns = [col for col in df_all.columns if col != 'image_id']

    for col in attribute_columns:
        df_all[col] = df_all[col] == 1  # Convert to boolean

    # Add image paths and filter to existing files to avoid broken rows
    df_all['image_path'] = df_all['image_id'].apply(lambda x: str(img_dir / x))
    exists_mask = df_all['image_path'].apply(lambda p: Path(p).exists())
    missing_count = int((~exists_mask).sum())
    if missing_count:
        print(f"  Skipping {missing_count} rows with missing image files")
    df_all = df_all[exists_mask]

    # Apply limit after filtering so we keep only valid rows
    if limit:
        print(f"  Limiting to {limit:,} images after filtering...")
        df = df_all.head(limit).copy()
    else:
        df = df_all

    # Reorder columns: image_id, image_path, then attributes
    cols = ['image_id', 'image_path'] + attribute_columns
    df = df[cols]

    # Save main dataset
    output_path = ctx.work_dir / "celeba.parquet"
    df.to_parquet(output_path, index=False)
    print(f"\nSaved main dataset: {output_path}")

    # Print statistics
    print(f"\nDataset Statistics:")
    print(f"  Total images: {len(df):,}")
    print(f"\nAttribute distributions (% True):")
    for col in sorted(attribute_columns):
        pct = (df[col].sum() / len(df)) * 100
        print(f"  {col:25s}: {pct:5.1f}%")

    print(f"\nCommon query examples:")
    print(f"  Males: {df['Male'].sum():,} images")
    print(f"  Females: {(~df['Male']).sum():,} images")
    print(f"  Smiling: {df['Smiling'].sum():,} images")
    print(f"  Young: {df['Young'].sum():,} images")

    # Prepare embeddings config
    embeddings = []
    if add_embeddings:
        print(f"\nConfiguring image embeddings...")
        print(f"  Model: {embeddings_model}")

        embeddings.append(
            EmbeddingConfig(
                space="image-clip",
                provider="sentence-transformers",  # Can handle vision models
                model=embeddings_model,
                source={"columns": ["image_path"]},
                distance_metric="cosine",
            )
        )

    # Build metadata
    metadata = {
        'total_images': len(df),
        'total_attributes': len(attribute_columns),
        'attributes': attribute_columns,
        'source': str(celeba_root),
        'columns': {
            'image_path': {
                'loader': 'image',
                'format': 'jpg',
                'description': 'Path to aligned celebrity face image - use ImageColumn for lazy loading'
            },
            'image_id': {
                'type': 'categorical',
                'description': 'Image filename identifier'
            }
        }
    }

    # Add attribute column metadata
    for attr in attribute_columns:
        metadata['columns'][attr] = {
            'type': 'boolean',
            'description': f'Binary attribute: {attr.replace("_", " ")}'
        }

    # Add top attributes by prevalence
    top_attrs = df[attribute_columns].sum().sort_values(ascending=False).head(10)
    metadata['top_10_attributes'] = {
        attr: int(count) for attr, count in top_attrs.items()
    }

    print(f"\n{'='*60}")
    print("Recipe complete!")
    print(f"{'='*60}")
    print(f"  Main dataset: {len(df):,} images")
    print(f"  Embeddings: {'Configured' if embeddings else 'None'}")

    # Track raw data for backup/provenance
    raw_data_sources = []
    if img_dir.exists():
        raw_data_sources.append(img_dir)  # Track the images directory
    if attr_csv.exists():
        raw_data_sources.append(attr_csv)  # Track the attributes CSV

    return RecipeOutput(
        main=[output_path],
        embeddings=embeddings,
        metadata=metadata,
        raw_data=raw_data_sources,
    )
