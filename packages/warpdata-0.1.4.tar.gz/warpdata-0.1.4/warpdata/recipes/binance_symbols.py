"""
Binance Symbols dataset recipe.

Downloads exchange info (symbols, base/quote assets, status) and writes
to a single Parquet file suitable for joining with CoinGecko datasets.

Notes:
- Public endpoint (no API key required)
- Allows dependency injection of fetch function for tests
"""
from __future__ import annotations

import os
import time
import threading
from typing import Any, Dict, Optional, Callable, List
from pathlib import Path

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


BINANCE_API_BASE = os.environ.get("BINANCE_API_BASE", "https://api.binance.com")
_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "warpdata-binance/1.0",
    }

    req = urllib.request.Request(full, headers=headers, method="GET")
    # Simple global rate limit (env tunable)
    global _LAST_REQ_TS
    with _REQ_LOCK:
        # Honor IP rate limit ~1000 req / 5 min => ~0.3s/request
        min_interval = float(os.environ.get("BINANCE_MIN_INTERVAL", "0.3"))
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
        return json.loads(data)


def binance_symbols(
    ctx: RecipeContext,
    *,
    symbol_status: Optional[str] = "TRADING",
    fetch_fn: Optional[Callable[[str, Optional[Dict[str, Any]]], Dict[str, Any]]] = None,
) -> RecipeOutput:
    """
    Create Binance symbols dataset from /api/v3/exchangeInfo.

    Args:
        ctx: Recipe context
        symbol_status: Optional status filter (e.g., 'TRADING')
        fetch_fn: Optional override for HTTP fetch (for tests)
    """
    fetch = fetch_fn or (lambda url, params: _http_get_json(url, params))

    params: Dict[str, Any] = {}
    if symbol_status:
        params["symbolStatus"] = symbol_status
    url = f"{BINANCE_API_BASE}/api/v3/exchangeInfo"
    js = fetch(url, params)

    symbols = js.get("symbols", []) if isinstance(js, dict) else []
    rows: List[Dict[str, Any]] = []
    for s in symbols:
        rows.append(
            {
                "symbol": s.get("symbol"),
                "status": s.get("status"),
                "base_asset": s.get("baseAsset"),
                "quote_asset": s.get("quoteAsset"),
                "is_spot_trading_allowed": s.get("isSpotTradingAllowed"),
            }
        )

    df = pd.DataFrame(rows)

    out_file = ctx.work_dir / "binance_symbols.parquet"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(out_file, index=False)

    return RecipeOutput(
        main=[out_file],
        metadata={"source": "binance", "endpoint": "exchangeInfo", "count": len(df)},
    )
