"""
CoinGecko Onchain Safe Pools - Top N tokens by market cap with safety filters.

Uses CoinGecko's megafilter endpoint to get verified safe pools:
- No honeypot tokens
- Good GT score (75+)
- Listed on CoinGecko
- Has social links

Auto-discovers top tokens by market cap from safe pools.

API key:
- Requires CoinGecko Pro API key (Analyst plan or above)

Networks supported:
- eth, bsc, polygon_pos, arbitrum, base, avalanche, solana, optimism, fantom, etc.

Example:
    >>> import warpdata as wd
    >>> # Get top 50 safe tokens on Ethereum
    >>> result = wd.run_recipe(
    ...     "coingecko_onchain_safe",
    ...     "warpdata://crypto/coingecko/onchain_eth_safe",
    ...     network="eth",
    ...     top_n=50,
    ...     with_materialize=True
    ... )
"""
from __future__ import annotations

import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


PRO_API_BASE = "https://pro-api.coingecko.com/api/v3"

_REQ_LOCK = threading.Lock()
_LAST_REQ_TS = 0.0
_MIN_INTERVAL_ENV = float(os.environ.get('COINGECKO_MIN_INTERVAL', '0')) if os.environ.get('COINGECKO_MIN_INTERVAL') else None


def _http_get_json(url: str, params: Optional[Dict[str, Any]] = None, *, api_key: Optional[str] = None, timeout: float = 30.0) -> Dict[str, Any]:
    import urllib.request
    import urllib.parse
    import json

    qs = urllib.parse.urlencode(params or {})
    full = f"{url}?{qs}" if qs else url

    headers = {
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }
    if api_key:
        headers["x-cg-pro-api-key"] = api_key

    req = urllib.request.Request(full, headers=headers, method="GET")

    global _LAST_REQ_TS
    with _REQ_LOCK:
        default_interval = 0.15 if api_key else 1.5
        min_interval = max(_MIN_INTERVAL_ENV or 0.0, default_interval)
        now = time.time()
        wait = _LAST_REQ_TS + min_interval - now
        if wait > 0:
            time.sleep(wait)
        _LAST_REQ_TS = time.time()

    backoff = 0.5
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = resp.read()
                return json.loads(data)
        except Exception as e:
            import urllib.error
            if isinstance(e, urllib.error.HTTPError):
                code = e.code
                body = e.read().decode("utf-8", errors="replace") if hasattr(e, "read") else ""

                if code in (429, 403) or 500 <= code < 600:
                    if attempt < 4:
                        time.sleep(backoff)
                        backoff *= 2
                        continue
                    raise RuntimeError(f"HTTP {code} for {full} :: {body}")

                raise RuntimeError(f"HTTP {code} for {full} :: {body}")

            if attempt == 4:
                raise
    raise RuntimeError(f"Failed to fetch {full}")


def _get_safe_pools(network: str, api_key: str, top_n: int = 100, dex: Optional[str] = None) -> List[Tuple[str, Dict]]:
    """
    Get top N safe pools using megafilter endpoint.

    Returns list of (token_address, pool_info) tuples sorted by market cap.
    """
    print(f"  🔄 Discovering top {top_n} safe tokens from megafilter...")
    print(f"     Filters: no_honeypot, good_gt_score, on_coingecko, has_social")

    url = f"{PRO_API_BASE}/onchain/pools/megafilter"

    # Build params with safety checks
    params = {
        "networks": network,
        "checks": "no_honeypot,good_gt_score,on_coingecko,has_social",
        "include": "base_token,quote_token",
    }

    if dex:
        params["dexes"] = dex

    pools_by_token = {}  # token_address -> best pool info
    page = 1
    max_pages = 10  # Limit to 10 pages (200 pools)

    while page <= max_pages:
        params["page"] = page

        try:
            response = _http_get_json(url, params, api_key=api_key)
            pools = response.get("data", [])
            included = response.get("included", [])

            if not pools:
                break

            # Build token lookup
            tokens = {}
            for item in included:
                if item.get("type") == "token":
                    tokens[item["id"]] = item["attributes"]

            # Process pools
            for pool in pools:
                attrs = pool.get("attributes", {})
                rels = pool.get("relationships", {})

                # Get base token (the main token, not stablecoin)
                base_token_id = rels.get("base_token", {}).get("data", {}).get("id")
                quote_token_id = rels.get("quote_token", {}).get("data", {}).get("id")

                if not base_token_id:
                    continue

                base_token = tokens.get(base_token_id, {})
                quote_token = tokens.get(quote_token_id, {})

                token_addr = base_token.get("address")
                if not token_addr:
                    continue

                token_addr = token_addr.lower()

                # Get market cap (use FDV if market cap not available)
                market_cap = attrs.get("market_cap_usd") or attrs.get("fdv_usd")

                if not market_cap:
                    continue

                try:
                    market_cap_float = float(market_cap)
                except (ValueError, TypeError):
                    continue

                # Keep the pool with highest liquidity for each token
                if token_addr not in pools_by_token or market_cap_float > pools_by_token[token_addr]["market_cap"]:
                    pools_by_token[token_addr] = {
                        "token_address": token_addr,
                        "token_name": base_token.get("name"),
                        "token_symbol": base_token.get("symbol"),
                        "coingecko_coin_id": base_token.get("coingecko_coin_id"),
                        "market_cap": market_cap_float,
                        "price_usd": float(attrs.get("base_token_price_usd", 0)),
                        "pool_address": attrs.get("address"),
                        "dex": rels.get("dex", {}).get("data", {}).get("id"),
                        "reserve_usd": float(attrs.get("reserve_in_usd", 0)),
                        "volume_24h": float(attrs.get("volume_usd", {}).get("h24", 0)),
                    }

            print(f"     Page {page}: {len(pools)} pools, {len(pools_by_token)} unique tokens so far")

            # Check if we have enough
            if len(pools_by_token) >= top_n:
                break

            page += 1

        except Exception as e:
            print(f"     ⚠️  Page {page} failed: {e}")
            break

    # Sort by market cap and take top N
    sorted_tokens = sorted(pools_by_token.items(), key=lambda x: x[1]["market_cap"], reverse=True)[:top_n]

    print(f"  ✓ Found {len(sorted_tokens)} safe tokens")

    if sorted_tokens:
        print(f"     Top token: {sorted_tokens[0][1]['token_symbol']} (${sorted_tokens[0][1]['market_cap']:,.0f})")
        print(f"     Bottom token: {sorted_tokens[-1][1]['token_symbol']} (${sorted_tokens[-1][1]['market_cap']:,.0f})")

    return sorted_tokens


def coingecko_onchain_safe(
    ctx: RecipeContext,
    network: str,
    *,
    top_n: int = 100,
    dex: Optional[str] = None,
    include_market_cap: bool = True,
    include_24hr_vol: bool = True,
    include_24hr_change: bool = True,
    include_reserve: bool = True,
    api_key: Optional[str] = None,
    max_workers: int = 10,
) -> RecipeOutput:
    """
    Create CoinGecko onchain safe token dataset.

    Uses megafilter to get verified safe pools, then fetches full token data.
    Filters applied:
    - no_honeypot: No honeypot tokens
    - good_gt_score: GT Score >= 75
    - on_coingecko: Listed on CoinGecko
    - has_social: Has social links

    Args:
        ctx: Recipe context
        network: Network ID (eth, bsc, polygon_pos, arbitrum, base, solana, etc.)
        top_n: Number of top tokens by market cap (default: 100)
        dex: Optional DEX filter (e.g., 'uniswap_v3')
        include_market_cap: Include market cap data
        include_24hr_vol: Include 24hr volume
        include_24hr_change: Include 24hr price change
        include_reserve: Include total reserve in USD
        api_key: CoinGecko Pro API key (Analyst plan or above)
        max_workers: Max parallel workers (default: 10)

    Returns:
        RecipeOutput with safe token price data

    Examples:
        >>> import warpdata as wd
        >>> # Top 50 safe tokens on Ethereum
        >>> result = wd.run_recipe(
        ...     "coingecko_onchain_safe",
        ...     "warpdata://crypto/coingecko/onchain_eth_safe",
        ...     network="eth",
        ...     top_n=50,
        ...     with_materialize=True
        ... )
    """
    api_key = api_key or os.environ.get("COINGECKO_API_KEY")

    if not api_key:
        raise ValueError("CoinGecko Pro API key required (Analyst plan or above). Set COINGECKO_API_KEY environment variable.")

    print(f"📊 Fetching CoinGecko Safe Token Data")
    print(f"  Network: {network}")
    print(f"  Top N: {top_n}")
    print(f"  Max workers: {max_workers}")
    if dex:
        print(f"  DEX filter: {dex}")

    # Get safe pools and extract token addresses
    safe_pools = _get_safe_pools(network, api_key, top_n, dex)

    if not safe_pools:
        raise ValueError("No safe pools found. Check your API key plan (requires Analyst or above).")

    token_addresses = [addr for addr, info in safe_pools]

    print(f"\n  🪙 Fetching price data for {len(token_addresses)} token(s)...")

    # Build query params
    params = {}
    if include_market_cap:
        params["include_market_cap"] = "true"
    if include_24hr_vol:
        params["include_24hr_vol"] = "true"
    if include_24hr_change:
        params["include_24hr_price_change"] = "true"
    if include_reserve:
        params["include_total_reserve_in_usd"] = "true"

    all_records = []
    timestamp = datetime.now(timezone.utc).isoformat()

    # Create lookup for pool info
    pool_info_lookup = {addr: info for addr, info in safe_pools}

    # Batch tokens (max 100 per request)
    batch_size = 100
    batches = [token_addresses[i:i + batch_size] for i in range(0, len(token_addresses), batch_size)]

    def fetch_batch(batch: List[str]) -> List[Dict]:
        try:
            addresses = ",".join(batch)
            url = f"{PRO_API_BASE}/onchain/simple/networks/{network}/token_price/{addresses}"

            response = _http_get_json(url, params, api_key=api_key)

            records = []

            # Response structure: data.attributes.{field_name}.{token_address}
            attrs = response.get("data", {}).get("attributes", {})

            # Extract fields
            token_prices = attrs.get("token_prices", {})
            market_caps = attrs.get("market_cap_usd", {})
            volumes = attrs.get("h24_volume_usd", {})
            price_changes = attrs.get("h24_price_change_percentage", {})
            reserves = attrs.get("total_reserve_in_usd", {})

            for token_addr, price_str in token_prices.items():
                token_addr_lower = token_addr.lower()

                # Get pool info
                pool_info = pool_info_lookup.get(token_addr_lower, {})

                # Parse price
                try:
                    price_usd = float(price_str) if price_str else None
                except (ValueError, TypeError):
                    price_usd = None

                record = {
                    "timestamp": timestamp,
                    "network": network,
                    "token_address": token_addr_lower,
                    "token_symbol": pool_info.get("token_symbol"),
                    "token_name": pool_info.get("token_name"),
                    "coingecko_coin_id": pool_info.get("coingecko_coin_id"),
                    "price_usd": price_usd,
                    "is_safe": True,  # All tokens from megafilter are safe
                }

                # Add optional fields
                if include_market_cap and token_addr_lower in market_caps:
                    try:
                        record["market_cap_usd"] = float(market_caps[token_addr_lower])
                    except (ValueError, TypeError):
                        record["market_cap_usd"] = pool_info.get("market_cap")  # Fallback to pool info

                if include_24hr_vol and token_addr_lower in volumes:
                    try:
                        record["volume_24h_usd"] = float(volumes[token_addr_lower])
                    except (ValueError, TypeError):
                        record["volume_24h_usd"] = pool_info.get("volume_24h")  # Fallback

                if include_24hr_change and token_addr_lower in price_changes:
                    try:
                        record["price_change_24h_pct_usd"] = float(price_changes[token_addr_lower])
                    except (ValueError, TypeError):
                        record["price_change_24h_pct_usd"] = None

                if include_reserve and token_addr_lower in reserves:
                    try:
                        record["total_reserve_usd"] = float(reserves[token_addr_lower])
                    except (ValueError, TypeError):
                        record["total_reserve_usd"] = pool_info.get("reserve_usd")  # Fallback

                # Add pool metadata
                record["best_pool_address"] = pool_info.get("pool_address")
                record["best_dex"] = pool_info.get("dex")

                records.append(record)

            return records

        except Exception as e:
            print(f"    ❌ Batch failed: {e}")
            return []

    # Fetch all batches in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(fetch_batch, batch): i for i, batch in enumerate(batches)}

        for future in as_completed(futures):
            batch_idx = futures[future]
            records = future.result()
            all_records.extend(records)
            print(f"    [{len(all_records):,} total] ✓ Batch {batch_idx + 1}/{len(batches)}: {len(records)} tokens")

    if not all_records:
        raise ValueError("No data collected")

    print(f"\n  ✓ Collected {len(all_records):,} safe token records")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Sort by market cap
    if "market_cap_usd" in df.columns:
        df = df.sort_values("market_cap_usd", ascending=False)

    # Load existing and append
    out_file = ctx.work_dir / "coingecko_onchain_safe.parquet"
    if out_file.exists():
        try:
            from ..api import load
            existing_df = load(ctx.dataset_id, as_format="pandas")
            print(f"\n  📦 Found existing dataset: {len(existing_df):,} records")

            df = pd.concat([existing_df, df], ignore_index=True)

            # Deduplicate on (timestamp, network, token_address)
            initial_count = len(df)
            df = df.drop_duplicates(subset=["timestamp", "network", "token_address"], keep="last")
            if len(df) < initial_count:
                print(f"  🧹 Removed {initial_count - len(df):,} duplicates")
        except Exception as e:
            print(f"  ℹ️  No existing dataset: {e}")

    df = df.reset_index(drop=True)

    # Save
    df.to_parquet(out_file, index=False)

    print(f"\n  ✅ Saved {len(df):,} records")
    print(f"  📊 Schema: {list(df.columns)}")

    # Show sample stats
    if len(df) > 0:
        latest = df[df["timestamp"] == df["timestamp"].max()]
        print(f"\n  📈 Latest snapshot ({latest.iloc[0]['timestamp']}):")
        print(f"     Safe tokens: {len(latest):,}")
        if "market_cap_usd" in df.columns:
            total_mc = latest["market_cap_usd"].sum()
            print(f"     Total market cap: ${total_mc:,.0f}")
        if "token_symbol" in df.columns:
            top3 = latest.head(3)
            print(f"     Top 3: {', '.join(top3['token_symbol'].tolist())}")

    readme = f"""# CoinGecko Safe Onchain Token Data

## Overview
Verified safe token prices from CoinGecko onchain API using megafilter

## Safety Filters Applied
- ✅ No honeypot tokens (verified by GoPlus & De.Fi Scanner)
- ✅ Good GT Score (>= 75)
- ✅ Listed on CoinGecko
- ✅ Has social links & token information

## Configuration
- **Network**: {network}
- **Top N**: {top_n}
- **Records**: {len(df):,}
- **Safe tokens**: {df["token_address"].nunique():,}

## Schema

{df.dtypes.to_string()}

## Primary Key
- `(timestamp, network, token_address)`

## Usage

```python
import warpdata as wd

# Load data
df = wd.load("{ctx.dataset_id}", as_format="pandas")

# Get latest safe tokens
latest = df[df["timestamp"] == df["timestamp"].max()]

# Top 10 by market cap
top10 = latest.nlargest(10, "market_cap_usd")
print(top10[["token_symbol", "price_usd", "market_cap_usd", "is_safe"]])
```

## Statistics
- Total records: {len(df):,}
- Unique tokens: {df["token_address"].nunique():,}
- Time snapshots: {df["timestamp"].nunique():,}
- Network: {network}
- All tokens verified safe: Yes
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "network": network,
            "top_n": top_n,
            "tokens": len(token_addresses),
            "records": len(df),
            "snapshots": df["timestamp"].nunique(),
            "source": "CoinGecko Onchain API (Megafilter)",
            "safety_filters": "no_honeypot,good_gt_score,on_coingecko,has_social",
        },
    )
