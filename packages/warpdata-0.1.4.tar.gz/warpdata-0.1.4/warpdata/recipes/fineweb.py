"""
FineWeb web text dataset recipe.

FineWeb is a large-scale English web corpus built from Common Crawl.

Source: https://huggingface.co/datasets/HuggingFaceFW/fineweb
Paper / blog: see dataset card for details.

This recipe builds a text+metadata table from a configurable FineWeb
config (e.g., 'sample-10BT') with an optional global row cap controlled
by the common ``--limit`` recipes CLI flag.

Schema (from HuggingFaceFW/fineweb):
    - text: str
    - id: str
    - dump: str
    - url: str
    - date: str
    - file_path: str
    - language: str
    - language_score: float
    - token_count: int

Note: The FineWeb dataset card declares language = 'en', so it is
effectively English-only. We still keep the 'language' column to enable
future multi-language variants and any downstream filtering.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Dict, Any, List

import pandas as pd
from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def fineweb(
    ctx: RecipeContext,
    repo_id: str = "HuggingFaceFW/fineweb",
    config: str = "sample-10BT",
    limit: Optional[int] = None,
) -> RecipeOutput:
    """
    Create a FineWeb text dataset.

    Args:
        ctx: Recipe context.
        repo_id: HuggingFace dataset ID (default: 'HuggingFaceFW/fineweb').
        config: FineWeb configuration to use. Good options include:
            - 'sample-10BT'   (recommended starting point)
            - 'sample-100BT'
            - 'sample-350BT'
            - 'default'       (full corpus; extremely large).
        limit: Maximum number of examples to process. This is wired up to
            the CLI ``--limit`` flag. ``None`` means "no explicit cap"
            (not recommended for full FineWeb, which is massive).

    Returns:
        RecipeOutput with a single Parquet file.

    Dataset columns:
        - text: str          – Web page content
        - id: str            – Example identifier
        - dump: str          – Common Crawl dump ID (e.g., 'CC-MAIN-2023-23')
        - url: str
        - date: str          – Crawl date
        - file_path: str     – Source path within the HF dataset
        - language: str      – Language code (FineWeb: usually 'en')
        - language_score: float
        - token_count: int   – Token count estimate

    Example:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "fineweb",
        ...     "warpdata://text/fineweb-1m",
        ...     config="sample-10BT",
        ...     limit=1_000_000,
        ...     with_materialize=True,
        ... )
        >>> df = wd.load("warpdata://text/fineweb-1m", as_format="pandas")
    """
    print(f"Loading FineWeb from {repo_id} (config={config})...")

    if limit is not None:
        print(f"Note: Limiting to {limit:,} examples (via --limit).")

    # Use streaming when we have a limit to avoid materializing the entire dataset.
    if limit is not None:
        print("Using streaming mode for efficient sampling.")
        ds = load_dataset(repo_id, config, split="train", streaming=True)
        all_records: List[Dict[str, Any]] = []

        for idx, example in enumerate(ds):
            if idx >= limit:
                break

            record = {
                "text": str(example.get("text", "")),
                "id": str(example.get("id", "")),
                "dump": str(example.get("dump", "")),
                "url": str(example.get("url", "")),
                "date": str(example.get("date", "")),
                "file_path": str(example.get("file_path", "")),
                "language": str(example.get("language", "")),
                "language_score": float(example.get("language_score", 0.0))
                if example.get("language_score") is not None
                else None,
                "token_count": int(example.get("token_count", 0))
                if example.get("token_count") is not None
                else None,
            }
            all_records.append(record)

            if (idx + 1) % 100_000 == 0:
                print(f"  Processed {idx + 1:,} examples...")

        total = len(all_records)
    else:
        print("Warning: limit is None – loading full split in non-streaming mode.")
        ds = load_dataset(repo_id, config, split="train")
        print(f"  Split size: {len(ds):,} examples")

        all_records = []
        for idx, example in enumerate(ds):
            record = {
                "text": str(example.get("text", "")),
                "id": str(example.get("id", "")),
                "dump": str(example.get("dump", "")),
                "url": str(example.get("url", "")),
                "date": str(example.get("date", "")),
                "file_path": str(example.get("file_path", "")),
                "language": str(example.get("language", "")),
                "language_score": float(example.get("language_score", 0.0))
                if example.get("language_score") is not None
                else None,
                "token_count": int(example.get("token_count", 0))
                if example.get("token_count") is not None
                else None,
            }
            all_records.append(record)

            if (idx + 1) % 1_000_000 == 0:
                print(f"  Processed {idx + 1:,} examples...")

        total = len(all_records)

    print(f"\nTotal examples collected: {total:,}")

    # Create DataFrame and write to Parquet.
    df = pd.DataFrame(all_records)
    out_path = ctx.work_dir / "fineweb.parquet"
    df.to_parquet(out_path, index=False)
    print(f"Saved to {out_path}")

    # Track raw data provenance (HF cache directory).
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[out_path],
        metadata={
            "total_examples": total,
            "repo_id": repo_id,
            "config": config,
            "limit": limit,
            "language": "en",
        },
        raw_data=raw_data_paths,
    )

