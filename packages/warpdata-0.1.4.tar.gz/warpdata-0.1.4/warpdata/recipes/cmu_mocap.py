"""
CMU Motion Capture Database Recipe.

Processes the Carnegie Mellon University Graphics Lab Motion Capture Database.
This is one of the largest freely available motion capture databases with 2,300+
motions across 144 subjects performing various activities.

Dataset: CMU Graphics Lab Motion Capture Database
Source: http://mocap.cs.cmu.edu
Format: BVH (BioVision Hierarchy) files
License: Free for research and commercial use

Features:
- 2,309 motion capture sequences
- 144 subjects (various actors/performers)
- Activities: dance, sports, locomotion, actions, interactions
- 120 fps sampling rate
- MotionBuilder-friendly skeleton hierarchy
- Professional motion capture quality

The BVH files contain:
- Skeleton hierarchy (31 joints)
- Frame-by-frame rotation/position data
- 96 channels per frame
- T-pose in frame 0

This recipe creates two datasets:
1. Main: Individual motion sequences with metadata
2. Subjects: Subject-level information with activity categories
"""
from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import re

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


def _parse_bvh_metadata(bvh_path: Path) -> Dict:
    """
    Parse BVH file to extract motion metadata.

    Args:
        bvh_path: Path to BVH file

    Returns:
        Dict with num_frames, frame_time, fps, duration_sec, num_channels
    """
    with open(bvh_path, 'r') as f:
        lines = f.readlines()

    # Find MOTION section
    motion_idx = None
    for i, line in enumerate(lines):
        if line.strip() == 'MOTION':
            motion_idx = i
            break

    if motion_idx is None:
        return {
            'num_frames': 0,
            'frame_time': 0.0,
            'fps': 0.0,
            'duration_sec': 0.0,
            'num_channels': 0
        }

    # Parse Frames line
    frames_line = lines[motion_idx + 1].strip()
    num_frames = int(frames_line.split(':')[1].strip())

    # Parse Frame Time line
    frame_time_line = lines[motion_idx + 2].strip()
    frame_time = float(frame_time_line.split(':')[1].strip())

    # Calculate FPS and duration
    fps = 1.0 / frame_time if frame_time > 0 else 0.0
    duration_sec = num_frames * frame_time

    # Count channels from first data line
    if motion_idx + 3 < len(lines):
        first_data = lines[motion_idx + 3].strip().split()
        num_channels = len(first_data)
    else:
        num_channels = 0

    return {
        'num_frames': num_frames,
        'frame_time': frame_time,
        'fps': round(fps, 2),
        'duration_sec': round(duration_sec, 2),
        'num_channels': num_channels
    }


def _parse_motion_index(index_path: Path) -> Dict[str, Dict]:
    """
    Parse the CMU motion index text file.

    Returns:
        Dict mapping "subject_motion" -> {'description': str, 'subject_desc': str}
        e.g., "01_01" -> {'description': 'playground - forward jumps', 'subject_desc': 'climb, swing'}
    """
    with open(index_path, 'r') as f:
        lines = f.readlines()

    motion_index = {}
    current_subject = None
    current_subject_desc = None

    for line in lines:
        line = line.strip()

        # Skip empty lines and headers
        if not line or line.startswith('Carnegie') or line.startswith('Compiled') or line.startswith('CMU'):
            continue

        # Check for subject line (e.g., "Subject #1 (climb, swing, hang on playground equipment)")
        subject_match = re.match(r'Subject #(\d+)\s*\(([^)]*)\)', line)
        if subject_match:
            current_subject = int(subject_match.group(1))
            current_subject_desc = subject_match.group(2).strip()
            continue

        # Check for motion line (e.g., "01_01\twalk")
        motion_match = re.match(r'(\d+)_(\d+)\s+(.+)', line)
        if motion_match and current_subject is not None:
            subject_id = int(motion_match.group(1))
            motion_id = int(motion_match.group(2))
            description = motion_match.group(3).strip()

            key = f"{subject_id:02d}_{motion_id:02d}"
            motion_index[key] = {
                'description': description,
                'subject_desc': current_subject_desc if current_subject_desc else 'Unknown'
            }

    return motion_index


def _extract_category(subject_desc: str, motion_desc: str) -> str:
    """
    Extract primary category from subject and motion descriptions.

    Args:
        subject_desc: Subject description (e.g., "modern dance")
        motion_desc: Motion description (e.g., "dance - pirouette")

    Returns:
        Category string (e.g., "dance", "sports", "locomotion")
    """
    combined = f"{subject_desc} {motion_desc}".lower()

    # Define category keywords (order matters - more specific first)
    categories = [
        ('dance', ['dance', 'ballet', 'pirouette', 'arabesque']),
        ('basketball', ['basketball', 'dribble', 'shoot']),
        ('boxing', ['boxing', 'punch', 'jab']),
        ('martial_arts', ['martial', 'kung fu', 'karate', 'kick']),
        ('gymnastics', ['gymnast', 'cartwheel', 'flip']),
        ('playground', ['playground', 'climb', 'swing', 'hang']),
        ('sports', ['sport', 'tennis', 'soccer', 'football']),
        ('locomotion', ['walk', 'run', 'jog', 'jump', 'hop', 'skip']),
        ('interaction', ['interaction', 'shake hands', 'give', 'take']),
        ('pantomime', ['pantomime', 'act', 'gesture']),
        ('everyday', ['sit', 'stand', 'wash', 'clean', 'pick up']),
    ]

    for category, keywords in categories:
        if any(kw in combined for kw in keywords):
            return category

    return 'other'


def cmu_mocap(ctx: RecipeContext, **options) -> RecipeOutput:
    """
    Process CMU Motion Capture Database from local BVH files.

    Options:
        mocap_root (str): Root directory containing cmu_mocap data
                         (default: ./recipes_raw_data/cmu_mocap)
        limit (int): Limit number of motions to process (default: all)
        subjects (list[int]): Process only specific subjects (default: all)

    Returns:
        RecipeOutput with main motions dataset and subjects subdataset.
    """
    import pandas as pd

    # Get options
    mocap_root = Path(options.get('mocap_root', './recipes_raw_data/cmu_mocap'))
    limit = options.get('limit', None)
    subject_filter = options.get('subjects', None)

    print(f"📂 Loading CMU MoCap data from {mocap_root}")

    # Check if directory exists
    if not mocap_root.exists():
        raise FileNotFoundError(
            f"CMU MoCap directory not found: {mocap_root}\n"
            f"Please ensure data is downloaded to this location."
        )

    data_dir = mocap_root / 'data'
    index_file = mocap_root / 'cmu-mocap-index-text.txt'

    if not data_dir.exists():
        raise FileNotFoundError(f"Data directory not found: {data_dir}")

    if not index_file.exists():
        raise FileNotFoundError(f"Index file not found: {index_file}")

    # Parse motion index
    print("📋 Parsing motion index...")
    motion_index = _parse_motion_index(index_file)
    print(f"   Found {len(motion_index)} motion descriptions")

    # Find all BVH files
    print("🔍 Scanning for BVH files...")
    subject_dirs = sorted([d for d in data_dir.iterdir() if d.is_dir()])

    motions_data = []
    subjects_data = {}

    total_processed = 0

    for subject_dir in subject_dirs:
        subject_id = int(subject_dir.name)

        # Filter by subject if specified
        if subject_filter and subject_id not in subject_filter:
            continue

        # Find BVH files for this subject
        bvh_files = sorted(subject_dir.glob('*.bvh'))

        if not bvh_files:
            continue

        for bvh_file in bvh_files:
            # Check limit
            if limit and total_processed >= limit:
                break

            # Parse filename (e.g., "01_01.bvh")
            filename = bvh_file.stem
            parts = filename.split('_')
            if len(parts) != 2:
                continue

            motion_id = int(parts[1])

            # Get metadata
            metadata = _parse_bvh_metadata(bvh_file)

            # Get description from index
            index_key = f"{subject_id:02d}_{motion_id:02d}"
            if index_key in motion_index:
                description = motion_index[index_key]['description']
                subject_desc = motion_index[index_key]['subject_desc']
            else:
                description = "Unknown"
                subject_desc = "Unknown"

            # Extract category
            category = _extract_category(subject_desc, description)

            # Add motion data
            motions_data.append({
                'subject_id': subject_id,
                'motion_id': motion_id,
                'filename': filename + '.bvh',
                'file_path': str(bvh_file.absolute()),
                'description': description,
                'subject_description': subject_desc,
                'category': category,
                'num_frames': metadata['num_frames'],
                'duration_sec': metadata['duration_sec'],
                'fps': metadata['fps'],
                'num_channels': metadata['num_channels'],
            })

            # Track subject info
            if subject_id not in subjects_data:
                subjects_data[subject_id] = {
                    'subject_id': subject_id,
                    'description': subject_desc,
                    'num_motions': 0,
                    'category': category,
                    'total_duration_sec': 0.0
                }

            subjects_data[subject_id]['num_motions'] += 1
            subjects_data[subject_id]['total_duration_sec'] += metadata['duration_sec']

            total_processed += 1

        if limit and total_processed >= limit:
            break

    print(f"✅ Processed {len(motions_data)} motions from {len(subjects_data)} subjects")

    # Create DataFrames
    motions_df = pd.DataFrame(motions_data)
    subjects_df = pd.DataFrame(list(subjects_data.values()))

    # Round total duration
    subjects_df['total_duration_sec'] = subjects_df['total_duration_sec'].round(2)

    # Save datasets
    main_path = ctx.work_dir / "cmu_mocap.parquet"
    subjects_path = ctx.work_dir / "cmu_mocap_subjects.parquet"

    print(f"💾 Saving datasets...")
    motions_df.to_parquet(main_path, index=False)
    subjects_df.to_parquet(subjects_path, index=False)

    # Generate statistics for documentation
    stats = {
        'total_motions': len(motions_df),
        'total_subjects': len(subjects_df),
        'total_duration_hours': motions_df['duration_sec'].sum() / 3600,
        'avg_duration_sec': motions_df['duration_sec'].mean(),
        'categories': motions_df['category'].value_counts().to_dict()
    }

    # Write documentation
    doc_content = f"""# CMU Motion Capture Database

## Overview
Carnegie Mellon University Graphics Lab Motion Capture Database in BVH format.
One of the largest freely available motion capture databases.

## Statistics
- Total motions: {stats['total_motions']:,}
- Total subjects: {stats['total_subjects']}
- Total duration: {stats['total_duration_hours']:.1f} hours
- Average motion duration: {stats['avg_duration_sec']:.1f} seconds
- Frame rate: 120 fps
- Channels per frame: 96

## Categories
{chr(10).join(f"- {cat}: {count} motions" for cat, count in sorted(stats['categories'].items(), key=lambda x: -x[1]))}

## Schema

### Main Dataset (cmu_mocap)
- `subject_id`: Subject number (1-144)
- `motion_id`: Motion number within subject
- `filename`: BVH filename (e.g., "01_01.bvh")
- `file_path`: Absolute path to BVH file
- `description`: Motion description
- `subject_description`: Subject activity description
- `category`: Motion category (dance, sports, locomotion, etc.)
- `num_frames`: Number of motion frames
- `duration_sec`: Motion duration in seconds
- `fps`: Frames per second (120)
- `num_channels`: Number of data channels (96)

### Subjects Subdataset (cmu_mocap-subjects)
- `subject_id`: Subject number
- `description`: Subject activity description
- `num_motions`: Number of motions for this subject
- `category`: Primary activity category
- `total_duration_sec`: Total duration of all motions

## Usage

```python
import warpdata as wd
from pathlib import Path

# Load motions
motions = wd.load("warpdata://mocap/cmu", as_format="pandas")

# Load subjects
subjects = wd.load("warpdata://mocap/cmu-subjects", as_format="pandas")

# Filter by category
dance = motions[motions['category'] == 'dance']
print(f"Dance motions: {{len(dance)}}")

# Get BVH file path
bvh_path = Path(motions.iloc[0]['file_path'])
print(f"BVH file: {{bvh_path}}")

# Analyze by subject
subject_1 = motions[motions['subject_id'] == 1]
print(f"Subject 1: {{subject_1['description'].iloc[0]}}")
print(f"Motions: {{len(subject_1)}}")

# Statistics by category
category_stats = motions.groupby('category').agg({{
    'duration_sec': ['count', 'sum', 'mean']
}}).round(2)
print(category_stats)
```

## BVH File Format

BVH files contain:
1. **HIERARCHY**: Skeleton structure with 31 joints
2. **MOTION**: Frame-by-frame animation data
   - Frame 0: T-pose (MotionBuilder-friendly)
   - Frames 1+: Captured motion data

Skeleton hierarchy:
- Root: Hips
- Legs: LeftUpLeg, LeftLeg, LeftFoot, LeftToeBase (mirrored for right)
- Spine: LowerBack, Spine, Spine1
- Arms: LeftShoulder, LeftArm, LeftForeArm, LeftHand (mirrored for right)
- Head: Neck, Neck1, Head

## Citation

If you use CMU Motion Capture Database, please cite:

```
@misc{{cmu_mocap,
  title={{CMU Graphics Lab Motion Capture Database}},
  author={{Carnegie Mellon University}},
  url={{http://mocap.cs.cmu.edu}},
  note={{Accessed: {pd.Timestamp.now().strftime('%Y-%m-%d')}}}
}}
```

And include the acknowledgment:
"The data used in this project was obtained from mocap.cs.cmu.edu.
The database was created with funding from NSF EIA-0196217."

## Notes

- BVH files are in MotionBuilder-friendly format (Bruce Hahne conversion)
- T-pose in frame 0 for proper retargeting
- Files sampled at 120 fps
- No finger motion data (joints present but not captured)
- Higher numbered subjects generally have better quality
- Free for research and commercial use

## Resources

- Original database: http://mocap.cs.cmu.edu
- BVH format info: https://research.cs.wisc.edu/graphics/Courses/cs-838-1999/Jeff/BVH.html
- MotionBuilder: https://www.autodesk.com/products/motionbuilder
"""

    ctx.write_documentation("README.md", doc_content)

    print(f"✅ CMU MoCap dataset created successfully!")
    print(f"   Motions: {len(motions_df)}")
    print(f"   Subjects: {len(subjects_df)}")
    print(f"   Total duration: {stats['total_duration_hours']:.1f} hours")

    return RecipeOutput(
        main=[main_path],
        subdatasets={
            'subjects': SubDataset(
                name='cmu_mocap-subjects',
                files=[subjects_path],
                description='Subject metadata with activity categories'
            )
        }
    )
