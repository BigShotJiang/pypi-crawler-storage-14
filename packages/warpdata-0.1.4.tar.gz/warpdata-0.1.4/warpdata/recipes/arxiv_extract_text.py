"""
ArXiv Text Extraction Recipe.

Extracts text from PDFs using fast methods (pdftotext/PyPDF).
Idempotent: checks pdf_sha1 to avoid reprocessing.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Optional, Set
import re
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput
from tqdm import tqdm


def _which(exe: str) -> bool:
    """Check if executable is available."""
    from shutil import which
    return which(exe) is not None


def _fast_text_from_pdf(pdf_path: str, max_pages: Optional[int] = None) -> str:
    """
    Extract text from PDF using fast methods.

    Tries:
    1. pdftotext (poppler-utils) - fast native extractor
    2. PyPDF2 - Python fallback

    Args:
        pdf_path: Path to PDF file
        max_pages: Optional limit on pages to extract

    Returns:
        Extracted text or empty string
    """
    # Try pdftotext first (fastest)
    if _which("pdftotext"):
        try:
            import subprocess
            args = ["pdftotext", "-layout", "-q"]
            if max_pages is not None:
                args += ["-f", "1", "-l", str(max_pages)]
            args += [pdf_path, "-"]
            result = subprocess.run(
                args, capture_output=True, text=True, timeout=20, check=False
            )
            if result.returncode == 0 and result.stdout:
                return result.stdout.strip()
        except Exception:
            pass

    # Fallback to PyPDF2
    try:
        from PyPDF2 import PdfReader
        txt_parts = []
        with open(pdf_path, "rb") as f:
            reader = PdfReader(f)
            pages = reader.pages[: (max_pages or len(reader.pages))]
            for page in pages:
                text = page.extract_text() or ""
                if text:
                    txt_parts.append(text)
        return "\n".join(txt_parts).strip()
    except Exception:
        pass

    return ""


# Regex patterns for content analysis
_HAS_EQUATIONS_RE = re.compile(r'\$|\\\[|\\\(', re.IGNORECASE)
_HAS_FIGURES_RE = re.compile(r'\bfigure\b|fig\.', re.IGNORECASE)
_HAS_TABLES_RE = re.compile(r'\btable\b|\|.*\|', re.IGNORECASE)


def arxiv_extract_text(
    ctx: RecipeContext,
    staged_id: str = "warpdata://arxiv/staged",
    pdf_method: str = "fast",
    max_pages: Optional[int] = None,
    existing_text_id: Optional[str] = None,  # Skip pdf_sha1 matches from this dataset
    workers: int = 1,  # Parallel extractors (threads)
) -> RecipeOutput:
    """
    Extract text from staged PDFs using fast methods.

    Idempotent: can skip already-processed PDFs if existing_text_id is provided.

    Args:
        ctx: Recipe context
        staged_id: Dataset ID for staged papers
        pdf_method: Extraction method ("fast" only in this version)
        max_pages: Optional page limit (None = all pages)
        existing_text_id: Optional dataset to skip PDFs already processed (checked via pdf_sha1)
        workers: Number of parallel extractors (threads)

    Returns:
        RecipeOutput with text Parquet

    Schema:
        All columns from staged, plus:
        - full_content: string (extracted text)
        - content_length: int64
        - has_full_content: bool
        - extraction_method: string ("fast-text")
        - extraction_timestamp: string (ISO format)
        - extraction_failed: bool
        - has_equations: bool
        - has_figures: bool
        - has_tables: bool
    """
    if pdf_method != "fast":
        raise ValueError(f"Only pdf_method='fast' supported in this version, got: {pdf_method}")

    print("📝 Extracting text from staged PDFs...")

    # Load staged papers
    print(f"   Loading staged papers: {staged_id}")
    try:
        import warpdata as wd
        staged_df = wd.load(staged_id, as_format="pandas")
    except Exception as e:
        raise ValueError(f"Could not load staged dataset {staged_id}: {e}")

    if len(staged_df) == 0:
        print("   ⚠️  No papers to process")
        # Create empty output with schema
        import pandas as pd
        empty_df = pd.DataFrame({"arxiv_id": []})  # At least one column for DuckDB
        empty_rel = ctx.engine.conn.from_df(empty_df)
        out_path = ctx.work_dir / "text.parquet"
        ctx.write_parquet(empty_rel, out_path)

        return RecipeOutput(
            main=[out_path],
            subdatasets={},
            docs={"README.md": "# ArXiv Text\n\nNo papers to process.\n"},
            metadata={"total_processed": 0, "success_count": 0, "failed_count": 0},
        )

    # Optional: load existing text dataset to skip by pdf_sha1
    skip_sha1s: Set[str] = set()
    if existing_text_id:
        try:
            import warpdata as wd
            existing_df = wd.load(existing_text_id, as_format="pandas")
            if "pdf_sha1" in existing_df.columns:
                skip_sha1s = set(existing_df["pdf_sha1"].dropna().unique())
                print(f"   Found {len(skip_sha1s)} already-processed PDFs in {existing_text_id}")
        except Exception as e:
            print(f"   ⚠️  Could not load existing_text_id={existing_text_id}: {e}")

    if skip_sha1s and "pdf_sha1" in staged_df.columns:
        before = len(staged_df)
        staged_df = staged_df[~staged_df["pdf_sha1"].isin(skip_sha1s)]
        skipped = before - len(staged_df)
        print(f"   Skipping {skipped} PDFs already processed (pdf_sha1 match)")

    if len(staged_df) == 0:
        print("   ⚠️  No papers to process after skipping existing")
        # Create empty output with schema
        import pandas as pd
        empty_df = pd.DataFrame({"arxiv_id": []})  # At least one column for DuckDB
        empty_rel = ctx.engine.conn.from_df(empty_df)
        out_path = ctx.work_dir / "text.parquet"
        ctx.write_parquet(empty_rel, out_path)

        return RecipeOutput(
            main=[out_path],
            subdatasets={},
            docs={"README.md": "# ArXiv Text\n\nNo papers to process.\n"},
            metadata={"total_processed": 0, "success_count": 0, "failed_count": 0},
        )

    print(f"   Processing {len(staged_df)} papers (workers={workers})...")

    def _process_record(rec: Dict[str, Any]) -> Dict[str, Any]:
        """Extract text for a single record and return updated dict."""
        pdf_path = rec.get("path")
        text = ""
        extraction_failed = False
        if pdf_path and Path(pdf_path).exists():
            try:
                text = _fast_text_from_pdf(pdf_path, max_pages=max_pages)
                if not text:
                    extraction_failed = True
                    rec["error_message"] = "No text extracted (empty or scan)"
            except Exception as e:
                extraction_failed = True
                rec["error_message"] = f"Extraction error: {str(e)}"
        else:
            extraction_failed = True
            rec["error_message"] = f"PDF not found: {pdf_path}"

        rec["full_content"] = text
        rec["content_length"] = len(text)
        rec["has_full_content"] = len(text) > 0
        rec["extraction_method"] = "fast-text" if not extraction_failed else None
        rec["extraction_timestamp"] = datetime.now().isoformat()
        rec["extraction_failed"] = extraction_failed

        if text:
            rec["has_equations"] = bool(_HAS_EQUATIONS_RE.search(text))
            rec["has_figures"] = bool(_HAS_FIGURES_RE.search(text))
            rec["has_tables"] = bool(_HAS_TABLES_RE.search(text))
        else:
            rec["has_equations"] = None
            rec["has_figures"] = None
            rec["has_tables"] = None

        return rec

    rows: List[Dict[str, Any]] = []
    success_count = 0
    failed_count = 0

    records = staged_df.to_dict(orient="records")

    if workers <= 1:
        for rec in tqdm(records, desc="Extracting", unit="pdf"):
            rec = _process_record(rec)
            rows.append(rec)
            if rec.get("has_full_content"):
                success_count += 1
            else:
                failed_count += 1
    else:
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_process_record, rec): rec for rec in records}
            with tqdm(total=len(records), desc="Extracting", unit="pdf") as pbar:
                for future in as_completed(futures):
                    rec = future.result()
                    rows.append(rec)
                    if rec.get("has_full_content"):
                        success_count += 1
                    else:
                        failed_count += 1
                    pbar.update(1)

    print(f"   ✅ Success: {success_count}")
    print(f"   ❌ Failed: {failed_count}")

    # Write text dataset
    import pandas as pd
    text_df = pd.DataFrame(rows)

    text_rel = ctx.engine.conn.from_df(text_df)
    out_path = ctx.work_dir / "text.parquet"
    ctx.write_parquet(text_rel, out_path)

    print(f"   Wrote text dataset: {out_path}")

    # Generate stats
    if len(text_df) > 0:
        avg_length = text_df[text_df["has_full_content"]]["content_length"].mean() if text_df["has_full_content"].sum() > 0 else 0
        with_equations = int(text_df["has_equations"].sum()) if "has_equations" in text_df.columns else 0
        with_figures = int(text_df["has_figures"].sum()) if "has_figures" in text_df.columns else 0
        with_tables = int(text_df["has_tables"].sum()) if "has_tables" in text_df.columns else 0
        cat_counts = {}
        for idx, row in text_df.iterrows():
            cats = row.get("categories")
            if isinstance(cats, list):
                for cat in cats:
                    cat_counts[cat] = cat_counts.get(cat, 0) + 1
    else:
        avg_length = 0
        with_equations = 0
        with_figures = 0
        with_tables = 0
        cat_counts = {}

    readme = f"""# ArXiv Text Extraction

## Overview
Full-text content extracted from ArXiv PDFs using fast methods.

## Statistics
- **Total papers**: {len(rows)}
- **Successfully extracted**: {success_count}
- **Failed**: {failed_count}
- **Success rate**: {100 * success_count / len(rows) if rows else 0:.1f}%
- **Average content length**: {avg_length:.0f} chars
- **Papers with equations**: {with_equations}
- **Papers with figures**: {with_figures}
- **Papers with tables**: {with_tables}

## Extraction Method
- **Method**: Fast text extraction (pdftotext → PyPDF2 fallback)
- **Max pages**: {max_pages or "All"}
- **Source**: {staged_id}

## Top Categories
"""
    for cat, count in sorted(cat_counts.items(), key=lambda x: -x[1])[:20]:
        readme += f"- **{cat}**: {count} papers\n"

    readme += """
## Schema
All metadata columns plus:
- `full_content`: Extracted text content
- `content_length`: Character count
- `has_full_content`: True if extraction succeeded
- `extraction_method`: "fast-text" or None
- `extraction_timestamp`: ISO timestamp
- `extraction_failed`: True if extraction failed
- `has_equations`: Boolean (LaTeX math detected)
- `has_figures`: Boolean ("figure" keyword detected)
- `has_tables`: Boolean (table patterns detected)
- `pdf_sha1`: SHA1 fingerprint for deduplication

## Usage
```python
import warpdata as wd

# Load text dataset
text = wd.load("warpdata://arxiv/papers-text", as_format="pandas")
print(f"Papers with text: {text['has_full_content'].sum()}")

# Filter successful extractions
success = text[text["has_full_content"]]
print(f"Average length: {success['content_length'].mean():.0f} chars")

# Find papers with equations
math_papers = text[text["has_equations"]]
print(f"Math papers: {len(math_papers)}")
```

## Next Steps
To add embeddings:
```python
import warpdata as wd

# Abstract embeddings
wd.add_embeddings(
    "warpdata://arxiv/papers-text",
    space="abstract-gemma-300m",
    provider="sentence-transformers",
    model="google/gemma-300m",
    source={"columns": ["abstract"]},
)

# Content embeddings
wd.add_embeddings(
    "warpdata://arxiv/papers-text",
    space="content-gemma-300m",
    provider="sentence-transformers",
    model="google/gemma-300m",
    source={"columns": ["full_content"]},
)

# Title embeddings
wd.add_embeddings(
    "warpdata://arxiv/papers-text",
    space="title-gemma-300m",
    provider="sentence-transformers",
    model="google/gemma-300m",
    source={"columns": ["title"]},
)
```
"""

    return RecipeOutput(
        main=[out_path],
        subdatasets={},
        docs={"README.md": readme},
        metadata={
            "staged_id": staged_id,
            "pdf_method": pdf_method,
            "max_pages": max_pages,
            "total_processed": len(rows),
            "success_count": success_count,
            "failed_count": failed_count,
            "success_rate": 100 * success_count / len(rows) if rows else 0,
            "workers": workers,
        },
    )
