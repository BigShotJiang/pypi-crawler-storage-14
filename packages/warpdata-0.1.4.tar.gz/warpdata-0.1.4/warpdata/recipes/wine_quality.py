"""
UCI Wine Quality dataset recipe.

Downloads red and white wine quality datasets from UCI ML Repository,
combines them with a wine_type column, and normalizes to Parquet.

Source: https://archive.ics.uci.edu/ml/datasets/wine+quality
"""
from pathlib import Path
from typing import List

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput
from ..core.utils import safe_filename


def wine_quality(ctx: RecipeContext, include_white: bool = True) -> RecipeOutput:
    """
    Create UCI Wine Quality dataset.

    Downloads CSV files from UCI ML Repository, adds wine_type column,
    combines red and optionally white wines, and outputs to Parquet.

    Args:
        ctx: Recipe context
        include_white: If True, include white wine data (default: True)

    Returns:
        List with single Parquet file path

    Examples:
        >>> import warpdata as wd
        >>> version = wd.run_recipe("wine_quality", "warpdata://uci/wine")
        >>> data = wd.load("warpdata://uci/wine", as_format="pandas")
        >>> print(data["wine_type"].value_counts())
    """
    # UCI ML Repository URLs
    red_url = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv"
    white_url = "https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-white.csv"

    # Download red wine data
    red_csv = ctx.download(red_url)

    # Build relation with proper delimiter (semicolon) and headers
    # UCI wine quality CSVs use semicolon delimiter
    red = ctx.engine.conn.read_csv(str(red_csv), header=True, sep=";")

    # Add wine_type column
    red_typed = ctx.engine.conn.sql("""
        SELECT 'red' AS wine_type, *
        FROM red
    """)

    # Optionally include white wine
    if include_white:
        white_csv = ctx.download(white_url)
        white = ctx.engine.conn.read_csv(str(white_csv), header=True, sep=";")

        white_typed = ctx.engine.conn.sql("""
            SELECT 'white' AS wine_type, *
            FROM white
        """)

        # Union red and white
        combined = red_typed.union(white_typed)
    else:
        combined = red_typed

    # Normalize column names (replace spaces with underscores, lowercase)
    # Get columns from the relation
    columns = combined.columns
    normalized_cols = [col.replace(" ", "_").lower() for col in columns]

    # Build SELECT with renamed columns
    select_parts = [
        f'"{col}" AS {norm_col}'
        for col, norm_col in zip(columns, normalized_cols)
    ]
    normalize_sql = f"""
        SELECT {', '.join(select_parts)}
        FROM combined
    """

    normalized = ctx.engine.conn.sql(normalize_sql)

    # Write to single Parquet file
    out = ctx.work_dir / f"{safe_filename(ctx.uri.name)}.parquet"
    ctx.write_parquet(normalized, out)

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / "wine_quality"
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[out],
        metadata={
            'include_white': include_white,
            'source': 'UCI ML Repository',
        },
        raw_data=raw_data_paths,
    )
