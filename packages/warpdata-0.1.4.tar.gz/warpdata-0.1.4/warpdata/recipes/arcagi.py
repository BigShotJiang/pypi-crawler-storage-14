"""
ARC-AGI-1 (Abstraction and Reasoning Corpus) recipe.

Processes local ARC-AGI-1 task JSON files into a normalized tabular dataset
with one row per input/output pair. Stores grids as JSON strings and provides
shape, color histogram, and split metadata for robust, query-friendly schema.

Raw data layout expected (from ARC-AGI-1 repo):
  ./recipes_raw_data/ARCAGI/
    data/
      training/*.json     # 400 tasks
      evaluation/*.json   # 400 tasks

Each task JSON contains:
  { "train": [{"input": [[...]], "output": [[...]]}, ...],
    "test":  [{"input": [[...]], "output": [[...]]}, ...] }

Main dataset columns:
  - task_id: str           Unique task identifier (filename stem)
  - split: str             "training" or "evaluation" (task split)
  - pair_type: str         "train" or "test" (pair grouping in task)
  - pair_index: int        Index within pair_type
  - input_json: str        JSON string of input grid (list[list[int]])
  - output_json: str       JSON string of output grid (list[list[int]])
  - input_height: int      Rows in input grid
  - input_width: int       Cols in input grid
  - output_height: int     Rows in output grid
  - output_width: int      Cols in output grid
  - input_cells: int       input_height * input_width
  - output_cells: int      output_height * output_width
  - input_n_colors: int    Number of distinct colors in input grid
  - output_n_colors: int   Number of distinct colors in output grid
  - input_color_hist: str  JSON {color:int -> count:int}
  - output_color_hist: str JSON {color:int -> count:int}

Notes:
  - We keep a single, well-defined schema and avoid subdatasets; training vs
    evaluation and train vs test are modeled as filterable columns.
  - Grids are stored as JSON strings to ensure stable Parquet typing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, Any, List
import json
from collections import Counter

import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def _grid_shape(grid: List[List[int]]) -> tuple[int, int]:
    h = len(grid)
    w = len(grid[0]) if h > 0 else 0
    return h, w


def _color_hist_json(grid: List[List[int]]) -> tuple[int, str]:
    flat = [v for row in grid for v in row]
    hist = Counter(flat)
    return len(hist), json.dumps({int(k): int(v) for k, v in hist.items()}, ensure_ascii=False)


def arcagi(
    ctx: RecipeContext,
    data_root: str = "./recipes_raw_data/ARCAGI",
    data_dir: str | None = None,
    limit: int | None = None,
) -> RecipeOutput:
    """
    Create ARC-AGI-1 dataset from local JSON tasks.

    Args:
      ctx: Recipe context
      data_root: Path to ARC-AGI-1 repository root containing data/ subfolder

    Returns:
      RecipeOutput with a single Parquet for all pairs.
    """
    # Resolve data directory (support either repo root or direct data dir)
    if data_dir:
        data_dir = Path(data_dir).resolve()
        root = data_dir.parent
    else:
        root = Path(data_root).resolve()
        data_dir = root / "data"
    train_dir = data_dir / "training"
    eval_dir = data_dir / "evaluation"

    if not data_dir.exists():
        raise FileNotFoundError(f"ARC-AGI-1 data directory not found: {data_dir}")
    if not train_dir.exists() or not eval_dir.exists():
        raise FileNotFoundError(f"Expected training/evaluation subfolders under: {data_dir}")

    records: List[Dict[str, Any]] = []
    total_tasks = 0

    for split_name, split_path in (("training", train_dir), ("evaluation", eval_dir)):
        json_files = sorted(split_path.glob("*.json"))
        if limit is not None:
            json_files = json_files[: max(0, int(limit))]
        total_tasks += len(json_files)
        print(f"Processing {len(json_files)} tasks from {split_name}...")

        for jf in json_files:
            task_id = jf.stem
            with open(jf, "r", encoding="utf-8") as fh:
                task = json.load(fh)

            for pair_type in ("train", "test"):
                pairs = task.get(pair_type, [])
                for idx, pair in enumerate(pairs):
                    inp = pair.get("input", [])
                    out = pair.get("output", [])

                    ih, iw = _grid_shape(inp)
                    oh, ow = _grid_shape(out)
                    in_colors, in_hist_json = _color_hist_json(inp)
                    out_colors, out_hist_json = _color_hist_json(out)

                    records.append(
                        {
                            "task_id": task_id,
                            "split": split_name,
                            "pair_type": pair_type,
                            "pair_index": idx,
                            "input_json": json.dumps(inp, ensure_ascii=False),
                            "output_json": json.dumps(out, ensure_ascii=False),
                            "input_height": ih,
                            "input_width": iw,
                            "output_height": oh,
                            "output_width": ow,
                            "input_cells": ih * iw,
                            "output_cells": oh * ow,
                            "input_n_colors": in_colors,
                            "output_n_colors": out_colors,
                            "input_color_hist": in_hist_json,
                            "output_color_hist": out_hist_json,
                        }
                    )

    df = pd.DataFrame.from_records(records)

    out_path = ctx.work_dir / "arcagi.parquet"
    df.to_parquet(out_path, index=False)

    # Build metadata and docs
    metadata = {
        "total_rows": int(len(df)),
        "total_tasks": int(total_tasks),
        "splits": {k: int(v) for k, v in df["split"].value_counts().to_dict().items()},
        "pair_types": {k: int(v) for k, v in df["pair_type"].value_counts().to_dict().items()},
        "columns": {
            "task_id": {"type": "string", "description": "Task identifier (filename stem)"},
            "split": {"type": "string", "enum": ["training", "evaluation"]},
            "pair_type": {"type": "string", "enum": ["train", "test"]},
            "pair_index": {"type": "int"},
            "input_json": {"type": "json", "description": "Input grid as JSON string (list[list[int]])"},
            "output_json": {"type": "json", "description": "Output grid as JSON string (list[list[int]])"},
            "input_height": {"type": "int"},
            "input_width": {"type": "int"},
            "output_height": {"type": "int"},
            "output_width": {"type": "int"},
            "input_cells": {"type": "int"},
            "output_cells": {"type": "int"},
            "input_n_colors": {"type": "int"},
            "output_n_colors": {"type": "int"},
            "input_color_hist": {"type": "json", "description": "JSON mapping color->count for input"},
            "output_color_hist": {"type": "json", "description": "JSON mapping color->count for output"},
        },
        "source": str(root),
        "dataset": "ARC-AGI-1",
    }

    readme = f"""# ARC-AGI-1 Dataset

This dataset contains all input/output pairs from the ARC-AGI-1 benchmark,
flattened to a single table with filterable columns for split (training/evaluation)
and pair_type (train/test). Grids are stored as JSON strings.

Quick usage:

```python
import warpdata as wd
df = wd.load("warpdata://arc/arcagi", as_format="pandas")

# Training pairs only
train_pairs = df[(df['split'] == 'training') & (df['pair_type'] == 'train')]

# Select 21x21 inputs
square_21 = df[(df['input_height'] == 21) & (df['input_width'] == 21)]
```

Columns:
- task_id (str)
- split (str: training|evaluation)
- pair_type (str: train|test)
- pair_index (int)
- input_json, output_json (JSON string: list[list[int]])
- input_height, input_width, output_height, output_width (int)
- input_cells, output_cells (int)
- input_n_colors, output_n_colors (int)
- input_color_hist, output_color_hist (JSON string)
"""

    # Track raw data provenance
    raw_data_paths = [data_dir]

    return RecipeOutput(
        main=[out_path],
        metadata=metadata,
        docs={"README.md": readme},
        raw_data=raw_data_paths,
    )
