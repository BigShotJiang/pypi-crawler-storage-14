from __future__ import annotations
from typing import Dict, Type, Optional

try:
    from importlib.metadata import entry_points
except Exception:  # pragma: no cover - very old Pythons
    entry_points = None  # type: ignore


def discover_providers() -> Dict[str, str]:
    """
    Discover provider entry points under group 'warp.datasets'.

    Returns a mapping of module_id -> python path "pkg.module:Class".
    """
    mapping: Dict[str, str] = {}
    if entry_points is None:
        return mapping
    try:
        eps = entry_points(group="warp.datasets")  # type: ignore[arg-type]
    except TypeError:
        # Python <3.10 API
        eps = entry_points().get("warp.datasets", [])  # type: ignore[assignment]
    for ep in eps:
        try:
            mapping[ep.name] = f"{ep.module}:{ep.attr}" if getattr(ep, "module", None) else ep.value  # type: ignore[attr-defined]
        except Exception:
            # Best-effort; skip broken entry point
            continue
    return mapping


def get_provider_class(module_id: str) -> Optional[Type]:
    """
    Resolve a provider class by module id using entry points, with a fallback
    to built-in providers bundled in this repo.
    """
    # 1) Entry points
    mapping = discover_providers()
    value = mapping.get(module_id)
    if value:
        mod_path, _, cls_name = value.partition(":")
        if not cls_name:
            # If value is already fully qualified via .value
            mod_path, _, cls_name = value.rpartition(".")
        if mod_path and cls_name:
            mod = __import__(mod_path, fromlist=[cls_name])
            return getattr(mod, cls_name)

    # 2) Fallback to in-repo providers
    try:
        if module_id == "warp.dataset.gsm8k":
            from .providers.gsm8k import GSM8KModule
            return GSM8KModule
        if module_id == "warp.dataset.gsm8k_symbolized":
            from .providers.gsm8k_symbolized import GSM8KSymbolizedModule
            return GSM8KSymbolizedModule
        if module_id == "warp.dataset.gsm8k_symbolized_steps":
            from .providers.gsm8k_symbolized_steps import GSM8KSymbolizedStepsModule
            return GSM8KSymbolizedStepsModule
        if module_id == "warp.dataset.logician":
            from .providers.logician import LogicianModule
            return LogicianModule
        if module_id == "warp.dataset.coco":
            from .providers.coco import CocoModule
            return CocoModule
        if module_id == "warp.dataset.coco_train":
            from .providers.coco import CocoTrainModule
            return CocoTrainModule
        if module_id == "warp.dataset.coco_val":
            from .providers.coco import CocoValModule
            return CocoValModule
        if module_id == "warp.dataset.imagenet_1k":
            from .providers.imagenet import ImageNet1KModule
            return ImageNet1KModule
        if module_id == "warp.dataset.imagenet_1k_sample":
            from .providers.imagenet import ImageNet1KSampleModule
            return ImageNet1KSampleModule
        if module_id == "warp.dataset.ag_news":
            from .providers.nlp import AGNewsModule
            return AGNewsModule
        if module_id == "warp.dataset.imdb":
            from .providers.nlp import IMDBModule
            return IMDBModule
        if module_id == "warp.dataset.openhermes":
            from .providers.nlp import OpenHermesModule
            return OpenHermesModule
        if module_id == "warp.dataset.truthfulqa":
            from .providers.nlp import TruthfulQAModule
            return TruthfulQAModule
        if module_id == "warp.dataset.yelp_polarity":
            from .providers.nlp import YelpPolarityModule
            return YelpPolarityModule
        if module_id == "warp.dataset.mmlu":
            from .providers.eval import MMLUModule
            return MMLUModule
        if module_id == "warp.dataset.arxiv_papers":
            from .providers.arxiv import ArxivPapersModule
            return ArxivPapersModule
        if module_id == "warp.dataset.mbpp":
            from .providers.code import MBPPModule
            return MBPPModule
        if module_id == "warp.dataset.hellaswag":
            from .providers.reasoning import HellaSwagModule
            return HellaSwagModule
        if module_id == "warp.dataset.vctk":
            from .providers.audio import VCTKModule
            return VCTKModule
        if module_id == "warp.dataset.vctk_speakers":
            from .providers.audio import VCTKSpeakersModule
            return VCTKSpeakersModule
        if module_id == "warp.dataset.lincs":
            from .providers.bio import LINCSModule
            return LINCSModule
        if module_id == "warp.dataset.lincs_genes":
            from .providers.bio import LINCSGenesModule
            return LINCSGenesModule
        if module_id == "warp.dataset.lincs_samples":
            from .providers.bio import LINCSSamplesModule
            return LINCSSamplesModule
        if module_id == "warp.dataset.wine":
            from .providers.uci import WineModule
            return WineModule
        if module_id == "warp.dataset.arcagi":
            from .providers.arc import ArcAGIModule
            return ArcAGIModule
        if module_id == "warp.dataset.arcagi2":
            from .providers.arc import ArcAGI2Module
            return ArcAGI2Module
        if module_id == "warp.dataset.celeba_attrs":
            from .providers.vision_extra import CelebAAttrsModule
            return CelebAAttrsModule
        if module_id == "warp.dataset.dream1k":
            from .providers.video import Dream1KModule
            return Dream1KModule
        if module_id == "warp.dataset.dream1k_events":
            from .providers.video import Dream1KEventsModule
            return Dream1KEventsModule
        if module_id == "warp.dataset.dmt_brains":
            from .providers.neuro import DMTBrainsModule
            return DMTBrainsModule
        if module_id == "warp.dataset.math_hendrycks":
            from .providers.math import MathHendrycksModule
            return MathHendrycksModule
        if module_id == "warp.dataset.mathvision":
            from .providers.math import MathVisionModule
            return MathVisionModule
        if module_id == "warp.dataset.mathvista":
            from .providers.math import MathVistaModule
            return MathVistaModule
        if module_id == "warp.dataset.mathx_100k":
            from .providers.math import MathX100KModule
            return MathX100KModule
        if module_id == "warp.dataset.numina_lean":
            from .providers.math import NuminaLeanModule
            return NuminaLeanModule
    except Exception:
        pass

    return None
