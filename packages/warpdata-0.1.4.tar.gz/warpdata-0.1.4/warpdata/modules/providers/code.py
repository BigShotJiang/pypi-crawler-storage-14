from __future__ import annotations
from ..base import BaseWarpDatasetModule


class MBPPModule(BaseWarpDatasetModule):
    """Provider for code/mbpp dataset."""

    id = "warp.dataset.mbpp"
    version = "1.0.0"
    dataset_uri = "warpdata://code/mbpp"

