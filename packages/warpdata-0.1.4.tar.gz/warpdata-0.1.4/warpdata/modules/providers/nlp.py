from __future__ import annotations
from ..base import BaseWarpDatasetModule


class AGNewsModule(BaseWarpDatasetModule):
    id = "warp.dataset.ag_news"
    version = "1.0.0"
    dataset_uri = "warpdata://nlp/ag-news"


class IMDBModule(BaseWarpDatasetModule):
    id = "warp.dataset.imdb"
    version = "1.0.0"
    dataset_uri = "warpdata://nlp/imdb"


class OpenHermesModule(BaseWarpDatasetModule):
    id = "warp.dataset.openhermes"
    version = "1.0.0"
    dataset_uri = "warpdata://nlp/openhermes"


class TruthfulQAModule(BaseWarpDatasetModule):
    id = "warp.dataset.truthfulqa"
    version = "1.0.0"
    dataset_uri = "warpdata://nlp/truthfulqa"


class YelpPolarityModule(BaseWarpDatasetModule):
    id = "warp.dataset.yelp_polarity"
    version = "1.0.0"
    dataset_uri = "warpdata://nlp/yelp-polarity"

