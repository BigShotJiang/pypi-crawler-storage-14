from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..base import BaseWarpDatasetModule


class GSM8KModule(BaseWarpDatasetModule):
    """Provider for math/gsm8k dataset."""

    id = "warp.dataset.gsm8k"
    version = "1.0.0"
    dataset_uri = "warpdata://math/gsm8k"

    # Inherit get_schema, prepare, load, fingerprint and embeddings helpers

