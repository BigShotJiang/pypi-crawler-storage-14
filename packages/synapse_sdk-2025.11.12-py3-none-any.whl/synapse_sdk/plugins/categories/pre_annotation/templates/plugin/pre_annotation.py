def pre_annotate(data, assignment_id, **kwargs):
    data['pre_annotate'] = 'hello world'
    return data
