#!/usr/bin/env python3
"""
Advanced usage example for CrewAI Observe integration.

This example demonstrates advanced features including:
- TracedCrew class usage
- Custom configuration
- Decorator approach
- Error handling
- Production patterns
"""

import asyncio
import os
import logging
from typing import Dict, Any
from crewai import Crew, Agent, Task
from crewai_langfuse import (
    TracedCrew,
    LangfuseConfig,
    execute_crew_with_tracing,
    traced,
    get_tracing_manager
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def setup_environment():
    """Set up environment variables for the example."""
    if not os.getenv("LANGFUSE_ENABLED"):
        print("Setting up demo environment variables...")
        os.environ["LANGFUSE_ENABLED"] = "1"
        os.environ["LANGFUSE_SECRET_KEY"] = "demo-secret-key"
        os.environ["LANGFUSE_PUBLIC_KEY"] = "demo-public-key"
        os.environ["LANGFUSE_HOST"] = "https://demo-langfuse.com"
        os.environ["LANGFUSE_SAMPLE_RATE"] = "0.8"  # Trace 80% of requests


def create_research_crew() -> Crew:
    """Create a research-focused crew."""
    analyst = Agent(
        role="Market Research Analyst",
        goal="Analyze market trends and provide strategic insights",
        backstory="Expert in market analysis with 10 years of experience in tech industry research.",
        verbose=True
    )

    strategist = Agent(
        role="Business Strategist",
        goal="Develop actionable business strategies based on research",
        backstory="Strategic consultant specializing in technology companies and market entry strategies.",
        verbose=True
    )

    research_task = Task(
        description="Research the current state of {market} market, including key players, trends, and opportunities",
        agent=analyst
    )

    strategy_task = Task(
        description="Based on the research, develop a comprehensive strategy for entering the {market} market",
        agent=strategist
    )

    return Crew(
        agents=[analyst, strategist],
        tasks=[research_task, strategy_task],
        verbose=1
    )


def create_content_crew() -> Crew:
    """Create a content creation crew."""
    researcher = Agent(
        role="Content Researcher",
        goal="Research and gather information on specified topics",
        backstory="Experienced researcher with expertise in technology and business domains.",
        verbose=True
    )

    writer = Agent(
        role="Content Writer",
        goal="Create engaging and informative content",
        backstory="Professional writer specializing in technical content and thought leadership articles.",
        verbose=True
    )

    research_task = Task(
        description="Research comprehensive information about {topic} including latest developments and expert opinions",
        agent=researcher
    )

    writing_task = Task(
        description="Write a comprehensive article about {topic} targeting {audience}. Make it engaging and informative.",
        agent=writer
    )

    return Crew(
        agents=[researcher, writer],
        tasks=[research_task, writing_task],
        verbose=1
    )


async def traced_crew_example():
    """Demonstrate TracedCrew class usage."""
    print("\n🎯 TracedCrew Class Example")
    print("-" * 40)

    crew = create_research_crew()

    # Create a TracedCrew with default settings
    traced_crew = TracedCrew(
        crew=crew,
        default_span_name="market-research-workflow",
        default_session_id="advanced-demo-session",
        default_user_id="demo-user-123",
        default_metadata={
            "workflow_type": "market_research",
            "version": "2.0",
            "environment": "demo"
        }
    )

    try:
        result = await traced_crew.kickoff_async(
            inputs={
                "market": "artificial intelligence",
            },
            metadata={
                "request_id": "req-001",
                "priority": "high"
            }
        )

        logger.info("✅ TracedCrew execution completed successfully!")
        print(f"Result preview: {str(result.raw)[:300]}...")

    except Exception as e:
        logger.error(f"❌ TracedCrew execution failed: {e}")


async def custom_config_example():
    """Demonstrate custom configuration usage."""
    print("\n⚙️ Custom Configuration Example")
    print("-" * 40)

    # Create custom configuration
    custom_config = LangfuseConfig(
        enabled=True,
        sample_rate=1.0,  # Trace 100% for this example
        flush_interval=1000,  # Flush more frequently
        # Note: In production, get these from secure storage
        secret_key="custom-secret-key",
        public_key="custom-public-key",
        host="https://custom-langfuse-instance.com"
    )

    crew = create_content_crew()

    try:
        result = await execute_crew_with_tracing(
            crew=crew,
            inputs={
                "topic": "Cloud Computing Trends 2024",
                "audience": "CTOs and technical decision makers"
            },
            span_name="custom-config-content-creation",
            session_id="custom-config-session",
            user_id="config-demo-user",
            metadata={
                "config_type": "custom",
                "sample_rate": 1.0,
                "content_type": "article"
            },
            config=custom_config
        )

        logger.info("✅ Custom configuration execution completed!")
        print(f"Result preview: {str(result.raw)[:300]}...")

    except Exception as e:
        logger.error(f"❌ Custom configuration execution failed: {e}")


@traced(
    span_name="decorator-workflow",
    metadata={"approach": "decorator", "example": "advanced"}
)
async def decorated_crew_execution(crew: Crew, inputs: Dict[str, Any]):
    """Example of using the @traced decorator."""
    logger.info("🎪 Executing crew with decorator tracing...")
    return await crew.kickoff_async(inputs)


async def decorator_example():
    """Demonstrate decorator approach."""
    print("\n🎭 Decorator Example")
    print("-" * 40)

    crew = create_content_crew()

    try:
        result = await decorated_crew_execution(
            crew=crew,
            inputs={
                "topic": "Microservices Architecture Best Practices",
                "audience": "software engineers and architects"
            }
        )

        logger.info("✅ Decorator execution completed successfully!")
        print(f"Result preview: {str(result.raw)[:300]}...")

    except Exception as e:
        logger.error(f"❌ Decorator execution failed: {e}")


async def error_handling_example():
    """Demonstrate error handling and graceful degradation."""
    print("\n🛡️ Error Handling Example")
    print("-" * 40)

    # Temporarily break the configuration
    original_host = os.getenv("LANGFUSE_HOST")
    os.environ["LANGFUSE_HOST"] = "https://invalid-host.example.com"

    crew = create_content_crew()

    try:
        # This should gracefully handle the invalid configuration
        result = await execute_crew_with_tracing(
            crew=crew,
            inputs={
                "topic": "Kubernetes Security",
                "audience": "DevOps engineers"
            },
            span_name="error-handling-test",
        )

        logger.info("✅ Error handling test completed (crew executed without tracing)")
        print(f"Result preview: {str(result.raw)[:300]}...")

    except Exception as e:
        logger.error(f"❌ Even error handling failed: {e}")

    finally:
        # Restore original configuration
        if original_host:
            os.environ["LANGFUSE_HOST"] = original_host


async def production_pattern_example():
    """Demonstrate production-ready patterns."""
    print("\n🏭 Production Pattern Example")
    print("-" * 40)

    class WorkflowOrchestrator:
        """Example of how to integrate in a production application."""

        def __init__(self):
            self.tracing_manager = get_tracing_manager()
            self.crews = {
                "research": create_research_crew(),
                "content": create_content_crew()
            }

        async def execute_workflow(
            self,
            workflow_type: str,
            inputs: Dict[str, Any],
            user_id: str,
            session_id: str = None
        ):
            """Execute a workflow with comprehensive tracing and error handling."""

            if workflow_type not in self.crews:
                raise ValueError(f"Unknown workflow type: {workflow_type}")

            crew = self.crews[workflow_type]
            session_id = session_id or f"session-{user_id}-{workflow_type}"

            metadata = {
                "workflow_type": workflow_type,
                "user_id": user_id,
                "session_id": session_id,
                "input_keys": list(inputs.keys()),
                "crew_agent_count": len(crew.agents),
                "crew_task_count": len(crew.tasks)
            }

            try:
                result = await execute_crew_with_tracing(
                    crew=crew,
                    inputs=inputs,
                    span_name=f"{workflow_type}-workflow",
                    session_id=session_id,
                    user_id=user_id,
                    metadata=metadata
                )

                logger.info(f"✅ Workflow {workflow_type} completed for user {user_id}")
                return {
                    "status": "success",
                    "result": result,
                    "session_id": session_id,
                    "workflow_type": workflow_type
                }

            except Exception as e:
                logger.error(f"❌ Workflow {workflow_type} failed for user {user_id}: {e}")
                return {
                    "status": "error",
                    "error": str(e),
                    "session_id": session_id,
                    "workflow_type": workflow_type
                }

    # Use the orchestrator
    orchestrator = WorkflowOrchestrator()

    # Execute multiple workflows
    workflows = [
        {
            "type": "content",
            "inputs": {"topic": "AI Ethics", "audience": "business leaders"},
            "user_id": "prod-user-001"
        },
        {
            "type": "research",
            "inputs": {"market": "edge computing"},
            "user_id": "prod-user-002"
        }
    ]

    for workflow in workflows:
        try:
            result = await orchestrator.execute_workflow(
                workflow_type=workflow["type"],
                inputs=workflow["inputs"],
                user_id=workflow["user_id"]
            )

            print(f"Workflow result: {result['status']} for user {workflow['user_id']}")

        except Exception as e:
            logger.error(f"Orchestrator error: {e}")


async def main():
    """Main function to run all advanced examples."""
    print("🚀 CrewAI Observe Integration - Advanced Usage Examples")
    print("=" * 65)

    setup_environment()

    examples = [
        ("TracedCrew Class", traced_crew_example),
        ("Custom Configuration", custom_config_example),
        ("Decorator Approach", decorator_example),
        ("Error Handling", error_handling_example),
        ("Production Patterns", production_pattern_example)
    ]

    for name, example_func in examples:
        try:
            print(f"\n🎯 Running: {name}")
            await example_func()
        except Exception as e:
            logger.error(f"❌ Example '{name}' failed: {e}")
        finally:
            print(f"✅ Completed: {name}")

    print("\n🎉 All advanced examples completed!")
    print("\nKey takeaways:")
    print("1. Use TracedCrew for consistent tracing across multiple executions")
    print("2. Custom configurations allow fine-tuning for production environments")
    print("3. Decorators provide clean integration for existing functions")
    print("4. Proper error handling ensures graceful degradation")
    print("5. Production patterns enable scalable integration")


if __name__ == "__main__":
    asyncio.run(main())