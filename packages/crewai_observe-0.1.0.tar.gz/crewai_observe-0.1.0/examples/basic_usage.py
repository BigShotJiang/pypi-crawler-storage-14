#!/usr/bin/env python3
"""
Basic usage example for CrewAI Observe.

This example demonstrates the simplest way to add Langfuse tracing
to your CrewAI workflows using the execute_crew_with_tracing function.
"""

import asyncio
import os
from crewai import Crew, Agent, Task
from crewai_langfuse import execute_crew_with_tracing


def setup_environment():
    """Set up environment variables for the example."""
    # In a real application, these would be set in your environment
    # For demo purposes, we'll set them here if not already set
    if not os.getenv("LANGFUSE_ENABLED"):
        print("Setting up demo environment variables...")
        os.environ["LANGFUSE_ENABLED"] = "1"
        os.environ["LANGFUSE_SECRET_KEY"] = "demo-secret-key"
        os.environ["LANGFUSE_PUBLIC_KEY"] = "demo-public-key"
        os.environ["LANGFUSE_HOST"] = "https://demo-langfuse.com"

    print(f"Langfuse enabled: {os.getenv('LANGFUSE_ENABLED')}")
    print(f"Langfuse host: {os.getenv('LANGFUSE_HOST')}")


def create_sample_crew():
    """Create a sample CrewAI crew for demonstration."""

    # Create a research agent
    researcher = Agent(
        role="Senior Research Analyst",
        goal="Uncover cutting-edge developments in AI and data science",
        backstory="""You work at a leading tech think tank.
        Your expertise lies in identifying emerging trends.
        You have a knack for dissecting complex data and presenting actionable insights.""",
        verbose=True,
        allow_delegation=False
    )

    # Create a writer agent
    writer = Agent(
        role="Tech Content Strategist",
        goal="Craft compelling content on tech advancements",
        backstory="""You are a renowned Content Strategist, known for your insightful
        and engaging articles. You transform complex concepts into compelling narratives.""",
        verbose=True,
        allow_delegation=True
    )

    # Define tasks
    task1 = Task(
        description="""Conduct a comprehensive analysis of the latest advancements in AI in 2024.
        Identify key trends, breakthrough technologies, and the big players in the space.
        Your final answer MUST be a full analysis report""",
        agent=researcher
    )

    task2 = Task(
        description="""Using the insights provided, develop an engaging blog
        post that highlights the most significant AI advancements.
        Your post should be informative yet accessible, catering to a tech-savvy audience.
        Make it sound cool, avoid complex words so it doesn't sound like AI.
        Your final answer MUST be the full blog post of at least 4 paragraphs.""",
        agent=writer
    )

    # Create crew
    crew = Crew(
        agents=[researcher, writer],
        tasks=[task1, task2],
        verbose=2  # You can set it to 1 or 2 to different logging levels
    )

    return crew


async def basic_tracing_example():
    """Demonstrate basic tracing with execute_crew_with_tracing."""
    print("\n🚀 Running basic tracing example...")

    crew = create_sample_crew()

    try:
        result = await execute_crew_with_tracing(
            crew=crew,
            inputs={
                "topic": "AI advancements in 2024",
                "target_audience": "tech professionals"
            },
            span_name="ai-research-blog-creation",
            session_id="demo-session-001",
            user_id="demo-user",
            metadata={
                "example_type": "basic_usage",
                "crew_size": 2,
                "task_count": 2,
                "domain": "AI research"
            }
        )

        print("✅ Crew execution completed successfully!")
        print(f"Result type: {type(result)}")
        print(f"Result: {result.raw[:200]}..." if len(str(result.raw)) > 200 else f"Result: {result.raw}")

    except Exception as e:
        print(f"❌ Error during execution: {e}")
        print("This might happen if Langfuse credentials are not properly configured")
        print("The crew would still execute normally without tracing if LANGFUSE_ENABLED=0")


async def fallback_example():
    """Demonstrate fallback behavior when tracing is disabled."""
    print("\n🔄 Running fallback example (tracing disabled)...")

    # Temporarily disable tracing
    original_enabled = os.getenv("LANGFUSE_ENABLED")
    os.environ["LANGFUSE_ENABLED"] = "0"

    crew = create_sample_crew()

    try:
        result = await execute_crew_with_tracing(
            crew=crew,
            inputs={
                "topic": "Machine Learning trends",
                "target_audience": "data scientists"
            },
            span_name="ml-trends-analysis",
        )

        print("✅ Crew execution completed without tracing!")
        print(f"Result type: {type(result)}")
        print(f"Result: {result.raw[:200]}..." if len(str(result.raw)) > 200 else f"Result: {result.raw}")

    except Exception as e:
        print(f"❌ Error during execution: {e}")

    finally:
        # Restore original setting
        if original_enabled:
            os.environ["LANGFUSE_ENABLED"] = original_enabled


async def main():
    """Main function to run all examples."""
    print("🎯 CrewAI Observe - Basic Usage Examples")
    print("=" * 60)

    # Setup environment
    setup_environment()

    # Run examples
    await basic_tracing_example()
    await fallback_example()

    print("\n✨ Examples completed!")
    print("\nNext steps:")
    print("1. Set up your actual Langfuse credentials")
    print("2. Check your Langfuse dashboard for trace data")
    print("3. Try the advanced_usage.py example for more features")


if __name__ == "__main__":
    asyncio.run(main())