#!/usr/bin/env python3
"""
Simple test to verify the CrewAI Observe package works.

This is a minimal example to test the package without requiring
actual Langfuse credentials or CrewAI execution.
"""

import os
import sys
import asyncio

# Add the src directory to Python path for local testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

def test_imports():
    """Test that all main components can be imported."""
    print("🔍 Testing imports...")

    try:
        from crewai_langfuse import (
            execute_crew_with_tracing,
            TracedCrew,
            LangfuseConfig,
            TracingError,
            ConfigurationError
        )
        print("✅ All main imports successful")
        return True
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False


def test_config():
    """Test configuration functionality."""
    print("\n🛠️ Testing configuration...")

    try:
        from crewai_langfuse.core.config import LangfuseConfig

        # Test disabled configuration
        os.environ["LANGFUSE_ENABLED"] = "0"
        config = LangfuseConfig.from_env()
        assert not config.enabled
        print("✅ Disabled config works")

        # Test enabled configuration (without validation)
        os.environ["LANGFUSE_ENABLED"] = "1"
        config = LangfuseConfig()
        assert config.enabled
        print("✅ Enabled config creation works")

        # Test configuration validation (should fail with missing credentials)
        try:
            config.validate()
            print("⚠️ Configuration validation passed unexpectedly")
        except Exception:
            print("✅ Configuration validation correctly fails with missing credentials")

        return True

    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False


def test_tracing_manager():
    """Test tracing manager functionality."""
    print("\n📊 Testing tracing manager...")

    try:
        from crewai_langfuse.core.tracing import TracingManager, get_tracing_manager

        # Test manager creation
        manager = TracingManager()
        assert isinstance(manager, TracingManager)
        print("✅ TracingManager creation works")

        # Test global manager
        global_manager = get_tracing_manager()
        assert isinstance(global_manager, TracingManager)
        print("✅ Global tracing manager works")

        # Test disabled tracing
        os.environ["LANGFUSE_ENABLED"] = "0"
        manager = TracingManager()
        assert not manager.is_enabled
        print("✅ Disabled tracing detection works")

        return True

    except Exception as e:
        print(f"❌ Tracing manager test failed: {e}")
        return False


def test_validation():
    """Test validation utilities."""
    print("\n🔍 Testing validation utilities...")

    try:
        from crewai_langfuse.utils.validation import validate_inputs, validate_metadata

        # Test input validation
        result = validate_inputs({"key": "value"})
        assert result == {"key": "value"}
        print("✅ Input validation works")

        # Test metadata validation
        result = validate_metadata({"meta": "data"})
        assert result == {"meta": "data"}
        print("✅ Metadata validation works")

        # Test None handling
        result = validate_inputs(None)
        assert result == {}
        print("✅ None input handling works")

        return True

    except Exception as e:
        print(f"❌ Validation test failed: {e}")
        return False


async def test_mock_crew_execution():
    """Test crew execution without actual CrewAI."""
    print("\n🤖 Testing mock crew execution...")

    try:
        from crewai_langfuse import execute_crew_with_tracing

        # Create a mock crew class
        class MockCrew:
            async def kickoff_async(self, inputs):
                """Mock async method to match CrewAI interface."""
                _ = inputs  # to avoid unused variable warning
                # Use async to match real CrewAI.kickoff_async() signature
                await asyncio.sleep(0)  # Make function genuinely async
                return MockCrewOutput("Mock result from crew execution")

        class MockCrewOutput:
            def __init__(self, raw):
                self.raw = raw

        # Test with tracing disabled
        os.environ["LANGFUSE_ENABLED"] = "0"
        mock_crew = MockCrew()

        result = await execute_crew_with_tracing(
            crew=mock_crew,
            inputs={"test": "input"}
        )

        assert result.raw == "Mock result from crew execution"
        print("✅ Mock crew execution works without tracing")

        return True

    except Exception as e:
        print(f"❌ Mock crew execution test failed: {e}")
        return False


async def run_all_tests():
    """Run all tests."""
    print("🧪 CrewAI Observe Package Tests")
    print("=" * 40)

    tests = [
        ("Imports", test_imports),
        ("Configuration", test_config),
        ("Tracing Manager", test_tracing_manager),
        ("Validation", test_validation),
        ("Mock Crew Execution", test_mock_crew_execution)
    ]

    passed = 0
    failed = 0

    for name, test_func in tests:
        try:
            if asyncio.iscoroutinefunction(test_func):
                success = await test_func()
            else:
                success = test_func()

            if success:
                passed += 1
            else:
                failed += 1

        except Exception as e:
            print(f"❌ Test '{name}' crashed: {e}")
            failed += 1

    print("\n📊 Test Results:")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    print(f"📈 Success rate: {passed / (passed + failed) * 100:.1f}%")

    if failed == 0:
        print("\n🎉 All tests passed! The package is working correctly.")
    else:
        print(f"\n⚠️ {failed} test(s) failed. Check the output above for details.")

    return failed == 0


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    sys.exit(0 if success else 1)