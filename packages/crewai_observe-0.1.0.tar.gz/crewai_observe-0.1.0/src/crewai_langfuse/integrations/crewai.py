"""CrewAI integration with Langfuse tracing."""

from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional, TYPE_CHECKING
from functools import wraps

if TYPE_CHECKING:
    from crewai import Crew, CrewOutput
else:
    # Runtime imports with fallbacks
    try:
        from crewai import Crew, CrewOutput
    except ImportError:
        # Allow package to be imported even if CrewAI is not installed
        Crew = None  # type: ignore
        CrewOutput = None  # type: ignore

from ..core.tracing import get_tracing_manager
from ..core.config import LangfuseConfig
from ..core.exceptions import CrewAIIntegrationError
from ..utils.logger import get_logger
from ..utils.validation import validate_crew_instance, validate_inputs

logger = get_logger(__name__)

# Constants
CREWAI_NOT_INSTALLED_ERROR = "CrewAI is not installed. Please install it with: pip install crewai"


async def execute_crew_with_tracing(
    crew: Crew,
    inputs: Optional[Dict[str, Any]] = None,
    span_name: str = "crew-kickoff",
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    config: Optional[LangfuseConfig] = None,
) -> CrewOutput:
    """
    Execute a CrewAI crew with Langfuse tracing.

    This function wraps the crew.kickoff_async() call with Langfuse span tracking
    to provide observability for LLM calls, token usage, and agent thoughts.
    It also associates the trace with session, user, and custom metadata for better
    filtering and analytics in Langfuse.

    Args:
        crew: The CrewAI Crew instance to execute
        inputs: Dictionary of inputs to pass to the crew
        span_name: Name for the Langfuse span (default: "crew-kickoff")
        session_id: Session identifier for grouping related traces (optional)
        user_id: User/tenant identifier for filtering traces (optional)
        metadata: Additional metadata to attach to the trace (optional)
        config: Optional Langfuse configuration (uses environment if not provided)

    Returns:
        The result from crew.kickoff_async()

    Raises:
        CrewAIIntegrationError: If crew execution fails

    Example:
        ```python
        from crewai_langfuse import execute_crew_with_tracing

        crew = Crew(agents=[...], tasks=[...])
        result = await execute_crew_with_tracing(
            crew=crew,
            inputs={"user_request": "Generate a report"},
            span_name="report-generation",
            session_id="session-123",
            user_id="user-456",
            metadata={"workspace_id": "ws-789"}
        )
        ```
    """
    if Crew is None:
        raise CrewAIIntegrationError(CREWAI_NOT_INSTALLED_ERROR)

    # Validate inputs
    validate_crew_instance(crew)
    validated_inputs = validate_inputs(inputs)

    # Get tracing manager
    tracing_manager = get_tracing_manager(config)

    if not tracing_manager.is_enabled:
        # If tracing is disabled, execute crew normally
        logger.debug("Langfuse tracing is disabled, executing crew without tracing")
        try:
            return await crew.kickoff_async(validated_inputs)
        except Exception as e:
            raise CrewAIIntegrationError(f"Crew execution failed: {e}") from e

    # Execute with tracing
    try:
        async with tracing_manager.trace_span_async(
            name=span_name,
            session_id=session_id,
            user_id=user_id,
            metadata=metadata,
        ) as _:
            logger.debug(f"Starting crew execution with tracing: {span_name}")
            result = await crew.kickoff_async(validated_inputs)
            logger.debug("Crew execution completed successfully")
            return result

    except Exception as e:
        logger.error(f"Error during traced crew execution: {e}")
        raise CrewAIIntegrationError(f"Traced crew execution failed: {e}") from e


def execute_crew_with_tracing_sync(
    crew: Crew,
    inputs: Optional[Dict[str, Any]] = None,
    span_name: str = "crew-kickoff",
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    config: Optional[LangfuseConfig] = None,
) -> CrewOutput:
    """
    Execute a CrewAI crew with Langfuse tracing (synchronous version).

    This is a synchronous wrapper around execute_crew_with_tracing for use
    in non-async contexts.

    Args:
        crew: The CrewAI Crew instance to execute
        inputs: Dictionary of inputs to pass to the crew
        span_name: Name for the Langfuse span (default: "crew-kickoff")
        session_id: Session identifier for grouping related traces (optional)
        user_id: User/tenant identifier for filtering traces (optional)
        metadata: Additional metadata to attach to the trace (optional)
        config: Optional Langfuse configuration (uses environment if not provided)

    Returns:
        The result from crew.kickoff()

    Raises:
        CrewAIIntegrationError: If crew execution fails

    Example:
        ```python
        from crewai_langfuse import execute_crew_with_tracing_sync

        crew = Crew(agents=[...], tasks=[...])
        result = execute_crew_with_tracing_sync(
            crew=crew,
            inputs={"user_request": "Generate a report"},
            span_name="report-generation",
            session_id="session-123"
        )
        ```
    """
    if Crew is None:
        raise CrewAIIntegrationError(CREWAI_NOT_INSTALLED_ERROR)

    # Validate inputs
    validate_crew_instance(crew)
    validated_inputs = validate_inputs(inputs)

    # Get tracing manager
    tracing_manager = get_tracing_manager(config)

    if not tracing_manager.is_enabled:
        # If tracing is disabled, execute crew normally
        logger.debug("Langfuse tracing is disabled, executing crew without tracing")
        try:
            return crew.kickoff(validated_inputs)
        except Exception as e:
            raise CrewAIIntegrationError(f"Crew execution failed: {e}") from e

    # Execute with tracing
    try:
        with tracing_manager.trace_span(
            name=span_name,
            session_id=session_id,
            user_id=user_id,
            metadata=metadata,
        ) as _:
            logger.debug(f"Starting crew execution with tracing: {span_name}")
            result = crew.kickoff(validated_inputs)
            logger.debug("Crew execution completed successfully")
            return result

    except Exception as e:
        logger.error(f"Error during traced crew execution: {e}")
        raise CrewAIIntegrationError(f"Traced crew execution failed: {e}") from e


class TracedCrew:
    """
    A wrapper class that adds tracing capabilities to CrewAI Crew instances.

    This class provides a convenient interface for crews that need consistent
    tracing configuration across multiple executions.

    Example:
        ```python
        from crewai_langfuse import TracedCrew

        # Create a traced crew
        traced_crew = TracedCrew(
            crew=Crew(agents=[...], tasks=[...]),
            default_span_name="my-crew-execution",
            default_metadata={"version": "1.0"}
        )

        # Execute with tracing
        result = await traced_crew.kickoff_async(
            inputs={"query": "Hello"},
            session_id="session-123"
        )
        ```
    """

    def __init__(
        self,
        crew: Crew,
        config: Optional[LangfuseConfig] = None,
        default_span_name: str = "crew-kickoff",
        default_session_id: Optional[str] = None,
        default_user_id: Optional[str] = None,
        default_metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize TracedCrew.

        Args:
            crew: The CrewAI Crew instance to wrap
            config: Optional Langfuse configuration
            default_span_name: Default span name for all executions
            default_session_id: Default session ID
            default_user_id: Default user ID
            default_metadata: Default metadata
        """
        if Crew is None:
            raise CrewAIIntegrationError(CREWAI_NOT_INSTALLED_ERROR)

        validate_crew_instance(crew)

        self.crew = crew
        self.config = config
        self.default_span_name = default_span_name
        self.default_session_id = default_session_id
        self.default_user_id = default_user_id
        self.default_metadata = default_metadata or {}

    async def kickoff_async(
        self,
        inputs: Optional[Dict[str, Any]] = None,
        span_name: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CrewOutput:
        """
        Execute crew asynchronously with tracing.

        Args:
            inputs: Dictionary of inputs to pass to the crew
            span_name: Override default span name
            session_id: Override default session ID
            user_id: Override default user ID
            metadata: Additional metadata (merged with defaults)

        Returns:
            The result from crew.kickoff_async()
        """
        # Merge metadata with defaults
        final_metadata = dict(self.default_metadata)
        if metadata:
            final_metadata.update(metadata)

        return await execute_crew_with_tracing(
            crew=self.crew,
            inputs=inputs,
            span_name=span_name or self.default_span_name,
            session_id=session_id or self.default_session_id,
            user_id=user_id or self.default_user_id,
            metadata=final_metadata if final_metadata else None,
            config=self.config,
        )

    def kickoff(
        self,
        inputs: Optional[Dict[str, Any]] = None,
        span_name: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> CrewOutput:
        """
        Execute crew synchronously with tracing.

        Args:
            inputs: Dictionary of inputs to pass to the crew
            span_name: Override default span name
            session_id: Override default session ID
            user_id: Override default user ID
            metadata: Additional metadata (merged with defaults)

        Returns:
            The result from crew.kickoff()
        """
        # Merge metadata with defaults
        final_metadata = dict(self.default_metadata)
        if metadata:
            final_metadata.update(metadata)

        return execute_crew_with_tracing_sync(
            crew=self.crew,
            inputs=inputs,
            span_name=span_name or self.default_span_name,
            session_id=session_id or self.default_session_id,
            user_id=user_id or self.default_user_id,
            metadata=final_metadata if final_metadata else None,
            config=self.config,
        )

    def __getattr__(self, name):
        """Delegate attribute access to the wrapped crew."""
        return getattr(self.crew, name)


# Convenience decorator for automatic tracing
def traced(
    span_name: Optional[str] = None,
    session_id: Optional[str] = None,
    user_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
):
    """
    Decorator to automatically add tracing to crew execution methods.

    Args:
        span_name: Custom span name
        session_id: Session identifier
        user_id: User identifier
        metadata: Additional metadata

    Example:
        ```python
        from crewai_langfuse import traced

        @traced(span_name="custom-crew-execution")
        async def run_my_crew(crew, user_input):
            return await crew.kickoff_async({"input": user_input})
        ```
    """
    def decorator(func):
        if asyncio.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args, **kwargs):
                tracing_manager = get_tracing_manager()

                if not tracing_manager.is_enabled:
                    return await func(*args, **kwargs)

                effective_span_name = span_name or f"{func.__name__}-execution"

                async with tracing_manager.trace_span_async(
                    name=effective_span_name,
                    session_id=session_id,
                    user_id=user_id,
                    metadata=metadata,
                ):
                    return await func(*args, **kwargs)

            return async_wrapper
        else:
            @wraps(func)
            def sync_wrapper(*args, **kwargs):
                tracing_manager = get_tracing_manager()

                if not tracing_manager.is_enabled:
                    return func(*args, **kwargs)

                effective_span_name = span_name or f"{func.__name__}-execution"

                with tracing_manager.trace_span(
                    name=effective_span_name,
                    session_id=session_id,
                    user_id=user_id,
                    metadata=metadata,
                ):
                    return func(*args, **kwargs)

            return sync_wrapper

    return decorator