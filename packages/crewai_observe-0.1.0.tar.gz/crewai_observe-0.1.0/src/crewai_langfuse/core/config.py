"""Configuration management for CrewAI Observe."""

import os
from dataclasses import dataclass
from typing import Optional, Dict, Any
from .exceptions import ConfigurationError


@dataclass
class LangfuseConfig:
    """Configuration class for Langfuse integration."""

    secret_key: Optional[str] = None
    public_key: Optional[str] = None
    host: Optional[str] = None
    enabled: bool = False
    tracing_enabled: bool = True
    sample_rate: float = 0.1
    flush_interval: int = 2000

    def __post_init__(self):
        """Initialize configuration from environment variables."""
        self.enabled = os.environ.get("LANGFUSE_ENABLED") == "1"

        if self.enabled:
            self.secret_key = self.secret_key or os.environ.get("LANGFUSE_SECRET_KEY")
            self.public_key = self.public_key or os.environ.get("LANGFUSE_PUBLIC_KEY")
            self.host = self.host or os.environ.get("LANGFUSE_HOST")

            # Override defaults with environment variables if provided
            if os.environ.get("LANGFUSE_SAMPLE_RATE"):
                try:
                    self.sample_rate = float(os.environ.get("LANGFUSE_SAMPLE_RATE"))
                except ValueError:
                    raise ConfigurationError(
                        f"Invalid LANGFUSE_SAMPLE_RATE: {os.environ.get('LANGFUSE_SAMPLE_RATE')}. "
                        "Must be a float between 0 and 1."
                    )

            if os.environ.get("LANGFUSE_FLUSH_INTERVAL"):
                try:
                    self.flush_interval = int(os.environ.get("LANGFUSE_FLUSH_INTERVAL"))
                except ValueError:
                    raise ConfigurationError(
                        f"Invalid LANGFUSE_FLUSH_INTERVAL: {os.environ.get('LANGFUSE_FLUSH_INTERVAL')}. "
                        "Must be an integer."
                    )

    def validate(self) -> None:
        """Validate configuration parameters."""
        if not self.enabled:
            return  # No validation needed if not enabled

        if not all([self.secret_key, self.public_key, self.host]):
            missing = []
            if not self.secret_key:
                missing.append("LANGFUSE_SECRET_KEY")
            if not self.public_key:
                missing.append("LANGFUSE_PUBLIC_KEY")
            if not self.host:
                missing.append("LANGFUSE_HOST")

            raise ConfigurationError(
                f"Langfuse is enabled but missing required environment variables: {', '.join(missing)}"
            )

        if not (0 <= self.sample_rate <= 1):
            raise ConfigurationError(
                f"Sample rate must be between 0 and 1, got: {self.sample_rate}"
            )

        if self.flush_interval <= 0:
            raise ConfigurationError(
                f"Flush interval must be positive, got: {self.flush_interval}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary for Langfuse client."""
        return {
            "secret_key": self.secret_key,
            "public_key": self.public_key,
            "host": self.host,
            "tracing_enabled": self.tracing_enabled,
            "sample_rate": self.sample_rate,
            "flush_interval": self.flush_interval,
        }

    @classmethod
    def from_env(cls) -> "LangfuseConfig":
        """Create configuration from environment variables."""
        config = cls()
        config.validate()
        return config