"""Custom exceptions for CrewAI Observe."""


class TracingError(Exception):
    """Base exception for tracing-related errors."""

    def __init__(self, message: str, original_error: Exception = None):
        self.message = message
        self.original_error = original_error
        super().__init__(self.message)


class ConfigurationError(TracingError):
    """Raised when there are configuration issues."""

    pass


class LangfuseConnectionError(TracingError):
    """Raised when Langfuse connection fails."""

    pass


class CrewAIIntegrationError(TracingError):
    """Raised when CrewAI integration encounters issues."""

    pass