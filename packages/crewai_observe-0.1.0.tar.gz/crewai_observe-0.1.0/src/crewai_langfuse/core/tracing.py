"""Core tracing functionality for Langfuse integration."""

import asyncio
from typing import Optional, Dict, Any
from contextlib import asynccontextmanager, contextmanager

from .config import LangfuseConfig
from .exceptions import LangfuseConnectionError
from ..utils.logger import get_logger
from ..utils.validation import validate_metadata

logger = get_logger(__name__)


class TracingManager:
    """Manages Langfuse tracing operations."""

    def __init__(self, config: Optional[LangfuseConfig] = None):
        """
        Initialize the tracing manager.

        Args:
            config: Optional configuration. If None, loads from environment.
        """
        self.config = config or LangfuseConfig.from_env()
        self._langfuse_client = None
        self._instrumentation_initialized = False

    @property
    def is_enabled(self) -> bool:
        """Check if tracing is enabled."""
        return self.config.enabled

    @property
    def langfuse_client(self):
        """Get or create Langfuse client."""
        if not self.is_enabled:
            return None

        if self._langfuse_client is None:
            self._initialize_langfuse()

        return self._langfuse_client

    def _initialize_langfuse(self) -> None:
        """Initialize Langfuse client and instrumentation."""
        try:
            from langfuse import Langfuse
            from openinference.instrumentation.crewai import CrewAIInstrumentor
            from openinference.instrumentation.litellm import LiteLLMInstrumentor

            # Create Langfuse client
            client_config = self.config.to_dict()
            self._langfuse_client = Langfuse(**client_config)

            # Verify connection
            if not self._langfuse_client.auth_check():
                raise LangfuseConnectionError(
                    "Authentication failed. Please check your credentials and host."
                )

            logger.info("Langfuse client is authenticated and ready!")

            # Initialize instrumentation (only once)
            if not self._instrumentation_initialized:
                try:
                    CrewAIInstrumentor().instrument(skip_dep_check=True)
                    LiteLLMInstrumentor().instrument()
                    self._instrumentation_initialized = True
                    logger.info("OpenInference instrumentation initialized successfully")
                except Exception as e:
                    logger.warning(f"Failed to initialize instrumentation: {e}")
                    # Continue without instrumentation - basic tracing will still work

        except ImportError as e:
            raise LangfuseConnectionError(
                f"Required packages not available: {e}. "
                "Please install: pip install langfuse openinference-instrumentation-crewai openinference-instrumentation-litellm"
            )
        except Exception as e:
            raise LangfuseConnectionError(f"Failed to initialize Langfuse: {e}")

    @contextmanager
    def trace_span(
        self,
        name: str,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Context manager for tracing synchronous operations.

        Args:
            name: Span name
            session_id: Session identifier
            user_id: User identifier
            metadata: Additional metadata
        """
        if not self.is_enabled or not self.langfuse_client:
            yield None
            return

        try:
            validated_metadata = validate_metadata(metadata)

            trace_updates = {}
            if session_id:
                trace_updates["session_id"] = session_id
            if user_id:
                trace_updates["user_id"] = user_id
            if validated_metadata:
                trace_updates["metadata"] = validated_metadata

            with self.langfuse_client.start_as_current_span(name=name) as span:
                if trace_updates:
                    span.update_trace(**trace_updates)
                yield span

        except Exception as e:
            logger.error(f"Error in trace span: {e}")
            yield None
        finally:
            try:
                if self.langfuse_client:
                    self.langfuse_client.flush()
            except Exception as e:
                logger.error(f"Error flushing Langfuse client: {e}")

    @asynccontextmanager
    async def trace_span_async(
        self,
        name: str,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Async context manager for tracing asynchronous operations.

        Args:
            name: Span name
            session_id: Session identifier
            user_id: User identifier
            metadata: Additional metadata
        """
        if not self.is_enabled or not self.langfuse_client:
            yield None
            return

        try:
            validated_metadata = validate_metadata(metadata)

            trace_updates = {}
            if session_id:
                trace_updates["session_id"] = session_id
            if user_id:
                trace_updates["user_id"] = user_id
            if validated_metadata:
                trace_updates["metadata"] = validated_metadata

            with self.langfuse_client.start_as_current_span(name=name) as span:
                if trace_updates:
                    span.update_trace(**trace_updates)
                yield span

        except Exception as e:
            logger.error(f"Error in async trace span: {e}")
            yield None
        finally:
            try:
                if self.langfuse_client:
                    # Run flush in executor to avoid blocking
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, self.langfuse_client.flush)
            except Exception as e:
                logger.error(f"Error flushing Langfuse client: {e}")

    def flush(self) -> None:
        """Flush pending traces."""
        if self.langfuse_client:
            try:
                self.langfuse_client.flush()
            except Exception as e:
                logger.error(f"Error flushing traces: {e}")

    async def flush_async(self) -> None:
        """Async flush pending traces."""
        if self.langfuse_client:
            try:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, self.langfuse_client.flush)
            except Exception as e:
                logger.error(f"Error flushing traces: {e}")


# Global instance for easy access
_global_tracing_manager: Optional[TracingManager] = None


def get_tracing_manager(config: Optional[LangfuseConfig] = None) -> TracingManager:
    """
    Get or create a global tracing manager instance.

    Args:
        config: Optional configuration

    Returns:
        TracingManager instance
    """
    global _global_tracing_manager

    if _global_tracing_manager is None or config is not None:
        _global_tracing_manager = TracingManager(config)

    return _global_tracing_manager