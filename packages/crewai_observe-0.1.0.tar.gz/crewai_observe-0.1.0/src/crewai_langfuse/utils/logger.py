"""Logging utilities for CrewAI Observe."""

import logging
import sys
from typing import Optional


def get_logger(
    name: str = "crewai_langfuse",
    level: int = logging.INFO,
    handler: Optional[logging.Handler] = None
) -> logging.Logger:
    """
    Get a configured logger instance.

    Args:
        name: Logger name
        level: Logging level
        handler: Optional custom handler

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)

    # Avoid adding multiple handlers if logger already exists
    if not logger.handlers:
        if handler is None:
            handler = logging.StreamHandler(sys.stdout)

        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(level)

        # Prevent propagation to root logger to avoid duplicate logs
        logger.propagate = False

    return logger