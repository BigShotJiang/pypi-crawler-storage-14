"""Input validation utilities."""

from typing import Any, Dict
from ..core.exceptions import TracingError


def validate_inputs(inputs: Any) -> Dict[str, Any]:
    """
    Validate and normalize inputs for crew execution.

    Args:
        inputs: Input data for crew execution

    Returns:
        Normalized inputs as dictionary

    Raises:
        TracingError: If inputs are invalid
    """
    if inputs is None:
        return {}

    if isinstance(inputs, dict):
        return inputs

    # Try to convert other types to dict if possible
    if hasattr(inputs, '__dict__'):
        return inputs.__dict__

    raise TracingError(
        f"Invalid inputs type: {type(inputs)}. Expected dict or object with __dict__ attribute."
    )


def validate_crew_instance(crew: Any) -> None:
    """
    Validate that the provided crew instance is valid.

    Args:
        crew: CrewAI crew instance to validate

    Raises:
        TracingError: If crew instance is invalid
    """
    if crew is None:
        raise TracingError("Crew instance cannot be None")

    # Check if it's a CrewAI crew by looking for expected methods
    required_methods = ['kickoff', 'kickoff_async']
    available_methods = [method for method in required_methods if hasattr(crew, method)]

    if not available_methods:
        raise TracingError(
            f"Invalid crew instance: missing required methods {required_methods}. "
            f"Expected a CrewAI Crew instance."
        )


def validate_metadata(metadata: Any) -> Dict[str, Any]:
    """
    Validate and normalize metadata for tracing.

    Args:
        metadata: Metadata to validate

    Returns:
        Normalized metadata as dictionary

    Raises:
        TracingError: If metadata is invalid
    """
    if metadata is None:
        return {}

    if isinstance(metadata, dict):
        return metadata

    if hasattr(metadata, '__dict__'):
        return metadata.__dict__

    raise TracingError(
        f"Invalid metadata type: {type(metadata)}. Expected dict or object with __dict__ attribute."
    )