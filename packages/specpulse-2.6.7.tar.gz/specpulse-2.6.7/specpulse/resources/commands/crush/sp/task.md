---
name: SpecPulse: Task Breakdown
description: Break down plans into detailed tasks using SpecPulse SDD methodology
category: SpecPulse
tags: [specpulse, tasks, breakdown, execution]
---

<!-- SPECPULSE:START -->
**Guardrails**
- CLI-first approach: Always try SpecPulse CLI commands before file operations
- Keep changes tightly scoped to the task breakdown outcome
- Only edit files in specs/, plans/, tasks/, memory/ directories - NEVER modify templates/ or internal config

**Critical Rules**
- **PRIMARY**: Use `specpulse task breakdown <plan-id>` when available
- **FALLBACK**: File Operations only if CLI fails
- **PROTECTED DIRECTORIES**: templates/, .specpulse/, specpulse/, .claude/, .gemini/, .windsurf/, .cursor/, .github/, .opencode/, .crush/
- **EDITABLE ONLY**: specs/, plans/, tasks/, memory/

**Steps**
Track these steps as TODOs and complete them one by one.

1. **Parse arguments** to extract plan reference and task options
2. **Determine current context**:
   - Read: memory/context.md
   - Extract current.feature and current.feature_id if available
3. **Try CLI first**:
   - Run `specpulse task breakdown <plan-id>`
   - If this succeeds, continue with task refinement
4. **If CLI doesn't exist, use File Operations**:
   - **Step 1: Read plan file**
     - Read: plans/current-feature_id/<plan-id>.md
     - Extract implementation phases and requirements
   - **Step 2: Create task breakdown file**
     - Create: tasks/current-feature_id/tasks-001.md (or next available number)
5. **Intelligent task breakdown**:
   - Analyze plan phases and create granular task breakdown
   - Generate comprehensive task sections:
     1. **Task Overview** (summary and scope)
     2. **Task Breakdown Structure** (hierarchical task list)
     3. **Task Details** (description, acceptance criteria, dependencies)
     4. **Effort Estimates** (time, complexity, skill requirements)
     5. **Execution Order** (dependencies and critical path)
   - Include validation criteria and deliverables

6. **Task optimization**:
   - Identify parallel execution opportunities
   - Optimize critical path
   - Assign resource requirements
   - Define milestones and checkpoints

**Reference**
- Use `specpulse task breakdown --help` for additional CLI options
- Check related plans for implementation phases
- Use `execute` to start task execution
- Run `specpulse doctor` if you encounter system issues
<!-- SPECPULSE:END -->