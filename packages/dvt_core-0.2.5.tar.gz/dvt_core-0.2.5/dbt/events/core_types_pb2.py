# preserving import path during dbtlabs.proto refactor
from dbtlabs.proto.public.v1.fields.core_types_pb2 import *  # noqa
