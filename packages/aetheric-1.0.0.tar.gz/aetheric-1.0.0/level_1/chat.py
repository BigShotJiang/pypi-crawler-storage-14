#!/usr/bin/env python3
import os, json, hmac, hashlib, asyncio, websockets, urllib.request, jwt
from datetime import datetime

SECRET = os.environ["APEX_SHARED_SECRET"]
KV_URL = os.environ["KV_REST_API_URL"]
KV_TOKEN = os.environ["KV_REST_API_TOKEN"]
LAST_KNOWN = 0

def kv(cmd, *args):
    req = urllib.request.Request(KV_URL, data=json.dumps([cmd] + list(args)).encode(),
                                 headers={"Authorization": f"Bearer {KV_TOKEN}"}, method="POST")
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read())["result"]

async def handler(ws):
    token = await ws.recv()
    if not token.startswith("Bearer "): await ws.close(); return
    try: payload = jwt.decode(token[7:], SECRET, algorithms=["HS512"])
    except: await ws.close(); return
    agent = payload["sub"]
    await ws.send(json.dumps({"type":"welcome","agent":agent}))
    global LAST_KNOWN
    msgs = [json.loads(m) for m in (kv("LRANGE", "council_messages/all", 0, -1) or [])]
    for m in msgs: await ws.send(json.dumps(m))
    while True:
        try:
            data = await asyncio.wait_for(ws.recv(), timeout=1)
            msg = json.loads(data)
            msg["agent_id"] = agent
            msg["timestamp_iso"] = datetime.utcnow().isoformat() + "Z"
            body = json.dumps(msg,separators=(',',':'),sort_keys=True).encode()
            msg["signature"] = hmac.new(SECRET.encode(), body, hashlib.sha512).hexdigest()
            kv("RPUSH", "council_messages/all", json.dumps(msg))
        except asyncio.TimeoutError:
            current = kv("LLEN", "council_messages/all") or 0
            if current > LAST_KNOWN:
                new = [json.loads(m) for m in kv("LRANGE", "council_messages/all", LAST_KNOWN, -1)]
                for m in new: await ws.send(json.dumps(m))
                LAST_KNOWN = current
        except: break

async def main():
    async with websockets.serve(handler, "", 8000):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())
