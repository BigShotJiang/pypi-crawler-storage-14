import json
import hmac
import hashlib
import os
import base64
import time
from http.server import BaseHTTPRequestHandler

class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        secret = os.getenv("APEX_SHARED_SECRET", "")
        if not secret:
            self.send_error(500, "missing secret")
            return

        headers = {k.lower(): v for k, v in self.headers.items()}
        auth = headers.get("authorization", "")

        if not auth.startswith("HMAC-SHA512 t="):
            self.send_error(401, "bad header")
            return

        try:
            t = auth.split("t=")[1].split(",s=")[0]
            sig = auth.split("s=")[1]
            timestamp = int(t)
            if abs(int(time.time()) - timestamp) > 120:
                self.send_error(403, "expired")
                return

            expected = hmac.new(secret.encode(), t.encode(), hashlib.sha512).digest()
            received = base64.b64decode(sig)

            if hmac.compare_digest(expected, received):
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"status":"BRIDGE ACTIVE","phase":"8"}).encode())
            else:
                self.send_error(403, "invalid signature")
        except Exception as e:
            self.send_error(400, f"bad request: {str(e)}")

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Authorization")
        self.end_headers()
