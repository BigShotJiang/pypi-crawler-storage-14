#!/usr/bin/env python3
import hashlib
import json
import os
import sys
import datetime

# CONSTITUTIONAL DOMAIN: LEVEL 0 CORTEX
TARGET_FILES = [
    "level_0/AethericContinuum.json",
    "level_0/AethericContinuum_Constitution_v4.json",
    "level_0/auth.py",
    "level_0/council.py",
    "level_0/tallyman.py",
    "level_0/key_rotation.py"
]

HASH_FILE = "continuity/cortex_hashes.json"

def calculate_file_hash(filepath):
    if not os.path.exists(filepath):
        return None
    with open(filepath, "rb") as f:
        return hashlib.sha512(f.read()).hexdigest()

def generate_baseline():
    print("[*] GENERATING NEW CORTEX BASELINE...")
    # Use timezone-aware UTC to avoid DeprecationWarning
    baseline = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "hashes": {}
    }
    
    for filepath in TARGET_FILES:
        h = calculate_file_hash(filepath)
        if h:
            baseline["hashes"][filepath] = h
            print(f"  [+] Hashed: {filepath}")
        else:
            print(f"  [!] MISSING: {filepath}")
            
    with open(HASH_FILE, "w") as f:
        json.dump(baseline, f, indent=2)
    print(f"[OK] BASELINE SAVED TO {HASH_FILE}")

def verify_integrity():
    print("[*] VERIFYING CORTEX INTEGRITY...")
    
    if not os.path.exists(HASH_FILE):
        print("[!] CRITICAL: No baseline found. Run with --generate first.")
        sys.exit(1)
        
    with open(HASH_FILE, "r") as f:
        baseline = json.load(f)
        
    integrity_breach = False
    
    for filepath, expected_hash in baseline["hashes"].items():
        current_hash = calculate_file_hash(filepath)
        
        if current_hash is None:
            print(f"[X] MISSING FILE: {filepath}")
            integrity_breach = True
        elif current_hash != expected_hash:
            print(f"[!] DRIFT DETECTED: {filepath}")
            print(f"    EXPECTED: {expected_hash[:16]}...")
            print(f"    ACTUAL:   {current_hash[:16]}...")
            integrity_breach = True
        else:
            print(f"[OK] {filepath}")
            
    if integrity_breach:
        print("\n[!!!] CORTEX INTEGRITY COMPROMISED [!!!]")
        sys.exit(1)
    else:
        print("\n[OK] CORTEX INTEGRITY VERIFIED.")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--generate":
        generate_baseline()
    else:
        verify_integrity()
