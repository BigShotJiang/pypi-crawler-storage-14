"""
AETHERIC CONTINUUM
GOVERNANCE: CONSTITUTION v3.1-final
COMPONENT: CORTEX_INDEX
VERSION: 1.3.6 - VERCEL COMPATIBLE CLASS HANDLER
STATUS: ACTIVE
"""
import json
import os
import urllib.request
from http.server import BaseHTTPRequestHandler

class Handler(BaseHTTPRequestHandler):
    def _get_dynamic_message(self):
        kv_url = os.getenv("KV_REST_API_URL", "").strip()
        kv_token = os.getenv("KV_REST_API_TOKEN", "").strip()
        default = os.getenv("APEX_GATE_MESSAGE", "Restricted Government Access").strip('"').strip("'")
        
        if not kv_url or not kv_token: return default
        try:
            url = f"{kv_url}/get/GATE_STATUS_MESSAGE"
            req = urllib.request.Request(url)
            req.add_header("Authorization", f"Bearer {kv_token}")
            with urllib.request.urlopen(req, timeout=2) as response:
                data = json.loads(response.read().decode())
                message = data.get("result")
                if message: return message
                return default
        except: return default

    def _send_response(self, code, body):
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(body, indent=2).encode())

    def do_GET(self):
        auth = self.headers.get("Authorization")
        expected_secret = os.getenv("APEX_ACCESS_KEY", "").strip().strip('"').strip("'")
        expected_auth = f"Bearer {expected_secret}" if expected_secret else None
        
        if not expected_auth or auth != expected_auth:
            msg = self._get_dynamic_message()
            self._send_response(403, {
                "status": "ACCESS_DENIED", 
                "message": msg,
                "endpoints": {
                    "GET /api/bridge": "Bridge communication (authenticated)",
                    "GET /": "Constitution access (authenticated)"
                }
            })
            return

        constit_path = os.path.join(os.getcwd(), "constitution/constitution.json")
        if not os.path.exists(constit_path):
            constit_path = os.path.join(os.getcwd(), "../constitution/constitution.json")

        if not os.path.exists(constit_path):
            self._send_response(500, {
                "error": "Constitution Missing from Sovereign Storage", 
                "path_checked": constit_path
            })
            return
        
        try:
            with open(constit_path, "r") as f: 
                data = json.load(f)
            self._send_response(200, data)
        except Exception as e:
            self._send_response(500, {"error": str(e)})
            
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
