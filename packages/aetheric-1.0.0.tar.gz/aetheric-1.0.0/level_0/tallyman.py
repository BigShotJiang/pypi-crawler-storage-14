#!/usr/bin/env python3
import json, hmac, hashlib, urllib.request, os
from datetime import datetime

SECRET = os.environ["APEX_SHARED_SECRET"]

def canonical(m): 
    return json.dumps(m, separators=(',', ':'), sort_keys=True).encode()

def verify(m):
    if "signature" not in m: return False
    expected = hmac.new(SECRET.encode(), canonical({k:v for k,v in m.items() if k!="signature"}), hashlib.sha512).hexdigest()
    return hmac.compare_digest(expected, m["signature"])

def tally(proposal_id):
    msgs = json.loads(urllib.request.urlopen("https://aetheric-continuum.vercel.app/api/council").read())
    valid = [m for m in msgs if verify(m) and m.get("proposal_id") == proposal_id]
    
    votes = {}
    veto = False
    for m in valid:
        if m["type"] == "VOTE":
            votes[m["agent_id"]] = m["vote"]
            if m["vote"] == "VETO": veto = True

    seated = {"HAWK","EYE","JUSTICE","ARCHITECT"}
    cast = len(set(votes.keys()) & seated)
    
    if veto: print("TALLY_SEAL → VETOED")
    elif cast < 3: print("TALLY_SEAL → QUORUM_FAILED")
    elif sum(1 for v in votes.values() if v=="AYE")/cast >= 0.66: print("TALLY_SEAL → RATIFIED")
    else: print("TALLY_SEAL → REJECTED")

if __name__ == "__main__":
    import sys
    tally(sys.argv[1])

# --- PHASE 23.2: REGENCY PROTOCOL ---
def check_regency(kv_client):
    """
    Determines if the Dead Man's Switch is active by checking KV store.
    If Zeus is silent for > 30 days, Veto power is suspended.
    """
    MAX_SILENCE = 86400 * 30 # 30 Days
    try:
        last_beat = kv_client("GET", "zeus_heartbeat")
        if not last_beat: return "SOVEREIGN_ACTIVE" # Assume active if no data
        
        if (time.time() - int(last_beat)) > MAX_SILENCE:
            return "REGENCY_ACTIVE"
    except:
        pass
    return "SOVEREIGN_ACTIVE"
