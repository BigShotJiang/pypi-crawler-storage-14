#!/usr/bin/env python3
import os, json, time, jwt
from http.server import BaseHTTPRequestHandler

# SECURITY CRITICAL: Fail if secret is default or missing
SECRET = os.environ.get("APEX_SHARED_SECRET")
if not SECRET or SECRET == "default_secret_change_me":
    raise SystemExit("CRITICAL SECURITY FAILURE: APEX_SHARED_SECRET is unset or default. System Halted.")

# CREDENTIAL ISOLATION: Load from Environment, never Source Control
AGENTS = json.loads(os.environ.get("COUNCIL_CREDENTIALS", "{}"))
if not AGENTS:
    print("⚠️ WARNING: COUNCIL_CREDENTIALS env var is empty. Login will fail.")

JWT_ALG = "HS256"
EXPIRY = 900  # 15 minutes

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path != "/login": 
            self.send_response(404); self.end_headers(); return
        try:
            length = int(self.headers.get("Content-Length", 0))
            data = json.loads(self.rfile.read(length))
            agent = data.get("agent_id")
            pwd = data.get("password")
            
            # Verify Credentials against Env
            if AGENTS.get(agent) != pwd:
                self.send_response(401)
                self.end_headers()
                self.wfile.write(b'{"error": "Invalid credentials"}')
                return

            # Generate Signed Token
            token = jwt.encode({
                "sub": agent,
                "iat": int(time.time()),
                "exp": int(time.time()) + EXPIRY,
                "tenant": "APEX_CORE"
            }, SECRET, algorithm=JWT_ALG)
            
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"token": token if isinstance(token, str) else token.decode('utf-8')}).encode())
        except Exception as e: 
            self.send_response(400)
            self.end_headers()
            # SECURE LOGGING: No sensitive data
            print(f"Auth Error: {e}")
