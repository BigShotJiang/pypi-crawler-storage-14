# aetheric v1.0.0 — Cryptographic Governance Primitive

- 5-seat Ed25519 signing
- 4-of-5 quorum enforcement
- BLAKE3-chained immutable ledger
- Python, TypeScript, Go SDKs

```bash
pip install aetheric
npm install @aetheric/core
go get github.com/aetheric/core
