from .core.signing import Seat
__version__ = "0.1.0"
from .core.quorum import requires_quorum
