from typing import List, Dict, Any, Callable
import json
from .ledger import append_entry

class QuorumError(Exception):
    pass

def requires_quorum(min_seats: int = 4, total_seats: int = 5):
    def decorator(func: Callable):
        def wrapper(*args, **kwargs):
            from aetheric.core.signing import Seat
            votes: List[Dict[str, Any]] = []
            for i in range(1, total_seats + 1):
                try:
                    seat = Seat(i)
                    vote = seat.sign({"function": func.__name__, "args": str(args), "kwargs": str(kwargs)})
                    votes.append(vote)
                except ValueError:
                    continue

            if len(votes) < min_seats:
                raise QuorumError(f"Quorum not reached: {len(votes)}/{min_seats}")

            result = func(*args, **kwargs)

            # IMMUTABLE LEDGER ENTRY
            append_entry({
                "action": func.__name__,
                "votes": votes,
                "result": result,
                "quorum": f"{len(votes)}/{total_seats}"
            })

            return {
                "result": result,
                "quorum": min_seats,
                "votes": votes,
                "proof": "4-of-5 quorum achieved, ledger updated"
            }
        return wrapper
    return decorator
