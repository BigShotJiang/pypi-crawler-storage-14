import json
import os
from blake3 import blake3
from typing import Any, Dict
from pathlib import Path

LEDGER_PATH = Path("ledger.jsonl")

def append_entry(entry: Dict[str, Any], prev_hash: str = None) -> str:
    if LEDGER_PATH.exists() and LEDGER_PATH.stat().st_size > 0:
        with open(LEDGER_PATH, "r") as f:
            lines = f.readlines()
            last_line = lines[-1].strip()
            prev_hash = json.loads(last_line)["hash"]
    else:
        prev_hash = "0" * 64

    entry_with_prev = {
        **entry,
        "prev_hash": prev_hash,
        "timestamp": __import__("time").time(),
    }
    payload = json.dumps(entry_with_prev, separators=(',', ':')).encode()
    current_hash = blake3(payload).hexdigest()

    final_entry = {**entry_with_prev, "hash": current_hash}

    with open(LEDGER_PATH, "a") as f:
        f.write(json.dumps(final_entry, separators=(',', ':')) + "\n")

    return current_hash

def verify_chain() -> bool:
    if not LEDGER_PATH.exists() or LEDGER_PATH.stat().st_size == 0:
        return True
    prev_hash = "0" * 64
    with open(LEDGER_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            entry = json.loads(line)
            if entry["prev_hash"] != prev_hash:
                return False
            payload = json.dumps({k: v for k, v in entry.items() if k != "hash"}, separators=(',', ':')).encode()
            prev_hash = blake3(payload).hexdigest()
            if prev_hash != entry["hash"]:
                return False
    return True
