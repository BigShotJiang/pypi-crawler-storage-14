import os
import base64
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization
from typing import Dict, Any

class Seat:
    def __init__(self, seat_id: int):
        self.seat_id = seat_id
        raw = os.getenv(f"SEAT_{seat_id}_PRIVATE_KEY")
        if not raw:
            raise ValueError(f"SEAT_{seat_id}_PRIVATE_KEY not set")

        # Handle both raw PEM and base64 (Railway format)
        try:
            # Try raw PEM first
            key = serialization.load_pem_private_key(raw.encode(), password=None)
        except ValueError:
            # Fall back to base64 decode
            pem_bytes = base64.b64decode(raw)
            key = serialization.load_pem_private_key(pem_bytes, password=None)

        self.private_key = key  # type: ed25519.Ed25519PrivateKey

    def sign(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        data = str(payload).encode()
        signature = self.private_key.sign(data).hex()
        return {
            "seat": f"seat-{self.seat_id}",
            "signature": signature,
            "payload": payload
        }
