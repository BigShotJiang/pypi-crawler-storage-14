import json
from aetheric import Seat

if __name__ == "__main__":
    seat = Seat(1)
    signed = seat.sign({"action": "test", "value": 42})
    print(json.dumps(signed, indent=2))
