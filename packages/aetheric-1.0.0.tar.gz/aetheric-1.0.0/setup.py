from setuptools import setup, find_packages

setup(
    name="aetheric",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "cryptography>=43.0.1",
    ],
    python_requires=">=3.9",
)
