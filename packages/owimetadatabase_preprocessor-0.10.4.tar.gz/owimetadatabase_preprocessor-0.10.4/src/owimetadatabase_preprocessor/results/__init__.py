"""A module to handle results data."""
