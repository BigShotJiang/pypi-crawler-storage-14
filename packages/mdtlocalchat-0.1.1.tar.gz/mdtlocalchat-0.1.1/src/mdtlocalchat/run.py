import uvicorn


def main():
    uvicorn.run("mdtlocalchat.main:app", host="127.0.0.1", port=11434, reload=True)


if __name__ == "__main__":
    main()
