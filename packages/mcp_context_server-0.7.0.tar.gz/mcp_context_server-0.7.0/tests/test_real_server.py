"""Integration tests for the real running MCP Context Storage Server.

Tests the actual server running via subprocess with uvx command,
verifying all 8 tools work correctly via FastMCP client.
"""

import asyncio
import base64
import os
import sqlite3
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import pytest
from fastmcp import Client


class MCPServerIntegrationTest:
    """Integration test for real MCP Context Storage Server."""

    def __init__(self, temp_db_path: Path | None = None) -> None:
        """Initialize the integration test suite.

        Args:
            temp_db_path: Optional path to temporary database.
        """
        self.client: Client[Any] | None = None
        self.test_results: list[tuple[str, bool, str]] = []
        self.test_thread_id = f'integration_test_{int(time.time())}'
        self.temp_db_path = temp_db_path
        self.original_env: dict[str, str | None] = {}

    async def start_server(self) -> bool:
        """Start the MCP server via FastMCP Client.

        Returns:
            bool: True (server starts automatically with Client).
        """
        print('[OK] Server will be started by FastMCP Client')
        return True

    async def connect_client(self) -> bool:
        """Connect FastMCP client to server.

        Returns:
            bool: True if client connected successfully.

        Raises:
            RuntimeError: If attempting to use default database in test mode.
        """
        try:
            # Use the wrapper script that sets up Python path correctly
            wrapper_script = Path(__file__).parent / 'run_server.py'
            print(f'[INFO] Connecting to server via wrapper: {wrapper_script}')

            # Environment variables MUST be set BEFORE creating Client
            # The Client spawns a subprocess that inherits the current environment
            if self.temp_db_path:
                # Store original env to restore later
                self.original_env['DB_PATH'] = os.environ.get('DB_PATH')
                self.original_env['MCP_TEST_MODE'] = os.environ.get('MCP_TEST_MODE')
                self.original_env['ENABLE_SEMANTIC_SEARCH'] = os.environ.get('ENABLE_SEMANTIC_SEARCH')

                # Set DB_PATH, MCP_TEST_MODE, and ENABLE_SEMANTIC_SEARCH
                # These MUST be set before Client() is called
                os.environ['DB_PATH'] = str(self.temp_db_path)
                os.environ['MCP_TEST_MODE'] = '1'  # THIS IS CRITICAL!
                os.environ['ENABLE_SEMANTIC_SEARCH'] = 'true'

                print('[INFO] Environment set BEFORE Client creation:')
                print(f"[INFO] DB_PATH={os.environ.get('DB_PATH')}")
                print(f"[INFO] MCP_TEST_MODE={os.environ.get('MCP_TEST_MODE')}")
                print(f"[INFO] ENABLE_SEMANTIC_SEARCH={os.environ.get('ENABLE_SEMANTIC_SEARCH')}")
                print(f'[INFO] Using temporary database: {self.temp_db_path}')

                # Verify it's not the default database
                default_db = Path.home() / '.mcp' / 'context_storage.db'
                if self.temp_db_path.resolve() == default_db.resolve():
                    raise RuntimeError(
                        f'CRITICAL: Attempting to use default database in test!\n'
                        f'Default: {default_db}\n'
                        f'Current: {self.temp_db_path}',
                    )

                # Initialize the database schema
                self._initialize_database()

            # Create client with wrapper script
            # The wrapper will detect pytest and force test mode with temp DB
            self.client = Client(str(wrapper_script))
            print(f'[INFO] Client created with wrapper: {wrapper_script}')

            # Connect to server
            await self.client.__aenter__()

            # Verify connection by pinging
            await self.client.ping()

            print('[OK] Client connected successfully')
            return True

        except Exception as e:
            print(f'[ERROR] Failed to connect client: {e}')
            import traceback

            traceback.print_exc()
            return False

    def _initialize_database(self) -> None:
        """Initialize the temporary database with schema."""
        if not self.temp_db_path:
            return

        try:
            # Ensure parent directory exists
            self.temp_db_path.parent.mkdir(parents=True, exist_ok=True)

            # Create database and apply schema
            from app.schemas import load_schema

            schema_sql = load_schema('sqlite')
            with sqlite3.connect(str(self.temp_db_path)) as conn:
                conn.executescript(schema_sql)

                # Apply optimizations
                conn.execute('PRAGMA foreign_keys = ON')
                conn.execute('PRAGMA journal_mode = WAL')
                conn.execute('PRAGMA synchronous = NORMAL')
                conn.execute('PRAGMA temp_store = MEMORY')
                conn.execute('PRAGMA busy_timeout = 30000')
                conn.commit()

            print(f'[OK] Database schema initialized at {self.temp_db_path}')
        except Exception as e:
            print(f'[WARNING] Failed to initialize database: {e}')
            # Continue anyway - the server will initialize on startup

    def _create_test_image(self) -> str:
        """Create a small test image as base64.

        Returns:
            str: Base64 encoded test image.
        """
        # Create a simple 1x1 pixel PNG image
        png_header = b'\x89PNG\r\n\x1a\n'
        ihdr = b'\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89'
        idat = b'\x00\x00\x00\x0bIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05W\xbf\xaa\xd4'
        iend = b'\x00\x00\x00\x00IEND\xaeB`\x82'
        png_data = png_header + ihdr + idat + iend
        return base64.b64encode(png_data).decode('utf-8')

    def _extract_content(self, result: object) -> dict[str, Any]:
        """Extract content from FastMCP CallToolResult.

        Args:
            result: CallToolResult object from FastMCP.

        Returns:
            dict: The actual result content.
        """
        # FastMCP CallToolResult has structured_content attribute
        content = getattr(result, 'structured_content', None)
        if content is not None:
            if isinstance(content, dict):
                # Handle wrapped results
                if 'result' in content:
                    if isinstance(content['result'], list):
                        return {'success': True, 'results': content['result']}
                    if isinstance(content['result'], dict):
                        return content['result']
                # Special handling for search_context - it returns entries and stats
                if 'entries' in content and 'stats' in content:
                    return {'success': True, 'results': content['entries'], 'stats': content['stats']}
                # Special handling for list_threads - it returns threads directly
                if 'threads' in content:
                    return {'success': True, 'threads': content['threads'], 'total_threads': content.get('total_threads', 0)}
                # Special handling for get_statistics - it returns stats directly
                if 'total_entries' in content:
                    return {'success': True, **content}  # Include all statistics fields
                # Direct dict results
                return content
            # List results
            if isinstance(content, list):
                return {'success': True, 'results': content}

        # Should not reach here with current FastMCP, but return error for safety
        return {'success': False, 'error': 'Unable to extract content from result'}

    async def test_store_context(self) -> bool:
        """Test storing text and multimodal context.

        Returns:
            bool: True if test passed.
        """
        test_name = 'store_context'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Test text storage
            text_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': self.test_thread_id,
                    'source': 'agent',  # Must be 'user' or 'agent'
                    'text': 'This is a test message for integration testing',
                    'metadata': {'test': True, 'timestamp': time.time()},
                    'tags': ['test', 'integration'],
                },
            )

            text_data = self._extract_content(text_result)
            print(f'DEBUG store text_data: {text_data}')  # Debug output

            # store_context returns a dict with success and nested results
            if not text_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to store text context: {text_data}'))
                return False

            # Extract context_id directly from response
            text_context_id = text_data.get('context_id')
            print(f'DEBUG text_context_id: {text_context_id}')  # Debug output

            # Test image storage
            image_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': self.test_thread_id,
                    'source': 'user',  # Must be 'user' or 'agent'
                    'text': 'Test message with image',
                    'images': [
                        {
                            'data': self._create_test_image(),
                            'mime_type': 'image/png',
                        },
                    ],
                    'tags': ['test', 'image'],
                },
            )

            image_data = self._extract_content(image_result)
            print(f'DEBUG store image_data: {image_data}')  # Debug output

            # store_context returns a dict with success and nested results
            if not image_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to store image context: {image_data}'))
                return False

            # Extract context_id directly from response
            image_context_id = image_data.get('context_id')
            print(f'DEBUG image_context_id: {image_context_id}')  # Debug output

            # Verify both contexts were stored
            if text_context_id and image_context_id:
                self.test_results.append((test_name, True, f'Stored contexts: {text_context_id}, {image_context_id}'))
                return True
            self.test_results.append((test_name, False, 'Missing context IDs'))
            return False

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_search_context(self) -> bool:
        """Test searching with various filters.

        Returns:
            bool: True if test passed.
        """
        test_name = 'search_context'
        assert self.client is not None  # Type guard for Pyright
        try:
            # First store some test data
            await self.client.call_tool(
                'store_context',
                {
                    'thread_id': self.test_thread_id,
                    'source': 'user',  # Must be 'user' or 'agent'
                    'text': 'Message for search testing',
                    'tags': ['searchable', 'test'],
                },
            )

            # Test search by thread
            thread_results = await self.client.call_tool(
                'search_context',
                {'thread_id': self.test_thread_id},
            )

            thread_data = self._extract_content(thread_results)

            # search_context returns success with results
            if not thread_data.get('success'):
                self.test_results.append((test_name, False, f'Thread search failed: {thread_data}'))
                return False

            # Test search by source
            source_results = await self.client.call_tool(
                'search_context',
                {'source': 'user'},
            )

            source_data = self._extract_content(source_results)

            # search_context returns success with results
            if not source_data.get('success'):
                self.test_results.append((test_name, False, f'Source search failed: {source_data}'))
                return False

            # Test search by tags
            tag_results = await self.client.call_tool(
                'search_context',
                {'tags': ['searchable']},
            )

            tag_data = self._extract_content(tag_results)

            # search_context returns success with results
            if not tag_data.get('success'):
                self.test_results.append((test_name, False, f'Tag search failed: {tag_data}'))
                return False

            # Test pagination
            paginated_results = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': self.test_thread_id,
                    'limit': 1,
                    'offset': 0,
                },
            )

            paginated_data = self._extract_content(paginated_results)

            # search_context returns success with results
            if not paginated_data.get('success'):
                self.test_results.append((test_name, False, f'Pagination failed: {paginated_data}'))
                return False

            # Verify all searches returned results
            all_have_results = all([
                len(thread_data.get('results', [])) > 0,
                len(source_data.get('results', [])) > 0,
                len(tag_data.get('results', [])) > 0,
                len(paginated_data.get('results', [])) > 0,
            ])

            if all_have_results:
                self.test_results.append((test_name, True, 'All search filters working'))
                return True
            self.test_results.append((test_name, False, 'Some searches returned no results'))
            return False

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_metadata_filtering(self) -> bool:
        """Test advanced metadata filtering functionality.

        Returns:
            bool: True if all tests pass.
        """
        test_name = 'Metadata Filtering'
        print('Testing metadata filtering...')

        # Store test context entries with various metadata
        test_entries = [
            {
                'thread_id': f'{self.test_thread_id}_metadata',
                'source': 'agent',
                'text': 'High priority task',
                'metadata': {'status': 'active', 'priority': 10, 'agent_name': 'analyzer'},
            },
            {
                'thread_id': f'{self.test_thread_id}_metadata',
                'source': 'agent',
                'text': 'Medium priority task',
                'metadata': {'status': 'active', 'priority': 5, 'agent_name': 'coordinator'},
            },
            {
                'thread_id': f'{self.test_thread_id}_metadata',
                'source': 'agent',
                'text': 'Low priority completed',
                'metadata': {'status': 'completed', 'priority': 1, 'completed': True},
            },
            {
                'thread_id': f'{self.test_thread_id}_metadata',
                'source': 'agent',
                'text': 'Failed task',
                'metadata': {'status': 'failed', 'priority': 8},
            },
        ]

        try:
            # Store all test entries
            assert self.client is not None  # Type guard for Pyright
            for entry in test_entries:
                result = await self.client.call_tool('store_context', entry)
                result_data = self._extract_content(result)
                if not result_data.get('success'):
                    print(f'Failed to store test entry: {result_data}')
                    self.test_results.append((test_name, False, 'Failed to store test entries'))
                    return False

            # Test 1: Simple metadata filtering
            result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': f'{self.test_thread_id}_metadata',
                    'metadata': {'status': 'active'},
                },
            )
            result_data = self._extract_content(result)
            if len(result_data.get('results', [])) != 2:
                print(f"Simple filter failed: expected 2, got {len(result_data.get('results', []))}")
                self.test_results.append((test_name, False, 'Simple metadata filter failed'))
                return False

            # Test 2: Advanced metadata filtering with gte operator
            result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': f'{self.test_thread_id}_metadata',
                    'metadata_filters': [{'key': 'priority', 'operator': 'gte', 'value': 5}],
                },
            )
            result_data = self._extract_content(result)
            if len(result_data.get('results', [])) != 3:
                print(f"Advanced gte filter failed: expected 3, got {len(result_data.get('results', []))}")
                self.test_results.append((test_name, False, 'Advanced gte filter failed'))
                return False

            # Test 3: Combined metadata filters
            result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': f'{self.test_thread_id}_metadata',
                    'metadata': {'status': 'active'},
                    'metadata_filters': [{'key': 'priority', 'operator': 'gt', 'value': 7}],
                },
            )
            result_data = self._extract_content(result)
            if len(result_data.get('results', [])) != 1:
                print(f"Combined filter failed: expected 1, got {len(result_data.get('results', []))}")
                self.test_results.append((test_name, False, 'Combined filter failed'))
                return False

            # Test 4: Exists operator
            result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': f'{self.test_thread_id}_metadata',
                    'metadata_filters': [{'key': 'completed', 'operator': 'exists', 'value': None}],
                },
            )
            result_data = self._extract_content(result)
            if len(result_data.get('results', [])) != 1:
                print(f"Exists filter failed: expected 1, got {len(result_data.get('results', []))}")
                self.test_results.append((test_name, False, 'Exists operator filter failed'))
                return False

            # Test 5: In operator
            result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': f'{self.test_thread_id}_metadata',
                    'metadata_filters': [{'key': 'agent_name', 'operator': 'in', 'value': ['analyzer', 'coordinator']}],
                },
            )
            result_data = self._extract_content(result)
            if len(result_data.get('results', [])) != 2:
                print(f"In operator filter failed: expected 2, got {len(result_data.get('results', []))}")
                self.test_results.append((test_name, False, 'In operator filter failed'))
                return False

            print('[OK] All metadata filtering tests passed')
            self.test_results.append((test_name, True, 'All tests passed'))
            return True

        except Exception as e:
            print(f'Test failed with exception: {e}')
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_get_context_by_ids(self) -> bool:
        """Test retrieving specific contexts by IDs.

        Returns:
            bool: True if test passed.
        """
        test_name = 'get_context_by_ids'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Store test data
            result1 = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': self.test_thread_id,
                    'source': 'agent',  # Must be 'user' or 'agent'
                    'text': 'First context for retrieval',
                },
            )

            result2 = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': self.test_thread_id,
                    'source': 'user',  # Must be 'user' or 'agent'
                    'text': 'Second context with image',
                    'images': [
                        {
                            'data': self._create_test_image(),
                            'mime_type': 'image/png',
                        },
                    ],
                },
            )

            data1 = self._extract_content(result1)
            data2 = self._extract_content(result2)

            if not (data1.get('success') and data2.get('success')):
                self.test_results.append((test_name, False, f'Failed to store test contexts: {data1}, {data2}'))
                return False

            context_ids = [data1['context_id'], data2['context_id']]

            # Test retrieval without images
            without_images = await self.client.call_tool(
                'get_context_by_ids',
                {
                    'context_ids': context_ids,
                    'include_images': False,
                },
            )

            without_data = self._extract_content(without_images)

            # get_context_by_ids returns success with results
            if not without_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to retrieve without images: {without_data}'))
                return False

            # Test retrieval with images
            with_images = await self.client.call_tool(
                'get_context_by_ids',
                {
                    'context_ids': context_ids,
                    'include_images': True,
                },
            )

            with_data = self._extract_content(with_images)

            # get_context_by_ids returns success with results
            if not with_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to retrieve with images: {with_data}'))
                return False

            # Verify both retrievals got the correct number of results
            if len(without_data.get('results', [])) == 2 and len(with_data.get('results', [])) == 2:
                self.test_results.append((test_name, True, f'Retrieved {len(context_ids)} contexts'))
                return True
            self.test_results.append((test_name, False, 'Incorrect number of results'))
            return False

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_delete_context(self) -> bool:
        """Test deletion operations.

        Returns:
            bool: True if test passed.
        """
        test_name = 'delete_context'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Create a separate thread for deletion tests
            delete_thread = f'{self.test_thread_id}_delete'

            # Store multiple contexts
            result1 = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': delete_thread,
                    'source': 'user',  # Must be 'user' or 'agent'
                    'text': 'Context to delete by ID',
                },
            )

            result2 = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': delete_thread,
                    'source': 'agent',  # Must be 'user' or 'agent'
                    'text': 'Context to delete with thread',
                },
            )

            result3 = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': delete_thread,
                    'source': 'user',  # Must be 'user' or 'agent'
                    'text': 'Another context in thread',
                },
            )

            data1 = self._extract_content(result1)
            data2 = self._extract_content(result2)
            data3 = self._extract_content(result3)

            if not all([
                data1.get('success'),
                data2.get('success'),
                data3.get('success'),
            ]):
                self.test_results.append((test_name, False, f'Failed to store test contexts: {data1}, {data2}, {data3}'))
                return False

            # Test delete by ID
            delete_by_id = await self.client.call_tool(
                'delete_context',
                {'context_ids': [data1['context_id']]},
            )

            delete_data = self._extract_content(delete_by_id)

            if not delete_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to delete by ID: {delete_data}'))
                return False

            # Verify deletion by trying to retrieve
            check_deleted = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [data1['context_id']]},
            )

            check_data = self._extract_content(check_deleted)

            # get_context_by_ids returns success with results
            if len(check_data.get('results', [])) > 0:
                self.test_results.append((test_name, False, f'Context not deleted by ID: {check_data}'))
                return False

            # Test delete by thread
            delete_by_thread = await self.client.call_tool(
                'delete_context',
                {'thread_id': delete_thread},
            )

            thread_delete_data = self._extract_content(delete_by_thread)

            if not thread_delete_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to delete by thread: {thread_delete_data}'))
                return False

            # Verify thread deletion
            check_thread = await self.client.call_tool(
                'search_context',
                {'thread_id': delete_thread},
            )

            check_thread_data = self._extract_content(check_thread)

            # search_context returns success with results
            if len(check_thread_data.get('results', [])) > 0:
                self.test_results.append((test_name, False, f'Thread contexts not deleted: {check_thread_data}'))
                return False

            deleted_count = delete_data.get('deleted_count', 0) + thread_delete_data.get('deleted_count', 0)
            self.test_results.append((test_name, True, f'Deleted {deleted_count} contexts'))
            return True

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_list_threads(self) -> bool:
        """Test thread listing resource.

        Returns:
            bool: True if test passed.
        """
        test_name = 'list_threads'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Create multiple threads with contexts
            threads = [
                f'{self.test_thread_id}_list_1',
                f'{self.test_thread_id}_list_2',
                f'{self.test_thread_id}_list_3',
            ]

            for thread in threads:
                # Store multiple contexts per thread
                for i in range(3):
                    result = await self.client.call_tool(
                        'store_context',
                        {
                            'thread_id': thread,
                            'source': 'agent' if i % 2 == 0 else 'user',  # Alternate sources
                            'text': f'Message {i} in {thread}',
                        },
                    )
                    data = self._extract_content(result)
                    if not data.get('success'):
                        self.test_results.append((test_name, False, f'Failed to store context for {thread}: {data}'))
                        return False

            # List threads
            thread_list = await self.client.call_tool('list_threads', {})

            list_data = self._extract_content(thread_list)

            # list_threads returns a dict with threads array (no success flag needed)
            if 'threads' not in list_data:
                self.test_results.append((test_name, False, f'Failed to list threads: {list_data}'))
                return False

            # Verify threads are in the list
            listed_threads = list_data['threads']
            thread_ids = [t['thread_id'] for t in listed_threads]

            all_present = all(thread in thread_ids for thread in threads)

            if all_present:
                # Check that threads have correct statistics
                for thread_info in listed_threads:
                    if thread_info['thread_id'] in threads and thread_info.get('entry_count', 0) != 3:
                        error_msg = f"Thread {thread_info['thread_id']} has wrong count: {thread_info.get('entry_count', 0)}"
                        self.test_results.append((test_name, False, error_msg))
                        return False

                self.test_results.append((test_name, True, f'Listed {len(threads)} test threads with correct counts'))
                return True
            self.test_results.append((test_name, False, 'Not all threads present in list'))
            return False

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_get_statistics(self) -> bool:
        """Test statistics resource.

        Returns:
            bool: True if test passed.
        """
        test_name = 'get_statistics'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Get current statistics
            stats = await self.client.call_tool('get_statistics', {})

            stats_data = self._extract_content(stats)

            # Check if we have the statistics fields (no success field needed)
            if 'total_entries' not in stats_data:
                self.test_results.append((test_name, False, f'Failed to get statistics: {stats_data}'))
                return False

            # Store a new context
            result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': f'{self.test_thread_id}_stats',
                    'source': 'user',  # Must be 'user' or 'agent'
                    'text': 'Context for statistics test',
                    'images': [
                        {
                            'data': self._create_test_image(),
                            'mime_type': 'image/png',
                        },
                    ],
                },
            )

            result_data = self._extract_content(result)

            if not result_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to store test context'))
                return False

            # Get updated statistics
            new_stats = await self.client.call_tool('get_statistics', {})

            new_stats_data = self._extract_content(new_stats)

            # Check if we have the statistics fields (no success field needed)
            if 'total_entries' not in new_stats_data:
                self.test_results.append((test_name, False, f'Failed to get updated statistics: {new_stats_data}'))
                return False

            # Verify statistics increased
            old_count = stats_data.get('total_entries', 0)
            new_count = new_stats_data.get('total_entries', 0)
            old_images = stats_data.get('total_images', 0)
            new_images = new_stats_data.get('total_images', 0)

            if new_count > old_count and new_images > old_images:
                self.test_results.append(
                    (test_name, True, f'Stats updated: entries {old_count}->{new_count}, images {old_images}->{new_images}'),
                )
                return True
            self.test_results.append((test_name, False, 'Statistics not updated correctly'))
            return False

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_update_context(self) -> bool:
        """Test updating existing context entries.

        Returns:
            bool: True if test passed.
        """
        test_name = 'update_context'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Create a separate thread for update tests
            update_thread = f'{self.test_thread_id}_update'

            # Store initial context
            initial_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': update_thread,
                    'source': 'agent',
                    'text': 'Initial text content',
                    'metadata': {'status': 'draft', 'priority': 1},
                    'tags': ['initial', 'test'],
                },
            )

            initial_data = self._extract_content(initial_result)

            if not initial_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to store initial context: {initial_data}'))
                return False

            context_id = initial_data.get('context_id')

            # Test 1: Update text only
            update_text_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'text': 'Updated text content',
                },
            )

            update_text_data = self._extract_content(update_text_result)

            if not update_text_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to update text: {update_text_data}'))
                return False

            # Verify text was updated
            verify_result = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_data = self._extract_content(verify_result)

            if not verify_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify text update'))
                return False

            updated_entry = verify_data['results'][0]

            if updated_entry.get('text_content') != 'Updated text content':
                self.test_results.append((test_name, False, 'Text not updated correctly'))
                return False

            # Test 2: Update metadata only
            update_metadata_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata': {'status': 'completed', 'priority': 10, 'reviewed': True},
                },
            )

            update_metadata_data = self._extract_content(update_metadata_result)

            if not update_metadata_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to update metadata: {update_metadata_data}'))
                return False

            # Test 3: Update tags (replacement)
            update_tags_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'tags': ['updated', 'final'],
                },
            )

            update_tags_data = self._extract_content(update_tags_result)

            if not update_tags_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to update tags: {update_tags_data}'))
                return False

            # Test 4: Add images (verify content_type changes to multimodal)
            update_images_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'images': [
                        {
                            'data': self._create_test_image(),
                            'mime_type': 'image/png',
                        },
                    ],
                },
            )

            update_images_data = self._extract_content(update_images_result)

            if not update_images_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to add images: {update_images_data}'))
                return False

            # Verify content_type changed to multimodal
            verify_multimodal = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id], 'include_images': True},
            )

            verify_multimodal_data = self._extract_content(verify_multimodal)

            if not verify_multimodal_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify multimodal update'))
                return False

            multimodal_entry = verify_multimodal_data['results'][0]

            if multimodal_entry.get('content_type') != 'multimodal':
                self.test_results.append((test_name, False, 'Content type not changed to multimodal'))
                return False

            # Test 5: Remove images (verify content_type changes back to text)
            remove_images_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'images': [],
                },
            )

            remove_images_data = self._extract_content(remove_images_result)

            if not remove_images_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to remove images: {remove_images_data}'))
                return False

            # Verify content_type changed back to text
            verify_text_type = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_text_type_data = self._extract_content(verify_text_type)

            if not verify_text_type_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify text-only update'))
                return False

            text_only_entry = verify_text_type_data['results'][0]

            if text_only_entry.get('content_type') != 'text':
                self.test_results.append((test_name, False, 'Content type not changed back to text'))
                return False

            # Test 6: Metadata patch - add new field to existing metadata
            # First restore metadata for patch testing
            restore_metadata_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata': {'status': 'active', 'priority': 5},
                },
            )

            restore_metadata_data = self._extract_content(restore_metadata_result)

            if not restore_metadata_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to restore metadata: {restore_metadata_data}'))
                return False

            # Now patch to add new field
            patch_add_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata_patch': {'new_field': 'added_value'},
                },
            )

            patch_add_data = self._extract_content(patch_add_result)

            if not patch_add_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to patch-add new field: {patch_add_data}'))
                return False

            # Verify patch added new field while preserving existing ones
            verify_patch_add = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_patch_add_data = self._extract_content(verify_patch_add)

            if not verify_patch_add_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify patch-add'))
                return False

            patched_metadata = verify_patch_add_data['results'][0].get('metadata', {})

            # Check that existing fields are preserved and new field was added
            if patched_metadata.get('status') != 'active':
                self.test_results.append((test_name, False, 'Patch-add did not preserve existing status field'))
                return False

            if patched_metadata.get('priority') != 5:
                self.test_results.append((test_name, False, 'Patch-add did not preserve existing priority field'))
                return False

            if patched_metadata.get('new_field') != 'added_value':
                self.test_results.append((test_name, False, 'Patch-add did not add new field'))
                return False

            # Test 7: Metadata patch - update existing field
            patch_update_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata_patch': {'priority': 10},
                },
            )

            patch_update_data = self._extract_content(patch_update_result)

            if not patch_update_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to patch-update existing field: {patch_update_data}'))
                return False

            # Verify patch updated field while preserving others
            verify_patch_update = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_patch_update_data = self._extract_content(verify_patch_update)

            if not verify_patch_update_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify patch-update'))
                return False

            updated_metadata = verify_patch_update_data['results'][0].get('metadata', {})

            if updated_metadata.get('priority') != 10:
                self.test_results.append((test_name, False, 'Patch-update did not change priority'))
                return False

            if updated_metadata.get('status') != 'active':
                self.test_results.append((test_name, False, 'Patch-update did not preserve status field'))
                return False

            if updated_metadata.get('new_field') != 'added_value':
                self.test_results.append((test_name, False, 'Patch-update did not preserve new_field'))
                return False

            # Test 8: Metadata patch - delete field with null value (RFC 7396 semantics)
            patch_delete_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata_patch': {'new_field': None},
                },
            )

            patch_delete_data = self._extract_content(patch_delete_result)

            if not patch_delete_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to patch-delete field: {patch_delete_data}'))
                return False

            # Verify patch deleted the field
            verify_patch_delete = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_patch_delete_data = self._extract_content(verify_patch_delete)

            if not verify_patch_delete_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify patch-delete'))
                return False

            deleted_metadata = verify_patch_delete_data['results'][0].get('metadata', {})

            if 'new_field' in deleted_metadata:
                self.test_results.append((test_name, False, 'Patch-delete did not remove field (RFC 7396 null semantics)'))
                return False

            if deleted_metadata.get('status') != 'active' or deleted_metadata.get('priority') != 10:
                self.test_results.append((test_name, False, 'Patch-delete modified other fields'))
                return False

            # Test 9: Mutual exclusivity - providing both metadata and metadata_patch should fail
            # The server raises ToolError which may propagate as an exception to the client
            mutual_exclusivity_validated = False
            try:
                mutual_exclusion_result = await self.client.call_tool(
                    'update_context',
                    {
                        'context_id': context_id,
                        'metadata': {'full': 'replacement'},
                        'metadata_patch': {'partial': 'update'},
                    },
                )

                mutual_exclusion_data = self._extract_content(mutual_exclusion_result)

                # If we get here without exception, check the response
                if mutual_exclusion_data.get('success'):
                    self.test_results.append(
                        (test_name, False, 'Mutual exclusivity check failed - both metadata and metadata_patch accepted'),
                    )
                    return False

                # Check error message in response
                error_msg = mutual_exclusion_data.get('error', '')
                error_mentions_mutual_exclusivity = 'mutual' in error_msg.lower() or 'exclusive' in error_msg.lower()
                error_mentions_metadata_params = 'metadata' in error_msg.lower() and 'patch' in error_msg.lower()
                if error_mentions_mutual_exclusivity or error_mentions_metadata_params:
                    mutual_exclusivity_validated = True
                else:
                    self.test_results.append(
                        (test_name, False, f'Mutual exclusivity error message unclear: {error_msg}'),
                    )
                    return False

            except Exception as mutual_exc:
                # ToolError is expected - verify the error message mentions mutual exclusivity
                error_msg = str(mutual_exc)
                error_mentions_mutual_exclusivity = 'mutual' in error_msg.lower() or 'exclusive' in error_msg.lower()
                error_mentions_metadata_params = 'metadata' in error_msg.lower() and 'patch' in error_msg.lower()
                if error_mentions_mutual_exclusivity or error_mentions_metadata_params:
                    mutual_exclusivity_validated = True
                else:
                    self.test_results.append(
                        (test_name, False, f'Unexpected exception during mutual exclusivity test: {mutual_exc}'),
                    )
                    return False

            if not mutual_exclusivity_validated:
                self.test_results.append((test_name, False, 'Mutual exclusivity validation did not complete'))
                return False

            # Test 10: Metadata patch on context with no existing metadata
            # Create new context without metadata
            no_metadata_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': update_thread,
                    'source': 'agent',
                    'text': 'Context without initial metadata',
                },
            )

            no_metadata_data = self._extract_content(no_metadata_result)

            if not no_metadata_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to create context without metadata: {no_metadata_data}'))
                return False

            no_metadata_context_id = no_metadata_data.get('context_id')

            # Apply patch to context with no metadata
            patch_empty_result = await self.client.call_tool(
                'update_context',
                {
                    'context_id': no_metadata_context_id,
                    'metadata_patch': {'created_via': 'patch', 'version': 1},
                },
            )

            patch_empty_data = self._extract_content(patch_empty_result)

            if not patch_empty_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to patch empty metadata: {patch_empty_data}'))
                return False

            # Verify metadata was created from scratch
            verify_patch_empty = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [no_metadata_context_id]},
            )

            verify_patch_empty_data = self._extract_content(verify_patch_empty)

            if not verify_patch_empty_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify patch on empty metadata'))
                return False

            created_metadata = verify_patch_empty_data['results'][0].get('metadata', {})

            if created_metadata.get('created_via') != 'patch' or created_metadata.get('version') != 1:
                self.test_results.append((test_name, False, 'Patch on empty metadata did not create expected fields'))
                return False

            # Verify immutable fields remain unchanged
            if text_only_entry.get('thread_id') != update_thread or text_only_entry.get('source') != 'agent':
                self.test_results.append((test_name, False, 'Immutable fields were modified'))
                return False

            self.test_results.append((test_name, True, 'All update operations passed'))
            return True

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_metadata_patch_deep_merge(self) -> bool:
        """Test RFC 7396 deep merge semantics for metadata_patch.

        This test verifies that nested objects are correctly merged according to
        RFC 7396 JSON Merge Patch specification, including deep merge and nested
        null deletion.

        RFC 7396 Specification: https://datatracker.ietf.org/doc/html/rfc7396

        Returns:
            bool: True if all deep merge tests passed.
        """
        test_name = 'metadata_patch_deep_merge'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Create a separate thread for deep merge tests
            deep_merge_thread = f'{self.test_thread_id}_deep_merge'

            # Test 1: Setup - Create context with nested metadata
            setup_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': deep_merge_thread,
                    'source': 'agent',
                    'text': 'Context for RFC 7396 deep merge testing',
                    'metadata': {
                        'a': {
                            'b': 'original_b',
                            'd': 'original_d',
                        },
                        'top_level': 'preserved',
                    },
                },
            )

            setup_data = self._extract_content(setup_result)
            if not setup_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to create test context: {setup_data}'))
                return False

            context_id = setup_data.get('context_id')

            # Test 2: RFC 7396 Case #7 - Deep merge with nested update (preserves siblings)
            # Patch: {"a": {"b": "updated"}} should preserve "d" in nested object
            patch_deep_merge = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata_patch': {'a': {'b': 'updated_b'}},
                },
            )

            patch_deep_data = self._extract_content(patch_deep_merge)
            if not patch_deep_data.get('success'):
                self.test_results.append((test_name, False, f'Failed deep merge patch: {patch_deep_data}'))
                return False

            # Verify deep merge preserved sibling key
            verify_deep = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_deep_data = self._extract_content(verify_deep)
            if not verify_deep_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify deep merge'))
                return False

            deep_metadata = verify_deep_data['results'][0].get('metadata', {})

            # RFC 7396: Nested sibling key "d" MUST be preserved
            if deep_metadata.get('a', {}).get('b') != 'updated_b':
                self.test_results.append((test_name, False, 'Deep merge did not update nested key "b"'))
                return False

            if deep_metadata.get('a', {}).get('d') != 'original_d':
                error_msg = f'RFC 7396 VIOLATION: Deep merge did not preserve sibling key "d". Got: {deep_metadata}'
                self.test_results.append((test_name, False, error_msg))
                return False

            if deep_metadata.get('top_level') != 'preserved':
                self.test_results.append((test_name, False, 'Deep merge did not preserve top-level key'))
                return False

            # Test 3: Nested null deletion (RFC 7396 Case #7 variant)
            # Patch: {"a": {"b": null}} should delete "b" but preserve "d"
            patch_nested_delete = await self.client.call_tool(
                'update_context',
                {
                    'context_id': context_id,
                    'metadata_patch': {'a': {'b': None}},  # RFC 7396: null means delete
                },
            )

            patch_delete_data = self._extract_content(patch_nested_delete)
            if not patch_delete_data.get('success'):
                self.test_results.append((test_name, False, f'Failed nested deletion patch: {patch_delete_data}'))
                return False

            # Verify nested deletion preserved sibling
            verify_delete = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [context_id]},
            )

            verify_delete_data = self._extract_content(verify_delete)
            if not verify_delete_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify nested deletion'))
                return False

            delete_metadata = verify_delete_data['results'][0].get('metadata', {})

            # RFC 7396: Key "b" should be deleted
            if 'b' in delete_metadata.get('a', {}):
                self.test_results.append(
                    (test_name, False, f'RFC 7396 VIOLATION: Nested null did not delete key "b". Got: {delete_metadata}'),
                )
                return False

            # RFC 7396: Key "d" MUST be preserved
            if delete_metadata.get('a', {}).get('d') != 'original_d':
                error_msg = f'RFC 7396 VIOLATION: Nested deletion did not preserve "d". Got: {delete_metadata}'
                self.test_results.append((test_name, False, error_msg))
                return False

            # Test 4: Deeply nested null deletion (RFC 7396 Case #15)
            # Create new context for this test
            deep_nested_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': deep_merge_thread,
                    'source': 'agent',
                    'text': 'Context for deeply nested null test',
                    'metadata': {},  # Start empty
                },
            )

            deep_nested_data = self._extract_content(deep_nested_result)
            if not deep_nested_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to create deeply nested test context'))
                return False

            deep_context_id = deep_nested_data.get('context_id')

            # RFC 7396 Case #15: {"a": {"bb": {"ccc": null}}} should result in {"a": {"bb": {}}}
            patch_deep_null = await self.client.call_tool(
                'update_context',
                {
                    'context_id': deep_context_id,
                    'metadata_patch': {'a': {'bb': {'ccc': None}}},
                },
            )

            patch_deep_null_data = self._extract_content(patch_deep_null)
            if not patch_deep_null_data.get('success'):
                self.test_results.append((test_name, False, f'Failed deeply nested null patch: {patch_deep_null_data}'))
                return False

            # Verify deeply nested structure
            verify_deep_null = await self.client.call_tool(
                'get_context_by_ids',
                {'context_ids': [deep_context_id]},
            )

            verify_deep_null_data = self._extract_content(verify_deep_null)
            if not verify_deep_null_data.get('success'):
                self.test_results.append((test_name, False, 'Failed to verify deeply nested null'))
                return False

            deep_null_metadata = verify_deep_null_data['results'][0].get('metadata', {})

            # RFC 7396 Case #15: Expected {"a": {"bb": {}}}
            # The deeply nested null should create empty nested objects, not include null
            if 'a' not in deep_null_metadata:
                self.test_results.append(
                    (test_name, False, f'RFC 7396 Case #15 VIOLATION: Missing top-level "a". Got: {deep_null_metadata}'),
                )
                return False

            if 'bb' not in deep_null_metadata.get('a', {}):
                self.test_results.append(
                    (test_name, False, f'RFC 7396 Case #15 VIOLATION: Missing nested "bb". Got: {deep_null_metadata}'),
                )
                return False

            # The key "ccc" should NOT exist (deleted by null)
            if 'ccc' in deep_null_metadata.get('a', {}).get('bb', {}):
                self.test_results.append(
                    (test_name, False, f'RFC 7396 Case #15 VIOLATION: Key "ccc" should be deleted. Got: {deep_null_metadata}'),
                )
                return False

            self.test_results.append((test_name, True, 'All RFC 7396 deep merge tests passed'))
            return True

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_search_context_with_date_filtering(self) -> bool:
        """Test search_context with start_date and end_date parameters.

        Returns:
            bool: True if test passed.
        """
        test_name = 'search_context_date_filtering'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Create a separate thread for date filtering tests
            date_filter_thread = f'{self.test_thread_id}_date_filter'

            # Store a test entry (will be created at current time)
            store_result = await self.client.call_tool(
                'store_context',
                {
                    'thread_id': date_filter_thread,
                    'source': 'user',
                    'text': 'Entry for date filtering test',
                    'tags': ['date-filter', 'test'],
                },
            )

            store_data = self._extract_content(store_result)
            if not store_data.get('success'):
                self.test_results.append((test_name, False, f'Failed to store test entry: {store_data}'))
                return False

            # Get current date information for testing
            from datetime import UTC
            from datetime import datetime
            from datetime import timedelta

            today = datetime.now(UTC).strftime('%Y-%m-%d')
            tomorrow = (datetime.now(UTC) + timedelta(days=1)).strftime('%Y-%m-%d')
            yesterday = (datetime.now(UTC) - timedelta(days=1)).strftime('%Y-%m-%d')
            future_date = (datetime.now(UTC) + timedelta(days=30)).strftime('%Y-%m-%d')
            past_date = (datetime.now(UTC) - timedelta(days=30)).strftime('%Y-%m-%d')

            # Test 1: Search with valid date range (today to tomorrow) - should find entry
            valid_range_result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': date_filter_thread,
                    'start_date': today,
                    'end_date': tomorrow,
                },
            )
            valid_range_data = self._extract_content(valid_range_result)
            if not valid_range_data.get('success') or len(valid_range_data.get('results', [])) != 1:
                self.test_results.append(
                    (test_name, False, f'Valid date range search failed: {valid_range_data}'),
                )
                return False

            # Test 2: Search with future start_date - should NOT find entry
            future_start_result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': date_filter_thread,
                    'start_date': future_date,
                },
            )
            future_start_data = self._extract_content(future_start_result)
            if not future_start_data.get('success') or len(future_start_data.get('results', [])) != 0:
                self.test_results.append(
                    (test_name, False, f'Future start_date returned results unexpectedly: {future_start_data}'),
                )
                return False

            # Test 3: Search with past end_date - should NOT find entry
            past_end_result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': date_filter_thread,
                    'end_date': past_date,
                },
            )
            past_end_data = self._extract_content(past_end_result)
            if not past_end_data.get('success') or len(past_end_data.get('results', [])) != 0:
                self.test_results.append(
                    (test_name, False, f'Past end_date returned results unexpectedly: {past_end_data}'),
                )
                return False

            # Test 4: Search with date-only end_date for today - should find entry
            # This verifies the UX fix where date-only end_date is expanded to end-of-day
            today_end_result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': date_filter_thread,
                    'end_date': today,
                },
            )
            today_end_data = self._extract_content(today_end_result)
            if not today_end_data.get('success') or len(today_end_data.get('results', [])) != 1:
                self.test_results.append(
                    (test_name, False, f'Date-only end_date failed to find today entry: {today_end_data}'),
                )
                return False

            # Test 5: Combined filters (date + source)
            combined_result = await self.client.call_tool(
                'search_context',
                {
                    'thread_id': date_filter_thread,
                    'source': 'user',
                    'start_date': yesterday,
                    'end_date': tomorrow,
                },
            )
            combined_data = self._extract_content(combined_result)
            if not combined_data.get('success') or len(combined_data.get('results', [])) != 1:
                self.test_results.append(
                    (test_name, False, f'Combined date+source filter failed: {combined_data}'),
                )
                return False

            self.test_results.append((test_name, True, 'All date filtering tests passed'))
            return True

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_semantic_search_context_with_date_filtering(self) -> bool:
        """Test semantic_search_context with date filtering parameters.

        Returns:
            bool: True if test passed or skipped gracefully.
        """
        test_name = 'semantic_search_date_filtering'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Check if semantic search is enabled via get_statistics
            stats = await self.client.call_tool('get_statistics', {})
            stats_data = self._extract_content(stats)

            semantic_info = stats_data.get('semantic_search', {})
            is_enabled = semantic_info.get('enabled', False)
            is_available = semantic_info.get('available', False)

            # Skip gracefully if not enabled or available
            if not is_enabled or not is_available:
                self.test_results.append(
                    (test_name, True, f'Skipped (enabled={is_enabled}, available={is_available})'),
                )
                return True

            # Create a separate thread for semantic search date filtering tests
            semantic_date_thread = f'{self.test_thread_id}_semantic_date'

            # Store semantically meaningful test content
            test_contexts = [
                'Machine learning algorithms process data to make predictions',
                'Database indexing improves query performance significantly',
            ]

            for text in test_contexts:
                result = await self.client.call_tool(
                    'store_context',
                    {
                        'thread_id': semantic_date_thread,
                        'source': 'agent',
                        'text': text,
                    },
                )
                result_data = self._extract_content(result)
                if not result_data.get('success'):
                    self.test_results.append((test_name, False, f'Failed to store test context: {result_data}'))
                    return False

            # Allow time for embedding generation
            import asyncio

            await asyncio.sleep(0.5)

            # Get date information for filtering
            from datetime import UTC
            from datetime import datetime
            from datetime import timedelta

            today = datetime.now(UTC).strftime('%Y-%m-%d')
            tomorrow = (datetime.now(UTC) + timedelta(days=1)).strftime('%Y-%m-%d')
            future_date = (datetime.now(UTC) + timedelta(days=30)).strftime('%Y-%m-%d')
            past_date = (datetime.now(UTC) - timedelta(days=30)).strftime('%Y-%m-%d')

            # Test 1: Semantic search with valid date range - should find results
            valid_range_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'machine learning artificial intelligence',
                    'thread_id': semantic_date_thread,
                    'start_date': today,
                    'end_date': tomorrow,
                    'top_k': 5,
                },
            )
            valid_range_data = self._extract_content(valid_range_result)
            if 'results' not in valid_range_data or len(valid_range_data.get('results', [])) == 0:
                self.test_results.append(
                    (test_name, False, f'Valid date range semantic search failed: {valid_range_data}'),
                )
                return False

            # Test 2: Semantic search with future start_date - should return empty
            future_start_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'machine learning',
                    'thread_id': semantic_date_thread,
                    'start_date': future_date,
                    'top_k': 5,
                },
            )
            future_start_data = self._extract_content(future_start_result)
            if 'results' not in future_start_data or len(future_start_data.get('results', [])) != 0:
                self.test_results.append(
                    (test_name, False, f'Future start_date returned results unexpectedly: {future_start_data}'),
                )
                return False

            # Test 3: Semantic search with past end_date - should return empty
            past_end_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'database indexing',
                    'thread_id': semantic_date_thread,
                    'end_date': past_date,
                    'top_k': 5,
                },
            )
            past_end_data = self._extract_content(past_end_result)
            if 'results' not in past_end_data or len(past_end_data.get('results', [])) != 0:
                self.test_results.append(
                    (test_name, False, f'Past end_date returned results unexpectedly: {past_end_data}'),
                )
                return False

            # Test 4: Combined filters (date + source)
            combined_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'algorithms data processing',
                    'thread_id': semantic_date_thread,
                    'source': 'agent',
                    'start_date': today,
                    'end_date': tomorrow,
                    'top_k': 5,
                },
            )
            combined_data = self._extract_content(combined_result)
            if 'results' not in combined_data or len(combined_data.get('results', [])) == 0:
                self.test_results.append(
                    (test_name, False, f'Combined date+source filter failed: {combined_data}'),
                )
                return False

            self.test_results.append((test_name, True, 'All semantic search date filtering tests passed'))
            return True

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def test_semantic_search_context(self) -> bool:
        """Test semantic search functionality (conditional on availability).

        Returns:
            bool: True if test passed or skipped gracefully.
        """
        test_name = 'semantic_search_context'
        assert self.client is not None  # Type guard for Pyright
        try:
            # Check if semantic search is enabled via get_statistics
            stats = await self.client.call_tool('get_statistics', {})
            stats_data = self._extract_content(stats)

            semantic_info = stats_data.get('semantic_search', {})
            is_enabled = semantic_info.get('enabled', False)
            is_available = semantic_info.get('available', False)

            # Skip gracefully if not enabled or available
            if not is_enabled or not is_available:
                self.test_results.append(
                    (test_name, True, f'Skipped (enabled={is_enabled}, available={is_available})'),
                )
                return True

            # Create a separate thread for semantic search tests
            semantic_thread = f'{self.test_thread_id}_semantic'

            # Store semantically diverse test contexts
            test_contexts = [
                'Machine learning models require large datasets for training and validation',
                'Python is a popular programming language for data science and AI applications',
                'The weather today is sunny with a high of 25 degrees celsius',
            ]

            for text in test_contexts:
                result = await self.client.call_tool(
                    'store_context',
                    {
                        'thread_id': semantic_thread,
                        'source': 'agent',
                        'text': text,
                    },
                )
                result_data = self._extract_content(result)
                if not result_data.get('success'):
                    self.test_results.append((test_name, False, f'Failed to store test context: {result_data}'))
                    return False

            # Allow time for embedding generation (non-blocking operation)
            await asyncio.sleep(0.5)

            # Test 1: Semantic search for ML-related content
            ml_search_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'artificial intelligence and deep learning',
                    'top_k': 5,
                },
            )

            ml_search_data = self._extract_content(ml_search_result)

            # semantic_search_context returns results directly without 'success' field
            # Check for 'results' key instead
            if 'results' not in ml_search_data:
                self.test_results.append((test_name, False, f'ML semantic search failed: {ml_search_data}'))
                return False

            # Verify results contain distance/similarity scores
            ml_results = ml_search_data.get('results', [])
            if not ml_results or 'distance' not in ml_results[0]:
                self.test_results.append((test_name, False, 'Missing distance scores in results'))
                return False

            # Test 2: Search with thread_id filter
            thread_search_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'programming languages',
                    'thread_id': semantic_thread,
                    'top_k': 3,
                },
            )

            thread_search_data = self._extract_content(thread_search_result)

            if 'results' not in thread_search_data:
                self.test_results.append((test_name, False, f'Thread-filtered search failed: {thread_search_data}'))
                return False

            # Test 3: Search with source filter
            source_search_result = await self.client.call_tool(
                'semantic_search_context',
                {
                    'query': 'data science',
                    'source': 'agent',
                    'top_k': 5,
                },
            )

            source_search_data = self._extract_content(source_search_result)

            if 'results' not in source_search_data:
                self.test_results.append((test_name, False, f'Source-filtered search failed: {source_search_data}'))
                return False

            # Get model name for success message
            model_name = semantic_info.get('model', 'unknown')

            self.test_results.append((test_name, True, f'Semantic search working (model: {model_name})'))
            return True

        except Exception as e:
            self.test_results.append((test_name, False, f'Exception: {e}'))
            return False

    async def cleanup(self) -> None:
        """Clean up server and resources."""
        try:
            # Disconnect client (this also stops the server subprocess)
            if self.client:
                await self.client.__aexit__(None, None, None)
                print('[OK] Client disconnected and server stopped')

            # Restore original environment variables
            for key, value in self.original_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

            # Clean up temporary database file if it exists
            if self.temp_db_path and self.temp_db_path.exists():
                try:
                    # Remove WAL and SHM files if they exist
                    wal_file = Path(str(self.temp_db_path) + '-wal')
                    shm_file = Path(str(self.temp_db_path) + '-shm')
                    if wal_file.exists():
                        wal_file.unlink()
                    if shm_file.exists():
                        shm_file.unlink()
                    # Remove main database file
                    self.temp_db_path.unlink()
                    print(f'[OK] Temporary database cleaned up: {self.temp_db_path}')
                except Exception as cleanup_err:
                    print(f'[WARNING] Could not clean up temp database: {cleanup_err}')

        except Exception as e:
            print(f'[WARNING] Cleanup error: {e}')

    async def run_all_tests(self) -> bool:
        """Run all tests and report results.

        Returns:
            bool: True if all tests passed.
        """
        print('\n' + '=' * 50)
        print('MCP SERVER INTEGRATION TEST')
        print('=' * 50)

        # Start server
        if not await self.start_server():
            print('[ERROR] Failed to start server')
            await self.cleanup()
            return False

        # Connect client
        if not await self.connect_client():
            print('[ERROR] Failed to connect client')
            await self.cleanup()
            return False

        # Run all tests
        tests = [
            ('Store Context', self.test_store_context),
            ('Search Context', self.test_search_context),
            ('Search Context Date Filtering', self.test_search_context_with_date_filtering),
            ('Metadata Filtering', self.test_metadata_filtering),
            ('Get Context by IDs', self.test_get_context_by_ids),
            ('Delete Context', self.test_delete_context),
            ('Update Context', self.test_update_context),
            ('Metadata Patch Deep Merge', self.test_metadata_patch_deep_merge),
            ('List Threads', self.test_list_threads),
            ('Get Statistics', self.test_get_statistics),
            ('Semantic Search', self.test_semantic_search_context),
            ('Semantic Search Date Filtering', self.test_semantic_search_context_with_date_filtering),
        ]

        print('\nRunning tests...\n')

        for test_name, test_func in tests:
            print(f'Testing: {test_name}...')
            try:
                success = await test_func()
                if success:
                    print(f'  [OK] {test_name} passed')
                else:
                    print(f'  [FAIL] {test_name} failed')
            except Exception as e:
                print(f'  [ERROR] {test_name} error: {e}')
                self.test_results.append((test_name, False, f'Exception: {e}'))

        # Display results
        print('\n' + '=' * 50)
        print('TEST RESULTS')
        print('=' * 50)

        passed = 0
        failed = 0

        for test_name, result, details in self.test_results:
            status = '[PASS]' if result else '[FAIL]'
            print(f'{status}: {test_name}')
            if details:
                print(f'   Details: {details}')
            if result:
                passed += 1
            else:
                failed += 1

        total = passed + failed
        print(f'\nTotal: {passed}/{total} tests passed')

        # Cleanup
        await self.cleanup()

        return failed == 0


# Pytest integration
@pytest.mark.integration
@pytest.mark.asyncio
async def test_real_server(tmp_path: Path) -> None:
    """Run integration tests against real server with temporary database.

    Args:
        tmp_path: Pytest fixture providing temporary directory.

    Raises:
        RuntimeError: If MCP_TEST_MODE is not set or if attempting to use default database.
    """
    # Verify we're in test mode from the global fixture
    if not os.environ.get('MCP_TEST_MODE'):
        raise RuntimeError(
            'MCP_TEST_MODE not set! Global test fixture may have failed.\n'
            'This could lead to pollution of the default database!',
        )

    # Create a unique database path in the temp directory
    temp_db = tmp_path / 'test_real_server.db'

    # Double-check we're not using the default database
    default_db = Path.home() / '.mcp' / 'context_storage.db'
    if temp_db.resolve() == default_db.resolve():
        raise RuntimeError(
            f'Test attempting to use default database!\nDefault: {default_db}\nTest DB: {temp_db}',
        )

    print(f'[TEST] Running with temp database: {temp_db}')
    print(f"[TEST] MCP_TEST_MODE: {os.environ.get('MCP_TEST_MODE')}")

    test = MCPServerIntegrationTest(temp_db_path=temp_db)
    success = await test.run_all_tests()
    assert success, 'Integration tests failed'


if __name__ == '__main__':
    # Allow running directly
    async def main() -> None:
        # Set test mode when running directly
        os.environ['MCP_TEST_MODE'] = '1'

        # Create a temporary directory for the database when running directly
        with tempfile.TemporaryDirectory(prefix='mcp_test_direct_') as tmpdir:
            temp_db_path = Path(tmpdir) / 'test_direct.db'

            # Set DB_PATH for the subprocess
            os.environ['DB_PATH'] = str(temp_db_path)

            print('[INFO] Running directly with test mode enabled')
            print(f'[INFO] Using temporary directory: {tmpdir}')
            print(f'[INFO] DB_PATH set to: {temp_db_path}')
            print(f"[INFO] MCP_TEST_MODE: {os.environ.get('MCP_TEST_MODE')}")

            test = MCPServerIntegrationTest(temp_db_path=temp_db_path)
            success = await test.run_all_tests()
            sys.exit(0 if success else 1)

    asyncio.run(main())
