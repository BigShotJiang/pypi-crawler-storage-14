The action in this module takes a function on a two-dimensional grid as input and computes a fourier transform upon the input function using [FFTW](https://www.fftw.org).
Currently, this actions performs a complex fourier transition even if the input data is real.  The functionality here was developed and used in the paper cited
below.
