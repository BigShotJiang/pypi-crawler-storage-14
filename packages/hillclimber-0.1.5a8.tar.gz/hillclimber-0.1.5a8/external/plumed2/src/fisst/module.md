This FISST module contains methods for adaptively determining weight parameters to construct a bias function that represents the Infinite Switch limit of Simulated Tempering for a linear bias coefficient of a CV, as described in the paper cited below.

Currently, all features of the FISST module are included in a single FISST bias function.
