"""
Tests for Fat Kernel v0.9.0 Components
======================================

Tests for the new centralized infrastructure components:
- Context Management (set_kernel, get_kernel, clear_kernel)
- Stream Driver (ParquetStreamDriver)
- Compute Driver (LocalComputeDriver)
- Transaction Management (UnitOfWork)
- Process State (SysProcess)
"""

import asyncio
import json
import os
import shutil
import tempfile
from datetime import UTC, datetime

import pytest
from pydantic import Field
from registro import DomainResource, register

from malha import (
    # Context Management
    connect,
    get_kernel,
    set_kernel,
    clear_kernel,
    # Stream Driver
    ParquetStreamDriver,
    # Compute Driver
    LocalComputeDriver,
    ComputeResult,
    RuntimeExecutionError,
    # Transaction Management
    UnitOfWork,
    Savepoint,
    # Process State
    SysProcess,
    ProcessStatus,
    # Core
    UnifiedDataManager,
    AsyncSQLAlchemyDriver,
    KuzuActor,
    DuckDBDriver,
    Interceptor,
)


# ==============================================================================
# Test Domain Resources
# ==============================================================================
# Note: Prefixed with "Sample" to avoid pytest collection warnings
# (pytest tries to collect classes starting with "Test" as test classes)

class SampleUser(DomainResource):
    """Sample user for Fat Kernel tests."""
    name: str = Field(..., min_length=1)
    email: str = Field(default="test@example.com")


class SampleOrder(DomainResource):
    """Sample order for Fat Kernel tests."""
    total: float = Field(..., gt=0)
    status: str = Field(default="pending")


# ==============================================================================
# Test Interceptors
# ============================================================================== 

class ReadFilterInterceptor(Interceptor):
    """Simple interceptor that hides specific RIDs on read."""

    def __init__(self, denied_rid: str):
        self.denied_rid = denied_rid

    async def on_write(self, obj, agent=None) -> None:  # pragma: no cover - not used in tests
        return None

    async def on_read(self, obj, agent=None):
        if obj.rid == self.denied_rid:
            return None
        return obj


# Register test resources
try:
    register("SampleUser", SampleUser)
    register("SampleOrder", SampleOrder)
except Exception:
    pass  # Already registered


# ==============================================================================
# Fixtures
# ==============================================================================

@pytest.fixture
async def temp_dir():
    """Create a temporary directory for tests."""
    temp_path = tempfile.mkdtemp()
    yield temp_path
    shutil.rmtree(temp_path, ignore_errors=True)


@pytest.fixture
async def kernel(temp_dir):
    """Create a test kernel with all drivers."""
    db_path = os.path.join(temp_dir, "test.db")
    graph_path = os.path.join(temp_dir, "test_graph")
    
    sql = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db_path}")
    await sql.create_tables()
    
    graph = KuzuActor(graph_path)
    analytics = DuckDBDriver(db_path)
    
    manager = UnifiedDataManager(
        sql_driver=sql,
        graph_driver=graph,
        analytics_driver=analytics,
        enable_monitoring=False,
        node_id="test-node",
    )
    
    # Set in global context
    set_kernel(manager)
    
    yield manager
    
    await manager.close()
    clear_kernel()


# ==============================================================================
# Tests: Context Management
# ==============================================================================

class TestContextManagement:
    """Tests for centralized context management."""
    
    @pytest.mark.asyncio
    async def test_set_and_get_kernel(self, kernel):
        """Test that set_kernel and get_kernel work correctly."""
        # Kernel was set in fixture
        retrieved = get_kernel()
        assert retrieved is kernel
    
    @pytest.mark.asyncio
    async def test_clear_kernel(self, kernel):
        """Test that clear_kernel removes the kernel from context."""
        # Kernel is set
        assert get_kernel() is kernel
        
        # Clear it
        clear_kernel()
        
        # Now get_kernel should raise
        with pytest.raises(RuntimeError, match="No kernel available"):
            get_kernel()
        
        # Restore for cleanup
        set_kernel(kernel)
    
    @pytest.mark.asyncio
    async def test_get_kernel_without_set_raises(self):
        """Test that get_kernel raises when no kernel is set."""
        # Clear any existing kernel
        clear_kernel()
        
        with pytest.raises(RuntimeError, match="No kernel available"):
            get_kernel()
    
    @pytest.mark.asyncio
    async def test_connect_sets_kernel(self, temp_dir):
        """Test that connect() automatically sets the kernel in context."""
        db_path = os.path.join(temp_dir, "connect_test.db")
        graph_path = os.path.join(temp_dir, "connect_graph")
        
        # Clear any existing kernel
        clear_kernel()
        
        # Connect should set the kernel
        kernel = await connect(
            url=f"sqlite+aiosqlite:///{db_path}",
            kuzu_path=graph_path,
            enable_monitoring=False,
        )
        
        try:
            # get_kernel should return the same instance
            assert get_kernel() is kernel
        finally:
            await kernel.close()
            clear_kernel()


# ==============================================================================
# Tests: Stream Driver
# ==============================================================================

class TestParquetStreamDriver:
    """Tests for ParquetStreamDriver."""
    
    @pytest.mark.asyncio
    async def test_write_single_record(self, temp_dir):
        """Test writing a single record."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=100,
        )
        
        await stream.write({
            "sensor_id": "s1",
            "value": 42.5,
            "timestamp": datetime.now(UTC).isoformat(),
        })
        
        # Record should be in buffer
        assert len(stream._buffer) == 1
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_write_batch(self, temp_dir):
        """Test writing multiple records."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=100,
        )
        
        records = [
            {"sensor_id": f"s{i}", "value": float(i)} 
            for i in range(10)
        ]
        
        await stream.write_batch(records)
        
        assert len(stream._buffer) == 10
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_auto_flush_on_limit(self, temp_dir):
        """Test that buffer auto-flushes when limit is reached."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=5,  # Low limit for testing
        )
        
        # Write 6 records (should trigger flush at 5)
        for i in range(6):
            await stream.write({"id": i, "value": float(i)})
        
        # Buffer should have 1 record (6 - 5 flushed)
        assert len(stream._buffer) == 1
        assert stream._total_written == 5
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_partition_column_extraction(self, temp_dir):
        """Test that partition columns are extracted from timestamp."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            partition_cols=["year", "month", "day"],
        )
        
        await stream.write({
            "sensor_id": "s1",
            "timestamp": "2024-06-15T10:30:00Z",
        })
        
        # Check that partition columns were added
        record = stream._buffer[0]
        assert record["year"] == 2024
        assert record["month"] == 6
        assert record["day"] == 15
        
        await stream.close()
    
    @pytest.mark.asyncio
    async def test_get_stats(self, temp_dir):
        """Test get_stats method."""
        stream = ParquetStreamDriver(
            base_path=os.path.join(temp_dir, "stream_data"),
            buffer_limit=100,
        )
        
        await stream.write({"id": 1})
        await stream.write({"id": 2})
        
        stats = stream.get_stats()
        
        assert stats["buffer_size"] == 2
        assert stats["total_written"] == 0
        assert "stream_data" in stats["base_path"]
        
        await stream.close()


# ==============================================================================
# Tests: Compute Driver
# ==============================================================================

class TestLocalComputeDriver:
    """Tests for LocalComputeDriver."""
    
    @pytest.mark.asyncio
    async def test_validate_safe_code(self, temp_dir):
        """Test that safe code passes validation."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        safe_code = '''
x = 1 + 2
print(x)
'''
        errors = compute.validate(safe_code)
        assert errors == []
    
    @pytest.mark.asyncio
    async def test_validate_forbidden_import(self, temp_dir):
        """Test that forbidden imports are detected."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        unsafe_code = '''
import os
os.system("ls")
'''
        errors = compute.validate(unsafe_code)
        assert any("os" in e for e in errors)
    
    @pytest.mark.asyncio
    async def test_validate_forbidden_pattern(self, temp_dir):
        """Test that forbidden patterns are detected."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        unsafe_code = '''
eval("1 + 2")
'''
        errors = compute.validate(unsafe_code)
        assert any("eval" in e for e in errors)
    
    @pytest.mark.asyncio
    async def test_validate_syntax_error(self, temp_dir):
        """Test that syntax errors are detected."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        bad_code = '''
def broken(
    print("missing paren")
'''
        errors = compute.validate(bad_code)
        assert any("Syntax error" in e for e in errors)
    
    @pytest.mark.asyncio
    async def test_execute_returns_result(self, temp_dir):
        """Test that execute returns a ComputeResult."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        result = await compute.execute('print("hello")')
        
        assert isinstance(result, ComputeResult)
        assert result.execution_time_ms > 0
    
    @pytest.mark.asyncio
    async def test_execute_validation_failure(self, temp_dir):
        """Test that validation failures return error result."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        result = await compute.execute('import os; os.system("ls")')
        
        assert result.success is False
        assert "Validation failed" in result.error
    
    @pytest.mark.asyncio
    async def test_pep723_header_generation(self, temp_dir):
        """Test PEP 723 header generation."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        code = 'print("hello")'
        deps = ["httpx", "pandas>=2.0"]
        
        result = compute._to_pep723(code, deps)
        
        assert "# /// script" in result
        assert "requires-python" in result
        assert '"httpx"' in result
        assert '"pandas>=2.0"' in result
        assert 'print("hello")' in result
    
    @pytest.mark.asyncio
    async def test_run_script_raises_on_error(self, temp_dir):
        """Test that run_script raises RuntimeExecutionError on failure."""
        compute = LocalComputeDriver(work_dir=temp_dir)
        
        with pytest.raises(RuntimeExecutionError):
            await compute.run_script('import subprocess')


# ==============================================================================
# Tests: Unit of Work
# ==============================================================================

class TestUnitOfWork:
    """Tests for UnitOfWork transaction management."""
    
    @pytest.mark.asyncio
    async def test_add_objects(self, kernel):
        """Test adding objects to unit of work."""
        async with UnitOfWork(kernel) as uow:
            user = SampleUser(name="Alice")
            order = SampleOrder(total=100.0)
            
            uow.add(user)
            uow.add(order)
            
            assert uow.pending_objects == 2
            assert uow.pending_links == 0
    
    @pytest.mark.asyncio
    async def test_add_links(self, kernel):
        """Test adding links to unit of work."""
        async with UnitOfWork(kernel) as uow:
            user = SampleUser(name="Bob")
            order = SampleOrder(total=50.0)
            
            uow.add(user)
            uow.add(order)
            uow.link(user, "PLACED", order)
            
            assert uow.pending_links == 1
    
    @pytest.mark.asyncio
    async def test_commit_persists_objects(self, kernel):
        """Test that commit persists all objects."""
        user = SampleUser(name="Charlie")
        order = SampleOrder(total=75.0)
        
        async with UnitOfWork(kernel) as uow:
            uow.add(user)
            uow.add(order)
            
            saved = await uow.commit()
            
            assert len(saved) == 2
            assert saved[0].rid is not None
            assert saved[1].rid is not None
    
    @pytest.mark.asyncio
    async def test_clear_removes_pending(self, kernel):
        """Test that clear removes pending objects and links."""
        async with UnitOfWork(kernel) as uow:
            uow.add(SampleUser(name="Dave"))
            uow.link(SampleUser(name="A"), "KNOWS", SampleUser(name="B"))
            
            assert uow.pending_objects == 1
            assert uow.pending_links == 1
            
            uow.clear()
            
            assert uow.pending_objects == 0
            assert uow.pending_links == 0
    
    @pytest.mark.asyncio
    async def test_context_manager_rollback_on_error(self, kernel):
        """Test that context manager clears on exception."""
        uow = UnitOfWork(kernel)
        
        try:
            async with uow:
                uow.add(SampleUser(name="Eve"))
                raise ValueError("Test error")
        except ValueError:
            pass
        
        # Should have been cleared
        assert uow.pending_objects == 0
    
    @pytest.mark.asyncio
    async def test_uses_context_kernel(self, kernel):
        """Test that UnitOfWork uses kernel from context if not provided."""
        # kernel fixture sets the context
        async with UnitOfWork() as uow:  # No kernel argument
            user = SampleUser(name="Frank")
            uow.add(user)
            
            # Should use kernel from context
            saved = await uow.commit()
            assert len(saved) == 1


# ==============================================================================
# Tests: Process State
# ==============================================================================

class TestSysProcess:
    """Tests for SysProcess model."""
    
    def test_create_process(self):
        """Test creating a SysProcess instance."""
        process = SysProcess(
            process_type="workflow",
            process_name="TestWorkflow",
            status=ProcessStatus.PENDING.value,
            node_id="test-node",
        )
        
        assert process.process_type == "workflow"
        assert process.process_name == "TestWorkflow"
        assert process.status == "PENDING"
    
    def test_process_status_enum(self):
        """Test ProcessStatus enum values."""
        assert ProcessStatus.PENDING.value == "PENDING"
        assert ProcessStatus.RUNNING.value == "RUNNING"
        assert ProcessStatus.COMPLETED.value == "COMPLETED"
        assert ProcessStatus.FAILED.value == "FAILED"
        assert ProcessStatus.COMPENSATING.value == "COMPENSATING"
        assert ProcessStatus.COMPENSATED.value == "COMPENSATED"
        assert ProcessStatus.DEAD_LETTER.value == "DEAD_LETTER"
    
    def test_process_with_state_payload(self):
        """Test SysProcess with JSON state payload."""
        state = {"step": 2, "order_id": "123", "items": ["a", "b"]}
        
        process = SysProcess(
            process_type="saga",
            process_name="OrderSaga",
            status=ProcessStatus.RUNNING.value,
            state_payload=json.dumps(state),
        )
        
        # Deserialize and verify
        loaded_state = json.loads(process.state_payload)
        assert loaded_state["step"] == 2
        assert loaded_state["order_id"] == "123"
    
    def test_process_defaults(self):
        """Test SysProcess default values."""
        process = SysProcess(
            process_type="job",
            process_name="TestJob",
        )
        
        assert process.status == ProcessStatus.PENDING.value
        assert process.retries == 0
        assert process.node_id == "local"
        assert process.parent_id is None


# ==============================================================================
# Integration Tests
# ==============================================================================

class TestFatKernelIntegration:
    """Integration tests for Fat Kernel components working together."""
    
    @pytest.mark.asyncio
    async def test_full_workflow(self, kernel):
        """Test a complete workflow using all Fat Kernel components."""
        # 1. Use UnitOfWork to create related objects
        user = SampleUser(name="Integration Test User")
        order1 = SampleOrder(total=100.0)
        order2 = SampleOrder(total=200.0)
        
        async with UnitOfWork(kernel) as uow:
            uow.add(user)
            uow.add(order1)
            uow.add(order2)
            uow.link(user, "PLACED", order1)
            uow.link(user, "PLACED", order2)
            
            saved = await uow.commit()
        
        assert len(saved) == 3
        
        # 2. Verify objects were persisted
        retrieved_user = await kernel.get(SampleUser, saved[0].rid)
        assert retrieved_user is not None
        assert retrieved_user.name == "Integration Test User"


class TestBatchRetrieval:
    """Tests for UnifiedDataManager.mget batch retrieval."""

    @pytest.mark.asyncio
    async def test_mget_returns_multiple_resources(self, kernel):
        user_a = SampleUser(name="Batch User A")
        user_b = SampleUser(name="Batch User B")

        saved_a = await kernel.save_versioned(user_a)
        saved_b = await kernel.save_versioned(user_b)

        rids = [saved_a.rid, saved_b.rid]
        results = await kernel.mget(SampleUser, rids)

        assert len(results) == 2
        assert {r.rid for r in results} == set(rids)

    @pytest.mark.asyncio
    async def test_mget_applies_interceptors(self, kernel):
        user_allowed = SampleUser(name="Visible User")
        user_hidden = SampleUser(name="Hidden User")

        saved_allowed = await kernel.save_versioned(user_allowed)
        saved_hidden = await kernel.save_versioned(user_hidden)

        interceptor = ReadFilterInterceptor(denied_rid=saved_hidden.rid)
        kernel.add_interceptor(interceptor)

        try:
            results = await kernel.mget(SampleUser, [saved_allowed.rid, saved_hidden.rid])
            assert len(results) == 1
            assert results[0].rid == saved_allowed.rid
        finally:
            kernel._interceptors.remove(interceptor)

    
    @pytest.mark.asyncio
    async def test_context_isolation(self, temp_dir):
        """Test that context is properly isolated."""
        # Create two separate kernels
        db1 = os.path.join(temp_dir, "db1.db")
        db2 = os.path.join(temp_dir, "db2.db")
        graph1 = os.path.join(temp_dir, "graph1")
        graph2 = os.path.join(temp_dir, "graph2")
        
        kernel1 = await connect(
            url=f"sqlite+aiosqlite:///{db1}",
            kuzu_path=graph1,
            enable_monitoring=False,
        )
        
        # get_kernel should return kernel1
        assert get_kernel() is kernel1
        
        # Set kernel2
        sql2 = AsyncSQLAlchemyDriver(f"sqlite+aiosqlite:///{db2}")
        await sql2.create_tables()
        graph2_driver = KuzuActor(graph2)
        analytics2 = DuckDBDriver(db2)
        
        kernel2 = UnifiedDataManager(
            sql_driver=sql2,
            graph_driver=graph2_driver,
            analytics_driver=analytics2,
            enable_monitoring=False,
        )
        
        set_kernel(kernel2)
        
        # Now get_kernel should return kernel2
        assert get_kernel() is kernel2
        
        # Cleanup
        await kernel1.close()
        await kernel2.close()
        clear_kernel()


# ==============================================================================
# Tests: Alembic Migrations
# ==============================================================================

class TestAlembicDriver:
    """Tests for embedded Alembic migrations."""

    @pytest.mark.asyncio
    async def test_alembic_driver_init(self, kernel, temp_dir):
        """Test AlembicDriver initialization."""
        from malha.drivers.alembic import AlembicDriver
        
        migrations_path = os.path.join(temp_dir, "migrations")
        driver = AlembicDriver(kernel, migrations_path=migrations_path)
        
        # Should not be initialized yet
        assert not driver.is_initialized
        
        # Initialize
        result = await driver.init()
        assert result.success
        assert result.operation == "init"
        
        # Now should be initialized
        assert driver.is_initialized
        assert os.path.exists(os.path.join(migrations_path, "env.py"))
        assert os.path.exists(os.path.join(migrations_path, "versions"))

    @pytest.mark.asyncio
    async def test_alembic_driver_current_revision(self, kernel, temp_dir):
        """Test getting current revision."""
        from malha.drivers.alembic import AlembicDriver
        
        migrations_path = os.path.join(temp_dir, "migrations")
        driver = AlembicDriver(kernel, migrations_path=migrations_path)
        
        # Initialize
        await driver.init()
        
        # No migrations applied yet
        current = await driver.current()
        assert current is None

    @pytest.mark.asyncio
    async def test_migrator_alembic_integration(self, kernel, temp_dir):
        """Test Migrator's AlembicDriver integration."""
        from malha.maintenance import Migrator
        
        migrations_path = os.path.join(temp_dir, "migrations")
        migrator = Migrator(kernel, migrations_path=migrations_path)
        
        # Initialize via migrator
        result = await migrator.init_alembic()
        assert result.success
        
        # Check alembic property works
        assert migrator.alembic is not None
        assert migrator.alembic.is_initialized


# ==============================================================================
# RFC-001: RUNTIME COGNITIVO TRANSACIONAL TESTS
# ==============================================================================

class TestRFC001SysProcessEnhancements:
    """Tests for SysProcess enhancements (Tarefa A)."""
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_idempotency_key(self, kernel):
        """Test that SysProcess has idempotency_key field."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
            idempotency_key="test-key-123",
        )
        assert process.idempotency_key == "test-key-123"
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_lock_version(self, kernel):
        """Test that SysProcess has lock_version for optimistic locking."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
        )
        assert process.lock_version == 0
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_result_payload(self, kernel):
        """Test that SysProcess has result_payload field."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
            result_payload='{"answer": 42}',
        )
        assert process.result_payload == '{"answer": 42}'
    
    @pytest.mark.asyncio
    async def test_sysprocess_has_timestamps(self, kernel):
        """Test that SysProcess has created_at and updated_at."""
        process = SysProcess(
            process_type="agent",
            process_name="TestAgent",
        )
        assert process.created_at is not None
        assert process.updated_at is not None
    
    @pytest.mark.asyncio
    async def test_process_status_suspended(self):
        """Test SUSPENDED status exists."""
        assert ProcessStatus.SUSPENDED.value == "SUSPENDED"
    
    @pytest.mark.asyncio
    async def test_process_status_recovering(self):
        """Test RECOVERING status exists."""
        assert ProcessStatus.RECOVERING.value == "RECOVERING"


class TestRFC001Savepoints:
    """Tests for UnitOfWork Savepoints (Tarefa B)."""
    
    @pytest.mark.asyncio
    async def test_savepoint_rollback_on_error(self, kernel):
        """Test that savepoint rolls back only its changes on error."""
        uow = UnitOfWork(kernel)
        
        # Add first object
        user1 = SampleUser(name="User1")
        uow.add(user1)
        assert uow.pending_objects == 1
        
        # Add second object in savepoint that will fail
        async with uow.savepoint():
            user2 = SampleUser(name="User2")
            uow.add(user2)
            assert uow.pending_objects == 2
            raise ValueError("Simulated tool failure")
        
        # After savepoint rollback, only user1 should remain
        assert uow.pending_objects == 1
    
    @pytest.mark.asyncio
    async def test_savepoint_success_keeps_changes(self, kernel):
        """Test that successful savepoint keeps its changes."""
        uow = UnitOfWork(kernel)
        
        user1 = SampleUser(name="User1")
        uow.add(user1)
        
        async with uow.savepoint():
            user2 = SampleUser(name="User2")
            uow.add(user2)
            # No exception - changes are kept
        
        assert uow.pending_objects == 2
    
    @pytest.mark.asyncio
    async def test_nested_savepoints(self, kernel):
        """Test nested savepoints work correctly."""
        uow = UnitOfWork(kernel)
        
        uow.add(SampleUser(name="Level0"))  # Base
        
        async with uow.savepoint():
            uow.add(SampleUser(name="Level1"))
            
            async with uow.savepoint():
                uow.add(SampleUser(name="Level2"))
                raise ValueError("Inner failure")
            
            # Inner rolled back, but level 1 still there
            assert uow.pending_objects == 2
        
        # All kept after outer succeeds
        assert uow.pending_objects == 2
    
    @pytest.mark.asyncio
    async def test_uow_rollback_method(self, kernel):
        """Test explicit rollback method."""
        uow = UnitOfWork(kernel)
        
        uow.add(SampleUser(name="Test"))
        assert uow.pending_objects == 1
        
        await uow.rollback()
        assert uow.pending_objects == 0
    
    @pytest.mark.asyncio
    async def test_uow_is_committed_property(self, kernel):
        """Test is_committed property."""
        uow = UnitOfWork(kernel)
        assert uow.is_committed is False


class TestRFC001ProcessLocking:
    """Tests for Process Locking (Tarefa C)."""
    
    @pytest.mark.asyncio
    async def test_get_or_create_process_creates_new(self, kernel):
        """Test get_or_create_process creates new process."""
        process, created = await kernel.get_or_create_process(
            idempotency_key="unique-key-001",
            process_type="agent",
            process_name="TestAgent",
        )
        
        assert created is True
        assert process.idempotency_key == "unique-key-001"
        assert process.status == ProcessStatus.PENDING.value
    
    @pytest.mark.asyncio
    async def test_get_or_create_process_returns_existing(self, kernel):
        """Test get_or_create_process returns existing process."""
        # Create first
        process1, created1 = await kernel.get_or_create_process(
            idempotency_key="duplicate-key-001",
            process_type="agent",
            process_name="Agent1",
        )
        assert created1 is True
        
        # Try to create with same key
        process2, created2 = await kernel.get_or_create_process(
            idempotency_key="duplicate-key-001",
            process_type="agent",
            process_name="Agent2",  # Different name, same key
        )
        
        assert created2 is False
        assert process2.id == process1.id
        assert process2.process_name == "Agent1"  # Original name
    
    @pytest.mark.asyncio
    async def test_acquire_and_release_lock(self, kernel):
        """Test acquiring and releasing process lock."""
        # Create a process
        process, _ = await kernel.get_or_create_process(
            idempotency_key="lock-test-001",
            process_type="workflow",
            process_name="LockTest",
        )
        
        # Acquire lock
        locked = await kernel.acquire_process_lock(process.id)
        assert locked is not None
        assert locked.heartbeat is not None
        
        # Release lock
        released = await kernel.release_process_lock(process.id)
        assert released is True
    
    @pytest.mark.asyncio
    async def test_acquire_lock_nonexistent_process(self, kernel):
        """Test acquiring lock on non-existent process returns None."""
        locked = await kernel.acquire_process_lock(99999)
        assert locked is None
    
    @pytest.mark.asyncio
    async def test_update_process_state(self, kernel):
        """Test updating process state."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="update-test-001",
            process_type="agent",
            process_name="UpdateTest",
        )
        
        # Update to RUNNING
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.RUNNING,
            state_payload='{"step": 1}',
        )
        
        assert updated.status == ProcessStatus.RUNNING.value
        assert updated.state_payload == '{"step": 1}'
        assert updated.lock_version == 1  # Incremented
    
    @pytest.mark.asyncio
    async def test_update_process_to_completed(self, kernel):
        """Test updating process to COMPLETED sets completed_at."""
        process, _ = await kernel.get_or_create_process(
            idempotency_key="complete-test-001",
            process_type="agent",
            process_name="CompleteTest",
        )
        
        updated = await kernel.update_process_state(
            process.id,
            status=ProcessStatus.COMPLETED,
            result_payload='{"answer": "success"}',
        )
        
        assert updated.status == ProcessStatus.COMPLETED.value
        assert updated.completed_at is not None
        assert updated.result_payload == '{"answer": "success"}'
