# /// script
# requires-python = ">=3.13"
# dependencies = [
#     "sqlmodel>=0.0.27",
#     "sqlalchemy>=2.0.44",
#     "aiosqlite>=0.21.0",
#     "kuzu>=0.11.3",
#     "duckdb>=1.4.2",
#     "politipo>=0.5.1",
#     "registro>=0.7.0",
#     "pydantic>=2.12.4",
#     "pyarrow>=10.0.0",
#     "asyncpg>=0.30.0",
#     "greenlet>=3.2.4",
#     "ulid-py>=1.1.0"
# ]
# ///

"""
Malha v0.11.0 - "Fat Kernel" 
=============================
Sistema Operacional Semântico - Unified Data & Compute Kernel with Lifecycle Management

This version consolidates infrastructure responsibilities into the kernel:
- Context Management: Thread/async-safe kernel injection
- Stream Drivers: High-performance data lake writes (Parquet)
- Compute Drivers: Safe script execution (PEP 723 + uv)
- Transaction Management: UnitOfWork for atomic graph operations
- Process State: Durable workflow persistence (SysProcess)

Architecture Layers:
┌─────────────────────────────────────────────────────────────┐
│  Application Layer (semantico, kinetic, perception, etc.)   │
├─────────────────────────────────────────────────────────────┤
│  Malha Kernel (THIS FILE)                                   │
│  ├─ Context: set_kernel(), get_kernel(), clear_kernel()     │
│  ├─ SQL Driver: AsyncSQLAlchemyDriver                       │
│  ├─ Graph Driver: KuzuActor                                 │
│  ├─ Analytics Driver: DuckDBDriver                          │
│  ├─ Stream Driver: ParquetStreamDriver (NEW)                │
│  ├─ Compute Driver: LocalComputeDriver (NEW)                │
│  ├─ Transaction: UnitOfWork (NEW)                           │
│  └─ Models: SysOutbox, SysProcess (NEW)                     │
└─────────────────────────────────────────────────────────────┘

Migration Guide (v0.8 → v0.9):
- Import set_kernel/get_kernel/clear_kernel from malha (not semantico)
- Use kernel.stream.write() instead of DataLakeWriter
- Use kernel.compute.execute() instead of EphemeralRuntime
- Use UnitOfWork for atomic multi-object operations

Legacy Compatibility:
- Old APIs remain functional but emit DeprecationWarning
- Remove deprecated code in v1.0.0

Changelog v0.9.0:
- [NEW] KernelContext: Centralized context management
- [NEW] ParquetStreamDriver: High-performance streaming writes
- [NEW] LocalComputeDriver: Safe script execution
- [NEW] UnitOfWork: Atomic transaction management
- [NEW] SysProcess: Workflow state persistence
- [DEPRECATED] External context management (use malha.set_kernel)
- [IMPROVED] Documentation and type hints

Arquitetura:
1.  **Async-Native & Thread-Safe**: I/O não bloqueante com padrão Actor para operações bloqueantes
2.  **Bitemporalidade Estrita (SCD Type 2)**: Histórico imutável com versionamento otimista
3.  **Consistência Dual via Outbox**: Sincronia SQL->Grafo desacoplada e atômica
4.  **Data Physics**: Uso de Politipo para serialização Zero-Copy (Arrow)
5.  **Identidade**: Uso nativo de Registro RIDs
6.  **Padrão Repository**: Separação clara entre lógica de domínio e acesso a dados
7.  **Otimistic Locking**: Controle de concorrência sem bloqueios

Dependências:
- `registro` (v0.5.1+): Identidade e Imutabilidade
- `politipo` (v0.5.1+): DDL Seguro e Tipagem Dialect-Aware
- `sqlmodel`: ORM assíncrono com suporte a Pydantic
- `kuzu`: Grafo de conhecimento
- `duckdb`: Processamento analítico
"""

import abc
import ast
import asyncio
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
import types
import warnings
from collections import defaultdict
from collections.abc import Callable, Sequence
from concurrent.futures import ThreadPoolExecutor
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Generic,
    Protocol,
    Type,
    TypeVar,
)

import duckdb
import kuzu
from pydantic import BaseModel
from sqlalchemy import and_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import Field as SQLField
from sqlmodel import SQLModel

# Type alias for signal handlers
Handler = Callable[[Any], Any]

# --- Fundações (Identity & Data Physics) ---
from politipo import DataType, PolyTransporter, generate_ddl
from registro import (
    DomainResource,  # Objeto Lógico (Pydantic Puro)
)
from registro import (
    Resource as RegistroResource,  # Envelope Físico (Tabela SQL)
)
from registro import (
    registry as global_registry,  # Registry global de classes de domínio
)
from registro.models.rid import RID

from .instrumentation import KernelInstrumentation, metrics
from .monitor import KernelMonitor

# Register RID with Politipo for Zero-Copy Transport
if not hasattr(DataType, "RID"):
    DataType.register("RID", RID, mapping=str)

# --- Configuração de Logging ---
logger = logging.getLogger("malha.kernel")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("[MALHA] %(asctime)s | %(levelname)s | %(message)s"))
    logger.addHandler(handler)

# --- Tipos e Constantes ---
T = TypeVar("T", bound=DomainResource)  # Repositórios trabalham com objetos de domínio

# --- Exceções ---
class OptimisticLockError(Exception):
    """Exceção lançada quando ocorre um conflito de concorrência otimista."""

class ValidationError(Exception):
    """Exceção lançada quando a validação de um recurso falha."""

class SystemOverloadedError(Exception):
    """Exceção lançada quando o sistema está sobrecarregado (backpressure)."""

class ConsistencyTimeoutError(Exception):
    """Exceção lançada quando o timeout de consistência é atingido em modo strict.
    
    Raised by KuzuActor.query when strict=True and the required watermark
    cannot be reached within CONSISTENCY_TIMEOUT.
    """


@dataclass
class KuzuConfig:
    """Configuration for Kùzu graph database tuning.
    
    Exposes Kùzu's internal configuration options for performance tuning.
    These settings affect memory usage, query performance, and concurrency.
    
    Kùzu Read Scaling Strategy:
    - **Vertical Scaling**: Use `max_num_threads` to maximize CPU usage for 
      complex OLAP queries. Has linear impact on query latency.
    - **Horizontal Scaling**: Use `read_only=True` to launch multiple reader
      processes pointing to the same storage (Single-Writer/Multi-Reader pattern).
      Only ONE process can write; unlimited readers can access simultaneously.
    
    Attributes:
        buffer_pool_size: Size of buffer pool in bytes. Default: 256MB.
                         Larger values improve performance for large graphs
                         but increase memory usage.
        max_num_threads: Maximum number of threads for query execution.
                        Default: 0 (use all CPU cores).
                        Set lower to avoid "noisy neighbor" issues when
                        running alongside other workloads (API server, etc).
        enable_compression: Enable database compression. Default: True.
                           Reduces disk usage but may impact write performance.
        read_only: Open database in read-only mode. Default: False.
                  CRITICAL for horizontal scaling: Multiple processes can
                  open the same database in read_only=True mode simultaneously.
                  Only ONE process should have read_only=False (the writer).
        max_db_size: Maximum database size in bytes. Default: None (unlimited).
                    Useful for preventing runaway disk usage.
        duckdb_path: Path to DuckDB file to attach for hybrid queries.
                    When set, enables zero-copy federation between Kùzu and DuckDB.
                    Queries can JOIN graph nodes with analytical tables.
        auto_load_extensions: Automatically load useful extensions (duckdb, httpfs).
                             Default: True.
    
    Example:
        ```python
        from malha import connect, KuzuConfig
        
        # === WRITER PROCESS (only one) ===
        # High-performance config with DuckDB federation
        writer_config = KuzuConfig(
            buffer_pool_size=4 * 1024**3,  # 4GB
            max_num_threads=8,
            read_only=False,  # This is the single writer
            duckdb_path="data/analytics.duckdb",
        )
        
        writer_kernel = await connect(
            kuzu_path="data/graph",
            kuzu_config=writer_config,
        )
        
        # === READER PROCESSES (multiple workers via Gunicorn/Uvicorn) ===
        # Read replica pointing to same storage
        reader_config = KuzuConfig(
            buffer_pool_size=1 * 1024**3,  # 1GB per worker
            max_num_threads=4,  # Limit to avoid noisy neighbor
            read_only=True,  # Multiple readers allowed
        )
        
        reader_kernel = await connect(
            kuzu_path="data/graph",  # Same path as writer!
            kuzu_config=reader_config,
        )
        
        # Low-memory config for edge device
        edge_config = KuzuConfig(
            buffer_pool_size=64 * 1024**2,  # 64MB
            max_num_threads=2,
            enable_compression=True,
            auto_load_extensions=False,  # Minimize overhead
        )
        ```
    """
    buffer_pool_size: int = 256 * 1024 * 1024  # 256MB default
    max_num_threads: int | None = None  # None = use CPU count (0 in Kùzu API)
    enable_compression: bool = True
    read_only: bool = False  # Set True for read replicas (horizontal scaling)
    max_db_size: int | None = None  # None = unlimited
    duckdb_path: str | None = None  # Path to DuckDB for hybrid queries
    auto_load_extensions: bool = True  # Load duckdb extension automatically


class RuntimeExecutionError(Exception):
    """Error during ephemeral runtime execution."""
    pass


class CodeSynthesisError(Exception):
    """Error during code synthesis/compilation."""
    pass


# ==============================================================================
# CONTEXT MANAGEMENT (Fat Kernel - Centralized)
# ==============================================================================
# This section provides thread/async-safe kernel injection.
# Previously in semantico.core, now centralized in malha.
# ==============================================================================

# ContextVar for transparent dependency injection of the Kernel
_kernel_context: ContextVar["UnifiedDataManager | None"] = ContextVar(
    "kernel_context", default=None
)


def set_kernel(kernel: "UnifiedDataManager") -> None:
    """Set the kernel in the current context (thread/async-safe).
    
    This is the canonical way to inject the kernel for use by domain objects.
    Call this once at application startup or in test fixtures.
    
    Args:
        kernel: UnifiedDataManager instance to use as the active kernel
        
    Example:
        ```python
        from malha import connect, set_kernel
        
        async def main():
            kernel = await connect()
            set_kernel(kernel)
            
            # Now domain objects can use get_kernel() transparently
            user = User(name="Alice")
            await user.save()  # Uses the kernel from context
        ```
    """
    _kernel_context.set(kernel)


def get_kernel() -> "UnifiedDataManager":
    """Get the kernel from the current context.
    
    Returns the kernel set via set_kernel() or connect().
    Raises RuntimeError if no kernel is available.
    
    Returns:
        The active UnifiedDataManager instance
        
    Raises:
        RuntimeError: If no kernel has been set
        
    Example:
        ```python
        from malha import get_kernel
        
        kernel = get_kernel()
        user = await kernel.get(User, rid="ri.app.prod.user.123")
        ```
    """
    kernel = _kernel_context.get()
    if kernel is None:
        raise RuntimeError(
            "No kernel available. Call malha.connect() or malha.set_kernel() first. "
            "Example: kernel = await malha.connect(); malha.set_kernel(kernel)"
        )
    return kernel


def clear_kernel() -> None:
    """Clear the kernel from the current context.
    
    Useful for testing to ensure clean state between tests.
    
    Example:
        ```python
        @pytest.fixture
        async def kernel():
            k = await connect(reset=True)
            set_kernel(k)
            yield k
            await k.close()
            clear_kernel()
        ```
    """
    _kernel_context.set(None)


# ==============================================================================
# PROCESS STATE MODEL (Fat Kernel - Workflow Persistence)
# ==============================================================================
# SysProcess stores durable workflow/saga state for crash recovery.
# Previously implicit in kinetic, now a first-class kernel model.
# ==============================================================================

class ProcessStatus(str, Enum):
    """Status of a system process (workflow/saga).
    
    State Machine:
        PENDING -> RUNNING -> COMPLETED
                          -> FAILED -> COMPENSATING -> COMPENSATED
                                                    -> DEAD_LETTER
        RUNNING -> SUSPENDED (can be resumed)
        RECOVERING (transient state during crash recovery)
    """
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUSPENDED = "SUSPENDED"  # NEW: Agent paused, can resume
    RECOVERING = "RECOVERING"  # NEW: Being recovered after crash
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    COMPENSATING = "COMPENSATING"
    COMPENSATED = "COMPENSATED"
    DEAD_LETTER = "DEAD_LETTER"


class SysProcess(SQLModel, table=True):
    """Durable process state for workflows and sagas.
    
    This table enables crash recovery for long-running processes.
    Workflows can checkpoint their state here and resume after restart.
    
    Attributes:
        id: Primary key (auto-generated)
        process_type: Type of process (e.g., "workflow", "saga", "job")
        process_name: Human-readable name
        status: Current status (PENDING, RUNNING, COMPLETED, etc.)
        state_payload: JSON-serialized process state
        started_at: When the process started
        completed_at: When the process completed (if applicable)
        heartbeat: Last heartbeat timestamp (for liveness detection)
        retries: Number of retry attempts
        error: Error message if failed
        node_id: Node that owns this process
        parent_id: Parent process ID (for nested workflows)
    
    Example:
        ```python
        # Create a workflow checkpoint
        process = SysProcess(
            process_type="workflow",
            process_name="OrderFulfillment",
            status=ProcessStatus.RUNNING,
            state_payload=json.dumps({"step": 2, "order_id": "123"}),
            node_id="node-1"
        )
        session.add(process)
        
        # Resume after crash
        stmt = select(SysProcess).where(
            SysProcess.status == ProcessStatus.RUNNING,
            SysProcess.node_id == "node-1"
        )
        orphaned = await session.execute(stmt)
        for proc in orphaned.scalars():
            await resume_workflow(proc)
        ```
    """
    __tablename__ = "sys_process"

    id: int | None = SQLField(default=None, primary_key=True)
    
    # Idempotency key - hash of (prompt + user_id + context)
    # Prevents duplicate processing of the same request
    idempotency_key: str | None = SQLField(default=None, unique=True, index=True)
    
    process_type: str = SQLField(index=True)  # 'workflow', 'saga', 'job', 'agent'
    process_name: str = SQLField(index=True)
    status: str = SQLField(default=ProcessStatus.PENDING.value, index=True)
    
    # State snapshot - serialized agent memory/conversation history
    state_payload: str | None = None  # JSON-serialized state
    
    # Result payload - structured output when completed
    result_payload: str | None = None  # JSON-serialized result
    
    # Optimistic locking for concurrent updates
    lock_version: int = SQLField(default=0)
    
    started_at: datetime | None = None
    completed_at: datetime | None = None
    heartbeat: datetime | None = None
    retries: int = SQLField(default=0)
    max_retries: int = SQLField(default=3)  # NEW: Configurable retry limit
    error: str | None = None
    node_id: str = SQLField(default="local", index=True)
    parent_id: int | None = SQLField(default=None, index=True)
    
    # Metadata for debugging and tracing
    created_at: datetime = SQLField(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = SQLField(default_factory=lambda: datetime.now(UTC))


# ==============================================================================
# STREAM DRIVER PROTOCOL & IMPLEMENTATION (Fat Kernel)
# ==============================================================================
# High-performance streaming writes to data lakes (Parquet).
# Previously in perception.DataLakeWriter, now centralized.
# ==============================================================================

class StreamDriver(Protocol):
    """Protocol for streaming data writers (data lake, event streams).
    
    Implementations handle buffering, partitioning, and efficient writes
    to storage systems like Parquet files, S3, or Kafka.
    """
    
    async def write(self, data: dict[str, Any]) -> None:
        """Write a single record to the stream buffer."""
        ...
    
    async def write_batch(self, records: list[dict[str, Any]]) -> None:
        """Write multiple records to the stream buffer."""
        ...
    
    async def flush(self) -> int:
        """Flush buffered records to storage. Returns count written."""
        ...
    
    async def close(self) -> None:
        """Close the stream and flush remaining data."""
        ...


class ParquetStreamDriver:
    """High-performance Parquet writer with Hive-style partitioning and WAL durability.
    
    Writes data to Parquet files with automatic buffering and partitioning.
    Supports local filesystem and S3 (via pyarrow).
    
    Features:
    - Automatic buffering with configurable flush threshold
    - Hive-style partitioning (year/month/day or custom)
    - Zero-copy writes via PyArrow
    - Async-friendly (runs I/O in thread pool)
    - **Write-Ahead Log (WAL)**: Optional durability guarantee for crash recovery
    
    Attributes:
        base_path: Root directory for Parquet files
        partition_cols: Columns to partition by (extracted from data)
        buffer_limit: Number of records before auto-flush
        wal_enabled: If True, writes to WAL before buffering (crash-safe)
    
    Example:
        ```python
        # Standard mode (fast, but may lose buffered data on crash)
        stream = ParquetStreamDriver(
            base_path="/data/events",
            partition_cols=["year", "month", "day"],
            buffer_limit=10000
        )
        
        # Durable mode (WAL-backed, crash-safe for critical data)
        stream = ParquetStreamDriver(
            base_path="/data/audit",
            buffer_limit=1000,
            wal_enabled=True  # Writes to .wal file before buffering
        )
        
        # Write records
        await stream.write({"sensor_id": "s1", "value": 42.5, "ts": "2024-01-15"})
        
        # Flush to disk
        count = await stream.flush()
        print(f"Wrote {count} records")
        
        # Cleanup
        await stream.close()
        ```
    """
    
    def __init__(
        self,
        base_path: str | Path,
        partition_cols: list[str] | None = None,
        buffer_limit: int = 10_000,
        wal_enabled: bool = False,
    ):
        """Initialize the Parquet stream driver.
        
        Args:
            base_path: Root directory for Parquet files
            partition_cols: Columns to use for Hive-style partitioning
                           Default: ["year", "month", "day"]
            buffer_limit: Number of records to buffer before auto-flush
            wal_enabled: If True, write records to WAL file before buffering.
                        This provides crash recovery at the cost of extra I/O.
                        Recommended for audit logs and financial data.
        """
        self.base_path = Path(base_path)
        self.partition_cols = partition_cols or ["year", "month", "day"]
        self.buffer_limit = buffer_limit
        self.wal_enabled = wal_enabled
        self._buffer: list[dict[str, Any]] = []
        self._lock = asyncio.Lock()
        self._total_written = 0
        
        # WAL (Write-Ahead Log) for crash recovery
        self._wal_path = self.base_path / ".wal" / "pending.ndjson"
        if self.wal_enabled:
            self._wal_path.parent.mkdir(parents=True, exist_ok=True)
            # Recover any pending records from previous crash
            self._recover_from_wal()
    
    def _recover_from_wal(self) -> None:
        """Recover pending records from WAL after crash.
        
        Called during initialization when wal_enabled=True.
        Loads any records that were written to WAL but not yet flushed to Parquet.
        """
        if not self._wal_path.exists():
            return
        
        recovered = 0
        try:
            with open(self._wal_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            record = json.loads(line)
                            self._buffer.append(record)
                            recovered += 1
                        except json.JSONDecodeError:
                            logger.warning(f"[WAL] Skipping corrupted line in WAL")
            
            if recovered > 0:
                logger.info(f"[WAL] Recovered {recovered} records from crash")
        except Exception as e:
            logger.error(f"[WAL] Error recovering from WAL: {e}")
    
    def _append_to_wal(self, record: dict[str, Any]) -> None:
        """Append a single record to WAL (synchronous, for durability).
        
        Args:
            record: Record to append to WAL
        """
        try:
            with open(self._wal_path, "a") as f:
                f.write(json.dumps(record, default=str) + "\n")
                f.flush()  # Ensure data hits disk
                os.fsync(f.fileno())  # Force OS to write to disk
        except Exception as e:
            logger.error(f"[WAL] Error appending to WAL: {e}")
            raise
    
    def _clear_wal(self) -> None:
        """Clear WAL after successful flush to Parquet.
        
        Called after records are safely written to Parquet files.
        """
        try:
            if self._wal_path.exists():
                self._wal_path.unlink()
        except Exception as e:
            logger.warning(f"[WAL] Error clearing WAL: {e}")
    
    async def write(self, data: dict[str, Any]) -> None:
        """Buffer a single record for batch writing.
        
        Automatically extracts partition columns from timestamp if present.
        Auto-flushes when buffer reaches limit.
        
        If WAL is enabled, the record is persisted to disk before buffering,
        ensuring crash recovery capability.
        
        Args:
            data: Record to write (dict with column values)
        """
        async with self._lock:
            # Auto-extract partition columns from timestamp
            row = self._enrich_partition_cols(data)
            
            # WAL: Persist to disk BEFORE buffering (crash-safe)
            if self.wal_enabled:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, self._append_to_wal, row)
            
            self._buffer.append(row)
            
            # Auto-flush if buffer is full
            if len(self._buffer) >= self.buffer_limit:
                await self._flush_internal()
    
    async def write_batch(self, records: list[dict[str, Any]]) -> None:
        """Buffer multiple records for batch writing.
        
        If WAL is enabled, records are persisted to disk before buffering.
        
        Args:
            records: List of records to write
        """
        async with self._lock:
            enriched_records = []
            for data in records:
                row = self._enrich_partition_cols(data)
                enriched_records.append(row)
            
            # WAL: Persist all records to disk BEFORE buffering (crash-safe)
            if self.wal_enabled:
                loop = asyncio.get_running_loop()
                for row in enriched_records:
                    await loop.run_in_executor(None, self._append_to_wal, row)
            
            self._buffer.extend(enriched_records)
            
            # Auto-flush if buffer exceeds limit
            while len(self._buffer) >= self.buffer_limit:
                await self._flush_internal()
    
    def _enrich_partition_cols(self, data: dict[str, Any]) -> dict[str, Any]:
        """Extract partition columns from timestamp if not present.
        
        Args:
            data: Original record
            
        Returns:
            Record with partition columns added
        """
        row = data.copy()
        
        # Try to extract from 'timestamp' field
        ts = data.get("timestamp")
        if ts:
            if isinstance(ts, str):
                try:
                    ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                except ValueError:
                    ts = None
            
            if isinstance(ts, datetime):
                if "year" not in row and "year" in self.partition_cols:
                    row["year"] = ts.year
                if "month" not in row and "month" in self.partition_cols:
                    row["month"] = ts.month
                if "day" not in row and "day" in self.partition_cols:
                    row["day"] = ts.day
        
        return row
    
    async def flush(self) -> int:
        """Flush buffered records to Parquet files.
        
        Returns:
            Number of records written
        """
        async with self._lock:
            return await self._flush_internal()
    
    async def _flush_internal(self) -> int:
        """Internal flush (must be called with lock held).
        
        Returns:
            Number of records written
        """
        if not self._buffer:
            return 0
        
        records_to_write = self._buffer.copy()
        self._buffer.clear()
        
        # Run I/O in thread pool
        loop = asyncio.get_running_loop()
        count = await loop.run_in_executor(
            None,
            self._write_parquet,
            records_to_write
        )
        
        self._total_written += count
        
        # WAL: Clear WAL after successful flush to Parquet
        # Records are now safely persisted, WAL can be cleared
        if self.wal_enabled:
            await loop.run_in_executor(None, self._clear_wal)
        
        return count
    
    def _write_parquet(self, records: list[dict[str, Any]]) -> int:
        """Write records to Parquet (runs in thread pool).
        
        Args:
            records: Records to write
            
        Returns:
            Number of records written
        """
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
            
            # Create Arrow table
            table = pa.Table.from_pylist(records)
            
            # Ensure base path exists
            self.base_path.mkdir(parents=True, exist_ok=True)
            
            # Write with partitioning
            pq.write_to_dataset(
                table,
                root_path=str(self.base_path),
                partition_cols=[c for c in self.partition_cols if c in table.column_names],
            )
            
            logger.debug(f"[Stream] Wrote {len(records)} records to {self.base_path}")
            return len(records)
            
        except ImportError:
            logger.warning("[Stream] PyArrow not available, falling back to JSON")
            return self._write_json_fallback(records)
        except Exception as e:
            logger.error(f"[Stream] Error writing Parquet: {e}")
            raise
    
    def _write_json_fallback(self, records: list[dict[str, Any]]) -> int:
        """Fallback to JSON if PyArrow is not available.
        
        Args:
            records: Records to write
            
        Returns:
            Number of records written
        """
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # Write as NDJSON (newline-delimited JSON)
        filename = f"data_{datetime.now(UTC).strftime('%Y%m%d_%H%M%S')}.ndjson"
        filepath = self.base_path / filename
        
        with open(filepath, "a") as f:
            for record in records:
                f.write(json.dumps(record, default=str) + "\n")
        
        return len(records)
    
    async def close(self) -> None:
        """Close the stream and flush remaining data."""
        await self.flush()
        logger.info(f"[Stream] Closed. Total records written: {self._total_written}")
    
    def get_stats(self) -> dict[str, Any]:
        """Get stream statistics.
        
        Returns:
            Dict with buffer_size, total_written, base_path
        """
        return {
            "buffer_size": len(self._buffer),
            "total_written": self._total_written,
            "base_path": str(self.base_path),
            "partition_cols": self.partition_cols,
        }


# ==============================================================================
# COMPUTE DRIVER PROTOCOL & IMPLEMENTATION (Fat Kernel)
# ==============================================================================
# Safe script execution using PEP 723 and uv.
# Previously in system.EphemeralRuntime, now centralized.
# ==============================================================================

class ComputeDriver(Protocol):
    """Protocol for compute drivers (script execution).
    
    Implementations handle safe execution of arbitrary code
    with dependency isolation and security constraints.
    """
    
    async def execute(
        self,
        code: str,
        dependencies: list[str] | None = None,
        timeout: int = 30,
    ) -> "ComputeResult":
        """Execute code and return result."""
        ...
    
    def validate(self, code: str) -> list[str]:
        """Validate code for safety. Returns list of errors."""
        ...


@dataclass
class ComputeResult:
    """Result of a compute execution.
    
    Attributes:
        success: Whether execution succeeded
        output: Stdout output
        error: Error message if failed
        return_value: Return value if any
        execution_time_ms: Execution time in milliseconds
    """
    success: bool
    output: str = ""
    error: str | None = None
    return_value: Any = None
    execution_time_ms: float = 0.0


class LocalComputeDriver:
    """Local script execution using uv and PEP 723.
    
    Creates ephemeral Python environments for safe execution of dynamic code.
    Uses PEP 723 inline script metadata for dependency specification.
    
    Features:
    - Isolated execution via uv (no dependency conflicts)
    - PEP 723 inline metadata for dependencies
    - Configurable timeout
    - Security validation (AST-based)
    
    Security:
    - Blocks dangerous imports (os, subprocess, sys, shutil)
    - Validates syntax before execution
    - Runs in subprocess for isolation
    
    Example:
        ```python
        compute = LocalComputeDriver()
        
        # Execute simple script
        result = await compute.execute('''
        print("Hello, World!")
        ''')
        print(result.output)  # "Hello, World!"
        
        # Execute with dependencies
        result = await compute.execute('''
        import httpx
        resp = httpx.get("https://api.example.com/data")
        print(resp.json())
        ''', dependencies=["httpx"])
        ```
    """
    
    # Forbidden patterns for security
    FORBIDDEN_IMPORTS = frozenset({"os", "subprocess", "sys", "shutil", "socket"})
    FORBIDDEN_PATTERNS = frozenset({
        "os.system", "subprocess", "eval(", "exec(", 
        "shutil.rmtree", "__import__", "open("
    })
    
    def __init__(
        self,
        work_dir: Path | str | None = None,
        sandbox_mode: str = "local",
    ):
        """Initialize the compute driver.
        
        Args:
            work_dir: Directory for temporary script files (Path or string)
            sandbox_mode: Execution mode ("local", "docker", "firecracker")
                         Currently only "local" is implemented.
        """
        if work_dir is None:
            self.work_dir = Path(tempfile.gettempdir()) / "malha_compute"
        elif isinstance(work_dir, str):
            self.work_dir = Path(work_dir)
        else:
            self.work_dir = work_dir
        self.work_dir.mkdir(parents=True, exist_ok=True)
        self.sandbox_mode = sandbox_mode
    
    async def execute(
        self,
        code: str,
        dependencies: list[str] | None = None,
        timeout: int = 30,
        env_vars: dict[str, str] | None = None,
    ) -> ComputeResult:
        """Execute a script in an isolated environment.
        
        Uses `uv run` with PEP 723 inline metadata for dependency management.
        Falls back to direct execution if uv is not available.
        
        Args:
            code: Python code to execute
            dependencies: List of pip dependencies (e.g., ["httpx", "pandas>=2.0"])
            timeout: Execution timeout in seconds
            env_vars: Additional environment variables
            
        Returns:
            ComputeResult with output or error
            
        Raises:
            RuntimeExecutionError: If execution fails critically
        """
        start = time.perf_counter()
        
        # Validate code first
        errors = self.validate(code)
        if errors:
            return ComputeResult(
                success=False,
                error=f"Validation failed: {'; '.join(errors)}",
                execution_time_ms=(time.perf_counter() - start) * 1000,
            )
        
        # Generate script with PEP 723 header
        script_content = self._to_pep723(code, dependencies or [])
        
        # Generate unique script file
        script_hash = hashlib.md5(code.encode()).hexdigest()[:8]
        script_path = self.work_dir / f"script_{script_hash}.py"
        
        try:
            # Write script
            script_path.write_text(script_content)
            
            logger.debug(f"[Compute] Executing script: {script_path}")
            
            # Execute with uv run
            env = {**os.environ, **(env_vars or {})}
            
            proc = await asyncio.create_subprocess_exec(
                "uv", "run", str(script_path),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=timeout,
                )
            except asyncio.TimeoutError:
                proc.kill()
                return ComputeResult(
                    success=False,
                    error=f"Execution timed out after {timeout}s",
                    execution_time_ms=(time.perf_counter() - start) * 1000,
                )
            
            elapsed = (time.perf_counter() - start) * 1000
            
            if proc.returncode != 0:
                return ComputeResult(
                    success=False,
                    output=stdout.decode().strip(),
                    error=stderr.decode().strip(),
                    execution_time_ms=elapsed,
                )
            
            return ComputeResult(
                success=True,
                output=stdout.decode().strip(),
                execution_time_ms=elapsed,
            )
            
        except FileNotFoundError:
            # uv not installed - fall back to simulation
            elapsed = (time.perf_counter() - start) * 1000
            logger.warning("[Compute] uv not found, returning simulated result")
            return ComputeResult(
                success=True,
                output=f"[Simulated - uv not found] Would execute: {script_path}",
                execution_time_ms=elapsed,
            )
        except Exception as e:
            elapsed = (time.perf_counter() - start) * 1000
            return ComputeResult(
                success=False,
                error=str(e),
                execution_time_ms=elapsed,
            )
        finally:
            # Cleanup
            if script_path.exists():
                try:
                    script_path.unlink()
                except Exception:
                    pass
    
    def _to_pep723(self, code: str, dependencies: list[str]) -> str:
        """Convert code to PEP 723 inline script format.
        
        Args:
            code: Python code
            dependencies: List of pip dependencies
            
        Returns:
            Code with PEP 723 header
        """
        if not dependencies:
            return code
        
        deps = "\n".join(f'#     "{dep}",' for dep in dependencies)
        header = f'''# /// script
# requires-python = ">=3.13"
# dependencies = [
{deps}
# ]
# ///

'''
        return header + code
    
    def validate(self, code: str) -> list[str]:
        """Validate code for safety using AST analysis.
        
        Checks for:
        1. Syntax validity
        2. Forbidden imports (os, subprocess, etc.)
        3. Forbidden patterns (eval, exec, etc.)
        
        Args:
            code: Python code to validate
            
        Returns:
            List of error messages (empty if valid)
        """
        errors = []
        
        # Check for forbidden patterns (string-based)
        for pattern in self.FORBIDDEN_PATTERNS:
            if pattern in code:
                errors.append(f"Forbidden pattern: {pattern}")
        
        # Syntax check and AST analysis
        try:
            tree = ast.parse(code)
            
            # Check for dangerous imports
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name in self.FORBIDDEN_IMPORTS:
                            errors.append(f"Forbidden import: {alias.name}")
                elif isinstance(node, ast.ImportFrom):
                    if node.module and node.module.split(".")[0] in self.FORBIDDEN_IMPORTS:
                        errors.append(f"Forbidden import: {node.module}")
                        
        except SyntaxError as e:
            errors.append(f"Syntax error: {e}")
        
        return errors
    
    async def run_script(
        self,
        code: str,
        dependencies: list[str] | None = None,
    ) -> str:
        """Convenience method to run a script and return output.
        
        Args:
            code: Python code to execute
            dependencies: List of pip dependencies
            
        Returns:
            Script output as string
            
        Raises:
            RuntimeExecutionError: If execution fails
        """
        result = await self.execute(code, dependencies)
        
        if not result.success:
            raise RuntimeExecutionError(result.error or "Unknown error")
        
        return result.output


# ==============================================================================
# UNIT OF WORK (Fat Kernel - Transaction Management)
# ==============================================================================
# Atomic transaction management for multi-object operations.
# Previously implicit in semantico.Archetype, now explicit.
# ==============================================================================

class Savepoint:
    """Context manager for nested transaction savepoints.
    
    Allows partial rollback within a UnitOfWork - if an operation fails
    inside a savepoint, only that portion is rolled back, not the entire
    transaction.
    
    Example - Agent Tool Retry:
        ```python
        async with UnitOfWork(kernel) as uow:
            uow.add(agent_state)  # This will be saved
            
            # Try tool A
            async with uow.savepoint() as sp:
                result = await risky_tool_a()
                uow.add(result)
            # If tool A fails, we can try tool B
            
            async with uow.savepoint() as sp:
                result = await tool_b()  # Fallback
                uow.add(result)
            
            await uow.commit()  # agent_state + successful tool result
        ```
    """
    
    def __init__(self, uow: "UnitOfWork", name: str | None = None):
        self._uow = uow
        self._name = name or f"sp_{id(self)}"
        self._objects_snapshot: int = 0
        self._links_snapshot: int = 0
        self._released = False
    
    async def __aenter__(self) -> "Savepoint":
        """Create savepoint - snapshot current state."""
        self._objects_snapshot = len(self._uow._objects)
        self._links_snapshot = len(self._uow._links)
        logger.debug(f"[Savepoint] Created {self._name} at objects={self._objects_snapshot}, links={self._links_snapshot}")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> bool:
        """Release or rollback savepoint based on exception."""
        if exc_type is not None and not self._released:
            # Rollback to snapshot
            self._uow._objects = self._uow._objects[:self._objects_snapshot]
            self._uow._links = self._uow._links[:self._links_snapshot]
            logger.warning(f"[Savepoint] Rolled back {self._name} due to: {exc_val}")
            self._released = True
            return True  # Suppress exception - savepoint handles it
        return False
    
    def release(self) -> None:
        """Explicitly release savepoint (merge changes to parent)."""
        self._released = True
        logger.debug(f"[Savepoint] Released {self._name}")


class UnitOfWork:
    """Atomic transaction manager for multi-object operations (SQL + Graph).
    
    The Problem:
    If you save a User (SQL) and then try to create a Link in the Graph,
    and the Link creation fails, you end up with an "orphan" User in the
    database with no graph connections.
    
    The Solution:
    UnitOfWork groups everything together. Graph edges are only processed
    if the SQL commit is successful. The pattern ensures:
    - All objects are saved in a single SQL transaction
    - Graph links are queued to the Outbox (processed after commit)
    - If anything fails, nothing is persisted
    
    NEW in v0.11: Savepoints for Nested Transactions
    - Use `uow.savepoint()` to create a nested transaction
    - If the savepoint fails, only that portion is rolled back
    - Perfect for AI agents trying multiple tools
    
    How It Works (Internal Flow):
    1. You call `uow.add(obj)` - object is queued (not saved yet)
    2. You call `uow.link(src, label, dst)` - link is queued (not created yet)
    3. You call `await uow.commit()`:
       - Step A: Opens SQL Transaction
       - Step B: Inserts all objects (generates RIDs)
       - Step C: Creates Outbox events for all links
       - Step D: Commits SQL (if fails, everything rolls back)
       - Step E: Graph Worker reads Outbox and creates edges asynchronously
    
    Note: Graph edges are created asynchronously via the Outbox pattern.
    This means there's a small delay before edges appear in the graph.
    Use `required_watermark` in graph queries if you need consistency.
    
    Example - Customer Registration with Address:
        ```python
        from malha import UnitOfWork, get_kernel
        
        async def register_customer(name: str, street: str):
            kernel = get_kernel()
            
            async with UnitOfWork(kernel) as uow:
                # 1. Create domain objects (not saved yet)
                user = User(name=name, email=f"{name.lower()}@corp.com")
                addr = Address(street=street, number="1000")
                
                # 2. Add to unit of work
                uow.add(user)
                uow.add(addr)
                
                # 3. Define the relationship
                uow.link(
                    src=user, 
                    label="LIVES_IN", 
                    dst=addr, 
                    props={"since": "2024"}
                )
                
                # 4. Atomic commit
                await uow.commit()
            
            print(f"Success! User RID: {user.rid}")
            return user
        ```
    
    Example - Agent with Tool Fallback (NEW):
        ```python
        async with UnitOfWork(kernel) as uow:
            # Save agent state first
            agent = AgentState(prompt="...", status="running")
            uow.add(agent)
            
            # Try primary tool with savepoint
            try:
                async with uow.savepoint():
                    result = await expensive_api_call()
                    uow.add(ToolResult(data=result))
            except ToolError:
                # Savepoint rolled back, try fallback
                async with uow.savepoint():
                    result = await fallback_tool()
                    uow.add(ToolResult(data=result))
            
            # Commit agent + successful tool result
            await uow.commit()
        ```
    
    Example - Batch Order Processing:
        ```python
        async with UnitOfWork(kernel) as uow:
            order = Order(total=500.00, status="pending")
            uow.add(order)
            
            for item_data in cart_items:
                item = OrderItem(
                    product_id=item_data["product_id"],
                    quantity=item_data["quantity"],
                    price=item_data["price"],
                )
                uow.add(item)
                uow.link(order, "CONTAINS", item)
            
            # All items linked to order atomically
            await uow.commit()
        ```
    
    Error Handling:
        ```python
        try:
            async with UnitOfWork(kernel) as uow:
                uow.add(user)
                uow.add(invalid_object)  # Will fail
                await uow.commit()
        except Exception as e:
            # UoW automatically clears pending objects
            # No orphan data in the database
            print(f"Transaction failed: {e}")
        ```
    """
    
    def __init__(self, kernel: "UnifiedDataManager | None" = None):
        """Initialize the Unit of Work.
        
        Args:
            kernel: UnifiedDataManager instance (uses context if not provided)
        """
        self._kernel = kernel
        self._objects: list[DomainResource] = []
        self._links: list[tuple[DomainResource, str, DomainResource, dict[str, Any] | None]] = []
        self._committed = False
        self._savepoint_counter = 0
    
    def _get_kernel(self) -> "UnifiedDataManager":
        """Get kernel from injection or context."""
        if self._kernel is not None:
            return self._kernel
        return get_kernel()
    
    async def __aenter__(self) -> "UnitOfWork":
        """Enter async context manager."""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager, rolling back if not committed."""
        if exc_type is not None and not self._committed:
            logger.warning(f"[UnitOfWork] Rolling back due to exception: {exc_val}")
            self.clear()
        return None  # Don't suppress exceptions
    
    def savepoint(self, name: str | None = None) -> Savepoint:
        """Create a savepoint for nested transaction.
        
        Use this when you want to try an operation that might fail,
        without losing the entire transaction.
        
        Args:
            name: Optional name for debugging
            
        Returns:
            Savepoint context manager
            
        Example:
            ```python
            async with uow.savepoint() as sp:
                # Try risky operation
                await risky_tool()
            # If it fails, only this savepoint is rolled back
            ```
        """
        self._savepoint_counter += 1
        sp_name = name or f"savepoint_{self._savepoint_counter}"
        return Savepoint(self, sp_name)
    
    def add(self, obj: DomainResource) -> DomainResource:
        """Add a domain object to the unit of work.
        
        Args:
            obj: Domain object to persist
            
        Returns:
            The same object (for chaining)
        """
        self._objects.append(obj)
        return obj
    
    def link(
        self,
        src: DomainResource,
        label: str,
        dst: DomainResource,
        props: dict[str, Any] | None = None,
    ) -> None:
        """Add a graph link to the unit of work.
        
        Args:
            src: Source object
            label: Edge label
            dst: Destination object
            props: Optional edge properties
        """
        self._links.append((src, label, dst, props))
    
    async def commit(self, agent: Any = None) -> list[DomainResource]:
        """Commit all changes atomically.
        
        Persists all objects first, then creates all links.
        If any operation fails, raises an exception (caller should handle rollback).
        
        Args:
            agent: Optional agent context for governance hooks
            
        Returns:
            List of persisted domain objects
            
        Raises:
            Exception: If any operation fails
        """
        kernel = self._get_kernel()
        saved: list[DomainResource] = []
        
        try:
            # 1. Persist all objects
            for obj in self._objects:
                result = await kernel.save_versioned(obj, agent=agent)
                # Update original object with persisted data
                obj.__dict__.update(result.__dict__)
                saved.append(obj)
            
            # 2. Create all links
            for src, label, dst, props in self._links:
                await kernel.link(src.to_envelope(), dst.to_envelope(), label, props)
            
            self._committed = True
            logger.debug(f"[UnitOfWork] Committed {len(saved)} objects and {len(self._links)} links")
            return saved
            
        except Exception as e:
            logger.error(f"[UnitOfWork] Commit failed: {e}")
            raise
    
    async def rollback(self) -> None:
        """Explicitly rollback the unit of work.
        
        Clears all pending objects and links without committing.
        """
        logger.info("[UnitOfWork] Explicit rollback requested")
        self.clear()
    
    def clear(self) -> None:
        """Clear all pending objects and links."""
        self._objects.clear()
        self._links.clear()
        self._committed = False
        self._savepoint_counter = 0
    
    @property
    def pending_objects(self) -> int:
        """Number of objects pending commit."""
        return len(self._objects)
    
    @property
    def pending_links(self) -> int:
        """Number of links pending commit."""
        return len(self._links)
    
    @property
    def is_committed(self) -> bool:
        """Whether this UoW has been committed."""
        return self._committed


# ==============================================================================
# DEPRECATION HELPERS
# ==============================================================================

def _emit_deprecation_warning(old_location: str, new_location: str, version: str = "1.0.0") -> None:
    """Emit a deprecation warning for moved functionality.
    
    Args:
        old_location: Where the function was (e.g., "semantico.set_kernel")
        new_location: Where it is now (e.g., "malha.set_kernel")
        version: Version when it will be removed
    """
    warnings.warn(
        f"{old_location} is deprecated and will be removed in v{version}. "
        f"Use {new_location} instead.",
        DeprecationWarning,
        stacklevel=3,
    )


# --- Implicit Causal Scheduling Types ---
@dataclass(order=True)
class KuzuTask:
    """Task wrapper for priority queue with causal ordering.
    
    Priority levels:
    - 0: High priority (writes) - processed first
    - 10: Low priority (reads) - processed after writes
    """
    priority: int
    payload: tuple = field(compare=False)  # (op, args, kwargs)
    future: asyncio.Future = field(compare=False)
    tx_id: int | None = field(default=None, compare=False)

# --- Modelos de Dados ---
class SysOutbox(SQLModel, table=True):
    """Tabela de Fila Transacional (Outbox Pattern) com suporte a replicação distribuída."""
    __tablename__ = "sys_outbox"

    id: int | None = SQLField(default=None, primary_key=True)
    rid: str = SQLField(index=True)
    operation: str  # 'UPSERT', 'DELETE'
    payload: str    # JSON serializado
    status: str = SQLField(default="PENDING", index=True)  # PENDING, DONE, FAILED, RETRY, DEAD_LETTER
    error: str | None = None
    created_at: datetime = SQLField(default_factory=lambda: datetime.now(UTC))
    processed_at: datetime | None = None

    # Campos para Replicação Distribuída (Synapse)
    origin_node: str = SQLField(default="local", index=True)  # Identifica origem do evento
    retries: int = SQLField(default=0)  # Contador de tentativas
    next_retry_at: datetime | None = None  # Timestamp para próxima tentativa

# --- Componentes de Domínio ---
# NOTA: BaseResource foi removida. Use DomainResource do registro.
# Para criar recursos de domínio customizados, herde de DomainResource:
#
#   from registro import DomainResource
#
#   class User(DomainResource):
#       name: str
#       email: str
#
# O DomainResource já implementa to_envelope() e from_envelope() para
# conversão automática entre o modelo lógico e a tabela física.

class Interceptor(abc.ABC):
    """Interceptor interface for domain hooks operating on DomainResource.
    
    Interceptors agora trabalham com objetos de domínio (DomainResource),
    permitindo validação e transformação na camada lógica antes da persistência.
    """

    @abc.abstractmethod
    async def on_write(self, obj: DomainResource, agent: Any | None = None) -> None:
        """Hook executed before or during persistence of a resource version.
        
        Args:
            obj: Objeto de domínio sendo persistido
            agent: Contexto opcional do agente executando a operação
        """
        raise NotImplementedError

    @abc.abstractmethod
    async def on_read(self, obj: DomainResource, agent: Any | None = None) -> DomainResource:
        """Hook executed after loading a resource version from persistence.
        
        Args:
            obj: Objeto de domínio carregado
            agent: Contexto opcional do agente executando a operação
            
        Returns:
            Objeto de domínio (potencialmente transformado)
        """
        raise NotImplementedError


# --- Repositórios ---
class BaseRepository(Generic[T]):
    """Base repository with CRUD operations using optimistic locking.
    
    Opera na tabela física (RegistroResource) mas retorna objetos de domínio (DomainResource).
    Implementa o padrão Domain Envelope:
    - Queries são feitas na tabela física
    - Resultados são hidratados para objetos de domínio via from_envelope()
    - Saves convertem domínio para físico via to_envelope()

    This repository is stateless with respect to database sessions. A concrete
    `AsyncSession` must be provided on each operation.
    """

    def __init__(self, model_cls: type[T]):
        """Initialize repository.
        
        Args:
            model_cls: Subclass de DomainResource (ex: User)
        """
        self.model_cls = model_cls  # Ex: User (DomainResource)
        self.physical_cls = RegistroResource  # Tabela física é sempre RegistroResource
        self._init_model()

    def _init_model(self) -> None:
        """Initialize model-specific configurations."""
        # A tabela física é sempre RegistroResource
        self.table = self.physical_cls.__table__
        self.primary_key = "id"  # Fixo no RegistroResource

    async def get(
        self,
        session: AsyncSession,
        id: Any = None,
        rid: str | None = None,
        version: int | None = None,
        at_time: datetime | None = None,
        active_only: bool = True,
        **filters,
    ) -> T | None:
        """Get a single resource with Time Travel support.
        
        Suporta busca por:
        - id: Primary key físico (único por versão)
        - rid: Resource ID lógico (compartilhado entre versões)
        - version: Versão específica
        - at_time: Point-in-time query (busca versão válida naquele momento)
        - active_only: Se True, busca apenas versão ativa (valid_to IS NULL)
        
        Time Travel Examples:
            # Estado atual
            user = await repo.get(session, rid="ri.app.prod.user.123")
            
            # Versão específica
            user_v1 = await repo.get(session, rid="ri.app.prod.user.123", version=1)
            
            # Estado em um momento específico
            user_past = await repo.get(session, rid="ri.app.prod.user.123", 
                                      at_time=datetime(2024, 1, 1))
        
        Args:
            session: SQLAlchemy async session
            id: Physical primary key
            rid: Logical resource identifier
            version: Specific version number
            at_time: Point-in-time for temporal query
            active_only: Only return active version (valid_to IS NULL)
            **filters: Additional column filters
        
        Returns:
            Hydrated domain object or None
        """
        # Query na tabela FÍSICA
        query = select(self.physical_cls)

        # Busca por ID físico (único por versão)
        if id is not None:
            query = query.where(self.physical_cls.id == id)

        # Busca por RID lógico (compartilhado entre versões)
        elif rid is not None:
            query = query.where(self.physical_cls.rid == rid)

            # Time Travel: versão específica
            if version is not None:
                query = query.where(self.physical_cls.version == version)

            # Time Travel: point-in-time query
            elif at_time is not None:
                query = query.where(
                    and_(
                        self.physical_cls.valid_from <= at_time,
                        or_(
                            self.physical_cls.valid_to.is_(None),
                            self.physical_cls.valid_to > at_time,
                        ),
                    ),
                )

            # Padrão: apenas versão ativa
            elif active_only:
                query = query.where(self.physical_cls.valid_to.is_(None))

        # Filtros adicionais em colunas SQL
        for key, value in filters.items():
            if hasattr(self.physical_cls, key):
                query = query.where(getattr(self.physical_cls, key) == value)

        result = await session.execute(query)
        physical_record = result.scalars().first()

        if physical_record:
            # Hidratação: Envelope -> Domain
            return self.model_cls.from_envelope(physical_record)
        return None

    async def mget(
        self,
        session: AsyncSession,
        rids: list[str],
        active_only: bool = True,
    ) -> list[T]:
        """Fetch multiple resources by RID in a single query.
        
        Optimized batch retrieval to solve N+1 problems.
        
        Args:
            session: SQLAlchemy session
            rids: List of Resource IDs to fetch
            active_only: Return only active versions (valid_to IS NULL)
            
        Returns:
            List of domain objects found (order is not guaranteed)
        """
        if not rids:
            return []

        query = select(self.physical_cls).where(self.physical_cls.rid.in_(rids))

        if active_only:
            query = query.where(self.physical_cls.valid_to.is_(None))

        result = await session.execute(query)
        physical_records = result.scalars().all()

        return [self.model_cls.from_envelope(record) for record in physical_records]

    async def create(self, session: AsyncSession, data: dict[str, Any] | BaseModel) -> T:
        """Create a new resource.
        
        Converte objeto de domínio para envelope físico antes de persistir.
        """
        # Se vier dict, instancia o DomainResource primeiro para validar
        if isinstance(data, dict):
            domain_obj = self.model_cls(**data)
        elif isinstance(data, BaseModel):
            # Se já é um BaseModel, pode ser DomainResource ou dict
            if isinstance(data, DomainResource):
                domain_obj = data
            else:
                # Converte para dict e instancia
                domain_obj = self.model_cls(**data.model_dump(exclude_unset=True))
        else:
            domain_obj = data

        # Converte para envelope físico
        physical_record = domain_obj.to_envelope()

        session.add(physical_record)
        await session.flush()
        await session.refresh(physical_record)

        # Retorna objeto de domínio hidratado (com IDs gerados)
        return self.model_cls.from_envelope(physical_record)

    async def update(
        self,
        session: AsyncSession,
        id: Any,
        data: dict[str, Any] | BaseModel,
        expected_version: int | None = None,
    ) -> T | None:
        """Update an existing resource with optimistic locking.
        
        Carrega o registro físico, atualiza campos, reconverte para envelope.
        """
        # Get current domain object
        current_domain = await self.get(session, id)
        if not current_domain:
            return None

        # Check version if expected_version is provided
        if expected_version is not None and current_domain.version != expected_version:
            raise OptimisticLockError(
                f"Version mismatch. Expected {expected_version}, got {current_domain.version}",
            )

        # Prepare update data
        if isinstance(data, BaseModel):
            update_data = data.model_dump(exclude_unset=True)
        else:
            update_data = data

        # Update fields on domain object
        for field, value in update_data.items():
            setattr(current_domain, field, value)

        # Increment version
        current_domain.version += 1
        current_domain.updated_at = datetime.now(UTC)

        # Convert back to physical and merge
        updated_physical = current_domain.to_envelope()

        # Merge into session (update existing record)
        merged = await session.merge(updated_physical)
        await session.flush()
        await session.refresh(merged)

        # Return hydrated domain object
        return self.model_cls.from_envelope(merged)

    async def delete(self, session: AsyncSession, id: Any, expected_version: int | None = None) -> bool:
        """Delete a resource with optional version check.
        
        Deleta o registro físico da tabela.
        """
        # Get domain object (for version check)
        domain_obj = await self.get(session, id)
        if not domain_obj:
            return False

        if expected_version is not None and domain_obj.version != expected_version:
            raise OptimisticLockError(
                f"Version mismatch. Expected {expected_version}, got {domain_obj.version}",
            )

        # Delete physical record
        # Precisamos buscar o registro físico novamente para deletar
        query = select(self.physical_cls).where(self.physical_cls.id == id)
        result = await session.execute(query)
        physical_record = result.scalars().first()

        if physical_record:
            await session.delete(physical_record)
            return True
        return False

    async def get_history(
        self,
        session: AsyncSession,
        rid: str,
        order_by: str = "valid_from",
        ascending: bool = True,
    ) -> list[T]:
        """Get complete version history for a resource (Time Travel).
        
        Retorna todas as versões de um recurso, ordenadas por timestamp.
        Útil para auditoria, debugging e análise de evolução.
        
        Example:
            # Ver todas as versões de um usuário
            history = await repo.get_history(session, rid="ri.app.prod.user.123")
            for version in history:
                print(f"Version {version.version}: {version.name} at {version.valid_from}")
        
        Args:
            session: SQLAlchemy async session
            rid: Logical resource identifier
            order_by: Campo para ordenação (valid_from, tx_from, version)
            ascending: Se True, ordem crescente; se False, decrescente
        
        Returns:
            Lista de todas as versões do recurso (hidratadas)
        """
        query = select(self.physical_cls).where(self.physical_cls.rid == rid)

        # Ordenação
        order_col = getattr(self.physical_cls, order_by, self.physical_cls.valid_from)
        if ascending:
            query = query.order_by(order_col.asc())
        else:
            query = query.order_by(order_col.desc())

        result = await session.execute(query)
        physical_records = result.scalars().all()

        # Hidratar todas as versões
        return [self.model_cls.from_envelope(record) for record in physical_records]

    async def list(
        self,
        session: AsyncSession,
        *,
        skip: int = 0,
        limit: int = 100,
        **filters: Any,
    ) -> list[T]:
        """List resources with pagination and filtering.
        
        Queries na tabela física, retorna lista de objetos de domínio.
        """
        query = select(self.physical_cls)

        # Apply filters (apenas colunas SQL)
        for key, value in filters.items():
            if hasattr(self.physical_cls, key):
                query = query.where(getattr(self.physical_cls, key) == value)

        # Apply pagination
        query = query.offset(skip).limit(limit)

        result = await session.execute(query)
        physical_records = result.scalars().all()

        # Hidrata todos os registros para objetos de domínio
        return [self.model_cls.from_envelope(record) for record in physical_records]

# --- Drivers ---
class SQLDriver(Protocol):
    """Protocol for SQL database drivers."""
    async def get_session(self) -> AsyncSession: ...
    async def create_tables(self) -> None: ...

class GraphDriver(Protocol):
    """Protocol for graph database drivers."""
    async def register_schema(self, model_cls: type[BaseModel]) -> None: ...
    async def upsert_node(self, data: dict, node_type: str) -> None: ...
    async def delete_node(self, rid: str, label: str) -> None: ...
    async def create_edge(self, src: str, dst: str, label: str, props: dict) -> None: ...
    async def delete_edge(self, src: str, dst: str, label: str) -> None: ...
    async def query(self, cypher: str, params: dict) -> list[dict]: ...

class AnalyticsDriver(Protocol):
    """Protocol for analytical database drivers."""
    async def register_view(self, view_name: str, source_table: str) -> None: ...
    async def ingest_arrow(self, table_name: str, arrow_table: Any) -> None: ...
    async def query(self, sql: str) -> Any: ...

class ReplicationDriver(Protocol):
    """Protocol for distributed replication drivers (e.g., Synapse).
    
    This driver enables P2P mesh networking for distributed data synchronization.
    Implementations should handle:
    - Broadcasting local changes to peer nodes
    - Receiving and applying remote changes
    - Loop prevention (origin tracking)
    - Connection management and fault tolerance
    """
    async def start(self) -> None:
        """Initialize and start the replication service (server + client)."""
        ...

    async def broadcast(self, event: SysOutbox) -> None:
        """Broadcast a replication event to all peer nodes.
        
        Args:
            event: Outbox event containing RID, operation, and payload
        """
        ...

    async def stop(self) -> None:
        """Gracefully shutdown the replication service."""
        ...

class AsyncSQLAlchemyDriver:
    """SQLAlchemy implementation of SQLDriver."""

    def __init__(self, url: str):
        # Auto-fix para drivers async
        if "sqlite" in url and "aiosqlite" not in url:
            url = url.replace("sqlite:", "sqlite+aiosqlite:")
        elif "postgresql" in url and "asyncpg" not in url:
            url = url.replace("postgresql:", "postgresql+asyncpg:")

        connect_args = {}
        pool_args = {}

        if "sqlite" in url:
            # Otimização de Concorrência para SQLite
            connect_args = {"check_same_thread": False, "timeout": 30}
            # SQLite usa StaticPool que não aceita pool_size/max_overflow
            if ":memory:" not in url:
                pool_args = {"pool_pre_ping": True}
        else:
            # PostgreSQL/MySQL podem usar pool completo
            pool_args = {
                "pool_pre_ping": True,
                "pool_size": 20,
                "max_overflow": 10,
                "pool_timeout": 30,
                "pool_recycle": 3600,
            }

        self.engine = create_async_engine(
            url,
            echo=False,  # Desabilitar echo nos testes
            future=True,
            connect_args=connect_args,
            **pool_args,
        )

        # Create session factory
        self.session_factory = sessionmaker(
            self.engine, expire_on_commit=False, class_=AsyncSession,
        )

    def get_engine(self) -> "AsyncEngine":
        """Return the underlying SQLAlchemy async engine.

        Exposed mainly for diagnostics and advanced tuning; tests also
        use this to verify URL normalization behavior.
        """
        return self.engine

    async def get_session(self) -> AsyncSession:
        """Get a new database session."""
        return self.session_factory()

    async def create_tables(self):
        """Create all tables in the database."""
        async with self.engine.begin() as conn:
            await conn.run_sync(SQLModel.metadata.create_all)

class KuzuActor:
    """Thread-safe actor for Kùzu database operations with Implicit Causal Scheduling.
    
    Features:
    - Priority Queue: Writes (priority 0) are processed before reads (priority 10)
    - Watermark Tracking: Tracks processed transaction IDs for causal consistency
    - Consistency Barriers: Reads can wait for specific writes to complete
    - Backpressure: Queue size monitoring for system health
    - Configurable: Buffer pool, threads, compression via KuzuConfig
    
    Example:
        ```python
        from malha import KuzuActor, KuzuConfig
        
        # Default configuration
        actor = KuzuActor("data/graph")
        
        # Custom configuration for high-performance server
        config = KuzuConfig(
            buffer_pool_size=2 * 1024**3,  # 2GB
            max_num_threads=8,
        )
        actor = KuzuActor("data/graph", config=config)
        ```
    """

    # Consistency timeout for waiting queries (seconds)
    CONSISTENCY_TIMEOUT = 3.0

    def __init__(
        self, 
        path: str, 
        max_workers: int = 1,
        config: KuzuConfig | None = None,
    ):
        """Initialize KuzuActor with optional configuration.
        
        Args:
            path: Path to Kùzu database directory
            max_workers: Number of worker threads (default: 1 for single-writer)
            config: Optional KuzuConfig for tuning buffer pool, threads, etc.
        """
        self.path = path
        self.config = config or KuzuConfig()
        
        # Priority Queue: lower number = higher priority (writes=0, reads=10)
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue()
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="kuzu_worker")
        self._db: kuzu.Database | None = None
        self._conn: kuzu.Connection | None = None
        self._running = True
        
        # IMPLICIT CAUSAL SCHEDULING: Consistency Control
        self._processed_watermark: int = 0  # Highest processed tx_id
        # Dict[tx_id, Set[Future]] - Queries waiting for specific transactions
        self._waiting_queries: dict[int, set[asyncio.Future]] = defaultdict(set)
        
        self._bg_task = asyncio.create_task(self._worker())

    async def _init_connection(self) -> None:
        """Initialize Kùzu connection in a thread-safe manner with config."""
        def _init():
            if self._db is None:
                # Build Kùzu Database with configuration
                # See: kuzu.Database(database_path, buffer_pool_size, max_num_threads, 
                #                    compression, lazy_init, read_only, max_db_size, ...)
                db_config = {
                    "buffer_pool_size": self.config.buffer_pool_size,
                    "compression": self.config.enable_compression,
                    "read_only": self.config.read_only,
                }
                
                # max_num_threads goes to Database in Kùzu API
                if self.config.max_num_threads:
                    db_config["max_num_threads"] = self.config.max_num_threads
                
                # Max database size
                if self.config.max_db_size:
                    db_config["max_db_size"] = self.config.max_db_size
                
                # Create database with config
                self._db = kuzu.Database(self.path, **db_config)
                
                # Create connection (num_threads also accepted here for per-connection override)
                self._conn = kuzu.Connection(self._db)
                
                logger.info(
                    f"[Kuzu] Initialized: buffer_pool={self.config.buffer_pool_size // (1024*1024)}MB, "
                    f"threads={self.config.max_num_threads or 'auto'}, "
                    f"compression={self.config.enable_compression}, "
                    f"read_only={self.config.read_only}"
                )
                
                # Load extensions for enhanced functionality
                if self.config.auto_load_extensions:
                    self._load_extensions()

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self._executor, _init)

    def _load_extensions(self) -> None:
        """Load Kùzu extensions for enhanced functionality.
        
        Extensions loaded:
        - duckdb: Enables zero-copy federation with DuckDB for hybrid queries
        - httpfs: Enables reading remote files (S3, HTTP) directly
        
        If duckdb_path is configured, attaches the DuckDB database as 'analytics'.
        """
        if self._conn is None:
            return
            
        # Load DuckDB extension for hybrid queries
        try:
            self._conn.execute("INSTALL duckdb; LOAD duckdb;")
            logger.info("[Kuzu] DuckDB extension loaded")
            
            # Attach DuckDB file if configured
            if self.config.duckdb_path and os.path.exists(self.config.duckdb_path):
                # Escape path for safety
                safe_path = self.config.duckdb_path.replace("'", "''")
                self._conn.execute(f"ATTACH '{safe_path}' AS analytics (DBTYPE DUCKDB);")
                logger.info(f"[Kuzu] Attached DuckDB '{self.config.duckdb_path}' as 'analytics'")
                self._duckdb_attached = True
            else:
                self._duckdb_attached = False
                
        except Exception as e:
            # Extension loading is optional, don't fail initialization
            logger.warning(f"[Kuzu] Failed to load DuckDB extension: {e}")
            self._duckdb_attached = False
        
        # Load httpfs for remote file access (S3, HTTP)
        try:
            self._conn.execute("INSTALL httpfs; LOAD httpfs;")
            logger.info("[Kuzu] HTTPFS extension loaded")
        except Exception as e:
            logger.debug(f"[Kuzu] HTTPFS extension not available: {e}")

    def get_watermark(self) -> int:
        """Return the current processed watermark (highest tx_id processed).
        
        Used by UnifiedDataManager to track consistency and implement backpressure.
        """
        return self._processed_watermark

    def qsize(self) -> int:
        """Return the size of the pending operations queue.
        
        Used for backpressure monitoring to prevent overwhelming
        the single-writer Kùzu database.
        """
        return self._queue.qsize()

    def _wake_up_waiters(self, current_mark: int) -> None:
        """Release queries waiting for transactions up to current_mark.
        
        Called after each write with a tx_id to notify waiting reads
        that their required data is now available.
        """
        # Find all tx_ids that are now satisfied
        satisfied_ids = [tx for tx in self._waiting_queries if tx <= current_mark]
        
        for tx_id in satisfied_ids:
            waiters = self._waiting_queries.pop(tx_id)
            for future in waiters:
                if not future.done():
                    future.set_result(True)

    async def _worker(self) -> None:
        """Background worker that processes operations by priority.
        
        Writes (priority 0) are processed before reads (priority 10).
        After processing a write with tx_id, updates watermark and wakes waiters.
        """
        await self._init_connection()

        while self._running or not self._queue.empty():
            try:
                # Get highest priority task (lowest number)
                task: KuzuTask = await asyncio.wait_for(
                    self._queue.get(),
                    timeout=0.1,
                )

                op, args, kwargs = task.payload

                try:
                    if op == "query":
                        result = await self._execute_query(*args, **kwargs)
                    elif op == "execute":
                        result = await self._execute_write(*args, **kwargs)
                        
                        # Update watermark if this was a tracked write
                        if task.tx_id is not None:
                            self._processed_watermark = max(self._processed_watermark, task.tx_id)
                            self._wake_up_waiters(self._processed_watermark)
                    else:
                        raise ValueError(f"Unknown operation: {op}")

                    if not task.future.done():
                        task.future.set_result(result)

                except Exception as e:
                    if not task.future.done():
                        task.future.set_exception(e)

                finally:
                    self._queue.task_done()

            except TimeoutError:
                continue
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in KuzuActor worker: {e}")

    async def _execute_query(self, query: str, params: dict | None = None) -> list:
        """Execute a read-only query."""
        def _run():
            if self._conn is None:
                raise RuntimeError("Kuzu connection not initialized")
            result = self._conn.execute(query, params or {})
            return result.get_as_df().to_dict("records")

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(self._executor, _run)

    async def _execute_write(self, query: str, params: dict | None = None) -> None:
        """Execute a write operation."""
        def _run():
            if self._conn is None:
                raise RuntimeError("Kuzu connection not initialized")
            self._conn.execute(query, params or {})

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(self._executor, _run)

    # Public API with Causal Consistency
    async def query(
        self, 
        query: str, 
        params: dict | None = None,
        required_watermark: int = 0,
        strict: bool = False,
    ) -> list:
        """Execute a read-only query with optional causal consistency barrier.
        
        Args:
            query: Cypher query string
            params: Query parameters
            required_watermark: If > 0, wait until this tx_id is processed
                               before executing the query (Read-Your-Own-Writes)
            strict: If True, raise ConsistencyTimeoutError on timeout instead of
                   proceeding with stale read. Use for critical queries where
                   reading stale data is worse than failing.
        
        Returns:
            List of result dictionaries
        
        Raises:
            ConsistencyTimeoutError: If strict=True and timeout is reached
        
        Example:
            # Simple query (no consistency guarantee)
            results = await actor.query("MATCH (n) RETURN n")
            
            # Query with consistency barrier (waits for tx 42 to be processed)
            results = await actor.query(
                "MATCH (n:User) RETURN n",
                required_watermark=42
            )
            
            # Strict mode: fail if consistency cannot be achieved
            results = await actor.query(
                "MATCH (n:Account) RETURN n.balance",
                required_watermark=session_watermark,
                strict=True  # Raises ConsistencyTimeoutError on timeout
            )
        """
        # 1. Consistency Barrier: Wait for required transaction if needed
        if required_watermark > self._processed_watermark:
            wait_future = asyncio.get_running_loop().create_future()
            self._waiting_queries[required_watermark].add(wait_future)
            try:
                # Timeout to prevent deadlock if event never arrives
                await asyncio.wait_for(wait_future, timeout=self.CONSISTENCY_TIMEOUT)
            except asyncio.TimeoutError:
                if strict:
                    raise ConsistencyTimeoutError(
                        f"Graph consistency timeout in strict mode. "
                        f"Required tx {required_watermark}, current {self._processed_watermark}. "
                        f"Query aborted to prevent stale read."
                    )
                else:
                    logger.warning(
                        f"Graph consistency timeout. Wanted tx {required_watermark}, "
                        f"got {self._processed_watermark}. Proceeding with stale read."
                    )
            finally:
                # CRITICAL: Clean up to prevent memory leak
                self._waiting_queries[required_watermark].discard(wait_future)
                if not self._waiting_queries[required_watermark]:
                    del self._waiting_queries[required_watermark]

        # 2. Schedule the query with low priority (10)
        future = asyncio.get_running_loop().create_future()
        task = KuzuTask(
            priority=10,  # Low priority (reads)
            payload=("query", [query], {"params": params}),
            future=future,
            tx_id=None,
        )
        await self._queue.put(task)
        return await future

    async def execute(
        self, 
        query: str, 
        params: dict | None = None,
        tx_id: int | None = None,
    ) -> None:
        """Execute a write operation with optional transaction tracking.
        
        Args:
            query: Cypher query string
            params: Query parameters
            tx_id: Transaction ID for watermark tracking (from outbox.id)
                   When provided, waiting queries will be notified after processing
        
        Example:
            # Simple write (no tracking)
            await actor.execute("CREATE (n:User {name: $name})", {"name": "Alice"})
            
            # Tracked write (for causal consistency)
            await actor.execute(
                "CREATE (n:User {name: $name})",
                {"name": "Bob"},
                tx_id=outbox_event.id
            )
        """
        future = asyncio.get_running_loop().create_future()
        task = KuzuTask(
            priority=0,  # High priority (writes)
            payload=("execute", [query], {"params": params}),
            future=future,
            tx_id=tx_id,
        )
        await self._queue.put(task)
        await future

    # Graph-specific methods
    _ghost_schema_initialized: bool = False

    async def ensure_ghost_schema(self) -> None:
        """Ensure the Ghost Node schema exists for Helix pattern.
        
        Creates the 'Object' node table and 'LINK' relationship table
        required for Virtual Objects that don't exist in the SQL layer.
        
        This method is idempotent - it only creates the schema once per instance.
        """
        if self._ghost_schema_initialized:
            return

        # Create Object node table for Ghost Nodes
        try:
            await self.execute("""
                CREATE NODE TABLE Object (
                    rid STRING PRIMARY KEY,
                    virtual BOOLEAN,
                    created_at STRING
                )
            """)
            logger.debug("[Helix] Created Object node table for Ghost Nodes")
        except RuntimeError as e:
            if "already exists" not in str(e).lower():
                logger.debug(f"Ghost schema Object table: {e}")

        # Create generic LINK relationship table
        try:
            await self.execute("""
                CREATE REL TABLE LINK (
                    FROM Object TO Object,
                    label STRING,
                    synced_at STRING,
                    source_pk STRING,
                    target_fk STRING
                )
            """)
            logger.debug("[Helix] Created LINK relationship table for Ghost Nodes")
        except RuntimeError as e:
            if "already exists" not in str(e).lower():
                logger.debug(f"Ghost schema LINK table: {e}")

        self._ghost_schema_initialized = True

    async def register_schema(self, model_cls: type[BaseModel]) -> None:
        """Register a model schema in Kùzu."""
        ddl = generate_ddl(model_cls, dialect="kuzu", table_name=getattr(model_cls, "__name__", "Resource"))
        for stmt in ddl.split(";"):
            stmt = stmt.strip()
            if stmt:
                try:
                    await self.execute(stmt)
                except RuntimeError as e:
                    if "already exists" not in str(e):
                        raise

    async def upsert_node(
        self, 
        data: dict, 
        node_type: str,
        tx_id: int | None = None,
    ) -> None:
        """Upsert a node in Kùzu with optional transaction tracking.
        
        Args:
            data: Node properties (must include 'rid')
            node_type: Node label/type
            tx_id: Transaction ID for causal consistency tracking
        """
        if not data.get("rid"):
            raise ValueError("Node must have an 'rid' field")

        props = []
        params = {}
        for k, v in data.items():
            if v is not None:
                props.append(f"{k}=${k}")
                params[k] = v

        query = f"""
        MERGE (n:{node_type} {{rid: $rid}})
        ON MATCH SET {', '.join(props)}
        ON CREATE SET {', '.join([f"n.{k}=${k}" for k in data])}
        """

        await self.execute(query, {**data, **params}, tx_id=tx_id)

    async def delete_node(
        self, 
        rid: str, 
        label: str,
        tx_id: int | None = None,
    ) -> None:
        """Delete a node from Kùzu with optional transaction tracking.
        
        Args:
            rid: Resource ID of the node to delete
            label: Node label/type
            tx_id: Transaction ID for causal consistency tracking
        """
        query = f"MATCH (n:{label} {{rid: $rid}}) DETACH DELETE n"
        await self.execute(query, {"rid": rid}, tx_id=tx_id)

    async def create_edge(
        self,
        src: str,
        dst: str,
        label: str,
        props: dict | None = None,
        create_ghost_nodes: bool = True,
    ) -> None:
        """Create an edge between two nodes with Ghost Node support (Helix).
        
        When create_ghost_nodes=True (default), this method uses MERGE to create
        "stub" nodes if they don't exist. This enables the Helix pattern where
        Virtual Objects (that live in external systems) can participate in the
        graph without being persisted in the SQL layer.
        
        Ghost nodes are created with only the RID and a virtual=true flag,
        allowing the graph to connect entities that the Kernel doesn't "own".
        
        Args:
            src: Source node RID
            dst: Destination node RID  
            label: Edge label/type
            props: Optional edge properties
            create_ghost_nodes: If True, create stub nodes for missing RIDs (Helix pattern)
        """
        props = props or {}
        now = datetime.now(UTC).isoformat()

        if create_ghost_nodes:
            # Ensure Ghost Node schema exists (Object table + LINK rel table)
            await self.ensure_ghost_schema()

            # Helix Pattern: Use MERGE to create Ghost Nodes (stubs) if they don't exist
            # This allows connecting Virtual Objects that aren't in the SQL layer
            # Step 1: Ensure source node exists
            try:
                await self.execute(
                    "MERGE (a:Object {rid: $rid}) ON CREATE SET a.virtual = $virtual, a.created_at = $now",
                    {"rid": src, "virtual": True, "now": now},
                )
            except RuntimeError:
                pass  # Node may already exist

            # Step 2: Ensure destination node exists
            try:
                await self.execute(
                    "MERGE (b:Object {rid: $rid}) ON CREATE SET b.virtual = $virtual, b.created_at = $now",
                    {"rid": dst, "virtual": True, "now": now},
                )
            except RuntimeError:
                pass  # Node may already exist

            # Step 3: Create the edge using LINK table
            # Store the label as a property since we use a generic LINK table
            edge_props = {
                "label": label,
                "synced_at": props.get("synced_at", now),
                "source_pk": props.get("source_pk", ""),
                "target_fk": props.get("target_fk", ""),
            }

            query = """
            MATCH (a:Object {rid: $src_rid}), (b:Object {rid: $dst_rid})
            CREATE (a)-[r:LINK {label: $label, synced_at: $synced_at, source_pk: $source_pk, target_fk: $target_fk}]->(b)
            """
            params = {"src_rid": src, "dst_rid": dst, **edge_props}
            await self.execute(query, params)
        else:
            # Traditional: Fail if nodes don't exist
            # This uses dynamic edge labels (requires pre-registered REL TABLE)
            props_str = ", ".join(f"{k}: ${k}" for k in props) if props else ""
            query = f"""
            MATCH (a), (b) 
            WHERE a.rid = $src_rid AND b.rid = $dst_rid
            CREATE (a)-[r:{label} {{{props_str}}}]->(b)
            RETURN r
            """
            params = {"src_rid": src, "dst_rid": dst, **props}
            await self.execute(query, params)

    async def delete_edge(self, src: str, dst: str, label: str) -> None:
        """Delete an edge between two nodes."""
        query = f"""
        MATCH (a)-[r:{label}]->(b)
        WHERE a.rid = $src_rid AND b.rid = $dst_rid
        DELETE r
        """

        await self.execute(query, {
            "src_rid": src,
            "dst_rid": dst,
        })

    async def close(self) -> None:
        """Clean up resources."""
        self._running = False
        self._bg_task.cancel()
        try:
            await self._bg_task
        except asyncio.CancelledError:
            pass
        self._executor.shutdown(wait=True)

class DuckDBDriver:
    """DuckDB implementation of AnalyticsDriver with Federation Support (Helix).
    
    Supports federated queries across:
    - PostgreSQL (via postgres extension)
    - Parquet files (local or S3 via httpfs)
    - CSV files (local or remote)
    - SQLite databases
    """

    # Supported federation source types
    SUPPORTED_SOURCES = {"postgres", "parquet", "csv", "sqlite", "s3"}

    def __init__(self, sqlite_path: str = None):
        self.conn = duckdb.connect(":memory:")
        self.zero_copy = False
        self._extensions_loaded: set = set()

        # Load federation extensions
        self._init_extensions()

        if sqlite_path and os.path.exists(sqlite_path):
            try:
                self._load_extension("sqlite")
                # DuckDB 1.0+ uses different sqlite_attach signature
                try:
                    self.conn.execute(f"CALL sqlite_attach('{sqlite_path}', 'source_db');")
                except Exception:
                    self.conn.execute(f"ATTACH '{sqlite_path}' AS source_db (TYPE SQLITE, READ_ONLY);")
                self.zero_copy = True
            except Exception as e:
                logger.warning(f"DuckDB Zero-Copy unavailable: {e}")

    def _init_extensions(self) -> None:
        """Load essential extensions for Federation (Helix).
        
        Extensions:
        - httpfs: S3/HTTP remote file access
        - postgres: PostgreSQL federation
        - parquet: Parquet file support (usually built-in)
        """
        # Core extensions for federation - fail silently if unavailable
        for ext in ["httpfs", "parquet"]:
            self._load_extension(ext, required=False)

    def _load_extension(self, name: str, required: bool = False) -> bool:
        """Load a DuckDB extension.
        
        Args:
            name: Extension name (e.g., 'postgres', 'httpfs')
            required: If True, raise on failure
            
        Returns:
            True if loaded successfully
        """
        if name in self._extensions_loaded:
            return True

        try:
            self.conn.execute(f"INSTALL {name}; LOAD {name};")
            self._extensions_loaded.add(name)
            logger.debug(f"DuckDB extension '{name}' loaded")
            return True
        except Exception as e:
            if required:
                raise RuntimeError(f"Required DuckDB extension '{name}' failed to load: {e}")
            logger.debug(f"DuckDB extension '{name}' not loaded (may not be needed): {e}")
            return False

    async def _run(self, func, *args):
        """Execute a DuckDB operation in a background thread (async-friendly)."""
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, lambda: func(*args))

    async def register_view(self, view_name: str, source_table: str) -> None:
        """Register a view in DuckDB."""
        if self.zero_copy:
            query = f"CREATE OR REPLACE VIEW {view_name} AS SELECT * FROM source_db.{source_table};"
            await self.query(query)

    async def ingest_arrow(self, table_name: str, arrow_table: Any) -> None:
        """Ingest data from an Arrow table."""
        def _ingest():
            self.conn.register(table_name, arrow_table)

        await self._run(_ingest)

    async def query(self, sql: str) -> Any:
        """Execute a SQL query returning raw tuples."""
        def _query():
            return self.conn.execute(sql).fetchall()

        return await self._run(_query)

    async def query_df(self, sql: str) -> list[dict[str, Any]]:
        """Execute a SQL query returning list of dicts (JSON-serializable).
        
        Args:
            sql: SQL query string
            
        Returns:
            List of dictionaries with column names as keys
        """
        def _query():
            df = self.conn.execute(sql).df()
            return df.to_dict(orient="records")

        return await self._run(_query)

    async def query_federated(
        self,
        source_config: dict[str, Any],
        sql_filter: str = "1=1",
        columns: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a federated query on an external data source without moving data.
        
        This enables Zero-ETL analytics by pushing predicates to the source system.
        DuckDB uses Predicate Pushdown to minimize data transfer.
        
        Args:
            source_config: Dictionary with connection details:
                - type: 'postgres', 'parquet', 'csv', 's3', 'sqlite'
                - For postgres: dsn, table (or schema.table)
                - For parquet/csv: path (local or s3://)
                - For s3: path, aws_access_key_id, aws_secret_access_key (optional)
                - For sqlite: path, table
            sql_filter: WHERE clause filter (default "1=1" for all rows)
            columns: Optional list of columns to select (default: all columns).
                     Use this for lightweight queries that only need specific fields,
                     especially useful for SyncService topology extraction.
            
        Returns:
            List of dictionaries with query results
            
        Example:
            # Query PostgreSQL directly (all columns)
            await driver.query_federated({
                "type": "postgres",
                "dsn": "dbname=legacy user=reader password=secret host=db.example.com",
                "table": "customers"
            }, "status = 'active' AND created_at > '2024-01-01'")
            
            # Query only specific columns (lightweight for SyncService)
            await driver.query_federated({
                "type": "postgres",
                "dsn": "dbname=legacy user=reader host=db.example.com",
                "table": "orders"
            }, "1=1", columns=["id", "customer_id"])
            
            # Query Parquet on S3
            await driver.query_federated({
                "type": "parquet",
                "path": "s3://bucket/data/events.parquet"
            }, "event_type = 'purchase'")
        """
        source_type = source_config.get("type", "").lower()

        if source_type not in self.SUPPORTED_SOURCES:
            raise ValueError(
                f"Unsupported federation source '{source_type}'. "
                f"Supported: {', '.join(sorted(self.SUPPORTED_SOURCES))}. "
                f"Example: {{'type': 'csv', 'path': '/data/file.csv'}}",
            )

        # Build the federated query based on source type
        if source_type == "postgres":
            query = self._build_postgres_query(source_config, sql_filter, columns)

        elif source_type == "parquet":
            query = self._build_parquet_query(source_config, sql_filter, columns)

        elif source_type == "csv":
            query = self._build_csv_query(source_config, sql_filter, columns)

        elif source_type == "s3":
            query = self._build_s3_query(source_config, sql_filter, columns)

        elif source_type == "sqlite":
            query = self._build_sqlite_query(source_config, sql_filter, columns)

        else:
            raise ValueError(f"Federation source '{source_type}' not implemented")

        logger.debug(f"[Helix] Federated query: {query[:200]}...")
        return await self.query_df(query)

    def _get_select_clause(self, columns: list[str] | None) -> str:
        """Build SELECT clause from columns list.
        
        Args:
            columns: List of column names or None for all columns
            
        Returns:
            SELECT clause string (e.g., "*" or "id, name, email")
        """
        if columns:
            # Validate column names to prevent SQL injection
            for col in columns:
                if not col.replace("_", "").isalnum():
                    raise ValueError(f"Invalid column name: {col}")
            return ", ".join(columns)
        return "*"

    def _build_postgres_query(
        self,
        config: dict[str, Any],
        sql_filter: str,
        columns: list[str] | None = None,
    ) -> str:
        """Build PostgreSQL federated query using postgres_scan."""
        self._load_extension("postgres", required=True)

        dsn = config.get("dsn")
        table = config.get("table")
        schema = config.get("schema", "public")

        if not dsn or not table:
            raise ValueError(
                "PostgreSQL federation requires 'dsn' and 'table' in config. "
                "Example: {'type': 'postgres', 'dsn': 'dbname=mydb user=reader host=localhost', 'table': 'users'}",
            )

        select_clause = self._get_select_clause(columns)

        # Use postgres_scan for direct TCP connection to Postgres
        # Supports predicate pushdown for efficient filtering
        return f"SELECT {select_clause} FROM postgres_scan('{dsn}', '{schema}', '{table}') WHERE {sql_filter}"

    def _build_parquet_query(
        self,
        config: dict[str, Any],
        sql_filter: str,
        columns: list[str] | None = None,
    ) -> str:
        """Build Parquet federated query using read_parquet."""
        path = config.get("path")
        if not path:
            raise ValueError(
                "Parquet federation requires 'path' in config. "
                "Example: {'type': 'parquet', 'path': '/data/events.parquet'} or "
                "{'type': 'parquet', 'path': 's3://bucket/data.parquet'}",
            )

        # Configure S3 credentials if provided
        self._configure_s3_if_needed(config)

        select_clause = self._get_select_clause(columns)

        # read_parquet supports local files, HTTP URLs, and S3 paths
        return f"SELECT {select_clause} FROM read_parquet('{path}') WHERE {sql_filter}"

    def _build_csv_query(
        self,
        config: dict[str, Any],
        sql_filter: str,
        columns: list[str] | None = None,
    ) -> str:
        """Build CSV federated query using read_csv_auto."""
        path = config.get("path")
        if not path:
            raise ValueError(
                "CSV federation requires 'path' in config. "
                "Example: {'type': 'csv', 'path': '/data/products.csv'}",
            )

        # Configure S3 credentials if provided
        self._configure_s3_if_needed(config)

        select_clause = self._get_select_clause(columns)

        # read_csv_auto auto-detects delimiters, headers, types
        return f"SELECT {select_clause} FROM read_csv_auto('{path}') WHERE {sql_filter}"

    def _build_s3_query(
        self,
        config: dict[str, Any],
        sql_filter: str,
        columns: list[str] | None = None,
    ) -> str:
        """Build S3 federated query (auto-detect format)."""
        path = config.get("path")
        if not path:
            raise ValueError(
                "S3 federation requires 'path' in config. "
                "Example: {'type': 's3', 'path': 's3://bucket/data.parquet'}",
            )

        self._configure_s3_if_needed(config)

        select_clause = self._get_select_clause(columns)

        # Auto-detect format based on extension
        if path.endswith(".parquet"):
            return f"SELECT {select_clause} FROM read_parquet('{path}') WHERE {sql_filter}"
        if path.endswith(".csv"):
            return f"SELECT {select_clause} FROM read_csv_auto('{path}') WHERE {sql_filter}"
        if path.endswith(".json") or path.endswith(".ndjson"):
            return f"SELECT {select_clause} FROM read_json_auto('{path}') WHERE {sql_filter}"
        # Default to parquet for S3
        return f"SELECT {select_clause} FROM read_parquet('{path}') WHERE {sql_filter}"

    def _build_sqlite_query(
        self,
        config: dict[str, Any],
        sql_filter: str,
        columns: list[str] | None = None,
    ) -> str:
        """Build SQLite federated query."""
        self._load_extension("sqlite", required=True)

        path = config.get("path")
        table = config.get("table")

        if not path or not table:
            raise ValueError(
                "SQLite federation requires 'path' and 'table' in config. "
                "Example: {'type': 'sqlite', 'path': '/data/legacy.db', 'table': 'users'}",
            )

        # Attach and query SQLite database
        # Use unique alias based on path hash to avoid conflicts
        alias = f"fed_{abs(hash(path)) % 10000}"

        # Check if already attached (avoid duplicate attach error)
        try:
            # Try to query the alias - if it works, it's already attached
            self.conn.execute(f"SELECT 1 FROM {alias}.sqlite_master LIMIT 1")
        except Exception:
            # Not attached yet, attach now
            try:
                self.conn.execute(f"CALL sqlite_attach('{path}', '{alias}');")
            except Exception:
                # Fallback for older DuckDB versions
                try:
                    self.conn.execute(f"ATTACH '{path}' AS {alias} (TYPE SQLITE, READ_ONLY);")
                except Exception:
                    pass  # Already attached or other error

        select_clause = self._get_select_clause(columns)

        return f"SELECT {select_clause} FROM {alias}.{table} WHERE {sql_filter}"

    def _configure_s3_if_needed(self, config: dict[str, Any]) -> None:
        """Configure S3 credentials if provided in config."""
        path = config.get("path", "")

        if not path.startswith("s3://"):
            return

        self._load_extension("httpfs", required=True)

        # Set S3 credentials if provided
        if "aws_access_key_id" in config:
            self.conn.execute(f"SET s3_access_key_id='{config['aws_access_key_id']}';")
        if "aws_secret_access_key" in config:
            self.conn.execute(f"SET s3_secret_access_key='{config['aws_secret_access_key']}';")
        if "aws_region" in config:
            self.conn.execute(f"SET s3_region='{config['aws_region']}';")
        if "s3_endpoint" in config:
            self.conn.execute(f"SET s3_endpoint='{config['s3_endpoint']}';")

    def close(self) -> None:
        """Close the DuckDB connection."""
        self.conn.close()

# --- Signal System ---
class Signal:
    """Simple signal/slot implementation for event handling."""

    def __init__(self, name: str):
        self.name = name
        self._handlers: list[Handler] = []

    def connect(self, handler: Handler) -> None:
        """Connect a handler to this signal."""
        if handler not in self._handlers:
            self._handlers.append(handler)

    async def emit(self, payload: Any, background: bool = True) -> None:
        """Emit this signal with the given payload."""
        for handler in self._handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    if background:
                        asyncio.create_task(handler(payload))
                    else:
                        await handler(payload)
                else:
                    handler(payload)
            except Exception as e:
                logger.error(f"Error in signal handler for {self.name}: {e}")


# Global signals used across the kernel
post_save = Signal("post_save")
post_delete = Signal("post_delete")
post_ingest = Signal("post_ingest")

# --- Unified Data Manager ---
class UnifiedDataManager:
    """
    Unified data access layer with SQL, Graph, and Analytics capabilities.
    
    This is the main entry point for all data operations in the system.
    It provides a consistent interface for working with different data stores
    while maintaining data consistency and integrity.
    """

    # IMPLICIT CAUSAL SCHEDULING: Backpressure Configuration
    MAX_GRAPH_LAG: int = 5000  # Maximum pending events before rejecting writes

    def __init__(
        self,
        sql_driver: SQLDriver,
        graph_driver: GraphDriver,
        analytics_driver: AnalyticsDriver,
        replication_driver: ReplicationDriver | None = None,
        enable_monitoring: bool = True,
        node_id: str = "local",
    ):
        # Low-level drivers
        self.sql_driver = sql_driver
        self.graph_driver = graph_driver
        self.analytics_driver = analytics_driver
        self.replication_driver = replication_driver  # Optional P2P mesh driver

        # v4-style convenience aliases for DX
        self.sql = sql_driver
        self.graph = graph_driver
        self.analytics = analytics_driver
        self._repositories: dict[type[T], BaseRepository[T]] = {}
        self._interceptors: list[Interceptor] = []
        self._model_registry: dict[str, type[SQLModel]] = {}
        self._running = True

        # Instance-level references to global signals
        self.post_save = post_save
        self.post_delete = post_delete
        self.post_ingest = post_ingest

        # IMPLICIT CAUSAL SCHEDULING: Session Consistency Token
        # Tracks the highest outbox.id created in this session for Read-Your-Own-Writes
        self._session_watermark: int = 0

        # Observability (Phase 5)
        self.monitor: KernelMonitor | None = None
        self.instrumentation: KernelInstrumentation | None = None
        if enable_monitoring:
            self.monitor = KernelMonitor(analytics_driver, node_id=node_id)
            self.instrumentation = KernelInstrumentation(analytics_driver, node_id=node_id)

        # Saga handlers (Gap 2)
        self._saga_error_handlers: list[Callable] = []
        self._saga_compensation_handlers: list[Callable] = []

        # Start background tasks
        self._outbox_processor = asyncio.create_task(self._process_outbox())

    # ---------------------------------------------------------------------
    # Context Manager Support (async with)
    # ---------------------------------------------------------------------

    async def __aenter__(self) -> "UnifiedDataManager":
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager, ensuring cleanup."""
        await self.close()

    def add_interceptor(self, interceptor: Interceptor) -> None:
        """Register an interceptor for write/read hooks."""
        self._interceptors.append(interceptor)

    def on_saga_error(self, handler: Callable) -> Callable:
        """Register a saga error handler (Gap 2).
        
        Usage:
            @kernel.on_saga_error
            async def handle_rollback(event, error_data):
                # Compensate for failed operation
                original_obj = await kernel.get(error_data['original_tx'])
                await original_obj.rollback()
        """
        self._saga_error_handlers.append(handler)
        return handler

    def on_saga_compensation(self, handler: Callable) -> Callable:
        """Register a saga compensation handler (Gap 2).
        
        Usage:
            @kernel.on_saga_compensation
            async def handle_compensation(event, payload):
                # Execute rollback logic
                await kernel.delete(payload['rid'])
        """
        self._saga_compensation_handlers.append(handler)
        return handler

    # ---------------------------------------------------------------------
    # Implicit Causal Scheduling - Consistency & Backpressure
    # ---------------------------------------------------------------------

    def get_session_watermark(self) -> int:
        """Return the current session watermark (highest outbox.id created).
        
        This is used by semantico LinkManager to request causal consistency
        when querying the graph after a write operation.
        
        Returns:
            The highest outbox.id created in this session
        """
        return self._session_watermark

    def _check_backpressure(self) -> None:
        """Check if the graph is overwhelmed and reject writes if necessary.
        
        This prevents the system from accepting writes faster than the graph
        can process them, avoiding memory exhaustion and unbounded lag.
        
        Raises:
            SystemOverloadedError: If graph lag exceeds MAX_GRAPH_LAG
        """
        if not hasattr(self.graph_driver, "get_watermark"):
            return

        graph_mark = self.graph_driver.get_watermark()
        lag = self._session_watermark - graph_mark

        if lag > self.MAX_GRAPH_LAG:
            raise SystemOverloadedError(
                f"System overloaded. Graph lag: {lag} events "
                f"(session: {self._session_watermark}, graph: {graph_mark}). "
                f"Max allowed: {self.MAX_GRAPH_LAG}"
            )

    # ---------------------------------------------------------------------
    # Federation (Helix) - Zero-ETL Analytics
    # ---------------------------------------------------------------------

    async def query_federated(
        self,
        source_config: dict[str, Any],
        sql_filter: str = "1=1",
        columns: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a federated query on an external data source.
        
        This enables Zero-ETL analytics by pushing predicates to external systems.
        Supports PostgreSQL, Parquet, CSV, S3, and SQLite sources.
        
        Args:
            source_config: Dictionary with connection details:
                - type: 'postgres', 'parquet', 'csv', 's3', 'sqlite'
                - For postgres: dsn, table, schema (optional)
                - For parquet/csv: path (local or s3://)
                - For s3: path, aws_access_key_id, aws_secret_access_key (optional)
                - For sqlite: path, table
            sql_filter: WHERE clause filter (default "1=1" for all rows)
            columns: Optional list of columns to select (default: all columns).
                     Use this for lightweight queries, especially for SyncService
                     topology extraction where only keys are needed.
            
        Returns:
            List of dictionaries with query results
            
        Example:
            # Query legacy PostgreSQL database directly
            customers = await kernel.query_federated({
                "type": "postgres",
                "dsn": "dbname=legacy user=reader host=db.example.com",
                "table": "customers"
            }, "status = 'active'")
            
            # Query only specific columns (lightweight for SyncService)
            keys = await kernel.query_federated({
                "type": "postgres",
                "dsn": "dbname=legacy user=reader host=db.example.com",
                "table": "orders"
            }, "1=1", columns=["id", "customer_id"])
            
            # Query Parquet file on S3
            events = await kernel.query_federated({
                "type": "parquet",
                "path": "s3://bucket/data/events.parquet"
            }, "event_type = 'purchase'")
        """
        return await self.analytics_driver.query_federated(source_config, sql_filter, columns)

    # Federation shortcuts for common sources
    async def from_postgres(
        self,
        dsn: str,
        table: str,
        filter: str = "1=1",
        schema: str = "public",
    ) -> list[dict[str, Any]]:
        """Query PostgreSQL directly (Zero-ETL).
        
        Args:
            dsn: PostgreSQL connection string (e.g., "dbname=... user=... host=...")
            table: Table name to query
            filter: WHERE clause (default: all rows)
            schema: Schema name (default: public)
            
        Example:
            users = await kernel.from_postgres(
                "dbname=legacy user=reader host=db.example.com",
                "users",
                "status = 'active'"
            )
        """
        return await self.query_federated({
            "type": "postgres",
            "dsn": dsn,
            "table": table,
            "schema": schema,
        }, filter)

    async def from_parquet(
        self,
        path: str,
        filter: str = "1=1",
        **s3_config,
    ) -> list[dict[str, Any]]:
        """Query Parquet file directly (local or S3).
        
        Args:
            path: File path (local) or S3 URI (s3://bucket/key.parquet)
            filter: WHERE clause (default: all rows)
            **s3_config: Optional S3 credentials (aws_access_key_id, aws_secret_access_key, aws_region)
            
        Example:
            events = await kernel.from_parquet("s3://bucket/events.parquet", "year = 2024")
        """
        config = {"type": "parquet", "path": path, **s3_config}
        return await self.query_federated(config, filter)

    async def from_csv(
        self,
        path: str,
        filter: str = "1=1",
        **s3_config,
    ) -> list[dict[str, Any]]:
        """Query CSV file directly (local or S3).
        
        Args:
            path: File path (local) or S3 URI
            filter: WHERE clause (default: all rows)
            **s3_config: Optional S3 credentials
            
        Example:
            products = await kernel.from_csv("/data/products.csv", "price > 100")
        """
        config = {"type": "csv", "path": path, **s3_config}
        return await self.query_federated(config, filter)

    async def from_sqlite(
        self,
        path: str,
        table: str,
        filter: str = "1=1",
    ) -> list[dict[str, Any]]:
        """Query SQLite database directly.
        
        Args:
            path: Path to SQLite database file
            table: Table name to query
            filter: WHERE clause (default: all rows)
            
        Example:
            orders = await kernel.from_sqlite("/data/legacy.db", "orders", "status = 'pending'")
        """
        return await self.query_federated({
            "type": "sqlite",
            "path": path,
            "table": table,
        }, filter)

    def get_repository(self, model_cls: type[T]) -> BaseRepository[T]:
        """Get a repository for the given model class."""
        if model_cls not in self._repositories:
            self._repositories[model_cls] = BaseRepository[T](model_cls=model_cls)
        return self._repositories[model_cls]

    # ---------------------------------------------------------------------
    # Process Locking (Pessimistic Locking for Concurrency Control)
    # ---------------------------------------------------------------------

    async def acquire_process_lock(
        self,
        process_id: int,
        timeout: float = 30.0,
        nowait: bool = False,
    ) -> SysProcess | None:
        """Acquire an exclusive lock on a SysProcess row.
        
        Uses SELECT FOR UPDATE to prevent concurrent modifications.
        This is essential for distributed systems where multiple workers
        might try to process the same agent/workflow simultaneously.
        
        Args:
            process_id: The SysProcess.id to lock
            timeout: How long to wait for the lock (seconds)
            nowait: If True, fail immediately if lock is held
            
        Returns:
            The locked SysProcess if acquired, None if not found or locked
            
        Raises:
            TimeoutError: If lock cannot be acquired within timeout
            
        Example - Exclusive Agent Processing:
            ```python
            # Worker 1 and Worker 2 both receive the same task
            process = await kernel.acquire_process_lock(process_id, nowait=True)
            if process is None:
                # Another worker has the lock, skip
                return {"status": "busy"}
            
            try:
                # Only one worker reaches here
                await run_agent(process)
            finally:
                await kernel.release_process_lock(process_id)
            ```
        
        Note:
            - SQLite uses BEGIN IMMEDIATE for locking (no FOR UPDATE)
            - PostgreSQL uses SELECT FOR UPDATE NOWAIT/SKIP LOCKED
            - The lock is released when the session commits/rollbacks
        """
        async with await self.sql_driver.get_session() as session:
            try:
                # SQLite doesn't support FOR UPDATE, but BEGIN IMMEDIATE
                # provides similar semantics at the transaction level
                stmt = select(SysProcess).where(SysProcess.id == process_id)
                
                # For PostgreSQL, we would add .with_for_update(nowait=nowait)
                # SQLite handles this at transaction level
                
                result = await session.execute(stmt)
                process = result.scalar_one_or_none()
                
                if process is None:
                    return None
                
                # Update heartbeat to claim ownership
                process.heartbeat = datetime.now(UTC)
                process.node_id = self._node_id if hasattr(self, '_node_id') else "local"
                session.add(process)
                await session.commit()
                
                logger.debug(f"[Lock] Acquired lock on process {process_id}")
                return process
                
            except Exception as e:
                logger.warning(f"[Lock] Failed to acquire lock on process {process_id}: {e}")
                if nowait:
                    return None
                raise

    async def release_process_lock(self, process_id: int) -> bool:
        """Release a previously acquired process lock.
        
        Updates the heartbeat to indicate the process is no longer being worked on.
        
        Args:
            process_id: The SysProcess.id to release
            
        Returns:
            True if released successfully, False if not found
        """
        async with await self.sql_driver.get_session() as session:
            stmt = select(SysProcess).where(SysProcess.id == process_id)
            result = await session.execute(stmt)
            process = result.scalar_one_or_none()
            
            if process is None:
                return False
            
            # Clear ownership indicators
            process.heartbeat = None
            session.add(process)
            await session.commit()
            
            logger.debug(f"[Lock] Released lock on process {process_id}")
            return True

    async def get_or_create_process(
        self,
        idempotency_key: str,
        process_type: str = "agent",
        process_name: str = "default",
        state_payload: str | None = None,
    ) -> tuple[SysProcess, bool]:
        """Get existing process by idempotency key or create new one.
        
        This is the core idempotency mechanism - if a request with the same
        key was already processed, return that process instead of creating
        a duplicate.
        
        Args:
            idempotency_key: Unique key (e.g., hash of prompt + user_id)
            process_type: Type of process (agent, workflow, saga)
            process_name: Human-readable name
            state_payload: Initial state (JSON string)
            
        Returns:
            Tuple of (process, created) where created is True if new
            
        Example - Idempotent Agent Execution:
            ```python
            key = hashlib.sha256(f"{user_id}:{prompt}".encode()).hexdigest()
            process, created = await kernel.get_or_create_process(
                idempotency_key=key,
                process_type="agent",
                process_name="ChatAgent",
            )
            
            if not created and process.status == "COMPLETED":
                # Already processed, return cached result
                return json.loads(process.result_payload)
            
            # New or incomplete, continue processing
            ```
        """
        async with await self.sql_driver.get_session() as session:
            # Try to find existing
            stmt = select(SysProcess).where(SysProcess.idempotency_key == idempotency_key)
            result = await session.execute(stmt)
            existing = result.scalar_one_or_none()
            
            if existing:
                return existing, False
            
            # Create new
            process = SysProcess(
                idempotency_key=idempotency_key,
                process_type=process_type,
                process_name=process_name,
                status=ProcessStatus.PENDING.value,
                state_payload=state_payload,
                started_at=datetime.now(UTC),
            )
            session.add(process)
            await session.commit()
            await session.refresh(process)
            
            logger.info(f"[Process] Created new process {process.id} with key {idempotency_key[:16]}...")
            return process, True

    async def update_process_state(
        self,
        process_id: int,
        status: ProcessStatus | None = None,
        state_payload: str | None = None,
        result_payload: str | None = None,
        error: str | None = None,
    ) -> SysProcess | None:
        """Update process state with optimistic locking.
        
        Uses lock_version to prevent lost updates in concurrent scenarios.
        
        Args:
            process_id: The process to update
            status: New status (optional)
            state_payload: New state snapshot (optional)
            result_payload: Final result (optional)
            error: Error message if failed (optional)
            
        Returns:
            Updated process or None if not found
            
        Raises:
            OptimisticLockError: If another worker updated the process
        """
        async with await self.sql_driver.get_session() as session:
            stmt = select(SysProcess).where(SysProcess.id == process_id)
            result = await session.execute(stmt)
            process = result.scalar_one_or_none()
            
            if process is None:
                return None
            
            current_version = process.lock_version
            
            # Apply updates
            if status is not None:
                process.status = status.value
            if state_payload is not None:
                process.state_payload = state_payload
            if result_payload is not None:
                process.result_payload = result_payload
            if error is not None:
                process.error = error
            
            # Update metadata
            process.lock_version = current_version + 1
            process.updated_at = datetime.now(UTC)
            process.heartbeat = datetime.now(UTC)
            
            if status == ProcessStatus.COMPLETED:
                process.completed_at = datetime.now(UTC)
            
            session.add(process)
            await session.commit()
            await session.refresh(process)
            
            return process

    # ---------------------------------------------------------------------
    # Lifecycle & model registration
    # ---------------------------------------------------------------------

    async def boot(self) -> None:
        """Initialize the SQL schema.

        Kept for backwards compatibility and explicit control. In many cases
        `create_manager`/`connect` already call `create_tables()`.
        """
        await self.sql_driver.create_tables()

    async def register_model(self, model_cls: type[SQLModel]) -> None:
        """Register model schemas in graph and analytics projections.

        This mirrors the v4 behavior: a model is announced to Kùzu and
        DuckDB so that projections/views can be created.
        """
        self._model_registry[model_cls.__name__] = model_cls
        await self.graph_driver.register_schema(model_cls)
        # Use the SQLModel table name when available
        table_name = getattr(model_cls, "__tablename__", model_cls.__name__)
        await self.analytics_driver.register_view(model_cls.__name__, table_name)

    async def save(
        self,
        model_cls: type[T],
        data: dict[str, Any] | BaseModel,
        expected_version: int | None = None,
        agent: Any | None = None,
    ) -> T:
        """
        Save a resource with optimistic locking.
        
        Args:
            model_cls: The model class
            data: The data to save (dict or Pydantic model)
            expected_version: The expected version for optimistic locking
            
        Returns:
            The saved resource
            
        Raises:
            OptimisticLockError: If the version check fails
        """
        repo = self.get_repository(model_cls)

        # Convert to dict if needed
        if isinstance(data, BaseModel):
            data = data.model_dump()

        # Get primary key
        primary_key = repo.primary_key
        is_update = primary_key in data and data[primary_key] is not None

        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                resource = None
                if is_update:
                    # Update existing resource
                    resource = await repo.update(
                        session=session,
                        id=data[primary_key],
                        data=data,
                        expected_version=expected_version,
                    )

                # If not update or update failed (resource not found), create new
                if resource is None:
                    # Create new resource
                    resource = await repo.create(session, data)

                # Interceptors on write
                if isinstance(data, dict): # data is dict here
                    # We need the resource object for interceptors?
                    # on_write takes (obj, agent).
                    # resource is the object.
                    for interceptor in self._interceptors:
                        await interceptor.on_write(resource, agent)

                # Add to outbox for graph sync
                await self._add_to_outbox(session, resource, "UPSERT")

                # Emit post_save signal
                await self.post_save.emit(resource)

                return resource

    async def save_versioned(
        self,
        obj: DomainResource,
        agent: Any | None = None,
        origin: str = "local",
    ) -> DomainResource:
        """Save a new immutable version of a bitemporal resource (SCD Type 2) with Pessimistic Locking.

        This method uses SELECT FOR UPDATE to guarantee atomicity in concurrent environments,
        preventing race conditions where multiple transactions could create duplicate active versions.
        
        Implementa o padrão Domain Envelope:
        - Recebe objeto de domínio (DomainResource)
        - Converte para envelope físico (RegistroResource) via to_envelope()
        - Opera na tabela física
        - Retorna objeto de domínio hidratado via from_envelope()
        
        Args:
            obj: Objeto de domínio a ser versionado
            agent: Optional agent context for governance hooks
            origin: Origin node identifier ("local" or remote node ID) for loop prevention
        
        Returns:
            Objeto de domínio com a nova versão criada
        """
        start_time = time.perf_counter()
        status = "success"
        model_name = obj.__class__.__name__

        # IMPLICIT CAUSAL SCHEDULING: Backpressure check
        self._check_backpressure()

        # Advanced instrumentation (Gap 1)
        with metrics.timer("save.latency"):
            metrics.increment("save.count")

        try:
            # Governance: write interceptors (operam no objeto de domínio)
            for interceptor in self._interceptors:
                await interceptor.on_write(obj, agent)

            now = datetime.now(UTC)

            # Converte para envelope físico
            physical_record = obj.to_envelope()

            # Extrai dados do envelope (excluindo id e campos bitemporais)
            # CRÍTICO: Sempre excluir 'id' para forçar geração de novo ID pelo banco
            envelope_data = physical_record.model_dump(exclude={
                "id", "valid_from", "valid_to", "tx_from", "tx_to",
                "created_at", "updated_at",  # Também excluir timestamps para regenerar
            })

            # CRÍTICO: Garantir que id não está no dict (pode ter sido extraído do RID)
            envelope_data.pop("id", None)

            # CRÍTICO: Gerar novo ID para a nova versão (SCD Type 2)
            # O RID permanece o mesmo, mas cada versão tem seu próprio ID físico
            import ulid
            new_id = str(ulid.new())

            # Cria NOVO registro físico (nova versão = novo id)
            new_physical = RegistroResource(
                id=new_id,  # Novo ID para nova versão
                **envelope_data,
                valid_from=now,
                valid_to=None,
                tx_from=now,
                tx_to=None,
            )

            # Garante Resource Type correto se não vier preenchido
            if not new_physical.resource_type:
                # Usa o nome da classe de domínio (ex: 'User' -> 'user')
                new_physical.resource_type = obj.__class__.__name__.lower()

            # Track outbox event for watermark update after commit
            outbox_event: SysOutbox | None = None
            
            async with await self.sql_driver.get_session() as session:
                async with session.begin():
                    # PESSIMISTIC LOCKING: Lock active rows for this RID na tabela FÍSICA
                    # This prevents concurrent transactions from closing the same version
                    if new_physical.rid:
                        stmt = (
                            select(RegistroResource)
                            .where(
                                RegistroResource.rid == new_physical.rid,
                                RegistroResource.valid_to.is_(None),
                            )
                            .with_for_update()  # 🔒 CRITICAL: Pessimistic lock
                        )
                        result = await session.execute(stmt)
                        current_active = result.scalars().first()

                        # Close current active version atomically
                        if current_active is not None:
                            current_active.valid_to = now
                            current_active.tx_to = now
                            session.add(current_active)

                    # Insert new version (registro físico)
                    session.add(new_physical)

                    # Enqueue replication event in outbox (only if origin is local)
                    # Payload é o objeto de DOMÍNIO (rico), não o físico
                    if origin == "local":
                        outbox_event = SysOutbox(
                            rid=new_physical.rid,
                            operation="UPSERT",
                            payload=obj.model_dump_json(),  # Serializa o objeto de domínio
                            status="PENDING",
                            origin_node=origin,
                        )
                        session.add(outbox_event)
                        
                        # Flush to get the generated outbox.id before commit
                        await session.flush()

                # Ensure we see DB-generated fields
                await session.refresh(new_physical)
                
                # IMPLICIT CAUSAL SCHEDULING: Update session watermark AFTER commit
                # CRITICAL: Only update after successful commit to prevent phantom watermarks
                if outbox_event is not None and outbox_event.id is not None:
                    self._session_watermark = max(self._session_watermark, outbox_event.id)

            # Retorna objeto de domínio re-hidratado
            return obj.__class__.from_envelope(new_physical)

        except Exception:
            status = "error"
            raise

        finally:
            # Collect metric
            if self.monitor:
                duration_ms = (time.perf_counter() - start_time) * 1000
                await self.monitor.collect_metric(
                    operation="save_versioned",
                    duration_ms=duration_ms,
                    status=status,
                    resource_type=model_name,
                    metadata={"rid": obj.rid, "origin": origin},
                )

    async def insert(
        self,
        obj: DomainResource,
        *,
        replicate: bool = False,
        agent: Any | None = None,
    ) -> DomainResource:
        """Insert a new record without SCD2 versioning logic (Append-Only/Logs).

        This method provides a high-performance insertion path for:
        - **Log tables**: Audit logs, event streams, telemetry
        - **Append-only data**: Immutable records that never update
        - **High-throughput scenarios**: Where SCD2 locking overhead is unnecessary

        Unlike `save_versioned()`, this method:
        - Does NOT lock existing rows (no SELECT FOR UPDATE)
        - Does NOT close previous versions (no SCD2 logic)
        - Simply INSERTs a new record with generated timestamps
        - Optionally replicates to graph/peers

        Args:
            obj: Domain object to insert
            replicate: If True, add to outbox for graph sync and peer replication
            agent: Optional agent context for governance hooks

        Returns:
            Inserted domain object with generated IDs and timestamps

        Example:
            # High-performance log insertion
            log = AuditLog(action="user_login", user_id="123", ip="1.2.3.4")
            await kernel.insert(log)

            # Event stream (no replication needed)
            event = TelemetryEvent(metric="cpu_usage", value=85.5)
            await kernel.insert(event, replicate=False)

            # Append-only with graph sync
            transaction = PaymentTransaction(amount=100, currency="BRL")
            await kernel.insert(transaction, replicate=True)
        """
        start_time = time.perf_counter()
        status = "success"
        model_name = obj.__class__.__name__

        # IMPLICIT CAUSAL SCHEDULING: Backpressure check (only if replicating)
        if replicate:
            self._check_backpressure()

        # Instrumentation
        with metrics.timer("insert.latency"):
            metrics.increment("insert.count")

        try:
            # Governance: write interceptors
            for interceptor in self._interceptors:
                await interceptor.on_write(obj, agent)

            now = datetime.now(UTC)

            # Convert to physical envelope
            physical_record = obj.to_envelope()

            # Extract data excluding auto-generated fields
            envelope_data = physical_record.model_dump(exclude={
                "id", "valid_from", "valid_to", "tx_from", "tx_to",
                "created_at", "updated_at",
            })
            envelope_data.pop("id", None)

            # Generate new ID
            import ulid
            new_id = str(ulid.new())

            # Create physical record (append-only: no version closing)
            new_physical = RegistroResource(
                id=new_id,
                **envelope_data,
                valid_from=now,
                valid_to=None,  # Append-only: always "active"
                tx_from=now,
                tx_to=None,
            )

            # Ensure resource_type
            if not new_physical.resource_type:
                new_physical.resource_type = obj.__class__.__name__.lower()

            # Track outbox event for watermark update after commit
            outbox_event: SysOutbox | None = None
            
            async with await self.sql_driver.get_session() as session:
                async with session.begin():
                    # Simple INSERT - no locking, no version closing
                    session.add(new_physical)

                    # Optional: add to outbox for replication
                    if replicate:
                        outbox_event = SysOutbox(
                            rid=new_physical.rid,
                            operation="INSERT",
                            payload=obj.model_dump_json(),
                            status="PENDING",
                            origin_node="local",
                        )
                        session.add(outbox_event)
                        
                        # Flush to get the generated outbox.id before commit
                        await session.flush()

                await session.refresh(new_physical)
                
                # IMPLICIT CAUSAL SCHEDULING: Update session watermark AFTER commit
                # CRITICAL: Only update after successful commit to prevent phantom watermarks
                if outbox_event is not None and outbox_event.id is not None:
                    self._session_watermark = max(self._session_watermark, outbox_event.id)

            # Return hydrated domain object
            return obj.__class__.from_envelope(new_physical)

        except Exception:
            status = "error"
            raise

        finally:
            if self.monitor:
                duration_ms = (time.perf_counter() - start_time) * 1000
                await self.monitor.collect_metric(
                    operation="insert",
                    duration_ms=duration_ms,
                    status=status,
                    resource_type=model_name,
                    metadata={"rid": obj.rid, "replicate": replicate},
                )

    async def insert_batch(
        self,
        objects: list[DomainResource],
        *,
        replicate: bool = False,
    ) -> list[DomainResource]:
        """Insert multiple records in a single transaction (Batch Append-Only).

        Optimized for high-throughput log ingestion where you need to insert
        many records efficiently without individual transaction overhead.

        Args:
            objects: List of domain objects to insert
            replicate: If True, add all to outbox for replication

        Returns:
            List of inserted domain objects with generated IDs

        Example:
            # Batch log insertion
            logs = [
                AuditLog(action="page_view", page="/home"),
                AuditLog(action="page_view", page="/products"),
                AuditLog(action="click", element="buy_button"),
            ]
            inserted = await kernel.insert_batch(logs)
        """
        start_time = time.perf_counter()
        status = "success"

        with metrics.timer("insert_batch.latency"):
            metrics.increment("insert_batch.count", len(objects))

        try:
            now = datetime.now(UTC)
            import ulid

            physical_records = []
            for obj in objects:
                physical_record = obj.to_envelope()
                envelope_data = physical_record.model_dump(exclude={
                    "id", "valid_from", "valid_to", "tx_from", "tx_to",
                    "created_at", "updated_at",
                })
                envelope_data.pop("id", None)

                new_physical = RegistroResource(
                    id=str(ulid.new()),
                    **envelope_data,
                    valid_from=now,
                    valid_to=None,
                    tx_from=now,
                    tx_to=None,
                )
                if not new_physical.resource_type:
                    new_physical.resource_type = obj.__class__.__name__.lower()

                physical_records.append((obj, new_physical))

            # Track outbox events for watermark update after commit
            outbox_events: list[SysOutbox] = []
            
            async with await self.sql_driver.get_session() as session:
                async with session.begin():
                    for obj, new_physical in physical_records:
                        session.add(new_physical)

                        if replicate:
                            outbox_event = SysOutbox(
                                rid=new_physical.rid,
                                operation="INSERT",
                                payload=obj.model_dump_json(),
                                status="PENDING",
                                origin_node="local",
                            )
                            session.add(outbox_event)
                            outbox_events.append(outbox_event)
                    
                    # Flush to get generated outbox IDs before commit
                    if outbox_events:
                        await session.flush()

                # Refresh all to get generated fields
                for _, new_physical in physical_records:
                    await session.refresh(new_physical)
                
                # IMPLICIT CAUSAL SCHEDULING: Update session watermark AFTER commit
                # This ensures we only track IDs that were successfully persisted
                for outbox_event in outbox_events:
                    if outbox_event.id is not None:
                        self._session_watermark = max(self._session_watermark, outbox_event.id)

            # Return hydrated domain objects
            return [
                obj.__class__.from_envelope(new_physical)
                for obj, new_physical in physical_records
            ]

        except Exception:
            status = "error"
            raise

        finally:
            if self.monitor:
                duration_ms = (time.perf_counter() - start_time) * 1000
                await self.monitor.collect_metric(
                    operation="insert_batch",
                    duration_ms=duration_ms,
                    status=status,
                    metadata={"count": len(objects), "replicate": replicate},
                )

    async def _add_to_outbox(
        self,
        session: AsyncSession,
        resource: DomainResource,
        operation: str,
    ) -> None:
        """Add an operation to the outbox.
        
        Serializa o objeto de domínio (rico) para o payload.
        """
        outbox = SysOutbox(
            rid=str(resource.rid),
            operation=operation,
            payload=resource.model_dump_json(),  # Serializa objeto de domínio
            status="PENDING",
        )
        session.add(outbox)

    async def _process_outbox(self) -> None:
        """Background task to process outbox entries with resilience (DLQ + Exponential Backoff).
        
        This processor implements:
        - Dead Letter Queue (DLQ) for failed items after max retries
        - Exponential backoff for transient failures
        - Dual-write to Graph + Replication (if configured)
        """
        while self._running:
            try:
                now = datetime.now(UTC)

                # Get next batch of pending items (including retries that are due)
                async with await self.sql_driver.get_session() as session:
                    stmt = (
                        select(SysOutbox)
                        .where(
                            or_(
                                SysOutbox.status == "PENDING",
                                and_(
                                    SysOutbox.status == "RETRY",
                                    SysOutbox.next_retry_at <= now,
                                ),
                            ),
                        )
                        .order_by(SysOutbox.created_at.asc())
                        .limit(100)
                    )

                    result = await session.execute(stmt)
                    items = result.scalars().all()

                    # Instrumentation: Monitor queue lag (Gap 1)
                    metrics.set_gauge("outbox.lag", len(items))

                    # Gap 3: Monitor Kùzu queue depth
                    if hasattr(self.graph_driver, "qsize"):
                        metrics.set_gauge("kuzu.queue_depth", self.graph_driver.qsize())

                    if not items:
                        await asyncio.sleep(1)
                        continue

                    # Process each item with resilience
                    for item in items:
                        try:
                            # Process graph sync
                            await self._process_outbox_item(item)

                            # Broadcast to replication mesh (if driver configured)
                            if self.replication_driver and item.origin_node == "local":
                                await self.replication_driver.broadcast(item)

                            # Success: mark as done
                            item.status = "DONE"
                            item.processed_at = now

                        except Exception as e:
                            # Increment retry counter
                            item.retries = (item.retries or 0) + 1

                            if item.retries > 5:
                                # Move to Dead Letter Queue after 5 failures
                                logger.critical(
                                    f"Outbox item {item.id} (RID: {item.rid}) moved to DLQ after {item.retries} retries: {e}",
                                )
                                item.status = "DEAD_LETTER"
                                item.error = str(e)
                            else:
                                # Schedule retry with exponential backoff
                                backoff_seconds = 2 ** item.retries
                                item.status = "RETRY"
                                item.next_retry_at = now + timedelta(seconds=backoff_seconds)
                                item.error = str(e)
                                logger.warning(
                                    f"Outbox item {item.id} retry {item.retries}/5 scheduled in {backoff_seconds}s: {e}",
                                )

                        await session.commit()

            except Exception as e:
                logger.error(f"Critical error in outbox processor: {e}")
                await asyncio.sleep(5)  # Backoff on critical error

    async def _process_outbox_item(self, item: SysOutbox) -> None:
        """Process a single outbox item.
        
        Usa o global_registry do registro para descobrir classes de domínio.
        """
        try:
            # Parse the resource
            resource_data = json.loads(item.payload)

            # Get the model class
            model_name = None

            # Strategy 1: Try to get from payload (sempre presente em objetos de domínio)
            if isinstance(resource_data, dict):
                # Tenta 'type' primeiro (usado em DELETE)
                model_name = resource_data.get("type")

                # Se não tiver 'type', tenta extrair do resource_type ou RID
                if not model_name:
                    model_name = resource_data.get("resource_type")

            # Strategy 2: Registro RID format ri.service.instance.type.id
            if not model_name and item.rid.startswith("ri."):
                parts = item.rid.split(".")
                if len(parts) >= 5:
                    # ri.<service>.<instance>.<type>.<id>
                    model_name = parts[-2]

            # Strategy 3: Legacy RID format Type:ID
            if not model_name and ":" in item.rid:
                model_name = item.rid.split(":")[0]

            # Strategy 4: Fallback - tenta match com registry keys
            if not model_name:
                for name in self._model_registry:
                    if item.rid.startswith(name):
                        model_name = name
                        break

            if not model_name:
                raise ValueError(f"Could not determine model class from RID: {item.rid}")

            # Busca a classe no Global Registry do registro
            model_cls = global_registry.get(model_name)

            # Fallback 1: Try case-insensitive match no global registry
            if not model_cls:
                for key in global_registry._registry.keys():
                    if key.lower() == model_name.lower():
                        model_cls = global_registry.get(key)
                        break

            # Fallback 2: Try local _model_registry (para compatibilidade)
            if not model_cls:
                model_cls = self._model_registry.get(model_name)
                if not model_cls:
                    for name, cls_ in self._model_registry.items():
                        if name.lower() == model_name.lower():
                            model_cls = cls_
                            break

            # Fallback 3: Use DomainResource genérico se não achar classe específica
            if not model_cls:
                logger.warning(
                    f"Model class '{model_name}' not found in registry. "
                    f"Using generic DomainResource for RID: {item.rid}",
                )
                model_cls = DomainResource

            # Apply to graph with tx_id for causal consistency tracking
            # O graph driver espera um dict achatado
            # IMPLICIT CAUSAL SCHEDULING: Pass item.id as tx_id to update watermark
            if item.operation == "UPSERT":
                await self.graph_driver.upsert_node(
                    resource_data,
                    node_type=model_cls.__name__,
                    tx_id=item.id,  # Enables watermark tracking
                )
            elif item.operation == "DELETE":
                await self.graph_driver.delete_node(
                    rid=item.rid,
                    label=model_cls.__name__,
                    tx_id=item.id,  # Enables watermark tracking
                )
            elif item.operation == "INSERT":
                # INSERT uses same path as UPSERT for graph sync
                await self.graph_driver.upsert_node(
                    resource_data,
                    node_type=model_cls.__name__,
                    tx_id=item.id,  # Enables watermark tracking
                )

            # Instrumentation: successful processing
            metrics.increment("outbox.processed")

        except Exception:
            # Instrumentation: error
            metrics.increment("outbox.errors")
            raise

    async def delete(
        self,
        model_cls: type[T],
        id: Any,
        expected_version: int | None = None,
    ) -> bool:
        """
        Delete a resource with optimistic locking.
        
        Args:
            model_cls: The model class
            id: The ID of the resource to delete
            expected_version: The expected version for optimistic locking
            
        Returns:
            bool: True if the resource was deleted, False if not found
            
        Raises:
            OptimisticLockError: If the version check fails
        """
        repo = self.get_repository(model_cls)

        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                # Get resource first to get RID for outbox
                resource = await repo.get(session, id)
                rid_for_outbox = str(id)
                if resource and hasattr(resource, "rid") and resource.rid:
                     rid_for_outbox = str(resource.rid)

                # Delete the resource
                deleted = await repo.delete(session, id, expected_version=expected_version)

                if deleted:
                    # Add to outbox for graph sync
                    outbox = SysOutbox(
                        rid=rid_for_outbox,
                        operation="DELETE",
                        payload=json.dumps({"id": str(id), "type": model_cls.__name__}),
                        status="PENDING",
                    )
                    session.add(outbox)

                return deleted

    async def delete_versioned(
        self,
        obj: DomainResource,
        agent: Any | None = None,
    ) -> None:
        """Soft delete a bitemporal resource by closing the active version.

        This mirrors the v4 kernel delete(): it marks the current active
        version as closed in both valid and transaction time and enqueues a
        DELETE event in the outbox for graph synchronization.
        
        Opera na tabela física (RegistroResource) para fechar a versão ativa.
        """
        now = datetime.now(UTC)

        async with await self.sql_driver.get_session() as session:
            async with session.begin():
                # Find the REAL active version in the database (tabela física)
                stmt = select(RegistroResource).where(
                    RegistroResource.rid == obj.rid,
                    RegistroResource.valid_to.is_(None),
                )
                result = await session.execute(stmt)
                active_row = result.scalars().first()

                if active_row is not None:
                    active_row.valid_to = now
                    active_row.tx_to = now
                    session.add(active_row)

                    # Outbox: delete event for graph sync
                    # Usa o nome da classe de domínio
                    outbox_event = SysOutbox(
                        rid=obj.rid,
                        operation="DELETE",
                        payload=json.dumps({"type": obj.__class__.__name__}),
                        status="PENDING",
                    )
                    session.add(outbox_event)

    async def get(
        self,
        model_cls: type[T],
        id: Any,
        agent: Any | None = None,
        **filters,
    ) -> T | None:
        """
        Get a single resource by ID.
        
        Args:
            model_cls: The model class
            id: The ID of the resource to get
            **filters: Additional filters to apply
            
        Returns:
            The resource, or None if not found
        """
        repo = self.get_repository(model_cls)
        async with await self.sql_driver.get_session() as session:
            if isinstance(id, str) and id.startswith("ri."):
                 resource = await repo.get(session, id=None, rid=id, **filters)
            else:
                 resource = await repo.get(session, id, **filters)

            if resource is None:
                return None
            for interceptor in self._interceptors:
                resource = await interceptor.on_read(resource, agent)
            return resource

    async def mget(
        self,
        model_cls: type[T],
        rids: list[str],
        agent: Any | None = None,
    ) -> list[T]:
        """Fetch multiple resources efficiently by RID.
        
        Mitigates N+1 query problems by using a single SQL query
        and applying governance interceptors per resource.
        """
        if not rids:
            return []

        repo = self.get_repository(model_cls)

        async with await self.sql_driver.get_session() as session:
            resources = await repo.mget(session, rids=rids)

            if not self._interceptors:
                return resources

            filtered: list[T] = []
            for resource in resources:
                processed = resource
                try:
                    for interceptor in self._interceptors:
                        processed = await interceptor.on_read(processed, agent)
                        if processed is None:
                            break
                except Exception:
                    processed = None

                if processed:
                    filtered.append(processed)

            return filtered

    async def list(
        self,
        model_cls: type[T],
        *,
        skip: int = 0,
        limit: int = 100,
        **filters,
    ) -> list[T]:
        """
        List resources with pagination and filtering.
        
        Args:
            model_cls: The model class
            skip: Number of items to skip
            limit: Maximum number of items to return
            **filters: Filters to apply
            
        Returns:
            A list of resources
        """
        repo = self.get_repository(model_cls)
        async with await self.sql_driver.get_session() as session:
            return await repo.list(session, skip=skip, limit=limit, **filters)

    async def link(
        self,
        src: RegistroResource,
        dst: RegistroResource,
        label: str,
        props: dict[str, Any] | None = None,
    ) -> None:
        """Create a semantic link between two resources in the graph store."""
        await self.graph_driver.create_edge(src.rid, dst.rid, label, props or {})

    async def unlink(
        self,
        src: RegistroResource,
        dst: RegistroResource,
        label: str,
    ) -> None:
        """Remove a semantic link between two resources in the graph store."""
        await self.graph_driver.delete_edge(src.rid, dst.rid, label)

    async def ingest_batch(
        self,
        table_name: str,
        data: Sequence[BaseModel],
    ) -> None:
        """Ingest a batch of Pydantic models into the analytics engine.

        Uses Politipo's PolyTransporter to build an Arrow table and forwards it
        to the analytics driver, then emits the global post_ingest signal.
        """
        if not data:
            return

        model_cls = type(data[0])
        transporter = PolyTransporter(model_cls)
        arrow_table = transporter.to_arrow(data)
        await self.analytics_driver.ingest_arrow(table_name, arrow_table)
        await self.post_ingest.emit(table_name)

    async def fork(self, new_db_url: str, new_kuzu_path: str) -> "UnifiedDataManager":
        """
        Create a fork of the current database state.
        
        Args:
            new_db_url: The URL for the new SQL database
            new_kuzu_path: The path for the new Kùzu database
            
        Returns:
            A new UnifiedDataManager instance with the forked state
        """
        # Create parent directory if it doesn't exist
        os.makedirs(os.path.dirname(new_kuzu_path), exist_ok=True)

        # Copy the Kùzu database
        if hasattr(self.graph_driver, "path") and os.path.exists(self.graph_driver.path):
            await asyncio.to_thread(shutil.copytree, self.graph_driver.path, new_kuzu_path)

        # Create new drivers
        new_sql = AsyncSQLAlchemyDriver(new_db_url)
        new_graph = KuzuActor(new_kuzu_path)
        new_analytics = DuckDBDriver()

        # Create and return the new manager
        return UnifiedDataManager(new_sql, new_graph, new_analytics)

    async def close(self) -> None:
        """
        Clean up resources.
        """
        self._running = False

        # Cancel background tasks
        if hasattr(self, "_outbox_processor"):
            self._outbox_processor.cancel()
            try:
                await self._outbox_processor
            except asyncio.CancelledError:
                pass

        # Stop monitor
        if self.monitor:
            await self.monitor.stop()

        # Stop instrumentation
        if self.instrumentation:
            await self.instrumentation.stop()

        # Close replication driver
        if self.replication_driver:
            await self.replication_driver.stop()

        # Close drivers
        if hasattr(self.graph_driver, "close"):
            await self.graph_driver.close()

        if hasattr(self.analytics_driver, "close"):
            # DuckDB close() is not async
            if asyncio.iscoroutinefunction(self.analytics_driver.close):
                await self.analytics_driver.close()
            else:
                self.analytics_driver.close()

    async def process_outbox(
        self,
        max_retries: int = 5,
        base_delay: float = 1.0,
        max_delay: float = 300.0,
        batch_size: int = 100,
    ) -> None:
        """Process pending outbox events with DLQ and Exponential Backoff.
        
        This method implements resilient event processing:
        - Exponential backoff: delay = base_delay * (2 ** retries)
        - Dead Letter Queue: events exceeding max_retries go to DLQ
        - Batch processing: process up to batch_size events per iteration
        
        Args:
            max_retries: Maximum retry attempts before DLQ
            base_delay: Initial delay in seconds (doubles each retry)
            max_delay: Maximum delay cap in seconds
            batch_size: Number of events to process per batch
        """
        if not self.replication_driver:
            logger.warning("[Outbox] No replication driver configured, skipping outbox processing")
            return

        async with await self.sql.get_session() as session:
            from sqlalchemy import and_, select

            now = datetime.now(UTC)

            # Select pending events ready for processing
            stmt = (
                select(SysOutbox)
                .where(
                    and_(
                        SysOutbox.status.in_(["PENDING", "RETRY"]),
                        # Only process if next_retry_at is None or in the past
                        (SysOutbox.next_retry_at.is_(None)) | (SysOutbox.next_retry_at <= now),
                    ),
                )
                .limit(batch_size)
            )

            result = await session.execute(stmt)
            events = result.scalars().all()

            if not events:
                return

            logger.info(f"[Outbox] Processing {len(events)} events")

            for event in events:
                try:
                    # Broadcast to peers
                    await self.replication_driver.broadcast(event)

                    # Mark as done
                    event.status = "DONE"
                    event.processed_at = now
                    event.error = None

                    logger.debug(f"[Outbox] Event {event.id} processed successfully")

                except Exception as e:
                    # Increment retry counter
                    event.retries += 1
                    event.error = str(e)

                    if event.retries >= max_retries:
                        # Move to Dead Letter Queue
                        event.status = "DEAD_LETTER"
                        event.processed_at = now
                        logger.error(
                            f"[Outbox] Event {event.id} moved to DLQ after {event.retries} retries: {e}",
                        )
                    else:
                        # Schedule retry with exponential backoff
                        event.status = "RETRY"
                        delay = min(base_delay * (2 ** event.retries), max_delay)
                        event.next_retry_at = now + timedelta(seconds=delay)
                        logger.warning(
                            f"[Outbox] Event {event.id} retry {event.retries}/{max_retries} "
                            f"scheduled in {delay:.1f}s: {e}",
                        )

            await session.commit()

    async def start_outbox_processor(
        self,
        interval: float = 5.0,
        **kwargs,
    ) -> None:
        """Start background task to process outbox events periodically.
        
        Args:
            interval: Seconds between processing runs
            **kwargs: Passed to process_outbox()
        """
        async def _outbox_loop():
            while self._running:
                try:
                    await self.process_outbox(**kwargs)
                    await asyncio.sleep(interval)
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    logger.error(f"[Outbox] Error in processor loop: {e}")
                    await asyncio.sleep(interval)

        self._outbox_processor = asyncio.create_task(_outbox_loop())
        logger.info(f"[Outbox] Background processor started (interval={interval}s)")

# ==============================================================================
# FACTORY FUNCTIONS
# ==============================================================================
# Note: Context management (set_kernel, get_kernel, clear_kernel) is defined
# at the top of this file in the CONTEXT MANAGEMENT section.
# ==============================================================================


async def connect(
    url: str = "sqlite+aiosqlite:///malha.db",
    kuzu_path: str = "data/kuzu",
    reset: bool = False,
    sql_driver: SQLDriver | None = None,
    graph_driver: GraphDriver | None = None,
    analytics_driver: AnalyticsDriver | None = None,
    replication_driver: ReplicationDriver | None = None,
    stream_driver: StreamDriver | None = None,
    compute_driver: ComputeDriver | None = None,
    enable_monitoring: bool = True,
    node_id: str = "local",
    kuzu_config: KuzuConfig | None = None,
    auto_boot: bool = True,
    auto_cleanup: bool = False,
    cleanup_retention_days: int = 30,
) -> UnifiedDataManager:
    """Create and register a new UnifiedDataManager instance.

    This is the main entry point for creating a Malha kernel. It initializes
    all drivers and sets the kernel in the global context for use by domain objects.

    Args:
        url: SQL database URL (default: SQLite file)
        kuzu_path: Path to Kùzu graph database directory
        reset: Whether to reset databases on startup (useful for testing)
        sql_driver: Optional custom SQL driver (for testing/advanced scenarios)
        graph_driver: Optional custom graph driver
        analytics_driver: Optional custom analytics driver
        replication_driver: Optional P2P replication driver (e.g., SynapseDriver)
        stream_driver: Optional stream driver for data lake writes
        compute_driver: Optional compute driver for script execution
        enable_monitoring: Enable KernelMonitor for observability
        node_id: Node identifier for distributed deployments
        kuzu_config: Optional KuzuConfig for graph database tuning
                    (buffer pool size, threads, compression, etc.)
        auto_boot: Run bootloader to recover WAL and zombie processes (default: True)
        auto_cleanup: Enable scheduled daily cleanup (default: False)
        cleanup_retention_days: Days to retain data before cleanup (default: 30)

    Returns:
        Configured UnifiedDataManager instance (also set in global context)

    Example:
        ```python
        from malha import connect, get_kernel, KuzuConfig

        async def main():
            # Create and connect kernel with custom Kùzu config
            kernel = await connect(
                url="sqlite+aiosqlite:///app.db",
                kuzu_path="data/graph",
                reset=True,  # Clean start for testing
                kuzu_config=KuzuConfig(
                    buffer_pool_size=512 * 1024**2,  # 512MB
                    max_num_threads=4,
                ),
                auto_boot=True,  # Recover from crash
                auto_cleanup=True,  # Enable daily cleanup
            )

            # Kernel is now available via get_kernel()
            assert get_kernel() is kernel

            # Use the kernel
            user = User(name="Alice")
            await kernel.save_versioned(user)

            # Cleanup
            await kernel.close()
        ```
    """
    # SQL driver
    if sql_driver is None:
        # Optional reset for SQLite-style URLs
        if reset and "sqlite" in url and ":memory:" not in url:
            local_db = url.split("///")[-1]
            if os.path.exists(local_db):
                os.remove(local_db)

        sql = AsyncSQLAlchemyDriver(url)
        await sql.create_tables()
    else:
        sql = sql_driver

    # Graph driver (Kùzu)
    if graph_driver is None:
        if reset and os.path.exists(kuzu_path):
            shutil.rmtree(kuzu_path, ignore_errors=True)
        graph = KuzuActor(kuzu_path, config=kuzu_config)
    else:
        graph = graph_driver

    # Analytics driver (DuckDB)
    if analytics_driver is None:
        sqlite_path = None
        if "sqlite" in url and ":memory:" not in url:
            sqlite_path = url.split("///")[-1]
        analytics = DuckDBDriver(sqlite_path)
    else:
        analytics = analytics_driver

    # Initialize replication driver if provided
    if replication_driver:
        await replication_driver.start()

    manager = UnifiedDataManager(
        sql,
        graph,
        analytics,
        replication_driver,
        enable_monitoring=enable_monitoring,
        node_id=node_id,
    )

    # Attach optional drivers to manager for unified access
    manager.stream = stream_driver
    manager.compute = compute_driver

    # Start instrumentation if enabled
    if manager.instrumentation:
        await manager.instrumentation.start()

    # Set in global context (Fat Kernel pattern)
    # This enables domain objects to use get_kernel() transparently
    set_kernel(manager)

    # Run bootloader for crash recovery (unless reset=True, which means fresh start)
    if auto_boot and not reset:
        try:
            from .boot import Bootloader
            bootloader = Bootloader(manager)
            boot_result = await bootloader.run()
            logger.info(f"[Kernel] Boot complete: {boot_result}")
        except Exception as e:
            logger.warning(f"[Kernel] Boot failed (non-fatal): {e}")

    # Schedule automatic cleanup if enabled
    if auto_cleanup:
        try:
            from .maintenance import Janitor
            janitor = Janitor(manager, retention_days=cleanup_retention_days)
            manager._janitor = janitor  # Store reference for cleanup
            await janitor.schedule_daily(hour=3, minute=0)  # Run at 3 AM
            logger.info(f"[Kernel] Daily cleanup scheduled (retention={cleanup_retention_days} days)")
        except Exception as e:
            logger.warning(f"[Kernel] Failed to schedule cleanup: {e}")

    return manager


# Backwards-compatible alias
create_manager = connect
