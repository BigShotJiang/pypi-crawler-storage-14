## 1.0.0-dev.1 (2025-11-23)

### Bug Fixes

* add missing exports to __init__.py for test compatibility ([92d91ac](https://github.com/sean2077/gopro-sdk-py/commit/92d91ace447e23444ea4bed58fa9923923a11acf))
* export missing symbols and skip hardware tests in CI ([59e013b](https://github.com/sean2077/gopro-sdk-py/commit/59e013be4e0a00092569bf1ec098b21ca78e6697))

### Documentation

* enhance with Material theme features ([d84a58c](https://github.com/sean2077/gopro-sdk-py/commit/d84a58c1df14dad51875dfe727aaa9842476fcdf))
