# Contributing

--8<-- "CONTRIBUTING.md"

---

For detailed technical information about development setup, testing, and architecture, see the [Development Guide](development.md).
