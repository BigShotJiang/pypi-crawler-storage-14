"""Version information for maid-runner package."""

__version__ = "0.1.2"
