"""Main Entry Point for the Images to PDF MCP Server."""

from .pdf_converter import convert_images_to_pdf

from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, ErrorData
from mcp import McpError
import gc
import sys
from typing import Union, Any, Optional


mcp = FastMCP("images-to-pdf-mcp")


def ok(msg: str) -> Union[TextContent, list]:
    """Create a Success Response."""
    return TextContent(type="text", text=msg)


def error(msg: str, data: Any = None) -> None:
    """Raise an Error - FastMCP will handle the error propagation."""
    raise McpError(ErrorData(code=-1, message=msg, data=data))


@mcp.tool(
    "convert_images_to_pdf",
    description=(
        "将多张图片合并为单个PDF文档，每张图片占一页。支持丰富的自定义选项:\n"
        "- 页面设置: 多种尺寸(A3/A4/A5, Letter, 16:9等)、DPI(72-1200)\n"
        "- 排序方式: 字母顺序、创建时间、修改时间\n"
        "- 布局控制: 自动适配页面、居中显示\n"
        "- 背景颜色: 20+预设颜色(white/gray/black等)\n\n"
        "参数:\n"
        "- input_files (list, 必需): 图片文件路径列表\n"
        "- output_dir (str, 可选): 输出目录，默认为第一个文件所在目录\n"
        "- file_name (str, 可选): 自定义文件名(不含扩展名)，默认自动命名\n"
        "- sort_order (str, 可选): 排序方式 alphabetical/creation_time/modification_time，默认alphabetical\n"
        "- page_size (str, 可选): 页面尺寸 A3/A4/A5/B3/B4/B5/Letter/Legal/Executive/Tabloid/16:9/4:3/Square，默认A4\n"
        "- dpi (int, 可选): PDF分辨率72-1200，默认300\n"
        "- fit_to_page (bool, 可选): 是否缩放图片以适应页面，默认True\n"
        "- center_image (bool, 可选): 是否居中显示图片，默认True\n"
        "- background_color (str, 可选): 背景色 white/gray/black/red/blue/green等，默认white"
    )
)
def convert_images_to_pdf_tool(
    input_files: list,
    output_dir: Optional[str] = None,
    file_name: Optional[str] = None,
    sort_order: str = "alphabetical",
    page_size: str = "A4",
    dpi: int = 300,
    fit_to_page: bool = True,
    center_image: bool = True,
    background_color: str = "white"
) -> TextContent:
    """Combine Multiple Images into PDF."""
    try:
        # First validate inputs before processing
        if not input_files or not isinstance(input_files, list):
            raise McpError(ErrorData(
                code=-1,
                message="Failed to Create PDF: input_files must be a non-empty list of file paths",
                data={"input_files": input_files, "page_size": page_size, "dpi": dpi}
            ))

        # Capture stdout/stderr to collect warnings
        import io
        from contextlib import redirect_stdout, redirect_stderr

        output_buffer = io.StringIO()
        with redirect_stdout(output_buffer), redirect_stderr(output_buffer):
            result = convert_images_to_pdf(
                input_files, output_dir, file_name, sort_order, page_size,
                dpi, fit_to_page, center_image, background_color
            )

        # Check if there were warnings
        output_text = output_buffer.getvalue()
        warnings = []
        if "(WARNING)" in output_text:
            warnings = [line.strip() for line in output_text.split('\n') if "(WARNING)" in line]

        if warnings:
            return ok(f"Successfully created PDF: {result}\n\n(WARNING) Warnings:\n" + "\n".join(warnings))
        else:
            return ok(f"Successfully created PDF: {result}")

    except McpError:
        raise
    except Exception as e:
        raise McpError(ErrorData(
            code=-1,
            message=f"Failed to Create PDF: {str(e)}",
            data={
                "input_files": input_files,
                "page_size": page_size,
                "dpi": dpi
            }
        ))
    finally:
        gc.collect()


def main():
    """Run the MCP Server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
