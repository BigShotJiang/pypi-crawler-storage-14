# 多图转 PDF MCP

一个专门用于将多张图片合并为 PDF 文档的模型上下文协议（MCP）服务器。

## 功能特性

- **PDF 文档生成**：将多张图片合并为单个 PDF 文件
- **灵活的页面设置**：
  - 多种页面尺寸（A3/A4/A5, Letter, 16:9 等）
  - DPI 设置（72-1200）
  - 自定义背景色（20+ 预设颜色）
- **图片排序选项**：
  - 字母数字顺序
  - 创建时间
  - 修改时间
- **布局控制**：
  - 图片自动适配页面
  - 居中显示
  - 保持宽高比
- **智能命名**：自动文件命名，防止重复

## 安装

### 从 PyPI 安装
```bash
pip install images-to-pdf-mcp
```

### 开发安装
```bash
git clone https://github.com/mcpcn/images-to-pdf-mcp
cd images-to-pdf-mcp
pip install -e .
```

## 配置

### MCP 配置示例

```json
{
  "mcpServers": {
    "Images to PDF MCP": {
      "command": "uvx",
      "args": ["images-to-pdf-mcp"],
      "env": {}
    }
  }
}
```

## 可用工具

### convert_images_to_pdf
将多张图片合并为 PDF 文档。

**参数**：
- `input_files` (list, 必需): 图片文件路径列表
- `output_dir` (str, 可选): 输出目录路径，默认为第一个文件所在目录
- `file_name` (str, 可选): 自定义文件名，默认自动命名
- `sort_order` (str, 可选): 排序方式，可选 'alphabetical'(字母)、'creation_time'(创建时间)、'modification_time'(修改时间)，默认 'alphabetical'
- `page_size` (str, 可选): 页面尺寸，支持 A3/A4/A5, B3/B4/B5, Letter/Legal/Executive/Tabloid, 16:9/4:3/Square，默认 'A4'
- `dpi` (int, 可选): PDF 分辨率，范围 72-1200，默认 300
- `fit_to_page` (bool, 可选): 是否缩放图片以适应页面，默认 True
- `center_image` (bool, 可选): 是否居中显示图片，默认 True
- `background_color` (str, 可选): 背景色，支持 white/gray/black 等 20+ 颜色，默认 'white'

## 支持的格式

### 输入格式
- JPEG (.jpg, .jpeg)
- PNG (.png)
- BMP (.bmp)
- TIFF (.tif, .tiff)
- WEBP (.webp)
- HEIC/HEIF (.heic, .heif)
- AVIF (.avif)

### 输出格式
- PDF (.pdf)

## 使用方法

### 命令行
```bash
images-to-pdf-mcp
```

### 作为 MCP 服务器
服务器通过标准输入输出运行，可以与任何 MCP 兼容的客户端集成。

## 系统要求

- Python 3.10+
- Pillow (PIL) 用于图片处理
- PyMuPDF 用于 PDF 生成

## 许可证

本项目采用 MIT 许可证 - 详情请参阅 [LICENSE](LICENSE) 文件。
