##########
 metadata
##########

.. automodule:: anemoi.inference.metadata
   :members:
   :no-undoc-members:
   :show-inheritance:
