############
 checkpoint
############

.. automodule:: anemoi.inference.checkpoint
   :members:
   :no-undoc-members:
   :show-inheritance:
