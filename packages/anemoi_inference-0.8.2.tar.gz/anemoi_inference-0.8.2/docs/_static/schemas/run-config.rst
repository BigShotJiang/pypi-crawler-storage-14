.. https://autodoc-pydantic.readthedocs.io

.. _run-config:

##################
Run configuration
##################

.. autopydantic_model:: anemoi.inference.config.Configuration
