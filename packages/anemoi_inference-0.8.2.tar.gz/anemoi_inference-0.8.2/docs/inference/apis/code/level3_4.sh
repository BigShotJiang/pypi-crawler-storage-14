anememoi-inference run lam.yaml \
    "input.dataset.cutout.0.dataset=./analysis_20240131_00.zarr" \
    "input.dataset.cutout.1.dataset=./lbc_20240131_00.zarr"
