
from setuptools import setup

setup(
    name="arycx",
    version="0.0.1.post1",
    description="Alias package for ACX framework.",
    packages=["arycx"],
    install_requires=["acx"],
)
