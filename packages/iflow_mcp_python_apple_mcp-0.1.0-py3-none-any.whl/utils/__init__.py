"""
Utility modules for the Apple MCP server.

This package contains modules for interacting with various Apple applications
on macOS, using AppleScript and other system interfaces.
"""