"""PrintAudit package bootstrap."""

from .cli import main

__all__ = [
    "cli",
    "config",
    "parser",
    "main",
]
