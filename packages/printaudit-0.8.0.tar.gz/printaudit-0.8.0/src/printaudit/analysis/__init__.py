"""Analysis aggregators for PrintAudit."""

from .aggregator import AnalysisReport, UsageAggregator

__all__ = ["AnalysisReport", "UsageAggregator"]
