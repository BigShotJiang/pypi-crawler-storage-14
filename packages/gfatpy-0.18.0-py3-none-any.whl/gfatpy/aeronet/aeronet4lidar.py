import pandas as pd

from gfatpy.aeronet.utils import add_interpol_aod, AERONET_INFO


def aod_lidar_wavelengths_all(header: dict, df: pd.DataFrame) -> pd.DataFrame:
    """Adds the AOD at 355, 532 and 1064 nm to the AERONET dataframe.

    Args:

        - header (dict): AERONET header.
        - df (pd.DataFrame): AERONET dataframe.

    Returns:
    
        - pd.DataFrame: AERONET dataframe.
    """

    df = add_interpol_aod( header, df, 355, 440, None)
    df = add_interpol_aod( header, df, 532, 440, 675)
    df = add_interpol_aod( header, df, 1064, None, 1020)
    return df
