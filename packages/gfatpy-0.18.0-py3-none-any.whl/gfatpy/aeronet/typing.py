import numpy as np
import pandas as pd
from loguru import logger

from gfatpy.aeronet import utils


def lee_typing(df,     
) -> pd.DataFrame:
    """Typing according to Lee's method with *.all AERONET file.

    Args:

        - fmf_550 (np.ndarray): fine mode fraction at 550nm.
        - ssa_440 (np.ndarray): single scattering albedo at 440nm.

    Raises:

        - ValueError: Length of inputs must be identical.

    Returns:

        - df (pd.DataFrame): DataFrame with new column "lee_typing". Aerosol types.

    References:
        - Lee et al., 2010.
    """
    fine440 = df["AOD_Extinction-Fine[440nm]"]
    total440 = df["AOD_Extinction-Total[440nm]"]
    
    fmf = utils.calculate_fine_mode_fraction(fine440, total440)
    ssa = df["Single_Scattering_Albedo[440nm]"].values.astype(float)

    # Columna final de clasificación
    df['lee_typing'] = 'Unclassified'

    # 1) FMF < 0.4
    mask_low = fmf < 0.4
    df.loc[mask_low & (ssa <= 0.95), 'lee_typing'] = 'DUST'

    # 2) 0.4 ≤ FMF ≤ 0.6 → Mixture
    mask_mid = (fmf >= 0.4) & (fmf <= 0.6)
    df.loc[mask_mid, 'lee_typing'] = 'MIXTURE'

    # 3) FMF > 0.6
    mask_high = fmf > 0.6

    # 3a) NA (no absorbente)
    df.loc[mask_high & (ssa > 0.95), 'lee_typing'] = 'NA'

    # 3b) BC con subtipos SA/MA/HA
    mask_bc = mask_high & (ssa <= 0.95)

    df.loc[mask_bc & (ssa > 0.90), 'lee_typing'] = 'SA'  # slightly absorbing
    df.loc[mask_bc & (ssa > 0.85) & (ssa <= 0.90), 'lee_typing'] = 'MA'  # moderately absorbing
    df.loc[mask_bc & (ssa <= 0.85), 'lee_typing'] = 'HA'  # highly absorbing
    return df

def angstrom_exponent_typing(
    df: pd.DataFrame,    
    ae_thresholds: tuple[float, float] = (0.2, 0.6),
) -> pd.DataFrame:
    """Typing according to the mode predominance.

    Args:

        - ae_440_870 (np.ndarray): Angstrom exponent between 440 and 870 nm.

    Returns:

        - df (pd.DataFrame): DataFrame with new column "angstrong_typing". Aerosol types.
    """

    ae_440_870 = df[
        "Angstrom_Exponent_440-870nm_from_Coincident_Input_AOD"].values.astype(float)
    
    try:
        n = len(ae_440_870)
        mode_predominance = np.array(["UNKNOWN"] * n)
        aemin_threshold, aemax_threshold = ae_thresholds

        # COARSE
        coarse_condition = ae_440_870 < aemin_threshold
        mode_predominance = np.where(coarse_condition, "COARSE", mode_predominance)

        # BIMODAL        
        mixture_condition = np.logical_and(
            ae_440_870 >= aemin_threshold, ae_440_870 <= aemax_threshold
        )
        mode_predominance = np.where(mixture_condition, "BIMODAL", mode_predominance)

        # FINE        
        fine_condition = ae_440_870 > aemax_threshold
        mode_predominance = np.where(fine_condition, "FINE", mode_predominance)        
    except Exception as e:
        logger.error("Mode Predominance not Calculated")
    
    df['angstrong_typing'] = mode_predominance

    return df

def shin_typing(df: pd.DataFrame, despo_thresholds: tuple[float, float] = (0.02, 0.30)) -> pd.DataFrame:
    """Typing according to Shin's method.
    Args:

        - df (pd.DataFrame): DataFrame load from aeronet file.
    Returns:

        - df (pd.DataFrame): DataFrame with new columns "shin_typing" and "shin_typing_PA". Aerosol types.
    """

    pldr_col = 'Depolarization_Ratio[1020nm]'
    ssa_col  = 'Single_Scattering_Albedo[1020nm]'

    delta_p    = df[pldr_col].astype(float)
    delta_nd_p, delta_d_p = despo_thresholds

    df['Rd_1020'] = (
        ((delta_p - delta_nd_p) * (1 + delta_d_p))
        / ((delta_d_p - delta_nd_p) * (1 + delta_p))
    )

    Rd   = df['Rd_1020']

    conditions_type = [
        Rd < 0.17,
        (Rd >= 0.17) & (Rd < 0.53),
        (Rd >= 0.53) & (Rd <= 0.89),
        (Rd > 0.89),
    ]

    choices_type = [
        'PA',
        'PDM',
        'DDM',
        'PD',
    ]

    df['shin_typing'] = np.select(
        conditions_type, choices_type, default='Unclassified'
    )

    #Subclassification based on SSA
    ssa = df[ssa_col].astype(float)
    conds_ssa = [
        (Rd >= 0.17),                                   # Not PA
        (Rd < 0.17) & (ssa > 0.95),                             # NA
        (Rd < 0.17) & (ssa > 0.90) & (ssa <= 0.95),           # WA
        (Rd < 0.17) & (ssa >= 0.85) & (ssa <= 0.90),          # MA
        (Rd < 0.17) & (ssa < 0.85),                             # SA
    ]

    choices_ssa = [None, 'NA', 'WA', 'MA', 'SA']

    df['shin_typing_PA'] = np.select(
        conds_ssa, choices_ssa, default='SSA_missing'
    )

    return df