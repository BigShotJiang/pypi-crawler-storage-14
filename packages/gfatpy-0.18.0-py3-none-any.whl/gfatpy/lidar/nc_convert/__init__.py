from pathlib import Path

CONFIGS_DIR = Path(__file__).parent / "configs"
