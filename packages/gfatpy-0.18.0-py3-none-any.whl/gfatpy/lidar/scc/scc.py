#TODO: automatization of the SCC submission process using a json configuration file
from pathlib import Path

def scc_submit(config_file: Path):
    pass