import os
from pathlib import Path
import sys
import glob
import json
import numpy as np
import xarray as xr
import datetime as dt
from loguru import logger
from multiprocessing import Pool

from atmospheric_lidar.scripts import licel2scc

from gfatpy.utils.io import read_yaml, find_nearest_filepath

"""
Functions for deriving SCC info directly from measurement folder/files
(Currently Not Used)
"""

def get_scc_code_from_measurement_folder(meas_folder, campaign):
    assert isinstance(meas_folder, str), "meas_folder must be String Type"
    assert isinstance(campaign, str), "campaign must be String Type"

    if campaign is not None:
        campaign_info, campaign_scc_fn = get_campaign_info(campaign)
        if campaign_info is None:
            logger.warning(f"No campaign info found for campaign: {campaign}")
            return None
        scc_cfg = campaign_info["scc_cfg"]
        scc_codes = campaign_info["scc_codes"]
        CustomLidarMeasurement = licel2scc.create_custom_class(
            campaign_scc_fn, use_id_as_name=True
        )
        rm_files = glob.glob(os.path.join(meas_folder, "R*"))
        if len(rm_files) > 0:
            rm_file = [rm_files[0]]
            measurement = CustomLidarMeasurement(rm_file)
            channels_in_rm = list(measurement.channels.keys())
            sccs = len(scc_codes)
            exist_scc = [False] * sccs
            channels_in_scc = [0] * sccs
            for i, i_scc in enumerate(scc_cfg):
                exist_scc[i] = all(
                    j in channels_in_rm for j in scc_cfg[i_scc]["channels"]
                )
                channels_in_scc[i] = len(scc_cfg[i_scc]["channels"])
            scc_code = [b for a, b in zip(exist_scc, scc_codes) if a]
            if len(scc_code) == 0:
                scc_code = None
            elif len(scc_code) == 1:
                scc_code = int(scc_code[0])
            elif len(scc_code) == 2:
                max_chan = channels_in_scc == np.max(channels_in_scc)
                scc_code = [b for a, b in zip(max_chan, scc_codes) if a]
                scc_code = int(scc_code[0])
        else:
            scc_code = None
    else:
        scc_code = None
    return scc_code

def get_campaign_info(campaign, scc_config_directory=None):
    try:
        if scc_config_directory is None:
            scc_config_directory = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), "scc_configFiles"
            )
        if campaign == "covid":
            campaign_scc_fn = find_nearest_filepath("info.yml", scc_config_directory)
            campaign_info = read_yaml(campaign_scc_fn)
            campaign_info["scc_codes"] = list(campaign_info["scc_cfg"].keys())
        else:
            campaign_info = None
            campaign_scc_fn = None
    except Exception as e:
        logger.warning(f"ERROR leyendo info.yml: {e}")
        campaign_info = None
        campaign_scc_fn = None

    return campaign_info, campaign_scc_fn

class TimeoutException(Exception):
    pass

def sigalrm_handler(signum, frame):
    raise TimeoutException()

def date_from_filename(filelist):
    datelist = []
    if filelist:
        for _file in filelist:
            body = _file.split(".")[0]
            tail = _file.split(".")[1]
            year = int(body[-7:-5]) + 2000
            month = body[-5:-4]
            try:
                month = int(month)
            except Exception as e:
                if month == "A":
                    month = 10
                elif month == "B":
                    month = 11
                elif month == "C":
                    month = 12
            day = int(body[-4:-2])
            hour = int(body[-2:])
            minute = int(tail[0:2])
            cdate = dt.datetime(year, month, day, hour, minute)
            datelist.append(cdate)
    else:
        print("Filelist is empty.")
        datelist = None
    return datelist

def getTP(filepath):
    if os.path.isfile(filepath):
        with open(filepath, mode="rb") as f:
            filename = f.readline().decode("utf-8").rstrip()[1:]
            second_line = f.readline().decode("utf-8")
            f.close()
        second_line_list = second_line.split(" ")
        if len(second_line_list) == 14:
            temperature = float(second_line_list[12].rstrip())
            pressure = float(second_line_list[13].rstrip())
        else:
            logger.warning("Cannot find temperature, pressure values. set to None")
            temperature = None
            pressure = None
    else:
        logger.warning("File not found.")
        temperature = None
        pressure = None
    return temperature, pressure

def apply_pc_peak_correction(filelist, scc_pc_channels):
    outputlist = list()
    threshold = 1000

    if np.logical_and(len(filelist) > 0, len(scc_pc_channels) > 0):
        for file_ in filelist:
            try:
                lxarray = xr.open_dataset(file_)
                output_directory = os.path.dirname(file_)
                filename = os.path.basename(file_)
                for channel_ in scc_pc_channels:
                    idx_channel = np.where(lxarray.channel_ID == channel_)[0]
                    if idx_channel.size > 0:
                        profile_raw = lxarray.Raw_Lidar_Data[:, idx_channel, :].values
                        shape_raw = profile_raw.shape
                        profile = np.squeeze(profile_raw)
                        new_profile = mulhacen_pc_peak_correction(profile)
                        lxarray.Raw_Lidar_Data[:, idx_channel, :] = np.reshape(
                            new_profile.astype("int"), shape_raw
                        )

                        profile_raw = lxarray.Background_Profile[
                            :, idx_channel, :
                        ].values
                        shape_raw = profile_raw.shape
                        profile = np.squeeze(profile_raw)
                        new_profile = mulhacen_pc_peak_correction(profile)
                        lxarray.Background_Profile[:, idx_channel, :] = np.reshape(
                            new_profile.astype("int"), shape_raw
                        )

                auxfilepath = os.path.join(output_directory, "aux")
                lxarray.to_netcdf(path=auxfilepath, mode="w")
                os.remove(file_)
                os.rename(auxfilepath, file_)
            except Exception as e:
                logger.warning(str(e))
                logger.warning("PC peak correction not performed")
            outputlist.append(file_)
    else:
        print("Files not found.")
    return outputlist

def get_info_from_measurement_file(mea_fn, scc_config_fn):
    CustomLidarMeasurement = licel2scc.create_custom_class(
        scc_config_fn, use_id_as_name=True
    )
    mea = CustomLidarMeasurement([mea_fn])
    time_ini_i = mea.info["start_time"].replace(tzinfo=None)
    time_end_i = mea.info["stop_time"].replace(tzinfo=None)
    channels_in_rm = mea.channels
    del CustomLidarMeasurement, mea
    return time_ini_i, time_end_i, channels_in_rm

def get_info_from_measurement_files(meas_files, scc_config_fn):
    try:
        with Pool(os.cpu_count()) as pool:
            x = [
                (
                    mea_fn,
                    scc_config_fn,
                )
                for mea_fn in meas_files
            ]
            res = np.array(pool.starmap(get_info_from_measurement_file, x))
        times_ini = [x[0] for x in res]
        times_end = [x[1] for x in res]
        channels_in_rm = [x[2] for x in res][0]
        time_start = times_ini[0].replace(second=0)
        time_end = times_end[-1] + dt.timedelta(minutes=1)
        time_end = time_end.replace(second=0)
    except Exception as e:
        logger.error(str(e))
        logger.error("Measurement files not read")
        return

    return times_ini, times_end, time_start, time_end, channels_in_rm

def get_scc_config(scc_config_fn):
    """
    Parameters
    ----------
    scc_config_fn: str
        scc configuration file (.py or .yml)

    Returns
    -------
    scc_config_dict: dict
        Dictionary with scc configuration info from scc config file
    """
    scc_config_dict = None
    try:
        # Si es YAML, lo leemos como diccionario
        if scc_config_fn.endswith('.yml') or scc_config_fn.endswith('.yaml'):
            scc_config_dict = read_yaml(scc_config_fn)
            if "general_parameters" not in scc_config_dict and "general_parameters" in scc_config_dict.get("scc_cfg", {}):
                scc_config_dict["general_parameters"] = scc_config_dict["scc_cfg"]["general_parameters"]
            if "channel_parameters" not in scc_config_dict and "channel_parameters" in scc_config_dict.get("scc_cfg", {}):
                scc_config_dict["channel_parameters"] = scc_config_dict["scc_cfg"]["channel_parameters"]
            if "channel_parameters" in scc_config_dict:
                scc_config_dict["channels"] = list(scc_config_dict["channel_parameters"].keys())
        else:
            logger.warning(f"Unsupported config file format: {scc_config_fn}")
    except Exception as e:
        logger.warning(f"ERROR importing scc parameters from {scc_config_fn}: {e}")
        scc_config_dict = None

    return scc_config_dict

def get_campaign_config(
    campaign_cfg_fn=None,
    scc_config_id=None,
    hour_ini=None,
    hour_end=None,
    hour_resolution=None,
    timestamp=0,
    slot_name_type=0,
):
    if campaign_cfg_fn is None:
        campaign_cfg_fn = "GFATserver"

    if campaign_cfg_fn == "GFATserver":
        scc_campaign_cfg = {
            "name": "operational",
            "lidar_config": {
                "operational": {
                    "scc": scc_config_id,
                    "hour_ini": hour_ini,
                    "hour_end": hour_end,
                    "hour_res": hour_resolution,
                    "timestamp": timestamp,
                    "slot_name_type": slot_name_type,
                }
            },
        }
    else:
        if os.path.isfile(campaign_cfg_fn):
            with open(campaign_cfg_fn) as f:
                scc_campaign_cfg = json.load(f)
        else:
            logger.error(
                "Campaign File %s Does Not Exist. Exit program" % campaign_cfg_fn
            )
            sys.exit()
    return scc_campaign_cfg

def check_scc_output_inlocal(scc_output_slot_dn):
    expected_dns = [
        "hirelpp",
        "cloudmask",
        "scc_preprocessed",
        "scc_optical",
        "scc_plots",
    ]
    exist_dns = [
        os.path.isdir(os.path.join(scc_output_slot_dn, i)) for i in expected_dns
    ]
    if not all(exist_dns):
        scc_output_inlocal = False
    else:
        if len(glob.glob(os.path.join(scc_output_slot_dn, "scc_optical"))) == 0:
            scc_output_inlocal = False
        if len(glob.glob(os.path.join(scc_output_slot_dn, "scc_plots"))) == 0:
            scc_output_inlocal = False
        else:
            scc_output_inlocal = True

    return scc_output_inlocal