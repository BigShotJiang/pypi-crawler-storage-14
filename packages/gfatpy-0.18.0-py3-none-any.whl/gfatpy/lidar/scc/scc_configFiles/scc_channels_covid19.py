#scc_cfg = {
#        "525": {'mode': 'day', 'channels': ["BT0", "BT1", "BT2", "BT3", "BC4"]},
#        "435": {'mode': 'ngt', 'channels': ["BT0", "BT1", "BT2", "BT3", "BC3", "BC4"]}
#        }
scc_cfg = {
        "555": {'mode': 'day', 'channels': ["BT0", "BT1", "BT2", "BT3", "BC0", "BC1", "BC2", "BC4"]},
        }
        #"555": {'mode': 'ngt', 'channels': ["BT0", "BT1", "BT2", "BT3", "BC0", "BC1", "BC2", "BC4"]},
