from pathlib import Path
from gfatpy.utils.io import read_yaml

MAX_EXEC_TIME = int(1200)  # 3600

__all__ = ["MAX_EXEC_TIME"]
