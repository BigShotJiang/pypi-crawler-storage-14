#!/usr/bin/env python3

import sys
from mpremote import main

sys.exit(main.main())
