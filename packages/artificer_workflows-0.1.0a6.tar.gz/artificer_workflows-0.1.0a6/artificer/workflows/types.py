from enum import Enum


class WorkflowStatus(Enum):
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    COMPLETED = "complete"
    FAILED = "failed"


class StepStatus(Enum):
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"
