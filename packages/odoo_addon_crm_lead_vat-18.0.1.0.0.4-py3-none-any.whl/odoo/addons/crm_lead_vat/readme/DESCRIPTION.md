This module was written to extend the functionality of CRM leads to
support setting the VAT identification number
(<https://en.wikipedia.org/wiki/VAT_identification_number>).
