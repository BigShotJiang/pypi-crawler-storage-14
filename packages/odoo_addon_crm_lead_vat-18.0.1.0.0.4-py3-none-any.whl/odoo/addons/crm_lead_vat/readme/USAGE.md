To use this module, you need to:

- Go to *CRM \> Leads*.
- Open a lead.
- You will see the new field.
- If you change vat in partner, it change in lead.
- If you change vat in lead, a warning will show informing you that if
  you save, vat change in partner.
