State
=====

Header file: ``<libs/superdrops/state.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/state.hpp>`_

.. doxygenstruct:: State
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
