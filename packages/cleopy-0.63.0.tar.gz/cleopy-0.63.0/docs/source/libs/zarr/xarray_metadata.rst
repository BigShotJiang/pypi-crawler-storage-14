Xarray Metadata
===============

Header file: ``<libs/zarr/xarray_metadata.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/zarr/xarray_metadata.hpp>`_

.. doxygenfunction:: xarray_metadata(const std::string_view units, const double scale_factor, const std::vector<std::string>& dimnames)
   :project: zarr

.. doxygenfunction:: xarray_metadata(const std::string_view units, const double scale_factor, const std::vector<std::string>& dimnames, const std::string_view sampledimname)
   :project: zarr
