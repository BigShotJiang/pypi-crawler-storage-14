Nsupers Observer
================

Header file: ``<libs/observers/nsupers_observer.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/nsupers_observer.hpp>`_

.. doxygenstruct:: NsupersFunc
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenfunction:: CollectNsupers
   :project: observers

.. doxygenfunction:: NsupersObserver
   :project: observers
