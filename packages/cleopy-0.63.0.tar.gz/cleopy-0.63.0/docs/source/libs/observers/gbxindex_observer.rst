Gbxindex Observer
=================

Header file: ``<libs/observers/gbxindex_observer.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/gbxindex_observer.hpp>`_

.. doxygenstruct:: GbxIndexFunctor
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenclass:: GbxindexObserver
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
