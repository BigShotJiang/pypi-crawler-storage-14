Collect Data For Dataset
========================

Header file: ``<libs/observers/collect_data_for_dataset.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/collect_data_for_dataset.hpp>`_

.. doxygenconcept:: CollectDataForDataset
   :project: observers

.. doxygenstruct:: CombinedCollectDataForDataset
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenstruct:: NullCollectDataForDataset
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
