State Observer
==============

Header file: ``<libs/observers/state_observer.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/state_observer.hpp>`_

.. doxygenfunction:: StateObserver
   :project: observers
