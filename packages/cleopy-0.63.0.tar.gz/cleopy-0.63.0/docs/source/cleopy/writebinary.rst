WRITEBINARY
===========

.. automodule:: cleopy.writebinary
  :members:
