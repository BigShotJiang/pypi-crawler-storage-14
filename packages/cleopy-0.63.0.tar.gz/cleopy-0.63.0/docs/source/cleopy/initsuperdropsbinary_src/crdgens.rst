CRDGENS
=======

.. automodule:: cleopy.initsuperdropsbinary_src.crdgens
   :members:
