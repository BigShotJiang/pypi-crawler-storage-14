PYSETUPTXT
==========

.. automodule:: cleopy.sdmout_src.pysetuptxt
  :members:
