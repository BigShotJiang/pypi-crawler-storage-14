"""Video Extract Frames MCP - Extract frames from video based on scene changes."""

__version__ = "0.1.0"