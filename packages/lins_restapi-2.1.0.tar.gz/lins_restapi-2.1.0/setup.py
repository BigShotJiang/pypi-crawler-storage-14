#!/usr/bin/env python

import os
import sys
from distutils.core import setup
from setuptools import find_packages
from lins_restapi import __version__


setup(
    author='TI Sistemas',
    author_email='ti.sistemas@grupolinsferrao.com.br',    
    description='Classes e utilitarios para uso em apis rest com django.',        
    license='MIT',    
    name='lins_restapi',
    packages=find_packages(),    
    install_requires=[
        'drf-yasg==1.21.10',
    ],
    url='https://bitbucket.org/grupolinsferrao/pypck-lins-restapi/',
    version=__version__,
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
)
