# GUIDE Framework – Ethical AI, Governance & Explainability (XAI)

`guide-framework` is a modern Ethical AI toolkit that helps organizations **audit**, **explain**, and **govern** AI systems using the **G.U.I.D.E.** ethical principles:

## 🌟 GUIDE AI ETHICS FRAMEWORK  
**G – Governance**  
**U – Universal Design**  
**I – Identification**  
**D – Dignity**  
**E – Equity**

This framework ensures:

- Fairness  
- Transparency  
- Explainability  
- Accessibility (508/WCAG)  
- Responsible AI decision-making  
- Ethical auditing and governance  

It includes both **Ethical AI auditing** and **XAI-based explainability tools**, plus a **built-in demo audit**.

---

# 🚀 INSTALLATION

```bash
pip install guide-framework
```

Requires **Python 3.8+**

For data-dependent audits:

```bash
pip install pandas scikit-learn numpy
```

---

# 🧠 QUICK START — ETHICAL AI AUDIT

```python
from guide_framework import EthicalAIAudit

audit = EthicalAIAudit("LoanModel")

audit.transparency_check({
    "model_name": "LoanModel",
    "version": "1.0",
    "training_data": "internal",
    "documentation": True
})

audit.fairness_check("Evaluate this loan application.")
audit.safety_check("This system may present danger.")
audit.accessibility_check("This explanation is readable and clear.")

print(audit.finalize_report())
```

**Output example:**

```json
{
  "model": "LoanModel",
  "results": {
    "transparency": {"status": "pass"},
    "fairness": {"status": "pass"},
    "safety": {"status": "fail"},
    "accessibility": {"status": "pass"}
  },
  "score": "3/4",
  "approved": true
}
```

---

# 🎧 EXPLAINABILITY (XAI)

```python
from guide_framework import ExplainabilityGuide

xai = ExplainabilityGuide(api_key="YOUR_OPENAI_KEY")

explanation = xai.explain_decision(
    "The system rejected the loan.",
    context="Applicant missing income documentation"
)

print(explanation)
```

---

# 🧾 TRANSPARENCY SUMMARY

```python
metadata = {
    "model_name": "LoanModel",
    "purpose": "Predict risk",
    "training_data": "public datasets",
    "version": "1.0.0",
    "risks": "May underperform for seniors"
}

print(xai.transparency_summary(metadata))
```

---

# 🧪 TEST AUDIT SCRIPT (`test_audit.py`)  
Run a full ethical audit in one file.

## 📄 Create `test_audit.py`

```python
from guide_framework import EthicalAIAudit

# Create an audit instance
audit = EthicalAIAudit("CreditCardAI")

# Run tests
audit.transparency_check({
    "model_name": "CreditCardAI",
    "version": "2.1",
    "training_data": "bank transactions 2018–2024",
    "documentation": True
})

audit.fairness_check("Applicant includes gender and ethnicity attributes")
audit.safety_check("No dangerous content here")
audit.accessibility_check("This message is readable.")

# Generate final structured output
report = audit.finalize_report()

print("\n=== FINAL AUDIT REPORT ===")
print(report)
```

### ▶️ Run it:
```bash
python test_audit.py
```

---

# ▶️ BUILT-IN TEST AUDIT DEMO  
A demo audit is included inside the framework.

Run it directly:

```bash
python -m guide_framework.run_demo
```

You’ll see:

```
=== GUIDE FRAMEWORK DEMO AUDIT ===
{ ... audit results ... }
```

Perfect for training, compliance reviews, and onboarding.

---

# 📦 MODULE MAP

```
guide_framework/
  ├─ auditor.py           # Ethical audit (transparency, safety, fairness, 508)
  ├─ xai_meaning.py       # XAI explainability & transparency
  ├─ governance.py        # G – Governance
  ├─ understanding.py     # U – Universal Design
  ├─ integrity.py         # I – Identification / Integrity
  ├─ disclosure.py        # D – Disclosure
  ├─ equity.py            # E – Equity
  ├─ situation_templates.py
  ├─ knowledge_base.py
  ├─ guide_simple.py
  ├─ guide.py
  ├─ run_demo.py          # ★ Built-in demo audit script
  └─ other supporting utilities…
```

---

# 📋 GUIDE ETHICAL CHECKLIST

### **G – Governance**
☑ Oversight structure  
☑ Documentation  
☑ Model lifecycle control  

### **U – Universal Design**
☑ Inclusive testing  
☑ Diverse demographic validation  

### **I – Identification**
☑ Clear indication of AI-generated content  

### **D – Dignity**
☑ Respectful outputs  
☑ Human-centered safety  

### **E – Equity**
☑ Fairness across groups  
☑ Bias detection  

---

# 🧩 FAIRNESS RECOMMENDATIONS

1. Remove sensitive demographic fields  
2. Review group disparities quarterly  
3. Add human review to borderline cases  
4. Provide explanations to affected users  
5. Test performance across culture, age, gender  
6. Establish ethical escalation procedures  

---

# 🔐 API KEYS & SECURITY

Your OpenAI key is **not stored**.

```python
xai = ExplainabilityGuide(api_key="sk-xxxx")
```

or:

```bash
export OPENAI_API_KEY="sk-xxxx"
```

---

# ⚠ TROUBLESHOOTING

Upgrade:

```bash
pip install --upgrade guide-framework
```

Rebuild manually:

```bash
Remove-Item -Recurse -Force dist, build, *.egg-info
python setup.py sdist bdist_wheel
```

---

# 📜 LICENSE  
MIT License

---

# 👤 AUTHOR  
**Kamal Master**  
Email: **ktabine@gmail.com**

---

# ✔ GUIDE AUDIT COMPLETE  
**Build AI that earns trust through ethical excellence.**
