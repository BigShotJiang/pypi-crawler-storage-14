"""
Deprecated GUIDE Auditor module.

The modern auditor is EthicalAIAudit located in auditor.py.
This file exists only for backward compatibility.
"""

# Optional wrapper (if needed later)
class GUIDEAuditor:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError(
            "GUIDEAuditor is deprecated. Use EthicalAIAudit instead."
        )
