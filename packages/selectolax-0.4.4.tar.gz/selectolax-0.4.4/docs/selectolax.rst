selectolax package
==================

Submodules
----------

selectolax.lexbor module
------------------------

.. automodule:: selectolax.lexbor
   :members:
   :undoc-members:
   :show-inheritance:

selectolax.parser module
------------------------

.. automodule:: selectolax.parser
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: selectolax
   :members:
   :undoc-members:
   :show-inheritance:
