"""Inference algorithms for Beta-Binomial hierarchical models.

This module provides the main inference algorithms:
- Empirical Bayes: Estimate hyperparameters via maximum likelihood
- Hierarchical Bayes: Fully Bayesian with hyperparameter uncertainty
- Single-Theta: Pool all data, assume single success rate
- Clopper-Pearson: Frequentist exact confidence interval
"""

from proportions.inference.clopper_pearson import clopper_pearson
from proportions.inference.empirical_bayes import empirical_bayes
from proportions.inference.hierarchical_bayes import hierarchical_bayes
from proportions.inference.single_theta import single_theta_bayesian

__all__ = [
    "empirical_bayes",
    "hierarchical_bayes",
    "single_theta_bayesian",
    "clopper_pearson",
]
