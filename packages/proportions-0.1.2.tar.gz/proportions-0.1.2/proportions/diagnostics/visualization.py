"""Visualization tools for Hierarchical Bayes importance sampling diagnostics.

This module provides diagnostic visualizations for assessing the quality
of importance sampling approximations, including marginal and joint posterior
distributions.
"""

import numpy as np
import matplotlib.pyplot as plt

from proportions.diagnostics.importance_sampling import ImportanceSamples
from proportions.inference import empirical_bayes
from proportions.core.models import (
    BinomialData,
    PosteriorResult,
    EmpiricalBayesResult,
    HierarchicalBayesResult,
)


def plot_mk_distributions(
    samples: ImportanceSamples,
    data: BinomialData | None = None,
    eb_comparison: bool = True,
    figsize: tuple[float, float] = (15, 5),
) -> plt.Figure:
    """Create 3-panel diagnostic figure showing distributions of m and k.

    Panels:
    1. Marginal posterior for m (weighted vs unweighted)
    2. Marginal posterior for k (weighted vs unweighted)
    3. 2D joint posterior p(m, k | data) using rectangular kernels

    Note: Panel 3 uses 2D histogram with rectangular kernels (not KDE).
    This provides better visualization for highly concentrated posteriors.
    Number of bins is chosen to have ~10 samples per bin.

    Args:
        samples: ImportanceSamples from extract_importance_samples().
        data: Optional BinomialData for EB comparison.
        eb_comparison: If True and data provided, shows EB estimates.
        figsize: Figure size (width, height).

    Returns:
        Matplotlib Figure object.

    Example:
        >>> from proportions.diagnostics.importance_sampling import extract_importance_samples
        >>> from proportions.diagnostics.visualization import plot_mk_distributions
        >>>
        >>> samples = extract_importance_samples(data, random_seed=42)
        >>> fig = plot_mk_distributions(samples, data=data)
        >>> fig.savefig('mk_distributions.png', dpi=150, bbox_inches='tight')
        >>> plt.show()
    """
    fig, axes = plt.subplots(1, 3, figsize=figsize)
    fig.suptitle(f'Distribution of (m, k) | data\n'
                f'ESS = {samples.effective_sample_size:.1f} / {samples.n_samples} '
                f'({samples.effective_sample_size/samples.n_samples:.1%})',
                fontsize=14, fontweight='bold')

    # Compute EB estimates if requested
    eb_m, eb_k = None, None
    if eb_comparison and data is not None:
        eb_result = empirical_bayes(data)
        eb_m = eb_result.m_hat
        eb_k = eb_result.k_hat

    # Weighted posterior means
    m_mean = np.sum(samples.weights * samples.m_samples)
    k_mean = np.sum(samples.weights * samples.k_samples)

    # ============================================================
    # Panel 1: Marginal posterior for m
    # ============================================================
    ax = axes[0]
    ax.hist(samples.m_samples, bins=50, alpha=0.3, color='gray',
           density=True, label='Prior samples (unweighted)')
    ax.hist(samples.m_samples, bins=50, weights=samples.weights,
           alpha=0.7, color='purple', density=True,
           label='Posterior (weighted)')
    ax.axvline(m_mean, color='purple', linestyle='--', linewidth=2,
              label=f'HB: m={m_mean:.3f}')
    if eb_m is not None:
        ax.axvline(eb_m, color='green', linestyle=':', linewidth=2,
                  label=f'EB: m={eb_m:.3f}')
    ax.set_xlabel('m (mean parameter)', fontsize=11)
    ax.set_ylabel('Density', fontsize=11)
    ax.set_title('Marginal Posterior p(m | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 2: Marginal posterior for k
    # ============================================================
    ax = axes[1]
    # Use log scale for k if range is large
    k_range = samples.k_prior_max - samples.k_prior_min
    if k_range > 100:
        bins = np.logspace(np.log10(max(samples.k_prior_min, 1)),
                          np.log10(samples.k_prior_max), 50)
        ax.set_xscale('log')
    else:
        bins = 50

    ax.hist(samples.k_samples, bins=bins, alpha=0.3, color='gray',
           density=True, label='Prior samples (unweighted)')
    ax.hist(samples.k_samples, bins=bins, weights=samples.weights,
           alpha=0.7, color='orange', density=True,
           label='Posterior (weighted)')
    ax.axvline(k_mean, color='orange', linestyle='--', linewidth=2,
              label=f'HB: k={k_mean:.1f}')
    if eb_k is not None:
        ax.axvline(eb_k, color='green', linestyle=':', linewidth=2,
                  label=f'EB: k={eb_k:.1f}')
    ax.set_xlabel('k (concentration parameter)', fontsize=11)
    ax.set_ylabel('Density', fontsize=11)
    ax.set_title('Marginal Posterior p(k | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 3: 2D joint posterior p(m, k | data)
    # ============================================================
    ax = axes[2]
    try:
        # Use 2D histogram with rectangular kernels (better for concentrated posteriors)
        # Determine number of bins: aim for ~10 samples per bin
        n_bins = max(10, int(np.sqrt(samples.n_samples / 10)))

        # Create 2D weighted histogram
        H, m_edges, k_edges = np.histogram2d(
            samples.m_samples, samples.k_samples,
            bins=n_bins, weights=samples.weights, density=True
        )

        # Create meshgrid for plotting
        m_centers = (m_edges[:-1] + m_edges[1:]) / 2
        k_centers = (k_edges[:-1] + k_edges[1:]) / 2
        M, K = np.meshgrid(m_centers, k_centers)

        # Plot as pcolormesh (rectangular kernels)
        pcm = ax.pcolormesh(m_edges, k_edges, H.T, cmap='viridis',
                           shading='flat', alpha=0.8)
        plt.colorbar(pcm, ax=ax, label='Posterior Density')


        # Mark estimates
        ax.plot(m_mean, k_mean, 'r*', markersize=15, label='HB weighted mean',
               markeredgecolor='white', markeredgewidth=1)
        if eb_m is not None and eb_k is not None:
            ax.plot(eb_m, eb_k, 'g*', markersize=15, label='EB MLE',
                   markeredgecolor='white', markeredgewidth=1)

    except Exception as e:
        # Fallback to scatter if histogram fails
        ax.scatter(samples.m_samples, samples.k_samples,
                  c=samples.weights, cmap='viridis', alpha=0.5, s=20)
        ax.plot(m_mean, k_mean, 'r*', markersize=15, label='HB')
        if eb_m is not None and eb_k is not None:
            ax.plot(eb_m, eb_k, 'g*', markersize=15, label='EB')

    ax.set_xlabel('m (mean parameter)', fontsize=11)
    ax.set_ylabel('k (concentration parameter)', fontsize=11)
    ax.set_title('Joint Posterior p(m, k | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    return fig


def plot_importance_sampling_diagnostics(
    samples: ImportanceSamples,
    data: BinomialData | None = None,
    eb_comparison: bool = True,
    figsize: tuple[float, float] = (16, 10),
) -> plt.Figure:
    """Create comprehensive 6-panel diagnostic figure for importance sampling.

    Panels:
    1. Marginal posterior for m (weighted vs unweighted)
    2. Marginal posterior for k (weighted vs unweighted)
    3. 2D joint posterior p(m, k | data) using rectangular kernels
    4. 2D joint posterior p(α, β | data) using rectangular kernels
    5. Scatter plot in (α, β) space with sizes proportional to weight
    6. Weight distribution histogram

    Note: Panels 3 and 4 use 2D histograms with rectangular kernels (not KDE).
    This provides better visualization for highly concentrated posteriors.
    Number of bins is chosen to have ~20 samples per bin.

    Args:
        samples: ImportanceSamples from extract_importance_samples().
        data: Optional BinomialData for EB comparison.
        eb_comparison: If True and data provided, shows EB estimates.
        figsize: Figure size (width, height).

    Returns:
        Matplotlib Figure object.

    Example:
        >>> from proportions.diagnostics.importance_sampling import extract_importance_samples
        >>> from proportions.diagnostics.visualization import plot_importance_sampling_diagnostics
        >>>
        >>> samples = extract_importance_samples(data, random_seed=42)
        >>> fig = plot_importance_sampling_diagnostics(samples, data=data)
        >>> fig.savefig('hb_diagnostics.png', dpi=150, bbox_inches='tight')
        >>> plt.show()
    """
    fig, axes = plt.subplots(2, 3, figsize=figsize)
    fig.suptitle(f'Hierarchical Bayes Importance Sampling Diagnostics\n'
                f'ESS = {samples.effective_sample_size:.1f} / {samples.n_samples} '
                f'({samples.effective_sample_size/samples.n_samples:.1%})',
                fontsize=14, fontweight='bold')

    # Compute EB estimates if requested
    eb_m, eb_k, eb_alpha, eb_beta = None, None, None, None
    if eb_comparison and data is not None:
        eb_result = empirical_bayes(data)
        eb_m = eb_result.m_hat
        eb_k = eb_result.k_hat
        eb_alpha = eb_result.alpha_hat
        eb_beta = eb_result.beta_hat

    # Weighted posterior means
    m_mean = np.sum(samples.weights * samples.m_samples)
    k_mean = np.sum(samples.weights * samples.k_samples)
    alpha_mean = np.sum(samples.weights * samples.alpha_samples)
    beta_mean = np.sum(samples.weights * samples.beta_samples)

    # ============================================================
    # Panel 1: Marginal posterior for m
    # ============================================================
    ax = axes[0, 0]
    ax.hist(samples.m_samples, bins=50, alpha=0.3, color='gray',
           density=True, label='Prior samples (unweighted)')
    ax.hist(samples.m_samples, bins=50, weights=samples.weights,
           alpha=0.7, color='purple', density=True,
           label='Posterior (weighted)')
    ax.axvline(m_mean, color='purple', linestyle='--', linewidth=2,
              label=f'HB: m={m_mean:.3f}')
    if eb_m is not None:
        ax.axvline(eb_m, color='green', linestyle=':', linewidth=2,
                  label=f'EB: m={eb_m:.3f}')
    ax.set_xlabel('m (mean parameter)', fontsize=11)
    ax.set_ylabel('Density', fontsize=11)
    ax.set_title('Marginal Posterior p(m | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 2: Marginal posterior for k
    # ============================================================
    ax = axes[0, 1]
    # Use log scale for k if range is large
    k_range = samples.k_prior_max - samples.k_prior_min
    if k_range > 100:
        bins = np.logspace(np.log10(max(samples.k_prior_min, 1)),
                          np.log10(samples.k_prior_max), 50)
        ax.set_xscale('log')
    else:
        bins = 50

    ax.hist(samples.k_samples, bins=bins, alpha=0.3, color='gray',
           density=True, label='Prior samples (unweighted)')
    ax.hist(samples.k_samples, bins=bins, weights=samples.weights,
           alpha=0.7, color='orange', density=True,
           label='Posterior (weighted)')
    ax.axvline(k_mean, color='orange', linestyle='--', linewidth=2,
              label=f'HB: k={k_mean:.1f}')
    if eb_k is not None:
        ax.axvline(eb_k, color='green', linestyle=':', linewidth=2,
                  label=f'EB: k={eb_k:.1f}')
    ax.set_xlabel('k (concentration parameter)', fontsize=11)
    ax.set_ylabel('Density', fontsize=11)
    ax.set_title('Marginal Posterior p(k | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 3: 2D joint posterior p(m, k | data)
    # ============================================================
    ax = axes[0, 2]
    try:
        # Use 2D histogram with rectangular kernels (better for concentrated posteriors)
        # Determine number of bins: aim for ~10 samples per bin
        n_bins = max(10, int(np.sqrt(samples.n_samples / 10)))

        # Create 2D weighted histogram
        H, m_edges, k_edges = np.histogram2d(
            samples.m_samples, samples.k_samples,
            bins=n_bins, weights=samples.weights, density=True
        )

        # Create meshgrid for plotting
        m_centers = (m_edges[:-1] + m_edges[1:]) / 2
        k_centers = (k_edges[:-1] + k_edges[1:]) / 2
        M, K = np.meshgrid(m_centers, k_centers)

        # Plot as pcolormesh (rectangular kernels)
        pcm = ax.pcolormesh(m_edges, k_edges, H.T, cmap='viridis',
                           shading='flat', alpha=0.8)
        plt.colorbar(pcm, ax=ax, label='Posterior Density')


        # Mark estimates
        ax.plot(m_mean, k_mean, 'r*', markersize=15, label='HB weighted mean',
               markeredgecolor='white', markeredgewidth=1)
        if eb_m is not None and eb_k is not None:
            ax.plot(eb_m, eb_k, 'g*', markersize=15, label='EB MLE',
                   markeredgecolor='white', markeredgewidth=1)

    except Exception as e:
        # Fallback to scatter if histogram fails
        ax.scatter(samples.m_samples, samples.k_samples,
                  c=samples.weights, cmap='viridis', alpha=0.5, s=20)
        ax.plot(m_mean, k_mean, 'r*', markersize=15, label='HB')
        if eb_m is not None and eb_k is not None:
            ax.plot(eb_m, eb_k, 'g*', markersize=15, label='EB')

    ax.set_xlabel('m (mean parameter)', fontsize=11)
    ax.set_ylabel('k (concentration parameter)', fontsize=11)
    ax.set_title('Joint Posterior p(m, k | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 4: 2D joint posterior p(α, β | data)
    # ============================================================
    ax = axes[1, 0]
    try:
        # Use 2D histogram with rectangular kernels (better for concentrated posteriors)
        # Determine number of bins: aim for ~10 samples per bin
        n_bins = max(10, int(np.sqrt(samples.n_samples / 10)))

        # Create 2D weighted histogram
        H, alpha_edges, beta_edges = np.histogram2d(
            samples.alpha_samples, samples.beta_samples,
            bins=n_bins, weights=samples.weights, density=True
        )

        # Create meshgrid for plotting
        alpha_centers = (alpha_edges[:-1] + alpha_edges[1:]) / 2
        beta_centers = (beta_edges[:-1] + beta_edges[1:]) / 2
        A, B = np.meshgrid(alpha_centers, beta_centers)

        # Plot as pcolormesh (rectangular kernels)
        pcm = ax.pcolormesh(alpha_edges, beta_edges, H.T, cmap='plasma',
                           shading='flat', alpha=0.8)
        plt.colorbar(pcm, ax=ax, label='Posterior Density')


        # Mark estimates
        ax.plot(alpha_mean, beta_mean, 'r*', markersize=15, label='HB weighted mean',
               markeredgecolor='white', markeredgewidth=1)
        if eb_alpha is not None and eb_beta is not None:
            ax.plot(eb_alpha, eb_beta, 'g*', markersize=15, label='EB MLE',
                   markeredgecolor='white', markeredgewidth=1)

    except Exception as e:
        # Fallback to scatter if histogram fails
        ax.scatter(samples.alpha_samples, samples.beta_samples,
                  c=samples.weights, cmap='plasma', alpha=0.5, s=20)
        ax.plot(alpha_mean, beta_mean, 'r*', markersize=15, label='HB')
        if eb_alpha is not None and eb_beta is not None:
            ax.plot(eb_alpha, eb_beta, 'g*', markersize=15, label='EB')

    ax.set_xlabel('α (Beta alpha parameter)', fontsize=11)
    ax.set_ylabel('β (Beta beta parameter)', fontsize=11)
    ax.set_title('Joint Posterior p(α, β | data)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 5: Scatter plot with sizes proportional to weight
    # ============================================================
    ax = axes[1, 1]
    # Scale marker sizes: larger weights = larger markers
    marker_sizes = 1000 * samples.weights / np.max(samples.weights)
    scatter = ax.scatter(samples.alpha_samples, samples.beta_samples,
                        s=marker_sizes, c=samples.weights, cmap='cool',
                        alpha=0.6, edgecolors='black', linewidths=0.5)
    ax.plot(alpha_mean, beta_mean, 'r*', markersize=20, label='HB weighted mean',
           markeredgecolor='white', markeredgewidth=1.5, zorder=10)
    if eb_alpha is not None and eb_beta is not None:
        ax.plot(eb_alpha, eb_beta, 'g*', markersize=20, label='EB MLE',
               markeredgecolor='white', markeredgewidth=1.5, zorder=10)

    plt.colorbar(scatter, ax=ax, label='Weight')
    ax.set_xlabel('α (Beta alpha parameter)', fontsize=11)
    ax.set_ylabel('β (Beta beta parameter)', fontsize=11)
    ax.set_title('Weighted Samples (size proportional to weight)', fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)

    # ============================================================
    # Panel 6: Weight distribution
    # ============================================================
    ax = axes[1, 2]
    ax.hist(samples.weights, bins=50, color='steelblue', alpha=0.7, edgecolor='black')
    ax.axvline(np.mean(samples.weights), color='red', linestyle='--',
              linewidth=2, label=f'Mean = {np.mean(samples.weights):.6f}')
    ax.axvline(np.max(samples.weights), color='orange', linestyle=':',
              linewidth=2, label=f'Max = {np.max(samples.weights):.6f}')
    ax.set_xlabel('Normalized Weight', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.set_title(f'Weight Distribution\n(ESS = {samples.effective_sample_size:.1f})',
                fontsize=12, fontweight='bold')
    ax.legend(fontsize=9)
    ax.grid(True, alpha=0.3)
    ax.set_yscale('log')

    plt.tight_layout()
    return fig
