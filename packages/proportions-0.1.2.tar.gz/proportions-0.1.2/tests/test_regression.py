"""Regression tests comparing library implementations against notebook reference results.

These tests ensure that our library implementations produce results consistent
with the original notebook implementations across all three test datasets.
"""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Add utilities directory to import notebook implementations
sys.path.insert(0, '/Users/javiermovellan/fun_bench/javier/utilities')

from empirical_bayes_improved import empirical_bayes_mk
from hierarchical_bayes_importance_sampling import (
    hierarchical_bayes_importance_sampling,
    weighted_posterior_T,
)
from average_posterior import (
    empirical_bayes_average_posterior,
    standard_bayes_average_posterior,
)


# Load reference results
REFERENCE_FILE = Path(__file__).parent / "reference_results.json"
with open(REFERENCE_FILE) as f:
    REFERENCE_RESULTS = json.load(f)


def load_dataset(dataset_name):
    """Load dataset from CSV file."""
    filename_map = {
        'simulated': 'simulated_beta_binomial_data.csv',
        'adversarial': 'adversarial_theta_data.csv',
        'homogeneous': 'homogeneous_theta_data.csv',
    }

    csv_path = Path(__file__).parent.parent / "data" / filename_map[dataset_name]
    df = pd.read_csv(csv_path)
    return df['x'].values, df['n'].values


@pytest.fixture(params=['simulated'])
def dataset_name(request):
    """Parametrize over datasets. Using only 'simulated' to reduce test time.

    Other datasets available: 'adversarial', 'homogeneous'
    Add them back to params list if needed for comprehensive testing.
    """
    return request.param


@pytest.fixture
def dataset(dataset_name):
    """Load dataset and reference results."""
    x, n = load_dataset(dataset_name)
    reference = REFERENCE_RESULTS[dataset_name]
    return x, n, reference, dataset_name


class TestEmpiricalBayesRegression:
    """Test Empirical Bayes implementation against notebook results."""

    def test_eb_hyperparameters(self, dataset):
        """Test that EB hyperparameter estimation matches notebook."""
        x, n, reference, name = dataset
        ref_eb = reference['empirical_bayes']

        # Run EB
        m_hat, k_hat, alpha_hat, beta_hat = empirical_bayes_mk(
            x, n,
            m_range=(0.7, 0.99),
            k_range=(5.0, 1000.0),
            m_grid=50,
            k_grid=50
        )

        # Check hyperparameters (allow small tolerance for grid search)
        assert np.isclose(m_hat, ref_eb['m_hat'], rtol=0.01, atol=0.01), \
            f"{name}: m_hat mismatch: got {m_hat:.4f}, expected {ref_eb['m_hat']:.4f}"

        assert np.isclose(k_hat, ref_eb['k_hat'], rtol=0.05, atol=1.0), \
            f"{name}: k_hat mismatch: got {k_hat:.2f}, expected {ref_eb['k_hat']:.2f}"

        assert np.isclose(alpha_hat, ref_eb['alpha_hat'], rtol=0.02, atol=0.1), \
            f"{name}: alpha_hat mismatch: got {alpha_hat:.2f}, expected {ref_eb['alpha_hat']:.2f}"

        assert np.isclose(beta_hat, ref_eb['beta_hat'], rtol=0.02, atol=0.1), \
            f"{name}: beta_hat mismatch: got {beta_hat:.2f}, expected {ref_eb['beta_hat']:.2f}"

    def test_eb_posterior_mean(self, dataset):
        """Test that EB posterior mean for T matches notebook."""
        x, n, reference, name = dataset
        ref_eb = reference['empirical_bayes']

        # Run EB
        m_hat, k_hat, alpha_hat, beta_hat = empirical_bayes_mk(
            x, n,
            m_range=(0.7, 0.99),
            k_range=(5.0, 1000.0),
            m_grid=50,
            k_grid=50
        )

        # Compute posterior for T
        result = empirical_bayes_average_posterior(alpha_hat, beta_hat, x, n)

        # Check posterior mean
        assert np.isclose(result['mu_T'], ref_eb['mu_T'], rtol=0.01, atol=0.001), \
            f"{name}: E[T] mismatch: got {result['mu_T']:.4f}, expected {ref_eb['mu_T']:.4f}"

    def test_eb_credible_interval(self, dataset):
        """Test that EB credible intervals match notebook."""
        x, n, reference, name = dataset
        ref_eb = reference['empirical_bayes']

        # Run EB
        m_hat, k_hat, alpha_hat, beta_hat = empirical_bayes_mk(
            x, n,
            m_range=(0.7, 0.99),
            k_range=(5.0, 1000.0),
            m_grid=50,
            k_grid=50
        )

        # Compute posterior for T
        result = empirical_bayes_average_posterior(alpha_hat, beta_hat, x, n)

        # Check CI bounds (allow slightly more tolerance for quantiles)
        assert np.isclose(result['ci_low'], ref_eb['ci_low'], rtol=0.01, atol=0.005), \
            f"{name}: CI lower mismatch: got {result['ci_low']:.4f}, expected {ref_eb['ci_low']:.4f}"

        assert np.isclose(result['ci_high'], ref_eb['ci_high'], rtol=0.01, atol=0.005), \
            f"{name}: CI upper mismatch: got {result['ci_high']:.4f}, expected {ref_eb['ci_high']:.4f}"


class TestHierarchicalBayesRegression:
    """Test Hierarchical Bayes implementation against notebook results."""

    def test_hb_posterior_mean(self, dataset):
        """Test that HB posterior mean for T matches notebook."""
        x, n, reference, name = dataset
        ref_hb = reference['hierarchical_bayes']

        # Run HB with same random seed as reference
        weighted_samples = hierarchical_bayes_importance_sampling(
            x, n,
            n_samples=40000,
            m_prior_alpha=1.0,
            m_prior_beta=1.0,
            k_prior_min=1.0,
            k_prior_max=1000.0,
            random_seed=42
        )

        result = weighted_posterior_T(weighted_samples, x, n)

        # Check posterior mean (allow more tolerance for stochastic method)
        tolerance = 0.02 if name != 'adversarial' else 0.05  # Adversarial is harder
        assert np.isclose(result['mu_T'], ref_hb['mu_T'], rtol=tolerance, atol=0.01), \
            f"{name}: E[T] mismatch: got {result['mu_T']:.4f}, expected {ref_hb['mu_T']:.4f}"

    def test_hb_credible_interval(self, dataset):
        """Test that HB credible intervals match notebook."""
        x, n, reference, name = dataset
        ref_hb = reference['hierarchical_bayes']

        # Run HB with same random seed as reference
        weighted_samples = hierarchical_bayes_importance_sampling(
            x, n,
            n_samples=40000,
            m_prior_alpha=1.0,
            m_prior_beta=1.0,
            k_prior_min=1.0,
            k_prior_max=1000.0,
            random_seed=42
        )

        result = weighted_posterior_T(weighted_samples, x, n)

        # Check CI bounds (allow more tolerance for stochastic method)
        tolerance = 0.03 if name != 'adversarial' else 0.10
        assert np.isclose(result['ci_low'], ref_hb['ci_low'], rtol=tolerance, atol=0.01), \
            f"{name}: CI lower mismatch: got {result['ci_low']:.4f}, expected {ref_hb['ci_low']:.4f}"

        assert np.isclose(result['ci_high'], ref_hb['ci_high'], rtol=tolerance, atol=0.01), \
            f"{name}: CI upper mismatch: got {result['ci_high']:.4f}, expected {ref_hb['ci_high']:.4f}"

    def test_hb_ess(self, dataset):
        """Test that HB effective sample size is reasonable."""
        x, n, reference, name = dataset
        ref_hb = reference['hierarchical_bayes']

        # Run HB with same random seed as reference
        weighted_samples = hierarchical_bayes_importance_sampling(
            x, n,
            n_samples=40000,
            m_prior_alpha=1.0,
            m_prior_beta=1.0,
            k_prior_min=1.0,
            k_prior_max=1000.0,
            random_seed=42
        )

        # ESS should be reasonably close (it's stochastic)
        # For adversarial, ESS is very low (~1), so allow wider range
        if name == 'adversarial':
            assert weighted_samples.effective_sample_size < 10, \
                f"{name}: ESS should be very low for adversarial data"
        else:
            # For other datasets, should be within 50% of reference
            assert 0.3 * ref_hb['ess'] < weighted_samples.effective_sample_size < 3.0 * ref_hb['ess'], \
                f"{name}: ESS {weighted_samples.effective_sample_size:.1f} too far from reference {ref_hb['ess']:.1f}"

    def test_hb_wider_ci_than_eb(self, dataset):
        """Test that HB has wider CI than EB (accounts for hyperparameter uncertainty)."""
        x, n, reference, name = dataset
        ref_eb = reference['empirical_bayes']
        ref_hb = reference['hierarchical_bayes']

        eb_width = ref_eb['ci_high'] - ref_eb['ci_low']
        hb_width = ref_hb['ci_high'] - ref_hb['ci_low']

        # HB should have wider or equal CI (accounting for hyperparameter uncertainty)
        assert hb_width >= eb_width * 0.95, \
            f"{name}: HB CI width {hb_width:.4f} should be >= EB CI width {eb_width:.4f}"


class TestStandardBayesRegression:
    """Test Standard Bayes (Multi-Theta) implementation against notebook results."""

    def test_sb_posterior_mean(self, dataset):
        """Test that Standard Bayes posterior mean matches notebook."""
        x, n, reference, name = dataset
        ref_sb = reference['standard_bayes']
        ref_eb = reference['empirical_bayes']  # Uses EB hyperparams as prior

        # Compute posteriors using EB hyperparameters as prior
        alpha_post = ref_eb['alpha_hat'] + x
        beta_post = ref_eb['beta_hat'] + (n - x)

        result = standard_bayes_average_posterior(alpha_post, beta_post)

        # Should match exactly (deterministic computation)
        assert np.isclose(result['mu_T'], ref_sb['mu_T'], rtol=1e-4, atol=1e-6), \
            f"{name}: E[T] mismatch: got {result['mu_T']:.4f}, expected {ref_sb['mu_T']:.4f}"

    def test_sb_credible_interval(self, dataset):
        """Test that Standard Bayes credible intervals match notebook."""
        x, n, reference, name = dataset
        ref_sb = reference['standard_bayes']
        ref_eb = reference['empirical_bayes']

        # Compute posteriors using EB hyperparameters as prior
        alpha_post = ref_eb['alpha_hat'] + x
        beta_post = ref_eb['beta_hat'] + (n - x)

        result = standard_bayes_average_posterior(alpha_post, beta_post)

        # Should match closely (small differences due to quantile computation)
        assert np.isclose(result['ci_low'], ref_sb['ci_low'], rtol=1e-3, atol=1e-4), \
            f"{name}: CI lower mismatch: got {result['ci_low']:.4f}, expected {ref_sb['ci_low']:.4f}"

        assert np.isclose(result['ci_high'], ref_sb['ci_high'], rtol=1e-3, atol=1e-4), \
            f"{name}: CI upper mismatch: got {result['ci_high']:.4f}, expected {ref_sb['ci_high']:.4f}"


class TestSingleThetaRegression:
    """Test Single-Theta Bayesian implementation against notebook results."""

    def test_single_theta_posterior_mean(self, dataset):
        """Test that Single-Theta posterior mean matches notebook."""
        x, n, reference, name = dataset
        ref_st = reference['single_theta']
        ref_eb = reference['empirical_bayes']  # Uses EB hyperparams as prior

        from empirical_bayes_improved import beta_ppf

        # Pool data
        x_total = np.sum(x)
        n_total = np.sum(n)

        # Compute posterior
        alpha_post = ref_eb['alpha_hat'] + x_total
        beta_post = ref_eb['beta_hat'] + (n_total - x_total)

        mean_single = alpha_post / (alpha_post + beta_post)

        # Should match closely (small rounding differences possible)
        assert np.isclose(mean_single, ref_st['mu_T'], rtol=1e-3, atol=1e-4), \
            f"{name}: E[T] mismatch: got {mean_single:.4f}, expected {ref_st['mu_T']:.4f}"

    def test_single_theta_credible_interval(self, dataset):
        """Test that Single-Theta credible intervals match notebook."""
        x, n, reference, name = dataset
        ref_st = reference['single_theta']
        ref_eb = reference['empirical_bayes']

        from empirical_bayes_improved import beta_ppf

        # Pool data
        x_total = np.sum(x)
        n_total = np.sum(n)

        # Compute posterior
        alpha_post = ref_eb['alpha_hat'] + x_total
        beta_post = ref_eb['beta_hat'] + (n_total - x_total)

        ci_low = beta_ppf(0.025, alpha_post, beta_post)
        ci_high = beta_ppf(0.975, alpha_post, beta_post)

        # Should match closely
        assert np.isclose(ci_low, ref_st['ci_low'], rtol=1e-3, atol=1e-4), \
            f"{name}: CI lower mismatch: got {ci_low:.4f}, expected {ref_st['ci_low']:.4f}"

        assert np.isclose(ci_high, ref_st['ci_high'], rtol=1e-3, atol=1e-4), \
            f"{name}: CI upper mismatch: got {ci_high:.4f}, expected {ref_st['ci_high']:.4f}"


class TestClopperPearsonRegression:
    """Test Clopper-Pearson implementation against notebook results."""

    def test_clopper_pearson_point_estimate(self, dataset):
        """Test that Clopper-Pearson point estimate matches notebook."""
        x, n, reference, name = dataset
        ref_cp = reference['clopper_pearson']

        # Pool data
        x_total = np.sum(x)
        n_total = np.sum(n)

        p_hat = x_total / n_total

        # Should match closely (small rounding differences possible)
        assert np.isclose(p_hat, ref_cp['point_estimate'], rtol=1e-3, atol=1e-4), \
            f"{name}: Point estimate mismatch: got {p_hat:.4f}, expected {ref_cp['point_estimate']:.4f}"

    def test_clopper_pearson_confidence_interval(self, dataset):
        """Test that Clopper-Pearson confidence intervals match notebook."""
        x, n, reference, name = dataset
        ref_cp = reference['clopper_pearson']

        from scipy import stats

        # Pool data
        x_total = int(np.sum(x))
        n_total = int(np.sum(n))

        # Compute Clopper-Pearson CI
        ci_low = stats.beta.ppf(0.025, x_total, n_total - x_total + 1)
        ci_high = stats.beta.ppf(0.975, x_total + 1, n_total - x_total)

        # Handle edge cases
        if x_total == 0:
            ci_low = 0.0
        if x_total == n_total:
            ci_high = 1.0

        # Should match closely
        assert np.isclose(ci_low, ref_cp['ci_low'], rtol=1e-3, atol=1e-4), \
            f"{name}: CI lower mismatch: got {ci_low:.4f}, expected {ref_cp['ci_low']:.4f}"

        assert np.isclose(ci_high, ref_cp['ci_high'], rtol=1e-3, atol=1e-4), \
            f"{name}: CI upper mismatch: got {ci_high:.4f}, expected {ref_cp['ci_high']:.4f}"


class TestDatasetCharacteristics:
    """Test that datasets have expected characteristics."""

    def test_simulated_dataset_properties(self):
        """Test simulated dataset has expected properties."""
        x, n = load_dataset('simulated')
        reference = REFERENCE_RESULTS['simulated']

        assert len(x) == reference['n_groups']

        pooled_rate = np.sum(x) / np.sum(n)
        assert np.isclose(pooled_rate, reference['pooled_rate'], rtol=1e-4)

    def test_adversarial_dataset_properties(self):
        """Test adversarial dataset has expected extreme properties."""
        x, n = load_dataset('adversarial')
        reference = REFERENCE_RESULTS['adversarial']

        assert len(x) == reference['n_groups']

        pooled_rate = np.sum(x) / np.sum(n)
        assert np.isclose(pooled_rate, reference['pooled_rate'], rtol=1e-3, atol=1e-4)

        # Adversarial should have very low pooled rate but higher T
        assert pooled_rate < 0.02
        assert reference['empirical_bayes']['mu_T'] > 0.3  # Much higher than pooled

    def test_homogeneous_dataset_properties(self):
        """Test homogeneous dataset has expected low heterogeneity."""
        x, n = load_dataset('homogeneous')
        reference = REFERENCE_RESULTS['homogeneous']

        assert len(x) == reference['n_groups']

        pooled_rate = np.sum(x) / np.sum(n)
        assert np.isclose(pooled_rate, reference['pooled_rate'], rtol=1e-4)

        # Homogeneous data: EB should hit k boundary (wants high concentration)
        assert reference['empirical_bayes']['k_hat'] >= 999.0  # Hit upper bound


class TestMethodComparison:
    """Test relationships between different methods."""

    def test_eb_sb_equivalence(self, dataset):
        """Test that EB and Standard Bayes give same results when using same prior."""
        x, n, reference, name = dataset

        ref_eb = reference['empirical_bayes']
        ref_sb = reference['standard_bayes']

        # When Standard Bayes uses EB hyperparameters, they should match
        assert np.isclose(ref_sb['mu_T'], ref_eb['mu_T'], rtol=1e-4), \
            f"{name}: EB and SB means should match when using same prior"

        assert np.isclose(ref_sb['ci_low'], ref_eb['ci_low'], rtol=1e-3), \
            f"{name}: EB and SB CI lower should match when using same prior"

        assert np.isclose(ref_sb['ci_high'], ref_eb['ci_high'], rtol=1e-3), \
            f"{name}: EB and SB CI upper should match when using same prior"

    def test_single_theta_pooled_equivalence(self, dataset):
        """Test that Single-Theta gives pooled rate for homogeneous data."""
        x, n, reference, name = dataset

        if name == 'homogeneous':
            ref_st = reference['single_theta']
            ref_cp = reference['clopper_pearson']

            # For homogeneous data, Single-Theta and Clopper-Pearson should be very close
            assert np.isclose(ref_st['mu_T'], ref_cp['point_estimate'], rtol=0.01), \
                "Single-Theta and pooled rate should be very close for homogeneous data"

    def test_hb_incorporates_uncertainty(self, dataset):
        """Test that HB properly accounts for hyperparameter uncertainty."""
        x, n, reference, name = dataset

        ref_eb = reference['empirical_bayes']
        ref_hb = reference['hierarchical_bayes']

        # HB should have wider CI (except possibly for very certain cases)
        eb_width = ref_eb['ci_high'] - ref_eb['ci_low']
        hb_width = ref_hb['ci_high'] - ref_hb['ci_low']

        assert hb_width >= eb_width * 0.9, \
            f"{name}: HB should have similar or wider CI than EB"
