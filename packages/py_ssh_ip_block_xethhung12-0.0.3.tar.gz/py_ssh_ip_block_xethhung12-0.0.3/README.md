
# py_ssh_ip_block_xethhung12
## Installation
```shell
pip install py-ssh-ip-block-xethhung
```

## Prerequisite
Before start using the tool, two operation is required
1. Create ipset
    ```shell
    ipset create {set-name} hash:ip 
    ```
2. add iptables rule
    ```shell
    sudo iptables -A INPUT -m set --match-set {set-name} src -p tcp --destination-port {port} -j DROP 
    ```

## Execution
Run through python project script
```shell
py-ssh-ip-block-xethhung12 -h
```

## Delete Rules
Delete iptables rule
```shell
# get rule number
sudo iptables -L INPUT --line-numbers

# delete rule by line number
sudo iptable -D INPUT 2 
```