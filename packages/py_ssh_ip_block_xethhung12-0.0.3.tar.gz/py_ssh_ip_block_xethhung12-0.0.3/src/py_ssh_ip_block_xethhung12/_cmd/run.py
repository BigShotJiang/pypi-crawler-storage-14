import py_ssh_ip_block_xethhung12 as project
def main():
    project.main()
