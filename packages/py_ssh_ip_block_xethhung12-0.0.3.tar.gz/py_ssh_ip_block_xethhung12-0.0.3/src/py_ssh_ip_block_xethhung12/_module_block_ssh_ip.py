import argparse
import argparse
import sqlite3
import re
import datetime as dt
import json
from zoneinfo import ZoneInfo
import subprocess

hkt = ZoneInfo("Asia/Hong_Kong")
default_dt_format="%Y-%m-%dT%H:%M:%S.%f%z"

def init_db():
    def check_table_exists(table_name):
        cur.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}';")
        return len(cur.fetchall())

    if check_table_exists(block_table_name) == 0:
        cur.execute(f"""
            CREATE TABLE {block_table_name} (
            ip TEXT PRIMARY KEY,
            count INTEGER NOT NULL DEFAULT 0 CHECK(count >= 0),
            last_found INTEGER NOT NULL DEFAULT (strftime('%s','now'))
            );
            """
        )
    
    if check_table_exists(block_table_name) == 0:
        raise Exception(f"The db not able to create: {block_table_name}")
    
    if check_table_exists(config_table_name) == 0:
        cur.execute(f"""
            CREATE TABLE {config_table_name} (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
            );
            """
        )
    
    if check_table_exists(config_table_name) == 0:
        raise Exception(f"The db not able to create: {config_table_name}")
    
    db.commit()

def get_reading_progress():
    cur.execute(f"SELECT value FROM {config_table_name} WHERE key='read.progress'")
    data = cur.fetchone()
    if data is None:
        cur.execute(f"INSERT INTO {config_table_name} (key, value) VALUES ('read.progress', 0)")
        db.commit()
        return 0
    else:
        cur.execute(f"SELECT value FROM {config_table_name} WHERE key='read.progress'")
        return cur.fetchone()[0]

def find_from_file():
    patters = [
        r"^(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d{6}\+\d{2}:\d{2}) [a-zA-Z0-9-]+ sshd\[\d+\]: Invalid user \w+ from (\d+\.\d+\.\d+\.\d+) port \d+$",
        r"^(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d{6}\+\d{2}:\d{2}) [a-zA-Z0-9-]+ sshd\[\d+\]: Failed password for \w+ from (\d+\.\d+\.\d+\.\d+) port \d+ ssh2$",
        r"^(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d{6}\+\d{2}:\d{2}) [a-zA-Z0-9-]+ sshd\[\d+\]: Connection closed by (\d+\.\d+\.\d+\.\d+) port \d+$",
    ]
    rs = {}
    compiled_patterns = [re.compile(pattern) for pattern in patters]
    with open(VAR_AUTH_LOG, "r", encoding="utf-8") as f:
        for line in f:
            matchers = [ compiled_pattern.match(line) for compiled_pattern in compiled_patterns]
            matchers = [matcher for matcher in matchers if matcher is not None]
            matcher = matchers[0] if len(matchers) > 0 else None
            if matcher is not None:
                time_obj = dt.datetime.fromisoformat(matcher[1])
                time_obj = time_obj.astimezone(tz=hkt)
                ip = matcher[2]
                if ip not in rs:
                    rs.update({ip:{
                        "ip": ip,
                        "count": 1,
                        "last_found": time_obj
                    }})
                else:
                    rs[ip]["count"]+=1
                    if rs[ip]["last_found"] < time_obj:
                        rs[ip]["last_found"] = time_obj

    for key in rs:
        rs[key]["last_found"] = rs[key]["last_found"].strftime(default_dt_format)
    return rs


def insert_new_records(ls):
    for l in ls:
        print(f"Inserting IP[{l['ip']}] to database, block due to failed login {l['count']} times")
        cur.execute(f"INSERT INTO {block_table_name} (ip, count, last_found) VALUES (?, ?, ?)", (l["ip"], l["count"], l["last_found"]))
    db.commit()

def update_records(ls):
    for l in ls:
        # print(f"Updating IP[{l['ip']}] to database")
        rec_in_db = cur.execute(f"SELECT last_found FROM {block_table_name} WHERE ip=?", (l["ip"],)).fetchone()[0]
        # print(rec_in_db)
        rec_in_db = dt.datetime.strptime(rec_in_db, default_dt_format)
        if rec_in_db < dt.datetime.strptime(l["last_found"], default_dt_format):
            print(f"{l['ip']} requires to update")
            cur.execute(f"UPDATE {block_table_name} SET count=?, last_found=? WHERE ip=?", (l["count"], l["last_found"], l["ip"]))
        else:
            pass
            # print(f"{l['ip']} don't to be update")
    db.commit()

def delete_records(ips):
    if len(ips) == 0:
        print("Nothing to delete")
        return
    print(f"Deleting ip: ")
    for ip in ips:
        print(f"\t{ip}")
    cur.execute(f"DELETE FROM {block_table_name} WHERE ip in ({','.join(['?']*len(ips))})", tuple(ips))
    db.commit()



def digest_data(found_data):
    ks = [k for k in found_data]
    deadline=dt.datetime.now(tz=hkt)-dt.timedelta(days=RETENTION_DAY)

    sql=f"select ip, last_found from {block_table_name} where ip not in ({','.join(['?']*len(ks))})"
    cur.execute(sql, tuple(ks))
    ips_not_in_db = [(i[0], dt.datetime.strptime(i[1], default_dt_format)) for i in cur]
    to_be_delete=[]
    for ip, d in ips_not_in_db:
        if d < deadline:
            to_be_delete.append(ip)
    delete_records(to_be_delete)

    # insert update
    sql=f"select ip from {block_table_name} where ip in ({','.join(['?']*len(ks))})"
    cur.execute(sql, tuple(ks))
    ips_in_db = [i[0] for i in cur]
    update_list = []
    insert_list = []
    for k in ks:
        if k in ips_in_db:
            # print(f"to be updated: {k}")
            update_list.append(k)
        else:
            if found_data[k]['count'] > 10:
                # print(f"to be insert: {k}")
                insert_list.append(k)
    # print(insert_list)
    # print(update_list)
    insert_new_records([found_data[i] for i in insert_list])
    update_records([found_data[i] for i in update_list])


def get_ipset_list():
    rs = subprocess.run(f"sudo ipset list {IPSET_NAME}".split(" "), capture_output=True, text=True, check=True)
    rs = rs.stdout.split("\n")
    found=False
    ips=[]
    for l in rs:
        if l.strip() == '':
            continue
        if found:
            ips.append(l.strip())
        if l=='Members:':
            # print("Found")
            found=True
    return ips

def get_ip_for_last_x_days(x):
    dd = cur.execute(f"select ip,last_found from {block_table_name}").fetchall()
    deadline=dt.datetime.now(tz=hkt)-dt.timedelta(days=x)

    rs=[]
    for i in dd:
        ip=i[0]
        last_found=dt.datetime.strptime(i[1], default_dt_format)
        if last_found < deadline:
            continue
        rs.append(ip)
    return rs

def remove_ip_from_ipset(ip):
    subprocess.run(f"sudo ipset del block-ssh-attack {ip}".split(" "), capture_output=True, text=True, check=True)

def add_ip_from_ipset(ip):
    subprocess.run(f"sudo ipset add block-ssh-attack {ip}".split(" "), capture_output=True, text=True, check=True)

def update_ipset_list():
    ipset_list = get_ipset_list()
    ip_blocked=get_ip_for_last_x_days(RETENTION_DAY)
    to_be_add=[]
    to_be_remove=[]
    for i in ip_blocked:
        if i not in ipset_list:
            to_be_add.append(i)
    for i in ipset_list:
        if i not in ip_blocked:
            to_be_remove.append(i)
        
    if (len(to_be_add) + len(to_be_remove)) == 0:
        print("Nothing to update")
        return
       
    print("Updating ipset list")
    for i in to_be_remove:
        print("Removing: ", i)
        remove_ip_from_ipset(i)
    for i in to_be_add:
        print("Adding: ", i)
        add_ip_from_ipset(i)

def main():
    parser = argparse.ArgumentParser(description="Block SSH attacks by parsing auth.log and managing ipset.", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--db-file', default='block-ip.db', help='Path to the SQLite database file.')
    parser.add_argument('--log-file', default='/var/log/auth.log', help='Path to the auth log file.')
    parser.add_argument('--ipset-name', default='block-ssh-attack', help='Name of the ipset.')
    parser.add_argument('--retention-days', type=int, default=1, help='Number of days to keep IPs in the block list.')

    args = parser.parse_args()

    # Make variables from args available globally for other functions
    global VAR_AUTH_LOG, IPSET_NAME, RETENTION_DAY
    global db, cur, block_table_name, config_table_name

    VAR_AUTH_LOG = args.log_file
    IPSET_NAME = args.ipset_name
    RETENTION_DAY = args.retention_days

    db = sqlite3.connect(args.db_file)
    cur = db.cursor()
    block_table_name = "block_table"
    config_table_name = "config_table"

    print(f"====== start refresh block ssh ip [{dt.datetime.now(hkt)}]")
    init_db()
    found_data = find_from_file()
    digest_data(found_data)
    update_ipset_list()
    print(f"====== done [{dt.datetime.now(hkt)}]")

    db.close()

if __name__ == "__main__":
    main()