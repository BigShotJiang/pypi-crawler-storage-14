__version__ = "8.19.1"
USER_AGENT = f"parsedmarc/{__version__}"
