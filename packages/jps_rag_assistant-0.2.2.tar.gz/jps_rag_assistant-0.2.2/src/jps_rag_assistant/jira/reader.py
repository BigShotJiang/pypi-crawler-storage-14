from __future__ import annotations

from typing import List

import keyring
from llama_index.core import Document
from llama_index.readers.jira import JiraReader


def retrieve_data(base_url: str, email: str, days: int) -> List[Document]:
    """Load Jira issues assigned to current user and updated in the last N days.

    Uses Jira Personal Access Token stored in system keyring.

    Args:
        base_url: Jira instance base URL
        email: User email
        days: Lookback period in days

    Returns:
        List of Document objects

    Raises:
        ValueError: If no Jira API token found in keyring
    """
    api_token = keyring.get_password("jira", email)
    if not api_token:
        raise ValueError(f"No Jira API token found in keyring for {email}")

    reader = JiraReader(
        jira_base_url=base_url,
        email=email,
        api_token=api_token,
    )
    jql = f"assignee = currentUser() AND updated >= -{days}d"
    return reader.load_data(jql=jql)
