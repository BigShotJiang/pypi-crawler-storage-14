from __future__ import annotations

import logging
from typing import List

import keyring
from llama_index.core import Document

logger = logging.getLogger(__name__)


def retrieve_data(folder_names: List[str], calendar_days: int) -> List[Document]:
    """Load emails and calendar events from Microsoft Outlook/365 via Graph API (emails) + local (calendar).

    Emails: Uses Microsoft Graph API — cloud-based, works on Linux/macOS/Windows.
    Calendar: Uses local Outlook app — Windows/macOS only (graceful fallback on Linux).

    Credentials (for Graph API emails):
    - Service: "outlook-graph"
    - Username: your email (e.g., dude@msn.com)
    - Keys: client_id, client_secret, tenant_id (optional, defaults to "common")

    Install:
        pip install llama-index-readers-microsoft-outlook-emails

    Args:
        folder_names: Folders to fetch emails from (e.g., ["Inbox", "Sent Items"])
        calendar_days: Days back for calendar events

    Returns:
        Combined list of email + calendar Document objects
    """
    docs: List[Document] = []

    # ─── Emails via Graph API ───

    import os

    import yaml

    try:
        from llama_index.readers.microsoft_outlook_emails import OutlookEmailReader

        # Load email from YAML config
        config_path = os.path.expanduser("~/.config/jps-rag-assistant/config.yaml")
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        email = config.get("jira", {}).get("email")
        if not email:
            logger.warning("No email found in config under 'jira: email'. Skipping emails.")
            email_docs = []
        else:
            client_id = keyring.get_password("outlook-graph", f"{email}_client_id")
            client_secret = keyring.get_password("outlook-graph", f"{email}_client_secret")
            tenant_id = keyring.get_password("outlook-graph", f"{email}_tenant_id") or "common"

            if not all([client_id, client_secret]):
                logger.warning(
                    f"Graph API credentials missing for {email}. Skipping emails. "
                    "Set via: keyring set outlook-graph {email}_client_id <id>"
                )
                email_docs = []
            else:
                reader = OutlookEmailReader(
                    client_id=client_id,
                    client_secret=client_secret,
                    tenant_id=tenant_id,
                )
                # Fetch from specified folders (Graph API supports this)
                for folder in folder_names:
                    folder_docs = reader.load_data(
                        folder_name=folder,
                        max_results=100,  # Configurable later
                    )
                    email_docs.extend(folder_docs)
                logger.info(f"Loaded {len(email_docs)} email documents")

    except ImportError as e:
        logger.error(
            f"Email reader not installed: {e}. Install with: "
            "pip install llama-index-readers-microsoft-outlook-emails"
        )
        email_docs = []
    except Exception as e:
        logger.error(f"Failed to load emails: {e}")
        email_docs = []

    docs.extend(email_docs)

    # ─── Calendar (local fallback) ───
    try:
        from llama_index.readers.microsoft_outlook import MicrosoftOutlookReader

        calendar_reader = MicrosoftOutlookReader()
        calendar_docs = calendar_reader.load_data_calendar(days=calendar_days)
        logger.info(f"Loaded {len(calendar_docs)} calendar events")
    except ImportError:
        logger.warning("Local calendar reader not available (Linux?). Skipping calendar.")
        calendar_docs = []
    except Exception as e:
        logger.warning(f"Failed to load calendar (may need local Outlook): {e}")
        calendar_docs = []

    docs.extend(calendar_docs)
    return docs
