from __future__ import annotations

import os
from pathlib import Path
from typing import List

from llama_index.core import (
    Document,
    Settings,
    StorageContext,
    VectorStoreIndex,
    load_index_from_storage,
)
from llama_index.core.node_parser import SentenceSplitter

# Use a fast, pure-Python, CPU-only HuggingFace model in tests
from llama_index.embeddings.huggingface import HuggingFaceEmbedding
from llama_index.embeddings.ollama import OllamaEmbedding
from llama_index.llms.ollama import Ollama

from .config import Config  # Now we pull everything from config

# Detect pytest to avoid real Ollama calls
UNDER_TEST = os.environ.get("PYTEST_CURRENT_TEST") is not None


def build_or_update_index(
    documents: List[Document],
    config: Config,  # ← Pass full config instead of just persist_dir
) -> VectorStoreIndex:
    """Build a new index or incrementally update an existing one.

    All embedding, LLM, and chunking settings are driven by the YAML config.

    Args:
        documents: List of Document objects to index
        config: Full application configuration

    Returns:
        The built or updated VectorStoreIndex
    """
    persist_dir = Path(config.vector_store.persist_dir).expanduser().resolve()
    persist_dir.mkdir(parents=True, exist_ok=True)

    # Use fast, offline-capable HuggingFace model under pytest
    if UNDER_TEST:
        # all-MiniLM-L6-v2 = 80MB, very fast on CPU, excellent quality, works offline after first download
        Settings.embed_model = HuggingFaceEmbedding(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )
        Settings.llm = None  # LLM not needed for embedding-only tests
    else:
        Settings.embed_model = OllamaEmbedding(model_name=config.ollama.embedding)
        Settings.llm = Ollama(
            model=config.ollama.model,
            request_timeout=config.ollama.request_timeout,
        )

    Settings.node_parser = SentenceSplitter(
        chunk_size=config.chunking.chunk_size,
        chunk_overlap=config.chunking.chunk_overlap,
    )

    docstore_path = persist_dir / "docstore.json"

    if docstore_path.exists():
        # Existing index: load and append documents
        storage_context = StorageContext.from_defaults(persist_dir=str(persist_dir))
        index = load_index_from_storage(
            storage_context,
            show_progress=config.vector_store.show_progress,
        )
        for doc in documents:
            index.insert(doc)
        print(f"Updated existing index with {len(documents)} new/updated documents")
    else:
        # New index: start with a fresh storage context and persist afterwards
        storage_context = StorageContext.from_defaults()
        index = VectorStoreIndex.from_documents(
            documents,
            storage_context=storage_context,
            show_progress=config.vector_store.show_progress,
        )
        print(f"Created new index with {len(documents)} documents")

    index.storage_context.persist(persist_dir=str(persist_dir))
    return index
