#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Unified help command for the jps-rag-assistant suite.

This script provides a friendly, richly formatted overview of the
jps-rag-assistant CLI tools — perfect for onboarding and daily use.

Usage:
    jps-rag-help
    python -m jps_rag_assistant.help
"""

import textwrap
from pathlib import Path

# ANSI colour codes (terminal-safe)
GREEN = "\033[92m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"
BOLD = "\033[1m"
RESET = "\033[0m"


def main() -> None:
    """Print a beautifully formatted help overview of all jps-rag-assistant commands."""
    config_path = Path("~/.config/jps-rag-assistant/config.yaml").expanduser()

    help_text = textwrap.dedent(
        f"""
        {CYAN}{BOLD}jps-rag-assistant — Your Private Local RAG Brain{YELLOW}
        {'=' * 68}{RESET}

        A 100% local, secure, and fully configurable Retrieval-Augmented Generation
        assistant that turns your personal knowledge from Outlook, Jira, and Confluence
        into a powerful, private AI memory — powered by LlamaIndex + Ollama.

        All data stays on your machine. No cloud. No leaks. No compromises.

        {GREEN}Available Commands{RESET}

        {GREEN}jps-rag-assistant-ingest{RESET}
            Ingest and incrementally update your personal vector store.
            • Pulls emails + calendar from Outlook
            • Loads your assigned/updated Jira issues
            • Indexes Confluence spaces (including ~personal)
            • Concurrent loading, incremental updates, zero hard-coded values
            • Secure auth via system keyring (Jira PAT + Confluence OAuth2 token)
            • Persists to {MAGENTA}{config_path}{RESET}

            {YELLOW}Examples:{RESET}
                jps-rag-assistant-ingest
                jps-rag-assistant-ingest --config-file ~/my-rag-config.yaml
                jps-rag-assistant-ingest --logfile /tmp/my-run.log

        {GREEN}jps-rag-help{RESET}
            Show this beautiful help overview (you are here)

        ------------------------------------------------------------
        {CYAN}Coming Soon (ask Jaideep to build them):{RESET}
            • {MAGENTA}jps-rag-chat{RESET}        → Interactive chat with sources & streaming
            • {MAGENTA}jps-rag-query{RESET}       → One-shot natural language queries
            • {MAGENTA}jps-rag-web{RESET}         → Local web UI (FastAPI + React)
            • {MAGENTA}jps-rag-speak{RESET}       → Voice mode (whisper + TTS)

        {YELLOW}Pro Tip:{RESET} Run any command with `--help` for full options and examples.

        {CYAN}Configuration:{RESET}  ~/.config/jps-rag-assistant/config.yaml
        {CYAN}Vector Store:{RESET}   {MAGENTA}{config_path.parent}{RESET}
        {CYAN}Project:{RESET}        https://github.com/jai-python3/jps-rag-assistant
        {CYAN}Built with care by Jaideep Sundaram{RESET}

        {BOLD}Your data. Your model. Your rules.{RESET}
        """
    ).strip()

    print(help_text + "\n")


if __name__ == "__main__":
    main()
