from __future__ import annotations

import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from llama_index.core import Document

from .config import Config
from .confluence import reader as confluence_reader
from .jira import reader as jira_reader
from .msoutlook import reader as outlook_reader
from .vector_store import build_or_update_index


def ingest_all(config: Config) -> None:
    """Main ingestion orchestrator with concurrency.

    Args:
        config: Config object with all settings
    """
    tasks = [
        (
            "Outlook",
            lambda: outlook_reader.retrieve_data(
                folder_names=config.outlook.folder_names,
                calendar_days=config.outlook.days,
            ),
        ),
        (
            "Jira",
            lambda: jira_reader.retrieve_data(
                base_url=config.jira.base_url,
                email=config.jira.email,
                days=config.jira.days,
            ),
        ),
        (
            "Confluence",
            lambda: confluence_reader.retrieve_data(
                base_url=config.confluence.base_url,
                space_keys=config.confluence.space_keys,
                email=config.jira.email,  # assuming same user
            ),
        ),
    ]

    all_docs: list[Document] = []

    with ThreadPoolExecutor(max_workers=3) as executor:
        future_to_name = {executor.submit(fn): name for name, fn in tasks}
        for future in as_completed(future_to_name):
            name = future_to_name[future]
            try:
                docs = future.result()
                count = len(docs)
                print(f"{name}: Loaded {count} documents")
                all_docs.extend(docs)
            except Exception as exc:
                print(f"{name} generated an exception: {exc}", file=sys.stderr)

    if not all_docs:
        print("No documents loaded from any source.")
        return

    persist_dir = Path(config.vector_store.persist_dir).expanduser().resolve()
    build_or_update_index(
        documents=all_docs,
        config=config,
    )
    print(f"Ingestion complete. Vector store: {persist_dir}")
