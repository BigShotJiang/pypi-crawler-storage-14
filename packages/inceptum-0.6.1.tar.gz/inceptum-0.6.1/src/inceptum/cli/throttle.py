__all__ = ['throttle']

from random import randint
from time import sleep

def throttle(input, delay=3, burst=None, burst_delay=2000):
    b = None
    for a in input:
        yield a
        if burst is not None:
            if b is None or b == 0:
                b = randint(*burst) if isinstance(burst, (tuple, list)) else burst
            b -= 1
            if b == 0:
                sleep(
                    randint(*burst_delay)
                    if isinstance(burst_delay, (tuple, list)) else
                    burst_delay
                )
        sleep(
            randint(*delay)
            if isinstance(delay, (tuple, list)) else
            delay
        )
