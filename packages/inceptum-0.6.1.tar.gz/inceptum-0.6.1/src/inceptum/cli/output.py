__all__ = ['output']

from io import BytesIO
import sys

from ..require import require

# FIXME
isiterator = require('isiterator')
to_json = require('to_json')

def output(result, fn=None, raw=False):
    if getattr(fn, 'no_result', False): return
    if isiterator(result):
        for a in result:
            output(a, fn, raw)
    elif isinstance(result, bytes):
        sys.stdout.buffer.write(result)
    elif hasattr(result, 'getpixel'):
        # assume result is an instance of PIL.Image
        buffer = BytesIO()
        result.save(buffer, format='JPEG')
        sys.stdout.buffer.write(buffer.getvalue())
    elif isinstance(result, (str, bytes)) and (raw or getattr(fn, 'raw_output', False)):
        sys.stdout.write(result)
    else:
        print(to_json(result), flush=True)
