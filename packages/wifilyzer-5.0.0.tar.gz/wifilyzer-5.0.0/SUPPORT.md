# Support

## Getting Help

If you encounter issues or have questions:

### 1. Check Documentation
- Review the [README.md](README.md) for usage instructions
- Consult [COMPREHENSIVE_WIFI6_ANALYSIS_GUIDE_v2.docx](COMPREHENSIVE_WIFI6_ANALYSIS_GUIDE_v2.docx) for detailed analysis
- Check [FILE_INDEX.md](FILE_INDEX.md) for project structure

### 2. Search Existing Issues
Before creating a new issue, search [existing issues](https://github.com/YOUR_USERNAME/wifi-pcap-toolkit/issues) to see if your question has been answered.

### 3. Create an Issue
If you can't find an answer, create a new issue:
- [Bug Report](https://github.com/YOUR_USERNAME/wifi-pcap-toolkit/issues/new?template=bug_report.yml) - Report bugs
- [Feature Request](https://github.com/YOUR_USERNAME/wifi-pcap-toolkit/issues/new?template=feature_request.yml) - Suggest enhancements

### 4. Community Support
- Review [Discussions](https://github.com/YOUR_USERNAME/wifi-pcap-toolkit/discussions) for community help
- Check [Stack Overflow](https://stackoverflow.com/questions/tagged/scapy+wifi) for Scapy-related questions

## Reporting Security Issues
Please see [SECURITY.md](SECURITY.md) for reporting security vulnerabilities.

## Contributing
Interested in contributing? See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Commercial Support
For commercial support, training, or custom development:
- Create an issue with the `commercial-inquiry` label
- Email: [Your contact method here]

## Response Times
- **Security Issues**: Within 48 hours
- **Bugs**: Within 1 week
- **Feature Requests**: Within 2 weeks
- **Questions**: Best effort basis

## What to Include in Support Requests
1. **Environment**:
   - OS and version
   - Python version
   - Scapy version
   - Wireshark version (if applicable)

2. **Problem Description**:
   - What you tried to do
   - What happened
   - What you expected to happen

3. **Reproducible Example**:
   - Command or code that triggers the issue
   - Full error message/traceback
   - Sample PCAP files (if applicable and safe to share)

4. **Steps Already Taken**:
   - Troubleshooting steps you've tried
   - Documentation you've consulted

## Resources
- [Scapy Documentation](https://scapy.readthedocs.io/)
- [Wireshark User Guide](https://www.wireshark.org/docs/wsug_html_chunked/)
- [802.11ax Standard (IEEE)](https://standards.ieee.org/standard/802_11ax-2021.html)
- [WiFi Alliance](https://www.wi-fi.org/)
