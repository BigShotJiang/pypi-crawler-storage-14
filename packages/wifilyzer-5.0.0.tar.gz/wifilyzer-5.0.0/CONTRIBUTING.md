# Contributing to WiFi Analysis Tool Suite

Thank you for considering contributing to this project! 🎉

## How to Contribute

### Reporting Bugs

If you find a bug, please open an issue with:
- A clear description of the problem
- Steps to reproduce
- Expected vs actual behavior
- Your environment (OS, Python version, Wireshark version)
- Any relevant pcap files or screenshots

### Suggesting Enhancements

We welcome suggestions! Please open an issue describing:
- The enhancement or feature
- Why it would be useful
- How it should work
- Any examples or references

### Pull Requests

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Make your changes**
   - Follow the existing code style
   - Add comments for complex logic
   - Update documentation if needed
4. **Test your changes**
   ```bash
   python wifi_analysis_tool.py generate
   python wifi_analysis_tool.py analyze comprehensive_wifi6_test.pcap --summary
   ```
5. **Commit with clear messages**
   ```bash
   git commit -m "Add amazing feature: description"
   ```
6. **Push to your fork**
   ```bash
   git push origin feature/amazing-feature
   ```
7. **Open a Pull Request**

## Development Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/wifi-analysis-tool.git
cd wifi-analysis-tool

# Create virtual environment
python -m venv .venv

# Activate virtual environment
# On Windows:
.venv\Scripts\activate
# On Linux/Mac:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

## Code Style

- Follow PEP 8 guidelines
- Use meaningful variable names
- Add docstrings to functions and classes
- Keep functions focused and concise
- Comment complex logic

## Testing

Before submitting a PR, ensure:
- [ ] Packet generation works
- [ ] Packet analysis works
- [ ] No Python errors or warnings
- [ ] Documentation is updated
- [ ] Code is formatted properly

## Areas for Contribution

- WiFi 6E (6 GHz band) support
- WPA3 SAE authentication scenarios
- 802.11k/v/r roaming analysis
- GUI interface
- Additional analysis features
- Performance improvements
- Documentation improvements
- Test coverage
- Bug fixes

## Questions?

Feel free to open an issue for any questions about contributing.

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
