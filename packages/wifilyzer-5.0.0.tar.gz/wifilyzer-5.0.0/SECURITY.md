# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability

If you discover a security vulnerability, please:

1. **DO NOT** open a public issue
2. Email the maintainers privately (or use GitHub's private vulnerability reporting)
3. Include:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

We will respond within 48 hours and work with you to address the issue.

## Security Considerations

### PCAP Files
- Generated PCAP files contain synthetic test data only
- Do NOT use real network captures with sensitive information in public issues
- Sanitize any real captures before sharing

### Network Analysis
- This tool is for educational and testing purposes
- Always have permission before capturing network traffic
- Follow local laws and regulations regarding network monitoring

### Dependencies
- We regularly update dependencies to patch security vulnerabilities
- Review `requirements.txt` before installation
- Use virtual environments to isolate dependencies

## Best Practices

When using this tool:
- Run in isolated test environments
- Don't capture production network traffic without authorization
- Review generated packets before using in production environments
- Keep your Wireshark and Python installations updated
