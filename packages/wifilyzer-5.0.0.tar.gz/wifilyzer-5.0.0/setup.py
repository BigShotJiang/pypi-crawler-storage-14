"""
Wifilyzer - Complete WiFi 4/5/6/7 Analysis Platform
Setup configuration for PyPI distribution
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8")

setup(
    name="wifilyzer",
    version="5.0.0",
    author="Niresh Shanmugam",
    author_email="niresh.shanmugam@gmail.com",
    description="Complete WiFi 4/5/6/7 packet analysis platform with 23 detection categories including security, beamforming, RRM, QoS, and power management",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nireshshanmugam/wifilyzer",
    project_urls={
        "Bug Reports": "https://github.com/nireshshanmugam/wifilyzer/issues",
        "Documentation": "https://github.com/nireshshanmugam/wifilyzer#readme",
        "Source": "https://github.com/nireshshanmugam/wifilyzer",
    },
    packages=find_packages(exclude=["tests", "archive", "*.pcap"]),
    # Include the top-level module file wifilyzer.py so console entry works
    py_modules=["wifilyzer"],
    classifiers=[
        # Development status
        "Development Status :: 5 - Production/Stable",

        # Intended audience
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "Intended Audience :: Telecommunications Industry",
        "Intended Audience :: Information Technology",

        # Topics
        "Topic :: System :: Networking :: Monitoring",
        "Topic :: System :: Networking",
        "Topic :: Security",
        "Topic :: System :: Systems Administration",
        "Topic :: Software Development :: Libraries :: Python Modules",

        # License
        "License :: OSI Approved :: MIT License",

        # Python versions
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",

        # OS support
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",

        # Natural language
        "Natural Language :: English",
    ],
    keywords=[
        "wifi", "wifi6", "wifi7", "802.11ax", "802.11be",
        "network-analysis", "packet-analysis", "scapy",
        "wireless", "security", "beamforming", "ofdma",
        "roaming", "rrm", "qos", "wmm", "power-save",
        "network-monitoring", "pcap", "wireshark"
    ],
    python_requires=">=3.8",
    install_requires=[
        "scapy>=2.5.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "flake8>=6.0",
            "mypy>=1.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "wifilyzer=wifilyzer:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.md", "LICENSE"],
    },
    zip_safe=False,
)
