oc delete -f install.yml
