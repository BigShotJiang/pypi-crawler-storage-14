from framework_mcp_client.cli import main

if __name__ == "__main__":
    main()
