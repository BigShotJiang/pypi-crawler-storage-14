"""
Standalone MCP HTTP client for forwarding stdio RPC calls to the remote
framework-mcp server. This script intentionally lives outside of the
`framework_mcp` package so that it only depends on `httpx`.
"""

import asyncio
import json
import os
import sys

try:
    import httpx
except ImportError:
    print("Error: httpx is required. Install with `pip install httpx`.", file=sys.stderr)
    sys.exit(1)


MCP_SERVER_URL = os.environ.get("MCP_SERVER_URL", "http://127.0.0.1:8000")
MCP_SERVER_TOKEN = os.environ.get("MCP_SERVER_TOKEN")


async def forward_request(payload: dict) -> dict | None:
    """Forward the JSON-RPC payload to the remote server via HTTP."""
    headers = {"Content-Type": "application/json"}
    if MCP_SERVER_TOKEN:
        headers["Authorization"] = f"Bearer {MCP_SERVER_TOKEN}"

    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.post(f"{MCP_SERVER_URL}/mcp", json=payload, headers=headers)
        if response.status_code == 204 or not response.content.strip():
            return None
        response.raise_for_status()
        return response.json()


async def handle_line(raw_line: str) -> None:
    """Handle a single line (JSON-RPC request) from stdin."""
    raw_line = raw_line.strip()
    if not raw_line:
        return

    try:
        payload = json.loads(raw_line)
    except json.JSONDecodeError as exc:
        error = {
            "jsonrpc": "2.0",
            "error": {"code": -32700, "message": "Parse error", "data": str(exc)},
            "id": None,
        }
        print(json.dumps(error), flush=True)
        return

    try:
        result = await forward_request(payload)
        if result is not None:
            print(json.dumps(result), flush=True)
    except httpx.HTTPError as exc:
        error = {
            "jsonrpc": "2.0",
            "error": {"code": -32000, "message": "HTTP request failed", "data": str(exc)},
            "id": payload.get("id"),
        }
        print(json.dumps(error), flush=True)
    except Exception as exc:
        error = {
            "jsonrpc": "2.0",
            "error": {"code": -32603, "message": "Internal error", "data": str(exc)},
            "id": payload.get("id"),
        }
        print(json.dumps(error), flush=True)


def main() -> None:
    """Entry point for the CLI client."""
    print(f"[framework-mcp client] forwarding requests to {MCP_SERVER_URL}", file=sys.stderr)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    try:
        while True:
            line = sys.stdin.readline()
            if not line:
                break
            loop.run_until_complete(handle_line(line))
    except KeyboardInterrupt:
        pass
    finally:
        loop.close()


if __name__ == "__main__":
    main()


