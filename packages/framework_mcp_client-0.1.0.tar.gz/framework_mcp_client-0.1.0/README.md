# Framework MCP Client

轻量级 HTTP 客户端代理，用于将 Cursor IDE 的 stdio 请求转发到远程 Framework MCP 服务器。

## 安装

### 从本地项目安装

```bash
# 进入客户端目录
cd client

# 使用 pip 安装
pip install -e .

# 或使用 uv
uv pip install -e .
```

### 从 Git 仓库安装（如果已发布）

```bash
pip install git+https://github.com/your-org/framework-mcp.git#subdirectory=client
```

### 从 PyPI 安装（如果已发布）

```bash
pip install framework-mcp-client
```

## 使用方法

### 在 Cursor IDE 中配置

在 Cursor 的 `mcp.json` 配置文件中添加：

```json
{
  "mcpServers": {
    "framework-mcp": {
      "command": "framework-mcp-client",
      "env": {
        "MCP_SERVER_URL": "http://your-server:8000",
        "MCP_SERVER_TOKEN": "可选：如果服务端开启鉴权"
      }
    }
  }
}
```

### 环境变量

- `MCP_SERVER_URL`（必需）：MCP 服务器的 HTTP 地址，例如 `http://localhost:8000`
- `MCP_SERVER_TOKEN`（可选）：如果服务器启用了认证，提供 Bearer Token

## 验证安装

```bash
# 检查命令是否可用
which framework-mcp-client  # Linux/Mac
where framework-mcp-client   # Windows

# 测试连接（需要服务器运行）
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}' | framework-mcp-client
```

## 依赖

- Python 3.11+
- httpx >= 0.25.0

## 打包发布

### 构建分发包

```bash
cd client
python -m build
```

### 发布到 PyPI

```bash
pip install twine
twine upload dist/*
```

### 发布到内部 PyPI

```bash
twine upload --repository internal dist/*
```

## 许可证

与主项目相同

