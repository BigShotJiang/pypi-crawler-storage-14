"""Unit test package for keep_gpu."""
