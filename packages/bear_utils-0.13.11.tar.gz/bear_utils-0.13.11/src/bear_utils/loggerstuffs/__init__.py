"""A server and client for logging over HTTP."""
