from pathlib import Path
import json


def test_csv_ingest(tmp_path):
    csv = """
    127.0.0.1,443,tcp,https,nginx,1.20
    127.0.0.1,22,tcp,ssh,,
    """.strip()
    allow = tmp_path / "allow.txt"
    allow.write_text("127.0.0.1\n", encoding="utf-8")
    csv_file = tmp_path / "assets.csv"
    csv_file.write_text(csv, encoding="utf-8")

    from security_hyacinth.core.run import AuditContext, ingest_data
    ctx = AuditContext(str(allow), dry_run=True, log_file=None, config_path=None)
    raw = ingest_data(ctx, nmap_path=None, csv_path=str(csv_file))
    assert len(raw["assets"]) == 1
    assert len(raw["assets"][0]["ports"]) == 2

