# HOS_SecGuardian

合规的 AI 安全审计与风险分析工具。支持在授权范围内进行资产导入、风险映射、AI 辅助建议与报告生成。

## 安装与使用

```bash
pip install HOS_SecGuardian
hos --help
```

## 重要说明

必须提供允许列表文件并在授权目标范围内运行。默认启用干跑模式。严禁用于任何未授权渗透或攻击。
