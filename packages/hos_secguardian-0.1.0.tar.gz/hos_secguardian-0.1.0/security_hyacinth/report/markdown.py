from typing import Dict, Any, List


def render_markdown(analyzed: Dict[str, Any]) -> str:
    lines: List[str] = []
    lines.append("# HOS SecGuardian Report")
    lines.append("")
    lines.append("## Assets")
    for a in analyzed.get("assets", []):
        lines.append(f"- {a.get('address')}")
        for p in a.get("ports", []):
            lines.append(f"  - {p.get('port')}/{p.get('protocol')} {p.get('service')}")
    lines.append("")
    lines.append("## Top Risks")
    risk = analyzed.get("risk", [])
    for r in risk[:10]:
        lines.append(f"- {r.get('address')}:{r.get('port')} {r.get('service')} severity {r.get('severity')}")
    lines.append("")
    lines.append("## Recommendations")
    for x in analyzed.get("analysis", []):
        lines.append(f"- {x.get('address')}:{x.get('port')} {x.get('service')} → {x.get('recommendation')}")
    return "\n".join(lines)
