from typing import Dict, Any


def render_html(analyzed: Dict[str, Any]) -> str:
    md = []
    md.append("<html><head><meta charset=\"utf-8\"><title>Hyacinth Report</title></head><body>")
    md.append("<h1>HOS SecGuardian Report</h1>")
    md.append("<h2>Assets</h2>")
    md.append("<ul>")
    for a in analyzed.get("assets", []):
        md.append(f"<li>{a.get('address')}<ul>")
        for p in a.get("ports", []):
            md.append(f"<li>{p.get('port')}/{p.get('protocol')} {p.get('service')}</li>")
        md.append("</ul></li>")
    md.append("</ul>")
    md.append("<h2>Top Risks</h2><ul>")
    risk = analyzed.get("risk", [])
    for r in risk[:10]:
        md.append(f"<li>{r.get('address')}:{r.get('port')} {r.get('service')} severity {r.get('severity')}</li>")
    md.append("</ul>")
    md.append("<h2>Recommendations</h2><ul>")
    for x in analyzed.get("analysis", []):
        md.append(f"<li>{x.get('address')}:{x.get('port')} {x.get('service')} → {x.get('recommendation')}</li>")
    md.append("</ul>")
    md.append("</body></html>")
    return "".join(md)
