import json
import logging
import os
from pathlib import Path
from typing import List, Dict, Any
from ..io.nmap import parse_nmap_xml
from ..io.csv import parse_csv
from ..vuln.mapping import map_risk
from ..ai.analyzer import Analyzer
from ..report.markdown import render_markdown
from ..report.html import render_html


class AuditContext:
    def __init__(self, allowlist_path: str | None, dry_run: bool, log_file: str | None, config_path: str | None):
        self.allowlist = set()
        if allowlist_path and Path(allowlist_path).exists():
            self.allowlist = set([l.strip() for l in Path(allowlist_path).read_text(encoding="utf-8").splitlines() if l.strip()])
        self.dry_run = True if dry_run else False
        self.log_file = log_file
        self.config_path = config_path
        self.logger = logging.getLogger("hyacinth")
        self.logger.setLevel(logging.INFO)
        handlers = []
        ch = logging.StreamHandler()
        handlers.append(ch)
        if self.log_file:
            fh = logging.FileHandler(self.log_file, encoding="utf-8")
            handlers.append(fh)
        fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
        for h in handlers:
            h.setFormatter(fmt)
            self.logger.addHandler(h)

    def check_targets(self, assets: List[Dict[str, Any]]):
        if not self.allowlist:
            raise RuntimeError("allowlist is required")
        filtered = []
        for a in assets:
            host = a.get("address")
            if host in self.allowlist:
                filtered.append(a)
        return filtered


def ingest_data(ctx: AuditContext, nmap_path: str | None, csv_path: str | None = None) -> Dict[str, Any]:
    ctx.logger.info("ingest start")
    assets: List[Dict[str, Any]] = []
    if nmap_path and Path(nmap_path).exists():
        assets = parse_nmap_xml(Path(nmap_path).read_text(encoding="utf-8"))
    if csv_path and Path(csv_path).exists():
        csv_assets = parse_csv(Path(csv_path).read_text(encoding="utf-8"))
        assets.extend(csv_assets)
    assets = ctx.check_targets(assets)
    return {"assets": assets}


def analyze_findings(ctx: AuditContext, raw: Dict[str, Any], cve_feed_path: str | None) -> Dict[str, Any]:
    ctx.logger.info("analyze start")
    assets = raw.get("assets", [])
    cve_feed: Dict[str, Any] = {}
    if cve_feed_path and Path(cve_feed_path).exists():
        cve_feed = json.loads(Path(cve_feed_path).read_text(encoding="utf-8"))
    risk = map_risk(assets, cve_feed)
    analyzer = Analyzer()
    reviewed = analyzer.review(risk)
    return {"assets": assets, "risk": risk, "analysis": reviewed}


def generate_report(ctx: AuditContext, analyzed: Dict[str, Any], fmt: str) -> str:
    ctx.logger.info("report start")
    if fmt == "md":
        return render_markdown(analyzed)
    if fmt == "html":
        return render_html(analyzed)
    return ""

