import xml.etree.ElementTree as ET
from typing import List, Dict, Any


def parse_nmap_xml(xml_text: str) -> List[Dict[str, Any]]:
    assets: List[Dict[str, Any]] = []
    root = ET.fromstring(xml_text)
    for host in root.findall("host"):
        status = host.find("status")
        if status is not None and status.get("state") != "up":
            continue
        address_el = host.find("address")
        addr = address_el.get("addr") if address_el is not None else None
        ports = []
        ports_el = host.find("ports")
        if ports_el is not None:
            for p in ports_el.findall("port"):
                portid = p.get("portid")
                proto = p.get("protocol")
                state_el = p.find("state")
                state = state_el.get("state") if state_el is not None else None
                service_el = p.find("service")
                name = service_el.get("name") if service_el is not None else None
                product = service_el.get("product") if service_el is not None else None
                version = service_el.get("version") if service_el is not None else None
                ports.append({
                    "port": int(portid) if portid else None,
                    "protocol": proto,
                    "state": state,
                    "service": name,
                    "product": product,
                    "version": version,
                })
        assets.append({
            "address": addr,
            "ports": ports,
        })
    return assets

