import argparse
import json
import os
import sys
from pathlib import Path
from .core.run import ingest_data, analyze_findings, generate_report, AuditContext


def main():
    parser = argparse.ArgumentParser(prog="hos")
    subparsers = parser.add_subparsers(dest="command")

    parser.add_argument("--allowlist", type=str, default=None)
    parser.add_argument("--dry-run", action="store_true", default=True)
    parser.add_argument("--log-file", type=str, default=None)
    parser.add_argument("--config", type=str, default=None)

    ingest = subparsers.add_parser("ingest")
    ingest.add_argument("--nmap", type=str, default=None)
    ingest.add_argument("--csv", type=str, default=None)
    ingest.add_argument("--out", type=str, required=True)

    analyze = subparsers.add_parser("analyze")
    analyze.add_argument("--input", type=str, required=True)
    analyze.add_argument("--cve-feed", type=str, default=None)
    analyze.add_argument("--out", type=str, required=True)

    report = subparsers.add_parser("report")
    report.add_argument("--input", type=str, required=True)
    report.add_argument("--format", type=str, choices=["md", "html"], default="md")
    report.add_argument("--out", type=str, required=True)

    args = parser.parse_args()

    audit = AuditContext(
        allowlist_path=args.allowlist,
        dry_run=args.dry_run,
        log_file=args.log_file,
        config_path=args.config,
    )

    if args.command == "ingest":
        data = ingest_data(audit, nmap_path=args.nmap, csv_path=args.csv)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return

    if args.command == "analyze":
        raw = json.loads(Path(args.input).read_text(encoding="utf-8"))
        findings = analyze_findings(audit, raw, cve_feed_path=args.cve_feed)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(findings, ensure_ascii=False, indent=2), encoding="utf-8")
        return

    if args.command == "report":
        analyzed = json.loads(Path(args.input).read_text(encoding="utf-8"))
        content = generate_report(audit, analyzed, fmt=args.format)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(content, encoding="utf-8")
        return

    parser.print_help()


if __name__ == "__main__":
    main()

