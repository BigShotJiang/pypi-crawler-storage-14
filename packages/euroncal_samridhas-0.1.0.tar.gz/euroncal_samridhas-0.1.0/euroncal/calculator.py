def add(a,b):
    """This will return addition of 2 nos"""
    return a+b

def subtract(a,b):
    """This will return substraction of 2 nos"""
    return a-b

def multiply(a,b):
    """This will product of 2 nos"""
    return a*b

def divide(a,b):
    """This will return division of 2 nos"""
    if b==0:
        raise ValueError("Divide by Zero")
    return a/b

def power (a,b):
    """This will return a to the power b"""
    return a**b
    
