# euroncal-samridhas

A simple Python package for basic calculator operations 

## 📦 Installation

```bash
pip install euroncal-samridhas