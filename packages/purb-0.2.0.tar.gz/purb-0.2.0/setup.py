from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any, Callable


def _require(attribute: str) -> Callable[..., Any]:
    try:
        module = importlib.import_module("setuptools")
    except ModuleNotFoundError as exc:  # pragma: no cover - setup guard
        raise RuntimeError(
            "setuptools must be installed before running setup.py"
        ) from exc
    return getattr(module, attribute)


setup: Callable[..., Any] = _require("setup")
find_packages: Callable[..., Any] = _require("find_packages")

README = Path(__file__).with_name("README.md")
long_description = README.read_text(encoding="utf-8") if README.exists() else ""

setup(
    name="purb",
    version="0.2.0",
    description="Distribute and print the ML lab programs for quick reference.",
    long_description="Made for the usage of quick fetch of all the ml lab programs",
    long_description_content_type="text/markdown" if long_description else "text/plain",
    author="Devanshk09",
    author_email="devanshkhetan9@gmail.com",
    url="https://nishpi.com/purb",
    packages=find_packages(exclude=("tests", "tests.*")),
    include_package_data=True,
    python_requires=">=3.10",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Education",
        "Topic :: Education",
    ],
    entry_points={
        "console_scripts": ["purb=purb.cli:main"],
    },
)