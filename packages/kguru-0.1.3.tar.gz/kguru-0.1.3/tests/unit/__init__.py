"""Unit tests for kguru package."""
