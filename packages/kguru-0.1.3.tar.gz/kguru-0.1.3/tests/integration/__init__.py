"""Integration tests for kguru package."""
