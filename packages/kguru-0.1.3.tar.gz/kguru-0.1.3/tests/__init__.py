# Tests for kguru package
