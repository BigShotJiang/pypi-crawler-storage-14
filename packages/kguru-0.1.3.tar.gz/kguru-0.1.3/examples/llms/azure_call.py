"""Example of using Azure OpenAI LLM provider."""

import asyncio
from pprint import pprint

from kguru.core.reasoning.llm.azure import AzureOpenAILLM


async def _validate():
    """Internal validation logic."""
    reasoning = AzureOpenAILLM()

    print("\n--- Azure Configuration ---")

    # Mask API key for security
    masked_key = (reasoning.api_key[:5] + "..." + reasoning.api_key[-4:]) if reasoning.api_key else "Not set"

    print(f"API Key: {masked_key}")
    print(f"Endpoint: {reasoning.azure_endpoint}")
    print(f"API Version: {reasoning.api_version}")
    print(f"Deployment: {reasoning.deployment}")
    print("---------------------------\n")

    print("Running a simple reasoning test...")

    result = await reasoning.reason_structure(
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {
                "role": "user",
                "content": "Briefly explain the theory of relativity in simple terms. Output in JSON with a single key 'explanation'.",
            },
        ]
    )

    print("\n--- Test Output ---")
    pprint(result)
    print("---------------------\n")

    print("Azure configuration and test successful.")


if __name__ == "__main__":
    asyncio.run(_validate())
