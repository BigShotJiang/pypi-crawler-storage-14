# Release Process

Simple guide for releasing kguru to PyPI.

## PyPI Profiles

Your machine has 3 PyPI profiles configured in `~/.pypirc`:

1. **pypi** (default) - Standard PyPI repository - DONOT use this
2. **pypi-llasea** - Alternative PyPI profile -  ✅ **Use this for kguru**
3. **dana** - Alternative PyPI profile - DONOT use this

## Pre-Release Checklist

1. **Update version** in `pyproject.toml`:
   ```toml
   version = "0.1.1"  # Update this
   ```

2. **Run tests**:
   ```bash
   make test
   ```

3. **Format and lint**:
   ```bash
   make all
   ```

## Release Steps

### 1. Clean previous builds
```bash
make clean
```

### 2. Build the package
```bash
uv build
```

This creates:
- `dist/kguru-{version}.tar.gz` (source distribution)
- `dist/kguru-{version}-py3-none-any.whl` (wheel)

### 3. Verify build contents (optional)
```bash
tar -tzf dist/kguru-*.tar.gz | head -20
unzip -l dist/kguru-*.whl
```

### 4. Upload to PyPI
```bash
twine upload --repository pypi-llasea dist/*
```

### 5. Verify release
Visit: `https://pypi.org/project/kguru/{version}/`

Test installation:
```bash
pip install kguru=={version}
```

## Quick Release (All Steps)

```bash
# Update version in pyproject.toml first!
make clean && make test && make all
uv build
twine upload --repository pypi-llasea dist/*
```

## Notes

- Always use the **pypi-llasea** profile for kguru releases
- Version format: `MAJOR.MINOR.PATCH` (e.g., 0.1.0, 0.1.1, 0.2.0)
- Package name is `kguru` (cannot be changed once published)
- Requires Python >=3.12
