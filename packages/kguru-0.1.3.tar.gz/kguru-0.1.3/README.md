# kguru

An AI agent platform for Python with domain-specific knowledge capabilities.

## Features

- **Agentic Framework**: Reasoning loop with human-in-the-loop for intelligent problem-solving
- **Domain Learning**: Learns from domain-specific knowledge and user feedback
- **Dynamic Knowledge Base**: Build and assemble knowledge on the fly from structured, semi-structured, and semantic vector sources
- **Multi-Model Support**: Works with various language models and vision language models

## Installation

```bash
pip install kguru
```

Or with uv:

```bash
uv add kguru
```

## Quick Start

```python
import kguru

agent = kguru.Agent()

# Run the agent loop
result = agent.solve("Your problem here")
```

