import logging
from typing import Literal, Optional, Union, List
import requests
import tempfile
import pandas as pd
from .utilities import _transform_key
from .results import SingleSimulationResults, BatchSimulationResults
from concurrent.futures import ThreadPoolExecutor, as_completed
from .device_flow_auth import device_auth
from packaging.version import Version
import json
from .api_utils import (
    BreatheException,
    make_design_names_map,
    map_design_names__human_to_machine,
    map_fields_in_place,
    convert_none_strings_to_none,
)
from .parameter_validator import parameter_validator
from .format import get_valid_materials, get_valid_assembly_types
import os
import dotenv
from .__init__ import __version__
import re
import time
from tqdm import tqdm
import datetime

dotenv.load_dotenv()

_logger = logging.getLogger(__name__)

temp_dir = tempfile.mkdtemp(prefix="myapp_")


class BreatheDesignModel:
    """
    A class for interacting with the Breathe Design API.
    """

    def __init__(self):
        self._auth = device_auth
        if "API_URL" in os.environ:
            self._api_url = os.environ["API_URL"]
            _logger.info(f"API_URL set from environment to {self._api_url}")
        else:
            self._api_url = (
                "https://bbt-apim-platform-prod.azure-api.net/platform/api/v1"
            )

        self._debug_prints = os.getenv("BD_DEBUG_PRINTS", "0") == "1"
        self._use_aync_endpoints = os.getenv("BD_USE_ASYNC_ENDPOINTS", "1") == "1"
        self._dump_payload = os.environ.get("BD_DUMP_PAYLOAD", "0") == "1"

    def ensure_logged_in(self):
        """
        Checks if a valid token is available and refreshes it if necessary.
        """
        device_auth.get_token()

    def _make_api_call(
        self, verb: Literal["POST", "GET"], endpoint: str, payload: Optional[dict]
    ) -> requests.Response:
        token = device_auth.get_token()
        headers = {
            "accept": "application/json",
            "Authorization": f"Bearer {token}",
            "breathe-design-version": __version__,
        }
        if payload is not None:
            headers["Content-Type"] = "application/json"

        try:
            if verb == "POST":
                func = requests.post
            elif verb == "GET":
                func = requests.get
            else:
                raise Exception(f"Unsupported method: {verb} for {endpoint}")
            # save payload to a file
            if self._dump_payload:
                with open("payload.json", "w") as f:
                    json.dump(payload, f)
            response = func(
                f"{self._api_url}{endpoint}",
                json=payload,
                headers=headers,
            )
            notification = response.headers.get("x-br-notification")
            if notification:
                print(notification)
            return response
        except Exception as e:
            raise BreatheException(f"Error {e}")

    # region Model simulation calls

    def _make_model_api_call(self, endpoint: str, payload: Union[dict, None]) -> dict:
        if self._use_aync_endpoints:
            return self._make_model_api_call_async(endpoint, payload)
        else:
            return self._make_model_api_call_sync(endpoint, payload)

    def _make_model_api_call_sync(
        self, endpoint: str, payload: Union[dict, None]
    ) -> dict:
        full_endpoint = f"/model-services/pbm/{endpoint}"
        response = self._make_api_call(
            "POST",
            full_endpoint,
            payload,
        )
        if response.status_code != 200:
            trace_id = response.headers.get("x-trace-id")
            span_id = response.headers.get("x-span-id")
            raise BreatheException(
                f"Error {response.status_code}, trace_id: {trace_id}, span_id: {span_id}: {response.text}"
            )
        return response.json()

    def _post_model_request(self, endpoint: str, payload: Union[dict, None]) -> str:
        """Post a model request to the API and return the job UUID.

        Once the job is posted, you should call _poll_for_model_request() to wait for the job to complete.

        Args:
            endpoint (str): The endpoint to call e.g. "run_sim".
            payload (Union[dict, None]): The payload to send to the endpoint.

        Raises:
            BreatheException: If the job is not posted successfully.

        Returns:
            str: The UUID of the job.
        """
        full_endpoint = f"/model-services/pbm-queue-request/{endpoint}"
        response = self._make_api_call("POST", full_endpoint, payload)
        if response.status_code != 202:
            trace_id = response.headers.get("x-trace-id")
            span_id = response.headers.get("x-span-id")
            raise BreatheException(
                f"Failed to post job {response.status_code}, trace_id: {trace_id}, span_id: {span_id}: {response.text}"
            )
        job_uuid = response.json()["uuid"]
        if self._debug_prints:
            print(f"Posted job UUID: {job_uuid}")
        return job_uuid

    def _poll_for_model_request(
        self,
        job_uuid: str,
        timeout: datetime.timedelta = datetime.timedelta(minutes=10),
    ) -> dict:
        """Poll for the completion of a model request.

        Use the UUID string that you got from _post_model_request() to poll for the completion of the job.

        Args:
            job_uuid (str): The UUID of the job to poll for.
            timeout (datetime.timedelta, optional): The maximum time to wait for the job to complete.  NOTE that simulation jobs might be long. Defaults to datetime.timedelta(minutes=5).

        Raises:
            BreatheException: _description_
            BreatheException: _description_

        Returns:
            dict: The result of the model request.
        """
        timeout_time = datetime.datetime.now() + timeout
        while datetime.datetime.now() < timeout_time:
            response = self._make_api_call(
                verb="GET",
                endpoint=f"/model-services/pbm-queue-poll/{job_uuid}",
                payload=None,
            )
            trace_id = response.headers.get("x-trace-id")
            span_id = response.headers.get("x-span-id")
            if response.status_code != 200:
                raise BreatheException(
                    f"Unknown error waiting for job {job_uuid} {response.status_code}, trace_id: {trace_id}, span_id: {span_id}: {response.text}"
                )

            response_data = response.json()
            status = response_data["status"]
            if status == "pending":
                # not ready yet, keep waiting
                time.sleep(0.5)
            elif status == "done":
                # success
                if self._debug_prints:
                    print(f"Job {job_uuid} completed")
                return response_data["result"]
            else:
                raise BreatheException(
                    f"Unknown satus waiting for job {job_uuid} {response.status_code}, trace_id: {trace_id}, span_id: {span_id}: {response.text}"
                )
        raise BreatheException(
            f"Timeout waiting for job {job_uuid} to complete, trace_id: {trace_id}, span_id: {span_id}"
        )

    def _make_model_api_call_async(
        self,
        endpoint: str,
        payload: Union[dict, None],
        timeout: datetime.timedelta = datetime.timedelta(minutes=5),
    ) -> dict:
        """Call the async PBM job endpoint.  Post the job and poll for completion.

        Args:
            endpoint (str): _description_
            payload (dict | None): _description_
            timeout (datetime.timedelta, optional): Maximum time to wait for the job to complete.  NOTE that simulation jobs might be long. Defaults to datetime.timedelta(minutes=5).

        Raises:
            BreatheException: _description_
            BreatheException: _description_
            BreatheException: _description_

        Returns:
            dict: _description_
        """
        # post job
        job_uuid = self._post_model_request(endpoint, payload)

        # poll for completion
        return self._poll_for_model_request(job_uuid, timeout)

    # end

    def get_service_version(self) -> Version:
        """Get the version number of the API

        Returns:
            _type_: _description_
        """
        response = self._make_model_api_call("get_version", payload={})

        version_str = response["versionStr"]
        return Version(version_str)

    def get_batteries(self) -> list[str]:
        """
        Gets a list of all batteries in your library.

        Returns:
            (list[str]): list of the available battery models.  Use these strings in subsequent functions for the "base_battery" argument.
        """
        _logger.info("Getting batteries...")
        response = self._make_api_call("GET", "/cells/", None)
        if response.status_code != 200:
            raise BreatheException(f"Error {response.status_code}: {response.text}")
        batteries = response.json()

        return [b["name"] for b in batteries]

    def get_battery_format(self, base_battery: str) -> dict:
        """
        Gets the battery format for a base battery. These are the form factor and cell casing parameters available for change in the api.

        Args:
            base_battery (str): The base battery model for the battery format.

        Returns:
            (dict): A dictionary containing the battery format. The keys in the dictionary depend on the format shape:

            **Common keys (all formats):**
            - ``shape`` (str): The format shape, either "cylinder" or "cuboid"
            - ``material`` (str): The material used for the housing
            - ``housingThickness_mm`` (float): Housing thickness in millimeters

            **Cylindrical format keys** (when ``shape == "cylinder"``):
            - ``diameter_mm`` (float): Outer diameter of the cylinder in millimeters
            - ``height_mm`` (float): Height of the cylinder in millimeters
            - ``innerDiameter_mm`` (float): Inner diameter of the cylinder in millimeters

            **Cuboid format keys** (when ``shape == "cuboid"``):
            - ``length_mm`` (float): Length of the cuboid in millimeters
            - ``width_mm`` (float): Width of the cuboid in millimeters
            - ``thickness_mm`` (float): Thickness of the cuboid in millimeters
            - ``assemblyType`` (str, optional): Type of assembly (e.g., "Stacked", "Wound", "ZFolded")

        Example:
            >>> format = api.get_battery_format("Molicel P45B")
            >>> if format["shape"] == "cylinder":
            ...     print(f"Diameter: {format['diameter_mm']} mm")
            ...     print(f"Height: {format['height_mm']} mm")
            >>> elif format["shape"] == "cuboid":
            ...     print(f"Length: {format['length_mm']} mm")
            ...     print(f"Width: {format['width_mm']} mm")
        """
        _logger.info(f"Getting battery format for {base_battery}...")
        return self._make_model_api_call(
            "get_battery_format", {"base_battery": base_battery}
        )

    def get_updated_format(self, base_battery: str, **kwargs) -> dict:
        """
        Gets the battery format for a base battery and updates it with the additional keywords. These are the form factor and cell casing parameters available for change in the api.

        Args:
            base_battery (str): The base battery model for the battery format.
            **kwargs: Format parameters to update. The available parameters depend on the format shape:
                - For cylindrical formats: ``diameter_mm``, ``height_mm``, ``innerDiameter_mm``, ``material``, ``housingThickness_mm``
                - For cuboid formats: ``length_mm``, ``width_mm``, ``thickness_mm``, ``material``, ``housingThickness_mm``
                - ``name``: Optional name for the updated format
                - ``assemblyType``: Cannot be changed (raises an error if attempted)

        Returns:
            (dict): A dictionary containing the updated battery format. See ``get_battery_format()`` for details on the returned dictionary structure.

        Raises:
            BreatheException: If attempting to change ``assemblyType`` or if a key is not found in the battery format.

        Example:
            >>> # For a cylindrical battery
            >>> format = api.get_updated_format(
            ...     "Molicel P45B",
            ...     name="Smaller Cell",
            ...     diameter_mm=20.0,
            ...     height_mm=65.0
            ... )
            >>> # For a cuboid battery
            >>> format = api.get_updated_format(
            ...     "SomeCuboidBattery",
            ...     name="Thinner Cell",
            ...     thickness_mm=8.0
            ... )
        """
        _logger.info(f"Getting battery format for {base_battery}...")
        format = self._make_model_api_call(
            "get_battery_format", {"base_battery": base_battery}
        )
        for key in kwargs.keys():
            if key == "assemblyType":
                raise BreatheException("Changing assemblyType is not allowed.")
            if key in format or key == "name":
                format[key] = kwargs[key]
            else:
                raise BreatheException(f"Key {key} not found in the battery format.")
        return format

    def get_active_materials(self):
        """
        Gets a list of all acive materials.

        Returns:
            (pandas.Dataframe): containing the battery active materials.
        """
        _logger.info("Getting active materials...")
        am = self._make_model_api_call("get_active_materials", {})
        return pd.DataFrame(am)

    def get_valid_format_materials(self) -> list[str]:
        """
        Gets a list of valid material types for battery formats.

        Returns:
            (list[str]): A sorted list of valid material names that can be used
                         when defining battery formats (e.g., "steel", "aluminum", "pouch_foil").
        """
        return get_valid_materials()

    def get_valid_assembly_types(self) -> list[str]:
        """
        Gets a list of valid assembly types for battery formats.

        Returns:
            (list[str]): A sorted list of valid assembly type names that can be used
                         when defining cuboid battery formats (e.g., "stacked", "wound", "zFolded").
        """
        return get_valid_assembly_types()

    def get_design_parameters(self, base_battery: str):
        """
        Gets the design parameters for a base battery.

        Args:
            base_battery (str): The base battery model for the design parameters.

        Returns:
            (dict): containing the design parameters.
        """
        _logger.info(f"Getting design parameters for {base_battery}...")
        return self._make_model_api_call(
            "get_design_parameters", {"base_battery": base_battery}
        )

    def download_designs(
        self,
        base_battery: str,
        designs: list[dict] = [],
        formats: list[dict] = [],
        output_tag: str = "",
        folder: str = ".",
    ) -> list[str]:
        """Send the design parameters for a given battery to the API, and get the resulting design, to be used with the Simulink blocks.

        Args:
            base_battery (str): The base battery to use to generate the design
            designs (list[str], optional): The designs for the simulation.
            formats (list[str], optional): The formats for the simulation.
            output_tag (str): A tag to be included in the metadata description.
            folder (str): The folder where design files will be saved. Defaults to current directory.
        Returns:
            (list[str]): The list of the file paths for the downloaded designs.
        Raises:
            BreatheException: _description_
        """
        import glob

        map_h2m, map_m2h = make_design_names_map(designs)
        designs_mapped = map_design_names__human_to_machine(designs, map_h2m)
        design_dict_mapped = self._make_model_api_call_batched(
            "download_design",
            {
                "base_battery": base_battery,
                "formats": formats,
            },
            designs_mapped,
        )

        # undo design name mapping
        design_dict = {}
        for k, v in design_dict_mapped.items():
            key_human = map_m2h.get(k, k)
            design_dict[key_human] = v
            design_dict[key_human]["Meta"]["cellName"] = key_human

        # Ensure folder exists
        os.makedirs(folder, exist_ok=True)

        # Find any existing files in the provided directory (to avoid trying to save with the same name and overwriting)
        existing_files = glob.glob(os.path.join(folder, "BMJN_*.json"))
        existing_numbers = set()
        pattern = re.compile(r"BMJN_(\d+)\.json$")
        for file_path in existing_files:
            filename = os.path.basename(file_path)
            match = pattern.match(filename)
            if match:
                try:
                    number = int(match.group(1))
                    existing_numbers.add(number)
                except ValueError:
                    continue

        # Find the next available number
        next_number = 0
        while next_number in existing_numbers:
            next_number += 1

        design_names = design_dict.keys()

        # Prepare metadata for description
        common_metadata_items = {
            "breathe_design_version": f"{__version__}",
            "base_battery": base_battery,
        }
        if output_tag:
            common_metadata_items["output_tag"] = output_tag

        # make a map of the original design details so we can attach the original inputs to the metadata
        design_details: dict[str, dict] = {}
        for design in designs:
            name = design["designName"]
            details = design.copy()
            details.pop("designName")
            design_details[name] = details

        files: list[str] = []
        for i, design_name in enumerate(design_names):
            # Use BMJN_XXXX naming convention
            filename = f"BMJN_{next_number + i}.json"
            filepath = os.path.join(folder, filename)

            # construct description metadata
            description = common_metadata_items.copy()
            if design_name in design_details:
                description.update(design_details[design_name])

            # Add metadata to the design
            design_data = design_dict[design_name].copy()
            if "Meta" not in design_data:
                design_data["Meta"] = {}
            # if Meta.description already exists, and is a dict, update it
            if "description" in design_data["Meta"] and isinstance(
                design_data["Meta"]["description"], dict
            ):
                design_data["Meta"]["description"].update(common_metadata_items)
            else:
                # otherwise set it
                design_data["Meta"]["description"] = common_metadata_items

            if design_name in design_details:
                design_data["Meta"]["description"]["design"] = design_details[
                    design_name
                ]

            with open(filepath, "w") as f:
                json.dump(design_data, f)
            files.append(filepath)
        return files

    def get_ocv(self, base_battery: str) -> pd.DataFrame:
        """
        Gets the OCV summary table for a base battery.

        Args:
            base_battery (str): The base battery model for the design parameters.

        Returns:
            (pandas.DataFrame): containing the OCV summary table.
        """
        _logger.info(f"Getting OCV for {base_battery}...")
        ocv_data = self._make_model_api_call("get_ocv", {"base_battery": base_battery})

        ocv_df = pd.DataFrame(ocv_data)
        return ocv_df

    def get_aged_ocv(
        self,
        base_battery: str,
        LAMPE: float = 0.0,
        LAMNE: float = 0.0,
        LLI: float = 0.0,
    ) -> pd.DataFrame:
        """
        Gets the OCV summary table for a base battery.

        Args:
            base_battery (str): The base battery model for the design parameters.
            LAMPE (float, optional): The electrolyte loss at positive electrode (PE) side.
            LAMNE (float, optional): The electrolyte loss at negative electrode (NE) side.
            LLI (float, optional): The loss of lithium inventory.

        Returns:
            (pandas.DataFrame): containing the OCV summary table.
        """
        _logger.info(f"Getting aged OCV for {base_battery}...")
        ocv_data = self._make_model_api_call(
            "get_aged_ocv",
            {"base_battery": base_battery, "LAMPE": LAMPE, "LAMNE": LAMNE, "LLI": LLI},
        )

        ocv_df = pd.DataFrame(ocv_data)
        return ocv_df

    def _format_kpis(self, results: dict) -> pd.DataFrame:
        kpis = results["KPIs"]
        kpi_names = [_transform_key(key) for key in results["KPInames"]]
        results_df = pd.DataFrame(kpis)
        # Add KPI names as a column to the DataFrame
        results_df["KPI"] = kpi_names
        results_df = results_df[
            ["KPI"] + [col for col in results_df.columns if col != "KPI"]
        ]
        return results_df.set_index("KPI")

    def get_eqm_kpis(
        self, base_battery: str, designs: list[dict] = [], formats: list[dict] = []
    ) -> "SingleSimulationResults":
        """
        Gets the equilibrium kpis for a given base battery, designs, and initial conditions.

        Args:
            base_battery (str): The base battery model for the simulation.
            designs (list[dict], optional): The designs for the simulation.
            formats (list[dict], optional): The battery formats for the simulation.

        Returns:
            (SingleSimulationResults): A results handler object containing the equilibrium KPIs.
                Use the plot_sensitivities() method to generate sensitivity plots.
        """
        _logger.info(f"Getting equilibrium kpis for {base_battery}...")
        map_h2m, map_m2h = make_design_names_map(designs)
        designs_mapped = map_design_names__human_to_machine(designs, map_h2m)
        results = self._make_model_api_call_batched(
            "run_sim",
            {
                "base_battery": base_battery,
                "formats": formats,
            },
            designs_mapped,
        )

        # unmap the KPIs
        map_fields_in_place(results, "KPIs", map_m2h)

        # Add input parameters to the result for easy access
        results["input_parameters"] = {
            "base_battery": base_battery,
            "designs": designs,
            "formats": formats,
        }

        return SingleSimulationResults(results)

    def _make_model_api_call_batched(
        self,
        endpoint: Literal["run_sim", "download_design"],
        common_payload: dict,
        designs_mapped: list[dict],
    ) -> dict:
        """Call run run_sim endpoint, but split the provided designs into batches
        and make a new run_sim call for each batch

        Args:
            endpoint (str): The endpoint to call e.g. "run_sim".
            common_payload (dict): The payload you would normally send to the run_sim endpoint, without the "designs" key.  That is added later for each batch.
            designs_mapped (list[dict]): The list of design dictionaries.  These are split into batches and each batch added to the "common_load" and sent to the endpoint.

        Raises:
            BreatheException: _description_

        Returns:
            dict: The combined result from all the batches.
        """
        # if there are no designs, just send it
        if len(designs_mapped) == 0:
            payload = {
                **common_payload,
                "designs": [],
            }
            _logger.debug("Submitting run_sim call with no designs")
            return self._make_model_api_call("run_sim", payload)

        # if there are designs, batch them
        batch_size = 10
        designs_batches = [
            designs_mapped[i : i + batch_size]
            for i in range(0, len(designs_mapped), batch_size)
        ]

        num_batches = len(designs_batches)
        results: list[dict] = [{}] * len(designs_batches)

        # empirically chosen
        max_workers = 8

        # run each batch in a different thread
        _logger.debug(f"Running {num_batches} batches with {max_workers} workers")
        with ThreadPoolExecutor(max_workers=max_workers) as executor:

            def _wrapper(designs_batch, index, batch_start_time):
                payload = {
                    **common_payload,
                    "designs": designs_batch,
                }
                # sleep until we can start
                delay_s = batch_start_time - time.time()
                if delay_s > 0:
                    time.sleep(delay_s)
                _logger.debug(
                    f"Submitting run_sim call for batch {index + 1} of {num_batches} with {len(designs_batch)} designs"
                )
                return self._make_model_api_call(endpoint, payload)

            # start each batch in a new thread
            future_to_index = {}
            start_time = time.time()
            for i, batch in enumerate(designs_batches):
                # ensure each thread calls the API 300ms after the previous one to avoid being rate limited by the API (429)
                batch_start_time = start_time + (i * 0.3)
                future_to_index[
                    executor.submit(_wrapper, batch, i, batch_start_time)
                ] = i

            # collect results
            progress = tqdm(
                total=len(designs_mapped), desc="Running...", unit=" designs"
            )
            for future in as_completed(future_to_index):
                idx = future_to_index[future]
                try:
                    results[idx] = future.result()
                    _logger.debug(f"Recieved result for batch {idx}")
                    progress.update(len(designs_batches[idx]))
                except Exception as e:
                    raise BreatheException(
                        f"Simulation run for batch {idx} failed with error: {e}"
                    )

        # recombine
        # NOTE that the each simultion batch has a "Baseline" but they are identical.
        # When we combine them, the "Baseline" from the last batch will override the rest.

        if endpoint == "run_sim":
            result = results[0]
            for i in range(1, len(results)):
                if "dynamicData" in result:
                    result["dynamicData"].update(results[i]["dynamicData"])
                if "KPIs" in result:
                    result["KPIs"].update(results[i]["KPIs"])
            return result
        elif endpoint == "download_design":
            result = results[0]
            for i in range(1, len(results)):
                result.update(results[i])
            return result
        else:
            raise BreatheException(f"Unsupported endpoint: {endpoint}")

    def run_sim(
        self,
        base_battery: str,
        cycler: dict,
        designs: list[dict] = [],
        formats: list[dict] = [],
        initialSoC: Union[int, float, List[Union[int, float]]] = 0.5,
        initialTemperature_degC: Union[int, float, List[Union[int, float]]] = 25.0,
        ambientTemperature_degC: Union[int, float, List[Union[int, float]]] = 25.0,
    ) -> Union["SingleSimulationResults", "BatchSimulationResults"]:
        """
        Runs a simulation for a given base battery, cycler, designs, and initial conditions.

        Args:
            base_battery (str): The base battery model for the simulation.
            cycler (dict): The cycler parameters for the simulation.
            designs (list[dict], optional): The design parameters for the simulation.
            formats (list[dict], optional): The battery formats for the simulation.
            initialSoC (int | float | list[int | float], optional): The initial state of charge for the simulation.
                If a single value is provided, it will be used for all simulations.
                If a list of values is provided, multiple simulations will be run with each value.
            initialTemperature_degC (int | float | list[int | float], optional): The initial temperature for the simulation in degC.
                If a single value is provided, it will be used for all simulations.
                If a list of values is provided, multiple simulations will be run with each value.
            ambientTemperature_degC (int | float | list[int | float], optional): The ambient temperature for the simulation in degC.
                If a single value is provided, it will be used for all simulations.
                If a list of values is provided, multiple simulations will be run with each value.

        Returns:
            (SimulationResults): A results handler object containing the simulation results.
                This automatically handles both single and batch simulations.
        """
        # Validate and format design parameters
        validated_designs = parameter_validator.validate_and_format_designs(designs)

        # Validate and format format parameters
        validated_formats = parameter_validator.validate_and_format_formats(formats)

        # map the designs to machine names
        map_h2m, map_m2h = make_design_names_map(validated_designs)
        designs_mapped = map_design_names__human_to_machine(validated_designs, map_h2m)

        if (
            isinstance(initialSoC, (int, float))
            and isinstance(initialTemperature_degC, (int, float))
            and isinstance(ambientTemperature_degC, (int, float))
        ):
            # Single value for initialSoC and initialTemperature_degC

            # run simulations, possibly batching them
            result = self._make_model_api_call_batched(
                "run_sim",
                {
                    "base_battery": base_battery,
                    "cycler": cycler,
                    "formats": validated_formats,
                    "initial_conditions": {
                        "socCell_0": initialSoC,
                        "initialTemperature_degC": initialTemperature_degC,
                        "ambientTemperature_degC": ambientTemperature_degC,
                    },
                },
                designs_mapped,
            )

            # Convert "none" strings to Python None in dynamic data
            if "dynamicData" in result:
                result["dynamicData"] = convert_none_strings_to_none(
                    result["dynamicData"]
                )

            map_fields_in_place(result, "KPIs", map_m2h)
            map_fields_in_place(result, "dynamicData", map_m2h)

            # Add input parameters to the result for easy access
            result["input_parameters"] = {
                "base_battery": base_battery,
                "cycler": cycler,
                "designs": designs,
                "initialSoC": initialSoC,
                "initialTemperature_degC": initialTemperature_degC,
                "ambientTemperature_degC": ambientTemperature_degC,
            }

            return SingleSimulationResults(result)
        else:
            # make sure we are logged in first.  We need to do this because we are about to spawn multiple
            # threads, and if we do that when we are logged out, each thread will independencly try to log back in.
            self.ensure_logged_in()

            initialSoCs = (
                [initialSoC] if not isinstance(initialSoC, list) else initialSoC
            )
            initialTemperature_degC = (
                [initialTemperature_degC]
                if not isinstance(initialTemperature_degC, list)
                else initialTemperature_degC
            )
            ambientTemperature_degC = (
                [ambientTemperature_degC]
                if not isinstance(ambientTemperature_degC, list)
                else ambientTemperature_degC
            )
            max_workers = min(4, len(initialSoCs) * len(initialTemperature_degC))
            results = []

            # make a list of all the conditions
            all_conditions = [
                (isc, itmp, atmp)
                for isc in initialSoCs
                for itmp in initialTemperature_degC
                for atmp in ambientTemperature_degC
            ]

            with ThreadPoolExecutor(max_workers=max_workers) as executor:

                def _wrapper(initial_conditions):
                    # unpack the initial conditions
                    initial_soc, initial_temperature_degC, ambient_temperature_degC = (
                        initial_conditions
                    )
                    return self._make_model_api_call_batched(
                        "run_sim",
                        {
                            "base_battery": base_battery,
                            "cycler": cycler,
                            "formats": validated_formats,
                            "initial_conditions": {
                                "socCell_0": initial_soc,
                                "initialTemperature_degC": initial_temperature_degC,
                                "ambientTemperature_degC": ambient_temperature_degC,
                            },
                        },
                        designs_mapped,
                    )

                for i, result in enumerate(
                    executor.map(
                        _wrapper,
                        all_conditions,
                    )
                ):
                    if result is None:
                        raise BreatheException(
                            f"Simulation run for conditions {all_conditions[i]} failed!"
                        )

                    # Convert "none" strings to Python None in dynamic data
                    if "dynamicData" in result:
                        result["dynamicData"] = convert_none_strings_to_none(
                            result["dynamicData"]
                        )

                    map_fields_in_place(result, "KPIs", map_m2h)
                    map_fields_in_place(result, "dynamicData", map_m2h)

                    # Add input parameters to each result for easy access
                    result["input_parameters"] = {
                        "base_battery": base_battery,
                        "cycler": cycler,
                        "designs": designs,
                        "initialSoC": all_conditions[i][0],
                        "initialTemperature_degC": all_conditions[i][1],
                        "ambientTemperature_degC": all_conditions[i][2],
                    }

                    results.append(result)

            return BatchSimulationResults(results)


api_interface = BreatheDesignModel()
