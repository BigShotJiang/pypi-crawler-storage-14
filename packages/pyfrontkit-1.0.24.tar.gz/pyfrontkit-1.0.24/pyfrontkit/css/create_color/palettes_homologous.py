# Copyright (C) [2025] Eduardo Antonio Ferrera Rodríguez
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation, either version 3 of the License, or any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY. See the COPYING file for more details.


# palettes_homologous.py

# Paletas de colores homologous
palette_homologous = {
    # REDS
    "red_pure":    {"principal": "#FF0000", "secondary": "#FF4D4D", "tertiary": "#FF9999", "quaternary": "#FFCCCC"},
    "red_dark":    {"principal": "#990000", "secondary": "#B22222", "tertiary": "#CC3333", "quaternary": "#FF6666"},
    "red_pink":    {"principal": "#FF66CC", "secondary": "#FF99D9", "tertiary": "#FFB3E6", "quaternary": "#FFD6F0"},
    "coral":       {"principal": "#FF7F50", "secondary": "#FF9980", "tertiary": "#FFB3A0", "quaternary": "#FFD1C1"},
    "tomato":      {"principal": "#FF6347", "secondary": "#FF8266", "tertiary": "#FF9980", "quaternary": "#FFB3A0"},

    # BLUES
    "blue_pure":   {"principal": "#0000FF", "secondary": "#4D4DFF", "tertiary": "#9999FF", "quaternary": "#CCCCFF"},
    "blue_medium": {"principal": "#0000CC", "secondary": "#3333FF", "tertiary": "#6666FF", "quaternary": "#9999FF"},
    "aqua":        {"principal": "#00FFFF", "secondary": "#66FFFF", "tertiary": "#99FFFF", "quaternary": "#CCFFFF"},
    "cyan":        {"principal": "#00CED1", "secondary": "#33D6D6", "tertiary": "#66E0E0", "quaternary": "#99EBEB"},
    "sky_blue":    {"principal": "#87CEEB", "secondary": "#A0D9F7", "tertiary": "#B3E4FB", "quaternary": "#CCF0FF"},

    # GREENS
    "green_pure":  {"principal": "#00FF00", "secondary": "#66FF66", "tertiary": "#99FF99", "quaternary": "#CCFFCC"},
    "green_light": {"principal": "#90EE90", "secondary": "#A6F0A6", "tertiary": "#B3F7B3", "quaternary": "#CCFFCC"},
    "green_dark":  {"principal": "#006400", "secondary": "#228B22", "tertiary": "#33AA33", "quaternary": "#66CC66"},
    "lime":        {"principal": "#32CD32", "secondary": "#66E066", "tertiary": "#99F099", "quaternary": "#CCFFCC"},
    "sea_green":   {"principal": "#2E8B57", "secondary": "#4DA66E", "tertiary": "#66B380", "quaternary": "#80C99C"},

    # YELLOWS
    "yellow":      {"principal": "#FFFF00", "secondary": "#FFFF66", "tertiary": "#FFFF99", "quaternary": "#FFFFCC"},
    "golden":      {"principal": "#FFD700", "secondary": "#FFE066", "tertiary": "#FFE680", "quaternary": "#FFF2B3"},
    "light_yellow":{"principal": "#FFFFE0", "secondary": "#FFFFF0", "tertiary": "#FFFFF5", "quaternary": "#FFFFFF"},
    "lemon":       {"principal": "#FFF44F", "secondary": "#FFF97F", "tertiary": "#FFFB99", "quaternary": "#FFFCCD"},

    # ORANGES
    "orange":      {"principal": "#FFA500", "secondary": "#FFB84D", "tertiary": "#FFC966", "quaternary": "#FFD699"},
    "dark_orange": {"principal": "#FF8C00", "secondary": "#FFA033", "tertiary": "#FFB266", "quaternary": "#FFC299"},
    "peach":       {"principal": "#FFE5B4", "secondary": "#FFEBCD", "tertiary": "#FFF2DC", "quaternary": "#FFF7EB"},
    "tangerine":   {"principal": "#F28500", "secondary": "#FF9A33", "tertiary": "#FFB266", "quaternary": "#FFCC99"},

    # VIOLETS
    "violet":      {"principal": "#8A2BE2", "secondary": "#A063E2", "tertiary": "#B380EB", "quaternary": "#C39EF0"},
    "lilac":       {"principal": "#C8A2C8", "secondary": "#D1B3D1", "tertiary": "#E0CCE0", "quaternary": "#F0E0F0"},
    "purple":      {"principal": "#800080", "secondary": "#993399", "tertiary": "#B366B3", "quaternary": "#CC99CC"},
    "orchid":      {"principal": "#DA70D6", "secondary": "#E28AD6", "tertiary": "#E6A0EB", "quaternary": "#F0C0F0"},

    # NEUTRALS
    "white":       {"principal": "#FFFFFF", "secondary": "#F2F2F2", "tertiary": "#E6E6E6", "quaternary": "#CCCCCC"},
    "black":       {"principal": "#000000", "secondary": "#333333", "tertiary": "#666666", "quaternary": "#999999"},
    "light_gray":  {"principal": "#D3D3D3", "secondary": "#E0E0E0", "tertiary": "#F0F0F0", "quaternary": "#FAFAFA"},
    "dark_gray":   {"principal": "#A9A9A9", "secondary": "#BFBFBF", "tertiary": "#D3D3D3", "quaternary": "#E6E6E6"},
    "beige":       {"principal": "#F5F5DC", "secondary": "#FAFAD2", "tertiary": "#FFFFE0", "quaternary": "#FFFEE0"},
    "silver":      {"principal": "#C0C0C0", "secondary": "#D3D3D3", "tertiary": "#E6E6E6", "quaternary": "#F2F2F2"},
}

# Reglas profesionales homologous

# homologous_color_rule actualizado para usar familias en mayúsculas
# palettes_homologous.py

# ... (Paletas de colores permanecen iguales) ...

# ----------------------------------------------------
# Reglas Profesionales Homologous (Semánticas)
# ----------------------------------------------------
homologous_color_rule = {
    "body": {
        "bg_role": "white.principal", 
        "text_role": "black.principal",
        "children": {
            # HEADER (Usa el color principal de la paleta elegida.)
            "HEADER": {
                "bg_role": "principal", 
                "text_role": "white.principal",
                "children": {
                    "*": {
                        "bg_role": "secondary",
                        "text_role": "white.principal"
                    }
                }
            },
            
            # FOOTER (Usa un neutro fijo.)
            "FOOTER": {
                "bg_role": "dark_gray.principal",
                "text_role": "white.principal",
                "children": {
                    "*": {
                        "bg_role": "dark_gray.secondary",
                        "text_role": "light_gray.principal"
                    }
                }
            },
            
            # STANDARD (Contenido principal/medio. Blanco base.)
            "STANDARD": {
                "bg_role": "white.principal",
                "text_role": "black.principal",
                "children": {
                    "ARTICLE": {
                        "bg_role": "tertiary",
                        "text_role": "black.principal",
                        "children": {
                            "*": {
                                "bg_role": "secondary",
                                "text_role": "principal"
                            }
                        }
                    },
                    "*": {
                        "bg_role": "secondary",
                        "text_role": "black.principal"
                    }
                }
            }
        }
    }
}


# ----------------------------------------------------
# FUNCIONES DE UTILIDAD CORREGIDAS
# ----------------------------------------------------

def _resolve_role_to_hex(role_str: str, current_palette_name: str, full_palette: dict) -> str:
    """
    Helper function to translate a semantic role string (e.g., 'principal' or 'white.secondary')
    into a final hexadecimal color code.
    """
    if not role_str:
        return None
    
    if "." in role_str:
        # External reference: "palette_name.role" (e.g., "white.principal")
        p_name, c_role = role_str.split(".")
        if p_name in full_palette:
            return full_palette[p_name].get(c_role, None) 
        return None 
    else:
        # Local reference: "role" (e.g., "principal" from the selected color_name)
        if current_palette_name in full_palette:
             # Look for the color role within the specified palette group
            # Note: This is a placeholder; in a real scenario, the function needs
            # to know the user's base color (e.g., "red_pure") to resolve "principal".
            # Since this function is static, we'll use a safe default or assume
            # the rule itself provides the context (which is complicated).
            # We'll rely on the rule being written with full definitions if called standalone.
            # However, for simplicity and integration with your system, we'll assume 
            # the user provides the base color name when calling this utility.
            # Since this utility is within the homologous file, we'll assume a default 
            # for "principal" resolution if not fully qualified.
            
            # **REGLA DE FALLBACK (TEMPORAL): Usar white/black si no hay contexto de color**
            if current_palette_name == "default":
                 return full_palette["white"].get(role_str, None) if "white" in full_palette else "#FFFFFF"
            
            # Si el rol no está totalmente calificado, es un BUG en la regla si es usada estáticamente.
            # Pero dado el diseño actual, es mejor devolver None para no aplicar un color incorrecto.
            return None


def get_color_for_tag(tag_path: list, base_color_name: str = "red_pure", rule=None):
    """
    Returns a dictionary {'bg': hex_color, 'text': hex_color} for any tag_path.
    - tag_path: list of tags from 'body' to the target tag, e.g.: ['body', 'main', 'section', 'p']
    - base_color_name: The palette group chosen by the user (e.g., "blue_pure").
    - rule: The rule to use (defaults to homologous_color_rule).
    """
    from copy import deepcopy
    if rule is None:
        rule = deepcopy(homologous_color_rule)

    current = rule
    bg_role, text_role = None, None

    for i, tag in enumerate(tag_path):
        # 1. Look for the exact tag (e.g., 'body')
        if "children" in current and tag in current["children"]:
            current = current["children"][tag]
        # 2. If it's a structural tag, check for its abstract category (e.g., 'HEADER')
        elif i > 0: # Skip 'body' check
             # Intentar mapear el tag real a una clave ABSTRACTA (HEADER, STANDARD)
             # Esto requiere que la función conozca el mapeo (FAMILY_MAP) que está en create_color.py,
             # lo cual no podemos hacer aquí sin crear dependencias circulares.
             # Por simplicidad y para que funcione con la regla anidada, confiamos en la jerarquía.
             
             # 3. If no exact tag, use the wildcard "*"
             if "children" in current and "*" in current["children"]:
                 current = current["children"]["*"]
             else:
                 break # End traversal if no children defined
        else:
            break # End traversal if not 'body' and no children defined

        # Actualizamos bg_role/text_role si están definidos en este nivel de la regla
        bg_role = current.get("bg_role", bg_role)
        text_role = current.get("text_role", text_role)

    # --------------------------------------------------
    # NUEVA LÓGICA DE RESOLUCIÓN DE COLOR
    # --------------------------------------------------
    
    # Intentamos obtener la paleta específica del usuario
    current_colors = palette_homologous.get(base_color_name)
    
    # Si no se encuentra el color base, usamos el color neutro (blanco/negro)
    if not current_colors:
        resolved_bg = _resolve_role_to_hex(bg_role, "white", palette_homologous)
        resolved_text = _resolve_role_to_hex(text_role, "black", palette_homologous)
        return {"bg": resolved_bg or "#FFFFFF", "text": resolved_text or "#000000"}

    # Resolvamos los roles
    def _local_resolve(role_str, current_colors):
        if not role_str: return None
        
        if "." in role_str:
            # Referencia externa (ej: "white.principal")
            p_name, c_role = role_str.split(".")
            return palette_homologous.get(p_name, {}).get(c_role, None)
        else:
            # Referencia local (ej: "principal")
            return current_colors.get(role_str, None)

    resolved_bg = _local_resolve(bg_role, current_colors)
    resolved_text = _local_resolve(text_role, current_colors)

    return {"bg": resolved_bg, "text": resolved_text}