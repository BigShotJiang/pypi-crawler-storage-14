from pathlib import Path
import tempfile
import threading
import time

import pandas
import pytest

from .. import Resource
from pandas import DataFrame


class DataFrameXLSXResource(Resource):
    def __init__(self, path: Path = None, identifier: str = None):
        if path and identifier:
            self.path = path
            self.identifier = identifier
        elif path and not identifier:
            self.path = path
            if not self.path.exists(): raise FileNotFoundError(f"File '{path}' does not exist")
            self.identifier = path.stem
        elif not path and identifier:
            self.path = Path.cwd() / f"{identifier}.xlsx"
            self.identifier = identifier
        else:
            raise ValueError("Either path or identifier must be specified")

        if not self.path.suffix == ".xlsx":
            raise ValueError(f"Path must be an xlsx file, got {self.path} instead")

        if not self.path.exists():
            pandas.DataFrame().to_excel(self.path, index=False)

        try:
            self.data: DataFrame = pandas.read_excel(self.path)
        except Exception as e:
            raise Exception(f"Failed to read xlsx file: {e}")

        super().__init__(identifier=self.identifier)

    def _enter(self) -> DataFrame:
        self.data = pandas.read_excel(self.path)
        return self.data

    def _exit(self):
        self.data.to_excel(self.path, index=False)

    def _peek(self) -> DataFrame:
        return pandas.read_excel(self.path)


@pytest.fixture
def temp_xlsx_path():
    with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as f:
        path = Path(f.name)

    pandas.DataFrame().to_excel(path, index=False)
    yield path

    if path.exists():
        path.unlink()


@pytest.fixture
def df_xlsx_resource(temp_xlsx_path):
    return DataFrameXLSXResource(path=temp_xlsx_path, identifier="test_resource")


def test_resource_initialization_with_both_args(temp_xlsx_path):
    resource = DataFrameXLSXResource(path=temp_xlsx_path, identifier="custom_id")
    assert resource.identifier == "custom_id"
    assert resource.path == temp_xlsx_path


def test_resource_initialization_with_path_only(temp_xlsx_path):
    resource = DataFrameXLSXResource(path=temp_xlsx_path)
    assert resource.identifier == temp_xlsx_path.stem


def test_resource_initialization_with_identifier_only():
    identifier = "test_identifier"
    resource = DataFrameXLSXResource(identifier=identifier)
    expected_path = Path.cwd() / f"{identifier}.xlsx"

    assert resource.identifier == identifier
    assert resource.path == expected_path
    assert resource.path.exists()

    expected_path.unlink()


def test_resource_initialization_with_no_args():
    with pytest.raises(ValueError, match="Either path or identifier must be specified"):
        DataFrameXLSXResource()


def test_resource_initialization_with_non_xlsx_path():
    path = Path("test.csv")
    with pytest.raises(ValueError, match="Path must be an xlsx file"):
        DataFrameXLSXResource(path=path)


def test_context_manager_basic_read_write(df_xlsx_resource):
    test_data = DataFrame({"name": ["Alice", "Bob"], "age": [25, 30]})

    with df_xlsx_resource as df:
        df["name"] = test_data["name"]
        df["age"] = test_data["age"]

    loaded_data = pandas.read_excel(df_xlsx_resource.path)
    pandas.testing.assert_frame_equal(loaded_data, test_data)


def test_context_manager_appends_data(df_xlsx_resource):
    initial_data = DataFrame({"value": [1, 2, 3]})
    initial_data.to_excel(df_xlsx_resource.path, index=False)

    with df_xlsx_resource as df:
        new_row = pandas.DataFrame({"value": [4]})
        df_xlsx_resource.data = pandas.concat([df, new_row], ignore_index=True)

    loaded_data = pandas.read_excel(df_xlsx_resource.path)
    assert len(loaded_data) == 4
    assert loaded_data["value"].tolist() == [1, 2, 3, 4]


def test_context_manager_modifies_in_place(df_xlsx_resource):
    initial_data = DataFrame({"value": [1, 2, 3]})
    initial_data.to_excel(df_xlsx_resource.path, index=False)

    with df_xlsx_resource as df:
        df["value"] = df["value"] * 2

    loaded_data = pandas.read_excel(df_xlsx_resource.path)
    assert loaded_data["value"].tolist() == [2, 4, 6]


def test_peek_returns_current_data(df_xlsx_resource):
    test_data = DataFrame({"col": ["x", "y", "z"]})
    test_data.to_excel(df_xlsx_resource.path, index=False)

    peeked_data = df_xlsx_resource.peek()
    pandas.testing.assert_frame_equal(peeked_data, test_data)


def test_peek_does_not_lock(df_xlsx_resource):
    test_data = DataFrame({"value": [1]})
    test_data.to_excel(df_xlsx_resource.path, index=False)

    with df_xlsx_resource as df:
        peeked = df_xlsx_resource.peek()
        assert "value" in peeked.columns


def test_concurrent_access_with_locking(df_xlsx_resource):
    results = []
    errors = []

    def writer_task(resource, value, delay=0):
        try:
            time.sleep(delay)
            with resource as df:
                df["counter"] = [value]
                time.sleep(0.1)
            results.append(value)
        except Exception as e:
            errors.append(e)

    threads = [
        threading.Thread(target=writer_task, args=(df_xlsx_resource, i, i * 0.05))
        for i in range(5)
    ]

    for thread in threads:
        thread.start()

    for thread in threads:
        thread.join()

    assert len(errors) == 0
    assert len(results) == 5

    final_data = pandas.read_excel(df_xlsx_resource.path)
    assert final_data["counter"].iloc[0] in range(5)


def test_timeout_on_lock_acquisition(df_xlsx_resource):
    df_xlsx_resource.timeout = 0.5

    def blocking_task():
        with df_xlsx_resource as df:
            time.sleep(2)

    thread = threading.Thread(target=blocking_task)
    thread.start()

    time.sleep(0.1)

    with pytest.raises(TimeoutError, match="Could not acquire"):
        with df_xlsx_resource as df:
            pass

    thread.join()


def test_multiple_sequential_accesses(df_xlsx_resource):
    for i in range(3):
        with df_xlsx_resource as df:
            df["iteration"] = [i]

        loaded = pandas.read_excel(df_xlsx_resource.path)
        assert loaded["iteration"].iloc[0] == i


def test_resource_state_persists_between_contexts(df_xlsx_resource):
    with df_xlsx_resource as df:
        df["step"] = [1]

    with df_xlsx_resource as df:
        assert df["step"].iloc[0] == 1
        df["step"] = [2]

    final_data = pandas.read_excel(df_xlsx_resource.path)
    assert final_data["step"].iloc[0] == 2


def test_concurrent_readers_with_peek(df_xlsx_resource):
    test_data = DataFrame({"value": [100]})
    test_data.to_excel(df_xlsx_resource.path, index=False)

    results = []

    def reader_task():
        for _ in range(10):
            peeked = df_xlsx_resource.peek()