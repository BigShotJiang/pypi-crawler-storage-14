"""
Scenario management operations for PyConvexity.

Provides operations for listing, querying, and managing scenarios.
"""

import sqlite3
import logging
from typing import List, Optional
from dataclasses import dataclass

from pyconvexity.core.errors import ValidationError

logger = logging.getLogger(__name__)


@dataclass
class Scenario:
    """Represents a scenario (single network per database)."""

    id: int
    name: str
    description: Optional[str]
    probability: Optional[float]  # For stochastic optimization
    created_at: str


def list_scenarios(conn: sqlite3.Connection) -> List[Scenario]:
    """
    List all scenarios (single network per database).

    Args:
        conn: Database connection

    Returns:
        List of Scenario objects ordered by creation date
    """
    cursor = conn.execute(
        """
        SELECT id, name, description, probability, created_at
        FROM scenarios
        ORDER BY created_at
    """
    )

    scenarios = []
    for row in cursor.fetchall():
        scenarios.append(
            Scenario(
                id=row[0],
                name=row[1],
                description=row[2],
                probability=row[3],
                created_at=row[4],
            )
        )

    return scenarios


def get_scenario_by_name(conn: sqlite3.Connection, name: str) -> Scenario:
    """
    Get a scenario by name (single network per database).

    Args:
        conn: Database connection
        name: Scenario name

    Returns:
        Scenario object

    Raises:
        ValidationError: If scenario doesn't exist
    """
    cursor = conn.execute(
        """
        SELECT id, name, description, probability, created_at
        FROM scenarios
        WHERE name = ?
    """,
        (name,),
    )

    row = cursor.fetchone()
    if not row:
        raise ValidationError(f"Scenario '{name}' not found")

    return Scenario(
        id=row[0],
        name=row[1],
        description=row[2],
        probability=row[3],
        created_at=row[4],
    )


def get_scenario_by_id(conn: sqlite3.Connection, scenario_id: int) -> Scenario:
    """
    Get a scenario by ID.

    Args:
        conn: Database connection
        scenario_id: Scenario ID

    Returns:
        Scenario object

    Raises:
        ValidationError: If scenario doesn't exist
    """
    cursor = conn.execute(
        """
        SELECT id, name, description, probability, created_at
        FROM scenarios
        WHERE id = ?
    """,
        (scenario_id,),
    )

    row = cursor.fetchone()
    if not row:
        raise ValidationError(f"Scenario with ID {scenario_id} not found")

    return Scenario(
        id=row[0],
        name=row[1],
        description=row[2],
        probability=row[3],
        created_at=row[4],
    )
