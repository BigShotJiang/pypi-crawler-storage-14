# Contrived Test Data

This directory contains test data contrived for specific purposes. Files in this
directory should clearly indicate their purpose with a comment.

