*[HTML]: Hyper Text Markup Language
*[HTTP]: HyperText Transfer Protocol
*[HTTPS]: HyperText Transfer Protocol Secure
*[API]: Application Programming Interface
*[UI]: User Interface
*[CLI]: Command-Line Interface
*[PIP]: Pip Install Packages
*[PyPI]: Python Packaging Index
*[PyPA]: Python Packaging Authority
*[PEP]: Python Enhancement Proposal
*[RDF]: Resource Description Framework
*[N3]: Notation 3, an assertion and logic language which is a superset of RDF
*[TriX]: Triples in XML
*[TriG]: Triples in Graphs
*[RDFa]: Resource Description Framework in Attributes
*[JSON-LD]: JavaScript Object Notation - Linked Data
*[JSON]: JavaScript Object Notation
*[OWL]: Web Ontology Language
*[XML]: Extensible Markup Language
*[SPARQL]: SPARQL Protocol and RDF Query Language
*[URL]: Uniform Resource Locator
*[URI]: Uniform Resource Identifier
*[IRI]: Internationalized Resource Identifier
*[CSV]: Comma-Separated Value
*[TSV]: Tab-Separated Value
*[PSV]: Pipe-Separated Value
*[RegEx]: Regular Expression
*[OBO]: Open Biological and Biomedical Ontology
*[VSCode]: VisualStudio Code
*[PR]: Pull request
*[PRs]: Pull requests
