"""
Various commandline tools for working with RDFLib
"""
