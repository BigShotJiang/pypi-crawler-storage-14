"""These examples all live in `./examples` in the source-distribution of RDFLib."""
