__pkg__ = "pyahmia"
__version__ = "0.7.3"
