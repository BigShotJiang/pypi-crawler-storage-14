import os
import json
import hashlib
import time
import platform
import webbrowser
from urllib.parse import urlparse, parse_qs
import requests
from urllib.parse import urlparse
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from pathlib import Path
import subprocess
import platform
import pickle
from pathlib import Path

cookies_file = Path.home() / ".miunlock" / "cookies.pkl"

headers = {"User-Agent": "XiaomiPCSuite"}

def download_captcha(path, captchaUrl, cookies):    
    response = requests.get(f"https://account.xiaomi.com/{captchaUrl}", cookies=cookies, headers=headers)
    cookies.update(response.cookies.get_dict())
    with open(path, "wb") as f:
        f.write(response.content)
    input('\nPress Enter to open the CAPTCHA image')
    if platform.system() == 'Windows':
        subprocess.run(['start', str(path)], shell=True)
    elif platform.system() == 'Darwin':
        subprocess.run(['open', str(path)])
    else:
        subprocess.run(['xdg-open', str(path)])
    
    print(f"\nCaptcha displayed from {path}")
    return cookies

def captcha_v(captchaUrl, cookies, data):
    path = Path.home() / f"{captchaUrl.split('&')[-1]}.captcha.jpg"    
    cookies = download_captcha(path, captchaUrl, cookies)
    captCode = input("\nEnter captcha code: ").strip()
    data.update({'captCode': captCode})
    response = requests.post(f"https://account.xiaomi.com/pass/serviceLoginAuth2", data=data, headers=headers, cookies=cookies)
    response_text = json.loads(response.text[11:])
    if response_text.get("code") == 87001:
        path.unlink()
        print("\nIncorrect captcha code. A new captcha will be generated.")
        return captcha_v(response_text["captchaUrl"], response.cookies.get_dict(), data)
    cookies = response.cookies.get_dict()
    path.unlink()
    return cookies


def create_session_with_retry():
    session = requests.Session()

    retry = Retry(
        total=3,
        backoff_factor=2,
        status_forcelist=[401],
        allowed_methods=["GET"],
        raise_on_status=False
    )

    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)

    return session


def open_browser_and_get_creds():
    input(f"\nPress Enter to open confirmation page, \n copy url after seeing \"R\":\"\",\"S\":\"OK\", \n  and return here")
    config_url = 'https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi&checkSafeAddress=true'
    if platform.system() == "Linux":
        os.system("xdg-open '" + config_url + "'")
    else:
        webbrowser.open(config_url)
    time.sleep(2)
    url = input("\nEnter url: ").strip()
    
    if urlparse(url).netloc != "unlock.update.miui.com":
        return {"error": "Invalid URL"}

    try:
        device_id = parse_qs(urlparse(url).query).get('d', [None])[0]
        if device_id is None:
            return {"error": "Invalid URL"}
    except (ValueError, IndexError):
        return {"error": "Invalid URL"}

    print('\ncheck Auth ...')
    session = create_session_with_retry()
    response = session.get(url, headers=headers)

    if response.status_code == 200:
        user_id = response.cookies.get('userId')
        if user_id:
            return {"user_id": user_id, "device_id": device_id}
        else:
            return {"error": "User ID not found in cookies!"}
    elif response.status_code == 401:
        print('\nURL(Auth) expired ...')
        return open_browser_and_get_creds()
    else:
        return {"error": f"Unexpected status code: {response.status_code}"}

def get_pass_token():

    if cookies_file.exists():
        pass_token = pickle.load(open(cookies_file, "rb"))
        choice = input(f"\nAlready logged in\nAccount ID: {pass_token['userId']}\n\nPress 'Enter' to continue\n(To log out, type 2 and press Enter.)").strip().lower()
        if choice == "2":
            cookies_file.unlink()
        else:
            return pass_token

    creds = open_browser_and_get_creds()
    if "error" in creds:
        return creds
        
    user_id = creds["user_id"]
    print(f'\naccount id: {user_id}')

    device_id = creds["device_id"]
    
    cookies = {'deviceId': device_id}
    
    url = 'https://account.xiaomi.com/pass/serviceLogin?sid=unlockApi'
    
    try:
        response = requests.get(url, headers=headers, cookies=cookies)
        response.raise_for_status()
        cookies = response.cookies.get_dict()
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}

    data = {
        '_json': 'true',
        'callback': 'https://unlock.update.miui.com/sts',
        'sid': 'unlockApi',
        'qs': '%3Fsid%3DunlockApi',
        '_sign': 'CiofaOM8ndWC+UjNoI6pjSx8sPM=',
        'serviceParam': '{"checkSafePhone":false,"checkSafeAddress":false,"lsrp_score":0.0}',
        '_locale': 'en_US',
        'useManMachine': 'false',
        'user': user_id
    }
    
    pwd = input(f'\nEnter password: ')
    data["hash"] = hashlib.md5(pwd.encode()).hexdigest().upper()
    
    try:
        response = requests.post(
            "https://account.xiaomi.com/pass/serviceLoginAuth2",
            data=data,
            headers=headers,
            cookies=cookies
        )
        response.raise_for_status()
        
        response_text = json.loads(response.text[11:])
        
        if response_text.get("code") == 70016:
            return {"error": "Invalid password"}      
        elif response_text.get("code") == 87001:
            print('\nCAPTCHA verification required !')
            captchaUrl = response_text["captchaUrl"]
            cookies = captcha_v(captchaUrl, response.cookies.get_dict(), data)
        else:
            cookies = response.cookies.get_dict()

        if 'passToken' not in cookies:
            print('\ndebug:', response_text)
            return {"error": "Failed to get pass token"}

        cookies_file.parent.mkdir(parents=True, exist_ok=True)
        pickle.dump(cookies, open(cookies_file, "wb"))
        print("\nLogin successful")

        return cookies
        
    except requests.exceptions.RequestException as e:
        return {"error": str(e)}
    except (ValueError, KeyError, json.JSONDecodeError) as e:
        return {"error": f"Failed to parse response: {e}"}