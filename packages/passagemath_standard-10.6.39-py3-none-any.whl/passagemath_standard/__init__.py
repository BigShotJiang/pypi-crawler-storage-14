# sage_setup: distribution = sagemath-standard

from sage.all import *
