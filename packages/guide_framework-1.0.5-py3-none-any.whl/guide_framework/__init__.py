﻿"""
GUIDE AI Ethics Framework

G - Governance
U - Understanding
I - Integrity
D - Disclosure
E - Equity

This package provides:
- Ethical AI Audit Tools
- Governance + Compliance Auditing
- Explainability (XAI) & Transparency Tools
- GUIDE principle-based assessments
"""

__version__ = "1.0.4"
__author__ = "GUIDE Ethics Team"

# -------------------------
# Import Public Classes
# -------------------------

# Main GUIDE Auditor (original)
from .guide import GUIDEAuditor

# Ethical + Governance Auditor (new)
from .auditor import EthicalAIAudit

# Explainability & Transparency (XAI)
from .xai_meaning import ExplainabilityGuide

# -------------------------
# Public API
# -------------------------

__all__ = [
    "GUIDEAuditor",
    "EthicalAIAudit",
    "ExplainabilityGuide"
]
