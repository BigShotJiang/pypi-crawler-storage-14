import os
import openai

class ExplainabilityGuide:
    """
    Explainability & Transparency Module
    ------------------------------------
    Provides:
    - Plain-language explanations of AI decisions
    - Transparency summaries
    - Accountability logs
    """

    def __init__(self, api_key=None, model_name="gpt-4o-mini"):
        # SAFE METHOD: use provided API key or environment variable
        if api_key:
            openai.api_key = api_key
        else:
            env_key = os.getenv("OPENAI_API_KEY")
            if env_key:
                openai.api_key = env_key
        
        self.model_name = model_name

    def explain_decision(self, decision, context=""):
        """
        Explain an AI decision in simple words.
        """
        prompt = f"""
        Explain the following AI decision clearly, ethically, and simply.
        Avoid technical language. Make it accessible to everyone.

        DECISION: {decision}
        CONTEXT: {context}

        Include:
        - What the AI did
        - Why it likely made this decision
        - Any limitations
        - Ethical considerations
        - Human impact
        """
        response = openai.ChatCompletion.create(
            model=self.model_name,
            messages=[{"role": "user", "content": prompt}]
        )

        return response["choices"][0]["message"]["content"]

    def transparency_summary(self, metadata):
        """
        Provide a transparency report for the model.
        """
        model_name = metadata.get("model_name", "Unknown")
        version = metadata.get("version", "N/A")
        data = metadata.get("training_data", "Not specified")
        purpose = metadata.get("purpose", "Not documented")
        risks = metadata.get("risks", "Not provided")

        return f"""
        Transparency Summary
        --------------------
        Model Name: {model_name}
        Version: {version}
        Purpose: {purpose}
        Training Data: {data}
        Risks/Limitations: {risks}
        """.strip()

    def justification_log(self, input_data, output_data, explanation):
        """
        Generate an accountability log for audits.
        """
        return {
            "input": input_data,
            "output": output_data,
            "explanation": explanation,
            "notes": "Generated using ethical + transparency guidelines."
        }
