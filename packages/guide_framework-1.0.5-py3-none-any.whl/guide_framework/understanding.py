﻿def check():
    msg = "[Understanding] Do stakeholders clearly understand how the model works?"
    print(msg)
    return msg
