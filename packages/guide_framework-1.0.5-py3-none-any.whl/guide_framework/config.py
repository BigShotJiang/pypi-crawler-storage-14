﻿DEFAULT_MODE = "reflection"

def set_mode(mode):
    global DEFAULT_MODE
    DEFAULT_MODE = mode
    print(f"[Config] GUIDE mode set to: {mode}")
