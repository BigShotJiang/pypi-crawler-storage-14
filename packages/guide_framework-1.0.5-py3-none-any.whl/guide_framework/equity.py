﻿def check():
    msg = "[Equity] Does this system promote fairness and inclusion?"
    print(msg)
    return msg
