"""Built-in node types for YBAgent workflows."""

from ybagent.nodes.llm_nodes import OpenAINode, HuggingFaceNode, LLMPromptNode, OllamaNode
from ybagent.nodes.control_nodes import ConditionalNode, SwitchNode, LoopNode, MergeNode
from ybagent.nodes.io_nodes import InputNode, OutputNode, VariableNode
from ybagent.nodes.action_nodes import APICallNode, TransformNode, ScriptNode

from .data_nodes import (
    WebScraperNode,
    FileReadNode,
    FileWriteNode,
    EmailNode,
    DatabaseNode
)

from .ai_nodes import (
    VectorSearchNode,
    SummarizationNode,
    TranslationNode,
    SentimentAnalysisNode,
    ClassificationNode,
    NERNode
)

from .debug_nodes import (
    LoggerNode,
    DebugNode,
    NotificationNode,
    FailNode
)

from .agent_nodes import (
    CodeAgentNode
)

from .reasoning_nodes import (
    ReActAgentNode
)

__all__ = [
    "InputNode", "OutputNode", "VariableNode",
    "LLMPromptNode", "OpenAINode", "HuggingFaceNode", "OllamaNode",
    "ConditionalNode", "SwitchNode", "LoopNode", "MergeNode",
    "APICallNode", "TransformNode", "ScriptNode",
    "WebScraperNode", "FileReadNode", "FileWriteNode", "EmailNode", "DatabaseNode",
    "VectorSearchNode", "SummarizationNode", "TranslationNode", "SentimentAnalysisNode", "ClassificationNode", "NERNode",
    "LoggerNode", "DebugNode", "NotificationNode", "FailNode",
    "CodeAgentNode", "ReActAgentNode"
]
