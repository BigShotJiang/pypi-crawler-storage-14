"""
YBAgent: AgentFlow - Visual Workflow Builder for AI Agents

A powerful Python library for building AI Agent workflows with a visual drag-and-drop interface.
"""

__version__ = "0.1.1"
__author__ = "YB AI Innovation Team"

from ybagent.workflow import Workflow, WorkflowExecutor, WorkflowState
from ybagent.node import BaseNode, NodeInput, NodeOutput, NodeType
from ybagent.edge import Edge

# Import built-in nodes
from ybagent.nodes.llm_nodes import OpenAINode, HuggingFaceNode, LLMPromptNode, OllamaNode
from ybagent.nodes.control_nodes import ConditionalNode, SwitchNode, LoopNode, MergeNode
from ybagent.nodes.io_nodes import InputNode, OutputNode, VariableNode
from ybagent.nodes.action_nodes import APICallNode, TransformNode, ScriptNode
from ybagent.nodes.data_nodes import WebScraperNode, FileReadNode, FileWriteNode, EmailNode, DatabaseNode, JsonLoaderNode
from ybagent.nodes.ai_nodes import (
    VectorSearchNode, SummarizationNode, TranslationNode, 
    SentimentAnalysisNode, ClassificationNode, NERNode, VisionNode
)
from ybagent.nodes.debug_nodes import LoggerNode, DebugNode, NotificationNode
from ybagent.nodes.agent_nodes import CodeAgentNode, DataAnalysisNode

# Import monitoring and plugins
from ybagent.monitoring import WorkflowLogger, ExecutionTracker
from ybagent.plugins import PluginManager, NodeRegistry

__all__ = [
    # Core
    "Workflow",
    "WorkflowExecutor",
    "WorkflowState",
    "BaseNode",
    "NodeInput",
    "NodeOutput",
    "NodeType",
    "Edge",
    # LLM Nodes
    "OpenAINode",
    "HuggingFaceNode",
    "LLMPromptNode",
    "OllamaNode",
    # Control Nodes
    "ConditionalNode",
    "SwitchNode",
    "LoopNode",
    "MergeNode",
    # I/O Nodes
    "InputNode",
    "OutputNode",
    "VariableNode",
    # Action Nodes
    "APICallNode",
    "TransformNode",
    "ScriptNode",
    # Data Nodes
    "WebScraperNode",
    "FileReadNode",
    "FileWriteNode",
    "EmailNode",
    "DatabaseNode",
    "JsonLoaderNode",
    # Advanced AI Nodes
    "VectorSearchNode",
    "SummarizationNode",
    "TranslationNode",
    "SentimentAnalysisNode",
    "ClassificationNode",
    "NERNode",
    "VisionNode",
    # Debug Nodes
    "LoggerNode",
    "DebugNode",
    "NotificationNode",
    # Agent Nodes
    "CodeAgentNode",
    "DataAnalysisNode",
    # Monitoring & Plugins
    "WorkflowLogger",
    "ExecutionTracker",
    "PluginManager",
    "NodeRegistry",
]
