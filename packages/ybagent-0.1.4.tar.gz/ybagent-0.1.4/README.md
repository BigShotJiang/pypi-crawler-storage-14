# YBAgent

**Workflow Builder for AI Agents**

YBAgent is a powerful Python framework for building sophisticated AI agent workflows through code. The first Arabic AI agent library that empowers developers to design, deploy, and monitor complex autonomous AI systems with intuitive programmatic control.

---

## Why YBAgent?

- **Multi-LLM Support** – OpenAI, Ollama, HuggingFace, and custom providers
- **Production-Ready Nodes** – Covering AI, vision, data science, data operations, control flow, and utilities
- **Intelligent Retry Logic** – Built-in exponential backoff and error handling
- **Full-Stack Integration** – Web scraping, file I/O, databases, vector search
- **Advanced Control Flow** – Conditionals, loops, switches, and merges
- **Enterprise Monitoring** – Integrated logging and execution tracking
- **Plugin Architecture** – Easily extend with custom nodes

---

## Installation

```bash
# Standard installation
pip install ybagent

# With sandbox support (Docker + RestrictedPython)
pip install ybagent[sandbox]
```

---

## Quick Start

```python
from ybagent import Workflow, InputNode, OutputNode, OllamaNode, LLMPromptNode

from ybagent import Workflow, InputNode, OutputNode, OllamaNode, LLMPromptNode

# 1. Setup workflow
wf = Workflow(name="OllamaTestWorkflow")

# 2. Add nodes
wf.add_node(
    InputNode(
        id="input_1",
        name="GetUserQuestion"
    )
)

wf.add_node(
    LLMPromptNode(
        id="prompt_formatter",
        template="{question}"
    )
)

wf.add_node(
    OllamaNode(
        id="node_gemma",
        name="gemma_node",
        model="gemma3:4b",
        temperature=0.7
    )
)

wf.add_node(
    OutputNode(
        id="output_1",
        name="PrintResponse"
    )
)

# 3. Connect nodes (new clean structure)

# Input → Prompt formatter
wf.connect(
    "input_1",
    "prompt_formatter",
    source_output="output",
    target_input="variables"
)

# Prompt formatter → Gemma LLM
wf.connect(
    "prompt_formatter",
    "node_gemma",
    source_output="prompt",
    target_input="prompt"
)

# LLM result → Output
wf.connect(
    "node_gemma",
    "output_1",
    source_output="response",
    target_input="input"
)

# 4. Execute workflow
user_question = "Whats AI Agent In Short?"
res = wf.execute({"question": user_question})
```

---

## Node Reference

| Category | Nodes |
|----------|-------|
| **Input/Output** | `InputNode`, `OutputNode` |
| **AI & NLP** | `OpenAINode`, `OllamaNode`, `HuggingFaceNode`, `SummarizationNode`, `SentimentNode`, `TranslationNode`, `ClassificationNode`, `NERNode`, `VectorSearchNode`, `CodeAgentNode`, `ReActAgentNode` |
| **Data Operations** | `WebScraperNode`, `FileReaderNode`, `FileWriterNode`, `DatabaseNode`, `APICallNode` |
| **Vision & Analysis** | `VisionNode`, `DataAnalysisNode` |
| **Control Flow** | `ConditionalNode`, `SwitchNode`, `LoopNode`, `MergeNode` |
| **Utilities** | `TransformNode`, `ScriptNode`, `LoggerNode`, `DebugNode`, `NotificationNode`, `FailNode` |

---

## Key Features

### AI & Machine Learning
- **LLM Integration** – OpenAI GPT-4, local Ollama models, HuggingFace transformers
- **NLP Operations** – Summarization, sentiment analysis, translation, classification, NER
- **Vector Search** – Semantic similarity with ChromaDB embeddings
- **Vision AI** – Optical Character Recognition (OCR) for extracting text from images and PDF files
- **Data Science** – Data analysis, data visualization, data cleaning, data transformation, Machine Learning

### Data Integration
- **Web Scraping** – Robust HTML parsing with anti-blocking
- **File Operations** – JSON, CSV, TXT, binary support
- **Databases** – SQL queries with connection pooling
- **APIs** – Full HTTP client with auth and rate limiting

### Advanced Capabilities
- **Autonomous Agents** – Self-correcting code agent, ReAct reasoning agent
- **Workflow Persistence** – JSON serialization for version control
- **Fault Tolerance** – Automatic recovery with exponential backoff
- **Custom Extensions** – Plugin architecture for domain-specific logic

---

## Use Cases

- **Conversational AI** – Build chatbots with context management
- **Content Intelligence** – Automate content extraction and analysis
- **Data Engineering** – AI-enhanced ETL pipelines
- **Document Processing** – Extract insights from unstructured documents
- **Research Automation** – Multi-source information gathering
- **Multi-Agent Systems** – Coordinate specialized AI agents

---

## License

**YB Agent Proprietary License**

Copyright © 2025 YB AI Innovation Team – All Rights Reserved

This library may be used within your applications (commercial or private) alongside other libraries. Redistribution, modification, or creation of derivative works is prohibited without prior written consent.

See [LICENSE]file for complete terms.

---

**Developed by YB AI Innovation Team**