"""
Created on 2024-04-18

@author: wf
"""

import sys

import wikibot3rd.wikipush

if __name__ == "__main__":
    sys.exit(wikibot3rd.wikipush.mainQuery())
