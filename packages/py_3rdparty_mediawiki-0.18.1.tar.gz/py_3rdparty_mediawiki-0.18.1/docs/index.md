# py-3rdparty-mediawiki API Documentation

::: wikibot3rd
    options:
      show_submodules: true
