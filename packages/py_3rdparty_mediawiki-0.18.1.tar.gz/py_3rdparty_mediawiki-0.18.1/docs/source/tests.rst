tests package
=============

Submodules
----------

tests.basetest module
---------------------

.. automodule:: tests.basetest
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_MediaWikiTable module
---------------------------------

.. automodule:: tests.test_MediaWikiTable
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_PageHistory module
------------------------------

.. automodule:: tests.test_PageHistory
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_SMWApi module
-------------------------

.. automodule:: tests.test_SMWApi
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_Selector module
---------------------------

.. automodule:: tests.test_Selector
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_WikiPush module
---------------------------

.. automodule:: tests.test_WikiPush
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_WikiUser module
---------------------------

.. automodule:: tests.test_WikiUser
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_duckinterface module
--------------------------------

.. automodule:: tests.test_duckinterface
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_lambda module
-------------------------

.. automodule:: tests.test_lambda
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_wikibot module
--------------------------

.. automodule:: tests.test_wikibot
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_wikiclient module
-----------------------------

.. automodule:: tests.test_wikiclient
   :members:
   :undoc-members:
   :show-inheritance:

tests.test\_wikiquery module
----------------------------

.. automodule:: tests.test_wikiquery
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tests
   :members:
   :undoc-members:
   :show-inheritance:
