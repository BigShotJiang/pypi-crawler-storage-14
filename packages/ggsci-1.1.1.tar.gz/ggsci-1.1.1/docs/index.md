# ggsci for Python <img src="assets/logo.png" align="right" width="120" />

[![PyPI version](https://img.shields.io/pypi/v/ggsci)](https://pypi.org/project/ggsci/)
![Python versions](https://img.shields.io/pypi/pyversions/ggsci)
[![CI tests](https://github.com/nanxstats/py-ggsci/actions/workflows/ci-tests.yml/badge.svg)](https://github.com/nanxstats/py-ggsci/actions/workflows/ci-tests.yml)
[![Mypy check](https://github.com/nanxstats/py-ggsci/actions/workflows/mypy.yml/badge.svg)](https://github.com/nanxstats/py-ggsci/actions/workflows/mypy.yml)
[![Ruff check](https://github.com/nanxstats/py-ggsci/actions/workflows/ruff-check.yml/badge.svg)](https://github.com/nanxstats/py-ggsci/actions/workflows/ruff-check.yml)
[![mkdocs](https://github.com/nanxstats/py-ggsci/actions/workflows/mkdocs.yml/badge.svg)](https://nanx.me/py-ggsci/)
![License](https://img.shields.io/pypi/l/ggsci)

ggsci for Python offers a collection of plotnine color palettes inspired by
scientific journals, data visualization libraries, science fiction movies,
and TV shows.

## Installation

You can install py-ggsci from PyPI:

```bash
pip install ggsci
```

Or install the development version from GitHub:

```bash
git clone https://github.com/nanxstats/py-ggsci.git
cd py-ggsci
python3 -m pip install -e .
```
