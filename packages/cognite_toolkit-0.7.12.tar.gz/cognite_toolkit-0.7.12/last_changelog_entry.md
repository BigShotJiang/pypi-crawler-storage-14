## Changelog 

### Added

- Added the `cdf about` command to give an overview of current toolkit
configuration and simplify debugging issues.