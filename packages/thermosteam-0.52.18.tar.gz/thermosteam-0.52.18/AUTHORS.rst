The Thermosteam Project Contributors is composed of:

* Yoel Cortes-Pena (Main Thermosteam author and maintainer)
* All other developers that have contributed to the thermosteam repository:
  
      https://github.com/BioSTEAMDevelopmentGroup/thermosteam/graphs/contributors

Additionally, some assets and code were originally sourced from third-party
authors or projects, including:

* Most chemical properties, including data and functions, are derived from `thermo <https://github.com/CalebBell/thermo>`_, by Caleb Bell.