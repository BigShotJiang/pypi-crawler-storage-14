pip3 install --upgrade pip
pip3 install jupyter
