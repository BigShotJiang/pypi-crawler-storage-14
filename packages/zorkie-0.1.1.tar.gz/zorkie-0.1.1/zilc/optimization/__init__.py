"""
Optimization passes for Z-machine story files.

These passes run after code generation but before assembly,
transforming and optimizing the intermediate representation.
"""
