"""Code generation - converts AST to Z-machine bytecode."""

from .codegen import CodeGenerator

__all__ = ['CodeGenerator']
