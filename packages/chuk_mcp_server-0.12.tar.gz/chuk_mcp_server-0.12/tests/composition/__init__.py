"""Tests for composition module."""
