"""
__init__ module
"""

from .main import CausalImpactAnalysis
