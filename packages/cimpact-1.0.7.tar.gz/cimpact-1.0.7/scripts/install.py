import yaml



def generate_docs():
    pass


def main():
    # edit_config_file()  #TODO: COmment by Dip (just this line)
    generate_docs()


if __name__ == "__main__":
    main()
