# En iatoolkit_enterprise/registry.py

from iatoolkit.company_registry import CompanyRegistry
from iatoolkit.base_company import BaseCompany
from typing import Dict, Type, Any


class EnterpriseRegistry(CompanyRegistry):
    def register(self, name: str, company_class: Type[BaseCompany]) -> None:
        # Enterprise logic: Allow unlimited companies
        company_key = name.lower()
        self._company_classes[company_key] = company_class

        # (Opcional) Validar contra el límite de la licencia Enterprise (ej. 5, 10, unlimited)