# COPIA ESTO EN: iatoolkit-enterprise/src/iatoolkit_enterprise/views/external_login_view.py

import logging
from flask import request, jsonify, url_for
from iatoolkit.views.base_login_view import BaseLoginView
from iatoolkit.common.session_manager import SessionManager

class ExternalLoginView(BaseLoginView):
    """
    Handles login for external users via API (Enterprise Implementation).
    """
    def post(self, company_short_name: str):
        # Authenticate the API call.
        auth_result = self.auth_service.verify()
        if not auth_result.get("success"):
            return jsonify(auth_result), auth_result.get("status_code")

        company = self.profile_service.get_company_by_short_name(company_short_name)
        if not company:
            return jsonify({"error": f"company not found: {company_short_name}"}), 404

        user_identifier = auth_result.get('user_identifier')

        # --- ENTERPRISE LOGIC START (Moved from ProfileService) ---
        # 1. Fetch the external user profile via Dispatcher.
        # We access dispatcher via profile_service to reuse the existing injection
        external_user_profile = self.profile_service.dispatcher.get_user_info(
            company_name=company.short_name,
            user_identifier=user_identifier
        )

        # 2. Call the generic session creation helper in ProfileService
        self.profile_service.save_user_profile(
            company=company,
            user_identifier=user_identifier,
            user_profile=external_user_profile
        )

        # 3. Make sure the flask session is clean
        SessionManager.clear()
        # --- ENTERPRISE LOGIC END ---

        # 3. Create a redeem_token for create session at the end of the process
        redeem_token = self.jwt_service.generate_chat_jwt(
            company_short_name=company_short_name,
            user_identifier=user_identifier,
            expires_delta_seconds=300
        )

        if not redeem_token:
            return jsonify({"error": "error generating reedem token for external login."}), 403

        # 4. Define URL to call when slow path is finished
        target_url = url_for('finalize_with_token',
                             company_short_name=company_short_name,
                             token=redeem_token,
                             _external=True)

        # 5. Delegate the path decision to the centralized logic.
        try:
            return self._handle_login_path(company_short_name, user_identifier, target_url, redeem_token)
        except Exception as e:
            logging.exception(f"Error processing external login path for {company_short_name}/{user_identifier}: {e}")
            return jsonify({"error": f"Internal server error while starting chat. {str(e)}"}), 500


class RedeemTokenApiView(BaseLoginView):
    # This endpoint is only used ONLY by chat_main.js to redeem a chat token
    def post(self, company_short_name: str):
        data = request.get_json()
        if not data or 'token' not in data:
            return jsonify({"error": "missing validation token in api-view"}), 400

        # get the token and validate with auth service
        token = data.get('token')
        redeem_result = self.auth_service.redeem_token_for_session(
            company_short_name=company_short_name,
            token=token
        )

        if not redeem_result['success']:
            return {"error": redeem_result['error']}, 401

        return {"status": "ok"}, 200