# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit
#
# IAToolkit is open source software.


import logging
from typing import Optional, Dict, Any
from injector import Injector
from iat_enterprise.common.exceptions import IatEnterpriceException
from iatoolkit import IAToolkit, register_company


IATOOLKIT_ENTERPRISE_VERSION = "1"

# global variable for the unique instance of IAToolkit
_enterprise_instance: Optional['IatEnterprise'] = None

class IatEnterprise:
    """
    IAToolkit Enterprise main class
    """
    def __new__(cls, config: Optional[Dict[str, Any]] = None):
        """
        Implementa el patrón Singleton
        """
        global _enterprise_instance
        if _enterprise_instance is None:
            _enterprise_instance = super().__new__(cls)
            _enterprise_instance._initialized = False
        return _enterprise_instance


    def __init__(self):
        if self._initialized:
            return

    @classmethod
    def get_instance(cls) -> 'IatEnterprise':
        # get the global IatEnterprise instance
        global _enterprise_instance
        if _enterprise_instance is None:
            _enterprise_instance = cls()
        return _enterprise_instance

    def create(self):
        """
            Creates, configures, and returns the Flask application instance.
            this is the main entry point for the application factory.
        """
        if self._initialized :
            return self

        # 1. Initialize and create the IAToolkit community instance
        self.iatoolkit = IAToolkit()
        self.iatoolkit.create_iatoolkit()

        self._configure_core_dependencies(self.iatoolkit.get_injector())
        self._register_routes()

        self._setup_cli_commands()
        self._setup_license()

        self.version = f"{self.iatoolkit.version}.{IATOOLKIT_ENTERPRISE_VERSION}"
        self._initialized = True

        logging.info(f"🎉 IAToolkit {self.license} version {self.version} correctly initialized.")


    def _configure_core_dependencies(self, injector: Injector):
        """⚙️ Configures all system dependencies."""
        try:

            # Bind all application components by calling the specific methods
            self._bind_repositories(injector)
            self._bind_views(injector)
            self._bind_services(injector)
            self._bind_infrastructure(injector)

            logging.info("✅ Enterprise dependencies configured successfully")


        except Exception as e:
            logging.error(f"❌ Error configuring dependencies: {e}")
            raise IatEnterpriceException(
                IatEnterpriceException.ErrorType.CONFIG_ERROR,
                f"❌ Error configuring dependencies: {e}"
            )

    def _register_routes(self):
        from iat_enterprise.common.routes import register_views
        from flask_injector import FlaskInjector

        register_views(self.iatoolkit.app)

        # IMPORTANT: Re-initialize FlaskInjector to process the enterprise views
        # This allows @inject to work in Enterprise views.
        FlaskInjector(app=self.iatoolkit.app, injector=self.iatoolkit.get_injector())


    def _bind_repositories(self, injector: Injector):
        pass

    def _bind_services(self, injector: Injector):
        from iat_enterprise.services.license_service import LicenseService

        injector.binder.bind(LicenseService, to=LicenseService)

    def _bind_infrastructure(self, injector: Injector):
        pass

    def _bind_views(self, injector):
        from iat_enterprise.views.login_simulation_view import LoginSimulationView
        injector.binder.bind(LoginSimulationView, to=LoginSimulationView)

    def _setup_cli_commands(self):
        from iat_enterprise.cli_commands import register_enterprise_commands

        # 1. Register core commands
        register_enterprise_commands(self.iatoolkit.app)
        logging.info("✅ Enterprise commands registered.")


    def _setup_license(self):
        from iat_enterprise.services.license_service import LicenseService

        license_service = self.iatoolkit.get_injector().get(LicenseService)
        plan_name = license_service.get_plan_name()
        self.iatoolkit.license = plan_name
        self.license = plan_name

# Función de conveniencia para inicialización rápida
def create_enterprise_app() -> IatEnterprise:
    iat_enterprise = IatEnterprise()
    iat_enterprise.create()

    return iat_enterprise


