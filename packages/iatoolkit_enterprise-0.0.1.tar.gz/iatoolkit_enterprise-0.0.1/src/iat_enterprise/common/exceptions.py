# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit
#
# IAToolkit is open source software.

from enum import Enum


class IatEnterpriceException(Exception):

    class ErrorType(Enum):
        SYSTEM_ERROR = 0
        DATABASE_ERROR = 1
        LLM_ERROR = 2
        CLOUD_STORAGE_ERROR = 3
        DOCUMENT_NOT_FOUND = 4
        INVALID_PARAMETER = 5
        MISSING_PARAMETER = 6
        PARAM_NOT_FILLED = 7
        PERMISSION = 8
        EXIST = 9
        LICENSE_KEY = 10
        PUBLIC_KEY = 11
        CONFIG_ERROR = 12



    def __init__(self, error_type: ErrorType = ErrorType.SYSTEM_ERROR, message=None):
        self.error_type = error_type
        self.message = message
        super().__init__(self.message)
