# Copyright (c) 2024 Fernando Libedinsky
# Product: IAToolkit
#
# IAToolkit is open source software.


# this function register all the views
def register_views(app):

    from iat_enterprise.views.external_login_view import ExternalLoginView, RedeemTokenApiView
    from iat_enterprise.views.login_simulation_view import LoginSimulationView


    # this is the login for external users
    app.add_url_rule('/<company_short_name>/ent_external_login',
                     view_func=ExternalLoginView.as_view('ent_external_login'))

    # this endpoint is called by the JS for changing the token for a session
    app.add_url_rule('/<string:company_short_name>/api/ent_redeem_token',
                     view_func = RedeemTokenApiView.as_view('ent_redeem_token'))


    # login testing
    app.add_url_rule('/<company_short_name>/ent_login',
                     view_func=LoginSimulationView.as_view('ent_login'))


