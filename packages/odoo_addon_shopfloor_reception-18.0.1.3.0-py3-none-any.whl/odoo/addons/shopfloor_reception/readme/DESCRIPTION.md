Shopfloor implementation of the reception scenario. Allows to receive
products and create the proper packs for each logistic unit.
