# -*- coding: utf-8 -*-

HELP = (
    "To tccli help text, you can run:\n"
    "\n"
    "  tccli help\n"
    "  tccli configure help\n"
    "  tccli service[cvm] help\n"
    "  tccli service[cvm] action[RunInstances] help\n"
)
USAGE = (
    "tccli [options] <command> <subcommand> [<subcommand> ...] [parameters]\n"
    "%s" % HELP
)
