#
# Copyright 2025 Yitao Zhang
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#

SUCCESS = 0
GENERAL_FAIL = 1
INVALID_INPUT_FILE = 2
FAIL_WRITE_OUTPUT_FILE = 3
INVALID_FORMAT = 4
INVALID_OPTION = 5
