# 
# Copyright 2025 Yitao Zhang
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#

from bin2hex.main import main

if __name__ == '__main__':
    raise SystemExit(main())