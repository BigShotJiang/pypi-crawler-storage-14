#!/bin/bash

pdoc -c show_source_code=False --html izi18n