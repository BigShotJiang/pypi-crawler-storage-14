AUTH_SANDBOX_URL = 'https://sandbox-oauth.piste.gouv.fr/api/oauth/token'
AUTH_PRODUCTION_URL = 'https://oauth.piste.gouv.fr/api/oauth/token'
API_SANDBOX_URL = 'https://sandbox-api.piste.gouv.fr'
API_PRODUCTION_URL = 'https://api.piste.gouv.fr'