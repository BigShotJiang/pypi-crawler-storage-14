"""Test suite for streamlm."""
