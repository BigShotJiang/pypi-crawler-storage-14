# sage_setup: distribution = sagemath-mcqd

from sage.all__sagemath_mcqd import *
