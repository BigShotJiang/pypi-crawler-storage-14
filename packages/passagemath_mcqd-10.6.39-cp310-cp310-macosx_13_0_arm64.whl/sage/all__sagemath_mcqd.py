# sage_setup: distribution = sagemath-mcqd
# delvewheel: patch
