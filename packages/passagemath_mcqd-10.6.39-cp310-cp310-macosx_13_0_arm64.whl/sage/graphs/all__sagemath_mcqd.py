# sage_setup: distribution = sagemath-mcqd
