"""Manager classes for Docker Monitor Manager."""
