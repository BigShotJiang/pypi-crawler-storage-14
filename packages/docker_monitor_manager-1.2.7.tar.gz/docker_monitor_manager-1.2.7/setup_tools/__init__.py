"""Setup tools for docker-monitor-manager installation and uninstallation"""

__all__ = ['post_install', 'uninstall']
