import re
import uuid

class DeviceLabelComposer:

    def __init__(self, raw_name):
        self.raw_name = raw_name

    def sanitise_name(self):
        """Remove unwanted characters and normalise spacing."""
        cleaned = re.sub(r'[^A-Za-z0-9 ]+', '', self.raw_name)
        return cleaned.strip().title()

    def forge_reference_id(self):
        """Create a unique but reproducible reference ID."""
        return "ELEC-" + str(uuid.uuid4())[:8]

    def craft_device_bundle(self):
        """Return a dictionary with formatted output."""
        return {
            "clean_name": self.sanitise_name(),
            "reference_id": self.forge_reference_id()
        }
