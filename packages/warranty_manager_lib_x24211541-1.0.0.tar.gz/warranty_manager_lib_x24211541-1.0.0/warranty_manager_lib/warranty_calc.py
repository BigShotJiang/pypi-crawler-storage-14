from datetime import datetime, timedelta

class ChronoWarrantyInspector:
    
    def __init__(self, purchase_date_str, warranty_months):
        self.purchase_date = datetime.strptime(purchase_date_str, "%Y-%m-%d")
        self.warranty_months = warranty_months

    def derive_expiry_date(self):
        """Return expiry date based on purchase date + months."""
        # Convert months to approximate days (30 per month)
        return self.purchase_date + timedelta(days=self.warranty_months * 30)

    def compute_days_left(self):
        """Return remaining warranty days."""
        expiry = self.derive_expiry_date()
        return (expiry - datetime.now()).days

    def is_warranty_active(self):
        """Check if warranty is still valid."""
        return self.compute_days_left() > 0

    def generate_warranty_summary(self):
        """Readable summary for debugging or UI display."""
        expiry = self.derive_expiry_date().strftime("%Y-%m-%d")
        days_left = self.compute_days_left()
        status = "ACTIVE" if days_left > 0 else "EXPIRED"

        return {
            "expiry_date": expiry,
            "days_left": days_left,
            "status": status
        }
