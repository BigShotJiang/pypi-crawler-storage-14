# warranty-manager-lib-x24211541

A custom Python library developed for the **Electronics Warranty Cloud Application**, created as part of the Cloud Platform Programming module.

This library provides utilities used by AWS Lambda functions and the Flask application.  
It includes functionality for:

### Warranty expiry date calculation  
### Human-readable date formatting  
### Device name sanitization and reference ID creation  

The library is used in an end-to-end cloud application deployed on AWS using:
- AWS Lambda  
- DynamoDB  
- API Gateway  
- S3  
- SNS  
- Elastic Beanstalk  

---

## Installation

After publishing to PyPI, install using:

pip install warranty-manager-lib-x24211541

## Usage Example

from warranty_manager_lib import ChronoWarrantyInspector

# Warranty checker example
inspector = ChronoWarrantyInspector("2024-01-10", 12)
summary = inspector.generate_warranty_summary()
print(summary)

## Library Content

warranty_manager_lib/
    __init__.py
    formatter.py
    warranty_calc.py
