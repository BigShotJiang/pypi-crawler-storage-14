---
title: "API Reference"
icon: "material/book-open-variant"
---

# API

A comprehensive API documentation of the benchmark tool python module.
