---
title: "ODS Gen"
---

# ODS Gen

::: benchmarktool.result.ods_gen
    handler: python
    options:
      filters: public
