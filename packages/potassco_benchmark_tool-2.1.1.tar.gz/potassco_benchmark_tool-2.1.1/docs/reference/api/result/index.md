---
title: "Result Components"
icon: "material/database"
---

# Result Components

All components regarding result parsing, evaluation and ODS file generation.
