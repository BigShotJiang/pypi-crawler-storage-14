---
title: "Result Parser"
---

# Result Parser

::: benchmarktool.result.parser
    handler: python
    options:
      filters: public
