$CAT {run.files} {run.root} {run.timeout} {run.memout} {run.root}/programs/{run.solver} {run.args} {run.encodings}
