"""Marvel Scheduler - Telescope Observation Scheduling."""

__version__ = "2.0.4"

from .main import main

__all__ = ["main"]