from setuptools import setup, find_packages
import os

# 读取 README（如果存在）
import os
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
else:
    long_description = "跨境电商数据分析工具包，包含数据清洗、分析、建模和可视化功能。"

setup(
    name="pandas2b",
    version="1.0.6",
    author="Data Analysis Team",
    author_email="analytics@company.com",
    description="跨境电商数据分析工具包 - 包含数据清洗、分析、建模和可视化功能",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/pandas2b",
    packages=['pandas2b'],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "pandas>=1.5.0",
        "numpy>=1.23.0",
        "matplotlib>=3.6.0",
        "seaborn>=0.12.0",
        "scikit-learn>=1.2.0",
        "pymysql>=1.0.0",
        "pyecharts>=2.0.0",
    ],
    extras_require={
        "dev": [
            "jupyter>=1.0.0",
            "pytest>=7.0.0",
        ],
    },
    package_data={
        'pandas2b': ['sql/*.sql', 'data/*.txt', 'report/*.md'],
    },
    include_package_data=True,
)
