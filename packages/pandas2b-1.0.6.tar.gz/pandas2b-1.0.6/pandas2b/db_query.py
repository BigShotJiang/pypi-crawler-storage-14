import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import pymysql
##120.55.6.12:3306 root Chen@123456
db_config = {
    'host': '120.55.6.12',
    'port': 3306,
    'user': 'root',
    'password': 'Chen@123456',
    'charset': 'utf8mb4',
    'database': 'ecm_analysis'
}

def execute_sql_query(query) :
    conn = pymysql.connect(**db_config)
    try :
        with conn.cursor() as cursor :
            cursor.execute(query)
            result = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            return pd.DataFrame(result,columns=columns)
    except Exception as e :
        print(e)
        return None
    finally:
        conn.close()

querys={
    "查询销售趋势":"""
    select month,sum(total_amount) as mouth_amount,count(order_id) from orders
    group by month
    order by month
    """
}

for query_name,query in querys.items() :
    print(f"{query_name}")
    print(execute_sql_query(query).head())