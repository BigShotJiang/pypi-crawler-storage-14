import pandas as pd
import matplotlib.pyplot as plt
import matplotlib

matplotlib.use("Agg")
import seaborn as sns

# 正确设置中文字体（修正拼写错误）
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False  # 修正为unicode_minus


def main():
    # 加载数据
    model_data = pd.read_csv("./clean.csv")

    # 创建大画布
    plt.figure(figsize=(20, 20))

    # 1. 月度销售额-折线图
    plt.subplot(5, 2, 1)
    month_sales = model_data.groupby("month")['total_amount'].sum()
    plt.plot(month_sales.index, month_sales.values,
             marker='o', linewidth=2, markersize=6, color='#2E86AB')
    plt.title("月度销售额趋势分析", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("月份", fontsize=12)
    plt.ylabel("销售额", fontsize=12)
    plt.grid(True, alpha=0.3)

    # 2. 分类销售分布-水平柱状图
    plt.subplot(5, 2, 2)
    category_sales = model_data.groupby("category")['total_amount'].sum().sort_values()
    plt.barh(category_sales.index, category_sales.values)
    plt.title("各品类销售分布", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("销售额", fontsize=12)
    plt.ylabel("产品分类", fontsize=12)
    plt.grid(True, alpha=0.3, axis='x')

    # 3. 商品价格与销量关系-散点图
    plt.subplot(5, 2, 3)
    plt.scatter(model_data["price"], model_data["quantity"],
                alpha=0.6, c=model_data["total_amount"], cmap='viridis')
    plt.colorbar(label='总销售额')
    plt.title("价格与销量关系分析", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("商品单价", fontsize=12)
    plt.ylabel("销售数量", fontsize=12)
    plt.grid(True, alpha=0.3)

    # 4. 各类价格-箱线图
    plt.subplot(5, 2, 4)
    sns.boxplot(x="category", y="price", data=model_data,
                palette='Set2')
    plt.title("各品类价格分布箱线图", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("产品分类", fontsize=12)
    plt.ylabel("单价", fontsize=12)
    plt.xticks(rotation=45)
    plt.grid(True, alpha=0.3)

    # 5. 月分类销售额-对比图
    plt.subplot(5, 1, 5)
    month_category_sales = model_data.groupby(["month", "category"])['total_amount'].sum().reset_index()
    sns.barplot(x='month', y='total_amount', data=month_category_sales,
                hue='category', palette='viridis')
    plt.title("月度-品类销售对比分析", fontsize=14, fontweight='bold', pad=15)
    plt.xlabel("月份", fontsize=12)
    plt.ylabel("销售额", fontsize=12)
    plt.legend(title="产品分类", bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(True, alpha=0.3, axis='y')
    plt.tight_layout()

    # 只保存一次
    plt.savefig("./综合销售分析报告.png", dpi=300, bbox_inches='tight')
    print("销售分析报告已保存为 './综合销售分析报告.png'")


if __name__ == "__main__":
    main()