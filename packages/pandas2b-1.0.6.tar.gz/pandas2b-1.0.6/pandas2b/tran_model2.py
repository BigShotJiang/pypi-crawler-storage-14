import pandas as pd

# 特征纬度、目标变量统计
model_data = pd.read_csv('./clean.csv')
category_dummies = pd.get_dummies(model_data['category'],prefix='category_')
model_data = pd.concat([model_data,category_dummies],axis=1)
features=['user_age', 'user_income', 'browse_time', 'price', 'quantity']\
         +[col for col in model_data.columns if col.startswith('category_')]
target = "total_amount"

X = model_data[features]
y = model_data[target]

from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split,cross_val_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import  mean_squared_error,r2_score
from sklearn.linear_model import LinearRegression
# 标准化数据
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

X_train,X_test,y_train,y_test = train_test_split(X_scaled,y,train_size=0.2,random_state=42)
lr_model = LinearRegression()
lr_model.fit(X_train,y_train)
y_pred_lr =  lr_model.predict(X_test)

rf_model = RandomForestRegressor()
rf_model.fit(X_train,y_train)
y_pred_rf = rf_model.predict(X_test)

lr_mse = mean_squared_error(y_test,y_pred_lr)
lr_r2 = r2_score(y_test,y_pred_lr)

rf_mse = mean_squared_error(y_test,y_pred_lr)
rf_r2 = r2_score(y_test,y_pred_lr)

cv_stores = cross_val_score(rf_model,X_scaled,y,cv=5,scoring='r2')
print(f"随机森林R2分数{cv_stores}")
print(f"R2平均值{cv_stores.mean():.4f}")

import  seaborn as sns
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")

feature_importance = pd.DataFrame({
    'features':features,
    'importance': rf_model.feature_importances_
}).sort_values('importance',ascending=False)

plt.rcParams['font.sans-serif'] = ["SimHei","Arial Unicode MS"]
plt.figure(figsize={20,40})
sns.barplot(data=feature_importance.head(10),x='importance',y='features')
plt.title("随机森林模型特征重要性排名")
plt.xlabel("重要性")
plt.ylabel("特征值")
plt.savefig("./随机森林模型特征重要性排名.png")
