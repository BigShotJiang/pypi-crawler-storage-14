import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")
import  seaborn as sns

plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

model_data =pd.read_csv("./clean.csv")
plt.figure(figsize=(20,20))
# 月度销售额-折线图
plt.subplot(5,2,1)
month_sales = model_data.groupby("month")['total_amount'].sum()
plt.plot(month_sales.index,month_sales.values)
plt.title("月度销售额")
plt.xlabel("月份")
plt.ylabel("销售额")
plt.grid()
plt.tight_layout()
plt.subplots_adjust(wspace=0.4,hspace=0.4)
plt.savefig("./月度销售额.png")
# 分类销售分部-柱状图
category_sales = model_data.groupby("category")['total_amount'].sum()
plt.subplot(5,2,2)
plt.barh(category_sales.index,category_sales.values)
plt.title("分类销售分部")
plt.xlabel("销售额")
plt.ylabel("分类")
plt.grid()
plt.savefig("./分类销售分部.png")
# 商品价格与销量关系-散点图
plt.subplot(5,2,3)
plt.scatter(model_data["price"],model_data["quantity"])
plt.title("商品价格与销量关系")
plt.xlabel("单价")
plt.ylabel("数量")
plt.grid()
plt.savefig("./商品价格与销量关系.png")
# 各类价格-箱线图
plt.subplot(5,2,4)
sns.boxplot(x="category",y="price",data=model_data)
plt.title("各类价格")
plt.xlabel("分类")
plt.ylabel("单价")
plt.savefig("./各类价格.png")
# 月分类销售额-对比图
plt.subplot(5,2,5)
month_category_sales = model_data.groupby(["month","category"])['total_amount'].sum().reset_index()
sns.barplot(x='month',y='total_amount',data=month_category_sales,hue='category')
plt.title("月分类销售额-对比")
plt.xlabel("月")
plt.ylabel("销售额")
plt.legend(title="分类")
plt.savefig("./月分类销售额-对比.png")


