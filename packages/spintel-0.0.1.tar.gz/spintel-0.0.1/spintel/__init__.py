"""spintel - Spatial Intelligence services to turn words into worlds..."""

__version__ = "0.0.1"
