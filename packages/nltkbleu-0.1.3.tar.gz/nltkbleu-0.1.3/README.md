# nltkbleud

Python package that provides the `BLEUD` class.
