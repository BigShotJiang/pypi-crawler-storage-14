import os

import typer
import uvicorn

from fastapi_clean_archi.managements.commands.base import Command


class Runserver(Command):
    name = "runserver"
    help = "FastAPI server 가 실행됩니다."

    def execute(self,
                host_port=typer.Argument("localhost:8000", help="호스트와 포트를 지정합니다. 예: localhost:8000"),
                settings_env=typer.Option(".env", "--settings-env")):
        host, port = host_port.split(":")

        os.environ.setdefault("SETTINGS_ENV", settings_env)
        uvicorn.run("main:app", host=host, port=int(port), reload=True)