from __future__ import annotations

import logging

from module_qc_analysis_tools.cli.main import app

logging.basicConfig()
__all__ = ("app",)
