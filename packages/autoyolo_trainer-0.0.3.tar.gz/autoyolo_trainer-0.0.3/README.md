# AutoYOLO-Trainer

**AutoYOLO-Trainer** is a Python package to automate training of YOLO models with:

- Custom augmentations
- Automatic base model download
- User-provided dataset YAML
- Configurable hyperparameters

## Installation

```bash
pip install autoyolo-trainer
