"""Tmuxinator data fixtures for import_tmuxinator tests."""

from __future__ import annotations

from . import test1, test2, test3
