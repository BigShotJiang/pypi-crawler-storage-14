"""Example tmuxp plugin module for hooks on window creation."""
