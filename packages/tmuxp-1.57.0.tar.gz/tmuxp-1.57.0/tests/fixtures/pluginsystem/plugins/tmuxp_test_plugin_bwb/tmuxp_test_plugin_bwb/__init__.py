"""Example tmuxp plugin that runs before workspace builder inits."""
