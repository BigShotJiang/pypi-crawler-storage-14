"""Test data for tmuxp plugin system."""
