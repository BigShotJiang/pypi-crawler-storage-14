# Builder - `tmuxp.workspace.builder`

```{eval-rst}
.. automodule:: tmuxp.workspace.builder
   :members:
   :show-inheritance:
   :undoc-members:
```
