# Logging - `tmuxp.log`

```{eval-rst}
.. automodule:: tmuxp.log
   :members:
   :show-inheritance:
   :undoc-members:
```
