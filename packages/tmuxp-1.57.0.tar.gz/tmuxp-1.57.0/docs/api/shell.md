# Shell - `tmuxp.shell`

```{eval-rst}
.. automodule:: tmuxp.shell
   :members:
   :show-inheritance:
   :undoc-members:
```
