# tmuxp load - `tmuxp.cli.load`

```{eval-rst}
.. automodule:: tmuxp.cli.load
   :members:
   :show-inheritance:
   :undoc-members:
```
