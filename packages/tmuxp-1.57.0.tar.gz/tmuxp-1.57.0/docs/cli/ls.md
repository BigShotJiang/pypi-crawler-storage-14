(cli-ls)=

(ls-config)=

# tmuxp ls

List sessions.

```{eval-rst}
.. argparse::
    :module: tmuxp.cli
    :func: create_parser
    :prog: tmuxp
    :path: ls
```
