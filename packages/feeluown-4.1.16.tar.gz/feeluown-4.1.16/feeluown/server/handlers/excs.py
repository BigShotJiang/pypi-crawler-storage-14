from feeluown.excs import FuoException


class HandlerException(FuoException):
    pass
