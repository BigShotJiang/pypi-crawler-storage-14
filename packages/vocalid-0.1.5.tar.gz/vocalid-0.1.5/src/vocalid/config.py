EMBEDDING_MODEL = "speechbrain/spkrec-ecapa-voxceleb"
SAMPLE_RATE = 16000
THRESHOLD = 0.75