"""Main module."""

from .ksdk import ksdk

if __name__ == "__main__":  # pragma: no cover
    ksdk()
