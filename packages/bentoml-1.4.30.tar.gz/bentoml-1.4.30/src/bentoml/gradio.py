from _bentoml_sdk.gradio import mount_gradio_app

__all__ = ["mount_gradio_app"]
