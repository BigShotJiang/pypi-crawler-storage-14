"""
AUTO-SELECT FEATURE GUIDE
=========================
How to let EssentiaX automatically pick the best variables to visualize
"""

from essentiax import smart_viz
import pandas as pd

print("\n" + "="*70)
print("🤖 ESSENTIAX AUTO-SELECT FEATURE GUIDE")
print("="*70)

# Load your dataset
df = pd.read_csv('creditcard.csv')  # or any dataset

# ═══════════════════════════════════════════════════════════
# METHOD 1: BASIC AUTO-SELECT (No Target)
# ═══════════════════════════════════════════════════════════
print("\n[1] BASIC AUTO-SELECT - Let EssentiaX choose best features")
print("-"*70)
print("""
🤖 Just add: auto_select=True

Command:
    smart_viz(df, auto_select=True)

What EssentiaX does:
✓ Analyzes ALL columns automatically
✓ Scores each feature based on:
  - Variance (how informative)
  - Missing values (completeness)
  - Uniqueness (diversity)
  - Cardinality (for categorical)
✓ Selects top 8 most important features
✓ Visualizes only those features

Perfect for:
- Quick exploration of new datasets
- When you don't know which features are important
- Datasets with 50+ columns
""")

# ═══════════════════════════════════════════════════════════
# METHOD 2: AUTO-SELECT WITH TARGET
# ═══════════════════════════════════════════════════════════
print("\n[2] AUTO-SELECT WITH TARGET - Find features related to target")
print("-"*70)
print("""
🎯 Add both: auto_select=True + target_column='ColumnName'

Command:
    smart_viz(df, target_column='Class', auto_select=True)

What EssentiaX does:
✓ Prioritizes features CORRELATED with target
✓ Selects features that best predict/explain target
✓ Automatically visualizes relationships with target

Selection criteria (with target):
1. High correlation with target (most important!)
2. High variance
3. Low missing values
4. Good uniqueness

Perfect for:
- Machine Learning feature selection
- Understanding what drives your target variable
- Fraud detection, price prediction, classification tasks
""")

# ═══════════════════════════════════════════════════════════
# METHOD 3: CONTROL NUMBER OF FEATURES
# ═══════════════════════════════════════════════════════════
print("\n[3] CONTROL SELECTION - Choose how many features to auto-select")
print("-"*70)
print("""
🎚️ Add: max_auto_features=N

Command:
    # Select top 5 features
    smart_viz(df, auto_select=True, max_auto_features=5)
    
    # Select top 10 features
    smart_viz(df, target_column='Price', auto_select=True, max_auto_features=10)

Recommended values:
- max_auto_features=5   → Quick focused analysis
- max_auto_features=8   → Default (balanced)
- max_auto_features=10  → Comprehensive view
- max_auto_features=15  → Deep dive (slower)

Perfect for:
- Controlling visualization complexity
- Reports with specific space constraints
- Time-sensitive analysis
""")

# ═══════════════════════════════════════════════════════════
# REAL-WORLD EXAMPLES
# ═══════════════════════════════════════════════════════════
print("\n[4] REAL-WORLD EXAMPLES")
print("-"*70)

print("""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXAMPLE 1: Credit Card Fraud Detection
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

df = pd.read_csv('creditcard.csv')  # 31 columns (V1-V28, Time, Amount, Class)

# ❌ OLD WAY: Manually select columns (tedious!)
smart_viz(df, specific_columns=['V1', 'V2', 'V3', 'V4', 'Amount'])

# ✅ NEW WAY: Let EssentiaX choose!
smart_viz(df, target_column='Class', auto_select=True)

Result:
🤖 EssentiaX automatically finds:
   - Top 8 features most correlated with fraud
   - Features like V14, V12, V10 (high fraud correlation)
   - Visualizes relationships automatically

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXAMPLE 2: House Price Prediction
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

df = pd.read_csv('house_prices.csv')  # 80+ columns

# Auto-select top 10 price predictors
smart_viz(df, target_column='SalePrice', auto_select=True, max_auto_features=10)

Result:
🤖 Automatically identifies:
   - GrLivArea (living area size)
   - YearBuilt
   - TotalBsmtSF
   - OverallQual
   - And 6 more key price drivers

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXAMPLE 3: Customer Churn Analysis
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

df = pd.read_csv('telecom_churn.csv')  # 20+ columns

# Find top 5 churn indicators
smart_viz(df, target_column='Churn', auto_select=True, max_auto_features=5)

Result:
🤖 Discovers:
   - tenure (contract length)
   - MonthlyCharges
   - Contract type
   - InternetService
   - TotalCharges

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXAMPLE 4: Employee Attrition
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

df = pd.read_csv('hr_data.csv')

# Auto-select attrition factors
smart_viz(df, target_column='Attrition', auto_select=True)

Result:
🤖 Identifies:
   - OverTime
   - MonthlyIncome
   - YearsAtCompany
   - JobSatisfaction
   - And more key attrition drivers
""")

# ═══════════════════════════════════════════════════════════
# COMPARISON TABLE
# ═══════════════════════════════════════════════════════════
print("\n[5] COMPARISON: Manual vs Auto-Select")
print("-"*70)
print("""
┌─────────────────────────┬──────────────────────┬──────────────────────┐
│ Scenario                │ Manual Selection     │ Auto-Select          │
├─────────────────────────┼──────────────────────┼──────────────────────┤
│ Time to setup           │ 5-10 minutes         │ 5 seconds            │
│ Domain knowledge needed │ High (must know      │ None (algorithm      │
│                         │ important features)  │ finds them)          │
│ Dataset with 100+ cols  │ Tedious, error-prone │ Effortless           │
│ Finding hidden patterns │ Might miss some      │ Catches all          │
│ Reproducibility         │ Depends on analyst   │ Consistent           │
└─────────────────────────┴──────────────────────┴──────────────────────┘
""")

# ═══════════════════════════════════════════════════════════
# WHAT ESSENTIAX LOOKS FOR
# ═══════════════════════════════════════════════════════════
print("\n[6] HOW AUTO-SELECT WORKS (Under the Hood)")
print("-"*70)
print("""
🤖 EssentiaX scoring system:

For NUMERIC columns:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Correlation with target (if provided)
   Score: 0-100 points
   Example: Feature highly correlated with fraud → 95 points

2. Variance (informativeness)
   Score: 0-50 points
   Example: Feature with high variance → 45 points

3. Completeness (low missing values)
   Score: 0-30 points
   Example: No missing values → 30 points

4. Uniqueness
   Score: 0-20 points
   Example: Many unique values → 20 points

For CATEGORICAL columns:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Association with target
   Score: 0-40 points

2. Cardinality (2-20 categories is ideal)
   Score: 10-50 points

3. Completeness
   Score: 0-30 points

4. Balance (not dominated by one category)
   Score: 0-20 points

🏆 Top-scored features are automatically selected!
""")

# ═══════════════════════════════════════════════════════════
# QUICK REFERENCE
# ═══════════════════════════════════════════════════════════
print("\n[7] QUICK REFERENCE - Copy & Paste")
print("-"*70)
print("""
# Basic auto-select (top 8 features)
smart_viz(df, auto_select=True)

# Auto-select with target (finds features related to target)
smart_viz(df, target_column='YourTarget', auto_select=True)

# Select top 5 features
smart_viz(df, auto_select=True, max_auto_features=5)

# Select top 10 features with target
smart_viz(df, target_column='Price', auto_select=True, max_auto_features=10)

# Auto-select + only specific plots
smart_viz(df, target_column='Class', auto_select=True, 
          plot_types=['scatter', 'boxplot', 'distribution'])

# Auto-select + sampling for large datasets
smart_viz(df, target_column='Churn', auto_select=True, 
          max_auto_features=6, sample_size=5000)
""")

print("\n" + "="*70)
print("✅ Ready to use! Just add auto_select=True to any smart_viz() call")
print("="*70 + "\n")

# ═══════════════════════════════════════════════════════════
# PRACTICAL TEST
# ═══════════════════════════════════════════════════════════
print("\n🧪 PRACTICAL TEST:")
print("-"*70)

choice = input("Test auto-select with your creditcard.csv? (y/n): ").strip().lower()

if choice == 'y':
    print("\n🚀 Running auto-select visualization...\n")
    
    # Test 1: Basic auto-select
    print("Test 1: Basic auto-select (no target)")
    smart_viz(df, auto_select=True, max_auto_features=5, show_plots=False)
    
    # Test 2: With target
    print("\nTest 2: Auto-select with target='Class'")
    smart_viz(df, target_column='Class', auto_select=True, 
              max_auto_features=5, show_plots=False)
    
    print("\n✅ Tests completed! Check the console output to see which features were selected.")
else:
    print("\n💡 When ready, just run:")
    print("   smart_viz(df, target_column='Class', auto_select=True)")