# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 标题栏
# @Time   : 2024-09-19 16:43
# @Author : 毛鹏
from .mango_title_bar import MangoTitleBar

__all__ = [
    'MangoTitleBar'
]