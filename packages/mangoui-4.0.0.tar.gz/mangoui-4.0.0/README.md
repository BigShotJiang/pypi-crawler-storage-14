# MangoUI - PySide6 UI 组件库

## 介绍

MangoUI 是一个基于 PySide6 的现代化桌面应用程序 UI 组件库，提供了丰富的可视化控件和布局管理功能，用于快速构建美观、功能完善的桌面应用界面。

该库包含多种类型的组件，如输入组件、显示组件、容器组件、图表组件等，所有组件都经过精心设计，具有统一的视觉风格和良好的用户体验。

## 特性

- 🎨 **现代化设计**: 采用现代化的 UI 设计语言，支持圆角、阴影等视觉效果
- 🎯 **组件丰富**: 提供输入、显示、容器、图表等多种类型的组件
- 🎨 **主题支持**: 支持自定义主题，可轻松切换不同的视觉风格
- 📦 **易于使用**: 简洁的 API 设计，易于集成到现有项目中
- ⚡ **性能优化**: 组件经过优化，确保良好的运行性能

## 安装教程

```bash
pip install mangoui
```

或者从源码安装：

```bash
git clone https://gitee.com/mao-peng/MangoUi.git
cd MangoUi
pip install -r requirements.txt
python setup.py install
```

## 使用说明

### 基本使用

```python
from PySide6.QtWidgets import QApplication
from mangoui.widgets.input import MangoPushButton

app = QApplication([])
button = MangoPushButton("点击我")
button.show()
app.exec()
```

### 运行示例

项目包含完整的测试页面，可以通过运行以下命令查看所有组件的效果：

```bash
cd tests
python demo.py
```

或者运行主测试程序：

```bash
cd tests/pages
python main.py
```

## 组件类型

- **输入组件**: 按钮、文本框、下拉框、滑块、开关等
- **显示组件**: 标签、进度条、表格、列表等
- **容器组件**: 卡片、分组框、堆叠窗口等
- **图表组件**: 折线图、饼图等
- **布局组件**: 各种布局管理器
- **菜单组件**: 菜单栏、工具栏等
- **窗口组件**: 主窗口、对话框等

## 依赖

- PySide6 >= 6.7.3
- pydantic >= 2.9.2
- matplotlib >= 3.9.2
- numpy >= 2.2.0
- pyqtgraph >= 0.13.7

## 项目结构

```
mangoui/
├── widgets/           # 核心UI组件
│   ├── input/         # 输入组件
│   ├── display/       # 显示组件
│   ├── container/     # 容器组件
│   ├── charts/        # 图表组件
│   ├── layout/        # 布局组件
│   ├── menu/          # 菜单组件
│   ├── window/        # 窗口组件
│   └── title_bar/     # 标题栏组件
├── styles/            # 样式和主题
├── settings/          # 配置和主题设置
├── models/            # 数据模型
├── components/        # 公共组件
└── enums/             # 枚举类型
```

## 开发

要为项目贡献代码，请遵循以下步骤：

1. Fork 项目
2. 创建功能分支
3. 提交更改
4. 发起 Pull Request

## 许可证

MIT License

## 作者

毛鹏 (729164035@qq.com)

## 项目地址

[Gitee](https://gitee.com/mao-peng/MangoUi)