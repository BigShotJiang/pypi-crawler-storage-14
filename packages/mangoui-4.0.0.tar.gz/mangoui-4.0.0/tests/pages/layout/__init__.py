# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2024-11-02 21:24
# @Author : 毛鹏

from .layout import LayoutPage
from .layout1 import Layout1Page
from .layout2 import Layout2Page