# -*- coding: utf-8 -*-
# @Project: 芒果测试平台
# @Description: 
# @Time   : 2024-08-20 19:00
# @Author : 毛鹏

# 导入所有页面模块，使它们可以通过 tests.pages 访问
from . import pages