def main():
    print("Hello from mcp-server-demo!")


if __name__ == "__main__":
    main()
