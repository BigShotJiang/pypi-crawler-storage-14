"""Scripts subpackage for btx_fix_mcp."""
