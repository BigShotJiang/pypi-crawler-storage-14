from setuptools import setup
setup(
    name='chec_code_da',
    version='1.3',
    packages = ['chec_code', 'code_get'],
    install_requires=[],
    python_requires=">=3.3",
    author="David_Yudin",
    author_email="dyudin1204@gmail.com"
)