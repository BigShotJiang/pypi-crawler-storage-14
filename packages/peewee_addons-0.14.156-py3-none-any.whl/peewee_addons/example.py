####
##
#
#


import os

from pprint import pprint

from peewee_addons.databases import connect
from peewee_addons.fields import AutoField
from peewee_addons.fields import CharField
from peewee_addons.models.base_model import BaseModel

# database = connect(
#    "sqlite:///:memory:",
#    pragmas=dict(foreign_keys=0, ignore_check_constraints=0),
# )


import peewee

# database = peewee.SqliteDatabase("./data.db/example.sqlite", pragmas=SQLITE_PRAGMAS)
# database = peewee.SqliteDatabase(
#    "./data.db/example.sqlite",
#    pragmas=dict(foreign_keys=0, ignore_check_constraints=1),
# )
# database.connect(reuse_if_open=True)

database = connect("sqlite:///:memory:")

# print("PRINT >>", database, type(database), database.__class__, "=++++\n")


class My_Model(BaseModel):
    id = AutoField()
    name = CharField(default="")

    class Meta:
        database = database


class A_Model(My_Model):
    # id = AutoField()
    # name = CharField()
    new_field = CharField()
    pass


class B_Model(A_Model):
    id = AutoField()
    name = CharField()
    # descr = CharField()


# print(
#    "EXAMPLE",
#    B_Model,
#    My_Model._meta.database.__class__,
#    B_Model._meta.database.__class__,
#    "=++++\n",
# )
# B_Model.create_table(safe=True)


def start():
    pass


def example_about():
    from peewee_addons import ABOUT

    print(ABOUT.summary())
    print(ABOUT.vendor(), "version:", ABOUT.version(), "at", ABOUT.__datetime__)
    pass


def example_fields():
    from peewee_addons import fields, FIELDS

    print("Additional field definitions:" + os.linesep)
    for x in FIELDS[1:]:
        print(x)
    pass


def example_databases():
    from peewee_addons.databases import DEFAULT_URL, connect

    print("Databases default url %s" % DEFAULT_URL)
    connection = connect(DEFAULT_URL)
    print("DB connection %s" % connection)


def example_basemodel():
    from peewee_addons.models.base_model import BaseModel
    from peewee_addons.fields import AutoField, CharField
    from peewee_addons.databases import DEFAULT_URL, connect

    print("BaseModel syntax OK")

    db = connect(DEFAULT_URL)

    class My_Model(BaseModel):
        id = AutoField()
        name = CharField()

        class Meta:
            database = db

    db.create_tables([My_Model])
    model = My_Model.get_or_create(id=1, name="example")[0]
    print(model.to_dict())


def example_migration():
    from peewee_addons.models.base_model import BaseModel
    from peewee_addons.fields import AutoField, CharField
    from peewee_addons.databases import DEFAULT_URL, connect

    print("Migration begin")

    db = connect(DEFAULT_URL)

    class My_Model(BaseModel):
        id = AutoField()
        name = CharField()

        class Meta:
            database = db

    # db.create_tables([My_Model])
    # model = My_Model.get_or_create(id=1, name="example")[0]
    # print(model.to_dict())


if __name__ == "__main__":
    print()
    example_about()
    print()
    example_fields()
    print()
    example_databases()
    print()
    example_basemodel()
    exit()
    print()
    example_migration()
