# Peewee miscellaneous addons

В связи с последними событиями в мире установки пакетов (PIP 517, 518, 660), "*старые*" пакеты,
устанавливаемые ранее через `setup.py`, теперь вызывают предупреждения, а некоторые и ошибки установки.
В этом репозитории в один пакет собраны разные полезные типы полей для [Peewee](https://docs.peewee-orm.com/) из репозиториев, которые давно не обновлялись.

Для дополнительной информации смотрите репозитории исходников.

Ранее в пакет входил модуль миграций, который в процессе разработки выделен в отдельный скрипт [ссылка]()

### установка
`pip install -U git+https://github.com/ablaternae/py-peewee-addons`

#### из клонированного репозитория
```
git clone --depth=1 https://github.com/ablaternae/py-peewee-addons peewee-addons
pip install -U peewee-addons
```

В зависимостях присутствует `ujson` для скоростной сериализации и `python-dotenv-typecast` (не помню для чего).

Добавьте самостоятельно пакеты
* `apsw` для асинхронного драйвера SQLite
* `bcrypt` для некоторых видов шифрования для полей типа `PasswordField`

### API

#### иерархия модулей
<!-- <details open> -->
<details><summary>package struct</summary>
<pre>
peewee_addons \
  .databases
  .fields (see below)
    .extra (synonim .extra_fields)
    EXTRAFIELDS
    FIELDS
    POSTFIELDS
  .mixins \
    .autosave
    .created
    .file
    .updated
    Autosave_Mixin
    Created_Timestamp_Mixin
    Updated_Timestamp_Mixin
  .models
    BaseModel
  .logger
  .utils
</pre>
</details>

#### список дополнительных полей без описаний
NB: здесь не все поля, а которые доступны через `peewee_addons.fields`
<details><summary>fields list</summary>
<pre>
AutoField
BigAutoField
BigBitField
BigIntegerField
BigUnsignedIntegerField
BinaryUUIDField
BitField
BlobField
BooleanField
CharField
ColorHexadecimalField
CurrencyISOCodeField
DateField
DateTimeField
DatetimeField
DecimalField
DoubleField
EMailField
EmailField
EnumField
FixedCharField
FloatField
IANCodeField
IBANISOCodeField
IPAddressField
IPField
IPNetworkField
IPv4AddressField
IPv6AddressField
IntegerField
JSONField
LanguageISOCodeField
MoneyField
PasswordField
PathField
PhoneNumberField
PhonenumberField
PickleField
RealField
RestrictedCharField
SWIFTISOCodeField
SemVerField
SimplePasswordField
SmallIntegerField
SmallUnsignedIntegerField
TextField
TimeDeltaField
TimeField
TimedeltaField
TimestampField
UUIDField
UnsignedBigIntegerField
UnsignedIntegerField
UnsignedSmallIntegerField
UserNameField
UsernameField
XMLField
</pre>
</details>


### источники
включены в пакет:

* https://github.com/mouday/peewee-ext библиотека китайского(?) происхождения, из неё взята общая структура;
 / last update Mar 19 2021, unlicensed
* https://github.com/kucharzyk-sebastian/peewee-enum-field лучшая реализация EnumField(CharField) с ошибкой в проекте
 / MIT license
* https://github.com/homeinfogmbh/peeweeplus дополнительные поля, например, RestrictedField, RegexpField, PhonenumberField / last update Aug 7 2023, GPL-3.0 license
* https://github.com/juancarlospaco/peewee-extra-fields специфичные поля вроде
 IPNetworkField, CurrencyISOCodeField, IBANISOCodeField / last update Dec 15 2021, GPL-3.0 license
* https://github.com/enpaul/peewee-plus рабочая библиотека, есть EnumField(CharField), в код не включена, здесь для примера
* ошибки, советы, полезные ссылки шлите известно куда
* структура файлов и API приведены в соседнем файле README.en.md



### история версий
основная ветка 0.7-beta

#### 0.7.25
Добавлен код из `peewee-extra-fields` --> `.fields.extra` (`.fields.extra_fields`)
#### 0.7
Добавлен и протестирован `peewee-extra-fields`

#### 2.0-aplha
next databases migration manager выделен из peewee-addons в отдельный скрипт, продолжена ветка 0.6

#### 0.6
Добавлены шаблоны подключений к базам (SQLite), требуется проверка и доработка
#### 0.5
Добавлены базовые модели и миксины
#### 0.4
Все (почти все) поля сведены в модуль `.fields`
