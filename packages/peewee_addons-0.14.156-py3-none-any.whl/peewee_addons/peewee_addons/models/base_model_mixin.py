# =============================================================================
#
# =============================================================================


# from enum import Enum
from time import time
from typing import Any, Dict, List, Union

from playhouse.hybrid import hybrid_method, hybrid_property
from playhouse.shortcuts import dict_to_model, model_to_dict, update_model_from_dict

from ..logger import logger

# from peewee_enum_field import EnumField   #   этот лучше. но ошибка версии питоона
# from peewee_plus import EnumField
from .base_model import (
    AutoField,
    BigIntegerField,
    CharField,
    IntegerField,
    Model,
    PrimaryKeyField,
    TextField,
    TimestampField,
)


class Created_Timestamp_Mixin(Model):
    """Model `created` fields, in table `created_timestamp` integer"""

    created = IntegerField(column_name="created_timestamp", index=True, null=True, default=time)

    pass  # Created_Timestamp_Mixin


class Updated_Timestamp_Mixin(Model):
    """Model `updated` fields, in table `updated_timestamp` integer"""

    updated = IntegerField(column_name="updated_timestamp", index=True, null=True, default=time)

    def __init__(self, *args, **kwargs):
        """в целом, верно. если принудительно не сохранять, то изменения не войдут"""
        super().__init__(self, *args, **kwargs)
        self.updated = int(time())

    @property
    def last_visit(self):
        return self.updated

    @last_visit.setter
    def last_visit(self, value=0):
        if 0 == value:
            value = time()

        # self.updated = value
        logger.debug(
            "Updated_Timestamp_Mixin @last_visit.setter %s id=%s"
            % (self.__class__.__name__, self.__class__.id)
        )
        q = (self.update(**dict(updated=value)).where(self.__class__.id == self.id)).execute()

        logger.debug(q)

    pass  # Updated_Timestamp_Mixin


class Autosave_Mixin(Model):
    """Model destructor"""

    def __del__(self):
        logger.debug(f"{self.__class__.__name__} destructor in {__class__.__name__}")
        if self.is_dirty():
            logger.info(f"{self.__class__.__name__}.save()")
            self.save()

        try:
            super().__del__()
        except Exception as exc:
            # print("нет деструктора модели, но лень обрабатывать", exc)
            pass

    pass  # Autosave_Mixin
