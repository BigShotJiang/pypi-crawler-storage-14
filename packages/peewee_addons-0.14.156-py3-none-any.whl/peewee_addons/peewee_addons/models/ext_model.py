# =============================================================================
#
# https://docs.peewee-orm.com/en/latest/peewee/querying.html
#
# =============================================================================


from typing import Any, Dict, Union

from peewee_addons.mixins import Created_Timestamp_Mixin, Iterator_Mixin, Updated_Timestamp_Mixin
from playhouse.shortcuts import dict_to_model, model_to_dict, update_model_from_dict

from .base_model import BaseModel


class ExtendModel(BaseModel):
    # class ExtendModel(BaseModel):
    """includes Mixins and fields:

    id: int = peewee.IntegerField(null=False, primary_key=True)

    """

    # id = AutoField() # inherit

    """ CRUD operations commonly performed on a relational database:
            Model.create(), for executing INSERT queries.
            Model.save() and Model.update(), for executing UPDATE queries.
            Model.delete_instance() and Model.delete(), for executing DELETE queries.
            Model.select(), for executing SELECT queries.
    """

    def _apply_where(self, query, filters, conjunction=None):
        conjunction = conjunction or operator.and_
        if filters:
            expressions = [
                (self.model_class._meta.fields[column] == value) for column, value in filters.items()
            ]
            query = query.where(reduce(conjunction, expressions))
        return query

    def _query(self, **query):
        return self._apply_where(self.model_class.select(), query)

    def find(self, **query):
        return self._query(**query).dicts()

    def find_one(self, **query):
        try:
            return self.find(**query).get()
        except self.model_class.DoesNotExist:
            return None

    def all(self):
        return self.find()

    @classmethod
    def filtered(cls, *args, **kwargs) -> dict:
        """deprecated"""
        return

    @classmethod
    def as_dict(cls, _data: Union[BaseModel, Dict, object, Any]) -> dict:
        """data's view filtered by model pattern
        представить данные как словарь без модели
        отфильтровать данные по полям модели и вернуть словарь
        """
        import ast
        from types import SimpleNamespace

        _dict = vars(SimpleNamespace(**ast.literal_eval(str(_data))))  # длинный способ
        _model = dict_to_model(cls, _dict, ignore_unknown=True)  # фильтруем поля
        return model_to_dict(_model)

    def to_dict(self, **kwargs) -> dict:
        """synonym  model_to_dict(), but for Model instance method
        https://docs.peewee-orm.com/en/latest/peewee/playhouse.html#model_to_dict

        default params:
            recurse=False
            backrefs=False
            only=None
            exclude=None
            extra_attrs=None
            fields_from_query=None
            max_depth=1
            manytomany=False
        """
        return model_to_dict(
            self,
            **{
                **dict(
                    recurse=False,
                    backrefs=False,
                    only=None,
                    exclude=None,
                    extra_attrs=None,
                    fields_from_query=None,
                    max_depth=1,
                    manytomany=False,
                ),
                **kwargs,
            },
        )

    def dump(self, *args, **kwargs) -> dict:
        """synonym for model_to_dict()"""
        return model_to_dict(self, *args, **kwargs)

    @classmethod
    def load(cls, data: dict, ignore_unknown: bool = True) -> "__class__":
        return dict_to_model(cls, data, ignore_unknown)

    @classmethod
    def load_from_dict(cls, data: dict, ignore_unknown: bool = True) -> "__class__":
        return dict_to_model(cls, data, ignore_unknown)

    def update_from_dict(self, data: dict, ignore_unknown: bool = True) -> "self":
        return update_model_from_dict(self, data, ignore_unknown)
