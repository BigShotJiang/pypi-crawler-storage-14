####
##
#
#


from datetime import datetime
from time import time

from peewee import SQL, DateTimeField, IntegerField, Model, TimestampField

# установка времени по умолчанию
# timestamp = DateTimeField(constraints=[SQL('DEFAULT CURRENT_TIMESTAMP')])

__all__ = ("Created_Datetime_Mixin", "Created_Timestamp_Mixin")


class Created_Timestamp_Mixin(Model):
    """Model `created` fields integer"""

    # created = IntegerField(
    #     column_name="created_timestamp", index=True, null=False, default=time
    # )
    # не надо так делать

    created = TimestampField(
        column_name="created_timestamp",
        index=True,
        null=False,
        default=time,
        constraints=[SQL("DEFAULT CURRENT_TIMESTAMP")],
    )


####


class Created_Datetime_Mixin(Model):
    """Model `created` fields Datetime type"""

    created = DateTimeField(
        column_name="created_datetime",
        index=True,
        null=False,
        default=datetime.now,
        constraints=[SQL("DEFAULT NOW()")],
    )


####
