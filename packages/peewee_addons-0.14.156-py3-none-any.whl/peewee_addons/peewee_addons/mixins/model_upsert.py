####
##
#
#

from peewee import Model

from ..logger import logger


class Upsert_Mixin(Model):
    """Model insert or update"""

    @classmethod
    # def update(cls, __data=None, **update):
    def insert_or_update(cls, __data=None, **kwargs):
        """wrapper for insert() ON CONFLICT update()"""

        from peewee import IntegrityError

        try:
            return cls.insert(__data, **kwargs)
        except (IntegrityError,) as exc:
            # except (IntegrityError, ConstraintError) as exc:
            # UNIQUE constraint failed: ... <class 'peewee.IntegrityError'>
            # UNIQUE constraint failed: ... <class 'apsw.ConstraintError'>
            # untraceable exception "apsw.ConstraintError: UNIQUE constraint failed"

            print()
            print(
                "UNIQUE constraint failed ========",
                "UNIQUE constraint failed" in str(exc),
            )

            # if "UNIQUE constraint failed" in str(exc):
            print(123456789, "args", args, "kwargs", kwargs)

            # print("UPDATE",self.model_class.update(**kwargs))
            print()

            return cls.update(__data=None, **kwargs)
            # else:
            # ...
        except Exception as exc:
            print("Exception in 'insert_or_update':", str(exc))

        return

    @classmethod
    def upsert(cls, __data=None, **kwargs):
        """insert_or_update() synonim"""
        return cls.insert_or_update(__data, **kwargs)
