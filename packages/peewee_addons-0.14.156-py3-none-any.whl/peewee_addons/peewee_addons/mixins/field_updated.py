####
##
#
#


from datetime import datetime
from time import time

from peewee import SQL, DateTimeField, IntegerField, Model, TimestampField

from ..logger import logger

__all__ = ("Updated_Datetime_Mixin", "Updated_Timestamp_Mixin")


class Updated_Timestamp_Mixin(Model):
    """Model `updated` fields, in table `updated_timestamp` integer"""

    updated = TimestampField(
        column_name="updated_timestamp",
        index=True,
        null=True,
        default=time,
        constraints=[SQL("DEFAULT CURRENT_TIMESTAMP")],
    )

    @classmethod
    def _normalize_data(cls, data, kwargs):
        # метод вызывается почти всегда при вставке и апдейте
        # print(cls.__name__, data, kwargs)
        if data is None and isinstance(kwargs, dict) and "updated" not in kwargs:
            kwargs["updated"] = int(time())
        elif isinstance(data, dict) and "updated" not in data:
            data["updated"] = int(time())
        return super()._normalize_data(data, kwargs)

    @property
    def last_visit(self):
        return self.updated

    @last_visit.setter
    def last_visit(self, value=None):
        if not value:
            value = int(time())

        # self.updated = value
        logger.debug(
            "Updated_Timestamp_Mixin @last_visit.setter %s id=%s"
            % (self.__class__.__name__, self.__class__.id)
        )
        q = (self.update(**dict(updated=value)).where(self.__class__.id == self.id)).execute()

        logger.debug(q)


####


class Updated_Datetime_Mixin(Updated_Timestamp_Mixin):
    """Model `created` fields Datetime type"""

    updated = DateTimeField(
        column_name="updated_datetime",
        index=True,
        null=True,
        default=datetime.now,
        constraints=[SQL("DEFAULT NOW()")],
    )

    @classmethod
    def _normalize_data(cls, data, kwargs):
        if data is None and isinstance(kwargs, dict) and "updated" not in kwargs:
            kwargs["updated"] = datetime.now()
        elif isinstance(data, dict) and "updated" not in data:
            data["updated"] = datetime.now()
        return super()._normalize_data(data, kwargs)


####
