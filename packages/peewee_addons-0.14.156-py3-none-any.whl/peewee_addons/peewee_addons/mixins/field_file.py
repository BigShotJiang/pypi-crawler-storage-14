####
## File <--> Blob mixin
#
# хорошая идея хранения файлов в базе вместе с описанием файла, но это что-то совершенно другое
# требуется доработка напильником
#
# @DEPRECATED

from __future__ import annotations

from hashlib import sha256
from mimetypes import guess_extension
from typing import Iterator

from magic import detect_from_content
from peewee import BlobField, CharField, Field, FixedCharField, IntegerField
from peewee import Model as pwModel

from ..logger import logger


class File_Blob_Mixin(pwModel):
    """Mixin for binary data."""

    bytes = BlobField()
    size = IntegerField()
    sha256sum = FixedCharField(64)
    mimetype = CharField()
    suffix = CharField()

    @classmethod
    def from_bytes(cls, data: bytes) -> File_Mixin:
        """Creates a file from the given bytes."""
        mimetype = detect_from_content(data[:1024])
        return cls(
            bytes=data,
            size=len(data),
            sha256sum=sha256(data).hexdigest(),
            mimetype=mimetype,
            suffix=guess_extension(mimetype),
        )

    @classmethod
    def shallow(cls) -> Iterator[Field]:
        """Yields all fields except BlobFields."""
        return filter(lambda field: not isinstance(field, BlobField), cls._meta.fields.values())


__all__ = ("File_Mixin",)
