####
##
#
# based on playhouse.DataSet
#

import csv
import datetime
import json
import operator
import sys
import time
import uuid
from decimal import Decimal
from typing import Any

import peewee
from apsw import ConstraintError

# from peewee.EXCEPTIONS import ConstraintError, IntegrityError
from peewee import (
    AutoField,
    BlobField,
    BooleanField,
    CharField,
    Database,
    DateField,
    DateTimeField,
    FloatField,
    ForeignKeyField,
    IntegerField,
    IntegrityError,
    Model,
    PrimaryKeyField,
    TextField,
    TimeField,
    UUIDField,
)
from var_dump import var_dump

from playhouse.migrate import SchemaMigrator, migrate
from playhouse.reflection import Introspector
from playhouse.shortcuts import dict_to_model, model_to_dict, update_model_from_dict

from ..logger import logger


class Dataset_Mixin(Model):
    """Provides flexible number of Model fields.
    adds colums only, does not delete or rename one"""

    class Meta:
        include_views = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._add_new_columns()

    #

    def init_subclass__(cls, /, *args, **kwargs):
        super().__init_subclass__(*args, **kwargs)
        print("__init_subclass__()", cls, args, kwargs, cls.__name__)

        print(
            cls._meta.fields,
            cls._meta.columns,
            cls.__data__,
            cls._meta.table_name,
            cls._meta.database,
            cls._meta.__dict__,
        )

        _model = cls(*args, **kwargs)
        print(_model._meta.fields, _model._meta.columns, _model.__data__)

    #

    def __delitem__(self, item):
        ...
        # сделать приведение поля к дефолтному значению
        # del self.model_class[item]

    # def __getattr__(self, name: str) -> Any:
    # перепроверить
    # return self.__getitem__(name)  # None returns by default

    @classmethod
    def _normalize_data(cls, data, kwargs):
        """этот метод вызывается при сохранении модели перед каждым инсерт\апдейт"""
        print("_normalize_data", data, kwargs)
        return super()._normalize_data(data, kwargs)

    def _guess_field_type(self, value):
        """угадываем тип поля по данным"""
        if issubclass(value, peewee.Field):
            # it doesn't need guessing
            return value.__class__
        elif isinstance(value, str):
            return TextField
        elif isinstance(value, int):
            return IntegerField
        elif isinstance(value, float):
            return FloatField
        elif isinstance(value, Decimal):
            return DecimalField
        elif isinstance(value, (datetime.datetime)):
            return DateTimeField
        elif isinstance(value, (datetime.date)):
            return DateField
        elif isinstance(value, (datetime.time, time.time)):
            return TimeField
        elif isinstance(value, bool):
            return BooleanField
        elif isinstance(value, (bytes, bytearray)):
            return BlobField
        elif isinstance(value, uuid.UUID):
            return UUIDField
        # elif isinstance(value, (list, dict, set, tuple)):
        #     return JSONField
        # The JSONField type is database-sensitive, there are different fields for SQLite\Pgsql\...
        return TextField

    def _migrate_new_columns(self, data, nullable=False):
        # мигрирует (добавляет) поля из пришедших данных
        new_keys = set(data) - set(self._meta.fields) - set(self._meta.columns)
        print("_migrate_new_columns", new_keys)
        if new_keys:
            operations = []
            for key in new_keys:
                field_class = self._guess_field_type(data[key])
                field = field_class(null=nullable)
                operations.append(self._migrator.add_column(self.name, key, field))
                field.bind(self, key)

            print("operations", operations, *operations)

            migrate(*operations)

            # self.update_cache(self.name)
            # это в датасете обновление данных о таблице

    def _add_new_columns(self, model_class=None, nullable=False):
        """_добавить_ в таблицу поля из текущей модели"""

        print("_add_new_columns")
        print("table name", self._meta.table_name)

        # Introspect the database and generate models.
        _introspector = Introspector.from_database(self._meta.database)
        _migrator = SchemaMigrator.from_database(self._meta.database)
        # здесь загружаются "модели" из базы
        _db_models = _introspector.generate_models(
            skip_invalid=True,
            table_names=[self._meta.table_name],
            literal_column_names=True,
            include_views=(self._meta.include_views or False),
        )
        if len(_db_models) == 0:
            return None

        print(".generate_models self._models ==", _db_models)
        _db_model = _db_models.get(self._meta.table_name, set())
        if len(_db_model) == 0:
            return None

        # print("TABLE model ==",self._model.__dict__)
        # print("TABLE model ==",self.__dict__)

        print("MODEL __data ==", self.__data__)
        print("MODEL fields ==", self._meta.fields)
        print("MODEL columns ==", self._meta.columns)

        new_keys = set(self.__data__) - set(_db_model._meta.fields) - set(_db_model._meta.columns)
        print("_add_new_columns", new_keys)
        if new_keys:
            operations = []
            for key in new_keys:
                # field_class = self._guess_field_type(self._meta.fields[key])
                # field = field_class(null=nullable)
                operations.append(_migrator.add_column(self._meta.table_name, key, self._meta.fields[key]))
                # field.bind(self, key)

            print("operations", operations, *operations)

            migrate(*operations)

        # print("fields", set(self.model_class._meta.fields))
        # print("columns", set(self.model_class._meta.columns))

        #         new_keys = set(data) - set(self.model_class._meta.fields) - set(self.model_class._meta.columns)
        #
        #         print("NEW new_keys", new_keys, bool(new_keys))

        # _add_new_columns

    @property
    def columns(self):
        # надо ли?
        return [f.name for f in self._meta.sorted_fields]
