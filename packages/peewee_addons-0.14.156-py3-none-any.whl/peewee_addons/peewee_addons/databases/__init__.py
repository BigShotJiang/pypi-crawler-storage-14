# =============================================================================
#
# очень интересно, для чего все это было?
#
# =============================================================================

import os
from pathlib import Path

from peewee import Database

from playhouse import db_url
from playhouse.db_url import connect as peewee_connect
from playhouse.db_url import register_database, schemes

from ..logger import logger

DATA_DIR = str(Path(os.getenv("DATA_DIR", "./data")).resolve())
DEFAULT_DRIVER = "sqlite"


def check_sqlite_dir(create_dir=True):
    logger.info("Check data dir")
    if not os.path.isdir(DATA_DIR):
        if create_dir:
            try:
                os.makedirs(DATA_DIR, 0o755)
                logger.info(f"Creating directory `{DATA_DIR}`... Ok")
            except Exception as exc:
                logger.error(f"Creating directory `{DATA_DIR}`... ERROR: " + str(exc))
        else:
            logger.info(f"Sqlite directory `{DATA_DIR}`... Ok")


from playhouse.db_url import connect

# не помню, зачем этот враппер
# def connect(db_url: str = None, **kwargs) -> Database:
#    if db_url:
#        return peewee_connect(db_url, **kwargs)
#    else:
#        scheme = kwargs.pop("scheme")
#        return schemes[scheme](**kwargs)


# DSN Data Source Name
# DEFAULT_URL = "memory://"
# db_url.schemes["memory"] = "sqlite:///:memory:"

DEFAULT_URL = "sqlite:///:memory:"
DEFAULT_DATABASE = DEFAULT_DB = connect(DEFAULT_URL)


# from .base_model import BaseModel, Database
__all__ = (
    "DEFAULT_DATABASE",
    "DEFAULT_DB",
    "DEFAULT_URL",
    "connect",
    "Database",
    # "BaseModel",
    # "Database",
    # "logger",
)
