####
##
#
#


from playhouse.apsw_ext import (
    SQL,
    AutoField,
    BigAutoField,
    BigIntegerField,
    BlobField,
    BooleanField,
    CharField,
    DateTimeField,
    DeferredForeignKey,
    Field,
    FixedCharField,
    FloatField,
    ForeignKeyField,
    IntegerField,
    Model,
    PrimaryKeyField,
    TextField,
    TimestampField,
    UUIDField,
)
from playhouse.fields import PickleField
from playhouse.sqlite_ext import JSONField

RealField = FloatField
DatetimeField = DateTimeField


SQLITE_PRAGMAS = dict(
    auto_vacuum="INCREMENTAL",  # 0 | NONE | 1 | FULL | 2 | INCREMENTAL
    cache_size=-(64),  # aprx 128kb = 128*1024  # 64MB = (64*1024)*1024
    # minus=in pages; approximately abs(N_pages*Size_page) bytes when Size_page = 1024
    foreign_keys=0,  #
    # foreign_keys=1,  # Enforce foreign-key constraints
    encoding="UTF8",  #
    # journal_mode="TRUNCATE",  # Use WAL-mode (you should always use this)
    journal_mode="WAL",  # Use WAL-mode (you should always use this)
    # journal_mode = DELETE | TRUNCATE | PERSIST | MEMORY | WAL | OFF
    secure_delete=1,
    ignore_check_constraints=0,
    temp_store="MEMORY",
)


KV_PRAGMAS = SQLITE_PRAGMAS.copy()
KV_PRAGMAS.update(
    dict(
        auto_vacuum="INCREMENTAL",  # 0 | NONE | 1 | FULL | 2 | INCREMENTAL
        cache_size=-(16),  # aprx 128kb = 128*1024  # 64MB = (64*1024)*1024
        foreign_keys=0,  # Enforce foreign-key constraints
        encoding="UTF8",  #
        journal_mode="PERSIST",  # Use WAL-mode (you should always use this)
        ignore_check_constraints=1,
        temp_store="MEMORY",
    )
)
