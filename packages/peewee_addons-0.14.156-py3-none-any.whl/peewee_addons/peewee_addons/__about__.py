# =============================================================================
#
# =============================================================================

__version__ = "0.14.156"

import os
import sys
import time
from uuid import uuid1, uuid4

if sys.version_info < (3, 10):
    from importlib_metadata import metadata
else:
    from importlib.metadata import metadata

# _name = __name__.split(".")[0]
# здесь хак: name должно быть имя пакета, а не модуля

# _name = os.path.basename(os.path.dirname(__file__))
# если повышать уровень модуля добавлением в sys.path

# print("__about__ GO")
# print(__package__)
# print(__name__)

meta = metadata(__package__).json

# __vendor__ = "peewee.addons"
__vendor__ = "tool." + __package__.lower().replace("_", ".")
__uuid__ = str(uuid4())
__url__ = meta.get("project_url", "")
__timestamp__ = os.stat(__file__).st_mtime
__summary__ = meta.get("summary", "")
__license__ = meta.get("license_expression", "")
__id__ = __uuid__
__dir__ = os.path.realpath(os.path.dirname(__file__))
__description__ = meta.get("description", "")
__datetime__ = time.strftime("%Y-%m-%d", time.localtime(os.stat(__file__).st_mtime))
__author_mail__ = meta.get("author_email", "")
__author__ = "d;)"

# print(tripcode(f"{__vendor__}_{__uuid__}"))
# print(f"{__vendor__}.{__uuid__}")


author = lambda: __author__
date = __datetime__
description = lambda: __description__
id = lambda: __id__
license = lambda: __license__
name = lambda: meta.get("name", "noname")
summary = lambda: __summary__
uuid = lambda: __uuid__
vendor = lambda: __vendor__
version = lambda: __version__


__all__ = (
    "__author__",
    "__datetime__",
    "__dir__",
    "__file__",
    "__id__",
    "__package__",
    "__summary__",
    "__timestamp__",
    "__uuid__",
    "__vendor__",
    "__version__",
    "author",
    "date",
    "description",
    "id",
    "license",
    "meta",
    "name",
    "summary",
    "uuid",
    "vendor",
    "version",
)
