"""Username field."""

from .restricted_char import RestrictedCharField

__all__ = ["UsernameField", "UserNameField", "USERNAME_REGEX"]


# USERNAME_REGEX = r"^[0-9A-Za-zÄäÖöÜüßéè '-]+$"
USERNAME_REGEX = r"^[\w\d_\-.()~]+$"


class UsernameField(RestrictedCharField):
    """Restricted field to store email addresses."""

    def __init__(self, *args, **kwargs):
        super().__init__(USERNAME_REGEX, *args, **kwargs)


UserNameField = UsernameField
