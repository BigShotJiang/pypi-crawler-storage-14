"""Specialized character-based fields."""

from re import fullmatch
from typing import Optional, Union

from peewee import CharField, FieldAccessor, Model

__all__ = ("RestrictedCharField",)


class RestrictedCharFieldAccessor(FieldAccessor):
    """Accessor class for HTML data."""

    def __set__(self, instance: Model, value: Optional[str]):
        if value is None:
            return super().__set__(instance, value)

        return super().__set__(instance, self.field.check(value))


class RestrictedCharField(CharField):
    """CharField with restricted character set."""

    def __init__(self, regex: str, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.regex = regex

    def check(self, text: str) -> str:
        """Checks the text against the allowed chars."""
        if fullmatch(self.regex, text):
            return text

        raise ValueError(f'Text "{text}" does not match regex: {self.regex}')

    accessor_class = RestrictedCharFieldAccessor
