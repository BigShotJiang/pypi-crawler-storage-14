"""Phone number field."""

from .restricted_char import RestrictedCharField

__all__ = ["PhoneNumberField", "PhonenumberField", "PHONE_REGEX"]


PHONE_REGEX = r"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$"


class PhoneNumberField(RestrictedCharField):
    """Restricted field to store email addresses."""

    def __init__(self, *args, **kwargs):
        super().__init__(PHONE_REGEX, *args, **kwargs)


PhonenumberField = PhoneNumberField
