"""Integer fields."""

from peewee import IntegerField, SmallIntegerField

__all__ = [
    "UnsignedSmallIntegerFieldd",
    "SmallUnsignedIntegerField",
    "UnsignedIntegerField",
    "UnsignedBigIntegerField",
    "BigUnsignedIntegerField",
]


class UnsignedSmallIntegerField(SmallIntegerField):
    """Small unsigned integer field."""

    field_type = "SMALLINT UNSIGNED"


SmallUnsignedIntegerField = UnsignedSmallIntegerField


class UnsignedIntegerField(IntegerField):
    """Unsigned integer field."""

    field_type = "INT UNSIGNED"


class UnsignedBigIntegerField(IntegerField):
    """Unsigned big integer field."""

    field_type = "BIGINT UNSIGNED"


BigUnsignedIntegerField = UnsignedBigIntegerField
