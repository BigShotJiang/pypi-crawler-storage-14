#

some fields from https://github.com/homeinfogmbh/peeweeplus GPL 3

EnumField(CharField) https://github.com/kucharzyk-sebastian/peewee-enum-field MIT license

not all fields from https://github.com/juancarlospaco/peewee-extra-fields GPL 3

