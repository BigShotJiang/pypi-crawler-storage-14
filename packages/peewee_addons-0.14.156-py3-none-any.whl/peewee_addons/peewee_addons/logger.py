####
## powered by peewee-ext/logger.py
#
#

import logging

logger = logging.getLogger("peewee")
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.DEBUG)
logger.propagate = False

__all__ = ("logger",)
