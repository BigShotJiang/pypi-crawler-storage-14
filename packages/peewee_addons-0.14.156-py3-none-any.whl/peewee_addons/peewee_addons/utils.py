# =============================================================================
#
# =============================================================================

from uuid import uuid4 as guid

from peewee import make_snake_case as pw_snake_case
from setuptools._normalization import safe_extra, safe_identifier, safe_name, safe_version


def make_snake_case(s: str) -> str:
    return safe_identifier(pw_snake_case(s))


def make_camel_case(s: str) -> str:
    import re

    return re.sub(r"\w+", lambda m: m.group(0).capitalize(), s)


def dbname_normalize(dbname: str) -> str:
    return make_snake_case(dbname)


def dbname_gener8(name: str):
    from os.path import join, realpath

    from settings import DATA_DIR, DB_EXT

    name = name.strip().lower()
    name = name.split(".")[-1 - int(name.endswith(".py"))]

    return realpath(join(DATA_DIR, safe_identifier(name)) + DB_EXT)


SQLITE_PRAGMAS = dict(
    auto_vacuum="INCREMENTAL",  # 0 | NONE | 1 | FULL | 2 | INCREMENTAL
    cache_size=-(64),  # aprx 128kb = 128*1024  # 64MB = (64*1024)*1024
    # minus=in pages; approximately abs(N_pages*Size_page) bytes when Size_page = 1024
    foreign_keys=0,  # Enforce foreign-key constraints
    # foreign_keys=1,  # Enforce foreign-key constraints
    encoding="UTF8",  #
    # journal_mode="TRUNCATE",  # Use WAL-mode (you should always use this)
    journal_mode="WAL",  # Use WAL-mode (you should always use this)
    # journal_mode = DELETE | TRUNCATE | PERSIST | MEMORY | WAL | OFF
    secure_delete=1,
    ignore_check_constraints=0,
    temp_store="MEMORY",
)
