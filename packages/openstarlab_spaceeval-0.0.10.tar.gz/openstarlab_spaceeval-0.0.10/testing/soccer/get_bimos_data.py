from spaceeval import Space_Model
import pdb

event_path = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/event_shot'
home_tracking_path = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/home_tracking'
away_tracking_path = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/away_tracking'
out_path = '/home/c_yeung/workspace6/python/openstarlab/spaceEval/testing/soccer'

model = Space_Model(space_model='soccer_BIMOS',
            event_data=event_path,
            tracking_home=home_tracking_path,
            tracking_away=away_tracking_path,
            testing_mode=True,
            out_path=out_path)

results = model.get_bimos()
# pdb.set_trace()


