from spaceeval import Space_Model

event_id = 0
events_data = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/event_shot/event_data_10502.csv'
tracking_home = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/home_tracking/home_tracking_10502.csv'
tracking_away = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/away_tracking/away_tracking_10502.csv'
ppcf= '/home/c_yeung/workspace6/python/openstarlab/spaceEval/testing/soccer/obso/10502_PPCF_dict.npy'
out_path = '/home/c_yeung/workspace6/python/openstarlab/spaceEval/testing/soccer/paper_fig'
model = Space_Model(space_model='soccer_OBSO')

model.vis_obso(event_id=event_id, 
               events_data=events_data, 
               tracking_home=tracking_home, 
               tracking_away=tracking_away, 
               PPCF=ppcf,
               with_vel=False,
               plot_heatmap=True,
               out_path=out_path
               )