from spaceeval import Space_Model
import numpy as np
import pandas as pd
import pdb  
import os

events_data = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/event_shot/event_data_10502.csv'
tracking_home = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/home_tracking/home_tracking_10502.csv'
tracking_away = '/home/c_yeung/workspace6/python/openstarlab/example/compare_space_eval/away_tracking/away_tracking_10502.csv'
bimos_pbcf= '/home/c_yeung/workspace6/python/openstarlab/spaceEval/testing/soccer/bimos/10502_PBCF_dict.npy'
out_path = '/home/c_yeung/workspace6/python/openstarlab/spaceEval/testing/soccer/paper_fig'
os.makedirs(out_path, exist_ok=True)

event_id = 0

model = Space_Model(space_model='soccer_BIMOS')

model.vis_bimos(event_id=event_id, 
            events_data=events_data, 
            tracking_home=tracking_home, 
            tracking_away=tracking_away, 
            PPCF=bimos_pbcf,
            out_path=out_path
            )