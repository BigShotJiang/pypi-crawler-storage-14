from bluer_ugv.README.ugvs.comparison.features.classes import Feature


class DYIFeature(Feature):
    nickname = "DYI"
    long_name = "سادگی ساخت "

    comparison_as_str = {}
