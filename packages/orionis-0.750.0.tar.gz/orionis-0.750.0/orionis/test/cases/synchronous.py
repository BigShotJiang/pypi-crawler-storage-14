import unittest
from orionis.test.output.dumper import TestDumper

class SyncTestCase(unittest.TestCase, TestDumper):
    """
    Base class for synchronous unit tests in the Orionis framework.
    """
    pass