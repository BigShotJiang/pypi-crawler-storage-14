from .dot_dict import DotDict

__all__ = [
    "DotDict"
]