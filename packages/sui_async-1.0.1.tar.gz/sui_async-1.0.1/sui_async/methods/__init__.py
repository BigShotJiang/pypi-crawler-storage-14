from .base import Base
from .client import Client
from .custom import Custom
from .server import Server


class Methods(
    Base,
    Client,
    Server,
    Custom
):
    pass