from ..models.models import (
    GET,
    GetInboundsResponse,
    GetOutboundsResponse,
    GetEndpointsResponse,
    GetServicesResponse,
    GetTLSResponse,
    GetConfigResponse,
    GetStatsResponse,
    GetStatusResponse,
    LogsResponse,
    AdminsResponse, SettingsResponse
)


class Server:

    async def get_all_parameters_server(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/load',
        )
        return result

    async def get_inbounds(self, inbound_id: int = None):
        data = {}
        if inbound_id is not None:
            data['id'] = inbound_id
        result = await self.request(
            method=GET,
            endpoint='/apiv2/inbounds',
            params=data,
        )
        return GetInboundsResponse(**result)

    async def get_outbounds(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/outbounds'
        )
        return GetOutboundsResponse(**result)

    async def get_endpoints(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/endpoints'
        )
        return GetEndpointsResponse(**result)

    async def get_services(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/services'
        )
        return GetServicesResponse(**result)

    async def get_tls(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/tls',
        )
        return GetTLSResponse(**result)

    async def get_config(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/config',
        )
        return GetConfigResponse(**result)

    async def get_settings(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/settings',
        )
        return SettingsResponse(**result)

    async def get_stats(self, params: dict[str, str] = None):
        if params is None:
            params = {}
        result = await self.request(
            method=GET,
            endpoint='/apiv2/stats',
            params=params
        )
        return GetStatsResponse(**result)

    async def get_status(
        self,
        cpu: bool = False,
        memory: bool = False,
        network: bool = False,
        system: bool = False,
        sbd: bool = False,
        dsk: bool = False,
        swp: bool = False,
        dio: bool = False,
    ):
        params = {}
        search = ''
        if cpu:
            search += 'cpu,'
        if memory:
            search += 'mem,'
        if network:
            search += 'net,'
        if system:
            search += 'sys,'
        if sbd:
            search += 'sbd,'
        if dsk:
            search += 'dsk,'
        if swp:
            search += 'swp,'
        if dio:
            search += 'dio,'
        params['r'] = search
        result = await self.request(
            method=GET,
            endpoint='/apiv2/status',
            params=params
        )
        return GetStatusResponse(**result)

    async def get_logs(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/logs',
        )
        return LogsResponse(**result)

    async def get_panel_admins(self):
        result = await self.request(
            method=GET,
            endpoint='/apiv2/users',
        )
        return AdminsResponse(**result)
