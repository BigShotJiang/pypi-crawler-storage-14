# Copyright 2024 ScriptChat contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
import tempfile
import unittest
from pathlib import Path

import requests

from scriptchat.core.config import Config, ProviderConfig, load_config
from scriptchat.core.conversations import Conversation
from scriptchat.core.openai_client import OpenAIChatClient


class OpenAIClientSmokeTest(unittest.TestCase):
    def test_provider_id_mismatch_raises(self):
        config_text = """
[general]
default_provider = "openai"
default_model = "gpt-4o"
conversations_dir = "{conv}"

[[providers]]
id = "openai"
type = "openai-compatible"
api_url = "https://api.openai.com"
api_key = "sk-test"
models = "gpt-4o"
"""
        with tempfile.TemporaryDirectory() as tmpdir:
            os.environ["HOME"] = tmpdir
            conv_dir = Path(tmpdir) / "conversations"
            cfg_dir = Path(tmpdir) / ".scriptchat"
            cfg_dir.mkdir()
            (cfg_dir / "config.toml").write_text(config_text.format(conv=conv_dir.as_posix()), encoding="utf-8")
            cfg = load_config()
            provider = cfg.get_provider("openai")
            client = OpenAIChatClient(cfg, provider, timeout=1)
            convo = Conversation(
                id=None,
                provider_id="other",
                model_name="gpt-4o",
                temperature=0.7,
                messages=[],
                tokens_in=0,
                tokens_out=0
            )
            with self.assertRaises(ValueError):
                client.chat(convo, "hi")

    def test_retries_without_temperature_on_temperature_error(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-4o",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-4o",
            default_temperature=0.7,
            timeout=1,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class FakeResponse:
            def __init__(self, status_code, payload, reason=""):
                self.status_code = status_code
                self._payload = payload
                self.reason = reason
                self.text = json.dumps(payload)

            def json(self):
                return self._payload

            def raise_for_status(self):
                if self.status_code >= 400:
                    raise requests.HTTPError("err", response=self)

            def iter_lines(self):
                return iter([])

        class FakeSession:
            def __init__(self):
                self.calls = []

            def post(self, url, json=None, timeout=None, stream=False):
                self.calls.append({"url": url, "json": json, "stream": stream})
                if len(self.calls) == 1:
                    return FakeResponse(400, {"error": {"param": "temperature", "message": "bad temperature"}}, reason="Bad Request")
                return FakeResponse(
                    200,
                    {
                        "choices": [{"message": {"content": "ok"}}],
                        "usage": {"prompt_tokens": 3, "completion_tokens": 2},
                    },
                    reason="OK",
                )

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-4o",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = FakeSession()

        reply = client.chat(convo, "hello")
        self.assertEqual(reply, "ok")
        self.assertEqual(len(client.session.calls), 2)  # retried without temperature
        self.assertEqual(convo.tokens_in, 3)
        self.assertEqual(convo.tokens_out, 2)
        # Second payload should omit temperature
        self.assertNotIn("temperature", client.session.calls[-1]["json"])

    def test_http_error_without_temperature_retry_surfaces(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-4o",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-4o",
            default_temperature=0.7,
            timeout=1,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class FailSession:
            def post(self, url, json=None, timeout=None, stream=False):
                class Resp:
                    status_code = 500
                    reason = "Server Error"
                    text = "fail"

                    def json(self_inner):
                        return {"error": {"message": "boom"}}

                    def raise_for_status(self_inner):
                        raise requests.HTTPError("fail", response=self_inner)

                    def iter_lines(self_inner):
                        return iter([])

                return Resp()

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-4o",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = FailSession()

        with self.assertRaises(RuntimeError):
            client.chat(convo, "hi")

    def test_streaming_appends_chunks_and_usage(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-4o",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-4o",
            default_temperature=0.7,
            timeout=1,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class StreamResponse:
            status_code = 200
            reason = "OK"

            def __init__(self, lines):
                self._lines = lines
                self.text = ""

            def raise_for_status(self):
                return None

            def iter_lines(self):
                return iter(self._lines)

            def json(self):
                return {}

        class StreamSession:
            def __init__(self, lines):
                self.lines = lines

            def post(self, url, json=None, timeout=None, stream=False):
                return StreamResponse(self.lines)

        lines = [
            b'data: {"choices": [{"delta": {"content": "Hel"}}], "usage": {"prompt_tokens": 1, "completion_tokens": 0}}\n',
            b'data: {"choices": [{"delta": {"content": "lo"}}], "usage": {"prompt_tokens": 1, "completion_tokens": 2}}\n',
            b"[DONE]",
        ]

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-4o",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = StreamSession(lines)

        collected = []

        def on_chunk(text):
            collected.append(text)

        content = client.chat(convo, "stream me", streaming=True, on_chunk=on_chunk)
        self.assertEqual(content, "Hello")
        self.assertEqual(collected[-1], "Hello")
        # Each chunk included usage; total prompt/completion accumulate
        self.assertEqual(convo.tokens_in, 2)
        self.assertEqual(convo.tokens_out, 2)

    def test_reasoning_effort_included_when_set(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-5.1",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-5.1",
            default_temperature=0.7,
            timeout=1,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class CaptureSession:
            def __init__(self):
                self.calls = []

            def post(self, url, json=None, timeout=None, stream=False):
                self.calls.append({"url": url, "json": json, "timeout": timeout, "stream": stream})

                class Resp:
                    status_code = 200
                    reason = "OK"
                    text = "{}"

                    def raise_for_status(self_inner):
                        return None

                    def json(self_inner):
                        return {
                            "choices": [{"message": {"content": "done"}}],
                            "usage": {"prompt_tokens": 1, "completion_tokens": 2},
                        }

                    def iter_lines(self_inner):
                        return iter([])

                return Resp()

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-5.1",
            temperature=0.7,
            reasoning_level="medium",
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = CaptureSession()

        reply = client.chat(convo, "hello")
        self.assertEqual(reply, "done")
        self.assertIn("reasoning", client.session.calls[0]["json"])
        self.assertEqual(client.session.calls[0]["json"]["reasoning"], {"effort": "medium"})
        self.assertTrue(client.session.calls[0]["url"].endswith("/v1/responses"))

    def test_responses_api_streaming_and_nonstream_content_extraction(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-5.1",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=True,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-5.1",
            default_temperature=0.7,
            timeout=1,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class StreamResponse:
            status_code = 200
            reason = "OK"

            def __init__(self, lines):
                self.lines = lines
                self.text = ""

            def raise_for_status(self):
                return None

            def iter_lines(self):
                return iter(self.lines)

            def json(self):
                return {}

        class StreamSession:
            def __init__(self, lines):
                self.lines = lines
                self.calls = []

            def post(self, url, json=None, timeout=None, stream=False):
                self.calls.append({"url": url, "json": json, "stream": stream})
                if stream:
                    return StreamResponse(self.lines)

                class Resp:
                    status_code = 200
                    reason = "OK"
                    text = "{}"

                    def raise_for_status(self_inner):
                        return None

                    def json(self_inner):
                        return {
                            "output_text": ["nonstream text"],
                            "usage": {"prompt_tokens": 1, "completion_tokens": 2},
                        }

                    def iter_lines(self_inner):
                        return iter([])

                return Resp()

        # Streaming path
        lines = [
            b'data: {"output_text": ["Hel"]}\n',
            b'data: {"output_text": ["lo"]}\n',
            b"[DONE]",
        ]

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-5.1",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = StreamSession(lines)

        collected = []

        def on_chunk(text):
            collected.append(text)

        streamed = client.chat(convo, "hi", streaming=True, on_chunk=on_chunk)
        self.assertEqual(streamed, "Hello")
        self.assertEqual(collected[-1], "Hello")

        # Non-streaming path uses same session with a fresh conversation
        convo2 = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-5.1",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        non_stream = client.chat(convo2, "hi", streaming=False)
        self.assertEqual(non_stream, "nonstream text")

    def test_runtime_timeout_override_used_for_requests(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-4o",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-4o",
            default_temperature=0.7,
            timeout=1,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class RecordingSession:
            def __init__(self):
                self.timeouts = []

            def post(self, url, json=None, timeout=None, stream=False):
                self.timeouts.append(timeout)

                class Resp:
                    status_code = 200
                    reason = "OK"
                    text = ""

                    def json(self_inner):
                        return {"choices": [{"message": {"content": "ok"}}], "usage": {}}

                    def raise_for_status(self_inner):
                        return None

                    def iter_lines(self_inner):
                        return iter([])

                return Resp()

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-4o",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = RecordingSession()

        cfg.timeout = 7

        reply = client.chat(convo, "hi")
        self.assertEqual(reply, "ok")
        self.assertEqual(client.session.timeouts, [7])

    def test_timeout_errors_are_wrapped(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-4o",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-4o",
            default_temperature=0.7,
            timeout=2,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class TimeoutSession:
            def post(self, url, json=None, timeout=None, stream=False):
                raise requests.Timeout("boom")

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-4o",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = TimeoutSession()

        with self.assertRaises(TimeoutError) as ctx:
            client.chat(convo, "hi")
        self.assertIn("Request timed out after 2 seconds", str(ctx.exception))

    def test_connection_errors_are_wrapped(self):
        provider = ProviderConfig(
            id="openai",
            type="openai-compatible",
            api_url="https://api.openai.com",
            api_key="sk-test",
            models=[],
            streaming=True,
            headers={},
            default_model="gpt-4o",
        )
        cfg = Config(
            api_url="https://api.openai.com",
            api_key="sk-test",
            conversations_dir=Path("."),
            exports_dir=None,
            enable_streaming=False,
            system_prompt=None,
            default_provider="openai",
            default_model="gpt-4o",
            default_temperature=0.7,
            timeout=2,
            file_confirm_threshold_bytes=40_000,
            log_level="INFO",
            log_file=None,
            providers=[provider],
        )

        class FailSession:
            def post(self, url, json=None, timeout=None, stream=False):
                raise requests.ConnectionError("nope")

        convo = Conversation(
            id=None,
            provider_id="openai",
            model_name="gpt-4o",
            temperature=0.7,
            messages=[],
            tokens_in=0,
            tokens_out=0,
        )
        client = OpenAIChatClient(cfg, provider, timeout=1)
        client.session = FailSession()

        with self.assertRaises(ConnectionError) as ctx:
            client.chat(convo, "hi")
        self.assertIn("Failed to connect to provider at https://api.openai.com", str(ctx.exception))
        self.assertIn("/timeout", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
