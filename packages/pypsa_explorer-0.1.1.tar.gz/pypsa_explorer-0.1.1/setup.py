"""
Setup configuration for PyPSA Explorer.

This file exists for editable installs and backwards compatibility.
Configuration is primarily in pyproject.toml.
"""

from setuptools import setup

setup()
