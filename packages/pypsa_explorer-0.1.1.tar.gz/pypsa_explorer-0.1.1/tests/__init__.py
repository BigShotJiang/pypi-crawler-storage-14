"""Test suite for PyPSA Explorer."""
