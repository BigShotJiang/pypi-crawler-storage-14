"""Configuration management commands.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

import getpass

import click
from rich.console import Console
from rich.text import Text

from glaip_sdk.branding import ACCENT_STYLE, ERROR_STYLE, INFO, SUCCESS, SUCCESS_STYLE, WARNING_STYLE
from glaip_sdk.cli.account_store import get_account_store
from glaip_sdk.cli.commands.common_config import check_connection, render_branding_header
from glaip_sdk.cli.config import CONFIG_FILE, load_config, save_config
from glaip_sdk.cli.hints import format_command_hint
from glaip_sdk.cli.masking import mask_api_key_display
from glaip_sdk.cli.rich_helpers import markup_text
from glaip_sdk.cli.utils import command_hint
from glaip_sdk.icons import ICON_TOOL
from glaip_sdk.rich_components import AIPTable

console = Console()

# Shared deprecation banner for legacy config commands
CONFIG_DEPRECATION_MSG = (
    f"[{WARNING_STYLE}]Deprecated: 'aip config ...' will be removed in a future release. "
    "Use 'aip accounts ...' (list/add/use/remove) or 'aip configure' for the wizard.[/]"
)


def _print_config_deprecation() -> None:
    """Print a standardized deprecation warning for legacy config commands."""
    console.print(CONFIG_DEPRECATION_MSG)


@click.group()
def config_group() -> None:
    """Configuration management operations."""
    _print_config_deprecation()


@config_group.command("list")
@click.option("--json", "output_json", is_flag=True, help="Output in JSON format")
@click.pass_context
def list_config(ctx: click.Context, output_json: bool) -> None:
    """List current configuration.

    Deprecated: run 'aip accounts list' for profile-aware output.
    """
    console.print(f"[{WARNING_STYLE}]Deprecated: run 'aip accounts list' for profile-aware output.[/]")

    # Delegate to accounts list by invoking the command
    from glaip_sdk.cli.commands.accounts import accounts_group  # noqa: PLC0415

    list_cmd = accounts_group.get_command(ctx, "list")
    if list_cmd:
        ctx.invoke(list_cmd, output_json=output_json)


CONFIG_VALUE_TYPES: dict[str, str] = {
    "api_url": "string",
    "api_key": "string",
    "timeout": "float",
    "history_default_limit": "int",
}


def _parse_bool_config(value: str) -> bool:
    """Parse boolean-like CLI input."""
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    raise click.ClickException("Invalid boolean value. Use one of: true, false, yes, no, 1, 0.")


def _parse_int_config(value: str) -> int:
    """Parse integer CLI input with non-negative enforcement."""
    try:
        parsed = int(value, 10)
    except ValueError as exc:
        raise click.ClickException("Invalid integer value.") from exc
    if parsed < 0:
        raise click.ClickException("Value must be greater than or equal to 0.")
    return parsed


def _parse_float_config(value: str) -> float:
    """Parse float CLI input with non-negative enforcement."""
    try:
        parsed = float(value)
    except ValueError as exc:
        raise click.ClickException("Invalid float value.") from exc
    if parsed < 0:
        raise click.ClickException("Value must be greater than or equal to 0.")
    return parsed


def _coerce_config_value(key: str, raw_value: str) -> str | bool | int | float:
    """Convert CLI string values to their target config types."""
    kind = CONFIG_VALUE_TYPES.get(key, "string")
    if kind == "bool":
        return _parse_bool_config(raw_value)
    if kind == "int":
        return _parse_int_config(raw_value)
    if kind == "float":
        return _parse_float_config(raw_value)
    return raw_value


@config_group.command("set")
@click.argument("key")
@click.argument("value")
@click.option(
    "--account",
    "account_name",
    help="Account name to set value for (defaults to active account)",
)
def set_config(key: str, value: str, account_name: str | None) -> None:
    """Set a configuration value.

    For api_url and api_key, this operates on the specified account (or active account).
    Other keys (timeout, history_default_limit) are global settings.
    """
    # For other keys, use legacy config
    valid_keys = tuple(CONFIG_VALUE_TYPES.keys())
    if key not in valid_keys:
        console.print(f"[{ERROR_STYLE}]Error: Invalid key '{key}'. Valid keys are: {', '.join(valid_keys)}[/]")
        raise click.ClickException(f"Invalid configuration key: {key}")

    store = get_account_store()
    # For api_url and api_key, update account profile but also mirror to legacy config
    if key in ("api_url", "api_key"):
        target_account = account_name or store.get_active_account() or "default"
        try:
            account = store.get_account(target_account) or {}
            account[key] = value
            store.add_account(
                target_account,
                account.get("api_url", ""),
                account.get("api_key", ""),
                overwrite=True,
            )
        except Exception:
            # If account store persistence fails (e.g., mocked I/O), continue with legacy config
            pass

        # Always update legacy config for backward compatibility and test isolation
        legacy_config = load_config()
        legacy_config[key] = value
        save_config(legacy_config)

        display_value = _mask_api_key(value) if key == "api_key" else value
        console.print(Text(f"✅ Set {key} = {display_value} for account '{target_account}'", style=SUCCESS_STYLE))
        return

    coerced_value = _coerce_config_value(key, value)
    config = load_config()
    config[key] = coerced_value
    save_config(config)

    display_value = _mask_api_key(coerced_value) if key == "api_key" else str(coerced_value)
    console.print(Text(f"✅ Set {key} = {display_value}", style=SUCCESS_STYLE))


@config_group.command("get")
@click.argument("key")
def get_config(key: str) -> None:
    """Get a configuration value."""
    config = load_config()

    value = config.get(key)

    # Fallback to account store for api_url/api_key when legacy config lacks the key
    if value is None and key in {"api_url", "api_key"}:
        store = get_account_store()
        active = store.get_active_account() or "default"
        account = store.get_account(active) or {}
        value = account.get(key)

    if value is None:
        console.print(markup_text(f"[{WARNING_STYLE}]Configuration key '{key}' not found.[/]"))
        raise click.ClickException(f"Configuration key not found: {key}")

    if key == "api_key":
        console.print(_mask_api_key(value))
    else:
        console.print(value)


@config_group.command("unset")
@click.argument("key")
def unset_config(key: str) -> None:
    """Remove a configuration value."""
    config = load_config()

    if key not in config:
        console.print(markup_text(f"[{WARNING_STYLE}]Configuration key '{key}' not found.[/]"))
        return

    del config[key]
    save_config(config)

    console.print(Text(f"✅ Removed {key} from configuration", style=SUCCESS_STYLE))


@config_group.command("reset")
@click.option("--force", is_flag=True, help="Skip confirmation prompt")
def reset_config(force: bool) -> None:
    """Reset all configuration to defaults."""
    if not force:
        console.print(f"[{WARNING_STYLE}]This will remove all AIP configuration.[/]")
        confirm = input("Are you sure? (y/N): ").strip().lower()
        if confirm not in ["y", "yes"]:
            console.print("Cancelled.")
            return

    config_data = load_config()
    file_exists = CONFIG_FILE.exists()

    if not file_exists and not config_data:
        console.print(f"[{WARNING_STYLE}]No configuration found to reset.[/]")
        console.print(Text("✅ Configuration reset (nothing to remove).", style=SUCCESS_STYLE))
        return

    if file_exists:
        try:
            CONFIG_FILE.unlink()
        except FileNotFoundError:  # pragma: no cover - defensive cleanup
            pass
    else:
        # In-memory configuration (e.g., tests) needs explicit clearing
        save_config({})

    hint = command_hint("config configure", slash_command="login")
    message = Text("✅ Configuration reset.", style=SUCCESS_STYLE)
    if hint:
        message.append(f" Run '{hint}' to set up again.")
    console.print(message)


def _configure_interactive(account_name: str | None = None) -> None:
    """Shared configuration logic for both configure commands."""
    store = get_account_store()

    # Determine account name (use provided, active, or default)
    if not account_name:
        account_name = store.get_active_account() or "default"

    # Get existing account if it exists
    existing = store.get_account(account_name)

    _render_configuration_header()
    config = _prompt_configuration_inputs_for_account(existing)

    # Save to account store
    api_url = config.get("api_url", "")
    api_key = config.get("api_key", "")
    if api_url and api_key:
        store.add_account(account_name, api_url, api_key, overwrite=True)
        console.print(Text(f"\n✅ Configuration saved to account '{account_name}'", style=SUCCESS_STYLE))

    _test_and_report_connection_for_account(account_name)
    _print_post_configuration_hints()
    # Show active account footer
    from glaip_sdk.cli.commands.accounts import _print_active_account_footer  # noqa: PLC0415

    _print_active_account_footer(store)


@config_group.command()
@click.option(
    "--account",
    "account_name",
    help="Account name to configure (defaults to active account)",
)
def configure(account_name: str | None) -> None:
    """Configure AIP CLI credentials and settings interactively.

    This command is an alias for 'aip accounts add <name>' and will
    configure the specified account (or active account if not specified).
    """
    _configure_interactive(account_name)


# Alias command for backward compatibility
@click.command()
@click.option(
    "--account",
    "account_name",
    help="Account name to configure (defaults to active account)",
)
def configure_command(account_name: str | None) -> None:
    """Configure AIP CLI credentials and settings interactively.

    This is an alias for 'aip config configure' for backward compatibility.
    For multi-account support, use 'aip accounts add <name>' instead.
    """
    console.print(
        f"[{WARNING_STYLE}]Setup tip:[/] Prefer 'aip accounts add <name>' or 'aip configure' from your terminal for "
        "multi-account setup. Launching the interactive wizard now..."
    )
    # Delegate to the shared function
    _configure_interactive(account_name)


# Note: The config command group should be registered in main.py
_mask_api_key = mask_api_key_display


def _print_missing_config_hint() -> None:
    """Show guidance when no configuration file exists."""
    hint = command_hint("config configure", slash_command="login")
    if hint:
        console.print(f"[{WARNING_STYLE}]No configuration found.[/] Run {format_command_hint(hint) or hint} to set up.")
    else:
        console.print(f"[{WARNING_STYLE}]No configuration found.[/]")


def _render_config_table(config: dict[str, str]) -> None:
    """Render the current configuration in a friendly table."""
    table = AIPTable(title=f"{ICON_TOOL} AIP Configuration")
    table.add_column("Setting", style=INFO, width=20)
    table.add_column("Value", style=SUCCESS)

    for key, value in config.items():
        table.add_row(key, _mask_api_key(value) if key == "api_key" else str(value))

    console.print(table)
    console.print(Text(f"\n📁 Config file: {CONFIG_FILE}"))


def _render_configuration_header() -> None:
    """Display the interactive configuration heading/banner."""
    render_branding_header(console, "[bold]AIP Configuration[/bold]")


def _prompt_configuration_inputs_for_account(existing: dict[str, str] | None) -> dict[str, str]:
    """Interactively prompt for account configuration values."""
    console.print("\n[bold]Enter your AIP configuration:[/bold]")
    if existing:
        console.print("(Leave blank to keep current values)")
    console.print("─" * 50)

    config = existing.copy() if existing else {}

    _prompt_api_url(config)
    _prompt_api_key(config)

    return config


def _prompt_api_url(config: dict[str, str]) -> None:
    """Ask the user for the API URL, preserving existing values by default."""
    current_url = config.get("api_url", "")
    suffix = f"(current: {current_url})" if current_url else ""
    console.print(f"\n[{ACCENT_STYLE}]AIP API URL[/] {suffix}:")
    new_url = input("> ").strip()
    if new_url:
        config["api_url"] = new_url
    elif not current_url:
        config["api_url"] = "https://your-aip-instance.com"


def _prompt_api_key(config: dict[str, str]) -> None:
    """Prompt the user for the API key while masking previous input."""
    current_key_masked = _mask_api_key(config.get("api_key"))
    suffix = f"(current: {current_key_masked})" if current_key_masked else ""
    console.print(f"\n[{ACCENT_STYLE}]AIP API Key[/] {suffix}:")
    new_key = getpass.getpass("> ")
    if new_key:
        config["api_key"] = new_key


def _test_and_report_connection_for_account(account_name: str) -> None:
    """Sanity-check the provided credentials against the backend."""
    store = get_account_store()
    account = store.get_account(account_name)
    if not account:
        return

    api_url = account.get("api_url", "")
    api_key = account.get("api_key", "")
    if not api_url or not api_key:
        return

    hint_status = command_hint("status", slash_command="status")
    extra_hint = None
    if hint_status:
        extra_hint = f"   You can run {format_command_hint(hint_status) or hint_status} later to test again"

    check_connection(api_url, api_key, console, abort_on_error=False, extra_hint=extra_hint)


def _print_post_configuration_hints() -> None:
    """Offer next-step guidance after configuration completes."""
    console.print("\n💡 You can now use AIP CLI commands!")
    hint_status = command_hint("status", slash_command="status")
    if hint_status:
        console.print(f"   • Run {format_command_hint(hint_status) or hint_status} to check connection")
    hint_agents = command_hint("agents list", slash_command="agents")
    if hint_agents:
        console.print(f"   • Run {format_command_hint(hint_agents) or hint_agents} to see your agents")
