## 快速清理无效的环境变量 (windows+linux+macos)


### 快速开始

```bash
uv run main.py  or  python main.py
```

