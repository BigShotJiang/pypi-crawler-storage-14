import os
import sys
import platform
from pathlib import Path

if sys.platform == "win32":
    import winreg


def read_env():
    if sys.platform == "win32":
        path = get_user_path_windows()
        env_vars = get_user_env_var_windows()
    else:
        path = os.environ.get("PATH")
        env_vars = get_user_env_var_unix()
    return path, env_vars


def get_user_env_var_windows():
    env_vars = {}
    try:
        with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                "Environment",
                0,
                winreg.KEY_READ,
        ) as key:
            i = 0
            while True:
                try:
                    name, value, _ = winreg.EnumValue(key, i)
                    if name.upper() == "PATH":
                        i += 1
                        continue
                    env_vars[name] = value
                    i += 1
                except OSError:
                    break
        return env_vars
    except Exception as e:
        print(f"Error reading registry: {e}")
        return None


def set_user_env_var_windows(name, value):
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment",
            0,
            winreg.KEY_SET_VALUE,
        )
        winreg.SetValueEx(key, name, 0, winreg.REG_EXPAND_SZ, value)
        winreg.CloseKey(key)
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False


def delete_user_env_var_windows(name):
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment",
            0,
            winreg.KEY_SET_VALUE,
        )
        winreg.DeleteValue(key, name)
        winreg.CloseKey(key)
        return True
    except FileNotFoundError:
        print(f"变量 {name} 不存在，无需删除")
        return False
    except Exception as e:
        print(f"删除失败: {e}")
        return False


def get_user_path_windows():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Environment") as key:
            path, _ = winreg.QueryValueEx(key, "PATH")
            return path
    except OSError:
        return None


def get_user_env_var_unix():
    env_vars = {k: v for k, v in os.environ.items() if k != "PATH"}
    return env_vars


def set_user_env_var_unix(name, value, shell_rc=None):
    """
    在 macOS / Linux 中设置持久环境变量
    shell_rc: 指定 rc 文件，例如 ~/.zshrc 或 ~/.bashrc
    """
    home = Path.home()
    if shell_rc is None:
        # macOS Catalina 及以后默认 zsh
        shell_rc = home / (".zshrc" if platform.system() == "Darwin" else ".bashrc")

    export_line = f'export {name}="{value}"\n'

    if shell_rc.exists():
        lines = shell_rc.read_text().splitlines()
        lines = [l for l in lines if not l.strip().startswith(f"export {name}=")]
    else:
        lines = []

    lines.append(export_line.strip())
    shell_rc.write_text("\n".join(lines) + "\n")
    print(f"已将 {name} 添加到 {shell_rc}（需要重新打开终端生效）")


def delete_user_env_var_unix(name, shell_rc=None):
    home = Path.home()
    if shell_rc is None:
        shell_rc = home / (".zshrc" if platform.system() == "Darwin" else ".bashrc")

    if not shell_rc.exists():
        return

    lines = shell_rc.read_text().splitlines()
    new_lines = [l for l in lines if not l.strip().startswith(f"export {name}=")]
    shell_rc.write_text("\n".join(new_lines) + "\n")
    print(f"已从 {shell_rc} 删除 {name}")


def reset_path(paths: list):
    new_path = os.pathsep.join(paths)
    if sys.platform == "win32":
        user_path = get_user_path_windows()
        if user_path == new_path:
            print("PATH 已是目标值")
            return
        set_user_env_var_windows("PATH", new_path)
    else:
        current_path = os.environ.get("PATH", "")
        if current_path == new_path:
            print("PATH 已是目标值")
            return
        set_user_env_var_unix("PATH", new_path)
    print(f"新 PATH: {new_path}")


def main():
    path, env_vars = read_env()
    paths = check_path(path)
    reset_path(paths)
    check_env(env_vars)


def check_path(path: str):
    paths = path.split(os.pathsep)
    paths = list(filter(lambda x: x != "", paths))
    new_paths = []
    for p in paths:
        if not os.path.exists(p):
            print(f"Path {p} 不存在")
            continue
        new_paths.append(p)
    return new_paths


def check_env(env_vars: dict):
    new_env_vars = {}
    for key, value in env_vars.items():
        if os.path.exists(value):
            continue
        else:
            print(f"{key} 的路径无效: {value}")
            new_env_vars[key] = value

    if sys.platform == "win32":
        old_env_vars = get_user_env_var_windows()
        if new_env_vars == old_env_vars:
            print("环境变量已是目标值")
            return
        for key in new_env_vars.keys():
            delete_user_env_var_windows(key)
    else:
        old_env_vars = get_user_env_var_unix()
        if new_env_vars == old_env_vars:
            print("环境变量已是目标值")
            return
        for key in new_env_vars.keys():
            delete_user_env_var_unix(key)


if __name__ == "__main__":
    main()
