# Changelog

This page was created to track changes to versions of GraphEx-Web-Automation-Plugin. The changelog was created in v1.1.3 and only changes starting from that version are tracked here.

## 1.1.3

- Update package metadata for PyPI
- Pin setuptools verison
