> Crackerjack Docs: [Main](<../../README.md>) | [Crackerjack Package](<../README.md>) | [Plugins](<./README.md>)

# Plugins

Optional plugins and extensions to the core system.

## Related

- [Crackerjack Package](<../README.md>) - Parent package
- [Agents](<../agents/README.md>) - AI agent system
- [Services](<../services/README.md>) - Core services that plugins extend
