# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.ContentX import ContentX

class FourPichive(ContentX):
    name     = "FourPichive"
    main_url = "https://four.pichive.online"