# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.VidMoly import VidMoly

class VidMolyMe(VidMoly):
    name     = "VidMolyMe"
    main_url = "https://vidmoly.me"