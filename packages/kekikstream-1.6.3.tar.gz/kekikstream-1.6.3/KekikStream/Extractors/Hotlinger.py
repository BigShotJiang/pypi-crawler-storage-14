# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.ContentX import ContentX

class Hotlinger(ContentX):
    name     = "Hotlinger"
    main_url = "https://hotlinger.com"