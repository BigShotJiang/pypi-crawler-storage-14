# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.ContentX import ContentX

class FourPlayRu(ContentX):
    name     = "FourPlayRu"
    main_url = "https://four.playru.net"