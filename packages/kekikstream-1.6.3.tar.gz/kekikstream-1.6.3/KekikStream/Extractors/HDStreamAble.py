# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Extractors.PeaceMakerst import PeaceMakerst

class HDStreamAble(PeaceMakerst):
    name     = "HDStreamAble"
    main_url = "https://hdstreamable.com"