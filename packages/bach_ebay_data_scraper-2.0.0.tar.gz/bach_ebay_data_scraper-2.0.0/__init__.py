"""MCP Server for Ebay Data Scraper"""
