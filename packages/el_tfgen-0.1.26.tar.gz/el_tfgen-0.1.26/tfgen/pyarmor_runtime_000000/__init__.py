# Pyarmor 9.2.1 (trial), 000000, 2025-12-01T17:47:17.187882
from .pyarmor_runtime import __pyarmor__
