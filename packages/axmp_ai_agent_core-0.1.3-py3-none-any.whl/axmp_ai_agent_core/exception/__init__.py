"""Exception module for AIOps Pilot."""
