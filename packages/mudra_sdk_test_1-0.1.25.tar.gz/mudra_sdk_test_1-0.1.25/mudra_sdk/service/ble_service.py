import asyncio
from typing import Callable, Optional
from bleak import BleakScanner
from bleak.backends.device import BLEDevice

from ..models.mudra_device import MudraDevice


class BleService:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        self._scan_task = None
        self._on_device_found: Optional[Callable[[MudraDevice], None]] = None
        self._scanner: Optional[BleakScanner] = None

    @property
    def _is_scanning(self) -> bool:
        """Check if currently scanning for devices."""
        return self._scan_task is not None and not self._scan_task.done()

    async def scan(self, callback: Callable[[MudraDevice], None]):
        """Start scanning for BLE devices."""
        if self._is_scanning:
            return
        print("Starting scan")
        self._on_device_found = callback
        self._scan_task = asyncio.create_task(self._scan_loop())

    async def stop_scanning(self):
        """Stop scanning for BLE devices."""
        if not self._is_scanning:
            return
        print("Stopping scan")
        
        # Cancel the scan task
        if self._scan_task and not self._scan_task.done():
            self._scan_task.cancel()
            try:
                await self._scan_task
            except asyncio.CancelledError:
                pass
        
        # Stop the scanner if it exists
        if self._scanner:
            try:
                await self._scanner.stop()
            except Exception as e:
                print(f"Error stopping scanner: {e}")
            finally:
                self._scanner = None
        
        self._scan_task = None
        self._on_device_found = None

    async def _scan_loop(self):
        """Internal method that performs the actual scanning."""
        try:
            self._scanner = BleakScanner()
            self._scanner.register_detection_callback(self._on_device_detected)
            
            await self._scanner.start()
            print("Scan started successfully")
            
            # Keep scanning until cancelled
            while True:
                await asyncio.sleep(1)
                
        except asyncio.CancelledError:
            print("Scan cancelled")
            if self._scanner:
                try:
                    await self._scanner.stop()
                except Exception as e:
                    print(f"Error stopping scanner during cancellation: {e}")
            raise
        except Exception as e:
            print(f"Error during scan: {e}")
            raise
        finally:
            self._scanner = None
            self._scan_task = None

    def _on_device_detected(self, device: BLEDevice, advertisement_data):
        """Callback when a BLE device is detected."""
        if self._on_device_found:
            try:
                mudra_device = MudraDevice(device)
                self._on_device_found(mudra_device)
            except Exception as e:
                print(f"Error processing device {device.address}: {e}")
