"""SSB Guardian Client."""

from ssb_guardian_client.client import GuardianClient

__all__ = ["GuardianClient"]
