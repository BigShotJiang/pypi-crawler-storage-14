This module allows to show the stock available in the e-commerce product matrix.
