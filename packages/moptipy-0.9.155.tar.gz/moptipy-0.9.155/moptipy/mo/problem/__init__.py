"""Routines and tools for defining multi-objective optimization problems."""
