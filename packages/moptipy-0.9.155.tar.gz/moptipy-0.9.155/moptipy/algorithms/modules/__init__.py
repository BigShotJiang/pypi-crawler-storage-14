"""A set of reuseable algorithm modules."""
