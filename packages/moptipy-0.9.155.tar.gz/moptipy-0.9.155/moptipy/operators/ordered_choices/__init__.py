"""
The operators for :mod:`moptipy.spaces.ordered_choices` spaces.

- Module :mod:`~moptipy.operators.ordered_choices.op0_choose_and_shuffle`
  provides a nullary operator for randomly picking an ordered choices
  instance.
"""
