"""
Migration 002: Add subdataset tracking and metadata.

Adds support for:
- Tracking parent-child relationships between datasets
- Identifying dataset types (main vs subdataset)
- Storing modality and column metadata for smart defaults
"""
import sqlite3


class Migration:
    version = 2
    description = "Add subdataset tracking and modality metadata"

    @staticmethod
    def upgrade(conn: sqlite3.Connection):
        """Add columns for subdataset tracking and metadata."""

        # Add parent dataset tracking to datasets table
        # NULL parent means this is a main dataset
        conn.execute("""
            ALTER TABLE datasets
            ADD COLUMN parent_workspace TEXT
        """)

        conn.execute("""
            ALTER TABLE datasets
            ADD COLUMN parent_name TEXT
        """)

        # Add dataset type (main or subdataset)
        conn.execute("""
            ALTER TABLE datasets
            ADD COLUMN dataset_type TEXT DEFAULT 'main'
        """)

        # Create index for faster subdataset queries
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_datasets_parent
            ON datasets(parent_workspace, parent_name)
        """)

        # Add foreign key constraint (SQLite requires recreation for FK)
        # Note: We'll validate this in application code instead due to SQLite limitations

        print("  ✓ Added parent_workspace, parent_name, dataset_type columns to datasets")
        print("  ✓ Created index on (parent_workspace, parent_name)")

    @staticmethod
    def downgrade(conn: sqlite3.Connection):
        """Remove subdataset tracking columns."""
        # SQLite doesn't support DROP COLUMN directly
        # Would need to recreate table - skipping for now
        # In practice, migrations are forward-only
        print("  Note: Downgrade not supported for SQLite ALTER TABLE")
        print("  To fully downgrade, manually recreate datasets table")
