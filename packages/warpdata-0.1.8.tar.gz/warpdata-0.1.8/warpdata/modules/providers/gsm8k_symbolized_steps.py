from __future__ import annotations
from ..base import BaseWarpDatasetModule


class GSM8KSymbolizedStepsModule(BaseWarpDatasetModule):
    """Provider for math/gsm8k_symbolized-steps dataset (per-step symbolic)."""

    id = "warp.dataset.gsm8k_symbolized_steps"
    version = "1.0.0"
    dataset_uri = "warpdata://math/gsm8k_symbolized-steps"

    # Inherit base behavior

