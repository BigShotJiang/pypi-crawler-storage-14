from __future__ import annotations
from ..base import BaseWarpDatasetModule


class HellaSwagModule(BaseWarpDatasetModule):
    id = "warp.dataset.hellaswag"
    version = "1.0.0"
    dataset_uri = "warpdata://reasoning/hellaswag"

