from __future__ import annotations
from ..base import BaseWarpDatasetModule


class ArcAGIModule(BaseWarpDatasetModule):
    id = "warp.dataset.arcagi"
    version = "1.0.0"
    dataset_uri = "warpdata://arc/arcagi"


class ArcAGI2Module(BaseWarpDatasetModule):
    id = "warp.dataset.arcagi2"
    version = "1.0.0"
    dataset_uri = "warpdata://arc/arcagi2"

