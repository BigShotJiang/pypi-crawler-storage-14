"""
Embeddings API for warpdata.

Provides functions for:
- Adding embedding spaces to datasets
- Searching embeddings
- Joining search results back to original data
- Listing embedding spaces
"""
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Union, Tuple
import numpy as np
import pyarrow.parquet as pq
import pyarrow as pa

logger = logging.getLogger(__name__)

from ..core.uris import parse_uri
from ..core.registry import get_registry
from ..core.cache import get_cache
from ..compute.embeddings import get_provider

# Optional progress bar (tqdm). If not available, we run without UI.
try:  # pragma: no cover - best-effort optional dependency
    from tqdm.auto import tqdm as _tqdm  # type: ignore
except Exception:  # pragma: no cover
    _tqdm = None


def add_embeddings(
    dataset_id: str,
    space: str,
    provider: str,
    source: Dict[str, Any],
    model: Optional[str] = None,
    dimension: Optional[int] = None,
    distance_metric: str = "cosine",
    batch_size: int = 100,
    show_progress: bool = True,
    max_rows: Optional[int] = None,
    rows_per_chunk: Optional[int] = None,
    write_rows_per_group: Optional[int] = None,
    **provider_kwargs,
) -> Path:
    """
    Add an embedding space to a dataset.

    The dataset must first be materialized to have a 'rid' (row ID) column.

    Args:
        dataset_id: Dataset ID (e.g., 'warpdata://nlp/reviews' or shorthand 'nlp/reviews')
        space: Name for this embedding space
        provider: Embedding provider ('numpy', 'sentence-transformers', 'openai', 'clap-audio', 'clip', 'clip-text')
        source: Source configuration (e.g., {'columns': ['text']})
        model: Model name (provider-specific)
        dimension: Embedding dimension (for providers that need it)
        distance_metric: Distance metric ('cosine', 'euclidean', 'dot')
        batch_size: Batch size for processing
        **provider_kwargs: Additional provider arguments

    Returns:
        Path to embedding storage directory

    Examples:
        >>> import warpdata as wd
        >>> wd.add_embeddings(
        ...     "warpdata://nlp/reviews",
        ...     space="openai-ada",
        ...     provider="openai",
        ...     model="text-embedding-ada-002",
        ...     source={"columns": ["review_text"]}
        ... )
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    # Materialize dataset to ensure rid column exists (do this FIRST)
    from .management import materialize
    from ..engine.duck import get_engine

    # Materialize without updating registry to keep dataset version stable
    materialized_path = materialize(dataset_id, update_registry=False)

    # Get dataset version AFTER materialization (version may have changed)
    registry = get_registry()
    dataset_ver = registry.get_dataset_version(workspace, name, version)

    if dataset_ver is None:
        raise ValueError(f"Dataset not found: {dataset_id}")

    version_hash = dataset_ver["version_hash"]

    # Get embedding provider first to know dimension
    # Resolve default model names per provider for clear registry metadata
    resolved_model = model
    if provider == "sentence-transformers" and resolved_model is None:
        resolved_model = "all-MiniLM-L6-v2"
    elif provider == "openai" and resolved_model is None:
        resolved_model = "text-embedding-ada-002"
    elif provider == "clip" and resolved_model is None:
        resolved_model = "openai/clip-vit-base-patch32"
    elif provider == "clap-audio" and resolved_model is None:
        resolved_model = "laion/clap-htsat-unfused"
    elif provider == "numpy" and dimension is None:
        # Keep None here; dimension is handled below
        pass

    embedding_provider = get_provider(
        provider=provider, model=resolved_model, dimension=dimension, **provider_kwargs
    )
    actual_dimension = embedding_provider.get_dimension()

    # Extract source columns
    columns = source.get("columns", [])
    if not columns:
        raise ValueError("Source must specify 'columns' to embed")

    # Build SQL query to concatenate columns and stream data
    # Safely quote column names, cast to string, and handle NULLs
    safe_columns = [f'COALESCE(CAST("{col}" AS VARCHAR), \'\')' for col in columns]
    text_sql_expr = "trim(" + " || ' ' || ".join(safe_columns) + ")"

    # Determine max text length based on provider
    # Most sentence transformers have 512 token limit (~2000 chars)
    # Truncate at SQL level to save memory and prevent tokenization issues
    if provider == "sentence-transformers":
        max_chars = 8000  # ~2000 tokens with safety margin
        text_sql_expr = f"LEFT({text_sql_expr}, {max_chars})"
    elif provider in ["openai", "clip-text"]:
        max_chars = 32000  # More generous for these models
        text_sql_expr = f"LEFT({text_sql_expr}, {max_chars})"

    # Create streaming query ordered by rid
    # Filter out rows with NULL or empty text to avoid embedding empty strings
    engine = get_engine()
    base_query_core = f"""
    SELECT rid, {text_sql_expr} AS text_to_embed
    FROM read_parquet('{materialized_path}')
    WHERE {text_sql_expr} IS NOT NULL AND {text_sql_expr} != ''
    """

    # Build final queries (count/read) with optional LIMIT
    limit_clause = f" LIMIT {int(max_rows)}" if (max_rows is not None and int(max_rows) > 0) else ""
    count_source_query = base_query_core + limit_clause

    # Determine total row count for progress bar and indexing heuristics
    try:
        count_query = f"SELECT COUNT(*) AS cnt FROM ({count_source_query}) AS sub"
        total_rows = engine.conn.execute(count_query).fetchone()[0]
    except Exception:
        total_rows = None

    # Prepare storage directory
    cache = get_cache()
    dataset_cache_dir = cache.get_dataset_cache_dir(workspace, name, version_hash)
    embeddings_dir = dataset_cache_dir / "embeddings" / space
    embeddings_dir.mkdir(parents=True, exist_ok=True)

    # Save embeddings as Parquet using efficient Arrow FixedSizeList
    vectors_path = embeddings_dir / "vectors.parquet"

    # Check if embeddings already exist and compare sizes
    existing_count = 0
    if vectors_path.exists():
        try:
            existing_table = pq.read_table(vectors_path)
            existing_count = len(existing_table)
            logger.info(f"Found existing embeddings: {existing_count:,} rows")

            # If we're trying to embed more rows than exist, overwrite
            if total_rows is not None and total_rows > existing_count:
                logger.info(f"Target size ({total_rows:,} rows) > existing ({existing_count:,} rows), overwriting...")
                vectors_path.unlink()
                existing_count = 0
            else:
                logger.info(f"Embeddings already complete ({existing_count:,} rows), skipping")
                # Register the space if not already registered
                registry.add_embedding_space(
                    workspace=workspace,
                    name=name,
                    version_hash=version_hash,
                    space=space,
                    provider=provider,
                    model=resolved_model,
                    dimension=actual_dimension,
                    distance_metric=distance_metric,
                    source=source,
                )
                return vectors_path
        except Exception as e:
            logger.warning(f"Error reading existing embeddings ({e}), will overwrite")
            if vectors_path.exists():
                vectors_path.unlink()
            existing_count = 0

    # Progress bar
    pbar = None
    if show_progress and _tqdm is not None and total_rows is not None:
        desc = f"Embedding {uri.workspace}/{uri.name}:{space}"
        try:
            pbar = _tqdm(total=total_rows, desc=desc, unit="rows")
        except Exception:
            pbar = None

    # Stream rows in batches from DuckDB using LIMIT/OFFSET pages to strictly bound memory
    writer = None
    rows_written = 0

    # Auto-calculate intelligent defaults based on available memory and text size
    def _calculate_smart_defaults():
        try:
            import psutil
            mem = psutil.virtual_memory()
            available_gb = mem.available / (1024**3)

            # Sample text lengths to estimate memory usage
            sample_query = base_query_core + " LIMIT 100"
            try:
                sample_df = engine.conn.execute(sample_query).fetchdf()
                if len(sample_df) > 0:
                    texts = sample_df["text_to_embed"].astype(str)
                    avg_text_bytes = texts.apply(lambda x: len(x.encode('utf-8'))).mean()
                    max_text_bytes = texts.apply(lambda x: len(x.encode('utf-8'))).max()
                else:
                    avg_text_bytes = 1000
                    max_text_bytes = 5000
            except Exception:
                avg_text_bytes = 1000
                max_text_bytes = 5000

            # Estimate memory per row during processing:
            # 1. Text string in Python (UTF-8 + Python object overhead ~50 bytes)
            # 2. Embedding output (dimension × 4 bytes float32)
            # 3. Buffer overhead (lists, arrays, etc.)
            bytes_per_text = avg_text_bytes + 50
            bytes_per_embedding = actual_dimension * 4
            bytes_per_row_buffer = bytes_per_text + bytes_per_embedding + 100

            # Text processing requires much more memory than just storage
            # Account for: batch in RAM, tokenization overhead, model activations
            # Use 3x multiplier for text + tokenization + intermediate tensors
            processing_multiplier = 3.0
            bytes_per_row_processing = bytes_per_text * processing_multiplier

            # Use only 10% of available RAM for buffering (very conservative)
            # This leaves room for model, tokenizer, and CUDA memory
            buffer_memory = available_gb * 0.10 * (1024**3)

            # Calculate max rows based on buffer memory (for write buffer)
            max_buffer_rows = int(buffer_memory / bytes_per_row_buffer)

            # Calculate chunk size based on processing memory
            # We want chunks small enough to process without OOM
            processing_memory = available_gb * 0.15 * (1024**3)
            max_chunk_rows = int(processing_memory / bytes_per_row_processing)

            # Clamp to reasonable ranges based on text size
            # Be extra conservative - multiply text size by 10x for safety
            # (accounts for batch processing, Python overhead, tokenization)
            if avg_text_bytes < 200:  # Very short texts (captions, labels)
                smart_chunk = max(50000, min(max_chunk_rows, 200000))
                smart_write_group = max(100000, min(max_buffer_rows, 500000))
            elif avg_text_bytes < 1000:  # Short texts (tweets, summaries)
                smart_chunk = max(20000, min(max_chunk_rows, 100000))
                smart_write_group = max(50000, min(max_buffer_rows, 200000))
            elif avg_text_bytes < 5000:  # Medium texts (paragraphs, reviews)
                smart_chunk = max(10000, min(max_chunk_rows, 50000))
                smart_write_group = max(30000, min(max_buffer_rows, 100000))
            else:  # Long texts (articles, documents) - very conservative
                smart_chunk = max(5000, min(max_chunk_rows, 20000))
                smart_write_group = max(10000, min(max_buffer_rows, 50000))

            logger.info(f"Auto-tuning: {available_gb:.1f}GB avail, avg_text={avg_text_bytes:.0f}B (max={max_text_bytes:.0f}B), "
                       f"chunk={smart_chunk:,}, write_group={smart_write_group:,}")

            return smart_chunk, smart_write_group
        except Exception as e:
            logger.warning(f"Auto-tuning failed ({e}), using conservative defaults")
            # Fallback to very conservative defaults
            return 20000, 50000

    # Micro-chunk size for the embedding model
    if rows_per_chunk is None:
        smart_chunk, smart_write = _calculate_smart_defaults()
        encode_rows_per_chunk = smart_chunk
    else:
        encode_rows_per_chunk = int(rows_per_chunk)
        smart_write = None

    # Accumulation target for Parquet writes (reduce write overhead)
    if write_rows_per_group is None:
        if smart_write is None:
            smart_write = _calculate_smart_defaults()[1]
        write_group_target = smart_write
    else:
        write_group_target = int(write_rows_per_group)

    # Page size for DuckDB fetch (make larger to reduce disk I/O)
    page_rows = min(encode_rows_per_chunk * 2, 100000)

    # Log the settings being used
    logger.info(f"Embedding settings: rows_per_chunk={encode_rows_per_chunk:,}, write_rows_per_group={write_group_target:,}, page_rows={page_rows:,}")

    to_process = int(total_rows or 0)
    if to_process == 0:
        # Fallback: if count failed for some reason, process in pages until empty
        to_process = 1 << 60  # effectively unlimited; loop will break on empty fetch

    offset = 0
    while offset < to_process:
        page_limit = page_rows if (total_rows is None) else min(page_rows, to_process - offset)
        page_query = base_query_core + f" ORDER BY rid LIMIT {page_limit} OFFSET {offset}"
        try:
            batch_df = engine.conn.execute(page_query).fetchdf()
        except Exception as e:
            # Stop on query errors
            break

        if batch_df is None or len(batch_df) == 0:
            break

        batch_rids = batch_df["rid"].astype("int64").to_numpy()
        batch_texts = batch_df["text_to_embed"].astype(str).tolist()

        # In-memory accumulation buffers to write larger row groups
        buf_rids: list[int] = []
        buf_vecs: list[np.ndarray] = []

        # Process this DataFrame in smaller micro-chunks to avoid large memory spikes
        n = len(batch_texts)
        start = 0
        while start < n:
            end = min(start + encode_rows_per_chunk, n)
            micro_texts = batch_texts[start:end]
            micro_rids = batch_rids[start:end]

            # Compute embeddings for this micro-batch
            try:
                micro_embeddings = embedding_provider.embed(micro_texts, batch_size=batch_size)
            except TypeError:
                micro_embeddings = embedding_provider.embed(micro_texts)

            if micro_embeddings is None or len(micro_embeddings) == 0:
                if pbar is not None:
                    try:
                        pbar.update(len(micro_rids))
                    except Exception:
                        pass
                start = end
                continue

            # Accumulate and flush in larger row groups
            buf_rids.extend([int(x) for x in micro_rids])
            if isinstance(micro_embeddings, np.ndarray):
                buf_vecs.append(micro_embeddings.astype(np.float32, copy=False))
            else:
                buf_vecs.append(np.asarray(micro_embeddings, dtype=np.float32))

            def _flush_buffer():
                nonlocal writer, rows_written, buf_rids, buf_vecs
                if not buf_rids:
                    return
                mat = np.vstack(buf_vecs).astype(np.float32, copy=False)
                flat_values = mat.ravel()
                vectors_array = pa.FixedSizeListArray.from_arrays(
                    pa.array(flat_values, type=pa.float32()), list_size=actual_dimension
                )
                table = pa.table({"rid": pa.array(np.array(buf_rids, dtype=np.int64)), "vector": vectors_array})
                if writer is None:
                    writer = pq.ParquetWriter(vectors_path, table.schema, compression='snappy')
                writer.write_table(table)
                rows_written += len(buf_rids)
                # reset buffers
                buf_rids = []
                buf_vecs = []

            if len(buf_rids) >= write_group_target:
                _flush_buffer()

            # Update progress
            if pbar is not None:
                try:
                    pbar.update(len(micro_rids))
                except Exception:
                    pass

            start = end

        # Flush remaining buffered rows for this page
        if buf_rids:
            # function defined above in scope, re-create to avoid mypy issues
            mat = np.vstack(buf_vecs).astype(np.float32, copy=False)
            flat_values = mat.ravel()
            vectors_array = pa.FixedSizeListArray.from_arrays(
                pa.array(flat_values, type=pa.float32()), list_size=actual_dimension
            )
            table = pa.table({"rid": pa.array(np.array(buf_rids, dtype=np.int64)), "vector": vectors_array})
            if writer is None:
                writer = pq.ParquetWriter(vectors_path, table.schema, compression='snappy')
            writer.write_table(table)
            rows_written += len(buf_rids)
            buf_rids = []
            buf_vecs = []

        # Advance to next page
        offset += len(batch_df)

    if writer is not None:
        writer.close()

    if pbar is not None:
        try:
            pbar.close()
        except Exception:
            pass

    # Handle empty dataset case: create empty vectors file with correct schema
    if rows_written == 0:
        vector_type = pa.list_(pa.float32(), actual_dimension)
        schema = pa.schema([("rid", pa.int64()), ("vector", vector_type)])
        empty_table = pa.table(
            {"rid": pa.array([], type=pa.int64()), "vector": pa.array([], type=vector_type)}
        )
        pq.write_table(empty_table, vectors_path)

    # Optionally create FAISS index for fast search (only if we have data)
    if rows_written > 0:
        # Heuristic: skip index creation for very large spaces to avoid OOM
        build_index = True
        if total_rows is not None:
            # Rough memory estimate: rows * dim * 4 bytes
            estimated_bytes = int(total_rows) * actual_dimension * 4
            # Skip index if estimated vector matrix > ~2GB
            if estimated_bytes > 2 * (1024**3):
                build_index = False

        if build_index:
            index_path = embeddings_dir / "index.faiss"
            try:
                import faiss

                # Load vectors back in a single Arrow table (safe for moderate sizes)
                vectors_table = pq.read_table(vectors_path, columns=["vector"])
                arr = vectors_table["vector"].combine_chunks()
                flat = arr.values.to_numpy()
                embeddings_array = flat.reshape(-1, actual_dimension).astype(np.float32)

                # Create FAISS index
                if distance_metric == "cosine":
                    # For cosine similarity, normalize vectors and use inner product
                    normalized = embeddings_array / (
                        np.linalg.norm(embeddings_array, axis=1, keepdims=True) + 1e-8
                    )
                    index = faiss.IndexFlatIP(actual_dimension)
                    index.add(normalized.astype(np.float32))
                else:
                    # For L2 distance
                    index = faiss.IndexFlatL2(actual_dimension)
                    index.add(embeddings_array.astype(np.float32))

                faiss.write_index(index, str(index_path))
            except ImportError:
                # FAISS not available, skip index creation
                pass

    # Register embedding space in registry
    registry.register_embedding_space(
        workspace=workspace,
        name=name,
        version_hash=version_hash,
        space_name=space,
        provider=provider,
        model=resolved_model or (model or "default"),
        dimension=actual_dimension,
        distance_metric=distance_metric,
        storage_path=str(embeddings_dir),
    )

    return embeddings_dir


def search_embeddings(
    dataset_id: str,
    space: str,
    query: Union[str, List[float]],
    top_k: int = 10,
    distance_metric: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Search embeddings for similar vectors.

    Args:
        dataset_id: Dataset ID (supports shorthand like 'nlp/reviews')
        space: Embedding space name
        query: Query (text string or vector)
        top_k: Number of results to return
        distance_metric: Distance metric (uses space's metric if not specified)

    Returns:
        List of search results with 'rid', 'score', and 'distance'

    Examples:
        >>> import warpdata as wd
        >>> results = wd.search_embeddings(
        ...     "nlp/reviews",  # Shorthand also works
        ...     space="openai-ada",
        ...     query="Great product, highly recommend!",
        ...     top_k=5
        ... )
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    # Get embedding space info
    registry = get_registry()
    dataset_ver = registry.get_dataset_version(workspace, name, version)

    if dataset_ver is None:
        raise ValueError(f"Dataset not found: {dataset_id}")

    version_hash = dataset_ver["version_hash"]

    # Get embedding space
    spaces = registry.list_embedding_spaces(workspace, name, version_hash)
    space_info = next((s for s in spaces if s["space_name"] == space), None)

    if space_info is None:
        raise ValueError(f"Embedding space '{space}' not found for dataset {dataset_id}")

    # If query is a string, embed it
    if isinstance(query, str):
        provider = get_provider(
            provider=space_info["provider"],
            model=space_info["model"],
            dimension=space_info["dimension"],
        )
        query_vector = provider.embed([query])[0]
    else:
        query_vector = np.array(query)

    # Validate query vector dimension
    expected_dim = space_info["dimension"]
    if query_vector.shape[0] != expected_dim:
        raise ValueError(
            f"Query vector dimension mismatch: expected {expected_dim}, "
            f"got {query_vector.shape[0]} for embedding space '{space}'"
        )

    # Use provided distance metric or fall back to space's metric
    metric = distance_metric or space_info["distance_metric"]

    # Load embeddings
    storage_path = Path(space_info["storage_path"])
    vectors_path = storage_path / "vectors.parquet"
    index_path = storage_path / "index.faiss"

    # Load vectors
    vectors_table = pq.read_table(vectors_path)
    rids = vectors_table["rid"].to_pylist()
    vectors = np.array(vectors_table["vector"].to_pylist(), dtype=np.float32)

    # Try to use FAISS index if available
    # Note: Skip FAISS if metric override differs from index's metric
    use_faiss = index_path.exists() and metric == space_info["distance_metric"]

    if use_faiss:
        try:
            import faiss

            index = faiss.read_index(str(index_path))

            # Normalize query for cosine similarity
            if metric == "cosine":
                query_norm = query_vector / (np.linalg.norm(query_vector) + 1e-8)
                query_to_search = query_norm
            else:
                query_to_search = query_vector

            # Search
            faiss_scores, indices = index.search(
                query_to_search.astype(np.float32).reshape(1, -1), top_k
            )

            # Build results with normalized distances
            results = []
            for idx, faiss_score in zip(indices[0], faiss_scores[0]):
                if idx < len(rids):  # Valid index
                    # Convert FAISS scores to distances for consistency
                    if metric == "cosine":
                        # FAISS IndexFlatIP returns inner product (similarity)
                        # Convert to distance: 1 - inner_product
                        distance = 1.0 - float(faiss_score)
                    else:
                        # For L2, FAISS returns squared Euclidean distance
                        # Take sqrt to match numpy fallback behavior
                        distance = float(faiss_score) ** 0.5

                    results.append({
                        "rid": int(rids[idx]),
                        "distance": distance,
                        "score": float(1 / (1 + distance))
                    })

            return results

        except ImportError:
            pass

    # Fallback: brute force search with numpy
    if metric == "cosine":
        # Cosine similarity
        query_norm = query_vector / (np.linalg.norm(query_vector) + 1e-8)
        vectors_norm = vectors / (np.linalg.norm(vectors, axis=1, keepdims=True) + 1e-8)
        similarities = np.dot(vectors_norm, query_norm)
        # Convert to distances (1 - similarity)
        distances_array = 1 - similarities
    else:
        # Euclidean distance
        distances_array = np.linalg.norm(vectors - query_vector, axis=1)

    # Get top k
    top_indices = np.argsort(distances_array)[:top_k]

    results = []
    for idx in top_indices:
        results.append(
            {
                "rid": int(rids[idx]),
                "distance": float(distances_array[idx]),
                "score": float(1 / (1 + distances_array[idx])),
            }
        )

    return results


def load_embeddings(
    dataset_id: str,
    *,
    space: str,
    rids: Optional[List[int]] = None,
    as_numpy: bool = True,
    return_rids: bool = False,
) -> Union[np.ndarray, List[List[float]], Tuple[List[int], np.ndarray], Tuple[List[int], List[List[float]]]]:
    """
    Load embedding vectors for a dataset and space.

    Args:
        dataset_id: Dataset ID (e.g., 'warpdata://vision/celeba-attrs' or shorthand 'vision/celeba-attrs')
        space: Embedding space name to load
        rids: Optional list of row IDs to subset and (re)order
        as_numpy: If True, return a NumPy array of shape (N, dim); otherwise a list of lists
        return_rids: If True, return (rids, vectors)

    Returns:
        Vectors as np.ndarray or list of lists. If return_rids=True, also returns the corresponding rid list.
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    registry = get_registry()
    dataset_ver = registry.get_dataset_version(workspace, name, version)
    if dataset_ver is None:
        raise ValueError(
            (
                f"Dataset not found: {dataset_id}.\n"
                f"• Check it exists: warp list | rg '{workspace}/{name}'\n"
                f"• If you meant a shorthand, use full ID: warpdata://{workspace}/{name}"
            )
        )
    version_hash = dataset_ver["version_hash"]

    # Discover embedding space and storage
    spaces = registry.list_embedding_spaces(workspace, name, version_hash)
    wanted = next((s for s in spaces if s.get("space_name") == space), None)
    if not wanted:
        available = ", ".join(sorted(s.get("space_name") for s in spaces)) if spaces else "none"
        raise ValueError(
            (
                f"Embedding space '{space}' not found for {dataset_id}.\n"
                f"• Available spaces: {available}\n"
                f"• Add embeddings: warp embeddings run {workspace}/{name} --space {space}\n"
                f"  or in Python: wd.add_embeddings('{workspace}/{name}', space='{space}', provider='sentence-transformers', source={{'columns':['text']}})"
            )
        )

    storage_path = wanted.get("storage_path")
    if not storage_path:
        raise FileNotFoundError(
            (
                f"Embedding space '{space}' for {dataset_id} is registered without a storage_path.\n"
                f"Recreate the space locally: warp embeddings run {workspace}/{name} --space {space}"
            )
        )

    vectors_path = Path(storage_path) / "vectors.parquet"
    if not vectors_path.exists():
        raise FileNotFoundError(
            (
                f"Missing vectors for {dataset_id} space='{space}'.\n"
                f"Expected file: {vectors_path}\n"
                f"This usually means the embeddings were computed on another machine or the cache was cleared.\n"
                f"Fix: recompute locally → warp embeddings run {workspace}/{name} --space {space}"
            )
        )

    # Use DuckDB for efficient filtering when rids is provided
    if rids is not None and len(rids) > 0:
        # Import DuckDB engine for filtering
        from ..engine.duck import get_engine
        import duckdb

        engine = get_engine()
        # Use parameterized query for safety and efficiency
        query = f"""
        SELECT rid, vector
        FROM read_parquet('{vectors_path}')
        WHERE rid IN (SELECT UNNEST(?))
        ORDER BY ARRAY_POSITION(?, rid)
        """
        # Execute query with parameters
        result = engine.conn.execute(query, [rids, rids]).fetchdf()
        rid_col = result["rid"].tolist()
        vecs_py = result["vector"].tolist()
    else:
        # Load entire file only if no filtering needed
        table = pq.read_table(vectors_path)
        rid_col = table["rid"].to_pylist()
        vecs_py = table["vector"].to_pylist()  # list of lists (or lists of floats)

    if as_numpy:
        arr = np.array(vecs_py, dtype=np.float32)
        if return_rids:
            return list(map(int, rid_col)), arr
        return arr
    else:
        if return_rids:
            return list(map(int, rid_col)), vecs_py  # type: ignore
        return vecs_py  # type: ignore


def join_results(
    dataset_id: str,
    rids: List[int],
    columns: Optional[List[str]] = None,
    as_format: str = "pandas",
) -> Any:
    """
    Join search results back to original dataset data.

    Args:
        dataset_id: Dataset ID (supports shorthand like 'nlp/reviews')
        rids: List of row IDs to retrieve
        columns: Columns to retrieve (all if not specified)
        as_format: Output format ('pandas', 'duckdb', 'polars')

    Returns:
        Data in requested format

    Examples:
        >>> import warpdata as wd
        >>> results = wd.search_embeddings(..., top_k=5)
        >>> rids = [r["rid"] for r in results]
        >>> data = wd.join_results(dataset_id, rids=rids, columns=["text", "label"])
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    # Parse URI and get dataset version
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    registry = get_registry()
    dataset_ver = registry.get_dataset_version(uri.workspace, uri.name, uri.version or "latest")

    if dataset_ver is None:
        raise ValueError(f"Dataset not found: {dataset_id}")

    # Determine path of materialized file without running materialization
    cache = get_cache()
    dataset_cache_dir = cache.get_dataset_cache_dir(
        uri.workspace, uri.name, dataset_ver["version_hash"]
    )
    materialized_path = dataset_cache_dir / "materialized.parquet"

    # Materialize only if file doesn't exist (avoid re-registering to prevent duplicate versions)
    if not materialized_path.exists():
        from .management import materialize
        materialize(dataset_id, output_path=materialized_path, update_registry=False)

    # Load with DuckDB
    from ..engine.duck import get_engine

    engine = get_engine()

    # Handle empty rids list
    if not rids:
        # Return empty result with correct schema
        if columns:
            cols_str = ", ".join(f'"{c}"' for c in columns)
            query = f"SELECT {cols_str} FROM read_parquet('{materialized_path}') LIMIT 0"
        else:
            query = f"SELECT * FROM read_parquet('{materialized_path}') LIMIT 0"
        relation = engine.conn.sql(query)
    else:
        # Use parameterized query with UNNEST for safety
        # DuckDB uses ? placeholders and requires UNNEST for list parameters
        if columns:
            cols_str = ", ".join(f'"{c}"' for c in columns)
            query = f"""
            SELECT {cols_str}
            FROM read_parquet('{materialized_path}')
            WHERE rid IN (SELECT UNNEST(?))
            ORDER BY rid
            """
        else:
            query = f"""
            SELECT *
            FROM read_parquet('{materialized_path}')
            WHERE rid IN (SELECT UNNEST(?))
            ORDER BY rid
            """

        # Execute with parameterized rids
        df = engine.conn.execute(query, [rids]).fetchdf()
        # Convert to DuckDB relation for consistency
        relation = engine.conn.from_df(df)

    # Convert to requested format
    if as_format == "duckdb":
        return relation
    elif as_format == "pandas":
        return engine.to_df(relation, "pandas")
    elif as_format == "polars":
        return engine.to_df(relation, "polars")
    else:
        raise ValueError(f"Unsupported format: {as_format}")


def list_embeddings(dataset_id: str, all_versions: bool = False) -> List[Dict[str, Any]]:
    """
    List all embedding spaces for a dataset.

    Args:
        dataset_id: Dataset ID (supports shorthand like 'nlp/reviews')

    Returns:
        List of embedding space info dictionaries

    Examples:
        >>> import warpdata as wd
        >>> spaces = wd.list_embeddings("nlp/reviews")  # Shorthand works
        >>> for space in spaces:
        ...     print(f"{space['space_name']}: {space['dimension']}d")
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    # Parse URI
    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    # Get dataset version
    registry = get_registry()
    if all_versions:
        # List spaces across all versions
        return registry.list_embedding_spaces_for_dataset(workspace, name)
    else:
        dataset_ver = registry.get_dataset_version(workspace, name, version)
        if dataset_ver is None:
            raise ValueError(f"Dataset not found: {dataset_id}")
        version_hash = dataset_ver["version_hash"]
        return registry.list_embedding_spaces(workspace, name, version_hash)


def remove_embeddings(dataset_id: str, space: str, delete_files: bool = False) -> None:
    """
    Remove an embedding space from a dataset's current version.

    Args:
        dataset_id: Dataset ID (supports shorthand like 'nlp/reviews', optionally pin a version with @hash)
        space: Space name to remove
        delete_files: If True, delete the storage directory on disk
    """
    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    registry = get_registry()
    dataset_ver = registry.get_dataset_version(workspace, name, version)
    if dataset_ver is None:
        raise ValueError(f"Dataset not found: {dataset_id}")
    version_hash = dataset_ver["version_hash"]

    # Fetch storage path before removal
    row = registry.get_embedding_space(workspace, name, version_hash, space)
    storage_path = row.get("storage_path") if row else None

    # Remove from registry
    registry.remove_embedding_space(workspace, name, version_hash, space)

    # Optionally delete files
    if delete_files and storage_path:
        p = Path(storage_path)
        if p.exists():
            import shutil
            shutil.rmtree(p, ignore_errors=True)


def migrate_embeddings_to_latest(
    dataset_id: str,
    move: bool = False,
    copy: bool = False,
) -> List[Dict[str, Any]]:
    """
    Migrate existing embedding spaces from older versions to the latest version
    without recomputation.

    If copy/move are False (default), this will register the existing storage_path
    under the latest version (no disk IO). If move=True, move directories into the
    latest version's embeddings folder and re-register; if copy=True, copy instead.

    Args:
        dataset_id: Dataset ID (supports shorthand like 'nlp/reviews')
        move: If True, move embedding directories to latest version
        copy: If True, copy embedding directories to latest version

    Returns a list of dicts describing migrated spaces.
    """
    if move and copy:
        raise ValueError("Specify only one of move or copy")

    # Resolve dataset ID (handles shorthand forms)
    from ..core.uris import resolve_dataset_id
    dataset_id = resolve_dataset_id(dataset_id)

    uri = parse_uri(dataset_id)
    if not uri.is_warpdata:
        raise ValueError(f"Invalid dataset ID: {dataset_id}")

    workspace = uri.workspace
    name = uri.name
    version = uri.version or "latest"

    registry = get_registry()
    latest = registry.get_dataset_version(workspace, name, version)
    if latest is None:
        raise ValueError(f"Dataset not found: {dataset_id}")
    latest_hash = latest["version_hash"]

    # Spaces on latest
    latest_spaces = {s["space_name"]: s for s in registry.list_embedding_spaces(workspace, name, latest_hash)}

    # Spaces across all versions
    all_spaces = registry.list_embedding_spaces_for_dataset(workspace, name)

    cache = get_cache()
    latest_dir = cache.get_dataset_cache_dir(workspace, name, latest_hash) / "embeddings"
    latest_dir.mkdir(parents=True, exist_ok=True)

    migrated = []
    for row in all_spaces:
        vh = row["version_hash"]
        space = row["space_name"]
        if vh == latest_hash:
            continue  # already on latest
        if space in latest_spaces:
            continue  # already exists on latest with same space name

        src_path = Path(row["storage_path"]).resolve()
        dst_path = src_path
        if move or copy:
            dst_path = latest_dir / space
            # Avoid overwriting
            if dst_path.exists():
                # pick a unique suffix
                i = 1
                while (latest_dir / f"{space}-{i}").exists():
                    i += 1
                dst_path = latest_dir / f"{space}-{i}"
            dst_path.parent.mkdir(parents=True, exist_ok=True)
            import shutil
            if copy:
                shutil.copytree(src_path, dst_path)
            else:
                shutil.move(str(src_path), str(dst_path))

        # Register under latest
        registry.register_embedding_space(
            workspace=workspace,
            name=name,
            version_hash=latest_hash,
            space_name=space,
            provider=row["provider"],
            model=row["model"],
            dimension=row["dimension"],
            distance_metric=row["distance_metric"],
            storage_path=str(dst_path),
        )

        # If moved, remove old registry row
        if move:
            registry.remove_embedding_space(workspace, name, vh, space)

        migrated.append({
            "space": space,
            "from_version": vh,
            "to_version": latest_hash,
            "storage_path": str(dst_path),
            "provider": row["provider"],
            "model": row["model"],
        })

    return migrated
