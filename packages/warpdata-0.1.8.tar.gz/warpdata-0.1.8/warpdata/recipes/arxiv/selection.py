"""
Paper selection strategies.

Implements smart paper selection with:
- Per-year quotas
- Category weights for balanced distribution
- Deduplication
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from tqdm import tqdm

from .api import ArxivAPI, ArxivPaper

# Default category weights (sum to ~1.0)
# Broad coverage across all major arXiv domains
DEFAULT_CATEGORY_WEIGHTS: dict[str, float] = {
    # === COMPUTER SCIENCE (45%) ===
    # Core ML/AI
    "cs.LG": 0.10,   # Machine Learning
    "cs.AI": 0.05,   # Artificial Intelligence
    "cs.NE": 0.03,   # Neural and Evolutionary Computing
    # NLP & Language
    "cs.CL": 0.08,   # Computation and Language
    "cs.IR": 0.02,   # Information Retrieval
    "cs.SD": 0.01,   # Sound
    # Vision & Graphics
    "cs.CV": 0.08,   # Computer Vision
    "cs.GR": 0.01,   # Graphics
    "cs.MM": 0.01,   # Multimedia
    # Systems & Infrastructure
    "cs.RO": 0.02,   # Robotics
    "cs.SY": 0.01,   # Systems and Control
    "cs.DC": 0.01,   # Distributed Computing
    "cs.NI": 0.01,   # Networking
    "cs.PF": 0.005,  # Performance
    "cs.OS": 0.005,  # Operating Systems
    # Theory & Algorithms
    "cs.DS": 0.01,   # Data Structures and Algorithms
    "cs.CC": 0.005,  # Computational Complexity
    "cs.LO": 0.005,  # Logic
    "cs.GT": 0.005,  # Game Theory
    # Security & Info
    "cs.CR": 0.02,   # Cryptography
    "cs.IT": 0.01,   # Information Theory
    # Software & HCI
    "cs.SE": 0.01,   # Software Engineering
    "cs.PL": 0.01,   # Programming Languages
    "cs.HC": 0.01,   # Human-Computer Interaction
    "cs.DB": 0.005,  # Databases
    "cs.SI": 0.005,  # Social Networks

    # === STATISTICS (10%) ===
    "stat.ML": 0.05,  # Machine Learning
    "stat.ME": 0.02,  # Methodology
    "stat.TH": 0.01,  # Theory
    "stat.AP": 0.01,  # Applications
    "stat.CO": 0.01,  # Computation

    # === MATHEMATICS (12%) ===
    "math.OC": 0.03,  # Optimization and Control
    "math.ST": 0.02,  # Statistics Theory
    "math.PR": 0.02,  # Probability
    "math.NA": 0.02,  # Numerical Analysis
    "math.CO": 0.01,  # Combinatorics
    "math.IT": 0.01,  # Information Theory
    "math.DS": 0.005, # Dynamical Systems
    "math.MP": 0.005, # Mathematical Physics

    # === PHYSICS (12%) ===
    "physics.comp-ph": 0.02,  # Computational Physics
    "physics.data-an": 0.02,  # Data Analysis
    "physics.bio-ph": 0.01,   # Biological Physics
    "physics.chem-ph": 0.01,  # Chemical Physics
    "physics.flu-dyn": 0.005, # Fluid Dynamics
    "physics.optics": 0.005,  # Optics
    "physics.soc-ph": 0.005,  # Physics and Society
    "physics.app-ph": 0.005,  # Applied Physics
    # Condensed Matter
    "cond-mat.stat-mech": 0.01,   # Statistical Mechanics
    "cond-mat.dis-nn": 0.01,      # Disordered Systems & Neural Networks
    "cond-mat.soft": 0.005,       # Soft Matter
    # Quantum & HEP
    "quant-ph": 0.01,    # Quantum Physics
    "hep-ph": 0.005,     # High Energy Physics - Phenomenology
    "hep-th": 0.005,     # High Energy Physics - Theory

    # === ELECTRICAL ENGINEERING (5%) ===
    "eess.SP": 0.015,  # Signal Processing
    "eess.AS": 0.01,   # Audio and Speech
    "eess.IV": 0.015,  # Image and Video Processing
    "eess.SY": 0.01,   # Systems and Control

    # === QUANTITATIVE BIOLOGY (6%) ===
    "q-bio.NC": 0.02,  # Neurons and Cognition
    "q-bio.QM": 0.01,  # Quantitative Methods
    "q-bio.GN": 0.01,  # Genomics
    "q-bio.BM": 0.01,  # Biomolecules
    "q-bio.PE": 0.005, # Populations and Evolution
    "q-bio.MN": 0.005, # Molecular Networks

    # === QUANTITATIVE FINANCE (5%) ===
    "q-fin.ST": 0.015, # Statistical Finance
    "q-fin.PM": 0.01,  # Portfolio Management
    "q-fin.CP": 0.01,  # Computational Finance
    "q-fin.RM": 0.005, # Risk Management
    "q-fin.TR": 0.005, # Trading
    "q-fin.MF": 0.005, # Mathematical Finance

    # === ECONOMICS (3%) ===
    "econ.EM": 0.015,  # Econometrics
    "econ.TH": 0.01,   # Theoretical Economics
    "econ.GN": 0.005,  # General Economics

    # === ASTROPHYSICS (2%) ===
    "astro-ph.CO": 0.005,  # Cosmology
    "astro-ph.IM": 0.005,  # Instrumentation and Methods
    "astro-ph.GA": 0.005,  # Galaxies
    "astro-ph.HE": 0.005,  # High Energy
}


@dataclass
class SelectionConfig:
    """Configuration for paper selection."""
    papers_per_year: int = 500
    years: list[int] = None
    category_weights: dict[str, float] = None
    existing_ids: set[str] = None  # IDs to skip (for incremental updates)
    sort_by: str = "submittedDate"  # submittedDate, relevance
    sort_order: str = "descending"

    def __post_init__(self):
        if self.years is None:
            self.years = [2020, 2021, 2022, 2023, 2024]
        if self.category_weights is None:
            self.category_weights = DEFAULT_CATEGORY_WEIGHTS.copy()
        if self.existing_ids is None:
            self.existing_ids = set()


def _normalize_weights(weights: dict[str, float]) -> dict[str, float]:
    """Normalize weights to sum to 1.0."""
    total = sum(weights.values())
    if total == 0:
        return weights
    return {k: v / total for k, v in weights.items()}


def select_papers(
    config: SelectionConfig,
    api: Optional[ArxivAPI] = None,
    progress: bool = True,
) -> list[ArxivPaper]:
    """
    Select papers according to configuration.

    Uses category weights to distribute papers proportionally.
    For each year, fetches papers from each category proportionally to its weight.

    Args:
        config: Selection configuration
        api: ArxivAPI instance (created if not provided)
        progress: Show progress bar

    Returns:
        List of selected papers (deduplicated by arxiv_id)
    """
    if api is None:
        api = ArxivAPI()

    weights = _normalize_weights(config.category_weights)
    all_papers: dict[str, ArxivPaper] = {}  # arxiv_id -> paper (for dedup)

    total_to_fetch = len(config.years) * config.papers_per_year
    desc = f"Fetching papers ({config.papers_per_year}/year × {len(config.years)} years)"

    with tqdm(total=total_to_fetch, desc=desc, disable=not progress) as pbar:
        for year in config.years:
            year_papers: dict[str, ArxivPaper] = {}
            year_target = config.papers_per_year

            # Calculate papers per category for this year
            category_targets = {
                cat: max(1, int(weight * year_target))
                for cat, weight in weights.items()
            }

            for category, target in category_targets.items():
                if len(year_papers) >= year_target:
                    break

                # Fetch more than needed to account for year filtering and duplicates
                # Year filtering is client-side, so we need to fetch more
                fetch_count = min(target * 10, 1000)

                try:
                    papers = api.search(
                        category=category,
                        year=year,
                        max_results=fetch_count,
                        sort_by=config.sort_by,
                        sort_order=config.sort_order,
                    )
                except Exception as e:
                    print(f"Warning: Failed to fetch {category}/{year}: {e}")
                    continue

                if not papers:
                    # Try without year filter and filter client-side
                    try:
                        papers = api.search(
                            category=category,
                            year=None,
                            max_results=fetch_count,
                            sort_by=config.sort_by,
                            sort_order=config.sort_order,
                        )
                        # Filter to target year
                        papers = [p for p in papers if p.year == year]
                    except Exception as e:
                        print(f"Warning: Retry failed for {category}/{year}: {e}")
                        continue

                added = 0
                for paper in papers:
                    # Skip if already have this paper or in existing set
                    if paper.arxiv_id in year_papers:
                        continue
                    if paper.arxiv_id in all_papers:
                        continue
                    if paper.arxiv_id in config.existing_ids:
                        continue

                    year_papers[paper.arxiv_id] = paper
                    added += 1

                    if added >= target or len(year_papers) >= year_target:
                        break

                pbar.update(added)

            # Add year's papers to total
            all_papers.update(year_papers)

    return list(all_papers.values())


def select_papers_simple(
    papers_per_year: int = 500,
    years: Optional[list[int]] = None,
    category_weights: Optional[dict[str, float]] = None,
    existing_ids: Optional[set[str]] = None,
    progress: bool = True,
) -> list[ArxivPaper]:
    """
    Convenience function for paper selection.

    Args:
        papers_per_year: Target papers per year
        years: List of years to fetch (default: 2020-2024)
        category_weights: Category -> weight mapping (default: DEFAULT_CATEGORY_WEIGHTS)
        existing_ids: Set of arxiv_ids to skip
        progress: Show progress bar

    Returns:
        List of selected papers
    """
    config = SelectionConfig(
        papers_per_year=papers_per_year,
        years=years,
        category_weights=category_weights,
        existing_ids=existing_ids,
    )
    return select_papers(config, progress=progress)
