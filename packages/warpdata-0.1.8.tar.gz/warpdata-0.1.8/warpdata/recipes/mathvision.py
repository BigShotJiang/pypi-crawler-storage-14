"""
MathVision dataset recipe.

MathVision is a mathematical reasoning benchmark with visual elements.
Contains math problems paired with images (diagrams, charts, geometric figures).

Source: https://huggingface.co/datasets/MathLLMs/MathVision

Splits:
- testmini: 304 examples
- test: 3,040 examples

Subjects include algebra, geometry, statistics, and more.
"""
from pathlib import Path
from typing import Tuple
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def mathvision(
    ctx: RecipeContext,
    repo_id: str = "MathLLMs/MathVision",
    splits: Tuple[str, ...] = ("testmini", "test"),
) -> RecipeOutput:
    """
    Create MathVision visual mathematical reasoning dataset.

    Downloads MathVision from HuggingFace. Each example contains a math question,
    an image, multiple choice options (if applicable), and detailed solutions.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("testmini", "test")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - id: str - Problem ID
        - question: str - The math question
        - options: list - Multiple choice options (if applicable)
        - image: str - Image path/reference
        - answer: str - Ground truth answer
        - solution: str - Detailed solution
        - level: str - Difficulty level
        - subject: str - Math subject (algebra, geometry, etc.)
        - split: str - testmini/test

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "mathvision",
        ...     "warpdata://math/mathvision",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://math/mathvision", as_format="pandas")
        >>> # Filter by subject
        >>> geometry = df[df['subject'] == 'geometry']
    """
    print(f"Loading MathVision from {repo_id}...")

    # Load all requested splits
    all_records = []

    for split_name in splits:
        print(f"  Loading {split_name} split...")
        ds = load_dataset(repo_id, split=split_name)

        print(f"  Processing {len(ds):,} examples...")

        for example in ds:
            record = {
                'id': str(example.get('id', '')),
                'question': str(example.get('question', '')),
                'options': example.get('options', []),
                'image': str(example.get('image', '')),
                'answer': str(example.get('answer', '')),
                'solution': str(example.get('solution', '')),
                'level': str(example.get('level', '')),
                'subject': str(example.get('subject', '')),
                'split': split_name,
            }

            all_records.append(record)

    print(f"\nTotal examples: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "mathvision.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())

    if 'subject' in df.columns:
        print(f"\nSubject distribution:")
        print(df['subject'].value_counts().to_string())

    if 'level' in df.columns:
        print(f"\nLevel distribution:")
        print(df['level'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_examples': len(df),
            'splits': df['split'].value_counts().to_dict(),
            'subjects': df['subject'].value_counts().to_dict() if 'subject' in df.columns else {},
            'levels': df['level'].value_counts().to_dict() if 'level' in df.columns else {},
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
