"""
GSE92742 - LINCS Phase 1 L1000 Gene Expression Dataset.

Source: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE92742
License: Public Domain (GEO)

The Library of Integrated Network-based Cellular Signatures (LINCS) L1000 dataset
contains gene expression profiles of human cell lines treated with various chemical
perturbations. This is the LINCS Phase 1 (Pilot) dataset with ~1.3 million profiles.

This dataset uses the L1000 assay platform which measures 978 landmark genes that
capture approximately 80% of the information in the genome-wide data.

Dataset details:
- Platform: L1000 (978 landmark genes)
- Samples: ~1.3 million perturbation profiles (Phase 1)
- Cell lines: Multiple human cell lines
- Perturbations: Small molecule compounds
- Phase: LINCS Pilot Phase 1
- Release: March 2017 (final, no further updates except bug fixes)

Examples:
    import warpdata as wd

    # Create the dataset with limited samples (recommended)
    wd.run_recipe('gse92742_lincs', 'warpdata://bio/lincs-phase1', limit_samples=5000)

    # Create with more samples for larger analysis
    wd.run_recipe('gse92742_lincs', 'warpdata://bio/lincs-phase1', limit_samples=50000)

    # Load the dataset
    df = wd.load('warpdata://bio/lincs-phase1', as_format='pandas')

    # Load metadata subdatasets
    samples = wd.load('warpdata://bio/lincs-phase1-samples', as_format='pandas')
    genes = wd.load('warpdata://bio/lincs-phase1-genes', as_format='pandas')
"""
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput, SubDataset


def gse92742_lincs(ctx: RecipeContext, **options) -> RecipeOutput:
    """
    Process GSE92742 LINCS L1000 gene expression dataset (Phase 1).

    The GCTX file is an HDF5 format containing:
    - Expression matrix: genes (rows) x samples (columns)
    - Row metadata: Gene information (gene_id, gene_symbol, etc.)
    - Column metadata: Sample information (cell_id, pert_id, pert_type, etc.)

    Args:
        ctx: Recipe context with download, storage, and DuckDB engine
        **options: Additional options
            - limit_samples: Optional[int] - Limit number of samples to process
            - limit_genes: Optional[int] - Limit number of genes to process
            - gctx_path: Optional[str] - Custom path to GCTX file

    Returns:
        RecipeOutput with main expression dataset and metadata subdatasets
    """
    import h5py

    # Extract options
    limit_samples = options.get('limit_samples', None)
    limit_genes = options.get('limit_genes', None)

    # Locate GCTX file
    custom_path = options.get('gctx_path')
    if custom_path:
        gctx_file = Path(custom_path)
    else:
        gctx_file = Path('./recipes_raw_data/GSE92742_LINCS.gctx').resolve()

    if not gctx_file.exists():
        raise FileNotFoundError(
            f"GCTX file not found at {gctx_file}. "
            f"Please download from https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE92742"
        )

    print(f"📂 Loading GCTX file: {gctx_file.name}")
    print(f"   File size: {gctx_file.stat().st_size / 1e9:.2f} GB")

    # Parse GCTX (HDF5) file
    with h5py.File(gctx_file, 'r') as f:
        # GCTX structure: /0/DATA/0/matrix (expression data)
        #                 /0/META/ROW (gene metadata)
        #                 /0/META/COL (sample metadata)

        # Load expression matrix (genes x samples)
        matrix = f['/0/DATA/0/matrix']
        print(f"📊 Expression matrix shape: {matrix.shape[0]:,} genes × {matrix.shape[1]:,} samples")

        # Determine slice ranges
        num_genes, num_samples = matrix.shape

        if limit_genes:
            gene_end = min(limit_genes, num_genes)
        else:
            gene_end = num_genes

        if limit_samples:
            sample_end = min(limit_samples, num_samples)
        else:
            sample_end = num_samples

        print(f"⚙️  Processing: {gene_end:,} genes × {sample_end:,} samples")

        # Note: We'll stream the matrix data in chunks below, not loading it all at once

        # Load row metadata (genes)
        row_meta_group = f['/0/META/ROW']
        gene_meta = {}
        for key in row_meta_group.keys():
            data = row_meta_group[key][:gene_end]
            # Decode bytes to strings if needed
            if data.dtype.kind == 'S' or data.dtype.kind == 'O':
                gene_meta[key] = [x.decode('utf-8') if isinstance(x, bytes) else str(x) for x in data]
            else:
                gene_meta[key] = data.tolist()

        # Load column metadata (samples)
        col_meta_group = f['/0/META/COL']
        sample_meta = {}
        for key in col_meta_group.keys():
            data = col_meta_group[key][:sample_end]
            # Decode bytes to strings if needed
            if data.dtype.kind == 'S' or data.dtype.kind == 'O':
                sample_meta[key] = [x.decode('utf-8') if isinstance(x, bytes) else str(x) for x in data]
            else:
                sample_meta[key] = data.tolist()

        # Create long-format expression dataset by streaming chunks
        # Convert matrix to long format: (sample_idx, gene_idx, expression_value)
        print("🔄 Converting expression matrix to long format (streaming to disk)...")

        # Process in chunks and write to disk immediately to avoid memory issues
        chunk_size = 5000  # Process 5k samples at a time
        chunk_files = []
        total_records = 0

        for start_sample in range(0, sample_end, chunk_size):
            end_sample = min(start_sample + chunk_size, sample_end)

            # Load ONLY this chunk of expression data from HDF5
            chunk_data = matrix[:gene_end, start_sample:end_sample]

            # Create records for this chunk
            chunk_records = []
            for local_sample_idx, sample_idx in enumerate(range(start_sample, end_sample)):
                for gene_idx in range(gene_end):
                    value = float(chunk_data[gene_idx, local_sample_idx])
                    # Skip storing zeros or very low values to reduce dataset size
                    if abs(value) > 0.001:  # Threshold to filter noise
                        chunk_records.append({
                            'sample_idx': sample_idx,
                            'gene_idx': gene_idx,
                            'expression': value
                        })

            # Write chunk directly to disk
            if chunk_records:
                chunk_df = pd.DataFrame(chunk_records)
                chunk_file = ctx.work_dir / f'expr_chunk_{len(chunk_files):04d}.parquet'
                chunk_df.to_parquet(chunk_file, index=False)
                chunk_files.append(chunk_file)
                total_records += len(chunk_records)

            # Progress update
            print(f"   Processed {end_sample:,} / {sample_end:,} samples ({total_records:,} non-zero entries, {len(chunk_files)} chunks)")

        print(f"✅ Created {total_records:,} expression records in {len(chunk_files)} chunk files")

        # Use DuckDB to concatenate chunks efficiently without loading all into memory
        print("🔗 Concatenating chunks using DuckDB...")
        from warpdata.engine.duck import get_engine
        engine = get_engine()

        # Create a pattern for all chunk files
        chunk_pattern = str(ctx.work_dir / 'expr_chunk_*.parquet')

        # Load combined data directly from DuckDB to get stats, then immediately write final parquet
        # This avoids loading ALL data into pandas memory at once
        print(f"   Computing statistics...")

        # Get row count and stats from DuckDB
        stats_result = engine.conn.execute(f"""
            SELECT
                COUNT(*) as total_measurements,
                AVG(expression) as mean_expression,
                MEDIAN(expression) as median_expression,
                STDDEV(expression) as std_expression,
                MIN(expression) as min_expression,
                MAX(expression) as max_expression
            FROM read_parquet('{chunk_pattern}')
        """).fetchone()

        expr_stats = {
            'total_measurements': int(stats_result[0]),
            'mean_expression': float(stats_result[1]),
            'median_expression': float(stats_result[2]),
            'std_expression': float(stats_result[3]),
            'min_expression': float(stats_result[4]),
            'max_expression': float(stats_result[5]),
        }

        print(f"📈 Expression statistics:")
        print(f"   Total records: {expr_stats['total_measurements']:,}")
        print(f"   Mean: {expr_stats['mean_expression']:.3f}")
        print(f"   Median: {expr_stats['median_expression']:.3f}")
        print(f"   Std: {expr_stats['std_expression']:.3f}")
        print(f"   Range: [{expr_stats['min_expression']:.3f}, {expr_stats['max_expression']:.3f}]")

        # Write final parquet directly from DuckDB
        main_path = ctx.work_dir / 'expression.parquet'
        print(f"   Writing final parquet...")
        engine.conn.execute(f"""
            COPY (
                SELECT * FROM read_parquet('{chunk_pattern}')
            ) TO '{main_path}' (FORMAT PARQUET)
        """)

        # Clean up chunk files
        for f in chunk_files:
            f.unlink()

        # Skip loading expr_df into memory - we don't need it anymore

    print("✅ GCTX file processed successfully")

    # Create gene metadata subdataset
    gene_df = pd.DataFrame(gene_meta)
    gene_df['gene_idx'] = range(len(gene_df))

    print(f"🧬 Gene metadata: {len(gene_df):,} genes")
    print(f"   Columns: {list(gene_df.columns)}")

    genes_path = ctx.work_dir / 'genes.parquet'
    ctx.write_parquet(gene_df, genes_path)

    # Create sample metadata subdataset
    sample_df = pd.DataFrame(sample_meta)
    sample_df['sample_idx'] = range(len(sample_df))

    print(f"🔬 Sample metadata: {len(sample_df):,} samples")
    print(f"   Columns: {list(sample_df.columns)}")

    samples_path = ctx.work_dir / 'samples.parquet'
    ctx.write_parquet(sample_df, samples_path)

    # expr_stats and main_path were already created above in the HDF5 processing section

    # Generate documentation
    readme = f"""
# GSE92742 - LINCS Phase 1 L1000 Gene Expression Dataset

## Description

The Library of Integrated Network-based Cellular Signatures (LINCS) L1000 dataset
contains gene expression profiles of human cell lines treated with various chemical
perturbations. This is Level 2 data (quantile-normalized expression values).

## Source

- **GEO Accession**: GSE92742
- **URL**: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE92742
- **Platform**: L1000 (978 landmark genes)
- **Phase**: LINCS Pilot Phase 1
- **Release**: March 2017 (final release)
- **License**: Public Domain

## Dataset Statistics

- **Genes**: {gene_end:,} ({len(gene_df.columns)} metadata fields)
- **Samples**: {sample_end:,} ({len(sample_df.columns)} metadata fields)
- **Expression records**: {len(expr_df):,} (non-zero values with |value| > 0.001)
- **Expression range**: [{expr_stats['min_expression']:.3f}, {expr_stats['max_expression']:.3f}]
- **Mean expression**: {expr_stats['mean_expression']:.3f}

## Schema

### Main Dataset (expression)
- `sample_idx` (int64): Sample index (joins to samples subdataset)
- `gene_idx` (int64): Gene index (joins to genes subdataset)
- `expression` (float64): Quantile-normalized expression value

### Genes Subdataset
- `gene_idx` (int64): Gene index
- Gene metadata fields (vary by GCTX file, typically include gene_id, gene_symbol)

### Samples Subdataset
- `sample_idx` (int64): Sample index
- Sample metadata fields (vary by GCTX file, typically include cell_id, pert_id, pert_type, pert_dose, pert_time, etc.)

## Usage

```python
import warpdata as wd

# Load expression data (long format)
expr = wd.load('warpdata://bio/lincs-phase1', as_format='pandas')

# Load metadata
genes = wd.load('warpdata://bio/lincs-phase1-genes', as_format='pandas')
samples = wd.load('warpdata://bio/lincs-phase1-samples', as_format='pandas')

# Join to get full information
from warpdata.engine.duck import get_engine
engine = get_engine()

result = engine.conn.sql(\"\"\"
    SELECT
        e.expression,
        g.*,
        s.*
    FROM 'warpdata://bio/lincs-phase1' e
    JOIN 'warpdata://bio/lincs-phase1-genes' g ON e.gene_idx = g.gene_idx
    JOIN 'warpdata://bio/lincs-phase1-samples' s ON e.sample_idx = s.sample_idx
    WHERE e.expression > 5.0
    LIMIT 100
\"\"\").df()

# Get expression for specific gene across all samples
gene_expr = engine.conn.sql(\"\"\"
    SELECT
        s.sample_idx,
        e.expression
    FROM 'warpdata://bio/lincs-phase1' e
    JOIN 'warpdata://bio/lincs-phase1-genes' g ON e.gene_idx = g.gene_idx
    JOIN 'warpdata://bio/lincs-phase1-samples' s ON e.sample_idx = s.sample_idx
    WHERE g.id = 'your_gene_id'
\"\"\").df()
```

## References

1. Subramanian et al. (2017) "A Next Generation Connectivity Map: L1000 Platform and the First 1,000,000 Profiles"
   Cell 171(6): 1437-1452. https://doi.org/10.1016/j.cell.2017.10.049

2. LINCS Project: https://lincsproject.org/

## Notes

- Data is stored in long format (sparse representation) to optimize storage
- Only non-zero expression values with |value| > 0.001 are stored
- Use DuckDB joins to combine expression data with gene/sample metadata
- L1000 measures 978 "landmark" genes that capture ~80% of genome-wide information
"""

    ctx.write_documentation('README.md', readme.strip())

    # Return output with subdatasets
    return RecipeOutput(
        main=[main_path],
        subdatasets={
            'genes': SubDataset(
                name='lincs-phase1-genes',
                files=[genes_path],
                description='Gene metadata for L1000 landmark genes'
            ),
            'samples': SubDataset(
                name='lincs-phase1-samples',
                files=[samples_path],
                description='Sample metadata including cell line, perturbation, dose, and time information'
            )
        },
        metadata={
            'source': 'GEO GSE92742',
            'license': 'Public Domain',
            'platform': 'L1000',
            'phase': 'LINCS Pilot Phase 1',
            'level': 'Level 2 (quantile-normalized)',
            'num_genes': gene_end,
            'num_samples': sample_end,
            'num_expression_records': expr_stats['total_measurements'],
            **expr_stats
        }
    )
