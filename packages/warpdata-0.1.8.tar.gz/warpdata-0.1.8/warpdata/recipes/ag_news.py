"""
AG News dataset recipe.

AG News is a news classification dataset with 4 categories.

Source: https://huggingface.co/datasets/ag_news
Paper: https://arxiv.org/abs/1509.01626

Splits:
- train: 120,000 articles
- test: 7,600 articles

Categories:
- 0: World
- 1: Sports
- 2: Business
- 3: Sci/Tech
"""
from pathlib import Path
from typing import Tuple
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def ag_news(
    ctx: RecipeContext,
    repo_id: str = "ag_news",
    splits: Tuple[str, ...] = ("train", "test"),
) -> RecipeOutput:
    """
    Create AG News text classification dataset.

    Downloads AG News from HuggingFace. Each article has a title + description
    and a category label (World/Sports/Business/Sci-Tech).

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        splits: Which splits to include ("train", "test")

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - text: str - Article text (title + description)
        - label: int - Category (0=World, 1=Sports, 2=Business, 3=Sci/Tech)
        - label_name: str - Category name
        - split: str - train/test

    Examples:
        >>> import warpdata as wd
        >>> result = wd.run_recipe(
        ...     "ag_news",
        ...     "warpdata://nlp/ag-news",
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://nlp/ag-news", as_format="pandas")
        >>> # Filter by category
        >>> business = df[df['label'] == 2]
    """
    from datasets import load_dataset

    print(f"Loading AG News from {repo_id}...")

    # Label names
    label_names = ['World', 'Sports', 'Business', 'Sci/Tech']

    # Load all requested splits
    all_records = []

    for split_name in splits:
        print(f"  Loading {split_name} split...")
        ds = load_dataset(repo_id, split=split_name)

        print(f"  Processing {len(ds):,} articles...")

        for example in ds:
            record = {
                'text': str(example['text']),
                'label': int(example['label']),
                'label_name': label_names[example['label']],
                'split': split_name,
            }

            all_records.append(record)

    print(f"\nTotal articles: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "ag_news.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")
    print(f"\nSplit distribution:")
    print(df['split'].value_counts().to_string())
    print(f"\nCategory distribution:")
    print(df['label_name'].value_counts().to_string())

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_articles': len(df),
            'splits': df['split'].value_counts().to_dict(),
            'categories': df['label_name'].value_counts().to_dict(),
            'source': repo_id,
        },
        raw_data=raw_data_paths,
    )
