"""
ArXiv Complete Pipeline Recipe.

Orchestrates full ArXiv ETL pipeline:
1. Scan local PDFs (manifest)
2. Load metadata from SQLite
3. Join and stage (only papers with both)
4. Extract text (fast methods)
5. Optional: Add embeddings (google/gemma-300m)

Fully idempotent: re-running only processes new papers.
"""
from __future__ import annotations
from typing import Optional

from ..api.recipes import RecipeContext, run_recipe
from ..recipes.base import RecipeOutput, EmbeddingConfig
import warpdata as wd


def arxiv(
    ctx: RecipeContext,
    local_pdf_dir: str = "./recipes_raw_data/arxiv_pdfs",
    db_path: str = "./recipes_raw_data/arxiv_papers.db",
    table: str = "papers",
    limit: Optional[int] = None,
    min_date: Optional[str] = None,  # e.g., "2024-01-01"
    pdf_method: str = "fast",
    max_pages: Optional[int] = None,
    add_embeddings: bool = True,
    embeddings_model: str = "google/embeddinggemma-300m",
) -> RecipeOutput:
    """
    Complete ArXiv ETL pipeline with embeddings.

    Runs 4 sub-recipes in sequence:
    1. arxiv_pdf_manifest: Scan local PDFs, compute SHA1 fingerprints
    2. arxiv_metadata_sqlite: Extract metadata from SQLite
    3. arxiv_stage_join: Join manifest + metadata, skip already-processed
    4. arxiv_extract_text: Extract text from staged PDFs

    Then optionally adds embeddings for abstract/content/title.

    Args:
        ctx: Recipe context
        local_pdf_dir: Directory containing PDFs (default: ./recipes_raw_data/arxiv_pdfs)
        db_path: SQLite database path (default: ./recipes_raw_data/arxiv_papers.db)
        table: Table name in database (default: "papers")
        limit: Optional row limit for testing
        pdf_method: Extraction method ("fast" only)
        max_pages: Optional page limit for extraction
        add_embeddings: If True, create 3 embedding spaces
        embeddings_model: Model for embeddings (default: google/embeddinggemma-300m)

    Returns:
        RecipeOutput with final text dataset and optional embeddings

    Example:
        >>> import warpdata as wd
        >>> # Full pipeline with embeddings
        >>> wd.run_recipe(
        ...     "arxiv",
        ...     "warpdata://arxiv/papers",
        ...     add_embeddings=True,
        ...     with_materialize=True,
        ... )
        >>> # Search by abstract
        >>> results = wd.search_embeddings(
        ...     "warpdata://arxiv/papers",
        ...     space="abstract-gemma-300m",
        ...     query="neural networks for theorem proving",
        ...     top_k=10,
        ... )
    """
    print("=" * 80)
    print("ArXiv Complete Pipeline")
    print("=" * 80)

    # Step 1: PDF Manifest
    print("\n[1/4] Creating PDF manifest...")
    manifest_id = f"warpdata://arxiv/pdf-manifest-{ctx.uri.name}"
    run_recipe(
        "arxiv_pdf_manifest",
        manifest_id,
        local_pdf_dir=local_pdf_dir,
    )
    # Load manifest to get stats
    manifest_df = wd.load(manifest_id, as_format="pandas")
    print(f"✅ Manifest created: {len(manifest_df)} PDFs")

    # Step 2: Metadata
    print("\n[2/4] Loading metadata from SQLite...")
    metadata_id = f"warpdata://arxiv/metadata-{ctx.uri.name}"
    run_recipe(
        "arxiv_metadata_sqlite",
        metadata_id,
        db_path=db_path,
        table=table,
        limit=limit,
        min_date=min_date,
    )
    # Load metadata to get stats
    metadata_df = wd.load(metadata_id, as_format="pandas")
    print(f"✅ Metadata loaded: {len(metadata_df)} papers")

    # Step 3: Stage Join (with dedup check)
    print("\n[3/4] Staging papers (join + dedup)...")
    staged_id = f"warpdata://arxiv/staged-{ctx.uri.name}"

    # Check if we already have text dataset (for incremental runs)
    existing_text_id = None
    try:
        # Try to load existing text dataset to skip already-processed papers
        existing_text_id = str(ctx.uri)
        wd.load(existing_text_id, as_format="pandas", limit=1)
        print(f"   Found existing text dataset: {existing_text_id}")
    except Exception:
        print("   No existing text dataset found (first run)")

    run_recipe(
        "arxiv_stage_join",
        staged_id,
        manifest_id=manifest_id,
        metadata_id=metadata_id,
        existing_text_id=existing_text_id,
    )
    # Load staged to get stats
    staged_df = wd.load(staged_id, as_format="pandas")
    total_staged = len(staged_df)
    # Estimate skipped (total with PDF - staged)
    skipped = len(manifest_df) - total_staged
    print(f"✅ Staged: {total_staged} papers (skipped ~{skipped} already-processed or no metadata)")

    if total_staged == 0:
        print("\n⚠️  No new papers to process. Pipeline complete.")
        print(f"   Existing dataset: {ctx.uri}")
        # Load existing dataset and re-write to work_dir for RecipeOutput
        try:
            existing_df = wd.load(str(ctx.uri), as_format="pandas")
            print(f"   Loaded existing dataset: {len(existing_df)} papers")
        except Exception as e:
            print(f"   Could not load existing dataset: {e}")
            # Create empty with schema
            import pandas as pd
            existing_df = pd.DataFrame({"arxiv_id": []})

        # Write to work_dir
        out_path = ctx.work_dir / "arxiv_papers.parquet"
        final_rel = ctx.engine.conn.from_df(existing_df)
        ctx.write_parquet(final_rel, out_path)

        return RecipeOutput(
            main=[out_path],
            subdatasets={},
            docs={"README.md": "# ArXiv Papers\n\nNo new papers to process.\n"},
            metadata={
                "total_papers": len(existing_df),
                "new_papers": 0,
                "skipped": skipped,
            },
        )

    # Step 4: Extract Text
    print("\n[4/4] Extracting text from PDFs...")
    run_recipe(
        "arxiv_extract_text",
        str(ctx.uri),  # Final output goes to main dataset ID
        staged_id=staged_id,
        pdf_method=pdf_method,
        max_pages=max_pages,
    )
    # Load final dataset to get stats
    final_df = wd.load(str(ctx.uri), as_format="pandas")
    success = final_df["has_full_content"].sum() if "has_full_content" in final_df.columns else 0
    failed = len(final_df) - success
    print(f"✅ Text extraction: {success} success, {failed} failed")

    # Prepare embedding configs
    emb_cfgs = []
    if add_embeddings:
        print(f"\n[5/5] Configuring embeddings with {embeddings_model}...")
        model_short = embeddings_model.split("/")[-1]

        # Abstract embeddings
        emb_cfgs.append(EmbeddingConfig(
            space=f"abstract-{model_short}",
            provider="sentence-transformers",
            model=embeddings_model,
            source={"columns": ["abstract"]},
            distance_metric="cosine",
        ))

        # Content embeddings
        emb_cfgs.append(EmbeddingConfig(
            space=f"content-{model_short}",
            provider="sentence-transformers",
            model=embeddings_model,
            source={"columns": ["full_content"]},
            distance_metric="cosine",
        ))

        # Title embeddings
        emb_cfgs.append(EmbeddingConfig(
            space=f"title-{model_short}",
            provider="sentence-transformers",
            model=embeddings_model,
            source={"columns": ["title"]},
            distance_metric="cosine",
        ))

        print(f"   Configured 3 embedding spaces: abstract, content, title")

    # Generate final documentation
    readme = f"""# ArXiv Papers Dataset

## Overview
Complete ArXiv papers dataset with metadata, full-text content, and embeddings.

## Pipeline Steps
1. **PDF Manifest**: Scanned {len(manifest_df)} local PDFs
2. **Metadata**: Loaded {len(metadata_df)} paper records
3. **Staging**: Matched {total_staged} papers (skipped ~{skipped} already-processed or no metadata)
4. **Text Extraction**: {success} successful, {failed} failed

## Configuration
- **PDF Directory**: {local_pdf_dir}
- **Database**: {db_path}
- **Table**: {table}
- **Extraction Method**: {pdf_method}
- **Max Pages**: {max_pages or "All"}
- **Embeddings**: {"Enabled" if add_embeddings else "Disabled"}
- **Model**: {embeddings_model if add_embeddings else "N/A"}

## Statistics
- **Total papers**: {len(final_df)}
- **Success rate**: {100 * success / len(final_df) if len(final_df) > 0 else 0:.1f}%

## Usage

### Load Dataset
```python
import warpdata as wd

# Load papers
papers = wd.load("{ctx.uri}", as_format="pandas")
print(f"Papers: {{len(papers)}}")

# Filter successful extractions
success = papers[papers["has_full_content"]]
print(f"With text: {{len(success)}}")
```
"""

    if add_embeddings:
        readme += f"""
### Search by Abstract
```python
results = wd.search_embeddings(
    "{ctx.uri}",
    space="abstract-{embeddings_model.split("/")[-1]}",
    query="neural networks for computer vision",
    top_k=10,
)
for row in results:
    print(f"{{row['title']}} (distance: {{row['distance']:.3f}})")
```

### Search by Content
```python
results = wd.search_embeddings(
    "{ctx.uri}",
    space="content-{embeddings_model.split("/")[-1]}",
    query="transformer architecture attention mechanism",
    top_k=10,
)
```

### Available Embedding Spaces
- `abstract-{embeddings_model.split("/")[-1]}`: Search paper abstracts
- `content-{embeddings_model.split("/")[-1]}`: Search full paper content
- `title-{embeddings_model.split("/")[-1]}`: Search paper titles
"""

    readme += """
## Idempotency
This pipeline is fully idempotent:
- PDF manifest tracks files by SHA1 fingerprint
- Stage join skips papers already processed
- Re-running only processes new papers

## Next Steps
```python
# Update with new papers
wd.run_recipe("arxiv", "warpdata://arxiv/papers", with_materialize=True)

# Add custom subdatasets
ml_papers = papers[papers["is_ml_related"]]
wd.register_dataset("warpdata://arxiv/ml-papers", ml_papers)
```
"""

    print("\n" + "=" * 80)
    print("✅ ArXiv Pipeline Complete!")
    print("=" * 80)

    # Get main parquet file from final dataset
    out_path = ctx.work_dir / "arxiv_papers.parquet"
    final_rel = ctx.engine.conn.from_df(final_df)
    ctx.write_parquet(final_rel, out_path)

    # Track raw data for backup/provenance
    raw_data_sources = []
    pdf_path = Path(local_pdf_dir)
    if pdf_path.exists():
        raw_data_sources.append(pdf_path)  # Track PDFs directory (~118GB)
    db_file = Path(db_path)
    if db_file.exists():
        raw_data_sources.append(db_file)  # Track SQLite database (~581MB)

    return RecipeOutput(
        main=[out_path],
        subdatasets={},
        docs={"README.md": readme},
        embeddings=emb_cfgs,
        metadata={
            "local_pdf_dir": local_pdf_dir,
            "db_path": db_path,
            "table": table,
            "pdf_method": pdf_method,
            "add_embeddings": add_embeddings,
            "embeddings_model": embeddings_model,
            "total_pdfs": len(manifest_df),
            "total_metadata": len(metadata_df),
            "total_staged": total_staged,
            "skipped_count": skipped,
            "success_count": int(success),
            "failed_count": int(failed),
            "success_rate": 100 * success / len(final_df) if len(final_df) > 0 else 0,
        },
        raw_data=raw_data_sources,
    )
