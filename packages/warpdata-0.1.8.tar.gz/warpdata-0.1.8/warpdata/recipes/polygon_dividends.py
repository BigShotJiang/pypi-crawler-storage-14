"""
Polygon Dividends dataset recipe.

Fetches historical dividend distributions from Polygon.io.
Includes: cash amounts, ex-dividend dates, pay dates, frequency.

Source: Polygon.io Reference API (/v3/reference/dividends)
"""
from pathlib import Path
from typing import Optional, Dict, Any
import json
import pandas as pd
import sys
import os

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_dividends(
    ctx: RecipeContext,
    *,
    ticker: Optional[str] = None,
    ex_dividend_date: Optional[str] = None,
    ex_dividend_date_gte: Optional[str] = None,
    ex_dividend_date_lte: Optional[str] = None,
    record_date: Optional[str] = None,
    record_date_gte: Optional[str] = None,
    record_date_lte: Optional[str] = None,
    declaration_date: Optional[str] = None,
    pay_date: Optional[str] = None,
    frequency: Optional[int] = None,
    cash_amount: Optional[float] = None,
    cash_amount_gte: Optional[float] = None,
    cash_amount_lte: Optional[float] = None,
    dividend_type: Optional[str] = None,
    order: str = "asc",
    limit: int = 1000,
    sort: str = "ex_dividend_date",
    polygon_api_key: Optional[str] = None,
    raw_data_dir: str = "recipes_raw_data/polygon_dividends",
) -> RecipeOutput:
    """
    Create Polygon Dividends dataset.

    Downloads historical cash dividend distributions.

    Args:
        ctx: Recipe context
        ticker: Filter by ticker symbol (e.g., "AAPL")
        ex_dividend_date: Filter by exact ex-dividend date (YYYY-MM-DD)
        ex_dividend_date_gte: Filter by ex-dividend date >= (YYYY-MM-DD)
        ex_dividend_date_lte: Filter by ex-dividend date <= (YYYY-MM-DD)
        record_date: Filter by exact record date (YYYY-MM-DD)
        record_date_gte: Filter by record date >= (YYYY-MM-DD)
        record_date_lte: Filter by record date <= (YYYY-MM-DD)
        declaration_date: Filter by declaration date (YYYY-MM-DD)
        pay_date: Filter by pay date (YYYY-MM-DD)
        frequency: Filter by frequency (0=one-time, 1=annual, 2=bi-annual, 4=quarterly, 12=monthly, 52=weekly)
        cash_amount: Filter by exact cash amount
        cash_amount_gte: Filter by cash amount >=
        cash_amount_lte: Filter by cash amount <=
        dividend_type: Filter by type (CD=regular cash, SC=special cash, LT=long-term gain, ST=short-term gain)
        order: Sort order (asc or desc, default: asc)
        limit: Maximum number of results (default: 1000)
        sort: Sort field (default: ex_dividend_date)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files

    Returns:
        RecipeOutput with dividend data

    Examples:
        >>> import warpdata as wd
        >>> # Fetch AAPL dividends
        >>> result = wd.run_recipe(
        ...     "polygon_dividends",
        ...     "warpdata://dividends/aapl",
        ...     ticker="AAPL",
        ...     with_materialize=True
        ... )
        >>> # Fetch quarterly dividends from 2020+
        >>> result = wd.run_recipe(
        ...     "polygon_dividends",
        ...     "warpdata://dividends/quarterly",
        ...     frequency=4,
        ...     ex_dividend_date_gte="2020-01-01",
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📊 Fetching Polygon Dividends")
    if ticker:
        print(f"   Ticker: {ticker}")
    if dividend_type:
        print(f"   Type: {dividend_type}")
    if frequency is not None:
        freq_map = {0: "one-time", 1: "annual", 2: "bi-annual", 4: "quarterly", 12: "monthly", 24: "bi-monthly", 52: "weekly"}
        print(f"   Frequency: {freq_map.get(frequency, frequency)}")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    # Prepare filters
    filters: Dict[str, Any] = {
        "order": order,
        "limit": limit,
        "sort": sort,
    }
    if ticker:
        filters["ticker"] = ticker
    if ex_dividend_date:
        filters["ex_dividend_date"] = ex_dividend_date
    if ex_dividend_date_gte:
        filters["ex_dividend_date.gte"] = ex_dividend_date_gte
    if ex_dividend_date_lte:
        filters["ex_dividend_date.lte"] = ex_dividend_date_lte
    if record_date:
        filters["record_date"] = record_date
    if record_date_gte:
        filters["record_date.gte"] = record_date_gte
    if record_date_lte:
        filters["record_date.lte"] = record_date_lte
    if declaration_date:
        filters["declaration_date"] = declaration_date
    if pay_date:
        filters["pay_date"] = pay_date
    if frequency is not None:
        filters["frequency"] = frequency
    if cash_amount is not None:
        filters["cash_amount"] = cash_amount
    if cash_amount_gte is not None:
        filters["cash_amount.gte"] = cash_amount_gte
    if cash_amount_lte is not None:
        filters["cash_amount.lte"] = cash_amount_lte
    if dividend_type:
        filters["dividend_type"] = dividend_type

    # Fetch dividends
    json_file = raw_dir / "dividends.json"
    print(f"\n📈 Fetching dividends...")

    try:
        result = etl.fetch_dividends(out=str(json_file), **filters)
        print(f"  ✓ Fetched {result.get('count', 0):,} dividend records")
    except Exception as e:
        raise RuntimeError(f"Failed to fetch dividends: {e}") from e

    # Load and process data
    if not json_file.exists():
        raise ValueError("No dividend data downloaded")

    with open(json_file) as f:
        data = json.load(f)

    if not isinstance(data, list) or len(data) == 0:
        raise ValueError("No dividend records found")

    # Convert to DataFrame
    df = pd.DataFrame(data)

    print(f"\n📊 Processing {len(df):,} dividend records...")

    # Convert date columns to datetime
    date_columns = ['ex_dividend_date', 'record_date', 'declaration_date', 'pay_date']
    for col in date_columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    # Add frequency labels
    if 'frequency' in df.columns:
        freq_map = {
            0: "one-time",
            1: "annual",
            2: "bi-annual",
            4: "quarterly",
            12: "monthly",
            24: "bi-monthly",
            52: "weekly"
        }
        df['frequency_label'] = df['frequency'].map(freq_map)

    # Add dividend type labels
    if 'dividend_type' in df.columns:
        type_map = {
            'CD': 'cash_dividend',
            'SC': 'special_cash',
            'LT': 'long_term_gain',
            'ST': 'short_term_gain'
        }
        df['dividend_type_label'] = df['dividend_type'].map(type_map)

    # Save to parquet
    output_file = ctx.work_dir / "polygon_dividends.parquet"
    df.to_parquet(output_file, index=False)

    print(f"  ✓ Saved {len(df):,} records to {output_file.name}")

    # Show sample
    print(f"\n  📊 Columns: {list(df.columns)}")
    if len(df) > 0:
        print(f"\n  📋 Sample Dividends:")
        for _, row in df.head(5).iterrows():
            ticker_str = row.get('ticker', 'N/A')
            amount = row.get('cash_amount', 0)
            date = row.get('ex_dividend_date', 'N/A')
            freq = row.get('frequency_label', 'N/A')
            print(f"    {ticker_str}: ${amount:.2f} on {date} ({freq})")

    # Generate documentation
    readme = f"""# Polygon Dividends Dataset

## Overview
Historical cash dividend distributions from Polygon.io

## Configuration
- **Order**: {order}
- **Sort**: {sort}
- **Limit**: {limit:,}
{f"- **Ticker**: {ticker}" if ticker else ""}
{f"- **Dividend Type**: {dividend_type}" if dividend_type else ""}
{f"- **Frequency**: {frequency}" if frequency is not None else ""}

## Statistics
- **Total Dividends**: {len(df):,}
- **Date Range**: {df['ex_dividend_date'].min()} to {df['ex_dividend_date'].max()}
- **Columns**: {len(df.columns)}
{f"- **Average Dividend**: ${df['cash_amount'].mean():.2f}" if 'cash_amount' in df.columns else ""}
{f"- **Total Paid**: ${df['cash_amount'].sum():.2f}" if 'cash_amount' in df.columns else ""}

## Key Fields

### Identification
- `ticker`: Stock ticker symbol
- `id`: Unique identifier for this dividend

### Dates
- `declaration_date`: When dividend was announced
- `ex_dividend_date`: First trading date without dividend (set by exchange)
- `record_date`: Date stock must be held to receive dividend (set by company)
- `pay_date`: Date dividend is actually paid

### Dividend Details
- `cash_amount`: Dividend amount per share
- `currency`: Currency code (e.g., USD)
- `frequency`: Payment frequency
  - 0 = one-time
  - 1 = annual
  - 2 = bi-annual
  - 4 = quarterly
  - 12 = monthly
  - 24 = bi-monthly
  - 52 = weekly
- `frequency_label`: Human-readable frequency
- `dividend_type`: Dividend classification
  - CD = Cash Dividend (regular, expected to continue)
  - SC = Special Cash (infrequent, unusual)
  - LT = Long-Term Capital Gain
  - ST = Short-Term Capital Gain
- `dividend_type_label`: Human-readable type

## Understanding Dividend Dates

### Timeline
1. **Declaration Date**: Company announces dividend
2. **Ex-Dividend Date**: First day stock trades without dividend
   - Must own stock BEFORE this date to receive dividend
3. **Record Date**: Must be shareholder of record on this date
4. **Pay Date**: Dividend is deposited

### Example
- Declaration: Jan 15 (announced)
- Ex-Dividend: Feb 1 (buy before this to get dividend)
- Record: Feb 3 (must be on record)
- Pay: Feb 15 (money received)

## Dividend Types

### Regular Cash Dividend (CD)
Consistent payments expected to continue on regular schedule.
Most common for established companies.

### Special Cash Dividend (SC)
One-time or irregular payments not expected to repeat.
Often from extraordinary events (asset sales, windfalls).

### Capital Gain Distributions (LT/ST)
Typically from mutual funds/REITs passing through gains.
Tax treatment differs from regular dividends.

## Usage

```python
import warpdata as wd
import pandas as pd

# Load dividends data
divs = wd.load("warpdata://dividends/all", as_format="pandas")

# Filter by ticker
aapl_divs = divs[divs['ticker'] == 'AAPL']

# Calculate dividend yield (requires price data)
# yield = (annual_dividend / price) * 100

# Find high-yield dividends
high_yield = divs.groupby('ticker')['cash_amount'].sum().sort_values(ascending=False)

# Recent dividends (last quarter)
recent = divs[divs['ex_dividend_date'] >= pd.Timestamp.now() - pd.Timedelta(days=90)]

# Quarterly dividend payers
quarterly = divs[divs['frequency'] == 4]

# Calculate total return
# total_return = price_gain + dividends

# Dividend growth rate
divs_sorted = divs.sort_values(['ticker', 'ex_dividend_date'])
divs_sorted['dividend_growth'] = divs_sorted.groupby('ticker')['cash_amount'].pct_change()

# Tax planning: separate regular from capital gains
regular = divs[divs['dividend_type'] == 'CD']
cap_gains = divs[divs['dividend_type'].isin(['LT', 'ST'])]
```

## Source
Polygon.io Reference API - /v3/reference/dividends
History: Records date back to January 15, 2000
Updated: Daily
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    metadata = {
        "total_dividends": len(df),
        "columns": list(df.columns),
        "source": "Polygon.io Reference API",
        "endpoint": "/v3/reference/dividends",
        "filters": filters,
    }

    return RecipeOutput(
        main=[output_file],
        subdatasets={},
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
