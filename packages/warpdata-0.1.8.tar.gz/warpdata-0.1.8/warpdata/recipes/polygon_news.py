"""
Polygon News dataset recipe.

Fetches news articles from Polygon.io API with sentiment analysis.
Includes article content, publisher info, associated tickers, and AI-generated insights.

Source: Polygon.io News API
Data types:
- News articles with metadata, sentiment, keywords, and tickers
"""
from pathlib import Path
from typing import List, Optional
import json
import pandas as pd
import sys
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import time

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def polygon_news(
    ctx: RecipeContext,
    *,
    tickers: Optional[List[str]] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 1000,
    polygon_api_key: Optional[str] = None,
    raw_data_dir: Optional[str] = None,
    max_workers: int = 10,
) -> RecipeOutput:
    """
    Create Polygon News dataset.

    Downloads news articles from Polygon.io with sentiment analysis and metadata.

    Args:
        ctx: Recipe context
        tickers: Optional list of tickers to filter news (if None, gets all news)
        start_date: Optional start date filter (YYYY-MM-DD)
        end_date: Optional end date filter (YYYY-MM-DD)
        limit: Max articles per ticker/query (default: 1000, max: 1000 per API docs)
        polygon_api_key: Polygon API key (or set POLYGON_API_KEY env var)
        raw_data_dir: Directory to store raw JSON files
        max_workers: Max parallel downloads (default: 10)

    Returns:
        RecipeOutput with news data

    Examples:
        >>> import warpdata as wd
        >>> # Fetch news for specific tickers
        >>> result = wd.run_recipe(
        ...     "polygon_news",
        ...     "warpdata://news/tech-news",
        ...     tickers=["AAPL", "MSFT", "GOOGL"],
        ...     limit=100,
        ...     with_materialize=True
        ... )
        >>> # Fetch all news for a date range
        >>> result = wd.run_recipe(
        ...     "polygon_news",
        ...     "warpdata://news/jan-2025",
        ...     start_date="2025-01-01",
        ...     end_date="2025-01-31",
        ...     limit=1000,
        ...     with_materialize=True
        ... )
    """
    # Import polygon ETL
    polygon_etl_path = Path("/home/alerad/workspace/option_pricing/options_etl")
    if polygon_etl_path.exists():
        sys.path.insert(0, str(polygon_etl_path.parent))

    try:
        from options_etl.polygon_etl_module import PolygonETLAPI
    except ImportError as e:
        raise ImportError(
            f"Could not import polygon_etl_module. "
            f"Make sure /home/alerad/workspace/option_pricing is accessible"
        ) from e

    # Get API key
    api_key = polygon_api_key or os.environ.get("POLYGON_API_KEY")
    if not api_key:
        raise ValueError(
            "Polygon API key required. Set POLYGON_API_KEY env var or pass polygon_api_key parameter"
        )

    print(f"📰 Fetching Polygon News data")
    if tickers:
        print(f"  Tickers: {', '.join(tickers[:10])}{'...' if len(tickers) > 10 else ''}")
    if start_date or end_date:
        print(f"  Date range: {start_date or 'any'} to {end_date or 'any'}")
    print(f"  Limit per query: {limit}")

    # Use global raw data directory if not specified
    if raw_data_dir is None:
        raw_data_dir = str(Path.home() / ".warpdata" / "polygon_raw_data" / "polygon_news")

    # Create raw data directory
    raw_dir = Path(raw_data_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)

    # Initialize Polygon ETL API
    etl = PolygonETLAPI(api_key=api_key)

    output_files = []
    metadata = {
        "source": "Polygon.io News API",
        "data_type": "news",
        "tickers": tickers,
        "start_date": start_date,
        "end_date": end_date,
        "limit": limit,
    }

    all_articles = []

    def fetch_news_page(ticker, published_utc_gte=None, published_utc_lte=None, cursor=None):
        """Fetch a single page of news from Polygon API."""
        # Build params
        params = {
            "limit": min(limit, 1000),  # API max is 1000
            "order": "desc",
            "sort": "published_utc",
        }

        if ticker:
            params["ticker"] = ticker
        if published_utc_gte:
            params["published_utc.gte"] = published_utc_gte
        if published_utc_lte:
            params["published_utc.lte"] = published_utc_lte
        if cursor:
            params["cursor"] = cursor

        try:
            # Use the client's news endpoint
            # Assuming the API has a news() method or similar
            # If not, we'll need to use a direct HTTP call

            # Build the URL manually since we're not sure about the exact client method
            import requests
            url = "https://api.polygon.io/v2/reference/news"
            params["apiKey"] = api_key

            response = requests.get(url, params=params)

            if response.status_code == 200:
                data = response.json()
                return data
            else:
                return {"status": "ERROR", "results": [], "message": f"Status {response.status_code}"}
        except Exception as e:
            return {"status": "ERROR", "results": [], "message": str(e)}

    def fetch_all_news_for_ticker(ticker_or_query):
        """Fetch all news for a ticker with pagination."""
        ticker = ticker_or_query if tickers else None

        # Create cache filename
        cache_parts = []
        if ticker:
            cache_parts.append(f"ticker-{ticker}")
        if start_date:
            cache_parts.append(f"from-{start_date}")
        if end_date:
            cache_parts.append(f"to-{end_date}")
        cache_parts.append(f"limit-{limit}")

        cache_filename = "_".join(cache_parts) if cache_parts else "all_news"
        json_file = raw_dir / f"{cache_filename}.json"

        # Check cache
        if json_file.exists():
            try:
                cached_data = json.loads(json_file.read_text())
                return (ticker, cached_data, None, True)
            except:
                pass  # Cache corrupted, re-fetch

        # Fetch from API
        articles = []
        cursor = None
        page = 0

        while len(articles) < limit:
            page += 1
            data = fetch_news_page(
                ticker=ticker,
                published_utc_gte=start_date,
                published_utc_lte=end_date,
                cursor=cursor
            )

            if data.get("status") == "ERROR":
                return (ticker, [], data.get("message", "Unknown error"), False)

            results = data.get("results", [])
            if not results:
                break

            articles.extend(results)

            # Check for next page
            next_url = data.get("next_url")
            if not next_url or len(articles) >= limit:
                break

            # Extract cursor from next_url
            # Format: ...?cursor=XXX
            if "cursor=" in next_url:
                cursor = next_url.split("cursor=")[1].split("&")[0]
            else:
                break

            # Rate limiting - be nice to the API
            time.sleep(0.1)

        # Limit to requested amount
        articles = articles[:limit]

        # Save to cache
        json_file.write_text(json.dumps(articles, indent=2))

        return (ticker, articles, None, False)

    # Fetch news
    if tickers:
        # Fetch news for each ticker in parallel
        print(f"\n🚀 Fetching news for {len(tickers)} tickers with {max_workers} workers...")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_all_news_for_ticker, ticker): ticker
                      for ticker in tickers}

            completed = 0
            for future in as_completed(futures):
                ticker, articles, error, from_cache = future.result()
                completed += 1

                if error:
                    print(f"  [{completed}/{len(tickers)}] ⚠️  {ticker}: {error}")
                else:
                    cache_indicator = "💾" if from_cache else "⬇️ "
                    print(f"  [{completed}/{len(tickers)}] {cache_indicator} {ticker}: {len(articles)} articles")
                    all_articles.extend(articles)
    else:
        # Fetch general news
        print(f"\n📰 Fetching general news...")
        ticker, articles, error, from_cache = fetch_all_news_for_ticker(None)

        if error:
            print(f"  ⚠️  Error: {error}")
        else:
            cache_indicator = "💾 From cache" if from_cache else "⬇️  Downloaded"
            print(f"  {cache_indicator}: {len(articles)} articles")
            all_articles.extend(articles)

    if all_articles:
        print(f"\n📊 Processing {len(all_articles):,} articles...")

        # Convert to DataFrame
        # Flatten insights and keywords for easier querying
        flattened_articles = []

        for article in all_articles:
            # Create base record
            record = {
                "id": article.get("id"),
                "title": article.get("title"),
                "author": article.get("author"),
                "published_utc": article.get("published_utc"),
                "article_url": article.get("article_url"),
                "amp_url": article.get("amp_url"),
                "image_url": article.get("image_url"),
                "description": article.get("description"),
                "publisher_name": article.get("publisher", {}).get("name"),
                "publisher_homepage": article.get("publisher", {}).get("homepage_url"),
                "publisher_logo": article.get("publisher", {}).get("logo_url"),
                "publisher_favicon": article.get("publisher", {}).get("favicon_url"),
                "tickers": ",".join(article.get("tickers", [])),
                "keywords": ",".join(article.get("keywords", [])),
            }

            # Extract insights (sentiment analysis)
            insights = article.get("insights", [])
            if insights:
                # Take first insight if multiple
                insight = insights[0]
                record["sentiment"] = insight.get("sentiment")
                record["sentiment_reasoning"] = insight.get("sentiment_reasoning")
                record["insight_ticker"] = insight.get("ticker")
            else:
                record["sentiment"] = None
                record["sentiment_reasoning"] = None
                record["insight_ticker"] = None

            flattened_articles.append(record)

        df = pd.DataFrame(flattened_articles)

        # Convert published_utc to datetime
        if 'published_utc' in df.columns:
            df['published_utc'] = pd.to_datetime(df['published_utc'], errors='coerce')

        # Sort by published date (newest first)
        if 'published_utc' in df.columns:
            df = df.sort_values('published_utc', ascending=False)

        # Remove duplicates by article ID
        df = df.drop_duplicates(subset=['id'], keep='first')

        # Merge with existing dataset if present
        try:
            from ..api import load
            existing = load(ctx.dataset_id, as_format="pandas")
            if existing is not None and len(existing) > 0:
                # Combine and deduplicate by stable article id
                merged = pd.concat([existing, df], ignore_index=True)
                if 'id' in merged.columns:
                    merged = merged.drop_duplicates(subset=['id'], keep='last')
                else:
                    merged = merged.drop_duplicates(keep='last')
                df = merged
                del existing
        except Exception:
            # No existing dataset or failed to load; proceed with new df
            pass

        # Save to parquet (consolidated)
        output_file = ctx.work_dir / "polygon_news.parquet"
        df.to_parquet(output_file, index=False)
        output_files.append(output_file)

        metadata["total_articles"] = len(df)
        metadata["unique_tickers"] = len(df['tickers'].str.split(',').explode().unique()) if 'tickers' in df.columns else 0
        metadata["date_range"] = f"{df['published_utc'].min()} to {df['published_utc'].max()}" if 'published_utc' in df.columns else None
        metadata["publishers"] = df['publisher_name'].nunique() if 'publisher_name' in df.columns else 0

        print(f"  ✓ Saved {len(df):,} articles to {output_file.name}")
        print(f"  📰 Unique publishers: {metadata['publishers']}")
        print(f"  📅 Date range: {metadata['date_range']}")

        # Show sentiment distribution
        if 'sentiment' in df.columns:
            sentiment_counts = df['sentiment'].value_counts()
            print(f"\n  📊 Sentiment distribution:")
            for sentiment, count in sentiment_counts.items():
                print(f"    {sentiment}: {count:,} ({count/len(df)*100:.1f}%)")

        # Show sample
        print(f"\n  📰 Sample articles:")
        sample_cols = ['published_utc', 'title', 'publisher_name', 'sentiment', 'tickers']
        sample_cols = [c for c in sample_cols if c in df.columns]
        print(df[sample_cols].head(3).to_string())
    else:
        print(f"  ⚠️  No articles found")

    # Generate documentation
    readme = f"""# Polygon News Dataset

## Overview
News articles from Polygon.io with sentiment analysis, metadata, and ticker associations.

## Configuration
- **Source**: Polygon.io News API
- **Tickers**: {', '.join(tickers) if tickers else 'All'}
- **Date Range**: {start_date or 'any'} to {end_date or 'any'}
- **Limit**: {limit} articles per query

## Schema

### Main Dataset
| Column | Type | Description |
|--------|------|-------------|
| id | string | Unique article identifier |
| title | string | Article title |
| author | string | Article author |
| published_utc | datetime | Publication timestamp (UTC) |
| article_url | string | Link to full article |
| amp_url | string | Mobile-friendly AMP URL |
| image_url | string | Article image URL |
| description | string | Article summary/description |
| publisher_name | string | Publisher name (e.g., "Bloomberg") |
| publisher_homepage | string | Publisher homepage URL |
| publisher_logo | string | Publisher logo URL |
| publisher_favicon | string | Publisher favicon URL |
| tickers | string | Comma-separated ticker symbols |
| keywords | string | Comma-separated keywords |
| sentiment | string | AI sentiment (positive/negative/neutral) |
| sentiment_reasoning | string | Explanation of sentiment |
| insight_ticker | string | Primary ticker for sentiment insight |

## Usage

```python
import warpdata as wd

# Load news data
df = wd.load("warpdata://news/...", as_format="pandas")

# Filter by ticker
aapl_news = df[df['tickers'].str.contains('AAPL')]

# Filter by sentiment
positive_news = df[df['sentiment'] == 'positive']

# Recent news
recent = df.nlargest(10, 'published_utc')

# Group by publisher
by_publisher = df.groupby('publisher_name').size().sort_values(ascending=False)
```

## Statistics
- Total articles: {metadata.get('total_articles', 0):,}
- Unique tickers mentioned: {metadata.get('unique_tickers', 0):,}
- Publishers: {metadata.get('publishers', 0):,}
- Date range: {metadata.get('date_range', 'N/A')}

## Sentiment Analysis
Articles include AI-generated sentiment analysis with reasoning, useful for:
- Market sentiment tracking
- Event-driven trading strategies
- Portfolio risk monitoring
- News impact analysis
"""

    # Track raw data provenance
    raw_data_paths = []
    if raw_dir.exists():
        raw_data_paths.append(raw_dir.absolute())

    return RecipeOutput(
        main=output_files,
        docs={"README.md": readme},
        metadata=metadata,
        raw_data=raw_data_paths,
    )
