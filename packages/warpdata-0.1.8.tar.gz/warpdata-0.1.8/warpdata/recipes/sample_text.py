"""
Sample text dataset recipe.

Generates synthetic text data for demonstration and testing purposes.
Useful for quickly testing embedding and search functionality.
"""
from pathlib import Path
from typing import List

from ..api.recipes import RecipeContext
from ..core.utils import safe_filename


def sample_text(
    ctx: RecipeContext, num_rows: int = 100, categories: int = 3
) -> List[Path]:
    """
    Create a sample text dataset with synthetic data.

    Generates text with different categories, suitable for testing
    embeddings and semantic search.

    Args:
        ctx: Recipe context
        num_rows: Number of rows to generate (default: 100)
        categories: Number of categories (default: 3)

    Returns:
        List with single Parquet file path

    Examples:
        >>> import warpdata as wd
        >>> version = wd.run_recipe(
        ...     "sample_text",
        ...     "warpdata://examples/text",
        ...     num_rows=1000,
        ...     categories=5
        ... )
        >>> data = wd.load("warpdata://examples/text", as_format="pandas")
    """
    # Generate synthetic text data using DuckDB
    # Create varied text patterns for each category
    sql = f"""
    WITH generated AS (
        SELECT
            row_number() OVER () AS id,
            (row_number() OVER () % {categories}) + 1 AS category,
            row_number() OVER () AS seq
        FROM generate_series(1, {num_rows})
    )
    SELECT
        id,
        category,
        'Category ' || category AS category_name,
        CASE category
            WHEN 1 THEN 'Technology and innovation drive modern progress. ' ||
                       'Software development continues to evolve rapidly. ' ||
                       'Digital transformation impacts every industry. Item ' || seq || '.'
            WHEN 2 THEN 'Health and wellness are fundamental to quality of life. ' ||
                       'Medical research advances improve treatments. ' ||
                       'Nutrition and exercise promote better outcomes. Item ' || seq || '.'
            WHEN 3 THEN 'Business strategies shape organizational success. ' ||
                       'Market dynamics influence decision making. ' ||
                       'Leadership and teamwork drive results. Item ' || seq || '.'
            ELSE 'General information and knowledge sharing. ' ||
                 'Learning and education promote growth. ' ||
                 'Communication enables collaboration. Item ' || seq || '.'
        END AS text,
        (id * 7919) % 100 AS score  -- Pseudo-random score
    FROM generated
    """

    relation = ctx.engine.conn.sql(sql)

    # Write to single Parquet file
    out = ctx.work_dir / f"{safe_filename(ctx.uri.name)}.parquet"
    ctx.write_parquet(relation, out)

    return [out]
