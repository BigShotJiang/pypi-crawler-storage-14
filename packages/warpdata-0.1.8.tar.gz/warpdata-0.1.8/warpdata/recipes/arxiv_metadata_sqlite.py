"""
ArXiv Metadata SQLite Recipe.

Extracts normalized metadata from SQLite database.
"""
from __future__ import annotations
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
import json
import sqlite3
from datetime import datetime

from ..api.recipes import RecipeContext
from ..recipes.base import RecipeOutput


def _parse_categories(cats: Any) -> List[str]:
    """Parse categories field (may be JSON string or list)."""
    try:
        if isinstance(cats, str):
            return json.loads(cats)
        return cats or []
    except Exception:
        return []


def _primary_category(categories: List[str]) -> str:
    """Extract primary category from list."""
    return categories[0] if categories else "unknown"


def _extract_year_month(date_str: Any) -> Tuple[Optional[int], Optional[int]]:
    """Extract year and month from date string."""
    try:
        if isinstance(date_str, str):
            dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        else:
            dt = date_str
        return dt.year, dt.month
    except Exception:
        return None, None


def arxiv_metadata_sqlite(
    ctx: RecipeContext,
    db_path: str = "./recipes_raw_data/arxiv_papers.db",
    table: str = "papers",
    limit: Optional[int] = None,
    min_date: Optional[str] = None,  # e.g., "2024-01-01"
) -> RecipeOutput:
    """
    Extract metadata from ArXiv SQLite database.

    Reads from SQLite table and normalizes to standard schema with:
    - Parsed categories (JSON -> list)
    - Primary category extraction
    - Year/month extraction from dates
    - Abstract and title lengths

    Args:
        ctx: Recipe context
        db_path: Path to SQLite database
        table: Table name (default: "papers")
        limit: Optional row limit for testing

    Returns:
        RecipeOutput with metadata Parquet

    Schema:
        - arxiv_id: string (primary key)
        - title: string
        - abstract: string
        - categories: list[string]
        - primary_category: string
        - submitted_date: string
        - updated_date: string
        - year: int (from submitted_date)
        - month: int (from submitted_date)
        - updated_year: int
        - updated_month: int
        - pdf_url: string
        - abs_url: string
        - doi: string
        - journal_ref: string
        - msc_class: string
        - acm_class: string
        - report_no: string
        - comments: string
        - is_ml_related: bool
        - abstract_length: int
        - title_length: int
        - language: string (default "en")
    """
    db_path = Path(db_path).resolve()
    if not db_path.exists():
        raise ValueError(f"Database not found: {db_path}")

    print(f"📊 Loading metadata from SQLite: {db_path}")
    print(f"   Table: {table}")

    # Connect and read
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row

    # Discover available columns so we can work with different DB schemas
    info_rows = conn.execute(f"PRAGMA table_info({table})").fetchall()
    existing_cols = {row[1] for row in info_rows}

    # Core fields we rely on; raise if truly missing
    required_cols = ["arxiv_id", "title", "abstract", "categories", "submitted_date", "updated_date"]
    missing_required = [c for c in required_cols if c not in existing_cols]
    if missing_required:
        raise ValueError(f"Database table {table} missing required columns: {', '.join(missing_required)}")

    # Optional fields; we will fill with None when absent
    optional_cols = [
        "pdf_url", "abs_url", "doi", "journal_ref", "msc_class", "acm_class",
        "report_no", "comments", "is_ml_related", "processing_status",
        "error_message", "created_at", "updated_at",
    ]

    select_cols = required_cols + [c for c in optional_cols if c in existing_cols]

    # Build query
    sql = f"SELECT {', '.join(select_cols)} FROM {table}"
    where_clauses = []
    if min_date:
        where_clauses.append(f"(submitted_date IS NULL OR submitted_date >= '{min_date}')")

    if where_clauses:
        sql += " WHERE " + " AND ".join(where_clauses)

    if limit:
        sql += f" LIMIT {int(limit)}"

    cur = conn.execute(sql)

    rows: List[Dict[str, Any]] = []
    for row in cur:
        rec = dict(row)

        # Ensure optional columns exist even if not in DB
        for col in optional_cols:
            rec.setdefault(col, None)

        # Parse categories
        cats = _parse_categories(rec.get("categories"))
        rec["categories"] = cats
        rec["primary_category"] = _primary_category(cats)

        # Extract year/month from submitted_date
        y, m = _extract_year_month(rec.get("submitted_date"))
        rec["year"] = y
        rec["month"] = m

        # Extract year/month from updated_date
        uy, um = _extract_year_month(rec.get("updated_date"))
        rec["updated_year"] = uy
        rec["updated_month"] = um

        # Compute lengths
        rec["abstract_length"] = len(rec.get("abstract") or "")
        rec["title_length"] = len(rec.get("title") or "")

        # Default language
        rec["language"] = "en"

        rows.append(rec)

    conn.close()

    print(f"   Loaded {len(rows)} metadata records")

    # Write to Parquet
    import pandas as pd
    metadata_df = pd.DataFrame(rows)

    # Sort by arxiv_id
    if len(metadata_df) > 0:
        metadata_df = metadata_df.sort_values("arxiv_id")

    metadata_rel = ctx.engine.conn.from_df(metadata_df)
    out_path = ctx.work_dir / "metadata.parquet"
    ctx.write_parquet(metadata_rel, out_path)

    print(f"   Wrote metadata: {out_path}")

    # Generate stats
    if len(metadata_df) > 0:
        cat_counts = {}
        for cats in metadata_df["categories"]:
            for cat in (cats or []):
                cat_counts[cat] = cat_counts.get(cat, 0) + 1

        year_counts = metadata_df["year"].value_counts().to_dict()
        ml_related = metadata_df["is_ml_related"].sum() if "is_ml_related" in metadata_df else 0
    else:
        cat_counts = {}
        year_counts = {}
        ml_related = 0

    readme = f"""# ArXiv Metadata

## Overview
Normalized metadata extracted from ArXiv SQLite database.

## Statistics
- **Total papers**: {len(rows)}
- **ML-related papers**: {ml_related}
- **Database**: {db_path}
- **Table**: {table}

## Top Categories
"""
    for cat, count in sorted(cat_counts.items(), key=lambda x: -x[1])[:20]:
        readme += f"- **{cat}**: {count} papers\n"

    readme += "\n## Papers by Year\n"
    for year, count in sorted(year_counts.items(), reverse=True)[:10]:
        readme += f"- **{year}**: {count} papers\n"

    readme += """
## Schema
- `arxiv_id`: ArXiv identifier (primary key)
- `title`: Paper title
- `abstract`: Paper abstract
- `categories`: List of arXiv categories
- `primary_category`: Main category (first in list)
- `submitted_date`: Original submission date
- `updated_date`: Last update date
- `year`, `month`: Extracted from submitted_date
- `pdf_url`, `abs_url`: ArXiv URLs
- `doi`, `journal_ref`: Publication info
- `is_ml_related`: ML/AI flag

## Usage
```python
import warpdata as wd
meta = wd.load("warpdata://arxiv/metadata", as_format="pandas")
print(f"Papers: {len(meta)}")
```
"""

    return RecipeOutput(
        main=[out_path],
        subdatasets={},
        docs={"README.md": readme},
        metadata={
            "source": "sqlite",
            "db_path": str(db_path),
            "table": table,
            "total_papers": len(rows),
            "ml_related": int(ml_related),
        },
    )
