"""
MathX-5M dataset recipe.

MathX-5M is a large-scale mathematical reasoning dataset containing 5 million
math problems with expected answers and generated solutions.

Source: https://huggingface.co/datasets/XenArcAI/MathX-5M

Contains:
- train: ~5 million math problems with solutions

Each problem includes the question, expected answer, and a detailed solution.
"""
from pathlib import Path
import pandas as pd

from datasets import load_dataset

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def mathx5m(
    ctx: RecipeContext,
    repo_id: str = "XenArcAI/MathX-5M",
    max_samples: int = None,
) -> RecipeOutput:
    """
    Create MathX-5M mathematical reasoning dataset.

    Downloads MathX-5M from HuggingFace. Contains 5 million math problems
    with expected answers and generated solutions.

    Args:
        ctx: Recipe context
        repo_id: HuggingFace repo ID
        max_samples: Maximum samples to process (None = all 5M). Use this for sampling.

    Returns:
        RecipeOutput with single dataset

    Dataset columns:
        - problem: str - The math problem statement
        - expected_answer: str - Expected answer
        - generated_solution: str - Detailed solution

    Examples:
        >>> import warpdata as wd
        >>> # Get a 100k sample
        >>> result = wd.run_recipe(
        ...     "mathx5m",
        ...     "warpdata://math/mathx-100k",
        ...     max_samples=100000,
        ...     with_materialize=True
        ... )
        >>> df = wd.load("warpdata://math/mathx-100k", as_format="pandas")
    """
    print(f"Loading MathX-5M from {repo_id}...")

    if max_samples:
        print(f"Note: Limiting to {max_samples:,} samples")
        # Use streaming for sampling to avoid loading all 5M
        ds = load_dataset(repo_id, split='train', streaming=True)

        print(f"  Processing up to {max_samples:,} problems...")

        all_records = []
        for idx, example in enumerate(ds):
            if idx >= max_samples:
                break

            record = {
                'problem': str(example.get('problem', '')),
                'expected_answer': str(example.get('expected_answer', '')),
                'generated_solution': str(example.get('generated_solution', '')),
            }
            all_records.append(record)

            # Progress update every 10k
            if (idx + 1) % 10000 == 0:
                print(f"    Processed {idx + 1:,} problems...")
    else:
        print("  Loading full dataset (5M problems - this will take a while)...")
        ds = load_dataset(repo_id, split='train')

        print(f"  Processing {len(ds):,} problems...")

        all_records = []
        for idx, example in enumerate(ds):
            record = {
                'problem': str(example.get('problem', '')),
                'expected_answer': str(example.get('expected_answer', '')),
                'generated_solution': str(example.get('generated_solution', '')),
            }
            all_records.append(record)

            # Progress update every 100k
            if (idx + 1) % 100000 == 0:
                print(f"    Processed {idx + 1:,} problems...")

    print(f"\nTotal problems: {len(all_records):,}")

    # Create DataFrame
    df = pd.DataFrame(all_records)

    # Write to output
    output_path = ctx.work_dir / "mathx5m.parquet"
    df.to_parquet(output_path, index=False)

    print(f"Saved to {output_path}")

    # Track raw data provenance
    raw_data_paths = []
    hf_cache = Path.home() / ".cache" / "huggingface" / "datasets" / repo_id.replace("/", "___")
    if hf_cache.exists():
        raw_data_paths.append(hf_cache)

    return RecipeOutput(
        main=[output_path],
        metadata={
            'total_problems': len(df),
            'source': repo_id,
            'sampled': max_samples is not None,
        },
        raw_data=raw_data_paths,
    )
