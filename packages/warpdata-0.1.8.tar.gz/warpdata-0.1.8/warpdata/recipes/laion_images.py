"""
LAION images downloader recipe.

Builds a derived dataset with local image files from a LAION metadata table
(URL + caption), adding an image_path column for successful downloads.

Typical usage:
    warp recipes run laion_images \
        warpdata://vision/laion-10m-images \
        --param source_dataset=warpdata://vision/laion-10m \
        --param max_images=50000 \
        --param workers=16 \
        --materialize

Notes:
- Downloads only a subset (max_images) to keep it practical.
- Saves images under the recipe work dir by default; you can override via images_dir.
- Records failures. Registers main dataset with only successful rows; failed rows are
  registered as a subdataset "failed".
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
import concurrent.futures as cf
import time
import urllib.request
import urllib.parse

import pandas as pd

import warpdata as wd
from ..api.recipes import RecipeContext
from .base import RecipeOutput, SubDataset
from ..core.utils import compute_hash, ensure_dir


def _infer_extension(url: str, content_type: Optional[str]) -> str:
    if content_type:
        ct = content_type.lower()
        if "image/jpeg" in ct:
            return ".jpg"
        if "image/png" in ct:
            return ".png"
        if "image/webp" in ct:
            return ".webp"
    # fallback from URL
    path = urllib.parse.urlparse(url).path
    for ext in (".jpg", ".jpeg", ".png", ".webp", ".bmp"):
        if path.lower().endswith(ext):
            return ".jpg" if ext == ".jpeg" else ext
    return ".jpg"


def _download_one(url: str, out_dir: Path, timeout: float = 10.0, user_agent: Optional[str] = None) -> Tuple[bool, Dict[str, Any]]:
    headers = {}
    if user_agent:
        headers["User-Agent"] = user_agent
    req = urllib.request.Request(url, headers=headers)
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content_type = resp.headers.get("Content-Type")
            if content_type and not content_type.lower().startswith("image/"):
                return False, {
                    "status": "not_image",
                    "http_status": getattr(resp, 'status', None),
                    "content_type": content_type,
                }

            ext = _infer_extension(url, content_type)
            # Use stable hash of the URL for filename
            stem = compute_hash(url, algorithm="sha1")
            fname = f"{stem}{ext}"
            out_path = out_dir / fname
            out_path.parent.mkdir(parents=True, exist_ok=True)

            # Stream to disk
            with open(out_path, "wb") as f:
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)

            size = out_path.stat().st_size
            return True, {
                "status": "ok",
                "http_status": getattr(resp, 'status', None),
                "content_type": content_type,
                "bytes": size,
                "image_path": str(out_path.resolve()),
            }
    except Exception as e:
        return False, {
            "status": "error",
            "error": str(e)[:500],
        }
    finally:
        _ = t0  # placeholder for future timing


def laion_images(
    ctx: RecipeContext,
    source_dataset: str = "warpdata://vision/laion-10m",
    url_column: str = "url",
    caption_column: str = "caption",
    max_images: int = 50_000,
    images_dir: Optional[str] = None,
    workers: int = 16,
    timeout: float = 10.0,
    user_agent: Optional[str] = None,
) -> RecipeOutput:
    """
    Download images from a LAION metadata dataset and produce a derived table with image_path.

    Args:
        ctx: Recipe context
        source_dataset: Source dataset ID with URL/caption columns
        url_column: Column name for image URL
        caption_column: Column name for caption (optional)
        max_images: Limit number of images to download
        images_dir: Output directory for images (defaults to recipe work dir / images)
        workers: Parallel download workers
        timeout: Per-request timeout in seconds
        user_agent: Optional HTTP User-Agent header
    """
    print(f"Source dataset: {source_dataset}")
    print(f"Max images: {max_images:,}  Workers: {workers}")

    # Load a limited subset of the source to keep it practical
    rel = wd.load(source_dataset, as_format="duckdb")
    # Project only needed columns and apply limit deterministically
    proj_cols = [url_column]
    has_caption = False
    try:
        schema = wd.schema(source_dataset)
        if caption_column in schema:
            has_caption = True
            proj_cols.append(caption_column)
    except Exception:
        pass

    select_expr = ", ".join(f'"{c}"' for c in proj_cols)
    limited = rel.project(select_expr).limit(int(max_images))
    df = limited.fetchdf()
    if df.empty:
        raise ValueError("No rows found in source dataset.")

    # Prepare output directory for images
    if images_dir:
        images_base = Path(images_dir).expanduser().resolve()
    else:
        images_base = ensure_dir(ctx.work_dir / "images")
    ensure_dir(images_base)
    print(f"Images directory: {images_base}")

    # Download in parallel
    results: List[Dict[str, Any]] = []
    urls = df[url_column].astype(str).tolist()
    caps = df[caption_column].astype(str).tolist() if has_caption else [None] * len(urls)

    with cf.ThreadPoolExecutor(max_workers=int(workers)) as ex:
        fut_to_i = {
            ex.submit(_download_one, url, images_base, timeout, user_agent): i
            for i, url in enumerate(urls)
        }
        done = 0
        for fut in cf.as_completed(fut_to_i):
            i = fut_to_i[fut]
            url = urls[i]
            cap = caps[i]
            ok, info = fut.result()
            row = {
                "url": url,
                "caption": cap,
                **info,
            }
            results.append(row)
            done += 1
            if done % 1000 == 0:
                ok_count = sum(1 for r in results if r.get("status") == "ok")
                print(f"  Downloaded {done:,}/{len(urls):,} (ok: {ok_count:,})")

    res_df = pd.DataFrame(results)
    ok_df = res_df[res_df["status"] == "ok"].copy()
    fail_df = res_df[res_df["status"] != "ok"].copy()

    if ok_df.empty:
        raise RuntimeError("No images downloaded successfully.")

    # Write outputs
    out_main = ctx.work_dir / "laion_images.parquet"
    ok_df.to_parquet(out_main, index=False)

    subdatasets: Dict[str, SubDataset] = {}
    if not fail_df.empty:
        out_failed = ctx.work_dir / "laion_images_failed.parquet"
        fail_df.to_parquet(out_failed, index=False)
        subdatasets["failed"] = SubDataset(
            name="failed",
            files=[out_failed],
            description="Failed downloads with error/status details",
        )

    meta = {
        "source_dataset": source_dataset,
        "url_column": url_column,
        "caption_column": caption_column,
        "downloaded": int(len(ok_df)),
        "attempted": int(len(res_df)),
        "images_dir": str(images_base),
    }

    readme = f"""# LAION Images (Derived)

This dataset contains local images downloaded from {source_dataset} with
columns:
- url: original image URL
- caption: text caption (if available)
- image_path: local file path to downloaded image
- content_type, bytes, http_status

Failed downloads are included as a subdataset named 'failed'.
"""

    return RecipeOutput(
        main=[out_main],
        subdatasets=subdatasets,
        metadata=meta,
        docs={"README.md": readme},
        raw_data=[images_base],
    )

