"""
Derive a sectors mapping from Polygon fundamentals ticker_details.

Input dataset (default): warpdata://fundamentals/fundamentals-all-ticker_details

Output columns:
- ticker
- name (if available)
- sector
- industry
- market_cap (if available)

Notes:
- If multiple rows per ticker, keep the row with largest market_cap when available,
  otherwise keep the latest occurrence as-is.
"""
from __future__ import annotations

from typing import Optional, List
from pathlib import Path
import pandas as pd

from ..api.recipes import RecipeContext
from .base import RecipeOutput


def sectors_from_fundamentals(
    ctx: RecipeContext,
    *,
    source: str = "warpdata://fundamentals/fundamentals-all-ticker_details",
) -> RecipeOutput:
    """
    Build a sectors mapping from fundamentals ticker_details.

    Args:
        ctx: Recipe context
        source: Input dataset ID for ticker_details

    Returns:
        RecipeOutput with a single Parquet file `sectors.parquet`.
    """
    # Lazy import to avoid circulars
    from ..api import load

    df = load(source, as_format="pandas")
    if df is None or df.empty:
        raise ValueError(f"Input dataset is empty: {source}")

    # Identify best-available columns
    ticker_col = "ticker" if "ticker" in df.columns else None
    if not ticker_col:
        raise ValueError("Input lacks required column: ticker")

    # Sector candidates
    sector_col = None
    for c in ["sector", "gics_sector", "sector_name", "sic_sector"]:
        if c in df.columns:
            sector_col = c
            break

    # Industry candidates
    industry_col = None
    for c in ["industry", "industry_name", "gics_industry", "sic_description"]:
        if c in df.columns:
            industry_col = c
            break

    cols: List[str] = [ticker_col]
    name_col = "name" if "name" in df.columns else None
    mc_col = "market_cap" if "market_cap" in df.columns else None
    if name_col:
        cols.append(name_col)
    if sector_col:
        cols.append(sector_col)
    if industry_col:
        cols.append(industry_col)
    if mc_col:
        cols.append(mc_col)

    sdf = df[cols].copy()

    # Normalize output column names
    ren = {}
    if name_col:
        ren[name_col] = "name"
    if sector_col:
        ren[sector_col] = "sector"
    if industry_col:
        ren[industry_col] = "industry"
    if mc_col:
        ren[mc_col] = "market_cap"
    sdf = sdf.rename(columns=ren)

    # Ensure required outputs exist
    if "sector" not in sdf.columns:
        sdf["sector"] = None
    if "industry" not in sdf.columns:
        sdf["industry"] = None

    # Drop rows entirely missing both sector and industry
    if sdf["sector"].isna().all() and sdf["industry"].isna().all():
        # Nothing to produce
        raise ValueError("Input lacks sector/industry information (no sector or industry-like columns found)")

    # Optionally drop rows without any classification
    sdf = sdf.dropna(subset=[col for col in ["sector", "industry"] if col in sdf.columns], how='all').copy()

    # Sort to keep preferred row per ticker (highest market_cap if present)
    if "market_cap" in sdf.columns:
        sdf = sdf.sort_values(["ticker", "market_cap"], ascending=[True, False])
    else:
        sdf = sdf.sort_values(["ticker"])  # deterministic

    # Keep one row per ticker
    sdf = sdf.drop_duplicates(subset=["ticker"], keep="first").reset_index(drop=True)

    # Write to stable path in work_dir
    out_file = ctx.work_dir / "sectors.parquet"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    sdf.to_parquet(out_file, index=False)

    # Simple README
    readme = f"""# Sectors Mapping (from Polygon fundamentals)

Input: {source}
Rows: {len(sdf)}

Columns:
- ticker
- name
- sector
- industry
- market_cap (when available)
"""

    return RecipeOutput(
        main=[out_file],
        docs={"README.md": readme},
        metadata={
            "source": "polygon-fundamentals",
            "input_dataset": source,
            "rows": len(sdf),
        },
    )
