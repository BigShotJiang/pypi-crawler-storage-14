from inference.models.moondream2.moondream2 import Moondream2
