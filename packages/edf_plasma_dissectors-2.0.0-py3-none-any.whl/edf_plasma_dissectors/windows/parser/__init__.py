"""Windows dissectors parsers"""
