Static pages for pretalx
==========================

This is a plugin for `pretalx`_ that allows you to add static pages to your
event, for example FAQ, Terms of Service, a Code of Conduct, etc.

|screenshots|

You can install this plugin via pip: ``pip install pretalx-pages``. Requires
pretalx 1.2.0 or higher.

Development setup
-----------------

1. Make sure that you have a working `pretalx development setup`_.

2. Clone this repository, eg to ``local/pretalx-pages``.

3. Activate the virtual environment you use for pretalx development.

4. Execute ``python setup.py develop`` within this directory to register this application with pretalx's plugin registry.

5. Execute ``make`` within this directory to compile translations.

6. Restart your local pretalx server. You can now use the plugin from this repository for your events by enabling it in
   the 'plugins' tab in the settings.


License
-------

Copyright 2019 Tobias Kunze

Released under the terms of the Apache License 2.0


.. _pretalx: https://github.com/pretalx/pretalx
.. _pretalx development setup: https://docs.pretalx.org/en/latest/developer/setup.html
.. |screenshots| image:: https://raw.githubusercontent.com/pretalx/pretalx-pages/master/assets/screenshots.png
   :alt: Screenshots of pretalx pages
