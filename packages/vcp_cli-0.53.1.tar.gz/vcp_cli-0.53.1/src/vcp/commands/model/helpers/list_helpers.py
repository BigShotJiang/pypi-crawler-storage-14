"""Helper functions for model list command."""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
from rich.table import Table

from vcp.commands.model.api import fetch_files_for_variant
from vcp.commands.model.models import ModelResponse, VariantData
from vcp.config.config import Config
from vcp.utils.size import format_size_bytes

logger = logging.getLogger(__name__)


def _get_variant_size(config: Config, variant_id: str) -> int | None:
    """
    Get total size in bytes for a variant by fetching its files.

    Args:
        config: Configuration object with base_url
        variant_id: UUID string of the variant

    Returns:
        Total size in bytes, or None if fetch fails or variant has no files
    """
    try:
        response = fetch_files_for_variant(config, variant_id=variant_id)
        total_size = sum(file.size_bytes for file in response.files)
        return total_size
    except requests.RequestException as e:
        # Log network/HTTP errors but continue gracefully
        logger.warning(
            f"Failed to fetch size for variant {variant_id}: {e}",
            exc_info=True,
        )
        return None


def _fetch_all_variant_sizes(
    config: Config, variants: list[VariantData], max_workers: int = 8
) -> dict[str, int | None]:
    """
    Fetch sizes for all variants in parallel.

    Args:
        config: Configuration object with base_url
        variants: List of VariantData objects
        max_workers: Maximum number of concurrent API calls

    Returns:
        Dictionary mapping variant_id to size in bytes (or None if fetch failed)
    """
    variant_sizes: dict[str, int | None] = {}

    # Fetch all sizes in parallel
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_get_variant_size, config, str(v.id)): str(v.id)
            for v in variants
        }

        for future in as_completed(futures):
            variant_id = futures[future]
            variant_sizes[variant_id] = future.result()

    return variant_sizes


def _collect_all_variants(models: list[ModelResponse]) -> list[VariantData]:
    """Collect all variants from all models and versions."""
    variants = []
    for model in models:
        for version in model.versions:
            if version.variants:  # Skip versions with no variants
                variants.extend(version.variants)
    return variants


def _format_variant_list(
    variants: list[VariantData], variant_sizes: dict[str, int | None]
) -> str:
    """Format list of variant names with sizes using bullet separator and styled sizes."""
    if not variants:
        # Empty variants list indicates a data issue - log warning
        logger.warning("Empty variants list encountered during formatting")
        return ""
    formatted_names = []
    for variant in variants:
        variant_id = str(variant.id)
        size = variant_sizes.get(variant_id)
        if size is not None:
            # Use dimmed styling for sizes to create visual hierarchy
            formatted_names.append(
                f"{variant.name} ([dim]{format_size_bytes(size)}[/dim])"
            )
        else:
            formatted_names.append(variant.name)
    # Use bullet separator for better readability
    return " • ".join(formatted_names)


def _create_table() -> Table:
    """Create and configure the models table with appropriate column settings."""
    table = Table(show_header=True, header_style="bold magenta", expand=False)
    # Don't set width constraints on headers to prevent truncation - let Rich auto-size
    table.add_column("Model Name", no_wrap=True, min_width=10)
    table.add_column("Version", no_wrap=True, min_width=7)  # "Version" is 7 chars
    table.add_column(
        "Variants",
        width=75,  # Max width to keep table compact
        overflow="fold",  # Wrap long variant lists
        no_wrap=False,  # Allow wrapping for readability
    )
    return table


def _add_model_rows(
    table: Table, models: list[ModelResponse], variant_sizes: dict[str, int | None]
) -> None:
    """Add rows to the table for each model and version."""
    for model in models:
        if not model.versions:
            table.add_row(model.name, "No versions", "")
            continue

        # Add all versions for this model
        # Show model name only on the first version row for better readability
        for version_index, version in enumerate(model.versions):
            variant_names = _format_variant_list(version.variants, variant_sizes)
            model_name = model.name if version_index == 0 else ""
            table.add_row(model_name, version.version, variant_names)


def format_models_table(models: list[ModelResponse], config: Config) -> Table:
    """
    Format models list as a Rich table with variant sizes.

    Args:
        models: List of ModelResponse objects
        config: Configuration object for API calls

    Returns:
        Rich Table ready for console.print()
    """
    # Early return for empty models list
    if not models:
        table = _create_table()
        table.add_row("No models found", "", "")
        return table

    # Collect all variants and fetch their sizes in parallel
    all_variants = _collect_all_variants(models)
    variant_sizes = (
        _fetch_all_variant_sizes(config, all_variants) if all_variants else {}
    )

    # Build and populate table
    table = _create_table()
    _add_model_rows(table, models, variant_sizes)

    return table
