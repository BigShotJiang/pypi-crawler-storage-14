# TODOV2: test general settings endpoints ( /settings CRUD )


def test_get_setting():
    pass
