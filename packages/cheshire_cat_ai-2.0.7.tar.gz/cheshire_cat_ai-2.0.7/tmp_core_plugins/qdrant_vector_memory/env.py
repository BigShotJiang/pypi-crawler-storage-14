# TODOV2: move Qdrant specifics to qdrant_vector_memory plugin settigns
envs = {
    "CCAT_QDRANT_HOST": None,
    "CCAT_QDRANT_PORT": "6333",
    "CCAT_QDRANT_API_KEY": None,
    "CCAT_QDRANT_CLIENT_TIMEOUT": None,
    "CCAT_SAVE_MEMORY_SNAPSHOTS": "false",
}