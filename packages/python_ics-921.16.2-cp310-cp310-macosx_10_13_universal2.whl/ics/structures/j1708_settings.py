# This file was auto generated; Do not modify, if you value your sanity!
import ctypes
import enum



class j1708_settings(ctypes.Structure):
    _pack_ = 2
    _fields_ = [
        ('enable_convert_mode', ctypes.c_uint16),
    ]


J1708_SETTINGS = j1708_settings

