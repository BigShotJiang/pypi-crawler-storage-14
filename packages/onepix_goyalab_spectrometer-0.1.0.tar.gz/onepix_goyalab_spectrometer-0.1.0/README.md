# Goyalab spectrometers installation 

## On the ONE-PIX using a Raspberry Pi board

## configure rules.d
To configure Goyalab USB rules you need to edit or create a rule file in /etc/udev/rules.d folder of the Rapsberry pi to indicate 
the spectrometer model used. For more information or specification, please contact us.


