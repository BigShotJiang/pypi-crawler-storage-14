# simplemathglh

A simple Python library for test.

## Installation

```bash
pip install simplemathglh