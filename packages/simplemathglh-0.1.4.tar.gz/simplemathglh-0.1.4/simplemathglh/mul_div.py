# -*- coding: utf-8 -*-
"""
Created on Wed Nov 27 19:21:15 2024

@author: ASUS
"""

def numbermultiply(a, b):
    """
    Add two numbers and return the result.

    Parameters:
    - a (int or float): The first number.
    - b (int or float): The second number.

    Returns:
    - int or float: The sum of a and b.
    """
    return a * b

def numberdivision(a, b):
    """
    Add two numbers and return the result.

    Parameters:
    - a (int or float): The first number.
    - b (int or float): The second number.

    Returns:
    - int or float: The sum of a and b.
    """
    return a / b