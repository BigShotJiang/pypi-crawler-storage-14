# -*- coding: utf-8 -*-
"""
Created on Sat May 25 17:35:37 2024

@author: ASUS
"""

def numberplus(a, b):
    """
    Add two numbers and return the result.

    Parameters:
    - a (int or float): The first number.
    - b (int or float): The second number.

    Returns:
    - int or float: The sum of a and b.
    """
    return a + b

def numberminus(a, b):
    """
    Add two numbers and return the result.

    Parameters:
    - a (int or float): The first number.
    - b (int or float): The second number.

    Returns:
    - int or float: The sum of a and b.
    """
    return a - b