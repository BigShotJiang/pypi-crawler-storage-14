# -*- coding: utf-8 -*-
# Author: ZPZ
# Description: Core module for tile downloading and concurrency management.

from __future__ import annotations

import logging
import os
import random
import time
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Union
import rasterio
from rasterio.enums import Compression
from rasterio.transform import from_bounds
import mercantile
import numpy as np
import requests
from PIL import Image
from tqdm import tqdm
from .error_info import error_img_bytes, error_img_bytes2

# 类型别名
Number = Union[float, int]
ArrayLike = Union[Number, np.ndarray]
Tile = mercantile.Tile


@dataclass
class TileDownloader:
    """
    暂时只支持吉林一号 TMS 下载

    - 假定服务使用 WebMercator 瓦片坐标 (z, x, y)
    - mercantile 产生的是 XYZ（原点左上，y向下）
    - JL1 接口使用 TMS 约定（原点左下，y向上），因此需要在请求前做 y 反转：
        y_tms = (2**z - 1) - y_xyz
    """

    # 要下载的瓦片列表（必需）
    tile_list: Sequence[Tile]

    # JL1 接口参数（如需自定义可以在实例化时传入）
    mk: str = ""
    tk: str = ""

    # 缩放等级（可从 tile_list 推断，保留一个属性方便日志打印）
    zoom: Optional[int] = None

    # URL 模板：注意这里是 XYZ/TMS 坐标位，mk/tk 从属性填充
    tile_url_template: str = (
        "https://api.jl1mall.com/getMap/{z}/{x}/{y}"
        "?mk={mk}&tk={tk}"
    )

    def _build_logger(self, output_folder: Path) -> logging.Logger:
        """
        为当前下载任务构建 logger。
        """
        os.makedirs(output_folder, exist_ok=True)

        logging.basicConfig(
            level=logging.INFO,
            format='[%(asctime)s] [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(
                    os.path.join(output_folder, 'download.log'),
                    encoding="utf-8"
                ),
            ],
            force=True,  # 覆盖旧配置
        )
        logger = logging.getLogger(__name__)
        return logger

    def _xyz_to_tms_y(self, z: int, y_xyz: int) -> int:
        """
        将 XYZ 体系的 y 转为 TMS 体系的 y。

        TMS 的 y 方向与 XYZ 相反：
            y_tms = (2**z - 1) - y_xyz
        """
        return (2 ** z - 1) - y_xyz

    def precheck_downloaded(self, output_folder: Union[str, Path]) -> None:
        """
        预检查：扫描 output_folder 中已下载的瓦片，根据文件名
        tile_{z}_{x}_{y}.png 识别哪些 tile 已存在，并从 self.tile_list 中剔除。

        最终：self.tile_list 将只包含“尚未下载”的 tiles。
        """
        output_folder = Path(output_folder)
        output_folder.mkdir(parents=True, exist_ok=True)

        # 列举目录中的现有瓦片文件
        existing_files = list(output_folder.glob("*/*/*.tif"))
        existing_set = set()

        # 从文件名解析 z,x,y
        for fp in existing_files:
            name = fp.stem  # tile_z_x_y
            try:
                # 获取倒数第3级目录（z）、倒数第2级目录（x）
                z = int(fp.parent.parent.name)
                x = int(fp.parent.name)
                # 从文件名提取 y（去掉扩展名）
                y = int(fp.stem)
                existing_set.add((z, x, y))
            except Exception:
                # 文件名不是 tile_z_x_y.png 格式，则跳过
                continue

        # 分离：已下载 vs 未下载
        remaining_tiles = []
        downloaded = 0

        for t in self.tile_list:
            key = (t.z, t.x, t.y)
            if key in existing_set:
                downloaded += 1
            else:
                remaining_tiles.append(t)

        # 更新 tile_list，仅保留待下载的
        self.tile_list = remaining_tiles

        # 打印检查结果
        print(f"已存在瓦片: {downloaded}")
        print(f"缺失瓦片: {len(self.tile_list)}")
        print(f"总计（原始）: {downloaded + len(self.tile_list)}\n")


    def precheck_downloaded_old(self, output_folder: Union[str, Path]) -> None:
        """
        预检查：扫描 output_folder 中已下载的瓦片，根据文件名
        tile_{z}_{x}_{y}.png 识别哪些 tile 已存在，并从 self.tile_list 中剔除。

        最终：self.tile_list 将只包含“尚未下载”的 tiles。
        """
        output_folder = Path(output_folder)
        output_folder.mkdir(parents=True, exist_ok=True)

        # 分离：已下载 vs 未下载
        remaining_tiles = []
        downloaded = 0

        for t in self.tile_list:
            png_path = output_folder / str(t.z) / str(t.x) / f"{t.y}.tif"
            if os.path.isfile(png_path):
                downloaded += 1
            else:
                remaining_tiles.append(t)

        # 更新 tile_list，仅保留待下载的
        self.tile_list = remaining_tiles

        # 打印检查结果
        print(f"已存在瓦片: {downloaded}")
        print(f"缺失瓦片: {len(self.tile_list)}")
        print(f"总计（原始）: {downloaded + len(self.tile_list)}\n")


    def human_delay(self, min_delay=0.06, max_delay=0.1):
        """
        模仿人类行为：在请求之间增加随机延迟。
        """
        delay = random.uniform(min_delay, max_delay)

        # 加一点细小波动，让行为更自然、不规则
        jitter = random.uniform(-0.05, 0.05)
        delay = max(0.0, delay + jitter)

        time.sleep(delay)

    def download_tiles(
            self,
            output_folder: Union[str, Path],
            tile_list: Optional[Sequence[Tile]] = None,
            verbose_debug: bool = False,
    ) -> None:
        """
        下载当前实例中的所有瓦片。

        Parameters
        ----------
        output_folder : str | Path
            瓦片输出目录。
        tile_list : Optional[Sequence[Tile]]
            可选：如果传入，将覆盖 self.tile_list，只下载这批瓦片。
        verbose_debug : bool
            如果为 True，会输出请求/响应/图像统计的详细调试信息。
        """
        output_folder = Path(output_folder)
        logger = self._build_logger(output_folder)
        self.precheck_downloaded(output_folder)

        tiles: Sequence[Tile] = tile_list if tile_list is not None else self.tile_list

        if len(tiles) == 0:
            logger.warning("Tile 列表为空，未执行任何下载。")
            return

        logger.info(f"Zoom 级别: {self.zoom}")
        logger.info(f"总瓦片数量 = 需要请求的次数 = {len(tiles)}")

        pbar = tqdm(total=len(tiles), desc="Downloading tiles", ncols=100)
        for idx, t in enumerate(tiles, start=1):
            x_xyz, y_xyz, z = t.x, t.y, t.z

            # mercantile 给的是 XYZ（原点左上），JL1 使用 TMS（原点左下）
            y_tms = self._xyz_to_tms_y(z, y_xyz)

            # 构造 URL
            url = self.tile_url_template.format(
                z=z,
                x=x_xyz,
                y=y_tms,
                mk=self.mk,
                tk=self.tk,
            )

            logger.info(f"[{idx}/{len(tiles)}] 请求瓦片 z={z}, x={x_xyz}, y_xyz={y_xyz}, y_tms={y_tms}")
            logger.debug(f"请求 URL: {url}")

            try:
                self.human_delay()
                response = requests.get(url, timeout=10)
            except requests.RequestException as e:
                logger.error(f"请求失败（网络异常）：{e}")
                break

            if verbose_debug:
                print("\n请求的完整信息：")
                print(f"请求的 URL: {response.request.url}")
                print(f"请求头: {response.request.headers}")
                print(f"请求方法: {response.request.method}")

                print("\n响应的完整信息：")
                print(f"状态码: {response.status_code}")
                print(f"响应头: {response.headers}")

            # 尝试区分 JSON / 图像
            content_type = response.headers.get("Content-Type", "")
            if response.status_code != 200:
                logger.error(f"请求失败，状态码：{response.status_code}, URL={url}")

                if "application/json" in content_type:
                    try:
                        logger.error(f"响应 JSON: {response.json()}")
                    except ValueError:
                        logger.error("响应看起来是 JSON，但解析失败。")
                break

            if "image" not in content_type:
                # 可能是 JSON 错误信息
                try:
                    err_json = response.json()
                    logger.error(f"返回内容不是图像，JSON={err_json}")
                except ValueError:
                    logger.error("返回内容不是图像，也不是 JSON。")
                break

            if response.content == error_img_bytes:
                logger.error("限额了停止吧。")
                break

            if response.content == error_img_bytes2:
                logger.error("账号被禁用了停止吧。")
                break

            # 处理图像
            img = Image.open(BytesIO(response.content))
            logger.info(f"图像模式: {img.mode}, 图像大小: {img.size}")

            if img.mode == "L":
                img = img.convert("RGB")
            if img.mode == "RGBA":
                img = img.convert("RGB")

            if verbose_debug:
                arr = np.asarray(img)
                print(f"mean: {np.mean(arr)}, unique: {np.unique(arr)[:10]} ...")

            # 保存文件名仍然使用 XYZ 的 y，更符合用户习惯
            out_name = output_folder / str(z) / str(x_xyz) / f"{y_xyz}.tif"
            os.makedirs(os.path.dirname(out_name), exist_ok=True)
            # img.save(out_name)

            # 使用 mercantile 获取该瓦片的地理边界（西、南、东、北）
            bounds = mercantile.bounds(mercantile.Tile(x=x_xyz, y=y_xyz, z=z))

            # 创建 transform 从边界计算
            transform = from_bounds(bounds.west, bounds.south, bounds.east, bounds.north, 256, 256)  # 假设瓦片尺寸为 256x256

            data = np.asarray(img)
            # 获取波段数
            num_bands = data.shape[-1]

            # 定义输出TIFF的元数据
            metadata = {
                'driver': 'GTiff',
                'count': num_bands,  # 多波段
                'dtype': data.dtype,  # 使用源图像的数据类型
                'crs': 'EPSG:4326',  # Web Mercator 坐标系统
                'transform': transform,
                'width': data.shape[0],  # 图像的宽度
                'height': data.shape[1],  # 图像的高度
                'compress': Compression.lzw  # 使用 LZW 压缩
            }

            # 将数据写入新的 TIFF 文件
            with rasterio.open(out_name, 'w+', **metadata) as dst:
                for i in range(num_bands):
                    dst.write(data[:, :, i], i+1)

            logger.info(f"瓦片 {z}_{x_xyz}_{y_xyz} 下载并保存成功 -> {out_name}")
            pbar.update(1)

        pbar.close()
        pass

    @classmethod
    def from_lon_lat(
            cls,
            min_lat: float,
            max_lat: float,
            min_lon: float,
            max_lon: float,
            zoom: int,
            mk: str = "",
            tk: str = "",
    ) -> "TileDownloader":
        """
        通过经纬度范围构造 TileDownloader。

        Parameters
        ----------
        min_lat, max_lat : float
            纬度范围。
        min_lon, max_lon : float
            经度范围。
        zoom : int
            瓦片缩放等级。
        mk, tk : str
            JL1 接口的 mk / tk 参数。
        """
        bbox = (min_lon, min_lat, max_lon, max_lat)  # (west, south, east, north)
        tile_list: List[Tile] = list(mercantile.tiles(*bbox, zoom))
        return cls(tile_list=tile_list, mk=mk, tk=tk, zoom=zoom)

    @classmethod
    def from_XYZs(
            cls,
            tiles: Iterable[Tile],
            mk: str = "",
            tk: str = "",
    ) -> "TileDownloader":
        """
        通过一组 mercantile.Tile (XYZ) 直接构造 TileDownloader。

        要求：所有 Tile 的 z 一致。
        """
        tile_list = list(tiles)
        if not tile_list:
            raise ValueError("tiles 不能为空。")

        z0 = tile_list[0].z
        if any(t.z != z0 for t in tile_list):
            raise ValueError("from_XYZs 要求所有 Tile 的 z 一致。")

        return cls(tile_list=tile_list, mk=mk, tk=tk, zoom=z0)

    @classmethod
    def from_shp(
            cls,
            shp_path: Union[str, Path],
            zoom: int,
            mk: str = "",
            tk: str = "",
    ) -> "TileDownloader":
        """
        通过一个矢量边界（shapefile）构造 TileDownloader。

        简单实现：使用 shapefile 的外包矩形（bbox）来确定瓦片范围。

        依赖 geopandas：
            pip install geopandas
        """
        from pathlib import Path as _Path

        import geopandas as gpd  # type: ignore

        shp_path = _Path(shp_path)
        gdf = gpd.read_file(shp_path)

        # 假定 shapefile 的坐标系是经纬度（EPSG:4326），否则需要先 reproject
        if gdf.crs is None:
            raise ValueError("shapefile 没有 CRS 信息，请先确保为 EPSG:4326。")
        if gdf.crs.to_epsg() != 4326:
            gdf = gdf.to_crs(epsg=4326)

        minx, miny, maxx, maxy = gdf.total_bounds  # lon/lat
        bbox = (float(minx), float(miny), float(maxx), float(maxy))

        tile_list: List[Tile] = list(mercantile.tiles(*bbox, zoom))
        return cls(tile_list=tile_list, mk=mk, tk=tk, zoom=zoom)



