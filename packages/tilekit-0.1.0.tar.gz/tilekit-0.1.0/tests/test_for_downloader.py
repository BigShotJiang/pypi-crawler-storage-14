from tilekit import TileDownloader

def test1():
    # 北京市区大致范围
    min_lon = 116.98
    max_lon = 117.00      # ← 从 117.85 收缩到 117.20
    min_lat = 39.99
    max_lat = 40.18
    # tk = "67382da79998d9ed086ff100b2d90ee4" # 198
    # tk = "ecc280f93ca3f40bd6492593ab79172e"  # 199
    tk = "8bc303f22da24322364a4bd68eee9a98" # 157
    tk = "c53dc6a1b8df46ed18aceeeb8599e85b" # zyr
    zoom = 18  # 你之前算过，北京城区 ~296078 tiles

    downloader = TileDownloader.from_lon_lat(
        min_lat=min_lat,
        max_lat=max_lat,
        min_lon=min_lon,
        max_lon=max_lon,
        zoom=zoom,
        tk=tk
    )

    print("=== 计算结果 ===")
    print(f"经纬度范围: lon={min_lon}~{max_lon}, lat={min_lat}~{max_lat}")
    print(f"Zoom 级别: {zoom}")
    print(f"总瓦片数量 = 需要请求的次数 = {len(downloader.tile_list)}\n")

    # 示例：真正下载时解除下面这一行注释即可
    downloader.download_tiles(output_folder=r"F:\zpz\datasets\JL1Tiles", verbose_debug=False)


def test2():
    # 北京市区大致范围
    min_lon = 114.98
    max_lon = 117.20      # ← 从 117.85 收缩到 117.20
    min_lat = 38.69
    max_lat = 41.18
    tk = "67382da79998d9ed086ff100b2d90ee4" # zpz 198
    tk = "ecc280f93ca3f40bd6492593ab79172e"  # zpz 199
    tk = "8bc303f22da24322364a4bd68eee9a98" # zpz 157
    tk = "c53dc6a1b8df46ed18aceeeb8599e85b" # zyr
    tk = "4f549776b131398a999e4e6715d426bb" # lyf 150
    tk = "52c35c9c34b4c6cace5f29a0f8435743" # wsx
    tk = "0eeeac1e6fee464958c0ea1536155678" # lyf 131

    tk_list = [
        "67382da79998d9ed086ff100b2d90ee4",
        "ecc280f93ca3f40bd6492593ab79172e",
        "8bc303f22da24322364a4bd68eee9a98",
        "c53dc6a1b8df46ed18aceeeb8599e85b",
    ]
    zoom = 18  # 你之前算过，北京城区 ~296078 tiles
    for tk in tk_list:
        path = r'F:\GIS绘图数据\北京shp\北京.shp'
        downloader = TileDownloader.from_shp(
            shp_path=path,
            zoom=zoom,
            tk=tk
        )

        print("=== 计算结果 ===")
        print(f"经纬度范围: lon={min_lon}~{max_lon}, lat={min_lat}~{max_lat}")
        print(f"Zoom 级别: {zoom}")
        print(f"总瓦片数量 = 需要请求的次数 = {len(downloader.tile_list)}\n")

        # 示例：真正下载时解除下面这一行注释即可
        downloader.download_tiles(output_folder=r"F:\zpz\datasets\JL1Tiles", verbose_debug=False)

if __name__ == "__main__":
    test1()
    test2()