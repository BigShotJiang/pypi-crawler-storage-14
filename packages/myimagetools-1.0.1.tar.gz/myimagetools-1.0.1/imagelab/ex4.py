# Image Difference Operation

import cv2
import numpy as np

image1 = cv2.imread("image1.jpg")
image2 = cv2.imread("image2.jpg")


image1 = cv2.resize(image1, (300, 300))
image2 = cv2.resize(image2, (300, 300))

#    Out(x,y) = abs(M1(x,y) - M2(x,y))
difference = cv2.absdiff(image1, image2)


cv2.imshow("Input Image 1", image1)
cv2.imshow("Input Image 2", image2)
cv2.imshow("Difference Image", difference)

cv2.waitKey(0)
cv2.destroyAllWindows()

# HOG

import cv2
import numpy as np
from skimage.feature import hog
import matplotlib.pyplot as plt

img = cv2.imread("person.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray = cv2.resize(gray, (64, 128))

gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)

magnitude = np.sqrt(gx**2 + gy**2)
orientation = np.arctan2(gy, gx) * (180 / np.pi) % 180  

cell_size = 8
bin_count = 9
h_cells = gray.shape[0] // cell_size
w_cells = gray.shape[1] // cell_size
hist = np.zeros((h_cells, w_cells, bin_count))

for i in range(h_cells):
    for j in range(w_cells):
        cell_mag = magnitude[i*8:(i+1)*8, j*8:(j+1)*8]
        cell_ori = orientation[i*8:(i+1)*8, j*8:(j+1)*8]
        hist[i, j, :], _ = np.histogram(cell_ori, bins=bin_count, range=(0, 180), weights=cell_mag)

block_size = 2 
features = []

for i in range(h_cells - 1):
    for j in range(w_cells - 1):
        block = hist[i:i+block_size, j:j+block_size, :].flatten()
        norm = np.linalg.norm(block) + 1e-6
        features.append(block / norm)

hog_features_manual = np.concatenate(features)
print("\nHOG Feature Length (Manual):", len(hog_features_manual))

hog_features, hog_image = hog(gray, orientations=9,
                              pixels_per_cell=(8,8),
                              cells_per_block=(2,2),
                              visualize=True,
                              block_norm='L2-Hys')

print("HOG Feature Length (Library Output):", len(hog_features))


plt.figure(figsize=(10,4))
plt.subplot(1,2,1), plt.imshow(gray, cmap='gray'), plt.title("Input Image")
plt.subplot(1,2,2), plt.imshow(hog_image, cmap='gray'), plt.title("HOG Visualization")
plt.show()
