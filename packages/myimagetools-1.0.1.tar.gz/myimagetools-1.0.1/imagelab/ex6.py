# SIFT Feature Extraction

import cv2
import numpy as np
from matplotlib import pyplot as plt

img = cv2.imread('thala.jpg', cv2.IMREAD_GRAYSCALE)

sift = cv2.SIFT_create()

keypoints, descriptors = sift.detectAndCompute(img, None)

print(f"Number of keypoints detected: {len(keypoints)}")
print("Example keypoint attributes:")
print(f"Location (x,y): {keypoints[0].pt}")
print(f"Scale (size): {keypoints[0].size}")
print(f"Orientation: {keypoints[0].angle}")
print(f"Response (strength): {keypoints[0].response}")

img_with_orientations = cv2.drawKeypoints(
    img, keypoints, None, flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)

print(f"Descriptor shape: {descriptors.shape}")  # (num_keypoints, 128)
print(f"Sample descriptor (first keypoint):\\n{descriptors[0][:10]} ...")  # show first 10 values

plt.figure(figsize=(10,6))
plt.imshow(img_with_orientations, cmap='gray')
plt.title('SIFT Keypoints with Orientation and Scale')
plt.axis('off')
plt.show()

# Binary Classification (Horse vs Human)

import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt
import numpy as np
from tensorflow.keras import layers, models

train_dir = "horse-or-human/train"
test_dir = "horse-or-human/validation"

img_size = (224,224)
batch = 32


train_gen = ImageDataGenerator()
test_gen = ImageDataGenerator()

train_data = train_gen.flow_from_directory(
    train_dir, target_size=img_size, batch_size=batch, class_mode='binary'
)

test_data = test_gen.flow_from_directory(
    test_dir, target_size=img_size, batch_size=batch, class_mode='binary'
)

print("Training images:", train_data.samples)
print("Testing images:", test_data.samples)

x, y = next(train_data)
class_names = list(train_data.class_indices.keys())

plt.figure(figsize=(7,7))
for i in range(6):
    plt.subplot(2,3,i+1)
    plt.imshow(x[i].astype("uint8"))
    plt.title(class_names[int(y[i])])
    plt.axis("off")
plt.show()


norm_gen = ImageDataGenerator(rescale=1./255)

train_norm = norm_gen.flow_from_directory(
    train_dir, target_size=img_size, batch_size=batch, class_mode='binary'
)

test_norm = norm_gen.flow_from_directory(
    test_dir, target_size=img_size, batch_size=batch, class_mode='binary'
)


base_model = tf.keras.applications.ResNet50(
    weights='imagenet', include_top=False, input_shape=(224,224,3)
)

base_model.trainable = False  # Freeze pretrained layers

model = models.Sequential([
    base_model,
    layers.GlobalAveragePooling2D(),
    layers.Dense(1, activation='sigmoid')
])

model.compile(
    optimizer='adam',
    loss='binary_crossentropy',
    metrics=['accuracy']
)


history = model.fit(train_norm, epochs=5, validation_data=test_norm)


print("\nTraining Accuracy:", history.history['accuracy'][-1])
print("Testing Accuracy:", history.history['val_accuracy'][-1])

plt.figure(figsize=(8,5))
plt.plot(history.history['accuracy'], label="Train Accuracy")
plt.plot(history.history['val_accuracy'], label="Validation Accuracy")
plt.xlabel("Epochs")
plt.ylabel("Accuracy")
plt.title("Training vs Validation Accuracy")
plt.legend()
plt.show()
