"""Utilities used by FastCC."""
