#!/usr/bin/env python3
"""Utility script for validating and packaging Blender extensions."""

import argparse
import logging
import pathlib
import sys

from .blender_wrapper import BlenderWrapper
from .exceptions import BlenderPythonUtilsError

LOGGER = logging.getLogger(__name__)


def configure_logging(level=logging.INFO):
    """
    Configure logging.

    Args:
        level:
            The logging level.
    """
    logging.basicConfig(
        style="{",
        format="[{asctime}] {levelname} {message}",
        datefmt="%Y-%m-%d %H:%M:%S",
        level=level,
    )


class CommandRunner:
    """
    Run selected commands. The only real purpose of this class is to avoid
    redundant subprocess calls to retrieve Blender information.
    """

    def __init__(self):
        self.blender = BlenderWrapper()

    def info(self, _pargs):
        """
        Print Blender information.
        """
        for key, value in sorted(self.blender.info.items()):
            print(f"{key}: {value}")

    def build(self, pargs):
        """
        Validate and build an extension. If a requirements.txt file is found in the
        extension directory then the wheels for its dependencies will be downloaded
        to the wheels directory and the manifest will be updated to include them.
        """
        bld = self.blender
        bld.ext_dir = pargs.path
        bld.download_wheel_deps()
        bld.validate()
        bld.build()

    def pip(self, pargs):
        """
        Install Python packages to Blender's module directory. Additional
        arguments as passed through to pip.
        """
        self.blender.pip(pargs.pip_args, path=pargs.path, uv=pargs.uv)


def main(args=None):
    """
    Main function.

    Args:
        args:
            Passed through to ArgumentParser.parse_args().
    """
    cmd_runner = CommandRunner()

    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(required=True)

    parser_info = subparsers.add_parser("info", description=cmd_runner.info.__doc__)
    parser_info.set_defaults(func=cmd_runner.info)

    parser_build = subparsers.add_parser("build", description=cmd_runner.build.__doc__)
    parser_build.add_argument(
        "-p",
        "--path",
        type=pathlib.Path,
        help=(
            "The path to the extension's root directory. "
            "If not given, the current working directory is assumed."
        ),
    )
    parser_build.set_defaults(func=cmd_runner.build)

    parser_pip = subparsers.add_parser("pip", description=cmd_runner.pip.__doc__)
    parser_pip.add_argument(
        "--path",
        type=pathlib.Path,
        help=(
            "Installation directory for Python packages. "
            "If not given, the default Blender module directory will be used. "
            'Use the "info" command to show the path to the module directory.'
        ),
    )
    parser_pip.add_argument(
        "--uv", action="store_true", help='Use "uv pip" instead of pip.'
    )
    parser_pip.add_argument(
        "pip_args",
        nargs="+",
        help=(
            "Arguments to pass through to pip. "
            'Precede these arguments with "--" if any of them begin with "-".'
        ),
        metavar="<PIP ARG>",
    )
    parser_pip.set_defaults(func=cmd_runner.pip)

    pargs = parser.parse_args(args)
    pargs.func(pargs)


def run_main(*args, **kwargs):
    """
    Run the main function with exception handling.

    Args:
        *args:
            Positional arguments passed through to main().

        **kwargs:
            Keyword arguments passed through to main().
    """
    configure_logging()
    try:
        main(*args, **kwargs)
    except BlenderPythonUtilsError as err:
        sys.exit(err)


if __name__ == "__main__":
    run_main()
