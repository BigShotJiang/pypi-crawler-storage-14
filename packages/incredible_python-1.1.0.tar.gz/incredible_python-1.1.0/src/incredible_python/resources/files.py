"""
Files resource for uploading and managing files.

This module provides file upload capabilities using pre-signed URLs
for secure direct uploads to storage.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, BinaryIO, Dict, List, Optional, Union

from .._base_client import BaseClient


@dataclass
class UploadUrlResponse:
    """
    Response from the upload URL generation endpoint.

    Attributes:
        success: Whether the request was successful
        file_id: Unique identifier for the file (use this in file_ids)
        upload_url: Pre-signed URL to upload the file to
        storage_path: Path where the file will be stored
    """

    success: bool
    file_id: str
    upload_url: str
    storage_path: str


@dataclass
class ConfirmUploadResponse:
    """
    Response from the confirm upload endpoint.

    Attributes:
        success: Whether the upload was confirmed
        file_id: Unique identifier for the file
        filename: Name of the uploaded file
        file_size: Size of the file in bytes
        file_type: Detected file type
        public_url: Public URL to access the file (if available)
    """

    success: bool
    file_id: str
    filename: str
    file_size: int
    file_type: Optional[str] = None
    public_url: Optional[str] = None


@dataclass
class FileMetadata:
    """
    Metadata for an uploaded file.

    Attributes:
        file_id: Unique identifier for the file
        filename: Name of the file
        file_size: Size in bytes
        file_type: Detected file type
        processed_at: When the file was processed
        public_url: Public URL to access the file
    """

    file_id: str
    filename: str
    file_size: int
    file_type: Optional[str] = None
    processed_at: Optional[str] = None
    public_url: Optional[str] = None


@dataclass
class UploadResponse:
    """
    Response from the complete upload helper method.

    Attributes:
        success: Whether the upload completed successfully
        file_id: Unique identifier for the file (use this in file_ids)
        filename: Name of the uploaded file
        file_size: Size of the file in bytes
        file_type: Detected file type
        public_url: Public URL to access the file (if available)
    """

    success: bool
    file_id: str
    filename: str
    file_size: int
    file_type: Optional[str] = None
    public_url: Optional[str] = None


class Files:
    """
    Files resource for uploading and managing files.

    The file upload process is a two-step flow:
    1. Generate a pre-signed upload URL
    2. Upload the file directly to storage
    3. Confirm the upload to process the file

    For convenience, use the `upload()` method which handles all steps.

    Example (simple upload):
        ```python
        from incredible_python import Incredible

        client = Incredible(api_key="your-api-key")

        # Upload a file (handles the full flow)
        result = client.files.upload("path/to/document.pdf")
        print(f"File ID: {result.file_id}")

        # Use the file_id with other endpoints
        response = client.answer(
            query="Summarize this document",
            file_ids=[result.file_id]
        )
        ```

    Example (manual upload flow):
        ```python
        # Step 1: Get upload URL
        url_response = client.files.create_upload_url("document.pdf")

        # Step 2: Upload to the pre-signed URL (using requests or httpx)
        import httpx
        with open("document.pdf", "rb") as f:
            httpx.put(url_response.upload_url, content=f.read())

        # Step 3: Confirm the upload
        confirm_response = client.files.confirm_upload(
            file_id=url_response.file_id,
            filename="document.pdf",
            file_size=1024
        )
        ```
    """

    def __init__(self, client: BaseClient) -> None:
        """
        Initialize the Files resource.

        Args:
            client: The base client instance for making API requests
        """
        self._client = client

    def upload(
        self,
        file: Union[str, Path, BinaryIO],
        filename: Optional[str] = None,
    ) -> UploadResponse:
        """
        Upload a file to Incredible storage.

        This is a convenience method that handles the full upload flow:
        1. Generates a pre-signed upload URL
        2. Uploads the file directly to storage
        3. Confirms the upload

        Args:
            file: Path to the file, Path object, or file-like object
            filename: Optional filename (inferred from path if not provided)

        Returns:
            UploadResponse: Contains file_id to use with other endpoints

        Raises:
            FileNotFoundError: If the file path doesn't exist
            APIError: If the upload fails

        Example:
            ```python
            # Upload from path
            result = client.files.upload("data.csv")
            print(f"Uploaded: {result.file_id}")

            # Upload with custom filename
            result = client.files.upload("temp.csv", filename="sales_data.csv")

            # Use with answer endpoint
            response = client.answer(
                query="Analyze this data",
                file_ids=[result.file_id]
            )
            ```
        """
        import httpx

        # Handle different input types
        if isinstance(file, (str, Path)):
            file_path = Path(file)
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")

            if filename is None:
                filename = file_path.name

            with open(file_path, "rb") as f:
                file_content = f.read()
            file_size = len(file_content)
        else:
            # File-like object
            file_content = file.read()
            file_size = len(file_content)
            if filename is None:
                filename = getattr(file, "name", "uploaded_file")
                if isinstance(filename, str) and "/" in filename:
                    filename = filename.split("/")[-1]

        # Step 1: Get upload URL
        url_response = self.create_upload_url(filename)

        # Step 2: Upload to pre-signed URL
        upload_response = httpx.put(
            url_response.upload_url,
            content=file_content,
            headers={"Content-Type": "application/octet-stream"},
            timeout=300.0,  # 5 minute timeout for large files
        )
        upload_response.raise_for_status()

        # Step 3: Confirm upload
        confirm_response = self.confirm_upload(
            file_id=url_response.file_id,
            filename=filename,
            file_size=file_size,
        )

        return UploadResponse(
            success=confirm_response.success,
            file_id=confirm_response.file_id,
            filename=confirm_response.filename,
            file_size=confirm_response.file_size,
            file_type=confirm_response.file_type,
            public_url=confirm_response.public_url,
        )

    def create_upload_url(self, filename: str) -> UploadUrlResponse:
        """
        Generate a pre-signed URL for file upload.

        This is step 1 of the manual upload flow. After getting the URL,
        upload the file directly to it using PUT request.

        Args:
            filename: Name of the file to upload

        Returns:
            UploadUrlResponse: Contains upload_url and file_id

        Raises:
            ValidationError: If filename is empty
            APIError: If the request fails

        Example:
            ```python
            url_response = client.files.create_upload_url("report.pdf")
            print(f"Upload to: {url_response.upload_url}")
            print(f"File ID: {url_response.file_id}")
            ```
        """
        response = self._client.request(
            "POST",
            "/v1/files/upload-url",
            json={"filename": filename},
        )
        data = response.json()

        return UploadUrlResponse(
            success=data.get("success", False),
            file_id=data.get("file_id", ""),
            upload_url=data.get("upload_url", ""),
            storage_path=data.get("storage_path", ""),
        )

    def confirm_upload(
        self,
        file_id: str,
        filename: str,
        file_size: int,
    ) -> ConfirmUploadResponse:
        """
        Confirm that a file was uploaded and process it.

        This is step 3 of the manual upload flow. Call this after
        uploading the file to the pre-signed URL.

        Args:
            file_id: File ID from create_upload_url response
            filename: Name of the uploaded file
            file_size: Size of the file in bytes

        Returns:
            ConfirmUploadResponse: Confirmation with file metadata

        Raises:
            ValidationError: If required fields are missing
            APIError: If the confirmation fails

        Example:
            ```python
            confirm = client.files.confirm_upload(
                file_id="abc123",
                filename="report.pdf",
                file_size=1048576
            )
            print(f"Confirmed: {confirm.success}")
            ```
        """
        response = self._client.request(
            "POST",
            "/v1/files/confirm-upload",
            json={
                "file_id": file_id,
                "filename": filename,
                "file_size": file_size,
            },
        )
        data = response.json()

        return ConfirmUploadResponse(
            success=data.get("success", False),
            file_id=data.get("file_id", file_id),
            filename=data.get("filename", filename),
            file_size=data.get("file_size", file_size),
            file_type=data.get("file_type"),
            public_url=data.get("public_url"),
        )

    def get_metadata(
        self,
        file_ids: List[str],
        user_id: str,
    ) -> List[FileMetadata]:
        """
        Get metadata for multiple files.

        Args:
            file_ids: List of file IDs to get metadata for
            user_id: User ID who owns the files

        Returns:
            List of FileMetadata objects

        Raises:
            ValidationError: If required fields are missing
            APIError: If the request fails

        Example:
            ```python
            metadata = client.files.get_metadata(
                file_ids=["file-1", "file-2"],
                user_id="user-123"
            )
            for file in metadata:
                print(f"{file.filename}: {file.file_size} bytes")
            ```
        """
        response = self._client.request(
            "POST",
            "/v1/files/metadata",
            json={
                "file_ids": file_ids,
                "user_id": user_id,
            },
        )
        data = response.json()

        if isinstance(data, list):
            return [
                FileMetadata(
                    file_id=item.get("file_id", ""),
                    filename=item.get("filename", ""),
                    file_size=item.get("file_size", 0),
                    file_type=item.get("file_type"),
                    processed_at=item.get("processed_at"),
                    public_url=item.get("public_url"),
                )
                for item in data
            ]
        return []

