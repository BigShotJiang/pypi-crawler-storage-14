"""
Research resource wrapper for web search and deep research.
Provides a unified interface for research operations.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .web_search import WebSearch, WebSearchResponse
from .deep_research import DeepResearch, DeepResearchResponse


class Research:
    """
    Research resource combining web search and deep research.
    
    This resource can be called directly for web search, or use specific methods.
    
    Example:
        ```python
        # Direct call (defaults to web search)
        results = client.research(query="Python tutorials", num_results=10)
        
        # Explicit web search
        results = client.research.web_search(query="Python tutorials")
        
        # Deep research
        report = client.research.deep_research(
            instructions="Research the impact of AI on education"
        )
        ```
    """
    
    def __init__(self, client) -> None:
        self._client = client
        self._web_search = WebSearch(client)
        self._deep_research = DeepResearch(client)
    
    def __call__(
        self,
        query: str,
        **kwargs
    ) -> WebSearchResponse:
        """
        Shorthand for web_search() - allows calling client.research(...) directly.
        
        Args:
            query: Search query
            **kwargs: Additional arguments passed to web_search
        
        Returns:
            WebSearchResponse: Search results
        
        Example:
            ```python
            # Instead of client.research.web_search(...)
            results = client.research(query="Python tutorials", num_results=10)
            ```
        """
        return self._web_search(query=query, **kwargs)
    
    def web_search(
        self,
        query: str,
        **kwargs
    ) -> WebSearchResponse:
        """
        Perform web search using Exa.AI.
        
        Args:
            query: Search query
            **kwargs: Additional search parameters
        
        Returns:
            WebSearchResponse: Search results
        """
        return self._web_search(query=query, **kwargs)
    
    def deep_research(
        self,
        instructions: str,
        **kwargs
    ) -> DeepResearchResponse:
        """
        Perform deep research with multi-step analysis.
        
        Args:
            instructions: Research task description
            **kwargs: Additional research parameters
        
        Returns:
            DeepResearchResponse: Research report with citations
        """
        return self._deep_research(instructions=instructions, **kwargs)

