"""
Integration tests for the Agent resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/integration/test_agent.py -v
"""

import os

import pytest

from incredible_python import Incredible
from incredible_python.resources.agent import AgentResponse, ToolCall


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    return Incredible(api_key=api_key, base_url=base_url)


@pytest.fixture
def sample_tools():
    """Sample tools for testing."""
    return [
        {
            "name": "get_weather",
            "description": "Get current weather for a location",
            "input_schema": {
                "type": "object",
                "properties": {
                    "location": {"type": "string", "description": "City name"},
                    "units": {
                        "type": "string",
                        "enum": ["celsius", "fahrenheit"],
                        "description": "Temperature units",
                    },
                },
                "required": ["location"],
            },
        },
        {
            "name": "calculator",
            "description": "Perform mathematical calculations",
            "input_schema": {
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "description": "Mathematical expression to evaluate",
                    }
                },
                "required": ["expression"],
            },
        },
    ]


class TestAgentNonStreaming:
    """Test non-streaming agent endpoint."""

    def test_simple_agent_call(self, client, sample_tools):
        """Test simple agent conversation without tool calling."""
        response = client.agent(
            messages=[
                {
                    "role": "user",
                    "content": "Hello! Just say hi back without using any tools.",
                }
            ],
            tools=sample_tools,
        )

        assert isinstance(response, AgentResponse)
        assert response.success is True
        assert isinstance(response.response, str)
        assert len(response.response) > 0
        print(f"\n✓ Simple agent call: {response.response[:100]}...")

    def test_agent_with_tool_call(self, client, sample_tools):
        """Test agent that should invoke tools."""
        response = client.agent(
            messages=[
                {
                    "role": "user",
                    "content": "What's the weather like in Tokyo? Please use the get_weather tool.",
                }
            ],
            tools=sample_tools,
        )

        assert isinstance(response, AgentResponse)
        assert response.success is True

        # Check if tool calls were made
        if response.tool_calls:
            print(f"\n✓ Tool calls made: {len(response.tool_calls)}")
            for call in response.tool_calls:
                assert isinstance(call, ToolCall)
                assert hasattr(call, "id")
                assert hasattr(call, "name")
                assert hasattr(call, "inputs")
                print(f"  - {call.name}: {call.inputs}")
        else:
            print("\n⚠ No tool calls made (model chose not to use tools)")

    def test_agent_with_system_prompt(self, client, sample_tools):
        """Test agent with custom system prompt."""
        response = client.agent(
            messages=[
                {
                    "role": "user",
                    "content": "Calculate 25 * 4 using the calculator tool.",
                }
            ],
            tools=sample_tools,
            system_prompt="You are a helpful assistant. Always use tools when appropriate.",
        )

        assert isinstance(response, AgentResponse)
        assert response.success is True
        print(f"\n✓ With system prompt: {response.response[:100]}...")

    def test_callable_shorthand(self, client, sample_tools):
        """Test that callable shorthand works."""
        response = client.agent(
            messages=[{"role": "user", "content": "Tell me a joke (no tools needed)."}],
            tools=sample_tools,
        )

        assert isinstance(response, AgentResponse)
        assert response.success is True
        assert len(response.response) > 0
        print(f"\n✓ Callable shorthand: {response.response[:50]}...")


class TestAgentStreaming:
    """Test streaming agent endpoint."""

    def test_streaming_simple(self, client, sample_tools):
        """Test streaming with a simple agent conversation."""
        stream = client.agent(
            messages=[
                {
                    "role": "user",
                    "content": "Explain what you can do for me. Keep it brief.",
                }
            ],
            tools=sample_tools,
            stream=True,
        )

        # Collect all events
        events = []
        content_chunks = []
        thinking_chunks = []
        tool_calls = []

        for event in stream:
            events.append(event)

            if "content" in event:
                content_chunks.append(event["content"])
                print(".", end="", flush=True)
            elif "thinking" in event:
                thinking_chunks.append(event["thinking"])
            elif "tool_call" in event:
                tool_calls.append(event["tool_call"])
                print(f"\n✓ Tool call: {event['tool_call'].get('name')}")
            elif "tokens" in event:
                print(f"\n✓ Tokens: {event['tokens']}")
            elif "done" in event:
                print("\n✓ Stream completed")
            elif "error" in event:
                print(f"\n⚠ Error event: {event['error']}")

        # Assertions
        assert len(events) > 0, "Should receive at least one event"

        full_content = "".join(content_chunks)
        if full_content:
            print(f"\n✓ Full content: {full_content[:100]}...")

    def test_streaming_with_tool_request(self, client, sample_tools):
        """Test streaming when agent might call tools."""
        stream = client.agent(
            messages=[
                {
                    "role": "user",
                    "content": "What's 15 multiplied by 8? Use the calculator if you want.",
                }
            ],
            tools=sample_tools,
            stream=True,
        )

        has_content = False
        has_thinking = False
        has_tool_call = False
        has_done = False

        for event in stream:
            if "thinking" in event:
                has_thinking = True
            elif "content" in event:
                has_content = True
            elif "tool_call" in event:
                has_tool_call = True
                print(f"\n✓ Tool call in stream: {event['tool_call'].get('name')}")
            elif "done" in event:
                has_done = True

        print(
            f"\n✓ Streaming with tools: content={has_content}, thinking={has_thinking}, tool_call={has_tool_call}, done={has_done}"
        )
        # At minimum we should receive some data
        assert has_content or has_thinking or has_tool_call, "Should receive some data"

    def test_stream_chat_method(self, client, sample_tools):
        """Test the dedicated stream_chat method."""
        stream = client.agent.stream_chat(
            messages=[{"role": "user", "content": "Count to 3 briefly."}],
            tools=sample_tools,
        )

        event_count = 0
        for event in stream:
            event_count += 1
            if "content" in event:
                print(".", end="", flush=True)

        print(f"\n✓ stream_chat method: {event_count} events")
        assert event_count > 0, "Should receive events"

    def test_streaming_type_safety(self, client, sample_tools):
        """Test that streaming returns properly typed events."""
        stream = client.agent(
            messages=[{"role": "user", "content": "Say hello."}],
            tools=sample_tools,
            stream=True,
        )

        # Type checker should recognize these as AgentStreamEvent
        for event in stream:
            # All valid event keys according to AgentStreamEvent TypedDict
            valid_keys = {"thinking", "content", "tool_call", "tokens", "done", "error"}
            event_keys = set(event.keys())

            assert event_keys.issubset(
                valid_keys
            ), f"Event has unexpected keys: {event_keys - valid_keys}"

            # Verify types of known keys
            if "content" in event:
                assert isinstance(event["content"], str)
            if "thinking" in event:
                assert isinstance(event["thinking"], str)
            if "tool_call" in event:
                assert isinstance(event["tool_call"], dict)
            if "tokens" in event:
                assert isinstance(event["tokens"], int)
            if "done" in event:
                assert event["done"] is True
            if "error" in event:
                assert isinstance(event["error"], str)

            # Break after first event to keep test fast
            break

        print("\n✓ Streaming events are properly typed")


class TestAgentErrorHandling:
    """Test error handling and edge cases."""

    def test_empty_messages_fails(self, client, sample_tools):
        """Test that empty messages list is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.agent(messages=[], tools=sample_tools)

        print(f"\n✓ Empty messages rejected: {exc_info.value}")

    def test_empty_tools_fails(self, client):
        """Test that empty tools list is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.agent(messages=[{"role": "user", "content": "Test"}], tools=[])

        print(f"\n✓ Empty tools rejected: {exc_info.value}")

    def test_invalid_tool_format(self, client):
        """Test that invalid tool format is rejected."""
        invalid_tools = [
            {"name": "bad_tool"}  # Missing description and input_schema
        ]

        with pytest.raises(Exception) as exc_info:
            client.agent(
                messages=[{"role": "user", "content": "Test"}], tools=invalid_tools
            )

        print(f"\n✓ Invalid tool format rejected: {exc_info.value}")

    def test_invalid_message_role(self, client, sample_tools):
        """Test that invalid role is rejected."""
        with pytest.raises(Exception):
            client.agent(
                messages=[
                    {"role": "system", "content": "Test"}  # Invalid role
                ],
                tools=sample_tools,
            )

        print("\n✓ Invalid role rejected")


class TestAgentMultiTurn:
    """Test multi-turn agent conversations."""

    def test_multi_turn_conversation(self, client, sample_tools):
        """Test multi-turn conversation with agent."""
        response = client.agent(
            messages=[
                {"role": "user", "content": "I need help with weather."},
                {
                    "role": "assistant",
                    "content": "I can help you check the weather. Which city?",
                },
                {"role": "user", "content": "Paris, France"},
            ],
            tools=sample_tools,
        )

        assert isinstance(response, AgentResponse)
        assert response.success is True
        print(f"\n✓ Multi-turn conversation: {response.response[:100]}...")

        if response.tool_calls:
            print(f"  Tool calls: {[call.name for call in response.tool_calls]}")


if __name__ == "__main__":
    # Allow running directly for quick testing
    print("Running integration tests for Agent resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
