"""
Integration tests for the Videos resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/test_videos.py -v
"""

import os

import pytest

from incredible_python import Incredible
from incredible_python._exceptions import ValidationError
from incredible_python.resources.videos import VideoGenerationResponse


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    return Incredible(api_key=api_key, base_url=base_url)


class TestVideos:
    """Test video generation endpoint."""

    def test_validation_error(self, client):
        """Test validation before API call."""
        with pytest.raises(ValidationError):
            client.generate_video(prompt="")

        with pytest.raises(ValidationError):
            client.generate_video(prompt="test", size="invalid")

        print("\n✓ Validation working correctly")

    # Video generation is expensive and slow, so we might skip it by default
    # or mark it as slow. For now, we'll include a test that is skipped unless
    # explicitly enabled or if we want to test it.
    # But keeping consistent with others, we'll put it here but maybe commented out or
    # strictly limited.

    @pytest.mark.skip(reason="Video generation is slow and expensive")
    def test_generate_video(self, client):
        """Test video generation."""
        response = client.generate_video(
            prompt="A simple red ball bouncing", size="1280x720"
        )

        assert isinstance(response, VideoGenerationResponse)
        assert response.success is True
        print(f"\n✓ Video generation started/completed: {response.status}")


if __name__ == "__main__":
    print("Running integration tests for Videos resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
