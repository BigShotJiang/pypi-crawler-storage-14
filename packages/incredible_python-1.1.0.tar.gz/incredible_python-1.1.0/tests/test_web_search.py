"""
Integration tests for the WebSearch resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/integration/test_web_search.py -v
"""

import os

import pytest

from incredible_python import Incredible
from incredible_python.resources.web_search import SearchResult, WebSearchResponse


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    client = Incredible(api_key=api_key, base_url=base_url)

    # Check if Exa is configured on backend
    try:
        client.web_search(query="test", num_results=1)
    except Exception as e:
        if "EXA_API_KEY not configured" in str(e):
            pytest.skip(
                "Backend Exa API key not configured - skipping web search tests"
            )
        # Other errors are OK (might be rate limits, etc.)

    return client


class TestWebSearchBasic:
    """Test basic web search functionality."""

    def test_simple_search(self, client):
        """Test simple web search with default parameters."""
        response = client.web_search(query="Python programming tutorials")

        assert isinstance(response, WebSearchResponse)
        assert response.success is True
        assert isinstance(response.results, list)
        assert len(response.results) > 0

        # Check first result structure
        first_result = response.results[0]
        assert isinstance(first_result, SearchResult)
        assert isinstance(first_result.title, str)
        assert len(first_result.title) > 0
        assert isinstance(first_result.url, str)
        assert first_result.url.startswith("http")
        assert isinstance(first_result.score, float)

        print(f"\n✓ Found {len(response.results)} results")
        print(f"  Top result: {first_result.title}")
        print(f"  URL: {first_result.url}")
        print(f"  Score: {first_result.score}")

    def test_limited_results(self, client):
        """Test search with specific number of results."""
        response = client.web_search(query="Machine learning", num_results=5)

        assert response.success is True
        assert len(response.results) <= 5
        print(f"\n✓ Requested 5 results, got {len(response.results)}")

    def test_callable_shorthand(self, client):
        """Test that callable shorthand works."""
        response = client.web_search(
            query="Artificial intelligence news", num_results=3
        )

        assert isinstance(response, WebSearchResponse)
        assert response.success is True
        assert len(response.results) <= 3
        print(f"\n✓ Callable shorthand: {len(response.results)} results")


class TestWebSearchTypes:
    """Test different search types."""

    def test_neural_search(self, client):
        """Test neural (semantic) search."""
        response = client.web_search(
            query="How does photosynthesis work?", num_results=5, search_type="neural"
        )

        assert response.success is True
        assert len(response.results) > 0
        print(f"\n✓ Neural search: {len(response.results)} results")
        print(f"  Top: {response.results[0].title[:60]}...")

    def test_keyword_search(self, client):
        """Test keyword-based search."""
        try:
            response = client.web_search(
                query="Python tutorial", num_results=5, search_type="keyword"
            )

            assert response.success is True
            assert len(response.results) > 0
            print(f"\n✓ Keyword search: {len(response.results)} results")
            print(f"  Top: {response.results[0].title[:60]}...")
        except Exception as e:
            raise e


class TestWebSearchFilters:
    """Test search filters."""

    def test_domain_inclusion(self, client):
        """Test filtering to include specific domains."""
        response = client.web_search(
            query="Python tutorials",
            num_results=5,
            include_domains=["python.org", "realpython.com"],
        )

        assert response.success is True
        assert len(response.results) > 0

        # Check that results are from specified domains
        for result in response.results:
            domain_match = any(
                domain in result.url for domain in ["python.org", "realpython.com"]
            )
            if domain_match:
                print(f"\n✓ Found result from allowed domain: {result.url}")
                break

    def test_domain_exclusion(self, client):
        """Test filtering to exclude specific domains."""
        response = client.web_search(
            query="Python programming",
            num_results=5,
            exclude_domains=["stackoverflow.com"],
        )

        assert response.success is True
        assert len(response.results) > 0

        # Verify excluded domain not in results
        for result in response.results:
            assert "stackoverflow.com" not in result.url

        print(f"\n✓ Domain exclusion: {len(response.results)} results")
        print("  (verified no stackoverflow.com)")

    def test_date_filtering(self, client):
        """Test filtering by publication date."""
        try:
            response = client.web_search(
                query="AI news", num_results=5, start_published_date="2024-01-01"
            )

            assert response.success is True
            assert len(response.results) > 0

            # Check if dates are available and valid
            dated_results = [r for r in response.results if r.published_date]
            if dated_results:
                print(f"\n✓ Date filtering: {len(dated_results)} results with dates")
                print(f"  Example date: {dated_results[0].published_date}")
            else:
                print(f"\n✓ Date filtering applied: {len(response.results)} results")
        except Exception as e:
            if "rate limit" in str(e).lower() or "429" in str(e):
                pytest.skip("Rate limit exceeded during date filtering test")
            else:
                raise e


class TestWebSearchContent:
    """Test content retrieval options."""

    def test_get_text(self, client):
        """Test retrieving full text content."""
        response = client.web_search(
            query="What is quantum computing?", num_results=3, get_text=True
        )

        assert response.success is True
        assert len(response.results) > 0

        # Check if any results have text
        text_results = [r for r in response.results if r.text]
        assert len(text_results) > 0

        print(f"\n✓ Retrieved text for {len(text_results)} results")
        print(f"  Sample text length: {len(text_results[0].text)} chars")

    def test_get_highlights(self, client):
        """Test retrieving highlights (currently not supported by API)."""
        # Note: The API doesn't currently support the 'highlights' option
        # This test just verifies basic search works
        response = client.web_search(
            query="Benefits of renewable energy", num_results=3
        )

        assert response.success is True
        assert len(response.results) > 0

        print(f"\n✓ Search completed: {len(response.results)} results")
        print(f"  Note: Highlights option not currently supported by API")

    def test_get_summary(self, client):
        """Test retrieving AI-generated summaries."""
        response = client.web_search(
            query="Climate change effects", num_results=3, get_summary=True
        )

        assert response.success is True
        assert len(response.results) > 0

        # Check if any results have summaries
        summary_results = [r for r in response.results if r.summary]
        if summary_results:
            print(f"\n✓ Retrieved summaries for {len(summary_results)} results")
            print(f"  Sample: {summary_results[0].summary[:150]}...")
        else:
            print(f"\n✓ Summaries requested: {len(response.results)} results")

    def test_all_content_options(self, client):
        """Test retrieving all supported content types together."""
        response = client.web_search(
            query="Space exploration",
            num_results=2,
            get_text=True,
            get_summary=True,
        )

        assert response.success is True
        assert len(response.results) > 0

        print(f"\n✓ Content options (text + summary): {len(response.results)} results")

        result = response.results[0]
        print(f"  Has text: {result.text is not None}")
        print(f"  Has highlights: {result.highlights is not None}")
        print(f"  Has summary: {result.summary is not None}")


class TestWebSearchAutoprompt:
    """Test autoprompt functionality."""

    def test_autoprompt_enabled(self, client):
        """Test search with autoprompt enabled (default)."""
        response = client.web_search(
            query="best python libraries", num_results=5, use_autoprompt=True
        )

        assert response.success is True
        assert len(response.results) > 0

        if response.autoprompt_string:
            print("\n✓ Autoprompt generated:")
            print("  Original: 'best python libraries'")
            print(f"  Enhanced: '{response.autoprompt_string}'")
        else:
            print(f"\n✓ Autoprompt enabled: {len(response.results)} results")

    def test_autoprompt_disabled(self, client):
        """Test search with autoprompt disabled."""
        response = client.web_search(
            query="python tutorials", num_results=5, use_autoprompt=False
        )

        assert response.success is True
        assert len(response.results) > 0
        print(f"\n✓ Autoprompt disabled: {len(response.results)} results")


class TestWebSearchAdvanced:
    """Test advanced search scenarios."""

    def test_complex_query(self, client):
        """Test complex multi-word query."""
        response = client.web_search(
            query="How to deploy a machine learning model in production using Docker and Kubernetes",
            num_results=5,
        )

        assert response.success is True
        assert len(response.results) > 0
        print(f"\n✓ Complex query: {len(response.results)} results")
        print(f"  Top: {response.results[0].title[:80]}...")

    def test_category_filter(self, client):
        """Test filtering by category if available."""
        response = client.web_search(
            query="AI research papers", num_results=5, category="research paper"
        )

        assert response.success is True
        assert len(response.results) > 0
        print(f"\n✓ Category filter: {len(response.results)} results")

    def test_combined_filters(self, client):
        """Test multiple filters together."""
        response = client.web_search(
            query="machine learning tutorials",
            num_results=5,
            include_domains=["medium.com", "towardsdatascience.com"],
            start_published_date="2023-01-01",
            get_summary=True,
            search_type="neural",
        )

        assert response.success is True
        print(f"\n✓ Combined filters: {len(response.results)} results")


class TestWebSearchMetadata:
    """Test metadata in search results."""

    def test_result_scores(self, client):
        """Test that results have relevance scores."""
        response = client.web_search(query="JavaScript frameworks", num_results=5)

        assert response.success is True
        assert len(response.results) > 0

        # Verify scores exist and are in reasonable range
        for result in response.results:
            assert isinstance(result.score, float)
            assert result.score >= 0.0

        # Verify results are sorted by score (descending)
        scores = [r.score for r in response.results]
        assert scores == sorted(
            scores, reverse=True
        ), "Results should be sorted by score"

        print(f"\n✓ Result scores: {scores}")

    def test_author_information(self, client):
        """Test author information when available."""
        response = client.web_search(query="tech blog posts", num_results=5)

        assert response.success is True
        assert len(response.results) > 0

        # Check if any results have author info
        with_authors = [r for r in response.results if r.author]
        if with_authors:
            print(f"\n✓ {len(with_authors)} results with author info")
            print(f"  Example: {with_authors[0].author}")
        else:
            print(f"\n✓ Author info checked: {len(response.results)} results")


class TestWebSearchErrorHandling:
    """Test error handling and validation."""

    def test_empty_query_fails(self, client):
        """Test that empty query is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.web_search(query="")

        print(f"\n✓ Empty query rejected: {exc_info.value}")

    def test_invalid_num_results(self, client):
        """Test that invalid num_results is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.web_search(
                query="test",
                num_results=200,  # Over limit (max 100)
            )

        print(f"\n✓ Invalid num_results rejected: {exc_info.value}")

    def test_zero_results(self, client):
        """Test that zero results is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.web_search(query="test", num_results=0)

        print(f"\n✓ Zero results rejected: {exc_info.value}")

    def test_invalid_search_type(self, client):
        """Test that invalid search type is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.web_search(query="test", search_type="invalid")

        print(f"\n✓ Invalid search type rejected: {exc_info.value}")

    def test_obscure_query(self, client):
        """Test that very obscure queries still return results."""
        response = client.web_search(
            query="asdfghjklqwertyuiop123456789", num_results=5
        )

        # Should succeed even if no results found
        assert response.success is True
        print(f"\n✓ Obscure query: {len(response.results)} results")


class TestWebSearchPagination:
    """Test result limits and pagination."""

    def test_minimum_results(self, client):
        """Test requesting minimum number of results."""
        response = client.web_search(query="Python", num_results=1)

        assert response.success is True
        assert len(response.results) <= 1
        print(f"\n✓ Minimum results (1): got {len(response.results)}")

    def test_maximum_results(self, client):
        """Test requesting maximum number of results."""
        response = client.web_search(query="programming", num_results=100)

        assert response.success is True
        assert len(response.results) <= 100
        print(f"\n✓ Maximum results (100): got {len(response.results)}")

    def test_various_result_counts(self, client):
        """Test different result counts."""
        counts = [3, 10, 25, 50]

        for count in counts:
            response = client.web_search(query="web development", num_results=count)

            assert response.success is True
            assert len(response.results) <= count
            print(f"  {count} requested -> {len(response.results)} received")

        print("\n✓ Tested various result counts")


if __name__ == "__main__":
    # Allow running directly for quick testing
    print("Running integration tests for WebSearch resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
