"""
Integration tests for the Integrations resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/test_integrations.py -v
"""

import os

import pytest

from incredible_python import Incredible


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    return Incredible(api_key=api_key, base_url=base_url)


class TestIntegrations:
    """Test integrations endpoint."""

    def test_list_integrations(self, client):
        """Test listing available integrations."""
        response = client.integrations.list()

        assert isinstance(response, list)
        print(f"\n✓ Found {len(response)} integrations")
        if len(response) > 0:
            first = response[0]
            print(f"  Sample: {first.get('name', 'Unknown')}")

    def test_retrieve_integration_not_found(self, client):
        """Test retrieving a non-existent integration."""
        # Assuming 'non_existent_id' doesn't exist
        try:
            client.integrations.retrieve("non_existent_id")
        except Exception as e:
            # We expect an error here, likely 404
            print(f"\n✓ Correctly failed to retrieve invalid integration: {e}")

    @pytest.mark.skip(reason="Requires a valid integration ID to test connect/execute")
    def test_connect_integration(self, client):
        """Test connecting to an integration."""
        # This needs a real integration ID
        pass


if __name__ == "__main__":
    print("Running integration tests for Integrations resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
