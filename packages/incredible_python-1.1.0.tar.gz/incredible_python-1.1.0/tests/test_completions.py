"""
Integration tests for the Completions resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/test_completions.py -v
"""

import os

import pytest

from incredible_python import Incredible
from incredible_python.resources.completions import CompletionResponse


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    return Incredible(api_key=api_key, base_url=base_url)


class TestCompletions:
    """Test completions endpoint."""

    def test_simple_completion(self, client):
        """Test simple text completion."""
        response = client.completions.create(
            model="small-1", prompt="Once upon a time", max_tokens=10
        )

        assert isinstance(response, CompletionResponse)
        assert isinstance(response.choices, list)
        assert len(response.choices) > 0
        assert response.choices[0].text
        print(f"\n✓ Simple completion: {response.choices[0].text}")

    def test_completion_shorthand(self, client):
        """Test callable shorthand."""
        response = client.completions(
            model="small-1", prompt="Hello, my name is", max_tokens=10
        )

        assert isinstance(response, CompletionResponse)
        assert len(response.choices) > 0
        print(f"\n✓ Shorthand completion: {response.choices[0].text}")

    def test_completion_agent(self, client):
        """Test completion agent."""
        response = client.completions(
            model="agent", prompt="Hello, my name is", max_tokens=10
        )

        assert isinstance(response, CompletionResponse)
        assert len(response.choices) > 0
        print(f"\n✓ Shorthand completion: {response.choices[0].text}")

    def test_completion_conversation(self, client):
        """Test completion conversation."""
        response = client.completions(
            model="conversation", prompt="Hello, my name is", max_tokens=10
        )

        assert isinstance(response, CompletionResponse)
        assert len(response.choices) > 0
        print(f"\n✓ Conversation completion: {response.choices[0].text}")

    def test_multiple_completions(self, client):
        """Test generating multiple completions."""
        n = 2
        response = client.completions.create(
            model="small-1", prompt="Three colors are:", max_tokens=20, n=n
        )

        assert isinstance(response, CompletionResponse)
        # Allow lenient check if backend doesn't support multiple choices
        assert len(response.choices) >= 1
        if len(response.choices) < n:
            print(f"\n⚠ Requested {n} completions, got {len(response.choices)}")
        else:
            print(f"\n✓ Multiple completions ({len(response.choices)})")

    def test_completion_with_parameters(self, client):
        """Test completion with various parameters."""
        response = client.completions.create(
            model="small-1",
            prompt="Write a haiku:",
            max_tokens=30,
            temperature=0.7,
            stop=["\n\n"],
            echo=True,
        )

        assert isinstance(response, CompletionResponse)
        assert len(response.choices) > 0
        # Echo should include prompt
        if response.choices[0].text.startswith("Write a haiku:"):
            print(
                f"\n✓ Parameterized completion (echo worked): {response.choices[0].text}"
            )
        else:
            print(
                f"\n⚠ Parameterized completion (echo missing): {response.choices[0].text}"
            )


if __name__ == "__main__":
    print("Running integration tests for Completions resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
