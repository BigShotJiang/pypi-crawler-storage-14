"""
Integration tests for the Models resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/test_models.py -v
"""

import os

import pytest

from incredible_python import Incredible


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    return Incredible(api_key=api_key, base_url=base_url)


class TestModels:
    """Test models endpoint."""

    def test_list_models(self, client):
        """Test listing available models."""
        response = client.models.list()

        # Response depends on API structure, usually a dict with 'data' list or just a list
        assert isinstance(response, (dict, list))
        print(f"\n✓ Models list response type: {type(response)}")

        # If it's a standard list response
        if isinstance(response, dict) and "data" in response:
            models = response["data"]
            print(f"✓ Found {len(models)} models")
            if len(models) > 0:
                print(f"  Sample: {models[0]}")


if __name__ == "__main__":
    print("Running integration tests for Models resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
