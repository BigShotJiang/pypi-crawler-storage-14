"""
Integration tests for the DeepResearch resource.

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Note: Deep research tests take longer (up to 10 minutes per test) and consume more credits.

Run with: pytest tests/integration/test_deep_research.py -v -s
"""

import os

import pytest

from incredible_python import Incredible
from incredible_python.resources.deep_research import Citation, DeepResearchResponse


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    client = Incredible(api_key=api_key, base_url=base_url)

    # Check if Exa is configured on backend
    try:
        client.deep_research(
            instructions="test",
            timeout=5.0,  # Short timeout for check
        )
    except Exception:
        # Other errors might be OK
        pass

    return client


class TestDeepResearchBasic:
    """Test basic deep research functionality."""

    @pytest.mark.slow
    def test_simple_research(self, client):
        """Test simple research with default parameters."""
        response = client.deep_research(
            instructions="Give me a brief overview of Python's history. Keep it to 2-3 sentences."
        )

        assert isinstance(response, DeepResearchResponse)
        assert response.success is True
        assert isinstance(response.research_id, str)
        assert len(response.research_id) > 0
        assert isinstance(response.status, str)
        assert isinstance(response.output, dict)
        assert len(response.output) > 0

        print("\n✓ Research completed")
        print(f"  Research ID: {response.research_id}")
        print(f"  Status: {response.status}")
        print(f"  Output keys: {list(response.output.keys())}")

        if response.citations:
            print(f"  Citations: {len(response.citations)}")
            if response.citations:
                print(f"    Example: {response.citations[0].title}")

        if response.searches_performed:
            print(f"  Searches performed: {response.searches_performed}")
        if response.pages_read:
            print(f"  Pages read: {response.pages_read}")

    @pytest.mark.slow
    def test_callable_shorthand(self, client):
        """Test that callable shorthand works."""
        response = client.deep_research(
            instructions="Summarize what TypeScript is in one sentence."
        )

        assert isinstance(response, DeepResearchResponse)
        assert response.success is True
        assert len(response.research_id) > 0
        print(f"\n✓ Callable shorthand: {response.research_id}")


class TestDeepResearchStructured:
    """Test structured output with schemas."""

    @pytest.mark.slow
    def test_structured_output_simple(self, client):
        """Test research with simple structured output schema."""
        schema = {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "year_created": {"type": "number"},
            },
            "required": ["summary"],
        }

        response = client.deep_research(
            instructions="Research when Python was created and provide a brief summary.",
            output_schema=schema,
        )

        assert response.success is True
        assert isinstance(response.output, dict)
        
        # API returns {'content': '...', 'parsed': {...}} structure
        parsed_output = response.output.get('parsed', response.output)
        
        assert "summary" in parsed_output
        assert isinstance(parsed_output["summary"], str)

        print("\n✓ Structured output (simple):")
        print(f"  Summary: {parsed_output.get('summary', '')[:100]}...")
        if "year_created" in parsed_output:
            print(f"  Year: {parsed_output['year_created']}")

    @pytest.mark.slow
    def test_structured_output_complex(self, client):
        """Test research with complex nested schema."""
        schema = {
            "type": "object",
            "properties": {
                "overview": {"type": "string"},
                "key_features": {"type": "array", "items": {"type": "string"}},
                "creator": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "nationality": {"type": "string"},
                    },
                },
            },
            "required": ["overview", "key_features"],
        }

        response = client.deep_research(
            instructions="Research Python programming language: overview, key features, and creator information.",
            output_schema=schema,
        )

        assert response.success is True
        
        # API returns {'content': '...', 'parsed': {...}} structure
        parsed_output = response.output.get('parsed', response.output)
        
        assert "overview" in parsed_output
        assert "key_features" in parsed_output
        assert isinstance(parsed_output["key_features"], list)

        print("\n✓ Structured output (complex):")
        print(f"  Overview: {parsed_output['overview'][:80]}...")
        print(f"  Key features: {len(parsed_output['key_features'])} items")
        if "creator" in parsed_output:
            print(f"  Creator: {parsed_output['creator']}")

    @pytest.mark.slow
    def test_structured_with_arrays(self, client):
        """Test schema with array of objects."""
        schema = {
            "type": "object",
            "properties": {
                "frameworks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "description": {"type": "string"},
                        },
                    },
                }
            },
            "required": ["frameworks"],
        }

        response = client.deep_research(
            instructions="List 3 popular Python web frameworks with brief descriptions.",
            output_schema=schema,
        )

        assert response.success is True
        
        # API returns {'content': '...', 'parsed': {...}} structure
        parsed_output = response.output.get('parsed', response.output)
        
        assert "frameworks" in parsed_output
        assert isinstance(parsed_output["frameworks"], list)
        assert len(parsed_output["frameworks"]) > 0

        print("\n✓ Array of objects:")
        print(f"  Found {len(parsed_output['frameworks'])} frameworks")
        for fw in parsed_output["frameworks"][:2]:
            print(f"    - {fw.get('name', 'N/A')}")


class TestDeepResearchModels:
    """Test different research models."""

    @pytest.mark.slow
    def test_basic_model(self, client):
        """Test with basic exa-research model."""
        response = client.deep_research(
            instructions="Briefly explain what JavaScript is (1-2 sentences).",
            model="exa-research",
        )

        assert response.success is True
        print("\n✓ Basic model (exa-research):")
        print(f"  Research ID: {response.research_id}")
        print(f"  Status: {response.status}")

    @pytest.mark.slow
    def test_pro_model(self, client):
        """Test with pro exa-research-pro model."""
        response = client.deep_research(
            instructions="Give a very brief overview of React (1 sentence).",
            model="exa-research-pro",
        )

        assert response.success is True
        print("\n✓ Pro model (exa-research-pro):")
        print(f"  Research ID: {response.research_id}")
        print(f"  Status: {response.status}")


class TestDeepResearchCitations:
    """Test citation handling."""

    @pytest.mark.slow
    def test_citations_present(self, client):
        """Test that research includes citations."""
        response = client.deep_research(
            instructions="Research the history of open source software (brief overview)."
        )

        assert response.success is True

        if response.citations:
            assert isinstance(response.citations, list)
            assert len(response.citations) > 0

            # Check citation structure
            first_citation = response.citations[0]
            assert isinstance(first_citation, Citation)
            assert isinstance(first_citation.url, str)
            assert first_citation.url.startswith("http")
            assert isinstance(first_citation.title, str)
            assert len(first_citation.title) > 0

            print("\n✓ Citations:")
            for i, cite in enumerate(response.citations[:3], 1):
                print(f"  {i}. {cite.title}")
                print(f"     {cite.url}")
        else:
            print("\n⚠ No citations returned (may be model-dependent)")

    @pytest.mark.slow
    def test_multiple_citations(self, client):
        """Test research that should generate multiple citations."""
        response = client.deep_research(
            instructions="Research recent developments in AI (brief summary, 2-3 points)."
        )

        assert response.success is True

        if response.citations:
            citation_count = len(response.citations)
            print(f"\n✓ Generated {citation_count} citations")

            # Verify URLs are unique
            urls = [c.url for c in response.citations]
            unique_urls = set(urls)
            assert len(unique_urls) == len(urls), "Citations should have unique URLs"
        else:
            print("\n⚠ No citations returned")


class TestDeepResearchMetrics:
    """Test research metrics."""

    @pytest.mark.slow
    def test_search_metrics(self, client):
        """Test that search metrics are reported."""
        response = client.deep_research(
            instructions="Quick research: What is Docker? (1-2 sentences)"
        )

        assert response.success is True

        if response.searches_performed is not None:
            assert isinstance(response.searches_performed, int)
            assert response.searches_performed >= 0
            print(f"\n✓ Searches performed: {response.searches_performed}")
        else:
            print("\n⚠ Search count not reported")

        if response.pages_read is not None:
            assert isinstance(response.pages_read, int)
            assert response.pages_read >= 0
            print(f"  Pages read: {response.pages_read}")
        else:
            print("  ⚠ Pages read not reported")


class TestDeepResearchCaching:
    """Test caching behavior."""

    @pytest.mark.slow
    def test_cache_enabled(self, client):
        """Test research with caching enabled (default)."""
        instructions = "What is Kubernetes? (1 sentence only)"

        # First request
        response1 = client.deep_research(instructions=instructions, use_cache=True)

        assert response1.success is True
        research_id_1 = response1.research_id

        print(f"\n✓ First request: {research_id_1}")

        # Second identical request (should use cache)
        response2 = client.deep_research(instructions=instructions, use_cache=True)

        assert response2.success is True
        research_id_2 = response2.research_id

        print(f"  Second request: {research_id_2}")

        # With caching, research IDs might be the same or different
        # depending on implementation, so we just verify both succeeded
        assert research_id_1 is not None
        assert research_id_2 is not None

    @pytest.mark.slow
    def test_cache_disabled(self, client):
        """Test research with caching disabled."""
        response = client.deep_research(
            instructions="Brief explanation of Git (1 sentence).", use_cache=False
        )

        assert response.success is True
        print(f"\n✓ Cache disabled: {response.research_id}")


class TestDeepResearchInstructions:
    """Test various instruction formats."""

    @pytest.mark.slow
    def test_question_format(self, client):
        """Test research with question format."""
        response = client.deep_research(
            instructions="What are the main benefits of using TypeScript over JavaScript?"
        )

        assert response.success is True
        assert len(response.output) > 0
        print(f"\n✓ Question format: {response.research_id}")

    @pytest.mark.slow
    def test_imperative_format(self, client):
        """Test research with imperative instructions."""
        response = client.deep_research(
            instructions="Explain the concept of containerization in software development."
        )

        assert response.success is True
        assert len(response.output) > 0
        print(f"\n✓ Imperative format: {response.research_id}")

    @pytest.mark.slow
    def test_detailed_instructions(self, client):
        """Test research with detailed instructions."""
        response = client.deep_research(
            instructions="""Research GraphQL and provide:
            1. A brief definition (1 sentence)
            2. One key advantage over REST
            Keep the response concise."""
        )

        assert response.success is True
        assert len(response.output) > 0
        print(f"\n✓ Detailed instructions: {response.research_id}")


class TestDeepResearchErrorHandling:
    """Test error handling and validation."""

    def test_empty_instructions_fails(self, client):
        """Test that empty instructions are rejected."""
        with pytest.raises(Exception) as exc_info:
            client.deep_research(instructions="")

        print(f"\n✓ Empty instructions rejected: {exc_info.value}")

    def test_invalid_model_fails(self, client):
        """Test that invalid model is rejected."""
        with pytest.raises(Exception) as exc_info:
            client.deep_research(instructions="test", model="invalid-model")

        print(f"\n✓ Invalid model rejected: {exc_info.value}")

    def test_whitespace_only_instructions(self, client):
        """Test that whitespace-only instructions are rejected."""
        with pytest.raises(Exception) as exc_info:
            client.deep_research(instructions="   \n\t  ")

        print(f"\n✓ Whitespace-only instructions rejected: {exc_info.value}")


class TestDeepResearchTimeout:
    """Test timeout handling."""

    @pytest.mark.slow
    def test_default_timeout(self, client):
        """Test that default timeout (10 minutes) is used."""
        response = client.deep_research(
            instructions="Quick research: What is Node.js? (1 sentence)"
        )

        assert response.success is True
        print(f"\n✓ Default timeout: {response.research_id}")

    @pytest.mark.slow
    def test_custom_timeout(self, client):
        """Test with custom timeout."""
        response = client.deep_research(
            instructions="What is MongoDB? (brief, 1 sentence)",
            timeout=300.0,  # 5 minutes
        )

        assert response.success is True
        print(f"\n✓ Custom timeout (5 min): {response.research_id}")


class TestDeepResearchOutputTypes:
    """Test different output structures."""

    @pytest.mark.slow
    def test_free_form_output(self, client):
        """Test research without structured schema."""
        response = client.deep_research(
            instructions="Provide a brief history of the internet (2-3 sentences)."
        )

        assert response.success is True
        assert isinstance(response.output, dict)

        print("\n✓ Free-form output:")
        print(f"  Keys: {list(response.output.keys())}")
        print(f"  Sample: {str(response.output)[:100]}...")

    @pytest.mark.slow
    def test_numeric_output(self, client):
        """Test schema with numeric fields."""
        schema = {
            "type": "object",
            "properties": {
                "description": {"type": "string"},
                "year_founded": {"type": "number"},
                "popularity_score": {"type": "number"},
            },
            "required": ["description"],
        }

        response = client.deep_research(
            instructions="Research when GitHub was founded and describe it briefly.",
            output_schema=schema,
        )

        assert response.success is True
        
        # API returns {'content': '...', 'parsed': {...}} structure
        parsed_output = response.output.get('parsed', response.output)
        
        assert "description" in parsed_output

        print("\n✓ Numeric output:")
        print(f"  Description: {parsed_output['description'][:60]}...")
        if "year_founded" in parsed_output:
            print(f"  Year: {parsed_output['year_founded']}")


if __name__ == "__main__":
    # Allow running directly for quick testing
    print("=" * 70)
    print("Running integration tests for DeepResearch resource...")
    print("=" * 70)
    print("\n⚠️  WARNING: Deep research tests are SLOW (up to 10 min each)")
    print("⚠️  WARNING: These tests consume significant API credits")
    print("\nMake sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    print("=" * 70 + "\n")
    pytest.main([__file__, "-v", "-s", "-m", "not slow"])
