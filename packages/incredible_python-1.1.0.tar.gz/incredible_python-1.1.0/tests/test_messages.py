"""
Integration tests for the Messages resource (Anthropic-compatible).

These tests call the real API and require:
- INCREDIBLE_API_KEY: Valid API key with credits
- INCREDIBLE_BASE_URL: Base URL of the API (optional, defaults to localhost:8000)

Run with: pytest tests/test_messages.py -v
"""

import os

import pytest

from incredible_python import Incredible
from incredible_python.types.messages import Message


@pytest.fixture(scope="module")
def client():
    """Create an Incredible client for integration tests."""
    api_key = os.getenv("INCREDIBLE_API_KEY")
    if not api_key:
        pytest.skip("INCREDIBLE_API_KEY not set - skipping integration tests")

    base_url = os.getenv("INCREDIBLE_BASE_URL")
    return Incredible(api_key=api_key, base_url=base_url)


class TestMessages:
    """Test messages endpoint."""

    def test_create_message(self, client):
        """Test simple message creation."""
        response = client.messages.create(
            model="small-1",
            max_tokens=100,
            messages=[{"role": "user", "content": "Hello, how are you?"}],
        )

        assert isinstance(response, Message)
        assert response.content
        assert len(response.content) > 0
        assert response.content[0]["text"]
        print(f"\n✓ Message response: {response.content[0]['text']}")

    def test_message_shorthand(self, client):
        """Test callable shorthand."""
        response = client.messages(
            model="small-1",
            max_tokens=100,
            messages=[{"role": "user", "content": "Say hello in French."}],
        )

        assert isinstance(response, Message)
        assert response.content
        print(f"\n✓ Shorthand response: {response.content[0]['text']}")

    def test_stream_message(self, client):
        """Test streaming message."""
        stream = client.messages.stream(
            model="small-1",
            max_tokens=100,
            messages=[{"role": "user", "content": "Count to 5."}],
        )

        chunks = []
        for chunk in stream:
            # This depends on how StreamBuilder yields items
            # It might yield raw events or processed objects
            chunks.append(chunk)

        assert len(chunks) > 0
        print(f"\n✓ Received {len(chunks)} stream chunks")

    def test_count_tokens(self, client):
        """Test token counting."""
        # This endpoint might not be available in all backends
        try:
            response = client.messages.count_tokens(
                model="small-1", messages=[{"role": "user", "content": "Hello world"}]
            )

            assert isinstance(response, dict)
            assert "input_tokens" in response
            print(f"\n✓ Token count: {response}")
        except Exception as e:
            pytest.skip(f"Count tokens failed (likely not supported by backend): {e}")


if __name__ == "__main__":
    print("Running integration tests for Messages resource...")
    print("Make sure INCREDIBLE_API_KEY and INCREDIBLE_BASE_URL are set!\n")
    pytest.main([__file__, "-v", "-s"])
