🚀 ayaiml — Automate Gemini, ChatGPT, Grok, Perplexity & Image Models (Web-based AI Automation Library)

ayaiml is a powerful Python library that automates real AI models directly from the web UI — including:

Google Gemini AI Mode

Google Gemini App

ChatGPT

Grok AI (xAI)

Perplexity

DeepAI Image Generator

This library uses Undetected ChromeDriver + Selenium automation to interact with the official web UI of each model — giving you zero-API-key access to real LLMs.

Perfect for:

Students

Developers

Researchers

Automation projects

No-API-key usage

✨ Features

📌 Zero API Key required

🌐 Works directly on web UI of LLMs

🤖 Supports 5 text models + image model

⚡ Fast and stable (Undetected ChromeDriver)

🧩 Easy unified API: llm.invoke("your prompt")

🧠 Compatible with LangChain LLM interface

📥 Installation
pip install ayaiml


(If not uploaded yet, install manually from source)

🧠 Supported Models
Model	Class Name	Description
Gemini AI Mode	GeminiAIMode	Google Search AI Mode
Gemini App	Gemini	Google Gemini App (full model)
ChatGPT	ChatGPT	ChatGPT Web (Free/GPT-4o mini)
Grok	Grok	xAI Model
Perplexity	Perplexity	Perplexity Web
DeepAI	Image	Text-to-Image generator
🚀 Usage
1️⃣ Gemini AI Mode
from ayaiml import GeminiAIMode

llm = GeminiAIMode()
print(llm.invoke("Explain quantum computing in simple language"))

2️⃣ Gemini (Full Model)
from ayaiml import Gemini

llm = Gemini()
response = llm.invoke("Write a poem about AI and humanity")
print(response)

3️⃣ ChatGPT Web
from ayaiml import ChatGPT

llm = ChatGPT()
print(llm.invoke("What is the future of programming?"))

4️⃣ Grok (xAI)
from ayaiml import Grok

bot = Grok()
print(bot.invoke("Tell me a dark joke (safe mode)."))

5️⃣ Perplexity AI
from ayaiml import Perplexity

px = Perplexity()
print(px.invoke("Who will win World Cup 2026?"))

6️⃣ Image Generator (DeepAI)
from ayaiml import Image

img = Image()
print(img.invoke("A futuristic city floating in clouds"))

📌 How It Works?

Opens a real Chrome browser (undetected)

Anti-bot evasion enabled

Fully bypasses navigator.webdriver

Sends your prompt

Waits for model response

Extracts the text

Returns result as plain text

Works even with free accounts.

⚠ Important Notes

This library uses web automation, not API requests

Requires Chrome installed

First response may take 10–20 seconds

Keep browser window open during execution

Some websites may change HTML structure (updates will fix)

📁 Project Structure
ayaiml/
 ├── __init__.py
 └── core.py
README.md

🤝 Contributing

Pull requests are welcome!
You can add new models, fix XPaths, or improve performance.

📜 License

MIT License
Feel free to use commercially.

⭐ Show Support

If you like this project:

⭐ Star the GitHub repo

📦 Install from PyPI

📝 Use & share it

🔥 Author

Ayush Kumar