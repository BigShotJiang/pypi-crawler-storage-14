from setuptools import setup, find_packages

setup(
    name="ayaiml",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "selenium",
        "undetected-chromedriver",
        "langchain-core",
    ],
    description="Automation-based AI model runner for Gemini, ChatGPT, Grok, Perplexity and Image models.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Ayush Kumar",
    author_email="ayush.lnct11325@gmail.com",
    url="https://pypi.org/project/ayaiml/",
    python_requires=">=3.8",
)
