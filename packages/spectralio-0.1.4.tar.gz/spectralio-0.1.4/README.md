# spectralio

> *Pydantic-based Read/Write utilities for spectral data in Python*