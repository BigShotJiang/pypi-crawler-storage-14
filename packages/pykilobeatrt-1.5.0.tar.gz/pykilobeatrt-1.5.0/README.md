# pykilobeatrt

Real-time bytebeat audio engine for Python with adjustable play/sample rate.
Generate bytebeat audio using formulas and play it instantly.

## Installation

pip install pykilobeatrt

## Example

from pykilobeatrt import compile_formula, BytebeatPlayer

f = compile_formula("(t>>10)*(t&42)")

player = BytebeatPlayer(f, sample_rate=44100)  # default 44100 Hz
player.start()

# change play rate dynamically

player.set_sample_rate(22050)  # half-speed playback

input("Press ENTER to stop...")
player.stop()

## Features

* Real-time audio playback
* Safe AST formula compiler
* Works with numpy ufuncs
* Swap formulas live
* Adjustable play/sample rate
* Byte or float output modes

## License

MIT