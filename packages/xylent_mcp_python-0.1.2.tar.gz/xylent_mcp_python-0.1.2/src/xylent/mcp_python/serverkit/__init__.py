"""Server toolkit for building MCP servers with FastAPI.

This module provides production-ready patterns for MCP servers:
- attach_mcp: Wire MCP into FastAPI with authentication
- BasicAuth: Config-driven auth aligned with client pattern
- NoAuth: Explicit opt-out for development/testing
- AuthBackend: Protocol for custom auth implementations
"""

from .auth import AuthBackend, BasicAuth, NoAuth
from .fastapi import Handle, attach_mcp

__all__ = ["attach_mcp", "AuthBackend", "BasicAuth", "NoAuth", "Handle"]
