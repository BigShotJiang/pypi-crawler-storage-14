"""FastAPI↔MCP adapter - minimal glue only.

This module provides a single function to wire MCP into FastAPI.
No opinions about app context, DI, or tool structure.
"""

import logging
import os
from collections.abc import AsyncIterator, Awaitable, Callable, Iterable
from contextlib import AbstractAsyncContextManager, AsyncExitStack, asynccontextmanager
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, Request
from mcp.server.fastmcp import FastMCP
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.responses import Response

from .auth import BasicAuth

if TYPE_CHECKING:
    from .auth import AuthBackend

logger = logging.getLogger(__name__)


@dataclass
class Handle:
    """Handle returned by attach_mcp for testing/inspection."""

    mcp: FastMCP
    session_manager: Any  # MCP's session manager
    path: str


def attach_mcp(
    app: FastAPI,
    *,
    name: str,
    tools: Iterable[Callable[..., Any]],
    app_context: Callable[[], AbstractAsyncContextManager[Any]],
    auth: "AuthBackend | None" = None,
    path: str = "/mcp",
    cors: bool = False,
    cors_origins: list[str] | None = None,
    on_exception: Callable[[Exception], None] | None = None,
) -> Handle:
    """Attach MCP to FastAPI with authentication.

    This function handles the mechanical aspects of MCP integration:
    - Mounts MCP HTTP endpoint at path with authentication
    - Wires FastAPI lifespan to start/stop MCP session manager
    - Calls your app_context during lifespan
    - Applies authentication to the MCP sub-application
    - Adds CORS if requested

    IMPORTANT: Authentication defaults to BasicAuth with BASIC_USERNAME
    and BASIC_PASSWORD from environment if not provided. The auth middleware
    is applied directly to the MCP Starlette sub-app because middleware on
    the parent FastAPI app does NOT protect mounted sub-applications due to
    ASGI application boundaries.

    Example with authentication:
        from xylent.mcp_python.serverkit import attach_mcp, BasicAuth, NoAuth

        # Default: reads from BASIC_USERNAME/BASIC_PASSWORD env vars
        attach_mcp(app, name="service", tools=[...], app_context=...)

        # Explicit auth override
        auth = BasicAuth(
            username=config.CUSTOM_USER,
            password=config.CUSTOM_PASS,
            allow_paths=[]
        )
        attach_mcp(app, name="service", tools=[...],
                  app_context=..., auth=auth)

        # Development with explicit NoAuth
        attach_mcp(app, name="service", tools=[...],
                  app_context=..., auth=NoAuth())

    Args:
        app: FastAPI application
        name: MCP service name
        tools: Your tool callables (no decoration needed)
        app_context: Your asynccontextmanager for app initialization
        auth: Authentication backend (optional - defaults to BasicAuth from env)
        path: Mount path for MCP endpoint
        cors: Enable CORS
        cors_origins: Specific origins for CORS (if cors=True)
        on_exception: Optional exception handler callback

    Returns:
        Handle with .mcp and .session_manager for testing/inspection
    """

    # Create MCP instance with lifespan that calls consumer's app_context
    @asynccontextmanager
    async def mcp_lifespan(mcp: FastMCP) -> AsyncIterator[Any]:
        """Wire consumer's app_context to MCP lifespan."""
        # Start the consumer's app context
        async with app_context() as ctx:
            # Yield it to MCP (tools will get it via ctx.request_context.lifespan_context)
            yield ctx

    # Create FastMCP with consumer's lifespan and correct internal path
    mcp = FastMCP(
        name=name,
        lifespan=mcp_lifespan,
        streamable_http_path="/",  # Internal path to avoid double nesting
        # Let consumer control other settings via env/config
    )

    # Register tools with optional metadata
    for tool in tools:
        # Tools should have MCP-compatible signature:
        # async def tool(ctx: Context[ServerSession, AppContext], ...args) -> result
        # Optional: tool.__mcp_name__, tool.__mcp_structured__, tool.__doc__
        mcp.tool(
            name=getattr(tool, "__mcp_name__", None),
            description=(tool.__doc__ or None),
            structured_output=getattr(tool, "__mcp_structured__", None),
        )(tool)

    # Get the Starlette app from MCP
    mcp_app = mcp.streamable_http_app()

    # Add CORS middleware first (needs to be added before wrapping)
    if cors:
        origins = cors_origins or ["*"]
        mcp_app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_methods=["GET", "POST", "OPTIONS"],
            allow_headers=["*"],
        )

    # Add exception tracking middleware if provided
    if on_exception is not None:
        # Local binding to help mypy understand the type
        exception_handler = on_exception

        class ExceptionMiddleware(BaseHTTPMiddleware):
            async def dispatch(self, request: Request, call_next: Callable[[Request], Awaitable[Response]]) -> Response:
                """Track exceptions with provided callback."""
                try:
                    return await call_next(request)
                except Exception as e:
                    exception_handler(e)
                    raise

        mcp_app.add_middleware(ExceptionMiddleware)

    # Get auth backend - use provided or default BasicAuth from environment
    if auth is None:
        username = os.getenv("BASIC_USERNAME")
        password = os.getenv("BASIC_PASSWORD")
        if not username or not password:
            raise ValueError("Authentication required. Either provide auth parameter or set BASIC_USERNAME and BASIC_PASSWORD environment variables.")
        auth = BasicAuth(username=username, password=password)

    # Store auth in a final variable for the closure
    final_auth = auth

    # Create auth middleware wrapper (applied at mount time)
    from starlette.types import ASGIApp, Receive, Scope, Send

    class AuthASGIMiddleware:
        def __init__(self, app: ASGIApp) -> None:
            self.app = app

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            if scope["type"] == "http":
                # Create a Request object for the auth backend
                from starlette.requests import Request as StarletteRequest

                request = StarletteRequest(scope, receive)
                try:
                    await final_auth(request)
                except Exception as exc:
                    # Send auth failure response
                    from fastapi import HTTPException
                    from starlette.responses import JSONResponse

                    if isinstance(exc, HTTPException):
                        response = JSONResponse(content={"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)
                    else:
                        response = JSONResponse(content={"detail": "Internal Server Error"}, status_code=500)
                    await response(scope, receive, send)
                    return

            # Auth passed or not HTTP, proceed
            await self.app(scope, receive, send)

    # Wrap the MCP app with auth middleware
    wrapped_mcp_app = AuthASGIMiddleware(mcp_app)

    # Wire FastAPI lifespan to include MCP session manager using AsyncExitStack
    original_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def combined_lifespan(app_instance: Any) -> AsyncIterator[None]:
        """Combine FastAPI's lifespan with MCP session manager."""
        async with AsyncExitStack() as stack:
            # Enter existing FastAPI lifespan if present
            if original_lifespan is not None:
                await stack.enter_async_context(original_lifespan(app_instance))

            # Enter MCP session manager
            await stack.enter_async_context(mcp.session_manager.run())

            # Yield control
            yield

    # Replace FastAPI's lifespan
    app.router.lifespan_context = combined_lifespan

    # Mount the wrapped MCP app (with auth) at the specified path
    app.mount(path, wrapped_mcp_app)

    # Return handle for testing/inspection
    return Handle(mcp=mcp, session_manager=mcp.session_manager, path=path)
