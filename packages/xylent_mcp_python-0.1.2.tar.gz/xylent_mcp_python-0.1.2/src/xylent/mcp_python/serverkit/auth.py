"""Auth backend protocol and implementations for MCP servers.

This module provides:
- AuthBackend protocol for custom auth implementations
- BasicAuth for production username/password authentication
- NoAuth for explicit opt-out in development/testing
"""

import base64
import hmac
from typing import Protocol

from fastapi import HTTPException, Request, status


class AuthBackend(Protocol):
    """Protocol for auth backends used with attach_mcp.

    Implementations should:
    - Raise HTTPException(401) to reject unauthorized requests
    - Return None to accept authorized requests
    - Use constant-time comparison for secrets

    Example custom implementation:
        class CustomHeaderAuth:
            def __init__(self, api_key: str):
                self.api_key = api_key

            async def __call__(self, request: Request) -> None:
                # Check custom header
                provided_key = request.headers.get("X-API-Key")
                if not provided_key or not hmac.compare_digest(provided_key, self.api_key):
                    raise HTTPException(
                        status_code=401,
                        detail="Unauthorized",
                        headers={"WWW-Authenticate": 'ApiKey realm="API"'}
                    )
    """

    async def __call__(self, request: Request) -> None:
        """Check auth. Raise HTTPException to reject, return None to accept."""
        ...


class BasicAuth:
    """Production-ready Basic HTTP authentication.

    Aligned with the client-side BasicHTTPAuth pattern using
    config-driven username/password credentials.

    Features:
    - Constant-time comparison for security
    - Support for both Basic and Bearer schemes
    - Optional path exclusions
    - Proper HTTP 401 with WWW-Authenticate header

    Usage:
        auth = BasicAuth(
            username=config.BASIC_USERNAME,
            password=config.BASIC_PASSWORD,
            allow_paths=[]  # No exclusions for MCP
        )
        attach_mcp(app, auth=auth, ...)
    """

    def __init__(self, username: str, password: str, allow_paths: list[str] | None = None) -> None:
        """Initialize Basic Auth with credentials.

        Args:
            username: The username (typically from BASIC_USERNAME env var)
            password: The password (typically from BASIC_PASSWORD env var)
            allow_paths: Optional paths to exclude from auth

        Raises:
            ValueError: If username or password is empty
        """
        if not username or not password:
            raise ValueError("BasicAuth requires both username and password")

        self.username = username
        self.password = password
        self.allow_paths = set(allow_paths or [])

    async def __call__(self, request: Request) -> None:
        """Check Basic auth credentials.

        Args:
            request: The incoming request

        Raises:
            HTTPException: If authentication fails
        """
        # Allow specified paths without auth
        if request.url.path in self.allow_paths:
            return

        # Extract Authorization header
        auth_header = request.headers.get("authorization")
        if not auth_header:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unauthorized",
                headers={"WWW-Authenticate": 'Basic realm="MCP Service"'},
            )

        # Parse auth scheme and token
        scheme, _, token = auth_header.partition(" ")
        scheme = scheme.lower().strip()
        token = token.strip()

        if scheme not in ("basic", "bearer") or not token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unauthorized",
                headers={"WWW-Authenticate": 'Basic realm="MCP Service"'},
            )

        # Validate credentials
        if not self._validate_credentials(token):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unauthorized",
                headers={"WWW-Authenticate": 'Basic realm="MCP Service"'},
            )

    def _validate_credentials(self, token: str) -> bool:
        """Validate Basic auth token using constant-time comparison.

        Args:
            token: Base64-encoded "username:password" string

        Returns:
            True if credentials match, False otherwise
        """
        try:
            # Decode base64 token
            decoded = base64.b64decode(token, validate=True).decode("utf-8")
        except Exception:
            return False

        # Must contain colon separator
        if ":" not in decoded:
            return False

        # Split into username and password
        username, password = decoded.split(":", 1)

        # Constant-time comparison to prevent timing attacks
        username_matches = hmac.compare_digest(username, self.username)
        password_matches = hmac.compare_digest(password, self.password)

        # Use bitwise AND to avoid short-circuit evaluation
        return username_matches & password_matches


class NoAuth:
    """Explicitly opt-out of authentication for development/testing.

    This makes the lack of auth intentional and visible in code,
    rather than having auth be accidentally missing.

    Usage:
        # Development/testing only!
        attach_mcp(app, auth=NoAuth(), ...)
    """

    async def __call__(self, request: Request) -> None:
        """Allow all requests without authentication."""
        pass  # Explicitly allow all
