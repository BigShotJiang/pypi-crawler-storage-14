from datetime import timedelta
from typing import Literal

from pydantic_settings import BaseSettings


class MCPClientConfig(BaseSettings):
    """Configuration for MCPClient.

    Attributes:
        server_url: The target MCP server URL (e.g., "http://localhost:8000/mcp")
        connect_timeout_s: Timeout in seconds for establishing the initial connection.
        stream_read_timeout_s: Timeout in seconds for reading from the SSE stream.
        call_timeout: Timeout for an individual MCP `session.call_tool` operation (protocol level).
        max_attempts: Maximum number of retry attempts for tool calls.
        retry_min_wait_s: Minimum wait time in seconds between retries (initial backoff).
        retry_max_wait_s: Maximum wait time in seconds between retries.
        auth_type: The type of authentication to use. Currently supports "basic" or "none".
    """

    server_url: str
    connect_timeout_s: timedelta = timedelta(seconds=10)
    stream_read_timeout_s: timedelta = timedelta(seconds=60)
    call_timeout: timedelta = timedelta(seconds=10)
    max_attempts: int = 3
    retry_min_wait_s: float = 0.5
    retry_max_wait_s: float = 5.0
    auth_type: Literal["basic", "none"] | None = None
    tool_use: bool = False
    # Optional auth credentials
    basic_username: str | None = None
    basic_password: str | None = None
