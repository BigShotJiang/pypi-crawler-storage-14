"""Error taxonomy for MCP client operations."""


class MCPError(Exception):
    """Base exception for all MCP client errors."""

    pass


class MCPConnectionError(MCPError):
    """Raised when connection to MCP server fails.

    This includes network errors, DNS failures, and connection timeouts.
    """

    pass


class MCPTimeout(MCPError):
    """Raised when an MCP operation times out.

    This can occur during connection establishment or tool execution.
    """

    pass
