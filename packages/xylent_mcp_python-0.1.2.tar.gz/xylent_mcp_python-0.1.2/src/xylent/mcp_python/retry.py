import asyncio
from builtins import BaseExceptionGroup
from collections.abc import Callable, Sequence
from typing import Any, cast

import anyio
import backoff
import httpx
from mcp.shared.exceptions import McpError

from .config import MCPClientConfig


class MCPRetryHandler:
    """
    Handles retry strategies and associated logging for an MCPClient's tool calls.

    It provides decorators for MCPClient methods to implement configurable backoff retry mechanisms
    for tool calls. These mechanisms distinguish between:
    1. Transport-level errors occurring *during* a call (e.g., network issues mid-call):
       Handled by policies that may suggest a session disconnect by the MCPClient before retrying the call.
       The `is_retriable` policy governs this.
    2. Transient tool-level errors (e.g., server-side timeouts, 5xx errors for a tool):
       These are retried by policies without necessarily disconnecting, assuming the underlying
       connection is still healthy. The `should_retry_call` policy determines this.

    Connection establishment retries are now handled by the MCP SDK's `streamablehttp_client`.
    """

    RETRIABLE_FLAT = (
        ConnectionError,  # DNS failures, socket errors, etc.
        httpx.TransportError,  # Includes TimeoutException, NetworkError,
        anyio.BrokenResourceError,  # Async in-memory stream blew up
        anyio.ClosedResourceError,  # Async in-memory stream was closed early
        asyncio.TimeoutError,  # Safety-net for manual timeouts around tool calls
    )

    # ---------------------------------------------------------------------
    # Transient HTTP status codes returned by the MCP server.
    # We retry the *tool call*, not the connection, on these.
    # ---------------------------------------------------------------------

    _TRANSIENT_MCP_CODES: set[int] = {
        httpx.codes.REQUEST_TIMEOUT,  # 408 – server couldn’t finish in time
        httpx.codes.TOO_MANY_REQUESTS,  # 429 – rate-limited
        httpx.codes.INTERNAL_SERVER_ERROR,  # 500 – generic transient error
        httpx.codes.BAD_GATEWAY,  # 502 – upstream died
        httpx.codes.SERVICE_UNAVAILABLE,  # 503 – server overloaded / restart
        httpx.codes.GATEWAY_TIMEOUT,  # 504 – upstream timed-out
    }

    def __init__(self, cfg: MCPClientConfig):
        self.cfg = cfg

    @staticmethod
    def is_retriable(exc: BaseException) -> bool:
        """
        Determines if an exception (occurring during a tool call) is a transport-level retriable error.
        An ExceptionGroup is retriable if and only if ALL of its constituent exceptions are.
        """
        if isinstance(exc, BaseExceptionGroup):
            if not exc.exceptions:
                return False
            return all(MCPRetryHandler.is_retriable(e) for e in exc.exceptions)
        return isinstance(exc, MCPRetryHandler.RETRIABLE_FLAT)

    @staticmethod
    def _is_transient_mcp(err: McpError) -> bool:
        """Return True if the given McpError wraps an error code that is deemed transient."""
        code = getattr(err.error, "code", None)
        return code in MCPRetryHandler._TRANSIENT_MCP_CODES

    @staticmethod
    def should_retry_call(exc: BaseException) -> bool:
        """Return True if our combined retry policy says to retry the failed tool call.
        This policy covers:
        - Transport-level issues (will trigger disconnect/reconnect by MCPClient): `is_retriable`.
        - Transient tool-level issues (McpError with certain status codes): `_is_transient_mcp`.
        """
        if MCPRetryHandler.is_retriable(exc):
            return True
        return isinstance(exc, McpError) and MCPRetryHandler._is_transient_mcp(exc)

    def create_call_retry_decorator(self, func_to_decorate: Callable[..., Any]) -> Callable[..., Any]:
        """Creates and returns a backoff-decorated version of func_to_decorate for tool calls."""
        return backoff.on_exception(
            backoff.expo,
            cast(
                "Sequence[type[Exception]]",
                (
                    BaseExceptionGroup,
                    *MCPRetryHandler.RETRIABLE_FLAT,
                    McpError,
                ),
            ),
            max_tries=self.cfg.max_attempts,
            jitter=backoff.full_jitter,
            base=self.cfg.retry_min_wait_s,
            max_time=self.cfg.retry_max_wait_s,
            factor=1.5,
            giveup=lambda e: not MCPRetryHandler.should_retry_call(e),
        )(func_to_decorate)
