import asyncio

from loguru import logger

from .auth import AuthStrategy
from .client import MCPClient
from .client_utils import get_auth_strategy
from .config import MCPClientConfig
from .retry import MCPRetryHandler


class MCPClientRegistry:
    """
    Singleton registry: exactly one MCPClient per server_url.

    This registry uses per-URL locking to allow concurrent client creation
    for different URLs while ensuring thread-safe access to each individual URL.

    The singleton pattern ensures all components share the same connection pool,
    preventing duplicate connections across the application.

    Usage:
        client = await MCPClientRegistry.get(url, config)
        # ... use client
        await MCPClientRegistry.aclose_all()
    """

    _clients: dict[str, MCPClient] = {}
    _url_locks: dict[str, asyncio.Lock] = {}
    _registry_lock = asyncio.Lock()  # Only for managing the locks dictionary

    @classmethod
    async def get(cls, url: str, client_cfg: MCPClientConfig | None = None, auth: AuthStrategy | None = None) -> MCPClient:
        """Gets or creates the client for a URL, ensuring its context is entered.

        This method uses per-URL locking to allow concurrent client creation
        for different URLs while maintaining thread safety for the same URL.

        Args:
            url: The server URL.
            client_cfg: Optional MCPClientConfig. If provided, this config will be used
                        for the client if it needs to be created. If not provided,
                        a default MCPClientConfig will be created with just the URL.
            auth: Optional AuthStrategy to use instead of deriving from config.
        """
        if not url:
            raise ValueError("URL cannot be empty for MCP client registry.")

        # Step 1: Get or create the URL-specific lock (quick operation)
        async with cls._registry_lock:
            if url not in cls._url_locks:
                cls._url_locks[url] = asyncio.Lock()
                logger.debug(f"Created new lock for URL: {url}")
            url_lock = cls._url_locks[url]

        # Step 2: Use URL-specific lock for client operations (potentially slow)
        async with url_lock:
            # Check if client already exists
            client = cls._clients.get(url)
            if client is not None:
                logger.debug(f"Returning existing MCPClient for: {url}")
                return client

            # Create new client
            logger.info(f"Creating new MCPClient instance for: {url}")
            cfg = client_cfg if client_cfg else MCPClientConfig(server_url=url)

            retry_handler = MCPRetryHandler(cfg)
            auth_strategy = auth if auth is not None else get_auth_strategy(cfg)
            client = MCPClient(cfg, retry_handler, auth_strategy)

            try:
                await client.__aenter__()
                cls._clients[url] = client
                logger.info(f"Successfully created and stored MCPClient for: {url}")
            except Exception as e:
                logger.error(f"Failed to enter context for new MCPClient ({url}): {e!r}")
                # Attempt to clean up if __aenter__ fails
                try:
                    await client.__aexit__(type(e), e, e.__traceback__)
                except Exception as ae_ex:
                    logger.error(f"Error during cleanup for {url} after __aenter__ failed: {ae_ex!r}")
                raise

            return client

    @classmethod
    async def remove_client(cls, url: str) -> None:
        """Remove a specific client from the registry and close it.

        This can be used to remove failed clients to allow fresh reconnection attempts.
        Uses per-URL locking to ensure thread safety without blocking other URLs.

        Args:
            url: The server URL of the client to remove.
        """
        # Get the URL-specific lock if it exists
        async with cls._registry_lock:
            url_lock = cls._url_locks.get(url)
            if url_lock is None:
                logger.debug(f"No lock found for URL: {url}, no client to remove")
                return

        # Use URL-specific lock for removal
        async with url_lock:
            client = cls._clients.pop(url, None)
            if client is None:
                logger.debug(f"No client found in registry for URL: {url}")
                return

            # Close the client
            logger.info(f"Removing and closing client for URL: {url}")
            try:
                await client.__aexit__(None, None, None)
                logger.info(f"Successfully closed and removed client for {url}")
            except Exception as e:
                logger.error(f"Error closing removed client for {url}: {e!r}")

        # Clean up the lock after client is removed
        async with cls._registry_lock:
            # Double-check no new client was created while we were closing
            if url not in cls._clients and url in cls._url_locks:
                del cls._url_locks[url]
                logger.debug(f"Removed lock for URL: {url}")

    @classmethod
    async def aclose_all(cls) -> None:
        """Closes all managed MCP clients by exiting their asynchronous contexts.

        This should be called during application shutdown to ensure graceful
        disconnection of all clients. This method is thread-safe and closes
        all clients concurrently for better performance.
        """
        logger.info("Initiating closure of all managed MCP clients...")

        # Get all clients to close under the registry lock
        async with cls._registry_lock:
            clients_to_close = list(cls._clients.items())  # Get (url, client) pairs
            cls._clients.clear()
            cls._url_locks.clear()  # Clear all locks since we're closing everything
            logger.debug(f"Registry cleared. {len(clients_to_close)} clients to close.")

        # Close all clients concurrently for better performance
        closed_count = 0
        errors_count = 0
        close_tasks = []

        async def close_client(url: str, client: MCPClient) -> tuple[str, bool]:
            """Close a single client and return success status."""
            try:
                await client.__aexit__(None, None, None)
                logger.debug(f"Successfully closed client for {url}")
                return (url, True)
            except Exception as e:
                logger.error(f"Error closing MCP client for {url}: {e!r}")
                return (url, False)

        # Create tasks for concurrent closing
        for url, client in clients_to_close:
            close_tasks.append(close_client(url, client))

        # Wait for all closures to complete
        if close_tasks:
            results = await asyncio.gather(*close_tasks, return_exceptions=False)
            for _, success in results:
                if success:
                    closed_count += 1
                else:
                    errors_count += 1

        logger.info(f"Closed {closed_count}/{len(clients_to_close)} MCP clients. {errors_count} errors encountered.")
