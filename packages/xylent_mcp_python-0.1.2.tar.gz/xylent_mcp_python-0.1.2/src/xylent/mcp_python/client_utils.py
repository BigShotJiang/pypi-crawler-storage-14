"""Helper utilities for parsing MCP_SERVERS configuration.

This module provides utilities for parsing MCP server configurations
from JSON strings, typically provided via environment variables.
"""

import json

from .auth import AuthStrategy, BasicHTTPAuth, NoAuth
from .config import MCPClientConfig


def parse_mcp_servers(mcp_servers_json: str) -> dict[str, MCPClientConfig]:
    """Parse MCP_SERVERS JSON configuration into MCPClientConfig instances.

    Expects a JSON string with the following structure:
    {
        "SERVER_NAME": {
            "server_url": "https://example.com/mcp",
            "auth_type": "basic",  # or "none"
            "tool_use": true,  # optional, defaults to False
            "connect_timeout_s": 10,  # optional
            "stream_read_timeout_s": 60,  # optional
            "call_timeout": 10,  # optional
            "max_attempts": 3,  # optional
            "retry_min_wait_s": 0.5,  # optional
            "retry_max_wait_s": 5.0  # optional
        }
    }

    Args:
        mcp_servers_json: JSON string containing server configurations

    Returns:
        Dictionary mapping server names to MCPClientConfig instances

    Raises:
        json.JSONDecodeError: If the JSON is invalid
        ValueError: If required fields are missing or invalid
    """
    try:
        servers_data = json.loads(mcp_servers_json)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid MCP_SERVERS JSON: {e}") from e

    if not isinstance(servers_data, dict):
        raise ValueError("MCP_SERVERS must be a JSON object")

    configs = {}

    for server_name, server_config in servers_data.items():
        if not isinstance(server_config, dict):
            raise ValueError(f"Server config for {server_name} must be an object")

        # Extract server_url (required)
        server_url = server_config.get("server_url")
        if not server_url:
            raise ValueError(f"Server {server_name} missing required 'server_url'")

        # Create config with all supported fields
        config_kwargs = {
            "server_url": server_url,
            "auth_type": server_config.get("auth_type", "none"),
            "tool_use": server_config.get("tool_use", False),
        }

        # Add optional timing fields if present
        optional_fields = [
            "connect_timeout_s",
            "stream_read_timeout_s",
            "call_timeout",
            "max_attempts",
            "retry_min_wait_s",
            "retry_max_wait_s",
            "basic_username",
            "basic_password",
        ]

        for field in optional_fields:
            if field in server_config:
                config_kwargs[field] = server_config[field]

        # Create the config instance
        configs[server_name] = MCPClientConfig(**config_kwargs)

    return configs


def get_auth_strategy(config: MCPClientConfig) -> AuthStrategy:
    """Create an auth strategy instance from config.

    This function enforces strict authentication - if credentials are required
    but missing, it will raise an error rather than silently falling back.

    Args:
        config: MCPClientConfig with auth_type specified

    Returns:
        Appropriate AuthStrategy instance

    Raises:
        ValueError: If auth_type is unknown or if required credentials are missing
    """
    auth_type = config.auth_type or "none"

    if auth_type == "none":
        return NoAuth()
    elif auth_type == "basic":
        if not config.basic_username or not config.basic_password:
            raise ValueError("Basic auth requires username and password")
        return BasicHTTPAuth(config.basic_username, config.basic_password)
    else:
        raise ValueError(f"Unknown auth_type: {auth_type}. Supported types: none, basic")
