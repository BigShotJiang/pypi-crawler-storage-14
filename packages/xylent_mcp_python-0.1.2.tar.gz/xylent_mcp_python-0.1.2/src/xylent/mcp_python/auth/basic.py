"""Basic HTTP Authentication strategy."""

import base64
from collections.abc import Mapping

from ..config import MCPClientConfig
from .base import AuthStrategy


class BasicHTTPAuth(AuthStrategy):
    """Implements Basic HTTP Authentication.

    Credentials are passed explicitly during initialization, supporting
    the design principle of "No Global State".
    """

    def __init__(self, username: str, password: str) -> None:
        """Initialize Basic HTTP Authentication with explicit credentials.

        Args:
            username: The username for basic authentication
            password: The password for basic authentication

        Raises:
            ValueError: If username or password is empty
        """
        if not username or not password:
            raise ValueError("Username and password are required for BasicHTTPAuth")

        self.username = username
        self.password = password
        self.credentials = f"{username}:{password}"

    def get_auth_headers(self) -> Mapping[str, str] | None:
        """Return the Basic Authentication header.

        Returns:
            Dictionary with Authorization header containing base64 encoded credentials
        """
        encoded_credentials = base64.b64encode(self.credentials.encode()).decode()
        return {"Authorization": f"Basic {encoded_credentials}"}

    @classmethod
    def from_config(cls, config: MCPClientConfig) -> "BasicHTTPAuth":
        """Build BasicHTTPAuth from an MCPClientConfig."""
        if not config.basic_username or not config.basic_password:
            raise ValueError("Basic auth requires username and password")
        return cls(config.basic_username, config.basic_password)
