"""Authentication strategies for MCP clients."""

from .base import AuthStrategy, NoAuth
from .basic import BasicHTTPAuth

__all__ = ["AuthStrategy", "NoAuth", "BasicHTTPAuth"]
