"""Base authentication strategy protocol."""

from collections.abc import Mapping
from typing import Protocol


class AuthStrategy(Protocol):
    """Protocol for authentication strategies."""

    def get_auth_headers(self) -> Mapping[str, str] | None:
        """Returns authentication headers, or None if no authentication is used."""
        ...


class NoAuth(AuthStrategy):
    """Represents no authentication."""

    def get_auth_headers(self) -> Mapping[str, str] | None:
        return None
