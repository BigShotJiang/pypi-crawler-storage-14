import asyncio
import contextlib
import time
from types import TracebackType
from typing import Any, Self, cast
from urllib.parse import urlparse

import mcp.types as types
from loguru import logger
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

from .auth import AuthStrategy
from .config import MCPClientConfig
from .retry import MCPRetryHandler


class MCPClient:
    """Minimal Streamable-HTTP-native MCP client.

    *   **Lazy connection** - a `streamablehttp_client()` pair is opened on the
        first tool call and kept until an unrecoverable transport error occurs.
    *   **Connection retry** - handled internally by the SDK helper; we do not
        implement our own back-off loop for connection establishment.
    *   **Tool-level retry** - provided by ``MCPRetryHandler``. If a retriable
        failure happens during a tool call, the session is torn down so the
        next attempt starts on a fresh transport.
    """

    def __init__(
        self,
        cfg: MCPClientConfig,
        retry_handler: MCPRetryHandler,
        auth_strategy: AuthStrategy | None = None,
    ):
        self.cfg = cfg
        self.retry_handler = retry_handler
        self.auth_strategy = auth_strategy

        self._session: ClientSession | None = None
        self._stack: contextlib.AsyncExitStack | None = None
        self._lock = asyncio.Lock()

        # TCP check caching
        self._last_tcp_check: float | None = None
        self._tcp_check_ttl = 60.0  # Cache TCP check for 1 minute

        self._call_with_retry = self.retry_handler.create_call_retry_decorator(self._call_attempt)
        self._list_tools_with_retry = self.retry_handler.create_call_retry_decorator(self._list_tools_attempt)

    # Async context manager ------------------------------------------------
    async def __aenter__(self) -> Self:
        """Prepares the client for use. Connection will be established lazily on the first tool call."""
        logger.info(f"MCPClient context entered for {self.cfg.server_url} (lazy connect via streamablehttp)")
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        """
        Disconnects the client if it was connected.
        """
        url = self.cfg.server_url
        logger.info(f"Exiting context for MCP client: {url}")
        await self._disconnect()
        logger.info(f"Disconnected MCP client for {self.cfg.server_url}")

    # Public API -----------------------------------------------------------
    async def call_tool(self, name: str, args: dict[str, Any] | None = None, meta: dict[str, Any] | None = None) -> types.CallToolResult:
        """Calls a tool using a retry mechanism for the tool call itself.
        Connection establishment uses SDK's internal retry.

        Args:
            name: The name of the tool to call
            args: Arguments to pass to the tool
            meta: Optional metadata to pass with the request (via _meta parameter).
                  This metadata is not visible to the LLM but can be accessed by the server.
        """
        if not name:
            raise ValueError("tool name cannot be empty")

        url = self.cfg.server_url
        logger.debug(f"[{url}] Initiating tool call '{name}' via retry wrapper...")
        if meta:
            logger.debug(f"[{url}] Including meta parameters: {list(meta.keys())}")
        result = await self._call_with_retry(name, args or {}, meta)
        logger.debug(f"[{url}] Tool call '{name}' successful after retries (if any).")
        logger.debug(f"call_tool result: {result}")

        if not isinstance(result, types.CallToolResult):
            raise TypeError(f"Expected CallToolResult, got {type(result).__name__}: {result}")

        return result

    async def list_tools(self) -> list[types.Tool]:
        """List available tools from the MCP server with retry logic.

        Returns:
            List of tool definitions from the MCP server
        """
        logger.debug(f"[{self.cfg.server_url}] Initiating list_tools via retry wrapper...")
        result: list[types.Tool] = await self._list_tools_with_retry()
        logger.info(f"[{self.cfg.server_url}] Found {len(result)} tools")
        return result

    def is_healthy(self) -> bool:
        """Check if the client connection is healthy.

        Returns:
            True if the client has an active session, False otherwise.
        """
        return self._is_connected

    # Internal helpers -----------------------------------------------------
    @property
    def _is_connected(self) -> bool:
        """Checks if the client has an active session."""
        return self._session is not None

    async def _preflight_tcp_check(self) -> None:
        """Attempts a TCP connection to the MCP server to fail fast if unreachable. Only for http/https URLs."""
        parsed = urlparse(self.cfg.server_url)
        if parsed.scheme not in ("http", "https"):
            return
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=self.cfg.connect_timeout_s.total_seconds(),
            )
            writer.close()
            await writer.wait_closed()
        except TimeoutError as e:
            logger.error(f"TCP connection to {host}:{port} timed out after {self.cfg.connect_timeout_s.total_seconds()}s")
            raise ConnectionError(
                f"Connection timeout: Unable to reach MCP server at {self.cfg.server_url} (timeout: {self.cfg.connect_timeout_s.total_seconds()}s)"
            ) from e
        except Exception as e:
            logger.error(f"Pre-flight TCP check to {host}:{port} failed: {type(e).__name__}: {e}")
            raise ConnectionError(f"Cannot establish TCP connection to MCP server at {self.cfg.server_url} ({host}:{port}): {e}") from e

    def _should_check_tcp(self) -> bool:
        """Determine if TCP check is needed based on cache and URL scheme."""
        # Skip for non-HTTP schemes
        parsed = urlparse(self.cfg.server_url)
        if parsed.scheme not in ("http", "https"):
            return False

        # Skip if recently checked
        if self._last_tcp_check is not None:
            elapsed = time.time() - self._last_tcp_check
            if elapsed < self._tcp_check_ttl:
                logger.debug(f"Skipping TCP check for {self.cfg.server_url} (checked {elapsed:.1f}s ago)")
                return False

        return True

    async def _ensure_session(self) -> ClientSession:
        """
        Ensures an active and initialized ClientSession is available.
        If not connected, it establishes a new session using streamablehttp_client.
        This method is idempotent.
        """
        if self._is_connected:
            return cast(ClientSession, self._session)

        async with self._lock:
            if self._is_connected:  # Double-check after acquiring lock
                return cast(ClientSession, self._session)

            # Clean up any existing resources before attempting new connection
            await self._reset_connection_state()

            # Pre-flight TCP check to fail fast on unreachable host (with caching)
            if self._should_check_tcp():
                await self._preflight_tcp_check()
                self._last_tcp_check = time.time()  # Cache successful check

            logger.info(f"Attempting to establish connection to: {self.cfg.server_url} via streamablehttp_client")
            stack = contextlib.AsyncExitStack()
            try:
                (
                    read,
                    write,
                    _,
                ) = await stack.enter_async_context(
                    streamablehttp_client(
                        self.cfg.server_url,
                        timeout=self.cfg.connect_timeout_s,
                        sse_read_timeout=self.cfg.stream_read_timeout_s,
                        headers=self._auth_headers(),
                    )
                )
                session = await stack.enter_async_context(
                    ClientSession(
                        read,
                        write,
                        read_timeout_seconds=self.cfg.call_timeout,
                    )
                )
                logger.debug(f"MCP ClientSession created for {self.cfg.server_url}")
                await session.initialize()

                # Only set these if everything succeeded
                self._stack = stack
                self._session = session
                logger.info(f"MCP session established for {self.cfg.server_url} using streamablehttp ✅")
                return session

            except Exception as e:
                error_msg = f"Failed to establish MCP session with {self.cfg.server_url}"
                if hasattr(e, "__cause__") and e.__cause__:
                    error_msg += f" (caused by: {type(e.__cause__).__name__}: {e.__cause__})"
                else:
                    error_msg += f": {type(e).__name__}: {e}"
                logger.error(error_msg)

                # Clean up the new stack
                try:
                    await stack.aclose()
                except Exception as cleanup_error:
                    logger.warning(f"Error during cleanup after connection failure: {cleanup_error!r}")

                # Ensure we're in a clean state for next attempt
                self._stack = None
                self._session = None
                raise e

    async def _disconnect(self) -> None:
        """Closes the current session and underlying transport resources."""
        async with self._lock:
            await self._reset_connection_state()

    async def _reset_connection_state(self) -> None:
        """Reset connection state and clean up resources.

        This method should be called with the lock held.
        It ensures complete cleanup of connection resources.
        """
        if self._session is None and self._stack is None:
            logger.debug(f"[{self.cfg.server_url}] No connection state to reset.")
            return

        logger.info(f"[{self.cfg.server_url}] Resetting connection state...")

        # Clear references first to prevent any further use
        stack, self._stack = self._stack, None
        self._session = None

        # Clean up the stack (which includes the session)
        if stack:
            logger.debug(f"Closing connection stack for {self.cfg.server_url}")
            try:
                await stack.aclose()
                logger.info(f"MCP connection stack closed for {self.cfg.server_url}")
            except Exception as e:
                logger.error(f"Error closing connection stack for {self.cfg.server_url}: {e!r}")
                # Continue anyway - we've already cleared the references

    async def _call_attempt(self, name: str, args: dict[str, Any], meta: dict[str, Any] | None = None) -> types.CallToolResult:
        """
        Performs a single tool call attempt. Wrapped by backoff decorator for tool-level retries.
        Ensures a session is active before calling.
        If a retriable transport error occurs during the call, disconnects to force a fresh session on next retry.

        Uses the lower-level send_request API to support meta parameters.
        """
        url = self.cfg.server_url
        session = await self._ensure_session()  # Ensures connection is active

        logger.debug(f"[{url}] Executing tool call '{name}' on active session...")
        try:
            async with asyncio.timeout(self.cfg.call_timeout.total_seconds()):
                # Build the request params with optional meta
                params = types.CallToolRequestParams(name=name, arguments=args)

                # Add meta to params if provided
                if meta:
                    # Create Meta object with the provided metadata
                    params.meta = types.RequestParams.Meta(**meta)
                    logger.debug(f"[{url}] Added meta to request: {list(meta.keys())}")

                # Use lower-level send_request to support meta parameter
                result = await session.send_request(types.ClientRequest(types.CallToolRequest(method="tools/call", params=params)), types.CallToolResult)
                logger.debug(f"[{url}] Tool call '{name}' result: {result}")
            logger.debug(f"[{url}] Tool call '{name}' successful.")
            return result
        except Exception as e:
            error_details = f"Tool '{name}' failed"
            if args:
                # Include arg keys but not values (could be sensitive)
                error_details += f" (args: {list(args.keys())})"
            if meta:
                error_details += f" (meta: {list(meta.keys())})"
            error_details += f": {type(e).__name__}: {e}"
            logger.warning(f"[{url}] {error_details}")

            if MCPRetryHandler.is_retriable(e):
                logger.info(f"[{url}] Detected retriable transport error for tool '{name}'. Disconnecting session to force fresh connection on retry.")
                await self._disconnect()
            raise e

    async def _list_tools_attempt(self) -> list[types.Tool]:
        """
        Performs a single list_tools attempt. Wrapped by backoff decorator for retries.
        Ensures a session is active before listing.
        If a retriable transport error occurs, disconnects to force a fresh session on next retry.
        """
        url = self.cfg.server_url
        session = await self._ensure_session()  # Ensures connection is active

        logger.debug(f"[{url}] Listing available tools on active session...")
        try:
            async with asyncio.timeout(self.cfg.call_timeout.total_seconds()):
                result = await session.list_tools()
                logger.debug(f"[{url}] list_tools result: {result}")
            # Extract tools from ListToolsResult
            tools = result.tools if hasattr(result, "tools") else []
            logger.debug(f"[{url}] list_tools successful, found {len(tools)} tools.")
            return tools
        except Exception as e:
            logger.warning(f"[{url}] Failed to list tools: {type(e).__name__}: {e}")
            if MCPRetryHandler.is_retriable(e):
                logger.info(f"[{url}] Detected retriable transport error during list_tools. Disconnecting session to force fresh connection on retry.")
                await self._disconnect()
            raise e

    def _auth_headers(self) -> dict[str, str] | None:
        if self.auth_strategy:
            auth_headers = self.auth_strategy.get_auth_headers()
            return dict(auth_headers) if auth_headers else None
        return None
