"""Xylent namespace package.

Houses the `xylent.mcp_python` implementation shipped as `xylent-mcp-python`.
"""
