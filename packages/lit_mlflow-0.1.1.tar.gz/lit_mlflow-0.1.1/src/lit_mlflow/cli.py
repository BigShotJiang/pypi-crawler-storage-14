from lit_mlflow.__about__ import __version__


def main():
    print(f"lit-mlflow v{__version__}!")
