from . import ir_config_parameter
