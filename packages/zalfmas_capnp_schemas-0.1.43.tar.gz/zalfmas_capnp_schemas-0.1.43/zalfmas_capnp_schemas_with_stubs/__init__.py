import os

schemas_dir = os.path.abspath("../../zalfmas_capnp_schemas")
