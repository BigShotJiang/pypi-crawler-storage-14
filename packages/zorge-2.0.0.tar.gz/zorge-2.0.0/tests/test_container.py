# ruff: noqa: ANN201

import typing

import pytest

import zorge
from .definitions import contracts, implementations


def test_callable_dependency_adding(container: zorge.Container) -> None:
    container.register_dependency(
        contract=contracts.DBEngineContract, implementation=implementations.sync_engine, cache_scope="container"
    )

    unit = next(iter(container))
    assert unit.cache_scope == zorge.definition.contracts.CacheScope.CONTAINER
    assert unit.contract is contracts.DBEngineContract
    assert unit.execution_signature is not None
    assert unit.implementation_execution_trigger is None
    assert unit.implementation_execution_type == zorge.definition.contracts.ImplementationExecutionType.SYNC
    assert unit.implementation_kind == zorge.definition.contracts.ImplementationKind.CALLABLE
    assert unit.init_signature is None
    assert unit.implementation() == "postgresql"


@pytest.mark.asyncio
async def test_async_dependency_adding(container: zorge.Container) -> None:
    container.register_dependency(
        contract=contracts.DBEngineContract, implementation=implementations.async_engine, cache_scope="container"
    )

    unit = next(iter(container))
    assert unit.cache_scope == zorge.definition.contracts.CacheScope.CONTAINER
    assert unit.contract is contracts.DBEngineContract
    assert unit.execution_signature is not None
    assert unit.implementation_execution_trigger is None
    assert unit.implementation_execution_type == zorge.definition.contracts.ImplementationExecutionType.ASYNC
    assert unit.implementation_kind == zorge.definition.contracts.ImplementationKind.CALLABLE
    assert unit.init_signature is None
    assert await unit.implementation() == "postgresql"


def test_class_dependency_adding(container: zorge.Container) -> None:
    container.register_dependency(
        contract=contracts.DBConnectionContract, implementation=implementations.DBConnection, cache_scope="resolver"
    )

    unit = next(iter(container))
    assert unit.cache_scope == zorge.definition.contracts.CacheScope.RESOLVER
    assert unit.contract is contracts.DBConnectionContract
    assert unit.execution_signature is None
    assert unit.implementation_execution_trigger is None
    assert unit.implementation_execution_type == zorge.definition.contracts.ImplementationExecutionType.SYNC
    assert unit.implementation_kind == zorge.definition.contracts.ImplementationKind.CLASS
    assert type(unit.init_signature) is zorge.definition.contracts.FunctionSignature
    assert unit.init_signature.parameters["db_engine"].type == contracts.DBEngineContract
    assert unit.implementation is implementations.DBConnection


def test_class_contract_auto_derivation(container: zorge.Container) -> None:
    container.register_dependency(implementation=implementations.AutoDerivedImplementation, cache_scope="resolver")

    unit = next(iter(container))
    assert unit.contract is contracts.AutoBaseContract
    assert unit.implementation is implementations.AutoDerivedImplementation


def test_callable_contract_auto_derivation(container: zorge.Container) -> None:
    container.register_dependency(implementation=implementations.auto_function_dependency, cache_scope="container")

    unit = next(iter(container))
    assert unit.contract is contracts.AutoFunctionContract
    assert isinstance(unit.implementation(), contracts.AutoFunctionContract)


def test_register_callback_invalid_trigger(container: zorge.Container) -> None:
    container.register_dependency(
        contract=contracts.DBConnectionContract, implementation=implementations.DBConnection, cache_scope="resolver"
    )

    invalid_trigger: typing.Any = "startup"

    with pytest.raises(zorge.definition.exceptions.UnsupportedTrigger):
        container.register_callback(
            contract=contracts.DBConnectionContract,
            callback=typing.cast(zorge.definition.contracts.CallbackType, implementations.close_connection),
            trigger=invalid_trigger,
        )


@pytest.mark.asyncio
async def test_container_shutdown_executes_callbacks(container: zorge.Container) -> None:
    container.register_dependency(
        contract=contracts.DBEngineContract, implementation=implementations.async_engine, cache_scope="container"
    )
    container.register_dependency(
        contract=contracts.DBConnectionContract, implementation=implementations.DBConnection, cache_scope="container"
    )
    container.register_callback(
        contract=contracts.DBConnectionContract,
        callback=typing.cast(zorge.definition.contracts.CallbackType, implementations.close_connection),
        trigger="shutdown",
    )

    async with container.get_resolver() as resolver:
        connection = await resolver.resolve(contracts.DBConnectionContract)

    await container.shutdown({"source": "test"})
    assert connection.sentinel == 1


def test_container_add_merges_units(container: zorge.Container) -> None:
    other = zorge.Container()
    other.register_dependency(
        contract=contracts.DBEngineContract, implementation=implementations.sync_engine, cache_scope="container"
    )
    other.register_dependency(
        contract=contracts.DBConnectionContract, implementation=implementations.DBConnection, cache_scope="resolver"
    )
    other.register_callback(
        contract=contracts.DBConnectionContract,
        callback=typing.cast(zorge.definition.contracts.CallbackType, implementations.close_connection),
        trigger="shutdown",
    )

    container += other

    units = list(container)
    assert len(units) == 3
    assert {unit.contract for unit in units} >= {contracts.DBEngineContract, contracts.DBConnectionContract}
