# ruff: noqa: ANN201

import types
import typing

import pytest

import zorge

from .definitions import contracts, implementations


def _build_provider_module() -> types.ModuleType:
    module = types.ModuleType("tests.definitions.provider_module")

    def engine_dc(engine_impl: typing.Any) -> zorge.Container:
        container = zorge.Container()
        container.register_dependency(
            contract=typing.cast(zorge.definition.contracts.ContractType, contracts.DBEngineContract),
            implementation=engine_impl,
            cache_scope="container",
        )
        return container

    setattr(module, "engine_dc", engine_dc)

    submodule = types.ModuleType("tests.definitions.provider_module.submodule")

    def connection_dc() -> zorge.Container:
        container = zorge.Container()
        container.register_dependency(
            contract=contracts.DBConnectionContract, implementation=implementations.DBConnection, cache_scope="resolver"
        )
        return container

    setattr(submodule, "connection_dc", connection_dc)
    setattr(module, "submodule", submodule)
    return module


def _build_invalid_module() -> types.ModuleType:
    module = types.ModuleType("tests.definitions.invalid_provider_module")

    def missing_config_dc(unknown_dependency: typing.Any) -> typing.Any:  # pragma: no cover - exercised via provider
        return unknown_dependency

    setattr(module, "missing_config_dc", missing_config_dc)
    return module


@pytest.mark.asyncio
async def test_container_provider_loads_modules() -> None:
    provider = zorge.ContainerProvider(engine_impl=implementations.sync_engine)
    provider.load_module(_build_provider_module())

    async with provider.get_container().get_resolver() as resolver:
        connection = await resolver.resolve(contracts.DBConnectionContract)
        assert "Connection with postgresql" in str(connection)


def test_container_provider_requires_config_values() -> None:
    provider = zorge.ContainerProvider()
    with pytest.raises(NotImplementedError):
        provider.load_module(_build_invalid_module())
