import abc


class DIException(Exception):
    def __init__(self, contract: type) -> None:
        self.contract = contract
        super().__init__(self.message())

    @abc.abstractmethod
    def message(self) -> str: ...


class UnsupportedTrigger(DIException):
    def __init__(self, contract: type, trigger: str) -> None:
        self._trigger = trigger
        super().__init__(contract)

    def message(self) -> str:
        return f"Unsupported trigger: {self._trigger} for contract: {self.contract}"


class ContractIsNotRegistered(DIException):
    def message(self) -> str:
        return f"Contract is not registered: {self.contract}"


class CannotAutomaticallyDeriveContract(DIException):
    def message(self) -> str:
        return f"Cannot automatically derive contract: {self.contract}"
