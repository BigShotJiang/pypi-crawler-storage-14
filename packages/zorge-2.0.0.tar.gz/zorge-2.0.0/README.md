# Zorge
Yet another implementation of dependency injection pattern