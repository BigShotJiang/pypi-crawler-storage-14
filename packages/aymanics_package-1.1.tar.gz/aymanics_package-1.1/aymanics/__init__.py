"""Defines the version of the application."""
VERSION = "1.1"
