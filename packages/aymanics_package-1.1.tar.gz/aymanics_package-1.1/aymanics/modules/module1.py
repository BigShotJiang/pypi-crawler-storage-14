# my_package/modules/module1.py
import logging

class MODULE_1:
    def __init__(self) -> None:
        # Bind the method once – now it can be called without arguments
        self.my_function = self.say_hello

    def say_hello(self) -> None:
        """Simple greeting that is logged."""
        logging.info("Hello!")

    def periodic_actions(self) -> None:
        """Called every second by the Application."""
        # Call the bound function (no arguments needed)
        self.my_function()