#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import logging
from aymanics.modules.module1 import MODULE_1
from twisted.internet import reactor, task
from typing import Callable

class _App:
    def __init__(self) -> None:
        logging.basicConfig(
            level=logging.INFO,
            format="%(levelname)-2s : %(message)s ",   # <-- this line changed
            force=True
        )
        logging.info("******************************************")
        logging.info("*                                        *")
        logging.info("*     ★★★  MY PROJECT IS RUNNING  ★★★    *")
        logging.info("*                                        *")
        logging.info("******************************************")

        self.module1_instance = MODULE_1()

    # … the rest of the class stays exactly the same …
    def _start_periodic_loop(self, function: Callable[[], None], period: int) -> None:
        loop = task.LoopingCall(function)
        deferred = loop.start(period, now=True)
        deferred.addErrback(self._callback_run_loop_error)

    def _callback_run_loop_error(self, failure):
        logging.error(f"Error in periodic loop: {failure}")

    def run(self) -> None:
        self._start_periodic_loop(self.module1_instance.periodic_actions, period=5)
        reactor.run()


def start_application() -> None:
    app = _App()
    app.run()


if __name__ == "__main__":
    start_application()