#!/usr/bin/python3
# coding: utf-8

from pathlib import Path
from setuptools import find_packages, setup

# Importing the version variable from your package
from aymanics import VERSION

# List to hold installation requirements
INSTALL_REQUIRES = []

# Retrieve requirements from requirements.txt if it exists
FILEPATH = Path("requirements.txt")
if FILEPATH.is_file():
    with open(FILEPATH, mode="r", encoding="utf8") as requirement_file:
        INSTALL_REQUIRES = requirement_file.read().splitlines()

# Create MyProject_VERSION file to store the current version
with open("MyProject_VERSION", mode="w", encoding="utf8") as myproject_version_file:
    myproject_version_file.write(VERSION + "\n")

# Setup configuration for the package
setup(
    name="aymanics_package",  # Replace with your package name
    version=VERSION,     # Dynamically set version from imported VERSION variable
    author="Ayman Elnour",  # Replace with your name
    author_email="ayman@example.com",  # Replace with your email
    description="A brief description of My Project",  # Short description of the project
    long_description=open("README.md").read(),  # Optional long description from README file
    long_description_content_type='text/markdown',  # Specify the type of the long description
    packages=find_packages(exclude=["tests", "examples", "myenv"]),  # Automatically find and include package directories
    install_requires=INSTALL_REQUIRES,  # Install required packages from requirements.txt
    include_package_data=True,  # Include other files as specified in MANIFEST.in, if it exists
    entry_points={
        "console_scripts": [
             "run=aymanics.application:main"  # Adjust this line with the correct module and function
        ]
    },
    data_files=[  # Include MyProject_VERSION file in the installation
        ("", ["MyProject_VERSION"])  # This places MyProject_VERSION in the root directory of the installation
    ],
    classifiers=[
        'Programming Language :: Python :: 3',  # Specify compatible Python versions
        'License :: OSI Approved :: MIT License',  # License type, update as needed
        'Operating System :: OS Independent',  # Specify compatible OS
    ],
    python_requires='>=3.6',  # Specify the minimum required Python version
)