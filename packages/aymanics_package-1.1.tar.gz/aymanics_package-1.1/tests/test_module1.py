# tests/test_module1.py
import unittest
from io import StringIO
import logging

from my_package.modules.module1 import MODULE_1


class TestMODULE1(unittest.TestCase):

    def test_hello_is_logged(self):
        # 1. Capture logs
        stream = StringIO()
        handler = logging.StreamHandler(stream)

        # 2. IMPORTANT: lower the root logger level
        root = logging.getLogger()
        root.addHandler(handler)
        root.setLevel(logging.DEBUG)   # or logging.INFO

        # 3. Run the code
        MODULE_1().my_function()

        # 4. Check
        self.assertIn("Hello!", stream.getvalue())

        # 5. Clean-up
        root.removeHandler(handler)
        root.setLevel(logging.NOTSET)   # restore default
 