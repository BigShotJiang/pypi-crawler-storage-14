"""Unit tests for Safeline audit components."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

from sfln.audit import (
    AuditEvent,
    AuditStoreClient,
    CompositeEmitter,
    EventType,
    FileAuditEmitter,
    MemoryEmitter,
    NoOpEmitter,
)


class TestAuditEvent:
    """Tests for AuditEvent class."""

    def test_event_creation(self) -> None:
        event = AuditEvent(
            operation_id="op-123",
            operation_type="test-op",
            event_type=EventType.STAGE_COMPLETED.value,
            actor="user",
            environment="test",
            stage_name="prepare",
            data={"key": "value"},
        )

        assert event.operation_id == "op-123"
        assert event.event_type == "stage_completed"
        assert event.stage_name == "prepare"
        assert event.data == {"key": "value"}
        assert event.event_id.startswith("evt-")

    def test_event_serialization(self) -> None:
        event = AuditEvent(
            operation_id="op-123",
            operation_type="test-op",
            event_type="stage_completed",
            actor="user",
            environment="test",
        )

        data = event.to_dict()
        restored = AuditEvent.from_dict(data)

        assert restored.operation_id == event.operation_id
        assert restored.event_type == event.event_type

    def test_event_to_json_line(self) -> None:
        event = AuditEvent(
            operation_id="op-123",
            operation_type="test-op",
            event_type="stage_completed",
            actor="user",
            environment="test",
        )

        json_line = event.to_json_line()
        parsed = json.loads(json_line)

        assert parsed["operation_id"] == "op-123"


class TestMemoryEmitter:
    """Tests for MemoryEmitter."""

    def test_emit_stores_events(self) -> None:
        emitter = MemoryEmitter()

        emitter.emit(
            event_type="stage_completed",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
            stage_name="prepare",
        )

        assert len(emitter.events) == 1
        assert emitter.events[0].stage_name == "prepare"

    def test_get_events_for_operation(self) -> None:
        emitter = MemoryEmitter()

        emitter.emit(
            event_type="stage_completed",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )
        emitter.emit(
            event_type="stage_completed",
            operation_id="op-456",
            operation_type="test",
            actor="user",
            environment="test",
        )

        events = emitter.get_events_for_operation("op-123")
        assert len(events) == 1
        assert events[0].operation_id == "op-123"

    def test_get_events_by_type(self) -> None:
        emitter = MemoryEmitter()

        emitter.emit(
            event_type="stage_started",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )
        emitter.emit(
            event_type="stage_completed",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )

        events = emitter.get_events_by_type("stage_completed")
        assert len(events) == 1

    def test_clear(self) -> None:
        emitter = MemoryEmitter()
        emitter.emit(
            event_type="test",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )

        emitter.clear()
        assert len(emitter.events) == 0


class TestNoOpEmitter:
    """Tests for NoOpEmitter."""

    def test_emit_does_nothing(self) -> None:
        emitter = NoOpEmitter()
        emitter.emit(
            event_type="test",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )
        # Should not raise


class TestCompositeEmitter:
    """Tests for CompositeEmitter."""

    def test_emits_to_all_emitters(self) -> None:
        emitter1 = MemoryEmitter()
        emitter2 = MemoryEmitter()
        composite = CompositeEmitter([emitter1, emitter2])

        composite.emit(
            event_type="test",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )

        assert len(emitter1.events) == 1
        assert len(emitter2.events) == 1

    def test_continues_on_failure(self) -> None:
        emitter1 = MagicMock()
        emitter1.emit.side_effect = Exception("Simulated failure")
        emitter2 = MemoryEmitter()

        composite = CompositeEmitter([emitter1, emitter2])

        composite.emit(
            event_type="test",
            operation_id="op-123",
            operation_type="test",
            actor="user",
            environment="test",
        )

        # emitter2 should still receive the event
        assert len(emitter2.events) == 1


class TestFileAuditEmitter:
    """Tests for FileAuditEmitter."""

    def test_emit_writes_to_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "audit.jsonl"
            emitter = FileAuditEmitter(file_path)

            emitter.emit(
                event_type="stage_completed",
                operation_id="op-123",
                operation_type="test",
                actor="user",
                environment="test",
                stage_name="prepare",
            )

            content = file_path.read_text()
            lines = content.strip().split("\n")
            assert len(lines) == 1

            event = json.loads(lines[0])
            assert event["operation_id"] == "op-123"
            assert event["stage_name"] == "prepare"

    def test_emit_appends_to_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "audit.jsonl"
            emitter = FileAuditEmitter(file_path)

            emitter.emit(
                event_type="event1",
                operation_id="op-123",
                operation_type="test",
                actor="user",
                environment="test",
            )
            emitter.emit(
                event_type="event2",
                operation_id="op-123",
                operation_type="test",
                actor="user",
                environment="test",
            )

            content = file_path.read_text()
            lines = content.strip().split("\n")
            assert len(lines) == 2


class TestAuditStoreClient:
    """Tests for AuditStoreClient."""

    def test_health_check_success(self) -> None:
        with patch("sfln.audit.client.urlopen") as mock_urlopen:
            mock_response = MagicMock()
            mock_response.status = 200
            mock_response.__enter__ = MagicMock(return_value=mock_response)
            mock_response.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_response

            client = AuditStoreClient(url="http://localhost:8080")
            result = client.health_check()

            assert result is True
            client.close()

    def test_health_check_failure(self) -> None:
        with patch("sfln.audit.client.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = Exception("Connection refused")

            client = AuditStoreClient(url="http://localhost:8080")
            result = client.health_check()

            assert result is False
            client.close()

    def test_fallback_file_on_failure(self) -> None:
        from urllib.error import URLError

        with tempfile.TemporaryDirectory() as tmpdir:
            fallback_path = Path(tmpdir) / "fallback.jsonl"

            with patch("sfln.audit.client.urlopen") as mock_urlopen:
                mock_urlopen.side_effect = URLError("Connection refused")

                client = AuditStoreClient(
                    url="http://localhost:8080",
                    fallback_file=fallback_path,
                    retry_attempts=1,
                    retry_delay=0.01,
                )

                client.emit(
                    event_type="test",
                    operation_id="op-123",
                    operation_type="test",
                    actor="user",
                    environment="test",
                )

                # Force flush
                client.flush()
                client.close()

            # Check fallback file
            assert fallback_path.exists()
            content = fallback_path.read_text()
            assert "op-123" in content
