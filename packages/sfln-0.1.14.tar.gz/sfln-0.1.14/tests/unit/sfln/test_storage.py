"""Unit tests for Safeline storage backends."""

from __future__ import annotations

from pathlib import Path

import pytest

from sfln import Context, MemoryStore, Operation, Stage, StageResult
from sfln.core.result import OperationState
from sfln.core.stage import StageState, StageStatus
from sfln.exceptions import OperationNotFoundError
from sfln.storage import FileStore


class SimpleOp(Operation):
    """Simple test operation."""

    name = "simple"
    stages = [Stage("first"), Stage("second")]

    def first(self, ctx: Context) -> StageResult:
        return StageResult(data={"first": True})

    def second(self, ctx: Context) -> StageResult:
        return StageResult(data={"second": True})


class TestMemoryStore:
    """Tests for MemoryStore."""

    def test_save_and_load_operation(self) -> None:
        """Save and load operation works."""
        store = MemoryStore()
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        loaded = store.load_operation("op-001")
        assert loaded is op

    def test_load_nonexistent_operation_returns_none(self) -> None:
        """Loading nonexistent operation returns None."""
        store = MemoryStore()
        assert store.load_operation("nonexistent") is None

    def test_load_state(self) -> None:
        """Load state returns context, statuses, and state."""
        store = MemoryStore()
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        loaded_ctx, loaded_statuses, loaded_state = store.load_state("op-001")
        assert loaded_ctx.operation_id == "op-001"
        assert loaded_ctx.actor == "tester"
        assert "first" in loaded_statuses
        assert "second" in loaded_statuses
        assert loaded_state == OperationState.CREATED

    def test_load_state_not_found(self) -> None:
        """Load state raises error for nonexistent operation."""
        store = MemoryStore()
        with pytest.raises(OperationNotFoundError):
            store.load_state("nonexistent")

    def test_update_stage_status(self) -> None:
        """Update stage status modifies stored data."""
        store = MemoryStore()
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        # Update first stage to completed
        new_status = StageStatus(stage=op.stages[0], state=StageState.COMPLETED)
        new_status.data = {"done": True}
        store.update_stage_status("op-001", new_status)

        _, loaded_statuses, _ = store.load_state("op-001")
        assert loaded_statuses["first"].state == StageState.COMPLETED

    def test_update_stage_status_not_found(self) -> None:
        """Update stage status raises error for nonexistent operation."""
        store = MemoryStore()
        stage = Stage("test")
        status = StageStatus(stage=stage, state=StageState.COMPLETED)
        with pytest.raises(OperationNotFoundError):
            store.update_stage_status("nonexistent", status)

    def test_update_state(self) -> None:
        """Update operation state."""
        store = MemoryStore()
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)
        store.update_state("op-001", OperationState.RUNNING)

        _, _, loaded_state = store.load_state("op-001")
        assert loaded_state == OperationState.RUNNING

    def test_update_state_not_found(self) -> None:
        """Update state raises error for nonexistent operation."""
        store = MemoryStore()
        with pytest.raises(OperationNotFoundError):
            store.update_state("nonexistent", OperationState.COMPLETED)

    def test_exists(self) -> None:
        """Exists check works."""
        store = MemoryStore()
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        assert not store.exists("op-001")
        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)
        assert store.exists("op-001")

    def test_delete(self) -> None:
        """Delete removes operation."""
        store = MemoryStore()
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)
        assert store.exists("op-001")

        store.delete("op-001")
        assert not store.exists("op-001")

    def test_delete_nonexistent_does_not_raise(self) -> None:
        """Delete nonexistent operation does not raise."""
        store = MemoryStore()
        store.delete("nonexistent")  # Should not raise

    def test_list_operations(self) -> None:
        """List operations returns all operation summaries."""
        store = MemoryStore()

        for i in range(3):
            op = SimpleOp(targets=[f"target{i}"])
            context = Context(
                operation_id=f"op-{i:03d}",
                operation_type="simple",
                targets=[f"target{i}"],
                actor="tester",
                environment="test",
            )
            stage_statuses = {
                s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages
            }
            store.save(f"op-{i:03d}", op, context, stage_statuses, OperationState.CREATED)

        summaries = store.list_operations()
        assert len(summaries) == 3
        op_ids = {s.operation_id for s in summaries}
        assert "op-000" in op_ids
        assert "op-001" in op_ids
        assert "op-002" in op_ids

    def test_list_operations_filter_by_state(self) -> None:
        """List operations can filter by state."""
        store = MemoryStore()

        for i, state in enumerate(
            [OperationState.CREATED, OperationState.COMPLETED, OperationState.CREATED]
        ):
            op = SimpleOp(targets=[f"target{i}"])
            context = Context(
                operation_id=f"op-{i:03d}",
                operation_type="simple",
                targets=[f"target{i}"],
                actor="tester",
                environment="test",
            )
            stage_statuses = {
                s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages
            }
            store.save(f"op-{i:03d}", op, context, stage_statuses, state)

        pending = store.list_operations(state=OperationState.CREATED)
        assert len(pending) == 2

        completed = store.list_operations(state=OperationState.COMPLETED)
        assert len(completed) == 1

    def test_list_operations_limit(self) -> None:
        """List operations respects limit."""
        store = MemoryStore()

        for i in range(5):
            op = SimpleOp(targets=[f"target{i}"])
            context = Context(
                operation_id=f"op-{i:03d}",
                operation_type="simple",
                targets=[f"target{i}"],
                actor="tester",
                environment="test",
            )
            stage_statuses = {
                s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages
            }
            store.save(f"op-{i:03d}", op, context, stage_statuses, OperationState.CREATED)

        summaries = store.list_operations(limit=2)
        assert len(summaries) == 2


class TestFileStore:
    """Tests for FileStore."""

    def test_save_and_load_operation(self, tmp_path: Path) -> None:
        """Save and load operation works."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        loaded = store.load_operation("op-001")
        assert loaded is op

    def test_load_state(self, tmp_path: Path) -> None:
        """Load state returns context, statuses, and state."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        loaded_ctx, loaded_statuses, loaded_state = store.load_state("op-001")
        assert loaded_ctx.operation_id == "op-001"
        assert loaded_ctx.actor == "tester"
        assert "first" in loaded_statuses
        assert "second" in loaded_statuses
        assert loaded_state == OperationState.CREATED

    def test_load_state_not_found(self, tmp_path: Path) -> None:
        """Load state raises error for nonexistent operation."""
        store = FileStore(tmp_path / "ops")
        with pytest.raises(OperationNotFoundError):
            store.load_state("nonexistent")

    def test_load_state_without_registered_operation(self, tmp_path: Path) -> None:
        """Load state raises error if operation not registered."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        # Create a new store instance without the operation registered
        store2 = FileStore(tmp_path / "ops")
        with pytest.raises(OperationNotFoundError):
            store2.load_state("op-001")

    def test_update_stage_status(self, tmp_path: Path) -> None:
        """Update stage status modifies stored data."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        new_status = StageStatus(stage=op.stages[0], state=StageState.COMPLETED)
        new_status.data = {"done": True}
        store.update_stage_status("op-001", new_status)

        _, loaded_statuses, _ = store.load_state("op-001")
        assert loaded_statuses["first"].state == StageState.COMPLETED

    def test_update_stage_status_not_found(self, tmp_path: Path) -> None:
        """Update stage status raises error for nonexistent operation."""
        store = FileStore(tmp_path / "ops")
        stage = Stage("test")
        status = StageStatus(stage=stage, state=StageState.COMPLETED)
        with pytest.raises(OperationNotFoundError):
            store.update_stage_status("nonexistent", status)

    def test_update_state(self, tmp_path: Path) -> None:
        """Update operation state."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)
        store.update_state("op-001", OperationState.RUNNING)

        _, _, loaded_state = store.load_state("op-001")
        assert loaded_state == OperationState.RUNNING

    def test_update_state_not_found(self, tmp_path: Path) -> None:
        """Update state raises error for nonexistent operation."""
        store = FileStore(tmp_path / "ops")
        with pytest.raises(OperationNotFoundError):
            store.update_state("nonexistent", OperationState.COMPLETED)

    def test_exists(self, tmp_path: Path) -> None:
        """Exists check works."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        assert not store.exists("op-001")
        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)
        assert store.exists("op-001")

    def test_delete(self, tmp_path: Path) -> None:
        """Delete removes operation file."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)
        assert store.exists("op-001")

        store.delete("op-001")
        assert not store.exists("op-001")
        assert not (tmp_path / "ops" / "op-001.json").exists()

    def test_delete_nonexistent_does_not_raise(self, tmp_path: Path) -> None:
        """Delete nonexistent operation does not raise."""
        store = FileStore(tmp_path / "ops")
        store.delete("nonexistent")  # Should not raise

    def test_list_operations(self, tmp_path: Path) -> None:
        """List operations returns all operation summaries."""
        store = FileStore(tmp_path / "ops")

        for i in range(3):
            op = SimpleOp(targets=[f"target{i}"])
            context = Context(
                operation_id=f"op-{i:03d}",
                operation_type="simple",
                targets=[f"target{i}"],
                actor="tester",
                environment="test",
            )
            stage_statuses = {
                s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages
            }
            store.save(f"op-{i:03d}", op, context, stage_statuses, OperationState.CREATED)

        summaries = store.list_operations()
        assert len(summaries) == 3

    def test_list_operations_filter_by_state(self, tmp_path: Path) -> None:
        """List operations can filter by state."""
        store = FileStore(tmp_path / "ops")

        for i, state in enumerate(
            [OperationState.CREATED, OperationState.COMPLETED, OperationState.CREATED]
        ):
            op = SimpleOp(targets=[f"target{i}"])
            context = Context(
                operation_id=f"op-{i:03d}",
                operation_type="simple",
                targets=[f"target{i}"],
                actor="tester",
                environment="test",
            )
            stage_statuses = {
                s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages
            }
            store.save(f"op-{i:03d}", op, context, stage_statuses, state)

        pending = store.list_operations(state=OperationState.CREATED)
        assert len(pending) == 2

        completed = store.list_operations(state=OperationState.COMPLETED)
        assert len(completed) == 1

    def test_list_operations_limit(self, tmp_path: Path) -> None:
        """List operations respects limit."""
        store = FileStore(tmp_path / "ops")

        for i in range(5):
            op = SimpleOp(targets=[f"target{i}"])
            context = Context(
                operation_id=f"op-{i:03d}",
                operation_type="simple",
                targets=[f"target{i}"],
                actor="tester",
                environment="test",
            )
            stage_statuses = {
                s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages
            }
            store.save(f"op-{i:03d}", op, context, stage_statuses, OperationState.CREATED)

        summaries = store.list_operations(limit=2)
        assert len(summaries) == 2

    def test_register_operation(self, tmp_path: Path) -> None:
        """Register operation allows loading state for existing files."""
        store = FileStore(tmp_path / "ops")
        op = SimpleOp(targets=["target1"])
        context = Context(
            operation_id="op-001",
            operation_type="simple",
            targets=["target1"],
            actor="tester",
            environment="test",
        )
        stage_statuses = {s.name: StageStatus(stage=s, state=StageState.PENDING) for s in op.stages}

        store.save("op-001", op, context, stage_statuses, OperationState.CREATED)

        # Create new store and register operation
        store2 = FileStore(tmp_path / "ops")
        store2.register_operation("op-001", op)

        loaded_ctx, loaded_statuses, loaded_state = store2.load_state("op-001")
        assert loaded_ctx.operation_id == "op-001"

    def test_creates_data_directory(self, tmp_path: Path) -> None:
        """FileStore creates data directory if it doesn't exist."""
        data_dir = tmp_path / "deep" / "nested" / "ops"
        assert not data_dir.exists()

        FileStore(data_dir)  # Creates directory as side effect
        assert data_dir.exists()
