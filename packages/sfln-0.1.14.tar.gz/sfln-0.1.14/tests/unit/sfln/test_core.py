"""Unit tests for Safeline core components."""

from __future__ import annotations

import pytest

from sfln import (
    Context,
    MemoryEmitter,
    MemoryStore,
    Operation,
    OperationState,
    Safeline,
    Stage,
    StageResult,
    StageState,
)
from sfln.exceptions import (
    ApprovalRequiredError,
    InvalidOperationStateError,
    InvalidStageTransitionError,
    StageNotFoundError,
)


class SimpleOperation(Operation):
    """Simple test operation."""

    name = "simple-test"
    stages = [
        Stage("prepare"),
        Stage("execute"),
        Stage("cleanup"),
    ]

    def prepare(self, context: Context) -> StageResult:
        return StageResult(data={"prepared": True})

    def execute(self, context: Context) -> StageResult:
        return StageResult(data={"executed": True})

    def cleanup(self, context: Context) -> StageResult:
        return StageResult(data={"cleaned": True})


class FailingOperation(Operation):
    """Operation that fails in execute stage."""

    name = "failing-test"
    stages = [
        Stage("prepare"),
        Stage("execute"),
    ]

    def prepare(self, context: Context) -> StageResult:
        return StageResult(data={"prepared": True})

    def execute(self, context: Context) -> StageResult:
        return StageResult(success=False, error="Simulated failure")


class ApprovalOperation(Operation):
    """Operation with approval required."""

    name = "approval-test"
    stages = [
        Stage("prepare"),
        Stage("deploy", needs_approval=True),
        Stage("verify"),
    ]

    def prepare(self, context: Context) -> StageResult:
        return StageResult(data={"prepared": True})

    def deploy(self, context: Context) -> StageResult:
        return StageResult(data={"deployed": True})

    def verify(self, context: Context) -> StageResult:
        return StageResult(data={"verified": True})


class RollbackOperation(Operation):
    """Operation with rollback support."""

    name = "rollback-test"
    stages = [
        Stage("prepare", reversible=True),
        Stage("execute", reversible=True),
    ]

    def prepare(self, context: Context) -> StageResult:
        return StageResult(data={"prepared": True})

    def execute(self, context: Context) -> StageResult:
        return StageResult(data={"executed": True})

    def rollback_execute(self, context: Context) -> StageResult:
        return StageResult(data={"rolled_back": True})


class TestStage:
    """Tests for Stage class."""

    def test_stage_creation(self) -> None:
        stage = Stage("test-stage")
        assert stage.name == "test-stage"
        assert stage.required is True
        assert stage.needs_approval is False
        assert stage.needs_lock is False

    def test_stage_with_options(self) -> None:
        stage = Stage(
            "deploy",
            required=True,
            needs_approval=True,
            needs_lock=True,
            timeout_seconds=300,
        )
        assert stage.name == "deploy"
        assert stage.needs_approval is True
        assert stage.needs_lock is True
        assert stage.timeout_seconds == 300

    def test_stage_invalid_name(self) -> None:
        with pytest.raises(ValueError, match="cannot be empty"):
            Stage("")

    def test_stage_invalid_chars(self) -> None:
        with pytest.raises(ValueError, match="must be alphanumeric"):
            Stage("invalid/name")


class TestOperation:
    """Tests for Operation base class."""

    def test_operation_creation(self) -> None:
        op = SimpleOperation(targets=["/path/a", "/path/b"])
        assert op.name == "simple-test"
        assert len(op.stages) == 3
        assert op.targets == ["/path/a", "/path/b"]

    def test_operation_get_stage(self) -> None:
        op = SimpleOperation()
        stage = op.get_stage("prepare")
        assert stage is not None
        assert stage.name == "prepare"

    def test_operation_get_stage_not_found(self) -> None:
        op = SimpleOperation()
        stage = op.get_stage("nonexistent")
        assert stage is None

    def test_operation_missing_method(self) -> None:
        class IncompleteOperation(Operation):
            name = "incomplete"
            stages = [Stage("missing")]

        with pytest.raises(StageNotFoundError):
            IncompleteOperation()


class TestSafeline:
    """Tests for Safeline orchestrator."""

    def test_create_operation(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = SimpleOperation(targets=["/test"])
        op_id = sl.create(op)

        assert op_id.startswith("op-")
        assert store.exists(op_id)

    def test_run_operation_success(self) -> None:
        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test-user", environment="test")

        op = SimpleOperation(targets=["/test"])
        result = sl.run(op)

        assert result.success
        assert result.state == OperationState.COMPLETED
        assert "prepare" in result.stages_completed
        assert "execute" in result.stages_completed
        assert "cleanup" in result.stages_completed

        # Check audit events
        events = auditor.events
        event_types = [e.event_type for e in events]
        assert "operation_created" in event_types
        assert "stage_started" in event_types
        assert "stage_completed" in event_types
        assert "operation_completed" in event_types

    def test_run_operation_failure(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = FailingOperation(targets=["/test"])
        result = sl.run(op)

        assert not result.success
        assert result.state == OperationState.FAILED
        assert "execute" in result.stages_failed

    def test_run_stage_individually(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = SimpleOperation(targets=["/test"])
        op_id = sl.create(op)

        result = sl.run_stage(op_id, "prepare")
        assert result.success
        assert result.data["prepared"] is True

    def test_approval_required(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = ApprovalOperation(targets=["/test"])
        op_id = sl.create(op)

        # Run prepare (no approval needed)
        result = sl.run_stage(op_id, "prepare")
        assert result.success

        # Try to run deploy (needs approval)
        with pytest.raises(ApprovalRequiredError):
            sl.run_stage(op_id, "deploy")

        # Approve and run
        sl.approve(op_id, "deploy", approver="admin")
        result = sl.run_stage(op_id, "deploy")
        assert result.success

    def test_stage_sequence_enforced(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = SimpleOperation(targets=["/test"])
        op_id = sl.create(op)

        # Try to run execute before prepare
        with pytest.raises(InvalidStageTransitionError):
            sl.run_stage(op_id, "execute")

    def test_get_status(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = SimpleOperation(targets=["/test"])
        op_id = sl.create(op)
        sl.run_stage(op_id, "prepare")

        status = sl.get_status(op_id)
        assert status["operation_id"] == op_id
        assert status["operation_type"] == "simple-test"
        assert status["stages"]["prepare"]["state"] == StageState.COMPLETED.value
        assert status["stages"]["execute"]["state"] == StageState.PENDING.value

    def test_rollback(self) -> None:
        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test-user", environment="test")

        op = RollbackOperation(targets=["/test"])
        result = sl.run(op)
        assert result.success

        # Rollback
        rollback_result = sl.rollback(result.operation_id)
        assert rollback_result.state == OperationState.ROLLED_BACK

        # Check rollback events emitted
        event_types = [e.event_type for e in auditor.events]
        assert "rollback_started" in event_types
        assert "rollback_completed" in event_types

    def test_dry_run(self) -> None:
        store = MemoryStore()
        sl = Safeline(store=store, actor="test-user", environment="test")

        op = SimpleOperation(targets=["/test"])
        op_id = sl.create(op, dry_run=True)

        status = sl.get_status(op_id)
        assert status["dry_run"] is True


class TestContext:
    """Tests for Context class."""

    def test_context_serialization(self) -> None:
        ctx = Context(
            operation_id="op-123",
            operation_type="test",
            environment="prod",
            actor="user",
            targets=["/a", "/b"],
            metadata={"key": "value"},
        )

        data = ctx.to_dict()
        restored = Context.from_dict(data)

        assert restored.operation_id == ctx.operation_id
        assert restored.environment == ctx.environment
        assert restored.targets == ctx.targets
        assert restored.metadata == ctx.metadata

    def test_get_stage_result(self) -> None:
        ctx = Context(
            operation_id="op-123",
            operation_type="test",
            environment="test",
            actor="user",
            stage_results={"prepare": {"ready": True}},
        )

        result = ctx.get_stage_result("prepare")
        assert result == {"ready": True}

        result = ctx.get_stage_result("nonexistent")
        assert result is None


class TestStageResult:
    """Tests for StageResult class."""

    def test_success_result(self) -> None:
        result = StageResult(data={"done": True})
        assert result.success is True
        assert result.data == {"done": True}

    def test_failure_result(self) -> None:
        result = StageResult(success=False, error="Something went wrong")
        assert result.success is False
        assert result.error == "Something went wrong"

    def test_failure_auto_error(self) -> None:
        result = StageResult(success=False, message="Failed")
        assert result.error == "Failed"

    def test_serialization(self) -> None:
        result = StageResult(
            success=True,
            data={"key": "value"},
            rollback_data={"restore": "data"},
        )

        data = result.to_dict()
        restored = StageResult.from_dict(data)

        assert restored.success == result.success
        assert restored.data == result.data
        assert restored.rollback_data == result.rollback_data


# Test operations for timeout and retry tests
class TimeoutOperation(Operation):
    """Operation with a slow stage for timeout testing."""

    name = "timeout-test"
    stages = [
        Stage("fast"),
        Stage("slow", timeout_seconds=1),
    ]

    def fast(self, context: Context) -> StageResult:
        return StageResult(data={"fast": True})

    def slow(self, context: Context) -> StageResult:
        import time

        time.sleep(5)  # Sleep longer than timeout
        return StageResult(data={"slow": True})


class RetryOperation(Operation):
    """Operation that fails initially then succeeds."""

    name = "retry-test"
    stages = [
        Stage("flaky", retry_count=2),
    ]
    attempt_count = 0

    def flaky(self, context: Context) -> StageResult:
        RetryOperation.attempt_count += 1
        if RetryOperation.attempt_count < 3:
            return StageResult(
                success=False, error=f"Attempt {RetryOperation.attempt_count} failed"
            )
        return StageResult(data={"succeeded_on_attempt": RetryOperation.attempt_count})


class AlwaysFailsOperation(Operation):
    """Operation that always fails."""

    name = "always-fails"
    stages = [
        Stage("fail", retry_count=2),
    ]

    def fail(self, context: Context) -> StageResult:
        return StageResult(success=False, error="Always fails")


class ResumeTestOperation(Operation):
    """Operation for resume testing."""

    name = "resume-test"
    stages = [
        Stage("step1"),
        Stage("step2"),
        Stage("step3"),
    ]
    fail_step2 = True

    def step1(self, context: Context) -> StageResult:
        return StageResult(data={"step1": True})

    def step2(self, context: Context) -> StageResult:
        if ResumeTestOperation.fail_step2:
            return StageResult(success=False, error="Step 2 failed")
        return StageResult(data={"step2": True})

    def step3(self, context: Context) -> StageResult:
        return StageResult(data={"step3": True})


class TestStageTimeout:
    """Tests for stage timeout functionality."""

    def test_stage_completes_within_timeout(self) -> None:
        """Stage that completes within timeout succeeds."""

        class QuickOperation(Operation):
            name = "quick"
            stages = [Stage("quick", timeout_seconds=5)]

            def quick(self, context: Context) -> StageResult:
                return StageResult(data={"quick": True})

        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = QuickOperation(targets=["x"])
        result = sl.run(op)

        assert result.success
        assert result.stages_completed == ["quick"]

    def test_stage_timeout_enforced(self) -> None:
        """Stage that exceeds timeout fails."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = TimeoutOperation(targets=["x"])
        op_id = sl.create(op)

        # Fast stage succeeds
        result = sl.run_stage(op_id, "fast")
        assert result.success

        # Slow stage times out
        result = sl.run_stage(op_id, "slow")
        assert not result.success
        assert "timed out" in result.error


class TestStageRetry:
    """Tests for stage retry functionality."""

    def test_stage_retry_succeeds_on_later_attempt(self) -> None:
        """Stage succeeds after retries."""
        RetryOperation.attempt_count = 0

        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test", environment="test")

        op = RetryOperation(targets=["x"])
        result = sl.run(op)

        assert result.success
        assert RetryOperation.attempt_count == 3

        # Check retry events
        event_types = [e.event_type for e in auditor.events]
        assert event_types.count("stage_retrying") == 2

    def test_stage_retry_exhausted(self) -> None:
        """Stage fails after all retries exhausted."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = AlwaysFailsOperation(targets=["x"])
        result = sl.run(op)

        assert not result.success
        assert "fail" in result.stages_failed

    def test_no_retry_on_success(self) -> None:
        """Stage with retry_count doesn't retry if succeeds first time."""

        class SuccessfulRetryOp(Operation):
            name = "success-retry"
            stages = [Stage("ok", retry_count=3)]
            call_count = 0

            def ok(self, context: Context) -> StageResult:
                SuccessfulRetryOp.call_count += 1
                return StageResult(data={"ok": True})

        SuccessfulRetryOp.call_count = 0
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = SuccessfulRetryOp(targets=["x"])
        result = sl.run(op)

        assert result.success
        assert SuccessfulRetryOp.call_count == 1


class TestResume:
    """Tests for resume functionality."""

    def test_resume_failed_operation(self) -> None:
        """Can resume a failed operation."""
        ResumeTestOperation.fail_step2 = True

        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = ResumeTestOperation(targets=["x"])
        result = sl.run(op)

        assert not result.success
        assert result.state == OperationState.FAILED

        # Now fix the operation and resume
        ResumeTestOperation.fail_step2 = False
        resume_result = sl.resume(result.operation_id)

        assert resume_result.success
        assert resume_result.state == OperationState.COMPLETED
        assert "step3" in resume_result.stages_completed

    def test_resume_skips_completed_stages(self) -> None:
        """Resume doesn't re-run completed stages."""

        class TrackingOperation(Operation):
            name = "tracking"
            stages = [Stage("a"), Stage("b")]
            a_count = 0
            b_count = 0
            fail_b = True

            def a(self, context: Context) -> StageResult:
                TrackingOperation.a_count += 1
                return StageResult(data={"a": True})

            def b(self, context: Context) -> StageResult:
                TrackingOperation.b_count += 1
                if TrackingOperation.fail_b:
                    return StageResult(success=False, error="B failed")
                return StageResult(data={"b": True})

        TrackingOperation.a_count = 0
        TrackingOperation.b_count = 0
        TrackingOperation.fail_b = True

        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = TrackingOperation(targets=["x"])
        result = sl.run(op)
        assert not result.success
        assert TrackingOperation.a_count == 1
        assert TrackingOperation.b_count == 1

        # Resume - 'a' should not run again
        TrackingOperation.fail_b = False
        sl.resume(result.operation_id)
        assert TrackingOperation.a_count == 1  # Still 1
        assert TrackingOperation.b_count == 2  # Now 2

    def test_resume_completed_operation_fails(self) -> None:
        """Cannot resume a completed operation."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = SimpleOperation(targets=["x"])
        result = sl.run(op)

        assert result.success

        with pytest.raises(InvalidOperationStateError):
            sl.resume(result.operation_id)

    def test_resume_emits_audit_event(self) -> None:
        """Resume emits operation_resumed event."""
        ResumeTestOperation.fail_step2 = True

        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test", environment="test")

        op = ResumeTestOperation(targets=["x"])
        result = sl.run(op)

        ResumeTestOperation.fail_step2 = False
        auditor.events.clear()

        sl.resume(result.operation_id)

        event_types = [e.event_type for e in auditor.events]
        assert "operation_resumed" in event_types


class TestAbandon:
    """Tests for operation abandonment (near-miss tracking)."""

    def test_abandon_basic(self) -> None:
        """Can abandon a created operation."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = SimpleOperation(targets=["x"])
        op_id = sl.create(op)

        result = sl.abandon(op_id, reason="Testing abandonment")

        assert result.operation_id == op_id
        assert result.state == OperationState.ABANDONED
        assert result.error == "Testing abandonment"

        # Verify state in store
        _, _, state = store.load_state(op_id)
        assert state == OperationState.ABANDONED

    def test_abandon_emits_audit_event(self) -> None:
        """Abandon emits operation_abandoned audit event."""
        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test", environment="test")

        op = SimpleOperation(targets=["x"])
        op_id = sl.create(op)

        # Clear creation events
        auditor.events.clear()

        sl.abandon(
            op_id,
            reason="Shell exit without completion",
            metadata={"session_duration_seconds": 42.5},
        )

        # Check abandon event was emitted
        abandon_events = [e for e in auditor.events if e.event_type == "operation_abandoned"]
        assert len(abandon_events) == 1

        event = abandon_events[0]
        assert event.operation_id == op_id
        assert event.success is False
        assert event.data["reason"] == "Shell exit without completion"
        assert event.data["previous_state"] == "created"
        assert event.metadata["session_duration_seconds"] == 42.5
        assert event.error == "Shell exit without completion"

    def test_abandon_after_partial_execution(self) -> None:
        """Can abandon operation after running some stages."""
        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test", environment="test")

        op = SimpleOperation(targets=["x"])
        op_id = sl.create(op)

        # Run first stage
        sl.run_stage(op_id, "prepare")

        # Clear audit events
        auditor.events.clear()

        # Abandon the operation
        result = sl.abandon(op_id, reason="User cancelled")

        assert result.state == OperationState.ABANDONED
        assert result.stages_completed == ["prepare"]

        # Check audit event
        abandon_events = [e for e in auditor.events if e.event_type == "operation_abandoned"]
        assert len(abandon_events) == 1
        assert abandon_events[0].data["previous_state"] == "created"

    def test_cannot_abandon_completed_operation(self) -> None:
        """Cannot abandon an already completed operation."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = SimpleOperation(targets=["x"])
        result = sl.run(op)

        # Try to abandon completed operation
        abandon_result = sl.abandon(result.operation_id)

        # Should return current state, not change it
        assert abandon_result.state == OperationState.COMPLETED
        assert "already completed" in abandon_result.error.lower()

    def test_cannot_abandon_rolled_back_operation(self) -> None:
        """Cannot abandon an already rolled back operation."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        op = RollbackOperation(targets=["x"])
        result = sl.run(op)
        sl.rollback(result.operation_id)

        # Try to abandon rolled back operation
        abandon_result = sl.abandon(result.operation_id)

        # Should return current state, not change it
        assert abandon_result.state == OperationState.ROLLED_BACK
        assert "already rolled_back" in abandon_result.error.lower()

    def test_abandon_default_reason(self) -> None:
        """Abandon with no reason uses default."""
        store = MemoryStore()
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test", environment="test")

        op = SimpleOperation(targets=["x"])
        op_id = sl.create(op)

        auditor.events.clear()
        result = sl.abandon(op_id)

        assert result.error == "Operation abandoned"

        abandon_event = [e for e in auditor.events if e.event_type == "operation_abandoned"][0]
        assert abandon_event.data["reason"] == "abandoned"
