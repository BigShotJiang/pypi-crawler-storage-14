"""Unit tests for Safeline config loader."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from sfln.config.loader import (
    _expand_config,
    _expand_env_vars,
    create_safeline_from_config,
    load_config,
)


class TestEnvVarExpansion:
    """Tests for environment variable expansion."""

    def test_expand_simple_var(self) -> None:
        """Expands ${VAR} syntax."""
        os.environ["TEST_VAR"] = "test_value"
        try:
            result = _expand_env_vars("prefix-${TEST_VAR}-suffix")
            assert result == "prefix-test_value-suffix"
        finally:
            del os.environ["TEST_VAR"]

    def test_expand_missing_var_unchanged(self) -> None:
        """Missing variables are left unchanged."""
        result = _expand_env_vars("${NONEXISTENT_VAR_12345}")
        assert result == "${NONEXISTENT_VAR_12345}"

    def test_expand_multiple_vars(self) -> None:
        """Multiple variables in string."""
        os.environ["VAR1"] = "one"
        os.environ["VAR2"] = "two"
        try:
            result = _expand_env_vars("${VAR1}-${VAR2}")
            assert result == "one-two"
        finally:
            del os.environ["VAR1"]
            del os.environ["VAR2"]

    def test_expand_no_vars(self) -> None:
        """String without variables unchanged."""
        result = _expand_env_vars("no variables here")
        assert result == "no variables here"


class TestExpandConfig:
    """Tests for recursive config expansion."""

    def test_expand_dict(self) -> None:
        """Expands variables in dict values."""
        os.environ["TEST_URL"] = "http://example.com"
        try:
            config = {"url": "${TEST_URL}", "name": "test"}
            result = _expand_config(config)
            assert result["url"] == "http://example.com"
            assert result["name"] == "test"
        finally:
            del os.environ["TEST_URL"]

    def test_expand_nested_dict(self) -> None:
        """Expands variables in nested dicts."""
        os.environ["NESTED_VAL"] = "nested_value"
        try:
            config = {"outer": {"inner": "${NESTED_VAL}"}}
            result = _expand_config(config)
            assert result["outer"]["inner"] == "nested_value"
        finally:
            del os.environ["NESTED_VAL"]

    def test_expand_list(self) -> None:
        """Expands variables in lists."""
        os.environ["LIST_VAL"] = "list_value"
        try:
            config = ["${LIST_VAL}", "static"]
            result = _expand_config(config)
            assert result == ["list_value", "static"]
        finally:
            del os.environ["LIST_VAL"]

    def test_expand_preserves_non_strings(self) -> None:
        """Non-string values preserved."""
        config = {"number": 42, "flag": True, "items": [1, 2, 3]}
        result = _expand_config(config)
        assert result["number"] == 42
        assert result["flag"] is True
        assert result["items"] == [1, 2, 3]


class TestLoadConfig:
    """Tests for config file loading."""

    def test_load_yaml_config(self, tmp_path: Path) -> None:
        """Loads YAML config file."""
        config_file = tmp_path / "config.yaml"
        config_file.write_text("""
storage:
  type: memory
environment: production
actor: deploy-bot
""")

        config = load_config(config_file)
        assert config["storage"]["type"] == "memory"
        assert config["environment"] == "production"
        assert config["actor"] == "deploy-bot"

    def test_load_config_with_env_vars(self, tmp_path: Path) -> None:
        """Loads config with environment variable expansion."""
        os.environ["CONFIG_ENV"] = "staging"
        try:
            config_file = tmp_path / "config.yaml"
            config_file.write_text("""
environment: ${CONFIG_ENV}
actor: test
""")

            config = load_config(config_file)
            assert config["environment"] == "staging"
        finally:
            del os.environ["CONFIG_ENV"]

    def test_load_config_file_not_found(self, tmp_path: Path) -> None:
        """Raises FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            load_config(tmp_path / "nonexistent.yaml")

    def test_load_empty_config(self, tmp_path: Path) -> None:
        """Handles empty config file."""
        config_file = tmp_path / "empty.yaml"
        config_file.write_text("")

        config = load_config(config_file)
        assert config == {}


class TestCreateSafelineFromConfig:
    """Tests for creating Safeline from config."""

    def test_create_with_memory_storage(self) -> None:
        """Creates Safeline with memory storage."""
        config = {
            "storage": {"type": "memory"},
            "environment": "test",
            "actor": "tester",
        }

        sl = create_safeline_from_config(config)
        assert sl._environment == "test"
        assert sl._actor == "tester"
        assert sl._store is not None

    def test_create_with_file_storage(self, tmp_path: Path) -> None:
        """Creates Safeline with file storage."""
        config = {
            "storage": {"type": "file", "path": str(tmp_path / "ops")},
            "environment": "test",
            "actor": "tester",
        }

        sl = create_safeline_from_config(config)
        assert sl._store is not None

    def test_create_with_locking(self, tmp_path: Path) -> None:
        """Creates Safeline with locking."""
        config = {
            "storage": {"type": "memory"},
            "locking": {"type": "file", "path": str(tmp_path / "locks")},
        }

        sl = create_safeline_from_config(config)
        assert sl._lock_manager is not None

    def test_create_with_approval(self, tmp_path: Path) -> None:
        """Creates Safeline with approval manager."""
        config = {
            "storage": {"type": "memory"},
            "approval": {"type": "file", "path": str(tmp_path / "approvals")},
        }

        sl = create_safeline_from_config(config)
        assert sl._approval_manager is not None

    def test_create_with_file_audit(self, tmp_path: Path) -> None:
        """Creates Safeline with file audit emitter."""
        config = {
            "storage": {"type": "memory"},
            "audit": {"type": "file", "path": str(tmp_path / "audit.jsonl")},
        }

        sl = create_safeline_from_config(config)
        assert sl._auditor is not None

    def test_create_with_webhooks(self) -> None:
        """Creates Safeline with webhook notifiers."""
        config = {
            "storage": {"type": "memory"},
            "notifications": [
                {
                    "type": "webhook",
                    "url": "https://example.com/webhook",
                    "events": ["operation_failed"],
                },
                {
                    "type": "webhook",
                    "url": "https://example.com/webhook2",
                },
            ],
        }

        sl = create_safeline_from_config(config)
        assert len(sl._notifiers) == 2

    def test_create_minimal(self) -> None:
        """Creates Safeline with minimal config."""
        config = {}

        sl = create_safeline_from_config(config)
        assert sl._environment == "unknown"
        assert sl._actor == "unknown"

    def test_create_with_noop_audit(self) -> None:
        """Creates Safeline with no-op audit."""
        config = {
            "storage": {"type": "memory"},
            "audit": {"type": "none"},
        }

        sl = create_safeline_from_config(config)
        # NoOpEmitter should be set
        from sfln.audit.emitter import NoOpEmitter

        assert isinstance(sl._auditor, NoOpEmitter)


class TestSafelineFromConfig:
    """Tests for Safeline.from_config class method."""

    def test_from_config_classmethod(self, tmp_path: Path) -> None:
        """Safeline.from_config creates instance from file."""
        from sfln import Safeline

        config_file = tmp_path / "safeline.yaml"
        config_file.write_text("""
storage:
  type: memory
environment: production
actor: deploy-bot
""")

        sl = Safeline.from_config(str(config_file))
        assert sl._environment == "production"
        assert sl._actor == "deploy-bot"
