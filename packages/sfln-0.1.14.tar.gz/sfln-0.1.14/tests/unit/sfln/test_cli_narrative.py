"""Tests for CLI narrative data structures."""

import pytest

from sfln.cli.narrative import Narrative, StageNarratives


class TestNarrative:
    """Tests for Narrative dataclass."""

    def test_create_narrative(self) -> None:
        narr = Narrative(
            verdict="SUCCESS",
            summary="operation succeeded",
            what_happened="Operation completed successfully",
            why_it_matters="This ensures the system is working",
            next_steps=["Monitor the system", "Run tests"],
        )

        assert narr.verdict == "SUCCESS"
        assert narr.summary == "operation succeeded"
        assert narr.what_happened == "Operation completed successfully"
        assert narr.why_it_matters == "This ensures the system is working"
        assert len(narr.next_steps) == 2

    def test_create_narrative_minimal(self) -> None:
        narr = Narrative(
            verdict="SUCCESS",
            summary="ok",
            what_happened="Done",
            why_it_matters="Good",
        )

        assert narr.verdict == "SUCCESS"
        assert narr.next_steps == []

    def test_narrative_with_placeholders(self) -> None:
        narr = Narrative(
            verdict="SUCCESS",
            summary="deployed {version}",
            what_happened="Deployed version {version} to {environment}",
            why_it_matters="The new version is live",
            next_steps=["Monitor {environment}", "Test {version}"],
        )

        assert "{version}" in narr.summary
        assert "{version}" in narr.what_happened
        assert "{environment}" in narr.what_happened

    def test_narrative_empty_verdict_fails(self) -> None:
        with pytest.raises(ValueError, match="verdict cannot be empty"):
            Narrative(
                verdict="",
                summary="ok",
                what_happened="done",
                why_it_matters="good",
            )

    def test_narrative_empty_summary_fails(self) -> None:
        with pytest.raises(ValueError, match="summary cannot be empty"):
            Narrative(
                verdict="SUCCESS",
                summary="",
                what_happened="done",
                why_it_matters="good",
            )

    def test_narrative_empty_what_happened_fails(self) -> None:
        with pytest.raises(ValueError, match="what_happened cannot be empty"):
            Narrative(
                verdict="SUCCESS",
                summary="ok",
                what_happened="",
                why_it_matters="good",
            )

    def test_narrative_empty_why_it_matters_fails(self) -> None:
        with pytest.raises(ValueError, match="why_it_matters cannot be empty"):
            Narrative(
                verdict="SUCCESS",
                summary="ok",
                what_happened="done",
                why_it_matters="",
            )


class TestStageNarratives:
    """Tests for StageNarratives dataclass."""

    def test_create_stage_narratives(self) -> None:
        success = Narrative(
            verdict="SUCCESS",
            summary="validated",
            what_happened="Validation passed",
            why_it_matters="Safe to proceed",
        )

        failure = Narrative(
            verdict="ERROR",
            summary="validation failed",
            what_happened="Validation failed",
            why_it_matters="Cannot proceed",
        )

        narr = StageNarratives(
            stage_name="validate",
            action_verb="Validating",
            success=success,
            failure=failure,
        )

        assert narr.stage_name == "validate"
        assert narr.action_verb == "Validating"
        assert narr.success == success
        assert narr.failure == failure
        assert narr.approval_required is None

    def test_create_stage_narratives_minimal(self) -> None:
        success = Narrative(
            verdict="SUCCESS",
            summary="ok",
            what_happened="Done",
            why_it_matters="Good",
        )

        narr = StageNarratives(
            stage_name="validate",
            action_verb="Validating",
            success=success,
        )

        assert narr.stage_name == "validate"
        assert narr.success == success
        assert narr.failure is None
        assert narr.approval_required is None

    def test_create_stage_narratives_with_approval(self) -> None:
        success = Narrative(
            verdict="SUCCESS", summary="ok", what_happened="Done", why_it_matters="Good"
        )

        approval = Narrative(
            verdict="REQUIRES_APPROVAL",
            summary="needs approval",
            what_happened="Approval required",
            why_it_matters="Safety gate",
        )

        narr = StageNarratives(
            stage_name="apply",
            action_verb="Applying",
            success=success,
            approval_required=approval,
        )

        assert narr.approval_required == approval

    def test_stage_narratives_empty_stage_name_fails(self) -> None:
        success = Narrative(
            verdict="SUCCESS", summary="ok", what_happened="Done", why_it_matters="Good"
        )

        with pytest.raises(ValueError, match="stage_name cannot be empty"):
            StageNarratives(
                stage_name="",
                action_verb="Validating",
                success=success,
            )

    def test_stage_narratives_empty_action_verb_fails(self) -> None:
        success = Narrative(
            verdict="SUCCESS", summary="ok", what_happened="Done", why_it_matters="Good"
        )

        with pytest.raises(ValueError, match="action_verb cannot be empty"):
            StageNarratives(
                stage_name="validate",
                action_verb="",
                success=success,
            )

    def test_stage_narratives_no_success_fails(self) -> None:
        with pytest.raises(ValueError, match="success narrative is required"):
            StageNarratives(
                stage_name="validate",
                action_verb="Validating",
                success=None,  # type: ignore
            )
