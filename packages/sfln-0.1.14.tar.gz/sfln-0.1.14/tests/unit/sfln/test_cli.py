"""Unit tests for Safeline CLI generator."""

from __future__ import annotations

import json

from click.testing import CliRunner

from sfln import Context, MemoryStore, Operation, Safeline, Stage, StageResult
from sfln.cli.generator import create_multi_operation_cli, generate_cli
from sfln.cli.output import OutputFormatter


class SimpleTestOperation(Operation):
    """Simple operation for CLI testing without approval gates."""

    name = "test-op"
    stages = [
        Stage("prepare"),
        Stage("execute"),
        Stage("cleanup"),
    ]

    def prepare(self, context: Context) -> StageResult:
        return StageResult(data={"prepared": True})

    def execute(self, context: Context) -> StageResult:
        if context.dry_run:
            return StageResult(data={"dry_run": True})
        return StageResult(data={"executed": True})

    def cleanup(self, context: Context) -> StageResult:
        return StageResult(data={"cleaned": True})


class ApprovalTestOperation(Operation):
    """Operation with approval gate for testing."""

    name = "approval-op"
    stages = [
        Stage("prepare"),
        Stage("execute", needs_approval=True),
        Stage("cleanup"),
    ]

    def prepare(self, context: Context) -> StageResult:
        return StageResult(data={"prepared": True})

    def execute(self, context: Context) -> StageResult:
        if context.dry_run:
            return StageResult(data={"dry_run": True})
        return StageResult(data={"executed": True})

    def cleanup(self, context: Context) -> StageResult:
        return StageResult(data={"cleaned": True})


class FailingOperation(Operation):
    """Operation that fails."""

    name = "fail-op"
    stages = [Stage("fail")]

    def fail(self, context: Context) -> StageResult:
        return StageResult(success=False, error="Intentional failure")


class TestGenerateCLI:
    """Tests for generate_cli function."""

    def test_generate_cli_creates_group(self) -> None:
        """generate_cli creates a Click group."""
        store = MemoryStore()
        sl = Safeline(store=store)

        cli = generate_cli(SimpleTestOperation, sl)

        assert cli is not None
        assert hasattr(cli, "commands")

    def test_generate_cli_has_expected_commands(self) -> None:
        """Generated CLI has all expected commands."""
        store = MemoryStore()
        sl = Safeline(store=store)

        cli = generate_cli(SimpleTestOperation, sl)

        expected_commands = ["run", "create", "stage", "approve", "status", "rollback", "stages"]
        for cmd in expected_commands:
            assert cmd in cli.commands

    def test_generate_cli_custom_name(self) -> None:
        """generate_cli respects custom name."""
        store = MemoryStore()
        sl = Safeline(store=store)

        cli = generate_cli(SimpleTestOperation, sl, name="custom-name")

        assert cli.name == "custom-name"


class TestCLIRunCommand:
    """Tests for the 'run' command."""

    def test_run_success(self) -> None:
        """Run command executes operation successfully."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["run", "target1", "target2", "--dry-run"])

        assert result.exit_code == 0
        assert "completed successfully" in result.output

    def test_run_no_targets(self) -> None:
        """Run command fails without targets."""
        store = MemoryStore()
        sl = Safeline(store=store)
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["run"])

        assert result.exit_code == 1
        assert "No targets specified" in result.output

    def test_run_json_output(self) -> None:
        """Run command supports JSON output."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["--json", "run", "target1", "--dry-run"])

        assert result.exit_code == 0
        # The output may be multi-line formatted JSON
        # Try to parse the whole output as JSON, or find JSON within it
        output = result.output.strip()
        try:
            data = json.loads(output)
            assert "operation_id" in data
        except json.JSONDecodeError:
            # Try to find JSON block in output
            import re

            match = re.search(r'\{[^{}]*"operation_id"[^{}]*\}', output, re.DOTALL)
            assert match is not None, f"No JSON with operation_id found: {output}"

    def test_run_with_options(self) -> None:
        """Run command accepts actor and environment options."""
        store = MemoryStore()
        sl = Safeline(store=store)
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["run", "target1", "--actor", "ci-bot", "--environment", "staging", "--dry-run"],
        )

        assert result.exit_code == 0


class TestCLICreateCommand:
    """Tests for the 'create' command."""

    def test_create_success(self) -> None:
        """Create command creates operation."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["create", "target1"])

        assert result.exit_code == 0
        assert "Created operation" in result.output

    def test_create_no_targets(self) -> None:
        """Create command fails without targets."""
        store = MemoryStore()
        sl = Safeline(store=store)
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["create"])

        assert result.exit_code == 1


class TestCLIStageCommand:
    """Tests for the 'stage' command."""

    def test_stage_success(self) -> None:
        """Stage command runs specific stage."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(SimpleTestOperation, sl)

        # First create an operation
        op = SimpleTestOperation(targets=["target1"])
        op_id = sl.create(op)

        runner = CliRunner()
        result = runner.invoke(cli, ["stage", op_id, "prepare"])

        assert result.exit_code == 0
        assert "completed" in result.output

    def test_stage_approval_required(self) -> None:
        """Stage command handles approval required."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(ApprovalTestOperation, sl)

        op = ApprovalTestOperation(targets=["target1"])
        op_id = sl.create(op)
        sl.run_stage(op_id, "prepare")

        runner = CliRunner()
        result = runner.invoke(cli, ["stage", op_id, "execute"])

        assert result.exit_code == 2
        assert "requires approval" in result.output


class TestCLIApproveCommand:
    """Tests for the 'approve' command."""

    def test_approve_success(self) -> None:
        """Approve command approves stage."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(ApprovalTestOperation, sl)

        op = ApprovalTestOperation(targets=["target1"])
        op_id = sl.create(op)
        sl.run_stage(op_id, "prepare")

        # Trigger approval request
        try:
            sl.run_stage(op_id, "execute")
        except Exception:
            pass

        runner = CliRunner()
        result = runner.invoke(cli, ["approve", op_id, "execute", "--approver", "admin"])

        assert result.exit_code == 0
        assert "approved" in result.output


class TestCLIStatusCommand:
    """Tests for the 'status' command."""

    def test_status_success(self) -> None:
        """Status command shows operation status."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(SimpleTestOperation, sl)

        op = SimpleTestOperation(targets=["target1"])
        op_id = sl.create(op)

        runner = CliRunner()
        result = runner.invoke(cli, ["status", op_id])

        assert result.exit_code == 0

    def test_status_not_found(self) -> None:
        """Status command handles missing operation."""
        store = MemoryStore()
        sl = Safeline(store=store)
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["status", "nonexistent-id"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestCLIRollbackCommand:
    """Tests for the 'rollback' command."""

    def test_rollback_success(self) -> None:
        """Rollback command rolls back operation."""

        class RollbackOp(Operation):
            name = "rollback"
            stages = [Stage("step", reversible=True)]

            def step(self, ctx: Context) -> StageResult:
                return StageResult(data={"done": True})

            def rollback_step(self, ctx: Context) -> StageResult:
                return StageResult(data={"rolled_back": True})

        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")
        cli = generate_cli(RollbackOp, sl)

        op = RollbackOp(targets=["target1"])
        result = sl.run(op)

        runner = CliRunner()
        cli_result = runner.invoke(cli, ["rollback", result.operation_id])

        assert cli_result.exit_code == 0
        assert "rolled back" in cli_result.output


class TestCLIStagesCommand:
    """Tests for the 'stages' command."""

    def test_stages_lists_stages(self) -> None:
        """Stages command lists all stages."""
        store = MemoryStore()
        sl = Safeline(store=store)
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["stages"])

        assert result.exit_code == 0

    def test_stages_json_output(self) -> None:
        """Stages command outputs JSON."""
        store = MemoryStore()
        sl = Safeline(store=store)
        cli = generate_cli(SimpleTestOperation, sl)

        runner = CliRunner()
        result = runner.invoke(cli, ["--json", "stages"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "stages" in data
        assert len(data["stages"]) == 3


class TestMultiOperationCLI:
    """Tests for create_multi_operation_cli."""

    def test_multi_cli_creates_subgroups(self) -> None:
        """Multi CLI creates subgroups for each operation."""
        store = MemoryStore()
        sl = Safeline(store=store)

        cli = create_multi_operation_cli(
            operations={
                "test": SimpleTestOperation,
                "fail": FailingOperation,
            },
            safeline=sl,
        )

        assert "test" in cli.commands
        assert "fail" in cli.commands

    def test_multi_cli_subcommands_work(self) -> None:
        """Multi CLI subcommands work correctly."""
        store = MemoryStore()
        sl = Safeline(store=store, actor="test", environment="test")

        cli = create_multi_operation_cli(
            operations={"test": SimpleTestOperation},
            safeline=sl,
        )

        runner = CliRunner()
        result = runner.invoke(cli, ["test", "run", "target1", "--dry-run"])

        assert result.exit_code == 0


class TestOutputFormatter:
    """Tests for OutputFormatter."""

    def test_formatter_text_mode(self) -> None:
        """OutputFormatter works in text mode."""
        fmt = OutputFormatter(json_output=False)
        # These shouldn't raise
        fmt.log("info message")
        fmt.success("success message")
        fmt.error("error message")
        fmt.warning("warning message")

    def test_formatter_json_mode(self) -> None:
        """OutputFormatter works in JSON mode."""
        fmt = OutputFormatter(json_output=True)
        fmt.log("info message")
        fmt.success("success message")

    def test_formatter_output_json(self, capsys) -> None:
        """OutputFormatter.output produces JSON in json mode."""
        fmt = OutputFormatter(json_output=True)
        fmt.output({"key": "value"})

        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data == {"key": "value"}

    def test_formatter_output_text(self, capsys) -> None:
        """OutputFormatter.output produces formatted text in text mode."""
        fmt = OutputFormatter(json_output=False)
        fmt.output({"key": "value"})

        captured = capsys.readouterr()
        # Should have some output
        assert "key" in captured.out or len(captured.out) > 0
