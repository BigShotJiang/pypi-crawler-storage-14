"""Unit tests for Safeline notifications."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from sfln.audit.events import AuditEvent
from sfln.notifications.webhook import (
    CompositeNotifier,
    NoOpNotifier,
    Notifier,
    WebhookNotifier,
)


class TestWebhookNotifier:
    """Tests for WebhookNotifier."""

    def test_webhook_notifier_creation(self) -> None:
        """WebhookNotifier can be created with URL."""
        notifier = WebhookNotifier(url="https://example.com/webhook")
        assert notifier.url == "https://example.com/webhook"
        assert "operation_completed" in notifier.events
        assert "operation_failed" in notifier.events
        assert "approval_requested" in notifier.events

    def test_webhook_notifier_custom_events(self) -> None:
        """WebhookNotifier respects custom events list."""
        notifier = WebhookNotifier(
            url="https://example.com/webhook",
            events=["stage_completed", "stage_failed"],
        )
        assert "stage_completed" in notifier.events
        assert "stage_failed" in notifier.events
        assert "operation_completed" not in notifier.events

    def test_webhook_ignores_non_matching_event(self) -> None:
        """WebhookNotifier ignores events not in its filter."""
        notifier = WebhookNotifier(
            url="https://example.com/webhook",
            events=["operation_failed"],
            async_send=False,
        )

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_completed",  # Not in filter
            actor="test",
            environment="test",
        )

        # Should not raise or make HTTP call
        with patch("sfln.notifications.webhook.urlopen") as mock_urlopen:
            notifier.notify(event)
            mock_urlopen.assert_not_called()

    def test_webhook_sends_matching_event(self) -> None:
        """WebhookNotifier sends events that match filter."""
        notifier = WebhookNotifier(
            url="https://example.com/webhook",
            events=["operation_failed"],
            async_send=False,
        )

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_failed",
            actor="test",
            environment="test",
        )

        with patch("sfln.notifications.webhook.urlopen") as mock_urlopen:
            mock_response = MagicMock()
            mock_response.__enter__ = MagicMock(return_value=mock_response)
            mock_response.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_response

            notifier.notify(event)
            mock_urlopen.assert_called_once()

    def test_webhook_failure_non_fatal(self) -> None:
        """WebhookNotifier swallows HTTP errors."""
        from urllib.error import URLError

        notifier = WebhookNotifier(
            url="https://example.com/webhook",
            events=["operation_failed"],
            async_send=False,
        )

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_failed",
            actor="test",
            environment="test",
        )

        with patch("sfln.notifications.webhook.urlopen") as mock_urlopen:
            mock_urlopen.side_effect = URLError("Connection refused")

            # Should not raise
            notifier.notify(event)

    def test_webhook_includes_custom_headers(self) -> None:
        """WebhookNotifier includes custom headers in request."""
        notifier = WebhookNotifier(
            url="https://example.com/webhook",
            events=["operation_failed"],
            headers={"Authorization": "Bearer token123"},
            async_send=False,
        )

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_failed",
            actor="test",
            environment="test",
        )

        with patch("sfln.notifications.webhook.urlopen") as mock_urlopen:
            mock_response = MagicMock()
            mock_response.__enter__ = MagicMock(return_value=mock_response)
            mock_response.__exit__ = MagicMock(return_value=False)
            mock_urlopen.return_value = mock_response

            notifier.notify(event)

            # Check request was made with headers
            call_args = mock_urlopen.call_args
            request = call_args[0][0]
            assert request.get_header("Authorization") == "Bearer token123"


class TestCompositeNotifier:
    """Tests for CompositeNotifier."""

    def test_composite_notifier_delegates(self) -> None:
        """CompositeNotifier delegates to all notifiers."""
        mock1 = MagicMock(spec=Notifier)
        mock2 = MagicMock(spec=Notifier)

        composite = CompositeNotifier([mock1, mock2])

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_completed",
            actor="test",
            environment="test",
        )

        composite.notify(event)

        mock1.notify.assert_called_once_with(event)
        mock2.notify.assert_called_once_with(event)

    def test_composite_notifier_empty(self) -> None:
        """CompositeNotifier handles empty list."""
        composite = CompositeNotifier([])

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_completed",
            actor="test",
            environment="test",
        )

        # Should not raise
        composite.notify(event)


class TestNoOpNotifier:
    """Tests for NoOpNotifier."""

    def test_noop_notifier_does_nothing(self) -> None:
        """NoOpNotifier does nothing."""
        notifier = NoOpNotifier()

        event = AuditEvent(
            operation_id="op-123",
            operation_type="test",
            event_type="operation_completed",
            actor="test",
            environment="test",
        )

        # Should not raise
        notifier.notify(event)


class TestNotifierIntegrationWithSafeline:
    """Tests for notifier integration with Safeline."""

    def test_safeline_calls_notifiers_on_events(self) -> None:
        """Safeline sends notifications for audit events."""
        from sfln import Context, MemoryStore, Operation, Safeline, Stage, StageResult

        class TestOp(Operation):
            name = "test"
            stages = [Stage("do")]

            def do(self, context: Context) -> StageResult:
                return StageResult(data={"done": True})

        mock_notifier = MagicMock(spec=Notifier)

        store = MemoryStore()
        sl = Safeline(
            store=store,
            actor="test",
            environment="test",
            notifiers=[mock_notifier],
        )

        op = TestOp(targets=["x"])
        sl.run(op)

        # Should have been called for various events
        assert mock_notifier.notify.call_count > 0

        # Check event types notified
        event_types = [call[0][0].event_type for call in mock_notifier.notify.call_args_list]
        assert "operation_created" in event_types
        assert "operation_completed" in event_types
