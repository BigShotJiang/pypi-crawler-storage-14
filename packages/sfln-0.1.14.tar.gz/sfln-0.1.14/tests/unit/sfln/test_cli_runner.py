"""Tests for CLI generic stage runner."""

from unittest.mock import Mock, patch

from sfln import OperationResult, OperationState
from sfln.cli.narrative import Narrative, StageNarratives
from sfln.cli.runner import run_stage_command


class TestRunStageCommand:
    """Tests for run_stage_command function."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        self.success_narrative = Narrative(
            verdict="SUCCESS",
            summary="operation succeeded",
            what_happened="Operation {operation_id} completed in {environment}",
            why_it_matters="All systems operational",
            next_steps=["Monitor the system"],
        )

        self.failure_narrative = Narrative(
            verdict="ERROR",
            summary="operation failed",
            what_happened="Operation {operation_id} failed",
            why_it_matters="System may be impacted",
            next_steps=["Check logs"],
        )

        self.approval_narrative = Narrative(
            verdict="REQUIRES_APPROVAL",
            summary="needs approval",
            what_happened="Operation requires approval",
            why_it_matters="Safety gate",
            next_steps=["Approve the operation"],
        )

        self.narratives = StageNarratives(
            stage_name="validate",
            action_verb="Validating",
            success=self.success_narrative,
            failure=self.failure_narrative,
            approval_required=self.approval_narrative,
        )

    def test_successful_stage_execution(self) -> None:
        """Test successful stage execution with narrative output."""
        # Mock context
        ctx = Mock()
        ctx.obj = {"json_output": False}

        # Mock safeline
        safeline = Mock()
        safeline._environment = "production"

        # Mock operation details with proper stage_results
        stage_results_dict = {
            "validate": {"valid": True},
            "plan": {"file_count": 10, "total_bytes": 1024},
        }
        details = Mock()
        details.stage_results = stage_results_dict
        safeline.get_operation.return_value = details

        # Mock successful stage result
        stage_result = Mock()
        stage_result.success = True
        stage_result.error = None
        safeline.run_stage.return_value = stage_result

        # Run command (should not raise or exit)
        with patch("sys.exit") as mock_exit:
            run_stage_command(ctx, "op-123", self.narratives, safeline=safeline)

            # Should not exit with error
            mock_exit.assert_not_called()

        # Verify calls
        safeline.get_operation.assert_called_with("op-123")
        safeline.run_stage.assert_called_once_with("op-123", "validate")

    def test_failed_stage_execution(self) -> None:
        """Test failed stage execution."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"
        safeline.get_operation.return_value = Mock()

        # Mock failed result
        result = OperationResult(
            operation_id="op-123",
            state=OperationState.FAILED,
            stages_completed=[],
            stage_results={"validate": {"error": "Validation failed"}},
            error="Validation failed",
        )
        safeline.run_stage.return_value = result

        # Should exit with code 1
        with patch("sys.exit") as mock_exit:
            run_stage_command(ctx, "op-123", self.narratives, safeline=safeline)

            mock_exit.assert_called_once_with(1)

    def test_operation_not_found(self) -> None:
        """Test when operation is not found."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"
        safeline.get_operation.return_value = None

        # Should exit with code 1
        with patch("sys.exit") as mock_exit:
            run_stage_command(ctx, "nonexistent", self.narratives, safeline=safeline)

            # Should have called exit with 1 (may be called multiple times due to error handling)
            assert mock_exit.called
            assert any(call[0][0] == 1 for call in mock_exit.call_args_list)

    def test_json_output_mode(self) -> None:
        """Test JSON output mode."""
        ctx = Mock()
        ctx.obj = {"json_output": True}

        safeline = Mock()
        safeline._environment = "production"

        # Mock operation details with proper stage_results
        stage_results_dict = {"validate": {"valid": True, "score": 95}}
        details = Mock()
        details.stage_results = stage_results_dict
        safeline.get_operation.return_value = details

        # Mock successful stage result
        stage_result = Mock()
        stage_result.success = True
        stage_result.error = None
        safeline.run_stage.return_value = stage_result

        # Capture JSON output - output goes to stdout via echo/print
        from io import StringIO

        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            run_stage_command(ctx, "op-123", self.narratives, safeline=safeline)

            # Should have printed JSON
            output = mock_stdout.getvalue()
            assert "operation_id" in output
            assert "op-123" in output
            assert "valid" in output

    def test_json_output_mode_failure(self) -> None:
        """Test JSON output mode with failure."""
        ctx = Mock()
        ctx.obj = {"json_output": True}

        safeline = Mock()
        safeline._environment = "production"
        safeline.get_operation.return_value = Mock()

        result = OperationResult(
            operation_id="op-123",
            state=OperationState.FAILED,
            stages_completed=[],
            stage_results={"validate": {"error": "Failed"}},
            error="Failed",
        )
        safeline.run_stage.return_value = result

        with patch("sys.exit") as mock_exit, patch("builtins.print"):
            run_stage_command(ctx, "op-123", self.narratives, safeline=safeline)

            # Should exit with code 1
            mock_exit.assert_called_once_with(1)

    def test_approval_required_scenario(self) -> None:
        """Test when approval is required."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"

        # Mock operation details with proper stage_results
        stage_results_dict = {"validate": {"requires_approval": True}}
        details = Mock()
        details.stage_results = stage_results_dict
        safeline.get_operation.return_value = details

        # Mock successful stage result (approval required is still success)
        stage_result = Mock()
        stage_result.success = True
        stage_result.error = None
        safeline.run_stage.return_value = stage_result

        # Should not exit (approval required is success but paused)
        with patch("sys.exit") as mock_exit:
            run_stage_command(ctx, "op-123", self.narratives, safeline=safeline)

            mock_exit.assert_not_called()

    def test_extract_data_callback(self) -> None:
        """Test custom data extraction callback."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"

        # Mock operation details with proper stage_results
        stage_results_dict = {
            "validate": {"custom_field": "custom_value"},
            "plan": {"file_count": 10},
        }
        details = Mock()
        details.stage_results = stage_results_dict
        safeline.get_operation.return_value = details

        # Mock successful stage result
        stage_result = Mock()
        stage_result.success = True
        stage_result.error = None
        safeline.run_stage.return_value = stage_result

        # Custom extractor
        def extract_data(stage_results: dict) -> dict:
            return {"custom": stage_results["validate"]["custom_field"]}

        with patch("sys.exit") as mock_exit:
            run_stage_command(
                ctx,
                "op-123",
                self.narratives,
                safeline=safeline,
                extract_data=extract_data,
            )

            mock_exit.assert_not_called()

    def test_pre_run_callback_abort(self) -> None:
        """Test pre_run callback that aborts execution."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"
        safeline.get_operation.return_value = Mock()

        # Pre-run that returns False to abort
        def pre_run(details: any) -> bool:
            return False

        with patch("sys.exit") as mock_exit:
            run_stage_command(
                ctx,
                "op-123",
                self.narratives,
                safeline=safeline,
                pre_run=pre_run,
            )

            # Should not call run_stage
            safeline.run_stage.assert_not_called()
            # Should not exit
            mock_exit.assert_not_called()

    def test_pre_run_callback_continue(self) -> None:
        """Test pre_run callback that allows execution."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"

        # Mock operation details with proper stage_results
        stage_results_dict = {"validate": {}}
        details = Mock()
        details.stage_results = stage_results_dict
        safeline.get_operation.return_value = details

        # Mock successful stage result
        stage_result = Mock()
        stage_result.success = True
        stage_result.error = None
        safeline.run_stage.return_value = stage_result

        # Pre-run that returns True to continue
        def pre_run(details: any) -> bool:
            return True

        with patch("sys.exit") as mock_exit:
            run_stage_command(
                ctx,
                "op-123",
                self.narratives,
                safeline=safeline,
                pre_run=pre_run,
            )

            # Should call run_stage
            safeline.run_stage.assert_called_once()
            mock_exit.assert_not_called()

    def test_build_extra_info_callback(self) -> None:
        """Test custom additional info builder."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"

        # Mock operation details with proper stage_results
        stage_results_dict = {"validate": {"score": 95}}
        details = Mock()
        details.stage_results = stage_results_dict
        safeline.get_operation.return_value = details

        # Mock successful stage result
        stage_result = Mock()
        stage_result.success = True
        stage_result.error = None
        safeline.run_stage.return_value = stage_result

        # Custom info builder
        def build_extra_info(data: dict, stage_data: dict) -> dict:
            return {"Validation Score": str(stage_data.get("score", 0))}

        with patch("sys.exit") as mock_exit:
            run_stage_command(
                ctx,
                "op-123",
                self.narratives,
                safeline=safeline,
                build_extra_info=build_extra_info,
            )

            mock_exit.assert_not_called()

    def test_exception_handling(self) -> None:
        """Test exception handling."""
        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"
        safeline.get_operation.side_effect = Exception("Unexpected error")

        with patch("sys.exit") as mock_exit:
            run_stage_command(ctx, "op-123", self.narratives, safeline=safeline)

            # Should exit with code 1 on exception
            mock_exit.assert_called_once_with(1)

    def test_default_failure_narrative(self) -> None:
        """Test default failure narrative when none provided."""
        # Narratives without custom failure
        narratives = StageNarratives(
            stage_name="validate",
            action_verb="Validating",
            success=self.success_narrative,
        )

        ctx = Mock()
        ctx.obj = {"json_output": False}

        safeline = Mock()
        safeline._environment = "production"
        safeline.get_operation.return_value = Mock()

        result = OperationResult(
            operation_id="op-123",
            state=OperationState.FAILED,
            stages_completed=[],
            stage_results={},
            error="Something went wrong",
        )
        safeline.run_stage.return_value = result

        with patch("sys.exit") as mock_exit:
            run_stage_command(ctx, "op-123", narratives, safeline=safeline)

            # Should exit with code 1
            mock_exit.assert_called_once_with(1)
