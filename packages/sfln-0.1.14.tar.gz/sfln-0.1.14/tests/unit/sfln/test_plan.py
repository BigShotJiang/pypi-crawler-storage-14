"""Tests for OperationPlan and related types."""

from datetime import datetime, timedelta, timezone

from sfln.core.plan import (
    PLAN_SCHEMA_VERSION,
    OperationPlan,
    StagePlan,
    StageStatusRecord,
    generate_plan_id,
)
from sfln.core.result import OperationState
from sfln.core.stage import StageState


class TestGeneratePlanId:
    """Tests for plan ID generation."""

    def test_generates_unique_ids(self) -> None:
        """Plan IDs should be unique."""
        ids = [generate_plan_id() for _ in range(100)]
        assert len(set(ids)) == 100

    def test_format(self) -> None:
        """Plan ID should follow expected format."""
        plan_id = generate_plan_id()
        assert plan_id.startswith("plan-")
        parts = plan_id.split("-")
        assert len(parts) == 4  # plan, date, time, hex
        assert len(parts[1]) == 8  # YYYYMMDD
        assert len(parts[2]) == 6  # HHMMSS
        assert len(parts[3]) == 8  # hex


class TestStagePlan:
    """Tests for StagePlan dataclass."""

    def test_creation_with_defaults(self) -> None:
        """StagePlan should have sensible defaults."""
        plan = StagePlan(name="test")
        assert plan.name == "test"
        assert plan.required is True
        assert plan.needs_approval is False
        assert plan.needs_lock is False
        assert plan.reversible is False
        assert plan.timeout_seconds is None
        assert plan.retry_count == 0
        assert plan.description == ""

    def test_creation_with_all_fields(self) -> None:
        """StagePlan should accept all fields."""
        plan = StagePlan(
            name="deploy",
            required=False,
            needs_approval=True,
            needs_lock=True,
            reversible=True,
            timeout_seconds=300,
            retry_count=3,
            description="Deploy the application",
        )
        assert plan.name == "deploy"
        assert plan.required is False
        assert plan.needs_approval is True
        assert plan.needs_lock is True
        assert plan.reversible is True
        assert plan.timeout_seconds == 300
        assert plan.retry_count == 3
        assert plan.description == "Deploy the application"

    def test_to_dict(self) -> None:
        """StagePlan should serialize to dict."""
        plan = StagePlan(name="test", needs_approval=True)
        data = plan.to_dict()
        assert data["name"] == "test"
        assert data["needs_approval"] is True
        assert data["required"] is True

    def test_from_dict(self) -> None:
        """StagePlan should deserialize from dict."""
        data = {
            "name": "deploy",
            "needs_approval": True,
            "timeout_seconds": 60,
        }
        plan = StagePlan.from_dict(data)
        assert plan.name == "deploy"
        assert plan.needs_approval is True
        assert plan.timeout_seconds == 60
        assert plan.required is True  # default

    def test_roundtrip(self) -> None:
        """StagePlan should survive serialization roundtrip."""
        original = StagePlan(
            name="test",
            required=False,
            needs_approval=True,
            reversible=True,
        )
        restored = StagePlan.from_dict(original.to_dict())
        assert restored.name == original.name
        assert restored.required == original.required
        assert restored.needs_approval == original.needs_approval
        assert restored.reversible == original.reversible


class TestStageStatusRecord:
    """Tests for StageStatusRecord dataclass."""

    def test_creation_with_defaults(self) -> None:
        """StageStatusRecord should have sensible defaults."""
        status = StageStatusRecord(stage_name="test")
        assert status.stage_name == "test"
        assert status.state == StageState.PENDING.value
        assert status.attempts == 0
        assert status.started_at is None
        assert status.completed_at is None
        assert status.error is None
        assert status.result_data == {}
        assert status.rollback_data == {}
        assert status.approved_by is None
        assert status.approved_at is None

    def test_creation_with_all_fields(self) -> None:
        """StageStatusRecord should accept all fields."""
        status = StageStatusRecord(
            stage_name="deploy",
            state=StageState.COMPLETED.value,
            attempts=2,
            started_at="2024-01-01T00:00:00Z",
            completed_at="2024-01-01T00:01:00Z",
            result_data={"deployed": True},
            rollback_data={"previous": "v1"},
            approved_by="admin",
            approved_at="2024-01-01T00:00:00Z",
        )
        assert status.stage_name == "deploy"
        assert status.state == StageState.COMPLETED.value
        assert status.attempts == 2
        assert status.result_data == {"deployed": True}
        assert status.approved_by == "admin"

    def test_to_dict(self) -> None:
        """StageStatusRecord should serialize to dict."""
        status = StageStatusRecord(
            stage_name="test",
            state=StageState.RUNNING.value,
            attempts=1,
        )
        data = status.to_dict()
        assert data["stage_name"] == "test"
        assert data["state"] == "running"
        assert data["attempts"] == 1

    def test_from_dict(self) -> None:
        """StageStatusRecord should deserialize from dict."""
        data = {
            "stage_name": "deploy",
            "state": "completed",
            "attempts": 3,
            "result_data": {"success": True},
        }
        status = StageStatusRecord.from_dict(data)
        assert status.stage_name == "deploy"
        assert status.state == "completed"
        assert status.attempts == 3
        assert status.result_data == {"success": True}

    def test_roundtrip(self) -> None:
        """StageStatusRecord should survive serialization roundtrip."""
        original = StageStatusRecord(
            stage_name="test",
            state=StageState.FAILED.value,
            attempts=2,
            error="Something went wrong",
        )
        restored = StageStatusRecord.from_dict(original.to_dict())
        assert restored.stage_name == original.stage_name
        assert restored.state == original.state
        assert restored.attempts == original.attempts
        assert restored.error == original.error


class TestOperationPlan:
    """Tests for OperationPlan dataclass."""

    def test_creation_minimal(self) -> None:
        """OperationPlan should create with minimal fields."""
        plan = OperationPlan(
            plan_id="plan-20240101-000000-abc12345",
            operation_id="op-20240101-000000-abc12345",
            operation_type="test-op",
        )
        assert plan.plan_id == "plan-20240101-000000-abc12345"
        assert plan.operation_id == "op-20240101-000000-abc12345"
        assert plan.operation_type == "test-op"
        assert plan.schema_version == PLAN_SCHEMA_VERSION
        assert plan.state == OperationState.CREATED
        assert plan.stages == []
        assert plan.stage_statuses == {}

    def test_creation_full(self) -> None:
        """OperationPlan should accept all fields."""
        stages = [
            StagePlan(name="validate"),
            StagePlan(name="deploy", needs_approval=True),
        ]
        stage_statuses = {
            "validate": StageStatusRecord(
                stage_name="validate",
                state=StageState.COMPLETED.value,
            ),
            "deploy": StageStatusRecord(
                stage_name="deploy",
                state=StageState.PENDING.value,
            ),
        }

        plan = OperationPlan(
            plan_id="plan-20240101-000000-abc12345",
            operation_id="op-20240101-000000-abc12345",
            operation_type="deploy",
            environment="production",
            actor="admin@example.com",
            targets=["server-1", "server-2"],
            metadata={"ticket": "JIRA-123"},
            dry_run=False,
            protection_level="production",
            protection_settings={"require_approval": True},
            state=OperationState.RUNNING,
            stages=stages,
            stage_statuses=stage_statuses,
            stage_results={"validate": {"valid": True}},
        )

        assert plan.environment == "production"
        assert plan.actor == "admin@example.com"
        assert len(plan.targets) == 2
        assert len(plan.stages) == 2
        assert len(plan.stage_statuses) == 2

    def test_is_active(self) -> None:
        """is_active should reflect operation state."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
        )
        assert plan.is_active  # CREATED

        plan.state = OperationState.RUNNING
        assert plan.is_active

        plan.state = OperationState.PAUSED
        assert plan.is_active

        plan.state = OperationState.COMPLETED
        assert not plan.is_active

        plan.state = OperationState.FAILED
        assert not plan.is_active

    def test_is_expired(self) -> None:
        """is_expired should check expires_at."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
        )
        assert not plan.is_expired  # No expiry

        # Set expiry in the past
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        plan.expires_at = past
        assert plan.is_expired

        # Set expiry in the future
        future = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        plan.expires_at = future
        assert not plan.is_expired

    def test_current_stage(self) -> None:
        """current_stage should return running stage."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
            stage_statuses={
                "validate": StageStatusRecord(
                    stage_name="validate",
                    state=StageState.COMPLETED.value,
                ),
                "deploy": StageStatusRecord(
                    stage_name="deploy",
                    state=StageState.RUNNING.value,
                ),
            },
        )
        assert plan.current_stage == "deploy"

    def test_next_stage(self) -> None:
        """next_stage should return next pending stage."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
            stages=[
                StagePlan(name="validate"),
                StagePlan(name="deploy"),
                StagePlan(name="verify"),
            ],
            stage_statuses={
                "validate": StageStatusRecord(
                    stage_name="validate",
                    state=StageState.COMPLETED.value,
                ),
                "deploy": StageStatusRecord(
                    stage_name="deploy",
                    state=StageState.PENDING.value,
                ),
                "verify": StageStatusRecord(
                    stage_name="verify",
                    state=StageState.PENDING.value,
                ),
            },
        )
        assert plan.next_stage == "deploy"

    def test_completed_stages(self) -> None:
        """completed_stages should return list of completed stage names."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
            stage_statuses={
                "validate": StageStatusRecord(
                    stage_name="validate",
                    state=StageState.COMPLETED.value,
                ),
                "deploy": StageStatusRecord(
                    stage_name="deploy",
                    state=StageState.COMPLETED.value,
                ),
                "verify": StageStatusRecord(
                    stage_name="verify",
                    state=StageState.PENDING.value,
                ),
            },
        )
        completed = plan.completed_stages
        assert "validate" in completed
        assert "deploy" in completed
        assert "verify" not in completed

    def test_failed_stages(self) -> None:
        """failed_stages should return list of failed stage names."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
            stage_statuses={
                "validate": StageStatusRecord(
                    stage_name="validate",
                    state=StageState.COMPLETED.value,
                ),
                "deploy": StageStatusRecord(
                    stage_name="deploy",
                    state=StageState.FAILED.value,
                    error="Deployment failed",
                ),
            },
        )
        failed = plan.failed_stages
        assert "deploy" in failed
        assert "validate" not in failed

    def test_add_audit_event(self) -> None:
        """add_audit_event should link events to plan."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
        )
        plan.add_audit_event("evt-001")
        plan.add_audit_event("evt-002")
        plan.add_audit_event("evt-001")  # Duplicate

        assert len(plan.audit_event_ids) == 2
        assert "evt-001" in plan.audit_event_ids
        assert "evt-002" in plan.audit_event_ids

    def test_to_dict(self) -> None:
        """OperationPlan should serialize to dict."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
            environment="production",
            targets=["server-1"],
            stages=[StagePlan(name="validate")],
        )
        data = plan.to_dict()
        assert data["plan_id"] == "plan-1"
        assert data["operation_id"] == "op-1"
        assert data["environment"] == "production"
        assert data["targets"] == ["server-1"]
        assert len(data["stages"]) == 1
        assert data["stages"][0]["name"] == "validate"

    def test_from_dict(self) -> None:
        """OperationPlan should deserialize from dict."""
        data = {
            "plan_id": "plan-1",
            "operation_id": "op-1",
            "operation_type": "deploy",
            "environment": "staging",
            "actor": "test-user",
            "targets": ["target-1"],
            "state": "running",
            "stages": [
                {"name": "validate", "required": True},
                {"name": "deploy", "needs_approval": True},
            ],
            "stage_statuses": {
                "validate": {
                    "stage_name": "validate",
                    "state": "completed",
                },
            },
        }
        plan = OperationPlan.from_dict(data)
        assert plan.plan_id == "plan-1"
        assert plan.environment == "staging"
        assert plan.state == OperationState.RUNNING
        assert len(plan.stages) == 2
        assert plan.stages[0].name == "validate"
        assert plan.stages[1].needs_approval is True
        assert len(plan.stage_statuses) == 1

    def test_roundtrip(self) -> None:
        """OperationPlan should survive serialization roundtrip."""
        original = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="deploy",
            environment="production",
            actor="admin",
            targets=["s1", "s2"],
            metadata={"reason": "update"},
            protection_level="production",
            state=OperationState.RUNNING,
            stages=[
                StagePlan(name="validate"),
                StagePlan(name="deploy", needs_approval=True),
            ],
            stage_statuses={
                "validate": StageStatusRecord(
                    stage_name="validate",
                    state=StageState.COMPLETED.value,
                    result_data={"valid": True},
                ),
            },
            stage_results={"validate": {"valid": True}},
            audit_event_ids=["evt-1", "evt-2"],
        )

        restored = OperationPlan.from_dict(original.to_dict())
        assert restored.plan_id == original.plan_id
        assert restored.operation_type == original.operation_type
        assert restored.environment == original.environment
        assert restored.state == original.state
        assert len(restored.stages) == len(original.stages)
        assert len(restored.stage_statuses) == len(original.stage_statuses)
        assert restored.audit_event_ids == original.audit_event_ids

    def test_to_json(self) -> None:
        """OperationPlan should serialize to JSON."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="test",
        )
        json_str = plan.to_json()
        assert '"plan_id": "plan-1"' in json_str
        assert '"operation_id": "op-1"' in json_str

    def test_from_json(self) -> None:
        """OperationPlan should deserialize from JSON."""
        json_str = '{"plan_id": "plan-1", "operation_id": "op-1", "operation_type": "test"}'
        plan = OperationPlan.from_json(json_str)
        assert plan.plan_id == "plan-1"
        assert plan.operation_id == "op-1"

    def test_to_summary(self) -> None:
        """to_summary should return a concise view."""
        plan = OperationPlan(
            plan_id="plan-1",
            operation_id="op-1",
            operation_type="deploy",
            environment="production",
            targets=["server-1"],
            stages=[
                StagePlan(name="validate"),
                StagePlan(name="deploy"),
            ],
            stage_statuses={
                "validate": StageStatusRecord(
                    stage_name="validate",
                    state=StageState.COMPLETED.value,
                ),
                "deploy": StageStatusRecord(
                    stage_name="deploy",
                    state=StageState.PENDING.value,
                ),
            },
        )
        summary = plan.to_summary()
        assert summary["plan_id"] == "plan-1"
        assert summary["operation_type"] == "deploy"
        assert summary["next_stage"] == "deploy"
        assert "validate" in summary["completed_stages"]
