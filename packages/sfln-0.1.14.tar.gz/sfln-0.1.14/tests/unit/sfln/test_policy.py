"""Tests for policy, risk, and user context models."""

import pytest

from sfln import PolicyVerdict, RiskLevel, RiskScore, UserContext, Verdict


class TestVerdict:
    """Tests for Verdict enum."""

    def test_verdict_values(self) -> None:
        assert Verdict.ALLOW == "allow"
        assert Verdict.DENY == "deny"
        assert Verdict.REQUIRE_APPROVAL == "require_approval"


class TestPolicyVerdict:
    """Tests for PolicyVerdict model."""

    def test_create_minimal(self) -> None:
        verdict = PolicyVerdict(verdict=Verdict.ALLOW)
        assert verdict.verdict == Verdict.ALLOW
        assert verdict.policy_id is None
        assert verdict.reason_code is None
        assert verdict.message is None
        assert verdict.reasons == []

    def test_create_full(self) -> None:
        verdict = PolicyVerdict(
            verdict=Verdict.DENY,
            policy_id="prod-policy",
            reason_code="unauthorized",
            message="User not authorized",
            reasons=["User not in admin group", "Production environment"],
        )
        assert verdict.verdict == Verdict.DENY
        assert verdict.policy_id == "prod-policy"
        assert verdict.reason_code == "unauthorized"
        assert verdict.message == "User not authorized"
        assert len(verdict.reasons) == 2

    def test_require_approval_verdict(self) -> None:
        verdict = PolicyVerdict(
            verdict=Verdict.REQUIRE_APPROVAL,
            message="High risk operation",
            reasons=["Affects production", "Large dataset"],
        )
        assert verdict.verdict == Verdict.REQUIRE_APPROVAL
        assert len(verdict.reasons) == 2


class TestRiskLevel:
    """Tests for RiskLevel enum."""

    def test_risk_level_values(self) -> None:
        assert RiskLevel.LOW == "low"
        assert RiskLevel.MEDIUM == "medium"
        assert RiskLevel.HIGH == "high"
        assert RiskLevel.CRITICAL == "critical"


class TestRiskScore:
    """Tests for RiskScore model."""

    def test_create_minimal(self) -> None:
        risk = RiskScore(level=RiskLevel.LOW, score=10)
        assert risk.level == RiskLevel.LOW
        assert risk.score == 10
        assert risk.reasons == []

    def test_create_with_reasons(self) -> None:
        risk = RiskScore(
            level=RiskLevel.HIGH,
            score=85,
            reasons=["Production environment", "Large dataset", "No backup"],
        )
        assert risk.level == RiskLevel.HIGH
        assert risk.score == 85
        assert len(risk.reasons) == 3

    def test_score_validation_min(self) -> None:
        with pytest.raises(ValueError, match="Risk score must be 0-100"):
            RiskScore(level=RiskLevel.LOW, score=-1)

    def test_score_validation_max(self) -> None:
        with pytest.raises(ValueError, match="Risk score must be 0-100"):
            RiskScore(level=RiskLevel.CRITICAL, score=101)

    def test_score_validation_valid_range(self) -> None:
        # Should not raise
        RiskScore(level=RiskLevel.LOW, score=0)
        RiskScore(level=RiskLevel.CRITICAL, score=100)

    def test_from_score_low(self) -> None:
        risk = RiskScore.from_score(15)
        assert risk.level == RiskLevel.LOW
        assert risk.score == 15

    def test_from_score_medium(self) -> None:
        risk = RiskScore.from_score(40)
        assert risk.level == RiskLevel.MEDIUM
        assert risk.score == 40

    def test_from_score_high(self) -> None:
        risk = RiskScore.from_score(60)
        assert risk.level == RiskLevel.HIGH
        assert risk.score == 60

    def test_from_score_critical(self) -> None:
        risk = RiskScore.from_score(90)
        assert risk.level == RiskLevel.CRITICAL
        assert risk.score == 90

    def test_from_score_boundaries(self) -> None:
        # Test exact boundaries
        assert RiskScore.from_score(0).level == RiskLevel.LOW
        assert RiskScore.from_score(24).level == RiskLevel.LOW
        assert RiskScore.from_score(25).level == RiskLevel.MEDIUM
        assert RiskScore.from_score(49).level == RiskLevel.MEDIUM
        assert RiskScore.from_score(50).level == RiskLevel.HIGH
        assert RiskScore.from_score(74).level == RiskLevel.HIGH
        assert RiskScore.from_score(75).level == RiskLevel.CRITICAL
        assert RiskScore.from_score(100).level == RiskLevel.CRITICAL

    def test_from_score_with_reasons(self) -> None:
        risk = RiskScore.from_score(score=85, reasons=["Production env", "High impact"])
        assert risk.level == RiskLevel.CRITICAL
        assert risk.score == 85
        assert len(risk.reasons) == 2


class TestUserContext:
    """Tests for UserContext model."""

    def test_create_minimal(self) -> None:
        user = UserContext(id="alice@company.com")
        assert user.id == "alice@company.com"
        assert user.role is None
        assert user.groups == []

    def test_create_with_role(self) -> None:
        user = UserContext(id="bob@company.com", role="admin")
        assert user.id == "bob@company.com"
        assert user.role == "admin"
        assert user.groups == []

    def test_create_with_groups(self) -> None:
        user = UserContext(
            id="charlie@company.com",
            role="operator",
            groups=["ops-team", "database-admins"],
        )
        assert user.id == "charlie@company.com"
        assert user.role == "operator"
        assert len(user.groups) == 2
        assert "ops-team" in user.groups
        assert "database-admins" in user.groups

    def test_has_role_true(self) -> None:
        user = UserContext(id="admin@company.com", role="admin")
        assert user.has_role("admin")

    def test_has_role_false(self) -> None:
        user = UserContext(id="user@company.com", role="operator")
        assert not user.has_role("admin")

    def test_has_role_none(self) -> None:
        user = UserContext(id="user@company.com")
        assert not user.has_role("admin")

    def test_in_group_true(self) -> None:
        user = UserContext(id="user@company.com", groups=["ops-team", "dev-team"])
        assert user.in_group("ops-team")
        assert user.in_group("dev-team")

    def test_in_group_false(self) -> None:
        user = UserContext(id="user@company.com", groups=["ops-team"])
        assert not user.in_group("admin-team")

    def test_in_group_empty_groups(self) -> None:
        user = UserContext(id="user@company.com")
        assert not user.in_group("any-team")

    def test_in_any_group_true(self) -> None:
        user = UserContext(id="user@company.com", groups=["ops-team", "dev-team"])
        assert user.in_any_group(["ops-team", "admin-team"])
        assert user.in_any_group(["dev-team"])

    def test_in_any_group_false(self) -> None:
        user = UserContext(id="user@company.com", groups=["ops-team"])
        assert not user.in_any_group(["admin-team", "security-team"])

    def test_in_any_group_empty(self) -> None:
        user = UserContext(id="user@company.com")
        assert not user.in_any_group(["admin-team"])

    def test_in_all_groups_true(self) -> None:
        user = UserContext(id="user@company.com", groups=["ops-team", "dev-team", "admin-team"])
        assert user.in_all_groups(["ops-team", "dev-team"])
        assert user.in_all_groups(["ops-team"])

    def test_in_all_groups_false(self) -> None:
        user = UserContext(id="user@company.com", groups=["ops-team", "dev-team"])
        assert not user.in_all_groups(["ops-team", "admin-team"])

    def test_in_all_groups_empty(self) -> None:
        user = UserContext(id="user@company.com")
        assert not user.in_all_groups(["ops-team"])

    def test_service_account_user(self) -> None:
        user = UserContext(id="deploy-bot", role="service-account", groups=["automation"])
        assert user.id == "deploy-bot"
        assert user.role == "service-account"
        assert user.in_group("automation")
