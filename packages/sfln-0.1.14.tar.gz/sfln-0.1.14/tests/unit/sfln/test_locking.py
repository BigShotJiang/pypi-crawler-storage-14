"""Unit tests for Safeline locking components."""

from __future__ import annotations

import tempfile
import threading
import time
from pathlib import Path

import pytest

from sfln.exceptions import LockAcquisitionError, LockNotHeldError
from sfln.locking import (
    FileLockManager,
    LockConfig,
    LockInfo,
    MemoryLockManager,
)


class TestLockConfig:
    """Tests for LockConfig."""

    def test_default_config(self) -> None:
        config = LockConfig()
        assert config.timeout_seconds == 300
        assert config.exclusive is True
        assert config.ttl_seconds == 3600

    def test_custom_config(self) -> None:
        config = LockConfig(
            scope="deploy:{env}",
            timeout_seconds=60,
            ttl_seconds=600,
        )
        assert config.scope == "deploy:{env}"
        assert config.timeout_seconds == 60


class TestLockInfo:
    """Tests for LockInfo."""

    def test_lock_info_creation(self) -> None:
        info = LockInfo(lock_key="test-key", holder="user-1")
        assert info.lock_key == "test-key"
        assert info.holder == "user-1"
        assert info.acquired_at is not None

    def test_lock_info_serialization(self) -> None:
        info = LockInfo(
            lock_key="test-key",
            holder="user-1",
            metadata={"context": "test"},
        )

        data = info.to_dict()
        restored = LockInfo.from_dict(data)

        assert restored.lock_key == info.lock_key
        assert restored.holder == info.holder
        assert restored.metadata == info.metadata

    def test_is_expired_no_expiry(self) -> None:
        info = LockInfo(lock_key="test", holder="user")
        assert info.is_expired() is False

    def test_is_expired_future(self) -> None:
        from datetime import datetime, timedelta, timezone

        future = datetime.now(timezone.utc) + timedelta(hours=1)
        info = LockInfo(
            lock_key="test",
            holder="user",
            expires_at=future.isoformat(),
        )
        assert info.is_expired() is False

    def test_is_expired_past(self) -> None:
        from datetime import datetime, timedelta, timezone

        past = datetime.now(timezone.utc) - timedelta(hours=1)
        info = LockInfo(
            lock_key="test",
            holder="user",
            expires_at=past.isoformat(),
        )
        assert info.is_expired() is True


class TestMemoryLockManager:
    """Tests for MemoryLockManager."""

    def test_acquire_lock(self) -> None:
        manager = MemoryLockManager()
        info = manager.acquire("test-lock", holder="user-1")

        assert info.lock_key == "test-lock"
        assert info.holder == "user-1"
        assert manager.is_locked("test-lock")

    def test_release_lock(self) -> None:
        manager = MemoryLockManager()
        manager.acquire("test-lock", holder="user-1")
        manager.release("test-lock", holder="user-1")

        assert not manager.is_locked("test-lock")

    def test_release_wrong_holder(self) -> None:
        manager = MemoryLockManager()
        manager.acquire("test-lock", holder="user-1")

        with pytest.raises(LockNotHeldError):
            manager.release("test-lock", holder="user-2")

    def test_release_not_held(self) -> None:
        manager = MemoryLockManager()

        with pytest.raises(LockNotHeldError):
            manager.release("nonexistent")

    def test_acquire_already_held(self) -> None:
        manager = MemoryLockManager()
        manager.acquire("test-lock", holder="user-1")

        with pytest.raises(LockAcquisitionError):
            manager.acquire("test-lock", holder="user-2", timeout_seconds=0.1)

    def test_get_lock_info(self) -> None:
        manager = MemoryLockManager()
        manager.acquire("test-lock", holder="user-1")

        info = manager.get_lock_info("test-lock")
        assert info is not None
        assert info.holder == "user-1"

    def test_get_lock_info_not_found(self) -> None:
        manager = MemoryLockManager()
        info = manager.get_lock_info("nonexistent")
        assert info is None

    def test_force_release(self) -> None:
        manager = MemoryLockManager()
        manager.acquire("test-lock", holder="user-1")
        manager.force_release("test-lock")

        assert not manager.is_locked("test-lock")

    def test_concurrent_acquisition(self) -> None:
        manager = MemoryLockManager()
        results: list[bool] = []

        def try_acquire(holder: str) -> None:
            try:
                manager.acquire("shared-lock", holder=holder, timeout_seconds=0.5)
                results.append(True)
                time.sleep(0.2)
                manager.release("shared-lock", holder=holder)
            except LockAcquisitionError:
                results.append(False)

        t1 = threading.Thread(target=try_acquire, args=("user-1",))
        t2 = threading.Thread(target=try_acquire, args=("user-2",))

        t1.start()
        time.sleep(0.05)  # Ensure t1 acquires first
        t2.start()

        t1.join()
        t2.join()

        # At least one should succeed
        assert True in results


class TestFileLockManager:
    """Tests for FileLockManager."""

    def test_acquire_lock(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileLockManager(tmpdir)
            info = manager.acquire("test-lock", holder="user-1")

            assert info.lock_key == "test-lock"
            assert info.holder == "user-1"
            assert manager.is_locked("test-lock")

            manager.release("test-lock", holder="user-1")

    def test_release_lock(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileLockManager(tmpdir)
            manager.acquire("test-lock", holder="user-1")
            manager.release("test-lock", holder="user-1")

            assert not manager.is_locked("test-lock")

    def test_get_lock_info(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileLockManager(tmpdir)
            manager.acquire("test-lock", holder="user-1")

            info = manager.get_lock_info("test-lock")
            assert info is not None
            assert info.holder == "user-1"

            manager.release("test-lock", holder="user-1")

    def test_force_release(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileLockManager(tmpdir)
            manager.acquire("test-lock", holder="user-1")
            manager.force_release("test-lock")

            assert not manager.is_locked("test-lock")

    def test_lock_file_created(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileLockManager(tmpdir)
            manager.acquire("test-lock", holder="user-1")

            lock_file = Path(tmpdir) / "test-lock.lock"
            info_file = Path(tmpdir) / "test-lock.json"

            assert lock_file.exists()
            assert info_file.exists()

            manager.release("test-lock", holder="user-1")
