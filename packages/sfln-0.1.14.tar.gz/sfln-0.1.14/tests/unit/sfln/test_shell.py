"""Tests for the interactive shell."""

from sfln import Context, MemoryStore, Operation, Safeline, Stage, StageResult
from sfln.cli.shell import SafelineShell


class SimpleOperation(Operation):
    """Simple test operation with standard stages."""

    name = "simple"
    stages = [
        Stage("plan"),
        Stage("validate"),
        Stage("stage", reversible=True),
        Stage("apply", needs_approval=True, reversible=True),
        Stage("verify"),
        Stage("closeout"),
    ]

    def plan(self, context: Context) -> StageResult:
        return StageResult(data={"planned": True})

    def validate(self, context: Context) -> StageResult:
        return StageResult(data={"valid": True})

    def stage(self, context: Context) -> StageResult:
        return StageResult(data={"staged": True})

    def apply(self, context: Context) -> StageResult:
        return StageResult(data={"applied": True})

    def verify(self, context: Context) -> StageResult:
        return StageResult(data={"verified": True})

    def closeout(self, context: Context) -> StageResult:
        return StageResult(data={"closed_out": True})


class TestShellTabCompletion:
    """Test tab completion in the shell."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        self.sl = Safeline(store=MemoryStore())
        self.shell = SafelineShell(self.sl, operation_class=SimpleOperation)

    def test_shell_initializes_with_operation(self) -> None:
        """Shell should initialize with operation class."""
        assert self.shell._operations == {"simple": SimpleOperation}
        assert self.shell._current_op_type == "simple"

    def test_get_stage_names(self) -> None:
        """Should return stage names for current operation."""
        stages = self.shell._get_stage_names()
        assert stages == ["plan", "validate", "stage", "apply", "verify", "closeout"]

    def test_get_approval_stage_names(self) -> None:
        """Should return only stages that need approval."""
        stages = self.shell._get_approval_stage_names()
        assert stages == ["apply"]

    def test_get_operation_names(self) -> None:
        """Should return registered operation names."""
        names = self.shell._get_operation_names()
        assert names == ["simple"]

    def test_complete_from_list_empty_text(self) -> None:
        """Should return all options when text is empty."""
        options = ["a", "b", "c"]
        result = self.shell._complete_from_list("", options)
        assert result == options

    def test_complete_from_list_with_prefix(self) -> None:
        """Should return matching options."""
        options = ["plan", "validate", "verify"]
        result = self.shell._complete_from_list("v", options)
        assert result == ["validate", "verify"]

    def test_complete_stage_returns_stages(self) -> None:
        """Tab completion for stage should return stage names."""
        # Simulate: stage <TAB>
        result = self.shell.complete_stage("", "stage ", 6, 6)
        assert result == ["plan", "validate", "stage", "apply", "verify", "closeout"]

    def test_complete_stage_with_prefix(self) -> None:
        """Tab completion for stage with prefix."""
        # Simulate: stage p<TAB>
        result = self.shell.complete_stage("p", "stage p", 6, 7)
        assert result == ["plan"]

    def test_complete_stage_with_v_prefix(self) -> None:
        """Tab completion for stage with 'v' prefix."""
        # Simulate: stage v<TAB>
        result = self.shell.complete_stage("v", "stage v", 6, 7)
        assert result == ["validate", "verify"]

    def test_complete_approve_returns_approval_stages(self) -> None:
        """Tab completion for approve should return stages needing approval."""
        # Simulate: approve <TAB>
        result = self.shell.complete_approve("", "approve ", 8, 8)
        assert result == ["apply"]

    def test_complete_create_returns_operations(self) -> None:
        """Tab completion for create should return operation names."""
        # Simulate: create <TAB>
        result = self.shell.complete_create("", "create ", 7, 7)
        assert result == ["simple"]

    def test_complete_run_returns_operations(self) -> None:
        """Tab completion for run should return operation names."""
        # Simulate: run <TAB>
        result = self.shell.complete_run("", "run ", 4, 4)
        assert result == ["simple"]

    def test_complete_json_returns_on_off(self) -> None:
        """Tab completion for json should return on/off."""
        result = self.shell.complete_json("", "json ", 5, 5)
        assert result == ["on", "off"]

    def test_complete_list_returns_states(self) -> None:
        """Tab completion for list should return operation states."""
        result = self.shell.complete_list("", "list ", 5, 5)
        assert "created" in result
        assert "completed" in result
        assert "failed" in result


class TestShellCommands:
    """Test shell commands."""

    def setup_method(self) -> None:
        """Set up test fixtures."""
        self.sl = Safeline(store=MemoryStore())
        self.shell = SafelineShell(self.sl, operation_class=SimpleOperation)

    def test_create_with_target(self) -> None:
        """Create command should work with just target."""
        self.shell.do_create("my-target")
        assert self.shell._current_op_id is not None
        assert self.shell._current_op_type == "simple"

    def test_create_with_operation_and_target(self) -> None:
        """Create command should work with operation name and target."""
        self.shell.do_create("simple my-target")
        assert self.shell._current_op_id is not None
        assert self.shell._current_op_type == "simple"

    def test_create_with_multiple_targets(self) -> None:
        """Create command should work with multiple targets."""
        self.shell.do_create("target1 target2 target3")
        assert self.shell._current_op_id is not None
        # Verify targets were passed
        status = self.sl.get_status(self.shell._current_op_id)
        assert "target1" in str(status.get("targets", []))

    def test_run_with_target(self) -> None:
        """Run command should work with just target."""
        # Note: This will pause at approval stage
        self.shell.do_run("my-target")
        assert self.shell._current_op_id is not None

    def test_stage_command_runs_stage(self) -> None:
        """Stage command should run a specific stage."""
        self.shell.do_create("my-target")
        op_id = self.shell._current_op_id

        self.shell.do_stage("plan")

        status = self.sl.get_status(op_id)
        stages = status.get("stages", {})
        assert stages.get("plan", {}).get("state") == "completed"

    def test_stage_command_runs_multiple_stages(self) -> None:
        """Should be able to run stages in sequence."""
        self.shell.do_create("my-target")
        op_id = self.shell._current_op_id

        self.shell.do_stage("plan")
        self.shell.do_stage("validate")
        self.shell.do_stage("stage")

        status = self.sl.get_status(op_id)
        stages = status.get("stages", {})
        assert stages.get("plan", {}).get("state") == "completed"
        assert stages.get("validate", {}).get("state") == "completed"
        assert stages.get("stage", {}).get("state") == "completed"

    def test_direct_stage_name_runs_stage(self) -> None:
        """Typing stage name directly should run that stage."""
        self.shell.do_create("my-target")
        op_id = self.shell._current_op_id

        # Use default() which handles unknown commands including stage names
        self.shell.default("plan")
        self.shell.default("validate")

        status = self.sl.get_status(op_id)
        stages = status.get("stages", {})
        assert stages.get("plan", {}).get("state") == "completed"
        assert stages.get("validate", {}).get("state") == "completed"

    def test_completenames_includes_stage_names(self) -> None:
        """Tab completion should include stage names as commands."""
        completions = self.shell.completenames("")
        # Should include stage names
        assert "plan" in completions
        assert "validate" in completions
        assert "apply" in completions


class TestShellMultiOperation:
    """Test shell with multiple operations."""

    def setup_method(self) -> None:
        """Set up test fixtures."""

        class AnotherOperation(Operation):
            name = "another"
            stages = [Stage("run")]

            def run(self, context: Context) -> StageResult:
                return StageResult(data={"ran": True})

        self.sl = Safeline(store=MemoryStore())
        self.shell = SafelineShell(
            self.sl,
            operations={"simple": SimpleOperation, "another": AnotherOperation},
        )

    def test_get_operation_names_multiple(self) -> None:
        """Should return all operation names."""
        names = self.shell._get_operation_names()
        assert "simple" in names
        assert "another" in names

    def test_complete_create_multiple_operations(self) -> None:
        """Tab completion should show all operations."""
        result = self.shell.complete_create("", "create ", 7, 7)
        assert "simple" in result
        assert "another" in result

    def test_create_requires_operation_name_with_multiple(self) -> None:
        """Create with multiple ops and no default errors without operation name."""
        # With multiple ops and no default, it should error
        self.shell.do_create("my-target")
        # Should NOT have created since no operation specified
        assert self.shell._current_op_id is None

    def test_create_with_operation_name_works(self) -> None:
        """Create with explicit operation name works."""
        self.shell.do_create("simple my-target")
        assert self.shell._current_op_id is not None
        assert self.shell._current_op_type == "simple"


class TestShellWelcomeMessage:
    """Test shell welcome message."""

    def test_welcome_includes_environment(self) -> None:
        """Welcome message should include environment."""
        sl = Safeline(store=MemoryStore(), environment="production")
        shell = SafelineShell(sl, operation_class=SimpleOperation)
        assert "Environment:" in shell.intro

    def test_welcome_includes_operations(self) -> None:
        """Welcome message should list operations."""
        sl = Safeline(store=MemoryStore())
        shell = SafelineShell(sl, operation_class=SimpleOperation)
        assert "simple" in shell.intro
        assert "6 stages" in shell.intro

    def test_welcome_includes_next_steps(self) -> None:
        """Welcome message should include next steps."""
        sl = Safeline(store=MemoryStore())
        shell = SafelineShell(sl, operation_class=SimpleOperation)
        assert "Next steps:" in shell.intro
        assert "create" in shell.intro
