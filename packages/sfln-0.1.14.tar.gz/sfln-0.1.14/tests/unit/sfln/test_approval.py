"""Unit tests for Safeline approval components."""

from __future__ import annotations

import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from sfln.approval import (
    ApprovalConfig,
    ApprovalError,
    ApprovalExpiredError,
    ApprovalRequest,
    FileApprovalManager,
    MemoryApprovalManager,
)


class TestApprovalConfig:
    """Tests for ApprovalConfig."""

    def test_default_config(self) -> None:
        config = ApprovalConfig()
        assert config.required_approvers == 1
        assert config.approval_timeout_hours == 24
        assert config.auto_approve_dry_run is True

    def test_is_approver_allowed_empty(self) -> None:
        config = ApprovalConfig()
        assert config.is_approver_allowed("anyone") is True

    def test_is_approver_allowed_list(self) -> None:
        config = ApprovalConfig(allowed_approvers=["admin", "ops-team"])
        assert config.is_approver_allowed("admin") is True
        assert config.is_approver_allowed("random-user") is False

    def test_serialization(self) -> None:
        config = ApprovalConfig(
            required_approvers=2,
            allowed_approvers=["admin"],
        )

        data = config.to_dict()
        restored = ApprovalConfig.from_dict(data)

        assert restored.required_approvers == config.required_approvers
        assert restored.allowed_approvers == config.allowed_approvers


class TestApprovalRequest:
    """Tests for ApprovalRequest."""

    def test_request_creation(self) -> None:
        request = ApprovalRequest(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
        )

        assert request.operation_id == "op-123"
        assert request.stage_name == "deploy"
        assert request.status == "pending"

    def test_approval_count(self) -> None:
        request = ApprovalRequest(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            approvals=[
                {"approver": "admin1", "approved_at": "2024-01-01T00:00:00Z"},
                {"approver": "admin2", "approved_at": "2024-01-01T00:01:00Z"},
            ],
        )

        assert request.approval_count() == 2

    def test_is_expired_no_expiry(self) -> None:
        request = ApprovalRequest(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
        )
        assert request.is_expired() is False

    def test_is_expired_future(self) -> None:
        future = datetime.now(timezone.utc) + timedelta(hours=1)
        request = ApprovalRequest(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            expires_at=future.isoformat(),
        )
        assert request.is_expired() is False

    def test_is_expired_past(self) -> None:
        past = datetime.now(timezone.utc) - timedelta(hours=1)
        request = ApprovalRequest(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            expires_at=past.isoformat(),
        )
        assert request.is_expired() is True

    def test_serialization(self) -> None:
        request = ApprovalRequest(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
        )

        data = request.to_dict()
        restored = ApprovalRequest.from_dict(data)

        assert restored.operation_id == request.operation_id
        assert restored.stage_name == request.stage_name


class TestMemoryApprovalManager:
    """Tests for MemoryApprovalManager."""

    def test_request_approval(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        request = manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        assert request.operation_id == "op-123"
        assert request.status == "pending"

    def test_approve(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        request = manager.approve(
            operation_id="op-123",
            stage_name="deploy",
            approver="admin",
            comment="Looks good",
        )

        assert len(request.approvals) == 1
        assert request.approvals[0]["approver"] == "admin"

    def test_deny(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        request = manager.deny(
            operation_id="op-123",
            stage_name="deploy",
            denier="admin",
            reason="Not ready",
        )

        assert request.status == "denied"
        assert len(request.denials) == 1

    def test_is_approved_single(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig(required_approvers=1)

        manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        assert manager.is_approved("op-123", "deploy", config) is False

        manager.approve("op-123", "deploy", approver="admin")
        assert manager.is_approved("op-123", "deploy", config) is True

    def test_is_approved_multiple(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig(required_approvers=2)

        manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        manager.approve("op-123", "deploy", approver="admin1")
        assert manager.is_approved("op-123", "deploy", config) is False

        manager.approve("op-123", "deploy", approver="admin2")
        assert manager.is_approved("op-123", "deploy", config) is True

    def test_is_approved_denied(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        manager.deny("op-123", "deploy", denier="admin")
        assert manager.is_approved("op-123", "deploy", config) is False

    def test_get_request(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval(
            operation_id="op-123",
            stage_name="deploy",
            actor="user",
            config=config,
        )

        request = manager.get_request("op-123", "deploy")
        assert request is not None
        assert request.operation_id == "op-123"

    def test_get_request_not_found(self) -> None:
        manager = MemoryApprovalManager()
        request = manager.get_request("nonexistent", "stage")
        assert request is None

    def test_list_pending(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval("op-1", "deploy", "user", config)
        manager.request_approval("op-2", "deploy", "user", config)
        manager.request_approval("op-3", "deploy", "user", config)
        manager.approve("op-1", "deploy", "admin")

        pending = manager.list_pending()
        # op-1 is approved but not denied, so it's still pending status
        # Actually, approve doesn't change status to approved automatically
        assert len(pending) >= 2

    def test_approve_nonexistent(self) -> None:
        manager = MemoryApprovalManager()

        with pytest.raises(ApprovalError):
            manager.approve("nonexistent", "deploy", "admin")

    def test_approve_already_denied(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval("op-123", "deploy", "user", config)
        manager.deny("op-123", "deploy", "admin")

        with pytest.raises(ApprovalError, match="already denied"):
            manager.approve("op-123", "deploy", "admin2")


class TestFileApprovalManager:
    """Tests for FileApprovalManager."""

    def test_request_approval(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            request = manager.request_approval(
                operation_id="op-123",
                stage_name="deploy",
                actor="user",
                config=config,
            )

            assert request.operation_id == "op-123"

            # Check file created
            files = list(Path(tmpdir).glob("*.json"))
            assert len(files) == 1

    def test_approve(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-123", "deploy", "user", config)
            request = manager.approve("op-123", "deploy", "admin")

            assert len(request.approvals) == 1

    def test_persistence(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager1 = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager1.request_approval("op-123", "deploy", "user", config)
            manager1.approve("op-123", "deploy", "admin")

            # Create new manager instance
            manager2 = FileApprovalManager(tmpdir)
            request = manager2.get_request("op-123", "deploy")

            assert request is not None
            assert len(request.approvals) == 1

    def test_deny(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-123", "deploy", "user", config)
            request = manager.deny("op-123", "deploy", "admin", "Not ready")

            assert request.status == "denied"
            assert len(request.denials) == 1

    def test_deny_nonexistent(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)

            with pytest.raises(ApprovalError):
                manager.deny("nonexistent", "deploy", "admin", "reason")

    def test_deny_expired(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-123", "deploy", "user", config)

            # Manually expire the request
            import json
            from datetime import datetime, timedelta, timezone

            path = Path(tmpdir) / "op-123_deploy.json"
            data = json.loads(path.read_text())
            data["expires_at"] = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
            path.write_text(json.dumps(data))

            with pytest.raises(ApprovalExpiredError):
                manager.deny("op-123", "deploy", "admin", "reason")

    def test_is_approved_not_enough(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig(required_approvers=2)

            manager.request_approval("op-123", "deploy", "user", config)
            manager.approve("op-123", "deploy", "admin1")

            assert manager.is_approved("op-123", "deploy", config) is False

    def test_is_approved_denied(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-123", "deploy", "user", config)
            manager.deny("op-123", "deploy", "admin", "no")

            assert manager.is_approved("op-123", "deploy", config) is False

    def test_is_approved_expired(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-123", "deploy", "user", config)
            manager.approve("op-123", "deploy", "admin")

            # Manually expire the request
            import json
            from datetime import datetime, timedelta, timezone

            path = Path(tmpdir) / "op-123_deploy.json"
            data = json.loads(path.read_text())
            data["expires_at"] = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
            path.write_text(json.dumps(data))

            assert manager.is_approved("op-123", "deploy", config) is False

    def test_list_pending(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-1", "deploy", "user", config)
            manager.request_approval("op-2", "deploy", "user", config)
            manager.deny("op-2", "deploy", "admin", "no")

            pending = manager.list_pending()
            assert len(pending) == 1

    def test_list_pending_skips_invalid(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            manager.request_approval("op-1", "deploy", "user", config)

            # Create invalid JSON file
            (Path(tmpdir) / "invalid.json").write_text("not json")

            pending = manager.list_pending()
            assert len(pending) == 1

    def test_path_sanitization(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            manager = FileApprovalManager(tmpdir)
            config = ApprovalConfig()

            # Operation ID and stage name with slashes
            manager.request_approval("op/001", "deploy/stage", "user", config)

            # Should sanitize path
            files = list(Path(tmpdir).glob("*.json"))
            assert len(files) == 1
            assert "/" not in files[0].name


class TestMemoryApprovalManagerEdgeCases:
    """Additional edge case tests for MemoryApprovalManager."""

    def test_deny_nonexistent(self) -> None:
        manager = MemoryApprovalManager()

        with pytest.raises(ApprovalError):
            manager.deny("nonexistent", "deploy", "admin", "reason")

    def test_deny_expired(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        request = manager.request_approval("op-123", "deploy", "user", config)
        # Manually expire
        request.expires_at = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()

        with pytest.raises(ApprovalExpiredError):
            manager.deny("op-123", "deploy", "admin", "reason")

    def test_is_approved_nonexistent(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        assert manager.is_approved("nonexistent", "deploy", config) is False

    def test_is_approved_expired(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        request = manager.request_approval("op-123", "deploy", "user", config)
        manager.approve("op-123", "deploy", "admin")
        # Manually expire
        request.expires_at = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()

        assert manager.is_approved("op-123", "deploy", config) is False

    def test_list_pending_skips_expired(self) -> None:
        manager = MemoryApprovalManager()
        config = ApprovalConfig()

        manager.request_approval("op-1", "deploy", "user", config)
        request = manager.request_approval("op-2", "deploy", "user", config)
        # Manually expire op-2
        request.expires_at = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()

        pending = manager.list_pending()
        assert len(pending) == 1
