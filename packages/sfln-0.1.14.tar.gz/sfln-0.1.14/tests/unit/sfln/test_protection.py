"""Unit tests for Safeline protection components."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

from sfln.protection import (
    PROTECTION_LEVELS,
    Environment,
    EnvironmentDetector,
    ProtectionLevel,
    ProtectionRegistry,
    detect_environment,
    get_protection_level,
)


class TestEnvironment:
    """Tests for Environment class."""

    def test_environment_creation(self) -> None:
        env = Environment(
            name="production",
            signature="abc123",
            source="file:/etc/env",
        )

        assert env.name == "production"
        assert env.signature == "abc123"
        assert env.source == "file:/etc/env"

    def test_serialization(self) -> None:
        env = Environment(
            name="staging",
            metadata={"region": "us-west"},
        )

        data = env.to_dict()
        restored = Environment.from_dict(data)

        assert restored.name == env.name
        assert restored.metadata == env.metadata


class TestEnvironmentDetector:
    """Tests for EnvironmentDetector."""

    def test_detect_from_env_var(self) -> None:
        os.environ["TEST_SAFELINE_ENV"] = "production"
        try:
            detector = EnvironmentDetector(env_var="TEST_SAFELINE_ENV")
            env = detector.detect()

            assert env.name == "production"
            assert "env:" in env.source
        finally:
            del os.environ["TEST_SAFELINE_ENV"]

    def test_detect_from_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / "environment"
            env_file.write_text("staging\n")

            detector = EnvironmentDetector(
                env_var="NONEXISTENT_VAR",
                env_file=env_file,
            )
            env = detector.detect()

            assert env.name == "staging"
            assert "file:" in env.source

    def test_detect_from_file_key_value(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / "environment"
            env_file.write_text("NAME=production\nSIGNATURE=abc123\n")

            detector = EnvironmentDetector(
                env_var="NONEXISTENT_VAR",
                env_file=env_file,
            )
            env = detector.detect()

            assert env.name == "production"
            assert env.signature == "abc123"

    def test_detect_default(self) -> None:
        detector = EnvironmentDetector(
            env_var="NONEXISTENT_VAR",
            env_file="/nonexistent/file",
            default="development",
        )
        env = detector.detect()

        assert env.name == "development"
        assert env.source == "default"


class TestProtectionLevel:
    """Tests for ProtectionLevel class."""

    def test_level_creation(self) -> None:
        level = ProtectionLevel(
            name="critical",
            description="Critical systems",
            require_approval=True,
            require_audit=True,
            require_backup=True,
        )

        assert level.name == "critical"
        assert level.require_approval is True
        assert level.require_audit is True

    def test_validate_operation_success(self) -> None:
        level = ProtectionLevel(
            name="standard",
            max_targets=100,
            allow_force=True,
        )

        valid, error = level.validate_operation(target_count=50, is_force=True)
        assert valid is True
        assert error is None

    def test_validate_operation_exceeds_targets(self) -> None:
        level = ProtectionLevel(
            name="limited",
            max_targets=10,
        )

        valid, error = level.validate_operation(target_count=50)
        assert valid is False
        assert "exceeds limit" in error

    def test_validate_operation_force_not_allowed(self) -> None:
        level = ProtectionLevel(
            name="strict",
            allow_force=False,
        )

        valid, error = level.validate_operation(target_count=1, is_force=True)
        assert valid is False
        assert "Force mode not allowed" in error

    def test_validate_operation_simulation_only(self) -> None:
        level = ProtectionLevel(
            name="readonly",
            simulation_only=True,
        )

        valid, error = level.validate_operation(target_count=1)
        assert valid is False
        assert "simulation mode" in error

    def test_serialization(self) -> None:
        level = ProtectionLevel(
            name="test",
            require_approval=True,
            custom_rules={"key": "value"},
        )

        data = level.to_dict()
        restored = ProtectionLevel.from_dict(data)

        assert restored.name == level.name
        assert restored.require_approval == level.require_approval
        assert restored.custom_rules == level.custom_rules


class TestBuiltinLevels:
    """Tests for built-in protection levels."""

    def test_critical_level(self) -> None:
        level = PROTECTION_LEVELS["critical"]
        assert level.require_approval is True
        assert level.allow_force is False
        assert level.max_targets == 10

    def test_production_level(self) -> None:
        level = PROTECTION_LEVELS["production"]
        assert level.require_approval is True
        assert level.require_backup is True

    def test_development_level(self) -> None:
        level = PROTECTION_LEVELS["development"]
        assert level.require_approval is False
        assert level.require_audit is False

    def test_testing_level(self) -> None:
        level = PROTECTION_LEVELS["testing"]
        assert level.require_approval is False
        assert level.retention_days == 1


class TestProtectionRegistry:
    """Tests for ProtectionRegistry."""

    def test_get_builtin_level(self) -> None:
        registry = ProtectionRegistry()
        level = registry.get("production")

        assert level is not None
        assert level.name == "production"

    def test_get_nonexistent_level(self) -> None:
        registry = ProtectionRegistry()
        level = registry.get("nonexistent")
        assert level is None

    def test_get_for_environment_matching(self) -> None:
        registry = ProtectionRegistry()
        level = registry.get_for_environment("production")

        assert level.name == "production"

    def test_get_for_environment_pattern_matching(self) -> None:
        registry = ProtectionRegistry()

        # Test production pattern
        level = registry.get_for_environment("prod-us-west")
        assert level.name == "production"

        # Test staging pattern
        level = registry.get_for_environment("staging-1")
        assert level.name == "staging"

        # Test test pattern
        level = registry.get_for_environment("testing-local")
        assert level.name == "testing"

    def test_get_for_environment_unknown(self) -> None:
        registry = ProtectionRegistry()
        level = registry.get_for_environment("random-env")

        # Should fallback to development
        assert level.name == "development"

    def test_register_custom_level(self) -> None:
        registry = ProtectionRegistry()
        custom = ProtectionLevel(
            name="custom",
            require_approval=True,
        )
        registry.register(custom)

        level = registry.get("custom")
        assert level is not None
        assert level.require_approval is True

    def test_map_environment(self) -> None:
        registry = ProtectionRegistry()
        registry.map_environment("my-special-env", "critical")

        level = registry.get_for_environment("my-special-env")
        assert level.name == "critical"

    def test_list_levels(self) -> None:
        registry = ProtectionRegistry()
        levels = registry.list_levels()

        assert "production" in levels
        assert "development" in levels
        assert "critical" in levels

    def test_all_levels(self) -> None:
        registry = ProtectionRegistry()
        all_levels = registry.all_levels()

        assert isinstance(all_levels, dict)
        assert "production" in all_levels
        assert all_levels["production"].name == "production"


class TestGlobalFunctions:
    """Tests for module-level helper functions."""

    def test_get_protection_level(self) -> None:
        level = get_protection_level("production")
        assert level.name == "production"

    def test_detect_environment(self) -> None:
        env = detect_environment()
        assert env is not None
        assert env.name is not None


class TestProtectionRegistryCustomLevels:
    """Tests for loading custom protection levels from YAML."""

    def test_load_single_level_yaml(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            yaml_content = """
name: custom-level
description: Custom test level
require_approval: true
require_backup: false
max_targets: 50
"""
            (config_dir / "custom.yaml").write_text(yaml_content)

            registry = ProtectionRegistry(config_dir=config_dir)
            level = registry.get("custom-level")

            assert level is not None
            assert level.name == "custom-level"
            assert level.require_approval is True
            assert level.max_targets == 50

    def test_load_multiple_levels_yaml(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            yaml_content = """
protection_levels:
  - name: level-a
    require_approval: true
  - name: level-b
    require_approval: false
"""
            (config_dir / "multi.yaml").write_text(yaml_content)

            registry = ProtectionRegistry(config_dir=config_dir)

            level_a = registry.get("level-a")
            level_b = registry.get("level-b")

            assert level_a is not None
            assert level_a.require_approval is True
            assert level_b is not None
            assert level_b.require_approval is False

    def test_load_yml_extension(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            yaml_content = """
name: yml-level
require_audit: true
"""
            (config_dir / "level.yml").write_text(yaml_content)

            registry = ProtectionRegistry(config_dir=config_dir)
            level = registry.get("yml-level")

            assert level is not None
            assert level.require_audit is True

    def test_load_yml_multiple_levels(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            yaml_content = """
protection_levels:
  - name: yml-a
    allow_force: true
  - name: yml-b
    allow_force: false
"""
            (config_dir / "levels.yml").write_text(yaml_content)

            registry = ProtectionRegistry(config_dir=config_dir)

            level_a = registry.get("yml-a")
            level_b = registry.get("yml-b")

            assert level_a is not None
            assert level_b is not None

    def test_skip_invalid_yaml_files(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            # Invalid YAML
            (config_dir / "invalid.yaml").write_text("not: valid: yaml: [")
            # Valid YAML
            (config_dir / "valid.yaml").write_text("name: valid-level\n")

            registry = ProtectionRegistry(config_dir=config_dir)
            level = registry.get("valid-level")

            assert level is not None

    def test_skip_yaml_without_name(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            # YAML without name field
            yaml_content = """
require_approval: true
max_targets: 10
"""
            (config_dir / "noname.yaml").write_text(yaml_content)

            # Should not raise, just skip
            registry = ProtectionRegistry(config_dir=config_dir)
            assert registry is not None

    def test_nonexistent_config_dir(self) -> None:
        registry = ProtectionRegistry(config_dir="/nonexistent/path")
        # Should still have built-in levels
        level = registry.get("production")
        assert level is not None

    def test_environment_mapping_in_constructor(self) -> None:
        registry = ProtectionRegistry(
            environment_mapping={
                "my-custom-env": "critical",
                "another-env": "development",
            }
        )

        level = registry.get_for_environment("my-custom-env")
        assert level.name == "critical"

        level = registry.get_for_environment("another-env")
        assert level.name == "development"


class TestProtectionRegistryGetForEnvironment:
    """Additional tests for get_for_environment."""

    def test_auto_detect_environment(self) -> None:
        registry = ProtectionRegistry()
        # Should not raise
        level = registry.get_for_environment(None)
        assert level is not None

    def test_environment_object(self) -> None:
        registry = ProtectionRegistry()
        env = Environment(name="production")
        level = registry.get_for_environment(env)
        assert level.name == "production"

    def test_critical_pattern(self) -> None:
        registry = ProtectionRegistry()
        level = registry.get_for_environment("critical-system")
        assert level.name == "production"

    def test_stage_pattern(self) -> None:
        registry = ProtectionRegistry()
        level = registry.get_for_environment("stage-us-west")
        assert level.name == "staging"

    def test_fallback_when_mapping_invalid(self) -> None:
        registry = ProtectionRegistry(environment_mapping={"my-env": "nonexistent-level"})
        # Should fallback since mapped level doesn't exist
        level = registry.get_for_environment("my-env")
        # Falls back to development
        assert level.name == "development"


class TestProtectionLevelValidation:
    """Additional tests for ProtectionLevel validation."""

    def test_validate_unlimited_targets(self) -> None:
        """max_targets=0 means unlimited."""
        level = ProtectionLevel(
            name="unlimited",
            max_targets=0,
        )

        valid, error = level.validate_operation(target_count=10000)
        assert valid is True

    def test_validate_at_limit(self) -> None:
        """Exactly at max_targets should pass."""
        level = ProtectionLevel(
            name="limited",
            max_targets=100,
        )

        valid, error = level.validate_operation(target_count=100)
        assert valid is True

    def test_validate_over_limit(self) -> None:
        """Over max_targets should fail."""
        level = ProtectionLevel(
            name="limited",
            max_targets=100,
        )

        valid, error = level.validate_operation(target_count=101)
        assert valid is False
        assert "exceeds limit" in error


class TestEnvironmentDetectorEdgeCases:
    """Additional edge case tests for EnvironmentDetector."""

    def test_detect_from_empty_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / "environment"
            env_file.write_text("")

            detector = EnvironmentDetector(
                env_var="NONEXISTENT_VAR",
                env_file=env_file,
                default="fallback",
            )
            env = detector.detect()

            assert env.name == "fallback"

    def test_detect_file_with_whitespace(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / "environment"
            env_file.write_text("  production  \n")

            detector = EnvironmentDetector(
                env_var="NONEXISTENT_VAR",
                env_file=env_file,
            )
            env = detector.detect()

            assert env.name == "production"

    def test_detect_file_with_metadata(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            env_file = Path(tmpdir) / "environment"
            env_file.write_text("NAME=production\nSIGNATURE=sig123\nREGION=us-west\n")

            detector = EnvironmentDetector(
                env_var="NONEXISTENT_VAR",
                env_file=env_file,
            )
            env = detector.detect()

            assert env.name == "production"
            assert env.signature == "sig123"
            # Keys are lowercased in metadata
            assert env.metadata.get("region") == "us-west"
