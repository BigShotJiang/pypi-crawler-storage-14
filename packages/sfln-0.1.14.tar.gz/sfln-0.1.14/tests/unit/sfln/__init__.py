"""Unit tests for the Safeline framework."""
