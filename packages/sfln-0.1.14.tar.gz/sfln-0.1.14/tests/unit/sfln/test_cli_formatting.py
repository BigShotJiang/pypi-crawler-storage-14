"""Tests for CLI formatting utilities."""

from io import StringIO
from unittest.mock import patch

from sfln.cli.formatting import format_bytes, format_template, print_structured_output


class TestFormatBytes:
    """Tests for format_bytes function."""

    def test_zero_bytes(self) -> None:
        assert format_bytes(0) == "0 B"

    def test_bytes(self) -> None:
        assert format_bytes(1) == "1 B"
        assert format_bytes(100) == "100 B"
        assert format_bytes(1023) == "1023 B"

    def test_kilobytes(self) -> None:
        assert format_bytes(1024) == "1.0 KB"
        assert format_bytes(1536) == "1.5 KB"
        assert format_bytes(2048) == "2.0 KB"
        assert format_bytes(1024 * 10) == "10.0 KB"

    def test_megabytes(self) -> None:
        assert format_bytes(1024 * 1024) == "1.0 MB"
        assert format_bytes(1024 * 1024 * 1.5) == "1.5 MB"
        assert format_bytes(1024 * 1024 * 100) == "100.0 MB"

    def test_gigabytes(self) -> None:
        assert format_bytes(1024 * 1024 * 1024) == "1.0 GB"
        assert format_bytes(int(1024 * 1024 * 1024 * 2.5)) == "2.5 GB"

    def test_terabytes(self) -> None:
        assert format_bytes(1024 * 1024 * 1024 * 1024) == "1.0 TB"
        assert format_bytes(int(1024 * 1024 * 1024 * 1024 * 1.5)) == "1.5 TB"

    def test_petabytes(self) -> None:
        assert format_bytes(1024 * 1024 * 1024 * 1024 * 1024) == "1.0 PB"

    def test_exabytes(self) -> None:
        # Really huge number
        assert format_bytes(1024 * 1024 * 1024 * 1024 * 1024 * 1024) == "1.0 EB"

    def test_negative_bytes(self) -> None:
        assert format_bytes(-1024) == "-1.0 KB"
        assert format_bytes(-1024 * 1024) == "-1.0 MB"


class TestFormatTemplate:
    """Tests for format_template function."""

    def test_format_simple(self) -> None:
        result = format_template("Hello {name}", {"name": "World"})
        assert result == "Hello World"

    def test_format_multiple_placeholders(self) -> None:
        result = format_template(
            "{greeting} {name}, you have {count} messages",
            {"greeting": "Hello", "name": "Alice", "count": 5},
        )
        assert result == "Hello Alice, you have 5 messages"

    def test_format_with_numbers(self) -> None:
        result = format_template("Count: {count}", {"count": 42})
        assert result == "Count: 42"

        result = format_template("Price: {price}", {"price": 19.99})
        assert result == "Price: 19.99"

    def test_format_with_boolean(self) -> None:
        result = format_template("Active: {active}", {"active": True})
        assert result == "Active: True"

    def test_format_missing_key(self) -> None:
        # Should return original template if key missing
        result = format_template("Hello {name}", {})
        assert result == "Hello {name}"

    def test_format_filters_complex_types(self) -> None:
        # Should filter out non-string/int/float/bool values
        result = format_template(
            "Hello {name}",
            {
                "name": "World",
                "complex": {"nested": "data"},
                "list_data": [1, 2, 3],
            },
        )
        assert result == "Hello World"

    def test_format_no_placeholders(self) -> None:
        result = format_template("No placeholders here", {"key": "value"})
        assert result == "No placeholders here"

    def test_format_empty_data(self) -> None:
        result = format_template("Template {with} {placeholders}", {})
        assert result == "Template {with} {placeholders}"


class TestPrintStructuredOutput:
    """Tests for print_structured_output function."""

    @patch("sys.stdout", new_callable=StringIO)
    def test_print_structured_output_no_click(self, mock_stdout: StringIO) -> None:
        """Test without Click (fallback mode)."""
        print_structured_output(
            verdict="SUCCESS",
            scenario="operation op-123",
            summary="test completed",
            what_happened="The test ran successfully",
            why_it_matters="Tests ensure quality",
            next_steps=["Deploy to production"],
        )

        output = mock_stdout.getvalue()

        assert "[SUCCESS]" in output
        assert "operation op-123" in output
        assert "test completed" in output
        assert "What happened:" in output
        assert "The test ran successfully" in output
        assert "Why it matters:" in output
        assert "Tests ensure quality" in output
        assert "Next steps:" in output
        assert "1. Deploy to production" in output

    @patch("sys.stdout", new_callable=StringIO)
    def test_print_structured_output_with_additional_info(self, mock_stdout: StringIO) -> None:
        print_structured_output(
            verdict="SUCCESS",
            scenario="operation op-123",
            summary="test completed",
            what_happened="The test ran successfully",
            why_it_matters="Tests ensure quality",
            next_steps=["Deploy"],
            additional_info={"Operation ID": "op-123", "Environment": "staging"},
        )

        output = mock_stdout.getvalue()

        assert "Details:" in output
        assert "Operation ID: op-123" in output
        assert "Environment: staging" in output

    @patch("sys.stdout", new_callable=StringIO)
    def test_print_structured_output_multiple_steps(self, mock_stdout: StringIO) -> None:
        print_structured_output(
            verdict="SUCCESS",
            scenario="deployment",
            summary="deployed",
            what_happened="Deployed to production",
            why_it_matters="Users have new features",
            next_steps=["Monitor metrics", "Run smoke tests", "Notify stakeholders"],
        )

        output = mock_stdout.getvalue()

        assert "1. Monitor metrics" in output
        assert "2. Run smoke tests" in output
        assert "3. Notify stakeholders" in output

    @patch("sys.stdout", new_callable=StringIO)
    def test_print_structured_output_no_next_steps(self, mock_stdout: StringIO) -> None:
        print_structured_output(
            verdict="SUCCESS",
            scenario="test",
            summary="done",
            what_happened="Test completed",
            why_it_matters="Quality assured",
            next_steps=[],
        )

        output = mock_stdout.getvalue()

        # Should not have "Next steps:" section
        assert "Next steps:" not in output

    @patch("sys.stdout", new_callable=StringIO)
    def test_print_structured_output_error_verdict(self, mock_stdout: StringIO) -> None:
        print_structured_output(
            verdict="ERROR",
            scenario="deployment",
            summary="failed",
            what_happened="Deployment failed",
            why_it_matters="Service is down",
            next_steps=["Rollback", "Investigate"],
        )

        output = mock_stdout.getvalue()

        assert "[ERROR]" in output
        assert "failed" in output

    @patch("sys.stdout", new_callable=StringIO)
    def test_print_structured_output_requires_approval(self, mock_stdout: StringIO) -> None:
        print_structured_output(
            verdict="REQUIRES_APPROVAL",
            scenario="production deployment",
            summary="needs approval",
            what_happened="Production changes require approval",
            why_it_matters="Safety gate for production",
            next_steps=["Get approval from team lead"],
        )

        output = mock_stdout.getvalue()

        assert "[REQUIRES_APPROVAL]" in output
        assert "needs approval" in output
