"""Integration tests for full Safeline workflows."""

from __future__ import annotations

from pathlib import Path

import pytest

from sfln import (
    Context,
    FileStore,
    MemoryEmitter,
    Operation,
    OperationState,
    Safeline,
    Stage,
    StageResult,
    StageState,
)
from sfln.locking.manager import FileLockManager


class DeployOperation(Operation):
    """Realistic deployment operation for testing."""

    name = "deploy"
    stages = [
        Stage("validate"),
        Stage("backup", reversible=True),
        Stage("deploy", needs_approval=True, needs_lock=True, reversible=True),
        Stage("verify"),
        Stage("notify", required=False),
    ]

    def validate(self, context: Context) -> StageResult:
        return StageResult(data={"valid": True, "target": context.targets[0]})

    def backup(self, context: Context) -> StageResult:
        return StageResult(
            data={"backup_id": "bak-001"},
            rollback_data={"backup_id": "bak-001"},
        )

    def deploy(self, context: Context) -> StageResult:
        if context.dry_run:
            return StageResult(data={"dry_run": True})
        return StageResult(
            data={"deployed": True, "version": "1.0.0"},
            rollback_data={"previous_version": "0.9.0"},
        )

    def verify(self, context: Context) -> StageResult:
        return StageResult(data={"healthy": True})

    def notify(self, context: Context) -> StageResult:
        return StageResult(data={"notified": True})

    def rollback_backup(self, context: Context) -> StageResult:
        return StageResult(data={"cleanup": True})

    def rollback_deploy(self, context: Context) -> StageResult:
        # Rollback doesn't need to access original data for this test
        return StageResult(data={"restored": True})


class TestFullWorkflow:
    """Test complete operation lifecycles."""

    def test_simple_operation_runs_all_stages(self, tmp_path: Path) -> None:
        """Operation with multiple stages runs to completion."""

        class SimpleOp(Operation):
            name = "simple"
            stages = [Stage("one"), Stage("two"), Stage("three")]

            def one(self, ctx: Context) -> StageResult:
                return StageResult(data={"one": True})

            def two(self, ctx: Context) -> StageResult:
                return StageResult(data={"two": True})

            def three(self, ctx: Context) -> StageResult:
                return StageResult(data={"three": True})

        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(SimpleOp(targets=["x"]))

        assert result.success
        assert result.state == OperationState.COMPLETED
        assert result.stages_completed == ["one", "two", "three"]

    def test_operation_with_optional_stage_failure(self, tmp_path: Path) -> None:
        """Optional stage failure doesn't fail operation."""

        class OptionalFailOp(Operation):
            name = "opt-fail"
            stages = [
                Stage("required_stage"),
                Stage("optional_stage", required=False),
                Stage("final_stage"),
            ]

            def required_stage(self, ctx: Context) -> StageResult:
                return StageResult(data={"ok": True})

            def optional_stage(self, ctx: Context) -> StageResult:
                return StageResult(success=False, error="Optional failed")

            def final_stage(self, ctx: Context) -> StageResult:
                return StageResult(data={"final": True})

        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(OptionalFailOp(targets=["x"]))

        assert result.success
        assert "optional_stage" in result.stages_failed
        assert "final_stage" in result.stages_completed

    def test_operation_with_required_stage_failure(self, tmp_path: Path) -> None:
        """Required stage failure fails operation."""

        class RequiredFailOp(Operation):
            name = "req-fail"
            stages = [
                Stage("first"),
                Stage("failing", required=True),
                Stage("never_reached"),
            ]

            def first(self, ctx: Context) -> StageResult:
                return StageResult(data={"ok": True})

            def failing(self, ctx: Context) -> StageResult:
                return StageResult(success=False, error="Required stage failed")

            def never_reached(self, ctx: Context) -> StageResult:
                return StageResult(data={"should_not_run": True})

        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(RequiredFailOp(targets=["x"]))

        assert not result.success
        assert result.state == OperationState.FAILED
        assert "failing" in result.stages_failed
        assert "never_reached" not in result.stages_completed

    def test_operation_with_timeout(self, tmp_path: Path) -> None:
        """Stage timeout is enforced."""

        class TimeoutOp(Operation):
            name = "timeout"
            stages = [Stage("slow", timeout_seconds=1)]

            def slow(self, ctx: Context) -> StageResult:
                import time

                time.sleep(5)
                return StageResult(data={"done": True})

        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(TimeoutOp(targets=["x"]))

        assert not result.success
        assert "slow" in result.stages_failed

    def test_operation_with_retry(self, tmp_path: Path) -> None:
        """Stage retry works on failure."""

        class RetryOp(Operation):
            name = "retry"
            stages = [Stage("flaky", retry_count=2)]
            attempts = 0

            def flaky(self, ctx: Context) -> StageResult:
                RetryOp.attempts += 1
                if RetryOp.attempts < 3:
                    return StageResult(success=False, error="Try again")
                return StageResult(data={"ok": True})

        RetryOp.attempts = 0
        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(RetryOp(targets=["x"]))

        assert result.success
        assert RetryOp.attempts == 3


class TestApprovalWorkflow:
    """Test approval gate workflows."""

    def test_approval_gate_blocks_execution(self, tmp_path: Path) -> None:
        """Stage with needs_approval blocks until approved."""
        store = FileStore(tmp_path / "ops")
        auditor = MemoryEmitter()
        sl = Safeline(store=store, auditor=auditor, actor="test", environment="test")

        op = DeployOperation(targets=["server-1"])
        op_id = sl.create(op)

        # Run stages up to approval gate
        sl.run_stage(op_id, "validate")
        sl.run_stage(op_id, "backup")

        # Deploy should raise approval required
        from sfln.exceptions import ApprovalRequiredError

        with pytest.raises(ApprovalRequiredError):
            sl.run_stage(op_id, "deploy")

        # Check status
        status = sl.get_status(op_id)
        assert status["stages"]["deploy"]["state"] == StageState.WAITING_APPROVAL.value

    def test_approve_then_run(self, tmp_path: Path) -> None:
        """Approved stage can be run."""
        from sfln.exceptions import ApprovalRequiredError

        store = FileStore(tmp_path / "ops")
        lock_mgr = FileLockManager(tmp_path / "locks")
        sl = Safeline(
            store=store,
            lock_manager=lock_mgr,
            actor="developer",
            environment="test",
        )

        op = DeployOperation(targets=["server-1"])
        op_id = sl.create(op)

        sl.run_stage(op_id, "validate")
        sl.run_stage(op_id, "backup")

        # Try to run deploy - triggers approval request
        with pytest.raises(ApprovalRequiredError):
            sl.run_stage(op_id, "deploy")

        # Approve
        sl.approve(op_id, "deploy", approver="manager")

        # Now can run
        result = sl.run_stage(op_id, "deploy")
        assert result.success

    def test_full_deployment_workflow(self, tmp_path: Path) -> None:
        """Complete deployment with approval."""
        from sfln.exceptions import ApprovalRequiredError

        store = FileStore(tmp_path / "ops")
        lock_mgr = FileLockManager(tmp_path / "locks")
        auditor = MemoryEmitter()

        sl = Safeline(
            store=store,
            lock_manager=lock_mgr,
            auditor=auditor,
            actor="ci-bot",
            environment="production",
        )

        op = DeployOperation(targets=["prod-server"])
        op_id = sl.create(op)

        # Run pre-approval stages
        sl.run_stage(op_id, "validate")
        sl.run_stage(op_id, "backup")

        # Try to run deploy - triggers approval request
        with pytest.raises(ApprovalRequiredError):
            sl.run_stage(op_id, "deploy")

        # Get approval
        sl.approve(op_id, "deploy", approver="ops-lead")

        # Run remaining stages
        sl.run_stage(op_id, "deploy")
        sl.run_stage(op_id, "verify")
        sl.run_stage(op_id, "notify")

        # Check final status
        status = sl.get_status(op_id)
        assert all(s["state"] == StageState.COMPLETED.value for s in status["stages"].values())


class TestRollbackWorkflow:
    """Test rollback functionality."""

    def test_rollback_reverses_completed_stages(self, tmp_path: Path) -> None:
        """Rollback runs rollback methods in reverse order."""
        from sfln.exceptions import ApprovalRequiredError

        store = FileStore(tmp_path / "ops")
        lock_mgr = FileLockManager(tmp_path / "locks")
        auditor = MemoryEmitter()

        sl = Safeline(
            store=store,
            lock_manager=lock_mgr,
            auditor=auditor,
            actor="test",
            environment="test",
        )

        op = DeployOperation(targets=["server"])
        op_id = sl.create(op)

        # Run through approval
        sl.run_stage(op_id, "validate")
        sl.run_stage(op_id, "backup")

        # Trigger approval request
        with pytest.raises(ApprovalRequiredError):
            sl.run_stage(op_id, "deploy")

        sl.approve(op_id, "deploy")
        sl.run_stage(op_id, "deploy")

        # Now rollback
        result = sl.rollback(op_id)
        assert result.state == OperationState.ROLLED_BACK

        # Check rollback events
        event_types = [e.event_type for e in auditor.events]
        assert "rollback_started" in event_types
        assert "rollback_completed" in event_types

    def test_rollback_skips_non_reversible(self, tmp_path: Path) -> None:
        """Non-reversible stages are skipped during rollback."""

        class MixedOp(Operation):
            name = "mixed"
            stages = [
                Stage("reversible", reversible=True),
                Stage("non_reversible", reversible=False),
            ]
            rollback_called = False

            def reversible(self, ctx: Context) -> StageResult:
                return StageResult(data={"done": True})

            def non_reversible(self, ctx: Context) -> StageResult:
                return StageResult(data={"done": True})

            def rollback_reversible(self, ctx: Context) -> StageResult:
                MixedOp.rollback_called = True
                return StageResult(data={"rolled_back": True})

        MixedOp.rollback_called = False
        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(MixedOp(targets=["x"]))
        assert result.success

        rollback_result = sl.rollback(result.operation_id)
        assert rollback_result.state == OperationState.ROLLED_BACK
        assert MixedOp.rollback_called


class TestResumeWorkflow:
    """Test resume from failure."""

    def test_resume_failed_operation(self, tmp_path: Path) -> None:
        """Failed operation can be resumed."""

        class ResumeOp(Operation):
            name = "resume"
            stages = [Stage("a"), Stage("b"), Stage("c")]
            fail_b = True

            def a(self, ctx: Context) -> StageResult:
                return StageResult(data={"a": True})

            def b(self, ctx: Context) -> StageResult:
                if ResumeOp.fail_b:
                    return StageResult(success=False, error="B failed")
                return StageResult(data={"b": True})

            def c(self, ctx: Context) -> StageResult:
                return StageResult(data={"c": True})

        ResumeOp.fail_b = True
        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(ResumeOp(targets=["x"]))
        assert not result.success

        # Fix and resume
        ResumeOp.fail_b = False
        resume_result = sl.resume(result.operation_id)

        assert resume_result.success
        assert resume_result.state == OperationState.COMPLETED

    def test_resume_skips_completed_stages(self, tmp_path: Path) -> None:
        """Completed stages not re-run on resume."""

        class TrackOp(Operation):
            name = "track"
            stages = [Stage("x"), Stage("y")]
            x_count = 0
            y_count = 0
            fail_y = True

            def x(self, ctx: Context) -> StageResult:
                TrackOp.x_count += 1
                return StageResult(data={"x": True})

            def y(self, ctx: Context) -> StageResult:
                TrackOp.y_count += 1
                if TrackOp.fail_y:
                    return StageResult(success=False, error="Y failed")
                return StageResult(data={"y": True})

        TrackOp.x_count = 0
        TrackOp.y_count = 0
        TrackOp.fail_y = True

        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        result = sl.run(TrackOp(targets=["x"]))
        assert TrackOp.x_count == 1
        assert TrackOp.y_count == 1

        TrackOp.fail_y = False
        sl.resume(result.operation_id)

        assert TrackOp.x_count == 1  # Not re-run
        assert TrackOp.y_count == 2  # Re-run


class TestDryRun:
    """Test dry-run mode."""

    def test_dry_run_flag_passed_to_context(self, tmp_path: Path) -> None:
        """Dry-run flag is available in context."""

        class DryRunOp(Operation):
            name = "dryrun"
            stages = [Stage("check")]
            saw_dry_run = None

            def check(self, ctx: Context) -> StageResult:
                DryRunOp.saw_dry_run = ctx.dry_run
                return StageResult(data={"dry_run": ctx.dry_run})

        store = FileStore(tmp_path / "ops")
        sl = Safeline(store=store, actor="test", environment="test")

        op = DryRunOp(targets=["x"])
        sl.run(op)
        assert DryRunOp.saw_dry_run is False

        DryRunOp.saw_dry_run = None
        op_id = sl.create(DryRunOp(targets=["y"]), dry_run=True)
        sl.run_stage(op_id, "check")
        assert DryRunOp.saw_dry_run is True
