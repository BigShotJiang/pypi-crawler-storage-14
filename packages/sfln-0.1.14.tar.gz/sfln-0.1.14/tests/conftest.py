"""
Pytest configuration for safeline tests.

Sets up test environment and fixtures.
"""

import os

import pytest


@pytest.fixture(scope="session", autouse=True)
def setup_test_environment(tmp_path_factory):
    """
    Set up test environment for all tests.

    Configures environment variables to use temporary directories
    instead of system directories that require permissions.
    """
    # Create a session-wide temp directory for test infrastructure
    tmpdir = tmp_path_factory.mktemp("safeline-test-session")

    # Set safeline data directory to temp location
    data_dir = tmpdir / "safeline"
    data_dir.mkdir(parents=True, exist_ok=True)
    os.environ["SAFELINE_DATA_DIR"] = str(data_dir)

    # Set lock directory to temp location
    lock_dir = tmpdir / "locks"
    lock_dir.mkdir(parents=True, exist_ok=True)
    os.environ["SAFELINE_LOCK_DIR"] = str(lock_dir)

    yield

    # Cleanup happens automatically when pytest cleans up tmp_path_factory
