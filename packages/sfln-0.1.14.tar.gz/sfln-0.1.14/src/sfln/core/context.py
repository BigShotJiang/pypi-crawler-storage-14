"""Execution context for Safeline operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    pass


@dataclass
class Context:
    """Execution context passed to stage methods.

    The context provides access to operation state, previous stage results,
    and framework services during stage execution.

    Attributes:
        operation_id: Unique identifier for this operation instance.
        operation_type: Name of the operation type (class name).
        environment: Current environment (e.g., "prod", "staging", "dev").
        actor: User or system that initiated the operation.
        targets: List of targets this operation is acting on.
        stage_results: Results from previously completed stages.
        metadata: Arbitrary metadata attached to the operation.
        dry_run: If True, stage should simulate but not perform actions.
    """

    operation_id: str
    operation_type: str
    environment: str
    actor: str
    targets: list[Any] = field(default_factory=list)
    stage_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    dry_run: bool = False

    def get_stage_result(self, stage_name: str) -> dict[str, Any] | None:
        """Get the result data from a previously completed stage.

        Args:
            stage_name: Name of the stage to get results from.

        Returns:
            Result data dictionary, or None if stage hasn't completed.
        """
        return self.stage_results.get(stage_name)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "environment": self.environment,
            "actor": self.actor,
            "targets": self.targets,
            "stage_results": self.stage_results,
            "metadata": self.metadata,
            "dry_run": self.dry_run,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Context:
        """Deserialize from dictionary."""
        return cls(
            operation_id=data["operation_id"],
            operation_type=data["operation_type"],
            environment=data.get("environment", "unknown"),
            actor=data.get("actor", "unknown"),
            targets=data.get("targets", []),
            stage_results=data.get("stage_results", {}),
            metadata=data.get("metadata", {}),
            dry_run=data.get("dry_run", False),
        )
