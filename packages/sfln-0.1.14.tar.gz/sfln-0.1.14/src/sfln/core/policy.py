"""Policy, risk assessment, and user context models for Safeline.

These models provide generic infrastructure for:
- Policy evaluation (OPA integration, custom policies)
- Risk assessment and scoring
- User context for RBAC and audit trails
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Verdict(str, Enum):
    """Policy verdict types.

    Used for OPA integration or custom policy evaluation.
    Operations can use verdicts to enforce safety gates.
    """

    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"


@dataclass
class PolicyVerdict:
    """Result from policy evaluation (OPA, built-in, custom policies).

    Attributes:
        verdict: The policy decision (allow, deny, require_approval)
        policy_id: Optional identifier for which policy made this decision
        reason_code: Optional machine-readable reason code
        message: Optional human-readable explanation
        reasons: List of specific reasons for this verdict

    Example:
        verdict = PolicyVerdict(
            verdict=Verdict.REQUIRE_APPROVAL,
            policy_id="production-changes",
            reason_code="high_risk_target",
            message="Production changes require approval",
            reasons=["Target is production database", "Risk score: 85/100"]
        )
    """

    verdict: Verdict
    policy_id: str | None = None
    reason_code: str | None = None
    message: str | None = None
    reasons: list[str] | None = None

    def __post_init__(self) -> None:
        if self.reasons is None:
            self.reasons = []


class RiskLevel(str, Enum):
    """Risk assessment levels.

    Used to categorize operation risk for policy decisions,
    approval requirements, and audit logging.
    """

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class RiskScore:
    """Risk assessment result.

    Attributes:
        level: Categorized risk level
        score: Numeric score 0-100 (0=no risk, 100=maximum risk)
        reasons: List of factors that contributed to this score

    Example:
        risk = RiskScore(
            level=RiskLevel.HIGH,
            score=85,
            reasons=[
                "Target is production environment",
                "Operation affects 1000+ records",
                "No recent backup found"
            ]
        )
    """

    level: RiskLevel
    score: int  # 0-100
    reasons: list[str] | None = None

    def __post_init__(self) -> None:
        if self.reasons is None:
            self.reasons = []
        if not 0 <= self.score <= 100:
            raise ValueError(f"Risk score must be 0-100, got {self.score}")

    @classmethod
    def from_score(cls, score: int, reasons: list[str] | None = None) -> RiskScore:
        """Create RiskScore from numeric score, auto-determining level.

        Args:
            score: Numeric score 0-100
            reasons: Optional list of risk factors

        Returns:
            RiskScore with appropriate level

        Example:
            risk = RiskScore.from_score(
                score=75,
                reasons=["Production environment", "Large dataset"]
            )
            assert risk.level == RiskLevel.HIGH
        """
        if score < 25:
            level = RiskLevel.LOW
        elif score < 50:
            level = RiskLevel.MEDIUM
        elif score < 75:
            level = RiskLevel.HIGH
        else:
            level = RiskLevel.CRITICAL

        return cls(level=level, score=score, reasons=reasons)


@dataclass
class UserContext:
    """User context for policy evaluation, RBAC, and audit trails.

    Attributes:
        id: Unique user identifier (email, username, service account name)
        role: Optional primary role (admin, operator, developer, etc.)
        groups: List of groups this user belongs to

    Example:
        user = UserContext(
            id="alice@company.com",
            role="admin",
            groups=["ops-team", "database-admins"]
        )
    """

    id: str
    role: str | None = None
    groups: list[str] | None = None

    def __post_init__(self) -> None:
        if self.groups is None:
            self.groups = []

    def has_role(self, role: str) -> bool:
        """Check if user has a specific role."""
        return self.role == role

    def in_group(self, group: str) -> bool:
        """Check if user is in a specific group."""
        return group in (self.groups or [])

    def in_any_group(self, groups: list[str]) -> bool:
        """Check if user is in any of the specified groups."""
        return any(self.in_group(g) for g in groups)

    def in_all_groups(self, groups: list[str]) -> bool:
        """Check if user is in all of the specified groups."""
        return all(self.in_group(g) for g in groups)
