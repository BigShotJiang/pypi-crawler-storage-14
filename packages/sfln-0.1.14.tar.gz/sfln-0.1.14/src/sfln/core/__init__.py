"""Core components for Safeline operations."""

from sfln.core.context import Context
from sfln.core.operation import Operation
from sfln.core.pipeline import Safeline
from sfln.core.result import OperationResult, OperationState, StageResult
from sfln.core.stage import Stage, StageState, StageStatus

__all__ = [
    "Context",
    "Operation",
    "OperationResult",
    "OperationState",
    "Safeline",
    "Stage",
    "StageResult",
    "StageState",
    "StageStatus",
]
