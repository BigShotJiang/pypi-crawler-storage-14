"""Pipeline orchestration for Safeline operations."""

from __future__ import annotations

import uuid
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeout
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from sfln.core.context import Context
from sfln.core.result import (
    CleanupResult,
    OperationDetails,
    OperationResult,
    OperationState,
    OperationSummary,
    StageResult,
)
from sfln.core.stage import StageState, StageStatus
from sfln.exceptions import (
    ApprovalRequiredError,
    InvalidOperationStateError,
    InvalidStageTransitionError,
    OperationNotFoundError,
)

if TYPE_CHECKING:
    from sfln.approval.manager import ApprovalManager
    from sfln.audit.emitter import AuditEmitter
    from sfln.core.operation import Operation
    from sfln.locking.manager import LockManager
    from sfln.notifications.webhook import Notifier
    from sfln.storage.store import OperationStore


def _now_iso() -> str:
    """Get current time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


def _generate_operation_id() -> str:
    """Generate a unique operation ID."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    suffix = uuid.uuid4().hex[:8]
    return f"op-{ts}-{suffix}"


class Safeline:
    """Main orchestrator for Safeline operations.

    The Safeline class manages the lifecycle of operations: creating them,
    running stages, handling approvals, acquiring locks, and emitting audit events.

    Example:
        sl = Safeline(
            data_dir="/var/lib/safeline",
            audit_url="http://audit-store:8080",
        )

        op = MyOperation(targets=["/path/to/target"])
        result = sl.run(op)
    """

    def __init__(
        self,
        store: OperationStore | None = None,
        auditor: AuditEmitter | None = None,
        lock_manager: LockManager | None = None,
        approval_manager: ApprovalManager | None = None,
        environment: str = "unknown",
        actor: str = "unknown",
        notifiers: list[Notifier] | None = None,
    ) -> None:
        """Initialize Safeline.

        Args:
            store: Operation store for persistence. Creates default if None.
            auditor: Audit emitter for events. Creates no-op if None.
            lock_manager: Lock manager for stage locking. Creates default if None.
            approval_manager: Approval manager. Creates default if None.
            environment: Default environment name.
            actor: Default actor name.
            notifiers: Optional list of notifiers for webhooks etc.
        """
        self._store = store
        self._auditor = auditor
        self._lock_manager = lock_manager
        self._approval_manager = approval_manager
        self._environment = environment
        self._actor = actor
        self._notifiers = notifiers or []

        # In-memory operation instances (for running operations)
        self._operations: dict[str, Operation] = {}

    @classmethod
    def from_config(cls, path: str) -> Safeline:
        """Create Safeline instance from config file.

        Args:
            path: Path to YAML configuration file.

        Returns:
            Configured Safeline instance.

        Example:
            sl = Safeline.from_config("/etc/safeline/safeline.yaml")
        """
        from sfln.config.loader import from_config

        return from_config(path)

    def create(
        self,
        operation: Operation,
        actor: str | None = None,
        environment: str | None = None,
        dry_run: bool = False,
    ) -> str:
        """Create a new operation and return its ID.

        This persists the operation to the store and emits an audit event.

        Args:
            operation: The operation instance to create.
            actor: Who is creating this operation. Uses default if None.
            environment: Environment name. Uses default if None.
            dry_run: If True, operation will simulate but not perform actions.

        Returns:
            The unique operation ID.
        """
        operation_id = _generate_operation_id()
        actor = actor or self._actor
        environment = environment or self._environment

        context = Context(
            operation_id=operation_id,
            operation_type=operation.name,
            environment=environment,
            actor=actor,
            targets=operation.targets,
            metadata=operation.metadata,
            dry_run=dry_run,
        )

        stage_statuses = operation.initialize_stage_statuses()

        # Store operation
        if self._store:
            self._store.save(
                operation_id=operation_id,
                operation=operation,
                context=context,
                stage_statuses=stage_statuses,
                state=OperationState.CREATED,
            )

        # Keep reference to operation instance
        self._operations[operation_id] = operation

        # Emit audit event and notify
        self._emit_and_notify(
            event_type="operation_created",
            operation_id=operation_id,
            operation_type=operation.name,
            actor=actor,
            environment=environment,
            data={
                "targets": operation.targets,
                "stages": [s.name for s in operation.stages],
                "dry_run": dry_run,
            },
        )

        return operation_id

    def run(
        self,
        operation: Operation,
        actor: str | None = None,
        environment: str | None = None,
        dry_run: bool = False,
    ) -> OperationResult:
        """Create and run an operation to completion.

        This creates the operation, runs all stages in sequence, and returns
        the final result. Stages requiring approval will block.

        Args:
            operation: The operation to run.
            actor: Who is running this operation.
            environment: Environment name.
            dry_run: If True, simulate but don't perform actions.

        Returns:
            The final operation result.
        """
        operation_id = self.create(operation, actor=actor, environment=environment, dry_run=dry_run)

        try:
            for stage in operation.stages:
                result = self.run_stage(operation_id, stage.name)
                if not result.success:
                    if stage.required:
                        return self._finalize_operation(
                            operation_id, OperationState.FAILED, result.error
                        )
        except ApprovalRequiredError:
            # Operation paused waiting for approval
            return self._finalize_operation(
                operation_id, OperationState.PAUSED, "Waiting for approval"
            )

        return self._finalize_operation(operation_id, OperationState.COMPLETED)

    def run_stage(self, operation_id: str, stage_name: str) -> StageResult:
        """Run a specific stage of an operation.

        Args:
            operation_id: The operation to run.
            stage_name: The stage to run.

        Returns:
            The stage result.

        Raises:
            OperationNotFoundError: If operation not found.
            InvalidStageTransitionError: If stage cannot be run.
            ApprovalRequiredError: If stage needs approval.
        """
        operation = self._get_operation(operation_id)
        stage = operation.get_stage(stage_name)
        if not stage:
            raise InvalidStageTransitionError(
                stage_name, "unknown", f"Stage '{stage_name}' not found"
            )

        # Load state from store
        context, stage_statuses, _ = self._load_state(operation_id)
        status = stage_statuses.get(stage_name)
        if not status:
            raise InvalidStageTransitionError(stage_name, "unknown", "Stage status not found")

        # Check if stage can be run
        self._validate_stage_runnable(stage_name, status, stage_statuses)

        # Check approval
        if stage.needs_approval and status.state != StageState.APPROVED:
            if status.state != StageState.WAITING_APPROVAL:
                status.state = StageState.WAITING_APPROVAL
                self._save_stage_status(operation_id, status)
                if self._auditor:
                    self._auditor.emit(
                        event_type="approval_requested",
                        operation_id=operation_id,
                        operation_type=operation.name,
                        actor=context.actor,
                        environment=context.environment,
                        stage_name=stage_name,
                    )
            raise ApprovalRequiredError(stage_name)

        # Acquire lock if needed
        lock_acquired = False
        if stage.needs_lock and self._lock_manager:
            lock_key = f"{operation_id}:{stage_name}"
            self._lock_manager.acquire(lock_key)
            lock_acquired = True
            if self._auditor:
                self._auditor.emit(
                    event_type="lock_acquired",
                    operation_id=operation_id,
                    operation_type=operation.name,
                    actor=context.actor,
                    environment=context.environment,
                    stage_name=stage_name,
                    data={"lock_key": lock_key},
                )

        try:
            # Update status to running
            status.state = StageState.RUNNING
            status.started_at = _now_iso()
            self._save_stage_status(operation_id, status)

            # Execute stage with retry logic
            method = operation.get_stage_method(stage_name)
            max_attempts = stage.retry_count + 1
            result: StageResult | None = None

            for attempt in range(max_attempts):
                status.attempts = attempt + 1
                self._save_stage_status(operation_id, status)

                if self._auditor:
                    self._auditor.emit(
                        event_type="stage_started",
                        operation_id=operation_id,
                        operation_type=operation.name,
                        actor=context.actor,
                        environment=context.environment,
                        stage_name=stage_name,
                        data={"attempt": status.attempts, "max_attempts": max_attempts},
                    )

                # Execute with or without timeout
                result = self._execute_stage_method(
                    method, context, stage_name, stage.timeout_seconds
                )

                if result.success:
                    break

                # Emit retry event if not last attempt
                if attempt < max_attempts - 1:
                    if self._auditor:
                        self._auditor.emit(
                            event_type="stage_retrying",
                            operation_id=operation_id,
                            operation_type=operation.name,
                            actor=context.actor,
                            environment=context.environment,
                            stage_name=stage_name,
                            success=False,
                            data={
                                "attempt": attempt + 1,
                                "max_attempts": max_attempts,
                                "error": result.error,
                            },
                        )

            # Update status based on result
            # result is always set since max_attempts >= 1
            assert result is not None
            status.completed_at = _now_iso()
            if result.success:
                status.state = StageState.COMPLETED
                status.result_data = result.data
                context.stage_results[stage_name] = result.data
            else:
                status.state = StageState.FAILED
                status.error = result.error

            self._save_stage_status(operation_id, status)

            # Emit audit event
            if self._auditor:
                self._auditor.emit(
                    event_type="stage_completed" if result.success else "stage_failed",
                    operation_id=operation_id,
                    operation_type=operation.name,
                    actor=context.actor,
                    environment=context.environment,
                    stage_name=stage_name,
                    success=result.success,
                    data=result.data,
                    error=result.error,
                )

            return result

        finally:
            # Release lock
            if lock_acquired and self._lock_manager:
                lock_key = f"{operation_id}:{stage_name}"
                self._lock_manager.release(lock_key)
                if self._auditor:
                    self._auditor.emit(
                        event_type="lock_released",
                        operation_id=operation_id,
                        operation_type=operation.name,
                        actor=context.actor,
                        environment=context.environment,
                        stage_name=stage_name,
                        data={"lock_key": lock_key},
                    )

    def approve(self, operation_id: str, stage_name: str, approver: str | None = None) -> None:
        """Approve a stage that is waiting for approval.

        Args:
            operation_id: The operation.
            stage_name: The stage to approve.
            approver: Who is approving. Uses default actor if None.
        """
        operation = self._get_operation(operation_id)
        context, stage_statuses, _ = self._load_state(operation_id)
        status = stage_statuses.get(stage_name)

        if not status:
            raise InvalidStageTransitionError(stage_name, "unknown", "Stage not found")

        if status.state != StageState.WAITING_APPROVAL:
            raise InvalidStageTransitionError(
                stage_name,
                status.state.value,
                "Stage is not waiting for approval",
            )

        approver = approver or self._actor
        status.state = StageState.APPROVED
        status.approved_by = approver
        status.approved_at = _now_iso()
        self._save_stage_status(operation_id, status)

        if self._auditor:
            self._auditor.emit(
                event_type="approval_granted",
                operation_id=operation_id,
                operation_type=operation.name,
                actor=approver,
                environment=context.environment,
                stage_name=stage_name,
            )

    def rollback(self, operation_id: str) -> OperationResult:
        """Rollback an operation by reversing completed stages.

        Stages are rolled back in reverse order. Only stages with
        rollback methods defined will be rolled back.

        Args:
            operation_id: The operation to rollback.

        Returns:
            The operation result after rollback.
        """
        operation = self._get_operation(operation_id)
        context, stage_statuses, _ = self._load_state(operation_id)

        if self._auditor:
            self._auditor.emit(
                event_type="rollback_started",
                operation_id=operation_id,
                operation_type=operation.name,
                actor=context.actor,
                environment=context.environment,
            )

        # Find completed stages in reverse order
        completed_stages = [
            s
            for s in reversed(operation.stages)
            if stage_statuses[s.name].state == StageState.COMPLETED and s.reversible
        ]

        rollback_errors: list[str] = []

        for stage in completed_stages:
            rollback_method = operation.get_rollback_method(stage.name)
            if not rollback_method:
                continue

            status = stage_statuses[stage.name]

            try:
                result = rollback_method(context)
                if result.success:
                    status.state = StageState.ROLLED_BACK
                else:
                    rollback_errors.append(f"{stage.name}: {result.error}")
            except Exception as e:
                rollback_errors.append(f"{stage.name}: {e}")

            self._save_stage_status(operation_id, status)

        if self._auditor:
            self._auditor.emit(
                event_type="rollback_completed",
                operation_id=operation_id,
                operation_type=operation.name,
                actor=context.actor,
                environment=context.environment,
                success=len(rollback_errors) == 0,
                data={"rolled_back": [s.name for s in completed_stages]},
                error="; ".join(rollback_errors) if rollback_errors else None,
            )

        if rollback_errors:
            return self._finalize_operation(
                operation_id,
                OperationState.FAILED,
                f"Rollback errors: {'; '.join(rollback_errors)}",
            )

        return self._finalize_operation(operation_id, OperationState.ROLLED_BACK)

    def resume(self, operation_id: str) -> OperationResult:
        """Resume a failed or paused operation from the next incomplete stage.

        Args:
            operation_id: The operation to resume.

        Returns:
            The operation result after resuming.

        Raises:
            OperationNotFoundError: If operation not found.
            InvalidOperationStateError: If operation cannot be resumed.
        """
        operation = self._get_operation(operation_id)
        context, stage_statuses, state = self._load_state(operation_id)

        # Only allow resuming failed or paused operations
        if state not in (OperationState.FAILED, OperationState.PAUSED):
            raise InvalidOperationStateError(
                operation_id, state.value, "Can only resume failed or paused operations"
            )

        # Update state to running
        if self._store:
            self._store.update_state(operation_id, OperationState.RUNNING)

        if self._auditor:
            self._auditor.emit(
                event_type="operation_resumed",
                operation_id=operation_id,
                operation_type=operation.name,
                actor=context.actor,
                environment=context.environment,
            )

        # Find first incomplete stage and run from there
        for stage in operation.stages:
            status = stage_statuses[stage.name]
            if status.state == StageState.COMPLETED:
                continue

            # Reset failed stages to pending
            if status.state == StageState.FAILED:
                status.state = StageState.PENDING
                status.error = None
                self._save_stage_status(operation_id, status)

            try:
                result = self.run_stage(operation_id, stage.name)
                if not result.success and stage.required:
                    return self._finalize_operation(
                        operation_id, OperationState.FAILED, result.error
                    )
            except ApprovalRequiredError:
                return self._finalize_operation(
                    operation_id, OperationState.PAUSED, "Waiting for approval"
                )

        return self._finalize_operation(operation_id, OperationState.COMPLETED)

    def abandon(
        self,
        operation_id: str,
        reason: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> OperationResult:
        """Mark an operation as abandoned (near-miss).

        This is used when an operation was created but never completed,
        recording it as a near-miss for audit purposes. This is critical
        for safety-critical systems to track abandoned operations.

        Args:
            operation_id: The operation to abandon.
            reason: Why the operation was abandoned.
            metadata: Additional context (e.g., session_duration_seconds).

        Returns:
            The operation result marked as abandoned.

        Raises:
            OperationNotFoundError: If operation not found.
        """
        operation = self._get_operation(operation_id)
        context, stage_statuses, current_state = self._load_state(operation_id)

        # Only allow abandoning operations that aren't already complete
        if current_state in (
            OperationState.COMPLETED,
            OperationState.ROLLED_BACK,
            OperationState.ABANDONED,
        ):
            # Already finalized, don't re-abandon
            return OperationResult(
                operation_id=operation_id,
                state=current_state,
                error=f"Operation already {current_state.value}",
            )

        # Emit abandon event
        self._emit_and_notify(
            event_type="operation_abandoned",
            operation_id=operation_id,
            operation_type=operation.name,
            actor=context.actor,
            environment=context.environment,
            success=False,
            data={
                "reason": reason or "abandoned",
                "previous_state": current_state.value,
            },
            metadata=metadata,
            error=reason,
        )

        # Finalize as abandoned
        return self._finalize_operation(
            operation_id,
            OperationState.ABANDONED,
            error=reason or "Operation abandoned",
        )

    def get_status(self, operation_id: str) -> dict[str, Any]:
        """Get the current status of an operation.

        Args:
            operation_id: The operation to check.

        Returns:
            Dictionary with operation status.
        """
        operation = self._get_operation(operation_id)
        context, stage_statuses, state = self._load_state(operation_id)

        return {
            "operation_id": operation_id,
            "operation_type": operation.name,
            "state": state.value,
            "environment": context.environment,
            "actor": context.actor,
            "targets": context.targets,
            "dry_run": context.dry_run,
            "stages": {name: status.to_dict() for name, status in stage_statuses.items()},
        }

    def list_operations(
        self,
        state: OperationState | None = None,
        environment: str | None = None,
        operation_type: str | None = None,
        actor: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[OperationSummary]:
        """List operations with filtering.

        Args:
            state: Filter by operation state
            environment: Filter by environment name
            operation_type: Filter by operation type
            actor: Filter by actor name
            since: Only operations created after this time
            until: Only operations created before this time
            limit: Maximum number of results (default 100, max 1000)
            offset: Skip first N results (default 0)

        Returns:
            List of operation summaries

        Example:
            # List all failed operations in production
            failed = sl.list_operations(
                state=OperationState.FAILED,
                environment="production"
            )

            # List recent operations
            from datetime import datetime, timedelta
            recent = sl.list_operations(
                since=datetime.now() - timedelta(days=7),
                limit=50
            )
        """
        if not self._store:
            return []

        return self._store.list_operations(
            state=state,
            environment=environment,
            operation_type=operation_type,
            actor=actor,
            since=since,
            until=until,
            limit=limit,
            offset=offset,
        )

    def get_operation(self, operation_id: str) -> OperationDetails:
        """Get complete operation details.

        Args:
            operation_id: The operation to retrieve

        Returns:
            Complete operation details

        Raises:
            OperationNotFoundError: If operation doesn't exist

        Example:
            details = sl.get_operation("op-20241123-120000-xyz789")
            print(f"State: {details.state}")
            print(f"Targets: {details.targets}")
            print(f"Completed stages: {details.stages_completed}")
            print(f"Metadata: {details.metadata}")
        """
        if not self._store:
            raise OperationNotFoundError(operation_id)

        # Load operation and state
        operation = self._get_operation(operation_id)
        context, stage_statuses, state = self._load_state(operation_id)

        # Load stored data to get timestamps
        try:
            stored_data = (
                self._store._operations.get(operation_id)
                if hasattr(self._store, "_operations")
                else {}
            )
        except AttributeError:
            # For FileStore, would need to load the JSON - for now just use what we have
            stored_data = {}

        # Build stage lists and results
        completed = []
        failed = []
        results = {}

        for stage in operation.stages:
            status = stage_statuses[stage.name]
            if status.state == StageState.COMPLETED:
                completed.append(stage.name)
                if status.result_data:
                    results[stage.name] = status.result_data
            elif status.state == StageState.FAILED:
                failed.append(stage.name)

        # Build error message if any
        error = None
        if state == OperationState.FAILED:
            # Get error from first failed stage
            for stage_name in failed:
                status = stage_statuses[stage_name]
                if status.error:
                    error = f"{stage_name}: {status.error}"
                    break

        return OperationDetails(
            operation_id=operation_id,
            operation_type=operation.name,
            state=state,
            environment=context.environment,
            actor=context.actor,
            targets=context.targets,
            metadata=context.metadata,
            dry_run=context.dry_run,
            created_at=stored_data.get("created_at", ""),
            started_at=stored_data.get("started_at"),
            completed_at=stored_data.get("completed_at"),
            stage_statuses={name: status.to_dict() for name, status in stage_statuses.items()},
            stage_results=results,
            stages_completed=completed,
            stages_failed=failed,
            error=error,
        )

    def cleanup(
        self,
        retention_days: int,
        environment: str | None = None,
        dry_run: bool = False,
    ) -> CleanupResult:
        """Remove operations older than retention period.

        Args:
            retention_days: Remove operations older than this many days
            environment: Only cleanup operations in this environment (optional)
            dry_run: If True, return what would be removed without removing

        Returns:
            Cleanup result with statistics

        Example:
            # Cleanup old prod operations
            result = sl.cleanup(
                retention_days=90,
                environment="production"
            )
            print(f"Removed {result.operations_removed} operations")
            print(f"Freed {result.bytes_freed} bytes")

            # Dry run to see what would be removed
            result = sl.cleanup(retention_days=30, dry_run=True)
            print(f"Would remove: {result.removed_operation_ids}")
        """
        if not self._store:
            return CleanupResult(
                operations_removed=0,
                operations_kept=0,
                bytes_freed=0,
                dry_run=dry_run,
            )

        return self._store.cleanup(
            retention_days=retention_days,
            environment=environment,
            dry_run=dry_run,
        )

    def _emit_and_notify(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        """Emit audit event and send notifications.

        Args:
            event_type: Type of event.
            operation_id: Operation ID.
            operation_type: Operation type name.
            actor: Who triggered this.
            environment: Environment name.
            stage_name: Optional stage name.
            success: Whether action succeeded.
            data: Event-specific data.
            metadata: Additional context.
            error: Error message if failed.
        """
        if self._auditor:
            self._auditor.emit(
                event_type=event_type,
                operation_id=operation_id,
                operation_type=operation_type,
                actor=actor,
                environment=environment,
                stage_name=stage_name,
                success=success,
                data=data,
                metadata=metadata,
                error=error,
            )

        # Send notifications
        if self._notifiers:
            from sfln.audit.events import AuditEvent

            event = AuditEvent(
                event_type=event_type,
                operation_id=operation_id,
                operation_type=operation_type,
                actor=actor,
                environment=environment,
                stage_name=stage_name,
                success=success,
                data=data or {},
                metadata=metadata or {},
                error=error,
            )
            for notifier in self._notifiers:
                notifier.notify(event)

    def _execute_stage_method(
        self,
        method: Any,
        context: Context,
        stage_name: str,
        timeout_seconds: int | None,
    ) -> StageResult:
        """Execute a stage method with optional timeout.

        Args:
            method: The stage method to call.
            context: The execution context.
            stage_name: Name of the stage (for error messages).
            timeout_seconds: Optional timeout in seconds.

        Returns:
            The stage result.
        """
        if timeout_seconds is None:
            # No timeout, execute directly
            try:
                result: StageResult = method(context)
                return result
            except Exception as e:
                return StageResult(success=False, error=str(e))

        # Execute with timeout using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(method, context)
            try:
                result = future.result(timeout=timeout_seconds)
                return result
            except FuturesTimeout:
                return StageResult(
                    success=False,
                    error=f"Stage timed out after {timeout_seconds}s",
                )
            except Exception as e:
                return StageResult(success=False, error=str(e))

    def _get_operation(self, operation_id: str) -> Operation:
        """Get operation instance by ID."""
        if operation_id not in self._operations:
            # Try to load from store
            if self._store:
                operation = self._store.load_operation(operation_id)
                if operation:
                    self._operations[operation_id] = operation
                    return operation
            raise OperationNotFoundError(operation_id)
        return self._operations[operation_id]

    def _load_state(
        self, operation_id: str
    ) -> tuple[Context, dict[str, StageStatus], OperationState]:
        """Load operation state from store."""
        if self._store:
            return self._store.load_state(operation_id)
        raise OperationNotFoundError(operation_id)

    def _save_stage_status(self, operation_id: str, status: StageStatus) -> None:
        """Save updated stage status to store."""
        if self._store:
            self._store.update_stage_status(operation_id, status)

    def _validate_stage_runnable(
        self,
        stage_name: str,
        status: StageStatus,
        all_statuses: dict[str, StageStatus],
    ) -> None:
        """Validate that a stage can be run."""
        # Check current state
        if status.state in (StageState.COMPLETED, StageState.ROLLED_BACK):
            raise InvalidStageTransitionError(
                stage_name, status.state.value, "Stage already completed"
            )

        if status.state == StageState.RUNNING:
            raise InvalidStageTransitionError(
                stage_name, status.state.value, "Stage is already running"
            )

        # Check previous stages are complete
        stage_names = [s.name for s in self._get_operation_stages(stage_name)]
        stage_index = stage_names.index(stage_name)

        for i in range(stage_index):
            prev_name = stage_names[i]
            prev_status = all_statuses.get(prev_name)
            if prev_status and prev_status.stage.required:
                if prev_status.state not in (
                    StageState.COMPLETED,
                    StageState.SKIPPED,
                ):
                    raise InvalidStageTransitionError(
                        stage_name,
                        status.state.value,
                        f"Previous required stage '{prev_name}' not complete",
                    )

    def _get_operation_stages(self, stage_name: str) -> list:
        """Get stages list for an operation containing the given stage."""
        # Find operation that has this stage
        for operation in self._operations.values():
            for stage in operation.stages:
                if stage.name == stage_name:
                    return operation.stages
        return []

    def _finalize_operation(
        self,
        operation_id: str,
        state: OperationState,
        error: str | None = None,
    ) -> OperationResult:
        """Finalize an operation and return result."""
        operation = self._get_operation(operation_id)
        context, stage_statuses, _ = self._load_state(operation_id)

        completed = []
        failed = []
        skipped = []
        stage_results = {}

        for stage in operation.stages:
            status = stage_statuses[stage.name]
            if status.state == StageState.COMPLETED:
                completed.append(stage.name)
                stage_results[stage.name] = status.result_data
            elif status.state == StageState.FAILED:
                failed.append(stage.name)
            elif status.state == StageState.SKIPPED:
                skipped.append(stage.name)

        result = OperationResult(
            operation_id=operation_id,
            state=state,
            stages_completed=completed,
            stages_failed=failed,
            stages_skipped=skipped,
            stage_results=stage_results,
            error=error,
            completed_at=_now_iso(),
        )

        if self._store:
            self._store.update_state(operation_id, state)

        self._emit_and_notify(
            event_type="operation_completed"
            if state == OperationState.COMPLETED
            else "operation_failed",
            operation_id=operation_id,
            operation_type=operation.name,
            actor=context.actor,
            environment=context.environment,
            success=state == OperationState.COMPLETED,
            data=result.to_dict(),
            error=error,
        )

        return result
