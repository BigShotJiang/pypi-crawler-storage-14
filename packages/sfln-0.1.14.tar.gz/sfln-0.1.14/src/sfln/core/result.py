"""Result types for Safeline operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class OperationState(str, Enum):
    """Overall state of an operation."""

    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"  # Waiting for approval
    COMPLETED = "completed"
    FAILED = "failed"
    ABANDONED = "abandoned"  # Created but not completed (near-miss)
    ROLLING_BACK = "rolling_back"
    ROLLED_BACK = "rolled_back"


@dataclass
class StageResult:
    """Result returned by a stage method.

    Stage methods return this to indicate success/failure and provide
    data that can be used by subsequent stages.

    Attributes:
        success: Whether the stage completed successfully. Default True.
        data: Arbitrary data to pass to subsequent stages.
        message: Human-readable status message.
        error: Error message if success is False.
        rollback_data: Data needed to rollback this stage.
    """

    success: bool = True
    data: dict[str, Any] = field(default_factory=dict)
    message: str = ""
    error: str | None = None
    rollback_data: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.success and not self.error:
            self.error = self.message or "Stage failed"

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "success": self.success,
            "data": self.data,
            "message": self.message,
            "error": self.error,
            "rollback_data": self.rollback_data,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StageResult:
        """Deserialize from dictionary."""
        return cls(
            success=data.get("success", True),
            data=data.get("data", {}),
            message=data.get("message", ""),
            error=data.get("error"),
            rollback_data=data.get("rollback_data", {}),
        )


@dataclass
class OperationResult:
    """Final result of a complete operation.

    This is returned when an operation finishes (success, failure, or rollback).

    Attributes:
        operation_id: Unique identifier for this operation.
        state: Final state of the operation.
        stages_completed: List of stage names that completed successfully.
        stages_failed: List of stage names that failed.
        stages_skipped: List of stage names that were skipped.
        stage_results: Results from each completed stage.
        error: Error message if operation failed.
        started_at: ISO timestamp when operation started.
        completed_at: ISO timestamp when operation finished.
    """

    operation_id: str
    state: OperationState
    stages_completed: list[str] = field(default_factory=list)
    stages_failed: list[str] = field(default_factory=list)
    stages_skipped: list[str] = field(default_factory=list)
    stage_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    error: str | None = None
    started_at: str | None = None
    completed_at: str | None = None

    @property
    def success(self) -> bool:
        """Whether the operation completed successfully."""
        return self.state == OperationState.COMPLETED

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "operation_id": self.operation_id,
            "state": self.state.value,
            "success": self.success,
            "stages_completed": self.stages_completed,
            "stages_failed": self.stages_failed,
            "stages_skipped": self.stages_skipped,
            "stage_results": self.stage_results,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


@dataclass
class OperationSummary:
    """Summary of an operation for list views.

    Lightweight representation without full stage results.
    Used by list_operations() to efficiently return operation summaries.
    """

    operation_id: str
    operation_type: str
    state: OperationState
    environment: str
    actor: str
    targets: list[str]
    created_at: str
    started_at: str | None = None
    completed_at: str | None = None
    stages_completed: int = 0
    stages_failed: int = 0
    stages_total: int = 0
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "state": self.state.value,
            "environment": self.environment,
            "actor": self.actor,
            "targets": self.targets,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "stages_completed": self.stages_completed,
            "stages_failed": self.stages_failed,
            "stages_total": self.stages_total,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OperationSummary:
        """Deserialize from dictionary."""
        return cls(
            operation_id=data["operation_id"],
            operation_type=data["operation_type"],
            state=OperationState(data["state"]),
            environment=data["environment"],
            actor=data["actor"],
            targets=data["targets"],
            created_at=data["created_at"],
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            stages_completed=data.get("stages_completed", 0),
            stages_failed=data.get("stages_failed", 0),
            stages_total=data.get("stages_total", 0),
            error=data.get("error"),
        )


@dataclass
class OperationDetails:
    """Complete operation details for show/inspect views.

    Full representation with all context and results.
    Used by get_operation() to return complete operation information.
    """

    operation_id: str
    operation_type: str
    state: OperationState
    environment: str
    actor: str
    targets: list[str]
    metadata: dict[str, Any]
    dry_run: bool
    created_at: str
    started_at: str | None = None
    completed_at: str | None = None

    # Stage information
    stage_statuses: dict[str, dict[str, Any]] = field(default_factory=dict)
    stage_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    stages_completed: list[str] = field(default_factory=list)
    stages_failed: list[str] = field(default_factory=list)

    # Operation results
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "state": self.state.value,
            "environment": self.environment,
            "actor": self.actor,
            "targets": self.targets,
            "metadata": self.metadata,
            "dry_run": self.dry_run,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "stage_statuses": self.stage_statuses,
            "stage_results": self.stage_results,
            "stages_completed": self.stages_completed,
            "stages_failed": self.stages_failed,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OperationDetails:
        """Deserialize from dictionary."""
        return cls(
            operation_id=data["operation_id"],
            operation_type=data["operation_type"],
            state=OperationState(data["state"]),
            environment=data["environment"],
            actor=data["actor"],
            targets=data["targets"],
            metadata=data["metadata"],
            dry_run=data["dry_run"],
            created_at=data["created_at"],
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            stage_statuses=data.get("stage_statuses", {}),
            stage_results=data.get("stage_results", {}),
            stages_completed=data.get("stages_completed", []),
            stages_failed=data.get("stages_failed", []),
            error=data.get("error"),
        )


@dataclass
class CleanupResult:
    """Result of cleanup operation.

    Contains statistics about what was cleaned up.
    """

    operations_removed: int
    operations_kept: int
    bytes_freed: int
    dry_run: bool
    removed_operation_ids: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "operations_removed": self.operations_removed,
            "operations_kept": self.operations_kept,
            "bytes_freed": self.bytes_freed,
            "dry_run": self.dry_run,
            "removed_operation_ids": self.removed_operation_ids,
        }
