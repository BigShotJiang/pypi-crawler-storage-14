"""Stage definition for Safeline operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class StageState(str, Enum):
    """State of a stage in an operation."""

    PENDING = "pending"
    WAITING_APPROVAL = "waiting_approval"
    APPROVED = "approved"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ROLLED_BACK = "rolled_back"


@dataclass
class Stage:
    """Definition of a stage in an operation pipeline.

    Stages are the building blocks of operations. Each stage represents
    a discrete step that can be executed, tracked, and potentially rolled back.

    Args:
        name: Unique name for this stage within the operation.
        required: If True, operation fails if this stage fails. Default True.
        needs_approval: If True, stage blocks until approved. Default False.
        needs_lock: If True, acquires exclusive lock before execution. Default False.
        reversible: If True, stage can be rolled back. Default False.
        timeout_seconds: Maximum execution time. None means no timeout.
        retry_count: Number of automatic retries on failure. Default 0.
        description: Human-readable description of what this stage does.
    """

    name: str
    required: bool = True
    needs_approval: bool = False
    needs_lock: bool = False
    reversible: bool = False
    timeout_seconds: int | None = None
    retry_count: int = 0
    description: str = ""

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("Stage name cannot be empty")
        if not self.name.replace("_", "").replace("-", "").isalnum():
            raise ValueError(
                f"Stage name '{self.name}' must be alphanumeric with underscores/hyphens"
            )


@dataclass
class StageStatus:
    """Runtime status of a stage within an operation instance.

    This tracks the current state and execution history of a stage.
    """

    stage: Stage
    state: StageState = StageState.PENDING
    attempts: int = 0
    started_at: str | None = None
    completed_at: str | None = None
    error: str | None = None
    result_data: dict[str, Any] = field(default_factory=dict)
    approved_by: str | None = None
    approved_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "stage_name": self.stage.name,
            "state": self.state.value,
            "attempts": self.attempts,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "error": self.error,
            "result_data": self.result_data,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any], stage: Stage) -> StageStatus:
        """Deserialize from dictionary."""
        return cls(
            stage=stage,
            state=StageState(data.get("state", "pending")),
            attempts=data.get("attempts", 0),
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            error=data.get("error"),
            result_data=data.get("result_data", {}),
            approved_by=data.get("approved_by"),
            approved_at=data.get("approved_at"),
        )
