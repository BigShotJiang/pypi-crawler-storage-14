"""Base Operation class for Safeline."""

from __future__ import annotations

from abc import ABC
from dataclasses import dataclass, field
from typing import Any, ClassVar

from sfln.core.stage import Stage, StageStatus
from sfln.exceptions import StageNotFoundError


@dataclass
class Operation(ABC):  # noqa: B024 - Stage methods are dynamically defined based on `stages` attribute
    """Base class for all Safeline operations.

    Subclasses define their own stages and implement methods for each stage.
    The framework handles orchestration, state management, locking, approvals,
    and audit.

    Example:
        class MyOperation(Operation):
            name = "my-operation"
            stages = [
                Stage("prepare"),
                Stage("execute", needs_approval=True),
                Stage("cleanup"),
            ]

            def prepare(self, context: Context) -> StageResult:
                return StageResult(data={"prepared": True})

            def execute(self, context: Context) -> StageResult:
                return StageResult(data={"done": True})

            def cleanup(self, context: Context) -> StageResult:
                return StageResult(data={"cleaned": True})

    Attributes:
        name: Unique name for this operation type. Must be set by subclass.
        stages: List of Stage definitions. Must be set by subclass.
        targets: List of targets this operation will act on.
        metadata: Arbitrary metadata for this operation instance.
    """

    # Class-level attributes (must be overridden by subclass)
    name: ClassVar[str] = ""
    stages: ClassVar[list[Stage]] = []

    # Instance attributes
    targets: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError(f"{self.__class__.__name__} must define 'name' class attribute")
        if not self.stages:
            raise ValueError(f"{self.__class__.__name__} must define 'stages' class attribute")
        self._validate_stages()

    def _validate_stages(self) -> None:
        """Validate that all stages have corresponding methods."""
        seen_names: set[str] = set()
        for stage in self.stages:
            if stage.name in seen_names:
                raise ValueError(f"Duplicate stage name: {stage.name}")
            seen_names.add(stage.name)

            if not hasattr(self, stage.name):
                raise StageNotFoundError(stage.name, self.__class__.__name__)

    def get_stage(self, name: str) -> Stage | None:
        """Get a stage by name."""
        for stage in self.stages:
            if stage.name == name:
                return stage
        return None

    def get_stage_method(self, stage_name: str) -> Any:
        """Get the method that implements a stage."""
        if not hasattr(self, stage_name):
            raise StageNotFoundError(stage_name, self.__class__.__name__)
        return getattr(self, stage_name)

    def get_rollback_method(self, stage_name: str) -> Any | None:
        """Get the rollback method for a stage, if it exists."""
        rollback_name = f"rollback_{stage_name}"
        if hasattr(self, rollback_name):
            return getattr(self, rollback_name)
        return None

    def initialize_stage_statuses(self) -> dict[str, StageStatus]:
        """Create initial StageStatus objects for all stages."""
        return {stage.name: StageStatus(stage=stage) for stage in self.stages}

    def to_dict(self) -> dict[str, Any]:
        """Serialize operation definition to dictionary."""
        return {
            "name": self.name,
            "operation_class": self.__class__.__name__,
            "stages": [
                {
                    "name": s.name,
                    "required": s.required,
                    "needs_approval": s.needs_approval,
                    "needs_lock": s.needs_lock,
                    "reversible": s.reversible,
                    "timeout_seconds": s.timeout_seconds,
                    "retry_count": s.retry_count,
                    "description": s.description,
                }
                for s in self.stages
            ],
            "targets": self.targets,
            "metadata": self.metadata,
        }
