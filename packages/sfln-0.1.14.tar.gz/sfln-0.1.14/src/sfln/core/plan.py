"""Operation plan definitions for Safeline.

The OperationPlan is the standardized, persistent record format for operations.
It provides a complete snapshot of an operation's definition, state, and history
that can be stored, queried, and used for compliance reporting.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from sfln.core.result import OperationState
from sfln.core.stage import Stage, StageState

# Schema version for plan format evolution
PLAN_SCHEMA_VERSION = "1.0"


def generate_plan_id() -> str:
    """Generate a unique plan ID.

    Format: plan-YYYYMMDD-HHMMSS-{8 hex chars}

    Returns:
        Unique plan identifier string.
    """
    now = datetime.now(timezone.utc)
    timestamp = now.strftime("%Y%m%d-%H%M%S")
    suffix = uuid.uuid4().hex[:8]
    return f"plan-{timestamp}-{suffix}"


def _now_iso() -> str:
    """Get current time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


@dataclass
class StagePlan:
    """Stage definition snapshot in an operation plan.

    This captures the stage configuration at the time the plan was created,
    ensuring the plan is self-contained and doesn't depend on runtime definitions.

    Attributes:
        name: Stage name (unique within operation).
        required: If True, failure stops the operation.
        needs_approval: If True, blocks until approved.
        needs_lock: If True, acquires exclusive lock.
        reversible: If True, stage can be rolled back.
        timeout_seconds: Max execution time (None = no limit).
        retry_count: Number of automatic retries on failure.
        description: Human-readable description.
    """

    name: str
    required: bool = True
    needs_approval: bool = False
    needs_lock: bool = False
    reversible: bool = False
    timeout_seconds: int | None = None
    retry_count: int = 0
    description: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "name": self.name,
            "required": self.required,
            "needs_approval": self.needs_approval,
            "needs_lock": self.needs_lock,
            "reversible": self.reversible,
            "timeout_seconds": self.timeout_seconds,
            "retry_count": self.retry_count,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StagePlan:
        """Deserialize from dictionary."""
        return cls(
            name=data["name"],
            required=data.get("required", True),
            needs_approval=data.get("needs_approval", False),
            needs_lock=data.get("needs_lock", False),
            reversible=data.get("reversible", False),
            timeout_seconds=data.get("timeout_seconds"),
            retry_count=data.get("retry_count", 0),
            description=data.get("description", ""),
        )

    @classmethod
    def from_stage(cls, stage: Stage) -> StagePlan:
        """Create StagePlan from a Stage definition."""
        return cls(
            name=stage.name,
            required=stage.required,
            needs_approval=stage.needs_approval,
            needs_lock=stage.needs_lock,
            reversible=stage.reversible,
            timeout_seconds=stage.timeout_seconds,
            retry_count=stage.retry_count,
            description=stage.description,
        )


@dataclass
class StageStatusRecord:
    """Stage execution record in an operation plan.

    This captures the runtime status and history of a stage execution,
    including timing, approval, attempts, and results.

    Attributes:
        stage_name: Name of the stage.
        state: Current state (pending, running, completed, etc.).
        attempts: Number of execution attempts.
        started_at: ISO timestamp when stage started.
        completed_at: ISO timestamp when stage finished.
        error: Error message if failed.
        result_data: Data returned by the stage.
        rollback_data: Data for rolling back this stage.
        approved_by: Who approved (if approval required).
        approved_at: ISO timestamp of approval.
    """

    stage_name: str
    state: str = StageState.PENDING.value
    attempts: int = 0
    started_at: str | None = None
    completed_at: str | None = None
    error: str | None = None
    result_data: dict[str, Any] = field(default_factory=dict)
    rollback_data: dict[str, Any] = field(default_factory=dict)
    approved_by: str | None = None
    approved_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "stage_name": self.stage_name,
            "state": self.state,
            "attempts": self.attempts,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "error": self.error,
            "result_data": self.result_data,
            "rollback_data": self.rollback_data,
            "approved_by": self.approved_by,
            "approved_at": self.approved_at,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StageStatusRecord:
        """Deserialize from dictionary."""
        return cls(
            stage_name=data["stage_name"],
            state=data.get("state", StageState.PENDING.value),
            attempts=data.get("attempts", 0),
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            error=data.get("error"),
            result_data=data.get("result_data", {}),
            rollback_data=data.get("rollback_data", {}),
            approved_by=data.get("approved_by"),
            approved_at=data.get("approved_at"),
        )


@dataclass
class OperationPlan:
    """Complete operation record with standardized schema.

    The OperationPlan is the canonical, persistent representation of an operation.
    It captures everything needed to:
    - Understand what the operation does
    - Track its current state and history
    - Support compliance and audit queries
    - Enable resume/rollback after failures

    The plan is self-contained - it includes snapshots of stage definitions
    and protection settings at creation time, so it doesn't depend on
    runtime configuration that might change.

    Attributes:
        plan_id: Unique plan identifier (plan-YYYYMMDD-HHMMSS-{hex}).
        operation_id: Runtime operation ID (op-YYYYMMDD-HHMMSS-{hex}).
        operation_type: Name of the operation class.
        schema_version: Plan schema version for evolution.
        created_at: ISO timestamp when plan was created.
        started_at: ISO timestamp when execution began.
        completed_at: ISO timestamp when execution finished.
        expires_at: ISO timestamp when plan should be cleaned up.
        environment: Environment name (prod, staging, dev, etc.).
        actor: User or system that created the operation.
        targets: List of targets the operation acts on.
        metadata: Arbitrary metadata attached to the operation.
        dry_run: If True, operation simulates but doesn't make changes.
        protection_level: Name of applied protection level.
        protection_settings: Snapshot of protection level settings.
        state: Current operation state.
        stages: Ordered list of stage definitions.
        stage_statuses: Status record for each stage.
        stage_results: Result data from each completed stage.
        error: Error message if operation failed.
        audit_event_ids: List of related audit event IDs.
    """

    # Identity
    plan_id: str
    operation_id: str
    operation_type: str
    schema_version: str = PLAN_SCHEMA_VERSION

    # Lifecycle timestamps
    created_at: str = field(default_factory=_now_iso)
    started_at: str | None = None
    completed_at: str | None = None
    expires_at: str | None = None

    # Context
    environment: str = "unknown"
    actor: str = "unknown"
    targets: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    dry_run: bool = False

    # Protection
    protection_level: str = "development"
    protection_settings: dict[str, Any] = field(default_factory=dict)

    # State
    state: OperationState = OperationState.CREATED
    stages: list[StagePlan] = field(default_factory=list)
    stage_statuses: dict[str, StageStatusRecord] = field(default_factory=dict)

    # Results
    stage_results: dict[str, dict[str, Any]] = field(default_factory=dict)
    error: str | None = None

    # Audit linkage
    audit_event_ids: list[str] = field(default_factory=list)

    @property
    def is_active(self) -> bool:
        """Check if operation is still active (not finished)."""
        return self.state in (
            OperationState.CREATED,
            OperationState.RUNNING,
            OperationState.PAUSED,
            OperationState.ROLLING_BACK,
        )

    @property
    def is_expired(self) -> bool:
        """Check if plan has expired based on expires_at."""
        if not self.expires_at:
            return False
        try:
            expiry = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
            return datetime.now(timezone.utc) > expiry
        except (ValueError, TypeError):
            return False

    @property
    def current_stage(self) -> str | None:
        """Get the name of the currently running stage, if any."""
        for name, status in self.stage_statuses.items():
            if status.state == StageState.RUNNING.value:
                return name
        return None

    @property
    def next_stage(self) -> str | None:
        """Get the name of the next pending stage, if any."""
        for stage in self.stages:
            status = self.stage_statuses.get(stage.name)
            if status and status.state in (
                StageState.PENDING.value,
                StageState.WAITING_APPROVAL.value,
            ):
                return stage.name
        return None

    @property
    def completed_stages(self) -> list[str]:
        """Get list of completed stage names."""
        return [
            name
            for name, status in self.stage_statuses.items()
            if status.state == StageState.COMPLETED.value
        ]

    @property
    def failed_stages(self) -> list[str]:
        """Get list of failed stage names."""
        return [
            name
            for name, status in self.stage_statuses.items()
            if status.state == StageState.FAILED.value
        ]

    def get_stage_status(self, stage_name: str) -> StageStatusRecord | None:
        """Get status record for a specific stage."""
        return self.stage_statuses.get(stage_name)

    def get_stage_result(self, stage_name: str) -> dict[str, Any] | None:
        """Get result data from a specific stage."""
        return self.stage_results.get(stage_name)

    def add_audit_event(self, event_id: str) -> None:
        """Link an audit event to this plan."""
        if event_id not in self.audit_event_ids:
            self.audit_event_ids.append(event_id)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary for storage."""
        return {
            "plan_id": self.plan_id,
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "schema_version": self.schema_version,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "expires_at": self.expires_at,
            "environment": self.environment,
            "actor": self.actor,
            "targets": self.targets,
            "metadata": self.metadata,
            "dry_run": self.dry_run,
            "protection_level": self.protection_level,
            "protection_settings": self.protection_settings,
            "state": self.state.value,
            "stages": [s.to_dict() for s in self.stages],
            "stage_statuses": {
                name: status.to_dict() for name, status in self.stage_statuses.items()
            },
            "stage_results": self.stage_results,
            "error": self.error,
            "audit_event_ids": self.audit_event_ids,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OperationPlan:
        """Deserialize from dictionary."""
        stages = [StagePlan.from_dict(s) for s in data.get("stages", [])]
        stage_statuses = {
            name: StageStatusRecord.from_dict(status_data)
            for name, status_data in data.get("stage_statuses", {}).items()
        }

        return cls(
            plan_id=data["plan_id"],
            operation_id=data["operation_id"],
            operation_type=data["operation_type"],
            schema_version=data.get("schema_version", "1.0"),
            created_at=data.get("created_at", _now_iso()),
            started_at=data.get("started_at"),
            completed_at=data.get("completed_at"),
            expires_at=data.get("expires_at"),
            environment=data.get("environment", "unknown"),
            actor=data.get("actor", "unknown"),
            targets=data.get("targets", []),
            metadata=data.get("metadata", {}),
            dry_run=data.get("dry_run", False),
            protection_level=data.get("protection_level", "development"),
            protection_settings=data.get("protection_settings", {}),
            state=OperationState(data.get("state", "created")),
            stages=stages,
            stage_statuses=stage_statuses,
            stage_results=data.get("stage_results", {}),
            error=data.get("error"),
            audit_event_ids=data.get("audit_event_ids", []),
        )

    def to_json(self, indent: int = 2) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, default=str)

    @classmethod
    def from_json(cls, json_str: str) -> OperationPlan:
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))

    def to_summary(self) -> dict[str, Any]:
        """Get a summary view of the plan for display."""
        return {
            "plan_id": self.plan_id,
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "state": self.state.value,
            "environment": self.environment,
            "actor": self.actor,
            "targets": self.targets,
            "dry_run": self.dry_run,
            "protection_level": self.protection_level,
            "created_at": self.created_at,
            "current_stage": self.current_stage,
            "next_stage": self.next_stage,
            "completed_stages": self.completed_stages,
            "failed_stages": self.failed_stages,
            "error": self.error,
        }
