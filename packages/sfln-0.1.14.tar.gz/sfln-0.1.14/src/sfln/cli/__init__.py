"""CLI generation and utilities for Safeline."""

from sfln.cli.formatting import format_bytes, format_template, print_structured_output
from sfln.cli.generator import create_multi_operation_cli, generate_cli
from sfln.cli.narrative import Narrative, StageNarratives
from sfln.cli.output import (
    OutputFormatter,
    log_error,
    log_info,
    log_success,
    log_warning,
    output_json,
    output_table,
)
from sfln.cli.runner import run_stage_command

__all__ = [
    # Narrative-based CLI
    "Narrative",
    "StageNarratives",
    "format_bytes",
    "format_template",
    "print_structured_output",
    "run_stage_command",
    # CLI generation
    "OutputFormatter",
    "create_multi_operation_cli",
    "generate_cli",
    # Logging utilities
    "log_error",
    "log_info",
    "log_success",
    "log_warning",
    # Output utilities
    "output_json",
    "output_table",
]
