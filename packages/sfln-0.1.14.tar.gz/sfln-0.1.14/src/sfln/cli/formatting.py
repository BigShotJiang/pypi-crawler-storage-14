"""Output formatting utilities for CLI.

This module provides utilities for formatting and printing structured
narrative output in a consistent way across all Safeline-based CLIs.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any


def format_bytes(num_bytes: int) -> str:
    """Format bytes as human-readable string.

    Converts byte counts to human-readable format with appropriate units.

    Args:
        num_bytes: Number of bytes to format

    Returns:
        Formatted string (e.g., "1.5 GB", "42 KB", "0 B")

    Examples:
        >>> format_bytes(0)
        '0 B'
        >>> format_bytes(1024)
        '1.0 KB'
        >>> format_bytes(1536)
        '1.5 KB'
        >>> format_bytes(1048576)
        '1.0 MB'
        >>> format_bytes(1073741824)
        '1.0 GB'
    """
    if num_bytes == 0:
        return "0 B"

    # Handle negative bytes
    is_negative = num_bytes < 0
    size: float = abs(num_bytes)

    for unit in ["B", "KB", "MB", "GB", "TB", "PB"]:
        if size < 1024:
            if unit == "B":
                result = f"{int(size)} {unit}"
            else:
                result = f"{size:.1f} {unit}"
            return f"-{result}" if is_negative else result
        size /= 1024

    # If we get here, it's huge (>1024 PB)
    result = f"{size:.1f} EB"
    return f"-{result}" if is_negative else result


def print_structured_output(
    *,
    verdict: str,
    scenario: str,
    summary: str,
    what_happened: str,
    why_it_matters: str,
    next_steps: list[str],
    additional_info: dict[str, str] | None = None,
) -> None:
    """Print structured narrative output with consistent formatting.

    This function provides a consistent way to display narrative output
    across all Safeline-based CLIs. It uses colors when Click is available
    but falls back gracefully to plain text.

    Args:
        verdict: Status indicator (e.g., "SUCCESS", "ERROR", "REQUIRES_APPROVAL")
        scenario: Brief context (e.g., "operation op-123")
        summary: One-line summary of outcome
        what_happened: Detailed explanation
        why_it_matters: Context about importance
        next_steps: List of suggested next actions
        additional_info: Optional dict of key-value pairs to display

    Example:
        ```python
        print_structured_output(
            verdict="SUCCESS",
            scenario="operation op-123",
            summary="deployment completed",
            what_happened="Deployed version 1.2.3 to production",
            why_it_matters="New version is now live and serving traffic.",
            next_steps=["Monitor metrics", "Run smoke tests"],
            additional_info={"Operation ID": "op-123", "Environment": "production"}
        )
        ```

    Output (with colors):
        [SUCCESS] operation op-123: deployment completed

        What happened:
          Deployed version 1.2.3 to production

        Why it matters:
          New version is now live and serving traffic.

        Next steps:
          1. Monitor metrics
          2. Run smoke tests

        Details:
          Operation ID: op-123
          Environment: production
    """
    # Try to import Click for colored output
    try:
        import click

        has_click = True
    except ImportError:
        has_click = False

    # Verdict-based colors
    verdict_colors = {
        "SUCCESS": "green",
        "ALLOWED": "green",
        "DENIED": "red",
        "ERROR": "red",
        "REQUIRES_APPROVAL": "yellow",
        "WARNING": "yellow",
        "INFO": "blue",
    }
    color = verdict_colors.get(verdict.upper(), "white")

    # Header line
    echo: Callable[..., None]
    if has_click:
        click.secho(f"\n[{verdict}] {scenario}: {summary}", fg=color, bold=True)
        echo = click.echo
    else:
        print(f"\n[{verdict}] {scenario}: {summary}")
        echo = print

    # What happened
    echo("")
    echo("What happened:")
    echo(f"  {what_happened}")

    # Why it matters
    echo("")
    echo("Why it matters:")
    echo(f"  {why_it_matters}")

    # Next steps
    if next_steps:
        echo("")
        echo("Next steps:")
        for i, step in enumerate(next_steps, 1):
            echo(f"  {i}. {step}")

    # Additional info
    if additional_info:
        echo("")
        echo("Details:")
        for key, value in additional_info.items():
            echo(f"  {key}: {value}")

    echo("")


def format_template(template: str, data: dict[str, Any]) -> str:
    """Format a template string with data values.

    Replaces {placeholders} in the template with values from the data dict.
    Handles missing keys gracefully by leaving the placeholder unchanged.

    Args:
        template: Template string with {placeholders}
        data: Dictionary of placeholder values

    Returns:
        Formatted string with placeholders replaced

    Examples:
        >>> format_template("Hello {name}", {"name": "World"})
        'Hello World'
        >>> format_template("Count: {count}", {"count": 42})
        'Count: 42'
        >>> format_template("Missing {key}", {})
        'Missing {key}'
    """
    try:
        # Filter to only string/int/float values that can be formatted
        format_data = {k: v for k, v in data.items() if isinstance(v, (str, int, float, bool))}
        return template.format(**format_data)
    except (KeyError, ValueError):
        # If formatting fails, return original template
        return template
