"""CLI generator for Safeline operations.

Automatically generates Click CLI commands from Operation definitions.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from sfln.cli.output import OutputFormatter
from sfln.core.pipeline import Safeline
from sfln.core.result import OperationState
from sfln.exceptions import ApprovalRequiredError, OperationNotFoundError

if TYPE_CHECKING:
    from sfln.core.operation import Operation

try:
    import click

    HAS_CLICK = True
except ImportError:
    HAS_CLICK = False


def generate_cli(
    operation_class: type[Operation],
    safeline: Safeline,
    name: str | None = None,
) -> Any:
    """Generate a Click CLI group for an Operation.

    Creates commands for:
    - run: Run all stages
    - create: Create operation without running
    - stage <name>: Run specific stage
    - approve <stage>: Approve a stage
    - status: Check operation status
    - rollback: Rollback operation
    - list: List operations

    Args:
        operation_class: The Operation subclass to generate CLI for.
        safeline: The Safeline instance to use.
        name: CLI group name (defaults to operation.name).

    Returns:
        A Click group with generated commands.

    Raises:
        ImportError: If Click is not installed.
    """
    if not HAS_CLICK:
        raise ImportError("Click is required for CLI generation: pip install click")

    cli_name = name or operation_class.name

    @click.group(name=cli_name)
    @click.option("--json", "json_output", is_flag=True, help="Output as JSON")
    @click.pass_context
    def cli(ctx: click.Context, json_output: bool) -> None:
        """Auto-generated CLI for {name} operations."""
        ctx.ensure_object(dict)
        ctx.obj["json_output"] = json_output
        ctx.obj["sfln"] = safeline
        ctx.obj["operation_class"] = operation_class

    cli.__doc__ = f"Auto-generated CLI for {cli_name} operations."

    # Generate 'run' command
    @cli.command()
    @click.argument("targets", nargs=-1)
    @click.option("--dry-run", is_flag=True, help="Simulate without making changes")
    @click.option("--actor", default="cli", help="Actor identity")
    @click.option("--environment", default=None, help="Environment name")
    @click.pass_context
    def run(
        ctx: click.Context,
        targets: tuple[str, ...],
        dry_run: bool,
        actor: str,
        environment: str | None,
    ) -> None:
        """Run operation on targets."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        sl = ctx.obj["sfln"]
        op_class = ctx.obj["operation_class"]

        if not targets:
            fmt.error("No targets specified")
            raise SystemExit(1)

        try:
            operation = op_class(targets=list(targets))
            fmt.log(f"Running {op_class.name} on {len(targets)} target(s)")

            result = sl.run(
                operation,
                actor=actor,
                environment=environment,
                dry_run=dry_run,
            )

            if result.success:
                fmt.success(f"Operation {result.operation_id} completed successfully")
            else:
                fmt.error(f"Operation {result.operation_id} failed: {result.error}")

            fmt.output(result.to_dict())

            if not result.success:
                raise SystemExit(1)

        except ApprovalRequiredError as e:
            fmt.warning(f"Operation paused: {e}")
            raise SystemExit(2) from None
        except Exception as e:
            fmt.error(str(e))
            raise SystemExit(1) from None

    # Generate 'create' command
    @cli.command()
    @click.argument("targets", nargs=-1)
    @click.option("--dry-run", is_flag=True, help="Simulate without making changes")
    @click.option("--actor", default="cli", help="Actor identity")
    @click.option("--environment", default=None, help="Environment name")
    @click.pass_context
    def create(
        ctx: click.Context,
        targets: tuple[str, ...],
        dry_run: bool,
        actor: str,
        environment: str | None,
    ) -> None:
        """Create operation without running."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        sl = ctx.obj["sfln"]
        op_class = ctx.obj["operation_class"]

        if not targets:
            fmt.error("No targets specified")
            raise SystemExit(1)

        try:
            operation = op_class(targets=list(targets))
            operation_id = sl.create(
                operation,
                actor=actor,
                environment=environment,
                dry_run=dry_run,
            )

            fmt.success(f"Created operation: {operation_id}")
            fmt.output(
                {
                    "operation_id": operation_id,
                    "targets": list(targets),
                    "stages": [s.name for s in operation.stages],
                }
            )

        except Exception as e:
            fmt.error(str(e))
            raise SystemExit(1) from None

    # Generate 'stage' command for running individual stages
    @cli.command()
    @click.argument("operation_id")
    @click.argument("stage_name")
    @click.pass_context
    def stage(ctx: click.Context, operation_id: str, stage_name: str) -> None:
        """Run a specific stage of an operation."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        sl = ctx.obj["sfln"]

        try:
            fmt.log(f"Running stage '{stage_name}' for operation {operation_id}")
            result = sl.run_stage(operation_id, stage_name)

            if result.success:
                fmt.success(f"Stage '{stage_name}' completed")
            else:
                fmt.error(f"Stage '{stage_name}' failed: {result.error}")

            fmt.output(result.to_dict())

            if not result.success:
                raise SystemExit(1)

        except ApprovalRequiredError as e:
            fmt.warning(f"Stage requires approval: {e}")
            fmt.output({"status": "waiting_approval", "stage": stage_name})
            raise SystemExit(2) from None
        except Exception as e:
            fmt.error(str(e))
            raise SystemExit(1) from None

    # Generate 'approve' command
    @cli.command()
    @click.argument("operation_id")
    @click.argument("stage_name")
    @click.option("--approver", default="cli", help="Approver identity")
    @click.pass_context
    def approve(
        ctx: click.Context,
        operation_id: str,
        stage_name: str,
        approver: str,
    ) -> None:
        """Approve a stage waiting for approval."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        sl = ctx.obj["sfln"]

        try:
            sl.approve(operation_id, stage_name, approver=approver)
            fmt.success(f"Stage '{stage_name}' approved by {approver}")
            fmt.output(
                {
                    "operation_id": operation_id,
                    "stage": stage_name,
                    "approved_by": approver,
                }
            )

        except Exception as e:
            fmt.error(str(e))
            raise SystemExit(1) from None

    # Generate 'status' command
    @cli.command()
    @click.argument("operation_id")
    @click.pass_context
    def status(ctx: click.Context, operation_id: str) -> None:
        """Check status of an operation."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        sl = ctx.obj["sfln"]

        try:
            status_data = sl.get_status(operation_id)
            fmt.output(status_data)

        except OperationNotFoundError:
            fmt.error(f"Operation not found: {operation_id}")
            raise SystemExit(1) from None
        except Exception as e:
            fmt.error(str(e))
            raise SystemExit(1) from None

    # Generate 'rollback' command
    @cli.command()
    @click.argument("operation_id")
    @click.pass_context
    def rollback(ctx: click.Context, operation_id: str) -> None:
        """Rollback an operation."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        sl = ctx.obj["sfln"]

        try:
            fmt.log(f"Rolling back operation {operation_id}")
            result = sl.rollback(operation_id)

            if result.state == OperationState.ROLLED_BACK:
                fmt.success(f"Operation {operation_id} rolled back")
            else:
                fmt.error(f"Rollback failed: {result.error}")

            fmt.output(result.to_dict())

            if result.state != OperationState.ROLLED_BACK:
                raise SystemExit(1)

        except Exception as e:
            fmt.error(str(e))
            raise SystemExit(1) from None

    # Generate 'stages' command to list stages
    @cli.command()
    @click.pass_context
    def stages(ctx: click.Context) -> None:
        """List stages for this operation type."""
        fmt = OutputFormatter(ctx.obj["json_output"])
        op_class = ctx.obj["operation_class"]

        stages_data = []
        for s in op_class.stages:
            stages_data.append(
                {
                    "name": s.name,
                    "required": s.required,
                    "needs_approval": s.needs_approval,
                    "needs_lock": s.needs_lock,
                    "reversible": s.reversible,
                    "description": s.description,
                }
            )

        fmt.output({"stages": stages_data})

    # Generate 'shell' command for interactive mode
    @cli.command()
    @click.pass_context
    def shell(ctx: click.Context) -> None:
        """Start interactive shell."""
        from sfln.cli.shell import SafelineShell

        sl = ctx.obj["sfln"]
        op_class = ctx.obj["operation_class"]
        json_output = ctx.obj["json_output"]

        sh = SafelineShell(sl, operation_class=op_class, json_output=json_output)
        sh.cmdloop()

    return cli


def create_multi_operation_cli(
    operations: dict[str, type[Operation]],
    safeline: Safeline,
    name: str = "sfln",
) -> Any:
    """Create a CLI that supports multiple operation types.

    Args:
        operations: Dict mapping names to Operation classes.
        safeline: The Safeline instance.
        name: Name for the CLI group.

    Returns:
        A Click group with subgroups for each operation.
    """
    if not HAS_CLICK:
        raise ImportError("Click is required for CLI generation: pip install click")

    @click.group(name=name)
    def cli() -> None:
        """Safeline - Safety-critical operations framework."""
        pass

    for op_name, op_class in operations.items():
        op_cli = generate_cli(op_class, safeline, name=op_name)
        cli.add_command(op_cli)

    # Add shell command for multi-operation CLI
    @cli.command()
    @click.option("--json", "json_output", is_flag=True, help="Output as JSON")
    def shell(json_output: bool) -> None:
        """Start interactive shell with all operations."""
        from sfln.cli.shell import SafelineShell

        sh = SafelineShell(safeline, operations=operations, json_output=json_output)
        sh.cmdloop()

    return cli
