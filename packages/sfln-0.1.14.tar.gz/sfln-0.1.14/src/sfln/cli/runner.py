"""Generic stage runner for narrative-based CLI commands.

This module provides a generic runner that handles the common pattern
of running a stage and outputting narrative or JSON results.
"""

from __future__ import annotations

import sys
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from sfln.cli.formatting import format_bytes, format_template, print_structured_output
from sfln.cli.narrative import ClickContext, Narrative, StageNarratives

if TYPE_CHECKING:
    from sfln import OperationResult, Safeline


def run_stage_command(
    ctx: ClickContext,
    operation_id: str,
    narratives: StageNarratives,
    *,
    safeline: Safeline,
    extract_data: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
    pre_run: Callable[[Any], bool | None] | None = None,
    build_extra_info: Callable[[dict[str, Any], dict[str, Any]], dict[str, str]] | None = None,
) -> None:
    """Generic runner for stage commands.

    Handles the common pattern of:
    1. Get operation details
    2. Run a stage
    3. Output JSON or narrative based on result
    4. Exit with appropriate code

    This eliminates ~140 lines of boilerplate per command, reducing commands
    to ~10 lines of narrative definitions + thin command wrapper.

    Args:
        ctx: Click context (must have ctx.obj["json_output"])
        operation_id: Operation ID to run stage on
        narratives: Narrative templates for this stage
        safeline: Safeline instance to use
        extract_data: Optional callback to extract custom data from stage results.
                     Called with full stage_results dict, should return dict of
                     additional data to make available in templates.
        pre_run: Optional callback before running. Called with operation details.
                Return False to abort without running stage.
        build_extra_info: Optional callback to build additional info dict.
                         Called with (data, stage_data), should return dict
                         of key-value pairs to display in "Details" section.

    Example:
        ```python
        # Define narratives once
        VALIDATE = StageNarratives(
            stage_name="validate",
            action_verb="Validating",
            success=Narrative(
                verdict="ALLOWED",
                summary="approved by safety policy",
                what_happened="Operation {operation_id} validated successfully.",
                why_it_matters="Safety checks passed.",
                next_steps=["Run stage {operation_id}"],
            ),
        )

        # Thin command wrapper
        @click.command()
        @click.argument("operation_id")
        @click.pass_context
        def validate(ctx, operation_id):
            helper = SafelineHelper()
            run_stage_command(ctx, operation_id, VALIDATE, safeline=helper.safeline)
        ```

    Exit codes:
        0: Success
        1: Failure or error
    """
    # Try to import Click for echo function
    try:
        import click

        echo = click.echo
    except ImportError:
        echo = print  # type: ignore[assignment]

    # Check for JSON output mode
    json_output = ctx.obj.get("json_output", False)
    env_name = safeline._environment

    try:
        # Log what we're doing (unless in JSON mode)
        if not json_output:
            echo(f"[INFO] {narratives.action_verb} operation: {operation_id}")

        # Get operation details
        details = safeline.get_operation(operation_id)
        if details is None:
            echo(f"[ERROR] Operation not found: {operation_id}")
            sys.exit(1)

        # Pre-run callback (can abort)
        if pre_run and pre_run(details) is False:
            return

        # Run the stage - returns StageResult
        stage_result = safeline.run_stage(operation_id, narratives.stage_name)

        # Get full operation details (which has stage_results) after running
        details_after = safeline.get_operation(operation_id)

        # Create a result-like object with stage_results for compatibility
        class _ResultWrapper:
            """Wrapper to make stage result compatible with output handlers."""

            def __init__(self, stage_result: Any, details: Any) -> None:
                self.success: bool = stage_result.success
                self.error: str | None = stage_result.error
                self.stage_results: dict[str, Any] = details.stage_results if details else {}

        result = _ResultWrapper(stage_result, details_after)

        # Handle JSON output mode
        if json_output:
            _handle_json_output(echo, operation_id, narratives.stage_name, result)  # type: ignore[arg-type]
            return

        # Extract and format narrative output
        _handle_narrative_output(
            echo=echo,
            operation_id=operation_id,
            env_name=env_name,
            narratives=narratives,
            result=result,  # type: ignore[arg-type]
            extract_data=extract_data,
            build_extra_info=build_extra_info,
        )

    except Exception as e:
        echo(f"[ERROR] {narratives.action_verb} failed: {e}")
        sys.exit(1)


def _handle_json_output(
    echo: Callable[[str], None],
    operation_id: str,
    stage_name: str,
    result: OperationResult,
) -> None:
    """Handle JSON output mode."""
    import json

    stage_data = result.stage_results.get(stage_name, {})

    output = {
        "operation_id": operation_id,
        "success": result.success,
        "stage": stage_name,
        **stage_data,
    }

    echo(json.dumps(output, indent=2))

    if not result.success:
        sys.exit(1)


def _handle_narrative_output(
    echo: Callable[[str], None],
    operation_id: str,
    env_name: str,
    narratives: StageNarratives,
    result: OperationResult,
    extract_data: Callable[[dict[str, Any]], dict[str, Any]] | None,
    build_extra_info: Callable[[dict[str, Any], dict[str, Any]], dict[str, str]] | None,
) -> None:
    """Handle narrative output mode."""
    # Extract stage data
    stage_data = result.stage_results.get(narratives.stage_name, {})
    plan_data = result.stage_results.get("plan", {})

    # Build standard data dict for templates
    file_count = plan_data.get("file_count", 0)
    total_bytes = plan_data.get("total_bytes", 0)

    data: dict[str, Any] = {
        "operation_id": operation_id,
        "environment": env_name,
        "file_count": file_count,
        "total_bytes": total_bytes,
        "total_size": format_bytes(total_bytes),
        "stage_data": stage_data,
    }

    # Custom data extraction
    if extract_data:
        data.update(extract_data(result.stage_results))

    # Build additional info section
    extra_info: dict[str, str] = {
        "Operation ID": operation_id,
        "Environment": env_name,
    }

    if build_extra_info:
        extra_info.update(build_extra_info(data, stage_data))

    # Determine which narrative to use
    narr = _select_narrative(narratives, result, stage_data, operation_id)

    # Format and output narrative
    print_structured_output(
        verdict=narr.verdict,
        scenario=f"operation {operation_id}",
        summary=narr.summary,
        what_happened=format_template(narr.what_happened, data),
        why_it_matters=narr.why_it_matters,
        next_steps=[format_template(s, data) for s in narr.next_steps],
        additional_info=extra_info,
    )

    if not result.success:
        sys.exit(1)


def _select_narrative(
    narratives: StageNarratives,
    result: OperationResult,
    stage_data: dict[str, Any],
    operation_id: str,
) -> Narrative:
    """Select appropriate narrative based on result."""
    # Check for approval required
    requires_approval = stage_data.get("requires_approval", False)
    verdict = stage_data.get("verdict", "")

    if (requires_approval or verdict == "require_approval") and narratives.approval_required:
        return narratives.approval_required

    # Success path
    if result.success:
        return narratives.success

    # Failure path - use custom or default
    if narratives.failure:
        return narratives.failure

    # Default failure narrative
    return Narrative(
        verdict="ERROR",
        summary="failed",
        what_happened=f"Operation failed: {result.error or 'Unknown error'}",
        why_it_matters="The operation could not complete successfully.",
        next_steps=[f"Check status: status {operation_id}"],
    )
