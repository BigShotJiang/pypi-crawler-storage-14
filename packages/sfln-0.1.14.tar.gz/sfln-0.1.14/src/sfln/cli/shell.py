"""Interactive shell for Safeline operations.

Provides a rich, workflow-aware REPL interface with:
- Environment and protection level display
- Multi-line contextual prompt showing operation state
- Detailed output with explanations and next steps
- Near-miss recording on shell exit
- Tab completion for commands and arguments
"""

from __future__ import annotations

import cmd
import shlex
from datetime import datetime
from typing import TYPE_CHECKING

# Import readline for tab completion support
try:
    import readline
except ImportError:
    readline = None  # type: ignore[assignment]

from sfln.cli.output import OutputFormatter
from sfln.core.result import OperationState
from sfln.core.stage import StageState
from sfln.exceptions import ApprovalRequiredError, OperationNotFoundError
from sfln.protection.environment import detect_environment
from sfln.protection.levels import PROTECTION_LEVELS

if TYPE_CHECKING:
    from sfln.core.operation import Operation
    from sfln.core.pipeline import Safeline
    from sfln.protection.levels import ProtectionLevel


class SafelineShell(cmd.Cmd):
    """Interactive shell for Safeline operations.

    Provides a rich REPL interface for managing operations interactively
    with environment awareness, workflow tracking, and detailed output.

    Example:
        shell = SafelineShell(safeline, operation_class)
        shell.cmdloop()

    Or with multiple operations:
        shell = SafelineShell(safeline, operations={"deploy": DeployOp, "migrate": MigrateOp})
        shell.cmdloop()
    """

    def __init__(
        self,
        safeline: Safeline,
        operation_class: type[Operation] | None = None,
        operations: dict[str, type[Operation]] | None = None,
        json_output: bool = False,
    ) -> None:
        """Initialize the shell.

        Args:
            safeline: The Safeline instance to use.
            operation_class: Single operation class (for single-operation shells).
            operations: Dict of operation classes (for multi-operation shells).
            json_output: If True, output JSON instead of human-readable text.
        """
        super().__init__()
        self._safeline = safeline
        self._operation_class = operation_class
        self._operations = operations or {}
        self._fmt = OutputFormatter(json_output)
        self._current_op_id: str | None = None
        self._current_op_type: str | None = None
        self._session_start = datetime.now()
        self._operations_created: list[str] = []
        self._operations_completed: list[str] = []

        if operation_class:
            self._operations[operation_class.name] = operation_class
            self._current_op_type = operation_class.name

        # Get environment and protection info
        self._env = detect_environment()
        self._protection = self._get_protection_level()

        # Configure readline for better tab completion
        if readline is not None:
            # Set completer delimiters - remove '-' so op-ids complete properly
            readline.set_completer_delims(" \t\n")

        # Set intro with rich context
        self.intro = self._build_welcome_message()
        # Set initial prompt
        self.prompt = self._build_prompt()

    def precmd(self, line: str) -> str:
        """Called before each command - update prompt."""
        self.prompt = self._build_prompt()
        return line

    def _run_stage_by_name(self, stage_name: str) -> bool:
        """Run a stage by name. Returns True if handled."""
        if not self._current_op_id:
            self._fmt.error("No operation selected. Use 'create' first.")
            return True

        # Check if this is a valid stage name
        stage_names = self._get_stage_names()
        if stage_name not in stage_names:
            return False

        # Run the stage using existing do_stage logic
        self.do_stage(stage_name)
        return True

    def _get_protection_level(self) -> ProtectionLevel:
        """Get protection level for current environment."""
        env_name = self._env.name.lower()
        # Map environment to protection level
        if env_name in PROTECTION_LEVELS:
            return PROTECTION_LEVELS[env_name]
        elif env_name in ("prod", "production"):
            return PROTECTION_LEVELS["production"]
        elif env_name in ("stg", "stage", "staging"):
            return PROTECTION_LEVELS["staging"]
        elif env_name in ("dev", "development"):
            return PROTECTION_LEVELS["development"]
        return PROTECTION_LEVELS.get("development", PROTECTION_LEVELS["testing"])

    def _build_welcome_message(self) -> str:
        """Build the rich welcome message."""
        lines = [
            "",
            "=" * 60,
            "Safeline Interactive Shell",
            "=" * 60,
            "",
            f"Environment:       {self._env.name}",
            f"Protection Level:  {self._protection.name}",
            "",
            "Protection Settings:",
        ]

        # Show relevant protection settings
        settings = []
        if self._protection.require_approval:
            settings.append("  - Approval required for operations")
        if self._protection.require_audit:
            settings.append("  - Audit logging enabled")
        if self._protection.require_backup:
            settings.append("  - Backups required before changes")
        if not self._protection.allow_force:
            settings.append("  - Force mode disabled")
        if self._protection.simulation_only:
            settings.append("  - SIMULATION ONLY (no real changes)")
        if self._protection.max_targets > 0:
            settings.append(f"  - Max targets: {self._protection.max_targets}")

        if settings:
            lines.extend(settings)
        else:
            lines.append("  - Minimal restrictions")

        lines.extend(
            [
                "",
                "Available Operations:",
            ]
        )

        if self._operations:
            for name, op_class in self._operations.items():
                stage_count = len(op_class.stages)
                lines.append(f"  - {name} ({stage_count} stages)")
        else:
            lines.append("  (none registered)")

        lines.extend(
            [
                "",
                "Type 'help' for commands, 'quit' to exit.",
                "-" * 60,
                "",
                "Next steps:",
            ]
        )

        # Show contextual next steps
        if self._operations:
            op_names = list(self._operations.keys())
            if len(op_names) == 1:
                op_name = op_names[0]
                op_class = self._operations[op_name]
                stage_names = [s.name for s in op_class.stages]
                stages_str = ", ".join(stage_names[:3])
                if len(stage_names) > 3:
                    stages_str += ", ..."
                lines.append(f"  1. Run 'create <targets...>' to create a {op_name} operation")
                lines.append(f"  2. Type stage names directly: {stages_str}")
                lines.append("  3. Or run 'run <targets...>' to execute all stages")
            else:
                lines.append("  1. Run 'operations' to see available operation types")
                lines.append("  2. Run 'create <operation> <targets...>' to create an operation")
                lines.append("  3. Type stage names directly to execute them")
        else:
            lines.append("  (no operations registered)")

        lines.append("")

        return "\n".join(lines)

    def _build_prompt(self) -> str:
        """Build multi-line prompt showing current state."""
        # Base prompt with environment and protection
        base = f"safeline:{self._env.name}[{self._protection.name}]"

        if not self._current_op_id:
            return f"{base}\n> "

        # Get current operation state
        try:
            status = self._safeline.get_status(self._current_op_id)
            state = status.get("state", "unknown")
            current_stage = status.get("current_stage", "none")
            stages = status.get("stages", {})

            # Find next stage
            next_stage = self._find_next_stage(stages)

            lines = [
                base,
                f"operation: {self._current_op_id}",
                f"state: {state}",
            ]

            if current_stage and current_stage != "none":
                lines.append(f"current: {current_stage}")
            if next_stage:
                lines.append(f"next: {next_stage}")

            lines.append("> ")
            return "\n".join(lines)

        except Exception:
            return f"{base}\noperation: {self._current_op_id}\n> "

    def _find_next_stage(self, stages: dict[str, object]) -> str | None:
        """Find the next stage to run."""
        for stage_name, stage_info in stages.items():
            # Handle both dict (from get_status) and string formats
            if isinstance(stage_info, dict):
                state = stage_info.get("state", "")
            else:
                state = str(stage_info)

            if state in (
                StageState.PENDING.value,
                "pending",
                StageState.WAITING_APPROVAL.value,
                "waiting_approval",
            ):
                return stage_name
        return None

    def _parse_args(self, line: str) -> list[str]:
        """Parse command line arguments."""
        try:
            return shlex.split(line)
        except ValueError:
            return line.split()

    def _get_operation_class(self, name: str | None = None) -> type[Operation] | None:
        """Get operation class by name or default.

        If name is provided and matches an operation, return it.
        Otherwise, fall back to default operation class or single operation.
        """
        # If name matches an operation, use it
        if name and name in self._operations:
            return self._operations[name]
        # Fall back to default operation class
        if self._operation_class:
            return self._operation_class
        # Fall back to single operation if only one exists
        if len(self._operations) == 1:
            return next(iter(self._operations.values()))
        return None

    def _is_operation_name(self, name: str) -> bool:
        """Check if name is a registered operation name."""
        return name in self._operations

    def _output_result(
        self,
        what_happened: str,
        why_it_matters: str,
        next_steps: list[str],
        data: dict | None = None,
    ) -> None:
        """Output a rich result with context."""
        if self._fmt.json_output:
            self._fmt.output(
                {
                    "what_happened": what_happened,
                    "why_it_matters": why_it_matters,
                    "next_steps": next_steps,
                    "data": data or {},
                }
            )
        else:
            print()
            print("What happened:")
            print(f"  {what_happened}")
            print()
            print("Why it matters:")
            print(f"  {why_it_matters}")
            print()
            print("Next steps:")
            for i, step in enumerate(next_steps, 1):
                print(f"  {i}. {step}")
            print()

    # -------------------------------------------------------------------------
    # Tab completion methods
    # -------------------------------------------------------------------------

    def _get_stage_names(self) -> list[str]:
        """Get stage names for current operation type."""
        op_class = self._get_operation_class(self._current_op_type)
        if op_class:
            return [s.name for s in op_class.stages]
        return []

    def _get_approval_stage_names(self) -> list[str]:
        """Get stage names that need approval."""
        op_class = self._get_operation_class(self._current_op_type)
        if op_class:
            return [s.name for s in op_class.stages if s.needs_approval]
        return []

    def _get_operation_names(self) -> list[str]:
        """Get available operation names."""
        return list(self._operations.keys())

    def _get_operation_ids(self) -> list[str]:
        """Get known operation IDs."""
        # Return operations created in this session
        ids = list(self._operations_created)
        # Also include current operation if set
        if self._current_op_id and self._current_op_id not in ids:
            ids.insert(0, self._current_op_id)
        return ids

    def _complete_from_list(self, text: str, options: list[str]) -> list[str]:
        """Complete text from a list of options."""
        if not text:
            return options
        return [opt for opt in options if opt.startswith(text)]

    def complete_stage(self, text: str, line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for stage command."""
        args = line.split()
        # If we're completing the first argument (stage name)
        if len(args) <= 2:
            return self._complete_from_list(text, self._get_stage_names())
        return []

    def complete_approve(self, text: str, line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for approve command."""
        args = line.split()
        # Complete with stages that need approval
        if len(args) <= 2:
            return self._complete_from_list(text, self._get_approval_stage_names())
        return []

    def complete_stages(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for stages command."""
        return self._complete_from_list(text, self._get_operation_names())

    def complete_create(self, text: str, line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for create command."""
        args = line.split()
        # First argument could be operation name
        if len(args) <= 2:
            return self._complete_from_list(text, self._get_operation_names())
        return []

    def complete_run(self, text: str, line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for run command."""
        args = line.split()
        # First argument could be operation name
        if len(args) <= 2:
            return self._complete_from_list(text, self._get_operation_names())
        return []

    def complete_use(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for use command."""
        return self._complete_from_list(text, self._get_operation_ids())

    def complete_status(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for status command."""
        return self._complete_from_list(text, self._get_operation_ids())

    def complete_rollback(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for rollback command."""
        return self._complete_from_list(text, self._get_operation_ids())

    def complete_resume(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for resume command."""
        return self._complete_from_list(text, self._get_operation_ids())

    def complete_json(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for json command."""
        return self._complete_from_list(text, ["on", "off"])

    def complete_list(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Tab completion for list command."""
        states = ["created", "running", "paused", "completed", "failed", "rolled_back"]
        return self._complete_from_list(text, states)

    def completedefault(self, text: str, _line: str, _begidx: int, _endidx: int) -> list[str]:
        """Default tab completion - suggest next logical step."""
        # Get suggestions based on current state
        suggestions = self._get_next_step_suggestions()
        return self._complete_from_list(text, suggestions)

    def completenames(self, text: str, *ignored: object) -> list[str]:
        """Override to include stage names and next step suggestions."""
        # Get standard command completions
        commands = super().completenames(text, *ignored)

        # Add stage names as valid commands (so you can type 'plan' instead of 'stage plan')
        stage_names = self._get_stage_names()
        all_commands = list(set(commands + stage_names))

        # If no text, also suggest next logical commands
        if not text:
            next_cmds = self._get_next_step_commands()
            # Put suggested commands first
            return next_cmds + [c for c in all_commands if c not in next_cmds]

        # Filter by prefix
        return [c for c in all_commands if c.startswith(text)]

    def _get_next_step_commands(self) -> list[str]:
        """Get the next logical commands based on current state."""
        if not self._current_op_id:
            # No operation - suggest create or run
            return ["create", "run"]

        try:
            status = self._safeline.get_status(self._current_op_id)
            state = status.get("state", "")
            stages = status.get("stages", {})

            # Find next stage or waiting approval stage
            for stage_name, stage_info in stages.items():
                # Extract state from dict or use directly
                if isinstance(stage_info, dict):
                    stage_state = stage_info.get("state", "")
                else:
                    stage_state = str(stage_info)

                if stage_state in ("waiting_approval", StageState.WAITING_APPROVAL.value):
                    return ["approve", stage_name]
                if stage_state in ("pending", StageState.PENDING.value):
                    # Return the stage name directly (e.g., 'plan' not 'stage')
                    return [stage_name]

            # Operation completed or failed
            if state in ("completed", OperationState.COMPLETED.value):
                return ["create", "run"]
            if state in ("failed", OperationState.FAILED.value):
                return ["rollback", "resume"]

        except Exception:
            pass

        return ["status"]

    def _get_next_step_suggestions(self) -> list[str]:
        """Get suggestions for next step based on current operation state."""
        if not self._current_op_id:
            return []

        try:
            status = self._safeline.get_status(self._current_op_id)
            stages = status.get("stages", {})

            # Find stages needing action
            for stage_name, stage_info in stages.items():
                # Extract state from dict or use directly
                if isinstance(stage_info, dict):
                    stage_state = stage_info.get("state", "")
                else:
                    stage_state = str(stage_info)

                if stage_state in ("waiting_approval", StageState.WAITING_APPROVAL.value):
                    return [stage_name]
                if stage_state in ("pending", StageState.PENDING.value):
                    return [stage_name]

        except Exception:
            pass

        return []

    # -------------------------------------------------------------------------
    # Commands
    # -------------------------------------------------------------------------

    def do_operations(self, _line: str) -> None:
        """List available operation types."""
        if not self._operations:
            self._fmt.warning("No operations registered")
            return

        if self._fmt.json_output:
            ops_data = []
            for name, op_class in self._operations.items():
                ops_data.append(
                    {
                        "name": name,
                        "stages": [s.name for s in op_class.stages],
                    }
                )
            self._fmt.output({"operations": ops_data})
        else:
            print("\nAvailable operations:")
            for name, op_class in self._operations.items():
                stages = [s.name for s in op_class.stages]
                print(f"  {name}: {' -> '.join(stages)}")
            print()

    def do_stages(self, line: str) -> None:
        """List stages for an operation type. Usage: stages [operation_name]"""
        args = self._parse_args(line)
        op_name = args[0] if args else None
        op_class = self._get_operation_class(op_name)

        if not op_class:
            self._fmt.error("No operation specified. Usage: stages <operation_name>")
            return

        stages_data: list[dict[str, object]] = []
        for stage in op_class.stages:
            stages_data.append(
                {
                    "name": stage.name,
                    "required": stage.required,
                    "needs_approval": stage.needs_approval,
                    "needs_lock": stage.needs_lock,
                    "reversible": stage.reversible,
                    "timeout": stage.timeout_seconds,
                    "retries": stage.retry_count,
                }
            )

        if self._fmt.json_output:
            self._fmt.output({"operation": op_class.name, "stages": stages_data})
        else:
            print(f"\nStages for {op_class.name}:")
            print("-" * 40)
            for s in stages_data:
                flags = []
                if s["needs_approval"]:
                    flags.append("approval")
                if s["needs_lock"]:
                    flags.append("lock")
                if s["reversible"]:
                    flags.append("reversible")
                if not s["required"]:
                    flags.append("optional")
                flag_str = f" [{', '.join(flags)}]" if flags else ""
                print(f"  {s['name']}{flag_str}")
            print()

    def do_create(self, line: str) -> None:
        """Create an operation. Usage: create [operation_name] <targets...> [--dry-run]"""
        args = self._parse_args(line)
        if not args:
            self._fmt.error("Usage: create [operation_name] <targets...> [--dry-run]")
            return

        dry_run = "--dry-run" in args
        args = [a for a in args if a != "--dry-run"]

        # Determine operation class and targets
        # First arg could be operation name or target
        op_class: type[Operation] | None
        if args and self._is_operation_name(args[0]):
            op_class = self._operations[args[0]]
            targets = args[1:]
        else:
            op_class = self._get_operation_class()
            targets = args

        if not op_class:
            self._fmt.error("No operation specified or found")
            return

        if not targets:
            self._fmt.error("No targets specified")
            return

        try:
            operation = op_class(targets=list(targets))
            op_id = self._safeline.create(operation, dry_run=dry_run)
            self._current_op_id = op_id
            self._current_op_type = op_class.name
            self._operations_created.append(op_id)

            # Find first stage
            first_stage = op_class.stages[0].name if op_class.stages else "none"

            self._output_result(
                what_happened=f"Created operation {op_id} with {len(targets)} target(s)",
                why_it_matters="The operation is now ready to execute. "
                "All stages will run in sequence unless approval is required.",
                next_steps=[
                    f"Run '{first_stage}' to execute the first stage",
                    "Or run 'run' to execute all stages",
                    "Use 'status' to check operation state at any time",
                ],
                data={
                    "operation_id": op_id,
                    "operation_type": op_class.name,
                    "targets": targets,
                    "dry_run": dry_run,
                },
            )
        except Exception as e:
            self._fmt.error(str(e))

    def do_run(self, line: str) -> None:
        """Run an operation. Usage: run [operation_name] <targets...> [--dry-run]"""
        args = self._parse_args(line)
        if not args:
            self._fmt.error("Usage: run [operation_name] <targets...> [--dry-run]")
            return

        dry_run = "--dry-run" in args
        args = [a for a in args if a != "--dry-run"]

        # Determine operation class and targets
        # First arg could be operation name or target
        op_class: type[Operation] | None
        if args and self._is_operation_name(args[0]):
            op_class = self._operations[args[0]]
            targets = args[1:]
        else:
            op_class = self._get_operation_class()
            targets = args

        if not op_class:
            self._fmt.error("No operation specified or found")
            return

        if not targets:
            self._fmt.error("No targets specified")
            return

        try:
            operation = op_class(targets=list(targets))
            self._fmt.log(f"Running {op_class.name} on {len(targets)} target(s)...")
            result = self._safeline.run(operation, dry_run=dry_run)
            self._current_op_id = result.operation_id
            self._current_op_type = op_class.name
            self._operations_created.append(result.operation_id)

            if result.success:
                self._operations_completed.append(result.operation_id)
                self._output_result(
                    what_happened=f"Operation {result.operation_id} completed successfully",
                    why_it_matters="All stages executed without errors. "
                    "The operation achieved its intended outcome.",
                    next_steps=[
                        "Use 'status' to review the final state",
                        "Start a new operation with 'create' or 'run'",
                    ],
                    data=result.to_dict(),
                )
            else:
                self._output_result(
                    what_happened=f"Operation {result.operation_id} failed: {result.error}",
                    why_it_matters="The operation did not complete successfully. "
                    "Some changes may have been made before the failure.",
                    next_steps=[
                        "Use 'status' to see which stages completed",
                        "Run 'rollback' if the operation supports it",
                        "Use 'resume' to retry after fixing the issue",
                    ],
                    data=result.to_dict(),
                )

        except ApprovalRequiredError as e:
            self._output_result(
                what_happened="Operation paused waiting for approval",
                why_it_matters=str(e),
                next_steps=[
                    "Run 'approve <stage_name>' to approve the pending stage",
                    "Then run 'resume' to continue the operation",
                ],
            )
        except Exception as e:
            self._fmt.error(str(e))

    def do_stage(self, line: str) -> None:
        """Run a specific stage. Usage: stage <stage_name> OR just type the stage name directly."""
        args = self._parse_args(line)

        # Handle 'stage' command with no arguments - if there's a stage named 'stage', run it
        if len(args) == 0 and self._current_op_id:
            stage_names = self._get_stage_names()
            if "stage" in stage_names:
                # Run the stage named "stage"
                args = ["stage"]
            else:
                self._fmt.error("Usage: stage <stage_name>")
                return

        if len(args) == 1 and self._current_op_id:
            op_id = self._current_op_id
            stage_name = args[0]
        elif len(args) == 2:
            op_id = args[0]
            stage_name = args[1]
        else:
            self._fmt.error("Usage: stage <stage_name>")
            return

        try:
            self._fmt.log(f"Running stage '{stage_name}'...")
            result = self._safeline.run_stage(op_id, stage_name)

            # Get next stage info
            status = self._safeline.get_status(op_id)
            stages = status.get("stages", {})
            next_stage = self._find_next_stage(stages)

            if result.success:
                next_steps = []
                if next_stage:
                    next_steps.append(f"Run '{next_stage}' to continue")
                else:
                    next_steps.append("All stages complete! Use 'status' to verify")

                self._output_result(
                    what_happened=f"Stage '{stage_name}' completed successfully",
                    why_it_matters="This stage executed without errors and "
                    "the operation can continue to the next stage.",
                    next_steps=next_steps,
                    data=result.to_dict(),
                )
            else:
                self._output_result(
                    what_happened=f"Stage '{stage_name}' failed: {result.error}",
                    why_it_matters="The stage did not complete successfully. "
                    "The operation cannot proceed until this is resolved.",
                    next_steps=[
                        "Fix the underlying issue",
                        "Run 'resume' to retry the failed stage",
                        "Or run 'rollback' to undo completed stages",
                    ],
                    data=result.to_dict(),
                )

        except ApprovalRequiredError as e:
            self._output_result(
                what_happened=f"Stage '{stage_name}' requires approval",
                why_it_matters=str(e),
                next_steps=[
                    f"Run 'approve {stage_name}' to approve this stage",
                    f"Then run 'stage {stage_name}' again to execute it",
                ],
            )
        except Exception as e:
            self._fmt.error(str(e))

    def do_approve(self, line: str) -> None:
        """Approve a stage. Usage: approve <operation_id> <stage_name> [approver] OR approve <stage_name> [approver]"""
        args = self._parse_args(line)

        if len(args) >= 1 and self._current_op_id:
            op_id = self._current_op_id
            stage_name = args[0]
            approver = args[1] if len(args) > 1 else "shell"
        elif len(args) >= 2:
            op_id = args[0]
            stage_name = args[1]
            approver = args[2] if len(args) > 2 else "shell"
        else:
            self._fmt.error("Usage: approve <operation_id> <stage_name> [approver]")
            return

        try:
            self._safeline.approve(op_id, stage_name, approver=approver)
            self._output_result(
                what_happened=f"Stage '{stage_name}' approved by {approver}",
                why_it_matters="The approval requirement has been satisfied. "
                "The stage can now be executed.",
                next_steps=[
                    f"Run '{stage_name}' to execute the approved stage",
                ],
            )
        except Exception as e:
            self._fmt.error(str(e))

    def do_status(self, line: str) -> None:
        """Check operation status. Usage: status [operation_id]"""
        args = self._parse_args(line)
        op_id = args[0] if args else self._current_op_id

        if not op_id:
            self._fmt.error("No operation ID specified. Usage: status <operation_id>")
            return

        try:
            status = self._safeline.get_status(op_id)

            if self._fmt.json_output:
                self._fmt.output(status)
            else:
                print(f"\nOperation: {op_id}")
                print("-" * 50)
                print(f"State: {status.get('state', 'unknown')}")
                print(f"Type: {status.get('operation_type', 'unknown')}")
                if status.get("targets"):
                    print(f"Targets: {', '.join(status['targets'])}")
                print()
                print("Stages:")
                stages = status.get("stages", {})
                for stage_name, stage_info in stages.items():
                    # Extract state from dict or use directly
                    if isinstance(stage_info, dict):
                        state = stage_info.get("state", "unknown")
                    else:
                        state = str(stage_info)

                    marker = "[ ]"
                    if state == "completed":
                        marker = "[x]"
                    elif state == "running":
                        marker = "[>]"
                    elif state == "failed":
                        marker = "[!]"
                    elif state == "waiting_approval":
                        marker = "[?]"
                    print(f"  {marker} {stage_name}: {state}")
                print()

        except OperationNotFoundError:
            self._fmt.error(f"Operation not found: {op_id}")
        except Exception as e:
            self._fmt.error(str(e))

    def do_rollback(self, line: str) -> None:
        """Rollback an operation. Usage: rollback [operation_id]"""
        args = self._parse_args(line)
        op_id = args[0] if args else self._current_op_id

        if not op_id:
            self._fmt.error("No operation ID specified. Usage: rollback <operation_id>")
            return

        try:
            self._fmt.log(f"Rolling back operation {op_id}...")
            result = self._safeline.rollback(op_id)

            if result.state == OperationState.ROLLED_BACK:
                self._output_result(
                    what_happened=f"Operation {op_id} rolled back successfully",
                    why_it_matters="All reversible stages have been undone. "
                    "The system should be back to its previous state.",
                    next_steps=[
                        "Verify the rollback with 'status'",
                        "Create a new operation if needed",
                    ],
                    data=result.to_dict(),
                )
            else:
                self._output_result(
                    what_happened=f"Rollback failed: {result.error}",
                    why_it_matters="The rollback did not complete successfully. "
                    "Manual intervention may be required.",
                    next_steps=[
                        "Check 'status' to see which stages were rolled back",
                        "Manually verify and fix any inconsistencies",
                    ],
                    data=result.to_dict(),
                )
        except Exception as e:
            self._fmt.error(str(e))

    def do_resume(self, line: str) -> None:
        """Resume a failed operation. Usage: resume [operation_id]"""
        args = self._parse_args(line)
        op_id = args[0] if args else self._current_op_id

        if not op_id:
            self._fmt.error("No operation ID specified. Usage: resume <operation_id>")
            return

        try:
            self._fmt.log(f"Resuming operation {op_id}...")
            result = self._safeline.resume(op_id)

            if result.success:
                self._operations_completed.append(op_id)
                self._output_result(
                    what_happened=f"Operation {op_id} completed after resume",
                    why_it_matters="The operation continued from where it left off "
                    "and completed successfully.",
                    next_steps=[
                        "Verify the final state with 'status'",
                        "Start a new operation if needed",
                    ],
                    data=result.to_dict(),
                )
            else:
                self._output_result(
                    what_happened=f"Resume failed: {result.error}",
                    why_it_matters="The operation could not continue successfully. "
                    "The issue that caused the original failure may still exist.",
                    next_steps=[
                        "Check 'status' to see current state",
                        "Fix the underlying issue",
                        "Try 'resume' again or 'rollback'",
                    ],
                    data=result.to_dict(),
                )
        except ApprovalRequiredError as e:
            self._output_result(
                what_happened="Resume paused - approval required",
                why_it_matters=str(e),
                next_steps=[
                    "Run 'approve <stage_name>' for the pending stage",
                    "Then run 'resume' again",
                ],
            )
        except Exception as e:
            self._fmt.error(str(e))

    def do_list(self, line: str) -> None:
        """List operations. Usage: list [state]"""
        args = self._parse_args(line)
        state_filter = None

        if args:
            try:
                state_filter = OperationState(args[0])
            except ValueError:
                self._fmt.error(f"Invalid state: {args[0]}")
                self._fmt.log(f"Valid states: {[s.value for s in OperationState]}")
                return

        try:
            store = self._safeline._store
            if store is None:
                self._fmt.error("No store configured")
                return
            op_summaries = store.list_operations(state=state_filter)
            if op_summaries:
                if self._fmt.json_output:
                    self._fmt.output({"operations": op_summaries, "count": len(op_summaries)})
                else:
                    print(f"\nOperations ({len(op_summaries)}):")
                    for summary in op_summaries:
                        marker = "*" if summary.operation_id == self._current_op_id else " "
                        print(f"  {marker} {summary.operation_id}")
                    print()
            else:
                self._fmt.log("No operations found")
        except Exception as e:
            self._fmt.error(str(e))

    def do_use(self, line: str) -> None:
        """Set current operation ID. Usage: use <operation_id>"""
        args = self._parse_args(line)
        if not args:
            if self._current_op_id:
                self._fmt.log(f"Current operation: {self._current_op_id}")
            else:
                self._fmt.log("No current operation set")
            return

        self._current_op_id = args[0]
        self._fmt.success(f"Using operation: {self._current_op_id}")

    def do_json(self, line: str) -> None:
        """Toggle JSON output mode. Usage: json [on|off]"""
        args = self._parse_args(line)
        if args:
            self._fmt = OutputFormatter(args[0].lower() == "on")
            self._fmt.log(f"JSON output: {args[0].lower()}")
        else:
            current = "on" if self._fmt.json_output else "off"
            self._fmt.log(f"JSON output is {current}")

    def do_env(self, _line: str) -> None:
        """Show current environment and protection level."""
        if self._fmt.json_output:
            self._fmt.output(
                {
                    "environment": self._env.to_dict(),
                    "protection_level": self._protection.to_dict(),
                }
            )
        else:
            print(f"\nEnvironment: {self._env.name}")
            print(f"Source: {self._env.source}")
            print(f"\nProtection Level: {self._protection.name}")
            print(f"Description: {self._protection.description}")
            print()
            print("Settings:")
            print(f"  Require approval: {self._protection.require_approval}")
            print(f"  Require audit:    {self._protection.require_audit}")
            print(f"  Require backup:   {self._protection.require_backup}")
            print(f"  Allow force:      {self._protection.allow_force}")
            print(f"  Simulation only:  {self._protection.simulation_only}")
            print(f"  Max targets:      {self._protection.max_targets or 'unlimited'}")
            print(f"  Retention days:   {self._protection.retention_days}")
            print()

    def _record_near_miss(self) -> None:
        """Record incomplete operations as near-misses."""
        incomplete = [
            op_id for op_id in self._operations_created if op_id not in self._operations_completed
        ]

        if not incomplete:
            return

        # Use safeline's abandon() method to properly record near-misses
        try:
            for op_id in incomplete:
                self._safeline.abandon(
                    operation_id=op_id,
                    reason="Operation abandoned in shell without completion",
                    metadata={
                        "abandoned_in": "shell",
                        "session_duration_seconds": (
                            datetime.now() - self._session_start
                        ).total_seconds(),
                    },
                )
        except Exception:
            pass  # Best effort - don't fail exit

    def do_quit(self, _line: str) -> bool:
        """Exit the shell."""
        # Check for incomplete operations
        incomplete = [
            op_id for op_id in self._operations_created if op_id not in self._operations_completed
        ]

        if incomplete and not self._fmt.json_output:
            print()
            print("=" * 50)
            print("Near-miss warning: Incomplete operations detected")
            print("=" * 50)
            print()
            print("The following operations were created but not completed:")
            for op_id in incomplete:
                print(f"  - {op_id}")
            print()
            print("These have been recorded for audit purposes.")
            print()

        self._record_near_miss()
        self._fmt.log("Goodbye!")
        return True

    def do_exit(self, line: str) -> bool:
        """Exit the shell."""
        return self.do_quit(line)

    def do_EOF(self, line: str) -> bool:
        """Handle Ctrl+D."""
        print()  # Newline for clean exit
        return self.do_quit(line)

    def emptyline(self) -> bool:
        """Do nothing on empty line."""
        return False

    def default(self, line: str) -> None:
        """Handle unknown commands - check if it's a stage name."""
        # Check if this is a stage name (allows typing 'plan' instead of 'stage plan')
        cmd = line.split()[0] if line.split() else ""
        if self._run_stage_by_name(cmd):
            return

        self._fmt.error(f"Unknown command: {line}")
        self._fmt.log("Type 'help' for available commands")


def create_shell(
    safeline: Safeline,
    operation_class: type[Operation] | None = None,
    operations: dict[str, type[Operation]] | None = None,
    json_output: bool = False,
) -> SafelineShell:
    """Create a Safeline shell instance.

    Args:
        safeline: The Safeline instance.
        operation_class: Single operation class.
        operations: Dict of operation classes.
        json_output: Enable JSON output mode.

    Returns:
        Configured SafelineShell instance.
    """
    return SafelineShell(
        safeline=safeline,
        operation_class=operation_class,
        operations=operations,
        json_output=json_output,
    )
