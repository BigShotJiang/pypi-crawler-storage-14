"""Narrative templates for CLI output.

This module provides data structures for defining narrative-style CLI output.
Narratives separate presentation from logic, allowing commands to be thin
wrappers that delegate to generic runners.

Example:
    ```python
    from sfln.cli import Narrative, StageNarratives

    VALIDATE = StageNarratives(
        stage_name="validate",
        action_verb="Validating",
        success=Narrative(
            verdict="ALLOWED",
            summary="approved by safety policy",
            what_happened="Operation {operation_id} passed validation.",
            why_it_matters="Validation ensures safe operations.",
            next_steps=["run stage {operation_id}"],
        ),
        failure=Narrative(
            verdict="DENIED",
            summary="rejected by safety policy",
            what_happened="Operation {operation_id} failed validation.",
            why_it_matters="This prevents unsafe operations.",
            next_steps=["Check the operation plan"],
        ),
    )
    ```
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    pass


class ClickContext(Protocol):
    """Protocol for Click context to avoid hard dependency on Click.

    This allows the narrative system to work with or without Click installed.
    """

    obj: dict[str, Any]


@dataclass
class Narrative:
    """Template for narrative output.

    Narratives define the human-readable output for a specific scenario.
    They use {placeholder} syntax for dynamic content that will be filled
    from operation data.

    Available placeholders:
        - {operation_id}: The operation ID
        - {environment}: Environment name
        - {file_count}: Number of files (from plan stage)
        - {total_bytes}: Total size in bytes
        - {total_size}: Formatted size string (e.g., "1.5 GB")
        - Custom fields from extract_data callback

    Attributes:
        verdict: Short status indicator (e.g., "SUCCESS", "DENIED", "REQUIRES_APPROVAL")
        summary: One-line summary of outcome
        what_happened: Detailed explanation with {placeholders}
        why_it_matters: Context about why this outcome is important
        next_steps: List of suggested next actions (supports {placeholders})

    Example:
        ```python
        success = Narrative(
            verdict="SUCCESS",
            summary="deployment completed",
            what_happened="Deployed version {version} to {environment}",
            why_it_matters="The new version is now live and serving traffic.",
            next_steps=[
                "Monitor metrics: dashboard {environment}",
                "Run smoke tests: test {operation_id}"
            ],
        )
        ```
    """

    verdict: str
    summary: str
    what_happened: str
    why_it_matters: str
    next_steps: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Validate narrative fields."""
        if not self.verdict:
            raise ValueError("verdict cannot be empty")
        if not self.summary:
            raise ValueError("summary cannot be empty")
        if not self.what_happened:
            raise ValueError("what_happened cannot be empty")
        if not self.why_it_matters:
            raise ValueError("why_it_matters cannot be empty")


@dataclass
class StageNarratives:
    """Narratives for different outcomes of a stage.

    Defines the human-readable output for success, failure, and
    approval-required scenarios for a specific stage.

    Attributes:
        stage_name: Stage identifier (e.g., "validate", "apply")
        action_verb: Present progressive verb for the action (e.g., "Validating", "Applying")
        success: Narrative for successful execution
        failure: Optional narrative for failure (if None, generic error used)
        approval_required: Optional narrative for when approval is required

    Example:
        ```python
        DEPLOY = StageNarratives(
            stage_name="deploy",
            action_verb="Deploying",
            success=Narrative(
                verdict="SUCCESS",
                summary="deployment completed successfully",
                what_happened="Deployed to {environment}",
                why_it_matters="New version is now live.",
                next_steps=["Verify deployment"],
            ),
            failure=Narrative(
                verdict="ERROR",
                summary="deployment failed",
                what_happened="Deployment to {environment} failed: {error}",
                why_it_matters="Service is still running old version.",
                next_steps=["Check logs", "Rollback if needed"],
            ),
            approval_required=Narrative(
                verdict="REQUIRES_APPROVAL",
                summary="deployment needs approval",
                what_happened="Production deployment requires approval",
                why_it_matters="Safety gate for production changes.",
                next_steps=["Approve: approve {operation_id} deploy"],
            ),
        )
        ```
    """

    stage_name: str
    action_verb: str
    success: Narrative
    failure: Narrative | None = None
    approval_required: Narrative | None = None

    def __post_init__(self) -> None:
        """Validate stage narratives."""
        if not self.stage_name:
            raise ValueError("stage_name cannot be empty")
        if not self.action_verb:
            raise ValueError("action_verb cannot be empty")
        if not self.success:
            raise ValueError("success narrative is required")
