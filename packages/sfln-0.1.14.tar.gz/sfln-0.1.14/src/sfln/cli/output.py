"""Output formatting for Safeline CLI."""

from __future__ import annotations

import json
import sys
from typing import Any

# Try to import click for colored output, but don't require it
try:
    import click

    HAS_CLICK = True
except ImportError:
    HAS_CLICK = False


def _echo(msg: str, err: bool = False, **kwargs: Any) -> None:
    """Echo message, using click if available."""
    if HAS_CLICK:
        click.echo(msg, err=err, **kwargs)
    else:
        print(msg, file=sys.stderr if err else sys.stdout)


def _secho(msg: str, fg: str | None = None, err: bool = False, **kwargs: Any) -> None:
    """Echo message with style, using click if available."""
    if HAS_CLICK:
        click.secho(msg, fg=fg, err=err, **kwargs)
    else:
        print(msg, file=sys.stderr if err else sys.stdout)


def log_info(msg: str) -> None:
    """Log an info message to stderr."""
    _echo(f"[INFO] {msg}", err=True)


def log_success(msg: str) -> None:
    """Log a success message to stderr."""
    _secho(f"[OK] {msg}", fg="green", err=True)


def log_warning(msg: str) -> None:
    """Log a warning message to stderr."""
    _secho(f"[WARN] {msg}", fg="yellow", err=True)


def log_error(msg: str) -> None:
    """Log an error message to stderr."""
    _secho(f"[ERROR] {msg}", fg="red", err=True)


def output_json(data: Any) -> None:
    """Output data as JSON to stdout."""
    print(json.dumps(data, indent=2, default=str))


def output_table(
    headers: list[str],
    rows: list[list[str]],
    title: str | None = None,
) -> None:
    """Output data as a simple table."""
    if title:
        print(f"\n{title}")
        print("=" * len(title))

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(str(cell)))

    # Print header
    header_line = " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    print(header_line)
    print("-" * len(header_line))

    # Print rows
    for row in rows:
        row_line = " | ".join(str(cell).ljust(widths[i]) for i, cell in enumerate(row))
        print(row_line)


class OutputFormatter:
    """Formatter that handles JSON and human-readable output."""

    def __init__(self, json_output: bool = False) -> None:
        self.json_output = json_output
        self._data: dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        """Set a value in the output data."""
        self._data[key] = value

    def log(self, msg: str) -> None:
        """Log a message (only in human mode)."""
        if not self.json_output:
            log_info(msg)

    def success(self, msg: str) -> None:
        """Log a success message (only in human mode)."""
        if not self.json_output:
            log_success(msg)

    def error(self, msg: str) -> None:
        """Log an error message (only in human mode)."""
        if not self.json_output:
            log_error(msg)

    def warning(self, msg: str) -> None:
        """Log a warning message (only in human mode)."""
        if not self.json_output:
            log_warning(msg)

    def output(self, data: dict[str, Any] | None = None) -> None:
        """Output the final result."""
        final_data = data if data is not None else self._data

        if self.json_output:
            output_json(final_data)
        else:
            # Human-readable output
            for key, value in final_data.items():
                if isinstance(value, dict):
                    print(f"\n{key}:")
                    for k, v in value.items():
                        print(f"  {k}: {v}")
                elif isinstance(value, list):
                    print(f"\n{key}:")
                    for item in value:
                        print(f"  - {item}")
                else:
                    print(f"{key}: {value}")
