"""Webhook notification system for Safeline."""

from __future__ import annotations

import json
import threading
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from sfln.logging import get_logger

if TYPE_CHECKING:
    from sfln.audit.events import AuditEvent

_logger = get_logger("notifications")


class Notifier(ABC):
    """Abstract base class for notifiers."""

    @abstractmethod
    def notify(self, event: AuditEvent) -> None:
        """Send notification for an event.

        Args:
            event: The audit event to notify about.
        """
        pass


class WebhookNotifier(Notifier):
    """Send HTTP webhooks on operation events.

    Example:
        notifier = WebhookNotifier(
            url="https://slack.com/webhook/...",
            events=["operation_failed", "approval_requested"],
        )
    """

    DEFAULT_EVENTS = [
        "operation_completed",
        "operation_failed",
        "approval_requested",
    ]

    def __init__(
        self,
        url: str,
        events: list[str] | None = None,
        headers: dict[str, str] | None = None,
        timeout: float = 10.0,
        async_send: bool = True,
    ) -> None:
        """Initialize webhook notifier.

        Args:
            url: Webhook URL to POST to.
            events: Event types to send. Defaults to operation_completed,
                    operation_failed, approval_requested.
            headers: Additional HTTP headers.
            timeout: HTTP request timeout.
            async_send: If True, send webhooks in background thread.
        """
        self._url = url
        self._events = set(events or self.DEFAULT_EVENTS)
        self._headers = headers or {}
        self._timeout = timeout
        self._async = async_send

    @property
    def url(self) -> str:
        """Get the webhook URL."""
        return self._url

    @property
    def events(self) -> set[str]:
        """Get the set of events this notifier handles."""
        return self._events

    def notify(self, event: AuditEvent) -> None:
        """Send webhook if event type matches filter.

        Args:
            event: The audit event to potentially send.
        """
        if event.event_type not in self._events:
            return

        if self._async:
            thread = threading.Thread(target=self._send, args=(event,), daemon=True)
            thread.start()
        else:
            self._send(event)

    def _send(self, event: AuditEvent) -> None:
        """Send HTTP POST with event data.

        Args:
            event: The audit event to send.
        """
        try:
            body = json.dumps(event.to_dict()).encode("utf-8")
            headers = {
                "Content-Type": "application/json",
                **self._headers,
            }
            request = Request(self._url, data=body, headers=headers, method="POST")
            with urlopen(request, timeout=self._timeout):  # nosec B310 - URL from config
                pass
        except (HTTPError, URLError, TimeoutError) as e:
            _logger.debug("Webhook notification to %s failed: %s", self._url, e)


class CompositeNotifier(Notifier):
    """Send to multiple notifiers.

    Example:
        notifier = CompositeNotifier([
            WebhookNotifier("https://slack.com/..."),
            WebhookNotifier("https://pagerduty.com/..."),
        ])
    """

    def __init__(self, notifiers: list[Notifier]) -> None:
        """Initialize composite notifier.

        Args:
            notifiers: List of notifiers to delegate to.
        """
        self._notifiers = notifiers

    @property
    def notifiers(self) -> list[Notifier]:
        """Get the list of notifiers."""
        return self._notifiers

    def notify(self, event: AuditEvent) -> None:
        """Send notification to all notifiers.

        Args:
            event: The audit event to notify about.
        """
        for notifier in self._notifiers:
            notifier.notify(event)


class NoOpNotifier(Notifier):
    """Notifier that does nothing. Useful for testing."""

    def notify(self, event: AuditEvent) -> None:
        """Do nothing."""
        pass
