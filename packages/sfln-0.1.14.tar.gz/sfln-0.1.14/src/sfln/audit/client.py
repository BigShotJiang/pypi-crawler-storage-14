"""Audit store client for sending events to an external audit-store service."""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from queue import Empty, Queue
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from sfln.audit.emitter import AuditEmitter
from sfln.audit.events import AuditEvent
from sfln.logging import get_logger

_logger = get_logger("audit")


class AuditStoreClient(AuditEmitter):
    """Client for sending audit events to an external audit-store service.

    Features:
    - Async batching for efficiency
    - Retry with exponential backoff
    - Local fallback file if audit-store unavailable
    - Thread-safe event queue

    Example:
        client = AuditStoreClient(
            url="http://audit-store:8080",
            batch_size=100,
            flush_interval=5.0,
        )

        # Events are batched and sent asynchronously
        client.emit(...)

        # Ensure all events are sent before shutdown
        client.close()
    """

    def __init__(
        self,
        url: str,
        batch_size: int = 100,
        flush_interval: float = 5.0,
        retry_attempts: int = 3,
        retry_delay: float = 1.0,
        timeout: float = 10.0,
        fallback_file: str | Path | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        """Initialize the audit store client.

        Args:
            url: Base URL of the audit-store service.
            batch_size: Max events per batch.
            flush_interval: Seconds between automatic flushes.
            retry_attempts: Number of retry attempts on failure.
            retry_delay: Initial delay between retries (exponential backoff).
            timeout: HTTP request timeout in seconds.
            fallback_file: Path to write events if audit-store unavailable.
            headers: Additional HTTP headers to include.
        """
        self._url = url.rstrip("/")
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._retry_attempts = retry_attempts
        self._retry_delay = retry_delay
        self._timeout = timeout
        self._fallback_file = Path(fallback_file) if fallback_file else None
        self._headers = headers or {}

        self._queue: Queue[AuditEvent] = Queue()
        self._shutdown = threading.Event()
        self._flush_thread = threading.Thread(target=self._flush_loop, daemon=True)
        self._flush_thread.start()

    def emit(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        """Queue an audit event for sending."""
        event = AuditEvent(
            event_type=event_type,
            operation_id=operation_id,
            operation_type=operation_type,
            actor=actor,
            environment=environment,
            stage_name=stage_name,
            success=success,
            data=data or {},
            metadata=metadata or {},
            error=error,
        )
        self._queue.put(event)

        # Trigger immediate flush if batch size reached
        if self._queue.qsize() >= self._batch_size:
            self._do_flush()

    def flush(self) -> None:
        """Flush all queued events immediately."""
        self._do_flush()

    def close(self) -> None:
        """Shutdown the client, flushing remaining events."""
        self._shutdown.set()
        self._do_flush()
        self._flush_thread.join(timeout=5.0)

    def _flush_loop(self) -> None:
        """Background thread that periodically flushes events."""
        while not self._shutdown.is_set():
            self._shutdown.wait(timeout=self._flush_interval)
            if not self._shutdown.is_set():
                self._do_flush()

    def _do_flush(self) -> None:
        """Collect queued events and send them."""
        events: list[AuditEvent] = []

        try:
            while len(events) < self._batch_size:
                event = self._queue.get_nowait()
                events.append(event)
        except Empty:
            pass

        if events:
            self._send_batch(events)

    def _send_batch(self, events: list[AuditEvent]) -> None:
        """Send a batch of events to audit-store."""
        payload = [e.to_dict() for e in events]

        for attempt in range(self._retry_attempts):
            try:
                self._http_post(f"{self._url}/events/batch", payload)
                return  # Success
            except (HTTPError, URLError, TimeoutError) as e:
                if attempt < self._retry_attempts - 1:
                    # Exponential backoff
                    delay = self._retry_delay * (2**attempt)
                    time.sleep(delay)
                else:
                    # All retries failed, write to fallback
                    self._write_fallback(events, str(e))

    def _http_post(self, url: str, data: Any) -> None:
        """Make HTTP POST request."""
        body = json.dumps(data).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            **self._headers,
        }

        request = Request(url, data=body, headers=headers, method="POST")

        try:
            with urlopen(request, timeout=self._timeout) as response:  # nosec B310 - URL from config
                if response.status >= 400:
                    raise HTTPError(url, response.status, "HTTP error", response.headers, None)
        except Exception:
            raise

    def _write_fallback(self, events: list[AuditEvent], error: str) -> None:
        """Write events to fallback file when audit-store unavailable."""
        if not self._fallback_file:
            return

        try:
            self._fallback_file.parent.mkdir(parents=True, exist_ok=True)
            with self._fallback_file.open("a") as f:
                for event in events:
                    f.write(event.to_json_line() + "\n")
        except Exception as e:
            _logger.warning(
                "Failed to write %d events to fallback file %s: %s",
                len(events),
                self._fallback_file,
                e,
            )

    def health_check(self) -> bool:
        """Check if audit-store is healthy."""
        try:
            request = Request(
                f"{self._url}/health",
                headers=self._headers,
                method="GET",
            )
            with urlopen(request, timeout=self._timeout) as response:  # nosec B310 - URL from config
                return bool(response.status == 200)
        except Exception as e:
            _logger.debug("Health check failed for %s: %s", self._url, e)
            return False


class FileAuditEmitter(AuditEmitter):
    """Emitter that writes events to a JSON Lines file."""

    def __init__(self, file_path: str | Path) -> None:
        """Initialize the file emitter.

        Args:
            file_path: Path to the audit log file.
        """
        self._file_path = Path(file_path)
        self._file_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def emit(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        event = AuditEvent(
            event_type=event_type,
            operation_id=operation_id,
            operation_type=operation_type,
            actor=actor,
            environment=environment,
            stage_name=stage_name,
            success=success,
            data=data or {},
            metadata=metadata or {},
            error=error,
        )

        with self._lock:
            with self._file_path.open("a") as f:
                f.write(event.to_json_line() + "\n")

    def flush(self) -> None:
        pass  # File writes are immediate

    def close(self) -> None:
        pass  # No resources to release
