"""Audit event emitter for Safeline."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from sfln.audit.events import AuditEvent
from sfln.logging import get_logger

_logger = get_logger("audit")


class AuditEmitter(ABC):
    """Abstract base class for audit event emitters.

    Subclasses implement specific transport mechanisms (HTTP, file, etc.).
    """

    @abstractmethod
    def emit(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        """Emit an audit event.

        Args:
            event_type: Type of event (e.g., "stage_completed").
            operation_id: ID of the operation.
            operation_type: Type/name of the operation.
            actor: Who triggered this action.
            environment: Environment name.
            stage_name: Stage name if applicable.
            success: Whether the action succeeded.
            data: Event-specific data.
            metadata: Additional context.
            error: Error message if failed.
        """
        pass

    @abstractmethod
    def flush(self) -> None:
        """Flush any buffered events."""
        pass

    @abstractmethod
    def close(self) -> None:
        """Close the emitter and release resources."""
        pass


class NoOpEmitter(AuditEmitter):
    """No-op emitter that discards all events."""

    def emit(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        pass

    def flush(self) -> None:
        pass

    def close(self) -> None:
        pass


class CompositeEmitter(AuditEmitter):
    """Emitter that sends events to multiple backends."""

    def __init__(self, emitters: list[AuditEmitter]) -> None:
        self._emitters = emitters

    def emit(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        for emitter in self._emitters:
            try:
                emitter.emit(
                    event_type=event_type,
                    operation_id=operation_id,
                    operation_type=operation_type,
                    actor=actor,
                    environment=environment,
                    stage_name=stage_name,
                    success=success,
                    data=data,
                    metadata=metadata,
                    error=error,
                )
            except Exception as e:
                _logger.debug(
                    "Emitter %s failed to emit event %s: %s",
                    emitter.__class__.__name__,
                    event_type,
                    e,
                )

    def flush(self) -> None:
        for emitter in self._emitters:
            try:
                emitter.flush()
            except Exception as e:
                _logger.debug(
                    "Emitter %s failed to flush: %s",
                    emitter.__class__.__name__,
                    e,
                )

    def close(self) -> None:
        for emitter in self._emitters:
            try:
                emitter.close()
            except Exception as e:
                _logger.debug(
                    "Emitter %s failed to close: %s",
                    emitter.__class__.__name__,
                    e,
                )


class MemoryEmitter(AuditEmitter):
    """In-memory emitter for testing. Stores all events in a list."""

    def __init__(self) -> None:
        self.events: list[AuditEvent] = []

    def emit(
        self,
        event_type: str,
        operation_id: str,
        operation_type: str,
        actor: str,
        environment: str,
        stage_name: str | None = None,
        success: bool = True,
        data: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        event = AuditEvent(
            event_type=event_type,
            operation_id=operation_id,
            operation_type=operation_type,
            actor=actor,
            environment=environment,
            stage_name=stage_name,
            success=success,
            data=data or {},
            metadata=metadata or {},
            error=error,
        )
        self.events.append(event)

    def flush(self) -> None:
        pass

    def close(self) -> None:
        pass

    def clear(self) -> None:
        """Clear all stored events."""
        self.events.clear()

    def get_events_for_operation(self, operation_id: str) -> list[AuditEvent]:
        """Get all events for a specific operation."""
        return [e for e in self.events if e.operation_id == operation_id]

    def get_events_by_type(self, event_type: str) -> list[AuditEvent]:
        """Get all events of a specific type."""
        return [e for e in self.events if e.event_type == event_type]
