"""Audit event definitions for Safeline."""

from __future__ import annotations

import socket
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class EventType(str, Enum):
    """Types of audit events."""

    # Operation lifecycle
    OPERATION_CREATED = "operation_created"
    OPERATION_COMPLETED = "operation_completed"
    OPERATION_FAILED = "operation_failed"
    OPERATION_ABANDONED = "operation_abandoned"

    # Stage lifecycle
    STAGE_STARTED = "stage_started"
    STAGE_COMPLETED = "stage_completed"
    STAGE_FAILED = "stage_failed"
    STAGE_SKIPPED = "stage_skipped"

    # Approval
    APPROVAL_REQUESTED = "approval_requested"
    APPROVAL_GRANTED = "approval_granted"
    APPROVAL_DENIED = "approval_denied"

    # Locking
    LOCK_ACQUIRED = "lock_acquired"
    LOCK_RELEASED = "lock_released"
    LOCK_FAILED = "lock_failed"

    # Rollback
    ROLLBACK_STARTED = "rollback_started"
    ROLLBACK_COMPLETED = "rollback_completed"
    ROLLBACK_FAILED = "rollback_failed"


def _generate_event_id() -> str:
    """Generate a unique event ID."""
    return f"evt-{uuid.uuid4().hex[:12]}"


def _now_iso() -> str:
    """Get current time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


def _get_hostname() -> str:
    """Get current hostname."""
    try:
        return socket.gethostname()
    except Exception:
        return "unknown"


@dataclass
class AuditEvent:
    """An audit event to be sent to audit-store.

    Audit events capture all significant actions within Safeline operations,
    providing a complete audit trail for compliance and debugging.

    Attributes:
        event_id: Unique identifier for this event.
        operation_id: ID of the operation this event belongs to.
        operation_type: Type/name of the operation.
        event_type: Type of event (from EventType enum).
        timestamp: When the event occurred (ISO format).
        actor: Who triggered this action.
        environment: Environment where this occurred.
        hostname: Host where this occurred.
        stage_name: Stage name (if applicable).
        success: Whether the action succeeded.
        data: Event-specific data.
        metadata: Additional context.
        error: Error message if failed.
    """

    operation_id: str
    operation_type: str
    event_type: str
    actor: str
    environment: str
    event_id: str = field(default_factory=_generate_event_id)
    timestamp: str = field(default_factory=_now_iso)
    hostname: str = field(default_factory=_get_hostname)
    stage_name: str | None = None
    success: bool = True
    data: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary for JSON encoding."""
        return {
            "event_id": self.event_id,
            "operation_id": self.operation_id,
            "operation_type": self.operation_type,
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "actor": self.actor,
            "environment": self.environment,
            "hostname": self.hostname,
            "stage_name": self.stage_name,
            "success": self.success,
            "data": self.data,
            "metadata": self.metadata,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AuditEvent:
        """Deserialize from dictionary."""
        return cls(
            event_id=data.get("event_id", _generate_event_id()),
            operation_id=data["operation_id"],
            operation_type=data["operation_type"],
            event_type=data["event_type"],
            timestamp=data.get("timestamp", _now_iso()),
            actor=data.get("actor", "unknown"),
            environment=data.get("environment", "unknown"),
            hostname=data.get("hostname", _get_hostname()),
            stage_name=data.get("stage_name"),
            success=data.get("success", True),
            data=data.get("data", {}),
            metadata=data.get("metadata", {}),
            error=data.get("error"),
        )

    def to_json_line(self) -> str:
        """Serialize to JSON line format."""
        import json

        return json.dumps(self.to_dict())
