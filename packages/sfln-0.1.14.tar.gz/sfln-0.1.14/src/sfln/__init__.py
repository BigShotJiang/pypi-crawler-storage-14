"""Safeline - A framework for safety-critical operations.

Safeline provides infrastructure for building operations with:
- Arbitrary stage pipelines
- Automatic audit trails (to audit-store)
- Locking and approval workflows
- Environment-aware protection levels

Example:
    from sfln import Operation, Stage, StageResult, Context, Safeline

    class MyOperation(Operation):
        name = "my-operation"
        stages = [
            Stage("prepare"),
            Stage("execute", needs_approval=True),
            Stage("cleanup"),
        ]

        def prepare(self, context: Context) -> StageResult:
            return StageResult(data={"ready": True})

        def execute(self, context: Context) -> StageResult:
            return StageResult(data={"done": True})

        def cleanup(self, context: Context) -> StageResult:
            return StageResult(data={"cleaned": True})

    # Run the operation
    sl = Safeline(...)
    result = sl.run(MyOperation(targets=["target1"]))
"""

from sfln.approval.config import ApprovalConfig
from sfln.approval.manager import (
    ApprovalManager,
    ApprovalRequest,
    FileApprovalManager,
    MemoryApprovalManager,
)
from sfln.audit.client import AuditStoreClient, FileAuditEmitter
from sfln.audit.emitter import (
    AuditEmitter,
    CompositeEmitter,
    MemoryEmitter,
    NoOpEmitter,
)
from sfln.audit.events import AuditEvent, EventType
from sfln.cli.formatting import format_bytes, format_template, print_structured_output
from sfln.cli.generator import create_multi_operation_cli, generate_cli
from sfln.cli.narrative import Narrative, StageNarratives
from sfln.cli.output import OutputFormatter
from sfln.cli.runner import run_stage_command
from sfln.cli.shell import SafelineShell, create_shell
from sfln.config.loader import (
    create_safeline_from_config,
    from_config,
    load_config,
)
from sfln.core.context import Context
from sfln.core.operation import Operation
from sfln.core.pipeline import Safeline
from sfln.core.plan import (
    PLAN_SCHEMA_VERSION,
    OperationPlan,
    StagePlan,
    StageStatusRecord,
    generate_plan_id,
)
from sfln.core.policy import (
    PolicyVerdict,
    RiskLevel,
    RiskScore,
    UserContext,
    Verdict,
)
from sfln.core.result import (
    CleanupResult,
    OperationDetails,
    OperationResult,
    OperationState,
    OperationSummary,
    StageResult,
)
from sfln.core.stage import Stage, StageState, StageStatus
from sfln.exceptions import (
    ApprovalRequiredError,
    AuditError,
    ConfigurationError,
    InvalidOperationStateError,
    InvalidStageTransitionError,
    LockAcquisitionError,
    LockError,
    LockNotHeldError,
    OperationExpiredError,
    OperationNotFoundError,
    RollbackError,
    SafelineError,
    StageError,
    StageNotFoundError,
    StageTimeoutError,
)
from sfln.locking.manager import (
    FileLockManager,
    LockConfig,
    LockInfo,
    LockManager,
    MemoryLockManager,
)
from sfln.notifications.webhook import (
    CompositeNotifier,
    NoOpNotifier,
    Notifier,
    WebhookNotifier,
)
from sfln.protection.environment import (
    Environment,
    EnvironmentDetector,
    detect_environment,
    get_environment_name,
)
from sfln.protection.levels import PROTECTION_LEVELS, ProtectionLevel
from sfln.protection.registry import (
    ProtectionRegistry,
    get_protection_level,
    get_registry,
)
from sfln.storage.store import FileStore, MemoryStore, OperationStore

__version__ = "0.1.14"

__all__ = [
    # Version
    "__version__",
    # Core
    "CleanupResult",
    "Context",
    "Operation",
    "OperationDetails",
    "OperationPlan",
    "OperationResult",
    "OperationState",
    "OperationSummary",
    "PLAN_SCHEMA_VERSION",
    "PolicyVerdict",
    "RiskLevel",
    "RiskScore",
    "Safeline",
    "Stage",
    "StagePlan",
    "StageResult",
    "StageState",
    "StageStatus",
    "StageStatusRecord",
    "UserContext",
    "Verdict",
    "generate_plan_id",
    # Storage
    "FileStore",
    "MemoryStore",
    "OperationStore",
    # Audit
    "AuditEmitter",
    "AuditEvent",
    "AuditStoreClient",
    "CompositeEmitter",
    "EventType",
    "FileAuditEmitter",
    "MemoryEmitter",
    "NoOpEmitter",
    # Locking
    "FileLockManager",
    "LockConfig",
    "LockInfo",
    "LockManager",
    "MemoryLockManager",
    # Approval
    "ApprovalConfig",
    "ApprovalManager",
    "ApprovalRequest",
    "FileApprovalManager",
    "MemoryApprovalManager",
    # Protection
    "Environment",
    "EnvironmentDetector",
    "PROTECTION_LEVELS",
    "ProtectionLevel",
    "ProtectionRegistry",
    "detect_environment",
    "get_environment_name",
    "get_protection_level",
    "get_registry",
    # CLI - Narrative-based
    "Narrative",
    "StageNarratives",
    "format_bytes",
    "format_template",
    "print_structured_output",
    "run_stage_command",
    # CLI - Generation and utilities
    "OutputFormatter",
    "SafelineShell",
    "create_multi_operation_cli",
    "create_shell",
    "generate_cli",
    # Notifications
    "CompositeNotifier",
    "Notifier",
    "NoOpNotifier",
    "WebhookNotifier",
    # Config
    "create_safeline_from_config",
    "from_config",
    "load_config",
    # Exceptions
    "ApprovalRequiredError",
    "AuditError",
    "ConfigurationError",
    "InvalidOperationStateError",
    "InvalidStageTransitionError",
    "LockAcquisitionError",
    "LockError",
    "LockNotHeldError",
    "OperationExpiredError",
    "OperationNotFoundError",
    "RollbackError",
    "SafelineError",
    "StageError",
    "StageNotFoundError",
    "StageTimeoutError",
]
