"""Lock management for Safeline operations."""

from __future__ import annotations

import fcntl
import json
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sfln.exceptions import LockAcquisitionError, LockNotHeldError
from sfln.logging import get_logger

_logger = get_logger("locking")


def _now_iso() -> str:
    """Get current time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


@dataclass
class LockConfig:
    """Configuration for locking behavior.

    Attributes:
        scope: Template for lock key (e.g., "deploy:{target}").
        timeout_seconds: How long to wait to acquire lock.
        exclusive: If True, only one holder at a time.
        ttl_seconds: Lock auto-expires after this time.
    """

    scope: str = "{operation_id}"
    timeout_seconds: int = 300
    exclusive: bool = True
    ttl_seconds: int = 3600


@dataclass
class LockInfo:
    """Information about a held lock.

    Attributes:
        lock_key: The key identifying this lock.
        holder: Who holds the lock.
        acquired_at: When the lock was acquired.
        expires_at: When the lock expires.
        metadata: Additional lock metadata.
    """

    lock_key: str
    holder: str
    acquired_at: str = field(default_factory=_now_iso)
    expires_at: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "lock_key": self.lock_key,
            "holder": self.holder,
            "acquired_at": self.acquired_at,
            "expires_at": self.expires_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LockInfo:
        return cls(
            lock_key=data["lock_key"],
            holder=data["holder"],
            acquired_at=data.get("acquired_at", _now_iso()),
            expires_at=data.get("expires_at"),
            metadata=data.get("metadata", {}),
        )

    def is_expired(self) -> bool:
        """Check if lock has expired."""
        if not self.expires_at:
            return False
        now = datetime.now(timezone.utc)
        expires = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        return now > expires


class LockManager(ABC):
    """Abstract base class for lock managers."""

    @abstractmethod
    def acquire(
        self,
        lock_key: str,
        holder: str = "unknown",
        timeout_seconds: int | None = None,
        ttl_seconds: int | None = None,
    ) -> LockInfo:
        """Acquire a lock.

        Args:
            lock_key: Key identifying the resource to lock.
            holder: Who is acquiring the lock.
            timeout_seconds: How long to wait for the lock.
            ttl_seconds: Lock expires after this time.

        Returns:
            LockInfo for the acquired lock.

        Raises:
            LockAcquisitionError: If lock cannot be acquired.
        """
        pass

    @abstractmethod
    def release(self, lock_key: str, holder: str = "unknown") -> None:
        """Release a held lock.

        Args:
            lock_key: Key of the lock to release.
            holder: Who is releasing (must match holder who acquired).

        Raises:
            LockNotHeldError: If lock is not held by this holder.
        """
        pass

    @abstractmethod
    def is_locked(self, lock_key: str) -> bool:
        """Check if a lock is currently held."""
        pass

    @abstractmethod
    def get_lock_info(self, lock_key: str) -> LockInfo | None:
        """Get information about a lock."""
        pass

    @abstractmethod
    def force_release(self, lock_key: str) -> None:
        """Force release a lock regardless of holder."""
        pass


class MemoryLockManager(LockManager):
    """In-memory lock manager for testing."""

    def __init__(self) -> None:
        self._locks: dict[str, LockInfo] = {}

    def acquire(
        self,
        lock_key: str,
        holder: str = "unknown",
        timeout_seconds: int | None = None,
        ttl_seconds: int | None = None,
    ) -> LockInfo:
        timeout = timeout_seconds or 30
        ttl = ttl_seconds or 3600

        start_time = time.time()
        while time.time() - start_time < timeout:
            # Clean expired locks
            if lock_key in self._locks and self._locks[lock_key].is_expired():
                del self._locks[lock_key]

            if lock_key not in self._locks:
                from datetime import timedelta

                now = datetime.now(timezone.utc)
                expires = (now + timedelta(seconds=ttl)) if ttl else None

                lock_info = LockInfo(
                    lock_key=lock_key,
                    holder=holder,
                    expires_at=expires.isoformat() if expires else None,
                )
                self._locks[lock_key] = lock_info
                return lock_info

            time.sleep(0.1)

        existing = self._locks.get(lock_key)
        raise LockAcquisitionError(
            lock_key,
            f"Lock held by {existing.holder if existing else 'unknown'}",
        )

    def release(self, lock_key: str, holder: str = "unknown") -> None:
        if lock_key not in self._locks:
            raise LockNotHeldError(lock_key)

        lock_info = self._locks[lock_key]
        if lock_info.holder != holder:
            raise LockNotHeldError(lock_key)

        del self._locks[lock_key]

    def is_locked(self, lock_key: str) -> bool:
        if lock_key in self._locks:
            if self._locks[lock_key].is_expired():
                del self._locks[lock_key]
                return False
            return True
        return False

    def get_lock_info(self, lock_key: str) -> LockInfo | None:
        lock = self._locks.get(lock_key)
        if lock and lock.is_expired():
            del self._locks[lock_key]
            return None
        return lock

    def force_release(self, lock_key: str) -> None:
        self._locks.pop(lock_key, None)


class FileLockManager(LockManager):
    """File-based lock manager using flock.

    Uses filesystem locks for coordination. Suitable for single-host deployments.
    """

    def __init__(self, lock_dir: str | Path) -> None:
        """Initialize the file lock manager.

        Args:
            lock_dir: Directory to store lock files.
        """
        self._lock_dir = Path(lock_dir)
        self._lock_dir.mkdir(parents=True, exist_ok=True)
        self._held_locks: dict[str, int] = {}  # lock_key -> fd

    def _lock_path(self, lock_key: str) -> Path:
        """Get the path for a lock file."""
        # Sanitize lock key for filesystem
        safe_key = lock_key.replace("/", "_").replace(":", "_")
        return self._lock_dir / f"{safe_key}.lock"

    def _info_path(self, lock_key: str) -> Path:
        """Get the path for lock info file."""
        safe_key = lock_key.replace("/", "_").replace(":", "_")
        return self._lock_dir / f"{safe_key}.json"

    def acquire(
        self,
        lock_key: str,
        holder: str = "unknown",
        timeout_seconds: int | None = None,
        ttl_seconds: int | None = None,
    ) -> LockInfo:
        timeout = timeout_seconds or 30
        ttl = ttl_seconds or 3600

        lock_path = self._lock_path(lock_key)
        info_path = self._info_path(lock_key)

        start_time = time.time()
        while time.time() - start_time < timeout:
            # Check for expired lock
            if info_path.exists():
                try:
                    info = LockInfo.from_dict(json.loads(info_path.read_text()))
                    if info.is_expired():
                        self.force_release(lock_key)
                except Exception as e:
                    _logger.debug("Failed to check/release expired lock %s: %s", lock_key, e)

            try:
                # Open or create lock file
                fd = os.open(
                    str(lock_path),
                    os.O_CREAT | os.O_RDWR,
                    0o644,
                )

                # Try to acquire exclusive lock (non-blocking)
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    os.close(fd)
                    time.sleep(0.1)
                    continue

                # Lock acquired
                self._held_locks[lock_key] = fd

                now = datetime.now(timezone.utc)
                from datetime import timedelta

                expires = (now + timedelta(seconds=ttl)) if ttl else None

                lock_info = LockInfo(
                    lock_key=lock_key,
                    holder=holder,
                    expires_at=expires.isoformat() if expires else None,
                )

                # Write lock info
                info_path.write_text(json.dumps(lock_info.to_dict()))

                return lock_info

            except OSError as e:
                raise LockAcquisitionError(lock_key, str(e)) from e

        # Timeout
        raise LockAcquisitionError(lock_key, "Timeout waiting for lock")

    def release(self, lock_key: str, holder: str = "unknown") -> None:
        if lock_key not in self._held_locks:
            raise LockNotHeldError(lock_key)

        # Check holder matches
        info_path = self._info_path(lock_key)
        if info_path.exists():
            try:
                info = LockInfo.from_dict(json.loads(info_path.read_text()))
                if info.holder != holder:
                    raise LockNotHeldError(lock_key)
            except json.JSONDecodeError:
                pass

        fd = self._held_locks.pop(lock_key)
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)
        except OSError:
            pass

        # Clean up files
        try:
            self._lock_path(lock_key).unlink(missing_ok=True)
            info_path.unlink(missing_ok=True)
        except OSError:
            pass

    def is_locked(self, lock_key: str) -> bool:
        lock_path = self._lock_path(lock_key)
        if not lock_path.exists():
            return False

        # Check if expired
        info_path = self._info_path(lock_key)
        if info_path.exists():
            try:
                info = LockInfo.from_dict(json.loads(info_path.read_text()))
                if info.is_expired():
                    self.force_release(lock_key)
                    return False
            except Exception as e:
                _logger.debug("Failed to check lock expiry for %s: %s", lock_key, e)

        # Try to acquire lock to check if it's held
        try:
            fd = os.open(str(lock_path), os.O_RDWR)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                # We got the lock, so it wasn't held
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
                return False
            except BlockingIOError:
                os.close(fd)
                return True
        except OSError:
            return False

    def get_lock_info(self, lock_key: str) -> LockInfo | None:
        info_path = self._info_path(lock_key)
        if not info_path.exists():
            return None

        try:
            info = LockInfo.from_dict(json.loads(info_path.read_text()))
            if info.is_expired():
                self.force_release(lock_key)
                return None
            return info
        except Exception as e:
            _logger.debug("Failed to get lock info for %s: %s", lock_key, e)
            return None

    def force_release(self, lock_key: str) -> None:
        # Release file descriptor if held by us
        if lock_key in self._held_locks:
            fd = self._held_locks.pop(lock_key)
            try:
                fcntl.flock(fd, fcntl.LOCK_UN)
                os.close(fd)
            except OSError:
                pass

        # Clean up files
        try:
            self._lock_path(lock_key).unlink(missing_ok=True)
            self._info_path(lock_key).unlink(missing_ok=True)
        except OSError:
            pass
