"""Configuration file loader for Safeline."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sfln.core.pipeline import Safeline


def _expand_env_vars(value: str) -> str:
    """Expand ${VAR} references in string.

    Args:
        value: String potentially containing ${VAR} references.

    Returns:
        String with environment variables expanded.
    """
    pattern = re.compile(r"\$\{([^}]+)\}")

    def replace(match: re.Match[str]) -> str:
        var_name = match.group(1)
        return os.environ.get(var_name, match.group(0))

    return pattern.sub(replace, value)


def _expand_config(obj: Any) -> Any:
    """Recursively expand environment variables in config.

    Args:
        obj: Configuration object (dict, list, or scalar).

    Returns:
        Configuration with environment variables expanded.
    """
    if isinstance(obj, str):
        return _expand_env_vars(obj)
    elif isinstance(obj, dict):
        return {k: _expand_config(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_expand_config(item) for item in obj]
    return obj


def load_config(path: str | Path) -> dict[str, Any]:
    """Load and parse config file.

    Supports YAML format. Environment variables in the format ${VAR}
    are expanded.

    Args:
        path: Path to the configuration file.

    Returns:
        Parsed configuration dictionary.

    Raises:
        FileNotFoundError: If config file doesn't exist.
        ImportError: If PyYAML is not installed.
    """
    try:
        import yaml
    except ImportError as e:
        raise ImportError(
            "PyYAML is required for config file support. Install it with: pip install pyyaml"
        ) from e

    path = Path(path)
    with path.open() as f:
        config = yaml.safe_load(f)
    result: dict[str, Any] = _expand_config(config or {})
    return result


def create_safeline_from_config(config: dict[str, Any]) -> Safeline:
    """Create Safeline instance from config dict.

    Args:
        config: Configuration dictionary.

    Returns:
        Configured Safeline instance.
    """
    from sfln.approval.manager import (
        ApprovalManager,
        FileApprovalManager,
        MemoryApprovalManager,
    )
    from sfln.audit.client import AuditStoreClient, FileAuditEmitter
    from sfln.audit.emitter import AuditEmitter, NoOpEmitter
    from sfln.core.pipeline import Safeline
    from sfln.locking.manager import FileLockManager, LockManager, MemoryLockManager
    from sfln.notifications.webhook import Notifier, WebhookNotifier
    from sfln.storage.store import FileStore, MemoryStore, OperationStore

    # Storage
    store: OperationStore | None = None
    if storage_cfg := config.get("storage"):
        store_type = storage_cfg.get("type", "memory")
        if store_type == "file":
            store = FileStore(storage_cfg["path"])
        else:
            store = MemoryStore()

    # Locking
    lock_manager: LockManager | None = None
    if lock_cfg := config.get("locking"):
        lock_type = lock_cfg.get("type", "memory")
        if lock_type == "file":
            lock_manager = FileLockManager(lock_cfg["path"])
        else:
            lock_manager = MemoryLockManager()

    # Approval
    approval_manager: ApprovalManager | None = None
    if approval_cfg := config.get("approval"):
        approval_type = approval_cfg.get("type", "memory")
        if approval_type == "file":
            approval_manager = FileApprovalManager(approval_cfg["path"])
        else:
            approval_manager = MemoryApprovalManager()

    # Audit
    auditor: AuditEmitter | None = None
    if audit_cfg := config.get("audit"):
        audit_type = audit_cfg.get("type", "none")
        if audit_type == "http":
            auditor = AuditStoreClient(
                url=audit_cfg["url"],
                batch_size=audit_cfg.get("batch_size", 100),
                flush_interval=audit_cfg.get("flush_interval", 5.0),
                fallback_file=audit_cfg.get("fallback_file"),
                headers=audit_cfg.get("headers"),
            )
        elif audit_type == "file":
            auditor = FileAuditEmitter(audit_cfg["path"])
        else:
            auditor = NoOpEmitter()

    # Notifications
    notifiers: list[Notifier] = []
    for notif_cfg in config.get("notifications", []):
        if notif_cfg.get("type") == "webhook":
            notifiers.append(
                WebhookNotifier(
                    url=notif_cfg["url"],
                    events=notif_cfg.get("events"),
                    headers=notif_cfg.get("headers"),
                )
            )

    return Safeline(
        store=store,
        auditor=auditor,
        lock_manager=lock_manager,
        approval_manager=approval_manager,
        environment=config.get("environment", "unknown"),
        actor=config.get("actor", "unknown"),
        notifiers=notifiers if notifiers else None,
    )


def from_config(path: str | Path) -> Safeline:
    """Load Safeline from config file.

    This is a convenience function that loads the config and creates
    a Safeline instance in one step.

    Example:
        sl = from_config("/etc/safeline/safeline.yaml")

    Args:
        path: Path to the configuration file.

    Returns:
        Configured Safeline instance.
    """
    config = load_config(path)
    return create_safeline_from_config(config)
