"""Safeline framework exceptions."""

from __future__ import annotations


class SafelineError(Exception):
    """Base exception for all Safeline errors."""

    pass


class StageError(SafelineError):
    """Error during stage execution."""

    def __init__(self, stage_name: str, message: str) -> None:
        self.stage_name = stage_name
        super().__init__(f"Stage '{stage_name}' failed: {message}")


class StageNotFoundError(SafelineError):
    """Stage method not found on operation."""

    def __init__(self, stage_name: str, operation_type: str) -> None:
        self.stage_name = stage_name
        self.operation_type = operation_type
        super().__init__(f"Stage '{stage_name}' not implemented on {operation_type}")


class InvalidStageTransitionError(SafelineError):
    """Invalid state transition attempted."""

    def __init__(self, stage_name: str, current_state: str, reason: str) -> None:
        self.stage_name = stage_name
        self.current_state = current_state
        super().__init__(f"Cannot run stage '{stage_name}' from state '{current_state}': {reason}")


class ApprovalRequiredError(SafelineError):
    """Stage requires approval before execution."""

    def __init__(self, stage_name: str) -> None:
        self.stage_name = stage_name
        super().__init__(f"Stage '{stage_name}' requires approval before execution")


class LockError(SafelineError):
    """Error acquiring or releasing lock."""

    pass


class LockAcquisitionError(LockError):
    """Failed to acquire lock."""

    def __init__(self, lock_key: str, reason: str) -> None:
        self.lock_key = lock_key
        super().__init__(f"Failed to acquire lock '{lock_key}': {reason}")


class LockNotHeldError(LockError):
    """Attempted operation on lock not held."""

    def __init__(self, lock_key: str) -> None:
        self.lock_key = lock_key
        super().__init__(f"Lock '{lock_key}' is not held")


class OperationNotFoundError(SafelineError):
    """Operation not found in store."""

    def __init__(self, operation_id: str) -> None:
        self.operation_id = operation_id
        super().__init__(f"Operation '{operation_id}' not found")


class OperationExpiredError(SafelineError):
    """Operation has expired."""

    def __init__(self, operation_id: str) -> None:
        self.operation_id = operation_id
        super().__init__(f"Operation '{operation_id}' has expired")


class AuditError(SafelineError):
    """Error emitting audit event."""

    pass


class ConfigurationError(SafelineError):
    """Configuration error."""

    pass


class RollbackError(SafelineError):
    """Error during rollback."""

    def __init__(self, stage_name: str, message: str) -> None:
        self.stage_name = stage_name
        super().__init__(f"Rollback of stage '{stage_name}' failed: {message}")


class InvalidOperationStateError(SafelineError):
    """Raised when operation is in invalid state for requested action."""

    def __init__(self, operation_id: str, current_state: str, message: str) -> None:
        self.operation_id = operation_id
        self.current_state = current_state
        super().__init__(f"Operation {operation_id} in state {current_state}: {message}")


class StageTimeoutError(SafelineError):
    """Stage execution timed out."""

    def __init__(self, stage_name: str, timeout_seconds: int) -> None:
        self.stage_name = stage_name
        self.timeout_seconds = timeout_seconds
        super().__init__(f"Stage '{stage_name}' timed out after {timeout_seconds}s")
