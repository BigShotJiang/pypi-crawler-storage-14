"""Approval management for Safeline operations."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from sfln.approval.config import ApprovalConfig
from sfln.exceptions import SafelineError
from sfln.logging import get_logger

_logger = get_logger("approval")


def _now_iso() -> str:
    """Get current time as ISO string."""
    return datetime.now(timezone.utc).isoformat()


class ApprovalError(SafelineError):
    """Error related to approval workflow."""

    pass


class ApprovalDeniedError(ApprovalError):
    """Approval was denied."""

    def __init__(self, stage_name: str, reason: str) -> None:
        self.stage_name = stage_name
        self.reason = reason
        super().__init__(f"Approval denied for stage '{stage_name}': {reason}")


class ApprovalExpiredError(ApprovalError):
    """Approval request has expired."""

    def __init__(self, stage_name: str) -> None:
        self.stage_name = stage_name
        super().__init__(f"Approval request for stage '{stage_name}' has expired")


@dataclass
class ApprovalRequest:
    """A request for approval.

    Attributes:
        operation_id: ID of the operation.
        stage_name: Stage requiring approval.
        actor: Who initiated the operation.
        requested_at: When approval was requested.
        expires_at: When the request expires.
        approvals: List of approvals received.
        denials: List of denials received.
        status: Current status (pending, approved, denied, expired).
    """

    operation_id: str
    stage_name: str
    actor: str
    requested_at: str = field(default_factory=_now_iso)
    expires_at: str | None = None
    approvals: list[dict[str, Any]] = field(default_factory=list)
    denials: list[dict[str, Any]] = field(default_factory=list)
    status: str = "pending"

    def to_dict(self) -> dict[str, Any]:
        return {
            "operation_id": self.operation_id,
            "stage_name": self.stage_name,
            "actor": self.actor,
            "requested_at": self.requested_at,
            "expires_at": self.expires_at,
            "approvals": self.approvals,
            "denials": self.denials,
            "status": self.status,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ApprovalRequest:
        return cls(
            operation_id=data["operation_id"],
            stage_name=data["stage_name"],
            actor=data.get("actor", "unknown"),
            requested_at=data.get("requested_at", _now_iso()),
            expires_at=data.get("expires_at"),
            approvals=data.get("approvals", []),
            denials=data.get("denials", []),
            status=data.get("status", "pending"),
        )

    def is_expired(self) -> bool:
        """Check if request has expired."""
        if not self.expires_at:
            return False
        now = datetime.now(timezone.utc)
        expires = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        return now > expires

    def approval_count(self) -> int:
        """Get number of approvals."""
        return len(self.approvals)


class ApprovalManager(ABC):
    """Abstract base class for approval managers."""

    @abstractmethod
    def request_approval(
        self,
        operation_id: str,
        stage_name: str,
        actor: str,
        config: ApprovalConfig,
    ) -> ApprovalRequest:
        """Create an approval request."""
        pass

    @abstractmethod
    def approve(
        self,
        operation_id: str,
        stage_name: str,
        approver: str,
        comment: str = "",
    ) -> ApprovalRequest:
        """Approve a pending request."""
        pass

    @abstractmethod
    def deny(
        self,
        operation_id: str,
        stage_name: str,
        denier: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Deny a pending request."""
        pass

    @abstractmethod
    def get_request(self, operation_id: str, stage_name: str) -> ApprovalRequest | None:
        """Get an approval request."""
        pass

    @abstractmethod
    def is_approved(self, operation_id: str, stage_name: str, config: ApprovalConfig) -> bool:
        """Check if a stage is approved."""
        pass

    @abstractmethod
    def list_pending(self) -> list[ApprovalRequest]:
        """List all pending approval requests."""
        pass


class MemoryApprovalManager(ApprovalManager):
    """In-memory approval manager for testing."""

    def __init__(self) -> None:
        self._requests: dict[str, ApprovalRequest] = {}

    def _key(self, operation_id: str, stage_name: str) -> str:
        return f"{operation_id}:{stage_name}"

    def request_approval(
        self,
        operation_id: str,
        stage_name: str,
        actor: str,
        config: ApprovalConfig,
    ) -> ApprovalRequest:
        key = self._key(operation_id, stage_name)

        now = datetime.now(timezone.utc)
        expires = now + timedelta(hours=config.approval_timeout_hours)

        request = ApprovalRequest(
            operation_id=operation_id,
            stage_name=stage_name,
            actor=actor,
            expires_at=expires.isoformat(),
        )

        self._requests[key] = request
        return request

    def approve(
        self,
        operation_id: str,
        stage_name: str,
        approver: str,
        comment: str = "",
    ) -> ApprovalRequest:
        key = self._key(operation_id, stage_name)
        request = self._requests.get(key)

        if not request:
            raise ApprovalError(f"No pending request for {operation_id}:{stage_name}")

        if request.is_expired():
            request.status = "expired"
            raise ApprovalExpiredError(stage_name)

        if request.status != "pending":
            raise ApprovalError(f"Request is already {request.status}")

        request.approvals.append(
            {
                "approver": approver,
                "comment": comment,
                "approved_at": _now_iso(),
            }
        )

        return request

    def deny(
        self,
        operation_id: str,
        stage_name: str,
        denier: str,
        reason: str = "",
    ) -> ApprovalRequest:
        key = self._key(operation_id, stage_name)
        request = self._requests.get(key)

        if not request:
            raise ApprovalError(f"No pending request for {operation_id}:{stage_name}")

        if request.is_expired():
            request.status = "expired"
            raise ApprovalExpiredError(stage_name)

        request.denials.append(
            {
                "denier": denier,
                "reason": reason,
                "denied_at": _now_iso(),
            }
        )
        request.status = "denied"

        return request

    def get_request(self, operation_id: str, stage_name: str) -> ApprovalRequest | None:
        key = self._key(operation_id, stage_name)
        return self._requests.get(key)

    def is_approved(self, operation_id: str, stage_name: str, config: ApprovalConfig) -> bool:
        request = self.get_request(operation_id, stage_name)
        if not request:
            return False

        if request.is_expired():
            return False

        if request.status == "denied":
            return False

        return request.approval_count() >= config.required_approvers

    def list_pending(self) -> list[ApprovalRequest]:
        pending = []
        for request in self._requests.values():
            if request.status == "pending" and not request.is_expired():
                pending.append(request)
        return pending


class FileApprovalManager(ApprovalManager):
    """File-based approval manager."""

    def __init__(self, data_dir: str | Path) -> None:
        self._data_dir = Path(data_dir)
        self._data_dir.mkdir(parents=True, exist_ok=True)

    def _request_path(self, operation_id: str, stage_name: str) -> Path:
        safe_op = operation_id.replace("/", "_")
        safe_stage = stage_name.replace("/", "_")
        return self._data_dir / f"{safe_op}_{safe_stage}.json"

    def request_approval(
        self,
        operation_id: str,
        stage_name: str,
        actor: str,
        config: ApprovalConfig,
    ) -> ApprovalRequest:
        now = datetime.now(timezone.utc)
        expires = now + timedelta(hours=config.approval_timeout_hours)

        request = ApprovalRequest(
            operation_id=operation_id,
            stage_name=stage_name,
            actor=actor,
            expires_at=expires.isoformat(),
        )

        path = self._request_path(operation_id, stage_name)
        path.write_text(json.dumps(request.to_dict(), indent=2))

        return request

    def approve(
        self,
        operation_id: str,
        stage_name: str,
        approver: str,
        comment: str = "",
    ) -> ApprovalRequest:
        path = self._request_path(operation_id, stage_name)

        if not path.exists():
            raise ApprovalError(f"No pending request for {operation_id}:{stage_name}")

        request = ApprovalRequest.from_dict(json.loads(path.read_text()))

        if request.is_expired():
            request.status = "expired"
            path.write_text(json.dumps(request.to_dict(), indent=2))
            raise ApprovalExpiredError(stage_name)

        if request.status != "pending":
            raise ApprovalError(f"Request is already {request.status}")

        request.approvals.append(
            {
                "approver": approver,
                "comment": comment,
                "approved_at": _now_iso(),
            }
        )

        path.write_text(json.dumps(request.to_dict(), indent=2))
        return request

    def deny(
        self,
        operation_id: str,
        stage_name: str,
        denier: str,
        reason: str = "",
    ) -> ApprovalRequest:
        path = self._request_path(operation_id, stage_name)

        if not path.exists():
            raise ApprovalError(f"No pending request for {operation_id}:{stage_name}")

        request = ApprovalRequest.from_dict(json.loads(path.read_text()))

        if request.is_expired():
            request.status = "expired"
            path.write_text(json.dumps(request.to_dict(), indent=2))
            raise ApprovalExpiredError(stage_name)

        request.denials.append(
            {
                "denier": denier,
                "reason": reason,
                "denied_at": _now_iso(),
            }
        )
        request.status = "denied"

        path.write_text(json.dumps(request.to_dict(), indent=2))
        return request

    def get_request(self, operation_id: str, stage_name: str) -> ApprovalRequest | None:
        path = self._request_path(operation_id, stage_name)
        if not path.exists():
            return None
        return ApprovalRequest.from_dict(json.loads(path.read_text()))

    def is_approved(self, operation_id: str, stage_name: str, config: ApprovalConfig) -> bool:
        request = self.get_request(operation_id, stage_name)
        if not request:
            return False

        if request.is_expired():
            return False

        if request.status == "denied":
            return False

        return request.approval_count() >= config.required_approvers

    def list_pending(self) -> list[ApprovalRequest]:
        pending = []
        for path in self._data_dir.glob("*.json"):
            try:
                request = ApprovalRequest.from_dict(json.loads(path.read_text()))
                if request.status == "pending" and not request.is_expired():
                    pending.append(request)
            except Exception as e:
                _logger.debug("Failed to load approval request from %s: %s", path, e)
        return pending
