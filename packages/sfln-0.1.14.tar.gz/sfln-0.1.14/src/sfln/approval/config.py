"""Approval configuration for Safeline operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ApprovalConfig:
    """Configuration for approval requirements.

    Attributes:
        required_approvers: Number of approvals needed.
        allowed_approvers: List of allowed approver identities (users/groups).
        approval_timeout_hours: Approval request expires after this time.
        auto_approve_dry_run: If True, dry-run operations auto-approve.
        require_different_approver: If True, approver must differ from actor.
    """

    required_approvers: int = 1
    allowed_approvers: list[str] = field(default_factory=list)
    approval_timeout_hours: int = 24
    auto_approve_dry_run: bool = True
    require_different_approver: bool = False

    def is_approver_allowed(self, approver: str) -> bool:
        """Check if an approver is allowed to approve.

        If allowed_approvers is empty, anyone can approve.
        """
        if not self.allowed_approvers:
            return True
        return approver in self.allowed_approvers

    def to_dict(self) -> dict[str, Any]:
        return {
            "required_approvers": self.required_approvers,
            "allowed_approvers": self.allowed_approvers,
            "approval_timeout_hours": self.approval_timeout_hours,
            "auto_approve_dry_run": self.auto_approve_dry_run,
            "require_different_approver": self.require_different_approver,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ApprovalConfig:
        return cls(
            required_approvers=data.get("required_approvers", 1),
            allowed_approvers=data.get("allowed_approvers", []),
            approval_timeout_hours=data.get("approval_timeout_hours", 24),
            auto_approve_dry_run=data.get("auto_approve_dry_run", True),
            require_different_approver=data.get("require_different_approver", False),
        )
