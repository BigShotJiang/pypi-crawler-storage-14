"""Logging configuration for Safeline.

Safeline uses Python's standard logging module. By default, no handlers
are configured (following the library best practice of letting the
application configure logging).

Usage in application code:
    import logging
    logging.getLogger("sfln").setLevel(logging.DEBUG)
    logging.basicConfig()  # Or configure handlers as needed

The logger hierarchy:
    safeline              - Root logger for the framework
    safeline.audit        - Audit-related logging
    safeline.locking      - Lock management logging
    safeline.pipeline     - Pipeline execution logging
    safeline.protection   - Protection level logging
"""

import logging

# Create the root logger for safeline
logger = logging.getLogger("sfln")

# Add a NullHandler to prevent "No handler found" warnings
# Applications should configure their own handlers
logger.addHandler(logging.NullHandler())


def get_logger(name: str) -> logging.Logger:
    """Get a child logger for a safeline component.

    Args:
        name: Component name (e.g., "audit", "locking").

    Returns:
        A logger instance for safeline.{name}.

    Example:
        from sfln.logging import get_logger
        logger = get_logger("audit")
        logger.debug("Processing event")
    """
    return logging.getLogger(f"safeline.{name}")
