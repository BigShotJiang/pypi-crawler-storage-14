"""Protection level registry for Safeline."""

from __future__ import annotations

from pathlib import Path

from sfln.logging import get_logger
from sfln.protection.environment import Environment, detect_environment
from sfln.protection.levels import PROTECTION_LEVELS, ProtectionLevel

_logger = get_logger("protection")


class ProtectionRegistry:
    """Registry for protection levels.

    Manages loading and resolving protection levels from built-in defaults
    and custom configuration files.
    """

    def __init__(
        self,
        config_dir: str | Path | None = None,
        environment_mapping: dict[str, str] | None = None,
    ) -> None:
        """Initialize the registry.

        Args:
            config_dir: Directory to load custom protection levels from.
            environment_mapping: Map of environment names to protection level names.
        """
        self._levels: dict[str, ProtectionLevel] = dict(PROTECTION_LEVELS)
        self._config_dir = Path(config_dir) if config_dir else None
        self._environment_mapping = environment_mapping or {}

        if self._config_dir:
            self._load_custom_levels()

    def _load_custom_levels(self) -> None:
        """Load custom protection levels from config directory."""
        if not self._config_dir or not self._config_dir.exists():
            return

        try:
            import yaml
        except ImportError:
            # YAML support optional
            return

        for path in self._config_dir.glob("*.yaml"):
            try:
                data = yaml.safe_load(path.read_text())
                if isinstance(data, dict):
                    if "protection_levels" in data:
                        # File contains multiple levels
                        for level_data in data["protection_levels"]:
                            level = ProtectionLevel.from_dict(level_data)
                            self._levels[level.name] = level
                    elif "name" in data:
                        # File contains single level
                        level = ProtectionLevel.from_dict(data)
                        self._levels[level.name] = level
            except Exception as e:
                _logger.debug("Failed to load protection level from %s: %s", path, e)

        for path in self._config_dir.glob("*.yml"):
            try:
                data = yaml.safe_load(path.read_text())
                if isinstance(data, dict):
                    if "protection_levels" in data:
                        for level_data in data["protection_levels"]:
                            level = ProtectionLevel.from_dict(level_data)
                            self._levels[level.name] = level
                    elif "name" in data:
                        level = ProtectionLevel.from_dict(data)
                        self._levels[level.name] = level
            except Exception as e:
                _logger.debug("Failed to load protection level from %s: %s", path, e)

    def get(self, name: str) -> ProtectionLevel | None:
        """Get a protection level by name."""
        return self._levels.get(name)

    def get_for_environment(self, environment: str | Environment | None = None) -> ProtectionLevel:
        """Get the protection level for an environment.

        Args:
            environment: Environment name or object. Auto-detects if None.

        Returns:
            The protection level for the environment.
        """
        if environment is None:
            env = detect_environment()
            env_name = env.name
        elif isinstance(environment, Environment):
            env_name = environment.name
        else:
            env_name = environment

        # Check explicit mapping
        if env_name in self._environment_mapping:
            level_name = self._environment_mapping[env_name]
            if level_name in self._levels:
                return self._levels[level_name]

        # Check if environment name matches a level
        if env_name in self._levels:
            return self._levels[env_name]

        # Default mapping based on common patterns
        env_lower = env_name.lower()
        if "prod" in env_lower or "critical" in env_lower:
            return self._levels.get("production", self._levels["development"])
        if "staging" in env_lower or "stage" in env_lower:
            return self._levels.get("staging", self._levels["development"])
        if "test" in env_lower:
            return self._levels.get("testing", self._levels["development"])

        # Fallback to development
        return self._levels["development"]

    def register(self, level: ProtectionLevel) -> None:
        """Register a custom protection level."""
        self._levels[level.name] = level

    def map_environment(self, environment: str, level_name: str) -> None:
        """Map an environment to a protection level."""
        self._environment_mapping[environment] = level_name

    def list_levels(self) -> list[str]:
        """List all registered level names."""
        return list(self._levels.keys())

    def all_levels(self) -> dict[str, ProtectionLevel]:
        """Get all registered levels."""
        return dict(self._levels)


# Global registry instance
_registry: ProtectionRegistry | None = None


def get_registry() -> ProtectionRegistry:
    """Get the global protection registry."""
    global _registry
    if _registry is None:
        _registry = ProtectionRegistry()
    return _registry


def get_protection_level(environment: str | None = None) -> ProtectionLevel:
    """Get protection level for an environment using the global registry."""
    return get_registry().get_for_environment(environment)
