"""Protection levels and environment detection for Safeline."""

from sfln.protection.environment import (
    Environment,
    EnvironmentDetector,
    detect_environment,
    get_environment_name,
)
from sfln.protection.levels import PROTECTION_LEVELS, ProtectionLevel
from sfln.protection.registry import (
    ProtectionRegistry,
    get_protection_level,
    get_registry,
)

__all__ = [
    "Environment",
    "EnvironmentDetector",
    "PROTECTION_LEVELS",
    "ProtectionLevel",
    "ProtectionRegistry",
    "detect_environment",
    "get_environment_name",
    "get_protection_level",
    "get_registry",
]
