"""Protection level definitions for Safeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ProtectionLevel:
    """Defines safety constraints for an environment.

    Protection levels control what operations are allowed and what
    safety measures are required in different environments.

    Attributes:
        name: Level name (e.g., "critical", "standard", "minimal").
        description: Human-readable description.
        require_approval: If True, operations require approval.
        require_audit: If True, operations must be audited.
        require_backup: If True, operations must create backups.
        allow_force: If True, --force flag is allowed.
        simulation_only: If True, only dry-run is allowed.
        max_targets: Maximum number of targets per operation (0 = unlimited).
        max_concurrent: Maximum concurrent operations (0 = unlimited).
        retention_days: How long to keep backups/audit (0 = forever).
        custom_rules: Additional custom rules for the operation.
    """

    name: str
    description: str = ""
    require_approval: bool = False
    require_audit: bool = True
    require_backup: bool = False
    allow_force: bool = True
    simulation_only: bool = False
    max_targets: int = 0
    max_concurrent: int = 0
    retention_days: int = 30
    custom_rules: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "require_approval": self.require_approval,
            "require_audit": self.require_audit,
            "require_backup": self.require_backup,
            "allow_force": self.allow_force,
            "simulation_only": self.simulation_only,
            "max_targets": self.max_targets,
            "max_concurrent": self.max_concurrent,
            "retention_days": self.retention_days,
            "custom_rules": self.custom_rules,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProtectionLevel:
        return cls(
            name=data.get("name", "unknown"),
            description=data.get("description", ""),
            require_approval=data.get("require_approval", False),
            require_audit=data.get("require_audit", True),
            require_backup=data.get("require_backup", False),
            allow_force=data.get("allow_force", True),
            simulation_only=data.get("simulation_only", False),
            max_targets=data.get("max_targets", 0),
            max_concurrent=data.get("max_concurrent", 0),
            retention_days=data.get("retention_days", 30),
            custom_rules=data.get("custom_rules", {}),
        )

    def validate_operation(
        self, target_count: int, is_force: bool = False
    ) -> tuple[bool, str | None]:
        """Validate an operation against this protection level.

        Args:
            target_count: Number of targets in the operation.
            is_force: Whether --force flag is used.

        Returns:
            Tuple of (is_valid, error_message).
        """
        if self.simulation_only:
            return False, f"Protection level '{self.name}' only allows simulation mode"

        if self.max_targets > 0 and target_count > self.max_targets:
            return (
                False,
                f"Target count {target_count} exceeds limit {self.max_targets} "
                f"for protection level '{self.name}'",
            )

        if is_force and not self.allow_force:
            return False, f"Force mode not allowed for protection level '{self.name}'"

        return True, None


# Built-in protection levels
PROTECTION_LEVELS = {
    "critical": ProtectionLevel(
        name="critical",
        description="Maximum protection for critical systems",
        require_approval=True,
        require_audit=True,
        require_backup=True,
        allow_force=False,
        simulation_only=False,
        max_targets=10,
        retention_days=365,
    ),
    "production": ProtectionLevel(
        name="production",
        description="Standard production protection",
        require_approval=True,
        require_audit=True,
        require_backup=True,
        allow_force=False,
        max_targets=100,
        retention_days=90,
    ),
    "staging": ProtectionLevel(
        name="staging",
        description="Staging environment protection",
        require_approval=False,
        require_audit=True,
        require_backup=True,
        allow_force=True,
        max_targets=1000,
        retention_days=30,
    ),
    "development": ProtectionLevel(
        name="development",
        description="Development environment - minimal restrictions",
        require_approval=False,
        require_audit=False,
        require_backup=False,
        allow_force=True,
        max_targets=0,
        retention_days=7,
    ),
    "testing": ProtectionLevel(
        name="testing",
        description="Testing environment - no restrictions",
        require_approval=False,
        require_audit=False,
        require_backup=False,
        allow_force=True,
        max_targets=0,
        retention_days=1,
    ),
}
