"""Environment detection for Safeline."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sfln.logging import get_logger

_logger = get_logger("protection")


@dataclass
class Environment:
    """Detected environment information.

    Attributes:
        name: Environment name (e.g., "prod", "staging", "dev").
        signature: Optional signature to verify environment.
        source: How the environment was detected.
        metadata: Additional environment metadata.
    """

    name: str
    signature: str | None = None
    source: str = "default"
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "signature": self.signature,
            "source": self.source,
            "metadata": self.metadata or {},
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Environment:
        return cls(
            name=data.get("name", "unknown"),
            signature=data.get("signature"),
            source=data.get("source", "dict"),
            metadata=data.get("metadata"),
        )


class EnvironmentDetector:
    """Detects the current environment.

    Detection priority:
    1. Environment variable (SAFELINE_ENVIRONMENT)
    2. Environment file (/etc/safeline/environment)
    3. Default fallback
    """

    ENV_VAR = "SAFELINE_ENVIRONMENT"
    ENV_FILE = "/etc/safeline/environment"

    def __init__(
        self,
        env_var: str | None = None,
        env_file: str | Path | None = None,
        default: str = "development",
    ) -> None:
        """Initialize the detector.

        Args:
            env_var: Environment variable to check (default: SAFELINE_ENVIRONMENT).
            env_file: File to read environment from (default: /etc/safeline/environment).
            default: Default environment if not detected.
        """
        self._env_var = env_var or self.ENV_VAR
        self._env_file = Path(env_file) if env_file else Path(self.ENV_FILE)
        self._default = default

    def detect(self) -> Environment:
        """Detect the current environment.

        Returns:
            Detected Environment.
        """
        # Check environment variable first
        env_value = os.environ.get(self._env_var)
        if env_value:
            return Environment(
                name=env_value,
                source=f"env:{self._env_var}",
            )

        # Check environment file
        if self._env_file.exists():
            try:
                content = self._env_file.read_text().strip()
                lines = content.split("\n")

                name = None
                signature = None
                metadata: dict[str, Any] = {}

                for line in lines:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue

                    if "=" in line:
                        key, value = line.split("=", 1)
                        key = key.strip().upper()
                        value = value.strip().strip("\"'")

                        if key == "NAME" or key == "ENVIRONMENT":
                            name = value
                        elif key == "SIGNATURE":
                            signature = value
                        else:
                            metadata[key.lower()] = value
                    elif not name:
                        # First non-empty line is the environment name
                        name = line

                if name:
                    return Environment(
                        name=name,
                        signature=signature,
                        source=f"file:{self._env_file}",
                        metadata=metadata if metadata else None,
                    )

            except Exception as e:
                _logger.debug("Failed to read environment file %s: %s", self._env_file, e)

        # Return default
        return Environment(
            name=self._default,
            source="default",
        )


# Global detector instance
_detector = EnvironmentDetector()


def detect_environment() -> Environment:
    """Detect the current environment using the global detector."""
    return _detector.detect()


def get_environment_name() -> str:
    """Get just the environment name."""
    return _detector.detect().name
