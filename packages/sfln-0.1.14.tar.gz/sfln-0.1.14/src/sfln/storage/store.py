"""Operation storage for Safeline."""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from sfln.core.context import Context
from sfln.core.result import CleanupResult, OperationState, OperationSummary
from sfln.core.stage import StageState, StageStatus
from sfln.exceptions import OperationNotFoundError

if TYPE_CHECKING:
    from sfln.core.operation import Operation


class OperationStore(ABC):
    """Abstract base class for operation storage."""

    @abstractmethod
    def save(
        self,
        operation_id: str,
        operation: Operation,
        context: Context,
        stage_statuses: dict[str, StageStatus],
        state: OperationState,
    ) -> None:
        """Save a new operation."""
        pass

    @abstractmethod
    def load_operation(self, operation_id: str) -> Operation | None:
        """Load an operation instance by ID."""
        pass

    @abstractmethod
    def load_state(
        self, operation_id: str
    ) -> tuple[Context, dict[str, StageStatus], OperationState]:
        """Load operation state."""
        pass

    @abstractmethod
    def update_stage_status(self, operation_id: str, status: StageStatus) -> None:
        """Update a stage's status."""
        pass

    @abstractmethod
    def update_state(self, operation_id: str, state: OperationState) -> None:
        """Update operation state."""
        pass

    @abstractmethod
    def exists(self, operation_id: str) -> bool:
        """Check if operation exists."""
        pass

    @abstractmethod
    def delete(self, operation_id: str) -> None:
        """Delete an operation."""
        pass

    @abstractmethod
    def list_operations(
        self,
        state: OperationState | None = None,
        environment: str | None = None,
        operation_type: str | None = None,
        actor: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[OperationSummary]:
        """List operations with filtering.

        Args:
            state: Filter by operation state
            environment: Filter by environment name
            operation_type: Filter by operation type
            actor: Filter by actor name
            since: Only operations created after this time
            until: Only operations created before this time
            limit: Maximum number of results (default 100, max 1000)
            offset: Skip first N results (default 0)

        Returns:
            List of operation summaries
        """
        pass

    @abstractmethod
    def cleanup(
        self,
        retention_days: int,
        environment: str | None = None,
        dry_run: bool = False,
    ) -> CleanupResult:
        """Remove operations older than retention period.

        Args:
            retention_days: Remove operations older than this many days
            environment: Only cleanup operations in this environment (optional)
            dry_run: If True, return what would be removed without removing

        Returns:
            Cleanup result with statistics
        """
        pass


class MemoryStore(OperationStore):
    """In-memory operation store for testing."""

    def __init__(self) -> None:
        self._operations: dict[str, dict[str, Any]] = {}
        self._operation_instances: dict[str, Operation] = {}

    def save(
        self,
        operation_id: str,
        operation: Operation,
        context: Context,
        stage_statuses: dict[str, StageStatus],
        state: OperationState,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self._operations[operation_id] = {
            "operation_def": operation.to_dict(),
            "context": context.to_dict(),
            "stage_statuses": {name: status.to_dict() for name, status in stage_statuses.items()},
            "state": state.value,
            "created_at": now,
            "started_at": None,
            "completed_at": None,
        }
        self._operation_instances[operation_id] = operation

    def load_operation(self, operation_id: str) -> Operation | None:
        return self._operation_instances.get(operation_id)

    def load_state(
        self, operation_id: str
    ) -> tuple[Context, dict[str, StageStatus], OperationState]:
        if operation_id not in self._operations:
            raise OperationNotFoundError(operation_id)

        data = self._operations[operation_id]
        context = Context.from_dict(data["context"])

        # Reconstruct stage statuses
        operation = self._operation_instances[operation_id]
        stage_statuses = {}
        for stage in operation.stages:
            status_data = data["stage_statuses"].get(stage.name, {})
            stage_statuses[stage.name] = StageStatus.from_dict(status_data, stage)

        state = OperationState(data["state"])
        return context, stage_statuses, state

    def update_stage_status(self, operation_id: str, status: StageStatus) -> None:
        if operation_id not in self._operations:
            raise OperationNotFoundError(operation_id)
        self._operations[operation_id]["stage_statuses"][status.stage.name] = status.to_dict()

    def update_state(self, operation_id: str, state: OperationState) -> None:
        if operation_id not in self._operations:
            raise OperationNotFoundError(operation_id)

        data = self._operations[operation_id]
        data["state"] = state.value

        # Track started_at and completed_at
        now = datetime.now(timezone.utc).isoformat()
        if state == OperationState.RUNNING and data["started_at"] is None:
            data["started_at"] = now
        elif state in (
            OperationState.COMPLETED,
            OperationState.FAILED,
            OperationState.ABANDONED,
            OperationState.ROLLED_BACK,
        ):
            data["completed_at"] = now

    def exists(self, operation_id: str) -> bool:
        return operation_id in self._operations

    def delete(self, operation_id: str) -> None:
        self._operations.pop(operation_id, None)
        self._operation_instances.pop(operation_id, None)

    def list_operations(
        self,
        state: OperationState | None = None,
        environment: str | None = None,
        operation_type: str | None = None,
        actor: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[OperationSummary]:
        results = []

        for op_id, data in self._operations.items():
            # Apply filters
            if state is not None and data["state"] != state.value:
                continue

            context = data["context"]
            if environment is not None and context["environment"] != environment:
                continue
            if actor is not None and context["actor"] != actor:
                continue

            operation_def = data["operation_def"]
            if operation_type is not None and operation_def["name"] != operation_type:
                continue

            # Time filtering
            created_at_str = data.get("created_at")
            if created_at_str:
                created_at = datetime.fromisoformat(created_at_str)
                if since and created_at < since:
                    continue
                if until and created_at > until:
                    continue

            # Count stages
            stage_statuses = data["stage_statuses"]
            stages_completed = sum(
                1 for s in stage_statuses.values() if s.get("state") == StageState.COMPLETED.value
            )
            stages_failed = sum(
                1 for s in stage_statuses.values() if s.get("state") == StageState.FAILED.value
            )
            stages_total = len(stage_statuses)

            # Build summary
            summary = OperationSummary(
                operation_id=op_id,
                operation_type=operation_def["name"],
                state=OperationState(data["state"]),
                environment=context["environment"],
                actor=context["actor"],
                targets=context["targets"],
                created_at=data.get("created_at", ""),
                started_at=data.get("started_at"),
                completed_at=data.get("completed_at"),
                stages_completed=stages_completed,
                stages_failed=stages_failed,
                stages_total=stages_total,
                error=None,  # Could extract from stage results if needed
            )
            results.append(summary)

        # Apply offset and limit
        results = results[offset : offset + limit]
        return results

    def cleanup(
        self,
        retention_days: int,
        environment: str | None = None,
        dry_run: bool = False,
    ) -> CleanupResult:
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        removed_ids = []
        kept_count = 0
        bytes_freed = 0

        for op_id, data in list(self._operations.items()):
            # Filter by environment if specified
            if environment is not None and data["context"]["environment"] != environment:
                kept_count += 1
                continue

            # Check age
            created_at_str = data.get("created_at")
            if not created_at_str:
                kept_count += 1
                continue

            created_at = datetime.fromisoformat(created_at_str)
            if created_at >= cutoff:
                kept_count += 1
                continue

            # Mark for removal
            removed_ids.append(op_id)

            # Calculate approximate size (in-memory, just estimate)
            bytes_freed += len(str(data))

            # Actually remove if not dry run
            if not dry_run:
                del self._operations[op_id]
                self._operation_instances.pop(op_id, None)

        return CleanupResult(
            operations_removed=len(removed_ids),
            operations_kept=kept_count,
            bytes_freed=bytes_freed,
            dry_run=dry_run,
            removed_operation_ids=removed_ids,
        )


class FileStore(OperationStore):
    """File-based operation store."""

    # Registry of operation classes by name for reconstruction
    _operation_classes: dict[str, type[Operation]] = {}

    @classmethod
    def register_operation_class(cls, operation_class: type[Operation]) -> None:
        """Register an operation class for reconstruction from stored data.

        This allows FileStore to reconstruct Operation instances when loading
        from JSON files. The operation class must implement from_dict().

        Args:
            operation_class: The Operation subclass to register.
        """
        cls._operation_classes[operation_class.name] = operation_class

    def __init__(self, data_dir: str | Path) -> None:
        self._data_dir = Path(data_dir)
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._operation_instances: dict[str, Operation] = {}

    def _operation_path(self, operation_id: str) -> Path:
        return self._data_dir / f"{operation_id}.json"

    def save(
        self,
        operation_id: str,
        operation: Operation,
        context: Context,
        stage_statuses: dict[str, StageStatus],
        state: OperationState,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        data = {
            "operation_def": operation.to_dict(),
            "context": context.to_dict(),
            "stage_statuses": {name: status.to_dict() for name, status in stage_statuses.items()},
            "state": state.value,
            "created_at": now,
            "started_at": None,
            "completed_at": None,
        }
        path = self._operation_path(operation_id)
        path.write_text(json.dumps(data, indent=2))
        self._operation_instances[operation_id] = operation

    def load_operation(self, operation_id: str) -> Operation | None:
        """Load operation instance, reconstructing from stored JSON if possible."""
        # First check in-memory cache
        if operation_id in self._operation_instances:
            return self._operation_instances[operation_id]

        # Try to reconstruct from stored JSON
        path = self._operation_path(operation_id)
        if not path.exists():
            return None

        try:
            data = json.loads(path.read_text())
            operation_def = data.get("operation_def", {})
            operation_name = operation_def.get("name")

            # Look up operation class in registry
            if operation_name and operation_name in self._operation_classes:
                operation_class = self._operation_classes[operation_name]
                # Reconstruct operation from stored definition
                if hasattr(operation_class, "from_dict"):
                    operation = operation_class.from_dict(operation_def)
                else:
                    # Fallback: create with targets and metadata
                    targets = operation_def.get("targets", [])
                    metadata = operation_def.get("metadata", {})
                    operation = operation_class(targets=targets, metadata=metadata)
                self._operation_instances[operation_id] = operation
                return cast("Operation", operation)
        except (json.JSONDecodeError, OSError, KeyError, TypeError):
            pass

        return None

    def load_state(
        self, operation_id: str
    ) -> tuple[Context, dict[str, StageStatus], OperationState]:
        path = self._operation_path(operation_id)
        if not path.exists():
            raise OperationNotFoundError(operation_id)

        data = json.loads(path.read_text())
        context = Context.from_dict(data["context"])

        # Reconstruct stage statuses
        operation = self._operation_instances.get(operation_id)
        if not operation:
            raise OperationNotFoundError(operation_id)

        stage_statuses = {}
        for stage in operation.stages:
            status_data = data["stage_statuses"].get(stage.name, {})
            stage_statuses[stage.name] = StageStatus.from_dict(status_data, stage)

        # Populate context.stage_results from completed stage statuses
        # This ensures stage results are available via context.get_stage_result()
        for stage_name, status in stage_statuses.items():
            if status.state == StageState.COMPLETED and status.result_data:
                context.stage_results[stage_name] = status.result_data

        state = OperationState(data["state"])
        return context, stage_statuses, state

    def update_stage_status(self, operation_id: str, status: StageStatus) -> None:
        path = self._operation_path(operation_id)
        if not path.exists():
            raise OperationNotFoundError(operation_id)

        data = json.loads(path.read_text())
        data["stage_statuses"][status.stage.name] = status.to_dict()
        path.write_text(json.dumps(data, indent=2))

    def update_state(self, operation_id: str, state: OperationState) -> None:
        path = self._operation_path(operation_id)
        if not path.exists():
            raise OperationNotFoundError(operation_id)

        data = json.loads(path.read_text())
        data["state"] = state.value

        # Track started_at and completed_at
        now = datetime.now(timezone.utc).isoformat()
        if state == OperationState.RUNNING and data.get("started_at") is None:
            data["started_at"] = now
        elif state in (
            OperationState.COMPLETED,
            OperationState.FAILED,
            OperationState.ABANDONED,
            OperationState.ROLLED_BACK,
        ):
            data["completed_at"] = now

        path.write_text(json.dumps(data, indent=2))

    def exists(self, operation_id: str) -> bool:
        return self._operation_path(operation_id).exists()

    def delete(self, operation_id: str) -> None:
        path = self._operation_path(operation_id)
        if path.exists():
            path.unlink()
        self._operation_instances.pop(operation_id, None)

    def list_operations(
        self,
        state: OperationState | None = None,
        environment: str | None = None,
        operation_type: str | None = None,
        actor: str | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[OperationSummary]:
        results = []

        # Iterate through all operation files
        for path in sorted(self._data_dir.glob("op-*.json"), reverse=True):
            try:
                data = json.loads(path.read_text())
            except (json.JSONDecodeError, OSError):
                continue

            # Apply filters
            if state is not None and data.get("state") != state.value:
                continue

            context = data.get("context", {})
            if environment is not None and context.get("environment") != environment:
                continue
            if actor is not None and context.get("actor") != actor:
                continue

            operation_def = data.get("operation_def", {})
            if operation_type is not None and operation_def.get("name") != operation_type:
                continue

            # Time filtering
            created_at_str = data.get("created_at")
            if created_at_str:
                created_at = datetime.fromisoformat(created_at_str)
                if since and created_at < since:
                    continue
                if until and created_at > until:
                    continue

            # Count stages
            stage_statuses = data.get("stage_statuses", {})
            stages_completed = sum(
                1 for s in stage_statuses.values() if s.get("state") == StageState.COMPLETED.value
            )
            stages_failed = sum(
                1 for s in stage_statuses.values() if s.get("state") == StageState.FAILED.value
            )
            stages_total = len(stage_statuses)

            # Build summary
            summary = OperationSummary(
                operation_id=path.stem,
                operation_type=operation_def.get("name", "unknown"),
                state=OperationState(data.get("state", "created")),
                environment=context.get("environment", "unknown"),
                actor=context.get("actor", "unknown"),
                targets=context.get("targets", []),
                created_at=data.get("created_at", ""),
                started_at=data.get("started_at"),
                completed_at=data.get("completed_at"),
                stages_completed=stages_completed,
                stages_failed=stages_failed,
                stages_total=stages_total,
                error=None,
            )
            results.append(summary)

        # Apply offset and limit
        results = results[offset : offset + limit]
        return results

    def cleanup(
        self,
        retention_days: int,
        environment: str | None = None,
        dry_run: bool = False,
    ) -> CleanupResult:
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        removed_ids = []
        kept_count = 0
        bytes_freed = 0

        for path in self._data_dir.glob("op-*.json"):
            try:
                data = json.loads(path.read_text())
            except (json.JSONDecodeError, OSError):
                kept_count += 1
                continue

            # Filter by environment if specified
            if environment is not None:
                context = data.get("context", {})
                if context.get("environment") != environment:
                    kept_count += 1
                    continue

            # Check age
            created_at_str = data.get("created_at")
            if not created_at_str:
                kept_count += 1
                continue

            created_at = datetime.fromisoformat(created_at_str)
            if created_at >= cutoff:
                kept_count += 1
                continue

            # Mark for removal
            op_id = path.stem
            removed_ids.append(op_id)
            bytes_freed += path.stat().st_size

            # Actually remove if not dry run
            if not dry_run:
                path.unlink()
                self._operation_instances.pop(op_id, None)

        return CleanupResult(
            operations_removed=len(removed_ids),
            operations_kept=kept_count,
            bytes_freed=bytes_freed,
            dry_run=dry_run,
            removed_operation_ids=removed_ids,
        )

    def register_operation(self, operation_id: str, operation: Operation) -> None:
        """Register an operation instance for an existing stored operation."""
        self._operation_instances[operation_id] = operation
