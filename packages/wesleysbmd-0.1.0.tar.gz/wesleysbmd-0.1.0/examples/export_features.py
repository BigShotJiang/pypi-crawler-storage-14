#!/usr/bin/env -S uv run --quiet --script
# /// script
# requires-python = ">=3.10"
# dependencies = []
# ///

"""
BlockMD Feature Exporter - Export all feature blocks as tree view.

This script demonstrates using BMD query API to filter and display
blocks with type='feature' in a hierarchical tree format.

Usage:
    ./export_features.py
    uv run export_features.py
"""

import sys
from pathlib import Path

# Add src to path for local development
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

from query import query


def main():
    """Export all feature blocks from demo.bmd as tree view."""
    
    # Get the demo file path
    demo_file = Path(__file__).parent / "demo.bmd"
    
    if not demo_file.exists():
        print(f"Error: {demo_file} not found!", file=sys.stderr)
        sys.exit(1)
    
    print("=" * 60)
    print("BlockMD Feature Exporter")
    print("=" * 60)
    print(f"Source: {demo_file.name}")
    print()
    
    # Query and filter features
    result = (query()
        .from_path(str(demo_file))
        .where(type='feature')
        .view('tree')
    )
    
    print(result)
    
    # Also show statistics
    print()
    print("-" * 60)
    
    q = query().from_path(str(demo_file))
    total_blocks = q.count()
    feature_blocks = q.where(type='feature').count()
    
    print(f"Statistics:")
    print(f"  Total blocks: {total_blocks}")
    print(f"  Feature blocks: {feature_blocks}")
    print(f"  Percentage: {feature_blocks/total_blocks*100:.1f}%")
    

if __name__ == "__main__":
    main()
