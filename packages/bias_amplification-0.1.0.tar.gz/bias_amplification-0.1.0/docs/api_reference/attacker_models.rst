ANN
===

Simple Dense Model
------------------

.. autoclass:: bias_amplification.attacker_models.ANN.simpleDenseModel
   :members: __init__, initLayers, filterActivations, forward, count_params
   :show-inheritance:
   :special-members: __init__
   :inherited-members: False