Bias Amplification Documentation
================================

Welcome to the Bias Amplification library documentation!

This library provides tools for measuring bias amplification and information leakage
in machine learning models.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api_reference/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
