# XGM_devtest_xy

XGM MDS24 设备驱动包

## 安装

```bash
pip install XGM_devtest_xy
```

## 使用

安装后，使用以下方式导入：

```python
import systemq_xy
from systemq_xy.XGM_MDS24 import Driver
```

## 版本信息

- 版本：V1.2-20250719
- XY 驱动版本：V1.0-20250523

## 依赖

- quarkstudio[remote]
- waveforms
- numpy

## 许可证

MIT License
