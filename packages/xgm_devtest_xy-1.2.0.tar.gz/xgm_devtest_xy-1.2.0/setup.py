from setuptools import setup, find_packages
from pathlib import Path

# 读取 README.md 作为长描述
readme_file = Path(__file__).parent / "README.md"
if readme_file.exists():
    with open(readme_file, encoding='utf-8') as f:
        long_description = f.read()
else:
    long_description = "XGM MDS24 设备驱动"

# 读取 requirements.txt
requirements_file = Path(__file__).parent / "requirements.txt"
if requirements_file.exists():
    with open(requirements_file, encoding='utf-8') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]
else:
    requirements = []

setup(
    name="XGM_devtest_xy",  # PyPI 上的包名
    version='1.2.0',
    author="baqis",
    author_email="baqis@baqis.ac.cn",
    url="https://gitee.com/",
    license="MIT",
    keywords="XGM MDS24 device driver",
    description="XGM MDS24 设备驱动",
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=["systemq_xy"],  # 指定包名，这是用户导入时使用的名称
    include_package_data=True,
    install_requires=requirements,
    python_requires='>=3.8.0',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: Chinese (Simplified)',
        'Natural Language :: English',
        'Operating System :: Microsoft :: Windows',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Physics',
    ],
    project_urls={
        'Source': 'https://gitee.com/',
    },
)
