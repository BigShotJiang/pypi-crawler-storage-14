# datacrunch is now verda

This package has been [renamed](https://verda.com/blog/datacrunch-is-changing-its-name-to-verda). Use `pip install verda` or `uv add verda` instead.

New package: https://pypi.org/project/verda/
