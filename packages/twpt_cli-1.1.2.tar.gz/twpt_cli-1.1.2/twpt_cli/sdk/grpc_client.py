"""gRPC client for ThreatWinds Pentest API."""

import asyncio
import threading
from typing import Optional, AsyncIterator, Dict, Any
from contextlib import asynccontextmanager

import grpc
from grpc import aio

from .models import Credentials


class GRPCClient:
    """gRPC client for ThreatWinds Pentest API streaming operations."""

    def __init__(self, address: str, credentials: Credentials):
        """Initialize gRPC client.

        Args:
            address: gRPC server address (e.g., "localhost:9742")
            credentials: API credentials for authentication
        """
        self.address = address
        self.credentials = credentials
        self.channel: Optional[grpc.aio.Channel] = None
        self.stub = None
        self._lock = threading.Lock()

    def _get_metadata(self) -> list:
        """Get authentication metadata for gRPC calls."""
        return [
            ('api-key', self.credentials.api_key),
            ('api-secret', self.credentials.api_secret),
        ]

    async def connect(self):
        """Establish connection to gRPC server."""
        if not self.channel:
            # Create an insecure channel (matching Go implementation)
            self.channel = grpc.aio.insecure_channel(self.address)

            # Dynamically import generated protobuf code
            # This will be generated from the .proto file
            try:
                from . import pentest_pb2_grpc
                self.stub = pentest_pb2_grpc.PentestServiceStub(self.channel)
            except ImportError:
                # If protobuf files aren't generated yet, provide instructions
                raise ImportError(
                    "gRPC protobuf files not generated. Run:\n"
                    "python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. "
                    "twpt_cli/sdk/pentest.proto"
                )

    async def close(self):
        """Close the gRPC connection."""
        if self.channel:
            await self.channel.close()
            self.channel = None
            self.stub = None

    @asynccontextmanager
    async def pentest_stream(self):
        """Create a bidirectional streaming connection.

        Yields:
            A tuple of (request_queue, response_iterator) for bidirectional streaming

        Example:
            async with client.pentest_stream() as (request_queue, response_stream):
                # Send requests
                await request_queue.put(schedule_request)

                # Receive responses
                async for response in response_stream:
                    handle_response(response)
        """
        if not self.stub:
            await self.connect()

        # Create a queue for outgoing requests
        request_queue = asyncio.Queue()

        async def request_iterator():
            """Generate requests from the queue."""
            while True:
                request = await request_queue.get()
                if request is None:  # Sentinel to close stream
                    break
                yield request

        # Start the bidirectional stream
        response_stream = self.stub.PentestStream(
            request_iterator(),
            metadata=self._get_metadata()
        )

        try:
            yield (request_queue, response_stream)
        finally:
            # Send sentinel to close the request stream
            await request_queue.put(None)

    async def schedule_pentest_stream(self, request_dict: Dict[str, Any]) -> AsyncIterator:
        """Schedule a pentest and stream real-time updates.

        Args:
            request_dict: Dictionary with pentest configuration

        Yields:
            Response messages from the server

        Example:
            request = {
                'style': 'AGGRESSIVE',
                'exploit': True,
                'targets': [
                    {'target': 'example.com', 'scope': 'TARGETED', 'type': 'BLACK_BOX'}
                ]
            }

            async for response in client.schedule_pentest_stream(request):
                print(response)
        """
        try:
            from . import pentest_pb2

            # Convert dict to protobuf message
            targets = []
            for target_dict in request_dict.get('targets', []):
                target = pentest_pb2.TargetRequest(
                    target=target_dict['target'],
                    scope=getattr(pentest_pb2.Scope, target_dict.get('scope', 'TARGETED')),
                    type=getattr(pentest_pb2.Type, target_dict.get('type', 'BLACK_BOX'))
                )
                if 'credentials' in target_dict:
                    target.credentials = str(target_dict['credentials'])
                targets.append(target)

            schedule_request = pentest_pb2.SchedulePentestRequest(
                style=getattr(pentest_pb2.Style, request_dict.get('style', 'AGGRESSIVE')),
                exploit=request_dict.get('exploit', True),
                targets=targets
            )

            # Wrap in ClientRequest
            client_request = pentest_pb2.ClientRequest(
                schedule_pentest=schedule_request
            )

            async with self.pentest_stream() as (request_queue, response_stream):
                # Send the schedule request
                await request_queue.put(client_request)

                # Yield responses as they come
                async for response in response_stream:
                    yield self._parse_response(response)

        except ImportError:
            raise ImportError(
                "gRPC protobuf files not generated. Run:\n"
                "python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. "
                "twpt_cli/sdk/pentest.proto"
            )

    async def watch_pentest_stream(self, pentest_id: str) -> AsyncIterator:
        """Watch an existing pentest and stream real-time updates.

        Args:
            pentest_id: ID of the pentest to watch

        Yields:
            Response messages from the server

        Example:
            async for response in client.watch_pentest_stream("pentest-uuid"):
                print(response)
        """
        try:
            from . import pentest_pb2

            # Create GetPentestRequest
            get_request = pentest_pb2.GetPentestRequest(
                pentest_id=pentest_id
            )

            # Wrap in ClientRequest
            client_request = pentest_pb2.ClientRequest(
                get_pentest=get_request
            )

            async with self.pentest_stream() as (request_queue, response_stream):
                # Send the get request to subscribe to updates
                await request_queue.put(client_request)

                # Yield responses as they come
                async for response in response_stream:
                    yield self._parse_response(response)

        except ImportError:
            raise ImportError(
                "gRPC protobuf files not generated. Run:\n"
                "python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. "
                "twpt_cli/sdk/pentest.proto"
            )

    def _parse_response(self, response) -> Dict[str, Any]:
        """Parse a ServerResponse protobuf message into a dictionary.

        Args:
            response: ServerResponse protobuf message

        Returns:
            Dictionary with parsed response data
        """
        from . import pentest_pb2

        response_type = response.WhichOneof('response_type')

        if response_type == 'schedule_response':
            return {
                'type': 'schedule_response',
                'pentest_id': response.schedule_response.pentest_id,
                'message': response.schedule_response.message
            }

        elif response_type == 'pentest_data':
            data = response.pentest_data
            return self._parse_pentest_data(data)

        elif response_type == 'status_update':
            update = response.status_update
            return {
                'type': 'status_update',
                'update_type': update.type,
                'pentest_id': update.pentest_id,
                'message': update.message if update.HasField('message') else None,
                'data': self._parse_pentest_data(update.data)
                        if update.HasField('data') else None
            }

        elif response_type == 'error':
            return {
                'type': 'error',
                'error': response.error.error,
                'details': response.error.details
            }

        return {'type': 'unknown', 'data': str(response)}

    def _parse_pentest_data(self, data) -> Dict[str, Any]:
        """Parse a PentestData protobuf message into a dictionary.

        Args:
            data: PentestData protobuf message

        Returns:
            Dictionary with parsed pentest data
        """
        from . import pentest_pb2

        return {
            'type': 'pentest_data',
            'id': data.id,
            'status': pentest_pb2.Status.Name(data.status),
            'style': pentest_pb2.Style.Name(data.style),
            'exploit': data.exploit,
            'created_at': data.created_at if data.HasField('created_at') else None,
            'started_at': data.started_at if data.HasField('started_at') else None,
            'finished_at': data.finished_at if data.HasField('finished_at') else None,
            'severity': pentest_pb2.Severity.Name(data.severity) if data.HasField('severity') else None,
            'findings': data.findings if data.HasField('findings') else 0,
            'targets': [self._parse_target(t) for t in data.targets]
        }

    def _parse_target(self, target) -> Dict[str, Any]:
        """Parse a TargetData protobuf message.

        Args:
            target: TargetData protobuf message

        Returns:
            Dictionary with parsed target data
        """
        from . import pentest_pb2

        return {
            'id': target.id,
            'pentest_id': target.pentest_id,
            'target': target.target,
            'scope': pentest_pb2.Scope.Name(target.scope),
            'type': pentest_pb2.Type.Name(target.type),
            'status': pentest_pb2.Status.Name(target.status),
            'phase': pentest_pb2.Phase.Name(target.phase) if target.HasField('phase') else None,
            'severity': pentest_pb2.Severity.Name(target.severity) if target.HasField('severity') else None,
            'findings': target.findings if target.HasField('findings') else 0,
        }


# Synchronous wrapper for easier CLI usage
class SyncGRPCClient:
    """Synchronous wrapper for the async gRPC client."""

    def __init__(self, address: str, credentials: Credentials):
        """Initialize synchronous gRPC client wrapper.

        Args:
            address: gRPC server address
            credentials: API credentials
        """
        self.async_client = GRPCClient(address, credentials)
        self._loop = None
        self._thread = None

    def _ensure_loop(self):
        """Ensure event loop is running in a separate thread."""
        if self._loop is None:
            import threading

            self._loop = asyncio.new_event_loop()

            def run_loop():
                asyncio.set_event_loop(self._loop)
                self._loop.run_forever()

            self._thread = threading.Thread(target=run_loop, daemon=True)
            self._thread.start()

    def schedule_pentest_stream(self, request_dict: Dict[str, Any], callback):
        """Schedule a pentest and stream updates via callback.

        Args:
            request_dict: Pentest configuration
            callback: Function to call with each response

        Example:
            def handle_response(response):
                print(f"Got response: {response}")

            client.schedule_pentest_stream(request, handle_response)
        """
        self._ensure_loop()

        async def stream_handler():
            async for response in self.async_client.schedule_pentest_stream(request_dict):
                callback(response)

        future = asyncio.run_coroutine_threadsafe(stream_handler(), self._loop)
        return future

    def close(self):
        """Close the client and cleanup resources."""
        if self._loop:
            future = asyncio.run_coroutine_threadsafe(
                self.async_client.close(),
                self._loop
            )
            future.result()
            self._loop.call_soon_threadsafe(self._loop.stop)
            if self._thread:
                self._thread.join(timeout=5)
            self._loop = None
            self._thread = None