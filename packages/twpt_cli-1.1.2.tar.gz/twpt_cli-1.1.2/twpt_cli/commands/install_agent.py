"""Install local ThreatWinds Pentest Agent command."""

import sys
import click
from rich.console import Console

from twpt_cli.config.constants import SERVICE_NAME
from twpt_cli.service import (
    download_agent,
    extract_agent,
    setup_python_environment,
    install_service,
    start_agent_service,
    is_service_installed,
    is_service_running,
    get_agent_path,
    check_linux_only,
    check_root_privileges,
)

console = Console()


@click.command()
@click.option(
    '--reinstall',
    is_flag=True,
    help='Reinstall agent even if already installed'
)
def install_agent(reinstall: bool):
    """Install ThreatWinds Pentest Agent as a local service.

    LINUX ONLY: This command installs the ThreatWinds agent as a systemd
    service on your local Linux system (Kali or Ubuntu).

    Requirements:
    - Linux (Kali Linux or Ubuntu)
    - Root/sudo privileges
    - Python 3.8+
    - Internet connection

    The agent will be installed as a systemd service and will:
    - Start automatically on boot
    - Listen on port 9741 (HTTP API)
    - Listen on port 9742 (gRPC streaming)

    Examples:
        sudo twpt-cli install-agent              # Install agent
        sudo twpt-cli install-agent --reinstall  # Reinstall agent

    Note: This command requires sudo privileges.
    """
    console.print("\n╔════════════════════════════════════════════╗", style="cyan")
    console.print("║   ThreatWinds Agent Local Installation     ║", style="cyan")
    console.print("╚════════════════════════════════════════════╝\n", style="cyan")

    # Check if running on Linux
    if not check_linux_only():
        sys.exit(1)

    # Check for root privileges
    if not check_root_privileges():
        sys.exit(1)

    # Check if already installed
    if is_service_installed() and not reinstall:
        console.print("✓ Agent service is already installed", style="green")

        if is_service_running():
            console.print("✓ Agent service is running", style="green")
            console.print("\n  API: http://localhost:9741", style="cyan")
            console.print("  gRPC: localhost:9742", style="cyan")
        else:
            console.print("⚠ Agent service is not running", style="yellow")
            console.print(f"  Start with: systemctl start {SERVICE_NAME}", style="dim")

        console.print("\nUse --reinstall to reinstall", style="dim")
        return

    console.print("Installing ThreatWinds Pentest Agent...\n", style="cyan")

    # Step 1: Download agent
    console.print("Step 1: Downloading agent package...", style="cyan bold")
    zip_path = download_agent()
    if not zip_path:
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 2: Extract agent
    console.print("Step 2: Extracting agent...", style="cyan bold")
    if not extract_agent(zip_path):
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 3: Setup Python environment
    console.print("Step 3: Setting up Python environment...", style="cyan bold")
    if not setup_python_environment():
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 4: Install systemd service
    console.print("Step 4: Installing systemd service...", style="cyan bold")
    if not install_service():
        console.print("\n✗ Installation failed", style="red")
        sys.exit(1)
    console.print()

    # Step 5: Start service
    console.print("Step 5: Starting agent service...", style="cyan bold")
    if not start_agent_service():
        console.print("\n✗ Installation failed", style="red")
        console.print(f"Check logs with: journalctl -u {SERVICE_NAME} -f", style="yellow")
        sys.exit(1)
    console.print()

    # Success!
    agent_path = get_agent_path()
    console.print("╔════════════════════════════════════════════╗", style="green")
    console.print("║    Agent Installation Complete!            ║", style="green")
    console.print("╚════════════════════════════════════════════╝\n", style="green")

    console.print("✓ Agent is installed and running as a systemd service", style="green")
    console.print(f"\n  Service: {SERVICE_NAME}", style="white")
    console.print(f"  Path: {agent_path}", style="white")
    console.print("  API: http://localhost:9741", style="cyan bold")
    console.print("  gRPC: localhost:9742", style="cyan bold")

    console.print("\nUseful commands:", style="white bold")
    console.print(f"  Check status:  systemctl status {SERVICE_NAME}", style="dim")
    console.print(f"  View logs:     journalctl -u {SERVICE_NAME} -f", style="dim")
    console.print(f"  Stop agent:    systemctl stop {SERVICE_NAME}", style="dim")
    console.print(f"  Start agent:   systemctl start {SERVICE_NAME}", style="dim")
    console.print(f"  Restart agent: systemctl restart {SERVICE_NAME}", style="dim")

    console.print("\nNow configure the CLI to use the local agent:", style="white")
    console.print("  twpt-cli init", style="cyan bold")
    console.print("  Then select 'localhost' when prompted\n", style="dim")
