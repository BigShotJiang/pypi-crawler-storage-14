#!/usr/bin/env python3
"""Interactive shell for ThreatWinds Pentest CLI."""

import os
import sys
import readline
import atexit
from pathlib import Path
from typing import List, Optional, Dict, Any
import shlex

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich import print as rprint

from twpt_cli import __version__
from twpt_cli.config import (
    load_credentials,
    load_endpoint_config,
    check_configured,
    get_api_endpoint,
    get_grpc_endpoint,
)

# Import command implementations
from twpt_cli.commands import (
    init,
    configure,
    schedule_pentest,
    get_pentest,
    download_evidence,
    update,
    uninstall,
    version_cmd,
    webui,
)

console = Console()

# History file for readline
HISTORY_FILE = Path.home() / ".twpt" / ".history"


class InteractiveShell:
    """Interactive shell for ThreatWinds Pentest CLI."""

    def __init__(self):
        """Initialize the interactive shell."""
        self.console = Console()
        self.running = True
        self.commands = self._build_command_map()
        self.setup_readline()
        self.last_pentest_id = None  # Track last pentest for convenience

    def _build_command_map(self) -> Dict[str, Dict[str, Any]]:
        """Build the command mapping for the shell."""
        return {
            # Core pentest commands
            "run": {
                "func": self.cmd_run,
                "help": "Run a new pentest",
                "usage": "run <target> [--safe] [--no-exploit] [--scope <holistic|targeted>] [--watch] [--config-file <path>]"
            },
            "get": {
                "func": self.cmd_get,
                "help": "Get pentest details",
                "usage": "get <pentest-id>"
            },
            "download": {
                "func": self.cmd_download,
                "help": "Download pentest evidence",
                "usage": "download <pentest-id> [--output <dir>] [--no-extract]"
            },

            # Configuration commands
            "init": {
                "func": self.cmd_init,
                "help": "Initialize remote endpoint configuration",
                "usage": "init <host> <port> | init --local"
            },
            "configure": {
                "func": self.cmd_configure,
                "help": "Configure API credentials",
                "usage": "configure [--skip-docker]"
            },
            "install-srv": {
                "func": self.cmd_install_server,
                "help": "Install local ThreatWinds server",
                "usage": "install-srv [--api-key KEY] [--api-secret SECRET] [--force]"
            },

            # Management commands
            "update": {
                "func": self.cmd_update,
                "help": "Update the pentest toolkit",
                "usage": "update [--force]"
            },
            "uninstall": {
                "func": self.cmd_uninstall,
                "help": "Uninstall the pentest toolkit",
                "usage": "uninstall [--remove-data]"
            },
            "version": {
                "func": self.cmd_version,
                "help": "Show version information",
                "usage": "version [--detailed]"
            },
            "webui": {
                "func": self.cmd_webui,
                "help": "Launch the web-based interface",
                "usage": "webui [--host <host>] [--port <port>] [--debug]"
            },

            # Shell commands
            "status": {
                "func": self.cmd_status,
                "help": "Show current configuration status",
                "usage": "status"
            },
            "list": {
                "func": self.cmd_list,
                "help": "List recent pentests (latest 5 by default)",
                "usage": "list [--page N] [--page-size N] [--all]"
            },
            "clear": {
                "func": self.cmd_clear,
                "help": "Clear the screen",
                "usage": "clear"
            },
            "help": {
                "func": self.cmd_help,
                "help": "Show help information",
                "usage": "help [command]"
            },
            "exit": {
                "func": self.cmd_exit,
                "help": "Exit the shell",
                "usage": "exit | quit | q"
            },
            "quit": {
                "func": self.cmd_exit,
                "help": "Exit the shell",
                "usage": "exit | quit | q"
            },
            "q": {
                "func": self.cmd_exit,
                "help": "Exit the shell",
                "usage": "exit | quit | q"
            },
        }

    def setup_readline(self):
        """Set up readline for command history and auto-completion."""
        # Set up history
        HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)

        if HISTORY_FILE.exists():
            try:
                readline.read_history_file(HISTORY_FILE)
            except (IOError, PermissionError):
                # Ignore history file errors
                pass

        # Save history on exit
        atexit.register(self.save_history)

        # Set up tab completion
        readline.set_completer(self.complete)
        readline.parse_and_bind('tab: complete')

        # Set history length
        readline.set_history_length(1000)

    def save_history(self):
        """Save command history."""
        try:
            readline.write_history_file(HISTORY_FILE)
        except (IOError, PermissionError):
            # Ignore history save errors
            pass

    def complete(self, text: str, state: int) -> Optional[str]:
        """Auto-complete commands."""
        if state == 0:
            # First time for this text, build matches
            if text:
                self.matches = [cmd for cmd in self.commands.keys() if cmd.startswith(text)]
            else:
                self.matches = list(self.commands.keys())

        # Return match at state
        if state < len(self.matches):
            return self.matches[state]
        return None

    def get_prompt(self) -> str:
        """Get the shell prompt."""
        # Check configuration status
        endpoint_config = load_endpoint_config()
        creds = load_credentials()

        # Build status indicators
        status_parts = []

        if endpoint_config and endpoint_config.get("use_remote"):
            host = endpoint_config.get("api_host", "unknown")
            port = endpoint_config.get("api_port", "9741")
            status_parts.append(f"[green]remote:{host}:{port}[/green]")
        else:
            status_parts.append("[yellow]local[/yellow]")

        if creds:
            status_parts.append("[green]✓[/green]")
        else:
            status_parts.append("[red]✗[/red]")

        status = " ".join(status_parts)
        return f"[bold cyan]twpt[/bold cyan] {status} [bold]>[/bold] "

    def parse_command(self, line: str) -> tuple:
        """Parse a command line into command and arguments."""
        if not line.strip():
            return None, []

        try:
            parts = shlex.split(line)
        except ValueError as e:
            self.console.print(f"[red]Parse error: {e}[/red]")
            return None, []

        if not parts:
            return None, []

        return parts[0].lower(), parts[1:]

    def run(self):
        """Run the interactive shell."""
        self.show_banner()

        while self.running:
            try:
                # Get input with rich prompt
                line = Prompt.ask(self.get_prompt(), console=self.console)

                if not line:
                    continue

                # Parse command
                cmd, args = self.parse_command(line)

                if not cmd:
                    continue

                # Execute command
                if cmd in self.commands:
                    self.commands[cmd]["func"](args)
                else:
                    self.console.print(f"[red]Unknown command: {cmd}[/red]")
                    self.console.print("Type 'help' for available commands")

            except KeyboardInterrupt:
                self.console.print("\n[yellow]Use 'exit' to quit[/yellow]")
            except EOFError:
                self.cmd_exit([])
            except Exception as e:
                self.console.print(f"[red]Error: {e}[/red]")

    def show_banner(self):
        """Show the shell banner."""
        banner = Panel.fit(
            f"[bold cyan]ThreatWinds Pentest CLI[/bold cyan]\n"
            f"Version {__version__}\n"
            f"Type 'help' for commands",
            border_style="cyan"
        )
        self.console.print(banner)
        self.console.print()

    # Command implementations

    def cmd_run(self, args: List[str]):
        """Run a new pentest."""
        if not args:
            self.console.print("[red]Error: Target required[/red]")
            self.console.print("Usage: run <target> [--safe] [--no-exploit] [--scope <holistic|targeted>] [--watch] [--config-file <path>]")
            return

        # Check if --watch flag is present (streaming mode requires direct invocation)
        has_watch = "--watch" in args

        # Build the CLI args and use CliRunner
        try:
            # Build command line args for the actual Click command
            cli_args = []

            # Check for config file first
            if "--config-file" in args:
                idx = args.index("--config-file")
                if idx + 1 < len(args):
                    cli_args.extend(["--config-file", args[idx + 1]])
            else:
                # Find the target (first non-flag argument)
                target = None
                for arg in args:
                    if not arg.startswith("--"):
                        target = arg
                        break

                if not target:
                    self.console.print("[red]Error: Target required[/red]")
                    self.console.print("Usage: run <target> [--safe] [--no-exploit] [--watch]")
                    return

                cli_args.extend(["--target", target])

            # Add flags
            if "--safe" in args:
                cli_args.append("--safe")
            if "--no-exploit" in args:
                cli_args.append("--no-exploit")
            if has_watch:
                cli_args.append("--watch")

            # For streaming commands (--watch), invoke directly to avoid output buffering
            if has_watch:
                import subprocess
                import sys

                # Build the full command
                cmd = [sys.executable, "-m", "twpt_cli.main", "run"] + cli_args

                # Run directly so output streams in real-time
                try:
                    subprocess.run(cmd, check=False)
                except KeyboardInterrupt:
                    self.console.print("\n[yellow]Interrupted[/yellow]")
            else:
                # Use Click's testing runner for non-streaming commands
                from click.testing import CliRunner
                runner = CliRunner()
                result = runner.invoke(schedule_pentest.schedule_pentest, cli_args, catch_exceptions=False)

                # Display output if there's any - print raw to avoid double-encoding ANSI codes
                if result.output:
                    # Print directly to stdout to preserve ANSI codes
                    import sys
                    sys.stdout.write(result.output)
                    sys.stdout.flush()

                # Check for errors
                if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                    raise result.exception

        except SystemExit:
            pass  # Commands may call sys.exit, catch it
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_get(self, args: List[str]):
        """Get pentest details (formerly get-pentest)."""
        if not args:
            if self.last_pentest_id:
                pentest_id = self.last_pentest_id
                self.console.print(f"[dim]Using last pentest ID: {pentest_id}[/dim]")
            else:
                self.console.print("[red]Error: Pentest ID required[/red]")
                self.console.print("Usage: get <pentest-id>")
                return
        else:
            pentest_id = args[0]

        try:
            from click.testing import CliRunner
            runner = CliRunner()
            result = runner.invoke(get_pentest.get_pentest, [pentest_id], catch_exceptions=False)

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception
        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_download(self, args: List[str]):
        """Download pentest evidence (formerly download-evidence)."""
        if not args:
            if self.last_pentest_id:
                pentest_id = self.last_pentest_id
                self.console.print(f"[dim]Using last pentest ID: {pentest_id}[/dim]")
            else:
                self.console.print("[red]Error: Pentest ID required[/red]")
                self.console.print("Usage: download <pentest-id> [--output <dir>]")
                return
        else:
            pentest_id = args[0]

        # Build CLI args
        cli_args = [pentest_id]

        if "--output" in args:
            idx = args.index("--output")
            if idx + 1 < len(args):
                cli_args.extend(["--output", args[idx + 1]])

        if "--no-extract" in args:
            cli_args.append("--no-extract")

        try:
            from click.testing import CliRunner
            runner = CliRunner()
            result = runner.invoke(download_evidence.download_evidence, cli_args, catch_exceptions=False)

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception
        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_init(self, args: List[str]):
        """Initialize remote endpoint configuration."""
        try:
            from click.testing import CliRunner
            runner = CliRunner()

            if "--local" in args:
                # Reset to local
                cli_args = ["--local"]
                # Need to provide dummy values for prompts
                result = runner.invoke(init.init, cli_args, catch_exceptions=False)
            elif len(args) >= 2:
                # Extract host and ports
                cli_args = []
                host = None
                api_port = None
                grpc_port = None

                # Find non-flag arguments
                non_flags = [a for a in args if not a.startswith("--")]
                if len(non_flags) >= 1:
                    host = non_flags[0]
                if len(non_flags) >= 2:
                    api_port = non_flags[1]
                if len(non_flags) >= 3:
                    grpc_port = non_flags[2]

                # Build CLI args
                if host:
                    cli_args.extend(["--host", host])
                if api_port:
                    cli_args.extend(["--api-port", api_port])
                if grpc_port:
                    cli_args.extend(["--grpc-port", grpc_port])
                if "--skip-test" in args:
                    cli_args.append("--skip-test")

                result = runner.invoke(init.init, cli_args, catch_exceptions=False, input="\n\n")
            else:
                self.console.print("[red]Error: Invalid arguments[/red]")
                self.console.print("Usage: init <host> <port> | init --local")
                return

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception

        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_configure(self, args: List[str]):
        """Configure API credentials."""
        # Prompt for credentials interactively
        api_key = Prompt.ask("API Key", console=self.console)
        api_secret = Prompt.ask("API Secret", password=True, console=self.console)

        try:
            from click.testing import CliRunner
            runner = CliRunner()

            cli_args = ["--api-key", api_key, "--api-secret", api_secret]
            if "--skip-docker" in args:
                cli_args.append("--skip-docker")

            result = runner.invoke(configure.configure, cli_args, catch_exceptions=False)

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception
        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_install_server(self, args: List[str]):
        """Install local ThreatWinds server."""
        # Check for flags
        api_key = None
        api_secret = None
        force = "--force" in args
        skip_docker = "--skip-docker-install" in args

        # Extract API key/secret if provided
        if "--api-key" in args:
            idx = args.index("--api-key")
            if idx + 1 < len(args):
                api_key = args[idx + 1]

        if "--api-secret" in args:
            idx = args.index("--api-secret")
            if idx + 1 < len(args):
                api_secret = args[idx + 1]

        # Prompt for credentials if not provided
        if not api_key:
            api_key = Prompt.ask("API Key", console=self.console)
        if not api_secret:
            api_secret = Prompt.ask("API Secret", password=True, console=self.console)

        try:
            from click.testing import CliRunner
            from twpt_cli.commands import install_server as install_server_cmd
            runner = CliRunner()

            cli_args = ["--api-key", api_key, "--api-secret", api_secret]
            if force:
                cli_args.append("--force")
            if skip_docker:
                cli_args.append("--skip-docker-install")

            result = runner.invoke(install_server_cmd.install_server, cli_args, catch_exceptions=False)

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception
        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_update(self, args: List[str]):
        """Update the pentest toolkit."""
        try:
            from click.testing import CliRunner
            runner = CliRunner()

            cli_args = []
            if "--force" in args:
                cli_args.append("--force")

            result = runner.invoke(update.update_latest, cli_args, catch_exceptions=False)

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception
        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_uninstall(self, args: List[str]):
        """Uninstall the pentest toolkit."""
        # Confirm in interactive mode
        if Confirm.ask("Are you sure you want to uninstall?", console=self.console):
            try:
                from click.testing import CliRunner
                runner = CliRunner()

                cli_args = ["--yes"]
                if "--remove-data" in args:
                    cli_args.append("--remove-data")

                result = runner.invoke(uninstall.uninstall, cli_args, catch_exceptions=False)

                if result.output:
                    import sys
                    sys.stdout.write(result.output)
                    sys.stdout.flush()

                if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                    raise result.exception
            except SystemExit:
                pass
            except Exception as e:
                self.console.print(f"[red]Error: {e}[/red]")
        else:
            self.console.print("[yellow]Uninstall cancelled[/yellow]")

    def cmd_version(self, args: List[str]):
        """Show version information."""
        try:
            from click.testing import CliRunner
            runner = CliRunner()

            cli_args = []
            if "--detailed" in args or "-d" in args:
                cli_args.append("--detailed")

            result = runner.invoke(version_cmd.version, cli_args, catch_exceptions=False)

            if result.output:
                import sys
                sys.stdout.write(result.output)
                sys.stdout.flush()

            if result.exit_code != 0 and result.exception and not isinstance(result.exception, SystemExit):
                raise result.exception
        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_webui(self, args: List[str]):
        """Launch the web-based interface."""
        # Parse arguments
        host = "0.0.0.0"
        port = 8080
        debug = "--debug" in args or "-d" in args

        for i, arg in enumerate(args):
            if arg in ("--host", "-h") and i + 1 < len(args):
                host = args[i + 1]
            elif arg in ("--port", "-p") and i + 1 < len(args):
                try:
                    port = int(args[i + 1])
                except ValueError:
                    self.console.print("[red]Error: Invalid port number[/red]")
                    return

        try:
            from click.testing import CliRunner
            import subprocess
            import sys

            # Build CLI args
            cli_args = ["--host", host, "--port", str(port)]
            if debug:
                cli_args.append("--debug")

            # Run directly via subprocess so the server runs interactively
            cmd = [sys.executable, "-m", "twpt_cli.main", "webui"] + cli_args

            try:
                subprocess.run(cmd, check=False)
            except KeyboardInterrupt:
                self.console.print("\n[yellow]Web UI stopped[/yellow]")

        except SystemExit:
            pass
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")

    def cmd_status(self, args: List[str]):
        """Show current configuration status."""
        # Create status table
        table = Table(title="Configuration Status", show_header=True, header_style="bold cyan")
        table.add_column("Setting", style="white")
        table.add_column("Value", style="green")
        table.add_column("Status", style="yellow")

        # Check credentials
        creds = load_credentials()
        if creds:
            table.add_row("API Credentials", "Configured", "✓")
        else:
            table.add_row("API Credentials", "Not configured", "✗")

        # Check endpoint
        endpoint_config = load_endpoint_config()
        if endpoint_config and endpoint_config.get("use_remote"):
            endpoint = f"{endpoint_config['api_host']}:{endpoint_config['api_port']}"
            table.add_row("Endpoint Mode", "Remote", "✓")
            table.add_row("API Endpoint", endpoint, "")
        else:
            table.add_row("Endpoint Mode", "Local (Docker)", "")
            table.add_row("API Endpoint", "localhost:9741", "")

        # Show URLs
        table.add_row("API URL", get_api_endpoint(), "")
        table.add_row("gRPC Address", get_grpc_endpoint(), "")

        self.console.print(table)

    def cmd_list(self, args: List[str]):
        """List recent pentests."""
        # Parse arguments
        page = 1
        page_size = 5  # Default: show latest 5 pentests
        show_all = False

        for i, arg in enumerate(args):
            if arg == "--page" and i + 1 < len(args):
                try:
                    page = int(args[i + 1])
                except ValueError:
                    self.console.print("[red]Error: Invalid page number[/red]")
                    return
            elif arg == "--page-size" and i + 1 < len(args):
                try:
                    page_size = int(args[i + 1])
                except ValueError:
                    self.console.print("[red]Error: Invalid page size[/red]")
                    return
            elif arg == "--all":
                show_all = True
                page_size = 100

        # Load credentials
        creds = load_credentials()
        if not creds:
            self.console.print("✗ Not configured. Please run: configure", style="red")
            return

        # Get pentests from API
        try:
            from twpt_cli.sdk import HTTPClient
            client = HTTPClient(get_api_endpoint(), creds)
            response = client.list_pentests(page=page, page_size=page_size)

            # Display header
            self.console.print("\n╔══════════════════════════════════════════════╗", style="cyan")
            self.console.print("║              Recent Pentests                  ║", style="cyan")
            self.console.print("╚══════════════════════════════════════════════╝\n", style="cyan")

            if not response.pentests:
                self.console.print("[yellow]No pentests found[/yellow]")
                return

            # Create table with overflow handling
            table = Table(show_header=True, header_style="bold cyan", box=None, show_edge=False)
            table.add_column("ID", style="white", no_wrap=True, min_width=36)
            table.add_column("Status", style="yellow", max_width=12)
            table.add_column("Targets", style="white", max_width=25)
            table.add_column("Findings", style="cyan", max_width=8)
            table.add_column("Severity", style="magenta", max_width=8)

            # Add rows
            for pentest in response.pentests:
                # Format status with color
                status_color = {
                    "PENDING": "yellow",
                    "IN_PROGRESS": "blue",
                    "COMPLETED": "green",
                    "FAILED": "red"
                }.get(pentest.status, "white")
                status = f"[{status_color}]{pentest.status}[/{status_color}]"

                # Format severity with color
                severity_color = {
                    "CRITICAL": "red",
                    "HIGH": "bright_red",
                    "MEDIUM": "yellow",
                    "LOW": "blue",
                    "NONE": "dim"
                }.get(pentest.severity, "white")
                severity = f"[{severity_color}]{pentest.severity}[/{severity_color}]"

                # Format targets - show target names (up to 20 chars)
                if pentest.targets and len(pentest.targets) > 0:
                    target_names = [t.target for t in pentest.targets]
                    if len(target_names) == 1:
                        # Single target: show name up to 20 chars
                        target_display = target_names[0][:20]
                    else:
                        # Multiple targets: show count and first target
                        target_display = f"{len(target_names)} ({target_names[0][:15]}...)"
                else:
                    target_display = "0 targets"

                table.add_row(
                    pentest.id,  # Show full ID
                    status,
                    target_display,
                    str(pentest.findings),
                    severity
                )

            self.console.print(table)

            # Show pagination info
            if response.total_pages > 1:
                self.console.print(
                    f"\n[dim]Page {response.page} of {response.total_pages} "
                    f"(Total: {response.total} pentests)[/dim]"
                )

            self.console.print("\n[dim]Use 'get <id>' to view pentest details[/dim]")

        except Exception as e:
            self.console.print(f"[red]Failed to list pentests: {e}[/red]")

    def cmd_clear(self, args: List[str]):
        """Clear the screen."""
        os.system('clear' if os.name == 'posix' else 'cls')

    def cmd_help(self, args: List[str]):
        """Show help information."""
        if args:
            # Show help for specific command
            cmd_name = args[0].lower()
            if cmd_name in self.commands:
                cmd_info = self.commands[cmd_name]
                self.console.print(f"\n[bold cyan]{cmd_name}[/bold cyan]")
                self.console.print(f"  {cmd_info['help']}")
                self.console.print(f"  Usage: {cmd_info['usage']}\n")
            else:
                self.console.print(f"[red]Unknown command: {cmd_name}[/red]")
        else:
            # Show all commands
            self.console.print("\n[bold cyan]Available Commands:[/bold cyan]\n")

            # Group commands
            groups = {
                "Pentest Operations": ["run", "get", "download", "list"],
                "Configuration": ["init", "configure", "install-srv", "status"],
                "Management": ["update", "uninstall", "version", "webui"],
                "Shell": ["help", "clear", "exit", "quit"],
            }

            for group_name, group_cmds in groups.items():
                self.console.print(f"[yellow]{group_name}:[/yellow]")
                for cmd_name in group_cmds:
                    if cmd_name in self.commands:
                        cmd_info = self.commands[cmd_name]
                        # Skip aliases
                        if cmd_name in ["quit", "q"]:
                            continue
                        self.console.print(f"  [bold]{cmd_name:12}[/bold] {cmd_info['help']}")
                self.console.print()

            self.console.print("[dim]Type 'help <command>' for detailed usage[/dim]\n")

    def cmd_exit(self, args: List[str]):
        """Exit the shell."""
        self.console.print("[cyan]Goodbye![/cyan]")
        self.running = False


def main():
    """Main entry point for interactive shell."""
    shell = InteractiveShell()
    shell.run()


if __name__ == "__main__":
    main()