__all__ = ["SpectralParam", "SpectralSource"]


from .model import SpectralParam
from .source import SpectralSource
