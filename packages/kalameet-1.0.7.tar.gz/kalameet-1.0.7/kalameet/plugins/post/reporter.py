import os
import json
from datetime import datetime
from kalameet.core.base import BasePlugin
from kalameet.config import settings

class ReporterPlugin(BasePlugin):
    meta = {
        'name': 'report',
        'description': 'Generate HTML Report from Logs',
        'author': 'Kalameet'
    }

    def __init__(self):
        self.log_root = settings.LOG_DIR
        self.report_file = os.path.join(settings.OUTPUT_DIR, "final_report.html")

    def add_arguments(self, parser):
        pass

    def run(self, args):
        print(f"[*] Scanning logs in: {self.log_root}")
        
        if not os.path.exists(self.log_root):
            print("[-] No logs directory found.")
            return

        # 1. Kumpulkan Data (Recursive Scan ke Subfolder Tanggal)
        auto_logs = []
        vuln_logs = []
        
        # os.walk akan masuk ke folder tanggal (24-11-2025)
        for root, dirs, files in os.walk(self.log_root):
            for filename in files:
                if filename.endswith(".json"):
                    filepath = os.path.join(root, filename)
                    try:
                        with open(filepath, 'r') as f:
                            data = json.load(f)
                            # Filter berdasarkan nama file
                            if "autopilot" in filename:
                                auto_logs.extend(data)
                            else:
                                for entry in data:
                                    if entry.get('status') in ['SUCCESS', 'FOUND', 'CAPTURED', 'SOLVED', 'CRITICAL']:
                                        vuln_logs.append(entry)
                    except: continue

        # Sortir berdasarkan waktu terbaru
        auto_logs.sort(key=lambda x: x['timestamp'], reverse=True)
        vuln_logs.sort(key=lambda x: x['timestamp'], reverse=True)

        # 2. Susun HTML (Dark Theme)
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Kalameet Mission Report</title>
            <style>
                body {{ background-color: #0d0d0d; color: #00ff41; font-family: 'Courier New', monospace; padding: 30px; }}
                h1 {{ border-bottom: 2px solid #00ff41; padding-bottom: 15px; text-transform: uppercase; letter-spacing: 2px; }}
                .box {{ background: #1a1a1a; padding: 20px; margin-bottom: 30px; border: 1px solid #333; box-shadow: 0 0 10px rgba(0,255,65,0.1); }}
                h2 {{ margin-top: 0; font-size: 1.2em; }}
                table {{ width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 0.9em; }}
                th, td {{ border: 1px solid #333; padding: 10px; text-align: left; }}
                th {{ background-color: #222; color: #fff; }}
                tr:hover {{ background-color: #252525; }}
                .tag {{ padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 0.8em; }}
                .tag-success {{ background: #006400; color: #fff; border: 1px solid #00ff00; }}
                .tag-danger {{ background: #8b0000; color: #fff; border: 1px solid #ff0000; }}
            </style>
        </head>
        <body>
            <h1>KALAMEET V4.0 // MISSION REPORT</h1>
            <p>Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")} | Source: {self.log_root}</p>

            <div class="box">
                <h2>[1] AUTOPILOT DECISIONS</h2>
                <table>
                    <tr><th>Time</th><th>Module</th><th>Activity</th></tr>
                    {''.join([f"<tr><td style='color:#888'>{l['timestamp'].split('T')[1][:8]}</td><td>{l['module']}</td><td>{l['message']}</td></tr>" for l in auto_logs])}
                </table>
            </div>

            <div class="box" style="border-color: #8b0000;">
                <h2 style="color: #ff4444;">[2] VULNERABILITY & CREDENTIALS FOUND</h2>
                <p>Total Issues: {len(vuln_logs)}</p>
                <table>
                    <tr><th>Module</th><th>Status</th><th>Finding</th><th>Raw Data</th></tr>
                    {''.join([f"<tr><td>{l['module']}</td><td><span class='tag tag-danger'>{l['status']}</span></td><td>{l['message']}</td><td style='color:#ccc'>{str(l.get('data', '-'))}</td></tr>" for l in vuln_logs])}
                </table>
            </div>
            
            <center><p style="color:#555">-- END OF CLASSIFIED REPORT --</p></center>
        </body>
        </html>
        """

        # 3. Simpan File
        try:
            with open(self.report_file, 'w') as f:
                f.write(html_content)
            
            print(f"\n{'-'*60}")
            print(f"[+] REPORT GENERATED SUCCESSFULLY!")
            print(f"[*] File Location: {self.report_file}")
            print(f"{'-'*60}")
            print(f"[?] HOW TO VIEW:")
            print(f"    python3 -m http.server 8000")
            print(f"    Open: http://localhost:8000/logs/output/final_report.html")
            print(f"{'-'*60}\n")
                
        except Exception as e:
            print(f"[-] Error writing report: {e}")