import hashlib
import os
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import Colors
from kalameet.config import settings

class HashBusterPlugin(BasePlugin):
    meta = {
        'name': 'crack',
        'description': 'Offline Hash Cracker (MD5, SHA1, SHA256)',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="hash_crack")

    def add_arguments(self, parser):
        parser.add_argument("-s", "--hash", required=True, help="Target Hash String")
        parser.add_argument("-w", "--wordlist", help="Custom wordlist path")

    def identify_hash(self, hash_str):
        length = len(hash_str)
        if length == 32: return "MD5"
        elif length == 40: return "SHA1"
        elif length == 64: return "SHA256"
        return "Unknown"

    def crack(self, target_hash, algo, wordlist_path):
        print(f"[*] Cracking {algo} hash using: {wordlist_path}")
        
        try:
            with open(wordlist_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f:
                    word = line.strip()
                    
                    # Hashing Process
                    if algo == "MD5":
                        hashed = hashlib.md5(word.encode()).hexdigest()
                    elif algo == "SHA1":
                        hashed = hashlib.sha1(word.encode()).hexdigest()
                    elif algo == "SHA256":
                        hashed = hashlib.sha256(word.encode()).hexdigest()
                    else:
                        return None

                    if hashed == target_hash.lower():
                        return word
        except FileNotFoundError:
            print(f"{Colors.FAIL}[-] Wordlist not found.{Colors.ENDC}")
        return None

    def run(self, args):
        target = args.hash.lower()
        algo = self.identify_hash(target)
        
        print(f"{Colors.BLUE}[*] Target Hash: {target}{Colors.ENDC}")
        print(f"{Colors.BLUE}[*] Detected Algorithm: {algo}{Colors.ENDC}")
        
        if algo == "Unknown":
            print(f"{Colors.FAIL}[-] Unsupported hash type.{Colors.ENDC}")
            return

        # Setup Wordlist
        if args.wordlist:
            wlist = args.wordlist
        else:
            wlist = os.path.join(settings.WORDLIST_DIR, settings.WORDLISTS['passwords'])

        # Start Cracking
        result = self.crack(target, algo, wlist)
        
        if result:
            print(f"\n{Colors.GREEN}[!!!] HASH CRACKED: {result}{Colors.ENDC}")
            self.logger.log("HashBuster", "CRACKED", f"Hash {target} -> {result}", {"algo": algo, "password": result})
        else:
            print(f"\n{Colors.FAIL}[-] Password not found in wordlist.{Colors.ENDC}")