import binascii
import os
from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors

class MagicHunterPlugin(BasePlugin):
    meta = {
        'name': 'forensics',
        'description': 'Magic Byte File Identification & Header Repair',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        # Database Signature (Ditambah biar lebih lengkap)
        self.signatures = {
            "ffd8ff": "jpg",
            "89504e47": "png",
            "504b0304": "zip/docx/apk",
            "25504446": "pdf",
            "47494638": "gif",
            "7f454c46": "elf (linux exec)",
            "4d5a": "exe (windows)"
        }

    def add_arguments(self, parser):
        parser.add_argument("-d", "--data", required=True, help="Path to suspicious file")
        parser.add_argument("--fix", action="store_true", help="Auto-fix header if detected")

    def run(self, args):
        file_path = args.data
        print(f"{Colors.BLUE}[*] Analyzing Magic Bytes: {file_path}{Colors.ENDC}")

        if not os.path.exists(file_path):
            print(f"{Colors.FAIL}[-] File not found.{Colors.ENDC}")
            return

        file_type = None
        hex_header = ""

        try:
            with open(file_path, 'rb') as f:
                # Baca 8 byte pertama (cukup untuk identifikasi umum)
                header_bytes = f.read(8)
                hex_header = binascii.hexlify(header_bytes).decode('utf-8')
                
                print(f"    [>] Hex Header: {Colors.BOLD}{hex_header}{Colors.ENDC}")
                
                for sig, ext in self.signatures.items():
                    if hex_header.startswith(sig):
                        file_type = ext
                        print(f"{Colors.GREEN}[+] File Identified: {ext.upper()}{Colors.ENDC}")
                        break
                
                if not file_type:
                    print(f"{Colors.WARNING}[-] Unknown Signature.{Colors.ENDC}")

        except Exception as e:
            print(f"{Colors.FAIL}[-] Error reading file: {e}{Colors.ENDC}")
            return

        # Logika Fix Header
        if file_type:
            # Jika user minta fix atau kita tawarkan interaktif
            if args.fix:
                self.fix_header(file_path, file_type)
            else:
                # Tawarkan perbaikan jika header terlihat rusak/pendek
                # (Logika sederhana: user bisa manual pilih y/n)
                choice = input(f"{Colors.WARNING}[?] Do you want to attempt header repair/recovery? (y/n): {Colors.ENDC}")
                if choice.lower() == 'y':
                    self.fix_header(file_path, file_type)

    def fix_header(self, file_path, file_type):
        print(f"[*] Attempting to restore header for {file_type}...")
        
        # Cari signature yang pas
        target_sig = None
        for sig, ext in self.signatures.items():
            if ext == file_type:
                target_sig = sig
                break
        
        if not target_sig: return

        try:
            # Baca konten asli
            with open(file_path, 'rb') as f:
                content = f.read()

            # Buat nama file baru
            new_filename = file_path + "_fixed." + file_type.split('/')[0]
            
            # Tulis ulang (Header Benar + Konten Asli)
            # Note: Ini logika overwrite header sederhana (prepend)
            # Untuk file CTF yang headernya dihapus total (0 byte), ini sangat berguna.
            with open(new_filename, 'wb') as f:
                # Jika header rusak (corrupt), kita bisa timpa byte awal
                # Tapi metode paling aman adalah prepend magic bytes jika file totally broken
                # Di sini kita tulis magic bytes + content
                # (Ini asumsi header hilang, bukan salah)
                
                # Konversi hex sig ke bytes
                sig_bytes = binascii.unhexlify(target_sig)
                
                # Cek apakah konten sudah punya header itu?
                if content.startswith(sig_bytes):
                    print(f"{Colors.BLUE}[i] Header seems correct already.{Colors.ENDC}")
                    f.write(content)
                else:
                    # Jika tidak, kita asumsikan header hilang/salah
                    # Kita timpa bagian awal sesuai panjang signature
                    # (Ini teknik 'Header Surgery' kasar tapi efektif di CTF)
                    f.write(sig_bytes + content[len(sig_bytes):])
            
            print(f"{Colors.GREEN}[+] File saved as: {new_filename}{Colors.ENDC}")

        except Exception as e:
            print(f"{Colors.FAIL}[-] Repair failed: {e}{Colors.ENDC}")