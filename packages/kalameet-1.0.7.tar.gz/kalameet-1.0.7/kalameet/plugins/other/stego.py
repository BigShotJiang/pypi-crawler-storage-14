import subprocess
import os
import shutil
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import Colors
from kalameet.config import settings

class StegoPlugin(BasePlugin):
    meta = {
        'name': 'stego',
        'description': 'Automated Steganography Solver (Exif/Strings/Steghide)',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="stego_analysis")

    def add_arguments(self, parser):
        parser.add_argument("-f", "--file", required=True, help="Target Image/Audio File")
        parser.add_argument("--pass", dest="password", help="Password for Steghide (Optional)")

    def run_cmd(self, cmd, description):
        print(f"\n{Colors.GREEN}[*] Running {description}...{Colors.ENDC}")
        print(f"    Command: {cmd}")
        try:
            # Jalankan perintah dan tangkap outputnya
            process = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            output = process.stdout.strip()
            
            if output:
                print(f"{Colors.BLUE}{output[:500]}...{Colors.ENDC}" if len(output) > 500 else f"{Colors.BLUE}{output}{Colors.ENDC}")
                # Log hasil
                self.logger.log("Stego", "EXEC", description, {"cmd": cmd, "output_snippet": output[:200]})
            else:
                print("    [-] No output / Empty.")
                
            if process.stderr:
                pass # Error biasanya wajar di stego (misal steghide gagal ekstrak)
        except Exception as e:
            print(f"{Colors.FAIL}[-] Execution Error: {e}{Colors.ENDC}")

    def check_tool(self, tool):
        if shutil.which(tool) is None:
            print(f"{Colors.WARNING}[!] Tool '{tool}' is missing. Install it via apt/brew.{Colors.ENDC}")
            return False
        return True

    def run(self, args):
        target = args.file
        if not os.path.exists(target):
            print(f"{Colors.FAIL}[-] File not found: {target}{Colors.ENDC}")
            return

        print(f"{Colors.HEADER}=== STEGO AUTO-ANALYSIS: {target} ==={Colors.ENDC}")

        # 1. Basic Strings (Cari teks tersembunyi)
        self.run_cmd(f"strings {target} | grep -iE 'flag|ctf|pass|admin|key'", "Strings Analysis (Searching for Flag)")

        # 2. ExifTool (Metadata)
        if self.check_tool("exiftool"):
            self.run_cmd(f"exiftool {target}", "ExifTool Metadata")

        # 3. Steghide (Extract data)
        if self.check_tool("steghide"):
            # Coba tanpa password
            self.run_cmd(f"steghide extract -sf {target} -p ''", "Steghide (Empty Password)")
            # Coba dengan password jika user memberikan
            if args.password:
                self.run_cmd(f"steghide extract -sf {target} -p {args.password}", f"Steghide (Pass: {args.password})")

        # 4. Binwalk (Cari file dalam file)
        if self.check_tool("binwalk"):
            # --run-as=root diperlukan di beberapa docker container
            self.run_cmd(f"binwalk -e {target} --run-as=root", "Binwalk Extraction")
        
        print(f"\n{Colors.HEADER}[*] Analysis Complete. Check current folder for extracted files.{Colors.ENDC}")