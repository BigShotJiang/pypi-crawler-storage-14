import base64
import string
import binascii
import sys
import logging
from kalameet.core.base import BasePlugin
from kalameet.core.interface import Colors

# Import pwntools untuk koneksi
try:
    from pwn import remote, context
    # Matikan log berisik pwntools
    context.log_level = 'error'
except ImportError:
    pass

class CryptoPlugin(BasePlugin):
    meta = {
        'name': 'crypto',
        'description': 'Crypto Suite: Static Decoder & Interactive AES Oracle Attacker',
        'author': 'Kalameet'
    }

    def add_arguments(self, parser):
        parser.add_argument("-d", "--data", help="Ciphertext string to analyze (Static Mode)")
        parser.add_argument("--key", help="Key for Vigenere/XOR (Optional)")
        parser.add_argument("--attack", choices=['aes_cbc'], help="Attack Mode")
        parser.add_argument("--connect", help="Target Host:Port (e.g. 127.0.0.1:1337)")

    # --- HELPER XOR MANUAL (PENGGANTI LIBRARY YANG ERROR) ---
    def _xor(self, b1, b2):
        """Melakukan XOR antar dua bytes object"""
        # Pastikan panjang sama atau gunakan zip untuk memotong yang terpanjang
        return bytes(x ^ y for x, y in zip(b1, b2))

    # --- BAGIAN 1: STATIC DECODER ---
    def rot_n(self, text, n):
        result = ""
        for char in text:
            if char.isalpha():
                shift = 65 if char.isupper() else 97
                result += chr((ord(char) - shift + n) % 26 + shift)
            else:
                result += char
        return result

    def vigenere_decrypt(self, ciphertext, key):
        key = key.upper()
        key_len = len(key)
        key_int = [ord(i) for i in key]
        ciphertext_int = [ord(i) for i in ciphertext]
        plaintext = ''
        for i in range(len(ciphertext_int)):
            if chr(ciphertext_int[i]).isalpha():
                value = (ciphertext_int[i] - key_int[i % key_len]) % 26
                if chr(ciphertext_int[i]).isupper():
                    value += 65
                else:
                    value += 97 - 32 if chr(ciphertext_int[i]).isupper() else 97
                plaintext += chr(value)
            else:
                plaintext += chr(ciphertext_int[i])
        return plaintext

    def xor_bruteforce(self, data_bytes):
        print(f"\n{Colors.WARNING}[*] Running XOR Brute Force...{Colors.ENDC}")
        found = False
        for key in range(256):
            decrypted = bytes([b ^ key for b in data_bytes])
            try:
                res = decrypted.decode('utf-8')
                if not all(c in string.printable for c in res): continue
                if "CTF" in res or "flag" in res or "admin" in res or "GEMASTIK" in res:
                    print(f"    {Colors.GREEN}[+] Key {hex(key)}: {res}{Colors.ENDC}")
                    found = True
            except: pass
        if not found: print("    [-] No flag pattern found in XOR.")

    def solve_caesar(self, text):
        print(f"\n{Colors.WARNING}[*] Running Caesar/Rot Brute Force...{Colors.ENDC}")
        rot13 = self.rot_n(text, 13)
        if "flag" in rot13.lower() or "ctf" in rot13.lower():
             print(f"    {Colors.GREEN}[+] ROT13: {rot13}{Colors.ENDC}")
        else:
             print(f"    [i] ROT13: {rot13}")

    def auto_decode(self, text):
        print(f"\n{Colors.BLUE}[*] Auto-Detect & Decode Chain...{Colors.ENDC}")
        current = text
        for i in range(10):
            decoded = False
            try:
                clean = current.strip().replace(" ", "").replace("\n", "")
                if len(clean) % 2 == 0:
                    byte_res = bytes.fromhex(clean)
                    try:
                        str_res = byte_res.decode('utf-8')
                        if all(c in string.printable for c in str_res) and len(str_res) > 2:
                            print(f"    [Layer {i+1}] Hex -> {Colors.BOLD}{str_res[:50]}...{Colors.ENDC}")
                            current = str_res
                            decoded = True
                            continue
                    except: pass
            except: pass

            try:
                pad = len(current) % 4
                temp = current + "="* (4-pad) if pad else current
                byte_res = base64.b64decode(temp, validate=True)
                str_res = byte_res.decode('utf-8')
                if all(c in string.printable for c in str_res) and len(str_res) > 2:
                    print(f"    [Layer {i+1}] Base64 -> {Colors.BOLD}{str_res[:50]}...{Colors.ENDC}")
                    current = str_res
                    decoded = True
                    continue
            except: pass
            if not decoded: break
        print(f"{Colors.GREEN}[=] FINAL RESULT: {current}{Colors.ENDC}")
        return current

    # --- BAGIAN 2: INTERACTIVE ATTACK (AES ORACLE) ---
    def get_dk(self, r, block):
        """Helper untuk menghitung D_k(block) via Oracle"""
        r.recvuntil(b'Give me your message: ')
        r.sendline(block.hex().encode())
        
        resp = r.recvline().strip().decode().split(': ')[1]
        resp_bytes = bytes.fromhex(resp)
        
        iv_new = resp_bytes[:16]
        z1_prime = resp_bytes[16:32]
        
        # [UPDATE] Ganti strxor dengan self._xor
        return self._xor(z1_prime, iv_new)

    def is_printable(self, b):
        return all(c in string.printable.encode() for c in [bytes([x]) for x in b])

    def attack_aes_cbc(self, target_host, target_port):
        print(f"{Colors.FAIL}[!!!] STARTING AES-CBC REVERSE ATTACK [!!!]{Colors.ENDC}")
        print(f"[*] Target Oracle: {target_host}:{target_port}")
        
        try:
            # Cek apakah pwntools terinstall
            if 'remote' not in globals():
                print(f"{Colors.FAIL}[-] Error: 'pwntools' not installed.{Colors.ENDC}")
                return

            r = remote(target_host, int(target_port))
            
            print("[*] Receiving initial encrypted flag...")
            r.recvuntil(b'encryption result: ')
            flag_enc = bytes.fromhex(r.recvline().strip().decode())
            
            iv_flag = flag_enc[:16]
            z_blocks = [flag_enc[i:i+16] for i in range(16, len(flag_enc), 16)]
            
            print(f"    [+] IV: {iv_flag.hex()}")
            print(f"    [+] Blocks: {len(z_blocks)}")
            
            print(f"\n{Colors.WARNING}[*] Brute-forcing last block (2 bytes)... This may take a while.{Colors.ENDC}")
            
            padding = b'\x0d' * 13
            suffix = b'}' + padding

            for b1 in range(256):
                print(f"    Trying byte 1: {hex(b1)}...", end='\r')
                for b2 in range(256):
                    f5_guess = bytes([b1, b2]) + suffix
                    
                    # Hitung mundur menggunakan fungsi _xor manual
                    dk_f5 = self.get_dk(r, f5_guess)
                    f4_candidate = self._xor(dk_f5, z_blocks[4]) 
                    
                    if self.is_printable(f4_candidate):
                        try:
                            dk_f4 = self.get_dk(r, f4_candidate)
                            f3_candidate = self._xor(dk_f4, z_blocks[3])
                            
                            dk_f3 = self.get_dk(r, f3_candidate)
                            f2_candidate = self._xor(dk_f3, z_blocks[2])
                            
                            dk_f2 = self.get_dk(r, f2_candidate)
                            f1_candidate = self._xor(dk_f2, z_blocks[1])
                            
                            dk_f1 = self.get_dk(r, f1_candidate)
                            check_iv = self._xor(dk_f1, z_blocks[0])
                            
                            if check_iv == iv_flag:
                                print(f"\n\n{Colors.GREEN}[!!!] PWNED! FLAG RECOVERED:{Colors.ENDC}")
                                full_flag = f1_candidate + f2_candidate + f3_candidate + f4_candidate + f5_guess
                                clean_flag = full_flag[:-13].decode()
                                print(f"{Colors.BOLD}{clean_flag}{Colors.ENDC}")
                                r.close()
                                return
                        except: continue
            r.close()
            print(f"\n{Colors.FAIL}[-] Attack finished but flag not found.{Colors.ENDC}")

        except Exception as e:
            print(f"\n{Colors.FAIL}[-] Connection/Exploit Error: {e}{Colors.ENDC}")

    def run(self, args):
        if args.attack == 'aes_cbc':
            if not args.connect:
                print(f"{Colors.FAIL}[-] AES Attack requires --connect HOST:PORT{Colors.ENDC}")
                return
            
            try:
                host, port = args.connect.split(':')
                self.attack_aes_cbc(host, port)
            except ValueError:
                print(f"[-] Format connection salah. Gunakan: 127.0.0.1:1337")
        
        elif args.data:
            decoded_data = self.auto_decode(args.data)
            self.solve_caesar(decoded_data)
            if args.key:
                res = self.vigenere_decrypt(decoded_data, args.key)
                print(f"    [+] Vigenere: {res}")
            try:
                clean_hex = args.data.replace("0x", "").replace(" ", "")
                bytes_data = bytes.fromhex(clean_hex)
                self.xor_bruteforce(bytes_data)
            except:
                self.xor_bruteforce(decoded_data.encode())
        else:
            print("[-] Please provide --data (for static) or --attack (for interactive).")