import os
import shutil
import time
from kalameet.core.base import BasePlugin
from kalameet.core.interface import UI, Colors
from kalameet.config import settings
from kalameet.core.translate import _

class cleanPlugin(BasePlugin):
    meta = {
        'name': 'clean',
        'description': '',
        'author': 'rhkapota'
    }

    def add_arguments(self, parser):
        parser.add_argument("-y", "--yes", action="store_true", help=_('argument.yes'))

    def remove_contents(self, folder):
        count = 0
        if not os.path.exists(folder): return 0
        
        for item in os.listdir(folder):
            item_path = os.path.join(folder, item)
            try:
                if os.path.isfile(item_path):
                    os.unlink(item_path)
                    count += 1
                elif os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                    count += 1
            except: pass
        return count

    def run(self, args):
        UI.header("CLEANUP SYSTEM")

        if not args.yes:
            print(f"[{Colors.WARNING}!{Colors.ENDC}] {Colors.YELLOW}{_('plugins.clean.info')}{Colors.ENDC}")
            print(f"    [{Colors.GREEN}+{Colors.ENDC}] Target: {settings.LOG_DIR}")

            try:
                confirm = input(f"\n[{Colors.YELLOW}*{Colors.ENDC}] {_('plugins.clean.confirm')} (y/N): ")
                if confirm.lower() != 'y':
                    UI.print_error(f"{_('stopped')}")
                    return
            except KeyboardInterrupt:
                print("")
                return

        print(f"[{Colors.GREEN}*{Colors.ENDC}] {Colors.GREEN}{_('plugins.clean.start')}{Colors.ENDC}")
        
        total_deleted = 0
        cache_deleted = 0
        
        time.sleep(0.5)
        log_count = self.remove_contents(settings.LOG_DIR)
        total_deleted += log_count
        
        if log_count > 0:
            UI.console.print(f"    [[green]✓[/]] Logs cleared          : {log_count} items removed")
        else:
            UI.console.print(f"    [[dim]-[/]] Logs directory        : Already clean")

        time.sleep(0.3)
        base_dir = settings.BASE_DIR
        for root, dirs, files in os.walk(base_dir):
            for d in dirs:
                if d == "__pycache__":
                    path = os.path.join(root, d)
                    try:
                        shutil.rmtree(path)
                        cache_deleted += 1
                    except: pass
        
        if cache_deleted > 0:
            UI.console.print(f"    [[green]✓[/]] Python cache purged   : {cache_deleted} folders removed")
        else:
            UI.console.print(f"    [[dim]-[/]] Python cache          : Clean")

        if total_deleted > 0 or cache_deleted > 0:
            print(f"[{Colors.GREEN}✓{Colors.ENDC}] {Colors.GREEN}{_('plugins.clean.success')}{Colors.ENDC}")
            print(f"    Total cache removed: {total_deleted + cache_deleted}")
        else:
            print(f"[{Colors.GREEN}✓{Colors.ENDC}] {Colors.GREEN}System was already clean.")