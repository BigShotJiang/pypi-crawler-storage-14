import requests
import concurrent.futures
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import UI, Colors

class CloudHunterPlugin(BasePlugin):
    meta = {
        'name': 's3hunt',
        'description': 'AWS S3 Bucket Leaks Scanner (Rich UI)',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="s3_hunter")
        self.found_count = 0

    def add_arguments(self, parser):
        parser.add_argument("-n", "--name", required=True, help="Base Company Name (e.g. 'flaws.cloud')")

    def check_bucket(self, bucket_name):
        url = f"http://{bucket_name}.s3.amazonaws.com"
        try:
            # Timeout pendek biar cepat scan-nya
            r = requests.get(url, timeout=3)
            if r.status_code == 200:
                return (200, url, "PUBLIC (LISTABLE)")
            elif r.status_code == 403:
                return (403, url, "PROTECTED (Exists but locked)")
        except: pass
        return None

    def run(self, args):
        base = args.name
        UI.header(f"CLOUD BUCKET HUNTER: {base}")
        
        # Generate variasi nama bucket (Mutations)
        permutations = [
            f"{base}", f"www.{base}", f"{base}.com",
            f"{base}-dev", f"{base}-prod", f"{base}-test", f"{base}-staging",
            f"{base}-backup", f"{base}-private", f"{base}-public",
            f"{base}-logs", f"{base}-data", f"{base}-assets", f"{base}-static",
            f"{base}-media", f"{base}-images", f"{base}-db",
            f"dev-{base}", f"prod-{base}", f"backup-{base}",
            f"s3-{base}", f"{base}-s3", f"{base}-bucket"
        ]
        
        # Reset Counter
        self.found_count = 0

        # [UI UPGRADE] Menggunakan Progress Bar
        with UI.progress_bar() as progress:
            task = progress.add_task(f"[cyan]Hunting {len(permutations)} buckets...", total=len(permutations))
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                futures = {executor.submit(self.check_bucket, name): name for name in permutations}
                
                for future in concurrent.futures.as_completed(futures):
                    progress.advance(task, 1)
                    res = future.result()
                    
                    if res:
                        code, url, status = res
                        self.found_count += 1
                        
                        if code == 200:
                            # 200 OK = CRITICAL (Hijau Terang)
                            msg = f"[bold green][+][/] [green][{code}][/] [bold white]{url}[/] -> [bold red]{status}[/]"
                            progress.console.print(msg)
                            
                            # Tampilkan Payload download AWS CLI
                            clean_url = url.replace("http://", "").replace(".s3.amazonaws.com", "")
                            progress.console.print(f"    [dim]└── Payload: aws s3 ls s3://{clean_url} --no-sign-request[/]")
                            
                            self.logger.log("S3Hunt", "LEAK", f"Public Bucket Found: {url}")
                            
                        elif code == 403:
                            # 403 Forbidden = Info (Kuning)
                            msg = f"[bold yellow][*][/] [yellow][{code}][/] [dim white]{url}[/] -> [dim]{status}[/]"
                            progress.console.print(msg)

        # Penutup
        print("-" * 60)
        if self.found_count > 0:
            UI.print_success(f"S3 HUNT FINISHED. Total Buckets Found: {self.found_count}")
        else:
            UI.print_error("No open buckets found with standard mutations.")