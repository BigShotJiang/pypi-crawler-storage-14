import socket
import concurrent.futures
from datetime import datetime
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import UI, Colors 

class portsPlugin(BasePlugin):
    meta = {
        'name': 'ports',
        'description': '',
        'author': 'rhkapota'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="ports")
        self.common_ports = {
            21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS',
            80: 'HTTP', 110: 'POP3', 143: 'IMAP', 443: 'HTTPS', 445: 'SMB',
            1433: 'MSSQL', 3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL',
            6379: 'Redis', 8080: 'HTTP-Proxy', 8443: 'HTTPS-Alt', 27017: 'MongoDB'
        }

    def add_arguments(self, parser):
        parser.add_argument("-t", "--target", required=True, help="Target IP/Hostname")
        parser.add_argument("--threads", type=int, default=50, help="Number of threads (Default: 50)")
        parser.add_argument("--range", type=int, default=1024, help="Max port range (Default: 1024)")

    # Tambahkan method ini di dalam class portsPlugin
    def get_banner(self, target, port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect((target, port))
            # Kirim bytes kosong atau payload pancingan jika perlu
            if port == 80 or port == 8080:
                s.send(b'HEAD / HTTP/1.0\r\n\r\n')
        
            banner = s.recv(1024).decode('utf-8', errors='ignore').strip()
            s.close()
            return banner
        except:
            return None

    def scan_port(self, target, port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.5) 
            result = s.connect_ex((target, port))
            s.close()
            
            if result == 0:
                service = self.common_ports.get(port, "Unknown")
                banner = self.get_banner(target, port) # Ambil banner
                if banner:
                    service += f" ({banner[:30]}...)" # Tampilkan 30 karakter pertama
                return port, service
        except: pass
        return None

    def run(self, args):
        raw_target = args.target
        clean_target = raw_target.replace("http://", "").replace("https://", "").split("/")[0]

        UI.header(f"NETWORK SCANNER")
        
        try:
            target_ip = socket.gethostbyname(clean_target)
            UI.console.print(f"[[green]+[/]] Target Host: [bold cyan]{clean_target}[/]")
            UI.console.print(f"[[green]+[/]] Target IP  : [bold cyan]{target_ip}[/]")
            UI.console.print(f"[[green]+[/]] Range      : 1-{args.range}")
            UI.console.print(f"[[green]+[/]] Threads    : {args.threads}")
            print("-" * 60)
        except socket.gaierror:
            UI.print_error("Hostname could not be resolved.")
            return

        start_time = datetime.now()
        open_ports = [] 
        
        with UI.console.status(f"[bold cyan]Scanning ports on {target_ip}...[/]", spinner="dots"):
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as executor:
                futures = {executor.submit(self.scan_port, target_ip, port): port for port in range(1, args.range + 1)}
                
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    if result:
                        port, service = result
                        open_ports.append([str(port), "TCP", service, "OPEN"])
                        self.logger.log("PortScanner", "OPEN", f"Port {port} is open", {"port": port, "service": service})

        duration_obj = datetime.now() - start_time
        duration_fmt = f"{duration_obj.total_seconds():.2f}s"
        
        if open_ports:
            print("") 
            open_ports.sort(key=lambda x: int(x[0])) 
            
            UI.table(["Port", "Protocol", "Service", "Status"], open_ports, title=f"Scan Results for {target_ip}")
            UI.print_success(f"Scan finished in {duration_fmt}. Found {len(open_ports)} open ports.")
        else:
            print("")
            UI.print_error(f"Scan finished in {duration_fmt}. No open ports found.")