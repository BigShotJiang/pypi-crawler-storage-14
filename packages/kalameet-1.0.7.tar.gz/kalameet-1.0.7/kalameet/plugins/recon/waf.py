import requests
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import UI, Colors
from kalameet.config import settings

class wafPlugin(BasePlugin):
    meta = {
        'name': 'waf',
        'description': '',
        'author': 'rhkapota'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="waf")
        self.waf_signatures = {
            "Cloudflare": ["cf-ray", "__cfduid", "cloudflare", "cf-cache-status"],
            "AWS WAF": ["x-amzn-requestid", "aws", "x-amz-cf-id"],
            "Akamai": ["akamai", "x-akamai", "x-akamai-trans-id"],
            "Google GFE/GWS": ["gws", "gfe", "esf", "google frontend"],
            "ModSecurity": ["mod_security", "not acceptable", "mod_security"],
            "F5 BIG-IP": ["big-ip", "bigip", "f5_cspm"],
            "Barracuda": ["barra", "barracuda"],
            "Imperva Incapsula": ["incap_ses", "visid_incap", "x-cdn"],
            "Wordfence": ["wordfence"],
            "Sucuri": ["sucuri", "x-sucuri"],
            "Palo Alto": ["miss", "hit"],
            "Citrix NetScaler": ["ns-server-id", "citrix"],
            "Nginx Generic Defense": ["nginx"],
        }

    def add_arguments(self, parser):
        parser.add_argument("-t", "--target", required=True, help="Target URL")

    def detect(self, headers, content):
        detected = []
        content = content.lower()
        
        for header, value in headers.items():
            header_full = f"{header}: {value}".lower()
            
            for waf, sigs in self.waf_signatures.items():
                for sig in sigs:
                    # Cek apakah signature ada di KEY atau VALUE header
                    if sig in header_full and waf not in detected:
                        detected.append(waf)

        for waf, sigs in self.waf_signatures.items():
            for sig in sigs:
                if sig in content and waf not in detected:
                    detected.append(waf)
                    
        return detected

    def run(self, args):
        target = args.target

        if not target.startswith(("http://", "https://")):
            target = f"http://{target}"

        UI.header(f"WAF DETECTOR")
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Target lock: {Colors.GREEN}{target}{Colors.ENDC}")
        print(f"[{Colors.GREEN}+{Colors.ENDC}] Signature DB Size: {Colors.GREEN}{len(self.waf_signatures)}{Colors.ENDC}")
        
        with UI.console.status("[bold cyan]Probing firewall defenses...[/]", spinner="dots"):
            try:
                r = requests.get(target, timeout=settings.DEFAULT_TIMEOUT)
                normal_code = r.status_code
                passive_waf = self.detect(r.headers, r.text)
            except Exception as e:
                UI.print_error(f"Connection failed: {str(e)}")
                return

            try:
                payload = {"id": "<script>alert('kalameet')</script>", "select": "UNION SELECT 1,2,3"}
                r_mal = requests.get(target, params=payload, timeout=settings.DEFAULT_TIMEOUT)
                mal_code = r_mal.status_code
                
                print(f"    Normal Request    : {Colors.BLUE}{normal_code}{Colors.ENDC}")
                print(f"    Malicious Request : {Colors.WARNING}{mal_code}{Colors.ENDC}")
                print("")
                
                active_waf = self.detect(r_mal.headers, r_mal.text)
                
                all_detected = list(set(passive_waf + active_waf))

                if mal_code in [403, 406, 501, 405]:
                    UI.print_success(f"Protection Detected (Blocked with {mal_code})")
                    if all_detected:
                        for w in all_detected:
                            UI.print_success(f"Identified: {w}")
                    else:
                        UI.print_warning("Generic WAF/ACL detected (Signature unknown)")

                elif all_detected:
                    UI.print_info(f"Traffic allowed ({mal_code}), but security device identified:")
                    for w in all_detected:
                        UI.console.print(f"[bold cyan]    -> {w}[/]")
                    UI.console.print("[yellow]    Note: The WAF might be in monitoring mode or sanitizing input silently.[/]")

                elif mal_code == 200:
                    UI.print_warning("No Blocking & No Signatures Detected.")
                    UI.console.print("    Target might be vulnerable OR using a very stealthy sanitization method.")
                
                else:
                    UI.print_info(f"Server returned {mal_code}. Results inconclusive.")

            except Exception as e:
                UI.print_error(f"Error during probe: {e}")