import socket
import os
from kalameet.core.base import BasePlugin
from kalameet.core.logger import Logger
from kalameet.core.interface import UI, Colors

class SnifferPlugin(BasePlugin):
    meta = {
        'name': 'sniff',
        'description': 'Real-time Network Packet Sniffer (Live Stream)',
        'author': 'Kalameet'
    }

    def __init__(self):
        super().__init__()
        self.logger = Logger(session_name="sniffer")
        self.packet_count = 0

    def add_arguments(self, parser):
        pass

    def get_local_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except: return "127.0.0.1"

    def run(self, args):
        host = self.get_local_ip()
        UI.header(f"NETWORK SNIFFER: {host}")
        
        # Cek Root (Hanya validasi, bukan restart)
        if os.name != 'nt' and os.geteuid() != 0:
            UI.print_error("Access Denied! This module requires ROOT privileges.")
            print(f"{Colors.WARNING}[*] Tip: The launcher should have asked for sudo. Try running as root manually.{Colors.ENDC}")
            return

        if host == "127.0.0.1":
            UI.print_error("Failed to detect LAN IP.")
            return

        try:
            # Setup Socket (Linux)
            sniffer = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
            sniffer.bind((host, 0))
            sniffer.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

            UI.print_success(f"Sniffer Initialized on {host}. Capturing packets...")
            print(f"{Colors.BOLD}[i] Press Ctrl+C to stop capture.{Colors.ENDC}\n")
            
            print(f"  {Colors.BOLD}{Colors.MAGENTA}{'SEQ':<6} {'SOURCE IP':<20} {'SIZE':<10} {'STATUS'}{Colors.ENDC}")
            print("-" * 60)

            while True:
                raw_data, addr = sniffer.recvfrom(65535)
                self.packet_count += 1
                
                print(
                    f"  {Colors.BLUE}#{self.packet_count:<5}{Colors.ENDC} "
                    f"{Colors.CYAN}{addr[0]:<20}{Colors.ENDC} "
                    f"{Colors.YELLOW}{len(raw_data)} bytes{Colors.ENDC}"
                )
                
                self.logger.log("Sniffer", "CAPTURED", f"Packet from {addr[0]}")

        except KeyboardInterrupt:
            print("-" * 60)
            UI.print_success(f"Sniffer stopped. Total Packets: {self.packet_count}")
        except Exception as e:
            UI.print_error(f"Runtime Error: {e}")