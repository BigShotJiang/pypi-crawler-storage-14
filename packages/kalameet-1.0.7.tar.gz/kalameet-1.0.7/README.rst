=====================================================
Kalameet Framework v5.2
=====================================================

|image_pypi_status|

.. image:: https://img.shields.io/badge/Status-BATTLE_READY-green.svg
   :target: https://github.com/rhkapota/kalameet

Autonomous Cyber Security Framework
-----------------------------------
Kalameet is an advanced, modular, and autonomous cyber security framework designed for CTF competitions and Red Teaming. It utilizes advanced techniques like AsyncIO, Payload Obfuscation, and integrated AI analysis.

**[✓] Key Features:**

* **Modular Architecture:** Plug-and-play system.
* **High Speed Recon:** AsyncIO Dirbusting (blitz) and Subdomain Hunting.
* **Advanced Exploits:** VulnLab Solver, Polyglot payloads, and Nmap/SQLMap orchestration.
* **Stealth:** User-Agent Rotation and Header Spoofing.
* **Persistence:** Shadow C2 Agent generation.

**[!] Disclaimer:** For Educational Purposes and Authorized Testing Only.

Installation
------------

To install the framework:

.. code-block:: bash

    # 1. Install from Source Code (Recommended for Development)
    pip install -e .

    # 2. Run initial system dependency check
    kalameet verify

Usage Example
-------------

To run a stealthy directory scan:

.. code-block:: bash

    kalameet dirbust -t http://testfire.net --threads 50

To use the AI auditor on a file:

.. code-block:: bash

    kalameet ask_ai --file leaked_code.js --key $OPENAI_KEY

.. |image_pypi_status| image:: https://img.shields.io/pypi/v/kalameet.svg
   :target: https://pypi.org/project/kalameet/