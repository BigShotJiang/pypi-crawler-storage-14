SELECT indexname FROM pg_indexes where schemaname = '{{pg_schema}}';
