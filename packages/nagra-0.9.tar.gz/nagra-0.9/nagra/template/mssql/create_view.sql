CREATE OR ALTER VIEW [{{ name }}] AS {{ view_def }};
