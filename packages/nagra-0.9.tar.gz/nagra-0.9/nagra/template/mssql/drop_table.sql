DROP TABLE IF EXISTS [{{ name }}];
