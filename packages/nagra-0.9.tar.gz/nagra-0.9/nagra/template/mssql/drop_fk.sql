ALTER TABLE [{{ table }}] DROP CONSTRAINT [{{ name }}];
