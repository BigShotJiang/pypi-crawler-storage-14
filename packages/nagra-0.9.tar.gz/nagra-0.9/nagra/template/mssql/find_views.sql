SELECT table_name, view_definition
FROM information_schema.views
;
