{% for name, value in _all_params.items() -%}
{{name}}={{value}}
{% endfor %}
