 SELECT * from duckdb_constraints();
