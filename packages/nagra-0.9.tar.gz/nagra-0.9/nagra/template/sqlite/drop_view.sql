DROP VIEW IF EXISTS "{{name}}";
