from .detector import PlatformDetector, PlatformInfo

__all__ = ["PlatformDetector", "PlatformInfo"]
