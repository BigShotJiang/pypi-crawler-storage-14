import sys

# OS runtime
IS_OS_MACOS = sys.platform == "darwin"
IS_OS_LINUX = sys.platform == "linux"
