class VacumException(Exception):
    pass
