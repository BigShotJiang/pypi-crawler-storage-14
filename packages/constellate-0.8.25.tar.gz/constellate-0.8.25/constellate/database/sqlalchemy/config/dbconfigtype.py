from enum import IntEnum, auto


class DBConfigType(IntEnum):
    INSTANCE = auto()
    TEMPLATE = auto()
