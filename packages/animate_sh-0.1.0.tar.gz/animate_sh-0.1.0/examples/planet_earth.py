#!/usr/bin/env python3
"""Planet Earth animation example."""

from animate import play
from animate.animations import PlanetEarth


def main() -> None:
    """Run planet Earth animation examples."""
    print("Example 1: Planet Earth - Play once")
    play(PlanetEarth())

    print("\nExample 2: Planet Earth - Loop for 5 seconds")
    play(PlanetEarth(), loop=True, timeout=5)

    print("\nExample 3: Planet Earth - Repeat 3 times")
    play(PlanetEarth(), repeat_count=3)

    print("\nExample 4: Planet Earth - Custom FPS (1 FPS - slower rotation)")
    play(PlanetEarth(), repeat_count=2, fps=1)


if __name__ == "__main__":
    main()
