"""Tests for animate package."""
