"""Tests for animation classes."""

from animate.animations.cyber_text import CyberText
from animate.animations.planet import PlanetEarth
from animate.animations.spinner import Spinner


class TestSpinner:
    """Tests for Spinner animation."""

    def test_spinner_get_frames(self) -> None:
        """Test that spinner returns correct frames."""
        spinner = Spinner()
        frames = spinner.get_frames()
        assert frames == ["|", "/", "-", "\\"]

    def test_spinner_get_fps(self) -> None:
        """Test that spinner returns correct FPS."""
        spinner = Spinner()
        assert spinner.get_fps() == 10.0

    def test_spinner_frames_not_empty(self) -> None:
        """Test that spinner frames are not empty."""
        spinner = Spinner()
        frames = spinner.get_frames()
        assert len(frames) > 0


class TestPlanetEarth:
    """Tests for PlanetEarth animation."""

    def test_planet_earth_get_frames(self) -> None:
        """Test that planet earth returns frames."""
        planet = PlanetEarth()
        frames = planet.get_frames()
        assert len(frames) > 0

    def test_planet_earth_get_fps(self) -> None:
        """Test that planet earth returns correct FPS."""
        planet = PlanetEarth()
        assert planet.get_fps() == 1.5

    def test_planet_earth_frames_contain_earth_art(self) -> None:
        """Test that frames contain recognizable Earth ASCII art."""
        planet = PlanetEarth()
        frames = planet.get_frames()
        # Check that frames contain Earth visualization elements (~ for ocean, @ for land)
        assert all("~" in frame and "@" in frame for frame in frames)


class TestCyberText:
    """Tests for CyberText animation."""

    def test_cyber_text_get_frames(self) -> None:
        """Test that cyber text returns frames."""
        cyber = CyberText("TEST")
        frames = cyber.get_frames()
        # Text is normalized to 10 chars, so 10 + 10 (window) = 20 frames
        assert len(frames) == 20

    def test_cyber_text_get_fps(self) -> None:
        """Test that cyber text returns correct FPS."""
        cyber = CyberText("TEST")
        assert cyber.get_fps() == 2.0

    def test_cyber_text_with_custom_text(self) -> None:
        """Test cyber text with custom input."""
        cyber = CyberText("HACK")
        frames = cyber.get_frames()
        # Text should appear in frames
        assert any("HACK" in frame for frame in frames)

    def test_cyber_text_default_text(self) -> None:
        """Test cyber text with default text."""
        cyber = CyberText()
        frames = cyber.get_frames()
        # Default text starts with 'CYBER' which should appear
        assert any("CYBER" in frame for frame in frames)

    def test_cyber_text_text_normalization(self) -> None:
        """Test that text is normalized to uppercase."""
        cyber = CyberText("hello")
        frames = cyber.get_frames()
        # Should be uppercase
        assert any("HELLO" in frame for frame in frames)
