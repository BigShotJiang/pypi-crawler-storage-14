"""Tests for core animation engine."""

import pytest

from animate.animations.spinner import Spinner
from animate.core import play


class TestPlay:
    """Tests for the play function."""

    def test_play_once(self) -> None:
        """Test playing animation once."""
        spinner = Spinner()
        # Should not raise any exception
        play(spinner)

    def test_play_with_repeat_count(self) -> None:
        """Test playing animation with repeat count."""
        spinner = Spinner()
        play(spinner, repeat_count=2)

    def test_play_with_loop_and_timeout(self) -> None:
        """Test looping with timeout."""
        spinner = Spinner()
        play(spinner, loop=True, timeout=0.1)

    def test_play_with_custom_fps(self) -> None:
        """Test custom FPS override."""
        spinner = Spinner()
        play(spinner, fps=5)

    def test_play_with_no_clear(self) -> None:
        """Test playing without clearing screen."""
        spinner = Spinner()
        play(spinner, clear=False)

    def test_play_raises_on_loop_and_repeat_count(self) -> None:
        """Test that specifying both loop and repeat_count raises error."""
        spinner = Spinner()
        with pytest.raises(ValueError, match="Cannot specify both"):
            play(spinner, loop=True, repeat_count=2)

    def test_play_raises_on_invalid_fps(self) -> None:
        """Test that invalid FPS raises error."""
        spinner = Spinner()
        with pytest.raises(ValueError, match="FPS must be positive"):
            play(spinner, fps=0)

    def test_play_raises_on_negative_fps(self) -> None:
        """Test that negative FPS raises error."""
        spinner = Spinner()
        with pytest.raises(ValueError, match="FPS must be positive"):
            play(spinner, fps=-1)
