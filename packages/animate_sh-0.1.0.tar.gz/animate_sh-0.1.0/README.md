# Animate

A Python library for printing animated ASCII art in the terminal.

## Features

- Simple and intuitive API
- Support for custom animations
- Configurable playback options (loop, timeout, FPS)
- Terminal-friendly and cross-platform

## Installation

Using pip:

```sh
pip install animate-sh
```

Using uv:

```sh
uv add animate-sh
```

With color support:

```sh
# pip
pip install animate-sh[color]

# uv
uv add animate-sh[color]
```

## Quick Start

```python
from animate import play
from animate.animations import Spinner

# Play a spinner animation
play(Spinner(), loop=True, timeout=10)
```

## Development

This project uses [just](https://github.com/casey/just) for task automation.

```sh
# Install dependencies
just install

# Run all checks (format, lint, type-check, test)
just check

# Individual commands
just test              # Run tests
just format            # Format code
just lint              # Lint code
just lint-fix          # Fix linting issues
just type-check        # Type check
just examples          # Run example scripts
just build             # Build distribution
just clean             # Clean build artifacts
```

## License

[MIT License](./LICENSE)
