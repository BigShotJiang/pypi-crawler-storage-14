"""Animate - A Python library for printing animated ASCII art."""

from animate.animations.base import BaseAnimation
from animate.core import play

__version__ = "0.0.1"
__all__ = ["play", "BaseAnimation"]
