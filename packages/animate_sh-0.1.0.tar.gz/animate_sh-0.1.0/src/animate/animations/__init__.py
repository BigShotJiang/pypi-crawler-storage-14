"""Animation templates."""

from animate.animations.base import BaseAnimation
from animate.animations.cyber_text import CyberText
from animate.animations.planet import PlanetEarth
from animate.animations.spinner import Spinner

__all__ = ["BaseAnimation", "Spinner", "PlanetEarth", "CyberText"]
