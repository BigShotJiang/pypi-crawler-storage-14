"""Cyberpunk style rotating text animation."""

from animate.animations.base import BaseAnimation


class CyberText(BaseAnimation):
    """Text scrolling through fixed sphere in cyberpunk style."""

    def __init__(self, text: str = "CYBERPUNK") -> None:
        """Initialize the CyberText animation.

        Args:
            text: The text to display as marquee (up to 10 characters).
                 Will be padded or truncated to 10 chars.
        """
        # Normalize text to exactly 10 characters
        self.text = (text.upper() + " " * 10)[:10]

        # Create frames with text scrolling through fixed sphere
        self._frames = self._generate_frames()

    def _generate_frames(self) -> list[str]:
        """Generate text marquee frames scrolling left-to-right inside sphere.

        Returns:
            List of frames showing text scrolling horizontally inside the sphere.
        """
        frames = []

        # Fixed sphere structure
        sphere_head = "    '=========='          "
        sphere_top = "  /             \\        "
        sphere_mid1 = " /               \\       "
        sphere_mid2 = "|                 |      "
        sphere_mid4 = "|                 |      "
        sphere_mid5 = " \\               /       "
        sphere_bottom1 = "  \\             /        "
        sphere_bottom2 = "    '=========='          "

        # Create repeating text for continuous marquee
        # The visible window is 10 chars, so we need enough repetition
        repeating_text = "          " + self.text + "          "  # Padding before and after

        # Generate frames for full scroll from right edge to left edge and beyond
        # Number of frames = length of text + visible window size
        num_frames = len(self.text) + 10

        for offset in range(num_frames):
            # Extract visible portion of text (10 chars wide inside sphere)
            visible_text = (repeating_text[offset : offset + 10]).ljust(10)

            # Format text line with proper spacing inside sphere
            # Format: 6 spaces + pipe + 10 char text + pipe
            text_line = f"|    {visible_text}   |"

            frame_lines = [
                sphere_head,
                sphere_top,
                sphere_mid1,
                sphere_mid2,
                text_line,
                sphere_mid4,
                sphere_mid5,
                sphere_bottom1,
                sphere_bottom2,
            ]

            frames.append("\n".join(frame_lines))

        return frames

    def get_frames(self) -> list[str]:
        """Get CyberText animation frames.

        Returns:
            List of frames showing rotating sphere with fixed text.
        """
        return self._frames

    def get_fps(self) -> float:
        """Get frames per second.

        Returns:
            2 FPS for smooth rotation effect.
        """
        return 2.0
