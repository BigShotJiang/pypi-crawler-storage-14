from julax.base import PyTree


def create_global_input(
    process_local_data: PyTree,
): ...
