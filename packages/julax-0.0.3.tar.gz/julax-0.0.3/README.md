<div align="center">
  <p>
  <img src="https://github.com/oolong-dev/julax/raw/main/docs/logo.svg?sanitize=true" width="320px">
  </p>
  <p>
  <h1>JULAX: Just Layers over JAX</h1>
  </p>
</div>