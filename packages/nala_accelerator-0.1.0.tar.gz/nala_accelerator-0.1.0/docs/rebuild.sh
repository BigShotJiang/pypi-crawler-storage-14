#!/bin/bash
make clean
rm -r source/automod/*
make html