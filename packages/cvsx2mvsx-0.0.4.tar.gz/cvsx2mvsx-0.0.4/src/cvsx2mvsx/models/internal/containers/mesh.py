from pydantic import BaseModel


class MeshContainer(BaseModel):
    vertices: list[float]
    indices: list[int]
    triangle_groups: list[int]
