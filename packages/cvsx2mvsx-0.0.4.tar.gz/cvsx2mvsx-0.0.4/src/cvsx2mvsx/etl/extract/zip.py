import os
from zipfile import BadZipFile, ZipFile


class ZipExtractor:
    def __init__(self, zip_path: str, out_dir_path: str) -> None:
        self._zip_path = zip_path
        self._out_dir_path = out_dir_path

    def run(self) -> None:
        if not os.path.exists(self._zip_path):
            raise FileNotFoundError(f"ZIP archive not found: '{self._zip_path}'")
        if not os.path.isfile(self._zip_path):
            raise ValueError(f"Path exists but is not a file: '{self._zip_path}'")

        os.makedirs(self._out_dir_path, exist_ok=True)

        try:
            with ZipFile(self._zip_path, "r") as z:
                z.extractall(self._out_dir_path)
        except BadZipFile:
            raise ValueError(
                f"File '{self._zip_path}' is corrupted or not a valid ZIP archive."
            )
        except Exception as e:
            raise RuntimeError(f"Failed to extract zip archive: {e}")
