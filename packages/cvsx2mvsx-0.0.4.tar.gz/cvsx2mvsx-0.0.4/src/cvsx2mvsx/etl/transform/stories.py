import os
from uuid import uuid4

from cvsx2mvsx.models.internal.entry import InternalEntry
from cvsx2mvsx.models.internal.segmentation import InternalSegmentation
from cvsx2mvsx.models.internal.volume import InternalVolume
from cvsx2mvsx.models.mvsx.states import MVSXEntry
from cvsx2mvsx.models.stories.model import (
    SceneAsset,
    SceneData,
    Story,
    StoryContainer,
    StoryMetadata,
)


class StoriesTransformer:
    def __init__(self, internal_entry: InternalEntry, mvsx_entry: MVSXEntry) -> None:
        self._internal_entry = internal_entry
        self._mvsx_entry = mvsx_entry

    def run(self) -> StoryContainer:
        # 1. Collect all assets (Main MVSX file + all Volumes and Segmentations)
        assets = self._collect_all_assets()

        # 2. Generate Scenes (one per timeframe)
        scenes: list[SceneData] = []

        # Sort timeframes to ensure order
        sorted_timeframes = sorted(
            self._internal_entry.timeframes.items(), key=lambda t: t[0]
        )

        for timeframe_id, timeframe in sorted_timeframes:
            # Generate the JavaScript that replicates the MVSX structure for this frame
            js_logic = self._generate_javascript_for_timeframe(timeframe)

            scene = SceneData(
                id=str(uuid4()),
                header=f"Timeframe {timeframe_id}",
                key=str(timeframe_id),
                description=f"Snapshot of timeframe {timeframe_id}",
                javascript=js_logic,
            )
            scenes.append(scene)

        # 3. Handle case where no timeframes exist (fallback)
        if not scenes:
            scenes.append(
                SceneData(
                    id=str(uuid4()),
                    header="Empty Story",
                    key="empty",
                    description="No timeframes found.",
                    javascript="",
                )
            )

        # 4. Create Metadata
        metadata = StoryMetadata(
            title=self._internal_entry.name or "Untitled Story",
            author_note=self._internal_entry.description,
        )

        # 5. Build the Story
        story = Story(
            metadata=metadata,
            javascript="",  # Global JS if needed
            scenes=scenes,
            assets=assets,
        )

        return StoryContainer(story=story)

    def _collect_all_assets(self) -> list[SceneAsset]:
        assets: list[SceneAsset] = []

        for root, dirs, files in os.walk(self._mvsx_entry.asset_dir):
            for file in files:
                full_path = os.path.join(root, file)

                # We need to preserve the relative structure (e.g. volumes/file.bcif)
                # so the JS can reference it correctly
                rel_path = os.path.relpath(full_path, self._mvsx_entry.asset_dir)

                with open(full_path, "rb") as f:
                    content = f.read()
                assets.append(SceneAsset(name=rel_path, content=content))
        return assets

    def _generate_javascript_for_timeframe(self, timeframe) -> str:
        """
        Generates a JavaScript string that uses the MVS builder to construct
        the state for a specific timeframe.
        """
        lines = []

        # 1. Initialize Builder
        # Assuming the context provides a 'builder' instance or we create one.
        # This syntax matches the standard MolViewSpec JS examples.
        lines.append("// Initialize State")

        # 2. Process Volumes
        for volume in timeframe.volumes.values():
            lines.append(self._js_volume(volume))

        # 3. Process Segmentations
        for segmentation in timeframe.segmentations.values():
            lines.append(self._js_segmentation(segmentation))

        return "\n".join(lines)

    def _js_volume(self, volume: InternalVolume) -> str:
        filename = os.path.basename(volume.source_filepath)
        # Path must match the structure in _collect_all_assets (relative to asset root)
        url = f"volumes/{filename}"

        # Base chain: download -> parse -> volume
        js = (
            f"builder.download({{ url: '{url}' }})"
            f".parse({{ format: 'bcif' }})"
            f".volume({{ channel_id: '{volume.channel_id}' }})"
        )

        # Representation parameters
        if volume.kind == "isosurface":
            js += (
                f".representation({{"
                f" type: 'isosurface',"
                f" relative_isovalue: {volume.relative_isovalue},"
                f" }})"
            )
        else:
            # Grid slice
            js += (
                f".representation({{"
                f" type: 'grid_slice',"
                f" relative_isovalue: {volume.relative_isovalue},"
                f" dimension: '{volume.dimension}',"
                f" }})"
            )

        # Common opacity
        js += f".color({{ color: '{volume.color}' }})"
        js += f".opacity({{ opacity: {volume.opacity} }});"
        return js

    def _js_segmentation(self, segmentation: InternalSegmentation) -> str:
        js = ""

        if segmentation.kind == "volume":
            pass
        elif segmentation.kind == "mesh":
            # Mesh segmentations are stored as JSON/MVSJ primitives
            for segment in segmentation.segments.values():
                filename = os.path.basename(segment.source_filepath)
                url = f"segmentations/mesh/{filename}"

                # MVS JS API for loading primitives
                js += f"builder.primitivesFromUri({{ uri: '{url}', format: 'mvs-node-json' }});\n"

        elif segmentation.kind == "geometric":
            # Geometric segmentations are stored as JSON/MVSJ primitives
            filename = os.path.basename(segmentation.source_filepath)
            url = f"segmentations/geometric/{filename}"

            js += f"builder.primitivesFromUri({{ uri: '{url}', format: 'mvs-node-json' }});\n"

        return js
