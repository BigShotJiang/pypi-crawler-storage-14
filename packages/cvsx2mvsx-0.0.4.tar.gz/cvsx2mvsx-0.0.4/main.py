from cvsx2mvsx.etl.pipelines.mvsx import MVSXPipeline


def main():
    cvsx_path = "data/cvsx/zipped/lattice/emd-1832.cvsx"
    output_path = "temp/test.mvsx"

    MVSXPipeline(
        cvsx_path=cvsx_path,
        output_path=output_path,
    ).run()


if __name__ == "__main__":
    main()
