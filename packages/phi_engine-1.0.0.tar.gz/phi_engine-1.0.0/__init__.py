# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE-code for details.

# __init__.py
"""
φ-Engine: a research-grade runtime for factorial calculus and rational β-streams.

This package exposes the high-level API (`PhiEngine`, `PhiEngineConfig`) along with
certificate utilities and exact β-stream constructors for reproducible analysis in nearly constant time.
Without grids.
"""

__version__ = "0.1.0"

# Core engine + config
from .core.phi_engine import PhiEngine
from .core.phi_engine_config import PhiEngineConfig

# Core building blocks explicitly exported for users
from .core.betas import beta_operator_fractions
from .core.fib import fib_ladder

from .core.moments import (
    w_derivative,
    w_integral
)

# Certificates
from .core.certificates import (
    PhiCert,
    HashInfo,
    save_cert,
    load_cert,
    verify_hash,
    verify_moments,
    verify_cert,
    betas_from_cert,
    emit_cert_from_engine,
)

__all__ = [
    # Engine
    "PhiEngine",
    "PhiEngineConfig",
    # Builders / moments
    "beta_operator_fractions",
    "fib_ladder",
    "w_derivative",
    "w_integral",
    # Certificates
    "PhiCert",
    "HashInfo",
    "save_cert",
    "load_cert",
    "verify_hash",
    "verify_moments",
    "verify_cert",
    "betas_from_cert",
    "emit_cert_from_engine",
]
