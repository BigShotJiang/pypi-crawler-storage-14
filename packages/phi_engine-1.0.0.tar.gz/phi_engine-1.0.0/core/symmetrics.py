# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/symmetrics.py
"""
Elementary symmetric polynomial utilities for factorial contraction.

This module provides exact rational implementations of the symmetric-sum
relations required to construct β-streams. Given factorial-derived layers
xᵢ = 1/(Fᵢ!)², these routines compute σₖ and related structures that form
the coefficients of the characteristic polynomial P_R(x) = ∏(x - xᵢ).

Functions like `elem_symmetric_sums` and `leave_one_out_symmetric_sums`
are purely algebraic — no floating-point arithmetic, no approximation —
and define the exact combinatorial backbone of φ-calculus moment solving.

`Pprime_at_layers` computes the derivative of P_R(x) evaluated at each node,
producing the denominators needed for the canonical Lagrange-like formula:
    βᵢ = [1 / P′(xᵢ)] Σₖ wₖ (−1)^{R−k} σ_{R−k}^{(i)}

Together, these utilities supply the raw structural data for
`beta_from_moment_law`, ensuring that all β-streams remain exact and
reproducible under rational arithmetic.
"""

from fractions import Fraction
from typing import List


def elem_symmetric_sums(xs: List[Fraction]) -> List[Fraction]:
    """Compute σ_k for k=0..R+1 (σ_0=1) using standard recurrence."""
    n = len(xs)
    sigma = [Fraction(0)] * (n + 1)
    sigma[0] = Fraction(1)
    for x in xs:
        for k in range(n, 0, -1):
            sigma[k] += x * sigma[k-1]
    return sigma  # length n+1

def leave_one_out_symmetric_sums(xs: List[Fraction],
                                 sigma: List[Fraction]) -> List[List[Fraction]]:
    """
    σ_k = σ_k^{(i)} + x_i σ_{k-1}^{(i)},  σ_0^{(i)}=1.
    Solve forward for σ_k^{(i)}.
    """
    n = len(xs)
    R = n - 1
    loi: List[List[Fraction]] = []
    for i, xi in enumerate(xs):
        s = [Fraction(0)] * (R + 1)
        s[0] = Fraction(1)
        for k in range(1, R + 1):
            s[k] = sigma[k] - xi * s[k-1]
        loi.append(s)
    return loi

def Pprime_at_layers(xs: List[Fraction]) -> List[Fraction]:
    """P_R'(x_i) = ∏_{j≠i}(x_i - x_j)."""
    n = len(xs)
    out = []
    for i in range(n):
        xi = xs[i]
        prod = Fraction(1)
        for j in range(n):
            if j == i: continue
            prod *= (xi - xs[j])
        out.append(prod)
    return out
