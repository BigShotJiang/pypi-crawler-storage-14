# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/moments.py
"""
Moment laws defining factorial contraction targets for φ-calculus.

This module encodes the analytic moment constraints that define each
β-stream family — derivative, and integral — within the φ-Engine.
Each moment law provides the exact rational targets Σ βᵢ xᵢᵏ = Mₖ for
k = 0..R, forming the linear systems solved by `beta_from_moment_law`.

Unlike numerical quadrature weights, these coefficients are not fitted
to functions or grids; they are *structural laws*. Each set of weights
expresses how factorial displacements contract to yield the identity
for a given operator family. The “integral” mode, for example, enforces
Σ βᵢ xᵢᵏ = 1/(2k+1), reproducing the primitive-free symmetric integral.

These laws fully determine the calculus behavior of the φ-Engine:
  - `w_derivative`: δ-moment, for first-order difference contraction.
  - `w_integral`: moment targets 1/(2k+1) for first-order symmetric integral.

Together they form the canonical factorial basis of φ-calculus.
They allow functions to execute themselves, with no retrospection.
"""

from fractions import Fraction
from typing import List

def w_integral(n: int, order: int = 1) -> List[Fraction]:
    return [Fraction(1, 2*k + 1) for k in range(n)]

def w_derivative(n: int, order: int = 1) -> List[Fraction]:
    return [Fraction(1 if k == 0 else 0) for k in range(n)]

