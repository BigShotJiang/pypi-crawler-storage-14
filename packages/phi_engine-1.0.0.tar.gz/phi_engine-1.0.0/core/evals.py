# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/evals.py
"""
Adaptive evaluators for analytic function deltas and symmetric forms.

This module provides low-level adaptive routines that compute forward
and symmetric finite differences directly in mpmath space, without
using any mesh or discrete grid. Each evaluator increases decimal
precision until the result becomes both finite and nonzero, allowing
the φ-Engine to perform self-stabilizing contraction of β-streams.

Unlike classical quadrature or finite-difference approaches, these
evaluators treat evaluation as a *pure functional call* with adaptive
precision budgeting — never as an accumulation of samples. They are
therefore compatible with φ-calculus' identity-free structure, where
integration, differentiation, and symmetric value evaluation share a
single factorial framework.

Critically, these functions do not operate on point sets: they act
directly on factorial displacements derived from exact Fractions,
making them coefficient-driven, not coordinate-driven.

All deltas and symmetrics returned by these functions are deterministic
given the same function and Fraction inputs, regardless of the starting
precision, making them ideal primitives for exact β-stream contraction.
"""



from fractions import Fraction
from typing import Callable, Tuple
from mpmath import mp


def _eval_deltaF_adaptive(
    F_eval: Callable[[mp.mpf], mp.mpf],
    x0: mp.mpf,
    h_frac: Fraction,
    start_dps: int,
    max_dps: int,
    dps_step: int,
) -> Tuple[mp.mpf, int]:
    """
    Identity-free evaluation of ΔF = F(x0+h) - F(x0-h) with brute-force precision growth.
    Rebuild mp values from Fractions at each precision; double dps until ΔF != 0 and finite.
    """
    dps = max(64, start_dps)
    last = None
    while True:
        if dps > max_dps:
            return last if last is not None else mp.mpf('0'), max_dps
        with mp.workdps(dps):
            h_mp = mp.mpf(h_frac.numerator) / mp.mpf(h_frac.denominator)
            cur = F_eval(x0 + h_mp) - F_eval(x0 - h_mp)
        if mp.isfinite(cur) and cur != 0:
            return cur, dps
        last = cur
        dps = min(max_dps, max(dps + dps_step, dps * 2))

def _eval_symF_adaptive(
    F_eval: Callable[[mp.mpf], mp.mpf],
    x0: mp.mpf,
    h_frac: Fraction,
    start_dps: int,
    max_dps: int,
    dps_step: int,
) -> Tuple[mp.mpf, int]:
    """
    Adaptive evaluation of S = (F(x0+h) + F(x0-h))/2.
    Rebuild mp values from Fractions each step; escalate precision until finite.
    """
    dps = max(64, start_dps)
    last = None
    while True:
        if dps > max_dps:
            return last if last is not None else mp.mpf('0'), max_dps
        with mp.workdps(dps):
            h_mp = mp.mpf(h_frac.numerator) / mp.mpf(h_frac.denominator)
            cur = (F_eval(x0 + h_mp) + F_eval(x0 - h_mp)) * mp.mpf('0.5')
        if mp.isfinite(cur):
            return cur, dps
        last = cur
        dps = min(max_dps, max(dps + dps_step, dps * 2))
