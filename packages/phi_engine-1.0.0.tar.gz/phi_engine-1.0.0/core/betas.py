# Copyright (C) 2025 Purrplexia
# Licensed under the GNU GPLv3 or later. See LICENSE for details.

# phi_engine/core/betas.py
"""
Constructors for exact rational β-streams used throughout the φ-Engine.

Each β-stream defines the contraction weights that transform factorial
Fibonacci node evaluations into derivative, or integral results
without grids or numeric fitting.  All coefficients are derived exactly
as `fractions.Fraction` objects by solving the finite moment system:

    Σ_i β_i x_i^k = w_k,    for k = 0..R,

where `x_i = 1/(F_i!)²` and `w_k` comes from the selected moment law
in `moments.py`.  The resulting β-streams guarantee perfect algebraic
consistency and form the certified payload recorded in φ-certificates.

Functions
---------
- `beta_from_moment_law(xs, w)`
    Solve a given moment law for β-coefficients using exact arithmetic.
- `beta_operator_fractions(fib_count)`
    Build all standard β-streams ("derivative", "integral")
    for a specified factorial Fibonacci ladder length.

Dependencies
------------
Relies on:
- `symmetrics.py` for symmetric sum utilities.
- `fib.py` for factorial Fibonacci node generation.
- `moments.py` for target moment laws.
"""

from typing import Dict, List
from .symmetrics import *
from .fib import *
from .moments import *


def beta_from_moment_law(xs: List[Fraction],
                         w: List[Fraction]) -> List[Fraction]:
    """
    Solve for β-coefficients that satisfy a given factorial moment law.

    Parameters
    ----------
    xs : list[Fraction]
        Node locations, typically x_i = 1/(F_i!)² for a factorial Fibonacci ladder.
    w : list[Fraction]
        Target moments defining the contraction rule (from `moments.py`).

    Returns
    -------
    list[Fraction]
        Exact rational β-coefficients satisfying Σ_i β_i x_i^k = w_k
        for k = 0..R, with R = len(xs) - 1.

    Notes
    -----
    This function builds and solves the moment system using exact
    fraction arithmetic. It never performs floating-point operations.
    """
    n = len(xs)
    R = n - 1
    sigma = elem_symmetric_sums(xs)
    loi = leave_one_out_symmetric_sums(xs, sigma)
    Pp  = Pprime_at_layers(xs)
    betas: List[Fraction] = []
    for i in range(n):
        acc = Fraction(0)
        s_i = loi[i]
        for k in range(n):
            sign = -1 if ((R - k) % 2 == 1) else 1
            acc += w[k] * sign * s_i[R - k]
        betas.append(acc / Pp[i])
    return betas

# ---------- Exact β-streams as Fractions ----------

def beta_operator_fractions(fib_count: int, order: int = 1) -> Dict[str, List[Fraction]]:
    """
    Construct all β-stream families (value, derivative, integral, int_primitive)
    as exact Fractions for the given factorial ladder depth and operator order.

    Parameters
    ----------
    fib_count : int
        Number of factorial layers (Fibonacci count - 1).
    order : int, optional
        Operator order. Affects:
            • derivative  → nth derivative
            • integral    → nth integral
        Value and int_primitive remain order-1 objects.

    Returns
    -------
    dict[str, list[Fraction]]
        {"value": [...], "derivative": [...], "integral": [...]}
    """

    fibs = fib_ladder(fib_count)
    xs   = layers_from_fibs(fibs)

    ops: Dict[str, List[Fraction]] = {
        "derivative": beta_from_moment_law(xs, w_derivative(fib_count, order)),
        "integral": beta_from_moment_law(xs, w_integral(fib_count, order))
    }

    return ops


