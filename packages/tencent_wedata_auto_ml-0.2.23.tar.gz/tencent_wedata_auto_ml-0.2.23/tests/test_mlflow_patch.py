"""
测试 MLflow 兼容性补丁

验证补丁是否能够修复 MLflow 2.21.x/2.22.x 的 generate_request_id 导入错误。
"""

import sys
import pytest


def test_mlflow_patch_auto_apply():
    """测试补丁是否自动应用"""
    # 清理已导入的模块
    modules_to_remove = [k for k in sys.modules.keys() if k.startswith("mlflow")]
    for module in modules_to_remove:
        del sys.modules[module]

    # 导入补丁模块（应该自动应用补丁）
    from wedata_automl.utils import mlflow_patch

    # 验证补丁是否注册
    from wedata_automl.utils.mlflow_patch import MLflowPatchFinder

    assert any(isinstance(finder, MLflowPatchFinder) for finder in sys.meta_path), \
        "MLflow 补丁未注册到 sys.meta_path"


def test_generate_request_id_import():
    """测试 generate_request_id 是否可以导入"""
    # 导入补丁
    from wedata_automl.utils import mlflow_patch  # noqa: F401

    # 尝试导入 generate_request_id
    try:
        from mlflow.tracing.utils import generate_request_id

        # 验证函数是否可调用
        request_id = generate_request_id()
        assert isinstance(request_id, str), "generate_request_id 应该返回字符串"
        assert len(request_id) == 32, "request_id 应该是 32 字符的 hex 字符串"

        print(f"✅ generate_request_id 导入成功，生成的 request_id: {request_id}")

    except ImportError as e:
        pytest.fail(f"无法导入 generate_request_id: {e}")


def test_mlflow_import():
    """测试 MLflow 是否可以正常导入"""
    # 导入补丁
    from wedata_automl.utils import mlflow_patch  # noqa: F401

    # 尝试导入 mlflow
    try:
        import mlflow

        print(f"✅ MLflow {mlflow.__version__} 导入成功")

        # 尝试使用 mlflow
        mlflow.set_experiment("test_experiment")
        print("✅ MLflow 功能正常")

    except ImportError as e:
        pytest.fail(f"无法导入 MLflow: {e}")


def test_wedata_automl_import():
    """测试 WeData AutoML SDK 是否可以正常导入"""
    try:
        from wedata_automl.engines.flaml_trainer import FLAMLTrainer

        print("✅ FLAMLTrainer 导入成功")

    except ImportError as e:
        pytest.fail(f"无法导入 FLAMLTrainer: {e}")


if __name__ == "__main__":
    print("=" * 80)
    print("测试 MLflow 兼容性补丁")
    print("=" * 80)

    print("\n测试 1: 补丁自动应用")
    test_mlflow_patch_auto_apply()

    print("\n测试 2: generate_request_id 导入")
    test_generate_request_id_import()

    print("\n测试 3: MLflow 导入")
    test_mlflow_import()

    print("\n测试 4: WeData AutoML SDK 导入")
    test_wedata_automl_import()

    print("\n" + "=" * 80)
    print("✅ 所有测试通过！")
    print("=" * 80)

