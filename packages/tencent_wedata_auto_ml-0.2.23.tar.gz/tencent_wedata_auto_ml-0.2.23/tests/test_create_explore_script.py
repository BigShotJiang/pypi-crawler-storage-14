"""
CreateExploreScript API 测试

测试 CreateExploreScript API 的各种功能
"""
import os
import json
import pytest
from wedata_automl.utils.cloud_sdk_client.client import FeatureCloudSDK
from wedata_automl.utils.cloud_sdk_client import models


@pytest.fixture
def client():
    """创建测试客户端"""
    return FeatureCloudSDK(
        secret_id=os.environ.get("TENCENT_SECRET_ID", "test_secret_id"),
        secret_key=os.environ.get("TENCENT_SECRET_KEY", "test_secret_key"),
        region=os.environ.get("TENCENT_REGION", "ap-guangzhou")
    )


def test_create_simple_sql_script(client):
    """测试创建简单的 SQL 脚本"""
    request = models.CreateExploreScriptRequest()
    request.ScriptName = "test_sql_script"
    request.ExtensionType = "sql"
    request.ScriptContent = "SELECT * FROM test_table LIMIT 10;"
    request.ProjectId = "test_project_id"
    request.AccessScope = "PRIVATE"
    
    # 注意：这个测试需要真实的凭证才能运行
    # 在 CI/CD 环境中，应该使用 mock
    try:
        response = client.CreateExploreScript(request)
        assert response is not None
        if response.Data:
            assert response.Data.ScriptName == "test_sql_script"
            assert response.Data.ExtensionType == "sql"
    except Exception as e:
        # 如果没有真实凭证，跳过测试
        pytest.skip(f"Skipping test due to: {e}")


def test_create_script_with_config(client):
    """测试创建带配置的脚本"""
    # 创建脚本配置
    script_config = models.ExploreScriptConfig()
    script_config.DatasourceId = "test_datasource_id"
    script_config.ComputeResource = "test_compute_resource"
    script_config.ExecutorGroupId = "test_executor_group_id"
    script_config.Params = json.dumps({"param1": "value1"})
    
    # 创建请求
    request = models.CreateExploreScriptRequest()
    request.ScriptName = "test_script_with_config"
    request.ExtensionType = "code_studio"
    request.ScriptContent = "print('Hello, WeData!')"
    request.ProjectId = "test_project_id"
    request.AccessScope = "SHARED"
    request.ScriptConfig = script_config
    
    try:
        response = client.CreateExploreScript(request)
        assert response is not None
        if response.Data:
            assert response.Data.ScriptName == "test_script_with_config"
            assert response.Data.AccessScope == "SHARED"
    except Exception as e:
        pytest.skip(f"Skipping test due to: {e}")


def test_create_script_with_cluster_info(client):
    """测试创建带引擎集群信息的脚本"""
    # 创建引擎集群信息
    cluster_info = models.EngineClusterInfo()
    cluster_info.ClusterId = "test_cluster_id"
    cluster_info.ClusterName = "test_cluster"
    cluster_info.ClusterType = "DLC"
    
    # 创建资源规格信息
    resource_spec = models.ResourceSpecInfo()
    resource_spec.ExecutorSpec = "2CU"
    resource_spec.DriverSpec = "2CU"
    resource_spec.ExecutorNum = "2"
    
    # 创建脚本配置
    script_config = models.ExploreScriptConfig()
    script_config.ClusterInfo = cluster_info
    script_config.ResourceSpecInfo = resource_spec
    
    # 创建请求
    request = models.CreateExploreScriptRequest()
    request.ScriptName = "test_script_with_cluster"
    request.ExtensionType = "sql"
    request.ScriptContent = "SELECT COUNT(*) FROM test_table;"
    request.ProjectId = "test_project_id"
    request.ScriptConfig = script_config
    
    try:
        response = client.CreateExploreScript(request)
        assert response is not None
        if response.Data:
            assert response.Data.ScriptName == "test_script_with_cluster"
    except Exception as e:
        pytest.skip(f"Skipping test due to: {e}")


def test_create_notebook_script(client):
    """测试创建 Notebook 脚本"""
    # 创建 Notebook Session 信息
    session_info = models.NotebookSessionInfo()
    session_info.SessionId = "test_session_id"
    session_info.SessionName = "test_session"
    session_info.KernelName = "python3"
    
    # 创建脚本配置
    script_config = models.ExploreScriptConfig()
    script_config.NotebookSessionInfo = session_info
    
    # 创建 Notebook 内容
    notebook_content = {
        "cells": [{"cell_type": "code", "source": ["print('test')"], "metadata": {}}],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5
    }
    
    # 创建请求
    request = models.CreateExploreScriptRequest()
    request.ScriptName = "test_notebook"
    request.ExtensionType = "ipynb"
    request.ScriptContent = json.dumps(notebook_content)
    request.ProjectId = "test_project_id"
    request.WorkspaceMappingId = "test_workspace_id"
    request.ScriptConfig = script_config
    
    try:
        response = client.CreateExploreScript(request)
        assert response is not None
        if response.Data:
            assert response.Data.ScriptName == "test_notebook"
            assert response.Data.ExtensionType == "ipynb"
    except Exception as e:
        pytest.skip(f"Skipping test due to: {e}")


def test_model_serialization():
    """测试模型序列化"""
    # 测试 ExploreScriptConfig
    config = models.ExploreScriptConfig()
    config.DatasourceId = "test_id"
    config.ComputeResource = "test_resource"
    
    # 测试 EngineClusterInfo
    cluster = models.EngineClusterInfo()
    cluster.ClusterId = "cluster_123"
    cluster.ClusterName = "test_cluster"
    
    # 测试 ResourceSpecInfo
    resource = models.ResourceSpecInfo()
    resource.ExecutorSpec = "2CU"
    resource.DriverSpec = "2CU"
    
    # 测试 NotebookSessionInfo
    session = models.NotebookSessionInfo()
    session.SessionId = "session_123"
    session.KernelName = "python3"
    
    # 验证属性设置成功
    assert config.DatasourceId == "test_id"
    assert cluster.ClusterId == "cluster_123"
    assert resource.ExecutorSpec == "2CU"
    assert session.SessionId == "session_123"


if __name__ == "__main__":
    # 运行测试
    pytest.main([__file__, "-v"])

