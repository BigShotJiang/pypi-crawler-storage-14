"""
简单测试 MLflow 兼容性补丁

只测试补丁本身，不依赖其他模块。
"""

import sys


def test_patch():
    """测试补丁是否有效"""
    print("=" * 80)
    print("测试 MLflow 兼容性补丁")
    print("=" * 80)

    # 清理已导入的 mlflow 模块
    modules_to_remove = [k for k in sys.modules.keys() if k.startswith("mlflow")]
    for module in modules_to_remove:
        del sys.modules[module]
    print(f"\n✅ 清理了 {len(modules_to_remove)} 个 mlflow 模块")

    # 导入补丁模块
    print("\n步骤 1: 导入补丁模块...")
    sys.path.insert(0, "/Users/zhangchunlin/Documents/UGit/wedata/wedata-automl/src")

    from wedata_automl.utils.mlflow_patch import apply_mlflow_patch, MLflowPatchFinder

    # 应用补丁
    print("\n步骤 2: 应用补丁...")
    apply_mlflow_patch()

    # 验证补丁是否注册
    patch_registered = any(isinstance(finder, MLflowPatchFinder) for finder in sys.meta_path)
    print(f"✅ 补丁已注册: {patch_registered}")

    # 尝试导入 mlflow.tracing.utils
    print("\n步骤 3: 导入 mlflow.tracing.utils...")
    try:
        import mlflow.tracing.utils as tracing_utils

        print(f"✅ mlflow.tracing.utils 导入成功")
        print(f"   模块路径: {tracing_utils.__file__}")

        # 检查 generate_request_id 是否存在
        if hasattr(tracing_utils, "generate_request_id"):
            print(f"✅ generate_request_id 存在")

            # 测试函数
            request_id = tracing_utils.generate_request_id()
            print(f"✅ generate_request_id() 返回: {request_id}")
            print(f"   类型: {type(request_id)}")
            print(f"   长度: {len(request_id)}")
        else:
            print(f"❌ generate_request_id 不存在")
            print(f"   可用属性: {dir(tracing_utils)}")

    except ImportError as e:
        print(f"❌ 导入 mlflow.tracing.utils 失败: {e}")
        return False

    # 尝试导入 mlflow
    print("\n步骤 4: 导入 mlflow...")
    try:
        import mlflow

        print(f"✅ mlflow 导入成功")
        print(f"   版本: {mlflow.__version__}")

    except ImportError as e:
        print(f"❌ 导入 mlflow 失败: {e}")
        import traceback

        traceback.print_exc()
        return False

    # 尝试使用 mlflow
    print("\n步骤 5: 测试 mlflow 功能...")
    try:
        mlflow.set_experiment("test_patch_experiment")
        print(f"✅ mlflow.set_experiment() 成功")

    except Exception as e:
        print(f"❌ mlflow.set_experiment() 失败: {e}")
        import traceback

        traceback.print_exc()
        return False

    print("\n" + "=" * 80)
    print("✅ 所有测试通过！补丁工作正常！")
    print("=" * 80)

    return True


if __name__ == "__main__":
    success = test_patch()
    sys.exit(0 if success else 1)

