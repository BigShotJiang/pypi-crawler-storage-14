# Security Policy

## Supported Versions

You should only download the latest version of ao3downloader. Any previous versions are not guaranteed to be free of known vulnerabilities. (Naturally, I cannot guarantee *any* versions to be free of unknown vulnerabilities.)

## Reporting a Vulnerability

If you discover a vulnerability in this project that could compromise other users in any way, please email me directly at nianeyna@gmail.com rather than opening an issue or discussion.
