#!/bin/bash
TANGIBLE_DIR="${HOME}/code/tangibleai/rdrag"
source "${TANGIBLE_DIR}/.env"

sudo cat >/etc/systemd/system/llama.service <<EOF
[Unit]
Description=Run llama.cpp llama-server with OpenAI API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${TANGIBLE_DIR}/llama.cpp/build/bin
ExecStart=${TANGIBLE_DIR}/llama.cpp/build/bin/llama-server --model ${HOME}/.cache/llama.cpp/ggml-org_gemma-3-1b-it-gguf_gemma-3-1b-it-Q4_K_M.gguf
Restart=on-success
RestartSec=7s
StandardOutput=file:${TANGIBLE_DIR}/llama.cpp/llama-server.stdout.log
StandardError=file:${TANGIBLE_DIR}/llama.cpp/llama-server.stderr.log

[Install]
WantedBy=multi-user.target
EOF
