#!/usr/bin/env bash

OLDUSER=$USER
NEWUSER=rdrag
pwhash=$(sudo getent shadow $OLDUSER | cut -d: -f2)


sudo useradd \
    --shell /bin/bash \
    --password "$pwhash" \
    --user-group \
    --create-home \
    --groups adm,cdrom,sudo,dip,plugdev,lpadmin,sambashare \
    $NEWUSER
sudo usermod -r --groups nopasswdlogin $NEWUSER

