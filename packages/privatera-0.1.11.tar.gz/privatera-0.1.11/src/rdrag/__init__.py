from rdrag.util import ask
from rdrag import constants, corpora, util, cli

__all__ = ['constants', 'corpora', 'util', ]


def main() -> None:
    print(cli.ask())
    # util.main()
