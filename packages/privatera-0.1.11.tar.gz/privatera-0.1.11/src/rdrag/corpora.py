import logging
from pathlib import Path
from rdrag.constants import PKG_DIR

log = logging.getLogger(__name__)

WIKITITLES_DIR = PKG_DIR / 'data' / 'wikititles'


def load_title_links():
    """ Create `title: list_of_links` dictionary from txt files in data/wikititles """
    title_links = {}
    for path in WIKITITLES_DIR.glob('*.txt'):
        # biochem = ['Virus', ...]
        title = path.name.split('.')[0]
        title_links[title] = [t.strip() for t in open(path)]
        log.info(f'Found {title}: {len(title_links[title])} in {path}')
    return title_links


def find_related_wikititles(
        titles: list[str] = 'Africa,Etheopia,Orinoko,Somalia,Nairobi,Kenya,South Africa,East Africa'.split(','),
        refresh: bool = True):
    """ Walk the tree of wikititles to retrieve additional links updating local wikititles txt files """
    if not titles:
        return {}
    log.warning(f"Finding links related to {len(titles)} articles: ['{titles[0]}', ...]")
    titles = {t: None for t in titles}
    for t in titles:
        titles[t] = []
        path = (WIKITITLES_DIR / make_wiki_title(t).replace(' ', '_')).with_suffix('.txt')
        prev_num_links = 0
        try:
            with open(path, 'r') as fin:
                titles[t].extend([line.strip() for line in fin])
            prev_num_links = len(titles[t])
            log.info(f'Found {prev_num_links} previously scraped links in {path}')
            continue
        except IOError as exc:
            log.warning(f'Links for wiki/{t} will be requested from Wikipedia')

        try:
            p = wiki.get_page(t)
            log.warning(f'loaded wikipedia page titled "{t}"')
        except Exception as exc:
            log.error(str(exc))
            continue
        log.warning(f'Found {len(p.links)} links for {t}')
        titles[t] = [lnk + '\n' for lnk in set(list(titles[t]) + list(p.links))]
        log.warning(f'Found {len(titles[t]) - prev_num_links} new links.')
        if len(titles[t]) == prev_num_links:
            continue
        with open(path, 'w') as fout:
            fout.writelines(titles[t])
        log.info(f'Saved {len(titles[t])} links from page "{t}" to {path}')
    return titles
