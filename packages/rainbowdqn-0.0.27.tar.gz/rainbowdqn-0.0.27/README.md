# rainbowrl
An easy, drop-in implementation of Rainbow DQN agent.
