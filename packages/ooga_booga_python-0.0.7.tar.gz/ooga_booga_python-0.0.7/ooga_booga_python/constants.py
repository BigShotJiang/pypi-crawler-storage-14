BASE_URL = "https://mainnet.api.oogabooga.io/v1"
CHAIN_ID = 80094