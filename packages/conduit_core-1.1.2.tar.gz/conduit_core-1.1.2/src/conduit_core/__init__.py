"""Conduit Core - Declarative Data Ingestion Framework."""

__version__ = "1.1.2"