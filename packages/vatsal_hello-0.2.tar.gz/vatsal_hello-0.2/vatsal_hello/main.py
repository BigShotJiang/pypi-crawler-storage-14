def hello():
    print('Vatsal says hello!')