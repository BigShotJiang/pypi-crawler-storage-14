# Example config files and imaging datasets

This directory contains a subdirectory of `.toml` config files that pair with the subdirectories of `imaging_datasets`.  Within each of the `imaging_datasets` subdirectories is also a `legacy_code` directory containing the `image_settings.txt` config file and output from running of the [legacy code](../legacy)  

For convenience, these examples are detailed here:

## NOVO imaging of a 14.8 MeV DT neutron source at PTB (ROOT DDAQ data format)

- Config file: [configs/novo_ptb.toml](configs/novo_ptb.toml)
- Dataset dir: [imaging_datasets/NOVO_experiment_DT_at_PTB](imaging_datasets/NOVO_experiment_DT_at_PTB)

## PHITS imaging of a neutron line source


