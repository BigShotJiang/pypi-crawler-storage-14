"""final unified ctl merge

Revision ID: fb6b0150d6e4
Revises: 3d9c476d7cea, 6b287ff8cde4
Create Date: 2022-10-06 14:56:13.267477

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "fb6b0150d6e4"
down_revision = ("3d9c476d7cea", "6b287ff8cde4")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
