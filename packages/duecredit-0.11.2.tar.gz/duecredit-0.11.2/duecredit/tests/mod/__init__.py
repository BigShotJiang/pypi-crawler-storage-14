"""Module to test various duecredit functionality, e.g. injections"""

from .imported import *  # noqa: F403

__version__ = "0.5"
