"""
Tests for provider fallback system.
"""

import time

import pytest

from erosolar_cli.core.provider_fallback import (
    ProviderConfig,
    ProviderFallbackManager,
    ProviderHealth,
    ProviderMetrics,
)


class TestProviderMetrics:
    """Test provider metrics tracking."""

    def test_initial_metrics(self):
        """Test initial metrics state."""
        metrics = ProviderMetrics(provider_name="test")

        assert metrics.success_rate() == 1.0
        assert metrics.health_status == ProviderHealth.HEALTHY
        assert metrics.is_available() is True

    def test_success_tracking(self):
        """Test tracking of successful requests."""
        metrics = ProviderMetrics(provider_name="test")

        metrics.update_success(100.0)
        metrics.update_success(150.0)

        assert metrics.total_requests == 2
        assert metrics.successful_requests == 2
        assert metrics.success_rate() == 1.0
        assert metrics.avg_response_time_ms == 125.0
        assert metrics.health_status == ProviderHealth.HEALTHY

    def test_failure_tracking(self):
        """Test tracking of failed requests."""
        metrics = ProviderMetrics(provider_name="test")

        metrics.update_failure()
        metrics.update_failure()

        assert metrics.total_requests == 2
        assert metrics.failed_requests == 2
        assert metrics.success_rate() == 0.0
        assert metrics.consecutive_failures == 2

    def test_health_status_degradation(self):
        """Test health status changes with failures."""
        metrics = ProviderMetrics(provider_name="test")

        # Initially healthy
        assert metrics.health_status == ProviderHealth.HEALTHY

        # 1 success, 1 failure = still healthy (100% -> 50%)
        metrics.update_success(100.0)
        metrics.update_failure()
        assert metrics.success_rate() == 0.5
        # Degraded because < 0.7
        assert metrics.health_status == ProviderHealth.DEGRADED

        # 3 consecutive failures = unavailable
        metrics.update_failure()
        metrics.update_failure()
        metrics.update_failure()
        assert metrics.consecutive_failures >= 3
        assert metrics.health_status == ProviderHealth.UNAVAILABLE

    def test_unavailable_with_cooldown(self):
        """Test cooldown period for unavailable providers."""
        metrics = ProviderMetrics(provider_name="test")

        # Make it unavailable
        metrics.update_failure()
        metrics.update_failure()
        metrics.update_failure()
        assert metrics.health_status == ProviderHealth.UNAVAILABLE
        assert metrics.is_available() is False

        # Manually set last_failure_time to past (simulate cooldown)
        metrics.last_failure_time = time.time() - 400  # 400 seconds ago (> 5 min)
        assert metrics.is_available() is True  # Should be available after cooldown

    def test_recovery_after_failure(self):
        """Test that provider recovers after failures."""
        metrics = ProviderMetrics(provider_name="test")

        # Fail a few times
        metrics.update_failure()
        metrics.update_failure()
        assert metrics.health_status == ProviderHealth.DEGRADED

        # Then succeed
        metrics.update_success(100.0)
        assert metrics.consecutive_failures == 0  # Reset


class TestProviderFallbackManager:
    """Test provider fallback manager."""

    def test_initialization(self):
        """Test manager initialization with default configs."""
        manager = ProviderFallbackManager()

        assert "anthropic" in manager.configs
        assert "openai" in manager.configs
        assert "google" in manager.configs
        assert len(manager.metrics) > 0

    def test_provider_registration(self):
        """Test registering custom provider."""
        manager = ProviderFallbackManager()

        config = ProviderConfig(
            name="custom_provider",
            priority=10,
            capabilities={"streaming"},
            supported_models=["model-1"],
        )
        manager.register_provider(config)

        assert "custom_provider" in manager.configs
        assert "custom_provider" in manager.metrics

    def test_get_best_provider_healthy(self):
        """Test getting best provider when all are healthy."""
        manager = ProviderFallbackManager()

        # All healthy, should return highest priority (lowest number)
        best = manager.get_best_provider()
        assert best == "anthropic"  # Priority 1

    def test_get_best_provider_with_failures(self):
        """Test getting best provider when some have failed."""
        manager = ProviderFallbackManager()

        # Make anthropic unavailable
        for _ in range(3):
            manager.record_failure("anthropic")

        best = manager.get_best_provider()
        assert best != "anthropic"
        assert best in ["openai", "google", "deepseek"]

    def test_get_best_provider_with_capabilities(self):
        """Test getting provider with required capabilities."""
        manager = ProviderFallbackManager()

        # Request provider with specific capabilities
        best = manager.get_best_provider(required_capabilities={"vision", "streaming"})

        config = manager.configs.get(best)
        assert config is not None
        assert "vision" in config.capabilities
        assert "streaming" in config.capabilities

    def test_get_best_provider_with_exclusions(self):
        """Test getting provider with exclusions."""
        manager = ProviderFallbackManager()

        best = manager.get_best_provider(exclude_providers={"anthropic", "openai"})

        assert best not in ["anthropic", "openai"]
        assert best in ["google", "deepseek"]

    def test_get_fallback_providers(self):
        """Test getting list of fallback providers."""
        manager = ProviderFallbackManager()

        fallbacks = manager.get_fallback_providers("anthropic", max_count=2)

        assert len(fallbacks) <= 2
        assert "anthropic" not in fallbacks  # Excluded current
        assert all(p in manager.configs for p in fallbacks)

    def test_record_success_and_failure(self):
        """Test recording successes and failures."""
        manager = ProviderFallbackManager()

        # Record success
        manager.record_success("openai", 150.0)
        metrics = manager.metrics["openai"]
        assert metrics.successful_requests == 1

        # Record failure
        manager.record_failure("openai")
        assert metrics.failed_requests == 1

    def test_provider_status(self):
        """Test getting provider status."""
        manager = ProviderFallbackManager()

        # Record some activity
        manager.record_success("anthropic", 100.0)
        manager.record_failure("openai")

        status = manager.get_provider_status()

        assert "anthropic" in status
        assert "openai" in status
        assert status["anthropic"]["success_rate"] == 1.0
        assert status["openai"]["success_rate"] < 1.0

    def test_reset_provider(self):
        """Test resetting provider metrics."""
        manager = ProviderFallbackManager()

        # Make provider fail
        manager.record_failure("anthropic")
        manager.record_failure("anthropic")
        assert manager.metrics["anthropic"].failed_requests == 2

        # Reset
        manager.reset_provider("anthropic")
        assert manager.metrics["anthropic"].failed_requests == 0
        assert manager.metrics["anthropic"].health_status == ProviderHealth.HEALTHY

    def test_provider_priority_ordering(self):
        """Test that providers are selected by priority."""
        manager = ProviderFallbackManager()

        # All healthy, should get in priority order
        best = manager.get_best_provider()
        assert best == "anthropic"  # Priority 1

        # Exclude anthropic, should get openai
        best = manager.get_best_provider(exclude_providers={"anthropic"})
        assert best == "openai"  # Priority 2

        # Exclude anthropic and openai, should get google
        best = manager.get_best_provider(exclude_providers={"anthropic", "openai"})
        assert best == "google"  # Priority 3


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
