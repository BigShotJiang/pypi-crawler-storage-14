"""
Metrics Dashboard for Alpha Zero 2

Provides visualization and reporting of tournament metrics,
agent performance trends, and code quality evolution.
"""

from __future__ import annotations

import json
import statistics
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
from datetime import datetime


@dataclass
class AgentMetrics:
    """Aggregated metrics for an agent."""

    agent_id: str
    total_rounds: int = 0
    wins: int = 0
    losses: int = 0
    ties: int = 0
    total_score: float = 0.0
    scores: list[float] = field(default_factory=list)

    @property
    def win_rate(self) -> float:
        return self.wins / self.total_rounds if self.total_rounds > 0 else 0.0

    @property
    def avg_score(self) -> float:
        return self.total_score / self.total_rounds if self.total_rounds > 0 else 0.0

    @property
    def score_std(self) -> float:
        return statistics.stdev(self.scores) if len(self.scores) > 1 else 0.0

    @property
    def best_score(self) -> float:
        return max(self.scores) if self.scores else 0.0

    @property
    def worst_score(self) -> float:
        return min(self.scores) if self.scores else 0.0


@dataclass
class TournamentMetrics:
    """Metrics for a tournament."""

    name: str
    timestamp: float
    total_rounds: int
    agent1_metrics: AgentMetrics
    agent2_metrics: AgentMetrics
    total_duration_ms: float
    avg_round_duration_ms: float


class MetricsDashboard:
    """
    Dashboard for Alpha Zero 2 metrics.

    Provides:
    - Tournament statistics and comparisons
    - Agent performance trends
    - Code quality evolution tracking
    - Rich text reports
    """

    def __init__(self, data_dir: Optional[Path] = None):
        """
        Initialize metrics dashboard.

        Args:
            data_dir: Directory containing tournament data
        """
        self.data_dir = data_dir or Path(".alpha_zero_tournaments")
        self._tournaments: list[dict[str, Any]] = []
        self._load_tournaments()

    def _load_tournaments(self) -> None:
        """Load all tournament data."""
        if not self.data_dir.exists():
            return

        for file in self.data_dir.glob("*.json"):
            if file.name in ("latest_tournament.json",):
                continue
            if "_intermediate" in file.name:
                continue

            try:
                with open(file) as f:
                    data = json.load(f)
                    self._tournaments.append(data)
            except Exception:
                pass

        # Sort by timestamp (newest first)
        self._tournaments.sort(
            key=lambda x: x.get("rounds", [{}])[0].get("timestamp", 0) if x.get("rounds") else 0,
            reverse=True,
        )

    def get_overall_stats(self) -> dict[str, Any]:
        """
        Get overall statistics across all tournaments.

        Returns:
            Dictionary with overall statistics
        """
        if not self._tournaments:
            return {
                "total_tournaments": 0,
                "total_rounds": 0,
                "message": "No tournament data available",
            }

        total_rounds = sum(t.get("total_rounds", 0) for t in self._tournaments)
        total_agent1_wins = sum(t.get("agent1_wins", 0) for t in self._tournaments)
        total_agent2_wins = sum(t.get("agent2_wins", 0) for t in self._tournaments)
        total_ties = sum(t.get("ties", 0) for t in self._tournaments)

        all_durations = [
            t.get("total_duration_ms", 0)
            for t in self._tournaments
            if t.get("total_duration_ms", 0) > 0
        ]

        return {
            "total_tournaments": len(self._tournaments),
            "total_rounds": total_rounds,
            "agent1_total_wins": total_agent1_wins,
            "agent2_total_wins": total_agent2_wins,
            "total_ties": total_ties,
            "agent1_overall_win_rate": total_agent1_wins / total_rounds if total_rounds > 0 else 0.0,
            "agent2_overall_win_rate": total_agent2_wins / total_rounds if total_rounds > 0 else 0.0,
            "avg_tournament_duration_ms": statistics.mean(all_durations) if all_durations else 0.0,
        }

    def get_tournament_comparison(self) -> list[dict[str, Any]]:
        """
        Compare all tournaments.

        Returns:
            List of tournament summaries for comparison
        """
        comparisons = []

        for t in self._tournaments:
            config = t.get("config", {})
            rounds = t.get("rounds", [])

            # Calculate score statistics
            agent1_scores = [r.get("agent1_score", 0) for r in rounds]
            agent2_scores = [r.get("agent2_score", 0) for r in rounds]

            comparisons.append({
                "name": config.get("name", "Unknown"),
                "num_rounds": t.get("total_rounds", 0),
                "agent1_wins": t.get("agent1_wins", 0),
                "agent2_wins": t.get("agent2_wins", 0),
                "ties": t.get("ties", 0),
                "agent1_avg_score": statistics.mean(agent1_scores) if agent1_scores else 0.0,
                "agent2_avg_score": statistics.mean(agent2_scores) if agent2_scores else 0.0,
                "duration_ms": t.get("total_duration_ms", 0),
                "status": t.get("status", "unknown"),
            })

        return comparisons

    def get_performance_trend(self, window_size: int = 5) -> dict[str, Any]:
        """
        Analyze performance trends across tournaments.

        Args:
            window_size: Number of tournaments to include in trend

        Returns:
            Performance trend data
        """
        recent = self._tournaments[:window_size]

        if not recent:
            return {"has_data": False}

        agent1_win_rates = [t.get("agent1_win_rate", 0) for t in recent]
        agent2_win_rates = [t.get("agent2_win_rate", 0) for t in recent]

        # Calculate trend direction
        def trend_direction(values: list[float]) -> str:
            if len(values) < 2:
                return "stable"
            first_half = statistics.mean(values[: len(values) // 2])
            second_half = statistics.mean(values[len(values) // 2:])
            diff = second_half - first_half
            if diff > 0.05:
                return "improving"
            elif diff < -0.05:
                return "declining"
            return "stable"

        return {
            "has_data": True,
            "window_size": len(recent),
            "agent1_trend": trend_direction(agent1_win_rates),
            "agent2_trend": trend_direction(agent2_win_rates),
            "agent1_win_rates": agent1_win_rates,
            "agent2_win_rates": agent2_win_rates,
            "agent1_avg_win_rate": statistics.mean(agent1_win_rates),
            "agent2_avg_win_rate": statistics.mean(agent2_win_rates),
        }

    def generate_report(self, format: str = "text") -> str:
        """
        Generate a comprehensive metrics report.

        Args:
            format: Output format ("text" or "markdown")

        Returns:
            Formatted report string
        """
        stats = self.get_overall_stats()
        comparisons = self.get_tournament_comparison()
        trends = self.get_performance_trend()

        if format == "markdown":
            return self._generate_markdown_report(stats, comparisons, trends)
        return self._generate_text_report(stats, comparisons, trends)

    def _generate_text_report(
        self,
        stats: dict[str, Any],
        comparisons: list[dict[str, Any]],
        trends: dict[str, Any],
    ) -> str:
        """Generate plain text report."""
        lines = [
            "=" * 60,
            "ALPHA ZERO 2 METRICS DASHBOARD",
            "=" * 60,
            "",
            "OVERALL STATISTICS",
            "-" * 40,
            f"Total Tournaments: {stats.get('total_tournaments', 0)}",
            f"Total Rounds: {stats.get('total_rounds', 0)}",
            "",
            f"Agent 1 Overall Win Rate: {stats.get('agent1_overall_win_rate', 0):.1%}",
            f"Agent 2 Overall Win Rate: {stats.get('agent2_overall_win_rate', 0):.1%}",
            "",
        ]

        if trends.get("has_data"):
            lines.extend([
                "PERFORMANCE TRENDS",
                "-" * 40,
                f"Agent 1 Trend: {trends.get('agent1_trend', 'N/A')}",
                f"Agent 2 Trend: {trends.get('agent2_trend', 'N/A')}",
                "",
            ])

        if comparisons:
            lines.extend([
                "TOURNAMENT HISTORY",
                "-" * 40,
            ])
            for c in comparisons[:10]:  # Show last 10
                winner = "Agent 1" if c["agent1_wins"] > c["agent2_wins"] else "Agent 2" if c["agent2_wins"] > c["agent1_wins"] else "Tie"
                lines.append(
                    f"  {c['name']}: {c['num_rounds']} rounds, "
                    f"A1={c['agent1_wins']} A2={c['agent2_wins']} -> {winner}"
                )
            lines.append("")

        return "\n".join(lines)

    def _generate_markdown_report(
        self,
        stats: dict[str, Any],
        comparisons: list[dict[str, Any]],
        trends: dict[str, Any],
    ) -> str:
        """Generate markdown report."""
        lines = [
            "# Alpha Zero 2 Metrics Dashboard",
            "",
            "## Overall Statistics",
            "",
            f"- **Total Tournaments**: {stats.get('total_tournaments', 0)}",
            f"- **Total Rounds**: {stats.get('total_rounds', 0)}",
            f"- **Agent 1 Win Rate**: {stats.get('agent1_overall_win_rate', 0):.1%}",
            f"- **Agent 2 Win Rate**: {stats.get('agent2_overall_win_rate', 0):.1%}",
            "",
        ]

        if trends.get("has_data"):
            lines.extend([
                "## Performance Trends",
                "",
                f"| Agent | Trend | Avg Win Rate |",
                f"|-------|-------|--------------|",
                f"| Agent 1 | {trends.get('agent1_trend', 'N/A')} | {trends.get('agent1_avg_win_rate', 0):.1%} |",
                f"| Agent 2 | {trends.get('agent2_trend', 'N/A')} | {trends.get('agent2_avg_win_rate', 0):.1%} |",
                "",
            ])

        if comparisons:
            lines.extend([
                "## Tournament History",
                "",
                "| Tournament | Rounds | A1 Wins | A2 Wins | A1 Avg | A2 Avg |",
                "|------------|--------|---------|---------|--------|--------|",
            ])
            for c in comparisons[:10]:
                lines.append(
                    f"| {c['name']} | {c['num_rounds']} | {c['agent1_wins']} | "
                    f"{c['agent2_wins']} | {c['agent1_avg_score']:.1f} | {c['agent2_avg_score']:.1f} |"
                )
            lines.append("")

        return "\n".join(lines)

    def export_data(self, output_path: Path) -> None:
        """
        Export all metrics data to JSON.

        Args:
            output_path: Path to write the export
        """
        export = {
            "exported_at": datetime.now().isoformat(),
            "overall_stats": self.get_overall_stats(),
            "tournament_comparisons": self.get_tournament_comparison(),
            "performance_trends": self.get_performance_trend(),
            "raw_tournaments": self._tournaments,
        }

        with open(output_path, "w") as f:
            json.dump(export, f, indent=2)


@dataclass
class CodeEvolutionMetrics:
    """Track code quality evolution over time."""

    version: str
    timestamp: float
    code_quality_score: float
    algorithm_efficiency: float
    error_handling_score: float
    syntax_validity: float
    documentation_quality: float


class CodeEvolutionTracker:
    """
    Track evolution of code quality through self-modification cycles.

    Records how agent-generated code improves over tournament iterations.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        """
        Initialize evolution tracker.

        Args:
            data_dir: Directory for storing evolution data
        """
        self.data_dir = data_dir or Path(".alpha_zero_evolution")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.metrics_history: list[CodeEvolutionMetrics] = []
        self._load_history()

    def record_metrics(
        self,
        version: str,
        code_quality_score: float,
        algorithm_efficiency: float,
        error_handling_score: float,
        syntax_validity: float,
        documentation_quality: float,
    ) -> None:
        """Record new code quality metrics."""
        metrics = CodeEvolutionMetrics(
            version=version,
            timestamp=datetime.now().timestamp(),
            code_quality_score=code_quality_score,
            algorithm_efficiency=algorithm_efficiency,
            error_handling_score=error_handling_score,
            syntax_validity=syntax_validity,
            documentation_quality=documentation_quality,
        )
        self.metrics_history.append(metrics)
        self._save_history()

    def get_evolution_summary(self) -> dict[str, Any]:
        """Get summary of code evolution."""
        if not self.metrics_history:
            return {"has_data": False}

        first = self.metrics_history[0]
        last = self.metrics_history[-1]

        return {
            "has_data": True,
            "total_versions": len(self.metrics_history),
            "initial_quality": first.code_quality_score,
            "current_quality": last.code_quality_score,
            "quality_improvement": last.code_quality_score - first.code_quality_score,
            "quality_improvement_pct": (
                (last.code_quality_score - first.code_quality_score) / first.code_quality_score * 100
                if first.code_quality_score > 0 else 0
            ),
            "efficiency_improvement": last.algorithm_efficiency - first.algorithm_efficiency,
            "error_handling_improvement": last.error_handling_score - first.error_handling_score,
        }

    def _save_history(self) -> None:
        """Save metrics history to disk."""
        history_file = self.data_dir / "evolution_history.json"
        data = [
            {
                "version": m.version,
                "timestamp": m.timestamp,
                "code_quality_score": m.code_quality_score,
                "algorithm_efficiency": m.algorithm_efficiency,
                "error_handling_score": m.error_handling_score,
                "syntax_validity": m.syntax_validity,
                "documentation_quality": m.documentation_quality,
            }
            for m in self.metrics_history
        ]
        with open(history_file, "w") as f:
            json.dump(data, f, indent=2)

    def _load_history(self) -> None:
        """Load metrics history from disk."""
        history_file = self.data_dir / "evolution_history.json"
        if not history_file.exists():
            return

        try:
            with open(history_file) as f:
                data = json.load(f)

            self.metrics_history = [
                CodeEvolutionMetrics(
                    version=m["version"],
                    timestamp=m["timestamp"],
                    code_quality_score=m["code_quality_score"],
                    algorithm_efficiency=m["algorithm_efficiency"],
                    error_handling_score=m["error_handling_score"],
                    syntax_validity=m["syntax_validity"],
                    documentation_quality=m["documentation_quality"],
                )
                for m in data
            ]
        except Exception:
            pass
