from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Annotated, List, TypedDict
from uuid import uuid4

from langchain_anthropic import ChatAnthropic
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph
from langgraph.graph.message import AnyMessage, add_messages
from langgraph.prebuilt import ToolNode
from openai import OpenAI


@dataclass(frozen=True)
class ModelConfig:
  provider: str
  model: str
  temperature: float | None = None
  max_tokens: int | None = None


class ConversationState(TypedDict, total=False):
  messages: Annotated[List[AnyMessage], add_messages]
  initialized: bool
  usage: dict | None


def create_app(
  model_config: ModelConfig,
  system_prompt: str,
  tools: list | None = None,
  checkpointer: MemorySaver | None = None,
):
  llm = _build_model(model_config, tools=tools)
  tool_node = ToolNode(tools or [])
  graph = StateGraph(ConversationState)

  def bootstrap(state: ConversationState) -> ConversationState:
    if state.get("initialized"):
      return {}
    existing = state.get("messages") or []
    return {"messages": [SystemMessage(content=system_prompt), *existing], "initialized": True}

  def run_model(state: ConversationState) -> ConversationState:
    response = llm.invoke(state["messages"])
    usage = {}
    metadata = getattr(response, "usage_metadata", None)
    if metadata:
      usage = dict(metadata)
    elif hasattr(response, "response_metadata"):
      token_usage = response.response_metadata.get("token_usage") or {}
      if token_usage:
        usage = dict(token_usage)
    return {"messages": [response], "usage": usage}

  def route_tools(state: ConversationState) -> str:
    last = state["messages"][-1] if state.get("messages") else None
    if isinstance(last, AIMessage) and getattr(last, "tool_calls", None):
      return "tools"
    return "end"

  graph.add_node("bootstrap", bootstrap)
  graph.add_node("model", run_model)
  graph.add_node("tools", tool_node)

  graph.set_entry_point("bootstrap")
  graph.add_edge("bootstrap", "model")
  graph.add_conditional_edges("model", route_tools, {"tools": "tools", "end": END})
  graph.add_edge("tools", "model")

  return graph.compile(checkpointer=checkpointer or MemorySaver())


def build_initial_state(
  user_prompt: str,
  previous_messages: list[AnyMessage] | None = None,
  initialized: bool = False,
) -> ConversationState:
  messages: list[AnyMessage] = previous_messages[:] if previous_messages else []
  messages.append(HumanMessage(content=user_prompt))
  return {"messages": messages, "initialized": initialized, "usage": None}


def _build_model(config: ModelConfig, tools: list | None = None):
  provider = config.provider.lower()
  common_kwargs = {
    "model": config.model,
  }
  if config.temperature is not None:
    common_kwargs["temperature"] = config.temperature
  if config.max_tokens is not None:
    common_kwargs["max_tokens"] = config.max_tokens

  if provider == "openai":
    return _OpenAIResponsesModel(common_kwargs["model"], tools or [])
  if provider == "anthropic":
    return ChatAnthropic(**common_kwargs).bind_tools(tools or [])

  raise ValueError(
    f"Provider '{config.provider}' is not wired up in the Python CLI yet. Add it in langgraph_app.py."
  )


def _convert_messages_to_openai(messages: list[AnyMessage]) -> list[dict]:
  payload: list[dict] = []
  for message in messages:
    if isinstance(message, HumanMessage):
      payload.append({"role": "user", "content": [{"type": "input_text", "text": str(message.content)}]})
    elif isinstance(message, SystemMessage):
      payload.append({"role": "system", "content": [{"type": "input_text", "text": str(message.content)}]})
    elif isinstance(message, ToolMessage):
      payload.append(
        {
          "role": "tool",
          "content": [{"type": "input_text", "text": str(message.content)}],
          "name": getattr(message, "name", None),
          "tool_call_id": getattr(message, "tool_call_id", None),
        }
      )
    elif isinstance(message, AIMessage):
      # Preserve assistant content but strip tool calls since they should be resolved before next send
      payload.append({"role": "assistant", "content": [{"type": "output_text", "text": str(message.content)}]})
    else:
      payload.append({"role": "user", "content": [{"type": "input_text", "text": str(message.content)}]})
  return payload


def _convert_tool(tool) -> dict:
  schema = {}
  if getattr(tool, "args_schema", None):
    try:
      schema = tool.args_schema.schema()
    except Exception:
      schema = {}
  params = schema or {"type": "object", "properties": {}}
  return {
    "type": "function",
    "name": tool.name,
    "description": tool.description or "",
    "parameters": params,
  }


class _OpenAIResponsesModel:
  def __init__(self, model: str, tools: list):
    self.model = model
    self.tools = tools or []
    self.client = OpenAI()

  def invoke(self, messages: list[AnyMessage]) -> AIMessage:
    payload_messages = _convert_messages_to_openai(messages)
    tool_defs = [_convert_tool(tool) for tool in self.tools] if self.tools else None

    response = self.client.responses.create(
      model=self.model,
      input=payload_messages,
      tools=tool_defs,
      stream=False,
    )

    text_chunks: list[str] = []
    tool_calls: list[dict] = []

    for block in getattr(response, "output", []) or []:
      for content in getattr(block, "content", []) or []:
        ctype = getattr(content, "type", None)
        if ctype in ("output_text", "text"):
          text_value = getattr(content, "text", None) or getattr(content, "value", "")
          if isinstance(text_value, str):
            text_chunks.append(text_value)
        elif ctype in ("tool_call", "output_tool_call"):
          tc = getattr(content, "tool_call", None) or getattr(content, "function_call", None)
          if tc:
            args = tc.arguments if isinstance(tc.arguments, str) else json.dumps(tc.arguments or {})
            tool_calls.append({"name": tc.name, "args": args, "id": getattr(tc, "id", None) or str(uuid4())})

    message = AIMessage(content="\n".join(text_chunks) if text_chunks else "")
    if tool_calls:
      message.tool_calls = tool_calls

    usage = getattr(response, "usage", None)
    if usage:
      cleaned = _clean_usage(usage)
      if cleaned:
        message.usage_metadata = cleaned
    return message


def _clean_usage(raw_usage: Any) -> dict | None:
  try:
    payload = dict(raw_usage)
  except Exception:
    return None
  cleaned: dict[str, int] = {}
  for key in ("input_tokens", "output_tokens", "total_tokens"):
    value = payload.get(key)
    if isinstance(value, (int, float)):
      cleaned[key] = int(value)
  return cleaned or None
