"""
Unified Core Module

Single entry point for all unified core functionality.
Provides a consistent API mirroring the TypeScript implementation.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from .types import (
    # Conversation
    ConversationRole,
    ConversationMessage,

    # Tools
    ToolCallRequest,
    ToolCallResult,
    ToolDefinition,
    ToolSuite,
    ToolRecord,

    # JSON Schema
    JSONSchemaType,
    JSONSchemaProperty,
    JSONSchemaObject,

    # Provider
    ProviderId,
    ProviderCapability,
    ProviderConfig,
    RateLimitConfig,
    ProviderToolDefinition,
    ProviderUsage,
    ProviderResponse,
    StreamChunk,

    # Task
    TaskTypeId,
    TaskTypeConfig,

    # Error
    ErrorSeverity,
    ErrorCategory,
    ErrorSuggestion,
    StructuredErrorData,

    # Version
    SemanticVersion,
    VersionBump,
    VersionConstraint,

    # Plugin
    PluginCategory,
    PluginState,
    PluginMetadata,
    PluginConfig,

    # Context
    ContextManagerConfig,
    TruncationResult,

    # Agent
    AgentConfig,
    AgentSession,

    # Alpha Zero
    CodeQualityMetrics,
    AgentPerformanceMetrics,
    TournamentConfig,
    CompetitionRoundResult,
    TournamentResult,

    # Security
    AuthorizationScope,
    AuthorizationRecord,
    VulnerabilityFinding,

    # Schema
    ToolCategoryConfig,
    SchemaToolDefinition,
    UnifiedSchema,
)

from .version import (
    # Parsing and formatting
    parse_version,
    format_version,

    # Comparison
    compare_versions,
    version_lt,
    version_lte,
    version_gt,
    version_gte,
    version_eq,

    # Bumping
    bump_version,

    # Constraints
    parse_constraint,
    satisfies_constraint,
    satisfies_all_constraints,
    satisfies,

    # Classes
    VersionManager,
    PluginDependencyResolver,
    SelfUpgradeManager,

    # Types
    VersionRecord,
    VersionManagerConfig,
    PluginDependency,
    ResolvedDependency,
    DependencyConflict,
    UpgradeResult,
    SelfUpgradeConfig,

    # Factory
    create_version_manager,
    is_compatible,
)

from .schema import (
    # Loading
    load_unified_schema,
    clear_schema_cache,

    # Provider lookups
    get_provider_config,
    get_all_providers,
    get_providers_with_capabilities,
    get_recommended_providers,

    # Task type lookups
    get_task_type_config,
    get_all_task_types,
    infer_task_type,

    # Tool lookups
    get_tool_definition,
    get_tools_by_category,
    get_tool_category,
    get_enabled_tools,
    tool_requires_auth,

    # Validation
    validate_tool_arguments,
    ToolArgumentValidationError,

    # Utilities
    get_schema_defaults,
    get_schema_metadata,
    get_schema_version,
    provider_supports_capability,
    select_best_provider,
)

from .errors import (
    # Base class
    StructuredError,

    # Specific errors
    DangerousOperationError,
    BlockedOperationError,
    ValidationError,
    ResourceLimitError,
    ContextOverflowError,
    ProviderError,
    ToolExecutionError,
    NetworkError,

    # Recovery
    ErrorRecoveryManager,
    RecoveryStrategy,
    RecoveryAttempt,

    # Utilities
    is_structured_error,
    wrap_error,
    create_error_recovery_manager,
)

from .tool_runtime import (
    # Runtime
    ToolRuntime,
    ToolRuntimeConfig,
    ToolRuntimeObserver,
    CacheEntry,
    CACHEABLE_TOOLS,

    # Factory
    create_tool_runtime,
    create_tool_suite,
)

from .tools import (
    # Core tools
    create_read_tool,
    create_write_tool,
    create_edit_tool,
    create_bash_tool,
    create_glob_tool,
    create_grep_tool,

    # Web tools
    create_web_search_tool,
    create_web_fetch_tool,

    # Coding tools
    create_analyze_complexity_tool,
    create_find_dependencies_tool,
    create_generate_docstring_tool,
    create_suggest_refactorings_tool,
    create_generate_test_stub_tool,

    # Security tools
    create_dependency_audit_tool,
    create_code_security_scan_tool,
    create_analyze_attack_surface_tool,

    # Alpha Zero tools
    create_alpha_zero_evaluate_tool,
    create_alpha_zero_tournament_tool,
    create_alpha_zero_introspect_tool,
    create_alpha_zero_history_tool,
    create_alpha_zero_metrics_tool,

    # Suite factories
    create_unified_tool_suite,
    create_core_tool_suite,
    create_web_tool_suite,
    create_coding_tool_suite,
    create_security_tool_suite,
    create_alpha_zero_tool_suite,
)

# Module metadata
UNIFIED_CORE_VERSION = "1.0.0"
UNIFIED_CORE_AUTHOR = "Bo Shang"
UNIFIED_CORE_FRAMEWORK = "erosolar-cli"

__all__ = [
    # Types
    "ConversationRole",
    "ConversationMessage",
    "ToolCallRequest",
    "ToolCallResult",
    "ToolDefinition",
    "ToolSuite",
    "ToolRecord",
    "JSONSchemaType",
    "JSONSchemaProperty",
    "JSONSchemaObject",
    "ProviderId",
    "ProviderCapability",
    "ProviderConfig",
    "RateLimitConfig",
    "ProviderToolDefinition",
    "ProviderUsage",
    "ProviderResponse",
    "StreamChunk",
    "TaskTypeId",
    "TaskTypeConfig",
    "ErrorSeverity",
    "ErrorCategory",
    "ErrorSuggestion",
    "StructuredErrorData",
    "SemanticVersion",
    "VersionBump",
    "VersionConstraint",
    "PluginCategory",
    "PluginState",
    "PluginMetadata",
    "PluginConfig",
    "ContextManagerConfig",
    "TruncationResult",
    "AgentConfig",
    "AgentSession",
    "CodeQualityMetrics",
    "AgentPerformanceMetrics",
    "TournamentConfig",
    "CompetitionRoundResult",
    "TournamentResult",
    "AuthorizationScope",
    "AuthorizationRecord",
    "VulnerabilityFinding",
    "ToolCategoryConfig",
    "SchemaToolDefinition",
    "UnifiedSchema",

    # Version
    "parse_version",
    "format_version",
    "compare_versions",
    "version_lt",
    "version_lte",
    "version_gt",
    "version_gte",
    "version_eq",
    "bump_version",
    "parse_constraint",
    "satisfies_constraint",
    "satisfies_all_constraints",
    "satisfies",
    "VersionManager",
    "PluginDependencyResolver",
    "SelfUpgradeManager",
    "VersionRecord",
    "VersionManagerConfig",
    "PluginDependency",
    "ResolvedDependency",
    "DependencyConflict",
    "UpgradeResult",
    "SelfUpgradeConfig",
    "create_version_manager",
    "is_compatible",

    # Schema
    "load_unified_schema",
    "clear_schema_cache",
    "get_provider_config",
    "get_all_providers",
    "get_providers_with_capabilities",
    "get_recommended_providers",
    "get_task_type_config",
    "get_all_task_types",
    "infer_task_type",
    "get_tool_definition",
    "get_tools_by_category",
    "get_tool_category",
    "get_enabled_tools",
    "tool_requires_auth",
    "validate_tool_arguments",
    "ToolArgumentValidationError",
    "get_schema_defaults",
    "get_schema_metadata",
    "get_schema_version",
    "provider_supports_capability",
    "select_best_provider",

    # Errors
    "StructuredError",
    "DangerousOperationError",
    "BlockedOperationError",
    "ValidationError",
    "ResourceLimitError",
    "ContextOverflowError",
    "ProviderError",
    "ToolExecutionError",
    "NetworkError",
    "ErrorRecoveryManager",
    "RecoveryStrategy",
    "RecoveryAttempt",
    "is_structured_error",
    "wrap_error",
    "create_error_recovery_manager",

    # Tool Runtime
    "ToolRuntime",
    "ToolRuntimeConfig",
    "ToolRuntimeObserver",
    "CacheEntry",
    "CACHEABLE_TOOLS",
    "create_tool_runtime",
    "create_tool_suite",

    # Tool Implementations - Core
    "create_read_tool",
    "create_write_tool",
    "create_edit_tool",
    "create_bash_tool",
    "create_glob_tool",
    "create_grep_tool",

    # Tool Implementations - Web
    "create_web_search_tool",
    "create_web_fetch_tool",

    # Tool Implementations - Coding
    "create_analyze_complexity_tool",
    "create_find_dependencies_tool",
    "create_generate_docstring_tool",
    "create_suggest_refactorings_tool",
    "create_generate_test_stub_tool",

    # Tool Implementations - Security
    "create_dependency_audit_tool",
    "create_code_security_scan_tool",
    "create_analyze_attack_surface_tool",

    # Tool Implementations - Alpha Zero
    "create_alpha_zero_evaluate_tool",
    "create_alpha_zero_tournament_tool",
    "create_alpha_zero_introspect_tool",
    "create_alpha_zero_history_tool",
    "create_alpha_zero_metrics_tool",

    # Suite Factories
    "create_unified_tool_suite",
    "create_core_tool_suite",
    "create_web_tool_suite",
    "create_coding_tool_suite",
    "create_security_tool_suite",
    "create_alpha_zero_tool_suite",

    # Metadata
    "UNIFIED_CORE_VERSION",
    "UNIFIED_CORE_AUTHOR",
    "UNIFIED_CORE_FRAMEWORK",
]
