"""
Unified Type Definitions

Single source of truth for all type definitions across the framework.
These types are designed to be language-agnostic and mirror the TypeScript implementation.

Principal Investigator: Bo Shang
Framework: erosolar-cli
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Literal, Optional, Union

# ============================================================================
# Conversation Types
# ============================================================================

ConversationRole = Literal["system", "user", "assistant", "tool"]


@dataclass
class ConversationMessage:
    """A message in a conversation."""
    role: ConversationRole
    content: str
    timestamp: Optional[str] = None
    tool_call_id: Optional[str] = None
    name: Optional[str] = None


# ============================================================================
# Tool Types
# ============================================================================

@dataclass
class ToolCallRequest:
    """A request to call a tool."""
    id: str
    name: str
    arguments: Dict[str, Any]


@dataclass
class ToolCallResult:
    """Result of a tool call execution."""
    tool_call_id: str
    output: str
    success: bool
    cached: bool
    duration_ms: float
    error: Optional[str] = None


@dataclass
class ToolDefinition:
    """Definition of a tool."""
    name: str
    description: str
    execute: Callable[[Dict[str, Any]], str]
    parameters: Optional["JSONSchemaObject"] = None
    cacheable: Optional[bool] = None
    requires_auth: Optional[bool] = None
    category: Optional[str] = None


@dataclass
class ToolSuite:
    """Collection of related tools."""
    name: str
    version: str
    tools: List[ToolDefinition]
    description: Optional[str] = None


@dataclass
class ToolRecord:
    """Internal record of a registered tool."""
    definition: ToolDefinition
    suite: str
    enabled: bool = True
    execution_count: int = 0
    last_executed: Optional[float] = None


# ============================================================================
# JSON Schema Types
# ============================================================================

JSONSchemaType = Literal["string", "number", "integer", "boolean", "array", "object", "null"]


@dataclass
class JSONSchemaProperty:
    """JSON Schema property definition."""
    type: Union[JSONSchemaType, List[JSONSchemaType]]
    description: Optional[str] = None
    enum: Optional[List[Any]] = None
    items: Optional["JSONSchemaProperty"] = None
    properties: Optional[Dict[str, "JSONSchemaProperty"]] = None
    required: Optional[List[str]] = None
    default: Optional[Any] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    pattern: Optional[str] = None
    format: Optional[str] = None


@dataclass
class JSONSchemaObject:
    """JSON Schema object definition."""
    type: Literal["object"] = "object"
    properties: Optional[Dict[str, JSONSchemaProperty]] = None
    required: Optional[List[str]] = None
    additional_properties: Optional[bool] = None
    description: Optional[str] = None


# ============================================================================
# Provider Types
# ============================================================================

ProviderId = Literal[
    "anthropic", "openai", "google", "deepseek", "xai", "ollama",
    "mistral", "groq", "together", "fireworks", "azure_openai", "bedrock"
]

ProviderCapability = Literal[
    "chat", "reasoning", "tools", "streaming", "multimodal", "vision", "prompt_caching"
]


@dataclass
class RateLimitConfig:
    """Rate limiting configuration."""
    max_retries: int = 4
    base_delay_ms: int = 750
    max_delay_ms: int = 40000
    backoff_multiplier: float = 2.0


@dataclass
class ProviderConfig:
    """Configuration for an LLM provider."""
    id: ProviderId
    label: str
    capabilities: List[ProviderCapability]
    models: List[str]
    default_model: str
    status: Literal["production", "beta", "deprecated"]
    description: Optional[str] = None
    base_url: Optional[str] = None
    api_version: Optional[str] = None
    env_vars: Dict[str, str] = field(default_factory=dict)
    reasoning_models: Optional[List[str]] = None
    openai_compatible: bool = False
    rate_limiting: Optional[RateLimitConfig] = None


@dataclass
class ProviderToolDefinition:
    """Tool definition in provider format."""
    type: Optional[str] = "function"
    function: Optional[Dict[str, Any]] = None
    name: Optional[str] = None
    description: Optional[str] = None
    parameters: Optional[JSONSchemaObject] = None


@dataclass
class ProviderUsage:
    """Token usage from a provider response."""
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cache_read_tokens: Optional[int] = None
    cache_creation_tokens: Optional[int] = None


@dataclass
class ProviderResponse:
    """Response from an LLM provider."""
    content: str
    tool_calls: Optional[List[ToolCallRequest]] = None
    usage: Optional[ProviderUsage] = None
    stop_reason: Optional[Literal["end_turn", "tool_use", "max_tokens", "stop_sequence"]] = None
    model: Optional[str] = None


@dataclass
class StreamChunk:
    """A chunk from a streaming response."""
    type: Literal["text", "tool_call_start", "tool_call_delta", "tool_call_end", "usage"]
    content: Optional[str] = None
    tool_call: Optional[Dict[str, Any]] = None
    usage: Optional[ProviderUsage] = None


# ============================================================================
# Task Types
# ============================================================================

TaskTypeId = Literal[
    "coding", "reasoning", "chat", "analysis", "research",
    "multimodal", "testing", "documentation", "security", "competitive_rl"
]


@dataclass
class TaskTypeConfig:
    """Configuration for a task type."""
    id: TaskTypeId
    label: str
    description: str
    required_capabilities: List[ProviderCapability]
    preferred_capabilities: List[ProviderCapability]
    default_temperature: float
    recommended_providers: List[ProviderId]
    tools: List[str]
    requires_auth: bool = False


# ============================================================================
# Error Types
# ============================================================================

class ErrorSeverity(Enum):
    """Severity level of an error."""
    CRITICAL = "critical"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class ErrorCategory(Enum):
    """Category of an error."""
    DANGEROUS = "dangerous"
    BLOCKED = "blocked"
    VALIDATION = "validation"
    RESOURCE = "resource"
    CONTEXT = "context"
    PROVIDER = "provider"
    TOOL = "tool"
    PERMISSION = "permission"
    NETWORK = "network"
    UNKNOWN = "unknown"


@dataclass
class ErrorSuggestion:
    """A suggestion for error recovery."""
    action: str
    description: str
    auto_fixable: bool = False
    fix_fn: Optional[Callable[[], bool]] = None


@dataclass
class StructuredErrorData:
    """Structured error data."""
    code: str
    message: str
    severity: ErrorSeverity
    category: ErrorCategory
    suggestions: List[ErrorSuggestion]
    recoverable: bool
    metadata: Dict[str, Any] = field(default_factory=dict)


# ============================================================================
# Version Types
# ============================================================================

@dataclass
class SemanticVersion:
    """Semantic version representation."""
    major: int
    minor: int
    patch: int
    prerelease: Optional[str] = None
    build: Optional[str] = None

    def __str__(self) -> str:
        s = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            s += f"-{self.prerelease}"
        if self.build:
            s += f"+{self.build}"
        return s

    def __lt__(self, other: "SemanticVersion") -> bool:
        return (self.major, self.minor, self.patch) < (other.major, other.minor, other.patch)

    def __le__(self, other: "SemanticVersion") -> bool:
        return (self.major, self.minor, self.patch) <= (other.major, other.minor, other.patch)

    def __gt__(self, other: "SemanticVersion") -> bool:
        return (self.major, self.minor, self.patch) > (other.major, other.minor, other.patch)

    def __ge__(self, other: "SemanticVersion") -> bool:
        return (self.major, self.minor, self.patch) >= (other.major, other.minor, other.patch)


VersionBump = Literal["major", "minor", "patch", "prerelease"]


@dataclass
class VersionConstraint:
    """Version constraint for dependencies."""
    operator: Literal["=", ">", ">=", "<", "<=", "^", "~"]
    version: SemanticVersion


# ============================================================================
# Plugin Types
# ============================================================================

class PluginCategory(Enum):
    """Category of a plugin."""
    CODING = "coding"
    RL = "rl"
    SECURITY = "security"
    DEV = "dev"
    INTEGRATION = "integration"


class PluginState(Enum):
    """State of a plugin."""
    UNLOADED = "unloaded"
    LOADING = "loading"
    LOADED = "loaded"
    ERROR = "error"
    DISABLED = "disabled"


@dataclass
class PluginMetadata:
    """Metadata for a plugin."""
    id: str
    name: str
    version: str
    description: str
    category: PluginCategory
    author: str
    requires_auth: bool = False
    dependencies: List[str] = field(default_factory=list)
    cli_commands: List[str] = field(default_factory=list)
    min_cli_version: Optional[str] = None
    max_cli_version: Optional[str] = None


@dataclass
class PluginConfig:
    """Configuration for a plugin."""
    enabled: bool = True
    settings: Dict[str, Any] = field(default_factory=dict)


# ============================================================================
# Context Types
# ============================================================================

@dataclass
class ContextManagerConfig:
    """Configuration for context management."""
    max_tokens: int = 130000
    target_tokens: int = 100000
    max_tool_output_length: int = 10000
    preserve_recent_messages: int = 10
    chars_per_token: float = 4.0
    enable_summarization: bool = False


@dataclass
class TruncationResult:
    """Result of truncating content."""
    content: str
    was_truncated: bool
    original_length: int
    truncated_length: int
    method: Optional[Literal["head", "tail", "middle", "smart"]] = None


# ============================================================================
# Agent Types
# ============================================================================

@dataclass
class AgentConfig:
    """Configuration for an agent."""
    provider_id: ProviderId
    model: str
    system_prompt: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    tools: Optional[List[str]] = None
    streaming: bool = False


@dataclass
class AgentSession:
    """An agent session."""
    id: str
    config: AgentConfig
    messages: List[ConversationMessage]
    start_time: str
    total_tokens_used: int = 0
    total_tool_calls: int = 0


# ============================================================================
# Alpha Zero Types
# ============================================================================

@dataclass
class CodeQualityMetrics:
    """Code quality evaluation metrics."""
    code_quality_score: float
    algorithm_efficiency: float
    error_handling_score: float
    documentation_score: float
    maintainability_score: float
    security_score: float


@dataclass
class AgentPerformanceMetrics:
    """Performance metrics for an agent."""
    session_id: str
    total_messages: int
    total_tool_calls: int
    total_tokens_used: int
    total_time_ms: float
    successful_tool_calls: int
    failed_tool_calls: int
    code_blocks_generated: int
    avg_response_time_ms: float
    avg_code_quality: float


@dataclass
class TournamentConfig:
    """Configuration for a tournament."""
    tournament_id: str
    rounds: int
    prompts: List[str]
    evaluate_code: bool = True
    parallel_execution: bool = False


@dataclass
class CompetitionRoundResult:
    """Result of a competition round."""
    prompt: str
    agent1: Dict[str, Any]
    agent2: Dict[str, Any]
    winner: str
    total_time_ms: float


@dataclass
class TournamentResult:
    """Result of a tournament."""
    tournament_id: str
    config: TournamentConfig
    rounds: List[CompetitionRoundResult]
    standings: Dict[str, int]
    start_time: str
    end_time: str
    total_duration_ms: float


# ============================================================================
# Security Types
# ============================================================================

class AuthorizationScope(Enum):
    """Scope of authorization for security research."""
    OWNED_SYSTEMS = "owned_systems"
    BUG_BOUNTY = "bug_bounty"
    PENTEST_ENGAGEMENT = "pentest_engagement"
    CTF_COMPETITION = "ctf_competition"
    RED_TEAM = "red_team"
    EDUCATIONAL = "educational"


@dataclass
class AuthorizationRecord:
    """Authorization record for security research."""
    scope: AuthorizationScope
    target_domain: str
    authorized_by: str
    authorization_date: str
    scope_limitations: List[str]
    out_of_scope: List[str]
    notes: str
    expiration_date: Optional[str] = None


@dataclass
class VulnerabilityFinding:
    """A vulnerability finding."""
    title: str
    severity: Literal["critical", "high", "medium", "low", "info"]
    category: str
    description: str
    evidence: str
    remediation: str
    cvss_score: Optional[float] = None
    cwe_id: Optional[str] = None


# ============================================================================
# Schema Types (for unified schema loading)
# ============================================================================

@dataclass
class ToolCategoryConfig:
    """Configuration for a tool category."""
    id: str
    label: str
    description: str
    always_enabled: bool = False
    requires_auth: bool = False
    tools: List[str] = field(default_factory=list)


@dataclass
class SchemaToolDefinition:
    """Tool definition from the schema."""
    id: str
    name: str
    description: str
    category: str
    cacheable: bool = False
    requires_auth: bool = False
    parameters: Optional[Dict[str, Any]] = None


@dataclass
class UnifiedSchema:
    """The unified schema structure."""
    contract_version: str
    version: str
    label: str
    description: str
    providers: List[ProviderConfig]
    task_types: List[TaskTypeConfig]
    tool_categories: List[ToolCategoryConfig]
    tools: List[SchemaToolDefinition]
    defaults: Dict[str, Any]
    metadata: Dict[str, Any]
