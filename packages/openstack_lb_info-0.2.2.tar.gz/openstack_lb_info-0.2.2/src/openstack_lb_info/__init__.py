# -*- coding: utf-8 -*-
"""openstack-lb-info module."""

__version__ = "0.2.2"
