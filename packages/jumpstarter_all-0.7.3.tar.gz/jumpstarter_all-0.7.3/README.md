# jumpstarter-all

The Jumpstarter project is a collection of tools and services to help automate
the testing of/on hardware devices.

This is a meta-package that pulls installation of all the Python modules
produced in the Jumpstarter project.

