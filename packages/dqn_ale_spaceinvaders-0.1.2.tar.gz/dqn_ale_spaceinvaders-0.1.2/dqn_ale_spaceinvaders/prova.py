"""
Module to enjoy a trained DQN agent playing Atari Space Invaders.
"""
import argparse
from pathlib import Path


import gymnasium as gym
import torch
import numpy as np
import yaml
import imageio.v3 as iio

from agent import Agent
from environment import make_env, get_env_dims

from utils import load_artifact



def record_gif(env: gym.Env, agent: Agent, filepath: Path, fps: int = 60) -> None:
    """Record a movie of the agent interacting with the environment."""
    images = []
    done = False
    state, _ = env.reset()
    img = env.render()
    images.append(img)

    while not done:
        action = agent.act(state, epsilon=0.0)

        next_state, _, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        state = next_state

        img = env.render()
        images.append(img)

    iio.imwrite(
        "demo.gif",
        images,
        duration=1000/60,
        loop=0,
        codec="libx264",
        macro_block_size=1,
    )
    print("done")

def enjoy(artifact_path: Path, n_episodes: int) -> None:
    """Enjoy a trained DQN agent playing Atari Space Invaders."""
    _, env, agent = load_artifact(artifact_path, "rgb_array")
    record_gif(env, agent, "")


    env.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--artifact",
        "-a",
        type=str,
        required=True,
        help="The artifact to play Atari Space Invaders.",
    )
    parser.add_argument(
        "--num-episodes",
        "-n",
        type=int,
        default=10,
        help="The number of Atari Space Invaders episodes to enjoy.",
    )
    args = parser.parse_args()

    artifact = Path(args.artifact)
    num_episodes = args.num_episodes

    enjoy(artifact_path=artifact, n_episodes=num_episodes)
