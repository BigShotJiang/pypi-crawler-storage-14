**Italiano**

Modulo per la stampa del libro giornale con reportlab

**English**

Module for print general journal with reportlab
