# 1.0.0 - 19 November 2025

Initial release of migrated `operator_libs_linux.v1.systemd` library (patch version 4)
with minor modifications to statisfy new linter rules.