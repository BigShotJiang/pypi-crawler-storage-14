# charmlibs.systemd

The `systemd` library.

To install, add `charmlibs-systemd` to your Python dependencies. Then in your Python code, import as:

```py
from charmlibs import systemd
```

See the [reference documentation](https://documentation.ubuntu.com/charmlibs/reference/charmlibs/systemd) for more.
