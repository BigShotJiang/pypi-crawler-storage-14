LEVEL_LOGGER_MAP = {
    'DEBUG': ('debug_logger', 'debug'),
    'INFO': ('info_logger', 'info'),
    'WARNING': ('warning_logger', 'warning'),
    'ERROR': ('error_logger', 'error'),
    'EXCEPTION': ('exception_logger', 'exception'),
}
