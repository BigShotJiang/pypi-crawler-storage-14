from threading import (
    local,
)


thread_data = local()
