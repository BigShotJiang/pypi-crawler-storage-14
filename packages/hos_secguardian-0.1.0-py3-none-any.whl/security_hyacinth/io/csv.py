from typing import List, Dict, Any


def parse_csv(text: str) -> List[Dict[str, Any]]:
    assets: Dict[str, Dict[str, Any]] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 2:
            continue
        addr = parts[0]
        port = int(parts[1]) if parts[1] else None
        proto = parts[2] if len(parts) > 2 else "tcp"
        service = parts[3] if len(parts) > 3 else None
        product = parts[4] if len(parts) > 4 else None
        version = parts[5] if len(parts) > 5 else None
        host = assets.setdefault(addr, {"address": addr, "ports": []})
        host["ports"].append({
            "port": port,
            "protocol": proto,
            "service": service,
            "product": product,
            "version": version,
        })
    return list(assets.values())

