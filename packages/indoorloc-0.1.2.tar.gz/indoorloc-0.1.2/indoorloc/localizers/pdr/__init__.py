"""
Pedestrian Dead Reckoning (PDR) Localizers

Inertial navigation-based localization methods.
"""

__all__ = []
