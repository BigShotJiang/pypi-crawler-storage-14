"""
Built-in Configurations

Pre-defined configurations for common use cases.
"""

__all__ = []
