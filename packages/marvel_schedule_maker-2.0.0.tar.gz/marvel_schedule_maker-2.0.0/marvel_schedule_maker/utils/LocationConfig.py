
from configparser import ConfigParser
from dataclasses import dataclass
import math
import os
from pathlib import Path

from astropy.coordinates import EarthLocation

# NOT IMPORTING FOR THE MOMENT, HARDCODED

# THIS IMPORT NEEDS TO CHANGE 
# MCONFIG = Path(__file__).resolve().parent.parent / "config"
# MCONFIG = Path(os.path.expandvars("$MCONFIG"))

# LOCATIONCONFIG = str(MCONFIG / "marvel/telescope/telescopeproperties.cfg")


@dataclass
class Location:
    LON: float
    LAT: float
    ELE: int


# def getConstants(configfile):
#     config = ConfigParser()
#     config.read(configfile)

#     location = Location(
#         LON=float(config.get("LONLAT", "longitude")),
#         LAT=float(config.get("LONLAT", "latitude")),
#         ELE=int(config.get("LONLAT", "elevation"))
#     )

#     return location

# LOCATION: Location = getConstants(LOCATIONCONFIG)

LOCATION: Location = Location(
    -0.31203578143571958,
    0.50199547796805788,
    2400
)

MyEarthLocation = EarthLocation.from_geodetic(
    LOCATION.LON / math.pi * 180,
    LOCATION.LAT / math.pi * 180,
    LOCATION.ELE
)