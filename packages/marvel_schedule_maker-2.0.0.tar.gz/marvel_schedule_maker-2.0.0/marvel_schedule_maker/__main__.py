"""Allow running as `python -m marvel_scheduler`."""

from .main import main

if __name__ == "__main__":
    main()