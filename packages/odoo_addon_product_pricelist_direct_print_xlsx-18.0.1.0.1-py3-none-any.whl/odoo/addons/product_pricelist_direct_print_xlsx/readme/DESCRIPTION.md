This module is based on the OCA module `product_pricelist_direct_print`
and add the possibility to export price list in XLSX format.
