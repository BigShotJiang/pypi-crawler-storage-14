from o2a_registry.validation.url_host_checker import ORCID_URL, ROR_URL

__all__ = ["ORCID_URL", "ROR_URL"]
