# -*- coding: utf-8 -*-
from .step import Step


class Task(Step):
    """
    Represents a plugin Task.
    """

    pass
