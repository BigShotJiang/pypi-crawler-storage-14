# REPL terminal UI components and event handling
