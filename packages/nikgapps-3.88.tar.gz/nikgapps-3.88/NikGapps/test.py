from niklibrary.web.Requests import Requests

print(Requests.get_package_details())
