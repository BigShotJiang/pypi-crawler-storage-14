a = 6

print(a)
print(a)
