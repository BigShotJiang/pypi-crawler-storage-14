"""Run Brenthy."""

import os
import sys

os.chdir("../..")
os.system(f"{sys.executable} .")
