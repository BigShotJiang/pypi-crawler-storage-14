def override_sigint(sig, frame):
    pass
