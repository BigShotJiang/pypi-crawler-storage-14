class FileNotFoundException(Exception):
    pass


class TTYContainerWithoutTTYCommandException(Exception):
    pass
