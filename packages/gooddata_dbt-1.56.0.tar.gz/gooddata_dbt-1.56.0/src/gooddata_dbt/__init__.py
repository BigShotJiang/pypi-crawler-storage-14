# (C) 2023 GoodData Corporation
from gooddata_dbt._version import __version__
