class Zensus2PgsqlError(Exception):
    pass
