"""Tests for zensus2pgsql commands."""
