"""Zensus Collector test suite."""
