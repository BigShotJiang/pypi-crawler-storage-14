"""
uv_easy 패키지의 메인 진입점
"""

from .cli import main

if __name__ == "__main__":
    main()
