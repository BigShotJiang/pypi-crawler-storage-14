from moysklad_api.methods import MSMethod
from moysklad_api.types import Assortment, MetaArray


class GetAssortment(MSMethod):
    """
    Use this method to get assortment.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/assortment#3-poluchit-assortiment
    """

    __return__ = MetaArray[Assortment]
    __api_method__ = "entity/assortment"
