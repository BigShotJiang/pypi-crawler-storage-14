from .entity import Entity


class State(Entity):
    pass
