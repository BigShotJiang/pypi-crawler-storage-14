from tools.discovery_engine import discovery_search_engine

def discovery_search():
    return discovery_search_engine