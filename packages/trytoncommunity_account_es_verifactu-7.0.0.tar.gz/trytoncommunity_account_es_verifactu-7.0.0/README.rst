###########################
Account Es Verifactu Module
###########################

The 'Veri*factu Regulation', referring to the simplest method for complying
with the standard by sending the billing records to the Tax Agency at
the time of their production.

The law which explains all the technical regulations is published:

https://www.boe.es/buscar/act.php?id=BOE-A-2024-22138

The new regulation will apply to all businesses and all their operations,
with the exception of those who are already subject to the Immediate Supply
of Information (SII) or those who do not have an obligation to invoice.

As regards its territorial scope, it is applicable throughout Spain except
in territories with a regional tax regime. In the Historical Territories
of Vizcaya, Guipúzcoa and Álava, the so-called 'Ticket Bai' systems have
recently been applicable, the operation of which is similar to that now
approved for the rest of Spain.


.. toctree::
   :maxdepth: 2

   setup
   usage
   configuration
   design
   reference
   releases
