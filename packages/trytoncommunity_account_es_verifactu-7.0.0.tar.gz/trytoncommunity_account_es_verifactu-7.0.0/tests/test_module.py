# The COPYRIGHT file at the top level of this repository contains the full
# copyright notices and license terms.
from trytond.tests.test_tryton import ModuleTestCase


class AccountEsVerifactuTestCase(ModuleTestCase):
    "Test Account Es Verifactu module"
    module = 'account_es_verifactu'


del ModuleTestCase
