from __future__ import annotations

import sys

from audex.cli import main

sys.exit(main())
