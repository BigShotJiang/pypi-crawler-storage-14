from .imports import *
from .lander import create_lander_ultra
from .generate_seo_files import create_seo_files

def bootstrap_domain(root_dir,**kwargs):
    """Creates: index.html, SEO files, directories, icons, etc."""
    domain = kwargs['domain']
   
    filename, ext = os.path.splitext(domain)
    ext = ext.replace(".", "")

    make_dirs(root_dir)
    
    index_path = os.path.join(root_dir, "index.html")


    meta_html = call_meta_data(**kwargs)
  

    create_lander_ultra(domain, index_path, meta_html)


    create_seo_files(domain, root_dir)

    return root_dir
