from abstract_utilities import write_to_file
from abstract_webtools import urlManager
from .generate_seo_files import create_seo_files

def create_lander_ultra(domain, file_path, meta_html):
    """Creates an SEO-rich landing page using full UltraMeta tags."""

    url_mgr = urlManager(domain)
    parsed = url_mgr.parsed
    name = parsed.get("app_name", domain)

    lander = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />

  <!-- Preconnect -->
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link rel="dns-prefetch" href="https://fonts.googleapis.com" />

  <!-- Canonical -->
  <link rel="canonical" href="https://{domain}" />

  <!-- Icons -->
  <link rel="icon" href="/imgs/icons/favicon.ico" />
  <link rel="apple-touch-icon" sizes="180x180" href="/imgs/icons/icon_180x180.png" />

  {meta_html}
</head>
<body>
  <h1>Welcome to {name}</h1>
</body>
</html>
"""

    write_to_file(contents=lander, file_path=file_path)
    return lander
