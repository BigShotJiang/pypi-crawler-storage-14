from .imports import *
from .bootstrap_utils import *
from .imports import *
PASSWORD = 'ANy1Kan@!23'

def check_if_default_dir(directory):
    
    default_files = [os.path.join(directory,'index.conf'),os.path.join(directory,'index_http.conf')]
    dir_list = collect_globs(directories=[directory], **kwargs)#,user_at_host='solcatcher',password=PASSWORD).get('files')
    
    if len(dir_list) == 2 and default_files[0] in dir_list and default_files[1] in dir_list:
        return True
    return False
def create_pointers_index(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    pointers_index_path = path_mgr.pointers_index_path
    domain = path_mgr.domain
    pointers_main_path = path_mgr.pointers_main_path
    main_root_path = path_mgr.main_root_path
    filename = path_mgr.filename
    ext = path_mgr.ext
    # index.conf
    contents = f"""#{pointers_index_path}
    include {pointers_main_path};"""
    write_to_file(contents=contents, file_path=pointers_index_path,password=PASSWORD)

    contents = f"""
location / {{
    include {main_root_path};
}}

# Serve your imgs folder (unhashed public images)
location /imgs/ {{
    alias /mnt/24T/media/images/{filename}/;
    disable_symlinks off;
    access_log off;
    expires 30d;
    add_header Cache-Control "public, max-age=2592000";
}}

# Serve your Webpack static assets (JS/CSS/etc)
location /static/ {{
    alias /var/www/sites/{filename}/{ext}/react/main/build/static/;
    access_log off;
    expires 30d;
    add_header Cache-Control "public, max-age=2592000";
}}
"""
    print(f"pointers_main_path == {pointers_main_path}")
    write_to_file(contents=contents, file_path=pointers_main_path,password=PASSWORD)

def create_noncannonical_redirect_content(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    domain = path_mgr.domain
    noncannonical_redirect_path = path_mgr.noncannonical_redirect_path
    contents = f"""
# ----------------------------
# 2) Non-canonical HTTPS redirect
# ----------------------------
server {{
    listen 443 ssl http2;
    server_name www.{domain};

    ssl_certificate     /etc/letsencrypt/live/{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{domain}/privkey.pem;
    include             /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam         /etc/letsencrypt/ssl-dhparams.pem;

    return 301 https://{domain}$request_uri;
}}
"""
    write_to_file(contents=contents, file_path=noncannonical_redirect_path)

def create_server_name_content(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    domain = path_mgr.domain
    main_server_name_path = path_mgr.server_name_path
    contents = f"""    server_name {domain} www.{domain};"""
    write_to_file(contents=contents,file_path=main_server_name_path,password=PASSWORD)#,user_at_host='solcatcher',password=PASSWORD)
def create_ssl_content(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    domain = path_mgr.domain
    main_ssl_path = path_mgr.main_ssl_path
    contents = f"""ssl_certificate /etc/letsencrypt/live/{domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{domain}/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;"""
    write_to_file(contents=contents,file_path=main_ssl_path,password=PASSWORD)#,user_at_host='solcatcher',password=PASSWORD)
def create_root_content(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    root_content_dir = path_mgr.root_content_dir
    main_root_path = path_mgr.main_root_path
    contents = f"""root {root_content_dir};
    index index.html;"""
    write_to_file(contents=contents,file_path=main_root_path,password=PASSWORD)#,user_at_host='solcatcher',password=PASSWORD)
def create_lander(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    root_content_dir = path_mgr.root_content_dir
    main_root_path = path_mgr.main_root_path
    domain = path_mgr.domain
    root_content_path = path_mgr.root_content_path
    url_mgr = urlManager(domain)
    parsed = url_mgr.parsed
    name = parsed.get('app_name')
    meta_data = call_meta_data(**kwargs)
    
    
    lander = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <!-- Preconnect -->
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link rel="dns-prefetch" href="https://fonts.googleapis.com" />

  <!-- Canonical -->
  <link rel="canonical" href="https://{domain}" />

  <!-- Icons -->
  <link rel="icon" href="/imgs/icons/favicon.ico" />
  <link rel="apple-touch-icon" sizes="180x180" href="/imgs/icons/icon_180x180.png" />

  {meta_data}
  <style>
    body {{
      font-family: system-ui, sans-serif;
      margin: 0;
      padding: 2rem;
      background: #f9fafb;
      color: #111;
    }}
    h1 {{
      font-size: 2rem;
      margin-bottom: 1rem;
    }}
    a {{
      display: inline-block;
      margin: 0.5rem 0;
      font-size: 1.1rem;
      color: #2563eb;
      text-decoration: none;
    }}
    a:hover {{
      text-decoration: underline;
    }}
  </style>
</head>
<body>
  <h1>Welcome to {name}</h1>

</body>
</html>
"""
    
    write_to_file(contents = lander,file_path=root_content_path,password=PASSWORD)
    return lander
def create_main_index_contents(*args,**kwargs):
    path_mgr = get_path_mgr(*args,**kwargs)
    create_noncannonical_redirect_content(*args,**kwargs)
    create_server_name_content(*args,**kwargs)
    create_ssl_content(*args,**kwargs)
    create_root_content(*args,**kwargs)
    create_pointers_index(*args,**kwargs)
    main_root_path = path_mgr.main_root_path
    main_ssl_path = path_mgr.main_ssl_path
    pointers_index_path = path_mgr.pointers_index_path
    server_name_path = path_mgr.server_name_path
    parent_index_path = path_mgr.parent_index_path
    
    # -----------------------
    # Now generate **index.conf**
    # -----------------------
    main_index_contents = f"""
# HTTP redirect to HTTPS
server {{
    include /etc/nginx/sites-available/common/listen_80.conf;
    include {server_name_path};
    include /etc/nginx/sites-available/common/301_return.conf;
}}

# HTTPS server
server {{
    include /etc/nginx/sites-available/common/listen_443.conf;
    include {server_name_path};
    include {main_root_path};
    include {main_ssl_path};
    include {pointers_index_path};
}}
"""

    write_to_file(
        contents=main_index_contents,
        file_path=parent_index_path
    )
    run_cmd('reload_nginx')
    create_lander(*args,**kwargs)
