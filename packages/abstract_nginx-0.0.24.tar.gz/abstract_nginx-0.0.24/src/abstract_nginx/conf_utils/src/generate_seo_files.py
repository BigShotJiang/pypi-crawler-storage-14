from .imports import *
def create_seo_files(domain, root_dir):
    """Creates robots.txt, sitemap.xml, manifest.json, oembed.json,
    opensearch.xml, browserconfig.xml, humans.txt, security.txt,
    site.webmanifest and creates required icon directories."""

    icons_root = os.path.join("/mnt/24T/media/images", domain.split('.')[0], "icons")
    make_dirs(icons_root)

    # -----------------------------
    # robots.txt
    # -----------------------------
    robots = f"""User-agent: *
Allow: /
Sitemap: https://{domain}/sitemap.xml
"""
    file_path = os.path.join(root_dir, "robots.txt")
    write_to_file(contents=robots, file_path=file_path)

    # -----------------------------
    # sitemap.xml
    # -----------------------------
    sitemap = f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>https://{domain}</loc></url>
</urlset>
"""
    file_path = os.path.join(root_dir, "sitemap.xml")
    write_to_file(contents=sitemap,file_path=file_path)

    # -----------------------------
    # manifest.json
    # -----------------------------
    manifest = f"""{{
  "name": "{domain}",
  "short_name": "{domain}",
  "theme_color": "#ffffff",
  "background_color": "#ffffff",
  "display": "standalone",
  "icons": [
    {{ "src": "/imgs/icons/icon-192.png", "sizes": "192x192", "type": "image/png" }},
    {{ "src": "/imgs/icons/icon-512.png", "sizes": "512x512", "type": "image/png" }}
  ]
}}
"""
    file_path = os.path.join(root_dir, "manifest.json")
    write_to_file(contents=manifest, file_path=file_path)
    file_path = os.path.join(root_dir, "site.webmanifest")
    write_to_file(contents=manifest, file_path=file_path)

    # -----------------------------
    # browserconfig.xml
    # -----------------------------
    browserconfig = f"""<?xml version="1.0" encoding="utf-8"?>
<browserconfig>
  <msapplication>
    <tile>
      <square150x150logo src="/imgs/icons/icon-192.png"/>
    </tile>
  </msapplication>
</browserconfig>
"""
    file_path = os.path.join(root_dir, "browserconfig.xml")
    write_to_file(contents=browserconfig, file_path=file_path)

    # -----------------------------
    # humans.txt
    # -----------------------------
    humans = f"""Team: {domain}
Site: https://{domain}
"""
    file_path = os.path.join(root_dir, "humans.txt")
    write_to_file(contents=humans, file_path=file_path)

    # -----------------------------
    # security.txt
    # -----------------------------
    well_known = os.path.join(root_dir, ".well-known")
    make_dirs(well_known)
    file_path = os.path.join(well_known, "security.txt")
    content = "Contact: mailto:security@{domain}"
    write_to_file(contents=content,file_path=file_path)

    # -----------------------------
    # opensearch.xml
    # -----------------------------
    opensearch = f"""<OpenSearchDescription>
  <ShortName>{domain}</ShortName>
  <Url type="text/html" template="https://{domain}/search?q={{searchTerms}}"/>
</OpenSearchDescription>
"""
    file_path = os.path.join(root_dir, "opensearch.xml")
    write_to_file(contents=opensearch,file_path=file_path)

    # -----------------------------
    # oembed.json
    # -----------------------------
    oembed = f"""{{
  "version": "1.0",
  "type": "link",
  "title": "{domain}",
  "provider_name": "{domain}",
  "provider_url": "https://{domain}"
}}
"""
    file_path = os.path.join(root_dir, "oembed.json")
    write_to_file(contents=oembed, file_path=file_path)

    return True

