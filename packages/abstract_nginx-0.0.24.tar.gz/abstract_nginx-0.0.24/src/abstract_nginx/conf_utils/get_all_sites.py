from .imports import *
from .src import *
from abstract_utilities import run_cmd as get_cmd


def check_and_back(*args,**kwargs):

    path_mgr = get_path_mgr(*args,**kwargs)
    create_main_index_contents(*args,**kwargs)
    get_cmd('reload_nginx',**kwargs)
    root_content_dir = path_mgr.root_content_dir
    bootstrap_domain(root_content_dir,*args,**kwargs)
