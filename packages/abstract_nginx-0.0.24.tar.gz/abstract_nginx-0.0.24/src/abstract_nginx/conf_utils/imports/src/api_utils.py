from .imports import *
def call_meta_data(**kwargs):
    return postRequest(
        url="https://typicallyoutliers.com",
        endpoint="/utilities/generate_meta_tags",
        data=kwargs
    )
