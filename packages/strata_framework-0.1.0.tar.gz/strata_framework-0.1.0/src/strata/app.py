"""Simple App class for Level 1 APIs"""

from typing import Any, Callable, Dict, Optional
import uvicorn
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route


class App:
    """Simple application class for quick API development.

    This is Level 1 of the Strata progressive API - equivalent to Flask/FastAPI
    but with the foundation for growing to full enterprise applications.
    """

    def __init__(self, debug: bool = False):
        self.debug = debug
        self.routes: Dict[str, Dict[str, Callable]] = {}
        self._starlette_app = None

    def get(self, path: str):
        """Decorator for GET routes"""
        def decorator(func: Callable) -> Callable:
            if path not in self.routes:
                self.routes[path] = {}
            self.routes[path]["GET"] = func
            return func
        return decorator

    def post(self, path: str):
        """Decorator for POST routes"""
        def decorator(func: Callable) -> Callable:
            if path not in self.routes:
                self.routes[path] = {}
            self.routes[path]["POST"] = func
            return func
        return decorator

    def put(self, path: str):
        """Decorator for PUT routes"""
        def decorator(func: Callable) -> Callable:
            if path not in self.routes:
                self.routes[path] = {}
            self.routes[path]["PUT"] = func
            return func
        return decorator

    def delete(self, path: str):
        """Decorator for DELETE routes"""
        def decorator(func: Callable) -> Callable:
            if path not in self.routes:
                self.routes[path] = {}
            self.routes[path]["DELETE"] = func
            return func
        return decorator

    def _create_starlette_routes(self) -> list:
        """Convert Strata routes to Starlette routes"""
        routes = []

        for path, methods in self.routes.items():
            for method, handler in methods.items():
                # Create a wrapper that handles the response
                async def route_handler(request, handler=handler):
                    # Call the user's handler function
                    result = handler()
                    # Handle async functions
                    if hasattr(result, '__await__'):
                        result = await result
                    # Convert to JSON response
                    return JSONResponse(result)

                routes.append(Route(path, route_handler, methods=[method]))

        return routes

    def _get_starlette_app(self) -> Starlette:
        """Get or create the Starlette application"""
        if self._starlette_app is None:
            routes = self._create_starlette_routes()
            self._starlette_app = Starlette(
                debug=self.debug,
                routes=routes
            )
        return self._starlette_app

    def run(self, host: str = "127.0.0.1", port: int = 8000, **kwargs):
        """Run the application with uvicorn"""
        app = self._get_starlette_app()
        uvicorn.run(app, host=host, port=port, **kwargs)