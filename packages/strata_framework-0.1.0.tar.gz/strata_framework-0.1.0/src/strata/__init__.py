"""Strata Framework - NestJS for Python"""

__version__ = "0.1.0"
__author__ = "Strata Framework Team"
__email__ = "team@strata-framework.dev"

from .app import App
from .application import Application

__all__ = ["App", "Application", "__version__"]