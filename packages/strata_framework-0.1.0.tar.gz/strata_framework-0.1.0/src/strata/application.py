"""Application class with provider system"""

from typing import Any, Dict, List, Optional, Type, TypeVar
from .container import Container
from .providers.base import Provider

T = TypeVar('T')


class Application:
    """Full-featured application class with provider system.

    This supports Level 2 (Provider Composition) and Level 3 (Enterprise Patterns)
    of the Strata progressive API.
    """

    def __init__(self, name: str = "strata-app", debug: bool = False):
        self.name = name
        self.debug = debug
        self._container = Container()
        self._providers: Dict[str, Provider] = {}
        self._started = False

    def use(self, provider: Provider) -> 'Application':
        """Add a provider to the application"""
        provider_name = getattr(provider, 'name', provider.__class__.__name__.lower())
        self._providers[provider_name] = provider
        return self

    def resolve(self, service_type: Type[T]) -> T:
        """Resolve a service from the container"""
        return self._container.resolve(service_type)

    async def startup(self) -> None:
        """Start the application and all providers"""
        if self._started:
            return

        # Register providers with container
        for provider in self._providers.values():
            await provider.register(self._container)

        # Start all providers
        for provider in self._providers.values():
            await provider.startup(self)

        self._started = True

    async def shutdown(self) -> None:
        """Shutdown the application and all providers"""
        if not self._started:
            return

        # Shutdown providers in reverse order
        for provider in reversed(list(self._providers.values())):
            await provider.shutdown(self)

        self._started = False

    def get_provider(self, name: str) -> Optional[Provider]:
        """Get a provider by name"""
        return self._providers.get(name)

    @property
    def providers(self) -> Dict[str, Provider]:
        """Get all registered providers"""
        return self._providers.copy()

    @property
    def container(self) -> Container:
        """Get the dependency injection container"""
        return self._container