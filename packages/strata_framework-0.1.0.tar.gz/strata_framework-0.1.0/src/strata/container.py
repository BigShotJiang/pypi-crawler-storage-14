"""Dependency injection container"""

from typing import Any, Dict, Type, TypeVar
import inspect

T = TypeVar('T')


class Container:
    """Simple dependency injection container"""

    def __init__(self):
        self._services: Dict[Type, Any] = {}
        self._singletons: Dict[Type, Any] = {}

    def register(self, service_type: Type[T], implementation: Type[T] | T) -> None:
        """Register a service implementation"""
        self._services[service_type] = implementation

    def singleton(self, service_type: Type[T], implementation: Type[T] | T) -> None:
        """Register a singleton service"""
        self._singletons[service_type] = implementation

    def resolve(self, service_type: Type[T]) -> T:
        """Resolve a service from the container"""
        # Check singletons first
        if service_type in self._singletons:
            instance = self._singletons[service_type]
            if inspect.isclass(instance):
                # Instantiate the class
                self._singletons[service_type] = self._instantiate(instance)
                return self._singletons[service_type]
            return instance

        # Check regular services
        if service_type in self._services:
            implementation = self._services[service_type]
            if inspect.isclass(implementation):
                return self._instantiate(implementation)
            return implementation

        # Try to instantiate the service type directly
        if inspect.isclass(service_type):
            return self._instantiate(service_type)

        raise ValueError(f"Cannot resolve service: {service_type}")

    def _instantiate(self, cls: Type[T]) -> T:
        """Instantiate a class with dependency injection"""
        # Get the constructor parameters
        init_signature = inspect.signature(cls.__init__)
        kwargs = {}

        for param_name, param in init_signature.parameters.items():
            if param_name == 'self':
                continue

            # Try to resolve the parameter type
            if param.annotation != inspect.Parameter.empty:
                try:
                    kwargs[param_name] = self.resolve(param.annotation)
                except ValueError:
                    # If we can't resolve it, check if it has a default
                    if param.default != inspect.Parameter.empty:
                        kwargs[param_name] = param.default
                    else:
                        raise
            elif param.default != inspect.Parameter.empty:
                kwargs[param_name] = param.default
            else:
                raise ValueError(f"Cannot resolve parameter '{param_name}' for {cls}")

        return cls(**kwargs)