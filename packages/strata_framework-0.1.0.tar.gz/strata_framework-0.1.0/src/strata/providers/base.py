"""Base provider classes"""

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..application import Application
    from ..container import Container


class Provider(ABC):
    """Base class for all providers"""

    def __init__(self):
        self.name = self.__class__.__name__.lower().replace('provider', '')

    @abstractmethod
    async def register(self, container: 'Container') -> None:
        """Register services with the container"""
        pass

    @abstractmethod
    async def startup(self, app: 'Application') -> None:
        """Start the provider"""
        pass

    @abstractmethod
    async def shutdown(self, app: 'Application') -> None:
        """Shutdown the provider"""
        pass