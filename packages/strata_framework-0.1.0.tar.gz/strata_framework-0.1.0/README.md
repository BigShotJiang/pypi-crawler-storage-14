# Strata Framework

**NestJS for Python** - Progressive Event-Driven Applications

[![PyPI version](https://badge.fury.io/py/strata-framework.svg)](https://pypi.org/project/strata-framework/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Strata is a progressive Python framework for building event-driven applications from simple REST APIs to federated GraphQL microservices with event sourcing.

## 🚀 Quick Start

### Level 1: Simple App (5 minutes)

```python
from strata import App

app = App()

@app.get("/")
async def hello():
    return {"message": "Hello, Strata!"}

# Run with: python -m uvicorn main:app --reload
```

### Level 2: Provider-Based (15 minutes)

```python
from strata import Application

app = Application()
# Add providers as they become available
# app.use(DatabaseProvider("postgresql://..."))
# app.use(AuthProvider(secret_key="..."))

# For now, just run the app
```

### Level 3: Enterprise Patterns (30+ minutes)

```python
from strata import Application

app = (
    Application(name="my-enterprise-app")
    # .with_state(provider="postgres", url="postgresql://...")
    # .with_cache(provider="redis", url="redis://localhost:6379")
    # .with_pubsub(provider="rabbitmq", url="amqp://...")
    # .configure(lambda builder: builder.add_environment_variables("APP_"))
    # .enforce_architecture([...])
    # .enable_telemetry(exporter="jaeger")
    .build()
)
```

## 🎯 Features

### 🏗️ Architectural Innovations
- **Provider Pattern**: Clean extensibility and modular components
- **Progressive Enhancement**: Start simple, add complexity as needed
- **Full Dependency Injection**: Enterprise-grade DI with scopes and lifecycle
- **Multi-Source Configuration**: Hierarchical config with Pydantic validation
- **Advanced Middleware Pipeline**: Async context sharing and proper ordering

### 🎯 Senior Developer Features
- **Architectural Guardrails**: Runtime enforcement of clean architecture (Coming Soon)
- **Native Test Bed**: Clean provider mocking for testing (Coming Soon)
- **Zero-Config OpenTelemetry**: Automatic distributed tracing (Coming Soon)
- **Super REPL**: Interactive console with full application context (Coming Soon)
- **Smart Queue Abstraction**: Unified interface with swappable drivers (Coming Soon)

### 🔧 Design Pattern Innovations
- **Unit of Work Manager**: Atomic transactions across services (Coming Soon)
- **Native Interceptor Pattern**: DI-aware AOP for cross-cutting concerns (Coming Soon)
- **Result Pattern**: Railway Oriented Programming for explicit error handling (Coming Soon)
- **Pipeline Pattern**: Chain of Responsibility for complex business flows (Coming Soon)
- **Strategy Resolver**: Polymorphic DI for runtime implementation selection (Coming Soon)

### 🌟 Advanced Capabilities
- **CQRS/Event Sourcing**: Command/query separation with event store (Coming Soon)
- **GraphQL Federation**: Native schema stitching and entity resolution (Coming Soon)
- **Health Monitoring**: RFC-compliant health checks with component monitoring (Coming Soon)
- **Async-First Architecture**: Non-blocking I/O throughout
- **Type-Safe Composition**: Protocol-based design with generic support

## 📦 Installation

```bash
pip install strata-framework
```

For development:
```bash
pip install strata-framework[dev]
```

## 🛠️ Development Commands

```bash
# Run the app
python -m uvicorn main:app --reload

# Run tests (when available)
pytest

# Format code (when available)
black .
isort .
```

## 📚 Documentation

- [Getting Started Guide](https://github.com/strata-framework/strata-framework)
- [API Reference](https://github.com/strata-framework/strata-framework)
- [Architecture Guide](https://github.com/strata-framework/strata-framework)
- [Migration from FastAPI](https://github.com/strata-framework/strata-framework)
- [Contributing Guidelines](CONTRIBUTING.md)

## 🔍 Why Strata?

### The FastAPI Problem
FastAPI is excellent for simple APIs but lacks architectural structure for large applications. Teams often hit a wall when:

- Multiple services need coordinated transactions
- Business logic becomes complex and intertwined
- Testing requires extensive mocking
- Architecture violations go undetected
- Observability is bolted on as an afterthought

### The Strata Solution
Strata provides **architectural discipline without sacrificing Python's flexibility**:

```python
# FastAPI: Manual transaction management
@app.post("/checkout")
async def checkout(db: Session = Depends(get_db)):
    try:
        # Manual session passing
        order = await order_service.create_order(db, ...)
        await inventory_service.deduct_stock(db, order.items)
        db.commit()
    except Exception:
        db.rollback()
        raise

# Strata: Automatic transaction management (Coming Soon)
# @app.post("/checkout")
# async def checkout(uow: UnitOfWork, order_srv: OrderService, inventory_srv: InventoryService):
#     async with uow:  # Automatic commit/rollback
#         order = await order_srv.create_order(...)
#         await inventory_srv.deduct_stock(order.items)
```

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

### Development Setup
```bash
git clone https://github.com/strata-framework/strata-framework.git
cd strata-framework
pip install -e .[dev]
```

### Running Tests
```bash
pytest
```

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

## 🙏 Acknowledgments

Inspired by:
- **NestJS**: For the provider pattern and modular architecture
- **Spring Boot**: For enterprise patterns and configuration management
- **ASP.NET Core**: For dependency injection and middleware pipeline
- **Starlette**: For the excellent ASGI foundation

Special thanks to the Python async community, FastAPI for pioneering async web frameworks, and NestJS for inspiring the provider pattern.

---

**Strata Framework** - The architecture framework Python deserves. 🚀