__version__ = '2.9.1'

if __name__ == '__main__':
    print(__version__)
