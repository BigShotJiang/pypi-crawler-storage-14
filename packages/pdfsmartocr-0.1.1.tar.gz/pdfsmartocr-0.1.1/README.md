# pdfsmartocr

Ferramenta de OCR híbrido para PDFs grandes:
- Até X páginas via Tesseract OCR paralelo
- Demais páginas via PdfReader nativo
- Feito para PDFs de processos judiciais

## Instalação
pip install pdfsmartocr

## Uso

```python
from pdfsmartocr import ocr_pdf

texto, tempo = ocr_pdf("arquivo.pdf", max_ocr_pages=70)
