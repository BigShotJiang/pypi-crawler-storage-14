from .logger import log_install, log_data, set_debug, get_installation_id

__version__ = "1.1.0"
__all__ = ["log_install", "log_data", "set_debug", "get_installation_id"]
