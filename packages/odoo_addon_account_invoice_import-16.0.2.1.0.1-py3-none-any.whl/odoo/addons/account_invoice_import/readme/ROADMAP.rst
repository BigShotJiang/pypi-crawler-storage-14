* Remove dependency on *base_iban* and develop a separate glue module between this module and *base_iban*
