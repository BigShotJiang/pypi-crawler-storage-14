from packages_KO.models import *
from pydantic import BaseModel
from fastapi import HTTPException

COMMENTS_DB : list[Comment] = []

def getAll_comments() -> list[Comment]:
    """
    Il ne prends pas de paramètres

    Returns:
        retourne tous les commentaires de ma base de données sous forme de liste
    """
    return COMMENTS_DB

def add_comment(comment : CommentData)->Comment:
    """

    Args:
        Prend en argument le commentaire à ajouter 

    Returns:
        Si le commentaire est ajouté avec succès il retourne le commentaire ajouté sinon il retourne une erreur 
    """
    comment_id = len(COMMENTS_DB) + 1
    COMMENTS_DB.append(Comment(
        commentId=comment_id,
        name= comment.name,
        email= comment.email,
        body= comment.body
    )) 
    return CommentData[comment_id]

def get_comment(comment_id : int) -> Comment:
    """_summary_

    Args:
        Prend en argument l'id du commentaire que l'on veut retourner

    Raises:
        génère une erreur si le commentaire n'est pas trouvé
    Returns:
        retourne le commentaire sil le trouve
    """
    for c in COMMENTS_DB : 
        if c.commentId == comment_id : 
            return c
    raise HTTPException(status_code=404, detail="Comment not found")

def update_comment(comment_id: int, updated: CommentData) -> Comment:
    for i,c in enumerate(COMMENTS_DB) :
        if c.commentId == comment_id :
            new = Comment(
                commentId= comment_id,
                name= updated.name,
                email= updated.email,
                body= updated.body
            )
            COMMENTS_DB[i] = new
            return new

def drop_comment(comment_id : int) -> None : 
    for i, c in enumerate(COMMENTS_DB):
        if c.id == comment_id:
            del COMMENTS_DB[i]
            return
    raise HTTPException(status_code=404, detail="Comment not found")

def bobo():
    return "COMMENTS_DB"