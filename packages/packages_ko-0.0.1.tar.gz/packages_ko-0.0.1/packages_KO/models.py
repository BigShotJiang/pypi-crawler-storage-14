from pydantic import BaseModel



class Company(BaseModel):
    name : str
    catchPhrase : str
    bs : str

class Geo(BaseModel):
    lat : str
    lng : str

class Adress(BaseModel):
    street : str
    suite : str
    city : str
    zipcode : str
    geo  : Geo

class User(BaseModel):
    userId : int
    name : str
    username : str
    email : str
    adress : Adress
    phone : str
    website : str

class Post(BaseModel):
    postId : int
    title : str
    body : str

class CommentData(BaseModel):
    name : str
    email : str
    body : str

class Comment(BaseModel):
    commentId : int
    name : str
    email : str
    body : str
    
class Album(BaseModel):
    albumId : int
    title : str

class Photo(BaseModel) : 
    photosId : int
    title : str
    url : str
    thumbnailUrl : str
    
class Todos(BaseModel):
    todosId : int
    title : str
    completed : str