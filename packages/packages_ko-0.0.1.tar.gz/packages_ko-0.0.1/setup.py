from setuptools import setup, find_packages

setup(
    author="Oumar KABA",
    description="API de l'url https://jsonplaceholder.typicode.com/",
    name= "packages_KO",
    version="0.0.1",
    packages=["packages_KO"]
)