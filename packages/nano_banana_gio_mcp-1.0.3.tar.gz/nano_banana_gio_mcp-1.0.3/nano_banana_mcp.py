#!/usr/bin/env python3
import os
import sys
import json
import base64
import re
import urllib.request
import urllib.parse
import ssl
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Union
from io import BytesIO
import asyncio

from mcp.server import Server
from mcp.types import Tool, TextContent
import mcp.server.stdio
from google import genai
from google.genai import types
from PIL import Image

# Configuration
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
IMGBB_API_KEY = "e60fdf3051783d12d3905740acd0c0fc"  # Clé API ImgBB intégrée

if not GEMINI_API_KEY:
    print("❌ Erreur : La variable GEMINI_API_KEY n'est pas définie", file=sys.stderr)
    sys.exit(1)

OUTPUT_DIR = Path.home() / "Downloads" / "nano-banana-outputs"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Initialiser le client Gemini
client = genai.Client(api_key=GEMINI_API_KEY)

# Créer le serveur MCP
server = Server("nano-banana-mcp")


def generate_filename(prefix: str = "generated") -> str:
    """Génère un nom de fichier unique avec timestamp"""
    timestamp = datetime.now().isoformat().replace(":", "-").replace(".", "-")
    return f"{prefix}_{timestamp}.png"


def upload_image_to_imgbb(image_source: str) -> str:
    """
    Upload une image vers ImgBB et retourne l'URL
    image_source peut être : chemin local, URL, ou base64
    """
    # Créer un contexte SSL qui ne vérifie pas les certificats
    ssl_context = ssl._create_unverified_context()
    
    # Préparer l'image en base64
    if image_source.startswith("http://") or image_source.startswith("https://"):
        # Télécharger l'image et la convertir en base64
        with urllib.request.urlopen(image_source, context=ssl_context) as response:
            image_data = response.read()
            img_base64 = base64.b64encode(image_data).decode('utf-8')
    elif image_source.startswith("data:image"):
        # Extraire le base64 du data URI
        img_base64 = image_source.split(",", 1)[1]
    elif re.match(r'^[A-Za-z0-9+/=]+$', image_source) and len(image_source) > 100:
        # C'est déjà du base64 pur
        img_base64 = image_source
    else:
        # C'est un chemin local, charger et convertir
        img = load_image_from_source(image_source)
        buffer = BytesIO()
        img.save(buffer, format='PNG')
        img_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    # Préparer la requête
    data = urllib.parse.urlencode({
        'key': IMGBB_API_KEY,
        'image': img_base64
    }).encode('utf-8')
    
    req = urllib.request.Request('https://api.imgbb.com/1/upload', data=data)
    
    try:
        with urllib.request.urlopen(req, context=ssl_context) as response:
            result = json.loads(response.read().decode('utf-8'))
            
            if result.get('success'):
                return result['data']['url']
            else:
                raise ValueError(f"Erreur lors de l'upload: {result.get('error', {}).get('message', 'Erreur inconnue')}")
    except Exception as e:
        raise ValueError(f"Impossible d'uploader l'image vers ImgBB: {str(e)}")


def load_image_from_source(source: str) -> Image.Image:
    """
    Charge une image depuis différentes sources :
    - Chemin de fichier local
    - URL (http:// ou https://)
    - Base64 (data:image/... ou juste le base64)
    """
    ssl_context = ssl._create_unverified_context()
    
    # Détection base64
    if source.startswith("data:image"):
        base64_data = source.split(",", 1)[1]
        image_data = base64.b64decode(base64_data)
        return Image.open(BytesIO(image_data))
    elif re.match(r'^[A-Za-z0-9+/=]+$', source) and len(source) > 100:
        try:
            image_data = base64.b64decode(source)
            return Image.open(BytesIO(image_data))
        except:
            pass
    
    # Détection URL
    if source.startswith("http://") or source.startswith("https://"):
        with urllib.request.urlopen(source, context=ssl_context) as response:
            image_data = response.read()
            return Image.open(BytesIO(image_data))
    
    # Sinon, c'est un chemin local
    return Image.open(source)


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Liste tous les outils disponibles"""
    return [
        Tool(
            name="upload_image_to_host",
            description="Upload une image vers ImgBB et retourne une URL publique. "
                       "Cet outil est utilisé automatiquement par Claude lorsque l'utilisateur uploade des images "
                       "dans la conversation et souhaite les utiliser avec Nano Banana. "
                       "L'image peut être un chemin local, une URL, ou du base64.",
            inputSchema={
                "type": "object",
                "properties": {
                    "image_source": {
                        "type": "string",
                        "description": "Chemin local, URL, ou base64 de l'image à uploader",
                    },
                },
                "required": ["image_source"],
            },
        ),
        Tool(
            name="generate_image",
            description="Génère une image avec Nano Banana Pro (Gemini 3 Pro Image). "
                       "Supporte les ratios personnalisés, résolutions jusqu'à 4K, "
                       "et le grounding avec Google Search. "
                       "\n\nIMPORTANT pour Claude : Si l'utilisateur a uploadé des images dans la conversation "
                       "et souhaite les utiliser, vous devez d'abord : "
                       "1. Lire l'image uploadée et la convertir en base64 "
                       "2. Utiliser l'outil 'upload_image_to_host' pour obtenir une URL publique "
                       "3. Utiliser cette URL avec generate_image_with_references",
            inputSchema={
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "Description détaillée de l'image à générer",
                    },
                    "model": {
                        "type": "string",
                        "enum": ["flash", "pro"],
                        "default": "pro",
                        "description": 'Modèle à utiliser : "flash" (rapide, 1K) ou "pro" (avancé, jusqu\'à 4K)',
                    },
                    "aspect_ratio": {
                        "type": "string",
                        "enum": ["1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"],
                        "default": "1:1",
                        "description": "Ratio d'aspect de l'image",
                    },
                    "image_size": {
                        "type": "string",
                        "enum": ["1K", "2K", "4K"],
                        "default": "2K",
                        "description": 'Résolution de l\'image (uniquement pour le modèle "pro")',
                    },
                    "use_grounding": {
                        "type": "boolean",
                        "default": False,
                        "description": "Activer le grounding avec Google Search pour des informations en temps réel",
                    },
                },
                "required": ["prompt"],
            },
        ),
        Tool(
            name="generate_image_with_references",
            description="Génère une image en utilisant des images de référence. "
                       "Le modèle Pro supporte jusqu'à 14 images (6 objets + 5 personnages). "
                       "Les images DOIVENT être des URLs publiques ou des chemins locaux. "
                       "\n\nIMPORTANT pour Claude : Si l'utilisateur a uploadé des images dans la conversation, "
                       "vous devez OBLIGATOIREMENT : "
                       "1. Lire chaque image uploadée et la convertir en base64 "
                       "2. Utiliser l'outil 'upload_image_to_host' pour CHAQUE image pour obtenir des URLs publiques "
                       "3. Utiliser ces URLs dans le paramètre reference_images "
                       "\nNe tentez JAMAIS de passer directement des chemins comme /mnt/user-data/uploads/... "
                       "car le MCP ne peut pas y accéder.",
            inputSchema={
                "type": "object",
                "properties": {
                    "prompt": {
                        "type": "string",
                        "description": "Description de l'image à générer",
                    },
                    "reference_images": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "URLs publiques ou chemins locaux des images de référence. Max 14 pour Pro, 3 pour Flash",
                    },
                    "model": {
                        "type": "string",
                        "enum": ["flash", "pro"],
                        "default": "pro",
                        "description": "Modèle à utiliser",
                    },
                    "aspect_ratio": {
                        "type": "string",
                        "enum": ["1:1", "2:3", "3:2", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"],
                        "default": "1:1",
                        "description": "Ratio d'aspect",
                    },
                    "image_size": {
                        "type": "string",
                        "enum": ["1K", "2K", "4K"],
                        "default": "2K",
                        "description": "Résolution (Pro uniquement)",
                    },
                },
                "required": ["prompt", "reference_images"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Gère les appels d'outils"""
    try:
        if name == "upload_image_to_host":
            return await upload_image_tool(arguments)
        elif name == "generate_image":
            return await generate_image(arguments)
        elif name == "generate_image_with_references":
            return await generate_image_with_references(arguments)
        else:
            raise ValueError(f"Outil inconnu : {name}")
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        return [TextContent(type="text", text=f"❌ Erreur : {str(e)}\n\nDétails:\n{error_details}")]


async def upload_image_tool(args: dict) -> list[TextContent]:
    """Upload une image vers ImgBB"""
    image_source = args["image_source"]
    
    try:
        url = upload_image_to_imgbb(image_source)
        return [TextContent(
            type="text",
            text=f"✅ Image uploadée avec succès !\n\n🔗 URL : {url}\n\nVous pouvez maintenant utiliser cette URL avec generate_image_with_references."
        )]
    except Exception as e:
        return [TextContent(
            type="text",
            text=f"❌ Erreur lors de l'upload : {str(e)}"
        )]


async def generate_image(args: dict) -> list[TextContent]:
    """Génère une image simple"""
    prompt = args["prompt"]
    model_type = args.get("model", "pro")
    aspect_ratio = args.get("aspect_ratio", "1:1")
    image_size = args.get("image_size", "2K")
    use_grounding = args.get("use_grounding", False)

    model_name = "gemini-2.5-flash-image" if model_type == "flash" else "gemini-3-pro-image-preview"

    config_params = {
        "response_modalities": ["TEXT", "IMAGE"],
        "image_config": types.ImageConfig(aspect_ratio=aspect_ratio),
    }

    if model_type != "flash":
        config_params["image_config"] = types.ImageConfig(
            aspect_ratio=aspect_ratio,
            image_size=image_size
        )

    if use_grounding:
        config_params["tools"] = [{"google_search": {}}]

    config = types.GenerateContentConfig(**config_params)

    response = client.models.generate_content(
        model=model_name,
        contents=[prompt],
        config=config
    )

    image_data = None
    text_response = ""

    for part in response.parts:
        if part.text is not None:
            text_response = part.text
        elif part.inline_data is not None:
            image = part.as_image()
            filename = generate_filename("nano-banana")
            filepath = OUTPUT_DIR / filename
            image.save(str(filepath))
            image_data = str(filepath)

    if not image_data:
        raise Exception("Aucune image générée dans la réponse")

    result = f"""✅ Image générée avec succès !

📁 Fichier : {image_data}
📐 Ratio : {aspect_ratio}
🎨 Modèle : {model_name}
"""

    if text_response:
        result += f"\n💬 Commentaire : {text_response}"

    return [TextContent(type="text", text=result)]


async def generate_image_with_references(args: dict) -> list[TextContent]:
    """Génère une image avec des images de référence"""
    prompt = args["prompt"]
    reference_images = args["reference_images"]
    model_type = args.get("model", "pro")
    aspect_ratio = args.get("aspect_ratio", "1:1")
    image_size = args.get("image_size", "2K")

    max_images = 3 if model_type == "flash" else 14
    if len(reference_images) > max_images:
        raise ValueError(f"Le modèle {model_type} supporte maximum {max_images} images de référence")

    model_name = "gemini-2.5-flash-image" if model_type == "flash" else "gemini-3-pro-image-preview"

    loaded_images = []
    for i, img_source in enumerate(reference_images):
        try:
            img = load_image_from_source(img_source)
            loaded_images.append(img)
            print(f"✓ Image {i+1}/{len(reference_images)} chargée", file=sys.stderr)
        except Exception as e:
            raise ValueError(f"Impossible de charger l'image {i+1} ({img_source[:50]}...): {str(e)}")

    contents = [prompt] + loaded_images

    config_params = {
        "response_modalities": ["TEXT", "IMAGE"],
        "image_config": types.ImageConfig(aspect_ratio=aspect_ratio),
    }

    if model_type != "flash":
        config_params["image_config"] = types.ImageConfig(
            aspect_ratio=aspect_ratio,
            image_size=image_size
        )

    config = types.GenerateContentConfig(**config_params)

    response = client.models.generate_content(
        model=model_name,
        contents=contents,
        config=config
    )

    image_data = None
    text_response = ""

    for part in response.parts:
        if part.text is not None:
            text_response = part.text
        elif part.inline_data is not None:
            image = part.as_image()
            filename = generate_filename("nano-banana-ref")
            filepath = OUTPUT_DIR / filename
            image.save(str(filepath))
            image_data = str(filepath)

    if not image_data:
        raise Exception("Aucune image générée dans la réponse")

    result = f"""✅ Image générée avec {len(reference_images)} référence(s) !

📁 Fichier : {image_data}
📐 Ratio : {aspect_ratio}
🎨 Modèle : {model_name}
"""

    if text_response:
        result += f"\n💬 Commentaire : {text_response}"

    return [TextContent(type="text", text=result)]


async def main():
    """Point d'entrée principal"""
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        print("🎨 Nano Banana MCP Server démarré !", file=sys.stderr)
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


def run():
    """Point d'entrée pour le package"""
    asyncio.run(main())

if __name__ == "__main__":
    run()