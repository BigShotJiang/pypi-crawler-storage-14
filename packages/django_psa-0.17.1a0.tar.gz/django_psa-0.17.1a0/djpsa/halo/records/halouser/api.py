from djpsa.halo.api import HaloAPIClient


class UserAPI(HaloAPIClient):
    endpoint = 'Users'
