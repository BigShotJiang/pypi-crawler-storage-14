from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class SmtpPreset:
    host: str
    port: int
    ssl: bool

SMTP_PRESETS = {
    "gmail":   SmtpPreset("smtp.gmail.com",      587, False),
    "outlook": SmtpPreset("smtp.office365.com",  587, False),
    "hotmail": SmtpPreset("smtp.office365.com",  587, False),
    "live":    SmtpPreset("smtp.office365.com",  587, False),
    "yahoo":   SmtpPreset("smtp.mail.yahoo.com", 465, True),
    "icloud":  SmtpPreset("smtp.mail.me.com",    587, False),
    "zoho":    SmtpPreset("smtp.zoho.com",       465, True),
}

def coerce_ssl_by_port(port: int, requested_ssl: bool) -> bool:
    if port == 587: return False
    if port == 465: return True
    return requested_ssl
