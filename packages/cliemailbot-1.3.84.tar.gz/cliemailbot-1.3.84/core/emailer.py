from __future__ import annotations
import ssl
import smtplib
import socket
from email.message import EmailMessage
from typing import List, Optional, Tuple
import re
from .smtp_presets import SMTP_PRESETS, coerce_ssl_by_port

_EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

def valid_email(addr: str) -> bool:
    return bool(_EMAIL_REGEX.match(addr or ""))

def parse_addresses(raw: Optional[str]) -> List[str]:
    if not raw:
        return []
    addrs = [a.strip() for a in raw.split(",") if a.strip()]
    return [a for a in addrs if valid_email(a)]

def build_message(
    sender: str,
    recipients: List[str],
    subject: str,
    body: str,
    cc_addrs: Optional[List[str]] = None,
) -> EmailMessage:
    if not valid_email(sender):
        raise ValueError("Invalid sender email.")
    if not recipients:
        raise ValueError("Recipients list cannot be empty.")
    msg = EmailMessage()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    if cc_addrs:
        msg["Cc"] = ", ".join(cc_addrs)
    msg["Subject"] = subject
    msg.set_content(body)
    return msg

def _tls_context() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    try:
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    except Exception:
        pass
    return ctx

def connectivity_ok(host: str, port: int, timeout: int = 10) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False

def send_email(
    host: str,
    port: int,
    use_ssl: bool,
    username: str,
    password: str,
    msg: EmailMessage,
    bcc_addrs: Optional[List[str]] = None,
    debug: bool = False,
    timeout: int = 30,
) -> None:
    bcc_addrs = bcc_addrs or []
    to_addrs = parse_addresses(msg.get("To", "")) + parse_addresses(msg.get("Cc", ""))
    to_addrs += bcc_addrs
    if not to_addrs:
        raise ValueError("No valid recipients to send to.")

    use_ssl = coerce_ssl_by_port(port, use_ssl)
    ctx = _tls_context()

    if use_ssl:
        with smtplib.SMTP_SSL(host, port, context=ctx, timeout=timeout) as server:
            if debug: server.set_debuglevel(1)
            server.login(username, password)
            server.send_message(msg, from_addr=username, to_addrs=to_addrs)
    else:
        with smtplib.SMTP(host, port, timeout=timeout) as server:
            if debug: server.set_debuglevel(1)
            server.ehlo()
            server.starttls(context=ctx)
            server.ehlo()
            server.login(username, password)
            server.send_message(msg, from_addr=username, to_addrs=to_addrs)

def send_via_preset(
    provider: str,
    sender_email: str,
    app_password: str,
    to_addrs: List[str],
    subject: str,
    body: str,
    cc_addrs: Optional[List[str]] = None,
    bcc_addrs: Optional[List[str]] = None,
    debug: bool = False,
) -> Tuple[bool, str]:
    preset = SMTP_PRESETS.get(provider.lower())
    if not preset:
        return False, f"Unknown provider: {provider}"
    if not connectivity_ok(preset.host, preset.port):
        return False, f"Cannot connect to {preset.host}:{preset.port}"

    try:
        msg = build_message(sender_email, to_addrs, subject, body, cc_addrs)
        send_email(
            host=preset.host,
            port=preset.port,
            use_ssl=preset.ssl,
            username=sender_email,
            password=app_password,
            msg=msg,
            bcc_addrs=bcc_addrs,
            debug=debug,
        )
        return True, "Email sent successfully."
    except smtplib.SMTPAuthenticationError as e:
        return False, f"Auth failed: {e}"
    except smtplib.SMTPRecipientsRefused as e:
        return False, f"Recipients refused: {e}"
    except smtplib.SMTPConnectError as e:
        return False, f"SMTP connect error: {e}"
    except smtplib.SMTPException as e:
        return False, f"SMTP error: {e}"
    except OSError as e:
        return False, f"Network/OS error: {e}"
    except Exception as e:
        return False, f"Unexpected error: {e}"
