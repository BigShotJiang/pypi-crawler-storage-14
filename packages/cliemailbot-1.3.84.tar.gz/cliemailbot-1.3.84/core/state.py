from __future__ import annotations
from dataclasses import dataclass, field
from threading import RLock, Event
from typing import Dict, List, Set, Optional, Literal, Tuple
import time

@dataclass
class MailState:
    subject: str = ""
    body: str = ""
    speed_sec: int = 1
    provider: str = "gmail"
    to: Set[str] = field(default_factory=set)
    cc: Set[str] = field(default_factory=set)
    bcc: Set[str] = field(default_factory=set)

@dataclass
class RunMetrics:
    total_sent: int = 0
    total_failed: int = 0
    total_errors: int = 0
    boot_time: float = field(default_factory=time.time)
    last_run_start: Optional[float] = None
    last_run_end: Optional[float] = None
    last_run_sent: int = 0
    last_run_failed: int = 0
    last_run_errors: int = 0

AddGmailState = Literal[
    "IDLE",
    "SELECT_PROVIDER",
    "WAIT_EMAIL",
    "WAIT_APP_PASSWORD",
    "READY"
]

ReceiverMode = Literal["one", "many"]
ReceiverState = Literal[
    "IDLE",
    "ASK_COUNT",
    "WAIT_ONE",
    "WAIT_MANY",
    "READY"
]

SimpleInputState = Literal[
    "IDLE",
    "WAIT_SUBJECT",
    "WAIT_BODY",
    "WAIT_SPEED"
]

@dataclass
class ChatFlow:
    addgmail_state: AddGmailState = "IDLE"
    chosen_provider: Optional[str] = None
    temp_email: Optional[str] = None
    temp_app_password: Optional[str] = None
    receiver_state: ReceiverState = "IDLE"
    receiver_mode: Optional[ReceiverMode] = None
    receiver_payload: Optional[List[str]] = None
    simple_state: SimpleInputState = "IDLE"
    created_at: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)

_LOCK = RLock()
_STATE = MailState()
_METRICS = RunMetrics()
_STOP_EVENT = Event()
_SENDING_FLAG = False
_CHAT: Dict[int, ChatFlow] = {}

def set_provider(name: str) -> None:
    with _LOCK:
        _STATE.provider = (name or "gmail").strip().lower()

def get_provider() -> str:
    with _LOCK:
        return _STATE.provider

def set_speed(seconds: int) -> None:
    if seconds < 0:
        seconds = 0
    with _LOCK:
        _STATE.speed_sec = seconds

def get_speed() -> int:
    with _LOCK:
        return _STATE.speed_sec

def set_subject(text: str) -> None:
    with _LOCK:
        _STATE.subject = (text or "").strip()

def set_body(text: str) -> None:
    with _LOCK:
        _STATE.body = (text or "")

def clear_text() -> None:
    with _LOCK:
        _STATE.subject = ""
        _STATE.body = ""

def add_to(items: List[str]) -> int:
    with _LOCK:
        before = len(_STATE.to)
        _STATE.to.update([i.strip() for i in items if i and i.strip()])
        return len(_STATE.to) - before

def remove_to(items: List[str]) -> int:
    with _LOCK:
        removed = 0
        for it in items:
            it = (it or "").strip()
            if it and it in _STATE.to:
                _STATE.to.remove(it)
                removed += 1
        return removed

def add_cc(items: List[str]) -> int:
    with _LOCK:
        before = len(_STATE.cc)
        _STATE.cc.update([i.strip() for i in items if i and i.strip()])
        return len(_STATE.cc) - before

def remove_cc(items: List[str]) -> int:
    with _LOCK:
        removed = 0
        for it in items:
            it = (it or "").strip()
            if it and it in _STATE.cc:
                _STATE.cc.remove(it)
                removed += 1
        return removed

def add_bcc(items: List[str]) -> int:
    with _LOCK:
        before = len(_STATE.bcc)
        _STATE.bcc.update([i.strip() for i in items if i and i.strip()])
        return len(_STATE.bcc) - before

def remove_bcc(items: List[str]) -> int:
    with _LOCK:
        removed = 0
        for it in items:
            it = (it or "").strip()
            if it and it in _STATE.bcc:
                _STATE.bcc.remove(it)
                removed += 1
        return removed

def get_lists() -> Tuple[List[str], List[str], List[str]]:
    with _LOCK:
        return list(_STATE.to), list(_STATE.cc), list(_STATE.bcc)

def start_run() -> None:
    with _LOCK:
        _METRICS.last_run_start = time.time()
        _METRICS.last_run_end = None
        _METRICS.last_run_sent = 0
        _METRICS.last_run_failed = 0
        _METRICS.last_run_errors = 0
        global _SENDING_FLAG
        _SENDING_FLAG = True
        _STOP_EVENT.clear()

def end_run() -> None:
    with _LOCK:
        _METRICS.last_run_end = time.time()
        global _SENDING_FLAG
        _SENDING_FLAG = False
        _STOP_EVENT.clear()

def mark_sending(on: bool) -> None:
    with _LOCK:
        global _SENDING_FLAG
        _SENDING_FLAG = on
        if not on:
            _STOP_EVENT.clear()

def request_stop() -> None:
    _STOP_EVENT.set()

def stopped() -> bool:
    return _STOP_EVENT.is_set()

def is_sending() -> bool:
    with _LOCK:
        return _SENDING_FLAG and not _STOP_EVENT.is_set()

def note_result(result: Literal["sent", "failed", "error"]) -> None:
    with _LOCK:
        if result == "sent":
            _METRICS.last_run_sent += 1
            _METRICS.total_sent += 1
        elif result == "failed":
            _METRICS.last_run_failed += 1
            _METRICS.total_failed += 1
        elif result == "error":
            _METRICS.last_run_errors += 1
            _METRICS.total_errors += 1

def uptime_seconds() -> int:
    with _LOCK:
        return int(time.time() - _METRICS.boot_time)

def snapshot(accounts_count: Optional[int] = None) -> Dict[str, object]:
    with _LOCK:
        run_dur = None
        if _METRICS.last_run_start is not None:
            end_t = _METRICS.last_run_end or time.time()
            run_dur = int(end_t - _METRICS.last_run_start)

        return {
            "provider": _STATE.provider,
            "speed_sec": _STATE.speed_sec,
            "subject": _STATE.subject,
            "body_preview": _STATE.body[:300] + ("…" if len(_STATE.body) > 300 else ""),
            "to_count": len(_STATE.to),
            "cc_count": len(_STATE.cc),
            "bcc_count": len(_STATE.bcc),
            "to": sorted(_STATE.to),
            "cc": sorted(_STATE.cc),
            "bcc": sorted(_STATE.bcc),
            "accounts_count": accounts_count,
            "is_sending": _SENDING_FLAG and not _STOP_EVENT.is_set(),
            "last_run_start": _METRICS.last_run_start,
            "last_run_end": _METRICS.last_run_end,
            "last_run_duration_sec": run_dur,
            "last_run_sent": _METRICS.last_run_sent,
            "last_run_failed": _METRICS.last_run_failed,
            "last_run_errors": _METRICS.last_run_errors,
            "total_sent": _METRICS.total_sent,
            "total_failed": _METRICS.total_failed,
            "total_errors": _METRICS.total_errors,
            "uptime_sec": uptime_seconds(),
        }

def _get_chat(chat_id: int) -> ChatFlow:
    with _LOCK:
        flow = _CHAT.get(chat_id)
        if not flow:
            flow = ChatFlow()
            _CHAT[chat_id] = flow
        flow.last_activity = time.time()
        return flow

def begin_add_gmail(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.addgmail_state = "SELECT_PROVIDER"
        flow.chosen_provider = None
        flow.temp_email = None
        flow.temp_app_password = None

def set_addgmail_provider(chat_id: int, provider: str) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.chosen_provider = (provider or "").lower().strip()
        flow.addgmail_state = "WAIT_EMAIL"

def set_addgmail_email(chat_id: int, email: str) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.temp_email = (email or "").strip()
        flow.addgmail_state = "WAIT_APP_PASSWORD"

def set_addgmail_app_password(chat_id: int, app_password: str) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.temp_app_password = (app_password or "").strip()
        flow.addgmail_state = "READY"

def peek_addgmail_payload(chat_id: int) -> Optional[Dict[str, str]]:
    flow = _get_chat(chat_id)
    with _LOCK:
        if flow.addgmail_state != "READY":
            return None
        return {
            "provider": flow.chosen_provider or "",
            "email": flow.temp_email or "",
            "app_password": flow.temp_app_password or "",
        }

def finalize_addgmail(chat_id: int) -> Optional[Dict[str, str]]:
    flow = _get_chat(chat_id)
    with _LOCK:
        if flow.addgmail_state != "READY":
            return None
        data = {
            "provider": flow.chosen_provider or "",
            "email": flow.temp_email or "",
            "app_password": flow.temp_app_password or "",
        }
        flow.addgmail_state = "IDLE"
        flow.chosen_provider = None
        flow.temp_email = None
        flow.temp_app_password = None
        return data

def cancel_addgmail(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.addgmail_state = "IDLE"
        flow.chosen_provider = None
        flow.temp_email = None
        flow.temp_app_password = None

def get_addgmail_state(chat_id: int) -> AddGmailState:
    return _get_chat(chat_id).addgmail_state

def begin_add_receivers(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.receiver_state = "ASK_COUNT"
        flow.receiver_mode = None
        flow.receiver_payload = None

def set_receivers_mode(chat_id: int, mode: ReceiverMode) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.receiver_mode = mode
        flow.receiver_state = "WAIT_ONE" if mode == "one" else "WAIT_MANY"

def set_receiver_one(chat_id: int, email: str) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.receiver_payload = [ (email or "").strip() ] if email else []
        flow.receiver_state = "READY"

def set_receiver_many(chat_id: int, raw: str) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        items = [x.strip() for x in (raw or "").split(",") if x.strip()]
        flow.receiver_payload = items
        flow.receiver_state = "READY"

def pop_receivers_ready(chat_id: int) -> Optional[List[str]]:
    flow = _get_chat(chat_id)
    with _LOCK:
        if flow.receiver_state != "READY":
            return None
        out = list(flow.receiver_payload or [])
        flow.receiver_state = "IDLE"
        flow.receiver_mode = None
        flow.receiver_payload = None
        return out

def cancel_add_receivers(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.receiver_state = "IDLE"
        flow.receiver_mode = None
        flow.receiver_payload = None

def get_receivers_state(chat_id: int) -> ReceiverState:
    return _get_chat(chat_id).receiver_state

def begin_wait_subject(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.simple_state = "WAIT_SUBJECT"

def begin_wait_body(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.simple_state = "WAIT_BODY"

def begin_wait_speed(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.simple_state = "WAIT_SPEED"

def consume_simple_input(chat_id: int, text: str) -> Optional[Literal["SUBJECT_SET","BODY_SET","SPEED_SET"]]:
    flow = _get_chat(chat_id)
    with _LOCK:
        st = flow.simple_state
        if st == "WAIT_SUBJECT":
            _STATE.subject = (text or "").strip()
            flow.simple_state = "IDLE"
            return "SUBJECT_SET"
        elif st == "WAIT_BODY":
            _STATE.body = (text or "")
            flow.simple_state = "IDLE"
            return "BODY_SET"
        elif st == "WAIT_SPEED":
            try:
                val = int((text or "0").strip())
                if val < 0: val = 0
            except Exception:
                val = 0
            _STATE.speed_sec = val
            flow.simple_state = "IDLE"
            return "SPEED_SET"
        else:
            return None

def cancel_simple(chat_id: int) -> None:
    flow = _get_chat(chat_id)
    with _LOCK:
        flow.simple_state = "IDLE"

def get_simple_state(chat_id: int) -> SimpleInputState:
    return _get_chat(chat_id).simple_state
