# pymediawikidocker API Documentation

::: mwdocker
    options:
      show_submodules: true
