# Codebase

TODO information about how the codebase is structured

```
├── cace
│   ├── cace_cli.py
│   ├── cace_gui.py
│   ├── common
│   ├── doc
│   ├── gui
│   ├── __init__.py
│   ├── __main__.py
│   └── __version__.py
```
