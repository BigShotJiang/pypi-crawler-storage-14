# Coding Style

As coding style for the whole codebase of CACE, ["blue"](https://github.com/grantjenks/blue) is used. It is based on ["black"](https://github.com/psf/black) and allows us to automatically lint and format the whole codebase. Before you push new code, please format the codebase using "blue".
