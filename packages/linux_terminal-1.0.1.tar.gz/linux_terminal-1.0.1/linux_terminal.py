import os

pwd = os.getcwd()

def cat(filename):
    stdout = []
    for line in open(filename):
        stdout.append(line)
    return "".join(stdout) 

def esc():
    exit()

def main():
    print("Linux Terminal Simulator Starting...")
    # start your CLI loop here
    while True:
        cmd = input(f"[WinPath:{pwd}]\nlearner@simulator:~$ ").strip()
        print("You typed:", cmd)
        if cmd.startswith('cat'):
            args = cmd.split(" ")
            if len(args) > 1:
                output = cat(args[1])
                print(output+"\n")
        elif cmd == "exit":
            esc()

if __name__ == '__main__':
    main()
