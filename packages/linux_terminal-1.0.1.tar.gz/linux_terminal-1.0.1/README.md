A trial-version Linux terminal simulator for learning Linux commands on Windows.

Bug Fixed - CLI printed multiple times, fixed it
