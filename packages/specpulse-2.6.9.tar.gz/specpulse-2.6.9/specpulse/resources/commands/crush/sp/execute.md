---
name: SpecPulse: Execute Tasks
description: Execute tasks continuously using SpecPulse SDD methodology
category: SpecPulse
tags: [specpulse, execution, development, implementation]
---

<!-- SPECPULSE:START -->
**Guardrails**
- CLI-first approach: Always try SpecPulse CLI commands before file operations
- Keep changes tightly scoped to the continuous task execution outcome
- Only edit files in specs/, plans/, tasks/, memory/ directories - NEVER modify templates/ or internal config

**Critical Rules**
- **PRIMARY**: Use `specpulse task execute` when available
- **FALLBACK**: File Operations only if CLI fails
- **PROTECTED DIRECTORIES**: templates/, .specpulse/, specpulse/, .claude/, .gemini/, .windsurf/, .cursor/, .github/, .opencode/, .crush/
- **EDITABLE ONLY**: specs/, plans/, tasks/, memory/

**Steps**
Track these steps as TODOs and complete them one by one.

1. **Parse arguments** to extract execution parameters
2. **Determine current context**:
   - Read: memory/context.md
   - Extract current.feature, current.feature_id, and current.task if available
3. **Try CLI first**:
   - Run `specpulse task execute [task-id]`
   - If this succeeds, monitor execution progress
4. **If CLI doesn't exist, use File Operations**:
   - **Step 1: Read task breakdown**
     - Read: tasks/current-feature_id/tasks-*.md
     - Extract task list and dependencies
5. **Continuous execution strategy**:
   - Execute tasks in dependency order
   - For each task:
     1. **Task Preparation**
        - Read task requirements and acceptance criteria
        - Prepare development environment
        - Check dependencies and prerequisites
     2. **Task Execution**
        - Implement task requirements
        - Create code, tests, and documentation
        - Follow coding standards and best practices
     3. **Task Validation**
        - Run tests and validation checks
        - Verify acceptance criteria met
        - Update progress and status
     4. **Task Completion**
        - Update memory/context.md with progress
        - Mark task as completed
        - Move to next task

6. **Progress tracking**:
   - Monitor task completion and progress
   - Handle errors and rollback when needed
   - Update context with current status
   - Generate progress reports

**Reference**
- Use `specpulse task execute --help` for additional CLI options
- Check task breakdown files for task details
- Use `status` to monitor execution progress
- Run `specpulse doctor` if you encounter system issues
<!-- SPECPULSE:END -->