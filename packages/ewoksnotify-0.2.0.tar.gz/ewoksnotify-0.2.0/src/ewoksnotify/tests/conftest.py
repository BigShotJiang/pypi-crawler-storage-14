from ewoksorange.tests.conftest import qtapp  # noqa F811
