window.addEventListener("DOMContentLoaded", () => {
    document.documentElement.classList.remove("dark");
    document.querySelector('[aria-label="Color theme switcher"]').style.display = "none";
});