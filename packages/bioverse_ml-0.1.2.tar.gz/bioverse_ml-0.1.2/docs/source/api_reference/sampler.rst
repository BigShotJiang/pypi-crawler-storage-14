Sampler
=======