Utilities
=========