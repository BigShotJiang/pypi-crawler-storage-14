Adapters
========

.. currentmodule:: bioverse.adapters

.. autosummary::
    :nosignatures:

    {% for cls in bioverse.adapters.classes %}
      {{ cls }}
    {% endfor %}


.. automodule:: bioverse.adapters
   :members:
   :show-inheritance:
