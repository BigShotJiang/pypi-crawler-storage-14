Frameworks
==========

.. automodule:: bioverse.frameworks.pyg
   :members: PygFramework, PygData

