from ..transform import Transform


class Identity(Transform):
    pass
