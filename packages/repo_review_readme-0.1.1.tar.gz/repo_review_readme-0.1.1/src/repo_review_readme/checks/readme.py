from importlib.abc import Traversable
from pathlib import Path


class Readme:
    family = "readme"


class RM001(Readme):
    """Readme exists and is not empty"""

    @staticmethod
    def check(root: Path) -> bool | str:
        readme = root / "README.md"
        if not readme.exists():
            return False
        if readme.stat().st_size > 0:
            return True
        return "README is empty"


class RM002(Readme):
    "Description should be set"

    @staticmethod
    def check(pyproject: dict) -> bool | str:
        match pyproject:
            case {"project": {"description": "Add your description here"}}:
                return "Project description not set"
        return True


class RM003(Readme):
    "Changelog file should exist"

    @staticmethod
    def check(package: Traversable) -> bool:
        "Projects must have a changelog"
        spellings = ("CHANGELOG", "NEWS")
        return any(
            p.name.startswith(spelling)
            for p in package.iterdir()
            for spelling in spellings
        )


def repo_review_checks() -> dict[str, Readme]:
    return {p.__name__: p() for p in Readme.__subclasses__()}
