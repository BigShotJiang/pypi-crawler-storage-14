from setuptools import setup, find_packages
import os

# Read README.md for long description
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

setup(
    name='sangreal_calendar',
    version='0.1.4',
    description='Trade day handling utilities for A-share market',
    long_description=read_readme(),
    long_description_content_type='text/markdown',
    author='liubola',
    author_email='lby3523@gmail.com',
    maintainer='liubola',
    maintainer_email='lby3523@gmail.com',
    url='https://github.com/liubola/sangreal-calendar',
    project_urls={
        'Bug Reports': 'https://github.com/liubola/sangreal-calendar/issues',
        'Source': 'https://github.com/liubola/sangreal-calendar',
    },
    license='GPL-3.0-or-later',
    packages=find_packages(exclude=['tests', 'tests.*']),
    python_requires='>=3.7',
    install_requires=[
        'pandas>=1.0.0',
    ],
    extras_require={
        'dev': [
            'pytest>=6.0',
            'pytest-cov',
            'black',
            'flake8',
        ],
    },
    keywords=[
        'trading',
        'calendar',
        'financial',
        'stock-market',
        'china',
        'a-share',
        'trade-dates',
    ],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Financial and Insurance Industry',
        'License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3 :: Only',
        'Topic :: Office/Business :: Financial',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Office/Business :: Financial :: Investment',
    ],
    zip_safe=False,
)
