"""
Tests for CLI functionality
"""
