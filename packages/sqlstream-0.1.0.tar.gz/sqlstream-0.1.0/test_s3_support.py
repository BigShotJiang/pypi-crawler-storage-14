"""
Test script for S3 Support

Verifies that readers correctly handle S3 paths and attempt to use s3fs.
Mocks s3fs to avoid actual network calls.
"""

import sys
import unittest
from unittest.mock import MagicMock, patch
from pathlib import Path

# Mock s3fs before importing readers
sys.modules["s3fs"] = MagicMock()

from sqlstream.readers.csv_reader import CSVReader
from sqlstream.readers.parquet_reader import ParquetReader

class TestS3Support(unittest.TestCase):
    def setUp(self):
        # Reset mock
        sys.modules["s3fs"].reset_mock()
        self.mock_fs = MagicMock()
        sys.modules["s3fs"].S3FileSystem.return_value = self.mock_fs

    def test_csv_reader_s3_init(self):
        """Test CSVReader initialization with S3 path"""
        path = "s3://bucket/data.csv"
        reader = CSVReader(path)
        
        self.assertTrue(reader.is_s3)
        self.assertEqual(reader.path_str, path)
        self.assertIsNone(reader.path) # Should be None for S3

    def test_csv_reader_s3_read(self):
        """Test CSVReader reading from S3"""
        path = "s3://bucket/data.csv"
        reader = CSVReader(path)
        
        # Mock file handle
        mock_file = MagicMock()
        self.mock_fs.open.return_value = mock_file
        mock_file.__enter__.return_value = ["name,age", "Alice,30"]
        
        # Trigger read (get_schema uses _get_file_handle)
        try:
            reader.get_schema()
        except Exception:
            pass # Ignore parsing errors, we just want to check the call
            
        # Verify s3fs usage
        sys.modules["s3fs"].S3FileSystem.assert_called_with(anon=False)
        self.mock_fs.open.assert_called_with(path, mode="r", encoding="utf-8")

    def test_parquet_reader_s3_init(self):
        """Test ParquetReader initialization with S3 path"""
        path = "s3://bucket/data.parquet"
        
        # Mock pyarrow.parquet.ParquetFile
        with patch("pyarrow.parquet.ParquetFile") as mock_pq:
            reader = ParquetReader(path)
            
            self.assertTrue(reader.is_s3)
            
            # Verify s3fs usage
            sys.modules["s3fs"].S3FileSystem.assert_called_with(anon=False)
            
            # Verify ParquetFile called with correct args
            # Path should be stripped of protocol
            expected_path = "bucket/data.parquet"
            mock_pq.assert_called_with(expected_path, filesystem=self.mock_fs)

if __name__ == "__main__":
    unittest.main()
