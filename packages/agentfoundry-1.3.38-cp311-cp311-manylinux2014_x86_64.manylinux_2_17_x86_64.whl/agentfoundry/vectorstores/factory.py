"""VectorStoreFactory – central point to obtain vector-store instances."""

from __future__ import annotations

import logging
import threading

from agentfoundry.utils.config import Config

# The registry was previously kept in providers.__init__; it now lives directly
# inside this Factory class for a single authoritative source of truth.

logger = logging.getLogger(__name__)


class VectorStoreFactory:
    """Return a LangChain VectorStore instance from the configured provider."""

    # --------------------------------------------------------------
    # Provider registry helpers (moved from providers.__init__)
    # --------------------------------------------------------------

    _REGISTRY: dict[str, type] = {}
    _CACHE: dict[str, object] = {}
    _LOCK = threading.Lock()

    @classmethod
    def register_provider(cls, name: str):
        """Decorator to register *provider class* under the given name."""

        def decorator(provider_cls):  # type: ignore[missing-return-type-doc]
            lower = name.lower()
            if lower in cls._REGISTRY:
                raise ValueError(f"Provider '{name}' already registered")
            cls._REGISTRY[lower] = provider_cls
            logger.debug(f"Registered vector-store provider '{lower}' -> {provider_cls}")
            return provider_cls

        return decorator

    @classmethod
    def get_provider_cls(cls, name: str):  # noqa: D401
        logger.info(f"Getting vector-store provider '{name}'")
        return cls._REGISTRY.get(name.lower())

    # Best-effort on-demand import for providers following the
    # '<name>_provider' module naming convention.
    @classmethod
    def _lazy_import_provider(cls, name: str) -> None:
        from importlib import import_module as _import_module
        mod_name = f"agentfoundry.vectorstores.providers.{name.lower()}_provider"
        try:
            _import_module(mod_name)
            logger.info(f"Lazy-imported vector-store provider module '{mod_name}'")
        except ModuleNotFoundError as _err:
            logger.warning(f"Vector-store provider module '{mod_name}' not found: {_err}")
        except Exception as _err:  # pragma: no cover – defensive logging
            logger.warning(f"Vector-store provider module '{mod_name}' failed to import: {_err}", exc_info=True)

    @classmethod
    def available_providers(cls):
        logger.info(f"Available vector-store providers: {cls._REGISTRY}")
        return list(cls._REGISTRY.keys())

    # --------------------------------------------------------------
    # Public factory methods
    # --------------------------------------------------------------

    @classmethod
    def get_store(cls, provider: str | None = None, *, org_id: str | None = None, **kwargs):
        """Return a store from a singleton provider instance.

        Maintains exactly one provider instance per provider type and serves
        per-org stores from that singleton provider.
        """
        if not provider:
            # Prefer a configured provider; if missing/empty, default to local 'chroma'
            try:
                provider = Config().get("VECTORSTORE.PROVIDER", "")
            except Exception:
                provider = ""
            if not provider:
                logger.warning("VECTORSTORE.PROVIDER not set; defaulting to 'chroma' (local persistence)")
                provider = "chroma"
        logger.info(f"VectorStore provider: {provider}")
        prov = cls.get_provider(provider)
        # Ask the provider for a store appropriate for this org
        try:
            return prov.get_store(org_id=org_id, **kwargs)
        except TypeError:
            # Backwards compatibility with providers that ignore org_id
            logger.error(f"Provider '{provider}' does not support org_id; using global store")
            return prov.get_store()

    @classmethod
    def get_provider(cls, provider: str | None = None):
        """Instantiate and return a VectorStore provider (abstract base type)."""
        if provider is None:
            try:
                cfg_value = Config().get("VECTORSTORE.PROVIDER", "")
            except Exception:
                cfg_value = ""
        else:
            cfg_value = provider
        if not cfg_value:
            logger.warning("VECTORSTORE.PROVIDER not set; defaulting to 'chroma' (local persistence)")
            cfg_value = "chroma"
        provider_name = cfg_value.lower()
        logger.info(f"VectorStoreFactory: provider={provider_name}")
        provider_cls = cls.get_provider_cls(provider_name)
        if provider_cls is None:
            logger.warning(f"VectorStoreFactory: provider={provider_name} not found; trying lazy import")
            # Try a lazy import once – accommodates environments where the
            # initial auto-import failed due to optional deps not being
            # available at interpreter start.
            cls._lazy_import_provider(provider_name)
            provider_cls = cls.get_provider_cls(provider_name)
        if provider_cls is None:
            error_msg = f"Unknown vector-store provider '{provider_name}'. Available providers: {cls.available_providers()}"
            raise ValueError(error_msg)

        # Cache instantiated providers: one instance per provider type
        cache_key = provider_name
        
        # Double-checked locking for thread safety
        if cache_key not in cls._CACHE:
            with cls._LOCK:
                if cache_key not in cls._CACHE:
                    logger.info(f"VectorStoreFactory initialising provider '{provider_name}'")
                    # Construct provider without org-specific kwargs; per-org stores are requested via get_store(...)
                    cls._CACHE[cache_key] = provider_cls()

        return cls._CACHE[cache_key]

# ---------------------------------------------------------------------------
# Auto-import default provider modules so they self-register.
# ---------------------------------------------------------------------------

from importlib import import_module as _import_module  # noqa: E402

for _mod in (
    "agentfoundry.vectorstores.providers.faiss_provider",
    "agentfoundry.vectorstores.providers.chroma_provider",
    "agentfoundry.vectorstores.providers.milvus_provider",
):
    try:
        _import_module(_mod)
    except ModuleNotFoundError as _err:  # pragma: no cover
        logger.warning(f"Optional vector-store provider '{_mod}' could not be imported: {_err}")
    except Exception as _err:  # pragma: no cover
        logger.warning(
            f"Optional vector-store provider '{_mod}' failed to import: {_err}",
            exc_info=True,
        )

# (duplicate public methods removed – now defined earlier inside the class)
