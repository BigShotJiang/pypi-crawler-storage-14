from .lambdag import LambdaGMethod

__all__ = ["LambdaGMethod"]