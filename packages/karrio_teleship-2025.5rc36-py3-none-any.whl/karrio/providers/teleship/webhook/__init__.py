from karrio.providers.teleship.webhook.register import (
    webhook_registration_request,
    parse_webhook_registration_response,
)
from karrio.providers.teleship.webhook.deregister import (
    webhook_deregistration_request,
    parse_webhook_deregistration_response,
)
