import sys, os, json
import time, os, json, random
from selenium import webdriver
import locale
from openpyxl import load_workbook
import pandas as pd
from human_actions import HumanActions
from datetime import datetime
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    NoSuchElementException, TimeoutException, WebDriverException
)

from PyQt5.QtWidgets import (
    QApplication, QWidget, QTabWidget, QVBoxLayout, QLabel, QPushButton,
    QLineEdit, QDateEdit, QTableWidget, QFileDialog, QFormLayout, QMessageBox
)
from PyQt5.QtCore import QDate


class ERPAutomation(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ERP Automation")
        self.resize(1000, 650)

        # Main layout and tab control
        layout = QVBoxLayout()
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # Add tabs
        self.create_login_tab()
        self.create_saving_entry_tab()
        self.create_cash_vouchers_tab()
        self.create_khadvitran_tab()

        self.setLayout(layout)

        # Load saved credentials if available
        self.load_saved_credentials()
        self.driver = None
        self.human = None
        self.df = None
        self.file_path = ""
        self.config = {}

    # === LOGIN TAB ===
    def create_login_tab(self):
        from PyQt5.QtWidgets import QFormLayout, QWidget
        tab = QWidget()
        form = QFormLayout()

        self.txtLink = QLineEdit()
        self.txtUsername = QLineEdit()
        self.txtPassword = QLineEdit()
        self.txtPassword.setEchoMode(QLineEdit.Password)
        self.dtLoginDate = QDateEdit()
        self.dtLoginDate.setDate(QDate.currentDate())

        btnLogin = QPushButton("Login")
        btnRegister = QPushButton("Register")

        # Connect signals
        btnLogin.clicked.connect(self.login_clicked)
        btnRegister.clicked.connect(self.register_clicked)

        form.addRow(QLabel("LINK:"), self.txtLink)
        form.addRow(QLabel("Username:"), self.txtUsername)
        form.addRow(QLabel("Password:"), self.txtPassword)
        form.addRow(QLabel("Login Date:"), self.dtLoginDate)
        form.addRow(btnLogin, btnRegister)

        tab.setLayout(form)
        self.tabs.addTab(tab, "Login")

    # === SAVING ENTRY TAB ===
    def create_saving_entry_tab(self):
        from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout, QTableWidgetItem
        tab = QWidget()
        vbox = QVBoxLayout()
        hbox = QHBoxLayout()

        btnSingle = QPushButton("Single Saving Entry")
        btnBulk = QPushButton("Bulk Entry")
        btnPaste = QPushButton("Paste Data")

        hbox.addWidget(btnSingle)
        hbox.addWidget(btnBulk)
        hbox.addWidget(btnPaste)
        vbox.addLayout(hbox)

        table = QTableWidget(10, 9)
        headers = [
            "Date", "Admission Number", "Product", "Deposit", "Withdrawal",
            "Remark", "Farmer Name", "Voucher_Type", "Batch_id"
        ]
        table.setHorizontalHeaderLabels(headers)
        vbox.addWidget(table)

        tab.setLayout(vbox)
        self.tabs.addTab(tab, "Saving Entry")

    # === CASH VOUCHERS TAB ===
    def create_cash_vouchers_tab(self):
        from PyQt5.QtWidgets import QVBoxLayout
        tab = QWidget()
        layout = QVBoxLayout()

        table = QTableWidget(10, 7)
        headers = [
            "Date", "Voucher_Type", "Ledger", "Voucher No",
            "Narration", "Amount", "Remark"
        ]
        table.setHorizontalHeaderLabels(headers)
        layout.addWidget(table)

        tab.setLayout(layout)
        self.tabs.addTab(tab, "Cash Vouchers")

    # === KHAD VITRAN TAB ===
    def create_khadvitran_tab(self):
        from PyQt5.QtWidgets import QFormLayout
        tab = QWidget()
        layout = QFormLayout()

        self.txtExcelPath = QLineEdit()
        self.txtExcelPath.setReadOnly(True)

        btnBrowse = QPushButton("Browse")
        btnBrowse.clicked.connect(self.browse_excel)
        btnStart = QPushButton("Start Entry")
        btnStart.clicked.connect(self.start_khad_vitran)
        layout.addRow(QLabel("Select Excel File:"), self.txtExcelPath)
        layout.addRow(btnBrowse, btnStart)

        tab.setLayout(layout)
        self.tabs.addTab(tab, "KhadVitran")

    # === Event handlers ===
    def browse_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Excel File", "", "Excel Files (*.xlsx *.xls)"
        )
        if path:
            self.txtExcelPath.setText(path)

    def register_clicked(self):
        """Save login credentials to a JSON file"""
        data = {
            "link": self.txtLink.text().strip(),
            "username": self.txtUsername.text().strip(),
            "password": self.txtPassword.text().strip(),
            "login_date": self.dtLoginDate.date().toString("yyyy-MM-dd")
        }

        # Basic validation
        if not all(data.values()):
            QMessageBox.warning(self, "Error", "Please fill all fields before registering.")
            return
        cred_path = os.path.join(os.path.expanduser("~"), "credentials.json")
        with open(cred_path, "w") as f:
            json.dump(data, f)

        QMessageBox.information(self, "Saved", "Credentials saved successfully!")

    def load_saved_credentials(self):
        """Load saved credentials if JSON exists"""
        cred_path = os.path.join(os.path.expanduser("~"), "credentials.json")
        if os.path.exists(cred_path):
            try:
                with open(cred_path, "r") as f:
                    data = json.load(f)
                    self.txtLink.setText(data.get("link", ""))
                    self.txtUsername.setText(data.get("username", ""))
                    self.txtPassword.setText(data.get("password", ""))
                    date_str = data.get("login_date", "")
                    if date_str:
                        self.dtLoginDate.setDate(QDate.fromString(date_str, "yyyy-MM-dd"))
            except Exception as e:
                QMessageBox.warning(self, "Warning", f"Could not load credentials:\n{e}")

    def login_clicked(self):
        """Login using values entered in GUI text boxes."""
        try:
            url = self.txtLink.text().strip()
            username = self.txtUsername.text().strip()
            password = self.txtPassword.text().strip()
            # Get system locale (based on user’s regional settings)
            locale.setlocale(locale.LC_TIME, '')

            # Get system date format and format the selected date from GUI
            date_obj = self.dtLoginDate.date().toPyDate()
        
            login_date = date_obj.strftime("%x")

            print(f"[INFO] Using system date format: {login_date}")


            if not url or not username or not password:
                QMessageBox.warning(self, "Error", "Please fill all fields before login.")
                return

            self.driver = start_chrome_driver()
            if self.driver is None:
                QMessageBox.warning(self, "Error", "chromedriver.exe not found in this folder.")
                return

            print(f"[INFO] Navigating to: {url}")
            self.driver.get(url)
            time.sleep(1)

            print("[INFO] Entering Username...")
            self.driver.find_element(By.ID, "UserName").send_keys(username)

            print("[INFO] Entering Password...")
            self.driver.find_element(By.ID, "Password").send_keys(password)

            print("[INFO] Entering Login Date...")
            login_input = self.driver.find_element(By.ID, "LoginDataTime")
            login_input.clear()
            login_input.send_keys(login_date)

            print("[INFO] Handling Captcha...")
            captcha_value = self.driver.find_element(By.ID, "Captcha").get_attribute("value")
            self.driver.find_element(By.ID, "ValidateCaptcha").send_keys(captcha_value)
            self.human = HumanActions(self.driver)
            print("[INFO] Clicking Login button...")
            self.human.click_xpath("//button[@id='btnView ']")
            
            time.sleep(.25)

            # Optional confirmation popup
            try:
                self.human.click_xpath("//button[contains(@class, 'confirm') and normalize-space(text())='OK']")
              
                print("[INFO] Clicked confirmation popup.")
            except:
                print("[INFO] No confirmation popup found.")

            

        except Exception as e:
            QMessageBox.warning(self, "Error", f"Login failed: {e}")
            print(f"[ERROR] {e}")

    def start_khad_vitran(self):
        """Loop through Excel rows and perform Khad Vitran like VBA."""
        self.human = HumanActions(self.driver)
        file_path = self.txtExcelPath.text().strip()
        if not file_path or not os.path.exists(file_path):
            QMessageBox.warning(self, "Error", "Please select a valid Excel file first.")
            return

        self.df = pd.read_excel(file_path, sheet_name="VitaranData")
        self.file_path = file_path
        print(f"[INFO] Loaded {len(self.df)} rows from VitaranData.")

        lrow = 0
        while lrow < len(self.df):
            try:
                admission_no = str(self.df.iloc[lrow, 1]).strip()  # Cells(lrow,2)
                if not admission_no or admission_no.lower() == "nan":
                    break

                print(f"\n🚜 Row {lrow + 2}: AdmissionNo = {admission_no}")

                url_main = self.txtLink.text().strip()
                url = f"{url_main}/WorkFlow/Index"
                print(f"[DEBUG] Target : {url}")

                # Ensure correct page
                if self.driver.current_url != url:
                    self.driver.get(url)

                self.driver.find_element(By.XPATH, "//p[normalize-space()='Merchandise']").click()
                self.wait_for_element("//span[normalize-space()='Sales']")

                self.driver.find_element(By.XPATH, "//span[normalize-space()='Sales']").click()
                self.wait_for_element("//input[@id='Admissionno']")

                admission_input = self.human.find_xpath("//input[@id='Admissionno']")
                admission_input.clear()
                admission_input.send_keys(admission_no)
                admission_input.send_keys("\t")
                self.wait_for_element("//input[@id='MemberName']")

                # ✅ Call adding_khad() and update lrow from its return value
                lrow = self.adding_khad(lrow)

            except Exception as e:
                self.remark(False, "Something Error Try Again", lrow, 9)
                print(f"[ERROR] Row {lrow + 2}: {e}")
                lrow += 1
                continue

        print("[INFO] ✅ Khad Vitran process completed.")


    def adding_khad(self, lrow):
        """Python version of VBA addingKhad(lrow) — exact same sequence."""
        from selenium.webdriver.common.by import By
        import time

        try:
            khad_count = 1
            sale_rate_row = lrow
            index_num = 0

            while True:
                # ======= Select Category =======
                category_select = self.human.find_xpath("//select[@id='Category']")
                self.human.select_xpath("//select[@id='Category']", str(self.df.iloc[lrow, 3]))
                self.wait_for_element("//a[@id='btnAddItems']")

                # ======= Click Add Items (+) =======
                self.human.click_xpath("//a[@id='btnAddItems']//i[@class='glyphicon glyphicon-plus']")
                time.sleep(0.25)

                # ======= Enter Khad Name =======
                khad_name = str(self.df.iloc[lrow, 4])
                input_xpath = f"//tbody/tr[{khad_count}]/td[1]/span[1]/input[1]"
                self.wait_for_element(input_xpath)
                input_el = self.human.find_xpath(input_xpath)
                input_el.send_keys(khad_name)
                index_num += 1

                # ======= Select Khad Name =======
                self.select_khad_name(lrow, index_num)

                # ======= Tab & wait =======
                input_el.send_keys("\t")
                self.wait_for_element("//input[@id='MemberName']")

                # ======= Write member info =======
                try:
                    name = self.driver.find_element(By.ID, "MemberName").get_attribute("value")
                    father = self.driver.find_element(By.ID, "MemberFatherOrSpouseName").get_attribute("value")
                    village = self.driver.find_element(By.ID, "MemberVillage").get_attribute("value")
                    full_name = f"{name} {father} {village}"
                    self.write_to_excel(lrow, 8, full_name)  # Cells(lrow,9)
                except Exception:
                    pass

                # ======= Quantity field =======
                qty = str(self.df.iloc[lrow, 5])
                if khad_count == 1:
                    qty_el = self.driver.find_element(By.ID, "txtsaleqty")
                else:
                    qty_el = self.driver.find_element(
                        By.XPATH, f"//tbody/tr[{khad_count}]/td[7]/input[1]"
                    )
                qty_el.send_keys(qty)

                # ======= Remark: Khad Added =======
                self.remark(True, "Khad Added", lrow, 9)

                # ======= Next Khad if same farmer =======
                next_adm = str(self.df.iloc[lrow + 1, 1]) if lrow + 1 < len(self.df) else ""
                curr_adm = str(self.df.iloc[lrow, 1])
                if next_adm == curr_adm:
                    lrow += 1
                    khad_count += 1
                    continue  # GoTo addingKhad
                break  # Exit loop if different AdmissionNo

            lrow = sale_rate_row

            # ======= Payment Section =======
            self.human.select_xpath("//select[@id='PaymentMethod']", "Credit")
            try:
              self.human.select_xpath("//select[@id='AccountType']", "Loans")
            except:
             self.human.select_xpath("//select[@id='AccountType']", "ऋण")
            self.wait_for_element("//select[@id='AccountType']")

            acc_type = self.range_value("AccountType")
            if acc_type == "CardPayment":
                ref_no = str(self.df.iloc[lrow, 6])
                self.driver.find_element(By.ID, "ReferenceNo").send_keys(ref_no)
            else:
                if not self.select_loan_account(self.df.iloc[lrow, 2]):
                    raise Exception("Khad Account Not Selected")
            time.sleep(0.25)

            # ======= Scroll & Confirm =======
            btn_confirm = self.human.find_xpath("//button[@id='btnsaleconfirmview']")
            self.driver.execute_script("arguments[0].scrollIntoView(true);", btn_confirm)
            self.human.click_xpath("//button[@id='btnsaleconfirmview']")
            time.sleep(0.2)

            # ======= Sale Rate Update =======
            while True:
                khad_name = str(self.df.iloc[lrow, 4]).strip()
                rate_val = self.df.iloc[lrow, 10]
                expected_per_unit = self.df.iloc[lrow, 12]
                print("Expected Per Unit =", expected_per_unit)

                #self.update_sale_rate_by_khad(khad_name, rate_val)
                self.update_sale_rate_by_khadd(khad_name, rate_val, expected_per_unit)
                next_adm = str(self.df.iloc[lrow + 1, 1]) if lrow + 1 < len(self.df) else ""
                curr_adm = str(self.df.iloc[lrow, 1])
                if next_adm == curr_adm:
                    lrow += 1
                    continue
                else:
                    break

            bill_no = "Bill No. " + self.driver.find_element(By.ID, "txtponumber").text

            # ======= Eligibility & Total Check =======
            el_elig = self.driver.find_element(By.XPATH, "//*[@id='EligibilityAmount']")
            el_total = self.driver.find_element(By.ID, "txttotalAmountwithcharges")
            eligibility_value = float(el_elig.text.strip() or 0)
            total_value = float(el_total.text.strip() or 0)

            if eligibility_value < total_value:
                self.driver.execute_script(
                    """
                    document.getElementById('EligibilityAmount').innerText = arguments[0];
                    document.getElementById('EligibilityAmount').setAttribute('class', 'label label-success');
                    """,
                    total_value,
                )
                time.sleep(.2)

            self.wait_for_element("//input[@id='btnsubmit']")

            # ======= Submit =======
            self.human.click_xpath("//input[@id='btnsubmit']")
            self.wait_for_element("//button[@id='btnsuccessmessageok']")

            # ======= Success =======
            self.remark(True, bill_no, lrow, 9)
            self.human.click_xpath("//button[@id='btnsuccessmessageok']")

            # ======= Move to Next AdmissionNo =======
            next_row = lrow + 1
            while next_row < len(self.df) and str(self.df.iloc[next_row, 1]) == str(self.df.iloc[lrow, 1]):
                next_row += 1
            return next_row

        except Exception as e:
            self.remark(False, "Khad Account Not Selected", lrow, 9)
            print(f"[ERROR addingKhad] Row {lrow + 2}: {e}")
            return lrow + 1

    def wait_for_element(self, xpath=None, timeout=30, visibility=True):

        import time
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.common.exceptions import TimeoutException

        start_time = time.time()
        self.driver.implicitly_wait(1)

        try:
            # --- 1️⃣ Wait for loading-container to disappear ---
            while True:
                try:
                    loading_visible = self.driver.find_elements(By.XPATH, "//div[@class='loading-container']")
                    if not loading_visible:
                        break
                except Exception:
                    break

                if time.time() - start_time > timeout:
                    print("[WARN] Timeout: loading-container still visible")
                    break
                time.sleep(0.2)

            # --- 2️⃣ Wait for resultLoading to hide ---
            try:
                el = self.driver.find_element(By.XPATH, "//div[@id='resultLoading']")
                while True:
                    style = el.get_attribute("style")
                    if "display:none" in style or "display: none" in style:
                        break
                    if time.time() - start_time > timeout:
                        print("[WARN] Timeout: resultLoading still visible")
                        break
                    time.sleep(0.1)
            except Exception:
                pass

            # --- 3️⃣ Wait for the target element (if given) ---
            if xpath:
                wait = WebDriverWait(self.driver, timeout)
                if visibility:
                    return wait.until(EC.visibility_of_element_located((By.XPATH, xpath)))
            else:
                return wait.until(EC.presence_of_element_located((By.XPATH, xpath)))

        except TimeoutException:
            print(f"[WARN] Timeout waiting for element: {xpath}")
            return None

        finally:
           self.driver.implicitly_wait(3)

    def remark(self, success: bool, msg: str, lrow: int, col_index_1based: int):
        prefix = "✅ " if success else "❌ "
        try:
            self.write_to_excel(lrow, col_index_1based, prefix + str(msg))
        except Exception:
            print(f"[remark] Could not write remark for row {lrow}: {msg}")
        print(f"[REMARK] row {lrow+1}: {prefix}{msg}")

    def write_to_excel(self, lrow, col_index_1based, value):
        """Update self.df in memory and save back to Excel."""
        try:
            col_idx0 = col_index_1based - 1
            while col_idx0 >= len(self.df.columns):
                self.df[f"ExtraCol{len(self.df.columns)+1}"] = ""
            self.df.iat[lrow, col_idx0] = str(value)
            with pd.ExcelWriter(self.file_path, engine="openpyxl", mode="a",
                                if_sheet_exists="overlay") as writer:
                self.df.to_excel(writer, sheet_name="VitaranData", index=False)
        except Exception as e:
            print(f"[write_to_excel] failed: {e}")

    def range_value(self, name):
        cfg = getattr(self, "config", {})
        if name in cfg:
            return cfg[name]
        try:
            wb = pd.read_excel(self.file_path, sheet_name="Config", header=None, index_col=0)
            if name in wb.index:
                return str(wb.loc[name, 1])
        except Exception:
            pass
        fallbacks = {"AccountType": "LoanAccount", "PaymentMethod": "Credit"}
        return fallbacks.get(name, "")

    def select_loan_account(self, account_text) -> bool:
        from selenium.webdriver.support.ui import Select
        try:
            sel_el = self.human.find_xpath("//select[@id='OtherBankAccounts']")
            sel = Select(sel_el)
            for opt in sel.options:
                if account_text in opt.text:
                    sel.select_by_visible_text(opt.text)
                    return True
            return False
        except Exception as e:
            print(f"[select_loan_account] error: {e}")
            return False

    def select_khad_name(self, lrow, index_num):
        try:
            ul = self.human.find_xpath(f"(//ul[contains(@class,'ui-autocomplete')])[{index_num}]")
            expected = str(self.df.iloc[lrow, 4]).strip()
            lis = ul.find_elements(By.TAG_NAME, "li")
            texts = [li.text.strip() for li in lis]

            if expected in texts:
                lis[texts.index(expected)].click()
            elif lis:
                lis[0].click()
            else:
                return False
            return True
        except Exception as e:
            print(f"[select_khad_name] failed: {e}")
            return False

    def update_sale_rate_by_khad(self, khad_name, rate_value):
        """Find all txtrate inputs for the given khad_name and update their rate."""
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        import time

        try:
            # Find all rows containing this khad name
            rows = self.driver.find_elements(
                By.XPATH,
                f"//table[@id='tblsaleconfirmation']//tr[td[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{khad_name.lower()}')]]"
            )

            if not rows:
                print(f"[update_sale_rate_by_khad] No rows found for {khad_name}")
                return False

            for row in rows:
                try:
                    # Find the txtrate input in that row
                    rate_input = row.find_element(By.XPATH, ".//input[@id='txtrate']")

                    # Clear existing value (CTRL+A → DELETE)
                    rate_input.click()
                    rate_input.send_keys(Keys.CONTROL, 'a')
                    rate_input.send_keys(Keys.DELETE)
                    time.sleep(0.05)

                    # Enter new rate
                    rate_input.send_keys(str(rate_value))
                    rate_input.send_keys(Keys.TAB)
                    time.sleep(0.2)
                    
                    print(f"[update_sale_rate_by_khad] Set rate {rate_value} for {khad_name}")
                except Exception as e:
                    print(f"[update_sale_rate_by_khad] Failed to set rate for {khad_name}: {e}")
            return True
        except Exception as e:
            print(f"[update_sale_rate_by_khad] Error: {e}")
            return False

    def wait_random_time(self, a=0.2, b=0.6):
        time.sleep(random.uniform(a, b))

    def update_sale_rate_by_khadsd(self, khad_name, erp_rate, manual_rate):
        """
        Auto-adjust ERP sale rate for a product until the page total (txtnewrateamt)
        matches the expected total (qty * manual_rate), ignoring paise.
        It should never be below expected total (even after rounding) 
        and never exceed it by ₹1 or more.
        """
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        import time

        try:
            rows = self.driver.find_elements(
                By.XPATH,
                f"//table[@id='tblsaleconfirmation']//tr[td[contains(translate(., 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{khad_name.lower()}')]]"
            )

            if not rows:
                print(f"[update_sale_rate_by_khad] No rows found for {khad_name}")
                return False

            for row in rows:
                try:
                    rate_input = row.find_element(By.XPATH, ".//input[@id='txtrate']")
                    total_input = row.find_element(By.XPATH, ".//input[@id='txtnewrateamt']")
                    qty_input = row.find_element(By.XPATH, ".//input[contains(@id,'txtnewqty') or contains(@id,'txtsaleqty')]")

                    qty_val = float(qty_input.get_attribute("value") or 0)
                    expected_total = round(qty_val * float(manual_rate), 2)

                    def set_rate(val):
                        rate_input.click()
                        rate_input.send_keys(Keys.CONTROL, 'a')
                        rate_input.send_keys(Keys.DELETE)
                        rate_input.send_keys(str(round(val, 2)))
                        rate_input.send_keys(Keys.TAB)
                        time.sleep(0.25)

                    rate_value = float(erp_rate)
                    set_rate(rate_value)
                    shown_total = float(total_input.get_attribute("value") or 0)
                    attempt = 0

                    while attempt < 400:
                        attempt += 1
                        rounded_page = int(round(shown_total))
                        rounded_expected = int(round(expected_total))

                        # ✅ Match achieved
                        if rounded_page == rounded_expected:
                            break

                        # ⬇️ Too low — increase
                        if shown_total < expected_total:
                            rate_value = round(rate_value + 0.01, 2)

                        # ⬆️ Too high (≥ ₹1 more) — decrease
                        elif shown_total - expected_total >= 1:
                            rate_value = round(rate_value - 0.01, 2)

                        # Apply updated rate
                        set_rate(rate_value)
                        shown_total = float(total_input.get_attribute("value") or 0)

                    print(
                        f"[update_sale_rate_by_khad] ✅ {khad_name}: Final ERP Rate = {rate_value}, "
                        f"Expected ≈ ₹{expected_total}, Page = ₹{shown_total}, Attempts = {attempt}"
                    )

                except Exception as e:
                    print(f"[update_sale_rate_by_khad] ⚠️ Failed for {khad_name}: {e}")

            return True

        except Exception as e:
            print(f"[update_sale_rate_by_khad] ❌ Error: {e}")
            return False


    def update_sale_rate_by_khadd(self, khad_name, erp_rate, expected_per_unit):
        from selenium.common.exceptions import StaleElementReferenceException
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        import time

        # 1️⃣ Find all row numbers containing the product
        all_rows = self.driver.find_elements(By.XPATH, "//table[@id='tblsaleconfirmation']/tbody/tr")
        target_row_nums = []
        for idx, row in enumerate(all_rows, start=1):  # XPath is 1-indexed
            try:
                cells = row.find_elements(By.XPATH, ".//td")
                if any(khad_name.lower() in c.text.strip().lower() for c in cells):
                    target_row_nums.append(idx)
            except StaleElementReferenceException:
                continue

        if not target_row_nums:
            print(f"[solver] No rows found for {khad_name}")
            return False

        print(f"[solver] Found {khad_name} in rows: {target_row_nums}")

        # 2️⃣ Loop over each row
        for row_num in target_row_nums:
            print(f"[solver] Updating row {row_num} for {khad_name}")
            current_rate = float(erp_rate)

            for attempt in range(30):
                try:
                    row_xpath = f"//table[@id='tblsaleconfirmation']/tbody/tr[{row_num}]"
                    row = self.driver.find_element(By.XPATH, row_xpath)

                    qty = float(row.find_element(By.XPATH, ".//td[7]").text.strip())
                    print(f"Quantity for this row: {qty}")
                    expected_total = expected_per_unit * qty

                    rate_input = row.find_element(By.XPATH, ".//input[@id='txtrate']")
                    final_input = row.find_element(By.XPATH, ".//input[@id='txtnewrateamt']")

                    # Update rate
                    rate_input.click()
                    rate_input.send_keys(Keys.CONTROL, "a")
                    rate_input.send_keys(Keys.DELETE)
                    rate_input.send_keys(f"{current_rate:.5f}")
                    rate_input.send_keys(Keys.TAB)
                    time.sleep(0.25)

                    erp_total = float(final_input.get_attribute("value"))
                    diff = erp_total - expected_total

                    print(f"[{khad_name}] Row {row_num} | Try {attempt+1} | Qty={qty} | ERP={erp_total:.5f} | Expected={expected_total:.5f} | Diff={diff:.5f}")

                    if diff == 0:
                        print(f"[MATCH] Exact match achieved for row {row_num}")
                        break
                    elif erp_total < expected_total:
                        current_rate += abs(diff)/qty
                    else:
                        current_rate -= abs(diff)/qty

                except StaleElementReferenceException:
                    print(f"[solver] Stale element on row {row_num}, attempt {attempt+1}, retrying...")
                    time.sleep(0.2)
                    continue

            print(f"[solver] Final ERP rate for {khad_name} row {row_num}: {current_rate:.5f}")

        return True


def start_chrome_driver():
    """Start Chrome WebDriver (chromedriver.exe in same folder)."""
    chrome_options = Options()
    chrome_options.add_experimental_option('excludeSwitches', ['enable-logging'])

    # Check if custom Chrome binary exists
    if os.path.exists(r"C:\chrome-win32\chrome.exe"):
        print("[INFO] Using custom Chrome binary...")
        chrome_options.binary_location = r"C:\chrome-win32\chrome.exe"

    # Locate chromedriver.exe
    driver_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chromedriver.exe")
    if not os.path.exists(driver_path):
        print("[ERROR] chromedriver.exe not found in current folder.")
        return None

    print("[INFO] Starting Chrome WebDriver...")
    service = Service(driver_path)
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.maximize_window()
    print("[INFO] Chrome started successfully.")
    return driver


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ERPAutomation()
    window.show()
    sys.exit(app.exec_())
