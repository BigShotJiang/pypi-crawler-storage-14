import time
import random
import pyautogui
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class HumanActions:
    def __init__(self, driver):
        self.driver = driver
        self.actions = ActionChains(driver)

    # 🕓 Random short pause to simulate thought
    def _pause(self, a=0.1, b=0.25):
        time.sleep(random.uniform(a, b))

    # 🧭 Smooth scroll element into view
    def scroll_into_view(self, element):
        try:
            self.driver.execute_script(
                "arguments[0].scrollIntoView({behavior: 'smooth', block: 'center'});", element
            )
            self._pause(0.2, 0.4)
        except Exception:
            pass

    # 🖱 Physically move mouse to element center
    def move_mouse_to(self, element):
        try:
            self.scroll_into_view(element)

            rect = element.rect
            win_pos = self.driver.get_window_rect()

            scroll_x = self.driver.execute_script("return window.pageXOffset;")
            scroll_y = self.driver.execute_script("return window.pageYOffset;")

            # Compute screen position accurately
            x = win_pos["x"] + rect["x"] - scroll_x + rect["width"] / 2
            y = win_pos["y"] + rect["y"] - scroll_y + rect["height"] / 2

            # Move visible cursor
            pyautogui.moveTo(x, y, duration=random.uniform(0.2, 0.5))
            self._pause(0.05, 0.15)
        except Exception as e:
            print(f"[WARN] move_mouse_to failed: {e}")

    # 👁 Hover visibly (physical movement + slight pause)
    def hover(self, element):
        try:
            self.scroll_into_view(element)
            self.move_mouse_to(element)
            self._pause(0.15, 0.25)
        except Exception:
            # JS fallback hover event
            self.driver.execute_script("""
                const ev = new MouseEvent('mouseover', {bubbles:true});
                arguments[0].dispatchEvent(ev);
            """, element)
        self._pause(0.1, 0.2)

    # 🖱 Click using Selenium (after physical hover)
    def human_click(self, element):
        try:
            self.hover(element)
            # Actual Selenium click (registered as mouse action)
            element.click()
            print("[HUMAN] Hovered + Selenium click done.")
        except Exception as e:
            print(f"[WARN] human_click fallback: {e}")
            try:
                self.driver.execute_script("arguments[0].click();", element)
            except Exception:
                pass
        self._pause(0.2, 0.4)

    # 🎹 Type text gradually (simulate real typing)
    def human_type(self, element, text, clear_first=True, delay=(0.05, 0.12)):
        self.scroll_into_view(element)
        self.hover(element)
        if clear_first:
            try:
                element.clear()
            except Exception:
                pass
            self._pause(0.1, 0.2)
        element.click()
        for ch in str(text):
            element.send_keys(ch)
            time.sleep(random.uniform(*delay))
        self._pause(0.2, 0.4)

    # 🔽 Human dropdown selection
    def human_select(self, element, visible_text):
        self.scroll_into_view(element)
        self.hover(element)
        try:
            Select(element).select_by_visible_text(visible_text)
        except Exception:
            try:
                element.click()
                pyautogui.typewrite(visible_text, interval=0.08)
                pyautogui.press('enter')
            except:
                self.driver.execute_script("arguments[0].value = arguments[1];", element, visible_text)
        self._pause(0.2, 0.3)

    # 🔍 Wait for element safely
    def find_xpath(self, xpath, timeout=10):
        return WebDriverWait(self.driver, timeout).until(
            EC.presence_of_element_located((By.XPATH, xpath))
        )

    # 🌟 Combined click (hover + Selenium click)
    def click_xpath(self, xpath, timeout=10):
        el = self.find_xpath(xpath, timeout)
        self.human_click(el)

    # ✏ Combined type (hover + typing)
    def type_xpath(self, xpath, text, timeout=10):
        el = self.find_xpath(xpath, timeout)
        self.human_type(el, text)

    # ⬇ Combined select
    def select_xpath(self, xpath, visible_text, timeout=10):
        el = self.find_xpath(xpath, timeout)
        self.human_select(el, visible_text)
