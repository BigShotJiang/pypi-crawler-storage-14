.. _sec:example-notebook:

GODOT Example
=============

`Example Jupyter Notebook <_static/Earth_Mars_SEP_Pyoptgra.html>`_