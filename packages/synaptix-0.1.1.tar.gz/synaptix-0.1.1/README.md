# 🤖 SynaptIX – Intelligence Module

SynaptIX es una librería moderna de Inteligencia Artificial diseñada para ofrecer una API unificada y sencilla que integra **Machine Learning**, **Deep Learning**, **Visión por Computador**, **Procesamiento del Lenguaje Natural** e **IA clásica**, todo dentro de una sola clase: `Intelligence`.

Este módulo busca ser una alternativa ligera, intuitiva y lista para escalar hacia proyectos profesionales y académicos.

---

## ✨ Características principales

### 🔹 Machine Learning
Métodos clásicos y ampliamente usados:
- `linear_regression()`
- `logistic_regression()`
- `svm_classifier()`
- `kmeans()`

### 🔹 Deep Learning
Modelos implementados de forma sencilla:
- `dense_network()`
- `cnn()`

### 🔹 Visión por Computador
Funciones esenciales para análisis y filtrado:
- `detect_edges()`
- `image_features()`

### 🔹 Procesamiento del Lenguaje Natural (NLP)
Herramientas básicas para texto:
- `tokenize()`
- `vectorize_tfidf()`

### 🔹 IA Clásica
Técnicas inspiradas en métodos tradicionales:
- `a_star()`
- `genetic_algorithm()`

---

## 🚀 Ejemplo rápido de uso

```python
from synaptix import Intelligence

ai = Intelligence(data)

ai.linear_regression()      # Machine Learning
ai.dense_network()          # Deep Learning
ai.detect_edges()           # Visión artificial
ai.tokenize()               # NLP
ai.a_star()                 # IA clásica

ai.help()                   # Ver documentación interna


📦 Instalación
```bash
pip install statslibx
```
🤝 Contribuciones ¡Todas las mejoras e ideas son bienvenidas! 
E-mail: ascendraemmanuel@gmail.com Puedes ajustar ese readme