from typing import Tuple, cast, Optional

from http_sf.innerlist import parse_item_or_inner_list, ser_item_or_inner_list
from http_sf.parameters import parse_params, ser_params
from http_sf.types import DictionaryType, ItemType, OnDuplicateKeyType
from http_sf.util import discard_http_ows, ser_key, parse_key


EQUALS = ord(b"=")
COMMA = ord(b",")


def parse_dictionary(
    data: bytes, on_duplicate_key: Optional[OnDuplicateKeyType] = None
) -> Tuple[int, DictionaryType]:
    bytes_consumed = 0
    dictionary = {}
    data_len = len(data)
    while True:
        offset, this_key = parse_key(data[bytes_consumed:])
        bytes_consumed += offset
        try:
            is_equals = data[bytes_consumed] == EQUALS
        except IndexError:
            is_equals = False
        if is_equals:
            bytes_consumed += 1  # consume the "="
            offset, member = parse_item_or_inner_list(data[bytes_consumed:], on_duplicate_key)
            bytes_consumed += offset
        else:
            params_consumed, params = parse_params(data[bytes_consumed:], on_duplicate_key)
            bytes_consumed += params_consumed
            member = (True, params)
        if on_duplicate_key and this_key in dictionary:
            on_duplicate_key(this_key, "dictionary")
        dictionary[this_key] = member
        bytes_consumed += discard_http_ows(data[bytes_consumed:])
        if bytes_consumed == data_len:
            return bytes_consumed, dictionary
        if data[bytes_consumed] != COMMA:
            raise ValueError(f"Dictionary member '{this_key}' has trailing characters")
        bytes_consumed += 1
        bytes_consumed += discard_http_ows(data[bytes_consumed:])
        if bytes_consumed == data_len:
            raise ValueError("Dictionary has trailing comma")


def ser_dictionary(dictionary: DictionaryType) -> str:
    if len(dictionary) == 0:
        raise ValueError("No contents; field should not be emitted")
    return ", ".join(
        [
            f"{ser_key(m)}"
            f"""{ser_params(n[1]) if
                (isinstance(n, tuple) and n[0] is True)
                else f'={ser_item_or_inner_list(cast(ItemType, n))}'}"""
            for m, n in dictionary.items()
        ]
    )
