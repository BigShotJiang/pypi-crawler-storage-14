from pro_craft_infer.core import AsyncIntel
from pro_craft_infer.core import atest_by_use_case
from digital_life.core.memorycard import MemoryCardManager
from digital_life.core.user import UserInfo
import os

import pytest


