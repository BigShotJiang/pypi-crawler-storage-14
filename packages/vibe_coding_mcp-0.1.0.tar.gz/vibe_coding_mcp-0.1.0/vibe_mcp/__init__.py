"""
Vibe Coding MCP Server

An MCP server and CLI tool that enforces the Vibe Coding workflow:
- Git branch per chunk
- Time and attempt tracking  
- Mandatory stops after each chunk
- User approval/rejection workflow
"""

__version__ = "0.1.0"

from pathlib import Path

# Package directory (for accessing bundled docs)
PACKAGE_DIR = Path(__file__).parent
DOCS_DIR = PACKAGE_DIR.parent / "docs"

