"""
Vibe Coding CLI

User commands to approve, reject, or continue chunks.

Install: pip install vibe-coding
Usage: vibe init, vibe start, vibe approve, etc.
"""

import json
import subprocess
import sys
import os
from datetime import datetime
from pathlib import Path

import click

# State file in current working directory
STATE_FILE = Path.cwd() / ".vibe_state.json"


def load_state() -> dict:
    """Load current state from file."""
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {
        "current_chunk": None,
        "start_time": None,
        "attempts": [],
        "history": []
    }


def save_state(state: dict):
    """Save state to file."""
    STATE_FILE.write_text(json.dumps(state, indent=2, default=str))


def run_git(args: list[str]) -> tuple[bool, str]:
    """Run a git command and return (success, output)."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            check=True
        )
        return True, result.stdout.strip()
    except subprocess.CalledProcessError as e:
        return False, e.stderr.strip()


def update_mcp_project(project_dir: Path):
    """Update MCP config with project directory via --project arg."""
    cursor_config_dir = Path.home() / ".cursor"
    mcp_config_path = cursor_config_dir / "mcp.json"
    
    if not mcp_config_path.exists():
        return  # No MCP config yet, setup-mcp will create it
    
    try:
        config = json.loads(mcp_config_path.read_text())
        if "vibe" in config.get("mcpServers", {}):
            vibe_config = config["mcpServers"]["vibe"]
            args = vibe_config.get("args", [])
            
            # Remove old --project args if present
            new_args = []
            skip_next = False
            for arg in args:
                if skip_next:
                    skip_next = False
                    continue
                if arg == "--project":
                    skip_next = True
                    continue
                new_args.append(arg)
            
            # Add new --project arg
            new_args.extend(["--project", str(project_dir)])
            vibe_config["args"] = new_args
            
            # Remove cwd if present (doesn't work reliably)
            vibe_config.pop("cwd", None)
            
            mcp_config_path.write_text(json.dumps(config, indent=2))
    except Exception:
        pass  # Silently fail, user can run setup-mcp manually


@click.group()
def cli():
    """Vibe Coding CLI - Manage your chunks."""
    pass


@cli.command()
def status():
    """Show current chunk status."""
    state = load_state()
    
    turbo = state.get("turbo", False)
    turbo_str = "🏎️ TURBO" if turbo else "🛑 MANUAL"
    
    if not state["current_chunk"]:
        click.echo(f"📊 No chunk in progress.  [{turbo_str}]")
        click.echo(f"\n   Toggle with: vibe turbo --{'off' if turbo else 'on'}")
        click.echo("\nHistory:")
        for h in state.get("history", [])[-5:]:
            click.echo(f"  • {h['chunk']}: {h['status']} ({h['attempts']} attempts)")
        return
    
    # Handle paused state
    if state.get("paused"):
        prior_min = round(state.get("elapsed_before_pause", 0) / 60, 1)
        click.echo(f"""
⏸️  CHUNK PAUSED  [{turbo_str}]

Chunk: {state["current_chunk"]}
Mode: {state.get("mode", "unknown").upper()}
Branch: chunk/{state["current_chunk"]}
Time before pause: {prior_min} minutes
Attempt: #{len(state["attempts"])}
{f"Pause note: {state.get('pause_message')}" if state.get('pause_message') else ""}

Resume with: vibe resume
""")
        return
    
    start = datetime.fromisoformat(state["start_time"])
    elapsed = datetime.now() - start
    prior_elapsed = state.get("elapsed_before_pause", 0)
    total_seconds = elapsed.total_seconds() + prior_elapsed
    minutes = total_seconds / 60
    
    click.echo(f"""
📊 VIBE STATUS  [{turbo_str}]

Chunk: {state["current_chunk"]}
Mode: {state.get("mode", "unknown").upper()}
Branch: chunk/{state["current_chunk"]}
Elapsed: {round(minutes, 1)} minutes
Attempt: #{len(state["attempts"])}

{"After complete_chunk: auto-merge & continue" if turbo else "After complete_chunk: run 'vibe approve' to merge"}
""")


@cli.command()
@click.option("--message", "-m", default=None, help="Commit message")
def approve(message: str):
    """Approve and merge the current chunk."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress.")
        return
    
    chunk_name = state["current_chunk"]
    branch_name = f"chunk/{chunk_name}"
    
    # Create pre-merge tag for rollback safety
    run_git(["tag", f"pre-chunk-{chunk_name}"])
    
    # Switch to main
    success, output = run_git(["checkout", "main"])
    if not success:
        click.echo(f"❌ Failed to switch to main: {output}")
        return
    
    # Merge the branch (normal merge, keeps history)
    merge_msg = message or f"chunk-{chunk_name}: Approved and merged"
    success, output = run_git(["merge", branch_name, "-m", merge_msg])
    if not success:
        click.echo(f"❌ Failed to merge: {output}")
        return
    
    # Create post-merge tag
    run_git(["tag", f"chunk-{chunk_name}"])
    
    # Delete the branch
    run_git(["branch", "-d", branch_name])
    
    # Update state
    if state["attempts"]:
        state["attempts"][-1]["status"] = "approved"
    
    state["history"].append({
        "chunk": chunk_name,
        "status": "✅ approved",
        "attempts": len(state["attempts"]),
        "completed": datetime.now().isoformat()
    })
    
    state["current_chunk"] = None
    state["start_time"] = None
    state["mode"] = None
    state["attempts"] = []
    save_state(state)
    
    click.echo(f"""
✅ CHUNK APPROVED AND MERGED

Chunk: {chunk_name}
Status: Merged to main
Branch: Deleted

You may now start the next chunk.
""")


@cli.command()
def reject():
    """Reject and delete the current chunk branch."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress.")
        return
    
    chunk_name = state["current_chunk"]
    branch_name = f"chunk/{chunk_name}"
    
    # Switch to main
    success, output = run_git(["checkout", "main"])
    if not success:
        click.echo(f"❌ Failed to switch to main: {output}")
        return
    
    # Delete the branch (force, no merge)
    success, output = run_git(["branch", "-D", branch_name])
    if not success:
        click.echo(f"❌ Failed to delete branch: {output}")
        return
    
    # Update state
    if state["attempts"]:
        state["attempts"][-1]["status"] = "rejected"
    
    state["history"].append({
        "chunk": chunk_name,
        "status": "❌ rejected",
        "attempts": len(state["attempts"]),
        "completed": datetime.now().isoformat()
    })
    
    state["current_chunk"] = None
    state["start_time"] = None
    state["mode"] = None
    state["attempts"] = []
    save_state(state)
    
    click.echo(f"""
❌ CHUNK REJECTED

Chunk: {chunk_name}
Status: Branch deleted (not merged)

You may start fresh with the same or different approach.
""")


@cli.command()
@click.option("--feedback", "-f", default="", help="Feedback for next attempt")
def cont(feedback: str):
    """Continue working on the current chunk."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress.")
        return
    
    # Start a new attempt
    state["attempts"].append({
        "number": len(state["attempts"]) + 1,
        "started": datetime.now().isoformat(),
        "status": "in_progress",
        "feedback": feedback
    })
    state["start_time"] = datetime.now().isoformat()
    save_state(state)
    
    click.echo(f"""
🔄 CONTINUING CHUNK

Chunk: {state["current_chunk"]}
Attempt: #{len(state["attempts"])}
{"Feedback: " + feedback if feedback else ""}

Timer reset. Continue working.
""")


@cli.command()
@click.argument("note")
def log(note: str):
    """Log a note/diagnostic to the current chunk."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress. Note not saved.")
        return
    
    # Create log file in .vibe/
    log_dir = Path(".vibe")
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"{state['current_chunk']}.log"
    
    timestamp = datetime.now().strftime("%H:%M:%S")
    with open(log_file, "a") as f:
        f.write(f"[{timestamp}] {note}\n")
    
    # Also add to state for summary
    if "logs" not in state:
        state["logs"] = []
    state["logs"].append({"time": timestamp, "note": note})
    save_state(state)
    
    click.echo(f"📝 Logged: {note[:50]}{'...' if len(note) > 50 else ''}")


@cli.command()
def logs():
    """Show logs for current chunk."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress.")
        return
    
    log_file = Path(".vibe") / f"{state['current_chunk']}.log"
    
    if log_file.exists():
        click.echo(f"📋 Logs for {state['current_chunk']}:\n")
        click.echo(log_file.read_text())
    else:
        click.echo("No logs yet for this chunk.")


@cli.command()
@click.argument("name")
@click.option("--mode", "-m", default="create", help="create or edit")
def start(name: str, mode: str):
    """Start a new chunk (for testing without MCP server)."""
    state = load_state()
    
    # Check if already in a chunk
    if state["current_chunk"]:
        click.echo(f"❌ Already in chunk '{state['current_chunk']}'. Complete it first.")
        return
    
    # Create branch
    branch_name = f"chunk/{name}"
    success, output = run_git(["checkout", "-b", branch_name])
    
    if not success:
        # Maybe branch exists, try switching
        success, output = run_git(["checkout", branch_name])
        if not success:
            click.echo(f"❌ Failed to create/switch branch: {output}")
            return
    
    # Update state
    state["current_chunk"] = name
    state["mode"] = mode
    state["start_time"] = datetime.now().isoformat()
    state["attempts"] = [{
        "number": 1,
        "started": datetime.now().isoformat(),
        "status": "in_progress"
    }]
    save_state(state)
    
    click.echo(f"""
✅ CHUNK STARTED

Chunk: {name}
Mode: {mode.upper()}
Branch: {branch_name}
Timer: Started

Work on your chunk, then run:
  vibe done "summary of what you did"
""")


@cli.command()
@click.argument("summary")
def done(summary: str):
    """Mark chunk as done, await review."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress.")
        return
    
    # Calculate duration
    start = datetime.fromisoformat(state["start_time"])
    duration = datetime.now() - start
    minutes = duration.total_seconds() / 60
    
    # Update attempt
    if state["attempts"]:
        state["attempts"][-1]["completed"] = datetime.now().isoformat()
        state["attempts"][-1]["duration_min"] = round(minutes, 1)
        state["attempts"][-1]["summary"] = summary
        state["attempts"][-1]["status"] = "awaiting_review"
    save_state(state)
    
    click.echo(f"""
🛑 CHUNK COMPLETE — AWAITING REVIEW

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Chunk: {state["current_chunk"]}
Mode: {state.get("mode", "unknown").upper()}
Duration: {round(minutes, 1)} minutes
Attempt: #{len(state["attempts"])}

Summary: {summary}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your options:
  vibe approve     → Merge to main, lock chunk
  vibe reject      → Delete branch, start over
  vibe cont        → Stay on branch, keep working
""")


@cli.command()
@click.argument("message", default="")
def pause(message: str):
    """Pause current chunk (stash work, stop timer)."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk in progress.")
        return
    
    if state.get("paused"):
        click.echo("❌ Already paused. Use 'vibe resume' to continue.")
        return
    
    # Calculate elapsed time so far
    start = datetime.fromisoformat(state["start_time"])
    elapsed = (datetime.now() - start).total_seconds()
    
    # Stash any uncommitted changes
    success, output = run_git(["stash", "push", "-m", f"vibe-pause: {state['current_chunk']}"])
    has_stash = "No local changes" not in output
    
    # Update state
    state["paused"] = True
    state["pause_time"] = datetime.now().isoformat()
    state["elapsed_before_pause"] = state.get("elapsed_before_pause", 0) + elapsed
    state["pause_message"] = message
    state["has_stash"] = has_stash
    save_state(state)
    
    click.echo(f"""
⏸️  CHUNK PAUSED

Chunk: {state["current_chunk"]}
Elapsed: {round(elapsed / 60, 1)} min (preserved)
{"Stashed: Yes" if has_stash else "Stashed: No (nothing to stash)"}
{f"Note: {message}" if message else ""}

Resume with: vibe resume
""")


@cli.command()
def resume():
    """Resume a paused chunk."""
    state = load_state()
    
    if not state["current_chunk"]:
        click.echo("❌ No chunk to resume.")
        return
    
    if not state.get("paused"):
        click.echo("❌ Chunk not paused. Already working!")
        return
    
    # Pop stash if we had one
    if state.get("has_stash"):
        success, output = run_git(["stash", "pop"])
        if not success:
            click.echo(f"⚠️ Warning: Failed to pop stash: {output}")
            click.echo("You may need to manually run: git stash pop")
    
    # Resume timer (start fresh, but we track elapsed_before_pause)
    state["paused"] = False
    state["start_time"] = datetime.now().isoformat()
    state["pause_time"] = None
    state["pause_message"] = None
    state["has_stash"] = False
    save_state(state)
    
    prior_min = round(state.get("elapsed_before_pause", 0) / 60, 1)
    
    click.echo(f"""
▶️  CHUNK RESUMED

Chunk: {state["current_chunk"]}
Prior time: {prior_min} min
Timer: Restarted

Continue working!
""")


@cli.command()
@click.option("--turbo", is_flag=True, help="Enable turbo mode (auto-approve chunks)")
def init(turbo: bool):
    """Initialize Vibe Coding in current directory."""
    project_dir = Path.cwd()
    
    # Check if git is initialized
    success, _ = run_git(["status"])
    if not success:
        click.echo("Initializing git...")
        run_git(["init"])
        run_git(["checkout", "-b", "main"])  # Ensure main branch
    
    # Check if there's at least one commit
    success, _ = run_git(["rev-parse", "HEAD"])
    if not success:
        click.echo("Creating initial commit...")
        # Create a comprehensive .gitignore
        gitignore = project_dir / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text("""# Vibe Coding
.vibe_state.json
.vibe/

# Python
__pycache__/
*.py[cod]
*$py.class
*.pyc
*.pyo
*.egg
*.egg-info/
.eggs/
dist/
build/
*.whl

# Virtual environments
venv/
.venv/
env/
.env

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Databases
*.db
*.sqlite3

# Logs
*.log
""")
        run_git(["add", ".gitignore"])
        run_git(["commit", "-m", "Initial commit (vibe init)"])
    
    # Create initial state with turbo mode setting
    state = {
        "current_chunk": None,
        "start_time": None,
        "attempts": [],
        "history": [],
        "turbo": turbo  # Store turbo mode setting
    }
    save_state(state)
    
    # Create notes directory
    Path(".vibe").mkdir(exist_ok=True)
    
    # Create .cursorrules with vibe coding instructions (different for turbo mode)
    cursorrules = project_dir / ".cursorrules"
    if turbo:
        cursorrules.write_text("""# Vibe Coding Rules (TURBO MODE 🏎️)

Always use these MCP tools for development work:
- Call start_chunk(name, mode) BEFORE starting any coding task
- Call complete_chunk(summary) when done - it will AUTO-MERGE and you can continue
- Each chunk is auto-tagged in git for easy rollback if needed

## CHUNK 0 RULE (Dependencies First)
Your FIRST chunk must always be "000-setup" which creates:
- pyproject.toml with:
  - ALL dependencies the project will need
  - [project.scripts] entry so CLI works immediately after install
  - [tool.setuptools.packages.find] with include = ["pkgname*"]
- Basic folder structure (empty __init__.py files)  
- README.md skeleton with usage examples

Example pyproject.toml structure:
```toml
[project]
name = "myapp"
version = "0.1.0"
dependencies = ["click>=8.0", "httpx>=0.28"]

[project.scripts]
myapp = "myapp.cli:main"

[tool.setuptools.packages.find]
include = ["myapp*"]

[build-system]
requires = ["setuptools", "wheel"]
build-backend = "setuptools.build_meta"
```

After chunk 000-setup completes, tell the user:
"⏸️ Run these commands then say 'continue':
```bash
python3 -m venv venv
source venv/bin/activate
pip install -e .
```"

Then WAIT for user confirmation before starting chunk 001.

## Workflow
start_chunk → work → complete_chunk → (auto-commits & auto-merges) → continue

TURBO MODE: 
- complete_chunk auto-commits all changes and merges to main
- Git tags provide the safety net for rollbacks
- If something breaks, user can run: vibe revert <chunk-name>
""")
    else:
        cursorrules.write_text("""# Vibe Coding Rules

Always use these MCP tools for development work:
- Call start_chunk(name, mode) BEFORE starting any coding task
- Call complete_chunk(summary) when done and STOP for user review
- Never proceed to the next task without user approval

## CHUNK 0 RULE (Dependencies First)
Your FIRST chunk must always be "000-setup" which creates:
- pyproject.toml with:
  - ALL dependencies the project will need
  - [project.scripts] entry so CLI works immediately after install
  - [tool.setuptools.packages.find] with include = ["pkgname*"]
- Basic folder structure (empty __init__.py files)
- README.md skeleton with usage examples

Example pyproject.toml structure:
```toml
[project]
name = "myapp"
version = "0.1.0"
dependencies = ["click>=8.0", "httpx>=0.28"]

[project.scripts]
myapp = "myapp.cli:main"

[tool.setuptools.packages.find]
include = ["myapp*"]

[build-system]
requires = ["setuptools", "wheel"]
build-backend = "setuptools.build_meta"
```

After chunk 000-setup completes, tell the user:
"⏸️ Run these commands then say 'continue':
```bash
python3 -m venv venv
source venv/bin/activate
pip install -e .
```"

Then WAIT for user confirmation before starting chunk 001.

## Workflow
start_chunk → work → complete_chunk → STOP → wait for approval

Note: complete_chunk auto-commits all changes before stopping.

After complete_chunk, output:
"🛑 CHUNK COMPLETE - Waiting for: vibe approve or vibe reject"
Then STOP and wait.
""")
    
    # Auto-update MCP config with this project's path
    update_mcp_project(project_dir)
    
    mode_str = "🏎️ TURBO MODE" if turbo else "🛑 STANDARD MODE"
    
    click.echo(f"""
✅ VIBE CODING INITIALIZED

Project: {project_dir}
Mode: {mode_str}

Created:
  • .gitignore
  • .vibe_state.json (state tracking)
  • .cursorrules (AI instructions)
  • .vibe/ (working memory)
  • Updated MCP config
{"" if not turbo else '''
TURBO MODE ENABLED:
  • Chunks auto-merge when complete
  • Git tags created for easy rollback
  • Use "vibe revert <chunk>" if needed
'''}
Next steps:
  1. Restart Cursor (first time only, or when switching projects)
  2. Start chatting - AI will begin with chunk 000-setup (dependencies)
  3. After chunk 0: create venv, install, then say "continue"
""")


@cli.command("setup-mcp")
def setup_mcp():
    """Configure MCP server in Cursor."""
    import shutil
    
    # Find the server.py path
    try:
        import vibe_mcp
        server_path = Path(vibe_mcp.__file__).parent / "server.py"
    except ImportError:
        # Fallback for development
        server_path = Path(__file__).parent / "server.py"
    
    # Find Python path
    python_path = sys.executable
    
    # Cursor MCP config path
    cursor_config_dir = Path.home() / ".cursor"
    cursor_config_dir.mkdir(exist_ok=True)
    mcp_config_path = cursor_config_dir / "mcp.json"
    
    # Create or update config
    config = {"mcpServers": {}}
    if mcp_config_path.exists():
        try:
            config = json.loads(mcp_config_path.read_text())
        except:
            pass
    
    config["mcpServers"]["vibe"] = {
        "command": str(python_path),
        "args": [str(server_path)]
    }
    
    mcp_config_path.write_text(json.dumps(config, indent=2))
    
    click.echo(f"""
✅ MCP SERVER CONFIGURED

Config: {mcp_config_path}
Python: {python_path}
Server: {server_path}

Next steps:
  1. Restart Cursor (Cmd+Q, reopen)
  2. The AI will have access to vibe tools:
     • start_chunk(name, mode)
     • complete_chunk(summary)
     • get_status()
     • log_note(note)
""")


@cli.command()
@click.argument("chunk_name")
def revert(chunk_name: str):
    """Revert to before a specific chunk was merged."""
    # Find the tag
    success, tags = run_git(["tag", "-l", f"pre-chunk-{chunk_name}"])
    if not success or not tags:
        # Try without the pre- prefix
        success, tags = run_git(["tag", "-l", f"chunk-{chunk_name}"])
        if success and tags:
            click.echo(f"""
Found tag: chunk-{chunk_name}

To revert TO this chunk (keep it):
  git reset --hard chunk-{chunk_name}

To revert BEFORE this chunk (remove it):
  Look for an earlier tag with: git tag -l "chunk-*"
""")
            return
        
        click.echo(f"❌ No tag found for chunk '{chunk_name}'")
        click.echo("\nAvailable chunk tags:")
        success, all_tags = run_git(["tag", "-l", "chunk-*"])
        if success:
            click.echo(all_tags or "  (none)")
        success, pre_tags = run_git(["tag", "-l", "pre-chunk-*"])
        if success:
            click.echo(pre_tags or "")
        return
    
    # Confirm with user
    click.echo(f"""
⚠️ WARNING: This will reset to BEFORE chunk '{chunk_name}' was merged.

All work after this point will be lost (but still in git reflog for 30 days).

Tag: pre-chunk-{chunk_name}
""")
    
    if not click.confirm("Proceed with revert?"):
        click.echo("Cancelled.")
        return
    
    # Do the reset
    success, output = run_git(["reset", "--hard", f"pre-chunk-{chunk_name}"])
    if not success:
        click.echo(f"❌ Failed to revert: {output}")
        return
    
    # Update state to remove reverted chunks from history
    state = load_state()
    
    # Find index of the reverted chunk and remove it + everything after
    new_history = []
    for h in state.get("history", []):
        if h["chunk"] == chunk_name:
            break  # Stop here, don't include this chunk or later ones
        new_history.append(h)
    
    state["history"] = new_history
    state["current_chunk"] = None
    state["start_time"] = None
    state["mode"] = None
    state["attempts"] = []
    save_state(state)
    
    remaining = len(new_history)
    click.echo(f"""
✅ REVERTED TO BEFORE CHUNK '{chunk_name}'

Current state is now at: pre-chunk-{chunk_name}
History updated: {remaining} chunks remain

To recover if needed: git reflog (within 30 days)
""")


@cli.command()
@click.option("--on", "enable", is_flag=True, help="Enable turbo mode")
@click.option("--off", "disable", is_flag=True, help="Disable turbo mode")
def turbo(enable: bool, disable: bool):
    """Toggle turbo mode (auto-approve chunks)."""
    state = load_state()
    
    if enable and disable:
        click.echo("❌ Can't use --on and --off together")
        return
    
    if enable:
        state["turbo"] = True
        save_state(state)
        click.echo("🏎️ TURBO MODE ENABLED - chunks will auto-merge")
    elif disable:
        state["turbo"] = False
        save_state(state)
        click.echo("🛑 TURBO MODE DISABLED - chunks require manual approval")
    else:
        current = state.get("turbo", False)
        click.echo(f"Turbo mode: {'🏎️ ON' if current else '🛑 OFF'}")
        click.echo("\nUse --on or --off to change")


@cli.command("docs")
def show_docs():
    """Show path to documentation."""
    try:
        import vibe_mcp
        docs_dir = Path(vibe_mcp.__file__).parent.parent / "docs"
    except ImportError:
        docs_dir = Path(__file__).parent.parent / "docs"
    
    if docs_dir.exists():
        click.echo(f"""
📚 VIBE CODING DOCUMENTATION

Location: {docs_dir}

Files:
  • VIBE_MANIFEST.md     - Full method (load into AI)
  • GIT_CHUNK_WORKFLOW.md - Git workflow
  • vibe_coding_method.md - Conceptual overview
  • templates/            - Copy-paste templates
""")
    else:
        click.echo(f"Docs not found at {docs_dir}")


if __name__ == "__main__":
    cli()

