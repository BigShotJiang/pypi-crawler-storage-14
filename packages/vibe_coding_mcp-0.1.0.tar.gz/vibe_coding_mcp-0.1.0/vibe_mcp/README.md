# Vibe MCP Server

An MCP (Model Context Protocol) server that enforces the Vibe Coding workflow.

## What It Does

- 🌿 **Git branch per chunk** - Isolates work, protects main
- ⏱️ **Time tracking** - Monitors duration per attempt
- 🛑 **Mandatory stops** - Pauses after each chunk for user review
- ✅ **Approval workflow** - User decides: approve, reject, or continue

## Installation

```bash
cd vibe_mcp
pip install -e .
```

## Setup in Cursor

Add to your Cursor MCP config (`~/.cursor/mcp.json`):

```json
{
  "mcpServers": {
    "vibe": {
      "command": "python",
      "args": ["/path/to/vibe_mcp/server.py"]
    }
  }
}
```

## Project Detection

The server automatically detects the project directory by:
1. `--project /path` argument (if provided)
2. `VIBE_PROJECT_DIR` environment variable (if set)
3. Auto-detect by searching upward for `.git` directory from cwd

This means the same MCP config works for **any project** — just open the project in Cursor and start coding!

## AI Tools (called by AI)

| Tool | Description |
|------|-------------|
| `start_chunk(name, mode)` | Create branch, start timer |
| `complete_chunk(summary)` | Signal done, STOP for user review |
| `get_status()` | Current chunk, time, attempts |
| `log_note(note)` | Save to working memory |

## CLI Commands (run by user)

```bash
# Initialize in project
vibe init

# Check status
vibe status

# After AI completes chunk:
vibe approve          # Merge to main
vibe reject           # Delete branch, start over
vibe cont -f "feedback"  # Continue with feedback
```

## Workflow

```
1. AI calls start_chunk("001-setup", "create")
   → Creates branch chunk/001-setup
   → Starts timer

2. AI works on chunk...

3. AI calls complete_chunk("Built the basic structure")
   → Logs completion
   → STOPS and waits

4. User reviews and runs:
   $ vibe approve    # Merges to main
   OR
   $ vibe reject     # Deletes branch
   OR
   $ vibe cont       # Keep working

5. Repeat for next chunk
```

## Files Created

- `.vibe_state.json` - Tracks current chunk, attempts, history
- `.vibe/working_memory.md` - AI scratch notes

## Why This Matters

Without enforcement, AI will:
- Keep debugging forever
- Modify working code accidentally  
- Proceed without verification

With Vibe MCP:
- Branches protect main
- Time-boxing forces chunk splitting
- Mandatory stops ensure user verification

