"""
Vibe Coding MCP Server

An MCP server that enforces the Vibe Coding workflow:
- Git branch per chunk
- Time and attempt tracking
- Mandatory stops after each chunk
- User approval/rejection workflow
"""

import json
import subprocess
import time
import os
import sys
from datetime import datetime
from pathlib import Path
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Initialize MCP server
server = Server("vibe-coding")


def find_project_root(start_path: Path = None) -> Path:
    """Find project root by looking for .git directory."""
    if start_path is None:
        start_path = Path.cwd()
    
    current = start_path.resolve()
    
    # Walk up looking for .git
    while current != current.parent:
        if (current / ".git").exists():
            return current
        current = current.parent
    
    # Fallback to start path if no .git found
    return start_path.resolve()


def get_project_dir() -> Path:
    """Get project directory from args, env, or auto-detect."""
    # 1. Check command line args
    for i, arg in enumerate(sys.argv):
        if arg == "--project" and i + 1 < len(sys.argv):
            return Path(sys.argv[i + 1])
    
    # 2. Check environment variable
    if "VIBE_PROJECT_DIR" in os.environ:
        return Path(os.environ["VIBE_PROJECT_DIR"])
    
    # 3. Auto-detect from cwd
    return find_project_root()


# Project directory (dynamically detected)
PROJECT_DIR = get_project_dir()

# State file location
STATE_FILE = PROJECT_DIR / ".vibe_state.json"

def load_state() -> dict:
    """Load current state from file."""
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {
        "current_chunk": None,
        "start_time": None,
        "attempts": [],
        "history": []
    }

def save_state(state: dict):
    """Save state to file."""
    STATE_FILE.write_text(json.dumps(state, indent=2, default=str))

def run_git(args: list[str]) -> tuple[bool, str]:
    """Run a git command and return (success, output)."""
    try:
        result = subprocess.run(
            ["/usr/bin/git"] + args,
            capture_output=True,
            text=True,
            check=True,
            cwd=str(PROJECT_DIR)
        )
        return True, result.stdout.strip()
    except subprocess.CalledProcessError as e:
        return False, e.stderr.strip()
    except Exception as e:
        return False, str(e)

def get_current_branch() -> str:
    """Get current git branch name."""
    success, output = run_git(["branch", "--show-current"])
    if success and output:
        return output
    # Fallback: try rev-parse
    success, output = run_git(["rev-parse", "--abbrev-ref", "HEAD"])
    if success and output:
        return output
    return "unknown"


def get_debug_info() -> str:
    """Get debug info about the server's environment."""
    info = []
    info.append(f"PROJECT_DIR: {PROJECT_DIR}")
    info.append(f"PROJECT_DIR exists: {PROJECT_DIR.exists()}")
    info.append(f"STATE_FILE: {STATE_FILE}")
    info.append(f".git exists: {(PROJECT_DIR / '.git').exists()}")
    
    success, branch = run_git(["branch", "--show-current"])
    info.append(f"git branch --show-current: success={success}, output='{branch}'")
    
    success, status = run_git(["status", "--porcelain"])
    info.append(f"git status: success={success}")
    
    state = load_state()
    info.append(f"turbo mode: {state.get('turbo', False)}")
    
    return "\n".join(info)


def auto_merge_chunk(chunk_name: str, summary: str = "") -> tuple[bool, str]:
    """Auto-merge a chunk (for turbo mode). Returns (success, message)."""
    branch_name = f"chunk/{chunk_name}"
    
    # AUTO-COMMIT: Stage and commit any uncommitted changes
    run_git(["add", "-A"])
    commit_msg = f"chunk-{chunk_name}: {summary}" if summary else f"chunk-{chunk_name}: Complete"
    success, output = run_git(["commit", "-m", commit_msg])
    # commit might fail if nothing to commit, that's okay
    
    # Create pre-merge tag for rollback safety
    success, _ = run_git(["tag", f"pre-chunk-{chunk_name}"])
    if not success:
        pass  # Tag might already exist, continue anyway
    
    # Switch to main
    success, output = run_git(["checkout", "main"])
    if not success:
        return False, f"Failed to switch to main: {output}"
    
    # Merge the branch
    merge_msg = f"chunk-{chunk_name}: Auto-merged (turbo mode)"
    success, output = run_git(["merge", branch_name, "-m", merge_msg])
    if not success:
        # Try to recover - go back to the branch
        run_git(["checkout", branch_name])
        return False, f"Failed to merge: {output}"
    
    # Create post-merge tag
    run_git(["tag", f"chunk-{chunk_name}"])
    
    # Delete the branch
    run_git(["branch", "-d", branch_name])
    
    return True, "Merged successfully"


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available tools."""
    return [
        Tool(
            name="start_chunk",
            description="Start a new chunk. Creates a git branch and logs start time.",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Chunk name (e.g., '001-setup')"},
                    "mode": {"type": "string", "enum": ["create", "edit"], "description": "Create or Edit mode"}
                },
                "required": ["name", "mode"]
            }
        ),
        Tool(
            name="complete_chunk",
            description="Signal that chunk work is complete. STOPS execution until user approves.",
            inputSchema={
                "type": "object",
                "properties": {
                    "summary": {"type": "string", "description": "Brief summary of what was done"}
                },
                "required": ["summary"]
            }
        ),
        Tool(
            name="get_status",
            description="Get current chunk status, elapsed time, and attempt count.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        ),
        Tool(
            name="log_note",
            description="Log a note to the working memory file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "note": {"type": "string", "description": "Note to log"}
                },
                "required": ["note"]
            }
        ),
        Tool(
            name="debug_info",
            description="Get debug info about the vibe server's environment.",
            inputSchema={
                "type": "object",
                "properties": {}
            }
        )
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    """Handle tool calls."""
    
    if name == "start_chunk":
        return await start_chunk(arguments["name"], arguments["mode"])
    elif name == "complete_chunk":
        return await complete_chunk(arguments["summary"])
    elif name == "get_status":
        return await get_status()
    elif name == "log_note":
        return await log_note(arguments["note"])
    elif name == "debug_info":
        return [TextContent(type="text", text=get_debug_info())]
    else:
        return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def start_chunk(chunk_name: str, mode: str) -> list[TextContent]:
    """Start a new chunk."""
    state = load_state()
    
    # Check if already in a chunk
    if state["current_chunk"]:
        return [TextContent(
            type="text",
            text=f"❌ Already in chunk '{state['current_chunk']}'. Complete or abandon it first."
        )]
    
    # Ensure we're on main
    current = get_current_branch()
    if current != "main":
        return [TextContent(
            type="text",
            text=f"❌ Not on main branch (on '{current}'). Switch to main first."
        )]
    
    # Create branch
    branch_name = f"chunk/{chunk_name}"
    success, output = run_git(["checkout", "-b", branch_name])
    
    if not success:
        return [TextContent(type="text", text=f"❌ Failed to create branch: {output}")]
    
    # Update state
    state["current_chunk"] = chunk_name
    state["mode"] = mode
    state["start_time"] = datetime.now().isoformat()
    state["attempts"].append({
        "number": len(state["attempts"]) + 1,
        "started": datetime.now().isoformat(),
        "status": "in_progress"
    })
    save_state(state)
    
    return [TextContent(
        type="text",
        text=f"""✅ Started chunk: {chunk_name}
📁 Branch: {branch_name}
🎯 Mode: {mode.upper()}
⏱️ Timer started

You may now begin working on this chunk.
Remember: Time-box to 5-10 minutes. Call complete_chunk when done."""
    )]


async def complete_chunk(summary: str) -> list[TextContent]:
    """Signal chunk completion."""
    state = load_state()
    
    if not state["current_chunk"]:
        return [TextContent(type="text", text="❌ No chunk in progress.")]
    
    chunk_name = state["current_chunk"]
    
    # Calculate duration
    start = datetime.fromisoformat(state["start_time"])
    duration = datetime.now() - start
    minutes = duration.total_seconds() / 60
    
    # Update current attempt
    if state["attempts"]:
        state["attempts"][-1]["completed"] = datetime.now().isoformat()
        state["attempts"][-1]["duration_min"] = round(minutes, 1)
        state["attempts"][-1]["summary"] = summary
    
    # Check if turbo mode is enabled
    turbo_mode = state.get("turbo", False)
    
    if turbo_mode:
        # AUTO-MERGE in turbo mode
        state["attempts"][-1]["status"] = "auto_merged"
        
        success, merge_msg = auto_merge_chunk(chunk_name, summary)
        
        if success:
            # Update history
            state["history"].append({
                "chunk": chunk_name,
                "status": "🏎️ auto-merged",
                "attempts": len(state["attempts"]),
                "completed": datetime.now().isoformat()
            })
            
            # Reset state for next chunk
            state["current_chunk"] = None
            state["start_time"] = None
            state["mode"] = None
            state["attempts"] = []
            save_state(state)
            
            return [TextContent(
                type="text",
                text=f"""
🏎️ CHUNK AUTO-MERGED (TURBO MODE)

┌─────────────────────────────────────┐
│ ✅ {chunk_name.ljust(30)} │
├─────────────────────────────────────┤
│ Duration: {str(round(minutes, 1)).ljust(24)} │
│ Committed: ✓                        │
│ Merged to main: ✓                   │
│ Tagged: ✓                           │
└─────────────────────────────────────┘

Summary: {summary}

🏷️ Tags created:
   • pre-chunk-{chunk_name} (rollback point)
   • chunk-{chunk_name} (completion marker)

📋 Pre-flight check for next chunk:
   • Lint errors addressed? (run read_lints if unsure)
   • Ready to continue? Start next chunk!

If rollback needed: vibe revert {chunk_name}"""
            )]
        else:
            # Merge failed, need manual intervention
            state["attempts"][-1]["status"] = "merge_failed"
            save_state(state)
            
            return [TextContent(
                type="text",
                text=f"""
❌ AUTO-MERGE FAILED

Chunk: {chunk_name}
Error: {merge_msg}

Please resolve manually:
  $ vibe approve   → Try manual merge
  $ vibe reject    → Delete branch, try again"""
            )]
    
    else:
        # Standard mode - auto-commit then wait for user approval
        run_git(["add", "-A"])
        commit_msg = f"chunk-{chunk_name}: {summary}" if summary else f"chunk-{chunk_name}: Complete"
        run_git(["commit", "-m", commit_msg])
        # commit might fail if nothing to commit, that's okay
        
        state["attempts"][-1]["status"] = "awaiting_review"
        save_state(state)
        
        return [TextContent(
            type="text",
            text=f"""
🛑 CHUNK COMPLETE — AWAITING USER REVIEW

┌─────────────────────────────────────┐
│ ⏸️ {chunk_name.ljust(30)} │
├─────────────────────────────────────┤
│ Mode: {state.get("mode", "unknown").upper().ljust(27)} │
│ Duration: {str(round(minutes, 1)).ljust(24)} │
│ Attempt: #{str(len(state["attempts"])).ljust(26)} │
│ Committed: ✓                        │
│ Awaiting merge: ⏳                  │
└─────────────────────────────────────┘

Summary: {summary}

📋 Pre-merge checklist:
   • Lint errors addressed? (run read_lints if unsure)
   • Code reviewed?

⏸️ DO NOT PROCEED until user provides status.

User options:
  $ vibe approve   → Merge to main, lock chunk
  $ vibe reject    → Delete branch, try again
  $ vibe continue  → Stay on branch, keep working

Waiting for user decision..."""
        )]


async def get_status() -> list[TextContent]:
    """Get current status."""
    state = load_state()
    
    if not state["current_chunk"]:
        return [TextContent(
            type="text",
            text="📊 No chunk in progress. Use start_chunk to begin."
        )]
    
    start = datetime.fromisoformat(state["start_time"])
    elapsed = datetime.now() - start
    minutes = elapsed.total_seconds() / 60
    
    return [TextContent(
        type="text",
        text=f"""📊 VIBE STATUS

Chunk: {state["current_chunk"]}
Mode: {state.get("mode", "unknown").upper()}
Branch: chunk/{state["current_chunk"]}
Elapsed: {round(minutes, 1)} minutes
Attempt: #{len(state["attempts"])}

{"⚠️ OVER TIME-BOX (>10 min)" if minutes > 10 else "✅ Within time-box"}
{"🔴 CONSIDER SPLITTING (>3 attempts)" if len(state["attempts"]) > 3 else ""}"""
    )]


async def log_note(note: str) -> list[TextContent]:
    """Log a note to working memory."""
    notes_dir = PROJECT_DIR / "notes"
    notes_dir.mkdir(exist_ok=True)
    
    notes_file = notes_dir / "working_memory.md"
    
    timestamp = datetime.now().strftime("%H:%M:%S")
    entry = f"\n[{timestamp}] {note}\n"
    
    with open(notes_file, "a") as f:
        f.write(entry)
    
    return [TextContent(
        type="text",
        text=f"📝 Note logged to {notes_file}"
    )]


async def main():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options()
        )


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())

