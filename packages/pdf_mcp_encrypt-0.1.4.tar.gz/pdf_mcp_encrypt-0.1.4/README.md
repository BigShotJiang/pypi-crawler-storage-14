# PDF 加密 MCP 服务

仅提供一个工具：`encrypt_pdf_file`，用于为 PDF 设置密码与权限，或进行光栅化加密。

## 运行

```bash
uv run pdf-mcp-server
```

或：

```bash
$env:PYTHONPATH="src"; python -c "import pdf_mcp.server; pdf_mcp.server.main()"
```

## 工具：encrypt_pdf_file

- `input_path` (str) 输入 PDF 文件路径
- `output_path` (str) 输出 PDF 文件路径
- `user_password` (str) 用户密码
- `owner_password` (str, 可选) 所有者密码
- `allow_printing/modifying/copying/annotating/fillingForms` (bool) 权限设置
- `mode` (str) 加密模式：`basic` 或 `rasterize`
- `dpi`/`image_format`/`quality` 光栅化参数（仅在 `rasterize` 模式）

## 示例

```
为 report.pdf 设置打开密码 123456，允许打印但禁止复制
```

## 依赖

- `fastmcp`
- `pikepdf`
- `pymupdf` (fitz)

## License

MIT
