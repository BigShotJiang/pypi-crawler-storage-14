from PIL import Image


def to_grayscale(input_path: str, output_path: str):
    """Load image from input_path, convert to grayscale, save to output_path."""
    img = Image.open(input_path)
    gray = img.convert("L")
    gray.save(output_path)

    # return gray
