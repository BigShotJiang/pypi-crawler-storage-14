from .core import to_grayscale

__all__ = ["to_grayscale"]
