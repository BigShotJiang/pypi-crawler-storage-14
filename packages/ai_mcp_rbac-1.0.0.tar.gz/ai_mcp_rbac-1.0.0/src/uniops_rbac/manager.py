"""RBAC Manager - maintains exact same interface as original code."""

import os as _os
from typing import List, Optional, Dict
import asyncpg
from uniops_rbac import _core

# Module-level singleton
_rbac_manager_instance: Optional['RBACManager'] = None


class RBACManager:
    """
    Role-Based Access Control Manager.
    
    Manages user permissions, roles, and authorization checks with:
    - PostgreSQL-backed storage
    - In-memory permission caching
    - Audit logging
    - Role assignment/revocation
    
    Environment Variables:
        RBAC_CACHE_TTL_SECONDS: Cache TTL in seconds (default: 300)
        RBAC_STRICT_MODE: Deny access on errors if 'true' (default: 'true')
        RBAC_AUDIT_ENABLED: Enable audit logging if 'true' (default: 'true')
    """
    
    def __init__(self, db_pool: asyncpg.Pool):
        self.db_pool = db_pool
        
        # Read from environment (same names as original)
        _cache_ttl = int(_os.getenv('RBAC_CACHE_TTL_SECONDS', '300'))
        self.permission_cache = _core._build_cache(1000, _cache_ttl)
        
        self._strict_mode = _os.getenv('RBAC_STRICT_MODE', 'true').lower() == 'true'
        self._audit_enabled = _os.getenv('RBAC_AUDIT_ENABLED', 'true').lower() == 'true'
    
    async def get_user_permissions(self, user_email: str) -> List[str]:
        """
        Get list of tool names user is authorized to access.
        
        Args:
            user_email: User's email address
            
        Returns:
            List of tool names (permission identifiers)
        """
        _cache_key = _core._gen_cache_key(user_email)
        
        if _cache_key in self.permission_cache:
            return self.permission_cache[_cache_key]
        
        try:
            _perms = await _core._fetch_user_perms(self.db_pool, user_email)
            self.permission_cache[_cache_key] = _perms
            return _perms
        except Exception:
            if self._strict_mode:
                raise
            return []
    
    async def check_permission(self, user_email: str, tool_name: str) -> bool:
        """
        Check if user has permission to access a specific tool.
        
        Args:
            user_email: User's email address
            tool_name: Tool/permission identifier
            
        Returns:
            True if user has permission, False otherwise
        """
        try:
            _perms = await self.get_user_permissions(user_email)
            _allowed = tool_name in _perms
            
            if self._audit_enabled:
                await _core._log_auth_event(
                    self.db_pool, user_email, tool_name, _allowed
                )
            
            return _allowed
        except Exception:
            if self._strict_mode:
                return False
            return True
    
    async def get_user_roles(self, user_email: str) -> List[Dict]:
        """
        Get user's assigned roles.
        
        Args:
            user_email: User's email address
            
        Returns:
            List of role dictionaries with id, name, description, etc.
        """
        try:
            return await _core._fetch_user_roles(self.db_pool, user_email)
        except Exception:
            return []
    
    async def assign_role(
        self,
        user_email: str,
        role_name: str,
        assigned_by: str,
        expires_at: Optional[object] = None
    ) -> bool:
        """Assign role to user."""
        try:
            async with self.db_pool.acquire() as conn:
                await conn.execute('''
                    INSERT INTO user_roles (user_id, role_id, assigned_by, expires_at)
                    SELECT u.id, r.id, $3, $4
                    FROM users u, roles r
                    WHERE u.email = $1 AND r.name = $2
                    ON CONFLICT (user_id, role_id) DO NOTHING
                ''', user_email, role_name, assigned_by, expires_at)
            
            self.clear_permission_cache(user_email)
            return True
        except Exception:
            return False
    
    async def revoke_role(self, user_email: str, role_name: str) -> bool:
        """Revoke role from user."""
        try:
            async with self.db_pool.acquire() as conn:
                await conn.execute('''
                    DELETE FROM user_roles
                    WHERE user_id = (SELECT id FROM users WHERE email = $1)
                    AND role_id = (SELECT id FROM roles WHERE name = $2)
                ''', user_email, role_name)
            
            self.clear_permission_cache(user_email)
            return True
        except Exception:
            return False
    
    def clear_permission_cache(self, user_email: Optional[str] = None):
        """Clear permission cache for user or all users."""
        if user_email:
            _key = _core._gen_cache_key(user_email)
            if _key in self.permission_cache:
                del self.permission_cache[_key]
        else:
            self.permission_cache.clear()


def init_rbac_manager(db_pool: asyncpg.Pool):
    """
    Initialize global RBAC manager instance.
    
    Args:
        db_pool: AsyncPG connection pool
    """
    global _rbac_manager_instance
    _rbac_manager_instance = RBACManager(db_pool)


def get_rbac_manager() -> RBACManager:
    """
    Get global RBAC manager instance.
    
    Returns:
        RBACManager instance
        
    Raises:
        RuntimeError: If manager not initialized
    """
    if _rbac_manager_instance is None:
        raise RuntimeError("RBAC Manager not initialized. Call init_rbac_manager() first.")
    return _rbac_manager_instance