"""Internal core logic with mild obfuscation."""

import asyncio as _aio
from datetime import datetime as _dt, timedelta as _td
from typing import List as _L, Optional as _O, Dict as _D
import jwt as _jwt_lib
from fastapi import HTTPException as _HE, status as _st
import asyncpg as _pg
from cachetools import TTLCache as _TC

# Obfuscated function names
def _build_cache(_max: int, _ttl: int) -> _TC:
    """Create permission cache."""
    return _TC(maxsize=_max, ttl=_ttl)

def _gen_cache_key(_email: str) -> str:
    """Generate cache key for user permissions."""
    return f"perms:{_email}"

async def _fetch_user_perms(_pool: _pg.Pool, _email: str) -> _L[str]:
    """Fetch user permissions from database."""
    _query = '''
        SELECT DISTINCT p.tool_name
        FROM users u
        JOIN user_roles ur ON u.id = ur.user_id
        JOIN role_permissions rp ON ur.role_id = rp.role_id
        JOIN permissions p ON rp.permission_id = p.id
        WHERE u.email = $1
        AND u.is_active = TRUE
        AND p.is_active = TRUE
        AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
    '''
    
    async with _pool.acquire() as _conn:
        _rows = await _conn.fetch(_query, _email)
        return [_row['tool_name'] for _row in _rows]

async def _fetch_user_roles(_pool: _pg.Pool, _email: str) -> _L[_D]:
    """Fetch user roles from database."""
    _query = '''
        SELECT 
            r.id,
            r.name,
            r.description,
            ur.assigned_at,
            ur.expires_at
        FROM users u
        JOIN user_roles ur ON u.id = ur.user_id
        JOIN roles r ON ur.role_id = r.id
        WHERE u.email = $1
        AND u.is_active = TRUE
        AND r.is_active = TRUE
        AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
    '''
    
    async with _pool.acquire() as _conn:
        _rows = await _conn.fetch(_query, _email)
        return [dict(_row) for _row in _rows]

async def _log_auth_event(
    _pool: _pg.Pool,
    _email: str,
    _resource: str,
    _allowed: bool,
    _details: _O[_D] = None
):
    """Log authorization event to audit table."""
    _query = '''
        INSERT INTO rbac_audit_log 
        (user_id, action, resource, result, details, timestamp)
        VALUES (
            (SELECT id FROM users WHERE email = $1),
            $2, $3, $4, $5, $6
        )
    '''
    
    async with _pool.acquire() as _conn:
        await _conn.execute(
            _query,
            _email,
            'permission_check',
            _resource,
            'allowed' if _allowed else 'denied',
            _details or {},
            _dt.now()
        )

def _encode_jwt_token(
    _payload: _D,
    _secret: str,
    _algo: str,
    _exp_delta: _O[_td] = None
) -> str:
    """Encode JWT token with expiration."""
    _data = _payload.copy()
    
    if _exp_delta:
        _exp = _dt.utcnow() + _exp_delta
    else:
        _exp = _dt.utcnow() + _td(minutes=30)
    
    _data.update({"exp": _exp, "iat": _dt.utcnow()})
    
    return _jwt_lib.encode(_data, _secret, algorithm=_algo)

def _decode_jwt_token(_token: str, _secret: str, _algo: str) -> _D:
    """Decode and validate JWT token."""
    try:
        return _jwt_lib.decode(_token, _secret, algorithms=[_algo])
    except _jwt_lib.ExpiredSignatureError:
        raise _HE(
            status_code=_st.HTTP_401_UNAUTHORIZED,
            detail="Token has expired"
        )
    except _jwt_lib.JWTError:
        raise _HE(
            status_code=_st.HTTP_401_UNAUTHORIZED,
            detail="Could not validate token"
        )