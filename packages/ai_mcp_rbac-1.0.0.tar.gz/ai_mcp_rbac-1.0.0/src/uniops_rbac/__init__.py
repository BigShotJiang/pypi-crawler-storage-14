"""
UniOps RBAC - Role-Based Access Control System

This package provides a complete RBAC implementation with:
- PostgreSQL-backed permission management
- JWT token-based authentication
- Per-user permission caching
- Audit logging
- Role assignment/revocation

Usage:
    >>> from uniops_rbac import init_rbac_manager, get_rbac_manager, JWTManager
    >>> 
    >>> # Initialize with asyncpg pool
    >>> init_rbac_manager(db_pool)
    >>> 
    >>> # Get manager instance
    >>> rbac = get_rbac_manager()
    >>> 
    >>> # Check permissions
    >>> allowed = await rbac.check_permission('user@example.com', 'admin_tool')
    >>> 
    >>> # Create JWT token
    >>> token = JWTManager.create_access_token('user@example.com', ['read', 'write'])
"""

from uniops_rbac.manager import RBACManager, init_rbac_manager, get_rbac_manager
from uniops_rbac.jwt_handler import JWTManager

__version__ = "1.0.0"
__all__ = [
    "RBACManager",
    "JWTManager", 
    "init_rbac_manager",
    "get_rbac_manager",
]