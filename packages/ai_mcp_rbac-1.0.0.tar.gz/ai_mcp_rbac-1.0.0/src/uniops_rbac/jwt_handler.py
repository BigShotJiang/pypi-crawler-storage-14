"""JWT Token Manager - maintains exact same interface."""

import os as _os
from datetime import timedelta
from typing import List, Optional, Dict
from uniops_rbac import _core


class JWTManager:
    """
    JWT Token Management for RBAC.
    
    Provides methods to create and decode JWT tokens for authentication
    and permission validation.
    
    Environment Variables:
        JWT_SECRET_KEY: Secret key for signing tokens (required)
        JWT_ALGORITHM: Algorithm for JWT encoding (default: 'HS256')
        JWT_ACCESS_TOKEN_EXPIRE_MINUTES: Token expiration in minutes (default: 30)
    """
    
    @staticmethod
    def create_access_token(
        user_email: str,
        permissions: List[str],
        expires_delta: Optional[timedelta] = None
    ) -> str:
        """
        Create JWT access token with user permissions.
        
        Args:
            user_email: User's email address
            permissions: List of permission identifiers
            expires_delta: Custom expiration timedelta (optional)
            
        Returns:
            Encoded JWT token string
        """
        _secret = _os.getenv('JWT_SECRET_KEY')
        if not _secret:
            raise ValueError("JWT_SECRET_KEY environment variable not set")
        
        _algo = _os.getenv('JWT_ALGORITHM', 'HS256')
        
        _payload = {
            "sub": user_email,
            "email": user_email,
            "permissions": permissions,
            "type": "access"
        }
        
        if not expires_delta:
            _exp_min = int(_os.getenv('JWT_ACCESS_TOKEN_EXPIRE_MINUTES', '30'))
            expires_delta = timedelta(minutes=_exp_min)
        
        return _core._encode_jwt_token(_payload, _secret, _algo, expires_delta)
    
    @staticmethod
    def decode_token(token: str) -> Dict:
        """
        Decode and validate JWT token.
        
        Args:
            token: JWT token string
            
        Returns:
            Decoded token payload
            
        Raises:
            HTTPException: If token is expired or invalid
        """
        _secret = _os.getenv('JWT_SECRET_KEY')
        if not _secret:
            raise ValueError("JWT_SECRET_KEY environment variable not set")
        
        _algo = _os.getenv('JWT_ALGORITHM', 'HS256')
        
        return _core._decode_jwt_token(token, _secret, _algo)