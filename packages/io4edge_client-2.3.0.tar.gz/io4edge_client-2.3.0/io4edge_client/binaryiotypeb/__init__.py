# SPDX-License-Identifier: Apache-2.0

from .client import Client
import io4edge_client.api.binaryIoTypeB.python.binaryIoTypeB.v1alpha1.binaryIoTypeB_pb2 as Pb

__all__ = ["Client", "Pb"]
