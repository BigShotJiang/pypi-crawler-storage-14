class CommandTemporaryUnavailableError(Exception):
    """Exception raised when a command cannot be processed temporarily."""
