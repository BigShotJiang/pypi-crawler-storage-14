# SPDX-License-Identifier: Apache-2.0
version = (2, 3, 0)
VERSION = "%d.%d.%d" % version
