# PARC Cognitive Shape Engine SDK — Dual License

Copyright (c) 2025 Jared Lewis

This SDK is offered under a **dual-license model**:

---

## 1. MIT License (Free Use)

You may use, modify, copy, and distribute this software **for personal, educational, or research purposes** under the MIT License.

See the full MIT text below.

---

## 2. Commercial License (Required for Paid or Production Use)

Any use of this software in:
- commercial products  
- paid tutoring systems  
- EdTech platforms  
- AI assistants  
- school district software  
- enterprise applications  
- SaaS or subscription products  
- any system generating revenue  

**requires a commercial license**.

Contact:

**jn.lewis1@outlook.com**

---

# MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the “Software”), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, **subject to the following conditions**:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

