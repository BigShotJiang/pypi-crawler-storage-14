"""
SPT Neo RAG Client.

A Python client library for interacting with the SPT Neo RAG API.
"""

__version__ = "0.3.0"

from .client import NeoRagClient
from .exceptions import (
    NeoRagException,
    NeoRagApiError,
    AuthenticationError,
    ConfigurationError,
    NetworkError,
)
from .models import (
    # Enums
    AllowedWebhookMethods,
    KnowledgeGraphExtractionStrategy,
    RaptorTreeStatus,
    RaptorNodeType,
    # User models
    Token,
    UserCreate,
    UserResponse,
    UserUpdate,
    UserResponseMinimal,
    PasswordResetRequest,
    # API Key models
    ApiKeyCreate,
    ApiKeyResponse,
    ApiKeyFullResponse,
    ApiKeyUpdate,
    # Knowledge Base models
    KnowledgeBaseCreate,
    KnowledgeBaseUpdate,
    KnowledgeBaseConfigUpdate,
    KnowledgeBaseResponse,
    KnowledgeBaseResponseMinimal,
    KnowledgeBaseWebhookConfigUpdate,
    # Document models
    DocumentCreate,
    DocumentUpdate,
    DocumentResponse,
    DocumentChunkResponse,
    DocumentPageImageResponse,
    DocumentContentResponse,
    BoundingBox,
    # Query models
    QueryRequest,
    QueryResponse,
    QueryResult,
    QueryResultSource,
    QueryStrategyResponse,
    SourcesResponse,
    # Task models
    TaskResponse,
    # Structured Schema models
    StructuredSchemaCreateRequest,
    StructuredSchemaUpdateRequest,
    StructuredSchemaResponse,
    # Team models
    TeamCreate,
    TeamUpdate,
    TeamResponse,
    TeamDetailResponse,
    # Health models
    HealthCheckComponent,
    HealthCheckResponse,
    DetailedHealthCheckResponse,
    # Knowledge Graph models
    KGEntityResponse,
    KGRelationshipNode,
    KGRelationshipInfo,
    KGRelationshipDetailResponse,
    KGPathSegment,
    KGProcessedDocumentResponse,
    PaginatedKGEntityResponse,
    # Model management
    ModelInfo,
    ModelCreateRequest,
    ModelUpdateRequest,
    ModelDeleteResponse,
    # RAPTOR models
    RaptorTreeCreate,
    RaptorTreeUpdate,
    RaptorTreeResponse,
    RaptorNodeResponse,
    # Admin models
    TokenUsageRecord,
    TokenUsageResponse,
    MaintenanceResponse,
    AuditRecordResponse,
    AuditCheckResponse,
    AuditCleanupResponse,
    LicenseStatusResponse,
    # Utility models
    CountResponse,
    StringListResponse,
    PublicSettings,
)

__all__ = [
    # Client
    "NeoRagClient",
    # Exceptions
    "NeoRagException",
    "NeoRagApiError",
    "AuthenticationError",
    "ConfigurationError",
    "NetworkError",
    # Enums
    "AllowedWebhookMethods",
    "KnowledgeGraphExtractionStrategy",
    "RaptorTreeStatus",
    "RaptorNodeType",
    # User models
    "Token",
    "UserCreate",
    "UserResponse",
    "UserUpdate",
    "UserResponseMinimal",
    "PasswordResetRequest",
    # API Key models
    "ApiKeyCreate",
    "ApiKeyResponse",
    "ApiKeyFullResponse",
    "ApiKeyUpdate",
    # Knowledge Base models
    "KnowledgeBaseCreate",
    "KnowledgeBaseUpdate",
    "KnowledgeBaseConfigUpdate",
    "KnowledgeBaseResponse",
    "KnowledgeBaseResponseMinimal",
    "KnowledgeBaseWebhookConfigUpdate",
    # Document models
    "DocumentCreate",
    "DocumentUpdate",
    "DocumentResponse",
    "DocumentChunkResponse",
    "DocumentPageImageResponse",
    "DocumentContentResponse",
    "BoundingBox",
    # Query models
    "QueryRequest",
    "QueryResponse",
    "QueryResult",
    "QueryResultSource",
    "QueryStrategyResponse",
    "SourcesResponse",
    # Task models
    "TaskResponse",
    # Structured Schema models
    "StructuredSchemaCreateRequest",
    "StructuredSchemaUpdateRequest",
    "StructuredSchemaResponse",
    # Team models
    "TeamCreate",
    "TeamUpdate",
    "TeamResponse",
    "TeamDetailResponse",
    # Health models
    "HealthCheckComponent",
    "HealthCheckResponse",
    "DetailedHealthCheckResponse",
    # Knowledge Graph models
    "KGEntityResponse",
    "KGRelationshipNode",
    "KGRelationshipInfo",
    "KGRelationshipDetailResponse",
    "KGPathSegment",
    "KGProcessedDocumentResponse",
    "PaginatedKGEntityResponse",
    # Model management
    "ModelInfo",
    "ModelCreateRequest",
    "ModelUpdateRequest",
    "ModelDeleteResponse",
    # RAPTOR models
    "RaptorTreeCreate",
    "RaptorTreeUpdate",
    "RaptorTreeResponse",
    "RaptorNodeResponse",
    # Admin models
    "TokenUsageRecord",
    "TokenUsageResponse",
    "MaintenanceResponse",
    "AuditRecordResponse",
    "AuditCheckResponse",
    "AuditCleanupResponse",
    "LicenseStatusResponse",
    # Utility models
    "CountResponse",
    "StringListResponse",
    "PublicSettings",
]
