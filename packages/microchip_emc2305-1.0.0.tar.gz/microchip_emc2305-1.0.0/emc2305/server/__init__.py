"""
gRPC Server

Remote control server for EMC2305 driver (optional feature).
"""

# Server implementation can be added if gRPC support is needed
