# Dataclass helpers - `libtmux._internal.dataclasses`

```{eval-rst}
.. automodule:: libtmux._internal.dataclasses
   :members:
   :special-members:

```
