def applications():
    print("\n==============================================================")
    print("      APPLICATION CASES — WHICH GRAPH ALGORITHM TO USE?")
    print("==============================================================\n")

    # BFS APPLICATIONS
    print("1. BFS (Breadth-First Search)")
    print("----------------------------------------------------------------")
    print("Use BFS when you need:")
    print("   • Shortest path in unweighted networks (social networks, grids).")
    print("   • Finding minimum number of moves in puzzles (like 8-puzzle states).")
    print("   • Level-wise exploration (web crawling, peer-to-peer systems).")
    print("   • Checking bipartiteness.")
    print("   • Flood-fill (image segmentation).")
    print("   • Spread/propagation simulations (rumors, viruses).\n")

    # DFS APPLICATIONS
    print("2. DFS (Depth-First Search)")
    print("----------------------------------------------------------------")
    print("Use DFS when you need:")
    print("   • Detecting cycles in directed or undirected graphs.")
    print("   • Topological sorting of tasks with dependencies.")
    print("   • Finding articulation points / bridges in networks.")
    print("   • Generating mazes and exploring deep paths.")
    print("   • Solving puzzles like Sudoku (backtracking).")
    print("   • Checking connectivity of a graph.\n")

    # DIJKSTRA APPLICATIONS
    print("3. Dijkstra’s Algorithm")
    print("----------------------------------------------------------------")
    print("Use Dijkstra when you need:")
    print("   • Shortest path in maps/GPS with positive weights (road distances).")
    print("   • Network routing (OSPF routing protocol).")
    print("   • Finding minimum travel time or cost (transport systems).")
    print("   • Optimal scheduling with positive delays.")
    print("   • Game pathfinding (AI movement).")
    print("Weights must be non-negative.\n")

    # BELLMAN-FORD APPLICATIONS
    print("4. Bellman–Ford Algorithm")
    print("----------------------------------------------------------------")
    print("Use Bellman-Ford when you need:")
    print("   • Shortest paths AND negative edge weights exist.")
    print("   • Detecting negative cycles (financial arbitrage detection).")
    print("   • Distance calculation over unreliable networks.")
    print("   • Routing with link-cost estimation (distance-vector protocols).")
    print("\nWhen you see negative weights → choose Bellman-Ford immediately.\n")

    # FLOYD-WARSHALL APPLICATIONS
    print("5. Floyd–Warshall Algorithm")
    print("----------------------------------------------------------------")
    print("Use Floyd-Warshall when you need:")
    print("   • All-pairs shortest paths in a dense graph.")
    print("   • Computing reachability matrix (transitive closure).")
    print("   • Checking if every node can reach every other node.")
    print("   • Precomputing shortest paths for repeated queries.")
    print("\nPerfect for small graphs that require fast repeated lookup.\n")

    # KRUSKAL APPLICATIONS
    print("6. Kruskal’s Algorithm")
    print("----------------------------------------------------------------")
    print("Use Kruskal when you need:")
    print("   • Minimum spanning tree (MST) in sparse graphs.")
    print("   • Building network backbones (communication, electricity).")
    print("   • Clustering algorithms (finding cluster trees).")
    print("   • When edges can be sorted easily.")
    print("\nUsed in: Electrical circuits, designing minimum-cost networks.\n")

    # PRIM APPLICATIONS
    print("7. Prim’s Algorithm")
    print("----------------------------------------------------------------")
    print("Use Prim when you need:")
    print("   • MST in dense graphs.")
    print("   • Growing the MST from a single starting node.")
    print("   • Network design with adjacency matrix representation.")
    print("\nUsed in: Fiber-optic layout, road network planning.\n")

    # TOPOLOGICAL SORT APPLICATIONS
    print("8. Topological Sorting")
    print("----------------------------------------------------------------")
    print("Use Topological Sorting when you need:")
    print("   • Task scheduling with prerequisites.")
    print("   • Course dependency planning in universities.")
    print("   • Build systems (ordering compilation).")
    print("   • Resolving package installation order.")
    print("\nWorks only on DAGs (directed acyclic graphs).\n")

    # SCC APPLICATIONS
    print("9. Strongly Connected Components (Tarjan/Kosaraju)")
    print("----------------------------------------------------------------")
    print("Use SCC algorithms when you need:")
    print("   • Identify 'cycles' of mutually reachable nodes (software modules).")
    print("   • Decompose a directed graph into DAG of components.")
    print("   • Analyze control flow graphs (compiler optimization).")
    print("   • Social network clusters where everyone can reach everyone.")
    print("\nUseful for condensation graphs and high-level structure understanding.\n")

    # MATCHING AND FLOW
    print("10. Max Flow / Min Cut (Ford-Fulkerson, Edmonds-Karp, Dinic)")
    print("----------------------------------------------------------------")
    print("Use Flow Algorithms when you need:")
    print("   • Maximum bipartite matching (job assignment).")
    print("   • Network routing with capacity limits.")
    print("   • Finding bottlenecks in a network (min-cut).")
    print("   • Traffic optimization, supply chain management.")
    print("   • Image segmentation (graph-cut).")
    print("\nFlow = optimization of movement under capacity constraints.\n")

    # DAG shortest path
    print("11. Shortest Path in DAG (Topological + DP)")
    print("----------------------------------------------------------------")
    print("Use when:")
    print("   • Graph is directed AND acyclic.")
    print("   • Edge weights may be positive or negative.")
    print("   • Need fastest possible shortest path algorithm (linear time).")
    print("\nExtremely fast because no cycles.\n")

    # CYCLE DETECTION
    print("12. Cycle Detection")
    print("----------------------------------------------------------------")
    print("Use cycle detection when you need:")
    print("   • Deadlock detection in operating systems.")
    print("   • Consistency checking in dependency graphs.")
    print("   • Feedback loop detection in circuits.")
    print("   • Loop finding in linked lists (Floyd’s cycle algo).")
    print("\nDFS-based cycle detection is the standard.\n")
