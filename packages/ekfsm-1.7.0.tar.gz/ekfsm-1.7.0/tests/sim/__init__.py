# flake8: noqa
from ...ekfsm.simctrl import register_gpio_simulations

__all__ = "register_gpio_simulations"
