from __future__ import annotations

from openai.types.beta.threads.file_path_delta_annotation import *  # noqa: F401, F403
