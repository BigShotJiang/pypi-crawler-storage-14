from __future__ import annotations

from openai.types.embedding import *  # noqa: F401, F403
