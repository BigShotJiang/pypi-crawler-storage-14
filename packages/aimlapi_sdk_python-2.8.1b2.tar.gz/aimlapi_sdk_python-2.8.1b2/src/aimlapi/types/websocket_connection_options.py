from __future__ import annotations

from openai.types.websocket_connection_options import *  # noqa: F401, F403
