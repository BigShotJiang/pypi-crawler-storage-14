from __future__ import annotations

from openai.types.audio.transcription_text_done_event import *  # noqa: F401, F403
