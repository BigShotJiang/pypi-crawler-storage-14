from __future__ import annotations

from openai.types.audio import *  # noqa: F401, F403
