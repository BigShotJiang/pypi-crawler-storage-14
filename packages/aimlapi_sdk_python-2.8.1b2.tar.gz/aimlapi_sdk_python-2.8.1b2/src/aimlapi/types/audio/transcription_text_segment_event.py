from __future__ import annotations

from openai.types.audio.transcription_text_segment_event import *  # noqa: F401, F403
