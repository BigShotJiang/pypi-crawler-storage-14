from __future__ import annotations

from openai.resources.uploads.parts import *  # noqa: F401, F403
