# gcp_route_optimizer

`gcp_route_optimizer` is a lightweight Python library that simplifies using the **Google Fleet Routing / OptimizeTours API**.

It automatically:
- Extracts the `project_id` from your Google Service Account JSON
- Generates OAuth tokens using the service account credentials
- Builds shipment and vehicle structures
- Sends requests to the OptimizeTours API
- Returns optimized route information (polyline + visit sequence)

This library contains **no AWS, SSM, Flask, or database code**, making it reusable in any project.

---

## 🚀 Features

- Simple and clean API
- Pure Google Route Optimization logic
- Auto token generation from service account JSON
- Zero cloud-specific dependencies
- Python 3.9+ compatible

---

## 📦 Installation

```bash
pip install gcp-route-optimizer
🔧 Basic Usage
python
Copy code
from gcp_route_optimizer import RouteOptimizer

# Google service account JSON (loaded from file, env, or SSM)
service_account_json = {
    "type": "service_account",
    "project_id": "your-project-id",
    "private_key": "...",
    "client_email": "...",
    ...
}

# Your warehouse or starting location
warehouse = {"lat": 11.01897, "lng": 77.00651}

# Orders to optimize
orders = [
    {"delivery_lat": 11.05, "delivery_lng": 77.10},
    {"delivery_lat": 11.02, "delivery_lng": 77.03}
]

optimizer = RouteOptimizer(
    service_account_json=service_account_json,
    warehouse_location=warehouse
)

result, success = optimizer.optimize(orders)

if success:
    print("Polyline:", result["polyline"])
    print("Visits:", result["visits"])
else:
    print("Error:", result["error"])
📤 Result Format
The library returns:

python
Copy code
{
  "polyline": "<encoded_polyline_string>",
  "visits": [
    {"shipmentLabel": "0", ...},
    {"shipmentLabel": "1", ...}
  ]
}
📘 Requirements
Python 3.9+

Google Cloud project with Fleet Routing API enabled

A valid Google Service Account JSON

🧩 Why This Library?
Keeps your app code clean

Avoids rewriting token / optimizeTours logic

Works with any framework or cloud provider

Ideal for logistics, delivery apps, and fleet systems

📜 License
MIT License — free for personal and commercial use.