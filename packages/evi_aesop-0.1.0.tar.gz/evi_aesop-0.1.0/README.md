# evi-aesop

## Instalação

```bash
pip install evi-aesop
```

## Uso

```python
from evi-aesop import evi
```
