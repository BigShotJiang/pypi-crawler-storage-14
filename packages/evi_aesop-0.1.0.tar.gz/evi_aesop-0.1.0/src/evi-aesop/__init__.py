"""evi-aesop"""
__version__ = "0.1.0"

from .evi import evi


__all__ = ["evi"]
