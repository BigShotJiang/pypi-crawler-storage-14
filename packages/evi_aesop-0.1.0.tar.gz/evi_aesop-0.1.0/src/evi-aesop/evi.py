import polars as pl


DROP_COLUMNS = [
    "kf",
    "ind",
    "ind_2",
    "k_opt",
    "tseries",
    "std_windows",
    "mean_windows",
    "evi_t1_t",
    "cat_mu",
    "cat_evi"
]


def evi(
    df: pl.DataFrame | pl.LazyFrame,
    series: str,
    m=5,
    r_a=4,
    mu=8,
    c=0.2
):
    df = (
        df.lazy()
        .sort("year_week")
        .with_columns(
            pl.col(series)
            .rolling_mean(window_size=r_a)
            .fill_nan(0)
            .fill_null(0)
            .alias("tseries")
        )
        .with_columns(
            pl.col("tseries")
            .rolling_std(window_size=m)
            .alias("std_windows")
        )
        .with_columns((
                (pl.col("std_windows") - pl.col("std_windows").shift())
                / abs(pl.col("std_windows").shift())
            ).fill_null(0).round(2).alias("evi_t1_t")
        )
        .with_columns(
            pl.when(pl.col("evi_t1_t").is_infinite())
            .then(pl.lit(0))
            .otherwise(pl.col("evi_t1_t"))
            .alias("evi_t1_t")
        ).with_columns(
            pl.col(series)
            .rolling_mean(window_size=mu)
            .fill_null(0)
            .alias("mean_windows")
        ).with_columns(
            pl.when(
                (pl.col(series) >= 0.75 * pl.col("mean_windows")) &
                (pl.col(series) < pl.col("mean_windows"))
            ).then(0.5)
            .when(
                pl.col(series) >= pl.col("mean_windows")
            ).then(1).otherwise(0).alias("cat_mu")
        ).with_columns(
            (pl.col("evi_t1_t") >= c).cast(pl.Int8).alias("cat_evi")
        ).with_columns(
            pl.when(
                (pl.col("cat_evi") == 1) & (pl.col("cat_mu") == 1)
            ).then(1).otherwise(0).alias("ind")
        ).with_columns(
            pl.when(
                (pl.col("evi_t1_t") > c) & (pl.col("cat_mu") == 1)
            ).then(1).otherwise(0).alias("ind_2")
        ).with_columns(
            (
                (pl.col(series) - pl.col("mean_windows")) /
                ((1 + c) * pl.col("std_windows").shift())
            ).alias("k_opt")
        ).with_columns(
            (
                pl.col("tseries") +
                pl.col("k_opt").abs() *
                (1 + c) *
                pl.col("std_windows").shift()
            ).fill_nan(0).fill_null(0).cast(pl.Int32).alias("upperbound")
        ).with_columns(
            pl.when(
                pl.col(series) > pl.col("upperbound")
            ).then(1).otherwise(0).alias("alarm")
        ).rename({"ano": "epiyear"})
        .select("alarm", "upperbound")
    )
    return df
