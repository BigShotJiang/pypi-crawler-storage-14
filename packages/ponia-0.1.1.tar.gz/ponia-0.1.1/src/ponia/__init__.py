"""Ponia: Query pandas DataFrames with natural language."""

from .ponia import ponia

__version__ = "0.1.0"
__all__ = ["ponia"]
