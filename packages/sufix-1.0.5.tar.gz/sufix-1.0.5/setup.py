from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="sufix",
    version="1.0.5",
    author="Sufiyan",
    author_email="sufibuisness@gmail.com",
    description="Unlimited free LLM chat - No API key needed!",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Sufiyan65889",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests>=2.25.0",
    ],
)