"""
Sufi AI - Unlimited Free LLM Chat
"""

__version__ = "1.0.5"

import requests
import sys
import os

def chat(message, api_key="SufiLLM-33990wAGjPP6PpdPm2iApi"):
    # Check if user is using correct format
    import traceback
    stack = traceback.extract_stack()
    if len(stack) >= 2:
        calling_frame = stack[-2]
        calling_code = calling_frame.line
        
        # Check if user is using proper format
        if calling_code and ("response" not in calling_code or "print(response)" not in calling_code):
            print("⚠️  ERROR: Please use correct format:")
            print("import sufix")
            print("response = sufix.chat('Your message')")  
            print("print(response)")
    
    url = "https://sufi-api-llm.vercel.app/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "messages": [{"role": "user", "content": message}]
    }
    
    try:
        r = requests.post(url, headers=headers, json=data)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"Error: {str(e)}"

# For direct script execution
if __name__ == "__main__":
    while True:
        msg = input("You: ")
        if msg.lower() in ["exit", "quit", "bye"]:
            break
        print("Sufi AI:", chat(msg))
        print("-" * 50)