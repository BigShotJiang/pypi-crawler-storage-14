import pandas as pd
import pymysql


class DatabaseManger:
    def __init__(self, host, port=3306, user='root', password='root', database='sale_analysis_db'):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.database = database
        self.conn = None
        self.cursor = None

    def conn_db(self):
        try:
            self.conn = pymysql.connect(host=self.host, port=self.port, user=self.user, password=self.password,
                                        database=self.database, charset='utf8mb4')
            self.cursor = self.conn.cursor()
            return True
        except Exception as e:
            print(e)
            return False
    # 加载数据
    def load_cleaned_data(self) :
        df = pd.read_csv('../output/clean_sale_data.csv')
        print(df['order_date'].dtype)
    # 提取数据插入到数据库
    def extral_data_insert_db(self):
        print()

    # 从数据库查询数据
    def query_data_from_db(self):
        print()

    def close_db(self):
        self.conn.close()


def main():
    print()
    db_manager = DatabaseManger(host='127.0.0.1')
    db_manager.conn_db()
    db_manager.extral_data_insert_db()
    db_manager.query_data_from_db()
    db_manager.close_db()


if __name__ == "__main__":
    main()
