import pandas as pd
import pymysql

db_config = {
    'host': '120.55.6.12',
    'port': 3306,
    'user': 'root',
    'password': 'Chen@123456',
    'charset': 'utf8mb4',
    'database': 'ecm_analysis'
}


def query_data(sql):
    conn = pymysql.connect(**db_config)
    try:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            result = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            return pd.DataFrame(result, columns=columns)
    except Exception as e:
        print(e)
        return None
    finally:
        conn.close()
