import  pandas as pd
import pymysql
cleaned_data = pd.read_csv("./clean.csv")

db_config = {
    'host':'120.55.6.12',
    'port': 3306,
    'user':'root',
     'password':'Chen@123456',
    'charset':'utf8mb4',
    'database':'ecm_analysis'
}

def insert_data(data,table_name) :
    conn = pymysql.connect(**db_config)
    try :
        with conn.cursor() as cursor :
            cursor.execute(f" DELETE FROM {table_name}")
            for index,row in data.iterrows() :
                sql = f" insert into {table_name} ({' ,'.join(row.index)}) values({' ,'.join(['%s']*len(row))})"
                cursor.execute(sql,tuple(row))
            conn.commit()
    except Exception as e :
        print(e)
        conn.rollback()
    finally:
        conn.close()

insert_data(cleaned_data,'orders')