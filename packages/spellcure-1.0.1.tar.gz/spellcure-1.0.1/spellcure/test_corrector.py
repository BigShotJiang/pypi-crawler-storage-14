from spellcure import corrector  # Correct import path and class name

def test_small():
    model = corrector(mode="small")  # Use the correct class name
    output = model.correct("olve")
    print(output)
    assert isinstance(output, str)
    assert output.strip() != ""
test_small()