from spellcure.corrector import corrector  # Correct import path and class name

def test_small_mode_basic():
    model = corrector(mode="small")  # Use the correct class name
    output = model.correct("thsi is a tset")
    assert isinstance(output, str)
    assert output.strip() != ""
