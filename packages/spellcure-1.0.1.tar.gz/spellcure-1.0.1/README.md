# SpellCure

**SpellCure** is a mathematical correction engine for **highly scrambled or distorted text**, created by **Saheban Khan**.  
Instead of machine learning, SpellCure uses a **position-weighted ratio algorithm** to compute similarity between distorted tokens and valid dictionary words.

It is designed to recover words even when the input is heavily jumbled — far beyond simple typo correction.

---

## ✨ Features

- Corrects **heavily scrambled** words  
- Pure **math-based algorithm** — no ML required  
- Supports both a **small built-in vocabulary** and **NLTK’s large word corpus**  
- Works on sentences, single words, or mixed noisy text  
- Fast, deterministic, and easy to integrate in other projects  

---

## 🧠 How SpellCure Works

SpellCure compares each input token against vocabulary words using:

- **position-based character similarity**
- **ratio scoring**
- **recursive refinement steps**
- **optional large NLTK vocabulary**

This allows SpellCure to recover the correct word even when the text looks like:

- `"aplpe"` → `"apple"`
- `"ths si a tset"` → `"this is a test"`
- `"tihs wrod is msesdy"` → `"this word is messy"`
---
## EXAMPLE from spellcure import SpellCure 
# Use small built-in vocabulary 
model = SpellCure(mode="small") 
print(model.correct("ths si a tset")) 
# Output: this is a test # Use NLTK's large vocabulary 
model = SpellCure(mode="large") print(model.correct("aplpe"))
---

## 🚀 Installation

Install the library using pip:

```bash
pip install spellcure
