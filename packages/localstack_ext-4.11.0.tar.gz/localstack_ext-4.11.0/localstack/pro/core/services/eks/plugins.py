from localstack.packages import Package
from localstack.pro.core.packages.core import pro_package
@pro_package(name='k3d')
def k3d_package()->Package:from localstack.pro.core.services.eks.packages import k3d_package as A;return A
@pro_package(name='velero')
def velero_package()->Package:from localstack.pro.core.services.eks.packages import velero_package as A;return A