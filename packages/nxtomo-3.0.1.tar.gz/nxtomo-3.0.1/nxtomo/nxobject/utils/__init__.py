"""Module providing NXobject mixin classes."""

from .concatenate import concatenate  # noqa F401
