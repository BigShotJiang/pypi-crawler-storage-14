"""Paths of the different components in the NXtomo application."""
