To use this module, you need to:

1.  Go to Sales -\> Products and select or create a product.
2.  Check "Is a contract" and select the contract template related to
    the product
3.  Define default recurrence rules
