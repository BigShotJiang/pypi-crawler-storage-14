#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 19:52:50 2024

@author: ncro8394
"""



def eel():
    
    '''
        Excitatory Event Locater (EEL)
    
        An automative detection of cortical arousals.
    
    '''
    
    return