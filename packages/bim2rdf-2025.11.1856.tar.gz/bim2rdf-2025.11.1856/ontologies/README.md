`python -m bim2rdf.cli.main ontologies --help`
