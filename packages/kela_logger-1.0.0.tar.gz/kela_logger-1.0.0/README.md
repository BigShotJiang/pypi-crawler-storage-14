# Kela Logger

A lightweight logging utility for Python applications.

## Installation

```bash
pip install kela-logger
```

## Quick Start

```python
from kela_logger import get_logger

# Get a logger instance
logger = get_logger("my_app")

# Log messages
logger.info("Application started")
logger.debug("Debug information")
logger.warning("Warning message")
logger.error("Error occurred")

# Set log level
logger.set_level("DEBUG")
```

## Configuration

```python
from kela_logger import configure

configure(
    enabled=True,  # Enable/disable logging
)
```

## Features

- Simple and lightweight
- Multiple log levels (DEBUG, INFO, WARNING, ERROR)
- Named loggers for different modules
- Thread-safe operation

## License

MIT License
