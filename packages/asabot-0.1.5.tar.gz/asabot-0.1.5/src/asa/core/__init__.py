"""内部核心子包。

通常用户只需要从顶层 `asa` 导入：

    from asa import QQBot, ConfigError
"""

