"""MsAction table services for Conbus."""
