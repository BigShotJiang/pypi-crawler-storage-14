"""
Setup script for Python Multi-Level Obfuscator
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README file
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

# Read requirements
requirements = []
with open('requirements.txt', 'r', encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith('#'):
            # Handle platform-specific packages
            if ';' in line:
                package, condition = line.split(';', 1)
                requirements.append(package.strip())
            else:
                requirements.append(line)

setup(
    name="python-multi-level-obfuscator",
    version="1.0.0",
    author="MiniMax Agent",
    author_email="agent@minimax.ai",
    description="Advanced Python obfuscation tool with memory, binary, and machine code protection",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/minimax/python-obfuscator",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Security",
        "Topic :: Software Development :: Obfuscation",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.12.0",
            "black>=21.0.0",
            "flake8>=3.9.0",
            "mypy>=0.910",
        ],
        "windows": ["pywin32>=227"],
        "macos": ["pyobjc>=7.0"],
        "full": [
            "numba>=0.54.0",
            "cython>=0.29.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "py-obfuscator=run:main",
            "python-obfuscator=run:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.json", "*.yaml", "*.yml", "*.md", "*.txt"],
    },
    keywords="python obfuscation security code protection pyinstaller",
    project_urls={
        "Bug Reports": "https://github.com/minimax/python-obfuscator/issues",
        "Source": "https://github.com/minimax/python-obfuscator",
        "Documentation": "https://github.com/minimax/python-obfuscator/wiki",
    },
)
