"""
Python Multi-Level Obfuscator
Advanced obfuscation tool with liquid glass GUI
Supports memory-level, binary-level, and machine code-level protection
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import tkinter.font as tkFont
import sys
import os
import threading
import time
import json
import tempfile
from pathlib import Path
from typing import Optional, Dict, List

# Import our obfuscation modules
from .gui.glass_ui import (
    GlassFrame, ModernButton, ProgressBar, GlassDialog,
    FilePanel, ObfuscationPanel, create_modern_tooltip
)
from .obfuscators.memory_obfuscator import MemoryObfuscator
from .obfuscators.binary_obfuscator import BinaryObfuscator
from .obfuscators.machine_obfuscator import MachineCodeObfuscator

class ObfuscationConfig:
    """Configuration manager for obfuscation settings"""
    
    def __init__(self):
        self.config_file = Path("obfuscation_config.json")
        self.default_config = {
            "memory_level": {
                "rename_variables": True,
                "encrypt_strings": True,
                "add_dead_code": True,
                "flatten_control_flow": True,
                "obfuscate_imports": True,
                "anti_debugging": True
            },
            "binary_level": {
                "resource_protection": True,
                "signature_verification": True,
                "debugger_detection": True,
                "integrity_checking": True,
                "pyinstaller_options": {
                    "onefile": True,
                    "compress": True,
                    "upx": False
                }
            },
            "machine_level": {
                "opcode_junk": True,
                "c_extension": False,
                "assembly_wrapper": False,
                "control_flow_flattening": True,
                "instruction_substitution": True
            },
            "general": {
                "output_directory": "obfuscated_output",
                "backup_original": True,
                "generate_report": True
            }
        }
        self.config = self.load_config()
    
    def load_config(self) -> Dict:
        """Load configuration from file"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return self.default_config.copy()
    
    def save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
        except Exception as e:
            print(f"Failed to save config: {e}")
    
    def get(self, category: str, key: str, default=None):
        """Get configuration value"""
        return self.config.get(category, {}).get(key, default)
    
    def set(self, category: str, key: str, value):
        """Set configuration value"""
        if category not in self.config:
            self.config[category] = {}
        self.config[category][key] = value

class ObfuscationEngine:
    """Main obfuscation engine that coordinates all obfuscation levels"""
    
    def __init__(self, config: ObfuscationConfig):
        self.config = config
        self.memory_obfuscator = MemoryObfuscator()
        self.binary_obfuscator = BinaryObfuscator()
        self.machine_obfuscator = MachineCodeObfuscator()
        self.progress_callback = None
        self.status_callback = None
    
    def set_progress_callback(self, callback):
        """Set progress callback function"""
        self.progress_callback = callback
    
    def set_status_callback(self, callback):
        """Set status callback function"""
        self.status_callback = callback
    
    def update_progress(self, value: int, message: str = ""):
        """Update progress and status"""
        if self.progress_callback:
            self.progress_callback(value)
        if self.status_callback and message:
            self.status_callback(message)
    
    def obfuscate_file(self, input_file: str, output_dir: str) -> Dict[str, str]:
        """Obfuscate a Python file using all three levels"""
        results = {
            "success": False,
            "memory_file": "",
            "binary_file": "",
            "machine_file": "",
            "errors": []
        }
        
        try:
            # Read input file
            with open(input_file, 'r', encoding='utf-8') as f:
                source_code = f.read()
            
            input_name = Path(input_file).stem
            self.update_progress(10, "Starting obfuscation process...")
            
            # Memory-level obfuscation
            if self.config.get("memory_level", "rename_variables", True):
                self.update_progress(25, "Applying memory-level obfuscation...")
                
                try:
                    protected_memory = self.memory_obfuscator.create_protected_module(source_code)
                    memory_file = os.path.join(output_dir, f"{input_name}_memory_obfuscated.py")
                    
                    with open(memory_file, 'w', encoding='utf-8') as f:
                        f.write(protected_memory)
                    
                    results["memory_file"] = memory_file
                    self.update_progress(35, "Memory-level obfuscation complete")
                    
                except Exception as e:
                    results["errors"].append(f"Memory obfuscation error: {e}")
            
            # Binary-level obfuscation
            if self.config.get("binary_level", "resource_protection", True):
                self.update_progress(50, "Applying binary-level obfuscation...")
                
                try:
                    # Use memory obfuscated file if available, otherwise use original
                    source_for_binary = results["memory_file"] if results["memory_file"] else input_file
                    
                    with BinaryObfuscator(output_dir=output_dir) as binary_obf:
                        success = binary_obf.create_protected_executable(
                            source_for_binary,
                            f"{input_name}_protected",
                            compress=self.config.get("binary_level", "pyinstaller_options", {}).get("compress", True)
                        )
                        
                        if success:
                            # Find the generated executable
                            exe_files = list(Path(output_dir).glob(f"{input_name}_protected*"))
                            if exe_files:
                                results["binary_file"] = str(exe_files[0])
                    
                    self.update_progress(70, "Binary-level obfuscation complete")
                    
                except Exception as e:
                    results["errors"].append(f"Binary obfuscation error: {e}")
            
            # Machine-level obfuscation
            if self.config.get("machine_level", "c_extension", False):
                self.update_progress(85, "Applying machine-level obfuscation...")
                
                try:
                    # Use memory obfuscated file if available
                    source_for_machine = results["memory_file"] if results["memory_file"] else input_file
                    
                    with MachineCodeObfuscator() as machine_obf:
                        success = machine_obf.create_comprehensive_protection(
                            open(source_for_machine).read(),
                            f"{input_name}_protected"
                        )
                        
                        if success:
                            # Find generated extension files
                            ext_files = list(Path.cwd().glob(f"{input_name}_protected*"))
                            for ext_file in ext_files:
                                if ext_file.suffix in ['.so', '.pyd', '.py']:
                                    results["machine_file"] = str(ext_file)
                                    break
                    
                    self.update_progress(95, "Machine-level obfuscation complete")
                    
                except Exception as e:
                    results["errors"].append(f"Machine obfuscation error: {e}")
            
            results["success"] = len(results["errors"]) == 0
            self.update_progress(100, "Obfuscation complete!")
            
            return results
            
        except Exception as e:
            results["errors"].append(f"General obfuscation error: {e}")
            self.update_progress(0, f"Error: {e}")
            return results

class ObfuscationGUI:
    """Main GUI application with liquid glass effects"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.setup_window()
        self.setup_variables()
        self.setup_gui()
        self.config = ObfuscationConfig()
        self.engine = ObfuscationEngine(self.config)
        self.setup_callbacks()
        
    def setup_window(self):
        """Setup main window"""
        self.root.title("Python Multi-Level Obfuscator")
        self.root.geometry("1200x800")
        self.root.configure(bg="#1a1a1a")
        
        # Center window
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (1200 // 2)
        y = (self.root.winfo_screenheight() // 2) - (800 // 2)
        self.root.geometry(f"1200x800+{x}+{y}")
        
        # Set modern font
        self.title_font = tkFont.Font(family="Segoe UI", size=18, weight="bold")
        self.button_font = tkFont.Font(family="Segoe UI", size=10, weight="bold")
        self.text_font = tkFont.Font(family="Segoe UI", size=9)
        
    def setup_variables(self):
        """Setup GUI variables"""
        self.status_var = tk.StringVar(value="Ready")
        self.progress_var = tk.IntVar(value=0)
        self.input_file_var = tk.StringVar()
        self.output_dir_var = tk.StringVar(value="obfuscated_output")
        
        # Obfuscation level variables
        self.memory_var = tk.BooleanVar(value=True)
        self.binary_var = tk.BooleanVar(value=True)
        self.machine_var = tk.BooleanVar(value=False)
        
    def setup_gui(self):
        """Setup GUI layout"""
        # Main container
        main_frame = tk.Frame(self.root, bg="#1a1a1a")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            main_frame,
            text="Python Multi-Level Obfuscator",
            font=self.title_font,
            fg="white",
            bg="#1a1a1a"
        )
        title_label.pack(pady=(0, 20))
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Create tabs
        self.create_main_tab()
        self.create_settings_tab()
        self.create_advanced_tab()
        
        # Progress section
        self.create_progress_section(main_frame)
        
    def create_main_tab(self):
        """Create main obfuscation tab"""
        main_tab = tk.Frame(self.notebook, bg="#1a1a1a")
        self.notebook.add(main_tab, text="Main")
        
        # File input section
        input_panel = GlassFrame(main_tab, width=350, height=150, bg_color="#2c3e50")
        input_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        input_label = tk.Label(
            input_panel.inner_frame,
            text="Input File",
            font=("Segoe UI", 12, "bold"),
            fg="white",
            bg="#2c3e50"
        )
        input_label.pack(pady=5)
        
        # File selection
        file_frame = tk.Frame(input_panel.inner_frame, bg="#2c3e50")
        file_frame.pack(fill=tk.X, padx=20, pady=10)
        
        self.input_entry = tk.Entry(
            file_frame,
            textvariable=self.input_file_var,
            font=self.text_font,
            bg="#34495e",
            fg="white",
            relief=tk.FLAT
        )
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        
        browse_btn = ModernButton(
            file_frame,
            text="Browse",
            command=self.browse_input_file,
            bg_color="#e74c3c",
            hover_color="#c0392b",
            width=80,
            height=30
        )
        browse_btn.pack(side=tk.RIGHT)
        
        # Output directory
        output_frame = tk.Frame(input_panel.inner_frame, bg="#2c3e50")
        output_frame.pack(fill=tk.X, padx=20, pady=5)
        
        output_label = tk.Label(
            output_frame,
            text="Output Directory:",
            font=self.text_font,
            fg="white",
            bg="#2c3e50"
        )
        output_label.pack(side=tk.LEFT)
        
        self.output_entry = tk.Entry(
            output_frame,
            textvariable=self.output_dir_var,
            font=self.text_font,
            bg="#34495e",
            fg="white",
            relief=tk.FLAT
        )
        self.output_entry.pack(side=tk.RIGHT, fill=tk.X, expand=True)
        
        # Obfuscation levels section
        levels_panel = GlassFrame(main_tab, width=350, height=200, bg_color="#34495e")
        levels_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(10, 0))
        
        levels_label = tk.Label(
            levels_panel.inner_frame,
            text="Obfuscation Levels",
            font=("Segoe UI", 12, "bold"),
            fg="white",
            bg="#34495e"
        )
        levels_label.pack(pady=5)
        
        # Level checkboxes
        levels_frame = tk.Frame(levels_panel.inner_frame, bg="#34495e")
        levels_frame.pack(fill=tk.X, padx=20, pady=10)
        
        memory_check = tk.Checkbutton(
            levels_frame,
            text="Memory-level Obfuscation",
            variable=self.memory_var,
            bg="#34495e",
            fg="white",
            activebackground="#34495e",
            selectcolor="#34495e",
            font=self.text_font
        )
        memory_check.pack(anchor="w", pady=2)
        create_modern_tooltip(memory_check, "Runtime obfuscation with anti-debugging")
        
        binary_check = tk.Checkbutton(
            levels_frame,
            text="Binary-level Obfuscation",
            variable=self.binary_var,
            bg="#34495e",
            fg="white",
            activebackground="#34495e",
            selectcolor="#34495e",
            font=self.text_font
        )
        binary_check.pack(anchor="w", pady=2)
        create_modern_tooltip(binary_check, "Executable protection with PyInstaller")
        
        machine_check = tk.Checkbutton(
            levels_frame,
            text="Machine-level Obfuscation",
            variable=self.machine_var,
            bg="#34495e",
            fg="white",
            activebackground="#34495e",
            selectcolor="#34495e",
            font=self.text_font
        )
        machine_check.pack(anchor="w", pady=2)
        create_modern_tooltip(machine_check, "C extension compilation and assembly protection")
        
        # Action buttons
        buttons_frame = tk.Frame(main_tab, bg="#1a1a1a")
        buttons_frame.pack(fill=tk.X, pady=20)
        
        self.obfuscate_btn = ModernButton(
            buttons_frame,
            text="Start Obfuscation",
            command=self.start_obfuscation,
            bg_color="#27ae60",
            hover_color="#229954",
            width=150,
            height=40
        )
        self.obfuscate_btn.pack(side=tk.LEFT, padx=(0, 10))
        
        clear_btn = ModernButton(
            buttons_frame,
            text="Clear Output",
            command=self.clear_output,
            bg_color="#f39c12",
            hover_color="#e67e22",
            width=120,
            height=40
        )
        clear_btn.pack(side=tk.LEFT)
        
    def create_settings_tab(self):
        """Create settings tab"""
        settings_tab = tk.Frame(self.notebook, bg="#1a1a1a")
        self.notebook.add(settings_tab, text="Settings")
        
        # Memory settings
        memory_panel = ObfuscationPanel(settings_tab)
        memory_panel.pack(fill=tk.X, padx=10, pady=5)
        
        # Memory level settings
        self.memory_rename_var = tk.BooleanVar(value=True)
        self.memory_encrypt_var = tk.BooleanVar(value=True)
        self.memory_dead_var = tk.BooleanVar(value=True)
        self.memory_flatten_var = tk.BooleanVar(value=True)
        
        self.memory_rename_var.trace('w', self.update_memory_settings)
        self.memory_encrypt_var.trace('w', self.update_memory_settings)
        self.memory_dead_var.trace('w', self.update_memory_settings)
        self.memory_flatten_var.trace('w', self.update_memory_settings)
        
        # Binary settings
        binary_panel = ObfuscationPanel(settings_tab)
        binary_panel.pack(fill=tk.X, padx=10, pady=5)
        
        # Machine settings
        machine_panel = ObfuscationPanel(settings_tab)
        machine_panel.pack(fill=tk.X, padx=10, pady=5)
        
    def create_advanced_tab(self):
        """Create advanced options tab"""
        advanced_tab = tk.Frame(self.notebook, bg="#1a1a1a")
        self.notebook.add(advanced_tab, text="Advanced")
        
        # Code preview section
        preview_panel = GlassFrame(advanced_tab, width=600, height=300, bg_color="#2c3e50")
        preview_panel.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        preview_label = tk.Label(
            preview_panel.inner_frame,
            text="Code Preview",
            font=("Segoe UI", 12, "bold"),
            fg="white",
            bg="#2c3e50"
        )
        preview_label.pack(pady=5)
        
        self.preview_text = scrolledtext.ScrolledText(
            preview_panel.inner_frame,
            font=self.text_font,
            bg="#34495e",
            fg="white",
            wrap=tk.WORD,
            height=15
        )
        self.preview_text.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Load sample code
        self.load_sample_code()
        
    def create_progress_section(self, parent):
        """Create progress monitoring section"""
        progress_panel = GlassFrame(parent, width=1100, height=80, bg_color="#2d3436")
        progress_panel.pack(fill=tk.X, pady=(10, 0))
        
        # Status and progress
        status_frame = tk.Frame(progress_panel.inner_frame, bg="#2d3436")
        status_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Status label
        self.status_label = tk.Label(
            status_frame,
            textvariable=self.status_var,
            font=self.text_font,
            fg="white",
            bg="#2d3436"
        )
        self.status_label.pack(side=tk.LEFT)
        
        # Progress bar
        self.progress_bar = ProgressBar(
            status_frame,
            width=300,
            height=20,
            bg_color="#3498db",
            track_color="#34495e"
        )
        self.progress_bar.pack(side=tk.RIGHT)
        
    def setup_callbacks(self):
        """Setup callback functions"""
        self.engine.set_progress_callback(self.update_progress)
        self.engine.set_status_callback(self.update_status)
    
    def update_progress(self, value: int):
        """Update progress bar"""
        self.progress_var.set(value)
        self.progress_bar.update_progress(value)
    
    def update_status(self, message: str):
        """Update status message"""
        self.status_var.set(message)
        self.root.update_idletasks()
    
    def browse_input_file(self):
        """Browse for input file"""
        filename = filedialog.askopenfilename(
            title="Select Python File",
            filetypes=[
                ("Python files", "*.py"),
                ("All files", "*.*")
            ]
        )
        if filename:
            self.input_file_var.set(filename)
            self.preview_text.delete(1.0, tk.END)
            try:
                with open(filename, 'r', encoding='utf-8') as f:
                    content = f.read()
                    self.preview_text.insert(1.0, content)
            except Exception as e:
                self.preview_text.insert(1.0, f"Error reading file: {e}")
    
    def update_memory_settings(self, *args):
        """Update memory obfuscation settings"""
        self.config.set("memory_level", "rename_variables", self.memory_rename_var.get())
        self.config.set("memory_level", "encrypt_strings", self.memory_encrypt_var.get())
        self.config.set("memory_level", "add_dead_code", self.memory_dead_var.get())
        self.config.set("memory_level", "flatten_control_flow", self.memory_flatten_var.get())
    
    def load_sample_code(self):
        """Load sample code for preview"""
        sample_code = '''def sample_function(x, y):
    """
    Sample function for obfuscation testing
    """
    result = (x * y) + 42
    
    if result > 100:
        return result - 10
    else:
        return result + 10

def main():
    """Main function"""
    values = [1, 2, 3, 4, 5]
    for val in values:
        output = sample_function(val, 2)
        print(f"Input: {val}, Output: {output}")

if __name__ == "__main__":
    main()
'''
        self.preview_text.insert(1.0, sample_code)
    
    def start_obfuscation(self):
        """Start obfuscation process"""
        input_file = self.input_file_var.get()
        output_dir = self.output_dir_var.get()
        
        if not input_file:
            messagebox.showerror("Error", "Please select an input file")
            return
        
        if not os.path.exists(input_file):
            messagebox.showerror("Error", "Input file does not exist")
            return
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        
        # Update configuration
        self.config.set("memory_level", "enabled", self.memory_var.get())
        self.config.set("binary_level", "enabled", self.binary_var.get())
        self.config.set("machine_level", "enabled", self.machine_var.get())
        
        # Disable button during processing
        self.obfuscate_btn.config(state="disabled", text="Processing...")
        
        # Start obfuscation in separate thread
        def obfuscation_thread():
            try:
                results = self.engine.obfuscate_file(input_file, output_dir)
                
                # Show results
                self.root.after(0, lambda: self.show_results(results))
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Obfuscation failed: {e}"))
            finally:
                self.root.after(0, lambda: self.obfuscate_btn.config(state="normal", text="Start Obfuscation"))
        
        thread = threading.Thread(target=obfuscation_thread, daemon=True)
        thread.start()
    
    def show_results(self, results: Dict):
        """Show obfuscation results"""
        if results["success"]:
            result_text = "Obfuscation completed successfully!\\n\\n"
            
            if results["memory_file"]:
                result_text += f"Memory-level file: {results['memory_file']}\\n"
            if results["binary_file"]:
                result_text += f"Binary-level file: {results['binary_file']}\\n"
            if results["machine_file"]:
                result_text += f"Machine-level file: {results['machine_file']}\\n"
            
            if results["errors"]:
                result_text += "\\nErrors:\\n"
                for error in results["errors"]:
                    result_text += f"- {error}\\n"
            
            messagebox.showinfo("Success", result_text)
        else:
            error_text = "Obfuscation failed!\\n\\nErrors:\\n"
            for error in results["errors"]:
                error_text += f"- {error}\\n"
            messagebox.showerror("Error", error_text)
        
        # Reset progress
        self.update_progress(0)
        self.update_status("Ready")
    
    def clear_output(self):
        """Clear output directory"""
        output_dir = self.output_dir_var.get()
        if os.path.exists(output_dir):
            if messagebox.askyesno("Confirm", f"Delete all files in {output_dir}?"):
                try:
                    import shutil
                    shutil.rmtree(output_dir)
                    os.makedirs(output_dir, exist_ok=True)
                    messagebox.showinfo("Success", "Output directory cleared")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to clear directory: {e}")
        else:
            messagebox.showinfo("Info", "Output directory does not exist")
    
    def run(self):
        """Run the application"""
        self.root.mainloop()

def main():
    """Main entry point"""
    try:
        app = ObfuscationGUI()
        app.run()
    except Exception as e:
        print(f"Application error: {e}")
        messagebox.showerror("Fatal Error", f"Application failed to start: {e}")

if __name__ == "__main__":
    main()
