"""
Python Multi-Level Obfuscator
Advanced Python code obfuscation tool with liquid glass GUI
"""

__version__ = "1.0.0"
__author__ = "MiniMax Agent"
__email__ = "agent@minimax.ai"
__description__ = "Advanced Python obfuscation tool with memory, binary, and machine code protection"

__all__ = [
    "__version__"
]