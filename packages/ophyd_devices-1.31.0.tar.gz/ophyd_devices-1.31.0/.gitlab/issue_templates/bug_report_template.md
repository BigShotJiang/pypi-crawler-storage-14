## Bug report - Summary

[Provide a brief description of the bug.]

## Expected Behavior vs Actual Behavior

[Describe what you expected to happen and what actually happened.]

## Steps to Reproduce

[Outline the steps that lead to the bug's occurrence. Be specific and provide a clear sequence of actions.]

## Related Issues

[Paste links to any related issues or feature requests.]