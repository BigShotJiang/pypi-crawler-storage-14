from setuptools import setup, find_packages

setup(
    name="DirectoryControl",
    version="0.1.0.2",
    packages=find_packages(),
    install_requires=[
        # список залежностей вашого пакету, якщо вони є
    ],
    author="Volodymyr Dzimina",
    author_email="vova.dzimina@gmail.com",
    description="This is a test package for python lessons",
    long_description="This package created for my python lessons with Dmitro Probachai, in this package i added simple linux comands",
    url="https://github.com/41cha/test-package-for-python-lesson",
)