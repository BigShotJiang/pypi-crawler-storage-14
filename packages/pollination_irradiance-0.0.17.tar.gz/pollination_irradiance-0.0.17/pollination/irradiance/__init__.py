from .entry import AnnualIrradianceEntryPoint


__pollination__ = {
    'entry_point': AnnualIrradianceEntryPoint
}
