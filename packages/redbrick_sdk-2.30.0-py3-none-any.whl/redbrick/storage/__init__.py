"""RedBrick Organization Storage method integration."""

from .public import StorageImpl
