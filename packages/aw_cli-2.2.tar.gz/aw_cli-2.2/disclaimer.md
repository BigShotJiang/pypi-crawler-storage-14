### Disclaimer
Questo progetto è offerto senza alcuna garanzia o responsabilità. 
Questo progetto deve essere utilizzato a rischio e pericolo dell'utente.
Tutti i contenuti di questo progetto sono accessibili dal publicco su Internet. 
L'autore e i contributori non sono responsabili per eventuali danni causati dall'utilizzo delle informazioni e del codice contenuti in questo progetto.
