from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Iterator, List, Literal, Union

from pydantic import BaseModel

if TYPE_CHECKING:
    from agex.agent.events import Event


@dataclass
class TextPart:
    text: str
    type: Literal["text"] = "text"


@dataclass
class ImagePart:
    """Represents a base64 encoded image."""

    image: str
    type: Literal["image"] = "image"


ContentPart = Union[TextPart, ImagePart]


@dataclass
class TokenChunk:
    """
    A piece of streamed content from the LLM.

    Not an Event - tokens are ephemeral and don't go in the state log.

    Attributes:
        type: Either "title", "thinking", or "python"
        content: The text content (incremental)
        done: True when this section is complete
    """

    type: Literal["title", "thinking", "python"]
    content: str
    done: bool = False


@dataclass
class StreamToken(TokenChunk):
    """TokenChunk enriched with agent metadata for on_token handlers."""

    agent_name: str = ""
    full_namespace: str = ""
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    start: bool = False


class LLMResponse(BaseModel):
    """Structured LLM response with parsed title, thinking, and code sections."""

    title: str = ""
    thinking: str
    code: str


class ResponseParseError(Exception):
    """Exception raised when an agent's response cannot be parsed."""

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message

    def __str__(self):
        return self.message


class LLMClient(ABC):
    """
    A common interface for LLM clients, ensuring compatibility between different
    providers and implementation approaches.
    """

    @abstractmethod
    def complete(self, system: str, events: List["Event"], **kwargs) -> LLMResponse:
        """
        Agent execution - convert events to structured response.

        Args:
            system: System message content (primer + capabilities)
            events: Conversation history as Event objects
            **kwargs: Provider-specific arguments (temperature, max_tokens, etc.)

        Returns:
            LLMResponse with parsed thinking and code sections

        Raises:
            RuntimeError: If the completion request fails
            ResponseParseError: If response doesn't match expected format
        """
        ...

    def complete_stream(
        self, system: str, events: List["Event"], **kwargs
    ) -> Iterator[TokenChunk]:
        """
        Agent execution with token-level streaming support.

        This method enables real-time UI feedback by yielding tokens as they arrive.
        Implementations can choose to support streaming or raise NotImplementedError.

        Default implementation: Falls back to complete() and yields buffered response.
        Providers that support streaming should override this method.

        Args:
            system: System message content (primer + capabilities)
            events: Conversation history as Event objects
            **kwargs: Provider-specific arguments (temperature, max_tokens, etc.)

        Yields:
            TokenChunk objects as sections are parsed from the stream

        Raises:
            NotImplementedError: If streaming is not supported by this client
            RuntimeError: If the completion request fails
            ResponseParseError: If response doesn't match expected format
        """
        # Default fallback: buffer complete() response and yield as tokens
        response = self.complete(system, events, **kwargs)

        # Yield title section first (if present)
        if response.title:
            yield TokenChunk(type="title", content=response.title, done=False)
            yield TokenChunk(type="title", content="", done=True)

        # Yield thinking section
        if response.thinking:
            yield TokenChunk(type="thinking", content=response.thinking, done=False)
        yield TokenChunk(type="thinking", content="", done=True)

        # Yield code section
        if response.code:
            yield TokenChunk(type="python", content=response.code, done=False)
        yield TokenChunk(type="python", content="", done=True)

    @abstractmethod
    def summarize(self, system: str, content: str, **kwargs) -> str:
        """
        Generic text generation with instructions.

        Used for capabilities summarization and other non-agent tasks.
        Does not handle events or multimodal content.

        Args:
            system: Instructions for the task
            content: Text content to process
            **kwargs: Provider-specific arguments (temperature, max_tokens, etc.)

        Returns:
            Generated text string
        """
        ...

    @property
    @abstractmethod
    def model(self) -> str:
        """
        The model name being used.

        Returns:
            Model identifier string
        """
        ...

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """
        The provider name for this client.

        Returns:
            Provider name string (e.g., "OpenAI", "Anthropic", "Google Gemini")
        """
        ...
