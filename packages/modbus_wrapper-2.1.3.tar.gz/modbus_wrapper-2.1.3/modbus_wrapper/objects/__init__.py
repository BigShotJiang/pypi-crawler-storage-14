from .modbus_object import ModbusObject
from .fatek_object import FatekObject
