from byte.domain.prompt_format.utils.boundary import Boundary

__all__ = [
    "Boundary",
]
