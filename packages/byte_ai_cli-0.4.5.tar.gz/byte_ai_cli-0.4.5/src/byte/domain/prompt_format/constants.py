EDIT_BLOCK_NAME = "Pseudo-XML Edit"
