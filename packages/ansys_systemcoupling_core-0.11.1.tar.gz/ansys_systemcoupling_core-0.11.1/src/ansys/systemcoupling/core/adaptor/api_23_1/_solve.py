#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.systemcoupling.core.adaptor.impl.types import *


class _solve(Command):
    """
    For internal use only.
    """

    syc_name = "Solve"
