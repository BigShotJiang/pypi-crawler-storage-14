import celery

from django.apps import (
    AppConfig as AppConfigBase,
)


class AppConfig(AppConfigBase):
    """Конфигурация реестра "Асинхронные задачи".

    Устанавливает имя и метку приложения для регистрации в системе Django.
    """

    name = __package__
    label = 'async_task'

    def ready(self):  # noqa: D102
        from educommon.async_task.tasks import (
            SyncTaskStatusesTask,
        )

        celery_app = celery.app.app_or_default()
        celery_app.register_task(SyncTaskStatusesTask)
