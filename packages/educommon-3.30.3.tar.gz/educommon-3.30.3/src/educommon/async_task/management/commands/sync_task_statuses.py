"""Management команда для синхронизации статусов задач между Celery backend и БД.

Параметры:
    --task-id           ID конкретной задачи в Celery / RunningTask.
    --from-queued-at    Дата/время начала интервала поиска задач (формат: YYYY-MM-DD или YYYY-MM-DD HH:MM:SS).
    --to-queued-at      Дата/время окончания интервала поиска задач.
    --limit             Максимальное количество задач для обработки.
    --dry-run           Если true — только выводит расхождения без изменения статусов в БД. Дефолтное значение: false.

Примеры запуска:
    # Синхронизировать все задачи, созданные 15 ноября 2025 года и позже
    django-admin sync_task_statuses --from-queued-at "2025-11-15 00:00:00"

    # Проверить последние 200 задач без изменения статусов в базе
    django-admin sync_task_statuses --limit 200 --dry-run

    # Синхронизировать конкретную задачу по ID (остальные фильтры игнорируются)
    django-admin sync_task_statuses --task-id "297a1bef-4e71-4395-9df3-79ae376411e0"
"""

import argparse
from datetime import (
    datetime,
)

from django.core.management.base import (
    BaseCommand,
    CommandParser,
)

from educommon.async_task.helpers import (
    sync_task_statuses,
)


def parse_datetime(value: str) -> datetime:
    """Парсит строковое значение даты в datetime."""
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue

    raise argparse.ArgumentTypeError(
        'Дата должна быть в формате ГГГГ-ММ-ДД или ГГГГ-ММ-ДД ЧЧ:ММ:СС'
    )


class Command(BaseCommand):
    """Команда для синхронизации статусов задач между Celery backend и БД."""

    help = 'Синхронизирует статусы задач между Celery backend и БД'  # noqa: A003

    def add_arguments(
        self,
        parser: CommandParser,
    ) -> None:
        """Добавляет аргументы команды."""
        parser.add_argument(
            '--task-id',
            type=str,
            help='ID конкретной задачи для проверки (если указан, остальные фильтры игнорируются)',
        )
        parser.add_argument(
            '--from-queued-at',
            type=parse_datetime,
            help='Дата начала периода (формат: ГГГГ-ММ-ДД или ГГГГ-ММ-ДД ЧЧ:ММ:СС)',
        )
        parser.add_argument(
            '--to-queued-at',
            type=parse_datetime,
            help='Дата окончания периода (формат: ГГГГ-ММ-ДД или ГГГГ-ММ-ДД ЧЧ:ММ:СС)',
        )
        parser.add_argument(
            '--limit',
            type=int,
            help='Максимальное количество задач для проверки',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            default=False,
            help='Только показывать несоответствия (по умолчанию обновляет статусы в БД)',
        )

    def handle(
        self,
        *args,
        **options,
    ) -> None:
        """Выполняет команду."""
        sync_task_statuses(
            from_queued_at=options['from_queued_at'],
            to_queued_at=options['to_queued_at'],
            limit=options['limit'],
            dry_run=options['dry_run'],
            task_id=options['task_id'],
        )
