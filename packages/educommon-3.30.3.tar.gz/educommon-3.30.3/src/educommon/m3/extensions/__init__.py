"""Утилиты для расширения интерфейсов и действий."""

from educommon.m3.extensions.listeners import (
    BaseEditWinListener,
    BaseSaveListener,
)
from educommon.m3.extensions.ui import (
    BaseEditWinExtender,
)
