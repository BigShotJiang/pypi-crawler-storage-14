COUNT = 'count'
SUM = 'sum'
