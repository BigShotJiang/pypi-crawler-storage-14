"""
CPAP MCP Server - Model Context Protocol server for CPAP data analysis.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
