# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed
- **BREAKING**: Replaced `upload_file` with `upload_archive` tool
  - Now accepts a single ZIP archive instead of individual files
  - More efficient for AI models with file upload limits
  - Simplifies the upload process (one upload vs. many)
  
### Added
- ZIP archive support for CPAP data uploads
- Helper script `examples/create_archive.py` for creating and encoding archives
- Updated test client example with ZIP archive support
- Comprehensive tests for ZIP archive upload functionality
- Skip hidden files and directory entries in archives

### Removed
- `upload_file` tool (replaced by `upload_archive`)

## [0.1.0] - 2024-12-01

### Added
- Initial release of CPAP MCP Server
- 17 MCP tools for CPAP data analysis:
  - File management (upload, list, clear)
  - Device and session information
  - Detailed analysis (events, pressure, flow, SpO2)
  - Settings and recommendations
- Support for ResMed CPAP devices
- Base64 file upload system
- Temporary working directory management
- Comprehensive test suite
- Documentation:
  - README.md with full feature documentation
  - USAGE.md with detailed examples
  - INSTALL.md with installation instructions
  - CONTRIBUTING.md with contribution guidelines
  - DEVELOPMENT.md with development guide
- Integration with cpap-py library for CPAP data parsing
- Example scripts for file encoding and testing
- Helper scripts:
  - install.sh for automated installation
  - run_tests.sh for running test suite
  - publish.sh for building and publishing

### Features
- **File Management**: Upload CPAP files, list uploaded files, clear working directory
- **Device Information**: Get device details, serial numbers, models, firmware
- **Session Analysis**: Retrieve therapy sessions with filtering and sorting
- **Detailed Metrics**: Access AHI, leak rates, pressure statistics, event counts
- **Event Tracking**: Query apneas, hypopneas, flow limitations, and other events
- **Waveform Data**: Access time-series pressure, flow, and SpO2 data
- **Recommendations**: Generate therapy effectiveness analysis and optimization suggestions
- **Settings Proposals**: Create validated pressure and comfort adjustment proposals
- **Data Export**: Export complete dataset as JSON
- **Error Reporting**: View data parsing errors and warnings

### Technical
- Python 3.10+ support
- MCP protocol via stdio transport
- Pydantic models for data validation
- Comprehensive error handling
- Sample limiting for large datasets
- Safety validation for settings proposals

[Unreleased]: https://github.com/dynacylabs/cpap-mcp/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/dynacylabs/cpap-mcp/releases/tag/v0.1.0
