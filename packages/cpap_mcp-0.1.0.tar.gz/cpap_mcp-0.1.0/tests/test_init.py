"""
Tests for package initialization.
"""

import pytest


# Mark as unit tests
pytestmark = pytest.mark.unit


def test_package_import():
    """Test that the package can be imported."""
    import cpap_mcp
    assert cpap_mcp is not None


def test_package_has_version():
    """Test that package has a version attribute or can be imported."""
    import cpap_mcp
    # The package should at least be importable
    assert hasattr(cpap_mcp, '__name__')


def test_server_module_import():
    """Test that the server module can be imported."""
    from cpap_mcp import server
    assert server is not None
