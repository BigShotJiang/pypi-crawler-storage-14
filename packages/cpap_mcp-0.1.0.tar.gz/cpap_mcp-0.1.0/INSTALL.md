# Installation Guide

This guide covers how to install the CPAP MCP Server.

## Table of Contents

- [Requirements](#requirements)
- [Installation Methods](#installation-methods)
  - [From PyPI](#from-pypi)
  - [From Source](#from-source)
  - [Development Installation](#development-installation)
- [Configuration](#configuration)
- [Verification](#verification)
- [Troubleshooting](#troubleshooting)

## Requirements

- **Python**: 3.10 or higher
- **pip**: Latest version recommended
- **Dependencies** (automatically installed): 
  - `mcp >= 0.9.0`
  - `pydantic >= 2.0.0`
  - `numpy >= 1.24.0`
  - `pandas >= 2.0.0`
  - `pyedflib >= 0.1.30`
  - `python-dateutil >= 2.8.0`
  - `cpap-py >= 0.1.0` (core CPAP parsing library)

## Installation Methods

### From PyPI (Recommended)

The easiest way to install the library is from PyPI using pip:

```bash
pip install cpap-mcp
```

To upgrade to the latest version:

```bash
pip install --upgrade cpap-mcp
```

To install a specific version:

```bash
pip install cpap-mcp==0.1.0
```

### From Source

To install directly from the GitHub repository:

```bash
# Clone the repository with submodules
git clone --recursive https://github.com/dynacylabs/cpap-mcp.git
cd cpap-mcp

# If you already cloned without --recursive, initialize submodules:
git submodule update --init --recursive

# Install
pip install .
```

Or install directly from GitHub without cloning:

```bash
pip install git+https://github.com/dynacylabs/cpap-mcp.git
```

### Development Installation

For development, install in editable mode:

```bash
# Clone the repository with submodules
git clone --recursive https://github.com/dynacylabs/cpap-mcp.git
cd cpap-mcp

# If you already cloned without --recursive, initialize submodules:
git submodule update --init --recursive

# Create and activate virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in editable mode
pip install -e .

# Install development dependencies
pip install -r requirements.txt
```

This allows you to make changes to the code and see them reflected immediately without reinstalling.

### Optional Dependencies

If you need development tools:

```bash
pip install cpap-mcp[dev]
```

For testing only:

```bash
pip install cpap-mcp[test]
```

This includes:
- pytest and plugins for testing
- black for code formatting
- ruff for linting
- mypy for type checking
- coverage tools

## Configuration

### Claude Desktop Configuration

To use the CPAP MCP Server with Claude Desktop, add the following to your Claude Desktop configuration:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "cpap": {
      "command": "cpap-mcp"
    }
  }
}
```

Or if running from source:

```json
{
  "mcpServers": {
    "cpap": {
      "command": "python",
      "args": ["-m", "cpap_mcp.server"],
      "cwd": "/path/to/cpap-mcp"
    }
  }
}
```

### Environment Variables

The server uses the following environment variables (optional):

- `CPAP_MCP_WORKDIR`: Custom working directory for uploaded files (default: temp directory)

## Verification

After installation, verify that the package is installed correctly:

```bash
# Check if the command is available
which cpap-mcp

# Or check the Python package
python -c "import cpap_mcp; print('CPAP MCP Server installed successfully')"
```

Run tests to ensure everything is working:

```bash
# Quick unit tests
./run_tests.sh unit

# All tests
./run_tests.sh all
```

## Troubleshooting

### Import Errors

If you see import errors related to `cpap_py`:

```bash
# Make sure submodules are initialized
git submodule update --init --recursive

# Reinstall in development mode
pip install -e .
```

### Permission Errors

If you get permission errors during installation:

```bash
# Use user installation
pip install --user cpap-mcp

# Or use a virtual environment (recommended)
python -m venv venv
source venv/bin/activate
pip install cpap-mcp
```

### Dependency Conflicts

If you encounter dependency conflicts:

```bash
# Create a fresh virtual environment
python -m venv fresh_venv
source fresh_venv/bin/activate
pip install --upgrade pip
pip install cpap-mcp
```

### Platform-Specific Issues

**macOS**: If you encounter issues with numpy or pandas:
```bash
# Install via conda (if using conda)
conda install numpy pandas

# Or upgrade pip and wheel
pip install --upgrade pip wheel setuptools
pip install cpap-mcp
```

**Windows**: Make sure you have the latest Visual C++ redistributables installed.

**Linux**: Some dependencies may require system packages:
```bash
# Ubuntu/Debian
sudo apt-get install python3-dev

# Fedora/RHEL
sudo dnf install python3-devel
```

### Getting Help

If you continue to experience issues:

1. Check the [GitHub Issues](https://github.com/dynacylabs/cpap-mcp/issues)
2. Review the [Development Guide](DEVELOPMENT.md)
3. Open a new issue with:
   - Your Python version (`python --version`)
   - Your OS and version
   - Full error message
   - Installation method used

## Next Steps

- Check the [README.md](README.md) Quick Start section to start using the server
- Read [Usage Guide](USAGE.md) for detailed examples and common use cases
- See [Development Guide](DEVELOPMENT.md) for contributing
