"""
CPAP MCP Server Setup
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
if readme_file.exists():
    long_description = readme_file.read_text(encoding='utf-8')
else:
    long_description = "Model Context Protocol (MCP) server for CPAP data analysis"

setup(
    name="cpap-mcp",
    version="0.1.0",
    author="Dynacy Labs",
    author_email="info@dynacylabs.com",
    description="Model Context Protocol (MCP) server for CPAP data analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/dynacylabs/cpap-mcp",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Healthcare Industry",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=[
        "mcp>=0.9.0",
        "pydantic>=2.0.0",
        "numpy>=1.24.0",
        "pandas>=2.0.0",
        "pyedflib>=0.1.30",
        "python-dateutil>=2.8.0",
        "cpap-py>=0.1.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "pytest-mock>=3.10.0",
            "coverage>=7.0.0",
            "black>=23.0.0",
            "ruff>=0.1.0",
            "mypy>=0.950",
        ],
        "test": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "pytest-mock>=3.10.0",
            "coverage>=7.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "cpap-mcp=cpap_mcp.server:main",
        ],
    },
)
