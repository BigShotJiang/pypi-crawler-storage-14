from omibio.sequence.polypeptide import Polypeptide
from omibio.sequence.sequence import Sequence


__all__ = [
    "Polypeptide",
    "Sequence"
]
