"""
今日头条MCP服务器主入口
"""

import sys
import os

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

def main():
    """主入口函数"""
    try:
        from start_server import main as start_main
        start_main()
    except ImportError as e:
        print(f"导入错误: {e}")
        # 直接运行服务器
        from .server import mcp, initialize_services
        import logging
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        logger = logging.getLogger(__name__)
        
        logger.info("正在启动今日头条MCP服务器...")
        
        # 初始化服务
        if not initialize_services():
            logger.error("服务初始化失败，无法启动服务器")
            return
        
        # 使用stdio模式启动
        mcp.run()

if __name__ == "__main__":
    main()