"""
Model Templates
"""
