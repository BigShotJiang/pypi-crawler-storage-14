# Copyright 2024 Datastrato Pvt Ltd.
# This software is licensed under the Apache License version 2.
import sys

from mcp_server_gravitino.server.main import main

sys.exit(main())
