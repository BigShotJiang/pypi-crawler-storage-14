class ButtonColor:
    PRIMARY = "primary"
    SECONDARY = "secondary"
    NEGATIVE = "negative"
    POSITIVE = "positive"

    blue = PRIMARY
    white = SECONDARY
    red = NEGATIVE
    green = POSITIVE
