"""Helper functions - timing, calculations, geometry, math."""
