from .fmu_results import FmuResults, FmuResultsSchema

__all__ = [
    "FmuResultsSchema",
    "FmuResults",
]
