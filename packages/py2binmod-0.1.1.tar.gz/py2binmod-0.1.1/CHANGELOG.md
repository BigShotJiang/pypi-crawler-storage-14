
<a name="0.1.1"></a>
## [0.1.1](https://github.com/binmod-io/py2binmod/compare/0.1.0...0.1.1)

> 2025-11-29

### Chore

* Fix repository URL

### Fix

* Fix license


<a name="0.1.0"></a>
## 0.1.0

> 2025-11-25

### Feat

* Initial project setup :tada:

