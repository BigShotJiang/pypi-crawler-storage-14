use std::path::PathBuf;


pub struct RenderedFile {
    pub path: PathBuf,
    pub content: String,
}