use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct Artifact {
    pub target_dir: PathBuf,
}
