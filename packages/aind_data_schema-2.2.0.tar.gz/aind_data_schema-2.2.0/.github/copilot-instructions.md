Always use the .venv
Always use unittest
Never add comments
Never run linting