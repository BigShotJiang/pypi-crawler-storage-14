# Data_name_patterns

## Model definitions

### DataLevel

Data level name

| Name | Value |
|------|-------|
| `DERIVED` | `derived` |
| `RAW` | `raw` |
| `SIMULATED` | `simulated` |


### Group

Data collection group name

| Name | Value |
|------|-------|
| `BEHAVIOR` | `behavior` |
| `EPHYS` | `ephys` |
| `MSMA` | `MSMA` |
| `OPHYS` | `ophys` |
| `NBA` | `NBA` |


