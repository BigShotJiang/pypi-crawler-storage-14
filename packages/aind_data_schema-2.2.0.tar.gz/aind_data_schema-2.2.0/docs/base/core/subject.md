# Subject

[Link to code](https://github.com/AllenNeuralDynamics/aind-data-schema/blob/dev/src/aind_data_schema/core/subject.py)

The `subject.json` file describes the subject from which data was obtained.

## Example

```{literalinclude} ../../examples/subject.py
:language: python
:linenos:
```

