""" base module for aind-data-schema
"""

__version__ = "2.2.0"
