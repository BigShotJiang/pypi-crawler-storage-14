from simianpy.analysis.stats.xarray.ttest_rel import xr_ttest_rel
from simianpy.analysis.stats.xarray.ttest_ind import xr_ttest_ind, xr_ttest_ind_by_var