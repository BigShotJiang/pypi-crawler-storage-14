import numpy as np
import matplotlib.pyplot as plt
import mplcursors

from simianpy.plotting.util import get_ax

class HoverLineSet:
    def __init__(self, ydata, xdata=None, labels=None, dim_alpha=0.1, ax=None):
        if ax is None:
            ax = get_ax()
        self.ax = ax
        self.ydata = ydata
        if labels is None:
            labels = np.arange(len(ydata))
        self.labels = labels
        self.lines = []
        self.dim_alpha = dim_alpha

        for idx, linedata in zip(labels, ydata):
            line, = ax.plot(linedata, color='black', alpha=0.3)
            line.label = idx  # Add the label as an attribute of the line
            self.lines.append(line)
        
        # Connect the hover event
        self.cursor = mplcursors.cursor(self.lines, hover=True)
        self.cursor.connect("add", self.on_hover)
        
    def on_hover(self, event):
        for line in self.lines:
            line.set_alpha(self.dim_alpha)
        event.artist.set_alpha(1)
        self.ax.figure.canvas.draw_idle()
        self.event.annotation.set_text(event.artist.label)
    