simianpy package
================

Subpackages
-----------

.. toctree::

   simianpy.analysis
   simianpy.cli
   simianpy.io
   simianpy.misc
   simianpy.signal

Module contents
---------------

.. automodule:: simianpy
   :members:
   :undoc-members:
   :show-inheritance:
