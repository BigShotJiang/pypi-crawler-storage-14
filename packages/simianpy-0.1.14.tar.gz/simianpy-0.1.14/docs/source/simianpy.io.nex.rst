simianpy.io.nex package
=======================

Submodules
----------

simianpy.io.nex.io module
-------------------------

.. automodule:: simianpy.io.nex.io
   :members:
   :undoc-members:
   :show-inheritance:

simianpy.io.nex.nexfile module
------------------------------

.. automodule:: simianpy.io.nex.nexfile
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: simianpy.io.nex
   :members:
   :undoc-members:
   :show-inheritance:
