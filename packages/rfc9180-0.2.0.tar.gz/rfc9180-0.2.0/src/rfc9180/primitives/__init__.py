"""
Primitive implementations for KEM, KDF, and AEAD.
"""


