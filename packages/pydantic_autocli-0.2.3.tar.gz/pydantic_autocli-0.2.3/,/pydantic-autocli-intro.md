---
title: "PydanticモデルからCLIを自動生成するpydantic-autocliの紹介"
emoji: "🔧"
type: "tech"
topics: ["python", "cli", "pydantic"]
published: true
---

# モチベーション

CLIツールを作る際、以下のような課題に直面することがあります：

- 引数のバリデーション
- ヘルプテキストの管理
- サブコマンドの実装
- 型安全性の確保

これらの課題を解決するため、PydanticモデルからCLIを自動生成する`pydantic-autocli`を作成しました。

# 基本的な機能

## インストール

```bash
pip install pydantic-autocli
```

## 最小限の実装

```python
from pydantic import BaseModel
from pydantic_autocli import AutoCLI

class MyCLI(AutoCLI):
    class CustomArgs(BaseModel):
        # 必須パラメータ
        required_value: int
        # オプショナルパラメータ
        optional_value: int = 123
        # 配列パラメータ
        names: list[str] = []
        
    def run_simple(self, args: CustomArgs):
        print(f"Required: {args.required_value}")
        print(f"Optional: {args.optional_value}")
        print(f"Names: {args.names}")

if __name__ == "__main__":
    cli = MyCLI()
    cli.run()
```

使用例：

```bash
# 必須パラメータを指定
python script.py simple --required-value 42

# すべてのパラメータを指定
python script.py simple --required-value 42 --names John Jane Bob
```

# 発展的な機能

## 共通引数と詳細な設定

```python
from pydantic import Field
from pydantic_autocli import AutoCLI, param

class MyCLI(AutoCLI):
    # 全コマンドで共有される引数
    class CommonArgs(AutoCLI.CommonArgs):
        verbose: bool = param(False, l="--verbose", s="-v", description="詳細な出力を有効化")
        seed: int = Field(42, json_schema_extra={"l": "--seed"})

    class AdvancedArgs(CommonArgs):
        # ファイル名は--file-nameとして指定
        file_name: str = param(..., l="--name", pattern=r"^[a-zA-Z]+\.(txt|json|yaml)$")
        # 選択肢を制限
        mode: str = param("read", l="--mode", choices=["read", "write", "append"])
        # 待機時間（秒）
        wait: float = Field(0.5, json_schema_extra={"l": "--wait", "s": "-w"})

    async def run_advanced(self, args: AdvancedArgs):
        print(f"File name: {args.file_name}")
        print(f"Mode: {args.mode}")
        
        if args.verbose:
            print("Verbose mode enabled")
        
        return True  # 成功時は0を返す

if __name__ == "__main__":
    cli = MyCLI()
    cli.run()
```

使用例：

```bash
python script.py advanced --file-name data.txt --mode write --wait 1.5 --verbose
```

## 引数の解決ルール

1. 型アノテーションによる指定
2. 命名規則による指定（`run_command` → `CommandArgs`）
3. `CommonArgs`へのフォールバック

```python
class MyCLI(AutoCLI):
    # 命名規則による指定
    class CommandArgs(AutoCLI.CommonArgs):
        name: str = param("default", l="--name")
    
    # 型アノテーションによる指定
    class CustomArgs(AutoCLI.CommonArgs):
        value: int = param(42, l="--value")
    
    # 型アノテーションが優先される
    def run_command(self, args: CustomArgs):
        print(f"Value: {args.value}")
        return True
```

# まとめ

`pydantic-autocli`を使用することで：

- Pydanticの型システムを活用した堅牢なCLI
- 直感的な引数定義
- 自動的なヘルプ生成
- サブコマンドの簡単な実装

が実現できます。 