pip install hatch

poetry version 0.1.15

poetry version 0.1.21
rm -rf dist
hatch build
git tag v0.1.21
git push --tags



poetry env remove python3.13
rm -rf ~/.cache/pypoetry
rm -rf ~/.local/share/pypoetry


curl -sSL https://install.python-poetry.org | python3 -


poetry config virtualenvs.in-project true
poetry config virtualenvs.create true
poetry config virtualenvs.prefer-active-python true

python3.13 -m venv .venv
source .venv/bin/activate

poetry install




# Update the version using Poetry to ensure it's in sync
poetry version 0.1.19

# Clean and rebuild
rm -rf dist/
hatch build

# Verify the version in the built package
ls -l dist/