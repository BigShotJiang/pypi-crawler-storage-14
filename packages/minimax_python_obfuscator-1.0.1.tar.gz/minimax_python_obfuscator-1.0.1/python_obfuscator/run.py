#!/usr/bin/env python3
"""
Python Multi-Level Obfuscator
Entry point script with command-line interface
"""

import sys
import os
import argparse
import json
from pathlib import Path

# Add current directory to path
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

from main import ObfuscationGUI, ObfuscationEngine, ObfuscationConfig
from utils.validation_utils import CodeValidator
from utils.file_utils import FileManager

def cli_obfuscate(args):
    """Command-line obfuscation interface"""
    print(f"Obfuscating file: {args.input}")
    print(f"Output directory: {args.output}")
    
    # Validate input file
    if not FileManager.validate_file_path(args.input):
        print(f"Error: Input file '{args.input}' not found or not accessible")
        return False
    
    # Load configuration
    config = ObfuscationConfig()
    
    # Update config based on args (with proper attribute checking)
    if hasattr(args, 'no_memory') and args.no_memory:
        config.set("memory_level", "enabled", False)
    if hasattr(args, 'no_binary') and args.no_binary:
        config.set("binary_level", "enabled", False)
    if hasattr(args, 'machine') and args.machine:
        config.set("machine_level", "enabled", True)
    
    config.set("output_directory", args.output)
    
    # Run obfuscation
    engine = ObfuscationEngine(config)
    
    # Simple progress callback
    def progress_callback(value):
        print(f"Progress: {value}%")
    
    engine.set_progress_callback(progress_callback)
    
    try:
        results = engine.obfuscate_file(args.input, args.output)
        
        if results["success"]:
            print("\\nObfuscation completed successfully!")
            if results["memory_file"]:
                print(f"Memory-level file: {results['memory_file']}")
            if results["binary_file"]:
                print(f"Binary-level file: {results['binary_file']}")
            if results["machine_file"]:
                print(f"Machine-level file: {results['machine_file']}")
        else:
            print("\\nObfuscation failed!")
            for error in results["errors"]:
                print(f"Error: {error}")
        
        return results["success"]
        
    except Exception as e:
        print(f"Obfuscation error: {e}")
        return False

def cli_validate(args):
    """Command-line validation interface"""
    print(f"Validating file: {args.input}")
    
    try:
        with open(args.input, 'r', encoding='utf-8') as f:
            code = f.read()
        
        validator = CodeValidator()
        report = validator.generate_validation_report(code, args.input)
        
        # Display results
        print(f"\\nValidation Results:")
        print(f"Syntax valid: {'Yes' if report['syntax_valid'] else 'No'}")
        
        if report['syntax_errors']:
            print("Syntax errors:")
            for error in report['syntax_errors']:
                print(f"  - {error}")
        
        print(f"\\nComplexity Metrics:")
        for key, value in report['complexity'].items():
            print(f"  {key}: {value}")
        
        print(f"\\nDependencies:")
        for dep in report['dependencies'][:10]:  # Show first 10
            print(f"  - {dep}")
        if len(report['dependencies']) > 10:
            print(f"  ... and {len(report['dependencies']) - 10} more")
        
        if report['suspicious_patterns']:
            print(f"\\nSuspicious patterns:")
            for pattern in report['suspicious_patterns']:
                print(f"  - {pattern}")
        
        if report['secrets_found']:
            print(f"\\nPotential secrets:")
            for secret in report['secrets_found']:
                print(f"  - {secret}")
        
        suitable, reason = validator.is_suitable_for_obfuscation(report)
        print(f"\\nSuitable for obfuscation: {'Yes' if suitable else 'No'}")
        print(f"Reason: {reason}")
        
        print(f"\\nRecommendations:")
        for rec in report['recommendations']:
            print(f"  - {rec}")
        
        # Save report if requested
        if args.report:
            report_file = args.report
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            print(f"\\nDetailed report saved to: {report_file}")
        
        return True
        
    except Exception as e:
        print(f"Validation error: {e}")
        return False

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Python Multi-Level Obfuscator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --gui                                    # Launch GUI interface
  %(prog)s obfuscate input.py -o output/           # Obfuscate file
  %(prog)s validate input.py                       # Validate file
  %(prog)s obfuscate input.py --no-memory --binary # Binary obfuscation only
        """
    )
    
    # Global arguments
    parser.add_argument('--version', action='version', version='Python Obfuscator 1.0.0')
    
    # Subcommands
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # GUI command
    gui_parser = subparsers.add_parser('gui', help='Launch GUI interface')
    
    # Obfuscate command
    obfuscate_parser = subparsers.add_parser('obfuscate', help='Obfuscate Python file')
    obfuscate_parser.add_argument('input', help='Input Python file')
    obfuscate_parser.add_argument('-o', '--output', default='obfuscated_output', 
                                 help='Output directory (default: obfuscated_output)')
    obfuscate_parser.add_argument('--no-memory', action='store_true',
                                 help='Disable memory-level obfuscation')
    obfuscate_parser.add_argument('--no-binary', action='store_true',
                                 help='Disable binary-level obfuscation')
    obfuscate_parser.add_argument('--machine', action='store_true',
                                 help='Enable machine-level obfuscation')
    
    # Validate command
    validate_parser = subparsers.add_parser('validate', help='Validate Python file')
    validate_parser.add_argument('input', help='Input Python file')
    validate_parser.add_argument('-r', '--report', metavar='FILE',
                                help='Save validation report to file')
    
    # Demo command
    demo_parser = subparsers.add_parser('demo', help='Run demonstration')
    demo_parser.add_argument('--quick', action='store_true',
                            help='Run quick demo instead of full demo')
    
    # Parse arguments
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Execute command
    try:
        if args.command == 'gui':
            print("Starting Python Multi-Level Obfuscator GUI...")
            app = ObfuscationGUI()
            app.run()
            
        elif args.command == 'obfuscate':
            success = cli_obfuscate(args)
            sys.exit(0 if success else 1)
            
        elif args.command == 'validate':
            success = cli_validate(args)
            sys.exit(0 if success else 1)
            
        elif args.command == 'demo':
            from demo import run_full_demo, quick_demo
            if args.quick:
                quick_demo()
            else:
                run_full_demo()
                
    except KeyboardInterrupt:
        print("\\nOperation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        if '--debug' in sys.argv:
            import traceback
            traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
