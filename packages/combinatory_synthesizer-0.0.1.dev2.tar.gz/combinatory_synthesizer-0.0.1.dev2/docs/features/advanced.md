# Advanced Usage
Documents how to access, use, and modify, the internal combinatory logic synthesizer of CoSy. 