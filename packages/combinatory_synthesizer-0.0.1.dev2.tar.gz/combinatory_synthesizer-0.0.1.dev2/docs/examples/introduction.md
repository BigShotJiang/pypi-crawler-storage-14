# Introduction to the Examples
Briefly explain the different kinds of examples and what takeaways from them should be. 
Takeaways should also be explained in each example in more detail. 