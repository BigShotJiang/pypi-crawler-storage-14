# Best Practice
Documents best practice when modeling a use-case. 