# Troubleshoot
An aggregation of information that can help debug and troubleshoot the synthesis. 

## Common Errors
Documents the types of errors that the CoSy developers and users have observed to occur often. 