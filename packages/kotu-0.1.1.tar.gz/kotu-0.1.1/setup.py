from setuptools import setup, find_packages

setup(
    name="kotu",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[],
    author="Kotu Admin",
    author_email="developer@kotu.me",
    description="Kotu.me — fast links, smart analytics, developer-first APIs.",
    url="https://developer.kotu.me",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)
