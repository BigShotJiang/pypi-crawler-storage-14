def hello():
    print("Welcome to Kotu!")