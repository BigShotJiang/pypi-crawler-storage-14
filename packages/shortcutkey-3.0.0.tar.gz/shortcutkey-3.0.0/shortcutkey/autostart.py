import os
import sys

# 添加当前目录到Python路径，使其可以直接运行
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入日志模块
from shortcutkey.logger import logger
import sys
from pathlib import Path
import platform
import shutil

# 添加当前目录到Python路径，使其可以直接运行
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入日志模块
try:
    from shortcutkey.logger import logger
except ImportError:
    # 如果logger模块不存在，创建一个简单的日志记录器
    import logging
    import datetime
    logger = logging.getLogger("shortcutkey")
    logger.setLevel(logging.INFO)
    # 获取用户目录
    user_home = os.path.expanduser("~")
    # 创建日志目录
    log_dir = os.path.join(user_home, ".shortcutkey")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    # 设置日志文件名（按日期）
    today = datetime.datetime.now().strftime("%Y-%m-%d")
    log_file = os.path.join(log_dir, f"shortcutkey_{today}.log")
    # 创建文件处理器
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    # 创建格式化器
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    # 添加处理器
    if not logger.handlers:
        logger.addHandler(file_handler)
    logger.warning("logger模块未找到，使用临时日志配置")


class AutoStartManager:
    """开机自启动管理器"""
    
    def __init__(self):
        """初始化开机自启动管理器"""
        self.system = platform.system()
        self.python_exe = sys.executable
        self.script_path = shutil.which('shortcutkey') or sys.argv[0]
    
    def setup_autostart(self):
        """设置开机自启动"""
        try:
            if self.system == 'Darwin':  # macOS
                self._setup_macos_autostart()
            elif self.system == 'Windows':  # Windows
                self._setup_windows_autostart()
            else:  # Linux
                self._setup_linux_autostart()
            
            print("已设置开机自启动")
            
        except Exception as e:
            print(f"设置开机自启动失败: {e}")
    
    def _setup_macos_autostart(self):
        """设置 macOS 开机自启动"""
        # 创建 LaunchAgent 配置文件
        launch_agent_dir = Path.home() / 'Library' / 'LaunchAgents'
        launch_agent_dir.mkdir(parents=True, exist_ok=True)
        
        plist_path = launch_agent_dir / 'com.shortcutkey.plist'
        
        # 创建 plist 内容
        plist_content = f'''
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.shortcutkey</string>
    <key>ProgramArguments</key>
    <array>
        <string>{self.python_exe}</string>
        <string>-m</string>
        <string>shortcutkey.main</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>{Path.home()}/.shortcutkey/log.txt</string>
    <key>StandardErrorPath</key>
    <string>{Path.home()}/.shortcutkey/error.txt</string>
</dict>
</plist>
'''.strip()
        
        # 写入 plist 文件
        with open(plist_path, 'w') as f:
            f.write(plist_content)
    
    def _setup_windows_autostart(self):
        """设置 Windows 开机自启动"""
        # 获取注册表路径
        import winreg
        
        try:
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r'SOFTWARE\Microsoft\Windows\CurrentVersion\Run',
                0,
                winreg.KEY_SET_VALUE
            )
            
            # 设置自启动项
            winreg.SetValueEx(
                key,
                'ShortcutKey',
                0,
                winreg.REG_SZ,
                f'{self.python_exe} -m shortcutkey.main'
            )
            
            winreg.CloseKey(key)
        except ImportError:
            # 如果没有 winreg 模块，尝试创建快捷方式
            startup_folder = os.path.join(
                os.environ['APPDATA'],
                'Microsoft\Windows\Start Menu\Programs\Startup'
            )
            
            shortcut_path = os.path.join(startup_folder, 'ShortcutKey.lnk')
            
            # 创建快捷方式（简化版，实际可能需要使用 win32com.client）
            try:
                import win32com.client
                shell = win32com.client.Dispatch('WScript.Shell')
                shortcut = shell.CreateShortCut(shortcut_path)
                shortcut.Targetpath = self.python_exe
                shortcut.Arguments = '-m shortcutkey.main'
                shortcut.WorkingDirectory = os.path.dirname(self.python_exe)
                shortcut.save()
            except ImportError:
                print("无法创建 Windows 快捷方式，请安装 pywin32")
    
    def _setup_linux_autostart(self):
        """设置 Linux 开机自启动"""
        # 创建 autostart 目录
        autostart_dir = Path.home() / '.config' / 'autostart'
        autostart_dir.mkdir(parents=True, exist_ok=True)
        
        # 创建 .desktop 文件
        desktop_path = autostart_dir / 'shortcutkey.desktop'
        
        desktop_content = f'''
[Desktop Entry]
Type=Application
Name=ShortcutKey
Comment=通过快捷键打开指定软件的工具
Exec={self.python_exe} -m shortcutkey.main
StartupNotify=false
Terminal=false
'''.strip()
        
        # 写入 .desktop 文件
        with open(desktop_path, 'w') as f:
            f.write(desktop_content)
        
        # 设置可执行权限
        os.chmod(desktop_path, 0o755)