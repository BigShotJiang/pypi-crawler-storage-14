import os
import logging
import datetime

class Logger:
    """日志记录器类"""
    
    def __init__(self, name="shortcutkey", level=logging.INFO):
        """初始化日志记录器"""
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        
        # 获取用户目录
        user_home = os.path.expanduser("~")
        # 创建日志目录
        log_dir = os.path.join(user_home, ".shortcutkey/log")
        if not os.path.exists(log_dir):
            try:
                os.makedirs(log_dir)
            except Exception as e:
                print(f"创建日志目录失败: {str(e)}")
                return
        
        # 设置日志文件名（按日期）
        today = datetime.datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(log_dir, f"shortcutkey_{today}.log")
        
        # 创建文件处理器
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        
        # 创建格式化器
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        
        # 添加处理器（避免重复添加）
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)
    
    def info(self, message):
        """记录信息级别日志"""
        self.logger.info(message)
    
    def warning(self, message):
        """记录警告级别日志"""
        self.logger.warning(message)
    
    def error(self, message):
        """记录错误级别日志"""
        self.logger.error(message)
    
    def debug(self, message):
        """记录调试级别日志"""
        self.logger.debug(message)

# 创建全局日志实例
logger = Logger()