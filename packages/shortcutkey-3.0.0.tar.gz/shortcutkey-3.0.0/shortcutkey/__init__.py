"""shortcutkey - 通过快捷键打开指定软件的工具"""

__version__ = "3.0.0"
