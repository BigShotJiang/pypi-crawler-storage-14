# shortcutkey

一个简单的工具，允许用户通过自定义快捷键打开指定的软件。

## 功能特性

- 通过快捷键快速打开指定软件
- 支持命令行配置快捷键
- 开机自启动
- 后台运行
- 简洁的帮助信息

## 安装

```bash
pip install shortcutkey
```

## 使用方法

### 1. 启动程序

```bash
shortcutkey
```

程序将在后台运行，监听配置的快捷键。

### 2. 配置快捷键

首次运行时，程序会引导您配置快捷键。您也可以通过以下方式重新配置：

```bash
shortcutkey --config
```

### 3. 查看帮助

```bash
shortcutkey -h
```

## 配置文件

配置文件位于用户目录下的 `.shortcutkey/config.yaml`。您可以手动编辑此文件来修改快捷键配置。

## 支持的系统

- Windows
- macOS
- Linux

## 许可证

MIT