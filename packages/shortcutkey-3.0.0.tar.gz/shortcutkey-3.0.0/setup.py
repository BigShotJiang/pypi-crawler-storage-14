from setuptools import setup, find_packages

# 从包的__init__.py中导入版本号
import sys
sys.path.insert(0, '.')
from shortcutkey import __version__

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="shortcutkey",
    version=__version__,
    author="Your Name",
    author_email="your.email@example.com",
    description="通过快捷键打开指定软件的工具",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/shortcutkey",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        "pynput>=1.7.6",
        "pyyaml>=6.0",
        "pyinstaller>=5.0.0",
    ],
    entry_points={
        'console_scripts': [
            'shortcutkey=shortcutkey.main:main',
        ],
    },
    include_package_data=True,
    package_data={
        'shortcutkey': ['config/*.yaml'],
    },
)