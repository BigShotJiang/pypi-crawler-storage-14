"""Core functionality module for derpy container tool."""

__all__ = []