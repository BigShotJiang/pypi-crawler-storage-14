"""
Derpy daemon package for privileged operations.

This package provides the daemon server (derpyd) that runs with elevated
privileges and handles build operations via Unix domain socket communication.
"""

__version__ = "0.2.0"
