from .multiline_legacy import MultiTwiss, MultilineLegacy, _multiline_from_madx
from .shared_knobs import VarSharing