"""Main CLI application for KITECH Repository."""

import typer
from rich.console import Console

from kitech_repository import __version__
from kitech_repository.cli.commands import config, login, logout, server, start, status

console = Console()
app = typer.Typer(
    name="kitech",
    help="KITECH 제조 데이터 리포지토리 CLI",
    add_completion=False,
)

# Register top-level commands
app.add_typer(login.app, name="login", help="KITECH 서버 로그인 (서버 설정 + 인증)")
app.add_typer(logout.app, name="logout", help="KITECH 서버 로그아웃")
app.add_typer(status.app, name="status", help="연결 및 인증 상태 확인")
app.add_typer(start.app, name="start", help="TUI 파일 관리자 시작")
app.add_typer(server.app, name="server", help="서버 설정 관리")
app.add_typer(config.app, name="config", help="설정 표시 또는 초기화")


@app.command()
def version():
    """버전 정보 표시"""
    console.print(f"[bold blue]KITECH Repository CLI[/bold blue] v{__version__}")


if __name__ == "__main__":
    app()
