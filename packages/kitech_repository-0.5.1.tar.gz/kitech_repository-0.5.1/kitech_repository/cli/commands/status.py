"""Status command - show connection and authentication status."""

import typer
from rich.console import Console

from kitech_repository.core.auth import AuthManager
from kitech_repository.core.client import KitechClient
from kitech_repository.core.config import Config

console = Console(highlight=False)
app = typer.Typer()


@app.callback(invoke_without_command=True)
def status(ctx: typer.Context):
    """연결 및 인증 상태 확인"""
    try:
        config = Config.load()
        auth_manager = AuthManager(config=config)

        # Show server info
        console.print(f"\n[bold]서버:[/bold] {config.server_url}")

        # Check authentication
        if auth_manager.is_authenticated():
            try:
                with KitechClient() as client:
                    result = client.test_connection()
                    user = result.get("user", {})

                    console.print("[green]✅ 인증됨[/green]")
                    console.print(f"사용자 이름: {user.get('name', 'N/A')}")
                    console.print(f"사용자 이메일: {user.get('email', 'N/A')}")

                    # Show expiry if available
                    metadata = auth_manager._load_metadata()
                    if metadata.get("expires_at"):
                        console.print(f"만료일: {metadata.get('expires_at')}")

                    console.print("")
            except Exception as e:
                console.print(f"[red]❌ 인증 실패: {e}[/red]")
                console.print("다시 로그인해주세요: [cyan]kitech login[/cyan]")
        else:
            console.print("[yellow]⚠️  인증되지 않음[/yellow]")
            console.print("먼저 로그인해주세요: [cyan]kitech login[/cyan]")
            console.print("")

    except Exception as e:
        console.print(f"[red]❌ 상태 확인 오류: {e}[/red]")
        raise typer.Exit(1)
