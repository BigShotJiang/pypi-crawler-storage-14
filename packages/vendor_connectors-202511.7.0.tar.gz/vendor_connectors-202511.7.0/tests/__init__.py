"""Tests for cloud_connectors package."""
