#!/usr/bin/env python3
#
# TRLC - Treat Requirements Like Code
# Copyright (C) 2022-2023 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
# Copyright (C) 2024      Florian Schanda
#
# This file is part of the TRLC Python Reference Implementation.
#
# TRLC is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# TRLC is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
# License for more details.
#
# You should have received a copy of the GNU General Public License
# along with TRLC. If not, see <https://www.gnu.org/licenses/>.

from abc import ABCMeta, abstractmethod
import re

from copy import copy
from difflib import get_close_matches
from enum import Enum, auto
from collections import OrderedDict
from fractions import Fraction

from trlc.errors import TRLC_Error, Location, Message_Handler
from trlc.lexer import Token
from trlc import math

#
# This module defines the AST and related object for the TRLC
# reference implementation. There are four sections:
#
# - Valuations deal with concrete values for record objects
# - AST expressions deal with the syntax tree
# - AST entities deal with concrete objects that have been declared
# - Symbol_Table and scope deals with name resolution
#


##############################################################################
# Valuations
##############################################################################

class Value:
    # lobster-trace: LRM.Boolean_Values
    # lobster-trace: LRM.Integer_Values
    # lobster-trace: LRM.Decimal_Values
    # lobster-trace: LRM.String_Values
    # lobster-trace: LRM.Markup_String_Values
    """Polymorphic value for evaluating expressions.

    Any record references will be fully resolved.

    :attribute location: source location this value comes from
    :type: Location

    :attribute value: the value or None (for null values)
    :type: str, int, bool, fractions.Fraction, list[Value], \
    Record_Reference, Enumeration_Literal_Spec

    :attribute typ: type of the value (or None for null values)
    :type: Type
    """
    def __init__(self, location, value, typ):
        assert isinstance(location, Location)
        assert value is None or \
            isinstance(value, (str,
                               int,
                               bool,
                               list,  # for arrays
                               dict,  # for tuples
                               Fraction,
                               Record_Reference,
                               Enumeration_Literal_Spec))
        assert typ is None or isinstance(typ, Type)
        assert (typ is None) == (value is None)

        self.location = location
        self.value    = value
        self.typ      = typ

    def __eq__(self, other):
        return self.typ == other.typ and self.value == other.value

    def __repr__(self):  # pragma: no cover
        return "Value(%s)" % self.value

    def resolve_references(self, mh):
        assert isinstance(mh, Message_Handler)

        if isinstance(self.value, Record_Reference):
            self.value.resolve(mh)


##############################################################################
# AST Nodes
##############################################################################

class Node(metaclass=ABCMeta):
    """Base class for all AST items.

    :attribute location: source location
    :type: Location
    """
    def __init__(self, location):
        # lobster-exclude: Constructor only declares variables
        assert isinstance(location, Location)
        self.location = location

    def set_ast_link(self, tok):
        assert isinstance(tok, Token)
        tok.ast_link = self

    def write_indent(self, indent, message):  # pragma: no cover
        # lobster-exclude: Debugging feature
        assert isinstance(indent, int)
        assert indent >= 0
        assert isinstance(message, str)
        print(" " * (3 * indent) + message)

    @abstractmethod
    def dump(self, indent=0):  # pragma: no cover
        """Visualise the parse tree.

        This can be called for any :class:`Node` or
        :class:`Symbol_Table`, and can be very helpful for debugging
        or understanding the parse tree. The dump methods will produce
        output like this::

            Symbol_Table
               Builtin_Boolean
               Builtin_Integer
               Builtin_Decimal
               Builtin_String
               Builtin_Markup_String
               Package bar
                  Symbol_Table
                     Record_Type MyType
                        Composite_Component name
                           Optional: False
                           Type: String
                        Checks
                           Error 'description is too short'
                              Anchor: description
                              Binary Binary_Operator.COMP_GT Expression
                                 Type: Boolean
                                 Unary Unary_Operator.STRING_LENGTH Expression
                                    Type: Integer
                                    Name Reference to description
                                 Integer Literal 10
               Package instances
                  Symbol_Table
                     Record_Object SomeThing
                        Type: MyType
                        Field description: "Potato"
               Builtin_Function endswith
               Builtin_Function len
               Builtin_Function matches
               Builtin_Function startswith
               Builtin_Function oneof

        """
        assert isinstance(indent, int) and indent >= 0
        assert False, f"dump not implemented for {self.__class__.__name__}"
        # lobster-exclude: Debugging feature


class Check_Block(Node):
    """Node representing check blocks

    Semantically this has no meaning, but it's nice to have some kind
    of similar representation to how it's in the file.

    :attribute n_typ: composite type for which the checks apply
    :type: Composite_Type

    :attribute checks: list of checks
    :type: list[Check]

    """
    def __init__(self, location, n_typ):
        # lobster-trace: LRM.Check_Block
        super().__init__(location)
        assert isinstance(n_typ, Composite_Type)
        self.n_typ  = n_typ
        self.checks = []

    def add_check(self, n_check):
        # lobster-trace: LRM.Check_Evaluation_Order
        assert isinstance(n_check, Check)
        self.checks.append(n_check)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Check_Block")
        self.write_indent(indent + 1, f"Type: {self.n_typ.name}")
        for n_check in self.checks:
            n_check.dump(indent + 1)


class Compilation_Unit(Node):
    """Special node to represent the concrete file structure

    :attribute package: the main package this file declares or contributes to
    :type: Package

    :attribute imports: package imported by this file
    :type: list[Package]

    :attribute items: list of
    :type: list[Node]

    """
    def __init__(self, file_name):
        # lobster-exclude: Constructor only declares variables
        super().__init__(Location(file_name))
        self.package       = None
        self.imports       = None
        self.raw_imports   = []
        self.items         = []

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Compilation_Unit ({self.location.file_name})")
        for t_import in self.raw_imports:
            self.write_indent(indent + 1, f"Import: {t_import.value}")
        for n_item in self.items:
            n_item.dump(indent + 1)

    def set_package(self, pkg):
        # lobster-trace: LRM.Current_Package
        assert isinstance(pkg, Package)
        self.package = pkg

    def add_import(self, mh, t_import):
        # lobster-trace: LRM.Import_Visibility
        # lobster-trace: LRM.Self_Imports
        assert isinstance(mh, Message_Handler)
        assert isinstance(t_import, Token)
        assert t_import.kind == "IDENTIFIER"

        if t_import.value == self.package.name:
            mh.error(t_import.location,
                     "package %s cannot import itself" % self.package.name)

        # Skip duplicates
        for t_previous in self.raw_imports:
            if t_previous.value == t_import.value:
                mh.warning(t_import.location,
                           "duplicate import of package %s" % t_import.value)
                return

        self.raw_imports.append(t_import)

    def resolve_imports(self, mh, stab):
        # lobster-trace: LRM.Import_Visibility
        assert isinstance(mh, Message_Handler)
        assert isinstance(stab, Symbol_Table)
        self.imports = set()
        for t_import in self.raw_imports:
            # We can ignore errors here, because that just means we
            # generate more error later.
            try:
                a_import = stab.lookup(mh, t_import, Package)
                self.imports.add(a_import)
                a_import.set_ast_link(t_import)
            except TRLC_Error:
                pass

    def is_visible(self, n_pkg):
        # lobster-trace: LRM.Import_Visibility
        assert self.imports is not None
        assert isinstance(n_pkg, Package)
        return n_pkg == self.package or n_pkg in self.imports

    def add_item(self, node):
        # lobster-trace: LRM.RSL_File
        # lobster-trace: LRM.TRLC_File
        assert isinstance(node, (Concrete_Type,
                                 Check_Block,
                                 Record_Object)), \
            "trying to add %s to a compilation unit" % node.__class__.__name__
        self.items.append(node)


class Check(Node):
    """User defined check

    This represent a single user-defined check inside a check block::

      checks T {
          a /= null implies a > 5, warning "potato", a
          ^^^^^^^^^^^^^^^^^^^^^^^1 ^2      ^3        ^4

    :attribute n_type: The tuple/record type this check applies to
    :type: Composite_Type

    :attribute n_expr: The boolean expression for the check (see 1)
    :type: Expression

    :attribute n_anchor: The (optional) record component where the message \
    should be issued (or None) (see 4)
    :type: Composite_Component

    :attribute severity: warning, error, or fatal (see 2; also if this is \
    not specified the default is 'error')
    :type: str

    :attribute message: the user-supplied message (see 3)
    :type: str
    """
    def __init__(self,
                 n_type,
                 n_expr,
                 n_anchor,
                 severity,
                 t_message,
                 extrainfo):
        # lobster-trace: LRM.Check_Block
        assert isinstance(n_type, Composite_Type)
        assert isinstance(n_expr, Expression)
        assert isinstance(n_anchor, Composite_Component) or n_anchor is None
        assert severity in ("warning", "error", "fatal")
        assert isinstance(t_message, Token)
        assert t_message.kind == "STRING"
        assert isinstance(extrainfo, str) or extrainfo is None
        super().__init__(t_message.location)

        self.n_type    = n_type
        self.n_expr    = n_expr
        self.n_anchor  = n_anchor
        self.severity  = severity
        # lobster-trace: LRM.No_Newlines_In_Message
        # This is the error recovery strategy if we find newlines in
        # the short error messages: we just remove them. The error
        # raised is non-fatal.
        self.message   = t_message.value.replace("\n", " ")
        self.extrainfo = extrainfo

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        if self.severity == "warning":
            self.write_indent(indent, f"Warning '{self.message}'")
        elif self.severity == "error":
            self.write_indent(indent, f"Error '{self.message}'")
        else:
            self.write_indent(indent, f"Fatal error '{self.message}'")
        if self.n_anchor:
            self.write_indent(indent + 1, f"Anchor: {self.n_anchor.name}")
        self.n_expr.dump(indent + 1)

    def get_real_location(self, composite_object):
        # lobster-exclude: LRM.Anchoring
        assert isinstance(composite_object, (Record_Object,
                                             Tuple_Aggregate))
        if isinstance(composite_object, Record_Object):
            fields = composite_object.field
        else:
            fields = composite_object.value

        if self.n_anchor is None or fields[self.n_anchor.name] is None:
            return composite_object.location
        else:
            return fields[self.n_anchor.name].location

    def perform(self, mh, composite_object):
        # lobster-trace: LRM.Check_Messages
        # lobster-trace: LRM.Check_Severity
        assert isinstance(mh, Message_Handler)
        assert isinstance(composite_object, (Record_Object,
                                             Tuple_Aggregate))

        if isinstance(composite_object, Record_Object):
            result = self.n_expr.evaluate(mh, copy(composite_object.field))
        else:
            result = self.n_expr.evaluate(mh, copy(composite_object.value))
        assert isinstance(result.value, bool)

        if not result.value:
            loc = self.get_real_location(composite_object)
            if self.severity == "warning":
                mh.warning(location    = loc,
                           message     = self.message,
                           explanation = self.extrainfo,
                           user        = True)
            else:
                mh.error(location    = loc,
                         message     = self.message,
                         explanation = self.extrainfo,
                         fatal       = self.severity == "fatal",
                         user        = True)
                return False

        return True

##############################################################################
# AST Nodes (Expressions)
##############################################################################


class Unary_Operator(Enum):
    # lobster-exclude: Utility enumeration for unary operators
    MINUS          = auto()
    PLUS           = auto()
    LOGICAL_NOT    = auto()
    ABSOLUTE_VALUE = auto()

    STRING_LENGTH  = auto()
    ARRAY_LENGTH   = auto()

    CONVERSION_TO_INT     = auto()
    CONVERSION_TO_DECIMAL = auto()


class Binary_Operator(Enum):
    # lobster-exclude: Utility enumeration for binary operators
    LOGICAL_AND     = auto()    # Short-circuit
    LOGICAL_OR      = auto()    # Short-circuit
    LOGICAL_XOR     = auto()
    LOGICAL_IMPLIES = auto()    # Short-circuit

    COMP_EQ  = auto()
    COMP_NEQ = auto()
    COMP_LT  = auto()
    COMP_LEQ = auto()
    COMP_GT  = auto()
    COMP_GEQ = auto()

    STRING_CONTAINS   = auto()
    STRING_STARTSWITH = auto()
    STRING_ENDSWITH   = auto()
    STRING_REGEX      = auto()

    ARRAY_CONTAINS = auto()

    PLUS      = auto()
    MINUS     = auto()
    TIMES     = auto()
    DIVIDE    = auto()
    REMAINDER = auto()

    POWER = auto()

    INDEX = auto()


class Expression(Node, metaclass=ABCMeta):
    """Abstract base class for all expressions.

    :attribute typ: The type of this expression (or None for null values)
    :type: Type
    """
    def __init__(self, location, typ):
        # lobster-exclude: Constructor only declares variables
        super().__init__(location)
        assert typ is None or isinstance(typ, Type)
        self.typ = typ

    def evaluate(self, mh, context):  # pragma: no cover
        """Evaluate the expression in the given context

        The context can be None, in which case the expression is
        evaluated in a static context. Otherwise it must be a
        dictionary that maps names (such as record fields or
        quantified variables) to expressions.

        :param mh: the message handler to use
        :type mh: Message_Handler
        :param context: name mapping or None (for a static context)
        :type context: dict[str, Expression]
        :raise TRLC_Error: if the expression cannot be evaluated
        :return: result of the evaluation
        :rtype: Value
        """
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        assert False, "evaluate not implemented for %s" % \
            self.__class__.__name__

    @abstractmethod
    def to_string(self):  # pragma: no cover
        assert False, "to_string not implemented for %s" % \
            self.__class__.__name__

    def ensure_type(self, mh, typ):
        # lobster-trace: LRM.Restricted_Null
        # lobster-trace: LRM.Null_Is_Invalid

        assert isinstance(typ, (type, Type))
        if self.typ is None:
            mh.error(self.location,
                     "null is not permitted here")
        elif isinstance(typ, type) and not isinstance(self.typ, typ):
            mh.error(self.location,
                     "expected expression of type %s, got %s instead" %
                     (typ.__name__,
                      self.typ.__class__.__name__))
        elif isinstance(typ, Type) and self.typ != typ:
            mh.error(self.location,
                     "expected expression of type %s, got %s instead" %
                     (typ.name,
                      self.typ.name))

    def resolve_references(self, mh):
        assert isinstance(mh, Message_Handler)

    @abstractmethod
    def can_be_null(self):
        """Test if the expression could return null

        Checks the expression if it could generate a null value
        *without* raising an error. For example `x` could generate a
        null value if `x` is a record component that is
        optional. However `x + 1` could not, since an error would
        occur earlier.

        :return: possibility of encountering null
        :rtype: bool

        """
        assert False, "can_be_null not implemented for %s" % \
            self.__class__.__name__


class Implicit_Null(Expression):
    """Synthesised null values

    When a record object or tuple aggregate is declared and an
    optional component or field is not specified, we synthesise an
    implicit null expression for this.

    For example given this TRLC type::

      type T {
         x optional Integer
      }

    And this declaration::

      T Potato {}

    Then the field mapping for Potato will be::

      {x: Implicit_Null}

    Each field will get its own implicit null. Further note that this
    implicit null is distinct from the explicit :class:`Null_Literal`
    that can appear in check expressions.

    """
    def __init__(self, composite_object, composite_component):
        # lobster-trace: LRM.Unspecified_Optional_Components
        assert isinstance(composite_object, (Record_Object,
                                             Tuple_Aggregate))
        assert isinstance(composite_component, Composite_Component)
        super().__init__(composite_object.location, None)

    def to_string(self):
        return "null"

    def evaluate(self, mh, context):
        # lobster-trace: LRM.Unspecified_Optional_Components
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, None, None)

    def to_python_object(self):
        return None

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Implicit_Null")

    def can_be_null(self):
        return True


class Literal(Expression, metaclass=ABCMeta):
    """Abstract base for all Literals

    Does not offer any additional features, but it's a nice way to
    group together all literal types. This is useful if you want to
    check if you are dealing with a literal::

      isinstance(my_expression, Literal)

    """
    @abstractmethod
    def to_python_object(self):
        assert False


class Null_Literal(Literal):
    # lobster-trace: LRM.Primary
    """The null literal

    This can appear in check expressions::

      a /= null implies a > 5
           ^^^^

    Please note that this is distinct from the :class:`Implicit_Null`
    values that appear in record objects.

    """
    def __init__(self, token):
        assert isinstance(token, Token)
        assert token.kind == "KEYWORD"
        assert token.value == "null"
        super().__init__(token.location, None)

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, "Null Literal")

    def to_string(self):
        return "null"

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, None, None)

    def to_python_object(self):
        return None

    def can_be_null(self):
        return True


class Integer_Literal(Literal):
    # lobster-trace: LRM.Integer_Values
    # lobster-trace: LRM.Primary
    """Integer literals

    Note that these are always positive. A negative integer is
    actually a unary negation expression, operating on a positive
    integer literal::

      x == -5

    This would create the following tree::

       OP_EQUALITY
          NAME_REFERENCE x
          UNARY_EXPRESSION -
             INTEGER_LITERAL 5

    :attribute value: the non-negative integer value
    :type: int
    """
    def __init__(self, token, typ):
        assert isinstance(token, Token)
        assert token.kind == "INTEGER"
        assert isinstance(typ, Builtin_Integer)
        super().__init__(token.location, typ)

        self.value = token.value

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"Integer Literal {self.value}")

    def to_string(self):
        return str(self.value)

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, self.value, self.typ)

    def to_python_object(self):
        return self.value

    def can_be_null(self):
        return False


class Decimal_Literal(Literal):
    # lobster-trace: LRM.Decimal_Values
    # lobster-trace: LRM.Primary
    """Decimal literals

    Note that these are always positive. A negative decimal is
    actually a unary negation expression, operating on a positive
    decimal literal::

      x == -5.0

    This would create the following tree::

       OP_EQUALITY
          NAME_REFERENCE x
          UNARY_EXPRESSION -
             DECIMAL_LITERAL 5.0

    :attribute value: the non-negative decimal value
    :type: fractions.Fraction
    """
    def __init__(self, token, typ):
        assert isinstance(token, Token)
        assert token.kind == "DECIMAL"
        assert isinstance(typ, Builtin_Decimal)
        super().__init__(token.location, typ)

        self.value = token.value

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"Decimal Literal {self.value}")

    def to_string(self):
        return str(self.value)

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, self.value, self.typ)

    def to_python_object(self):
        return float(self.value)

    def can_be_null(self):
        return False


class String_Literal(Literal):
    # lobster-trace: LRM.String_Values
    # lobster-trace: LRM.Markup_String_Values
    # lobster-trace: LRM.Primary
    """String literals

    Note the value of the string does not include the quotation marks,
    and any escape sequences are fully resolved. For example::

       "foo\\"bar"

    Will have a value of ``foo"bar``.

    :attribute value: string content
    :type: str

    :attribute references: resolved references of a markup string
    :type: list[Record_Reference]

    """
    def __init__(self, token, typ):
        assert isinstance(token, Token)
        assert token.kind == "STRING"
        assert isinstance(typ, Builtin_String)
        super().__init__(token.location, typ)

        self.value          = token.value
        self.has_references = isinstance(typ, Builtin_Markup_String)
        self.references     = []

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"String Literal {repr(self.value)}")
        if self.has_references:
            self.write_indent(indent + 1, "Markup References")
            for ref in self.references:
                ref.dump(indent + 2)

    def to_string(self):
        return self.value

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, self.value, self.typ)

    def to_python_object(self):
        return self.value

    def resolve_references(self, mh):
        assert isinstance(mh, Message_Handler)
        for ref in self.references:
            ref.resolve_references(mh)

    def can_be_null(self):
        return False


class Boolean_Literal(Literal):
    # lobster-trace: LRM.Boolean_Values
    # lobster-trace: LRM.Primary
    """Boolean values

    :attribute value: the boolean value
    :type: bool
    """
    def __init__(self, token, typ):
        assert isinstance(token, Token)
        assert token.kind == "KEYWORD"
        assert token.value in ("false", "true")
        assert isinstance(typ, Builtin_Boolean)
        super().__init__(token.location, typ)

        self.value = token.value == "true"

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"Boolean Literal {self.value}")

    def to_string(self):
        return str(self.value)

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, self.value, self.typ)

    def to_python_object(self):
        return self.value

    def can_be_null(self):
        return False


class Enumeration_Literal(Literal):
    """Enumeration values

    Note that this is distinct from
    :class:`Enumeration_Literal_Spec`. An enumeration literal is a
    specific mention of an enumeration member in an expression::

       foo != my_enum.POTATO
              ^^^^^^^^^^^^^^

    To get to the string value of the enumeration literal
    (i.e. ``POTATO`` here) you can get the name of the literal spec
    itself: ``enum_lit.value.name``; and to get the name of the
    enumeration (i.e. ``my_enum`` here) you can use
    ``enum_lit.value.n_typ.name``.

    :attribute value: enumeration value
    :type: Enumeration_Literal_Spec

    """
    def __init__(self, location, literal):
        # lobster-exclude: Constructor only declares variables
        assert isinstance(literal, Enumeration_Literal_Spec)
        super().__init__(location, literal.n_typ)

        self.value = literal

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent,
                          f"Enumeration Literal {self.typ.name}.{self.value.name}")

    def to_string(self):
        return self.typ.name + "." + self.value.name

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, self.value, self.typ)

    def to_python_object(self):
        return self.value.name

    def can_be_null(self):
        return False


class Array_Aggregate(Expression):
    """Instances of array types

    This is created when assigning to array components::

       potatoes = ["picasso", "yukon gold", "sweet"]
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    The type of expression that can be found in an array is somewhat
    limited:

    * :class:`Literal`
    * :class:`Array_Aggregate`
    * :class:`Record_Reference`

    :attribute value: contents of the array
    :type: list[Expression]

    """
    def __init__(self, location, typ):
        # lobster-trace: LRM.Record_Object_Declaration

        super().__init__(location, typ)
        self.value = []

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Array_Aggregate")
        for n_value in self.value:
            n_value.dump(indent + 1)

    def append(self, value):
        assert isinstance(value, (Literal,
                                  Unary_Expression,
                                  Array_Aggregate,
                                  Tuple_Aggregate,
                                  Record_Reference))
        self.value.append(value)

    def to_string(self):
        return "[" + ", ".join(x.to_string() for x in self.value) + "]"

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location,
                     list(element.evaluate(mh, context)
                          for element in self.value),
                     self.typ)

    def resolve_references(self, mh):
        assert isinstance(mh, Message_Handler)

        for val in self.value:
            val.resolve_references(mh)

    def to_python_object(self):
        return [x.to_python_object() for x in self.value]

    def can_be_null(self):
        return False


class Tuple_Aggregate(Expression):
    """Instances of a tuple

    This is created when assigning to a tuple components. There are
    two forms, the ordinary form::

       coordinate = (12.3, 40.0)
                    ^^^^^^^^^^^^

    And the separator form::

       item = 12345@42
              ^^^^^^^^

    In terms of AST there is no difference, as the separator is only
    syntactic sugar.

    :attribute value: contents of the tuple
    :type: dict[str, Expression]

    """
    def __init__(self, location, typ):
        # lobster-trace: LRM.Unspecified_Optional_Components
        # lobster-trace: LRM.Record_Object_Declaration

        super().__init__(location, typ)
        self.value = {n_field.name : Implicit_Null(self, n_field)
                      for n_field in self.typ.components.values()}

    def assign(self, field, value):
        assert isinstance(field, str)
        assert isinstance(value, (Literal,
                                  Unary_Expression,
                                  Tuple_Aggregate,
                                  Record_Reference)), \
                "value is %s" % value.__class__.__name__
        assert field in self.typ.components

        self.value[field] = value

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Tuple_Aggregate")
        self.write_indent(indent + 1, f"Type: {self.typ.name}")
        for n_item in self.typ.iter_sequence():
            if isinstance(n_item, Composite_Component):
                self.value[n_item.name].dump(indent + 1)

    def to_string(self):
        first = True
        if self.typ.has_separators():
            rv = ""
        else:
            rv = "("
        for n_item in self.typ.iter_sequence():
            if isinstance(n_item, Separator):
                rv += " %s " % n_item.token.value
            elif first:
                first = False
            else:
                rv += ", "

            if isinstance(n_item, Composite_Component):
                rv += self.value[n_item.name].to_string()
        if self.typ.has_separators():
            rv = ""
        else:
            rv = ")"
        return rv

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location,
                     {name : element.evaluate(mh, context)
                      for name, element in self.value.items()},
                     self.typ)

    def resolve_references(self, mh):
        assert isinstance(mh, Message_Handler)

        for val in self.value.values():
            val.resolve_references(mh)

    def to_python_object(self):
        return {name: value.to_python_object()
                for name, value in self.value.items()}

    def can_be_null(self):
        return False


class Record_Reference(Expression):
    """Reference to another record object

    This can appear in record object declarations::

      Requirement Kitten {
          depends_on = Other_Package.Cat
                       ^1            ^2
      }

    Note that this is distinct from :class:`Record_Object`. It is just
    the name; to get to the object referred to by this you can consult
    the target attribute.

    The reason we have this indirection is that not all names can be
    immediately resolved on parsing in the TRLC language.

    Note that while the containing package (see 1) is optional in the
    source language, the containing package will always be filled in
    in this AST node.

    :attribute name: The name of the record (see 2)
    :type: str

    :attribute target: The concrete record object referred to by (2)
    :type: Record_Object

    :attribute package: The package (see 1) supposed to contain (2)
    :type: Package

    """
    def __init__(self, location, name, typ, package):
        # lobster-exclude: Constructor only declares variables
        assert isinstance(location, Location)
        assert isinstance(name, str)
        assert isinstance(typ, Record_Type) or typ is None
        assert isinstance(package, Package)
        super().__init__(location, typ)

        self.name    = name
        self.target  = None
        self.package = package

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Record Reference {self.name}")
        self.write_indent(indent + 1,
                          f"Resolved: {self.target is not None}")

    def to_string(self):
        return self.name

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)
        return Value(self.location, self, self.typ)

    def resolve_references(self, mh):
        # lobster-trace: LRM.References_To_Extensions
        assert isinstance(mh, Message_Handler)

        self.target = self.package.symbols.lookup_direct(
            mh                = mh,
            name              = self.name,
            error_location    = self.location,
            required_subclass = Record_Object)
        if self.typ is None:
            self.typ = self.target.n_typ
        elif not self.target.n_typ.is_subclass_of(self.typ):
            mh.error(self.location,
                     "expected reference of type %s, but %s is of type %s" %
                     (self.typ.name,
                      self.target.name,
                      self.target.n_typ.name))

    def to_python_object(self):
        return self.target.fully_qualified_name()

    def can_be_null(self):
        return False


class Name_Reference(Expression):
    # lobster-trace: LRM.Qualified_Name
    # lobster-trace: LRM.Static_Regular_Expression

    """Reference to a name

    Name reference to either a :class:`Composite_Component` or a
    :class:`Quantified_Variable`. The actual value of course depends
    on the context. See :py:meth:`Expression.evaluate()`.

    For example::

      (forall x in potato => x > 1)
                   ^1        ^2

    Both indicated parts are a :class:`Name_Reference`, the first one
    refers to a :class:`Composite_Component`, and the second refers to a
    :class:`Quantified_Variable`.

    :attribute entity: the entity named here
    :type: Composite_Component, Quantified_Variable
    """
    def __init__(self, location, entity):
        assert isinstance(entity, (Composite_Component,
                                   Quantified_Variable))
        super().__init__(location, entity.n_typ)
        self.entity = entity

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"Name Reference to {self.entity.name}")

    def to_string(self):
        return self.entity.name

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        if context is None:
            mh.error(self.location,
                     "cannot be used in a static context")

        assert self.entity.name in context
        return context[self.entity.name].evaluate(mh, context)

    def can_be_null(self):
        # The only way we could generate null here (without raising
        # error earlier) is when we refer to a component that is
        # optional.
        if isinstance(self.entity, Composite_Component):
            return self.entity.optional
        else:
            return False


class Unary_Expression(Expression):
    """Expression with only one operand

    This captures the following operations:

    * Unary_Operator.PLUS (e.g. ``+5``)
    * Unary_Operator.MINUS (e.g. ``-5``)
    * Unary_Operator.ABSOLUTE_VALUE (e.g. ``abs 42``)
    * Unary_Operator.LOGICAL_NOT (e.g. ``not True``)
    * Unary_Operator.STRING_LENGTH (e.g. ``len("foobar")``)
    * Unary_Operator.ARRAY_LENGTH (e.g. ``len(component_name)``)
    * Unary_Operator.CONVERSION_TO_INT (e.g. ``Integer(5.3)``)
    * Unary_Operator.CONVERSION_TO_DECIMAL (e.g. ``Decimal(5)``)

    Note that several builtin functions are mapped to unary operators.

    :attribute operator: the operation
    :type: Unary_Operator

    :attribute n_operand: the expression we operate on
    :type: Expression

    """
    def __init__(self, mh, location, typ, operator, n_operand):
        # lobster-trace: LRM.Simple_Expression
        # lobster-trace: LRM.Relation
        # lobster-trace: LRM.Factor
        # lobster-trace: LRM.Signature_Len
        # lobster-trace: LRM.Signature_Type_Conversion

        super().__init__(location, typ)
        assert isinstance(mh, Message_Handler)
        assert isinstance(operator, Unary_Operator)
        assert isinstance(n_operand, Expression)
        self.operator  = operator
        self.n_operand = n_operand

        if operator in (Unary_Operator.MINUS,
                        Unary_Operator.PLUS,
                        Unary_Operator.ABSOLUTE_VALUE):
            self.n_operand.ensure_type(mh, Builtin_Numeric_Type)
        elif operator == Unary_Operator.LOGICAL_NOT:
            self.n_operand.ensure_type(mh, Builtin_Boolean)
        elif operator == Unary_Operator.STRING_LENGTH:
            self.n_operand.ensure_type(mh, Builtin_String)
        elif operator == Unary_Operator.ARRAY_LENGTH:
            self.n_operand.ensure_type(mh, Array_Type)
        elif operator == Unary_Operator.CONVERSION_TO_INT:
            self.n_operand.ensure_type(mh, Builtin_Numeric_Type)
        elif operator == Unary_Operator.CONVERSION_TO_DECIMAL:
            self.n_operand.ensure_type(mh, Builtin_Numeric_Type)
        else:
            mh.ice_loc(self.location,
                       "unexpected unary operation %s" % operator)

    def to_string(self):
        prefix_operators = {
            Unary_Operator.MINUS          : "-",
            Unary_Operator.PLUS           : "+",
            Unary_Operator.ABSOLUTE_VALUE : "abs ",
            Unary_Operator.LOGICAL_NOT    : "not ",
        }
        function_calls = {
            Unary_Operator.STRING_LENGTH         : "len",
            Unary_Operator.ARRAY_LENGTH          : "len",
            Unary_Operator.CONVERSION_TO_INT     : "Integer",
            Unary_Operator.CONVERSION_TO_DECIMAL : "Decimal"
        }

        if self.operator in prefix_operators:
            return prefix_operators[self.operator] + \
                self.n_operand.to_string()

        elif self.operator in function_calls:
            return "%s(%s)" % (function_calls[self.operator],
                               self.n_operand.to_string())

        else:
            assert False

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Unary {self.operator} Expression")
        self.write_indent(indent + 1, f"Type: {self.typ.name}")
        self.n_operand.dump(indent + 1)

    def evaluate(self, mh, context):
        # lobster-trace: LRM.Null_Is_Invalid
        # lobster-trace: LRM.Signature_Len
        # lobster-trace: LRM.Signature_Type_Conversion
        # lobster-trace: LRM.Len_Semantics
        # lobster-trace: LRM.Integer_Conversion_Semantics
        # lobster-trace: LRM.Decimal_Conversion_Semantics

        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        v_operand = self.n_operand.evaluate(mh, context)
        if v_operand.value is None:
            mh.error(v_operand.location,
                     "input to unary expression %s (%s) must not be null" %
                     (self.to_string(),
                      mh.cross_file_reference(self.location)))

        if self.operator == Unary_Operator.MINUS:
            return Value(location = self.location,
                         value    = -v_operand.value,
                         typ      = self.typ)
        elif self.operator == Unary_Operator.PLUS:
            return Value(location = self.location,
                         value    = +v_operand.value,
                         typ      = self.typ)
        elif self.operator == Unary_Operator.LOGICAL_NOT:
            return Value(location = self.location,
                         value    = not v_operand.value,
                         typ      = self.typ)
        elif self.operator == Unary_Operator.ABSOLUTE_VALUE:
            return Value(location = self.location,
                         value    = abs(v_operand.value),
                         typ      = self.typ)
        elif self.operator in (Unary_Operator.STRING_LENGTH,
                               Unary_Operator.ARRAY_LENGTH):
            return Value(location = self.location,
                         value    = len(v_operand.value),
                         typ      = self.typ)
        elif self.operator == Unary_Operator.CONVERSION_TO_INT:
            if isinstance(v_operand.value, Fraction):
                return Value(
                    location = self.location,
                    value    = math.round_nearest_away(v_operand.value),
                    typ      = self.typ)
            else:
                return Value(location = self.location,
                             value    = v_operand.value,
                             typ      = self.typ)
        elif self.operator == Unary_Operator.CONVERSION_TO_DECIMAL:
            return Value(location = self.location,
                         value    = Fraction(v_operand.value),
                         typ      = self.typ)
        else:
            mh.ice_loc(self.location,
                       "unexpected unary operation %s" % self.operator)

    def to_python_object(self):
        assert self.operator in (Unary_Operator.MINUS,
                                 Unary_Operator.PLUS)
        val = self.n_operand.to_python_object()
        if self.operator == Unary_Operator.MINUS:
            return -val
        else:
            return val

    def can_be_null(self):
        return False


class Binary_Expression(Expression):
    """Expression with two operands

    This captures the following operations:

    * Binary_Operator.LOGICAL_AND (e.g. ``a and b``)
    * Binary_Operator.LOGICAL_OR (e.g. ``a or b``)
    * Binary_Operator.LOGICAL_XOR (e.g. ``a xor b``)
    * Binary_Operator.LOGICAL_IMPLIES (e.g. ``a implies b``)
    * Binary_Operator.COMP_EQ (e.g. ``a == null``)
    * Binary_Operator.COMP_NEQ (e.g. ``a != null``)
    * Binary_Operator.COMP_LT (e.g. ``1 < 2``)
    * Binary_Operator.COMP_LEQ (e.g. ``1 <= 2``)
    * Binary_Operator.COMP_GT (e.g. ``a > b``)
    * Binary_Operator.COMP_GEQ (e.g. ``a >= b``)
    * Binary_Operator.STRING_CONTAINS (e.g. ``"foo" in "foobar"``)
    * Binary_Operator.STRING_STARTSWITH (e.g. ``startswith("foo", "f")``)
    * Binary_Operator.STRING_ENDSWITH (e.g. ``endswith("foo", "o")``)
    * Binary_Operator.STRING_REGEX (e.g. ``matches("foo", ".o.``)
    * Binary_Operator.ARRAY_CONTAINS (e.g. ``42 in arr``)
    * Binary_Operator.PLUS (e.g. ``42 + b`` or ``"foo" + bar``)
    * Binary_Operator.MINUS (e.g. ``a - 1``)
    * Binary_Operator.TIMES (e.g. ``2 * x``)
    * Binary_Operator.DIVIDE (e.g. ``x / 2``)
    * Binary_Operator.REMAINDER (e.g. ``x % 2``)
    * Binary_Operator.POWER (e.g. ``x ** 2``)
    * Binary_Operator.INDEX (e.g. ``foo[2]``)

    Note that several builtin functions are mapped to unary operators.

    Note also that the plus operation is supported for integers,
    rationals and strings.

    :attribute operator: the operation
    :type: Binary_Operator

    :attribute n_lhs: the first operand
    :type: Expression

    :attribute n_rhs: the second operand
    :type: Expression

    """
    def __init__(self, mh, location, typ, operator, n_lhs, n_rhs):
        # lobster-trace: LRM.Expression
        # lobster-trace: LRM.Relation
        # lobster-trace: LRM.Simple_Expression
        # lobster-trace: LRM.Term
        # lobster-trace: LRM.Factor
        # lobster-trace: LRM.Signature_String_End_Functions
        # lobster-trace: LRM.Signature_Matches

        super().__init__(location, typ)
        assert isinstance(mh, Message_Handler)
        assert isinstance(operator, Binary_Operator)
        assert isinstance(n_lhs, Expression)
        assert isinstance(n_rhs, Expression)
        self.operator = operator
        self.n_lhs    = n_lhs
        self.n_rhs    = n_rhs

        if operator in (Binary_Operator.LOGICAL_AND,
                        Binary_Operator.LOGICAL_OR,
                        Binary_Operator.LOGICAL_XOR,
                        Binary_Operator.LOGICAL_IMPLIES):
            self.n_lhs.ensure_type(mh, Builtin_Boolean)
            self.n_rhs.ensure_type(mh, Builtin_Boolean)

        elif operator in (Binary_Operator.COMP_EQ,
                          Binary_Operator.COMP_NEQ):
            if (self.n_lhs.typ is None) or (self.n_rhs.typ is None):
                # We can compary anything to null (including itself)
                pass
            elif self.n_lhs.typ != self.n_rhs.typ:
                # Otherwise we can compare anything, as long as the
                # types match
                mh.error(self.location,
                         "type mismatch: %s and %s do not match" %
                         (self.n_lhs.typ.name,
                          self.n_rhs.typ.name))

        elif operator in (Binary_Operator.COMP_LT,
                          Binary_Operator.COMP_LEQ,
                          Binary_Operator.COMP_GT,
                          Binary_Operator.COMP_GEQ):
            self.n_lhs.ensure_type(mh, Builtin_Numeric_Type)
            self.n_rhs.ensure_type(mh, self.n_lhs.typ)

        elif operator in (Binary_Operator.STRING_CONTAINS,
                          Binary_Operator.STRING_STARTSWITH,
                          Binary_Operator.STRING_ENDSWITH,
                          Binary_Operator.STRING_REGEX):
            self.n_lhs.ensure_type(mh, Builtin_String)
            self.n_rhs.ensure_type(mh, Builtin_String)

        elif operator == Binary_Operator.ARRAY_CONTAINS:
            self.n_rhs.ensure_type(mh, Array_Type)
            self.n_lhs.ensure_type(mh, self.n_rhs.typ.element_type.__class__)

        elif operator == Binary_Operator.PLUS:
            if isinstance(self.n_lhs.typ, Builtin_Numeric_Type):
                self.n_rhs.ensure_type(mh, self.n_lhs.typ)
            else:
                self.n_lhs.ensure_type(mh, Builtin_String)
                self.n_rhs.ensure_type(mh, Builtin_String)

        elif operator in (Binary_Operator.MINUS,
                          Binary_Operator.TIMES,
                          Binary_Operator.DIVIDE):
            self.n_lhs.ensure_type(mh, Builtin_Numeric_Type)
            self.n_rhs.ensure_type(mh, self.n_lhs.typ)

        elif operator == Binary_Operator.POWER:
            self.n_lhs.ensure_type(mh, Builtin_Numeric_Type)
            self.n_rhs.ensure_type(mh, Builtin_Integer)

        elif operator == Binary_Operator.REMAINDER:
            self.n_lhs.ensure_type(mh, Builtin_Integer)
            self.n_rhs.ensure_type(mh, Builtin_Integer)

        elif operator == Binary_Operator.INDEX:
            self.n_lhs.ensure_type(mh, Array_Type)
            self.n_rhs.ensure_type(mh, Builtin_Integer)

        else:
            mh.ice_loc(self.location,
                       "unexpected binary operation %s" % operator)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Binary {self.operator} Expression")
        self.write_indent(indent + 1, f"Type: {self.typ.name}")
        self.n_lhs.dump(indent + 1)
        self.n_rhs.dump(indent + 1)

    def to_string(self):
        infix_operators = {
            Binary_Operator.LOGICAL_AND     : "and",
            Binary_Operator.LOGICAL_OR      : "or",
            Binary_Operator.LOGICAL_XOR     : "xor",
            Binary_Operator.LOGICAL_IMPLIES : "implies",
            Binary_Operator.COMP_EQ         : "==",
            Binary_Operator.COMP_NEQ        : "!=",
            Binary_Operator.COMP_LT         : "<",
            Binary_Operator.COMP_LEQ        : "<=",
            Binary_Operator.COMP_GT         : ">",
            Binary_Operator.COMP_GEQ        : ">=",
            Binary_Operator.STRING_CONTAINS : "in",
            Binary_Operator.ARRAY_CONTAINS  : "in",
            Binary_Operator.PLUS            : "+",
            Binary_Operator.MINUS           : "-",
            Binary_Operator.TIMES           : "*",
            Binary_Operator.DIVIDE          : "/",
            Binary_Operator.REMAINDER       : "%",
            Binary_Operator.POWER           : "**",
        }
        string_functions = {
            Binary_Operator.STRING_STARTSWITH : "startswith",
            Binary_Operator.STRING_ENDSWITH   : "endswith",
            Binary_Operator.STRING_REGEX      : "matches",
        }

        if self.operator in infix_operators:
            return "%s %s %s" % (self.n_lhs.to_string(),
                                 infix_operators[self.operator],
                                 self.n_rhs.to_string())

        elif self.operator in string_functions:
            return "%s(%s, %s)" % (string_functions[self.operator],
                                   self.n_lhs.to_string(),
                                   self.n_rhs.to_string())

        elif self.operator == Binary_Operator.INDEX:
            return "%s[%s]" % (self.n_lhs.to_string(),
                               self.n_rhs.to_string())

        else:
            assert False

    def evaluate(self, mh, context):
        # lobster-trace: LRM.Null_Equivalence
        # lobster-trace: LRM.Null_Is_Invalid
        # lobster-trace: LRM.Signature_String_End_Functions
        # lobster-trace: LRM.Signature_Matches
        # lobster-trace: LRM.Startswith_Semantics
        # lobster-trace: LRM.Endswith_Semantics
        # lobster-trace: LRM.Matches_Semantics

        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        v_lhs = self.n_lhs.evaluate(mh, context)
        if v_lhs.value is None and \
           self.operator not in (Binary_Operator.COMP_EQ,
                                 Binary_Operator.COMP_NEQ):
            mh.error(v_lhs.location,
                     "lhs of check %s (%s) must not be null" %
                     (self.to_string(),
                      mh.cross_file_reference(self.location)))

        # Check for the short-circuit operators first
        if self.operator == Binary_Operator.LOGICAL_AND:
            assert isinstance(v_lhs.value, bool)
            if v_lhs.value:
                return self.n_rhs.evaluate(mh, context)
            else:
                return v_lhs

        elif self.operator == Binary_Operator.LOGICAL_OR:
            assert isinstance(v_lhs.value, bool)
            if v_lhs.value:
                return v_lhs
            else:
                return self.n_rhs.evaluate(mh, context)

        elif self.operator == Binary_Operator.LOGICAL_IMPLIES:
            assert isinstance(v_lhs.value, bool)
            if v_lhs.value:
                return self.n_rhs.evaluate(mh, context)
            else:
                return Value(location = self.location,
                             value    = True,
                             typ      = self.typ)

        # Otherwise, evaluate RHS and do the operation
        v_rhs = self.n_rhs.evaluate(mh, context)
        if v_rhs.value is None and \
           self.operator not in (Binary_Operator.COMP_EQ,
                                 Binary_Operator.COMP_NEQ):
            mh.error(v_rhs.location,
                     "rhs of check %s (%s) must not be null" %
                     (self.to_string(),
                      mh.cross_file_reference(self.location)))

        if self.operator == Binary_Operator.LOGICAL_XOR:
            assert isinstance(v_lhs.value, bool)
            assert isinstance(v_rhs.value, bool)
            return Value(location = self.location,
                         value    = v_lhs.value ^ v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.COMP_EQ:
            return Value(location = self.location,
                         value    = v_lhs.value == v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.COMP_NEQ:
            return Value(location = self.location,
                         value    = v_lhs.value != v_rhs.value,
                         typ      = self.typ)

        elif self.operator in (Binary_Operator.COMP_LT,
                               Binary_Operator.COMP_LEQ,
                               Binary_Operator.COMP_GT,
                               Binary_Operator.COMP_GEQ):
            return Value(
                location = self.location,
                value    = {
                    Binary_Operator.COMP_LT  : lambda lhs, rhs: lhs < rhs,
                    Binary_Operator.COMP_LEQ : lambda lhs, rhs: lhs <= rhs,
                    Binary_Operator.COMP_GT  : lambda lhs, rhs: lhs > rhs,
                    Binary_Operator.COMP_GEQ : lambda lhs, rhs: lhs >= rhs,
                }[self.operator](v_lhs.value, v_rhs.value),
                typ      = self.typ)

        elif self.operator == Binary_Operator.STRING_CONTAINS:
            assert isinstance(v_lhs.value, str)
            assert isinstance(v_rhs.value, str)

            return Value(location = self.location,
                         value    = v_lhs.value in v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.STRING_STARTSWITH:
            assert isinstance(v_lhs.value, str)
            assert isinstance(v_rhs.value, str)
            return Value(location = self.location,
                         value    = v_lhs.value.startswith(v_rhs.value),
                         typ      = self.typ)

        elif self.operator == Binary_Operator.STRING_ENDSWITH:
            assert isinstance(v_lhs.value, str)
            assert isinstance(v_rhs.value, str)
            return Value(location = self.location,
                         value    = v_lhs.value.endswith(v_rhs.value),
                         typ      = self.typ)

        elif self.operator == Binary_Operator.STRING_REGEX:
            assert isinstance(v_lhs.value, str)
            assert isinstance(v_rhs.value, str)
            return Value(location = self.location,
                         value    = re.match(v_rhs.value,
                                             v_lhs.value) is not None,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.ARRAY_CONTAINS:
            assert isinstance(v_rhs.value, list)

            return Value(location = self.location,
                         value    = v_lhs in v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.PLUS:
            assert isinstance(v_lhs.value, (int, str, Fraction))
            assert isinstance(v_rhs.value, (int, str, Fraction))
            return Value(location = self.location,
                         value    = v_lhs.value + v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.MINUS:
            assert isinstance(v_lhs.value, (int, Fraction))
            assert isinstance(v_rhs.value, (int, Fraction))
            return Value(location = self.location,
                         value    = v_lhs.value - v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.TIMES:
            assert isinstance(v_lhs.value, (int, Fraction))
            assert isinstance(v_rhs.value, (int, Fraction))
            return Value(location = self.location,
                         value    = v_lhs.value * v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.DIVIDE:
            assert isinstance(v_lhs.value, (int, Fraction))
            assert isinstance(v_rhs.value, (int, Fraction))

            if v_rhs.value == 0:
                mh.error(v_rhs.location,
                         "division by zero in %s (%s)" %
                         (self.to_string(),
                          mh.cross_file_reference(self.location)))

            if isinstance(v_lhs.value, int):
                return Value(location = self.location,
                             value    = v_lhs.value // v_rhs.value,
                             typ      = self.typ)
            else:
                return Value(location = self.location,
                             value    = v_lhs.value / v_rhs.value,
                             typ      = self.typ)

        elif self.operator == Binary_Operator.REMAINDER:
            assert isinstance(v_lhs.value, int)
            assert isinstance(v_rhs.value, int)

            if v_rhs.value == 0:
                mh.error(v_rhs.location,
                         "division by zero in %s (%s)" %
                         (self.to_string(),
                          mh.cross_file_reference(self.location)))

            return Value(location = self.location,
                         value    = math.remainder(v_lhs.value, v_rhs.value),
                         typ      = self.typ)

        elif self.operator == Binary_Operator.POWER:
            assert isinstance(v_lhs.value, (int, Fraction))
            assert isinstance(v_rhs.value, int)
            return Value(location = self.location,
                         value    = v_lhs.value ** v_rhs.value,
                         typ      = self.typ)

        elif self.operator == Binary_Operator.INDEX:
            assert isinstance(v_lhs.value, list)
            assert isinstance(v_rhs.value, int)

            if v_rhs.value < 0:
                mh.error(v_rhs.location,
                         "index cannot be less than zero in %s (%s)" %
                         (self.to_string(),
                          mh.cross_file_reference(self.location)))
            elif v_lhs.typ.upper_bound is not None and \
                 v_rhs.value > v_lhs.typ.upper_bound:
                mh.error(v_rhs.location,
                         "index cannot be more than %u in %s (%s)" %
                         (v_lhs.typ.upper_bound,
                          self.to_string(),
                          mh.cross_file_reference(self.location)))
            elif v_rhs.value > len(v_lhs.value):
                mh.error(v_lhs.location,
                         "array is not big enough in %s (%s)" %
                         (self.to_string(),
                          mh.cross_file_reference(self.location)))

            return Value(location = self.location,
                         value    = v_lhs.value[v_rhs.value].value,
                         typ      = self.typ)

        else:
            mh.ice_loc(self.location,
                       "unexpected binary operator %s" % self.operator)

    def can_be_null(self):
        return False


class Field_Access_Expression(Expression):
    """Tuple field access

    For example in::

      foo.bar
      ^1  ^2

    :attribute n_prefix: expression with tuple type (see 1)
    :type: Expression

    :attribute n_field: a tuple field to dereference (see 2)
    :type: Composite_Component

    """
    def __init__(self, mh, location, n_prefix, n_field):
        assert isinstance(mh, Message_Handler)
        assert isinstance(n_prefix, Expression)
        assert isinstance(n_field, Composite_Component)
        super().__init__(location, n_field.n_typ)
        self.n_prefix = n_prefix
        self.n_field  = n_field

        self.n_prefix.ensure_type(mh, self.n_field.member_of)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Field_Access ({self.n_field.name})")
        self.n_prefix.dump(indent + 1)

    def to_string(self):
        return self.n_prefix.to_string() + "." + self.n_field.name

    def evaluate(self, mh, context):
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        return self.n_prefix.evaluate(mh, context).value[self.n_field.name]

    def can_be_null(self):
        return False


class Range_Test(Expression):
    """Range membership test

    For example in::

      x in 1   ..   field+1
      ^lhs ^lower   ^^^^^^^upper

    Note that none of these are guaranteed to be literals or names;
    you can have arbitrarily complex expressions here.

    :attribute n_lhs: the expression to test
    :type: Expression

    :attribute n_lower: the lower bound
    :type: Expression

    :attribute n_upper: the upper bound
    :type: Expression

    """
    def __init__(self, mh, location, typ, n_lhs, n_lower, n_upper):
        # lobster-trace: LRM.Relation
        super().__init__(location, typ)
        assert isinstance(mh, Message_Handler)
        assert isinstance(n_lhs, Expression)
        assert isinstance(n_lower, Expression)
        assert isinstance(n_upper, Expression)
        self.n_lhs   = n_lhs
        self.n_lower = n_lower
        self.n_upper = n_upper

        self.n_lhs.ensure_type(mh, Builtin_Numeric_Type)
        self.n_lower.ensure_type(mh, self.n_lhs.typ)
        self.n_upper.ensure_type(mh, self.n_lhs.typ)

    def to_string(self):
        return "%s in %s .. %s" % (self.n_lhs.to_string(),
                                   self.n_lower.to_string(),
                                   self.n_upper.to_string())

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Range Test")
        self.write_indent(indent + 1, f"Type: {self.typ}")
        self.n_lhs.dump(indent + 1)
        self.n_lower.dump(indent + 1)
        self.n_upper.dump(indent + 1)

    def evaluate(self, mh, context):
        # lobster-trace: LRM.Null_Is_Invalid
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        v_lhs = self.n_lhs.evaluate(mh, context)
        if v_lhs.value is None:
            mh.error(v_lhs.location,
                     "lhs of range check %s (%s) see must not be null" %
                     (self.to_string(),
                      mh.cross_file_reference(self.location)))

        v_lower = self.n_lower.evaluate(mh, context)
        if v_lower.value is None:
            mh.error(v_lower.location,
                     "lower bound of range check %s (%s) must not be null" %
                     (self.to_string(),
                      mh.cross_file_reference(self.location)))

        v_upper = self.n_upper.evaluate(mh, context)
        if v_upper.value is None:
            mh.error(v_upper.location,
                     "upper bound of range check %s (%s) must not be null" %
                     (self.to_string(),
                      mh.cross_file_reference(self.location)))

        return Value(location = self.location,
                     value    = v_lower.value <= v_lhs.value <= v_upper.value,
                     typ      = self.typ)

    def can_be_null(self):
        return False


class OneOf_Expression(Expression):
    """OneOf expression

    For example in::

      oneof(a, b, c)
            ^^^^^^^ choices

    :attribute choices: a list of boolean expressions to test
    :type: list[Expression]
    """
    def __init__(self, mh, location, typ, choices):
        # lobster-trace: LRM.Signature_OneOf
        super().__init__(location, typ)
        assert isinstance(typ, Builtin_Boolean)
        assert isinstance(mh, Message_Handler)
        assert isinstance(choices, list)
        assert all(isinstance(item, Expression)
                   for item in choices)
        self.choices = choices

        for n_choice in choices:
            n_choice.ensure_type(mh, Builtin_Boolean)

    def to_string(self):
        return "oneof(%s)" % ", ".join(n_choice.to_string()
                                       for n_choice in self.choices)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "OneOf Test")
        self.write_indent(indent + 1, f"Type: {self.typ}")
        for n_choice in self.choices:
            n_choice.dump(indent + 1)

    def evaluate(self, mh, context):
        # lobster-trace: LRM.OneOf_Semantics
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        v_choices = [n_choice.evaluate(mh, context).value
                     for n_choice in self.choices]

        return Value(location = self.location,
                     value    = v_choices.count(True) == 1,
                     typ      = self.typ)

    def can_be_null(self):
        return False


class Action(Node):
    """An if or elseif part inside a conditional expression

    Each :class:`Conditional_Expression` is made up of a sequence of
    Actions. For example here is a single expression with two
    Actions::

      (if x == 0 then "zero" elsif x == 1 then "one" else "lots")
       ^^^^^^^^^^^^^^^^^^^^^ ^^^^^^^^^^^^^^^^^^^^^^^

    Note that the else part is not an action, it is an attribute of
    the :class:`Conditional_Expression` itself.

    :attribute kind: Either if or elseif
    :type: str

    :attribute n_cond: The boolean condition expression
    :type: Expression

    :attribute n_expr: The value if the condition evaluates to true
    :type: Expression

    """
    def __init__(self, mh, t_kind, n_condition, n_expression):
        # lobster-trace: LRM.Conditional_Expression
        assert isinstance(mh, Message_Handler)
        assert isinstance(t_kind, Token)
        assert t_kind.kind == "KEYWORD"
        assert t_kind.value in ("if", "elsif")
        assert isinstance(n_condition, Expression)
        assert isinstance(n_expression, Expression)
        super().__init__(t_kind.location)
        self.kind   = t_kind.value
        self.n_cond = n_condition
        self.n_expr = n_expression
        # lobster-trace: LRM.Conditional_Expression_Types
        self.n_cond.ensure_type(mh, Builtin_Boolean)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"{self.kind.capitalize()} Action")
        self.write_indent(indent + 1, "Condition")
        self.n_cond.dump(indent + 2)
        self.write_indent(indent + 1, "Value")
        self.n_expr.dump(indent + 2)

    def to_string(self):
        return "%s %s then %s" % (self.kind,
                                  self.n_cond.to_string(),
                                  self.n_expr.to_string())


class Conditional_Expression(Expression):
    """A conditional expression

    Each :class:`Conditional_Expression` is made up of a sequence of
    one or more :class:`Action`. For example here is a single
    expression with two Actions::

      (if x == 0 then "zero" elsif x == 1 then "one" else "lots")
       ^^^^^^^^^^^^^^^^^^^^^ ^^^^^^^^^^^^^^^^^^^^^^^      ^^^^^^

    The else expression is part of the conditional expression itself.

    A conditional expression will have at least one action (the if
    action), and all other actions will be elsif actions. The else
    expression is not optional and will always be present. The types
    of all actions and the else expression will match.

    :attribute actions: a list of Actions
    :type: list[Action]

    :attribute else_expr: the else expression
    :type: Expression

    """
    def __init__(self, location, if_action):
        # lobster-trace: LRM.Conditional_Expression
        assert isinstance(if_action, Action)
        assert if_action.kind == "if"
        super().__init__(location, if_action.n_expr.typ)
        self.actions   = [if_action]
        self.else_expr = None

    def add_elsif(self, mh, n_action):
        # lobster-trace: LRM.Conditional_Expression
        # lobster-trace; LRM.Conditional_Expression_Types
        assert isinstance(mh, Message_Handler)
        assert isinstance(n_action, Action)
        assert n_action.kind == "elsif"

        n_action.n_expr.ensure_type(mh, self.typ)
        self.actions.append(n_action)

    def set_else_part(self, mh, n_expr):
        # lobster-trace: LRM.Conditional_Expression
        # lobster-trace; LRM.Conditional_Expression_Types
        assert isinstance(mh, Message_Handler)
        assert isinstance(n_expr, Expression)

        n_expr.ensure_type(mh, self.typ)
        self.else_expr = n_expr

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Conditional expression")
        for action in self.actions:
            action.dump(indent + 1)
        self.write_indent(indent + 1, "Else")
        self.else_expr.dump(indent + 2)

    def to_string(self):
        rv = "(" + " ".join(action.to_string()
                            for action in self.actions)
        rv += " else %s" % self.else_expr.to_string()
        rv += ")"
        return rv

    def evaluate(self, mh, context):
        # lobster-trace: LRM.Conditional_Expression_Else
        # lobster-trace: LRM.Conditional_Expression_Evaluation
        # lobster-trace: LRM.Null_Is_Invalid
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        for action in self.actions:
            v_cond = action.n_cond.evaluate(mh, context)
            if v_cond.value is None:
                mh.error(v_cond.location,
                         "condition of %s (%s) must not be null" %
                         (action.to_string(),
                          mh.cross_file_reference(self.location)))
            if v_cond.value:
                return action.n_expr.evaluate(mh, context)

        return self.else_expr.evaluate(mh, context)

    def can_be_null(self):
        if self.else_expr and self.else_expr.can_be_null():
            return True

        return any(action.n_expr.can_be_null()
                   for action in self.actions)


class Quantified_Expression(Expression):
    """A quantified expression

    For example::

      (forall x in array_component => x > 0)
       ^4     ^1   ^2                 ^^^^^3

    A quantified expression introduces and binds a
    :class:`Quantified_Variable` (see 1) from a specified source (see
    2). When the body (see 3) is evaluated, the name of 1 is bound to
    each component of the source in turn.

    :attribute n_var: The quantified variable (see 1)
    :type: Quantified_Variable

    :attribute n_source: The array to iterate over (see 2)
    :type: Name_Reference

    :attribute n_expr: The body of the quantifier (see 3)
    :type: Expression

    :attribute universal: True means forall, false means exists (see 4)
    :type: Boolean

    """
    def __init__(self, mh, location,
                 typ,
                 universal,
                 n_variable,
                 n_source,
                 n_expr):
        # lobster-trace: LRM.Quantified_Expression
        # lobster-trace: LRM.Quantification_Type
        super().__init__(location, typ)
        assert isinstance(typ, Builtin_Boolean)
        assert isinstance(universal, bool)
        assert isinstance(n_variable, Quantified_Variable)
        assert isinstance(n_expr, Expression)
        assert isinstance(n_source, Name_Reference)
        self.universal = universal
        self.n_var     = n_variable
        self.n_expr    = n_expr
        self.n_source  = n_source
        self.n_expr.ensure_type(mh, Builtin_Boolean)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        if self.universal:
            self.write_indent(indent, "Universal quantified expression")
        else:
            self.write_indent(indent, "Existential quantified expression")
        self.n_var.dump(indent + 1)
        self.n_expr.dump(indent + 1)

    def to_string(self):
        return "(%s %s in %s => %s)" % ("forall"
                                        if self.universal
                                        else "exists",
                                        self.n_var.name,
                                        self.n_source.to_string(),
                                        self.n_expr.to_string())

    def evaluate(self, mh, context):
        # lobster-trace: LRM.Null_Is_Invalid
        # lobster-trace: LRM.Universal_Quantification_Semantics
        # lobster-trace: LRM.Existential_Quantification_Semantics
        assert isinstance(mh, Message_Handler)
        assert context is None or isinstance(context, dict)

        if context is None:
            new_ctx = {}
        else:
            new_ctx = copy(context)

        # This is going to be a bit tricky. We essentially eliminate
        # the quantifier and substitute; for the sake of making better
        # error messages.
        assert isinstance(self.n_source.entity, Composite_Component)
        array_values = context[self.n_source.entity.name]
        if isinstance(array_values, Implicit_Null):
            mh.error(array_values.location,
                     "%s in quantified expression %s (%s) "
                     "must not be null" %
                     (self.n_source.to_string(),
                      self.to_string(),
                      mh.cross_file_reference(self.location)))
        else:
            assert isinstance(array_values, Array_Aggregate)

        rv  = self.universal
        loc = self.location
        for binding in array_values.value:
            new_ctx[self.n_var.name] = binding
            result = self.n_expr.evaluate(mh, new_ctx)
            assert isinstance(result.value, bool)
            if self.universal and not result.value:
                rv  = False
                loc = binding.location
                break
            elif not self.universal and result.value:
                rv  = True
                loc = binding.location
                break

        return Value(location = loc,
                     value    = rv,
                     typ      = self.typ)

    def can_be_null(self):
        return False


##############################################################################
# AST Nodes (Entities)
##############################################################################

class Entity(Node, metaclass=ABCMeta):
    """Base class for all entities.

    An entity is a concrete object (with a name) for which we need to
    allocate memory. Examples of entities are types and record
    objects.

    :attribute name: unqualified name of the entity
    :type: str

    """
    def __init__(self, name, location):
        # lobster-trace: LRM.Described_Name_Equality
        super().__init__(location)
        assert isinstance(name, str)
        self.name = name


class Typed_Entity(Entity, metaclass=ABCMeta):
    """Base class for entities with a type.

    A typed entity is a concrete object (with a name and TRLC type)
    for which we need to allocate memory. Examples of typed entities
    are record objects and components.

    :attribute n_typ: type of the entity
    :type: Type

    """
    def __init__(self, name, location, n_typ):
        # lobster-exclude: Constructor only declares variables
        super().__init__(name, location)
        assert isinstance(n_typ, Type)
        self.n_typ = n_typ


class Quantified_Variable(Typed_Entity):
    """Variable used in quantified expression.

    A quantified expression declares and binds a variable, for which
    we need a named entity. For example in::

      (forall x in array => x > 1)
              ^

    We represent this first x as a :class:`Quantified_Variable`, the
    second x will be an ordinary :class:`Name_Reference`.

    :attribute typ: type of the variable (i.e. element type of the array)
    :type: Type

    """
    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Quantified Variable {self.name}")
        self.n_typ.dump(indent + 1)


class Type(Entity, metaclass=ABCMeta):
    """Abstract base class for all types.

    """
    def perform_type_checks(self, mh, value):
        assert isinstance(mh, Message_Handler)
        assert isinstance(value, Expression)
        return True

    def get_example_value(self):
        # lobster-exclude: utility method
        assert False


class Concrete_Type(Type, metaclass=ABCMeta):
    # lobster-trace: LRM.Type_Declarations
    """Abstract base class for all non-anonymous types.

    :attribute n_package: package where this type was declared
    :type: Package
    """
    def __init__(self, name, location, n_package):
        super().__init__(name, location)
        assert isinstance(n_package, Package)
        self.n_package = n_package

    def fully_qualified_name(self):
        """Return the FQN for this type (i.e. PACKAGE.NAME)

        :returns: the type's full name
        :rtype: str
        """
        return self.n_package.name + "." + self.name

    def __hash__(self):
        return hash((self.n_package.name, self.name))

    def __repr__(self):
        return "%s<%s>" % (self.__class__.__name__,
                           self.fully_qualified_name())


class Builtin_Type(Type, metaclass=ABCMeta):
    # lobster-trace: LRM.Builtin_Types
    """Abstract base class for all builtin types.

    """
    LOCATION = Location(file_name = "<builtin>")

    def __init__(self, name):
        super().__init__(name, Builtin_Type.LOCATION)

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, self.__class__.__name__)


class Builtin_Numeric_Type(Builtin_Type, metaclass=ABCMeta):
    # lobster-trace: LRM.Builtin_Types
    """Abstract base class for all builtin numeric types.

    """
    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, self.__class__.__name__)


class Builtin_Function(Entity):
    # lobster-trace: LRM.Builtin_Functions
    """Builtin functions.

    These are auto-generated by the :class:`~trlc.trlc.Source_Manager`.

    :attribute arity: number of parameters
    :type: int

    :attribute arity_at_least: when true, arity indicates a lower bound
    :type: bool

    """
    LOCATION = Location(file_name = "<builtin>")

    def __init__(self, name, arity, arity_at_least=False):
        super().__init__(name, Builtin_Function.LOCATION)
        assert isinstance(arity, int)
        assert isinstance(arity_at_least, bool)
        assert arity >= 0
        self.arity          = arity
        self.arity_at_least = arity_at_least

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, self.__class__.__name__ + " " + self.name)


class Array_Type(Type):
    """Anonymous array type.

    These are declared implicitly for each record component that has
    an array specifier::

      foo Integer [5 .. *]
                  ^

    :attribute lower_bound: minimum number of elements
    :type: int

    :attribute loc_lower: text location of the lower bound indicator
    :type: Location

    :attribute upper_bound: maximum number of elements (or None)
    :type: int

    :attribute loc_upper: text location of the upper bound indicator
    :type: Location

    :attribute element_type: type of the array elements
    :type: Type

    """
    def __init__(self,
                 location,
                 element_type,
                 loc_lower,
                 lower_bound,
                 loc_upper,
                 upper_bound):
        # lobster-exclude: Constructor only declares variables
        assert isinstance(element_type, Type) or element_type is None
        assert isinstance(lower_bound, int)
        assert lower_bound >= 0
        assert upper_bound is None or isinstance(upper_bound, int)
        assert upper_bound is None or upper_bound >= 0
        assert isinstance(loc_lower, Location)
        assert isinstance(loc_upper, Location)

        if element_type is None:
            name = "universal array"
        elif upper_bound is None:
            if lower_bound == 0:
                name = "array of %s" % element_type.name
            else:
                name = "array of at least %u %s" % (lower_bound,
                                                    element_type.name)
        elif lower_bound == upper_bound:
            name = "array of %u %s" % (lower_bound,
                                       element_type.name)
        else:
            name = "array of %u to %u %s" % (lower_bound,
                                             upper_bound,
                                             element_type.name)
        super().__init__(name, location)
        self.lower_bound  = lower_bound
        self.loc_lower    = loc_lower
        self.upper_bound  = upper_bound
        self.loc_upper    = loc_upper
        self.element_type = element_type

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, "Array_Type")
        self.write_indent(indent + 1, f"Lower bound: {self.lower_bound}")
        if self.upper_bound is None:
            self.write_indent(indent + 1, "Upper bound: *")
        else:
            self.write_indent(indent + 1, f"Upper bound: {self.upper_bound}")
        self.write_indent(indent + 1, f"Element type: {self.element_type.name}")

    def perform_type_checks(self, mh, value):
        assert isinstance(mh, Message_Handler)
        if isinstance(value, Array_Aggregate):
            return all(self.element_type.perform_type_checks(mh, v)
                       for v in value.value)
        else:
            assert isinstance(value, Implicit_Null)
            return True

    def get_example_value(self):
        # lobster-exclude: utility method
        return "[%s]" % self.element_type.get_example_value()


class Builtin_Integer(Builtin_Numeric_Type):
    # lobster-trace: LRM.Builtin_Types
    # lobster-trace: LRM.Integer_Values
    """Builtin integer type."""
    def __init__(self):
        super().__init__("Integer")

    def get_example_value(self):
        # lobster-exclude: utility method
        return "100"


class Builtin_Decimal(Builtin_Numeric_Type):
    # lobster-trace: LRM.Builtin_Types
    # lobster-trace: LRM.Decimal_Values
    """Builtin decimal type."""
    def __init__(self):
        super().__init__("Decimal")

    def get_example_value(self):
        # lobster-exclude: utility method
        return "3.14"


class Builtin_Boolean(Builtin_Type):
    # lobster-trace: LRM.Builtin_Types
    # lobster-trace: LRM.Boolean_Values
    """Builtin boolean type."""
    def __init__(self):
        super().__init__("Boolean")

    def get_example_value(self):
        # lobster-exclude: utility method
        return "true"


class Builtin_String(Builtin_Type):
    # lobster-trace: LRM.Builtin_Types
    # lobster-trace: LRM.String_Values
    """Builtin string type."""
    def __init__(self):
        super().__init__("String")

    def get_example_value(self):
        # lobster-exclude: utility method
        return "\"potato\""


class Builtin_Markup_String(Builtin_String):
    # lobster-trace: LRM.Builtin_Types
    # lobster-trace: LRM.Markup_String_Values
    """Builtin string type that allows checked references to TRLC
       objects.
    """
    def __init__(self):
        super().__init__()
        self.name = "Markup_String"

    def get_example_value(self):
        # lobster-exclude: utility method
        return "\"also see [[potato]]\""


class Package(Entity):
    """Packages.

    A package is declared when it is first encountered (in either a
    rsl or trlc file). A package contains all symbols declared in it,
    both types and record objects. A package is not associated with
    just a single file, it can be spread over multiple files.

    :attribute declared_late: indicates if this package is declared in a \
      trlc file
    :type: bool

    :attribute symbols: symbol table of the package
    :type: Symbol_Table

    """
    def __init__(self, name, location, builtin_stab, declared_late):
        # lobster-exclude: Constructor only declares variables
        super().__init__(name, location)
        assert isinstance(builtin_stab, Symbol_Table)
        assert isinstance(declared_late, bool)
        self.symbols = Symbol_Table()
        self.symbols.make_visible(builtin_stab)
        self.declared_late = declared_late

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Package {self.name}")
        self.write_indent(indent + 1, f"Declared_Late: {self.declared_late}")
        self.symbols.dump(indent + 1, omit_heading=True)

    def __repr__(self):
        return "%s<%s>" % (self.__class__.__name__,
                           self.name)


class Composite_Type(Concrete_Type, metaclass=ABCMeta):
    """Abstract base for record and tuple types, as they share some
       functionality.

    :attribute components: type components (including inherited if applicable)
    :type: Symbol_Table[Composite_Component]

    :attribute description: user-supplied description of the type or None
    :type: str

    :attribute checks: used-defined checks for this type (excluding \
      inherited checks)
    :type: list[Check]

    """
    def __init__(self,
                 name,
                 description,
                 location,
                 package,
                 inherited_symbols=None):
        # lobster-trace: LRM.Described_Name_Description
        super().__init__(name, location, package)
        assert isinstance(description, str) or description is None
        assert isinstance(inherited_symbols, Symbol_Table) or \
            inherited_symbols is None

        self.components  = Symbol_Table(inherited_symbols)
        self.description = description
        self.checks      = []

    def add_check(self, n_check):
        # lobster-trace: LRM.Check_Evaluation_Order
        assert isinstance(n_check, Check)
        self.checks.append(n_check)

    def iter_checks(self):
        # lobster-trace: LRM.Check_Evaluation_Order
        yield from self.checks

    def all_components(self):
        # lobster-exclude: Convenience function
        """Convenience function to get a list of all components.

        :rtype: list[Composite_Component]
        """
        return list(self.components.table.values())


class Composite_Component(Typed_Entity):
    """Component in a record or tuple.

    When declaring a composite type, for each component an entity is
    declared::

      type|tuple T {
         foo "blah" optional Boolean
         ^1  ^2     ^3       ^4

    :attribute description: optional text (see 2) for this component, or None
    :type: str

    :attribute member_of: a link back to the containing record or tuple; \
    for inherited fields this refers back to the original base record type
    :type: Composite_Type

    :attribute optional: indicates if the component can be null or not (see 3)
    :type: bool

    """

    def __init__(self,
                 name,
                 description,
                 location,
                 member_of,
                 n_typ,
                 optional):
        # lobster-trace: LRM.Described_Name_Description
        super().__init__(name, location, n_typ)
        assert isinstance(description, str) or description is None
        assert isinstance(member_of, Composite_Type)
        assert isinstance(optional, bool)
        self.description = description
        self.member_of   = member_of
        self.optional    = optional

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Composite_Component {self.name}")
        if self.description:
            self.write_indent(indent + 1, f"Description: {self.description}")
        self.write_indent(indent + 1, f"Optional: {self.optional}")
        self.write_indent(indent + 1, f"Type: {self.n_typ.name}")

    def __repr__(self):
        return "%s<%s>" % (self.__class__.__name__,
                           self.member_of.fully_qualified_name() + "." +
                           self.name)


class Record_Type(Composite_Type):
    """A user-defined record type.

    In this example::

      type T  "optional description of T" extends Root_T {
           ^1 ^2                                  ^3

    Note that (1) is part of the :class:`Entity` base, and (2) is part
    of the :class:`Composite_Type` base.

    :attribute parent: root type or None, indicated by (3) above
    :type: Record_Type

    :attribute frozen: mapping of frozen components
    :type: dict[str, Expression]

    :attribute is_final: type is final (i.e. no new components may be declared)
    :type: bool

    :attribute is_abstract: type is abstract
    :type: bool

    """
    def __init__(self,
                 name,
                 description,
                 location,
                 package,
                 n_parent,
                 is_abstract):
        # lobster-exclude: Constructor only declares variables
        assert isinstance(n_parent, Record_Type) or n_parent is None
        assert isinstance(is_abstract, bool)
        super().__init__(name,
                         description,
                         location,
                         package,
                         n_parent.components if n_parent else None)
        self.parent      = n_parent
        self.frozen      = {}
        self.is_final    = (n_parent.is_final if n_parent else False)
        self.is_abstract = is_abstract

    def iter_checks(self):
        # lobster-trace: LRM.Check_Evaluation_Order
        # lobster-trace: LRM.Check_Evaluation_Order_For_Extensions
        if self.parent:
            yield from self.parent.iter_checks()
        yield from self.checks

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Record_Type {self.name}")
        if self.description:
            self.write_indent(indent + 1, f"Description: {self.description}")
        if self.parent:
            self.write_indent(indent + 1, f"Parent: {self.parent.name}")
        self.components.dump(indent + 1, omit_heading=True)
        if self.checks:
            self.write_indent(indent + 1, "Checks")
            for n_check in self.checks:
                n_check.dump(indent + 2)
        else:
            self.write_indent(indent + 1, "Checks: None")

    def all_components(self):
        """Convenience function to get a list of all components.

        :rtype: list[Composite_Component]
        """
        if self.parent:
            return self.parent.all_components() + \
                list(self.components.table.values())
        else:
            return list(self.components.table.values())

    def is_subclass_of(self, record_type):
        """ Checks if this record type is or inherits from the given type

        :param record_type: check if are or extend this type
        :type record_type: Record_Type

        :returns: true if we are or extend the given type
        :rtype: Boolean
        """
        assert isinstance(record_type, Record_Type)

        ptr = self
        while ptr:
            if ptr is record_type:
                return True
            else:
                ptr = ptr.parent
        return False

    def is_frozen(self, n_component):
        """Test if the given component is frozen.

        :param n_component: a composite component of this record type \
          (or any of its parents)
        :type n_component: Composite_Component

        :rtype: bool
        """
        assert isinstance(n_component, Composite_Component)
        if n_component.name in self.frozen:
            return True
        elif self.parent:
            return self.parent.is_frozen(n_component)
        else:
            return False

    def get_freezing_expression(self, n_component):
        """Retrieve the frozen value for a frozen component

        It is an internal compiler error to call this method with a
        component that his not frozen.

        :param n_component: a frozen component of this record type \
          (or any of its parents)
        :type n_component: Composite_Component

        :rtype: Expression

        """
        assert isinstance(n_component, Composite_Component)
        if n_component.name in self.frozen:
            return self.frozen[n_component.name]
        elif self.parent:
            return self.parent.get_freezing_expression(n_component)
        else:
            assert False

    def get_example_value(self):
        # lobster-exclude: utility method
        return "%s_instance" % self.name


class Tuple_Type(Composite_Type):
    """A user-defined tuple type.

    In this example::

      tuple T  "optional description of T" {
            ^1 ^2

    Note that (1) is part of the :class:`Entity` base, and (2) is part
    of the :class:`Composite_Type` base.

    :attribute separators: list of syntactic separators.
    :type: list[Separator]

    Note the list of separators will either be empty, or there will be
    precisely one less separator than components.

    """
    def __init__(self, name, description, location, package):
        # lobster-trace: LRM.Tuple_Declaration
        super().__init__(name,
                         description,
                         location,
                         package)
        self.separators = []

    def add_separator(self, n_separator):
        # lobster-exclude: utility method
        assert isinstance(n_separator, Separator)
        assert len(self.separators) + 1 == len(self.components.table)
        self.separators.append(n_separator)

    def iter_separators(self):
        """Iterate over all separators"""
        # lobster-exclude: utility method
        yield from self.separators

    def iter_sequence(self):
        """Iterate over all components and separators in syntactic order"""
        # lobster-exclude: utility method
        if self.separators:
            for i, n_component in enumerate(self.components.table.values()):
                yield n_component
                if i < len(self.separators):
                    yield self.separators[i]
        else:
            yield from self.components.table.values()

    def has_separators(self):
        """Returns true if a tuple type requires separators"""
        # lobster-exclude: utility method
        return bool(self.separators)

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Tuple_Type {self.name}")
        if self.description:
            self.write_indent(indent + 1, f"Description: {self.description}")
        self.write_indent(indent + 1, "Fields")
        for n_item in self.iter_sequence():
            n_item.dump(indent + 2)
        if self.checks:
            self.write_indent(indent + 1, "Checks")
            for n_check in self.checks:
                n_check.dump(indent + 2)
        else:
            self.write_indent(indent + 1, "Checks: None")

    def perform_type_checks(self, mh, value):
        # lobster-trace: LRM.Check_Evaluation_Order
        assert isinstance(mh, Message_Handler)
        if isinstance(value, Tuple_Aggregate):
            ok = True
            for check in self.iter_checks():
                if not check.perform(mh, value):
                    ok = False
            return ok
        else:
            assert isinstance(value, Implicit_Null)
            return True

    def get_example_value(self):
        # lobster-exclude: utility method
        parts = []
        for n_item in self.iter_sequence():
            if isinstance(n_item, Composite_Component):
                parts.append(n_item.n_typ.get_example_value())
            else:
                parts.append(n_item.to_string())
        if self.has_separators():
            return " ".join(parts)
        else:
            return "(%s)" % ", ".join(parts)


class Separator(Node):
    # lobster-trace: LRM.Tuple_Declaration
    """User-defined syntactic separator

    For example::

      separator x
                ^1

    :attribute token: token used to separate fields of the tuple
    :type: Token
    """
    def __init__(self, token):
        super().__init__(token.location)
        assert isinstance(token, Token) and token.kind in ("IDENTIFIER",
                                                           "AT",
                                                           "COLON",
                                                           "SEMICOLON")
        self.token = token

    def to_string(self):
        return {
            "AT"        : "@",
            "COLON"     : ":",
            "SEMICOLON" : ";"
        }.get(self.token.kind, self.token.value)

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"Separator {self.token.value}")


class Enumeration_Type(Concrete_Type):
    """User-defined enumeration types.

    For example::

      enum T  "potato" {
           ^1 ^2

    :attribute description: user supplied optional description, or None
    :type: str

    :attribute literals: the literals in this enumeration
    :type: Symbol_Table[Enumeration_Literal_Spec]

    """
    def __init__(self, name, description, location, package):
        # lobster-trace: LRM.Described_Name_Description
        super().__init__(name, location, package)
        assert isinstance(description, str) or description is None
        self.literals    = Symbol_Table()
        self.description = description

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Enumeration_Type {self.name}")
        if self.description:
            self.write_indent(indent + 1, f"Description: {self.description}")
        self.literals.dump(indent + 1, omit_heading=True)

    def get_example_value(self):
        # lobster-exclude: utility method
        options = list(self.literals.values())
        if options:
            choice = len(options) // 2
            return self.name + "." + choice.name
        else:
            return "ERROR"


class Enumeration_Literal_Spec(Typed_Entity):
    """Declared literal in an enumeration declaration.

    Note that for literals mentioned later in record object
    declarations, we use :class:`Enumeration_Literal`. Literal specs
    are used here::

      enum ASIL {
         QM "not safety related"
         ^1 ^2

    :attribute description: the optional user-supplied description, or None
    :type: str

    """
    def __init__(self, name, description, location, enum):
        # lobster-trace: LRM.Described_Name_Description
        super().__init__(name, location, enum)
        assert isinstance(description, str) or description is None
        assert isinstance(enum, Enumeration_Type)
        self.description = description

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Enumeration_Literal_Spec {self.name}")
        if self.description:
            self.write_indent(indent + 1, f"Description: {self.description}")


class Record_Object(Typed_Entity):
    """A declared instance of a record type.

    This is going to be the bulk of all entities created by TRLC::

       section "Potato" {
               ^5
         Requirement PotatoReq {
         ^1          ^2
             component1 = 42
             ^3           ^4

    Note that the name (see 2) and type (see 1) of the object is
    provided by the name attribute of the :class:`Typed_Entity` base
    class.

    :attribute field: the specific values for all components (see 3 and 4)
    :type: dict[str, Expression]

    :attribute section: None or the section this record is contained in (see 5)
    :type: Section

    :attribute n_package: The package in which this record is declared in
    :type: Section

    The actual type of expressions in the field attribute are limited
    to:

    * :class:`Literal`
    * :class:`Unary_Expression`
    * :class:`Array_Aggregate`
    * :class:`Tuple_Aggregate`
    * :class:`Record_Reference`
    * :class:`Implicit_Null`

    """
    def __init__(self, name, location, n_typ, section, n_package):
        # lobster-trace: LRM.Section_Declaration
        # lobster-trace: LRM.Unspecified_Optional_Components
        # lobster-trace: LRM.Record_Object_Declaration

        assert isinstance(n_typ, Record_Type)
        assert isinstance(section, list) or section is None
        assert isinstance(n_package, Package)
        super().__init__(name, location, n_typ)
        self.field     = {
            comp.name: Implicit_Null(self, comp)
            for comp in self.n_typ.all_components()
        }
        self.section   = section
        self.n_package = n_package

    def fully_qualified_name(self):
        """Return the FQN for this type (i.e. PACKAGE.NAME)

        :returns: the object's full name
        :rtype: str
        """
        return self.n_package.name + "." + self.name

    def to_python_dict(self):
        """Return an evaluated and simplified object for Python.

        For example it might provide::

          {"foo" : [1, 2, 3],
           "bar" : None,
           "baz" : "value"}

        This is a function especially designed for the Python API. The
        name of the object itself is not in this returned dictionary.

        """
        return {name: value.to_python_object()
                for name, value in self.field.items()}

    def is_component_implicit_null(self, component) -> bool:
        return not isinstance(self.field[component.name], Implicit_Null)

    def assign(self, component, value):
        assert isinstance(component, Composite_Component)
        assert isinstance(value, (Literal,
                                  Array_Aggregate,
                                  Tuple_Aggregate,
                                  Record_Reference,
                                  Implicit_Null,
                                  Unary_Expression)), \
                "value is %s" % value.__class__.__name__
        if self.is_component_implicit_null(component):
            raise KeyError(f"Component {component.name} already \
                           assigned to {self.n_typ.name} {self.name}!")
        self.field[component.name] = value

    def dump(self, indent=0):  # pragma: no cover
        # lobster-exclude: Debugging feature
        self.write_indent(indent, f"Record_Object {self.name}")
        self.write_indent(indent + 1, f"Type: {self.n_typ.name}")
        for key, value in self.field.items():
            self.write_indent(indent + 1, f"Field {key}")
            value.dump(indent + 2)
        if self.section:
            self.section[-1].dump(indent + 1)

    def resolve_references(self, mh):
        assert isinstance(mh, Message_Handler)
        for val in self.field.values():
            val.resolve_references(mh)

    def perform_checks(self, mh):
        # lobster-trace: LRM.Check_Evaluation_Order
        # lobster-trace: LRM.Evaluation_Of_Checks
        assert isinstance(mh, Message_Handler)

        ok = True

        # First evaluate all tuple checks
        for n_comp in self.n_typ.all_components():
            if not n_comp.n_typ.perform_type_checks(mh,
                                                    self.field[n_comp.name]):
                ok = False

        # Then evaluate all record checks
        for check in self.n_typ.iter_checks():
            # Prints messages, if applicable. Raises exception on
            # fatal checks, which causes this to abort.
            if not check.perform(mh, self):
                ok = False

        return ok

    def __repr__(self):
        return "%s<%s>" % (self.__class__.__name__,
                           self.n_package.name + "." +
                           self.n_typ.name + "." +
                           self.name)


class Section(Entity):
    # lobster-trace: LRM.Section_Declaration
    """A section for readability

    This represents a section construct in TRLC files to group record
    objects together::

      section "Foo" {
              ^^^^^ parent section
         section "Bar" {
                 ^^^^^ section

    :attribute parent: the parent section or None
    :type: Section

    """
    def __init__(self, name, location, parent):
        super().__init__(name, location)
        assert isinstance(parent, Section) or parent is None
        self.parent = parent

    def dump(self, indent=0):  # pragma: no cover
        self.write_indent(indent, f"Section {self.name}")
        if self.parent is None:
            self.write_indent(indent + 1, "Parent: None")
        else:
            self.write_indent(indent + 1, f"Parent: {self.parent.name}")


##############################################################################
# Symbol Table & Scopes
##############################################################################

class Symbol_Table:
    """ Symbol table mapping names to entities
    """
    def __init__(self, parent=None):
        # lobster-exclude: Constructor only declares variables
        assert isinstance(parent, Symbol_Table) or parent is None
        self.parent   = parent
        self.imported = []
        self.table    = OrderedDict()
        self.trlc_files = []
        self.section_names = []

    @staticmethod
    def simplified_name(name):
        # lobster-trace: LRM.Sufficiently_Distinct
        assert isinstance(name, str)
        return name.lower().replace("_", "")

    def all_names(self):
        # lobster-exclude: API for users
        """ All names in the symbol table

        :rtype: set[str]
        """
        rv = set(item.name for item in self.table.values())
        if self.parent:
            rv |= self.parent.all_names()
        return rv

    def iter_record_objects_by_section(self):
        """API for users

        Retriving information about the section hierarchy for record objects
        Inputs: folder with trlc files where trlc files have sections,
        sub sections and record objects
        Output: Information about sections and level of sections,
        record objects and levels of record object
        """
        for record_object in self.iter_record_objects():
            location = record_object.location.file_name
            if location not in self.trlc_files:
                self.trlc_files.append(location)
                yield location
            if record_object.section:
                object_level = len(record_object.section) - 1
                for level, section in enumerate(record_object.section):
                    if section not in self.section_names:
                        self.section_names.append(section)
                        yield section.name, level
                yield record_object, object_level
            else:
                object_level = 0
                yield record_object, object_level

    def iter_record_objects(self):
        # lobster-exclude: API for users
        """ Iterate over all record objects

        :rtype: iterable[Record_Object]
        """
        for item in self.table.values():
            if isinstance(item, Package):
                yield from item.symbols.iter_record_objects()

            elif isinstance(item, Record_Object):
                yield item

    def values(self, subtype=None):
        # lobster-exclude: API for users
        assert subtype is None or isinstance(subtype, type)
        if self.parent:
            yield from self.parent.values(subtype)
        for name in sorted(self.table):
            if subtype is None or isinstance(self.table[name], subtype):
                yield self.table[name]

    def make_visible(self, stab):
        assert isinstance(stab, Symbol_Table)
        self.imported.append(stab)

    def register(self, mh, entity):
        # lobster-trace: LRM.Duplicate_Types
        # lobster-trace: LRM.Unique_Enumeration_Literals
        # lobster-trace: LRM.Tuple_Unique_Field_Names
        # lobster-trace: LRM.Sufficiently_Distinct
        # lobster-trace: LRM.Unique_Object_Names

        assert isinstance(mh, Message_Handler)
        assert isinstance(entity, Entity)

        simple_name = self.simplified_name(entity.name)

        if self.contains_raw(simple_name):
            pdef = self.lookup_direct(mh, entity.name, entity.location,
                                      simplified=True)
            if pdef.name == entity.name:
                mh.error(entity.location,
                         "duplicate definition, previous definition at %s" %
                         mh.cross_file_reference(pdef.location))
            else:
                mh.error(entity.location,
                         "%s is too similar to %s, declared at %s" %
                         (entity.name,
                          pdef.name,
                          mh.cross_file_reference(pdef.location)))

        else:
            self.table[simple_name] = entity

    def __contains__(self, name):
        # lobster-trace: LRM.Described_Name_Equality
        return self.contains(name)

    def contains_raw(self, simple_name, precise_name=None):
        # lobster-trace: LRM.Described_Name_Equality
        # lobster-trace: LRM.Sufficiently_Distinct
        #
        # Internal function to test if the simplified name is in the
        # table.
        assert isinstance(simple_name, str)
        assert isinstance(precise_name, str) or precise_name is None

        if simple_name in self.table:
            # No need to continue searching since registering a
            # clashing name would have been stopped
            return precise_name is None or \
                self.table[simple_name].name == precise_name

        elif self.parent:
            return self.parent.contains_raw(simple_name, precise_name)

        for stab in self.imported:
            if stab.contains_raw(simple_name, precise_name):
                return True

        return False

    def contains(self, name):
        # lobster-trace: LRM.Described_Name_Equality
        """ Tests if the given name is in the table

        :param name: the name to test
        :type name: str

        :rtype: bool
        """
        assert isinstance(name, str)
        return self.contains_raw(self.simplified_name(name), name)

    def lookup_assuming(self, mh, name, required_subclass=None):
        # lobster-trace: LRM.Described_Name_Equality
        # lobster-trace: LRM.Sufficiently_Distinct
        """Retrieve an object from the table assuming its there

        This is intended for the API specifically where you want to
        e.g. find some used-defined types you know are there.

        :param mh: The message handler to use
        :type mh: Message_Handler

        :param name: The name to search for
        :type name: str

        :param required_subclass: If set, creates an error if the object \
        is not an instance of the given class
        :type required_subclass: type

        :raise TRLC_Error: if the object is not of the required subclass
        :returns: the specified entity (or None if it does not exist)
        :rtype: Entity

        """
        assert isinstance(mh, Message_Handler)
        assert isinstance(name, str)
        assert isinstance(required_subclass, type) or required_subclass is None

        simple_name = self.simplified_name(name)

        ptr = self
        for ptr in [self] + self.imported:
            while ptr:
                if simple_name in ptr.table:
                    rv = ptr.table[simple_name]
                    if rv.name != name:
                        return None

                    if required_subclass is not None and \
                       not isinstance(rv, required_subclass):
                        mh.error(rv.location,
                                 "%s %s is not a %s" %
                                 (rv.__class__.__name__,
                                  name,
                                  required_subclass.__name__))
                    return rv
                else:
                    ptr = ptr.parent

        return None

    def lookup_direct(self,
                      mh,
                      name,
                      error_location,
                      required_subclass=None,
                      simplified=False):
        # lobster-trace: LRM.Described_Name_Equality
        # lobster-trace: LRM.Sufficiently_Distinct
        # lobster-trace: LRM.Valid_Base_Names
        # lobster-trace: LRM.Valid_Access_Prefixes
        # lobster-trace: LRM.Valid_Function_Prefixes
        """Retrieve an object from the table

        For example::

          pkg = stab.lookup_direct(mh,
                                   "potato",
                                   Location("foobar.txt", 42),
                                   Package)

        This would search for an object named ``potato``. If it is
        found, and it is a package, it is returned. If it is not a
        Package, then the following error is issued::

          foobar.txt:42: error: Enumeration_Type potato is not a Package

        If it is not found at all, then the following error is issued::

          foobar.txt:42: error: unknown symbol potato

        :param mh: The message handler to use
        :type mh: Message_Handler

        :param name: The name to search for
        :type name: str

        :param error_location: Where to create the error if the name is \
        not found
        :type error_location: Location

        :param required_subclass: If set, creates an error if the object \
        is not an instance of the given class
        :type required_subclass: type

        :param simplified: If set, look up the given simplified name instead \
        of the actual name
        :type simplified: bool

        :raise TRLC_Error: if the name is not in the table
        :raise TRLC_Error: if the object is not of the required subclass
        :returns: the specified entity
        :rtype: Entity

        """
        assert isinstance(mh, Message_Handler)
        assert isinstance(name, str)
        assert isinstance(error_location, Location)
        assert isinstance(required_subclass, type) or required_subclass is None
        assert isinstance(simplified, bool)

        simple_name = self.simplified_name(name)
        ptr         = self
        options     = []

        for ptr in [self] + self.imported:
            while ptr:
                if simple_name in ptr.table:
                    rv = ptr.table[simple_name]
                    if not simplified and rv.name != name:
                        mh.error(error_location,
                                 "unknown symbol %s, did you mean %s?" %
                                 (name,
                                  rv.name))

                    if required_subclass is not None and \
                       not isinstance(rv, required_subclass):
                        mh.error(error_location,
                                 "%s %s is not a %s" %
                                 (rv.__class__.__name__,
                                  name,
                                  required_subclass.__name__))
                    return rv
                else:
                    options += list(item.name
                                    for item in ptr.table.values())
                    ptr      = ptr.parent

        matches = get_close_matches(
            word          = name,
            possibilities = options,
            n             = 1)

        if matches:
            mh.error(error_location,
                     "unknown symbol %s, did you mean %s?" %
                     (name,
                      matches[0]))
        else:
            mh.error(error_location,
                     "unknown symbol %s" % name)

    def lookup(self, mh, referencing_token, required_subclass=None):
        # lobster-trace: LRM.Described_Name_Equality
        assert isinstance(mh, Message_Handler)
        assert isinstance(referencing_token, Token)
        assert referencing_token.kind in ("IDENTIFIER", "BUILTIN")
        assert isinstance(required_subclass, type) or required_subclass is None

        return self.lookup_direct(
            mh                = mh,
            name              = referencing_token.value,
            error_location    = referencing_token.location,
            required_subclass = required_subclass)

    def write_indent(self, indent, message):  # pragma: no cover
        # lobster-exclude: Debugging feature
        assert isinstance(indent, int)
        assert indent >= 0
        assert isinstance(message, str)
        print(" " * (3 * indent) + message)

    def dump(self, indent=0, omit_heading=False):  # pragma: no cover
        # lobster-exclude: Debugging feature
        if omit_heading:
            new_indent = indent
        else:
            self.write_indent(indent, "Symbol_Table")
            new_indent = indent + 1
        ptr = self
        while ptr:
            for name in ptr.table:
                ptr.table[name].dump(new_indent)
            ptr = ptr.parent

    @classmethod
    def create_global_table(cls, mh):
        # lobster-trace: LRM.Builtin_Types
        # lobster-trace: LRM.Builtin_Functions
        # lobster-trace: LRM.Builtin_Type_Conversion_Functions
        # lobster-trace: LRM.Signature_Len
        # lobster-trace: LRM.Signature_String_End_Functions
        # lobster-trace: LRM.Signature_Matches

        stab = Symbol_Table()
        stab.register(mh, Builtin_Integer())
        stab.register(mh, Builtin_Decimal())
        stab.register(mh, Builtin_Boolean())
        stab.register(mh, Builtin_String())
        stab.register(mh, Builtin_Markup_String())
        stab.register(mh,
                      Builtin_Function("len", 1))
        stab.register(mh,
                      Builtin_Function("startswith", 2))
        stab.register(mh,
                      Builtin_Function("endswith", 2))
        stab.register(mh,
                      Builtin_Function("matches", 2))
        stab.register(mh,
                      Builtin_Function("oneof", 1, arity_at_least=True))

        return stab


class Scope:
    def __init__(self):
        # lobster-exclude: Constructor only declares variables
        self.scope = []

    def push(self, stab):
        assert isinstance(stab, Symbol_Table)
        self.scope.append(stab)

    def pop(self):
        self.scope.pop()

    def contains(self, name):
        assert isinstance(name, str)

        for stab in reversed(self.scope):
            if stab.contains(name):
                return True
        return False

    def lookup(self, mh, referencing_token, required_subclass=None):
        assert len(self.scope) >= 1
        assert isinstance(mh, Message_Handler)
        assert isinstance(referencing_token, Token)
        assert referencing_token.kind in ("IDENTIFIER", "BUILTIN")
        assert isinstance(required_subclass, type) or required_subclass is None

        for stab in reversed(self.scope[1:]):
            if stab.contains(referencing_token.value):
                return stab.lookup(mh, referencing_token, required_subclass)
        return self.scope[0].lookup(mh, referencing_token, required_subclass)

    def size(self):
        return len(self.scope)
