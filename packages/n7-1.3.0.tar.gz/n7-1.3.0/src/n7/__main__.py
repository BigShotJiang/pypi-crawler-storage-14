"""N7 CLI pour les projets N7"""

import typer
from rich.console import Console

from n7 import __version__
from n7.commands import (
    docker_test_application,
    down_command,
    local_test_application,
    logs_command,
    up_command, connect_shell_command,
)

# init Typer
app = typer.Typer(
    name="n7",
    help="CLI global pour les projets N7",
    add_completion=True,
    rich_markup_mode="rich",
    context_settings={"help_option_names": ["-h", "--help"]},
    pretty_exceptions_show_locals=False,
    pretty_exceptions_short=True,
)

console = Console()

# Group docker compose
dkc_app = typer.Typer(help="Commandes Docker Compose")
dkc_app.add_typer(docker_test_application, name="t", help="Tests pytest in container")
dkc_app.add_typer(up_command, name="up", help="Start container")
dkc_app.add_typer(down_command, name="down", help="Stop and delete container")
dkc_app.add_typer(logs_command, name="l", help="Logs a container")
dkc_app.add_typer(connect_shell_command, name="sh", help="Start shell in container")

app.add_typer(dkc_app, name="dkc", help="Commandes Docker Compose")

# Group local
app.add_typer(local_test_application, name="t", help="Tests pytest local")

#
# HELP => display help
#

version_option = typer.Option(
    False,
    "--version",
    "-v",
    help="Show version CLI n7",
)

debug_option = typer.Option(
    False,
    "--debug",
    help="Mode debug with traceback completed",
)


@app.callback(invoke_without_command=True)
def main_callback(version: bool = version_option, debug: bool = debug_option):
    """Callback principal pour gérer les options globales."""
    if debug:
        app.pretty_exceptions_show_locals = True
        app.pretty_exceptions_short = False

    if version:
        console.print(f"version [blue]{__version__}[/blue]")
        raise typer.Exit()


if __name__ == "__main__":
    app()
