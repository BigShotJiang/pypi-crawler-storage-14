"""Commandes du CLI N7"""
from n7.commands.docker.container.connect_shell_command import connect_shell_command
from n7.commands.docker.container.down_command import down_command
from n7.commands.docker.container.logs_command import logs_command
from n7.commands.docker.container.up_command import up_command
from n7.commands.docker.test.docker_test_command import docker_test_application
from n7.commands.local.test.local_test_command import local_test_application

__all__ = [
    "local_test_application",
    "docker_test_application",
    "up_command",
    "down_command",
    "logs_command",
    "connect_shell_command"
]
