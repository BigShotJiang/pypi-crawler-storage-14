# ruff: noqa: F401

from odoo.addons.edi_core_oca.tests.fale_models import EdiExchangeConsumerTest
