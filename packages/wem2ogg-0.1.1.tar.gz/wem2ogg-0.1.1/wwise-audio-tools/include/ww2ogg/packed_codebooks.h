#ifndef WW2OGG_PACKED_CODEBOOKS_H
#define WW2OGG_PACKED_CODEBOOKS_H

namespace ww2ogg {
extern unsigned char packed_codebooks_bin[];
extern unsigned int packed_codebooks_bin_len;
} // namespace ww2ogg

#endif // WW2OGG_PACKED_CODEBOOKS_H