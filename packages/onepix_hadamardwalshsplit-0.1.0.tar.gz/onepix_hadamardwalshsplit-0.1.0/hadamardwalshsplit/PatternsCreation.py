import numpy as np
from hadamardwalshsplit.custom_walsh_hadamard import *
import cv2
from fis_common_function import FIS_common_acquisition as FIS


class CreationPatterns:
    """Class HadamardPatterns allows to create a sequence of
    Hadamard split patterns and their order list.
    """

    def __init__(self, height=0, width=0):

        self.acquisition_results={}        # import users defined spatial infos
        self.fis=FIS.FisCommonAcquisition()
        self.config_path=self.fis.config_path
        self.spatial_res =self.fis.spatial_res

        self.dim = 2 ** (round(np.log2(self.spatial_res)))
        self.nb_patterns = 2 * self.dim**2
        self.sequence = []
        self.pattern_order = []
        self.white_pattern_idx = 0
        self.interp_method = cv2.INTER_AREA
        if self.dim != self.spatial_res:
            print(
                f"Warning: Hadamard sampling request for powers of 2 dimensions. The nearest eligible size is {self.dim}. "
            )

    def sequence_order(self):
        """
        This function creates the sequence order list associated to the frequencies displayed

        Returns
        -------
        pattern_order : list of str
            list of name of Hadamard split patterns stored in sequence.
        freqs : list of tuples
            list of tuples of 2D spatial frequencies sampled.

        """
        patterns_order = []
        freqs = []

        for j in range(self.dim):  # column broom
            for k in range(self.dim):  # line broom
                patterns_order.append("Hpos(%d,%d)" % (j, k))
                patterns_order.append("Hneg(%d,%d)" % (j, k))
        freqs.append((j, k))
        self.acquisition_results["patterns_order"]=patterns_order
        return patterns_order, freqs

    def creation_patterns(self):
        """
        Function for the creation of Hadamard patterns with the splitting method


        Returns
        -------
        split_patterns : array of int
            3D array of split Hadamard patterns.

        """
        

        had_walsh_matrix = walsh2_matrix(self.dim).astype(np.int16)
          # initialized an dim by dim Walsh Hadamard matrix
        self.sequence = []
        for col in range(self.dim**2):
            self.sequence.append(
                np.uint8(
                    255
                    * (
                        (
                            1
                            + (
                                np.reshape(
                                    had_walsh_matrix[:, col], [self.dim, self.dim]
                                )
                            )
                        )
                        // 2
                    )
                )
            )  # reshape of the Patterns in 2D(dim X dim)
            self.sequence.append(
                np.uint8(
                    255
                    * (
                        (
                            1
                            - (
                                np.reshape(
                                    had_walsh_matrix[:, col], [self.dim, self.dim]
                                )
                            )
                        )
                        // 2
                    )
                )
            )
        del had_walsh_matrix

        self.patterns_order, freqs = self.sequence_order()
        self.acquisition_results["patterns"]=self.sequence
        return self.sequence

    def save_raw_data(self, acquisition_class, path=None):
        saver = FIS.FisCommonAcquisition(acquisition_class)
        saver.save_raw_data(path=None)
