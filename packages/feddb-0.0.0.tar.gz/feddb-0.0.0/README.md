# FedDB (Federated Database)

FedDB is a privacy-preserving federated data collaboration platform that enables multiple parties to perform joint data queries and analysis without revealing raw data. Built by SecretFlow Team, it uses advanced cryptographic technologies to ensure data privacy while providing familiar database interfaces.

## Notice

This package is currently under development. Please stay tuned for updates.