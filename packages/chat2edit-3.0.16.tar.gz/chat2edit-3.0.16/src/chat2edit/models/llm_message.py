from chat2edit.models.message import Message


class LlmMessage(Message):
    pass
