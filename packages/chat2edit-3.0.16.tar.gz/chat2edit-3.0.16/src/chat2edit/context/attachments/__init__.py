from chat2edit.context.attachments.attachment import Attachment

__all__ = ["Attachment"]
