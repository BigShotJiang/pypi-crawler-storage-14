def add(a,b):
    """This will return addition of two numbers"""
    return a+b

def subtract(a,b):
    """this will return the substraction of two numbers"""
    return a-b

def multiply(a,b):
    return a*b

def divide(a,b):
    if b == 0:
        raise ValueError("cant divide by zero")
    return a/b

def power(a,b):
    """this is calculating the power of numbers"""
    return a**b
