# Euroncalcu

A Simple calculator package for python.

## Installation

pip install euroncalcu