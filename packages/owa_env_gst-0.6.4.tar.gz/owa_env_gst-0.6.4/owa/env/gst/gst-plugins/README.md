This folder contains plugins for `gstreamer`.

To see example of gstreamer plugin, check following links:
- https://gitlab.freedesktop.org/gstreamer/gstreamer/-/tree/main/subprojects/gst-python/examples/plugins
