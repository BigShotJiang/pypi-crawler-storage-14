from .best_practice_rule import BestPracticeRule
from ..PyDAXLexer import PyDAXLexer
from antlr4 import Token
from ..DAXToken import DAXToken

rule_metadata = {
    "ID": "UNUSED_VARIABLES",
    "Name": "[DAX Expressions] Remove unused variables",
    "Category": "DAX Expressions",
    "Description": "A variable is defined but never used in the DAX expression",
    "Severity": 2,
    "short_name": "Remove unused variables"
}


class UnusedVariables(BestPracticeRule):
    def __init__(self) -> None:
        super().__init__(
            id=rule_metadata["ID"],
            name=rule_metadata["Name"],
            description=rule_metadata["Description"],
            severity=str(rule_metadata["Severity"]),
            category=rule_metadata["Category"],
            short_name=rule_metadata["short_name"]
        )

    def verify_violation(self, lexer: "PyDAXLexer") -> None:
        self.clear_violations()
        lexer.reset()

        tokens: list[Token] = []
        t: Token = lexer.nextToken()
        while t.type != Token.EOF:
            if t.channel == Token.DEFAULT_CHANNEL or t.type == PyDAXLexer.VAR:
                tokens.append(t)
            t = lexer.nextToken()

        IDENT_LIKE = {
            PyDAXLexer.TABLE_OR_VARIABLE,
        }

        var_defs: dict[str, Token] = {}
        n = len(tokens)
        i = 0
        while i < n:
            tok = tokens[i]
            if tok.type == PyDAXLexer.VAR:
                j = i + 1
                if j < n and tokens[j].type in IDENT_LIKE:
                    name_l = tokens[j].text.lower()
                    var_defs[name_l] = tokens[j]
                    i = j
            i += 1

        if not var_defs:
            self.verified = True
            return

        used: set[str] = set()
        for idx, tok in enumerate(tokens):
            if tok.type in IDENT_LIKE:
                name_l = tok.text.lower()
                if name_l in var_defs and tok is not var_defs[name_l]:
                    used.add(name_l)

        for name_l, def_tok in var_defs.items():
            if name_l not in used:
                self.violators_tokens.append(DAXToken(def_tok))
                self.highlight_tokens.append(DAXToken(def_tok))

        self.verified = True
