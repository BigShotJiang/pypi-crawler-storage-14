from .identifier import VersionDescriptor

__all__ = ["VersionDescriptor"]
