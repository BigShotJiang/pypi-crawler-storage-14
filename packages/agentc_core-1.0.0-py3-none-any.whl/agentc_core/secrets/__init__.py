from .secrets import get_secret
from .secrets import put_secret

__all__ = ["get_secret", "put_secret"]
