"""
supplyforge
-----------

A Python package for generating country-level electricity supply datasets for power system analysis.

This package provides a reproducible Snakemake workflow to build a consistent and transparent
data foundation describing the generation infrastructure and resources of European electricity systems.
It integrates data primarily from ENTSO-E to create validated, ready-to-use datasets for
scenario analysis and planning models.

For more information, please visit the [GitLab repository](https://git.persee.minesparis.psl.eu/energy-alternatives/supplyforge).
"""

__version__ = "0.1.0"

from pathlib import Path
import pandas as pd
from dotenv import load_dotenv
load_dotenv()



ROOT_DIR = Path(__file__).parent.parent
RESULTS_DIR = ROOT_DIR / "results"

pd.set_option('future.no_silent_downcasting', True)