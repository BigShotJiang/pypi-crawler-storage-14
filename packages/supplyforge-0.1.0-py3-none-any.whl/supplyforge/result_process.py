import polars as pl
import pandas as pd
import matplotlib.pyplot as plt
from pommes_craft.components import *


gen_palette = {
    'Nuclear': '#A0A0A0',
    'RoR_Pondage': '#1E90FF',
    'Solar': '#FDB813',
    'Wind_Onshore': '#66B2FF',
    'Wind_Offshore': '#0077BE',
    'lake_hydro_plant': '#0000CD',
    'Pumped_Hydro_Discharging': '#9370DB',
    'Battery_Discharging': '#9B59B6',
    'Coal': '#4B4B4B',
    'Gas': '#E97451',
    'Oil': '#8B4513',
    'Biomass': '#2E8B57',
    'Waste': '#6B8E23',
    'Other': '#CCCCCC',
    'Imports': '#15616d',
    "Load_Shedding": '#d90429'
}
dem_palette = {
    'Demand': '#2a9d8f',
    'Pumped_Hydro_Charging': '#CBA0F5',
    'Battery_Charging': '#D7BDE2',
    'Exports': '#F08080',
    "Flexible_Demand": "#0f4c5c"
}

def extract_power_results(energy_model, country_code):

    area_fr = energy_model.areas[country_code]
    # retrieving power produced by generators
    powers = (
        energy_model.get_results("operation", "power", [ConversionTechnology])
        .pivot(on='name', values='value')
        .drop(['area', 'year_op', 'hour', "lake_hydro_inflow"])
        .to_pandas()
        .set_index('datetime')
    )

    # retrieving power stored and released in pumped hydro storages
    hydro_storage_power_in = area_fr.components['pumped_hydro_storage'].results['operation']['power_in']
    hydro_storage_power_out = area_fr.components['pumped_hydro_storage'].results['operation']['power_out']

    # retrieving imported and exported powers
    interco_powers = energy_model.get_results("operation", "power", [TransportTechnology])
    imports_to_fr = (
        interco_powers.filter(pl.col('link').str.ends_with(country_code))
        .group_by(pl.col('datetime'), maintain_order=True)
        .agg(pl.col('value').sum())
    )
    exports_from_fr = (
        interco_powers.filter(pl.col('link').str.ends_with(country_code) == False)
        .group_by(pl.col('datetime'), maintain_order=True)
        .agg(pl.col('value').sum())
    )
    demand = area_fr.components['electricity_demand'].demand['demand'].to_numpy()
    load_shedding = (
        area_fr
        .components['electricity_load_shedding']
        .results['operation']['power']['value'].to_numpy()
    )

    powers['Pumped_Hydro_Discharging'] = hydro_storage_power_out['value'].to_numpy()
    powers['Pumped_Hydro_Charging'] = hydro_storage_power_in['value'].to_numpy()
    powers['Imports'] = imports_to_fr['value'].to_numpy()
    powers['Exports'] = exports_from_fr['value'].to_numpy()
    powers['Demand'] = demand
    powers['Load_Shedding'] = load_shedding

    if "Battery_Storage" in area_fr.components.keys():
        # retrieving power stored and released in batteries
        battery_power_in = area_fr.components['Battery_Storage'].results['operation']['power_in']
        battery_power_out = area_fr.components['Battery_Storage'].results['operation']['power_out']
        powers['Battery_Charging'] = battery_power_in['value'].to_numpy()
        powers['Battery_Discharging'] = battery_power_out['value'].to_numpy()
    else:
        powers['Battery_Charging'] = 0.
        powers['Battery_Discharging'] = 0.



    flex = energy_model.get_results('operation', 'demand', [FlexibleDemand])

    if flex.is_empty():
        powers['Flexible_Demand'] = 0.
    else:
        powers['Flexible_Demand'] = flex['value'].to_numpy()

    return powers

def plot_power_balance(power_df, resample_step="1h", week=None, day=None, max_y=None):


    fig, ax = plt.subplots(1, 2,figsize=(15, 6))

    if week is not None:
        plot_mask = power_df.index.isocalendar().week == week
    elif day is not None:
        plot_mask = power_df.index.day_of_year == day
    else:
        plot_mask = power_df.index

    powers_to_p = power_df.loc[plot_mask].resample(resample_step).mean()

    gen_cols = list(gen_palette.keys())
    powers_to_p[gen_cols].plot.area(ax=ax[0], color=gen_palette, linewidth=0)

    dem_cols = list(dem_palette.keys())
    powers_to_p[dem_cols].plot.area(ax=ax[1], color=dem_palette, linewidth=0)
    ax[0].legend(
        loc='upper center',
        bbox_to_anchor=(0.5, -0.15),
        ncol=3,
        frameon=False,
        fontsize=9
    )
    ax[1].legend(
        loc='upper center',
        bbox_to_anchor=(0.5, -0.15),
        ncol=3,
        frameon=False,
        fontsize=9
    )

    ax[0].set_ylabel('Power in MW')
    ax[0].set_xlabel('')
    ax[1].set_xlabel('')
    if max_y is not None:
        ax[0].set_ylim(0, max_y)
        ax[1].set_ylim(0, max_y)
    plt.show()

def get_summary_df(model_dict, country_code, cmap='Greys'):

    cols = list(gen_palette.keys()) + list(dem_palette.keys())
    index_colors = (
            {f'{k} in TWh': f"{v}80" for k,v in gen_palette.items()}
            | {f'{k} in TWh': f"{v}80" for k,v in dem_palette.items()}
            | {
                "Costs in B€": "#fca31180",
                'Peak Demand in GW': "#2a9d8f80",
                'Peak Load Shedding in GW': "#FF000080"
            }
    )
    dfs = []
    for name, energy_model in model_dict.items():
        powers_df = extract_power_results(energy_model, country_code)
        comp_df = powers_df[cols].sum().to_frame() * 1.e-6
        comp_df.columns = [name]
        comp_df.index = [f"{c} in TWh" for c in comp_df.index]
        peak_demand = powers_df[['Demand', "Flexible_Demand"]].sum(axis=1).max() * 1.e-3
        comp_df.loc['Peak Demand in GW', name] = peak_demand
        peak_load_shedding = powers_df["Load_Shedding"].max() * 1.e-3
        comp_df.loc['Peak Load Shedding in GW', name] = peak_load_shedding
        costs = energy_model.get_results('operation', "costs")['value'].sum() * 1.e-9
        comp_df.loc['Costs in B€', name] = costs
        dfs.append(comp_df)

    df = pd.concat(dfs, axis=1).round(2)

    separators = [f"{list(gen_palette)[-1]} in TWh",
                  f"{list(dem_palette)[-1]} in TWh",
                  'Peak Load Shedding in GW',
                  ]

    def bold_row_bottom_border(styler, indices_to_style):
        index_map = {label: i + 1 for i, label in enumerate(styler.data.index)}
        styles = []

        # Corrected Property Format: (property_name, property_value)
        property_tuple = ('border-bottom', '3px solid #14213d !important;')

        for index_label in indices_to_style:
            if index_label in index_map:
                row_number = index_map[index_label]

                # Selector targets ALL cells (*, i.e., both <th> and <td>)
                # within the Nth table row (tr:nth-child(N)).
                selector = f'tr:nth-child({row_number}) *'

                styles.append({
                    'selector': selector,
                    # Pass the property tuple inside a list
                    'props': [property_tuple]
                })

        return styles


    df_styled = (
        df.style.apply_index(
            lambda idx: [f"background-color: {index_colors.get(i, '')}" for i in idx],
            axis=0
        ).format(precision=2)
        .set_table_styles(
            bold_row_bottom_border(df.style, separators)
        )
    )

    if len(dfs) > 1:
        df_styled = df_styled.background_gradient(cmap=cmap, axis=1)

    return df, df_styled