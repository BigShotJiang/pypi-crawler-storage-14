"""Slack connector for review notifications."""
from .client import SlackConnector

__all__ = ["SlackConnector"]

