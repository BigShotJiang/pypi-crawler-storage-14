# Masgent
Masgent: Materials Simulation Agent

## Installation
1. Requirements:
   - Python >= 3.9, < 3.13
2. Install via pip:
```bash
pip install masgent
```

## Usage
1. After installation, run the following command to start the Masgent:
```bash
masgent
```
2. Optional preparation:
- For AI functionalities, obtain your OpenAI API key from [platform.openai.com](https://platform.openai.com/account/api-keys).
- For Materials Project access, obtain your API key from [materialsproject.org](https://next-gen.materialsproject.org/api).

## Features
- AI agent (Pydantic AI + OpenAI)
- Materials Project access
- Distributed as a Python package
- Robust system prompts to guide AI behavior
- Strict input validation (Pydantic schemas)
- API key management and validation
- Interactive command selection menu (Bullet)
- Color-coded terminal interface (Colorama)
- AI standby for instant assistance
- Smart memory management
- Detailed user guidance
- Spinner for AI response waiting time (Yaspin)
- Automated file handling and management

## Progress Record
1. Density Functional Theory (DFT) Simulations
  - 1.1 Structure Preparation & Manipulation
    - 1.1.1 Generate POSCAR from chemical formula
    - 1.1.2 Convert POSCAR coordinates (Direct <-> Cartesian)
    - 1.1.3 Convert structure file formats (CIF, POSCAR, XYZ)
    - 1.1.4 Generate structures with defects (Vacancies, Substitutions, Interstitials with Voronoi)
    - 1.1.5 Generate supercells
    - 1.1.6 Generate special quasirandom structures (SQS)
    - 1.1.7 Generate surface slabs
    - 1.1.8 (Planned) Generate interface structures
  
  - 1.2 VASP Input File Preparation
    - 1.2.1 Prepare full VASP input files (INCAR, KPOINTS, POTCAR, POSCAR)
    - 1.2.2 Generate INCAR templates (relaxation, static, MD, etc.)
    - 1.2.3 Generate KPOINTS with specified accuracy
    - 1.2.4 Generate HPC job submission script
    - 1.2.5 Generate standard VASP calculation workflows
      - 1.2.5.1 Convergence testing (ENCUT, KPOINTS)
      - 1.2.5.2 Equation of State (EOS)
      - 1.2.5.3 (Planned) Elastic constants
  
  - 1.3 VASP Output Analysis

2. (Planned) Machine Learning Potentials (MLP)

3. (Planned) Machine Learning Model Training & Evaluation

## Installation
1. Requirements:
   - Python >= 3.9, < 3.13
2. Install via pip:
```bash
pip install masgent
```

## Usage
1. After installation, run the following command to start the Masgent:
```bash
masgent
```
2. Optional preparation:
- For AI functionalities, obtain your OpenAI API key from [platform.openai.com](https://platform.openai.com/account/api-keys).
- For Materials Project access, obtain your API key from [materialsproject.org](https://next-gen.materialsproject.org/api).