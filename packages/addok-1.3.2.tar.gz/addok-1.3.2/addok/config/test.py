# Just to test that keys from a local file are loaded.
COMMON_THRESHOLD = 1000
