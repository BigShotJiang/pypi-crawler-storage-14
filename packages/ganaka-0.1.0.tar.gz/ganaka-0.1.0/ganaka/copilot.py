class Copilot:
    def diagnose(self, session):
        # Logic to look at session.triangle
        # If age_1_factor > 2.0:
        #    return "High volatility detected in Age 1."
        pass