import chainladder as cl

class ReservingSession:
    def __init__(self, df):
        self.triangle = cl.Triangle(df, ...)
        self.model = cl.Chainladder()
        self.judgments = [] # Store user notes here

    def calculate(self, overrides=None):
        # ... logic to run chainladder with overrides ...
        return results

    def add_judgment(self, note):
        self.judgments.append(note)