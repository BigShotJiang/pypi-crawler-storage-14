"""
Test that the_datagarden provides the correct top level imports
"""

import the_datagarden


def test_imports():
    assert the_datagarden
