targetScope = 'resourceGroup'

@description('Cosmos DB account name (globally unique, 3-44 lowercase letters, numbers, and hyphens).')
@minLength(3)
@maxLength(44)
param accountName string

@description('Region for the Cosmos DB account.')
param location string

@description('The default consistency level of the Cosmos DB account.')
@allowed([
  'Eventual'
  'ConsistentPrefix'
  'Session'
  'BoundedStaleness'
  'Strong'
])
param defaultConsistencyLevel string = 'Session'

@description('Database name for Cosmos DB SQL API.')
param databaseName string

@description('Container name for Cosmos DB SQL API.')
param containerName string = 'defaultContainer'

@description('Throughput for the container (RU/s). Use 400 for dev/test, higher for production.')
@minValue(400)
@maxValue(1000000)
param throughput int = 400

@description('Enable automatic failover for multi-region accounts.')
param enableAutomaticFailover bool = false

@description('Enable free tier (only one free tier account per subscription).')
param enableFreeTier bool = false

resource cosmosAccount 'Microsoft.DocumentDB/databaseAccounts@2023-04-15' = {
  name: accountName
  location: location
  kind: 'GlobalDocumentDB'
  properties: {
    consistencyPolicy: {
      defaultConsistencyLevel: defaultConsistencyLevel
    }
    locations: [
      {
        locationName: location
        failoverPriority: 0
        isZoneRedundant: false
      }
    ]
    databaseAccountOfferType: 'Standard'
    enableAutomaticFailover: enableAutomaticFailover
    enableFreeTier: enableFreeTier
    publicNetworkAccess: 'Enabled' // Change to 'Disabled' after NSP/Private Endpoint setup
    networkAclBypass: 'AzureServices'
    disableKeyBasedMetadataWriteAccess: true
    minimalTlsVersion: 'Tls12'
  }
}

resource cosmosDatabase 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases@2023-04-15' = {
  parent: cosmosAccount
  name: databaseName
  properties: {
    resource: {
      id: databaseName
    }
  }
}

resource cosmosContainer 'Microsoft.DocumentDB/databaseAccounts/sqlDatabases/containers@2023-04-15' = {
  parent: cosmosDatabase
  name: containerName
  properties: {
    resource: {
      id: containerName
      partitionKey: {
        paths: [
          '/id'
        ]
        kind: 'Hash'
      }
      indexingPolicy: {
        indexingMode: 'consistent'
        automatic: true
        includedPaths: [
          {
            path: '/*'
          }
        ]
        excludedPaths: [
          {
            path: '/"_etag"/?'
          }
        ]
      }
    }
    options: {
      throughput: throughput
    }
  }
}

output accountId string = cosmosAccount.id
output accountName string = cosmosAccount.name
output documentEndpoint string = cosmosAccount.properties.documentEndpoint
output databaseName string = cosmosDatabase.name
output containerName string = cosmosContainer.name
