targetScope = 'resourceGroup'

@description('SQL Server name (globally unique, lowercase letters, numbers, and hyphens).')
@minLength(1)
@maxLength(63)
param serverName string

@description('Region for the SQL Server and Database.')
param location string

@description('Administrator username for SQL Server.')
param administratorLogin string

@description('Administrator password for SQL Server.')
@secure()
param administratorLoginPassword string

@description('Database name.')
@minLength(1)
@maxLength(128)
param databaseName string

@description('Database SKU name.')
@allowed([
  'Basic'
  'S0'
  'S1'
  'S2'
  'S3'
  'P1'
  'P2'
  'P4'
  'GP_Gen5_2'
  'GP_Gen5_4'
  'GP_Gen5_8'
])
param skuName string = 'Basic'

@description('Database tier.')
@allowed([
  'Basic'
  'Standard'
  'Premium'
  'GeneralPurpose'
])
param tier string = 'Basic'

@description('Maximum size of the database in bytes.')
param maxSizeBytes int = 2147483648 // 2 GB for Basic tier

@description('Enable Azure AD authentication only (disable SQL authentication).')
param enableAzureADOnlyAuth bool = false

@description('Azure AD admin object ID (required if enableAzureADOnlyAuth is true).')
param azureADAdminObjectId string = ''

@description('Azure AD admin login name (required if enableAzureADOnlyAuth is true).')
param azureADAdminLogin string = ''

resource sqlServer 'Microsoft.Sql/servers@2023-05-01-preview' = {
  name: serverName
  location: location
  properties: {
    administratorLogin: administratorLogin
    administratorLoginPassword: administratorLoginPassword
    version: '12.0'
    minimalTlsVersion: '1.2'
    publicNetworkAccess: 'Enabled' // Change to 'Disabled' after NSP/Private Endpoint setup
    restrictOutboundNetworkAccess: 'Disabled'
  }
}

// Configure Azure AD admin if provided
resource sqlServerADAdmin 'Microsoft.Sql/servers/administrators@2023-05-01-preview' = if (!empty(azureADAdminObjectId) && !empty(azureADAdminLogin)) {
  parent: sqlServer
  name: 'ActiveDirectory'
  properties: {
    administratorType: 'ActiveDirectory'
    login: azureADAdminLogin
    sid: azureADAdminObjectId
    tenantId: subscription().tenantId
    azureADOnlyAuthentication: enableAzureADOnlyAuth
  }
}

// Allow Azure services to access the server
resource allowAzureServices 'Microsoft.Sql/servers/firewallRules@2023-05-01-preview' = {
  parent: sqlServer
  name: 'AllowAllWindowsAzureIps'
  properties: {
    startIpAddress: '0.0.0.0'
    endIpAddress: '0.0.0.0'
  }
}

resource sqlDatabase 'Microsoft.Sql/servers/databases@2023-05-01-preview' = {
  parent: sqlServer
  name: databaseName
  location: location
  sku: {
    name: skuName
    tier: tier
  }
  properties: {
    collation: 'SQL_Latin1_General_CP1_CI_AS'
    maxSizeBytes: maxSizeBytes
    catalogCollation: 'SQL_Latin1_General_CP1_CI_AS'
    zoneRedundant: false
    readScale: 'Disabled'
    requestedBackupStorageRedundancy: 'Local'
  }
}

// Enable auditing (sends to Log Analytics if configured)
resource sqlServerAuditSettings 'Microsoft.Sql/servers/auditingSettings@2023-05-01-preview' = {
  parent: sqlServer
  name: 'default'
  properties: {
    state: 'Enabled'
    isAzureMonitorTargetEnabled: true
    retentionDays: 90
  }
}

// Enable Advanced Threat Protection
resource sqlServerSecurityAlert 'Microsoft.Sql/servers/securityAlertPolicies@2023-05-01-preview' = {
  parent: sqlServer
  name: 'Default'
  properties: {
    state: 'Enabled'
    emailAccountAdmins: true
  }
}

output serverId string = sqlServer.id
output serverName string = sqlServer.name
output databaseId string = sqlDatabase.id
output databaseName string = sqlDatabase.name
output serverFqdn string = sqlServer.properties.fullyQualifiedDomainName
