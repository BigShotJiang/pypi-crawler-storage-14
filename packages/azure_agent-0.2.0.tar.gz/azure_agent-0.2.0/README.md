# Azure Agent MCP Server

An Azure resource deployment and management agent built with Model Context Protocol (MCP). This agent provides tools for deploying and managing Azure resources with built-in SFI compliance features including automatic Network Security Perimeter (NSP) attachment and Log Analytics diagnostic settings.

## Features

- **Resource Deployment**: Deploy Azure resources using Bicep templates
- **SFI Compliance**: Automatic NSP attachment and Log Analytics configuration
- **Supported Resources**: Storage Accounts, Key Vault, Azure OpenAI, AI Search, AI Foundry, Cosmos DB, SQL Database, and more
- **Auto-Dependency Management**: Automatic installation and configuration of required PowerShell modules

## Installation

```bash
pip install azure-agent
```

## Prerequisites

- Python 3.12 or higher
- Azure CLI (`az`) installed and authenticated
- PowerShell (pwsh or powershell)

## Supported Azure Resources

- Storage Accounts
- Azure Key Vault
- Azure OpenAI
- Azure AI Search
- Azure AI Foundry
- Cosmos DB
- SQL Database
- Network Security Perimeter

## Usage

The agent exposes MCP tools for deploying and managing Azure resources. All deployments automatically include SFI compliance features.

## License

MIT
