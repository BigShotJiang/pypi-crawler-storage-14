from moysklad_api.methods import MSMethod
from moysklad_api.types import MetaArray, Webhook


class GetWebhooks(MSMethod):
    """
    Метод для получения списка вебхуков.

    Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/workbook/workbook-webhooks#3-chto-takoe-vebhuk
    """

    __return__ = MetaArray[Webhook]
    __api_method__ = "entity/webhook"
