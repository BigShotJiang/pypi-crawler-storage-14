from .entity import Entity


class Attribute(Entity):
    pass
