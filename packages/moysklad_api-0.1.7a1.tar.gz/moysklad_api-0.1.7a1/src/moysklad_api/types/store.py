from .entity import Entity


class Store(Entity):
    pass
