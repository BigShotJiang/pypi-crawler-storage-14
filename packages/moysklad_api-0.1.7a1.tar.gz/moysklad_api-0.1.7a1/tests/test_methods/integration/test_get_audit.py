import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Audit
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetAudit:
    """
    Example with options: --audit-id=1234-5678
    """

    async def test_method(
        self,
        real_client: MoyskladAPI,
        audit_id: str | None, api_params
    ):
        audit = await real_client.get_audit(audit_id=audit_id, **api_params)
        assert isinstance(audit, Audit)
        expanded = api_params.get("expand", None)
        if expanded:
            assert_expand(expanded, audit)
