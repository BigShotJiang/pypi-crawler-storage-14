import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Counterparty, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetCounterparties:
    async def test_method(
        self, real_client: MoyskladAPI, api_params
    ):
        counterparties = await real_client.get_counterparties(**api_params)
        assert isinstance(counterparties, MetaArray)
        assert all(isinstance(c, Counterparty) for c in counterparties.rows)

        expanded = api_params.get("expand", None)
        if expanded:
            for counterparty in counterparties.rows:
                assert_expand(expanded, counterparty)
