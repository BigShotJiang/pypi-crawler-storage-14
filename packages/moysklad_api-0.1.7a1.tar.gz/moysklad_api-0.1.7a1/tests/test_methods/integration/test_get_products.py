import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import MetaArray, Product
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetProducts:
    """
    Example with options: --product-id=1234-5678 --expand=supplier
    """

    async def test_method(
        self, real_client: MoyskladAPI, api_params
    ):
        products = await real_client.get_products(**api_params)

        assert isinstance(products, MetaArray)
        assert all(isinstance(p, Product) for p in products.rows)
        assert len(products.rows) > 1

        expanded = api_params.get("expand", None)
        if expanded:
            for product in products.rows:
                assert_expand(expanded, product)
