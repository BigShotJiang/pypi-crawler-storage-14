import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import MetaArray, Webhook
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetWebhooks:
    async def test_method(
        self, real_client: MoyskladAPI, api_params
    ):
        webhooks = await real_client.get_webhooks(**api_params)
        assert isinstance(webhooks, MetaArray)
        assert all(isinstance(d, Webhook) for d in webhooks.rows)

        expanded = api_params.get("expand", None)
        if expanded:
            for webhook in webhooks.rows:
                assert_expand(expanded, webhook)
