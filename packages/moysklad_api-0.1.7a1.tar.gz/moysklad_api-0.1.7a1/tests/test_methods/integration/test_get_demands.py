import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Demand, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetDemands:
    async def test_method(
        self, real_client: MoyskladAPI, api_params
    ):
        demands = await real_client.get_demands(**api_params)
        assert isinstance(demands, MetaArray)
        assert all(isinstance(d, Demand) for d in demands.rows)

        expanded = api_params.get("expand", None)
        if expanded:
            for demand in demands.rows:
                assert_expand(expanded, demand)
