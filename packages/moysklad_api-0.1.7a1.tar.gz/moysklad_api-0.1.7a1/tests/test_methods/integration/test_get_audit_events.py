import pytest

from moysklad_api import MoyskladAPI
from moysklad_api.types import Event, MetaArray
from tests.exapand import assert_expand


@pytest.mark.asyncio
@pytest.mark.integration
class TestGetAuditEvents:
    """
    Example with options: --audit-id=1234-5678
    """

    async def test_method(
        self,
        real_client: MoyskladAPI,
        audit_id: str | None, api_params
    ):
        events = await real_client.get_audit_events(audit_id=audit_id, **api_params)
        assert isinstance(events, MetaArray)
        assert all(isinstance(e, Event) for e in events.rows)
        expanded = api_params.get("expand", None)
        if expanded:
            assert_expand(expanded, events)
