from .management.base import BaseConfig, BasePath
from .management.fields import ConfField


class SecurityConfig(BaseConfig):
    """Security-related configuration settings."""

    secret_key = ConfField(
        env="SECRET_KEY",
        toml="secret-key",
        default="",
    )

    debug = ConfField(
        env="DEBUG",
        toml="debug",
        default=True,
    )

    allowed_hosts = ConfField(
        env="ALLOWED_HOSTS",
        toml="allowed-hosts",
        default=[],
    )


class ApplicationConfig(BaseConfig):
    """Application and URL configuration settings."""

    configured_apps = ConfField(
        env="CONFIGURED_APPS",
        toml="configured-apps",
        default=[],
    )


class DatabaseConfig(BaseConfig):
    """Database configuration settings."""

    backend = ConfField(
        env="DB_BACKEND",
        toml="db-backend",
        default="sqlite3",
    )

    use_vars = ConfField(
        env="DB_USE_VARS",
        toml="db-use-vars",
        default=False,
    )

    user = ConfField(
        env="DB_USER",
        toml="db-user",
        default="",
    )

    password = ConfField(
        env="DB_PASSWORD",
        toml="db-password",
        default="",
    )

    name = ConfField(
        env="DB_NAME",
        toml="db-name",
        default="",
    )

    host = ConfField(
        env="DB_HOST",
        toml="db-host",
        default="",
    )

    port = ConfField(
        env="DB_PORT",
        toml="db-port",
        default="",
    )

    pool = ConfField(
        env="DB_POOL",
        toml="db-pool",
        default=False,
    )

    pg_service = ConfField(
        env="PG_SERVICE",
        toml="pg-service",
        default="",
    )


class StorageConfig(BaseConfig):
    """Storage configuration settings."""

    backend = ConfField(
        env="STORAGE_BACKEND",
        toml="storage.backend",
        default="filesystem",
    )

    blob_read_write_token = ConfField(
        env="BLOB_READ_WRITE_TOKEN",
        toml="storage.blob_token",
        default="",
    )


class BuildConfig(BaseConfig):
    """Build process configuration settings."""

    commands = ConfField(
        env="BUILD_COMMANDS",
        toml="build-commands",
        default=[],
    )


class DjangXConf:
    """Main configuration class that orchestrates environment, security, app, and database configs."""

    def __init__(self):
        self.base_dir = BasePath().base_dir
        self.security = SecurityConfig()
        self.apps = ApplicationConfig()
        self.db = DatabaseConfig()
        self.storage = StorageConfig()
        self.build = BuildConfig()
