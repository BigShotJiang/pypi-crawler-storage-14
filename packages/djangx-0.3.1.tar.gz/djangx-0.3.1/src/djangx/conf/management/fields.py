from typing import Any, Optional

from ...core.management.utils import (
    str_to_bool,
    str_to_list,
    to_str_if_value_else_empty_str,
)


class ConfField:
    """
    Django-style configuration field descriptor.

    This class defines a configuration field that can be populated from either
    environment variables or TOML configuration files, with a fallback default value.
    Type conversion is handled automatically based on the field name.

    Args:
        env: Environment variable name to read from
        toml: TOML key path (dot-separated) to read from
        default: Default value if neither source provides a value
    """

    # Define which fields need special type handling
    BOOL_FIELDS = {"debug", "use_vars", "pool"}
    LIST_FIELDS = {"allowed_hosts", "configured_apps", "commands"}

    def __init__(
        self,
        env: str = "",
        toml: str = "None",
        default: Any = None,
    ):
        self.env = env
        self.toml = toml
        self.default = default
        self.name: Optional[str] = None

    def __set_name__(self, owner: type, name: str) -> None:
        """
        Called when the descriptor is assigned to a class attribute.
        Stores the attribute name for error messages and debugging.
        """
        self.name = name

    def to_tuple(self) -> tuple:
        """
        Convert the ConfField to the tuple format expected by BaseConfig.

        Returns:
            A tuple of (env_key, toml_key, default, field_name)
        """
        return (self.env, self.toml, self.default, self.name)

    def _convert_value(self, value: Any) -> Any:
        """
        Convert the raw value to the appropriate type based on field name.

        Args:
            value: Raw value from env or TOML

        Returns:
            Converted value of the appropriate type
        """
        if self.name is None:
            return value

        # Handle boolean fields
        if self.name in self.BOOL_FIELDS:
            return str_to_bool(value)

        # Handle list fields
        if self.name in self.LIST_FIELDS:
            return str_to_list(value)

        # Default: return as string or original type
        return to_str_if_value_else_empty_str(value)

    def __get__(self, instance: Any, owner: type) -> Any:
        """
        This shouldn't be called since BaseConfig converts these to properties.
        If this is called, it means __init_subclass__ didn't properly convert the field.
        """
        if instance is None:
            return self
        raise AttributeError(
            f"ConfField {self.name} should have been converted to a property"
        )
