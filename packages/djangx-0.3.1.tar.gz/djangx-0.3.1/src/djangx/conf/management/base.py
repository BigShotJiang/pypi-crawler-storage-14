from __future__ import annotations

import os
import sys
import tomllib
from pathlib import Path
from typing import Any, Dict, Optional

from django.core.management.color import color_style

from .fields import ConfField


class BasePath:
    """Directory path configuration settings and validation of DjangX app project structure."""

    def __init__(self):
        self._cwd = Path.cwd()
        self._base_dir: Optional[Path] = None
        self._is_base_dir: Optional[bool] = None

    def _detect_base_dir(self) -> None:
        """Detect if we're in a valid DjangX project and cache the results."""
        apps_py = self._cwd / "app" / "apps.py"

        if apps_py.exists():
            try:
                with open(apps_py, "r", encoding="utf-8") as f:
                    content = f.read()
                if "DjangXAppConfig" in content:
                    self._base_dir = apps_py.resolve().parent.parent
                    self._is_base_dir = True
                else:
                    self._base_dir = self._cwd
                    self._is_base_dir = False
            except (OSError, UnicodeDecodeError):
                self._base_dir = self._cwd
                self._is_base_dir = False
        else:
            self._base_dir = self._cwd
            self._is_base_dir = False

    @property
    def base_dir(self) -> Path:
        if self._base_dir is None:
            self._detect_base_dir()
        assert self._base_dir is not None
        if self._is_base_dir is False:
            print(
                color_style().WARNING(
                    "Not a DjangX root. Navigate to your project root or initialize a new DjangX app."
                )
            )
            sys.exit(1)
        return self._base_dir


class BaseConfig:
    """Base configuration class that handles loading from environment variables and TOML files."""
    
    _toml_data: Dict[str, Any] = {}
    _toml_loaded: bool = False
    _config_specs = {}

    @classmethod
    def _load_toml(
        cls,
        toml_path: Path = BasePath().base_dir / "pyproject.toml",
        section: str | None = None,
    ) -> None:
        """Load TOML configuration from pyproject.toml file."""
        if not cls._toml_loaded:
            path = toml_path
            if path.exists():
                with path.open("rb") as f:
                    all_data = tomllib.load(f)
                
                # Navigate to the specified section if provided
                if section:
                    data: Any = all_data
                    for key in section.split("."):
                        if isinstance(data, dict):
                            data = data.get(key, {})
                        else:
                            data = {}
                            break
                    cls._toml_data = data if isinstance(data, dict) else {}
                else:
                    cls._toml_data = all_data
            else:
                cls._toml_data = {}
            cls._toml_loaded = True

    @classmethod
    def _get_from_toml(
        cls, key: str | None, section: str | None = "tool.djangx", default: Any = None
    ) -> Any:
        """
        Get value from TOML configuration.
        
        Args:
            key: Dot-separated path to the config value (e.g., "storage.backend")
            section: The TOML section to load (e.g., "tool.djangx")
            default: Default value if key is not found
            
        Returns:
            The value from TOML, or the default if not found
        """
        if key is None:
            return default
        
        # Ensure TOML is loaded with the correct section
        cls._load_toml(section=section)
        
        # Navigate through nested keys
        current = cls._toml_data
        for k in key.split("."):
            if isinstance(current, dict) and k in current:
                current = current[k]
            else:
                return default
        
        return current

    @classmethod
    def _fetch_value(
        cls,
        env_key: str | None = None,
        toml_key: str | None = None,
        default: Any = None,
        toml_section: str | None = "tool.djangx",
    ) -> Any:
        """
        Fetch configuration value with fallback priority: ENV -> TOML -> default.
        
        Args:
            env_key: Environment variable name to check
            toml_key: TOML key path to check (dot-separated)
            default: Default value if neither source has the value
            toml_section: TOML section to search in
            
        Returns:
            The configuration value from the first available source (raw, no casting)
        """
        # Try environment variable first (if env_key is provided and exists)
        if env_key and env_key in os.environ:
            return os.environ[env_key]
        
        # Fall back to TOML config
        value = cls._get_from_toml(toml_key, section=toml_section, default=default)
        return value

    def __init_subclass__(cls) -> None:
        """
        Automatically convert ConfField descriptors to properties when a subclass is created.
        This allows declarative configuration field definitions to work seamlessly.
        """
        super().__init_subclass__()
        cls._config_specs = dict(getattr(cls, "_config_specs", {}))

        for attr_name, attr_value in list(vars(cls).items()):
            # Skip private attributes, methods, and special descriptors
            if (
                attr_name.startswith("_")
                or callable(attr_value)
                or isinstance(attr_value, (classmethod, staticmethod, property))
            ):
                continue

            config_tuple = None

            # Check if this is a ConfField and extract its configuration
            if isinstance(attr_value, ConfField):
                config_tuple = attr_value.to_tuple()

            if not config_tuple:
                continue

            # Store the configuration spec for this field
            cls._config_specs[attr_name] = config_tuple

            # Create a property getter for this configuration field
            def make_getter(name: str, cfg: tuple, field: ConfField):
                def getter(self: "BaseConfig") -> Any:
                    env_key = cfg[0]
                    toml_key = cfg[1]
                    default = cfg[2]

                    # Fetch the raw value using the configured sources
                    raw_value = self._fetch_value(env_key, toml_key, default)
                    
                    # Convert to the appropriate type using the ConfField's logic
                    return field._convert_value(raw_value)

                return getter

            # Replace the ConfField with a property
            setattr(cls, attr_name, property(make_getter(attr_name, config_tuple, attr_value)))

    @classmethod
    def list_env_keys(cls):
        """List all environment variable keys used by this config class."""
        pass