from django.apps import AppConfig


class DjangXCoreConfig(AppConfig):
    name = "djangx.core"
