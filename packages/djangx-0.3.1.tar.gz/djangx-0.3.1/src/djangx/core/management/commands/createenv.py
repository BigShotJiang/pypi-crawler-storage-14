"""Management command: createenv"""

# TODO: Based on my utils.py, create for me a fully typed createenv.py management command that uses getattr settings. BASE_DIR and pathlib write_text, and mutually exclusive arguments for --force (if I want to overwrite) and --example (if I want to create an .env.example instead) that writes to an .env file (or .env.example if --example flag is used) all the possible environment variables and they should all be commented out. Use textwrap.dedent for proper code alignment if necessary.

# from django.conf import settings
# from django.core.management.base import BaseCommand, CommandError, CommandParser
