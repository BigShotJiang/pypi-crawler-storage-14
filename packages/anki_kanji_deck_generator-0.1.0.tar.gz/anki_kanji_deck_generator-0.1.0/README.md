# Anki Kanji Deck Generator

A Python script built to **generate Anki flashcard decks for JLPT Kanji with customizable templates**. This tool efficiently fetches comprehensive Kanji data using the **Kanjilive API** and utilizes the **genanki** library to create high-quality, structured Anki decks tailored for Japanese language learners.

## 🌟 Features

* **Flexible Filtering:** Generate decks based on standard **JLPT Levels** (N5 to N1) or **Kyōiku Kanji School Grades** (Grade 1 to 6).
* **Customizable Templates:** Supports using custom HTML (`.html`) and CSS (`.css`) templates (located in `src/generator/template`) for unique card styling.
* **Rich Kanji Data:** Fetches detailed information (readings, meanings, stroke order, compounds, etc.) via the Kanjilive API.
* **Modern Python Tooling:** Managed using **Poetry** for robust dependency management and project structure.

---

## 🛠️ Prerequisites

* **Python 3.11** (Required version as per `pyproject.toml`)
* **[Poetry](https://python-poetry.org/docs/#installation)** (Recommended dependency manager)

---

## 🚀 Installation

This project uses [Poetry](https://python-poetry.org/) for dependency management and environment setup.

1.  **Clone the Repository:**

    ```bash
    git clone [https://github.com/arirismansyah/anki-kanji-deck-generator.git](https://github.com/arirismansyah/anki-kanji-deck-generator.git)
    cd anki-kanji-deck-generator
    ```

2.  **Install Dependencies:**

    Poetry will read the `pyproject.toml` file, create a virtual environment, and install all required packages.

    ```bash
    poetry install
    ```

---

## 💡 Usage

To run the generator and create your Anki deck, execute the main script within the Poetry environment.

1.  **Execute the Generator:**

    ```bash
    poetry run python src/generator/main.py
    ```

    *Note: Before running, ensure you configure the script (e.g., in `src/generator/main.py`) to specify whether you are generating by **JLPT Level** or **School Grade**.*

2.  **Generated Deck:**

    Upon successful execution, a new Anki package file (e.g., `Kanji_Deck_N4.apkg` or `Kanji_Deck_Grade3.apkg`) will be created in the designated output directory.

3.  **Import into Anki:**

    Open your Anki application and import the generated `.apkg` file via **File** → **Import**.

---

## 📦 Key Dependencies

| Package | Purpose |
| :--- | :--- |
| `genanki` | The core library for programmatic generation of Anki decks. |
| `requests` | Handling HTTP requests to fetch data from the Kanjilive API. |
| `pandas` | Data manipulation and structuring of Kanji entries. |
| `pydantic` | Data validation for the fetched Kanji schema. |

---

## 🤝 Credits

This project relies on the following excellent tools and services:

* **[Kanjilive API](https://kanjilive.com/)**: The source for comprehensive Kanji data.
* **[genanki](https://github.com/kerrickstaley/genanki)**: The library used for deck construction.

## 📄 License

This project is licensed under the **MIT License**.