# Usage

To use climdata in a project:

```
import climdata
```
