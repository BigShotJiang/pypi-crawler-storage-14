print("{} {}".format("hello", "world"))
