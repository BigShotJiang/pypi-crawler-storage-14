fruit = ["apple", "banana", "orange"]
