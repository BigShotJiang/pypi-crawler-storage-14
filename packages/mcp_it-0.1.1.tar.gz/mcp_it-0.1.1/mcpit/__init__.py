"""MCP It – Transform any FastAPI server into an MCP server."""
from .main import MCPIt

__version__ = "0.1.0"
__all__ = ["MCPIt"]

