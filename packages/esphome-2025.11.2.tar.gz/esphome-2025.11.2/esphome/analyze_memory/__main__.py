"""Main entry point for running the memory analyzer as a module."""

from .cli import main

if __name__ == "__main__":
    main()
