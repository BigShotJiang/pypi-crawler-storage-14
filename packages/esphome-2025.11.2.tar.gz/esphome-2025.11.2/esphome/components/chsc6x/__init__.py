CODEOWNERS = ["@kkosik20"]
DEPENDENCIES = ["i2c"]
