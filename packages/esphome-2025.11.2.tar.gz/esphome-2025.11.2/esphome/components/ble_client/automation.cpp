#ifdef USE_ESP32

#include "automation.h"

namespace esphome {
namespace ble_client {

const char *const Automation::TAG = "ble_client.automation";

}  // namespace ble_client
}  // namespace esphome

#endif
