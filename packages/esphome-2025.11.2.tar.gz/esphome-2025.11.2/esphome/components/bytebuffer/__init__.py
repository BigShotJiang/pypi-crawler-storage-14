CODEOWNERS = ["@clydebarrow"]

# Allows bytebuffer to be configured in yaml, to allow use of the C++ api.

CONFIG_SCHEMA = {}
