from setuptools import setup

# This file exists to support editable installs with older pip versions
# All configuration is in pyproject.toml
setup()
