"""Python client for the Ray debugging app (port of spatie/ray PHP library).

Public API:
- ray(*values): send values to Ray and return a Ray instance.
- rd(*values): send values and terminate the process.
"""

from __future__ import annotations

from .ray import Ray  # noqa: F401
from .helpers import ray, rd  # noqa: F401

__all__ = ["Ray", "ray", "rd"]
