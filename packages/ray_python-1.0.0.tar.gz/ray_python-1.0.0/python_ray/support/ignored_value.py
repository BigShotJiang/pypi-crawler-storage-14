from __future__ import annotations


class IgnoredValue:
    """Marker type used internally to drop values from Ray.send."""

    @staticmethod
    def make() -> "IgnoredValue":  # parity with PHP API name
        return IgnoredValue()
