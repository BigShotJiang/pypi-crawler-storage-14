from __future__ import annotations

from typing import Any, Dict

from .base import Payload


class SeparatorPayload(Payload):
    def get_type(self) -> str:
        return "separator"

    def get_content(self) -> Dict[str, Any]:
        return {}
