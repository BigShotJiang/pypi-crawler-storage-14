from __future__ import annotations

from typing import Any, Dict

from .base import Payload


class HidePayload(Payload):
    def get_type(self) -> str:
        return "hide"

    def get_content(self) -> Dict[str, Any]:
        return {}
