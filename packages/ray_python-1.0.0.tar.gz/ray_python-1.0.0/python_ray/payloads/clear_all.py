from __future__ import annotations

from typing import Any, Dict

from .base import Payload


class ClearAllPayload(Payload):
    def get_type(self) -> str:
        return "clear_all"

    def get_content(self) -> Dict[str, Any]:
        return {}
