# MNE_XDF

A Python library for importing XDF files for use with MNE-Python. This package provides utilities to read and convert XDF (eXtensible Data Format) files into MNE-Python compatible data structures.
