"""Payload schema metadata for AIP resources.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

__all__: list[str] = []
