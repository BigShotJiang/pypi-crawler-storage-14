"""Account management commands for multi-account profiles.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

import getpass
import json
import sys

import click
from rich.console import Console
from rich.text import Text

from glaip_sdk.branding import (
    ACCENT_STYLE,
    ERROR_STYLE,
    INFO,
    NEUTRAL,
    SUCCESS,
    SUCCESS_STYLE,
    WARNING_STYLE,
)
from glaip_sdk.cli.account_store import (
    AccountNotFoundError,
    AccountStore,
    AccountStoreError,
    InvalidAccountNameError,
    get_account_store,
)
from glaip_sdk.cli.commands.common_config import check_connection, render_branding_header
from glaip_sdk.cli.hints import format_command_hint
from glaip_sdk.cli.masking import mask_api_key_display
from glaip_sdk.cli.utils import command_hint
from glaip_sdk.icons import ICON_TOOL
from glaip_sdk.rich_components import AIPPanel, AIPTable

console = Console()


@click.group()
def accounts_group() -> None:
    """Manage multiple account profiles."""


_mask_api_key = mask_api_key_display


def _print_active_account_footer(store: AccountStore) -> None:
    """Print footer showing active account."""
    active = store.get_active_account()
    if active:
        account = store.get_account(active)
        if account:
            url = account.get("api_url", "")
            masked_key = _mask_api_key(account.get("api_key"))
            console.print(f"\n[{SUCCESS_STYLE}]Active account[/]: {active} · {url} · {masked_key}")


@accounts_group.command("list")
@click.option("--json", "output_json", is_flag=True, help="Output in JSON format")
def list_accounts(output_json: bool) -> None:
    """List all account profiles."""
    store = get_account_store()
    accounts = store.list_accounts()
    active_account = store.get_active_account()

    if output_json:
        accounts_list = []
        for name, account in accounts.items():
            accounts_list.append(
                {
                    "name": name,
                    "api_url": account.get("api_url", ""),
                    "has_key": bool(account.get("api_key")),
                    "active": name == active_account,
                },
            )
        click.echo(json.dumps(accounts_list, indent=2))
        return

    if not accounts:
        console.print(f"[{WARNING_STYLE}]No accounts found.[/]")
        hint = command_hint("accounts add", slash_command="login")
        if hint:
            console.print(f"Run {format_command_hint(hint) or hint} to add an account.")
        return

    # Render table
    table = AIPTable(title=f"{ICON_TOOL} AIP Accounts")
    table.add_column("Name", style=INFO, width=20)
    table.add_column("API URL", style=SUCCESS, width=40)
    table.add_column("Key (masked)", style=NEUTRAL, width=20)
    table.add_column("Status", style=SUCCESS_STYLE, width=10)

    for name, account in sorted(accounts.items()):
        url = account.get("api_url", "")
        masked_key = _mask_api_key(account.get("api_key"))
        is_active = name == active_account
        status = "[bold green]●[/bold green] active" if is_active else ""

        table.add_row(name, url, masked_key, status)

    console.print(table)

    if active_account:
        console.print(f"\n[{SUCCESS_STYLE}]Active account[/]: {active_account}")


def _check_account_overwrite(name: str, store: AccountStore, overwrite: bool) -> dict[str, str] | None:
    """Check if account exists and handle overwrite logic.

    Args:
        name: Account name.
        store: Account store instance.
        overwrite: Whether to allow overwrite.

    Returns:
        Existing account dict or None.

    Raises:
        click.Abort: If account exists and overwrite is False.
    """
    existing = store.get_account(name)
    if existing and not overwrite:
        console.print(f"[{WARNING_STYLE}]Account '{name}' already exists.[/] Use --yes to overwrite.")
        raise click.Abort()
    return existing


def _get_credentials_non_interactive(url: str, read_key_from_stdin: bool, name: str) -> tuple[str, str]:
    """Get credentials in non-interactive mode.

    Args:
        url: API URL from flag.
        read_key_from_stdin: Whether to read key from stdin.
        name: Account name (for error messages).

    Returns:
        Tuple of (api_url, api_key).

    Raises:
        click.Abort: If stdin is required but not available, or if --key used without --url.
    """
    if read_key_from_stdin:
        if not sys.stdin.isatty():
            return url, sys.stdin.read().strip()
        console.print(
            f"[{ERROR_STYLE}]Error: --key requires stdin input. "
            f"Use: cat key.txt | aip accounts add {name} --url {url} --key[/]",
        )
        raise click.Abort()
    # URL provided, prompt for key
    console.print(f"\n[{ACCENT_STYLE}]AIP API Key[/]:")
    return url, getpass.getpass("> ")


def _get_credentials_interactive(read_key_from_stdin: bool, existing: dict[str, str] | None) -> tuple[str, str]:
    """Get credentials in interactive mode.

    Args:
        read_key_from_stdin: Whether --key flag was used.
        existing: Existing account data.

    Returns:
        Tuple of (api_url, api_key).

    Raises:
        click.Abort: If --key used without --url.
    """
    if read_key_from_stdin:
        console.print(
            f"[{ERROR_STYLE}]Error: --key requires --url. For non-interactive mode, provide both: --url <url> --key[/]",
        )
        raise click.Abort()
    # Fully interactive
    _render_configuration_header()
    return _prompt_account_inputs(existing)


def _collect_account_credentials(
    url: str | None,
    read_key_from_stdin: bool,
    name: str,
    existing: dict[str, str] | None,
) -> tuple[str, str]:
    """Collect account credentials from various input methods.

    Args:
        url: Optional URL from flag.
        read_key_from_stdin: Whether to read key from stdin.
        name: Account name (for error messages).
        existing: Existing account data.

    Returns:
        Tuple of (api_url, api_key).

    Raises:
        click.Abort: If credentials cannot be collected or are invalid.
    """
    if url and read_key_from_stdin:
        # Non-interactive: URL from flag, key from stdin
        api_url, api_key = _get_credentials_non_interactive(url, True, name)
    elif url:
        # URL provided, prompt for key
        api_url, api_key = _get_credentials_non_interactive(url, False, name)
    else:
        # Fully interactive or error case
        api_url, api_key = _get_credentials_interactive(read_key_from_stdin, existing)

    if not api_url or not api_key:
        console.print(f"[{ERROR_STYLE}]Error: Both API URL and API key are required.[/]")
        raise click.Abort()
    return api_url, api_key


@accounts_group.command("add")
@click.argument("name")
@click.option("--url", help="API URL (required for non-interactive mode)")
@click.option(
    "--key",
    "read_key_from_stdin",
    is_flag=True,
    help="Read API key from stdin (secure, for scripts). Requires --url.",
)
@click.option(
    "--yes",
    "overwrite",
    is_flag=True,
    help="Overwrite existing account without prompting",
)
def add_account(
    name: str,
    url: str | None,
    read_key_from_stdin: bool,
    overwrite: bool,
) -> None:
    """Add or update an account profile.

    NAME is the account name (1-32 chars, alphanumeric, dash, underscore).

    By default, this command runs interactively, prompting for API URL and key.
    For non-interactive use, both --url and --key (stdin) are required.
    """
    store = get_account_store()

    # Check account overwrite
    existing = _check_account_overwrite(name, store, overwrite)

    # Collect credentials
    api_url, api_key = _collect_account_credentials(url, read_key_from_stdin, name, existing)

    # Save account
    try:
        store.add_account(name, api_url, api_key, overwrite=True)
        console.print(Text(f"✅ Account '{name}' saved successfully", style=SUCCESS_STYLE))
        _print_active_account_footer(store)
    except InvalidAccountNameError as e:
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e
    except AccountStoreError as e:
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e


@accounts_group.command("use")
@click.argument("name")
def use_account(name: str) -> None:
    """Switch to a different account profile."""
    store = get_account_store()

    try:
        account = store.get_account(name)
        if not account:
            console.print(f"[{ERROR_STYLE}]Error: Account '{name}' not found.[/]")
            raise click.Abort()

        url = account.get("api_url", "")
        masked_key = _mask_api_key(account.get("api_key"))
        api_key = account.get("api_key", "")

        if not url or not api_key:
            console.print(
                f"[{ERROR_STYLE}]Error: Account '{name}' is missing credentials. Re-run 'aip accounts add {name}'.[/]"
            )
            raise click.Abort()

        # Always validate before switching
        check_connection(url, api_key, console, abort_on_error=True)

        store.set_active_account(name)

        console.print(
            AIPPanel(
                f"[{SUCCESS_STYLE}]Active account ➜ {name}[/]\nAPI URL: {url}\nKey: {masked_key}",
                title="✅ Account Switched",
                border_style=SUCCESS,
            ),
        )
    except click.Abort:
        # check_connection already printed the failure context; just propagate
        raise
    except AccountNotFoundError as e:
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e
    except Exception as e:
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e


@accounts_group.command("rename")
@click.argument("current_name")
@click.argument("new_name")
@click.option(
    "--yes",
    "overwrite",
    is_flag=True,
    help="Overwrite target account if it already exists",
)
def rename_account(current_name: str, new_name: str, overwrite: bool) -> None:
    """Rename an account profile."""
    store = get_account_store()

    if current_name == new_name:
        console.print(f"[{WARNING_STYLE}]Source and target names are the same; nothing to rename.[/]")
        return

    try:
        if not store.get_account(current_name):
            console.print(f"[{ERROR_STYLE}]Error: Account '{current_name}' not found.[/]")
            raise click.Abort()

        # Guard before calling store.rename_account to keep consistent messaging with add --yes
        if store.get_account(new_name) and not overwrite:
            console.print(f"[{WARNING_STYLE}]Account '{new_name}' already exists.[/] Use --yes to overwrite.")
            raise click.Abort()

        store.rename_account(current_name, new_name, overwrite=overwrite)
        console.print(Text(f"✅ Account '{current_name}' renamed to '{new_name}'", style=SUCCESS_STYLE))
        _print_active_account_footer(store)
    except AccountStoreError as e:
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e
    except Exception as e:  # pragma: no cover - defensive catch-all
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e


@accounts_group.command("remove")
@click.argument("name")
@click.option("--yes", "force", is_flag=True, help="Skip confirmation prompt")
def remove_account(name: str, force: bool) -> None:
    """Remove an account profile."""
    store = get_account_store()

    account = store.get_account(name)
    if not account:
        console.print(f"[{WARNING_STYLE}]Account '{name}' not found.[/]")
        return

    if not force:
        console.print(f"[{WARNING_STYLE}]This will remove account '{name}'.[/]")
        confirm = input("Are you sure? (y/N): ").strip().lower()
        if confirm not in ["y", "yes"]:
            console.print("Cancelled.")
            return

    try:
        store.remove_account(name)
        console.print(Text(f"✅ Account '{name}' removed", style=SUCCESS_STYLE))

        # Show new active account if it changed
        active = store.get_active_account()
        if active:
            console.print(f"[{SUCCESS_STYLE}]Active account is now: {active}[/]")
    except AccountStoreError as e:
        console.print(f"[{ERROR_STYLE}]Error: {e}[/]")
        raise click.Abort() from e


def _render_configuration_header() -> None:
    """Display the interactive configuration heading/banner."""
    render_branding_header(console, "[bold]AIP Account Configuration[/bold]")


def _prompt_account_inputs(existing: dict[str, str] | None) -> tuple[str, str]:
    """Interactively prompt for account credentials."""
    console.print("\n[bold]Enter your AIP configuration:[/bold]")
    if existing:
        console.print("(Leave blank to keep current values)")
    console.print("─" * 50)

    # Prompt for URL
    current_url = existing.get("api_url", "") if existing else ""
    suffix = f"(current: {current_url})" if current_url else ""
    console.print(f"\n[{ACCENT_STYLE}]AIP API URL[/] {suffix}:")
    new_url = input("> ").strip()
    api_url = new_url if new_url else current_url
    if not api_url:
        api_url = "https://your-aip-instance.com"

    # Prompt for key
    current_key_masked = _mask_api_key(existing.get("api_key")) if existing else ""
    suffix = f"(current: {current_key_masked})" if current_key_masked else ""
    console.print(f"\n[{ACCENT_STYLE}]AIP API Key[/] {suffix}:")
    new_key = getpass.getpass("> ")
    if new_key:
        api_key = new_key
    elif existing:
        api_key = existing.get("api_key", "")
    else:
        api_key = ""

    return api_url, api_key
