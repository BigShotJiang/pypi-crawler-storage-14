class FXMacroDataError(Exception):
    """Custom exception for FXMacroData client errors."""

    pass
