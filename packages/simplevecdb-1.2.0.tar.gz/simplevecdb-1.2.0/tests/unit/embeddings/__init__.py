"""Embeddings server tests."""
