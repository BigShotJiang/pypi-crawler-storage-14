# Quantization Strategy

The quantization module handles vector encoding and compression.

::: simplevecdb.engine.quantization.QuantizationStrategy

::: simplevecdb.engine.quantization.normalize_l2
