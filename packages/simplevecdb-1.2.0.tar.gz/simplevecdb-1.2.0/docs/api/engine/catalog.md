# Catalog Manager

The catalog module handles collection schema management and CRUD operations.

::: simplevecdb.engine.catalog.CatalogManager
