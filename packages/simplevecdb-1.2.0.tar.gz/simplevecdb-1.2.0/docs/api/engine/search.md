# Search Engine

The search module handles all vector and keyword search operations.

::: simplevecdb.engine.search.SearchEngine
