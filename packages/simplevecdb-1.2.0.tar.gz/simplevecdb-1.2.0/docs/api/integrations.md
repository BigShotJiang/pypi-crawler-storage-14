# Integrations API

## LangChain

::: simplevecdb.integrations.langchain.SimpleVecDBVectorStore

## LlamaIndex

::: simplevecdb.integrations.llamaindex.SimpleVecDBLlamaStore
