# Embeddings API

::: simplevecdb.embeddings.models

::: simplevecdb.embeddings.server
