# Core API

::: simplevecdb.core.VectorDB

::: simplevecdb.core.VectorCollection
