import os

from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _


class FileSizeValidator:
    """
    Validator for file size validation.
    Requires explicit max_size parameter in bytes.
    """
    message = _('File too large. Size is %(size)s, maximum allowed is %(max_size)s.')
    code = 'file_too_large'

    def __init__(self, max_size, message=None, code=None):
        self.max_size = max_size
        if message is not None:
            self.message = message
        if code is not None:
            self.code = code

    def __call__(self, file):
        if file.size > self.max_size:
            # Format sizes for user-friendly display with appropriate units
            def format_size(size_bytes):
                if size_bytes >= 1024 * 1024:  # >= 1MB
                    return f'{size_bytes / (1024 * 1024):.1f}MB'
                elif size_bytes >= 1024:  # >= 1KB
                    return f'{size_bytes / 1024:.1f}KB'
                else:  # < 1KB
                    return f'{size_bytes}B'

            raise ValidationError(
                self.message,
                code=self.code,
                params={
                    'size': format_size(file.size),
                    'max_size': format_size(self.max_size),
                    'size_bytes': file.size,
                    'max_size_bytes': self.max_size,
                }
            )


class FileExtensionValidator:
    """
    Validator for file extension validation.
    Requires explicit list of allowed extensions.
    """
    message = _('File extension "%(extension)s" is not allowed. Allowed extensions are: %(allowed_extensions)s.')
    code = 'invalid_extension'

    def __init__(self, allowed_extensions, message=None, code=None):
        self.allowed_extensions = allowed_extensions
        if message is not None:
            self.message = message
        if code is not None:
            self.code = code

    def __call__(self, file):
        ext = os.path.splitext(file.name)[1].lower()
        if ext not in [e.lower() for e in self.allowed_extensions]:
            raise ValidationError(
                self.message,
                code=self.code,
                params={
                    'extension': ext,
                    'allowed_extensions': ', '.join(self.allowed_extensions),
                }
            )


class ContentTypeValidator:
    """
    Validator for MIME type validation.
    Requires explicit list of allowed content types.
    """
    message = _('File type "%(content_type)s" is not allowed. Allowed types are: %(allowed_types)s.')
    code = 'invalid_content_type'

    def __init__(self, allowed_types, message=None, code=None):
        self.allowed_types = allowed_types
        if message is not None:
            self.message = message
        if code is not None:
            self.code = code

    def __call__(self, file):
        # Use the actual content type from the uploaded file, not guessed from filename
        mime_type = getattr(file, 'content_type', 'unknown')

        if mime_type not in self.allowed_types:
            raise ValidationError(
                self.message,
                code=self.code,
                params={
                    'content_type': mime_type,
                    'allowed_types': ', '.join(self.allowed_types),
                }
            )
