import json
import mimetypes
import posixpath
import uuid
from datetime import datetime

from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.core.files.storage import Storage, default_storage
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.utils.translation import gettext_lazy as _
from django.views import View
from django.views.decorators.http import require_POST

from .utils import create_file_token, sanitize_file_extension
from .validators import ContentTypeValidator, FileExtensionValidator, FileSizeValidator


def get_default_validators():
    """Get default validators from Django settings."""
    default_validators = []

    # Add file size validator if max size is configured
    max_size = getattr(settings, 'AJAX_FILEFIELD_DEFAULT_MAX_SIZE', None)
    if max_size is not None:
        default_validators.append(FileSizeValidator(max_size))

    # Add extension validator if allowed extensions are configured
    allowed_extensions = getattr(settings, 'AJAX_FILEFIELD_DEFAULT_ALLOWED_EXTENSIONS', None)
    if allowed_extensions:
        default_validators.append(FileExtensionValidator(allowed_extensions))

    # Add content type validator if allowed types are configured
    allowed_types = getattr(settings, 'AJAX_FILEFIELD_DEFAULT_ALLOWED_CONTENT_TYPES', None)
    if allowed_types:
        default_validators.append(ContentTypeValidator(allowed_types))

    return default_validators


@method_decorator(require_POST, name='dispatch')
class AjaxUploadView(View):
    """
    Class-based view for handling AJAX file uploads.

    Attributes:
        upload_to (str or callable): Path within storage where files will be uploaded.
        storage: Django storage backend to use.
        validators (list): List of validator functions to apply to uploaded files.
        save_metadata (bool): Whether to save metadata files alongside uploads.
    """

    upload_to = ""
    storage = None
    validators = None
    save_metadata = True

    def __init__(self, **kwargs):
        """
        Initialize the view with validators.
        Args:
            **kwargs: Arbitrary keyword arguments passed to the parent class.
        """
        super().__init__(**kwargs)

        # Since get_default_validators() depends on settings, we set it here
        # in __init__() so that tests can change the settings as needed.
        # We do it before super().__init__() so validators supplied via kwargs
        # always take precedence.
        if self.validators is None:
            self.validators = get_default_validators()

        if self.storage is None:
            self.storage = default_storage
        elif callable(self.storage):
            storage = self.storage()
            if not isinstance(storage, Storage):
                raise TypeError(
                    f"{self.__class__.__qualname__}.storage must be a subclass/instance of {Storage.__module__}.{Storage.__qualname__}"
                )
            else:
                self.storage = storage

    def post(self, request):
        """Handle AJAX file upload POST requests."""
        if "file" not in request.FILES:
            return JsonResponse({
                "success": False,
                "errors": [{"code": "no_file", "message": _("No file provided")}]
            }, status=400)

        uploaded_file = request.FILES["file"]

        # Validate the uploaded file
        validation_errors = self.validate_file(uploaded_file)
        if validation_errors:
            return JsonResponse({
                "success": False,
                "errors": validation_errors
            }, status=400)

        # Process and save the file
        result = self.process_file(uploaded_file)
        return JsonResponse({
            "success": True,
            **result
        })

    def validate_file(self, uploaded_file):
        """Validate the uploaded file using configured validators."""
        errors = []
        for validator in self.validators:
            try:
                validator(uploaded_file)
            except ValidationError as e:
                errors.append({
                    "code": e.code,
                    "message": e.messages[0],
                })
        return errors

    def process_file(self, uploaded_file):
        """Process and save the uploaded file."""
        upload_datetime = datetime.now()

        # Generate and save the file
        filename = self.get_upload_filename(uploaded_file, upload_datetime)
        filename = self.storage.generate_filename(filename)
        saved_path = self.storage.save(filename, uploaded_file)

        # Create and save metadata
        metadata = self.get_metadata(uploaded_file, upload_datetime)

        if self.save_metadata:
            self.save_metadata_file(filename, metadata)

        return {
            # Path within storage where the file is saved, used as value by the filefield
            "tmp_path": saved_path,
            # URL for accessing the uploaded file (e.g. for preview)
            "tmp_file_url": self.storage.url(saved_path),
            # Security token for verifying file access (bound to filename to prevent file swapping)
            "token": create_file_token(saved_path, filename=metadata["original_filename"]),
            # Additional metadata about the uploaded file
            **metadata
        }

    def get_upload_filename(self, uploaded_file, upload_datetime):
        """Generate the filename for the uploaded file."""
        if callable(self.upload_to):
            return self.upload_to(uploaded_file)
        else:
            dirname = upload_datetime.strftime(str(self.upload_to))
            unique_id = str(uuid.uuid4())
            ext = sanitize_file_extension(uploaded_file.name)

            return posixpath.join(dirname, f"{int(upload_datetime.timestamp())}_{unique_id}{ext}")

    def get_metadata(self, uploaded_file, upload_datetime):
        """Generate metadata for the uploaded file."""
        uploaded_file_name = uploaded_file.name
        uploaded_file_mime_type = mimetypes.guess_type(uploaded_file_name)[0]

        return {
            "original_filename": uploaded_file_name,
            "size": uploaded_file.size,
            "extension": sanitize_file_extension(uploaded_file_name),
            "mime_type": uploaded_file_mime_type,
            "is_image": uploaded_file_mime_type and uploaded_file_mime_type.startswith("image/"),
            "uploaded_at": upload_datetime.timestamp(),
        }

    def get_metadata_filename(self, original_filename):
        """Generate a metadata filename by appending '.json' extension to the original filename."""
        return f"{original_filename}.json"

    def save_metadata_file(self, filename, metadata):
        """Save metadata file alongside the uploaded file."""
        metadata_filename = self.get_metadata_filename(filename)
        metadata_file = ContentFile(json.dumps(metadata, indent=2).encode('utf-8'))
        self.storage.save(metadata_filename, metadata_file)


def ajax_upload_view(*args, **kwargs):
    """
    Factory function that creates a configurable AJAX upload view.

    Args:
        *args: Positional arguments passed to AjaxUploadView
        **kwargs: Keyword arguments passed to AjaxUploadView, including:
            upload_to (str or callable): Path within storage where files will be uploaded.
            storage: Django storage backend to use (defaults to default_storage)
            validators (list): List of validator functions to apply to uploaded files.
            save_metadata (bool): Whether to save metadata files alongside uploads.

    Returns:
        View class configured with the specified parameters
    """
    return AjaxUploadView.as_view(*args, **kwargs)
