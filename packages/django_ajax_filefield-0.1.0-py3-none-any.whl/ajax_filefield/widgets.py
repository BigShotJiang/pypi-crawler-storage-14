
from django.forms.widgets import FileInput
from django.utils.translation import gettext_lazy as _


class AjaxFileInput(FileInput):
    input_type = "file"
    needs_multipart_form = False
    template_name = "ajax_filefield/widget.html"

    choose_button_label = _("Choose File")
    clear_button_label = _("Clear")
    reset_button_label = _("Reset")
    uploading_label = _("Uploading...")

    error_messages = {
        "invalid_response": _("Invalid server response. Please try uploading again."),
        "network": _("Network error during upload. Please try uploading again."),
        "unknown": _("An unknown error occurred. Please try uploading again."),
    }

    # Needed so that Django doesn't treat this as a hidden input
    is_hidden = False

    def __init__(self, attrs=None):
        super().__init__(attrs)

    def input_name_for_path(self, name):
        """
        Given the name of the file input, return the name of the hidden
        input field that will store the file path.
        """
        return name + "-path"

    def input_name_for_filename(self, name):
        """
        Given the name of the file input, return the name of the hidden
        input field that will store the original uploaded file's filename.
        """
        return name + "-filename"

    def input_name_for_changed(self, name):
        """
        Given the name of the file input, return the name of the hidden
        input field that will store whether the file has changed.
        """
        return name + "-changed"

    def input_name_for_url(self, name):
        """
        Given the name of the file input, return the name of the hidden
        input field that will store the file URL.
        """
        return name + "-url"

    def input_name_for_token(self, name):
        """
        Given the name of the file input, return the name of the hidden
        input field that will store the security token.
        """
        return name + "-token"

    def get_context(self, name, value, attrs):
        """
        Build template context from normalized value dict.

        Maps the canonical data structure to template-friendly variables.
        No more defensive coding - we KNOW the structure is always consistent!
        """
        context = super().get_context(name, value, attrs)

        current = value["current"]
        initial = value["initial"]

        # Map to template context
        context["widget"].update({
            # Widget configuration
            "upload_view_name": self.upload_view_name,

            # Names of hidden inputs
            "input_name_for_path": self.input_name_for_path(name),
            "input_name_for_filename": self.input_name_for_filename(name),
            "input_name_for_url": self.input_name_for_url(name),
            "input_name_for_changed": self.input_name_for_changed(name),
            "input_name_for_token": self.input_name_for_token(name),

            # Translatable labels
            "choose_button_label": self.choose_button_label,
            "clear_button_label": self.clear_button_label,
            "reset_button_label": self.reset_button_label,
            "uploading_label": self.uploading_label,

            # Translatable error messages (for JavaScript)
            "error_messages": self.error_messages,

            # Initial file info (for reset functionality)
            "has_initial": value["has_initial"],
            "initial_path": initial["path"],
            "initial_filename": initial["filename"],
            "initial_url": initial["url"],

            # Current file info (for display and submission)
            "has_current_file": value["has_current"],
            "path_value": current["path"],
            "filename_value": current["filename"],
            "url_value": current["url"],
            "token_value": current["token"],
            "changed_value": "true" if value["changed"] else "false",
        })

        return context

    def use_required_attribute(self, initial):
        """
        Override Django's default behavior for the 'required' attribute when Widget.is_hidden is False.

        This method prevents Django from automatically adding the 'required' attribute to the
        HTML input element, even when the field is required.
        """
        return False

    def value_from_datadict(self, data, files, name):
        """
        Extract form POST data and return as flat dict.

        Returns a simple dict mapping the form field names to their values.
        Normalization happens later in bound_data().

        Note: The canonical 'name' input is the file input (type=file), which is
        cleared immediately by JavaScript after upload. We read the actual data
        from the suffixed hidden inputs.
        """
        return {
            "path": data.get(self.input_name_for_path(name), ""),
            "filename": data.get(self.input_name_for_filename(name), ""),
            "url": data.get(self.input_name_for_url(name), ""),
            "token": data.get(self.input_name_for_token(name), ""),
            "changed": (data.get(self.input_name_for_changed(name)) == "true"),
        }

    def value_omitted_from_data(self, data, files, name):
        """
        Check if widget data was omitted from the submitted form.

        Unlike Django's FileInput which checks 'files', our widget uses hidden inputs
        to store the file data. We check if the required hidden input (path) is present
        to determine if the widget participated in the form submission.
        """
        return self.input_name_for_path(name) not in data

    class Media:
        css = {
            'all': ('ajax_filefield/widget.css',)
        }
        js = ('ajax_filefield/widget.js',)
