__version__ = "1.2.0"

def main():
    from .main import main as _main
    return _main()