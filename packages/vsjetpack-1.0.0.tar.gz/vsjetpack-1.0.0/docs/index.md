---
hide:
  - navigation
  - toc
---

--8<-- "README.md"