# Default configuration files for various applications
