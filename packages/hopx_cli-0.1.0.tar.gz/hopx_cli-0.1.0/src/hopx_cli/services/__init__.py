"""Service layer for business logic and API interactions."""
