from .wup import Wup

__all__ = ['Wup']

DEFAULT_TICKET_NUMBER = -1

# https://fedlib.msstatic.com/fedbasic/huyabaselibs/taf-signal/taf-signal.global.0.0.15.prod.js