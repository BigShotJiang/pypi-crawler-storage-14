# Hyperparse

A simple and powerful parser for shell environment variables and command line arguments.

## Installation

```bash
pip install hyperparse
```

## Quick Start

```python
from hyperparse import parse_string

config = parse_string('lr=1e-4,batch=32,model={name:bert,layers:12}')

print(config.lr)           # 0.0001
print(config.batch)        # 32
print(config.model.name)   # 'bert'
```

## Supported Types

| Type | Example | Result |
|------|---------|--------|
| Integer | `a=1` | `1` |
| Negative | `a=-1` | `-1` |
| Float | `a=3.14` | `3.14` |
| Scientific | `a=1e-5` | `0.00001` |
| Boolean | `a=True` | `True` |
| None | `a=None` or `a` | `None` |
| String | `a=hello` | `'hello'` |
| List | `a=[1,2,3]` | `[1, 2, 3]` |
| Nested List | `a=[[1,2],[3,4]]` | `[[1, 2], [3, 4]]` |
| Dict | `a={x:1,y:2}` | `{'x': 1, 'y': 2}` |
| Nested | `a={x:[1,2],y:{z:3}}` | `{'x': [1, 2], 'y': {'z': 3}}` |

## Attribute Access

Parse results support both dict-style and attribute-style access:

```python
config = parse_string('a=1,b={x:2,y:3}')

# Dict style
config['a']      # 1
config['b']['x'] # 2

# Attribute style
config.a         # 1
config.b.x       # 2
```

## Check Key Existence

```python
config = parse_string('a=1,b=2,c=3')

# Check if all keys exist
config.hasall('a', 'b')      # True
config.hasall('a', 'x')      # False

# Check if any key exists
config.hasany('a', 'x')      # True
config.hasany('x', 'y')      # False
```

## Environment Variables

```bash
export usermode="lr=1e-4,batch=32,epochs=10"
python main.py
```

```python
from hyperparse import parse, reset_hyper

usermode, _ = parse("usermode")
print(usermode.lr)     # 0.0001
print(usermode.batch)  # 32
```

## Argparse Integration

```python
from hyperparse import parse, reset_hyper
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('--lr', type=float, default=0.01)
parser.add_argument('--batch', type=int, default=16)
args = parser.parse_args()

usermode, _ = parse("usermode")
reset_hyper(usermode, args)

print(args.lr)     # 0.0001 (overridden by env)
print(args.batch)  # 32 (overridden by env)
```

## Local Variables

```python
from hyperparse import parse, reset_hyper

lr = 0.01
batch = 16

usermode, _ = parse("usermode")
reset_hyper(usermode)

print(lr)     # 0.0001
print(batch)  # 32
```

## API Reference

### `parse_string(s)`
Parse a string into an AttrDict.

### `parse(name)`
Parse from environment variable or command line argument.

### `reset_hyper(hyper, pargs=None)`
Update argparse namespace or local variables with parsed values.

### `AttrDict`
Dict subclass with attribute access and helper methods:
- `.hasall(*keys)` - True if all keys exist
- `.hasany(*keys)` - True if any key exists

## License

MIT
