from vwsfriend.vwsfriend_base import main

if __name__ == '__main__':
    main()
