import * as wasm from "./nucleation_bg.wasm";
export * from "./nucleation_bg.js";
import { __wbg_set_wasm } from "./nucleation_bg.js";
__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
