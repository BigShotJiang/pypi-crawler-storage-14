This module is not compatible with cash rounding
