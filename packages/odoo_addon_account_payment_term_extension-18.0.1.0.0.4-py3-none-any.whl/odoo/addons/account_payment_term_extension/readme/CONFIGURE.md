To configure the Payment Terms and see the new options on the Payment
Term Lines, you need to:

1.  Go to the menu Invoicing \> Configuration \> Invoicing \> Payment
    Terms.

To use multiple payment days, define for each payment term line which
payment days apply, separated by spaces, commas or dashes. To use
holidays, insert the holiday and the date payment terms will be
postponed to.

To modify the type of delay options available in the payment terms, you need to:
1.  Go to the menu Invoicing \> Configuration \> Settings \> Payment
    Terms.
2. Choose an option from:
    - Days
    - Days and Weeks
    - Days and Months
    - Days, Weeks and Months
