Go to **Invoicing \> Customers \> Invoices** and edit any invoice or
create a new one.

Select any payment term and set a date in invoice.

You must see the due date based on this payment term.
