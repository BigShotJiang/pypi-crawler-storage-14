"""
Módulo para la sincronización de datos entre el sistema Libertador y Softseguros.
Gestiona la sincronización de clientes, solicitudes y notificaciones para diferentes inmobiliarias.

primero se ejecuta el endpoint request_a_one_day_range en un rango de fechas y para todos los
estados disponibles (State), estos registros se crean en base de datos, esto permite tener toda
la informacion completa en base de datos de todas las solicitudes, luego se utiliza el endpoint
data_unique para actualizar solicitudes pasadas que tenga un estado

"""

import copy
import os
from datetime import datetime
from typing import Any, List, Union

from dotenv import load_dotenv
from loguru import logger

from softseguros.api_libertador.api import DetailByDataFull, RequestDataUnique, ServiceAPILibertador
from softseguros.api_softseguros.api_softseguros import Observations, RequestsCreateCustomerSoftseguros, ServiceAPISoftSeguros
from src.database.config_db import session_castillo, session_estrella, session_livin, session_villacruz
from src.database.repository import Libertador, get_approved_records, get_records_with_state_postponed, insert_record, update_state_solicitud
from softseguros.notifier.notificaciones import shipment_message_customers_libertador

load_dotenv()

# phones = os.getenv("PHONES")
# phones = ast.literal_eval(phones)
phones = ["573165241659", "573013853937", "573006538383"]



def with_point(n: Union[int, float, str]) -> str:
    """
    Formatea un número con puntos como separador de miles.

    Args:
        n: Número a formatear (puede ser entero, decimal o string)

    Returns:
        str: Número formateado con puntos como separador de miles
    """
    return f"{int(n):,}".replace(",", ".")


class Company:
    name: str
    numero_inmobiliaria: str
    client_id: str
    client_secret: str
    username: str = os.getenv("USERNAME_SOFTSEGUROS", "")
    password: str = os.getenv("USERNAME_PASSWORD_SOFTSEGUROS", "")
    categories: str
    session: Any
    phone_numbers: List[str] = phones


class Estrella(Company):
    """
    Configuración específica para la inmobiliaria Estrella.

    Attributes:
        name: Identificador de la inmobiliaria
        numero_inmobiliaria: NIT de la inmobiliaria
        client_id: ID de cliente para API Libertador
        client_secret: Secreto de cliente para API Libertador
        categories: Categorías en Softseguros (47205: La Estrella, 47664: Común)
        session: Sesión de base de datos específica
    """

    name: str = "estrella"
    numero_inmobiliaria: str = "800018892"
    client_id: str = os.getenv("CLIENT_ID_ESTRELLA", "")
    client_secret: str = os.getenv("CLIENT_SECRET_ESTRELLA", "")
    categories: str = "47205,47664"
    session: Any = session_estrella


class Castillo(Company):
    """
    Configuración específica para la inmobiliaria Castillo.

    Attributes:
        name: Identificador de la inmobiliaria
        numero_inmobiliaria: NIT de la inmobiliaria
        client_id: ID de cliente para API Libertador
        client_secret: Secreto de cliente para API Libertador
        categories: Categorías en Softseguros (47203: Castillo, 47664: Común)
        session: Sesión de base de datos específica
    """

    name: str = "castillo"
    numero_inmobiliaria: str = "890930984"
    client_id: str = os.getenv("CLIENT_ID_CASTILLO", "")
    client_secret: str = os.getenv("CLIENT_SECRET_CASTILLO", "")
    categories: str = "47203,47664"
    session: Any = session_castillo


class Villacruz(Company):
    """
    Configuración específica para la inmobiliaria Villacruz.

    Attributes:
        name: Identificador de la inmobiliaria
        numero_inmobiliaria: NIT de la inmobiliaria
        client_id: ID de cliente para API Libertador
        client_secret: Secreto de cliente para API Libertador
        categories: Categorías en Softseguros (47202: Villacruz, 47664: Común)
        session: Sesión de base de datos específica
    """

    name: str = "villacruz"
    numero_inmobiliaria: str = "890918082"
    client_id: str = os.getenv("CLIENT_ID_VILLACRUZ", "")
    client_secret: str = os.getenv("CLIENT_SECRET_VILLACRUZ", "")
    categories: str = "47202,47664"
    session: Any = session_villacruz


class Livin(Company):
    """
    Configuración específica para la inmobiliaria Livin.

    Attributes:
        name: Identificador de la inmobiliaria
        numero_inmobiliaria: NIT de la inmobiliaria
        client_id: ID de cliente para API Libertador
        client_secret: Secreto de cliente para API Libertador
        categories: Categorías en Softseguros (47204: Livin, 47664: Común)
        session: Sesión de base de datos específica
    """

    name: str = "livin"
    numero_inmobiliaria: str = "900635562"
    client_id: str = os.getenv("CLIENT_ID_LIVIN", "")
    client_secret: str = os.getenv("CLIENT_SECRET_LIVIN", "")
    categories: str = "47204,47664"
    session: Any = session_livin


def synchronize_libertador_table_from_estrella_by_day() -> None:
    """
    Ejecuta la sincronización completa para la inmobiliaria Estrella.

    Este proceso incluye:
    1. Sincronización de datos diarios desde Libertador
    2. Actualización de solicitudes específicas
    3. Creación de clientes en Softseguros
    4. Notificación a asesores
    """
    logger.info("Iniciando sincronización para inmobiliaria Estrella")
    synchronize_libertador_table_by_day(company=Estrella)
    synchronize_libertador_table_by_solicitud(company=Estrella)
    result_create_customer_in_softseguros = create_customer_in_softseguros(company=Estrella)
    notify_advisor_softseguros(company=Estrella, data_customers=result_create_customer_in_softseguros)
    logger.info("Finalizada sincronización para inmobiliaria Estrella")


def synchronize_libertador_table_from_livin_by_day() -> None:
    """
    Ejecuta la sincronización completa para la inmobiliaria Livin.

    Este proceso incluye:
    1. Sincronización de datos diarios desde Libertador
    2. Actualización de solicitudes específicas
    3. Creación de clientes en Softseguros
    4. Notificación a asesores
    """
    logger.info("Iniciando sincronización para inmobiliaria Livin")
    synchronize_libertador_table_by_day(company=Livin)
    synchronize_libertador_table_by_solicitud(company=Livin)
    result_create_customer_in_softseguros = create_customer_in_softseguros(company=Livin)
    notify_advisor_softseguros(company=Livin, data_customers=result_create_customer_in_softseguros)
    logger.info("Finalizada sincronización para inmobiliaria Livin")


def synchronize_libertador_table_from_villacruz_by_day() -> None:
    """
    Ejecuta la sincronización completa para la inmobiliaria Villacruz.

    Este proceso incluye:
    1. Sincronización de datos diarios desde Libertador
    2. Actualización de solicitudes específicas
    3. Creación de clientes en Softseguros
    4. Notificación a asesores
    """
    logger.info("Iniciando sincronización para inmobiliaria Villacruz")
    synchronize_libertador_table_by_day(company=Villacruz)
    synchronize_libertador_table_by_solicitud(company=Villacruz)
    result_create_customer_in_softseguros = create_customer_in_softseguros(company=Villacruz)
    notify_advisor_softseguros(company=Villacruz, data_customers=result_create_customer_in_softseguros)
    logger.info("Finalizada sincronización para inmobiliaria Villacruz")


def synchronize_libertador_table_from_castillo_by_day() -> None:
    """
    Ejecuta la sincronización completa para la inmobiliaria Castillo.

    Este proceso incluye:
    1. Sincronización de datos diarios desde Libertador
    2. Actualización de solicitudes específicas
    3. Creación de clientes en Softseguros
    4. Notificación a asesores
    """
    logger.info("Iniciando sincronización para inmobiliaria Castillo")
    synchronize_libertador_table_by_day(company=Castillo)
    synchronize_libertador_table_by_solicitud(company=Castillo)
    result_create_customer_in_softseguros = create_customer_in_softseguros(company=Castillo)
    notify_advisor_softseguros(company=Castillo, data_customers=result_create_customer_in_softseguros)
    logger.info("Finalizada sincronización para inmobiliaria Castillo")


def synchronize_libertador_table_by_day(company: Company) -> None:
    """
    Sincroniza los datos de clientes desde Libertador a la base de datos local.

    Args:
        company: Instancia de Company con la configuración de la inmobiliaria

    Este proceso:
    1. Consulta las solicitudes del día en Libertador
    2. Filtra los clientes con tipo de identificación CC
    3. Actualiza o inserta los registros en la base de datos local
    """
    logger.info(f"Iniciando sincronización diaria para {company.name}")

    # Inicialización del servicio
    service_libertador = ServiceAPILibertador(client_id=company.client_id, client_secret=company.client_secret)

    # Consultar solicitudes por día
    result = service_libertador.request_a_one_day_range()

    customers: List[DetailByDataFull] = result.data
    if customers is None:
        logger.warning(f"No se encontraron clientes para sincronizar en {company.name}: {customers=}")
        return

    logger.info(f"Numero de customers para cargar a DB: {len(customers)}")

    # ACTUALIZAR REGISTROS EN DB
    for customer in customers:
        if customer.tipoIdentificacion == "CC":
            # + REGISTRAR EN BASE DE DATOS LIBERTADOR LAS SOLICITUDES
            record = {}
            record["solicitud"] = customer.solicitud
            record["fecha_radicacion"] = datetime.strptime(customer.fechaRadicacion, "%d/%m/%Y %H:%M:%S")
            record["fecha_resultado"] = datetime.strptime(customer.fechaResultado, "%d/%m/%Y %H:%M:%S")
            record["resultado"] = customer.estadoGeneral
            record["destino"] = customer.destinoInmueble
            record["tipo_persona"] = "Natural"
            record["ciudad"] = customer.ciudadInmueble
            record["direccion"] = customer.direccionInmueble
            record["numero_inmobiliaria"] = company.numero_inmobiliaria
            record["nombre_inquilino"] = customer.nombreInquilino
            record["numero_inquilino"] = customer.telefonoInquilino
            record["nombre_asesor"] = customer.nombreAsesor
            record["correo_asesor"] = customer.correoAsesor
            record["documento_inquilino"] = customer.identificacionInquilino
            record["canon"] = customer.canon
            record["correo"] = customer.correoInquilino
            record["fecha_expedicion"] = customer.fechaExpedicion
            record["ingresos"] = customer.ingresos

            for key, value in record.items():
                if value == "No Registra":
                    record[key]= None

            obj = Libertador(**record)
            insert_record(obj, company.session)
            logger.info(f"Solicitud: {customer.solicitud, customer.estadoGeneral} actualizada/insertada")


def synchronize_libertador_table_by_solicitud(company: Company) -> None:
    """
    Sincroniza el estado de las solicitudes aplazadas con Libertador.

    Args:
        company: Instancia de Company con la configuración de la inmobiliaria

    Este proceso:
    1. Obtiene todas las solicitudes con estado "APLAZADO-NUBE" o "APLAZADA"
    2. Consulta el estado actual en Libertador
    3. Actualiza a "APROBADA" si el código de resultado es "01"
    """
    logger.info(f"Iniciando sincronización de solicitudes aplazadas para {company.name}")

    # Inicialización del servicio
    service_libertador = ServiceAPILibertador(client_id=company.client_id, client_secret=company.client_secret)

    # Sincronización de solicitudes con estados ("APLAZADO-NUBE", "APLAZADA")
    records_db = get_records_with_state_postponed(company.session)
    logger.info(f"Número de solicitudes aplazadas para validar: {len(records_db)}")

    for record_db in records_db:
        logger.debug(f"Procesando solicitud: {record_db.solicitud}")
        if not record_db.solicitud:
            logger.warning("Encontrada solicitud sin número, omitiendo")
            continue

        results = service_libertador.data_unique(data=RequestDataUnique(solicitud=str(record_db.solicitud)))
        if not results.status:
            logger.warning(f"No se pudo obtener información de la solicitud {record_db.solicitud}")
            continue

        for record_api in results.data:
            if record_api.codigoResultado == "01":
                obj = copy.deepcopy(record_db)
                obj.resultado = "APROBADA"
                insert_record(obj, company.session)
                logger.info(f"Solicitud {obj.solicitud} actualizada a estado {obj.resultado}")


def create_customer_in_softseguros(company: Company) -> List[List[str]]:
    """
    Crea clientes en Softseguros a partir de las solicitudes aprobadas en la base de datos.

    Args:
        company: Instancia de Company con la configuración de la inmobiliaria

    Returns:
        List[List[str]]: Lista de clientes creados exitosamente, cada cliente es una lista con:
            [solicitud, documento_inquilino, nombre_inquilino, numero_inquilino]

    Este proceso:
    1. Obtiene todas las solicitudes aprobadas de la base de datos
    2. Para cada solicitud, calcula el valor comercial según el canon
    3. Crea el cliente en Softseguros con la información necesaria
    4. Registra el resultado de la creación
    """
    logger.info(f"Iniciando creación de clientes en Softseguros para {company.name}")
    api_softseguros = ServiceAPISoftSeguros(username=company.username, password=company.password)

    # Consultar todos los posibles clientes con solicitud aprobada en DB
    customer_db = get_approved_records(company.session)
    logger.info(f"Encontrados {len(customer_db)} clientes con solicitud aprobada")

    created_customer_result: List[List[str]] = []
    for cust_db in customer_db:
        if not cust_db.documento_inquilino:
            logger.warning(f"Cliente en solicitud {cust_db.solicitud} sin documento, omitiendo")
            continue

        fecha_expedicion = cust_db.fecha_expedicion
        if fecha_expedicion is None or fecha_expedicion == "No Registra":
            cust_db.fecha_expedicion = None
        else:
            if isinstance(fecha_expedicion, datetime):
                cust_db.fecha_expedicion= fecha_expedicion.date().strftime("%Y-%m-%d")
            elif isinstance(fecha_expedicion, str):
                cust_db.fecha_expedicion = datetime.fromisoformat(fecha_expedicion.replace("T", " ")).date().strftime("%Y-%m-%d")


        observations = Observations(canon=cust_db.canon, destinacion=cust_db.destino, asesor=cust_db.nombre_asesor, correoAsesor=cust_db.correo_asesor)
        obs = str(observations.model_dump(mode="json"))

        new_customer_softseguros = RequestsCreateCustomerSoftseguros(
            numero_documento=cust_db.documento_inquilino,
            nombres=cust_db.nombre_inquilino,
            direccion=cust_db.direccion,
            telefono=cust_db.numero_inquilino,
            celular=cust_db.numero_inquilino,
            email=cust_db.correo,
            observaciones=obs,
            ids_categorias=company.categories,
            ciudad=cust_db.ciudad,
            fecha_expedicion_cedula=cust_db.fecha_expedicion,
            ingreso_mensual=str(cust_db.ingresos),
        )

        logger.info(f"Inicia creacion en softseguros para el cliente: {cust_db.documento_inquilino=}")
        resp_create_customer = api_softseguros.create_customer(new_customer_softseguros)
        logger.info(f"Resultado de creacion en softseguros del cliente: {cust_db.documento_inquilino=}: {resp_create_customer=}")
        if resp_create_customer.get("status"):
            logger.info(f"Cliente {cust_db.documento_inquilino} creado exitosamente en Softseguros")
            logger.debug(f"Detalles del cliente creado: {new_customer_softseguros}")
            created_customer_result.append([cust_db.solicitud, cust_db.documento_inquilino, cust_db.nombre_inquilino, cust_db.numero_inquilino])
        else:
            logger.error(f"Error al crear cliente {cust_db.documento_inquilino} en Softseguros\nDetalles: {new_customer_softseguros}")

    logger.info(f"Proceso finalizado. {len(created_customer_result)} clientes creados en Softseguros")
    return created_customer_result


def notify_advisor_softseguros(company: Company, data_customers: List[List[str]]) -> None:
    """
    Notifica a los asesores sobre los nuevos clientes creados en Softseguros.

    Args:
        company: Instancia de Company con la configuración de la inmobiliaria
        data_customers: Lista de clientes creados, cada cliente es una lista con:
            [solicitud, documento_inquilino, nombre_inquilino, numero_inquilino]

    Este proceso:
    1. Envía mensajes a los asesores con la información de los clientes creados
    2. Actualiza el estado de las solicitudes a notificadas
    """
    logger.info(f"Iniciando notificación a asesores de {company.name}")
    logger.debug(f"Números de teléfono de asesores: {company.phone_numbers}")

    if not data_customers:
        logger.info("No hay clientes nuevos para notificar")
        return

    # Enviar notificaciones a los asesores
    shipment_message_customers_libertador(phone_advisers=company.phone_numbers, data_customers=data_customers, real_state=company.name)

    # Actualizar estado de las solicitudes
    for customer in data_customers:
        solicitud = customer[0]  # El primer elemento es el número de solicitud
        update_state_solicitud(solicitud, True, company.session)
        logger.debug(f"Actualizado estado de notificación para solicitud {solicitud}")

    logger.info(f"Completada notificación de {len(data_customers)} clientes a los asesores")


if __name__ == "__main__":
    username = os.getenv("USERNAME_SOFTSEGUROS")
    password = os.getenv("USERNAME_PASSWORD_SOFTSEGUROS")
    api_softseguros = ServiceAPISoftSeguros(username=username, password=password)

    # 3610548
    category_estrella = {"id": 47205, "nombre": "La Estrella", "color": "#28a187", "tipo": "cliente"}
    customer = {"canon": 1800000, "identificacionInquilino": "10072325404", "nombreInquilino": "Juan V", "direccionInmueble": "Direcciion prueba", "telefonoInquilino": "573103555748", "correoInquilino": "juan@gmail.com"}
    observations = Observations(canon=customer.get("canon"))
    new_customer_softseguros = RequestsCreateCustomerSoftseguros(
        numero_documento=customer.get("identificacionInquilino"),
        nombres=customer.get("nombreInquilino"),
        direccion=customer.get("direccionInmueble"),
        telefono=customer.get("telefonoInquilino"),
        celular=customer.get("telefonoInquilino"),
        email=customer.get("correoInquilino"),
        observations=observations,
        ids_categorias=str(category_estrella.get("id")),
    )

    resp_create_customer = api_softseguros.create_customer(new_customer_softseguros)



# para consultar
# 1039048054,
