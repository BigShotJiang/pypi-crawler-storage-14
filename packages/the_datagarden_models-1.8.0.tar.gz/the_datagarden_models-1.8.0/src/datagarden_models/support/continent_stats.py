from .country_stats import CountryStats


class ContinentStats(CountryStats):
	pass
