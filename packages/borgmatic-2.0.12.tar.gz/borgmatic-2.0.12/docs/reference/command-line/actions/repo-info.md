---
title: repo-info
eleventyNavigation:
  key: repo-info
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/repo-info.txt %}
```


## Related documentation

 * [How to inspect your backups](https://torsion.org/borgmatic/how-to/inspect-your-backups/)
