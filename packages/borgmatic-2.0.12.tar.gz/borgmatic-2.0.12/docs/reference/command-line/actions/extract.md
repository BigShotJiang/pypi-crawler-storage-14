---
title: extract
eleventyNavigation:
  key: extract
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/extract.txt %}
```


## Related documentation

 * [How to extract a backup](https://torsion.org/borgmatic/how-to/extract-a-backup/)
