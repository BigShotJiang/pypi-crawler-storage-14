---
title: export-tar
eleventyNavigation:
  key: export-tar
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/export-tar.txt %}
```
