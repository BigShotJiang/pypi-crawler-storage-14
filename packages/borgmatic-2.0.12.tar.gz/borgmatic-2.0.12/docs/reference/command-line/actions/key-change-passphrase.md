---
title: key change-passphrase
eleventyNavigation:
  key: key change-passphrase
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/key-change-passphrase.txt %}
```
