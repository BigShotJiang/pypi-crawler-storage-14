---
title: restore
eleventyNavigation:
  key: restore
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/restore.txt %}
```


## Related documentation

 * [Database restoration](https://torsion.org/borgmatic/how-to/backup-your-databases/#database-restoration)
