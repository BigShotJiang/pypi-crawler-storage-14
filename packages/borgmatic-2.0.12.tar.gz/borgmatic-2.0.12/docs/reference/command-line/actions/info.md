---
title: info
eleventyNavigation:
  key: info
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/info.txt %}
```


## Related documentation

 * [How to inspect your backups](https://torsion.org/borgmatic/how-to/inspect-your-backups/)
