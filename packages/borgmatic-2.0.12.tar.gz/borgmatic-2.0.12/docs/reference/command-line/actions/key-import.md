---
title: key import
eleventyNavigation:
  key: key import
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/key-import.txt %}
```
