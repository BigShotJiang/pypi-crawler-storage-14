---
title: list
eleventyNavigation:
  key: list
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/list.txt %}
```


## Related documentation

 * [How to inspect your backups](https://torsion.org/borgmatic/how-to/inspect-your-backups/)
