---
title: break-lock
eleventyNavigation:
  key: break-lock
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/break-lock.txt %}
```
