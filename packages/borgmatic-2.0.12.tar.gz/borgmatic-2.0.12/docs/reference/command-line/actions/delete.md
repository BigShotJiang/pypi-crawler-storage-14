---
title: delete
eleventyNavigation:
  key: delete
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/delete.txt %}
```
