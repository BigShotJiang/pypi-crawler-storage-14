---
title: repo-delete
eleventyNavigation:
  key: repo-delete
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/repo-delete.txt %}
```
