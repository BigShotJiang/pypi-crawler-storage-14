---
title: config generate
eleventyNavigation:
  key: config generate
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/config-generate.txt %}
```


## Related documentation

 * [Configuration](https://torsion.org/borgmatic/how-to/set-up-backups/#configuration)
