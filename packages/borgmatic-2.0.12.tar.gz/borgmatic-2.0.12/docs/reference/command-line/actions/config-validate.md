---
title: config validate
eleventyNavigation:
  key: config validate
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/config-validate.txt %}
```


## Related documentation

 * [Validation](https://torsion.org/borgmatic/how-to/set-up-backups/#validation)
