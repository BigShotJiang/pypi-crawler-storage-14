---
title: prune
eleventyNavigation:
  key: prune
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/prune.txt %}
```
