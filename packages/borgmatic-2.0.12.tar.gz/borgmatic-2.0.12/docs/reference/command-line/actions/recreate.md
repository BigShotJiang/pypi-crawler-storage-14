---
title: recreate
eleventyNavigation:
  key: recreate
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/recreate.txt %}
```
