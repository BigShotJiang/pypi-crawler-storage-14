---
title: repo-create
eleventyNavigation:
  key: repo-create
  parent: 🎬 Actions
---
```
{% include borgmatic/command-line/repo-create.txt %}
```


## Related documentation

 * [Repository creation](https://torsion.org/borgmatic/how-to/set-up-backups/#repository-creation)
