---
title: compact
eleventyNavigation:
  key: compact
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/compact.txt %}
```
