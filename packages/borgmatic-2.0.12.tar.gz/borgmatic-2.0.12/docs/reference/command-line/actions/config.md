---
title: config
eleventyNavigation:
  key: config
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/config.txt %}
```
