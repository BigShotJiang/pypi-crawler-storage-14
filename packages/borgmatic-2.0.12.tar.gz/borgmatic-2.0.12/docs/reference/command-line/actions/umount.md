---
title: umount
eleventyNavigation:
  key: umount
  parent: 🎬 Actions
---

```
{% include borgmatic/command-line/umount.txt %}
```


## Related documentation

 * [Mount a filesystem](https://torsion.org/borgmatic/how-to/extract-a-backup/#mount-a-filesystem)
