module.exports = function() {
    return {
        environment: process.env.NODE_ENV || "development"
    };
};
