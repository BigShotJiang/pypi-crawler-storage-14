* Thomas Binsfeld <thomas.binsfeld@acsone.eu>
* Raf Ven <raf.ven@dynapps.be>
* Andrea Stirpe <a.stirpe@onestein.nl>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
