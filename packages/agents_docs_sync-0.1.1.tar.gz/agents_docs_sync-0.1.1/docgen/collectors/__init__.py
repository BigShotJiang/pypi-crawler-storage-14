"""
プロジェクト情報収集モジュール
"""

from .project_info_collector import ProjectInfoCollector

__all__ = ["ProjectInfoCollector"]
