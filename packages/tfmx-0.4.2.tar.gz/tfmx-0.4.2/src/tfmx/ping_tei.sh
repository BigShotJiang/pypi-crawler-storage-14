curl 127.0.0.1:28888/embed \
    -X POST \
    -d '{"inputs":["What is Deep Learning?","现在的北京时间"]}' \
    -H 'Content-Type: application/json'