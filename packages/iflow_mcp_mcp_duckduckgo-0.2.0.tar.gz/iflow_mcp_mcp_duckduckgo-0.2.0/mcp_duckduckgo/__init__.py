"""DuckDuckGo search plugin for Model Context Protocol."""

__version__ = "0.2.0"

__all__ = [
    "__version__",
]
