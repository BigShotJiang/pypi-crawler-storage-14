"""
Test package for the MCP DuckDuckGo plugin.
"""
