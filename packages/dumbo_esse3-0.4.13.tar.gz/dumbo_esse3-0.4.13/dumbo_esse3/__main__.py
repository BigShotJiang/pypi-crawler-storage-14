#!/usr/bin/env python

from dumbo_esse3.cli import run_app

if __name__ == "__main__":
    run_app()
