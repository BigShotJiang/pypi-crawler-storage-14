import sys

from setuptools import setup

if sys.version_info < (3, 6):
    sys.exit("ERROR: delete-me-discord requires Python 3.6+")

setup()



