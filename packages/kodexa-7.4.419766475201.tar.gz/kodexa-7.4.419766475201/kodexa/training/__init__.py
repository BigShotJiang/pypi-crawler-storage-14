"""
Utilities for training actions using Kodexa
"""
