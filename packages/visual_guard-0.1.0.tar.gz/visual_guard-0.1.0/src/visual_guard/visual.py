import os
import time
from PIL import Image, ImageChops, ImageDraw
from io import BytesIO
from .logger import setup_logger

logger = setup_logger("visual_guard.visual")

class VisualTester:
    """
    Handles visual regression testing by comparing screenshots against baselines.
    Compatible with Selenium WebDriver (Web) and Appium (Mobile).
    """

    def __init__(self, baseline_dir="tests/baselines", snapshot_dir="tests/snapshots"):
        self.baseline_dir = baseline_dir
        self.snapshot_dir = snapshot_dir
        self.diff_dir = os.path.join(snapshot_dir, "diffs")
        
        os.makedirs(self.baseline_dir, exist_ok=True)
        os.makedirs(self.snapshot_dir, exist_ok=True)
        os.makedirs(self.diff_dir, exist_ok=True)

    def _process_image(self, image_data):
        """Converts input (path, bytes, WebElement) to PIL Image."""
        if isinstance(image_data, str):
            if os.path.exists(image_data):
                return Image.open(image_data).convert("RGB")
            else:
                raise FileNotFoundError(f"Image not found: {image_data}")
        elif isinstance(image_data, bytes):
            return Image.open(BytesIO(image_data)).convert("RGB")
        elif hasattr(image_data, "screenshot_as_png"): # Selenium WebElement
            png_data = image_data.screenshot_as_png
            return Image.open(BytesIO(png_data)).convert("RGB")
        elif hasattr(image_data, "get_screenshot_as_png"): # Selenium WebDriver
            png_data = image_data.get_screenshot_as_png()
            return Image.open(BytesIO(png_data)).convert("RGB")
        else:
            # Try to see if it's a base64 string directly
            try:
                import base64
                return Image.open(BytesIO(base64.b64decode(image_data))).convert("RGB")
            except:
                pass
            raise ValueError(f"Unsupported image format: {type(image_data)}. Provide file path, bytes, or Selenium element.")

    def _mask_regions(self, image, regions):
        """Draws black rectangles over excluded regions."""
        if not regions:
            return image
        
        masked_image = image.copy()
        draw = ImageDraw.Draw(masked_image)
        
        for region in regions:
            # Region format: (x, y, width, height)
            if len(region) == 4:
                x, y, w, h = region
                draw.rectangle([x, y, x + w, y + h], fill="black")
            else:
                logger.warning(f"Invalid region format: {region}. Expected (x, y, w, h).")
                
        return masked_image

    def crop_region(self, image_data, region):
        """Crops a specific region from the image."""
        image = self._process_image(image_data)
        x, y, w, h = region
        return image.crop((x, y, x + w, y + h))

    def assert_matches(self, image_data, name, threshold=0.1, exclude_regions=None):
        """
        Compares the provided image against the baseline.
        
        Args:
            image_data: The current screenshot (path, bytes, or WebElement).
            name: Unique name for the test case.
            threshold: Allowed pixel difference percentage (0.0 to 100.0).
            exclude_regions: List of (x, y, w, h) tuples to ignore.
            
        Returns:
            bool: True if matches (or new baseline created), False otherwise.
        """
        current_image = self._process_image(image_data)
        
        # Apply masking if needed
        if exclude_regions:
            current_image = self._mask_regions(current_image, exclude_regions)

        baseline_path = os.path.join(self.baseline_dir, f"{name}.png")
        snapshot_path = os.path.join(self.snapshot_dir, f"{name}.png")
        diff_path = os.path.join(self.diff_dir, f"{name}_diff.png")

        # Save current snapshot
        current_image.save(snapshot_path)

        # 1. First Run: Create Baseline
        if not os.path.exists(baseline_path):
            current_image.save(baseline_path)
            logger.info(f"Baseline created for '{name}' at {baseline_path}")
            return True

        # 2. Compare
        baseline_image = Image.open(baseline_path).convert("RGB")
        
        # Ensure dimensions match
        if current_image.size != baseline_image.size:
            logger.error(f"Image dimensions mismatch for '{name}': {current_image.size} vs {baseline_image.size}")
            # Resize baseline to match current (simple approach, or fail)
            # For strict testing, we should probably fail or resize current to baseline.
            # Let's resize current to match baseline for comparison sake if close? 
            # No, strict fail is better for visual regression.
            # But to generate a diff, we need same size.
            current_image = current_image.resize(baseline_image.size)

        # Calculate difference
        diff = ImageChops.difference(baseline_image, current_image)
        
        # Get bounding box of non-zero difference
        if diff.getbbox():
            # Calculate percentage difference
            # Convert to grayscale to count pixels
            diff_gray = diff.convert("L")
            # Count non-black pixels
            # This is slow for large images, but accurate.
            # Faster approach: histogram
            histogram = diff_gray.histogram()
            # histogram[0] is count of black (0) pixels (no diff)
            total_pixels = current_image.width * current_image.height
            matching_pixels = histogram[0]
            diff_pixels = total_pixels - matching_pixels
            diff_percent = (diff_pixels / total_pixels) * 100

            if diff_percent > threshold:
                logger.error(f"Visual check failed for '{name}'. Diff: {diff_percent:.2f}% (Threshold: {threshold}%)")
                
                # Generate visual diff (overlay)
                # We can just save the 'diff' image which shows the difference in color
                # Or blend them. Let's save the diff.
                diff.save(diff_path)
                logger.info(f"Diff image saved to {diff_path}")
                return False
            else:
                logger.info(f"Visual check passed for '{name}' (Diff: {diff_percent:.2f}% within threshold)")
                return True
        else:
            logger.info(f"Visual check passed for '{name}' (Perfect match)")
            return True
