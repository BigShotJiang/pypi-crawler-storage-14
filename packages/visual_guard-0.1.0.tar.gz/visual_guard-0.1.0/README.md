# Visual Guard

**Visual Guard** is a powerful Python library designed specifically for **Visual Regression Testing**. It allows you to automatically detect UI changes by comparing screenshots against approved baselines, ensuring your application looks perfect on every release.

## Key Features

- **Visual Comparison**: Pixel-perfect comparison of full pages or specific elements.
- **Region Masking**: Easily exclude dynamic content (like timestamps, ads, or carousels) to prevent flaky tests.
- **Visual Reporting**: Generates professional HTML reports with side-by-side views of Baseline, Actual, and Diff images.
- **Cross-Platform**: Works seamlessly with **Selenium WebDriver** (Web) and **Appium** (Mobile).

## Installation

```bash
pip install visual-guard
```

## Quick Start

### Web Automation

```python
from visual_guard import VisualTester
from selenium import webdriver

# 1. Setup Driver
driver = webdriver.Chrome()
driver.get("https://example.com")

# 2. Initialize Visual Guard
visual = VisualTester()

# 3. Compare Full Page
# First run creates the baseline. Subsequent runs compare against it.
visual.assert_matches(driver, "homepage")

# 4. Compare Specific Element
button = driver.find_element("id", "submit-btn")
visual.assert_matches(button, "submit_button")
```

### Mobile Automation (Appium)

```python
from visual_guard import VisualTester
from appium import webdriver

caps = {
    "platformName": "iOS",
    "app": "path/to/my.app",
    "automationName": "XCUITest"
}
driver = webdriver.Remote("http://localhost:4723/wd/hub", caps)

visual = VisualTester()
visual.assert_matches(driver, "mobile_dashboard")
```

### Region Masking

Ignore dynamic areas to keep tests stable:

```python
# Mask a region (x, y, width, height)
visual.assert_matches(driver, "dashboard", exclude_regions=[(100, 50, 200, 30)])
```

### Reporting

Generate a visual report to see exactly what changed:

```python
from visual_guard import SimpleReporter

reporter = SimpleReporter()
# ... add results ...
reporter.generate("visual_report.html")
```
