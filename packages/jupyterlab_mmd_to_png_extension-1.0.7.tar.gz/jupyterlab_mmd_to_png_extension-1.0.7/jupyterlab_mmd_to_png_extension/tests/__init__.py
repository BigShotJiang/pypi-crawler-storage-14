"""Python unit tests for jupyterlab_mmd_to_png_extension."""
