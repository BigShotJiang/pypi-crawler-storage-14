"""Variable-derivation helpers for NUDB pipelines."""

from .skoleaar import utd_skoleaar_slutt
