pytest_plugins = [
    "fixtures.fixture_test_repo",
    "fixtures.fixture_issue_1",
    "fixtures.fixture_issue_22",
]