from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.prompt import Confirm
from rich.rule import Rule

console = Console()


def log(msg: str) -> None:
    console.print(f"[bold cyan][setup][/bold cyan] {msg}")


def warn(msg: str) -> None:
    console.print(f"[bold yellow][setup WARNING][/bold yellow] {msg}")


def error(msg: str) -> None:
    console.print(f"[bold red][setup ERROR][/bold red] {msg}")


def section(title: str) -> None:
    console.print()
    console.print(Rule(f"[bold]{title}[/bold]"))


def ask_yes_no(
    question: str,
    *,
    default: bool = True,
    auto_yes: bool = False,
) -> bool:
    """
    Ask a yes/no question. If auto_yes is True, returns True without prompting.
    """
    if auto_yes:
        return True
    return Confirm.ask(question, default=default)
