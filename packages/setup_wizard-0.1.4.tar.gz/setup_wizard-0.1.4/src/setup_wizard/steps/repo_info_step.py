from __future__ import annotations

import subprocess

from ..prompts import log, warn, section
from ..health import record_step


def run_repo_info(auto_yes: bool = False) -> None:
    section("Repository info")
    try:
        root = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        warn("Not in a git repository (or git not installed).")
        record_step("repo_info", "skipped", "Not a git repo")
        return

    try:
        branch = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        branch = "unknown"

    try:
        remote = subprocess.check_output(
            ["git", "remote", "get-url", "origin"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        remote = "none"

    log(f"Repo root:  {root}")
    log(f"Branch:     {branch}")
    log(f"Remote URL: {remote}")
    record_step("repo_info", "done", f"{branch} @ {remote}")
