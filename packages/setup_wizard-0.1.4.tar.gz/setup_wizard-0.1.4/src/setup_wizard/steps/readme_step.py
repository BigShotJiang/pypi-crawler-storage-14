from __future__ import annotations

import subprocess
import webbrowser
from pathlib import Path
from typing import Dict, Any

from ..prompts import log, section, ask_yes_no
from ..health import record_step


def maybe_open_readme(cfg: Dict[str, Any], auto_yes: bool) -> None:
    section("README")

    readme_path = Path(cfg["paths"]["readme"])
    if not readme_path.exists():
        record_step("readme", "skipped", f"No {readme_path}")
        return

    log(
        f"I found a README at {readme_path}. You can start by reading it for "
        "more detailed information about this project."
    )

    if not ask_yes_no(
        f"Open {readme_path} now?",
        default=True,
        auto_yes=auto_yes,
    ):
        record_step("readme", "skipped", "User skipped")
        return

    # Try VSCode if available, fall back to default system handler
    try:
        subprocess.Popen(["code", str(readme_path)])
        log("Opened README in VSCode.")
    except Exception:
        webbrowser.open(readme_path.resolve().as_uri())
        log("Opened README with the default system application.")
    record_step("readme", "done", "Opened README")
