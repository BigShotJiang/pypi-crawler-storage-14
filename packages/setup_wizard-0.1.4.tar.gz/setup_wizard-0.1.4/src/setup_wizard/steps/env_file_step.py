from __future__ import annotations

import shutil
from pathlib import Path
from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step


def ensure_env_file(cfg: Dict[str, Any], auto_yes: bool) -> None:
    section("Step 3/3: Local .env configuration")

    env_path = Path(cfg["paths"]["env_file"])
    env_example_path = Path(cfg["paths"]["env_example"])

    log(
        "The application may rely on a .env file for local configuration.\n"
        "If it doesn't exist, I can create one for you, optionally copying from the example."
    )

    if not ask_yes_no(
        f"Ensure a .env file exists at {env_path}?",
        default=True,
        auto_yes=auto_yes,
    ):
        record_step(".env", "skipped", "User skipped")
        return

    if env_path.exists():
        log(f"{env_path} already exists; not modifying it.")
        record_step(".env", "done", "Existing .env")
        return

    try:
        if env_example_path.exists():
            log(f"Creating {env_path} from {env_example_path}...")
            shutil.copy(env_example_path, env_path)
        else:
            warn(f"No {env_example_path} found; creating minimal .env.")
            env_path.write_text("APP_ENV=dev\n", encoding="utf-8")
        log(f"Created {env_path}.")

        # Optional: offer to open it in editor
        if ask_yes_no(
            "Do you want to review/edit the .env file now?",
            default=False,
            auto_yes=False if auto_yes else False,
        ):
            # We don't try to be too clever: tell the user where it is
            log(f"Please open {env_path} in your editor to review values.")
        record_step(".env", "done", "Created .env")
    except Exception as e:
        warn(f"Failed to create .env: {e}")
        record_step(".env", "failed", str(e))
