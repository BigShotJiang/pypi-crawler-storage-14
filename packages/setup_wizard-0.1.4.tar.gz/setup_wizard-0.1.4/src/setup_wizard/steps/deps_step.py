from __future__ import annotations

from pathlib import Path
from typing import Dict, Any

from ..prompts import log, warn, section, ask_yes_no
from ..health import record_step
from .venv_step import run_in_venv


def install_dependencies(cfg: Dict[str, Any], auto_yes: bool) -> None:
    section("Step 2/3: Dependencies")

    req_path = Path(cfg["paths"]["requirements"])
    if not req_path.exists():
        warn(f"No {req_path} found; skipping dependency installation.")
        record_step("dependencies", "skipped", "No requirements file")
        return

    log(
        "I can install or update the Python packages listed in your requirements "
        "into the project virtualenv."
    )
    if not ask_yes_no(
        f"Install/upgrade dependencies from {req_path} now?",
        default=True,
        auto_yes=auto_yes,
    ):
        record_step("dependencies", "skipped", "User skipped")
        return

    try:
        run_in_venv(cfg, ["-m", "pip", "install", "-r", str(req_path)])
        record_step("dependencies", "done", f"Installed from {req_path}")
    except Exception as e:
        warn(f"Dependency installation failed: {e}")
        record_step("dependencies", "failed", str(e))
