# Pyarmor 9.2.0 (basic), 009672, 2025-12-01T22:58:14.903131
from .pyarmor_runtime import __pyarmor__
