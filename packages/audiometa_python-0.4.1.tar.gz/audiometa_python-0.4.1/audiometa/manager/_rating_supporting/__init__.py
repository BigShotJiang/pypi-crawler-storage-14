"""Rating-supporting metadata managers."""
