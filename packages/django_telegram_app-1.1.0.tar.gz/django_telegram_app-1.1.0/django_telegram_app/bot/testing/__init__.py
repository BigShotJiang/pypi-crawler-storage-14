"""Testing framework for Telegram bot app."""
