# OctoBot-Backtesting [1.9.8](https://github.com/Drakkar-Software/OctoBot-Backtesting/blob/master/CHANGELOG.md)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/aa0b156e99604b3c98923fffeaea6a49)](https://app.codacy.com/gh/Drakkar-Software/OctoBot-Backtesting?utm_source=github.com&utm_medium=referral&utm_content=Drakkar-Software/OctoBot-Backtesting&utm_campaign=Badge_Grade_Dashboard)
[![PyPI](https://img.shields.io/pypi/v/OctoBot-Backtesting.svg)](https://pypi.python.org/pypi/OctoBot-Backtesting/)
[![Coverage Status](https://coveralls.io/repos/github/Drakkar-Software/OctoBot-Backtesting/badge.svg?branch=master)](https://coveralls.io/github/Drakkar-Software/OctoBot-Backtesting?branch=master)
[![Github-Action-CI](https://github.com/Drakkar-Software/OctoBot-Backtesting/workflows/OctoBot-Backtesting-CI/badge.svg)](https://github.com/Drakkar-Software/OctoBot-Backtesting/actions)
[![Build Status](https://cloud.drone.io/api/badges/Drakkar-Software/OctoBot-Backtesting/status.svg)](https://cloud.drone.io/Drakkar-Software/OctoBot-Backtesting)

OctoBot backtesting engine package.