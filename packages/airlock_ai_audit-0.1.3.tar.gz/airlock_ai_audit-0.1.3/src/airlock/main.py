import os
import sys
import subprocess
import typer
from rich.console import Console
from rich.markdown import Markdown
from openai import OpenAI
from dotenv import load_dotenv, find_dotenv  # <--- FIXED IMPORT

# 1. Initialize the App
app = typer.Typer()
console = Console()

# --- DEBUGGING LOGIC ---
# Find the .env file
env_path = find_dotenv(usecwd=True) 
if env_path:
    load_dotenv(env_path, override=True)
else:
    load_dotenv(override=True)

# Helper Function to check key
def check_key():
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        # LOUD DEBUG PRINTS
        console.print(f"\n[bold yellow]🔍 DEBUG INFO:[/bold yellow]")
        console.print(f"📂 Current Folder: {os.getcwd()}")
        console.print(f"📄 .env File Found: {env_path if env_path else '❌ None found by find_dotenv'}")
        
        # Check what files are actually in the folder
        console.print(f"📂 Files here: {os.listdir(os.getcwd())}")
        
        console.print("\n[bold red]❌ Error:[/bold red] OPENAI_API_KEY is missing.")
        sys.exit(1)
    return key

# 2. Helper Function: Get the Diff
def get_git_diff(branch: str = None):
    try:
        if branch:
            command = ["git", "diff", branch]
        else:
            command = ["git", "diff", "--staged"]
            
        result = subprocess.run(
            command, 
            capture_output=True, 
            text=True, 
            check=True,
            encoding="utf-8"
        )
        return result.stdout
    except subprocess.CalledProcessError:
        console.print("[bold red]Error:[/bold red] Git command failed.")
        sys.exit(1)

# 3. Helper Function: Talk to AI
def analyze_with_ai(diff_text):
    api_key = check_key() # <--- CALL THE DEBUG CHECKER
    client = OpenAI(api_key=api_key)

    system_prompt = "You are a code reviewer. Summarize changes and find risks."
    user_prompt = f"Here is the git diff:\n\n{diff_text}"

    with console.status("[bold green]Consulting the AI agent...[/bold green]"):
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
        )
    return response.choices[0].message.content

# 4. The Command
@app.command()
def audit(branch: str = typer.Option(None, help="The branch to compare against")):
    """
    Run the AI audit.
    """
    console.print(f"[bold blue]🚀 Airlock v0.1.3: Starting Audit...[/bold blue]")
    
    diff = get_git_diff(branch)
    
    if not diff:
        console.print("[yellow]No changes found.[/yellow]")
        return

    try:
        summary = analyze_with_ai(diff)
        console.print("\n[bold]---------------- REPORT ----------------[/bold]\n")
        console.print(Markdown(summary))
        console.print("\n[bold]----------------------------------------[/bold]")

        if not typer.confirm("\n👮 Airlock: Do you want to proceed with this commit?"):
            console.print("[bold red]❌ Commit aborted by user.[/bold red]")
            sys.exit(1)

    except Exception as e:
        console.print(f"[bold red]An error occurred:[/bold red] {e}")
        sys.exit(1)

if __name__ == "__main__":
    app()