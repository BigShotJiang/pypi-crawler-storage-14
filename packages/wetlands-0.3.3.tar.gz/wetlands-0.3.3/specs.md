I am developing a python library which creates conda envs on demand ; and then can activate them, open a server in them which listens for execution orders. 

For example, a user can create an env for Stardist, another for Cellpose, and ask them to segment an image:

```python
from mylib import logger, EnvironmnetManager

# Optionnaly initialize the logger
def logCallback(line):
    # Do things with logs
    print(line)
logger.attachLogHandler(logCallback, logging.INFO)

# Create the env manager
em = EnvironmentManager()


# Create the envs:
stardistDeps = {"python": "3.10", "conda": ["tensorflow"], "pip": ["stardist"]}
cellposeDeps = {"python": "3.10", "pip": ["torch", "cellpose"]}
stardist = em.create("stardist", stardistDeps)
cellpose = em.create("cellpose", cellposeDeps)

# Launch the servers
stardist.launch()
cellpose.launch()

# Open an image
im = iio.imread('image.png')

# Segment it
# Blocking
segmentationResult1 = stardist.runScript("segment_image_stardist.py", im)

# Blocking
segmentationResult2 = cellpose.runScript("segment_image_cellpose.py", im)

# It is also possible to execute functions from a module:
# here we execute the segment_with_stadist function from the segment_image.py module
# Blocking
segmentationResult3 = stardist.execute("segment_image.py", "segment_with_stadist", im)


# Use a thread if you want it non blocking:
import concurrent.futures
with concurrent.futures.ThreadPoolExecutor() as executor:
    future = executor.submit(lambda: stardist.execute("segment_image.py", "segment_with_stadist", im))
    # Do things
    time.sleep(1)
    # When you want the result:
    segmentationResult4 = future.result()


# It is also possible to execute commands in the env (it activates the env before executing commands)

# Blocking
process = cellpose.executeCommands(["ls -a ."], wait=True)
for line in process.stdout
    gui.print(line)

# When wait=False, this is non blocking since process.wait() is not called. 
process = cellpose.executeCommands(["python -m http.server"], wait=False)
```


Internally, this is how the env execute functions:

```python
class Environment:
    
    ...

    @synchronized
    def launch(self, additionalActivateCommands: Commands = {}) -> None:
        """Launches a server listening for orders in the environment.

        Args:
                additionalActivateCommands: Platform-specific activation commands.
        """

        if self.launched():
            return

        moduleExecutorFile = "module_executor.py"
        moduleExecutorPath = Path(__file__).parent.resolve() / "_internal" / moduleExecutorFile

        debugArgs = f" --debugPort 0" if self.environmentManager.debug else ""
        commands = [
            f'python -u "{moduleExecutorPath}" {self.name} --wetlandsInstancePath {self.environmentManager.wetlandsInstancePath.resolve()}{debugArgs}'
        ]

        self.process = self.executeCommands(commands, additionalActivateCommands)

        if self.process.stdout is not None:
            try:
                for line in self.process.stdout:
                    logger.info(line.strip())
                    if self.environmentManager.debug:
                        if line.strip().startswith("Listening debug port "):
                            debugPort = int(line.strip().replace("Listening debug port ", ""))
                            self.environmentManager.registerEnvironment(self, debugPort, moduleExecutorPath)
                    if line.strip().startswith("Listening port "):
                        self.port = int(line.strip().replace("Listening port ", ""))
                        break
            except Exception as e:
                self.process.stdout.close()
                raise e

        if self.process.poll() is not None:
            if self.process.stdout is not None:
                self.process.stdout.close()
            raise Exception(f"Process exited with return code {self.process.returncode}.")
        if self.port is None:
            raise Exception(f"Could not find the server port.")
        self.connection = Client(("localhost", self.port))

    def _sendAndWait(self, payload: dict) -> Any:
        """Send a payload to the remote environment and wait for its response."""
        connection = self.connection
        if connection is None or connection.closed:
            raise ExecutionException("Connection not ready.")

        try:
            connection.send(payload)
            while message := connection.recv():
                action = message.get("action")
                if action == "execution finished":
                    logger.info(f"{payload.get('action')} finished")
                    return message.get("result")
                elif action == "error":
                    logger.error(message["exception"])
                    logger.error("Traceback:")
                    for line in message["traceback"]:
                        logger.error(line)
                    raise ExecutionException(message)
                else:
                    logger.warning(f"Got an unexpected message: {message}")

        except EOFError:
            logger.info("Connection closed gracefully by the peer.")
        except BrokenPipeError as e:
            logger.error(f"Broken pipe. The peer process might have terminated. Exception: {e}.")
        except OSError as e:
            if e.errno == 9:  # Bad file descriptor
                logger.error("Connection closed abruptly by the peer.")
            else:
                logger.error(f"Unexpected OSError: {e}")
                raise e
        return None

    @synchronized
    def execute(self, modulePath: str | Path, function: str, args: tuple = (), kwargs: dict[str, Any] = {}) -> Any:
        """Executes a function in the given module and return the result.
        Warning: all arguments (args and kwargs) must be picklable (since they will be send with [multiprocessing.connection.Connection.send](https://docs.python.org/3/library/multiprocessing.html#multiprocessing.connection.Connection.send))!

        Args:
                modulePath: the path to the module to import
                function: the name of the function to execute
                args: the argument list for the function
                kwargs: the keyword arguments for the function

        Returns:
                The result of the function if it is defined and the connection is opened ; None otherwise.
        Raises:
            OSError when raised by the communication.
        """
        payload = dict(
            action="execute",
            modulePath=str(modulePath),
            function=function,
            args=args,
            kwargs=kwargs,
        )
        return self._sendAndWait(payload)

    @synchronized
    def runScript(self, scriptPath: str | Path, args: tuple = (), run_name: str = "__main__") -> Any:
        """
        Runs a Python script remotely using runpy.run_path(), simulating
        'python script.py arg1 arg2 ...'

        Args:
            scriptPath: Path to the script to execute.
            args: List of arguments to pass (becomes sys.argv[1:] remotely).
            run_name: Value for runpy.run_path(run_name=...); defaults to "__main__".

        Returns:
            The resulting globals dict from the executed script, or None on failure.
        """
        payload = dict(
            action="run",
            scriptPath=str(scriptPath),
            args=args,
            run_name=run_name,
        )
        return self._sendAndWait(payload)
    
    def executeCommands(...):
        self.commandExecutor.executeCommands(...)

```

This is the execute CommandExecutor.executeCommands:

```python

class CommandExecutor:

    ...

    def executeCommands(
        self,
        commands: list[str],
        exitIfCommandError: bool = True,
        popenKwargs: dict[str, Any] = {},
        wait: bool = False,
        removePythonEnvVars: bool = True,
    ) -> subprocess.Popen:
        """Executes shell commands in a subprocess. Warning: does not wait for completion unless ``wait`` is True.

        Args:
                commands: List of shell commands to execute.
                exitIfCommandError: Whether to insert error checking after each command to make sure the whole command chain stops if an error occurs (otherwise the script will be executed entirely even when one command fails at the beginning).
                popenKwargs: Keyword arguments for subprocess.Popen() (see [Popen documentation](https://docs.python.org/3/library/subprocess.html#popen-constructor)). Defaults are: dict(stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, encoding="utf-8", errors="replace", bufsize=1).
                wait: Whether to wait for the process to complete before returning.
                removePythonEnvVars: Whether to remove PYTHONEXECUTABLE, PYTHONHOME and PYTHONPATH from the environment variables to avoid interference with conda/pixi environment activation.

        Returns:
                Subprocess handle for the executed commands.
        """
        import os

        commandsString = "\n\t\t".join(commands)
        logger.debug(f"Execute commands:\n\n\t\t{commandsString}\n")
        with tempfile.NamedTemporaryFile(
            dir=self.scriptsPath, suffix=".ps1" if self._isWindows() else ".sh", mode="w", delete=False
        ) as tmp:
            if exitIfCommandError:
                commands = self._insertCommandErrorChecks(commands)
            tmp.write("\n".join(commands))
            tmp.flush()
            tmp.close()
            executeFile = (
                [
                    "powershell",
                    "-WindowStyle",
                    "Hidden",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "ByPass",
                    "-File",
                    tmp.name,
                ]
                if self._isWindows()
                else ["/bin/bash", tmp.name]
            )
            if not self._isWindows():
                subprocess.run(["chmod", "u+x", tmp.name])
            logger.debug(f"Script file: {tmp.name}")

            if removePythonEnvVars:
                # Remove environment variables that can interfere with conda/pixi activation
                # These are typically set by the parent application (e.g., napari) and can cause
                # Python to use the wrong interpreter or libraries instead of the isolated environment
                env = popenKwargs.get("env")
                vars_to_remove = ["PYTHONEXECUTABLE", "PYTHONHOME", "PYTHONPATH"]
                # warn if mergedKwargs had an env variable which can cause issues with env activation
                if env is not None and any(var in vars_to_remove for var in env):
                    logger.warning(f"Removing variables {vars_to_remove} from env.")

                if env is None:
                    env = os.environ.copy()

                for var in vars_to_remove:
                    env.pop(var, None)
                popenKwargs["env"] = env

            defaultPopenKwargs = {
                "stdout": subprocess.PIPE,
                "stderr": subprocess.STDOUT,  # Merge stderr and stdout to handle all them with a single loop
                "stdin": subprocess.DEVNULL,  # Prevent the command to wait for input: instead we want to stop if this happens
                "encoding": "utf-8",
                "errors": "replace",  # Determines how encoding and decoding errors should be handled: replaces invalid characters with a placeholder (e.g., ? in ASCII).
                "bufsize": 1,  # 1 means line buffered
            }
            process = subprocess.Popen(executeFile, **(defaultPopenKwargs | popenKwargs))
            if wait:
                process.wait()
            return process
```

Here is how the server is launched:

```python
"""
This script launches a server inside a specified conda environment. It listens on a dynamically assigned
local port for incoming execution commands sent via a multiprocessing connection.

Clients can send instructions to:
- Dynamically import a Python module from a specified path and execute a function
- Run a Python script via runpy.run_path()
- Receive the result or any errors from the execution

Designed to be run within isolated environments for sandboxed execution of Python code modules.
"""

import sys
import logging
import threading
import traceback
import argparse
import runpy
from pathlib import Path
from importlib import import_module
from multiprocessing.connection import Listener, Connection

# Configure logging to both file and console
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s:%(process)d:%(name)s:%(message)s",
    handlers=[
        logging.FileHandler("environments.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)

port = 0
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        "Wetlands module executor",
        "Module executor is executed in a conda environment. It listens to a port and waits for execution orders. "
        "When instructed, it can import a module and execute one of its functions or run a script with runpy.",
    )
    parser.add_argument("environment", help="The name of the execution environment.")
    parser.add_argument("-p", "--port", help="The port to listen to.", default=0, type=int)
    parser.add_argument(
        "-dp", "--debugPort", help="The debugpy port to listen to. Only provide in debug mode.", default=None, type=int
    )
    parser.add_argument(
        "-wip",
        "--wetlandsInstancePath",
        help="Path to the folder containing the state of the wetlands instance to debug. Only provide in debug mode.",
        default=None,
        type=Path,
    )
    args = parser.parse_args()
    port = args.port
    logger = logging.getLogger(args.environment)
    if args.debugPort is not None:
        logger.setLevel(logging.DEBUG)
        logger.debug(f"Starting {args.environment} with python {sys.version}")
        import debugpy

        _, debugPort = debugpy.listen(args.debugPort)
        print(f"Listening debug port {debugPort}")
else:
    logger = logging.getLogger("module_executor")


def sendMessage(lock: threading.Lock, connection: Connection, message: dict):
    """Thread-safe sending of messages."""
    with lock:
        connection.send(message)


def handleExecutionError(lock: threading.Lock, connection: Connection, e: Exception):
    """Common error handling for any execution type."""
    logger.error(str(e))
    logger.error("Traceback:")
    tbftb = traceback.format_tb(e.__traceback__)
    for line in tbftb:
        logger.error(line)
    sys.stderr.flush()
    sendMessage(
        lock,
        connection,
        dict(
            action="error",
            exception=str(e),
            traceback=tbftb,
        ),
    )
    logger.debug("Error sent")


def executeFunction(message: dict):
    """Import a module and execute one of its functions."""
    modulePath = Path(message["modulePath"])
    logger.debug(f"Import module {modulePath}")
    sys.path.append(str(modulePath.parent))
    module = import_module(modulePath.stem)
    if not hasattr(module, message["function"]):
        raise Exception(f"Module {modulePath} has no function {message['function']}.")
    args = message.get("args", [])
    kwargs = message.get("kwargs", {})
    logger.info(f"Execute {message['modulePath']}:{message['function']}({args})")
    try:
        result = getattr(module, message["function"])(*args, **kwargs)
    except SystemExit as se:
        raise Exception(f"Function raised SystemExit: {se}\n\n")
    logger.info("Executed")
    return result


def runScript(message: dict):
    """Run a Python script via runpy.run_path(), simulating 'python script.py args...'."""
    scriptPath = message["scriptPath"]
    args = message.get("args", [])
    run_name = message.get("run_name", "__main__")

    sys.argv = [scriptPath] + list(args)
    logger.info(f"Running script {scriptPath} with args {args} and run_name={run_name}")
    runpy.run_path(scriptPath, run_name=run_name)
    logger.info("Script executed")
    return None


def executionWorker(lock: threading.Lock, connection: Connection, message: dict):
    """
    Worker function handling both 'execute' and 'run' actions.
    """
    try:
        action = message["action"]
        if action == "execute":
            result = executeFunction(message)
        elif action == "run":
            result = runScript(message)
        else:
            raise Exception(f"Unknown action: {action}")

        sendMessage(
            lock,
            connection,
            dict(
                action="execution finished",
                message=f"{action} completed",
                result=result,
            ),
        )
    except Exception as e:
        handleExecutionError(lock, connection, e)


def getMessage(connection: Connection) -> dict:
    logger.debug("Waiting for message...")
    return connection.recv()


def launchListener():
    """
    Launches a listener on a random available port on localhost.
    Waits for client connections and handles 'execute', 'run', or 'exit' messages.
    """
    lock = threading.Lock()
    with Listener(("localhost", port)) as listener:
        while True:
            print(f"Listening port {listener.address[1]}")
            with listener.accept() as connection:
                logger.debug(f"Connection accepted {listener.address}")
                message = ""
                try:
                    while message := getMessage(connection):
                        logger.debug(f"Got message: {message}")

                        if message["action"] in ("execute", "run"):
                            logger.debug(f"Launch thread for action {message['action']}")
                            thread = threading.Thread(
                                target=executionWorker,
                                args=(lock, connection, message),
                            )
                            thread.start()

                        elif message["action"] == "exit":
                            logger.info("exit")
                            sendMessage(lock, connection, dict(action="exited"))
                            listener.close()
                            return
                except Exception as e:
                    handleExecutionError(lock, connection, e)


if __name__ == "__main__":
    launchListener()

logger.debug("Exit")


```


Now, I am thinking about the best solution to retrieve logs in all cases (execute, runScripts and executeCommands), in the blocking and non-blocking cases.
I am also wondering whether execute and runScript should remain blocking in all cases, or if I should add an arg to make them non blocking. 
As we have seen, using Thread is a way to make them non blocking. But 

I am thinking about different solutions.


### Solution 1

All functions (execute, runScript and executeCommands) have a log_callback argument, a callback which is called for each new line:

```python
def processStdOut(line):
    gui.print(line)

process = cellpose.executeCommands(["ls -a .", "code-server"], log_callback=processStdOut)
```

This is very simple. Is there any drawback with this solution?


### Solution 2

In the Environment class, "logs" is a generator which yeilds a line as soon as it arrives:

```python

def processStdOut(gui):
    for ling in cellpose.logs:
        gui.print(line)

threading.Thread(target=processStdOut, args=[gui]).start()
process = cellpose.executeCommands(["python -m http.server"], wait=False)

```

It is more complicated. More importantly, it is not clear how the logs corresponds to this execution only, and not previous ones.

### Solution 3

In the Environment class, "logging_queue" is a queue filled with the process output:

```python

def processStdOut(environment, stdout_file):
    while True:
        line = environment.logging_queue.get()
        if line is None:
            break
        gui.print(line)

threading.Thread(target=processStdOut, args=[cellpose, gui]).start()
process = cellpose.executeCommands(["python -m http.server"], wait=False)

```

It is more complicated. And same thing, the queue must be cleared before each execution. 
To me, it seems odd to have a logging_queue which only corresponds to the last execution.


### Solution 4

All functions return a ExecutionResult which contain both the result and the logs

```python


class ExecutionResult:
    def __init__(self):
        self.result = None
        self.logs = threading.Queue()
        self.process = None
        self._lock = threading.Lock()  # For thread-safe log appending?

    def _addLog(self, line: str):
        """Called by execution mechanism to append a log"""
        self.logs.put(line)

# Use it:
result: ExecutionResult = cellpose.executeCommands(["python -m http.server"], wait=False)

def processStdOut(result, gui):
    while True:
        line = result.logs.get()
        if line is None:
            break
        gui.print(line)

threading.Thread(target=processStdOut, args=[result, gui]).start()

result.process.wait()

```
This is ok, but more complicated than a simple callback.

And this requires to make the execute and runScript functions non blocking, otherwise we cannot get the logs during the execution:
```python

import concurrent.futures
with concurrent.futures.ThreadPoolExecutor() as executor:
    future = executor.submit(lambda: stardist.execute("segment_image.py", "segment_with_stadist", im))
    # Do things: but we have no access to the results.logs here!
    time.sleep(1)
    # You need to get the results to get the logs
    result: ExecutionResult = future.result()
    result.logs
```

If I add a `wait` arg to the execute and runScript functions it is fine:

```python

result: ExecutionResult = stardist.execute("segment_image.py", "segment_with_stadist", im, wait=False)

def processStdOut(result, gui):
    while True:
        line = result.logs.get()
        if line is None:
            break
        gui.print(line)

threading.Thread(target=processStdOut, args=[result, gui]).start()

```
but this changes how my lib works.

### Solution 5

A totally different implementation.


The execute, runScripts and executeCommands functions could return a task like so:

```python

# Non blocking
task = stardist.execute("segment_image.py", "segment_with_stadist", im)

def task_listener(event):
    match event.responseType:
        case ResponseType.UPDATE:
            gui.print(f"Progress {task.current}/{task.maximum}")
        case ResponseType.COMPLETION:
            numer = task.outputs["numer"]
            denom = task.outputs["denom"]
            ratio = numer / denom
            gui.print(f"Task complete. Result: {numer}/{denom} =~ {ratio}");
        case ResponseType.CANCELATION:
            gui.print("Task canceled")
        case ResponseType.FAILURE:
            gui.print(f"Task failed: {task.error}")

task.listen(task_listener)

task.start()
sleep(1)
if not task.status.is_finished():
    # Task is taking too long; request a cancelation.
    task.cancel()

task.wait_for()
```


The last solution is nice because it handles all cases. But it is a bit more complicated to use than the callback solution.

Note: the user do not necessarily want to log things per execution. He might want to do it, but maybe not. He can use logger.attachLogHandler() to handle all logs.
So the simple solution might be good enough.

Which solution do you think is the best?

For each solution, give the pros and cons.

Then, forget about everything I said and propose your ultimate API for this library.



---

I want to refactor how the logging is implemented in Wetlands. 

The EnvironmentManager.executeCommands(), ExternalEnvironment.launch(), ExternalEnvironment.execute() and ExternalEnvironment.runScript() all should take a log_callback argument enabling to handle logs, for each new line:

```python
def processServerStdOut(line):
    gui.print(line)

process = server_environment.executeCommands(["python -m http.server"], log_callback=processServerStdOut)


def processGlobalStdOut(line):
    gui.print(line)

process = cellpose_environment.launch(log_callback=processGlobalStdOut)


def processSegmentationStdOut(line):
    gui.print(line)

cellpose_environment.runScript("segmentation.py", (image), log_callback=processSegmentationStdOut)
# or cellpose_environment.execute("segmentation.py", "segmentation", (image), log_callback=processSegmentationStdOut)

# etc...

```

The importModule method in environment.py must be updated.

The executeCommands function will launch a thread (daemon=True) to read stdout and call the callbacks if any (using a thread lock).
The launch function will pass the global log callback. 
The execute and runScript log_callback will log only the logs of their execution, not before after (per execution callback).
There cannot be mutliple execution at the same time.

There is 2 solutions: 
- the thread (created in executeCommands) calls all callbacks from a list (of 2 callbacks max: the global one, and the per execution one). This means the execution and runScript functions must have a way append their callback to the list.
- the thread have a single callback. The launch function gives executeCommand() a special callback defined in ExternalEnvironemnt which: calls the user global callback, and calls the per execution callback.

The second solution is better.

So, in command_executor.py ; add the log_callback which launchs a thread to call the given callback. Do not change the getOutput() and executeCommandsAndGetOutput() functions ; this part of the API does not change. 

In external_environment.py ; remove the loggingQueue and logThread which will not be used anymore. Replace by the global callback which will call the per-execution callback if any.

Do not modify internal_environment.py since the logs happens in the main thread there.

Before doing this:
1. Carefully read the code base to understand and implement this solution, think hard and make a nice plan before implementing your solution.
2. Write the tests for this new API.
3. Implement the solution so that the tests pass.
4. Update the documentation and examples with the new changes.




Since the library executes the `log_callback` on a **background thread**, users using a GUI (like PyQt, PySide, or Tkinter) **cannot** simply update their widgets inside that callback. Doing so will crash the application or cause random freezing.

Here are examples for the two most common Python GUI frameworks.

### The Golden Rule
> "The `log_callback` is called from a background thread. You must **signal** the main thread to update the GUI. Do not modify widgets directly inside the callback."

---

### 1. If the user uses PyQt or PySide (Most Common)
Qt has a built-in "Signal/Slot" mechanism which is thread-safe. The user should create a Signal, connect it to their widget, and pass the **signal's emit function** as the callback.

**User Code Example:**

```python
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtWidgets import QTextEdit, QApplication

# 1. Create a bridge class (Signals must be defined on QObjects)
class LogBridge(QObject):
    new_log = pyqtSignal(str)

app = QApplication([])
console = QTextEdit()
bridge = LogBridge()

# 2. Connect the signal to the widget's update method
# (Qt automatically handles the thread context switch here)
bridge.new_log.connect(console.append)

# 3. Pass the 'emit' method to your library
# When the library calls this on the bg thread, Qt puts the event 
# onto the main thread's event loop.
stardist.execute(
    "script.py", 
    "run", 
    im, 
    log_callback=bridge.new_log.emit  # <--- The Magic Link
)
```

### 2. If the user uses Tkinter
Tkinter does not have built-in signals. The standard Pythonic way to handle this is using a `queue.Queue`. The library pushes to the queue, and the GUI periodically checks it.

**User Code Example:**

```python
import tkinter as tk
import queue

root = tk.Tk()
text_area = tk.Text(root)
text_area.pack()

# 1. Create a thread-safe queue
log_queue = queue.Queue()

# 2. Define the callback that puts data into the queue
def my_log_callback(line):
    log_queue.put(line)

# 3. Create a poller function on the main thread
def process_log_queue():
    while not log_queue.empty():
        line = log_queue.get_nowait()
        text_area.insert(tk.END, line + "\n")
        text_area.see(tk.END) # Scroll to bottom
    
    # Check again in 100ms
    root.after(100, process_log_queue)

# Start polling
process_log_queue()

# 4. Pass the callback to your library
# (Note: stardist.execute must be run in a thread itself if using Tkinter, 
# otherwise it blocks the GUI entirely)
import threading
threading.Thread(target=lambda: stardist.execute(..., log_callback=my_log_callback)).start()

root.mainloop()
```

### 3. If the user just wants to use `print`
If the user is running a GUI but also wants to see logs in the terminal/console (stdout), `print` is **thread-safe** in Python. They can do this directly:

```python
# This is safe even from a background thread
stardist.execute(..., log_callback=print)
```

### Summary for your Documentation

You don't need to change your library code. You just need to add a "Integration with GUIs" section to your docstring or README:

> **Warning for GUI Developers:**
> The `log_callback` is executed on a background thread. If you are updating a GUI (e.g., PyQt, Tkinter), you must dispatch the update to the main thread.
> *   **PyQt/PySide:** Use `Signal.emit` as the callback.
> *   **Tkinter:** Use a `queue.Queue` and poll it using `root.after()`.



# Use python logging for logs in Wetlands

Read the @getting_started.py, @environement_manager.py, @external_environment, @environement.py, @module_executor.py and @command_executor.py to understand Wetlands and how the logging is managed.

I want to change how logs are handled by Wetlands.
I wonder if using the python logging module would be a good fit (instead of the ExternalEnvironment.loggingQueue for example).
For now, the logs from the EnvironmentManager.create() function are not captured / printed in real time. This is a problem: the user does not know what happens during env creation.
I am thinking of having a log class extending logging.Logger.
This class emits special log levels: global (from general executeCommands() ), environment (from ExternalEnvironment.launch() ), or execution logs (from ExternalEnvironment.execute() and runScript() ). 

The tricky part is that: when the process is launched in the CommandExecutor.executeCommands, the process is returned. The ExternalEnvironment.launch() needs to parse the stdout to extract the connection port. But the user might want to read stdout for other reasons as well, likely in another thread. And it is important that by default, all stdout from all command executions are logged into a file. I guess the best is that CommandExecutor is responsible of reading stdout, give the lines to a logger which can then be used by the internal Wetlands classes and the user. But I don't know if it's the best option.

Think hard and make a nice logging API proposal. Do not make code changes yet.



