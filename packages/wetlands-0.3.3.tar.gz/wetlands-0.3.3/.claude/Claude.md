# Claude Code Memory

## Testing Workflow

### Running Tests with UV
Use `uv run pytest <test_file>` to run tests for this project.

**Important:** Do NOT run `tests/test_wetlands.py` as it is an integration test that creates real conda environments and is very slow. The user will run it manually.

