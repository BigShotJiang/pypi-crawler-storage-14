# Wetlands Logging System Implementation Plan

**Status**: Planning Phase
**Date Created**: 2024-11-25
**Objective**: Redesign Wetlands logging to provide real-time, context-aware, thread-safe log handling

---

## Executive Summary

Redesign the Wetlands logging architecture to:
1. **Emit logs in real-time** during environment creation (currently blocks until completion)
2. **Eliminate stdout reading conflicts** (currently multiple threads try to read from same pipe)
3. **Add log context tracking** (distinguish global vs environment vs execution logs)
4. **Support user callbacks and filtering** (allow users to subscribe to specific log types)
5. **Maintain thread safety** without complexity

**Core Innovation**: `ProcessLogger` class that manages all subprocess stdout reading, allowing multiple subscribers without conflicts.

---

## Current Codebase Architecture

### Files to Understand

#### 1. **logger.py** (`src/wetlands/logger.py`)
- **Current state**: Simple wrapper around Python's logging module
- **Responsibilities**:
  - Global `_logger` instance
  - File + console output setup
  - `attachLogHandler()` for custom callbacks
  - `setLogLevel()` and `setLogFilePath()`
- **Limitations**:
  - No context tracking (can't tell which env/execution a log came from)
  - `attachLogHandler()` uses basicConfig which is called once - doesn't support dynamic logging
  - No real-time streaming during long operations

#### 2. **environment_manager.py** (`src/wetlands/environment_manager.py`)
- **Line 461**: `self.commandExecutor.executeCommandsAndGetOutput(createEnvCommands)`
  - **Problem**: Synchronous call that blocks until all output is read
  - Logs only visible AFTER environment creation completes
  - User sees no progress during conda env creation (can take 5+ minutes)
- **Line 77-78**: Sets log file path during init
  - Good: Centralized logging config point

#### 3. **external_environment.py** (`src/wetlands/external_environment.py`)
- **Line 43-59**: `logOutput()` method
  - Runs in separate thread (line 107)
  - **Problem**: Reads stdout line-by-line from process.stdout
  - **Conflict**: Can't coexist with other stdout readers
- **Line 62-108**: `launch()` method
  - **Problem**: Also reads process.stdout directly (line 85) to extract port number
  - **Conflict**: Competes with `logOutput()` thread for stdout access
  - When one thread reads a line, the other can't read it
  - Line buffering issues when multiple readers exist
- **Line 41**: `self.loggingQueue = queue.Queue()`
  - **Current use**: `logOutput()` puts lines here (line 53)
  - **Problem**: Designed to buffer output but not used for port parsing or user subscriptions

#### 4. **command_executor.py** (`src/wetlands/_internal/command_executor.py`)
- **Line 74-110**: `getOutput()` method
  - Reads process.stdout line-by-line (line 97)
  - Optionally logs each line (line 101)
  - **Problem**: Synchronous reading - blocks until process completes
- **Line 192-210**: `executeCommandsAndGetOutput()`
  - Calls `executeCommands()` then `getOutput()`
  - **Problem**: No streaming - output invisible until process finishes
  - Used by `EnvironmentManager.create()` → no real-time env creation logs
- **Line 112-190**: `executeCommands()`
  - Creates subprocess with line-buffered stdout
  - Sets up default Popen kwargs (line 179-186)
  - Returns process without waiting
  - **Current workflow**: Caller must call `getOutput()` to read stdout

#### 5. **module_executor.py** (`src/wetlands/_internal/module_executor.py`)
- **Line 24-31**: Logging setup inside the environment
  - Uses basicConfig with FileHandler and StreamHandler
  - **Note**: This is inside the subprocess, separate from main logging
- **Line 155-163**: `launchListener()` prints "Listening port" to stdout
  - This is what `ExternalEnvironment.launch()` parses (external_environment.py:91)
  - Must remain as print() not logger, since it's the protocol
- **Line 102, 107, 118, 120**: Logs to logger (structured)
- **Line 163**: Also prints to stdout (protocol)

#### 6. **environment.py** (`src/wetlands/environment.py`)
- Base class for environments
- `executeCommands()` delegates to environmentManager
- Not relevant for logging changes

---

## Problem Analysis

### Problem 1: Real-time Logging Gap During Environment Creation

**When**: `EnvironmentManager.create()` executes conda installation commands
**Current flow**:
1. `create()` calls `commandExecutor.executeCommandsAndGetOutput(createEnvCommands)` (line 461)
2. `executeCommandsAndGetOutput()` creates process, then calls `getOutput()` (blocking)
3. `getOutput()` reads ALL output in a loop until process.wait() completes
4. Result: User sees nothing until environment is fully created

**User experience**: Hanging for 5+ minutes with no feedback

**Root cause**: Synchronous stdout reading in `getOutput()`

---

### Problem 2: Multiple Stdout Readers Conflict

**When**: `ExternalEnvironment.launch()` is called
**Current flow**:
1. `launch()` creates process and reads stdout to find port (line 85)
2. Inside the loop: checks each line for "Listening port " (line 91)
3. Meanwhile: `logOutput()` thread also tries to read from process.stdout (line 48)
4. **Conflict**: Process.stdout is a file object - only one reader can consume lines
5. When one thread reads a line, the other thread doesn't see it
6. Result: Race condition, missing logs, buffering issues

**Root cause**: Two independent readers on same stream

---

### Problem 3: No Log Context/Source Tracking

**Current state**: All logs are flat strings
```
logger.info(line.strip())  # No way to know source
```

**Missing information**:
- Is this a global operation, environment creation, or execution?
- Which environment? Which function?
- Should user callbacks filter these logs?

**Root cause**: Python logging records don't include Wetlands-specific metadata

---

### Problem 4: User Callback Limitations

**Current**: `attachLogHandler()` (logger.py:94-98)
```python
def attachLogHandler(log: Callable[[str], None], logLevel=logging.INFO):
    logger.setLevel(logLevel)
    ch = CustomHandler(log)
    ch.setLevel(logLevel)
    logger.addHandler(ch)
```

**Issues**:
- Only receives formatted string, not LogRecord
- Can't filter by log source (would need to parse strings)
- User can't easily subscribe to just environment creation or just one execution
- No context information available

---

## Proposed Solution Architecture

### Core Concept: ProcessLogger (Central Stdout Reader)

**Key Innovation**: Single background thread reads process.stdout once. All consumers (logger, port parser, user callbacks) subscribe to events instead of competing for stdout.

```
Process stdout
     ↓
ProcessLogger (thread-safe reader)
     ↓
     ├→ Logger (with context tags)
     ├→ Port Parser (for ExternalEnvironment.launch)
     └→ User Callbacks (subscriptions)
```

### Components to Create

#### 1. `ProcessLogger` class (new file: `src/wetlands/_internal/process_logger.py`)

Responsibilities:
- Spawn background thread to read process.stdout
- Emit `LogRecord` objects with context to Python's logging system
- Allow subscriptions for specific line processing (e.g., port parsing)
- Handle thread safety

```python
class ProcessLogger:
    def __init__(self, process, log_context):
        """
        process: subprocess.Popen
        log_context: dict with {"log_source": "global|environment|execution", ...}
        """
        self.process = process
        self.log_context = log_context
        self._subscribers = []  # callbacks for raw lines
        self._reader_thread = None

    def start_reading(self):
        """Spawn reader thread."""
        self._reader_thread = threading.Thread(
            target=self._read_stdout,
            daemon=True
        )
        self._reader_thread.start()

    def subscribe(self, callback):
        """Register callback(line, context) for each line."""
        self._subscribers.append(callback)

    def _read_stdout(self):
        """Read stdout line by line, emit to logger and subscribers."""
        if self.process.stdout is None:
            return
        try:
            for line in self.process.stdout:
                line = line.strip()

                # Emit to Python logging with context
                logger.info(
                    line,
                    extra={
                        "log_source": self.log_context.get("log_source"),
                        "env_name": self.log_context.get("env_name"),
                        "func_name": self.log_context.get("func_name"),
                        "stage": self.log_context.get("stage"),
                    }
                )

                # Notify subscribers
                for callback in self._subscribers:
                    try:
                        callback(line, self.log_context)
                    except Exception as e:
                        logger.error(f"Subscriber error: {e}")
        except Exception as e:
            logger.error(f"ProcessLogger reading error: {e}")
        finally:
            if self.process.stdout:
                self.process.stdout.close()
            self.process.wait()
```

#### 2. `WetlandsLogger` class (modify `src/wetlands/logger.py`)

Extend Python's Logger with convenience methods:

```python
class WetlandsLogger(logging.Logger):
    def log_global(self, msg, **kwargs):
        """Log from global/manager context."""
        self.info(msg, extra={"log_source": "global", **kwargs})

    def log_environment(self, msg, env_name, stage=None, **kwargs):
        """Log from environment creation/launch."""
        self.info(msg, extra={
            "log_source": "environment",
            "env_name": env_name,
            "stage": stage,
            **kwargs
        })

    def log_execution(self, msg, env_name, func_name=None, **kwargs):
        """Log from function/script execution."""
        self.info(msg, extra={
            "log_source": "execution",
            "env_name": env_name,
            "func_name": func_name,
            **kwargs
        })

# Replace root logger
logging.setLoggerClass(WetlandsLogger)
logger = logging.getLogger("wetlands")
```

---

## Implementation Phases

### Phase 1: Foundation (2-3 hours)
- [ ] Create `ProcessLogger` class in `_internal/process_logger.py`
- [ ] Extend `WetlandsLogger` in `logger.py`
- [ ] Add log level constants (`LOG_SOURCE_*`)
- [ ] Write unit tests for ProcessLogger threading

**Files to modify**:
- Create: `src/wetlands/_internal/process_logger.py`
- Modify: `src/wetlands/logger.py`

**Tests to write**:
- `tests/test_process_logger.py` - threading, subscribing, context propagation

---

### Phase 2: CommandExecutor Integration (2-3 hours)
- [ ] Modify `CommandExecutor.executeCommands()` to use ProcessLogger
- [ ] Add `log_context` parameter to `executeCommands()`
- [ ] Remove synchronous stdout reading from `getOutput()`
- [ ] Update `executeCommandsAndGetOutput()` to handle async reading

**Files to modify**:
- `src/wetlands/_internal/command_executor.py`

**Breaking changes**:
- `executeCommands()` no longer waits for process by default
- `getOutput()` may need refactoring since stdout is now read by ProcessLogger

**Backwards compatibility**:
- Keep `executeCommandsAndGetOutput()` but underlying behavior changes
- Should be transparent to users if tested properly

---

### Phase 3: EnvironmentManager Updates (2-3 hours)
- [ ] Update `EnvironmentManager.create()` to pass log_context to CommandExecutor
- [ ] Add `logger.log_global()` and `logger.log_environment()` calls
- [ ] Ensure real-time logging during env creation

**Files to modify**:
- `src/wetlands/environment_manager.py` (line 443-461)

**Result**: Users see progress during env creation

---

### Phase 4: ExternalEnvironment Refactoring (3-4 hours)
- [ ] Remove old `logOutput()` method
- [ ] Refactor `launch()` to use ProcessLogger with subscription for port parsing
- [ ] Add `logger.log_environment()` calls to launch flow
- [ ] Thread-safe port extraction

**Files to modify**:
- `src/wetlands/external_environment.py` (lines 43-108)

**Key change**:
```python
# OLD: try to read stdout for port
for line in self.process.stdout:
    if line.startswith("Listening port "):
        self.port = int(line.split()[-1])
        break

# NEW: subscribe to ProcessLogger
port_found = threading.Event()
def parse_port(line, context):
    if line.startswith("Listening port "):
        self.port = int(line.split()[-1])
        port_found.set()

process_logger.subscribe(parse_port)
port_found.wait(timeout=30)  # Non-blocking!
```

---

### Phase 5: User-Facing API (1-2 hours)
- [ ] Document filtering by log_source in logger.py
- [ ] Add example handlers for file, GUI, analytics
- [ ] Create `@contextmanager` for per-execution logging
- [ ] Update docstrings

**Files to create/modify**:
- Create: `examples/logging_examples.py` (comprehensive examples)
- Modify: `src/wetlands/logger.py` (docstrings and helpers)

---

### Phase 6: Testing & Polish (3-4 hours)
- [ ] Integration tests for real-time logging during env creation
- [ ] Tests for port parsing with ProcessLogger
- [ ] Test multiple subscribers
- [ ] Test GUI handler example
- [ ] Test per-execution file logging
- [ ] Performance testing (ensure logging doesn't slow things down)
- [ ] Documentation and README updates

---

## Files to Read/Understand

### Must Read (Already Done - See Context Below)
- ✅ `examples/getting_started.py` - Usage patterns
- ✅ `src/wetlands/environment_manager.py` - Entry points, create()
- ✅ `src/wetlands/external_environment.py` - Process management, stdout reading
- ✅ `src/wetlands/logger.py` - Current logging system
- ✅ `src/wetlands/_internal/command_executor.py` - Command execution
- ✅ `src/wetlands/_internal/module_executor.py` - Inside-environment logging
- ✅ `src/wetlands/environment.py` - Base class

### Should Read
- [ ] `src/wetlands/internal_environment.py` - For completeness
- [ ] `src/wetlands/_internal/dependency_manager.py` - Might use logging
- [ ] `tests/test_*.py` - To understand testing patterns

---

## Key Design Decisions

### 1. ProcessLogger vs Global Reader Thread
**Decision**: Each process gets its own ProcessLogger instance
**Rationale**:
- Isolates context (each process has its own log context)
- Multiple processes can run simultaneously without conflicts
- Easier to test in isolation

### 2. Logging Levels: "log_source" as extra field vs Custom Level
**Decision**: Use Python's `logging.extra` field for context
**Rationale**:
- Compatible with existing logging ecosystem
- Users can filter/format using standard filters
- Easier than creating custom log levels
- Clear separation: level=INFO/WARNING/ERROR, source=global/environment/execution

### 3. Backwards Compatibility
**Decision**: Keep existing logger API, add new methods
**Rationale**:
- `logger.info("message")` still works (backwards compatible)
- New `logger.log_environment()` methods are optional convenience
- Existing code doesn't break

### 4. Port Parsing in launch()
**Decision**: Use subscription callback instead of competing stdout read
**Rationale**:
- Thread-safe: no race conditions
- Maintains real-time logging
- Port parser doesn't block stdout reading
- Cleaner separation of concerns

---

## Testing Strategy

### Unit Tests
```python
# tests/test_process_logger.py
def test_process_logger_reads_stdout():
    """Verify ProcessLogger reads subprocess output."""

def test_process_logger_subscribers():
    """Verify subscribers receive lines."""

def test_process_logger_context_propagation():
    """Verify log context passed correctly."""

def test_process_logger_thread_safety():
    """Verify thread safety with multiple subscribers."""
```

### Integration Tests
```python
# tests/test_logging_integration.py
def test_environment_creation_real_time_logging():
    """Verify logs appear during env.create()."""

def test_launch_port_parsing():
    """Verify port parsing doesn't block logging."""

def test_execution_logging_context():
    """Verify execution logs have correct context."""

def test_user_callback_receives_logs():
    """Verify user callbacks work."""
```

### Manual Testing
- Run `examples/getting_started.py` and verify console output in real-time
- Create environment and check `wetlands.log` has continuous updates
- Test GUI example with real environment creation

---

## Current Code Context

### ExternalEnvironment.logOutput() (lines 43-59)
```python
def logOutput(self) -> None:
    """Logs output from the subprocess."""
    if self.process is None or self.process.stdout is None:
        return
    try:
        for line in iter(self.process.stdout.readline, ""):
            logger.info(line.strip())
            self.loggingQueue.put(line.strip())
    except Exception as e:
        logger.error(f"Exception in logging thread: {e}")
        self.loggingQueue.put(f"Exception in logging thread: {e}")
    finally:
        self.loggingQueue.put(None)
    return
```
**To be replaced by**: ProcessLogger with context tags

### ExternalEnvironment.launch() (lines 62-108)
```python
def launch(self, ...):
    ...
    if self.process.stdout is not None:
        try:
            for line in self.process.stdout:  # ← PROBLEM: Competes with logOutput()
                logger.info(line.strip())
                if self.environmentManager.debug:
                    if line.strip().startswith("Listening debug port "):
                        debugPort = int(...)
                        self.environmentManager.registerEnvironment(...)
                if line.strip().startswith("Listening port "):  # ← Port parsing
                    self.port = int(line.strip().replace("Listening port ", ""))
                    break
```
**To be replaced by**: ProcessLogger with subscribe callback for port parsing

### EnvironmentManager.create() (lines 384-462)
```python
def create(self, name, dependencies=None, ...):
    ...
    # Line 461: Synchronous call blocks until env creation completes
    self.commandExecutor.executeCommandsAndGetOutput(createEnvCommands)
    return self.environments[name]
```
**To be enhanced with**: ProcessLogger passed to CommandExecutor with `log_context={"log_source": "environment", "env_name": name}`

---

## Example Usage After Implementation

### For Users: Real-time Environment Creation
```python
env_manager = EnvironmentManager()
print("Creating environment... (logs appear in real-time)")
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
# Output visible as env creation progresses, not after!
```

### For Users: GUI Integration
```python
gui = LogViewerGUI()
attachLogHandler(gui.log_callback)
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
# All logs appear in GUI in real-time
```

### For Users: Per-Execution File Logging
```python
@contextmanager
def capture_execution_logs(env_name, func_name, file_path):
    handler = logging.FileHandler(file_path)
    handler.addFilter(lambda r:
        r.extra.get("log_source") == "execution" and
        r.extra.get("env_name") == env_name
    )
    logger.addHandler(handler)
    try:
        yield
    finally:
        logger.removeHandler(handler)

with capture_execution_logs("cellpose", "segment", "segment.log"):
    env.execute("segment.py", "segment")
```

---

## Success Criteria

- [ ] Environment creation logs appear in real-time (not blocking)
- [ ] No race conditions between port parsing and logging
- [ ] Users can filter logs by source (global/environment/execution)
- [ ] User callbacks receive complete log information
- [ ] Existing code doesn't break (backwards compatible)
- [ ] All tests pass
- [ ] Documentation complete with examples
- [ ] Performance: logging doesn't measurably slow down operations

---

## Notes

### Threading Considerations
- ProcessLogger runs reader thread as daemon
- Main process exit doesn't hang waiting for reader
- Reader thread handles exceptions gracefully
- Lock-free design using subscribers pattern (not queues)

### Backwards Compatibility
- Old code: `logger.info("message")` still works
- New code: `logger.log_environment("message", env_name="cellpose")`
- Existing `attachLogHandler()` still works but receives context in extra

### Future Enhancements (Not in Scope)
- Structured logging (JSON output)
- Log rotation policies
- Remote logging backends
- Machine-readable error formats
- Log aggregation across multiple wetlands instances

---

## Restart Instructions

To resume this task:

1. **Understand the problem**: Read "Problem Analysis" section (line ~89)
2. **Review the solution**: Read "Proposed Solution Architecture" (line ~120)
3. **Start implementation**: Begin with Phase 1 (line ~180)
4. **Reference current state**: See "Current Code Context" (line ~280)
5. **Check success criteria**: Line ~370

**Current status**: All planning done, ready to implement Phase 1.

