# Wetlands Logging Solution: Architecture & Examples

**Purpose**: Reference guide for the proposed logging architecture and user-facing examples

---

## Table of Contents
1. [Solution Overview](#solution-overview)
2. [Architecture Diagram](#architecture-diagram)
3. [Core Components](#core-components)
4. [User Examples](#user-examples)
5. [Implementation API Reference](#implementation-api-reference)

---

## Solution Overview

### The Problem (In 30 seconds)

**Current Issues**:
1. Users don't see logs during environment creation (5+ minute wait with no feedback)
2. Multiple threads compete for process stdout, causing race conditions
3. No way to distinguish which environment or execution a log came from
4. Users can't easily subscribe to specific log types

**Root Cause**: Synchronous stdout reading + multiple independent readers on same pipe

### The Solution

**Central idea**: One `ProcessLogger` per subprocess reads stdout once in background thread, emits logs with context tags, allows multiple subscribers.

```
Before (Problem):
  CommandExecutor → blocks reading stdout
  ExternalEnvironment → also tries to read stdout (race condition)
  User → sees no logs until complete

After (Solution):
  ProcessLogger → reads stdout in background thread once
    ├→ Logger (emits with context: global/environment/execution)
    ├→ Port Parser (callback for port extraction)
    ├→ User Callbacks (subscriptions for custom handling)
    └→ File Handler (all logs to file automatically)
```

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    Wetlands Application                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  EnvironmentManager.create()                                    │
│        ↓                                                         │
│  CommandExecutor.executeCommands(commands, log_context={...})   │
│        ↓                                                         │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Subprocess (conda install, etc.)                        │   │
│  │  stdout: "Solving environment..."                        │   │
│  │  stdout: "Installing numpy..."                           │   │
│  │  stdout: "Done!"                                         │   │
│  └────────────────┬─────────────────────────────────────────┘   │
│                   │                                             │
│                   ↓                                             │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │          ProcessLogger (background thread)               │   │
│  │  • Reads stdout line-by-line (non-blocking)            │   │
│  │  • Adds context: {log_source, env_name, stage, ...}    │   │
│  │  • Notifies all subscribers                            │   │
│  └────────────────┬─────────────────────────────────────────┘   │
│                   │                                             │
│        ┌──────────┼──────────┬──────────┬──────────┐             │
│        ↓          ↓          ↓          ↓          ↓             │
│   ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐       │
│   │Logger  │ │Port    │ │File    │ │GUI     │ │Custom  │       │
│   │(emit)  │ │Parser  │ │Handler │ │Handler │ │Handler │       │
│   │        │ │(find   │ │        │ │        │ │        │       │
│   │        │ │port)   │ │        │ │        │ │        │       │
│   └────────┘ └────────┘ └────────┘ └────────┘ └────────┘       │
│        │          │          │          │          │            │
│        └──────────┴──────────┴──────────┴──────────┘            │
│                   ↓                                             │
│   Logs with context available to all destinations              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. ProcessLogger Class

**File**: `src/wetlands/_internal/process_logger.py` (NEW)

**Responsibility**: Thread-safe central stdout reader for subprocess

```python
class ProcessLogger:
    """Manages subprocess stdout reading and distribution to subscribers."""

    def __init__(self, process: subprocess.Popen, log_context: dict):
        """
        Args:
            process: The subprocess.Popen object
            log_context: Context dict like {"log_source": "environment", "env_name": "cellpose"}
        """
        self.process = process
        self.log_context = log_context
        self._subscribers = []  # List of callback functions
        self._reader_thread = None

    def start_reading(self):
        """Start background thread to read process stdout."""
        self._reader_thread = threading.Thread(
            target=self._read_stdout,
            daemon=True
        )
        self._reader_thread.start()

    def subscribe(self, callback: Callable[[str, dict], None]):
        """
        Register callback for each line.

        Args:
            callback: Function(line: str, context: dict) called for each line
        """
        self._subscribers.append(callback)

    def join(self, timeout=None):
        """Wait for reader thread to complete."""
        if self._reader_thread:
            self._reader_thread.join(timeout)

    def _read_stdout(self):
        """Background thread: read stdout and emit logs."""
        if self.process.stdout is None:
            return
        try:
            for line in self.process.stdout:
                line = line.strip()
                if not line:
                    continue

                # Emit to Python logging with context
                logger.info(
                    line,
                    extra={
                        "log_source": self.log_context.get("log_source"),
                        "env_name": self.log_context.get("env_name"),
                        "call_target": self.log_context.get("call_target"),
                        "stage": self.log_context.get("stage"),
                    }
                )

                # Notify subscribers
                for callback in self._subscribers:
                    try:
                        callback(line, self.log_context)
                    except Exception as e:
                        logger.error(f"Subscriber error: {e}")

        except Exception as e:
            logger.error(f"ProcessLogger reading error: {e}")
        finally:
            if self.process.stdout:
                self.process.stdout.close()
            self.process.wait()
```

### 2. WetlandsLogger Class

**File**: `src/wetlands/logger.py` (MODIFY)

**Responsibility**: Extend logging.Logger with Wetlands-specific methods

```python
import logging

# Define log sources as constants
LOG_SOURCE_GLOBAL = "global"
LOG_SOURCE_ENVIRONMENT = "environment"
LOG_SOURCE_EXECUTION = "execution"

class WetlandsLogger(logging.Logger):
    """Logger with built-in support for Wetlands log sources."""

    def log_global(self, msg, **kwargs):
        """Log from global/manager context."""
        self.info(msg, extra={
            "log_source": LOG_SOURCE_GLOBAL,
            **kwargs
        })

    def log_environment(self, msg, env_name, stage=None, **kwargs):
        """
        Log from environment creation/launch.

        Args:
            msg: Log message
            env_name: Name of the environment
            stage: Optional stage (e.g., "create", "launch", "install")
        """
        self.info(msg, extra={
            "log_source": LOG_SOURCE_ENVIRONMENT,
            "env_name": env_name,
            "stage": stage,
            **kwargs
        })

    def log_execution(self, msg, env_name, call_target=None, **kwargs):
        """
        Log from function/script execution.

        Args:
            msg: Log message
            env_name: Name of the environment
            call_target: Name of the function being executed
        """
        self.info(msg, extra={
            "log_source": LOG_SOURCE_EXECUTION,
            "env_name": env_name,
            "call_target": call_target,
            **kwargs
        })

# Set WetlandsLogger as the logger class
logging.setLoggerClass(WetlandsLogger)
logger: WetlandsLogger = logging.getLogger("wetlands")
```

### 3. Log Context Dict Format

Passed through the system to track log source:

```python
# Global operation
log_context = {
    "log_source": "global",
}

# Environment creation
log_context = {
    "log_source": "environment",
    "env_name": "cellpose",
    "stage": "install",  # "create", "install", "launch", etc.
}

# Function execution
log_context = {
    "log_source": "execution",
    "env_name": "cellpose",
    "call_target": "segmentation.py", # can be a script name alone, or a script name with a function as in segmentation.py:segment
}
```

---

## User Examples

### Example 1: GUI Integration (Real-time Log Viewer)

**Use case**: Display all Wetlands logs in a GUI window as they happen

```python
from pathlib import Path
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger, attachLogHandler
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
import logging

class LogViewerGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Wetlands Monitor")
        self.root.geometry("800x600")

        self.text_widget = ScrolledText(self.root, height=25, width=100)
        self.text_widget.pack(fill="both", expand=True)

        # Start button
        button = tk.Button(self.root, text="Create Cellpose Env", command=self.create_env)
        button.pack()

    def log_callback(self, line: str):
        """Called for each log record."""
        self.text_widget.insert(tk.END, line + "\n")
        self.text_widget.see(tk.END)  # Auto-scroll
        self.text_widget.update()  # Refresh GUI

    def create_env(self):
        """Create environment (logs appear in real-time in GUI)."""
        env_manager = EnvironmentManager()
        self.log_callback("=" * 60)
        self.log_callback("Creating cellpose environment...")
        self.log_callback("=" * 60)

        # All logs go to GUI callback
        env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})

        self.log_callback("Environment created successfully!")
        self.log_callback("Launching environment...")

        env.launch()

        self.log_callback("Environment launched and ready!")

    def run(self):
        # Attach GUI callback to logger
        attachLogHandler(self.log_callback)

        self.root.mainloop()

if __name__ == "__main__":
    gui = LogViewerGUI()
    gui.run()
```

**Output in GUI (in real-time)**:
```
============================================================
Creating cellpose environment...
============================================================
[2024-11-25 10:30:15] Solving environment
[2024-11-25 10:30:20] Installing numpy==1.24.0
[2024-11-25 10:30:35] Installing scipy==1.11.0
[2024-11-25 10:30:50] Installing cellpose==3.1.0
[2024-11-25 10:31:00] Solving environment completed
Environment created successfully!
Launching environment...
[2024-11-25 10:31:05] Starting module executor
[2024-11-25 10:31:10] Listening port 12345
Environment launched and ready!
```

---

### Example 2: Per-Execution File Logging

**Use case**: Capture logs from ONE `env.execute()` call to a separate file

```python
from pathlib import Path
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger
import logging
from contextlib import contextmanager

@contextmanager
def capture_execution_logs(env_name: str, call_target: str, output_file: Path):
    """Context manager to capture execution logs to a file."""

    # Create file handler
    handler = logging.FileHandler(output_file)
    handler.setFormatter(
        logging.Formatter(
            '%(asctime)s [%(levelname)s] %(message)s'
        )
    )

    # Only pass execution logs from this specific env/function
    def filter_logs(record: logging.LogRecord) -> bool:
        extra = getattr(record, 'extra', {})
        return (
            extra.get("log_source") == "execution" and
            extra.get("env_name") == env_name and
            extra.get("call_target") == call_target
        )

    handler.addFilter(filter_logs)
    logger.addHandler(handler)

    try:
        yield handler
    finally:
        logger.removeHandler(handler)
        handler.close()

# Usage
env_manager = EnvironmentManager()
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
env.launch()

# Capture logs from the segment function to a file
with capture_execution_logs("cellpose", "segment", Path("segment_execution.log")):
    result = env.execute("segment_module.py", "segment", args=(imagePath, outputPath))

print(f"Segment execution logs saved to segment_execution.log")

# Output file:
# 2024-11-25 10:31:10 [INFO] Execute segment_module.py:segment()
# 2024-11-25 10:31:11 [INFO] Loading model...
# 2024-11-25 10:31:15 [INFO] Processing image...
# 2024-11-25 10:31:45 [INFO] Segmentation complete
# 2024-11-25 10:31:46 [INFO] Executed
```

---

### Example 3: Custom Callback - Simple Line Processing

**Use case**: Process each log line with custom logic (parsing, analytics, filtering)

```python
from pathlib import Path
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger, attachLogHandler
import logging

class LogAnalyzer:
    def __init__(self):
        self.error_count = 0
        self.warning_count = 0
        self.install_packages = []

    def on_log(self, record: logging.LogRecord):
        """Process each log record."""
        message = record.getMessage()
        level = record.levelname
        source = getattr(record, 'extra', {}).get("log_source", "?")

        # Count errors and warnings
        if level == "ERROR":
            self.error_count += 1
        elif level == "WARNING":
            self.warning_count += 1

        # Extract installed packages from environment logs
        if source == "environment" and "Installing" in message:
            package = message.split("Installing ")[-1].split(" ")[0]
            self.install_packages.append(package)

        # Print with custom formatting
        emoji_map = {
            "global": "📋",
            "environment": "🔧",
            "execution": "▶️ ",
        }
        emoji = emoji_map.get(source, "ℹ️ ")
        print(f"{emoji} {message}")

    def print_summary(self):
        print("\n" + "=" * 60)
        print(f"Errors: {self.error_count}")
        print(f"Warnings: {self.warning_count}")
        print(f"Packages installed: {', '.join(self.install_packages)}")
        print("=" * 60)

# Use it
analyzer = LogAnalyzer()
attachLogHandler(analyzer.on_log)

env_manager = EnvironmentManager()
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
env.launch()
result = env.execute("script.py", "main")

analyzer.print_summary()

# Output:
# 📋 Creating environment...
# 🔧 Solving environment
# 🔧 Installing numpy-1.24.0
# 🔧 Installing scipy-1.11.0
# 🔧 Installing cellpose-3.1.0
# ▶️  Starting execution
# ▶️  Execution completed
# ============================================================
# Errors: 0
# Warnings: 0
# Packages installed: numpy, scipy, cellpose
# ============================================================
```

---

### Example 4: Advanced - Filter Logs by Source

**Use case**: Route different log types to different handlers (environment logs to file, execution logs to console, errors to email)

```python
from pathlib import Path
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger
import logging

# Create different handlers for different log sources
env_handler = logging.FileHandler("environment_creation.log")
exec_handler = logging.FileHandler("execution.log")
error_handler = logging.FileHandler("errors.log")

# Setup formatters
formatter = logging.Formatter('%(asctime)s - %(message)s')
env_handler.setFormatter(formatter)
exec_handler.setFormatter(formatter)
error_handler.setFormatter(formatter)

# Create filters
def filter_environment(record):
    return getattr(record, 'extra', {}).get("log_source") == "environment"

def filter_execution(record):
    return getattr(record, 'extra', {}).get("log_source") == "execution"

def filter_errors(record):
    return record.levelname in ("ERROR", "CRITICAL")

env_handler.addFilter(filter_environment)
exec_handler.addFilter(filter_execution)
error_handler.addFilter(filter_errors)

# Add to logger
logger.addHandler(env_handler)
logger.addHandler(exec_handler)
logger.addHandler(error_handler)

# Now logs are automatically routed!
env_manager = EnvironmentManager()
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})  # → environment_creation.log
env.launch()
result = env.execute("script.py", "main")  # → execution.log
# Any errors → errors.log

print("Logs saved to:")
print("  - environment_creation.log")
print("  - execution.log")
print("  - errors.log")
```

---

### Example 5: Context Manager for Execution Logging

**Use case**: Temporarily capture all logs from a block of code

```python
from pathlib import Path
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger
import logging
from contextlib import contextmanager

@contextmanager
def log_to_file(filepath: Path, level=logging.INFO, source_filter=None):
    """Context manager: temporarily log to a file."""

    handler = logging.FileHandler(filepath)
    handler.setLevel(level)
    handler.setFormatter(
        logging.Formatter('%(asctime)s [%(levelname)s] %(message)s')
    )

    if source_filter:
        handler.addFilter(source_filter)

    logger.addHandler(handler)

    try:
        yield
    finally:
        logger.removeHandler(handler)
        handler.close()

# Usage: capture environment creation to file
env_manager = EnvironmentManager()

with log_to_file(Path("env_creation.log")):
    env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
    env.launch()

print("Environment creation logged to env_creation.log")

# Usage: capture only errors to file
def error_filter(record):
    return record.levelname == "ERROR"

with log_to_file(Path("errors.log"), source_filter=error_filter):
    result = env.execute("script.py", "main")

print("Errors logged to errors.log")
```

---

### Example 6: Streaming to Network (Monitoring Dashboard)

**Use case**: Send logs to a monitoring service as they arrive

```python
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger, attachLogHandler
import logging
import requests
import json
from datetime import datetime

class RemoteLogHandler(logging.Handler):
    def __init__(self, endpoint: str):
        super().__init__()
        self.endpoint = endpoint

    def emit(self, record: logging.LogRecord):
        """Send each log to remote service."""
        try:
            payload = {
                "timestamp": datetime.now().isoformat(),
                "level": record.levelname,
                "message": record.getMessage(),
                "log_source": getattr(record, 'extra', {}).get("log_source"),
                "env_name": getattr(record, 'extra', {}).get("env_name"),
                "call_target": getattr(record, 'extra', {}).get("call_target"),
            }

            # Send to monitoring service
            requests.post(self.endpoint, json=payload, timeout=1)
        except Exception as e:
            self.handleError(record)

# Usage
remote_handler = RemoteLogHandler("http://monitoring.example.com/logs")
logger.addHandler(remote_handler)

env_manager = EnvironmentManager()
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
env.launch()

# All logs streamed to monitoring dashboard in real-time!
result = env.execute("script.py", "main")
```

---

### Example 7: Jupyter Notebook Integration

**Use case**: Display logs in Jupyter with live updates

```python
from ipywidgets import Output, VBox, HTML
from wetlands.environment_manager import EnvironmentManager
from wetlands.logger import logger, attachLogHandler
import logging

# Create output widget
log_output = Output()

@log_output.capture()
def notebook_log_handler(record: logging.LogRecord):
    """Handler for Jupyter notebook."""
    message = record.getMessage()
    level = record.levelname

    # Color code by level
    colors = {
        "ERROR": "red",
        "WARNING": "orange",
        "INFO": "blue",
    }
    color = colors.get(level, "black")

    print(f"<span style='color:{color}'>{level}</span>: {message}")

# Add handler
logger.addHandler(logging.Handler())
logger.addHandler(lambda record: notebook_log_handler(record))

# Display in notebook
display(HTML("<h2>Wetlands Execution Log</h2>"))
display(log_output)

# Execute
env_manager = EnvironmentManager()
env = env_manager.create("cellpose", {"conda": ["cellpose==3.1.0"]})
env.launch()
result = env.execute("script.py", "main")

# Logs appear in live output!
```

---

## Implementation API Reference

### CommandExecutor Changes

```python
# OLD (synchronous, blocks)
process = executor.executeCommands(commands)
output = executor.getOutput(process, commands)  # Blocks until complete

# NEW (async with ProcessLogger)
process = executor.executeCommands(
    commands,
    log_context={
        "log_source": "environment",
        "env_name": "cellpose",
        "stage": "install"
    }
)
# Returns immediately, logs emitted in background
# ProcessLogger is accessible via process._process_logger
```

### ExternalEnvironment.launch() Changes

```python
# OLD (reads stdout for port, conflicts with logging)
for line in self.process.stdout:
    if line.startswith("Listening port "):
        self.port = int(line.split()[-1])
        break

# NEW (subscribes to ProcessLogger)
port_found = threading.Event()

def parse_port(line, context):
    if line.startswith("Listening port "):
        self.port = int(line.split()[-1])
        port_found.set()

self._process_logger.subscribe(parse_port)
port_found.wait(timeout=30)
```

### EnvironmentManager.create() Changes

```python
# Add logging calls with context
self.logger.log_global("Creating environment: {name}")

self.commandExecutor.executeCommandsAndGetOutput(
    createEnvCommands,
    log_context={
        "log_source": "environment",
        "env_name": name,
        "stage": "create"
    }
)

self.logger.log_environment("Environment created", env_name=name)
```

### User-Facing API

```python
# Standard Python logging still works
logger.info("message")
logger.warning("message")
logger.error("message")

# New convenience methods
logger.log_global("Global operation")
logger.log_environment("Env message", env_name="cellpose")
logger.log_execution("Exec message", env_name="cellpose", call_target="segment")

# Standard handlers/filters work
logger.addHandler(my_handler)
logger.addFilter(my_filter)

# Access log context in filters
def my_filter(record):
    source = getattr(record, 'extra', {}).get("log_source")
    return source == "execution"

handler.addFilter(my_filter)
```

---

## Key Differences: Before vs After

| Aspect | Before | After |
|--------|--------|-------|
| Env creation feedback | None until complete | Real-time as progress happens |
| Multiple stdout readers | Race condition ❌ | Safe subscriptions ✓ |
| Log context | None (flat strings) | Rich metadata in records |
| Port parsing | Blocks on stdout | Non-blocking callback |
| User callbacks | String only | Full LogRecord with context |
| Thread safety | Manual/risky | Built into ProcessLogger |
| File logging | Manual setup | Automatic via handlers |
| GUI integration | Awkward | Clean callback |

---

## Notes

- **Backwards compatible**: Old code still works, new methods are optional
- **Non-blocking**: All I/O happens in background threads
- **Thread-safe**: ProcessLogger handles synchronization
- **Testable**: Each component can be tested independently
- **Extensible**: Users can create custom handlers/filters

