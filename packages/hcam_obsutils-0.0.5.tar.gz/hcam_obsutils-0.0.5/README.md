# HCAM Obsutils

This is a package containing useful scripts for observing with the instruments HiPERCAM, ULTRACAM and ULTRASPEC.
