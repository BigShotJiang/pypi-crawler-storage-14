
Pattern - represents a knitting pattern

`Pattern.cast_on(n)`

    alias `co`

    Cast on `n` stitches

    
`Work.work_stitch(
- name: The name or code of the stitch
- parent_count = 1: The number of stitches from the left needle that will be worked
- slip_parent_stitches = True: Indicates whether to slip the parent stitches 
- add_stitch_to_right_needle = True: Indicates whether to add the new stitch to the right needle
- tags = []: 

`Work.slip_stitch()
