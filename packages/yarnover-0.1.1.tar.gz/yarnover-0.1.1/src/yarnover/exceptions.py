
class KnittingException(Exception):
    ...


class PatternException(Exception):
    ...