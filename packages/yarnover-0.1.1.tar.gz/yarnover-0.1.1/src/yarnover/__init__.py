from yarnover.pattern import Pattern
from yarnover.swatch import MetricSwatch

def co(count : int = 0) -> Pattern:
    """Star new :class:`Pattern`, optionally casting on ``count`` stitches

    Equivant to ``Pattern().co(count)``

    :param count: The number of stitches to cast on.
    """
    return Pattern().co(count)

