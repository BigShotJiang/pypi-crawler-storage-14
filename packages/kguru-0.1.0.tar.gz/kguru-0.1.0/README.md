# kguru

An AI agent platform for Python with domain-specific knowledge capabilities.

## Features

- **STAR Framework**: Reasoning loop for intelligent problem-solving
- **Dynamic Knowledge Base**: Assemble knowledge from structured, semi-structured, and semantic vector sources
- **Multi-Model Support**: Works with various language models and vision language models

## Installation

```bash
pip install kguru
```

Or with uv:

```bash
uv add kguru
```

## Quick Start

```python
import kguru

# Create an agent with the STAR framework
agent = kguru.Agent()

# Run the agent loop
result = agent.solve("Your problem here")
```

