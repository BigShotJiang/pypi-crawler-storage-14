"""Basic tests for kguru package."""

import kguru


def test_import():
    """Test that the package can be imported."""
    assert kguru is not None


def test_version():
    """Test that version is accessible."""
    assert hasattr(kguru, "__version__")
