"""Pytest configuration and fixtures for kguru tests."""

import pytest


@pytest.fixture
def sample_fixture():
    """Example fixture for testing."""
    return "test_data"
