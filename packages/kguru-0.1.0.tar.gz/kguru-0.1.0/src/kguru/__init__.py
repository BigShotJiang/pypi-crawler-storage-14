"""kguru - An AI agent platform for Python."""

__version__ = "0.1.0"
