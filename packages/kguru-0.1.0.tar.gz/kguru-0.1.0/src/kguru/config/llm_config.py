"""LLM provider configuration."""

import os

from dotenv import load_dotenv

load_dotenv(override=True)

# Default max tokens for completions
DEFAULT_MAX_TOKENS = 4096


class OpenAIConfig:
    """Configuration for OpenAI LLM provider."""

    model: str = os.getenv("OPENAI_MODEL", "gpt-4")
    api_key: str = os.getenv("OPENAI_API_KEY", "")
    api_base: str | None = os.getenv("OPENAI_API_BASE")


class AzureOpenAIConfig:
    """Configuration for Azure OpenAI LLM provider."""

    model: str = os.getenv("AZURE_OPENAI_MODEL", "gpt-4")
    api_key: str = os.getenv("AZURE_OPENAI_API_KEY", "")
    azure_endpoint: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    api_version: str = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    deployment: str = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
