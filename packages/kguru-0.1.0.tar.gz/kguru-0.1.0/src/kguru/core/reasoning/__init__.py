"""Reasoning modules for kguru."""
