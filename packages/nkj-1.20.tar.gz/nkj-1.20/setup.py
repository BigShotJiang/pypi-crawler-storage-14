#
# [name] setup.py
#
# Written by Yoshikazu NAKAJIMA
#

from setuptools import setup, find_packages

setup(
	name='nkj',
	version='1.20',
	description='Phthon library for geometric computation',
	author='Yoshikazu NAKAJIMA',
	license='Department of Biomedical Informatics, Institute of Science Tokyo, Japan',
	packages=find_packages()
)
