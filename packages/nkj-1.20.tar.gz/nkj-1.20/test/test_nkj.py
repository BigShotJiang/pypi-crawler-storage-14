#
# [name] test_nkj.py
# [exec] python test_nkj.py
#
# Written by Yoshikazu NAKAJIMA
#

print('test_nkj')

case = None

if (case == 1):
	import nkj as n
	_DEBUGLEVEL = 1
	n.debuglevel(_DEBUGLEVEL)  # from ._ncore import * が有効
	print('DEBUGLEVEL: {0}'.format(n.debuglevel()))
	n.dprint('dprint() is available.')
elif (case == 2):
	from nkj import *
	_DEBUGLEVEL = 1
	s.debuglevel(_DEBUGLEVEL)  # __init__.py の all の設定が有効
	print('DEBUGLEVEL: {0}'.format(s.debuglevel()))
	s.dprint('dprint() is available.')
elif (case == 3):
	from nkj.s import *
	_DEBUGLEVEL = 1
	debuglevel(_DEBUGLEVEL)  # from ._ncore import * が有効
	print('DEBUGLEVEL: {0}'.format(debuglevel()))
	dprint('dprint() is available.')
else:
	pass

if (True):
	import nkj.m as nm

if (True):
	import nkj.cs as cs
