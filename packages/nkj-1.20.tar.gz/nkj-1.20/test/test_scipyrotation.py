#
from scipy.spatial.transform import Rotation as _sr

print(_sr)
