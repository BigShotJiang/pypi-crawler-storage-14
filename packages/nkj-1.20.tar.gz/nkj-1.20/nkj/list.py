#
# [name] nkj.list.py
# [exec] python -m nkj.lib
#
# Written by Yoshikau NAKAJIMA
#
import numpy as np
import nkj as _n
import nkj.str as _ns
import nkj.math as _nm

_DATAHEADER_INDEX_NONE = 0
_DATAHEADER_INDEX_SINGLELINE = 1
_DATAHEADER_INDEX_MULTILINES = 2
_COMPONENTHEADER_INDEX_NONE = _DATAHEADER_INDEX_NONE
_COMPONENTHEADER_INDEX_SINGLELINE = _DATAHEADER_INDEX_SINGLELINE
_COMPONENTHEADER_INDEX_MULTILINES = _DATAHEADER_INDEX_MULTILINES

class uniclasslist_cls(list):
	_classname = 'nkj.uniclasslist'
	_componentclass = None
	_dataheader = None

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	@classmethod
	def setComponentClass(cls, c):
		cls._componentclass = c

	def set_componentclass(cls, c):
		cls.setComponentClass(c)

	def set(self, x):
		_n.ldprint('--> nkj.list.uniclasslist.set()')
		if (x is None):
			return  # Do nothing
		
		_n.ldprint("x:                        {}".format(x))
		_n.ldprint("x.component class:        {}".format(_n.classtype(x)))
		_n.ldprint("x.component classname:    {}".format(_ns.strbracket(_n.classname(x))))
		
		if (self.componentclass is None):
			self.setComponentClass(_n.classtype(x))
		
		_n.ldprint("self.component class:     {}".format(self.componentclass))
		_n.ldprint("self.component classname: {}".format(_ns.strbracket(_n.classname(self.componentclass))))
		
		self.clear()
		
		if (x is None):
			raise Exception('__ERROR__: Illegal algorithm. NKJ-LIST-00070.')
		if (len(x) == 0):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-LIST-00074.")
		
		if (self.isinstance(x)):
			self += x
		else:
			self.append(x)
		
		_n.ldprint("<-- nkj.list.uniclasslist.set()")

	def append(self, x):
		_n.ldprint("--> nkj.list.uniclasslist.append()")
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		
		if (x is None):
			raise Exception("__ERROR__: Null data. NKJ-LIST-00081.")
		
		if (len(x) == 0):
			_n.ldprint("Null list. Do nothing.")
			_n.ldprint("<-- nkj.list.uniclasslist.append()")
			return  # Do nothing
		
		_n.ldprint('x.classtype:         {}'.format(type(x)))
		_n.ldprint("x.classname:         {}".format(_n.classname(x)))
		_n.ldprint("self.compoent class: {}".format(self.componentclass))
		
		if (self.isinstance(x)):
			_n.ldprint("@-- uniclasslist_cls")
			self += x
		elif (isinstance(x, self.componentclass)):       # Append a component. list クラスを継承している line3 クラス等のために，こちらを先に比較すること．
			_n.ldprint("@-- self.componentclass")
			super().append(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			_n.ldprint("@-- list, tuple, np.array")
			if (isinstance(x[0], self.componentclass)):  # [component1, component2, ...]
				for c in x:
					super().append(c)
			elif (isinstance(x[0], (list, tuple, np.ndarray))):
				ndim = np.array(x).ndim
				_n.ldprint('ndim: {}'.format(ndim))
				if (ndim == 2):
					super().append(self.componentclass(x))
				elif (ndim == 3):
					for c in x:
						super().append(self.componentclass(c))
				else:
					raise TypeError('__ERROR__: Illegal data type.')
			else:
				for i in range(len(x)):
					_n.ldprint("x[{0}].component class: {1}".format(i, x[i].__class__.__name__))
					super().append(self.componentclass(x[i]))
		else:
			_n.print_error("ERROR#: NKJ-LIST-00114.")
			_n.print_error("x: {0} ({1})".format(x, type(x)))
			_n.print_error("component class: {}".format(self.componentclass))
			_n.print_error("isinstance: {}".format(isinstance(x, self.componentclass)))
			raise TypeError("__ERROR__: Illegal data type. NKJ-LIST-00111.")
		_n.ldprint("<-- nkj.list.uniclasslist.append()")

	def component(self, i):
		return self.componentclass(self[i])

	def comp(self, i):
		return self.component(i)

	def c(self, i):
		return self.component(i)

	def dataheader(cls, s=None):
		if (s is None):
			return cls._dataheader
		else:
			cls._dataheader = s
			return True

	def componentheader(cls, s=None):
		return dataheader(s)

	# Data string

	def getDataString(self, rowend=None, separator='\n'):
		_n.ldprint('--> nkj.list.uniclasslist.getDataString()')
		_n.ldprint('rowend: \'{}\''.format('CR' if (rowend == '\n') else rowend))
		s = ''
		for k in range(len(self)):
			if (k != 0):
				if (separator is None or separator == ''):
					s += ', '
				else:
					s += separator
			try:
				s += self[k].getDataString(rowend=', ')
			except Exception as e:
				for j in range(self[k].rows):
					if (j != 0):
						if (rowend is None or rowend == ''):
							s += ', '
						else:
							s += rowend
					for i in range(self[k].columns):
						if (i != 0):
							s += ', '
						s += '{:21.12f}'.format(self[k, j, i])
		_n.ldprint('s: \'{}\''.format(s))
		_n.ldprint('<-- nkj.cs.uniclasslist.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.list.uniclasslist.setDataString()')
		_n.ldprint('datastr[{0}]: {1} ({2})'.format(len(s), s, type(s)))
		if (s[-1] == '\n'):
			s = s[:-1]
		s = s.split('\n')
		_n.ldprint('datastr[{0}]: {1} ({2})'.format(len(s), s, type(s)))
		k = 0
		self.clear()
		for ss in s:
			ss = ss.replace('(', '').replace(')', '').split(',')
			_n.ldprint('datastr[{0}]: \'{1}\' ({2})'.format(k, ss, type(ss)))
			self.append(self.componentclass(ss))
			k += 1
		_n.ldprint('<-- nkj.list.uniclasslist.setDataString()')

	def getDataStr(self, rowend=''):
		return self.getDataString(rowend)

	def setDataStr(self, s):
		self.setDataString(s)

	@property
	def datastring(self):
		return self.getDataString()

	@datastring.setter
	def datastring(self, s):
		self.setDataString(s)

	@property
	def datastr(self):
		return self.getDataString()

	@datastr.setter
	def datastr(self, s):
		self.setDataString(s)

	@property
	def dstr(self):
		return self.getDataString()

	@dstr.setter
	def dstr(self, s):
		self.setDataString(s)

	@property
	def ds(self):
		return self.getDataString()

	@ds.setter
	def ds(self, s):
		self.setDataString(s)

	# Print

	def getPrintString(self, title=None, dataheader=None):
		_n.ldprint("--> nkj.list.uniclasslist.getPrintString()")
		_n.ldprint("this class:          {}".format(_n.classtype(self)))
		_n.ldprint("this classname:      {}".format(_ns.strbracket(_n.classname(self))))
		_n.ldprint("component class:     {}".format(self.componentclass))
		_n.ldprint("component classname: {}".format(_ns.strbracket(_n.classname(self.componentclass))))
		s = ''
		llen = len(self)
		if (title is not None):
			s += '--- {0}[{1}] ---\n'.format(title, llen)
		for i in range(llen):
			if (dataheader is not None):
				s += datahearder
			elif (self.dataheader() is not None):
				if (self.dataheader() is _DATAHEADER_INDEX_NONE):
					pass
				elif (self.dataheader() is _DATAHEADER_INDEX_SINGLELINE):
					s += '[{}]: '.format(i)
				elif (self.dataheader() is _DATAHEADER_INDEX_MULTILINES):
					s += '[{}]:\n'.format(i)
				else:
					s += self.dataheader()
			if (isinstance(self[i], str)):
				s += self[i]
			else:
				s += self[i].getPrintString()
			s += '\n'
		if (title is not None):
			s += '---'
		_n.ldprint("<-- nkj.list.uniclasslist.getPrintString()")
		return s

	def getPrintStr(self, title=None, dataheader=None):
		return self.getPrintString(title, dataheader)

	@property
	def printstring(self):
		return self.getPrintString()

	@property
	def printstr(self):
		return self.getPrintString()

	@property
	def pstr(self):
		return self.getPrintString()

	def print(self, title=None, dataheader=None):
		print(self.getPrintString(title, dataheader), flush=True)

	# load, save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataString(f.read())

	def save(self, filename, rowend='', separator='\n'):
		_DATAEND = '\n'
		if (filename == '-'):
			print(self.getDataString(rowend, separator) + _DATAEND, flush=True)
		else:
			with open(filename, 'w') as f:
				f.write(self.getDataString(rowend, separator) + _DATAEND)

	def isinstance(self, x):
		return is_uniclasslist(x)

class uniclasslist(uniclasslist_cls):
	pass

class uclist(uniclasslist_cls):
	pass

def is_uniclasslist(x):
	return isinstance(x, uniclasslist_cls)

def is_uclist(x):
	return is_uniclasslist(x)


class multiclasslist_cls(list):
	_classname = 'nkj.multiclasslist'
	_componentclass = None

	def __new__(cls, x=None):
		self = super().__new__(cls)
		raise Exception("__ERROR__: Not implemented. NKJ-LIST-00188.")

	def __init__(self, x=None):
		super().__init__()
		raise Exception("__ERROR__: Not implemented. NKJ-LIST-00192.")

class multiclasslist(multiclasslist_cls):
	pass

class mclist_cls(multiclasslist_cls):
	pass

class mclist(multiclasslist_cls):
	pass


DATAHEADER_INDEX_NONE =       _DATAHEADER_INDEX_NONE
DATAHEADER_INDEX_SINGLELINE = _DATAHEADER_INDEX_SINGLELINE
DATAHEADER_INDEX_MULTILINES = _DATAHEADER_INDEX_MULTILINES
COMPONENTHEADER_INDEX_NONE =       _COMPONENTHEADER_INDEX_NONE
COMPONENTHEADER_INDEX_SINGLELINE = _COMPONENTHEADER_INDEX_SINGLELINE
COMPONENTHEADER_INDEX_MULTILINES = _COMPONENTHEADER_INDEX_MULTILINES


#-- lib main

if __name__ == '__main__':
	_LIB_DEBUGLEVEL = 1
	_n.lib_debuglevel(_LIB_DEBUGLEVEL)

	_n.ldprint("Lib Debug Level: {}".format(_n.lib_debuglevel()))

	#_ns.default_bracket('()')

	uclist = uniclasslist()
	uclist.print("uniclasslist")
