#
# [name]    nkj.primitiveshape.py
# [comment] Primitive Shapes (ps) Library
# [exec]    python -m nkj.primitiveshape
#
# Written by Yoshikazu NAKAJIMA
#
import math as _m
import numpy as np
from scipy.optimize import curve_fit
import copy
import nkj as _n
import nkj.str as _ns
import nkj.math as _nm
import nkj.list as _nl
import nkj.cs as _ncs
import nkj.vtk as _ntk

_DEFAULT_KEEPING_DISTANCE = _nm.keeping_distance()
_DEFAULT_KEEPING_ANGLE =    _nm.keeping_angle()

_DEFAULT_LINE2 =  [_ncs.vec2([0.0, 0.0]), _ncs.vec2([1.0, 0.0])]
_DEFAULT_LINE3 =  [_ncs.vec3([0.0, 0.0, 0.0]), _ncs.vec3([1.0, 0.0, 0.0])]
_DEFAULT_ZLINE3 = [_ncs.vec3([0.0, 0.0, 0.0]), _ncs.vec3([0.0, 0.0, 1.0])]

_DEFAULT_PLANE_ORIGIN = _ncs.vec3([0.0, 0.0, 0.0])
_DEFAULT_PLANE_NORMAL = _ncs.vec3([0.0, 0.0, 1.0])
_DEFAULT_PLANE = [_DEFAULT_PLANE_ORIGIN, _DEFAULT_PLANE_NORMAL]

_DEFAULT_SPHERE_ORIGIN = _ncs.point3([0.0, 0.0, 0.0])
_DEFAULT_SPHERE_RADIUS = 1.0
_DEFAULT_SPHERE = [_DEFAULT_SPHERE_ORIGIN, _DEFAULT_SPHERE_RADIUS]

_DEFAULT_CIRCLE2_ORIGIN = _ncs.point2([0.0, 0.0])
_DEFAULT_CIRCLE2_RADIUS = 1.0
_DEFAULT_CIRCLE2 = [_DEFAULT_CIRCLE2_ORIGIN, _DEFAULT_CIRCLE2_RADIUS]

_DEFAULT_CIRCLE3_MATRIX = _ncs.DEFAULT_MAT3X4
_DEFAULT_CIRCLE3_RADIUS = 1.0
_DEFAULT_CIRCLE3 = [_DEFAULT_CIRCLE3_MATRIX, _DEFAULT_CIRCLE3_RADIUS]

_DEFAULT_CYLINDER_AXIS = _DEFAULT_ZLINE3
_DEFAULT_CYLINDER_RADIUS = 1.0
_DEFAULT_CYLINDER = [_DEFAULT_CYLINDER_AXIS, _DEFAULT_CYLINDER_RADIUS]

_DEFAULT_CONE_BASECENTER = _ncs.vec3([0.0, 0.0, 0.0])
_DEFAULT_CONE_TIP =        _ncs.vec3([0.0, 0.0, 1.0])
_DEFAULT_CONE_BASERADIUS = 1.0
_DEFAULT_CONE = [_DEFAULT_CONE_BASECENTER, _DEFAULT_CONE_TIP, _DEFAULT_CONE_BASERADIUS]

_LINE_SETTINGFLAG_TWOPOINTS = 0
_LINE_SETTINGFLAG_ORIGINANDVECTOR = 1
_DEFAULT_LINE_SETTINGFLAG = _LINE_SETTINGFLAG_TWOPOINTS

LINE_SETTINGFLAG_TWOPOINTS = _LINE_SETTINGFLAG_TWOPOINTS
LINE_SETTINGFLAG_ORIGINANDVECTOR = _LINE_SETTINGFLAG_ORIGINANDVECTOR

_ICOSAHEDRON_RADIUS1 = 30.0
_ICOSAHEDRON_RADIUS2 = 50.0

nd = _n.LibDebugFlag()

# Classes

#-- Primitive shape classes

class primitiveshape_cls(list):
	_classname = 'nkj.primitiveshape.primitiveshape'

	def __new__(cls):
		self = super().__new__(cls)
		return self

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	# Components

	def getComponents(self):
		_n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def setComponents(self, x):
		_n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def Components(self, x=None):
		if (x is None):
			return self.getComponents()
		else:
			self.setComponents(x)

	@property
	def components(self):
		return self.getComponents()

	@components.setter
	def components(self, x):
		self.setComponents(x)

	@property
	def comps(self):
		return self.getComponents()

	@comps.setter
	def comps(self, x):
		self.setComponents(x)

	def getSerialized(self):
		return self.getComponents()

	def serialize(self):
		return self.getComponents()

	@property
	def serialized(self):
		return self.getComponents()

	# Component

	def getComponent(self, index):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def setComponent(self, index, x):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def Component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def comp(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def c(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	# Parameters

	def getParameters(self):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def setParameters(self):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def Parameters(self, x=None):
		if (x is None):
			return self.getParameters()
		else:
			self.setParameters(x)

	@property
	def parameters(self):
		return self.getParameters()

	@parameters.setter
	def parameters(self, x):
		self.setParameters(x)

	@property
	def params(self):
		return self.getParameters()

	@params.setter
	def params(self, x):
		self.setParameters(x)

	def getParameterized(self):
		return self.getParameters()

	def parameterize(self):
		return self.getParameters()

	@property
	def parameterized(self):
		return self.getParameters()

	# Data string

	def getDataString(self):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def setDataString(self, s):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def DataString(self, s=None):
		if (s is None):
			return self.getDataString()
		else:
			self.setDataString(s)

	def getDataStr(self):
		return self.getDataString()

	def setDataStr(self, s):
		self.setDataString(s)

	def DataStr(self, s=None):
		if (s is None):
			return self.getDataString()
		else:
			self.setDataString(s)

	@property
	def datastring(self):
		return self.getDataString()

	@datastring.setter
	def datastring(self, s):
		self.setDataString(s)

	@property
	def datastr(self):
		return self.getDataString()

	@datastr.setter
	def datastr(self, s):
		self.setDataString(s)

	@property
	def dstr(self):
		return self.getDataString()

	@dstr.setter
	def dstr(self, s):
		self.setDataString(s)

	@property
	def ds(self):
		return self.getDataString()

	@ds.setter
	def ds(self, s):
		self.setDataString(s)

	# Print

	def getPrintString(self, title=None):
		n.print_error('This function should be overried in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstring(self):
		return self.getPrintString()

	@property
	def printstr(self):
		return self.getPrintString()

	@property
	def pstr(self):
		return self.getPrintString()

	@property
	def ps(self):
		return self.getPrintString()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

	# Load, Save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataString(f.read())

	def save(self, filename):
		_DATAEND = '\n'
		if (filename == '-'):
			print(self.getDataString() + _DATAEND)
		else:
			try:
				with open(filename, 'w') as f:
					f.write(self.getDataString() + _DATAEND)
			except Exception as e:
				raise Exception(e)


#-- Line classes

class linex_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshape.linex'
	_componentclass = None

	def __new__(cls):
		self = super().__new__(cls)
		return self

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	def set(self, pts, flag=_DEFAULT_LINE_SETTINGFLAG):
		self.setPoints(pts, flag)

	def setPoints(self, pts, flag=_DEFAULT_LINE_SETTINGFLAG):
		_n.ldprint("--> nkj.primitiveshape.linex.setPoints(, flag:{})".format(flag))
		_n.ldprint("pts: {0} ({1})".format(pts, type(pts)))
		
		if (pts is None):
			raise ValueError("__ERROR__: Value is None.")
		
		if (nd.LIB_DEBUG):
			print("component class: {}".format(type(self.componentclass)))
			print("pts: {0} ({1})".format(pts, type(pts)))
			print("len(pts): {}".format(len(pts)))
			for i in range(2):
				print('pt[{0}]: {1} ({2})'.format(i, pts[i], type(pts[i])))
		
		# ここでは、{vec2, vec3, list/tuple/np.ndarray} を要素とする {list, tuple} クラスを取り扱う．
		
		if (isinstance(pts, (list, tuple, np.ndarray))):
			if (len(pts) != 2):
				raise ValueError("__ERROR__: Illegal data. NKJ-PRIMITIVESHAPE-00107.")
			
			if (self.is_componentclass(pts[0]) and self.is_componentclass(pts[1])):
				self.clear()
				if (flag == _LINE_SETTINGFLAG_TWOPOINTS):
					if (nd.LIB_DEBUG):
						print('@-- componentclass, TWOPOINTS_SETTING')
					self.append(pts[0])
					self.append(pts[1])
				elif (flag == _LINE_SETTINGFLAG_ORIGINANDVECTOR):
					if (nd.LIB_DEBUG):
						print('@-- componentclass, ORIGINANDVECTOR_SETTING')
					self.append(pts[0])
					self.append(self.componentclass(pts[0]) + self.componentclass(pts[1]))
					# *1)  ↑
					# リストの要素同士の足し算は、時として、リストの足し算（結合）として計算されるので、
					# コンポーネントクラスの演算を演算子で行う場合には、
					# コンポーネントクラス（vec2, vec3）に型変換（キャスト）してから、計算する
					#
				else:
					raise Exception("__ERROR__: Illegal flag. NKJ-PRIMITIVESHAPE-00131.")
			elif (isinstance(pts[0], (list, tuple, np.ndarray)) and isinstance(pts[1], (list, tuple, np.ndarray))):
				self.clear()
				if (flag == _LINE_SETTINGFLAG_TWOPOINTS):
					if (nd.LIB_DEBUG):
						print('@-- list/tuple/np.ndarray, TWOPOINTS_SETTING')
					for i in range(2):
						pt = self.componentclass(pts[i])
						self.append(pt)
				elif (flag == _LINE_SETTINGFLAG_ORIGINANDVECTOR):
					if (nd.LIB_DEBUG):
						print('@-- list/tuple/np.ndarray, ORIGINANDVECTOR_SETTING')
					for i in range(2):
						pt = self.componentclass(pts[0]) if (i == 0) else (self.componentclass(pts[0]) + self.componentclass(pts[1]))  # 上と同様 *1)
						self.append(pt)
				else:
					raise Exception("__ERROR__: Illegal flag. NKJ-PRIMITIVESHAPE-00142.")
			else:
				raise ValueError("__ERROR__: Illegal data.")
			
			if (nd.LIB_DEBUG):
				self.print("@nkj.primitiveshape.linex.setPoints()")
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-00128.")
		_n.ldprint("<-- nkj.primitiveshape.linex.setPoints()")

	# Components

	def getComponents(self):
		clist = []
		for i in range(2):
			if (_nm.is_digit(self[i])):
				clist.append(self[i])
			else:
				clist.extend(self[i].getComponents())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != len(self.getComponents())):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.clear()
		vdim = self.componentclass().vdim
		i = 0
		c = []
		for j in range(vdim):
			c.append(x[i])
			i += 1
		self.append(self.componentclass(c))
		c.clear()
		for j in range(vdim):
			c.append(x[i])
			i += 1
		self.append(self.componentclass(c))

	# Component

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError('__ERROR__: Illegal index.')
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError('__ERROR__: Illegal index.')
		if (self.is_componentclass(x)):
			self[index] = x
		elif (isinstance(x, (list, tuple, np.ndarray))):
			self[index] = self.componentclass(x)
		else:
			raise ValueError("__ERROR__: Illegal data.")

	def getPoint(self, index):
		return self.getComponent(index)

	def setPoint(self, index, pt):
		self.setComponent(index, pt)

	def Point(self, index, pt=None):
		if (pt is None):
			return self.getPoint(index)
		else:
			self.setPoint(index, pt)

	@property
	def point0(self):
		return self.getPoint(0)

	@property
	def point1(self):
		return self.getPoint(1)

	@point0.setter
	def point0(self, pt):
		self.setPoint(0, pt)

	@point1.setter
	def point1(self, pt):
		self.setPoint(1, pt)

	@property
	def pt0(self):
		return self.getPoint(0)

	@property
	def pt1(self):
		return self.getPoint(1)

	@pt0.setter
	def pt0(self, pt):
		self.setPoint(0, pt)

	@pt1.setter
	def pt1(self, pt):
		self.setPoint(1, pt)

	@property
	def p0(self):
		return self.getPoint(0)

	@property
	def p1(self):
		return self.getPoint(1)

	@p0.setter
	def p0(self, pt):
		self.setPoint(0, pt)

	@p1.setter
	def p1(self, pt):
		self.setPoint(1, pt)

	def getOrigin(self):
		return self.getPoint(0)

	def setOrigin(self, x):
		self.setPoint(0, x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	def getDirectionalVector(self):
		return (self.getPoint(1) - self.getPoint(0))

	def setDirectionalVector(self, x):
		orig = self.getOrigin()
		v = self.getDirectionalVector()
		len = self.getLength()
		x = x.normalized
		self.setComponent(1, orig + len * x)

	def DirectionalVector(self):
		return self.getDirectionalVector()

	def getDirection(self):
		return self.getDirectionalVector()

	def Direction(self):
		return self.getDirection()

	def getVector(self):
		return self.getDirectionalVector()

	def Vector(self):
		return self.getVector(self)
	
	@property
	def direction(self):
		return self.getDirection()

	@property
	def vector(self):
		return self.getDirection()

	@property
	def vec(self):
		return self.getDirection()

	def getLength(self):
		return np.linalg.norm(self.getPoint(1) - self.getPoint(0))

	def setLength(self, len):
		self.setPoint(1, self.getPoint(0) + len * self.getDirectionalVector())

	def Length(self, l=None):
		if (l is None):
			return self.getLength()
		else:
			self.setLength(l)

	@property
	def length(self):
		return self.getLength()

	@length.setter
	def length(self, l):
		self.setLength(l)

	@property
	def len(self):
		return self.getLength()

	@len.setter
	def len(self, l):
		self.setLength(l)

	@property
	def l(self):
		return self.getLength()

	@l.setter
	def l(self, l):
		self.setLength(l)

	def getNorm(self):
		return self.getLength()

	def Norm(self):
		return self.getNorm()

	@property
	def norm(self):
		return self.getNorm()

	def getNormalized(self):
		nv = copy.deepcopy(self)
		length = self.getLength()
		nv /= length
		return nv

	@property
	def normalized(self):
		return self.getNormalized()

	# Data string

	def getDataString(self):
		_n.ldprint('--> nkj.primitiveshape.linex.getDataString()')
		s = ''
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getPoint(i).getDataString())
		_n.ldprint('<-- nkj.primitiveshape.linex.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.linex.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		while (s[-1] == '\n'):
			s = s[:-1]
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		c = []
		ii = 0
		for j in range(2):
			c.clear()
			for i in range(self.getComponent(0).vdim):
				c.append(data[ii])
				ii += 1
			_n.ldprint('component[{0}]: {1} ({2})'.format(j, c, type(c)))
			self.setComponent(j, self.componentclass(c))
		_n.ldprint('<-- nkj.primitiveshape.linex.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getPoint(i).getPrintString())
		return s

	# isinstance

	def is_componentclass(self, x):
		raise Exception("__ERROR__: Not implemented.")

	def isinstance(self, x):
		return is_linex(x)

class linex(linex_cls):
	pass

def is_linex(x):
	return isinstance(x, linex_cls)


class line2_cls(linex_cls):
	_classname = 'nkj.primitiveshapes.line2'
	_componentclass = _ncs.point2

	def __new__(cls, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self = super().__new__(cls)
		self.set(_DEFAULT_LINE2 if (pts is None) else pts, flag)
		return self

	def __init__(self, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self.set(_DEFAULT_LINE2 if (pts is None) else pts, flag)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __xor__(self, second):  # '^' operator
		return self.innerproduct(second)

	def __mul(self, second):    # '*' operator
		return self.outerproduct(second)

	def __matmul__(self, second):
		raise Exception('__ERROR__: Not supported.')

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def __and__(self, second):  # '&' operator
		return self.crosssection(second)

	# Parameterization
	#
	# a * (x - x0) + b * (y - y0) = 0
	#

	def getParameters(self):
		vec = self.getVector()
		orig = self.getOrigin()
		return [vec.x, vec.y, orig.x, orig.y]  # a, b, x0, y0

	def setParameters(self, x):
		vec = _ncs.vec2([x[0], x[1]])
		orig = _ncs.vec2([x[2], x[3]])
		self.set([orig, vec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)

	# Operators

	def rmultiply(self, x):
		if (_ncs.is_mat2x2(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass(x @ self.getPoint(i)))
			return line2(newpts)
		elif (_ncs.is_mat2x3(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x.h @ self.getPoint(i).h).ih))
			return line2(newpts)
		elif (_ncs.is_mat3x3(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x @ self.getPoint(i).h).ih))
			return line3(newpts)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Geometrical computation

	def innerproduct(self, v):
		v1 = self.vector
		v2 = v.vector
		return (v1 ^ v2)

	def inner(self, v):
		return self.innerproduct(v)

	def dotproduct(self, v):
		return self.innerproduct(v)

	def dot(self, v):
		return self.innerproduct(v)

	def outerproduct(self, x):
		v1 = self.vector
		v2 = v.vector
		return (v1 * v2)

	def outer(self, v):
		return self.outerproduct(v)

	def crossproduct(self, v):
		return self.outerproduct(v)

	def cross(self, v):
		return self.outerproduct(v)

	def crosssection(self, x):
		_n.ldprint('--> nkj.primitiveshape.line2.crosssection()')
		
		if (not self.isinstance(x)):
			raise TypeError('__ERROR__: Illegal data type.')
		
		l1 = self
		l2 = x
		
		deno = l1.vector * l2.vector  # crosssection, denominator
		
		if (_nm.is_ineps(deno)):
			_n.print_error('Two lines are parallel.')
			return None
		
		s = (l2.p0 - l1.p0) * (l2.p1 - l2.p0) / deno
		t = (l1.p1 - l1.p0) * (l1.p0 - l2.p0) / deno
		
		a = l1.p0
		b = l1.p1
		c = l2.p0
		d = l2.p1
		
		cpt = _ncs.vec2([a.x + s * (b - a).x, a.y + s * (b - a).y])
		
		if (nd.LIB_DEBUG):
			cpt.print('crosssection point')
		
		_n.ldprint('<-- nkj.primitiveshape.line2.crosssection()')
		return cpt

	def crosspoint(self, x):
		return self.crosssection(x)

	def getAngle(self, x):
		v1 = self.getVector()
		v2 = x.getVector()
		return v1.getAngle(v2)

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	# isinstance

	def is_componentclass(self, x):
		return _ncs.is_vec2(x)

	def isinstance(self, x):
		return is_line2(x)

class line2(line2_cls):
	pass

def is_line2(x):
	return isinstance(x, line2_cls)


class line3_cls(linex_cls):
	_classname = 'nkj.primitiveshapes.line3'
	_componentclass = _ncs.point3

	def __new__(cls, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self = super().__new__(cls)
		self.set(_DEFAULT_LINE3 if (pts is None) else pts, flag)
		return self

	def __init__(self, pts=None, flag=_DEFAULT_LINE_SETTINGFLAG):
		self.set(_DEFAULT_LINE3 if (pts is None) else pts, flag)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not supported.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def __and__(self, second):
		return self.crosssection(second)

	# Operations

	def rmultiply(self, x):
		if (_ncs.is_mat3x3(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass(x @ self.getPoint(i)))
			return line3(newpts)
		elif (_ncs.is_mat3x4(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x.h @ self.getPoint(i).h).ih))
			return line3(newpts)
		elif (_ncs.is_mat4x4(x)):
			newpts = []
			for i in range(2):
				newpts.append(self.componentclass((x @ self.getPoint(i).h).ih))
			return line3(newpts)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Parameterization
	#
	#  x - x0     y - y0     z - z0
	# -------- = -------- = --------
	#    a          b          c
	#

	def getParameters(self):
		vec = self.getVector()
		orig = self.getOrigin()
		return [vec.x, vec.y, vec.z, orig.x, orig.y, orig.z]  # a, b, c, x0, y0, z0

	def setParameters(self, x):
		vec = _ncs.vec3([x[0], x[1], x[2]])
		orig = _ncs.vec3([x[3], x[4], x[5]])
		self.set([orig, vec], _LINE_SETTINGFLAG_VECTORANDORIGIN)

	# Matrix

	def getMat3x4(self):
		m = _ncs.mat3x4()
		xaxis = self.getDirectionalVector().normalized
		m = xaxis.matrix(_ncs.XAXISINDEX)
		m.setTranslation(self.getOrigin())
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	@property
	def m3x4(self):
		return self.getMat3x4()

	@property
	def mat3(self):
		return self.getMat3x4()

	@property
	def m3(self):
		return self.getMat3x4()

	def getMatrix(self):
		return self.getMat3x4()

	@property
	def matrix(self):
		return self.getMat3x4()

	@property
	def mat(self):
		return self.getMat3x4()

	@property
	def m(self):
		return self.getMat3x4()

	# Geometrical computation

	def getDistance(self, pt):
		#
		# d = |b| sin(theta)
		#   = |b| sqrt( 1 - cos(theta)^2)
		#
		#                    (a dot b)^2
		#   = |b| sqrt( 1 - --------------)
		#                     (|a||b|)^2
		#
		# ただし、a は直線の向き、 b は直線上の任意の点（ここでは直線原点 P0) から pt（ここでは点 P1）に向かうベクトル．
		# ここで、a は、P0 から直線への直線上の最近傍点 P2 へ向かうベクトルと一致する．
		#
		a, b, c, x0, y0, z0 = self.parameterize()
		av = _ncs.vec3([a, b, c]).normalized
		bv = pt - _ncs.vec3([x0, y0, z0])
		
		if (_nm.is_ineps(bv.norm)):    # 点 P1 が直線原点 P0 と一致．即ち、P1 は直線上に存在．
			d = 0.0
		elif (_nm.is_ineps(av.norm)):  # 点 P1 から直線への最近傍点 P2 が直線原点 P0 と一致．というより直線の向きがゼロベクトルなので，計算不可．
			d = bv.norm
		else:
			nume = _nm.sq(av ^ bv)
			deno = _nm.sq(av.norm * bv.norm)  # av.norm も bv.norm もゼロでないので、分母がゼロになることはない．
			if (_nm.is_ineps(av.normalized ^ bv.normalized, 1.0)):  # av と bv がほぼ並行 = pt が直線上にある
				return 0.0
			if (_nm.is_ineps(deno)):                                # av と bv の外積がゼロの場合も pt が直線上にあると考えられる
				return 0.0
			s = 1.0 - nume / deno
			_METHOD = 2
			if (_METHOD == 1):     # 1.0 - nume / demo が負のとき、0.0 にする．
				s = max([0.0, s])
				sign = 1.0
			elif (_METHOD == 2):   # 1.0 - nume / demo が負のときに、sqrt() が負に対応しないので絶対をとる
				sign = np.sign(s)
				s = abs(s)
			else:
				raise Exception('__ERROR__: Illegal algorithm. Incorrect _METHOD.')
			_n.ldprint2('sin: {:.6f}'.format(s))
			d = bv.norm * sign * _m.sqrt(s)
		return d

	def Distance(self, pt):
		return self.getDistance(pt)

	def distance(self, pt):
		return self.getDistance(pt)

	def dist(self, pt):
		return self.getDistance(pt)

	def crosssection(self, x):
		_n.ldprint('--> nkj.primitiveshape.line3.crosssection()')
		if (is_plane(x)):
			return x.crosssection(self)  # plane.crosssection() をコール
		if (x is None):
			raise ValueError('__ERROR__: Null line. NKJ-PRIMITIVESHAPE-00380.')
		l2 = x if (is_line3(x)) else line3(x)
		l1 = self
		if (_nm.is_ineps(abs(l1.vector ^ l2.vector), 1.0)):
			_n.print_error('Two lines are almotst parallel at nkj.primitiveshape.line3.crosssection()')
			return None
		nvec = l1.vector * l2.vector
		pl_1 = plane([l1.origin, l1.vector * nvec])  # 直線 l1 とベクトル nvec を含む平面を定義
		pl_2 = plane([l2.origin, l2.vector * nvec])  # 直線 l2 とベクトル nvec を含む平面を定義
		cpt1 = pl_2 & l1
		cpt2 = pl_1 & l2
		cpt = (cpt1 + cpt2) / 2.0
		_n.ldprint('<-- nkj.primitiveshape.line3.crosssection()')
		return cpt

	def crosspoint(self, x):
		return self.crosssection(x)

	def setByPoints(self, pts, length=1.0):
		_n.ldprint('--> nkj.primitiveshape.line3.setByPoints(, {})'.format(length))
		if (_ncs.is_point3list(pts)):
			pass
		elif (isinstance(pts, (list, tuple))):
			pts = _ncs.point3list(pts)
		else:
			raise TypeError("Illegal data type. NKJ-PRIMITIVESHAPE-00340.")
		l, p = np.linalg.eigh(pts.cvm)
		_n.ldprint2('Eigen value:  {}'.format(l))
		_n.ldprint2('Eigen vector: {}'.format(p))
		maxval, maxid = _nm.max_index(l)
		maxvec = p[:, maxid]  # i番目の固有値とp[:, i]の固有ベクトルが対応している
		_n.ldprint2('Maximum eigen value: index:[{0}], value:{1}'.format(maxid, maxval))
		_n.ldprint2('Maximum eigen vector:              {}'.format(maxvec))
		maxvec = _ncs.vec3(maxvec)
		maxvec.normalize()
		_n.ldprint2('Maximum eigen vector (normalized): {}'.format(maxvec))
		self.setPoint(0, pts.average)
		self.setPoint(1, pts.average + length * maxvec)
		if (nd.LIB_DEBUG):
			self.print("line3 (by points)")
		_n.ldprint('<-- nkj.primitiveshape.line3.setByPoints()')

	def setFromPoints(self, pts, length=1.0):
		self.setByPoints(pts, length)

	@property
	def by_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00359.")

	@by_points.setter
	def by_points(self, x):
		if (_ncs.is_point3list(x)):
			self.setByPoints(x)
		elif (isinstance(x, (list, tuple, np.array))):
			if (len(x) == 2):
				if ((_ncs.is_point3list(x[0]) or isinstance(x[0], (list, tuple))) and _nm.is_digit(x[1])):
					self.setByPoints(x[0], x[1])
				else:
					self.setByPoints(x)
			else:
				self.setByPoints(x)

	@property
	def from_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00379.")

	@from_points.setter
	def from_points(self, x):
		if (_ncs.is_point3list(x)):
			self.setFromPoints(x)
		elif (isinstance(x, (list, tuple, np.array))):
			if (len(x) == 2):
				if ((_ncs.is_point3list(x[0]) or isinstance(x[0], (list, tuple))) and _nm.is_digit(x[1])):
					self.setFromPoints(x[0], x[1])
				else:
					self.setFromPoints(x)
			else:
				self.setFromPoints(x)

	def getAngle(self, x):
		v1 = self.getVector()
		v2 = x.getVector()
		return v1.getAngle(v2)

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	def is_componentclass(self, x):
		return _ncs.is_point3(x)

	#
	#  x - x0     y - y0     z - z0
	# -------- = -------- = --------
	#    a          b          c
	#
	def getPointFromX(self, x):
		a, b, c, x0, y0, z0 = self.parameterize()
		x = x0 if (_nm.is_ineps(a)) else x
		y = y0 if (_nm.is_ineps(a)) else y0 + b * (x - x0) / a
		z = z0 if (_nm.is_ineps(a)) else z0 + c * (x - x0) / a
		return _nm.vec3([x, y, z])

	def getPointFromY(self, y):
		a, b, c, x0, y0, z0 = self.parameterize()
		y = x0 if (_nm.is_ineps(b)) else y
		z = z0 if (_nm.is_ineps(b)) else z0 + c * (y - y0) / b
		x = x0 if (_nm.is_ineps(b)) else x0 + a * (y - y0) / b
		return _nm.vec3([x, y, z])

	def getPointFromZ(self, z):
		a, b, c, x0, y0, z0 = self.parameterize()
		z = z0 if (_nm.is_ineps(c)) else z
		x = x0 if (_nm.is_ineps(c)) else x0 + a * (z - z0) / c
		y = y0 if (_nm.is_ineps(c)) else y0 + b * (z - z0) / c
		return _nm.vec3([x, y, z])

	def PointFromX(self, x):
		return self.getPointFromX(x)

	def PointFromY(self, y):
		return self.getPointFromY(y)

	def PointFromZ(self, z):
		return self.getPointFromZ(z)

	def point_from_x(self, x):
		return self.getPointFromX(x)

	def point_from_y(self, y):
		return self.getPointFromY(y)

	def point_from_z(self, z):
		return self.getPointFromZ(z)

	def from_x(self, x):
		return self.getPointFromX(x)

	def from_y(self, y):
		return self.getPointFromY(y)

	def from_z(self, z):
		return self.getPointFromZ(z)

	def getPointFromIndexAndValue(self, index, val):
		if (index == 0):
			pt = self.getPointFromX(val)
		elif (index == 1):
			pt = self.getPointFromY(val)
		elif (index == 2):
			pt = self.getPointFromZ(val)
		else:
			raise ValueError('__ERROR__: Illegal index.')
		return pt

	def PointFromIndexAndValue(self, index, val):
		return self.getPointFromIndexAndValue(index, val)

	def point_from_indexandvalue(self, index, val):
		return self.getPointFromIndexAndValue(index, val)

	def from_indexandvalue(self, index, val):
		return self.getPointFromIndexAndValue(index, val)

	# isinstance

	def is_componentclass(self, x):
		return _ncs.is_vec3(x)

	def isinstance(self, x):
		return is_line3(x)

class line3(line3_cls):
	pass

class line(line3_cls):
	pass

def is_line3(x):
	return isinstance(x, line3_cls)

def is_line(x):
	return is_line3(x)


#-- Plane class

class plane3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.plane3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_PLANE if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		return self.multiply(second)

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def __and__(self, second):     # '&' operator
		return self.crosssection(second)

	def __lshift__(self, second):  # 'self.plane << x' operator
		return self.project(second)

	def __rrshift__(self, first):  # 'x >> self.plane' operator
		return self.project(first)

	# Data operation

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.plane.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type.")
		if (len(x) == 0):
			raise TypeError("__ERROR__: Null data.")
		_n.ldprint2("len(x): {}".format(len(x)))
		if (len(x) != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		if (not _ncs.is_vec3(x[0])):
			if (isinstance(x, (list, tuple, np.ndarray))):
				x[0] = _ncs.vec3(x[0])
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		if (not _ncs.is_vec3(x[1])):
			if (isinstance(x, (list, tuple, np.ndarray))):
				x[1] = _ncs.vec3(x[1])
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		self.clear()
		for i in range(2):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		if (nd.LIB_DEBUG):
			for i in range(len(x)):
				self[i].print("{0}".format(_n.classname(x[i])))
		_n.ldprint("<-- nkj.primitiveshape.plane.set()")

	# Component

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		if (index == 0):
			if (_ncs.is_vec3(x)):
				pass
			elif (isinstance(x, (list, tuple, np.ndarray))):
				x = _ncs.vec3(x)
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		elif (index == 1):
			if (_ncs.is_vec3(x)):
				pass
			elif (isinstance(x, (list, tuple, np.ndarray))):
				x = _ncs.vec3(x)
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		self[index] = x

	def Component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def getOrigin(self):
		return self.getComponent(0)

	def setOrigin(self, x):
		self.setComponent(0, x)

	def Origin(self, x=None):
		if (x is None):
			return self.getOrigin()
		else:
			self.setOrigin(x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getNormalVector(self):
		return self.getComponent(1)

	def setNormalVector(self, x):
		self.setComponent(1, x)

	def NormalVector(self, x=None):
		if (x is None):
			return self.getNormalVector()
		else:
			self.setNormalVector(x)

	def getNormal(self):
		return self.getNormalVector()

	def setNormal(self, x):
		self.setNormalVector(x)

	def Normal(self, x=None):
		if (x is None):
			return self.getNormalVector()
		else:
			self.setNormalVector(x)

	def getVector(self):
		return self.getNormalVector()

	def setVector(self, x):
		self.setNormalVector(x)

	def Vector(self, x=None):
		if (x is None):
			return self.getNormalVector()
		else:
			self.setNormalVector(x)

	@property
	def normalvector(self):
		return self.getNormalVector()

	@normalvector.setter
	def normalvector(self, x):
		self.setNormalVector(x)

	@property
	def nv(self):
		return self.getNormalVector()

	@nv.setter
	def nv(self, x):
		self.setNormalVector(x)

	@property
	def normal(self):
		return self.getNormalVector()

	@normal.setter
	def normal(self, x):
		self.setNormalVector(x)

	@property
	def n(self):
		return self.getNormalVector()

	@n.setter
	def n(self, x):
		self.setNormalVector(x)

	@property
	def vector(self):
		return self.getNormalVector()

	@vector.setter
	def vector(self, x):
		self.setNormalVector(x)

	@property
	def vec(self):
		return self.getNormalVector()

	@vec.setter
	def vec(self, x):
		self.setNormalVector(x)

	@property
	def v(self):
		return self.getNormalVector()

	@v.setter
	def v(self, x):
		self.setNormalVector(x)

	def getOriginAndNormal(self):
		return self.getOrigin(), self.getNormal()

	def setOriginAndNormal(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data type.')
		self.setOrigin(x[0])
		self.setNormal(x[1])

	def OriginAndNormal(self, x=None):
		if (x is None):
			return self.getOriginAndNormal(x)
		else:
			self.setOriginAndNormal(x)

	@property
	def originandnormal(self):
		return self.getOriginAndNormal()

	@originandnormal.setter
	def originandnormal(self, orig, nv):
		self.setOriginAndNormal(orig, nv)

	# Goemetrical computation

	def getSignedDistance(self, pt):
		#
		#      a * x + b * y + c * z + d
		# d = ---------------------------------
		#        sqrt(a^2 + b^2 + c^2)
		#
		a, b, c, x0, y0, z0 = self.parameterize()
		v = _ncs.vec3([a, b, c])
		deno = v.norm  # denominator: sqrt(sq(a) + sq(b) + sq(c))   # denominator
		if (is_ineps(denomin)):
			_n.print_error('Zero directional vector: {}'.format(v))
			raise Exception('__ERROR__: Illegal plane parameters.')
		nume = a * (pt.x - x0) + b * (pt.y - y0) + c * (pt.z - z0)  # numerator: a * x + b * y + c * z + d
		d = nume / deno
		return d

	def SignedDistance(self, pt):
		return self.getSignedDistance(self, pt)

	def signeddistance(self, pt):
		return self.getSignedDistance(self, pt)

	def sdist(self, pt):
		return self.getSignedDistance(self, pt)

	def getDistance(self, pt):
		return _m.sqrt(self.getSignedDistance(pt))

	def Distance(self, pt):
		return self.getDistance(pt)

	def distance(self, pt):
		return self.getDistance(pt)

	def dist(self, pt):
		return self.getDistance(pt)

	def setByPoints(self, pts):
		_n.ldprint('--> nkj.primitiveshape.plane.setByPoints()')
		if (_ncs.is_point3list(pts)):
			pass
		elif (isinstance(pts, (list, tuple))):
			pts = _ncs.point3list(pts)
		else:
			raise TypeError("Illegal data type. NKJ-PRIMITIVESHAPE-00546.")
		l, p = np.linalg.eigh(pts.cvm)
		_n.ldprint2('Eigen value:  {}'.format(l))
		_n.ldprint2('Eigen vector: {}'.format(p))
		minval, minid = _nm.min_index(l)
		minvec = p[:, minid]  # i番目の固有値とp[:, i]の固有ベクトルが対応している
		_n.ldprint2('Minimum eigen value: index:[{0}], value:{1}'.format(minid, minval))
		_n.ldprint2('Minimum eigen vector:              {}'.format(minvec))
		minvec = _ncs.vec3(minvec)
		minvec.normalize()
		_n.ldprint2('Minimum eigen vector (normalized): {}'.format(minvec))
		self.setOrigin(pts.average)
		self.setNormal(minvec)
		if (nd.LIB_DEBUG):
			self.print("plane (by points)")
		_n.ldprint('<-- nkj.primitiveshape.plane.setByPoints()')

	def setFromPoints(self, pts):
		self.setByPoints(pts)

	@property
	def by_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00554.")

	@by_points.setter
	def by_points(self, pts):
		self.setByPoints(pts)

	@property
	def from_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00642.")

	@from_points.setter
	def from_points(self, pts):
		self.setFromPoints(pts)

	def setByMatrix(self, m):
		self.setOrigin(m.getColumn3(3))
		self.setNormal(m.getColumn3(2))

	def setFromMatrix(self, m):
		self.setByMatrix(self, m)
	
	@property
	def by_matrix(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00657.")

	@by_matrix.setter
	def by_matrix(self, m):
		self.setByMatrix(m)

	@property
	def from_matrix(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00665.")

	@from_matrix.setter
	def from_matrix(self, m):
		self.setFromMatrix(m)

	def getMat3x4(self):
		zaxis = self.getNormal().normalized
		m = _ncs.mat3x4()
		m = zaxis.matrix(_ncs.ZAXISINDEX)
		m.setTranslation(self.getOrigin())
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	@property
	def m3x4(self):
		return self.getMat3x4()

	@property
	def mat3(self):
		return self.getMat3x4()

	@property
	def m3(self):
		return self.getMat3x4()

	def getMatrix(self):
		return self.getMat3x4()

	@property
	def matrix(self):
		return self.getMat3x4()

	@property
	def mat(self):
		return self.getMat3x4()

	@property
	def m(self):
		return self.getMat3x4()

	# Operators

	def multiply(self, second):
		if (second is None):
			raise Exception('__ERROR__: Null data.')
		if (_ncs.is_mat3x4(second)):
			pl = plane3()
			pl.setOrigin(_ncs.point3(second @ self.getOrigin()))
			pl.setNormal(_ncs.vec3(second @ self.getNormal()))
			return pl
		else:
			_n.print_error('second: {0} ({1})'.format(second, type(second)))
			raise Exception('__ERROR__: Not implemented.')

	def rmultiply(self, first):
		return self.multiply(first)

	# Geometrical computation

	def getAngle(self, x):
		v1 = self.getNormal()
		v2 = x.getNormal()
		return v1.getAngle(v2)

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	def crosssection(self, x):
		_n.ldprint('--> nkj.primitiveshape.plane3.crosssection()')
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (nd.LIB_DEBUG2):
			self.print('self')
			x.print('x')
		if (self.isinstance(x)):  # x is a plane. Return the crosssection line.
			pl1 = self
			pl2 = x
			nvec1 = pl1.normal.normalized
			nvec2 = pl2.normal.normalized
			crossvec = (nvec1 * nvec2).normalized
			line1 = line3([pl1.origin, nvec1 * crossvec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
			line2 = line3([pl2.origin, nvec2 * crossvec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
			origin = line1 & line2
			return line3([origin, crossvec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
		elif (is_line3(x)):  # x is a line. Return the crosssection point.
			line = x
			plane = self
			a_l, b_l, c_l = line.vector.components
			x0_l, y0_l, z0_l = line.origin.components
			a, b, c = plane.vector.components
			x0, y0, z0 = plane.origin.components
			t = (a * (x0 - x0_l) + b * (y0 - y0_l) + c * (z0 - z0_l)) / (a * a_l + b * b_l + c * c_l)
			x = a_l * t + x0_l
			y = b_l * t + y0_l
			z = c_l * t + z0_l
			return _ncs.vec3([x, y, z])
		else:
			raise Exception('__ERROR__: Not supported.')
		_n.ldprint('<-- nkj.primitiveshape.plane3.crosssection()')

	def crosspoint(self, x):
		return self.crosssection(x)

	def project2(self, x):
		return self.getMat3x4().project2(x)

	def project3(self, x):
		return self.getMat3x4().project3(x)

	def project(self, x):
		return self.project3(x)

	#
	# a * (x - x0) + b * (y - y0) + c * (z - z0) = 0
	#
	def getX(self, pt):
		a, b, c, x0, y0, z0 = self.parameterize()
		y = pt[0]
		z = pt[1]
		x = x0 if (_nm.is_ineps(a)) else x0 - (b * (y - y0) + c * (z - z0)) / a
		return z

	def getY(self, pt):  # 引数は◯ (x, z) であり、× (z, x) でないので注意すること．
		a, b, c, x0, y0, z0 = self.parameterize()
		x = pt[0]
		z = pt[1]
		y = y0 if (_nm.is_ineps(b)) else y0 - (c * (z - z0) + a * (x - x0)) / b
		return z

	def getZ(self, pt):
		a, b, c, x0, y0, z0 = self.parameterize()
		x = pt[0]
		y = pt[1]
		z = z0 if (_nm.is_ineps(c)) else z0 - (a * (x - x0) + b * (y - y0)) / c
		return z

	def X(self, pt):
		return self.getX(pt)

	def Y(self, pt):
		return self.getY(pt)

	def Z(self, pt):
		return self.getZ(pt)

	def x(self, pt):
		return self.getX(pt)

	def y(self, pt):
		return self.getY(pt)

	def z(self, pt):
		return self.getZ(pt)

	def getPointFromYZ(self, pt):
		return _nm.vec3([self.getX(pt), pt[0], pt[1]])

	def getPointFromXZ(self, pt):
		return _nm.vec3([pt[0], self.getY(pt), pt[1]])

	def getPointFromXY(self, pt):
		return _nm.vec3([pt[0], pt[1], self.getZ(pt)])

	def PointFromYZ(self, pt):
		return self.getPointFromYZ(pt)

	def PointFromXZ(self, pt):
		return self.getPointFromXZ(pt)

	def PointFromXY(self, pt):
		return self.getPointFromXY(pt)

	def point_from_yz(self, pt):
		return self.getPointFromYZ(pt)

	def point_from_xy(self, pt):
		return self.getPointFromXZ(pt)

	def point_from_xy(self, pt):
		return self.getPointFromXY(pt)

	def from_yz(self, pt):
		return self.getPointFromYZ(pt)

	def from_xy(self, pt):
		return self.getPointFromXZ(pt)

	def from_xy(self, pt):
		return self.getPointFromXY(pt)

	# Parameterization
	#
	# a * (x - x0) + b * (y - y0) + c * (z - z0) = 0
	#

	def getParameters(self):
		vec = self.getVector()
		orig = self.getOrigin()
		return [vec.x, vec.y, vec.z, orig.x, orig.y, orig.z]  # a, b, c, x0, y0, z0

	def setParameters(self, x):
		vec = _ncs.vec3([x[0], x[1], x[2]])
		orig = _ncs.vec3([x[3], x[4], x[5]])
		self.set([orig, vec])

	# Components

	def getComponents(self):
		clist = []
		for i in range(2):
			if (_nm.is_digit(self[i])):
				clist.append(self[i])
			else:
				clist.extend(self[i].getComponents())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != 6):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.setOrigin([x[0], x[1], x[2]])
		self.setNormal([x[3], x[4], x[5]])

	# Data string

	def getDataString(self):
		s = ''
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getComponent(i).getDataString())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.plane3.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		c = []
		ii = 0
		for j in range(2):
			c.clear()
			for i in range(3):
				c.append(data[ii])
				ii += 1
			self[j].setComponent(j, c)
		_n.ldprint('<-- nkj.primitiveshape.plane3.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		for i in range(2):
			if (i != 0):
				s += ', '
			s += '{}'.format(self.getComponent(i).getPrintString())
		return s

	# isinstace

	def isinstance(self, x):
		return is_plane3(x)

class plane3(plane3_cls):
	pass

class plane(plane3_cls):
	pass

def is_plane3(x):
	return isinstance(x, plane3_cls)

def is_plane(x):
	return is_plane3(x)


#-- Sphere class

class sphere3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.sphere3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(_DEFAULT_SPHERE if (x is None) else x)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_SPHERE if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.sphere.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		if (not (self.isinstance(x) or isinstance(x, (list, tuple, np.ndarray)))):
			raise TypeError("__ERROR__: Illegal data type.")
		
		dlen = len(x)
		_n.ldprint2("len(x): {}".format(dlen))
		
		if (dlen != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		
		if (_ncs.is_vec3(x[0])):
			pass
		elif (isinstance(x[0], (list, tuple, np.ndarray))):
			x[0] = _ncs.vec3(x[0])
		else:
			raise TypeError("__ERROR__: Illegal data type.")
		
		if (not _nm.is_digit(x[1])):
			raise TypeError("__ERROR__: Illegal data type.")
		
		self.clear()
		for i in range(dlen):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		
		if (nd.LIB_DEBUG):
			self[0].print("{0}".format(_n.classname(x[0])))
			print("{0}: {1}".format(_n.classname(x[1]), x[1]))
		_n.ldprint("<-- nkj.primitiveshape.sphere.set()")

	# Component

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		if (index == 0):
			if (_ncs.is_vec3(x)):
				pass
			elif (isinstance(x, (list, tuple, np.ndarray))):
				if (len(x) != 3):
					raise TypeError("__ERROR__: Illegal data type.")
				x = _ncs.vec3(x)
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		if (index == 1):
			if (not _nm.is_digit(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		self[index] = x

	def getOrigin(self):
		return self.getComponent(0)

	def setOrigin(self, x):
		self.setComponent(0, x)

	def Origin(self, x=None):
		if (x is None):
			return self.getOrigin()
		else:
			self.setOrigin(x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	def Radius(self, x=None):
		if (x is None):
			return self.getRadius()
		else:
			self.setRadius(x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	# Parameterization
	#
	# (x - x0)^2 + (y - y0)^2 + (z - z0)^2 = r^2
	#

	def getParameters(self):
		orig = self.getOrigin()
		radius = self.getRadius()
		return [orig.x, orig.y, orig.z, radius]  # x0, y0, z0, r

	def setParameters(self, x):
		orig = _ncs.vec3([x[0], x[1], x[2]])
		radius = x[3]
		self.set([orig, radius])

	# Operators

	def rmultiply(self, first):
		if (_ncs.is_mat3x3(first)):
			list = []
			list.append(_ncs.vec3(first @ self.getOrigin()))
			list.append(self.getRadius())
			return sphere3(list)
		elif (_ncs.is_mat3x4(first)):
			list = []
			list.append(_ncs.vec3(first @ self.getOrigin().h))
			list.append(self.getRadius())
			return sphere3(list)
		elif (_ncs.is_mat4x4(first)):
			list = []
			list.append(_ncs.vec3((first @ self.getOrigin().h).ih))
			list.append(self.getRadius())
			return sphere3(list)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Components

	def getComponents(self):
		clist = []
		clist.extend(self.getOrigin().getComponents())
		clist.append(self.getRadius())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != 4):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.setOrigin([x[0], x[1], x[2]])
		self.setRadius(x[3])

	# Data string

	def getDataString(self):
		s = ''
		s += '{}'.format(self.getOrigin().getDataString())
		s += ', '
		s += '{:21.12f}'.format(self.getRadius())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.plane3.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		c = []
		ii = 0
		for i in range(3):
			c.append(data[ii])
			ii += 1
		self.setComponent(0, _ncs.vec3(c))
		self.setComponent(1, data[ii])
		_n.ldprint('<-- nkj.primitiveshape.plane3.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getOrigin().getPrintString())
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	#  isinstance

	def isinstance(self, x):
		return is_sphere3(x)

class sphere3(sphere3_cls):
	pass

class sphere(sphere3_cls):
	pass

def is_sphere3(x):
	return isinstance(x, sphere3_cls)

def is_sphere(x):
	return is_sphere3(x)


#-- Circle classes

class circle2_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.circle2'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(_DEFAULT_CIRCLE2 if (x is None) else x)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_CIRCLE2 if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.circle2.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		
		if (not isinstance(x, (list, tuple))):
			raise TypeError("__ERROR__: Illegal data type.")
		
		dlen = len(x)
		_n.ldprint2("len(x): {}".format(dlen))
		if (dlen != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		
		_n.ldprint("x: {0} ({1})".format(x, type(x)))
		
		if (not _ncs.is_vec2(x[0])):
			if (isinstance(x[0], (list, tuple, np.ndarray))):
				x[0] = _ncs.vec2(x[0])
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		
		if (not _nm.is_digit(x[1])):
			raise TypeError("__ERROR__: Illegal data type.")
		
		self.clear()
		for i in range(dlen):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		
		if (nd.LIB_DEBUG):
			self[0].print("{0}".format(_n.classname(x[0])))
			print("{0}: {1}".format(_n.classname(x[1]), x[1]))
		
		_n.ldprint("<-- nkj.primitiveshape.circle2.set()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		if (index == 0):
			if (not _ncs.is_vec2(x)):
				if (isinstance(x, (list, tuple, np.ndarray))):
					x = _ncs.vec2(x)
				else:
					raise TypeError("__ERROR__: Illegal data type.")
		elif (index == 1):
			if (not _nm.is_digit(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		else:
			raise ValueError('__ERROR__: Illegal index.')
		self[index] = x

	def getOrigin(self):
		return self.getComponent(0)

	def setOrigin(self, x):
		self.setComponent(0, x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	# Parameterization
	#
	# (x - x0)^2 + (y - y0)^2 = r^2
	#

	def getParameters(self):
		orig = self.getOrigin()
		radius = self.getRadius()
		return [orig.x, orig.y, radius]  # x0, y0, r

	def setParameters(self, x):
		orig = _ncs.vec2([x[0], x[1]])
		radius = x[2]
		self.set([orig, radius])

	# Operators

	def rmultiply(self, first):
		if (_ncs.is_mat2x2(first)):
			newl = []
			newl.append(_ncs.point2(first @ self.getOrigin()))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat2x3(first)):
			newl = []
			newl.append(_ncs.point2(first @ self.getOrigin().h))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat3x3(first)):
			newl = []
			newl.append(_ncs.point2((first @ self.getOrigin().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Components

	def getComponents(self):
		clist = []
		clist.extend(self.getOrigin().getComponents())
		clist.append(self.getRadius())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != 3):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.setOrigin([x[0], x[1]])
		self.setRadius(x[2])

	# Data string

	def getDataString(self):
		s = ''
		s += '{}'.format(self.getOrigin().getDataString())
		s += ', '
		s += '{:21.12f}'.format(self.getRadius())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.circle2.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		self.setOrigin([data[0], data[1]])
		self.setRadius(data[2])
		_n.ldprint('<-- nkj.primitiveshape.circle2.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getOrigin().getPrintString())
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	# isinstance

	def isinstance(self, x):
		return is_circle2(x)

class circle2(circle2_cls):
	pass

class circle(circle2_cls):
	pass

class arc2(circle2_cls):
	pass

class arc(circle2_cls):
	pass

def is_circle2(x):
	return isinstance(x, circle2_cls)

def is_circle(x):
	return is_circle2(x)

def is_arc2(x):
	return is_circle2(x)

def is_arc(x):
	return is_circle2(x)


class circle3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshapes.circle3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(_DEFAULT_CIRCLE3 if (x is None) else x)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_CIRCLE3 if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint("--> nkj.primitiveshape.circle3.set()")
		if (x is None):
			raise ValueError("__ERROR__: Value is None.")
		
		if (not isinstance(x, (list, tuple))):
			raise TypeError("__ERROR__: Illegal data type.")
		
		dlen = len(x)
		_n.ldprint2("len(x): {}".format(dlen))
		if (dlen != 2):
			raise TypeError("__ERROR__: Illegal data type.")
		
		_n.ldprint("x: {0} ({1})".format(x, type(x)))
		
		if (_ncs.is_mat3x4(x[0])):
			pass
		elif (_ncs.is_mat4x4(x[0])):
			x[0] = x[0].mat3x4
		elif (isinstance(x[0], (list, tuple, np.ndarray))):
			x[0] = _ncs.mat3x4(x[0])
		else:
			_n.print_error("x[0]: {0}, classname: \'{1}\'".format(x[0], _ns.classname(x[0])))
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01034.")
		
		if (not _nm.is_digit(x[1])):
			_n.print_error("x[1]: {0}, classname: \'{1}\'".format(x[1], _ns.classname(x[1])))
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01036.")
		
		self.clear()
		for i in range(dlen):
			_n.ldprint("class name: {}".format(_n.classname(x[i])))
			self.append(x[i])
		
		if (nd.LIB_DEBUG):
			self[0].print("{0}".format(_n.classname(x[0])))
			print("{0}: {1}".format(_n.classname(x[1]), x[1]))
		
		_n.ldprint("<-- nkj.primitiveshape.circle3.set()")

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		return self[index]

	def setComponent(self, index, x):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError("__ERROR__: Illegal index.")
		
		if (index == 0):
			if (_ncs.is_mat3x4(x)):
				pass
			elif (_ncs.is_mat4x4(x)):
				x = x.mat3x4
			elif (isinstance(x, (list, tuple, np.ndarray))):
				x = _ncs.mat3x4(x)
			else:
				raise TypeError("__ERROR__: Illegal data type.")
		elif (index == 1):
			if (not _nm.is_digit(x)):
				raise TypeError("__ERROR__: Illegal data type.")
		
		self[index] = x

	def getMatrix(self):
		return self.getComponent(0)

	def setMatrix(self, x):
		self.setComponent(0, x)

	@property
	def matrix(self):
		return self.getMarix()

	@matrix.setter
	def matrix(self, x):
		self.setMatrix(x)

	@property
	def mat(self):
		return self.getMarix()

	@mat.setter
	def mat(self, x):
		self.setMatrix(x)

	def getOrigin(self):
		return self.getMatrix().getTranslation()

	def setOrigin(self, x):
		m = self.getMatrix()
		m.setTranslation(x)
		self.setComponent(0, m)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getNormalVector(self):
		return self.getMatrix().zaxis

	def getNormal(self):
		return self.getNormalVector()

	def getVector(self):
		return self.getNormalVector()

	@property
	def normal(self):
		return self.getNormalVector()

	@property
	def n(self):
		return self.getNormalVector()

	@property
	def vector(self):
		return self.getNormalVector()

	@property
	def vec(self):
		return self.getNormalVector()

	@property
	def v(self):
		return self.getNormalVector()

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	# Parameterization
	#
	# (x - x0)^2 + (y - y0)^2 + (z - z0)^2 = r^2
	#

	def getParameters(self):
		orig = self.getOrigin()
		n = self.getNormal()
		radius = self.getRadius()
		return [orig.x, orig.y, orig.z, n.x, n.y, n.z, radius]  # x0, y0, z0, nx, ny, nz, r

	def setParameters(self, x):
		raise Exception('__ERROR__: Not implemented.')

	# Operators

	def rmultiply(self, first):
		if (_ncs.is_mat3x3(first)):
			newl = []
			newl.append(_ncs.mat3x4((first.mat3x4.h @ self.getMatrix().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat3x4(first)):
			newl = []
			newl.append(_ncs.mat3x4((first.h @ self.getMatrix().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		elif (_ncs.is_mat4x4(first)):
			newl = []
			newl.append(_ncs.mat3x4((first @ self.getMatrix().h).ih))
			newl.append(self.getRadius())
			return plane(newl)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Components

	def getComponents(self):
		clist = []
		clist.extend(self.getMatrix().getComponents())
		clist.append(self.getRadius())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != 13):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.setMatrix([[x[0], x[1], x[2], x[3]], [x[4], x[5], x[6], x[7]], [x[8], x[9], x[10], x[11]]])
		self.setRadius(x[12])

	# Data string

	def getDataString(self):
		s = ''
		s += '{}'.format(self.getMatrix().getDataString())
		s += ', '
		s += '{:21.12f}'.format(self.getRadius())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.circle3.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		m = _ncs.mat3x4()
		for j in range(3):
			for i in range(4):
				m[j, i] = data[4 * j + i]
		self.setMatrix(m)
		self.setRadius(data[12])
		_n.ldprint('<-- nkj.primitiveshape.circle3.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(_ns.bracket(self.getMatrix().getDataString(), '()'))
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	# isinstance

	def isinstance(self, x):
		return is_circle3(x)

class circle3(circle3_cls):
	pass

def is_circle3(x):
	return isinstance(x, circle3_cls)


#-- Arc class

"""
class arc3_cls(circle3_cls):
	_classname = 'nkj.primitiveshapes.arc3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		self.set(_DEFAULT_ARC3 if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x):
		if (x is None):
			raise ValueError('__ERROR__: Null input.')
		raise Exception('__ERROR__: Not implemented.')  # No implementation

class arc3(arc3_cls):
	pass

def is_arc3(x):
	return isinstance(x, arc3_cls)
"""


#-- Cylinder class

class cylinder3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshape.cylinder'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(_DEFAULT_CYLINDER if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	"""
	def __rmatmul__(self, first):
		return self.rmultiply(first)
	"""

	def get(self):
		return self.getComponents()

	def set(self, x=None):
		if (x is None):
			raise ValueError('__ERROR__: Null input.')
		if (self.isinstance(x)):
			axis, radius = x.components
		elif (isinstance(x, (list, tuple, np.ndarray))):
			if (len(x) != 2):
				raise TypeError('__ERROR__: Illegal data.')
			axis = x[0] if (is_line3(x[0])) else line3(x[0])
			if (_nm.is_digit(x[1])):
				radius = x[1]
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		self.clear()
		self.append(axis)
		self.append(radius)

	# Component

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise ValueError('__ERROR__: Illegal index.')
		return self[index]

	def setComponent(self, index, x):
		if (index == 0):
			self[0] = x if (is_line3(x)) else line3(x)
		elif (index == 1):
			if (_nm.is_digit(x)):
				self[1] = x
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		else:
			raise ValueError('__ERROR__: Illegal index.')

	def getLine(self):
		return self.getComponent(0)

	def setLine(self, x):
		self.setComponent(0, x)

	def Line(self, x=None):
		if (x is None):
			return self.getLine()
		else:
			self.setLine(x)

	@property
	def line(self):
		return self.getLine()

	@line.setter
	def line(self, x):
		self.setLine(x)

	def getAxis(self):
		return self.getLine()

	def setAxis(self, x):
		self.setLine(x)

	def Axis(self, x=None):
		if (x is None):
			return self.getLine()
		else:
			self.setLine(x)

	@property
	def axis(self):
		return self.getLine()

	@axis.setter
	def axis(self, x):
		self.setLine(x)

	def getOrigin(self):
		return self.getLine().getOrigin()

	def setOrigin(self, x):
		self.getLine().setOrigin(x)

	def Origin(self, x=None):
		if (x is None):
			return self.getOrigin()
		else:
			self.setOrigin(x)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, x):
		self.setOrigin(x)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, x):
		self.setOrigin(x)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, x):
		self.setOrigin(x)

	def getLength(self):
		return self.getLine().getLength()

	def setLength(self, x):
		return self.getLine().setLength(x)

	def Length(self, x=None):
		if (x is None):
			return self.getLength()
		else:
			self.setLength(x)

	@property
	def length(self):
		return self.getLength()

	@length.setter
	def length(self, x):
		self.setLength(x)

	@property
	def len(self):
		return self.getLength()

	@len.setter
	def len(self, x):
		self.setLength(x)

	@property
	def l(self):
		return self.getLength()

	@l.setter
	def l(self, x):
		self.setLength(x)

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	def Radius(self, x=None):
		if (x is None):
			return self.getRadius()
		else:
			self.setRadius(x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	# Serialization

	def getRadius(self):
		return self.getComponent(1)

	def setRadius(self, x):
		self.setComponent(1, x)

	def Radius(self, x=None):
		if (x is None):
			return self.getRadius()
		else:
			self.setRadius(x)

	@property
	def radius(self):
		return self.getRadius()

	@radius.setter
	def radius(self, x):
		self.setRadius(x)

	@property
	def r(self):
		return self.getRadius()

	@r.setter
	def r(self, x):
		self.setRadius(x)

	# Parameterization
	#
	# axis([[p0.x, p0.y, p0.z], [p1.x, p1.y, p1.z]]), radius
	#

	def getParameters(self):
		axis = self.getAxis()
		radius = self.getRadius()
		return [axis.p0.x, axis.p0.y, axis.p0.z, axis.p1.x, axis.p1.y, axis.p1.z, radius]

	def setParameters(self, x):
		axis = _ncs.line3([[x[0], x[1], x[2]], [x[3], x[4], x[5]]])
		radius = x[6]
		self.set([axis, radius])

	# Components

	def getComponents(self):
		clist = []
		clist.extend(self.getAxis().getComponents())
		clist.append(self.getRadius())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != 7):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.setAxis([[x[0], x[1], x[2]], [x[3], x[4], x[5]]])
		self.setRadius(x[6])

	# Data string

	def getDataString(self):
		s = ''
		s += '{}'.format(self.getAxis().getDataString())
		s += ', '
		s += '{:21.12f}'.format(self.getRadius())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.cone3.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		self.set([[[data[0], data[1], data[2]], [data[3], data[4], data[5]]], data[6]])
		_n.ldprint('<-- nkj.primitiveshape.cone3.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getAxis().getPrintString())
		s += ', '
		s += '{:12.6f}'.format(self.getRadius())
		return s

	# isinstance

	def isinstance(self, x):
		return is_cylinder3(x)

class cylinder3(cylinder3_cls):
	pass

class cylinder(cylinder3):
	pass

class pipe3(cylinder3_cls):
	pass

class pipe(pipe3):
	pass

def is_cylinder3(x):
	return isinstance(x, cylinder3_cls)

def is_cylinder(x):
	return is_cylinder3(x)

def is_pipe3(x):
	return is_cylinder3(x)

def is_pipe(x):
	return is_cylinder3(x)


#-- Cone class

class cone3_cls(primitiveshape_cls):
	_classname = 'nkj.primitiveshape.cone3'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(_DEFAULT_CONE if (x is None) else x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented.")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def get(self):
		return self.getComponents()

	def set(self, x=None):
		if (x is None):
			raise ValueError('__ERROR__: Null input.')
		if (self.isinstance(x)):
			basecenter, tip, baseradius = x.components
		elif (isinstance(x, (list, tuple, np.ndarray))):
			if (len(x) != 3):
				raise TypeError('__ERROR__: Illegal data.')
			basecenter = x[0] if (_ncs.is_vec3(x[0])) else _ncs.vec3(x[0])
			tip = x[1] if (_ncs.is_vec3(x[1])) else _ncs.vec3(x[1])
			if (_nm.is_digit(x[2])):
				baseradius = x[2]
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		self.clear()
		self.append(basecenter)
		self.append(tip)
		self.append(baseradius)

	# Parameterization
	#
	# center([x, y, z]), tip([x, y, z]), radius
	#

	def getParameters(self):
		center = self.getCenter()
		tip = self.getTip()
		radius = self.getRadius()
		return [center.x, center.y, center.z, tip.x, tip.y, tip.z, radius]

	def setParameters(self, x):
		center = _ncs.vec3([x[0], x[1], x[2]])
		tip = _ncs.vec3([x[3], x[4], x[5]])
		radius = x[6]
		self.set([center, tip, radius])

	# Component

	def getComponent(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise ValueError('__ERROR__: Illegal index.')
		return self[index]

	def setComponent(self, index, x):
		if (index == 0):
			self.setBaseCenter(x)
		elif (index == 1):
			self.setTip(x)
		elif (index == 2):
			self.setBaseRadius(x)
		else:
			raise ValueError('__ERROR__: Illegal index.')

	def Component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def component(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def comp(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def c(self, index, x=None):
		if (x is None):
			return self.getComponent(index)
		else:
			self.setComponent(index, x)

	def getBaseCenter(self):
		return self[0]

	def setBaseCenter(self, x):
		self[0] = x if (_ncs.is_vec3(x)) else _ncs.vec3(x)

	def BaseCenter(self, x=None):
		if (x is None):
			return self.getBaseCenter()
		else:
			self.setBaseCenter(x)

	@property
	def basecenter(self):
		return self.getBaseCenter()

	@basecenter.setter
	def basecenter(self, x):
		self.setBaseCenter(x)

	def getCenter(self):
		return self.getBaseCenter()

	def setCenter(self, x):
		self.setBaseCenter(x)

	def Center(self, x=None):
		if (x is None):
			return self.getBaseCenter()
		else:
			self.setBaseCenter(x)

	@property
	def center(self):
		return self.getBaseCenter()
	
	@center.setter
	def center(self, x):
		self.setBaseCenter(x)

	@property
	def cen(self):
		return self.getBaseCenter()

	@cen.setter
	def cen(self, x):
		self.setBaseCenter(x)

	@property
	def c(self):
		return self.getBaseCenter()

	@c.setter
	def c(self, x):
		self.setBaseCenter(x)

	def getOrigin(self):
		return self.getBaseCenter()

	def setOrigin(self, x):
		self.setBaseCenter(x)

	def Origin(self, x=None):
		if (x is None):
			return self.getOrigin()
		else:
			self.setOrigin(x)

	@property
	def origin(self):
		return self.getBaseCenter()

	@origin.setter
	def origin(self, x):
		self.setBaseCenter(x)

	@property
	def orig(self):
		return self.getBaseCenter()

	@orig.setter
	def orig(self, x):
		self.setBaseCenter(x)

	@property
	def o(self):
		return self.getBaseCenter()

	@o.setter
	def o(self, x):
		self.setBaseCenter(x)

	def getTip(self):
		return self[1]

	def setTip(self, x):
		self[1] = x if (_ncs.is_vec3(x)) else _ncs.vec3(x)

	def Tip(self, x=None):
		if (x is None):
			return self.getTip()
		else:
			self.setTip(x)

	@property
	def tip(self):
		return self.getTip()

	@tip.setter
	def tip(self, x):
		self.setTip(x)

	def getTop(self):
		return self.getTip()

	def setTop(self, x):
		self.setTop(x)

	def Top(self, x=None):
		if (x is None):
			return self.getTop()
		else:
			self.setTop(x)

	@property
	def top(self):
		return self.getTop()

	@tip.setter
	def top(self, x):
		self.setTop(x)

	def getAxis(self):
		return _nps.line3([self.getBaseCenter(), self.getTip()])

	def setAxis(self, x):
		x = x if (is_line3(x)) else line3(x)
		set.setBaseCenter(x.getPoint(0))
		set.setTip(x.getPoint(1))

	def Axis(self, x=None):
		if (x is None):
			return self.getAxis()
		else:
			self.setAxis(x)

	@property
	def axis(self):
		return self.getAxis()

	@axis.setter
	def axis(self, x):
		self.setAxis(x)

	def getAxisComponent(self, index):
		return self.getAxis().getComponent(index)

	def setAxisComponent(self, index, x):
		self.getAxis().setComponent(index, x if (_ncs.is_vec3(x)) else _ncs.vec3(x))

	def AxisComponent(self, index, x=None):
		if (x is None):
			return self.getAxisComponent(index)
		else:
			self.setAxisComponent(index, x)

	def axiscomponent(self, index, x=None):
		if (x is None):
			return self.getAxisComponent(index)
		else:
			self.setAxisComponent(index, x)

	def getBaseRadius(self):
		return self[2]

	def setBaseRadius(self, x):
		if (not _nm.is_digit(x)):
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01466.")
		self[2] = x

	def BaseRadius(self, x=None):
		if (x is None):
			return self.getBaseRadius()
		else:
			self.setBaseRadius(x)

	@property
	def baseradius(self):
		return self.getBaseRadius()

	@baseradius.setter
	def baseradius(self, x):
		self.setBaseRadius(x)

	def getRadius(self):
		return self.getBaseRadius()

	def setRaidus(self, x):
		self.setBaseRadius(x)

	def Radius(self, x=None):
		if (x is None):
			return self.getBaseRadius()
		else:
			self.setBaseRadius(x)

	@property
	def radius(self):
		return self.getBaseRadius()

	@radius.setter
	def radius(self, x):
		self.setBaseRadius(x)

	@property
	def r(self):
		return self.getBaseRadius()

	@r.setter
	def r(self, x):
		self.setBaseRadius(x)

	def getHeight(self):
		return self.getAxis().getLength()

	def setHeight(self, x):
		return self.getAxis().setLength(x)

	@property
	def height(self):
		return self.getHeight()

	@height.setter
	def height(self, x):
		self.setHeight(x)

	@property
	def h(self):
		return self.getHeight()

	@h.setter
	def h(self, x):
		self.setHeight(x)

	def getVector(self):
		return self.getAxis().getVector()

	@property
	def vector(self):
		return self.getVector()

	@property
	def vec(self):
		return self.getVector()

	@property
	def v(self):
		return self.getVector()

	def getDirection(self):
		return self.getAxis().getVector()

	@property
	def direction(self):
		return self.getDirection()

	@property
	def direct(self):
		return self.getDirection()

	def getMatrix(self):
		return self.getAxis().getMat3x4()

	@property
	def matrix(self):
		return self.getMatrix()

	@property
	def mat(self):
		return self.getMatrix()

	@property
	def m(self):
		return self.getMatrix()

	# Operations

	def rmultiply(self, first):
		if (_ncs.is_mat3x3(first)):
			newl = []
			newl.append(_ncs.vec3(first @ self.getBaseCenter()))
			newl.append(_ncs.vec3(first @ self.getTip()))
			newl.append(self.getBaseRadius())
			return cone3(newl)
		elif (_ncs.is_mat3x4(first)):
			newl = []
			newl.append(_ncs.vec3((first @ self.getBaseCenter().h).ih))
			newl.append(_ncs.vec3((first @ self.getTip().h).ih))
			newl.append(self.getBaseRadius())
			return cone3(newl)
		elif (_ncs.is_mat4x4(first)):
			newl = []
			newl.append(_ncs.vec3((first @ self.getBaseCenter().h).ih))
			newl.append(_ncs.vec3((first @ self.getTip().h).ih))
			newl.append(self.getRadius())
			return cone3(newl)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Goemetic computation

	def _crosssections_for_line(self, x):
		_n.ldprint(["--> nkj.primitiveshape.cone3._crosssections_for_line()"])
		cone = self
		line = x if (_nps.is_line3(x)) else _nps.line3(x)
		_n.ldprint(["Cone: {0}".format(cone)])
		_n.ldprint(["Line: {0}".format(line)])
		
		h = cone.height
		r = cone.radius
		_n.ldprint(["Cone height: {0}".format(h)])
		_n.ldprint(["Cone radius: {0}".format(r)])
		
		k = _nm.sq(h) / (_nm.sq(h) + _nm.sq(r))
		p = np.array(line_origin(line))
		d = np.array(line_vector(line))
		p_norm = np.linalg.norm(p)
		d_norm = np.linalg.norm(d)
		A = k * _nm.sq(d_norm) - _nm.sq(d[1])
		B = k * np.dot(p, d) - p[1] * d[1]
		C = k * _nm.sq(p_norm) - _nm.sq(p[1])
		D = _nm.sq(B) - A * C
		if (D > 0.0):
			t0 = (-B - np.sqrt(D)) / A
			t1 = (-B + np.sqrt(D)) / A
			_n.ldprint(["t0: {0}".format(t0)])
			_n.ldprint(["t1: {0}".format(t1)])
			cpt1 = tuple(p + d * t0) # Due to t0 < t1, t0 should be the point close to the focal point.
			cpt2 = tuple(p + d * t1) # Due to t0 < t1, t0 should be the point close to the focal point.
			_n.ldprint(["Cross point[0]: {0}".format(cpt1)])
			_n.ldprint(["Cross point[1]: {0}".format(cpt2)])
			cone_residue1 = np.sqrt(sq(cpt1[0]) + sq(cpt1[2])) + r * cpt1[1] / h
			cone_residue2 = np.sqrt(sq(cpt2[0]) + sq(cpt2[2])) + r * cpt2[1] / h
			line_residue1 = line.distance(cpt1)
			line_residue2 = line.distance(cpt2)
			_n.ldprint(["Cone residue[0]: {0}".format(cone_residue1)])
			_n.ldprint(["Cone residue[1]: {0}".format(cone_residue2)])
			_n.ldprint(["Line residue[0]: {0}".format(line_residue1)])
			_n.ldprint(["Line residue[1]: {0}".format(line_residue2)])
			retval = cpt1, cpt2, [[cone_residue1, line_residue1], [cone_residue2, line_residue2]]
		else:
			retval = None
		_n.ldprint(["<-- nkj.primitiveshape.cone3._crosssections_for_line()"])
		return retval

	def getCrosssectionPoints(self, x):
		if (_nps.is_line3(x)):
			return crosssections_for_line(x)
		else:
			raise Exception('__ERROR__: Not supported.')

	def CrosssectionPoints(self, x):
		return self.getCrosssectionPoints(x)
	
	def crosssection_points(self, x):
		return self.getCrosssectionPoints(x)
	
	def crosssectionpoints(self, x):
		return self.getCrosssectionPoints(x)
	
	def Crosssections(self, x):
		return self.getCrosssectionPoints(x)
	
	def crosssections(self, x):
		return self.getCrosssectionPoints(x)

	# Components

	def getComponents(self):
		clist = []
		clist.extend(self.getOrigin().getComponents())
		clist.extend(self.getTip().getComponents())
		clist.append(self.getBaseRadius())
		return clist

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data.')
		if (len(x) != 7):
			_ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		self.setOrigin([x[0], x[1], x[2]])
		self.setTip([x[3], x[4], x[5]])
		self.setBaseRadius(x[6])

	# Data string

	def getDataString(self):
		s = ''
		s += '{}'.format(self.getBaseCenter().getDataString())
		s += ', '
		s += '{}'.format(self.getTip().getDataString())
		s += ', '
		s += '{:21.12f}'.format(self.getBaseRadius())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.cone3.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		self.set([[data[0], data[1], data[2]], [data[3], data[4], data[5]], data[6]])
		_n.ldprint('<-- nkj.primitiveshape.cone3.setDataString()')

	# Print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '{}'.format(self.getBaseCenter().getPrintString())
		s += ', '
		s += '{}'.format(self.getTip().getPrintString())
		s += ', '
		s += '{}'.format(self.getBaseRadius())
		return s

	# isinstance

	def isinstance(self, x):
		return is_cone3(x)

class cone3(cone3_cls):
	pass

class cone(cone3_cls):
	pass

def is_cone3(x):
	return isinstance(x, cone3_cls)

def is_cone(x):
	return is_cone3(x)


#-- List classes

class linexlist_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.primitiveshape.linexlist'
	_componentclass = None

	# Data string

	def getDataString(self, separator='\n'):
		_n.ldprint('--> nkj.primitiveshape.linexlist.getDataString()')
		s = ''
		for i in range(len(self)):
			c = self[i]
			if (i != 0):
				s += ', '
			s += '{}'.format(c.getDataString())
			s += separator
		_n.ldprint('datastring: \'{}\''.format(s))
		_n.ldprint('<-- nkj.primitiveshape.linexlist.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.linexlist.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
		_n.ldprint('list[{0}]: {1}'.format(len(data), data))
		c = []
		ii = 0
		for j in range(2):
			c.clear()
			for i in range(self.getComponent(0).vdim):
				c.append(data[ii])
				ii += 1
			_n.ldprint('component[{0}]: {1} ({2})'.format(j, c, type(c)))
			self.setComponent(j, self.componentclass(c))
		_n.ldprint('<-- nkj.primitiveshape.linexlist.setDataString()')


class line2list_cls(linexlist_cls):
	_classname = 'nkj.primitiveshape.line2list'
	_componentclass = line2

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(x)
		self.dataheader(_nl.DATAHEADER_INDEX_SINGLELINE)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	def set(self, x):
		_n.ldprint('--> nkj.primitiveshape.line2list.set()')
		self.clear()
		self.append(x)
		if (nd.LIB_DEBUG):
			self.print('self (line2list)')
		_n.ldprint('<-- nkj.primitiveshape.line2list.set()')
	
	def append(self, x):
		_n.ldprint('--> nkj.primitiveshape.line2list.append()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		if (x is None):
			pass
		elif (self.isinstance(x)):  # line2list
			super().extend(x)
		elif (is_line2(x)):  # line2
			super().append(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			ndim = np.array(x).ndim
			_n.ldprint('ndim: {}'.format(ndim))
			if (ndim == 2):  # line2
				super().append(line2(x))
			elif (ndim == 3):
				if (len(x) == 0):
					raise Exception('__ERROR__: Illegal algorithm. Null line-list.')
				for line in x:
					_n.ldprint2('line:           {}'.format(line))
					_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
					if (is_line2(line)):
						_n.ldprint2('line2 class')
						pass
					elif (isinstance(line, (list, tuple, np.ndarray))):
						_n.ldprint2('list, tuple, np.ndarray')
						line = line2(line)
					else:
						raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01233.")
					_n.ldprint2('line:           {}'.format(line))
					_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
					self.append(line)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01253.")
		_n.ldprint('<-- nkj.primitiveshape.line2list.append()')

	# Functions

	def getVanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		_n.ldprint('--> nkj.primitiveshape.line2list.getVanishingPoint(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
		anglethresh = 0.0 if (anglethresh is None) else anglethresh
		vptlist = _ncs.vec2list()
		for i in range(len(self)):
			for j in range(i + 1, len(self)):
				l1, l2 = self[i], self[j]
				angle = abs(Angle(l1, l2))
				_n.ldprint('angle: {:.6f} [deg]'.format(_nm.rad2deg(angle)))
				if (angle > anglethresh and abs(angle - _nm.deg2rad(180.0)) > anglethresh):
					_n.ldprint2('appended')
					vptlist.append(l1.crosssection(l2))
				else:
					_n.ldprint2('passed')
		if (nd.LIB_DEBUG):
			vptlist.print('crosssection points of l1 and l2: ')
		if (len(vptlist) == 0):
			_n.ldprint('No crosssection point')
			vtp = None
		else:
			vpt = vptlist.gravity
			if (nd.LIB_DEBUG):
				vpt.print('vanishing point')
		#
		# vanishing point と、直線からの距離や垂直二等分点からの距離で、データを取捨選択したいならここで実装．
		#
		_FINE_VERNISHING = True
		if (_FINE_VERNISHING and (vpt is not None)):
			_n.ldprint('->> Fine tuning.')
			vptlist.clear()
			for i in range(len(self)):
				for j in range(i + 1, len(self)):
					l1, l2 = self[i], self[j]
					angle = abs(Angle(l1, l2))
					_n.ldprint('angle: {:.6f} [deg]'.format(_nm.rad2deg(angle)))
					if (angle > anglethresh and abs(angle - _nm.deg2rad(180.0)) > anglethresh):
						_n.ldprint2('appended')
						vpt_candidate = l1.crosssection(l2)
						dist = (vpt_candidate - vpt).norm
						_n.ldprint('distance: {:.6f}'.format(dist))
						if (dist < _nm.distance_thresh()):
							vptlist.append(vpt_candidate)
					else:
						_n.ldprint2('passed')
		if (nd.LIB_DEBUG):
			vptlist.print('crosssection points of l1 and l2: ')
		if (len(vptlist) == 0):
			_n.ldprint('No crosssection point')
			vpt = None
		else:
			vpt = vptlist.gravity
			if (nd.LIB_DEBUG):
				vpt.print('vanishing point')
		_n.ldprint('<-- nkj.primitiveshape.line2list.getVanishingPoint()')
		return vpt

	def VanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(self, anglethresh)

	def vanishingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def vanishing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def getConversingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def ConversingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		self.getConversingPoint(self, anglethresh)

	def conversingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	def conversing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	# Data string

	def getDataString(self, rowend=None, separator='\n'):
		s = ''
		for i in range(len(self)):
			if (i != 0):
				s += separator
			c = self[i]
			s += '{}'.format(c.getDataString())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.linex.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		while (s[-1] == '\n'):
			s = s[:-1]
		slist = s.split('\n')
		if (nd.LIB_DEBUG):
			print('string list: {}'.format(slist))
		self.clear()
		for s in slist:
			_n.ldprint('string: {}'.format(s))
			data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
			_n.ldprint('list[{0}]: {1}'.format(len(data), data))
			self.append(self.componentclass([[data[0], data[1]], [data[2], data[3]]]))
		_n.ldprint('<-- nkj.primitiveshape.linex.setDataString()')

	# isinstance

	def isinstance(self, x):
		return is_line2list(x)

class line2list(line2list_cls):
	pass

class line2s(line2list_cls):
	pass

def is_line2list(x):
	return isinstance(x, line2list_cls)

def is_line2s(x):
	return is_line2list(x)


class line3list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.primitiveshape.line3list'
	_componentclass = line3

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.set(x)
		self.dataheader(_nl.DATAHEADER_INDEX_SINGLELINE)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	def getComponentClass(cls):
		return cls._componentclass

	@classmethod
	@property
	def componentclass(cls):
		return cls.getComponentClass()

	def set(self, x):
		_n.ldprint('--> nkj.primitiveshape.line3list.set()')
		self.clear()
		self.append(x)
		if (nd.LIB_DEBUG):
			self.print('self (line3list)')
		_n.ldprint('<-- nkj.primitiveshape.line3list.set()')
	
	def append(self, x):
		_n.ldprint('--> nkj.primitiveshape.line3list.append()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		if (x is None):
			pass
		elif (self.isinstance(x)):  # line3list
			super().extend(x)
		elif (is_line3(x)):  # line3
			super().append(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			ndim = np.array(x).ndim
			_n.ldprint('ndim: {}'.format(ndim))
			if (ndim == 2):  # line3
				super().append(line3(x))
			elif (ndim == 3):
				if (len(x) == 0):
					raise Exception('__ERROR__: Illegal algorithm. Null line-list.')
				for line in x:
					_n.ldprint2('line:           {}'.format(line))
					_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
					if (is_line3(line)):
						_n.ldprint2('line3 class')
						pass
					elif (isinstance(line, (list, tuple, np.ndarray))):
						_n.ldprint2('list, tuple, np.ndarray')
						line = line3(line)
					else:
						raise TypeError("__ERROR__: Illegal data type.")
					_n.ldprint2('line:           {}'.format(line))
					_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
					self.append(line)
		else:
			raise TypeError("__ERROR__: Illegal data type.")
		_n.ldprint('<-- nkj.primitiveshape.line3list.append()')

	"""
	def set(self, x):
		_n.ldprint('--> nkj.primitiveshape.line3list.set()')
		_n.ldprint('x:           {}'.format(x))
		_n.ldprint('x.classname: \'{}\''.format(_n.classname(x)))
		if (x is None):
			pass
		elif (isinstance(x, (list, tuple))):
			if (len(x) == 0):
				raise Exception('__ERROR__: Illegal algorithm. NKJ-PRIMITIVESHAPE-01248.')
			for line in x:
				_n.ldprint2('line:           {}'.format(line))
				_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
				if (is_line3(line)):
					_n.ldprint2('line3 class')
					pass
				elif (isinstance(line, (list, tuple))):
					_n.ldprint2('list, tuple')
					line = line3(line)
				else:
					raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01233.")
				_n.ldprint2('line:           {}'.format(line))
				_n.ldprint2('line.classname: \'{}\''.format(_n.classname(line)))
				self.append(line)
		elif (is_line3list(x)):
			self.append(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-PRIMITIVESHAPE-01253.")
		_n.ldprint('<-- nkj.primitiveshape.line3list.set()')
	"""

	# Functions

	def getVanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		vptlist = point3list()
		if (anglethresh is None):
			for i in range(len(self)):
				for j in range(i + 1, len(self)):
					l1, l2 = self[i], self[j]
			return vptlist.gravity
		else:
			if (anglethresh > 0.0):
				for i in range(len(self)):
					for j in range(i + 1, len(self)):
						l1, l2 = self[i], self[j]
						if (Angle(l1, l2) > anglethresh):  # Line elimination by angle
							vptlist.append(l1 & l2)
				return vptlist.gravity
			else:
				for i in range(len(self)):
					for j in range(i + 1, len(self)):
						l1, l2 = self[i], self[j]
				return vptlist.gravity

	def VanishingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(self, anglethresh)

	def vanishingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def vanishing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def getConversingPoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getVanishingPoint(anglethresh)

	def conversingpoint(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	def conversing(self, anglethresh=_DEFAULT_KEEPING_ANGLE):
		return self.getConversingPoint(anglethresh)

	# Data string

	def getDataString(self, rowend=None, separator='\n'):
		s = ''
		for i in range(len(self)):
			if (i != 0):
				s += separator
			c = self[i]
			s += '{}'.format(c.getDataString())
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.primitiveshape.line3list.setDataString()')
		_n.ldprint('datastr: {}'.format(s))
		while (s[-1] == '\n'):
			s = s[:-1]
		slist = s.split('\n')
		if (nd.LIB_DEBUG):
			print('string list: {}'.format(slist))
		self.clear()
		for s in slist:
			_n.ldprint('string: {}'.format(s))
			data = list(map(float, s.replace('(', '').replace(')', '').split(',')))
			_n.ldprint('list[{0}]: {1}'.format(len(data), data))
			self.append(self.componentclass([[data[0], data[1], data[2]], [data[3], data[4], data[5]]]))
		_n.ldprint('<-- nkj.primitiveshape.line3list.setDataString()')

	# isinstance

	def isinstance(self, x):
		return is_line3list(x)

class line3list(line3list_cls):
	pass

class line3s(line3list_cls):
	pass

class linelist(line3list_cls):
	pass

class lines(line3list_cls):
	pass

def is_line3list(x):
	return isinstance(x, line3list_cls)

def is_line3s(x):
	return is_line3list(x)

def is_linelist(x):
	return is_line3list(x)

def is_lines(x):
	return is_line3list(x)


#-- Definitions

DEFAULT_LINE2 = line2(_DEFAULT_LINE2)
DEFAULT_LINE3 = line3(_DEFAULT_LINE3)
DEFAULT_LINE = DEFAULT_LINE3
DEFAULT_PLANE = plane(_DEFAULT_PLANE)
DEFAULT_PLANE3 = DEFAULT_PLANE
DEFAULT_SPHERE = sphere(_DEFAULT_SPHERE)
DEFAULT_SPHERE3 = DEFAULT_SPHERE
DEFAULT_CIRCLE2 = circle2(_DEFAULT_CIRCLE2)
DEFAULT_CIRCLE3 = circle3(_DEFAULT_CIRCLE3)
DEFAULT_CIRCLE = DEFAULT_CIRCLE2


#-- Functions

def Angle(x1, x2):
	if (is_line2(x1)):
		if (is_line2(x2)):
			angle = x1.getAngle(x2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	elif (is_line3(x1)):
		if (is_line3(x2)):
			angle = x1.getAngle(x2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	elif (is_plane3(x1)):
		if (is_plane3(x2)):
			angle = x1.getAngle(x2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	else:
		raise Exception('__ERROR__: Not supported.')
	return angle

def Rad(x1, x2):
	return Angle(x1, x2)

def Deg(x1, x2):
	return _nm.rad2deg(Angle(x1, x2))

def LineCrosssection(l1, l2):
	return l1.crosssection(l2)

def LineCrossPoint(l1, l2):
	return LineCrosssection(l1, l2)

def PlaneLineCrosssection(pl, l):
	return pl.crosssection(l)

def PlaneLineCrossPoint(pl, l):
	return PlaneLineCrosssection(pl, l)

def Crosssection(a, b):
	if (is_line2(a) or is_line3(a)):
		return LineCrosssection(a, b)
	elif (is_plane3(a)):
		return PlaneLineCrosssection(a, b)
	else:
		raise TypeError('__ERROR__: Not implemented. NKJ-PRIMITIVESHAPE-01870.')

def CrossPoint(a, b):
	return CrossSection(a, b)

def crosssection(a, b):
	return Crosssection(a, b)

def crosspoint(a, b):
	return CrossPoint(a, b)

def PerpendicularBisectorLine2(pt1:_ncs.point2, pt2:_ncs.point2):
	_n.ldprint('--> nkj.primitive.shape.PerpendicularBisectorLine2()')
	orig = (pt1 + pt2) / 2.0
	vec = (pt2 - pt1).perpendicular
	line = line2([orig, vec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
	if (nd.LIB_DEBUG2):
		line.print('perpendicular line')
		line.vector.print('line vector')
	_n.ldprint('<-- nkj.primitive.shape.PerpendicularBisectorLine2()')
	return line

def PerpendicularBisectorLine(pt1:_ncs.point2, pt2:_ncs.point2):
	return PerpendicularBisectorLine2(pt1, pt2)

def PerpendicularBisectorPlane3(pt1:_ncs.point3, pt2:_ncs.point3):
	orig = (pt1 + pt2) / 2.0
	vec = pt2 - pt1
	return plane3([orig, vec])

def PerpendicularBisectorPlane(pt1:_ncs.point3, pt2:_ncs.point3):
	return PerpendicularBisectorPlane3(pt1, pt2)

def PerpendicularBisector(pt1:_ncs.point2, pt2:_ncs.point2):
	return PerpendicularBisectorLine2(pt1, pt2)

def VanishingPoint(lines, anglethresh=_DEFAULT_KEEPING_ANGLE):
	if (not (is_line2list(lines) or is_line3list(lines))):
		raise Exception('__ERROR__: Not supported.')
	return lines.getVanishingPoint(anglethresh)

def ConversingLines(lines, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return VanishingPoint(lines, anglethresh)

def RotationalVector(m1, m2):
	return _ncs.RotationalVector(m1, m2)

def RotationVector(m1, m2):
	return _ncs.RotationVector(m1, m2)

def RotationCenter4Points(pts1, pts2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationCenter4Points(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	if (pts2 is None):  # For points on a circle.
		_n.ldprint('@-- points. (pts2 is None.)')
		pts = pts1
		if (_ncs.is_vec2list(pts)):
			raise Exception('__ERROR__: Not implemented.')
		elif (_ncs.is_vec3list(pts)):
			raise Exception('__ERROR__: Not implemented.')
		else:
			raise Exception('__ERROR__: Not supported.')
	else:  # For point pairs. Using concentric circles
		_n.ldprint('@-- point pairs')
		if (nd.LIB_DEBUG2):
			pts1.print('pts1')
			pts2.print('pts2')
			print('pts1: {0} ({1})'.format(pts1, type(pts1)))
			print('pts2: {0} ({1})'.format(pts2, type(pts2)))
		
		if (_ncs.is_vec2list(pts1)):
			_n.ldprint('@-- pts1: vec2list')
			pass
		elif (isinstance(pts1, (list, tuple, np.ndarray))):
			_n.ldprint('@-- pts1: list/tuple/np.ndarray')
			ndim = _nm.ndim(pts1)
			_n.ldprint('pts.mdim: {}'.format(ndim))
			if (ndim == 1):
				_n.ldprint('pts1.len: {}'.format(len(pts1)))
				if (len(pts1) == 0):
					raise Exception('__ERROR__: Null data.')
			"""
			rows, columns = _nm.shape(pts1)
			_n.ldprint('pts.shape: ({0}, {1})'.format(rows, columns))
			"""
			pts1 = _ncs.vec2list(pts1)
		else:
			raise Exception('__ERROR__: Unsupported data type.')
		
		if (_ncs.is_vec2list(pts2)):
			_n.ldprint('@-- pts2: vec2list')
			pass
		elif (isinstance(pts2, (list, tuple, np.ndarray))):
			_n.ldprint('@-- pts2: list/tuple/np.ndarray')
			pts2 = _ncs.vec2list(pts2)
		else:
			raise Exception('__ERROR__: Unsupported data type.')
		
		if (nd.LIB_DEBUG2):
			pts1.print('pts1')
			pts2.print('pts2')
		
		if (len(pts1) != len(pts2)):
			_n.print_error('len(pts1): {0}, len(pts2): {1}'.format(len(pts1), len(pts2)))
			raise Exception('__ERROR__: List sizes are different.')
		
		if (_ncs.is_vec2list(pts1)):
			if (_ncs.is_vec2list(pts2)):
				_n.ldprint('@-- pair of vec2list --')
				plinelist = line2list()
				for i in range(len(pts1)):
					pt1 = pts1[i]
					pt2 = pts2[i]
					plinelist.append(PerpendicularBisectorLine2(pt1, pt2))
				if (nd.LIB_DEBUG):
					plinelist.print('perpendicular lines')
				if (len(plinelist) < 2):
					raise Exception('__ERROR__: Illegal algorithm. Perpendicular-line number is too little less than 2.')
				cenpt = VanishingPoint(plinelist, anglethresh)
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (_ncs.is_vec3list(pts1)):
			if (_ncs.is_vec3list(pts2)):
				_n.ldprint('@-- pair of vec3list --')
				if (len(pts1) != len(pts2)):
					raise Exception('__ERROR__: List sizes are different.')
				pplanelist = plane3list()
				for pt1, pt2 in pts1, pts2:
					pplanelist.append(PerpendicularBisectorPlane3(pt1, pt2))
				plinelist = line3list()
				for i in range(len(pplanelist)):
					for j in range(i + 1, len(planelist)):
						pl1 = pplanelist[i]
						pl2 = pplanelist[j]
						if (abs(Angle(pl1.vector, pl2.vector)) < anglethresh):
							plinelist.append(pl1 & pl2)
				cenpt = VanishingPoint(plinelist, anglethresh)
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		else:
			raise Exception('__ERROR__: Not supported.')
	if (nd.LIB_DEBUG):
		cenpt.print('rotation center point')
	_n.ldprint('<-- nkj.primitiveshape.RotationCenter4Points()')
	return cenpt

def RotationCenterPoint4Points(pts1, pts2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationCenter4Points(pts1, pts2, anglethresh)

def RotationCenter4Matrices(m1, m2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationCenter4Matrices(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	if (_ncs.is_mat3x4(m1)):
		if (_ncs.is_mat3x4(m2)):
			raxis = _ncs.RotationalVector(m1, m2).normalized
			_METHOD = 2  # 残差計算の観点より，_METHOD #1 より _METHOD #2 をお勧め
			if (_METHOD == 1):
				_n.ldprint('@->> _METHOD: 1')
				orig = _ncs.vec3([0.0, 0.0, 0.0])
			elif (_METHOD == 2):
				_n.ldprint('@->> _METHOD: 2')
				orig = (m1.origin + m2.origin) / 2.0  # 投影平面の原点を計測座標系辺りに移動
			else:
				raise Exception('Illegal algorithm. Incorrect _METHOD.')
			if (nd.LIB_DEBUG2):
				raxis.print('rotation axis')
				orig.print('origin')
			m_plane = plane3([orig, raxis]).matrix  # m_plane: 任意の平面をx-y平面とする座標系
			if (nd.LIB_DEBUG2):
				m_plane.print('m_plane')
			_METHOD = 2
			if (_METHOD == 1):
				_n.ldprint('@->> _METHOD: 1')
				if (nd.LIB_DEBUG2):
					m1.print('m1')
					m2.print('m2')
				m2d_1 = m_plane.project2(m1)
				m2d_2 = m_plane.project2(m2)
				if (nd.LIB_DEBUG2):
					m2d_1.print('m2d_1')
					m2d_2.print('m2d_2')
				pts2d_1 = m2d_1.OriginAndHexagonVerts(10.0)  # 原点と正6角形頂点群．6角形半径は10.0
				pts2d_2 = m2d_2.OriginAndHexagonVerts(10.0)
				if (nd.LIB_DEBUG2):
					pts2d_1.print('pts2d_1 (origin and hexagon verts)')
					pts2d_2.print('pts2d_2 (origin and hexagon verts)')
			elif (_METHOD == 2):
				_n.ldprint('@->> _METHOD: 2')
				pts3d_1 = m1.OriginAndIcosahedronVerts(_ICOSAHEDRON_RADIUS1)  # 原点と正20面体頂点群．20面体半径は30.0
				pts3d_1.extend(m1.IcosahedronVerts(_ICOSAHEDRON_RADIUS2))     # 半径50.0の正20面体頂点群を追加．
				pts3d_2 = m2.OriginAndIcosahedronVerts(_ICOSAHEDRON_RADIUS1)
				pts3d_2.extend(m2.IcosahedronVerts(_ICOSAHEDRON_RADIUS2))
				if (nd.LIB_DEBUG0):
					if (len(pts3d_1) != len(pts3d_2)):
							raise Exception('__ERROR__: Number of points are mismatch.')
				#-- ここから取捨選択
				if (True):
					_DISTANCE_THRESHOLD = _nm.distance_thresh()
					_MIN_POINTS = 3
					plist1 = _ncs.vec3list()
					plist2 = _ncs.vec3list()
					for i in range(len(pts3d_1)):
						pt1 = pts3d_1[i]
						pt2 = pts3d_2[i]
						if ((pt2 - pt1).norm > _DISTANCE_THRESHOLD):
							plist1.append(pt1)
							plist2.append(pt2)
					if (len(plist1) < _MIN_POINTS):
						raise Exception('__ERROR__: Less points')
					pts3d_1 = plist1
					pts3d_2 = plist2
				#-- ここまで取捨選択
				if (nd.LIB_DEBUG2):
					pts3d_1.print('point3list #1')
					pts3d_2.print('point3list #2')
				if (nd.LIB_DEBUG2):
					#
					# Check with vtk polys
					#
					_VTK_POINTSFILE1 = 'testdata/test_icosahedronverts1.vtp'
					_VTK_POINTSFILE2 = 'testdata/test_icosahedronverts2.vtp'
					_VTK_LINEFILE = 'testdata/test_icosahedronvertsline.vtp'
					_VTK_PLANEFILE = 'testdata/test_icosahedronvertsplane.vtu'
					_VTK_CSFILE = 'testdata/test_icosahedronvertscs.vtp'
					poly1 = _ntk.points(pts3d_1)
					poly1.save(_VTK_POINTSFILE1)
					poly2 = _ntk.points(pts3d_2)
					poly2.save(_VTK_POINTSFILE2)
					if (len(pts3d_1) != len(pts3d_2)):
						raise Exception('__ERROR__: Illegal algorithm.')
					linelist = line3list()
					for i in range(len(pts3d_1)):
						linelist.append(line3([pts3d_1[i], pts3d_2[i]]))
					poly3 = _ntk.lines(linelist)
					poly3.save(_VTK_LINEFILE)
					poly4 = _ntk.plane(plane3([orig, raxis]))
					poly4.save(_VTK_PLANEFILE)
					poly5 = _ntk.coordinate(m_plane, 10.0)
					poly5.save(_VTK_CSFILE)
				pts2d_1 = m_plane.project2(pts3d_1)
				pts2d_2 = m_plane.project2(pts3d_2)
				if (nd.LIB_DEBUG2):
					pts2d_1.print('point2list #1')
					pts2d_2.print('point2list #2')
			else:
				raise Exception('__ERROR__: Illegal _METHOD.')
			cpt2 = RotationCenter4Points(pts2d_1, pts2d_2, anglethresh)  # 回転中心点 on the x-y plane of m_plane-CS
			if (nd.LIB_DEBUG):
				cpt2.print('rotation center in 2D-CS')
			if (cpt2 is None):
				cenpt = None
			else:
				cenpt = m_plane @ _ncs.vec3([cpt2.x, cpt2.y, 0.0])
				cenpt.residue = cpt2.residue
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	else:
		raise Exception('__ERROR__: Not supported.')
	_n.ldprint('<-- nkj.primitiveshape.RotationCenter4Matrices(): {}'.format(cenpt))
	return cenpt

def RotationCenterPoint4Matrices(m1, m2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationCenter4Matrices(m1, m2, anglethresh)

def RotationCenter(x1, x2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationCenter(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	_n.ldprint('x1: {0} ({1})'.format(x1, type(x1)))
	_n.ldprint('x2: {0} ({1})'.format(x2, type(x2)))
	if (_ncs.is_point2list(x1) or _ncs.is_point3list(x1)):
		cenpt = RotationCenter4Points(x1, x2, anglethresh)
	elif (_ncs.is_mat3x4(x1)):
		cenpt = RotationCenter4Matrices(x1, x2, anglethresh)
	else:
		raise Exception('__ERROR__: Not supported.')
	_n.ldprint('<-- nkj.primitiveshape.RotationCenter()')
	return cenpt

def RotationCenterPoint(x1, x2=None, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationCenter(x1, x2, anglethresh)

def RotationalAxis(m1, m2, anglethresh=_DEFAULT_KEEPING_ANGLE):
	_n.ldprint('--> nkj.primitiveshape.RotationalAxis(, anglethresh: {}[deg])'.format(_nm.rad2deg(anglethresh)))
	vec = RotationalVector(m1, m2).normalized
	if (nd.LIB_DEBUG):
		vec.print('rotation vector')
	if (_nm.is_ineps(vec.norm, 0.0)):
		_n.ldprint2('@ERROR: No rotation.')
		_n.ldprint('<-- nkj.primitiveshape.RotationalAxis(): {}'.format(None))
		return None
	else:
		cpt = RotationCenter(m1, m2, anglethresh)
		if (cpt is None):
			raxis = None
		else:
			raxis = line3([cpt, vec], _LINE_SETTINGFLAG_ORIGINANDVECTOR)
		_n.ldprint('<-- nkj.primitiveshape.RotationalAxis(): {}'.format(raxis))
		return raxis

def RotationAxis(m1, m2, anglethresh=_DEFAULT_KEEPING_ANGLE):
	return RotationalAxis(m1, m2, anglethresh)

def toLine3(x):
	if (is_line2(x)):
		line2 = x
		return line3([[line2.p0.x, line2.p0.y, 0.0], [line2.p1.x, line2.p1.y, 0.0]])
	elif (is_line2list(x)):
		linelist = line3list()
		for line2 in x:
			linelist.append(line3([[line2.p0.x, line2.p0.y, 0.0], [line2.p1.x, line2.p1.y, 0.0]]))
		return linelist
	else:
		_n.print_error('x: {0} ({1})'.format(x, type(x)))
		raise TypeError('__ERROR__: Illegal data type.')

def to_line3(x):
	return toLine3(x)

def toVec3(x):
	if (is_line2(x) or is_line2list(x)):
		return toLine3(x)
	elif (is_line2(x) or is_line2list(x)):
		return _ncs.toVec3(x)

def to_vec3(v2):
	return toVec3(v2)

def to_point3(v2):
	return toVec3(v2)

def toLine2(x):
	if (is_line3(x)):
		line3 = x
		if (not (is_ineps(line3.p0.z) and is_ineps(line3.p1.z))):
			raise Exception('__ERROR__: Z residue is too large.')
		return line2([[line3.p0.x, line3.p0.y], [line3.p1.x, line3.p1.y]])
	elif (is_line3list(x)):
		linelist = line2list()
		for line3 in x:
			if (not (is_ineps(line3.p0.z) and is_ineps(line3.p1.z))):
				raise Exception('__ERROR__: Z residue is too large.')
			linelist.append(line2([[line3.p0.x, line3.p0.y], [line3.p1.x, line3.p1.y]]))
		return linelist
	else:
		_n.print_error('x: {0} ({1})'.format(x, type(x)))
		raise TypeError('__ERROR__: Illegal data type.')

def to_line3(x):
	return toLine3(x)

def toVec3(x):
	if (is_line2(x) or is_line2list(x)):
		return toLine3(x)
	else:
		return _ncs.toVec3(x)

def to_vec3(v2):
	return toVec3(v2)

def to_point3(v2):
	return toVec3(v2)


#-- lib-test main

if (__name__ == '__main__'):
	from scipy.spatial.transform import Rotation as spr
	import quaternion
	from matplotlib import pyplot as plt

	_DEBUGLEVEL = 1

	_n.debuglevel(_DEBUGLEVEL)

	entireflag = False

	if (entireflag and True):
		print("\n-- line2")
		l = line2()
		l.print("line2")
		l = line2([[1.0, 2.0], [3.0, 4.0]])
		l.print("line2")
		l = line2([(5.0, 5.0), (7.0, 8.0)])
		l.print("line2")
		l = line2(((9.0, 10.0), (11.0, 12.0)))
		l.print("line2")
		for i in range(2):
			l.getPoint(i).print("point[{}]".format(i))

	if (entireflag and True):
		print("\n-- line2")
		for i in range(2):
			l.setPoint(i, _ncs.point2([10 + 2 * i, 10 + 2 * i + 1]))
		l.print("line2")
		for i in range(2):
			l.setPoint(i, (20 + 2 * i, 20 + 2 * i + 1))
		l.print("line2")
		for i in range(2):
			l.setPoint(i, [30 + 2 * i, 30 + 2 * i + 1])
		l.print("line2")

	if (entireflag and True):
		print("\n-- line3")
		l = line3()
		l.print("line3")
		l = line3([_ncs.point3([1.0, 2.0, 3.0]), _ncs.point3([4.0, 5.0, 6.0])])
		l.print("line3")
		l = line3([(1.0, 2.0, 3.0), (4.0, 5.0, 6.0)])
		l.print("line3")
		for i in range(2):
			l.getPoint(i).print("point[{}]".format(i))

	if (entireflag and True):
		print("\n-- line3")
		l = line3()
		for i in range(2):
			l.setPoint(i, (10 + 3 * i, 10 + 3 * i + 1, 10 + 3 * i + 2))
		l.print("line3")
		m = _ncs.mat3x3()
		r = spr.from_rotvec(np.array([0.0, np.pi / 2.0, np.pi / 3.0]))
		m.rotatelocal(r)
		m.print("rotational matrix")
		l2 = m @ l
		l2.print("line3 (rotated)")
		m2 = _ncs.mat3x4(m)
		m2.translate([1.0, 2.0, 3.0])
		m2.print("translational matrix")
		l2 = m2 @ l
		l2.print("line3 (translated)")

	if (entireflag and True):
		print("\n-- line from points")
		pts = _ncs.point3list([0.0, 0.0, 0.0])
		pts.append([1.0, 1.0, 0.0])
		pts.append([2.0, 2.0, 0.0])
		pts.print("points")
		l = line3()
		"""
		l.setByPoints(pts)
		l.setByPoints(pts, 3.0)
		l.setFromPoints(pts)
		l.setFromPoints(pts, 3.0)
		l.by_points = pts
		l.by_points = pts, 3.0
		l.from_points = pts
		"""
		l.from_points = pts, 3.0
		l.print("line (from points)")
		m = l.matrix
		m.print("line matrix")

	if (entireflag and True):
		print("\n-- plane")
		pl = plane()
		pl.print("plane")
		m = _ncs.mat3x4()
		r = spr.from_rotvec(np.array([0.0, np.pi / 2.0, np.pi / 3.0]))
		m.rotatelocal(r)
		m.translate([1.0, 2.0, 3.0])
		m.print("rotational matrix")
		pl2 = m @ pl
		pl2.print("plane (rotated)")

	if (entireflag and True):
		print("\n-- plane from points")
		pts = _ncs.point3list([0.0, 0.0, 0.0])
		pts.append([1.0, 2.0, 0.0])
		pts.append([3.0, 4.0, 0.0])
		pts.print("points")
		pl = plane()
		"""
		pl.setByPoints(pts)
		pl.setFromPoints(pts)
		pl.by_points = pts
		"""
		pl.from_points = pts
		pl.print("plane (from points)")
		m = pl.matrix
		m.print("plane matrix")
		pts_2 = pl << pts
		pts_2.print("points (projected)")

	if (entireflag and True):
		print("\n-- sphere")
		sph = sphere()
		sph.print("sphere")

	if (True):
		print("\n-- rotation axis")
		m1 = _ncs.mat3x4()
		m2 = copy.deepcopy(m1)
		
		"""
		m2.rotatex(_nm.deg2rad(60.0))
		m2.rotatey(_nm.deg2rad(60.0))
		m2.rotatez(_nm.deg2rad(60.0))
		"""
		rotangle = _nm.deg2rad(60.0)
		rotvec = _ncs.vec3([1.0, 3.0, 0.0])
		m2.rotate(spr.from_rotvec((rotangle * rotvec).components))
		
		m1.translate([20.0, 0.0, 0.0])
		m2.translate([20.0, 0.0, 0.0])
		m1.print('m1')
		m2.print('m2')
		raxis = RotationalAxis(m1, m2)
		if (raxis is None):
			print('No crosssection point was found..')
		else:
			raxis.print('rotation axis  ')
			rvec = raxis.vector
			rvec.print('rotational vector')
