#
# [name] nkj.json.py
# [exec] python -m nkj.json
#
# Written by Yoshiakzu NAKAJIMA
#
import os
import sys
import re
import numpy as np
import json

import nkj as _n
import nkj.str as _ns

sys.path.append(os.path.abspath(".."))

def load_nparrayjson(filename):
	with open(filename, 'r') as f:
		data = json.load(f)
		ndata = {}
		for key in data.keys():
			ndata[key] = _ns.extract_float(data[key])
		return ndata
	return None

def save_nparrayjson(filename, data):
	if (type(data) != dict):
		print_error("Illegal data type.")
		return False
	ndata = {}
	for key in data.keys():
		ndata[key] = str(tuple(data[key].tolist()))
	with open(filename, 'w') as f:
		json.dump(ndata, f, indent=2)
		return True
	return False

#-- main

if __name__ == '__main__':
	_LIB_DEBUGLEVEL = 1
	_USAGE = " input.json"

	nd = _n.LibDebugFlag()
	nd.debuglevel(_LIB_DEBUGLEVEL)

	argc = len(sys.argv)

	if (argc == 2):
		filename = sys.argv[1]
	else:
		_n.print_usage(sys.argv[0] + _USAGE)
		os.sys.exit()
	_n.ldprint(["Filename: ", str_bracket(filename)])

	data = load_nparrayjson(filename)
	if (data == None):
		_n.print_error("Can't load input.json")
		os.sys.exit()

	_n.ldprint(["Data: ", data])
