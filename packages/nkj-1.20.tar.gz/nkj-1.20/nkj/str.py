#
# [name] nkj.str.py
# [purpose] nkj.str library
# [exec] python -m nkj.str
#
# Written by Yoshikazu NAKAJIMA (Wed Sep 23 14:38:26 JST 2020)
#

#print('CALLED: nkj.s')

import os
import sys
import numpy as np
import re
from typing import Union
import copy

from ._ncore import *

_BRACKET_SINGLE = '\''
_BRACKET_DOUBLE = '\"'
_BRACKET_PARENTHESES = '()'
_BRACKET_ANGLE_BRACKETS = '<>'
_BRACKET_CURLY_BRACKETS = '{}'
_BRACKET_SQUARE_BRACKETS = '[]'
_DEFAULT_BRACKET = _BRACKET_SINGLE
_BRACKET = _DEFAULT_BRACKET


#-- str

def is_nullstr(s):
	if (s is None):
		return False
	else:
		return (s == NULLSTR)

def nullstr(s):
	return is_nullstr(s)

def is_intstr(s):
	try:
		int(s, 10)
	except ValueError:
		return False
	else:
		return True

def is_floatstr(s):  # float に変換可能かどうかをテストして判定しているので、int の場合も True を返す．
	try:
		float(s)
	except ValueError:
		return False
	else:
		return True

def is_truefloatstr(s):
	try:
		float(s)
	except ValueError:
		return False
	else:
		return (not is_intstr(s))

def intstr(s):
	return is_intstr(s)

def floatstr(s):
	return is_floatstr(s)

def truefloatstr(s):
	return is_truefloatstr(s)

def is_intstr_re(s):  # 正規表現 (Regular expression, re) バージョン
	p = r'[-+]?\d+'
	return True if re.fullmatch(p, s) else False

def is_floatstr_re(s):
	p = r'[-+]?(\d+\.?\d* | \.\d+)([eE][-+]?\d+)?'
	return True if re.fullmatch(p, s) else False

def intstr_re(s):
	return is_intstr_re(s)

def floatstr_re(s):
	return is_floatstr_re(s)



#-- tuple

def is_nulltuple(t):
	return not isnot_nulltuple(t)

def isnot_nulltuple(t):
	return any(t)

def nulltuple(t):
	return is_nulltuple(t)

def not_nulltuple(t):
	return not nulllist(t)


#-- list

def is_nulllist(d):
	return not isnot_nulllist(d)

def isnot_nulllist(l):
	return any(l)

def nulllist(d):
	return is_nulllist(d)

def not_nulllist(d):
	return not nulllist(d)


#-- dict

def is_nulldict(d):
	return not isnot_nulldict(d)

def isnot_nulldict(d):
	return any(d)  # 組み込み関数 any() を用いて NULL 判定（空判定）する

def nulldict(d):
	return is_nulldict(d)

def not_nulldict(d):
	return not nulldict(d)


#-- json

def is_jsonstr(s:str):
	ldprint('--> nkj.str.is_jsonstr(\'{}\')'.format(s))
	try:
		s = s.replace('\'', '\"')  # シングルクォーテーションは JSON として認識されないので、ダブルクォーテーションに変換．
		json.loads(s)
	except json.JSONDecodeError as jde:
		ldprint('<-- nkj.str.is_jsonstr(): {}'.format(False))
		return False
	else:
		ldprint('<-- nkj.str.is_jsonstr(): {}'.format(True))
		return True

def isnot_jsonstr(s:str):
	return not is_jsonstr(s)

def jsonstr(s:str):
	return is_jsonstr(s)

def not_jsonstr(s:str):
	return isnot_jsonstr(s)

def todict(s:Union[dict, tuple, list, str, None]):
	ldprint('--> nkj.str.todict(\'{0}\' ({1}))'.format(s, type(s)))
	ldprint2('val: \'{0}\' ({1})'.format(s, type(s)))
	if (s is None):
		d = {}
	elif (isinstance(s, dict)):
		d = copy.deepcopy(s)
	elif (isinstance(s, tuple) or isinstance(s, list)):
		if (len(s) != 2):
			raise ValueError('Illegal format for dict component')
		d = {}
		d[s[0]] = s[1]
	elif (isinstance(s, str)):
		s = s.replace('\'', '\"')  # シングルクォーテーションは JSON として認識されないので、ダブルクォーテーションに変換．
		if (is_jsonstr(s)):
			d = json.loads(s)
		else:
			s = s.split(',')
			if (len(s) == 2):
				d = {}
				d[s[0]] = s[1]
			else:
				ldprint('\'{0}\' ({1})'.format(s, type(s)))
				raise ValueError('Illegal data format')
	else:
		ldprint('\'{0}\' ({1})'.format(s, type(s)))
		d = s.copy()
	ldprint('<-- nkj.str.todict()')
	return d


#-- digit

def intstr(s):
	return is_intstr(s)

def is_intstr_re(s):  # 正規表現 (Regular expression, re) バージョン
	p = r'[-+]?\d+'
	return True if re.fullmatch(p, s) else False

def is_floatstr_re(s):
	p = r'[-+]?(\d+\.?\d* | \.\d+)([eE][-+]?\d+)?'
	return True if re.fullmatch(p, s) else False

#-- bracket

def default_bracket(s=None):
	global _BRACKET
	if (s is None):
		return _DEFAULT_BRACKET if (_BRACKET is None) else _BRACKET
	else:
		_BRACKET = s

def defaultbracket(s=None):
	return default_bracket(s)

default_bracket(_DEFAULT_BRACKET)   # _DEFAULT_BRACKET を default_brakcet() に設定

def str_bracket(in_str, bstr=None):
	bstr = default_bracket() if (bstr is None) else bstr
	if (len(bstr) == 1):
		bstr = bstr + bstr
	if (in_str is None):
		s = bstr[0] + bstr[1]
	elif (in_str == ""):
		s = bstr[0] + bstr[1]
	else:
		s = bstr[0] + str(in_str) + bstr[1]
	return s

def strbracket(in_str, s=None):
	return str_bracket(in_str, s)

def sbracket(in_str, s=None):
	return str_bracket(in_str, s)

def bracket(in_str, s=None):
	return str_bracket(in_str, s)

def str_float(in_str):
	return "{0:8.3f}".format(in_str)

def strfloat(in_str):
	return str_float(in_str)

def sfloat(in_str):
	return str_float(in_str)


#-- concat

def concat(strlist):
	retstr = NULLSTR
	if (len(strlist) != 0):
		for i in range(len(strlist)):
			if (strlist[i] != None and strlist[i] != NULLSTR):
				retstr += str(strlist[i])
	return retstr

def concat_path(pathlist):
	retstr = NULLSTR
	for path in pathlist[:-1]:
		dprint3(["PATH: ", str_bracket(path)])
		if (path[-1] != '/'):
			path += '/'
		retstr = concat([retstr, path])
	dprint3(["PATH: ", str_bracket(pathlist[-1])])
	retstr += pathlist[-1]
	return retstr

def is_none(str):
	if (str is None):
		return True
	elif (str == NULLSTR):
		return True
	else:
		return False

def isnot_none(str):
	return (not isNone(str))

def extract_float(istr):
	strs = re.findall(r"[-]*[0-9][0-9]*[.]*[0-9]*[e+-]*[0-9]*", istr)
	vals = []
	for s in strs:
		vals.append(float(s))
	return np.array(vals)

def atoi(s):
	return int(s.strip())

def linestr2int(s_line):
	dlist = []
	for s in s_line.split(','):
		dlist.append(atoi(s))
	return dlist

def l2i(linestr):
	return linestr2int(linestr)

def atof(s):
	return float(s.strip())

def linestr2float(s_line):
	linestr = s_line.split(',')
	if (len(linestr) == 1):
		linestr = s_line.split(' ')
	dlist = []
	for s in linestr:
		dlist.append(atof(s))
	return dlist

def l2f(linestr):
	return linestr2float(linestr)


SINGLE_BRACKET = _BRACKET_SINGLE
DOUBLE_BRACKET = _BRACKET_DOUBLE
PARENTHESES = _BRACKET_PARENTHESES
ANGLE_BRACKETS = _BRACKET_ANGLE_BRACKETS
CURLY_BRACKETS = _BRACKET_CURLY_BRACKETS
SQUARE_BRACKETS = _BRACKET_SQUARE_BRACKETS
DEFAULT_BRACKET = _DEFAULT_BRACKET


#-- main

if __name__ == '__main__':
	'''
	if (False):
		import nkj.ncore as nc
		print(["ROOTPATH: ", nc.rootpath()])

	if (False):
		import nkj.score as ns
		ns.debuglevel(5)
		ns.dprint(["test1, ", "test2, ", "test3"])
	'''

	debuglevel(5)

	print("test")
	__DEBUGLEVEL = 5
	dprint(["test, ", "test2, ", ""])

	print(concat_path(["test", "test2"]))
	print(concat_path(["test/", "test2"]))
	print(concat_path(["test/", "test2", "test3"]))

	print(linestr2float('   0.00123, 2.345,  -12.356'))

	for s in ['5', '-3', '2.71828', '-2.71828', '-3.14e+2', '4.tadfa']:
		print('\'{0}\' is int:        {1}'.format(s, is_intstr(s)))
		print('\'{0}\' is float:      {1}'.format(s, is_floatstr(s)))
		print('\'{0}\' is true float: {1}'.format(s, is_truefloatstr(s)))
