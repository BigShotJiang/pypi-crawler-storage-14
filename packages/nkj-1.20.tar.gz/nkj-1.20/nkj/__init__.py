#
# [name] __init__.py
#
# Written by Yoshikazu NAKAJIMA
#
from ._ncore import *

__all__ = ['str', 'math']
