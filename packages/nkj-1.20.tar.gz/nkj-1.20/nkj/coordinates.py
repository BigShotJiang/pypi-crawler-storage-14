#
# [name]    nkj.cs.py
# [comment] Coordinate System (CS) Library
# [exec]    python -m nkj.cs
#
# Written by Yoshikazu NAKAJIMA
#
import os
import sys
import math
import numpy as np
import quaternion  # numpy.quaternion (quaternionをインポートすると、numpy のコンポーネントとして np.quaternion がインポートされる）
import scipy
import copy
from scipy.spatial.transform import Rotation as spr  # scipy.rotation (including quaternion)
import numbers
from functools import singledispatch
from abc import ABC, abstractmethod
import nkj as _n
import nkj.str as _ns
import nkj.math as _nm
import nkj.list as _nl
import nkj.cs as _ncs


#-- Flags

ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION = False
ENABLE_MULOPERATOR_FOR_CSTRANS3_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_MAT4X4_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_POINT3_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_LINE3_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_PLANE3_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION


#-- Lib Constants

_XAXISINDEX = 0
_YAXISINDEX = 1
_ZAXISINDEX = 2

_XAXIS2 = [1.0, 0.0]
_YAXIS2 = [0.0, 1.0]
_XAXIS3 = [1.0, 0.0, 0.0]
_YAXIS3 = [0.0, 1.0, 0.0]
_ZAXIS3 = [0.0, 0.0, 1.0]

_MAXIMUM_ITERATIONS = 10

_DEFAULT_RESIDUE =         None
_DEFAULT_SIGMA =           3.0   # Sigma of Gaussian distribution for variance elimination
_DEFAULT_RADIUS_FORVERTS = 10.0

_DEFAULT_VEC2 =   [[0.0], [0.0]]
_DEFAULT_VEC2H =  [[0.0], [0.0], [1.0]]
_DEFAULT_VEC3 =   [[0.0], [0.0], [0.0]]
_DEFAULT_VEC3H =  [[0.0], [0.0], [0.0], [1.0]]
_DEFAULT_VEC4 =   [[0.0], [0.0], [0.0], [0.0]]
_DEFAULT_MAT2X2 = [[1.0, 0.0], [0.0, 1.0]]
_DEFAULT_MAT2X3 = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]
_DEFAULT_MAT3X3 = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]]
_DEFAULT_MAT3X4 = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]]
_DEFAULT_MAT4X4 = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0], [0.0, 0.0, 0.0, 1.0]]

_DEFAULT_SCIPYQUATERNION =  [0.0, 0.0, 0.0, 1.0]  # (x, y, z; w)
_DEFAULT_NUMPYQUATERNION =  [1.0, 0.0, 0.0, 0.0]  # (w; x, y, z)
_DEFAULT_MATHEXQUATERNION = _DEFAULT_NUMPYQUATERNION
_DEFAULT_QUATERNION =       _DEFAULT_NUMPYQUATERNION

_DEFAULT_XAXIS2 = _XAXIS2
_DEFAULT_YAXIS2 = _YAXIS2
_DEFAULT_XAXIS3 = _XAXIS3
_DEFAULT_YAXIS3 = _YAXIS3
_DEFAULT_ZAXIS3 = _ZAXIS3

_DEFAULT_RMAT2 = _DEFAULT_MAT2X2
_DEFAULT_MAT2  = _DEFAULT_MAT2X3
_DEFAULT_MAT2H = _DEFAULT_MAT3X3
_DEFAULT_RMAT3 = _DEFAULT_MAT3X3
_DEFAULT_MAT3  = _DEFAULT_MAT3X4
_DEFAULT_MAT3H = _DEFAULT_MAT4X4

_DEFAULT_CSV2 = _DEFAULT_VEC2
_DEFAULT_CSV3 = _DEFAULT_VEC3
_DEFAULT_CSM2 = _DEFAULT_MAT2
_DEFAULT_CSM3 = _DEFAULT_MAT3
_DEFAULT_CS2 =  _DEFAULT_CSM2
_DEFAULT_CS3 =  _DEFAULT_CSM3

_DEFAULT_POINT2 = _DEFAULT_VEC2
_DEFAULT_POINT3 = _DEFAULT_VEC3

_DEFAULT_XAXISINDEX = _XAXISINDEX
_DEFAULT_YAXISINDEX = _YAXISINDEX
_DEFAULT_ZAXISINDEX = _ZAXISINDEX

_NKJNUMPYQUATERNION_REID =  0  # (w; x, y, z), self[0]
_NKJNUMPYQUATERNION_IMID =  1  # (w; x, y, z), [self[1], self[2], self[3]]
_NKJSCIPYQUATERNION_REID =  3  # (x, y, z; w), self[3]
_NKJSCIPYQUATERNION_IMID =  0  # (x, y, z; w), [self[0], self[1], self[2]]
_NKJMATHEXQUATERNION_REID = _NKJNUMPYQUATERNION_REID
_NKJMATHEXQUATERNION_IMID = _NKJNUMPYQUATERNION_IMID
_NKJQUATERNION_REID =       _NKJNUMPYQUATERNION_REID
_NKJQUATERNION_IMID =       _NKJNUMPYQUATERNION_IMID

def _isseriallist(l):
	if (isinstance(l, (list, tuple))):
		return not isinstance(l[0], (list, tuple))
	else:
		return False

_NUMPY_ROWINDEX =    0
_NUMPY_COLUMNINDEX = 1


nd = _n.LibDebugFlag()

#-- Classes ---------------------------------------------------------------------------
#
# Class Hierarchy
#
# array_cls (array, a)
#  + vec_cls (vec, v)
#  |  + vec2_cls (vec2, v2)
#  |  |  + (csv2)
#  |  |  + (point2)
#  |  + vec2h_cls (vec2h, v2h)
#  |  |  + (csv2h)
#  |  |  + (point2h)
#  |  + vec3_cls (vec3, v3)
#  |  |  + (csv3)
#  |  |  + (point3)
#  |  + vec3h_cls (vec3h, v3h)
#  |  |  + (csv3h)
#  |  |  + (point3h)
#  |  + vec4_cls (vec4, v4)
#  + mat_cls (mat, m)
#     + mat2x2_cls (mat2x2, m2x2)
#     |  + (rotmat2, rmat2, rm2)
#     |  + (rcs2)
#     + mat3x3_cls (mat3x3, m3x3)
#     |  + (rotmat3, rmat3, rm3)
#     |  + (rcs3)
#     |  + (mat2h, m2h)
#     |  + (csm2h, cs2h)
#     + mat4x4_cls (mat4x4, m4x4)
#     |  + (mat3h, m3h)
#     |  + (csm3h, cs3h)
#     + mat2x3_cls (mat2x3, m2x3)
#     |  + (mat2, m2)
#     |  + (csm2, cs2)
#     + mat3x4_cls (mat3x4, m3x4)
#        + (mat3, m3)
#        + (csm3, cs3)
#

class array_cls(np.ndarray):
	_classname = 'nkj.cs.array'

	def __new__(cls, shape, dtype='float32'):
		self = super().__new__(cls, shape=shape, dtype=dtype)  # 初期化するときは、生成したインスタンスを self に代入してインスタンス関数を呼び出す．
		return self                                            # 必ず、self を return すること

	def __init__(self, shape=None, dtype='float32'):  # self.__init__() は、shape, dtype は None で呼び出されることが前提
		super().__init__()
		# ここでは、self.set() を呼び出さない

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def get(self):
		return self

	def set(self, x=None):
		_n.ldprint('--> nkj.cs.array.set()')
		if (not self.is_correctarray(x)):
			raise TypeError('__ERROR__: Incorrect array.')
		_n.ldprint2("class name: {}".format(_n.classname(x)))
		_n.ldprint2('x: {0} ({1})'.format(x, type(x)))
		if (x is None):
			_n.ldprint2("None")
			self.zeros()
		elif (isinstance(x, (list, tuple, np.ndarray, array_cls))):
			_n.ldprint2('list/tuple/nparray: {0} ({1})'.format(x, type(x)))
			self.setArray(x)
		elif (isinstance(x, str)):
			_n.ldprint2('str: {}'.format(x))
			self.setStr(x)
		else:
			raise TypeError("__ERROR__: Illegal data type")
		_n.ldprint('<-- nkj.cs.array.set()')

	def getDimensions(self):
		return self.shape

	def Dimensions(self):
		return self.getDimensions()

	@property
	def dimensions(self):
		return self.getDimensions()

	@property
	def dim(self):
		return self.getDimensions()

	def zeros(self):
		for j in range(self.rows):
			for i in range(self.columns):
				self[j, i] = 0.0

	def identify(self):
		for j in range(self.rows):
			for i in range(self.columns):
				self[j, i] = 1.0 if (i == j) else 0.0

	def identity(self):
		self.identify()

	def getStr(self):
		s = ''
		for j in range(self.rows):
			for i in range(self.columns):
				if (i != 0 or j != 0):
					s += ', '
				s += '{}'.format(self[j, i])
		return s

	def setStr(self, s:str):
		_n.ldprint('--> nkj.cs.array.setStr()')
		_n.ldprint2(s)
		_n.ldprint2(s.split(','))
		l = list(map(float, s.split(',')))
		_n.ldprint2(l)
		if (len(l) != self.size):
			raise ValueError("__ERROR__: Illegal size")
		ii = 0
		for j in range(self.rows):
			for i in range(self.columns):
				self[j, i] = l[ii]
				ii += 1
		_n.ldprint('<-- nkj.cs.array.setStr()')

	@property
	def str(self):
		return self.getStr()

	@str.setter
	def str(self, s):
		self.setStr(s)

	@property
	def s(self):
		return self.getStr()

	@s.setter
	def s(self, _s):
		self.setStr(_s)

	# Getting dimension

	def getArrayDimension(self):
		return np.array(self).ndim

	def ArrayDimension(self):
		return self.getArrayDimension()

	def ArrayDim(self):
		return self.getArrayDimension()

	@property
	def arraydimension(self):
		return self.getArrayDimension()

	@property
	def arraydim(self):
		return self.getArrayDimension()

	@property
	def arrdim(self):
		return self.getArrayDimension()

	@property
	def adim(self):
		return self.getArrayDimension()

	def getArrayShape(self):
		return self.shape

	def ArrayShape(self):
		return self.getArrayShape()

	@property
	def arrayshape(self):
		return self.getArrayShape()

	@property
	def arrshape(self):
		return self.getArrayShape()

	@property
	def ashape(self):
		return self.getArrayShape()

	def getComponentDimensions(self):
		return self.getArrayShape()

	def ComponentDimensions(self):
		return self.getComponentDimensions()

	def ComponentDims(self):
		return self.getComponentDimensions()

	def CompDims(self):
		return self.getComponentDimensions()

	@property
	def componentdimensions(self):
		return self.getComponentDimensions()

	@property
	def componentdims(self):
		return self.getComponentDimensions()

	@property
	def compdims(self):
		return self.getComponentDimensions()

	@property
	def cdims(self):
		return self.getComponentDimensions()

	def getRows(self):
		rows, _ = self.getArrayShape()
		return rows

	def getColumns(self):
		_, columns = self.getArrayShape()
		return columns

	def Rows(self):
		return self.getRows()

	def Columns(self):
		return self.getColumns()

	@property
	def rows(self):
		return self.getRows()

	@property
	def columns(self):
		return self.getColumns()

	def getSpaceDimension(self):
		return self.Rows()

	def SpaceDimension(self):
		return self.getSpaceDimension()

	@property
	def spacedimension(self):
		return self.getSpaceDimension()

	@property
	def spacedim(self):
		return self.getSpaceDimension()

	@property
	def sdim(self):
		return self.getSpaceDimension()

	# Array

	def getArray(self):
		return np.array(self)

	def setArray(self, _a):
		_n.ldprint('--> nkj.cs.array.setArray()')
		_n.ldprint("a:       {0} ({1})".format(_a, type(_a)))
		a = np.array(_a)
		if (a.ndim == 1):
			_n.ldprint('-- ndim: 1')
			columns = a.shape[0]
			_n.ldprint("columns:    {}".format(columns))
			_n.ldprint("self.shape: {}".format(self.shape))
			_n.ldprint("a.shape:    {}".format(a.shape))
			for i in range(columns):
				self[i] = a[i]
		elif (a.ndim == 2):
			_n.ldprint('-- ndim: 2')
			rows, columns = a.shape
			_n.ldprint("rows        {}".format(rows))
			_n.ldprint("columns:    {}".format(columns))
			_n.ldprint("self.shape: {}".format(self.shape))
			_n.ldprint("a.shape:    {}".format(a.shape))
			for j in range(rows):
				for i in range(columns):
					self[j, i] = a[j, i]
		else:
			raise ValueError("__ERROR__: Illegal dimensions")
		if (nd.LIB_DEBUG):
			self.print('self')
		_n.ldprint('<-- nkj.cs.array.setArray()')

	@property
	def array(self):
		return self.getArray()

	@array.setter
	def array(self, a):
		self.setArray(a)

	@property
	def arr(self):
		return self.getArray()

	@arr.setter
	def arr(self, a):
		self.setArray(a)

	@property
	def a(self):
		return self.getArray()

	@a.setter
	def a(self, _a):
		self.setArray(a)

	# Components

	def getComponents(self):
		_ns.print_error('This function should be implemented in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def setComponents(self, x):
		_ns.print_error('This function should be implemented in a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def Components(self, x=None):
		if (x is None):
			return self.getComponents()
		else:
			self.setComponents(x)

	@property
	def components(self):
		return self.getComponents()

	@components.setter
	def components(self, x):
		self.setComponents(x)

	@property
	def comps(self):
		return self.getComponents()

	@comps.setter
	def comps(self, x):
		self.setComponents(x)

	# Serialization

	def getSerialized(self):
		return self.getComponents()

	def Serialized(self):
		return self.getComponents()

	def serialize(self):
		return self.getComponents()

	@property
	def serialized(self):
		return self.getComponents()

	# Component

	def getComponent(self, i):
		_n.ldprint('--> nkj.cs.vec.getComponent({})'.format(i))
		_n.ldprint('self: {}'.format(self))
		if (nd.LIB_DEBUG0):
			ndim = _nm.ndim(self)
			_n.ldprint2('self.ndim: {}'.format(ndim))
			if (ndim == 1):
				raise ValueError('__ERROR__: Illegal data at self. NKJ-CS-00556.')
			elif (ndim == 2):
				rows, columns = self.shape
				if (columns != 1):
					raise ValueError('__ERROR__: Illegal data at self. NKJ-CS-00560.')
			if (not _nm.is_inrange(i, 0, rows - 1)):
				_n.ldprint2('index:      {}'.format(i))
				_n.ldprint2('self.shape: {}'.format(self.shape))
		_n.ldprint('<-- nkj.cs.vec.getComponent(): {}'.format(self[i, 0]))
		return self[i, 0]

	def setComponent(self, i, c):
		self[i, 0] = c
		return True

	def Component(self, i, c=None):
		return self.getComponent(i) if (c is None) else self.setComponent(i, c)

	def component(self, i, c=None):
		return self.getComponent(i) if (c is None) else self.setComponent(i, c)

	def comp(self, i, a=None):
		return self.component(i, a)

	def c(self, i, a=None):
		return self.component(i, a)

	# Data string

	def getDataString(self, rowend=None):
		_n.ldprint('--> nkj.cs.array.getDataString()')
		_n.ldprint('rowend: \'{}\''.format('CR' if (rowend == '\n') else rowend))
		s = ''
		for j in range(self.rows):
			if (j != 0):
				if (rowend is None or rowend == ''):
					s += ', '
				else:
					s += rowend
			for i in range(self.columns):
				if (i != 0):
					s += ', '
				s += '{:21.12f}'.format(self[j, i])
		_n.ldprint('s: \'{}\''.format(s))
		_n.ldprint('<-- nkj.cs.array.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.cs.array.setDataString()')
		_n.ldprint('datastr: \'{0}\' ({1})'.format(s, type(s)))
		if (len(s) == 0):
			_n.print_error('Null string s[{0}]: \'{1}\' ({2})'.format(len(s), s, type(s)))
			raise ValueError('__ERROR__: Null input.')
		if (s[-1] == '\n'):
			s = s[:-1]
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		s = s.replace('\n', ', ').replace('(', '').replace(')', '').split(',')
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		data = list(map(float, s))
		_n.ldprint('list[{0}]: {1} ({2})'.format(len(data), data, type(data)))
		ii = 0
		for j in range(self.rows):
			for i in range(self.columns):
				self[j, i] = data[ii]
				ii += 1
		_n.ldprint('<-- nkj.cs.array.setDataString()')

	def getDataStr(self, rowend=''):
		return self.getDataString(rowend)

	def setDataStr(self, s):
		self.setDataString(s)

	@property
	def datastr(self):
		return self.getDataString()

	@datastr.setter
	def datastr(self, s):
		self.setDataString(s)

	@property
	def dstr(self):
		return self.getDataString()

	@dstr.setter
	def dstr(self, s):
		self.setDataString(s)

	@property
	def ds(self):
		return self.getDataString()

	@ds.setter
	def ds(self, s):
		self.setDataString(s)

	# Print

	def getPrintString(self, title=None):
		s = ''
		ndim = self.ndim
		_n.ldprint2("ndim: {}".format(ndim))
		if (ndim == 1):
			columns = len(self)
			_n.ldprint2("columns: {}".format(columns))
			if (title is not None):
				s += '{0}[{1}]: '.format(title, columns)
			for i in range(columns):
				if (i != 0):
					s += ', '
				s += '{0:16.12f}'.format(self[i])
		elif (ndim == 2):
			if (title is not None):
				s += '--- {} ---\n'.format(title)
			rows, columns = self.shape
			_n.ldprint2("array size: ({0}, {1})".format(rows, columns))
			for j in range(rows):
				for i in range(columns):
					if (i != 0):
						s += ', '
					s += '{0:16.12f}'.format(self[j, i])
				if (j < rows - 1):
					s += '\n'
			if (title is not None):
				s += '\n---'
		else:
			raise ValueError("__ERROR__: Illegal data shape.")
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

	# Load, Save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataStr(f.read())

	def save(self, filename, rowend=None):
		_n.ldprint('--> nkj.cs.array.save(\'{}\')'.format(filename))
		_n.ldprint('s: \'{}\''.format(self.getDataString(rowend)))
		_DATAEND = '\n'
		if (filename == '-'):
			print(self.getDataString(rowend) + _DATAEND, flush=True)
		else:
			with open(filename, 'w') as f:
				f.write(self.getDataString(rowend) + _DATAEND)
		_n.ldprint('<-- nkj.cs.array.save()')

	# isinstance

	def is_correctarray(self, x):
		_n.ldprint('-->> nkj.cs.array.is_correctarray()')
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint('x:    {0} ({1})'.format(x, type(x)))
		if (not isinstance(x, (list, tuple, np.ndarray))):
			_n.print_error('__ERROR__: Incorrect data type. @nkj.cs.array: NKJ-CS-00480.')
			return False
		s_arrdim = self.getArrayDimension()
		x_arrdim = np.array(x).ndim
		_n.ldprint('self array dimension: {}'.format(s_arrdim))
		_n.ldprint('x array dimension:    {}'.format(x_arrdim))
		if (x_arrdim == 1):  # for quaternion
			if (x_arrdim != s_arrdim):
				_n.print_error('__ERROR__: Incorrect array dimension. @nkj.cs.array: NKJ-CS-00488.')
				return False
			_n.ldprint('self array length: {}'.format(len(self)))
			_n.ldprint('x array length:    {}'.format(len(x)))
			if (len(x) != len(self)):
				_n.print_error('__ERROR__: Incorrect array length. @nkj.cs.array: NKJ-CS-00493.')
				return False
		elif (x_arrdim == 2):  # for vec, matrix
			if (x_arrdim != s_arrdim):
				_n.print_error('__ERROR__: Incorrect array dimension. @nkj.cs.array: NKJ-CS-00498.')
				return False
			s_rows, s_columns = self.getDimensions()
			x_rows, x_columns = np.array(x).shape
			_n.ldprint('self array shape: (rows:{0}, columns:{1})'.format(s_rows, s_columns))
			_n.ldprint('x array shape:    (rows:{0}, columns:{1})'.format(x_rows, x_columns))
			if (s_rows != x_rows or s_columns != x_columns):
				_n.print_error('__ERROR__: Incorrect array shape. @nkj.cs.array: NKJ-CS-00505.')
				return False
		else:
			_n.print_error('__ERROR__: Incorrect array shape.')
			return False
		return True

class array(array_cls):
	pass


#-- vec, mat

class vec_cls(ABC, array_cls):
	_classname = 'nkj.cs.vec'

	def __new__(cls, v):  # 次元（int）を指定するか，初期化のためのvec, list, tuple, np.array を指定する．self.__new__() では、次元が指定された時のみ対応．
		if (isinstance(v, int)):
			d = v
			v = None
		else:
			d = _nm.ndim(v)
		self = super().__new__(cls, shape=(d, 1), dtype='float32')  # shape=(d, 1): d次元の縦ベクトルを生成
		self.__residue = _DEFAULT_RESIDUE
		return self

	def __init__(self, v=None):
		super().__init__()
		self.__residue = _DEFAULT_RESIDUE
		if (v is None):
			self.zeros()
		elif (isinstance(v, int)):
			self.zeros()  # self.__new__() のための初期化のときに動作．
		else:
			self.set(v)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	# Operators

	"""
	def __getitem__(self, i):
		return self
	"""

	def __xor__(self, v):  # '^' operator
		return self.innerproduct(v)

	def __inv__(self):  # '~' operator
		return self.getInversed()

	# Get, Set

	def set(self, v):
		_n.ldprint("--> nkj.cs.vec.set()")
		_n.ldprint("v: {0} ({1})".format(v, type(v)))
		if (v is None):
			raise Exception('__ERROR__: Null input.')
		if (not isinstance(v, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Incorrect data type.')
		if (self.isinstance(v)):
			for i in range(self.dim):
				self.component(i, v.component(i))
		elif (self.is_correctrowvectorarray(v)):  # 1-D row array -> 1-D column array に整形
			for i in range(self.vdim):
				self.component(i, v[i])
		elif (self.is_correctvectorarray(v)):
			for i in range(self.vdim):
				self.component(i, v[i][0])
		else:
			raise TypeError('__ERROR__: Incorrect data type.')
		_n.ldprint("<-- nkj.cs.vec.set()")

	# Components

	def getComponents(self):
		_n.ldprint('--> nkj.cs.vec.getComponents()')
		ndim = _nm.ndim(self)
		if (ndim == 2):
			rows, columns = self.shape
			if (columns == 1):
				complist = []
				for i in range(rows):
					complist.append(self.component(i))
			else:
				_n.print_error('@ERROR: vec_cls should be a column vector, one-dimensional array for vertical.')
				raise Exception('__ERROR__: Illegal algorithm. NKJ-CS-00559.')
		else:
			raise Exception('__ERROR__: Illegal algorithm. NKJ-CS-00562.')
		_n.ldprint('components: {0} ({1})'.format(complist, type(complist)))
		_n.ldprint('<-- nkj.cs.vec.getComponents()')
		return complist

	def setComponents(self, x):
		_n.ldprint('--> nkj.cs.vec.setComponents()')
		_n.ldprint('x[{0}]: {1} ({2})'.format(len(x), x, type(x)))
		if (self.vdim != len(x)):
			ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		for i in range(self.vdim):
			self[i, 0] = x[i]
		_n.ldprint('<-- nkj.cs.vec.setComponents()')

	# Component

	def getComponent(self, i):
		_n.ldprint('--> nkj.cs.vec.getComponent({})'.format(i))
		_n.ldprint('self: {}'.format(self))
		if (nd.LIB_DEBUG0):
			ndim = _nm.ndim(self)
			_n.ldprint2('self.ndim: {}'.format(ndim))
			if (ndim == 1):
				raise ValueError('__ERROR__: Illegal data at self. NKJ-CS-00556.')
			elif (ndim == 2):
				rows, columns = self.shape
				if (columns != 1):
					raise ValueError('__ERROR__: Illegal data at self. NKJ-CS-00560.')
			if (not _nm.is_inrange(i, 0, rows - 1)):
				_n.ldprint2('index:      {}'.format(i))
				_n.ldprint2('self.shape: {}'.format(self.shape))
		_n.ldprint('<-- nkj.cs.vec.getComponent(): {}'.format(self[i, 0]))
		return self[i, 0]

	def setComponent(self, i, c):
		self[i, 0] = c
		return True

	def Component(self, i, c=None):
		return self.getComponent(i) if (c is None) else self.setComponent(i, c)

	def component(self, i, c=None):
		return self.getComponent(i) if (c is None) else self.setComponent(i, c)

	def comp(self, i, a=None):
		return self.component(i, a)

	def c(self, i, a=None):
		return self.component(i, a)

	def getValue(self, i):
		return self.getComponent(i)

	def setValue(self, i, x):
		return self.setComponent(i, x)

	def Value(self, i, x=None):
		return self.getValue(i) if (x is None) else self.setValue(x)

	def value(self, i, x=None):
		return self.getValue(i) if (x is None) else self.setValue(x)

	def val(self, i, x=None):
		return self.value(i, x)

	def getVectorDimension(self):
		rows, columns = self.shape
		if (columns != 1):
			raise ValueError("__ERROR__: Illegal shape")
		return rows

	def VectorDimension(self):
		return self.getVectorDimension()

	@property
	def vectordimension(self):
		return self.getVectorDimension()

	@property
	def vecdim(self):
		return self.getVectorDimension()

	@property
	def vdim(self):
		return self.getVectorDimension()

	def getResidue(self):
		return self.__residue

	def setResidue(self, x):
		self.__residue = x

	@property
	def residue(self):
		return self.getResidue()

	@residue.setter
	def residue(self, x):
		self.setResidue(x)

	@property
	def res(self):
		return self.getResidue()

	@res.setter
	def res(self, x):
		self.setResidue(x)

	def clear_residue(self):
		self.setResidue(_DEFAULT_RESIDUE)

	def clear_res(self):
		self.clear_residue()

	def clearresidue(self):
		self.clear_residue()

	def clearres(self):
		self.clear_residue()

	def getLength(self):
		csqsum = 0.0
		for i in range(self.getDim()):
			csqsum += _nm.sq(self.component(i))
		return math.sqrt(csqsum)

	def Length(self):
		return self.getLength()

	@property
	def length(self):
		return self.getLength()

	@property
	def len(self):
		return self.getLength()

	def getDistance(self):
		return self.Length()

	@property
	def distance(self):
		return self.getDistance()

	@property
	def dist(self):
		return self.getDistance()

	def getNorm(self):
		rows, columns = self.shape
		if (columns != 1):
			raise ValueError("__ERROR__: Illegal shape")
		powsum = 0.0
		for i in range(rows):
			powsum += self[i, 0] ** 2
		return math.sqrt(powsum)

	@property
	def norm(self):
		return self.getNorm()

	# Inverse, Transpose, Normalize

	def inverse(self):
		rows, columns = self.shape
		if (columns != 1):
			raise ValueError("__ERROR__: Illegal shape")
		for i in range(rows):
			self[i] *= -1
		return self

	def getInversed(self):
		iarr = copy.deepcopy(self)
		iarr.inverse()
		return iarr

	def Inversed(self):
		return self.getInversed()

	@property
	def inversed(self):
		return self.getInversed()

	@property
	def inv(self):
		return self.getInversed()

	@property
	def i(self):
		return self.getInversed()

	def transpose(self):
		rows, columns = self.shape
		if (columns != 1):
			raise ValueError("__ERROR__: Illegal shape")
		for i in range(math.floor(rows / 2)):
			swapvalue = self[i, 0]
			self[i, 0] = self[rows - 1 - i, 0]
			self[rows - 1 - i, 0] = swapvalue
		return self

	def getTransposed(self):
		tarr = copy.deepcopy(self)
		tarr .transpose()
		return tarr

	def Transposed(self):
		return self.getTransposed()

	@property
	def transposed(self):
		return self.getTransposed()

	@property
	def T(self):
		return self.getTransposed()

	def normalize(self):
		_n.ldprint("--> nkj.cs.vec.normalize()")
		norm = self.getNorm()
		if (nd.LIB_DEBUG):
			print('norm: {}'.format(norm))
			self.print('self (original)  ')
		self.set(self if (_nm.is_ineps(norm)) else self / norm)
		if (nd.LIB_DEBUG):
			self.print('self (normalized)')
		_n.ldprint("<-- nkj.cs.vec.normalize()")

	def getNormalized(self):
		_n.ldprint("--> nkj.cs.vec.getNormalized()")
		nv = copy.deepcopy(self)
		if (nd.LIB_DEBUG):
			nv.print('vector (original)  ')
		nv.normalize()
		if (nd.LIB_DEBUG):
			nv.print('vector (normalized)')
		_n.ldprint("<-- nkj.cs.vec.getNormalized()")
		return nv

	def Normalized(self):
		return self.getNormalized()

	@property
	def normalized(self):
		return self.getNormalized()

	# Homogeneous, Inhomogeneous

	def getHomogeneous(self):
		_n.ldprint('--> nkj.cs.vec.getHomogeneous()')
		if (self.vdim == 2):
			hv = vec2h_cls()
		elif (self.vdim == 3):
			hv = vec3h_cls()
		else:
			return None
		for i in range(self.vdim):
			hv[i, 0] = self[i, 0]
		hv[self.vdim, 0] = 1.0
		_n.ldprint('<-- nkj.cs.vec.getHomogeneous()')
		return hv

	def setHomogeneous(self, vh):
		for i in range(vh.vdim - 1):
			self[i, 0] = hv[i, 0]

	def Homogeneous(self, vh=None):
		if (vh is None):
			return self.getHomogeneous()
		else:
			self.setHomogeneous(vh)

	@property
	def homogeneous(self):
		return self.getHomogeneous()

	@homogeneous.setter
	def homogeneous(self, vh):
		self.setHomogeneous(vh)

	@property
	def h(self):
		return self.getHomogeneous()

	@h.setter
	def h(self, vh):
		self.setHomogeneous(vh)

	def getInhomogeneous(self):
		_n.ldprint("--> nkj.vec.getInhomogeneous()")
		if (is_vec2h(self)):
			v = vec2_cls([self.x, self.y])
		elif (is_vec3h(self)):
			v = vec3_cls([self.x, self.y, self.z])
		_n.ldprint("<-- nkj.vec.getInhomogeneous()")
		return v

	def setInhomogeneous(self, v):
		for i in range(v.vdim):
			self[i, 0] = v[i, 0]

	@property
	def inhomogeneous(self):
		return self.getInhomogeneous()

	@inhomogeneous.setter
	def inhomogeneous(self, ihv):
		self.setInhomogeneous(ihv)

	@property
	def ih(self):
		return self.getInhomogeneous()

	@ih.setter
	def ih(self, v):
		self.setInhomogeneous(v)

	# Goemetrical computation

	def innerproduct(self, v):
		_n.ldprint2("--> nkj.cs.vec.innerproduct()")
		_n.ldprint2('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint2('v:    {0} ({1})'.format(v, type(v)))
		if (not self.isinstance(v)):
			raise Exception('__ERROR__: Unsupport type of data.')
		sdim = self.vdim
		vdim = v.vdim
		if (sdim != vdim):
			_n.print_error('@ERROR: self.vdim: {}'.format(sdim))
			_n.print_error('@ERROR: v.vdim:    {}'.format(vdim))
			raise ValueError("__ERROR__: Illegal shape")
		_n.ldprint2("Dim: {}".format(sdim))
		v1 = self
		v2 = v
		val = 0.0
		for i in range(sdim):
			val += v1.c(i) * v2.c(i)
		_n.ldprint2("<-- nkj.cs.vec.innerproduct(): {}".format(val))
		return val

	def inner(self, v):
		return self.innerproduct(v)

	def dotproduct(self, v):
		return self.innerproduct(v)

	def dot(self, v):
		return self.innerproduct(v)

	def outerproduct(self, x):  # This function should be overrided at a child class.
		raise Exception('__ERROR__: Illegal algorithm. This functions should be overrided by a child class.')

	def outer(self, v):
		return self.outerproduct(v)

	def crossproduct(self, v):
		return self.outerproduct(v)

	def cross(self, v):
		return self.outerproduct(v)

	# Functions

	def getAngle(self, x):
		_n.print_error('@ERROR: This function should be implemented and overrided at the child class.')
		raise Exception('__ERROR__: Not implemented.')

	def angle(self, x):
		return self.getAngle(x)

	def ang(self, x):
		return self.getAngle(x)

	def rad(self, x):
		return self.getAngle(x)

	def deg(self, x):
		return _nm.rad2deg(self.getAngle(x))

	# Print String

	def getPrintString(self, title=None):
		_n.ldprint("--> nkj.cs.vec.getPrintString()")
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		_n.ldprint2("vector dimension: {}".format(self.vdim))
		s += '('
		for i in range(self.vdim):
			if (i != 0):
				s += ', '
			_n.ldprint2("component[{0}]: {1}".format(i, self.c(i)))
			s += '{0:12.6f}'.format(self.c(i))
		s += ')'
		_n.ldprint("<-- nkj.cs.vec.getPrintString()")
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True)

	# isinstance

	def is_correctrowvectorarray(self, x):
		_n.ldprint('-->> nkj.cs.vec.is_correctrowvectorarray()')
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint('x:    {0} ({1})'.format(x, type(x)))
		if (isinstance(x, (list, tuple, np.ndarray))):
			if (np.array(x).ndim == 1):
				s_rows, _ = self.getDimensions()
				if (len(x) == s_rows):
					_n.ldprint('@-- correct row array')
					return True
				else:
					_n.ldprint('@-- Not row array')
					return False
			else:
				_n.ldprint('@-- Not row array')
				return False
		else:
			_n.ldprint('@-- Not row array')
			return False

	def is_correctvectorarray(self, x):
		_n.ldprint('-->> nkj.cs.vec.is_correctvectorarray()')
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint('x:    {0} ({1})'.format(x, type(x)))
		if (self.isinstance(x)):
			return True
		if (not isinstance(x, (list, tuple, np.ndarray))):
			_n.print_error('__ERROR__: Incorrect data type. @nkj.cs.vec: NKJ-CS-00991.')
			return False
		s_arrdim = self.getArrayDimension()
		x_arrdim = np.array(x).ndim
		_n.ldprint('self array dimension: {}'.format(s_arrdim))
		_n.ldprint('x array dimension:    {}'.format(x_arrdim))
		if (x_arrdim != 2):
			_n.print_error('__ERROR__: Incorrect array dimension. @nkj.cs.vec: NKJ-CS-00998.')
			return False
		if (x_arrdim != s_arrdim):
			_n.print_error('__ERROR__: Incorrect array dimension. @nkj.cs.vec: NKJ-CS-01001.')
			return False
		s_rows, s_columns = self.getDimensions()
		x_rows, x_columns = np.array(x).shape
		_n.ldprint('self array shape: (rows:{0}, columns:{1})'.format(s_rows, s_columns))
		_n.ldprint('x array shape:    (rows:{0}, columns:{1})'.format(x_rows, x_columns))
		if (s_rows != x_rows or s_columns != x_columns):
			_n.print_error('__ERROR__: Incorrect array shape. @nkj.cs.vec: NKJ-CS-01008.')
			return False
		return True

	# isinstance

	def isinstance(self, x):
		return is_vec(x)

class vec(vec_cls):
	pass

class vector(vec_cls):
	pass

def is_vec(x):
	return isinstance(x, vec_cls)

def is_vector(x):
	return is_vec(x)


class mat_cls(array_cls):
	_classname = 'nkj.cs.mat'

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __inv__(self):  # '~' operator
		return self.getInversed()

	def getMatrixDimension(self):
		rows, _ = self.getDimensions()
		return rows

	def MatrixDimension(self):
		return self.getMatrixDimension()

	@property
	def matrixdimension(self):
		return self.getMatrixDimension()

	@property
	def matdim(self):
		return self.getMatrixDimension()

	@property
	def mdim(self):
		return self.getMatrixDimension()

	def getRows(self):
		rows, _ = self.getDimensions()
		return rows

	def getColumns(self):
		_, columns = self.getDimensions()
		return columns

	def Rows(self):
		return self.getRows()

	def Columns(self):
		return self.getColumns()

	@property
	def rows(self):
		return self.getRows()

	@property
	def columns(self):
		return self.getColumns()

	def getInversed(self):
		return np.linalg.inv(self)

	def Inversed(self):
		return self.getInversed()

	@property
	def inversed(self):
		return self.getInversed()

	@property
	def inv(self):
		return self.inversed

	@property
	def i(self):
		return self.inversed

	def inverse(self):
		self.set(self.getInversed())

	# Components

	def getComponents(self):
		_n.ldprint('--> nkj.cs.mat.getComponents()')
		complist = []
		for j in range(self.rows):
			for i in range(self.columns):
				complist.append(self[j, i])
		_n.ldprint('<-- nkj.cs.mat.getComponents()')
		return complist

	def setComponents(self, x):
		_n.ldprint('--> nkj.cs.mat.setComponents()')
		_n.ldprint('x[{0}]: {1} ({2})'.format(len(x), x, type(x)))
		if (len(x) != self.rows * self.columns):
			ns.print_error('Data lengths are different.')
			raise TypeError('__ERROR__: Illegal data.')
		ii = 0
		for j in range(self.rows):
			for i in range(self.columns):
				self[j, i] = x[ii]
				ii += 1
		_n.ldprint('<-- nkj.cs.mat.setComponents()')

	# Load, Save

	def save(self, filename, rowend='\n'):  # デフォルトで各行の終わりで改行する．１行のデータ記述にしたい場合は rowend = ', ' を指定．
		super().save(filename, rowend=rowend)

	# isinstance

	def isinstance(self, x):
		return is_mat(x)

class mat(mat_cls):
	pass

class matrix(mat):
	pass

def is_mat(x):
	return isinstance(x, mat_cls)

def is_matrix(x):
	return is_mat(x)


class vec2_cls(vec_cls):
	_classname = 'nkj.cs.vec2'

	def __new__(cls, v=None):
		self = super().__new__(cls, 2)  # 初期化するときは、生成したインスタンスを self に代入してインスタンス関数を呼び出す．
		return self                     # 必ず、self を return すること

	def __init__(self, v=None):
		super().__init__()
		self.set(_DEFAULT_VEC2 if (v is None) else v)

	def __mul__(self, second): # '*' operator
		if (self.isinstance(second)):  # nkj.cs.vec2
			return self.outerproduct(second)
		elif (_nm.is_digit(second)):
			return self.__rmul__(second)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def __rmul__(self, first):  # '*' right operator
		if (_nm.is_digit(first)):
			return vec2(first * self.array)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, v):
		_n.ldprint("--> nkj.cs.vec2.set()")
		_n.ldprint('v: {0} ({1})'.format(v, type(v)))
		_n.ldprint2("class name: {}".format(v.__class__.__name__))
		if (v is None):
			raise Exception('__ERROR__: Null input.')
		if (not self.is_correctvec2array(v)):
			raise TypeError('__ERROR__: Incorrect data.')
		if (self.isinstance(v) or is_vec2h(v)):
			for i in range(2):
				self.component(i, v.component(i))
#			self.setResidue(v.getResidue())
		elif (isinstance(v, (list, tuple, np.ndarray))):
			ndim = np.array(v).ndim
			if (ndim == 1):
				if (len(v) == 2):  # for arrays of vec2
					for i in range(2):
						self.component(i, v[i])
				else:
					raise TypeError('__ERROR__: Illegal data shape.')
			elif (ndim == 2):
				rows, columns = np.array(v).shape
				_n.ldprint('shape: ({0}, {1})'.format(rows, columns))
				if (rows == 2 and columns == 1):
					super().set(v)
				else:
					_n.print_error('v: {0} ({1})'.format(v, type(v)))
					_n.print_error('v.shape: ({0}, {1})'.format(rows, columns))
					raise TypeError('__ERROR__: Illegal data shape.')
		else:
			raise TypeError('__ERROR__: Illegal data type. NKJ-CS-00949.')
		_n.ldprint("<-- nkj.cs.vec2.set()")

	@property
	def x(self):
		return self[0][0]

	@x.setter
	def x(self, _x):
		self[0][0] = _x

	@property
	def y(self):
		return self[1][0]

	@y.setter
	def y(self, _y):
		self[1][0] = _y

	# Operations

	def outerproduct(self, v):
		_n.ldprint("--> nkj.cs.vec2.outerproduct()")
		if (not (self.isinstance(v) or vec2h.isinstance(v))):
			raise TypeError("__ERROR__: Illegal data type")
		val = self.c(0) * v.c(1) - self.c(1) * v.c(0)
		_n.ldprint("<-- nkj.cs.vec2.outerproduct()")
		return val

	def outer(self, v):
		return self.outerproduct(v)

	def crossproduct(self, v):
		return self.outerproduct(v)

	def cross(self, v):
		return self.outerproduct(v)

	@property
	def perpendicular_vector(self):
		return vec2([-self.component(1), self.component(0)])

	@property
	def perpendicularvector(self):
		return self.perpendicular_vector

	@property
	def perpendicular(self):
		return self.perpendicular_vector

	# Functions

	def getHexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Hexagon vertecies
		_METHOD = 2
		if (_METHOD == 1):
			m = mat2x2()
			m.rotate(_nm.deg2rad(60.0))
			plist = point2list()
			p = radius * vec2()
			for i in range(6):
				plist.append(p)
				p = m @ p
		elif (_METHOD == 2):
			plist = point2list()
			for i in range(6):
				theta60 = _nm.deg2rad(60.0 * float(i))
				plist.append(vec2([radius * math.cos(theta60), radius * math.sin(theta60)]))
		else:
			raise ValueError('__ERROR__: Illegal value. _METHOD.')
		return plist

	def HexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getHexiagonVerts(radius)

	@property
	def hexagonverts(self):
		return self.getHexagonVerts()

	def getOriginAndHexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Origin and hexagon vertecies
		plist = point2list()
		plist.append([0.0, 0.0])
		plist.append(self.getHexagonVerts(radius))
		return plist

	def OriginAndHexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getOriginAndHexagonVerts(radius)

	@property
	def origin_and_hexagonverts(self):
		return self.getHexagonVerts()

	# Homogenenous

	@property
	def vec3(self):
		return self.getHomogeneous()

	@vec3.setter
	def vec3(self, vh):
		self.setHomogeneous(vh)

	@property
	def v3(self):
		return self.getHomogeneous()

	@v3.setter
	def v3(self, vh):
		self.setHomogeneous(vh)

	def getAngle(self, x):
		_n.ldprint('--> nkj.cs.vec2.getAngle()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		c = self.innerproduct(x)
		s = self.outerproduct(x)
		_n.ldprint('(cos, sin): ({0}, {1})'.format(c, s))
		angle = math.atan2(s, c)
		_n.ldprint2('angle: {}'.format(_nm.rad2deg(angle)))
		_n.ldprint('<-- nkj.cs.vec2.getAngle()')
		return angle

	# isinstance

	def is_correctvec2array(self, x):
		if (super().is_correctrowvectorarray(x)):
			vdim = len(x)
		elif (super().is_correctvectorarray(x)):
			rows, _ = np.array(x).shape
			vdim = rows
		else:
			return False
		return True if (vdim == 2) else False

	def isinstance(self, v):
		return is_vec2(v)

class vec2(vec2_cls):
	pass

class v2(vec2_cls):
	pass

class csv2(vec2_cls):
	pass

class point2(vec2_cls):
	pass

def is_vec2(v):
	return isinstance(v, vec2_cls)

def is_csv2(v):
	return is_vec2(v)

def is_point2(v):
	return is_vec2(v)


class vec2h_cls(vec_cls):
	_classname = 'nkj.cs.vec2h'

	def __new__(cls, v=None):
		self = super().__new__(cls, 3)
		return self

	def __init__(self, v=None):
		super().__init__()
		self.set(_DEFAULT_VEC2H if (v is None) else v)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, v):
		_n.ldprint("--> nkj.cs.vec2h.set()")
		if (v is None):
			raise Exception('__ERROR__: Null input.')
		if (not self.is_correctvec2harray(v)):
			raise TypeError('__ERROR__: Incorrect data.')
		if (self.isinstance(v) or is_vec2(v)):
			for i in range(2):
				self.component(i, v.component(i))
		elif (isinstance(v, (list, tuple, np.ndarray))):
			ndim = np.array(v).ndim
			if (ndim == 1):
				if (len(v) == 2 or len(v) == 3):  # for arrays of vec2 and vec2h
					for i in range(2):
						self.component(i, v[i])
					if (len(v) == 3):
						if (v[2] != 1.0):
							raise ValueError('__ERROR__: Illegal data.')
					self.component(2, 1.0)
				else:
					raise TypeError('__ERROR__: Illegal data shape.')
			elif (ndim == 2):
				rows, columns = np.array(v).shape
				_n.ldprint('shape: ({0}, {1})'.format(rows, columns))
				if (rows == 2 and columns == 1):
					super().set(v)
				elif (rows == 3 and columns == 1):
					super().set(v)
				else:
					_n.print_error('v: {0} ({1})'.format(v, type(v)))
					_n.print_error('v.shape: ({0}, {1})'.format(rows, columns))
					raise TypeError('__ERROR__: Illegal data shape.')
			else:
				raise TypeError('__ERROR__: Illegal data shape.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint("<-- nkj.cs.vec2h.set()")

	@property
	def x(self):
		return self[0][0]

	@x.setter
	def x(self, _x):
		self[0][0] = _x

	@property
	def y(self):
		return self[1][0]

	@y.setter
	def y(self, _y):
		self[1][0] = _y

	def is_correctvec2harray(self, x):
		if (super().is_correctrowvectorarray(x)):
			vdim = len(x)
		elif (super().is_correctvectorarray(x)):
			rows, _ = np.array(x).shape
			vdim = rows
		else:
			return False
		return True if (vdim == 3) else False

	def isinstance(self, v):
		return is_vec2h(v)

class vec2h(vec2h_cls):
	pass

class v2h(vec2h_cls):
	pass

class csv2h(vec2h_cls):
	pass

class point2h(vec2h_cls):
	pass

def is_vec2h(v):
	return isinstance(v, vec2h_cls)

def is_csv2h(v):
	return is_vec2h(v)

def is_point2h(x):
	return is_vec2h(x)


class vec3_cls(vec_cls):
	_classname = 'nkj.cs.vec3'

	def __new__(cls, v=None):
		self = super().__new__(cls, 3)
		return self

	def __init__(self, v=None):
		super().__init__()
		self.set(_DEFAULT_VEC3 if (v is None) else v)

	def __mul__(self, second): # '*' operator
		if (self.isinstance(second)):  # nkj.cs.vec3
			return self.outerproduct(second)
		elif (_nm.is_digit(second)):
			return self.__rmul__(second)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def __rmul__(self, first):  # '*' right operator
		if (_nm.is_digit(first)):
			_n.ldprint('@-- is_digit(), first: {0} ({1})'.format(first, type(first)))
			return vec3(first * self.array)
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, v):
		_n.ldprint("--> nkj.cs.vec3.set()")
		if (v is None):
			raise Exception('__ERROR__: Null input.')
		if (not self.is_correctvec3array(v)):
			raise TypeError('__ERROR__: Incorrect data.')
		if (self.isinstance(v) or is_vec3h(v)):
			for i in range(3):
				self.component(i, v.component(i))
#			self.setResidue(v.getResidue())
		elif (isinstance(v, (list, tuple, np.ndarray))):
			ndim = np.array(v).ndim
			if (ndim == 1):
				if (len(v) == 3):  # for arrays of vec3
					for i in range(3):
						self.component(i, v[i])
				else:
					raise TypeError('__ERROR__: Illegal data shape.')
			elif (ndim == 2):
				rows, columns = np.array(v).shape
				_n.ldprint('shape: ({0}, {1})'.format(rows, columns))
				if (rows == 3 and columns == 1):
					super().set(v)
				else:
					_n.print_error('v: {0} ({1})'.format(v, type(v)))
					_n.print_error('v.shape: ({0}, {1})'.format(rows, columns))
					raise TypeError('__ERROR__: Illegal data shape.')
			else:
				raise TypeError('__ERROR__: Illegal data shape.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint("<-- nkj.cs.vec3.set()")

	@property
	def x(self):
		return self[0][0]

	@x.setter
	def x(self, _x):
		self[0][0] = _x

	@property
	def y(self):
		return self[1][0]

	@y.setter
	def y(self, _y):
		self[1][0] = _y

	@property
	def z(self):
		return self[2][0]

	@z.setter
	def z(self, _z):
		self[2][0] = _z

	# Get matrix

	def getAxisMat3x4(self, index):
		m = mat3x4()
		return VectorRotationMat3x4(m.getColumn3(index), self)

	def getXaxisMat3x4(self):
		return self.getAxisMat3x4(0)

	def getYaxisMat3x4(self):
		return self.getAxisMat3x4(1)

	def getZaxisMat3x4(self):
		return self.getAxisMat3x4(2)

	def getXaxisMatrix(self):
		return self.getXaxisMat3x4()

	def getYaxisMatrix(self):
		return self.getYaxisMat3x4()

	def getZaxisMatrix(self):
		return self.getZaxisMat3x4()

	@property
	def xaxismatrix(self):
		return self.getXaxisMatrix()

	@property
	def yaxismatrix(self):
		return self.getYaxisMatrix()

	@property
	def xaxism(self):
		return self.getXaxisMatrix()

	@property
	def yaxism(self):
		return self.getYaxisMatrix()

	@property
	def zaxism(self):
		return self.getZaxisMatrix()

	def getMat3x4(self, index=_ZAXISINDEX):
		return self.getAxisMat3x4(index)

	def mat3x4(self, index=_ZAXISINDEX):
		return self.getMat3x4(index)

	def getMatrix(self, index=_ZAXISINDEX):
		return self.getMat3x4(index)

	def matrix(self, index=_ZAXISINDEX):
		return self.getMatrix(index)

	def mat(self, index=_ZAXISINDEX):
		return self.getMatrix(index)

	def m(self, index=_ZAXISINDEX):
		return self.getMatrix(index)

	# Icosahedron verts

	def getIcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Icosahedron vertecies
		_n.ldprint('--> nkj.cs.vec3.getIcosahedronVerts()')
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint('radius: {}'.format(radius))
		phi = (1.0 + math.sqrt(5.0)) / 2.0
		plist = point3list()
		plist.append(self + radius * vec3([ 0.0,  1.0,  phi]))
		plist.append(self + radius * vec3([ 0.0,  1.0, -phi]))
		plist.append(self + radius * vec3([ 0.0, -1.0,  phi]))
		plist.append(self + radius * vec3([ 0.0, -1.0, -phi]))
		plist.append(self + radius * vec3([ 1.0,  phi,  0.0]))
		plist.append(self + radius * vec3([ 1.0, -phi,  0.0]))
		plist.append(self + radius * vec3([-1.0,  phi,  0.0]))
		plist.append(self + radius * vec3([-1.0, -phi,  0.0]))
		plist.append(self + radius * vec3([ phi,  0.0,  1.0]))
		plist.append(self + radius * vec3([ phi,  0.0, -1.0]))
		plist.append(self + radius * vec3([-phi,  0.0,  1.0]))
		plist.append(self + radius * vec3([-phi,  0.0, -1.0]))
		if (nd.LIB_DEBUG):
			plist.print('Icosahedron verts')
		_n.ldprint('<-- nkj.cs.vec3.getIcosahedronVerts()')
		return plist

	def IcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getIcosahedronVerts(radius)

	@property
	def icosahedronverts(self):
		return self.getIcosahedronVerts()

	def getOriginAndIcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Origin and icosahedron vertecies
		plist = point3list()
		plist.append(self)
		plist.append(self.getIcosahedronVerts(radius))
		return plist

	def OriginAndIcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getOriginAndIcosahedronnVerts(radius)

	@property
	def origin_and_icosahedronverts(self):
		return self.getOriginAndIcosahedronVerts()

	# Operations

	def outerproduct(self, v):
		_n.ldprint("--> vec3_cls.outerproduct()")
		if (not self.isinstance(v)):
			raise TypeError("__ERROR__: Illegal data type")
		v = vec3([self.c(1) * v.c(2) - self.c(2) * v.c(1),
				self.c(2) * v.c(0) - self.c(0) * v.c(2),
				self.c(0) * v.c(1) - self.c(1) * v.c(0)])
		if (False):
			v.print("outerproduct")
		_n.ldprint("<-- vec3_cls.outerproduct()")
		return v

	def outer(self, v):
		return self.outerproduct(v)

	def crossproduct(self, v):
		return self.outerproduct(v)

	def cross(self, v):
		return self.outerproduct(v)

	def multiplied(self, second):
		_n.ldprint("--> nkj.cs.vec3.muptiplied({})".format(second))
		if (_nm.is_digit(second)):
			retval = vec3(super().__mul__(second))
		else:
			raise TypeError("__ERROR__: Illegal data type")
		_n.ldprint("<-- nkj.cs.vec3.muptiplied()")
		return retval

	def is_correctvec3array(self, x):
		if (super().is_correctrowvectorarray(x)):
			vdim = len(x)
		elif (super().is_correctvectorarray(x)):
			rows, _ = np.array(x).shape
			vdim = rows
		else:
			return False
		return True if (vdim == 3) else False

	# Homogeneous

	@property
	def vec4(self):
		return self.getHomogeneous()

	@vec4.setter
	def vec4(self, vh):
		self.setHomogeneous(vh)

	@property
	def v4(self):
		return self.getHomogeneous()

	@v4.setter
	def v4(self, vh):
		self.setHomogeneous(vh)

	@property
	def vec2(self):
		return self.getInhomogeneous()

	@vec2.setter
	def vec2(self, ihv):
		self.setInhomogeneous(ihv)

	@property
	def v2(self):
		return self.getInhomogeneous()

	@v2.setter
	def v2(self, ihv):
		self.setInhomogeneous(ihv)

	# Geomerical computation

	def getAngle(self, x):
		_n.ldprint('--> nkj.cs.vec3.getAngle()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		c = self.innerproduct(x)
		s = self.outerproduct(x).norm
		_n.ldprint('(cos, sin): ({0}, {1})'.format(c, s))
		angle = math.atan2(s, c)
		_n.ldprint2('angle: {}'.format(_nm.rad2deg(angle)))
		_n.ldprint('<-- nkj.cs.vec3.getAngle()')
		return angle

	def lerp(self, second):
		return Lerp(self, second)

	# isinstance

	def isinstance(self, v):
		return is_vec3(v)

class vec3(vec3_cls):
	pass

class v3(vec3_cls):
	pass

class csv3(vec3_cls):
	pass

class point3(vec3_cls):
	pass

def is_vec3(x):
	_n.ldprint("--> nkj.cs.is_vec3()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs..is_vec3()")
	return isinstance(x, vec3_cls)

def is_csv3(v):
	return is_vec3(v)

def is_point3(v):
	return is_vec3(v)


class vec3h_cls(vec_cls):
	_classname = 'nkj.cs.vec3h'

	def __new__(cls, v=None):
		self = super().__new__(cls, 4)
		return self

	def __init__(self, v=None):
		super().__init__()
		self.set(_DEFAULT_VEC3H if (v is None) else v)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, v):
		_n.ldprint("--> nkj.cs.vec3h.set()")
		if (v is None):
			raise Exception('__ERROR__: Null input.')
		if (not self.is_correctvec3harray(v)):
			raise TypeError('__ERROR__: Incorrect data.')
		if (self.isinstance(v) or is_vec3(v)):
			for i in range(3):
				self.component(i, v.component(i))
#			self.setResidue(v.getResidue())
		elif (isinstance(v, (list, tuple, np.ndarray))):
			ndim = np.array(v).ndim
			if (ndim == 1):
				if (len(v) == 3 or len(v) == 4):  # for arrays of vec3 and vec3h
					for i in range(3):
						self.component(i, v[i])
					if (len(v) == 4):
						if (v[3] != 1.0):
							raise TypeError('__ERROR__: Illegal data.')
					self.component(3, 1.0)
				else:
					raise TypeError('__ERROR__: Illegal data shape.')
			elif (ndim == 2):
				rows, columns = np.array(v).shape
				_n.ldprint('shape: ({0}, {1})'.format(rows, columns))
				if (rows == 4 and columns == 1):    # for vec3h
					if (v[3][0] != 1.0):
						raise ValueError('__ERROR__: Illegal value.')
					super().set(v)
				elif (rows == 3 and columns == 1):  # for vec3
					for i in range(3):
						self.component(i, v[i][0])
				else:
					_n.print_error('v: {0} ({1})'.format(v, type(v)))
					_n.print_error('v.shape: ({0}, {1})'.format(rows, columns))
					raise TypeError('__ERROR__: Illegal data shape.')
			else:
				raise TypeError('__ERROR__: Illegal data shape.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint("<-- nkj.cs.vec3h.set()")

	@property
	def x(self):
		return self[0][0]

	@x.setter
	def x(self, _x):
		self[0][0] = _x

	@property
	def y(self):
		return self[1][0]

	@y.setter
	def y(self, _y):
		self[1][0] = _y

	@property
	def z(self):
		return self[2][0]

	@z.setter
	def z(self, _z):
		self[2][0] = _z

	def isinstance(self, v):
		return is_vec3h(v)

	def lerp(self, second):
		return Lerp(self, second)

	def is_correctvec3harray(self, x):
		if (super().is_correctrowvectorarray(x)):
			vdim = len(x)
		elif (super().is_correctvectorarray(x)):
			rows, _ = np.array(x).shape
			vdim = rows
		else:
			return False
		return True if (vdim == 4) else False

	# Homogeneous

	@property
	def vec3(self):
		return self.getInhomogeneous()

	@vec3.setter
	def vec3(self, ihv):
		self.setInhomogeneous(ihv)

	@property
	def v3(self):
		return self.getInhomogeneous()

	@v3.setter
	def v3(self, ihv):
		self.setInhomogeneous(ihv)

	# isinstance

	def isinstance(self, x):
		return is_vec3h(x)

class vec3h(vec3h_cls):
	pass

class v3h(vec3h_cls):
	pass

class csv3h(vec3h_cls):
	pass

class point3h(vec3h_cls):
	pass

def is_vec3h(x):
	_n.ldprint("--> nkj.cs.is_vec3h()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs.is_vec3h()")
	return isinstance(x, vec3h_cls)

def is_csv3h(x):
	return is_vec3h(x)

def is_point3h(x):
	return is_vec3h(x)


class vec4_cls(vec_cls):
	_classname = 'nkj.cs.vec4'

	def __new__(cls, v=None):
		self = super().__new__(cls, 4)
		return self

	def __init__(self, v=None):
		super().__init__()
		self.set(_DEFAULT_VEC4 if (v is None) else v)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, v):
		_n.ldprint("--> nkj.cs.vec4.set()")
		if (v is None):
			raise Exception('__ERROR__: Null input.')
		if (not self.is_correctvec4array(v)):
			raise TypeError('__ERROR__: Incorrect data.')
		if (self.isinstance(v)):
			for i in range(4):
				self.component(i, v.component(i))
#			self.setResidue(v.getResidue())
		elif (isinstance(v, (list, tuple, np.ndarray))):
			ndim = np.array(v).ndim
			if (ndim == 1):
				if (len(v) == 4):  # for arrays of vec4
					for i in range(4):
						self.component(i, v[i])
				else:
					raise TypeError('__ERROR__: Illegal data shape.')
			elif (ndim == 2):
				rows, columns = np.array(v).shape
				_n.ldprint('shape: ({0}, {1})'.format(rows, columns))
				if (rows == 4 and columns == 1):
					super().set(v)
				else:
					_n.print_error('v: {0} ({1})'.format(v, type(v)))
					_n.print_error('v.shape: ({0}, {1})'.format(rows, columns))
					raise TypeError('__ERROR__: Illegal data shape.')
			else:
				raise TypeError('__ERROR__: Illegal data shape.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint("<-- nkj.cs.vec4.set()")

	@property
	def x(self):
		return self[0][0]

	@x.setter
	def x(self, _x):
		self[0][0] = _x

	@property
	def y(self):
		return self[1][0]

	@y.setter
	def y(self, _y):
		self[1][0] = _y

	@property
	def z(self):
		return self[2][0]

	@z.setter
	def z(self, _z):
		self[2][0] = _z

	@property
	def w(self):
		return self[3][0]

	@w.setter
	def w(self, _w):
		self[3][0] = _w

	def is_correctvec4array(self, x):
		if (super().is_correctrowvectorarray(x)):
			vdim = len(x)
		elif (super().is_correctvectorarray(x)):
			rows, _ = np.array(x).shape
			vdim = rows
		else:
			return False
		return True if (vdim == 4) else False

	# Homogeneous

	@property
	def vec3(self):
		return self.getInhomogeneous()

	@vec3.setter
	def vec3(self, ihv):
		self.setInhomogeneous(ihv)

	@property
	def v3(self):
		return self.getInhomogeneous()

	@v3.setter
	def v3(self, ihv):
		self.setInhomogeneous(ihv)

	# isinstance

	def isinstance(self, v):
		return is_vec4(v)

class vec4(vec4_cls):
	pass

class v4(vec4_cls):
	pass

def is_vec4(x):
	_n.ldprint("--> nkj.cs.is_vec4()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs.is_vec4()")
	return isinstance(x, vec4_cls)

def is_v4(x):
	return is_vec4(x)


#---- mat2x2, mat3x3, mat4x4, mat2x3, mat3x4

class mat2x2_cls(mat_cls):
	_classname = 'nkj.cs.mat2x2'

	def __new__(cls, m=None):
		self = super().__new__(cls, shape=(2, 2), dtype='float32')
		self.set(_DEFAULT_MAT2X2 if (m is None) else m)
		return self

	def __init__(self, m=None):
		super().__init__()
		self.set(_DEFAULT_MAT2X2 if (m is None) else m)

	@classmethod
	def getClassName(cls):
		return cls._classname

	def __matmul__(self, second):
		if (self.isinstance(second)):
			return mat2x2(second.array @ self.array)
		elif (is_vec2(second)):
			return vec2(self.array @ second.array)
		elif (second is None):
			raise TypeError("__ERROR__: Illegal data type")
		else:
			return second.__rmatmul__(self)

	def __rmatmul__(self, first):
		raise Exception("__ERROR__: Not implemented")

	def set(self, m):
		if (nd.LIB_DEBUG0):
			ndim = np.array(m).ndim
			if (ndim != 2):
				raise TypeError('__ERROR__: Incorrect data shape.')
			rows, columns = np.array(m).shape
			if (rows != 2 or columns != 2):
				raise TypeError('__ERROR__: Incorrect data shape.')
		super().set(_DEFAULT_MAT2X2 if (m is None) else m)

	def getRow(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01472.")
		return vec2([self[index][0], self[index][1]])

	def setRow(self, index, v):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01546.")
		if (is_vec2(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 2):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec2(v)
		for i in range(2):
			self[index][i] = v.component(i)

	def getColumn(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01481.")
		return vec2([self[0][index], self[1][index]])

	def setColumn(self, index, v):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01546.")
		if (is_vec2(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 2):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec2(v)
		for i in range(2):
			self[i][index] = v.component(i)

	def row(self, index, v=None):
		if (v is None):
			return self.getRow(index)
		else:
			self.setRow(index, v)

	def column(self, index, v=None):
		if (v is None):
			return self.getColumn(index)
		else:
			self.setColumn(index, v)

	def getRow2(self, index):
		return self.getRow(index)

	def setRow2(self, index, v):
		self.setRow(index, v)

	def getColumn2(self, index):
		return self.getColumn(index)

	def setColumn2(self, index, v):
		self.setColumn(index, v)

	def row2(self, index, v=None):
		if (v is None):
			return self.getRow2(index)
		else:
			self.setRow2(index, v)

	def column2(self, index, v=None):
		if (v is None):
			return self.getColumn2(index)
		else:
			self.setColumn2(index, v)

	def getXaxis(self):
		return self.getColumn2(0)

	def getYaxis(self):
		return self.getColumn2(1)

	def getZaxis(self):
		return self.getColumn2(2)

	@property
	def xaxis(self):
		return self.getXaxis()

	@property
	def yaxis(self):
		return self.getYaxis()

	@property
	def zaxis(self):
		return self.getZaxis()

	# Identification

	def identity(self):
		return self.set(_DEFAULT_MAT2X2)

	def identify(self):
		return self.identity()

	# Orthonormalization

	def orthonormalize(self):
		c = (self[0, 0] + self[1, 1]) / 2.0
		s = (-self[0, 1] + self[1, 0]) / 2.0
		angle = math.atan2(s, c)
		self[0, 0] = math.cos(angle)
		self[0, 1] = -math.sin(angle)
		self[1, 0] = math.sin(angle)
		self[1, 1] = math.cos(angle)

	def OrthoNormalize(self):
		self.orthonormalize()

	def Orthonormalize(self):
		self.orthonormalize()

	def getOrthoNormalized(self):
		m = copy.deepcopy(self)
		m.orthonormalize()
		return m

	def OrthoNormalized(self):
		return self.getOrthoNormalized(self)

	def Orthonormalized(self):
		return self.getOrthoNormalized(self)

	@property
	def orthonormalized(self):
		return self.getOrthoNormalized(self)

	# Rotation

	def rotatelocal(self, x):
		_n.ldprint("--> nkj.cs.mat2x2.rotatelocal({:.3f} deg)".format(_nm.rad2deg(x)))
		if (self.isinstance(x)):
			rm = x
		elif (_nm.is_digit(x)):
			c = math.cos(x)
			s = math.sin(x)
			rm = mat2x2([[c, -s], [s, c]])
		else:
			raise TypeError("__ERROR__: Illegal data type")
		if (nd.LIB_DEBUG2):
			self.print("self (original)")
		m = self @ rm
		self.set(m)
		if (nd.LIB_DEBUG2):
			self.print("self (rotated)")
		_n.ldprint("<-- nkj.cs.mat2x2.rotatelocal()")

	def rotatedlocal(self, x):
		_n.ldprint("--> nkj.cs.mat2x2.rotatedlocal({:.3f} deg)".format(_nm.rad2deg(x)))
		m = copy.deepcopy(self)
		if (nd.LIB_DEBUG2):
			m.print("m (original)")
		m.rotatelocal(x)
		if (nd.LIB_DEBUG2):
			m.print("m (rotated local)")
		_n.ldprint("<-- nkj.cs.mat2x2.rotatedlocal()")
		return m

	def rotateglobal(self, x):
		if (_nm.is_digit(x)):
			c = math.cos(x)
			s = math.sin(x)
			rm = mat2x2([[c, -s], [s, c]])
		elif (self.isinstance(x)):
			rm = x
		else:
			raise TypeError("__ERROR__: Illegal data type")
		m = rm @ self
		self.set(m)

	def rotatedglobal(senf, x):
		m = copy.deepcopy(self)
		m.rotateglobal(x)
		return m

	# isinstance

	def isinstance(self, x):
		return is_mat2x2(x)

class mat2x2(mat2x2_cls):
	pass

class m2x2(mat2x2_cls):
	pass

class rotmat2(mat2x2_cls):
	pass

class rmat2(mat2x2_cls):
	pass

class rcsm2(mat2x2_cls):
	pass

class rcs2(mat2x2_cls):
	pass

def is_mat2x2(x):
	_n.ldprint("--> nkj.cs.is_mat2x2()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs.is_mat2x2()")
	return isinstance(x, mat2x2_cls)

def is_m2x2(x):
	return is_mat2x2(x)

def is_rotmat2(x):
	return is_mat2x2(x)

def is_rmat2(x):
	return is_mat2x2(x)

def is_rcsm2(x):
	return is_mat2x2(x)

def is_rcs2(x):
	return is_mat2x2(x)


class mat3x3_cls(mat_cls):
	_classname = 'nkj.cs.mat3x3'

	def __new__(cls, m=None):
		self = super().__new__(cls, shape=(3, 3), dtype='float32')
		self.set(_DEFAULT_MAT3X3 if (m is None) else m)
		return self

	def __init__(self, m=None):
		super().__init__()
		self.set(_DEFAULT_MAT3X3 if (m is None) else m)

	@classmethod
	def getClassName(cls):
		return cls._classname

	def __matmul__(self, second):
		if (self.isinstance(second)):
			return mat3x3(second.array @ self.array)
		elif (is_vec2(second)):
			return vec2h(self.array @ second.h.array).ih
		elif (is_vec2h(second)):
			return vec2h(self.array @ second.array)
		elif (is_vec3(second)):
			return vec3(self.array @ second.array)
		elif (second is None):
			raise TypeError("__ERROR__: Illegal data type")
		else:
			return second.__rmatmul__(self)

	def __rmatmul__(self, first):
		raise Exception("__ERROR__: Not implemented")

	def set(self, x):
		_n.ldprint("--> nkj.cs.mat3x3.set()")
		_n.ldprint2("x: {}".format(x))
		_n.ldprint2("class name: {}".format(_n.classname(x)))
		if (x is None):
			super().set(_DEFAULT_MAT3X3)
		elif (self.isinstance(x)):  # mat3x3
			super().set(x)
		elif (is_mat2x3(x)):
			for j in range(2):
				for i in range(3):
					self[j, i] = x[j, i]
			for i in range(3):
				self[2, i] = 1.0 if (i == 2) else 0.0
		elif (isinstance(x, scipy.spatial.transform._rotation.Rotation)):
			super().set(x.as_matrix())
		elif (isinstance(x, np.quaternion)):
			q = scipyquaternion()
			q.setNumpyQuaternion(x)
			rm = q.getMat3x3()
		elif (isinstance(x, (list, tuple, np.ndarray))):
			if (nd.LIB_DEBUG0):
				ndim = np.array(x).ndim
				if (ndim != 2):
					raise TypeError('__ERROR__: Incorrect data shape.')
				rows, columns = np.array(x).shape
				if (rows != 3 or columns != 3):
					raise TypeError('__ERROR__: Incorrect data shape.')
			super().set(x)
		else:
			raise TypeError('__ERROR__: Incorrect data shape.')
		_n.ldprint("<-- nkj.cs.mat3x3.set()")

	def getRow(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01694.")
		return vec3([self[index][0], self[index][1], self[index][2]])

	def setRow(self, index, v):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01775.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec3(v)
		for i in range(3):
			self[index][i] = v.component(i)

	def getColumn(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01703.")
		return vec3([self[0][index], self[1][index], self[2][index]])

	def setColumn(self, index, v):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01788.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec3(v)
		for i in range(3):
			self[i][index] = v.component(i)

	def row(self, index, v=None):
		if (v is None):
			return self.getRow(index)
		else:
			self.setRow(index, v)

	def column(self, index, v=None):
		if (v is None):
			return self.getColumn(index)
		else:
			self.setColumn(index, v)

	def getRow3(self, index):
		return self.getRow(index)

	def setRow3(self, index, v):
		self.setRow(index, v)

	def getColumn3(self, index):
		return self.getColumn(index)

	def setColumn3(self, index, v):
		self.setColumn(index, v)

	def row3(self, index, v=None):
		if (v is None):
			return self.getRow3(index)
		else:
			self.setRow3(index, v)

	def column3(self, index, v=None):
		if (v is None):
			return self.getColumn3(index)
		else:
			self.setColumn3(index, v)

	def getXaxis3(self):
		return self.getColumn3(0)

	def setXaxis3(self, v):
		self.setColumn3(0, v)

	def getYaxis3(self):
		return self.getColumn3(1)

	def setYaxis3(self, v):
		self.setColumn3(1, v)

	def getZaxis3(self):
		return self.getColumn3(2)

	def setZaxis3(self, v):
		self.setColumn3(2, v)

	@property
	def xaxis3(self):
		return self.getXaxis()

	@xaxis3.setter
	def xaxis3(self, v):
		self.setXaxis(v)

	@property
	def yaxis3(self):
		return self.getYaxis()

	@yaxis3.setter
	def yaxis3(self, v):
		self.setYaxis(v)

	@property
	def zaxis3(self):
		return self.getZaxis()

	@zaxis3.setter
	def zaxis3(self, v):
		self.setZaxis(v)

	def getXaxis(self):
		return self.getXaxis3()

	def setXaxis(self, v):
		self.setXaxis3(v)

	def getYaxis(self):
		return self.getYaxis3()

	def setYaxis(self, v):
		self.setYaxis3(v)

	def getZaxis(self):
		return self.getZaxis3()

	def setZaxis(self, v):
		self.setZaxis3(v)

	@property
	def xaxis(self):
		return self.getXaxis()

	@xaxis.setter
	def xaxis(self, v):
		self.setXaxis(v)

	@property
	def yaxis(self):
		return self.getYaxis()

	@yaxis.setter
	def yaxis(self, v):
		self.setYaxis(v)

	@property
	def zaxis(self):
		return self.getZaxis()

	@zaxis.setter
	def zaxis(self, v):
		self.setZaxis(v)

	def getRow2(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01694.")
		return vec2([self[index][0], self[index][1]])

	def setRow2(self, index, v):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01821.")
		if (is_vec2(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 2):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec2(v)
		for i in range(2):
			self[index][i] = v.component(i)

	def getColumn2(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01831.")
		return vec2([self[0][index], self[1][index]])

	def setColumn2(self, index, v):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-01834.")
		if (is_vec2(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 2):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")

	def getXaxis2(self):
		return self.getColumn2(0)

	def setXaxis2(self, v):
		self.setColumn2(0, v)

	def getYaxis2(self):
		return self.getColumn2(1)

	def setYaxis2(self, v):
		self.setColumn2(1, v)

	def getZaxis2(self):
		return self.getColumn2(2)

	def setZaxis2(self, v):
		self.setColumn2(2, v)

	def row2(self, index, v=None):
		if (v is None):
			return self.getRow2(index)
		else:
			self.setRow2(index, v)

	def column2(self, index, v=None):
		if (v is None):
			return self.getColumn2(index)
		else:
			self.setColumn2(index, v)

	@property
	def xaxis2(self):
		return self.getXaxis2()

	@xaxis2.setter
	def xaxis2(self, v):
		self.setXaxis2(v)

	@property
	def yaxis2(self):
		return self.getYaxis2()

	@yaxis2.setter
	def yaxis2(self, v):
		self.setYaxis2(v)

	@property
	def zaxis2(self):
		return self.getZaxis2()

	@zaxis2.setter
	def zaxis2(self, v):
		self.setZaxis2(v)

	def getTranslation2(self):
		return self.getColumn2(3)

	def setTranslation2(self, v):
		self.setColumn2(3, v)

	def getTrans2(self):
		return self.getTranslation2()

	def setTrans2(self, v):
		self.setColumn2(3, v)

	@property
	def translation2(self):
		return self.getTranslation2()

	@translation2.setter
	def translation2(self, v):
		self.setTranslation2(v)

	@property
	def trans2(self):
		return self.getTranslation2()

	@trans2.setter
	def trans2(self, v):
		self.setTranslation2(v)

	@property
	def t2(self):
		return self.getTranslation2()

	@t2.setter
	def t2(self, v):
		self.setTranslation2(v)

	@property
	def translation(self):
		return self.getTranslation()

	@translation.setter
	def translation(self, v):
		self.setTranslation(v)

	def getTranslation(self):
		return self.getTranslation2()

	def setTranslation(self, v):
		self.setTranslation2(v)

	def getTrans(self):
		return self.getTranslation()

	def setTranslation(self, v):
		self.setTranslation(v)

	@property
	def trans(self):
		return self.getTranslation()

	@trans.setter
	def trans(self, v):
		self.setTranslation(v)

	@property
	def t(self):
		return self.getTranslation()

	@t.setter
	def t(self, v):
		self.setTranslation(v)

	# Matrix functions

	def identify(self):
		self.set(_DEFAULT_MAT3X3)

	def identity(self):
		self.identify()

	@property
	def mat2x3(self):
		return mat2x3(self)

	@property
	def m2x3(self):
		return self.mat2x3

	@property
	def m2(self):
		return self.mat2x3

	@property
	def csm(self):
		return self.mat2x3

	@property
	def cs(self):
		return self.mat2x3

	# Homogeneous

	@property
	def inhomogeneous(self):
		return self.mat2x3

	@property
	def ih(self):
		return self.mat2x3

	#
	# Quaternion @mat3x3
	#
	# numpy.quaternion: (w; x, y, z), (q.w; q.x, q.y, q.z)
	# scipy.quaternion: (x, y, z; w), np.array(q[0], q[1], q[2]; q[3])
	#

	def getNumpyQuaternion(self):
		spq = self.getScipyQuaternion()
		return np.quaternion(spq[3], spq[0], spq[1], spq[2])

	def setNumpyQuaternion(self, q):
		self.setScipyQuaternion(np.array([q.x, q.y, q.z, q.w]))

	@property
	def nquaternion(self):
		return self.getNumpyQuaternion()

	@nquaternion.setter
	def nquaternion(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nquat(self):
		return self.getNumpyQuaternion()

	@nquat.setter
	def nquat(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nq(self):
		return self.getNumpyQuaternion()

	@nq.setter
	def nq(self, q):
		self.setNumpyQuaternion(q)

	def getScipyQuaternion(self):
		return scipyquaternion(self.getScipyRotation().as_quat())

	def setScipyQuaternion(self, q):
		self.setScipyRotation(spr.from_quat(np.array(q)))

	@property
	def scipyquaternion(self):
		return self.getScipyQuaternion()

	@scipyquaternion.setter
	def scipyquaternion(self, q):
		self.setScipyQuaternion(q)

	@property
	def squaternion(self):
		return self.getScipyQuaternion()

	@squaternion.setter
	def squaternion(self, q):
		self.setScipyQuaternion(q)

	@property
	def squat(self):
		return self.getScipyQuaternion()

	@squat.setter
	def squat(self, q):
		self.setScipyQuaternion(q)

	@property
	def sq(self):
		return self.getScipyQuaternion()

	@sq.setter
	def sq(self, q):
		self.setScipyQuaternion(q)

	def getNkjQuaternion(self):
		return nkquaternion(self.getScipyRotation().as_quat())

	def setNkjQuaternion(self, q):
		self.setScipyRotation(spr.from_quat(np.array(q)))

	@property
	def nkjquaternion(self):
		return self.getNkjQuaternion()

	@nkjquaternion.setter
	def nkjquaternion(self, q):
		self.setNkjQuaternion(q)

	@property
	def nkquaternion(self):
		return self.getNkjQuaternion()

	@nkquaternion.setter
	def nkquaternion(self, q):
		self.setNkjQuaternion(q)

	@property
	def nkquat(self):
		return self.getNkjQuaternion()

	@nkquat.setter
	def nkquat(self, q):
		self.setNkjQuaternion(q)

	@property
	def nkq(self):
		return self.getNkjQuaternion()

	@nkq.setter
	def nkq(self, q):
		self.setNkjQuaternion(q)

	def getQuaternion(self):     # あとで、nkj.cs.quaternion クラスに変更すること．
		return self.getNkjQuaternion()

	def setQuaternion(self, q):  # nkj.cs.quaternion クラスは，np.quaternion を継承しているのでそのまま代入できる．
		self.setNkjQuaternion(q)

	@property
	def quaternion(self):
		return self.getQuaternion()

	@quaternion.setter
	def quaternion(self, q):
		self.setQuaternion(q)

	@property
	def quat(self):
		return self.getQuaternion()

	@quat.setter
	def quat(self, q):
		self.setQuaternion(q)

	@property
	def q(self):
		return self.getQuaternion()

	@q.setter
	def q(self, _q):
		self.setQuaternion(_q)

	# Other rotation functions

	def getScipyRotation(self):
		return spr.from_matrix(self.array)

	def setScipyRotation(self, r):
		_n.ldprint('--> nkj.cs.mat3x3.setScipyRotation()')
		_n.ldprint('r: {0} ({1})'.format(r, type(r)))
		if (not isinstance(r, scipy.spatial.transform._rotation.Rotation)):
			_n.print_error('@ERROR: r: {0} ({1})'.format(r, type(r)))
			raise TypeError('__ERROR__: Illegal data type.')
		self.set(r.as_matrix())
		_n.ldprint('<-- nkj.cs.mat3x3.setScipyRotation()')

	@property
	def rotation(self):
		return self.getScipyRotation()

	@rotation.setter
	def rotation(self, r):
		self.setScipyRotation(r)

	@property
	def rot(self):
		return self.rotation

	@rot.setter
	def rot(self, r):
		self.rotation = r

	@property
	def r(self):
		return self.rotation

	@r.setter
	def r(self, _r):
		self.rotation = _r

	def getRotationAxisAndAngle(self):
		rv = self.getScipyRotationVector()
		angle = rv.norm
		rv /= angle
		return rv, angle

	@property
	def rotaxisangle(self):
		return self.getRotationAxisAndAngle()

	@property
	def raxisangle(self):
		return self.getRotationAxisAndAngle()

	@property
	def raxisang(self):
		return self.getRotationAxisAndAngle()

	@property
	def rotaxis(self):
		axis, angle = self.getRotationAxisAndAngle()
		return axis

	@property
	def raxis(self):
		return self.rotaxis

	@property
	def rotangle(self):
		axis, angle = self.getRotationAxisAndAngle()
		return angle

	@property
	def rangle(self):
		return self.rotangle

	@property
	def rang(self):
		return self.rotangle

	def getScipyRotationVector(self):
		return vec3(self.rotation.as_rotvec())

	def setScipyRotationVector(self, v):
		self.setScipyRotation(spr.from_rotvec(np.array(v)))

	@property
	def scipyrotationvector(self):
		return self.getRotationVector()

	@scipyrotationvector.setter
	def scipyrotationvector(self, v):
		self.setRotationVector(v)

	@property
	def sprotationvector(self):
		return self.getRotationVector()

	@sprotationvector.setter
	def sprotationvector(self, v):
		self.setRotationVector(v)

	@property
	def sprotvec(self):
		return self.getRotationVector()

	@sprotvec.setter
	def sprotvec(self, v):
		self.setRotationVector(v)

	@property
	def sprvec(self):
		return self.getRotationVector()

	@sprvec.setter
	def sprvec(self, v):
		self.setRotationVector(v)

	@property
	def sprv(self):
		return self.getRotationVector()

	@sprv.setter
	def sprv(self, v):
		self.setRotationVector(v)

	def getRotationVector(self):
		return self.getScipyRotationVector()

	def setRotationVector(self, v):
		self.setScipyRotationVector(v)

	@property
	def rotationvector(self):
		return self.getRotationVector()

	@rotationvector.setter
	def rotationvector(self, v):
		self.setRotationVector(v)

	@property
	def rotvec(self):
		return self.getRotationVector()

	@rotvec.setter
	def rotvec(self, v):
		self.setRotationVector(v)

	@property
	def rvec(self):
		return self.getRotationVector()

	@rvec.setter
	def rvec(self, v):
		self.setRotationVector(v)

	@property
	def rv(self):
		return self.getRotationVector()

	@rv.setter
	def rv(self, v):
		self.setRotationVector(v)

	def getScipyEulerAngles(self, flag):
		return self.rotation.as_euler(flag)

	def setScipyEulerAngles(self, flag, e):
		self.setScipyRotation(spr.from_euler(flag, np.array(e)))

	def getScipyEuler(self, flag):
		return self.getScipyEulerAngles(flag)

	def setScipyEuler(self, flag, e):
		self.setScipyEulerAngles(flag, e)

	def eulerangles(self, flag, e=None):
		if (e is None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, e)

	def euler(self, flag, e=None):
		if (e is None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, e)

	def euler(self, flag, e=None):
		if (e is  None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, e)

	def e(self, flag, _e=None):
		if (_e is None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, _e)

	# Orthonormalization

	def orthonormalize(self):
		_n.ldprint('--> nkj.mat3x3.orthonormalize()')
		q = self.getNumpyQuaternion()  # 一旦、quaternion に変換すると、正規直交化される
		if (nd.LIB_DEBUG):
			q.print('Scipy Quaternion')
		self.setNumpyQuaternion(q)
		_n.ldprint('<-- nkj.mat3x3.orthonormalize()')

	def OrthoNormalize(self):
		self.orthonormalize()

	def Orthonormalize(self):
		self.orthonormalize()

	def getOrthoNormalized(self):
		m = copy.deepcopy(self)
		m.orthonormalize()
		return m

	def OrthoNormalized(self):
		return self.getOrthoNormalized()

	def Orthonormalized(self):
		return self.getOrthoNormalized()

	@property
	def orthonormalized(self):
		return self.getOrthoNormalized()

	# Rotation

	def rotatelocal(self, x):
		_n.ldprint("--> nkj.cs.mat3x3.rotatelocal()")
		if (self.isinstance(x)):
			rm = x
		elif (isinstance(x, scipy.spatial.transform._rotation.Rotation)):
			rm = mat3x3(x.as_matrix())
		elif (isinstance(x, np.quaternion)):
			rm = mat3x3(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			rm = mat3x3(x)
		else:
			_n.ldprint("class name: {}".format(x.__class__.__name__))
			raise TypeError("__ERROR__: Illegal data type")
		if (nd.LIB_DEBUG2):
			self.print("self (original)")
		m = self @ rm
		self.set(m)
		if (nd.LIB_DEBUG2):
			self.print("self (rotated)")
		_n.ldprint("<-- nkj.cs.mat3x3.rotatelocal()")

	def rotatedlocal(self, x):
		m = copy.deepcopy(self)
		m.rotatelocal(x)
		return m

	def rotateglobal(self, x):
		_n.ldprint("--> nkj.cs.mat3x3.rotateglobal()")
		"""
		if (self.isinstance(x)):
			rm = x
		elif (isinstance(x, scipy.spatial.transform._rotation.Rotation)):
			rm = mat3x3(x)
		elif (isinstance(x, np.quaternion)):
			q = nkquaternion()
			q.setNumpyQuaternion(x)
			rm = q.getMat3x3()
		elif (isinstance(x, (list, tuple))):
			rm = mat3x3(x)
		elif (isinstance(x, np.ndarray)):
			rm = mat3x3(x)
		else:
			raise TypeError("__ERROR__: Illegal data type")
		"""
		rm = mat3x3(x)
		m = rm @ self
		self.set(m)
		_n.ldprint("<-- nkj.cs.mat3x3.rotateglobal()")

	def rotatedglobal(senf, x):
		m = copy.deepcopy(self)
		m.rotateglobal(x)
		return m

	def rotate(self, x):
		return self.rotateglobal(x)

	def rotated(self, x):
		return self.rotatedglobal(x)

	def rotatexlocal(self, x):
		self.rotatelocal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotateylocal(self, x):
		self.rotatelocal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatezlocal(self, x):
		self.rotatelocal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatedxlocal(self, x):
		return self.rotatedlocal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotatedylocal(self, x):
		return self.rotatedlocal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatedzlocal(self, x):
		return self.rotatedlocal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatexglobal(self, x):
		self.rotateglobal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotateyglobal(self, x):
		self.rotateglobal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatezglobal(self, x):
		self.rotateglobal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatedxglobal(self, x):
		return self.rotatedglobal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotatedyglobal(self, x):
		return self.rotatedglobal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatedzglobal(self, x):
		return self.rotatedglobal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatex(self, x):
		self.rotatexglobal(x)

	def rotatey(self, x):
		self.rotateyglobal(x)

	def rotatez(self, x):
		self.rotatezglobal(x)

	def rotatedx(self, x):
		return self.rotatedxglobal(x)

	def rotatedy(self, x):
		return self.rotatedyglobal(x)

	def rotatedz(self, x):
		return self.rotatedzglobal(x)

	# isinstance

	def isinstance(self, x):
		return is_mat3x3(x)

class mat3x3(mat3x3_cls):
	pass

class m3x3(mat3x3_cls):
	pass

class rotmat3(mat3x3_cls):
	pass

class rmat3(mat3x3_cls):
	pass

class rcsm3(mat3x3_cls):
	pass

class rcs3(mat3x3_cls):
	pass

class mat2h(mat3x3_cls):
	pass

class m2h(mat3x3_cls):
	pass

class csm2h(mat3x3_cls):
	pass

class cs2h(mat3x3_cls):
	pass

def is_mat3x3(x):
	_n.ldprint("--> nkj.cs.is_mat3x3()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs.is_mat3x3()")
	return isinstance(x, mat3x3_cls)

def is_rotmat3(x):
	return is_mat3x3(x)

def is_rmat3(x):
	return is_mat3x3(x)

def is_rcsm3(x):
	return is_mat3x3(x)

def is_rcs3(x):
	return is_mat3x3(x)

def is_mat2h(x):
	return is_mat3x3(x)

def is_m2h(x):
	return is_mat3x3(x)

def is_csm2h(x):
	return is_mat3x3(x)

def is_cs2h(x):
	return is_mat3x3(x)


class mat4x4_cls(mat_cls):
	_classname = 'nkj.cs.mat4x4'

	def __new__(cls, m=None):
		self = super().__new__(cls, shape=(4, 4), dtype='float32')
		self.set(_DEFAULT_MAT4X4 if (m is None) else m)
		return self

	def __init__(self, m=None):
		super().__init__()
		self.set(_DEFAULT_MAT4X4 if (m is None) else m)

	@classmethod
	def getClassName(cls):
		return cls._classname

	def __matmul__(self, second):
		if (self.isinstance(second)):
			return mat4x4(self.array @ second.array)
		elif (is_mat3x4(second)):
			return mat4x4(self.array @ second.h.array)
		elif (is_vec3(second)):
			return vec3h(self.array @ second.h.array).ih
		elif (is_vec3h(second)):
			return vec3h(self.array @ second.array)
		elif (is_vec4(second)):
			return vec4(self.array @ second.array)
		elif (second is None):
			raise TypeError("__ERROR__: Illegal data type")
		else:
			return second.__rmatmul__(self)

	def __rmatmul__(self, a):
		raise Exception("__ERROR__: Not implemented")

	def set(self, x):
		_n.ldprint("--> nkj.cs.mat4x4.set()")
		_n.ldprint("x: {}".format(x))
		_n.ldprint2("class name: {}".format(_n.classname(x)))
		if (x is None):
			super().set(_DEFAULT_MAT4X4)
		elif (self.isinstance(x)):  # mat4x4
			super().set(x)
		elif (is_mat3x4(x)):
			for j in range(3):
				for i in range(4):
					self[j, i] = x[j, i]
			for i in range(4):
				self[3, i] = 1.0 if (i == 3) else 0.0
		elif (isinstance(x, (list, tuple, np.ndarray))):
			if (nd.LIB_DEBUG0):
				ndim = np.array(x).ndim
				if (ndim != 2):
					raise TypeError('__ERROR__: Incorrect data shape.')
				rows, columns = np.array(x).shape
				if (rows != 4 or columns != 4):
					raise TypeError('__ERROR__: Incorrect data shape.')
			super().set(x)
		else:
			raise TypeError('__ERROR__: Incorrect data shape.')
		_n.ldprint("<-- nkj.cs.mat4x4.set()")

	def getRow(self, index):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02169.")
		return vec4([self[index][0], self[index][1], self[index][2], self[index][3]])

	def setRow(self, index, v):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02506.")
		if (is_vec4(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 4):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec4(v)
		for i in range(4):
			self[index][i] = v.component(i)

	def getColumn(self, index):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02178.")
		return vec4([self[0][index], self[1][index], self[2][index], self[3][index]])

	def setColumn(self, index, v):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02506.")
		if (is_vec4(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 4):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec4(v)
		for i in range(4):
			self[i][index] = v.component(i)

	def row(self, index, v=None):
		if (v is None):
			return self.getRow(index)
		else:
			self.setRow(index, v)

	def column(self, index, v=None):
		if (v is None):
			return self.getColumn(index)
		else:
			self.setColumn(index, v)

	def getRow3(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02169.")
		return vec3([self[index][0], self[index][1], self[index][2]])

	def setRow3(self, index, v):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02506.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec3(v)
		for i in range(3):
			self[index][i] = v.component(i)

	def getColumn3(self, index):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02178.")
		return vec3([self[0][index], self[1][index], self[2][index]])

	def setColumn3(self, index, v):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02413.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02513.")
			v = vec3(v)
		for i in range(3):
			self[i][index] = v.component(i)

	def row3(self, index, v=None):
		if (v is None):
			return self.getRow3(index)
		else:
			self.setRow3(index, v)

	def column3(self, index, v=None):
		if (v is None):
			return self.getColumn3(index)
		else:
			self.setColumn3(index, v)

	def getXaxis(self):
		return self.getColumn3(0)

	def setXaxis(self, v):
		self.setColumn3(0, v)

	def getYaxis(self):
		return self.getColumn3(1)

	def setYaxis(self, v):
		self.setColumn3(1, v)

	def getZaxis(self):
		return self.getColumn3(2)

	def setZaxis(self, v):
		self.setColumn3(2, v)

	@property
	def xaxis(self):
		return self.getXaxis()

	@xaxis.setter
	def xaxis(self, v):
		self.setXaxis(v)

	@property
	def yaxis(self):
		return self.getYaxis()

	@yaxis.setter
	def yaxis(self, v):
		self.setYaxis(v)

	@property
	def zaxis(self):
		return self.getZaxis()

	@zaxis.setter
	def zaxis(self, v):
		self.setZaxis(v)

	def getTranslation(self):
		return self.getColumn3(3)

	def setTranslation(self, v):
		self.setColumn3(3, v)

	def getTrans(self):
		return self.getTranslation()

	def setTrans(self, v):
		self.setTranslation(v)

	@property
	def translation(self):
		return self.getTranslation()

	@translation.setter
	def translation(self, v):
		self.setTranslation(v)

	@property
	def trans(self):
		return self.getTranslation()

	@trans.setter
	def trans(self, v):
		self.setTranslation(v)

	@property
	def t(self):
		return self.getTranslation()

	@t.setter
	def t(self, v):
		self.setTranslation(v)

	def getOrigin(self):
		return self.getTranslation()

	def setOrigin(self, v):
		self.setTranslation(v)

	def getOrig(self):
		return self.getOrigin()

	def setOrig(self, v):
		self.setOrigin(v)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, v):
		self.setOrigin(v)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, v):
		self.setOrigin(v)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, v):
		self.setOrigin(v)

	# Matrix functions

	def identify(self):
		self.set(_DEFAULT_MAT4X4)

	def identity(self):
		self.identify()

	@property
	def mat3x4(self):
		return mat3x4(self)

	@property
	def m3x4(self):
		return self.mat3x4

	@property
	def mat3(self):
		return self.mat3x4

	@property
	def m3(self):
		return self.mat3x4

	@property
	def csm(self):
		return self.mat3x4

	@property
	def cs(self):
		return self.mat3x4

	# Homogeneous

	@property
	def inhomogeneous(self):
		return self.mat3x4

	@property
	def ih(self):
		return self.mat3x4

	# isinstance

	def isinstance(self, x):
		return is_mat4x4(x)

class mat4x4(mat4x4_cls):
	pass

class m4x4(mat4x4_cls):
	pass

class mat3h(mat4x4_cls):
	pass

class m3h(mat4x4_cls):
	pass

class csm3h(mat4x4_cls):
	pass

class cs3h(mat4x4_cls):
	pass

def is_mat4x4(x):
	_n.ldprint("--> nkj.cs.is_mat4x4()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs.is_mat4x4()")
	return isinstance(x, mat4x4_cls)

def is_m4x4(x):
	return is_mat4x4(x)

def is_mat3h(x):
	return is_mat4x4(x)

def is_m3h(x):
	return is_mat4x4(x)

def is_csm3h(x):
	return is_mat4x4(x)

def is_cs3h(x):
	return is_mat4x4(x)


class mat2x3_cls(mat_cls):
	_classname = 'nkj.cs.mat2x3'

	def __new__(cls, m=None):
		self = super().__new__(cls, shape=(2, 3), dtype='float32')
		self.set(_DEFAULT_MAT2X3 if (m is None) else m)
		return self

	def __init__(self, m=None):
		super().__init__()
		self.set(_DEFAULT_MAT2X3 if (m is None) else m)

	@classmethod
	def getClassName(cls):
		return cls._classname

	def __matmul__(self, second):
		if (self.isinstance(second)):
			return mat3x3(self.mat3x3.array @ second.mat3x3.array).mat2x3
		elif (is_vec2(second)):
			return vec2(self.array @ second.h.array)
		elif (is_vec2h(second)):
			return vec2(self.array @ second.array).h
		elif (is_point2list(second)):
			plist = point2list()
			for c in second:
				plist.append(self @ c)
			return plist
		elif (second is None):
			raise TypeError('__ERROR__: Null input.')
		else:
			return second.__rmatmul__(self)

	def __rmatmul__(self, a):
		raise Exception("__ERROR__: Not implemented")

	def set(self, m):
		_n.ldprint("--> nkj.cs.mat2x3.set()")
		if (m is None):
			super().set(_DEFAULT_MAT2X3)
		elif (is_mat3x3(m)):
			for j in range(2):
				for i in range(3):
					self[j, i] = m[j, i]
		else:
			super().set(m)
		_n.ldprint("<-- nkj.cs.mat2x3.set()")

	def getRow2(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02307.")
		return vec2([self[index][0], self[index][1]])

	def setRow2(self, index, v):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02574.")
		if (is_vec2(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 2):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02579.")
			v = vec2(v)
		for i in range(2):
			self[index][i] = v.component(i)

	def getColumn2(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02313.")
		return vec2([self[0][index], self[1][index]])

	def setColumn2(self, index, v):
		_n.ldprint('--> nkj.cs.mat2x3.setColumn2()')
		_n.ldprint2('index: {}'.format(index))
		_n.ldprint2('v:     {0} ({1})'.format(v, type(v)))
		if (not _nm.is_inrange(index, 0, 2)):
			_n.print_error('index: {}'.format(index))
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02506.")
		if (is_vec2(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 2):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02596.")
			v = vec2(v)
		for i in range(2):
			self[i][index] = v.component(i)
		_n.ldprint('<-- nkj.cs.mat2x3.setColumn2()')

	def row2(self, index, v=None):
		if (v is None):
			return self.getRow2(index)
		else:
			self.setRow2(index, v)

	def column2(self, index, v=None):
		if (v is None):
			return self.getColumn2(index)
		else:
			self.setColumn2(index, v)

	def getRow3(self, index):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-03287.")
		return vec3([self[index][0], self[index][1], self[index][2]])

	def setRow3(self, index, v):
		if (not _nm.is_inrange(index, 0, 1)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02574.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02579.")
			v = vec3(v)
		for i in range(3):
			self[index][i] = v.component(i)

	def row3(self, index, v=None):
		if (v is None):
			return self.getRow3(index)
		else:
			self.setRow3(index, v)

	def getRow(self, index):
		return self.getRow3(index)

	def setRow(self, index, v):
		self.setRow3(index, v)

	def getColumn(self, index):
		return self.getColumn2(index)

	def setColumn(self, index, v):
		self.setColumn2(index, v)

	def row(self, index, v=None):
		if (v is None):
			return self.getRow(index)
		else:
			self.setRow(index, v)

	def column(self, index, v=None):
		if (v is None):
			return self.getColumn(index)
		else:
			self.setColumn(index, v)

	def getXaxis2(self):
		return self.getColumn2(0)

	def setXaxis2(self, v):
		self.setColumn2(0, v)

	def getYaxis2(self):
		return self.getColumn2(1)

	def setYaxis2(self, v):
		self.setColumn2(1, v)

	def getZaxis2(self):
		return self.getColumn2(2)

	def setZaxis2(self, v):
		self.setColumn2(2, v)

	def getXaxis(self):
		return self.getColumn2(0)

	def setXaxis(self, v):
		self.setColumn2(0, v)

	def getYaxis(self):
		return self.getColumn2(1)

	def setYaxis(self, v):
		self.setColumn2(1, v)

	def getTranslation(self):
		return self.getColumn2(2)

	def setTranslation(self, v):
		self.setColumn2(2, v)

	def getTrans(self):
		return self.getTranslation()

	def setTrans(self, v):
		self.setTranslation(v)

	def getOrigin(self):
		return self.getTranslation()

	def setOrigin(self, v):
		self.setTranslation(v)

	def getOrig(self):
		return self.getOrigin()

	def setOrig(self, v):
		self.setOrigin(v)

	@property
	def xaxis(self):
		return self.getXaxis()

	@xaxis.setter
	def xaxis(self, v):
		self.setXaxis(v)

	@property
	def yaxis(self):
		return self.getYaxis()

	@yaxis.setter
	def yaxis(self, v):
		self.setYaxis(v)

	@property
	def zaxis(self):
		return self.getZaxis()

	@zaxis.setter
	def zaxis(self, v):
		self.setZaxis(v)

	@property
	def translation(self):
		return self.getTranslation()

	@translation.setter
	def translation(self, v):
		self.setTranslation(v)

	@property
	def trans(self):
		return self.getTranslation()

	@trans.setter
	def trans(self, v):
		self.setTranslation(v)

	@property
	def t(self):
		return self.getTranslation()

	@t.setter
	def t(self, v):
		self.setTranslation(v)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, v):
		self.setOrigin(v)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, v):
		self.setOrigin(v)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, v):
		self.setOrigin(v)

	def identity(self):
		return self.set(_DEFAULT_MAT2X3)

	def identify(self):
		return self.identity()

	@property
	def mat3x3(self):
		return mat3x3(self)

	@property
	def m3x3(self):
		return self.mat3x3

	@property
	def m3(self):
		return self.mat3x3

	@property
	def square(self):
		return self.mat3x3

	@property
	def sq(self):
		return self.mat3x3

	# Homogeneous

	@property
	def homogeneous(self):
		return self.mat3x3

	@property
	def h(self):
		return self.mat3x3

	def getRotationalMatrix(self):
		_n.ldprint("--> nkj.cs.mat2x3.getRotationalMatrix()")
		m = mat2x2()
		for j in range(2):
			for i in range(2):
				m[j, i] = self[j, i]
		_n.ldprint("<-- nkj.cs.mat2x3.getRotationalMatrix()")
		return m

	def setRotationalMatrix(self, m):
		_n.ldprint("--> nkj.cs.mat2x3.setRotationalMatrix()")
		for j in range(2):
			for i in range(2):
				self[j, i] = m[j, i]
		_n.ldprint("<-- nkj.cs.mat2x3.setRotationalMatrix()")

	@property
	def rotmat(self):
		return self.getRotationalMatrix()

	@rotmat.setter
	def rotmat(self, m):
		self.setRotationalMatrix(m)

	@property
	def rmat(self):
		return self.getRotationalMatrix()

	@rmat.setter
	def rmat(self, m):
		self.setRotationalMatrix(m)

	@property
	def rm(self):
		return self.getRotationalMatrix()

	@rm.setter
	def rm(self, m):
		self.setRotationalMatrix(m)

	@property
	def rotation(self):
		return self.getRotationalMatrix()

	@rotation.setter
	def rotation(self, m):
		self.setRotationalMatrix(m)

	@property
	def rot(self):
		return self.getRotationalMatrix()

	@rot.setter
	def rot(self, m):
		self.setRotationalMatrix(m)

	@property
	def r(self):
		return self.getRotationalMatrix()

	@r.setter
	def r(self, m):
		self.setRotationalMatrix(m)

	def getTranslationalVector(self):
		return vec2([self[0, 2], self[1, 2]])

	def setTranslationalVector(self, v):
		v = vec2(v)
		for i in range(2):
			self[i, 2] = v[i]

	@property
	def transvec(self):
		return self.getTranslationalVector()

	@transvec.setter
	def transvec(self, v):
		self.setTranslationalVector(v)

	@property
	def tvec(self):
		return self.getTranslationalVector()

	@tvec.setter
	def tvec(self, v):
		self.setTranslationalVector(v)

	@property
	def tv(self):
		return self.getTranslationalVector()

	@tv.setter
	def tv(self, v):
		self.setTranslationalVector(v)

	@property
	def translation(self):
		return self.getTranslationalVector()

	@translation.setter
	def translation(self, v):
		self.setTranslationalVector(v)

	@property
	def trans(self):
		return self.getTranslationalVector()

	@trans.setter
	def trans(self, v):
		self.setTranslationalVector(v)

	@property
	def t(self):
		return self.getTranslationalVector()

	@t.setter
	def t(self, v):
		self.setTranslationalVector(v)

	def getInversed(self):
		return mat3x3(np.linalg.inv(self.h)).ih

	@property
	def inversed(self):
		return self.getInversed()

	@property
	def inv(self):
		return self.inversed

	@property
	def i(self):
		return self.inversed

	def inverse(self):
		self.set(self.getInversed())

	# Orthonormalization

	# Rotation

	def rotatelocal(self, ang, offsetm=None):
		_n.ldprint("--> nkj.cs.mat2x3.rotatelocal({:.3f} deg)".format(_nm.rad2deg(ang)))
		#
		# m = localm * offsetm * rotm * !offsetm
		#
		m = self if (offsetm is None) else self @ mat2x3(offsetm)
		rm = m.getRotationalMatrix()
		rm.rotatelocal(ang)
		m.setRotationalMatrix(rm)
		if (offsetm is not None):
			m = m @ mat2x3(offsetm).i
		self.set(m)
		_n.ldprint("<-- nkj.cs.mat2x3.rotatelocal()")

	def localrotate(self, ang, offsetm=None):
		self.rotatelocal(ang, offsetm)

	def rotatedlocal(self, ang, offsetm=None):
		m = copy.deepcopy(self)
		m.rotatelocal(ang, offsetm)
		return m

	def localrorated(self, ang, offsetm=None):
		return self.rotatedlocal(ang, offsetm)

	def rotateglobal(self, ang, offsetm=None):
		#
		# m = offsetm * rotm * !offsetm * localm
		#
		m = self if (offsetm is None) else mat2x3(offsetm).i @ self
		rm = m.getRotationalMatrix()
		rm.rotateglobal(ang)
		m.setRotationalMatrix(rm)
		if (offsetm is not None):
			m = mat2x3(offsetm) @ m
		self.set(m)

	def globalrotate(self, ang, offsetm=None):
		self.rotateglobal(ang, offsetm)

	def rotatedglobal(self, ang, offsetm=None):
		m = copy.deepcopy(self)
		m.rotateglobal(ang, offsetm)
		return m

	def globalrotated(self, ang, offsetm=None):
		return self.rotatedglobal(ang, offsetm)

	def rotate(self, ang, offsetm=None):
		self.rotateglobal(ang, offsetm)

	def translateglobal(self, v):
		t = self.getTranslationalVector()
		for i in range(2):
			t[i] += v[i]
		self.setTranslationalVector(t)

	def globaltranslate(self, v):
		self.translateglobal(v)

	def translate(self, v):
		self.translateglobal(v)

	def translatedglobal(self, v):
		m = copy.deepcopy(self)
		m.translateglobal(v)
		return m

	def globaltranslated(self, v):
		return self.translatedglobal(v)

	def translated(self, v):
		return self.translatedglobal(v)

	# Functions

	def getHexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Hexagon vertecies
		_n.ldprint('--> nkj.cs.mat2x3.getHexagonVerts(, radius:{}'.format(radius))
		plist = self @ vec2().getHexagonVerts(radius)
		if (nd.LIB_DEBUG2):
			print('plist: {0} ({1})'.format(plist, type(plist)))
		_n.ldprint('<-- nkj.cs.mat2x3.getHexagonVerts()')
		return plist

	def HexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getHexiagonVerts(radius)

	@property
	def hexagonverts(self):
		return self.getHexagonVerts()

	def getOriginAndHexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Origin and hexagon vertecies
		plist = point2list()
		plist.append([0.0, 0.0])
		plist.append(self.getHexagonVerts(radius))
		return plist

	def OriginAndHexagonVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getOriginAndHexagonVerts(radius)

	@property
	def origin_and_hexagonverts(self):
		return self.getHexagonVerts()

	# isinstance

	def isinstance(self, x):
		return is_mat2x3(x)

class mat2x3(mat2x3_cls):
	pass

class m2x3(mat2x3_cls):
	pass

class mat2(mat2x3_cls):
	pass

class m2(mat2x3_cls):
	pass

class csm2(mat2x3_cls):
	pass

class cs2(mat2x3_cls):
	pass

def is_mat2x3(x):
	_n.ldprint("--> nkj.cs.is_mat2x3()")
	_n.ldprint2("class name: {}".format(x.__class__.__name__))
	_n.ldprint("<-- nkj.cs.is_mat2x3()")
	return isinstance(x, mat2x3_cls)

def is_mat2(x):
	return is_mat2x3(x)

def is_m2(x):
	return is_mat2x3(x)

def is_csm2(x):
	return is_mat2x3(x)

def is_csm2(x):
	return is_mat2x3(x)

def is_cs2(x):
	return is_mat2x3(x)


class mat3x4_cls(mat_cls):
	_classname = 'nkj.cs.mat3x4'

	def __new__(cls, m=None):
		self = super().__new__(cls, shape=(3, 4), dtype='float32')
		return self

	def __init__(self, m=None):
		super().__init__()
		self.set(_DEFAULT_MAT3X4 if (m is None) else m)

	@classmethod
	def getClassName(cls):
		return cls._classname

	def __matmul__(self, second):
		if (second is None):
			raise TypeError("__ERROR__: Null data.")
		if (self.isinstance(second)):
			return mat4x4(self.mat4x4.array @ second.mat4x4.array).mat3x4
		elif (is_mat4x4(second)):
			return mat4x4(self.mat4x4.array @ second.array).mat3x4
		elif (is_mat3x3(second)):
			return mat4x4(self.mat4x4.array @ second.mat4x4.array).mat3x4
		elif (isinstance(second, spr)):
			m = mat3x4()
			m.setScipyRotation(second)
			return mat4x4(self.mat4x4.array @ m.mat4x4.array).mat3x4
		elif (isinstance(second, np.quaternion)):
			m = mat3x4()
			m.setNumpyQuaternion(second)
			return mat4x4(self.mat4x4.array @ m.mat4x4.array).mat3x4
		elif (is_vec3(second)):
			return vec3(self.array @ second.h.array)
		elif (is_vec3h(second)):
			return vec3(self.array @ second.array).h
		else:
			return second.__rmatmul__(self)

	def __rmatmul__(self, first):
		if (isinstance(first, spr)):
			m = mat3x4()
			m.setScipyRotation(first)
			return mat4x4(m.mat4x4.array @ self.mat4x4.array).mat3x4
		else:
			return first.__matmul__(self)

	def __lshift__(self, second):  # 'self.mat3x4 << x' operator
		return self.project(second)

	def __rrshift__(self, first):  # 'x >> self.mat3x4' operator
		return self.project(first)

	# Get / Set

	def set(self, m):
		_n.ldprint('--> nkj.cs.mat3x4.set()')
		if (m is None):
			raise Exception('__ERROR__: Null input.')
		if (self.isinstance(m) or is_mat4x4(m)):
			_n.ldprint('@-- mat3x4 / mat4x4')
			_n.ldprint('self: {0} ({1})'.format(self, type(self)))
			_n.ldprint('m:    {0} ({1})'.format(m, type(m)))
			for j in range(3):
				for i in range(4):
					self[j][i] = m[j][i]
		elif (isinstance(m, (list, tuple, np.ndarray))):
			_n.ldprint('@-- list / tuple / np.array')
			s_rows, s_columns = self.dimensions
			m_rows, m_columns = np.array(m).shape
			_n.ldprint('m: {0} ({1})'.format(m, type(m)))
			_n.ldprint('self.dim: {0}, {1}'.format(s_rows, s_columns))
			_n.ldprint('m.dim:    {0}, {1}'.format(m_rows, m_columns))
			_n.ldprint('self.shape: {}'.format(self.shape))
			_n.ldprint('m.shape   : {}'.format(np.array(m).shape))
			if (nd.LIB_DEBUG3):
				if (s_rows != 3 or s_columns != 4):
					raise Exception('__ERROR__: Illegal structure of self')
			if (m_rows == 3 and m_columns == 4):
				for j in range(3):
					for i in range(4):
						self[j][i] = m[j][i]
			else:
				_n.print_error('@ERROR: m.dim: {0}, {1}'.format(m_rows, m_columns))
				raise TypeError('__ERROR__: Illegal data type.')
		elif (isinstance(m, spr)):
			self.setScipyRotation(m)
			self.setTranslation([0.0, 0.0, 0.0])
		elif (isinstance(second, np.quaternion)):
			self.setNumpyQuaternion(second)
			self.setTranslation([0.0, 0.0, 0.0])
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint('<-- nkj.cs.mat3x4.set()')

	def getRow3(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02680.")
		return vec3([self[index][0], self[index][1], self[index][2]])

	def setRow3(self, index, v):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02850.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02979.")
			v = vec3(v)
		for i in range(3):
			self[index][i] = v.component(i)

	def getColumn3(self, index):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02689.")
		return vec3([self[0][index], self[1][index], self[2][index]])

	def setColumn3(self, index, v):
		if (not _nm.is_inrange(index, 0, 3)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02982.")
		if (is_vec3(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 3):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02992.")
			v = vec3(v)
		for i in range(3):
			self[i][index] = v.component(i)

	def row3(self, index, v=None):
		if (v is None):
			return self.getRow3(index)
		else:
			self.setRow3(index, v)

	def column3(self, index, v=None):
		if (v is None):
			return self.getColumn3(index)
		else:
			self.setColumn3(index, v)

	def getRow4(self, index):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02680.")
		return vec4([self[index][0], self[index][1], self[index][2], self[index][3]])

	def setRow4(self, index, v):
		if (not _nm.is_inrange(index, 0, 2)):
			raise Exception("__ERROR__: Illegal index. NKJ-CS-02850.")
		if (is_vec4(v)):
			pass
		elif (isinstance(v, (list, tuple, np.ndarray))):
			if (len(v) != 4):
				raise Exception("__ERROR__: Illegal data. NKJ-CS-02979.")
			v = vec4(v)
		for i in range(4):
			self[index][i] = v.component(i)

	def row4(self, index, v=None):
		if (v is None):
			return self.getRow4(index)
		else:
			self.setRow4(index, v)

	def getRow(self, index):
		return self.getRow4(index)

	def setRow(self, index, v):
		self.setRow4(index, v)

	def getColumn(self, index):
		return self.getColumn3(index)

	def setColumn(self, index, v):
		self.setColumn3(index, v)

	def row(self, index, v=None):
		if (v is None):
			return self.getRow(index)
		else:
			self.setRow(index, v)

	def column(self, index, v=None):
		if (v is None):
			return self.getColumn(index)
		else:
			self.setColumn(index, v)

	def getXaxis(self):
		return self.getColumn3(0)

	def setXaxis(self, v):
		self.setColumn3(0, v)

	def getYaxis(self):
		return self.getColumn3(1)

	def setYaxis(self, v):
		self.setColumn3(1, v)

	def getZaxis(self):
		return self.getColumn3(2)

	def setZaxis(self, v):
		self.setColumn3(2, v)

	@property
	def xaxis(self):
		return self.getXaxis()

	@xaxis.setter
	def xaxis(self, v):
		self.setXaxis(v)

	@property
	def yaxis(self):
		return self.getYaxis()

	@yaxis.setter
	def yaxis(self, v):
		self.setYaxis(v)

	@property
	def zaxis(self):
		return self.getZaxis()

	@zaxis.setter
	def zaxis(self, v):
		self.setZaxis(v)

	def getTranslation(self):
		return self.getColumn3(3)

	def setTranslation(self, v):
		self.setColumn3(3, v)

	def getTrans(self):
		return self.getTranslation()

	def setTrans(self, v):
		self.setTranslation(v)

	def getOrigin(self):
		return self.getTranslation()

	def setOrigin(self, v):
		self.setTranslation(v)

	def getOrig(self):
		return self.getOrigin()

	def setOrig(self, v):
		self.setOrigin(v)

	@property
	def translation(self):
		return self.getTranslation()

	@translation.setter
	def translation(self, v):
		self.setTranslation(v)

	@property
	def trans(self):
		return self.getTranslation()

	@trans.setter
	def trans(self, v):
		self.setTranslation(v)

	@property
	def t(self):
		return self.getTranslation()

	@t.setter
	def t(self, v):
		self.setTranslation(v)

	@property
	def origin(self):
		return self.getOrigin()

	@origin.setter
	def origin(self, v):
		self.setOrigin(v)

	@property
	def orig(self):
		return self.getOrigin()

	@orig.setter
	def orig(self, v):
		self.setOrigin(v)

	@property
	def o(self):
		return self.getOrigin()

	@o.setter
	def o(self, v):
		self.setOrigin(v)

	def identity(self):
		return self.set(_DEFAULT_MAT3X4)

	@property
	def mat4x4(self):
		return mat4x4(self)

	@property
	def m4x4(self):
		return self.mat4x4

	@property
	def m4(self):
		return self.mat4x4

	@property
	def square(self):
		return self.mat4x4

	@property
	def sq(self):
		return self.mat4x4

	# Homogeneous

	@property
	def homogeneous(self):
		return self.mat4x4

	@property
	def h(self):
		return self.mat4x4

	def getRotationalMatrix(self):
		return mat3x3([[self[0, 0], self[0, 1], self[0, 2]], [self[1, 0], self[1, 1], self[1, 2]], [self[2, 0], self[2, 1], self[2, 2]]])

	def setRotationalMatrix(self, m):
		m = mat3x3(m)
		for j in range(3):
			for i in range(3):
				self[j, i] = m[j, i]

	@property
	def rotmat(self):
		return self.getRotationalMatrix()

	@rotmat.setter
	def rotmat(self, m):
		self.setRotationalMatrix(m)

	@property
	def rmat(self):
		return self.getRotationalMatrix()

	@rmat.setter
	def rmat(self, m):
		self.setRotationalMatrix(m)

	@property
	def rm(self):
		return self.getRotationalMatrix()

	@rm.setter
	def rm(self, m):
		self.setRotationalMatrix(m)

	@property
	def rotation(self):
		return self.getRotationalMatrix()

	@rotation.setter
	def rotation(self, m):
		self.setRotationalMatrix(m)

	@property
	def rot(self):
		return self.getRotationalMatrix()

	@rot.setter
	def rot(self, m):
		self.setRotationalMatrix(m)

	@property
	def r(self):
		return self.getRotationalMatrix()

	@r.setter
	def r(self, m):
		self.setRotationalMatrix(m)

	def getScipyRotation(self):
		return self.getRotationalMatrix().getScipyRotation()

	def setScipyRotation(self, r):
		m = mat3x3()
		m.setScipyRotation(r)
		self.setRotationalMatrix(m)

	@property
	def srotation(self):
		return self.getScipyRotation()

	@srotation.setter
	def srotation(self, r):
		self.setScipyRotation(r)

	@property
	def srot(self):
		return self.rotation

	@srot.setter
	def srot(self, r):
		self.rotation = r

	@property
	def sr(self):
		return self.rotation

	@sr.setter
	def sr(self, _r):
		self.rotation = _r

	def getRotationAxisAndAngle(self):
		return self.getRotationalMatrix().getRotationAxisAndAngle()

	@property
	def rotaxisangle(self):
		return self.getRotationAxisAndAngle()

	@property
	def raxisangle(self):
		return self.getRotationAxisAndAngle()

	@property
	def raxisang(self):
		return self.getRotationAxisAndAngle()

	@property
	def rotaxis(self):
		axis, angle = self.getRotationAxisAndAngle()
		return axis

	@property
	def raxis(self):
		return self.rotaxis

	@property
	def rotangle(self):
		axis, angle = self.getRotationAxisAndAngle()
		return angle

	@property
	def rangle(self):
		return self.rotangle

	@property
	def rang(self):
		return self.rotangle

	def getScipyRotationVector(self):
		return self.getRotationalMatrix().getScipyRotationVector()

	def setScipyRotationVector(self, v):
		m = mat3x3()
		m.setScipyRotationVector(v)
		self.setRotationalMatrix(m)

	@property
	def rotationvector(self):
		return self.getScipyRotationVector()

	@rotationvector.setter
	def rotationvector(self, v):
		self.setScipyRotationVector(v)

	@property
	def rotvec(self):
		return self.getScipyRotationVector()

	@rotvec.setter
	def rotvec(self, v):
		self.rotationvector = v

	@property
	def rvec(self):
		return self.getScipyRotationVector()

	@rvec.setter
	def rvec(self, v):
		self.rotationvector = v

	@property
	def rv(self):
		return self.getScipyRotationVector()

	@rv.setter
	def rv(self, v):
		self.rotationvector = v

	def getScipyEulerAngles(self, flag):
		return self.getRotationalMatrix().getScipyEulerAngles(flag)

	def setScipyEulerAngles(self, flag, e):
		m = mat3x3()
		m.setScipyEulerAngles(flag, e)
		self.setRotationalMatrix(m)

	def getScipyEuler(self, flag):
		return self.getRotationalMatrix().getScipyEuler(flag)

	def setScipyEuler(self, flag, e):
		m = mat3x3()
		m.setScipyEuler(flag, e)
		self.setRotationalMatrix(m)

	def eulerangles(self, flag, e=None):
		if (e is None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, e)

	def euler(self, flag, e=None):
		if (e is None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, e)

	def euler(self, flag, e=None):
		if (e is  None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, e)

	def e(self, flag, _e=None):
		if (_e is None):
			return self.getScipyEulerAngles(flag)
		else:
			self.setScipyEulerAngles(flag, _e)

	# Quaternion @mat3x4

	def getScipyQuaternion(self):
		return self.getRotationalMatrix().getScipyQuaternion()

	def setScipyQuaternion(self, q):
		m = mat3x3()
		m.setScipyQuaternion(q)
		self.setRotationalMatrix(m)

	@property
	def scipyquaternion(self):
		return self.getScipyQuaternion()

	@scipyquaternion.setter
	def scipyquaternion(self, q):
		self.setScipyQuaternion(q)

	@property
	def squaternion(self):
		return self.getScipyQuaternion()

	@squaternion.setter
	def squaternion(self, q):
		self.setScipyQuaternion(q)

	@property
	def squat(self):
		return self.quaternion

	@squat.setter
	def squat(self, q):
		self.quaternion = q

	@property
	def sq(self):
		return self.quaternion

	@sq.setter
	def sq(self, _q):
		self.quaternion = _q

	def getNumpyQuaternion(self):
		return self.getRotationalMatrix().getNumpyQuaternion()

	def setNumpyQuaternion(self, q):
		m = mat3x3()
		m.setNumpyQuaternion(q)
		self.setRotationalMatrix(m)

	@property
	def numpyquaternion(self):
		return self.getNumpyQuaternion()

	@numpyquaternion.setter
	def numpyquaternion(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nquaternion(self):
		return self.getNumpyQuaternion()

	@nquaternion.setter
	def nquaternion(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nquat(self):
		return self.getNumpyQuaternion()

	@nquat.setter
	def nquat(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nq(self):
		return self.getNumpyQuaternion()

	@nq.setter
	def nq(self, q):
		self.setNumpyQuaternion(q)

	def getNkjQuaternion(self):
		return nkquaternion(self.getNumpyQuaternion())

	def setNkjQuaternion(self, q):
		self.setNumpyQuaternion(q)

	def NkjQuaternion(self, q=None):
		if (q is None):
			return self.getNkjQuaternion()
		else:
			self.setNkjQuaternion(q)

	@property
	def nkjquaternion(self):
		return self.getNkjQuaternion()

	@nkjquaternion.setter
	def nkjquaternion(self, q):
		self.setNkjQuaternion(q)

	def getNkQuaternion(self):
		return self.getNkjQuaternion(self)

	def setNkQuaternion(self, q):
		self.setNkjQuaternion(q)

	def NkQuaternion(self, q=None):
		if (q is None):
			return self.getNkjQuaternion()
		else:
			self.setNkjQuaternion(q)

	@property
	def nkquaternion(self):
		return self.getNkjQuaternion()

	@nkquaternion.setter
	def nkquaternion(self, q):
		self.setNkjQuaternion(q)

	@property
	def nkquat(self):
		return self.getNkjQuaternion()

	@nkquat.setter
	def nkquat(self, q):
		self.setNkjQuaternion(q)

	@property
	def nkq(self):
		return self.getNkjQuaternion()

	@nkq.setter
	def nkq(self, q):
		self.setNkjQuaternion(q)

	def getQuaternion(self):     # あとで、nkj.cs.quaternion クラスに変更すること．
		return self.getNkjQuaternion()

	def setQuaternion(self, q):  # nkj.cs.quaternion クラスは，np.quaternion を継承しているのでそのまま代入できる．
		self.setNkjQuaternion(q)

	@property
	def quaternion(self):
		return self.getQuaternion()

	@quaternion.setter
	def quaternion(self, q):
		self.setQuaternion(q)

	@property
	def quat(self):
		return self.getQuaternion()

	@quat.setter
	def quat(self, q):
		self.setQuaternion(q)

	@property
	def q(self):
		return self.getQuaternion()

	@q.setter
	def q(self, _q):
		self.setQuaternion(_q)

	# Translation

	def getTranslationalVector(self):
		return vec3([self[0, 3], self[1, 3], self[2, 3]])

	def setTranslationalVector(self, v):
		_n.ldprint('--> nkj.cs.mat3x4.setTranslationalVector()')
		_n.ldprint('v: {} ({})'.format(v, type(v)))
		v = vec3(v)
		for i in range(3):
			self[i, 3] = v.component(i)
		_n.ldprint('<-- nkj.cs.mat3x4.setTranslationalVector()')

	def getTranslation(self):
		return self.getTranslationalVector()

	def setTranslation(self, v):
		self.setTranslationalVector(v)

	@property
	def transvec(self):
		return self.getTranslationalVector()

	@transvec.setter
	def transvec(self, v):
		self.setTranslationalVector(v)

	@property
	def tvec(self):
		return self.getTranslationalVector()

	@tvec.setter
	def tvec(self, v):
		self.setTranslationalVector(v)

	@property
	def tv(self):
		return self.getTranslationalVector()

	@tv.setter
	def tv(self, v):
		self.setTranslationalVector(v)

	@property
	def translation(self):
		return self.getTranslationalVector()

	@translation.setter
	def translation(self, v):
		self.setTranslationalVector(v)

	@property
	def trans(self):
		return self.getTranslationalVector()

	@trans.setter
	def trans(self, v):
		self.setTranslationalVector(v)

	@property
	def t(self):
		return self.getTranslationalVector()

	@t.setter
	def t(self, v):
		self.setTranslationalVector(v)

	@property
	def origin(self):
		return self.getTranslationalVector()

	@origin.setter
	def origin(self, v):
		self.setTranslationalVector(v)

	@property
	def orig(self):
		return self.getTranslationalVector()

	@orig.setter
	def orig(self, v):
		self.setTranslationalVector(v)

	# Geometric operation

	def getInversed(self):
		return mat4x4(np.linalg.inv(self.h)).ih

	@property
	def inversed(self):
		return self.getInversed()

	@property
	def inv(self):
		return self.inversed

	@property
	def i(self):
		return self.inversed

	def inverse(self):
		self.set(self.getInversed())

	def orthonormalize(self):
		_n.ldprint('--> nkj.mat3x4.orthonormalize()')
		if (False):
			trans = self.getTranslation()
		self.setRotationalMatrix(self.getRotationalMatrix().orthonormalized)
		if (False):
			self.setTranslation(trans)
		if (nd.LIB_DEBUG):
			xaxis = self.getXaxis()
			yaxis = self.getYaxis()
			zaxis = self.getZaxis()
			print('xaxis.norm: {:.6f}'.format(xaxis.norm))
			print('yaxis.norm: {:.6f}'.format(yaxis.norm))
			print('zaxis.norm: {:.6f}'.format(zaxis.norm))
			print('xaxis ^ yaxis: {}'.format(xaxis ^ yaxis))
			print('yaxis ^ zaxis: {}'.format(yaxis ^ zaxis))
			print('zaxis ^ xaxis: {}'.format(zaxis ^ xaxis))
		_n.ldprint('<-- nkj.mat3x4.orthonormalize()')

	def OrthoNormalize(self):
		self.orthonormalize()

	def Orthonormalize(self):
		self.orthonormalize()

	def getOrthoNormalized(self):
		m = copy.deepcopy(self)
		m.orthonormalize()
		return m

	def OrthoNormalized(self):
		return self.getOrthoNormalized()

	def Orthonormalized(self):
		return self.getOrthoNormalized()

	@property
	def orthonormalized(self):
		return self.getOrthoNormalized()

	# Operators

	def multiply(self, second):
		_n.ldprint('--> nkj.cs.mat3x4.multiply() -->')
		_n.ldprint('second: {0} ({1})'.format(second, type(second)))
		if (second is None):
			raise TypeError("__ERROR__: Null data.")
		if (self.isinstance(second)):
			return (self.mat4x4 @ second.mat4x4).mat3x4
		elif (is_mat3x3(second)):
			return (self.mat4x4 @ second.mat4x4).mat3x4
		elif (is_mat4x4(second)):
			return (self.mat4x4 @ second).mat3x4
		elif (is_vec3(second)):
			if (nd.LIB_DEBUG):
				self.print('self')
				second.h.print('second.h')
				print('second.h: {}'.format(second.h))
				vec3(self.a @ second.h.a).print('self @ second.h')
			return vec3(self.a @ second.h.a)
		elif (is_vec3h(second)):
			return vec3(self.a @ second.a).h
		else:
			return second.__rmatmul__(self)

	def rmultiply(self, first):
		_n.ldprint('--> nkj.cs.mat3x4.rmultiply() -->')
		_n.ldprint('first: {0} ({1})'.format(first, type(first)))
		raise Exception("__ERROR__: Not implemented.")

	# Geometrical operations

	def rotatelocal(self, x, offsetm=None):
		_n.ldprint("--> nkj.cs.mat3x4.rotatelocal()")
		#
		# m = localm * offsetm * rotm * !offsetm
		#
		m = self if (offsetm is None) else self @ mat3x4(offsetm)
		rm = m.getRotationalMatrix()
		rm.rotatelocal(x)
		m.setRotationalMatrix(rm)
		if (offsetm is not None):
			m = m @ mat3x4(offsetm)
		self.set(m)
		_n.ldprint("<-- nkj.cs.mat3x4.rotatelocal()")

	def rotateglobal(self, x, offsetm=None):
		_n.ldprint('--> nkj.cs.mat3x4.rotateglobal()')
		#
		# m = offsetm * rotm * !offsetm * localm
		#
		_n.ldprint('x:    {0} ({1})'.format(x, type(x)))
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		if (self.isinstance(x)):
			rm = x
		elif (is_mat3x3(x)):
			rm = mat3x4(x)
		elif (isinstance(x, scipy.spatial.transform._rotation.Rotation)):
			rm = mat3x4(x)
		elif (isinstance(x, np.quaternion)):
			rm = mat3x4(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			rm = mat3x4(x)
		else:
			raise TypeError("__ERROR__: Illegal data type")
		if (nd.LIB_DEBUG2):
			rm.print('rotational matrix')
			self.print('original matrix (self)')
			rm.h.print('rotational matrix (homogeneous)')
			self.h.print('original matrix (homogeneous)')
			(rm.h @ self.h).print('translated (homogeneous)')
			(rm.h @ self.h).ih.print('translated (homogeneous)')
		if (offsetm is None):
			m = (rm.h @ self.h).ih
		else:
			m = (offsetm.h @ rm.h @ offsetm.h.i @ self.h).ih
		self.set(m)
		if (nd.LIB_DEBUG2):
			self.print('self (rotated)')
		_n.ldprint('<-- nkj.cs.mat3x4.rotateglobal()')

	def rotate(self, x):
		self.rotateglobal(x)

	def rotatedlocal(self, x):
		m = copy.deepcopy(self)
		m.rotatelocal(x)
		return m

	def rotatedglobal(self, x):
		m = copy.deepcopy(self)
		m.rotateglobal(x)
		return m

	def rotated(self, x):
		return self.rotatedglobal(x)

	def rotatexlocal(self, x):
		self.rotatelocal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotateylocal(self, x):
		self.rotatelocal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatezlocal(self, x):
		self.rotatelocal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatedxlocal(self, x):
		return self.rotatedlocal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotatedylocal(self, x):
		return self.rotatedlocal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatedzlocal(self, x):
		return self.rotatedlocal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatexglobal(self, x):
		self.rotateglobal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotateyglobal(self, x):
		self.rotateglobal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatezglobal(self, x):
		self.rotateglobal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatedxglobal(self, x):
		return self.rotatedglobal(spr.from_rotvec([x, 0.0, 0.0]))

	def rotatedyglobal(self, x):
		return self.rotatedglobal(spr.from_rotvec([0.0, x, 0.0]))

	def rotatedzglobal(self, x):
		return self.rotatedglobal(spr.from_rotvec([0.0, 0.0, x]))

	def rotatex(self, x):
		self.rotatexglobal(x)

	def rotatey(self, x):
		self.rotateyglobal(x)

	def rotatez(self, x):
		self.rotatezglobal(x)

	def rotatedx(self, x):
		return self.rotatedxglobal(x)

	def rotatedy(self, x):
		return self.rotatedyglobal(x)

	def rotatedz(self, x):
		return self.rotatedzglobal(x)

	def translatelocal(self, v):
		raise Exception('__ERROR__: Not implemented.')

	def translateglobal(self, v):
		_n.ldprint("--> nkj.cs.mat3x4.translate()")
		t = self.getTranslationalVector()
		for i in range(3):
			t[i] = t[i] + v[i]
		self.setTranslationalVector(t)
		_n.ldprint("<-- nkj.cs.mat3x4.translate()")

	def translate(self, v):
		self.translateglobal(v)

	def translatedlocal(self, v):
		raise Exception('__ERROR__: Not implemented.')

	def translatedglobal(self, v):
		m = copy.deepcopy(self)
		m.translateglobal(v)
		return m

	def translated(self, v):
		return self.translatedglobal(v)

	def setByPoints(self, pts):
		_n.ldprint('--> nkj.cs.mat3x4.setByPoints()')
		if (is_point3list(pts)):
			pass
		elif (isinstance(pts, (list, tuple))):
			pts = point3list(pts)
		else:
			raise TypeError("Illegal data type. NKJ-CS-03267.")
		l, p = np.linalg.eigh(pts.cvm)
		_n.ldprint2('Eigen values:  {}'.format(l))
		_n.ldprint2('Eigen vectors: {}'.format(p))
		#l_sort = np.sort(l)
		#_n.ldprint2('Eigen values (sorted):  {}'.format(l_sort))
		l_sort_index = np.argsort(l)
		_n.ldprint2('Eigen value indexes (sorted): {}'.format(l_sort_index))
		xaxis = p[:, l_sort_index[2]]  # i番目の固有値とp[:, i]の固有ベクトルが対応している
		xaxis = _ncs.vec3(xaxis)
		xaxis.normalize()
		_n.ldprint2('Xaxis: {}'.format(xaxis))
		yaxis = p[:, l_sort_index[1]]
		yaxis = _ncs.vec3(yaxis)
		yaxis.normalize()
		_n.ldprint2('Yaxis: {}'.format(yaxis))
		zaxis = p[:, l_sort_index[0]]
		zaxis = _ncs.vec3(zaxis)
		zaxis.normalize()
		_n.ldprint2('Zaxis: {}'.format(zaxis))
		self.setColumn3(0, xaxis)
		self.setColumn3(1, yaxis)
		self.setColumn3(2, zaxis)
		self.setColumn3(3, pts.average)
		if (nd.LIB_DEBUG):
			self.print("mat3x4 (by points)")
		_n.ldprint('<-- nkj.cs.mat3x4.setByPoints()')

	def setFromPoints(self, pts):
		self.setByPoints(pts)

	@property
	def by_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00359.")

	@by_points.setter
	def by_points(self, x):
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (_ncs.is_point3list(x)):
			self.setByPoints(x)
		elif (isinstance(x, (list, tuple, np.array))):
			if (len(x) == 2):
				if ((_ncs.is_point3list(x[0]) or isinstance(x[0], (list, tuple))) and _nm.is_digit(x[1])):
					self.setByPoints(x[0], x[1])
				else:
					raise TypeError('__ERROR__: Illegal data type.')
			else:
				self.setByPoints(x)
		else:
			raise TypeError('__ERROR__: Illegal data type.')

	@property
	def from_points(self):
		raise Exception("__ERROR__: Not implemented. (Dummy property). NKJ-PRIMITIVESHAPE-00379.")

	@from_points.setter
	def from_points(self, x):
		self.by_points = x

	def _project2_4point(self, x):  # Project to the x-y plane in this coordinate system.
		_n.ldprint('--> nkj.cs.mat3x4._project2_4point()')
		_n.ldprint2('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint2('x:    {0} ({1})'.format(x, type(x)))
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (nd.LIB_DEBUG):  # 整形して確認
			self.print('self')
			x.print('x')
		if (_ncs.is_vec3(x)):
			pt3 = x
		elif(isinstance(x, (list, tuple, np.ndarray))):
			pt3 = _ncs.vec3(x)
		else:
			raise Exception('__ERROR__: Not implemented. NKJ-CS-03798.')
		m = self
		if (nd.LIB_DEBUG2):  # 整形して確認
			m.print('m')
			pt3.print('pt3')
		pt3 = m.inv @ pt3
		if (nd.LIB_DEBUG2):  # 整形して確認
			m.inv.print('m.inv')
			pt3.print('pt3')
		pt = _ncs.vec2([pt3.x, pt3.y])
		pt.residue = pt3.z
		if (nd.LIB_DEBUG2):  # 整形して確認
			pt.print('pt ')
			(m @ m.inv).print('inversing operation check (m @ m.inv)')
			print('residue: {}'.format(pt.residue))
		_n.ldprint('<-- nkj.cs.mat3x4._project2_4point(): {0} ({1})'.format(pt.getPrintString(), type(pt)))
		return pt

	def _project2_4vec(self, x):  # Project to the x-y plane in this coordinate system.
		return self._project2_4point(x)

	def _project2_4pointlist(self, x):  # Project to the x-y plane in this coordinate system.
		_n.ldprint('--> nkj.cs.mat3x4._project2_4pointlist()')
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (_ncs.is_point3list(x)):
			pts3 = x
		elif(isinstance(x, (list, tuple, np.ndarray))):
			pts3 = _ncs.point3list(x)
		else:
			raise Exception('__ERROR__: Not implemented. NKJ-CS-03798.')
		if (nd.LIB_DEBUG):
			pts3.print('pts3 (original)')
		m = self
		if (nd.LIB_DEBUG2):
			(m @ m.inv).print('Matrix check')
		pts3_2 = m.inv @ pts3
		if (nd.LIB_DEBUG2):
			pts3_3 = m @ pts3_2
			pts3_3.print('pts3 (check)')
			for i in range(len(pts3)):
				print('check: {}'.format(pts3_3[i] - pts3[i]))
		pts2 = _ncs.point2list()
		for pt3 in pts3_2:
			pt = _ncs.vec2([pt3.x, pt3.y])
			pt.residue = pt3.z
			pts2.append(pt)
		_n.ldprint('<-- nkj.cs.mat3x4._project2_4pointlist()')
		return pts2

	def _project2_4matrix(self, x):  # Project a mat3x4 to the x-y plane in this coordinate system to get a mat2x3.
		_n.ldprint('--> nkj.cs.mat3x4._project2_4matrix()')
		if (not _ncs.is_mat3x4(x)):
			raise TypeError('__ERROR__: Illegal data type.')
		origin3 = x.origin
		xaxis3 = x.xaxis
		yaxis3 = x.yaxis
		zaxis3 = x.zaxis
		if (nd.LIB_DEBUG2):
			origin3.print('origin 3D')
			xaxis3.print('xaxis 3D ')
			yaxis3.print('yaxis 3D ')
		origin2 = self._project2_4point(origin3)
		if (_nm.is_ineps(abs(self.zaxis ^ xaxis3), 1.0)):    # X-axis がほぼ self.zaxis と等しい = xaxis の方向が決められない．
			_n.ldprint2('-- Xaxis is almost parallel for self.zaxis.')
			yaxis2 = self._project2_4vec(yaxis3).normalized  # 以下で，Y-axis を基準に2次元座標系を決める．まず，Y-axis を決める．
			xaxis2 = yaxis2.perpendicular                    # Y-axis を基準に X-axis の方向を決める．
			xaxis2_2 = -self._project2_4vec(zaxis3)          # オリジナルの X-axis は local Z-axis 方向に縮退しているので，Z-axis の逆方向を X-axis と決める．
			if (xaxis2 ^ xaxis2_2 < 0.0):
				xaxis2 = -xaxis2
		elif (_nm.is_ineps(abs(self.zaxis ^ yaxis3), 1.0)):    # Y-axis がほぼ self.zaxis と等しい = yaxis の方向が決められない．
			_n.ldprint2('-- Yaxis is almost parallel for self.zaxis.')
			xaxis2 = self._project2_4vec(xaxis3).normalized
			yaxis2 = xaxis2.perpendicular
			yaxis2_2 = -self._project2_4vec(zaxis3)          # オリジナルの Y-axis は local Z-axis 方向に縮退しているので，Z-axis の逆方向を Y-axis と決める．
			if (yaxis2 ^ yaxis2_2 < 0.0):
				yaxis2 = -yaxis2
		else:                                                # X-axis は self 座標系のx-y 平面に現れるケース．
			_n.ldprint2('-- Xaxis and Yaxis are not parallel for self.zaxis.')
			xaxis2 = self._project2_4vec(xaxis3).normalized
			yaxis2 = xaxis2.perpendicular
			yaxis2_2 = self._project2_4vec(yaxis3)
			if (yaxis2 ^ yaxis2_2 < 0.0):
				yaxis2 = -yaxis2
		if (nd.LIB_DEBUG2):
			xaxis2.print('xaxis2 ')
			yaxis2.print('yaxis2 ')
			origin2.print('origin2')
		m = m2x3()
		m.setXaxis2(xaxis2)
		m.setYaxis2(yaxis2)
		m.setOrigin(origin2)
		if (nd.LIB_DEBUG2):
			m.print('projected matrix (2D)')
		_n.ldprint('<-- nkj.cs.mat3x4._project2_4matrix()')
		return m

	def project2(self, x):  # Project to the x-y plane in this coordinate system.
		if (_ncs.is_point3(x)):
			return self._project2_4point(x)
		elif (_ncs.is_point3list(x)):
			return self._project2_4pointlist(x)
		elif (_ncs.is_mat3x4(x)):
			return self._project2_4matrix(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			raise Exception('__ERROR__: Not implemented.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')

	def _project3_4point(self, x):  # Project to the x-y plane in the world coordinate system.
		_n.ldprint('--> nkj.cs.mat3x4.project3_4point()')
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (_ncs.is_point3list(x)):
			pts3 = x
		elif(isinstance(x, (list, tuple, np.ndarray))):
			pts3 = _ncs.point3list(x)
		else:
			raise Exception('__ERROR__: Not implemented. NKJ-PRIMITIVESHAPE-03812.')
		m = self
		if (nd.LIB_DEBUG2):
			m.print('mat3x4 (in project3())')
			pts3.print('pts3')
		pts3 = m.inv @ pts3
		if (nd.LIB_DEBUG2):
			pts3.print('pts3 (in the local cs)')
		npt3 = _ncs.point3([pt3.x, pt3.y, 0.0])
		if (nd.LIB_DEBUG2):
			npt3.print('npt3 (in the local cs)')
		npt3 = m @ npt3
		if (nd.LIB_DEBUG2):
			npt3.print('npt3 (in the world-cs)')
		_n.ldprint('<-- nkj.cs.mat3x4.project3_4point()')
		return npt3

	def _project3_4vec(self, x):  # Project to the x-y plane in the world coordinate system.
		return self._project3_4point(x)

	def _project3_4pointlist(self, x):  # Project to the x-y plane in the world coordinate system.
		_n.ldprint('--> nkj.cs.mat3x4.project3_4pointlist()')
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		if (_ncs.is_point3list(x)):
			pts3 = x
		elif(isinstance(x, (list, tuple, np.ndarray))):
			pts3 = _ncs.point3list(x)
		else:
			raise Exception('__ERROR__: Not implemented. NKJ-PRIMITIVESHAPE-03812.')
		m = self
		if (nd.LIB_DEBUG2):
			m.print('mat3x4 (in project3())')
			m.inv.print('mat3x4 (inversed)(in project3())')
			pts3.print('pts3')
		pts3 = m.inv @ pts3
		if (nd.LIB_DEBUG2):
			pts3.print('pts3 (in the local cs)')
		npts3 = _ncs.point3list()
		for pt3 in pts3:
			npts3.append(_ncs.point3([pt3.x, pt3.y, 0.0]))
		if (nd.LIB_DEBUG2):
			npts3.print('npts3 (in the local cs)')
		npts3 = m @ npts3
		if (nd.LIB_DEBUG2):
			npts3.print('npts3 (in the world-cs)')
		_n.ldprint('<-- nkj.cs.mat3x4.project3_4pointlist()')
		return npts3

	def _project3_4matrix(self, x):  # Project to the x-y plane in the world coordinate system.
		if (_ncs.is_mat3x4(x)):
			m2 = self._project2_4matrix(x)
			m3 = mat3x4()
			m3.setXaxis([m2.xaxis.x, m2.xaxis.y, 0.0])
			m3.setYaxis([m2.yaxis.x, m2.yaxis.y, 0.0])
			m3.setZaxis([0.0, 0.0, 1.0])
			m3.setOrigin([m2.origin.x, m2.origin.y, 0.0])
			return self @ m3
		else:
			raise TypeError('__ERROR__: Illegal data type.')

	def project3(self, x):  # Project to the x-y plane in this coordinate system.
		if (_ncs.is_point3(x)):
			return self._project3_4point(x)
		elif (_ncs.is_point3list(x)):
			return self._project3_4pointlist(x)
		elif (_ncs.is_mat3x4(x)):
			return self._project3_4matrix(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			ndim = _nm.ndim(x)
			if (ndim == 1):
				return self._project3_4point(point3(x))
			elif (ndim == 2):
				if (len(x) == 0):
					raise TypeError('__ERROR__: Illegal data type.')
				return self._project3_4pointlist(_ncs.point3list(x))
			else:
				raise Exception('__ERROR__: Not implemented.')
		else:
			raise TypeError('__ERROR__: Illegal data type.')

	def project(self, x):
		return self.project3(x)

	def getIcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Icosahedron vertecies
		_n.ldprint('--> nkj.cs.mat3x4.getIcosahedronVerts(, radius: {})'.format(radius))
		plist = self @  vec3([0.0, 0.0, 0.0]).getIcosahedronVerts(radius)
		_n.ldprint('<-- nkj.cs.mat3x4.getIcosahedronVerts()')
		return plist

	def IcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getIcosahedronVerts(radius)

	@property
	def icosahedronverts(self):
		return self.getIcosahedronVerts()

	def getOriginAndIcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):  # Origin and icosahedron vertecies
		_n.ldprint('--> nkj.cs.mat3x4.getOriginAndIcosahedronVerts(, radius: {})'.format(radius))
		plist = self @ vec3([0.0, 0.0, 0.0]).getOriginAndIcosahedronVerts(radius)
		_n.ldprint('<-- nkj.cs.mat3x4.getIcosahedronVerts()')
		return plist

	def OriginAndIcosahedronVerts(self, radius=_DEFAULT_RADIUS_FORVERTS):
		return self.getOriginAndIcosahedronVerts(radius)

	@property
	def origin_and_icosahedronverts(self):
		return self.getOriginAndIcosahedronVerts()

	# isinstance

	def isinstance(self, x):
		return is_mat3x4(x)

class mat3x4(mat3x4_cls):
	pass

class m3x4(mat3x4_cls):
	pass

class mat3(mat3x4_cls):
	pass

class m3(mat3x4_cls):
	pass

class csm3(mat3x4_cls):
	pass

class cs3(mat3x4_cls):
	pass

def is_mat3x4(x):
	return isinstance(x, mat3x4_cls)

def is_m3x4(x):
	return is_mat3x4(x)

def is_mat3(x):
	return is_mat3x4(x)

def is_m3(x):
	return is_mat3x4(x)

def is_csm3(x):
	return is_mat3x4(x)

def is_cs3(x):
	return is_mat3x4(x)


class scipyquaternion_cls(array_cls):
	#
	# (nk-)scipyquaternion の要素は scipy.transform.rotation = (x, y, z; w) に合わせて，
	# q = (v; s) = [imv[0], imv[1], imv[2], re]
	# とした．
	# ちなみに通常の要素表記，numpy.quaternion および nkj.cs.quaternion は，
	# q = (s; v) = [re, imv[0], imv[1], imv[2]]
	#
	_classname = 'nkj.cs.scipyquaternion'

	def __new__(cls, q=None):
		self = super().__new__(cls, shape=(4,), dtype='float32')  # shape=(d, 1): d次元の縦ベクトルを生成
		return self

	def __init__(self, q=None):
		super().__init__()
		self.set(_DEFAULT_SCIPYQUATERNION if (q is None) else q)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __inv__(self):  # '~' operator
		return self.getInversed()

	def __matmul__(self, x):
		if (self.isinstance(x)):
			#
			# q1 = (s1; v1), q2 = (s2; v2) とおく．ここで s1, s2 はスカラー，v1, v2 はベクトルとする．このとき，
			# q1 q2 = (s1 s2 - v1^v2; s1 v2 + s2 v1 + v1*v2)
			#
			s1 = self.getReal()
			v1 = self.getImaginaryVec()
			s2 = a.getReal()
			v2 = a.getImaginaryVec()
			s = s1 * s2 - (v1^v2)
			v = s1 * v2.a + s2 * v1.a + np.array(v1*v2)
			q = scipyquaternion()
			q.setComponent(_NKJSCIPYQUATERNION_REID, s)
			for i in range(3):
				q.setComponent(_NKJSCIPYQUATERNION_IMID + i, v.getComponent(i))
			return q
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def __rmatmul__(self, x):
			raise Exception('__ERROR__: Not implemented.')

	def set(self, q):
		_n.ldprint("--> nkj.cs.scipyquaternion.set()")
		_n.ldprint("q: {0} ({1})".format(q, type(q)))
		if (q is None):
			raise Exception('__ERROR__: Null input.')
		if (self.isinstance(q)):  # nkj.cs.scipyquaternion
			for i in range(4):
				self.setComponent(i, q.getComponent(q))
		elif (isinstance(q, scipy.spatial.transform._rotation.Rotation)):  # scipy.rotation
			super().set(q.as_quat())
		elif (isinstance(q, np.quaternion)):  # np.quaternion
			self.setNumpyQuaternion(q)
		elif (isinstance(q, np.ndarray)):
			super().set(q)
		elif (isinstance(q, (list, tuple))):
			super().set(np.array(q))
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint("<-- nkj.cs.scipyquaternion.set()")

	# Component

	def getComponent(self, i):
		return self[i]

	def setComponent(self, i, x):
		self[i] = x
		return True

	def Component(self, i, x=None):
		if (x is None):
			return self.getComponent(i)
		else:
			return self.setComponent(i, x)

	def component(self, i, x=None):
		if (x is None):
			return self.getComponent(i)
		else:
			return self.setComponent(i, x)

	def comp(self, i, x=None):
		return self.component(i, x)

	def c(self, i, x=None):
		return self.component(i, x)

	def getValue(self, i):
		return self.getComponent(i)

	def setValue(self, i, x):
		return self.setComponent(i, x)

	def Value(self, i, x=None):
		if (x is None):
			return self.getValue(i)
		else:
			self.setValue(i, x)

	def getVal(self, i):
		return self.getValue(i)

	def setVal(self, i, x):
		self.setValue(i, x)
		return True

	def value(self, i, x=None):
		return self.getValue(i) if (x is None) else self.setValue(x)

	def val(self, i, x=None):
		return self.value(i, x)

	def v(self, i, x=None):
		return self.value(i, x)

	@property
	def x(self):
		return self[_NKJSCIPYQUATERNION_IMID]

	@x.setter
	def x(self, _x):
		self[_NKJSCIPYQUATERNION_IMID] = _x

	@property
	def y(self):
		return self[_NKJSCIPYQUATERNION_IMID + 1]

	@y.setter
	def y(self, _y):
		self[_NKJSCIPYQUATERNION_IMID + 1] = _y

	@property
	def z(self):
		return self[_NKJSCIPYQUATERNION_IMID + 2]

	@z.setter
	def z(self, _z):
		self[_NKJSCIPYQUATERNION_IMID + 2] = _z

	@property
	def w(self):
		return self[_NKJSCIPYQUATERNION_REID]

	@w.setter
	def w(self, _w):
		self[_NKJSCIPYQUATERNION_REID] = _w

	def getCos(self):
		return self.getComponent(_NKJSCIPYQUATERNION_REID)

	def setCos(self, x):
		self.setComponent(_NKJSCIPYQUATERNION_REID, x)

	@property
	def cos(self):
		return self.getCos()

	@cos.setter
	def cos(self, x):
		self.setCos(x)

	def getReal(self):
		return self.getCos()

	def setReal(self, x):
		self.setCos(x)

	def getRe(self):
		return self.getReal()

	def setRe(self, x):
		self.setReal(x)

	@property
	def real(self):
		return self.getReal()

	@property
	def re(self):
		return self.getReal()

	@re.setter
	def re(self, x):
		self.setReal(x)

	def getSinVec(self):
		return vec3([self.getComponent(_NKJSCIPYQUATERNION_IMID), self.getComponent(_NKJSCIPYQUATERNION_IMID + 1), self.getComponent(_NKJSCIPYQUATERNION_IMID + 2)])

	def setSinVec(self, x):
		for i in range(3):
			self.setComponent(_NKJSCIPYQUATERNION_IMID + i, x[i])

	@property
	def sinvec(self):
		return self.getSinVec()

	@sinvec.setter
	def sinvec(self, x):
		self.setSin(x)

	def getImaginaryVec(self):
		return self.getSinVec()

	def setImaginaryVec(self, x):
		self.setSinVec(x)

	def getImvec(self):
		return self.getImaginaryVec()

	def setImvec(self, x):
		self.setImaginaryVec(x)

	def getImv(self):
		return self.getImaginaryVec()

	def setImv(self, x):
		self.setImaginaryVec(x)

	@property
	def imaginaryvec(self):
		return self.getImaginaryVec()

	@imaginaryvec.setter
	def imaginaryvec(self, x):
		self.setImaginaryVec(x)

	@property
	def imvec(self):
		return self.getImaginaryVec()

	@imvec.setter
	def imvec(self, x):
		self.setImaginaryVec(x)

	@property
	def imv(self):
		return self.getImaginaryVec()

	@imv.setter
	def imv(self, x):
		self.setImaginaryVec(x)

	@property
	def imag(self):
		return self.getImaginaryVec()

	def getSin(self):
		return self.getSinVec().norm

	@property
	def sin(self):
		return self.getSin()

	def getImaginary(self):
		return self.getSin()

	@property
	def imaginary(self):
		return self.getSin()

	@property
	def im(self):
		return self.getSin()

	# Scipy.Rotation (scipy.spatial.transform.Rotation)

	def getScipyRotation(self):
		return spr.from_quat(self.getScipyQuaternionArray())

	def setScipyRotation(self, r):
		self.setScipyQuaternionArray(r.as_quat())

	@property
	def scipyrotation(self):
		return self.getScipyRotation()

	@scipyrotation.setter
	def scipyrotation(self, r):
		self.setScipyRotation(r)

	@property
	def spr(self):
		return self.getScipyRotation()

	@spr.setter
	def spr(self, r):
		self.setScipyRotation(r)

	@property
	def srotation(self):
		return self.getScipyRotation()

	@srotation.setter
	def srotation(self, r):
		self.setScipyRotation(r)

	@property
	def sr(self):
		return self.getScipyRotation()

	@sr.setter
	def sr(self, r):
		self.setScipyRotation(r)

	# Quaternion Array (@nkj.cs.scipyquaternion)

	def getScipyQuaternionArray(self):
		return np.array([self[_NKJSCIPYQUATERNION_IMID], self[_NKJSCIPYQUATERNION_IMID + 1], self[_NKJSCIPYQUATERNION_IMID + 2], self[_NKJSCIPYQUATERNION_REID]])

	def setScipyQuaternionArray(self, a):
		self.setReal(a[3])
		self.setImaginaryVec(np.array([a[0], a[1], a[2]]))

	def ScipyQuaternionArray(self, a=None):
		if (a is None):
			return self.getScipyQuaternionArray()
		else:
			self.setScipyQuaternionArray(a)

	@property
	def scipyquaternionarray(self):
		return self.getScipyQuaternionArray()

	@scipyquaternionarray.setter
	def scipyquaternionarray(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def squatarray(self):
		return self.getScipyQuaternionArray()

	@squatarray.setter
	def squatrray(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def sqarray(self):
		return self.getScipyQuaternionArray()

	@sqarray.setter
	def sqarray(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def sqarr(self):
		return self.getScipyQuaternionArray()

	@sqarr.setter
	def sqarr(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def sqa(self):
		return self.getScipyQuaternionArray()

	@sqa.setter
	def sqa(self, a):
		self.setScipyQuaternionArray(a)

	def getNumpyQuaternionArray(self):
		return np.array([self[_NKJSCIPYQUATERNION_REID], self[_NKJSCIPYQUATERNION_IMID], self[_NKJSCIPYQUATERNION_IMID + 1], self[_NKJSCIPYQUATERNION_IMID + 2]])

	def setNumpyQuaternionArray(self, a):
		self.setReal(a[0])
		self.setImaginaryVec(np.array([a[1], a[2], a[3]]))

	def NumpyQuaternionArray(self, a=None):
		if (a is None):
			return self.getNumpyQuaternionArray()
		else:
			self.setNumpyQuaternionArray(a)

	@property
	def numpyquaternionarray(self):
		return self.getNumpyQuaternionArray()

	@numpyquaternionarray.setter
	def numpyquaternionarray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nquaternionarray(self):
		return self.getNumpyQuaternionArray()

	@nquaternionarray.setter
	def nquaternionarray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nquatarray(self):
		return self.getNumpyQuaternionArray()

	@nquatarray.setter
	def nquatrray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nqarray(self):
		return self.getNumpyQuaternionArray()

	@nqarray.setter
	def nqarray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nqarr(self):
		return self.getNumpyQuaternionArray()

	@nqarr.setter
	def nqarr(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nqa(self):
		return self.getNumpyQuaternionArray()

	@nqa.setter
	def nqa(self, a):
		self.setNumpyQuaternionArray(a)

	def getQuaternionArray(self):
		return np.array([self[_NKJSCIPYQUATERNION_REID], self[_NKJSCIPYQUATERNION_IMID], self[_NKJSCIPYQUATERNION_IMID + 1], self[_NKJSCIPYQUATERNION_IMID + 2]])

	def setQuaternionArray(self, a):
		self.setReal(a[0])
		self.setImaginaryVec(np.array([a[1], a[2], a[3]]))

	def QuaternionArray(self, a=None):
		if (a is None):
			return self.getQuaternionArray()
		else:
			self.setQuaternionArray(a)

	@property
	def quaternionarray(self):
		return self.getQuaternionArray()

	@quaternionarray.setter
	def quaternionarray(self, a):
		self.setQuaternionArray(a)

	@property
	def quatarray(self):
		return self.getQuaternionArray()

	@quatarray.setter
	def quatrray(self, a):
		self.setQuaternionArray(a)

	@property
	def qarray(self):
		return self.getQuaternionArray()

	@qarray.setter
	def qarray(self, a):
		self.setQuaternionArray(a)

	@property
	def qarr(self):
		return self.getQuaternionArray()

	@qarr.setter
	def qarr(self, a):
		self.setQuaternionArray(a)

	@property
	def qa(self):
		return self.getQuaternionArray()

	@qa.setter
	def qa(self, a):
		self.setQuaternionArray(a)

	# Quaternion (@nkj.cs.scipyquaternion)

	def getNumpyQuaternion(self):
		a = self.getNumpyQuaternionArray()
		return np.quaternion(a[0], a[1], a[2], a[3])

	def setNumpyQuaternion(self, q):
		_n.ldprint0('--> nkj.cs.quaternion.setNumpyQuaternion()')
		if (not isinstance(q, np.quaternion)):
			raise TypeError("__ERROR__: Illegal data type.")
		self.setNumpyQuaternionArray([q.w, q.x, q.y, q.z])
		if (nd.DEBUG0):
			self.print('self')
		_n.ldprint0('<-- nkj.cs.quaternion.setNumpyQuaternion()')

	def NumpyQuaternoin(self, q=None):
		if (q is None):
			return self.getNumpyQuaternion()
		else:
			self.setNumpyQuaternion(q)

	@property
	def nquaternion(self):
		return self.getNumpyQuaternion()

	@nquaternion.setter
	def nquaternion(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nquat(self):
		return self.getNumpyQuaternion()

	@nquat.setter
	def nquat(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nq(self):
		return self.getNumpyQuaternion()

	@nq.setter
	def nq(self, q):
		self.setNumpyQuaternion(q)

	def getQuaternion(self):
		a = self.getQuaternionArray()
		return quaternion(a[0], a[1], a[2], a[3])

	def setQuaternion(self, q):
		if (not isinstance(q, quaternion)):
			raise TypeError("__ERROR__: Illegal data type.")
		self.setQuaternionArray([q.w, q.x, q.y, q.z])

	def Quaternoin(self, q=None):
		if (q is None):
			return self.getQuaternion()
		else:
			self.setQuaternion(q)

	@property
	def quaternion(self):
		return self.getQuaternion()

	@quaternion.setter
	def quaternion(self, q):
		self.setQuaternion(q)

	@property
	def quat(self):
		return self.getQuaternion()

	@quat.setter
	def quat(self, q):
		self.setQuaternion(q)

	@property
	def q(self):
		return self.getQuaternion()

	@q.setter
	def q(self, _q):
		self.setQuaternion(_q)

	# Mathematical expression

	def getMathematicalExpression(self):
		return self.getReal(), self.getImaginaryVec()

	def setMathematicalExpression(self, re, imv):
		self.setReal(re)
		self.setImaginaryVec(imv)

	def getMathex(self):
		return self.getMathematicalExpression()

	def setMathex(self, re, imv):
		self.setMathematicalExpression(re, imv)

	@property
	def mathex(self):
		return self.getMathematicalExpression()

	@mathex.setter
	def mathex(self, re, imv):
		self.setMathematicalExpression(re, imv)

	def getMathematicalExpressionArray(self):
		imv = self.getImaginaryVec()
		return np.array((self.getReal(), imv[0], imv[1], imv[2]))

	def setMathematicalExpressionArray(self, a):
		self.setMathematicalExpression(a[0], np.array(a[1], a[2], a[3]))

	def getMathexArray(self):
		return getMathematicalExpressionArray(self)

	def setMathexArray(self, a):
		self.setMathematicalExpressionArray(a)

	@property
	def mathexarray(self):
		return self.getMathematicalExpressionArray()

	@mathexarray.setter
	def mathexarray(self, a):
		self.setMathematicalExpressionArray(a)

	# Matrix

	def getMat3x3(self):
		rm = mat3x3()
		rm.setScipyRotation(spr.from_quat(self.getScipyQuaternionArray()))
		return rm

	def setMat3x3(self, m):
		self.setScipyRotation(spr.from_matrix(m))

	@property
	def mat3x3(self):
		return self.getMat3x3()

	@mat3x3.setter
	def mat3x3(self, m):
		self.setMat3x3(m)

	@property
	def m3x3(self):
		return self.getMat3x3()

	@m3x3.setter
	def m3x3(self, m):
		self.setMat3x3(m)

	def getRotationalMatrix(self):
		return self.getMat3x3()

	def setRotationalMatrix(self, m):
		self.setMat3x3(m)

	@property
	def rotationalmatrix(self):
		return self.getRotationalMatrix()

	@rotationalmatrix.setter
	def rotationalmatrix(self, m):
		self.setRotationalMatrix(m)

	@property
	def rotmat(self):
		return self.getRotationalMatrix()

	@rotmat.setter
	def rotmat(self, m):
		self.setRotationalMatrix(m)

	@property
	def rm(self):
		return self.getRotationalMatrix()

	@rm.setter
	def rm(self, m):
		self.setRotationalMatrix(m)

	def getMatrix(self):
		return self.getMat3x3()

	def setMatrix(self, m):
		self.setMat3x3(m)

	@property
	def matrix(self):
		return self.getMatrix()

	@matrix.setter
	def matrix(self, m):
		self.setMatrix(m)

	@property
	def mat(self):
		return self.getMatrix()

	@mat.setter
	def mat(self, m):
		self.setMatrix(m)

	@property
	def m(self):
		return self.getMatrix()

	@m.setter
	def m(self, _m):
		self.setMatrix(_m)

	def getMat3x4(self):
		m = mat3x4()
		m.setRotationalMatrix(self.getMat3x3())
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	@property
	def m3x4(self):
		return self.getMat3x4()

	def getMat3(self):
		return self.getMat3x4()

	@property
	def mat3(self):
		return self.getMatrix()

	@property
	def m3(self):
		return self.getMatrix()

	@property
	def csm3(self):
		return self.getMatrix()

	@property
	def cs3(self):
		return self.getMatrix()

	# Operation

	def inverse(self):
		q = self.getNumpyQuaternion()
		self.setNumpyQuaternion(q.inverse())

	def getInversed(self):
		q = copy.deepcopy(self)
		q.inverse()
		return q

	@property
	def inversed(self):
		return self.getInversed()

	@property
	def inv(self):
		return self.getInversed()

	@property
	def i(self):
		return self.getInversed()

	def conjugate(self):
		q = self.getNumpyQuaternion()
		self.setNumpyQuaternion(q.conjugate())

	def getConjugated(self):
		q = copy.deepcopy(self)
		q.conjugate()
		return q

	@property
	def conjugated(self):
		return self.getConjugated()

	@property
	def conj(self):
		return self.getConjugated()

	@property
	def j(self):
		return self.getConjugated()

	# Geometrical computation

	def getDirectionalVector(self):
		v = self.getSinVec()
		v.normalized
		return v

	@property
	def directionalvector(self):
		return self.getDirectionalVector()

	def getDirection(self):
		return self.getDirectionalVector()

	@property
	def direction(self):
		return self.getDirectionalVector()

	def getVector(self):
		return self.getDirectionalVector()

	@property
	def vector(self):
		return self.getDirectionalVector()

	@property
	def vec(self):                           # nkj.cs.scipyquaternion での self.vec は正規化してあるので注意
		return self.getDirectionalVector()

	@property
	def v(self):
		return self.getDirectionalVector()

	def getRotationalAngle(self):
		c = self.getCos()
		s = self.getSin()
		ang = math.atan2(s, c)
		ang = 2.0 * ang
		return ang

	@property
	def rotationalangle(self):
		return self.getRotationalAngle()

	def getAngle(self):
		return self.getRotationalAngle()

	@property
	def angle(self):
		return self.getRotationalAngle()

	@property
	def ang(self):
		return self.getRotationalAngle()

	@property
	def rad(self):
		return self.getAngle()

	@property
	def deg(self):
		return _nm.rad2deg(self.getAngle())

	def getNumpyAngle(self):
		q = self.getNumpyQuaternion()
		return q.angle()

	@property
	def npangle(self):
		return self.getAngle()

	@property
	def npang(self):
		return self.getAngle()

	def getDirectionalVectorAndAngle(self):
		vec = self.getDirectionalVector()
		ang = self.getAngle()
		return vec, ang

	def getDirectionAndAngle(self):
		return gelf.getDirectionalVectorAndAngle()

	def getVectorAndAngle(self):
		return self.getDirectionalVectorAndAngle()

	def setDirectionalVectorAndAngle(self, v, ang):
		_n.ldprint("--> nkj.cs.quat.setDirectinalVectorAndAngle()")
		nv = copy.deepcopy(v)
		nv.normalize()
		c = math.cos(ang / 2.0)
		s = math.sin(ang / 2.0)
		_n.ldprint2("cos: {}".format(c))
		_n.ldprint2("sin: {}".format(s))
		self.setComponent(_NKJSCIPYQUATERNION_IMID,     s * nv.getComponent(0))
		self.setComponent(_NKJSCIPYQUATERNION_IMID + 1, s * nv.getComponent(1))
		self.setComponent(_NKJSCIPYQUATERNION_IMID + 2, s * nv.getComponent(2))
		self.setComponent(_NKJSCIPYQUATERNION_REID, c)
		_n.ldprint("<-- nkj.cs.quat.setDirectinalVectorAndAngle()")

	def setDirectionAndAngle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	def setVectorAndAngle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def directionalvector_angle(self):
		return self.getDirectionalVectorAndAngle()

	@directionalvector_angle.setter
	def directionalvectorandangle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def direction_angle(self):
		return self.getDirectionalVectorAndAngle()

	@direction_angle.setter
	def directionandangle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def vector_angle(self):
		return self.getDirectionalVectorAndAngle()

	@vector_angle.setter
	def vector_angle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def vec_ang(self):
		return self.getDirectionalVectorAndAngle()

	@vec_ang.setter
	def vec_ang(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	def slerp(self, second, w=0.5):
		return Slerp(self, second, w)

	# Components

	def getComponents(self):
		return [self[0], self[1], self[2], self[3]]

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data type.')
		if (np.array(x).ndim != 1):
			raise TypeError('__ERROR__: Illegal data type.')
		if (len(x) != 4):
			raise TypeError('__ERROR__: Illegal data type.')
		for i in range(4):
			self[i] = x[i]

	def Components(self, x=None):
		if (x is None):
			return self.getComponents()
		else:
			self.setComponents(x)

	@property
	def components(self):
		return self.getComponents()

	@components.setter
	def components(self, x):
		self.setComponents(x)

	@property
	def comps(self):
		return self.getComponents()

	@comps.setter
	def comps(self, x):
		self.Components(x)

	def getSerialized(self):
		return self.getComponents()

	@property
	def serialized(self):
		return self.getSerialized()

	def Serialize(self):
		return self.getSerialized()

	def serialize(self):
		return self.getSerialized()

	# Data string

	def getDataString(self, rowend=None):
		_n.ldprint('--> nkj.cs.scipyquaternion.getDataString()')
		_n.ldprint('rowend: \'{}\''.format('CR' if (rowend == '\n') else rowend))
		s = ''
		for i in range(4):
			if (i != 0):
				s += ', '
			s += '{:21.12f}'.format(self.getComponent(i))
		_n.ldprint('s: \'{}\''.format(s))
		_n.ldprint('<-- nkj.cs.scipyquaternion.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.cs.scipyquaternion.setDataString()')
		_n.ldprint('datastr: \'{0}\' ({1})'.format(s, type(s)))
		if (len(s) == 0):
			_n.print_error('Null string s[{0}]: \'{1}\' ({2})'.format(len(s), s, type(s)))
			raise ValueError('__ERROR__: Null input.')
		if (s[-1] == '\n'):
			s = s[:-1]
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		s = s.replace('\n', ', ').replace('(', '').replace(')', '').split(',')
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		data = list(map(float, s))
		_n.ldprint('list[{0}]: {1} ({2})'.format(len(data), data, type(data)))
		if (len(data) != 4):
			raise TypeError('__ERROR__: Illegal data type.')
		self.set([data[0], data[1], data[2], data[3]])
		_n.ldprint('<-- nkj.cs.scipyquaternion.setDataString()')

	def DataString(self, s=None, rowend=''):
		if (s is None):
			return self.getDataString(rowend)
		else:
			self.setDataString(s)

	def getDataStr(self, rowend=''):
		return self.getDataString(rowend)

	def setDataStr(self, s):
		self.setDataString(s)

	def DataStr(self, s=None, rowend=''):
		if (s is None):
			return self.getDataString(rowend)
		else:
			self.setDataString(s)

	@property
	def datastring(self):
		return self.getDataString()

	@datastring.setter
	def datastring(self, s):
		self.setDataString(s)

	@property
	def datastr(self):
		return self.getDataString()

	@datastr.setter
	def datastr(self, s):
		self.setDataString(s)

	@property
	def dstr(self):
		return self.getDataString()

	@dstr.setter
	def dstr(self, s):
		self.setDataString(s)

	@property
	def ds(self):
		return self.getDataString()

	@ds.setter
	def ds(self, s):
		self.setDataString(s)

	# Print

	def getPrintString(self, title=None, flag=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '('
		for i in range(3):
			if (i != 0):
				s += ', '
	@property
	def datastr(self):
		return self.getDataString()

	@datastr.setter
	def datastr(self, s):
		self.setDataString(s)

	@property
	def dstr(self):
		return self.getDataString()

	@dstr.setter
	def dstr(self, s):
		self.setDataString(s)

	@property
	def ds(self):
		return self.getDataString()

	@ds.setter
	def ds(self, s):
		self.setDataString(s)

	# Print

	def getPrintString(self, title=None, flag=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		s += '('
		for i in range(3):
			if (i != 0):
				s += ', '
			s += '{:21.12f}'.format(self.getComponent(_NKJSCIPYQUATERNION_IMID + i))
		s += '; '
		s += '{:21.12f}'.format(self.getComponent(_NKJSCIPYQUATERNION_REID))
		s += ')'
		return s

	def getPrintStr(self, title=None, flag=None):
		return self.getPrintString(title, flag)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None, flag=None):
		print(self.getPrintString(title, flag), flush=True)

	# Load, Save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataStr(f.read())

	def save(self, filename, rowend=None):
		_n.ldprint('--> nkj.cs.scipyquaternion.save(\'{}\')'.format(filename))
		_n.ldprint('s: \'{}\''.format(self.getDataString(rowend)))
		_DATAEND = '\n'
		if (filename == '-'):
			print(self.getDataString(rowend) + _DATAEND, flush=True)
		else:
			with open(filename, 'w') as f:
				f.write(self.getDataString(rowend) + _DATAEND)
		_n.ldprint('<-- nkj.cs.scipyquaternion.save()')

	# isinstance

	def isinstance(self, v):
		return is_scipyquaternion(v)

class scipyquaternion(scipyquaternion_cls):
	pass

class squaternion(scipyquaternion):
	pass

class squat(scipyquaternion):
	pass

class sq(scipyquaternion):
	pass

def is_scipyquaternion(x):
	return isinstance(x, scipyquaternion_cls)

def is_squaternion(x):
	return is_scipyquaternion(x)

def is_squat(x):
	return is_scipyquaternion(x)

def is_sq(x):
	return is_scipyquaternion(x)


class quaternion_cls(np.quaternion):
	#
	# 要素は，numpy.quaternion および通常の要素表記に合わせて，
	# q = (s; v) = [re, imv[0], imv[1], imv[2]]
	# とする．
	# ちなみに，scipy.transform.rotation および nkj.cs.scipyquaternion では，
	# q = (v; s) = [imv[0], imv[1], imv[2], re]
	# であるので注意．
	#
	_classname = 'nkj.cs.quaternion'

	def __init__(self, q=None):
		self.set(_DEFAULT_QUATERNION if (q is None) else q)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __str__(self):
		return self.getPrintString()

	def __repr__(self):
		return self.getPrintString()

	def __neg__(self):
		return self.__class__(super().__neg__())

	def __invert__(self):
		return self.__class__(super().__invert__())

	def __add__(self, second):
		return self.__class__(super().__add__(second))

	def __sub__(self, second):
		return self.__class__(super().__sub__(second))

	def __mul__(self, second):
		return self.__class__(super().__mul__(second))

	def __matmul__(self, second):
		return self.__class__(self.__mul__(second))

	def __truediv__(self, second):
		return self.__class__(super().__truediv__(second))

	def __iadd__(self, second):
		return self.__class__(super().__iadd__(second))

	def __isub__(self, second):
		return self.__class__(super().__isub__(second))

	def __imul__(self, second):
		return self.__class__(super().__imul__(second))

	def __imatmul__(self, second):
		return self.__class__(super().__imatmul__(second))

	def __itruediv__(self, second):
		return self.__class__(super().__itruediv__(second))

	def set(self, q):
		_n.ldprint("--> nkj.cs.quaternion.set()")
		_n.ldprint("q: {0} ({1})".format(q, type(q)))
		if (q is None):
			raise Exception('__ERROR__: Null input.')
		if (self.isinstance(q)):  # nkj.cs.quaternion
			q = q.components
		elif (isinstance(q, scipy.spatial.transform._rotation.Rotation)):  # scipy.rotation
			qarr = q.as_quat()
			q = [qarr[3], qarr[0], qarr[1], qarr[2]]
		elif (isinstance(q, np.quaternion)):  # np.quaternion
			q = [q.w, q.x, q.y, q.z]
		elif (isinstance(q, (list, tuple, np.ndarray))):
			pass
		else:
			raise TypeError('__ERROR__: Illegal data type.')
		super().__init__(q[0], q[1], q[2], q[3])
		_n.ldprint("<-- nkj.cs.quaternion.set()")

	# Component

	def getComponent(self, i):
		if (i == 0):
			c = self.w
		elif (i == 1):
			c = self.x
		elif (i == 2):
			c = self.y
		elif (i == 3):
			c = self.z
		else:
			_ns.print_error('Index: {}'.format(i))
			raise ValueError('__ERROR__: Illegal index.')
		return c

	def setComponent(self, i, x):
		if (i == 0):
			self.w = x
		elif (i == 1):
			self.x = x
		elif (i == 2):
			self.y = x
		elif (i == 3):
			self.z = x
		else:
			_ns.print_error('Index: {}'.format(i))
			raise ValueError('__ERROR__: Illegal index.')
		return True

	def component(self, i, x=None):
		if (x is None):
			return self.getComponent(i)
		else:
			return self.setComponent(i, x)

	def comp(self, i, x=None):
		return self.component(i, x)

	def c(self, i, x=None):
		return self.component(i, x)

	def getValue(self, i):
		return self.getComponent(i)

	def setValue(self, i, x):
		return self.setComponent(i, x)

	def getVal(self, i):
		return self.getValue(i)

	def setVal(self, i, x):
		return self.setValue(i, x)

	def value(self, i, x=None):
		return self.getValue(i) if (x is None) else self.setValue(x)

	def val(self, i, x=None):
		return self.value(i, x)

	def v(self, i, x=None):
		return self.value(i, x)

	# self.w, self.x, self.y, self.z は numpy.quaternion で実装済

	def getCos(self):
		return self.getComponent(_NKJQUATERNION_REID)

	def setCos(self, x):
		self.setComponent(_NKJQUATERNION_REID, x)

	@property
	def cos(self):
		return self.getCos()

	@cos.setter
	def cos(self, x):
		self.setCos(x)

	def getReal(self):
		return self.getCos()

	def setReal(self, x):
		self.setCos(x)

	def getRe(self):
		return self.getReal()

	def setRe(self, x):
		self.setReal(x)

	# self.real は numpy.quaternion で実装済

	@property
	def re(self):
		return self.getReal()

	@re.setter
	def re(self, x):
		self.setReal(x)

	def getSinVec(self):
		return vec3([self.getComponent(_NKJQUATERNION_IMID), self.getComponent(_NKJQUATERNION_IMID + 1), self.getComponent(_NKJQUATERNION_IMID + 2)])

	def setSinVec(self, x):
		for i in range(3):
			self.setComponent(_NKJQUATERNION_IMID + i, x[i])

	@property
	def sinvec(self):
		return self.getSinVec()

	@sinvec.setter
	def sinvec(self, x):
		self.setSin(x)

	def getImaginaryVec(self):
		return self.getSinVec()

	def setImaginaryVec(self, x):
		self.setSinVec(x)

	def getImvec(self):
		return self.getImaginaryVec()

	def setImvec(self, x):
		self.setImaginaryVec(x)

	def getImv(self):
		return self.getImaginaryVec()

	def setImv(self, x):
		self.setImaginaryVec(x)

	@property
	def imaginaryvec(self):
		return self.getImaginaryVec()

	@imaginaryvec.setter
	def imaginaryvec(self, x):
		self.setImaginaryVec(x)

	@property
	def imvec(self):
		return self.getImaginaryVec()

	@imvec.setter
	def imvec(self, x):
		self.setImaginaryVec(x)

	@property
	def imv(self):
		return self.getImaginaryVec()

	@imv.setter
	def imv(self, x):
		self.setImaginaryVec(x)

	def getSin(self):
		return self.getSinVec().norm

	@property
	def sin(self):
		return self.getSin()

	def getImaginary(self):
		return self.getSin()

	@property
	def imaginary(self):
		return self.getSin()

	# self.imag は numpy.quaternion で np.array ベクトルとして実装済．あえて override しない．

	@property
	def im(self):
		return self.getSin()

	# scipy.rotation

	def getScipyRotation(self):
		return spr.from_quat(self.getScipyQuaternionArray())

	def setScipyRotation(self, r):
		self.setScipyQuaternionArray(r.as_quat())

	@property
	def scipyrotation(self):
		return self.getScipyRotation()

	@scipyrotation.setter
	def scipyrotation(self, r):
		self.setScipyRotation(r)

	@property
	def spr(self):
		return self.getScipyRotation()

	@spr.setter
	def spr(self, r):
		self.setScipyRotation(r)

	@property
	def srotation(self):
		return self.getScipyRotation()

	@srotation.setter
	def srotation(self, r):
		self.setScipyRotation(r)

	@property
	def sr(self):
		return self.getScipyRotation()

	@sr.setter
	def sr(self, r):
		self.setScipyRotation(r)

	# Quaternion Array (@nkj.cs.quaternion)

	def getScipyQuaternionArray(self):
		return np.array([self.getComponent(_NKJQUATERNION_IMID), self.getComponent(_NKJQUATERNION_IMID + 1), self.getComponent(_NKJQUATERNION_IMID + 2), self.getComponent(_NKJQUATERNION_REID)])

	def setScipyQuaternionArray(self, a):
		self.setReal(a[3])
		self.setImaginaryVec(np.array([a[0], a[1], a[2]]))

	def ScipyQuaternionArray(self, a=None):
		if (a is None):
			return self.getScipyQuaternionArray()
		else:
			self.setScipyQuaternionArray(a)

	@property
	def scipyquaternionarray(self):
		return self.getScipyQuaternionArray()

	@scipyquaternionarray.setter
	def scipyquaternionarray(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def squatarray(self):
		return self.getScipyQuaternionArray()

	@squatarray.setter
	def squatrray(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def sqarray(self):
		return self.getScipyQuaternionArray()

	@sqarray.setter
	def sqarray(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def sqarr(self):
		return self.getScipyQuaternionArray()

	@sqarr.setter
	def sqarr(self, a):
		self.setScipyQuaternionArray(a)

	@property
	def sqa(self):
		return self.getScipyQuaternionArray()

	@sqa.setter
	def sqa(self, a):
		self.setScipyQuaternionArray(a)

	def getNumpyQuaternionArray(self):
		return np.array([self.getComponent(_NKJQUATERNION_REID), self.getComponent(_NKJQUATERNION_IMID), self.getComponent(_NKJQUATERNION_IMID + 1), self.getComponent(_NKJQUATERNION_IMID + 2)])

	def setNumpyQuaternionArray(self, a):
		self.setReal(a[0])
		self.setImaginaryVec(np.array([a[1], a[2], a[3]]))

	def NumpyQuaternionArray(self, a=None):
		if (a is None):
			return self.getNumpyQuaternionArray()
		else:
			self.setNumpyQuaternionArray(a)

	@property
	def numpyquaternionarray(self):
		return self.getNumpyQuaternionArray()

	@numpyquaternionarray.setter
	def numpyquaternionarray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nquaternionarray(self):
		return self.getNumpyQuaternionArray()

	@nquaternionarray.setter
	def nquaternionarray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nquatarray(self):
		return self.getNumpyQuaternionArray()

	@nquatarray.setter
	def nquatrray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nqarray(self):
		return self.getNumpyQuaternionArray()

	@nqarray.setter
	def nqarray(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nqarr(self):
		return self.getNumpyQuaternionArray()

	@nqarr.setter
	def nqarr(self, a):
		self.setNumpyQuaternionArray(a)

	@property
	def nqa(self):
		return self.getNumpyQuaternionArray()

	@nqa.setter
	def nqa(self, a):
		self.setNumpyQuaternionArray(a)

	def getQuaternionArray(self):
		return np.array([self[_NKJQUATERNION_REID], self[_NKJQUATERNION_IMID], self[_NKJQUATERNION_IMID + 1], self[_NKJQUATERNION_IMID + 2]])

	def setQuaternionArray(self, a):
		self.setReal(a[0])
		self.setImaginaryVec(np.array([a[1], a[2], a[3]]))

	def QuaternionArray(self, a=None):
		if (a is None):
			return self.getQuaternionArray()
		else:
			self.setQuaternionArray(a)

	@property
	def quaternionarray(self):
		return self.getQuaternionArray()

	@quaternionarray.setter
	def quaternionarray(self, a):
		self.setQuaternionArray(a)

	@property
	def quatarray(self):
		return self.getQuaternionArray()

	@quatarray.setter
	def quatrray(self, a):
		self.setQuaternionArray(a)

	@property
	def qarray(self):
		return self.getQuaternionArray()

	@qarray.setter
	def qarray(self, a):
		self.setQuaternionArray(a)

	@property
	def qarr(self):
		return self.getQuaternionArray()

	@qarr.setter
	def qarr(self, a):
		self.setQuaternionArray(a)

	@property
	def qa(self):
		return self.getQuaternionArray()

	@qa.setter
	def qa(self, a):
		self.setQuaternionArray(a)

	# Quaternion (@nkj.cs.quaternion)

	def getScipyQuaternion(self):
		return scipyquaternion(self.getScipyQuaternionArray())

	def setScipyQuaternion(self, q):
		if (not isinstance(q, scipyquaternion)):
			raise TypeError("__ERROR__: Illegal data type.")
		self.setScipyQuaternionArray([q.x, q.y, q.z, q.w])

	def ScipyQuaternoin(self, q=None):
		if (q is None):
			return self.getScipyQuaternion()
		else:
			self.setScipyQuaternion(q)

	@property
	def scipyquaternion(self):
		return self.getScipyQuaternion()

	@scipyquaternion.setter
	def scipyquaternion(self, q):
		self.setScipyQuaternion(q)

	@property
	def squaternion(self):
		return self.getScipyQuaternion()

	@squaternion.setter
	def squaternion(self, q):
		self.setScipyQuaternion(q)

	@property
	def squat(self):
		return self.getScipyQuaternion()

	@squat.setter
	def squat(self, q):
		self.setScipyQuaternion(q)

	@property
	def sq(self):
		return self.getScipyQuaternion()

	@sq.setter
	def sq(self, q):
		self.setScipyQuaternion(q)

	def getNumpyQuaternion(self):
		a = self.getNumpyQuaternionArray()
		return np.quaternion(a[0], a[1], a[2], a[3])

	def setNumpyQuaternion(self, q):
		if (not isinstance(q, np.quaternion)):
			raise TypeError("__ERROR__: Illegal data type.")
		self.setNumpyQuaternionArray([q.w, q.x, q.y, q.z])

	def NumpyQuaternoin(self, q=None):
		if (q is None):
			return self.getNumpyQuaternion()
		else:
			self.setNumpyQuaternion(q)

	@property
	def numpyquaternion(self):
		return self.getNumpyQuaternion()

	@numpyquaternion.setter
	def numpyquaternion(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nquaternion(self):
		return self.getNumpyQuaternion()

	@nquaternion.setter
	def nquaternion(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nquat(self):
		return self.getNumpyQuaternion()

	@nquat.setter
	def nquat(self, q):
		self.setNumpyQuaternion(q)

	@property
	def nq(self):
		return self.getNumpyQuaternion()

	@nq.setter
	def nq(self, q):
		self.setNumpyQuaternion(q)

	# Mathematical expression

	def getMathematicalExpression(self):
		return self.getReal(), self.getImaginaryVec()

	def setMathematicalExpression(self, re, imv):
		self.setReal(re)
		self.setImaginaryVec(imv)

	def getMathex(self):
		return self.getMathematicalExpression()

	def setMathex(self, re, imv):
		self.setMathematicalExpression(re, imv)

	@property
	def mathex(self):
		return self.getMathematicalExpression()

	@mathex.setter
	def mathex(self, re, imv):
		self.setMathematicalExpression(re, imv)

	def getMathematicalExpressionArray(self):
		imv = self.getImaginaryVec()
		return np.array((self.getReal(), imv[0], imv[1], imv[2]))

	def setMathematicalExpressionArray(self, a):
		self.setMathematicalExpression(a[0], np.array(a[1], a[2], a[3]))

	def getMathexArray(self):
		return getMathematicalExpressionArray(self)

	def setMathexArray(self, a):
		self.setMathematicalExpressionArray(a)

	@property
	def mathexarray(self):
		return self.getMathematicalExpressionArray()

	@mathexarray.setter
	def mathexarray(self, a):
		self.setMathematicalExpressionArray(a)

	# Matrix

	def getMat3x3(self):
		rm = mat3x3()
		rm.setScipyRotation(spr.from_quat(self.getScipyQuaternionArray()))
		return rm

	def setMat3x3(self, m):
		self.setScipyRotation(spr.from_matrix(m))

	@property
	def mat3x3(self):
		return self.getMat3x3()

	@mat3x3.setter
	def mat3x3(self, m):
		self.setMat3x3(m)

	@property
	def m3x3(self):
		return self.getMat3x3()

	@m3x3.setter
	def m3x3(self, m):
		self.setMat3x3(m)

	def getRotationalMatrix(self):
		return self.getMat3x3()

	def setRotationalMatrix(self, m):
		self.setMat3x3(m)

	@property
	def rotationalmatrix(self):
		return self.getRotationalMatrix()

	@rotationalmatrix.setter
	def rotationalmatrix(self, m):
		self.setRotationalMatrix(m)

	@property
	def rotmat(self):
		return self.getRotationalMatrix()

	@rotmat.setter
	def rotmat(self, m):
		self.setRotationalMatrix(m)

	@property
	def rm(self):
		return self.getRotationalMatrix()

	@rm.setter
	def rm(self, m):
		self.setRotationalMatrix(m)

	def getMatrix(self):
		return self.getMat3x3()

	def setMatrix(self, m):
		self.setMat3x3(m)

	@property
	def matrix(self):
		return self.getMatrix()

	@matrix.setter
	def matrix(self, m):
		self.setMatrix(m)

	@property
	def mat(self):
		return self.getMatrix()

	@mat.setter
	def mat(self, m):
		self.setMatrix(m)

	@property
	def m(self):
		return self.getMatrix()

	@m.setter
	def m(self, _m):
		self.setMatrix(_m)

	def getMat3x4(self):
		m = mat3x4()
		m.setRotationalMatrix(self.getMat3x3())
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	@property
	def m3x4(self):
		return self.getMat3x4()

	def getMat3(self):
		return self.getMat3x4()

	@property
	def mat3(self):
		return self.getMatrix()

	@property
	def m3(self):
		return self.getMatrix()

	@property
	def csm3(self):
		return self.getMatrix()

	@property
	def cs3(self):
		return self.getMatrix()

	# Geometrical compuation

	def getDirectionalVector(self):
		v = self.getSinVec()
		v.normalized
		return v

	@property
	def directionalvector(self):
		return self.getDirectionalVector()

	def getDirection(self):
		return self.getDirectionalVector()

	@property
	def direction(self):
		return self.getDirectionalVector()

	def getVector(self):
		return self.getDirectionalVector()

	@property
	def vector(self):
		return self.getDirectionalVector()

	@property
	def vec(self):
		return self.getDirectionalVector()

	@property
	def v(self):
		return self.getDirectionalVector()

	def getRotationalAngle(self):
		c = self.getCos()
		s = self.getSin()
		ang = math.atan2(s, c)
		ang = 2.0 * ang
		return ang

	@property
	def rotationalangle(self):
		return self.getRotationalAngle()

	def getAngle(self):
		return self.getRotationalAngle()

	@property
	def angle(self):
		return self.getRotationalAngle()

	@property
	def ang(self):
		return self.getRotationalAngle()

	@property
	def rad(self):
		return self.getAngle()

	@property
	def deg(self):
		return _nm.rad2deg(self.getAngle())

	def getNumpyAngle(self):
		q = self.getNumpyQuaternion()
		return q.angle()

	@property
	def npangle(self):
		return self.getAngle()

	@property
	def npang(self):
		return self.getAngle()

	def getDirectionalVectorAndAngle(self):
		vec = self.getDirectionalVector()
		ang = self.getAngle()
		return vec, ang

	def getDirectionAndAngle(self):
		return gelf.getDirectionalVectorAndAngle()

	def getVectorAndAngle(self):
		return self.getDirectionalVectorAndAngle()

	def setDirectionalVectorAndAngle(self, v, ang):
		_n.ldprint("--> nkj.cs.quaternion.setDirectinalVectorAndAngle()")
		nv = copy.deepcopy(v)
		nv.normalize()
		c = math.cos(ang / 2.0)
		s = math.sin(ang / 2.0)
		_n.ldprint2("cos: {}".format(c))
		_n.ldprint2("sin: {}".format(s))
		self.setComponent(_NKJQUATERNION_REID, c)
		self.setComponent(_NKJQUATERNION_IMID,     s * nv.getComponent(0))
		self.setComponent(_NKJQUATERNION_IMID + 1, s * nv.getComponent(1))
		self.setComponent(_NKJQUATERNION_IMID + 2, s * nv.getComponent(2))
		_n.ldprint("<-- nkj.cs.quaternion.setDirectinalVectorAndAngle()")

	def setDirectionAndAngle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	def setVectorAndAngle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def directionalvector_angle(self):
		return self.getDirectionalVectorAndAngle()

	@directionalvector_angle.setter
	def directionalvectorandangle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def direction_angle(self):
		return self.getDirectionalVectorAndAngle()

	@direction_angle.setter
	def directionandangle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def vector_angle(self):
		return self.getDirectionalVectorAndAngle()

	@vector_angle.setter
	def vector_angle(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	@property
	def vec_ang(self):
		return self.getDirectionalVectorAndAngle()

	@vec_ang.setter
	def vec_ang(self, v, ang):
		self.setDirectionalVectorAndAngle(v, ang)

	def slerp(self, second, w=0.5):
		return Slerp(self, second, w)

	# Operators

	# self.inverse() は numpy.quaternion で実装済であるが，nkj.cs.quaternion クラスで返したいのでオーバーライドする．

	def inverse(self):
		_n.ldprint('--> nkj.cs.quaternion.inverse()')
		nq = self.getNumpyQuaternion()  # numpy.quaternion クラス
		self.setNumpyQuaternion(nq.inverse())
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint('<-- nkj.cs.quaternion.inverse()')
		return self

	def getInversed(self):
		_n.ldprint('--> nkj.cs.quaternion.getInversed()')
		q = copy.deepcopy(self)
		q = self.__class__(q.inverse())  # self.inverse() では，np.quaternion.quaternion.inverse() が呼び出されるので，値の代入操作とキャストしておく．
		_n.ldprint('q: {0} ({1})'.format(q, type(q)))
		_n.ldprint('<-- nkj.cs.quaternion.getInversed()')
		return q

	@property
	def inversed(self):
		return self.getInversed()

	@property
	def inv(self):
		return self.getInversed()

	@property
	def i(self):
		return self.getInversed()

	# self.conjugate() は，numpy.quaternion で実装済であるが，nkj.cs.quaternion クラスで返したいのでオーバーライドする．

	def conjugate(self):
		_n.ldprint('--> nkj.cs.quaternion.conjugate()')
		nq = self.getNumpyQuaternion()  # numpy.quaternion クラス
		self.setNumpyQuaternion(nq.conjugate())
		_n.ldprint('self: {0} ({1})'.format(self, type(self)))
		_n.ldprint('<-- nkj.cs.quaternion.conjugate()')
		return self

	def getConjugated(self):
		q = copy.deepcopy(self)
		q = self.__class__(q.conjugate())  # self.conjugate() では，np.quaternion.quaternion.conjugate() が呼び出されるので，値の代入操作とキャストしておく．
		return q

	@property
	def conjugated(self):
		return self.getConjugated()

	@property
	def conj(self):
		return self.getConjugated()

	@property
	def j(self):
		return self.getConjugated()

	def slerp(self, second, w=0.5):
		return Slerp(self, second, w)

	# Components,  self.components は numpy.quaternion で実装済．(w, x, y, z) をnumpy.arrayで返す．

	def getComponents(self):
		return self.components

	def setComponents(self, x):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError('__ERROR__: Illegal data type.')
		if (np.array(x).ndim != 1):
			raise TypeError('__ERROR__: Illegal data type.')
		if (len(x) != 4):
			raise TypeError('__ERROR__: Illegal data type.')
		self.w = x[0]
		self.x = x[1]
		self.y = x[2]
		self.z = x[3]

	def Components(self, x=None):
		if (x is None):
			return self.getComponents()
		else:
			self.setComponents(x)

	# self.components は numpy.quaternion で実装済．

	@property
	def comps(self):
		return self.getComponents()

	@comps.setter
	def comps(self, x):
		self.Components(x)

	def getSerialized(self):
		return self.getComponents()

	@property
	def serialized(self):
		return self.getSerialized()

	def Serialize(self):
		return self.getSerialized()

	def serialize(self):
		return self.getSerialized()

	# Data string

	def getDataString(self, rowend=None):
		_n.ldprint('--> nkj.cs.quaternion.getDataString()')
		_n.ldprint('rowend: \'{}\''.format('CR' if (rowend == '\n') else rowend))
		s = ''
		for i in range(4):
			if (i != 0):
				s += ', '
			s += '{:21.12f}'.format(self.getComponent(i))
		_n.ldprint('s: \'{}\''.format(s))
		_n.ldprint('<-- nkj.cs.quaternion.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.cs.quaternion.setDataString()')
		_n.ldprint('datastr: \'{0}\' ({1})'.format(s, type(s)))
		if (len(s) == 0):
			_n.print_error('Null string s[{0}]: \'{1}\' ({2})'.format(len(s), s, type(s)))
			raise ValueError('__ERROR__: Null input.')
		if (s[-1] == '\n'):
			s = s[:-1]
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		s = s.replace('\n', ', ').replace('(', '').replace(')', '').split(',')
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		data = list(map(float, s))
		_n.ldprint('list[{0}]: {1} ({2})'.format(len(data), data, type(data)))
		if (len(data) != 4):
			raise TypeError('__ERROR__: Illegal data type.')
		self.set(data)
		_n.ldprint('<-- nkj.cs.quaternion.setDataString()')

	def DataString(self, s=None, rowend=''):
		if (s is None):
			return self.getDataString(rowend)
		else:
			self.setDataString(s)

	def getDataStr(self, rowend=''):
		return self.getDataString(rowend)

	def setDataStr(self, s):
		self.setDataString(s)

	def DataStr(self, s=None, rowend=''):
		if (s is None):
			return self.getDataString(rowend)
		else:
			self.setDataString(s)

	@property
	def datastring(self):
		return self.getDataString()

	@datastring.setter
	def datastring(self, s):
		self.setDataString(s)

	@property
	def datastr(self):
		return self.getDataString()

	@datastr.setter
	def datastr(self, s):
		self.setDataString(s)

	@property
	def dstr(self):
		return self.getDataString()

	@dstr.setter
	def dstr(self, s):
		self.setDataString(s)

	@property
	def ds(self):
		return self.getDataString()

	@ds.setter
	def ds(self, s):
		self.setDataString(s)

	# Print

	def getPrintString(self, title=None, flag=None):
		s = ''
		if (title is not None):
			s += '{0}: '.format(title)
		
		s += '('
		s += '{:21.12f}'.format(self.getComponent(_NKJQUATERNION_REID))
		for i in range(3):
			if (i == 0):
				s += '; '
			else:
				s += ', '
			s += '{:21.12f}'.format(self.getComponent(_NKJQUATERNION_IMID + i))
		s += ')'
		return s

	def getPrintStr(self, title=None, flag=None):
		return self.getPrintString(title, flag)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None, flag=None):
		print(self.getPrintString(title, flag), flush=True)

	# Load, Save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataStr(f.read())

	def save(self, filename, rowend=None):
		_n.ldprint('--> nkj.cs.quaternion.save(\'{}\')'.format(filename))
		_n.ldprint('s: \'{}\''.format(self.getDataString(rowend)))
		_DATAEND = '\n'
		if (filename == '-'):
			print(self.getDataString(rowend) + _DATAEND, flush=True)
		else:
			with open(filename, 'w') as f:
				f.write(self.getDataString(rowend) + _DATAEND)
		_n.ldprint('<-- nkj.cs.quaternion.save()')

	# isinstance

	def isinstance(self, v):
		return is_quaternion(v)

	# isinstance

	def isinstance(self, v):
		return is_quat(v)

class quaternion(quaternion_cls):
	pass

class quat(quaternion):
	pass

def is_quaternion(x):
	return isinstance(x, quaternion_cls)

def is_quat(x):
	return is_quaternion(x)


class vec2list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.cs.vec2list'
	_componentclass = vec2

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.dataheader(_nl.DATAHEADER_INDEX_SINGLELINE)
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		raise Exception("__ERROR__: Not implemented")

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		self.clear()
		if (x is not None):
			if (len(x) == 0):
				return  # Do nothing
			elif (self.isinstance(x)):  # vec2list
				self.extend(x)
			elif (is_vec2(x)):          # vec2
				self.append(x)
			elif (isinstance(x, (list, tuple))):
				ndim = _nm.ndim(x)
				if (ndim == 3):
					if (is_vec2(x[0])):       # [vec2_1, vec2_2, ...]
						for c in x:
							self.append(c)
				elif (ndim == 2):         # [[1.0, 2.0], [3.0, 4.0], ...]
					for c in x:
						self.append(vec2(c))
				elif (ndim == 1):         # [1.0, 2.0]
					self.append(vec2(x))
				else:
					raise TypeError('__ERROR__: Illegal data type.')
			else:
				raise TypeError('__ERROR__: Illegal data type.')

	def append(self, x):
		_n.ldprint('--> nkj.cs.vec2list.append()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		ndim = _nm.ndim(x)
		_n.ldprint('x.ndim: {}'.format(ndim))
		if (ndim == 1):
			if (self.isinstance(x)):
				raise TypeError('__ERROR__: Illegal data type. list-type input.')
			elif (isinstance(x, (list, tuple, np.ndarray))):
				super().append(vec2(x))
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (ndim == 2):
			if (is_vec2(x)):
				super().append(vec2(x))
			elif (isinstance(x, (list, tuple, np.ndarray))):
				super().append(vec2(x))
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (ndim == 3):
			if (self.isinstance(x)):
				super().append(x)
			elif (isinstance(x, (list, tuple, np.ndarray))):
				for c in x:
					super().append(vec2(c))
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint('<-- nkj.cs.vec2list.append()')

	def getResidue(self, index):
		return self[index].residue if (_nm.is_inrange(index, 0, len(self) - 1)) else None

	def setResidue(self, index, x):
		if (_nm.is_inrange(index, 0, len(x) - 1)):
			self[index].residue = x
		else:
			raise ValueError('__ERROR__: Illegal index. NKJ-CS-05257.')

	def residue(self, index, x=None):
		if (x is None):
			return self.getResidue(index)
		else:
			self.setResidue(index, x)

	def getResidueList(self):
		reslist = []
		for c in self:
			reslist.append(c.residue)
		return reslist

	def getResidues(self):
		return self.getResidueList()

	@property
	def residuelist(self):
		return self.getResidueList()

	@property
	def residues(self):
		return self.getResidueList()

	def clear_residues(self):
		for c in self:
			c.clear_residue()

	def clear_res(self):
		self.clear_residue()

	def clearresidue(self):
		self.clear_residue()

	def clearres(self):
		self.clear_residue()

	def rmultiply(self, x):
		if (is_mat2x2(x) or is_mat2x3(x)):
			plen = len(self)
			plist = vec2list()
			for i in range(plen):
				plist.append(x @ self[i])
			return plist
		elif (isinstance(x, mat2list)):
			plen = len(self)
			if (plen != len(x)):
				raise Exception("__ERROR__: List sizes are different.")
			plist = vec2list()
			for i in range(plen):
				plist.append(x[i] @ self[i])
			return plist
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def getAveragePoint(self, flag=False):
		_n.ldprint('--> nkj.cs.vec2list.getAveragePoint()')
		if (len(self) == 0):
			return None
		avpt = vec2()
		for pt in self:
			avpt += pt
		avpt /= len(self)
		if (True):
			var = 0.0
			for pt in self:
				var += _nm.sq((pt - avpt).norm)
			var /= len(self)
			avpt.res = math.sqrt(var)
			_n.ldprint('residue: {:.6f}'.format(avpt.res))
		_n.ldprint('<-- nkj.cs.vec2list.getAveragePoint()')
		return avpt

	def getAverage(self, flag=False):
		return self.getAveragePoint(flag)

	@property
	def averagepoint(self):
		return self.getAveragePoint()

	@property
	def average(self):
		return self.getAveragePoint()

	@property
	def ave(self):
		return self.getAveragePoint()

	def getGravity(self, flag=True):
		return self.getAveragePoint(flag)

	@property
	def gravity(self):
		return self.getAveragePoint()

	def getCovarianceMatrix(self):
		_n.ldprint('--> nkj.cs.vec2list.getCovarianceMatrix()')
		avpt = self.getAveragePoint()
		cm = mat2x2()
		a_11 = a_12 = a_21 = a_22 = 0.0
		for pt in self:
			dx = pt.x - avpt.x
			dy = pt.y - avpt.y
			a_11 += dx * dx
			a_12 += dx * dy
			a_22 += dy * dy
		n = len(self)
		a_11 /= n
		a_12 /= n
		a_21 = a_12
		a_22 /= n
		cm[0][0] = a_11
		cm[0][1] = a_12
		cm[1][0] = a_21
		cm[1][1] = a_22
		_n.ldprint('<-- nkj.cs.vec2list.getCovarianceMatrix()')
		return cm

	@property
	def covariancematrix(self):
		return self.getCovarianceMatrix()

	@property
	def covmat(self):
		return self.getCovarianceMatrix()

	@property
	def covm(self):
		return self.getCovarianceMatrix()

	@property
	def cvm(self):
		return self.getCovarianceMatrix()

	def getRotationCenter(self):
		return vec2()

	@property
	def rotationcenter(self):
		return self.getRotationCenter()

	@property
	def rotcen(self):
		return self.getRotationCenter()

	@property
	def rc(self):
		return self.getRotationCenter()

	# isinstance

	def isinstance(self, x):
		return is_vec2list(x)

class vec2list(vec2list_cls):
	pass

class vec2s(vec2list):
	pass

class point2list(vec2list_cls):
	pass

class point2s(point2list):
	pass

def is_vec2list(x):
	return isinstance(x, vec2list_cls)

def is_vec2s(x):
	return is_vec2list(x)

def is_point2list(x):
	return is_vec2list(x)

def is_point2s(x):
	return is_vec2list(x)


class vec3list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.cs.vec3list'
	_componentclass = vec3

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.set(x)
		self.dataheader(_nl.DATAHEADER_INDEX_SINGLELINE)
		self.Sigma(_DEFAULT_SIGMA)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		return self.multiply(second)

	def __rmatmul__(self, first):
		return self.rmultiply(first)

	def set(self, x):
		_n.ldprint('--> nkj.cs.vec3list.set()')
		self.clear()
		if (x is not None):
			if (len(x) == 0):
				return  # Do nothing
			elif (self.isinstance(x)):  # vec3list
				self.extend(x)
			elif (is_vec3(x)):          # vec3
				self.append(x)
			elif (isinstance(x, (list, tuple))):
				ndim = _nm.ndim(x)
				if (is_vec3(x[0])):       # [vec3_1, vec3_2, ...]
					for c in x:
						self.append(c)
				elif (ndim == 2):         # [[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], ...]
					for c in x:
						self.append(vec3(c))
				elif (ndim == 1):         # [1.0, 2.0, 3.0]
					self.append(vec3(x))
				else:
					raise TypeError('__ERROR__: Illegal data type.')
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint('<-- nkj.cs.vec3list.set()')

	def append(self, x):
		_n.ldprint('--> nkj.cs.vec3list.append()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		ndim = _nm.ndim(x)
		_n.ldprint('x.ndim: {}'.format(ndim))
		if (ndim == 1):
			#
			# 1D {list, tuple, np.ndarray}
			#
			if (self.isinstance(x)):
				raise TypeError('__ERROR__: Illegal data type. list-type input.')
			elif (isinstance(x, (list, tuple, np.ndarray))):
				super().append(vec3(x))
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (ndim == 2):
			#
			# vec3 or 2D {list, tuple, np.ndarray}
			#
			if (is_vec3(x)):
				_n.ldprint2('-- vec3')
				super().append(vec3(x))
			elif (isinstance(x, (list, tuple, np.ndarray))):
				_n.ldprint2('-- list')
				rows, columns = _nm.shape(x)
				_n.ldprint2('x.shape: ({0}, {1})'.format(rows, columns))
				if (columns == 3):    # row vector
					for pt in x:
						super().append(vec3(pt))
				elif (columns == 1):  # column vector
					super().append(vec3(x))
				else:
					raise TypeError('__ERROR__: Illegal data type. NKJ-CS-05060.')
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (ndim == 3):
			#
			# vec3list or 3D {list, tuple np.ndarray}
			#
			if (len(x) == 0):  # Null list
				raise TypeError('__ERROR__: Illegal data type.')
			if (self.isinstance(x)):  # vec3list
				super().extend(x)
			elif (isinstance(x, (list, tuple, np.ndarray))):
				if (self.isinstance(x[0])):
					for c in x:
						super().append(c)
				elif (isinstance(x[0], (list, tuple, np.ndarray))):
					for c in x:
						super().append(vec3(c))
				else:
					raise TypeError('__ERROR__: Illegal data type.')
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint('<-- nkj.cs.vec3list.append()')

	def multiply(self, second):
		raise Exception('__ERROR__: Not implemented.')

	def rmultiply(self, x):
		_n.ldprint('--> nkj.cs.vec3list.rmultiply()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		if (is_mat3x3(x) or is_mat3x4(x)):
			plist = vec3list()
			for pt in self:
				_n.ldprint('x:  {0} ({1})'.format(x, type(x)))
				_n.ldprint('pt: {0} ({1})'.format(pt, type(pt)))
				plist.append(x @ pt)
			return plist
		elif (isinstance(x, mat3list)):
			plen = len(self)
			if (plen != len(x)):
				raise Exception("__ERROR__: List sizes are different.")
			plist = vec3list()
			for i in range(plen):
				plist.append(x[i] @ self[i])
			return plist
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	def Sigma(self, x=None):  # Sigma of Gaussian distribution
		if (x is None):
			return self._sigma
		else:
			self._sigma = x
			return None

	@property
	def sigma(self):
		return self.Sigma()

	@sigma.setter
	def sigma(self, x):
		self.Sigma(x)

	def clearSigma(self):
		self.Sigma(None)

	def clear_sigma(self):
		self.clearSigma()

	def clearsigma(self):
		self.clearSigma()

	def VarianceThreshold(self, x=None):
		return self.Sigma(x)

	@property
	def variance_threshold(self):
		return self.VarianceThreshold()

	@variance_threshold.setter
	def variance_threshold(self, x):
		self.VarianceThreshold(x)

	@property
	def variancethreshold(self):
		return self.VarianceThreshold()

	@variancethreshold.setter
	def variancethreshold(self, x):
		self.VarianceThreshold(x)

	@property
	def varth(self):
		return self.VarianceThreshold(x)

	@varth.setter
	def varth(self, x):
		self.VarianceThreshold(x)

	def VarianceEliminationOn(self, x):
		self.Sigma(x)

	def VarianceEliminationOff(self):
		self.clearSigma()

	_MAXIMUM_ITERATIONS = 10

	def getAveragePoint(self, flag=False):
		avept = vec3()
		if (flag is False or self.sigma is None or len(self) < 5):
			for pt in self:
				avept += pt
			avept = avept / len(self)
		else:
			pts = copy.deepcopy(self)
			for niter in range(_MAXIMUM_ITERATIONS):
				sd = pts.getSD()
				newpts = point3list()
				oldavept = copy.deepcopy(avept)
				avept.set(_DEFAULT_VEC3)
				for pt in pts:
					if ((pt - avept).distance < self.sigma * sd):
						newpts.append(pt)
						avept += pt
				avept /= len(newpts)
				if (len(newpts) == len(pts)):
					break
				if (len(newpts) < 5):
					avept = oldavept
					break
				pts = newpts
			return avept
		return avept

	def getAverage(self, flag=False):
		return self.getAveragePoint(flag)

	@property
	def averagepoint(self):
		return self.getAveragePoint()

	@property
	def average(self):
		return self.getAveragePoint()

	@property
	def ave(self):
		return self.getAveragePoint()

	def getGravity(self, flag=True):
		return self.getAveragePoint(flag)

	@property
	def gravity(self):
		return self.getGravity()

	def getVariance(self):
		if (len(self) == 0):
			return 0.0
		avept = vec3()
		for pt in self:
			avept += pt
		avept = avept / len(self)
		var = 0.0
		for pt in self:
			var += _nm.sq(pt - avept)
		var /= len(self)
		return var

	@property
	def variance(self):
		return self.getVariance()

	@property
	def var(self):
		return self.getVariance()

	def getSD(self):
		return math.sqrt(self.getVariance())

	@property
	def sd(self):
		return self.getSD()

	def getCovarianceMatrix(self):
		_n.ldprint('--> nkj.cs.vec3list.getCovarianceMatrix()')
		avpt = self.getAveragePoint()
		cm = mat3x3()
		a_11 = a_12 = a_13 = a_21 = a_22 = a_23 = a_31 = a_32 = a_33 = 0.0
		for pt in self:
			dx = pt.x - avpt.x
			dy = pt.y - avpt.y
			dz = pt.z - avpt.z
			a_11 += dx * dx
			a_12 += dx * dy
			a_13 += dx * dz
			a_22 += dy * dy
			a_23 += dy * dz
			a_33 += dz * dz
		n = len(self)
		a_11 /= n
		a_12 /= n
		a_13 /= n
		a_21 = a_12
		a_22 /= n
		a_23 /= n
		a_31 = a_13
		a_32 = a_23
		a_33 /= n
		cm[0][0] = a_11
		cm[0][1] = a_12
		cm[0][2] = a_13
		cm[1][0] = a_21
		cm[1][1] = a_22
		cm[1][2] = a_23
		cm[2][0] = a_31
		cm[2][1] = a_32
		cm[2][2] = a_33
		_n.ldprint('<-- nkj.cs.vec3list.getCovarianceMatrix()')
		return cm

	@property
	def covariancematrix(self):
		return self.getCovarianceMatrix()

	@property
	def covmat(self):
		return self.getCovarianceMatrix()

	@property
	def covm(self):
		return self.getCovarianceMatrix()

	@property
	def cvm(self):
		return self.getCovarianceMatrix()

	def getMat3x4(self):
		m = mat3x4()
		m.by_points(self)
		return m

	@property
	def mat3x4(self):
		return self.getMat3x4()

	def getMatrix(sefl):
		return self.getMat3x4()

	@property
	def matrix(self):
		return self.getMatrix()

	@property
	def mat(self):
		return self.getMatrix()

	@property
	def m(self):
		return self.getMatrix()

	def getResidue(self, index):
		return self[index].residue if (_nm.is_inrange(index, 0, len(self) - 1)) else None

	def setResidue(self, index, x):
		if (_nm.is_inrange(index, 0, len(x) - 1)):
			self[index].residue = x
		else:
			raise ValueError('__ERROR__: Illegal index. NKJ-CS-05257.')

	def residue(self, index, x=None):
		if (x is None):
			return self.getResidue(index)
		else:
			self.setResidue(index, x)

	def getResidueList(self):
		reslist = []
		for c in self:
			reslist.append(c.residue)
		return reslist

	def getResidues(self):
		return self.getResidueList()

	@property
	def residuelist(self):
		return self.getResidueList()

	@property
	def residues(self):
		return self.getResidueList()

	def clear_residues(self):
		for c in self:
			c.clear_residue()

	def clear_res(self):
		self.clear_residue()

	def clearresidue(self):
		self.clear_residue()

	def clearres(self):
		self.clear_residue()

	def isinstance(self, x):
		return is_vec3list(x)

class vec3list(vec3list_cls):
	pass

class vec3s(vec3list):
	pass

class vecs(vec3list):
	pass

class point3list(vec3list_cls):
	pass

class point3s(point3list):
	pass

class points(point3list):
	pass

def is_vec3list(x):
	return isinstance(x, vec3list_cls)

def is_vec3s(x):
	return is_vec3list(x)

def is_point3list(x):
	return is_vec3list(x)

def is_point3s(x):
	return is_vec3list(x)

def is_points(x):
	return is_vec3list(x)


class mat2x3list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.cs.mat2x3list'
	_componentclass = mat2

	def __new__(cls, x=None):
		self = super().__new__(cls)
		self.set(x)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.set(x)
		self.dataheader(_nl.DATAHEADER_INDEX_MULTILINES)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def __matmul__(self, second):
		return self.matmul(second)

	def __rmatmul__(self, first):
		raise Exception("__ERROR__: Not implemented")

	def set(self, x):
		_n.ldprint('--> nkj.cs.mat2x3list.set()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		self.clear()
		if (x is not None):
			if (len(x) == 0):
				return  # Do nothing
			elif (self.isinstance(x)):
				self.extend(x)
			else:
				self.append(x)
		_n.ldprint('<-- nkj.cs.mat2x3list.set()')

	def append(self, x):
		_n.ldprint('--> nkj.cs.mat2x3list.append()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		if (x is None):
			pass  # Do nothing.
		ndim = _nm.ndim(x)
		if (ndim == 3):  # Add a list
			for c in x:
				if (is_mat2x3(c)):
					super().append(mat2x3(c))
				elif (isinstance(c, (list, tuple, np.ndarray))):
					super().append(mat2x3(c))
				else:
					raise TypeError("__ERROR__: Illegal data type. NKJ-CS-05689.")
		elif (ndim == 2):  # Add a component
			if (is_mat2x3(x)):
				super().append(mat2x3(x))
			elif (isinstance(x, (list, tuple, np.ndarray))):
				super().append(mat2x3(x))
			else:
				raise TypeError("__ERROR__: Illegal data type. NKJ-CS-05696.")
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-CS-05698.")
		_n.ldprint('<-- nkj.cs.mat2x3list.append()')

	def matmul(second):
		if (isinstance(second, mat2list)):
			mlen = len(self)
			if (mlen != len(second)):
				raise Exception("__ERROR__: List sizes are different.")
			mlist = mat2list()
			for i in range(mlen):
				mlist.append(self[i] @ second[i])
			return mlist
		elif (is_mat2x2(second) or is_mat2x3(second)):
			mlen = len(self)
			mlist = mat2list()
			for i in range(mlen):
				mlist.append(self[i] @ second)
			return mlist
		elif (is_point2(second)):
			mlen = len(self)
			plist = point2list()
			for i in range(mlen):
				plist.append(self[i] @ second)
			return plist
		elif (isinstance(second, point2list)):
			mlen = len(self)
			if (mlen != len(second)):
				raise Exception("__ERROR__: List sizes are different.")
			plist = point2list()
			for i in range(mlen):
				plist.append(self[i] @ second[i])
			return plist
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Data string

	def getDataString(self, rowend=', ', separator='\n'):
		_n.ldprint('--> nkj.cs.mat2x3list.getDataString()')
		_n.ldprint('rowend: \'{}\''.format('CR' if (rowend == '\n') else rowend))
		s = ''
		for k in range(len(self)):
			c = self[k]
			sss = self[k].getDataString(rowend='')
			_n.ldprint('sss: \'{}\''.format(sss))
			s += c.getDataString(rowend='')
			s += separator
		_n.ldprint('s: \'{}\''.format(s))
		_n.ldprint('<-- nkj.cs.mat2x3list.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.cs.mat2x3list.setDataString()')
		_n.ldprint('datastr: \'{0}\' ({1})'.format(s, type(s)))
		if (len(s) == 0):
			_n.print_error('Null string s[{0}]: \'{1}\' ({2})'.format(len(s), s, type(s)))
			raise ValueError('__ERROR__: Null input.')
		while (s[-1] == '\n'):
			s = s[:-1]
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		s = s.replace('\n', ', ').replace('(', '').replace(')', '').split(',')
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		data = list(map(float, s))
		_n.ldprint('list[{0}]: {1} ({2})'.format(len(data), data, type(data)))
		datalen = len(data)
		ii = 0
		self.clear()
		while (ii < datalen):
			c = mat2x3()
			for j in range(2):
				for i in range(3):
					c[j, i] = data[ii]
					ii += 1
			self.append(c)
		_n.ldprint('<-- nkj.cs.mat2x3list.setDataString()')

	# isinstance

	def isinstance(self, x):
		return is_mat2x3list(x)

class mat2x3list(mat2x3list_cls):
	pass

class mat2x3s(mat2x3list):
	pass

class mat2list(mat2x3list_cls):
	pass

class mat2s(mat2list):
	pass

def is_mat2x3list(x):
	return isinstance(x, mat2x3list_cls)

def is_mat2x3s(x):
	return is_mat2x3list(x)

def is_mat2list(x):
	return is_mat2x3list(x)

def is_mat2s(x):
	return is_mat2x3list(x)


class mat3x4list_cls(_nl.uniclasslist_cls):
	_classname = 'nkj.cs.mat3x4list'
	_componentclass = mat3x4

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.setComponentClass(self.componentclass)
		self.dataheader(_nl.DATAHEADER_INDEX_MULTILINES)
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	def __matmul__(self, second):
		return self.matmul(second)

	def __rmatmul__(self, first):
		raise Exception("__ERROR__: Not implemented")

	def set(self, x):
		_n.ldprint('--> nkj.cs.mat3x4list.set()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		self.clear()
		if (x is not None):
			if (len(x) == 0):
				return  # Do nothing
			elif (self.isinstance(x)):            # mat3x4list
				_n.ldprint('@-- mat3x4list')
				self.extend(x)
			elif (is_mat3x4(x)):                  # mat3x4
				self.append(x)
			elif (isinstance(x, (list, tuple))):
				ndim = _nm.ndim(x)
				_n.ldprint('ndim: {}'.format(ndim))
				if (ndim == 3):
					_n.ldprint('@-- [mat3x4_1, mat3x4_2, ...]')
					for c in x:
						self.append(c)
				elif (ndim == 2):
					self.append(x)
				else:
					raise TypeError('__ERROR__: Illegal data type.')
			else:
				_n.ldprint('x: {0} ({1})'.format(x, type(x)))
				raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint('<-- nkj.cs.mat3x4list.set()')

	def append(self, x):
		_n.ldprint('--> nkj.cs.mat3x4list.append()')
		_n.ldprint('x: {0} ({1})'.format(x, type(x)))
		ndim = _nm.ndim(x)
		_n.ldprint('x.ndim: {}'.format(ndim))
		if (ndim == 1):
			if (self.isinstance(x)):
				raise TypeError('__ERROR__: Illegal data type. list-type input.')
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (ndim == 2):
			if (is_mat3x4(x)):                                # mat3x4
				super().append(x)
			elif (isinstance(x, (list, tuple, np.ndarray))):  # array = [[1.0, 2.0, 3.0, 4.0], ...]
				super().append(mat3x4(x))
			else:
				raise TypeError('__ERROR__: Illegal data type.')
		elif (ndim == 3):
			if (self.isinstance(x)):
				raise TypeError('__ERROR__: Illegal data type. List-type input.')
			for c in x:
				if (is_mat3x4(c)):                                # [mat3x4_1, mat3x4_2, ...]
					super().append(c)
				elif (isinstance(x, (list, tuple, np.ndarray))):  # [array_1, array_2, ...] = [[[1.0, 2.0, 3.0, 4.0], ...], [[1.0, 2.0, 3.0, 4.0], ...]]
					super().append(mat3x4(c))
				else:
					raise TypeError('__ERROR__: Illegal data type.')
		_n.ldprint('<-- nkj.cs.mat3x4list.append()')

	def matmul(x):
		if (isinstance(x, mat3list)):
			mlen = len(self)
			if (mlen != len(x)):
				raise Exception("__ERROR__: List sizes are different.")
			mlist = mat3x4list()
			for i in range(mlen):
				mlist.append(self[i] @ x[i])
			return mlist
		elif (is_mat3x3(x) or is_mat3x4(x)):
			mlen = len(self)
			mlist = mat3x4list()
			for i in range(mlen):
				mlist.append(self[i] @ x)
			return mlist
		elif (is_point3(x)):
			mlen = len(self)
			plist = point3list()
			for i in range(mlen):
				plist.append(self[i] @ x)
			return plist
		elif (isinstance(x, point3list)):
			mlen = len(self)
			if (mlen != len(x)):
				raise Exception("__ERROR__: List sizes are different.")
			plist = point3list()
			for i in range(mlen):
				plist.append(self[i] @ x[i])
			return plist
		else:
			raise TypeError("__ERROR__: Illegal data type.")

	# Data string

	def getDataString(self, rowend=', ', separator='\n'):
		_n.ldprint('--> nkj.cs.mat3x4list.getDataString()')
		_n.ldprint('rowend: \'{}\''.format('CR' if (rowend == '\n') else rowend))
		s = ''
		for k in range(len(self)):
			c = self[k]
			sss = self[k].getDataString(rowend='')
			_n.ldprint('sss: \'{}\''.format(sss))
			s += c.getDataString(rowend='')
			s += separator
		_n.ldprint('s: \'{}\''.format(s))
		_n.ldprint('<-- nkj.cs.mat3x4list.getDataString()')
		return s

	def setDataString(self, s):
		_n.ldprint('--> nkj.cs.mat3x4list.setDataString()')
		_n.ldprint('datastr: \'{0}\' ({1})'.format(s, type(s)))
		if (len(s) == 0):
			_n.print_error('Null string s[{0}]: \'{1}\' ({2})'.format(len(s), s, type(s)))
			raise ValueError('__ERROR__: Null input.')
		while (s[-1] == '\n'):
			s = s[:-1]
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		s = s.replace('\n', ', ').replace('(', '').replace(')', '').split(',')
		_n.ldprint('datastr: {0} ({1})'.format(s, type(s)))
		data = list(map(float, s))
		_n.ldprint('list[{0}]: {1} ({2})'.format(len(data), data, type(data)))
		datalen = len(data)
		ii = 0
		self.clear()
		while (ii < datalen):
			c = mat3x4()
			for j in range(3):
				for i in range(4):
					c[j, i] = data[ii]
					ii += 1
			self.append(c)
		_n.ldprint('<-- nkj.cs.mat3x4list.setDataString()')

	# isinstance

	def isinstance(self, x):
		return is_mat3x4list(x)

class mat3x4list(mat3x4list_cls):
	pass

class mat3x4s(mat3x4list_cls):
	pass

class mat3list(mat3x4list_cls):
	pass

class mat3s(mat3x4list_cls):
	pass

class cs3list(mat3x4list_cls):
	pass

class cs3s(mat3x4list_cls):
	pass

class cslist(mat3x4list_cls):
	pass

class cses(mat3x4list_cls):
	pass

class coordinates(mat3x4list_cls):
	pass

def is_mat3x4list(x):
	return isinstance(x, mat3x4list_cls)

def is_mat3x4s(x):
	return is_mat3x4list(x)

def is_mat3list(x):
	return is_mat3x4list(x)

def is_mat3s(x):
	return is_mat3x4list(x)

def is_cs3list(x):
	return is_mat3x4list(x)

def is_cs3s(x):
	return is_mat3x4list(x)

def is_cslist(x):
	return is_mat3x4list(x)

def is_cses(x):
	return is_mat3x4list(x)

def is_coordinates(x):
	return is_mat3x4list(x)


#-- Constants

XAXISINDEX = _XAXISINDEX
YAXISINDEX = _YAXISINDEX
ZAXISINDEX = _ZAXISINDEX

XAXIS2 = vec2(_XAXIS2)
YAXIS2 = vec2(_YAXIS2)
XAXIS3 = vec3(_XAXIS3)
YAXIS3 = vec3(_YAXIS3)
ZAXIS3 = vec3(_ZAXIS3)

DEFAULT_VEC2 = vec2(_DEFAULT_VEC2)
DEFAULT_VEC3 = vec3(_DEFAULT_VEC3)
DEFAULT_VEC4 = vec4(_DEFAULT_VEC4)
DEFAULT_MAT2X2 = mat2x2(_DEFAULT_MAT2X2)
DEFAULT_MAT2X3 = mat2x3(_DEFAULT_MAT2X3)
DEFAULT_MAT3X3 = mat3x3(_DEFAULT_MAT3X3)
DEFAULT_MAT3X4 = mat3x4(_DEFAULT_MAT3X4)
DEFAULT_MAT4X4 = mat4x4(_DEFAULT_MAT4X4)

DEFAULT_XAXIS2 = vec2(_DEFAULT_XAXIS2)
DEFAULT_YAXIS2 = vec2(_DEFAULT_YAXIS2)
DEFAULT_XAXIS3 = vec3(_DEFAULT_XAXIS3)
DEFAULT_YAXIS3 = vec3(_DEFAULT_YAXIS3)
DEFAULT_ZAXIS3 = vec3(_DEFAULT_ZAXIS3)

DEFAULT_RMAT2 = rmat2(_DEFAULT_RMAT2)
DEFAULT_RMAT3 = rmat3(_DEFAULT_RMAT3)
DEFAULT_MAT2  = mat2(_DEFAULT_MAT2)
DEFAULT_MAT3  = mat3(_DEFAULT_MAT3)

DEFAULT_CSV2 = csv2(_DEFAULT_CSV2)
DEFAULT_CSV3 = csv3(_DEFAULT_CSV3)
DEFAULT_CSM2 = csm2(_DEFAULT_CSM2)
DEFAULT_CSM3 = csm3(_DEFAULT_CSM3)
DEFAULT_CS2 = DEFAULT_CSM2
DEFAULT_CS3 = DEFAULT_CSM3
DEFAULT_POINT2 = point2(_DEFAULT_POINT2)
DEFAULT_POINT3 = point3(_DEFAULT_POINT3)

DEFAULT_SCIPYQUATERNION =  scipyquaternion(_DEFAULT_SCIPYQUATERNION)
DEFAULT_SCIPYQUAT =        DEFAULT_SCIPYQUATERNION
DEFAULT_SQUATERNION =      DEFAULT_SCIPYQUATERNION
DEFAULT_SQUAT =            DEFAULT_SCIPYQUATERNION
DEFAULT_NUMPYQUATERNION =  np.quaternion(_DEFAULT_NUMPYQUATERNION[0], _DEFAULT_NUMPYQUATERNION[1], _DEFAULT_NUMPYQUATERNION[2], _DEFAULT_NUMPYQUATERNION[3])
DEFAULT_NUMPYQUAT =        DEFAULT_NUMPYQUATERNION
DEFAULT_NQUATERNION =      DEFAULT_NUMPYQUATERNION
DEFAULT_NQUAT =            DEFAULT_NUMPYQUATERNION
DEFAULT_MATHEXQUATERNION = _DEFAULT_MATHEXQUATERNION  # list[4]
DEFAULT_MATHEXQUAT =       DEFAULT_MATHEXQUATERNION
DEFAULT_QUATERNION =       quaternion(_DEFAULT_QUATERNION)
DEFAULT_QUAT =             DEFAULT_QUATERNION


#-- Functions

def toVec3(v2):
	if (is_vec2(v2)):
		return vec3([v2.x, v2.y, 0.0])
	elif (is_vec2list(v2)):
		list = vec3list()
		for c in v2:
			list.append(toVec3(c))
		return list
	else:
		raise TypeError('__ERROR__: Not supported.')

def to_vec3(v2):
	return toVec3(v2)

def to_point3(v2):
	return toVec3(v2)

def toVec2(v3):
	if (is_vec3(v3)):
		if (not is_ineps(v3.z)):
			v3.print('vec3')
			raise ValueError('__ERROR__: Could not projected.')
		return vec2([v2.x, v2.y, 0.0])
	elif (is_vec3list(v3)):
		list = vec2list()
		for c in v3:
			list.append(toVec2(c))
		return list
	else:
		raise TypeError('__ERROR__: Not supported.')

def to_vec2(v3):
	return toVec2(v3)

def to_point2(v3):
	return toVec2(v3)

def Normalize(v):
	return v.normalized

def Lerp(p1, p2, w=0.5):
	if (is_vec3(p1) and is_vec3(p2)):
		return (1.0 - w) * p1 + w * p2
	elif (is_vec3h(p1) and is_vec3h(p2)):
		return (1.0 - w) * p1.ih + w * p2.ih
	else:
		raise TypeError("__ERROR__: Illegal data type.")

def Slerp(q1, q2, w=0.5):
	if (is_quaternion(q1) and is_quaternion(q2)):
		return quaternion((1.0 - w) * q1 + w * q2)
	elif (is_scipyquaternion(q1) and is_scipyquaternion(q2)):
		return scipyquaternion((1.0 - w) * q1 + w * q2)
	elif (is_numpyquaternion(q1) and is_numpyquaternion(q2)):
		return np.quaternion((1.0 - w) * q1 + w * q2)
	else:
		raise TypeError("__ERROR__: Illegal data type.")

def Angle(v1, v2):
	if (is_vec2(v1)):
		if (is_vec2(v2)):
			angle = v1.getAngle(v2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	elif (is_vec3(v1)):
		if (is_vec3(v2)):
			angle = v1.getAngle(v2)
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	else:
		raise Exception('__ERROR__: Not supported.')
	return angle

def Rad(v1, v2):
	return Angle(v1, v2)

def Deg(v1, v2):
	return _nm.rad2deg(Angle(v1, v2))

def VectorRotationMat3x4(v1, v2):
	v1 = copy.deepcopy(v1).normalized
	v2 = copy.deepcopy(v2).normalized
	c = v1 ^ v2
	sv = v1 * v2
	s = sv.norm
	vector = sv.normalized
	thetah = math.atan2(s, c) / 2.0
	ch = math.cos(thetah)
	sh = math.sin(thetah)
	ivec = sh * vector
	m = mat3x4()
	m.setNumpyQuaternion(np.quaternion(ch, ivec.x, ivec.y, ivec.z))  # np.quaternion(w, x, y, z)
	m.orthonormalize()
	return m

def VectorRotationMatrix(v1, v2):
	return VectorRotationMat3x4(v1, v2)

def VectorMat3x4(v1, v2):
	return self.VectorRotationMat3x4(v1, v2)

def VectorMatrix(v1, v2):
	return VectorMat3x4(v1, v2)

def RotationalVector(m1, m2):
	if (is_mat3x3(m1) or is_mat3x4(m1)):
		if (is_mat3x3(m2) or is_mat3x4(m2)):
			#
			# T = T_1 T_{1to2} T_1.i
			#   = T_1 (T_1.i T_2) T_1.i  (Because T_{1to2} = T_1.i T_2)
			#   = T_2 T_1.i
			#
			q = quaternion(m2.numpyquaternion * m1.numpyquaternion.inverse())
			rotvec = vec3(q.imag)
			c = q.real
			s = rotvec.norm
			angle = math.atan2(s, c)
			rotvec.normalize()
			rotvec *= angle
		else:
			raise TypeError('__ERROR__: Illegal data type.')
	else:
		raise Exception('__ERROR__: Not supported.')
	return rotvec

def RotationVector(m1, m2):
	return RotationVector(m1, m2)


#-- Lib main -----------------------------------------------------------------------------

if (__name__ == '__main__'):
	_LIB_DEBUGLEVEL = 0

	if (False):
		print("===== nkj")
		import nkj.str as ns
		_n.lib_debuglevel(_LIB_DEBUGLEVEL)
		print('LIB_DEBUGLEVEL: {0}'.format(_n.lib_debuglevel()))

	if (False):
		print("\n===== vectors", end='')
		if (True):
			print('\n-- vec2')
			v2 = vec2()
			v2.print("vec2")
			v2 = vec2([1.0, 2.0])
			v2.print("vec2")
			v2 = vec2(vec2([1.0, 2.0]))
			v2.print("vec2")
			print("({0}, {1})".format(v2[0], v2[1]))
			print("({0}, {1})".format(v2.x, v2.y))
			print("vec2.dim: {}".format(v2.dim))
			v2.h.print("vec2.h")
			v2.inversed.print("vec2.i")
			v2.transposed.print("vec2.t")
			v2.normalized.print("vec2.n")
			v2_2 = v2
			v2_2.print("vec2_copied")
			print("innter product: {}".format(v2 ^ v2_2))
			print("cross product:  {}".format(v2 * v2_2))

		if (True):
			print('\n-- vec2h')
			v2h = vec2h()
			v2h.print("vec2.h")

		if (True):
			print('\n-- vec3')
			v3 = vec3()
			v3.print("vec3")
			v3 = vec3([1.0, 2.0, 3.0])
			v3.print("vec3")
			v3 = vec3(vec3([1.0, 2.0, 3.0]))
			v3.print("vec3")
			print("({0}, {1}, {2})".format(v3[0], v3[1], v3[2]))
			print("({0}, {1}, {2})".format(v3.x, v3.y, v3.z))
			print("vec3.dim: {}".format(v3.dim))
			v3.h.print("vec3.h")
			v3.inversed.print("vec3.i")
			v3.transposed.print("vec3.t")
			v3.normalized.print("vec3.n")
			v3_2 = v3
			v3_2.print("vec3_copied")
			print("innter product: {}".format(v3 ^ v3_2))
			(v3 * v3_2).print("cross product")
			v3 = vec3([1.0, 2.0, 3.0])
			v3_2 = vec3([2.0, 1.0, 3.0])
			v3.print("v3")
			v3_2.print("v3_2")
			(v3 * v3_2).print("cross product")

		if (True):
			print('\n-- vec3h')
			v3h = vec3h()
			v3h.print("vec3.h")

		if (True):
			print('\n-- vec4')
			v4 = vec4()
			v4.print("vec4")
			v4 = vec4([1.0, 2.0, 3.0, 4.0])
			v4.print("vec4")
			v4 = vec4(vec4([1.0, 2.0, 3.0, 4.0]))
			v4.print("vec4")
			print("({0}, {1}, {2}, {3})".format(v4[0], v4[1], v4[2], v4[3]))
			print("({0}, {1}, {2}, {3})".format(v4.x, v4.y, v4.z, v4.w))
			print("vec4.dim: {}".format(v4.dim))
			print("vec4.h:   {}".format(v4.h))
			v4.inversed.print("vec4.i")
			v4.transposed.print("vec4.t")
			v4.normalized.print("vec4.n")
			v4_2 = v4
			v4_2.print("vec4_copied")

	if (False):
		print("\n===== matrices", end='')
		if (True):
			print('\n-- mat2x2')
			m = mat2x2()
			m = mat2x2([[1.0, 2.0], [3.0, 4.0]])
			m.print("mat2x2")
			m.column2(0).print("mat2x2.column2(0)")
			m.column2(1).print("mat2x2.column2(1)")
			m.column(0).print("mat2x2.column(0)")
			m.column(1).print("mat2x2.column(1)")

		if (True):
			print('\n-- mat3x3')
			m = mat3x3()
			m = mat3x3([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])
			m.print("mat3x3")
			m.column2(0).print("mat3x3.column2(0)")
			m.column2(1).print("mat3x3.column2(1)")
			m.column2(2).print("mat3x3.column2(2)")
			m.column3(0).print("mat3x3.column3(0)")
			m.column3(1).print("mat3x3.column3(1)")
			m.column3(2).print("mat3x3.column3(2)")
			m.column(0).print("mat3x3.column(0)")
			m.column(1).print("mat3x3.column(1)")
			m.column(2).print("mat3x3.column(2)")

		if (True):
			print('\n-- mat4x4')
			m = mat4x4()
			m = mat4x4([[1.0, 2.0, 3.0, 4.0], [5.0, 6.0, 7.0, 8.0], [9.0, 10.0, 11.0, 12.0], [13.0, 14.0, 15.0, 16.0]])
			m.print("mat4x4")
			m.column3(0).print("mat4x4.column3(0)")
			m.column3(1).print("mat4x4.column3(1)")
			m.column3(2).print("mat4x4.column3(2)")
			m.column3(3).print("mat4x4.column3(3)")
			m.column(0).print("mat4x4.column(0)")
			m.column(1).print("mat4x4.column(1)")
			m.column(2).print("mat4x4.column(2)")
			m.column(3).print("mat4x4.column(3)")

		if (True):
			print('\n-- mat2x3')
			m = mat2x3()
			m = mat2x3([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
			m.print("mat2x3")
			m.column2(0).print("mat2x3.column2(0)")
			m.column2(1).print("mat2x3.column2(1)")
			m.column2(2).print("mat2x3.column2(2)")
			m.column(0).print("mat2x3.column(0)")
			m.column(1).print("mat2x3.column(1)")
			m.column(2).print("mat2x3.column(2)")

		if (True):
			print('\n-- mat3x4')
			m = mat3x4()
			m = mat3x4([[1.0, 2.0, 3.0, 4.0], [5.0, 6.0, 7.0, 8.0], [9.0, 10.0, 11.0, 12.0]])
			m.print("mat3x4")
			m.column3(0).print("mat3x4.column3(0)")
			m.column3(1).print("mat3x4.column3(1)")
			m.column3(2).print("mat3x4.column3(2)")
			m.column3(3).print("mat3x4.column3(3)")
			m.column(0).print("mat3x4.column(0)")
			m.column(1).print("mat3x4.column(1)")
			m.column(2).print("mat3x4.column(2)")
			m.column(3).print("mat3x4.column(3)")

	if (False):
		print("\n===== point/matrix list", end='')
		if (True):
			print("\n-- point2list")
			plist = point2list()
			plist.print("point2list")
			plist = point2list(point2list([0.0, 0.0]))
			plist.print("point2list")
			plist = point2list([vec2([1.0, 2.0]), vec2([3.0, 4.0])])
			plist.print("point2list")
			plist = point2list([[1.0, 2.0], [3.0, 4.0]])
			plist.print("point2list")
			plist = point2list(vec2([1.0, 2.0]))
			plist.print("point2list")
			plist = point2list([0.0, 0.0])
			plist.print("point2list")
			plist += point2list([1.0, 2.0])
			plist.print("point2list")
			print("component class:     {}".format(plist.componentclass))
			print("component classname: {}".format(_ns.strbracket(_n.classname(plist.componentclass))))
			plist.save("./test.data/test.p2")

		if (True):
			print("\n-- point3list")
			plist = point3list()
			plist.print("point3list")
			plist = point3list(point3list([0.0, 0.0, 0.0]))
			plist.print("point3list")
			plist = point3list([vec3([1.0, 2.0, 3.0]), vec3([4.0, 5.0, 6.0])])
			plist.print("point3list")
			plist = point3list([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
			plist.print("point3list")
			plist = point3list(vec3([1.0, 2.0, 3.0]))
			plist.print("point3list")
			plist = point3list([0.0, 0.0, 0.0])
			plist.print("point3list")
			plist += point3list([1.0, 2.0, 3.0])
			plist.print("point3list")
			print("component class:     {}".format(plist.componentclass))
			print("component classname: {}".format(_ns.strbracket(_n.classname(plist.componentclass))))
			plist.save("./test.data/test.p3")
			plist.average.print("average point")
			plist.covmat.print("covariance matrix")

		if (True):
			print("\n-- mat3x4list")
			mlist = mat3x4list()
			mlist.print("mat3x4list")
			mlist = mat3x4list([mat3x4([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]])])  # Generate with a list of mat3x4
			mlist.append([[[1.0, 2.0, 3.0, 10.0], [4.0, 5.0, 6.0, 20.0], [7.0, 8.0, 9.0, 30.0]]])             # Add a list of mat3x4 array
			mlist.print("mat3x4list")
			mlist = mat3x4list(mat3x4([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]]))  # Generate with a mat3x4
			mlist.append([[1.0, 2.0, 3.0, 10.0], [4.0, 5.0, 6.0, 20.0], [7.0, 8.0, 9.0, 30.0]])             # Add a mat3x4 array
			mlist.print("mat3x4list")
			print("component class:     {}".format(mlist.componentclass))
			print("component classname: {}".format(_ns.strbracket(_n.classname(mlist.componentclass))))
			_ROWEND = '\n'
			_DATASEPARATOR = '--\n'
			mlist.save("./test.data/test.m3", rowend=_ROWEND, separator=_DATASEPARATOR)
			mlist = mat3x4list([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]])  # Generate with a mat3x4 array
			mlist.append([[1.1, 2.1, 3.1, 10.1], [4.1, 5.1, 6.1, 20.1], [7.1, 8.1, 9.1, 30.1]])     # Add a mat3x4 array
			mlist.print("mat3x4list")

	if (False):
		print("\n===== mat3x4 (from points)")
		pts = point3list([0.0, 0.0, 0.0])
		pts.append([1.0, 2.0, 0.0])
		pts.append([3.0, 4.0, 0.0])
		pts.print("points")
		m = mat3x4()
		"""
		m.setByPoints(pts)
		m.setFromPoints(pts)
		m.by_points = pts
		"""
		m.from_points = pts
		m.print("matrix (from points)")

	if (True):
		print("\n===== linear operations", end='')
		if (True):
			print('\n-- 3D operations')
			v = vec3([1.0, 2.0, 3.0])
			v.print("vec3")
			print('vec3: {0} ({1})'.format(v, type(v)))
			print("vec3: ({0}, {1}, {2})".format(v[0], v[1], v[2]))
			print("vec3: ({0}, {1}, {2})".format(v.x, v.y, v.z))
			m = mat3x4()
			m.rotatez(_nm.deg2rad(45.0))
			m.translate([1.0, 2.0, 3.0])
			v.print("vec3 (original)  ")
			m.print("mat3x4")
			v = m @ v
			v.print("vec3 (translated)")

	if (False):
		print("\n===== axis matrices")
		v = vec3([1.0, 0.0, .0])
		v.print('vector')
		v.xaxism.print('x-axis matrix')
		v.yaxism.print('y-axis matrix')
		v.zaxism.print('z-axis matrix')

	if (False):
		print("\n===== hexagon verts")
		pt = vec2()
		pts = pt.origin_and_hexagonverts
		pts.print('Hexagon verts')
