#
# [name] nkj.cv.py
# [exec] python cv.py
# [reference] https://qiita.com/teraken_/items/c8ac4c0ff60d8856a15c
#
# Written by Yoshikazu NAKAJIMA
#

DEBUGLEVEL = 2

import os
import sys
import cv2 as cv
import json
import sys
import platform
import nkj as _n
import nkj.str as _ns
import nkj.math as _nm

sys.path.append(os.path.abspath(".."))

"""
OpenCV camera calibration で使用するデータの型について（参照：https://kamino.hatenablog.com/entry/opencv_calibrate_camera#sec4）

objectPoint:  vector<Point3f>         -> np.array([[x1, y1, z1], [x2, y2, z2], ...], dtype=np.float32)
objectPoints: vector<vector<Point3f>> -> [np.array([[x1, y1, z1], [x2, y2, z2], ...], dtype=np.float32)]  # モデルの姿勢ごとにnp.arrayにまとめてそれをリストにしている。
                                         [[np.array([x, y, z], dtype=np.float32)]] や、np.array([[[x1, y, z1], [x2, y2, z2], ...], ...], dtype=np.float32) では動作し"ない"ので注意。
imagePoint:   vector<Point2f>         -> np.array([[x1, y1], [x2, y2], ...], dtype=np.float32)
imagePoints:  vector<vector<Point2f>> -> [np.array([[x1, y1], [x2, y2], ...], dtype=np.float32)]  # モデルの姿勢ごとにnp.arrayにまとめてそれをリストにしている。
                                         [[np.array([x, y, z], dtype=np.float32)]] や、np.array([[[x1, y, z1], [x2, y2, z2], ...], ...], dtype=np.float32) では動作し"ない"ので注意。
"""

class window():
	#-- class variables
	_classname = "nkj.cv.window"

	def __init__(self):
		#-- instance variables
		self._pt = []
		self._m = 0
		self._n = 0
		self._p = 0

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls._classname

	def mouseevent_callback(self, event, x, y, flags, param):
		if (event == cv.EVENT_LBUTTONDOWN):
			self._m = self._n
			self._pt.append((x, y))
			self._n = self._n + 1
			self._m = self._m + 1
			_n.ldprint(["pt[", str(self._n), "]: ", str(self._pt)])
		if (event == cv.EVENT_RBUTTONDOWN and self._n > 0):
			self._pt.pop(self._m - 1)
			self._m = self._m - 1
			self._n = self._n - 1
			self._p = self._p + 1
			_n.ldprint(["pt[", str(self._n), "]: ", str(self._pt)])

	def clearPoints(self):
		self._pt.clear()
		self._m = 0
		self._n = 0

	def getPoints(self):
		return self._pt

	@property
	def points(self):
		return self.getPoints()

	def getPoint(self, index):
		return self._pt[index]

	def point(self, index):
		return self.getPoint(index)

	def getM(self):
		return self._m

	@property
	def m(self):
		return self.getM()

	def getN(self):
		return self._n

	@property
	def n(self):
		return self.getN()

	def getP(self):
		return self._p

	@property
	def p(self):
		return self.getP()

#-- main

if __name__ == '__main__':

	WINDOW_TITLE = "image"

	_n.checkPythonVersion()

	win = window()

	cap = cv.VideoCapture(0) # カメラを設定
	cv.namedWindow(WINDOW_TITLE, cv.WINDOW_GUI_NORMAL) # ウィンドウの設定

	cv.setMouseCallback(WINDOW_TITLE, win.mouseevent_callback) # マウスイベントの設定

	print(">>> start!! (Press ESC-key to exit)")

	while True:
		ret, frame = cap.read()

		if (win.getN() >= 1):
			cv.drawMarker(frame, win.getPoint(win.getM() - 1), (0, 255, 255), markerType=cv.MARKER_TILTED_CROSS, markerSize=15)

		if (win.getN() >= 2):
			for i in range(1, win.getN()):
				cv.line(frame, win.getPoint(i - 1), win.getPoint(i), (0, 255, 255), 1)

		cv.imshow(WINDOW_TITLE, frame)

		k = cv.waitKey(1)

		if (k == 27):
			print(">>> Exit")
			break
		elif (k == ord("c")):
			print(">>> Clear coordinates.")
			win.clearPoints()
		elif (k == ord("s")):
			pirnt(">>> Save image and coordinates.")
			str = "patient(no:03}.png".format(no = win.getP())
			cv.imwrite(str, frame)
			with open("painted.json", "w") as f:
				json.dump(getPoints(), f, indent=4)

	cap.release()
	cv.destroyAllWindows()

