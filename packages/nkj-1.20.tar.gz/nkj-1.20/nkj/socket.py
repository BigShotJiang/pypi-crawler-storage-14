#
# [name] nkj.socket.py
# [exec] python -m nkj.scoket
#
# Written by Yoshikazu NAKAJIMA
#
import socket
import atexit
import nkj as _n
import nkj.str as _ns

_DEFAULT_HOSTNAME =   None
_DEFAULT_HOSTADDR =  '127.0.0.1'  # local host
_DEFAULT_PORT =       5000
_DEFAULT_BUFSIZE =    4096
_DEFAULT_SOCKET =     None

# Classes

class socket_cls():
	_classname = 'nkj.socket.socket'
	_addressfamily = None
	_type =          None

	def __new__(cls):
		self = super().__new__(cls)
		self._hostname = _DEFAULT_HOSTNAME
		self._hostaddr = _DEFAULT_HOSTADDR
		self._port =     _DEFAULT_PORT
		self._bufsize =  _DEFAULT_BUFSIZE
		self._socket =   _DEFAULT_SOCKET
		return self

	def __init__(self):
		super().__init__()

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@classmethod
	def getSocketAddressFamily(cls):
		return cls._addressfamily

	@classmethod
	def getAddressFamily(cls):
		return cls.getSocketAddressFamily()

	@classmethod
	@property
	def socketaddressfamily(cls):
		return cls.getSocketAddressFamily()

	@classmethod
	@property
	def addressfamily(cls):
		return cls.getSocketAddressFamily()

	@classmethod
	@property
	def family(cls):
		return cls.getSocketAddressFamily()

	@classmethod
	def getSocketType(cls):
		return cls._type

	@classmethod
	def getType(cls):
		return cls.getSocketType()

	@classmethod
	@property
	def sockettype(cls):
		return cls.getSocketType()

	@classmethod
	@property
	def socktype(cls):
		return cls.getSocketType()

	@classmethod
	@property
	def type(cls):
		return cls.getSocketType()

	def getSocket(self):
		return self._socket

	def setSocket(self, x):
		self._socket = x

	def Socket(self, x=None):
		if (x is None):
			return self.getSocket()
		else:
			self.setSocket(x)

	@property
	def socket(self):
		return self.getSocket()

	@socket.setter
	def socket(self, x):
		self.setSocket(x)

	@property
	def sock(self):
		return self.getSocket()

	@sock.setter
	def sock(self, x):
		self.setSocket(x)

	def getHostName(self):
		return self._hostname

	def setHostName(self, x):
		self._hostname = x
		self._hostaddr = socket.gethostbyname(self._hostname)

	def HostName(self, x=None):
		if (x is None):
			return self.getHostName()
		else:
			self.setHostName(x)

	def getHostname(self):
		return self.getHostName()

	def setHostname(self, x):
		self.setHostName(x)

	def Hostname(self, x=None):
		if (x is None):
			return self.getHostName()
		else:
			self.setHostName(x)

	@property
	def hostname(self):
		return self.getHostName()

	@hostname.setter
	def hostname(self, x):
		self.setHostName(x)

	def getHostAddress(self):
		return self._hostaddr

	def setHostAddress(self, x):
		self._hostaddr = x
		self._hostname = None

	def HostAddress(self, x=None):
		if (x is None):
			return self.getHostAddress()
		else:
			self.setHostAddress(x)

	def getHostAddr(self):
		return self.getHostAddress()

	def setHostAddr(self, x):
		self.setHostAddress(x)

	def HostAddr(self, x=None):
		if (x is None):
			return self.getHostAddress()
		else:
			self.setHostAddress(x)

	@property
	def hostaddress(self):
		return self.getHostAddress()

	@hostaddress.setter
	def hostaddress(self, x):
		self.setHostAddress(x)

	@property
	def hostaddr(self):
		return self.getHostAddress()

	@hostaddr.setter
	def hostaddr(self, x):
		self.setHostAddress(x)

	def getHostIP(self):
		return self.getHostAddress()

	def setHostIP(self, x):
		self.setHostAddress(x)

	def HostIP(self, x=None):
		if (x is None):
			return self.getHostIP()
		else:
			self.setHostIP(x)

	@property
	def hostip(self):
		return self.getHostIP()

	@hostip.setter
	def hostip(self, x):
		self.setHostIP(x)

	def getPort(self):
		return self._port

	def setPort(self, x):
		self._port = x

	def Port(self, x=None):
		if (x is None):
			return self.getPort()
		else:
			self.setPort(x)

	@property
	def port(self):
		return self.getPort()

	@port.setter
	def port(self, x):
		self.setPort(x)

	def getBufferSize(self):
		return self._bufsize

	def setBufferSize(self, x):
		self._bufsize = x

	def BufferSize(self, x=None):
		if (x is None):
			return self.getBufferSize()
		else:
			self.setBufferSize(x)

	@property
	def buffersize(self):
		return self.getBufferSize()

	@buffersize.setter
	def buffersize(self, x):
		self.setBufferSize(x)

	@property
	def bufsize(self):
		return self.getBufferSize()

	@bufsize.setter
	def bufsize(self, x):
		self.setBufferSize(x)

	def getSocket(self):
		return self._socket

	def setSocket(self, x):
		self._socket = x

	def Socket(self, x=None):
		if (x is None):
			return self.getSocket()
		else:
			self.setSocket(x)

	@property
	def socket(self):
		return self.getSocket()

	@socket.setter
	def socket(self, x):
		self.setSocket(x)

	def is_opened(self):
		return (self.getSocket() is not None)

	def is_closed(self):
		return (self.getSocket() is None)

	def open(self):
		if (self.is_opened()):
			self.close()
			self.open()
		else:
			with socket.socket(self.getSocketAddressFamily(), self.getSocketType()) as s:
				self.setSocket(s)
				self.loopfunc()

	def close(self):
		sock = self.getSocket()
		if (sock is not None):
			try:
				sock.close()
				self.setSocket(None)
			except Exception as e:
				raise Exception(e)
		else:
			pass  # Do nothing

	def loopfunc(self):
		_ns.print_error('This function should be overried at a child class.')
		raise Exception('__ERROR__: Not implemented.')

	def do(self):
		self.loopfunc()

def is_socket(x):
	return isinstance(x, socket_cls)


# TCP/IP

class tcpsocket_cls(socket_cls):
	_classname = 'nkj.socket.tcpsocket'
	_addressfamily = socket.AF_INET      # IPv4
	_type =          socket.SOCK_STREAM

	def __new__(cls):
		self = super().__new__(cls)
		return self

	def __init__(self):
		super().__init__()

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()


class tcpsocket(tcpsocket_cls):
	pass

def is_tcpsocket(x):
	return isinstance(x, tcpsocket_cls)


class tcpserver_cls(tcpsocket_cls):
	_classname = 'nkj.socket.tcpserver'

	def __new__(cls):
		self = super().__new__(cls)
		return self

	def __init__(self):
		super().__init__()

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@property
	def server(self):
		return self.getSocket()

	@server.setter
	def server(self, x):
		self.setSocket(x)

	# Loop

	def loopfunc(self):
		s = self.getSocket()
		s.bind((self.getHostAddr(), self.getPort()))
		s.listen()
		conn, addr = s.accept()
		with conn:
			print(f'Connected by {addr}')
			while True:
				data = conn.recv(self.getBufferSize())
				if (not data):
					break
				conn.sendall(data)

	# isinstance

	def isinstance(self, x):
		return is_server(x)

class tcpserver(tcpserver_cls):
	pass

def is_tcpserver(x):
	return isinstance(x, tcpserver_cls)


class tcpclient_cls(tcpsocket_cls):
	_classname = 'nkj.socket.tcpclient'

	def __new__(cls):
		self = super().__new__(cls)
		return self

	def __init__(self):
		super().__init__()

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	@property
	def client(self):
		return self.getSocket()

	@client.setter
	def client(self, x):
		self.setSocket(x)

	# Loop

	def loopfunc(self):
		s = self.getSocket()
		s.connect((self.getHostAddr(), self.getPort()))
		s.sendall(b"Hello, world")
		data = s.recv(self.getBufferSize())

	# isinstance

	def isinstance(self, x):
		return is_tcpclient(x)

class tcpclient(tcpclient_cls):
	pass

def is_tcpclient(x):
	return isinstance(x, tcpclient_cls)


# UDP


#-- Main

if __name__ == '__main__':
	DEBUGLEVEL = 1
	nd = _n.DebugFlag()
	nd.debuglevel(DEBUGLEVEL)
	
	nd.print(f'debug level: {nd.debuglevel()}')
	
	if (True):
		server = tcpserver()
		
		if (nd.DEBUG):
			print(f'Socket Address family: {server.addressfamily}', end='')
			print(f' (AF_INET: {socket.AF_INET})')
			print(f'Socket Type:           {server.type}', end='')
			print(f' (SOCK_STREAM: {socket.SOCK_STREAM})')
		
		server.open()
		server.do()
		
		atexit.register(server.close())        # プログラム終了時の強制実行に登録．@atexit.unregister で解除．
