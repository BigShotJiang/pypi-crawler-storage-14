#
# [name] nkj._score.py
# [purpose] nkj._score library
# [exec] python -m nkj._score
#
# Written by Yoshikazu NAKAJIMA (Wed Sep 23 14:38:26 JST 2020)
#

#print('CALLED: nkj._score')

import os
import sys
import numpy as np
import inspect

__DEBUGLEVEL = 0
__LIB_DEBUGLEVEL = 0

NULLSTR = ''
CR = '\r' # 行頭へ復帰
LF = '\n' # 改行
CRLF = '\r\n'

PRINTEND_CR = CR
PRINTEND_LF = LF
PRINTEND_CRLF = CRLF
PRINTEND_NONE = ''
DEFAULT_PRINTEND = PRINTEND_LF

DEFAULT_DOTPRINT = True
_VERBOSE_DOTPRINT = DEFAULT_DOTPRINT
_VERBOSE_DOTPRINT_COUNTER = 0

classname = lambda x: x.__name__ if (inspect.isclass(x)) else x.__class__.__name__

# Debug printing

def debuglevel(level=None):
	global __DEBUGLEVEL
	if (level is None):
		return __DEBUGLEVEL
	else:
		__DEBUGLEVEL = level
		return True

def lib_debuglevel(level=None):
	global __LIB_DEBUGLEVEL
	if (level is None):
		return __LIB_DEBUGLEVEL
	else:
		__LIB_DEBUGLEVEL = level
		return True

debug = lambda x: True if (debuglevel() > x - 1) else False
lib_debug = lambda x: True if (lib_debuglevel() > x - 1) else False

class DebugFlag:
	def debuglevel(self, level=None):
		return debuglevel(level)
	
	@property
	def DEBUG(self):
		return debug(1)
	
	@property
	def DEBUG0(self):
		return debug(0)
	
	@property
	def DEBUG1(self):
		return debug(1)
	
	@property
	def DEBUG2(self):
		return debug(2)
	
	@property
	def DEBUG3(self):
		return debug(3)
	
	def print(self, strlist, end=DEFAULT_PRINTEND):
		_dprint(1, strlist, end)
	
	def print0(self, strlist, end=DEFAULT_PRINTEND):
		_dprint(0, strlist, end)
	
	def print1(self, strlist, end=DEFAULT_PRINTEND):
		_dprint(1, strlist, end)
	
	def print2(self, strlist, end=DEFAULT_PRINTEND):
		_dprint(2, strlist, end)
	
	def print3(self, strlist, end=DEFAULT_PRINTEND):
		_dprint(3, strlist, end)

class LibDebugFlag:
	def debuglevel(self, level=None):
		return lib_debuglevel(level)
	
	@property
	def DEBUG(self):
		return lib_debug(1)
	
	@property
	def DEBUG0(self):
		return lib_debug(0)
	
	@property
	def DEBUG1(self):
		return lib_debug(1)
	
	@property
	def DEBUG2(self):
		return lib_debug(2)
	
	@property
	def DEBUG3(self):
		return lib_debug(3)
	
	@property
	def LIB_DEBUG(self):
		return lib_debug(1)
	
	@property
	def LIB_DEBUG0(self):
		return lib_debug(0)
	
	@property
	def LIB_DEBUG1(self):
		return lib_debug(1)
	
	@property
	def LIB_DEBUG2(self):
		return lib_debug(2)
	
	@property
	def LIB_DEBUG3(self):
		return lib_debug(3)
	
	def print(self, strlist, end=DEFAULT_PRINTEND):
		_ldprint(1, strlist, end)
	
	def print0(self, strlist, end=DEFAULT_PRINTEND):
		_ldprint(0, strlist, end)
	
	def print1(self, strlist, end=DEFAULT_PRINTEND):
		_ldprint(1, strlist, end)
	
	def print2(self, strlist, end=DEFAULT_PRINTEND):
		_ldprint(2, strlist, end)
	
	def print3(self, strlist, end=DEFAULT_PRINTEND):
		_ldprint(3, strlist, end)

# Print

def print_usage(msg):
	print("Usage: python " + sys.argv[0] + " " + msg, flush=True)
	sys.stdout.flush()

def print_message(msg):
	print(msg, flush=True)
	sys.stdout.flush()

def print_warning(msg):
	print("WARNING: " + msg, flush=True)
	sys.stdout.flush()

def printwarning(msg):
	print_warning(msg)

def print_error(msg):
	print("ERROR: " + msg, flush=True)
	sys.stdout.flush()

def printerror(msg):
	print_error(msg)

def printerr(msg):
	print_error(msg)

def _dprint(level, strlist, end=DEFAULT_PRINTEND): # '_' で始まる関数は import * で読み込まれない
	if (__DEBUGLEVEL >= level):
		message = NULLSTR
		for i in range(len(strlist)):
			s = str(strlist[i])
			if (s != NULLSTR):
				message += s
			else:
				message += "NULL"
		print(message, flush=True, end=end)
		sys.stdout.flush()
	else:
		pass

def _ldprint(level, strlist, end=DEFAULT_PRINTEND):
	if (__LIB_DEBUGLEVEL >= level):
		message = NULLSTR
		for i in range(len(strlist)):
			s = str(strlist[i])
			if (s != NULLSTR):
				message += s
			else:
				message += "NULL"
		print(message, flush=True, end=end)
		sys.stdout.flush()
	else:
		pass

def dprint0(strlist, end=DEFAULT_PRINTEND):
	_dprint(0, strlist, end)

def dprint1(strlist, end=DEFAULT_PRINTEND):
	_dprint(1, strlist, end)

def dprint2(strlist, end=DEFAULT_PRINTEND):
	_dprint(2, strlist, end)

def dprint3(strlist, end=DEFAULT_PRINTEND):
	_dprint(3, strlist, end)

def dprint(strlist, end=DEFAULT_PRINTEND):
	dprint1(strlist, end)

def ldprint0(strlist, end=DEFAULT_PRINTEND):
	_ldprint(0, strlist, end)

def ldprint1(strlist, end=DEFAULT_PRINTEND):
	_ldprint(1, strlist, end)

def ldprint2(strlist, end=DEFAULT_PRINTEND):
	_ldprint(2, strlist, end)

def ldprint3(strlist, end=DEFAULT_PRINTEND):
	_ldprint(3, strlist, end)

def ldprint(strlist, end=DEFAULT_PRINTEND):
	ldprint1(strlist, end)

def verbose_dotprint(flag=None, interval=None):
	global _VERBOSE_DOTPRINT
	global _VERBOSE_DOTPRINT_COUNTER
	if (flag is None):
		if (_VERBOSE_DOTPRINT is True):
			if (interval == None):
				print(".", end='', file=sys.stderr)
				sys.stderr.flush()
			elif (_VERBOSE_DOTPRINT_COUNTER >= interval - 1):
				print(".", end='', file=sys.stderr)
				sys.stderr.flush()
				_VERBOSE_DOTPRINT_COUNTER = 0
			else:
				_VERBOSE_DOTPRINT_COUNTER += 1
	elif (flag == 'end'):
		print("", file=sys.stderr)

def flatten(s):
	if (isinstance(s, list) or isinstance(s, tuple)):
		for i in range(np.ndim(s) - 1):
			s = sum(s, [])
		return s
	elif (isinstance(s, np.array)):
		return np.array(s).flatten()
	else:
		raise TypeError("__ERROR__: Illegal data type.")

#-- main

if __name__ == '__main__':
	_DEBUGLEVEL = 1
	debuglevel(_DEBUGLEVEL)

	if (True):
		print('DEBUGLEVEL: {0}'.format(debuglevel()))

	if (True):
		l = [0, 1, 2, 3, 4]
		print("{}".format(l))
		print("Flatten: {}".format(flatten(l)))
		l2 = [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]
		print("{}".format(l2))
		print("Flatten: {}".format(flatten(l2)))
		l3 = [[[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]], [[0, 1, 2, 3, 4], [5, 6, 7, 8, 9]]]
		print("{}".format(l3))
		print("Flatten: {}".format(flatten(l3)))

