#
# [name] nkj.math.py
# [exec] python -m nkj.math
#
# Written by Yoshikazu NAKAJIMA
#
_LIB_DEBUGLEVEL = 0

import os
import sys
import numpy as np
import math as m
from scipy.spatial.transform import Rotation as R
import copy
import numbers
from functools import singledispatch
import nkj as _n
import nkj.str as _ns

# Fags

ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION = False
ENABLE_MULOPERATOR_FOR_CSTRANS3D_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_MAT4X4_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_POINT3D_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_LINE3D_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION
ENABLE_MULOPERATOR_FOR_PLANE3D_CLASS = ENABLE_MULOPERATOR_FOR_GEOMETRYCOMPUTATION

# Defaults

# Global values

nd = _n.DebugFlag()

#-- Global functions --------------------------------------------------------------------------

def eps(x=None):
	global __EPS
	if (x is None):
		return __EPS
	else:
		__EPS = x

def serialize(x):
	_n.ldprint2('--> nkj.math.serialize()')
	_n.ldprint2('x: {0} ({1})'.format(x, type(x)))
	if (x is None):
		pass
	elif (isinstance(x, (list, tuple, np.ndarray))):
		ndim = np.ndim(x)
		if (ndim == 1):
			pass
		elif (ndim == 2):
			if (len(x) == 1):
				classtype = x.__class__
				v = classtype((np.array(x).T)[0])
			else:
				classtype = x.__class__
				x = classtype(x[0])
		else:
			raise TypeError('__ERROR__: Illegal data type. NKJ-MATH-00058.')
	else:
		raise TypeError('__ERROR__: Illegal data type. NKJ-MATH-00064.')
	_n.ldprint2('<-- nkj.math.serialize()')
	return x

def max(x):
	if (nd.LIB_DEBUG0):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00037.")
		for d in x:
			if (not is_digit(d)):
				raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00040.")
	maxval = None
	for c in x:
		maxval = c if (maxval is None) else (maxval if (maxval > c) else c)
	return maxval

def min(x):
	if (nd.LIB_DEBUG0):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00048.")
		for d in x:
			if (not is_digit(d)):
				raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00051.")
	minval = None
	for c in x:
		minval = c if (minval is None) else (minval if (minval < c) else c)
	return minval

def max_index(x):
	if (nd.LIB_DEBUG0):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00059.")
		for c in x:
			if (not is_digit(c)):
				raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00063.")
	maxval = None
	maxid = 0
	for i in range(len(x)):
		c = x[i]
		if (maxval is None):
			maxval = c
			maxid = 0
		elif (c > maxval):
			maxval = c
			maxid = i
	return maxval, maxid

def min_index(x):
	if (nd.LIB_DEBUG0):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00059.")
		for d in x:
			if (not is_digit(d)):
				raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00063.")
	minval = None
	minid = 0
	for i in range(len(x)):
		c = x[i]
		if (minval is None):
			minval = c
			minid = 0
		elif (c < minval):
			minval = c
			minid = i
	return minval, minid

def argmax(x):
	if (nd.LIB_DEBUG0):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00059.")
		for c in x:
			if (not is_digit(c)):
				raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00063.")
	maxval = None
	maxid = 0
	for i in range(len(x)):
		c = x[i]
		if (maxval is None):
			maxval = c
			maxid = 0
		elif (c > maxval):
			maxval = c
			maxid = i
	return maxid

def argmin(x):
	if (nd.LIB_DEBUG0):
		if (not isinstance(x, (list, tuple, np.ndarray))):
			raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00059.")
		for d in x:
			if (not is_digit(d)):
				raise TypeError("__ERROR__: Illegal data type. NKJ-MATH-00063.")
	minval = None
	minid = 0
	for i in range(len(x)):
		c = x[i]
		if (minval is None):
			minval = c
			minid = 0
		elif (c < minval):
			minval = c
			minid = i
	return minid

def index_max(x):
	return argmax(x)

def index_min(x):
	return argmin(x)

def arange2(x, y, step=None):
	if (step == None):
		return np.arange(x, y + 1)
	else:
		return np.arange(x, y + step, step)

def is_ineps(x, ref=None):
	if (ref is None):
		return True if (abs(x) < eps()) else False
	else:
		return True if (abs(x - ref) < eps()) else False

def ineps(x, ref=None):
	return is_ineps(x, ref)

def is_digit(x):
	return isinstance(x, (int, float, np.int8, np.int16, np.int32, np.int64, np.uint8, np.uint16, np.uint32, np.uint64, np.float16, np.float32, np.float64))

def is_scalar(x):
	return isinstance(x, numbers.Number)

def is_geometric_primitive(x):
	ty = type(x)
	flag = False
	for object in [point3d, line3d, plane3d]:
		flag |= ty is object
	return flag

def is_geometric(x):
	return is_geometric_primitive(x)

def is_inrange(x, min, max):
	return (False if (x < min or x > max) else True)

def ndim(x):
	return np.ndim(x)  # np.array(x).ndim でも良い

def shape(x):
	return np.shape(np.array(x))

def sq(x):
	return x * x

def sqrt(x):
	return np.sqrt(x)

def rad2deg(x):
	if (x is None):
		return None
	if (isinstance(x, (list, tuple))):
		l = []
		for i in range(len(x)):
			l.append(rad2deg(x[i]))
		return l
	else:
		#return (x * 180.0 / np.pi)
		return m.degrees(x)

def deg2rad(x):
	if (isinstance(x, (list, tuple))):
		l = []
		for i in range(len(deglist)):
			l.append(deg2rad(deglist[i]))
		return l
	else:
		#return (x * np.pi / 180.0)
		return m.radians(x)

def inch2mm(x):
	return 25.4 * x   # 30.48 * x / 1.2

def mm2inch(x):
	return x / 25.4

def feet2cm(x):
	return 30.48 * x

def cm2feet(x):
	return x / 30.48

def feet2mm(x):
	return 304.8 * x

def mm2feet(x):
	return x / 304.8

"""-----
def rad2deg4list(radlist):
	deglist = []
	for i in range(len(radlist)):
		deglist.append(rad2deg(radlist[i]))
	return deglist

def deg2rad4list(deglist):
	radlist = []
	for i in range(len(deglist)):
		radlist.append(deg2rad(deglist[i]))
	return radlist
-----"""

def sigmoid(x, tau=1.0, x0=0.0):
	return 1.0 / (1.0 + np.exp(-(x - x0) / tau))

def vecnorm(v):
	if (isinstance(v, np.ndarray)):
		v = np.array(v)
	return np.linalg.norm(v)

def norm(x):
	if (isinstance(x, np.ndarray)):
		if (x.ndim == 1):
			return vecnorm(x)
		else:
			raise ValueError("__ERROR__: Illegal data dimensions")
	else:
		raise TypeError("__ERROR__: Illegal data type")

def vecnormalize(v):
	if (isinstance(v, list) or isinstance(v, tuple)):
		v = np.array(v)
	vlen = vecnorm(v)
	if (vlen != 0):
		v = v / vlen   # np.array の要素に対して、v /= vlen はできない
	if (isinstance(v, np.ndarray)):
		pass
	elif (isinstance(v, list)):
		v = [v[0], v[1], v[2]]
	elif (isinstance(v, tuple)):
		v = (v[0], v[1], v[2])
	return v

def normalize(x):
	if (isinstance(x, np.ndarray)):
		if (x.ndim == 1):
			return vecnormalize(x)
		else:
			raise ValueError("__ERROR__: Illegal data dimensions")
	else:
		raise TypeError("__ERROR__: Illegal data type")

def vecangle(basev, v):
	u = basev
	nu = vecnorm(u)
	nv = vecnorm(v)
	if (nu == 0.0):
		return 0.0
	if (nv == 0.0):
		return 0.0
	u = u / nu # normalize
	v = v / nv # normalize
	c = np.inner(u, v)
	s = np.linalg.norm(np.cross(u, v)) # np.cross() は、ベクトルが両方とも2次元の場合はスカラー返すが、3次元の場合は3次元ベクトルを返す。
	return np.arctan2(s, c)

"""-----
def angle_(base, target):
	if (base is None or target is None):
		raise ValueError("__ERROR__: None value was given.")
	if (isinstance(base, list) or isinstance(base, tuple)):
		base = np.array(base)
	if (isinstance(target, list) or isinstance(target, tuple)):
		target = np.array(target)
	if (isinstance(base, np.ndarray) and isinstance(target, np.ndarray)):
		return vecangle(base, target)
	elif (isinstance(base, vec3d) and isinstance(target, vec3d)):
		return vecangle(base.get(), target.get())
	elif (isinstance(base, line3d) and isinstance(target, line3d)):
		return vecangle(base.getVector(), target.getVector())
	elif (isinstance(base, plane3d) and isinstance(target, plane3d)):
		return vecangle(base.getNormal(), target.getNormal())
	elif (isinstance(base, plane3d) and isinstance(target, line3d)):
		return np.pi / 2.0 - vecangle(base.getNormal(), target.getVector())
	elif (isinstance(base, line3d) and isinstance(target, plane3d)):
		return np.pi / 2.0 - vecangle(base.getVector(), target.getNormal())
	else:
		raise TypeError("__ERROR__: Illegal data type")
------"""

def normalized(x):
	return x.normalized()

def inversed(x):
	return x.inversed()

def transposed(x):
	return x.transposed()

def conjugated(x):
	return x.conjugated()

def decimal_unit(x):
	if (x == 0.0):
		return 0.0
	elif (x > 0.0):
		sign = 1.0
	else:
		sign = -1.0
		x = -x
	unit = 1.0
	if (x > 1.0):
		while (unit < x):
			unit *= 10.0
		if (unit > x):
			unit /= 10.0
	else: # 0.0 < x < 1.0
		while (unit > x):
			unit /= 10.0
	return sign * unit

def logticks(min, max, ticks=10):
	_ns.ldprint2(["--> logticks({0}, {1}, {2})".format(min, max, ticks)])
	if (min < 0.0 or max < 0.0):
		print_error("Illegal arguments.")
		return None
	if (min > max):
		print_error("Illegal arguments.")
		return None
	if (ticks < 0):
		print_error("Illegal ticks.")
		return None
	tick_interval = 1.0 / float(ticks)
	_ns.ldprint3(["Tick interval: {0}".format(tick_interval)])
	min_log10 = np.log10(min)
	max_log10 = np.log10(max)
	unit_min_log10 = int(np.ceil(min_log10 * ticks))
	unit_max_log10 = int(np.floor(max_log10 * ticks))
	_ns.ldprint3(["min: {0} -> log10(min): {1} -> {2}".format(min, min_log10, unit_min_log10)])
	_ns.ldprint3(["max: {0} -> log10(max): {1} -> {2}".format(max, max_log10, unit_max_log10)])
	xlist = []
	if (min_log10 * ticks < unit_min_log10):
		xlist.append(min)
	for unit_tick_log10 in range(unit_min_log10, unit_max_log10 + 1):
		tick_log10 = unit_tick_log10 * tick_interval
		_ns.ldprint3(["Tick_log10: {0}".format(tick_log10)])
		tick = np.power(10.0, tick_log10)
		xlist.append(tick)
	if (max_log10 * ticks > unit_max_log10):
		xlist.append(max)
	_ns.ldprint(["xlist: ", xlist])
	_ns.ldprint2(["<-- logticks()"])
	return xlist

def pseudo_logticks(min, max, tick_scale=1.0):
	_ns.ldprint2(["--> pseudo_logticks({0}, {1}, {2})".format(min, max, tick_scale)])
	if (min < 0.0 or max < 0.0):
		print_error("Illegal arguments.")
		return None
	if (min > max):
		print_error("Illegal arguments.")
		return None
	if (tick_scale <= 0.0 or tick_scale > 1.0):
		print_error("Illegal tick scale.")
		return None
	min_unit = decimal_unit(min)
	max_unit = decimal_unit(max)
	if (max_unit < max):
		max_unit *= 10.0
	_ns.ldprint3(["unit: ", min, " -> ", min_unit])
	_ns.ldprint3(["unit: ", max, " -> ", max_unit])
	min_log10 = int(np.log10(min_unit))
	max_log10 = int(np.log10(max_unit))
	_ns.ldprint3(["log10: ", min_unit, " -> ", min_log10])
	_ns.ldprint3(["log10: ", max_unit, " -> ", max_log10])
	xlist = []
	for i in range(min_log10, max_log10):
		_ns.ldprint3(["log10: ", i])
		unit = np.power(10.0, i)
		_ns.ldprint3(["unit: ", unit])
		j_max = int(10.0 / tick_scale)
		for j in range(1, j_max):
			val = unit * tick_scale * j
			if (val < min):
				hval = unit * tick_scale * (j + 1)
				if (min < hval):
					xlist.append(min)
			elif (val < max):
				xlist.append(val)
			else:
				xlist.append(max)
				break
		if (val < max and max <= np.power(10.0, i + 1)):
			list.append(max)
	"""
	xlist = list(set(xlist))
	xlist = xlist.sort()
	"""
	_ns.ldprint2(["xlist: ", xlist])
	_ns.ldprint2(["<-- pseudo_logticks()"])
	return xlist

_DEFAULT_EPS =                 1.0e-8
_DEFAULT_DISTANCE_THRESHOLD =  1.0  # [mm]
_DEFAULT_ANGLE_THRESHOLD_DEG = 1.0  # [deg]
_DEFAULT_ANGLE_THRESHOLD_RAD = deg2rad(_DEFAULT_ANGLE_THRESHOLD_DEG)
_DEFAULT_ANGLE_THRESHOLD =     _DEFAULT_ANGLE_THRESHOLD_RAD
_DEFAULT_KEEPING_DISTANCE =    3.0   # [mm]
_DEFAULT_KEEPING_ANGLE_DEG =   15.0  # [deg]
_DEFAULT_KEEPING_ANGLE_RAD =   deg2rad(_DEFAULT_KEEPING_ANGLE_DEG)
_DEFAULT_KEEPING_ANGLE =       _DEFAULT_KEEPING_ANGLE_RAD

DEFAULT_EPS =                 _DEFAULT_EPS
DEFAULT_DISTANCE_THRESHOLD =  _DEFAULT_DISTANCE_THRESHOLD
DEFAULT_ANGLE_THRESHOLD_DEG = _DEFAULT_ANGLE_THRESHOLD_DEG
DEFAULT_ANGLE_THRESHOLD_RAD = _DEFAULT_ANGLE_THRESHOLD_RAD
DEFAULT_ANGLE_THRESHOLD =     _DEFAULT_ANGLE_THRESHOLD
DEFAULT_KEEPING_DISTANCE =    _DEFAULT_KEEPING_DISTANCE
DEFAULT_KEEPING_ANGLE_DEG =   _DEFAULT_KEEPING_ANGLE_DEG
DEFAULT_KEEPING_ANGLE_RAD =   _DEFAULT_KEEPING_ANGLE_RAD
DEFAULT_KEEPING_ANGLE =       _DEFAULT_KEEPING_ANGLE

# Global values

__EPS =                _DEFAULT_EPS
__DISTANCE_THRESHOLD = _DEFAULT_DISTANCE_THRESHOLD
__ANGLE_THRESHOLD =    _DEFAULT_ANGLE_THRESHOLD
__KEEPING_DISTANCE =   _DEFAULT_KEEPING_DISTANCE
__KEEPING_ANGLE =      _DEFAULT_KEEPING_ANGLE

def zero_threshold(x=None):
	if (x is None):
		return eps()
	else:
		eps(x)

def zero_thresh(x=None):
	if (x is None):
		return eps()
	else:
		eps(x)

def zerothreshold(x=None):
	if (x is None):
		return eps()
	else:
		eps(x)

def zerothresh(x=None):
	if (x is None):
		return eps()
	else:
		eps(x)

def distance_threshold(x=None):
	global __DISTANCE_THRESHOLD
	if (x is None):
		return __DISTANCE_THRESHOLD
	else:
		__DISTANCE_THRESHOLD = x

def distance_thresh(x=None):
	if (x is None):
		return distance_threshold()
	else:
		distance_threshold(x)

def distancethreshold(x=None):
	if (x is None):
		return distance_threshold()
	else:
		distance_threshold(x)

def distancethresh(x=None):
	if (x is None):
		return distance_threshold()
	else:
		distance_threshold(x)

def distthresh(x=None):
	if (x is None):
		return distance_threshold()
	else:
		distance_threshold(x)

def disable_distance_threshold():
	distance_threshold(0.0)

def disable_distancethreshold():
	distance_threshold(0.0)

def disable_distancethresh():
	distance_threshold(0.0)

def clear_distance_threshold():
	distance_threshold(0.0)

def clear_distancethreshold():
	distance_threshold(0.0)

def clear_distancethresh():
	distance_threshold(0.0)

def clear_distthresh():
	distance_threshold(0.0)

def angle_threshold(x=None):
	global __ANGLE_THRESHOLD
	if (x is None):
		return __ANGLE_THRESHOLD
	else:
		__ANGLE_THRESHOLD = x

def anglethreshold(x=None):
	if (x is None):
		return angle_threshold()
	else:
		angle_threshold(x)

def anglethresh(x=None):
	if (x is None):
		return angle_threshold()
	else:
		angle_threshold(x)

def angthresh(x=None):
	if (x is None):
		return angle_threshold()
	else:
		angle_threshold(x)

def disable_angle_threshold():
	angle_threshold(0.0)

def disable_anglethreshold():
	angle_threshold(0.0)

def disable_anglethresh():
	angle_threshold(0.0)

def disable_angthresh():
	angle_threshold(0.0)

def clear_angle_threshold():
	angle_threshold(0.0)

def clear_anglethreshold():
	angle_threshold(0.0)

def clear_anglethresh():
	angle_threshold(0.0)

def clear_angthresh():
	angle_threshold(0.0)

def keeping_distance(x=None):
	global __KEEPING_DISTANCE
	if (x is None):
		return __KEEPING_DISTANCE
	else:
		__KEEPING_DISTANCE = x

def keepingdistance(x=None):
	if (x is None):
		return keeping_distance()
	else:
		keeping_distance(x)

def keepingdist(x=None):
	if (x is None):
		return keeping_distance()
	else:
		keeping_distance(x)

def disable_keeping_distance():
	keeping_distance(0.0)

def disable_keepingdistance():
	keeping_distance(0.0)

def disable_keepingdist():
	keeping_distance(0.0)

def clear_keeping_distance():
	keeping_distance(0.0)

def clear_keepingdistance():
	keeping_distance(0.0)

def clear_keepingdist():
	keeping_distance(0.0)

def keeping_angle(x=None):
	global __KEEPING_ANGLE
	if (x is None):
		return __KEEPING_ANGLE
	else:
		__KEEPING_ANGLE = x

def keepingangle(x=None):
	if (x is None):
		return keeping_angle()
	else:
		keeping_angle(x)

def keepingang(x=None):
	if (x is None):
		return keeping_angle()
	else:
		keeping_angle(x)

def disable_keeping_angle():
	keeping_angle(0.0)

def disable_keepingangle():
	keeping_angle(0.0)

def disable_keepingang():
	keeping_angle(0.0)

def clear_keeping_angle():
	keeping_angle(0.0)

def clear_keepingangle():
	keeping_angle(0.0)

def clear_keepingang():
	keeping_angle(0.0)


# Classes -----------------------------------------------------------------------------------
#-- Angle

_DEFAULT_ANGLE = 0.0   # degree

class angle_cls():
	_classname = 'nkj.m.angle_cls'

	def __init__(self, r=None):
		_ns.ldprint('--> nkj.math.angle._init_()')
		if (r is None):
			self.set()
		else:
			self.set(r)
		_ns.ldprint2('val: {0} [rad] ({1} [deg])'.format(self.getRad(), self.getDeg()))
		_ns.ldprint('<-- nkj.math.angle._init_()')

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	# get, set

	def get(self):
		return self.getAngle()

	def set(self, r=None):
		if (r is None):
			self.setDeg(_DEFAULT_ANGLE)
		elif (isinstance(r, float)):
			self.setAngle(r)
		else:
			raise TypeError("__ERROR__: Illegal data type")

	# angle

	def getAngle(self):
		return self.getRad()

	def setAngle(self, r):
		self.setRad(r)

	def getRad(self):
		return self._r

	def setRad(self, r):
		self._r = r

	@property
	def rad(self):
		return self.getRad()

	@rad.setter
	def rad(self, a):
		self.setRad(a)

	def getDeg(self):
		return rad2deg(self.getRad())

	def setDeg(self, a):
		self.setRad(deg2rad(a))

	@property
	def deg(self):
		return self.getDeg()

	@deg.setter
	def deg(self, a):
		self.setDeg(a)

	# cos, sin

	@property
	def cos(self):
		return np.cos(self.getRad())

	@property
	def sin(self):
		return np.sin(self.getRad())

	@property
	def c(self):
		return self.cos

	@property
	def s(self):
		return self.sin

	# string

	def getStr(self):
		return '{:.12f}'.format(self.getDeg())

	def setStr(self, s):
		self.setDeg(float(s))

	@property
	def str(self):
		return self.getStr()

	@str.setter
	def str(self, s):
		self.setStr(s)

	def getDataStr(self):
		return '{:.12f}'.format(self.getDeg())

	@property
	def datastr(self):
		return self.getDataStr()

	# print

	def getPrintString(self, title=None):
		s = ''
		if (title is not None):
			s += '{}: '.format(title)
		s += '{0:.6f} deg ({1:.6f} rad)'.format(self.getDeg(), self.getRad())
		if (title is not None):
			s += '\n'
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintStr()

	@property
	def pstr(self):
		return self.getPrintStr()

	def print(self, title=None):
		print(self.getPrintStr(title), end='', flush=True)

	# load, save

	def load(self, filename):
		with open(filename, 'r') as f:
			self.setDataStr(f.read())

	def save(self, filename):
		with open(filename, 'w') as f:
			f.write(self.getDataStr())

class angle(angle_cls):
	pass


#-- Lib Main

if (__name__ == '__main__'):
	import nkj.math as nm

	_LIB_DEBUGLEVEL = 1

	if (True):
		import nkj as n
		n.lib_debuglevel(_LIB_DEBUGLEVEL)
		print('LIB_DEBUGLEVEL: {0}'.format(n.lib_debuglevel()))
	else:
		from nkj import *
		s.lib_debuglevel(_LIB_DEBUGLEVEL)
		print('LIB_DEBUGLEVEL: {0}'.format(s.lib_debuglevel()))

	if (True):
		print("\n-- angle")
		a = nm.angle()
		a.deg = 60
		print("Rad: {0:.3f}".format(a.rad))
		print("Deg: {0:.1f}".format(a.rad / m.pi * 180.0))
		print("Str: {0}".format(a.str))

	if (True):
		print("\n-- test functions")
		print("max: {}".format(nm.max([1.0, 2.0])))
		print("max: {}".format(nm.max([0.0, 1.0, 2.0, 3.0, -1.0])))
