#
# [name] nkj.vtk.py
# [exec] python -m nkj.vtk
#
# Written by Yoshikazu NAKAJIMA
#
import numpy as np
import copy
import vtk
from xml.dom import minidom
import xml.etree.ElementTree as ET
import nkj as _n
import nkj.str as _ns
import nkj.math as _nm
import nkj.cs as _ncs
import nkj.primitiveshape as _nps
import nkj.xml as _nxml

_DEFAULT_VTK_LEAGACY_DATAFILE_HEADER = "# vtk DataFile Version 3.0\n" + "VTK data\n" + "ASCII\n" + "DATASET POLYDATA\n"
_DEFAULT_VTK_XMLROOTELEMENT_INDEX = 'VTKFile'

_DEFAULT_PLANE_WIDTH = 10.0
_DEFAULT_PLANE_HEIGHT = 10.0

_DEFAULT_CS = _ncs.mat3x4()
_DEFAULT_CS_AXISSIZE = 10.0

nd = _n.LibDebugFlag()

# Classes

#-- Polydata

class polydata_cls(_nxml.elementtree_cls):
	_classname = 'nkj.vtk.polydata'

	def __new__(cls, x=None):
		self = super().__new__(cls, _DEFAULT_VTK_XMLROOTELEMENT_INDEX)
		return self

	def __init__(self, x=None):
		super().__init__(_DEFAULT_VTK_XMLROOTELEMENT_INDEX)
		self.root.set('type', 'PolyData')
		self.root.set('version', '0.1')
		self.root.set('byte_order', 'LittleEndian')
		self._polyelem = ET.SubElement(self.root, 'PolyData')
		self._pieceelem = ET.SubElement(self._polyelem, 'Piece')
		self._pieceelem.set('NumberOfPoints', '0')
		self._pieceelem.set('NumberOfVerts', '0')
		self._pieceelem.set('NumberOfLines', '0')
		self._pieceelem.set('NumberOfCells', '0')
		self._pieceelem.set('NumberOfStrips', '0')
		self._pieceelem.set('NumberOfPolys', '0')
		self._pointselem = ET.SubElement(self._pieceelem, 'Points')
		self._vertselem =  ET.SubElement(self._pieceelem, 'Verts')
		self._lineselem =  ET.SubElement(self._pieceelem, 'Lines')
		self._lineselem =  ET.SubElement(self._pieceelem, 'Cells')
		self._stripselem = ET.SubElement(self._pieceelem, 'Strips')
		self._polyselem =  ET.SubElement(self._pieceelem, 'Polys')
		self._polyselem =  ET.SubElement(self._pieceelem, 'Coordinates')
		self._pointdataelem = ET.SubElement(self._pieceelem, 'PointData')
		self._celldataelem =  ET.SubElement(self._pieceelem, 'CellData')
		self._points = None
		self._verts = None
		self._lines = None
		self._strips = None
		self._polys = None
		self._coordinates = None
		self._pointdata = None
		self._celldata = None

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def refreshXMLElementTree(self):
		if (self.getPoints() is None):
			pass
		else:
			raise Exception("__ERROR__: Not implemented. NKJ-VTK-00117.")

	def refresh(self):
		self.refreshXMLElementTree(self)

class polydata(polydata_cls):
	pass


class unstructuredgrid_cls(_nxml.elementtree_cls):
	_classname = 'nkj.vtk.unstructuredgrid'

	def __new__(cls, x=None):
		self = super().__new__(cls, _DEFAULT_VTK_XMLROOTELEMENT_INDEX)
		return self

	def __init__(self, x=None):
		super().__init__(_DEFAULT_VTK_XMLROOTELEMENT_INDEX)
		self.root.set('type', 'UnstructuredGrid')
		self.root.set('version', '0.1')
		self.root.set('byte_order', 'LittleEndian')
		self._polyelem = ET.SubElement(self.root, 'UnstructuredGrid')
		self._pieceelem = ET.SubElement(self._polyelem, 'Piece')
		self._pieceelem.set('NumberOfPoints', '0')
		self._pieceelem.set('NumberOfVerts', '0')
		self._pieceelem.set('NumberOfLines', '0')
		self._pieceelem.set('NumberOfCells', '0')
		self._pieceelem.set('NumberOfStrips', '0')
		self._pieceelem.set('NumberOfPolys', '0')
		self._pointselem = ET.SubElement(self._pieceelem, 'Points')
		self._vertselem =  ET.SubElement(self._pieceelem, 'Verts')
		self._lineselem =  ET.SubElement(self._pieceelem, 'Lines')
		self._lineselem =  ET.SubElement(self._pieceelem, 'Cells')
		self._stripselem = ET.SubElement(self._pieceelem, 'Strips')
		self._polyselem =  ET.SubElement(self._pieceelem, 'Polys')
		self._polyselem =  ET.SubElement(self._pieceelem, 'Coordinates')
		self._pointdataelem = ET.SubElement(self._pieceelem, 'PointData')
		self._celldataelem =  ET.SubElement(self._pieceelem, 'CellData')
		self._points = None
		self._verts = None
		self._lines = None
		self._strips = None
		self._polys = None
		self._coordinates = None
		self._pointdata = None
		self._celldata = None

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def refreshXMLElementTree(self):
		if (self.getPoints() is None):
			pass
		else:
			raise Exception("__ERROR__: Not implemented. NKJ-VTK-00117.")

	def refresh(self):
		self.refreshXMLElementTree(self)

class unstructuredgrid(unstructuredgrid_cls):
	pass


#-- Points

class points_cls(polydata_cls):
	_classname = 'nkj.vtk.points'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x=None):
		self.setPoints(x)

	# Points

	def getPoints(self):
		return self._points

	def setPoints(self, x=None):
		_n.ldprint('--> nkj.vtk.polydata.setPoints({0} ({1}))'.format(x, type(x)))
		
		if (x is None):
			x = _ncs.point3list()
		elif (_ncs.is_point3list(x)):
			x = copy.deepcopy(x)
		elif (isinstance(x, (list, tuple))):
			x = _ncs.point3list(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00114.")
		
		self._points = x
		
		# PolyData.Piece
		
		piece_elemlist = self.retrieve('PolyData.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00122.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# PolyData.Piece.Points
			
			points_elemlist = self.retrieve('PolyData.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00134.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			npts = len(x)
			for i in range(npts):
				pt = x[i]
				if (nd.LIB_DEBUG2):
					pt.print('point[{}]'.format(i))
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(npts)  # 属性データ（辞書（dict）タイプ {key: value}. Piece.attr:NumberOfPoints）の更新
			
			# PolyData.Piece.Verts (頂点 Vertex の複数形である Verticies の略)
			
			verts_elemlist = self.retrieve('PolyData.Piece.Verts')
			if (len(verts_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00164.")
			
			velem = verts_elemlist[0][1]
			array_elem = ET.SubElement(velem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			nverts = len(x)
			for i in range(nverts):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(i)
			array_elem.text = value_str
			array_elem = ET.SubElement(velem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(nverts):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(i + 1)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfVerts'] = '{:d}'.format(nverts)  # Piece.attr:NumberOfVerts を更新しないと、点群が表示されない．
			
			# PolyData.Piece.Lines
			
			lines_elemlist = self.retrieve('PolyData.Piece.Lines')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00156.")
			
			lelem = lines_elemlist[0][1]
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			nlines = len(x) - 1
			for i in range(nlines):
				if (i != 0):
					value_str += ' '
				value_str += '{0} {1}'.format(i, i + 1)
			array_elem.text = value_str
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(nlines):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(2 * (i + 1))
			array_elem.text = value_str
			piece_elem.attrib['NumberOfLines'] = '{:d}'.format(nlines)  # Piece.attr:NumberOfLines を更新しないと、それぞれ2点の間の線が表示されない．
			
		if (nd.LIB_DEBUG):
			self.print('self')
		_n.ldprint('<-- nkj.vtk.polydata.setPoints()')

	@property
	def points(self):
		return self.getPoints()

	@points.setter
	def points(self, x):
		self.setPoints(x)

class points(points_cls):
	pass

class point3s(points_cls):
	pass

class pointlist(points_cls):
	pass

class point3list(points_cls):
	pass


#-- Line

class line_cls(polydata_cls):
	_classname = 'nkj.vtk.line'

	def __new__(cls, x=None, linesize=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None, linesize=None):
		super().__init__()
		self.setLineSize(linesize)
		self.set(x, linesize)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def getLineSize(self):
		return self._linesize

	def setLineSize(self, s):
		self._linesize = s

	@property
	def linesize(self):
		return self.getLineSize()

	@linesize.setter
	def linesize(self, s):
		self.getLineSize(s)

	def getLineLength(self):
		return self.getLineSize()

	def setLineLength(self, l):
		self.setLineSize(l)

	@property
	def linelength(self):
		return self.getLineLength()

	@linelength.setter
	def linelength(self, l):
		self.getLineLength(l)

	@property
	def linelen(self):
		return self.getLineLength()

	@linelen.setter
	def linelen(self, l):
		self.getLineLength(l)

	def set(self, x=None, linesize=None):
		self.setLine(x, linesize)

	# Points

	def getPoints(self):
		return self._points

	@property
	def points(self):
		return self.getPoints()

	# Line

	def getLine(self):
		return self._lines

	def setLine(self, x, linesize=None):
		_n.ldprint('--> nkj.vtk.polydata.setLine({0} ({1}), linesize:{2})'.format(x, type(x), linesize))
		
		if (linesize is not None):
			self.setLineSize(linesize)
		
		linesize = self.getLineSize()
		
		_n.ldprint('linelength: {}'.format(linesize))
		
		if (_nps.is_line3(x)):
			pass
		elif (isinstance(x, (list, tuple, np.ndarray))):
			x = _nps.line3(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00236.")
		
		if (nd.LIB_DEBUG):
			print('x: {} ({})'.format(x, type(x)))
			if (not _nps.is_line3(x)):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00251.")
		
		linevec = x.getPoint(1) - x.getPoint(0)
		
		self._points = _ncs.vec3list()
		self._points.append(x.getPoint(0))
		
		if (linesize is None):
			self._points.append(x.getPoint(1))
		else:
			self._points.append(x.getPoint(0) + linesize * linevec)
		
		self._lines = _nps.line3list([x])
		
		if (nd.LIB_DEBUG):
			self._points.print('points @ nkj.vtk.line')
			self._lines.print('lines @ nkj.vtk.line ')
		
		# PolyData.Piece
		
		piece_elemlist = self.retrieve('PolyData.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00243.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# PolyData.Piece.Points
			
			points_elemlist = self.retrieve('PolyData.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00256.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(len(self._points)):
				pt = self._points[i]
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(len(self._points))
			
			# PolyData.Piece.Lines
			
			lines_elemlist = self.retrieve('PolyData.Piece.Lines')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00282.")
			
			lelem = lines_elemlist[0][1]
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			array_elem.text = '0 1'
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			array_elem.text = '2'
			piece_elem.attrib['NumberOfLines'] = '1'
			
		if (nd.LIB_DEBUG):
			self.print('self')
		_n.ldprint('<-- nkj.vtk.polydata.setLine()')

	@property
	def line(self):
		return self.getLine()

	@line.setter
	def line(self, x):
		self.setLine(x)

class line(line_cls):
	pass

class line3(line_cls):
	pass


#-- Lines

class lines_cls(polydata_cls):
	_classname = 'nkj.vtk.lines'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		super().__init__()
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x=None):
		self.setLines(x)

	# Points

	def getPoints(self):
		return self._points

	@property
	def points(self):
		return self.getPoints()

	# Lines

	def getLines(self):
		return self._lines

	def setLines(self, x=None):
		_n.ldprint('--> nkj.vtk.polydata.setLine({0} ({1}))'.format(x, type(x)))
		
		if (_nps.is_line3(x)):
			x = _nps.line3list(copy.deepcopy(x))
		elif (_nps.is_line3list(x)):
			pass
		elif (isinstance(x, (list, tuple, np.ndarray))):
			x = _nps.line3list(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00236.")
		
		self._points = _ncs.point3list()
		for l in x:
			if (nd.LIB_DEBUG0):
				if (not _nps.is_line3(l)):
					raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00251.")
			self._points.append(l.getPoint(0))
			self._points.append(l.getPoint(1))
		
		self._lines = x
		
		# PolyData.Piece
		
		piece_elemlist = self.retrieve('PolyData.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00243.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# PolyData.Piece.Points
			
			points_elemlist = self.retrieve('PolyData.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00256.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(len(self._points)):
				pt = self._points[i]
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(len(self._points))
			
			# PolyData.Piece.Lines
			
			lines_elemlist = self.retrieve('PolyData.Piece.Lines')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00282.")
			
			lelem = lines_elemlist[0][1]
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			nlines = 0
			for i in range(0, len(self._points), 2):
				if (i != 0):
					value_str += ' '
				value_str += '{0} {1}'.format(i, i + 1)
				nlines += 1
			array_elem.text = value_str
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(nlines):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(2 * (i + 1))
			array_elem.text = value_str
			piece_elem.attrib['NumberOfLines'] = '{}'.format(nlines)
			
		if (nd.LIB_DEBUG):
			self.print('self')
		_n.ldprint('<-- nkj.vtk.polydata.setLines()')

	@property
	def lines(self):
		return self.getLines()

	@lines.setter
	def lines(self, x):
		self.setLines(x)

class lines(lines_cls):
	pass

class line3s(lines_cls):
	pass

class linelist(lines_cls):
	pass

class line3list(lines_cls):
	pass


#-- Plane class (PolyData, UnstructuredGrid)

class polyplane_cls(polydata_cls):
	_classname = 'nkj.vtk.plane'

	def __new__(cls, x=None, planesize=[_DEFAULT_PLANE_WIDTH, _DEFAULT_PLANE_HEIGHT]):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None, planesize=[_DEFAULT_PLANE_WIDTH, _DEFAULT_PLANE_HEIGHT]):
		super().__init__()
		width, height = planesize
		self.setPlaneWidth(width)
		self.setPlaneHeight(height)
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x):
		self.setPlane(x)

	# Points

	def getPolyPoints(self):
		return self._points

	@property
	def polypoints(self):
		return self.getPolyPoints()

	def getPoints(self):
		return self.getPlanePoints()

	@property
	def points(self):
		return self.getPoints()

	# Plane

	def getPlane(self):
		return self._plane

	def setPlane(self, x):
		_n.ldprint('--> nkj.vtk.polyplane.setPlane({0} ({1}))'.format(x, type(x)))
		
		if (x is None):
			x = _nps.plane(_nps._DEFAULT_PLANE)
		
		if (_nps.is_plane(x)):
			self._plane = copy.deepcopy(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			self._plane = _nps.plane(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00550.")
		
		pl = self._plane
		
		pl_woffset = self.getPlaneWidth() / 2.0
		pl_hoffset = self.getPlaneHeight() / 2.0
		pl_m = pl.matrix
		
		self._points = _ncs.point3list()
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([-pl_woffset,  pl_hoffset, 0.0])
		self._points.append([-pl_woffset,  pl_hoffset, 0.0])
		self._points.append([ pl_woffset,  pl_hoffset, 0.0])
		self._points.append([ pl_woffset,  pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([ pl_woffset,  pl_hoffset, 0.0])
		self._points.append([ pl_woffset,  pl_hoffset, 0.0])
		self._points.append([ pl_woffset, -pl_hoffset, 0.0])
		self._points.append([ pl_woffset, -pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([ pl_woffset, -pl_hoffset, 0.0])
		self._points.append([ pl_woffset, -pl_hoffset, 0.0])
		self._points.append([-pl_woffset, -pl_hoffset, 0.0])
		self._points.append([-pl_woffset, -pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([-pl_woffset, -pl_hoffset, 0.0])
		self._points.append([-pl_woffset, -pl_hoffset, 0.0])
		self._points.append([-pl_woffset,  pl_hoffset, 0.0])
		self._points.append([-pl_woffset,  pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		
		self._points = pl_m @ self._points
		
		# PolyData.Piece
		
		piece_elemlist = self.retrieve('PolyData.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00361.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# PolyData.Piece.Points
			
			points_elemlist = self.retrieve('PolyData.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00374.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(len(self._points)):
				pt = self._points[i]
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(len(self._points))
			
			# PolyData.Piece.Lines
			
			lines_elemlist = self.retrieve('PolyData.Piece.Lines')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00397.")
			
			lelem = lines_elemlist[0][1]
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(0, len(self._points), 2):
				if (i != 0):
					value_str += ' '
				value_str += '{0} {1}'.format(i, i + 1)
			array_elem.text = value_str
			
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(0, len(self._points), 2):
				if (i != 0):
					value_str += ' '
				value_str += '{0}'.format(i + 2)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfLines'] = '{}'.format(int(len(self._points) / 2))
			
		if (nd.LIB_DEBUG):
			self.print('self')
		
		_n.ldprint('<-- nkj.vtk.polyplane.setPlane()')

	@property
	def plane(self):
		return self.getPlane()

	@plane.setter
	def plane(self, x):
		self.setPlane(x)

	# Model parameters

	def getPlaneWidth(self):
		return self._width

	def setPlaneWidth(self, x=None):
		self._width = _DEFAULT_PLANE_WIDTH if (x is None) else x

	def getPlaneHeight(self):
		return self._height

	def setPlaneHeight(self, x=None):
		self._height = _DEFAULT_PLANE_HEIGHT if (x is None) else x

	@property
	def planewidth(self):
		return self.getPlaneWidth()

	@planewidth.setter
	def planewidth(self, x):
		self.setPlaneWidth(x)

	@property
	def width(self):
		return self.getPlaneWidth()

	@width.setter
	def width(self, x):
		self.setPlaneWidth(x)

	@property
	def planeheight(self):
		return self.getPlaneHeight()

	@planeheight.setter
	def planeheight(self, x):
		self.setPlaneHeight(x)

	@property
	def height(self):
		return self.getPlaneHeight()

	@height.setter
	def height(self, x):
		self.setPlaneHeight(x)

class polyplane(polyplane_cls):
	pass

class polyplane3(polyplane_cls):
	pass

class wireplane(polyplane_cls):
	pass

class wireplane3(polyplane_cls):
	pass


class plane_cls(unstructuredgrid_cls):
	_classname = 'nkj.vtk.plane'

	def __new__(cls, x=None, planesize=[_DEFAULT_PLANE_WIDTH, _DEFAULT_PLANE_HEIGHT]):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None, planesize=[_DEFAULT_PLANE_WIDTH, _DEFAULT_PLANE_HEIGHT]):
		super().__init__()
		width, height = planesize
		self.setPlaneWidth(width)
		self.setPlaneHeight(height)
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x):
		self.setPlane(x)

	# Points

	def getPolyPoints(self):
		return self._points

	@property
	def polypoints(self):
		return self.getPolyPoints()

	def getPoints(self):
		return self.getPlanePoints()

	@property
	def points(self):
		return self.getPoints()

	# Plane

	def getPlane(self):
		return self._plane

	def setPlane(self, x):
		_n.ldprint('--> nkj.vtk.plane.setPlane({0} ({1}))'.format(x, type(x)))
		
		if (x is None):
			x = _nps.plane(_nps._DEFAULT_PLANE)
		
		if (_nps.is_plane(x)):
			self._plane = copy.deepcopy(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			self._plane = _nps.plane(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00550.")
		
		pl = self._plane
		
		pl_woffset = self.getPlaneWidth() / 2.0
		pl_hoffset = self.getPlaneHeight() / 2.0
		pl_m = pl.matrix
		
		self._points = _ncs.point3list()
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([-pl_woffset,  pl_hoffset, 0.0])
		self._points.append([ pl_woffset,  pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([ pl_woffset,  pl_hoffset, 0.0])
		self._points.append([ pl_woffset, -pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([ pl_woffset, -pl_hoffset, 0.0])
		self._points.append([-pl_woffset, -pl_hoffset, 0.0])
		self._points.append([0.0, 0.0, 0.0])
		self._points.append([-pl_woffset, -pl_hoffset, 0.0])
		self._points.append([-pl_woffset,  pl_hoffset, 0.0])
		
		self._points = pl_m @ self._points
		
		# UnstructuredGrid.Piece
		
		piece_elemlist = self.retrieve('UnstructuredGrid.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00361.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# UnstructuredGrid.Piece.Points
			
			points_elemlist = self.retrieve('UnstructuredGrid.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00374.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(len(self._points)):
				pt = self._points[i]
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(len(self._points))
			
			# UnstructuredGrid.Piece.Cells
			
			cells_elemlist = self.retrieve('UnstructuredGrid.Piece.Cells')
			if (len(cells_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00702.")
			
			celem = cells_elemlist[0][1]
			array_elem = ET.SubElement(celem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(0, len(self._points), 3):
				if (i != 0):
					value_str += ' '
				value_str += '{0} {1} {2}'.format(i, i + 1, i + 2)
			array_elem.text = value_str
			
			array_elem = ET.SubElement(celem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(0, len(self._points), 3):
				if (i != 0):
					value_str += ' '
				value_str += '{0}'.format(i + 3)
			array_elem.text = value_str
			
			array_elem = ET.SubElement(celem, 'DataArray')
			array_elem.set('Name', 'types')
			array_elem.set('type', 'UInt32')
			array_elem.set('format', 'ascii')
			_VTK_TRIANGLE_ID = 5
			value_str = ''
			for i in range(0, len(self._points), 3):
				if (i != 0):
					value_str += ' '
				value_str += '{0}'.format(_VTK_TRIANGLE_ID)
			array_elem.text = value_str
			piece_elem.attrib['NumberOfCells'] = '{}'.format(int(len(self._points) / 3))
			
		if (nd.LIB_DEBUG):
			self.print('self')
		
		_n.ldprint('<-- nkj.vtk.plane.setPlane()')

	@property
	def plane(self):
		return self.getPlane()

	@plane.setter
	def plane(self, x):
		self.setPlane(x)

	# Model parameters

	def getPlaneWidth(self):
		return self._width

	def setPlaneWidth(self, x=None):
		self._width = _DEFAULT_PLANE_WIDTH if (x is None) else x

	def getPlaneHeight(self):
		return self._height

	def setPlaneHeight(self, x=None):
		self._height = _DEFAULT_PLANE_HEIGHT if (x is None) else x

	@property
	def planewidth(self):
		return self.getPlaneWidth()

	@planewidth.setter
	def planewidth(self, x):
		self.setPlaneWidth(x)

	@property
	def width(self):
		return self.getPlaneWidth()

	@width.setter
	def width(self, x):
		self.setPlaneWidth(x)

	@property
	def planeheight(self):
		return self.getPlaneHeight()

	@planeheight.setter
	def planeheight(self, x):
		self.setPlaneHeight(x)

	@property
	def height(self):
		return self.getPlaneHeight()

	@height.setter
	def height(self, x):
		self.setPlaneHeight(x)

class plane(plane_cls):
	pass

class plane3(plane_cls):
	pass


#-- Sphere class

class sphere_cls(polydata_cls):
	_classname = 'nkj.vtk.sphere'

class sphere(sphere_cls):
	pass

class sphere3(sphere_cls):
	pass


#-- Coordinate class

class coordinate_cls(polydata_cls):
	_classname = 'nkj.vtk.coordinate'

	def __new__(cls, x=None, axissize=_DEFAULT_CS_AXISSIZE):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None, axissize=_DEFAULT_CS_AXISSIZE):
		super().__init__()
		self._coordinates = None
		self._axissize = axissize
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x=None):
		self.setCS(_DEFAULT_CS if (x is None) else x)

	# Components

	def getAxisSize(self):
		return self._axissize

	def setAxisSize(self, s):
		self._axissize = s
		if (self._coordinates is not None):
			self.updateAxisSizeInXml()

	def getAxisLength(self):
		return self.getAxisSize()

	def setAxisLength(self, s):
		self.setAxisSize(s)

	@property
	def axissize(self):
		return self.getAxisSize()

	@axissize.setter
	def axissize(self, s):
		self.setAxisSize(s)

	@property
	def axislength(self):
		return self.getAxisLength()

	@axislength.setter
	def axislength(self, s):
		self.setAxisLength(s)

	@property
	def axislen(self):
		return self.getAxisLength()

	@axislen.setter
	def axislen(self, s):
		self.setAxisLength(s)

	def getPoints(self):
		return self._points

	@property
	def points(self):
		return self.getPoints()

	def getLines(self):
		return self._lines

	@property
	def lines(self):
		return self.getLines()

	# Coordinate lines

	def getCS(self):
		if (len(self._coordinates) == 0):
			return None
		elif (len(self._coordinates) == 1):
			return self._coordinates[0]
		else:
			raise Exception('__ERROR__: Illegal algorithm. NKJ-VTK-00812.')

	def setCS(self, x=None):
		_n.ldprint('--> nkj.vtk.coordinate.setCS({0} ({1})'.format(x, type(x)))
		
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		
		if (_ncs.is_mat3x4(x)):
			cs = copy.deepcopy(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			cs = _ncs.mat3x4(x)
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00822.")
		
		if (nd.LIB_DEBUG):
			cs.print('coordinate')
		
		self._coordinates = _ncs.mat3x4list()
		self._coordinates.append(cs)
		
		self._points = _ncs.vec3list()
		self._points.append(cs.origin)
		self._points.append(cs.origin + self.axislen * cs.xaxis)
		self._points.append(cs.origin)
		self._points.append(cs.origin + self.axislen * cs.yaxis)
		self._points.append(cs.origin)
		self._points.append(cs.origin + self.axislen * cs.zaxis)
		
		if (nd.LIB_DEBUG):
			self._points.print('self._points')
		
		self._lines = _nps.line3list()
		self._lines.append(_nps.line3([cs.origin, self.axislen * cs.xaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		self._lines.append(_nps.line3([cs.origin, self.axislen * cs.yaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		self._lines.append(_nps.line3([cs.origin, self.axislen * cs.zaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		
		# PolyData.Piece
		
		piece_elemlist = self.retrieve('PolyData.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00243.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# PolyData.Piece.Points
			
			points_elemlist = self.retrieve('PolyData.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00858.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(len(self._points)):
				pt = self._points[i]
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 0.0
			value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 3.0
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(len(self._points) + 2)
			
			# PolyData.Piece.Lines
			
			lines_elemlist = self.retrieve('PolyData.Piece.Lines')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00879.")
			
			lelem = lines_elemlist[0][1]
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			nlines = 0
			for i in range(0, len(self._points), 2):
				if (i != 0):
					value_str += ' '
				value_str += '{0} {1}'.format(i, i + 1)
				nlines += 1
			array_elem.text = value_str
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(nlines):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(2 * (i + 1))
			array_elem.text = value_str
			piece_elem.attrib['NumberOfLines'] = '{}'.format(nlines)
			
			#
			# 色は，赤:3.0，黄色: 1.6，水色: 0.8 あたりが妥当．
			#
			
			# PolyData.Piece.PointData
			
			pdata_elemlist = self.retrieve('PolyData.Piece.PointData')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00928.")
			
			pdelem = pdata_elemlist[0][1]
			pdelem.set('Scalars', 'point value')
			
			array_elem = ET.SubElement(pdelem, 'DataArray')
			array_elem.set('Name', 'point value')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			_RED = 2.8
			_YELLOW = 1.6
			_LIGHTBLUE = 0.8
			value_str = '{}'.format(_RED)
			value_str += ' {}'.format(_RED)
			value_str += ' {}'.format(_LIGHTBLUE)
			value_str += ' {}'.format(_LIGHTBLUE)
			value_str += ' {}'.format(_YELLOW)
			value_str += ' {}'.format(_YELLOW)
			value_str += ' {}'.format(0.0)
			value_str += ' {}'.format(3.0)
			array_elem.text = value_str
			
		if (nd.LIB_DEBUG):
			self.print('self')
		_n.ldprint('<-- nkj.vtk.coordinate.setCS()')

	def updateAxisSizeInXml(self):
		_n.ldprint('--> nkj.vtk.coordinate.updateAxisSizeInXml()')
		
		if (len(self._coordinates) == 0):
			return
		
		cs = self._coordinates[0]
		
		self._points.clear()
		self._points.append(cs.origin)
		self._points.append(cs.origin + self.axislen * cs.xaxis)
		self._points.append(cs.origin)
		self._points.append(cs.origin + self.axislen * cs.yaxis)
		self._points.append(cs.origin)
		self._points.append(cs.origin + self.axislen * cs.zaxis)
		
		self._lines.clear()
		self._lines.append(_nps.line3([cs.origin, self.axislen * cs.xaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		self._lines.append(_nps.line3([cs.origin, self.axislen * cs.yaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		self._lines.append(_nps.line3([cs.origin, self.axislen * cs.zaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		
		elemlist = self.retrieve('PolyData.Piece.Points.DataArray')
		if (len(elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-01024.")
		array_elem = elemlist[0][1]
		value_str = ''
		for i in range(len(self._points)):
			pt = self._points[i]
			if (i != 0):
				value_str += ' '
			value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
		value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 0.0
		value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 3.0
		array_elem.text = value_str
		
		_n.ldprint('<-- nkj.vtk.coordinate.updateAxisSizeInXml()')

	@property
	def coordinate(self):
		return self.getCS()

	@coordinate.setter
	def coordinate(self, x):
		self.setCS(x)

	@property
	def cs(self):
		return self.getCS()

	@cs.setter
	def cs(self, x):
		self.setCS(x)

class coordinate(coordinate_cls):
	pass

class coordinate3(coordinate_cls):
	pass

class cs(coordinate_cls):
	pass

class cs3(coordinate_cls):
	pass


class coordinates_cls(polydata_cls):
	_classname = 'nkj.vtk.coordinates'

	def __new__(cls, x=None, axissize=_DEFAULT_CS_AXISSIZE):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None, axissize=_DEFAULT_CS_AXISSIZE):
		super().__init__()
		self._coordinates = None
		self._axissize = axissize
		self.set(x)

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def set(self, x=None):
		self.setCSlist(_DEFAULT_CS if (x is None) else x)

	# Components

	def getAxisSize(self):
		return self._axissize

	def setAxisSize(self, s):
		self._axissize = s
		if (self._coordinates is not None):
			self.updateAxisSizeInXml()

	def getAxisLength(self):
		return self.getAxisSize()

	def setAxisLength(self, s):
		self.setAxisSize(s)

	@property
	def axissize(self):
		return self.getAxisSize()

	@axissize.setter
	def axissize(self, s):
		self.setAxisSize(s)

	@property
	def axislength(self):
		return self.getAxisLength()

	@axislength.setter
	def axislength(self, s):
		self.setAxisLength(s)

	@property
	def axislen(self):
		return self.getAxisLength()

	@axislen.setter
	def axislen(self, s):
		self.setAxisLength(s)

	def getPoints(self):
		return self._points

	@property
	def points(self):
		return self.getPoints()

	def getLines(self):
		return self._lines

	@property
	def lines(self):
		return self.getLines()

	# Coordinate lines

	def getCSlist(self):
		return None if (len(self._coordinates) == 0) else self._coordinates

	def setCSlist(self, x=None):
		_n.ldprint('--> nkj.vtk.polydata.setCS({0} ({1}))'.format(x, type(x)))
		
		if (x is None):
			raise Exception('__ERROR__: Null input.')
		
		if (_ncs.is_mat3x4list(x)):
			self._coordinates = copy.deepcopy(x)
		elif (_ncs.is_mat3x4(x)):
			self._coordinates = _ncs.mat3x4list()
			self._coordinates.append(x)
		elif (isinstance(x, (list, tuple, np.ndarray))):
			self._coordinates = _ncs.mat3x4list()
			if (len(x) == 0):
				return
			if (_ncs.is_mat3x4(x[0])):
				self._coordinates.append(x[0])
			elif (isinstance(x[0], (list, tuple, np.ndarray))):
				for c in x:
					self._coordinates.append(_ncs.mat3x4(c))
			else:
				raise Exception('__ERROR__: Unsupport data.')
		else:
			raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00822.")
		
		if (nd.LIB_DEBUG):
			self._coordinates.print('coordinates')
		
		self._points = _ncs.vec3list()
		for cs in self._coordinates:
			self._points.append(cs.origin)
			self._points.append(cs.origin + self.axislen * cs.xaxis)
			self._points.append(cs.origin)
			self._points.append(cs.origin + self.axislen * cs.yaxis)
			self._points.append(cs.origin)
			self._points.append(cs.origin + self.axislen * cs.zaxis)
		
		if (nd.LIB_DEBUG):
			self._points.print('self._points')
		
		self._lines = _nps.line3list()
		for cs in self._coordinates:
			self._lines.append(_nps.line3([cs.origin, self.axislen * cs.xaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
			self._lines.append(_nps.line3([cs.origin, self.axislen * cs.yaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
			self._lines.append(_nps.line3([cs.origin, self.axislen * cs.zaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		
		# PolyData.Piece
		
		piece_elemlist = self.retrieve('PolyData.Piece')
		
		if (len(piece_elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00243.")
		
		for e in piece_elemlist:  # e = piece_elemlist[0] と等価
			piece_tag = e[0]
			piece_elem = e[1]
			_n.ldprint2('\'{0}\'.attrib: from: {1}'.format(piece_tag, piece_elem.attrib))
			if (nd.LIB_DEBUG):
				x.print('class name: \'{}\''.format(x.__class__.__name__))
			
			# PolyData.Piece.Points
			
			points_elemlist = self.retrieve('PolyData.Piece.Points')
			if (len(points_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00858.")
			
			pelem = points_elemlist[0][1]
			array_elem = ET.SubElement(pelem, 'DataArray')
			array_elem.set('Name', 'points')
			array_elem.set('NumberOfComponents', '3')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(len(self._points)):
				pt = self._points[i]
				if (i != 0):
					value_str += ' '
				value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
			value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 0.0
			value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 3.0
			array_elem.text = value_str
			piece_elem.attrib['NumberOfPoints'] = '{}'.format(len(self._points) + 2)
			
			# PolyData.Piece.Lines
			
			lines_elemlist = self.retrieve('PolyData.Piece.Lines')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00879.")
			
			lelem = lines_elemlist[0][1]
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'connectivity')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			nlines = 0
			for i in range(0, len(self._points), 2):
				if (i != 0):
					value_str += ' '
				value_str += '{0} {1}'.format(i, i + 1)
				nlines += 1
			array_elem.text = value_str
			array_elem = ET.SubElement(lelem, 'DataArray')
			array_elem.set('Name', 'offsets')
			array_elem.set('type', 'Int32')
			array_elem.set('format', 'ascii')
			value_str = ''
			for i in range(nlines):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(2 * (i + 1))
			array_elem.text = value_str
			piece_elem.attrib['NumberOfLines'] = '{}'.format(nlines)
			
			#
			# 色は，赤:3.0，黄色: 1.6，水色: 0.8 あたりが妥当．
			#
			
			# PolyData.Piece.PointData
			
			pdata_elemlist = self.retrieve('PolyData.Piece.PointData')
			if (len(lines_elemlist) != 1):
				raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-00928.")
			
			pdelem = pdata_elemlist[0][1]
			pdelem.set('Scalars', 'point value')
			
			array_elem = ET.SubElement(pdelem, 'DataArray')
			array_elem.set('Name', 'point value')
			array_elem.set('type', 'Float32')
			array_elem.set('format', 'ascii')
			_RED = 2.8
			_YELLOW = 1.6
			_LIGHTBLUE = 0.8
			value_str = ''
			for i in range(len(self._coordinates)):
				if (i != 0):
					value_str += ' '
				value_str += '{}'.format(_RED)
				value_str += ' {}'.format(_RED)
				value_str += ' {}'.format(_LIGHTBLUE)
				value_str += ' {}'.format(_LIGHTBLUE)
				value_str += ' {}'.format(_YELLOW)
				value_str += ' {}'.format(_YELLOW)
			value_str += ' {}'.format(0.0)
			value_str += ' {}'.format(3.0)
			array_elem.text = value_str
			
		if (nd.LIB_DEBUG):
			self.print('self')
		_n.ldprint('<-- nkj.vtk.polydata.setCS()')

	def updateAxisSizeInXml(self):
		_n.ldprint('--> nkj.vtk.coordinates.updateAxisSizeInXml()')
		
		if (len(self._coordinates) == 0):
			return
		
		_n.ldprint('axislen: {}'.format(self.axislen))
		
		self._points.clear()
		for cs in self._coordinates:
			self._points.append(cs.origin)
			self._points.append(cs.origin + self.axislen * cs.xaxis)
			self._points.append(cs.origin)
			self._points.append(cs.origin + self.axislen * cs.yaxis)
			self._points.append(cs.origin)
			self._points.append(cs.origin + self.axislen * cs.zaxis)
		
		self._lines.clear()
		for cs in self._coordinates:
			self._lines.append(_nps.line3([cs.origin, self.axislen * cs.xaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
			self._lines.append(_nps.line3([cs.origin, self.axislen * cs.yaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
			self._lines.append(_nps.line3([cs.origin, self.axislen * cs.zaxis], _nps.LINE_SETTINGFLAG_ORIGINANDVECTOR))
		
		elemlist = self.retrieve('PolyData.Piece.Points.DataArray')
		if (len(elemlist) != 1):
			raise Exception("__ERROR__: Illegal algorithm. NKJ-VTK-01318.")
		array_elem = elemlist[0][1]
		value_str = ''
		for i in range(len(self._points)):
			pt = self._points[i]
			if (i != 0):
				value_str += ' '
			value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(pt.x, pt.y, pt.z)
		value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 0.0
		value_str += '{0:.3f} {1:.3f} {2:.3f}'.format(0.0, 0.0, 0.0)  # Dummy point for PointData for color 3.0
		array_elem.text = value_str
		
		_n.ldprint('<-- nkj.vtk.coordinates.updateAxisSizeInXml()')

	@property
	def coordinates(self):
		return self.getCSlist()

	@coordinates.setter
	def coordinates(self, x):
		self.setCSlist(x)

	@property
	def coordinatelist(self):
		return self.getCSlist()

	@coordinatelist.setter
	def coordinatelist(self, x):
		self.setCSlist(x)

class coordinates(coordinates_cls):
	pass

class coordinate3s(coordinates_cls):
	pass

class coordinatelist(coordinates_cls):
	pass

class coordinate3list(coordinates_cls):
	pass


#-- Functions

_VTK_DATAFILE_HEADER = _DEFAULT_VTK_LEAGACY_DATAFILE_HEADER

def file_header(x=None):
	global _VTK_DATAFILE_HEADER
	if (x is None):
		return _VTK_DATAFILE_HEADER
	elif (isinstance(x, str)):
		_VTK_DATAFILE_HEADER = x
	else:
		raise TypeError("__ERROR__: Illegal data type. NKJ-VTK-00211.")

def fileheader(x=None):
	return file_header(x)

def saveVtkFile(filename, x):
	if (_ncs.is_point3(x)):
		return savePoint3VtkFile(filename, x)
	elif (_ncs.is_point3list(x)):
		return savePoint3listVtkFile(filename, x)
	else:
		raise TypeError("__ERROR__: Not supported. NKJ-VTK-00222.")

def savePoint3VtkFile(filename, x):  # point3
	try:
		with open(filename, 'w') as f:
			f.write(file_header())
	except Exception as e:
		_n.printerr(e)
		return False

def savePoint3listVtkFile(filename, x):  # point3list
	try:
		with open(filename, 'w') as f:
			f.write(file_header())
	except Exception as e:
		_n.printerr(e)
		return False


#-- Lib main

if __name__ == '__main__':
	_LIB_DEBUGLEVEL = 0
	_n.lib_debuglevel(_LIB_DEBUGLEVEL)
	_n.ldprint("DEBUGLEVEL: {}".format(_n.lib_debuglevel()))

	if (True):
		_VTK_TESTFILENAME = "./test.data/test_vtk.vtp"
		poly = polydata()
		poly.print(_VTK_TESTFILENAME)
		poly.save(_VTK_TESTFILENAME)

	if (True):
		print('\n-- Points')
		_VTK_TESTPOINTFILENAME = "./test.data/test_points.vtp"
		poly = points([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0], [7.0, 8.0, 9.0]])
		poly.print(_VTK_TESTPOINTFILENAME)
		poly.save(_VTK_TESTPOINTFILENAME)

	if (True):
		print('\n-- Line')
		_VTK_TESTLINEFILENAME = "./test.data/test_line.vtp"
		poly = line([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
		poly.print(_VTK_TESTLINEFILENAME)
		poly.save(_VTK_TESTLINEFILENAME)

	if (True):
		print('\n-- WirePlane')
		_VTK_TESTPLANEFILENAME = "./test.data/test_wireplane.vtp"
		_VTK_PLANEWIDTH = 15.0
		_VTK_PLANEHEIGHT = 10.0
		poly = wireplane(None, [_VTK_PLANEWIDTH, _VTK_PLANEHEIGHT])
		poly.print(_VTK_TESTPLANEFILENAME)
		poly.save(_VTK_TESTPLANEFILENAME)

	if (True):
		print('\n-- Plane')
		_VTK_TESTPLANEFILENAME = "./test.data/test_plane.vtp"
		_VTK_PLANEWIDTH = 15.0
		_VTK_PLANEHEIGHT = 10.0
		poly = plane(None, [_VTK_PLANEWIDTH, _VTK_PLANEHEIGHT])
		poly.print(_VTK_TESTPLANEFILENAME)
		poly.save(_VTK_TESTPLANEFILENAME)

	if (True):
		print('\n-- Lines')
		_VTK_TESTLINESFILENAME = "./test.data/test_lines.vtp"
		poly = lines([[[1.1, 2.1, 3.1], [4.1, 5.1, 6.1]], [[4.1, 5.1, 6.1], [7.1, 8.1, 9.1]]])
		poly.print(_VTK_TESTLINESFILENAME)
		poly.save(_VTK_TESTLINESFILENAME)

	if (True):
		print('\n-- Coordinate')
		_VTK_TESTCSFILENAME = "./test.data/test_cs.vtp"
		poly = coordinate()
		poly.print(_VTK_TESTCSFILENAME)
		poly.save(_VTK_TESTCSFILENAME)
		
		m = _ncs.mat3x4()
		m.rotatex(_nm.deg2rad(45.0))
		m.translate([1.0, 2.0, 3.0])
		_AXISLENGTH = 10.0
		_VTK_TESTCSFILENAME2 = "./test.data/test_cs2.vtp"
		poly = coordinate(m, _AXISLENGTH)
		poly.print(_VTK_TESTCSFILENAME2)
		poly.save(_VTK_TESTCSFILENAME2)

	if (True):
		print('\n-- Coordinates')
		mlist = _ncs.mat3x4list()
		m = _ncs.mat3x4()
		mlist.append(m)
		m.rotatex(_nm.deg2rad(45.0))
		m.translate([1.0, 2.0, 3.0])
		mlist.append(m)
		m.translate([1.0, 2.0, 3.0])
		mlist.append(m)
		_VTK_TESTCSLISTFILENAME = "./test.data/test_cslist.vtp"
		_AXISLENGTH = 10.0
		poly = coordinates(mlist)
		poly.axislen = _AXISLENGTH  # 座標軸長を指定する別の方法
		poly.print(_VTK_TESTCSLISTFILENAME)
		poly.save(_VTK_TESTCSLISTFILENAME)
