#
# [name] nkj.xml.py
# [exec] python -m nkj.xml && cat ./testdata/test.xml ./testdata/test2.xml
#
# Written by Yoshikazu NAKAJIMA
#
import re
import copy
from xml.dom import minidom
import xml.etree.ElementTree as ET
import nkj as _n
import nkj.str as _ns

_DEFAULT_XML_ROOTELEMENT_INDEX = 'root'
_DEFAULT_XML_HEADER = "<?xml version=\"1.0\"?>\n"

_XML_USE_RESPLIT = True
if (_XML_USE_RESPLIT):
	_XML_SPLIT_CHAR = '[/.]'  # re.split()
else:
	_XML_SPLIT_CHAR = '.'     # (Standard) str.split()

nd = _n.LibDebugFlag()

#-- Class

class elementtree_cls():
	_classname = 'nkj.xml.elementtree'

	def __new__(cls, x=None):
		self = super().__new__(cls)
		return self

	def __init__(self, x=None):
		self.setRootIndex(_DEFAULT_XML_ROOTELEMENT_INDEX if (x is None) else x)
		self.setRoot(ET.Element(self.getRootIndex()))

	@classmethod
	def getClassName(cls):
		return cls._classname

	@classmethod
	@property
	def classname(cls):
		return cls.getClassName()

	def setRootIndex(self, index):
		self._rootindex = index

	def getRootIndex(self):
		return self._rootindex

	def setRoot(self, r):
		self._root = r

	def getRoot(self):
		return self._root

	@property
	def root(self):
		return self.getRoot()

	@root.setter
	def root(self, r):
		self.setRoot(r)

	# element operations

	def searchElements(self, tag='*'):
		_n.ldprint('--> nkj.xml.elementtree.searchElements(, tag:\'{}\')'.format(tag))
		
		if (tag is None):
			return None
		def _search_subelem(patientelem, patientelemtag, taglist):
			_n.ldprint2('--> nkj.xml._search_subelem({0}, \'{1}\', {2})'.format(patientelem, patientelemtag, taglist))
			
			elemdata = []
			if (len(taglist) == 0):
				raise Except("__ERROR__: Illegal algorithm.")
			elif (len(taglist) == 1):
				_n.ldprint2('--> Search single component of taglist.')
				tag = taglist[0]
				_n.ldprint2('searching tag: \'{}\''.format(tag))
				if (tag == '*'):
					_n.ldprint2('--> Search tag(\'{}\')'.format('*'))
					elemlist = patientelem.findall(tag)
					if (len(elemlist) == 0):
						_n.ldprint3('Null elemlist')
						_n.ldprint2('patientelem.tag: \'{}\''.format(patientelemtag))
						elemdata = [[patientelemtag, patientelem]]
					else:
						for e in elemlist:
							elemtag = patientelemtag + '.{}'.format(e.tag)
							elemdata += _search_subelem(e, elemtag, taglist)
					_n.ldprint('elemdata: {}'.format(elemdata))
					_n.ldprint2('<-- Search tag(\'{}\')'.format('*'))
				else:
					elemtag = patientelemtag + '.{}'.format(tag)
					_n.ldprint2('elemtag:       \'{}\''.format(elemtag))
					elemlist = patientelem.findall(tag)
					if (len(elemlist) == 0):
						_n.ldprint3('Null elemlist')
						_n.ldprint2('patientelem.tag: \'{}\''.format(patientelemtag))
						elemdata = [[patientelemtag, patientelem]]
					else:
						for e in elemlist:
							elemtag = patientelemtag + '.{}'.format(e.tag)
							elemdata += _search_subelem(e, elemtag, taglist)
				_n.ldprint2('<-- Search single component of taglist.')
			else:
				elemlist = patientelem.findall(taglist[0])
				sub_taglist = taglist[1:]
				elemdata = []
				for e in elemlist:
					elemtag = patientelemtag + '.{}'.format(e.tag)
					elemdata += _search_subelem(e, elemtag, sub_taglist)
			_n.ldprint2('<-- nkj.xml._search_subelem()')
			return elemdata
		
		if (tag == '*'):
			elemdata = _search_subelem(self.root, '', [tag])
		elif (tag[0] == '.'):
			taglist = re.split(_XML_SPLIT_CHAR, tag) if (_XML_USE_RESPLIT) else tag.split(_XML_SPLIT_CHAR)
			taglist = taglist[1:]
			elemdata = _search_subelem(self.root, '<ROOT>', taglist)
		else:  # Start at subelement
			_n.ldprint('--> Start at sub-element')
			taglist = re.split(_XML_SPLIT_CHAR, tag) if (_XML_USE_RESPLIT) else tag.split(_XML_SPLIT_CHAR)
			_n.ldprint3('tag list:    {}'.format(taglist))
			_n.ldprint3('tag list[0]: \'{}\''.format(taglist[0]))
			elemlist = self.root.iter(taglist[0])
			taglist = taglist[1:]
			elemdata = []
			for e in elemlist:
				_n.ldprint2('element:     {}'.format(e))
				_n.ldprint2('element.tag: \'{}\''.format(e.tag))
				_n.ldprint2('tag list:    {}'.format(taglist))
				elemdata += _search_subelem(e, e.tag, taglist)
			_n.ldprint('<-- Start at sub-element')
		
		if (nd.LIB_DEBUG2):
			print('len(elemdata): {}'.format(len(elemdata)))
			for i in range(len(elemdata)):
				print('elemdata[{0}]:     \'{1}\''.format(i, elemdata[i]))
		
		_n.ldprint('<-- nkj.xml.elementtree.searchElements()')
		return elemdata

	def searchElem(self, tag='*'):
		return self.searchElements(tag)

	def searchelem(self, tag='*'):
		return self.searchElements(tag)

	def search(self, tag='*'):
		return self.searchElements(tag)

	def retrieveElements(self, tag='*'):
		return self.searchElements(tag)

	def retrieveElem(self, tag='*'):
		return self.searchElements(tag)

	def retrieveelem(self, tag='*'):
		return self.searchElements(tag)

	def retrieve(self, tag='*'):
		return self.searchElements(tag)

	def getElements(self, tag='*'):
		return self.searchElements(tag)

	def getElem(self, tag='*'):
		return self.getElements(tag)

	def getelem(self, tag='*'):
		return self.getElements(tag)

	def get(self, tag='*'):
		return self.getElements(tag)

	def iter(self, tag='*'):
		return self.searchElements(tag)

	# print

	def getPrintString(self, title=None):
		root_p = copy.deepcopy(self.root)
		ET.indent(root_p, space='  ')  # 適切な改行およびインデントを追加して、Element Tree を整形
		s = ''
		if (title is not None):
			s += '----- {} -----\n'.format(title)
		s += ET.tostring(root_p, encoding='unicode')
		s += '\n'
		if (title is not None):
			s += '-----\n'
		return s

	def getPrintStr(self, title=None):
		return self.getPrintString(title)

	@property
	def printstr(self):
		return self.getPrintString()

	@property
	def pstr(self):
		return self.getPrintString()

	def print(self, title=None):
		print(self.getPrintString(title), flush=True, end='')

	# load, save

	def load(self, filename):
		try:
			tree = ET.parse(filename)
			self.setRoot(tree.getroot())
		except Exception as e:
			raise Exception('__ERROR__: Loading file \'{}\' was failed.'.format(filename))

	def _prettify(self, rough_string):  # 空白行などを削除して、ElementTree を整形
		reparsed = minidom.parseString(rough_string)
		pretty = re.sub(r"[\t ]+\n", "", reparsed.toprettyxml(indent="\t"))  # インデント後の不要な改行を削除
		pretty = pretty.replace(">\n\n\t<", ">\n\t<")  # 不要な空行を削除
		pretty = re.sub(r"\n\s*\n", "\n", pretty)  # 連続した改行（空白行を含む）を単一の改行に置換
		pretty = pretty.replace("\n", "")  # 空白行を削除
		pretty = pretty.replace("\t", "")  # タブを削除
		return pretty

	def save(self, filename):
		try:
			doc = minidom.parseString(self._prettify(ET.tostring(self.getRoot(), 'utf-8')))
			with open(filename, 'w') as f:
				doc.writexml(f, encoding='utf-8', newl='\n', indent='', addindent='  ')
		except Exception as e:
			raise Exception('__ERROR__: Can\'t save file \'{}\'.'.format(filename))
	
class elementtree(elementtree_cls):
	pass

class elemtree(elementtree_cls):
	pass

class elements(elementtree_cls):
	pass

class et(elementtree_cls):
	pass


#-- Lib main

if __name__ == '__main__':
	_LIB_DEBUGLEVEL = 1
	_n.lib_debuglevel(_LIB_DEBUGLEVEL)
	_n.ldprint("DEBUGLEVEL: {}".format(_n.lib_debuglevel()))
	
	#
	# nkj.elementtree クラス (xml.etree.EmelentTree クラスを継承) の説明
	#
	# <elem>.set('attribute title', 'attribute value') で属性の設定
	# <elem>.text = 'element value' で値の設定
	#
	
	if (True):
		et = elemtree()
		elem1 = ET.SubElement(et.root, 'elem1')
		elem2 = ET.SubElement(elem1, 'elem2')
		
		# 子ノードを追加
		elem3_1 = ET.SubElement(elem2, 'elem3')
		elem3_1.set('attr1','1234')
		elem3_1.set('attr2','abcd')
		elem3_1.text = 'value1'
		
		# 子ノードを追加
		elem3_2 = ET.SubElement(elem2, 'elem4')
		elem3_2.set('attr1','5678')
		elem3_2.set('attr2','efgh')
		elem3_2.text = 'value2'
		
		et.print("Test XML Element Tree")
		
		if (True):
			_TEST_XMLFILE = "./testdata/test.xml"
			et.save(_TEST_XMLFILE)
			
			et2 = elemtree()
			et2.load(_TEST_XMLFILE)
			
			et2.print("Test XML Element Tree")
			
			et2.save("./testdata/test2.xml")

		if (True):
			et = elemtree()
			et.load(_TEST_XMLFILE)
			
			print('')
			elist = et.retrieve()
			print('-- elist[{}] --'.format(len(elist)))
			for i in range(len(elist)):
				print('elem[{0}]: tag=\'{1}\', {2}'.format(i, elist[i][0], elist[i][1]))
			print('--')
			
			print('')
			elist = et.retrieve('.elem1.elem2.elem4')
			print('-- elist[{}] --'.format(len(elist)))
			for i in range(len(elist)):
				print('elem[{0}]: tag=\'{1}\', {2}'.format(i, elist[i][0], elist[i][1]))
			print('--')
			
			print('')
			elist = et.retrieve('elem2.elem4')
			print('-- elist[{}] --'.format(len(elist)))
			for i in range(len(elist)):
				print('elem[{0}]: tag=\'{1}\', {2}'.format(i, elist[i][0], elist[i][1]))
			print('--')
