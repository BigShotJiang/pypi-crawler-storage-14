"""Authentication handling."""
