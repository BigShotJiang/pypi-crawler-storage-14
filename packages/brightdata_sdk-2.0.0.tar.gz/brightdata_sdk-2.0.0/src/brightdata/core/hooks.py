"""Event hooks system."""
