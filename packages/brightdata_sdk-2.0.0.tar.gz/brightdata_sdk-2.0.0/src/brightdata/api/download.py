"""Download/snapshot operations."""
