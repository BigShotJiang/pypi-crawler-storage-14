"""Browser API."""
