# Changelog

All notable changes to GRNexus will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.3] - 2025-11-27

### Changed
- Reorganized package structure for better professionalism
- Moved examples to dedicated `examples/` directory
- Renamed `test/` to `tests/` following Python conventions
- Updated all tests to use installed PyPI package instead of local files
- Created `docs/` directory for documentation

### Fixed
- Tests now properly import from installed `grnexus` package
- Removed hardcoded `sys.path` manipulations in tests

## [0.1.2] - 2025-11-27

### Added
- Native C libraries included in package for all platforms
  - macOS: `.dylib` files
  - Windows: `.dll` files
  - Linux: `.so` files
- Multi-platform support with automatic library detection

### Changed
- Package size increased to ~259 KB (wheel) due to native libraries
- Improved library path detection for both development and installed environments

### Fixed
- ModuleNotFoundError when trying to load native libraries
- Library detection now works in both development and production

## [0.1.1] - 2025-11-27

### Fixed
- Import errors due to absolute imports
- Changed to relative imports (`.lib` instead of `lib`)

### Known Issues
- Native C libraries not included in package

## [0.1.0] - 2025-11-27

### Added
- Initial release on PyPI
- Complete neural network implementation
- 50+ activation functions
- Multiple optimizers (SGD, Adam, RMSprop)
- Model persistence in `.nexus` format
- Keras-like API

### Known Issues
- Import errors due to incorrect import paths
- Native libraries not included
