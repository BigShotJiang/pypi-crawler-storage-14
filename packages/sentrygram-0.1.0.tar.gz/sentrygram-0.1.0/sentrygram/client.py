# ABOUTME: Sentrygram API client for sending alerts.
# ABOUTME: Supports message levels (info, warning, error, critical) and context.

from enum import Enum
from typing import Optional, Dict, Any
import requests


class AlertLevel(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class SentrygramError(Exception):
    """Base exception for Sentrygram errors."""
    pass


class RateLimitError(SentrygramError):
    """Raised when rate limited."""
    def __init__(self, retry_after: Optional[int] = None):
        self.retry_after = retry_after
        super().__init__(f"Rate limited. Retry after {retry_after} seconds." if retry_after else "Rate limited.")


class NotificationsPausedError(SentrygramError):
    """Raised when notifications are paused."""
    def __init__(self):
        super().__init__("Notifications are paused. Reactivate at sentrygram.com")


class Sentrygram:
    """Sentrygram client for sending alerts to Telegram."""

    DEFAULT_BASE_URL = "https://api.sentrygram.com"

    def __init__(self, api_key: str, base_url: Optional[str] = None):
        """
        Initialize the Sentrygram client.

        Args:
            api_key: Your Sentrygram API key (starts with sk_)
            base_url: Optional custom API URL (for self-hosted or testing)
        """
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def alert(
        self,
        message: str,
        level: Optional[AlertLevel] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """
        Send an alert to your linked Telegram.

        Args:
            message: The alert message
            level: Optional severity level (info, warning, error, critical)
            context: Optional dict of additional context

        Returns:
            True if alert was sent successfully

        Raises:
            RateLimitError: If rate limited (10/min burst limit)
            NotificationsPausedError: If notifications are paused
            SentrygramError: For other API errors
        """
        payload = {"message": message}

        if level:
            payload["level"] = level.value if isinstance(level, AlertLevel) else level

        if context:
            payload["context"] = context

        response = self._session.post(f"{self.base_url}/v1/alert", json=payload)

        if response.status_code == 200:
            return True

        if response.status_code == 429:
            try:
                detail = response.json().get("detail", {})
                error_type = detail.get("error")
                if error_type == "notifications_paused":
                    raise NotificationsPausedError()
                raise RateLimitError(retry_after=detail.get("retry_after"))
            except (ValueError, KeyError):
                raise RateLimitError()

        if response.status_code == 401:
            raise SentrygramError("Invalid API key")

        if response.status_code == 400:
            try:
                detail = response.json().get("detail", {})
                if detail.get("error") == "telegram_not_linked":
                    raise SentrygramError("Telegram not linked. Visit sentrygram.com to link your account.")
            except (ValueError, KeyError):
                pass
            raise SentrygramError(f"Bad request: {response.text}")

        raise SentrygramError(f"API error ({response.status_code}): {response.text}")
