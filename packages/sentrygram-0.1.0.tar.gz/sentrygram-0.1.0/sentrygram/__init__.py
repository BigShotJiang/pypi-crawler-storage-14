# ABOUTME: Sentrygram Python SDK - send alerts to your Telegram.
# ABOUTME: Simple client for the Sentrygram API.

from .client import Sentrygram, AlertLevel

__version__ = "0.1.0"
__all__ = ["Sentrygram", "AlertLevel"]
