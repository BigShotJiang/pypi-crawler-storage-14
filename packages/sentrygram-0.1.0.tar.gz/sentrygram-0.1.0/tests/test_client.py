# ABOUTME: Tests for the Sentrygram Python SDK.
# ABOUTME: Tests client initialization and alert sending.

import pytest
from unittest.mock import patch, MagicMock

from sentrygram import Sentrygram, AlertLevel
from sentrygram.client import RateLimitError, NotificationsPausedError, SentrygramError


class TestSentrygramInit:
    def test_requires_api_key(self):
        with pytest.raises(ValueError, match="API key is required"):
            Sentrygram("")

    def test_sets_default_base_url(self):
        client = Sentrygram("sk_test123")
        assert client.base_url == "https://api.sentrygram.com"

    def test_custom_base_url(self):
        client = Sentrygram("sk_test123", base_url="https://custom.example.com/")
        assert client.base_url == "https://custom.example.com"


class TestAlert:
    @patch("sentrygram.client.requests.Session")
    def test_sends_simple_alert(self, mock_session_class):
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_session.post.return_value = mock_response

        client = Sentrygram("sk_test123")
        result = client.alert("Test message")

        assert result is True
        mock_session.post.assert_called_once()
        call_args = mock_session.post.call_args
        assert call_args[0][0] == "https://api.sentrygram.com/v1/alert"
        assert call_args[1]["json"] == {"message": "Test message"}

    @patch("sentrygram.client.requests.Session")
    def test_sends_alert_with_level(self, mock_session_class):
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_session.post.return_value = mock_response

        client = Sentrygram("sk_test123")
        client.alert("Error occurred", level=AlertLevel.ERROR)

        call_args = mock_session.post.call_args
        assert call_args[1]["json"] == {"message": "Error occurred", "level": "error"}

    @patch("sentrygram.client.requests.Session")
    def test_sends_alert_with_context(self, mock_session_class):
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_session.post.return_value = mock_response

        client = Sentrygram("sk_test123")
        client.alert("User signup", context={"user_id": 123, "email": "test@example.com"})

        call_args = mock_session.post.call_args
        assert call_args[1]["json"] == {
            "message": "User signup",
            "context": {"user_id": 123, "email": "test@example.com"}
        }

    @patch("sentrygram.client.requests.Session")
    def test_raises_rate_limit_error(self, mock_session_class):
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.json.return_value = {"detail": {"error": "rate_limit", "retry_after": 30}}
        mock_session.post.return_value = mock_response

        client = Sentrygram("sk_test123")
        with pytest.raises(RateLimitError) as exc_info:
            client.alert("Test")
        assert exc_info.value.retry_after == 30

    @patch("sentrygram.client.requests.Session")
    def test_raises_notifications_paused_error(self, mock_session_class):
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_response.json.return_value = {"detail": {"error": "notifications_paused"}}
        mock_session.post.return_value = mock_response

        client = Sentrygram("sk_test123")
        with pytest.raises(NotificationsPausedError):
            client.alert("Test")

    @patch("sentrygram.client.requests.Session")
    def test_raises_invalid_api_key_error(self, mock_session_class):
        mock_session = MagicMock()
        mock_session_class.return_value = mock_session
        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_session.post.return_value = mock_response

        client = Sentrygram("sk_invalid")
        with pytest.raises(SentrygramError, match="Invalid API key"):
            client.alert("Test")
