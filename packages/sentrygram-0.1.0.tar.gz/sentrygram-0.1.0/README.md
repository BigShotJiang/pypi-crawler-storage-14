# Sentrygram Python SDK

Send alerts to your Telegram with one line of code.

## Installation

```bash
pip install sentrygram
```

## Quick Start

```python
from sentrygram import Sentrygram

# Initialize with your API key
client = Sentrygram("sk_your_api_key")

# Send a simple alert
client.alert("Deployment completed successfully!")

# Send with severity level
client.alert("Database connection failed", level="error")

# Send with context
client.alert(
    "New user signup",
    level="info",
    context={"user_id": 123, "plan": "pro"}
)
```

## Alert Levels

- `info` - Informational messages (blue)
- `warning` - Warning messages (yellow)
- `error` - Error messages (red)
- `critical` - Critical alerts (red)

```python
from sentrygram import Sentrygram, AlertLevel

client = Sentrygram("sk_your_api_key")
client.alert("Server is down!", level=AlertLevel.CRITICAL)
```

## Error Handling

```python
from sentrygram import Sentrygram
from sentrygram.client import RateLimitError, NotificationsPausedError, SentrygramError

client = Sentrygram("sk_your_api_key")

try:
    client.alert("Hello!")
except RateLimitError as e:
    print(f"Rate limited. Retry after {e.retry_after} seconds")
except NotificationsPausedError:
    print("Notifications paused. Reactivate at sentrygram.com")
except SentrygramError as e:
    print(f"Error: {e}")
```

## Rate Limits

- **Burst limit**: 10 alerts per minute
- **Hourly limit**: 200 alerts per hour

If you exceed the burst limit repeatedly, notifications will be automatically paused to prevent spam.

## Get Your API Key

1. Sign up at [sentrygram.com](https://sentrygram.com)
2. Link your Telegram account
3. Create an API key in the dashboard

## License

MIT
