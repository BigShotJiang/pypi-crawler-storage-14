import { defineComponent as l, inject as _, reactive as f, onMounted as g, onUnmounted as v, computed as u, createElementBlock as S, openBlock as h, createElementVNode as c, toDisplayString as d } from "vue";
const w = { class: "system-widget" }, y = { id: "info_time" }, T = { id: "uptime" }, b = /* @__PURE__ */ l({
  __name: "SystemWidget",
  setup(n) {
    const s = _("tangramApi");
    if (!s)
      throw new Error("assert: tangram api not provided");
    const e = f({
      hovered: !1,
      uptime: "",
      info_utc: (/* @__PURE__ */ new Date()).getTime()
    });
    let i = null;
    g(async () => {
      try {
        i = await s.realtime.subscribe(
          "system:update-node",
          (t) => {
            t.el === "uptime" && (e.uptime = t.value), t.el === "info_utc" && (e.info_utc = t.value);
          }
        );
      } catch (t) {
        console.error("failed to subscribe to system:update-node", t);
      }
    }), v(() => {
      i?.dispose();
    });
    const r = u(() => {
      const t = new Date(e.info_utc), o = t.getUTCHours().toString().padStart(2, "0"), a = t.getUTCMinutes().toString().padStart(2, "0"), p = t.getUTCSeconds().toString().padStart(2, "0");
      return `${o}:${a}:${p} Z`;
    }), m = u(() => new Date(e.info_utc).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: !1,
      timeZoneName: "shortOffset"
    }));
    return (t, o) => (h(), S("div", w, [
      c("div", {
        class: "clock",
        onMouseover: o[0] || (o[0] = (a) => e.hovered = !0),
        onMouseleave: o[1] || (o[1] = (a) => e.hovered = !1)
      }, [
        c("span", y, d(e.hovered ? m.value : r.value), 1)
      ], 32),
      c("span", T, d(e.uptime), 1)
    ]));
  }
}), $ = (n, s) => {
  const e = n.__vccOpts || n;
  for (const [i, r] of s)
    e[i] = r;
  return e;
}, k = /* @__PURE__ */ $(b, [["__scopeId", "data-v-6f95989c"]]);
function D(n) {
  n.ui.registerWidget("system-widget", "TopBar", k);
}
export {
  D as install
};
//# sourceMappingURL=index.js.map
