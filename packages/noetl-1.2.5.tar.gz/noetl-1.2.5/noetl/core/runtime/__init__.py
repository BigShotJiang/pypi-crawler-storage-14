"""
Pure runtime engine (context, router, loop, registry, executor).
This package must remain side-effect free.
"""

