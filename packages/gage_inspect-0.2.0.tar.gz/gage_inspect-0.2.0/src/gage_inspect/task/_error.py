class NoModel(Exception):
    pass
