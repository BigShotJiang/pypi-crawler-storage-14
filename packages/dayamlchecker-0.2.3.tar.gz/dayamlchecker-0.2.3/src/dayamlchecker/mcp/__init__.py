"""MCP server integration for DAYamlChecker."""
