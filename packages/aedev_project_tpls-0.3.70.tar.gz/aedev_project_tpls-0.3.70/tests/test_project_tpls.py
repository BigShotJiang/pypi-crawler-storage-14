""" project_tpls unit tests. """


class TestDummyClass:
    def test_dummy(self):
        assert True
