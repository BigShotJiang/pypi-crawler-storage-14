
test = "Hello world"

print("Module loaded")
