NAME = 'timg'
VERSION = '1.1.6'
DESC = 'print an image in terminal'
