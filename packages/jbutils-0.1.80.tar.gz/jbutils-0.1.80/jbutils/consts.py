"""Constant variables for the jbutils library"""


class RuntimeGlobals:
    debug: bool = False
    verbose: bool = False
