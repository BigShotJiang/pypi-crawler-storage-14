"""Generic Logging builder"""

