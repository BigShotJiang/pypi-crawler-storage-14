<h1 align="center">Payme Software Development Kit</h1>

## Installation

```shell
pip install payme-sdk
```

## Installation to Django

Add `'payme'` in to your settings.py

```python
INSTALLED_APPS = [
    ...
    'payme',
    ...
]
```

Add `'payme'` credentials inside to settings.py

One time payment (Однаразовый платеж) configuration settings.py

Example project: https://github.com/PayTechUz/shop-backend

```python
PAYME_ID = "your-payme-id"
PAYME_KEY = "your-payme-key"
PAYME_ACCOUNT_FIELD = "order_id"
PAYME_AMOUNT_FIELD = "total_amount"
PAYME_ACCOUNT_MODEL = "orders.models.Orders"
PAYME_ONE_TIME_PAYMENT = True
```

Multi payment (Накопительный) configuration settings.py

Example project: Coming soon

```python
PAYME_ID = "your-payme-id"
PAYME_KEY = "your-payme-key"
PAYME_ACCOUNT_FIELD = "id"
PAYME_ACCOUNT_MODEL = "clients.models.Client"
PAYME_ONE_TIME_PAYMENT = False

PAYME_DISABLE_ADMIN = False(optionally
configuration if you
want
to
disable
change
to
True)
```

Create a new View that about handling call backs

```python
from payme.views import PaymeWebHookAPIView


class PaymeCallBackAPIView(PaymeWebHookAPIView):
    def handle_created_payment(self, params, result, *args, **kwargs):
        """
        Handle the successful payment. You can override this method
        """
        print(f"Transaction created for this params: {params} and cr_result: {result}")

    def handle_successfully_payment(self, params, result, *args, **kwargs):
        """
        Handle the successful payment. You can override this method
        """
        print(f"Transaction successfully performed for this params: {params} and performed_result: {result}")

    def handle_cancelled_payment(self, params, result, *args, **kwargs):
        """
        Handle the cancelled payment. You can override this method
        """
        print(f"Transaction cancelled for this params: {params} and cancelled_result: {result}")
```

Add a `payme` path to core of urlpatterns:

```python
from django.urls import path
from django.urls import include

from your_app.views import PaymeCallBackAPIView

urlpatterns = [
    ...
    path("payment/update/", PaymeCallBackAPIView.as_view()),
    ...
]
```

Run migrations

```shell
python manage.py migrate
```

🎉 Congratulations you have been integrated merchant api methods with django, keep reading docs. After successfull
migrations check your admin panel and see results what happened.

## Generate Pay Link

Example to generate link:

- Input

```python
from payme import Payme

payme = Payme(payme_id="your-payme-id")
pay_link = payme.initializer.generate_pay_link(id=123456, amount=5000, return_url="https://example.com")
print(pay_link)
```

- Output

```
https://checkout.paycom.uz/bT15b3VyLXBheW1lLWlkO2FjLmlkPTEyMzQ1NjthPTUwMDAwMDtjPWh0dHBzOi8vZXhhbXBsZS5jb20=
```

## Generate Fallback Link

Example to generate fallback link:

- Input

The ID in the fallback is different from the merchant ID. You can get the ID from the Payme team.

```python
from payme import Payme

payme = Payme(payme_id="your-payme-id", fallback_id="your-fallback-id")

form_fields = {
    "driver_id": 12345,
    "amount": 1000
}

fallback_link = payme.initializer.generate_fallback_link(form_fields)  # form field is optional
print(fallback_link)
```

- Output

```
https://payme.uz/fallback/merchant/?id=examplelinkgenerated&driver_id=12345&amount=1000
```
