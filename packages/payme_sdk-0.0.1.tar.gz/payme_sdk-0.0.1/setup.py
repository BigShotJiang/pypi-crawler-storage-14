import pathlib

from setuptools import find_packages, setup

here = pathlib.Path(__file__).parent.resolve()

long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
    name='payme-sdk',
    version='0.0.1',
    license='MIT',
    author="Jahongir Hakimjonov",
    author_email='jahongirhakimjonov@gmail.com',
    packages=find_packages(),
    url='https://github.com/JahongirHakimjonov/payme-sdk',
    keywords=['payme-sdk'],
    install_requires=[
        'requests==2.*',
        "dataclasses==0.*;python_version<'3.7'",  # will only install on py3.6
        'djangorestframework==3.*'
      ],
    long_description=long_description,
    long_description_content_type="text/markdown",
)
