import requests
class ProxyTools:
    def get_one_proxy(self):
        proxy=None
        current_proxies = {
            "http": f"http://{proxy}",
            "https": f"http://{proxy}"
        }
        return ""
ProxyTool= ProxyTools()