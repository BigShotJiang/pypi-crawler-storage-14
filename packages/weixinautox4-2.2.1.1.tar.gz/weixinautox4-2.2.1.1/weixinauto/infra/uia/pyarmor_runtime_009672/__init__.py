# Pyarmor 9.2.0 (basic), 009672, 2025-11-28T22:46:04.699686
from .pyarmor_runtime import __pyarmor__
