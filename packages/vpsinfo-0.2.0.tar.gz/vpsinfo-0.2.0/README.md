# VPSinfo

A command-line tool for monitoring VPS information using SolusVM and Virtualizor APIs. Supports concurrent monitoring of multiple VPS instances with bandwidth usage and system status information.

## Features

- Monitor bandwidth usage (used, total, percentage)
- Monitor memory usage (used, total, percentage)
- Monitor disk usage (used, total, percentage)
- Concurrent monitoring of multiple VPS instances
- Human-readable data formatting
- Simple JSON configuration
- Verbose mode for debugging

## Installation

```bash
pip install vpsinfo
```

## Configuration

Create a configuration file at `~/.vpsinfo.json`:

```json
[
    {
        "name": "my-solusvm-vps",
        "type": "solusvm",
        "url": "https://your-solusvm-url:5656",
        "key": "your-api-key",
        "hash": "your-api-hash"
    },
    {
        "name": "my-virtualizor-vps",
        "type": "virtualizor",
        "url": "https://your-virtualizor-url:4083",
        "key": "your-api-key",
        "hash": "your-api-password-hash"
    },
    {
        "name": "vps-with-self-signed-cert",
        "type": "solusvm",
        "url": "https://manage.example.com",
        "key": "your-api-key",
        "hash": "your-api-hash",
        "verify_ssl": false
    }
]
```

Each VPS entry requires:
- `name`: A friendly name for the VPS
- `type`: VPS panel type ("solusvm" or "virtualizor")
- `url`: API URL
  - For SolusVM: usually ends with :5656
  - For Virtualizor: usually ends with :4083
- `key`: API key from control panel
- `hash`:
  - For SolusVM: API hash from control panel
  - For Virtualizor: API password hash from control panel
- `verify_ssl`: (Optional) Whether to verify SSL certificates (default: `true`)
  - Set to `false` to disable SSL verification for servers with self-signed or invalid certificates
  - **Warning**: Disabling SSL verification reduces security

## Usage

Monitor all VPS metrics (bandwidth, memory, disk):
```bash
vpsinfo
```

Enable verbose output for debugging:
```bash
vpsinfo -v
```
or
```bash
vpsinfo --verbose
```

## Example Output

```
╒══════════════╤══════════╤══════════╤═══════════╤═══════╤══════════╤═══════════╤═══════╤══════════╤═══════════╤═══════╕
│ VPS Name     │ Status   │ BW Used  │ BW Total  │ BW %  │ Mem Used │ Mem Total │ Mem % │ Disk Used│ Disk Total│ Disk %│
╞══════════════╪══════════╪══════════╪═══════════╪═══════╪══════════╪═══════════╪═══════╪══════════╪═══════════╪═══════╡
│ my-vps-1     │ Success  │ 1.25 GiB │ 500.0 GiB │ 0.3%  │ 512.0MiB │ 1.0 GiB   │ 50.0% │ 10.0 GiB │ 50.0 GiB  │ 20.0%│
╘══════════════╧══════════╧══════════╧═══════════╧═══════╧══════════╧═══════════╧═══════╧══════════╧═══════════╧═══════╛
```

When an error occurs:
```
╒══════════════╤═════════════════════════╤══════════╤═══════════╤═══════╤══════════╤═══════════╤═══════╤══════════╤═══════════╤═══════╕
│ VPS Name     │ Status                  │ BW Used  │ BW Total  │ BW %  │ Mem Used │ Mem Total │ Mem % │ Disk Used│ Disk Total│ Disk %│
╞══════════════╪═════════════════════════╪══════════╪═══════════╪═══════╪══════════╪═══════════╪═══════╪══════════╪═══════════╪═══════╡
│ my-vps-1     │ Error - Connection failed│ N/A      │ N/A       │ N/A   │ N/A      │ N/A       │ N/A   │ N/A      │ N/A       │ N/A   │
╘══════════════╧═════════════════════════╧══════════╧═══════════╧═══════╧══════════╧═══════════╧═══════╧══════════╧═══════════╧═══════╛
```

## Error Handling

- If a VPS is unreachable or there are API errors, the status will show as "Error" with an error message
- All metrics will show as "N/A" when an error occurs
- Configuration file errors will be reported with clear error messages
- All errors are displayed in red for better visibility
- Use verbose mode (-v) to see detailed debug information

## Requirements

- Python 3.7 or higher
- click
- tabulate
- requests
