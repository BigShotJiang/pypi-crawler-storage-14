"""Answer generation pipeline for knowledge graph retrieval.

This module provides the complete pipeline for:
1. SPARQL generation from subgraphs
2. Full KG retrieval (seed nodes -> subgraphs -> SPARQL -> results)
3. Natural language answer generation from retrieval results or subgraphs
"""

import os
import json
import dspy
from typing import List, Dict, Any, Optional, Callable, Tuple
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

from kgnode.core.sparql_query import execute_sparql_query
from kgnode.core.kg_config import KGConfig
from kgnode.seed_finder import get_seed_nodes, citable
from kgnode.subgraph_extraction import get_subgraphs


# ============================================================================
# HELPER FUNCTIONS (No dependencies)
# ============================================================================

def _validate_sparql(
    sparql_query: str,
    kg_connection: Callable
) -> Tuple[bool, Optional[str]]:
    """Validate SPARQL query by attempting execution.

    Args:
        sparql_query: SPARQL query string to validate.
        kg_connection: SPARQL query executor function (already configured with config).

    Returns:
        Tuple of (is_valid, error_message):
            - is_valid: True if query executes successfully
            - error_message: None if valid, error string if invalid
    """
    try:
        # Try to execute the query (kg_connection already has config bound)
        results = kg_connection(sparql_query)
        return True, None
    except Exception as e:
        error_msg = f"SPARQL validation failed: {str(e)}"
        return False, error_msg


def _format_subgraph_for_prompt(subgraph: Dict[str, Any]) -> str:
    """Convert subgraph structure to human-readable text for LLM.

    Args:
        subgraph: Dictionary with 'triplet_uris' and 'path_with_label' keys.

    Returns:
        Formatted string representation of the subgraph.

    Example Output:
        Node: Robert Schober (https://dblp.org/pid/95/2265)
        --[wikidata]-->
        Node: Q55238282 (https://www.wikidata.org/entity/Q55238282)
    """
    lines = []

    # Add header
    lines.append("Knowledge Graph Path:")
    lines.append("-" * 60)

    # Format the path with labels
    for uri, label, is_node in subgraph['path_with_label']:
        if is_node:
            lines.append(f"Node: {label}")
            lines.append(f"      URI: <{uri}>")
        else:
            lines.append(f"  --[{label}]-->")

    # Add triplet information
    lines.append("-" * 60)
    lines.append("Triple URIs:")
    for source, relation, target in subgraph['triplet_uris']:
        lines.append(f"  <{source}> <{relation}> <{target}>")

    return "\n".join(lines)


# ============================================================================
# SPARQL GENERATION (Depends on helper functions)
# ============================================================================

def generate_sparql(
    query: str,
    subgraphs: List[Dict[str, Any]],
    config: Optional[KGConfig] = None,
    kg_connection: Optional[Callable] = None,
    max_retries: int = 3
) -> Optional[str]:
    """Generate SPARQL query from natural language query and multiple subgraphs.

    Uses DSpy to generate SPARQL based on the query and all subgraph structures,
    then validates the generated SPARQL. Uses DSpy assertions for automatic retries.

    Args:
        query: User's natural language query.
        subgraphs: List of subgraph dicts from extract_subgraphs_bfs.
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.
            The config provides lm_api_key for SPARQL generation.
        kg_connection: Optional SPARQL query executor function. If None, creates from config.
        max_retries: Maximum number of retry attempts for invalid SPARQL.

    Returns:
        Valid SPARQL query string, or None if generation fails.
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Load environment variables
    load_dotenv()

    # Initialize DSpy LM
    api_key = config.lm_api_key
    if not api_key:
        print("Error: LM API key not found in config or environment")
        return None

    lm = dspy.LM(model=config.openai_model, api_key=api_key)
    dspy.configure(lm=lm)

    # Initialize kg_connection if not provided
    if kg_connection is None:
        kg_connection = lambda q: execute_sparql_query(q, config=config)

    # Format all subgraphs for prompt
    formatted_subgraphs = []
    for i, subgraph in enumerate(subgraphs, 1):
        formatted_subgraphs.append(f"\n=== Knowledge Graph Path {i} ===")
        formatted_subgraphs.append(_format_subgraph_for_prompt(subgraph))

    formatted_subgraph = "\n".join(formatted_subgraphs)

    # Create DSpy module based on chain_of_thought setting with instructions
    signature_with_instructions = config.sparql_generation_signature.with_instructions(
        config.sparql_generation_instruction
    )

    if config.chain_of_thought:
        sparql_generator = dspy.ChainOfThought(signature_with_instructions)
    else:
        sparql_generator = dspy.Predict(signature_with_instructions)

    # Try to generate valid SPARQL with retries
    for attempt in range(max_retries):
        try:
            # Call DSpy
            result = sparql_generator(query=query, subgraphs=formatted_subgraph)
            sparql_query = result.sparql.strip()

            # Remove markdown code blocks if present
            if sparql_query.startswith("```"):
                lines = sparql_query.split("\n")
                sparql_query = "\n".join(lines[1:-1]) if len(lines) > 2 else sparql_query
                sparql_query = sparql_query.replace("```sparql", "").replace("```", "").strip()

            # Validate the generated SPARQL
            is_valid, error_msg = _validate_sparql(sparql_query, kg_connection)

            if is_valid:
                print(f"  Generated valid SPARQL query (attempt {attempt + 1}/{max_retries})")
                return sparql_query
            else:
                print(f"  Invalid SPARQL (attempt {attempt + 1}/{max_retries}): {error_msg}")
                # DSpy will automatically retry with suggestion if we use dspy.Suggest
                # For now, manually retry with updated context
                dspy.Suggest(False, f"SPARQL validation failed: {error_msg}")

        except Exception as e:
            print(f"  Error generating SPARQL (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                continue

    # All retries exhausted
    print(f"Failed to generate valid SPARQL after {max_retries} attempts")
    return None


# ============================================================================
# KG RETRIEVAL PIPELINE (Depends on generate_sparql + existing modules)
# ============================================================================

def kg_retrieve(
    query: str,
    config: Optional[KGConfig] = None,
    check_citable: bool = False,
    n_seed_results: int = 3,
    max_hops: int = 10,
    max_k: int = 2,
    kg_connection: Optional[Callable] = None,
    max_sparql_retries: int = 3
) -> Optional[Dict[str, Any]]:
    """Full retrieval pipeline: query -> seed nodes -> subgraphs -> SPARQL -> results.

    This function orchestrates the complete knowledge graph retrieval pipeline:
    1. Optional citability check
    2. Seed node finding (keyword + semantic search)
    3. Subgraph extraction using path-aware Markov chain
    4. SPARQL generation from ALL subgraphs (single LLM call)
    5. SPARQL execution to retrieve results

    Args:
        query: User's natural language query.
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.
            The config provides lm_api_key and embedding_model.
        check_citable: Whether to check citability before retrieval.
        n_seed_results: Number of seed nodes to retrieve per entity.
        max_hops: Maximum hops for subgraph extraction.
        max_k: Maximum neighbors per hop in subgraph extraction.
        kg_connection: Optional SPARQL query executor function. If None, creates from config.
        max_sparql_retries: Max retries for SPARQL generation.

    Returns:
        Dictionary with structure:
        {
            'sparql': str,              # Generated SPARQL query
            'results': List[Dict],      # SPARQL execution results
            'subgraphs': List[Dict],    # All extracted subgraphs used
        }
        Returns None if pipeline fails at any stage.
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    load_dotenv()

    # Initialize DSpy LM
    api_key = config.lm_api_key
    if not api_key:
        print("Error: LM API key not found in config or environment")
        return None

    lm = dspy.LM(model=config.openai_model, api_key=api_key)
    dspy.configure(lm=lm)

    # Initialize kg_connection if not provided
    if kg_connection is None:
        kg_connection = lambda q: execute_sparql_query(q, config=config)

    print("=" * 80)
    print("KG RETRIEVAL PIPELINE")
    print("=" * 80)
    print(f"Query: {query}\n")

    # Step 1: Optional citability check
    if check_citable:
        print("Step 1: Checking citability...")
        is_citable, entity_nodes = citable(
            query=query,
            config=config,
            n_results_per_entity=n_seed_results
        )

        if not is_citable:
            print("  Query is not citable - no suitable seed nodes found in knowledge graph")
            return None
        print(f"  Query is citable - found entities: {list(entity_nodes.keys())}\n")

    # Step 2: Seed node finding
    print("Step 2: Finding seed nodes...")
    seed_nodes = get_seed_nodes(
        query=query,
        config=config,
        n_results=n_seed_results
    )

    if not seed_nodes:
        print("  No seed nodes found")
        return None

    print(f"  Found {len(seed_nodes)} seed nodes")
    for i, node in enumerate(seed_nodes[:5], 1):
        print(f"  {i}. {node['label']} ({node['source']}) - {node['entity_uri']}")
    if len(seed_nodes) > 5:
        print(f"  ... and {len(seed_nodes) - 5} more")
    print()

    # Step 3: Subgraph extraction
    print("Step 3: Extracting subgraphs...")
    all_subgraphs = []

    for seed_node in seed_nodes:
        seed_uri = seed_node['entity_uri']
        print(f"  Extracting from seed: {seed_node['label']}")

        try:
            subgraphs = get_subgraphs(
                seed_node=seed_uri,
                query=query,
                config=config,
                kg_connection=kg_connection,
                max_hops=max_hops,
                max_k=max_k
            )

            print(f"    -> Found {len(subgraphs)} subgraphs")
            all_subgraphs.extend(subgraphs)

        except Exception as e:
            print(f"    Error extracting subgraphs: {e}")
            continue

    if not all_subgraphs:
        print("  No valid subgraphs extracted from any seed node")
        return None

    print(f"\n  Total subgraphs extracted: {len(all_subgraphs)}\n")

    # Step 4: SPARQL generation using ALL subgraphs
    print("Step 4: Generating SPARQL from all subgraphs...")

    sparql_query = generate_sparql(
        query=query,
        subgraphs=all_subgraphs,
        config=config,
        kg_connection=kg_connection,
        max_retries=max_sparql_retries
    )

    if sparql_query is None:
        print("  Failed to generate valid SPARQL")
        return None

    # Step 5: Execute SPARQL
    print("\nStep 5: Executing SPARQL query...")

    try:
        sparql_results = kg_connection(sparql_query)

        if not sparql_results:
            print("  SPARQL executed but returned no results")
            return None

        print(f"  Found {len(sparql_results)} results")

        # Return single result
        result = {
            'sparql': sparql_query,
            'results': sparql_results,
            'subgraphs': all_subgraphs
        }

        print("\n" + "=" * 80)
        print("PIPELINE COMPLETE")
        print("=" * 80)
        return result

    except Exception as e:
        print(f"  Error executing SPARQL: {e}")
        return None


# ============================================================================
# ANSWER GENERATION (Depends on kg_retrieve)
# ============================================================================

def generate_answer(
    query: str,
    config: Optional[KGConfig] = None,
    check_citable: bool = False,
    n_seed_results: int = 3,
    max_hops: int = 10,
    max_k: int = 2,
    kg_connection: Optional[Callable] = None,
    max_sparql_retries: int = 3
) -> Optional[Dict[str, Any]]:
    """End-to-end natural language answer generation using full KG retrieval pipeline.

    Runs the complete pipeline (kg_retrieve) and generates a natural language
    answer from the retrieved results using DSpy.

    Args:
        query: User's natural language query.
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.
            The config provides lm_api_key and embedding_model.
        check_citable: Whether to check citability before retrieval.
        n_seed_results: Number of seed nodes per entity.
        max_hops: Maximum hops for subgraph extraction.
        max_k: Maximum neighbors per hop.
        kg_connection: Optional SPARQL query executor function. If None, creates from config.
        max_sparql_retries: Max retries for SPARQL generation.

    Returns:
        Dictionary with structure:
        {
            'answer': str,                  # Natural language answer
            'citations': List[str],         # Entity URIs cited
            'confidence': float,            # Confidence score (0-1)
            'sparql_used': str,             # SPARQL query used
            'raw_results': Dict             # Raw kg_retrieve result
        }
        Returns None if pipeline fails.
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    load_dotenv()

    # Initialize DSpy LM
    api_key = config.lm_api_key
    if not api_key:
        print("Error: LM API key not found in config or environment")
        return None

    lm = dspy.LM(model=config.openai_model, api_key=api_key)
    dspy.configure(lm=lm)

    print("\n" + "=" * 80)
    print("ANSWER GENERATION PIPELINE")
    print("=" * 80)

    # Step 1: Run KG retrieval pipeline
    retrieval_result = kg_retrieve(
        query=query,
        config=config,
        check_citable=check_citable,
        n_seed_results=n_seed_results,
        max_hops=max_hops,
        max_k=max_k,
        kg_connection=kg_connection,
        max_sparql_retries=max_sparql_retries
    )

    if retrieval_result is None:
        print("\n  Answer generation failed: No retrieval results")
        return None

    # Step 2: Format results for LLM
    print("\nFormatting retrieval results for answer generation...")

    formatted_results = []
    formatted_results.append(f"SPARQL Query: {retrieval_result['sparql']}")
    formatted_results.append(f"Results ({len(retrieval_result['results'])} items):")

    for j, row in enumerate(retrieval_result['results'][:10], 1):
        formatted_results.append(f"  {j}. {row}")

    if len(retrieval_result['results']) > 10:
        formatted_results.append(f"  ... and {len(retrieval_result['results']) - 10} more results")

    results_text = "\n".join(formatted_results)

    # Step 3: Generate answer using DSpy
    print("Generating natural language answer...\n")

    # Create DSpy module based on chain_of_thought setting with instructions
    signature_with_instructions = config.answer_generation_signature.with_instructions(
        config.answer_generation_instruction
    )

    if config.chain_of_thought:
        answer_generator = dspy.ChainOfThought(signature_with_instructions)
    else:
        answer_generator = dspy.Predict(signature_with_instructions)

    try:
        # Call DSpy
        result = answer_generator(query=query, results=results_text)

        # Parse citations from JSON string
        citations = json.loads(result.citations) if isinstance(result.citations, str) else result.citations

        # Build final result
        final_result = {
            'answer': result.answer,
            'citations': citations,
            'confidence': float(result.confidence),
            'sparql_used': retrieval_result['sparql'],
            'raw_results': retrieval_result
        }

        print("=" * 80)
        print("ANSWER GENERATED SUCCESSFULLY")
        print("=" * 80)
        print(f"\nAnswer: {final_result['answer']}")
        print(f"\nConfidence: {final_result['confidence']:.2f}")
        print(f"Citations: {len(final_result['citations'])} entities")
        print("=" * 80)

        return final_result

    except json.JSONDecodeError as e:
        print(f"  Error parsing DSpy response citations as JSON: {e}")
        print(f"Citations was: {result.citations}")
        return None
    except Exception as e:
        print(f"  Error generating answer: {e}")
        return None


# ============================================================================
# ANSWER GENERATION FROM SUBGRAPH (Depends on helper functions)
# ============================================================================

def generate_answer_using_subgraph(
    query: str,
    config: Optional[KGConfig] = None,
    subgraphs: Optional[List[Dict[str, Any]]] = None,
    n_seed_results: int = 3,
    max_hops: int = 10,
    max_k: int = 2,
    kg_connection: Optional[Callable] = None
) -> Optional[Dict[str, Any]]:
    """Generate natural language answer directly from query and subgraphs.

    Unlike generate_answer(), this function works directly with subgraphs
    without going through SPARQL generation and execution. If subgraphs are
    not provided, it will automatically extract them from the query. Uses DSpy for generation.

    Args:
        query: User's natural language query.
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.
            The config provides lm_api_key and embedding_model.
        subgraphs: Optional list of subgraph dicts. If None, will extract from query.
        n_seed_results: Number of seed nodes to retrieve (used if subgraphs is None).
        max_hops: Maximum hops for subgraph extraction (used if subgraphs is None).
        max_k: Maximum neighbors per hop (used if subgraphs is None).
        kg_connection: Optional SPARQL query executor function. If None, creates from config.

    Returns:
        Dictionary with structure:
        {
            'answer': str,                  # Natural language answer
            'citations': List[str],         # Entity URIs cited
            'confidence': float,            # Confidence score (0-1)
            'subgraphs_used': List[int],    # Indices of subgraphs used
            'raw_subgraphs': List[Dict]     # Original subgraphs
        }
        Returns None if generation fails.
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    load_dotenv()

    # Initialize DSpy LM
    api_key = config.lm_api_key
    if not api_key:
        print("Error: LM API key not found in config or environment")
        return None

    lm = dspy.LM(model=config.openai_model, api_key=api_key)
    dspy.configure(lm=lm)

    # Extract subgraphs if not provided
    if subgraphs is None:
        print("No subgraphs provided. Extracting from query...")
        print("=" * 80)

        # Initialize kg_connection if not provided
        if kg_connection is None:
            kg_connection = lambda q: execute_sparql_query(q, config=config)

        # Step 1: Find seed nodes
        print("\nStep 1: Finding seed nodes...")
        seed_nodes = get_seed_nodes(
            query=query,
            config=config,
            n_results=n_seed_results
        )

        if not seed_nodes:
            print("  No seed nodes found")
            return None

        print(f"  Found {len(seed_nodes)} seed nodes")

        # Step 2: Extract subgraphs
        print("\nStep 2: Extracting subgraphs...")
        subgraphs = []

        for seed_node in seed_nodes:
            seed_uri = seed_node['entity_uri']
            print(f"  Extracting from seed: {seed_node['label']}")

            try:
                extracted_subgraphs = get_subgraphs(
                    seed_node=seed_uri,
                    query=query,
                    config=config,
                    kg_connection=kg_connection,
                    max_hops=max_hops,
                    max_k=max_k
                )

                print(f"    -> Found {len(extracted_subgraphs)} subgraphs")
                subgraphs.extend(extracted_subgraphs)

            except Exception as e:
                print(f"    Error extracting subgraphs: {e}")
                continue

        if not subgraphs:
            print("  No valid subgraphs extracted")
            return None

        print(f"\n  Total subgraphs extracted: {len(subgraphs)}\n")
        print("=" * 80)

    # Validate we have subgraphs at this point
    if not subgraphs:
        print("  No subgraphs available")
        return None

    print("=" * 80)
    print("ANSWER GENERATION FROM SUBGRAPHS")
    print("=" * 80)
    print(f"Query: {query}")
    print(f"Number of subgraphs: {len(subgraphs)}\n")

    # Format all subgraphs for the prompt
    formatted_subgraphs = []

    for i, subgraph in enumerate(subgraphs, 1):
        formatted_subgraphs.append(f"Knowledge Graph Path {i}:")
        formatted_subgraphs.append("-" * 60)

        # Format path with labels
        for uri, label, is_node in subgraph['path_with_label']:
            if is_node:
                formatted_subgraphs.append(f"  Node: {label}")
                formatted_subgraphs.append(f"        URI: <{uri}>")
            else:
                formatted_subgraphs.append(f"    --[{label}]-->")

        formatted_subgraphs.append("")

    subgraphs_text = "\n".join(formatted_subgraphs)

    # Create DSpy module based on chain_of_thought setting with instructions
    signature_with_instructions = config.answer_from_subgraph_signature.with_instructions(
        config.answer_from_subgraph_instruction
    )

    if config.chain_of_thought:
        answer_generator = dspy.ChainOfThought(signature_with_instructions)
    else:
        answer_generator = dspy.Predict(signature_with_instructions)

    try:
        print("Generating answer from subgraphs...")

        # Call DSpy
        result = answer_generator(query=query, subgraphs=subgraphs_text)

        # Parse JSON strings
        citations = json.loads(result.citations) if isinstance(result.citations, str) else result.citations
        subgraphs_used = json.loads(result.subgraphs_used) if isinstance(result.subgraphs_used, str) else result.subgraphs_used

        # Build final result
        final_result = {
            'answer': result.answer,
            'citations': citations,
            'confidence': float(result.confidence),
            'subgraphs_used': subgraphs_used,
            'raw_subgraphs': subgraphs
        }

        print("\n" + "=" * 80)
        print("ANSWER GENERATED SUCCESSFULLY")
        print("=" * 80)
        print(f"\nAnswer: {final_result['answer']}")
        print(f"\nConfidence: {final_result['confidence']:.2f}")
        print(f"Citations: {len(final_result['citations'])} entities")
        print(f"Subgraphs used: {final_result['subgraphs_used']}")
        print("=" * 80)

        return final_result

    except json.JSONDecodeError as e:
        print(f"  Error parsing DSpy response as JSON: {e}")
        print(f"Citations: {result.citations}, Subgraphs used: {result.subgraphs_used}")
        return None
    except Exception as e:
        print(f"  Error generating answer: {e}")
        return None


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == '__main__':
    # Example 1: Test generate_sparql
    # print("\n" + "=" * 80)
    # print("EXAMPLE 1: Generate SPARQL from subgraphs")
    # print("=" * 80)
    #
    # # Sample subgraphs for testing
    # sample_subgraphs = [
    #     {
    #         'triplet_uris': [
    #             ('https://dblp.org/pid/95/2265', 'https://dblp.org/rdf/schema#wikidata',
    #              'https://www.wikidata.org/entity/Q55238282')
    #         ],
    #         'path_with_label': [
    #             ('https://dblp.org/pid/95/2265', 'Robert Schober', True),
    #             ('https://dblp.org/rdf/schema#wikidata', 'wikidata', False),
    #             ('https://www.wikidata.org/entity/Q55238282', 'Q55238282', True)
    #         ]
    #     }
    # ]
    #
    # sparql = generate_sparql(
    #     query="What is the Wikidata ID of Robert Schober?",
    #     subgraphs=sample_subgraphs
    # )
    # if sparql:
    #     print(f"\nGenerated SPARQL:\n{sparql}")

    # Example 2: Test kg_retrieve
    # print("\n" + "=" * 80)
    # print("EXAMPLE 2: Full KG retrieval pipeline")
    # print("=" * 80)
    #
    # result = kg_retrieve(
    #     query="What is the Wikidata ID of Robert Schober?",
    #     check_citable=True,
    #     n_seed_results=2,
    #     max_hops=3,
    #     max_k=2
    # )
    # if result:
    #     print(f"\nSPARQL: {result['sparql']}")
    #     print(result)
    #     print(f"Results: {len(result['results'])} items")
    #     print(f"Subgraphs: {len(result['subgraphs'])} paths")

    # Example 3: Test generate_answer
    print("\n" + "=" * 80)
    print("EXAMPLE 3: End-to-end answer generation")
    print("=" * 80)

    answer = generate_answer(
        query="What is the Wikidata ID of Robert Schober?",
        check_citable=True,
        n_seed_results=2,
        max_hops=3,
        max_k=2
    )
    if answer:
        print(f"\nFinal Answer: {answer['answer']}")
        print(f"Confidence: {answer['confidence']:.2f}")
        print(f"Citations: {answer['citations']}")
        print(f"\nSPARQL Used: {answer['sparql_used']}")

    # Example 4a: Test generate_answer_using_subgraph with provided subgraphs
    # print("\n" + "=" * 80)
    # print("EXAMPLE 4a: Answer generation from provided subgraphs")
    # print("=" * 80)
    #
    # # You can use subgraphs from kg_retrieve result or extract_subgraphs_bfs
    # # For this example, we'll use the sample subgraphs
    # sample_subgraphs = [
    #     {
    #         'triplet_uris': [
    #             ('https://dblp.org/pid/95/2265', 'https://dblp.org/rdf/schema#wikidata',
    #              'https://www.wikidata.org/entity/Q55238282')
    #         ],
    #         'path_with_label': [
    #             ('https://dblp.org/pid/95/2265', 'Robert Schober', True),
    #             ('https://dblp.org/rdf/schema#wikidata', 'wikidata', False),
    #             ('https://www.wikidata.org/entity/Q55238282', 'Q55238282', True)
    #         ]
    #     }
    # ]
    #
    # answer = generate_answer_using_subgraph(
    #     query="What is the Wikidata ID of Robert Schober?",
    #     subgraphs=sample_subgraphs
    # )
    # if answer:
    #     print(f"\nFinal Answer: {answer['answer']}")
    #     print(f"Confidence: {answer['confidence']:.2f}")
    #     print(f"Citations: {answer['citations']}")
    #     print(f"Subgraphs used: {answer['subgraphs_used']}")

    # Example 4b: Test generate_answer_using_subgraph without subgraphs (auto-extract)
    # print("\n" + "=" * 80)
    # print("EXAMPLE 4b: Answer generation with automatic subgraph extraction")
    # print("=" * 80)
    #
    # # When subgraphs are not provided, the function will automatically:
    # # 1. Find seed nodes from the query
    # # 2. Extract subgraphs from those seed nodes
    # # 3. Generate answer from the extracted subgraphs
    # answer = generate_answer_using_subgraph(
    #     query="What is the Wikidata ID of Robert Schober?",
    #     n_seed_results=2,
    #     max_hops=3,
    #     max_k=2
    # )
    # if answer:
    #     print(f"\nFinal Answer: {answer['answer']}")
    #     print(f"Confidence: {answer['confidence']:.2f}")
    #     print(f"Citations: {answer['citations']}")
    #     print(f"Subgraphs used: {answer['subgraphs_used']}")
    #
    # print("\nAll examples defined. Uncomment the code blocks to test each function.")
