import time
from datetime import datetime

import pandas as pd
from kgnode._node_ranker import get_top_entities_by_degree
from kgnode.core.kg_config import KGConfig

import chromadb
from chromadb.config import Settings
from typing import List, Dict, Optional
import os


def add_descriptions_to_csv_batched(
    csv_path: str,
    config: KGConfig,
    output_path: str = None,
    batch_size: int = 80
) -> pd.DataFrame:
    """
    Read CSV and add descriptions using batched queries.

    Args:
        csv_path: Path to input CSV file
        config: KGConfig instance with descriptor functions
        output_path: Path to save output CSV
        batch_size: Number of entities to query at once, query should fit in 8kb, so batch size max 100.

    Returns:
        DataFrame with added 'description' column
    """
    df = pd.read_csv(csv_path)

    if 'entity' not in df.columns:
        raise ValueError("CSV must have an 'entity' column")

    entity_uris = df['entity'].unique().tolist()

    print(f"Processing {len(entity_uris)} unique entities in batches of {batch_size}...")

    # Process in batches using config's descriptor
    all_descriptions = {}
    for i in range(0, len(entity_uris), batch_size):
        batch = entity_uris[i:i + batch_size]
        print(f"Processing batch {i // batch_size + 1}/{(len(entity_uris) - 1) // batch_size + 1}...")
        batch_descriptions = config.describe_entities_batch(batch)
        all_descriptions.update(batch_descriptions)

    # Map descriptions
    df['description'] = df['entity'].map(all_descriptions)
    df['description'] = df['description'].fillna('')

    if output_path is None:
        output_path = csv_path

    df.to_csv(output_path, index=False)
    print(f"Saved results to {output_path}")

    return df


def compile_chromadb(
        csv_path: str,
        config: Optional[KGConfig] = None,
        entity_limit: int = 10000,
        description_batch_size: int = 80,
        db_batch_size: int = 1000,
        force_recreate: bool = False
) -> chromadb.Collection:
    """
    Complete pipeline to compile a ChromaDB collection from knowledge graph entities.

    This function orchestrates the entire process:
    1. Retrieves top entities from KG by degree
    2. Adds descriptions to entities using config's descriptor functions
    3. Compiles ChromaDB collection

    Args:
        csv_path: Path for intermediate CSV file (will be created/overwritten).
            If not provided, uses config.csv_path (default: ~/.kgnode/data/top_entities.csv).
        config: Optional KGConfig instance with descriptor functions and settings.
            If None, uses default KGConfig with environment variables or built-in defaults.
        entity_limit: Number of top entities to retrieve from KG
        description_batch_size: Batch size for entity description queries (max 100)
        db_batch_size: Number of documents to insert per batch into ChromaDB
        force_recreate: If True, delete existing collection and create new one

    Returns:
        ChromaDB collection object
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()
    print("=" * 60)
    print("STEP 1: Retrieving top entities by degree")
    print("=" * 60)

    # Step 1: Get top entities by degree
    get_top_entities_by_degree(limit=entity_limit, output_file=csv_path, config=config)

    print("\n" + "=" * 60)
    print("STEP 2: Adding descriptions to entities")
    print("=" * 60)

    # Step 2: Add descriptions to the CSV using config
    add_descriptions_to_csv_batched(
        csv_path=csv_path,
        config=config,
        output_path=csv_path,
        batch_size=description_batch_size
    )

    print("\n" + "=" * 60)
    print("STEP 3: Compiling ChromaDB collection")
    print("=" * 60)

    # Step 3: Compile ChromaDB from the CSV with descriptions
    collection = compile_chromadb_from_csv(
        csv_path=csv_path,
        config=config,
        batch_size=db_batch_size,
        force_recreate=force_recreate
    )

    print("\n" + "=" * 60)
    print("✓ PIPELINE COMPLETE")
    print("=" * 60)

    return collection


def compile_chromadb_from_csv(
        csv_path: str,
        config: Optional[KGConfig] = None,
        batch_size: int = 1000,
        force_recreate: bool = False
) -> chromadb.Collection:
    """
    Compile a ChromaDB collection from a CSV file with entity descriptions.
    Uses batch insertion for fast performance.

    Args:
        csv_path: Path to CSV file with 'entity' and 'description' columns
        config: Optional KGConfig instance for collection settings.
            If None, uses default KGConfig with environment variables or built-in defaults.
        batch_size: Number of documents to insert per batch (larger = faster but more memory)
        force_recreate: If True, delete existing collection and create new one

    Returns:
        ChromaDB collection object
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Extract config values
    collection_name = config.collection_name
    persist_directory = config.chroma_persist_dir
    embedding_model = config.embedding_model
    # Read the CSV file
    print(f"Reading CSV from {csv_path}...")
    df = pd.read_csv(csv_path)

    # Validate required columns
    if 'entity' not in df.columns or 'description' not in df.columns:
        raise ValueError("CSV must have 'entity' and 'description' columns")

    # Remove rows with empty descriptions
    df = df.dropna(subset=['description'])
    df = df[df['description'].str.strip() != '']

    print(f"Found {len(df)} entities with descriptions")

    # Initialize ChromaDB client with persistence
    print(f"Initializing ChromaDB at {persist_directory}...")
    client = chromadb.PersistentClient(path=persist_directory)

    # Delete existing collection if force_recreate is True
    if force_recreate:
        try:
            client.delete_collection(name=collection_name)
            print(f"Deleted existing collection '{collection_name}'")
        except:
            pass

    # Create or get collection with the specified embedding model
    print(f"Creating collection '{collection_name}' with model '{embedding_model}'...")
    collection = client.get_or_create_collection(
        name=collection_name,
        metadata={
            "hnsw:space": "cosine",
            "description": "Entity descriptions from knowledge graph"
        },
        embedding_function=chromadb.utils.embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name=embedding_model
        )
    )

    # Check if collection already has data
    existing_count = collection.count()
    if existing_count > 0 and not force_recreate:
        print(f"Collection already has {existing_count} documents. Use force_recreate=True to rebuild.")
        return collection

    # Prepare data for batch insertion
    entities = df['entity'].tolist()
    descriptions = df['description'].tolist()

    # Insert in batches for performance
    total_batches = (len(entities) + batch_size - 1) // batch_size
    print(f"\nInserting {len(entities)} entities in {total_batches} batches...")

    for i in range(0, len(entities), batch_size):
        batch_entities = entities[i:i + batch_size]
        batch_descriptions = descriptions[i:i + batch_size]

        # Use entity URIs as IDs (ChromaDB requires string IDs)
        # If URIs are too long or have special chars, create simpler IDs
        batch_ids = [f"entity_{j}" for j in range(i, min(i + batch_size, len(entities)))]

        # Store original entity URI in metadata
        batch_metadatas = [{"entity_uri": entity} for entity in batch_entities]

        collection.add(
            ids=batch_ids,
            documents=batch_descriptions,
            metadatas=batch_metadatas
        )

        batch_num = (i // batch_size) + 1
        print(f"Batch {batch_num}/{total_batches} completed ({len(batch_entities)} entities)")

    final_count = collection.count()
    print(f"\n✓ ChromaDB compilation complete!")
    print(f"✓ Total entities indexed: {final_count}")
    print(f"✓ Collection: {collection_name}")
    print(f"✓ Persisted at: {persist_directory}")

    return collection


def _build_type_enhanced_query(entity_name: str, entity_types: List[str]) -> str:
    """Build type-enhanced query string for semantic search.

    Incorporates entity type information into the query string to improve
    semantic search relevance by matching the entity descriptor format.

    Args:
        entity_name: Original entity name (e.g., "Geoffrey Hinton")
        entity_types: Predicted entity types (e.g., ["Creator", "Person"])

    Returns:
        Enhanced query string matching descriptor format

    Examples:
        entity_name="Geoffrey Hinton", types=["Creator", "Person"]
        -> "Creator Person: Geoffrey Hinton."

        entity_name="Deep Learning", types=["Article", "Publication"]
        -> "Article Publication: Deep Learning."

        entity_name="neural networks", types=[]
        -> "neural networks"
    """
    if not entity_types:
        return entity_name

    # Match exact descriptor format: "{Type1} {Type2}: {Name}."
    types_str = " ".join(entity_types)
    enhanced_query = f"{types_str}: {entity_name}."

    return enhanced_query


def semantic_search_entities(
        collection: chromadb.Collection,
        query: str,
        n_results: int = 5,
        entity_types: Optional[List[str]] = None
) -> List[Dict[str, any]]:
    """Search for similar entities based on query with optional type enhancement.

    Args:
        collection: ChromaDB collection
        query: Query text to search for (entity name)
        n_results: Number of results to return
        entity_types: Optional list of entity types to enhance the search query.
            If provided, types are incorporated into the query for better semantic matching.

    Returns:
        List of dictionaries with entity URIs, descriptions, and similarity scores
    """
    # Enhance query with entity types if provided
    if entity_types:
        enhanced_query = _build_type_enhanced_query(query, entity_types)
        print(f"  Semantic search enhanced: '{query}' -> '{enhanced_query}'")
    else:
        enhanced_query = query

    results = collection.query(
        query_texts=[enhanced_query],
        n_results=n_results
    )

    # Format results
    formatted_results = []
    for i in range(len(results['ids'][0])):
        formatted_results.append({
            'entity_uri': results['metadatas'][0][i]['entity_uri'],
            'description': results['documents'][0][i],
            'distance': results['distances'][0][i] if 'distances' in results else None,
            'id': results['ids'][0][i]
        })

    return formatted_results


def _get_next_entity_id(collection: chromadb.Collection) -> int:
    """
    Get the next available entity ID number from a collection.

    Args:
        collection: ChromaDB collection

    Returns:
        Next available entity ID number (e.g., if max is entity_99, returns 100)
    """
    all_ids = collection.get()['ids']
    if not all_ids:
        return 0

    # Extract numeric parts from entity_N format
    id_numbers = []
    for id_str in all_ids:
        if id_str.startswith('entity_'):
            try:
                num = int(id_str.split('_')[1])
                id_numbers.append(num)
            except (ValueError, IndexError):
                continue

    return max(id_numbers) + 1 if id_numbers else 0


def _chromadb_exists(
        config: Optional[KGConfig] = None
) -> bool:
    """
    Check if ChromaDB collection exists.

    Args:
        config: Optional KGConfig instance for collection settings.
            If None, uses default KGConfig with environment variables or built-in defaults.

    Returns:
        True if collection exists, False otherwise
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Extract config values
    collection_name = config.collection_name
    persist_directory = config.chroma_persist_dir

    try:
        client = chromadb.PersistentClient(path=persist_directory)
        client.get_collection(name=collection_name)
        return True
    except:
        return False


def _load_chromadb(
        config: Optional[KGConfig] = None
) -> chromadb.Collection:
    """
    Load an existing ChromaDB collection (private function).

    Args:
        config: Optional KGConfig instance for collection settings.
            If None, uses default KGConfig with environment variables or built-in defaults.

    Returns:
        ChromaDB collection object

    Raises:
        chromadb.errors.NotFoundError: If collection does not exist
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Extract config values
    collection_name = config.collection_name
    persist_directory = config.chroma_persist_dir
    embedding_model = config.embedding_model

    client = chromadb.PersistentClient(path=persist_directory)

    collection = client.get_collection(
        name=collection_name,
        embedding_function=chromadb.utils.embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name=embedding_model
        )
    )

    print(f"Loaded collection '{collection_name}' with {collection.count()} entities")
    return collection


def get_or_create_chromadb(
        config: Optional[KGConfig] = None,
        csv_path: Optional[str] = None,
        entity_limit: int = 10000,
        description_batch_size: int = 80,
        db_batch_size: int = 1000,
        force_recreate: bool = False
) -> chromadb.Collection:
    """
    Get existing ChromaDB collection or create it if it doesn't exist.

    This function intelligently handles ChromaDB collection lifecycle:
    - If force_recreate=True: Recreates collection from scratch
    - If collection exists: Loads existing collection
    - If collection doesn't exist: Creates new collection via compile_chromadb()

    Args:
        config: Optional KGConfig instance for collection settings.
            If None, uses default KGConfig with environment variables or built-in defaults.
        csv_path: Optional path for intermediate CSV file. If None, defaults to
            ~/.kgnode/data/top_entities.csv (can be overridden via KGNODE_DATA_DIR env var)
        entity_limit: Number of top entities to retrieve from KG (used only if creating)
        description_batch_size: Batch size for entity description queries (used only if creating)
        db_batch_size: Number of documents to insert per batch (used only if creating)
        force_recreate: If True, delete existing collection and create new one

    Returns:
        ChromaDB collection object
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Set default csv_path if not provided
    if csv_path is None:
        csv_path = config.csv_path

    # If force_recreate, always compile
    if force_recreate:
        print("Force recreate enabled - compiling ChromaDB from scratch...")
        return compile_chromadb(
            csv_path=csv_path,
            config=config,
            entity_limit=entity_limit,
            description_batch_size=description_batch_size,
            db_batch_size=db_batch_size,
            force_recreate=True
        )

    # Check if collection exists
    if _chromadb_exists(config=config):
        print("ChromaDB collection found - loading existing collection...")
        return _load_chromadb(config=config)
    else:
        print("ChromaDB collection not found - creating new collection...")
        return compile_chromadb(
            csv_path=csv_path,
            config=config,
            entity_limit=entity_limit,
            description_batch_size=description_batch_size,
            db_batch_size=db_batch_size,
            force_recreate=False
        )


def add_or_update_entities(
        entity_uris: List[str],
        config: Optional[KGConfig] = None,
        batch_size: int = 80,
        save_csv: bool = False
) -> tuple[int, int, chromadb.Collection]:
    """
    Add new entities to ChromaDB or update existing ones with new descriptions.

    This function generates descriptions for the provided entity URIs using the config's
    descriptor functions, then either adds them as new entries or updates existing ones.
    ChromaDB automatically re-embeds updated descriptions.

    Args:
        entity_uris: List of entity URIs to add or update
        config: Optional KGConfig instance for generating descriptions and loading collection.
            If None, uses default KGConfig with environment variables or built-in defaults.
        batch_size: Batch size for description generation and DB operations
        save_csv: If True, saves the processed entities to a timestamped CSV file
            in config.chroma_persist_dir with columns: entity_uri, description, status

    Returns:
        Tuple of (num_added, num_updated, collection)

    Raises:
        RuntimeError: If ChromaDB collection does not exist
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Check if collection exists
    if not _chromadb_exists(config=config):
        raise RuntimeError(
            "ChromaDB collection does not exist. Please call get_or_create_chromadb() first "
            "to create the collection before adding or updating entities."
        )

    # Load collection using config
    collection = _load_chromadb(config=config)

    print(f"Processing {len(entity_uris)} entities...")

    # Generate descriptions in batches
    all_descriptions = {}
    for i in range(0, len(entity_uris), batch_size):
        batch = entity_uris[i:i + batch_size]
        print(f"Generating descriptions for batch {i // batch_size + 1}/{(len(entity_uris) - 1) // batch_size + 1}...")
        batch_descriptions = config.describe_entities_batch(batch)
        all_descriptions.update(batch_descriptions)

    # Filter out entities with empty descriptions
    valid_entities = [(uri, desc) for uri, desc in all_descriptions.items()
                      if desc and desc.strip()]

    if not valid_entities:
        print("No valid descriptions generated. Nothing to add or update.")
        return 0, 0, collection

    print(f"\nChecking which entities exist in collection...")

    # Separate into add and update lists
    to_add = []
    to_update = []

    # Query for each entity URI to check if it exists
    for entity_uri, description in valid_entities:
        # Query by metadata to find if entity exists
        results = collection.get(
            where={"entity_uri": entity_uri}
        )

        if results['ids']:
            # Entity exists - prepare for update
            to_update.append({
                'id': results['ids'][0],
                'uri': entity_uri,
                'description': description
            })
        else:
            # Entity doesn't exist - prepare for addition
            to_add.append({
                'uri': entity_uri,
                'description': description
            })

    print(f"Found {len(to_update)} entities to update and {len(to_add)} entities to add")

    # Update existing entities in batches
    num_updated = 0
    if to_update:
        print(f"\nUpdating {len(to_update)} existing entities...")
        for i in range(0, len(to_update), batch_size):
            batch = to_update[i:i + batch_size]

            batch_ids = [item['id'] for item in batch]
            batch_documents = [item['description'] for item in batch]
            batch_metadatas = [{"entity_uri": item['uri']} for item in batch]

            collection.update(
                ids=batch_ids,
                documents=batch_documents,
                metadatas=batch_metadatas
            )

            num_updated += len(batch)
            print(f"Updated batch {i // batch_size + 1}/{(len(to_update) - 1) // batch_size + 1}")

    # Add new entities in batches
    num_added = 0
    if to_add:
        print(f"\nAdding {len(to_add)} new entities...")
        next_id = _get_next_entity_id(collection)

        for i in range(0, len(to_add), batch_size):
            batch = to_add[i:i + batch_size]

            batch_ids = [f"entity_{next_id + j}" for j in range(len(batch))]
            batch_documents = [item['description'] for item in batch]
            batch_metadatas = [{"entity_uri": item['uri']} for item in batch]

            collection.add(
                ids=batch_ids,
                documents=batch_documents,
                metadatas=batch_metadatas
            )

            num_added += len(batch)
            next_id += len(batch)
            print(f"Added batch {i // batch_size + 1}/{(len(to_add) - 1) // batch_size + 1}")

    print(f"\n✓ Complete: Added {num_added}, Updated {num_updated}")
    print(f"✓ Total entities in collection: {collection.count()}")

    # Save to CSV if requested
    if save_csv and (to_add or to_update):
        records = []
        for item in to_add:
            records.append({
                'entity_uri': item['uri'],
                'description': item['description'],
                'status': 'added'
            })
        for item in to_update:
            records.append({
                'entity_uri': item['uri'],
                'description': item['description'],
                'status': 'updated'
            })

        df = pd.DataFrame(records)
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        csv_filename = f"{timestamp}.csv"
        csv_path = os.path.join(config.data_dir, csv_filename)

        os.makedirs(config.data_dir, exist_ok=True)
        df.to_csv(csv_path, index=False)
        print(f"✓ Saved entity records to {csv_path}")

    return num_added, num_updated, collection


def delete_entities(
        entity_uris: List[str],
        config: Optional[KGConfig] = None
) -> int:
    """
    Delete entities from ChromaDB by their URIs.

    Args:
        entity_uris: List of entity URIs to delete
        config: Optional KGConfig instance for loading collection.
            If None, uses default KGConfig with environment variables or built-in defaults.

    Returns:
        Number of entities successfully deleted

    Raises:
        RuntimeError: If ChromaDB collection does not exist
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Check if collection exists
    if not _chromadb_exists(config=config):
        raise RuntimeError(
            "ChromaDB collection does not exist. Please call get_or_create_chromadb() first "
            "to create the collection before deleting entities."
        )

    # Load collection using config
    collection = _load_chromadb(config=config)

    print(f"Searching for {len(entity_uris)} entities to delete...")

    # Find ChromaDB IDs for each entity URI
    ids_to_delete = []
    for entity_uri in entity_uris:
        results = collection.get(
            where={"entity_uri": entity_uri}
        )

        if results['ids']:
            ids_to_delete.extend(results['ids'])

    # Delete all found IDs in one operation
    if ids_to_delete:
        print(f"Deleting {len(ids_to_delete)} entities...")
        collection.delete(ids=ids_to_delete)
        print(f"✓ Successfully deleted {len(ids_to_delete)} entities")
        print(f"✓ Remaining entities in collection: {collection.count()}")
    else:
        print("No matching entities found to delete")

    return len(ids_to_delete)


if __name__ == "__main__":
    # Add description to csv speed checking
    # start_time = time.time()
    # config = KGConfig.default()  # Use default DBLP descriptors
    # add_descriptions_to_csv_batched("./test_top_entities.csv", config=config, batch_size=80)
    #
    # end_time = time.time()
    # elapsed_time = end_time - start_time
    #
    # print(f"\n{'=' * 60}")
    # print(f"Total execution time: {elapsed_time:.2f} seconds")
    # print(f"Total execution time: {elapsed_time / 60:.2f} minutes")
    # print(f"{'=' * 60}")

    # ==================================================================
    # Compile ChromaDB with full pipeline (entity ranking + descriptions + vector db)
    # start_time = time.time()
    #
    # # Option A: Use default config (recommended)
    # collection = compile_chromadb(
    #     csv_path="../../_data/vector_db/test_top_entities.csv",
    #     entity_limit=10000,
    #     description_batch_size=80,
    #     db_batch_size=1000,  # Adjust based on your memory
    #     force_recreate=True  # Set to False to skip if already exists
    # )
    #
    # # Option B: Use custom config
    # # config = KGConfig.default()  # or KGConfig(embedding_model="custom-model")
    # # collection = compile_chromadb(
    # #     csv_path="../../_data/vector_db/test_top_entities.csv",
    # #     config=config,
    # #     entity_limit=10000,
    # #     description_batch_size=80,
    # #     db_batch_size=1000,
    # #     force_recreate=True
    # # )
    #
    # elapsed = time.time() - start_time
    # print(f"\nTotal time: {elapsed:.2f} seconds")
    #
    # # Search for similar entities
    # print("\n" + "=" * 60)
    # print("TESTING SEARCH")
    # print("=" * 60)
    #
    # query = "somatic drivers in 2,658 cancer whole genomes"
    # results = semantic_search_entities(collection, query, n_results=3)
    #
    # print(f"\nQuery: {query}\n")
    # for i, result in enumerate(results, 1):
    #     print(f"{i}. Entity: {result['entity_uri']}")
    #     print(f"   Distance: {result['distance']:.4f}")
    #     print(f"   Description: {result['description'][:200]}...")
    #     print()

    # ==================================================================
    # Example 1: Add or update entities
    # ==================================================================
    print("\n" + "=" * 60)
    print("EXAMPLE: ADD OR UPDATE ENTITIES")
    print("=" * 60)

    # Define entity URIs to add/update
    new_entities = [
        "https://dblp.org/pid/95/2265",
        "https://dblp.org/pid/04/6636",
        "https://dblp.org/pid/s/MohammadSoleymani",
        "https://dblp.org/pid/304/4294",
        "https://dblp.org/pid/08/4968",
        "https://dblp.org/pid/58/6070",
        "https://dblp.org/pid/141/4165",
        "https://dblp.org/pid/r/MattiRossi",
        "https://dblp.org/pid/180/1494",
        "https://dblp.org/pid/12/3559",
        "https://dblp.org/pid/g/PeterWGlynn",
        "https://dblp.org/pid/93/5969",
        "https://dblp.org/pid/199/9664",
        "https://dblp.org/pid/33/7873",
        "https://dblp.org/pid/172/1162",
        "https://dblp.org/pid/230/3185",
        "https://dblp.org/pid/00/2941",
        "https://dblp.org/pid/16/304",
        "https://dblp.org/pid/85/5045",
        "https://dblp.org/pid/35/6713",
    ]

    # Option A: Use default config (recommended)
    num_added, num_updated, collection = add_or_update_entities(
        entity_uris=new_entities,
        batch_size=80,
        save_csv=True,
    )

    # Option B: Use custom config
    # config = KGConfig.default()  # or KGConfig(embedding_model="custom-model")
    # num_added, num_updated, collection = add_or_update_entities(
    #     entity_uris=new_entities,
    #     config=config,
    #     batch_size=80
    # )

    print(f"\nResults: {num_added} added, {num_updated} updated")

    # ==================================================================
    # Example 2: Delete entities
    # ==================================================================
    # print("\n" + "=" * 60)
    # print("EXAMPLE: DELETE ENTITIES")
    # print("=" * 60)
    #
    # # Define entity URIs to delete
    # entities_to_delete = [
    #     "https://dblp.org/pid/64/6025-131",
    #     "https://dblp.org/pid/204/5989"
    # ]
    #
    # # Option A: Use default config (recommended)
    # num_deleted = delete_entities(
    #     entity_uris=entities_to_delete
    # )
    #
    # # Option B: Use custom config
    # # config = KGConfig.default()  # or KGConfig(embedding_model="custom-model")
    # # num_deleted = delete_entities(
    # #     entity_uris=entities_to_delete,
    # #     config=config
    # # )
    #
    # print(f"\nDeleted {num_deleted} entities")