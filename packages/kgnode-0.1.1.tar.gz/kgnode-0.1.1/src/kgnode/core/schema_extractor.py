"""Schema extraction from knowledge graphs.

This module provides internal functionality to extract entity types and relation types
from either an ontology file (.nt format) or via SPARQL queries.

All functions are private (internal use only).
"""

from typing import Dict, List, Optional, Set

from kgnode.core.kg_config import KGConfig
from kgnode.core.sparql_query import execute_sparql_query


def _uri_to_readable_label(uri: str) -> str:
    """Convert a URI to a human-readable label.

    Args:
        uri: Full URI (e.g., "http://www.w3.org/1999/02/22-rdf-syntax-ns#type")

    Returns:
        Readable label (e.g., "type")

    Examples:
        >>> _uri_to_readable_label("http://example.org/Person")
        'Person'
        >>> _uri_to_readable_label("http://xmlns.com/foaf/0.1/knows")
        'knows'
    """
    if not uri:
        return ""

    # Handle URIs with fragment (#)
    if "#" in uri:
        return uri.split("#")[-1]

    # Handle URIs with path separator (/)
    if "/" in uri:
        return uri.split("/")[-1]

    return uri


def _extract_schema_from_ontology(ontology_path: str) -> Dict[str, List[str]]:
    """Extract entity types and relation types from an ontology file (.nt format).

    Args:
        ontology_path: Path to ontology file in N-Triples (.nt) format

    Returns:
        Dict with 'entity_types' and 'relation_types' keys, each containing a list of labels
        Example: {'entity_types': ['Person', 'Publication'], 'relation_types': ['authoredBy']}

    Raises:
        FileNotFoundError: If ontology file doesn't exist
        ValueError: If ontology file cannot be parsed
    """
    try:
        from rdflib import Graph, RDF, RDFS, OWL
    except ImportError:
        raise ImportError(
            "rdflib is required for ontology parsing. Install with: pip install rdflib"
        )

    # Load ontology file
    g = Graph()
    try:
        g.parse(ontology_path, format="nt")
    except Exception as e:
        raise ValueError(f"Failed to parse ontology file {ontology_path}: {e}")

    entity_types: Set[str] = set()
    relation_types: Set[str] = set()

    # Extract entity types (classes)
    # Look for: ?s rdf:type owl:Class or ?s rdf:type rdfs:Class
    for s in g.subjects(RDF.type, OWL.Class):
        label = _uri_to_readable_label(str(s))
        if label:
            entity_types.add(label)

    for s in g.subjects(RDF.type, RDFS.Class):
        label = _uri_to_readable_label(str(s))
        if label:
            entity_types.add(label)

    # Extract relation types (properties)
    # Store both URIs and labels
    relation_uris_set: Set[str] = set()

    # Look for: ?s rdf:type owl:ObjectProperty or rdf:Property
    for s in g.subjects(RDF.type, OWL.ObjectProperty):
        relation_uris_set.add(str(s))

    for s in g.subjects(RDF.type, RDF.Property):
        relation_uris_set.add(str(s))

    # Also check for owl:DatatypeProperty
    for s in g.subjects(RDF.type, OWL.DatatypeProperty):
        relation_uris_set.add(str(s))

    # Convert URIs to labels while preserving order
    relation_uris_list = sorted(list(relation_uris_set))
    relation_types_list = [_uri_to_readable_label(uri) for uri in relation_uris_list]

    return {
        "entity_types": sorted(list(entity_types)),
        "relation_types": relation_types_list,
        "relation_uris": relation_uris_list,
    }


def _extract_schema_from_sparql(config: Optional[KGConfig] = None) -> Dict[str, List[str]]:
    """Extract entity types and relation types from knowledge graph via SPARQL.

    Args:
        config: KGConfig instance with SPARQL endpoint configuration

    Returns:
        Dict with keys:
        - 'entity_types': List of entity type labels
        - 'relation_types': List of relation type labels
        - 'relation_uris': List of full relation URIs (same order as relation_types)

        Example: {
            'entity_types': ['Person', 'Publication'],
            'relation_types': ['authoredBy', 'wikidata'],
            'relation_uris': ['https://dblp.org/rdf/schema#authoredBy', 'https://dblp.org/rdf/schema#wikidata']
        }
    """
    # Extract entity types (rdf:type objects)
    entity_types_query = """
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

    SELECT DISTINCT ?type
    WHERE {
        ?entity rdf:type ?type .
    }
    LIMIT 1000
    """

    entity_results = execute_sparql_query(entity_types_query, config=config)
    entity_types = [
        _uri_to_readable_label(result.get("type", ""))
        for result in entity_results
        if result.get("type")
    ]

    # Extract relation types (all predicates except rdf:type)
    # LIMIT to make it faster on large KGs
    relation_types_query = """
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>

    SELECT DISTINCT ?predicate
    WHERE {
        ?s ?predicate ?o .
        FILTER (?predicate != rdf:type)
    }
    LIMIT 1000
    """

    relation_results = execute_sparql_query(relation_types_query, config=config)

    # Store both labels and full URIs
    relation_uris = []
    relation_types = []
    seen = set()

    for result in relation_results:
        uri = result.get("predicate", "")
        if uri and uri not in seen:
            seen.add(uri)
            relation_uris.append(uri)
            relation_types.append(_uri_to_readable_label(uri))

    return {
        "entity_types": sorted(list(set(entity_types))),
        "relation_types": relation_types,  # Keep same order as URIs
        "relation_uris": relation_uris,    # Full URIs for filtering
    }


def _get_schema(
    config: Optional[KGConfig] = None, ontology_path: Optional[str] = None
) -> Dict[str, List[str]]:
    """Get schema from ontology file or SPARQL endpoint.

    This is the main entry point for schema extraction. It tries the ontology file first
    (if provided), then falls back to SPARQL extraction.

    Args:
        config: KGConfig instance with SPARQL endpoint configuration
        ontology_path: Optional path to ontology file (.nt format)

    Returns:
        Dict with 'entity_types' and 'relation_types' keys
        Example: {'entity_types': ['Person', 'Publication'], 'relation_types': ['authoredBy']}
    """
    # Try ontology file first
    if ontology_path:
        try:
            print(f"Extracting schema from ontology file: {ontology_path}")
            schema = _extract_schema_from_ontology(ontology_path)
            print(
                f"✓ Extracted {len(schema['entity_types'])} entity types and "
                f"{len(schema['relation_types'])} relation types from ontology"
            )
            return schema
        except Exception as e:
            print(f"Warning: Failed to extract from ontology: {e}")
            print("Falling back to SPARQL extraction...")

    # Fallback to SPARQL extraction
    print("Extracting schema from SPARQL endpoint...")
    schema = _extract_schema_from_sparql(config)
    print(
        f"✓ Extracted {len(schema['entity_types'])} entity types and "
        f"{len(schema['relation_types'])} relation types from SPARQL"
    )
    return schema


if __name__ == "__main__":
    """Example usage of schema extraction."""
    from kgnode.core.kg_config import KGConfig

    print("=" * 60)
    print("EXAMPLE 1: Extract from SPARQL endpoint")
    print("=" * 60)

    config = KGConfig()
    schema = _get_schema(config=config, ontology_path="../../../_data/schema.nt")

    print(f"\nEntity Types (first 10):")
    for et in schema["entity_types"][:10]:
        print(f"  - {et}")

    print(f"\nRelation Types (first 10):")
    for rt in schema["relation_types"][:10]:
        print(f"  - {rt}")

    print("\n" + "=" * 60)
    print("EXAMPLE 2: Extract from ontology file")
    print("=" * 60)
    print("\nTo use with ontology:")
    print("  schema = _get_schema(config=config, ontology_path='_data/ontology.nt')")
    print("\n✓ Schema extraction examples complete!")
