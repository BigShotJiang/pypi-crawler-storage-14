import os
from typing import Callable, Optional, List, Dict, Any, Type, TypedDict
import dspy


# Type aliases for descriptor functions
EntityDescriptorFunction = Callable[[str, List[Dict[str, Any]]], str]
RelationDescriptorFunction = Callable[[str], str]


class ExtractedEntity(TypedDict):
    """Entity extracted from query with predicted types."""
    name: str              # e.g., "Geoffrey Hinton"
    types: List[str]       # e.g., ["Creator", "Person"]


# ============================================================================
# DEFAULT DSPY SIGNATURES
# ============================================================================

class EntityExtractionSignature(dspy.Signature):
    """Extract entity names WITH predicted types from a natural language query.

    Given a natural language query, identify key entities and predict their types
    using the provided schema context. Each entity can have 1-3 predicted types.
    """
    query: str = dspy.InputField(desc="Natural language query from user")
    schema_context: str = dspy.InputField(desc="Available entity types in the knowledge graph schema")
    entities: str = dspy.OutputField(desc='JSON array of objects with "name" and "types" fields, e.g., [{"name": "John Smith", "types": ["Creator", "Person"]}, {"name": "ICML", "types": ["Inproceedings"]}]')


class TemplateCreationSignature(dspy.Signature):
    """Convert a question into a short knowledge graph path pattern.

    Extract entity names from the question and include them along with key relationships
    and concepts. Keep it concise (3-7 words) and include entity names.
    """
    query: str = dspy.InputField(desc="Natural language question")
    path_pattern: str = dspy.OutputField(desc="Concise path pattern with entity names and relationships")


class SchemaAwareTemplateCreationSignature(dspy.Signature):
    """Convert a question into a knowledge graph path pattern using schema context.

    Use the provided schema context (entity types and relation types) to guide your
    path pattern creation. Include relevant entity names from the query and use
    relationship types that exist in the schema.
    """
    query: str = dspy.InputField(desc="Natural language question")
    schema_context: str = dspy.InputField(desc="Available entity types and relation types in the KG")
    path_pattern: str = dspy.OutputField(desc="Concise path pattern using schema terms")


class SPARQLGenerationSignature(dspy.Signature):
    """Generate a valid SPARQL query from natural language query and knowledge graph subgraphs.

    Rules:
    1. Use the exact URIs provided in the subgraphs
    2. Generate a SELECT query that returns the answer
    3. You may combine information from multiple paths if needed
    4. Use DISTINCT to avoid duplicates
    5. Keep the query simple and focused
    6. Use proper SPARQL syntax with PREFIX declarations if needed
    """
    query: str = dspy.InputField(desc="User's natural language query")
    subgraphs: str = dspy.InputField(desc="Formatted knowledge graph subgraphs with paths and URIs")
    sparql: str = dspy.OutputField(desc="Valid SPARQL query without markdown code blocks")


class AnswerGenerationSignature(dspy.Signature):
    """Generate natural language answer from knowledge graph query results.

    Analyze the SPARQL query results and generate a clear, concise natural language answer.
    """
    query: str = dspy.InputField(desc="User's natural language question")
    results: str = dspy.InputField(desc="SPARQL query results")
    answer: str = dspy.OutputField(desc="Natural language answer")
    citations: str = dspy.OutputField(desc="JSON array of entity URIs cited, e.g., [\"uri1\", \"uri2\"]")
    confidence: float = dspy.OutputField(desc="Confidence score between 0.0 and 1.0")


class AnswerFromSubgraphSignature(dspy.Signature):
    """Generate natural language answer from knowledge graph paths.

    Analyze the knowledge graph paths and generate a clear, concise natural language answer.
    Indicate which paths support your answer and provide confidence based on how well
    the paths answer the question.
    """
    query: str = dspy.InputField(desc="User's natural language question")
    subgraphs: str = dspy.InputField(desc="Formatted knowledge graph paths with node labels and URIs")
    answer: str = dspy.OutputField(desc="Natural language answer")
    citations: str = dspy.OutputField(desc="JSON array of entity URIs cited, e.g., [\"uri1\", \"uri2\"]")
    confidence: float = dspy.OutputField(desc="Confidence score between 0.0 and 1.0")
    subgraphs_used: str = dspy.OutputField(desc="JSON array of subgraph indices used, e.g., [1, 3]")


class KGConfig:
    """Configuration class for KGNode with environment variable support.

    This class allows users to configure custom entity and relation descriptor
    functions for their specific knowledge graph schema. If not provided,
    default DBLP descriptors will be used.
    """

    # ============================================================================
    # SECTION A: CORE INFRASTRUCTURE
    # ============================================================================
    DEFAULT_SPARQL_ENDPOINT = os.getenv(
        "KGNODE_SPARQL_ENDPOINT", default="http://localhost:7878/query"
    )
    DEFAULT_EMBEDDING_MODEL = os.getenv("KGNODE_EMBEDDING_MODEL", default="all-MiniLM-L6-v2")
    DEFAULT_OPENAI_MODEL = os.getenv("KGNODE_OPENAI_MODEL", default="openai/gpt-4o-mini")
    DEFAULT_LM_API_KEY = ""
    DEFAULT_COLLECTION_NAME = "top_entity_descriptions"
    DEFAULT_CHROMA_PERSIST_DIR = os.path.expanduser("~/.kgnode/chroma_db")
    DEFAULT_DATA_DIR = os.path.expanduser(
        os.getenv("KGNODE_DATA_DIR", "~/.kgnode/data")
    )
    DEFAULT_CSV_PATH = os.path.join(DEFAULT_DATA_DIR, "top_entities.csv")

    # ============================================================================
    # SECTION B: THRESHOLDS & BEHAVIOR FLAGS
    # ============================================================================
    DEFAULT_SEMANTIC_SIMILARITY_THRESHOLD = 0.6
    DEFAULT_FUZZY_MATCH_THRESHOLD = 0.8
    DEFAULT_CHAIN_OF_THOUGHT = False

    # ============================================================================
    # SECTION C: SCHEMA-AWARE CONFIGURATION
    # ============================================================================
    DEFAULT_USE_SCHEMA_AWARE_TEMPLATES = True
    DEFAULT_SCHEMA_TOP_K_ENTITIES = 20
    DEFAULT_SCHEMA_TOP_K_RELATIONS = 30
    DEFAULT_SCHEMA_INCLUDE_EXAMPLES = False
    DEFAULT_FORCE_SCHEMA_REFRESH = False

    # Schema-based relation filtering (Phase 1)
    DEFAULT_ENABLE_SCHEMA_BASED_FILTERING = True
    DEFAULT_FALLBACK_TO_ALL_RELATIONS = False

    # ============================================================================
    # SECTION D: DSPY SIGNATURES (by task)
    # ============================================================================
    # Entity Extraction
    DEFAULT_ENTITY_EXTRACTION_SIGNATURE = EntityExtractionSignature

    # Template Creation
    DEFAULT_TEMPLATE_CREATION_SIGNATURE = TemplateCreationSignature
    DEFAULT_SCHEMA_AWARE_TEMPLATE_CREATION_SIGNATURE = SchemaAwareTemplateCreationSignature

    # SPARQL Generation
    DEFAULT_SPARQL_GENERATION_SIGNATURE = SPARQLGenerationSignature

    # Answer Generation
    DEFAULT_ANSWER_GENERATION_SIGNATURE = AnswerGenerationSignature
    DEFAULT_ANSWER_FROM_SUBGRAPH_SIGNATURE = AnswerFromSubgraphSignature

    # ============================================================================
    # SECTION E: DSPY INSTRUCTION STRINGS (with few-shot examples)
    # ============================================================================

    # --- Entity Extraction ---
    DEFAULT_ENTITY_EXTRACTION_INSTRUCTION = """Extract key entities from the natural language query and predict their types using the provided schema context.

For each entity:
1. Identify the entity name from the query
2. Predict 1-3 most likely entity types from the schema context
3. If highly confident, use 1 type; if uncertain, use up to 3 types

Examples:

Query: "Show papers by John Smith published in ICML"
Schema Context: Entity Types: Creator, Person, Publication, Inproceedings, Article
Entities: [{"name": "John Smith", "types": ["Creator", "Person"]}, {"name": "ICML", "types": ["Inproceedings"]}]

Query: "What is the Wikidata ID of Robert Schober?"
Schema Context: Entity Types: Creator, Person, Organization
Entities: [{"name": "Robert Schober", "types": ["Creator", "Person"]}]

Query: "Find authors who collaborated with Alice Wang on machine learning papers"
Schema Context: Entity Types: Creator, Person, Publication, Article
Entities: [{"name": "Alice Wang", "types": ["Creator"]}, {"name": "machine learning", "types": ["Article", "Publication"]}]

Query: "List publications about neural networks in 2020"
Schema Context: Entity Types: Article, Publication, Inproceedings, Literal
Entities: [{"name": "neural networks", "types": ["Article", "Publication"]}, {"name": "2020", "types": ["Literal"]}]"""

    # --- Template Creation ---
    DEFAULT_TEMPLATE_CREATION_INSTRUCTION = """Convert the natural language query into a concise path pattern (3-7 words) that represents the knowledge graph traversal needed.

Examples:

Query: "What is the Wikidata ID of Robert Schober?"
Path Pattern: Robert Schober wikidata identifier

Query: "Show papers by John Smith published in ICML"
Path Pattern: John Smith papers ICML venue

Query: "Find authors who collaborated with Alice Wang"
Path Pattern: Alice Wang coauthor relationships

Query: "List publications about neural networks in 2020"
Path Pattern: neural networks publications 2020"""

    # --- Schema-Aware Template Creation ---
    DEFAULT_SCHEMA_AWARE_TEMPLATE_CREATION_INSTRUCTION = """Convert the natural language query into a concise path pattern (3-7 words) using the provided schema context.

CRITICAL: Use EXACT relation names from the schema context. Do NOT paraphrase, add extra words, or use synonyms.

Rules:
1. Use ONLY relation names that appear in the "Relations:" list
2. Include entity names from the query
3. Keep pattern to 3-7 words
4. Do NOT add extra words to relation names
5. Do NOT use synonyms for relation names

Examples:

✓ CORRECT:
Query: "What is the Wikidata ID of Robert Schober?"
Schema Context:
  Entity Types: Person, Publication, Venue
  Relations: wikidata, authoredBy, publishedIn
Path Pattern: Robert Schober wikidata

✗ INCORRECT (do not do this):
Path Pattern: Robert Schober wikidata ID  ← Don't add "ID"
Path Pattern: Robert Schober identifier   ← Don't use synonym

---

✓ CORRECT:
Query: "Show papers by John Smith published in ICML"
Schema Context:
  Entity Types: Person, Publication, Venue
  Relations: authoredBy, publishedIn
Path Pattern: John Smith authoredBy publications publishedIn ICML

✗ INCORRECT:
Path Pattern: John Smith authored papers in ICML  ← Don't paraphrase "authoredBy"

---

✓ CORRECT:
Query: "Find authors who collaborated with Alice Wang"
Schema Context:
  Relations: authoredBy, coauthorOf, cites
Path Pattern: Alice Wang coauthorOf

✗ INCORRECT:
Path Pattern: Alice Wang collaborated with  ← Use "coauthorOf", not "collaborated"

---

✓ CORRECT:
Query: "List publications about neural networks in 2020"
Schema Context:
  Relations: hasTitle, publishedYear, about
Path Pattern: neural networks publications publishedYear 2020"""

    # --- SPARQL Generation ---
    DEFAULT_SPARQL_GENERATION_INSTRUCTION = """Generate a valid SPARQL query from the natural language query and knowledge graph subgraphs provided.

Rules:
1. Use EXACT URIs from the subgraphs
2. Generate a SELECT query that returns the answer
3. Use DISTINCT to avoid duplicates
4. Keep the query simple and focused
5. Include PREFIX declarations if needed

Example:

Query: "What is the Wikidata ID of Robert Schober?"
Subgraphs: Path 1: <https://dblp.org/pid/s/RobertSchober> --hasWikidataId--> <http://www.wikidata.org/entity/Q1234>
SPARQL:
PREFIX dblp: <https://dblp.org/rdf/schema#>
SELECT DISTINCT ?wikidataId WHERE {
  <https://dblp.org/pid/s/RobertSchober> dblp:hasWikidataId ?wikidataId .
}

Example:

Query: "Show papers by John Smith"
Subgraphs: Path 1: <https://dblp.org/pid/123/456> --authoredBy--> <https://dblp.org/rec/conf/icml/Smith20>
SPARQL:
PREFIX dblp: <https://dblp.org/rdf/schema#>
SELECT DISTINCT ?paper WHERE {
  ?paper dblp:authoredBy <https://dblp.org/pid/123/456> .
}"""

    # --- Answer Generation from SPARQL Results ---
    DEFAULT_ANSWER_GENERATION_INSTRUCTION = """Generate a clear, concise natural language answer from the SPARQL query results.

Examples:

Query: "What is the Wikidata ID of Robert Schober?"
Results: [{"wikidataId": "Q1234567"}]
Answer: The Wikidata ID of Robert Schober is Q1234567.
Citations: ["https://dblp.org/pid/s/RobertSchober"]
Confidence: 0.95

Query: "How many papers did John Smith publish?"
Results: [{"count": 42}]
Answer: John Smith has published 42 papers.
Citations: ["https://dblp.org/pid/123/456"]
Confidence: 0.9

Query: "List venues where Alice Wang published"
Results: [{"venue": "ICML"}, {"venue": "NeurIPS"}, {"venue": "ICLR"}]
Answer: Alice Wang has published in ICML, NeurIPS, and ICLR.
Citations: ["https://dblp.org/pid/w/AliceWang"]
Confidence: 0.85"""

    # --- Answer Generation from Subgraph Paths ---
    DEFAULT_ANSWER_FROM_SUBGRAPH_INSTRUCTION = """Generate a clear, concise natural language answer by analyzing the knowledge graph paths provided.

Examples:

Query: "What is the Wikidata ID of Robert Schober?"
Subgraphs:
Path 1: Person: Robert Schober --hasWikidataId--> Q1234567
Answer: The Wikidata ID of Robert Schober is Q1234567.
Citations: ["https://dblp.org/pid/s/RobertSchober"]
Confidence: 0.95
Subgraphs Used: [1]

Query: "Who collaborated with John Smith?"
Subgraphs:
Path 1: Person: John Smith --coauthorOf--> Paper: ML Basics --authoredBy--> Person: Alice Wang
Path 2: Person: John Smith --coauthorOf--> Paper: Deep Learning --authoredBy--> Person: Bob Chen
Answer: John Smith collaborated with Alice Wang and Bob Chen.
Citations: ["https://dblp.org/pid/123/456", "https://dblp.org/pid/789/012", "https://dblp.org/pid/345/678"]
Confidence: 0.9
Subgraphs Used: [1, 2]

Query: "Where did Alice Wang publish in 2020?"
Subgraphs:
Path 1: Person: Alice Wang --authorOf--> Paper: Neural Nets (2020) --publishedIn--> Venue: ICML
Path 2: Person: Alice Wang --authorOf--> Paper: Deep Models (2020) --publishedIn--> Venue: NeurIPS
Answer: In 2020, Alice Wang published papers in ICML and NeurIPS.
Citations: ["https://dblp.org/pid/w/AliceWang", "https://dblp.org/rec/conf/icml/Wang20", "https://dblp.org/rec/conf/nips/Wang20a"]
Confidence: 0.88
Subgraphs Used: [1, 2]"""

    def __init__(
        self,
        # Descriptor functions
        entity_descriptor: Optional[EntityDescriptorFunction] = None,
        relation_descriptor: Optional[RelationDescriptorFunction] = None,
        # Core infrastructure
        sparql_endpoint: Optional[str] = None,
        embedding_model: Optional[str] = None,
        openai_model: Optional[str] = None,
        lm_api_key: Optional[str] = None,
        collection_name: Optional[str] = None,
        chroma_persist_dir: Optional[str] = None,
        data_dir: Optional[str] = None,
        csv_path: Optional[str] = None,
        # Thresholds and behavior flags
        semantic_similarity_threshold: Optional[float] = None,
        fuzzy_match_threshold: Optional[float] = None,
        chain_of_thought: Optional[bool] = None,
        # Schema-aware configuration
        ontology_path: Optional[str] = None,
        use_schema_aware_templates: Optional[bool] = None,
        schema_top_k_entities: Optional[int] = None,
        schema_top_k_relations: Optional[int] = None,
        schema_include_examples: Optional[bool] = None,
        force_schema_refresh: Optional[bool] = None,
        # DSpy signatures (6 tasks)
        entity_extraction_signature: Optional[Type[dspy.Signature]] = None,
        template_creation_signature: Optional[Type[dspy.Signature]] = None,
        schema_aware_template_creation_signature: Optional[Type[dspy.Signature]] = None,
        sparql_generation_signature: Optional[Type[dspy.Signature]] = None,
        answer_generation_signature: Optional[Type[dspy.Signature]] = None,
        answer_from_subgraph_signature: Optional[Type[dspy.Signature]] = None,
        # DSpy instructions (6 tasks)
        entity_extraction_instruction: Optional[str] = None,
        template_creation_instruction: Optional[str] = None,
        schema_aware_template_creation_instruction: Optional[str] = None,
        sparql_generation_instruction: Optional[str] = None,
        answer_generation_instruction: Optional[str] = None,
        answer_from_subgraph_instruction: Optional[str] = None,
    ):
        """Initialize KGConfig with optional custom descriptor functions.

        Args:
            entity_descriptor: Optional custom function for entity descriptions.
                Should take (entity_uri: str, triples: List[Dict]) and return str.
                If None, uses default DBLP descriptor logic.
            relation_descriptor: Optional custom function for relation descriptions.
                Should take (relation_uri: str) and return str.
                If None, uses default URI-to-label conversion.
            sparql_endpoint: Optional SPARQL endpoint URL.
            embedding_model: Optional embedding model name.
            openai_model: Optional OpenAI model name.
            lm_api_key: Optional API key for language model. If not provided or empty, will load from OPENAI_API_KEY environment variable.
            collection_name: Optional ChromaDB collection name.
            chroma_persist_dir: Optional directory for ChromaDB persistence.
            data_dir: Optional directory for data files.
            csv_path: Optional path for entity CSV file.
            semantic_similarity_threshold: Optional threshold for semantic similarity (lower is better).
            fuzzy_match_threshold: Optional threshold for fuzzy matching (higher is better).
            chain_of_thought: Whether to use DSpy ChainOfThought (True) or Predict (False).
            ontology_path: Path to ontology file (.nt format) for schema extraction.
            use_schema_aware_templates: Enable schema-aware template creation (default True).
            schema_top_k_entities: Number of entity types to include in template context.
            schema_top_k_relations: Number of relation types to include in template context.
            schema_include_examples: Include examples with schema types in prompt.
            force_schema_refresh: Force refresh of schema collections.
            entity_extraction_signature: Custom DSpy signature for entity extraction.
            template_creation_signature: Custom DSpy signature for template creation.
            schema_aware_template_creation_signature: Custom DSpy signature for schema-aware template creation.
            sparql_generation_signature: Custom DSpy signature for SPARQL generation.
            answer_generation_signature: Custom DSpy signature for answer generation.
            answer_from_subgraph_signature: Custom DSpy signature for answer from subgraph.
            entity_extraction_instruction: Custom instruction string for entity extraction with few-shot examples.
            template_creation_instruction: Custom instruction string for template creation with few-shot examples.
            schema_aware_template_creation_instruction: Custom instruction string for schema-aware template creation.
            sparql_generation_instruction: Custom instruction string for SPARQL generation with few-shot examples.
            answer_generation_instruction: Custom instruction string for answer generation with few-shot examples.
            answer_from_subgraph_instruction: Custom instruction string for answer from subgraph with few-shot examples.
        """
        # Descriptor functions
        self._entity_descriptor = entity_descriptor
        self._relation_descriptor = relation_descriptor

        # Core infrastructure
        self.sparql_endpoint = sparql_endpoint or self.DEFAULT_SPARQL_ENDPOINT
        self.embedding_model = embedding_model or self.DEFAULT_EMBEDDING_MODEL
        self.openai_model = openai_model or self.DEFAULT_OPENAI_MODEL
        self.lm_api_key = lm_api_key or self.DEFAULT_LM_API_KEY
        if not self.lm_api_key:
            self.lm_api_key = os.getenv("OPENAI_API_KEY", "")
        self.collection_name = collection_name or self.DEFAULT_COLLECTION_NAME
        self.chroma_persist_dir = chroma_persist_dir or self.DEFAULT_CHROMA_PERSIST_DIR
        self.data_dir = data_dir or self.DEFAULT_DATA_DIR
        self.csv_path = csv_path or self.DEFAULT_CSV_PATH

        # Thresholds and behavior flags
        self.semantic_similarity_threshold = semantic_similarity_threshold or self.DEFAULT_SEMANTIC_SIMILARITY_THRESHOLD
        self.fuzzy_match_threshold = fuzzy_match_threshold or self.DEFAULT_FUZZY_MATCH_THRESHOLD
        self.chain_of_thought = chain_of_thought if chain_of_thought is not None else self.DEFAULT_CHAIN_OF_THOUGHT

        # Schema-aware configuration
        self.ontology_path = ontology_path
        self.use_schema_aware_templates = use_schema_aware_templates if use_schema_aware_templates is not None else self.DEFAULT_USE_SCHEMA_AWARE_TEMPLATES
        self.schema_top_k_entities = schema_top_k_entities if schema_top_k_entities is not None else self.DEFAULT_SCHEMA_TOP_K_ENTITIES
        self.schema_top_k_relations = schema_top_k_relations if schema_top_k_relations is not None else self.DEFAULT_SCHEMA_TOP_K_RELATIONS
        self.schema_include_examples = schema_include_examples if schema_include_examples is not None else self.DEFAULT_SCHEMA_INCLUDE_EXAMPLES
        self.force_schema_refresh = force_schema_refresh if force_schema_refresh is not None else self.DEFAULT_FORCE_SCHEMA_REFRESH

        # Schema-based relation filtering (Phase 1)
        self.enable_schema_based_filtering = self.DEFAULT_ENABLE_SCHEMA_BASED_FILTERING
        self.fallback_to_all_relations = self.DEFAULT_FALLBACK_TO_ALL_RELATIONS

        # DSpy signatures
        self.entity_extraction_signature = entity_extraction_signature or self.DEFAULT_ENTITY_EXTRACTION_SIGNATURE
        self.template_creation_signature = template_creation_signature or self.DEFAULT_TEMPLATE_CREATION_SIGNATURE
        self.schema_aware_template_creation_signature = schema_aware_template_creation_signature or self.DEFAULT_SCHEMA_AWARE_TEMPLATE_CREATION_SIGNATURE
        self.sparql_generation_signature = sparql_generation_signature or self.DEFAULT_SPARQL_GENERATION_SIGNATURE
        self.answer_generation_signature = answer_generation_signature or self.DEFAULT_ANSWER_GENERATION_SIGNATURE
        self.answer_from_subgraph_signature = answer_from_subgraph_signature or self.DEFAULT_ANSWER_FROM_SUBGRAPH_SIGNATURE

        # DSpy instruction strings
        self.entity_extraction_instruction = entity_extraction_instruction or self.DEFAULT_ENTITY_EXTRACTION_INSTRUCTION
        self.template_creation_instruction = template_creation_instruction or self.DEFAULT_TEMPLATE_CREATION_INSTRUCTION
        self.schema_aware_template_creation_instruction = schema_aware_template_creation_instruction or self.DEFAULT_SCHEMA_AWARE_TEMPLATE_CREATION_INSTRUCTION
        self.sparql_generation_instruction = sparql_generation_instruction or self.DEFAULT_SPARQL_GENERATION_INSTRUCTION
        self.answer_generation_instruction = answer_generation_instruction or self.DEFAULT_ANSWER_GENERATION_INSTRUCTION
        self.answer_from_subgraph_instruction = answer_from_subgraph_instruction or self.DEFAULT_ANSWER_FROM_SUBGRAPH_INSTRUCTION

        # Lazy initialization of wrappers
        self._entity_wrapper = None
        self._relation_wrapper = None

    @classmethod
    def default(cls) -> "KGConfig":
        """Create a KGConfig instance with all default settings.

        Returns:
            KGConfig instance initialized with environment variables or built-in defaults.
        """
        return cls()

    @property
    def entity_descriptor_function(self) -> Optional[EntityDescriptorFunction]:
        """Get the user-provided entity descriptor function, or None for default."""
        return self._entity_descriptor

    @property
    def relation_descriptor_function(self) -> Optional[RelationDescriptorFunction]:
        """Get the user-provided relation descriptor function, or None for default."""
        return self._relation_descriptor

    def describe_entity(self, entity_uri: str) -> str:
        """Create description for a single entity using configured descriptor.

        Args:
            entity_uri: URI of the entity (with or without angle brackets).

        Returns:
            Natural language description of the entity.
        """
        # Lazy initialization of wrapper
        if self._entity_wrapper is None:
            from kgnode._entity_descriptor import EntityDescriptorWrapper
            self._entity_wrapper = EntityDescriptorWrapper(
                descriptor_function=self._entity_descriptor,
                config=self
            )
        return self._entity_wrapper.describe_single(entity_uri)

    def describe_entities_batch(self, entity_uris: List[str]) -> Dict[str, str]:
        """Create descriptions for multiple entities in batch (optimized).

        Args:
            entity_uris: List of entity URIs (with or without angle brackets).

        Returns:
            Dictionary mapping original URIs to their descriptions.
        """
        # Lazy initialization of wrapper
        if self._entity_wrapper is None:
            from kgnode._entity_descriptor import EntityDescriptorWrapper
            self._entity_wrapper = EntityDescriptorWrapper(
                descriptor_function=self._entity_descriptor,
                config=self
            )
        return self._entity_wrapper.describe_batch(entity_uris)

    def describe_relation(self, relation_uri: str) -> str:
        """Create description for a relation using configured descriptor.

        Args:
            relation_uri: URI of the relation/predicate.

        Returns:
            Human-readable description of the relation.
        """
        # Lazy initialization
        if self._relation_wrapper is None:
            from kgnode._entity_descriptor import _default_relation_descriptor_logic
            self._relation_wrapper = self._relation_descriptor or _default_relation_descriptor_logic
        return self._relation_wrapper(relation_uri)