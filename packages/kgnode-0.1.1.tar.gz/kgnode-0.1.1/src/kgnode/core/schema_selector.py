"""Query-aware schema selection using semantic search.

This module provides internal functionality to select relevant entity types and relation types
for a given query using semantic similarity search in ChromaDB.

All functions are private (internal use only).
"""

from typing import Dict, List, Optional

from kgnode.core.kg_config import KGConfig
from kgnode.core.schema_chromadb import _load_schema_collections


def _select_relevant_schema(
    query: str,
    config: Optional[KGConfig] = None,
    top_k_entities: int = 20,
    top_k_relations: int = 30,
) -> Dict[str, List[str]]:
    """Select relevant entity types and relation types for a query.

    Uses semantic search in schema ChromaDB collections to find types most relevant
    to the query.

    Args:
        query: Natural language query (e.g., "Show papers by John Smith")
        config: KGConfig instance
        top_k_entities: Number of entity types to select
        top_k_relations: Number of relation types to select

    Returns:
        Dict with 'entity_types' and 'relation_types' keys
        Example: {'entity_types': ['Person', 'Publication'], 'relation_types': ['authoredBy']}
    """
    if config is None:
        config = KGConfig()

    # Load schema collections
    entities_collection, relations_collection = _load_schema_collections(config)

    # Search for relevant entity types (skip if top_k_entities is 0)
    entity_types = []
    if top_k_entities > 0:
        entity_results = entities_collection.query(query_texts=[query], n_results=top_k_entities)
        if entity_results["documents"] and entity_results["documents"][0]:
            entity_types = entity_results["documents"][0]

    # Search for relevant relation types (skip if top_k_relations is 0)
    relation_types = []
    if top_k_relations > 0:
        relation_results = relations_collection.query(
            query_texts=[query], n_results=top_k_relations
        )
        if relation_results["documents"] and relation_results["documents"][0]:
            relation_types = relation_results["documents"][0]

    return {"entity_types": entity_types, "relation_types": relation_types}


def _format_schema_for_prompt(
    selected_schema: Dict[str, List[str]], include_examples: bool = False
) -> str:
    """Format selected schema for inclusion in LLM prompt.

    Args:
        selected_schema: Dict with 'entity_types' and 'relation_types' keys
        include_examples: If True, include brief examples (not implemented yet - simple list for now)

    Returns:
        Formatted schema string for prompt

    Example output:
        "Relations (use these EXACT names): wikidata, authoredBy, publishedIn
        Entity Types: Person, Publication, Venue"
    """
    entity_types = selected_schema.get("entity_types", [])
    relation_types = selected_schema.get("relation_types", [])

    lines = []

    # Put relations FIRST and emphasize they should be used EXACTLY
    if relation_types:
        relation_str = ", ".join(relation_types)
        lines.append(f"Relations (use these EXACT names): {relation_str}")

    if entity_types:
        entity_str = ", ".join(entity_types)
        lines.append(f"Entity Types: {entity_str}")

    return "\n".join(lines)


if __name__ == "__main__":
    """Example usage of query-aware schema selection."""
    from kgnode.core.kg_config import KGConfig

    print("=" * 60)
    print("EXAMPLE: Query-aware schema selection")
    print("=" * 60)

    config = KGConfig()

    # Example queries
    queries = [
        "Show papers by John Smith published in ICML",
        "What is the Wikidata ID of Robert Schober?",
        "Find authors affiliated with MIT",
    ]

    for query in queries:
        print(f"\nQuery: {query}")
        print("-" * 60)

        # Select relevant schema
        relevant_schema = _select_relevant_schema(
            query=query, config=config, top_k_entities=5, top_k_relations=5
        )

        # Format for prompt
        schema_context = _format_schema_for_prompt(relevant_schema, include_examples=False)

        print("Relevant schema:")
        print(schema_context)

    print("\n" + "=" * 60)
    print("✓ Schema selection examples complete!")
