"""ChromaDB compilation for knowledge graph schema.

This module provides internal functionality to compile schema (entity types and relation types)
into ChromaDB collections for semantic search during template creation.

All functions are private (internal use only).
"""

from typing import Optional, Tuple

import chromadb

from kgnode.core.kg_config import KGConfig
from kgnode.core.schema_extractor import _get_schema


# Collection names
_SCHEMA_ENTITIES_COLLECTION = "kg_schema_entities"
_SCHEMA_RELATIONS_COLLECTION = "kg_schema_relations"


def _compile_schema_collections(
    config: Optional[KGConfig] = None,
    ontology_path: Optional[str] = None,
    force_recreate: bool = False,
) -> Tuple[chromadb.Collection, chromadb.Collection]:
    """Compile schema into ChromaDB collections.

    Creates two ChromaDB collections:
    - kg_schema_entities: Entity type labels
    - kg_schema_relations: Relation type labels

    Args:
        config: KGConfig instance with SPARQL endpoint and embedding model
        ontology_path: Optional path to ontology file (.nt format)
        force_recreate: If True, delete existing collections and recreate

    Returns:
        Tuple of (entities_collection, relations_collection)
    """
    if config is None:
        config = KGConfig()

    # Extract schema
    schema = _get_schema(config=config, ontology_path=ontology_path)

    entity_types = schema["entity_types"]
    relation_types = schema["relation_types"]

    if not entity_types and not relation_types:
        raise ValueError("No entity types or relation types found in schema")

    # Initialize ChromaDB client
    persist_directory = config.chroma_persist_dir
    print(f"Initializing ChromaDB at {persist_directory}...")
    client = chromadb.PersistentClient(path=persist_directory)

    # Delete existing collections if force_recreate
    if force_recreate:
        try:
            client.delete_collection(name=_SCHEMA_ENTITIES_COLLECTION)
            print(f"Deleted existing collection '{_SCHEMA_ENTITIES_COLLECTION}'")
        except Exception:
            pass

        try:
            client.delete_collection(name=_SCHEMA_RELATIONS_COLLECTION)
            print(f"Deleted existing collection '{_SCHEMA_RELATIONS_COLLECTION}'")
        except Exception:
            pass

    # Create embedding function
    embedding_function = chromadb.utils.embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name=config.embedding_model
    )

    # Create/get entity types collection
    print(f"Creating collection '{_SCHEMA_ENTITIES_COLLECTION}'...")
    entities_collection = client.get_or_create_collection(
        name=_SCHEMA_ENTITIES_COLLECTION,
        metadata={
            "hnsw:space": "cosine",
            "description": "Entity types from knowledge graph schema",
        },
        embedding_function=embedding_function,
    )

    # Create/get relation types collection
    print(f"Creating collection '{_SCHEMA_RELATIONS_COLLECTION}'...")
    relations_collection = client.get_or_create_collection(
        name=_SCHEMA_RELATIONS_COLLECTION,
        metadata={
            "hnsw:space": "cosine",
            "description": "Relation types from knowledge graph schema",
        },
        embedding_function=embedding_function,
    )

    # Check if collections already have data
    entities_count = entities_collection.count()
    relations_count = relations_collection.count()

    if entities_count > 0 and relations_count > 0 and not force_recreate:
        print(
            f"Schema collections already populated (entities: {entities_count}, "
            f"relations: {relations_count})"
        )
        print("Use force_recreate=True to rebuild")
        return entities_collection, relations_collection

    # Populate entity types collection
    if entity_types:
        print(f"\nInserting {len(entity_types)} entity types...")
        entities_collection.add(
            ids=[f"entity_type_{i}" for i in range(len(entity_types))],
            documents=entity_types,
            metadatas=[{"type_label": et} for et in entity_types],
        )
        print(f"✓ Inserted {len(entity_types)} entity types")

    # Populate relation types collection
    if relation_types:
        print(f"\nInserting {len(relation_types)} relation types...")
        relations_collection.add(
            ids=[f"relation_type_{i}" for i in range(len(relation_types))],
            documents=relation_types,
            metadatas=[{"type_label": rt} for rt in relation_types],
        )
        print(f"✓ Inserted {len(relation_types)} relation types")

    print(f"\n✓ Schema collections compiled successfully!")
    print(f"✓ Entity types collection: {entities_collection.count()} types")
    print(f"✓ Relation types collection: {relations_collection.count()} types")
    print(f"✓ Persisted at: {persist_directory}")

    return entities_collection, relations_collection


def _load_schema_collections(
    config: Optional[KGConfig] = None,
) -> Tuple[chromadb.Collection, chromadb.Collection]:
    """Load existing schema collections from ChromaDB.

    Args:
        config: KGConfig instance with embedding model configuration

    Returns:
        Tuple of (entities_collection, relations_collection)

    Raises:
        ValueError: If collections don't exist
    """
    if config is None:
        config = KGConfig()

    persist_directory = config.chroma_persist_dir
    client = chromadb.PersistentClient(path=persist_directory)

    # Create embedding function
    embedding_function = chromadb.utils.embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name=config.embedding_model
    )

    try:
        entities_collection = client.get_collection(
            name=_SCHEMA_ENTITIES_COLLECTION, embedding_function=embedding_function
        )
        relations_collection = client.get_collection(
            name=_SCHEMA_RELATIONS_COLLECTION, embedding_function=embedding_function
        )
        return entities_collection, relations_collection
    except Exception as e:
        raise ValueError(
            f"Schema collections not found. Please compile them first using "
            f"_compile_schema_collections(). Error: {e}"
        )


if __name__ == "__main__":
    """Example usage of schema ChromaDB compilation."""
    from kgnode.core.kg_config import KGConfig

    print("=" * 60)
    print("EXAMPLE: Compile schema into ChromaDB")
    print("=" * 60)

    config = KGConfig()

    # Compile schema collections (from SPARQL)
    print("\nCompiling schema collections from SPARQL endpoint...")
    entities_col, relations_col = _compile_schema_collections(
        config=config, ontology_path="../../../_data/schema.nt", force_recreate=True
    )

    print("\n" + "=" * 60)
    print("EXAMPLE: Load existing schema collections")
    print("=" * 60)

    # Load existing collections
    print("\nLoading existing schema collections...")
    entities_col, relations_col = _load_schema_collections(config=config)
    print(f"✓ Loaded entities collection with {entities_col.count()} types")
    print(f"✓ Loaded relations collection with {relations_col.count()} types")

    print("\n" + "=" * 60)
    print("EXAMPLE: With ontology file")
    print("=" * 60)
    print("\nTo compile from ontology file:")
    print("  entities_col, relations_col = _compile_schema_collections(")
    print("      config=config,")
    print("      ontology_path='_data/ontology.nt',")
    print("      force_recreate=True")
    print("  )")

    print("\n✓ Schema ChromaDB examples complete!")
