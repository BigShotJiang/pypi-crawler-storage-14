from kgnode.core.sparql_query import execute_sparql_query

__all__ = ["execute_sparql_query"]