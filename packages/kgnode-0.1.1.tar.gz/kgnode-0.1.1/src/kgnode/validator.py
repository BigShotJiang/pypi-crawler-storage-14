"""Subgraph validation utilities for knowledge graph node extraction.

This module provides validation functions to check if extracted subgraphs
contain the correct answer paths by comparing against ground truth SPARQL queries.
"""

import os
from typing import Dict, Any, Callable, Optional
from dotenv import load_dotenv
from kgnode.core.kg_config import KGConfig
from kgnode.core.sparql_query import execute_sparql_query


def validate_subgraph(subgraph: Dict[str, Any],
                      answer_sparql: str,
                      config: Optional[KGConfig] = None,) -> bool:
    """
    Returns True if subgraph contains answer path.

    Args:
        subgraph: Dictionary with 'triplet_uris' and 'path_with_label' keys
        answer_sparql: SPARQL query that retrieves the correct answer
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.
        kg_connection: Optional SPARQL query function. If None, creates from config.

    Returns:
        True if the subgraph's path leads to the correct answer, False otherwise

    Example:
        answer_sparql = "SELECT DISTINCT ?answer WHERE {
            <https://dblp.org/pid/95/2265> <https://dblp.org/rdf/schema#wikidata> ?answer
        }"
        If subgraph contains this edge, returns True
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Execute the answer SPARQL query to get ground truth answer(s)
    results = execute_sparql_query(answer_sparql, config=config)

    if not results:
        return False

    # Extract answer URIs from SPARQL results
    answer_uris = set()
    for result in results:
        # The answer variable is typically named '?answer' in the query
        if 'answer' in result:
            answer_uris.add(result['answer'])

    if not answer_uris:
        return False

    # Check if any node in the subgraph path matches an answer URI
    for uri, label, is_node in subgraph['path_with_label']:
        if is_node and uri in answer_uris:
            return True

    return False


if __name__ == '__main__':
    """
    Example usage demonstrating subgraph validation.

    This example validates subgraphs extracted for the question:
    "Show the Wikidata ID of the person Robert Schober."

    It checks if the extracted subgraphs contain the correct answer path
    leading to Robert Schober's Wikidata ID.
    """
    from kgnode.subgraph_extraction import get_subgraphs
    from kgnode.core.kg_config import KGConfig

    # Define the test case
    seed_node = 'https://dblp.org/pid/95/2265'
    query = "Show the Wikidata ID of the person Robert Schober."
    answer_sparql = """
    SELECT DISTINCT ?answer WHERE {
        <https://dblp.org/pid/95/2265> <https://dblp.org/rdf/schema#wikidata> ?answer
    }
    """

    print("=" * 80)
    print("SUBGRAPH VALIDATION EXAMPLE")
    print("=" * 80)
    print(f"\nQuestion: {query}")
    print(f"Seed Node: {seed_node}")
    print(f"\nExtracting subgraphs...")

    # Extract subgraphs using the path-aware Markov chain algorithm (uses default config)
    subgraphs = get_subgraphs(
        seed_node=seed_node,
        query=query,
        max_hops=3,
        max_k=2
    )

    print(f"Total subgraphs found: {len(subgraphs)}")
    print("\n" + "=" * 80)
    print("VALIDATION RESULTS")
    print("=" * 80)

    # Validate each subgraph (uses default config)
    valid_count = 0
    for i, subgraph in enumerate(subgraphs):
        is_valid = validate_subgraph(subgraph, answer_sparql)
        if is_valid:
            valid_count += 1
            print(f"\n Subgraph {i + 1} is VALID!")
            print(f"  Number of edges: {len(subgraph['triplet_uris'])}")
            print(f"  Edges: {subgraph['triplet_uris']}")
            print(f"  Path:")
            for uri, label, is_node in subgraph['path_with_label']:
                if is_node:
                    print(f"    Node: {label}")
                    print(f"          ({uri})")
                else:
                    print(f"    --> Relation: {label}")
            print("-" * 80)
        else:
            print(f"\n Subgraph {i + 1} is INVALID (does not contain answer)")

    # Print summary
    print("\n" + "=" * 80)
    print("SUMMARY")
    print("=" * 80)
    print(f"Valid subgraphs: {valid_count}/{len(subgraphs)}")
    print(f"Accuracy: {(valid_count / len(subgraphs) * 100):.2f}%")
    print("=" * 80)