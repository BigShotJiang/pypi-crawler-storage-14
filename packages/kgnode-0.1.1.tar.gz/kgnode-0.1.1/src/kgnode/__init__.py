"""kgnode - Knowledge Graph Agnostic Node for Knowledge-Aware LLM Applications.

Public API for knowledge graph retrieval and answer generation.
"""

# Main Pipeline APIs
# VectorDB Operations
from kgnode.chroma_db import (
    add_or_update_entities,
    compile_chromadb,
    compile_chromadb_from_csv,
    delete_entities,
    get_or_create_chromadb,
    semantic_search_entities,
)

# Core Configuration
from kgnode.core.kg_config import KGConfig
from kgnode.core.sparql_query import execute_sparql_query
from kgnode.generator import (
    generate_answer,
    generate_answer_using_subgraph,
    generate_sparql,
    kg_retrieve,
)

# Search Operations
from kgnode.keyword_search import search_entities_by_keywords
from kgnode.seed_finder import SearchMode, citable, get_seed_nodes
from kgnode.subgraph_extraction import get_subgraphs

# Validation
from kgnode.validator import validate_subgraph

__all__ = [
    # Main Pipeline APIs
    "citable",
    "get_seed_nodes",
    "SearchMode",
    "get_subgraphs",
    "generate_sparql",
    "kg_retrieve",
    "generate_answer",
    "generate_answer_using_subgraph",
    # Validation
    "validate_subgraph",
    # Search Operations
    "search_entities_by_keywords",
    # VectorDB Operations
    "compile_chromadb",
    "compile_chromadb_from_csv",
    "semantic_search_entities",
    "get_or_create_chromadb",
    "add_or_update_entities",
    "delete_entities",
    # Core Configuration
    "KGConfig",
    "execute_sparql_query",
]