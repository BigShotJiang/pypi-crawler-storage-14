# Seed node: <https://dblp.org/pid/95/2265>
# Question: Show the Wikidata ID of the person Robert Schober.
# Subgraph: ??
# Sparql: SELECT DISTINCT ?answer WHERE { <https://dblp.org/pid/95/2265> <https://dblp.org/rdf/schema#wikidata> ?answer }
# Answer: https://www.wikidata.org/entity/Q55238282
import os
import dspy
from dotenv import load_dotenv
from typing import List, Tuple, Dict, Any, Callable, LiteralString, Optional, Set
import numpy as np
from kgnode.core.kg_config import KGConfig


def _get_allowed_relations(config: KGConfig) -> Set[str]:
    """Get set of allowed relation URIs from schema.

    This function extracts relation types from the knowledge graph schema and
    returns their full URIs. It's used to filter neighbors to only data-level
    relations (excluding ontology meta-relations like rdf:type).

    Args:
        config: KGConfig instance with schema configuration

    Returns:
        Set of allowed relation URIs (e.g., {'https://dblp.org/rdf/schema#wikidata', ...})
        Empty set means allow all relations (no filtering)

    Raises:
        Exception: If schema extraction fails and fallback_to_all_relations is False
    """
    if not config.enable_schema_based_filtering:
        return set()  # Empty = allow all

    try:
        from kgnode.core.schema_extractor import _get_schema

        # Get schema - now includes full URIs directly
        schema = _get_schema(config=config, ontology_path=config.ontology_path)

        # Use relation URIs directly (much faster than querying again!)
        relation_uris = schema.get('relation_uris', [])

        if not relation_uris:
            print("Warning: No relation URIs found in schema")
            if config.fallback_to_all_relations:
                return set()
            else:
                raise ValueError("No relation URIs found in schema")

        allowed_relations = set(relation_uris)
        print(f"✓ Schema-based filtering enabled: {len(allowed_relations)} relations allowed")
        return allowed_relations

    except Exception as e:
        print(f"Warning: Schema-based filtering failed: {e}")
        if config.fallback_to_all_relations:
            print("Falling back to allowing all relations")
            return set()  # Allow all
        else:
            raise


def get_neighbor_nodes(node_id: str, sparql_query: Callable, allowed_relations: Optional[Set[str]] = None) -> List[Tuple[str, str, str]]:
    """
    Get all outgoing neighbors of a node in the knowledge graph.

    Args:
        node_id: URI of the node (e.g., 'https://dblp.org/pid/95/2265')
        sparql_query: sparql_query method for querying the SPARQL endpoint.
        allowed_relations: Optional set of allowed relation URIs. If provided and non-empty,
            only neighbors connected via these relations will be returned.
            If None or empty, all relations are allowed.

    Returns:
        List of tuples: (relation, neighbor_node_id, neighbor_label)
        - relation: predicate URI connecting node_id to neighbor
        - neighbor_node_id: URI of the neighbor node
        - neighbor_label: rdfs:label of neighbor node (empty string if not available)
    """

    # Build VALUES clause for relation filtering
    if allowed_relations:
        values_list = " ".join([f"<{r}>" for r in allowed_relations])
        filter_clause = f"VALUES ?relation {{ {values_list} }}"
    else:
        filter_clause = ""

    query = f"""
    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

    SELECT DISTINCT ?relation ?neighbor ?label
    WHERE {{
      {filter_clause}
      <{node_id}> ?relation ?neighbor .

      # Only include neighbors that are URIs (not literals)
      FILTER(isURI(?neighbor))

      # Optionally get the label of the neighbor
      OPTIONAL {{
        ?neighbor rdfs:label ?label .
      }}
    }}
    """

    results = sparql_query(query)

    # Convert results to list of tuples
    neighbors = []
    for result in results:
        relation = result['relation']
        neighbor_node_id = result['neighbor']
        neighbor_label = result.get('label', '')  # Empty string if label not found

        neighbors.append((relation, neighbor_node_id, neighbor_label))

    return neighbors


def get_node_label(node_id: str, sparql_query: Callable, label_cache: Dict[str, str]) -> str:
    """
    Get the rdfs:label of a node from the knowledge graph.

    Args:
        node_id: URI of the node (e.g., 'https://dblp.org/pid/95/2265')
        sparql_query: sparql_query method for querying the SPARQL endpoint
        label_cache: Dictionary to cache node labels for performance

    Returns:
        The label of the node, or the last part of the URI if no label exists
    """
    # Check cache first
    if node_id in label_cache:
        return label_cache[node_id]

    query = f"""
    PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

    SELECT ?label
    WHERE {{
      <{node_id}> rdfs:label ?label .
    }}
    LIMIT 1
    """

    results = sparql_query(query)

    if results and len(results) > 0:
        label = results[0].get('label', '')
        label_cache[node_id] = label
        return label
    else:
        # Fallback: extract last part of URI
        fallback_label = node_id.split('/')[-1].split('#')[-1]
        label_cache[node_id] = fallback_label
        return fallback_label


def extract_relation_name(relation_uri: str) -> str:
    """
    Extract human-readable name from relation URI.

    Args:
        relation_uri: Full URI of the relation (e.g., 'https://dblp.org/rdf/schema#wikidata')

    Returns:
        Human-readable relation name (e.g., 'wikidata')

    Examples:
        'https://dblp.org/rdf/schema#wikidata' -> 'wikidata'
        'http://xmlns.com/foaf/0.1/name' -> 'name'
        'https://dblp.org/rdf/schema#authoredBy' -> 'authoredBy'
    """
    # Split by '#' first (common in RDF URIs)
    if '#' in relation_uri:
        return relation_uri.split('#')[-1]

    # Otherwise split by '/' and take the last part
    if '/' in relation_uri:
        return relation_uri.split('/')[-1]

    # If no separators, return as-is
    return relation_uri


def create_template(query: str, config: KGConfig, embedding_model) -> tuple[Any, Any]:
    """
    Creates template embedding from query using DSpy rephrasing.

    If schema-aware templates are enabled, includes relevant entity types and relation types
    from the knowledge graph schema to improve template quality.

    Args:
        query: The original question (e.g., "Show the Wikidata ID of the person Robert Schober.")
        config: KGConfig instance with DSpy signature configuration
        embedding_model: Sentence transformer model for creating embeddings

    Returns:
        Tuple of (template_embedding, template_text)

    Example (without schema):
        query = "Show the Wikidata ID of the person Robert Schober."
        -> Rephrased to: "Robert Schober wikidata ID"
        -> Returns: (embedding vector, "Robert Schober wikidata ID")

    Example (with schema-aware templates):
        query = "Show papers by John Smith published in ICML"
        -> Uses relevant schema: Entity Types: Person, Publication, Venue; Relations: authoredBy, publishedIn
        -> Rephrased to: "John Smith authoredBy publications publishedIn ICML"
        -> Returns: (embedding vector, "John Smith authoredBy publications publishedIn ICML")
    """
    # Check if schema-aware templates are enabled
    if config.use_schema_aware_templates:
        # Ensure schema collections exist (compile if needed on first use)
        try:
            from kgnode.core.schema_chromadb import _compile_schema_collections, _load_schema_collections

            # Try to load existing collections first
            try:
                _load_schema_collections(config)
            except ValueError:
                # Collections don't exist - compile them (one-time operation)
                _compile_schema_collections(
                    config=config,
                    ontology_path=config.ontology_path,
                    force_recreate=config.force_schema_refresh
                )

            # Select relevant schema for this query
            from kgnode.core.schema_selector import _select_relevant_schema, _format_schema_for_prompt

            relevant_schema = _select_relevant_schema(
                query=query,
                config=config,
                top_k_entities=config.schema_top_k_entities,
                top_k_relations=config.schema_top_k_relations
            )

            schema_context = _format_schema_for_prompt(
                relevant_schema,
                include_examples=config.schema_include_examples
            )

            # Use schema-aware signature and instruction
            signature_with_instructions = config.schema_aware_template_creation_signature.with_instructions(
                config.schema_aware_template_creation_instruction
            )

            if config.chain_of_thought:
                template_creator = dspy.ChainOfThought(signature_with_instructions)
            else:
                template_creator = dspy.Predict(signature_with_instructions)

            # Call DSpy with query and schema context
            result = template_creator(query=query, schema_context=schema_context)

        except Exception as e:
            # If schema-aware processing fails, fall back to standard template creation
            print(f"Warning: Schema-aware template creation failed: {e}")
            print("Falling back to standard template creation...")

            signature_with_instructions = config.template_creation_signature.with_instructions(
                config.template_creation_instruction
            )

            if config.chain_of_thought:
                template_creator = dspy.ChainOfThought(signature_with_instructions)
            else:
                template_creator = dspy.Predict(signature_with_instructions)

            result = template_creator(query=query)
    else:
        # Standard template creation (original behavior)
        signature_with_instructions = config.template_creation_signature.with_instructions(
            config.template_creation_instruction
        )

        if config.chain_of_thought:
            template_creator = dspy.ChainOfThought(signature_with_instructions)
        else:
            template_creator = dspy.Predict(signature_with_instructions)

        result = template_creator(query=query)

    template_text = result.path_pattern.strip()

    # Create embedding
    template_embedding = embedding_model.encode(template_text, convert_to_numpy=True)

    return template_embedding, template_text


def compute_path_embedding(path_nodes: List[str], path_relations: List[str],
                           embedding_model, label_cache: Dict[str, str],
                           sparql_query: Callable) -> tuple[Any, str | LiteralString]:
    """
    Returns embedding vector for current path.

    Args:
        path_nodes: List of node URIs in the path (e.g., [a, b, v, w])
        path_relations: List of relation URIs connecting nodes (e.g., [r1, r2, r3])
        embedding_model: Sentence transformer model for creating embeddings
        label_cache: Dictionary to cache node labels for performance
        sparql_query: sparql_query method for querying the SPARQL endpoint

    Returns:
        Path embedding as numpy array

    Example:
        path_nodes = ['https://dblp.org/pid/95/2265', 'https://www.wikidata.org/entity/Q55238282']
        path_relations = ['https://dblp.org/rdf/schema#wikidata']
        -> Creates text: "Robert Schober wikidata Q55238282"
        -> Returns: embedding vector
    """
    # Handle empty path (just seed node)
    if len(path_nodes) == 1 and len(path_relations) == 0:
        node_label = get_node_label(path_nodes[0], sparql_query, label_cache)
        path_text = node_label
    else:
        # Build path text: "label_a relation1 label_b relation2 label_c ..."
        path_parts = []

        for i, node in enumerate(path_nodes):
            # Get node label
            node_label = get_node_label(node, sparql_query, label_cache)
            path_parts.append(node_label)

            # Add relation if not the last node
            if i < len(path_relations):
                relation_name = extract_relation_name(path_relations[i])
                path_parts.append(relation_name)

        # Join all parts with spaces
        path_text = " ".join(path_parts)

    # Create embedding
    path_embedding = embedding_model.encode(path_text, convert_to_numpy=True)

    return path_embedding, path_text


def compute_transition_probability(path_embedding: np.ndarray,
                                   template_embedding: np.ndarray) -> float:
    """
    Returns probability score using cosine similarity and softmax.

    Args:
        path_embedding: Embedding vector of the current path
        template_embedding: Embedding vector of the query template

    Returns:
        Probability score (between 0 and 1)

    Note:
        Uses cosine similarity followed by softmax normalization.
        Since we're computing probability for a single transition,
        we use exponential of cosine similarity as the probability.
    """
    # Compute cosine similarity
    # cosine_sim = (A · B) / (||A|| × ||B||)
    dot_product = np.dot(path_embedding, template_embedding)
    norm_path = np.linalg.norm(path_embedding)
    norm_template = np.linalg.norm(template_embedding)

    cosine_sim = dot_product / (norm_path * norm_template)

    # Apply exponential (softmax-like transformation)
    # This gives us a probability-like score
    probability = np.exp(cosine_sim)

    return float(probability)


def select_next_nodes(current_node: str, path_history: List[str],
                      relation_history: List[str], template_embedding: np.ndarray,
                      previous_max_prob: float, embedding_model, kg_connection,
                      label_cache: Dict[str, str], max_k: int = 2,
                      allowed_relations: Optional[Set[str]] = None) -> List[Tuple[str, str, float]]:
    """
    Returns top max_k (neighbor_node_id, relation, probability) tuples.

    Args:
        current_node: URI of the current node to expand
        path_history: List of node URIs visited so far (not including current_node)
        relation_history: List of relation URIs used so far
        template_embedding: Embedding vector of the query template
        previous_max_prob: Maximum probability from the previous hop
        embedding_model: Sentence transformer model for creating embeddings
        kg_connection: SPARQL query function
        label_cache: Dictionary to cache node labels
        max_k: Maximum number of neighbors to select (default: 2)
        allowed_relations: Optional set of allowed relation URIs for filtering

    Returns:
        List of tuples: [(neighbor_node_id, relation, probability), ...]
        Sorted by probability in descending order, containing at most max_k entries.
        Only includes neighbors where probability > previous_max_prob.
    """
    # Get all neighbors of current node
    neighbors = get_neighbor_nodes(current_node, kg_connection, allowed_relations)

    if not neighbors:
        return []

    # Store neighbor labels in cache for later use
    for relation, neighbor_id, neighbor_label in neighbors:
        if neighbor_label and neighbor_id not in label_cache:
            label_cache[neighbor_id] = neighbor_label

    # Prepare data for batch embedding
    candidate_paths = []
    candidate_info = []  # Store (neighbor_id, relation) for each candidate

    for relation, neighbor_id, neighbor_label in neighbors:
        # Build new path: path_history + [current_node] + [neighbor_id]
        new_path_nodes = path_history + [current_node, neighbor_id]
        new_path_relations = relation_history + [relation]

        candidate_paths.append((new_path_nodes, new_path_relations))
        candidate_info.append((neighbor_id, relation))

    # Batch compute path embeddings
    path_embeddings = []
    for path_nodes, path_relations in candidate_paths:
        path_emb, path_text = compute_path_embedding(path_nodes, path_relations, embedding_model,
                                          label_cache, kg_connection)
        path_embeddings.append((path_emb, path_text))

    # Compute probabilities for all candidates
    probabilities = []
    for path_emb, path_text in path_embeddings:
        prob = compute_transition_probability(path_emb, template_embedding)
        print(f"........... path_text: {path_text} --> prob: {prob}")
        probabilities.append(prob)

    # Filter candidates where probability > previous_max_prob
    valid_candidates = []
    for (neighbor_id, relation), prob in zip(candidate_info, probabilities):
        if prob > previous_max_prob:
            valid_candidates.append((neighbor_id, relation, prob))

    # Sort by probability (descending) and take top max_k
    valid_candidates.sort(key=lambda x: x[2], reverse=True)

    return valid_candidates[:max_k]


def get_subgraphs(seed_node: str, query: str,
                  config: Optional[KGConfig] = None,
                  kg_connection=None,
                  max_hops: int = 10, max_k: int = 2) -> List[Dict[str, Any]]:
    """
    Returns list of subgraphs, each as dict with 'nodes', 'edges', 'path' keys.

    Args:
        seed_node: URI of the starting node
        query: The original query/question
        config: Optional KGConfig instance for configuration.
            If None, uses default KGConfig with environment variables or built-in defaults.
        kg_connection: Optional SPARQL query function. If None, creates from config.
        max_hops: Maximum number of hops to explore (default: 10)
        max_k: Maximum number of neighbors to select per node (default: 2)

    Returns:
        List of subgraphs, each as:
        {
            'nodes': [node_uri1, node_uri2, ...],
            'edges': [(node_uri1, relation_uri, node_uri2), ...],
            'path': [(node_uri, node_label), (relation_name, None), ...]
        }
    """
    # Initialize config if not provided
    if config is None:
        config = KGConfig.default()

    # Initialize embedding model from config
    from sentence_transformers import SentenceTransformer
    embedding_model = SentenceTransformer(config.embedding_model)

    # Initialize DSpy LM
    import os
    from dotenv import load_dotenv
    load_dotenv()
    api_key = config.lm_api_key
    if not api_key:
        raise ValueError("LM API key not found in config or environment")

    lm = dspy.LM(model=config.openai_model, api_key=api_key)
    dspy.configure(lm=lm)

    # Initialize kg_connection if not provided
    if kg_connection is None:
        from kgnode.core.sparql_query import execute_sparql_query
        kg_connection = lambda q: execute_sparql_query(q, config=config)

    # Initialize label cache for this query
    label_cache = {}

    # Initialize allowed relations for schema-based filtering (Phase 1)
    allowed_relations = _get_allowed_relations(config)

    # Create template embedding
    template_embedding, template_text = create_template(query, config, embedding_model)
    print(f"Template text: {template_text}")

    # Initialize BFS queue: (current_node, path_nodes, path_relations, previous_max_prob, hop_count)
    queue = [(seed_node, [], [], 0.0, 0)]

    # Store completed subgraphs
    subgraphs = []

    while queue:
        current_node, path_nodes, path_relations, previous_max_prob, current_hop = queue.pop(0)

        # Check stopping conditions
        if current_hop >= max_hops:
            # Store this path as a complete subgraph
            subgraph = _build_subgraph(path_nodes + [current_node], path_relations, label_cache, kg_connection)
            subgraphs.append(subgraph)
            continue

        # Select next nodes to explore
        selected_neighbors = select_next_nodes(
            current_node=current_node,
            path_history=path_nodes,
            relation_history=path_relations,
            template_embedding=template_embedding,
            previous_max_prob=previous_max_prob,
            embedding_model=embedding_model,
            kg_connection=kg_connection,
            label_cache=label_cache,
            max_k=max_k,
            allowed_relations=allowed_relations
        )

        # If no valid neighbors found (all probabilities <= previous_max_prob), store subgraph
        if not selected_neighbors:
            subgraph = _build_subgraph(path_nodes + [current_node], path_relations, label_cache, kg_connection)
            subgraphs.append(subgraph)
            continue

        # Find max probability among selected neighbors for next iteration
        current_max_prob = max(prob for _, _, prob in selected_neighbors)

        # Add selected neighbors to queue
        for neighbor_id, relation, prob in selected_neighbors:
            new_path_nodes = path_nodes + [current_node]
            new_path_relations = path_relations + [relation]

            queue.append((neighbor_id, new_path_nodes, new_path_relations, current_max_prob, current_hop + 1))

    return subgraphs


def _build_subgraph(path_nodes: List[str], path_relations: List[str],
                    label_cache: Dict[str, str], kg_connection: Callable) -> Dict[str, Any]:
    """
    Helper function to build subgraph dictionary from path.

    Args:
        path_nodes: List of node URIs in the path
        path_relations: List of relation URIs in the path
        label_cache: Dictionary containing cached node labels
        kg_connection: SPARQL query function

    Returns:
        Dictionary with 'edges' and 'path' keys
        - edges: [(source_uri, relation_uri, target_uri), ...]
        - path: [(uri, label, is_node), ...] where is_node is True for nodes, False for relations
    """
    # Build edges list: [(source, relation, target), ...]
    edges = []
    for i in range(len(path_relations)):
        source = path_nodes[i]
        relation = path_relations[i]
        target = path_nodes[i + 1]
        edges.append((source, relation, target))

    # Build path with (uri, label, is_node) format
    path = []
    for i, node in enumerate(path_nodes):
        node_label = get_node_label(node, kg_connection, label_cache)
        path.append((node, node_label, True))  # True = is_node

        # Add relation if not the last node
        if i < len(path_relations):
            relation_uri = path_relations[i]
            relation_name = extract_relation_name(relation_uri)
            path.append((relation_uri, relation_name, False))  # False = is_relation

    return {
        'triplet_uris': edges,
        'path_with_label': path
    }



if __name__ == '__main__':
    # neighbors = get_neighbor_nodes("https://dblp.org/pid/95/2265", _sparql_query)
    # print(neighbors)
    # print(get_node_label("https://dblp.org/pid/95/2265", _sparql_query, {}))
    # print(extract_relation_name("https://dblp.org/rdf/schema#wikidata"))


    # ---------------------------- template embedding --------------------------
    # from openai import OpenAI
    # from sentence_transformers import SentenceTransformer
    #
    # # Initialize models
    # openai_client = OpenAI(api_key="api_key")
    # embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    #
    # # Test create_template
    # query = "Show the Wikidata ID of the person Robert Schober."
    # template_emb, template_text = create_template(query, openai_client, embedding_model)
    # print(f"Template embedding shape: {template_emb.shape}")
    # print(f"Template text : {template_text}")
    #
    # # Test with multiple entities
    # query2 = "Did John Smith and Mary Johnson collaborate on any papers?"
    # template_emb2, template_text_2 = create_template(query2, openai_client, embedding_model)
    # print(f"\nTemplate embedding 2 shape: {template_emb2.shape}")
    # print(f"Template text 2: {template_text_2}")


    # --------------------------------- path embedding -----------------------------
    # from sentence_transformers import SentenceTransformer
    # from kgnode._sparql_query import _sparql_query
    #
    # # Initialize model
    # embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    # label_cache = {}
    #
    # # Test 1: Single node (seed node)
    # path_nodes = ['https://dblp.org/pid/95/2265']
    # path_relations = []
    # path_emb, path_text = compute_path_embedding(path_nodes, path_relations, embedding_model, label_cache, _sparql_query)
    # print(f"Single node embedding shape: {path_emb.shape}")
    # print(f"Cached label: {label_cache.get('https://dblp.org/pid/95/2265', 'Not found')}")
    # print(f"Path embedding text: {path_text}")
    #
    # # Test 2: Two nodes with one relation
    # path_nodes = ['https://dblp.org/pid/95/2265', 'https://www.wikidata.org/entity/Q55238282']
    # path_relations = ['https://dblp.org/rdf/schema#wikidata']
    # path_emb_2, path_text_2 = compute_path_embedding(path_nodes, path_relations, embedding_model, label_cache, _sparql_query)
    # print(f"\nTwo node path embedding shape: {path_emb_2.shape}")
    # print(f"Path embedding text: {path_text_2}")


    # --------------------------------- compute transitional probability -----------------------------
    # from sentence_transformers import SentenceTransformer
    # from openai import OpenAI
    # from kgnode._sparql_query import _sparql_query
    # import numpy as np
    #
    # # Initialize models
    # embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    # openai_client = OpenAI(api_key="api_key")
    # label_cache = {}
    #
    # # Create template embedding
    # query = "Show the Wikidata ID of the person Robert Schober."
    # template_emb, template_text = create_template(query, openai_client, embedding_model)
    #
    # # Create a path embedding
    # path_nodes = ['https://dblp.org/pid/95/2265', 'https://www.wikidata.org/entity/Q55238282']
    # path_relations = ['https://dblp.org/rdf/schema#wikidata']
    # path_emb, path_text = compute_path_embedding(path_nodes, path_relations, embedding_model, label_cache, _sparql_query)
    #
    # # Compute transition probability
    # prob = compute_transition_probability(path_emb, template_emb)
    # print(f"Transition probability: {prob}")
    # print(f"Probability type: {type(prob)}")
    #
    # # Test with a less relevant path (should have lower probability)
    # irrelevant_path_nodes = ['https://dblp.org/pid/95/2265']
    # irrelevant_path_relations = []
    # irrelevant_path_emb, irrelevant_path_text = compute_path_embedding(irrelevant_path_nodes, irrelevant_path_relations,
    #                                              embedding_model, label_cache, _sparql_query)
    # prob2 = compute_transition_probability(irrelevant_path_emb, template_emb)
    # print(f"\nIrrelevant path probability: {prob2}")
    # print(f"template_text: {template_text} \npath_text: {path_text} \nirrelevant_path_text: {irrelevant_path_text}")


    # --------------------------------- select next node -----------------------------
    # from sentence_transformers import SentenceTransformer
    # from openai import OpenAI
    # from kgnode._sparql_query import _sparql_query
    #
    # # Initialize models
    # embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    # openai_client = OpenAI(api_key="api_key")
    # label_cache = {}
    #
    # # Create template embedding
    # query = "Show the Wikidata ID of the person Robert Schober."
    # template_emb, template_text = create_template(query, openai_client, embedding_model)
    #
    # # Test select_next_nodes
    # seed_node = 'https://dblp.org/pid/95/2265'
    # path_history = []
    # relation_history = []
    # previous_max_prob = 0.0  # Starting probability
    #
    # selected_nodes = select_next_nodes(
    #     current_node=seed_node,
    #     path_history=path_history,
    #     relation_history=relation_history,
    #     template_embedding=template_emb,
    #     previous_max_prob=previous_max_prob,
    #     embedding_model=embedding_model,
    #     kg_connection=_sparql_query,
    #     label_cache=label_cache,
    #     max_k=2
    # )
    #
    # print(f"Number of selected neighbors: {len(selected_nodes)}")
    # for neighbor_id, relation, prob in selected_nodes:
    #     print(f"\nNeighbor: {neighbor_id}")
    #     print(f"Relation: {extract_relation_name(relation)}")
    #     print(f"Probability: {prob:.6f}")


    # --------------------------------- select next node -----------------------------------
    from sentence_transformers import SentenceTransformer
    from openai import OpenAI

    # Initialize models
    embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    openai_client = OpenAI(api_key="api_key")

    # Test extract_subgraphs_bfs
    seed_node = 'https://dblp.org/pid/95/2265'
    query = "Show the Wikidata ID of the person Robert Schober."

    subgraphs = get_subgraphs(
        seed_node=seed_node,
        query=query,
        max_hops=5,  # Keep it small for testing
        max_k=4
    )

    print(f"Number of subgraphs found: {len(subgraphs)}")
    print("\n" + "=" * 80)

    for i, subgraph in enumerate(subgraphs[:3]):  # Show first 3 subgraphs
        print(f"\nSubgraph {i + 1}:")
        print(f"Triplet count: {len(subgraph['triplet_uris'])}")
        print(f"Path with label count: {len(subgraph['path_with_label'])}")
        print(f"Triplet uris: {subgraph['triplet_uris']}")
        print(f"Path with labels: {subgraph['path_with_label']}")
        print(f"\n  Path:")
        for uri, label, is_node in subgraph['path_with_label']:
            if is_node:  # It's a node
                print(f"    Node: {label} ({uri})")
            else:  # It's a relation
                print(f"    relation --> {label} {uri} -->")
        print("\n" + "-" * 80)


    # --------------------------------- validate subgraph -----------------------------------
    # from kgnode.core.sparql_query import execute_sparql_query
    # from kgnode.validator import validate_subgraph
    # from kgnode.core.kg_config import KGConfig
    #
    # # Initialize config
    # load_dotenv()
    # config = KGConfig.default()
    #
    # # Test full pipeline
    # seed_node = 'https://dblp.org/pid/95/2265'
    # query = "Show the Wikidata ID of the person Robert Schober."
    # answer_sparql = """
    # SELECT DISTINCT ?answer WHERE {
    #     <https://dblp.org/pid/95/2265> <https://dblp.org/rdf/schema#wikidata> ?answer
    # }
    # """
    #
    # # Extract subgraphs
    # subgraphs = get_subgraphs(
    #     seed_node=seed_node,
    #     query=query,
    #     config=config,
    #     kg_connection=execute_sparql_query,
    #     max_hops=3,
    #     max_k=2
    # )
    #
    # print(subgraphs)
    # print(f"Total subgraphs found: {len(subgraphs)}")
    # print("\n" + "=" * 80)
    #
    # # Validate each subgraph
    # valid_count = 0
    # for i, subgraph in enumerate(subgraphs):
    #     is_valid = validate_subgraph(subgraph, answer_sparql, execute_sparql_query)
    #     if is_valid:
    #         valid_count += 1
    #         print(f"\n✓ Subgraph {i + 1} is VALID!")
    #         print(f"  Edges: {subgraph['triplet_uris']}")
    #         print(f"  Path:")
    #         for uri, label, is_node in subgraph['path_with_label']:
    #             if is_node:
    #                 print(f"    Node: {label} ({uri})")
    #             else:
    #                 print(f"    --> Relation: {label} ({uri})")
    #         print("-" * 80)
    #
    # print(f"\n\nSummary: {valid_count}/{len(subgraphs)} subgraphs contain the correct answer")

