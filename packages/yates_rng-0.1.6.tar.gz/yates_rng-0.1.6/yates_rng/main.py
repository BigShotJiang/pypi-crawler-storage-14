from yates_rng import domino_search,rin,domino_pick,domino_shuffle

print(rin([2,3,4],5))
print(domino_pick([1,2,3]))
print(domino_shuffle([2,3,4]))
print(domino_search([2,3,4],2))
