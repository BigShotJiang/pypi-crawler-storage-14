"""
西方占星系统（预留）

西方占星术系统的实现接口
待实现时取消注释并完善
"""

# from .astrology_system import AstrologySystem
# __all__ = ['AstrologySystem']


# 预留占位
class AstrologySystem:
    """占星系统占位类"""

    pass
