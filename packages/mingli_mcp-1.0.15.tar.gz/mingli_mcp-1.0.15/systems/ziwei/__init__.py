"""
紫微斗数系统
"""

from .ziwei_system import ZiweiSystem

__all__ = ["ZiweiSystem"]
