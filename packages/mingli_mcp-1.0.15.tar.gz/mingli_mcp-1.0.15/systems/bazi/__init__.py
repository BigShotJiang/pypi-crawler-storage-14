"""
八字系统

八字（四柱命理）系统的实现
基于lunar_python库实现四柱排盘和分析
"""

from .bazi_system import BaziSystem

__all__ = ["BaziSystem"]
