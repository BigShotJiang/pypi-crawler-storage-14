# itoutils

Bibliothèque d'utilitaire utilisée au sein des différents projets Python du GIP Plateforme de l'inclusion.


## Développement

Vous aurez besoin du petit utilitaire [`uv`](https://docs.astral.sh/uv/getting-started/installation/) sur votre système.

Pour la création du virtualenv :
```shell
uv venv
```

Pour les dépendances :
```shell
uv sync
```
