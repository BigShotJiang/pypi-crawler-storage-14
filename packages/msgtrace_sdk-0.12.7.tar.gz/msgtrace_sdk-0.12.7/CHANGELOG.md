# Changelog

All notable changes to msgtrace-sdk will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.12.7] - 2025-11-25

## [0.12.6] - 2025-11-25

## [0.12.5] - 2025-11-25

## [0.12.4] - 2025-11-25

## [0.12.3] - 2025-11-25

## [0.12.2] - 2025-11-24

### Removed
- **Performance benchmarks** - Removed benchmark workflow and tests
- Cleaned up AUTOMATION.md to remove benchmark references

### Changed
- Simplified automation workflow (now 8 workflows instead of 9)

## [0.12.1] - 2025-11-24

### Fixed
- Remove unused pytest import in test_benchmark.py (ruff lint error)

## [0.12.0] - 2025-11-24

### Removed
- **Auto-merge workflow** - Removed in favor of merge bot (more explicit control)
- **AUTO_MERGE_GUIDE.md** - No longer needed

### Changed
- Simplified to single merge strategy: command-based merge bot only
- Dependabot PRs no longer get automatic `automerge` label
- Updated AUTOMATION.md to reflect merge bot-only approach

## [0.11.0] - 2025-11-24

### Added
- **Merge Bot** - PyTorch-style merge bot with comment commands (`@mergebot merge`, `/merge`)
- **MERGE_BOT_GUIDE.md** - Comprehensive guide for using the merge bot
- Merge bot waits up to 10 minutes for CI checks to pass before merging
- Permission checking (only write/admin collaborators can merge)
- Automatic branch deletion after merge
- Interactive feedback with emoji reactions

## [0.10.0] - 2025-11-24

### Changed
- **Labeler** now recognizes both `[]` and `()` brackets in conventional commits
- **Labeler** now case-insensitive (FEAT, feat, FIX, fix all work)
- **Dependabot** PRs now automatically get `automerge` label
- **Changelog workflow** improved to handle dependencies and maintenance labels

### Added
- **AUTO_MERGE_GUIDE.md** comprehensive guide for using auto-merge workflow

### Fixed
- Dependabot commit message format (now uses CHORE prefix)

## [0.9.0] - 2025-11-24

### Added
- **Dependabot** for automatic dependency updates (Python packages and GitHub Actions)
- **Auto-merge workflow** for automatically merging PRs after CI passes
- **Stale bot** for closing inactive issues/PRs
- **Auto-labeling** based on file changes, PR size, and conventional commit prefixes
- **CodeQL security scanning** for vulnerability detection
- **Release Drafter** for automatic release note generation
- **Changelog automation** that updates CHANGELOG.md on PR merge
- **Performance benchmarks** using pytest-benchmark with regression detection
- **AUTOMATION.md** documenting all automated workflows

### Changed
- Enhanced CI/CD pipeline with 9 automated workflows
- Pre-commit hooks now auto-update weekly

## [0.8.0] - 2025-11-24

### Changed
- Removed TestPyPI publishing step for cleaner workflow
- Re-enabled attestations for enhanced package security and provenance

### Security
- Digital attestations now generated for all PyPI releases

## [0.7.0] - 2025-11-24

### Fixed
- Disabled attestations to avoid conflict between TestPyPI and PyPI publishes

## [0.6.0] - 2025-11-24

### Changed
- Renamed workflow from `release.yml` to `publish.yml` to match PyPI trusted publisher configuration

## [0.5.0] - 2025-11-24

### Fixed
- Release workflow now uses explicit `environment: pypi` for trusted publishing

## [0.4.0] - 2025-11-24

### Fixed
- Release workflow now properly handles trusted publishing without environment separation

## [0.3.0] - 2025-11-24

### Changed
- Unified release workflow: single job for tag creation and PyPI publishing
- Removed separate auto-tag, validate-version-bump, and publish workflows

## [0.2.0] - 2025-11-24

### Added
- Initial release of msgtrace-sdk
- OpenTelemetry-based tracing for AI applications
- Unified `MsgTraceAttributes` class with 60+ GenAI semantic convention attributes
- `Spans` class with sync/async context managers and decorators
- Thread-safe `TracerManager` singleton with lazy initialization
- Zero-overhead when telemetry disabled (no-op tracer)
- Support for GenAI semantic conventions (`gen_ai.*`)
- Custom attributes for workflows, tools, agents, costs
- Comprehensive test suite (69 tests, 100% passing)
- Complete API documentation in README
- CI/CD pipeline with automated testing and PyPI publishing

### Changed
- Consolidated API documentation into single README.md
- Cost attributes now use `gen_ai.usage.cost.*` namespace (OpenTelemetry standard)
- Removed `total` parameter from `set_cost()` (auto-calculated by backend)
- Cleaned up attribute namespaces (vendor-neutral for generic attributes)

### Removed
- Removed pytest-xdist (performance overhead for small test suite)
- Removed separate documentation files (now all in README)
