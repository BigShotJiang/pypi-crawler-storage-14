"""Version information for msgtrace-sdk."""

__version__ = "0.12.7"
