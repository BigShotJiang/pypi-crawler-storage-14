"""Chat completions router with OpenAI-compatible API."""

from .completions import router

__all__ = ["router"]
