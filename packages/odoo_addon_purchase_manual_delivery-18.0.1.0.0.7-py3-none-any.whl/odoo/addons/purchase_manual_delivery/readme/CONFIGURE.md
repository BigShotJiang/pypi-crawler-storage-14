The `Manual delivery` checkbox can be edited on any RFQ, on the `Other Information`
tab. To set the default value for new POs, go to Settings -> Purchase -> Delivery.
