The goal of this module is to allow the manual creation of incoming
shipments. When installed, a purchase order won't impact directly the
stock. It will not create the pickings upon order confirmation. It
allows the reception and the impact on stock to be done manually when
needed. The goal is to be used when a supplier does not confirm the full
order at once. As the supplier confirms the different purchase order
lines, the user can manually create the incoming shipments for those
specific lines.
