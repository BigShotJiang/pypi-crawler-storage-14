"""
Tests for setuptools-nodejs.
"""
