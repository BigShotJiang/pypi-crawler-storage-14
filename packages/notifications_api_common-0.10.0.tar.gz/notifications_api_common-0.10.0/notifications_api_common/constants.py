# Exernally defined scopes.
SCOPE_NOTIFICATIES_CONSUMEREN_LABEL = "notificaties.consumeren"
SCOPE_NOTIFICATIES_PUBLICEREN_LABEL = "notificaties.publiceren"
