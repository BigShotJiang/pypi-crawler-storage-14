## Changelog 

### Fixed

- In the data plugin, `cdf data upload dir` now works with argument and
not only in interactive mode.