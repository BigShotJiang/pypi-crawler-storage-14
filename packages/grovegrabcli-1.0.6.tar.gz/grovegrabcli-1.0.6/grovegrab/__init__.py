"""
GroveGrab CLI - Spotify Downloader
A command-line tool for downloading Spotify tracks, playlists, albums, and artists.
"""

__version__ = "1.0.6"
__author__ = "Your Name"
__license__ = "MIT"
