"""Utility functions to handle numpy 2."""

from pykalman.utils._numpy import newbyteorder

__all__ = ["newbyteorder"]
