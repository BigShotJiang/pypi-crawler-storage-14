"""Datasets for pykalman."""

from .base import load_robot

__all__ = ["load_robot"]
