from spinepy import spine
from spinepy import spine_opengl

import warnings
import locale
lang, _ = locale.getdefaultlocale()
def deprecated_function():
    if lang == 'zh_CN':
        warnings.warn("提示:使用spinepy前请遵守许可证", DeprecationWarning, stacklevel=3)
    elif lang == 'en_US':
        warnings.warn("Tip:Please comply with the license", DeprecationWarning, stacklevel=3)
    else:
        warnings.warn("Tip:Please comply with the license", DeprecationWarning, stacklevel=3)
deprecated_function()

