import time
import sdl2
from OpenGL.GL import *
import ctypes

from spinepy import spine
import spinepy.spine_opengl as spine_opengl

# 初始化SDL2
if sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO) != 0:
    print("SDL_Init failed:", sdl2.SDL_GetError())
    exit(1)

# 配置OpenGL上下文（匹配着色器版本330 core）
sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MAJOR_VERSION, 3)    # 改为3
sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MINOR_VERSION, 3)    # 改为3
sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_PROFILE_MASK, sdl2.SDL_GL_CONTEXT_PROFILE_CORE)
sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_DOUBLEBUFFER, 1)             # 强制启用双缓冲
sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_DEPTH_SIZE, 24)

width  = 640
height = 480


# 创建窗口
window = sdl2.SDL_CreateWindow(
    b"OpenGL Triangle",
    sdl2.SDL_WINDOWPOS_CENTERED,
    sdl2.SDL_WINDOWPOS_CENTERED,
    width, height,
    sdl2.SDL_WINDOW_OPENGL | sdl2.SDL_WINDOW_SHOWN
)
if not window:
    print("Window creation failed:", sdl2.SDL_GetError())
    exit(1)

# 创建OpenGL上下文
gl_context = sdl2.SDL_GL_CreateContext(window)
if not gl_context:
    print("OpenGL context creation failed:", sdl2.SDL_GetError())
    exit(1)

# 确保上下文是当前的
if sdl2.SDL_GL_MakeCurrent(window, gl_context) != 0:
    print("MakeCurrent failed:", sdl2.SDL_GetError())
    exit(1)

# 检查OpenGL版本（调试用）
print("OpenGL版本:", glGetString(GL_VERSION).decode())
print("着色器版本:", glGetString(GL_SHADING_LANGUAGE_VERSION).decode())


# We use a y-down coordinate system, see renderer_set_viewport_size()
spine.Bone.set_y_down(True)
print("spine.Bone.set_y_down(True)")
#Load the atlas and the skeleton data
import os

print(os.path.exists("data/spineboy-pma.atlas"))
atlas:spine_opengl.Atlas = spine_opengl.Atlas("data/spineboy-pma.atlas")
print("atlas")
binary:spine.SkeletonBinary = spine.SkeletonBinary(atlas.atlas)
skeletonData:spine.SkeletonData  = binary.read_skeleton_data_file(spine.String("data/spineboy-pro.skel"));

print("skeletonData")

#Create a skeleton from the data, set the skeleton's position to the bottom center of
#the screen and scale it to make it smaller.
skeleton = spine.Skeleton(skeletonData)
skeleton.set_position(width / 2, height - 100)
skeleton.set_scale_x(0.3)
skeleton.set_scale_y(0.3)
skeleton.set_x(300)


print("skeleton.set_x(300)")

#Create an AnimationState to drive a nimations on the skeleton. Set the "portal" animation
#on track with index 0.
animationStateData= spine.AnimationStateData(skeletonData)
animationStateData.setDefaultMix(0.2)
animationState = spine.AnimationState (animationStateData)

print("animationState")

#在这俩方法上出问题了
animationState.set_animation_by_name(0, spine.String("portal"), True)
animationState.add_animation_by_name(0, spine.String("run"), True, 0)


print("animationState.add_animation_by_name")

# print(set_res)
# print(add_res)

#Create the renderer and set the viewport size to match the window size. This sets up a
#pixel perfect orthogonal projection for 2D rendering.
renderer:spine_opengl.renderer_t = spine_opengl.renderer_create()
spine_opengl.renderer_set_viewport_size(renderer, width, height)


# 主循环
running = True
event = sdl2.SDL_Event()
last_time  = time.time()
while running:
    sdl2.SDL_Delay(16)
    while sdl2.SDL_PollEvent(ctypes.byref(event)) != 0:
        if event.type == sdl2.SDL_QUIT:
            running = False
        # 处理键盘事件（可选，按ESC退出）
        elif event.type == sdl2.SDL_KEYDOWN:
            if event.key.keysym.sym == sdl2.SDLK_ESCAPE:
                running = False
    cur_time = time.time()
    delta = cur_time - last_time
    last_time = cur_time


	# Update and apply the animation state to the skeleton
    animationState.update(delta)
    animationState.apply(skeleton)

	# # Update the skeleton time (used for physics)
    skeleton.update(delta)

	# # Calculate the new pose
    skeleton.update_world_transform(spine.Physics.UPDATE)

	# # Clear the screen
    glClear(GL_COLOR_BUFFER_BIT)
    glClearColor(1,1,1,1)

	# # Render the skeleton in its current pose
    spine_opengl.renderer_draw(renderer, skeleton, True)
    
    # 交换缓冲区
    sdl2.SDL_GL_SwapWindow(window)

    
spine_opengl.renderer_dispose(renderer)
# 清理资源
sdl2.SDL_GL_DeleteContext(gl_context)
sdl2.SDL_DestroyWindow(window)
sdl2.SDL_Quit()
