# Copyright (c) [GuYeying] [2025]
# This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
# See the LICENSE file in the project root for full license details.
# SPDX-License-Identifier: MIT

from spinepy import spine
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader


# A vertex of a mesh generated from a Spine skeleton
class vertex_t:...
# A GPU-side mesh using OpenGL vertex arrays, vertex buffer, and
# indices buffer.
class mesh_t :...
# Renderer capable of rendering a spine_skeleton_drawable, using a shader, a mesh, and a
# temporary CPU-side vertex buffer used to update the GPU-side mesh
class renderer_t:...

#mesh_t *mesh_create();
def mesh_create()->mesh_t:...

#void mesh_update(mesh_t *mesh, vertex_t *vertices, int num_vertices, uint16_t *indices, int num_indices);
def mesh_update(mesh:mesh_t,vertices:vertex_t,num_vertices:int,indices:int,num_indices:int):...

#void mesh_draw(mesh_t *mesh);
def mesh_draw(mesh:mesh_t):...

# void mesh_dispose(mesh_t *mesh);
def mesh_dispose(mesh:mesh_t):...

# # A shader (the OpenGL shader program id)
# typedef unsigned int shader_t;
shader_t = int

# # Creates a shader program from the vertex and fragment shader
# shader_t shader_create(const char *vertex_shader, const char *fragment_shader);
def shader_create(vertex_shader:str,fragment_shader:str)->shader_t:...

# # Sets a uniform matrix by name
# void shader_set_matrix4(shader_t program, const char *name, const float *matrix);
def shader_set_matrix4(program:shader_t,name:str,matrix:float):...

# # Sets a uniform float by name
# void shader_set_float(shader_t program, const char *name, float value);
def shader_set_float(program:shader_t,name:str,value:float):...

# # Sets a uniform int by name
# void shader_set_int(shader_t program, const char *name, int value);
def shader_set_int(program:shader_t,name:str,value:int):...

# # Binds the shader
# void shader_use(shader_t shader);
def shader_use(shader:shader_t):...

# # Disposes the shader
# void shader_dispose(shader_t shader);
def shader_dispose(shader:shader_t):...

# # A texture (the OpenGL texture object id)
# typedef unsigned int texture_t;
texture_t = int


# # Loads the given image and creates an OpenGL texture with default settings and auto-generated mipmap levels
# texture_t texture_load(const char *file_path);
def texture_load(file_path:str)->texture_t:...

# # Binds the texture to texture unit 0
# void texture_use(texture_t texture);
def texture_use(texture:texture_t):...

# # Disposes the texture
# void texture_dispose(texture_t texture);
def texture_dispose(texture:texture_t):...

# # A TextureLoader implementation for OpenGL. Use this with spine::Atlas.
# class GlTextureLoader : public spine::TextureLoader {
# public:
# 	void load(spine::AtlasPage &page, const spine::String &path);
# 	void unload(void *texture);
# };
class GlTextureLoader(spine.TextureLoader):
    def __init__(self):
        super().__init__()
    def load(self,page:spine.AtlasPage,path:spine.String):...
    def unload(self,texture):...


# Creates a new renderer
# renderer_t *renderer_create();
def renderer_create()->renderer_t:...

# # Sets the viewport size for the 2D orthographic projection
# void renderer_set_viewport_size(renderer_t *renderer, int width, int height);
def renderer_set_viewport_size(renderer:renderer_t,width:int,height:int):...

# # Draws the given skeleton. The atlas must be the atlas from which the drawable
# # was constructed.
# void renderer_draw(renderer_t *renderer, spine::Skeleton *skeleton, bool premultipliedAlpha);
def renderer_draw(renderer:renderer_t,skeleton:spine.Skeleton,premultipliedAlpha:bool):...

# # Draws the given skeleton. The atlas must be the atlas from which the drawable
# # was constructed.
# void renderer_draw_lite(renderer_t *renderer, spine_skeleton skeleton, bool premultipliedAlpha);
def renderer_draw_lite(renderer:renderer_t,skeleton:spine.skeleton_t,premultipliedAlpha:bool):...

# # Disposes the renderer
# void renderer_dispose(renderer_t *renderer);
def renderer_dispose(renderer:renderer_t):...
