# Copyright (c) [GuYeying] [2025]
# This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
# See the LICENSE file in the project root for full license details.
# SPDX-License-Identifier: MIT

import os
from spinepy import spine
from OpenGL.GL import *
from OpenGL.GL.shaders import compileProgram, compileShader
from array import array
from PIL import Image
import numpy as np

texture_t = int
shader_t  = int

# A vertex of a mesh generated from a Spine skeleton
class vertex_t(ctypes.Structure):
    """对应 C++ 的 vertex_t 结构体，内存布局需完全匹配"""
    _fields_ = [
        ("x", ctypes.c_float),       # 顶点 X 坐标（float，4字节）
        ("y", ctypes.c_float),       # 顶点 Y 坐标（float，4字节）
        ("color", ctypes.c_uint32),  # 颜色（4字节：RGBA，unsigned byte 打包）
        ("u", ctypes.c_float),       # UV 纹理 X 坐标（float，4字节）
        ("v", ctypes.c_float),       # UV 纹理 Y 坐标（float，4字节）
        ("darkColor", ctypes.c_uint32)  # 深色（4字节：RGBA，unsigned byte 打包）
    ]

# A GPU-side mesh using OpenGL vertex arrays, vertex buffer, and
# indices buffer.
class mesh_t:
    """对应 C++ 的 mesh_t 结构体，封装 VAO/VBO/IBO 和顶点/索引计数"""
    def __init__(self, vao: "GLuint", vbo: "GLuint", ibo: "GLuint"): # type: ignore
        self.vao:int = vao          # 顶点数组对象 ID（核心，关联 VBO/IBO 和顶点属性）
        self.vbo:int = vbo          # 顶点缓冲对象 ID（存储顶点数据）
        self.ibo:int = ibo          # 索引缓冲对象 ID（存储三角形索引）
        self.num_vertices:int = 0   # 当前顶点数量（初始为 0，后续添加顶点时更新）
        self.num_indices:int = 0    # 当前索引数量（初始为 0，后续添加索引时更新）

# Renderer capable of rendering a spine_skeleton_drawable, using a shader, a mesh, and a
# temporary CPU-side vertex buffer used to update the GPU-side mesh
class renderer_t:
    def __init__(self):
        self.shader:int=0
        self.mesh:mesh_t=None
        self.vertex_buffer_size:int=0
        self.vertex_buffer:vertex_t=None
        self.renderer:spine.SkeletonRenderer=None


blend_modes:list[list]= [
		[ GL_SRC_ALPHA,  GL_ONE,  GL_ONE_MINUS_SRC_ALPHA,  GL_ONE],
		[ GL_SRC_ALPHA,  GL_ONE,  GL_ONE,  GL_ONE],
		[ GL_DST_COLOR,  GL_DST_COLOR,  GL_ONE_MINUS_SRC_ALPHA,  GL_ONE_MINUS_SRC_ALPHA],
		[ GL_ONE,  GL_ONE,  GL_ONE_MINUS_SRC_COLOR,  GL_ONE_MINUS_SRC_COLOR]]



def mesh_create()->mesh_t:
    """
    对应 C++ 的 mesh_create()，创建并初始化 Mesh 对象（VAO/VBO/IBO + 顶点属性配置）
    返回：初始化完成的 Mesh 实例
    """
    # 1. 生成 OpenGL 对象（VAO:1个，VBO:1个，IBO:1个）
    # 注意：PyOpenGL 中 glGen* 函数返回的是列表（即使只生成1个），需取第0个元素
    vao = glGenVertexArrays(1)  # 直接返回整数，无需 [0]
    vbo = glGenBuffers(1)       # 直接返回整数，无需 [0]
    ibo = glGenBuffers(1)       # 直接返回整数，无需 [0]

    # 2. 绑定 VAO（后续操作都关联到这个 VAO）
    glBindVertexArray(vao)

    # 3. 绑定 VBO（顶点缓冲）和 IBO（索引缓冲）
    glBindBuffer(GL_ARRAY_BUFFER, vbo)          # 绑定 VBO 到 GL_ARRAY_BUFFER 目标
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo)  # 绑定 IBO 到 GL_ELEMENT_ARRAY_BUFFER 目标

    # 4. 配置顶点属性（对应 C++ 的 glVertexAttribPointer + glEnableVertexAttribArray）
    # 注意：Vertex 结构体的内存偏移用 ctypes.offsetof 计算（与 C++ offsetof 完全一致）
    vertex_size = ctypes.sizeof(vertex_t)  # 单个顶点的字节大小（对应 C++ 的 sizeof(vertex_t)）

    # 属性 0：顶点坐标（x, y）- 2个 float，不归一化，步长=顶点大小，偏移=Vertex.x 的偏移
    glVertexAttribPointer(
        index=0,
        size=2,                      # 每个属性的分量数（x+y 共2个）
        type=GL_FLOAT,               # 数据类型（float）
        normalized=GL_FALSE,         # 是否归一化（坐标不需要归一化）
        stride=vertex_size,          # 相邻顶点的字节间隔（单个顶点的大小）
        pointer=ctypes.c_void_p(vertex_t.x.offset)  # 该属性在顶点结构体中的偏移
    )
    glEnableVertexAttribArray(0)  # 启用属性 0

    # 属性 1：颜色（color）- 4个 unsigned byte，归一化（将 0-255 映射到 0.0-1.0）
    glVertexAttribPointer(
        index=1,
        size=4,                      # 颜色分量数（R+G+B+A 共4个）
        type=GL_UNSIGNED_BYTE,       # 数据类型（unsigned byte，对应 c_uint32 拆分后的每个字节）
        normalized=GL_TRUE,          # 归一化（颜色需要将 0-255 转为 0.0-1.0）
        stride=vertex_size,
        pointer=ctypes.c_void_p(vertex_t.color.offset)
    )
    glEnableVertexAttribArray(1)  # 启用属性 1

    # 属性 2：UV 坐标（u, v）- 2个 float，不归一化
    glVertexAttribPointer(
        index=2,
        size=2,
        type=GL_FLOAT,
        normalized=GL_FALSE,
        stride=vertex_size,
        pointer=ctypes.c_void_p(vertex_t.u.offset)
    )
    glEnableVertexAttribArray(2)  # 启用属性 2

    # 属性 3：深色（darkColor）- 4个 unsigned byte，归一化
    glVertexAttribPointer(
        index=3,
        size=4,
        type=GL_UNSIGNED_BYTE,
        normalized=GL_TRUE,
        stride=vertex_size,
        pointer=ctypes.c_void_p(vertex_t.darkColor.offset)
    )
    glEnableVertexAttribArray(3)  # 启用属性 3

    # 5. 解绑 VAO（避免后续操作意外修改该 VAO）
    glBindVertexArray(0)

    # 6. 创建并返回 Mesh 实例（对应 C++ 的 malloc + 赋值）
    return mesh_t(vao=vao, vbo=vbo, ibo=ibo)


def mesh_update(
    mesh: mesh_t,
    vertices: list[vertex_t],  # 顶点列表（元素为 Vertex 实例）
    indices: list[int]       # 索引列表（元素为 uint16_t 范围内的整数）
) -> None:
    """
    更新 Mesh 的顶点和索引数据（对应 C++ 的 mesh_update）
    :param mesh: 要更新的 Mesh 实例
    :param vertices: 新的顶点列表（需为 Vertex 类型的列表）
    :param indices: 新的索引列表（值需在 0~65535 范围内，对应 uint16_t）
    """
    # 1. 绑定 VAO（确保操作关联到该 Mesh）
    glBindVertexArray(mesh.vao)

    # 2. 更新 VBO（顶点缓冲）
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo)
    num_vertices = len(vertices)
    # 计算顶点数据总字节数（单个顶点大小 × 顶点数量）
    vertex_data_size = ctypes.sizeof(vertex_t) * num_vertices
    # 将 Python 列表转换为 C 兼容的缓冲区（连续内存）
    vertex_buffer = (vertex_t * num_vertices)(*vertices)  # 打包为 Vertex 数组
    glBufferData(
        GL_ARRAY_BUFFER,
        vertex_data_size,          # 数据大小（字节）
        vertex_buffer,             # 顶点数据缓冲区
        GL_STATIC_DRAW             # 数据使用方式（静态绘制）
    )
    mesh.num_vertices = num_vertices  # 更新顶点计数

    # 3. 更新 IBO（索引缓冲）
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ibo)
    num_indices = len(indices)
    # 计算索引数据总字节数（每个索引 2 字节 × 索引数量，对应 uint16_t）
    index_data_size = ctypes.sizeof(ctypes.c_uint16) * num_indices
    # 将索引列表转换为 C 兼容的 uint16_t 数组
    index_buffer = (ctypes.c_uint16 * num_indices)(*indices)
    glBufferData(
        GL_ELEMENT_ARRAY_BUFFER,
        index_data_size,           # 数据大小（字节）
        index_buffer,              # 索引数据缓冲区
        GL_STATIC_DRAW             # 数据使用方式（静态绘制）
    )
    mesh.num_indices = num_indices  # 更新索引计数

    # 4. 解绑 VAO
    glBindVertexArray(0)



def mesh_draw(mesh: mesh_t) -> None:
    """绘制 Mesh（对应 C++ 的 mesh_draw）"""
    if mesh.num_indices == 0:
        return  # 无索引数据，不绘制

    # 绑定 VAO 并绘制三角形（索引绘制）
    glBindVertexArray(mesh.vao)
    glDrawElements(
        GL_TRIANGLES,              # 绘制图元类型（三角形）
        mesh.num_indices,          # 索引数量
        GL_UNSIGNED_SHORT,         # 索引数据类型（对应 uint16_t）
        None                       # 索引偏移（从开头开始，为 None 即可）
    )
    glBindVertexArray(0)  # 解绑 VAO



def mesh_dispose(mesh: mesh_t) -> None:
    """释放 Mesh 的 OpenGL 资源（对应 C++ 的 mesh_dispose）"""
    # 删除 VBO、IBO、VAO（注意参数是列表，PyOpenGL 要求）
    glDeleteBuffers(1, [mesh.vbo])
    glDeleteBuffers(1, [mesh.ibo])
    glDeleteVertexArrays(1, [mesh.vao])
    # Python 中无需手动 free，GC 会自动回收 Mesh 实例




def compile_shader(source: str, shader_type: int) -> int:
    # 1. 创建着色器对象
    shader = glCreateShader(shader_type)
    if shader == 0:
        print("Error: 无法创建着色器对象")
        return 0

    # 2. 绑定源码并编译
    glShaderSource(shader, [source])
    glCompileShader(shader)

    # 3. 检查编译结果
    success = ctypes.c_int()
    glGetShaderiv(shader, GL_COMPILE_STATUS, ctypes.byref(success))
    if not success.value:
        # 直接使用封装好的 glGetShaderInfoLog，仅传入 shader 对象
        info_log = glGetShaderInfoLog(shader)  # 这里是关键修改
        print(f"着色器编译失败:\n{info_log.decode('utf-8')}")  # 转换为字符串
        glDeleteShader(shader)
        return 0

    return shader



def shader_create(vertex_source: str, fragment_source: str) -> int:
    """
    创建着色器程序（链接顶点着色器和片段着色器，对应 C++ 的 shader_create）
    :param vertex_source: 顶点着色器源码
    :param fragment_source: 片段着色器源码
    :return: 链接成功的程序 ID（失败返回 0）
    """
    # 1. 编译顶点着色器和片段着色器
    vertex_shader = compile_shader(vertex_source, GL_VERTEX_SHADER)
    fragment_shader = compile_shader(fragment_source, GL_FRAGMENT_SHADER)
    if vertex_shader == 0 or fragment_shader == 0:
        # 编译失败，清理资源
        if vertex_shader != 0:
            glDeleteShader(vertex_shader)
        if fragment_shader != 0:
            glDeleteShader(fragment_shader)
        return 0

    # 2. 创建程序并附加着色器
    program = glCreateProgram()
    if program == 0:
        print("Error: 无法创建着色器程序")
        glDeleteShader(vertex_shader)
        glDeleteShader(fragment_shader)
        return 0

    glAttachShader(program, vertex_shader)
    glAttachShader(program, fragment_shader)

    # 3. 链接程序
    glLinkProgram(program)

    # 4. 检查链接结果
    success = ctypes.c_int()
    glGetProgramiv(program, GL_LINK_STATUS, ctypes.byref(success))
    if not success.value:
        # 获取错误日志
        info_log = ctypes.create_string_buffer(512)
        glGetProgramInfoLog(program, 512, None, info_log)
        print(f"着色器链接失败:\n{info_log.value.decode('utf-8')}")
        glDeleteProgram(program)  # 链接失败，删除程序
        program = 0

    # 5. 链接成功后，删除着色器（已被程序引用，无需保留）
    glDeleteShader(vertex_shader)
    glDeleteShader(fragment_shader)

    return program



def shader_set_matrix4(shader:shader_t, name:str, matrix:list)->None:
	glUseProgram(shader)
	location:int = glGetUniformLocation(shader, name)
	glUniformMatrix4fv(location, 1, GL_FALSE, matrix)

def shader_set_float(shader:shader_t, name:str, value:float)->None:
	glUseProgram(shader)
	location:int = glGetUniformLocation(shader, name)
	glUniform1f(location, value)


def shader_set_int(shader:shader_t, name:str, value:int)->None:
	glUseProgram(shader)
	location:int = glGetUniformLocation(shader, name)
	glUniform1i(location, value)


def shader_use( program:shader_t)->None:
	glUseProgram(program)

def shader_dispose( program:shader_t)->None:
	glDeleteProgram(program)


def texture_load(file_path: str) -> int:
    """
    加载纹理文件并创建 OpenGL 纹理对象（使用 Pillow + NumPy 替代 STB）
    修复：移除多余的纹理翻转，适配 Spine PMA 纹理
    :param file_path: 纹理文件路径
    :return: OpenGL 纹理 ID（失败返回 0）
    """
    try:
        # 补全绝对路径，避免相对路径错误
        file_abs = os.path.abspath(file_path)
        if not os.path.exists(file_abs):
            print(f"纹理文件不存在：{file_abs}")
            return 0

        # 1. 使用 Pillow 打开图像，强制转换为 RGBA（适配 Spine PMA 纹理）
        with Image.open(file_abs) as img:
            img_rgba = img.convert("RGBA")
            width, height = img_rgba.size
            # 2. 转换为 NumPy 数组（**移除翻转代码**）
            img_array = np.array(img_rgba).astype(np.uint8)  # 不再执行 transpose

        # 3. 固定为 RGBA 格式（适配 Spine PMA 纹理）
        format = GL_RGBA

        # 4. 生成并绑定 OpenGL 纹理对象
        texture = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, texture)

        # 5. 上传纹理数据（关键：Spine PMA 纹理需使用 GL_UNPACK_ALIGNMENT 1）
        glPixelStorei(GL_UNPACK_ALIGNMENT, 1)  # 修复纹理像素对齐问题
        glTexImage2D(
            GL_TEXTURE_2D,
            0,                      # 纹理级别
            GL_RGBA8,               # 内部格式：明确使用 8 位 RGBA（适配 PMA）
            width,                  # 宽度
            height,                 # 高度
            0,                      # 边框
            format,                 # 像素格式
            GL_UNSIGNED_BYTE,       # 数据类型
            img_array               # 像素数据（无翻转）
        )

        # 6. 设置纹理参数（优化：PMA 纹理需关闭 mipmap 或调整过滤）
        glGenerateMipmap(GL_TEXTURE_2D)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
        # 若仍有模糊，可改为 GL_LINEAR（关闭 mipmap 过滤）
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR)
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)

        # 7. 解绑纹理
        glBindTexture(GL_TEXTURE_2D, 0)

        print(f"纹理加载成功：{file_abs} (宽：{width}, 高：{height})")
        return texture

    except Exception as e:
        print(f"加载纹理失败 {file_path}: {str(e)}")
        return 0


def texture_use(texture:texture_t)->None:
	glActiveTexture(GL_TEXTURE0)# Set active texture unit to 0
	glBindTexture(GL_TEXTURE_2D, texture)
def texture_dispose(texture:texture_t)->None:
	glDeleteTextures(1, texture)



def matrix_ortho_projection(matrix:list, width:float, height:float)->None:
	left = 0.0
	right = width
	bottom = height
	top = 0.0
	near = -1.0
	far = 1.0
    
	matrix[0] = 2.0 / (right - left)
	matrix[5] = 2.0 / (top - bottom)
	matrix[10] = -2.0 / (far - near)
	matrix[12] = -(right + left) / (right - left)
	matrix[13] = -(top + bottom) / (top - bottom)
	matrix[14] = -(far + near) / (far - near)
	matrix[15] = 1.0


class Atlas:
    def __init__(self,path:str):
        self.atlas = spine.Atlas(spine.String("data/spineboy-pma.atlas"),None,False)
        self.load()

    def load(self):
        pages:list = self.atlas.get_pages()
        print("pages length:",len(pages))
        for page in pages:
            name        : spine.String = page.name
            path        : spine.String = page.texture_path
            formate     : spine.Format = page.format
            min_filter  : spine.TEXTURE_FILTER_ENUM = page.min_filter
            mag_filter  : spine.TEXTURE_FILTER_ENUM = page.mag_filter
            u_wrap      : spine.TextureWrap = page.u_wrap
            v_warp      : spine.TextureWrap = page.v_wrap
            width       : int  = page.width
            height      : int  = page.height
            pma         : bool = page.pma
            index       : int  = page.index

            page.texture = texture_load(str(path))

        regions = self.atlas.get_regions()
        for region in regions:
            texture_path = region.page.texture_path
            region.rendererObject = page.texture

    def unload(self):
        if self.atlas:
            pages:list = self.atlas.get_pages()
            for page in pages:
                name        : spine.String = page.name
                path        : spine.String = page.texture_path
                formate     : spine.Format = page.format
                min_filter  : spine.TEXTURE_FILTER_ENUM = page.min_filter
                mag_filter  : spine.TEXTURE_FILTER_ENUM = page.mag_filter
                u_wrap      : spine.TextureWrap = page.u_wrap
                v_warp      : spine.TextureWrap = page.v_wrap
                width       : int  = page.width
                height      : int  = page.height
                pma         : bool = page.pma
                index       : int  = page.index
                #texture     : int  = page.texture
         
    def __del__(self):
         self.unload()


def renderer_create()->renderer_t :
    shader:shader_t = shader_create("""#version 330 core
        layout (location = 0) in vec2 aPos;
        layout (location = 1) in vec4 aLightColor;
        layout (location = 2) in vec2 aTexCoord;
        layout (location = 3) in vec4 aDarkColor;

        uniform mat4 uMatrix;

        out vec4 lightColor;
        out vec4 darkColor;
        out vec2 texCoord;

        void main() {
            lightColor = aLightColor;
            darkColor = aDarkColor;
            texCoord = aTexCoord;
            gl_Position = uMatrix * vec4(aPos, 0.0, 1.0);
        }"""
        ,
		"""#version 330 core
        in vec4 lightColor;
        in vec4 darkColor;
        in vec2 texCoord;
        out vec4 fragColor;

        uniform sampler2D uTexture;
        void main() {
            vec4 texColor = texture(uTexture, texCoord);
            float alpha = texColor.a * lightColor.a;
            fragColor.a = alpha;
            fragColor.rgb = ((texColor.a - 1.0) * darkColor.a + 1.0 - texColor.rgb) * darkColor.rgb + texColor.rgb * lightColor.rgb;
        }
    """)
    if (shader==None):
         return None
    mesh:mesh_t = mesh_create()
    renderer = renderer_t()
    renderer.shader = shader
    renderer.mesh = mesh
    renderer.vertex_buffer_size = 0
    renderer.vertex_buffer = None
    renderer.renderer = spine.SkeletonRenderer()
    return renderer




def renderer_set_viewport_size(renderer: renderer_t, width: int, height: int) -> None:
    """设置渲染器视口大小并更新投影矩阵"""
    matrix = [0 for i in range(16)]
    # 生成正交投影矩阵
    matrix_ortho_projection(matrix,float(width), float(height))
    # 使用着色器并设置矩阵 uniforms
    shader_use(renderer.shader)
    shader_set_matrix4(renderer.shader, "uMatrix", matrix)



def renderer_draw_lite(renderer: renderer_t, spine_skeleton, premultiplied_alpha: bool) -> None:
    """简化版绘制函数（包装 renderer_draw）"""
    # spine_skeleton 是 Python 绑定的 Spine 骨骼对象（对应 C++ 的 spine_skeleton）
    renderer_draw(renderer, spine_skeleton, premultiplied_alpha)


def renderer_draw(renderer: renderer_t, skeleton, premultiplied_alpha: bool) -> None:
    """绘制 Spine 骨骼动画的核心函数"""
    # 1. 激活着色器并设置纹理单元
    shader_use(renderer.shader)
    shader_set_int(renderer.shader, "uTexture", 0)  # 绑定到纹理单元 0
    glEnable(GL_BLEND)  # 启用混合

    # 2. 获取 Spine 渲染命令（假设 renderer.render() 返回 RenderCommand 链表）
    #在此处生成渲染指令，该类是用来生成渲染指令的
    command = renderer.renderer.render(skeleton)

    # 3. 遍历所有渲染命令并绘制
    while command:
        num_vertices = command.numVertices
        num_indices = command.numIndices

        # 4. 确保顶点缓冲区足够大（动态扩容）
        if renderer.vertex_buffer_size < num_vertices:
            renderer.vertex_buffer_size = num_vertices
            # 重新分配顶点缓冲区（Python 列表自动管理内存）
            renderer.vertex_buffer = [vertex_t() for _ in range(num_vertices)]

        # 5. 填充顶点数据（转换 Spine 命令数据到顶点缓冲区）
        data        = command.get_raw_data()
        positions   = data["positions"]#command.positions  # 格式：[x0, y0, x1, y1, ...]
        uvs         = data["uvs"]#command.uvs              # 格式：[u0, v0, u1, v1, ...]
        colors      = data["colors"]#command.colors        # 格式：[color0, color1, ...]（uint32）
        dark_colors = data["darkColors"]#command.darkColors
        indices     = data["indices"]
        texture     = data["texture"]
        for i in range(num_vertices):
            j = i * 2  # 位置和 UV 是 2 个元素一组
            vertex = renderer.vertex_buffer[i]
            # 位置
            vertex.x = positions[j]
            vertex.y = positions[j + 1]
            # UV
            vertex.u = uvs[j]
            vertex.v = uvs[j + 1]
            # 颜色（转换 RGBA 字节顺序，适配 OpenGL）
            color = colors[i]
            # C++: (color & 0xFF00FF00) | ((color & 0x00FF0000) >> 16) | ((color & 0x000000FF) << 16)
            # 等价于：交换 R 和 B 通道（Spine 可能用 RGBA，OpenGL 纹理可能用 BGRA）
            vertex.color = (
                (color & 0xFF00FF00)  # 保留 G 和 A 通道
                | ((color & 0x00FF0000) >> 16)  # R 通道移到 B 位置
                | ((color & 0x000000FF) << 16)  # B 通道移到 R 位置
            )
            # 深色（同上）
            dark_color = dark_colors[i]
            vertex.darkColor = (
                (dark_color & 0xFF00FF00)
                | ((dark_color & 0x00FF0000) >> 16)
                | ((dark_color & 0x000000FF) << 16)
            )

        # 6. 更新网格数据
        mesh_update(
            renderer.mesh,
            renderer.vertex_buffer[:num_vertices],  # 有效顶点
            indices[:num_indices]           # 有效索引
        )

        # 7. 设置混合模式（根据预乘 alpha 选择不同因子）
        blend_mode = blend_modes[command.blendMode]
        src_color = blend_mode[1] if premultiplied_alpha else blend_mode[0]
        glBlendFuncSeparate(
            GLenum(src_color),
            GLenum(blend_mode[2]),
            GLenum(blend_mode[3]),
            GLenum(blend_mode[2])
        )

        # 8. 绑定纹理并绘制
        texture_use(texture)  # 激活纹理
        mesh_draw(renderer.mesh)  # 绘制网格

        # 9. 处理下一个命令
        command = command.next



def renderer_dispose(renderer: renderer_t) -> None:
    """释放渲染器所有资源"""
    # 释放着色器
    shader_dispose(renderer.shader)
    # 释放网格
    mesh_dispose(renderer.mesh)
    # 清空顶点缓冲区（Python 自动回收）
    renderer.vertex_buffer = []
    renderer.vertex_buffer_size = 0
    # 释放 Spine 渲染器（假设是 Python 绑定的对象，可能需要特定释放方法）
    del renderer.renderer










