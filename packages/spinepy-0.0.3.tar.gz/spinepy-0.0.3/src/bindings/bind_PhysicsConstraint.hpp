// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/PhysicsConstraint.h>

namespace py = pybind11;
using namespace spine;

void bind_physics_constraint(py::module_& m) {
    // 绑定物理约束类（继承自 Updatable）
    py::class_<PhysicsConstraint, Updatable>(m, "PhysicsConstraint")
        // 构造函数（通常由 Skeleton 内部创建，Python 中一般不直接调用）
        .def(py::init<PhysicsConstraintData&, Skeleton&>(),
             py::arg("data"), py::arg("skeleton"),
             "构造函数：物理约束数据 + 骨骼实例")

        // 关联数据与骨骼
        .def("get_data", &PhysicsConstraint::getData,
             "获取关联的物理约束数据（PhysicsConstraintData）",
             py::return_value_policy::reference)  // 返回数据引用（不转移所有权）
        .def("set_bone", &PhysicsConstraint::setBone,
             py::arg("bone"), "设置关联的骨骼（Bone）")
        .def("get_bone", &PhysicsConstraint::getBone,
             "获取关联的骨骼（Bone）",
             py::return_value_policy::reference)  // 返回骨骼引用

        // 物理参数（惯性/强度/阻尼等）
        .def("set_inertia", &PhysicsConstraint::setInertia, py::arg("value"), "设置惯性")
        .def("get_inertia", &PhysicsConstraint::getInertia, "获取惯性")
        .def("set_strength", &PhysicsConstraint::setStrength, py::arg("value"), "设置强度")
        .def("get_strength", &PhysicsConstraint::getStrength, "获取强度")
        .def("set_damping", &PhysicsConstraint::setDamping, py::arg("value"), "设置阻尼")
        .def("get_damping", &PhysicsConstraint::getDamping, "获取阻尼")
        .def("set_mass_inverse", &PhysicsConstraint::setMassInverse, py::arg("value"), "设置质量倒数")
        .def("get_mass_inverse", &PhysicsConstraint::getMassInverse, "获取质量倒数")
        .def("set_wind", &PhysicsConstraint::setWind, py::arg("value"), "设置风力")
        .def("get_wind", &PhysicsConstraint::getWind, "获取风力")
        .def("set_gravity", &PhysicsConstraint::setGravity, py::arg("value"), "设置重力")
        .def("get_gravity", &PhysicsConstraint::getGravity, "获取重力")
        .def("set_mix", &PhysicsConstraint::setMix, py::arg("value"), "设置混合系数")
        .def("get_mix", &PhysicsConstraint::getMix, "获取混合系数")

        // 重置与状态参数
        .def("set_reset", &PhysicsConstraint::setReset, py::arg("value"), "设置是否重置物理状态")
        .def("get_reset", &PhysicsConstraint::getReset, "判断是否重置物理状态")
        .def("set_ux", &PhysicsConstraint::setUx, py::arg("value"), "设置UX参数")
        .def("get_ux", &PhysicsConstraint::getUx, "获取UX参数")
        .def("set_uy", &PhysicsConstraint::setUy, py::arg("value"), "设置UY参数")
        .def("get_uy", &PhysicsConstraint::getUy, "获取UY参数")
        .def("set_cx", &PhysicsConstraint::setCx, py::arg("value"), "设置CX参数")
        .def("get_cx", &PhysicsConstraint::getCx, "获取CX参数")
        .def("set_cy", &PhysicsConstraint::setCy, py::arg("value"), "设置CY参数")
        .def("get_cy", &PhysicsConstraint::getCy, "获取CY参数")
        .def("set_tx", &PhysicsConstraint::setTx, py::arg("value"), "设置TX参数")
        .def("get_tx", &PhysicsConstraint::getTx, "获取TX参数")
        .def("set_ty", &PhysicsConstraint::setTy, py::arg("value"), "设置TY参数")
        .def("get_ty", &PhysicsConstraint::getTy, "获取TY参数")

        // 偏移与速度参数
        .def("set_x_offset", &PhysicsConstraint::setXOffset, py::arg("value"), "设置X轴偏移")
        .def("get_x_offset", &PhysicsConstraint::getXOffset, "获取X轴偏移")
        .def("set_x_velocity", &PhysicsConstraint::setXVelocity, py::arg("value"), "设置X轴速度")
        .def("get_x_velocity", &PhysicsConstraint::getXVelocity, "获取X轴速度")
        .def("set_y_offset", &PhysicsConstraint::setYOffset, py::arg("value"), "设置Y轴偏移")
        .def("get_y_offset", &PhysicsConstraint::getYOffset, "获取Y轴偏移")
        .def("set_y_velocity", &PhysicsConstraint::setYVelocity, py::arg("value"), "设置Y轴速度")
        .def("get_y_velocity", &PhysicsConstraint::getYVelocity, "获取Y轴速度")
        .def("set_rotate_offset", &PhysicsConstraint::setRotateOffset, py::arg("value"), "设置旋转偏移")
        .def("get_rotate_offset", &PhysicsConstraint::getRotateOffset, "获取旋转偏移")
        .def("set_rotate_velocity", &PhysicsConstraint::setRotateVelocity, py::arg("value"), "设置旋转速度")
        .def("get_rotate_velocity", &PhysicsConstraint::getRotateVelocity, "获取旋转速度")
        .def("set_scale_offset", &PhysicsConstraint::setScaleOffset, py::arg("value"), "设置缩放偏移")
        .def("get_scale_offset", &PhysicsConstraint::getScaleOffset, "获取缩放偏移")
        .def("set_scale_velocity", &PhysicsConstraint::setScaleVelocity, py::arg("value"), "设置缩放速度")
        .def("get_scale_velocity", &PhysicsConstraint::getScaleVelocity, "获取缩放速度")

        // 激活状态与时间参数
        .def("set_active", &PhysicsConstraint::setActive, py::arg("value"), "设置约束是否激活")
        .def("is_active", &PhysicsConstraint::isActive, "判断约束是否激活")
        .def("set_remaining", &PhysicsConstraint::setRemaining, py::arg("value"), "设置剩余时间")
        .def("get_remaining", &PhysicsConstraint::getRemaining, "获取剩余时间")
        .def("set_last_time", &PhysicsConstraint::setLastTime, py::arg("value"), "设置最后更新时间")
        .def("get_last_time", &PhysicsConstraint::getLastTime, "获取最后更新时间")

        // 核心方法
        .def("reset", &PhysicsConstraint::reset, "重置物理约束状态")
        .def("set_to_setup_pose", &PhysicsConstraint::setToSetupPose, "设置为初始姿态")
        .def("update", &PhysicsConstraint::update,
             py::arg("physics"), "更新物理约束（参数为Physics枚举）")
        .def("translate", &PhysicsConstraint::translate,
             py::arg("x"), py::arg("y"), "平移约束")
        .def("rotate", &PhysicsConstraint::rotate,
             py::arg("x"), py::arg("y"), py::arg("degrees"), "旋转约束")

        // 调试字符串表示
        .def("__repr__", [](const PhysicsConstraint& self) {
            // 临时解除const限制以调用非const成员函数
            PhysicsConstraint& non_const_self = const_cast<PhysicsConstraint&>(self);
            return py::str("PhysicsConstraint(data='{}',active={})")
                .format(
                    non_const_self.getData().getName().buffer(),
                    non_const_self.isActive()
                );
        });
}