// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/SpineObject.h>  // 包含SpineObject头文件

namespace py = pybind11;
using namespace spine;

void bind_spine_object(py::module_ &m) {
    // 绑定 SpineObject 基类（所有Spine对象的根类）
    py::class_<SpineObject>(m, "SpineObject")
        .def(py::init<>(), "Spine对象基类的默认构造函数")
        // 不需要显式绑定 operator new/delete 等内存管理函数
        // pybind11 会自动适配C++的内存管理机制
        ;
}