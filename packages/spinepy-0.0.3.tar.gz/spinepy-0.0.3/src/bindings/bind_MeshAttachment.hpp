// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/MeshAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_mesh_attachment(py::module_& m) {
    py::class_<MeshAttachment, VertexAttachment>(m, "MeshAttachment")
        // 1. 构造函数与析构函数
        .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为网格附件的名称")
        .def("__del__", [](MeshAttachment& self) { /* 自动触发C++析构，释放内部向量和关联资源 */ }, 
             "析构函数，清理网格数据、UV、三角形索引等资源")

        // 2. 核心功能函数（重写父类方法+自身方法）
        // 重写的computeWorldVertices（父类VertexAttachment的using声明需绑定）
        .def("computeWorldVertices", 
             py::overload_cast<Slot&, size_t, size_t, float*, size_t, size_t>(&MeshAttachment::computeWorldVertices),
             py::arg("slot"), py::arg("start"), py::arg("count"), 
             py::arg("worldVertices"), py::arg("offset"), py::arg("stride") = 2,
             "计算网格顶点的世界坐标（重写父类方法）\n"
             "- start：起始顶点索引（每个顶点2个值：x/y）\n"
             "- count：需计算的顶点值数量（需 ≤ 总顶点数×2 - start）\n"
             "- worldVertices：输出数组（需预分配 ≥ offset + count 长度）\n"
             "- offset：数组起始写入位置\n"
             "- stride：顶点数据步长（默认2，即[x,y]连续存储）")
        
        .def("updateRegion", &MeshAttachment::updateRegion, 
             "更新纹理区域（TextureRegion）关联的UV数据\n"
             "当修改Region或父网格后调用，确保UV与纹理坐标同步")

        // 3. 网格核心属性的get/set（ hull长度、尺寸、路径）
        .def("getHullLength", &MeshAttachment::getHullLength, "获取网格外壳（hull）顶点数量")
        .def("setHullLength", &MeshAttachment::setHullLength, py::arg("inValue"), "设置网格外壳顶点数量")
        .def("getWidth", &MeshAttachment::getWidth, "获取网格宽度（非必需属性，用于辅助计算）")
        .def("setWidth", &MeshAttachment::setWidth, py::arg("inValue"), "设置网格宽度")
        .def("getHeight", &MeshAttachment::getHeight, "获取网格高度（非必需属性，用于辅助计算）")
        .def("setHeight", &MeshAttachment::setHeight, py::arg("inValue"), "设置网格高度")
        .def("getPath", &MeshAttachment::getPath, py::return_value_policy::reference_internal, 
             "获取纹理路径字符串（只读，内部存储）")
        .def("setPath", &MeshAttachment::setPath, py::arg("inValue"), "设置纹理路径字符串")

        // 4. 数据向量（UV、三角形索引、边缘索引）
        .def("getRegionUVs", &MeshAttachment::getRegionUVs, py::return_value_policy::reference_internal, 
             "获取纹理区域UV向量（Vector<float>，每个顶点2个值，相对于纹理区域的坐标）")
        .def("getUVs", &MeshAttachment::getUVs, py::return_value_policy::reference_internal, 
             "获取全局纹理UV向量（Vector<float>，每个顶点2个值，相对于整个纹理的归一化坐标）")
        .def("getTriangles", &MeshAttachment::getTriangles, py::return_value_policy::reference_internal, 
             "获取三角形索引向量（Vector<unsigned short>，每3个索引构成一个三角形）")
        .def("getEdges", &MeshAttachment::getEdges, py::return_value_policy::reference_internal, 
             "获取边缘索引向量（Vector<unsigned short>，非必需属性，用于碰撞检测等场景）")

        // 5. 关联对象（纹理区域、序列、父网格）
        .def("getColor", &MeshAttachment::getColor, py::return_value_policy::reference_internal, 
             "获取网格颜色引用（可直接修改RGB值，影响整个网格渲染效果）")
        .def("getRegion", &MeshAttachment::getRegion, py::return_value_policy::reference, 
             "获取关联的TextureRegion（可能为None，需确保Region生命周期有效）")
        .def("setRegion", &MeshAttachment::setRegion, py::arg("region"), "设置关联的TextureRegion（可传None）")
        .def("getSequence", &MeshAttachment::getSequence, py::return_value_policy::reference, 
             "获取关联的Sequence（序列帧，可能为None，用于动画帧切换）")
        .def("setSequence", &MeshAttachment::setSequence, py::arg("sequence"), "设置关联的Sequence（可传None）")
        .def("getParentMesh", &MeshAttachment::getParentMesh, py::return_value_policy::reference, 
             "获取父网格（可能为None，用于共享网格数据的链接网格）")
        .def("setParentMesh", &MeshAttachment::setParentMesh, py::arg("inValue"), "设置父网格（可传None）")

        // 6. 复制与链接网格方法
        .def("copy", &MeshAttachment::copy, 
             "复制当前网格附件并返回新实例（深拷贝所有数据，需手动管理新实例生命周期）")
        .def("newLinkedMesh", &MeshAttachment::newLinkedMesh, 
             "创建一个链接到当前网格的新实例\n"
             "新网格共享父网格的顶点、UV、三角形数据，仅自身存储变形和颜色等属性");
}