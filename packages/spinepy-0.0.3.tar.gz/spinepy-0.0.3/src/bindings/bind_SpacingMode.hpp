// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/SpacingMode.h>

namespace py = pybind11;
using namespace spine;

void bind_spacing_mode(py::module_& m) {
    py::enum_<SpacingMode>(m, "SpacingMode")
        .value("LENGTH", SpacingMode_Length, "长度间距模式")
        .value("FIXED", SpacingMode_Fixed, "固定间距模式")
        .value("PERCENT", SpacingMode_Percent, "百分比间距模式")
        .value("PROPORTIONAL", SpacingMode_Proportional, "比例间距模式");
}