// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/TextureLoader.h>


namespace py = pybind11;
using namespace spine;

void bind_texture_loader(py::module_& m) {
    // 绑定抽象类 TextureLoader（不绑定构造函数，禁止直接实例化）
    py::class_<TextureLoader, SpineObject>(m, "TextureLoader")
        // 移除 .def(py::init<>()) 构造函数绑定
        .def("load", &TextureLoader::load,  // 纯虚函数，Python子类必须实现
             py::arg("page"), py::arg("path"), 
             "加载纹理（纯虚函数，必须在子类中实现）")
        .def("unload", &TextureLoader::unload,  // 纯虚函数，Python子类必须实现
             py::arg("texture"), 
             "卸载纹理（纯虚函数，必须在子类中实现）");
}