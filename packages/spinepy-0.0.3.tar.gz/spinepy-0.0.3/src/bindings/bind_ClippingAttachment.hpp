// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include "spine/ClippingAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_clipping_attachment(py::module_& m) {
    py::class_<ClippingAttachment, VertexAttachment>(m, "ClippingAttachment")
        .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为附件名称")
        .def("getEndSlot", &ClippingAttachment::getEndSlot, py::return_value_policy::reference, 
             "返回裁剪结束的插槽数据")
        .def("setEndSlot", &ClippingAttachment::setEndSlot, py::arg("inValue"), 
             "设置裁剪结束的插槽数据")
        .def("getColor", &ClippingAttachment::getColor, py::return_value_policy::reference_internal, 
             "返回裁剪区域的颜色引用")
        .def("copy", &ClippingAttachment::copy, 
             "复制附件并返回新实例（返回值需要手动管理生命周期）");
}