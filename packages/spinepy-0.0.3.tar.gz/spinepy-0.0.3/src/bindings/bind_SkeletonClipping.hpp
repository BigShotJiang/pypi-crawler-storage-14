// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/SkeletonClipping.h>

namespace py = pybind11;
using namespace spine;

// -------------------------- 3. 绑定 SkeletonClipping 类--------------------------
void bind_skeleton_clipping(py::module& m) {
    py::class_<SkeletonClipping, SpineObject>(m, "SkeletonClipping")
        // -------------------------- 构造函数 --------------------------
        .def(py::init<>(), "创建 SkeletonClipping 实例（用于骨骼裁剪功能）")

        // -------------------------- 核心成员方法 --------------------------
        // 1. clipStart：开始裁剪（参数为 Slot 引用 + ClippingAttachment 指针）
        .def("clip_start", &SkeletonClipping::clipStart,
             py::arg("slot"), py::arg("clip"),
             py::return_value_policy::copy,  // 返回 size_t（裁剪顶点数），按值返回
             "开始裁剪操作\n"
             "- slot：要裁剪的 Slot 实例（需提前创建）\n"
             "- clip：裁剪附件（ClippingAttachment 实例）\n"
             "- 返回：裁剪后的顶点数量")

        // 2. clipEnd：结束裁剪（两个重载版本：带 Slot 参数 / 无参数）
        .def("clip_end", py::overload_cast<Slot&>(&SkeletonClipping::clipEnd),
             py::arg("slot"),
             "结束指定 Slot 的裁剪操作")
        .def("clip_end", py::overload_cast<>(&SkeletonClipping::clipEnd),
             "结束当前所有裁剪操作（无参数版本）")

        // 3. clipTriangles：裁剪三角形（3 个重载版本，用 overload_cast 区分）
        // 重载1：float* 顶点 + unsigned short* 三角形索引 + 索引长度
        .def("clip_triangles", 
             py::overload_cast<float*, unsigned short*, size_t>(&SkeletonClipping::clipTriangles),
             py::arg("vertices"), py::arg("triangles"), py::arg("triangles_length"),
             "裁剪三角形（基础版本）\n"
             "- vertices：float 数组，存储顶点坐标（x1,y1,x2,y2,...）\n"
             "- triangles：unsigned short 数组，存储三角形索引（每个三角形 3 个索引）\n"
             "- triangles_length：triangles 数组的元素个数（必须是 3 的倍数）")

        // 重载2：带 UV 坐标 + 步长（stride：每个顶点的 UV 数据长度，通常为 2）
        .def("clip_triangles", 
             py::overload_cast<float*, unsigned short*, size_t, float*, size_t>(&SkeletonClipping::clipTriangles),
             py::arg("vertices"), py::arg("triangles"), py::arg("triangles_length"),
             py::arg("uvs"), py::arg("stride"),
             "裁剪三角形（带 UV 坐标版本）\n"
             "- uvs：float 数组，存储顶点的 UV 坐标（u1,v1,u2,v2,...）\n"
             "- stride：每个顶点对应的 UV 数据长度（通常为 2，即 u + v）")

        // 重载3：Spine Vector 版本（最常用，适配 Spine 内部数据结构）
        .def("clip_triangles", 
             py::overload_cast<Vector<float>&, Vector<unsigned short>&, Vector<float>&, size_t>(&SkeletonClipping::clipTriangles),
             py::arg("vertices"), py::arg("triangles"), py::arg("uvs"), py::arg("stride"),
             py::keep_alive<1, 2>(), py::keep_alive<1, 3>(), py::keep_alive<1, 4>(),
             "裁剪三角形（Spine Vector 版本，推荐使用）\n"
             "- vertices：Spine.Vector<float>，存储顶点坐标\n"
             "- triangles：Spine.Vector<unsigned short>，存储三角形索引\n"
             "- uvs：Spine.Vector<float>，存储 UV 坐标\n"
             "- stride：每个顶点的 UV 数据长度（通常为 2）\n"
             "- 注意：函数会直接修改输入的 Vector，不会返回新对象")

        // 4. isClipping：判断是否正在裁剪
        .def("is_clipping", &SkeletonClipping::isClipping,
             py::return_value_policy::copy,
             "判断当前是否处于裁剪状态（返回 True 表示正在裁剪）")

        // 5. 获取裁剪结果（返回内部 Vector 的引用，需用 keep_alive 保持生命周期）
        .def("get_clipped_vertices", &SkeletonClipping::getClippedVertices,
             py::return_value_policy::reference_internal,  // 返回内部引用，不转移所有权
             py::keep_alive<0, 1>(),  // 确保返回的 Vector 生命周期与 SkeletonClipping 一致
             "获取裁剪后的顶点列表（返回 Spine.Vector<float> 引用）")

        .def("get_clipped_triangles", &SkeletonClipping::getClippedTriangles,
             py::return_value_policy::reference_internal,
             py::keep_alive<0, 1>(),
             "获取裁剪后的三角形索引列表（返回 Spine.Vector<unsigned short> 引用）")

        .def("get_clipped_uvs", &SkeletonClipping::getClippedUVs,
             py::return_value_policy::reference_internal,
             py::keep_alive<0, 1>(),
             "获取裁剪后的 UV 坐标列表（返回 Spine.Vector<float> 引用）");

}

