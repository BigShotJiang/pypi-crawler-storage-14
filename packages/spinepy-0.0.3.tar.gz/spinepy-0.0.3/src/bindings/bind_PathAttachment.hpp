// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/PathAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_path_attachment(py::module_& m) {
    py::class_<PathAttachment, VertexAttachment>(m, "PathAttachment")
        .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为附件名称")
        .def("getLengths", &PathAttachment::getLengths, py::return_value_policy::reference_internal, 
             "返回路径各段长度的向量引用")
        .def("isClosed", &PathAttachment::isClosed, "返回路径是否闭合")
        .def("setClosed", &PathAttachment::setClosed, py::arg("inValue"), "设置路径是否闭合")
        .def("isConstantSpeed", &PathAttachment::isConstantSpeed, "返回是否匀速运动")
        .def("setConstantSpeed", &PathAttachment::setConstantSpeed, py::arg("inValue"), "设置是否匀速运动")
        .def("getColor", &PathAttachment::getColor, py::return_value_policy::reference_internal, 
             "返回路径的颜色引用")
        .def("copy", &PathAttachment::copy, 
             "复制附件并返回新实例（返回值需要手动管理生命周期）");
}