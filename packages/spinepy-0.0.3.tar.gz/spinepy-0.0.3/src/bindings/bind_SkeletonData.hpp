// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/SkeletonData.h>

namespace py = pybind11;
using namespace spine;

void bind_skeleton_data(py::module_& m) {
    // 绑定骨骼数据容器类（存储骨骼的所有静态数据）
    py::class_<SkeletonData, SpineObject, std::unique_ptr<SkeletonData>>(m, "SkeletonData")
        // 1. 构造函数与析构函数
        .def(py::init<>(), "构造函数：创建空的骨骼数据容器")
        .def("__del__", [](SkeletonData& self) { /* 交由Spine内部管理析构，避免二次释放 */ },
             "析构函数：由Spine运行时统一管理生命周期")

        // 2. 查找类接口（按名称查找各类数据，返回NULL时Python侧为None）
        .def("find_bone", &SkeletonData::findBone,
             py::arg("bone_name"),
             "按名称查找骨骼数据（BoneData），未找到返回None",
             py::return_value_policy::reference)  // 骨骼数据由SkeletonData管理，返回引用
        .def("find_slot", &SkeletonData::findSlot,
             py::arg("slot_name"),
             "按名称查找插槽数据（SlotData），未找到返回None",
             py::return_value_policy::reference)
        .def("find_skin", &SkeletonData::findSkin,
             py::arg("skin_name"),
             "按名称查找皮肤（Skin），未找到返回None",
             py::return_value_policy::reference)
        .def("find_event", &SkeletonData::findEvent,
             py::arg("event_name"),
             "按名称查找事件数据（EventData），未找到返回None",
             py::return_value_policy::reference)
        .def("find_animation", &SkeletonData::findAnimation,
             py::arg("animation_name"),
             "按名称查找动画（Animation），未找到返回None",
             py::return_value_policy::reference)
        .def("find_ik_constraint", &SkeletonData::findIkConstraint,
             py::arg("constraint_name"),
             "按名称查找IK约束数据（IkConstraintData），未找到返回None",
             py::return_value_policy::reference)
        .def("find_transform_constraint", &SkeletonData::findTransformConstraint,
             py::arg("constraint_name"),
             "按名称查找变换约束数据（TransformConstraintData），未找到返回None",
             py::return_value_policy::reference)
        .def("find_path_constraint", &SkeletonData::findPathConstraint,
             py::arg("constraint_name"),
             "按名称查找路径约束数据（PathConstraintData），未找到返回None",
             py::return_value_policy::reference)
        .def("find_physics_constraint", &SkeletonData::findPhysicsConstraint,
             py::arg("constraint_name"),
             "按名称查找物理约束数据（PhysicsConstraintData），未找到返回None",
             py::return_value_policy::reference)

        // 3. 基础属性（名称、位置、尺寸等）
        .def("get_name", &SkeletonData::getName,
             "获取骨骼数据容器的名称（字符串）",
             py::return_value_policy::reference_internal)  // 内部字符串，不转移所有权
        .def("set_name", &SkeletonData::setName,
             py::arg("name"), "设置骨骼数据容器的名称")
        .def("get_x", &SkeletonData::getX, "获取骨骼的初始X轴位置")
        .def("set_x", &SkeletonData::setX, py::arg("x"), "设置骨骼的初始X轴位置")
        .def("get_y", &SkeletonData::getY, "获取骨骼的初始Y轴位置")
        .def("set_y", &SkeletonData::setY, py::arg("y"), "设置骨骼的初始Y轴位置")
        .def("get_width", &SkeletonData::getWidth, "获取骨骼的宽度（导出时定义）")
        .def("set_width", &SkeletonData::setWidth, py::arg("width"), "设置骨骼的宽度")
        .def("get_height", &SkeletonData::getHeight, "获取骨骼的高度（导出时定义）")
        .def("set_height", &SkeletonData::setHeight, py::arg("height"), "设置骨骼的高度")
        .def("get_reference_scale", &SkeletonData::getReferenceScale,
             "获取骨骼的参考缩放比例（用于适配不同分辨率）")
        .def("set_reference_scale", &SkeletonData::setReferenceScale,
             py::arg("scale"), "设置骨骼的参考缩放比例")

        // 4. 数据列表（骨骼、插槽、皮肤、动画等）
        .def("get_bones", &SkeletonData::getBones,
             "获取所有骨骼数据列表（Vector<BoneData*>，按父骨骼优先排序，根骨骼在首位）",
             py::return_value_policy::reference_internal)
        .def("get_slots", &SkeletonData::getSlots,
             "获取所有插槽数据列表（Vector<SlotData*>，按初始绘制顺序排序）",
             py::return_value_policy::reference_internal)
        .def("get_skins", &SkeletonData::getSkins,
             "获取所有皮肤列表（Vector<Skin*>，包含默认皮肤）",
             py::return_value_policy::reference_internal)
        .def("get_default_skin", &SkeletonData::getDefaultSkin,
             "获取默认皮肤（Skin），未设置时返回None",
             py::return_value_policy::reference)
        .def("set_default_skin", &SkeletonData::setDefaultSkin,
             py::arg("skin"), "设置默认皮肤（Skin）")
        .def("get_events", &SkeletonData::getEvents,
             "获取所有事件数据列表（Vector<EventData*>）",
             py::return_value_policy::reference_internal)
        .def("get_animations", &SkeletonData::getAnimations,
             "获取所有动画列表（Vector<Animation*>）",
             py::return_value_policy::reference_internal)

        // 5. 约束数据列表（各类约束的静态数据）
        .def("get_ik_constraints", &SkeletonData::getIkConstraints,
             "获取所有IK约束数据列表（Vector<IkConstraintData*>）",
             py::return_value_policy::reference_internal)
        .def("get_transform_constraints", &SkeletonData::getTransformConstraints,
             "获取所有变换约束数据列表（Vector<TransformConstraintData*>）",
             py::return_value_policy::reference_internal)
        .def("get_path_constraints", &SkeletonData::getPathConstraints,
             "获取所有路径约束数据列表（Vector<PathConstraintData*>）",
             py::return_value_policy::reference_internal)
        .def("get_physics_constraints", &SkeletonData::getPhysicsConstraints,
             "获取所有物理约束数据列表（Vector<PhysicsConstraintData*>）",
             py::return_value_policy::reference_internal)

        // 6. 导出相关属性（版本、路径、帧率等）
        .def("get_version", &SkeletonData::getVersion,
             "获取导出该骨骼数据的Spine版本（字符串）",
             py::return_value_policy::reference_internal)
        .def("set_version", &SkeletonData::setVersion,
             py::arg("version"), "设置Spine版本字符串")
        .def("get_hash", &SkeletonData::getHash,
             "获取骨骼数据的哈希值（用于校验数据完整性）",
             py::return_value_policy::reference_internal)
        .def("set_hash", &SkeletonData::setHash,
             py::arg("hash"), "设置骨骼数据的哈希值")
        .def("get_images_path", &SkeletonData::getImagesPath,
             "获取图片资源的路径（字符串）",
             py::return_value_policy::reference_internal)
        .def("set_images_path", &SkeletonData::setImagesPath,
             py::arg("path"), "设置图片资源的路径")
        .def("get_audio_path", &SkeletonData::getAudioPath,
             "获取音频资源的路径（字符串）",
             py::return_value_policy::reference_internal)
        .def("set_audio_path", &SkeletonData::setAudioPath,
             py::arg("path"), "设置音频资源的路径")
        .def("get_fps", &SkeletonData::getFps,
             "获取Spine中设置的 dopesheet 帧率（仅导出非必要数据时可用）")
        .def("set_fps", &SkeletonData::setFps,
             py::arg("fps"), "设置dopesheet帧率")

        // 7. 调试字符串（便于Python侧查看核心信息）
        .def("__repr__", [](const SkeletonData& self) {
            SkeletonData& non_const_self = const_cast<SkeletonData&>(self);
            const char* default_skin_name = non_const_self.getDefaultSkin()
                ? non_const_self.getDefaultSkin()->getName().buffer()
                : "null";
            return py::str("SkeletonData(name='{}', bones_count={}, animations_count={}, default_skin='{}')")
                .format(
                    non_const_self.getName().buffer(),
                    non_const_self.getBones().size(),
                    non_const_self.getAnimations().size(),
                    default_skin_name
                );
        });
}