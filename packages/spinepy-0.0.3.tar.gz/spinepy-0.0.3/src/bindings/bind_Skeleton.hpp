// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Skeleton.h>


namespace py = pybind11;
using namespace spine;

void bind_skeleton(py::module_& m) {
    // 绑定骨骼实例类（管理骨骼运行时状态、约束和绘制顺序）
    py::class_<Skeleton, SpineObject, std::unique_ptr<Skeleton>>(m, "Skeleton")
        // 1. 构造函数（通过SkeletonData创建骨骼实例）
        .def(py::init<SkeletonData*>(),
             py::arg("skeleton_data"),
             "构造函数：通过骨骼数据（SkeletonData）创建骨骼实例")

        // 2. 核心更新方法（缓存更新、世界变换计算）
        .def("update_cache", &Skeleton::updateCache,
             "更新骨骼和约束的缓存信息（添加/移除骨骼、约束后必须调用）")
        .def("print_update_cache", &Skeleton::printUpdateCache,
             "打印更新缓存信息（调试用）")
        .def("update_world_transform", py::overload_cast<Physics>(&Skeleton::updateWorldTransform),
             py::arg("physics"),
             "更新所有骨骼的世界变换并应用约束（参数为Physics枚举，控制物理更新逻辑）")
        .def("update_world_transform", py::overload_cast<Physics, Bone*>(&Skeleton::updateWorldTransform),
             py::arg("physics"), py::arg("parent_bone"),
             "更新指定父骨骼及其子骨骼的世界变换并应用约束")

        // 3. 初始姿态设置
        .def("set_to_setup_pose", &Skeleton::setToSetupPose,
             "将所有骨骼、约束和插槽重置为初始姿态")
        .def("set_bones_to_setup_pose", &Skeleton::setBonesToSetupPose,
             "仅将骨骼和约束重置为初始姿态")
        .def("set_slots_to_setup_pose", &Skeleton::setSlotsToSetupPose,
             "仅将插槽重置为初始姿态（包括附件和颜色）")

        // 4. 查找接口（按名称查找骨骼、插槽、约束）
        .def("find_bone", &Skeleton::findBone,
             py::arg("bone_name"),
             "按名称查找骨骼（Bone），未找到返回None",
             py::return_value_policy::reference)  // 骨骼由Skeleton管理，返回引用
        .def("find_slot", &Skeleton::findSlot,
             py::arg("slot_name"),
             "按名称查找插槽（Slot），未找到返回None",
             py::return_value_policy::reference)
        .def("find_ik_constraint", &Skeleton::findIkConstraint,
             py::arg("constraint_name"),
             "按名称查找IK约束（IkConstraint），未找到返回None",
             py::return_value_policy::reference)
        .def("find_transform_constraint", &Skeleton::findTransformConstraint,
             py::arg("constraint_name"),
             "按名称查找变换约束（TransformConstraint），未找到返回None",
             py::return_value_policy::reference)
        .def("find_path_constraint", &Skeleton::findPathConstraint,
             py::arg("constraint_name"),
             "按名称查找路径约束（PathConstraint），未找到返回None",
             py::return_value_policy::reference)
        .def("find_physics_constraint", &Skeleton::findPhysicsConstraint,
             py::arg("constraint_name"),
             "按名称查找物理约束（PhysicsConstraint），未找到返回None",
             py::return_value_policy::reference)
        // 5. 皮肤管理（设置皮肤、获取/设置附件）
        .def("set_skin", py::overload_cast<const String&>(&Skeleton::setSkin),
            py::arg("skin_name"),
            "按名称设置皮肤（内部查找皮肤并应用）")
        .def("set_skin", py::overload_cast<Skin*>(&Skeleton::setSkin),
            py::arg("new_skin"),
            "设置皮肤（Skin实例），新皮肤的附件会替换旧皮肤中对应插槽的附件")
        .def("get_attachment", py::overload_cast<const String&, const String&>(&Skeleton::getAttachment),
            py::arg("slot_name"), py::arg("attachment_name"),
            "按插槽名称和附件名称获取附件（Attachment），未找到返回None",
            py::return_value_policy::reference)
        .def("get_attachment", py::overload_cast<int, const String&>(&Skeleton::getAttachment),
            py::arg("slot_index"), py::arg("attachment_name"),
            "按插槽索引和附件名称获取附件（Attachment），未找到返回None",
            py::return_value_policy::reference)
        .def("set_attachment", &Skeleton::setAttachment,
            py::arg("slot_name"), py::arg("attachment_name"),
            "为指定插槽设置附件（attachment_name为空则移除附件）")

        // 6. 边界计算（获取所有可见附件的轴对齐包围盒AABB）
        .def("get_bounds", py::overload_cast<float&, float&, float&, float&, Vector<float>&>(&Skeleton::getBounds),
             py::arg("out_x"), py::arg("out_y"), py::arg("out_width"), py::arg("out_height"), py::arg("out_vertex_buffer"),
             "计算骨骼所有可见附件的AABB边界：\n"
             "- out_x: 边界左边缘与骨骼原点的水平距离\n"
             "- out_y: 边界下边缘与骨骼原点的垂直距离\n"
             "- out_width: 边界宽度\n"
             "- out_height: 边界高度\n"
             "- out_vertex_buffer: 存储顶点数据的向量（输出参数）")

        //!还没有绑定！！！
        .def("get_bounds", py::overload_cast<float&, float&, float&, float&, Vector<float>&, SkeletonClipping*>(&Skeleton::getBounds),
             py::arg("out_x"), py::arg("out_y"), py::arg("out_width"), py::arg("out_height"), py::arg("out_vertex_buffer"), py::arg("clipper"),
             "计算考虑裁剪附件的AABB边界（clipper为裁剪器实例）")

        // 7. 基础属性（根骨骼、数据、位置、缩放等）
        .def("get_root_bone", &Skeleton::getRootBone,
             "获取根骨骼（Bone），未设置时返回None",
             py::return_value_policy::reference)
        .def("get_data", &Skeleton::getData,
             "获取关联的骨骼数据（SkeletonData）",
             py::return_value_policy::reference)  // 数据由外部管理，返回引用
        .def("get_color", &Skeleton::getColor,
             "获取骨骼整体颜色（Color），影响所有插槽",
             py::return_value_policy::reference_internal)  // 内部颜色对象，返回引用
        .def("set_position", &Skeleton::setPosition,
             py::arg("x"), py::arg("y"), "同时设置骨骼的X和Y轴位置")
        .def("get_x", &Skeleton::getX, "获取骨骼的X轴位置")
        .def("set_x", &Skeleton::setX, py::arg("x"), "设置骨骼的X轴位置")
        .def("get_y", &Skeleton::getY, "获取骨骼的Y轴位置")
        .def("set_y", &Skeleton::setY, py::arg("y"), "设置骨骼的Y轴位置")
        .def("get_scale_x", &Skeleton::getScaleX, "获取骨骼的X轴缩放比例")
        .def("set_scale_x", &Skeleton::setScaleX, py::arg("scale_x"), "设置骨骼的X轴缩放比例")
        .def("get_scale_y", &Skeleton::getScaleY, "获取骨骼的Y轴缩放比例")
        .def("set_scale_y", &Skeleton::setScaleY, py::arg("scale_y"), "设置骨骼的Y轴缩放比例")
        .def("get_time", &Skeleton::getTime, "获取骨骼的当前时间（用于物理模拟）")
        .def("set_time", &Skeleton::setTime, py::arg("time"), "设置骨骼的当前时间")

        // 8. 时间更新与物理操作
        .def("update", &Skeleton::update,
             py::arg("delta"), "更新骨骼时间（delta为时间增量，用于物理模拟）")
        .def("physics_translate", &Skeleton::physicsTranslate,
             py::arg("x"), py::arg("y"),
             "物理平移：旋转物理约束，使下一次update的力模拟骨骼绕世界坐标(x,y)旋转")
        .def("physics_rotate", &Skeleton::physicsRotate,
             py::arg("x"), py::arg("y"), py::arg("degrees"),
             "物理旋转：对所有物理约束应用旋转（绕世界坐标(x,y)旋转指定角度）")

        // 9. 数据列表（骨骼、插槽、约束等）
        .def("get_bones", &Skeleton::getBones,
             "获取所有骨骼列表（Vector<Bone*>，按父骨骼优先排序）",
             py::return_value_policy::reference_internal)
        .def("get_update_cache_list", &Skeleton::getUpdateCacheList,
             "获取可更新对象列表（Vector<Updatable*>，用于约束更新排序）",
             py::return_value_policy::reference_internal)
        .def("get_slots", &Skeleton::getSlots,
             "获取所有插槽列表（Vector<Slot*>，按初始顺序）",
             py::return_value_policy::reference_internal)
        .def("get_draw_order", &Skeleton::getDrawOrder,
             "获取绘制顺序列表（Vector<Slot*>，控制插槽渲染顺序）",
             py::return_value_policy::reference_internal)
        .def("get_ik_constraints", &Skeleton::getIkConstraints,
             "获取所有IK约束列表（Vector<IkConstraint*>）",
             py::return_value_policy::reference_internal)
        .def("get_transform_constraints", &Skeleton::getTransformConstraints,
             "获取所有变换约束列表（Vector<TransformConstraint*>）",
             py::return_value_policy::reference_internal)
        .def("get_path_constraints", &Skeleton::getPathConstraints,
             "获取所有路径约束列表（Vector<PathConstraint*>）",
             py::return_value_policy::reference_internal)
        .def("get_physics_constraints", &Skeleton::getPhysicsConstraints,
             "获取所有物理约束列表（Vector<PhysicsConstraint*>）",
             py::return_value_policy::reference_internal)
        .def("get_skin", &Skeleton::getSkin,
             "获取当前使用的皮肤（Skin），未设置时返回None",
             py::return_value_policy::reference)

        // 10. 调试字符串
        .def("__repr__", [](const Skeleton& self) {
            Skeleton& non_const_self = const_cast<Skeleton&>(self);
            const char* data_name = non_const_self.getData() ? non_const_self.getData()->getName().buffer() : "null";
            return py::str("Skeleton(data='{}', bones_count={}, slots_count={}, skin='{}')")
                .format(
                    data_name,
                    non_const_self.getBones().size(),
                    non_const_self.getSlots().size(),
                    non_const_self.getSkin() ? non_const_self.getSkin()->getName().buffer() : "null"
                );
        });
}