// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Timeline.h>

namespace py = pybind11;
using namespace spine;

void bind_timeline(py::module_& m) {
    // 绑定 Timeline 抽象基类（继承自 SpineObject，含纯虚函数 apply）
    py::class_<Timeline, SpineObject, std::unique_ptr<Timeline, py::nodelete>>(m, "Timeline")

        // 2. 纯虚函数 apply（抽象接口，子类必须实现，绑定为纯虚方法）
        .def("apply", &Timeline::apply,
             py::arg("skeleton"), py::arg("last_time"), py::arg("time"),
             py::arg("events") = static_cast<Vector<Event*>*>(nullptr),  // 默认为空（忽略事件）
             py::arg("alpha") = 1.0f, py::arg("blend"),  // 默认混合模式
             py::arg("direction"),  // 默认混合方向
             "应用时间线到骨骼：\n"
             "- skeleton: 目标骨骼容器\n"
             "- last_time: 上一次应用的时间（用于触发区间内事件）\n"
             "- time: 当前动画时间\n"
             "- events: 接收事件的数组（默认为None，不接收事件）\n"
             "- alpha: 混合系数（0-1，控制时间线影响强度）\n"
             "- blend: 混合模式（MixBlend枚举）\n"
             "- direction: 混合方向（MixDirection枚举）")

        // 3. 帧相关属性（获取帧数量、每帧条目数、帧数据）
        .def("get_frame_count", &Timeline::getFrameCount,
             "获取时间线的总帧数")
        .def("get_frame_entries", &Timeline::getFrameEntries,
             "获取每帧的条目数（单帧数据包含的参数个数）")
        .def("get_frames", &Timeline::getFrames,
             "获取帧数据数组（Vector<float>，存储所有帧的时间和参数）",
             py::return_value_policy::reference_internal)  // 内部容器，不转移所有权

        // 4. 时间线时长与属性ID
        .def("get_duration", &Timeline::getDuration,
             "获取时间线的总时长（最后一帧的时间）")
        .def("get_property_ids", &Timeline::getPropertyIds,
             "获取时间线影响的属性ID列表（Vector<PropertyId>）",
             py::return_value_policy::reference_internal)  // 内部属性ID列表

        // 5. 调试字符串（便于Python侧识别子类实例）
        .def("__repr__", [](const Timeline& self) {
            Timeline& non_const_self = const_cast<Timeline&>(self);
            return py::str("Timeline(type='{}', frame_count={}, duration={})")
                .format(
                    typeid(self).name(),  // 显示实际子类类型（如IkConstraintTimeline）
                    non_const_self.getFrameCount(),
                    non_const_self.getDuration()
                );
        });
}