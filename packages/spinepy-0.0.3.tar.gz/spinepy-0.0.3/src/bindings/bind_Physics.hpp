// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Physics.h>  // 假设包含该枚举的头文件

namespace py = pybind11;
using namespace spine;

void bind_physics_enum(py::module_& m) {
    // 绑定 Physics 枚举，不导出到模块顶层以避免命名污染
    py::enum_<Physics>(m, "Physics")
        .value("NONE", Physics_None, "不更新也不应用物理效果")
        .value("RESET", Physics_Reset, "将物理效果重置为当前姿态")
        .value("UPDATE", Physics_Update, "更新物理效果并应用物理姿态")
        .value("POSE", Physics_Pose, "不更新物理效果但应用物理姿态");
        // 不调用 export_values()，确保枚举值仅通过 Physics 类型访问
}