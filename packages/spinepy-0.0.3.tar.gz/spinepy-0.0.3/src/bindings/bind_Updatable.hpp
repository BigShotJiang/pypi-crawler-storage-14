// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Updatable.h>  // 确保包含Updatable头文件
#include <spine/Physics.h>    // 包含Physics类型的头文件

namespace py = pybind11;
using namespace spine;

// 绑定 Updatable 基类（纯虚类，需用 py::abstract_ 标记）
void bind_updatable(py::module_ &m) {

    // 绑定 Updatable 抽象类（不绑定构造函数）
    py::class_<Updatable, SpineObject>(m, "Updatable")
        // 移除 .def(py::init<>(), ...) 这一行！！！
        // 标记为抽象类（关键）
        .def_property_readonly("__is_abstract__", [](const Updatable&) { return true; })
        // 只绑定纯虚函数的声明（无需实现）
        .def("update", &Updatable::update, py::arg("physics"), "更新方法（纯虚函数）")
        .def("is_active", &Updatable::isActive, "判断是否激活（纯虚函数）")
        .def("set_active", &Updatable::setActive, py::arg("in_value"), "设置激活状态（纯虚函数）");
}