// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/SpineString.h>  // 假设实际头文件是这个

namespace py = pybind11;
using namespace spine;

void bind_spine_string(py::module_ &m) {
    py::class_<String>(m, "String")
        // 构造函数绑定
        .def(py::init<>(), "默认构造函数")
        .def(py::init<const char*>(), py::arg("chars"), "从C字符串构造")
        .def(py::init<const char*, bool, bool>(),
             py::arg("chars"), py::arg("own") = false, py::arg("tofree") = true,
             "从C字符串构造（指定所有权参数）")
        .def(py::init<const String&>(), py::arg("other"), "拷贝构造函数")

        // 基本属性与方法
        .def("length", &String::length, "返回字符串长度")
        .def("is_empty", &String::isEmpty, "判断字符串是否为空")  // 用snake_case适配Python风格
        .def("buffer", &String::buffer,
             py::return_value_policy::reference,  // 不转移所有权，返回内部缓冲区引用
             "返回内部C字符串缓冲区")

        // 所有权管理（处理重载）
        .def("own", py::overload_cast<const String&>(&String::own),
             py::arg("other"), "接管另一个String的内容")
        .def("own", py::overload_cast<const char*>(&String::own),
             py::arg("chars"), "接管C字符串的内容")
        .def("unown", &String::unown, "释放所有权（不释放内存）")

        // 字符串操作（处理append重载）
        .def("append", py::overload_cast<const char*>(&String::append),
             py::arg("chars"), "追加C字符串")
        .def("append", py::overload_cast<const String&>(&String::append),
             py::arg("other"), "追加另一个String")
        .def("append", py::overload_cast<int>(&String::append),
             py::arg("value"), "追加整数")
        .def("append", py::overload_cast<float>(&String::append),
             py::arg("value"), "追加浮点数")

        // 其他字符串方法
        .def("starts_with", &String::startsWith,  // snake_case适配
             py::arg("needle"), "判断是否以指定字符串开头")
        .def("last_index_of", &String::lastIndexOf,  // snake_case适配
             py::arg("c"), "返回字符最后出现的位置")
        .def("substring", py::overload_cast<int, int>(&String::substring, py::const_),
             py::arg("start_index"), py::arg("length"), "截取子字符串（指定长度）")
        .def("substring", py::overload_cast<int>(&String::substring, py::const_),
             py::arg("start_index"), "从指定位置截取到末尾")

        // 赋值运算符
        .def("__assign__", py::overload_cast<const String&>(&String::operator=),
             py::arg("other"), "赋值运算符（String）")
        .def("__assign__", py::overload_cast<const char*>(&String::operator=),
             py::arg("chars"), "赋值运算符（C字符串）")

        // 比较运算符（处理全局友元函数）
        .def("__eq__", [](const String& a, const String& b) { return operator==(a, b); },
             py::arg("other"), "相等比较")
        .def("__ne__", [](const String& a, const String& b) { return operator!=(a, b); },
             py::arg("other"), "不等比较")

        // 与Python字符串的比较
        .def("__eq__", [](const String& a, const std::string& b) {
            return a.buffer() && std::strcmp(a.buffer(), b.c_str()) == 0;
        }, py::arg("other"), "与Python字符串相等比较")
        .def("__ne__", [](const String& a, const std::string& b) {
            return !a.buffer() || std::strcmp(a.buffer(), b.c_str()) != 0;
        }, py::arg("other"), "与Python字符串不等比较")

        // 反向比较（Python字符串 vs String）
        .def("__eq__", [](const std::string& a, const String& b) {
            return b.buffer() && std::strcmp(a.c_str(), b.buffer()) == 0;
        }, "Python字符串与String相等比较")
        .def("__ne__", [](const std::string& a, const String& b) {
            return !b.buffer() || std::strcmp(a.c_str(), b.buffer()) != 0;
        }, "Python字符串与String不等比较")

        // Python特殊方法
        .def("__len__", &String::length, "支持len()函数")
        .def("__bool__", [](const String& s) { return !s.isEmpty(); }, "支持布尔判断（非空即真）")
        .def("__str__", [](const String& s) {
            return s.buffer() ? std::string(s.buffer()) : std::string("");
        }, "转换为Python字符串")
        .def("__repr__", [](const String& s) {
            return s.buffer() ? "spine.String('" + std::string(s.buffer()) + "')" : "spine.String()";
        }, "调试字符串表示")

        // 索引访问（类似Python字符串）
        .def("__getitem__", [](const String& s, int idx) {
            if (idx < 0) idx += static_cast<int>(s.length());  // 支持负索引
            if (idx < 0 || static_cast<size_t>(idx) >= s.length()) {
                throw py::index_error("字符串索引超出范围");
            }
            return s.buffer()[idx];
        }, "通过索引访问字符")

        // 字符串拼接（+运算符）
        .def("__add__", [](const String& a, const String& b) {
            String res(a);
            res.append(b);
            return res;
        }, py::arg("other"), "拼接两个String")
        .def("__add__", [](const String& a, const char* b) {
            String res(a);
            res.append(b);
            return res;
        }, py::arg("other"), "拼接String与C字符串")
        .def("__add__", [](const String& a, const std::string& b) {
            String res(a);
            res.append(b.c_str());
            return res;
        }, py::arg("other"), "拼接String与Python字符串")

        // 字符串重复（*运算符）
        .def("__mul__", [](const String& a, int n) {
            if (n <= 0) return String();
            String res;
            for (int i = 0; i < n; ++i) {
                res.append(a);
            }
            return res;
        }, py::arg("n"), "重复字符串n次")
        .def("__rmul__", [](const String& a, int n) {
            if (n <= 0) return String();
            String res;
            for (int i = 0; i < n; ++i) {
                res.append(a);
            }
            return res;
        }, py::arg("n"), "重复字符串n次");
}