// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/PositionMode.h>

namespace py = pybind11;
using namespace spine;

void bind_position_mode(py::module_& m) {
    py::enum_<PositionMode>(m, "PositionMode")
        .value("FIXED", PositionMode_Fixed, "固定位置模式")
        .value("PERCENT", PositionMode_Percent, "百分比位置模式");
}