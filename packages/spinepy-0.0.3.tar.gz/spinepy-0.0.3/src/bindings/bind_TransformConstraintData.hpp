// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/TransformConstraintData.h>

namespace py = pybind11;
using namespace spine;

void bind_transform_constraint_data(py::module_& m) {
    // 绑定变换约束数据类（继承自 ConstraintData）
    py::class_<TransformConstraintData, ConstraintData>(m, "TransformConstraintData")
        // 构造函数（接收约束名称，骨骼中唯一）
        .def(py::init<const String&>(),
             py::arg("name"),
             "构造函数：传入变换约束名称（骨骼中唯一标识）")

        // 受约束的骨骼列表
        .def("get_bones", &TransformConstraintData::getBones,
             "获取受该变换约束控制的骨骼数据列表（Vector<BoneData*>）",
             py::return_value_policy::reference_internal)  // 内部容器，不转移所有权

        // 目标骨骼操作（约束的目标骨骼）
        .def("get_target", &TransformConstraintData::getTarget,
             "获取变换约束的目标骨骼数据（BoneData）",
             py::return_value_policy::reference)  // 目标骨骼由外部管理，返回引用
        .def("set_target", &TransformConstraintData::setTarget,
             py::arg("target_bone_data"),
             "设置变换约束的目标骨骼数据（BoneData）")

        // 混合系数（控制约束对各变换属性的影响强度，0-1范围）
        .def("get_mix_rotate", &TransformConstraintData::getMixRotate,
             "获取旋转属性的混合系数（0-1，值越大约束影响越强）")
        .def("set_mix_rotate", &TransformConstraintData::setMixRotate,
             py::arg("mix"), "设置旋转属性的混合系数（0-1）")
        .def("get_mix_x", &TransformConstraintData::getMixX,
             "获取X轴位置的混合系数（0-1）")
        .def("set_mix_x", &TransformConstraintData::setMixX,
             py::arg("mix"), "设置X轴位置的混合系数（0-1）")
        .def("get_mix_y", &TransformConstraintData::getMixY,
             "获取Y轴位置的混合系数（0-1）")
        .def("set_mix_y", &TransformConstraintData::setMixY,
             py::arg("mix"), "设置Y轴位置的混合系数（0-1）")
        .def("get_mix_scale_x", &TransformConstraintData::getMixScaleX,
             "获取X轴缩放的混合系数（0-1）")
        .def("set_mix_scale_x", &TransformConstraintData::setMixScaleX,
             py::arg("mix"), "设置X轴缩放的混合系数（0-1）")
        .def("get_mix_scale_y", &TransformConstraintData::getMixScaleY,
             "获取Y轴缩放的混合系数（0-1）")
        .def("set_mix_scale_y", &TransformConstraintData::setMixScaleY,
             py::arg("mix"), "设置Y轴缩放的混合系数（0-1）")
        .def("get_mix_shear_y", &TransformConstraintData::getMixShearY,
             "获取Y轴剪切的混合系数（0-1）")
        .def("set_mix_shear_y", &TransformConstraintData::setMixShearY,
             py::arg("mix"), "设置Y轴剪切的混合系数（0-1）")

        // 偏移量（约束应用时的附加偏移）
        .def("get_offset_rotation", &TransformConstraintData::getOffsetRotation,
             "获取旋转属性的偏移量（角度）")
        .def("set_offset_rotation", &TransformConstraintData::setOffsetRotation,
             py::arg("offset"), "设置旋转属性的偏移量（角度）")
        .def("get_offset_x", &TransformConstraintData::getOffsetX,
             "获取X轴位置的偏移量")
        .def("set_offset_x", &TransformConstraintData::setOffsetX,
             py::arg("offset"), "设置X轴位置的偏移量")
        .def("get_offset_y", &TransformConstraintData::getOffsetY,
             "获取Y轴位置的偏移量")
        .def("set_offset_y", &TransformConstraintData::setOffsetY,
             py::arg("offset"), "设置Y轴位置的偏移量")
        .def("get_offset_scale_x", &TransformConstraintData::getOffsetScaleX,
             "获取X轴缩放的偏移量")
        .def("set_offset_scale_x", &TransformConstraintData::setOffsetScaleX,
             py::arg("offset"), "设置X轴缩放的偏移量")
        .def("get_offset_scale_y", &TransformConstraintData::getOffsetScaleY,
             "获取Y轴缩放的偏移量")
        .def("set_offset_scale_y", &TransformConstraintData::setOffsetScaleY,
             py::arg("offset"), "设置Y轴缩放的偏移量")
        .def("get_offset_shear_y", &TransformConstraintData::getOffsetShearY,
             "获取Y轴剪切的偏移量")
        .def("set_offset_shear_y", &TransformConstraintData::setOffsetShearY,
             py::arg("offset"), "设置Y轴剪切的偏移量")

        // 相对/局部模式开关
        .def("is_relative", &TransformConstraintData::isRelative,
             "判断是否启用相对模式（true=相对目标骨骼变换，false=绝对变换）")
        .def("set_relative", &TransformConstraintData::setRelative,
             py::arg("enable"), "设置是否启用相对模式")
        .def("is_local", &TransformConstraintData::isLocal,
             "判断是否启用局部模式（true=使用骨骼本地坐标系，false=使用世界坐标系）")
        .def("set_local", &TransformConstraintData::setLocal,
             py::arg("enable"), "设置是否启用局部模式")

        // 调试字符串表示
        .def("__repr__", [](const TransformConstraintData& self) {
            // 临时解除const限制（处理非const成员函数）
            TransformConstraintData& non_const_self = const_cast<TransformConstraintData&>(self);
            // 获取目标骨骼名称（若存在）
            const char* target_name = non_const_self.getTarget()
                ? non_const_self.getTarget()->getName().buffer()
                : "null";
            return py::str("TransformConstraintData(name='{}', target='{}', bones_count={})")
                .format(
                    non_const_self.getName().buffer(),  // 从基类继承的名称
                    target_name,
                    non_const_self.getBones().size()     // 受约束骨骼数量
                );
        });
}