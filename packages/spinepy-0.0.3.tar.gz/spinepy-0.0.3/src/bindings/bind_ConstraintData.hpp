// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/ConstraintData.h>

namespace py = pybind11;
using namespace spine;

void bind_constraint_data(py::module_& m) {
    // 绑定约束数据基类 ConstraintData（抽象接口类）
    py::class_<ConstraintData, SpineObject>(m, "ConstraintData")
        // 构造函数（接收约束名称）
        .def(py::init<const String&>(),
             py::arg("name"),
             "构造函数：传入约束名称（骨骼中唯一）")

        // 名称（只读，唯一标识）
        .def("get_name", &ConstraintData::getName,
             "获取约束名称（骨骼中唯一）",
             py::return_value_policy::reference_internal)  // 内部字符串引用

        // 应用顺序（ordinal）
        .def("get_order", &ConstraintData::getOrder,
             "获取约束应用顺序（数值越小越先应用）")
        .def("set_order", &ConstraintData::setOrder,
             py::arg("order"), "设置约束应用顺序")

        // 皮肤相关性
        .def("is_skin_required", &ConstraintData::isSkinRequired,
             "判断约束是否仅在特定皮肤下激活")
        .def("set_skin_required", &ConstraintData::setSkinRequired,
             py::arg("required"), "设置约束是否仅在特定皮肤下激活")

        // 调试字符串表示
        .def("__repr__", [](const ConstraintData& self) {
            // 临时解除 const 限制以调用非 const 成员函数
            ConstraintData& non_const_self = const_cast<ConstraintData&>(self);
            return py::str("ConstraintData(name='{}', order={}, skin_required={})")
                .format(
                    non_const_self.getName().buffer(),
                    non_const_self.getOrder(),
                    non_const_self.isSkinRequired()
                );
        });
}