// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include "spine/BoundingBoxAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_bounding_box_attachment(py::module_& m) {
    py::class_<BoundingBoxAttachment, VertexAttachment>(m, "BoundingBoxAttachment")
        .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为附件名称")
        .def("getColor", &BoundingBoxAttachment::getColor, py::return_value_policy::reference_internal, 
             "返回边界框的颜色引用")
        .def("copy", &BoundingBoxAttachment::copy, 
             "复制附件并返回新实例（返回值需要手动管理生命周期）");
}