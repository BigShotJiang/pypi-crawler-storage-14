// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Atlas.h>
#include <spine/TextureLoader.h>
#include <spine/TextureRegion.h>

namespace py = pybind11;
using namespace spine;

void bind_atlas(py::module_& m) {
    // 1. 绑定枚举类型（保持不变）
    py::enum_<Format>(m, "Format")
        .value("ALPHA", Format_Alpha)
        .value("INTENSITY", Format_Intensity)
        .value("LUMINANCE_ALPHA", Format_LuminanceAlpha)
        .value("RGB565", Format_RGB565)
        .value("RGBA4444", Format_RGBA4444)
        .value("RGB888", Format_RGB888)
        .value("RGBA8888", Format_RGBA8888);
        //.export_values();

    py::enum_<TEXTURE_FILTER_ENUM>(m, "TextureFilter")
        .value("UNKNOWN", TextureFilter_Unknown)
        .value("NEAREST", TextureFilter_Nearest)
        .value("LINEAR", TextureFilter_Linear)
        .value("MIP_MAP", TextureFilter_MipMap)
        .value("MIP_MAP_NEAREST_NEAREST", TextureFilter_MipMapNearestNearest)
        .value("MIP_MAP_LINEAR_NEAREST", TextureFilter_MipMapLinearNearest)
        .value("MIP_MAP_NEAREST_LINEAR", TextureFilter_MipMapNearestLinear)
        .value("MIP_MAP_LINEAR_LINEAR", TextureFilter_MipMapLinearLinear);
        //.export_values();

    py::enum_<TextureWrap>(m, "TextureWrap")
        .value("MIRRORED_REPEAT", TextureWrap_MirroredRepeat)
        .value("CLAMP_TO_EDGE", TextureWrap_ClampToEdge)
        .value("REPEAT", TextureWrap_Repeat);
        //.export_values();
// }
// void bind_atlas_atlas_page(py::module_& m) {
    // 2. 绑定AtlasPage类（保持不变）
    py::class_<AtlasPage, SpineObject>(m, "AtlasPage")
        .def(py::init<const String&>(), py::arg("in_name"))
        .def_readwrite("name", &AtlasPage::name)
        .def_readwrite("texture_path", &AtlasPage::texturePath)
        .def_readwrite("format", &AtlasPage::format)
        .def_readwrite("min_filter", &AtlasPage::minFilter)
        .def_readwrite("mag_filter", &AtlasPage::magFilter)
        .def_readwrite("u_wrap", &AtlasPage::uWrap)
        .def_readwrite("v_wrap", &AtlasPage::vWrap)
        .def_readwrite("width", &AtlasPage::width)
        .def_readwrite("height", &AtlasPage::height)
        .def_readwrite("pma", &AtlasPage::pma)
        .def_readwrite("index", &AtlasPage::index)
        // 用 def_property 替代 def_readwrite，自定义读写逻辑
        .def_property(
            "texture",
            // getter：将 void* 转换为整数（返回给 Python）
            [](const AtlasPage& self) -> uint64_t {
                // 转换 void* 为 uint64_t（适配 64 位系统，32 位可用 uint32_t）
                return reinterpret_cast<uint64_t>(self.texture);
            },
            // setter：将 Python 传入的整数转换为 void*
            [](AtlasPage& self, uint64_t tex_id) {
                // 转换整数为 void*
                self.texture = reinterpret_cast<void*>(tex_id);
            },
            "OpenGL 纹理 ID（通过整数读写）"
        )
        .def("__repr__", [](const AtlasPage& page) {
            return py::str("AtlasPage(name='{}', size=({}, {}))")
                .format(page.name.buffer(), page.width, page.height);
        });
// }
// void bind_atlas_atlas_region(py::module_& m) {
    // 3. 绑定AtlasRegion类（复用Vector绑定，移除手动列表转换）
    py::class_<AtlasRegion, TextureRegion>(m, "AtlasRegion")
        .def(py::init<>())
        .def_readwrite("page", &AtlasRegion::page)
        .def_readwrite("name", &AtlasRegion::name)
        .def_readwrite("index", &AtlasRegion::index)
        .def_readwrite("x", &AtlasRegion::x)
        .def_readwrite("y", &AtlasRegion::y)
        // 直接暴露Vector成员（复用已绑定的Vector接口）
        .def_readonly("splits", &AtlasRegion::splits, "分割数据（spine.VectorInt）")
        .def_readonly("pads", &AtlasRegion::pads, "填充数据（spine.VectorInt）")
        .def_readonly("names", &AtlasRegion::names, "名称列表（spine.VectorString）")
        .def_readonly("values", &AtlasRegion::values, "数值列表（spine.VectorFloat）")
        .def("__repr__", [](const AtlasRegion& region) {
            return py::str("AtlasRegion(name='{}', page='{}')")
                .format(region.name.buffer(), region.page ? region.page->name.buffer() : "null");
        });
// }
// void bind_atlas_atlas(py::module_& m) {
    // 4. 绑定Atlas类（复用Vector绑定）
    py::class_<Atlas, SpineObject>(m, "Atlas")
        .def(py::init<const String&, TextureLoader*, bool>(),
             py::arg("path"), py::arg("texture_loader"), py::arg("create_texture") = true)
        .def(py::init<const char*, int, const char*, TextureLoader*, bool>(),
             py::arg("data"), py::arg("length"), py::arg("dir"), py::arg("texture_loader"), py::arg("create_texture") = true)
        .def("flip_v", &Atlas::flipV)
        .def("find_region", &Atlas::findRegion, py::arg("name"),
             py::return_value_policy::reference)
        // 直接返回Vector对象（复用已绑定的Vector接口）
        .def("get_pages", &Atlas::getPages, 
             py::return_value_policy::reference_internal,  // 内部引用，不转移所有权
             "获取所有AtlasPage的Vector")
        .def("get_regions", &Atlas::getRegions,
             py::return_value_policy::reference_internal,
             "获取所有AtlasRegion的Vector")
        .def("__repr__", [](const Atlas& atlas) {
            // 临时解除 const 限制以调用非 const 的 getPages() 和 getRegions()
            Atlas& non_const_atlas = const_cast<Atlas&>(atlas);
            return py::str("Atlas(pages={}, regions={})")
                .format(non_const_atlas.getPages().size(), non_const_atlas.getRegions().size());
        });
}