// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Event.h>

namespace py = pybind11;
using namespace spine;

void bind_event(py::module_& m) {
    py::class_<Event, SpineObject>(m, "Event")
        // 构造函数（通常由 Spine 内部创建，Python 中可能无需直接调用，但仍绑定）
        .def(py::init<float, const EventData&>(),
             py::arg("time"), py::arg("data"),
             "构造函数：动画时间 + 事件数据（EventData）")

        // 事件数据（只读，关联的 EventData）
        .def("get_data", &Event::getData,
             "获取关联的事件数据（EventData）",
             py::return_value_policy::reference)  // 返回对 EventData 的引用（不转移所有权）

        // 动画时间（只读，事件触发的时间点）
        .def("get_time", &Event::getTime,
             "获取事件在动画中的触发时间")

        // 整数类型值
        .def("get_int_value", &Event::getIntValue,
             "获取整数类型值")
        .def("set_int_value", &Event::setIntValue,
             py::arg("value"), "设置整数类型值")

        // 浮点类型值
        .def("get_float_value", &Event::getFloatValue,
             "获取浮点类型值")
        .def("set_float_value", &Event::setFloatValue,
             py::arg("value"), "设置浮点类型值")

        // 字符串类型值
        .def("get_string_value", &Event::getStringValue,
             "获取字符串类型值",
             py::return_value_policy::reference_internal)  // 内部字符串引用
        .def("set_string_value", &Event::setStringValue,
             py::arg("value"), "设置字符串类型值")

        // 音量
        .def("get_volume", &Event::getVolume,
             "获取音量（0-1范围）")
        .def("set_volume", &Event::setVolume,
             py::arg("volume"), "设置音量（0-1范围）")

        // 声道平衡
        .def("get_balance", &Event::getBalance,
             "获取声道平衡（-1左到1右）")
        .def("set_balance", &Event::setBalance,
             py::arg("balance"), "设置声道平衡（-1左到1右）")

        .def("__repr__", [](const Event& self) {
            // 临时解除 const 限制，调用非 const 成员函数
            Event& non_const_self = const_cast<Event&>(self);
            return py::str("Event(time={:.2f}, data={}, int={}, float={:.2f})")
                .format(
                    non_const_self.getTime(),
                    non_const_self.getData().getName().buffer(),  // 访问关联的 EventData 名称
                    non_const_self.getIntValue(),
                    non_const_self.getFloatValue()
                );
        });
}