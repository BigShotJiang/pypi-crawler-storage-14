// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Property.h>  // 替换为包含 Property 枚举的实际头文件

namespace py = pybind11;
using namespace spine;

void bind_property_enum(py::module_& m) {
    // 2. 绑定 Property 枚举（支持位运算组合）
    py::enum_<Property>(m, "Property", py::arithmetic())  // 启用算术运算（支持 | & 等位操作）
        .value("ROTATE", Property_Rotate, "旋转属性（1 << 0）")
        .value("X", Property_X, "X轴位置属性（1 << 1）")
        .value("Y", Property_Y, "Y轴位置属性（1 << 2）")
        .value("SCALE_X", Property_ScaleX, "X轴缩放属性（1 << 3）")
        .value("SCALE_Y", Property_ScaleY, "Y轴缩放属性（1 << 4）")
        .value("SHEAR_X", Property_ShearX, "X轴剪切属性（1 << 5）")
        .value("SHEAR_Y", Property_ShearY, "Y轴剪切属性（1 << 6）")
        .value("INHERIT", Property_Inherit, "继承属性（1 << 7）")
        .value("RGB", Property_Rgb, "RGB颜色属性（1 << 8）")
        .value("ALPHA", Property_Alpha, "透明度属性（1 << 9）")
        .value("RGB2", Property_Rgb2, "第二个RGB颜色属性（1 << 10）")
        .value("ATTACHMENT", Property_Attachment, "附件属性（1 << 11）")
        .value("DEFORM", Property_Deform, "变形属性（1 << 12）")
        .value("EVENT", Property_Event, "事件属性（1 << 13）")
        .value("DRAW_ORDER", Property_DrawOrder, "绘制顺序属性（1 << 14）")
        .value("IK_CONSTRAINT", Property_IkConstraint, "IK约束属性（1 << 15）")
        .value("TRANSFORM_CONSTRAINT", Property_TransformConstraint, "变换约束属性（1 << 16）")
        .value("PATH_CONSTRAINT_POSITION", Property_PathConstraintPosition, "路径约束位置属性（1 << 17）")
        .value("PATH_CONSTRAINT_SPACING", Property_PathConstraintSpacing, "路径约束间距属性（1 << 18）")
        .value("PATH_CONSTRAINT_MIX", Property_PathConstraintMix, "路径约束混合属性（1 << 19）")
        .value("PHYSICS_CONSTRAINT_INERTIA", Property_PhysicsConstraintInertia, "物理约束惯性属性（1 << 20）")
        .value("PHYSICS_CONSTRAINT_STRENGTH", Property_PhysicsConstraintStrength, "物理约束强度属性（1 << 21）")
        .value("PHYSICS_CONSTRAINT_DAMPING", Property_PhysicsConstraintDamping, "物理约束阻尼属性（1 << 22）")
        .value("PHYSICS_CONSTRAINT_MASS", Property_PhysicsConstraintMass, "物理约束质量属性（1 << 23）")
        .value("PHYSICS_CONSTRAINT_WIND", Property_PhysicsConstraintWind, "物理约束风力属性（1 << 24）")
        .value("PHYSICS_CONSTRAINT_GRAVITY", Property_PhysicsConstraintGravity, "物理约束重力属性（1 << 25）")
        .value("PHYSICS_CONSTRAINT_MIX", Property_PhysicsConstraintMix, "物理约束混合属性（1 << 26）")
        .value("PHYSICS_CONSTRAINT_RESET", Property_PhysicsConstraintReset, "物理约束重置属性（1 << 27）")
        .value("SEQUENCE", Property_Sequence, "序列属性（1 << 28）");
}