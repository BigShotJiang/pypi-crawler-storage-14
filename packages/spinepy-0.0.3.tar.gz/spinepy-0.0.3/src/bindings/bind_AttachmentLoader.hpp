// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include "spine/AttachmentLoader.h"  // 确保路径正确

namespace py = pybind11;
using namespace spine;

void bind_attachment_loader(py::module_& m) {
    // 关键：删除 py::init<>()，不允许直接创建 AttachmentLoader 实例
    py::class_<AttachmentLoader, SpineObject, std::unique_ptr<AttachmentLoader, py::nodelete>>(
        m, "AttachmentLoader"
    )
        // 1. 绑定 newRegionAttachment（纯虚函数，通过 lambda 转发调用）
        .def("newRegionAttachment", 
             [](AttachmentLoader& self, Skin& skin, const String& name, const String& path, Sequence* sequence) -> RegionAttachment* {
                 return self.newRegionAttachment(skin, name, path, sequence);
             }, 
             py::arg("skin"), py::arg("name"), py::arg("path"), py::arg("sequence"),
             "创建新的RegionAttachment\n"
             "参数：\n"
             "  - skin：所属的Skin实例\n"
             "  - name：附件名称\n"
             "  - path：纹理路径\n"
             "  - sequence：关联的Sequence（可为None）\n"
             "返回：新的RegionAttachment实例（可为None，表示不加载该附件）")

        // 2. 绑定 newMeshAttachment
        .def("newMeshAttachment", 
             [](AttachmentLoader& self, Skin& skin, const String& name, const String& path, Sequence* sequence) -> MeshAttachment* {
                 return self.newMeshAttachment(skin, name, path, sequence);
             }, 
             py::arg("skin"), py::arg("name"), py::arg("path"), py::arg("sequence"),
             "创建新的MeshAttachment（返回值可为None）")

        // 3. 绑定 newBoundingBoxAttachment
        .def("newBoundingBoxAttachment", 
             [](AttachmentLoader& self, Skin& skin, const String& name) -> BoundingBoxAttachment* {
                 return self.newBoundingBoxAttachment(skin, name);
             }, 
             py::arg("skin"), py::arg("name"),
             "创建新的BoundingBoxAttachment（返回值可为None）")

        // 4. 绑定 newPathAttachment
        .def("newPathAttachment", 
             [](AttachmentLoader& self, Skin& skin, const String& name) -> PathAttachment* {
                 return self.newPathAttachment(skin, name);
             }, 
             py::arg("skin"), py::arg("name"),
             "创建新的PathAttachment（返回值可为None）")

        // 5. 绑定 newPointAttachment
        .def("newPointAttachment", 
             [](AttachmentLoader& self, Skin& skin, const String& name) -> PointAttachment* {
                 return self.newPointAttachment(skin, name);
             }, 
             py::arg("skin"), py::arg("name"),
             "创建新的PointAttachment（返回值可为None）")

        // 6. 绑定 newClippingAttachment
        .def("newClippingAttachment", 
             [](AttachmentLoader& self, Skin& skin, const String& name) -> ClippingAttachment* {
                 return self.newClippingAttachment(skin, name);
             }, 
             py::arg("skin"), py::arg("name"),
             "创建新的ClippingAttachment（返回值可为None）")

        // 7. 绑定 configureAttachment
        .def("configureAttachment", 
             [](AttachmentLoader& self, Attachment* attachment) {
                 self.configureAttachment(attachment);
             }, 
             py::arg("attachment"),
             "配置附件的附加属性（如渲染参数、自定义数据等）");
}