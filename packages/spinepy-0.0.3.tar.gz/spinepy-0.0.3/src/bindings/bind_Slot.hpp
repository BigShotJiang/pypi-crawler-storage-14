// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "spine/Slot.h"  // 假设包含原始类定义的头文件

namespace py = pybind11;
using namespace spine;

void bind_slot(py::module_& m) {
    py::class_<Slot, SpineObject>(m, "Slot")
        .def(py::init<SlotData&, Bone&>(), py::arg("data"), py::arg("bone"))
        .def("setToSetupPose", &Slot::setToSetupPose)
        .def("getData", &Slot::getData, py::return_value_policy::reference_internal, 
             "Returns the slot's data")
        .def("getBone", &Slot::getBone, py::return_value_policy::reference_internal,
             "Returns the bone this slot is attached to")
        .def("getSkeleton", &Slot::getSkeleton, py::return_value_policy::reference_internal,
             "Returns the skeleton this slot belongs to")
        .def("getColor", &Slot::getColor, py::return_value_policy::reference_internal,
             "Returns the slot's color")
        .def("getDarkColor", &Slot::getDarkColor, py::return_value_policy::reference_internal,
             "Returns the slot's dark color")
        .def("hasDarkColor", &Slot::hasDarkColor,
             "Returns true if the slot has a dark color")
        .def("getAttachment", &Slot::getAttachment, py::return_value_policy::reference,
             "Returns the attachment, or None if no attachment is set")
        .def("setAttachment", &Slot::setAttachment, py::arg("inValue"),
             "Sets the attachment (may be None)")
        .def("getAttachmentState", &Slot::getAttachmentState,
             "Returns the attachment state")
        .def("setAttachmentState", &Slot::setAttachmentState, py::arg("state"),
             "Sets the attachment state")
        .def("getDeform", &Slot::getDeform, py::return_value_policy::reference_internal,
             "Returns the deform vector")
        .def("getSequenceIndex", &Slot::getSequenceIndex,
             "Returns the sequence index")
        .def("setSequenceIndex", &Slot::setSequenceIndex, py::arg("index"),
             "Sets the sequence index");
}