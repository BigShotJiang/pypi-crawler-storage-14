// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/PhysicsConstraintData.h>

namespace py = pybind11;
using namespace spine;

void bind_physics_constraint_data(py::module_& m) {
    // 绑定物理约束数据类（继承自 ConstraintData）
    py::class_<PhysicsConstraintData, ConstraintData>(m, "PhysicsConstraintData")
        // 构造函数（接收约束名称）
        .def(py::init<const String&>(),
             py::arg("name"),
             "构造函数：传入物理约束名称（骨骼中唯一）")

        // 关联骨骼操作
        .def("set_bone", &PhysicsConstraintData::setBone,
             py::arg("bone_data"), "设置关联的骨骼数据（BoneData）")
        .def("get_bone", &PhysicsConstraintData::getBone,
             "获取关联的骨骼数据（BoneData）",
             py::return_value_policy::reference)  // 返回骨骼引用（不转移所有权）

        // 位置与变换属性
        .def("set_x", &PhysicsConstraintData::setX, py::arg("x"), "设置X坐标")
        .def("get_x", &PhysicsConstraintData::getX, "获取X坐标")
        .def("set_y", &PhysicsConstraintData::setY, py::arg("y"), "设置Y坐标")
        .def("get_y", &PhysicsConstraintData::getY, "获取Y坐标")
        .def("set_rotate", &PhysicsConstraintData::setRotate, py::arg("rotate"), "设置旋转角度")
        .def("get_rotate", &PhysicsConstraintData::getRotate, "获取旋转角度")
        .def("set_scale_x", &PhysicsConstraintData::setScaleX, py::arg("scale_x"), "设置X轴缩放")
        .def("get_scale_x", &PhysicsConstraintData::getScaleX, "获取X轴缩放")
        .def("set_shear_x", &PhysicsConstraintData::setShearX, py::arg("shear_x"), "设置X轴剪切")
        .def("get_shear_x", &PhysicsConstraintData::getShearX, "获取X轴剪切")
        .def("set_limit", &PhysicsConstraintData::setLimit, py::arg("limit"), "设置限制值")
        .def("get_limit", &PhysicsConstraintData::getLimit, "获取限制值")

        // 物理参数
        .def("set_step", &PhysicsConstraintData::setStep, py::arg("step"), "设置步长")
        .def("get_step", &PhysicsConstraintData::getStep, "获取步长")
        .def("set_inertia", &PhysicsConstraintData::setInertia, py::arg("inertia"), "设置惯性")
        .def("get_inertia", &PhysicsConstraintData::getInertia, "获取惯性")
        .def("set_strength", &PhysicsConstraintData::setStrength, py::arg("strength"), "设置强度")
        .def("get_strength", &PhysicsConstraintData::getStrength, "获取强度")
        .def("set_damping", &PhysicsConstraintData::setDamping, py::arg("damping"), "设置阻尼")
        .def("get_damping", &PhysicsConstraintData::getDamping, "获取阻尼")
        .def("set_mass_inverse", &PhysicsConstraintData::setMassInverse, py::arg("mass_inverse"), "设置质量倒数")
        .def("get_mass_inverse", &PhysicsConstraintData::getMassInverse, "获取质量倒数")
        .def("set_wind", &PhysicsConstraintData::setWind, py::arg("wind"), "设置风力")
        .def("get_wind", &PhysicsConstraintData::getWind, "获取风力")
        .def("set_gravity", &PhysicsConstraintData::setGravity, py::arg("gravity"), "设置重力")
        .def("get_gravity", &PhysicsConstraintData::getGravity, "获取重力")
        .def("set_mix", &PhysicsConstraintData::setMix, py::arg("mix"), "设置混合系数")
        .def("get_mix", &PhysicsConstraintData::getMix, "获取混合系数")

        // 全局参数开关
        .def("set_inertia_global", &PhysicsConstraintData::setInertiaGlobal, py::arg("global"), "设置惯性是否全局生效")
        .def("is_inertia_global", &PhysicsConstraintData::isInertiaGlobal, "判断惯性是否全局生效")
        .def("set_strength_global", &PhysicsConstraintData::setStrengthGlobal, py::arg("global"), "设置强度是否全局生效")
        .def("is_strength_global", &PhysicsConstraintData::isStrengthGlobal, "判断强度是否全局生效")
        .def("set_damping_global", &PhysicsConstraintData::setDampingGlobal, py::arg("global"), "设置阻尼是否全局生效")
        .def("is_damping_global", &PhysicsConstraintData::isDampingGlobal, "判断阻尼是否全局生效")
        .def("set_mass_global", &PhysicsConstraintData::setMassGlobal, py::arg("global"), "设置质量是否全局生效")
        .def("is_mass_global", &PhysicsConstraintData::isMassGlobal, "判断质量是否全局生效")
        .def("set_wind_global", &PhysicsConstraintData::setWindGlobal, py::arg("global"), "设置风力是否全局生效")
        .def("is_wind_global", &PhysicsConstraintData::isWindGlobal, "判断风力是否全局生效")
        .def("set_gravity_global", &PhysicsConstraintData::setGravityGlobal, py::arg("global"), "设置重力是否全局生效")
        .def("is_gravity_global", &PhysicsConstraintData::isGravityGlobal, "判断重力是否全局生效")
        .def("set_mix_global", &PhysicsConstraintData::setMixGlobal, py::arg("global"), "设置混合系数是否全局生效")
        .def("is_mix_global", &PhysicsConstraintData::isMixGlobal, "判断混合系数是否全局生效")

        // 调试字符串表示
        .def("__repr__", [](const PhysicsConstraintData& self) {
            // 临时解除 const 限制以调用非 const 成员函数
            PhysicsConstraintData& non_const_self = const_cast<PhysicsConstraintData&>(self);
            const char* bone_name = non_const_self.getBone() ? non_const_self.getBone()->getName().buffer() : "null";
            return py::str("PhysicsConstraintData(name='{}', bone='{}', inertia={:.2f})")
                .format(
                    non_const_self.getName().buffer(),
                    bone_name,
                    non_const_self.getInertia()
                );
        });
}