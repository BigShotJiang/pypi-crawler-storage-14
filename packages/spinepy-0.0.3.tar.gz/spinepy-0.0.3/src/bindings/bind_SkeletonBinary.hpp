// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>  // 用于字符串、容器类型适配
#include <spine/SkeletonBinary.h>

namespace py = pybind11;
using namespace spine;

// -------------------------- 关键：静态常量的类外定义 --------------------------
// 骨骼相关常量
const int SkeletonBinary::BONE_ROTATE;
const int SkeletonBinary::BONE_TRANSLATE;
const int SkeletonBinary::BONE_TRANSLATEX;
const int SkeletonBinary::BONE_TRANSLATEY;
const int SkeletonBinary::BONE_SCALE;
const int SkeletonBinary::BONE_SCALEX;
const int SkeletonBinary::BONE_SCALEY;
const int SkeletonBinary::BONE_SHEAR;
const int SkeletonBinary::BONE_SHEARX;
const int SkeletonBinary::BONE_SHEARY;
const int SkeletonBinary::BONE_INHERIT;

// Slot 相关常量（重点包含报错的 SLOT_RGB2）
const int SkeletonBinary::SLOT_ATTACHMENT;
const int SkeletonBinary::SLOT_RGBA;
const int SkeletonBinary::SLOT_RGB;
const int SkeletonBinary::SLOT_RGBA2;  // 对应绑定中的 SLOT_RGBA2
const int SkeletonBinary::SLOT_RGB2;   // 报错的常量，必须定义！
const int SkeletonBinary::SLOT_ALPHA;  // 后续的 SLOT_ALPHA


void bind_skeleton_binary(py::module& m) {
    // 绑定 SkeletonBinary（继承自 SpineObject）
    py::class_<SkeletonBinary, SpineObject>(m, "SkeletonBinary")
        // -------------------------- 1. 绑定静态常量（直接用类内定义的字面量）--------------------------
        // 骨骼相关常量
     //    .def_readonly_static("BONE_ROTATE",    &SkeletonBinary::BONE_ROTATE)
     //    .def_readonly_static("BONE_TRANSLATE", &SkeletonBinary::BONE_TRANSLATE)
     //    .def_readonly_static("BONE_TRANSLATEX",&SkeletonBinary::BONE_TRANSLATEX)
     //    .def_readonly_static("BONE_TRANSLATEY",&SkeletonBinary::BONE_TRANSLATEY)
     //    .def_readonly_static("BONE_SCALE",     &SkeletonBinary::BONE_SCALE)
     //    .def_readonly_static("BONE_SCALEX",    &SkeletonBinary::BONE_SCALEX)
     //    .def_readonly_static("BONE_SCALEY",    &SkeletonBinary::BONE_SCALEY)
     //    .def_readonly_static("BONE_SHEAR",     &SkeletonBinary::BONE_SHEAR)
     //    .def_readonly_static("BONE_SHEARX",    &SkeletonBinary::BONE_SHEARX)
     //    .def_readonly_static("BONE_SHEARY",    &SkeletonBinary::BONE_SHEARY)
     //    .def_readonly_static("BONE_INHERIT",   &SkeletonBinary::BONE_INHERIT)

     //    // Slot 相关常量
     //    .def_readonly_static("SLOT_ATTACHMENT", &SkeletonBinary::SLOT_ATTACHMENT)
     //    .def_readonly_static("SLOT_RGBA",       &SkeletonBinary::SLOT_RGBA)
     //    .def_readonly_static("SLOT_RGB",        &SkeletonBinary::SLOT_RGB)
     //    .def_readonly_static("SLOT_RGBA2",      &SkeletonBinary::SLOT_RGBA2)//////
     //    .def_readonly_static("SLOT_RGB2",       &SkeletonBinary::SLOT_RGB2)
     //    .def_readonly_static("SLOT_ALPHA",      &SkeletonBinary::SLOT_ALPHA)

     //    // 附件相关常量
     //    .def_readonly_static("ATTACHMENT_DEFORM",  &SkeletonBinary::ATTACHMENT_DEFORM)
     //    .def_readonly_static("ATTACHMENT_SEQUENCE", &SkeletonBinary::ATTACHMENT_SEQUENCE)

     //    // 路径相关常量
     //    .def_readonly_static("PATH_POSITION", &SkeletonBinary::PATH_POSITION)
     //    .def_readonly_static("PATH_SPACING",  &SkeletonBinary::PATH_SPACING)
     //    .def_readonly_static("PATH_MIX",      &SkeletonBinary::PATH_MIX)

     //    // 物理相关常量
     //    .def_readonly_static("PHYSICS_INERTIA",  &SkeletonBinary::PHYSICS_INERTIA)
     //    .def_readonly_static("PHYSICS_STRENGTH", &SkeletonBinary::PHYSICS_STRENGTH)
     //    .def_readonly_static("PHYSICS_DAMPING",  &SkeletonBinary::PHYSICS_DAMPING)
     //    .def_readonly_static("PHYSICS_MASS",     &SkeletonBinary::PHYSICS_MASS)
     //    .def_readonly_static("PHYSICS_WIND",     &SkeletonBinary::PHYSICS_WIND)
     //    .def_readonly_static("PHYSICS_GRAVITY",  &SkeletonBinary::PHYSICS_GRAVITY)
     //    .def_readonly_static("PHYSICS_MIX",      &SkeletonBinary::PHYSICS_MIX)
     //    .def_readonly_static("PHYSICS_RESET",    &SkeletonBinary::PHYSICS_RESET)

     //    // 曲线相关常量
     //    .def_readonly_static("CURVE_LINEAR",  &SkeletonBinary::CURVE_LINEAR)
     //    .def_readonly_static("CURVE_STEPPED", &SkeletonBinary::CURVE_STEPPED)
     //    .def_readonly_static("CURVE_BEZIER",  &SkeletonBinary::CURVE_BEZIER)

        // -------------------------- 2. 绑定构造函数（处理依赖类型）--------------------------
        // 构造函数 1：接收 Atlas*（注意：Atlas 需提前绑定，且 Python 侧需传入 Atlas 实例）
        .def(py::init<Atlas*>(), 
             py::arg("atlas"), 
             "通过 Atlas 实例创建 SkeletonBinary（用于加载带纹理的骨骼数据）")

        // 构造函数 2：接收 AttachmentLoader* + 是否拥有 Loader 的标志（默认 false）
        .def(py::init<AttachmentLoader*, bool>(), 
             py::arg("attachment_loader"), py::arg("owns_loader") = false,
             "通过自定义 AttachmentLoader 创建 SkeletonBinary\n"
             "- owns_loader: 若为 true，SkeletonBinary 析构时会自动释放 loader")

        // -------------------------- 3. 绑定核心成员方法 --------------------------
        // 读取二进制骨骼数据（从内存缓冲区）
        .def("read_skeleton_data", &SkeletonBinary::readSkeletonData,
             py::arg("binary"), py::arg("length"),
             py::return_value_policy::take_ownership,  // 让 Python 接管 SkeletonData 的内存释放
             "从内存二进制数据读取骨骼数据\n"
             "- binary: 二进制数据缓冲区（Python 侧传 bytes 或 bytearray）\n"
             "- length: 数据长度\n"
             "- 返回：SkeletonData 实例（需手动管理生命周期，或依赖 Python GC）")

        // 读取骨骼数据文件（从路径）
        .def("read_skeleton_data_file", &SkeletonBinary::readSkeletonDataFile,
             py::arg("path"),
             py::return_value_policy::take_ownership,
             "从文件路径读取骨骼数据（支持 .skel 格式）\n"
             "- path: 文件路径（相对/绝对路径）\n"
             "- 返回：SkeletonData 实例")

        // 设置缩放因子（加载时对骨骼数据进行缩放）
        .def("set_scale", &SkeletonBinary::setScale,
             py::arg("scale"),
             "设置骨骼数据加载时的缩放因子（默认 1.0，>1 放大，<1 缩小）")

        // 获取错误信息（读取失败时用）
        .def("get_error", &SkeletonBinary::getError,
             py::return_value_policy::reference_internal,  // 引用内部字符串，不转移所有权
             "获取最后一次读取操作的错误信息（无错误则返回空字符串）")

        // -------------------------- 4. 析构函数说明（可选）--------------------------
        .def("__repr__", [](const SkeletonBinary& self) {
            SkeletonBinary& non_const_self = const_cast<SkeletonBinary&>(self);
            std::string error_buf = non_const_self.getError().buffer();  // 先把 const char* 转成 std::string
            return "<spine.SkeletonBinary (error: "+error_buf+")>";
        }, "字符串表示（方便调试时查看错误状态）");
}