// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include "spine/PointAttachment.h"

namespace py = pybind11;
using namespace spine;

void bind_point_attachment(py::module_& m) {
    py::class_<PointAttachment, Attachment>(m, "PointAttachment")
        .def(py::init<const String&>(), py::arg("name"), "构造函数，参数为附件名称")
        .def("computeWorldPosition", &PointAttachment::computeWorldPosition, 
             py::arg("bone"), py::arg("ox"), py::arg("oy"), 
             "计算点在世界坐标系中的位置，结果通过ox和oy输出")
        .def("computeWorldRotation", &PointAttachment::computeWorldRotation, py::arg("bone"), 
             "计算点在世界坐标系中的旋转角度")
        .def("getX", &PointAttachment::getX, "返回X坐标")
        .def("setX", &PointAttachment::setX, py::arg("inValue"), "设置X坐标")
        .def("getY", &PointAttachment::getY, "返回Y坐标")
        .def("setY", &PointAttachment::setY, py::arg("inValue"), "设置Y坐标")
        .def("getRotation", &PointAttachment::getRotation, "返回旋转角度")
        .def("setRotation", &PointAttachment::setRotation, py::arg("inValue"), "设置旋转角度")
        .def("getColor", &PointAttachment::getColor, py::return_value_policy::reference_internal, 
             "返回点的颜色引用")
        .def("copy", &PointAttachment::copy, 
             "复制附件并返回新实例（返回值需要手动管理生命周期）");
}