// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <spine/Attachment.h>
#include <spine/SpineObject.h>  // 引入基类头文件

namespace py = pybind11;
using namespace spine;

void bind_attachment(py::module_& m) {
    // 1. 显式声明继承自 SpineObject
    // 2. 抽象基类无需绑定构造函数，使用默认的 holder（通常是 unique_ptr，而非 shared_ptr，需根据实际内存管理调整）
    py::class_<Attachment, SpineObject, std::unique_ptr<Attachment, py::nodelete>>(m, "Attachment")
        // 绑定纯虚函数和普通成员函数（抽象基类的纯虚函数无需实现，由子类覆盖）
        .def("get_name", &Attachment::getName,  // 统一蛇形命名
             "获取附件名称",
             py::return_value_policy::reference_internal)  // 内部字符串引用
        .def("get_ref_count", &Attachment::getRefCount,
             "获取引用计数")
        .def("reference", &Attachment::reference,
             "增加引用计数")
        .def("dereference", &Attachment::dereference,
             "减少引用计数")
        .def("copy", &Attachment::copy,  // 纯虚函数，绑定后由子类实现
             "复制附件（返回新实例）")

        // 调试字符串（处理 const 成员函数问题）
        .def("__repr__", [](const Attachment& self) {
            // 若 getName() 非 const，需临时解除 const 限制
            Attachment& non_const_self = const_cast<Attachment&>(self);
            return py::str("Attachment(name='{}')")
                .format(non_const_self.getName().buffer());
        });
}