// Copyright (c) [GuYeying] [2025]
// This file is part of [Spine Runtimes C++ Bindings for Python], licensed under the MIT License.
// See the LICENSE file in the project root for full license details.
// SPDX-License-Identifier: MIT
#include <pybind11/pybind11.h>
#include <pybind11/functional.h>  // 用于绑定 C++ 函数对象（EventListener）
#include <spine/AnimationState.h>  // 核心类所在头文件

namespace py = pybind11;
using namespace spine;  // 简化 Spine 命名空间访问


void bind_enums(py::module& m) {
    // 1. 动画事件类型：对应动画生命周期的关键节点
    py::enum_<EventType>(m, "EventType")
        .value("START", EventType::EventType_Start)       // 动画开始
        .value("INTERRUPT", EventType::EventType_Interrupt) // 动画被中断
        .value("END", EventType::EventType_End)           // 动画结束
        .value("COMPLETE", EventType::EventType_Complete) // 动画完成（循环结束一次）
        .value("DISPOSE", EventType::EventType_Dispose)   // 动画资源释放
        .value("EVENT", EventType::EventType_Event)       // 自定义事件触发
        .export_values();  // 允许 Python 通过枚举名访问
}

void bind_track_entry(py::module& m) {
    py::class_<TrackEntry, SpineObject, HasRendererObject>(m, "TrackEntry")
        // -------------------------- 只读属性 --------------------------
        .def_property_readonly("track_index", &TrackEntry::getTrackIndex, "轨道索引（int）")
        .def_property_readonly("animation", &TrackEntry::getAnimation, "关联的动画对象（Animation）")
        .def_property_readonly("previous", &TrackEntry::getPrevious, "前一个轨道条目（可能为None）")
        .def_property_readonly("next", &TrackEntry::getNext, "下一个排队的轨道条目（可能为None）")
        .def_property_readonly("mixing_from", &TrackEntry::getMixingFrom, "正在混合的源轨道（可能为None）")
        .def_property_readonly("mixing_to", &TrackEntry::getMixingTo, "正在混合的目标轨道（可能为None）")
        .def_property_readonly("is_complete", &TrackEntry::isComplete, "是否至少完成一次循环（bool）")
        .def_property_readonly("was_applied", &TrackEntry::wasApplied, "是否已应用到骨架（bool）")
        .def_property_readonly("animation_time", &TrackEntry::getAnimationTime, "当前动画时间（秒）")
        .def_property_readonly("mix_time", &TrackEntry::getMixTime, "混合进度时间（秒）")
        .def_property_readonly("mix_duration", &TrackEntry::getMixDuration, "混合总时长（秒）")
        
        // -------------------------- 读写属性 --------------------------
        .def_property("loop", &TrackEntry::getLoop, &TrackEntry::setLoop, "是否循环播放（bool）")
        .def_property("hold_previous", &TrackEntry::getHoldPrevious, &TrackEntry::setHoldPrevious, 
                      "混合时是否保持前一个动画的状态（bool）")
        .def_property("reverse", &TrackEntry::getReverse, &TrackEntry::setReverse, "是否反向播放（bool）")
        .def_property("delay", &TrackEntry::getDelay, &TrackEntry::setDelay, "播放延迟时间（秒）")
        .def_property("track_time", &TrackEntry::getTrackTime, &TrackEntry::setTrackTime, "轨道当前时间（秒）")
        .def_property("track_end", &TrackEntry::getTrackEnd, &TrackEntry::setTrackEnd, "轨道结束时间（秒）")
        .def_property("time_scale", &TrackEntry::getTimeScale, &TrackEntry::setTimeScale, "时间缩放（1.0为正常速度）")
        .def_property("alpha", &TrackEntry::getAlpha, &TrackEntry::setAlpha, "动画透明度（0.0~1.0，控制混合强度）")
        .def_property("mix_blend", &TrackEntry::getMixBlend, &TrackEntry::setMixBlend, "混合模式（MixBlend枚举）")
        
        // -------------------------- 核心方法 --------------------------
        .def("reset_rotation_directions", &TrackEntry::resetRotationDirections, 
             "重置旋转混合方向（避免骨骼绕远路旋转）")
        .def("set_mix_duration", py::overload_cast<float>(&TrackEntry::setMixDuration), 
             py::arg("mix_duration"), "设置混合总时长（秒）")
        .def("set_mix_duration", py::overload_cast<float, float>(&TrackEntry::setMixDuration), 
             py::arg("mix_duration"), py::arg("delay"), "设置混合时长+延迟（秒）")
        .def("is_next_ready", &TrackEntry::isNextReady, "下一个排队动画是否准备好启动（bool）");
}



void bind_animation_state(py::module& m) {
    // 定义 C++ 回调类型（适配 Python 函数/ lambda）
    using AnimationStateListener = void (*)(AnimationState*, EventType, TrackEntry*, Event*);

    py::class_<AnimationState, SpineObject, HasRendererObject>(m, "AnimationState")
        // -------------------------- 构造函数 --------------------------
        .def(py::init<AnimationStateData*>(), py::arg("data"), "通过AnimationStateData创建实例")
        
        // -------------------------- 核心控制方法 --------------------------
        .def("update", &AnimationState::update, py::arg("delta"), "更新动画时间（delta：帧间隔秒数）")
        .def("apply", &AnimationState::apply, py::arg("skeleton"), 
             "将动画应用到骨架（返回是否成功应用，bool）")
        .def("clear_tracks", &AnimationState::clearTracks, "清空所有轨道的动画")
        .def("clear_track", &AnimationState::clearTrack, py::arg("track_index"), 
             "清空指定索引的轨道动画")
        
     // -------------------------- 动画设置与排队 --------------------------
     .def("set_animation", py::overload_cast<size_t, Animation*, bool>(&AnimationState::setAnimation),
          py::arg("track_index"), py::arg("animation"), py::arg("loop"),
          py::return_value_policy::reference,  // 核心：返回的 TrackEntry 由 C++ 管理，Python 不参与释放
          "设置轨道当前动画（覆盖排队动画，返回TrackEntry）")

     .def("set_animation_by_name", py::overload_cast<size_t, const String&, bool>(&AnimationState::setAnimation),
          py::arg("track_index"), py::arg("animation_name"), py::arg("loop"),
          py::return_value_policy::reference,  // 同样适用
          "通过动画名称设置轨道当前动画（返回TrackEntry）")

     .def("add_animation", py::overload_cast<size_t, Animation*, bool, float>(&AnimationState::addAnimation),
          py::arg("track_index"), py::arg("animation"), py::arg("loop"), py::arg("delay"),
          py::return_value_policy::reference,
          "排队添加动画（delay：前一个动画开始后延迟秒数，返回TrackEntry）")

     .def("add_animation_by_name", py::overload_cast<size_t, const String&, bool, float>(&AnimationState::addAnimation),
          py::arg("track_index"), py::arg("animation_name"), py::arg("loop"), py::arg("delay"),
          py::return_value_policy::reference,
          "通过名称排队添加动画（返回TrackEntry）")
        
        // -------------------------- 空动画（混合回初始姿态） --------------------------
        .def("set_empty_animation", &AnimationState::setEmptyAnimation,
             py::arg("track_index"), py::arg("mix_duration"),
             "设置空动画（混合回初始姿态，返回TrackEntry）")
        .def("add_empty_animation", &AnimationState::addEmptyAnimation,
             py::arg("track_index"), py::arg("mix_duration"), py::arg("delay"),
             "排队添加空动画（返回TrackEntry）")
        .def("set_empty_animations", &AnimationState::setEmptyAnimations,
             py::arg("mix_duration"), "所有轨道设置空动画（混合回初始姿态）")
        
        // -------------------------- 状态查询与配置 --------------------------
        .def("get_current", &AnimationState::getCurrent, py::arg("track_index"),
             "获取指定轨道的当前TrackEntry（可能为None）")
        .def_property_readonly("data", &AnimationState::getData, "关联的AnimationStateData")
        .def_property_readonly("tracks", &AnimationState::getTracks, "所有轨道的TrackEntry列表（含None）")
        .def_property("time_scale", &AnimationState::getTimeScale, &AnimationState::setTimeScale,
                      "全局时间缩放（影响所有轨道，1.0为正常）")
        .def_property("manual_track_disposal", &AnimationState::getManualTrackEntryDisposal, &AnimationState::setManualTrackEntryDisposal,
                      "是否手动释放TrackEntry（默认自动，bool）")
        
        // -------------------------- 事件监听 --------------------------
        .def("set_listener", py::overload_cast<AnimationStateListener>(&AnimationState::setListener),
             py::arg("listener"), "设置C风格函数监听（不推荐Python用）")
        .def("set_listener", py::overload_cast<AnimationStateListenerObject*>(&AnimationState::setListener),
             py::arg("listener_object"), "设置对象监听（推荐Python继承AnimationStateListenerObject实现）")
        
        // -------------------------- 事件队列控制 --------------------------
        .def("disable_queue", &AnimationState::disableQueue, "禁用事件队列（立即触发事件）")
        .def("enable_queue", &AnimationState::enableQueue, "启用事件队列（批量触发事件）")
        .def("dispose_track_entry", &AnimationState::disposeTrackEntry, py::arg("entry"),
             "手动释放TrackEntry（需开启manual_track_disposal）");
}

void bind_listener_object(py::module& m) {
    // 1. 显式指定基类 spine::SpineObject（必须已提前绑定！）
    // 2. 直接绑定纯虚函数 callback，不依赖任何 py::is_virtual/pure_virtual 宏
    py::class_<spine::AnimationStateListenerObject>(
        m, "AnimationStateListenerObject"
    )
        .def(
            "callback", 
            &spine::AnimationStateListenerObject::callback,  // 直接传纯虚函数地址
            py::arg("state"),    // 对应 C++ 的 AnimationState*
            py::arg("type"),     // 对应 C++ 的 EventType
            py::arg("entry"),    // 对应 C++ 的 TrackEntry*
            py::arg("event")     // 对应 C++ 的 Event*（允许为 NULL，Python 侧显示为 None）
        );
}

void bind_animation_state_all(py::module& m) {
    bind_enums(m);
    bind_track_entry(m);
    bind_animation_state(m);
    bind_listener_object(m);
}